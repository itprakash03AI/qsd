#!/bin/sh
# 2026-07-15 — optional env-driven runtime config for the SPA.
#
# The browser reads window.APP_CONFIG.apiUrl from /config.js (loaded synchronously
# by index.html).  A browser can't read a container env var directly, so this
# entrypoint bridges the gap: when QS_UI_API_URL is set, it writes config.js (and
# config.json for the fallback path) from the env at container start — the same
# env-driven model the backend already uses.
#
# OPT-IN + fail-safe: when QS_UI_API_URL is unset, the existing config.js is left
# exactly as-is (a mounted ConfigMap or the baked-in default), so this changes
# nothing for deployments that configure the UI via a ConfigMap file mount.
set -eu

BUILD_DIR="${QS_UI_BUILD_DIR:-/app/build}"

if [ -n "${QS_UI_API_URL:-}" ]; then
    # URLs don't contain quotes/backslashes/newlines; strip them defensively so a
    # bad value can't break out of the JS string literal.
    _api=$(printf '%s' "$QS_UI_API_URL"        | tr -d '"\\\n\r')
    _pub=$(printf '%s' "${QS_UI_PUBLISHED_API_URL:-}" | tr -d '"\\\n\r')
    # 2026-10-29: the reports / downloads pods (empty = served by apiUrl)
    _rpt=$(printf '%s' "${QS_UI_REPORT_API_URL:-}"    | tr -d '"\\\n\r')
    _dl=$(printf '%s' "${QS_UI_DOWNLOAD_API_URL:-}"   | tr -d '"\\\n\r')
    # 2026-11-03 Reports app (docs/REPORTS_APP_PLAN_2026_11_03.html): which app this pod
    # serves ("" = QueryStudio, "reports" = the Reports app) and where QueryStudio is
    _prd=$(printf '%s' "${QS_UI_PRODUCT:-}"            | tr -d '"\\\n\r')
    _qsu=$(printf '%s' "${QS_UI_QUERYSTUDIO_URL:-}"    | tr -d '"\\\n\r')

    if printf 'window.APP_CONFIG = { apiUrl: "%s", publishedApiUrl: "%s", reportApiUrl: "%s", downloadApiUrl: "%s", product: "%s", queryStudioUrl: "%s" };\n' \
            "$_api" "$_pub" "$_rpt" "$_dl" "$_prd" "$_qsu" > "$BUILD_DIR/config.js" 2>/dev/null; then
        printf '{ "apiUrl": "%s", "publishedApiUrl": "%s", "reportApiUrl": "%s", "downloadApiUrl": "%s", "product": "%s", "queryStudioUrl": "%s" }\n' \
            "$_api" "$_pub" "$_rpt" "$_dl" "$_prd" "$_qsu" > "$BUILD_DIR/config.json" 2>/dev/null || true
        echo "[ui-config] runtime config from env: apiUrl=$_api reportApiUrl=${_rpt:-(apiUrl)} downloadApiUrl=${_dl:-(apiUrl)}"
    else
        echo "[ui-config] WARNING: QS_UI_API_URL is set but $BUILD_DIR/config.js is" \
             "not writable (read-only ConfigMap mount?) — leaving existing config" \
             "in place." >&2
    fi
else
    echo "[ui-config] QS_UI_API_URL not set — using existing config.js" \
         "(ConfigMap mount or baked-in default)."
fi

exec "$@"
