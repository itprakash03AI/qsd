/**
 * ClockworkAccessContext — the scheduler visibility verdict, read ONCE
 * from the backend and applied by the existing visibility machinery.
 *
 * Plan §7: a scheduler-scoped principal sees the scheduler and nothing
 * else — nav, routes and landing.  The RULE lives in the backend
 * predicate; this context only carries its published verdict.
 * `readSchedulerScope` is the single adapter between the endpoint's shape
 * and the app — re-pointing it when the backend publishes its final shape
 * is a one-line change there, nowhere else.
 *
 * This is PRESENTATION, not the security boundary: every scheduler route
 * is enforced server-side, and `super_admin` bypasses the scope here the
 * way it bypasses every other visibility guard (Phase 107-I).
 *
 * Failure is honest in both directions.  A verdict we could not read
 * must not hide the rest of the app on a network blip, and must not
 * pretend the scheduler is open either: `source: 'unavailable'` renders
 * the scheduler entry, and the scheduler page then shows the backend's
 * own 403 with the reason.
 */
import React, { createContext, useContext, useEffect, useState } from 'react';
import { useAuth } from './AuthContext';
import { isReportsApp } from '../utils/product';
import clockwork, { type SchedulerScope } from '../services/api/clockwork';

export interface ClockworkAccess {
  scope: SchedulerScope;
  /** Where the verdict came from.  `pending` until the first read lands. */
  source: 'backend' | 'unavailable' | 'super_admin' | 'pending' | 'reports_app';
  reason: string;
  canAuthor: boolean;
  /** `can_admin` from the backend: who may author QUERY TEMPLATES (admin-only routes). */
  canAdmin: boolean;
  /** Convenience: the one predicate Layout and App consult. */
  schedulerOnly: boolean;
}

const DEFAULT: ClockworkAccess = {
  scope: 'full', source: 'pending', reason: '', canAuthor: false, canAdmin: false, schedulerOnly: false,
};

const ClockworkAccessContext = createContext<ClockworkAccess>(DEFAULT);

export const useClockworkAccess = (): ClockworkAccess => useContext(ClockworkAccessContext);

const SCOPES: SchedulerScope[] = ['full', 'scheduler_only', 'none'];

/**
 * THE ADAPTER.  Turns whatever GET /api/clockwork/access returned into the
 * app's verdict.  Contract (services/api/clockwork.ts): `{ scope, reason,
 * can_author }`.  Anything not one of the three scopes is treated as
 * unreadable, never as a scope.
 */
export function readSchedulerScope(raw: unknown, role: string | undefined): ClockworkAccess {
  if (role === 'super_admin') {
    return { scope: 'full', source: 'super_admin', reason: 'super_admin bypasses the scope',
             canAuthor: true, canAdmin: true, schedulerOnly: false };
  }
  const r = (raw && typeof raw === 'object') ? raw as Record<string, unknown> : {};
  const scope = r.scope;
  if (typeof scope !== 'string' || !SCOPES.includes(scope as SchedulerScope)) {
    return { scope: 'full', source: 'unavailable',
             reason: `the access verdict could not be read (scope was ${JSON.stringify(scope)})`,
             canAuthor: false, canAdmin: false, schedulerOnly: false };
  }
  if (typeof r.component_key === 'string' && r.component_key !== SCHEDULER_COMPONENT_KEY) {
    console.warn(`[clockwork] backend component_key ${JSON.stringify(r.component_key)} differs from the frontend's ${JSON.stringify(SCHEDULER_COMPONENT_KEY)}; nav/route gating will not narrow`);
  }
  return {
    scope: scope as SchedulerScope,
    source: 'backend',
    reason: typeof r.reason === 'string' ? r.reason : '',
    canAuthor: r.can_author === true,
    canAdmin: r.can_admin === true,
    schedulerOnly: scope === 'scheduler_only',
  };
}

export const ClockworkAccessProvider = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  const role = user?.role;
  const username = user?.username;
  const [access, setAccess] = useState<ClockworkAccess>(DEFAULT);

  useEffect(() => {
    let cancelled = false;
    if (role === 'super_admin') { setAccess(readSchedulerScope(null, role)); return undefined; }
    // 2026-11-03: the Reports app has no scheduling screens and its API (the reports pod) no
    // scheduler routes -- say so rather than ask a question nothing there can answer.
    if (isReportsApp()) {
      setAccess({ scope: 'full', source: 'reports_app', reason: 'scheduling is in QueryStudio',
                  canAuthor: false, canAdmin: false, schedulerOnly: false });
      return undefined;
    }
    clockwork.getAccess()
      .then(raw => { if (!cancelled) setAccess(readSchedulerScope(raw, role)); })
      .catch(err => {
        if (cancelled) return;
        setAccess({ scope: 'full', source: 'unavailable',
                    reason: err?.message || 'the access verdict could not be read',
                    canAuthor: false, canAdmin: false, schedulerOnly: false });
      });
    return () => { cancelled = true; };
    // Re-read when the principal changes (login / logout), not on every render.
  }, [role, username]);

  return (
    <ClockworkAccessContext.Provider value={access}>
      {children}
    </ClockworkAccessContext.Provider>
  );
};

/** The one componentKey the scheduler surface is gated by.  MUST equal
 *  core/clockwork/scope.py SCHEDULER_COMPONENT_KEY: the backend's
 *  /api/app-settings component_visibility map switches every OTHER key
 *  off for a scoped principal, so the existing nav machinery narrows
 *  itself only if this is the key it leaves on.  The access payload
 *  echoes it as `component_key`; readSchedulerScope warns on a mismatch. */
export const SCHEDULER_COMPONENT_KEY = 'clockwork';

/** Does the scope let this nav item / route through?  Applied BEFORE the
 *  role allowlist and the admin visibility map: a scheduler-only
 *  principal's scheduler entry is allowed by the backend verdict, whatever
 *  role string it carries. */
export function allowedUnderScope(access: Pick<ClockworkAccess, 'schedulerOnly'>,
                                  componentKey: string | undefined): boolean | null {
  if (!access.schedulerOnly) return null;   // no opinion — fall through to the usual filters
  return componentKey === SCHEDULER_COMPONENT_KEY;
}
