/**
 * Add, change and remove a dataset's settings (2026-11-04, the owner: "cant modify dataset ...
 * dimension and measure ... even connection and all").  These tabs only listed what was there,
 * though the server could always save them.  Every call goes through the dataset routes, which
 * hold the owner / group / admin rule; a refusal is shown in its own words.
 */
import React, { useState } from 'react';
import { Alert, Autocomplete, Button, Divider, MenuItem, Stack, TextField, Typography } from '@mui/material';
import api from '../../services/api';
import { appConfirm, appPrompt } from '../common/appDialogs';

const message = (e: any, fallback: string) => (typeof e === 'string' ? e : e?.message || fallback);

/** Saves through one road, and says what went wrong. */
function useSave(onChanged: () => void, fallback: string) {
  const [error, setError] = useState<string | null>(null);
  const run = async (work: () => Promise<any>): Promise<boolean> => {
    setError(null);
    try {
      await work();
      onChanged();
      return true;
    } catch (e: any) {
      setError(message(e, fallback));
      return false;
    }
  };
  return { error, run };
}

export const RemoveButton = ({ what, testId, onRemove }: { what: string; testId: string; onRemove: () => void }) => (
  <Button size="small" color="error" data-testid={testId}
          onClick={async () => { if (await appConfirm(`Remove ${what}?`)) onRemove(); }}>Remove</Button>
);

const Heading = ({ children }: { children: React.ReactNode }) => (
  <>
    <Divider sx={{ my: 2 }} />
    <Typography variant="subtitle2" sx={{ mb: 1 }}>{children}</Typography>
  </>
);

/* ── Classes ─────────────────────────────────────────────────────────────── */
export const useClassActions = (onChanged: () => void) => {
  const { error, run } = useSave(onChanged, 'The class could not be saved.');
  return {
    error,
    rename: async (cls: any) => {
      const name = await appPrompt('Class name', cls.label || cls.name);
      if (name?.trim()) await run(() => api.updateDatasetClass(cls.id, { name: name.trim(), label: name.trim() }));
    },
    remove: (id: number) => run(() => api.deleteDatasetClass(id)),
  };
};

export const AddClass = ({ datasetId, onChanged, sortOrder }: { datasetId: number; onChanged: () => void; sortOrder: number }) => {
  const [name, setName] = useState('');
  const { error, run } = useSave(onChanged, 'The class could not be saved.');
  const add = async () => {
    const clean = name.trim();
    if (await run(() => api.createDatasetClass(datasetId, { name: clean, label: clean, sort_order: sortOrder }))) setName('');
  };
  return (
    <>
      <Heading>Add a class</Heading>
      <Stack direction="row" spacing={1}>
        <TextField size="small" label="Name" value={name} onChange={e => setName(e.target.value)}
                   inputProps={{ 'data-testid': 'class-name' }} sx={{ minWidth: 260 }} />
        <Button variant="contained" data-testid="class-add" disabled={!name.trim()} onClick={add}>Add</Button>
      </Stack>
      {error && <Alert severity="error" sx={{ mt: 1 }} data-testid="class-error">{error}</Alert>}
    </>
  );
};

/* ── Relationships ───────────────────────────────────────────────────────── */
const JOIN_TYPES = ['inner', 'left', 'right', 'full'];
const CARDINALITIES = ['many_to_one', 'one_to_many', 'one_to_one', 'many_to_many'];

export const AddRelationship = ({ datasetId, onChanged }: { datasetId: number; onChanged: () => void }) => {
  const empty = { left_table: '', right_table: '', left: '', right: '', join_type: 'inner', cardinality: 'many_to_one' };
  const [f, setF] = useState(empty);
  const set = (k: keyof typeof empty) => (e: any) => setF(v => ({ ...v, [k]: e.target.value }));
  const { error, run } = useSave(onChanged, 'The relationship could not be saved.');
  const ready = f.left_table.trim() && f.right_table.trim() && f.left.trim() && f.right.trim();
  const add = async () => {
    const saved = await run(() => api.createDatasetRelationship(datasetId, {
      left_table: f.left_table.trim(), right_table: f.right_table.trim(),
      join_keys: [{ left: f.left.trim(), right: f.right.trim() }],
      join_type: f.join_type, cardinality: f.cardinality,
    }));
    if (saved) setF(empty);
  };
  return (
    <>
      <Heading>Add a relationship</Heading>
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} flexWrap="wrap" useFlexGap>
        <TextField size="small" label="Left table" value={f.left_table} onChange={set('left_table')} inputProps={{ 'data-testid': 'rel-left-table' }} />
        <TextField size="small" label="Left column" value={f.left} onChange={set('left')} inputProps={{ 'data-testid': 'rel-left' }} />
        <TextField size="small" label="Right table" value={f.right_table} onChange={set('right_table')} inputProps={{ 'data-testid': 'rel-right-table' }} />
        <TextField size="small" label="Right column" value={f.right} onChange={set('right')} inputProps={{ 'data-testid': 'rel-right' }} />
        <TextField select size="small" label="Join" value={f.join_type} onChange={set('join_type')} sx={{ minWidth: 110 }}>
          {JOIN_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
        </TextField>
        <TextField select size="small" label="Cardinality" value={f.cardinality} onChange={set('cardinality')} sx={{ minWidth: 160 }}>
          {CARDINALITIES.map(t => <MenuItem key={t} value={t}>{t.replace(/_/g, ' ')}</MenuItem>)}
        </TextField>
        <Button variant="contained" data-testid="rel-add" disabled={!ready} onClick={add}>Add</Button>
      </Stack>
      {error && <Alert severity="error" sx={{ mt: 1 }} data-testid="rel-error">{error}</Alert>}
    </>
  );
};

/* ── Conditions ──────────────────────────────────────────────────────────── */
/** Add a condition, or change the one passed in `editing`. */
export const ConditionForm = ({ datasetId, editing, onDone }: { datasetId: number; editing: any | null; onDone: () => void }) => {
  const [name, setName] = useState(editing?.label || editing?.name || '');
  const [where, setWhere] = useState(editing?.where_clause || '');
  const { error, run } = useSave(onDone, 'The condition could not be saved.');
  const save = async () => {
    const body = { name: name.trim(), label: name.trim(), where_clause: where.trim() };
    const saved = await run(() => (editing
      ? api.updatePreDefinedCondition(editing.id, body)
      : api.createPreDefinedCondition(datasetId, body)));
    if (saved && !editing) { setName(''); setWhere(''); }
  };
  return (
    <>
      <Heading>{editing ? `Change "${editing.label || editing.name}"` : 'Add a condition'}</Heading>
      <Stack spacing={1}>
        <TextField size="small" label="Name" value={name} onChange={e => setName(e.target.value)}
                   inputProps={{ 'data-testid': 'cond-name' }} sx={{ maxWidth: 360 }} />
        <TextField size="small" label="WHERE clause" multiline minRows={2} value={where}
                   onChange={e => setWhere(e.target.value)} placeholder="REGION = 'EMEA'"
                   inputProps={{ 'data-testid': 'cond-where' }} />
        <Stack direction="row" spacing={1}>
          <Button variant="contained" data-testid="cond-save" disabled={!name.trim() || !where.trim()} onClick={save}>
            {editing ? 'Save' : 'Add'}
          </Button>
          {editing && <Button onClick={onDone}>Cancel</Button>}
        </Stack>
      </Stack>
      {error && <Alert severity="error" sx={{ mt: 1 }} data-testid="cond-error">{error}</Alert>}
    </>
  );
};

/* ── Aggregation awareness ───────────────────────────────────────────────── */
export const AddAggAwareness = ({ datasetId, measures, dimensions, onChanged }: {
  datasetId: number; measures: any[]; dimensions: any[]; onChanged: () => void;
}) => {
  const [measure, setMeasure] = useState<number | ''>('');
  const [table, setTable] = useState('');
  const [dims, setDims] = useState<any[]>([]);
  const { error, run } = useSave(onChanged, 'The rule could not be saved.');
  const add = async () => {
    const saved = await run(() => api.createAggAwareness(datasetId, {
      measure_col_id: Number(measure), agg_table: table.trim(), agg_dimensions: dims.map(d => d.physical_name),
    }));
    if (saved) { setMeasure(''); setTable(''); setDims([]); }
  };
  return (
    <>
      <Heading>Add a rule (admins only)</Heading>
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={1} alignItems="flex-start">
        <TextField select size="small" label="Measure" value={measure} sx={{ minWidth: 200 }}
                   onChange={e => setMeasure(Number(e.target.value))}
                   inputProps={{ 'data-testid': 'agg-measure' }}>
          {measures.map(m => <MenuItem key={m.id} value={m.id}>{m.friendly_name || m.physical_name}</MenuItem>)}
        </TextField>
        <TextField size="small" label="Summary table" value={table} onChange={e => setTable(e.target.value)}
                   inputProps={{ 'data-testid': 'agg-table' }} sx={{ minWidth: 240 }} />
        <Autocomplete multiple size="small" sx={{ minWidth: 280, flex: 1 }} value={dims} options={dimensions}
                      getOptionLabel={(c: any) => c.friendly_name || c.physical_name}
                      onChange={(_, v) => setDims(v)}
                      renderInput={p => <TextField {...p} label="Dimensions in that table" />} />
        <Button variant="contained" data-testid="agg-add" disabled={!measure || !table.trim()} onClick={add}>Add</Button>
      </Stack>
      {error && <Alert severity="error" sx={{ mt: 1 }} data-testid="agg-error">{error}</Alert>}
    </>
  );
};

/* ── A column's type, in its row ─────────────────────────────────────────── */
const AGGREGATED = ['measure', 'kpi'];

const CANNOT_ADD_UP = ['date', 'timestamp', 'datetime', 'time', 'boolean'];

/** A date or a yes/no cannot be added up.  A column listed as a string can: that may be a wrong
 *  guess about a decimal, and the source answers if it really is text. */
export const canBeType = (col: any, next: string): boolean =>
  !(AGGREGATED.includes(next) && CANNOT_ADD_UP.includes(String(col.data_type || '').toLowerCase()));

/** What changing a column's type must also change: a measure needs a way to add up, and
 *  anything else must not keep one.  The data type stays: it says what the column holds, and
 *  writing it here would make a date a number for good.  Detect columns corrects a wrong one. */
export const columnTypeChange = (col: any, next: string): Record<string, any> => {
  const change: Record<string, any> = { column_type: next };
  if (AGGREGATED.includes(next)) {
    if (!col.aggregation) change.aggregation = 'sum';
  } else if (col.aggregation) {
    change.aggregation = '';
  }
  return change;
};

/** The formats on offer for a column, by what it holds.  Anything else can still be typed. */
const DATE_FORMATS = ['YYYY-MM-DD', 'DD-MMM-YYYY', 'DD/MM/YYYY', 'MM/DD/YYYY', 'MMM YYYY'];
const NUMBER_FORMATS = ['#,##0', '#,##0.00', '$#,##0.00', '0.00%'];

export const formatChoices = (dataType?: string): string[] => {
  const t = String(dataType || '').toLowerCase();
  if (t === 'date' || t === 'datetime' || t === 'timestamp') return DATE_FORMATS;
  if (t === 'number') return NUMBER_FORMATS;
  return [...DATE_FORMATS, ...NUMBER_FORMATS];
};

export const FormatPicker = ({ dataType, value, onChange }: {
  dataType?: string; value: string; onChange: (next: string) => void;
}) => (
  <Autocomplete freeSolo options={formatChoices(dataType)} value={value} inputValue={value}
                onChange={(_e, next) => onChange(next ?? '')} onInputChange={(_e, next) => onChange(next)}
                renderInput={params => (
                  <TextField {...params} label="Format" placeholder="Choose, or type your own"
                             helperText="Changes how the value looks, not the value itself."
                             inputProps={{ ...params.inputProps, 'data-testid': 'column-format' }} />
                )} />
);

export const ColumnTypePicker = ({ col, types, onChanged, onError }: {
  col: any; types: readonly string[]; onChanged: () => void; onError: (text: string) => void;
}) => (
  <TextField select size="small" variant="standard" value={col.column_type}
             inputProps={{ 'aria-label': `Type of ${col.friendly_name || col.physical_name}`,
                           'data-testid': `column-type-${col.id}` }}
             onChange={async e => {
               try {
                 await api.updateDatasetColumn(col.id, columnTypeChange(col, e.target.value));
                 onChanged();
               } catch (err: any) {
                 onError(message(err, 'The column could not be saved.'));
               }
             }}>
    {types.map(t => <MenuItem key={t} value={t} disabled={!canBeType(col, t)}>{t}</MenuItem>)}
  </TextField>
);

export const useRemove = (onChanged: () => void) => useSave(onChanged, 'It could not be removed.');
