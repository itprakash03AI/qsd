/**
 * A screen that is not part of the Reports app (2026-11-03; docs/REPORTS_APP_PLAN_2026_11_03.html).
 * Plain words, and a link to the same screen in QueryStudio when its address is configured.
 */
import React from 'react';
import { Box, Button, Typography } from '@mui/material';
import { useLocation, useNavigate } from 'react-router-dom';
import { REPORTS_PATH } from '../utils/reportUrls';
import { queryStudioLink } from '../utils/product';

export default function NotInReportsApp() {
  const location = useLocation();
  const navigate = useNavigate();
  const link = queryStudioLink(`${location.pathname}${location.search}`);
  return (
    <Box sx={{ maxWidth: 640, mx: 'auto', mt: 8, textAlign: 'center' }} data-testid="not-in-reports-app">
      <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>This page is in QueryStudio</Typography>
      <Typography color="text.secondary" sx={{ mb: 3 }}>
        The Reports app has the report screens only. {link ? 'Open this page in QueryStudio instead.' : 'Ask your administrator for the QueryStudio address.'}
      </Typography>
      <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center' }}>
        {link && <Button variant="contained" href={link} data-testid="open-in-querystudio">Open in QueryStudio</Button>}
        <Button onClick={() => navigate(REPORTS_PATH)} data-testid="back-to-reports">Back to the reports</Button>
      </Box>
    </Box>
  );
}
