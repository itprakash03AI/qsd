/**
 * Single source of truth for the window.APP_CONFIG runtime contract.
 *
 * Loaded synchronously by index.html via /config.js BEFORE the React
 * bundle parses, then potentially merged with /config.json by
 * main.tsx's ensureAppConfig() async fallback.
 *
 * Deep-dive #8 (2026-06-30): consolidated here from prior duplicate
 * declarations in main.tsx + services/api/core.ts.  TypeScript's
 * declaration merging would silently widen the interface if the two
 * sites drifted -- maintainers thought "edit either site, they're in
 * sync" but actually the merger just picked up the union of both,
 * making "missing field on one side" invisible.  One file, one truth.
 */
// Bootstrap config-load status, surfaced on window by main.tsx's
// ensureAppConfig() so downstream code (AuthContext offline banner) can
// explain WHY the API is unreachable.  Lives HERE (a .d.ts in tsconfig
// `include`) rather than in main.tsx so every module -- and the IDE's TS
// language server -- always sees the Window augmentation.  A `declare
// global` inside main.tsx (a regular module) is only reliably visible once
// that module is loaded into the program, which is why AuthContext.tsx
// intermittently reported "__QS_BOOTSTRAP_STATUS__ does not exist on Window".
//   - 'ok'                -> config loaded cleanly (config.js OR config.json had apiUrl)
//   - 'empty'             -> bootstrap succeeded but apiUrl is empty (same-origin assumed)
//   - 'config_js_404'     -> config.js script tag failed to load
//   - 'config_json_404'   -> /config.json fetch returned non-2xx
//   - 'config_json_html'  -> /config.json hijacked by SPA catch-all (HTML body)
//   - 'config_json_threw' -> /config.json fetch threw (network down at boot)
export type BootstrapStatus =
  | 'ok' | 'empty'
  | 'config_js_404' | 'config_json_404' | 'config_json_html' | 'config_json_threw';

declare global {
  interface Window {
    APP_CONFIG?: {
      apiUrl?: string;
      publishedApiUrl?: string;
      /**
       * Base URL of the dedicated Report API pod
       * (QS_POD_ROLE=api + QUERYSTUDIO_REPORTS_MODE=true).
       *
       * EMPTY = shared mode: report traffic goes to `apiUrl`, exactly as
       * before. Set it only when reports run on their own pod -- without it
       * that pod exists but nothing ever calls it, so the CPU offload it was
       * deployed for never happens.
       */
      reportApiUrl?: string;
      /**
       * Base URL of the dedicated Download Centre pod
       * (QS_POD_ROLE=api + QUERYSTUDIO_DOWNLOADS_MODE=true).
       *
       * EMPTY = shared mode: /api/downloads/* and /api/exports go to
       * `apiUrl`, exactly as before.  Set it only when the Download
       * Centre runs on its own pod -- without it that pod exists and
       * nothing calls it, so the offload it was deployed for (preview /
       * chart / pivot compete with query execution on the API pod's
       * worker pool) never happens.
       */
      downloadApiUrl?: string;
      /**
       * 2026-11-03 -- which app this UI pod serves: empty = QueryStudio, "reports" = the
       * Reports app (docs/REPORTS_APP_PLAN_2026_11_03.html; utils/product.ts).  Same image.
       */
      product?: string;
      /** The QueryStudio app's address, for the Reports app's "open in QueryStudio" links. */
      queryStudioUrl?: string;
      // Phase 154 (2026-06-25) -- extended fields surfaced by the
      // newer Helm chart (k8s/querystudioapi-helm/ui).
      environment?: string;
      defaultTimezone?: string;
      features?: {
        sparkConnectUi?: boolean;
        multiPodDashboard?: boolean;
      };
    };
    __QS_BOOTSTRAP_STATUS__?: BootstrapStatus;
  }
}
export {};
