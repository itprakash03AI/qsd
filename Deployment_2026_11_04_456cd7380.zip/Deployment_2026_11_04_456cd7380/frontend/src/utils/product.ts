/**
 * Which app this UI serves (2026-11-03; docs/REPORTS_APP_PLAN_2026_11_03.html).
 *
 * The same image serves QueryStudio and the Reports app; the UI pod's start-up config says
 * which (`window.APP_CONFIG.product`: empty = QueryStudio, "reports" = the Reports app, set
 * from QS_UI_PRODUCT by docker-entrypoint.sh).  The Reports app shows only the report screens
 * (REPORTS_APP_PATHS); any other screen is a plain page with a link to QueryStudio at
 * `window.APP_CONFIG.queryStudioUrl`.  Its API calls go to its `apiUrl` -- the reports pod --
 * whose routes are Reports API v1 (backend/core/reports_api_v1.py).
 */

/** The screens of the Reports app: a path belongs when it is one of these or under one. */
export const REPORTS_APP_PATHS = [
  '/',                         // home (the report portal's landing)
  '/finance-reports',          // list, viewer, studio, canvas builder, templates
  '/report-portal',
  '/report-catalog',
  '/dashboards',
  '/downloads',
  '/file-preview',
  '/value-lists',
  '/switched-off',
  '/login',
  '/shared-business-report',
  '/embedded-business-report',
  '/shared-dashboard',
];

export function isReportsApp(): boolean {
  return String((typeof window !== 'undefined' && window.APP_CONFIG?.product) || '').trim().toLowerCase() === 'reports';
}

export function inReportsApp(path: string): boolean {
  const p = (path || '/').split(/[?#]/)[0] || '/';
  return REPORTS_APP_PATHS.some(r => (r === '/' ? p === '/' : p === r || p.startsWith(`${r}/`)));
}

/** QueryStudio's address for a path ('' when not configured -- the link is then not offered). */
export function queryStudioLink(path: string): string {
  const base = String((typeof window !== 'undefined' && window.APP_CONFIG?.queryStudioUrl) || '').trim().replace(/\/+$/, '');
  return base ? `${base}${path.startsWith('/') ? path : `/${path}`}` : '';
}

/** The menu sections this app shows: everything in QueryStudio; the report screens in the Reports app. */
export function productSections<T extends { items: any[] }>(sections: T[]): T[] {
  if (!isReportsApp()) return sections;
  return sections
    .map(s => ({
      ...s,
      items: s.items
        .map(item => (Array.isArray(item.children)
          ? { ...item, children: item.children.filter((c: any) => inReportsApp(c.path)) }
          : item))
        .filter(item => (Array.isArray(item.children) ? item.children.length > 0 : inReportsApp(item.path))),
    }))
    .filter(s => s.items.length > 0);
}
