-- =============================================================================
--  QueryStudio: set up reports directly from PostgreSQL, every type
-- =============================================================================
--  Run this on QueryStudio's own PostgreSQL database (psql, DBeaver, pgAdmin --
--  any client; no psql-only commands).  Each call below queues ONE report, by
--  NAMES, never ids.  QueryStudio picks it up within about a minute and saves it
--  through the same checks as the screen.  Never INSERT into business_reports.
--
--  HOW TO USE
--    1. Change YOUR_CONNECTION to your connection's name, and the FROM line in
--       step 1 to your table.
--    2. Run the file as it is: every call has  true  as its second value, a DRY
--       RUN, which checks the names and saves nothing.
--    3. Read the result (the last statement):  SELECT * FROM qs_report_apply_status
--    4. Change  true  to  false  on the reports you want, and run them again.
--
--  Running a name again UPDATES that report and keeps its link.  Pick what you
--  need; each call stands alone once the dataset in step 1 exists.
--
--  Guide: docs/REPORTS_FROM_SQL_GUIDE_2026_11_04.html
--  Proven on the Docker rig by scripts/docker_proof/reports_from_sql_proof.py
-- =============================================================================


-- ---------------------------------------------------------------------------
-- 1. THE DATA: one dataset, with its columns detected.  Reports below use it.
--    This call really saves (false): the reports' names can only be checked
--    against a dataset that exists.  Wait a minute before running step 2.
-- ---------------------------------------------------------------------------
SELECT qs_report_apply($spec$ {
  "name": "Finance - start here",
  "type": "table",
  "dataset_sql": {
    "name": "FACT_TETB_REPORTS",
    "connection": "YOUR_CONNECTION",
    "sql": "SELECT FACT_TETB.BUSINESS_CLOSE_DATE AS \"Close Date\", FACT_TETB.SAP_COMPANY_ID AS \"Sap Company Code\", FACT_TETB.TRANSACTIONAL_CURRENCY_ID AS \"Transactional Currency\", FACT_TETB.BOOK_NAME AS \"Source Book Code\", FACT_TETB.DOC_TYPE_ID AS \"Sap Doc Type\", CAST(SUM(FACT_TETB.USD_CURRENCY_AMOUNT) AS DOUBLE) AS \"USD Currency Amount\", CAST(SUM(FACT_TETB.GBP_CURRENCY_AMOUNT) AS DOUBLE) AS \"GBP Currency Amount\", CAST(SUM(FACT_TETB.TRANSACTIONAL_CURRENCY_AMOUNT) AS DOUBLE) AS \"Transactional Currency Amount\", CAST(SUM(FACT_TETB.LIMIT_AMOUNT) AS DOUBLE) AS \"Facility Limit Amount\", CAST(SUM(FACT_TETB.UNDRAWN_AMOUNT) AS DOUBLE) AS \"Facility Undrawn Amount\" FROM icbg.fins.fact_tetb FACT_TETB GROUP BY 1, 2, 3, 4, 5"
  },
  "columns": ["Sap Company Code", "USD Currency Amount"]
} $spec$::jsonb, false);


-- ---------------------------------------------------------------------------
-- 2. A TABLE: columns, a sort, a filter the person picks when they run it
-- ---------------------------------------------------------------------------
SELECT qs_report_apply($spec$ {
  "name": "Finance - balances by company",
  "type": "table",
  "dataset": "FACT_TETB_REPORTS",
  "description": "Balances by company and currency.",
  "columns": ["Sap Company Code", "Transactional Currency", "USD Currency Amount", "GBP Currency Amount"],
  "order_by": [{"column": "USD Currency Amount", "direction": "desc"}],
  "drill_hierarchy": {"name": "Company to book",
                      "levels": ["Sap Company Code", "Transactional Currency", "Source Book Code"]},
  "parameters": [{"name": "company", "label": "Company", "parameter_type": "multi_select",
                  "column": "Sap Company Code", "is_required": false}],
  "published": true
} $spec$::jsonb, true);


-- ---------------------------------------------------------------------------
-- 3. A PIVOT: rows, columns, the numbers in the middle
-- ---------------------------------------------------------------------------
SELECT qs_report_apply($spec$ {
  "name": "Finance - pivot by company and currency",
  "type": "pivot",
  "dataset": "FACT_TETB_REPORTS",
  "pivot": {"rows": ["Sap Company Code"], "columns": ["Transactional Currency"],
            "values": [{"column": "USD Currency Amount", "aggregation": "sum"}]}
} $spec$::jsonb, true);


-- ---------------------------------------------------------------------------
-- 4. A CANVAS: your own page of tiles.  layout: x and w across 12 columns.
--    kind: number table pivot heatmap bar hbar stacked_bar line area
--    stacked_area combo radar pie donut treemap funnel waterfall scatter bubble
-- ---------------------------------------------------------------------------
SELECT qs_report_apply($spec$ {
  "name": "Finance - my page",
  "type": "canvas",
  "dataset": "FACT_TETB_REPORTS",
  "columns": ["Sap Company Code", "Transactional Currency", "USD Currency Amount"],
  "theme": "Finance Blue",
  "tiles": [
    {"kind": "number", "title": "USD in all",
     "measures": [{"column": "USD Currency Amount", "aggregation": "sum"}],
     "layout": {"x": 0, "y": 0, "w": 4, "h": 3}},
    {"kind": "number", "title": "GBP in all",
     "measures": [{"column": "GBP Currency Amount", "aggregation": "sum"}],
     "layout": {"x": 4, "y": 0, "w": 4, "h": 3}},
    {"kind": "hbar", "title": "Top 10 companies", "top_n": 10,
     "dimensions": ["Sap Company Code"],
     "measures": [{"column": "USD Currency Amount", "aggregation": "sum"}],
     "sort": {"by": "measure", "dir": "desc"},
     "layout": {"x": 0, "y": 3, "w": 8, "h": 8}},
    {"kind": "donut", "title": "By currency",
     "dimensions": ["Transactional Currency"],
     "measures": [{"column": "USD Currency Amount", "aggregation": "sum"}],
     "layout": {"x": 8, "y": 0, "w": 4, "h": 11}}
  ]
} $spec$::jsonb, true);


-- ---------------------------------------------------------------------------
-- 5. A READY-MADE DESIGN: name the design and fill its slots with your columns
-- ---------------------------------------------------------------------------
SELECT qs_report_apply($spec$ {"name": "Finance - financial summary", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "financial_summary",
  "slots": {"date": ["Close Date"], "categories": ["Sap Company Code"], "amounts": ["USD Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - day on day", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "day_on_day",
  "slots": {"date": ["Close Date"], "categories": ["Sap Company Code"], "amounts": ["USD Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - trend", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "trend_over_time",
  "slots": {"date": ["Close Date"], "categories": ["Transactional Currency"], "amounts": ["USD Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - operations dashboard", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "operations_dashboard",
  "slots": {"date": ["Close Date"], "categories": ["Sap Company Code", "Transactional Currency"],
            "amounts": ["USD Currency Amount", "GBP Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - budget vs actual", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "budget_vs_actual",
  "slots": {"date": ["Close Date"], "categories": ["Sap Company Code"],
            "actual": ["USD Currency Amount"], "budget": ["GBP Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - top N", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "top_n_ranking",
  "slots": {"category": ["Sap Company Code"], "amount": ["USD Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - mix", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "mix_share",
  "slots": {"categories": ["Transactional Currency"], "amount": ["USD Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - detail listing", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "detail_listing",
  "slots": {"date": ["Close Date"], "categories": ["Sap Company Code"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - heatmap", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "matrix_heatmap",
  "slots": {"categories": ["Sap Company Code", "Transactional Currency"], "amount": ["USD Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - month-end pack", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "multi_page_pack",
  "slots": {"date": ["Close Date"], "categories": ["Sap Company Code", "Transactional Currency"],
            "amounts": ["USD Currency Amount", "GBP Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - P&L bridge", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "pnl_bridge",
  "slots": {"date": ["Close Date"], "categories": ["Sap Company Code"], "total": ["Transactional Currency Amount"],
            "parts": ["USD Currency Amount", "GBP Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - statement", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "statement",
  "slots": {"date": ["Close Date"], "levels": ["Sap Company Code", "Transactional Currency"],
            "amounts": ["USD Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - limit usage", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "limit_usage",
  "slots": {"categories": ["Sap Company Code"], "usage": ["Facility Undrawn Amount"], "limit": ["Facility Limit Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - ageing", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "ageing_buckets",
  "slots": {"bucket": ["Sap Doc Type"], "owners": ["Sap Company Code"], "amount": ["USD Currency Amount"]}} $spec$::jsonb, true);

SELECT qs_report_apply($spec$ {"name": "Finance - breaks", "type": "template", "dataset": "FACT_TETB_REPORTS",
  "template": "break_report",
  "slots": {"keys": ["Sap Company Code"], "side_a": ["USD Currency Amount"], "side_b": ["GBP Currency Amount"]}} $spec$::jsonb, true);


-- ---------------------------------------------------------------------------
-- 6. A REPORT ON YOUR OWN SQL: your query as written.  Saves it as an SQL file
--    named like the report.  To use a file you saved already, give "sql_file".
--    For a database connection (Trino, Starburst, Snowflake, Oracle ...).  S3 files
--    have no engine of their own for this: use type table with dataset_sql instead.
-- ---------------------------------------------------------------------------
SELECT qs_report_apply($spec$ {
  "name": "Finance - my own query",
  "type": "sql",
  "connection": "YOUR_CONNECTION",
  "sql": "SELECT FACT_TETB.SAP_COMPANY_ID AS \"Sap Company Code\", CAST(SUM(FACT_TETB.USD_CURRENCY_AMOUNT) AS DOUBLE) AS \"USD Currency Amount\" FROM icbg.fins.fact_tetb FACT_TETB GROUP BY 1"
} $spec$::jsonb, true);


-- ---------------------------------------------------------------------------
-- WHAT HAPPENED: state is pending, running, done or failed; error says why
-- ---------------------------------------------------------------------------
SELECT request_id, report_name, state, dry_run, action, report_id, slug, error
FROM qs_report_apply_status
ORDER BY request_id DESC
LIMIT 25;
