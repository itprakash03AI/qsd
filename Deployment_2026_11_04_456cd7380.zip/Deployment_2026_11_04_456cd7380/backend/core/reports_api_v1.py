"""Reports API v1 -- the ONE list of routes the Reports app may call and the reports pod serves
(2026-11-03; docs/REPORTS_APP_PLAN_2026_11_03.html section 3.2, the owner's option B of 2026-10-26).

A route belongs to v1 when its path IS one of ``PREFIXES`` or starts with one followed by "/".
Two guards hold the list in place (``backend/tests/test_reports_api_v1_2026_11_03.py``):

  * the reports pod serves EXACTLY this surface -- every v1 prefix has a route there (a missing
    router is a failing test, never a 404 in front of a person), and every route it serves is in
    the list or is ``OPERATIONAL`` (health, metrics, docs);
  * every API call the Reports app's code makes is in the list (from step 3 of the plan, when the
    app exists), so the app cannot drift into another feature's routes.

``PREFIXES`` maps each prefix to the plain words of what it is for -- the guard's message when one
is missing.
"""
from __future__ import annotations

from typing import Dict, Iterable, List

PREFIXES: Dict[str, str] = {
    # reports: run, view, edit, export, share, embed, comments, sign-off, instances
    "/api/business-reports": "reports",
    "/api/shared-business-report": "a shared report",
    "/api/embedded-business-report": "an embedded report",
    "/api/report-themes": "report themes",
    "/api/report-templates": "report templates",
    "/api/report-parameter-templates": "parameter templates",
    # the semantic layer reports are built on
    "/api/datasets": "datasets",
    "/api/columns": "column mapping",
    # subscriptions and their e-mails
    "/api/subscriptions": "subscriptions",
    "/api/unsubscribe": "the unsubscribe link",
    # dashboards (Reports owns Dashboards, decided 2026-10-26)
    "/api/dashboards": "dashboards",
    "/api/shared-dashboard": "a shared dashboard",
    # finding reports
    "/api/portal": "the report portal",
    "/api/report-catalog": "the report catalog",
    "/api/report-folders": "report folders",
    "/api/report-tags": "report tags",
    "/api/reports": "the catalog's report list",
    "/api/report-usage": "report usage",
    # the lists behind parameter choices
    "/api/value-lists": "value lists",
    # the person: sign-in, what they may do, their notifications
    "/auth": "sign-in",
    "/api/me/capabilities": "what the signed-in person may do",
    "/api/notifications": "notifications",
    # what every screen asks as it opens: role-resolved settings, the person's preferences and drafts
    "/api/app-settings": "the app's settings for the signed-in person",
    "/api/user-preferences": "the person's preferences",
    "/api/user/drafts": "the person's unsaved drafts",
    "/api/user/drafts-by-prefix": "the person's unsaved drafts, by kind",
    "/api/admin/drafts": "how many drafts are kept (admin)",
    # a report / dashboard / value list deleted = switched off; the one way back
    "/api/config/switched-off": "switched-off settings",
    # report admin settings served by the reports pod
    "/api/admin/business-reports": "report admin queues and settings",
    "/api/admin/reports/config": "report settings",
    "/api/admin/delivery/config": "delivery settings",
    "/api/admin/pivot/config": "pivot settings",
    "/api/admin/federation/config": "federation settings",
    "/api/admin/semantic-layer/config": "semantic layer settings",
    "/api/admin/agg-cache": "the aggregate cache",
    "/api/admin/diagnostics": "diagnostics",
}

#: served by every pod for the platform itself, not part of the product surface
OPERATIONAL = ("/", "/health", "/metrics", "/api/health", "/api/version", "/openapi.json", "/docs",
               "/api-docs", "/api-redoc", "/ws")


def _under(path: str, prefix: str) -> bool:
    return path == prefix or path.startswith(prefix.rstrip("/") + "/")


def in_v1(path: str) -> bool:
    return any(_under(path, p) for p in PREFIXES)


def is_operational(path: str) -> bool:
    return path == "/" or any(_under(path, p) for p in OPERATIONAL if p != "/")


def missing_prefixes(served: Iterable[str]) -> List[str]:
    """The v1 prefixes a pod serves NO route under, in words."""
    paths = list(served)
    return [f"{p} ({words})" for p, words in PREFIXES.items() if not any(_under(x, p) for x in paths)]


def outside_v1(served: Iterable[str]) -> List[str]:
    """Routes a pod serves that are neither v1 nor operational."""
    return sorted({x for x in served if not in_v1(x) and not is_operational(x)})
