"""Retention sweeps, as daemons the SCHEDULER POD can own.

WHY THIS MODULE EXISTS
----------------------
Four DB-retention sweeps — ETL executions, feed executions, data-quality
results, agent decision logs — lived as inline ``while True: sleep(); DELETE``
closures inside ``main.py``'s startup.  That placement had a consequence
nobody had to decide on: they ran wherever the HTTP app ran, and nowhere else.

* Gating them behind the pod role removed them from the API pod and from
  every other pod at once, because ``scheduler_worker.py`` starts
  ``init_scheduler`` plus a registered daemon list and never touched these.
  Result: no sweeps at all, i.e. silent unbounded table growth.
* Leaving them ungated kept database maintenance running inside the pod that
  serves queries, alongside DuckDB's memory limit.

Both options were wrong because the daemons were not RELOCATABLE.  Here they
become ordinary APScheduler registrations with the same ``register_*(sched,
db_manager)`` shape as every other brain daemon, so the scheduler pod can own
them and the API pod can decline them — the arrangement an operator gets when
they stand up a separate background-jobs pod.

Each job:
  * reads its own interval / retention from config, so behaviour is unchanged;
  * is individually try/except'd — one sweep's failure never stops another;
  * honours ``core.background_jobs.is_paused()`` via the registry entry, so an
    admin can pause it;
  * is idempotent and safe to run on more than one pod (the DELETEs are
    bounded by age, not by cursor), which matters during a rolling upgrade
    when both an old and a new pod are briefly live.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Iterable, Optional

logger = logging.getLogger(__name__)

#: Registered job ids — kept here so main.py's gate and the worker agree on
#: the names, and so an operator greps one list.
JOB_IDS = (
    "etl_cleanup",
    "feed_cleanup",
    "dq_cleanup",
    "agent_log_cleanup",
    "pv_cleanup",
    # 2026-09-15 — two more retention values that were a PROMISE WITH NO
    # MECHANISM.  row_security.audit_retention_days (30) and
    # delivery.delivery_history_retention_days (90) were both declared, both
    # shown, and neither swept, so both tables grew without bound.  The RLS
    # one is the sharper case: DatabaseManager.cleanup_row_security_audit
    # already EXISTED, fully written and tested, with zero callers -- BUILT
    # is indistinguishable from WIRED, again.
    "rls_audit_cleanup",
    "delivery_history_cleanup",
    # 2026-09-15 — the only sweep here that deletes FILES rather than rows.
    # Its function has said "call from a scheduled job" since it was written
    # and no job called it.
    "query_log_cleanup",
    # 2026-09-27 -- not a retention sweep: the daily CLOSE-OUT DIGEST
    # (core/feed/close_out_digest.py).  It lives in this list because this
    # list IS the platform's relocatable-daemon contract: a name here is
    # registered on the scheduler pod, owned in daemon_registry, and gated
    # by its literal in main.py, and three guards fail when any leg is
    # missing.  Its tick is cheap and idempotent (a DB marker per group and
    # date), so N pods ticking send one digest.
    "feed_close_out_digest",
    # 2026-09-28 -- the feed CONSUMER late watcher (core/feed/consumer_
    # notices.py): a tick that raises ONE "late" notice per (feed, business
    # date) whose SLA passed with no delivery, for the consumers who asked.
    # Idempotent through the feed_consumer_notices ledger (insert-first
    # under a unique key), so N pods ticking tell one person once.
    "feed_consumer_late_watch",
    # 2026-10-03 -- the SHARED rate limiter's finished windows
    # (rate_limit_windows, core/rate_limiter.py): one row per (action,
    # identity, window), so without a sweep every API key and login address
    # adds a row a minute forever.  Retention is
    # queue.rate_limit_window_retention_seconds (3600; 0 = keep forever).
    "rate_limit_window_cleanup",
    # 2026-10-07 -- the FILE arrival watcher (core/feed/file_arrival_source.
    # py): a tick that lists each declared file-dependency location for the
    # WAIT runs in the window and records the arrival once the files (and
    # the control file) are there.  Not a sweep; it rides this list because
    # this list IS the relocatable-daemon contract.  Single runner: the
    # tick acts only in the scheduler-lock holder (the same predicate the
    # dependency poller that releases the run reads), so N hybrid pods list
    # once; arrivals are one per (dependency, date, source) regardless.
    "feed_dependency_file_watch",
    # 2026-10-11 -- the ORACLE-TABLE arrival watcher (core/feed/
    # oracle_table_source.py): a tick that reads the new rows of each
    # configured upstream Oracle table (the OG QS_KAFKA_MESSAGE landing
    # table), resolves them through the Kafka resolver rules and records
    # the arrivals.  Same relocatable-daemon contract, same single runner
    # (the scheduler-lock holder); the rows land deduplicated regardless.
    "feed_dependency_oracle_table_watch",
    # 2026-10-13 -- feed template create/update/apply requests queued FROM
    # SQL (qs_feed_template_apply(), core/feed/template_requests.py), applied
    # through the template routes by the scheduler-lock holder.
    "feed_template_requests",
    # 2026-11-04 -- reports queued FROM SQL (qs_report_apply(), core/reports/from_sql.py),
    # applied through the routes the screen uses by the scheduler-lock holder.
    "report_requests",
    # 2026-10-17 -- the published-API ROLLUP (core/published_api/rollup.py):
    # raw call rows -> hourly / daily buckets with a latency histogram, the
    # dashboard's numbers, OFF the published-api pod's hot path.  Idempotent
    # per bucket (a replace in one transaction); the lock holder rolls.
    "published_api_rollup",
    # 2026-10-24 -- named value lists (core/value_lists.py): a DAILY list is
    # re-synced from its own connection once its interval has passed; a list
    # whose last sync failed is retried each tick.  The lock holder syncs.
    "value_list_sync",
    # 2026-10-29 -- the query-pod scaler (core/query_pods/scaler.py): per
    # size, watch KEDA (alert in words) or scale the Deployment itself; one
    # controller per size.  The lock holder scales -- never two scalers.
    "query_pod_scaler",
    # 2026-11-02 -- who watches the watcher (core/component_health/
    # scheduler_deadman.py): the JOB-WORKER raises one "the scheduler is not
    # running" alert when lock row 1 stops heartbeating; the fleet watcher that
    # raises every other alert runs ON the scheduler, so it cannot.
    "scheduler_deadman",
)


def _hours(cfg: Any, attr: str, default: int) -> int:
    """Interval in seconds, floored at one hour — matching the inline loops'
    ``max(cfg.cleanup_interval_hours * 3600, 3600)``."""
    try:
        return max(int(getattr(cfg, attr, default)) * 3600, 3600)
    except Exception:
        return max(int(default) * 3600, 3600)


def _safe(label: str, fn: Callable[[], Any],
          out: Optional[Dict[str, Any]] = None) -> Any:
    """Run one sweep, never propagate.  A retention DELETE failing must not
    take down the scheduler thread that also runs mirrors and prefetch.

    2026-10-07: records the sweep's count under ``label`` in ``out`` (and a
    failure under ``out["errors"]``) so every runner returns what it did --
    the background-job ledger classifies a scheduled fire from that dict,
    and a runner that returned None read as "fired, outcome unknown"."""
    try:
        n = fn()
        if n:
            logger.info("[retention] %s: %s row(s)", label, n)
        if out is not None:
            out[label] = n if n is not None else 0
        return n
    except Exception as exc:
        logger.warning("[retention] %s failed (non-fatal): %s", label, exc)
        if out is not None:
            out.setdefault("errors", []).append(f"{label}: {exc}"[:200])
        return None


def _skipped(reason: str) -> Dict[str, Any]:
    return {"status": "skipped", "reason": reason}


def _keep_forever_guard(out: Dict[str, Any], label: str, key: str, days: Any) -> int:
    """``0`` (or less, or unreadable) = KEEP FOREVER, on every sweep.

    2026-10-08: four of the sweeps (etl / feed / dq / pv) passed the
    retention straight to a DELETE whose cutoff is ``now - days``, so a
    retention of 0 -- the value the rls / delivery / query-log / agent-log
    siblings document as "keep forever" -- deleted EVERY row.  One knob,
    two meanings, and the wrong one is the data-loss direction.  The leg is
    recorded as skipped with the key named, so the ledger says why.
    """
    try:
        n = int(days)
    except (TypeError, ValueError):
        n = 0
    if n <= 0:
        out[f"{label} skipped"] = f"{key} = {days!r} (keep forever)"
        return 0
    return n


def _safe_dict(label: str, fn: Callable[[], Dict[str, Any]],
               count_key: str) -> Dict[str, Any]:
    """A runner whose module returns its OWN summary dict (status + lists):
    return it as-is so the ledger reads the module's verdict; log the count
    the retention log line used to show."""
    try:
        out = fn()
        if isinstance(out, dict) and out.get("status") == "ran":
            v = out.get(count_key)
            # a module may report its count as a NUMBER (the published-API rollup's
            # 'rows') or as a list; len() of an int made every rollup tick read
            # 'failed' in the ledger (2026-10-18, the rig)
            n = v if isinstance(v, int) else len(v or [])
            if n:
                logger.info("[retention] %s: %s row(s)", label, n)
            return out
        return out if isinstance(out, dict) else {"result": out}
    except Exception as exc:
        logger.warning("[retention] %s failed (non-fatal): %s", label, exc)
        return {"error": f"{label}: {exc}"[:300]}


# ── the four sweeps ────────────────────────────────────────────────────────

def run_etl_cleanup(db_manager: Any) -> Dict[str, Any]:
    from core.config import etl_pipelines as _cfg

    out: Dict[str, Any] = {}
    _safe("etl stale-reset", lambda: db_manager.reset_stale_running_executions(
        stale_minutes=getattr(_cfg, "stale_execution_minutes", 60)), out)
    # 2026-09-16 -- the fallback MUST equal the declared default (90).  It was
    # 30: if the accessor were ever missing this sweep would silently delete
    # THREE TIMES as much execution history as the operator configured, and a
    # retention sweep that over-deletes is data loss, not a tuning drift.
    # Same class as the six iceberg fallbacks fixed today; this one is the
    # dangerous direction.
    days = _keep_forever_guard(out, "etl executions",
                               "etl_pipelines.execution_history_retention_days",
                               getattr(_cfg, "execution_history_retention_days", 90))
    if days:
        _safe("etl executions", lambda: db_manager.cleanup_old_etl_executions(days), out)
    return out


def run_feed_cleanup(db_manager: Any) -> Dict[str, Any]:
    from core.config import feed_generation as _fg_cfg

    out: Dict[str, Any] = {}
    _safe("feed stale-reset",
          lambda: db_manager.reset_stale_feed_executions(stale_minutes=60), out)

    def _clean():
        # raises when the engine is not initialised in this process or the
        # legal-hold store cannot be read -- ``_safe`` records it under
        # ``errors``; a silent 0 used to read as "nothing to reap"
        from core.feed_engine import cleanup_old_executions
        return cleanup_old_executions()

    if _keep_forever_guard(out, "feed executions",
                           "feed_generation.execution_history_retention_days",
                           getattr(_fg_cfg, "execution_history_retention_days", 90)):
        _safe("feed executions", _clean, out)
    return out


def run_dq_cleanup(db_manager: Any) -> Dict[str, Any]:
    from core.config import data_quality as _cfg

    out: Dict[str, Any] = {}
    # the fallback equals the DECLARED default (90) -- it was 30, the
    # 2026-09-16 over-deleting class, reachable only if the accessor vanished
    days = _keep_forever_guard(out, "dq results", "data_quality.result_retention_days",
                               getattr(_cfg, "result_retention_days", 90))
    if days:
        _safe("dq results", lambda: db_manager.cleanup_dq_results(days), out)
    return out


def run_agent_log_cleanup(db_manager: Any) -> Dict[str, Any]:
    from core.config import get as _get

    days = _get("agents", "max_decision_log_days", 30)
    if not days or int(days) <= 0:
        return _skipped("agents.max_decision_log_days <= 0 (keep forever)")
    out: Dict[str, Any] = {}
    _safe("agent decision log",
          lambda: db_manager.cleanup_agent_decisions(max_age_days=int(days)), out)
    return out


def run_pv_cleanup(db_manager: Any) -> Dict[str, Any]:
    """Published-Views retention: stale API access logs + expired cache
    files.

    2026-08-20 — the FIFTH sweep to join this module, for the same reason as
    the first four: it lived only as an inline thread in main.py (Phase 75),
    so gating it off the API pod deleted it — access logs grew unbounded on
    any api/worker split.  Registered UNCONDITIONALLY (keeps the JOB_IDS
    count invariant the guard tests pin); the sweep itself no-ops when
    published_views is disabled, mirroring main.py's ``_pv_cfg.enabled``
    gate.
    """
    from core.config import published_views as _pv_cfg

    if not getattr(_pv_cfg, "enabled", False):
        return _skipped("published_views.enabled is false")

    out: Dict[str, Any] = {}
    days = _keep_forever_guard(out, "pv access logs",
                               "published_views.access_log_retention_days",
                               _pv_cfg.access_log_retention_days)
    if days:
        _safe("pv access logs", lambda: db_manager.cleanup_api_access_logs(
            retention_days=days), out)

    def _clean_cache_files():
        # Stale cache files older than max TTL * 2 — same rule as the
        # inline loop.
        import time as _t
        from pathlib import Path as _P
        cache_dir = _P(_pv_cfg.cache_dir)
        if not cache_dir.exists():
            return 0
        max_age = max(_pv_cfg.default_cache_ttl_seconds * 2, 3600)
        now = _t.time()
        n = 0
        for f in cache_dir.glob("*.parquet"):
            if now - f.stat().st_mtime > max_age:
                f.unlink(missing_ok=True)
                # its truth sidecar goes with it (a bypass run's too, 2026-10-24)
                _P(str(f) + ".manifest.json").unlink(missing_ok=True)
                n += 1
        return n

    _safe("pv cache files", _clean_cache_files, out)
    return out


def run_rls_audit_cleanup(db_manager: Any) -> Dict[str, Any]:
    """Purge row_security_audit rows past their retention.

    The DELETE has been implemented since the RLS audit shipped and was
    never called from anywhere.  ``audit_retention_days`` therefore read as
    a policy an operator could rely on, while the table kept every row ever
    written -- and an audit table is one of the few that a compliance answer
    is EXPECTED to be able to bound.  0 = keep forever.
    """
    from core.config import row_security as _rs_cfg

    days = int(getattr(_rs_cfg, "audit_retention_days", 30) or 0)
    if days <= 0:
        return _skipped("row_security.audit_retention_days = 0 (keep forever)")
    out: Dict[str, Any] = {}
    _safe("row security audit",
          lambda: db_manager.cleanup_row_security_audit(days), out)
    return out


def run_delivery_history_cleanup(db_manager: Any) -> Dict[str, Any]:
    """Purge delivery_history rows past their retention.

    One row per delivery attempt per schedule per burst recipient: on a
    daily estate this is the fastest-growing table nobody was watching.
    0 = keep forever.
    """
    from core.config import delivery as _dl_cfg

    days = int(getattr(_dl_cfg, "delivery_history_retention_days", 90) or 0)
    if days <= 0:
        return _skipped("delivery.delivery_history_retention_days = 0 (keep forever)")
    out: Dict[str, Any] = {}
    _safe("delivery history",
          lambda: db_manager.cleanup_delivery_history(retention_days=days), out)
    return out


def run_query_log_cleanup(db_manager: Any) -> Dict[str, Any]:
    """Delete per-query log files past their retention.

    2026-09-15 — ``core/execution_stage.py::cleanup_old_query_logs`` has
    carried the instruction "Call from a scheduled job" in its own docstring
    since it was written, and NOTHING called it.  A comment is not a caller
    (the 2026-09-01 ``init_persistence`` incident, one more time), so one log
    FILE PER QUERY accumulated on the pod's disk forever -- a filesystem
    leak, which no table-retention sweep would ever have noticed.

    ``db_manager`` is unused: this sweep touches the filesystem, not the
    database.  It takes the argument so the registration shape stays
    identical to its five siblings; a special-cased job is a job someone
    forgets when the table moves.
    """
    from core.config import get as _get

    # Fallbacks equal the declared defaults AND equal cleanup_old_query_logs'
    # own signature defaults (7, 1000) -- the three must agree or the knob
    # means something different depending on which one you read.
    days = int(_get("query_logs", "retention_days", 7) or 0)
    if days <= 0:
        return _skipped("query_logs.retention_days = 0 (keep forever)")
    max_files = int(_get("query_logs", "max_files", 1000) or 1000)

    def _sweep() -> int:
        from core.execution_stage import cleanup_old_query_logs
        return cleanup_old_query_logs(retention_days=days, max_files=max_files)

    out: Dict[str, Any] = {}
    _safe("query logs", _sweep, out)
    return out


def run_feed_close_out_digest(db_manager: Any) -> Dict[str, Any]:
    """One tick of the daily close-out digest (2026-09-27).

    Sends nothing until the configured time has passed, sends each group's
    digest once per business date, and is a no-op with a reason when the
    mailer is not configured.  The whole answer is in the module; this is
    the daemon-shaped caller.
    """
    def _tick():
        from core.feed.close_out_digest import run_close_out_digest_tick
        return run_close_out_digest_tick(db_manager)

    # The module's own summary (status / sent / reason) is the record; a
    # real send logs its count, a not-due / unconfigured tick stays quiet.
    return _safe_dict("feed close-out digest", _tick, count_key="sent")


def close_out_digest_interval_seconds() -> int:
    from core.feed.close_out_digest import load_config
    try:
        return int(load_config()["check_interval_seconds"])
    except Exception:
        return 300


def run_feed_consumer_late_watch(db_manager: Any) -> Dict[str, Any]:
    """One tick of the feed consumer LATE watcher (2026-09-28): one notice
    per (feed, business date) past its SLA with nothing delivered, to the
    consumers subscribed to ``late``, once.  The answer is in the module;
    this is the daemon-shaped caller."""
    def _tick():
        from core.feed.consumer_notices import late_tick
        return late_tick(db_manager)

    return _safe_dict("feed consumer late watch", _tick, count_key="late")


def run_rate_limit_window_cleanup(db_manager: Any) -> Dict[str, Any]:
    """Delete shared rate-limit windows that ended more than
    ``queue.rate_limit_window_retention_seconds`` ago (2026-10-03).  0 =
    keep forever.  Idempotent and bounded by age, so N pods sweeping is
    harmless."""
    from core.config import queue as _q_cfg

    seconds = int(getattr(_q_cfg, "rate_limit_window_retention_seconds", 3600) or 0)
    if seconds <= 0:
        return _skipped("queue.rate_limit_window_retention_seconds = 0 (keep forever)")

    def _sweep() -> int:
        from core.rate_limiter import sweep_expired_windows
        return sweep_expired_windows(db_manager, retention_seconds=seconds)

    out: Dict[str, Any] = {}
    _safe("rate limit windows", _sweep, out)
    return out


def consumer_late_watch_interval_seconds() -> int:
    from core.feed.consumer_notices import load_config
    try:
        return int(load_config()["check_interval_seconds"])
    except Exception:
        return 300


def run_feed_dependency_file_watch(db_manager: Any) -> Dict[str, Any]:
    """One tick of the FILE arrival watcher (2026-10-07): list every
    declared file-dependency location a WAIT run is held on and record the
    arrival once the files (and the control file) have landed.  The answer
    is in the module; this is the daemon-shaped caller.

    Acts only in the process holding the scheduler lock -- the predicate
    the dependency poller (which then releases the run) reads per tick.  On
    the scheduler pod APScheduler runs only there anyway; on hybrid pods
    this keeps N replicas from listing the same prefixes N times."""
    from core.scheduler import _this_process_runs_apscheduler
    if not _this_process_runs_apscheduler():
        logger.debug("[file_arrival] not the scheduler-lock holder -- the "
                     "watcher runs elsewhere")
        return _skipped("not the scheduler-lock holder")

    def _tick():
        from core.feed.file_arrival_source import watch_tick
        return watch_tick(db_manager)

    # The watcher's own summary (status ran/disabled/error, targets,
    # arrivals, waiting, unreadable) is the record.
    return _safe_dict("feed dependency file watch", _tick, count_key="detail")


def dependency_file_watch_interval_seconds() -> int:
    from core.feed.file_arrival_source import load_config
    try:
        return int(load_config()["interval_seconds"])
    except Exception:
        return 60


def run_feed_dependency_oracle_table_watch(db_manager: Any) -> Dict[str, Any]:
    """One tick of the ORACLE-TABLE arrival watcher (2026-10-11): read each
    configured upstream table's new rows, resolve them through the Kafka
    resolver rules and record the arrivals -- the OG landing table driving
    dependencies exactly like the topic.  The answer is in the module; this
    is the daemon-shaped caller.

    Acts only in the process holding the scheduler lock, like the file
    watcher: N hybrid pods must not each read the table and race to land
    the same rows (the landing dedupes, but the reads are not free)."""
    from core.scheduler import _this_process_runs_apscheduler
    if not _this_process_runs_apscheduler():
        logger.debug("[oracle_table_source] not the scheduler-lock holder -- the "
                     "watcher runs elsewhere")
        return _skipped("not the scheduler-lock holder")

    def _tick():
        from core.feed.oracle_table_source import watch_tick
        return watch_tick(db_manager)

    return _safe_dict("feed dependency oracle table watch", _tick, count_key="detail")


def run_feed_template_requests(db_manager: Any) -> Dict[str, Any]:
    """One tick of the SQL-queued template requests (2026-10-13): make sure
    ``qs_feed_template_apply()`` exists, then apply the queued requests
    through the template routes.  Scheduler-lock holder only -- one applier."""
    from core.scheduler import _this_process_runs_apscheduler
    if not _this_process_runs_apscheduler():
        return _skipped("not the scheduler-lock holder")

    def _tick():
        from core.feed.template_requests import tick
        return tick(db_manager)

    return _safe_dict("feed template requests", _tick, count_key="detail")


#: seconds between template-request ticks (a queued request waits at most this)
FEED_TEMPLATE_REQUESTS_INTERVAL_SECONDS = 10


def run_report_requests(db_manager: Any) -> Dict[str, Any]:
    """One tick of the reports queued from SQL (2026-11-04): make sure ``qs_report_apply()``
    exists, then apply the queued requests.  Scheduler-lock holder only -- one applier."""
    from core.scheduler import _this_process_runs_apscheduler
    if not _this_process_runs_apscheduler():
        return _skipped("not the scheduler-lock holder")

    def _tick():
        from core.reports.from_sql import tick
        return tick(db_manager)

    return _safe_dict("report requests", _tick, count_key="detail")


#: seconds between ticks (a queued report waits at most this)
REPORT_REQUESTS_INTERVAL_SECONDS = 10


def run_published_api_rollup(db_manager: Any) -> Dict[str, Any]:
    """One pass of the published-API rollup (2026-10-17,
    core/published_api/rollup.py::roll): the raw call rows since the lag
    window folded into hourly and daily buckets, the watermark advanced,
    old buckets swept.  Scheduler-lock holder only -- one roller (a second
    would converge, but would also double the work)."""
    from core.scheduler import _this_process_runs_apscheduler
    if not _this_process_runs_apscheduler():
        return _skipped("not the scheduler-lock holder")

    def _tick():
        # the roll, then the alert pass (thresholds / dependency-broken /
        # sunsets) -- ONE tick definition shared with the job contract
        from core.published_api.rollup import tick
        return tick(db_manager)

    return _safe_dict("published-api rollup", _tick, count_key="rows")


def run_value_list_sync(db_manager: Any) -> Dict[str, Any]:
    """One pass of the value-list sync (2026-10-24, core/value_lists.py::tick):
    every DAILY list past its interval re-synced.  Scheduler-lock holder only."""
    from core.scheduler import _this_process_runs_apscheduler
    if not _this_process_runs_apscheduler():
        return _skipped("not the scheduler-lock holder")

    def _tick():
        from core.value_lists import tick
        return tick(db_manager)

    return _safe_dict("value-list sync", _tick, count_key="synced")


#: seconds between value-list sync ticks (a due list waits at most this)
VALUE_LIST_SYNC_INTERVAL_SECONDS = 300


def _scheduler_deadman_interval() -> int:
    from core.component_health.scheduler_deadman import INTERVAL_SECONDS
    return INTERVAL_SECONDS


def run_scheduler_deadman(db_manager: Any) -> Dict[str, Any]:
    """One look at the scheduler's lock (2026-11-02, core/component_health/
    scheduler_deadman.py).  The job-worker tier's lock holder only."""
    from core.scheduler import _this_process_runs_apscheduler
    if not _this_process_runs_apscheduler():
        return _skipped("not the lock holder")

    def _tick():
        from core.component_health.scheduler_deadman import tick
        return tick(db_manager)

    return _safe_dict("scheduler dead-man", _tick, count_key="cleared")


def run_query_pod_scaler(db_manager: Any) -> Dict[str, Any]:
    """One pass of the query-pod scaler (2026-10-29, core/query_pods/
    scaler.py::tick).  Scheduler-lock holder only: two scalers would fight."""
    from core.scheduler import _this_process_runs_apscheduler
    if not _this_process_runs_apscheduler():
        return _skipped("not the scheduler-lock holder")

    def _tick():
        from core.query_pods.scaler import tick
        return tick(db_manager)

    return _safe_dict("query-pod scaler", _tick, count_key="scaled")


def query_pod_scaler_interval_seconds() -> int:
    try:
        from core.query_pods.classes import load_settings
        return int(load_settings().tick_seconds)
    except Exception:
        return 60


def published_api_rollup_interval_seconds() -> int:
    try:
        from core.config import published_views as _pv
        return max(5, int(_pv.rollup_interval_seconds))
    except Exception:
        return 60


def dependency_oracle_table_watch_interval_seconds() -> int:
    from core.feed.oracle_table_source import load_config
    try:
        return int(load_config()["interval_seconds"])
    except Exception:
        return 15


# ── registration ───────────────────────────────────────────────────────────

def register_retention_daemons(scheduler: Any, db_manager: Any,
                               only: Optional[Iterable[str]] = None) -> int:
    """Register all four sweeps on ``scheduler``.  Returns the count added.

    Same signature as every other ``register_*_daemon`` so the scheduler
    worker's daemon table can carry it unchanged.  Individually guarded: a
    module that fails to import (e.g. feed_engine absent in a slim image)
    costs only its own sweep.

    ``only`` (2026-11-02, core/responsibilities.py): the job ids THIS process
    is the home of -- a scheduler pod registers the watching / sweeping ones,
    a job-worker pod the executing one (``value_list_sync`` reads source data),
    a standalone install all of them.  None = all (the pre-2026-11-02 call).
    """
    wanted = None if only is None else set(only)
    from core.config import data_quality as _dq_cfg
    from core.config import etl_pipelines as _etl_cfg
    from core.config import feed_generation as _fg_cfg
    from core.config import published_views as _pv_cfg

    specs = [
        ("etl_cleanup", run_etl_cleanup,
         _hours(_etl_cfg, "cleanup_interval_hours", 6)),
        ("feed_cleanup", run_feed_cleanup,
         _hours(_fg_cfg, "cleanup_interval_hours", 6)),
        ("dq_cleanup", run_dq_cleanup,
         _hours(_dq_cfg, "cleanup_interval_hours", 6)),
        # Daily, matching the inline loop's 86400s cadence.
        ("agent_log_cleanup", run_agent_log_cleanup, 86400),
        # 2026-08-20 — PV access-log/cache retention (Phase 75 inline loop).
        ("pv_cleanup", run_pv_cleanup,
         _hours(_pv_cfg, "cleanup_interval_hours", 24)),
        # 2026-09-15 — daily, like the agent log sweep.  Both are registered
        # UNCONDITIONALLY and no-op on a retention of 0, which keeps the
        # JOB_IDS count invariant the guard tests pin and matches how
        # pv_cleanup handles its own disabled case.
        ("rls_audit_cleanup", run_rls_audit_cleanup, 86400),
        ("delivery_history_cleanup", run_delivery_history_cleanup, 86400),
        ("query_log_cleanup", run_query_log_cleanup, 86400),
        # 2026-09-27 -- the close-out digest's due-check tick (default 300 s).
        ("feed_close_out_digest", run_feed_close_out_digest,
         close_out_digest_interval_seconds()),
        # 2026-09-28 -- the consumer late watcher's tick (default 300 s).
        ("feed_consumer_late_watch", run_feed_consumer_late_watch,
         consumer_late_watch_interval_seconds()),
        # 2026-10-03 -- hourly: windows are a minute long, so an hour's
        # sweep keeps the table at about two hours of rows.
        ("rate_limit_window_cleanup", run_rate_limit_window_cleanup, 3600),
        # 2026-10-07 -- the file arrival watcher's tick (default 60 s).
        ("feed_dependency_file_watch", run_feed_dependency_file_watch,
         dependency_file_watch_interval_seconds()),
        # 2026-10-11 -- the Oracle-table arrival watcher's tick (default 15 s).
        ("feed_dependency_oracle_table_watch", run_feed_dependency_oracle_table_watch,
         dependency_oracle_table_watch_interval_seconds()),
        # 2026-10-13 -- template requests queued from SQL.
        ("feed_template_requests", run_feed_template_requests,
         FEED_TEMPLATE_REQUESTS_INTERVAL_SECONDS),
        # 2026-11-04 -- reports queued from SQL.
        ("report_requests", run_report_requests, REPORT_REQUESTS_INTERVAL_SECONDS),
        # 2026-10-17 -- the published-API rollup's tick (default 60 s).
        ("published_api_rollup", run_published_api_rollup,
         published_api_rollup_interval_seconds()),
        # 2026-10-24 -- the daily value-list sync's tick (300 s).
        ("value_list_sync", run_value_list_sync, VALUE_LIST_SYNC_INTERVAL_SECONDS),
        # 2026-10-29 -- the query-pod scaler's tick (query_pods.tick_seconds, 60).
        ("query_pod_scaler", run_query_pod_scaler, query_pod_scaler_interval_seconds()),
        # 2026-11-02 -- the scheduler dead-man (30 s; two DOWN ticks raise).
        ("scheduler_deadman", run_scheduler_deadman, _scheduler_deadman_interval()),
    ]

    added = 0
    for job_id, fn, seconds in specs:
        if wanted is not None and job_id not in wanted:
            continue
        try:
            scheduler.add_job(
                fn, "interval", seconds=seconds, args=[db_manager],
                id=job_id, replace_existing=True,
                # Long sweeps must not stack up behind a slow database.
                max_instances=1, coalesce=True,
            )
            added += 1
            logger.info("[retention] registered %s (every %ds)",
                        job_id, seconds)
        except Exception as exc:
            logger.warning("[retention] %s registration failed "
                           "(non-fatal): %s", job_id, exc)
    return added


def register_daemon(scheduler: Any, db_manager: Any) -> Optional[int]:
    """Alias matching the worker's ``register_*`` convention."""
    return register_retention_daemons(scheduler, db_manager)
