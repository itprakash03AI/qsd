"""Phase 87 — Unified Credential Manager.

Resolves credentials for S3 and Snowflake connections using:
  1. System accounts (DB-backed, encrypted, admin-managed)
  2. Personal/per-user portal SSO (user's own AD identity)
  3. The default (global) login: the System Account chosen on Admin -> AWS
     Portal (aws_portal.service_system_account_id).  The typed
     aws_portal.service_username/password is no longer used (2026-10-30).

Handles auto-retry on token expiry: clear cache → re-fetch → return fresh config.
"""
from __future__ import annotations

import logging
import time
import threading
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

# ── Module singleton ────────────────────────────────────────────────────────

_credential_manager: Optional["CredentialManager"] = None


def set_credential_manager(cm: "CredentialManager") -> None:
    global _credential_manager
    _credential_manager = cm


def get_credential_manager() -> Optional["CredentialManager"]:
    return _credential_manager


class CredentialResolutionError(Exception):
    """Raised when no credential source can provide valid credentials."""
    pass


class PersonalPasswordRequired(CredentialResolutionError):
    """BF-286: raised when a PRIVATE connection needs the logged-in user's
    AWS portal password but the vault is empty (or stale).  API layer
    catches this and returns 401 with ``type: "portal_password_required"``
    so the frontend pops the password prompt modal (BF-285)."""
    pass


class PortalLoginMustBeSystemAccount(CredentialResolutionError):
    """2026-10-30: nothing else gave credentials, the Admin -> AWS Portal page
    still has the old typed service username/password saved and NO System
    Account is chosen.  The pair is never used; the message is
    ``aws_portal_auth.TYPED_PAIR_NOT_USED``.  Raised (never swallowed) so the
    connection fails saying what to do instead of a generic auth error."""
    pass


class CredentialManager:
    """Resolves and refreshes credentials for portal-mode connections."""

    def __init__(self, db_manager):
        self._db = db_manager
        self._lock = threading.Lock()

    # ── S3 credential resolution ────────────────────────────────────────────

    def resolve_s3_credentials(self, conn_config: dict, username: str = "",
                                force_refresh: bool = False,
                                min_lifetime_seconds: float = 0) -> dict:
        """Inject AWS credentials into conn_config for auth_mode='portal'.

        BF-286 — connection ownership drives the credential source:
          - **Shared connection** (``is_shared=True`` on the Connection row):
            uses the configured ``system_account_id`` to fetch AWS
            credentials.  The system account holds an admin-supplied
            AD service account whose password is encrypted at rest.
            All users sharing the connection benefit — no per-user
            prompts.
          - **Private connection** (``is_shared=False``): uses the
            logged-in user's own AD credentials.  Per BF-285 the
            password is held in the in-memory vault for the session;
            if the vault is empty we raise PersonalPasswordRequired
            so the API layer can return 401 and the frontend modal
            prompts the user.

        ``credential_source`` (legacy) overrides:
          - "system_account" forces system-account path (must set
            ``system_account_id``)
          - "personal" forces per-user vault path
          - "auto" (default) defers to ``is_shared`` from the connection
            row when present, otherwise tries personal → system → config

        Returns conn_config copy with AWS keys injected + auth_mode="keys".
        Raises ``PersonalPasswordRequired`` when private mode hits an
        empty vault — caller (api/execute_api) surfaces 401 with
        ``type: "portal_password_required"`` to trigger the frontend modal.
        """
        from core import config as _cfg

        auth_mode = (conn_config.get("auth_mode") or "").lower()
        if auth_mode != "portal":
            return conn_config  # not a portal connection — pass through

        # BF-286: derive credential_source from is_shared when the admin
        # didn't pin it explicitly.  is_shared is the user-visible knob;
        # credential_source is the legacy back-channel.
        source = (conn_config.get("credential_source") or "").lower()
        if not source or source == "auto":
            is_shared = bool(conn_config.get("is_shared"))
            if is_shared:
                source = "system_account"
            elif username:
                source = "personal"
            else:
                source = "auto"  # fall back to legacy resolution chain
        sys_acct_id = conn_config.get("system_account_id")
        # BF-PORTAL-CONN-OVERRIDES — single source of truth for the
        # override kwargs.  Same helper used by inject_portal_creds,
        # auth_api._refresh_aws_creds_for_user, and admin_api modal flow
        # so a connection's JWT/STS call shape is identical regardless
        # of which entry point fired it.
        from core.aws_portal_auth import build_portal_kwargs_for_connection
        portal_kwargs = build_portal_kwargs_for_connection(conn_config)

        creds = None

        if source == "system_account" and sys_acct_id:
            creds = self._fetch_system_account_creds(
                int(sys_acct_id), force_refresh=force_refresh,
                min_lifetime_seconds=min_lifetime_seconds, **portal_kwargs,
            )
            # BF-286: shared connection MUST resolve via system account.
            # If the admin pinned a missing/inactive system account, fail
            # explicitly — don't silently fall back to personal mode (would
            # confuse users sharing the connection with unexpected prompts).
            if not creds:
                raise CredentialResolutionError(
                    f"Shared connection requires system account "
                    f"id={sys_acct_id} but credential fetch failed. "
                    "Check the System Accounts admin page — the account may be "
                    "missing, inactive, or its AD password may have rotated."
                )
        elif source == "personal":
            creds = self._fetch_personal_creds(
                username, force_refresh=force_refresh,
                min_lifetime_seconds=min_lifetime_seconds, **portal_kwargs,
            )
            # BF-286: private connection requires the logged-in user's
            # password.  If we got nothing back (vault empty / stale)
            # raise the typed error so api/execute_api can return 401
            # ``portal_password_required`` and the frontend modal pops.
            if not creds:
                raise PersonalPasswordRequired(
                    "Private connection requires your AWS portal password. "
                    "Please enter it when prompted."
                )
        elif source == "hybrid":
            # BF-415 — Hybrid mode.  Try personal vault → system account in
            # order; if BOTH fail and a user is present, prompt them for
            # their portal password (modal pops).  Designed for connections
            # that should work BOTH interactively AND under a scheduled
            # job / published API consumer using the linked system account.
            if username:
                creds = self._fetch_personal_creds(
                    username, force_refresh=force_refresh,
                    min_lifetime_seconds=min_lifetime_seconds, **portal_kwargs,
                )
            if not creds and sys_acct_id:
                creds = self._fetch_system_account_creds(
                    int(sys_acct_id), force_refresh=force_refresh,
                    min_lifetime_seconds=min_lifetime_seconds, **portal_kwargs,
                )
            if not creds:
                # Interactive user → prompt.  Non-interactive (batch / published
                # API) → hard error so the caller can return a structured 401.
                if username:
                    raise PersonalPasswordRequired(
                        "Hybrid connection: tried personal creds and system "
                        "account; both failed.  Please enter your AWS portal "
                        "password when prompted."
                    )
                raise CredentialResolutionError(
                    f"Hybrid connection (no interactive user) requires a "
                    f"working system account.  system_account_id={sys_acct_id} "
                    "either missing, inactive, or its AD password has rotated."
                )
        else:  # "auto"
            # Try personal first
            if username:
                creds = self._fetch_personal_creds(
                    username, force_refresh=force_refresh,
                    min_lifetime_seconds=min_lifetime_seconds, **portal_kwargs,
                )
            # Fall back to system account from config
            if not creds and sys_acct_id:
                creds = self._fetch_system_account_creds(
                    int(sys_acct_id), force_refresh=force_refresh,
                    min_lifetime_seconds=min_lifetime_seconds, **portal_kwargs,
                )
            # Fall back to the DEFAULT (global) login on Admin -> AWS Portal:
            # ONLY a chosen System Account (2026-10-30; the typed pair is no
            # longer read) -- ...only while that page is Enabled.
            _admin_on = bool(_cfg.aws_portal.enabled)
            if not creds and _admin_on and _cfg.aws_portal.service_system_account_id:
                creds = self._fetch_system_account_creds(
                    _cfg.aws_portal.service_system_account_id,
                    force_refresh=force_refresh,
                    min_lifetime_seconds=min_lifetime_seconds, **portal_kwargs,
                )
            if not creds:
                # a caller that would have used the old typed pair: fail
                # with the one sentence, never use the pair (this branch is
                # reached only with no interactive user -- see `source`)
                from core.aws_portal_auth import global_service_problem
                _problem = global_service_problem()
                if _problem:
                    raise PortalLoginMustBeSystemAccount(_problem)

        if not creds:
            # BF-415 — when the request comes from an interactive user, pop
            # the password modal instead of failing silently with a generic
            # error.  Background / published-API contexts (username="") still
            # get the hard error since there's no UI to prompt.
            if username:
                raise PersonalPasswordRequired(
                    "Could not resolve AWS credentials automatically. "
                    "Please enter your AWS portal password when prompted."
                )
            raise CredentialResolutionError(
                "Could not resolve AWS credentials. "
                "Ensure a system account is configured or log in to the AWS portal."
            )

        # Inject into a copy of the config
        injected = dict(conn_config)
        injected["aws_access_key_id"] = creds["aws_access_key_id"]
        injected["aws_secret_access_key"] = creds["aws_secret_access_key"]
        injected["aws_session_token"] = creds.get("aws_session_token", "")
        injected["auth_mode"] = "keys"  # force keys mode for boto3
        return injected

    # ── Snowflake credential resolution ─────────────────────────────────────

    def resolve_snowflake_credentials(self, conn_config: dict, username: str = "",
                                       force_refresh: bool = False) -> dict:
        """Inject Snowflake credentials for auth_type='sso_portal'.

        Resolution order (2026-11-04, the rule of qs_credentials/login.py):
          1. DB system account (system_account_id), when one is chosen
          2. Per-connection sso_username / sso_password fields
        """
        auth_type = (conn_config.get("auth_type") or "").lower()
        if auth_type != "sso_portal":
            return conn_config

        injected = dict(conn_config)

        # Simple mode: credentials stored directly on the connection
        sso_user = conn_config.get("sso_username", "").strip()
        sso_pass = conn_config.get("sso_password", "").strip()
        if sso_user and sso_pass and not conn_config.get("system_account_id"):
            injected["user"] = sso_user
            injected["password"] = sso_pass
            injected["auth_type"] = "password"
            return injected

        # Legacy mode: DB system account
        sys_acct_id = conn_config.get("system_account_id")
        if not sys_acct_id:
            raise CredentialResolutionError(
                "Snowflake SSO portal connections require either sso_username/sso_password "
                "or a system account ID."
            )

        # BF-407 — catch the typed DB error so the operator sees a
        # specific message instead of the generic "not found or inactive".
        try:
            acct = self._db.get_system_account_raw(int(sys_acct_id))
        except Exception as exc:
            from core.database import SystemAccountLookupError as _SALE
            if isinstance(exc, _SALE):
                raise CredentialResolutionError(
                    f"System account {sys_acct_id} lookup failed at the DB "
                    f"layer: {exc}.  This is NOT a 'wrong credentials' error — "
                    "the DB read itself failed.  Common causes on OpenShift: "
                    "(a) `system_accounts` table not migrated (check the "
                    "[STARTUP] banner — was 'system_accounts' in tables?); "
                    "(b) PVC mount missing or read-only; "
                    "(c) SQLite locked by another writer (look for "
                    "[slow-query] log lines with 'database is locked')."
                ) from exc
            raise   # any other exception bubbles up unchanged
        if not acct or not acct.get("is_active", True):
            raise CredentialResolutionError(
                f"System account {sys_acct_id} not found or inactive."
            )

        self._db.update_system_account_status(int(sys_acct_id), "success")
        # Phase 156 (2026-06-25) deep-dive -- route through the Phase 154
        # qs_credentials chokepoint so use_vault=True system accounts
        # actually fetch from vault.  Pre-fix this read ``acct["password"]``
        # directly which is BLANK by design for vault-backed accounts
        # -> Snowflake driver received empty password -> auth failed with
        # a confusing "incorrect username or password" error.
        _sf_username = acct.get("username") or ""
        _sf_password = acct.get("password") or ""
        _resolved: dict = {}
        try:
            from core.qs_credentials import resolve_system_account
            _resolved = resolve_system_account(
                int(sys_acct_id), db_manager=self._db,
            )
            if _resolved.get("username"):
                _sf_username = _resolved["username"]
            if _resolved.get("password"):
                _sf_password = _resolved["password"]
        except Exception as _sr_exc:
            # Resolver failure for a vault-backed account: refuse to
            # propagate blank creds -- raise a clear error so the
            # operator sees the misconfig.
            if bool(acct.get("use_vault", False)):
                raise CredentialResolutionError(
                    f"Snowflake system_account id={sys_acct_id} has "
                    f"use_vault=True but vault resolution failed: "
                    f"{_sr_exc}.  Refusing to hand a blank password "
                    f"to the Snowflake driver."
                ) from _sr_exc
            # use_vault=False -- column is authoritative; pass through.
        injected["user"] = _sf_username
        # 2026-11-04: an entry holding a key has no password to give.  Left unset, the auth type
        # is decided from the account's entry when the connector is built, as on every other road.
        from core.connectors import _SF_KV_KEY_FIELDS, _first_kv
        if not _sf_password and _first_kv(_resolved, _SF_KV_KEY_FIELDS) is not None:
            injected.pop("password", None)
            injected["auth_type"] = ""
            return injected
        injected["password"] = _sf_password
        injected["auth_type"] = "password"
        return injected

    # ── Refresh + retry ─────────────────────────────────────────────────────

    def refresh_and_retry(self, conn_config: dict, username: str = "") -> Optional[dict]:
        """Clear credential cache and re-fetch for portal connections.

        Returns fresh conn_config with new credentials, or None if not a portal connection.
        """
        auth_mode = (conn_config.get("auth_mode") or "").lower()
        auth_type = (conn_config.get("auth_type") or "").lower()

        if auth_mode == "portal":
            # Clear portal credential cache for relevant user/account
            from core.aws_portal_auth import clear_cache
            source = (conn_config.get("credential_source") or "auto").lower()
            if source == "personal" and username:
                clear_cache(username)
            else:
                clear_cache()  # clear all — simpler for retry
            try:
                return self.resolve_s3_credentials(conn_config, username, force_refresh=True)
            except CredentialResolutionError:
                return None

        if auth_type == "sso_portal":
            try:
                return self.resolve_snowflake_credentials(conn_config, username, force_refresh=True)
            except CredentialResolutionError:
                return None

        return None  # not a portal connection

    # ── Internal helpers ────────────────────────────────────────────────────

    def _fetch_system_account_creds(self, system_account_id: int,
                                     force_refresh: bool = False,
                                     jwt_url: Optional[str] = None,
                                     credential_url: Optional[str] = None,
                                     portal_base_url: Optional[str] = None,
                                     role_name: Optional[str] = None,
                                     account_id: Optional[str] = None,
                                     sf_ref_no: Optional[str] = None,
                                     proxy_url: Optional[str] = None,
                                     min_lifetime_seconds: float = 0) -> Optional[dict]:
        """Fetch AWS creds using a DB-stored system account.

        ``min_lifetime_seconds`` (BF-461) — when > 0, the cached creds
        must have at least this many seconds remaining; otherwise we
        refetch.  Used by long-running operations to avoid mid-flight
        ExpiredToken.

        Per-connection portal overrides are forwarded to fetch_credentials().
        """
        from core.aws_portal_auth import creds_cache_key, get_cached_credentials, fetch_credentials

        acct = self._db.get_system_account_raw(system_account_id)
        if not acct or not acct.get("is_active", True):
            logger.warning("System account %d not found or inactive", system_account_id)
            return None

        cache_key = creds_cache_key(f"sys:{system_account_id}", role_name=role_name, account_id=account_id,
                                    portal_base_url=portal_base_url, jwt_url=jwt_url,
                                    credential_url=credential_url)

        # BF-477 — track strict + any cached so refetch failure can
        # fall back to near-expiry cached.  Same regression class as
        # _fetch_personal_creds.
        any_cached = None
        if not force_refresh:
            any_cached = get_cached_credentials(cache_key, min_lifetime_seconds=0)
            cached = get_cached_credentials(cache_key, min_lifetime_seconds=min_lifetime_seconds)
            if cached:
                return cached
            if min_lifetime_seconds > 0 and any_cached:
                logger.info(
                    "[cred-mgr] preflight refresh: system_account=%d cached creds "
                    "had less than %.0fs remaining — refetching (will fall back "
                    "to cached on refetch failure)",
                    system_account_id, min_lifetime_seconds,
                )

        _login = system_account_login(self._db, system_account_id, acct)
        if _login is None:
            return None
        _sa_username, _sa_password = _login
        try:
            creds = fetch_credentials(
                _sa_username, _sa_password,
                jwt_url=jwt_url, credential_url=credential_url,
                portal_base_url=portal_base_url, role_name=role_name,
                account_id=account_id, sf_ref_no=sf_ref_no,
                proxy_url=proxy_url,
            )
            # Re-cache under system account key
            from core.aws_portal_auth import _cache_lock, _cred_cache
            with _cache_lock:
                _cred_cache[cache_key] = (creds, creds.get("expires_at", time.time() + 3300))

            self._db.update_system_account_status(system_account_id, "success")
            return creds
        except Exception as exc:
            logger.warning("System account %d portal auth failed: %s", system_account_id, exc)
            self._db.update_system_account_status(
                system_account_id, "failed", str(exc)
            )
            # BF-477 — refetch failed; return near-expiry cached if we have
            # one.  This restores the pre-BF-461 "use cached until actual
            # expiry" semantics that the user reported was working.
            if any_cached:
                logger.warning(
                    "[cred-mgr] refetch failed for system_account=%d — "
                    "falling back to near-expiry cached creds (legacy behaviour)",
                    system_account_id,
                )
                return any_cached
            return None

    def _fetch_personal_creds(self, username: str,
                               force_refresh: bool = False,
                               jwt_url: Optional[str] = None,
                               credential_url: Optional[str] = None,
                               portal_base_url: Optional[str] = None,
                               role_name: Optional[str] = None,
                               account_id: Optional[str] = None,
                               sf_ref_no: Optional[str] = None,
                               proxy_url: Optional[str] = None,
                               min_lifetime_seconds: float = 0) -> Optional[dict]:
        """Fetch AWS creds for a specific user via portal SSO.

        Resolution order:
          1. If cached AWS creds exist (and not force_refresh), use them.
          2. BF-286: if the user has a vaulted portal password (BF-285 —
             entered once per session via the PortalPasswordModal), fetch
             fresh creds using it.  This makes long-running queries
             survive STS expiry without re-prompting.
          3. Return None — caller surfaces 401 portal_password_required
             so the frontend pops the password modal.
        """
        if not username:
            return None

        from core.aws_portal_auth import (creds_cache_key, get_cached_credentials, fetch_credentials,
                                          PortalAuthError)
        _user_key = creds_cache_key(username, role_name=role_name, account_id=account_id,
                                    portal_base_url=portal_base_url, jwt_url=jwt_url,
                                    credential_url=credential_url)

        # BF-477 (2026-05-19) — track BOTH the strict (TTL-respecting) and
        # near-expiry cached creds.  When min_lifetime_seconds is set
        # (preflight refresh, BF-461), strict_cached is None if the
        # cached entry has less remaining than the threshold — and we
        # try to refetch.  But if the refetch FAILS (portal hiccup,
        # vault password rotated, proxy error), we must NOT return
        # None — that's the regression the user reported:
        # "it was getting resolved automatically before".  Fall back
        # to the about-to-expire cached entry as a last resort; it's
        # still better than no creds (the feed may finish before the
        # actual expiry).  Pre-BF-461 behaviour: cached entry returned
        # regardless of remaining TTL.  Post-BF-477 behaviour: try
        # refetch, fall back to cached on refetch failure.
        strict_cached = None
        any_cached = None
        if not force_refresh:
            any_cached = get_cached_credentials(_user_key, min_lifetime_seconds=0)
            strict_cached = get_cached_credentials(
                _user_key, min_lifetime_seconds=min_lifetime_seconds,
            )
            if strict_cached:
                return strict_cached
            if min_lifetime_seconds > 0 and any_cached:
                logger.info(
                    "[cred-mgr] preflight refresh: user='%s' cached creds had less "
                    "than %.0fs remaining — refetching (will fall back to cached "
                    "on refetch failure)", username, min_lifetime_seconds,
                )

        # BF-286: attempt vault-driven fetch.  The user entered their
        # password once at login; we re-use it (decrypted from the
        # in-memory vault) to mint fresh STS creds without prompting.
        try:
            from core.portal_password_vault import get_password as _vault_get
            vaulted_pw = _vault_get(username)
        except Exception as exc:
            logger.debug("[cred-mgr] vault read failed for '%s': %s", username, exc)
            vaulted_pw = None

        if vaulted_pw:
            try:
                creds = fetch_credentials(
                    username, vaulted_pw,
                    jwt_url=jwt_url, credential_url=credential_url,
                    portal_base_url=portal_base_url, role_name=role_name,
                    account_id=account_id, sf_ref_no=sf_ref_no,
                    proxy_url=proxy_url,
                )
                logger.info("[cred-mgr] personal creds fetched via vault for '%s'",
                             username)
                return creds
            except PortalAuthError as exc:
                logger.warning("[cred-mgr] vault-driven personal fetch failed for "
                                "'%s': %s — clearing vault and falling through",
                                username, exc)
                # Stale password (user changed AD password mid-session) —
                # drop the vault entry so the frontend re-prompts.
                try:
                    from core.portal_password_vault import clear_password
                    clear_password(username)
                except Exception:
                    pass

        # BF-477 — refetch path exhausted.  If we have a near-expiry
        # cached entry, return it (better than None for short ops).
        # This preserves the pre-BF-461 behaviour where cached creds
        # were used until actual expiry.
        if any_cached:
            logger.warning(
                "[cred-mgr] refetch failed for '%s' — falling back to "
                "near-expiry cached creds (legacy behaviour)", username,
            )
            return any_cached

        # No cached creds + no working vault password → frontend must prompt.
        return None


def system_account_login(db, system_account_id: int,
                         acct: Optional[dict] = None) -> Optional[Tuple[str, str]]:
    """The (username, password) a System Account logs in to the AWS portal
    with, or None when it cannot give one (the reason is logged and stored on
    the account's status).

    ONE rule for every caller (2026-10-28: a connection's system account AND
    the Admin page's global fallback account): the password comes from Vault
    when the account says ``use_vault``, else from the account itself.
    Phase 156 (2026-06-25): routed through the Phase 154 qs_credentials
    chokepoint -- the column password is BLANK by design on a vault-backed
    account, and calling the portal with it failed as "invalid credentials".
    """
    if acct is None:
        acct = db.get_system_account_raw(system_account_id)
    if not acct or not acct.get("is_active", True):
        logger.warning("System account %d not found or inactive", system_account_id)
        return None
    username = acct.get("username") or ""
    password = acct.get("password") or ""
    try:
        from core.qs_credentials import resolve_system_account
        resolved = resolve_system_account(system_account_id, db_manager=db)
        if resolved.get("username"):
            username = resolved["username"]
        if resolved.get("password"):
            password = resolved["password"]
    except Exception as exc:
        # Fall back to the column ONLY when use_vault=False -- otherwise stop
        # with a clear reason instead of a portal failure on a blank password.
        if bool(acct.get("use_vault", False)):
            logger.error(
                "[cred-mgr] system_account=%d use_vault=True but "
                "qs_credentials failed (%s) -- aborting rather than calling "
                "the portal with the BLANK column password.",
                system_account_id, exc,
            )
            db.update_system_account_status(
                system_account_id, "failed", f"vault resolution failed: {exc}",
            )
            return None
        logger.debug(
            "[cred-mgr] qs_credentials fallback for system_account=%d "
            "use_vault=False (%s) -- using column creds as-is",
            system_account_id, exc,
        )
    else:
        # A Vault account whose answer has no username or no password: the
        # values above are the account's own -- placeholders on a Vault
        # account -- and the portal would be sent them as a real login.
        if bool(acct.get("use_vault", False)) and not (
                resolved.get("username") and resolved.get("password")):
            reason = ("Vault answered without a username and password -- check "
                      "the account's Secret Type (AD_accounts reads data.username "
                      "and data.password) and its Secret URL")
            logger.error("[cred-mgr] system_account=%d: %s", system_account_id, reason)
            db.update_system_account_status(system_account_id, "failed", reason)
            return None
    return username, password
