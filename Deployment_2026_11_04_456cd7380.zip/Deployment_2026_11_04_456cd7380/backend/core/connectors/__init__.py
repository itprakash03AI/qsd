"""
SQL Connector factory.

Usage:
    from backend.core.connectors import get_connector

    connector = get_connector(connection_type, config)
    result = connector.execute_query("SELECT 1")
    connector.close()

Supported types:
    "trino"      / "starburst"  – Trino / Starburst on-prem or Galaxy
    "snowflake"                  – Snowflake cloud
    "databricks"                 – Databricks SQL Warehouse
    "oracle"                     – Oracle Database (python-oracledb, thin mode)
    "athena"                     – AWS Athena (serverless, pay-per-TB-scanned)
"""

from typing import Any, Dict

from .base import SqlConnector, DriverNotInstalled

_REGISTRY: Dict[str, str] = {
    "trino":      "trino_connector.TrinoConnector",
    "starburst":  "trino_connector.TrinoConnector",
    "snowflake":  "snowflake_connector.SnowflakeConnector",
    "databricks": "databricks_connector.DatabricksConnector",
    "oracle":     "oracle_connector.OracleConnector",
    "athena":     "athena_connector.AthenaConnector",
    "rest_api":   "rest_api_connector.RestApiConnector",
}

# Display-friendly names for the UI
CONNECTOR_DISPLAY_NAMES = {
    "trino":      "Trino",
    "starburst":  "Starburst",
    "snowflake":  "Snowflake",
    "databricks": "Databricks SQL",
    "oracle":     "Oracle Database",
    "athena":     "AWS Athena",
    "rest_api":   "REST API",
}

# Config field definitions for each connector type (used by the frontend form)
CONNECTOR_FIELDS: Dict[str, list] = {
    "trino": [
        {"key": "host",        "label": "Host",          "type": "text",     "required": True},
        {"key": "port",        "label": "Port",          "type": "number",   "required": True, "default": 443},
        {"key": "user",        "label": "User",          "type": "text",     "required": True},
        {"key": "auth_type",   "label": "Auth Type",     "type": "select",   "required": True,
         "options": ["none", "basic", "jwt", "kerberos", "oauth2"], "default": "basic"},
        {"key": "password",    "label": "Password",      "type": "password", "required": False, "showIf": {"auth_type": "basic"}},
        {"key": "token",       "label": "JWT Token",     "type": "password", "required": False, "showIf": {"auth_type": "jwt"}},
        {"key": "catalog",     "label": "Default Catalog", "type": "text",   "required": False},
        {"key": "schema",      "label": "Default Schema",  "type": "text",   "required": False},
        {"key": "http_scheme", "label": "HTTP Scheme",   "type": "select",   "required": False,
         "options": ["https", "http"], "default": "https"},
        {"key": "verify_ssl",  "label": "Verify SSL",    "type": "boolean",  "required": False, "default": True},
        # ── Write ladder rung 1 (2026-08-22): engine-side unload declaration.
        # ALL THREE must be set for the connection to declare the
        # engine_write capability (the per-connection declaration IS the
        # opt-in — half-configured means NOT declared, never "probably").
        {"key": "unload_scratch_catalog", "label": "Unload Scratch Catalog (rung 1)", "type": "text", "required": False,
         "placeholder": "hive"},
        {"key": "unload_scratch_schema",  "label": "Unload Scratch Schema (rung 1)",  "type": "text", "required": False,
         "placeholder": "qs_scratch"},
        {"key": "unload_s3_location",     "label": "Unload S3 Location (rung 1)",     "type": "text", "required": False,
         "placeholder": "s3a://bucket/qs-unload"},
    ],
    "starburst": [
        {"key": "host",        "label": "Host",          "type": "text",     "required": True},
        {"key": "port",        "label": "Port",          "type": "number",   "required": True, "default": 443},
        {"key": "user",        "label": "User",          "type": "text",     "required": True},
        {"key": "auth_type",   "label": "Auth Type",     "type": "select",   "required": True,
         "options": ["none", "basic", "jwt", "kerberos", "oauth2"], "default": "basic"},
        {"key": "password",    "label": "Password",      "type": "password", "required": False, "showIf": {"auth_type": "basic"}},
        {"key": "token",       "label": "JWT Token",     "type": "password", "required": False, "showIf": {"auth_type": "jwt"}},
        {"key": "catalog",     "label": "Default Catalog", "type": "text",   "required": False},
        {"key": "schema",      "label": "Default Schema",  "type": "text",   "required": False},
        {"key": "http_scheme", "label": "HTTP Scheme",   "type": "select",   "required": False,
         "options": ["https", "http"], "default": "https"},
        {"key": "verify_ssl",  "label": "Verify SSL",    "type": "boolean",  "required": False, "default": True},
        # ── Write ladder rung 1 (2026-08-22): engine-side unload declaration.
        # ALL THREE must be set for the connection to declare the
        # engine_write capability (the per-connection declaration IS the
        # opt-in — half-configured means NOT declared, never "probably").
        {"key": "unload_scratch_catalog", "label": "Unload Scratch Catalog (rung 1)", "type": "text", "required": False,
         "placeholder": "hive"},
        {"key": "unload_scratch_schema",  "label": "Unload Scratch Schema (rung 1)",  "type": "text", "required": False,
         "placeholder": "qs_scratch"},
        {"key": "unload_s3_location",     "label": "Unload S3 Location (rung 1)",     "type": "text", "required": False,
         "placeholder": "s3a://bucket/qs-unload"},
    ],
    "snowflake": [
        {"key": "account",     "label": "Account",       "type": "text",     "required": True,
         "placeholder": "xy12345.us-east-1"},
        {"key": "user",        "label": "User",          "type": "text",     "required": True},
        {"key": "auth_type",   "label": "Auth Type",     "type": "select",   "required": True,
         "options": ["password", "key_pair", "oauth"], "default": "password"},
        {"key": "password",    "label": "Password",      "type": "password", "required": False, "showIf": {"auth_type": "password"}},
        {"key": "private_key", "label": "Private Key (PEM)", "type": "textarea", "required": False, "showIf": {"auth_type": "key_pair"}},
        {"key": "private_key_passphrase", "label": "Key Passphrase", "type": "password", "required": False, "showIf": {"auth_type": "key_pair"}},
        {"key": "token",       "label": "OAuth Token",   "type": "password", "required": False, "showIf": {"auth_type": "oauth"}},
        {"key": "warehouse",   "label": "Warehouse",     "type": "text",     "required": False},
        {"key": "database",    "label": "Database",      "type": "text",     "required": False},
        {"key": "schema",      "label": "Default Schema", "type": "text",    "required": False},
        {"key": "role",        "label": "Role",          "type": "text",     "required": False},
    ],
    "databricks": [
        {"key": "server_hostname", "label": "Server Hostname", "type": "text",     "required": True,
         "placeholder": "adb-1234567890.12.azuredatabricks.net"},
        {"key": "http_path",       "label": "HTTP Path",       "type": "text",     "required": True,
         "placeholder": "/sql/1.0/warehouses/abc123def456"},
        {"key": "access_token",    "label": "Access Token",    "type": "password", "required": True},
        {"key": "catalog",         "label": "Default Catalog", "type": "text",     "required": False},
        {"key": "schema",          "label": "Default Schema",  "type": "text",     "required": False},
    ],
    "oracle": [
        {"key": "host",            "label": "Host",            "type": "text",     "required": False,
         "placeholder": "oracle.example.com"},
        {"key": "port",            "label": "Port",            "type": "number",   "required": False, "default": 1521},
        {"key": "service_name",    "label": "Service Name",    "type": "text",     "required": False,
         "placeholder": "ORCL or pdb1.example.com"},
        {"key": "sid",             "label": "SID (legacy)",    "type": "text",     "required": False},
        {"key": "dsn",             "label": "DSN (override)",  "type": "text",     "required": False,
         "placeholder": "Leave blank to build from host/port/service"},
        {"key": "user",            "label": "Username",        "type": "text",     "required": True},
        {"key": "password",        "label": "Password",        "type": "password", "required": True},
        {"key": "wallet_location", "label": "Wallet Path",     "type": "text",     "required": False,
         "placeholder": "/path/to/wallet (Autonomous DB / mTLS)"},
        {"key": "wallet_password", "label": "Wallet Password", "type": "password", "required": False},
    ],
    "athena": [
        {"key": "region",                 "label": "AWS Region",                "type": "text",     "required": True,
         "placeholder": "us-east-1", "default": "us-east-1"},
        {"key": "s3_staging_dir",         "label": "S3 Staging Dir",            "type": "text",     "required": True,
         "placeholder": "s3://my-bucket/athena-results/"},
        {"key": "workgroup",              "label": "Workgroup",                 "type": "text",     "required": True,
         "placeholder": "primary",
         "helperText": "Athena enforces per-query bytes-scanned + cost caps at the workgroup level. Use a named workgroup with limits set."},
        {"key": "catalog",                "label": "Data Catalog",              "type": "text",     "required": False,
         "default": "AwsDataCatalog",
         "placeholder": "AwsDataCatalog or Lake Formation catalog name"},
        {"key": "schema",                 "label": "Default Database",          "type": "text",     "required": False,
         "placeholder": "default"},
        {"key": "auth_type",              "label": "Auth Mode",                 "type": "select",   "required": True,
         "options": ["iam_role", "access_key", "profile", "instance"], "default": "iam_role",
         "helperText": "iam_role/instance: pod IAM role (recommended). access_key: explicit AWS keys. profile: ~/.aws/credentials profile."},
        {"key": "aws_access_key_id",      "label": "AWS Access Key ID",         "type": "text",     "required": False,
         "showIf": {"auth_type": "access_key"}},
        {"key": "aws_secret_access_key",  "label": "AWS Secret Access Key",     "type": "password", "required": False,
         "showIf": {"auth_type": "access_key"}},
        {"key": "aws_session_token",      "label": "AWS Session Token (STS)",   "type": "password", "required": False,
         "showIf": {"auth_type": "access_key"}},
        {"key": "aws_profile",            "label": "AWS Profile Name",          "type": "text",     "required": False,
         "showIf": {"auth_type": "profile"}, "placeholder": "default"},
        {"key": "bytes_scanned_cutoff_mb","label": "Per-Query Cost Cap (MB)",   "type": "number",   "required": False,
         "placeholder": "e.g. 10240 = 10 GB",
         "helperText": "Advisory cost guard. Athena enforces a scan cap only as a WORKGROUP setting (BytesScannedCutoffPerQuery) — set it there to actually reject queries. Here it logs a warning when a query exceeds it. At ~$5/TB, 10 GB ≈ $0.05/query."},
    ],
    "rest_api": [
        {"key": "base_url",        "label": "Base URL",        "type": "text",     "required": True,
         "placeholder": "https://api.example.com/v2"},
        {"key": "auth_type",       "label": "Auth Type",       "type": "select",   "required": True,
         "options": ["none", "basic", "bearer", "api_key", "oauth2_client_credentials"], "default": "bearer"},
        {"key": "token",           "label": "Bearer Token",    "type": "password", "required": False,
         "showIf": {"auth_type": "bearer"}},
        {"key": "username",        "label": "Username",        "type": "text",     "required": False,
         "showIf": {"auth_type": "basic"}},
        {"key": "password",        "label": "Password",        "type": "password", "required": False,
         "showIf": {"auth_type": "basic"}},
        {"key": "api_key_name",    "label": "API Key Name",    "type": "text",     "required": False,
         "showIf": {"auth_type": "api_key"}, "placeholder": "X-API-Key"},
        {"key": "api_key_value",   "label": "API Key Value",   "type": "password", "required": False,
         "showIf": {"auth_type": "api_key"}},
        {"key": "api_key_location","label": "Key Location",    "type": "select",   "required": False,
         "showIf": {"auth_type": "api_key"}, "options": ["header", "query"], "default": "header"},
        {"key": "client_id",       "label": "Client ID",       "type": "text",     "required": False,
         "showIf": {"auth_type": "oauth2_client_credentials"}},
        {"key": "client_secret",   "label": "Client Secret",   "type": "password", "required": False,
         "showIf": {"auth_type": "oauth2_client_credentials"}},
        {"key": "token_url",       "label": "Token URL",       "type": "text",     "required": False,
         "showIf": {"auth_type": "oauth2_client_credentials"},
         "placeholder": "https://auth.example.com/oauth/token"},
        {"key": "default_headers", "label": "Default Headers (JSON)", "type": "textarea", "required": False,
         "placeholder": '{"Accept": "application/json"}'},
        {"key": "timeout_seconds", "label": "Timeout (sec)",   "type": "number",   "required": False, "default": 30},
        {"key": "verify_ssl",      "label": "Verify SSL",      "type": "boolean",  "required": False, "default": True},
        {"key": "rate_limit_rps",  "label": "Rate Limit (req/sec)", "type": "number", "required": False, "default": 10},
    ],
}


def _try_system_account_fallback(connector, connection_id: int,
                                    connection_name: str, sql,
                                    args, kwargs,
                                    method: str = "execute_query"):
    """BF-557 (2026-05-29): one-shot retry through the connection's
    configured system_account when the primary auth path has tripped
    the circuit breaker.

    Returns the connector result on success, ``None`` on any failure
    (including "no system_account configured" / "fallback also
    fails").  Telemetry-only — never raises so the caller's existing
    CircuitOpenError surfaces cleanly when fallback isn't an option.

    Opt-out via ``circuit_breaker.system_account_fallback_enabled=false``.
    """
    try:
        from core.config import get as _cfg
        if not bool(_cfg("circuit_breaker",
                         "system_account_fallback_enabled", True)):
            return None
    except Exception as _cfg_exc:
        import logging as _l
        _l.getLogger(__name__).debug(
            "BF-557 config read failed; defaulting to fallback-enabled: %s",
            _cfg_exc)
    try:
        from core.connection_manager import get_connection_manager
        cm = get_connection_manager()
        if not (cm and getattr(cm, "db", None)):
            return None
        conn = cm.db.get_connection_raw(int(connection_id))
        if not conn:
            return None
        cfg = conn.get("config", {}) or {}
        sa_id = cfg.get("system_account_id")
        if not sa_id:
            return None  # no fallback configured
        sa = cm.db.get_system_account_raw(int(sa_id))
        if not sa:
            return None
        # Build a one-shot connector using the system_account credentials.
        import logging as _l
        _log = _l.getLogger(__name__)
        _log.warning(
            "BF-557 CB-open on %s (id=%d) — attempting "
            "one-shot system_account fallback",
            connection_name, connection_id,
        )
        # Clone the config with system_account creds patched in.
        _sa_cfg = dict(cfg)
        # Phase 156 (2026-06-25) deep-dive -- credential source MUST go
        # through the Phase 154 qs_credentials chokepoint so the
        # use_vault toggle is honoured.  Pre-fix this path read
        # ``sa["password"]`` directly which is BLANK for vault-backed
        # accounts (password column is intentionally empty when
        # use_vault=True) -- silent auth failure on every CB-fallback
        # for vault accounts.
        _sa_username = ""
        _sa_password = ""
        try:
            from core.qs_credentials import resolve_system_account
            _resolved = resolve_system_account(int(sa_id), db_manager=cm.db)
            _sa_username = str(_resolved.get("username") or "")
            _sa_password = str(_resolved.get("password") or "")
        except Exception as _sr_exc:
            # Resolver failed (vault outage, misconfig).  Fall back to
            # the column ONLY when use_vault=False -- otherwise abort
            # the fallback so we don't silently retry with blank creds.
            if not bool(sa.get("use_vault", False)):
                _sa_username = str(
                    sa.get("username")
                    or (sa.get("config") or {}).get("username") or ""
                )
                _sa_password = str(
                    sa.get("password")
                    or (sa.get("config") or {}).get("password") or ""
                )
                if not _sa_password:
                    _log.warning(
                        "BF-557 SA fallback: column-based creds for "
                        "id=%s came back blank -- aborting fallback "
                        "instead of retrying with empty password.",
                        sa_id,
                    )
                    return None
            else:
                _log.error(
                    "BF-557 SA fallback: vault-backed SA id=%s "
                    "(use_vault=True) resolution failed (%s) -- "
                    "aborting rather than retrying with the BLANK "
                    "column password.",
                    sa_id, _sr_exc,
                )
                return None
        # Inject resolved creds across the field-name variants that
        # each connector adapter looks up.
        for src_value, dst_keys in (
            (_sa_username, ("username", "user")),
            (_sa_password, ("password", "pass", "secret")),
        ):
            if src_value:
                for dk in dst_keys:
                    _sa_cfg[dk] = src_value
        _conn_type = conn.get("connection_type", "")
        # Use the same factory path the primary connector used so any
        # adapter / wrap logic stays consistent.
        _fb_connector = get_connector(_conn_type, _sa_cfg,
                                        connection_id=None,
                                        connection_name=connection_name + "[fallback]")
        if _fb_connector is None:
            return None

        def _close_fb():
            # Best-effort close so we don't leak connector state.
            for _attr in ("close", "shutdown", "dispose"):
                _close = getattr(_fb_connector, _attr, None)
                if callable(_close):
                    try:
                        _close()
                    except Exception:
                        break
                    break

        # 2026-08-20 -- STREAMING fallback.  The circuit breaker now guards
        # execute_query_streaming too (it guarded only execute_query, while
        # the product's data path -- interactive background execution, feeds,
        # reports, cross-source legs -- ALL stream), so BF-557 must be able
        # to answer in kind: a materialised execute_query result is the
        # wrong shape for a streaming caller.  The fallback connector must
        # stay OPEN until the caller exhausts the generator, hence the
        # close-on-final wrapper instead of the finally below.
        if method == "execute_query_streaming":
            def _stream_and_close():
                try:
                    for _item in _fb_connector.execute_query_streaming(
                            sql, *args, **kwargs):
                        yield _item
                finally:
                    _close_fb()
            return _stream_and_close()
        try:
            return _fb_connector.execute_query(sql, *args, **kwargs)
        finally:
            _close_fb()
    except Exception as exc:
        import logging as _l
        _l.getLogger(__name__).debug(
            "BF-557 system_account fallback failed: %s", exc)
        return None


#: SQLSTATE classes that mean the SOURCE answered and refused the STATEMENT
#: (syntax / missing object / access rule 42, data 22, cardinality 21,
#: integrity 23, unsupported feature 0A) -- the source is up.
_STATEMENT_FAULT_SQLSTATE_CLASSES = frozenset({"42", "22", "21", "23", "0A"})
#: Oracle's equivalents (ORA-00900..00999 statement/identifier errors incl.
#: 00942 table or view does not exist, 00904 invalid identifier; 01722
#: invalid number; 01427 single-row subquery; 01476 divisor is zero; date
#: format errors 01843/01847/01858/01861).
_ORACLE_STATEMENT_FAULT_CODES = frozenset(
    set(range(900, 1000)) | {1427, 1476, 1722, 1843, 1847, 1858, 1861})


def statement_refused_by_source(exc: BaseException) -> bool:
    """True when ``exc`` is the source's verdict on the STATEMENT -- it was
    reached, it answered, it refused the SQL -- rather than a sign the source
    is unhealthy.

    2026-10-03, REAL Snowflake: three "Object 'SUPPLIER' does not exist"
    compilation errors (a user's unqualified table names) OPENED the
    connection's circuit breaker, and every later query on it -- correct ones
    included -- was refused "temporarily unavailable" with a growing backoff.
    A breaker exists to stop hammering a source that is DOWN; a source that
    compiled the statement and said no is up.  Walks the cause chain because
    the connectors re-raise driver errors as SourceStatementError."""
    seen = 0
    e = exc
    while e is not None and seen < 5:
        seen += 1
        if type(e).__name__ == "TrinoUserError":
            return True
        state = str(getattr(e, "sqlstate", "") or "")
        if len(state) >= 2 and state[:2].upper() in _STATEMENT_FAULT_SQLSTATE_CLASSES:
            return True
        err0 = e.args[0] if getattr(e, "args", None) else None
        code = getattr(err0, "code", None)
        if type(e).__module__.startswith("oracledb") and isinstance(code, int)                 and code in _ORACLE_STATEMENT_FAULT_CODES:
            return True
        e = e.__cause__ or e.__context__
    return False


#: The connector methods that open a session and may meet the source's
#: refusal of the LOGIN.  Each is wrapped by ``_wrap_with_credential_freshness``.
#: ``execute_query_streaming`` is handled apart (a generator).
_FRESHNESS_METHODS = ("execute_query", "test_connection", "list_catalogs",
                      "list_schemas", "list_tables", "list_columns",
                      "detect_partitions")


def _wrap_with_credential_freshness(connector, connection_type: str,
                                    stored_config: Dict[str, Any],
                                    connection_id):
    """A connector built from a System Account heals itself ONCE when the
    source rejects the login (2026-10-30).

    The owner on UAT: after a Vault rotation QueryStudio "tries with old
    pwd ... after 20-30 mins worked".  The credential cache (15 min memory,
    24 h disk) and the connector pool (keyed on the STORED config, which a
    rotation does not change) both kept the old password.  Now, when a
    wrapped method raises an AUTH failure -- and ONLY that, as declared in
    ``core/qs_credentials/freshness.py::is_auth_failure``; a statement the
    source refused is never retried -- the account is forgotten on this pod
    (memory dropped, disk distrusted, pooled connectors closed), re-read
    from Vault, re-applied to the stored config, the connector's session is
    closed so it reconnects with the fresh login, and the call runs once
    more.  If Vault still holds the very secret the source rejected, the
    original error is raised (the log says the two disagree).

    Retry safety is DECLARED, never assumed (security review, 2026-10-30):
    an auth refusal normally comes at the CONNECT, but the vocabulary also
    reads message text, and a statement can fail mid-run with similar words
    (Trino reading S3 with a bad key).  So a STATEMENT (``execute_query`` /
    ``execute_query_streaming``) is run again only when it is PROVED
    read-only (``core/s3_scan_retry.py::read_only_refusal`` -- parsed, nested
    writes included, unparseable = unsafe); a write is healed (the next call
    logs in fresh) but never re-run -- the original error is raised.  The
    metadata calls and Test are reads by nature.  The streaming method is
    retried only when it failed BEFORE its first row.

    A config that names no account is returned untouched."""
    from core.qs_credentials import freshness as _fresh
    sa_ref = _fresh.account_ref(stored_config)
    if sa_ref is None:
        return connector
    import functools

    def _heal(exc, what) -> bool:
        fresh = _fresh.heal(
            sa_ref, exc, connection_id=connection_id,
            what=f"{connection_type} {what}",
            previous=_fresh.creds_view(getattr(connector, "config", None)))
        if fresh is None:
            return False
        connector.config = apply_system_account(connection_type, stored_config)
        try:
            connector.close()          # the session built from the old login
        except Exception as close_exc:  # noqa: BLE001
            import logging as _logging
            _logging.getLogger(__name__).debug(
                "freshness: close before reconnect failed: %s", close_exc)
        return True

    def _may_rerun(name, args, kwargs) -> bool:
        if name not in ("execute_query", "execute_query_streaming"):
            return True
        sql = args[0] if args else (kwargs.get("sql") or kwargs.get("query"))
        from core.s3_scan_retry import read_only_refusal
        why = read_only_refusal(sql)
        if why is not None:
            import logging as _logging
            _logging.getLogger(__name__).warning(
                "[credential-freshness] %s %s: the login was refreshed but the "
                "statement is NOT run again (%s); the next call uses the fresh login",
                connection_type, name, why)
            return False
        return True

    def _result_is_auth_failure(result):
        # test_connection reports its driver error as a dict, not a raise.
        if isinstance(result, dict) and result.get("success") is False:
            msg = str(result.get("message") or result.get("error") or "")
            return _fresh.is_auth_failure(RuntimeError(msg)) is not None
        return False

    for name in _FRESHNESS_METHODS:
        original = getattr(connector, name, None)
        if not callable(original):
            continue

        def _make(original, name):
            @functools.wraps(original)
            def fresh_call(*args, **kwargs):
                try:
                    result = original(*args, **kwargs)
                except Exception as exc:
                    if not _heal(exc, name) or not _may_rerun(name, args, kwargs):
                        raise
                    return original(*args, **kwargs)
                if _result_is_auth_failure(result) and _heal(
                        RuntimeError(str(result.get("message") or result.get("error"))), name):
                    return original(*args, **kwargs)
                return result
            return fresh_call
        setattr(connector, name, _make(original, name))

    original_stream = getattr(connector, "execute_query_streaming", None)
    if callable(original_stream):
        @functools.wraps(original_stream)
        def fresh_stream(*args, **kwargs):
            gen = original_stream(*args, **kwargs)
            try:
                first = next(gen)
            except StopIteration:
                return
            except Exception as exc:
                # Nothing was yielded: the failure is the login's, or the
                # statement's -- heal decides, and only an auth failure
                # starts the stream again.
                if (not _heal(exc, "execute_query_streaming")
                        or not _may_rerun("execute_query_streaming", args, kwargs)):
                    raise
                yield from original_stream(*args, **kwargs)
                return
            yield first
            yield from gen
        connector.execute_query_streaming = fresh_stream
    return connector


def _wrap_with_circuit_breaker(connector, connection_id: int, connection_name: str):
    """Wrap connector methods with circuit breaker checks."""
    try:
        from core.circuit_breaker import check_circuit, record_success, record_failure, CircuitOpenError
    except ImportError:
        return connector

    original_execute = connector.execute_query
    original_test = getattr(connector, 'test_connection', None)

    def guarded_execute(sql, *args, **kwargs):
        check_circuit(connection_id, connection_name)
        try:
            result = original_execute(sql, *args, **kwargs)
            record_success(connection_id)
            return result
        except CircuitOpenError:
            # BF-557 (2026-05-29): on CB open, attempt a one-shot
            # fallback through the connection's system_account if
            # configured.  Often the primary auth (portal STS, personal
            # vault) has expired but the system_account is still valid.
            # If the fallback succeeds we DO NOT touch the CB —
            # primary's outage is still real, just less impactful.
            _fb_result = _try_system_account_fallback(
                connector, connection_id, connection_name, sql,
                args, kwargs,
            )
            if _fb_result is not None:
                return _fb_result
            raise
        except Exception as e:
            if statement_refused_by_source(e):
                record_success(connection_id)   # it answered: the source is up
            elif not isinstance(e, CircuitOpenError):
                record_failure(connection_id, str(e), connection_name)
            raise

    connector.execute_query = guarded_execute

    # 2026-08-20 -- GUARD THE STREAMING METHOD TOO.  The breaker wrapped
    # execute_query only, but the product's data path is
    # execute_query_streaming: execute_sql_connector_background
    # (api/execute_api.py), connector_to_parquet.execute_sql_to_parquet
    # (feeds, reports) and the cross-source legs ALL stream.  So an OPEN
    # circuit did not stop interactive/feed/report queries, their failures
    # never called record_failure (a flapping source could hammer forever
    # without ever tripping), and the BF-557 system-account fallback could
    # never fire on the path users actually run.
    #
    # Generator semantics, deliberately:
    #   * check_circuit runs when iteration STARTS (a generator body does
    #     not execute at call time) -- every call site iterates immediately.
    #   * record_success only after the stream is EXHAUSTED: rows already
    #     yielded cannot be un-yielded, so a mid-stream failure must count
    #     as a failure, not a success-then-failure.
    #   * a caller abandoning the generator early (GeneratorExit) records
    #     neither success nor failure -- nothing is known about the source.
    original_stream = getattr(connector, 'execute_query_streaming', None)
    if callable(original_stream):
        def guarded_stream(sql, *args, **kwargs):
            try:
                check_circuit(connection_id, connection_name)
            except CircuitOpenError:
                # BF-557: same one-shot system_account fallback as
                # execute_query, in streaming shape.  On success the CB is
                # deliberately NOT touched -- the primary's outage is still
                # real, just less impactful.
                _fb_stream = _try_system_account_fallback(
                    connector, connection_id, connection_name, sql,
                    args, kwargs, method="execute_query_streaming",
                )
                if _fb_stream is not None:
                    for item in _fb_stream:
                        yield item
                    return
                raise
            try:
                for item in original_stream(sql, *args, **kwargs):
                    yield item
            except Exception as e:
                if statement_refused_by_source(e):
                    record_success(connection_id)
                elif not isinstance(e, CircuitOpenError):
                    record_failure(connection_id, str(e), connection_name)
                raise
            else:
                record_success(connection_id)
        connector.execute_query_streaming = guarded_stream

    if original_test:
        def guarded_test(*args, **kwargs):
            check_circuit(connection_id, connection_name)
            try:
                result = original_test(*args, **kwargs)
            except Exception as e:
                if not isinstance(e, CircuitOpenError):
                    record_failure(connection_id, str(e), connection_name)
                raise
            # 2026-10-18 -- a test that RETURNS {"success": False} is a failed
            # call to the source as much as one that raises (every connector
            # catches its driver's error and returns it as a message): it
            # counts toward the breaker, so three failed tests of a dead source
            # open it and the rig's C7 can prove a reset reaches every pod.
            if isinstance(result, dict) and result.get("success") is False:
                record_failure(connection_id, str(result.get("message") or result.get("error") or "test failed"),
                               connection_name)
            else:
                record_success(connection_id)
            return result
        connector.test_connection = guarded_test

    return connector


#: 2026-10-03 -- the Vault kv field names a Snowflake KEY-PAIR System Account
#: may carry its key under (first non-empty wins), its passphrase, and its
#: login name.  ("why should we paste the private key ... in a real scenario
#: the key comes from Vault as a key/value pair").
_SF_KV_KEY_FIELDS = ("private_key", "private_key_pem", "rsa_private_key",
                     "snowflake_private_key")
_SF_KV_PASSPHRASE_FIELDS = ("private_key_passphrase", "passphrase")
_SF_KV_USER_FIELDS = ("username", "user")
#: Keys the resolver itself adds to a kv payload -- never Vault fields.
_RESOLVER_META_KEYS = frozenset({"id", "vault_id", "account_type", "via"})


def _first_kv(creds: Dict[str, Any], fields) -> Any:
    """The first of ``fields`` that holds a non-blank value, else None."""
    return next((creds[f] for f in fields if str(creds.get(f) or "").strip()),
                None)


def _snowflake_service_login(config: Dict[str, Any]) -> Dict[str, Any]:
    """A Snowflake ``sso_portal`` connection as the login it really is
    (2026-11-04; a new dict).  Despite the name no portal is called: Snowflake
    is given a service user + password, or a key.  So the typed service pair
    becomes the connection's user + password, and with a System Account the
    auth type is left unset: the account's entry decides, a password or a key
    (``_map_snowflake_key_pair``).  Every other connection is returned as is."""
    if str(config.get("auth_type") or "").strip().lower() != "sso_portal":
        return config
    out = dict(config)
    has_account = (out.get("system_account_id") or out.get("system_account_name")
                   or out.get("system_account"))
    if has_account:
        # Anything typed before the account was chosen stays stored behind "***":
        # kept, a password would also stop the entry's key from being used.
        out.pop("user", None)
        out.pop("password", None)
        out["auth_type"] = ""
        return out
    typed_user = str(out.get("sso_username") or "").strip()
    typed_password = str(out.get("sso_password") or "").strip()
    if typed_user and typed_password:
        out["user"], out["password"] = typed_user, typed_password
    out["auth_type"] = "password"
    return out


def snowflake_login_problem(creds: Dict[str, Any]) -> str | None:
    """What stops a resolved account from logging in to Snowflake, or None.
    Field NAMES only, never a value.  AWS keys in the entry are not a login:
    Snowflake never reads them."""
    if _first_kv(creds, _SF_KV_KEY_FIELDS) is not None:
        return snowflake_key_pair_problem(creds)
    if _first_kv(creds, _SF_KV_USER_FIELDS) and str(creds.get("password") or "").strip():
        return None
    present = sorted(str(k) for k in creds if k not in _RESOLVER_META_KEYS)
    return (f"the entry has no Snowflake login: it must carry one of "
            f"{list(_SF_KV_USER_FIELDS)} and 'password', or a private key "
            f"(it has the fields {present})")


def _map_snowflake_key_pair(config: Dict[str, Any], creds: Dict[str, Any],
                            sa_ref: Any, literal_password: bool) -> None:
    """Fill a Snowflake connection's key-pair login from its resolved System
    Account (``config`` is the caller's private copy; mutated in place).

    Literal wins, as for every other mapping here: a pasted key -- with its
    own passphrase -- is never replaced, and a connection whose auth_type is
    password / oauth / sso_portal is not touched.  An UNSET auth_type takes
    the account's key unless a literal password was typed.  The account's
    passphrase travels with the account's key; absent, a typed passphrase
    stays.  A key_pair connection that relies on the account and gets no key
    raises, naming the accepted fields and the fields the entry DOES have
    (names only): Snowflake would otherwise be asked to log in with nothing,
    and the account's real shape would be invisible."""
    user = _first_kv(creds, _SF_KV_USER_FIELDS)
    if user and not str(config.get("user") or "").strip():
        config["user"] = user
    auth = str(config.get("auth_type") or "").strip().lower()
    if auth not in ("", "key_pair") or str(config.get("private_key") or "").strip():
        return
    key = _first_kv(creds, _SF_KV_KEY_FIELDS)
    if key is None and auth == "key_pair":
        present = sorted(str(k) for k in creds if k not in _RESOLVER_META_KEYS)
        raise RuntimeError(
            f"SystemAccount {sa_ref!r} has no Snowflake private key: its "
            f"entry must carry one of {list(_SF_KV_KEY_FIELDS)} "
            f"(it has the fields {present})")
    if key is None or (auth == "" and literal_password):
        return
    config["private_key"] = key
    config["auth_type"] = "key_pair"
    passphrase = _first_kv(creds, _SF_KV_PASSPHRASE_FIELDS)
    if passphrase:
        config["private_key_passphrase"] = passphrase


def snowflake_key_pair_problem(creds: Dict[str, Any]) -> str | None:
    """What stops a resolved ``snowflake_keypair`` System Account from
    logging in -- or None when its key is present and opens.

    The admin Test of such an account used to say "Resolver succeeded"
    whenever Vault answered, whatever the entry held.  This asks the
    question a login would: is there a key under an accepted field, and do
    the key and passphrase load?  Field NAMES only in the answer, never a
    value."""
    key = _first_kv(creds, _SF_KV_KEY_FIELDS)
    if key is None:
        present = sorted(str(k) for k in creds if k not in _RESOLVER_META_KEYS)
        return (f"the Vault entry has no private key: it must carry one of "
                f"{list(_SF_KV_KEY_FIELDS)} (it has the fields {present})")
    if _first_kv(creds, _SF_KV_USER_FIELDS) is None:
        return (f"the Vault entry has no login name: add one of "
                f"{list(_SF_KV_USER_FIELDS)} (or type the Username on the "
                f"connection)")
    from .snowflake_connector import load_private_key_der
    try:
        load_private_key_der(key, _first_kv(creds, _SF_KV_PASSPHRASE_FIELDS))
    except ValueError as exc:
        return str(exc)
    return None


def apply_system_account(connection_type: str, config: Dict[str, Any]) -> Dict[str, Any]:
    """The connection config with its System Account's credentials filled in
    (a new dict; the input is untouched).  THE one place a SQL connection's
    ``system_account_id`` becomes a login: ``get_connector`` calls it, and so
    does the Spark lane's source conf (``core/spark_k8s/feed_conf.py``), which
    read the saved fields alone and sent a Vault-backed connection to the pod
    with no password (2026-10-29).  Raises ``CredentialsUnavailableError``
    when the account cannot be resolved and nothing typed can stand in."""
    if (connection_type or "").lower() == "snowflake":
        config = _snowflake_service_login(config)
    # Phase 154 (2026-06-25) -- SQL connector SystemAccount resolution.
    # When the connection config references a SystemAccount (by id or
    # name), pre-resolve its credentials via the QueryStudio secret
    # resolver chokepoint BEFORE instantiating the connector.  This
    # closes the gap operator surfaced ("...in case of if any system
    # account used for aws s3 or trino or any source...").  Mirrors
    # the AWS S3 wire-in at core/credential_resolver.py.
    #
    # 2026-06-25 fail-CLOSED policy (operator: "i dont want any risk"):
    # if the connection has NO literal username/password AND only the
    # SystemAccount ref, a resolver failure means we cannot connect.
    # Raise RuntimeError to surface the misconfiguration loudly.  When
    # literal user/password ARE configured alongside the ref, fall
    # through with a warning (operator explicitly opted-in to both).
    _sa_ref = (config.get("system_account_id")
               or config.get("system_account_name")
               or config.get("system_account"))
    if _sa_ref:
        _literal_user = ((config.get("user") or config.get("username")) or "").strip()
        _literal_password = bool((config.get("password") or "").strip())
        _has_literal_creds = bool(_literal_user and _literal_password)
        # 2026-10-03 -- a key-pair connection's literal credential is its
        # PRIVATE KEY, not a password.  Counting only user+password made a
        # key_pair connection with a pasted key AND a System Account fail
        # CLOSED on a resolver error although it had everything it needed.
        if (not _has_literal_creds
                and str(config.get("auth_type") or "").strip().lower() == "key_pair"):
            _has_literal_creds = bool(
                _literal_user and str(config.get("private_key") or "").strip())
        try:
            from core.qs_credentials import resolve_system_account
            _sa_creds = resolve_system_account(_sa_ref)
            config = dict(config)
            # DB_accounts / AD_accounts -> user + password.  Most SQL
            # connectors use `user`; oracle uses `username`.  Set both
            # so connector-specific code finds what it expects.
            #
            # 2026-10-29 -- a username and its password are ONE credential.
            # The owner: "leave username/password blank to use vault but
            # username is mandatory ... works with my credentials, not vault
            # based".  The form required a Username, so a typed name went to
            # Trino with the VAULT password -- a pair nobody owns, HTTP 401.
            # With no typed password, the account's username AND password are
            # the login (a typed username is not kept beside them).  Typed
            # username + password = the typed pair, as before.
            # THE rule (core/qs_credentials/login.py::pair_login) -- for a
            # PASSWORD login only.  A key pair, a token, Kerberos, JWT or OAuth
            # login is not a user + password pair: its typed user is the
            # identity (the review: a Snowflake key pair took the account's
            # AD name beside the pasted key, a Kerberos session user became
            # the service account), so there only empty fields are filled.
            from core.qs_credentials.login import pair_login
            _auth = str(config.get("auth_type") or config.get("authenticator") or "").strip().lower()
            _password_login = _auth in ("", "basic", "password", "snowflake", "userpass")
            _typed_secret = (config.get("password") or config.get("private_key")
                             or config.get("token") or config.get("access_token") or "")
            if _password_login:
                _account_user = _sa_creds.get("username")
                if (connection_type or "").lower() == "snowflake":
                    _account_user = _first_kv(_sa_creds, _SF_KV_USER_FIELDS)
                _login = pair_login(_literal_user, _typed_secret,
                                    _account_user, _sa_creds.get("password"))
                if _login.user:
                    config["user"] = _login.user
                    config["username"] = _login.user
                if _login.secret_from == "account":
                    config["password"] = _login.secret
            else:
                if _sa_creds.get("username") and not config.get("user"):
                    config["user"] = _sa_creds["username"]
                if _sa_creds.get("username") and not config.get("username"):
                    config["username"] = _sa_creds["username"]
                if _sa_creds.get("password") and not config.get("password"):
                    config["password"] = _sa_creds["password"]
            if _sa_creds.get("tns_alias") and not config.get("tns_alias"):
                config["tns_alias"] = _sa_creds["tns_alias"]
            # kv_secrets shape (rare for SQL connectors but supported
            # for OAuth/token-based auth):
            for k in ("token", "access_key", "secret_key"):
                v = _sa_creds.get(k)
                if v and not config.get(k):
                    config[k] = v
            # Connector-specific key mappings: the resolver returns generic
            # names, but a few connectors read their own keys.  Additive +
            # literal-wins; does NOT touch the user/password/token fills above
            # or the working S3 / Snowflake-sso paths.
            _ct = (connection_type or "").lower()
            if _ct == "databricks" and not config.get("access_token"):
                # Databricks reads ``access_token``.  A system account may carry
                # the PAT as ``token``, as a kv ``access_key``, or (db_account)
                # as the ``password`` column -- accept any of them.
                _tok = (_sa_creds.get("token") or _sa_creds.get("access_key")
                        or _sa_creds.get("password"))
                if _tok:
                    config["access_token"] = _tok
            elif _ct == "athena":
                # Athena (access_key mode) reads the aws_-prefixed keys.
                for _src, _tgt in (
                    ("access_key",    "aws_access_key_id"),
                    ("secret_key",    "aws_secret_access_key"),
                    ("session_token", "aws_session_token"),
                ):
                    _v = _sa_creds.get(_src)
                    if _v and not config.get(_tgt):
                        config[_tgt] = _v
            elif _ct == "snowflake":
                _map_snowflake_key_pair(config, _sa_creds, _sa_ref,
                                        _literal_password)
                if str(config.get("auth_type") or "").strip().lower() in ("", "password"):
                    # A password login, on either auth type.  With no user or no
                    # password, say so: an entry under other field names used to
                    # reach the driver as a blank login, or as KeyError 'user'.
                    if (not (str(config.get("user") or "").strip()
                             and str(config.get("password") or "").strip())
                            and not _has_literal_creds):
                        _problem = (snowflake_login_problem(_sa_creds)
                                    or "a password login needs a username and a password")
                        raise RuntimeError(f"SystemAccount {_sa_ref!r}: {_problem}")
                    config["auth_type"] = "password"
        except Exception as _sa_exc:
            import logging as _logging
            _log = _logging.getLogger(__name__)
            if _has_literal_creds:
                # Fail-OPEN: literal creds are the explicit fallback.
                _log.warning(
                    "SystemAccount %r resolution failed for connector "
                    "type=%s (%s) -- falling back to literal user/password",
                    _sa_ref, connection_type, _sa_exc,
                )
            else:
                # Fail-CLOSED: nothing else to try.  Re-raise so caller
                # sees the misconfiguration immediately.
                _log.error(
                    "SystemAccount %r resolution failed for connector "
                    "type=%s (%s) -- FAIL-CLOSED: no literal credentials "
                    "available, cannot instantiate connector.",
                    _sa_ref, connection_type, _sa_exc,
                )
                # 2026-10-04 -- typed, so every route answers 503 + Retry-After
                # with a caller-safe sentence instead of a 500 "contact
                # administrator"; the root cause is in the ERROR line above.
                from core.connectors.base import CredentialsUnavailableError
                raise CredentialsUnavailableError(
                    _sa_exc, connection_type) from _sa_exc
    return config


def get_connector(connection_type: str, config: Dict[str, Any],
                  connection_id: int | None = None,
                  connection_name: str = "") -> SqlConnector:
    """
    Instantiate and return the correct SqlConnector for `connection_type`.

    Args:
        connection_type: one of "trino", "starburst", "snowflake", "databricks"
        config: the connection-specific configuration dict stored in the DB
        connection_id: optional DB id — when provided, wraps connector with circuit breaker
        connection_name: optional display name for circuit breaker logging

    Returns:
        SqlConnector instance (not yet connected — call test_connection or execute_query)

    Raises:
        ValueError: if connection_type is unsupported
        RuntimeError: if the required driver package is not installed
    """
    entry = _REGISTRY.get(connection_type.lower())
    if not entry:
        supported = ", ".join(sorted(_REGISTRY.keys()))
        raise ValueError(
            f"Unsupported connection type '{connection_type}'. "
            f"Supported: {supported}"
        )

    stored_config = config
    config = apply_system_account(connection_type, config)

    module_name, class_name = entry.rsplit(".", 1)
    # Lazy import within this package
    import importlib
    module = importlib.import_module(f".{module_name}", package=__name__)
    cls = getattr(module, class_name)
    connector = cls(config)

    # 2026-10-30 -- a System-Account connector heals itself ONCE on an AUTH
    # failure (the stored config is what the account is re-applied to).
    # Inside the circuit-breaker wrap below, so a healed login counts as
    # the success it is.
    connector = _wrap_with_credential_freshness(
        connector, connection_type, stored_config, connection_id)

    # Phase 133-H round 9 — stamp the connection_id on the raw connector
    # so per-connection lookups (e.g. RestApiConnector.list_columns
    # reading saved RestQueryDef rows) can find their config.  Set on
    # the BARE connector before circuit-breaker wrapping so the
    # attribute is visible through any wrapper's __getattr__ fallback.
    if connection_id is not None:
        try:
            connector._connection_id = connection_id
        except Exception:
            pass
    # 2026-09-27 -- the ENGINE this connector is (core/engine_attribution.py
    # reads it through ``engine_for_connector``).  Stamped on the bare
    # connector for the same reason as ``_connection_id``: the background
    # executor receives an already-constructed connector and nothing else
    # said which source it talks to.
    try:
        connector._engine_type = str(connection_type or "").lower()
    except Exception:
        pass

    # Circuit breaker wrapping
    if connection_id is not None:
        connector = _wrap_with_circuit_breaker(connector, connection_id, connection_name)

    return connector


SQL_CONNECTOR_TYPES = list(_REGISTRY.keys())

# ── "Can THIS server open this connection type?" ─────────────────────────
# 2026-09-15.  Every connector lazy-imports its driver, so a type the
# registry offers (and the Connection UI lists) can be one this image
# cannot open at all -- ``databricks`` is deliberately shipped without
# ``databricks-sql-connector`` (requirements.txt, thrift CVE pin), and
# ``athena``/``oracle`` depend on the interpreter.  The only way to learn
# that was to save the connection and test it.  This answers OFFLINE (a
# find_spec, no import, no network) so the types listing can say so at
# selection time.  ``None`` = no third-party driver (rest_api is stdlib).
_DRIVER_MODULES: Dict[str, tuple] = {
    "trino":      ("trino", "trino"),
    "starburst":  ("trino", "trino"),
    "snowflake":  ("snowflake.connector", "snowflake-connector-python"),
    "databricks": ("databricks.sql", "databricks-sql-connector"),
    "oracle":     ("oracledb", "oracledb"),
    "athena":     ("pyathena", "pyathena"),
    "rest_api":   None,
}


def driver_status(connection_type: str) -> Dict[str, Any]:
    """``{"available": bool, "package": str|None, "reason": str}`` for a
    registered type -- what the browse routes will answer with 501 if it
    is False, said BEFORE the connection is saved.

    ``available`` is decided by ``importlib.util.find_spec`` on the
    driver's top-level module: cheap, no import side effects, no network.
    A spec that exists but fails to import (a broken install) is reported
    available here and refused by the connector at open time with the
    same message -- this is a pre-check, not a proof.
    """
    import importlib.util
    ctype = str(connection_type or "").lower()
    if ctype not in _REGISTRY:
        return {"available": False, "package": None,
                "reason": f"'{connection_type}' is not a registered connector type"}
    spec = _DRIVER_MODULES.get(ctype)
    if spec is None:
        return {"available": True, "package": None, "reason": ""}
    module, package = spec
    import sys
    if module in sys.modules:
        # Already imported (or deliberately blanked with None, the standard
        # way a test removes a driver).  find_spec would read ``__spec__``
        # off the module object, which a stub lacks.
        found = sys.modules[module] is not None
    else:
        try:
            found = importlib.util.find_spec(module) is not None
        except (ImportError, ValueError):
            # find_spec raises when a PARENT package is present but broken
            # (e.g. ``snowflake`` without ``snowflake.connector``).
            found = False
    if found:
        return {"available": True, "package": package, "reason": ""}
    extra = ""
    if ctype == "databricks":
        extra = (" It is deliberately not bundled (its thrift pin carries "
                 "open CVEs); install it into the image that needs Databricks.")
    return {"available": False, "package": package,
            "reason": f"{package} is not installed on this server, so "
                      f"{ctype} connections cannot be opened here.{extra}"}


def driver_statuses() -> Dict[str, Dict[str, Any]]:
    """``driver_status`` for every registered type, keyed by type."""
    return {t: driver_status(t) for t in _REGISTRY}

# Connector types usable from the SQL editor page (raw-SQL execution +
# catalog/schema/table browsing).  ``rest_api`` is a connector for REST
# endpoints — it has no SQL surface, so offering it in a SQL editor would be
# a dead end.  DECLARED here, next to the registry, so the frontend reads it
# from ``GET /api/sql/connector-types`` instead of restating (and drifting
# from) the list — the SqlQueryPage's hardcoded copy had already lost
# oracle and athena, hiding every Oracle/Athena connection from the page.
# ── "Is this a SQL connector?" — the ONE answer ──────────────────────────
# 2026-09-05.  That question was answered in four disagreeing places:
# ``core/scheduler.py::_SQL_TYPES`` and ``api/reports_api.py::_SQL_CONN_TYPES``
# (literal 6-type sets), ``core/federation_engine.py::SQL_CONNECTION_TYPES``
# (a literal 8, CLAIMING postgresql and mysql that ``_REGISTRY`` has no entry
# for -- ``get_connector("postgresql", ...)`` raises), and the registry
# itself.  Same defect class as the eight dialect vocabularies retired the
# same day: two ENGINES is fine, two ANSWERS to one question is not.
#
# DERIVED from ``_REGISTRY``, so registering a connector answers this for
# every consumer and a set here can never claim a type the factory would
# refuse.  ``rest_api`` is excluded because it has no SQL surface: it is a
# registered connector, but handing it a SELECT is not a routing decision
# any caller here wants -- the same exclusion, and the same reason, as
# ``SQL_EDITOR_TYPES`` below, which now derives from this rather than
# restating it.
SQL_EXECUTABLE_TYPES = frozenset(t for t in _REGISTRY if t != "rest_api")

SQL_EDITOR_TYPES = [t for t in _REGISTRY if t in SQL_EXECUTABLE_TYPES]
