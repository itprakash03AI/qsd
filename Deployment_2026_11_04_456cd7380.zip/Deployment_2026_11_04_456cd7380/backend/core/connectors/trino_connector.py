﻿"""
Trino / Starburst connector.
Supports both on-premises and cloud Starburst Galaxy deployments.

Required config keys:
  host          – Trino/Starburst host (e.g. "trino.example.com")
  port          – int, default 443 for HTTPS or 8080 for HTTP
  user          – authenticating user
  auth_type     – "basic" | "jwt" | "kerberos" | "oauth2" | "none"
  password      – for basic auth
  token         – for JWT/Bearer token auth
  catalog       – default catalog (optional)
  schema        – default schema (optional)
  http_scheme   – "https" | "http", default "https"
  verify_ssl    – bool, default True
  extra_headers – dict of extra HTTP headers (optional)
  session_props – dict of Trino session properties (optional)
"""

import functools
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from .base import SqlConnector, unique_column_names, DriverNotInstalled
from core.best_effort import note_best_effort
from core.cancel_scope import note_cancel


def _trino_query_id(cur) -> Optional[str]:
    """The coordinator's id of the statement ``cur`` runs, when the driver
    exposes it (``stats['queryId']`` once the query is registered; the
    ``_query`` object before) -- None otherwise.  Never raises."""
    try:
        st = getattr(cur, "stats", None)
        if isinstance(st, dict) and st.get("queryId"):
            return str(st["queryId"])
        q = getattr(cur, "_query", None)
        qid = getattr(q, "query_id", None) if q is not None else None
        return str(qid) if qid else None
    except Exception:  # noqa: BLE001
        return None


def _cancel_when_known(cur, cancel_event, stop, cancel) -> None:
    """The cancel watchdog's loop: once ``cancel_event`` is set, call ``cancel()``
    as soon as the coordinator knows the statement (it has a query id) -- or stop
    when ``stop`` is set (the statement ended).

    2026-11-02 (release-check, capacity_wait_proof): a report cancelled in the
    instant between "admitted" and "the statement reached Trino" left its
    statement RUNNING.  The watchdog saw the cancel first, called
    ``cur.cancel()`` on a cursor with no query yet (a no-op) and returned;
    ``execute`` then started the statement and nothing ever cancelled it."""
    while not stop.is_set():
        if cancel_event.is_set() and _trino_query_id(cur) is not None:
            cancel()
            return
        stop.wait(0.1 if cancel_event.is_set() else 0.5)


def _refuse_if_cancelled(cancel_event, what: str) -> None:
    """Never SEND a statement for a run that is already cancelled."""
    if cancel_event is not None and cancel_event.is_set():
        raise InterruptedError(f"{what} cancelled before it was sent to Trino")

_DEFAULT_CA_BUNDLE = Path(__file__).resolve().parent.parent.parent / "certs" / "tls_bundle.pem"


logger = logging.getLogger(__name__)


#: Seconds a connection is trusted without re-pinging the coordinator.
#: Short enough that a dead connection is caught quickly, long enough
#: that a burst of metadata calls costs ONE ping rather than N.
_PING_MAX_AGE_SECONDS = 60.0


def _reconnect_once(fn):
    """Retry ONE idempotent metadata read on a dead cached connection.

    2026-08-20 -- the 2026-08-19 ping throttle skips the ``SELECT 1`` liveness
    check for 60s and justified itself as "safe because execute_query already
    detects a dead connection and retries once on a fresh one".  That retry
    exists ONLY in execute_query.  Every other ``_cursor()`` user -- the
    catalog/schema/table/column listings, partition detection, test_connection
    -- had no recovery at all, so inside the 60s window they could receive a
    dead cached connection and surface a raw transport error where the ping
    used to have healed it silently.

    Applied ONLY to idempotent reads.  Deliberately NOT applied to
    execute_query (it has its own retry) or execute_query_streaming (a
    generator: re-running it after rows were already yielded would duplicate
    them, which is worse than the error).
    """
    @functools.wraps(fn)
    def _wrap(self, *args, **kwargs):
        try:
            return fn(self, *args, **kwargs)
        except Exception as exc:
            if not self._is_connection_error(exc):
                raise
            logger.warning(
                "Trino %s hit a stale cached connection -- reconnecting once: %s",
                getattr(fn, "__name__", "?"), exc)
            self._conn = None
            return fn(self, *args, **kwargs)
    return _wrap


def _qi(name: Any) -> str:
    """Quote one Trino identifier -- but only when it actually needs quoting.

    2026-08-19 -- catalog/schema/table were interpolated bare into SHOW and
    DESCRIBE (``f"DESCRIBE {catalog}.{schema}.{table}"``).  Any name needing
    quoting -- a hyphen, a reserved word, mixed case -- failed, and because
    these values reach here from an authenticated user's connection config
    and browse requests, the bare f-string was also an injection surface
    running under the connection's own credentials.

    2026-08-20 -- CONDITIONAL, like its three siblings.  The original fix
    quoted UNCONDITIONALLY, and Trino LOWER-FOLDS bare identifiers, so a
    connection config with ``catalog: "Hive"`` or a browse of ``MYSCHEMA``
    that worked before the fix started emitting the case-sensitive
    ``"Hive"`` -> "Catalog 'Hive' does not exist".  The bare-safe
    pass-through was applied to the snowflake/databricks/athena quoters the
    same day and never retrofitted here.  Now all four delegate to the ONE
    shared implementation in base.py (which also quotes reserved words --
    the injection posture is unchanged: any name that could carry a quote
    or a break-out character is still quoted and escaped).
    """
    from .base import quote_identifier
    return quote_identifier(name, quote='"', fold=str.lower,
                            allow_dollar=False)


def _roles_for(config: Dict[str, Any]) -> Optional[Dict[str, str]]:
    """The ``roles`` the trino client sends as ``X-Trino-Role`` (2026-10-08).

    ``role`` is the SYSTEM role -- what Starburst Galaxy means by a role
    (``accountadmin``, a custom role) and what a ``set role`` statement
    selects when no catalog is named; ``catalog_roles`` maps a catalog to its role for clusters
    with catalog-level roles (Hive sql-standard).  Before this no road sent
    a role at all, so a connection could only ever run as the user's
    DEFAULT role -- and on a Galaxy account whose default role sees
    nothing, every browse was honestly empty.  None when nothing is set:
    the client then sends no header.
    """
    out: Dict[str, str] = {}
    system = str(config.get("role") or "").strip()
    if system:
        out["system"] = system
    for cat, role in dict(config.get("catalog_roles") or {}).items():
        cat_s, role_s = str(cat or "").strip(), str(role or "").strip()
        if cat_s and role_s:
            out[cat_s] = role_s
    return out or None


def _resolve_ssl_verify(val, ca_cert_pem: Any = None) -> Any:
    """Return the ``requests`` verify value, via the SHARED trust resolver.

    2026-10-08 -- ``ca_cert_pem``: the issuing CA pasted on the connection
    (a Starburst Enterprise behind a corporate CA).  When verification is
    on, it becomes a bundle file merged with certifi
    (``core.ssl_config.bundle_for_pem``); ``verify_ssl=False`` still wins,
    said out loud by the resolver.  A paste that holds no certificate is a
    ValueError naming the field -- never a silent fall-back to the system
    store, which would fail the handshake with a sentence about the server.

    2026-08-19 -- this used to be a private third trust store.  It knew ONE
    path (``backend/certs/tls_bundle.pem``) and never merged certifi, while
    ``core.ssl_config`` -- which DuckDB/httpfs, boto3, pyiceberg and the REST
    connector all use -- scans seven field-observed spellings (including the
    helm ``tls-ca-bundle.pem`` and ``/usr/local/querystudioapi/certs/...``),
    honours ``QS_CA_BUNDLE_PATH``, and merges certifi into any operator
    bundle.

    That divergence produced PARTIAL failures on a single connection, which
    is the worst shape to debug: a hybrid Starburst+S3 report where the S3
    half validated and the Trino half did not, or the inverse -- an operator
    bundle carrying only corp CAs handed raw to the Trino client, so a
    Starburst Galaxy endpoint on a public CA failed while every ssl_config
    consumer succeeded.  This was already recorded once as
    "Starburst SSL: 3 client stacks, 3 DIFFERENT CA stores" (2026-08-07).

    It also fixes the capital-T string: ``"True"`` matched neither branch and
    was returned as an "explicit path", so requests raised
    ``Could not find a suitable TLS CA certificate bundle, invalid path: True``.
    """
    try:
        from core.ssl_config import as_boto3_verify, bundle_for_pem, resolve_ssl
        # as_boto3_verify yields exactly what requests wants: False, True, or
        # a path to a bundle -- the same union the trino client accepts.
        resolution = resolve_ssl(val)
        if resolution.enabled and str(ca_cert_pem or "").strip():
            return bundle_for_pem(str(ca_cert_pem))
        return as_boto3_verify(resolution)
    except ValueError:
        raise                       # the pasted CA is not a certificate: say so
    except Exception as exc:  # pragma: no cover - import-time safety net
        logger.warning(
            "shared SSL resolver unavailable (%s); falling back to the "
            "local bundle check", exc)
        if val is False:
            return False
        if val is True or (isinstance(val, str) and val.lower() == "true"):
            return str(_DEFAULT_CA_BUNDLE) if _DEFAULT_CA_BUNDLE.exists() else True
        if isinstance(val, str) and val.lower() == "false":
            return False
        return val  # explicit path


#: Iceberg partition TRANSFORMS.  ``partitioning = ARRAY['day(ts)']`` names
#: the transform, and the COLUMN is its first argument -- so a naive parse
#: yields "day(ts)", which matches no column and silently disables pruning.
#: ``truncate``/``bucket`` take a second numeric argument.
_ICEBERG_TRANSFORM_RE = re.compile(
    r"^\s*(year|month|day|hour|bucket|truncate|identity|void)\s*\(\s*"
    r"([^,)]+?)\s*(?:,[^)]*)?\)\s*$",
    re.IGNORECASE,
)


def _strip_iceberg_transform(token: str) -> str:
    """``day(ts)`` -> ``ts``; ``bucket(id, 16)`` -> ``id``; plain -> plain.

    Quotes are stripped FIRST: the DDL renders each entry as ``'day(ts)'``,
    and a leading quote makes the transform pattern miss, which silently
    returned the whole expression as if it were a column name.
    """
    s = token.strip().strip("'\"").strip()
    m = _ICEBERG_TRANSFORM_RE.match(s)
    if m:
        return m.group(2).strip().strip("'\"")
    return s


def _split_partition_specs(body: str) -> List[str]:
    """Split an ARRAY[...] body on TOP-LEVEL commas only.

    ``bucket(id, 16)`` contains a comma; a plain ``split(",")`` cut it into
    ``bucket(id`` and ``16)`` and produced two bogus partition columns.
    """
    out: List[str] = []
    depth = 0
    cur: List[str] = []
    for ch in body:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        if ch == "," and depth == 0:
            out.append("".join(cur))
            cur = []
            continue
        cur.append(ch)
    out.append("".join(cur))
    return [s for s in (t.strip() for t in out) if s]


def _parse_trino_partitions(ddl: str) -> List[str]:
    """Extract partition column names from Trino/Starburst CREATE TABLE DDL.

    Supports:
      - PARTITIONED BY (ARRAY['col1', 'col2'])
      - WITH (partitioned_by = ARRAY['col1', 'col2'])      -- HIVE connector
      - WITH (partitioning  = ARRAY['col1', 'day(ts)'])    -- ICEBERG connector
      - PARTITIONED BY (col1, col2)

    2026-08-13 -- ``partitioning`` and transform-stripping were both
    MISSING, and either one silently returns [] rather than failing.  Trino's
    ICEBERG connector spells the property ``partitioning``, not
    ``partitioned_by``, so an Iceberg table on Starburst detected NO partition
    columns at all; and an Iceberg partition spec is commonly written as a
    transform (``day(event_ts)``, ``bucket(id, 16)``) whose column name is the
    ARGUMENT -- returning the literal "day(event_ts)" matches no column, so
    pruning stays off and the BQB partition filter never appears.
    """
    # Format 1: PARTITIONED BY (ARRAY['col1', 'col2'])
    m = re.search(r"PARTITIONED\s+BY\s*\(\s*ARRAY\s*\[([^\]]+)\]", ddl, re.IGNORECASE)
    if m:
        return [_strip_iceberg_transform(c) for c in _split_partition_specs(m.group(1))]

    # Format 2: WITH (partitioned_by = ARRAY[...])   -- Hive
    # Format 2b: WITH (partitioning  = ARRAY[...])   -- Iceberg
    # ``partitioning`` is matched with its own alternation rather than a
    # prefix, so ``partitioned_by`` cannot be shadowed by it.
    m = re.search(r"\b(?:partitioned_by|partitioning)\s*=\s*ARRAY\s*\[([^\]]+)\]",
                  ddl, re.IGNORECASE)
    if m:
        return [_strip_iceberg_transform(c) for c in _split_partition_specs(m.group(1))]

    # Format 3: PARTITIONED BY (col1, col2) — plain column names
    m = re.search(r"PARTITIONED\s+BY\s*\(([^)]+)\)", ddl, re.IGNORECASE)
    if m:
        # Exclude ARRAY keyword patterns (already handled above)
        body = m.group(1).strip()
        if not body.upper().startswith("ARRAY"):
            return [_strip_iceberg_transform(c) for c in _split_partition_specs(body)]

    return []


def _spawn_stats_poller(connector, cur, stop_event) -> None:
    """BF-TRINO-STATUS: poll ``cur.stats`` every 5s and push coordinator
    state to the per-execution stage tracker.

    2026-08-22 — extracted VERBATIM from ``execute_query_streaming``'s
    inline ``_status_loop`` so the rung-1 unload path (``unload_to_s3``)
    reports the same coordinator state without a second copy of the
    loop.  No-op when the connector carries no ``_qs_execution_id`` or
    the stage tracker is unavailable.  The thread exits when
    ``stop_event`` is set.
    """
    import threading as _th

    def _status_loop():
        _exec_id = getattr(connector, "_qs_execution_id", None)
        if not _exec_id:
            return
        try:
            from core.execution_stage import update_progress as _upd
        except Exception:
            return
        _last_msg = ""
        while not stop_event.is_set():
            try:
                stats = getattr(cur, "stats", None)
                if stats and isinstance(stats, dict):
                    _state = stats.get("state", "UNKNOWN")
                    _qid   = stats.get("queryId", "")
                    _csp   = int(stats.get("completedSplits") or 0)
                    _tsp   = int(stats.get("totalSplits") or 0)
                    _rows  = int(stats.get("processedRows") or 0)
                    _bytes = int(stats.get("processedBytes") or 0)
                    _elap  = int(stats.get("elapsedTimeMillis") or 0) // 1000
                    _peak  = int(stats.get("peakUserMemoryBytes") or 0)
                    _peak_mb = _peak / (1024 * 1024) if _peak else 0
                    _bytes_mb = _bytes / (1024 * 1024) if _bytes else 0
                    msg = (
                        f"Trino {_state}"
                        + (f" qid={_qid[:8]}" if _qid else "")
                        + (f" splits={_csp}/{_tsp}" if _tsp else "")
                        + (f" rows={_rows:,}" if _rows else "")
                        + (f" bytes={_bytes_mb:.0f}MB" if _bytes else "")
                        + (f" peak={_peak_mb:.0f}MB" if _peak_mb else "")
                        + (f" elapsed={_elap}s" if _elap else "")
                    )
                    if msg != _last_msg:
                        _last_msg = msg
                        try:
                            # 2026-09-01 — ``files_total`` does not exist
                            # on update_progress (keyword-only: files_done /
                            # files_delta / bytes_* / rows_done / message /
                            # log; ``set_stage`` is what takes a total).  So
                            # every tick of this loop raised TypeError and
                            # note_best_effort swallowed it: Starburst /
                            # Trino queries reported NO live progress at all
                            # — no splits, no rows, no bytes — while the
                            # status thread ran happily every 5s.
                            #
                            # The split total is not lost: ``msg`` already
                            # carries "splits=<done>/<total>".
                            _upd(_exec_id, message=msg, files_done=_csp,
                                 bytes_done=_bytes)
                        except Exception as _be_exc:
                            note_best_effort("_upd(...)", _be_exc,
                                             logger=logger)
            except Exception as _be_exc:
                note_best_effort("_upd(...)", _be_exc,
                                 logger=logger)
            stop_event.wait(5.0)
    _th.Thread(target=_status_loop, name="qs-trino-status", daemon=True).start()


class TrinoConnector(SqlConnector):
    """Connector for Trino / Starburst Enterprise / Starburst Galaxy."""

    #: 2026-09-16 — audited for reuse.  Instance state is ``_conn`` plus
    #: ``_last_ok``, and the second is a LIVENESS timestamp about the
    #: connection rather than about the caller: ``_get_connection`` pings
    #: ``SELECT 1`` and transparently reconnects when the cached session has
    #: gone stale, which is exactly the validation a pool wants and which
    #: this connector already did for itself.  No SET SESSION, no
    #: transaction, no temp object.  Cursors are per call.
    POOL_SAFE = True

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._conn = None

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _get_connection(self):
        if self._conn is not None:
            # Liveness check — reuse only if the cached connection is still alive
            # 2026-08-19 -- THROTTLE THIS.  It ran a full `SELECT 1`
            # round-trip to the coordinator on EVERY _cursor() call: every
            # query, every DESCRIBE, every partition-value lookup.  In the
            # partition-values loop that is an N+1 of coordinator
            # round-trips, and the column-type resolution added today makes
            # one more per query.
            #
            # Safe to skip because execute_query already detects a dead
            # connection (_is_connection_error) and retries once on a fresh
            # one -- the ping was belt-and-braces on a mechanism that
            # already handles the failure.  Idle connections still get it.
            import time as _t
            if (_t.monotonic() - getattr(self, "_last_ok", 0.0)
                    < _PING_MAX_AGE_SECONDS):
                return self._conn
            try:
                ping = self._conn.cursor()
                try:
                    ping.execute("SELECT 1")
                    ping.fetchone()
                finally:
                    ping.close()
                self._last_ok = _t.monotonic()
                return self._conn
            except Exception:
                logger.info("Trino cached connection stale — reconnecting")
                try:
                    self._conn.close()
                except Exception as _be_exc:
                    note_best_effort("self._conn.close()", _be_exc,
                                     logger=logger)
                self._conn = None
        try:
            import trino
            from trino.auth import BasicAuthentication, JWTAuthentication
        except ImportError:
            raise DriverNotInstalled(
                "trino",
                "trino package is not installed. "
                "Add 'trino' to requirements.txt and restart the backend."
            )

        host       = self.config["host"]
        port       = int(self.config.get("port", 443))
        user       = self.config.get("user", "query_studio")
        auth_type  = self.config.get("auth_type", "none").lower()
        http_scheme = self.config.get("http_scheme", "https")
        verify_ssl = _resolve_ssl_verify(self.config.get("verify_ssl", True),
                                         self.config.get("ca_cert_pem"))
        roles      = _roles_for(self.config)
        catalog    = self.config.get("catalog")
        schema     = self.config.get("schema")
        extra_hdr  = self.config.get("extra_headers", {}) or {}
        session_p  = self.config.get("session_props", {}) or {}

        # 2026-08-19 -- the module docstring has always advertised
        # "basic | jwt | kerberos | oauth2 | none", but only basic and jwt
        # were implemented.  Every other spelling fell through to auth=None,
        # so a Kerberos-configured connection connected ANONYMOUSLY and
        # failed with a bare 401 -- with nothing anywhere saying the config
        # had been accepted and ignored.  The trino client ships all of
        # these; wire them, and make an unknown mode a loud error rather
        # than a silent downgrade to unauthenticated.
        auth = None
        if auth_type == "basic":
            auth = BasicAuthentication(user, self.config.get("password", ""))
        elif auth_type in ("jwt", "bearer"):
            auth = JWTAuthentication(self.config.get("token", ""))
        elif auth_type == "kerberos":
            from trino.auth import KerberosAuthentication
            kerb_kwargs = {}
            if self.config.get("kerberos_service_name"):
                kerb_kwargs["service_name"] = self.config["kerberos_service_name"]
            if self.config.get("kerberos_principal"):
                kerb_kwargs["principal"] = self.config["kerberos_principal"]
            if self.config.get("kerberos_config"):
                kerb_kwargs["config"] = self.config["kerberos_config"]
            auth = KerberosAuthentication(**kerb_kwargs)
        elif auth_type == "oauth2":
            from trino.auth import OAuth2Authentication
            auth = OAuth2Authentication()
        elif auth_type == "certificate":
            from trino.auth import CertificateAuthentication
            auth = CertificateAuthentication(
                self.config.get("cert"), self.config.get("key"))
        elif auth_type not in ("none", ""):
            raise ValueError(
                f"Unsupported Trino auth_type '{auth_type}'. Supported: "
                f"basic, jwt, bearer, kerberos, oauth2, certificate, none. "
                f"Refusing to connect ANONYMOUSLY with an auth_type that was "
                f"configured but not understood."
            )

        from core.ssl_config import session_keeping_verify
        kwargs = dict(
            host=host,
            port=port,
            user=user,
            auth=auth,
            http_scheme=http_scheme,
            verify=verify_ssl,
            # 2026-11-04: the driver's own session lets a process-wide CA variable beat this.
            http_session=session_keeping_verify(verify_ssl),
            http_headers=extra_hdr,
            session_properties=session_p,
        )
        if catalog:
            kwargs["catalog"] = catalog
        if schema:
            kwargs["schema"] = schema
        if roles:
            # X-Trino-Role: system=ROLE{..},<catalog>=ROLE{..}; the cluster
            # validates it on EVERY statement, so a role the user was not
            # granted is its own verdict ("Cannot set role ...").
            kwargs["roles"] = roles

        self._conn = trino.dbapi.connect(**kwargs)
        import time as _t2
        self._last_ok = _t2.monotonic()
        return self._conn

    def _cursor(self):
        return self._get_connection().cursor()

    def _fetchall_as_dicts(self, cursor) -> List[Dict[str, Any]]:
        desc = cursor.description or []
        col_names = unique_column_names(d[0] for d in desc)
        return [dict(zip(col_names, row)) for row in cursor.fetchall()]

    # ── Connection lifecycle ─────────────────────────────────────────────────

    @_reconnect_once
    def test_connection(self) -> Dict[str, Any]:
        cur = None
        try:
            cur = self._cursor()
            cur.execute("SELECT 1")
            cur.fetchone()
            # current_version() is Starburst-only; version() works on both
            # Trino and Starburst. Fall back gracefully if neither is available.
            try:
                cur.execute("SELECT version()")
                row = cur.fetchone()
                version = row[0] if row else "unknown"
            except Exception:
                version = "unknown"
            return {
                "success": True,
                "message": f"Connected to Trino/Starburst version {version}",
                "details": {"version": version, "host": self.config.get("host")},
            }
        except Exception as e:
            logger.exception("Trino test_connection failed")
            return self._test_failure(e)
        finally:
            if cur:
                cur.close()

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception as exc:
                logging.getLogger(__name__).warning("%s failed: %s", "trino_connector", exc, exc_info=True)
            self._conn = None

    # ── Schema browsing ──────────────────────────────────────────────────────

    @_reconnect_once
    def list_catalogs(self) -> List[str]:
        cur = self._cursor()
        try:
            cur.execute("SHOW CATALOGS")
            return [row[0] for row in cur.fetchall()]
        finally:
            cur.close()

    @_reconnect_once
    def list_schemas(self, catalog: str) -> List[str]:
        cur = self._cursor()
        try:
            cur.execute(f"SHOW SCHEMAS FROM {_qi(catalog)}")
            return [row[0] for row in cur.fetchall()]
        finally:
            cur.close()

    @_reconnect_once
    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        cur = self._cursor()
        try:
            cur.execute(f"SHOW TABLES FROM {_qi(catalog)}.{_qi(schema)}")
            return [
                {"name": row[0], "type": "TABLE", "catalog": catalog, "schema": schema}
                for row in cur.fetchall()
            ]
        finally:
            cur.close()

    @_reconnect_once
    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        cur = self._cursor()
        try:
            cur.execute(f"DESCRIBE {_qi(catalog)}.{_qi(schema)}.{_qi(table)}")
            rows = cur.fetchall()
            # Trino DESCRIBE: Column, Type, Extra, Comment
            return [
                {"name": r[0], "type": r[1], "nullable": True, "ordinal": i}
                for i, r in enumerate(rows)
            ]
        finally:
            cur.close()

    # ── Partition detection ────────────────────────────────────────────────────

    @_reconnect_once
    def detect_partitions(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """Detect partition columns via SHOW CREATE TABLE DDL parsing."""
        cur = self._cursor()
        try:
            cur.execute(f"SHOW CREATE TABLE {_qi(catalog)}.{_qi(schema)}.{_qi(table)}")
            ddl = cur.fetchone()[0]
            partition_cols = _parse_trino_partitions(ddl)
            if not partition_cols:
                return []

            # Get column types for the partition columns
            cur.execute(f"DESCRIBE {_qi(catalog)}.{_qi(schema)}.{_qi(table)}")
            col_types = {r[0]: r[1] for r in cur.fetchall()}

            return [
                {"name": p, "type": col_types.get(p, "string"), "transform": "identity"}
                for p in partition_cols
            ]
        except Exception:
            # 2026-08-19 -- WARNING, not DEBUG.  This returns the same empty
            # list for "the table is not partitioned" and "we could not find
            # out" (no privilege on SHOW CREATE TABLE, catalog unreachable),
            # and the consequence of the second is invisible: the query
            # builder never prompts for a partition filter, so every query on
            # a large partitioned table silently becomes a full scan.  Keep
            # failing OPEN -- partition detection must not block browsing --
            # but say so where an operator will see it.
            logger.warning(
                "detect_partitions failed for %s.%s.%s -- treating the table "
                "as UNPARTITIONED, so no partition filter will be offered and "
                "queries may full-scan it",
                catalog, schema, table, exc_info=True)
            return []
        finally:
            cur.close()

    # ── Query execution ──────────────────────────────────────────────────────

    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        sql = self._apply_limit(sql, limit)
        for attempt in range(2):
            cur = self._cursor()
            try:
                cur.execute(sql)
                desc = cur.description or []
                col_info = [{"name": n, "type": str(d[1])} for n, d in zip(unique_column_names(d[0] for d in desc), desc)]
                rows_raw = cur.fetchall()
                col_names = unique_column_names(d[0] for d in desc)
                rows = [dict(zip(col_names, row)) for row in rows_raw]
                return {"columns": col_info, "rows": rows, "total_rows": len(rows)}
            except Exception as exc:
                cur.close()
                # On first attempt, if it looks like a connection error, reset and retry
                if attempt == 0 and self._is_connection_error(exc):
                    logger.warning("Trino execute_query connection error, retrying: %s", exc)
                    self._conn = None
                    continue
                raise
            finally:
                try:
                    cur.close()
                except Exception as _be_exc:
                    note_best_effort("cur.close()", _be_exc,
                                     logger=logger)
        raise RuntimeError("Trino execute_query failed after retry")

    # ── Write ladder rung 1: engine-side unload (2026-08-22) ─────────────────

    def write_capabilities(self) -> Dict[str, Any]:
        """Declare rung-1 (engine-side write) eligibility.

        The per-CONNECTION declaration IS the opt-in (vault-resolver
        rule): all three of ``unload_scratch_catalog``,
        ``unload_scratch_schema`` and ``unload_s3_location`` must be set
        on the connection config, or nothing is declared and the write
        ladder floors to native streaming — UNKNOWN = UNSAFE, and a
        half-configured connection is UNKNOWN, not "probably fine".

        Secrets never enter this dict: it is stamped verbatim into the
        execution record's write-ladder audit.
        """
        scratch_catalog = str(self.config.get("unload_scratch_catalog") or "").strip()
        scratch_schema = str(self.config.get("unload_scratch_schema") or "").strip()
        s3_location = str(self.config.get("unload_s3_location") or "").strip()
        if not (scratch_catalog and scratch_schema and s3_location):
            return {}
        return {
            "engine_write": {
                "scratch_catalog": scratch_catalog,
                "scratch_schema": scratch_schema,
                "s3_location": s3_location,
                "s3_access_configured": bool(self.config.get("unload_s3_access")),
            }
        }

    _UNLOAD_TABLE_RE = re.compile(r"^[a-z][a-z0-9_]{0,127}$")

    def unload_to_s3(
        self,
        sql: str,
        *,
        s3_location: str,
        scratch_catalog: str,
        scratch_schema: str,
        table_name: str,
        cancel_event=None,
        writer_session: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Rung 1: the CLUSTER writes the result as parquet parts to S3.

        ``writer_session`` (2026-10-12, ``engine_unload.writer_session_for``):
        parquet-writer session properties of the SCRATCH catalog, set on this
        cursor's session before the CTAS -- a 460-column write at the
        engine's default buffer sizes exceeds a node's memory.

        Issues a Hive-connector CTAS with an ``external_location``::

            CREATE TABLE "cat"."schema"."tbl"
            WITH (external_location = 's3a://…/tbl/', format = 'PARQUET')
            AS <sql>

        The statement's result row (Trino returns the written row count)
        is the SOURCE-rows figure the caller must reconcile the S3
        footers against before certifying anything.  ``sql`` must arrive
        ALREADY row-secured — this method embeds it verbatim, which is
        exactly how RLS survives the pushed-down write (asserted by the
        rung-1 tests on the generated text).

        Cleanup is the CALLER's contract via :meth:`drop_scratch_table`
        (call it in a ``finally`` — a scratch table left behind after a
        failure is garbage in the customer's catalog).  This method
        itself drops nothing on success: the external data must survive
        the drop, and listing/verification happens between the two.

        Cancel: same coordinator-side ``cur.cancel()`` watchdog as the
        streaming path — an abandoned CTAS burning cluster time is
        someone else's money.
        """
        import threading as _th

        for label, ident in (("scratch_catalog", scratch_catalog),
                             ("scratch_schema", scratch_schema)):
            if not str(ident or "").strip():
                raise ValueError(f"unload_to_s3: {label} is required")
        if not self._UNLOAD_TABLE_RE.match(table_name or ""):
            raise ValueError(
                f"unload_to_s3: scratch table name {table_name!r} must match "
                f"{self._UNLOAD_TABLE_RE.pattern} (it is interpolated into DDL)")
        loc = str(s3_location or "").strip()
        if not re.match(r"^s3a?://[^/]+", loc):
            raise ValueError(
                f"unload_to_s3: s3_location must be s3://bucket/... or "
                f"s3a://bucket/... — got {loc!r}")
        external_location = loc.rstrip("/") + "/" + table_name + "/"
        table_fqn = f"{_qi(scratch_catalog)}.{_qi(scratch_schema)}.{_qi(table_name)}"
        # external_location is a SQL string literal — escape single quotes.
        _loc_lit = external_location.replace("'", "''")
        ctas_sql = (
            f"CREATE TABLE {table_fqn}\n"
            f"WITH (\n"
            f"  external_location = '{_loc_lit}',\n"
            f"  format = 'PARQUET'\n"
            f") AS\n"
            f"{sql}"
        )

        cur = self._cursor()
        for _prop, _val in (writer_session or {}).items():
            if (not re.match(r"^[a-z_]+$", str(_prop))
                    or not re.match(r"^\d+(B|kB|MB|GB)$", str(_val))):
                raise ValueError(f"unload_to_s3: writer session {_prop}={_val!r} refused")
            cur.execute(f"SET SESSION {_qi(scratch_catalog)}.{_prop} = '{_val}'")
            cur.fetchall()
        if writer_session:
            logger.info("[write-ladder] rung1 writer sizing on %s: %s",
                        scratch_catalog, writer_session)
        _stop = _th.Event()
        if cancel_event is not None:
            def _cancel_ctas():
                _qid = _trino_query_id(cur)
                try:
                    cur.cancel()
                    note_cancel(cancel_event, "trino", reached=True,
                                statement=_qid,
                                detail="the CTAS was cancelled at the coordinator")
                except Exception as _be_exc:
                    note_best_effort("cur.cancel()", _be_exc,
                                     logger=logger)
                    note_cancel(cancel_event, "trino", reached=False,
                                statement=_qid,
                                detail=f"cur.cancel() failed: {_be_exc}")

            def _wd():
                _cancel_when_known(cur, cancel_event, _stop, _cancel_ctas)
            _th.Thread(target=_wd, name="qs-trino-unload-cancel",
                       daemon=True).start()
        _spawn_stats_poller(self, cur, _stop)
        _completed = False
        try:
            _refuse_if_cancelled(cancel_event, "the unload")
            cur.execute(ctas_sql)
            if cancel_event is not None and cancel_event.is_set():
                raise InterruptedError("unload cancelled by user")
            row = cur.fetchone()
            # Trino's CTAS result is one row: the count of rows written.
            if row is None or row[0] is None:
                raise RuntimeError(
                    "unload_to_s3: CTAS returned no row count — cannot "
                    "verify the write; refusing to treat it as success")
            rows_reported = int(row[0])
            stats = getattr(cur, "stats", None) or {}
            query_id = str(stats.get("queryId") or "")
            _completed = True
            logger.info(
                "[write-ladder] rung1 CTAS complete: table=%s rows=%d "
                "query_id=%s location=%s",
                table_fqn, rows_reported, query_id, external_location,
            )
            return {
                "rows_reported": rows_reported,
                "query_id": query_id,
                "table_fqn": table_fqn,
                "external_location": external_location,
                "ctas_sql": ctas_sql,
            }
        finally:
            if not _completed:
                # Abandoned/failed CTAS: cancel at the coordinator first —
                # same contract as the streaming path's abandon handler.
                try:
                    cur.cancel()
                except Exception as _cxl_exc:
                    logger.debug("unload cancel on failure: %s", _cxl_exc)
            _stop.set()
            try:
                cur.close()
            except Exception as _be_exc:
                note_best_effort("cur.close()", _be_exc,
                                 logger=logger)

    def drop_scratch_table(self, table_fqn: str) -> None:
        """Drop a CTAS scratch table.  For a Hive EXTERNAL table the S3
        data survives the drop — that is the whole point: the catalog
        entry disappears, the parts remain for QS to list and publish.
        Raises on failure — a scratch table we could not drop is garbage
        in the CUSTOMER's catalog and the caller must know."""
        cur = self._cursor()
        try:
            cur.execute(f"DROP TABLE IF EXISTS {table_fqn}")
            try:
                cur.fetchall()
            except Exception as _be_exc:
                note_best_effort("cur.fetchall()", _be_exc,
                                 logger=logger)
        finally:
            try:
                cur.close()
            except Exception as _be_exc:
                note_best_effort("cur.close()", _be_exc,
                                 logger=logger)

    def execute_query_streaming(
        self,
        sql: str,
        chunk_size: int = 1000,
        limit: Optional[int] = None,
        cancel_event=None,
    ):
        """Phase 139 (Tier 2.1) — cursor-based streaming via fetchmany.

        BF-262 follow-up: ``cancel_event`` watchdog calls ``cur.cancel()``
        (Trino-python) which sends a query-cancel to the Trino coordinator,
        aborting the running plan.

        BF-TRINO-STATUS: a second background thread polls ``cur.stats`` (the
        Trino REST stats blob — state, queued/running splits, processed rows,
        elapsed CPU time, peak memory) every 5s while the query is running
        and pushes the summary to the per-execution stage tracker so the
        QueryStudio heartbeat / per-query log shows ACTUAL coordinator state
        instead of "running for 6 minutes".  No-op for connectors / cursors
        that don't expose .stats.
        """
        import threading as _th
        sql = self._apply_limit(sql, limit)
        cur = self._cursor()
        _stop = _th.Event()
        # ONE cancel, ONE note: the watchdog OR the stream's own early exit
        # (the loop sees the event between fetches) -- whichever gets there
        # first cancels and records it.  The early exit used to cancel
        # without a note and stop the watchdog before it wrote one.
        _cancel_lock = _th.Lock()
        _cancelled = [False]

        def _cancel_and_note() -> None:
            with _cancel_lock:
                if _cancelled[0]:
                    return
                _cancelled[0] = True
            # 2026-10-26 -- what the cancel reached is RECORDED on the run
            # (core/cancel_scope.py::note_cancel): the coordinator was told,
            # or it was not.
            _qid = _trino_query_id(cur)
            try:
                cur.cancel()
                note_cancel(cancel_event, "trino", reached=True,
                            statement=_qid,
                            detail="cancelled at the coordinator")
            except Exception as _be_exc:
                note_best_effort("cur.cancel()", _be_exc,
                                 logger=logger)
                note_cancel(cancel_event, "trino", reached=False,
                            statement=_qid,
                            detail=f"cur.cancel() failed: {_be_exc}")

        if cancel_event is not None:
            def _wd():
                _cancel_when_known(cur, cancel_event, _stop, _cancel_and_note)
            _th.Thread(target=_wd, name="qs-trino-cancel", daemon=True).start()

        # ── BF-TRINO-STATUS: poll cursor.stats and push to stage tracker ────
        # Trino-python's BasicCursor exposes .stats as a dict after execute()
        # (and even during execute via the running statement context).
        # execution_id is set on the connector instance via set_execution_id()
        # by the caller (execute_sql_connector_background) before this is
        # invoked.  ContextVar wouldn't propagate to worker pool threads.
        # 2026-08-22 — loop body extracted to _spawn_stats_poller (module
        # level) so the rung-1 unload path reports the same coordinator
        # state without a second copy.
        _spawn_stats_poller(self, cur, _stop)

        _drained = False
        try:
            _refuse_if_cancelled(cancel_event, "the statement")
            cur.execute(sql)
            desc = cur.description or []
            col_info = [{"name": n, "type": str(d[1])} for n, d in zip(unique_column_names(d[0] for d in desc), desc)]
            col_names = unique_column_names(d[0] for d in desc)
            yielded_any = False
            while True:
                if cancel_event is not None and cancel_event.is_set():
                    break
                batch = cur.fetchmany(chunk_size)
                if not batch:
                    break
                yielded_any = True
                yield col_info, [dict(zip(col_names, row)) for row in batch]
            if not yielded_any:
                yield col_info, []
            _drained = True
        finally:
            # 2026-08-21 — CANCEL AT THE COORDINATOR ON ANY EARLY EXIT.
            #
            # Operator: two count queries still burning coordinator time after
            # the UI had already errored, and the same on an explicit Cancel.
            #
            # This block used to do `_stop.set()` then `cur.close()`.  Both are
            # wrong for an abandoned query:
            #   * _stop.set() kills the cancel WATCHDOG — the only thing that
            #     ever called cur.cancel() — and it polls every 0.5s, so an
            #     abort usually beat it to the punch;
            #   * cur.close() is not a cancel.  Trino keeps executing the
            #     statement server-side.
            # So a consumer that stopped reading (user cancel, a write-side
            # failure, GeneratorExit on GC) left the source running to
            # completion.  A client-side bug that burns someone else's cluster.
            #
            # Cancel FIRST, then stop the watchdog, then close.  Only when the
            # result set was NOT drained — a completed query needs no cancel and
            # cancelling it would be a pointless coordinator round trip.
            if not _drained and cancel_event is not None and cancel_event.is_set():
                _cancel_and_note()                 # the run's cancel: cancel + record
            elif not _drained:
                try:
                    cur.cancel()
                    logger.info(
                        "Trino: result set abandoned before completion — "
                        "cancelled the query at the coordinator")
                except Exception as _cxl_exc:
                    logger.debug("Trino cancel on abandon failed: %s", _cxl_exc)
            _stop.set()
            try:
                cur.close()
            except Exception as _be_exc:
                note_best_effort("cur.close()", _be_exc,
                                 logger=logger)

    @staticmethod
    def _is_connection_error(exc: Exception) -> bool:
        """Detect connection-level errors that warrant a retry with a fresh connection."""
        msg = str(exc).lower()
        return any(k in msg for k in (
            "connection refused", "connection reset", "connection abort",
            "broken pipe", "eof", "timed out", "timeout",
            "server disconnected", "connection closed",
        ))
