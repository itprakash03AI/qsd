"""
Generic REST API data source connector.

Allows QueryStudio to pull tabular data from any HTTP/REST endpoint
(Salesforce, Jira, internal microservices, etc.) as a data source.

Supports:
    - Auth: none, basic, bearer token, API key (header/query), OAuth2 client credentials
    - Pagination: none, offset, cursor, link_header, page_number
    - JSON response flattening to tabular rows/columns
    - Rate limiting (token bucket)
    - Configurable timeout and SSL verification
"""
from __future__ import annotations

import json
import logging
import re
import time
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

# Module-level ON PURPOSE, even though the SSRF check below also imports
# them locally: tests/test_ssrf_protection.py patches
# ``core.connectors.rest_api_connector.socket.getaddrinfo``, and that patch
# target only resolves if this module exposes ``socket`` as an attribute.
# A lint sweep removed these as "unused" on 2026-08-17 and all seven SSRF
# tests broke with "module has no attribute 'socket'" -- the protection code
# still ran, but the tests that PROVE it could no longer reach it.
import ipaddress  # noqa: F401 -- SSRF test patch target
import socket     # noqa: F401 -- SSRF test patch target


import requests

from .base import SqlConnector

logger = logging.getLogger(__name__)

# ── Config defaults ──────────────────────────────────────────────────────────
_DEFAULT_TIMEOUT = 30          # rest_api.default_timeout_seconds
_MAX_TIMEOUT = 300             # rest_api.max_timeout_seconds (0 = unlimited)
_DEFAULT_RATE_LIMIT = 10       # requests per second
_MAX_PAGES = 500               # default runaway-pagination guard (rest_api.max_pages)


def _resolve_timeout(configured) -> int:
    """The request timeout for ONE connection, clamped by the deployment.

    2026-09-15 -- three ``rest_api`` keys shipped, were rendered in the admin
    screen, and were read by NOTHING: ``default_timeout_seconds`` (30),
    ``max_timeout_seconds`` (300) and ``flatten_max_depth`` (5).  The
    connector used module constants with the same values, so an operator who
    changed any of them in the UI saw the new number saved, displayed, and
    ignored.  A knob that moves nothing is worse than no knob: it answers the
    question "is there a ceiling on REST calls?" with "yes, 300s" when the
    real answer was "no, a connection may hold a worker for as long as it
    likes".

    The inline fallbacks below are the DECLARED defaults, deliberately --
    core/config.py:1262 requires it and an AST guard enforces it for the
    iceberg section.  So wiring these keys changes nothing in a deployment
    that has not touched them; it only makes the ones that HAVE touched them
    take effect.

    0 = UNLIMITED on the ceiling (the product-wide rule).  A cap read as
    "refuse everything" is the LIMIT 0 defect this codebase has paid for
    twice; here it would make every REST call time out instantly.
    """
    try:
        from core.config import get as _get
        default_s = int(_get("rest_api", "default_timeout_seconds", _DEFAULT_TIMEOUT))
        max_s = int(_get("rest_api", "max_timeout_seconds", _MAX_TIMEOUT))
    except Exception:                                   # pragma: no cover
        default_s, max_s = _DEFAULT_TIMEOUT, _MAX_TIMEOUT
    # `or default_s` is correct here and not the 0-folding bug: a timeout of
    # zero seconds is not "unlimited", it is "fail immediately", and no
    # connection means it.
    timeout = int(configured or default_s)
    if timeout <= 0:
        timeout = default_s
    if max_s > 0 and timeout > max_s:
        logger.warning(
            "[rest] connection timeout %ss exceeds the deployment ceiling "
            "rest_api.max_timeout_seconds=%ss — clamped", timeout, max_s)
        timeout = max_s
    return timeout


def _flatten_max_depth() -> int:
    """``rest_api.flatten_max_depth``; the module constant is the fallback
    and carries the same value, so this is inert until an operator moves it.
    A depth of 0 means "do not descend at all", which is a meaningful
    setting, so it is NOT read as unlimited."""
    try:
        from core.config import get as _get
        depth = int(_get("rest_api", "flatten_max_depth", _MAX_FLATTEN_DEPTH))
    except Exception:                                   # pragma: no cover
        return _MAX_FLATTEN_DEPTH
    return max(0, depth)


def _max_response_bytes() -> int:
    """``rest_api.max_response_size_mb`` in bytes; 0/absent = no cap."""
    try:
        from core.config import get as _get
        return int(_get("rest_api", "max_response_size_mb", 50) or 0) * 1024 * 1024
    except Exception:                                   # pragma: no cover
        return 50 * 1024 * 1024


def _enforce_response_size(resp, url: str) -> None:
    """Refuse a response bigger than the configured cap.

    2026-09-16 -- ``rest_api.max_response_size_mb`` (default 50) was READ ONLY
    BY THE ADMIN SCREEN.  Nothing in this connector checked a size, so every
    response went straight into ``resp.json()`` and into the API pod's heap:
    a declared OOM guard that did not exist, on a surface that fetches from
    hosts the operator does not control.

    ``Content-Length`` is the cheap check and covers the ordinary case.  A
    chunked response has none, and ``requests`` has already buffered the body
    by the time we are here, so the length of what arrived is the honest
    second test -- it cannot prevent that one allocation, but it stops the
    rows being parsed, multiplied into Python objects and paged N more times.
    Refusing beats truncating: a silently short page would be reported as the
    whole answer.
    """
    cap = _max_response_bytes()
    if cap <= 0:
        return
    declared = resp.headers.get("content-length")
    size = None
    if declared:
        try:
            size = int(declared)
        except (TypeError, ValueError):
            size = None
    if size is None:
        try:
            size = len(resp.content or b"")
        except Exception:                               # pragma: no cover
            return
    if size > cap:
        raise ValueError(
            f"REST response from {url} is {size / 1048576:.1f} MB, over the "
            f"{cap / 1048576:.0f} MB limit (rest_api.max_response_size_mb). "
            f"Narrow the query, add pagination, or raise the limit.")


class RestPaginationExhausted(RuntimeError):
    """The page guard tripped while the endpoint was STILL returning rows.

    2026-08-17: this used to be a silent ``break`` -- the connector returned a
    partial result with no marker and the caller reported SUCCESS.  A
    runaway-guard is a CORRECTNESS gate, not a throttle: if we cannot finish
    the read we must say so, not hand back a truncated answer that looks whole.
    """
_MAX_FLATTEN_DEPTH = 5


class _PageBudget:
    """Shared paging bookkeeping for the four pagination styles.

    2026-08-17/20 -- ``max_rows=None`` means UNLIMITED and a page guard of
    0 means no guard; neither may fold into a silent cap.  Kept in ONE
    object so the four styles share one definition of "room left" and
    "guard still open" rather than four copies that can drift apart.
    """

    def __init__(self, max_rows: Optional[int], page_guard: int):
        self.max_rows = max_rows
        self.page_guard = page_guard
        self.rows: List[dict] = []
        self.page = 0

    def want_more(self) -> bool:
        """Room left for more rows?  None max_rows = always."""
        return self.max_rows is None or len(self.rows) < self.max_rows

    def guard_ok(self) -> bool:
        """Is the page guard still open?  0 = no guard."""
        return self.page_guard <= 0 or self.page < self.page_guard

    def may_fetch(self) -> bool:
        """The pair every pagination loop tests before another request."""
        return self.guard_ok() and self.want_more()


def _parse_default_headers(raw_headers: Any) -> dict:
    """Decode the ``default_headers`` config, which may be JSON text or a dict.

    Unparseable JSON yields no headers rather than failing construction.
    """
    if isinstance(raw_headers, str):
        try:
            return json.loads(raw_headers)
        except (json.JSONDecodeError, TypeError):
            return {}
    return dict(raw_headers)


def _addr_is_private(addr_text: str) -> bool:
    """Is one resolved address private / loopback / link-local?

    An IPv4-mapped IPv6 address (``::ffff:10.0.0.1``) is unwrapped first --
    the mapped form does not report as private on its own.
    """
    # NO function-local ``import ipaddress`` here -- but NOT for the reason
    # a 2026-09-12 commit first claimed, and the difference matters because
    # the wrong one sends the next reader hunting the wrong thing.
    #
    # A local import does NOT defeat ``patch('...rest_api_connector.socket
    # .getaddrinfo')``.  Both bindings are the SAME module object out of
    # sys.modules, and the patch replaces an attribute ON that object, so
    # the call sees it either way.  Verified.
    #
    # What DOES break the target is the module-level import going away --
    # then ``rest_api_connector.socket`` does not exist and the patch dies
    # with AttributeError.  That is exactly the 2026-08-17 lint sweep.  A
    # local import is dangerous because it makes the module-level one look
    # UNUSED, so the next ``ruff --fix F401`` deletes it and reproduces the
    # incident.  It is a fuse, not the failure.
    ip = ipaddress.ip_address(addr_text)
    if hasattr(ip, "ipv4_mapped") and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return ip.is_private or ip.is_loopback or ip.is_link_local


def _host_resolves_private(host: str) -> bool:
    """Does *host* resolve to an internal address we may reach directly?

    Only consulted when ``rest_api.allow_private_ips`` is on -- the same
    knob the SSRF check honours.  Fail-open to "no bypass": a DNS or
    config-import failure must not crash connector setup, it just falls
    through to the configured proxy.
    """
    try:
        from core.config import rest_api as _ra_cfg
        if not getattr(_ra_cfg, "allow_private_ips", False):
            return False
        # Module-level ``socket`` only -- see _addr_is_private for WHY (it is
        # about F401 deleting an apparently-unused import, not shadowing).  The
        # patch target is ``rest_api_connector.socket.getaddrinfo``, which a
        # local import makes unreachable.
        for _, _, _, _, addr in socket.getaddrinfo(host, None):
            if _addr_is_private(addr[0]):
                return True
    except Exception:
        # DNS / config import failures — don't crash the connector
        # setup; just fall through to the configured proxy.
        pass
    return False


def _resolve_db_manager():
    """The DB manager, or None when it cannot be resolved.

    2026-09-01 -- ``main`` has no ``_db_manager``.  The ImportError hit
    the fail-open here, so REST column suggestions returned [] every
    time and the editor always fell back to free-text typing.
    """
    try:
        from core.database import get_db_manager as _get_db
        return _get_db()
    except Exception:
        return None


def _list_rest_query_defs(db, conn_id) -> Optional[list]:
    """Saved RestQueryDefs on *conn_id*, or None when the lookup FAILED.

    None (not []) keeps "could not look up" distinguishable from "none
    saved": both make the caller fall back, but only one is a defect.
    """
    try:
        if hasattr(db, "list_rest_query_defs"):
            return db.list_rest_query_defs(conn_id) or []
    except Exception:
        return None
    return []


class RestApiConnector(SqlConnector):
    """
    Generic REST/HTTP API connector.

    Config dict keys:
        base_url          — required, e.g. "https://api.example.com/v2"
        auth_type         — "none" | "basic" | "bearer" | "api_key" | "oauth2_client_credentials"
        username          — for basic auth
        password          — for basic auth
        token             — for bearer auth
        api_key_name      — header/param name for api_key auth
        api_key_value     — the key value
        api_key_location  — "header" (default) or "query"
        client_id         — OAuth2 client credentials
        client_secret     — OAuth2 client credentials
        token_url         — OAuth2 token endpoint
        default_headers   — JSON string or dict of default headers
        timeout_seconds   — request timeout (default 30)
        verify_ssl        — bool (default True)
        rate_limit_rps    — max requests per second (default 10, 0 = unlimited)
    """

    #: Flatten depth used when ``__init__`` did not run.  A CLASS attribute,
    #: not an instance-only one: subclasses and test doubles construct this
    #: connector without calling ``__init__``, and a per-instance-only value
    #: turned ``_flatten_record`` into an AttributeError for every one of
    #: them.  The value is the module constant, which equals the declared
    #: default -- so an object that skipped ``__init__`` behaves exactly as
    #: it did before the config key was wired.
    _flatten_depth_cap = _MAX_FLATTEN_DEPTH

    #: 2026-09-16 — audited for reuse.  ``_session`` is a
    #: ``requests.Session``, an object built to be reused (that is the whole
    #: reason it exists — connection keep-alive).  ``_last_request_time``
    #: drives rate limiting and SHOULD persist across callers: a per-caller
    #: reset would let N callers each burn the first request of the window
    #: and defeat the limiter.  ``_flatten_depth_cap`` is resolved from
    #: config, and config is part of the pool key.  The base's execution id
    #: is the only per-caller field, cleared by the inherited reset.
    POOL_SAFE = True

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = (config.get("base_url") or "").rstrip("/")
        self.auth_type = (config.get("auth_type") or "none").lower()
        self.timeout = _resolve_timeout(config.get("timeout_seconds"))
        # Instance value overrides the class default declared above.
        self._flatten_depth_cap = _flatten_max_depth()
        self.verify_ssl = config.get("verify_ssl", True)
        if isinstance(self.verify_ssl, str):
            self.verify_ssl = self.verify_ssl.lower() in ("true", "1", "yes")
        self.rate_limit_rps = float(config.get("rate_limit_rps") or _DEFAULT_RATE_LIMIT)

        # Parse default headers
        self.default_headers = _parse_default_headers(
            config.get("default_headers") or "{}")

        # OAuth2 token cache
        self._oauth2_token: Optional[str] = None
        self._oauth2_expires_at: float = 0

        # Rate limiter state
        self._last_request_time: float = 0

        # Session for connection pooling
        # 2026-11-04: not a plain Session, whose verify a process-wide CA variable beats.
        from core.ssl_config import session_keeping_verify
        self._session = session_keeping_verify(self.verify_ssl)
        # Phase 119 proxy + BF-SAP-PROXY-BYPASS -- the bypass rules and why
        # they exist live on _should_bypass_proxy_for_base_url below.  The
        # import stays HERE and unconditional: a broken core.proxy_utils
        # must fail connector construction, as it always did.
        from core.proxy_utils import get_requests_proxies

        if not self._should_bypass_proxy_for_base_url():
            _rp = get_requests_proxies()
            if _rp:
                self._session.proxies = _rp

    def _should_bypass_proxy_for_base_url(self) -> bool:
        """Should requests to ``base_url`` skip the corporate proxy?

        Browsers bypass the corporate proxy for internal hosts via their
        PAC file / OS bypass list.  When the REST connector targets such
        a host (typical for SAP on-prem) we mirror that behaviour, OR
        else every request gets routed through a proxy that can't reach
        the internal network and the connection fails.

        Bypass rules (in order):
          1. base_url host matches ``proxy.no_proxy`` list
          2. base_url resolves to a private/loopback/link-local IP AND
             ``rest_api.allow_private_ips`` is true (symmetric with the
             SSRF allowance — if internal IPs are deliberately allowed
             they're also reachable directly, not via corp proxy).
        When neither rule fires the configured corporate proxy applies
        as before.
        """
        from core.proxy_utils import should_bypass_proxy

        _host = urlparse(self.base_url).hostname or ""
        if not _host:
            return False
        if should_bypass_proxy(_host):
            return True
        return _host_resolves_private(_host)

    # ── Connection lifecycle ─────────────────────────────────────────────────

    def test_connection(self) -> Dict[str, Any]:
        """GET the base_url and check for a 2xx response."""
        try:
            self._validate_url_safety(self.base_url)
            self._rate_limit()
            headers = self._build_headers()
            resp = self._session.get(
                self.base_url,
                headers=headers,
                timeout=self.timeout,
                allow_redirects=False,
            )
            if resp.status_code < 300:
                return {
                    "success": True,
                    "message": f"Connected: HTTP {resp.status_code}",
                    "details": {
                        "status_code": resp.status_code,
                        "content_type": resp.headers.get("content-type", ""),
                        "response_time_ms": int(resp.elapsed.total_seconds() * 1000),
                    },
                }
            return {
                "success": False,
                "message": f"HTTP {resp.status_code}: {resp.reason}",
                "details": {"status_code": resp.status_code, "body": resp.text[:500]},
            }
        except requests.exceptions.SSLError as e:
            from core.proxy_utils import sanitize_proxy_error
            return {"success": False, "message": f"SSL error: {sanitize_proxy_error(str(e))}", "details": {}}
        except requests.exceptions.ConnectionError as e:
            from core.proxy_utils import sanitize_proxy_error
            return {"success": False, "message": f"Connection error: {sanitize_proxy_error(str(e))}", "details": {}}
        except requests.exceptions.Timeout:
            return {"success": False, "message": f"Timeout after {self.timeout}s", "details": {}}
        except Exception as e:
            # 2026-09-14: explain_failure scrubs through sanitize_proxy_error
            # itself, so this keeps the redaction and gains the reason.
            return self._test_failure(e)

    def close(self):
        """Close the requests session."""
        try:
            self._session.close()
        except Exception:
            pass

    # ── Schema browsing (REST has no catalog/schema/table hierarchy) ─────────

    def list_catalogs(self) -> List[str]:
        return ["endpoints"]

    def list_schemas(self, catalog: str) -> List[str]:
        return ["default"]

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        """
        REST doesn't have tables — this returns saved RestQueryDef names.
        The caller (connections_api.py) handles this via DB lookup.
        """
        return []

    @staticmethod
    def _columns_from_mapping(mapping: list) -> List[Dict[str, Any]]:
        """Project a saved query def's ``column_mapping`` into column dicts.

        An entry with no usable name is dropped -- it would render as a
        blank entry in the publish dialog's dropdown.
        """
        return [
            {
                "name": (m.get("name") or m.get("source") or "") if isinstance(m, dict) else "",
                "type": (m.get("type") or "string") if isinstance(m, dict) else "string",
                "nullable": True,
                "ordinal": i,
            }
            for i, m in enumerate(mapping)
            if isinstance(m, dict) and (m.get("name") or m.get("source"))
        ]

    def _columns_for_query_def_named(self, defs: list,
                                     table: str) -> List[Dict[str, Any]]:
        """Columns declared by the saved query def whose name matches *table*.

        [] when nothing matches, and also when the matching def declares a
        non-list mapping -- in which case the scan CONTINUES, because a
        later def may carry the same name with a usable mapping.
        """
        for d in defs:
            if not isinstance(d, dict):
                continue
            if (d.get("name") or "").lower() == table.lower():
                mapping = d.get("column_mapping") or []
                if isinstance(mapping, list):
                    return self._columns_from_mapping(mapping)
        return []

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """
        REST connectors don't have a static catalogue, so to populate the
        WHERE-clause editor's column dropdown we look at saved query
        definitions on this connection (``RestQueryDef`` table) and, when
        ``table`` matches one of their names, return the column_mapping
        the publisher already declared.

        Phase 133-H round 8 — was returning ``[]`` unconditionally, which
        meant the publish dialog's column dropdown was empty for any
        REST-backed published view.  Now returns the declared columns
        from the saved query def when we can find a match.

        Fail-open: missing DB, missing query def, missing column_mapping
        all return ``[]`` — the editor falls back to free-text typing.
        """
        if not table:
            return []
        _db = _resolve_db_manager()
        if _db is None:
            return []
        # Try to find a RestQueryDef on this connection whose name matches.
        # ``self._connection_id`` is set when the factory wraps the
        # connector with the circuit breaker; fall back to scanning all
        # REST query defs when it's not available.
        conn_id = getattr(self, "_connection_id", None)
        if not conn_id:
            # Without conn_id we can't scope the query-def lookup.  The
            # factory stamps ``_connection_id`` on every connector it
            # produces; if it's missing here, the connector was built
            # bare (e.g. test) and the dropdown gracefully falls back.
            return []
        defs = _list_rest_query_defs(_db, conn_id)
        if defs is None:
            return []
        return self._columns_for_query_def_named(defs, table)

    # ── Query execution ──────────────────────────────────────────────────────

    @staticmethod
    def _unpack_rest_config(config: dict) -> Dict[str, Any]:
        """Read the RestQueryDef fields with their defaults, in one place."""
        return {
            "method": (config.get("http_method") or "GET").upper(),
            "endpoint": config.get("endpoint_path") or "/",
            "params": dict(config.get("query_params") or {}),
            "body": config.get("request_body"),
            "json_path": config.get("response_json_path") or "",
            "pagination_type": (config.get("pagination_type") or "none").lower(),
            "pagination_cfg": config.get("pagination_config") or {},
            "column_mapping": config.get("column_mapping") or [],
            "template_params": config.get("template_params") or {},
        }

    def _apply_templating(self, config: dict, endpoint: str, params: dict,
                          body: Any, pagination_cfg: dict,
                          template_params: dict):
        """Substitute ``{{param}}`` placeholders through the whole request.

        Phase 142+: parameter templating — admin can use {{param_name}}
        placeholders in endpoint_path / query_params / request_body /
        extra_headers.  Runtime substitution from `template_params` dict
        passed in config OR from query-level params (BQB / BR).  Supports
        SAP-style URL parameterisation (e.g. "/sap/odata/orders('{{order_id}}')")
        and dynamic value injection without code changes.

        ``config["extra_headers"]`` is rewritten IN PLACE, exactly as the
        inline code did -- the request builder reads it back off config.
        """
        endpoint = self._substitute_template(endpoint, template_params)
        params = self._substitute_template_dict(params, template_params)
        if body is not None:
            body = self._substitute_template_recursive(body, template_params)
        extra_hdrs = config.get("extra_headers")
        if extra_hdrs:
            config["extra_headers"] = self._substitute_template_dict(extra_hdrs, template_params)
        # Also apply to pagination_config so cursor/page values can be templated
        if pagination_cfg:
            pagination_cfg = self._substitute_template_dict(pagination_cfg, template_params)
        return endpoint, params, body, pagination_cfg

    @staticmethod
    def _resolve_row_budget(limit: Optional[int]):
        """Resolve ``(max_rows, configured_cap)``.  ``None`` max_rows = UNLIMITED.

        The incident history stays as ``#`` comments below rather than in
        this docstring: the absence guard in
        test_rest_connector_no_silent_cap_2026_08_17 scans this module's
        source for the old zero-folding idiom and exempts only ``#``
        lines, so quoting the old code here would trip it -- correctly.
        """
        # 2026-08-17 -- THREE stacked silent caps used to live here:
        #   max_rows = limit or 100000          <- zero-fold: 0/None meant
        #                                          "unlimited" everywhere else
        #                                          in this product, and became
        #                                          a hard 100k here
        #   min(max_rows, max_rows_per_query)   <- clamped even an explicit
        #                                          larger caller limit
        #   while page < _MAX_PAGES             <- stopped mid-stream silently
        # The result dict carried no truncation marker, so a 250k-row REST /
        # SAP-generic endpoint delivered 100k rows and reported SUCCESS.
        # ``None`` now means UNLIMITED all the way down.
        max_rows: Optional[int] = None
        if limit is not None and int(limit) > 0:
            max_rows = int(limit)
        _cfg_cap = 0
        try:
            from core.config import rest_api as _ra_cfg
            _cfg_cap = int(getattr(_ra_cfg, "max_rows_per_query", 0) or 0)
            if _cfg_cap > 0:
                max_rows = _cfg_cap if max_rows is None else min(max_rows, _cfg_cap)
        except Exception as _cap_exc:
            logger.debug("rest_api.max_rows_per_query unreadable (%s) -- "
                         "no configured row governor applied", _cap_exc)
        return max_rows, _cfg_cap

    @staticmethod
    def _disclose_truncation(result: Dict[str, Any], cfg_cap: int) -> None:
        """Mark a result the CONFIGURED governor cut short.

        DISCLOSE.  A cap may THROTTLE; it may not hand back a short
        answer and call it the whole answer.
        """
        result["truncated"] = True
        result["truncation_cap"] = int(cfg_cap)
        result["truncation_source"] = "rest_api.max_rows_per_query"
        logger.warning(
            "REST result TRUNCATED at %d rows by rest_api."
            "max_rows_per_query -- the endpoint had more.  Downstream "
            "completeness verdicts must treat this as INCOMPLETE.  "
            "Set rest_api.max_rows_per_query=0 for no governor.",
            int(cfg_cap),
        )

    def execute_query(self, sql_or_config: Any, limit: Optional[int] = None) -> Dict[str, Any]:
        """
        Execute a REST API query.

        Args:
            sql_or_config: Either a SQL string (ignored for REST) or a dict with:
                http_method       — "GET" or "POST"
                endpoint_path     — "/api/v2/search"
                query_params      — dict of query parameters
                request_body      — dict for POST body
                response_json_path— dot-notation path to array in response
                pagination_type   — "none"|"offset"|"cursor"|"link_header"|"page_number"
                pagination_config — dict with pagination params
                column_mapping    — optional list of {source, name, type}
            limit: max rows to return

        Returns:
            { "columns": [...], "rows": [...], "total_rows": int }
        """
        if isinstance(sql_or_config, str):
            # 2026-08-09 silent-wrong-data fix (source-agnostic audit §1):
            # a REST endpoint cannot execute SQL text.  This used to return
            # ``{"columns": [], "rows": [], "total_rows": 0}`` — an EMPTY
            # SUCCESS — so every report/engine path that hands connectors
            # SQL strings (business reports via connector_to_parquet, BQB,
            # data-quality, reconciliation) completed "successfully" with
            # zero rows forever, no error, no refusal.  A scheduled REST-
            # backed report would be built, run and EMAILED permanently
            # empty while marked successful.  UNKNOWN = UNSAFE (same
            # posture as core/reports/sources.py): raise loudly.  Callers
            # that legitimately drive this connector pass a RestQueryDef
            # dict (connections_api preview) and are unaffected.
            raise ValueError(
                "REST API connections cannot execute SQL text. This "
                "connector accepts a REST query definition (dict with "
                "endpoint_path / http_method / pagination), which report "
                "paths do not supply — a report on a rest_api connection "
                "would otherwise succeed permanently EMPTY. Materialise "
                "the REST/SAP data to parquet first (DataFlow/ETL) and "
                "report on that, or use a SQL-capable connection."
            )

        config = sql_or_config if isinstance(sql_or_config, dict) else {}
        _q = self._unpack_rest_config(config)
        method = _q["method"]
        endpoint = _q["endpoint"]
        params = _q["params"]
        body = _q["body"]
        json_path = _q["json_path"]
        pagination_type = _q["pagination_type"]
        pagination_cfg = _q["pagination_cfg"]
        column_mapping = _q["column_mapping"]
        template_params = _q["template_params"]

        if template_params:
            endpoint, params, body, pagination_cfg = self._apply_templating(
                config, endpoint, params, body, pagination_cfg, template_params)

        url = self._build_url(endpoint)
        all_rows: List[dict] = []
        max_rows, _cfg_cap = self._resolve_row_budget(limit)

        # 2026-08-20 -- OVERFLOW SENTINEL, so truncation is DETECTED not guessed.
        #
        # The 2026-08-17 change flipped the DEFAULT to 0 (unlimited) but left
        # the DISCLOSURE missing: when an operator armed this governor the
        # fetch simply stopped and the result dict reported
        # ``total_rows = len(flat_rows)`` with no marker at all.  A 250k-row
        # endpoint under a 100k cap delivered 100k rows and reported SUCCESS
        # -- and this connector feeds reports, federation and feeds, so a
        # silent partial here poisons every downstream completeness verdict.
        # Note the file's own ``max_pages`` guard RAISES rather than return a
        # silent partial; the row governor was the one that did not.
        #
        # Asking for ONE MORE ROW than the budget is what makes the
        # difference between "the endpoint had exactly N rows" and "we cut it
        # at N" observable -- the same idiom published-view dataset
        # materialization uses (``limit = cap + 1``).  Only the CONFIG cap
        # counts as truncation: a caller asking for 100 and getting 100 is
        # the request being honoured, not data loss.
        _fetch_budget = None if max_rows is None else int(max_rows) + 1

        if pagination_type == "none":
            data = self._single_request(method, url, params, body)
            all_rows = self._extract_rows(data, json_path)
        else:
            all_rows = self._paginated_request(
                method, url, params, body, json_path,
                pagination_type, pagination_cfg, _fetch_budget,
            )

        # Did the CONFIGURED governor cut a real result short?
        _truncated_by_cap = bool(
            _cfg_cap > 0 and max_rows is not None
            and int(max_rows) == int(_cfg_cap)
            and len(all_rows) > int(_cfg_cap)
        )

        # Trim the sentinel row (and honour the caller's own limit).
        if max_rows is not None and len(all_rows) > int(max_rows):
            all_rows = all_rows[:int(max_rows)]
        # Apply the caller's limit (0/None = unlimited -- never fold).
        if limit is not None and int(limit) > 0 and len(all_rows) > int(limit):
            all_rows = all_rows[:int(limit)]

        # Flatten nested objects
        flat_rows = [self._flatten_record(row) for row in all_rows]

        # Apply column mapping (rename/type hints)
        if column_mapping:
            flat_rows = self._apply_column_mapping(flat_rows, column_mapping)

        # Detect columns
        columns = self._detect_columns(flat_rows)

        result: Dict[str, Any] = {
            "columns": columns,
            "rows": flat_rows,
            "total_rows": len(flat_rows),
        }
        if _truncated_by_cap:
            self._disclose_truncation(result, _cfg_cap)
        return result

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _build_url(self, endpoint: str) -> str:
        """Combine base_url with endpoint path, then validate against SSRF."""
        if endpoint.startswith("http://") or endpoint.startswith("https://"):
            url = endpoint
        else:
            url = f"{self.base_url}/{endpoint.lstrip('/')}"
        self._validate_url_safety(url)
        return url

    @staticmethod
    def _validate_url_safety(url: str) -> None:
        """Block requests to private/loopback/link-local IPs (SSRF mitigation).

        Delegates to shared ``core.url_safety.validate_url_safety()``.
        """
        from core.url_safety import validate_url_safety
        validate_url_safety(url)

    def _build_headers(self, extra: Optional[dict] = None) -> dict:
        """Build request headers with auth and defaults."""
        headers = {"Accept": "application/json"}
        headers.update(self.default_headers)
        if extra:
            headers.update(extra)

        if self.auth_type == "bearer":
            token = self.config.get("token") or ""
            headers["Authorization"] = f"Bearer {token}"
        elif self.auth_type == "api_key":
            location = (self.config.get("api_key_location") or "header").lower()
            if location == "header":
                key_name = self.config.get("api_key_name") or "X-API-Key"
                headers[key_name] = self.config.get("api_key_value") or ""
        elif self.auth_type == "oauth2_client_credentials":
            token = self._get_oauth2_token()
            headers["Authorization"] = f"Bearer {token}"

        return headers

    def _build_auth(self) -> Optional[tuple]:
        """Return requests auth tuple for basic auth, else None."""
        if self.auth_type == "basic":
            return (self.config.get("username") or "", self.config.get("password") or "")
        return None

    def _build_query_params(self, params: dict) -> dict:
        """Inject API key into query params if api_key_location=query."""
        result = dict(params)
        if self.auth_type == "api_key":
            location = (self.config.get("api_key_location") or "header").lower()
            if location == "query":
                key_name = self.config.get("api_key_name") or "api_key"
                result[key_name] = self.config.get("api_key_value") or ""
        return result

    def _single_request(self, method: str, url: str, params: dict, body: Any) -> Any:
        """Make a single HTTP request and return parsed JSON."""
        self._rate_limit()
        headers = self._build_headers()
        auth = self._build_auth()
        query_params = self._build_query_params(params)

        kwargs: dict = {
            "headers": headers,
            "params": query_params,
            "timeout": self.timeout,
            "allow_redirects": False,
        }
        if auth:
            kwargs["auth"] = auth
        if method == "POST" and body:
            kwargs["json"] = body

        resp = self._session.request(method, url, **kwargs)
        resp.raise_for_status()
        _enforce_response_size(resp, url)

        content_type = resp.headers.get("content-type", "")
        if "json" in content_type or resp.text.strip().startswith(("{", "[")):
            return resp.json()
        return {"_raw_text": resp.text}

    def _page_by_offset(self, method: str, url: str, params: dict, body: Any,
                        json_path: str, cfg: dict,
                        budget: "_PageBudget") -> None:
        """Offset/limit pagination: advance ``offset`` until a page is empty."""
        offset_param = cfg.get("offset_param", "offset")
        limit_param = cfg.get("limit_param", "limit")
        limit_value = int(cfg.get("limit_value", 100))
        offset = 0

        while budget.may_fetch():
            p = dict(params)
            p[offset_param] = str(offset)
            p[limit_param] = str(limit_value)
            data = self._single_request(method, url, p, body)
            rows = self._extract_rows(data, json_path)
            if not rows:
                break
            budget.rows.extend(rows)
            offset += limit_value
            budget.page += 1

    def _page_by_number(self, method: str, url: str, params: dict, body: Any,
                        json_path: str, cfg: dict,
                        budget: "_PageBudget") -> None:
        """Page-number pagination: advance ``page`` until a page is empty."""
        page_param = cfg.get("page_param", "page")
        per_page_param = cfg.get("per_page_param", "per_page")
        per_page_value = int(cfg.get("per_page_value", 100))
        current_page = int(cfg.get("start_page", 1))

        while budget.may_fetch():
            p = dict(params)
            p[page_param] = str(current_page)
            p[per_page_param] = str(per_page_value)
            data = self._single_request(method, url, p, body)
            rows = self._extract_rows(data, json_path)
            if not rows:
                break
            budget.rows.extend(rows)
            current_page += 1
            budget.page += 1

    def _page_by_cursor(self, method: str, url: str, params: dict, body: Any,
                        json_path: str, cfg: dict,
                        budget: "_PageBudget") -> None:
        """Cursor pagination: follow the cursor field out of each response.

        A page that yields no cursor ends the walk WITHOUT counting as a
        consumed page -- the page counter only advances when there is a
        next page to fetch, which is what the guard check downstream reads.
        """
        cursor_field = cfg.get("cursor_field", "next_cursor")
        cursor_param = cfg.get("cursor_param", "cursor")
        cursor_value = None

        while budget.may_fetch():
            p = dict(params)
            if cursor_value:
                p[cursor_param] = cursor_value
            data = self._single_request(method, url, p, body)
            rows = self._extract_rows(data, json_path)
            if not rows:
                break
            budget.rows.extend(rows)

            # Extract next cursor from response
            if isinstance(data, dict):
                cursor_value = self._get_nested(data, cursor_field)
            if not cursor_value:
                break
            budget.page += 1

    def _page_by_link_header(self, method: str, url: str, params: dict,
                             body: Any, json_path: str,
                             budget: "_PageBudget") -> None:
        """RFC-5988 Link-header pagination: follow ``rel="next"``.

        Every next_url comes from the REMOTE response, so each one is
        SSRF-validated before it is fetched.
        """
        next_url: Optional[str] = url
        current_params = dict(params)

        while budget.may_fetch() and next_url:
            self._rate_limit()
            headers = self._build_headers()
            auth = self._build_auth()
            query_params = self._build_query_params(current_params)

            kwargs: dict = {"headers": headers, "params": query_params,
                           "timeout": self.timeout, "allow_redirects": False}
            if auth:
                kwargs["auth"] = auth
            if method == "POST" and body:
                kwargs["json"] = body

            # SSRF-validate pagination URLs from Link headers
            self._validate_url_safety(next_url)
            resp = self._session.request(method, next_url, **kwargs)
            resp.raise_for_status()
            _enforce_response_size(resp, next_url)
            data = resp.json()
            rows = self._extract_rows(data, json_path)
            if not rows:
                break
            budget.rows.extend(rows)

            # Parse Link header for next URL
            link_header = resp.headers.get("Link", "")
            next_url = self._parse_link_next(link_header)
            current_params = {}  # next_url already has params
            budget.page += 1

    @staticmethod
    def _check_pagination_exhausted(budget: "_PageBudget") -> None:
        """Tripped the guard while rows were still coming = incomplete."""
        if (budget.page_guard > 0 and budget.page >= budget.page_guard
                and budget.want_more()):
            raise RestPaginationExhausted(
                f"REST pagination hit the {budget.page_guard}-page guard while "
                f"the endpoint was still returning rows "
                f"({len(budget.rows)} so far).  Refusing to return a "
                f"SILENTLY TRUNCATED result.  Either the cursor/offset "
                f"is not advancing (a bug at the source), or this feed "
                f"legitimately needs more pages -- raise "
                f"rest_api.max_pages (0 = no guard)."
            )

    def _paginated_request(
        self, method: str, url: str, params: dict, body: Any,
        json_path: str, pagination_type: str, pagination_cfg: dict,
        max_rows: Optional[int],
    ) -> List[dict]:
        """Execute paginated requests and accumulate all rows.

        ``max_rows=None`` means UNLIMITED -- keep paging until the endpoint
        stops returning rows.  The page guard (``rest_api.max_pages``, 0 =
        off) exists only to stop a broken cursor looping forever; tripping it
        RAISES rather than returning a silent partial.
        """
        try:
            from core.config import rest_api as _ra_cfg
            _page_guard = int(getattr(_ra_cfg, "max_pages", _MAX_PAGES) or 0)
        except Exception:
            _page_guard = _MAX_PAGES

        budget = _PageBudget(max_rows, _page_guard)

        if pagination_type == "offset":
            self._page_by_offset(method, url, params, body, json_path,
                                 pagination_cfg, budget)
        elif pagination_type == "page_number":
            self._page_by_number(method, url, params, body, json_path,
                                 pagination_cfg, budget)
        elif pagination_type == "cursor":
            self._page_by_cursor(method, url, params, body, json_path,
                                 pagination_cfg, budget)
        elif pagination_type == "link_header":
            self._page_by_link_header(method, url, params, body, json_path,
                                      budget)

        # One check for every branch: if we stopped because the GUARD tripped
        # (not because the endpoint ran out), the result is incomplete and must
        # not be returned as if it were whole.
        self._check_pagination_exhausted(budget)
        return budget.rows

    def _extract_rows(self, data: Any, json_path: str) -> List[dict]:
        """Extract array of records from response using json_path."""
        if not data:
            return []

        target = data
        if json_path:
            target = self._get_nested(data, json_path)

        if isinstance(target, list):
            return [row if isinstance(row, dict) else {"value": row} for row in target]
        if isinstance(target, dict):
            return [target]
        return []

    def _get_nested(self, data: Any, path: str) -> Any:
        """Traverse a dot-notation path into nested data."""
        if not path:
            return data
        parts = path.split(".")
        current = data
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            elif isinstance(current, list) and part.isdigit():
                idx = int(part)
                current = current[idx] if idx < len(current) else None
            else:
                return None
            if current is None:
                return None
        return current

    # ── Phase 142+: parameter templating helpers ─────────────────────────────
    # Supports SAP-style URL/body/header parameterisation:
    #   endpoint_path:  "/sap/odata/orders('{{order_id}}')/items"
    #   query_params:   {"date": "{{biz_date}}", "code": "{{region}}"}
    #   request_body:   {"filters": [{"field": "id", "value": "{{order_id}}"}]}
    # Pattern: {{name}} matches per-call template_params dict.
    # Unsubstituted placeholders are left intact (admin's responsibility to
    # ensure all required params are provided — we don't error at runtime
    # because that would mask the more useful "API returned 400 with
    # 'invalid X'" error which tells admin exactly what the API expected).

    _TEMPLATE_RE = re.compile(r"\{\{\s*([\w.\-]+)\s*\}\}")

    @classmethod
    def _substitute_template(cls, template: str, params: Dict[str, Any]) -> str:
        """Substitute {{key}} placeholders in a string using params dict."""
        if not template or not isinstance(template, str):
            return template
        if "{{" not in template:
            return template
        def _sub(m):
            key = m.group(1)
            if key in params:
                v = params[key]
                return "" if v is None else str(v)
            return m.group(0)  # keep placeholder if no value provided
        return cls._TEMPLATE_RE.sub(_sub, template)

    @classmethod
    def _substitute_template_dict(cls, d: Dict[str, Any], params: Dict[str, Any]) -> Dict[str, Any]:
        """Apply _substitute_template to every string value in a flat dict.

        Keys are NOT templated (would change the dict shape unpredictably).
        Non-string values pass through.
        """
        if not isinstance(d, dict):
            return d
        out = {}
        for k, v in d.items():
            if isinstance(v, str):
                out[k] = cls._substitute_template(v, params)
            else:
                out[k] = v
        return out

    @classmethod
    def _substitute_template_recursive(cls, obj: Any, params: Dict[str, Any]) -> Any:
        """Walk nested dicts/lists/strings and substitute templates.

        Used for JSON request bodies where the placeholder might be nested
        inside arrays of objects (common in OData / GraphQL POST bodies).
        """
        if isinstance(obj, str):
            return cls._substitute_template(obj, params)
        if isinstance(obj, dict):
            return {k: cls._substitute_template_recursive(v, params) for k, v in obj.items()}
        if isinstance(obj, list):
            return [cls._substitute_template_recursive(x, params) for x in obj]
        return obj

    def _flatten_record(self, record: dict, prefix: str = "", depth: int = 0) -> dict:
        """Flatten nested dicts with dot-notation keys. Arrays become JSON strings."""
        flat: dict = {}
        # Resolved ONCE per connector (see __init__), never here: this
        # function is called per record and recurses per nesting level, so a
        # config read at this site would be a lookup per record per level.
        # Measuring the latency you add is a rule this repo has already paid
        # to learn (a parse inside a per-(table,column) loop cost 530ms/query).
        if depth > self._flatten_depth_cap:
            return {prefix.rstrip("."): json.dumps(record, default=str)}

        for key, value in record.items():
            full_key = f"{prefix}{key}" if not prefix else f"{prefix}.{key}"
            if isinstance(value, dict):
                flat.update(self._flatten_record(value, full_key + ".", depth + 1))
            elif isinstance(value, list):
                flat[full_key] = json.dumps(value, default=str)
            else:
                flat[full_key] = value
        return flat

    def _apply_column_mapping(self, rows: List[dict], mapping: List[dict]) -> List[dict]:
        """Rename columns and apply type hints based on column_mapping config."""
        rename_map = {}
        for m in mapping:
            source = m.get("source", "")
            name = m.get("name", source)
            if source and name and source != name:
                rename_map[source] = name

        if not rename_map:
            return rows

        result = []
        for row in rows:
            new_row = {}
            for k, v in row.items():
                new_key = rename_map.get(k, k)
                new_row[new_key] = v
            result.append(new_row)
        return result

    def _detect_columns(self, rows: List[dict]) -> List[Dict[str, str]]:
        """Auto-detect column names and types from row data."""
        if not rows:
            return []

        # Collect all keys across first N rows
        all_keys: dict = {}  # key → python type
        for row in rows[:100]:
            for k, v in row.items():
                if k not in all_keys and v is not None:
                    all_keys[k] = type(v).__name__

        type_map = {
            "str": "VARCHAR",
            "int": "INTEGER",
            "float": "DOUBLE",
            "bool": "BOOLEAN",
            "NoneType": "VARCHAR",
        }

        return [
            {"name": k, "type": type_map.get(v, "VARCHAR")}
            for k, v in all_keys.items()
        ]

    def _get_oauth2_token(self) -> str:
        """Exchange client credentials for an access token (cached)."""
        now = time.time()
        if self._oauth2_token and now < self._oauth2_expires_at:
            return self._oauth2_token

        token_url = self.config.get("token_url") or ""
        client_id = self.config.get("client_id") or ""
        client_secret = self.config.get("client_secret") or ""

        if not token_url:
            raise ValueError("OAuth2 client_credentials requires token_url")
        self._validate_url_safety(token_url)

        resp = self._session.post(
            token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            },
            timeout=self.timeout,
            allow_redirects=False,
        )
        resp.raise_for_status()
        token_data = resp.json()

        self._oauth2_token = token_data.get("access_token") or ""
        expires_in = int(token_data.get("expires_in", 3600))

        try:
            from core.config import rest_api as _ra_cfg
            cache_seconds = _ra_cfg.oauth2_token_cache_seconds
        except Exception:
            cache_seconds = 3500

        self._oauth2_expires_at = now + min(expires_in - 60, cache_seconds)
        return self._oauth2_token

    def _rate_limit(self):
        """Simple token-bucket rate limiter."""
        if self.rate_limit_rps <= 0:
            return
        min_interval = 1.0 / self.rate_limit_rps
        now = time.time()
        elapsed = now - self._last_request_time
        if elapsed < min_interval:
            time.sleep(min_interval - elapsed)
        self._last_request_time = time.time()

    @staticmethod
    def _parse_link_next(link_header: str) -> Optional[str]:
        """Parse Link header to extract rel="next" URL."""
        if not link_header:
            return None
        for part in link_header.split(","):
            part = part.strip()
            match = re.match(r'<([^>]+)>;\s*rel="next"', part)
            if match:
                return match.group(1)
        return None
