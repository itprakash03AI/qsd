"""The spark_k8s retry/state classifier — the vocabulary is DATA (2026-08-22).

WHY THIS EXISTS AS ITS OWN MODULE: the markers and state names below were
built from spark-operator/Kubernetes CONVENTIONS, not observed CRs — no real
cluster has run this backend yet (docs/spark_k8s_native_runner_2026_08_22.md
§7 names that debt explicitly).  When a real cluster shows a state or an
error text this table did not predict, the operator must be able to teach
the classifier WITHOUT a code change: every rule is a declared datum with a
required REASON, and config can extend or override the table
(``spark_k8s.classifier_markers``, ``spark_k8s.cr_states`` — both declared
in ``core.config._DEFAULTS``).

THE CENTRAL RULE (same lesson as core/filter_ops.py, 2026-08-21): an
UNRECOGNISED spelling and a DELIBERATE verdict must never be
indistinguishable.  Anything the table does not match gets an explicitly
DECLARED conservative treatment with its own reason string — never a silent
"retryable" and never a silent "terminal":

* unmatched failure text  -> ``unknown_failure:conservative_bounded_retry``
  — retried, BOUNDED by ``spark_k8s.max_retries`` (0 = zero, never
  unlimited), so it converges to a terminal row either way, and logged
  (once per distinct state/error head) so the operator can declare a rule.
* unmatched CR state      -> ``PHASE_UNKNOWN`` — supervised as in-flight
  (the ``job_timeout_seconds`` gate still bounds it; the reaper treats it
  as possibly-live and never deletes it), and logged once per state.

Precedence: FIRST MATCH IN SEQUENCE.  Operator config rules come first, in
the order the operator declared them — a rule written from an OBSERVED CR
outranks one written from a convention, and redeclaring a built-in marker
therefore overrides its verdict.  The built-in table lists every
``non_retryable`` rule before its ``retryable`` rules, so when two built-in
markers match the same error text the STRICTER verdict wins (a
deterministic refusal must not be burned as a transient retry) — a
property the test suite pins.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

# ── Verdicts ─────────────────────────────────────────────────────────────

VERDICT_NON_RETRYABLE = "non_retryable"
VERDICT_RETRYABLE = "retryable"
VALID_VERDICTS = (VERDICT_NON_RETRYABLE, VERDICT_RETRYABLE)


@dataclass(frozen=True)
class MarkerRule:
    """One declared classification rule.

    ``marker``  — lowercase substring matched against
                  ``f"{state} {errorMessage}".lower()``.
    ``verdict`` — one of ``VALID_VERDICTS``.
    ``reason``  — REQUIRED prose: why this verdict.  It travels into the
                  execution row's error_message and the logs, so the
                  operator reading a failed feed sees the argument, not
                  just the label.
    """
    marker: str
    verdict: str
    reason: str


@dataclass(frozen=True)
class FailureClass:
    retryable: bool
    reason: str        # machine-greppable, stable format (see classify_failure)
    detail: str = ""   # the matched rule's human reason ("" for legacy ctors)


# ── The built-in marker table (conventions; config can extend/override) ──

# ORDER IS LOAD-BEARING (first match wins): every non_retryable rule sits
# before every retryable rule so a double match refuses — pinned by
# tests/test_spark_k8s_closeout_2026_08_22.py.
DEFAULT_MARKER_RULES: Tuple[MarkerRule, ...] = (
    # image problems — deterministic until a human fixes the image/registry
    MarkerRule("imagepullbackoff", VERDICT_NON_RETRYABLE,
               "the node cannot pull the image; every retry pulls the same "
               "image from the same registry"),
    MarkerRule("errimagepull", VERDICT_NON_RETRYABLE,
               "image pull error; identical on every attempt"),
    MarkerRule("invalidimagename", VERDICT_NON_RETRYABLE,
               "the image reference itself is malformed; config fix needed"),
    MarkerRule("image pull failed", VERDICT_NON_RETRYABLE,
               "image pull error; identical on every attempt"),
    MarkerRule("failed to pull image", VERDICT_NON_RETRYABLE,
               "image pull error; identical on every attempt"),
    # our own declared config refusals — deterministic by construction
    MarkerRule("no jdbc url grammar", VERDICT_NON_RETRYABLE,
               "QueryStudio's own JDBC grammar refused this connection "
               "type; retrying re-runs the same refusal"),
    MarkerRule("jdbc_config.url", VERDICT_NON_RETRYABLE,
               "the resolved feed config is missing/invalid at the JDBC "
               "URL; a retry rebuilds the same config"),
    MarkerRule("classnotfoundexception", VERDICT_NON_RETRYABLE,
               "the driver jar is not in the Spark image; needs an image "
               "rebuild, not another attempt"),
    MarkerRule("no suitable driver", VERDICT_NON_RETRYABLE,
               "JDBC driver missing from the image; needs an image rebuild"),
    # authentication/authorization — deterministic until credentials change
    MarkerRule("unauthorized", VERDICT_NON_RETRYABLE,
               "the source refused the credentials; retrying re-sends the "
               "same credentials"),
    MarkerRule("forbidden", VERDICT_NON_RETRYABLE,
               "authorization refusal; deterministic until access changes"),
    MarkerRule("access denied", VERDICT_NON_RETRYABLE,
               "authorization refusal; deterministic until access changes"),
    MarkerRule("accessdenied", VERDICT_NON_RETRYABLE,
               "authorization refusal; deterministic until access changes"),
    MarkerRule("invalid username or password", VERDICT_NON_RETRYABLE,
               "credential rejection; retrying re-sends the same secret"),
    MarkerRule("authentication failed", VERDICT_NON_RETRYABLE,
               "credential rejection; retrying re-sends the same secret"),
    # memory sizing — the same sizing will OOM the same way; needs a human
    # to raise spark_driver_memory / spark_executor_memory
    MarkerRule("oomkilled", VERDICT_NON_RETRYABLE,
               "the same pod sizing OOMs the same way; raise "
               "spark_driver_memory/spark_executor_memory instead"),
    MarkerRule("outofmemoryerror", VERDICT_NON_RETRYABLE,
               "JVM heap exhaustion recurs at the same sizing"),
    MarkerRule("exit code 137", VERDICT_NON_RETRYABLE,
               "SIGKILL by the kernel OOM killer; same sizing, same kill"),
    # ── declared RETRYABLE — the transient class Airflow's retries=1
    #    existed for.  Declaring them (instead of relying on the unknown
    #    fallback) keeps "we predicted this and chose retry" distinguishable
    #    from "we never saw this before" in logs and error messages.
    MarkerRule("executorlostfailure", VERDICT_RETRYABLE,
               "executor loss is the canonical transient fault (node "
               "churn, spot reclaim); a fresh attempt lands elsewhere"),
    MarkerRule("executor lost", VERDICT_RETRYABLE,
               "executor loss is the canonical transient fault"),
    MarkerRule("node shutdown", VERDICT_RETRYABLE,
               "the node went away under the job; a fresh attempt lands "
               "on a live node"),
    MarkerRule("evicted", VERDICT_RETRYABLE,
               "pod eviction is scheduling pressure, not a property of "
               "the job"),
    # 143 = SIGTERM: the driver was ASKED to stop by the cluster (a node
    # drain, preemption, a deletion outside QueryStudio; seen under load
    # 2026-10) -- not by its own work.  The reconciler's OWN budget kill
    # never reaches this table (it finalises with FailureClass(False,
    # "job_timeout") directly), so a stalled run is never retried by this
    # rule.  Both spellings: the operator writes "ExitCode: 143".
    MarkerRule("exit code 143", VERDICT_RETRYABLE,
               "SIGTERM from the cluster (node drain, preemption, a deletion "
               "outside QueryStudio); a fresh attempt lands on a live node"),
    MarkerRule("exitcode: 143", VERDICT_RETRYABLE,
               "SIGTERM from the cluster (node drain, preemption, a deletion "
               "outside QueryStudio); a fresh attempt lands on a live node"),
    MarkerRule("connection refused", VERDICT_RETRYABLE,
               "a dependency was momentarily unreachable; classic "
               "transient"),
    MarkerRule("connection reset", VERDICT_RETRYABLE,
               "mid-stream network fault; classic transient"),
)

#: Reason string for the declared conservative default.  A cap THROTTLES, a
#: correctness gate FAILS — this is neither: it is a declared retry bounded
#: by max_retries, so it converges to a terminal row on every path.
UNKNOWN_FAILURE_REASON = "unknown_failure:conservative_bounded_retry"

# ── CR applicationState phases (spark-operator v1beta2 conventions) ──────

PHASE_SUCCESS = "success"
PHASE_FAILURE = "failure"
PHASE_IN_FLIGHT = "in_flight"
PHASE_UNKNOWN = "unknown"
VALID_PHASES = (PHASE_SUCCESS, PHASE_FAILURE, PHASE_IN_FLIGHT)

#: Terminal states in which the JOB NEVER RAN: spark-submit itself failed
#: (the operator's ``SUBMISSION_FAILED``), so no driver existed and nothing
#: the job does -- a pod-side delivery included -- can have happened.  The
#: reconciler's "this feed delivers from inside the pod, a resubmit might
#: deliver AGAIN" refusal does not apply to these (2026-10-11: every
#: owner-case run that died with "argument list too long" at submit was
#: labelled ``non_retryable:pod_side_delivery`` -- nothing was delivered).
NEVER_STARTED_STATES = frozenset({"SUBMISSION_FAILED"})

DEFAULT_STATE_PHASES: Dict[str, str] = {
    # terminal
    "COMPLETED":         PHASE_SUCCESS,
    "FAILED":            PHASE_FAILURE,
    "SUBMISSION_FAILED": PHASE_FAILURE,
    # in flight ("" = the operator has not written a status yet)
    "":                  PHASE_IN_FLIGHT,
    "NEW":               PHASE_IN_FLIGHT,
    "SUBMITTED":         PHASE_IN_FLIGHT,
    "RUNNING":           PHASE_IN_FLIGHT,
    "SUCCEEDING":        PHASE_IN_FLIGHT,
    "FAILING":           PHASE_IN_FLIGHT,
    "PENDING_RERUN":     PHASE_IN_FLIGHT,
    "INVALIDATING":      PHASE_IN_FLIGHT,
    # the operator itself lost sight of the driver — keep supervising; the
    # job_timeout gate bounds it
    "UNKNOWN":           PHASE_IN_FLIGHT,
    # ── Pod phases (submit_mode="driver_pod", 2026-09-03) ────────────
    # The kubelet's vocabulary, added as DATA exactly as this module's
    # header promised: "a new spelling needs no code".  FAILED, RUNNING
    # and UNKNOWN already carry the right verdict and are shared with
    # the CR vocabulary above; only these two are new.
    #
    # PENDING is IN_FLIGHT and NOT a failure — the pending_timeout gate
    # is what turns a pod that never schedules (quota, ImagePullBackOff)
    # into a terminal never-started, and it must stay the thing that
    # decides that, not this table.
    "SUCCEEDED":         PHASE_SUCCESS,
    "PENDING":           PHASE_IN_FLIGHT,
}


# ── Config merge + validation ────────────────────────────────────────────

def validate_marker_entry(entry) -> Optional[str]:
    """Return an error string when ``entry`` is not a valid marker-rule
    dict, else None.  A rule WITHOUT a reason is invalid by design — the
    reason is the point of the table."""
    if not isinstance(entry, dict):
        return f"not a dict: {entry!r}"
    marker = entry.get("marker")
    verdict = entry.get("verdict")
    reason = entry.get("reason")
    if not isinstance(marker, str) or not marker.strip():
        return f"missing/empty 'marker': {entry!r}"
    if verdict not in VALID_VERDICTS:
        return (f"'verdict' must be one of {list(VALID_VERDICTS)}, "
                f"got {verdict!r} in {entry!r}")
    if not isinstance(reason, str) or not reason.strip():
        return (f"missing/empty 'reason' in {entry!r} — a rule without a "
                f"reason is exactly the undeclared behaviour this table "
                f"exists to remove")
    return None


_logged_invalid: set = set()


def _log_invalid_once(kind: str, problems: Sequence[str]) -> None:
    key = (kind, tuple(problems))
    if not problems or key in _logged_invalid:
        return
    _logged_invalid.add(key)
    logger.error(
        "[spark_k8s] %d invalid %s config entr%s IGNORED (the remaining "
        "declared rules still apply): %s",
        len(problems), kind, "y" if len(problems) == 1 else "ies",
        "; ".join(problems),
    )


def load_marker_rules(config_entries=None) -> Tuple[MarkerRule, ...]:
    """Operator rules (``spark_k8s.classifier_markers``) FIRST, then the
    built-ins — an operator rule for a marker the built-ins also know
    therefore OVERRIDES the built-in verdict (observed CRs outrank
    conventions).  Invalid entries are excluded and ERROR-logged once per
    distinct problem set; the valid rest still applies."""
    if config_entries is None:
        from core.config import get as _get
        config_entries = _get("spark_k8s", "classifier_markers", []) or []
    rules: List[MarkerRule] = []
    problems: List[str] = []
    if not isinstance(config_entries, (list, tuple)):
        problems.append(
            f"spark_k8s.classifier_markers must be a LIST of "
            f"{{marker, verdict, reason}} dicts, got "
            f"{type(config_entries).__name__}")
        config_entries = []
    for entry in config_entries:
        err = validate_marker_entry(entry)
        if err is not None:
            problems.append(err)
            continue
        rules.append(MarkerRule(
            marker=str(entry["marker"]).strip().lower(),
            verdict=str(entry["verdict"]),
            reason=str(entry["reason"]).strip(),
        ))
    _log_invalid_once("classifier_markers", problems)
    return tuple(rules) + DEFAULT_MARKER_RULES


def load_state_phases(config_value=None) -> Dict[str, str]:
    """Built-in phases overlaid with ``spark_k8s.cr_states`` — a dict of
    ``{"success": [...], "failure": [...], "in_flight": [...]}``.  A state
    the operator redeclares moves bucket (observed reality outranks the
    convention, INFO-logged); a state named in two config buckets is
    rejected loudly (both entries dropped — an ambiguous verdict is no
    verdict)."""
    if config_value is None:
        from core.config import get as _get
        config_value = _get("spark_k8s", "cr_states", {}) or {}
    phases = dict(DEFAULT_STATE_PHASES)
    problems: List[str] = []
    if not isinstance(config_value, dict):
        _log_invalid_once("cr_states", [
            f"spark_k8s.cr_states must be a dict with keys "
            f"{list(VALID_PHASES)}, got {type(config_value).__name__}"])
        return phases
    claimed: Dict[str, str] = {}
    duplicated: set = set()
    for bucket, states in config_value.items():
        if bucket not in VALID_PHASES:
            problems.append(
                f"unknown bucket {bucket!r} (valid: {list(VALID_PHASES)})")
            continue
        if not isinstance(states, (list, tuple)):
            problems.append(f"bucket {bucket!r} must hold a LIST of state "
                            f"names, got {type(states).__name__}")
            continue
        for state in states:
            if not isinstance(state, str) or not state.strip():
                problems.append(f"empty/non-string state in bucket "
                                f"{bucket!r}: {state!r}")
                continue
            s = state.strip().upper()
            if s in claimed and claimed[s] != bucket:
                problems.append(
                    f"state {s!r} claimed by both {claimed[s]!r} and "
                    f"{bucket!r} — ambiguous, BOTH dropped")
                duplicated.add(s)
                continue
            claimed[s] = bucket
    for s, bucket in claimed.items():
        if s in duplicated:
            continue
        if s in DEFAULT_STATE_PHASES and DEFAULT_STATE_PHASES[s] != bucket:
            logger.info(
                "[spark_k8s] cr_states: operator moved state %r from the "
                "built-in %r bucket to %r (observed cluster outranks the "
                "convention)", s, DEFAULT_STATE_PHASES[s], bucket)
        phases[s] = bucket
    _log_invalid_once("cr_states", problems)
    return phases


# ── Classification ───────────────────────────────────────────────────────

_warned_unknown_failures: set = set()
_warned_unknown_states: set = set()
_WARN_CACHE_CAP = 200  # bound the once-per-novelty sets


def classify_failure(state: str, error_message: str,
                     rules: Optional[Sequence[MarkerRule]] = None
                     ) -> FailureClass:
    """Classify a terminal CR failure against the declared vocabulary.

    Match order: FIRST MATCH IN SEQUENCE — operator rules come before the
    built-ins in ``load_marker_rules``'s output, so an operator rule that
    redeclares a built-in marker OVERRIDES its verdict, and the built-in
    table lists non-retryable rules before retryable ones so a double
    match inside the built-ins refuses (stricter wins).  No match at all
    is the DECLARED conservative default: retryable, bounded by
    ``max_retries`` (0 = zero retries, never unlimited), reason
    ``unknown_failure:conservative_bounded_retry``, WARNING-logged once
    per novelty so the operator can extend
    ``spark_k8s.classifier_markers``.
    """
    if rules is None:
        rules = load_marker_rules()
    blob = f"{state} {error_message}".lower()
    for rule in rules:
        if rule.marker in blob:
            return FailureClass(
                retryable=(rule.verdict == VERDICT_RETRYABLE),
                reason=(f"{rule.verdict}_marker:"
                        f"{rule.marker.replace(' ', '_')}"),
                detail=rule.reason,
            )
    novelty = (str(state), str(error_message)[:120])
    if (novelty not in _warned_unknown_failures
            and len(_warned_unknown_failures) < _WARN_CACHE_CAP):
        _warned_unknown_failures.add(novelty)
        logger.warning(
            "[spark_k8s] UNRECOGNISED failure (state=%r, error=%.300r) "
            "matched no declared marker rule — treated conservatively as "
            "retryable, BOUNDED by spark_k8s.max_retries.  If this is a "
            "real cluster's spelling, declare it in "
            "spark_k8s.classifier_markers "
            "({marker, verdict, reason}) — no code change needed.",
            state, error_message,
        )
    return FailureClass(
        retryable=True,
        reason=UNKNOWN_FAILURE_REASON,
        detail=("no declared marker matched; retried within the "
                "max_retries bound so it still converges to a terminal "
                "row — observe the CR and declare a rule in "
                "spark_k8s.classifier_markers"),
    )


def classify_cr_state(state: str,
                      phases: Optional[Dict[str, str]] = None) -> str:
    """Map a CR ``applicationState.state`` onto a lifecycle phase.

    An unmapped state returns ``PHASE_UNKNOWN`` — the caller must treat it
    as its own declared branch (the reconciler supervises it like
    in-flight, still bounded by the job timeout; the reaper treats it as
    possibly-live and never deletes it), and it is WARNING-logged once per
    state so the operator can declare it in ``spark_k8s.cr_states``.
    """
    if phases is None:
        phases = load_state_phases()
    key = str(state or "").strip().upper()
    phase = phases.get(key)
    if phase is not None:
        return phase
    if (key not in _warned_unknown_states
            and len(_warned_unknown_states) < _WARN_CACHE_CAP):
        _warned_unknown_states.add(key)
        logger.warning(
            "[spark_k8s] UNRECOGNISED SparkApplication state %r — treated "
            "conservatively as possibly-live (supervised like in-flight, "
            "job_timeout still applies, never reaped).  Declare it in "
            "spark_k8s.cr_states {success|failure|in_flight: [...]} — no "
            "code change needed.", key,
        )
    return PHASE_UNKNOWN
