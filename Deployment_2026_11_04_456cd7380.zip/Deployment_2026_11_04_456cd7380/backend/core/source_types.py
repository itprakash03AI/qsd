"""Driver type name -> the product's data_type vocabulary.  ONE copy.

FB-42 (2026-09-19).  This lived in ``api/datasets_api.py`` and was needed by
the federation engine, which must not import ``api/``; moving it rather
than copying it keeps "is this engine type a number?" answered once.
``api.datasets_api`` re-exports it under its old names.
"""
from __future__ import annotations

from typing import Any, Optional

#: Checked by substring because every engine spells these differently
#: ("varchar(50)", "DECIMAL(18,2)", "timestamp(3) with time zone").
DRIVER_TYPE_HINTS = (
    ("bool", "boolean"),
    ("int", "number"), ("dec", "number"), ("num", "number"), ("fixed", "number"),
    ("double", "number"), ("real", "number"), ("float", "number"),
    ("timestamp", "date"), ("date", "date"), ("time", "date"),
    ("char", "string"), ("string", "string"), ("text", "string"),
    ("uuid", "string"),
)

#: The stored data_type values that can never be aggregated with SUM/AVG.
NON_NUMERIC_DATA_TYPES = frozenset({"string", "boolean", "date"})


def driver_data_type(raw: Any) -> Optional[str]:
    """Map a driver-reported column type onto the product vocabulary.

    Returns None when the spelling is not recognised, so the caller falls
    back to sampling (or the stored type) rather than inventing a type.
    Unknown is not text.
    """
    t = str(raw or "").strip().lower()
    if not t:
        return None
    for needle, mapped in DRIVER_TYPE_HINTS:
        if needle in t:
            return mapped
    return None
