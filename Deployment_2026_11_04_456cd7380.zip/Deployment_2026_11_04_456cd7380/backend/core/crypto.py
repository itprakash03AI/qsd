"""
Credential encryption for Query Studio connection configs.

Sensitive fields (passwords, tokens, private keys) are encrypted at rest using
Fernet symmetric encryption (AES-128-CBC + HMAC-SHA256).

ONE key for every component (2026-10-15).  Found deploying to a NEW server:
the key was a FILE on the shared volume, created by whichever pod started
first; where the pods could not write that folder (a fresh NFS volume, an
OpenShift-assigned UID) every pod silently invented its OWN ephemeral key,
and connections saved through one pod could not be read by any other --
16 of 16 stored credentials unreadable in every component, every pod
"healthy".

Key resolution (logged once per process, readable at
``GET /api/admin/encryption-key`` -- the key itself never):
  PRIMARY (encrypts; decrypts)
    1. ``QUERY_STUDIO_SECRET_KEY`` -- the api chart's shared Secret creates it
       ONCE and keeps it (helm ``lookup``), so every component gets it;
    2. else the key FILE on the shared volume (``paths.secret_key_file``) --
       CREATED ONLY BY THE KEY OWNER (``QS_ENCRYPTION_KEY_OWNER``: true in
       the api chart, false in every other component; unset = owner, for a
       single-process run).  A non-owner never creates a key: until the
       API's file exists it WAITS -- it starts, refuses to encrypt, and picks
       the key up on its next use once the file appears (no restart);
    3. else NO KEY -- never a throw-away key: encrypting a credential is
       REFUSED (``EncryptionKeyUnavailable``) with the fix, and nothing is
       written under a key that would be lost (2026-10-15, the owner: "if the
       key is not available at all ... the key will be created once the UI and
       API are deployed, and then connections are saved").
  DECRYPT-ONLY (credentials saved before; re-encrypted under the primary at
  start by ``core/encryption_key_rotation.py``)
    * ``QUERY_STUDIO_SECRET_KEY_PREVIOUS`` -- comma-separated: an OLD
      environment's key, for a database moved to a new server;
    * the key FILE, when the primary came from the variable and the file
      holds a different key (an upgrade from the file-based release).
To generate a valid key:
    python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict

logger = logging.getLogger(__name__)

# Prefix that marks an already-encrypted value — allows idempotent encrypt/decrypt
_ENC_PREFIX = "enc::"

# Config field names that contain credentials and must be encrypted at rest
#
# SECURITY AUDIT 2026-08-03 (S3): this single constant drives masking
# (mask_config), encrypt-at-rest (encrypt_config) AND the "***"-unmask guard
# on connection PUT/test — so an omission here breaks all three at once.
# Added the credential keys that real connector configs actually use but
# were missing: api_key_value / client_secret (rest_api connector),
# aws_session_token (athena/S3 STS), secret_key / session_token (S3 alias
# keys, see core/connectors/__init__.py credential alias mapping).
#
# MIGRATION / READ-COMPAT: rows written before this widening store the new
# fields as PLAINTEXT (no "enc::" prefix).  decrypt_value() passes any
# value without the "enc::" prefix through unchanged, so widening the list
# NEVER breaks reads of existing rows; the value is transparently encrypted
# on the next write (encrypt_value is idempotent via the prefix check).
SENSITIVE_FIELDS: frozenset[str] = frozenset([
    "password",
    "token",
    "access_token",
    "aws_secret_access_key",
    "private_key",
    "private_key_passphrase",
    "wallet_password",       # Oracle Autonomous DB wallet password
    "portal_password",       # connection-level portal system account password (Phase 104-N)
    "sso_password",          # Snowflake service login typed on the connection (2026-11-04)
    # S3 audit additions (2026-08-03)
    "api_key_value",         # REST-API connector: API key credential
    "client_secret",         # REST-API connector: OAuth2 client credential
    "aws_session_token",     # Athena/S3: STS session token
    "secret_key",            # S3 alias for aws_secret_access_key
    "session_token",         # S3 alias for aws_session_token
])

_fernet = None        # module-level singleton, initialized lazily
_CRYPTO_AVAILABLE = None  # tri-state: None=unknown, True/False after first check


def _check_crypto() -> bool:
    global _CRYPTO_AVAILABLE
    if _CRYPTO_AVAILABLE is None:
        try:
            import cryptography  # noqa: F401
            _CRYPTO_AVAILABLE = True
        except ImportError:
            _CRYPTO_AVAILABLE = False
            logger.warning(
                "cryptography package is not installed — credential encryption is disabled. "
                "Install it with: pip install cryptography>=42.0.0"
            )
    return _CRYPTO_AVAILABLE


#: what this process's keys are and where each came from (never the key)
_KEY_STATUS: Dict[str, Any] = {}

# ── Envelope encryption (2026-10-17) ──────────────────────────────────────
#
# The owner: "api deployed on two container and its updated in values in db
# ... its completely blocking".  Each component encrypted with ITS OWN copy of
# the key and a start-up sweep re-encrypted every stored secret under it: two
# containers resolving different keys rewrote each other's values in long
# transactions and waited on each other's row locks.
#
# In a SERVER process (``querystudio/cli.py`` binds the store) the key above is
# the MASTER key only: it unwraps the DATA keys every component reads from the
# database (``encryption_data_keys``, ``core/data_key_store.py``), so every
# component encrypts and decrypts with the SAME keys -- they cannot diverge.
#   * no data keys yet: ONLY the key owner (the API) creates them, once, under
#     a database lock -- a NEW random active key (the master key never encrypts
#     a secret again) plus every key used so far as RETIRED (each stored secret
#     stays readable, none is rewritten);
#   * a master key that opens no data key = MISMATCH: said with both
#     fingerprints; this component refuses to save a secret and writes nothing;
#   * a data key opened by a PREVIOUS master key (QUERY_STUDIO_SECRET_KEY_PREVIOUS
#     after a Vault rotation) is re-wrapped by the owner -- a handful of rows,
#     never a stored secret;
#   * nothing scans or rewrites stored secrets at start-up any more.
# No store bound (tests, one-off scripts) = the direct mode below, unchanged.
_DATA_KEY_STORE = None
_LAST_BUILD_TRY = 0.0
_LOADED_AT = 0.0
_LAST_RELOAD = 0.0
#: a component with no usable key looks again at most this often (a DB read)
_RETRY_SECONDS = 5.0
#: a component re-reads the data keys this often (another pod rotated them)
_REFRESH_SECONDS = 300.0


def bind_data_key_store(store) -> None:
    """THIS process is a server: its keys are the database's data keys
    (envelope mode).  Called once by ``querystudio/cli.py``."""
    global _DATA_KEY_STORE, _fernet, _LAST_BUILD_TRY
    _DATA_KEY_STORE = store
    _fernet = None
    _LAST_BUILD_TRY = 0.0

#: the last "no key" state logged (a waiting process looks on every use)
_LAST_NO_KEY = ""


def key_fingerprint(key: str) -> str:
    """A short, one-way label of a key (never the key) -- to compare pods."""
    import hashlib
    return hashlib.sha256(str(key).strip().encode()).hexdigest()[:12]


def _valid_key(key: str, source: str):
    from cryptography.fernet import Fernet
    try:
        Fernet(key.encode())
        return key
    except Exception as e:                                   # noqa: BLE001
        logger.error("[encryption-key] the key from %s is not a valid Fernet key (%s) -- ignored",
                     source, type(e).__name__)
        return None


def _key_file_path():
    from pathlib import Path
    try:
        from core.config import paths as _cfg_paths
        return Path(_cfg_paths.secret_key_file)
    except Exception:                                        # noqa: BLE001
        return Path(__file__).resolve().parent.parent / "data" / "secret.key"


def _read_key_file(path):
    try:
        if path.exists():
            stored = path.read_text().strip()
            return stored or None
    except Exception as e:                                   # noqa: BLE001
        logger.error("[encryption-key] the key file %s cannot be read: %s", path, e)
    return None


class EncryptionKeyUnavailable(RuntimeError):
    """No encryption key in this process (yet): a credential cannot be stored."""


def is_key_owner() -> bool:
    """Whether THIS process may create the key file.  ``QS_ENCRYPTION_KEY_OWNER``:
    the api chart sets true, every other component false; unset = owner (a
    single-process run, a developer machine, the tests)."""
    v = os.environ.get("QS_ENCRYPTION_KEY_OWNER", "").strip().lower()
    return v in ("", "1", "true", "yes", "on")


def _key_material():
    """``(primary or None, primary_source, [(previous, source), ...])`` -- the
    module docstring's resolution.  ``None`` = no key: WAITING for the
    owner's file (a non-owner), or NO KEY (the owner could not create it)."""
    from cryptography.fernet import Fernet
    previous = []
    path = _key_file_path()
    raw_env = os.environ.get("QUERY_STUDIO_SECRET_KEY", "").strip()
    env_key = _valid_key(raw_env, "QUERY_STUDIO_SECRET_KEY") if raw_env else None
    primary, source = None, ""
    if env_key:
        primary, source = env_key, "QUERY_STUDIO_SECRET_KEY"
        file_key = _read_key_file(path)
        if file_key and file_key != env_key and _valid_key(file_key, f"key file {path}"):
            previous.append((file_key, f"key file {path} (decrypt-only)"))
    else:
        file_key = _read_key_file(path)
        if file_key and _valid_key(file_key, f"key file {path}"):
            primary, source = file_key, f"key file {path}"
        elif not is_key_owner():
            source = (f"WAITING for the key the API creates at {path} (this component never "
                      f"creates one: QS_ENCRYPTION_KEY_OWNER=false)")
        else:
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                primary = _publish_key_file_once(path, Fernet.generate_key().decode())
                source = f"key file {path} (created by this process, the key owner)"
            except Exception as e:                           # noqa: BLE001
                source = (f"NO KEY: QUERY_STUDIO_SECRET_KEY is not set and the key file {path} "
                          f"cannot be created ({type(e).__name__}: {e})")
    for i, k in enumerate(x.strip() for x in os.environ.get(
            "QUERY_STUDIO_SECRET_KEY_PREVIOUS", "").replace("\n", ",").split(",")):
        if k and k != primary and _valid_key(k, f"QUERY_STUDIO_SECRET_KEY_PREVIOUS[{i}]"):
            previous.append((k, f"QUERY_STUDIO_SECRET_KEY_PREVIOUS[{i}] (decrypt-only)"))
    return primary, source, previous


#: what to do when there is no key -- every refusal says it
NO_KEY_FIX = ("Set QUERY_STUDIO_SECRET_KEY for every component (the api chart's Secret creates "
              "it), or let the API create the key file: make the folder of "
              "paths.secret_key_file writable for its user.")


def _build_fernet():
    if not _check_crypto():
        return None
    from cryptography.fernet import Fernet, MultiFernet
    primary, source, previous = _key_material()
    _KEY_STATUS.clear()
    _KEY_STATUS.update({
        "source": source, "fingerprint": key_fingerprint(primary) if primary else None,
        "available": bool(primary), "owner": is_key_owner(),
        "waiting": source.startswith("WAITING"), "ephemeral": False,
        "previous": [{"source": s, "fingerprint": key_fingerprint(k)} for k, s in previous]})
    if not primary:
        global _LAST_NO_KEY
        if source != _LAST_NO_KEY:          # said once per state, not on every look
            _LAST_NO_KEY = source
            (logger.warning if source.startswith("WAITING") else logger.error)(
                "[encryption-key] %s -- stored credentials cannot be read here yet, and none can "
                "be saved.  %s", source, NO_KEY_FIX)
        return None
    if _DATA_KEY_STORE is not None:
        return _build_envelope(primary, source, previous)
    _KEY_STATUS["mode"] = "direct"
    logger.info("[encryption-key] key from %s (fingerprint %s)%s", source, key_fingerprint(primary),
                "; decrypt-only: " + ", ".join(f"{s} ({key_fingerprint(k)})" for k, s in previous)
                if previous else "")
    keys = [Fernet(primary.encode())] + [Fernet(k.encode()) for k, _ in previous]
    return MultiFernet(keys) if len(keys) > 1 else keys[0]


def _data_key_row(key: str, master, master_fp: str, state: str, origin: str) -> Dict[str, Any]:
    return {"key_id": f"dk-{key_fingerprint(key)}", "wrapped": master.encrypt(key.encode()).decode(),
            "wrapped_by": master_fp, "state": state, "origin": origin}


def _bootstrap_rows(primary: str, previous) -> list:
    """A NEW random active data key + every key used so far, RETIRED (the
    values they encrypted stay readable, untouched)."""
    from cryptography.fernet import Fernet
    master, mfp = Fernet(primary.encode()), key_fingerprint(primary)
    new = Fernet.generate_key().decode()
    rows, seen = [_data_key_row(new, master, mfp, "active", "generated")], {new}
    for k in [primary] + [k for k, _ in previous]:
        if k not in seen:
            seen.add(k)
            rows.append(_data_key_row(k, master, mfp, "retired", "legacy"))
    return rows


def _no_key(reason: str, **extra):
    global _LAST_NO_KEY
    _KEY_STATUS.update({"available": False, "source": reason, **extra})
    if reason != _LAST_NO_KEY:
        _LAST_NO_KEY = reason
        (logger.warning if reason.startswith("WAITING") else logger.error)(
            "[encryption-key] %s -- stored credentials cannot be read here, and none can be "
            "saved.  %s", reason, NO_KEY_FIX)
    return None


def _build_envelope(primary: str, source: str, previous):
    """The data keys, opened with the master key (the block comment above)."""
    global _LOADED_AT
    from cryptography.fernet import Fernet, InvalidToken, MultiFernet
    store = _DATA_KEY_STORE
    master_fp = key_fingerprint(primary)
    _KEY_STATUS.update({"mode": "envelope", "master": {"source": source, "fingerprint": master_fp},
                        "mismatch": False, "data_keys": []})
    try:
        rows = store.list()
        if not rows:
            if not is_key_owner():
                return _no_key("WAITING for the API to create the data keys (this component never "
                               "creates them: QS_ENCRYPTION_KEY_OWNER=false)", waiting=True)
            rows = store.bootstrap(_bootstrap_rows(primary, previous))
    except Exception as exc:                                 # noqa: BLE001
        return _no_key(f"DATA KEYS UNREADABLE: the encryption_data_keys table could not be read "
                       f"({type(exc).__name__}: {exc}) -- unknown is not 'none'")
    opener = MultiFernet([Fernet(primary.encode())] + [Fernet(k.encode()) for k, _ in previous])
    opened, closed = [], []
    for r in rows:
        try:
            opened.append((r, opener.decrypt(r["wrapped"].encode()).decode()))
        except (InvalidToken, ValueError):
            closed.append(r)
    _KEY_STATUS["data_keys"] = (
        [{"key_id": r["key_id"], "state": r["state"], "origin": r.get("origin"),
          "wrapped_by": r["wrapped_by"], "opened": True} for r, _ in opened]
        + [{"key_id": r["key_id"], "state": r["state"], "origin": r.get("origin"),
            "wrapped_by": r["wrapped_by"], "opened": False} for r in closed])
    if not opened:
        wrapped_by = sorted({r["wrapped_by"] for r in rows})
        return _no_key(
            f"MASTER KEY MISMATCH: this component's master key ({source}, fingerprint "
            f"{master_fp}) opens none of this deployment's data keys (wrapped by "
            f"{', '.join(wrapped_by)}).  Give it the deployment's QUERY_STUDIO_SECRET_KEY (the "
            f"same Vault secret as the API); after a Vault rotation also "
            f"QUERY_STUDIO_SECRET_KEY_PREVIOUS = the old one.  Nothing was written",
            mismatch=True)
    if is_key_owner():
        master = Fernet(primary.encode())
        for r, key in opened:
            if r["wrapped_by"] != master_fp:          # opened by a PREVIOUS master key
                try:
                    store.rewrap(r["key_id"], master.encrypt(key.encode()).decode(), master_fp)
                    logger.warning("[encryption-key] data key %s re-wrapped from master %s to %s "
                                   "(no stored secret touched)", r["key_id"], r["wrapped_by"], master_fp)
                except Exception as exc:              # noqa: BLE001
                    logger.error("[encryption-key] data key %s could not be re-wrapped: %s",
                                 r["key_id"], exc)
    ordered = ([k for r, k in opened if r["state"] == "active"]
               + [k for r, k in reversed(opened) if r["state"] != "active"])
    _KEY_STATUS.update({"available": True, "fingerprint": key_fingerprint(ordered[0]),
                        "source": f"data key dk-{key_fingerprint(ordered[0])} (envelope; master from {source})"})
    if closed:
        logger.error("[encryption-key] %d data key(s) cannot be opened by this master key: %s -- "
                     "values they encrypted are unreadable here", len(closed),
                     ", ".join(r["key_id"] for r in closed))
    logger.info("[encryption-key] envelope: master %s from %s; %d data key(s), active %s",
                master_fp, source, len(opened), _KEY_STATUS["fingerprint"])
    _LOADED_AT = __import__("time").monotonic()
    keys = [Fernet(k.encode()) for k in ordered]
    return MultiFernet(keys) if len(keys) > 1 else keys[0]


def rotate_data_key() -> Dict[str, Any]:
    """A NEW active data key (the old ones retired, still decrypting).  The
    admin action of the key owner; nothing stored is rewritten."""
    global _fernet
    from cryptography.fernet import Fernet
    if _DATA_KEY_STORE is None:
        raise EncryptionKeyUnavailable("data keys are a server-process feature (envelope mode)")
    primary, _source, _previous = _key_material()
    if not primary or _get_fernet() is None:
        raise EncryptionKeyUnavailable(f"no usable key here: {_KEY_STATUS.get('source')}")
    new = Fernet.generate_key().decode()
    _DATA_KEY_STORE.add_active(_data_key_row(new, Fernet(primary.encode()), key_fingerprint(primary),
                                             "active", "generated"))
    _fernet = None
    return key_status()


def key_status() -> Dict[str, Any]:
    """Where this process's keys came from, by fingerprint (never a key)."""
    _get_fernet()
    return dict(_KEY_STATUS)


def _primary_only():
    """The primary key alone -- to tell 'current' from 'saved under an older key'."""
    f = _get_fernet()
    return getattr(f, "_fernets", [f])[0] if f is not None else None


def rotation_allowed() -> bool:
    """Re-encrypting stored secrets needs a key that outlives this process."""
    return _get_fernet() is not None


def rotate_value(value: str):
    """``(value, state)`` for ONE stored value: ``current`` (the primary reads
    it), ``rotated`` (an older key read it -- returned re-encrypted under the
    primary), ``unreadable`` (no key reads it -- returned UNCHANGED, never
    blanked), or ``plain`` (not encrypted)."""
    if not isinstance(value, str) or not value.startswith(_ENC_PREFIX):
        return value, "plain"
    token = value[len(_ENC_PREFIX):].encode()
    primary = _primary_only()
    if primary is None:
        return value, "unreadable"
    try:
        primary.decrypt(token)
        return value, "current"
    except Exception:                                        # noqa: BLE001
        pass
    f = _get_fernet()
    try:
        plain = f.decrypt(token)
    except Exception:                                        # noqa: BLE001
        # perhaps under a data key another pod added a moment ago: re-read once
        if not _reload_after_unknown_token():
            return value, "unreadable"
        return rotate_value(value)
    return _ENC_PREFIX + primary.encrypt(plain).decode(), "rotated"


def _publish_key_file_once(key_file, candidate: str) -> str:
    """Publish ``candidate`` at ``key_file`` unless a key is already there,
    and return THE key on disk -- ours if we won, the other pod's if we lost.

    ``os.link`` is atomic and refuses an existing name (POSIX and NFS), so
    two pods can never both believe they published.  Filesystems without
    hard links fall back to an exclusive create (``O_EXCL``)."""
    import time as _time
    from pathlib import Path
    key_file = Path(key_file)
    tmp = key_file.with_name(f".{key_file.name}.{os.getpid()}.{_time.time_ns()}.tmp")
    tmp.write_text(candidate)
    try:
        try:
            os.link(tmp, key_file)
            return candidate
        except FileExistsError:
            pass                                  # another pod published first
        except (AttributeError, NotImplementedError, OSError):
            # No hard links here: an exclusive create is the same promise.
            try:
                fd = os.open(str(key_file), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                with os.fdopen(fd, "w") as fh:
                    fh.write(candidate)
                return candidate
            except FileExistsError:
                pass
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass
    # Another pod published first: use ITS key.  The O_EXCL fallback can be
    # observed mid-write, so wait briefly for a complete key.
    for _ in range(50):
        stored = key_file.read_text().strip()
        if stored:
            return stored
        _time.sleep(0.1)
    raise RuntimeError(f"encryption key file {key_file} exists but stayed empty")


def _get_fernet():
    """The process key, resolved once -- except while there is NONE: then each
    use looks again (a non-owner picks the API's key file up the moment it
    appears, without a restart).  The look is cheap: an env read and a stat."""
    global _fernet, _LAST_BUILD_TRY
    import time as _t
    now = _t.monotonic()
    if _DATA_KEY_STORE is not None:
        # envelope mode: re-read the data keys now and then (another pod rotated
        # them); with NO usable key, look again at most every _RETRY_SECONDS --
        # a look is a database read, not a stat
        if _fernet is not None and now - _LOADED_AT > _REFRESH_SECONDS:
            _fernet = _refresh_keeping(_fernet, "scheduled re-read")
            return _fernet
        if _fernet is None and now - _LAST_BUILD_TRY < _RETRY_SECONDS:
            return None
        if _fernet is None:
            _LAST_BUILD_TRY = now
    if _fernet is None:
        _fernet = _build_fernet()
    return _fernet


def _reload_after_unknown_token() -> bool:
    """A value no data key here opens may be under a key another pod added a
    moment ago: re-read the data keys once (at most every 10 s)."""
    global _fernet, _LAST_RELOAD, _LAST_BUILD_TRY
    import time as _t
    if _DATA_KEY_STORE is None or _t.monotonic() - _LAST_RELOAD < 10:
        return False
    _LAST_RELOAD = _t.monotonic()
    if _fernet is None:
        _LAST_BUILD_TRY = 0.0
        return _get_fernet() is not None
    _fernet = _refresh_keeping(_fernet, "a value no loaded data key opens")
    return _fernet is not None


def reload_data_keys() -> bool:
    """Re-read the data keys NOW; True only when that read succeeded (the
    re-encrypt job must write under the active key the database has, not the
    one this pod loaded minutes ago).  A failed read keeps the loaded keys."""
    global _fernet, _LAST_BUILD_TRY
    if _DATA_KEY_STORE is None:
        return _get_fernet() is not None
    if _fernet is None:
        _LAST_BUILD_TRY = 0.0
        return _get_fernet() is not None
    _fernet = _refresh_keeping(_fernet, "the re-encrypt job's re-read")
    return "refresh_error" not in _KEY_STATUS


def _refresh_keeping(current, why: str):
    """Re-read the data keys, but NEVER lose a working keyset to a failed
    re-read.  A data key never changes once written (a re-wrap changes only its
    wrapping, a rotation only ADDS one), so keys loaded earlier stay right: a
    database blip, or a pod still on the old master after another pod
    re-wrapped the rows for a Vault rotation, keeps decrypting and encrypting
    with them -- and says why its re-read failed -- instead of every stored
    credential reading "" until it restarts."""
    global _LOADED_AT
    import time as _t
    before = dict(_KEY_STATUS)
    fresh = _build_fernet()
    if fresh is not None:
        return fresh
    reason = _KEY_STATUS.get("source")
    _KEY_STATUS.clear()
    _KEY_STATUS.update(before)
    _KEY_STATUS["refresh_error"] = f"{why}: {reason} -- still using the data keys loaded earlier"
    logger.error("[encryption-key] re-reading the data keys failed (%s); keeping the %s loaded "
                 "earlier", reason, before.get("fingerprint"))
    # look again in a minute, not on every use
    _LOADED_AT = _t.monotonic() - _REFRESH_SECONDS + 60.0
    return current


# ── Public API ─────────────────────────────────────────────────────────────────

def encrypt_value(plaintext: str) -> str:
    """Encrypt a single string value.  Returns ``enc::<base64token>``.
    If cryptography is not installed, returns the plaintext unchanged (with a log warning)."""
    if not plaintext:
        return plaintext
    if plaintext.startswith(_ENC_PREFIX):
        return plaintext  # already encrypted — idempotent
    fernet = _get_fernet()
    if fernet is None:
        if not _check_crypto():
            return plaintext  # cryptography unavailable — store as plaintext
        raise EncryptionKeyUnavailable(
            f"A credential cannot be saved: this component has no encryption key "
            f"({_KEY_STATUS.get('source')}).  {NO_KEY_FIX}")
    token = fernet.encrypt(plaintext.encode()).decode()
    return f"{_ENC_PREFIX}{token}"


def decrypt_value(value: str) -> str:
    """Decrypt a single encrypted value.  Pass-through for unencrypted strings."""
    if not value or not value.startswith(_ENC_PREFIX):
        return value
    fernet = _get_fernet()
    if fernet is None:
        return ""  # no key here (yet): unreadable -- said by key_status / the sweep
    token = value[len(_ENC_PREFIX):]
    try:
        return fernet.decrypt(token.encode()).decode()
    except Exception:
        if _reload_after_unknown_token():
            try:
                return _get_fernet().decrypt(token.encode()).decode()
            except Exception:                                # noqa: BLE001
                pass
        logger.error(
            "Credential decryption failed — key mismatch or corrupted value. "
            "Check QUERY_STUDIO_SECRET_KEY."
        )
        return ""  # return empty rather than crash; callers will fail at connect time


def masked_for_client(stored_config: Dict[str, Any]) -> Dict[str, Any]:
    """The STORED config as a browser may see it: every sensitive field that
    holds a value becomes ``"***"`` -- decided by PRESENCE, without
    decrypting (2026-10-02).

    ``mask_config(decrypt_config(stored))`` masked only what decrypted to
    something; a value that could not be decrypted (a key change) came back
    ``""`` and the edit form showed the password BLANK, and a Save then wrote
    that blank over the stored credential.  Presence is what masking needs;
    whether the value can be READ is a separate question --
    :func:`undecryptable_fields`."""
    if not stored_config:
        return stored_config
    return _map_sensitive(stored_config, lambda k, v: "***" if v else v)


def _map_sensitive(config: Any, fn) -> Any:
    """Apply ``fn(field, value)`` to every SENSITIVE field of ``config`` --
    at ANY depth (2026-10-12).  Every rule below walked the top level only,
    so a secret nested one level down -- a Trino connection's
    ``unload_s3_access.aws_secret_access_key`` -- was stored in PLAIN TEXT
    and served UNMASKED to the browser (found live on the rig).  Dicts are
    copied, never mutated; lists of dicts are walked too."""
    if isinstance(config, dict):
        out = {}
        for k, v in config.items():
            if k in SENSITIVE_FIELDS and not isinstance(v, (dict, list)):
                out[k] = fn(k, v)
            else:
                out[k] = _map_sensitive(v, fn)
        return out
    if isinstance(config, list):
        return [_map_sensitive(v, fn) for v in config]
    return config


def _sensitive_paths(config: Any, path: str = ""):
    """(dotted path, value) of every sensitive field, at any depth."""
    if isinstance(config, dict):
        for k, v in config.items():
            p = f"{path}.{k}" if path else str(k)
            if k in SENSITIVE_FIELDS and not isinstance(v, (dict, list)):
                yield p, v
            else:
                yield from _sensitive_paths(v, p)
    elif isinstance(config, list):
        for i, v in enumerate(config):
            yield from _sensitive_paths(v, f"{path}[{i}]")


def has_masked(config: Any) -> bool:
    """Does ``config`` carry a ``"***"`` in a sensitive field, at any depth?"""
    return any(v == "***" for _, v in _sensitive_paths(config or {}))


def undecryptable_fields(stored_config: Dict[str, Any]) -> list:
    """Sensitive fields (dotted paths, at any depth) whose STORED value cannot
    be decrypted with this process's key (the key changed since it was
    saved).  Unknown is not empty: such a field is still SAVED, it just
    cannot be read here."""
    return sorted(p for p, val in _sensitive_paths(stored_config or {})
                  if isinstance(val, str) and val.startswith(_ENC_PREFIX) and not decrypt_value(val))


def encrypt_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *config* with all sensitive fields encrypted (any depth)."""
    if not config:
        return config
    return _map_sensitive(config, lambda k, v: encrypt_value(v) if v and isinstance(v, str) else v)


def decrypt_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *config* with all sensitive fields decrypted (any depth)."""
    if not config:
        return config
    return _map_sensitive(config, lambda k, v: decrypt_value(v) if v and isinstance(v, str) else v)


def restore_masked(new_config: Any, plain_config: Any, stored_config: Any = None,
                   on_undecryptable=None) -> Any:
    """THE rule for a form saved with ``"***"`` (any depth): a sensitive field
    sent as ``"***"`` takes the stored DECRYPTED value; a stored value this
    process cannot decrypt (``enc::`` that decrypts to nothing -- a key
    change) is KEPT as stored, encrypted, and ``on_undecryptable(path)`` is
    told; nothing stored -> "".  Everything else is the new value.  The
    update and the test-connection routes all read this one function."""
    def walk(new, plain, stored, path):
        if isinstance(new, dict):
            plain = plain if isinstance(plain, dict) else {}
            stored = stored if isinstance(stored, dict) else {}
            out = {}
            for k, v in new.items():
                p = f"{path}.{k}" if path else str(k)
                if k in SENSITIVE_FIELDS and v == "***":
                    real = plain.get(k)
                    if real:
                        out[k] = real
                    elif str(stored.get(k) or "").startswith(_ENC_PREFIX):
                        if on_undecryptable:
                            on_undecryptable(p)
                        out[k] = stored[k]
                    else:
                        out[k] = ""
                else:
                    out[k] = walk(v, plain.get(k), stored.get(k), p)
            return out
        if isinstance(new, list):
            pl = plain if isinstance(plain, list) else []
            st = stored if isinstance(stored, list) else []
            return [walk(v, pl[i] if i < len(pl) else None, st[i] if i < len(st) else None, f"{path}[{i}]")
                    for i, v in enumerate(new)]
        return new
    return walk(new_config, plain_config, stored_config, "")


def mask_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of *config* with sensitive fields replaced by ``"***"``.
    Safe to return to API clients / browser -- at ANY depth (2026-10-12)."""
    if not config:
        return config
    return _map_sensitive(config, lambda k, v: "***" if v else v)
