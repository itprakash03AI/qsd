"""qs_credentials.resolver -- QS API facade for vault-backed creds.

DB-driven twin of the ETL facade.  Reads SystemAccount rows from the
``system_accounts`` table (per-row vault ref columns) instead of
vault_config.yaml.  Same chokepoint (qs_credentials.vault) + same
cache (qs_credentials.cache.QSCredCache) as ETL.

Use ``resolve_system_account(name_or_id)`` for every cred-fetch site
that consumes a SystemAccount row.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
import time
from typing import Any, Dict, Optional, Tuple, Union

# Relative imports work in the backend pod (single PYTHONPATH layout).
# The shared library (``cache.py`` + ``vault/``) is byte-identical
# with ``ETL/qs_credentials/``; CI contract test ``TestSyncedCopies``
# fails when the two drift.
from .cache import QSCredCache
from .vault import is_valid_vault_payload, fetch_secret_with_vendor_fallback

logger = logging.getLogger(__name__)

# ────────────────────────────────────────────────────────────────────────
#  Global enable/disable
# ────────────────────────────────────────────────────────────────────────


def vault_explicitly_disabled(
    workflow_config: Optional[Dict[str, Any]] = None,
) -> bool:
    """Did an operator DELIBERATELY turn vault off?

    ``is_vault_enabled`` answers "is vault on", which conflates two very
    different states: "an operator switched it off" and "nobody set the
    global flag".  For a resource that ALREADY declares vault -- an Oracle
    ``secret_ref``, a Starburst ``secret_ref``, a system account with
    ``use_vault=True`` -- that conflation is a foot-gun: the declaration IS
    the opt-in, and demanding a second flag agree means a correctly
    configured account fails with "vault is DISABLED" until someone finds
    the other switch.  Two places having to agree is the defect class this
    codebase keeps paying for.

    So callers holding such a declaration use THIS instead: proceed unless
    vault was explicitly killed.

    Explicit OFF means exactly:
      * ``ETL_USE_VAULT`` in {0, false, no}  -- the fleet-wide kill switch,
        which must keep winning over everything; or
      * a per-workflow ``vault_enabled`` set to an explicit falsey value --
        the mixed-posture opt-out (Starburst on vault, Oracle on literals).

    A merely-absent global ``secrets.enabled`` is NOT explicit off.
    """
    env = (os.environ.get("ETL_USE_VAULT") or "").strip().lower()
    if env in ("0", "false", "no"):
        return True
    if isinstance(workflow_config, dict):
        wf_flag = workflow_config.get("vault_enabled")
        if wf_flag is None or str(wf_flag).strip() == "":
            for section_key in ("oracle", "starburst", "s3"):
                sub = workflow_config.get(section_key)
                if isinstance(sub, dict):
                    sub_flag = sub.get("vault_enabled")
                    if sub_flag is not None and str(sub_flag).strip() != "":
                        wf_flag = sub_flag
                        break
        if wf_flag is not None and str(wf_flag).strip() != "":
            return str(wf_flag).strip().lower() not in ("1", "true", "yes")
    return False


def is_vault_enabled(account_use_vault: Optional[bool] = None) -> bool:
    """Three-layer toggle for QueryStudio vault resolution.

    Resolution order (highest priority wins):

      1. ``QS_USE_VAULT`` env var
         * "1" / "true" / "yes"  -> ON  (returns True immediately)
         * "0" / "false" / "no"  -> OFF (returns False immediately)
         * unset / blank          -> defer to layer 2
      2. Per-account ``use_vault`` column on the SystemAccount row
         (when caller passes it).
      3. Global ``secrets.enabled`` from ``core.config`` (default
         False -- dev-safe).
    """
    env = os.environ.get("QS_USE_VAULT", "").strip().lower()
    if env in ("1", "true", "yes"):
        return True
    if env in ("0", "false", "no"):
        return False

    if account_use_vault is not None:
        return bool(account_use_vault)

    # Layer 3: read from core.config when available.  Falls back to
    # False (dev-safe) when the config block is missing.
    try:
        from core.config import secrets as _secrets_cfg
        return bool(getattr(_secrets_cfg, "enabled", False))
    except Exception:
        return False


# ────────────────────────────────────────────────────────────────────────
#  Shared cache + retry/stale fallback (Phase 158 chokepoint)
# ────────────────────────────────────────────────────────────────────────


def _qs_disk_cache_settings() -> Dict[str, Any]:
    """Pod-specific settings provider for the shared QSCredCache.

    Read from ``core.config.secrets.*`` -- QS's own knobs (which
    parallel ETL's ``vault_config.yaml -> secrets.vault.*``).  Both
    pods share cache lines via the disk Fernet path; both files
    consume the SAME QSCredCache class so future hardening lives in
    ONE place.
    """
    try:
        from core.config import secrets as _s
    except Exception:
        _s = None
    return {
        "enabled": bool(getattr(_s, "disk_cache_enabled", True)),
        "path":    str(getattr(_s, "disk_cache_path",
                                "/tmp/.qs_secrets.enc")),
        "ttl":     int(getattr(_s, "disk_cache_ttl_seconds", 86400) or 0),
        "key_env": str(getattr(_s, "disk_cache_key_env",
                                "QS_SECRETS_KEY")),
        "mem_ttl": int(getattr(_s, "cache_ttl_seconds", 900) or 0),
    }


# Pod-singleton instance of the shared cache.
_cred_cache = QSCredCache(
    settings_provider=_qs_disk_cache_settings,
    plaintext_env_var="QS_SECRETS_ALLOW_PLAINTEXT",
    logger=logger,
)


# ────────────────────────────────────────────────────────────────────────
#  Phase 158 R5 -- periodic refresh daemon (mirrors ETL/qs_credentials/resolver.py)
# ────────────────────────────────────────────────────────────────────────
#
# Bounds the rotation propagation window on the QS API pod.  The
# mem_ttl (default 15 min) already guarantees Vault rotations get
# picked up within 15 min on the happy path, but a hot system_account
# that's continuously re-cached will never hit the natural TTL
# expiry.  This periodic invalidation forces a fresh fetch every
# ``QS_CRED_REFRESH_HOURS`` hours (default 24h).
#
# Set ``QS_CRED_REFRESH_HOURS=0`` to disable (tests, dev pods).
# Phase 158 R10 (2026-06-28) -- resolution order: env var ->
# core.config.secrets.cred_refresh_hours -> 24h default.  Admin UI
# edits land in the config layer.
def _resolve_refresh_hours() -> float:
    raw = os.environ.get("QS_CRED_REFRESH_HOURS", "").strip()
    if raw:
        try:
            return float(raw)
        except ValueError:
            logger.warning(
                "QS_CRED_REFRESH_HOURS=%r is not a float -- "
                "falling through to config.", raw,
            )
    try:
        from core.config import secrets as _s
        return float(getattr(_s, "cred_refresh_hours", 24) or 24)
    except Exception:
        return 24.0


_REFRESH_HOURS = _resolve_refresh_hours()
_cred_cache.start_periodic_refresh(
    _REFRESH_HOURS, name_hint="qs-cred-cache-refresh",
)


# Back-compat aliases -- existing call sites + tests use these names.
def _cache_get_fresh(name: str) -> Optional[Any]:
    return _cred_cache.mem_get_fresh(name)


def _cache_get_any(name: str) -> Optional[Any]:
    return _cred_cache.mem_get_any(name)


def _cache_put(name: str, payload: Any, ttl_seconds: int) -> None:
    _cred_cache.mem_put(name, payload, ttl_seconds)


def invalidate(name: str) -> None:
    """Drop the cached entry -- call after an auth failure so the
    next resolve fetches a fresh secret."""
    _cred_cache.invalidate(name)


def reset_cache() -> None:
    """Test hook -- wipe in-process cache."""
    _cred_cache.reset_mem()


def _disk_cache_settings() -> Dict[str, Any]:
    """Back-compat alias; the public name some tests still grep for."""
    return _qs_disk_cache_settings()


def _disk_cache_get_fresh(name: str) -> Optional[Any]:
    return _cred_cache.disk_get_fresh(name)


def _disk_cache_get_any(name: str) -> Optional[Any]:
    return _cred_cache.disk_get_any(name)


def _disk_cache_put(name: str, payload: Any) -> None:
    _cred_cache.disk_put(name, payload)


def disk_cache_clear() -> None:
    _cred_cache.disk_clear()


def _is_valid_payload(payload: Any, secret_type: str) -> bool:
    """Back-compat alias to the shared chokepoint validator."""
    return is_valid_vault_payload(payload, secret_type)


def _call_qsclient(name: str, ref: Dict[str, Any]) -> Any:
    """Back-compat thin wrapper over the chokepoint vault-call ladder.
    Older tests / call sites import this name directly."""
    try:
        from core.config import secrets as _s
        machine = getattr(_s, "machine", "openshift")
        token_method = getattr(_s, "token_method", "JWT")
    except Exception:
        machine = "openshift"
        token_method = "JWT"
    return fetch_secret_with_vendor_fallback(
        name, ref, machine=machine, token_method=token_method,
    )


# ────────────────────────────────────────────────────────────────────────
#  Public API
# ────────────────────────────────────────────────────────────────────────


def _fetch_with_fallback(name: str, ref: Dict[str, Any]) -> Any:
    """Vault call with 2x retry + last-known-good cache fallback.

    Phase 158 (2026-06-26) -- delegates the algorithm to the shared
    ``QSCredCache.fetch_with_fallback`` so it stays in lockstep with
    ETL.  This file owns only the QS-specific machine + token_method
    lookup (from ``core.config.secrets``).
    """
    try:
        from core.config import secrets as _s
        machine = getattr(_s, "machine", "openshift")
        token_method = getattr(_s, "token_method", "JWT")
    except Exception:
        machine = "openshift"
        token_method = "JWT"
    return _cred_cache.fetch_with_fallback(
        name, ref, machine=machine, token_method=token_method,
    )


def _row_by_name_decrypted(db_manager: Any, name: str) -> Optional[Dict[str, Any]]:
    """Load a system_account row by NAME with the password DECRYPTED.

    2026-07-09 fix: the resolver must NOT read through the plain
    ``get_system_account_by_name`` -- on the real (Postgres) db_manager that
    method MASKS the password to ``'***'`` (API-safe; ``test_phase87`` relies on
    it), which the non-vault branch then rejects via the ``'***'`` guard,
    breaking name-based resolution of non-vault accounts.  Prefer the
    convention-correct ``*_raw`` variant (mirrors the id-path's
    ``get_system_account_raw``); fall back to the non-raw name lookup only for
    older managers / test fakes that decrypt under that name.
    """
    if hasattr(db_manager, "get_system_account_by_name_raw"):
        return db_manager.get_system_account_by_name_raw(name)
    return db_manager.get_system_account_by_name(name)


def secret_cache_key(row: Dict[str, Any]) -> Optional[str]:
    """THE cache key of an account's secret (2026-11-04, the owner: "vault based connection
    failing ... if same vault used with multiple connections").  Secret Ref is free text and not
    unique, and it was the whole key: two accounts given one ref were handed whichever secret was
    read first, another account's login, or a shape that fails.  So a ref also names WHERE it
    reads.  Accounts reading the same entry still share one read.  A ref equal to the account's own Name stays as it was, unique."""
    ref = str(row.get("secret_ref") or "").strip()
    if not ref or ref == row.get("name"):
        return row.get("name") or None
    where = f"{row.get('secret_type') or ''}|{row.get('vault_secret_url') or ''}"
    return f"{ref}#{hashlib.sha256(where.encode()).hexdigest()[:12]}"


def _row_to_ref(row: Dict[str, Any]) -> Dict[str, Any]:
    """Build the QSClient ``ref`` dict from a SystemAccount row.
    Same field names as ETL's vault_config.yaml entries so the call
    shape is interchangeable."""
    return {
        "type":       row.get("secret_type") or "",
        "auth_url":   row.get("vault_auth_url") or "",
        "role_name":  row.get("vault_role_name") or "",
        "role_type":  row.get("vault_role_type") or "",
        "secret_url": row.get("vault_secret_url") or "",
        "rotate_url": row.get("vault_rotate_url") or "",
        # 2026-07-13 — ETL PARITY: AppRole / JWT-step-up fields so the vault
        # dance (identical to ETL) can do token_method="approle" from
        # QueryStudio.  Blank/absent for JWT accounts (harmless — the JWT
        # branch uses ROLE_NAME + AUTH_URL only).  Mirrors the keys ETL's
        # vault_config.yaml ref carries (see qs_credentials/vault/__init__.py).
        "step_up_name":          row.get("vault_step_up_name") or "",
        "step_up_auth_url":      row.get("vault_step_up_auth_url") or "",
        "approle_secret_id_url": row.get("vault_approle_secret_id_url") or "",
        "approle_auth_url":      row.get("vault_approle_auth_url") or "",
        "role_id":               row.get("vault_role_id") or "",
    }


def resolve_system_account(
    name_or_id: Union[str, int],
    *,
    db_manager: Any = None,
) -> Dict[str, Any]:
    """Single chokepoint -- resolve a SystemAccount row to its
    runtime credentials.

    Args:
      name_or_id:  SystemAccount row id (int) or name (str).
      db_manager:  optional override; falls back to
                    ``core.database.db_manager`` (the global instance
                    that the rest of the codebase uses).

    Returns:
      A dict shape per ``account_type`` + ``secret_type``:

        DB_accounts / AD_accounts ->
            {"username": "...", "password": "..."}

        kv_secrets ->
            the full kv dict from QSClient (typically
            {"access_key": "...", "secret_key": "...", ...})

    Behaviour:
      * ``use_vault=False`` on the row -> returns the row's
        ``username`` + decrypted ``password`` column (back-compat).
        Operator can flip use_vault=True per account WITHOUT
        re-onboarding any callers.
      * ``use_vault=True`` AND vault is globally enabled -> fires
        QSClient + caches as documented above.
      * ``use_vault=True`` but vault globally disabled (env / config)
        -> raises with the SAME three-place actionable message
        ETL/qs_credentials/resolver uses so operators see one consistent
        toggle story.

    Raises:
      ValueError on row not found.
      RuntimeError on vault disabled-but-required + on all-fallbacks-
                    exhausted (mirrors ETL semantics).
    """
    # BUG-FIX 2026-06-25 -- ``core.database`` exposes ``get_db_manager()``
    # + ``set_db_manager()`` + ``_GLOBAL_DB_MANAGER`` (private) but NOT a
    # bare ``db_manager`` symbol.  Importing ``from core.database import
    # db_manager`` raises ImportError at runtime.  Use the public
    # accessor instead.
    if db_manager is None:
        from core.database import get_db_manager  # type: ignore
        db_manager = get_db_manager()
        if db_manager is None:
            raise RuntimeError(
                "QS qs_credentials: DatabaseManager not initialised yet "
                "(get_db_manager() returned None).  Resolver was called "
                "before main.py wired the global DB manager."
            )

    # 2026-10-30 -- did a PEER pod change a System Account since this pod
    # last looked?  Throttled (one PK SELECT per cache.coherence_poll_seconds)
    # and fail-open; on a change every cached credential here is distrusted
    # before the lookup below (core/qs_credentials/freshness.py).
    from core.qs_credentials import freshness as _fresh_observe
    _fresh_observe.observe()

    # Load the row WITH DECRYPTED password.  BUG-FIX 2026-06-25 --
    # the original id-based path called ``get_system_account(int)``
    # which MASKS the password (returns "***") because it's the
    # API-safe variant.  The legacy-path callers then propagated
    # "***" as a literal password to drivers, producing auth failures
    # with a misleading error.  Both code paths below now return
    # the decrypted password.
    row: Optional[Dict[str, Any]] = None
    try:
        if isinstance(name_or_id, int) or (
            isinstance(name_or_id, str) and name_or_id.isdigit()
        ):
            # id-based: ``get_system_account_raw`` decrypts.  Falls
            # through to the AttributeError branch on older db_managers
            # that don't expose it (e.g. test fakes from before this
            # commit).
            row = db_manager.get_system_account_raw(int(name_or_id))
        else:
            # name-based: read the DECRYPTED row (the plain
            # get_system_account_by_name MASKS on the real db_manager).
            row = _row_by_name_decrypted(db_manager, str(name_or_id))
    except AttributeError:
        # Older db_manager fallback -- raw SQL via SystemAccount model.
        # Pulls the row WITH ``include_password=True`` so the legacy
        # decrypt below works.  No "***" risk here.
        from core.db.models import SystemAccount  # type: ignore
        from core.crypto import decrypt_value  # type: ignore
        with db_manager.get_session(read_only=True) as session:
            q = session.query(SystemAccount)
            if isinstance(name_or_id, int) or (
                isinstance(name_or_id, str) and name_or_id.isdigit()
            ):
                row_obj = q.filter(SystemAccount.id == int(name_or_id)).first()
            else:
                row_obj = q.filter(
                    SystemAccount.name == str(name_or_id),
                ).first()
            if row_obj:
                row = row_obj.to_dict(include_password=True)
                try:
                    row["password"] = decrypt_value(row.get("password") or "")
                except Exception:
                    # Decrypt failure here is OK for vault-only accounts
                    # (the password column is meaningless when
                    # use_vault=True); the resolver's vault branch
                    # never reads ``row["password"]``.
                    row["password"] = ""

    if not row:
        raise ValueError(
            f"SystemAccount {name_or_id!r} not found.  Either create "
            f"the row via /api/admin/system-accounts OR pass a valid id."
        )
    if not row.get("is_active", True):
        raise RuntimeError(
            f"SystemAccount {name_or_id!r} is INACTIVE -- flip "
            f"is_active=True before resolution.")

    use_vault_row = bool(row.get("use_vault", False))

    # Legacy / back-compat path: just return the stored row.
    if not use_vault_row:
        password = row.get("password") or ""
        # BUG-FIX 2026-06-25 -- if the password somehow still arrives
        # as the literal "***" masking placeholder (test fakes,
        # malformed row, or a db_manager that doesn't surface the
        # decrypted column), refuse loudly instead of returning the
        # placeholder to the caller.  Returning "***" as the literal
        # password leads to silent driver auth failures.
        if password == "***":
            raise RuntimeError(
                f"SystemAccount {name_or_id!r} password column came "
                f"back masked ('***').  The resolver requires a "
                f"db_manager that decrypts the column (e.g. "
                f"get_system_account_raw / get_system_account_by_name)."
            )
        return {
            # Canonical row id -- callers that audit MUST use this
            # over the operator-supplied name_or_id so two paths
            # ("prod-svc" vs "42") audit identically.  Added 2026-06-25
            # after the materialise endpoint's audit-evasion bug-A.
            "id":           row.get("id"),
            "username":     row.get("username") or "",
            "password":     password,
            "account_type": row.get("account_type"),
            "via":          "encrypted_column",
        }

    # use_vault=True on the row IS the opt-in: layer 2 of is_vault_enabled
    # returns on the per-account hint, so the global `secrets.enabled` is
    # never consulted on this path.  The ONLY thing that can reach the raise
    # below is the explicit QS_USE_VAULT kill switch.
    if not is_vault_enabled(account_use_vault=True):
        raise RuntimeError(
            f"SystemAccount {name_or_id!r} has use_vault=True but "
            f"QS_USE_VAULT is set to an explicit OFF value on this pod. "
            f"That kill switch wins by design.  Either unset / flip "
            f"QS_USE_VAULT, or set use_vault=False on the account and use "
            f"the encrypted password column (DEV only).  NOTE: the global "
            f"core.config.secrets.enabled flag does NOT gate this path -- a "
            f"vault-backed system account resolves without it."
        )

    ref_name = secret_cache_key(row)
    if not ref_name:
        raise RuntimeError(
            f"SystemAccount id={row.get('id')} has use_vault=True but "
            f"no secret_ref or name -- nothing to look up in vault.")

    # Required ref fields validation.
    ref = _row_to_ref(row)
    required = ("type", "auth_url", "role_name", "role_type", "secret_url")
    missing = [k for k in required if not ref.get(k)]
    if missing:
        raise RuntimeError(
            f"SystemAccount {ref_name!r} has use_vault=True but is "
            f"missing required vault field(s): {missing}.  Update the "
            f"row's vault_auth_url / vault_role_name / vault_role_type "
            f"/ vault_secret_url + secret_type columns."
        )

    # 2026-10-30 -- a name the source REJECTED (or that a peer pod announced
    # as changed) is DISTRUSTED: neither cache layer answers, and the stale
    # fallback is not consulted -- the stale value IS the rejected password.
    # core/qs_credentials/freshness.py owns the rule; this is where the
    # resolver obeys it.
    from core.qs_credentials import freshness as _fresh
    if _fresh.is_distrusted(ref_name):
        payload = _fetch_strict(ref_name, ref)
        return _payload_to_creds(payload, ref["type"], row)

    # Cache layer 1: in-process (only fresh).
    fresh = _cache_get_fresh(ref_name)
    if fresh is not None:
        return _payload_to_creds(fresh, ref["type"], row)

    # Cache layer 2: disk (only fresh).
    disk_fresh = _disk_cache_get_fresh(ref_name)
    if disk_fresh is not None:
        _cache_put(ref_name, disk_fresh, _disk_cache_settings()["mem_ttl"])
        return _payload_to_creds(disk_fresh, ref["type"], row)

    # Vault (with built-in retry + last-known-good fallback -- for Vault
    # being DOWN, never for a wrong password: see _fetch_strict).
    payload = _fetch_with_fallback(ref_name, ref)
    return _payload_to_creds(payload, ref["type"], row)


def _fetch_strict(name: str, ref: Dict[str, Any]) -> Any:
    """Vault, or the reason -- NO stale / last-known-good fallback.

    Used for a DISTRUSTED name (the source rejected the cached secret, or a
    peer pod announced the account changed).  ``fetch_with_fallback`` would
    serve the last-known-good value when Vault fails, which is right for a
    Vault outage and wrong here: that value is the password the source just
    refused, and serving it again would log in with the old password for
    another TTL -- the owner's "it tries with old pwd" for 20-30 minutes.
    Two attempts (a transient blank), then the failure is said.  A valid
    answer lands in both cache layers (the disk entry is OVERWRITTEN, which
    is how the stale disk value is retired) and the name is trusted again.
    """
    from core.qs_credentials import freshness as _fresh
    try:
        from core.config import secrets as _s
        machine = getattr(_s, "machine", "openshift")
        token_method = getattr(_s, "token_method", "JWT")
    except Exception:
        machine = "openshift"
        token_method = "JWT"
    secret_type = ref.get("type") or ""
    last_problem = None
    with _cred_cache._get_fetch_lock(name):
        # Another thread may have refreshed it while we waited for the lock.
        if not _fresh.is_distrusted(name):
            cached = _cred_cache.mem_get_fresh(name)
            if cached is not None:
                return cached
        for attempt in (1, 2):
            fetch_out: Dict[str, Any] = {}
            try:
                payload = fetch_secret_with_vendor_fallback(
                    name, ref, machine=machine, token_method=token_method,
                    _out=fetch_out)
            except Exception as exc:
                last_problem = f"{type(exc).__name__}: {exc}"
                logger.warning("Vault strict fetch attempt %d for secret_ref=%r "
                               "raised %s", attempt, name, last_problem)
                continue
            if is_valid_vault_payload(payload, secret_type):
                ttl = int(_qs_disk_cache_settings().get("mem_ttl", 0) or 0)
                lease = fetch_out.get("lease_duration")
                if isinstance(lease, int) and lease > 0:
                    ttl = min(lease, ttl) if ttl > 0 else lease
                _cred_cache.mem_put(name, payload, ttl)
                _cred_cache.disk_put(name, payload)
                _fresh.trust(name)
                logger.warning(
                    "[credential-freshness] pod %s re-read secret_ref=%r from "
                    "Vault after it was distrusted (attempt %d); caches refilled",
                    _fresh.pod_name(), name, attempt)
                return payload
            last_problem = (f"invalid payload (type={secret_type}): "
                            f"{fetch_out.get('invalid_reason') or '<unknown>'}")
            logger.warning("Vault strict fetch attempt %d for secret_ref=%r "
                           "returned an %s", attempt, name, last_problem)
    raise RuntimeError(
        f"secret_ref={name!r}: the cached credential was rejected by the "
        f"source (or changed by an administrator) and Vault could not be "
        f"read for a fresh one after 2 attempts ({last_problem}).  The "
        f"last-known-good value is deliberately NOT used: it is the "
        f"credential that was rejected.  Fix Vault access or the secret, "
        f"then retry.")


def _payload_to_creds(
    payload: Any, secret_type: str, row: Dict[str, Any],
) -> Dict[str, Any]:
    """Normalise a QSClient payload to the QueryStudio creds dict
    shape (so all callers consume the same {username, password, ...}
    structure)."""
    if secret_type in ("DB_accounts", "AD_accounts"):
        if isinstance(payload, (tuple, list)) and len(payload) >= 2:
            tns = (str(payload[2])
                   if len(payload) >= 3 and payload[2] else "")
            return {
                # Canonical row id (audit-correlation key).
                "id":            row.get("id"),
                "username":      str(payload[0]),
                "password":      str(payload[1]),
                "tns_alias":     tns,
                "account_type":  row.get("account_type"),
                "via":           "vault",
            }
    elif secret_type == "kv_secrets":
        if isinstance(payload, dict):
            out = dict(payload)
            # If the vault payload already had its own "id" key (rare
            # but possible -- some vaults ship a "secret_id" or similar
            # under "id"), preserve it under "vault_id" so the audit
            # path can use the SystemAccount row id without losing the
            # vault-side identifier.
            if "id" in out:
                out["vault_id"] = out["id"]
            # Canonical row id -- ALWAYS the SystemAccount id for
            # audit-correlation consistency across DB / vault / kv
            # shapes.
            out["id"] = row.get("id")
            out["account_type"] = row.get("account_type")
            out["via"] = "vault"
            return out
    raise RuntimeError(
        f"Vault payload shape doesn't match secret_type={secret_type!r} "
        f"for SystemAccount id={row.get('id')}."
    )


def fill_creds_from_system_account(
    config: Dict[str, Any],
    account_name_or_id: Union[str, int],
    *,
    user_key: str = "username",
    password_key: str = "password",
    access_key_key: str = "access_key",
    secret_key_key: str = "secret_key",
    db_manager: Any = None,
) -> Dict[str, Any]:
    """Mutate ``config`` in-place: fill blanks from the resolved
    SystemAccount.  Mirrors ETL/fill_creds_from_ref semantics --
    literal values in ``config`` ALWAYS win over the resolved
    creds (operator override beats vault).

    Handles both DB/AD accounts (user/password) and kv_secrets
    (AWS access_key/secret_key etc.) automatically based on the
    resolved payload shape.
    """
    creds = resolve_system_account(account_name_or_id, db_manager=db_manager)

    if creds.get("via") == "vault" and creds.get("account_type") in (
        None,
    ):
        pass  # nothing extra

    # DB/AD-style (user, password) creds
    if creds.get("username") and not config.get(user_key):
        config[user_key] = creds["username"]
    if creds.get("password") and not config.get(password_key):
        config[password_key] = creds["password"]

    # kv-style (AWS keys etc.) -- common fields surfaced explicitly
    # so the connector code doesn't need to introspect.
    for k_resolved, k_target in (
        ("access_key", access_key_key),
        ("secret_key", secret_key_key),
        ("session_token", "session_token"),
        ("endpoint_url", "endpoint_url"),
        ("region", "region"),
    ):
        v = creds.get(k_resolved)
        if v and not config.get(k_target):
            config[k_target] = v

    return config


# ────────────────────────────────────────────────────────────────────────
#  Phase 158 R5 -- auth-failure refresh + retry helpers
#  (mirrors ETL/qs_credentials/resolver.py shape)
# ────────────────────────────────────────────────────────────────────────


def refresh(
    name_or_id: Union[str, int],
    *,
    db_manager: Any = None,
    reason: str = "refresh requested",
    announce: bool = False,
) -> Dict[str, Any]:
    """Drop the cached entry for ``name_or_id`` and re-resolve from Vault.

    Use this when an auth attempt with cached creds returned a
    password-failure error -- e.g., Oracle ORA-01017 (invalid
    user/password), Trino 401, S3 InvalidAccessKeyId / SignatureDoesNotMatch.
    The cache may be holding a pre-rotation credential; this forces a
    fresh fetch.

    Returns the freshly-resolved creds dict (same shape as
    ``resolve_system_account``).  Raises with the actionable cause if
    the row is missing OR Vault is also down.

    2026-10-30 -- goes through ``core/qs_credentials/freshness.py::forget``:
    the memory entry is dropped AND the disk entry is distrusted (this used
    to drop memory only, so the 24-hour disk entry refilled memory with the
    same old password), the pooled connectors built from the account are
    closed, and the re-resolve is STRICT (no stale fallback).  ``announce``
    tells every other pod.
    """
    from core.qs_credentials import freshness as _fresh
    _fresh.forget(name_or_id, reason=reason, announce=announce)
    return resolve_system_account(name_or_id, db_manager=db_manager)


def resolve_with_auth_retry(
    name_or_id: Union[str, int],
    auth_callable,
    *,
    db_manager: Any = None,
):
    """Resolve creds + call ``auth_callable(creds_dict)``.  If the call
    raises (typical: driver auth failure), drop the cache + re-fetch
    fresh creds + retry ONCE.  Re-raises on the second failure.

    Apply rule: use this wrapper around DB driver / connector
    constructors that consume QS system_account creds, so a
    rotated-password incident self-heals on the NEXT request rather
    than the next mem_ttl expiry (15 min default).

    Example::

        from core.qs_credentials import resolve_with_auth_retry

        def _open_oracle(creds):
            return oracledb.connect(
                user=creds["username"],
                password=creds["password"],
                dsn=dsn,
            )

        conn = resolve_with_auth_retry(account_id, _open_oracle)

    Args:
      name_or_id:     SystemAccount row id (int) or name (str).
      auth_callable:  callable taking the resolved creds dict and
                      returning the authenticated object (connection,
                      client, ...) or raising on failure.
      db_manager:     optional override for the QS DatabaseManager.

    Returns whatever ``auth_callable`` returns on success.
    Raises the second auth_callable exception when retry also fails.

    2026-10-30 -- the retry is ONLY for an AUTH failure, as declared in
    ``core/qs_credentials/freshness.py::is_auth_failure``.  This used to
    retry on ANY exception ("drop the cache to be safe"), which re-ran the
    callable after a network or statement error -- retry safety is a
    declaration, not a default.  Delegates to ``with_fresh_credentials``,
    the one rule every road (SQL connectors, SFTP, Kafka, S3) now calls.
    """
    from core.qs_credentials import freshness as _fresh
    creds = resolve_system_account(name_or_id, db_manager=db_manager)
    return _fresh.with_fresh_credentials(
        name_or_id, auth_callable, creds=creds, what="login")


__all__ = [
    "is_vault_enabled",
    "resolve_system_account",
    "fill_creds_from_system_account",
    "invalidate",
    "reset_cache",
    "disk_cache_clear",
    "refresh",
    "resolve_with_auth_retry",
]
