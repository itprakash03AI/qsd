"""DatabaseManager mixin -- the component-health tables (2026-10-17).

Three tables, one writer rule: a pod's rows are written by that pod's
reporter (one batched upsert per cycle, the ``record_daemon_heartbeat``
shape), the fleet rows by the fleet watcher under ``FLEET_POD_ID``.  Reads
are whole-table: the page is ONE SELECT, grouped in Python.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional

from core.db.models import ComponentHealth, ComponentHealthEvent, ComponentIntent


def _utc(v: Optional[datetime]) -> Optional[datetime]:
    if v is None:
        return None
    return v if v.tzinfo else v.replace(tzinfo=timezone.utc)


class ComponentHealthMixin:

    # ── observations ─────────────────────────────────────────────────────
    def upsert_component_health(self, pod_id: str, rows: Iterable[Dict[str, Any]]) -> int:
        """Upsert this pod's rows in ONE session.  Carries ``state_since`` /
        ``confirmations`` forward: a row that keeps its state keeps its
        since and counts one more observation; a row that changes state
        starts again at 1.  Returns rows written."""
        rows = [r for r in rows if r.get("component_id")]
        if not pod_id or not rows:
            return 0
        now = datetime.now(timezone.utc)
        written = 0
        with self.get_session() as session:
            existing = {r.component_id: r for r in session.query(ComponentHealth)
                        .filter(ComponentHealth.pod_id == pod_id).all()}
            for r in rows:
                cid = str(r["component_id"])[:200]
                row = existing.get(cid)
                checked = _utc(r.get("checked_at")) or now
                if row is None:
                    row = ComponentHealth(pod_id=pod_id, component_id=cid)
                    row.state_since = checked
                    row.confirmations = 1
                    session.add(row)
                elif row.state != r["state"]:
                    row.state_since = checked
                    row.confirmations = 1
                else:
                    row.confirmations = int(row.confirmations or 0) + 1
                    if row.state_since is None:
                        row.state_since = checked
                row.kind = r["kind"]
                row.scope = r["scope"]
                row.label = str(r.get("label") or cid)[:200]
                row.group = (str(r["group"])[:40] if r.get("group") else None)
                row.state = r["state"]
                row.disposition = r.get("disposition")
                row.reason = str(r.get("reason") or "")[:2000]
                row.evidence = (str(r["evidence"])[:120] if r.get("evidence") else None)
                row.metrics = r.get("metrics") or {}
                row.pod_role = r.get("pod_role")
                row.build = (str(r["build"])[:120] if r.get("build") else None)
                row.checked_at = checked
                row.reported_at = now
                row.interval_seconds = r.get("interval_seconds")
                row.timeout_seconds = r.get("timeout_seconds")
                row.probe_ms = r.get("probe_ms")
                if "muted_by_intent" in r:
                    row.muted_by_intent = r.get("muted_by_intent")
                if "alert_id" in r:
                    row.alert_id = r.get("alert_id")
                written += 1
        return written

    def set_component_health_alert(self, pod_id: str, component_id: str,
                                   alert_id: Optional[int]) -> bool:
        with self.get_session() as session:
            row = session.query(ComponentHealth).filter(
                ComponentHealth.pod_id == pod_id,
                ComponentHealth.component_id == component_id).first()
            if row is None:
                return False
            row.alert_id = alert_id
            return True

    def list_component_health(self, pod_id: Optional[str] = None,
                              component_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Every row (the page), or one pod's / one component's."""
        with self.get_session(read_only=True) as session:
            q = session.query(ComponentHealth)
            if pod_id is not None:
                q = q.filter(ComponentHealth.pod_id == pod_id)
            if component_id is not None:
                q = q.filter(ComponentHealth.component_id == component_id)
            return [r.to_dict() for r in q.order_by(ComponentHealth.pod_id,
                                                    ComponentHealth.component_id).all()]

    def delete_component_health(self, *, pod_id: Optional[str] = None,
                                component_ids: Optional[Iterable[str]] = None,
                                reported_before: Optional[datetime] = None) -> int:
        """GC: a pod's rows, named components (a connection that was deleted),
        or every row of pods silent since ``reported_before``."""
        with self.get_session() as session:
            q = session.query(ComponentHealth)
            if pod_id is not None:
                q = q.filter(ComponentHealth.pod_id == pod_id)
            if component_ids is not None:
                ids = list(component_ids)
                if not ids:
                    return 0
                q = q.filter(ComponentHealth.component_id.in_(ids))
            if reported_before is not None:
                q = q.filter(ComponentHealth.reported_at < reported_before.replace(tzinfo=None))
            if pod_id is None and component_ids is None and reported_before is None:
                return 0
            return int(q.delete(synchronize_session=False) or 0)

    # ── events ───────────────────────────────────────────────────────────
    def add_component_health_event(self, data: Dict[str, Any]) -> Dict[str, Any]:
        with self.get_session() as session:
            row = ComponentHealthEvent(
                component_id=str(data["component_id"])[:200], pod_id=data.get("pod_id"),
                from_state=data.get("from_state"), to_state=data["to_state"],
                reason=(str(data["reason"])[:2000] if data.get("reason") else None),
                at=_utc(data.get("at")) or datetime.now(timezone.utc),
                by=data.get("by"), intent_id=data.get("intent_id"), alert_id=data.get("alert_id"))
            session.add(row)
            session.flush()
            return row.to_dict()

    def list_component_health_events(self, *, component_id: Optional[str] = None,
                                     since: Optional[datetime] = None,
                                     limit: int = 100) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ComponentHealthEvent)
            if component_id:
                q = q.filter(ComponentHealthEvent.component_id == component_id)
            if since is not None:
                q = q.filter(ComponentHealthEvent.at >= since.replace(tzinfo=None))
            rows = q.order_by(ComponentHealthEvent.at.desc(), ComponentHealthEvent.id.desc()) \
                    .limit(max(1, min(int(limit), 1000))).all()
            return [r.to_dict() for r in rows]

    def prune_component_health_events(self, older_than_days: int) -> int:
        if int(older_than_days) <= 0:
            return 0          # 0 = keep forever (the retention rule of this repo)
        cutoff = datetime.now(timezone.utc) - timedelta(days=int(older_than_days))
        with self.get_session() as session:
            return int(session.query(ComponentHealthEvent)
                       .filter(ComponentHealthEvent.at < cutoff.replace(tzinfo=None))
                       .delete(synchronize_session=False) or 0)

    # ── intents ──────────────────────────────────────────────────────────
    def create_component_intent(self, data: Dict[str, Any]) -> Dict[str, Any]:
        with self.get_session() as session:
            row = ComponentIntent(
                control=data["control"], component_id=str(data["component_id"])[:200],
                target_pod_id=str(data["target_pod_id"])[:150],
                requested_by=str(data.get("requested_by") or "unknown")[:100],
                reason=str(data["reason"])[:2000], expires_at=_utc(data.get("expires_at")),
                status=data.get("status") or "pending", applied_by_pods={},
                consequence=(str(data["consequence"])[:2000] if data.get("consequence") else None),
                audit_action=data.get("audit_action"))
            session.add(row)
            session.flush()
            return row.to_dict()

    def get_component_intent(self, intent_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(ComponentIntent).filter(ComponentIntent.id == int(intent_id)).first()
            return row.to_dict() if row else None

    def list_component_intents(self, *, status: Optional[Iterable[str]] = None,
                               component_id: Optional[str] = None,
                               limit: int = 200) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ComponentIntent)
            if status is not None:
                st = list(status)
                if not st:
                    return []
                q = q.filter(ComponentIntent.status.in_(st))
            if component_id:
                q = q.filter(ComponentIntent.component_id == component_id)
            rows = q.order_by(ComponentIntent.id.desc()).limit(max(1, min(int(limit), 1000))).all()
            return [r.to_dict() for r in rows]

    def update_component_intent(self, intent_id: int, fields: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(ComponentIntent).filter(ComponentIntent.id == int(intent_id)).first()
            if row is None:
                return None
            for k, v in fields.items():
                if k in ("expires_at", "withdrawn_at") and v is not None:
                    v = _utc(v)
                setattr(row, k, v)
            session.flush()
            return row.to_dict()

    def record_component_intent_application(self, intent_id: int, pod_id: str, outcome: str,
                                            detail: str = "", *, complete: bool,
                                            every_of: Optional[Iterable[str]] = None) -> Optional[Dict[str, Any]]:
        """One pod's application of an intent.  ``complete`` says this
        application finishes the intent (a single-pod target).  For a
        fleet-wide one (``*``) the caller passes ``every_of`` -- the pods
        reporting right now -- and the intent completes when EVERY one of
        them is in the MERGED ``applied_by_pods``, decided here under the
        row's lock (2026-11-03: decided from the caller's snapshot, two pods
        applying 4 ms apart each missed the other and the intent stayed
        partially_applied with all seven pods applied)."""
        with self.get_session() as session:
            q = session.query(ComponentIntent).filter(ComponentIntent.id == int(intent_id))
            if session.bind is not None and session.bind.dialect.name == "postgresql":
                q = q.with_for_update()                    # one writer at a time per intent
            row = q.first()
            if row is None:
                return None
            applied = dict(row.applied_by_pods or {})
            applied[str(pod_id)[:150]] = {"at": datetime.now(timezone.utc).isoformat(),
                                          "outcome": outcome, "detail": str(detail or "")[:500]}
            row.applied_by_pods = applied
            if every_of is not None:
                complete = {str(p)[:150] for p in every_of} <= set(applied)
            if complete:
                row.status = "applied" if all(a.get("outcome") == "ok" for a in applied.values()) \
                    else "partially_applied"
            session.flush()
            return row.to_dict()


__all__ = ["ComponentHealthMixin"]
