"""Unified SSL/TLS configuration resolution for ALL S3 / outbound HTTPS access.

2026-06-18 -- strategic consolidation.  Before this module, SSL config was
parsed inline in ~10 different files (s3_storage / duckdb_subprocess (twice)
/ iceberg_service / credential_resolver / data_grid_api / etc).  Each
parser made slightly different choices:

  * duckdb_subprocess.py:765-769 had a DEAD BRANCH -- when ssl_verify=True
    (the secure default), it set urllib3 CERT_NONE -- bypassing verification
    AND silently ignoring the helm-deployed `backend/certs/tls_bundle.pem`.
  * s3_storage._parse_ssl_verify autodetected the bundle.
  * iceberg_service repeated the autodetect logic (different code path,
    same intent).
  * credential_resolver used a third spelling.

Result: the helm-deployed .pem was honoured on SOME paths and ignored on
others.  Operator couldn't tell which.

This module centralises the decision in ONE place.  ``SslResolution``
captures the only two facts that matter: should we verify, and against
which CA?  Adapter functions translate it for each downstream library
(urllib3 / ssl.SSLContext / boto3 / env vars for child processes).
"""
from __future__ import annotations

import logging
import os
import ssl
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Union

logger = logging.getLogger(__name__)

# Helm chart writes the cluster CA bundle here (see
# k8s/querystudioapi-helm + the iceberg_service.py reference at line 136).
# Path is RELATIVE TO backend/ root: this file lives at backend/core/, so
# parent.parent is backend/.
#
# 2026-06-18 -- operator-observed deployments mount the bundle at
# /usr/local/querystudioapi/certs/tls-ca-bundle.pem (hyphenated name).
# We scan a list of canonical paths instead of one hardcoded location so
# the autodetect honours every spelling we've seen in the field.  The
# env var QS_CA_BUNDLE_PATH always wins; the first existing path in the
# list wins otherwise.
_BUNDLE_ENV_VAR = "QS_CA_BUNDLE_PATH"
_BUNDLE_CANDIDATES = (
    # Repo-relative (this file is at backend/core/, parent.parent is backend/).
    Path(__file__).resolve().parent.parent / "certs" / "tls_bundle.pem",
    Path(__file__).resolve().parent.parent / "certs" / "tls-ca-bundle.pem",
    # Absolute pod paths (helm + operator-side mounts).
    Path("/usr/local/querystudioapi/certs/tls-ca-bundle.pem"),
    Path("/usr/local/querystudioapi/certs/tls_bundle.pem"),
    Path("/etc/ssl/certs/tls-ca-bundle.pem"),
    # 2026-06-24 -- RHEL / CoreOS system trust store (the bundle the
    # operator's `curl -kv` showed as ``CAfile``).  Carries Amazon
    # roots out of the box.  Placed AFTER operator paths so an
    # explicit operator bundle still wins; placed BEFORE the
    # generic certifi fallback so the system store is used when the
    # operator didn't deploy a custom bundle.
    Path("/etc/pki/tls/certs/ca-bundle.crt"),
    Path("/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem"),
)
# Kept for back-compat with any external import (was: single Path).  Now
# resolves at call-time via _find_default_bundle_path() so we honour the
# env var + every candidate every time.
_DEFAULT_BUNDLE_PATH = _BUNDLE_CANDIDATES[0]


def _find_default_bundle_path() -> Optional[Path]:
    """Return the first existing CA bundle path, or None.

    Order of precedence: env var QS_CA_BUNDLE_PATH > _BUNDLE_CANDIDATES.
    """
    env_override = os.environ.get(_BUNDLE_ENV_VAR, "").strip()
    if env_override and os.path.isfile(env_override):
        return Path(env_override)
    for p in _BUNDLE_CANDIDATES:
        try:
            if p.exists():
                return p
        except OSError:
            continue
    return None


# Cached path to the merged operator+certifi bundle.  Built lazily on the
# first call to ``_merged_bundle_with_certifi`` so test runs that never
# touch AWS don't pay the I/O cost.
_MERGED_BUNDLE_CACHE: Dict[str, str] = {}
_MERGED_BUNDLE_LOCK: Any = None  # set below
try:
    import threading as _ssl_threading
    _MERGED_BUNDLE_LOCK = _ssl_threading.Lock()
except Exception:
    _MERGED_BUNDLE_LOCK = None


def _disable_merge() -> bool:
    """Operator opt-out for the certifi merge.  Default: merge ON.

    Reasons to opt out: the operator's bundle is intentionally air-gapped
    (no Amazon trust desired), or certifi is missing from the image.
    Set ``QS_DISABLE_CERTIFI_MERGE=1`` to disable.
    """
    return os.environ.get("QS_DISABLE_CERTIFI_MERGE", "").strip() in (
        "1", "true", "TRUE", "yes",
    )


def _merged_bundle_with_certifi(operator_bundle: str) -> str:
    """Return a path to a CA-bundle file that contains BOTH the operator's
    PEM and certifi's PEM concatenated.  Cached after the first call so
    repeated SSL resolutions don't re-write the temp file.

    Why this exists -- 2026-06-24.  Operator deployments (esp. OpenShift)
    often mount a custom CA bundle that contains internal corp CAs ONLY
    -- the system bundle (with Amazon Root CA 1/2/3/4) is NOT included.
    Setting ``ca_cert_file`` to the operator's bundle then makes libcurl
    (DuckDB httpfs) + urllib3 (boto3) fail TLS chain validation against
    AWS S3 / VPCE endpoints because the Amazon roots aren't trusted.
    Result: HTTP 0 from libcurl, SSL: CERTIFICATE_VERIFY_FAILED from
    boto3.  Symptom: ``curl -k`` (skip verify) succeeds, both libraries
    fail.

    Strategic fix: when an operator bundle IS set, ALSO trust certifi's
    bundle (which carries every public root including Amazon).  Internal
    corp hosts still validate (operator's CAs are present); AWS hosts
    also validate (certifi's CAs are present).  No code path needs to
    know about both lists -- the merged file is the single trust store.

    Operator opt-out: set ``QS_DISABLE_CERTIFI_MERGE=1`` if the
    deployment intentionally air-gaps AWS trust (rare).

    Returns the operator path unchanged if certifi is unavailable or
    merge is disabled.
    """
    if _disable_merge():
        return operator_bundle
    if not os.path.isfile(operator_bundle):
        return operator_bundle

    _cached = _MERGED_BUNDLE_CACHE.get(operator_bundle)
    if _cached and os.path.isfile(_cached):
        return _cached

    try:
        import certifi
        certifi_path = certifi.where()
    except Exception:
        return operator_bundle
    if not certifi_path or not os.path.isfile(certifi_path):
        return operator_bundle
    # If they're already the same file, nothing to merge.
    try:
        if os.path.samefile(operator_bundle, certifi_path):
            return operator_bundle
    except OSError:
        pass

    # Build the merged file under the pod-writable tmp area so multiple
    # processes can share it.  Filename is deterministic per operator
    # path so concurrent boots don't race to write different files.
    import hashlib
    import tempfile
    _digest = hashlib.sha256(operator_bundle.encode("utf-8")).hexdigest()[:16]
    _merged_dir = tempfile.gettempdir()
    _merged_path = os.path.join(
        _merged_dir, f"qs-ca-merged-{_digest}.pem",
    )

    def _do_merge():
        try:
            with open(operator_bundle, "rb") as _opf:
                _op_bytes = _opf.read()
            with open(certifi_path, "rb") as _ctf:
                _ct_bytes = _ctf.read()
            _content = (
                b"# QueryStudio merged trust store -- operator + certifi\n"
                b"# Source 1: " + operator_bundle.encode("utf-8") + b"\n"
                + _op_bytes
                + b"\n# Source 2 (certifi): " + certifi_path.encode("utf-8") + b"\n"
                + _ct_bytes
            )
            # Atomic write: tmpfile + rename so concurrent readers never
            # see a half-written merge.
            _tmp = _merged_path + ".tmp"
            with open(_tmp, "wb") as _of:
                _of.write(_content)
            os.replace(_tmp, _merged_path)
            try:
                os.chmod(_merged_path, 0o644)
            except OSError:
                pass
            return _merged_path
        except Exception as _merge_exc:
            logger.warning(
                "ssl_config: certifi merge failed (%s) -- falling back to "
                "operator bundle alone.  AWS chain validation may fail.",
                _merge_exc,
            )
            return operator_bundle

    if _MERGED_BUNDLE_LOCK is not None:
        with _MERGED_BUNDLE_LOCK:
            _cached = _MERGED_BUNDLE_CACHE.get(operator_bundle)
            if _cached and os.path.isfile(_cached):
                return _cached
            _result = _do_merge()
            _MERGED_BUNDLE_CACHE[operator_bundle] = _result
            return _result
    _result = _do_merge()
    _MERGED_BUNDLE_CACHE[operator_bundle] = _result
    return _result


@dataclass(frozen=True)
class SslResolution:
    """Two facts: do we verify, and against which CA bundle.

    enabled=True + ca_bundle_path=None  -> system CA store (default)
    enabled=True + ca_bundle_path=<p>   -> custom bundle (helm or operator-provided)
    enabled=False                      -> verification disabled (on-prem dev / known-bad cert)
    """

    enabled: bool
    ca_bundle_path: Optional[str] = None

    def __post_init__(self):
        # Defensive: ca_bundle_path is meaningless when enabled=False.
        if not self.enabled and self.ca_bundle_path:
            # Frozen dataclass -- can't mutate, but log so future tracing is easy.
            object.__setattr__(self, "ca_bundle_path", None)


#: Spellings that mean "do not verify".  Deliberately broad: this value
#: arrives from an admin form, a JSON config, and DB columns of three
#: different types, and an unrecognised spelling used to fail SECURE-but-
#: WRONG -- the operator turned verification off and it stayed on.
_FALSY_SPELLINGS = frozenset({"false", "0", "no", "off", "n", "disabled", "none"})

#: Spellings that mean "verify, and find me a CA bundle".
_TRUTHY_SPELLINGS = frozenset({"true", "1", "yes", "on", "y", "enabled"})

#: Hosts we have already warned about, so a per-query connector does not
#: emit the same line on every execution.
_DISABLED_WARNED: set = set()


def _disabled(reason: str) -> "SslResolution":
    """Verification OFF, said out loud, with urllib3's noise suppressed.

    2026-08-20 -- two things belong together here and were previously
    neither done nor documented:

    1. Disabling TLS verification is a security decision.  It gets a WARNING
       naming WHY, once per distinct reason, so it appears in pod logs
       instead of being inferred from a failure that stopped happening.

    2. requests/urllib3 then emit an ``InsecureRequestWarning`` per REQUEST.
       On a query that polls for results that is one warning per poll, which
       buries real output.  Suppressed here -- at the single point that
       decides verification is off -- rather than at each call site, where
       one connector would silence it and the next would not.

    The suppression is process-global (urllib3 offers no per-session
    control), so it only fires once a connection has genuinely asked for
    verification to be off.
    """
    if reason not in _DISABLED_WARNED:
        _DISABLED_WARNED.add(reason)
        logger.warning(
            "TLS certificate verification is DISABLED (%s).  The connection "
            "is not protected against interception; this is only appropriate "
            "for an internal endpoint with a self-signed cert.", reason)
    try:
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    except Exception:  # pragma: no cover - urllib3 always present with requests
        logger.debug("could not suppress urllib3 InsecureRequestWarning")
    return SslResolution(enabled=False, ca_bundle_path=None)


def resolve_ssl(ssl_verify: Any) -> SslResolution:
    """Single source of truth -- accept anything the polling row / config
    JSON / env var might supply, return the canonical resolution.

    Inputs handled:
      * True / False (bool)            -- the documented spellings
      * "true" / "false" (str)         -- Oracle/JSON returns strings
      * <path string>                  -- explicit CA bundle path
      * None / "" / missing            -- defaults to True (secure)

    Auto-detection: when ssl_verify resolves to True AND the helm-deployed
    bundle exists at backend/certs/tls_bundle.pem, USE IT.  This is the
    behaviour the helm chart counts on.  Operator-supplied path always wins.
    """
    if ssl_verify is None or ssl_verify == "":
        # Default = secure verify with whatever CA we can find.
        return _default_verify()

    if isinstance(ssl_verify, bool):
        if ssl_verify:
            return _default_verify()
        return _disabled("verify_ssl=False on the connection")

    # 2026-08-20 -- THE CONNECTION'S SETTING IS AUTHORITATIVE.
    #
    # Only ``False`` and ``"false"`` were recognised as OFF.  Every other
    # spelling an operator, a JSON round-trip or an Oracle/SQLite column
    # actually produces -- 0, "0", "no", "off", "n", "disabled" -- fell
    # through to the CA-BUNDLE-PATH branch below, failed to find a file, and
    # silently returned enabled=True.  So a connection explicitly configured
    # not to verify DID verify, and the only trace was a "path does not
    # exist" warning that reads like a mount problem.
    #
    # Measured before this change:
    #     verify_ssl=0     -> True      (verification ON)
    #     verify_ssl="0"   -> True
    #     verify_ssl="no"  -> True
    #     verify_ssl=False -> False     (the only spellings that worked)
    #
    # Widening this DISABLES verification for configs that previously got it
    # by accident, which is a real security-relevant change -- hence the
    # loud, host-naming log in _disabled() rather than a silent flip.
    if isinstance(ssl_verify, int) and not isinstance(ssl_verify, bool):
        if ssl_verify == 0:
            return _disabled("verify_ssl=0 on the connection")
        return _default_verify()

    if isinstance(ssl_verify, str):
        s = ssl_verify.strip()
        if s.lower() in _FALSY_SPELLINGS:
            return _disabled(f"verify_ssl={ssl_verify!r} on the connection")
        if s.lower() in _TRUTHY_SPELLINGS:
            return _default_verify()
        # Treat as an explicit CA bundle path.
        if not os.path.isfile(s):
            logger.warning(
                "ssl_verify points at a path that does not exist: %s -- "
                "falling back to system CA store.  Check helm cert volume "
                "mount.",
                s,
            )
            return SslResolution(enabled=True, ca_bundle_path=None)
        return SslResolution(
            enabled=True,
            ca_bundle_path=_merged_bundle_with_certifi(s),
        )

    # Unknown type -- be safe.
    logger.warning(
        "ssl_verify config has unexpected type %s (value=%r) -- "
        "defaulting to secure verify",
        type(ssl_verify).__name__, ssl_verify,
    )
    return _default_verify()


def _default_verify() -> SslResolution:
    """Auto-detect the helm-deployed bundle; fall back to system CA store.

    Scans _BUNDLE_CANDIDATES so every spelling we've seen in the field
    is honoured.  Env var QS_CA_BUNDLE_PATH wins if it points at a file.

    When an operator bundle is found, ALWAYS merge with certifi (unless
    opted out) so AWS chain validation works even when the operator's
    PEM contains only internal corp CAs.  Single chokepoint -- every
    consumer of ``resolve_ssl`` benefits, no per-site wiring.
    """
    found = _find_default_bundle_path()
    if found is not None:
        return SslResolution(
            enabled=True,
            ca_bundle_path=_merged_bundle_with_certifi(str(found)),
        )
    return SslResolution(enabled=True, ca_bundle_path=None)


#: The field a connection carries its issuing CA in (PEM text, one or more
#: ``BEGIN CERTIFICATE`` blocks).  Named here so the refusal below and the
#: connection forms spell it the same way.
CA_PEM_FIELD = "ca_cert_pem"

_PEM_CERT_BEGIN = "-----BEGIN CERTIFICATE-----"
_PEM_CERT_END = "-----END CERTIFICATE-----"


def _certificate_blocks(pem_text: str) -> list:
    """The ``BEGIN/END CERTIFICATE`` blocks of ``pem_text``, each base64-
    decodable.  Anything else (a private key, prose, an empty paste) is a
    ValueError naming the field: a trust store that silently held nothing
    would fail every TLS handshake with a sentence about the SERVER's
    certificate, sending the person to the wrong side."""
    import base64
    import binascii
    text = str(pem_text or "")
    blocks = []
    pos = 0
    while True:
        start = text.find(_PEM_CERT_BEGIN, pos)
        if start < 0:
            break
        end = text.find(_PEM_CERT_END, start)
        if end < 0:
            raise ValueError(
                f"{CA_PEM_FIELD}: a BEGIN CERTIFICATE block has no END CERTIFICATE line")
        body = "".join(text[start + len(_PEM_CERT_BEGIN):end].split())
        try:
            raw = base64.b64decode(body, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise ValueError(
                f"{CA_PEM_FIELD}: a certificate block is not valid base64 ({exc})") from exc
        if not raw:
            raise ValueError(f"{CA_PEM_FIELD}: an empty certificate block")
        lines = [body[i:i + 64] for i in range(0, len(body), 64)]
        blocks.append("\n".join([_PEM_CERT_BEGIN, *lines, _PEM_CERT_END]) + "\n")
        pos = end + len(_PEM_CERT_END)
    if not blocks:
        raise ValueError(
            f"{CA_PEM_FIELD} holds no certificate: paste the issuing CA as PEM text "
            f"(one or more '{_PEM_CERT_BEGIN}' ... '{_PEM_CERT_END}' blocks)")
    return blocks


def bundle_for_pem(pem_text: str) -> str:
    """A CA bundle FILE for a PEM pasted on a connection (2026-10-08).

    A Starburst Enterprise cluster sits behind a corporate CA, and Galaxy on
    a public one; before this the only way to trust a private CA was a
    file on every pod (``QS_CA_BUNDLE_PATH`` / the helm bundle), which is a
    deployment, not a connection.  The connection's own ``ca_cert_pem`` is
    written once per distinct text under the pod's tmp area and MERGED
    with certifi through the same chokepoint the operator bundle uses, so
    a Starburst on a private CA and an S3 endpoint on a public one both
    validate from one connection.  The path is deterministic per content
    (sha256), so every process on the pod shares it and a re-paste of the
    same CA changes nothing.

    Never a reason to stop verifying: a PEM that holds no certificate is a
    ValueError naming the field, not ``verify=False``.
    """
    import hashlib
    import tempfile
    blocks = _certificate_blocks(pem_text)
    normalized = "".join(blocks)
    digest = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]
    path = os.path.join(tempfile.gettempdir(), f"qs-ca-inline-{digest}.pem")
    if not os.path.isfile(path):
        tmp = f"{path}.{os.getpid()}.tmp"
        with open(tmp, "wb") as fh:
            fh.write(b"# QueryStudio inline CA (connection ca_cert_pem)\n")
            fh.write(normalized.encode("utf-8"))
        os.replace(tmp, path)
    return _merged_bundle_with_certifi(path)


# ── Adapters for downstream libraries ─────────────────────────────────────


def as_urllib3_kwargs(r: SslResolution) -> Dict[str, Any]:
    """Translate to urllib3.PoolManager kwargs.

    CRITICAL: the prior duckdb_subprocess.py code had `cert_reqs="CERT_NONE"`
    when ssl_verify=True (the default!) -- this was the DEAD BRANCH that
    silently ignored the helm-deployed CA bundle.  Fixed here: enabled=True
    always means CERT_REQUIRED, with ca_bundle_path injected when present.
    """
    if not r.enabled:
        return {"cert_reqs": "CERT_NONE"}
    kw: Dict[str, Any] = {"cert_reqs": "CERT_REQUIRED"}
    if r.ca_bundle_path:
        kw["ca_certs"] = r.ca_bundle_path
    return kw


def as_ssl_context(r: SslResolution) -> ssl.SSLContext:
    """Translate to a stdlib ssl.SSLContext for urlopen / smtplib / ldap3."""
    ctx = ssl.create_default_context()
    if not r.enabled:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    if r.ca_bundle_path:
        ctx.load_verify_locations(r.ca_bundle_path)
    return ctx


def as_boto3_verify(r: SslResolution) -> Union[bool, str]:
    """Translate to the boto3 client kwarg `verify=`.

    boto3 accepts: True (default CA), False (disabled), or a path string.
    """
    if not r.enabled:
        return False
    if r.ca_bundle_path:
        return r.ca_bundle_path
    return True


def session_keeping_verify(verify: Any) -> Any:
    """A ``requests.Session`` whose ``verify`` is what the CONNECTION said, whatever the process
    environment says (2026-11-04, the owner: "ssl off and it was working, then suddenly dropped").

    ``requests`` lets REQUESTS_CA_BUNDLE / CURL_CA_BUNDLE beat ``session.verify``, False included,
    on every request that passes no verify of its own.  Opening a Snowflake connection sets that
    variable for the whole process, because its driver reads nothing else.  So a Trino connection
    with SSL off, or with its own pasted CA, began verifying against the other bundle from then on,
    until the pod restarted and only once a Snowflake connection opened again.  One connection's
    setting must not depend on what another did earlier in the process.

    A plain "verify on" is left to ``requests``: that is the default trust, and a CA bundle
    operations set in the pod's environment is part of it.
    """
    import requests

    class _KeepsVerify(requests.Session):
        def merge_environment_settings(self, url, proxies, stream, verify_arg, cert):
            settings = super().merge_environment_settings(url, proxies, stream, verify_arg, cert)
            if self.verify is not True and (verify_arg is None or verify_arg is True):
                settings["verify"] = self.verify
            return settings

    session = _KeepsVerify()
    session.verify = verify
    return session


def as_env_vars(r: SslResolution) -> Dict[str, str]:
    """Translate to env vars that subprocess-spawned downloaders + pyiceberg
    pick up.

    Sets AWS_CA_BUNDLE (boto3 / pyiceberg / awscli) and
    REQUESTS_CA_BUNDLE (requests / older urllib3 callers).  When
    verification is disabled, returns the PYICEBERG-specific disable
    string used by iceberg_service.py.
    """
    if not r.enabled:
        return {"PYICEBERG_S3__VERIFY_SSL": "false"}
    if r.ca_bundle_path:
        return {
            "AWS_CA_BUNDLE": r.ca_bundle_path,
            "REQUESTS_CA_BUNDLE": r.ca_bundle_path,
        }
    return {}


def apply_env_vars(r: SslResolution) -> None:
    """Imperative variant of as_env_vars -- mutates os.environ.

    Used at process boot / connection setup where env propagation is the
    only way to plumb the bundle to a child library.  When verification
    is enabled but no bundle is configured, also CLEARS any pre-existing
    AWS_CA_BUNDLE so a stale path doesn't shadow the system store.
    """
    env_updates = as_env_vars(r)
    if env_updates:
        for k, v in env_updates.items():
            os.environ[k] = v
        # If we enabled verify with a path, clear the pyiceberg disable.
        if r.enabled:
            os.environ.pop("PYICEBERG_S3__VERIFY_SSL", None)
    else:
        # System-CA path: clear any stale custom bundle env so we don't
        # leak a previous connection's CA into the next.
        os.environ.pop("AWS_CA_BUNDLE", None)
        os.environ.pop("REQUESTS_CA_BUNDLE", None)
        os.environ.pop("PYICEBERG_S3__VERIFY_SSL", None)


def describe(r: SslResolution) -> str:
    """Human-readable log line.  Use at debug / connection-setup time."""
    if not r.enabled:
        return "ssl verify=OFF (insecure -- only for on-prem dev / known-broken certs)"
    if r.ca_bundle_path:
        return f"ssl verify=ON, ca_bundle={r.ca_bundle_path}"
    return "ssl verify=ON, ca_bundle=system store (no custom bundle found)"


def apply_ssl_to_duckdb_con(con, conn_config: dict, *, log_prefix: str = "SSL") -> "SslResolution":
    """Single chokepoint for "apply SSL config to a DuckDB connection".

    2026-06-24 -- previously every site (multi_worker_dispatcher,
    federation_engine, data_grid_api, duckdb_subprocess) duplicated
    a ~15-line dance that:
      * read ``ssl_verify`` from conn_config
      * type-checked whether it was a string path
      * conditionally emitted ``SET ca_cert_file`` OR
        ``SET enable_server_cert_verification=false``

    Four out of five sites contained a SUBTLE BUG: when
    ``ssl_verify`` was the boolean ``True`` (the *default*), the
    branch fell into the FORCE-OFF path because the string-check
    failed.  Effect: operators who set ``ssl_verify=True`` to enforce
    cert verification got SSL silently DISABLED.  Operators who
    expected their entered ``.pem`` to apply only got it honored
    when they set ``ssl_verify="<absolute path>"`` (the type-check
    branch).  Bool True / mixed-case "true" / etc. all fell into
    the broken FORCE-OFF.

    Single source of truth via this helper:
      1. ``resolve_ssl(ssl_verify)`` -- canonical interpretation of
         True / False / "true" / "false" / "<path>".
      2. enabled + bundle path  -> ``SET ca_cert_file='<path>'``
      3. enabled + no bundle    -> leave DuckDB defaults (system CA)
      4. disabled               -> SET enable_server_cert_verification=false
                                  AND enable_curl_server_cert_verification=false

    Returns the ``SslResolution`` so the caller can log
    ``describe(...)`` and pass the same resolution to env-var
    setters (for subprocess-spawned helpers).
    """
    import logging
    _logger = logging.getLogger(__name__)
    _ssl_res = resolve_ssl(conn_config.get("ssl_verify", True))
    try:
        _logger.info("%s -- %s", log_prefix, describe(_ssl_res))
    except Exception:
        pass

    _esc = lambda v: str(v).replace("'", "''")
    if _ssl_res.enabled and _ssl_res.ca_bundle_path:
        try:
            con.execute(
                f"SET ca_cert_file='{_esc(_ssl_res.ca_bundle_path)}';"
            )
        except Exception as _ca_exc:
            _logger.debug("%s ca_cert_file set failed (continuing): %s",
                          log_prefix, _ca_exc)
    elif not _ssl_res.enabled:
        for _stmt in (
            "SET enable_server_cert_verification=false;",
            "SET enable_curl_server_cert_verification=false;",
        ):
            try:
                con.execute(_stmt)
            except Exception as _ss_exc:
                _logger.debug("%s %s rejected by DuckDB (continuing): %s",
                              log_prefix, _stmt, _ss_exc)
    # else: enabled + no custom bundle path -> leave DuckDB libcurl
    # to use its default trust store (system CA).  This is the
    # CORRECT behaviour and was broken at 4 of 5 sites pre-2026-06-24.
    return _ssl_res


def duckdb_settings_for_ssl(conn_config: dict) -> dict:
    """Return a dict of ``SET key=value`` pairs the worker dispatcher
    should send to its workers for SSL setup.  Same three-state
    resolution as ``apply_ssl_to_duckdb_con`` but emits a settings
    dict instead of executing on a connection -- used by
    ``multi_worker_dispatcher._duckdb_settings_from_conn_config``
    where the worker is on a remote pod.

    Returns one of:
      * ``{"ca_cert_file": "<path>"}``  -- enabled + bundle.
      * ``{}``                          -- enabled + no bundle (system CA).
      * ``{"enable_server_cert_verification": False,
         "enable_curl_server_cert_verification": False}``  -- disabled.
    """
    _ssl_res = resolve_ssl(conn_config.get("ssl_verify", True))
    if _ssl_res.enabled and _ssl_res.ca_bundle_path:
        return {"ca_cert_file": _ssl_res.ca_bundle_path}
    if not _ssl_res.enabled:
        return {
            "enable_server_cert_verification": False,
            "enable_curl_server_cert_verification": False,
        }
    return {}


# ── VPC endpoint detection ────────────────────────────────────────────────


def is_vpc_endpoint_url(endpoint_url: Optional[str]) -> bool:
    """Return True if the endpoint URL is an AWS VPC endpoint.

    Pattern: ``vpce-<id>.s3.<region>.vpce.amazonaws.com``.  Used to short-
    circuit the presigned-URL pre-download path (which assumes the regular
    S3 host) and route to boto3 instead -- presigned URLs signed for
    s3.amazonaws.com return HTTP 403 when sent to a vpce-* host because
    the signature's Host header doesn't match.

    Strategic placement here (next to SSL config) because VPC endpoint
    detection and CA bundle resolution together gate the entire S3
    access decision.
    """
    if not endpoint_url:
        return False
    return ".vpce.amazonaws.com" in endpoint_url.lower()


def s3_endpoint_host_for_duckdb(conn_config: Optional[dict]) -> str:
    """Return the SCHEME-STRIPPED, VPCE-NORMALISED host string ready for
    DuckDB ``SET s3_endpoint='...'``.

    2026-06-24 -- single chokepoint at the SET-site level.  Before this
    helper, every one of the 9 sites that issued ``SET s3_endpoint``
    duplicated:

      ep = cfg.get("endpoint_url") or cfg.get("endpoint") or ""
      ep_clean = ep.replace("https://", "").replace("http://", "").rstrip("/")
      con.execute(f"SET s3_endpoint='{ep_clean}'")

    Each site was responsible for remembering to call
    ``normalize_vpce_endpoint_for_s3_data`` first.  Easy to miss --
    and the audit after the 2026-06-24 ``bucket.``-prefix incident
    proved several sites HAD missed it (silent VPCE bypass).

    This helper does both jobs:
      1. Pull ``endpoint_url`` / ``endpoint`` from conn_config.
      2. Pipe through ``normalize_vpce_endpoint_for_s3_data`` so the
         ``bucket.vpce-XXX...`` rewrite is applied.
      3. Strip scheme (``https://``/``http://``).
      4. Strip trailing ``/``.

    Returns the empty string when no endpoint is configured (caller
    short-circuits with ``if ep:``).  Sites that need to know whether
    the original was ``https://`` should ALSO call ``s3_endpoint_uses_ssl``
    below (kept as a separate helper so the two decisions are
    explicit at each call site).

    Used by:
      - core/s3_access.py -- since 2026-09-26 the ONLY consumer.  The ten
        sites that each issued ``SET s3_endpoint`` (subprocess, data grid,
        metadata catalog, federation SECRET + pragmas, ETL x2, iceberg
        mirror, mirror_common, s3_utilities, the worker dispatcher's
        settings dict) now consume ``resolve_s3_access(cfg)`` and decide
        nothing themselves.
    """
    if not conn_config:
        return ""
    _raw = conn_config.get("endpoint_url") or conn_config.get("endpoint") or ""
    if not _raw:
        return ""
    _normalised = normalize_vpce_endpoint_for_s3_data(_raw) or _raw
    # Strip scheme (case-insensitive defensive against ``HTTPS://``).
    _stripped = _normalised
    _low = _stripped.lower()
    if _low.startswith("https://"):
        _stripped = _stripped[len("https://"):]
    elif _low.startswith("http://"):
        _stripped = _stripped[len("http://"):]
    return _stripped.rstrip("/")


def s3_endpoint_uses_ssl(conn_config: Optional[dict]) -> bool:
    """Companion to ``s3_endpoint_host_for_duckdb`` -- returns True
    when the configured endpoint is HTTPS (or unspecified, since AWS
    S3 + most managed S3-compatible providers default to HTTPS).
    Used by sites that need to emit ``SET s3_use_ssl=false`` for HTTP
    on-prem endpoints."""
    if not conn_config:
        return True
    _raw = conn_config.get("endpoint_url") or conn_config.get("endpoint") or ""
    if not _raw:
        return True
    return not _raw.lower().startswith("http://")


def normalize_vpce_endpoint_for_s3_data(endpoint_url: Optional[str]) -> Optional[str]:
    """Single chokepoint: rewrite the GENERIC S3 VPCE endpoint
    ``vpce-<id>.s3.<region>.vpce.amazonaws.com`` to the BUCKET-DATA
    endpoint ``bucket.vpce-<id>.s3.<region>.vpce.amazonaws.com``
    (prepending ``bucket.``) so all boto3/DuckDB calls land on the
    sub-domain whose TLS cert AWS designed to validate bucket data
    requests.

    Why this exists -- 2026-06-24, operator-confirmed on the pod:

        boto3 with endpoint=https://bucket.vpce-XXX.s3.<region>.vpce.amazonaws.com
              + addressing_style=path  -> list_objects_v2 SUCCESS.
        boto3 with endpoint=https://vpce-XXX.s3.<region>.vpce.amazonaws.com
                                       -> CERTIFICATE_VERIFY_FAILED
                                          (cert covers *.bucket.vpce-...,
                                          NOT vpce-... directly).

    AWS S3 VPCE exposes multiple sub-domains, each with its own cert
    SAN list:

      vpce-<id>.s3.<region>.vpce.amazonaws.com            -- control/generic
      bucket.vpce-<id>.s3.<region>.vpce.amazonaws.com     -- bucket data (THIS)
      accesspoint.vpce-<id>.s3.<region>.vpce.amazonaws.com -- access points
      *.bucket.vpce-<id>.s3.<region>.vpce.amazonaws.com   -- per-bucket VHOST

    Operators commonly enter the generic ``vpce-XXX.s3...`` form
    because that's what AWS's console / their IT team gives them.
    This helper normalises it transparently so the connection just
    works.  Idempotent -- if the ``bucket.`` prefix is already
    present, the input is returned unchanged.

    Opt out via ``QS_VPCE_AUTO_BUCKET_PREFIX=0`` for deployments
    that want to keep the raw value (rare).

    Returns the original input unchanged when:
      * empty / None
      * not a VPCE pattern (``.vpce.amazonaws.com`` not present)
      * already prefixed with ``bucket.`` / ``accesspoint.`` / etc.
    """
    if not endpoint_url:
        return endpoint_url
    if os.environ.get(
        "QS_VPCE_AUTO_BUCKET_PREFIX", "1").strip() in (
        "0", "false", "FALSE",
    ):
        return endpoint_url
    _lower = endpoint_url.lower()
    if ".vpce.amazonaws.com" not in _lower:
        return endpoint_url
    # Strip scheme to inspect host, keep so we can re-attach.
    _scheme_split = endpoint_url.split("://", 1)
    if len(_scheme_split) == 2:
        _scheme = _scheme_split[0] + "://"
        _rest = _scheme_split[1]
    else:
        _scheme = ""
        _rest = endpoint_url
    # Split off any trailing path / port so we only touch the host.
    _host_terminators = ("/", ":")
    _host_end = len(_rest)
    for _t in _host_terminators:
        _i = _rest.find(_t)
        if _i != -1 and _i < _host_end:
            _host_end = _i
    _host = _rest[:_host_end]
    _tail = _rest[_host_end:]
    _host_lower = _host.lower()
    # If the host is already prefixed (bucket., accesspoint., or any
    # custom <name>.vpce-XXX...), leave it alone.  Detect by checking
    # whether there's anything BEFORE the ``vpce-`` segment in the
    # host.  ``vpce-XXX.s3...`` -> starts with ``vpce-``.
    # ``bucket.vpce-XXX.s3...`` -> starts with ``bucket.``.
    # 2026-07-30 -- DROP any PATH from the tail; keep only a :port.
    #
    # An S3 ``endpoint_url`` must be scheme://host[:port] with NO path.
    # botocore treats a path as a PREFIX and still appends the bucket under
    # path-style addressing, so an operator who pastes
    #   https://bucket.vpce-<id>.s3.<region>.vpce.amazonaws.com/my-bucket
    # (an easy mistake -- it is what the full request URL looks like in logs)
    # gets requests built as ``/my-bucket/my-bucket/<key>``: every call 404s
    # or fails to sign, which reads as "VPC is broken".
    # ``validate_vpce_url`` also now rejects it outright so the operator sees
    # the real reason; this arm is the safety net for values already stored
    # on a connection record.
    if _tail and _tail.startswith("/"):
        _tail = ""
    elif _tail and ":" in _tail:
        # ":443/path" -> keep ":443", drop "/path"
        _tail = _tail.split("/", 1)[0]

    if not _host_lower.startswith("vpce-"):
        return f"{_scheme}{_host}{_tail}" if _scheme or _tail else endpoint_url
    # Prepend bucket. -- the cert SAN list includes ``bucket.vpce-...``
    # AND ``*.bucket.vpce-...`` so this is the universally safe choice
    # for S3 data-plane operations.
    return f"{_scheme}bucket.{_host}{_tail}"


# Regex shared by every code path that needs to detect hive-style
# partition segments in s3:// URLs.  Single source of truth.
import re as _hive_path_re  # noqa: E402
_HIVE_PATH_PATTERN = _hive_path_re.compile(r"'s3://[^']*/[^/=']+=[^/']+/")


def has_hive_partition_paths_in_sql(setup_sql: Optional[str]) -> bool:
    """Return True if any s3:// URL in ``setup_sql`` has hive-style
    ``key=value/`` segments.

    These are the only paths that trigger DuckDB httpfs's libcurl
    URL-encoding bug (`=` -> `%3D` in the canonical request -> SigV4
    SignatureDoesNotMatch).  Flat-key S3 URLs are safe.
    """
    if not setup_sql:
        return False
    return bool(_HIVE_PATH_PATTERN.search(setup_sql))


def vpc_httpfs_workaround_needed(
    endpoint_url: Optional[str],
    setup_sql: Optional[str],
    config_switch_on: Optional[bool] = None,
) -> tuple[bool, str]:
    """Single decision point: do we need the boto3 pre-download
    workaround for this VPC + hive-partition scenario?

    Returns ``(needed, reason)`` where ``reason`` is a human-readable
    explanation suitable for a log line.  Callers MUST use the
    workaround when ``needed`` is True OR they will hit
    SignatureDoesNotMatch 403s on every partition file -- this is the
    libcurl `=` URL-encoding bug discovered 2026-06-15.

    ``config_switch_on=None`` (default) reads ``s3.force_boto3_for_vpc``
    config + ``QS_FORCE_BOTO3_FOR_VPC`` env var.  Pass an explicit
    bool to skip the lookup (useful for unit tests).

    2026-06-24 -- OBSOLETE FOR THE BUCKET-PREFIXED VPCE PATH.  Operator
    verified on the pod that DuckDB httpfs reads ``s3://`` URLs
    natively (no presigning, no boto3 fallback) when:

        SET s3_endpoint='bucket.vpce-<id>.s3.<region>.vpce.amazonaws.com'
        SET s3_url_style='path'
        SET s3_use_ssl=true
        SET s3_region/access_key_id/secret_access_key/session_token

    Result: ``SELECT * FROM 's3://bucket/key' LIMIT 5`` succeeded
    against a hive-partitioned parquet (``business_close_date=2025-09-30
    /code=ACBS-2300-EMEA/businessevent=S00/``).  The libcurl ``=``
    URL-encoding bug this helper was meant to dodge does NOT fire
    with this combination -- path-style addressing keeps the ``=``
    chars in a URL segment libcurl encodes consistently with the way
    AWS reconstructs the canonical request for SigV4.

    Since the chokepoint ``normalize_vpce_endpoint_for_s3_data``
    now guarantees every consumer sees the ``bucket.``-prefixed VPCE
    endpoint, AND the SET sites all consult ``effective_path_style``
    (which auto-flips to path-style for VPCE), the presigning
    workaround actively HARMS production -- it rewrites s3:// URLs
    to presigned HTTPS URLs whose subsequent libcurl GET returns
    HTTP 0 / CURLE_GOT_NOTHING (the new bug that this helper
    introduced after the original libcurl issue went away).

    Default is now OFF.  Operators who genuinely need the legacy
    boto3 presign-then-stream path can flip ``QS_FORCE_BOTO3_FOR_VPC=1``
    or ``s3.force_boto3_for_vpc=true`` in config.

    Used by:
      - core/duckdb_subprocess.py (the subprocess pre-download branch)
      - in-process httpfs callers that need to know whether to route
        via the s3_readers framework instead of hitting httpfs directly
    """
    # Switch lookup.
    if config_switch_on is None:
        env_v = os.environ.get("QS_FORCE_BOTO3_FOR_VPC", "").strip()
        if env_v in ("0", "false", "FALSE"):
            config_switch_on = False
        elif env_v in ("1", "true", "TRUE"):
            config_switch_on = True
        else:
            try:
                from core.config import s3 as _s3_cfg_vpc
                # 2026-06-24 -- flipped to False (was True).  See
                # docstring above for the operator-verified rationale.
                config_switch_on = bool(getattr(
                    _s3_cfg_vpc, "force_boto3_for_vpc", False))
            except Exception:
                config_switch_on = False
    if not config_switch_on:
        return False, ("VPC workaround disabled (default) -- DuckDB "
                       "httpfs reads s3:// URLs natively via "
                       "bucket.vpce-XXX endpoint + path-style + creds; "
                       "the libcurl '=' bug doesn't fire with this "
                       "combination.  Set QS_FORCE_BOTO3_FOR_VPC=1 to "
                       "re-enable the legacy presign-rewrite workaround.")
    if not is_vpc_endpoint_url(endpoint_url):
        return False, "endpoint is not a VPC interface endpoint"
    if not setup_sql:
        return False, "no setup SQL to inspect"
    if not has_hive_partition_paths_in_sql(setup_sql):
        return False, ("VPC endpoint detected but no hive-partition paths "
                       "in SQL -- flat keys are safe through native httpfs")
    return True, ("VPC endpoint + hive-partition paths detected -- "
                  "legacy QS_FORCE_BOTO3_FOR_VPC=1 path active "
                  "(rare; default since 2026-06-24 is native httpfs).")
