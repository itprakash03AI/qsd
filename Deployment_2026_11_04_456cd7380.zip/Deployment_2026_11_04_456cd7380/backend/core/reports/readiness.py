"""Business-date READINESS on a report -- "is this number final?" (2026-09-28).

A finance viewer opening a report before 09:00 needs one sentence beside
"Data as of": whether the DATA for the business date is complete, from the
same evidence the feeds wait on.  This module answers it by handing the
report's declared dependencies (``report_dependency_mappings``, the feed
mapping's vocabulary keyed by report) to THE gate --
``core.feed.etl_dependency.evaluate_gate_over_rows`` -- so a report and a
feed naming the same dependency are told the same thing.  There is no
second readiness engine here: this module only decides WHICH business date
the report is asking about, projects the gate's verdicts into a sentence,
and records the verdict a run was served under (the SLO's evidence).

Four states, never folded:

    complete    every dependency MET (or NOT EXPECTED on its own calendar,
                or SKIPPED by an operator -- said so in the sentence)
    partial     at least one dependency NOT MET -- "waiting on X (usually
                by 04:19)"; the number may change
    unknown     nothing is not met but at least one could not be read --
                "could not tell: <reason>".  UNKNOWN IS NEVER COMPLETE.
    undeclared  the report declares no dependencies: nothing can be said,
                and nothing is claimed

The business date is the report's date parameter -- the one the readiness
subject names, else the first ``date`` / ``date_range`` parameter -- as the
caller resolved it (``@PREV_BUSINESS_DAY:LDN`` and friends go through the
one calendar-token resolver in the API layer), else today (UTC).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

STATE_COMPLETE = "complete"
STATE_PARTIAL = "partial"
STATE_UNKNOWN = "unknown"
STATE_UNDECLARED = "undeclared"

#: Parameter types that carry a business date.
DATE_PARAMETER_TYPES = ("date", "date_range")

SOURCE_PARAMETER = "parameter"          # the named / first date parameter's value
SOURCE_PARAMETER_DEFAULT = "parameter_default"
SOURCE_REQUEST = "request"              # ?business_date= on the readiness route
SOURCE_TODAY = "today"


@dataclass
class BusinessDateChoice:
    business_date: date
    source: str
    parameter: Optional[str] = None
    #: why the parameter's value could not be used (kept, never hidden)
    note: Optional[str] = None


@dataclass
class Readiness:
    report_id: int
    business_date: date
    business_date_source: str
    business_date_param: Optional[str]
    state: str
    summary: str
    dependencies: List[dict] = field(default_factory=list)
    waiting_on: List[str] = field(default_factory=list)
    unreadable: List[str] = field(default_factory=list)
    evaluated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    note: Optional[str] = None

    @property
    def complete(self) -> bool:
        return self.state == STATE_COMPLETE

    @classmethod
    def from_dict(cls, d: dict) -> "Readiness":
        """The verdict back from :meth:`to_dict` (2026-11-03: a run handed to
        a query pod carries the verdict the API decided at submit, so the
        pod's terminal write records the SAME one -- never a re-evaluation)."""
        d = dict(d or {})
        bd = d.get("business_date")
        ev = d.get("evaluated_at")
        return cls(
            report_id=int(d.get("report_id") or 0),
            business_date=date.fromisoformat(str(bd)[:10]) if bd else date.today(),
            business_date_source=str(d.get("business_date_source") or ""),
            business_date_param=d.get("business_date_param"),
            state=str(d.get("state") or ""),
            summary=str(d.get("summary") or ""),
            dependencies=list(d.get("dependencies") or []),
            waiting_on=list(d.get("waiting_on") or []),
            unreadable=list(d.get("unreadable") or []),
            evaluated_at=(datetime.fromisoformat(str(ev)) if ev else datetime.now(timezone.utc)),
            note=d.get("note"),
        )

    def to_dict(self) -> dict:
        return {
            "report_id": self.report_id,
            "business_date": self.business_date.isoformat(),
            "business_date_source": self.business_date_source,
            "business_date_param": self.business_date_param,
            "state": self.state,
            "complete": self.complete,
            "summary": self.summary,
            "dependencies": list(self.dependencies),
            "waiting_on": list(self.waiting_on),
            "unreadable": list(self.unreadable),
            "evaluated_at": self.evaluated_at.isoformat(),
            "note": self.note,
        }


# ── which business date? ─────────────────────────────────────────────────

def _parse_date_value(value: Any) -> Optional[date]:
    """A parameter's RESOLVED value as a date: ``YYYY-MM-DD[...]``, a date, or
    a date_range's ``to`` (the end of the range is the date the numbers are
    "as of")."""
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, dict):
        for key in ("to", "end", "from", "start"):
            if value.get(key) not in (None, ""):
                return _parse_date_value(value[key])
        return None
    if isinstance(value, (list, tuple)) and value:
        return _parse_date_value(value[-1])
    if isinstance(value, str):
        text = value.strip()
        if len(text) >= 10:
            try:
                return date.fromisoformat(text[:10])
            except ValueError:
                return None
    return None


def choose_business_date(params: List[dict], param_values: Dict[str, Any], *,
                         subject: Optional[dict] = None,
                         resolve: Optional[Callable[[Any], Any]] = None,
                         today: Optional[date] = None) -> BusinessDateChoice:
    """The business date a readiness question is about.

    ``params`` are the report's parameter rows; ``param_values`` the values
    the run was asked with; ``resolve`` renders a shortcut (``@TODAY``,
    ``@PREV_BUSINESS_DAY:LDN``) to a literal -- the API passes its own
    resolver, which REFUSES an unrenderable token (a 400 on the run, the
    right answer), so no calendar is guessed here.
    """
    t = today or datetime.now(timezone.utc).date()
    by_name = {str(p.get("name")): p for p in (params or []) if p.get("name")}
    wanted = str((subject or {}).get("business_date_param") or "").strip() or None
    chosen: Optional[dict] = None
    note: Optional[str] = None
    if wanted:
        chosen = by_name.get(wanted)
        if chosen is None:
            note = (f"the readiness declaration names parameter {wanted!r}, "
                    f"which the report no longer has")
    if chosen is None:
        for p in (params or []):
            if str(p.get("parameter_type") or "") in DATE_PARAMETER_TYPES:
                chosen = p
                break
    if chosen is None:
        return BusinessDateChoice(t, SOURCE_TODAY, None, note)
    name = str(chosen.get("name"))
    raw = (param_values or {}).get(name)
    source = SOURCE_PARAMETER
    if raw in (None, "", [], {}):
        raw = chosen.get("default_value")
        source = SOURCE_PARAMETER_DEFAULT
    if raw in (None, "", [], {}):
        return BusinessDateChoice(
            t, SOURCE_TODAY, name,
            note or f"parameter {name!r} has no value and no default; today is used")
    resolved = resolve(raw) if resolve is not None else raw
    parsed = _parse_date_value(resolved)
    if parsed is None:
        return BusinessDateChoice(
            t, SOURCE_TODAY, name,
            note or f"parameter {name!r} value {resolved!r} is not a date; today is used")
    return BusinessDateChoice(parsed, source, name, note)


# ── the verdicts, as a sentence ──────────────────────────────────────────

def _hhmm(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        try:
            value = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    if not isinstance(value, datetime):
        return None
    if value.tzinfo is not None:
        value = value.astimezone(timezone.utc)
    return value.strftime("%H:%M")


def _usual_by(db: Any, name: str, business_date: date, now: datetime) -> tuple:
    """``(usual_by HH:MM or None, observations or None)`` from the arrival
    ledger through THE clocks function -- the overdue clock is minted only
    from a high-confidence profile (FR-SLA-04), exactly as for a feed."""
    try:
        from core.feed.acting_time import compute_clocks
        from core.feed.ledger import arrival_profile
        profile = arrival_profile(db, name, None, now=now)
        clocks = compute_clocks(business_date=business_date,
                                arrival_profile=profile)
        usual = clocks.overdue_at.strftime("%H:%M") if clocks.overdue_at else None
        return usual, int(getattr(profile, "observations", 0) or 0)
    except Exception as exc:                          # noqa: BLE001
        logger.debug("[readiness] arrival profile for %s unreadable: %s",
                     name, exc)
        return None, None


def _describe(entry: dict) -> str:
    """One dependency, in the words the sentence uses."""
    from core.feed.dependency_gate import MET, NOT_EXPECTED, UNKNOWN
    name = entry["name"]
    verdict = entry["verdict"]
    if verdict == MET:
        if entry.get("asserted"):
            return f"{name} skipped by an operator"
        at = entry.get("arrived_at")
        return f"{name} arrived {at}" if at else f"{name} arrived"
    if verdict == NOT_EXPECTED:
        return f"{name} not expected today (its own calendar)"
    if verdict == UNKNOWN:
        return f"{name}: {entry.get('reason') or 'could not be read'}"
    usual = entry.get("usual_by")
    return f"{name} (usually by {usual})" if usual else name


def project_gate(report_id: int, business_date: date, gate: Any, *,
                 choice: BusinessDateChoice, db: Any = None,
                 now: Optional[datetime] = None) -> Readiness:
    """The gate's answer for a report, as the four states and one sentence.
    Pure over ``gate`` except for the optional "usually by" lookup."""
    from core.feed.dependency_gate import MET, NOT_EXPECTED, NOT_MET, UNKNOWN
    at_now = now or datetime.now(timezone.utc)
    bd_iso = business_date.isoformat()
    base = dict(report_id=report_id, business_date=business_date,
                business_date_source=choice.source,
                business_date_param=choice.parameter, note=choice.note,
                evaluated_at=at_now)
    if gate is None:
        return Readiness(state=STATE_UNKNOWN,
                         summary=f"Could not tell for {bd_iso} -- the dependency "
                                 f"gate is not available in this build",
                         **base)
    verdicts = list(getattr(gate, "verdicts", []) or [])
    if not verdicts:
        return Readiness(state=STATE_UNDECLARED,
                         summary=f"No readiness dependencies are declared for "
                                 f"this report -- nothing can be said about "
                                 f"{bd_iso}",
                         **base)
    entries: List[dict] = []
    for v in verdicts:
        entry = {
            "name": v.dependency_name,
            "verdict": v.verdict,
            "reason": v.reason,
            "satisfies": bool(v.satisfies),
            "asserted": bool(v.asserted),
            "arrived_at": _hhmm(v.last_seen) if v.verdict == MET else None,
            "last_seen": (v.last_seen.isoformat()
                          if isinstance(v.last_seen, datetime) else
                          (str(v.last_seen) if v.last_seen else None)),
            "usual_by": None,
            "observations": None,
            "sources": ([dict(s) for s in v.sources] if v.sources else None),
        }
        if v.verdict == NOT_MET and db is not None:
            entry["usual_by"], entry["observations"] = _usual_by(
                db, v.dependency_name, business_date, at_now)
        entries.append(entry)
    not_met = [e for e in entries if e["verdict"] == NOT_MET]
    unknown = [e for e in entries if e["verdict"] == UNKNOWN]
    waiting = [e["name"] for e in not_met]
    unreadable = [e["name"] for e in unknown]
    if not_met:
        text = (f"Partial for {bd_iso} -- waiting on "
                + ", ".join(_describe(e) for e in not_met))
        if unknown:
            text += "; could not tell: " + "; ".join(_describe(e) for e in unknown)
        text += " -- numbers may change"
        state = STATE_PARTIAL
    elif unknown:
        text = (f"Could not tell for {bd_iso} -- "
                + "; ".join(_describe(e) for e in unknown))
        state = STATE_UNKNOWN
    else:
        text = (f"Complete for {bd_iso} -- "
                + ", ".join(_describe(e) for e in entries
                            if e["verdict"] in (MET, NOT_EXPECTED)))
        state = STATE_COMPLETE
    return Readiness(state=state, summary=text, dependencies=entries,
                     waiting_on=waiting, unreadable=unreadable, **base)


# ── the entry points ─────────────────────────────────────────────────────

def evaluate_readiness(db: Any, report: dict, business_date: date, *,
                       choice: Optional[BusinessDateChoice] = None,
                       now: Optional[datetime] = None) -> Readiness:
    """Readiness of ``report`` for ``business_date`` -- the report's
    mapping rows through THE gate.  A gate that cannot be read is
    ``unknown`` with the reason, never complete."""
    from core.feed.etl_dependency import evaluate_gate_over_rows
    report_id = int(report["id"])
    ch = choice or BusinessDateChoice(business_date, SOURCE_REQUEST, None)
    try:
        rows = db.list_report_dependency_mappings_with_tracking(report_id, business_date)
        gate = evaluate_gate_over_rows(db, rows, business_date)
    except Exception as exc:                          # noqa: BLE001
        logger.error("[readiness] report %s @ %s: the gate could not be read: %s",
                     report_id, business_date, exc)
        return Readiness(
            report_id=report_id, business_date=business_date,
            business_date_source=ch.source, business_date_param=ch.parameter,
            state=STATE_UNKNOWN,
            summary=(f"Could not tell for {business_date.isoformat()} -- the "
                     f"readiness gate could not be read ({type(exc).__name__}: {exc})"),
            note=ch.note, evaluated_at=now or datetime.now(timezone.utc))
    return project_gate(report_id, business_date, gate, choice=ch, db=db, now=now)


def readiness_for_run(db: Any, report: dict, param_values: Dict[str, Any], *,
                      resolve: Optional[Callable[[Any], Any]] = None,
                      params: Optional[List[dict]] = None,
                      now: Optional[datetime] = None) -> Readiness:
    """Readiness for the business date a RUN is asking about: the date
    parameter as given (or its default), resolved by the caller's shortcut
    resolver, else today.  What the execute routes stamp on the envelope."""
    report_id = int(report["id"])
    if params is None:
        params = db.list_report_parameters(report_id) or []
    try:
        subject = db.get_report_readiness_subject(report_id)
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[readiness] subject row for report %s unreadable: %s",
                       report_id, exc)
        subject = None
    choice = choose_business_date(params, param_values or {}, subject=subject,
                                  resolve=resolve)
    return evaluate_readiness(db, report, choice.business_date, choice=choice,
                              now=now)


def record_readiness_run(db: Any, readiness: Readiness, *, execution_id: Optional[str],
                         executed_by: Optional[str], surface: str) -> Optional[dict]:
    """Write the verdict a run was served under (``report_readiness_runs``)
    -- the SLO's evidence.  Fail-open and logged: a ledger write must never
    fail the run it describes, but a silent miss would make every promise
    read as missed."""
    try:
        return db.record_report_readiness_run({
            "report_id": readiness.report_id,
            "execution_id": execution_id,
            "business_date": readiness.business_date,
            "state": readiness.state,
            "summary": readiness.summary[:2000],
            "surface": surface,
            "executed_by": executed_by,
            "evaluated_at": readiness.evaluated_at,
        })
    except Exception as exc:                          # noqa: BLE001
        logger.error("[readiness] could not record the readiness of run %s for "
                     "report %s @ %s (%s) -- the SLO rule will not see this run",
                     execution_id, readiness.report_id, readiness.business_date, exc)
        return None


__all__ = [
    "STATE_COMPLETE", "STATE_PARTIAL", "STATE_UNKNOWN", "STATE_UNDECLARED",
    "DATE_PARAMETER_TYPES", "BusinessDateChoice", "Readiness",
    "choose_business_date", "project_gate", "evaluate_readiness",
    "readiness_for_run", "record_readiness_run",
]
