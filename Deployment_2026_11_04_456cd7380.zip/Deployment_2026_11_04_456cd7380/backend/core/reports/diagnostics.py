"""The report DIAGNOSTICS panel -- "why is this number different?" on the screen (2026-10-30).

The owner: "more parameter diagnostic".  Before this, the answer to "which
value did my run use, and where did it go?" was in the logs:
``_build_report_filters`` logged a parameter that filtered nothing, the
engine logged ``source filters bound (t.sys=2 value(s))``, and the scan
counts were on the admin-only diagnose page.  Plan:
``docs/REPORT_OUTLINE_AND_DETAIL_LINKS_2026_10_30.html`` §6.

THE RULE: THE PANEL SHOWS WHAT THE RUN RECORDED -- IT NEVER RECOMPUTES A GUESS.

* :func:`note_source_filters` is called BY THE ENGINE at the moment it puts
  the values into the dataset's own WHERE (``FederationEngine.
  _execute_dataset_query_inner`` step 1b) and stamps the condition before and
  after -- the text the source received -- on the execution's diagnostic
  entry (``core.query_diagnostic_store``).
* :func:`record_report_run` is called BY THE ROUTE at the end of a run, with
  the very filter list and source bindings the run used, the result the
  engine returned, and the diagnostic entry the engine and the reader stamped.
  It writes ONE durable row (``report_run_diagnostics``), so a run on another
  pod, or before a restart, still answers.
* :func:`project_for_caller` serves that row -- the SQL only to a caller who
  may EDIT the report (the rule ``_enrich_source_parameters`` uses for
  ``source_sql``).

UNKNOWN SAYS SO.  Every fact the run did not record is ``None`` beside a
``*_words`` sentence that says "not recorded" -- never blank, never 0.  A run
with no row at all answers ``recorded: false`` with the reason and what the
execution row itself holds.

Recording is BEST-EFFORT by construction: a diagnostic must never be the
reason a report fails, so every entry point swallows and logs.

THE PLACEMENTS ("applied where"), in the words a support person reads:

=========================  ==================================================
``source``                 inside the dataset's own query (filtered at the
                           source) -- with the exact condition it received
``result``                 on the dataset's results -- with the condition,
                           where that ran, and WHY it was not put inside the
                           dataset's query
``not_applied_empty``      no value: All, or the query's own condition
``not_applied_unbound``    a value was given, but the parameter is linked to
                           no column and no condition, so it filtered nothing
=========================  ==================================================
"""
from __future__ import annotations

import logging
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional, Sequence

from core.reports.param_model import is_empty, normalize_value, value_words

logger = logging.getLogger(__name__)

PLACEMENT_SOURCE = "source"
PLACEMENT_RESULT = "result"
PLACEMENT_NONE_EMPTY = "not_applied_empty"
PLACEMENT_NONE_UNBOUND = "not_applied_unbound"
#: (rig 2026-11-01) a business date whose PERIOD replaced its filter: it only says "as of"
PLACEMENT_REPLACED = "replaced_by_period"
PLACEMENTS = (PLACEMENT_SOURCE, PLACEMENT_RESULT, PLACEMENT_NONE_EMPTY, PLACEMENT_NONE_UNBOUND)

#: the key the engine's note travels under on the execution's diagnostic entry
STORE_KEY = "source_filters_applied"

NOT_RECORDED = "not recorded"

#: a recorded SQL longer than this is kept to this many characters and SAYS so
MAX_SQL_CHARS = 200_000

#: the version of the ``facts`` shape (a reader can tell an old row)
FACTS_VERSION = 1

_OP_SQL = {"eq": "=", "neq": "<>", "gt": ">", "gte": ">=", "lt": "<", "lte": "<=",
           "like": "LIKE", "contains": "contains", "in": "IN", "not_in": "NOT IN",
           "between": "BETWEEN", "is_null": "IS NULL", "is_not_null": "IS NOT NULL"}


# ── the engine's note ──────────────────────────────────────────────────────

def note_source_filters(execution_id: Any, sql_before: str, sql_after: str,
                        dialect: Optional[str], bindings: Sequence[Dict[str, Any]]) -> None:
    """Stamp, per source binding, the condition as the dataset's query wrote it
    and as the run sent it.  Called by the engine right after
    ``core.source_filters.apply``; reads both texts with the same parser, so
    ``after`` is the conjunct the source received, not a rendering of ours.
    A binding with no value is stamped with ``after = before`` and
    ``bound: False`` (the query's own condition stood)."""
    if not execution_id:
        return
    try:
        from core import source_filters as _sf
        before = _sf.discover(sql_before or "", dialect).by_key()
        after_preds = {p.index: p for p in _sf.discover(sql_after or "", dialect).predicates}
        out: List[Dict[str, Any]] = []
        for b in bindings or []:
            key = str(b.get(_sf.SOURCE_KEY) or "").strip().lower()
            pred = before.get(key)
            if pred is None:
                continue
            new = after_preds.get(pred.index)
            after_sql = new.sql if new is not None else None
            out.append({"key": key, "before": pred.sql, "after": after_sql,
                        "bound": bool(after_sql) and after_sql != pred.sql,
                        "table": pred.table_ref or pred.table or None})
        from core.query_diagnostic_store import record_pruning
        record_pruning(str(execution_id), {STORE_KEY: out, "source_filter_dialect": dialect or None})
    except Exception as exc:                                     # noqa: BLE001
        logger.info("[diagnostics] source-filter note skipped for %s: %s", execution_id, exc)


# ── secrets out of a SQL text ──────────────────────────────────────────────

_PRESIGNED = re.compile(r"(X-Amz-(?:Signature|Credential|Security-Token)=)[^&'\"\s)]+", re.I)


def redact_sql(sql: Optional[str]) -> Optional[str]:
    """``sql`` with every credential the product knows how to spot removed:
    the error sanitizer's patterns (connection strings, ``password=``,
    proxy credentials, AWS keys) and a presigned URL's signature, credential
    and session token.  Never truncated by the sanitizer's 500-character rule
    (that is for error messages); :data:`MAX_SQL_CHARS` applies instead."""
    if not sql:
        return None
    from core.error_sanitizer import _PATTERNS
    text = str(sql)
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return _PRESIGNED.sub(r"\1***", text)


# ── which engine read the data, in words ───────────────────────────────────

_CACHE_ENGINES = {"agg_cache": "a stored summary of this data (the aggregate cache)",
                  "result_cache": "a stored copy of this exact query's result",
                  "instance": "a saved result of this report"}
_LOCAL_ENGINES = ("duckdb", "single", "local", "multi_worker")
_S3_KINDS = ("s3",)


def _kind_label(kind: str) -> str:
    k = (kind or "").strip().lower()
    if k == "trino":
        return "Trino"
    from core.engine_attribution import engine_label
    return engine_label(k) or k


def read_by_words(engine: Optional[str], connection_kinds: Sequence[str]) -> str:
    """The plain sentence for WHICH ENGINE READ THE DATA."""
    eng = (engine or "").strip().lower()
    kinds = [str(k or "").strip().lower() for k in connection_kinds or [] if k]
    if not eng:
        return "Which engine read the data was not recorded."
    if eng in _CACHE_ENGINES:
        return f"Not read from the source: served from {_CACHE_ENGINES[eng]}."
    sql_kinds = [k for k in kinds if k not in _S3_KINDS + ("local", "file", "parquet")]
    if eng == "hybrid":
        others = ", ".join(sorted({_kind_label(k) for k in sql_kinds})) or "a SQL source"
        return f"AWS S3 read directly by QueryStudio, joined with {others} by QueryStudio."
    if eng in _LOCAL_ENGINES:
        if any(k in _S3_KINDS for k in kinds):
            return "AWS S3, read directly by QueryStudio (its own reader, DuckDB)."
        return "QueryStudio's own engine (DuckDB) -- the dataset names no outside source."
    if eng.startswith("spark"):
        return "Spark."
    if sql_kinds:
        return f"{_kind_label(sql_kinds[0])} -- the query ran at the source."
    return f"{_kind_label(eng)} -- the query ran at the source."


# ── a filter dict in words ────────────────────────────────────────────────

def _lit(v: Any) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def filter_condition(f: Dict[str, Any], columns: Dict[int, Dict[str, Any]]) -> str:
    """One filter of the run's filter list as a condition: ``Company = 'ACME'``."""
    col = columns.get(_int(f.get("column_id"))) or {}
    name = col.get("physical_name") or f"column {f.get('column_id')}"
    op = str(f.get("operator") or "eq").lower()
    val = f.get("value")
    if op in ("in", "not_in"):
        vals = val if isinstance(val, (list, tuple)) else [val]
        return f"{name} {_OP_SQL[op]} ({', '.join(_lit(v) for v in vals)})"
    if op == "between":
        return f"{name} BETWEEN {_lit(val)} AND {_lit(f.get('value2'))}"
    if op in ("is_null", "is_not_null"):
        return f"{name} {_OP_SQL[op]}"
    return f"{name} {_OP_SQL.get(op, op)} {_lit(val)}"


def _int(v: Any) -> Optional[int]:
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _param_filters(param: Dict[str, Any], pval: Any) -> List[Dict[str, Any]]:
    """The filter dicts ``_build_report_filters`` appends for ONE result
    parameter -- its own rule, mirrored so the record can FIND them in the
    filter list the run actually used (and say so when one is missing)."""
    cid = param.get("lov_column_id")
    kind = param.get("parameter_type")
    if kind == "multi_select" and isinstance(pval, list):
        return [{"column_id": cid, "operator": "in", "value": pval}]
    if kind == "date_range" and isinstance(pval, dict):
        out = []
        if pval.get("from"):
            out.append({"column_id": cid, "operator": "gte", "value": pval["from"]})
        if pval.get("to"):
            out.append({"column_id": cid, "operator": "lte", "value": pval["to"]})
        return out
    return [{"column_id": cid, "operator": "eq", "value": pval}]


def _claimed_filters(param: Dict[str, Any], pval: Any, combined_filters: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """The run's filters THIS parameter put there.  A PERIOD's are the range /
    date-set filters on its column (its dates depend on the calendar, so they
    are found, not re-derived -- rig 2026-11-01: the record said 'not recorded'
    while the IN list sat among the other filters); any other kind's are its
    own rule mirrored (``_param_filters``)."""
    if param.get("parameter_type") == "period":
        cid = _int(param.get("lov_column_id"))
        return [f for f in combined_filters or [] if _int(f.get("column_id")) == cid
                and str(f.get("operator") or "").lower() in ("in", "gte", "lte")]
    mine = _param_filters(param, pval)
    return [f for f in combined_filters or [] if any(_same_filter(f, m) for m in mine)]


def _same_filter(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    return (_int(a.get("column_id")) == _int(b.get("column_id"))
            and str(a.get("operator") or "eq").lower() == str(b.get("operator") or "eq").lower()
            and a.get("value") == b.get("value"))


# ── the run's record ──────────────────────────────────────────────────────

def _effect(column_names: Sequence[str], entry: Dict[str, Any], scan: Dict[str, Any]) -> Dict[str, Any]:
    """What the reader recorded about THIS column's filter: the reader's own
    breakdown (``filter_breakdown``: did it use the value to skip files, and
    why) and the run's files read of listed.  Rows per parameter are not
    recorded by any reader -- said, not guessed."""
    names = {str(n or "").strip().lower().split(".")[-1] for n in column_names if n}
    used = []
    for fb in entry.get("filter_breakdown") or []:
        if not isinstance(fb, dict):
            continue
        if str(fb.get("column") or "").strip().lower().split(".")[-1] in names:
            used.append({"support": fb.get("support"), "reason": fb.get("support_reason"),
                         "column_kind": fb.get("column_kind") or None})
    files_read, files_total = scan.get("files_read"), scan.get("files_total")
    if used:
        how = "; ".join(f"{u['support'] or 'used'}" + (f" ({u['reason']})" if u.get("reason") else "")
                        for u in used)
        words = f"The reader used this value to choose what to read: {how}."
        if files_total is not None:
            words += f" The run read {files_read} of {files_total} files."
    elif files_total is not None:
        words = (f"The run read {files_read} of {files_total} files; the reader did not record "
                 f"whether this value narrowed them.")
    else:
        words = "Files and partitions read were not recorded for this source."
    return {"reader_used": used or None, "files_read": files_read, "files_total": files_total,
            "rows": None, "words": words}


def _why_not_at_source(param: Dict[str, Any], col: Dict[str, Any], base_query: str,
                       discovery: Any, *, with_sql: bool = True) -> str:
    """Why the value was not put inside the dataset's query.  ``with_sql=False``
    (2026-10-30 security fix): the same answer WITHOUT any text of the query --
    a viewer the owner let into the panel sees where each value went, never
    the query's conditions (the parser's reason may quote it, a predicate IS it)."""
    if not base_query:
        return ("The dataset reads a table directly, so there is no query of its own to put the "
                "value into; the condition is part of the query sent to the source.")
    if discovery is None:
        return "Whether the dataset's query has a condition on this column was not recorded."
    if getattr(discovery, "reason", None):
        if not with_sql:
            return "The dataset's query has no condition this value could go into."
        return f"The dataset's query has no condition this value could go into: {discovery.reason}"
    name = str(col.get("physical_name") or "").strip().lower()
    for p in getattr(discovery, "predicates", ()) or ():
        if str(p.column or "").strip().lower() == name:
            if not with_sql:
                return ("The dataset's query has its own condition on this column, but this parameter is "
                        "linked to the report's column, not to that condition. Link it to the condition "
                        "(report builder: Filter at the source) to filter at the source.")
            return (f"The dataset's query has its own condition on {p.column} ({p.sql}), but this "
                    f"parameter is linked to the report's column, not to that condition. Link it "
                    f"to the condition (report builder: Filter at the source) to filter at the source.")
    return ("The dataset's query has no condition on this column, so the value is applied to the "
            "query's results.")


#: the plain-language fields a caller who may not see SQL is given instead
#: of the ones that quote it (``project_for_caller``)
_SQL_FREE_WORDS = {"where_words": "where_words_no_sql", "why_not_at_source": "why_not_at_source_no_sql"}


def _result_where_words(engine: Optional[str], base_query: str) -> str:
    eng = (engine or "").strip().lower()
    if eng in _CACHE_ENGINES:
        return "On the results (served from a stored copy, filtered the same way)"
    at_source = bool(eng) and eng not in _LOCAL_ENGINES and eng != "hybrid" and not eng.startswith("spark")
    if not base_query:
        return ("In the query sent to the source" if at_source
                else "In the query QueryStudio ran on the data it read")
    if at_source:
        return "On the dataset's results -- sent to the source with the query, around the dataset's own query"
    return "On the dataset's results -- applied by QueryStudio around the dataset's own query"


def parameter_placements(*, params: Sequence[Dict[str, Any]], param_values: Dict[str, Any],
                         combined_filters: Sequence[Dict[str, Any]],
                         source_bindings: Sequence[Dict[str, Any]],
                         applied: Sequence[Dict[str, Any]], columns: Dict[int, Dict[str, Any]],
                         base_query: str, discovery: Any, engine: Optional[str],
                         entry: Dict[str, Any], scan: Dict[str, Any],
                         resolve: Callable[[Any], Any], db: Any = None) -> List[Dict[str, Any]]:
    """One record per declared parameter: its value and WHERE the run applied it.

    ``combined_filters`` / ``source_bindings`` are the lists the run used;
    ``applied`` is the engine's own note (:func:`note_source_filters`)."""
    by_key = {str(a.get("key") or ""): a for a in applied or []}
    bound_keys = {str(b.get("source_column") or "").strip().lower() for b in source_bindings or []}
    preds = {}
    if discovery is not None and not getattr(discovery, "reason", None):
        preds = {p.key: p for p in getattr(discovery, "predicates", ()) or ()}
    from core.reports import period as _period
    try:
        replaced = _period.anchors_replaced(list(params or []), param_values or {})
    except Exception:                                        # noqa: BLE001
        replaced = set()
    by_anchor = {p.get("depends_on_param_id"): p for p in params or [] if p.get("parameter_type") == "period"}
    out: List[Dict[str, Any]] = []
    for p in params or []:
        name = p.get("name")
        given = (param_values or {}).get(name)
        from_default = is_empty(given) and p.get("default_value") not in (None, "")
        raw = p.get("default_value") if from_default else given
        try:
            value = None if is_empty(raw) else resolve(normalize_value(p, raw))
        except Exception as exc:                             # noqa: BLE001
            value = None
            logger.info("[diagnostics] value of %r not resolved: %s", name, exc)
        rec: Dict[str, Any] = {
            "name": name, "label": p.get("label") or name, "type": p.get("parameter_type"),
            "given": given, "from_default": bool(from_default),
            "default": p.get("default_value") if p.get("default_value") not in (None, "") else None,
            "value": value, "value_words": value_words(p, value),
            "placement": None, "where_words": None, "condition": None,
            "condition_before": None, "why_not_at_source": None, "effect": None,
        }
        src = str(p.get("source_column") or "").strip().lower()
        col = columns.get(_int(p.get("lov_column_id"))) or {}
        if src:
            note = by_key.get(src)
            pred = preds.get(src)
            if is_empty(value):
                rec["placement"] = PLACEMENT_NONE_EMPTY
                own = (note or {}).get("before") or (pred.sql if pred is not None else None)
                rec["condition"] = own
                rec["where_words"] = ("Not applied -- no value, so the dataset's query ran with its own "
                                      f"condition: {own}" if own else
                                      "Not applied -- no value, so the dataset's query ran as written")
                rec["where_words_no_sql"] = ("Not applied -- no value, so the dataset's query ran with its "
                                             "own condition on this column" if own else rec["where_words"])
            else:
                rec["placement"] = PLACEMENT_SOURCE
                rec["condition_before"] = (note or {}).get("before") or (pred.sql if pred is not None else None)
                if note and note.get("after"):
                    rec["condition"] = note["after"]
                    rec["where_words"] = "Inside the dataset's own query (filtered at the source)"
                elif src in bound_keys:
                    rec["where_words"] = ("Inside the dataset's own query (filtered at the source); the exact "
                                          "condition sent was not recorded")
                else:
                    rec["where_words"] = "Inside the dataset's own query -- the run did not record the binding"
            rec["effect"] = _effect([pred.column if pred is not None else src], entry, scan)
        elif not p.get("lov_column_id"):
            if is_empty(value):
                rec["placement"] = PLACEMENT_NONE_EMPTY
                rec["where_words"] = "Not applied -- no value chosen"
            else:
                rec["placement"] = PLACEMENT_NONE_UNBOUND
                rec["where_words"] = ("Not applied -- this parameter is not linked to a column of the report "
                                      "or a condition of the dataset's query, so it filtered nothing. Set its "
                                      "Filter Column in the report builder.")
        elif is_empty(value):
            rec["placement"] = PLACEMENT_NONE_EMPTY
            rec["where_words"] = ("Not applied -- All (no value chosen)"
                                  if p.get("parameter_type") in ("dropdown", "multi_select", None, "")
                                  else "Not applied -- no value chosen")
        elif str(name) in replaced:
            per = by_anchor.get(p.get("id")) or {}
            rec["placement"] = PLACEMENT_REPLACED
            rec["where_words"] = (f"As of only -- the period '{per.get('label') or per.get('name')}' replaced this "
                                  "date's own filter with its dates")
        else:
            sent = _claimed_filters(p, value, combined_filters)
            rec["placement"] = PLACEMENT_RESULT
            if sent:
                rec["condition"] = " AND ".join(filter_condition(f, columns) for f in sent)
                rec["where_words"] = _result_where_words(engine, base_query)
                if p.get("parameter_type") == "period":
                    anchor_p = next((x for x in params or [] if x.get("id") == p.get("depends_on_param_id")), None)
                    try:
                        _cal, cal_words = _period.calendar_for(anchor_p, None, db)
                    except Exception:                        # noqa: BLE001
                        cal_words = None
                    if cal_words:
                        rec["where_words"] += f" -- the dates are business days ({cal_words})"
            else:
                rec["where_words"] = ("On the results -- but the run's filter list does not carry it "
                                      "(not recorded)")
            rec["why_not_at_source"] = _why_not_at_source(p, col, base_query, discovery)
            rec["why_not_at_source_no_sql"] = _why_not_at_source(p, col, base_query, discovery, with_sql=False)
            rec["effect"] = _effect([col.get("physical_name")], entry, scan)
        # the SQL-free twins (project_for_caller serves them to a caller who
        # may not see the query); most sentences never quote it
        rec.setdefault("where_words_no_sql", rec["where_words"])
        if rec.get("why_not_at_source") is not None:
            rec.setdefault("why_not_at_source_no_sql", rec["why_not_at_source"])
        out.append(rec)
    return out


def _other_filters(combined_filters: Sequence[Dict[str, Any]], placements: Sequence[Dict[str, Any]],
                   params: Sequence[Dict[str, Any]], columns: Dict[int, Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Filters on the results that no parameter put there: the report's own
    fixed filters and anything the caller added (a drill)."""
    claimed: List[Dict[str, Any]] = []
    by_name = {p.get("name"): p for p in params or []}
    for rec in placements:
        if rec.get("placement") == PLACEMENT_RESULT and rec.get("value") is not None:
            claimed.extend(_claimed_filters(by_name.get(rec["name"]) or {}, rec["value"], combined_filters))
    out = []
    for f in combined_filters or []:
        if any(_same_filter(f, c) for c in claimed):
            continue
        out.append({"condition": filter_condition(f, columns),
                    "where_words": "On the dataset's results (a filter of the report itself, or one added "
                                   "for this run)"})
    return out


def _cache_words(result: Dict[str, Any], engine: Optional[str]) -> Dict[str, Any]:
    if result.get("cache_hit"):
        age = result.get("cache_age_seconds")
        return {"served": "aggregate_cache", "age_seconds": age,
                "words": ("Served from a stored summary of this data (the aggregate cache)"
                          + (f", {int(age)} s old" if isinstance(age, (int, float)) and age else ""))}
    if result.get("result_cache_hit"):
        fresh = result.get("cache_freshness")
        how = {"verified": "checked against the source and unchanged",
               "unknown": "not checked against the source"}.get(str(fresh or ""), NOT_RECORDED)
        return {"served": "result_cache", "freshness": fresh,
                "words": f"Served from a stored copy of this exact query's result ({how})"}
    if (engine or "") in _CACHE_ENGINES:
        return {"served": engine, "words": f"Served from {_CACHE_ENGINES[engine]}"}
    if result.get("result_cache_hit") is False or result.get("cache_hit") is False:
        return {"served": "fresh", "words": "Fresh: read from the source for this run"}
    return {"served": None, "words": "Whether a cache served this run was not recorded"}


def _canvas_tiles(report: Dict[str, Any]) -> List[Dict[str, Any]]:
    canvas = ((report or {}).get("layout_config") or {}).get("canvas") or {}
    out = []
    for t in canvas.get("tiles") or []:
        if not isinstance(t, dict):
            continue
        linked = t.get("linked")
        out.append({"id": t.get("id"), "kind": t.get("kind"), "title": t.get("title") or None,
                    "linked_setting": linked if isinstance(linked, bool) else None})
    return out


def _connection_names(db: Any, report: Dict[str, Any], ds: Dict[str, Any]) -> List[str]:
    """The names of the connections this run read: its dataset's, or its SQL file's."""
    ids = list((ds or {}).get("connection_ids") or [])
    if not ids and report.get("raw_connection_override_id"):
        ids = [report["raw_connection_override_id"]]
    if not ids and report.get("raw_sql_file_id"):
        try:
            ids = [(db.get_sql_file(int(report["raw_sql_file_id"])) or {}).get("connection_id")]
        except Exception as exc:                             # noqa: BLE001
            logger.info("[diagnostics] SQL file of report unreadable: %s", exc)
    names = []
    for cid in ids:
        try:
            name = (db.get_connection(int(cid)) or {}).get("name") if cid else None
        except Exception:                                    # noqa: BLE001
            name = None
        if name:
            names.append(str(name))
    return names


def _connection_kinds(db: Any, ds: Dict[str, Any]) -> List[str]:
    kinds = []
    for cid in (ds or {}).get("connection_ids") or []:
        try:
            c = db.get_connection(int(cid)) or {}
        except Exception:                                    # noqa: BLE001
            c = {}
        k = str(c.get("connection_type") or "").strip().lower()
        if k:
            kinds.append(k)
    return kinds


def build_run_facts(db: Any, *, report: Dict[str, Any], report_id: int, execution_id: str,
                    param_values: Dict[str, Any], combined_filters: Sequence[Dict[str, Any]],
                    source_bindings: Sequence[Dict[str, Any]], result: Dict[str, Any],
                    username: Optional[str], surface: str) -> Dict[str, Any]:
    """The facts of ONE run, from what it used and what it stamped."""
    from api.business_reports_api import _report_parameters_for_execution, _resolve_param_value
    from core.query_diagnostic_store import get_pruning
    from core.reports.scan_disclosure import scan_disclosure

    result = dict(result or {})
    params = list(_report_parameters_for_execution(report, db, report_id) or [])
    ds: Dict[str, Any] = {}
    if report.get("dataset_id"):
        try:
            ds = db.get_dataset_full(int(report["dataset_id"])) or {}
        except Exception as exc:                             # noqa: BLE001
            logger.info("[diagnostics] dataset of report %s unreadable: %s", report_id, exc)
    columns = {_int(c.get("id")): c for c in ds.get("columns") or [] if _int(c.get("id")) is not None}
    base_query = str(ds.get("base_query") or "")
    entry = dict(get_pruning(str(execution_id)) or {})
    applied = list(entry.get(STORE_KEY) or [])
    discovery = None
    if base_query:
        try:
            from core import source_filters as _sf
            dialect = entry.get("source_filter_dialect")
            if dialect is None:
                from api.business_reports_api import _federation_engine
                if _federation_engine is not None:
                    dialect = _federation_engine.dataset_sql_dialect(ds)
            discovery = _sf.discover_cached(base_query, dialect)
        except Exception as exc:                             # noqa: BLE001
            logger.info("[diagnostics] conditions of report %s's query not read: %s", report_id, exc)
    scan = scan_disclosure(execution_id)
    engine = (result.get("execution_engine") or entry.get("execution_engine") or None)
    engine = str(engine).strip() or None if engine else None
    kinds = _connection_kinds(db, ds)

    placements = parameter_placements(
        params=params, param_values=param_values or {}, combined_filters=combined_filters or [],
        source_bindings=source_bindings or [], applied=applied, columns=columns,
        base_query=base_query, discovery=discovery, engine=engine, entry=entry, scan=scan,
        resolve=_resolve_param_value, db=db)

    sql_exec = result.get("sql_executed") or ""
    sql_gen = result.get("sql_generated") or ""
    sql = redact_sql(sql_exec or sql_gen)
    sql_cut = bool(sql and len(sql) > MAX_SQL_CHARS)
    if sql_cut:
        sql = sql[:MAX_SQL_CHARS]
    from core.engine_attribution import engine_label
    rows = result.get("total_rows")
    duration = result.get("duration_seconds")
    run = {
        "engine": engine, "engine_label": engine_label(engine),
        "read_by_words": read_by_words(engine, kinds),
        "connection_kinds": kinds,
        "connection_names": _connection_names(db, report, ds),
        "sql": sql,
        "sql_words": (("The statement the source received (translated for it), values filled in."
                       if sql_exec else
                       "The statement QueryStudio ran, values filled in.")
                      if sql else "The SQL of this run was not recorded."),
        "sql_cut_at": MAX_SQL_CHARS if sql_cut else None,
        "duration_seconds": duration if isinstance(duration, (int, float)) else None,
        "rows": rows if isinstance(rows, int) else None,
        "row_limit": result.get("row_limit"),
        "truncated": result.get("truncated"),
        "cache": _cache_words(result, engine),
        "scan": {k: scan.get(k) for k in ("files_read", "files_total", "manifests_read",
                                          "manifests_total", "read_reason")},
        "scan_words": (f"Read {scan['files_read']} of {scan['files_total']} files"
                       if scan.get("files_total") is not None
                       else "Files and partitions read were not recorded for this source"),
        "surface": surface,
        "dataset_id": report.get("dataset_id"),
    }
    return {
        "version": FACTS_VERSION,
        "execution_id": str(execution_id),
        "report_id": int(report_id),
        "executed_by": username or None,
        "parameters": placements,
        "other_filters": _other_filters(combined_filters, placements, params, columns),
        "run": run,
        "tiles": _canvas_tiles(report),
        "dataset_conditions": ([{"key": p.key, "condition": p.sql} for p in discovery.predicates]
                               if discovery is not None and not discovery.reason else []),
    }


# ── storage ───────────────────────────────────────────────────────────────

_PRUNE_LOCK = threading.Lock()
_LAST_PRUNE = [0.0]
_PRUNE_EVERY_S = 3600.0


def _retention_days() -> int:
    try:
        from core.config import storage
        return max(1, int(storage.downloads_expiry_days))
    except Exception:                                        # noqa: BLE001
        return 7


def _store(db: Any, execution_id: str, report_id: int, executed_by: Optional[str],
           facts: Dict[str, Any]) -> None:
    from core.db.models import ReportRunDiagnostic
    from core.json_utils import sanitize_for_json
    clean = sanitize_for_json(facts)
    with db.get_session() as session:
        row = (session.query(ReportRunDiagnostic)
               .filter(ReportRunDiagnostic.execution_id == str(execution_id)).first())
        if row is None:
            row = ReportRunDiagnostic(execution_id=str(execution_id), report_id=int(report_id))
            session.add(row)
        row.executed_by = executed_by
        row.facts = clean
        row.recorded_at = datetime.now(timezone.utc)
        session.commit()
    _prune_if_due(db)


def _prune_if_due(db: Any) -> None:
    now = time.monotonic()
    with _PRUNE_LOCK:
        if now - _LAST_PRUNE[0] < _PRUNE_EVERY_S:
            return
        _LAST_PRUNE[0] = now
    try:
        from core.db.models import ReportRunDiagnostic
        cutoff = datetime.now(timezone.utc) - timedelta(days=_retention_days())
        with db.get_session() as session:
            n = (session.query(ReportRunDiagnostic)
                 .filter(ReportRunDiagnostic.recorded_at < cutoff)
                 .delete(synchronize_session=False))
            session.commit()
        if n:
            logger.info("[diagnostics] removed %d run records older than %s", n, cutoff.date())
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[diagnostics] retention sweep skipped: %s", exc)


def record_report_run(db: Any, *, report: Dict[str, Any], report_id: int, execution_id: str,
                      param_values: Optional[Dict[str, Any]], combined_filters: Optional[Sequence[Dict[str, Any]]],
                      source_bindings: Optional[Sequence[Dict[str, Any]]], result: Any,
                      username: Optional[str], surface: str = "interactive") -> bool:
    """Record ONE run for its Diagnostics panel.  Never raises; returns
    whether a row was written."""
    if not execution_id or db is None:
        return False
    try:
        res = result.to_dict() if hasattr(result, "to_dict") else (result or {})
        facts = build_run_facts(db, report=report or {}, report_id=report_id,
                                execution_id=str(execution_id), param_values=param_values or {},
                                combined_filters=list(combined_filters or []),
                                source_bindings=list(source_bindings or []),
                                result=res if isinstance(res, dict) else {},
                                username=username, surface=surface)
        _store(db, str(execution_id), int(report_id), username, facts)
        return True
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("[diagnostics] run %s of report %s not recorded: %s",
                       execution_id, report_id, exc)
        return False


def record_serve(db: Any, *, serve_execution_id: str, source_execution_id: str, report_id: int,
                 served_to: Optional[str]) -> bool:
    """A SERVED instance (``instances`` "ri_..." -- the stored result of an earlier run whose
    parameters and row security match the caller's) carries THAT run's record under its own
    execution id (2026-11-03).  Found on the rig: a Book click on a report opened from its saved
    result read no record for the serve's id, so the popup applied none of the report's
    parameters and listed every date.  Resolved ONCE here, when the serve is registered, so
    every reader of "this run's record" (the canvas actions, the Diagnostics panel) agrees.
    False when the source run has no record (said by the reader, never invented)."""
    src = get_run_record(db, source_execution_id)
    facts = (src or {}).get("facts") if src else None
    if not isinstance(facts, dict):
        return False
    # SECURITY (review of 951b40a90): only what the caller SHARES with that run -- the same
    # parameters and row-security scope chose the instance -- never who ran it nor that run's
    # SQL / engine facts (a per-user substitution could sit in its SQL).
    copy = {k: facts.get(k) for k in ("version", "report_id", "parameters", "other_filters", "tiles",
                                      "dataset_conditions") if k in facts}
    copy.update({"execution_id": str(serve_execution_id), "executed_by": served_to or None,
                 "served_from": str(source_execution_id),
                 "run": {"served": True, "words": "Served from a saved result of this report with the same choices."}})
    _store(db, str(serve_execution_id), int(report_id), served_to, copy)
    return True


def get_run_record(db: Any, execution_id: str) -> Optional[Dict[str, Any]]:
    from core.db.models import ReportRunDiagnostic
    with db.get_session(read_only=True) as session:
        row = (session.query(ReportRunDiagnostic)
               .filter(ReportRunDiagnostic.execution_id == str(execution_id)).first())
        return row.to_dict() if row is not None else None


# ── who may open the panel, and what they see ─────────────────────────────

#: the report setting (``layout_config``) that lets a person who may only VIEW
#: the report open its Diagnostics panel
VIEWERS_SETTING = "diagnostics_for_viewers"


def viewers_may_open(report: Dict[str, Any]) -> bool:
    return bool(((report or {}).get("layout_config") or {}).get(VIEWERS_SETTING))


def may_open_panel(report: Dict[str, Any], *, can_edit: bool, is_admin: bool) -> bool:
    """The report's owner and editors and an admin always; a person who may
    only view it when the owner allowed it (``layout_config.
    diagnostics_for_viewers``)."""
    return bool(can_edit or is_admin or viewers_may_open(report))


def action_runs(db: Any, report_id: int, execution_id: str) -> Dict[str, Any]:
    """The canvas ACTION runs (e.g. Download detail) made from this run.

    The actions feature records each click (who, what was sent, rows, time)
    in ``report_canvas_action_runs`` (model ``ReportCanvasActionRun``, keyed by
    the run's ``execution_id``).  Read through ``db.list_report_action_runs(
    report_id=, execution_id=)`` when the database layer has it, else that
    table when the model exists; with neither the section says there are
    none -- never an error, never an empty list without words."""
    reader = getattr(db, "list_report_action_runs", None)
    if not callable(reader):
        reader = _action_runs_from_table(db)
    if not callable(reader):
        return {"available": False, "runs": [], "words": "No action runs."}
    try:
        runs = list(reader(report_id=int(report_id), execution_id=str(execution_id)) or [])
    except Exception as exc:                                 # noqa: BLE001
        # the reason stays in the server log: an exception's text can carry a
        # path, a table name or a connection detail the caller must not see
        logger.warning("[diagnostics] action runs of %s unreadable: %s", execution_id, exc, exc_info=True)
        return {"available": True, "runs": [],
                "words": "The action runs could not be read just now. Try again; if it keeps failing, "
                         "ask an administrator to look at the server log."}
    from core.error_sanitizer import redact_structure
    return {"available": True, "runs": redact_structure(runs),
            "words": "No action runs." if not runs else f"{len(runs)} action run(s) from this result."}


_ACTION_RUN_FIELDS = ("id", "action_id", "tile_id", "username", "label", "values_sent", "query_string",
                      "status", "message", "file_name", "row_count", "total_rows", "file_size_bytes",
                      "created_at", "finished_at")


def _action_runs_from_table(db: Any) -> Optional[Callable[..., List[Dict[str, Any]]]]:
    try:
        from core.db import models as _m
    except Exception:                                        # noqa: BLE001
        return None
    model = getattr(_m, "ReportCanvasActionRun", None)
    if model is None or not hasattr(db, "get_session"):
        return None

    def read(*, report_id: int, execution_id: str) -> List[Dict[str, Any]]:
        with db.get_session(read_only=True) as s:
            rows = (s.query(model).filter(model.report_id == int(report_id),
                                          model.execution_id == str(execution_id))
                    .order_by(model.created_at.asc()).limit(200).all())
            out = [r.to_dict() for r in rows]
        try:   # the actions feature's own words for a run (a stale "preparing" is failed)
            from core.reports.canvas_actions import public_run
            out = [public_run(r) for r in out]
        except Exception:                                    # noqa: BLE001
            pass
        return [{k: r.get(k) for k in _ACTION_RUN_FIELDS if k in r} for r in out]
    return read


def unrecorded_answer(execution_id: str, fed: Optional[Dict[str, Any]],
                      job: Optional[Dict[str, Any]], *, with_sql: bool) -> Dict[str, Any]:
    """A run with no diagnostics row: say so, and give what the execution
    row itself holds (rows, time, the SQL) -- each "not recorded" when absent."""
    fed = fed or {}
    job = job or {}
    rows = fed.get("total_rows") if fed else job.get("total_rows")
    sql = redact_sql(fed.get("sql_generated")) if with_sql else None
    return {
        "recorded": False, "execution_id": str(execution_id),
        "reason": ("This run was not recorded for the Diagnostics panel: it ran before the panel "
                   "existed, or its record was removed after the days results are kept. Run the "
                   "report again to see how each parameter was applied."),
        "parameters": [], "other_filters": [], "tiles": [], "dataset_conditions": [],
        "run": {
            "engine": None, "engine_label": None,
            "read_by_words": "Which engine read the data was not recorded.",
            "sql": sql,
            "sql_words": ("The statement QueryStudio ran, as the execution row kept it."
                          if sql else ("The SQL is shown to the report's owner and editors."
                                       if not with_sql else "The SQL of this run was not recorded.")),
            "rows": rows if isinstance(rows, int) else None,
            "duration_seconds": fed.get("duration_seconds") if fed else None,
            "cache": {"served": None, "words": "Whether a cache served this run was not recorded"},
            "scan": {}, "scan_words": "Files and partitions read were not recorded for this source",
        },
    }


def project_for_caller(record: Dict[str, Any], *, with_sql: bool) -> Dict[str, Any]:
    """The stored facts as the caller may see them: the SQL and the exact
    conditions only for a caller who may EDIT the report (a viewer the owner
    let in sees where each value went, in words, not the query's text)."""
    facts = dict((record or {}).get("facts") or {})
    out = dict(facts)
    out["recorded"] = True
    out["recorded_at"] = record.get("recorded_at")
    out["sql_shown"] = bool(with_sql)
    params = [dict(p) for p in out.get("parameters") or []]
    if not with_sql:
        run = dict(out.get("run") or {})
        run["sql"] = None
        run["sql_words"] = "The SQL is shown to the report's owner and editors."
        out["run"] = run
        # every sentence that QUOTES the query is replaced by its SQL-free twin
        # (a record written before the twins existed gets a fixed sentence)
        for p in params:
            for field, twin in _SQL_FREE_WORDS.items():
                if p.get(field) is None:
                    continue
                p[field] = p[twin] if p.get(twin) else _sql_free_fallback(field, p)
            p["condition"] = None
            p["condition_before"] = None
    for p in params:
        for twin in _SQL_FREE_WORDS.values():
            p.pop(twin, None)
    out["parameters"] = params
    if not with_sql:
        out["other_filters"] = [dict(f, condition=None) for f in out.get("other_filters") or []]
        out["dataset_conditions"] = []
    return out


def _sql_free_fallback(field: str, p: Dict[str, Any]) -> str:
    """A record written before the SQL-free twins: the two sentences that
    could quote the query become fixed words; every other sentence never did."""
    if field == "why_not_at_source":
        return "Why it was not put inside the dataset's query is shown to the report's owner and editors."
    words = str(p.get(field) or "")
    if "condition:" in words:
        return "Not applied -- no value, so the dataset's query ran with its own condition on this column"
    return words


def band_parameters(record: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The values a run used, for a canvas BAND tile: name, label, kind, the
    value and its words, and whether it came from the default.  Nothing about
    where it was applied (that is the panel's)."""
    if not record:
        return {"recorded": False, "parameters": [],
                "words": "The values of this run were not recorded."}
    params = ((record.get("facts") or {}).get("parameters")) or []
    return {"recorded": True, "parameters": [
        {k: p.get(k) for k in ("name", "label", "type", "value", "value_words", "from_default")}
        for p in params]}


__all__ = [
    "PLACEMENTS", "PLACEMENT_SOURCE", "PLACEMENT_RESULT", "PLACEMENT_NONE_EMPTY",
    "PLACEMENT_NONE_UNBOUND", "STORE_KEY", "VIEWERS_SETTING",
    "note_source_filters", "redact_sql", "read_by_words", "filter_condition",
    "parameter_placements", "build_run_facts", "record_report_run", "get_run_record",
    "viewers_may_open", "may_open_panel", "action_runs", "unrecorded_answer",
    "project_for_caller", "band_parameters",
]
