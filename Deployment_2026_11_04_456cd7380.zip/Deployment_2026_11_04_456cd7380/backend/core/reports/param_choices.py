"""A report parameter's choices read from DATA -- ONE rule (2026-10-24).

The owner: "parameter lists come dynamically -- all distinct values from a
defined table (SAP company may come from some other table)"; "if fact_tetb
is in the query, use the cached values when the user selects those
columns"; "CQB is already caching all values -- use it".

core/reports/param_values.py decides WHICH source (saved list / partition
metadata / data / another table); this module reads the DATA ones, in this
order, every answer through THE value cache (core/column_value_cache.py,
shared with the query builder's picker) and under the reader's row security:

1. ``table`` -- the author named another table's column
   (``lov_source_connection_id`` / ``lov_source_table`` / ``lov_source_column``).
2. The report column TRACED to its source table (core/reports/column_lineage.py):
   ``SELECT DISTINCT <col> FROM <that table>`` on the dataset's one
   connection -- fast, and the same list the query builder caches.
3. Otherwise -- a computed column, a UNION, a SELECT *, a table dataset, a
   cascade (a parent selection narrows the list, which only the report's
   own query can do), or a traced read that FAILED -- the report's own
   DISTINCT, as before.  The answer says why it could not use 1 or 2
   (``source_note``): never an empty list in place of an error.

``search`` is a case-insensitive "contains" run on the server, so a value
past the list's cap can still be found.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional

from core import column_value_cache as cvc

logger = logging.getLogger(__name__)


def _scope_user(user_ctx: Optional[Dict[str, Any]]) -> Any:
    return user_ctx or {}


async def _may_see_connection(conn: Dict[str, Any], user: Optional[Dict[str, Any]]) -> bool:
    """THE connections' visibility rule (api/connections_api).  Unknown = no,
    and NO reader is no access (the rule itself answers True for a missing
    user -- a share / embed token must never take that branch)."""
    if not user:
        return False
    try:
        from api.connections_api import _connection_visible_to
        return bool(await _connection_visible_to(conn, user))
    except Exception:                                          # noqa: BLE001
        return False


async def _owner_may_see(db, conn: Dict[str, Any], owner: Optional[str]) -> bool:
    """The REPORT OWNER may still see the value table's connection (checked
    when the list is READ, not only when it was saved: a connection unshared
    later stops serving the list).  The owner's scope is resolved server-side
    (core.scheduler._resolve_owner_user_ctx, the background runs' resolver)."""
    if not owner:
        return False
    try:
        from core.scheduler import _resolve_owner_user_ctx
        ctx = await asyncio.to_thread(_resolve_owner_user_ctx, owner) or {}
    except Exception:                                          # noqa: BLE001
        ctx = {}
    return await _may_see_connection(conn, {**ctx, "username": owner,
                                            "role": ctx.get("role") or "viewer"})


async def read(fed, db, *, dataset_id: int, param: Dict[str, Any],
               parent_filters: Optional[List[Dict[str, Any]]], search: Optional[str],
               limit: int, user_ctx: Optional[Dict[str, Any]], temporal: bool,
               source: str, report_owner: Optional[str] = None,
               reader: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """``{"values", "source", "table"?, "cached", "source_note"?}``.  ``limit``
    is asked for as given (a caller asks one more than it shows, to know a
    list was cut).  Raises when the LAST resort fails; the route words it."""
    scope = cvc.scope_for(_scope_user(user_ctx))
    search = (search or "").strip() or None

    if source == "table":
        cid = int(param["lov_source_connection_id"])
        table, column = str(param["lov_source_table"]), str(param["lov_source_column"])
        conn = await asyncio.to_thread(db.get_connection_raw, cid)
        if not conn:
            raise ValueError(f"The connection of this parameter's value table (id {cid}) no longer exists.")
        if not await _owner_may_see(db, conn, report_owner):
            raise PermissionError("The report's owner can no longer see the connection of this "
                                  "parameter's value table, so its choices are not served.")
        values, cached = await _cached_table_read(fed, {cid: conn}, [], cid, table, column,
                                                  search, limit, user_ctx, temporal, scope)
        return {"values": values, "source": "table", "table": f"{table}.{column}", "cached": cached}

    note = None             # a READ that failed: the viewer is told
    trace_note = None       # why the column was not traced: for the author
    try:
        ds = await asyncio.to_thread(db.get_dataset_full, int(dataset_id))
    except Exception as exc:                                  # noqa: BLE001
        # the faster roads are an optimisation: a dataset that cannot be
        # read here falls through to the report's own DISTINCT, which says
        # what is wrong if it cannot read it either
        logger.info("[param-choices] dataset %s not read for tracing: %s", dataset_id, exc)
        ds = None
    col = next((c for c in (ds or {}).get("columns") or [] if c.get("id") == param.get("lov_column_id")), None)
    if ds and col and not parent_filters:
        traced = await asyncio.to_thread(_trace, fed, ds, col)
        if traced.get("table") and not await _may_see_connection(
                next(iter(traced["connections"].values())), reader):
            # SECURITY (2026-10-24 review): the source table's list may hold
            # values the report's own query filters out.  Only a reader who
            # may query that connection directly (the query builder's rule)
            # is served it; anyone else -- a share / embed token, a viewer
            # without the connection -- gets the report's own DISTINCT.
            traced = {"reason": "You cannot read this report's connection directly, so the "
                                "choices come from the report's query."}
        if traced.get("table"):
            try:
                values, cached = await _cached_table_read(
                    fed, traced["connections"], ds.get("source_tables") or [], traced["connection_id"],
                    traced["table"], traced["column"], search, limit, user_ctx, temporal, scope)
                return {"values": values, "source": "table", "table": f"{traced['table']}.{traced['column']}",
                        "traced_from": "query", "cached": cached}
            except Exception as exc:                          # noqa: BLE001
                # Never an empty list in place of an error: the report's own
                # DISTINCT answers, and says why the table could not.
                logger.warning("[param-choices] traced read of %s.%s failed: %s",
                               traced["table"], traced["column"], exc)
                note = (f"The values of {traced['table']}.{traced['column']} could not be read "
                        f"({type(exc).__name__}), so they come from the report's query.")
        else:
            trace_note = traced.get("reason")
    elif parent_filters:
        trace_note = "Narrowed by the parameter it depends on, so the choices come from the report's query."

    qualifier = json.dumps(parent_filters or [], sort_keys=True, default=str)
    key = cvc.key(f"dataset:{dataset_id}:{(ds or {}).get('updated_at') or ''}", "",
                  str(param.get("lov_column_id")), search=search or "", scope=scope, qualifier=qualifier)
    hit = cvc.get(key, limit)
    if hit is not None:
        values, cached = hit, True
    else:
        values = await asyncio.to_thread(
            fed.get_column_distinct_values, dataset_id=int(dataset_id),
            column_id=param["lov_column_id"], parent_filters=parent_filters or None,
            limit=limit, user_ctx=user_ctx, search=search)
        values, cached = list(values or []), False
        cvc.put(key, values, limit)
    out: Dict[str, Any] = {"values": values, "source": "data", "cached": cached}
    if note:
        out["source_note"] = note
    if trace_note:
        out["trace_note"] = trace_note
    return out


def _trace(fed, ds: Dict[str, Any], col: Dict[str, Any]) -> Dict[str, Any]:
    """The dataset column -> one source table column on ONE connection."""
    base_query = (ds.get("base_query") or "").strip()
    if not base_query:
        # 2026-11-01 (rig defect: every dropdown of a TABLE-sourced dataset answered
        # "could not be traced") -- a dataset built from a table has no SQL to
        # trace: its source IS its table.  ONE source table -> that connection,
        # that table, the column's own name; several -> the table the column
        # names itself (``table.column``), else said in plain words.
        tables = [t for t in (ds.get("source_tables") or []) if isinstance(t, dict) and t.get("table")]
        phys = str(col.get("physical_name") or "")
        if len(tables) == 1:
            t = tables[0]
            conn_id = int(t.get("connection_id") or (ds.get("connection_ids") or [0])[0] or 0)
            if not conn_id:
                return {"reason": "The dataset's table names no connection, so its choices come from the report's own data."}
            try:
                connections = fed._resolve_connections(ds)
            except Exception:                                 # noqa: BLE001
                connections = {}
            return {"table": str(t["table"]), "column": phys.split(".")[-1] if "." in phys else phys,
                    "connection_id": conn_id, "connections": connections}
        if len(tables) > 1 and "." in phys:
            tname = phys.rsplit(".", 1)[0].lower()
            t = next((x for x in tables if str(x["table"]).lower().endswith(tname)), None)
            if t:
                try:
                    connections = fed._resolve_connections(ds)
                except Exception:                             # noqa: BLE001
                    connections = {}
                return {"table": str(t["table"]), "column": phys.rsplit(".", 1)[1],
                        "connection_id": int(t.get("connection_id") or 0), "connections": connections}
        if len(tables) > 1:
            return {"reason": "The dataset reads several tables and the column does not say which one it comes "
                              "from, so its choices come from the report's own data."}
        return {"reason": None}         # a local / uploaded dataset: its own DISTINCT IS the table's
    conn_ids = [int(c) for c in (ds.get("connection_ids") or [])]
    if not conn_ids:
        return {"reason": None}         # a local query: its own DISTINCT
    if len(conn_ids) != 1:
        return {"reason": "The report's query reads more than one connection, so its "
                          "choices come from the query itself."}
    try:
        connections = fed._resolve_connections(ds)
    except ValueError:      # the connection is gone; the report's run says so in words
        connections = {}
    conn = connections.get(conn_ids[0])
    if not conn:
        return {"reason": "The report's connection could not be read."}
    from core.reports.column_lineage import trace
    from core.sql_filter_wrapper import dialect_for_connection_type
    dialect = ("duckdb" if fed._get_connection_type(conn) == "s3"
               else dialect_for_connection_type(conn.get("connection_type")) or "")
    src = trace(base_query, str(col.get("physical_name") or ""), dialect)
    if not src.traced:
        return {"reason": src.reason}
    return {"table": src.table, "column": src.column, "connection_id": conn_ids[0],
            "connections": connections}


async def _cached_table_read(fed, connections, source_tables, connection_id, table, column,
                             search, limit, user_ctx, temporal, scope):
    # A DATE list is newest first (a cut list keeps the days people filter
    # on); the query builder's entries are ascending -- so dates keep their
    # own entry, every other column shares the query builder's.
    k = cvc.key(connection_id, table, column, search=search or "", scope=scope,
                qualifier="newest-first" if temporal else "")
    hit = cvc.get(k, limit)
    if hit is not None:
        return hit, True
    values = await asyncio.to_thread(
        fed.get_table_column_values, connections=connections, source_tables=source_tables,
        table_ref=table, column=column, search=search, limit=limit, temporal=temporal,
        user_ctx=user_ctx)
    values = list(values or [])
    cvc.put(k, values, limit)
    return values, False
