"""The scan disclosure a REPORT VIEWER may read (2026-09-27).

"read 126 of 448 files · 2 of 3 manifests · DuckDB · cache miss" -- the
sentence that tells a person whether their filter narrowed the scan and
which engine answered.  Every number in it was already computed:
``iceberg_reader`` stamps ``files_before_prune`` / ``files_after_prune``
(and, since today, ``manifests_total`` / ``manifests_read``) on the
execution's diagnostic entry (``core.query_diagnostic_store``) and persists
the same row to ``query_pruning_history``; the federation engine now stamps
``execution_engine`` beside them.  Until this module the only reader was
``GET /api/admin/queries/diagnose/{execution_id}`` -- admin only, and
carrying the bucket, the table prefix, the snapshot id, the config
snapshot, worker state and bottleneck hints, none of which a report
consumer should see.

THIS IS THE NON-ADMIN PROJECTION.  It takes an execution id and returns
SIX facts and nothing else; the route that serves it runs the REPORT's
view rule first and binds the execution to that report (the same shape as
``dataset-meta``).  Nothing here widens who may read a report, and nothing
here names a bucket, a prefix, a snapshot, a file or a config key.

UNKNOWN IS ``None``, NEVER 0.  The reader's own payload writes
``int(x or 0)``, so a count it did not have arrives as 0 -- and a report
that read no files at all (an empty table) is indistinguishable from one
whose scan was never recorded.  This module treats a ``files_total`` of 0
as NOT RECORDED: a chip that says "read 0 of 0 files" would claim a scan
happened and found nothing, which is the wrong claim in the common case
(a non-Iceberg source, or a pod that did not run the query).  ``recorded``
says whether ANY fact is known, so the chip can say "scan: not recorded"
rather than render an empty label.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: The keys a consumer gets.  Adding one here is the ONLY way to widen the
#: disclosure; the route returns exactly this dict.
#: 2026-10-08 -- ``files_read`` is what the engine READ (the row's
#: ``files_read``: after the LIMIT-only early stop, a mirror or an island
#: swap), falling back to the pruner's ``files_after_prune`` for a row
#: that predates the column; ``read_reason`` says why they differ
#: (``limit_early_stop`` / ``mirror`` / ``island``) and is None when they
#: do not.
DISCLOSURE_KEYS = ("files_read", "files_total", "manifests_read", "manifests_total",
                   "read_reason", "engine", "engine_label")


def _pos_int(v: Any) -> Optional[int]:
    """A count that is known and meaningful, else ``None``."""
    try:
        if v is None or isinstance(v, bool):
            return None
        n = int(v)
    except (TypeError, ValueError):
        return None
    return n if n >= 0 else None


def _engine_of_record(db: Any, execution_id: str) -> Optional[str]:
    """The engine the run wrote in its Diagnostics record: what a run on another
    pod leaves.  The diagnostic entry naming it lives in that pod's memory, and a
    report on a query pod always ran on another pod (2026-11-04)."""
    try:
        from core.reports.diagnostics import get_run_record
        rec = get_run_record(db, execution_id) or {}
        engine = ((rec.get("facts") or {}).get("run") or {}).get("engine")
        return str(engine).strip() or None if engine else None
    except Exception as exc:                                 # noqa: BLE001
        logger.debug("scan disclosure: run record unreadable for %s: %s", execution_id, exc)
        return None


def scan_disclosure(execution_id: Any, db: Any = None) -> Dict[str, Any]:
    """The six facts for ``execution_id``, each ``None`` when not recorded.

    Reads the process-local diagnostic entry first (it has everything the
    reader stamped), then the persisted ``query_pruning_history`` row (what
    survives a pod restart or a query that ran on another pod).  Best-effort
    by construction: a failure to read is ``recorded: False``, logged, never
    raised -- a diagnostic must never be the reason a report fails.
    """
    out: Dict[str, Any] = {k: None for k in DISCLOSURE_KEYS}
    out["execution_id"] = str(execution_id or "")
    out["recorded"] = False
    if not execution_id:
        return out
    entry: Dict[str, Any] = {}
    try:
        from core.query_diagnostic_store import get_pruning
        entry = dict(get_pruning(str(execution_id)) or {})
    except Exception as exc:                                 # noqa: BLE001
        logger.debug("scan disclosure: diagnostic store unreadable for %s: %s",
                     execution_id, exc)
    hist: Dict[str, Any] = {}
    if not entry.get("files_before_prune"):
        try:
            from core.query_diagnostic_store import get_pruning_history
            rows = get_pruning_history(execution_id=str(execution_id), limit=1) or []
            hist = dict(rows[0]) if rows else {}
        except Exception as exc:                             # noqa: BLE001
            logger.debug("scan disclosure: history unreadable for %s: %s",
                         execution_id, exc)

    src = entry if entry.get("files_before_prune") else hist
    files_total = _pos_int(src.get("files_before_prune"))
    files_read = _pos_int(src.get("files_read"))
    read_reason = src.get("read_reason")
    read_reason = str(read_reason) if read_reason else None
    if files_read is None:
        files_read, read_reason = _pos_int(src.get("files_after_prune")), None
    if not files_total:
        # 0 or absent: the reader had no count (see the module docstring)
        files_total, files_read, read_reason = None, None, None
    manifests_total = _pos_int(entry.get("manifests_total"))
    manifests_read = _pos_int(entry.get("manifests_read"))
    if not manifests_total:
        manifests_total, manifests_read = None, None

    engine = entry.get("execution_engine")
    engine = str(engine).strip() if engine else None
    if not engine and db is not None:
        engine = _engine_of_record(db, str(execution_id))
    label = None
    if engine:
        from core.engine_attribution import engine_label
        label = engine_label(engine)

    out.update({
        "files_read": files_read, "files_total": files_total,
        "manifests_read": manifests_read, "manifests_total": manifests_total,
        "read_reason": read_reason,
        "engine": engine, "engine_label": label,
    })
    out["recorded"] = any(out[k] is not None for k in DISCLOSURE_KEYS)
    return out


__all__ = ["DISCLOSURE_KEYS", "scan_disclosure"]
