"""A date written the way a column's format says, for the exports (2026-11-04, the owner: "we should
have date format").  Lockstep with ``frontend/src/utils/formatters.ts::formatDateByPattern``, so a PDF
and an Excel file show what the screen shows.  A date is not a moment: the text is split, never moved
to a time zone.  Anything that is not a date, or a pattern that is not a date pattern, is left as it is.
"""
from __future__ import annotations

import re

_MONTHS = ("January", "February", "March", "April", "May", "June", "July", "August", "September",
           "October", "November", "December")
_DATE_TEXT = re.compile(r"^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?")
_DATE_PATTERN = re.compile(r"YYYY|YY|MMM|DD")
_TOKENS = re.compile(r"YYYY|YY|MMMM|MMM|MM|DD|HH|mm|ss")


def format_date_text(value: str, pattern: str) -> str:
    """``format_date_text("2024-06-28", "DD-MMM-YYYY")`` is ``28-Jun-2024``."""
    if not pattern or not _DATE_PATTERN.search(pattern):
        return value
    m = _DATE_TEXT.match(value.strip())
    if not m or not 1 <= int(m.group(2)) <= 12:
        return value
    y, mo, d, h, mi, s = m.group(1), m.group(2), m.group(3), m.group(4), m.group(5), m.group(6)
    month = _MONTHS[int(mo) - 1]
    parts = {"YYYY": y, "YY": y[-2:], "MMMM": month, "MMM": month[:3], "MM": mo, "DD": d,
             "HH": h or "00", "mm": mi or "00", "ss": s or "00"}
    return _TOKENS.sub(lambda t: parts[t.group(0)], pattern)
