"""Engine-pushed pagination over business-report result artifacts.

Design rule (2026-08-04 strategic redesign): a page request must NEVER mean
"read and fully sort the entire result in pandas on the event loop".  Two
users paging a 5M-row report through the old ``pd.read_parquet`` +
``sort_values`` path froze the single event loop for tens of seconds — the
same failure class that starved ``/health`` and restarted the pod.

Here the sort/limit/offset are pushed into DuckDB (C++, streaming, reads only
the row-groups it needs); only the requested PAGE is ever materialised in
Python.  A pyarrow fallback (C++ sort, no pandas) covers environments where
DuckDB cannot open the file.  All functions are synchronous by design —
API endpoints call them via ``asyncio.to_thread`` so the event loop stays free.

``paginate_result`` is the drop-in single chokepoint that replaced
``api.business_reports_api._paginate_result``'s body; its page contract
({rows: records, columns, total_rows, page, page_size, total_pages}) is
unchanged — existing tests (phase81 / phase100) are the compatibility CONTROL.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


def _quote_ident(name: str) -> str:
    """Safely quote a SQL identifier (double-quote escaping)."""
    return '"' + str(name).replace('"', '""') + '"'


def _sql_path(path: Path) -> str:
    """Quote a filesystem path as a SQL string literal (forward slashes)."""
    return "'" + str(path).replace("\\", "/").replace("'", "''") + "'"


def _duckdb_page(path: Path, offset: int, limit: Optional[int],
                 sort_column: Optional[str], sort_direction: Optional[str],
                 ) -> Tuple[List[Dict[str, Any]], List[str], int]:
    """Engine-pushed page read: DuckDB does count/sort/slice, Python gets ONE page."""
    import duckdb

    suffix = path.suffix.lower()
    if suffix in (".parquet", ".pq"):
        src = f"read_parquet({_sql_path(path)})"
    else:
        src = f"read_csv_auto({_sql_path(path)})"

    con = duckdb.connect()
    try:
        cols = [r[0] for r in con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()]
        total = int(con.execute(f"SELECT COUNT(*) FROM {src}").fetchone()[0])

        order = ""
        if sort_column and sort_column in cols:
            direction = "DESC" if (sort_direction or "asc").lower() == "desc" else "ASC"
            order = f" ORDER BY {_quote_ident(sort_column)} {direction} NULLS LAST"

        sql = f"SELECT * FROM {src}{order}"
        if limit is not None:
            sql += f" LIMIT {int(limit)} OFFSET {int(offset)}"
        elif offset:
            sql += f" OFFSET {int(offset)}"

        page_df = con.execute(sql).fetch_df()   # bounded: page rows only
        return page_df.to_dict(orient="records"), cols, total
    finally:
        con.close()


def _pyarrow_page(path: Path, offset: int, limit: Optional[int],
                  sort_column: Optional[str], sort_direction: Optional[str],
                  ) -> Tuple[List[Dict[str, Any]], List[str], int]:
    """Fallback reader — pyarrow C++ sort + zero-copy slice (parquet), pandas for CSV."""
    if path.suffix.lower() in (".parquet", ".pq"):
        import pyarrow.parquet as pq
        table = pq.read_table(path)
        cols = table.column_names
        total = table.num_rows
        if sort_column and sort_column in cols:
            order = "descending" if (sort_direction or "asc").lower() == "desc" else "ascending"
            table = table.sort_by([(sort_column, order)])
        table = table.slice(offset, limit) if limit is not None else table.slice(offset)
        return table.to_pylist(), cols, total

    import pandas as pd
    df = pd.read_csv(path)
    cols = list(df.columns)
    total = len(df)
    if sort_column and sort_column in df.columns:
        df = df.sort_values(sort_column,
                            ascending=(sort_direction or "asc").lower() != "desc",
                            na_position="last")
    end = None if limit is None else offset + int(limit)
    return df.iloc[offset:end].to_dict(orient="records"), cols, total


def read_artifact_page(path: Path, *, offset: int = 0, limit: Optional[int] = None,
                       sort_column: Optional[str] = None,
                       sort_direction: Optional[str] = None,
                       ) -> Tuple[List[Dict[str, Any]], List[str], int]:
    """Read ONE page of a result artifact: ``(records, columns, total_rows)``.

    Sort/limit/offset are pushed to DuckDB; an unknown ``sort_column`` is
    ignored (validated against the file schema — identifier injection is
    structurally impossible).  Falls back to pyarrow on any DuckDB failure.
    """
    path = Path(path)
    try:
        return _duckdb_page(path, offset, limit, sort_column, sort_direction)
    except Exception as exc:
        logger.warning("read_artifact_page: duckdb path failed for %s (%s) — "
                       "falling back to pyarrow", path, exc)
        return _pyarrow_page(path, offset, limit, sort_column, sort_direction)


# ── Progressive (parts-dataset) reading ──────────────────────────────────────
#
# 2026-09-05.  ``core/scan_partitions`` runs a report's query as N bucket
# queries and lands each bucket as an immutable PART beside the artifact,
# rewriting ``manifest.partial.json`` after every one.  Until now nothing on
# the reports lane could read that: report readers open a FILE, so
# ``federation_engine`` consolidated the parts into one parquet and deleted
# them before returning -- parallel EXTRACTION, but the first row still
# appeared only when the last bucket had finished.
#
# These functions are the reader half.  They add no second manifest reader:
# the manifest is opened through ``api.published_views.bulk.open_dataset``
# (``allow_partial=True``) and the rows come out of
# ``core.feed.parts_manifest.iter_manifest_batches`` -- the same two
# functions the Published API's bulk lane already serves growing datasets
# with.
#
# THE CORRECTNESS CORE IS THE PIN.  A parts manifest GROWS while it is being
# served.  ``PartsManifest.version_at(n)`` names the n-part PREFIX, and parts
# are immutable + append-only, so a version minted against a 3-part manifest
# stays byte-valid against the 30-part one it becomes.  A reader therefore
# pins ``version_at(n)`` on its first page and echoes it on every later page;
# every page is then served from that exact prefix, so page N and page N+1
# cannot skip or repeat a row.  A REBUILD mints a new ``build_id``, which
# changes every prefix version -- so a splice across two builds is a 409,
# and never silent.

PARTS_DIR_SUFFIX = ".parts"

#: Server-minted execution ids only.  ``expected_report_artifact`` joins this
#: onto the shared downloads dir, so anything that could traverse out of it
#: (``..``, a separator, a drive letter) is refused rather than sanitised.
_SAFE_EXEC_ID = re.compile(r"^[A-Za-z0-9_-]{1,128}$")


def parts_dir_for(output_path) -> Path:
    """The parts directory a partitioned build writes BESIDE its artifact.

    ONE spelling of the convention ``core/federation_engine.py`` applies when
    it runs a partitioned scan (``parts_dir = f"{output_path}.parts"``).  The
    engine should import this rather than re-spell it; until it does, a guard
    in ``tests/test_report_progressive_serving_2026_09_05.py`` fails if the
    two ever disagree.
    """
    return Path(str(output_path) + PARTS_DIR_SUFFIX)


#: THE ARTIFACT IS PER ATTEMPT (query pods phase 4, 2026-11-03, third review).
#: A report run retried on another query pod keeps its execution id -- the
#: record, its cache entry, the diagnostics, the cancel handles and the
#: progress all key on it -- but its FILE must not be the one a fenced late
#: writer (the first attempt, told to stop, still flushing) could overwrite:
#: attempt n > 1 writes ``{execution_id}.a{n}.parquet``.  ONE spelling, here:
#: the engine names its file through :func:`artifact_file_name`, the runner
#: declares the attempt with :func:`artifact_attempt_scope` around the engine
#: call (a ContextVar: the worker pool copies the context into its threads),
#: and every reader that derives the path from the id passes the record's
#: ``attempt`` to :func:`expected_report_artifact`.
import contextlib
import contextvars

_ARTIFACT_ATTEMPT: "contextvars.ContextVar[int]" = contextvars.ContextVar(
    "qs_report_artifact_attempt", default=1)


@contextlib.contextmanager
def artifact_attempt_scope(attempt: Optional[int]):
    """Run a block as attempt ``attempt`` of its execution: the engine's
    file name carries ``.a{n}`` for a retry (n > 1); None / 1 = the plain name."""
    token = _ARTIFACT_ATTEMPT.set(max(1, int(attempt or 1)))
    try:
        yield
    finally:
        _ARTIFACT_ATTEMPT.reset(token)


def artifact_suffix(attempt: Optional[int] = None) -> str:
    """``""`` for the first attempt, ``".a{n}"`` for a retry.  ``attempt``
    None = the attempt declared by the enclosing :func:`artifact_attempt_scope`."""
    n = int(attempt) if attempt is not None else int(_ARTIFACT_ATTEMPT.get() or 1)
    return "" if n <= 1 else f".a{n}"


def artifact_file_name(execution_id: str, attempt: Optional[int] = None) -> str:
    """The artifact's file name for ``execution_id`` as THIS attempt writes
    it -- the one place the ``{id}{.a{n}}.parquet`` spelling lives."""
    return f"{execution_id}{artifact_suffix(attempt)}.parquet"


def attempt_probe_cap() -> int:
    """The highest attempt number a retry can carry: the queue's
    ``jobqueue.max_attempts`` (a report job never gets more), floored at 2.
    A reader PROBES ``{id}.a{n}`` for n = cap .. 2 with ``exists()`` -- a
    bounded handful of stats, never a directory listing (fifth review: a
    glob here listed a 50k-file downloads dir four times per grid page,
    with the lane switched off and for ad-hoc results too)."""
    try:
        from core.config import get as _cfg_get
        return max(2, int(_cfg_get("jobqueue", "max_attempts", 2) or 2))
    except Exception:
        return 2


def attempt_artifacts(base: Path, execution_id: str, ext: str = ".parquet") -> List[Tuple[int, Path]]:
    """The RETRY artifacts (n >= 2) of ``execution_id`` present in ``base``,
    highest attempt first.  Bounded probes, no listing."""
    out: List[Tuple[int, Path]] = []
    for n in range(attempt_probe_cap(), 1, -1):
        try:
            cand = base / artifact_file_name(execution_id, n).replace(".parquet", ext)
            if cand.exists():
                out.append((n, cand))
        except (OSError, ValueError):
            continue
    return out


def report_artifact_of_record(db, execution_id: str) -> Optional[Path]:
    """THE RECORD IS THE AUTHORITY (fifth review): the file a report run's
    own record names -- the execute-async record's ``output_path``, else the
    server-side execution row's -- when it exists on this pod.  None when no
    record names an existing file (a reader then falls back to what is on
    disk).  A zombie attempt's row write cannot make a partial retry file
    the answer: the record names ONE path, written through the door or the
    fenced artifact write."""
    if db is None:
        return None
    for getter in ("get_br_async_job", "get_federation_execution"):
        try:
            row = getattr(db, getter)(execution_id)
        except Exception:
            row = None
        if not row:
            continue
        p = row.get("output_path")
        if not p:
            continue
        try:
            fp = Path(str(p))
            if fp.exists():
                return fp
        except (OSError, ValueError):
            continue
    return None


def expected_report_artifact(execution_id: str, attempt: Optional[int] = None) -> Optional[Path]:
    """Where a report execution's artifact WILL be, before it exists.

    A build in flight has written no ``output_path`` anywhere yet -- the DB
    row gets it on completion -- so a reader that wants to serve the parts
    while they are still being produced has to derive the location.  It is
    derivable because both engines name the file
    :func:`artifact_file_name` inside the configured shared downloads dir --
    ``attempt`` is the RECORD's attempt (a retry's parts live beside ITS
    file; a dead first attempt's leftovers are never served as its progress).

    Returns ``None`` for an execution id that is not the server-minted shape,
    rather than joining it onto the downloads dir: the id reaches this
    function from a URL path segment, and ``downloads_dir / '../../x'``
    escapes the directory.  ``None`` means "no derivable artifact", which
    every caller already treats as "nothing progressive to serve".
    """
    if not execution_id or not _SAFE_EXEC_ID.match(str(execution_id)):
        return None
    try:
        from core.config import paths as _paths
        base = str(_paths.downloads_dir)
    except Exception as exc:                                  # pragma: no cover
        logger.warning("expected_report_artifact: downloads dir unresolvable "
                       "(%s) -- no progressive source for %s", exc, execution_id)
        return None
    if not base:
        return None
    return Path(base) / artifact_file_name(execution_id, attempt if attempt is not None else 1)


def resolve_result_source(output_path) -> Tuple[str, Optional[Path]]:
    """Which ONE dataset answers for this result: ``("file"|"parts"|"none", path)``.

    THE SINGLE FILE ALWAYS WINS.  ``consolidate_parts_to_file`` publishes the
    merged parquet with ``os.replace`` and only THEN unlinks the parts, so
    for a moment both exist.  If the parts could still answer during that
    window one execution would be readable as two different datasets at the
    same time -- the exact splice the pin exists to prevent.  Ordering the
    check makes that structurally impossible instead of unlikely.
    """
    if not output_path:
        return "none", None
    p = Path(str(output_path))
    try:
        if p.is_file():
            return "file", p
    except OSError as exc:
        logger.warning("resolve_result_source: cannot stat %s: %s", p, exc)
        return "none", None
    parts = parts_dir_for(p)
    try:
        from core.feed.parts_manifest import is_parts_dir
        if is_parts_dir(parts):
            return "parts", parts
    except Exception as exc:
        logger.warning("resolve_result_source: parts probe failed for %s: %s",
                       parts, exc)
    return "none", None


def is_parts_pin(pin: Any) -> bool:
    """Is this a parts-prefix pin (``parts:<n>:<rows>:<digest>``)?"""
    return isinstance(pin, str) and pin.startswith("parts:")


def _pin_part_count(pin: str) -> int:
    """The part count a pin NAMES -- a hint, never the gate.

    ``manifest.version_at(n) == pin`` is what actually decides whether the
    prefix is the one the pin was minted against; this only says which n to
    put the question to.  -1 when the token is not that shape at all.
    """
    try:
        return int(str(pin).split(":", 3)[1])
    except (IndexError, ValueError):
        return -1


def _prefix_manifest(manifest, n_parts: int):
    """The manifest RESTRICTED to its first ``n_parts`` parts.

    Every downstream read (row arithmetic, batch iteration, totals) then runs
    against the pinned prefix BY CONSTRUCTION -- there is no path that could
    read part n+1, because the object handed to the reader does not contain
    it.  ``version_at`` is unchanged by the truncation: the digest covers
    ``build_id``, ``sql_sha256`` and the first n parts, all carried over
    identically.
    """
    from core.feed.parts_manifest import PartsManifest
    n = max(0, min(int(n_parts), len(manifest.parts)))
    if n == len(manifest.parts):
        return manifest
    kept = list(manifest.parts[:n])
    return PartsManifest(
        parts=kept,
        schema_b64=manifest.schema_b64,
        total_rows=sum(p.rows for p in kept),
        total_bytes=sum(p.bytes for p in kept),
        status=manifest.status,
        sql_sha256=manifest.sql_sha256,
        build_id=manifest.build_id,
        created_at=manifest.created_at,
        completed_at=manifest.completed_at,
        source=dict(manifest.source or {}),
    )


def _stream_parts_page(parts_dir, prefix_manifest, offset: int,
                       limit: Optional[int]) -> List[Dict[str, Any]]:
    """Unsorted page: the offset skips whole parts by manifest arithmetic and
    then whole row groups by footer arithmetic; only the page materialises."""
    from core.feed.parts_manifest import iter_manifest_batches
    if limit is not None and int(limit) <= 0:
        return []
    rows: List[Dict[str, Any]] = []
    batch_rows = 65536 if limit is None else max(1, min(65536, int(limit)))
    for batch in iter_manifest_batches(
            parts_dir, prefix_manifest,
            offset=max(0, int(offset)),
            max_rows=(0 if limit is None else int(limit)),
            batch_rows=batch_rows):
        rows.extend(batch.to_pylist())
    return rows


def _sorted_parts_page(parts_dir, prefix_manifest, offset: int,
                       limit: Optional[int], sort_column: str,
                       sort_direction: Optional[str]) -> List[Dict[str, Any]]:
    """Sorted page over the PINNED PREFIX, engine-pushed into DuckDB.

    The sort covers the rows that exist so far and nothing else -- which is
    why the page carries ``sort_scope="pinned_prefix"`` (``"complete"`` once
    the pinned prefix IS the finished build).  Presenting it as
    the report's final order would be a claim a later part can break;
    refusing the sort outright would take a working control away from a user
    mid-build.  Disclosing its scope is the only honest third option.
    """
    parts_dir = Path(parts_dir)
    paths = [parts_dir / p.name for p in prefix_manifest.parts
             if p.location == "local"]
    if not paths:
        return []
    direction = "DESC" if (sort_direction or "asc").lower() == "desc" else "ASC"
    try:
        import duckdb
        src = ("read_parquet([" + ", ".join(_sql_path(p) for p in paths)
               + "], union_by_name=true)")
        con = duckdb.connect()
        try:
            sql = (f"SELECT * FROM {src} "
                   f"ORDER BY {_quote_ident(sort_column)} {direction} NULLS LAST")
            if limit is not None:
                sql += f" LIMIT {int(limit)} OFFSET {int(offset)}"
            elif offset:
                sql += f" OFFSET {int(offset)}"
            return con.execute(sql).fetch_df().to_dict(orient="records")
        finally:
            con.close()
    except Exception as exc:
        logger.warning("[report-progressive] duckdb sort over %d pinned part(s) "
                       "failed (%s) -- falling back to pyarrow", len(paths), exc)
    import pyarrow as pa
    from core.feed.parts_manifest import iter_manifest_batches
    batches = list(iter_manifest_batches(parts_dir, prefix_manifest))
    if not batches:
        return []
    table = pa.Table.from_batches(batches)
    table = table.sort_by([(sort_column,
                            "descending" if direction == "DESC" else "ascending")])
    table = table.slice(offset, limit) if limit is not None else table.slice(offset)
    return table.to_pylist()


def stale_pin_page(pin: str, reason: str, page: int,
                   page_size: int, *, consolidated: bool) -> Dict[str, Any]:
    """The page a reader gets when its pin no longer names a servable prefix.

    NO ROWS.  The flag is what the API turns into a 409, but a caller that
    ignores the flag must still be unable to splice two snapshots together,
    so the refusal is in the DATA as well as in the disclosure.  ``reason``
    separates the two outcomes that lead to opposite actions:
    ``consolidated`` (the build finished and the merged file is now the
    dataset -- re-request without the pin) and ``rebuilt`` (a different build
    replaced it -- those rows are gone).
    """
    return {
        "rows": [], "columns": [], "total_rows": 0,
        "page": page, "page_size": page_size, "total_pages": 0,
        "progressive": False,
        "pin_stale": True,
        "pin_stale_reason": reason,
        "requested_dataset_version": pin,
        "consolidated": bool(consolidated),
    }


def unpinned_page_refusal(manifest, n_ready: int, page: int,
                          page_size: int, columns: List[str]) -> Dict[str, Any]:
    """The page a reader gets for a DEEP page it did not pin, mid-build.

    THE PIN IS NOT AN OPT-IN FEATURE, IT IS THE CONTRACT.  ``read_parts_page``
    refuses to auto-EXTEND a pin because extending is unsafe over a growing
    build; leaving the identical widening open to a caller that merely omits
    the parameter would make the unsafe path the DEFAULT one.  Measured on a
    real growing build (8 pages of 5, sorted): 17 rows duplicated, 32 skipped
    and 24 served from a prefix the session had never seen -- behind eight
    HTTP 200s.  The round-two audit measured the same class on its own
    fixture (23 duplicated, 31 skipped).

    So: page 1 unpinned is always servable and MINTS the pin (returned as
    ``dataset_version``); any later page without it is refused here, naming
    the remedy -- ``restart_from_page: 1`` with the ``dataset_version`` this
    refusal carries.  No rows -- a caller that ignores the flag must still be
    unable to splice two prefixes -- and never a ``sort_scope``, because
    nothing was pinned and nothing was sorted.

    A finished build never reaches this: it is not growing, so an unpinned
    deep page cannot disagree with a pinned one.
    """
    return {
        "rows": [], "columns": list(columns),
        "total_rows": int(manifest.total_rows),
        "page": page, "page_size": page_size,
        "progressive": True,
        "consolidated": False,
        # The prefix that exists RIGHT NOW.  Paired with ``restart_from_page``
        # it is the remedy: begin the session again at page 1 with this pin.
        # It is deliberately NOT "the pin for the page you just asked for" --
        # using it for page N alone, after page N-1 came from a smaller
        # prefix, would be the very splice this refusal exists to stop.
        "dataset_version": manifest.version_at(n_ready),
        "restart_from_page": 1,
        "parts_ready": int(n_ready),
        "parts_pinned": 0,
        "building": True,
        "more_expected": True,
        "build_complete": False,
        "total_mode": "at_least",
        "unpinned_page_refused": True,
        "unpinned_page_reason": "growing_build",
        # Refreshing is not the remedy here (the dataset did not move) --
        # re-requesting this page WITH dataset_version is.
        "refresh_available": False,
    }


def read_parts_page(parts_dir, *, offset: int = 0, limit: Optional[int] = None,
                    sort_column: Optional[str] = None,
                    sort_direction: Optional[str] = None,
                    pin: Optional[str] = None) -> Dict[str, Any]:
    """ONE page of a parts dataset that may still be building.

    ``pin`` -- the ``dataset_version`` from an earlier page of the same paging
    session.  Absent, the prefix is pinned HERE (at the part count the
    manifest holds right now) and returned so the caller can echo it.
    Present and no longer nameable, the result is a ``pin_stale`` page with
    no rows (see :func:`stale_pin_page`).  Absent on a page PAST THE FIRST
    while the build is still growing, the page is refused with the remedy
    named (see :func:`unpinned_page_refusal`) -- omitting
    the pin must not be a quieter way to get the widening this module
    already refuses to do by extension.

    The returned dict discloses, always:

      ``dataset_version``   the pin to echo on the next page
      ``total_rows``        rows in the PINNED PREFIX, not in the build
      ``total_mode``        ``exact`` only when the build has finished AND the
                            pin covers all of it; ``at_least`` otherwise
      ``building``          the manifest is still partial: more rows are coming
      ``more_expected``     the same fact named for the consumer -- "no rows on
                            this page" does NOT mean the dataset is finished
      ``parts_ready`` / ``parts_pinned``
      ``refresh_available`` + ``refresh_reason`` -- re-request WITHOUT the pin
                            to pick up ``more_rows``, or because the build is
                            ``build_complete``
    """
    from fastapi import HTTPException

    from api.published_views import bulk as _bulk

    try:
        pf = _bulk.open_dataset(parts_dir, allow_partial=True)
    except Exception as exc:
        logger.warning("[report-progressive] parts dataset %s could not be "
                       "opened: %s", parts_dir, exc)
        raise
    try:
        ref = _bulk.describe_dataset(parts_dir, cache_key="", pf=pf)
        manifest = ref.parts_manifest
        if manifest is None:                                  # pragma: no cover
            raise RuntimeError(f"{parts_dir} opened without a parts manifest")
        n_all = len(manifest.parts)
        n_pinned = n_all
        building = bool(manifest.status != "complete")
        columns = list(manifest.columns()) if manifest.schema_b64 else []
        # THE UNSAFE PATH MUST NOT BE THE DEFAULT ONE.  A deep page with no
        # pin, over a build that is still growing, is served from a different
        # prefix than the page before it -- which duplicates and skips rows
        # behind a 200.  Page 1 mints the pin; a later page has to carry it.
        # See :func:`unpinned_page_refusal`.
        if (not pin) and int(offset) > 0 and building:
            return unpinned_page_refusal(manifest, n_all, 1,
                                         int(limit or 0), columns)
        if pin:
            try:
                # THE shared append-only-prefix rule, not a second copy of it.
                _bulk.verify_dataset_version(pin, ref, source="cursor")
            except HTTPException:
                return stale_pin_page(pin, "rebuilt", 1, int(limit or 0),
                                      consolidated=False)
            n_pinned = _pin_part_count(pin)
            if not (0 <= n_pinned <= n_all) or manifest.version_at(n_pinned) != pin:
                return stale_pin_page(pin, "rebuilt", 1, int(limit or 0),
                                      consolidated=False)

        pm = _prefix_manifest(manifest, n_pinned)
        total_rows = int(pm.total_rows)
        sorted_page = bool(sort_column) and sort_column in columns

        if not pm.parts or not manifest.schema_b64:
            # A build that has written its manifest but not yet its first
            # part.  There are no rows AND no schema to present them in, so
            # the readers below would raise ("manifest carries no schema").
            # An empty page here is not a claim that the report is empty —
            # ``building``/``more_expected`` below say the opposite, which is
            # the whole reason this state has to be servable rather than a
            # 500 a poller would read as a failed report.
            records: List[Dict[str, Any]] = []
        elif sorted_page:
            records = _sorted_parts_page(parts_dir, pm, offset, limit,
                                         sort_column, sort_direction)
        else:
            records = _stream_parts_page(parts_dir, pm, offset, limit)

        complete_prefix = (not building) and n_pinned == n_all
        out: Dict[str, Any] = {
            "rows": records,
            "columns": columns,
            "total_rows": total_rows,
            "progressive": True,
            "consolidated": False,
            "dataset_version": manifest.version_at(n_pinned),
            "parts_ready": n_all,
            "parts_pinned": n_pinned,
            "building": building,
            "more_expected": building,
            "build_complete": not building,
            "total_mode": "exact" if complete_prefix else "at_least",
        }
        # SORT_SCOPE IS A CLAIM ABOUT WHAT WAS SORTED, so it is emitted only
        # when a sort actually ran over parts that were actually pinned.  It
        # used to be stamped whenever a sort column was named -- including on
        # a prefix of ZERO parts, where nothing was pinned and nothing was
        # sorted.  An affirmatively false disclosure is worse than none: a
        # reader trusts it to decide whether the order it is showing can
        # still change.  ``complete`` and ``pinned_prefix`` are different
        # facts and lead to different UI, so they are named differently.
        if sorted_page and pm.parts:
            out["sort_scope"] = "complete" if complete_prefix else "pinned_prefix"
        if n_all > n_pinned:
            out["refresh_available"] = True
            out["refresh_reason"] = "more_rows"
        elif not building:
            out["refresh_available"] = True
            out["refresh_reason"] = "build_complete"
        else:
            out["refresh_available"] = False
        return out
    finally:
        try:
            _bulk.close_dataset(pf)
        except Exception as exc:                              # pragma: no cover
            logger.debug("[report-progressive] close_dataset failed: %s", exc)


def parts_progress(output_path) -> Optional[Dict[str, Any]]:
    """What a STATUS poll can honestly say about an in-flight build.

    ``None`` when there is no parts dataset beside ``output_path`` (nothing
    progressive to disclose, so nothing is disclosed -- the status payload
    stays exactly as it is today).  Otherwise the counts a client needs to
    decide it can start paging: how many parts are durable, how many rows
    they hold, and whether more are coming.

    Reads the manifest ONLY.  It never opens a part, so polling this every
    second costs one small JSON read.
    """
    kind, path = resolve_result_source(output_path)
    if kind != "parts":
        return None
    try:
        from core.feed.parts_manifest import load_manifest
        manifest, src = load_manifest(path, allow_partial=True)
    except Exception as exc:
        logger.warning("[report-progressive] progress unreadable for %s: %s",
                       path, exc)
        return None
    building = bool(manifest.status != "complete")
    return {
        "partial_results_available": len(manifest.parts) > 0,
        "parts_ready": len(manifest.parts),
        "rows_ready": int(manifest.total_rows),
        "building": building,
        "build_complete": not building,
        "total_mode": "at_least" if building else "exact",
        "dataset_version": manifest.version(),
    }


def paginate_records(raw_rows: List[Dict[str, Any]], page: int, effective_page_size: int,
                     sort_column: Optional[str], sort_direction: Optional[str],
                     ) -> Tuple[List[Dict[str, Any]], int]:
    """Page over already-materialised (small, in-memory) rows.

    Sort semantics preserved from the legacy paginator (None sorts last on
    ascending; reversed wholesale on descending).
    """
    rows = raw_rows or []
    if sort_column:
        ascending = (sort_direction or "asc") == "asc"
        rows = sorted(rows,
                      key=lambda r: (r.get(sort_column) is None, r.get(sort_column)),
                      reverse=not ascending)
    total_rows = len(rows)
    offset = (page - 1) * effective_page_size
    return rows[offset: offset + effective_page_size], total_rows


def paginate_result(result: Optional[dict], page: int, page_size: int,
                    sort_column: Optional[str], sort_direction: Optional[str],
                    cfg, *, dataset_version: Optional[str] = None) -> dict:
    """Server-side pagination over any normalised/legacy result dict.

    Drop-in for the old ``_paginate_result`` (same page contract), but the
    artifact path is engine-pushed: only the requested page is materialised.
    Synchronous — call via ``asyncio.to_thread`` from async handlers.

    ``dataset_version`` (2026-09-05) is the progressive-serving pin: the
    ``dataset_version`` a previous page of the SAME paging session returned.
    It only means anything when the result is still a parts dataset; a report
    that produced one parquet the ordinary way is read exactly as it was
    before, and its page dict is unchanged key-for-key.
    """
    from core.json_utils import sanitize_for_json

    if not result:
        return {"rows": [], "total_rows": 0, "page": page,
                "page_size": page_size, "total_pages": 0}

    effective_page_size = page_size if page_size > 0 else cfg.business_reports.page_size
    effective_page_size = min(effective_page_size, cfg.business_reports.max_page_size)

    output_path = result.get("output_path", "")
    raw_columns = result.get("columns", [])
    columns = [c["name"] if isinstance(c, dict) and "name" in c else str(c)
               for c in raw_columns] if raw_columns else []

    artifact = Path(output_path) if output_path else None
    _artifact_gone = False
    # ONE answer to "which dataset is this result": the merged file whenever
    # it exists, the parts dir only while it does not.  See
    # :func:`resolve_result_source` for why the order is the whole guarantee.
    _source_kind, _source_path = resolve_result_source(output_path)
    if _source_kind == "file":
        if is_parts_pin(dataset_version):
            # The build this pin belongs to has been CONSOLIDATED: the parts
            # are gone and the merged file is now the dataset.  Serving the
            # file under a parts pin would answer a question asked about
            # snapshot A with snapshot B's rows — silently.  Refuse, and NAME
            # the transition so the caller drops the pin and refreshes, which
            # is exactly the step this feature was asked to end on.
            return stale_pin_page(dataset_version, "consolidated", page,
                                  effective_page_size, consolidated=True)
        offset = (page - 1) * effective_page_size
        records, columns, total_rows = read_artifact_page(
            _source_path, offset=offset, limit=effective_page_size,
            sort_column=sort_column, sort_direction=sort_direction)
        rows = sanitize_for_json(records)
    elif _source_kind == "parts":
        # The merged file does not exist yet — serve the parts that do.
        offset = (page - 1) * effective_page_size
        prog = read_parts_page(_source_path, offset=offset,
                               limit=effective_page_size,
                               sort_column=sort_column,
                               sort_direction=sort_direction,
                               pin=dataset_version)
        prog["page"] = page
        prog["page_size"] = effective_page_size
        if prog.get("pin_stale"):
            return prog
        prog["rows"] = sanitize_for_json(prog.get("rows") or [])
        _prefix_rows = int(prog.get("total_rows") or 0)
        prog["total_pages"] = (
            max(1, (_prefix_rows + effective_page_size - 1) // effective_page_size)
            if effective_page_size > 0 else 1)
        # Same additive convention as the file path: present only when the
        # source result carries them, never fabricated.
        if isinstance(result, dict):
            if result.get("row_limit") is not None:
                prog["row_limit"] = result.get("row_limit")
            if "truncated" in result:
                prog["truncated"] = result.get("truncated")
        return prog
    else:
        # 2026-08-25 — DISTINGUISH TWO CASES THIS BRANCH USED TO CONFLATE.
        #
        # Legitimate: ``output_path`` is empty because the result is small and
        # already materialised in the dict. Handled below, unchanged.
        #
        # NOT legitimate: ``output_path`` is SET and the file is GONE. The
        # result cache is a 50-entry LRU, so eviction is routine; the caller
        # then rebuilds ``result`` as {output_path, total_rows} with no data
        # key. Add a pod restart or an unshared downloads volume and the file
        # is missing for a result the DB still records as N rows. Falling
        # through produced rows:[] / total_rows:0 behind HTTP 200, which the
        # viewer renders as "ran successfully but returned no rows" — a
        # positive assertion of success over a result we know we lost, blaming
        # the user's parameters. Logged nowhere.
        _artifact_expected_but_missing = bool(output_path) and (
            artifact is None or not artifact.exists())

        # Small results already materialised in the result dict.
        # PV legacy uses "data"; the unified envelope emits both "data" and
        # positional "rows" — prefer records ("data") when present.
        raw_rows = result.get("data") or []
        if not raw_rows:
            candidate = result.get("rows") or []
            # Envelope "rows" are positional lists — rebuild records if needed.
            if candidate and isinstance(candidate[0], (list, tuple)) and columns:
                raw_rows = [dict(zip(columns, r)) for r in candidate]
            else:
                raw_rows = candidate
        page_rows, total_rows = paginate_records(
            raw_rows, page, effective_page_size, sort_column, sort_direction)
        rows = sanitize_for_json(page_rows)
        # Only an error when there is no fallback either. An artifact PLUS
        # inline rows is not a failure — use the rows and stay quiet.
        if _artifact_expected_but_missing and not raw_rows:
            logger.warning(
                "[report-page] result artifact is MISSING for %s — reporting "
                "the page as unavailable rather than as zero rows. Causes: the "
                "50-entry result cache evicted the entry, the pod restarted, or "
                "the downloads volume is not shared across replicas.",
                output_path)
            _artifact_gone = True

    total_pages = (max(1, (total_rows + effective_page_size - 1) // effective_page_size)
                   if effective_page_size > 0 else 1)
    out = {
        "rows": rows,
        "columns": columns,
        "total_rows": total_rows,
        "page": page,
        "page_size": effective_page_size,
        "total_pages": total_pages,
    }
    # 2026-08-05 audit (never silently degrade): pass the execution's
    # row_limit / truncated verdict through to page consumers when the source
    # result carries them (stamped by _with_contract_keys / ReportEnvelope).
    # Additive keys — absent when unknown, never fabricated: the total_rows
    # above counts the ARTIFACT's rows, which is the post-cap count, so the
    # cap must travel with the page for the UI to disclose it.
    if isinstance(result, dict):
        if result.get("row_limit") is not None:
            out["row_limit"] = result.get("row_limit")
        if "truncated" in result:
            out["truncated"] = result.get("truncated")
    # Additive, following the same convention: absent means "fine", never
    # fabricated. The API layer turns this into a 410 so the user gets
    # something they can act on instead of a false success.
    if _artifact_gone:
        out["artifact_missing"] = True
    return out
