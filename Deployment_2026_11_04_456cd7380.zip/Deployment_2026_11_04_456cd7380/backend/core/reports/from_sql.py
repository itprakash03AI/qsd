"""Set reports up FROM SQL, every type, through the routes the screen uses (2026-11-04;
the owner: "i need sql config for all type of reports so i can teach users").

The same model as feeds (``core/feed/template_requests.py``).  On PostgreSQL:

``qs_report_apply(p_spec jsonb, p_dry_run boolean, p_requested_by text) -> integer``
    Queues one report and returns the request id.
``qs_report_apply_status`` (view)
    One row per request: state (pending / running / done / failed), what was done, the
    report's id, and the reason in plain words when it was refused.

The scheduler's ``report_requests`` job (the scheduler-lock holder) applies each request
through ``api/business_reports_api``, ``api/datasets_api``, ``api/sql_files_api`` and
``api/report_templates_api``, so every rule of the screen holds (names, canvas and theme
checks, cross-source refusal, version history).  Nothing writes ``business_reports``
around them.  Whoever may EXECUTE the function on QueryStudio's own database already
controls every report, so a request runs with administrator rights, stamped with who
asked.  Grant EXECUTE to the release / DBA role only.

A SPEC uses NAMES, never ids, so it can be taught, kept in a file and run in any
environment.  The ``type`` says the kind of report:

  table     ``dataset`` + ``columns``, optional ``filters`` / ``order_by``
  pivot     + ``pivot``: ``rows``, ``columns``, ``values`` [{column, aggregation}]
  canvas    + ``tiles``: [{kind, title, dimensions, measures, series, layout, ...}]
  template  + ``template`` (a design id) and ``slots`` {slot: [column, ...]}
  sql       ``sql_file`` (a saved SQL file's name), or ``sql`` + ``connection``

Any of the first four takes ``dataset`` (an existing name) or ``dataset_sql``
{name, connection, sql, subject}, which creates it and detects its columns.  All take
``description``, ``row_limit``, ``theme``, ``parameters``, ``drill_hierarchy`` (not sql) and
``published``.  Applying a
name that exists UPDATES that report; a name two active reports share is refused.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

FUNCTION_NAME = "qs_report_apply"
STATUS_VIEW = "qs_report_apply_status"
MAX_PER_TICK = 5
STALE_RUNNING_SECONDS = 1800
TYPES = ("table", "pivot", "canvas", "template", "sql")

_FUNCTION_SQL = f"""
CREATE OR REPLACE FUNCTION {FUNCTION_NAME}(
    p_spec         jsonb,
    p_dry_run      boolean DEFAULT false,
    p_requested_by text    DEFAULT NULL
) RETURNS integer LANGUAGE sql AS $fn$
    INSERT INTO report_apply_requests
        (report_name, requested_by, spec, dry_run, state, requested_at)
    VALUES (COALESCE(p_spec ->> 'name', ''), COALESCE(p_requested_by, session_user),
            p_spec::json, COALESCE(p_dry_run, false), 'pending', (now() AT TIME ZONE 'utc'))
    RETURNING id
$fn$;
COMMENT ON FUNCTION {FUNCTION_NAME}(jsonb, boolean, text) IS
  'QueryStudio: queue one report create/update from a spec of names; returns the request id. '
  'See view {STATUS_VIEW}. Applied by the scheduler through the screen''s own rules.';
"""

_VIEW_SQL = f"""
CREATE OR REPLACE VIEW {STATUS_VIEW} AS
SELECT r.id AS request_id, r.report_name, r.state, r.dry_run, r.action, r.report_id, r.slug,
       r.error, r.requested_by, r.requested_at, r.started_at, r.finished_at, r.detail
FROM report_apply_requests r;
"""

_ensured: Dict[int, bool] = {}


class SpecRefused(ValueError):
    """The spec cannot be applied; the message is for the person who wrote it."""


def ensure_sql_objects(db: Any) -> bool:
    """Create / refresh the function and the view (PostgreSQL only).  Once per process."""
    key = id(db)
    if _ensured.get(key):
        return True
    engine = getattr(db, "engine", None)
    if engine is None or engine.dialect.name != "postgresql":
        return False
    from sqlalchemy import text
    from core.db.models import ReportApplyRequest
    ReportApplyRequest.__table__.create(bind=engine, checkfirst=True)
    with engine.begin() as conn:
        conn.execute(text(_FUNCTION_SQL))
        conn.execute(text(_VIEW_SQL))
    _ensured[key] = True
    logger.info("[report_requests] %s() and %s are in place", FUNCTION_NAME, STATUS_VIEW)
    return True


def submit(db: Any, spec: Dict[str, Any], *, dry_run: bool = False, requested_by: str = "") -> int:
    """What the SQL function does, for a caller holding the manager."""
    from core.db.models import ReportApplyRequest as R
    with db.get_session() as s:
        row = R(report_name=str((spec or {}).get("name") or ""), requested_by=requested_by, spec=spec,
                dry_run=bool(dry_run), state="pending")
        s.add(row)
        s.flush()
        return int(row.id)


def get(db: Any, request_id: int) -> Optional[Dict[str, Any]]:
    from core.db.models import ReportApplyRequest as R
    with db.get_session(read_only=True) as s:
        r = s.query(R).filter(R.id == int(request_id)).first()
        if r is None:
            return None
        return {c.name: getattr(r, c.name) for c in R.__table__.columns}


def pending_count(db: Any) -> int:
    from core.db.models import ReportApplyRequest as R
    with db.get_session(read_only=True) as s:
        return int(s.query(R).filter(R.state == "pending").count())


def _requeue_stale(db: Any) -> int:
    from core.db.models import ReportApplyRequest as R
    cutoff = datetime.now(timezone.utc) - timedelta(seconds=STALE_RUNNING_SECONDS)
    with db.get_session() as s:
        return int(s.query(R).filter(R.state == "running", R.started_at < cutoff)
                   .update({"state": "pending", "started_at": None}, synchronize_session=False) or 0)


def _claim(db: Any) -> Optional[Dict[str, Any]]:
    """The oldest pending request, moved to ``running`` by a compare-and-swap."""
    from core.db.models import ReportApplyRequest as R
    with db.get_session() as s:
        cand = s.query(R.id).filter(R.state == "pending").order_by(R.id).first()
        if cand is None:
            return None
        n = (s.query(R).filter(R.id == cand[0], R.state == "pending")
             .update({"state": "running", "started_at": datetime.now(timezone.utc)}, synchronize_session=False))
        if not n:
            return None
    return get(db, cand[0])


def _finish(db: Any, request_id: int, **fields) -> None:
    from core.db.models import ReportApplyRequest as R
    fields["finished_at"] = datetime.now(timezone.utc)
    with db.get_session() as s:
        s.query(R).filter(R.id == int(request_id)).update(fields, synchronize_session=False)


# ── names to ids ─────────────────────────────────────────────────────────

def _one_by_name(rows: List[dict], name: str, what: str, key: str = "name") -> dict:
    want = str(name or "").strip().lower()
    hits = [r for r in rows if str(r.get(key) or "").strip().lower() == want]
    if not hits:
        raise SpecRefused(f"There is no {what} named '{name}'.")
    if len(hits) > 1:
        raise SpecRefused(f"{len(hits)} {what}s are named '{name}'. Rename one so the name means one thing.")
    return hits[0]


class _Columns:
    """A dataset's columns by what a person calls them: friendly or physical name."""

    def __init__(self, columns: List[dict]):
        self.by: Dict[str, List[int]] = {}
        for c in columns or []:
            names = {str(c.get(k) or "").strip().lower() for k in ("friendly_name", "physical_name")}
            for n in names - {""}:
                self.by.setdefault(n, []).append(int(c["id"]))
        self.names = sorted({str(c.get("friendly_name") or c.get("physical_name")) for c in columns or []})

    def id(self, name: Any) -> int:
        hits = self.by.get(str(name or "").strip().lower(), [])
        if len(hits) == 1:
            return hits[0]
        if hits:
            raise SpecRefused(f"Two columns of this dataset are called '{name}'.")
        raise SpecRefused(f"This dataset has no column called '{name}'. It has: {', '.join(self.names[:40])}.")

    def ids(self, names: Any) -> List[int]:
        return [self.id(n) for n in (names or [])]


def _with_column_ids(items: Any, cols: _Columns) -> List[dict]:
    """[{column: name, ...}] to [{column_id: id, ...}], for filters, sorts and measures."""
    out = []
    for it in items or []:
        d = dict(it)
        if "column" not in d:
            raise SpecRefused(f"Each entry needs a 'column' name: {it}.")
        d["column_id"] = cols.id(d.pop("column"))
        out.append(d)
    return out


def _pivot_config(spec: dict, cols: _Columns) -> dict:
    p = spec.get("pivot")
    if not isinstance(p, dict) or not p.get("values"):
        raise SpecRefused("A pivot needs 'pivot' with 'rows', 'columns' and 'values'.")
    return {"row_field_ids": cols.ids(p.get("rows")), "col_field_ids": cols.ids(p.get("columns")),
            "value_fields": _with_column_ids(p.get("values"), cols),
            "show_grand_total": bool(p.get("show_grand_total", True))}


def _canvas(spec: dict, cols: _Columns) -> dict:
    tiles = spec.get("tiles")
    if not isinstance(tiles, list) or not tiles:
        raise SpecRefused("A canvas needs 'tiles': a list of at least one.")
    out = []
    for i, raw in enumerate(tiles, 1):
        if not isinstance(raw, dict) or not raw.get("kind"):
            raise SpecRefused(f"Tile {i} needs a 'kind', for example number, bar or table.")
        t = {"id": f"{raw['kind']}_{i}", "title": "", "series": None, "sort": None, "top_n": None,
             "layout": {"x": 0, "y": (i - 1) * 6, "w": 12, "h": 6}, **raw}
        t["dimensions"] = cols.ids(raw.get("dimensions"))
        t["measures"] = _with_column_ids(raw.get("measures"), cols)
        if raw.get("series") is not None:
            t["series"] = cols.id(raw["series"])
        out.append(t)
    return {"version": 1, "tiles": out}


def _canvas_column_ids(canvas: dict) -> List[int]:
    seen: List[int] = []
    for t in canvas["tiles"]:
        ids = list(t["dimensions"]) + [m["column_id"] for m in t["measures"]]
        if t.get("series") is not None:
            ids.append(t["series"])
        seen.extend(i for i in ids if i not in seen)
    return seen


# ── the steps, each through the route the screen calls ───────────────────

async def _dataset(db: Any, spec: dict, user: dict, dry_run: bool, detail: dict) -> Optional[dict]:
    import api.datasets_api as dsa
    rows = await asyncio.to_thread(db.list_datasets)
    new = spec.get("dataset_sql")
    if new:
        if not isinstance(new, dict) or not new.get("name") or not new.get("sql") or not new.get("connection"):
            raise SpecRefused("'dataset_sql' needs 'name', 'connection' and 'sql'.")
        wanted = [r for r in rows if str(r.get("name")).strip().lower() == str(new["name"]).strip().lower()]
        if not wanted:
            conn = _one_by_name(await asyncio.to_thread(db.list_connections), new["connection"], "connection")
            if dry_run:
                detail["dataset"] = f"would create '{new['name']}'"
                return None
            made = await dsa.create_dataset(dsa.DatasetCreate(
                name=new["name"], subject=str(new.get("subject") or "reports from SQL"),
                connection_ids=[int(conn["id"])], base_query=new["sql"]), user)
            await dsa.auto_detect_columns(int(made["id"]), user)
            detail["dataset"] = f"created '{new['name']}'"
            return await asyncio.to_thread(db.get_dataset_full, int(made["id"]))
        detail["dataset"] = f"reused '{new['name']}'"
        return await asyncio.to_thread(db.get_dataset_full, int(_one_by_name(rows, new["name"], "dataset")["id"]))
    if not spec.get("dataset"):
        raise SpecRefused("Say which data this report reads: 'dataset' (a name) or 'dataset_sql'.")
    return await asyncio.to_thread(db.get_dataset_full, int(_one_by_name(rows, spec["dataset"], "dataset")["id"]))


def _refuse_s3_for_own_sql(conn: Optional[dict]) -> None:
    """An own-SQL report runs on the source's own engine, and S3 files have none: saved, it
    would fail on its first run ("Unsupported connection type 's3'", found on the rig)."""
    if str((conn or {}).get("connection_type") or "").lower() == "s3":
        raise SpecRefused(f"Connection '{conn.get('name')}' is S3 files, which a report on your own SQL cannot "
                          "read. Use type table with 'dataset_sql' instead: it takes the same query.")


async def _sql_file_id(db: Any, spec: dict, user: dict, dry_run: bool, detail: dict) -> Optional[int]:
    import api.sql_files_api as sfa
    if spec.get("sql_file"):
        files = await asyncio.to_thread(lambda: db.list_sql_files(limit=5000))
        found = _one_by_name(files, spec["sql_file"], "SQL file")
        if found.get("connection_id"):
            _refuse_s3_for_own_sql(await asyncio.to_thread(db.get_connection, int(found["connection_id"])))
        return int(found["id"])
    if not spec.get("sql") or not spec.get("connection"):
        raise SpecRefused("A sql report needs 'sql_file' (a saved file's name), or 'sql' and 'connection'.")
    conn = _one_by_name(await asyncio.to_thread(db.list_connections), spec["connection"], "connection")
    _refuse_s3_for_own_sql(conn)
    if dry_run:
        detail["sql_file"] = f"would save '{spec['name']}'"
        return None
    made = await sfa.create_sql_file(sfa.SqlFileCreate(
        name=spec["name"], sql=spec["sql"], connection_id=int(conn["id"]), is_shared=True), user)
    detail["sql_file"] = f"saved '{spec['name']}'"
    return int(made["id"])


async def _template_body(spec: dict, ds: dict, cols: _Columns, user: dict) -> dict:
    import api.report_templates_api as rta
    slots = {k: cols.ids(v if isinstance(v, list) else [v]) for k, v in (spec.get("slots") or {}).items()}
    if not spec.get("template"):
        raise SpecRefused("A template report needs 'template', the design's id.")
    built = await rta.build(str(spec["template"]), rta.BuildBody(
        dataset_id=int(ds["id"]), slots=slots, name=spec["name"], theme=spec.get("theme")), user)
    return built


def _body_for(spec: dict, ds: dict, cols: _Columns) -> Dict[str, Any]:
    """The report body of table / pivot / canvas, as the builder would send it."""
    kind = spec["type"]
    picked = cols.ids(spec.get("columns"))
    layout: Dict[str, Any] = {"report_type": "pivot" if kind == "pivot" else "table"}
    if kind == "pivot":
        layout["pivot_config"] = _pivot_config(spec, cols)
        pc = layout["pivot_config"]
        picked += [i for i in pc["row_field_ids"] + pc["col_field_ids"] + [v["column_id"] for v in pc["value_fields"]]
                   if i not in picked]
    if kind == "canvas":
        layout["canvas"] = _canvas(spec, cols)
        picked += [i for i in _canvas_column_ids(layout["canvas"]) if i not in picked]
    if not picked:
        raise SpecRefused("Say which columns this report shows: 'columns'.")
    return {"name": spec["name"], "dataset_id": int(ds["id"]), "data_source_type": "dataset", "column_ids": picked,
            "filter_specs": _with_column_ids(spec.get("filters"), cols),
            "order_by": _with_column_ids(spec.get("order_by"), cols), "layout_config": layout}


async def _drill_hierarchy_id(db: Any, spec: dict, ds: dict, cols: _Columns, user: dict, dry_run: bool) -> Optional[int]:
    """``drill_hierarchy`` {name, levels: [column, ...]}: the dataset's hierarchy of that name,
    created or brought up to date through the routes."""
    import api.datasets_api as dsa
    spec_h = spec.get("drill_hierarchy")
    if not spec_h:
        return None
    if not isinstance(spec_h, dict) or not spec_h.get("name") or len(spec_h.get("levels") or []) < 2:
        raise SpecRefused("'drill_hierarchy' needs a 'name' and at least two 'levels'.")
    levels = [{"column_id": cols.id(n), "label": str(n)} for n in spec_h["levels"]]
    rows = await asyncio.to_thread(db.list_drill_hierarchies, int(ds["id"]))
    same = [h for h in rows if str(h.get("name")).strip().lower() == str(spec_h["name"]).strip().lower()]
    if dry_run:
        return None
    if same:
        await dsa.update_hierarchy(int(same[0]["id"]), dsa.HierarchyUpdate(levels=levels), user)
        return int(same[0]["id"])
    made = await dsa.create_hierarchy(int(ds["id"]), dsa.HierarchyCreate(name=spec_h["name"], levels=levels), user)
    return int(made["id"])


def _parameter_items(spec_params: Any, cols: Optional[_Columns]) -> List[dict]:
    out = []
    for p in spec_params or []:
        d = dict(p)
        if "column" in d:
            name = d.pop("column")
            if cols is None:
                raise SpecRefused("A sql report's parameter has no dataset column; use the query's own :name.")
            d["lov_column_id"] = cols.id(name)
        out.append(d)
    return out


async def _save(db: Any, spec: dict, body: Dict[str, Any], parameters: List[dict], user: dict,
                dry_run: bool, detail: dict) -> Dict[str, Any]:
    import api.business_reports_api as bra
    for k in ("description", "row_limit"):
        if spec.get(k) is not None:
            body[k] = spec[k]
    if spec.get("theme") and body.get("layout_config") is not None:
        body["layout_config"].setdefault("theme", {"name": spec["theme"]})
    rows = await asyncio.to_thread(db.list_business_reports)
    same = [r for r in rows if str(r.get("name")).strip().lower() == str(spec["name"]).strip().lower()]
    if len(same) > 1:
        raise SpecRefused(f"{len(same)} reports are named '{spec['name']}'. Rename one so the name means one report.")
    if dry_run:
        detail["column_ids"] = body.get("column_ids")
        detail["parameters"] = [p.get("name") for p in parameters]
        return {"action": "would update" if same else "would create",
                "report_id": int(same[0]["id"]) if same else None, "slug": same[0].get("slug") if same else None}
    if same:
        rid = int(same[0]["id"])
        fields = {k: v for k, v in body.items() if k != "name"}
        await bra.update_report(rid, bra.ReportUpdate(**fields), user)
        action = "updated"
    else:
        made = await bra.create_report(bra.ReportCreate(**body), user)
        rid = int(made["id"])
        action = "created"
    if spec.get("parameters") is not None or parameters:
        await bra.batch_save_parameters(rid, bra.BatchParameterRequest(parameters=parameters), user)
    if spec.get("published") is not None:
        await bra.toggle_publish(rid, bra.PublishRequest(action="publish" if spec["published"] else "unpublish"), user)
    saved = await asyncio.to_thread(db.get_business_report, rid)
    return {"action": action, "report_id": rid, "slug": (saved or {}).get("slug")}


def _bind_routes(db: Any) -> None:
    """These run on the scheduler pod, which never mounts these two routers, so main.py never
    gave them their database: a design failed "Database not ready" and an own-SQL report
    "Service not initialized" (found on the rig, 2026-11-04).  The other routes read the manager."""
    import api.report_templates_api as rta
    import api.sql_files_api as sfa
    if rta._db_manager is None:
        rta._db_manager = db
    if sfa._db_manager is None:
        sfa._db_manager = db


async def apply_spec(db: Any, spec: Any, *, dry_run: bool, requested_by: str) -> Dict[str, Any]:
    """One spec through the routes; raises ``SpecRefused`` or the route's HTTPException."""
    _bind_routes(db)
    if not isinstance(spec, dict):
        raise SpecRefused("The spec must be a JSON object.")
    if not str(spec.get("name") or "").strip():
        raise SpecRefused("The spec needs a 'name'.")
    kind = spec.get("type") or "table"
    if kind not in TYPES:
        raise SpecRefused(f"'{kind}' is not a report type. Use one of: {', '.join(TYPES)}.")
    spec = {**spec, "type": kind}
    user = {"username": (requested_by or "database")[:100], "role": "admin", "auth_source": "sql_function"}
    detail: Dict[str, Any] = {"type": kind}

    if kind == "sql":
        fid = await _sql_file_id(db, spec, user, dry_run, detail)
        body = {"name": spec["name"], "data_source_type": "raw_sql", "dataset_id": 0, "raw_sql_file_id": fid,
                "layout_config": {"report_type": "table"}}
        out = await _save(db, spec, body, _parameter_items(spec.get("parameters"), None), user, dry_run, detail)
        return {**out, "detail": detail}

    ds = await _dataset(db, spec, user, dry_run, detail)
    if ds is None:                     # a dry run of a dataset that does not exist yet
        return {"action": "would create", "report_id": None, "slug": None,
                "detail": {**detail, "note": "Column names are checked once the dataset exists."}}
    cols = _Columns(ds.get("columns") or [])
    if kind == "template":
        built = await _template_body(spec, ds, cols, user)
        body = dict(built["report"])
        params = list(built.get("parameters") or []) + _parameter_items(spec.get("parameters"), cols)
        detail["notes"] = built.get("notes")
    else:
        body = _body_for(spec, ds, cols)
        params = _parameter_items(spec.get("parameters"), cols)
    drill = await _drill_hierarchy_id(db, spec, ds, cols, user, dry_run)
    if drill is not None:
        body["drill_hierarchy_id"] = drill
    out = await _save(db, spec, body, params, user, dry_run, detail)
    return {**out, "detail": detail}


def _words(exc: Exception) -> str:
    """The refusal in words; a route's 422 detail may be a dict holding the message."""
    d = getattr(exc, "detail", None) or str(exc) or type(exc).__name__
    if isinstance(d, dict):
        d = d.get("message") or d.get("problems") or d
    return str(d)[:4000]


def process_one(db: Any) -> Optional[Dict[str, Any]]:
    req = _claim(db)
    if req is None:
        return None
    try:
        res = asyncio.run(apply_spec(db, req.get("spec"), dry_run=bool(req.get("dry_run")),
                                     requested_by=req.get("requested_by") or ""))
        _finish(db, req["id"], state="done", action=res.get("action"), report_id=res.get("report_id"),
                slug=res.get("slug"), detail=res.get("detail"), error=None)
        logger.info("[report_requests] request %s (%s): %s", req["id"], req.get("report_name"), res.get("action"))
    except Exception as exc:  # noqa: BLE001 -- every failure is RECORDED on the row
        words = _words(exc)
        _finish(db, req["id"], state="failed", error=words)
        logger.warning("[report_requests] request %s (%s) failed: %s", req["id"], req.get("report_name"), words)
    return get(db, req["id"])


def tick(db: Any) -> Dict[str, Any]:
    """One pass: make sure the SQL objects exist, apply up to MAX_PER_TICK."""
    out: Dict[str, Any] = {"sql_objects": False, "applied": 0, "failed": 0}
    try:
        out["sql_objects"] = ensure_sql_objects(db)
    except Exception as exc:  # noqa: BLE001 -- the queue still drains; said
        out["sql_objects_error"] = str(exc)[:300]
        logger.warning("[report_requests] could not create %s(): %s", FUNCTION_NAME, exc)
    out["requeued"] = _requeue_stale(db)
    for _ in range(MAX_PER_TICK):
        row = process_one(db)
        if row is None:
            break
        out["applied" if row["state"] == "done" else "failed"] += 1
    return out
