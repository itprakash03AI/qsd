"""
Query Studio Scheduler — APScheduler 3.x wrapper.

Runs a BackgroundScheduler backed by SQLAlchemyJobStore (same SQLite DB).
Jobs are submitted to a dedicated thread pool sized by
``scheduler.job_pool_size`` (default 20), isolated from the interactive
query_executor so scheduled jobs never starve interactive users.
(2026-08-09, metadata-scale audit finding 4/15: this docstring used to claim
20 threads while the executor hardcoded 4 — the config key now actually
drives the executor, so config, heartbeat and reality agree.)

Job dispatch pattern:
  parquet saved_query  → OptimizedParquetEngine.execute_query → .parquet
  sql_query            → cross_source_engine.execute_single_source_query
  report               → REFUSED (FB-60: the legacy parametric entity is gone)
  business_report      → Phase 111: FederationEngine or raw_sql adapter

All jobs:
  - record start / completion / failure in the Schedule DB record
  - register the output CSV in DownloadFile
  - broadcast a WebSocket notification
"""

from __future__ import annotations

import atexit
import logging
import os
import socket
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Optional
from core.download_retention import (
    download_expires_at as _download_expires_at)
from core.sql_filter_wrapper import dialect_for_connection_type

logger = logging.getLogger(__name__)

# Phase 83C: scheduler lock worker_id for this process
_scheduler_worker_id: Optional[str] = None
#: Which election this process's APScheduler belongs to (2026-11-02): row 1 =
#: the scheduler tier (the schedules and the watchers), row 2 = the job-worker
#: tier (the executing loops).  ``database.try_acquire_scheduler_lock(lock_id=)``.
SCHEDULER_LOCK_ID = 1
JOB_WORKER_LOCK_ID = 2
_lock_id: int = SCHEDULER_LOCK_ID


def holds_scheduler_lock() -> bool:
    """This process holds the SCHEDULER tier's lock (row 1) -- not merely "runs an
    APScheduler".  2026-11-02: the job-worker holds row 2 through the same
    ``_scheduler_worker_id``, and the health page called it the scheduler-lock holder."""
    return _scheduler_worker_id is not None and _lock_id == SCHEDULER_LOCK_ID


def holds_job_worker_lock() -> bool:
    """This process holds the job-worker tier's lock (row 2)."""
    return _scheduler_worker_id is not None and _lock_id == JOB_WORKER_LOCK_ID


def _this_process_runs_apscheduler() -> bool:
    """The per-tick "am I the single runner?" answer for APScheduler jobs.

    APScheduler is started ONLY in the process holding the Phase 83C
    scheduler lock (``init_scheduler``; a non-holder retries and never
    starts), so that lock IS the single-runner guarantee: a job ticking here
    is already the only one.  2026-09-27 -- five jobs (failover agent, reclaim
    sweeper, row-count baseline refresh, orphan sweep, ETL-dependency poller)
    compared the SchedulerLease holder (``host#pid``) with this lock's id
    (``host:pid``).  The two never match, so whenever any lease row existed
    every one of them returned silently each tick while APScheduler logged
    "executed successfully".  Found on the Docker rig: WAIT feed runs were
    never released."""
    return _scheduler_worker_id is not None


# ── "APScheduler started IN THIS PROCESS" hooks (2026-09-28) ─────────────────
#
# Found live on the Docker rig, the ROLLING-DEPLOY case: the scheduler
# container was recreated while the old container's ``scheduler_lock``
# heartbeat was still fresh (a Kubernetes rolling update starts the new pod
# before the old one dies).  ``init_scheduler`` returned early ("another
# instance holds the lock") and ``_start_lock_retry`` won the lock minutes
# later -- but everything that registers AGAINST APScheduler had already run
# once, at boot, against ``scheduler=None``: every retention sweep, the
# close-out digest, the DQ loop, the SLA scanner, the brain daemons.  Nothing
# re-ran them, so the new pod held the lock and ran none of them.
#
# The hook list is the ONE place both entry points hand that work to: a
# callable queued here runs the moment THIS process starts APScheduler,
# whether that is the boot-time ``init_scheduler`` call or the retry thread's
# later one -- ``_fire_started_hooks`` is called from the end of
# ``init_scheduler`` and nowhere else.  A hook queued after the scheduler is
# already running is called immediately, so a caller never has to ask which
# side of the start it is on.
_started_hooks: list = []
_started_hooks_lock = threading.Lock()


def _run_started_hook(fn: Callable[[], Any]) -> None:
    """One hook, guarded on its own: a failing hook must neither stop the
    scheduler from starting nor strand the hooks behind it."""
    try:
        fn()
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[scheduler] started-hook %s failed (non-fatal): %s",
                       getattr(fn, "__name__", fn), exc, exc_info=True)


def on_apscheduler_started(fn: Callable[[], Any]) -> bool:
    """Run ``fn`` once APScheduler is running in THIS process.

    Returns True when it ran right away (the scheduler is already up) and
    False when it was queued for the start that ``init_scheduler`` will
    perform later -- at boot, or on the lock retry after the previous
    holder's heartbeat goes stale.  Each queued hook runs exactly once.
    """
    with _started_hooks_lock:
        if _scheduler is None:
            _started_hooks.append(fn)
            return False
    _run_started_hook(fn)
    return True


def _fire_started_hooks() -> int:
    """Run and clear every queued hook; returns how many ran.  Called by
    ``init_scheduler`` after the scheduler is started and its own jobs are
    registered, on every path that starts one (initial and retry)."""
    with _started_hooks_lock:
        pending = list(_started_hooks)
        _started_hooks.clear()
    for fn in pending:
        _run_started_hook(fn)
    if pending:
        logger.info("[scheduler] APScheduler is running in this process -- "
                    "ran %d started-hook(s) (late daemon registrations, "
                    "deferred singletons)", len(pending))
    return len(pending)


# ── Module-level references injected at startup ───────────────────────────────
#: Whether :func:`_release_lock_on_exit` is registered with atexit (once per
#: process; see ``init_scheduler``).
_release_on_exit_registered = False


def _release_lock_on_exit():
    """atexit: release the scheduler lock this process holds, through the
    manager ``init_scheduler`` was last given.  No log line -- atexit runs
    after pytest closes its captured streams (see ``init_scheduler``)."""
    if not _scheduler_worker_id or _db() is None:
        return
    try:
        _db().release_scheduler_lock(_scheduler_worker_id, lock_id=_lock_id)
    except Exception:
        pass


def _lock_retry_interval_seconds() -> float:
    """How often to re-attempt the scheduler lock after losing the race.

    Must be SHORTER than the 60s staleness threshold so a crashed holder's
    lock is picked up promptly once it expires, and long enough not to spin.
    Never raises.
    """
    try:
        from core.config import get as _cfg_get
        v = float(_cfg_get("scheduler", "lock_retry_seconds", 20) or 20)
        return v if v > 0 else 20.0
    except Exception as exc:
        logger.debug("scheduler lock-retry interval read failed: %s", exc)
        return 20.0


def _start_lock_retry(db_manager, db_url: str, *, start_paused: bool) -> None:
    """Keep re-attempting ``init_scheduler`` until this pod wins the lock.

    Idempotent: at most ONE retry thread exists per process, so repeated
    failed initialisations cannot fan out into a thread storm.  The thread
    exits as soon as a scheduler is running -- either because we acquired
    the lock, or because another code path started one.

    Daemon thread: it must never hold up interpreter shutdown.
    """
    global _lock_retry_thread

    def _retry_loop():
        interval = _lock_retry_interval_seconds()
        while True:
            time.sleep(interval)
            if _scheduler is not None:
                logger.debug("scheduler lock-retry: scheduler is running, "
                             "retry thread exiting")
                return
            try:
                init_scheduler(db_manager, db_url, start_paused=start_paused)
            except Exception as exc:
                # A failed attempt must not kill the retry loop -- the whole
                # point is to survive until the holder's lock goes stale.
                logger.warning("scheduler lock-retry attempt failed: %s", exc)
                continue
            if _scheduler is not None:
                logger.info("APScheduler started on retry — the previous "
                            "lock holder's heartbeat went stale")
                return

    with _lock_retry_lock:
        if _lock_retry_thread is not None and _lock_retry_thread.is_alive():
            return
        _lock_retry_thread = threading.Thread(
            target=_retry_loop, name="scheduler-lock-retry", daemon=True)
        _lock_retry_thread.start()
    logger.info("Scheduler lock contended — retrying every %.0fs until the "
                "holder releases or its heartbeat goes stale",
                _lock_retry_interval_seconds())


def pv_cache_lru_eviction():
    """LRU-evict the Published-Views dataset cache.

    F9/F10 (2026-08-08).  Three defects, all in this one job:

    * MANIFESTS WERE INVISIBLE.  The glob was ``v*.parquet`` only, so
      the ``<parquet>.manifest.json`` truth sidecars were neither
      counted nor deleted.  Evicting a dataset left its sidecar behind
      forever: unbounded small-file growth on NFS, and a stale manifest
      sitting exactly where a future entry with the same cache key
      would land -- feeding the silent-truncation window (F3).
    * ONE DATASET COULD EXCEED THE WHOLE BUDGET.  Bulk datasets are
      unbounded by design.  Billed against the paged 2 GB budget, a
      single 20 GB export made the loop delete every OTHER view's
      entry, still fail to get under budget, and do it again 4 h later
      -- every /data consumer permanently on MISS because of one bulk
      pull.  Bulk now has its own budget and its own bookkeeping.
    * ``.tmp`` LEAKED.  Interrupted copies were counted toward the
      total forever but never removed, so a crashed multi-GB publish
      permanently shrank the usable cache.

    The paged class keeps its exact previous eviction policy (oldest
    first, no age floor) so ~1000 interactive users see no behaviour
    change; only the accounting and the sidecar handling differ.
    """
    try:
        import time as _t
        from pathlib import Path as _Path
        from core.config import published_views as _pv_cfg_ev
        from api.published_views.envelope import manifest_sidecar_path
        from api.published_views.helpers import pv_cache_is_bulk

        cache_dir = _Path(_pv_cfg_ev.cache_dir)
        if not cache_dir.exists():
            return
        now = _t.time()

        def _size_of(p):
            try:
                return p.stat().st_size
            except OSError:
                return 0

        # ── Orphaned sidecars: a manifest with no dataset is stale
        # truth waiting to be mis-bound.  Always remove, budget or not.
        orphans = 0
        for sc in cache_dir.glob("v*.parquet.manifest.json"):
            ds = _Path(str(sc)[: -len(".manifest.json")])
            if not ds.exists():
                try:
                    sc.unlink(missing_ok=True)
                    orphans += 1
                except OSError:
                    pass
        if orphans:
            logger.info("[pv-cache-lru] removed %d orphaned manifest sidecar(s)", orphans)

        # ── Abandoned .tmp copies.  A live atomic write is seconds-to-
        # minutes old; anything older lost its writer.  Still counted
        # toward the total while young so a burst of publishes cannot
        # overshoot the budget unnoticed.
        _TMP_STALE_S = 6 * 3600
        tmp_bytes = {"paged": 0, "bulk": 0}
        stale_tmp = 0
        for tp in cache_dir.glob("v*.tmp"):
            try:
                st = tp.stat()
            except OSError:
                continue
            if now - st.st_mtime > _TMP_STALE_S:
                try:
                    tp.unlink(missing_ok=True)
                    stale_tmp += 1
                    continue
                except OSError:
                    pass
            tmp_bytes["bulk" if pv_cache_is_bulk(tp) else "paged"] += st.st_size
        if stale_tmp:
            logger.warning(
                "[pv-cache-lru] removed %d abandoned .tmp cache write(s) older than %dh "
                "— an interrupted publish leaks its staging copy",
                stale_tmp, _TMP_STALE_S // 3600,
            )

        # ── Collect datasets, billing each sidecar to its dataset ──
        entries = {"paged": [], "bulk": []}
        for pf in cache_dir.glob("v*.parquet"):
            try:
                st = pf.stat()
            except OSError:
                continue
            sc = manifest_sidecar_path(pf)
            total = st.st_size + _size_of(sc)
            cls = "bulk" if pv_cache_is_bulk(pf) else "paged"
            entries[cls].append((pf, sc, total, st.st_mtime))

        def _evict(cls: str, max_mb: int, min_retain_s: float):
            max_bytes = int(max_mb) * 1024 * 1024
            if max_bytes <= 0:
                return                      # 0 = this class is not size-managed
            rows = entries[cls]
            total_bytes = sum(r[2] for r in rows) + tmp_bytes[cls]
            if total_bytes <= max_bytes:
                return

            # Oldest first (LRU).  Within the bulk class, entries still
            # young enough to be feeding an in-flight stream or an
            # outstanding resume cursor are never taken: breaking a
            # running 10M-row export to reclaim space trades a bounded
            # disk problem for a failed pull.
            rows = sorted(rows, key=lambda r: r[3])
            evicted = 0
            protected = 0
            for path, sc, size, mtime in rows:
                if total_bytes <= max_bytes:
                    break
                if min_retain_s > 0 and (now - mtime) < min_retain_s:
                    protected += 1
                    continue
                try:
                    path.unlink(missing_ok=True)
                    # The sidecar goes WITH its dataset — never left to
                    # stamp stale truth onto a future entry.
                    sc.unlink(missing_ok=True)
                    total_bytes -= size
                    evicted += 1
                except OSError:
                    pass
            if evicted:
                logger.info(
                    "[pv-cache-lru] %s: evicted %d entr(ies), now %.1f MB (max %d MB)",
                    cls, evicted, total_bytes / 1024 / 1024, max_mb,
                )
            if total_bytes > max_bytes:
                # Say so LOUDLY rather than deleting the rest of the
                # cache every 4 h in a loop that can never succeed.
                biggest = max(rows, key=lambda r: r[2], default=None)
                logger.error(
                    "[pv-cache-lru] %s cache is STILL over budget after eviction: "
                    "%.1f MB vs %d MB (%d entr(ies) protected as too recent). "
                    "Largest single entry: %s at %.1f MB. A single dataset larger "
                    "than the budget cannot be cached — raise published_views.%s, "
                    "or narrow the view's filters.",
                    cls, total_bytes / 1024 / 1024, max_mb, protected,
                    (biggest[0].name if biggest else "?"),
                    ((biggest[2] / 1024 / 1024) if biggest else 0.0),
                    "bulk_cache_size_mb" if cls == "bulk" else "max_cache_size_mb",
                )

        _evict("paged", _pv_cfg_ev.max_cache_size_mb, 0.0)
        _evict("bulk", _pv_cfg_ev.bulk_cache_size_mb,
               float(_pv_cfg_ev.bulk_cache_min_retain_minutes) * 60.0)
    except Exception as exc:
        logger.warning("PV cache LRU eviction error: %s", exc)


class _DaemonJobstoreProxy:
    """Routes daemon registrations into the in-memory ``daemon`` jobstore.

    2026-08-20 — every ``register_*_daemon(scheduler, db)`` module adds
    closure-shaped tick jobs, and the persistent SQLAlchemy jobstore
    refuses closures/unpicklable args (see the jobstores comment in
    init_scheduler): those registrations were silently dropped for months,
    each behind its own try/except warning.  Rather than editing ~10
    daemon modules, this proxy is handed to them in place of the raw
    scheduler; ``add_job`` defaults ``jobstore="daemon"`` (an explicit
    caller choice still wins, and a scheduler without the alias falls back
    to its default store), everything else passes through.
    """

    __slots__ = ("_sched",)

    def __init__(self, sched):
        self._sched = sched

    def add_job(self, *args, **kwargs):
        if "jobstore" not in kwargs:
            try:
                return self._sched.add_job(*args, jobstore="daemon", **kwargs)
            except KeyError:
                # No 'daemon' alias on this scheduler (plain/legacy setup)
                # — register in its default store, today's behaviour.
                pass
        return self._sched.add_job(*args, **kwargs)

    def __getattr__(self, item):
        return getattr(self._sched, item)


def get_daemon_scheduler():
    """The handle DAEMON registrations must use (None before init).

    Wraps the singleton so daemon jobs land in the memory-backed
    ``daemon`` jobstore instead of being rejected by the persistent one.
    """
    if _scheduler is None:
        return None
    return _DaemonJobstoreProxy(_scheduler)


def run_feed_stale_reclaim_sweep(db, threshold_seconds: int) -> dict:
    """One pass of every feed orphan reaper (FR-RUN-08, 2026-09-02).

    HEARTBEAT-keyed, never age alone.  The sweeper used to call
    ``reclaim_stale_running_feed_runs`` — keyed on ``started_at`` only —
    so ANY feed run older than the threshold (1 h default) was reset to
    ``pending`` WHILE STILL RUNNING; a second worker claimed it and the
    same feed executed and DELIVERED twice, with its connection claims
    reaped from under it at the same time.  A 160M-row extract or a SAP
    month-end balance feed is exactly such a run.

    ``reap_orphaned_feed_runs`` reaps only runs whose pod stopped
    BEATING (the queue worker now beats at ~threshold/6 — see
    ``FeedRunQueueWorker._heartbeat_loop``); a healthy 4-hour run
    survives.  NULL-heartbeat decision, deliberate: a row whose
    ``heartbeat_at`` is NULL (claimed before this deploy, or its pod
    died before the first beat) FALLS BACK to the ``started_at`` age
    rule — identical to the old sweeper for legacy rows, so the first
    sweep after deploy reaps nothing yesterday's would not have, and a
    genuinely dead pre-deploy pod is still recovered.

    Returns ``{"claims": n, "runs": n, "executions": n, "file_runs": n}``.
    The run-row reap PROPAGATES on failure (callers log); the other
    three are each best-effort so one failing table cannot shield the
    others from being swept.
    """
    out = {"claims": 0, "runs": 0, "executions": 0, "file_runs": 0}
    # Connection slots a dead pod is holding (Foundation C).  A pod that
    # died holding four slots starves the source until someone notices.
    try:
        from core.feed import claims as _claims_reap
        out["claims"] = int(_claims_reap.reap_stale_claims(
            db, threshold_seconds) or 0)
    except Exception as _cl_exc:
        logger.warning(
            "[stale_reclaim] connection-slot reclaim failed (%s) — slots "
            "stay held until the next sweep", _cl_exc)
    out["runs"] = int(db.reap_orphaned_feed_runs(threshold_seconds) or 0)
    # Twin reapers, same heartbeat keying.  An execution row left active
    # by a dead pod blocks its feed via the one-active partial index; a
    # child file-run left 'running' blocks its partition's re-run.
    try:
        out["executions"] = int(
            db.reap_orphaned_feed_executions(threshold_seconds) or 0)
    except Exception as _ex_exc:
        logger.warning(
            "[stale_reclaim] execution-row reap failed (%s) — retried "
            "next sweep", _ex_exc)
    try:
        out["file_runs"] = int(
            db.reap_orphaned_feed_file_runs(threshold_seconds) or 0)
    except Exception as _fr_exc:
        logger.warning(
            "[stale_reclaim] child file-run reap failed (%s) — retried "
            "next sweep", _fr_exc)
    return out


def run_sod_generator_once() -> dict:
    """ONE pass of the Feed SOD task generator for today -- the function the
    APScheduler job ``__feed_sod_generator__`` runs at ``feed_generation.
    sod_cron`` and 120 s after boot, and the one ``POST /api/admin/
    background-jobs/feed_sod_generator/run-now`` runs on the owner.

    2026-10-11: it RETURNS the generator's result (``SodResult.to_dict()``)
    instead of only logging it, so the job-contract listener can ledger
    every scheduled fire by value: "did SOD run by itself this morning,
    and what did it create" is an admin-route answer, not a log grep.  A
    failure is returned as ``{"status": "error", "error": ...}`` (ledgered
    as an error tick), never raised into APScheduler.
    """
    try:
        if not _db():
            return {"status": "skipped",
                    "reason": "no db manager is bound in this process"}
        from core.feed.sod_generator import SodTaskGenerator
        gen = SodTaskGenerator(_db())
        result = gen.run_for_date().to_dict()
        logger.info("[sod] %s", result)
        return result
    except Exception as exc:
        logger.warning("[sod] generator failed: %s", exc)
        return {"status": "error", "error": f"{type(exc).__name__}: {exc}"[:300]}


def init_scheduler(db_manager, db_url: str, *, start_paused: bool = False):
    """
    Create and start the APScheduler BackgroundScheduler.

    Call ``set_broadcast_fn()`` first to wire up notification delivery.
    Called once during startup (from FastAPI or from scheduler_worker).

    Phase 83C: Only one instance runs at a time — uses DB lock.

    When ``start_paused=True`` the scheduler is initialized and triggers
    are registered but no jobs fire until POST /api/admin/scheduler/resume
    flips it.  Driven by the ``scheduler.autostart`` config flag (see
    main.py).
    """
    global _db_manager, _scheduler, _scheduler_worker_id

    _db_manager = db_manager

    # 2026-10-27 -- EVERY process frees what its pod's previous process left
    # running, lease or no lease (core/feed/queue_worker.py::
    # schedule_previous_process_reap): found live, a killed hybrid API's run
    # stayed "running" for the reaper's hour because the lock had moved to
    # the scheduler container, whose worker reaps only its own pod's claims.
    try:
        from core.feed.queue_worker import schedule_previous_process_reap
        schedule_previous_process_reap(db_manager)
    except Exception as _reap_exc:                      # noqa: BLE001 -- said, never fatal at start-up
        logger.warning("previous-process reap not scheduled (%s) -- the heartbeat "
                       "reaper frees a dead process's runs later", _reap_exc)
    # Phase 83C: Try to acquire scheduler lock
    # 2026-09-28 -- try under a LOCAL id and publish it only once the lock
    # is HELD.  ``_this_process_runs_apscheduler()`` reads this global, so
    # writing it before the attempt opened a window on every 20 s retry in
    # which a NON-holder answered "I am the single runner" -- found live: the
    # deferral watcher polled inside that window and started every singleton
    # (Netcool sender, SLA watcher, Iceberg sync...) beside the real holder.
    _candidate_worker_id = f"{socket.gethostname()}:{os.getpid()}"
    if not db_manager.try_acquire_scheduler_lock(_candidate_worker_id):
        logger.warning(
            "APScheduler not starting — another instance holds the lock (this worker: %s)",
            _candidate_worker_id,
        )
        _scheduler_worker_id = None
        # 2026-08-03 — RETRY, do not give up permanently.
        #
        # The lock is considered stale only after 60s without a heartbeat
        # (database.try_acquire_scheduler_lock) and the holder heartbeats
        # every 30s.  A pod that CRASHES (OOM, failed liveness probe — both
        # have happened here) leaves no atexit release, so its own heartbeat
        # is still fresh when Kubernetes restarts it seconds later.  The
        # restarted pod then saw a held lock, returned here, and never tried
        # again -- while separately holding the BF-410.4 scheduler LEASE,
        # which stops any sibling from taking over.  Net effect at
        # replicas=1: every scheduled feed, report, subscription and sweeper
        # silently stops until the next restart, with no error anywhere.
        #
        # Retrying is the conservative half of the fix: it can never steal a
        # lock from a LIVE holder (the staleness rule is unchanged), it only
        # stops us abandoning the role forever after a transient collision.
        _start_lock_retry(db_manager, db_url, start_paused=start_paused)
        return

    _scheduler_worker_id = _candidate_worker_id
    logger.info("APScheduler lock acquired by %s", _scheduler_worker_id)

    # Register atexit handler to release the lock on shutdown.
    # No log line — atexit runs after pytest closes its captured
    # stdout/stderr; calling logger.info() routes through stdlib
    # logging whose handler error path prints to a closed stream
    # and produces "I/O operation on closed file" stack traces even
    # when wrapped in try/except (because the logging framework
    # catches handler exceptions itself).  Symmetric "lock released"
    # info is not worth that noise — the DB release below is the
    # only thing that has to succeed.
    #
    # 2026-10-04 -- registered ONCE per process.  It was a closure over
    # this call's db_manager, registered on every init_scheduler -- every
    # app lifespan in a test worker and every lock-retry win -- and atexit
    # held each closure, and with it a DatabaseManager whose pool kept its
    # SQLite connections open, for the life of the process (a per-lifespan
    # memory leak the CI replica's workers accumulated).  The module-level
    # function releases with the CURRENT manager, which is the one holding
    # the lock.
    global _release_on_exit_registered
    if not _release_on_exit_registered:
        atexit.register(_release_lock_on_exit)
        _release_on_exit_registered = True

    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
    from apscheduler.executors.pool import ThreadPoolExecutor as APSThreadPool
    from sqlalchemy import create_engine
    from sqlalchemy import event as _sa_event

    # Build a dedicated SQLAlchemy engine for the APS jobstore.
    # SQLite: WAL mode + 30-second busy_timeout so APS never fails with SQLITE_BUSY.
    # PostgreSQL: standard pool — no SQLite-specific pragmas.
    _is_sqlite = db_url.startswith("sqlite")
    _aps_engine_kwargs = {}
    if _is_sqlite:
        _aps_engine_kwargs["connect_args"] = {"check_same_thread": False}
    _aps_engine = create_engine(db_url, **_aps_engine_kwargs)

    if _is_sqlite:
        @_sa_event.listens_for(_aps_engine, "connect")
        def _set_aps_pragmas(dbapi_conn, _conn_record):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA busy_timeout=30000")
            cursor.close()

    jobstore  = SQLAlchemyJobStore(engine=_aps_engine)
    # Limit worker threads so scheduled jobs never starve interactive queries.
    #
    # Defence-in-depth "job singleton" backstop: swap the plain APScheduler
    # ThreadPoolExecutor for one that wraps EVERY dispatched tick in a
    # cross-pod advisory-lock guard (core/job_singleton.py).  This is the
    # SINGLE chokepoint — every registered maintenance/cleanup/sync/mirror/
    # prefetch/reconciliation job (and every user schedule + jobs added later
    # onto this same scheduler via the "default" executor) inherits the guard
    # with no per-daemon edits.  On SQLite / single-pod it is a pure no-op
    # (always acquires → identical behaviour); on PostgreSQL it ensures
    # at-most-one runner per tick even when leader election is disabled.
    # Fail-safe: a lock error runs the job anyway (leader lease still primary).
    try:
        from core.job_singleton import SingletonThreadPoolExecutor

        def _sg_db_getter():
            return _db()

        def _sg_enabled_getter():
            try:
                from core.config import scheduler as _sg_cfg
                return bool(getattr(_sg_cfg, "job_singleton_lock_enabled", True))
            except Exception:
                return True

        executor = SingletonThreadPoolExecutor(
            max_workers=_executor_max_workers(),
            db_manager_getter=_sg_db_getter,
            enabled_getter=_sg_enabled_getter,
        )
        logger.info(
            "Scheduler executor: job-singleton backstop ACTIVE "
            "(cross-pod advisory lock; no-op on SQLite/single-pod; "
            "max_workers=%d from scheduler.job_pool_size)",
            _executor_max_workers(),
        )
    except Exception as _sg_exc:
        # Never let the backstop wiring stop the scheduler from starting —
        # fall back to the plain executor (today's leader-only behaviour).
        logger.warning(
            "Could not install job-singleton executor (%s) — "
            "falling back to plain ThreadPoolExecutor (leader-only guard)",
            _sg_exc,
        )
        executor = APSThreadPool(max_workers=_executor_max_workers())

    # 2026-08-20 — a SECOND, IN-MEMORY jobstore for system/daemon jobs.
    #
    # Discovered while making daemon ownership explicit: the persistent
    # SQLAlchemy jobstore REFUSES any job whose callable is a closure
    # ("cannot be serialized ... consider a textual reference") or whose
    # args are unpicklable (DatabaseManager holds thread locks).  Every such
    # add_job here is wrapped in try/except-warning, so TWELVE of this
    # function's own maintenance jobs (zombie scanner, feed stale-reclaim,
    # orphan sweeps, api-key revocation, heartbeat, ...) plus every
    # closure-shaped brain daemon and the 2026-08-19 retention sweeps
    # (args=[db_manager]) were being silently DROPPED at registration —
    # "registered" in the logs, absent from the store.  Verified by
    # executing init_scheduler and listing surviving job ids.
    #
    # Daemon jobs need NO persistence: every boot re-registers them with
    # replace_existing=True.  Only USER SCHEDULES benefit from the
    # persistent store (next_run continuity), and they keep it — the
    # "default" store is unchanged.
    from apscheduler.jobstores.memory import MemoryJobStore

    _scheduler = BackgroundScheduler(
        jobstores={"default": jobstore, "daemon": MemoryJobStore()},
        executors={"default": executor},
        job_defaults={
            "coalesce": True,       # collapse missed fires into one
            "max_instances": 1,     # no overlapping runs for the same job
            # Short grace time: skip jobs missed while the server was down for
            # more than 30 s — prevents bulk-firing on restart which would
            # compete with interactive queries for CPU/IO.
            "misfire_grace_time": 30,
        },
        timezone="UTC",
    )
    _scheduler.start(paused=start_paused)
    # 2026-10-07 -- every scheduled fire of a DECLARED job lands in the
    # background-job ledger (core/background_job_contract.py), the same
    # record an admin run-now writes.  Attached here, after start, because
    # this is the one function both entry points (main.py, scheduler_
    # worker.py) and the lock-retry start pass through.
    try:
        from core.background_job_contract import attach_scheduler_listener
        attach_scheduler_listener(_scheduler)
    except Exception as _bjc_exc:
        logger.warning("background-job ledger listener not attached "
                       "(scheduled fires will not be ledgered): %s", _bjc_exc)
    if start_paused:
        logger.warning(
            "QueryScheduler started PAUSED (autostart=false) — "
            "admin: POST /api/admin/scheduler/resume to begin firing jobs"
        )
    else:
        logger.info("QueryScheduler started (APScheduler %s)", _aps_version())

    # One-time migration sweep: system job ids (``__x__``) that a PREVIOUS
    # build managed to persist into the default store would now DOUBLE-FIRE
    # against their memory-store replacements — drop the persistent copies.
    # (Corrupted/unresolvable rows are already auto-removed by the jobstore
    # on load.)
    try:
        for _stale in _scheduler.get_jobs(jobstore="default"):
            if _stale.id.startswith("__") and _stale.id.endswith("__"):
                _scheduler.remove_job(_stale.id, jobstore="default")
                logger.info("Migrated system job %s out of the persistent "
                            "jobstore (now memory-backed)", _stale.id)
    except Exception as _mig_exc:
        logger.warning("System-job jobstore migration sweep failed "
                       "(non-fatal): %s", _mig_exc)

    # Re-register all active schedules from DB (APScheduler jobstore already has
    # their trigger state from the previous run; this just refreshes next_run_at).
    # 2026-08-09: paginated — the old ``limit=1000`` silently never registered
    # schedule #1,001+ (metadata-scale audit finding 4).
    schedules = _load_all_active_schedules(db_manager)
    _bootstrap_schedules(schedules)
    logger.info("Loaded %d active schedule(s) from DB", len(schedules))

    # Add periodic temp-file cleanup — runs every 30 minutes.
    # Deletes raw execution CSVs not registered in the Download Center
    # and any Download Center files whose expiry has passed.
    try:
        from apscheduler.triggers.interval import IntervalTrigger as _IT
        _scheduler.add_job(
            func=_cleanup_temp_files,
            trigger=_IT(minutes=30),
            id="__temp_file_cleanup__", jobstore="daemon",
            name="Temp file cleanup",
            replace_existing=True,
            misfire_grace_time=120,
        )
        logger.info("Registered temp-file cleanup job (every 30 min)")
    except Exception as _ce:
        logger.warning("Could not register cleanup job: %s", _ce)

    # Register query result cache cleanup — runs every 30 minutes
    try:
        from core.query_cache import cleanup_expired as _cache_cleanup
        _scheduler.add_job(
            func=_cache_cleanup,
            trigger=_IT(minutes=30),
            id="__query_cache_cleanup__", jobstore="daemon",
            name="Query cache cleanup",
            replace_existing=True,
            misfire_grace_time=120,
        )
        logger.info("Registered query cache cleanup job (every 30 min)")
    except Exception as _ce:
        logger.warning("Could not register cache cleanup job: %s", _ce)

    # BF-411.3 — Audit log retention sweep — daily at 02:30 (off-peak)
    try:
        from apscheduler.triggers.cron import CronTrigger as _CT
        _scheduler.add_job(
            func=_cleanup_audit_log,
            trigger=_CT(hour=2, minute=30),
            id="__audit_log_cleanup__", jobstore="daemon",
            name="Audit log retention sweep",
            replace_existing=True,
            misfire_grace_time=3600,
        )
        logger.info("Registered audit log retention sweep (daily at 02:30)")
    except Exception as _ce:
        logger.warning("Could not register audit log sweep job: %s", _ce)

    # BF-411.2 — Local-tables orphan-file cleanup — daily at 03:00
    try:
        from apscheduler.triggers.cron import CronTrigger as _CT
        _scheduler.add_job(
            func=_cleanup_local_tables_orphans,
            trigger=_CT(hour=3, minute=0),
            id="__local_tables_orphan_cleanup__", jobstore="daemon",
            name="Local tables orphan-file cleanup",
            replace_existing=True,
            misfire_grace_time=3600,
        )
        logger.info("Registered local-tables orphan cleanup (daily at 03:00)")
    except Exception as _ce:
        logger.warning("Could not register local-tables cleanup job: %s", _ce)

    # BF-257: Persistent S3 file cache LRU eviction — only runs when enabled
    try:
        from core.config import s3_local_cache as _sclc
        if _sclc.enabled:
            from core.duckdb_views import evict_s3_cache_lru as _s3c_evict
            _interval = max(5, int(_sclc.evict_interval_minutes))
            _scheduler.add_job(
                func=_s3c_evict,
                trigger=_IT(minutes=_interval),
                id="__s3_local_cache_lru__", jobstore="daemon",
                name="S3 file cache LRU eviction",
                replace_existing=True,
                misfire_grace_time=120,
            )
            logger.info("Registered S3 file cache LRU eviction job (every %d min, max %d GB)",
                        _interval, _sclc.max_size_gb)
    except Exception as _ce:
        logger.warning("Could not register S3 cache eviction job: %s", _ce)

    # Iceberg manifest + snapshot cache LRU eviction — runs every 6h.
    # These caches grow forever otherwise: every snapshot a writer commits
    # adds a row to IcebergSnapshotCache; every distinct manifest file
    # adds to IcebergManifestCache.  Over years of operation the DB grows
    # unbounded.  Eviction defaults: 200 snapshots, 5000 manifests (LRU).
    try:
        from core.config import get as _cfg_get_for_iceberg
        _ic_max_snap = int(_cfg_get_for_iceberg(
            "iceberg", "snapshot_cache_max_entries", 200) or 200)
        _ic_max_manifest = int(_cfg_get_for_iceberg(
            "iceberg", "manifest_cache_max_entries", 5000) or 5000)

        def _iceberg_cache_evict_job():
            # Returns its counts (2026-10-07): the background-job ledger
            # classifies the scheduled fire from them.
            try:
                if not _db():
                    return {"status": "skipped", "reason": "no db manager"}
                n_snap = _db().evict_iceberg_snapshot_cache_lru(_ic_max_snap)
                n_man = _db().evict_iceberg_manifest_cache_lru(_ic_max_manifest)
                if n_snap or n_man:
                    logger.info(
                        "[iceberg-cache-lru] evicted %d snapshot rows + %d manifest rows",
                        n_snap, n_man,
                    )
                return {"snapshot_rows": int(n_snap or 0),
                        "manifest_rows": int(n_man or 0)}
            except Exception as _evict_err:
                logger.warning("[iceberg-cache-lru] failed: %s", _evict_err)
                return {"error": str(_evict_err)[:300]}

        # next_run_time=now() runs immediately on startup, then every 6h.
        # Important for over-grown caches — don't wait 6h for first eviction.
        import datetime as _dt_imm
        _scheduler.add_job(
            func=_iceberg_cache_evict_job,
            trigger=_IT(hours=6),
            id="__iceberg_cache_lru__", jobstore="daemon",
            name="Iceberg manifest/snapshot cache LRU eviction",
            replace_existing=True,
            misfire_grace_time=300,
            next_run_time=_dt_imm.datetime.now(_dt_imm.timezone.utc) + _dt_imm.timedelta(seconds=60),
        )
        logger.info(
            "Registered Iceberg cache LRU eviction job (every 6h; "
            "max snapshots=%d, max manifests=%d)",
            _ic_max_snap, _ic_max_manifest,
        )
    except Exception as _ic_ev_exc:
        logger.warning("Could not register Iceberg cache LRU eviction job: %s",
                        _ic_ev_exc)

    # ── BF-512 (2026-05-28): Iceberg metadata-key DB refresh sweep ───────────
    # Proactive companion to BF-511.  BF-511 hardened the on-demand read
    # path (DB hit now verifies via version-hint + falls through past hard
    # max-age).  BF-512 closes the OTHER direction: if no query ever hits
    # a particular DB row, its pointer can still drift far from S3 reality
    # until a query touches it.  This job iterates ALL non-sentinel rows
    # on the admin-configured interval and force-re-resolves each one
    # against S3 — guaranteeing freshness regardless of query traffic.
    #
    # FULLY ADMIN-CONTROLLED — nothing hardcoded:
    #   iceberg.metadata_key_background_refresh_enabled   bool  default True
    #   iceberg.metadata_key_background_refresh_interval_minutes int default 30
    #   iceberg.metadata_key_background_refresh_batch_size int default 0 (=all)
    # When `enabled=false` the job is NOT REGISTERED — no idle thread, no
    # silent S3 cost.  Disabling at runtime requires a restart (standard
    # scheduler pattern); the interval is read fresh on each registration.
    try:
        from core.config import get as _cfg_get_for_ic
        _bg_enabled = bool(_cfg_get_for_ic(
            "iceberg", "metadata_key_background_refresh_enabled", True))
        _bg_interval = int(_cfg_get_for_ic(
            "iceberg", "metadata_key_background_refresh_interval_minutes", 30)
            or 30)
        _bg_batch = int(_cfg_get_for_ic(
            "iceberg", "metadata_key_background_refresh_batch_size", 0) or 0)
        if _bg_interval < 1:
            _bg_interval = 1  # clamp pathological config

        if not _bg_enabled:
            logger.info(
                "Iceberg metadata-key background refresh DISABLED via config "
                "(iceberg.metadata_key_background_refresh_enabled=false). "
                "DB rows refresh on-demand only (BF-511 hard max-age still "
                "caps stale-row blast radius).")
        else:
            def _iceberg_metadata_key_refresh_job():
                """Sweep ``IcebergMetadataKeyCache`` and force-refresh each
                non-sentinel row.  Per-row failures are isolated — one bad
                connection cannot stop the sweep."""
                if not _db():
                    return
                t0 = datetime.now(timezone.utc)
                try:
                    rows = _db().list_iceberg_metadata_keys_for_refresh(
                        limit=_bg_batch, exclude_sentinel=True)
                except Exception as exc:
                    logger.warning(
                        "[iceberg-meta-refresh] DB list failed: %s", exc)
                    return
                if not rows:
                    return
                try:
                    from core.iceberg_reader import refresh_metadata_key_db_row
                except Exception as exc:
                    logger.warning(
                        "[iceberg-meta-refresh] import failed: %s", exc)
                    return
                n_ok = n_adv = n_fail = 0
                fail_examples: list[str] = []
                for row in rows:
                    try:
                        out = refresh_metadata_key_db_row(
                            row.get("connection_id"), row.get("cache_id"))
                        if out.get("ok"):
                            n_ok += 1
                            if out.get("advanced"):
                                n_adv += 1
                        else:
                            n_fail += 1
                            if len(fail_examples) < 5:
                                fail_examples.append(
                                    f"{row.get('cache_id')} ({out.get('error')})")
                    except Exception as exc:
                        n_fail += 1
                        if len(fail_examples) < 5:
                            fail_examples.append(
                                f"{row.get('cache_id')} (uncaught: {exc})")
                dur = (datetime.now(timezone.utc) - t0).total_seconds()
                logger.info(
                    "[iceberg-meta-refresh] swept %d rows in %.1fs — "
                    "ok=%d (advanced=%d), failed=%d%s",
                    len(rows), dur, n_ok, n_adv, n_fail,
                    (f"; samples=[{'; '.join(fail_examples)}]"
                     if fail_examples else ""),
                )
                # 2026-10-07 -- the ledger reads these counts.
                return {"rows": len(rows), "ok": n_ok, "advanced": n_adv,
                        "failed": n_fail}

            # Stagger first run so it doesn't dogpile with the LRU evict
            # job on startup; both touch the same DB.
            _scheduler.add_job(
                func=_iceberg_metadata_key_refresh_job,
                trigger=_IT(minutes=_bg_interval),
                id="__iceberg_meta_key_refresh__", jobstore="daemon",
                name="Iceberg metadata-key DB refresh sweep",
                replace_existing=True,
                misfire_grace_time=600,
                next_run_time=datetime.now(timezone.utc)
                              + timedelta(seconds=120),
            )
            logger.info(
                "Registered Iceberg metadata-key DB refresh job "
                "(every %d min%s, BF-512)",
                _bg_interval,
                f", batch={_bg_batch}" if _bg_batch > 0 else ", batch=ALL",
            )
    except Exception as _bg_ref_exc:
        logger.warning(
            "Could not register Iceberg metadata-key refresh job: %s",
            _bg_ref_exc)

    # ── BF-516 (2026-05-28): Zombie-run scanner ──────────────────────────────
    # When a worker pod crashes / is OOM-killed mid-execution, the run row
    # stays ``status='running'`` forever — dashboards mis-report active load
    # and operators have no clean recovery signal.  This job sweeps both
    # FeedRun + DataFlowRun and flips long-stuck rows to ``failed`` with
    # explicit zombie markers so operations can triage vs. silently re-trigger.
    #
    # FULLY ADMIN-CONTROLLED — nothing hardcoded:
    #   zombie_scanner.enabled                              bool default True
    #   zombie_scanner.interval_minutes                     int  default 15
    #   zombie_scanner.feed_run_max_runtime_seconds         int  default 14400 (4h)
    #   zombie_scanner.dataflow_run_max_runtime_seconds     int  default 14400 (4h)
    # When ``enabled=false`` the job is NOT REGISTERED — operators who run
    # their own zombie recovery pipeline can opt out cleanly.
    try:
        from core.config import get as _cfg_get_for_zombie
        _z_enabled = bool(_cfg_get_for_zombie(
            "zombie_scanner", "enabled", True))
        _z_interval = int(_cfg_get_for_zombie(
            "zombie_scanner", "interval_minutes", 15) or 15)
        _z_fr_max = int(_cfg_get_for_zombie(
            "zombie_scanner", "feed_run_max_runtime_seconds", 14400) or 14400)
        _z_df_max = int(_cfg_get_for_zombie(
            "zombie_scanner", "dataflow_run_max_runtime_seconds", 14400) or 14400)
        if _z_interval < 1:
            _z_interval = 1  # clamp pathological config

        if not _z_enabled:
            logger.info(
                "Zombie-run scanner DISABLED via config "
                "(zombie_scanner.enabled=false).  Long-running 'running' rows "
                "will persist on dashboards until manually cleared.")
        else:
            def _zombie_scanner_job():
                """Sweep stuck feed_runs + dataflow_runs.  Per-table errors
                are isolated so a partial failure doesn't stop the other
                sweep."""
                if not _db():
                    return
                fr_count = df_count = 0
                try:
                    fr_count = _db().mark_zombie_feed_runs(_z_fr_max)
                except Exception as exc:
                    logger.warning(
                        "[zombie-scan] feed_runs sweep failed: %s", exc)
                try:
                    df_count = _db().mark_zombie_dataflow_runs(_z_df_max)
                except Exception as exc:
                    logger.warning(
                        "[zombie-scan] dataflow_runs sweep failed: %s", exc)
                if fr_count or df_count:
                    logger.warning(
                        "[zombie-scan] marked %d feed_run(s) + %d "
                        "dataflow_run(s) as failed (stuck >fr=%ds/df=%ds)",
                        fr_count, df_count, _z_fr_max, _z_df_max,
                    )

            _scheduler.add_job(
                func=_zombie_scanner_job,
                trigger=_IT(minutes=_z_interval),
                id="__zombie_run_scanner__", jobstore="daemon",
                name="Zombie-run scanner (feed_runs + dataflow_runs)",
                replace_existing=True,
                misfire_grace_time=600,
                next_run_time=datetime.now(timezone.utc)
                              + timedelta(seconds=180),
            )
            logger.info(
                "Registered zombie-run scanner (every %d min; "
                "feed_run_max=%ds, dataflow_run_max=%ds, BF-516)",
                _z_interval, _z_fr_max, _z_df_max,
            )
    except Exception as _z_exc:
        logger.warning(
            "Could not register zombie-run scanner job: %s", _z_exc)

    # Enforce disk quota on cache + downloads — runs every 30 minutes
    try:
        _scheduler.add_job(
            func=_enforce_storage_quotas,
            trigger=_IT(minutes=30),
            id="__storage_quota__", jobstore="daemon",
            name="Storage quota enforcement",
            replace_existing=True,
            misfire_grace_time=120,
        )
        logger.info("Registered storage quota job (every 30 min)")
    except Exception as _ce:
        logger.warning("Could not register storage quota job: %s", _ce)

    # Clean up orphaned DuckDB spill + presigned download staging dirs — every 30 min.
    # These are left behind when executor subprocesses crash or are OOM-killed.
    try:
        _scheduler.add_job(
            func=_cleanup_subprocess_temp_dirs,
            trigger=_IT(minutes=30),
            id="__subprocess_temp_cleanup__", jobstore="daemon",
            name="Subprocess temp dir cleanup",
            replace_existing=True,
            misfire_grace_time=120,
        )
        logger.info("Registered subprocess temp dir cleanup job (every 30 min)")
    except Exception as _ce:
        logger.warning("Could not register subprocess temp cleanup job: %s", _ce)

    # Prune old execution history — runs once daily
    try:
        from apscheduler.triggers.interval import IntervalTrigger as _DIT
        _scheduler.add_job(
            func=_cleanup_execution_history,
            trigger=_DIT(hours=24),
            id="__execution_history_cleanup__", jobstore="daemon",
            name="Execution history cleanup",
            replace_existing=True,
            misfire_grace_time=3600,
        )
        logger.info("Registered execution history cleanup job (every 24 h)")
    except Exception as _ce:
        logger.warning("Could not register execution history cleanup job: %s", _ce)

    # Auto-refresh stale partition caches — runs every 5 hours
    try:
        _scheduler.add_job(
            func=_refresh_partition_caches,
            trigger=_IT(hours=5),
            id="__partition_cache_refresh__", jobstore="daemon",
            name="Partition cache refresh",
            replace_existing=True,
            misfire_grace_time=600,
        )
        logger.info("Registered partition cache refresh job (every 5 h)")
    except Exception as _pce:
        logger.warning("Could not register partition cache refresh job: %s", _pce)

    # Auto-discard expired local tables — runs every N hours (default 6)
    try:
        from core.config import local_tables as _lt_cfg
        _scheduler.add_job(
            func=_cleanup_expired_local_tables_job,
            trigger=_IT(hours=_lt_cfg.cleanup_interval_hours),
            id="__local_table_cleanup__", jobstore="daemon",
            name="Local table auto-discard",
            replace_existing=True,
            misfire_grace_time=600,
        )
        logger.info("Registered local table cleanup job (every %d h)", _lt_cfg.cleanup_interval_hours)
    except Exception as _ltce:
        logger.warning("Could not register local table cleanup job: %s", _ltce)

    # Phase 104: stale cache sweep — runs every N hours (default 2)
    try:
        from core.config import cache as _cache_cfg_sched
        _sweep_interval = _cache_cfg_sched.snapshot_sweep_interval_hours
        _scheduler.add_job(
            func=_sweep_stale_cache_entries,
            trigger=_IT(hours=_sweep_interval),
            id="__stale_cache_sweep__", jobstore="daemon",
            name="Stale cache sweep (partition-aware)",
            replace_existing=True,
            misfire_grace_time=600,
        )
        logger.info("Registered stale cache sweep job (every %d h)", _sweep_interval)
    except Exception as _scs_exc:
        logger.warning("Could not register stale cache sweep job: %s", _scs_exc)

    # Aggregation cache cleanup + quota enforcement — runs every N hours
    try:
        from core.agg_cache import cleanup_expired as _agg_cleanup, enforce_storage_quota as _agg_quota
        from core.config import agg_cache as _agg_cfg

        def _agg_cache_maintenance():
            _agg_cleanup()
            _agg_quota()

        _scheduler.add_job(
            func=_agg_cache_maintenance,
            trigger=_IT(hours=_agg_cfg.cleanup_interval_hours),
            id="__agg_cache_cleanup__", jobstore="daemon",
            name="Agg cache cleanup + quota",
            replace_existing=True,
            misfire_grace_time=600,
        )
        logger.info("Registered agg cache maintenance job (every %d h)",
                     _agg_cfg.cleanup_interval_hours)
    except Exception as _ace:
        logger.warning("Could not register agg cache cleanup job: %s", _ace)

    # Phase 60: Subscription delivery processor
    #
    # 2026-11-02 -- an EXECUTION (it runs reports and sends e-mails), so it
    # is the job-worker tier's: registered here only in a process that owns
    # background execution (a standalone install); on a job-worker pod the
    # daemon registry registers the same job (``subscription_delivery``,
    # daemon_registry.DAEMON_HOME); the scheduler pod registers nothing.
    try:
        from core import responsibilities as _resp_sub
        if _resp_sub.owns(_resp_sub.BACKGROUND_EXECUTION):
            register_subscription_delivery_job(_scheduler)
        else:
            logger.info("Subscription delivery job NOT registered in this process -- %s",
                        _resp_sub.why_not(_resp_sub.BACKGROUND_EXECUTION))
    except Exception as _sde:
        logger.warning("Could not register subscription delivery job: %s", _sde)

    # Phase 76: Feed file generation cleanup + retry
    try:
        from core.config import feed_generation as _fg_cfg
        if _fg_cfg.enabled:
            from core.feed_engine import cleanup_old_executions as _feed_cleanup
            _scheduler.add_job(
                func=_feed_cleanup,
                trigger=_IT(hours=_fg_cfg.cleanup_interval_hours),
                id="__feed_execution_cleanup__", jobstore="daemon",
                name="Feed execution cleanup",
                replace_existing=True,
                misfire_grace_time=600,
            )
            logger.info("Registered feed execution cleanup job (every %d h)",
                         _fg_cfg.cleanup_interval_hours)
    except Exception as _fce:
        logger.warning("Could not register feed cleanup job: %s", _fce)

    # Phase 130 hotfix-11: Queue worker for SOD-generated pending
    # feed_runs.  Polls every queue_poll_interval_seconds; atomic
    # claim defends against double-trigger when multiple pods poll.
    #
    # 2026-11-02 -- WHO RUNS FEEDS IS A RESPONSIBILITY, not two flags.
    # ``core/responsibilities.py``: the queue worker registers in a process
    # that OWNS feed runs -- a standalone install (one process, everything)
    # -- and in no other.  The scheduler pod declares itself the scheduler
    # and never registers one; the feed-worker pods poll on their own
    # (feed_worker.py).  ``feed_generation.queue_worker_enabled`` and
    # ``worker_pod_only`` no longer decide this (they are kept as declared
    # keys so an old config file still loads; a value set is logged and
    # ignored).  Every trigger road -- the cron fire, Run Now, the external
    # trigger, SOD -- puts a row on the queue, so a process that owns feed
    # runs ALWAYS consumes it: a standalone install with the old default
    # (queue_worker_enabled=false) would otherwise never run a Run Now.
    try:
        from core import responsibilities as _resp
        from core.config import feed_generation as _fg_cfg_qw
        for _old_flag in ("queue_worker_enabled", "worker_pod_only"):
            if bool(getattr(_fg_cfg_qw, _old_flag, False)):
                logger.warning(
                    "feed_generation.%s is set but no longer decides anything: which "
                    "process runs feeds is its declared responsibility (this process "
                    "is the %s). Remove the key from the config.", _old_flag, _resp.current())
        if _resp.owns(_resp.FEED_RUNS):
            # Singleton worker so `_inflight` persists across ticks — a
            # fresh-per-tick worker silently breaks max_concurrent
            # enforcement.  The shared accessor is also used by the
            # admin `/poll-now` endpoint so the per-pod inflight bound
            # is enforced regardless of trigger source.
            from core.feed.queue_worker import get_shared_queue_worker
            _shared_qw = get_shared_queue_worker(
                _db_manager,
                max_concurrent=_fg_cfg_qw.max_concurrent_native,
            )

            def _run_queue_worker():
                try:
                    if not _db():
                        return
                    result = _shared_qw.poll_once()
                    if result.claimed > 0 or result.errors > 0:
                        logger.info("[queue_worker] %s", result.to_dict())
                except Exception as exc:
                    logger.warning("[queue_worker] tick failed: %s", exc)

            _qw_interval = max(5, int(_fg_cfg_qw.queue_poll_interval_seconds))
            _scheduler.add_job(
                func=_run_queue_worker,
                trigger=_IT(seconds=_qw_interval),
                id="__feed_queue_worker__", jobstore="daemon",
                name="Feed run queue worker",
                replace_existing=True,
                misfire_grace_time=300,
            )
            logger.info(
                "Registered Feed queue worker (every %ds, max_concurrent=%d)",
                _qw_interval, _fg_cfg_qw.max_concurrent_native,
            )
        else:
            logger.info(
                "Feed queue worker NOT registered in this process -- %s",
                _resp.why_not(_resp.FEED_RUNS))
    except Exception as _qwe:
        logger.warning("Could not register Feed queue worker: %s", _qwe)

    # Phase 130 hotfix-13: Feed failover agent.  Probes Airflow + native
    # worker health every ``failover_agent_interval_seconds`` and flips
    # ``feed_generation.backend_override`` automatically when one side
    # is down.  Off by default — admin opts in via the failover panel.
    #
    # Multi-pod safety: ``init_scheduler`` only ran on the lease-holding
    # pod, so the job is registered ONLY on the leader.  We add a
    # per-tick lease-still-mine check as belt-and-suspenders for the
    # brief window where a lease can lapse (network blip) and a NEW
    # leader is elected before the OLD pod's APScheduler stops.
    try:
        from core.config import feed_generation as _fg_cfg_fa
        if _fg_cfg_fa.failover_agent_enabled:
            def _run_failover_agent():
                try:
                    if not _db():
                        return
                    # Per-tick leader check — drop the tick when we're
                    # no longer the leader (post lease-handover).
                    try:
                        if not _this_process_runs_apscheduler():
                            logger.debug(
                                "[failover_agent] this process does not hold the scheduler lock — skipping tick",
                            )
                            return
                    except Exception:
                        pass
                    from core.feed.failover_agent import get_agent
                    agent = get_agent(_db(), broadcast_fn=_broadcast_fn)
                    result = agent.tick()
                    if result.get("changed"):
                        logger.info("[failover_agent] %s", result)
                except Exception as exc:
                    logger.warning("[failover_agent] tick failed: %s", exc)

            _fa_interval = max(5, int(_fg_cfg_fa.failover_agent_interval_seconds))
            _scheduler.add_job(
                func=_run_failover_agent,
                trigger=_IT(seconds=_fa_interval),
                id="__feed_failover_agent__", jobstore="daemon",
                name="Feed backend failover agent",
                replace_existing=True,
                misfire_grace_time=120,
            )
            logger.info("Registered Feed failover agent (every %ds)", _fa_interval)
    except Exception as _fae:
        logger.warning("Could not register Feed failover agent: %s", _fae)

    # Phase 130 hotfix-13: Stale running-row reclamation.  When a worker
    # pod crashes mid-execution, its feed_runs are stuck in status=
    # 'running'.  This sweeper resets them to 'pending' after
    # ``stale_running_reclaim_seconds`` so another shard picks them up.
    # Critical for shard pod resilience — without it a crashed shard
    # silently loses its in-flight feeds.
    # FR-RUN-08 (2026-09-02): the sweep is now HEARTBEAT-keyed — see
    # run_feed_stale_reclaim_sweep above.  The threshold is a heartbeat
    # timeout, not a run-duration cap: a healthy multi-hour run that
    # keeps beating is never reaped.
    try:
        from core.config import feed_generation as _fg_cfg_rec
        _rec_secs = int(_fg_cfg_rec.stale_running_reclaim_seconds)
        if _rec_secs > 0:
            def _run_reclaim_sweeper():
                try:
                    if not _db():
                        return
                    # Only the lease holder runs the sweeper to avoid
                    # double-reclamation.
                    try:
                        if not _this_process_runs_apscheduler():
                            return
                    except Exception:
                        pass
                    # FR-RUN-08 (2026-09-02) — one heartbeat-keyed pass
                    # over claims, run rows, execution rows and child
                    # file-runs.  Extracted to a module-level function so
                    # the property "a beating run survives the sweep" is
                    # testable by value; see its docstring for the
                    # NULL-heartbeat (legacy row) decision.
                    counts = run_feed_stale_reclaim_sweep(
                        _db(),
                        _fg_cfg_rec.stale_running_reclaim_seconds,
                    )
                    if counts.get("claims"):
                        logger.warning(
                            "[stale_reclaim] reclaimed %d connection "
                            "slot(s) from pods that stopped beating",
                            counts["claims"])
                    count = int(counts.get("runs") or 0)
                    if count > 0:
                        logger.warning(
                            "[stale_reclaim] Reset %d orphaned running feed_run row(s) to pending "
                            "(no heartbeat for >%ds — claiming pods presumed dead)",
                            count, _fg_cfg_rec.stale_running_reclaim_seconds,
                        )
                        try:
                            _db().audit(
                                "system", "feed_runs_stale_reclaimed",
                                resource_type="feed_runs",
                                extra={"count": count,
                                       "stale_after_seconds": _fg_cfg_rec.stale_running_reclaim_seconds},
                            )
                        except Exception:
                            pass
                    if counts.get("executions") or counts.get("file_runs"):
                        logger.warning(
                            "[stale_reclaim] reaped %d orphaned execution row(s) "
                            "and %d orphaned child file-run(s) (no heartbeat "
                            "for >%ds)",
                            counts.get("executions") or 0,
                            counts.get("file_runs") or 0,
                            _fg_cfg_rec.stale_running_reclaim_seconds,
                        )
                except Exception as exc:
                    logger.warning("[stale_reclaim] sweep failed: %s", exc)

            _rec_interval = max(60, int(_fg_cfg_rec.stale_running_reclaim_interval_seconds))
            _scheduler.add_job(
                func=_run_reclaim_sweeper,
                trigger=_IT(seconds=_rec_interval),
                id="__feed_stale_reclaim__", jobstore="daemon",
                name="Feed stale-running reclamation",
                replace_existing=True,
                misfire_grace_time=600,
            )
            logger.info("Registered Feed stale-running reclamation (every %ds, threshold=%ds)",
                         _rec_interval, _rec_secs)
    except Exception as _rece:
        logger.warning("Could not register Feed stale reclamation: %s", _rece)

    # Phase 130/4: Feed SLA tracker.  Periodic sweep of pending+running
    # feed_runs whose sla_to deadline has passed; marks sla_breached
    # and fires notifications.  Off by default.
    try:
        from core.config import feed_generation as _fg_cfg_sla
        if _fg_cfg_sla.sla_tracker_enabled:
            def _run_sla_tracker():
                try:
                    if not _db():
                        return
                    from core.feed.sla_tracker import SlaTracker
                    tracker = SlaTracker(_db(),
                                         notify_fn=feed_sla_breach_notify)
                    result = tracker.sweep_once()
                    if result.breached_new > 0 or result.error_details:
                        logger.info("[sla_tracker] %s", result.to_dict())
                except Exception as exc:
                    logger.warning("[sla_tracker] sweep failed: %s", exc)

            _interval = max(15, int(_fg_cfg_sla.sla_check_interval_seconds))
            _scheduler.add_job(
                func=_run_sla_tracker,
                trigger=_IT(seconds=_interval),
                id="__feed_sla_tracker__", jobstore="daemon",
                name="Feed SLA tracker",
                replace_existing=True,
                misfire_grace_time=300,
            )
            logger.info("Registered Feed SLA tracker (every %ds)", _interval)
    except Exception as _sle:
        logger.warning("Could not register Feed SLA tracker: %s", _sle)

    # ─── Phase 131-A: ETL dependency poller (leader-gated) ───────────────
    # Polls pending feed_runs whose feed has etl_id set, checks each
    # mapping's tracking row for business_date, flips action_decision to
    # RUN (deps ready) or WAIT (not yet).  Off by default.  When on, only
    # the scheduler-lease holder runs the tick to prevent multi-pod
    # double-flipping.
    try:
        from core.feed.etl_dependency import load_config as _etl_dep_load_cfg
        _ed_cfg = _etl_dep_load_cfg()
        if _ed_cfg.get("enabled"):
            _feed_dep_broadcast = feed_dep_broadcast

            def _run_etl_dep_poller():
                # Returns its counters (2026-10-07) for the background-job
                # ledger; a non-holder says so instead of returning nothing.
                try:
                    if not _db():
                        return {"status": "skipped", "reason": "no db manager"}
                    if _ed_cfg.get("leader_only", True):
                        try:
                            if not _this_process_runs_apscheduler():
                                return {"status": "skipped",
                                        "reason": "not the scheduler-lock holder"}
                        except Exception:
                            pass
                    # 2026-10-11 -- a NEW system entity a COMPLETE message named
                    # becomes a feed (+ its SOD task for that business date)
                    # BEFORE the poll, so its run is evaluated in this same tick
                    # (core/feed/auto_onboard.py).  Never raises.
                    from core.feed.auto_onboard import process_requests as _onboard
                    _ob = _onboard(_db())
                    if any(_ob.values()):
                        logger.warning("[auto_onboard] %s", _ob)
                    from core.feed.etl_dependency import poll_pending_runs, escalate_stale_wait_runs
                    counters = poll_pending_runs(
                        _db(),
                        broadcast_fn=_feed_dep_broadcast,
                        sla_grace_hours=float(_ed_cfg.get("sla_grace_hours", 2)),
                    )
                    if counters.get("flipped_to_run", 0) or counters.get("sla_breached", 0):
                        logger.info("[etl_dependency] %s", counters)
                    # Phase 131 deep-dive #12: escalation sweep — fail
                    # rows stuck in WAIT past the threshold so they
                    # don't hang silently forever.
                    _esc_hours = float(_ed_cfg.get("wait_escalation_hours", 48))
                    if _esc_hours > 0:
                        esc_counters = escalate_stale_wait_runs(
                            _db(),
                            escalation_hours=_esc_hours,
                            broadcast_fn=_feed_dep_broadcast,
                        )
                        if esc_counters.get("escalated", 0):
                            logger.warning("[etl_dependency] escalation %s", esc_counters)
                        counters = {**counters,
                                    "escalated": int(esc_counters.get("escalated", 0) or 0)}
                    return counters
                except Exception as exc:
                    logger.warning("[etl_dependency] poll failed: %s", exc)
                    return {"error": str(exc)[:300]}

            _ed_interval = max(15, int(_ed_cfg.get("interval_seconds", 60)))
            _scheduler.add_job(
                func=_run_etl_dep_poller,
                trigger=_IT(seconds=_ed_interval),
                id="__feed_etl_dep_poller__", jobstore="daemon",
                name="Feed ETL dependency poller",
                replace_existing=True,
                misfire_grace_time=120,
            )
            logger.info("Registered Feed ETL dependency poller (every %ds, leader_only=%s)",
                         _ed_interval, _ed_cfg.get("leader_only", True))
    except Exception as _ede:
        logger.warning("Could not register ETL dependency poller: %s", _ede)

    # ─── Phase 131-B: Row-count baseline refresh (daily) ─────────────────
    # Walks each opt-in feed config (row_count_action != 'off'), recomputes
    # the rolling-window baseline from recent completed runs, upserts the
    # feed_row_count_baseline row.  Cheap — runs once a day.
    try:
        from core.feed.row_count_check import _load_defaults as _rc_load
        from core.cron_compat import crontab_trigger as _CT_rc

        def _run_baseline_refresh():
            try:
                if not _db():
                    return
                # Leader-gated to avoid duplicate writes from multi-pod.
                try:
                    if not _this_process_runs_apscheduler():
                        return
                except Exception:
                    pass
                from core.feed.row_count_check import recompute_baseline_from_history
                from datetime import datetime as _dt, timedelta as _td, timezone as _tz
                defaults = _rc_load()
                window = int(defaults.get("default_window_days", 7))
                since = _dt.now(_tz.utc) - _td(days=window)
                feeds = _db().list_feed_configs(is_active=True)
                touched = 0
                for fc in feeds:
                    action = (fc.get("row_count_action") or "off").lower()
                    if action == "off":
                        continue
                    runs = _db().list_recent_completed_feed_runs(
                        fc["id"], since=since, limit=50,
                    )
                    base = recompute_baseline_from_history(
                        runs, rolling_window_days=window,
                    )
                    if base is None:
                        continue
                    _db().upsert_feed_row_count_baseline(fc["id"], base)
                    touched += 1
                if touched:
                    logger.info("[row_count_baseline] refreshed %d feeds", touched)
            except Exception as exc:
                logger.warning("[row_count_baseline] refresh failed: %s", exc)

        # Cron expression is DB-tunable via system_settings — no hardcoded
        # value.  Defaults to 01:00 UTC daily when DB has no override.
        try:
            from core.config import _db_setting_or as _dbget
            _baseline_cron = str(_dbget(
                "feed_generation.row_count_baseline_cron", "0 1 * * *",
            ))
        except Exception:
            _baseline_cron = "0 1 * * *"
        _scheduler.add_job(
            func=_run_baseline_refresh,
            trigger=_CT_rc(_baseline_cron),
            id="__feed_row_count_baseline__", jobstore="daemon",
            name="Feed row-count baseline refresh",
            replace_existing=True,
            misfire_grace_time=3600,
        )
        logger.info("Registered Feed row-count baseline refresh (cron: %s)", _baseline_cron)
    except Exception as _rbe:
        logger.warning("Could not register row-count baseline refresh: %s", _rbe)

    # ─── Phase 131 deep-dive #12: orphan-temp-file sweeper ───────────────
    # When a feed worker pod crashes mid-execution (OOM / SIGKILL), the
    # finally block that cleans up temp parquet files never runs.  Daily
    # sweep deletes feed-named temp files older than the configured age,
    # while skipping any file that belongs to a still-inflight execution.
    try:
        from core.feed_engine import sweep_orphan_feed_temp_files as _sweep_orphans
        try:
            from core.config import _db_setting_or as _dbget2
            _orphan_age = float(_dbget2("feed_generation.orphan_temp_file_max_age_hours", 24))
            _orphan_cron = str(_dbget2("feed_generation.orphan_temp_file_cron", "0 2 * * *"))
        except Exception:
            _orphan_age = 24.0
            _orphan_cron = "0 2 * * *"

        def _run_orphan_sweep():
            try:
                if not _db():
                    return
                # Leader-gated — sweeping the shared NFS twice from
                # parallel pods is wasteful.
                try:
                    if not _this_process_runs_apscheduler():
                        return
                except Exception:
                    pass
                counters = _sweep_orphans(max_age_hours=_orphan_age)
                if counters.get("deleted", 0):
                    logger.info("[feed_engine] orphan sweep: %s", counters)
            except Exception as exc:
                logger.warning("[feed_engine] orphan sweep failed: %s", exc)

        from core.cron_compat import crontab_trigger as _CT_orph
        _scheduler.add_job(
            func=_run_orphan_sweep,
            trigger=_CT_orph(_orphan_cron),
            id="__feed_orphan_temp_sweep__", jobstore="daemon",
            name="Feed orphan temp file sweep",
            replace_existing=True,
            misfire_grace_time=3600,
        )
        logger.info("Registered Feed orphan-temp sweeper (cron: %s, age>%dh)",
                     _orphan_cron, _orphan_age)
    except Exception as _orphe:
        logger.warning("Could not register orphan-temp sweeper: %s", _orphe)

    # Phase 131 deep-dive #13: in-flight API-key revocation sweep.
    # Catches keys revoked on another pod (immediate-cancel hook only
    # runs on the pod that handled the DELETE).  Cheap — empty registry
    # exits in microseconds, populated registry does one DB lookup per
    # active execution.  Disabled when the interval is <=0.
    try:
        _akr_interval = 0
        try:
            from core.config import _db_setting_or
            _akr_interval = int(_db_setting_or("auth.api_key_revocation_sweep_seconds", 30))
        except Exception:
            _akr_interval = 30

        if _akr_interval > 0:
            from apscheduler.triggers.interval import IntervalTrigger as _IT_akr

            def _run_api_key_revocation_sweep():
                try:
                    from core.api_key_lifecycle import sweep_revoked_api_keys
                    counters = sweep_revoked_api_keys(_db())
                    if counters.get("cancelled"):
                        logger.info("[api_key_lifecycle] sweep: %s", counters)
                except Exception as exc:
                    logger.debug("[api_key_lifecycle] sweep failed: %s", exc)

            _scheduler.add_job(
                func=_run_api_key_revocation_sweep,
                trigger=_IT_akr(seconds=_akr_interval),
                id="__api_key_revocation_sweep__", jobstore="daemon",
                name="API key revocation sweep",
                replace_existing=True,
                misfire_grace_time=_akr_interval * 2,
            )
            logger.info("Registered API-key revocation sweeper (interval: %ds)",
                         _akr_interval)
    except Exception as _akre:
        logger.warning("Could not register api-key revocation sweeper: %s", _akre)

    # Round 18 — feed execution timeout sweeper.  Flips stuck
    # in_progress/running feed_executions to failed once they exceed
    # feed_generation.execution_timeout_seconds.  Runs every 60s so
    # the user sees the failure within 1 min of the timeout firing.
    try:
        from apscheduler.triggers.interval import IntervalTrigger as _IT_fto

        def _run_feed_timeout_sweep():
            try:
                from core.feed_timeout_sweeper import sweep_timed_out_executions
                counters = sweep_timed_out_executions(_db())
                if counters.get("timed_out"):
                    logger.info("[feed_timeout_sweeper] sweep: %s", counters)
            except Exception as exc:
                logger.debug("[feed_timeout_sweeper] sweep failed: %s", exc)

        _scheduler.add_job(
            func=_run_feed_timeout_sweep,
            trigger=_IT_fto(seconds=60),
            id="__feed_execution_timeout_sweep__", jobstore="daemon",
            name="Feed execution timeout sweep",
            replace_existing=True,
            misfire_grace_time=120,
        )
        logger.info("Registered feed-execution timeout sweeper (every 60s)")
    except Exception as _fts_exc:
        logger.warning("Could not register feed-execution timeout sweeper: %s", _fts_exc)

    # Phase 130/3: Feed SOD (start-of-day) task generator.
    # Creates one feed_runs row per active feed_config at the configured
    # cron time (default 00:00 UTC).  Gated behind feed_generation.sod_enabled;
    # production deploys keep the old behaviour until admin opts in.
    try:
        from core.config import feed_generation as _fg_cfg_sod
        if _fg_cfg_sod.sod_enabled:
            from core.cron_compat import crontab_trigger as _crontab_trigger_sod

            _scheduler.add_job(
                func=run_sod_generator_once,
                trigger=_crontab_trigger_sod(_fg_cfg_sod.sod_cron),
                id="__feed_sod_generator__", jobstore="daemon",
                name="Feed SOD task generator",
                replace_existing=True,
                misfire_grace_time=3600,
                # 2026-08-23 (Phase 4) — boot catch-up.  Daemon jobs live in
                # a MEMORY jobstore, so a restart spanning the SOD cron time
                # silently skipped the whole day: no rows, /feeds/today
                # empty, indistinguishable from healthy.  run_for_date() is
                # idempotent per (feed, business_date) — one catch-up fire
                # shortly after boot costs nothing on a day already
                # generated and rescues a missed midnight.
                next_run_time=datetime.now(timezone.utc) + timedelta(seconds=120),
            )
            logger.info("Registered Feed SOD task generator (cron: %s, "
                        "boot catch-up in 120s)", _fg_cfg_sod.sod_cron)
            # Phase 4 (2026-08-23) — producer-without-consumer check.
            # SOD creates pending rows; for CRON feeds the cron path
            # now claims them, but cron-LESS feeds are executed ONLY by
            # the queue worker.  sod_enabled=true with no queue worker
            # anywhere left those rows pending forever, silently.
            # 2026-11-02: the consumer is a responsibility, not a flag -- this
            # process's own queue worker, or a feed-worker pod that ticks.
            from core import responsibilities as _resp_sod
            if not _resp_sod.owns(_resp_sod.FEED_RUNS):
                try:
                    from core.feed.health import probe_queue_consumer
                    _consumer = probe_queue_consumer(_fg_cfg_sod, db=_db_manager)
                except Exception:                              # noqa: BLE001
                    _consumer = None
                if _consumer is not None and _consumer.determined and not _consumer.present:
                    logger.warning(
                        "feed_generation.sod_enabled=true but no feed-worker pod has "
                        "ticked (%s) -- SOD rows will sit pending until one runs. This "
                        "process does not run feeds: %s",
                        _consumer.reason, _resp_sod.why_not(_resp_sod.FEED_RUNS))
    except Exception as _sce:
        logger.warning("Could not register Feed SOD task generator: %s", _sce)

    # ─── 2026-09-15: producer-without-consumer, for EVERY producer ──────
    # The check above lives inside ``if sod_enabled:`` -- a branch that is
    # also off by default -- so in the default deployment neither the
    # producer check nor the producer it checks was running, and the
    # OTHER producers were never covered at all.  A backfill
    # (POST /api/feeds/{id}/backfill), an external trigger and a manual
    # re-run each insert pending feed_runs rows too.  This fires on the
    # only evidence that matters: rows are waiting and nothing polls.
    # It is a bootstrap-time observation, so it reports the state it
    # finds rather than gating anything -- the row-creating routes carry
    # their own warning at the moment they create work.
    try:
        from core.feed.health import pending_work_with_no_consumer
        _pc = pending_work_with_no_consumer(db=_db_manager)
        if _pc.get("stalled"):
            _n = _pc.get("pending_runs")
            _approx = "" if _pc.get("pending_runs_exact") else "+"
            logger.warning(
                "%s%s feed run(s) are PENDING and nothing on this estate "
                "will execute them — %s  (backfills, SOD rows and external "
                "triggers all land here.)",
                _n, _approx, (_pc.get("consumer") or {}).get("reason"))
        elif not (_pc.get("consumer") or {}).get("determined", True):
            logger.warning(
                "Could not determine whether any feed queue worker exists: "
                "%s", (_pc.get("consumer") or {}).get("reason"))
    except Exception as _pce:
        logger.debug("producer/consumer check skipped: %s", _pce)

    # ─── Phase 4 (2026-08-23): feed-schedule reconciler ──────────────────
    # feed_configs is the ONE truth for per-feed crons.  The API's
    # _register_schedule only reaches the LOCAL pod's scheduler and swallows
    # failures — on a non-leader pod (or scheduler.mode=external) a feed's
    # schedule was accepted with 200 and NEVER fired; disabling on such a
    # pod left the persistent job firing forever.  This sweep runs on
    # whichever pod owns the scheduler and converges jobs to DB truth.
    # Gated only on feed_generation.enabled — it must run even when SOD /
    # queue worker are off, because per-feed crons predate both.
    try:
        from core.config import feed_generation as _fg_cfg_fsr
        if _fg_cfg_fsr.enabled:
            def _run_feed_schedule_reconcile():
                try:
                    if not _db() or not _scheduler:
                        return
                    from core.feed.schedule_reconciler import (
                        reconcile_feed_schedule_jobs,
                    )
                    c = reconcile_feed_schedule_jobs(_db(), _scheduler)
                    if c["added"] or c["updated"] or c["removed"] or c["invalid"] or c["errors"]:
                        logger.info("[feed_schedule_reconciler] %s", c)
                except Exception as exc:
                    logger.warning("[feed_schedule_reconciler] pass failed: %s", exc)

            _fsr_interval = int(_fg_cfg_fsr.schedule_reconcile_interval_seconds)
            _scheduler.add_job(
                func=_run_feed_schedule_reconcile,
                trigger=_IT(seconds=_fsr_interval),
                id="__feed_schedule_reconcile__", jobstore="daemon",
                name="Feed schedule reconciler (DB truth -> APScheduler)",
                replace_existing=True,
                misfire_grace_time=_fsr_interval,
                # First pass shortly after boot so a schedule created while
                # this pod was down (or on another pod) fires today, not
                # after the first interval elapses.
                next_run_time=datetime.now(timezone.utc) + timedelta(seconds=15),
            )
            logger.info("Registered feed-schedule reconciler (every %ds)",
                        _fsr_interval)
    except Exception as _fsre:
        logger.warning("Could not register feed-schedule reconciler: %s", _fsre)

    # Phase 83A: Cleanup stale async business report jobs — runs every hour
    try:
        def _cleanup_br_jobs():
            try:
                from api.business_reports_api import _br_cleanup_stale
                _br_cleanup_stale()
            except Exception as exc:
                logger.debug("BR async job cleanup error: %s", exc)

        _scheduler.add_job(
            func=_cleanup_br_jobs,
            trigger=_IT(hours=1),
            id="__br_async_cleanup__", jobstore="daemon",
            name="Business report async job cleanup",
            replace_existing=True,
            misfire_grace_time=600,
        )
        logger.info("Registered business report async job cleanup (every 1 h)")
    except Exception as _br_ce:
        logger.warning("Could not register BR async cleanup job: %s", _br_ce)

    # Phase 98-I: Published Views cache safety-net — runs every 2 hours
    # Deletes expired cache files whose TTL has elapsed (in case Kafka events
    # were missed). Also logs "safety_net" trigger for admin visibility.
    try:
        def _pv_cache_safety_net():
            try:
                from pathlib import Path as _Path
                from core.config import published_views as _pv_cfg
                import time as _t

                cache_dir_str = _pv_cfg.cache_dir
                cache_dir = _Path(cache_dir_str) if not _Path(cache_dir_str).is_absolute() else _Path(cache_dir_str)
                if not cache_dir.exists():
                    return
                deleted = 0
                for pf in cache_dir.glob("v*.parquet"):
                    try:
                        # Extract view_id from filename v{id}_{hash}.parquet
                        stem = pf.stem  # e.g. "v42_abc123"
                        parts = stem.split("_", 1)
                        view_id_str = parts[0].lstrip("v")
                        view_id = int(view_id_str)
                        age = _t.time() - pf.stat().st_mtime
                        # Use a conservative 24h default if we can't look up per-view TTL
                        ttl = 86400
                        try:
                            pv = db_manager.get_published_view(view_id)
                            if pv:
                                ttl = pv.get("cache_ttl_seconds") or 86400
                        except Exception:
                            pass
                        if age > ttl:
                            pf.unlink(missing_ok=True)
                            meta = pf.with_suffix(".meta.json")
                            if meta.exists():
                                meta.unlink(missing_ok=True)
                            # 2026-08-08 — the DatasetManifest sidecar is
                            # ``<parquet>.manifest.json``, not ``.meta.json``;
                            # it was never swept here, so every expired entry
                            # left its truth file behind.  Those orphans grow
                            # without bound AND sit exactly where the next
                            # entry with the same cache key lands.
                            from api.published_views.envelope import (
                                manifest_sidecar_path as _msp,
                            )
                            _msp(pf).unlink(missing_ok=True)
                            deleted += 1
                    except Exception:
                        pass
                if deleted:
                    logger.info("[pv-safety-net] Deleted %d expired cache file(s)", deleted)
            except Exception as exc:
                logger.debug("PV cache safety-net error: %s", exc)

        _scheduler.add_job(
            func=_pv_cache_safety_net,
            trigger=_IT(hours=2),
            id="__pv_cache_safety_net__", jobstore="daemon",
            name="Published Views cache safety-net",
            replace_existing=True,
            misfire_grace_time=600,
        )
        logger.info("Registered Published Views cache safety-net job (every 2 h)")
    except Exception as _pv_sn_exc:
        logger.warning("Could not register PV cache safety-net job: %s", _pv_sn_exc)

    # Published Views cache LRU eviction — enforces max_cache_size_mb
    try:
        # Module-level so it is directly testable (see
        # tests/test_published_views_bulk_hardening_2026_08_08.py); the job
        # registration below is the only production caller.
        _pv_cache_lru_eviction = pv_cache_lru_eviction

        _eviction_hours = 4
        try:
            from core.config import published_views as _pv_cfg_sched
            _eviction_hours = _pv_cfg_sched.cache_eviction_interval_hours
        except Exception as _cfg_exc:
            logger.warning("Could not read cache_eviction_interval_hours, using default %dh: %s", _eviction_hours, _cfg_exc)
        _scheduler.add_job(
            func=_pv_cache_lru_eviction,
            trigger=_IT(hours=_eviction_hours),
            id="__pv_cache_lru_eviction__", jobstore="daemon",
            name="Published Views cache LRU eviction",
            replace_existing=True,
            misfire_grace_time=600,
        )
        logger.info("Registered Published Views cache LRU eviction job (every %d h)", _eviction_hours)
    except Exception as _pv_ev_exc:
        logger.warning("Could not register PV cache LRU eviction job: %s", _pv_ev_exc)

    # Phase 83C: Scheduler lock heartbeat — runs every 30 seconds
    try:
        if _scheduler_worker_id:
            def _scheduler_heartbeat():
                try:
                    db_manager.heartbeat_scheduler_lock(_scheduler_worker_id)
                except Exception as exc:
                    logger.debug("Scheduler heartbeat error: %s", exc)

            from apscheduler.triggers.interval import IntervalTrigger as _HIT
            _scheduler.add_job(
                func=_scheduler_heartbeat,
                trigger=_HIT(seconds=30),
                id="__scheduler_heartbeat__", jobstore="daemon",
                name="Scheduler lock heartbeat",
                replace_existing=True,
                misfire_grace_time=10,
            )
            logger.info("Registered scheduler lock heartbeat (every 30 s)")
    except Exception as _hb_ce:
        logger.warning("Could not register scheduler heartbeat job: %s", _hb_ce)

    # Phase 123: Automated database backup
    try:
        from core.config import backup as _bk_cfg
        if _bk_cfg.enabled:
            def _scheduled_backup():
                try:
                    from core.backup import perform_backup
                    from core.config import database as _db_cfg_bk
                    perform_backup(
                        db_url=_db_cfg_bk.db_url,
                        backup_dir=_bk_cfg.backup_dir,
                        retention_count=_bk_cfg.retention_count,
                    )
                except Exception as exc:
                    logger.error("Scheduled backup failed: %s", exc, exc_info=True)

            _scheduler.add_job(
                func=_scheduled_backup,
                trigger=_IT(hours=int(_bk_cfg.schedule_hours)),
                id="__db_backup__", jobstore="daemon",
                name="Automated database backup",
                replace_existing=True,
                misfire_grace_time=3600,
            )
            logger.info("Registered automated database backup (every %d h)", _bk_cfg.schedule_hours)
    except Exception as _bk_exc:
        logger.warning("Could not register backup job: %s", _bk_exc)

    # After every job is registered, honour the admin's per-job enable
    # state from config (jobs.<job_id>.enabled).  Jobs whose enabled=False
    # are paused immediately so they never tick until admin resumes them.
    try:
        from core.job_control import apply_initial_state as _apply_initial_state
        _apply_initial_state(_scheduler)
    except Exception as _jc_exc:
        logger.warning("Could not apply job_control initial state: %s", _jc_exc)

    # 2026-09-28 -- THE ONE PLACE the "APScheduler started here" event is
    # raised, on the boot-time start and on the lock-retry start alike (the
    # retry thread calls this same function).  The daemon registry queues the
    # registrations that found no scheduler at boot and the singletons it
    # deferred; main.py's hybrid boot queues its inline daemon block.
    _fire_started_hooks()

    return _scheduler


def init_job_worker_scheduler(db_manager) -> bool:
    """THE JOB-WORKER TIER'S daemon host (2026-11-02, core/responsibilities.py).

    A job-worker pod hosts the EXECUTING daemons (DQ rules, pipelines,
    DataFlow, reconciliation, custom jobs, value-list fills, mirrors,
    subscription deliveries -- ``daemon_registry.DAEMON_HOME`` says which).
    Several of them are singletons, so the tier has its own election: lock
    row ``JOB_WORKER_LOCK_ID`` (never contended with the scheduler tier's row
    1), and the leader runs ONE in-memory APScheduler for those jobs -- no
    persistent jobstore, no user schedules, no SOD, none of the scheduler
    tier's inline jobs.  It is published through the same module globals
    (``_scheduler``, ``_scheduler_worker_id``, ``_db_manager``) because every
    singleton gate (``daemon_registry._worker_holds_singleton_role``), every
    ``get_daemon_scheduler`` registration and the ledger listener read those,
    and the job-worker leader IS the single runner of ITS daemons.  A
    non-leader retries every ``scheduler.lock_retry_seconds`` and registers
    late, exactly like the scheduler tier.  Returns True when APScheduler is
    running in this process.
    """
    global _db_manager, _scheduler, _scheduler_worker_id, _lock_id, _release_on_exit_registered
    from core import responsibilities as _resp
    if not _resp.owns(_resp.BACKGROUND_EXECUTION):
        logger.error("init_job_worker_scheduler called in a process that is not a job-worker (%s) -- refused",
                     _resp.current())
        return False
    if _scheduler is not None:
        return True
    _db_manager = db_manager
    _lock_id = JOB_WORKER_LOCK_ID
    candidate = f"{socket.gethostname()}:{os.getpid()}"
    if not db_manager.try_acquire_scheduler_lock(candidate, lock_id=JOB_WORKER_LOCK_ID):
        logger.warning("job-worker daemon host: another job-worker holds the tier's lock (this "
                       "process: %s) -- retrying every %.0fs; the task-queue loop runs meanwhile",
                       candidate, _lock_retry_interval_seconds())
        _scheduler_worker_id = None
        _start_job_worker_lock_retry(db_manager)
        return False
    _scheduler_worker_id = candidate
    logger.info("job-worker daemon host: tier lock (row %d) acquired by %s", JOB_WORKER_LOCK_ID, candidate)
    if not _release_on_exit_registered:
        atexit.register(_release_lock_on_exit)
        _release_on_exit_registered = True
    from apscheduler.executors.pool import ThreadPoolExecutor as APSThreadPool
    from apscheduler.jobstores.memory import MemoryJobStore
    from apscheduler.schedulers.background import BackgroundScheduler
    _scheduler = BackgroundScheduler(
        jobstores={"default": MemoryJobStore(), "daemon": MemoryJobStore()},
        executors={"default": APSThreadPool(max_workers=_executor_max_workers())},
        job_defaults={"coalesce": True, "max_instances": 1, "misfire_grace_time": 30},
        timezone="UTC",
    )
    _scheduler.start()
    try:
        from core.background_job_contract import attach_scheduler_listener
        attach_scheduler_listener(_scheduler)
    except Exception as exc:                                  # noqa: BLE001 -- the ledger, not the host
        logger.warning("job-worker daemon host: ledger listener not attached: %s", exc)

    def _job_worker_heartbeat():
        try:
            db_manager.heartbeat_scheduler_lock(_scheduler_worker_id, lock_id=JOB_WORKER_LOCK_ID)
        except Exception as exc:                              # noqa: BLE001
            logger.debug("job-worker lock heartbeat error: %s", exc)

    from apscheduler.triggers.interval import IntervalTrigger as _HIT
    _scheduler.add_job(func=_job_worker_heartbeat, trigger=_HIT(seconds=30),
                       id="__job_worker_lock_heartbeat__", jobstore="daemon",
                       name="Job-worker lock heartbeat", replace_existing=True)
    try:
        from core.daemon_registry import _queue_drain_on_scheduler_start
        _queue_drain_on_scheduler_start()
    except Exception as exc:                                  # noqa: BLE001
        logger.debug("job-worker: deferred-singleton drain hook not armed: %s", exc)
    logger.info("job-worker daemon host: APScheduler (in-memory) started")
    return True


_jw_lock_retry_thread = None


def _start_job_worker_lock_retry(db_manager) -> None:
    """Keep re-attempting the job-worker tier's lock until this pod wins it
    (the previous leader stopped, or its heartbeat went stale)."""
    global _jw_lock_retry_thread

    def _retry_loop():
        interval = _lock_retry_interval_seconds()
        while True:
            time.sleep(interval)
            if _scheduler is not None:
                return
            try:
                if init_job_worker_scheduler(db_manager):
                    logger.info("job-worker daemon host started on retry -- the previous leader's "
                                "lock was released or went stale")
                    return
            except Exception as exc:                          # noqa: BLE001
                logger.warning("job-worker lock-retry attempt failed: %s", exc)

    with _lock_retry_lock:
        if _jw_lock_retry_thread is not None and _jw_lock_retry_thread.is_alive():
            return
        _jw_lock_retry_thread = threading.Thread(target=_retry_loop, name="job-worker-lock-retry", daemon=True)
        _jw_lock_retry_thread.start()


_db_manager  = None


def _db():
    """THE db handle this module reads (2026-10-08): what ``init_scheduler`` bound
    here, else the process-wide manager.  One rule, in
    ``core.database.resolve_db_manager``; never read the global bare -- a
    route on a pod that never started this daemon found None (the class
    found live in the Iceberg watcher's settings)."""
    from core.database import resolve_db_manager
    return resolve_db_manager(_db_manager)


_scheduler   = None

# Pluggable broadcast function — set via set_broadcast_fn() before init.
# In embedded mode:  wraps asyncio.run_coroutine_threadsafe(ws_manager.broadcast)
# In external mode:  wraps notification_queue.enqueue() (DB-backed queue)
_broadcast_fn: Optional[Callable[[dict], None]] = None

# NOTE (2026-08-04 merge): the audit branch carried its own copy of the
# scheduler-lock retry (module state + _start_lock_retry) because the same
# defect was found independently by two agents.  Master's implementation --
# below, near init_scheduler -- is kept: it reads the interval from
# `scheduler.lock_retry_seconds` instead of hardcoding 20.0, and owns its own
# lock object.  The duplicate was removed rather than left in place: two
# defs of one name in a module is not a merge artifact you can leave, since
# the second silently wins and the first reads as live code.


def get_scheduler():
    """Return the APScheduler BackgroundScheduler instance (or None if not initialized)."""
    return _scheduler


def feed_dep_broadcast(kind: str, payload: dict) -> None:
    """The dependency poller's and the WAIT escalation's broadcast seam
    (2026-09-27).

    Both call ``broadcast_fn(kind, payload)``; ``_broadcast_fn`` takes ONE
    dict carrying a ``username`` (``broadcast_to_user``).  The mismatch
    raised inside the callers' own ``try`` for as long as both existed, so
    no ``feed_dep_*`` event ever reached a WebSocket client -- the
    escalation "broadcast" the brief found unconsumed could not even be
    sent.

    2026-10-07 -- ADDRESSING.  A payload the producer already addressed
    (``audience``, stamped by ``core.feed.event_audience.address``) is
    delivered as addressed.  One that is not is addressed HERE, through the
    same one function (``feed_event_audience``: the owner and the owner
    group -- it used to be the owner alone while the run's own events went
    to the actor).  An empty audience is dropped by ``_broadcast_fn``
    itself; nothing is ever sent unaddressed.
    """
    if _broadcast_fn is None:
        return
    msg = {"type": kind, **dict(payload or {})}
    from core.feed.event_audience import (
        AUDIENCE_KEY, address, feed_event_audience)
    if AUDIENCE_KEY not in msg:
        fid = msg.get("feed_config_id")
        try:
            if not fid and msg.get("feed_run_id") and _db() is not None:
                run = _db().get_feed_run(int(msg["feed_run_id"]))
                fid = (run or {}).get("feed_config_id")
        except Exception as exc:
            logger.debug("[scheduler] feed_dep broadcast run lookup failed: %s", exc)
        # ``run_id=`` the payload's run (None when it names none): the
        # person who ASKED for a backfilled row hears its release.
        address(msg, feed_event_audience(_db(), fid, None,
                                         run_id=msg.get("feed_run_id")))
    _broadcast_fn(msg)


def feed_sla_breach_notify(run_row: dict, breach_seconds) -> None:
    """The feed SLA tracker's breach notification (Phase 4, 2026-08-23;
    module level since 2026-10-07 so it is the one testable producer).

    The module docstring promised notifications but production always
    constructed the tracker with notify_fn=None -- a breach flipped a DB
    flag and told NO ONE.  It routes through the same broadcast every
    other feed event uses.  2026-10-07: it carried NO address, so the
    embedded scheduler dropped it ("no user in payload") and the outbox
    drain on an external-scheduler deployment sent it to EVERY browser;
    it is addressed through ``feed_event_audience`` now.
    """
    from core.feed.event_audience import address, feed_event_audience
    try:
        fid = run_row.get("feed_config_id")
        _broadcast(address({
            "type": "feed_sla_breach",
            "feed_run_id": run_row.get("id"),
            "feed_config_id": fid,
            "business_date": str(run_row.get("business_date") or ""),
            "breach_seconds": int(breach_seconds),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }, feed_event_audience(_db(), fid, None, run=run_row)))
    except Exception as _nx:
        logger.debug("[sla_tracker] breach broadcast failed: %s", _nx)


def set_broadcast_fn(fn: Callable[[dict], None]):
    """Set the function used to broadcast notifications from scheduled jobs.

    Must be called before ``init_scheduler()`` so that system jobs and
    user-scheduled jobs can send WebSocket-style notifications.
    """
    global _broadcast_fn
    _broadcast_fn = fn


def _executor_max_workers() -> int:
    """Executor thread-pool width — ``scheduler.job_pool_size`` (default 20).

    2026-08-09 (metadata-scale audit finding 4): the executor hardcoded
    ``max_workers=4`` while the module docstring claimed 20 and the config
    key ``job_pool_size`` (default 20, reported in the worker heartbeat)
    drove nothing.  5,000 jobs due at 06:00 at ~30 s each drained in ~10
    hours on 4 threads.  One knob now rules all three: config, heartbeat
    and the actual pool.  Fail-open to the documented default of 20 —
    never let a config hiccup stop the scheduler from starting.  Floor 1.
    This changes only how many jobs RUN CONCURRENTLY, never when they fire.
    """
    try:
        from core.config import scheduler as _cfg
        return max(1, int(getattr(_cfg, "job_pool_size", 20)))
    except Exception:
        return 20


def _load_all_active_schedules(db_manager) -> list:
    """EVERY active schedule, paginated — bootstrap must never truncate.

    2026-08-09 (metadata-scale audit finding 4): bootstrap called
    ``list_schedules(active_only=True, limit=1000)`` — schedule #1,001 was
    SILENTLY never registered: it simply never fired, with no error
    anywhere.  A silent cap on correctness is a gate failing quietly.
    This loop pages until a short page says the table is exhausted — no
    cap at all.  The only guard is against a pathological DB stub that
    ignores ``offset`` (which would loop forever): a page that yields no
    NEW schedule ids aborts the loop with a LOUD error, never silently.
    """
    out: list = []
    seen_ids: set = set()
    offset, batch = 0, 500
    while True:
        page = db_manager.list_schedules(active_only=True,
                                         limit=batch, offset=offset) or []
        new = [s for s in page if s.get("id") not in seen_ids]
        if page and not new:
            logger.error(
                "Schedule bootstrap pagination made no progress at offset %d "
                "(list_schedules ignoring offset?) — aborting the scan with "
                "%d schedule(s) loaded. Schedules beyond this point are NOT "
                "registered; fix list_schedules pagination.",
                offset, len(out))
            break
        for s in new:
            seen_ids.add(s.get("id"))
            out.append(s)
        if len(page) < batch:
            break
        offset += batch
    return out


_lock_retry_thread = None
_lock_retry_lock = threading.Lock()


def shutdown_scheduler():
    # 2026-10-14 -- the queue worker this process hosts hands its unfinished
    # runs back BEFORE the scheduler stops (core/feed/run_lifecycle.py): every
    # deploy used to leave the run in flight "running" for the hourly reaper.
    try:
        from core.feed.queue_worker import peek_shared_queue_worker
        from core.feed.run_lifecycle import hand_back_on_exit
        _qw = peek_shared_queue_worker()
        _hb_db = _db()
        if _qw is not None and _hb_db is not None:
            hand_back_on_exit(_qw, _hb_db)
    except Exception as exc:                                # noqa: BLE001
        logger.error("[scheduler] hand-back at shutdown failed: %s", exc)
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("QueryScheduler stopped")


def pause_scheduler():
    """Pause all scheduled jobs (stops firing triggers). Running jobs finish normally."""
    if _scheduler and _scheduler.running:
        _scheduler.pause()
        logger.info("QueryScheduler paused — no new jobs will fire")
        return True
    return False


def resume_scheduler():
    """Resume firing scheduled jobs."""
    if _scheduler:
        _scheduler.resume()
        logger.info("QueryScheduler resumed")
        return True
    return False


# 2026-08-09 — there were TWO module-level ``get_scheduler_status`` defs.
# This one came first and was therefore DEAD: the second (further down, near
# ``get_next_run``) rebound the name at import time and is what every caller
# has actually been getting.  The two returned DIFFERENT shapes and the
# frontend consumes BOTH — SchedulerSection.tsx reads ``job_count`` (only the
# dead one emitted it, so the admin panel's "Jobs" stat card has been showing
# 0 via its ?? fallback) while SchedulesPage.tsx reads ``total_jobs`` (only
# the live one emits it).  The surviving definition below is now the union of
# both shapes, so neither consumer has to change.


def _aps_version() -> str:
    try:
        import apscheduler
        return apscheduler.__version__
    except Exception:
        return "unknown"


def _job_next_run(job):
    """next_run_time of an APScheduler job, or None.

    A job in a NOT-YET-STARTED scheduler is PENDING and accessing
    .next_run_time raises AttributeError (APScheduler 3.x) -- this
    took the status endpoint down with a 500 whenever one pending
    job existed.  One accessor, used by every reader."""
    return getattr(job, "next_run_time", None) if job is not None else None


def _bootstrap_schedules(schedules: list):
    """After restart, ensure all active schedules have a live APScheduler job."""
    for s in schedules:
        try:
            if s.get("apscheduler_job_id") and _scheduler.get_job(s["apscheduler_job_id"]):
                # Job already exists in jobstore — refresh next_run_at in DB
                job = _scheduler.get_job(s["apscheduler_job_id"])
                _next = _job_next_run(job)
                if _next:
                    _db().update_schedule(s["id"], next_run_at=_next)
            else:
                # Missing from jobstore (e.g. memory store) — re-add
                job_id = add_schedule(s)
                _db().update_schedule(s["id"], apscheduler_job_id=job_id)
        except Exception as e:
            logger.warning("Could not bootstrap schedule %s: %s", s["id"], e, exc_info=True)


# ── Public API called from schedules_api.py ───────────────────────────────────

def _user_schedule_misfire_grace() -> int:
    """Misfire grace for user schedules — see the _DEFAULTS note in
    core/config.py.  The scheduler-wide default of 30 s silently SKIPPED
    a user's daily download when a restart overlapped the fire time."""
    try:
        from core.config import scheduler as _sched_cfg
        return int(_sched_cfg.user_schedule_misfire_grace_seconds)
    except Exception:
        return 3600


class SchedulerUnavailable(RuntimeError):
    """No scheduler in THIS process, so no job can be registered here."""


def can_register_jobs() -> bool:
    """True when this process holds a scheduler that can accept jobs.

    False on an api-role pod (main.py: "role=api means no background
    daemons, full stop") and on a replica that lost leader election --
    both keep serving /api/schedules while owning no scheduler.  Ask
    this BEFORE persisting anything: see add_schedule.
    """
    return _scheduler is not None


def add_schedule(schedule_record: dict) -> str:
    """Register a new APScheduler job. Returns the APS job_id."""
    if _scheduler is None:
        # 2026-08-31 -- remove_schedule(), the sibling directly below,
        # has always guarded this; add_schedule never did.  The None
        # surfaced as "'NoneType' object has no attribute 'add_job'"
        # wrapped in a 500 raised AFTER the caller's row was written.
        raise SchedulerUnavailable(
            "no APScheduler in this process: the pod role forbids "
            "background daemons and scheduler.mode is not 'external'")
    job_id  = f"qs_{schedule_record['id']}_{uuid.uuid4().hex[:6]}"
    trigger = _build_trigger(schedule_record["trigger_config"])
    _scheduler.add_job(
        func=_run_scheduled_job,
        trigger=trigger,
        id=job_id,
        args=[schedule_record["id"]],
        name=schedule_record.get("name", job_id),
        replace_existing=True,
        misfire_grace_time=_user_schedule_misfire_grace(),
    )
    job = _scheduler.get_job(job_id)
    # getattr: a job added to a not-yet-started scheduler is PENDING and
    # accessing .next_run_time raises AttributeError (APScheduler 3.x).
    # The registration itself succeeded -- don't turn a missing preview
    # timestamp into a 500 on the create endpoint.
    _next = _job_next_run(job)
    if _next:
        _db().update_schedule(schedule_record["id"], next_run_at=_next)
    return job_id


def remove_schedule(job_id: str):
    if _scheduler and job_id and _scheduler.get_job(job_id):
        _scheduler.remove_job(job_id)


def pause_schedule(job_id: str):
    if _scheduler and job_id:
        _scheduler.pause_job(job_id)


def resume_schedule(job_id: str):
    if _scheduler and job_id:
        _scheduler.resume_job(job_id)
        return _job_next_run(_scheduler.get_job(job_id))


def run_now(schedule_id: int):
    """Submit an immediate (out-of-schedule) run without affecting the trigger.

    2026-08-23 (Phase 4): passes ``force=True`` so a PAUSED schedule still
    runs.  Before, Run-Now on a paused schedule returned 200 "Triggered",
    the job body hit the ``is_active`` gate and silently returned — no run,
    no error, and the UI's live chip stayed "Running" forever.  An explicit
    user click IS the authorization to run; the gate remains for
    trigger-fired runs (it protects against a row deactivated between fire
    and load)."""
    try:
        from core.worker_pool import get_pool, WorkType
        get_pool().submit_sync(WorkType.SCHEDULED, _run_scheduled_job, schedule_id,
                               username="scheduler", force=True)
    except RuntimeError:
        _rpt_executor().submit(_run_scheduled_job, schedule_id, force=True)


def get_next_run(job_id: str) -> Optional[datetime]:
    if not _scheduler or not job_id:
        return None
    return _job_next_run(_scheduler.get_job(job_id))


def get_scheduler_status() -> Dict[str, Any]:
    """Scheduler state for the admin panel + /control/status.

    Returns the UNION of the two shapes this module used to define (see the
    tombstone above): ``running``/``total_jobs``/``jobs[].next_run_time`` for
    SchedulesPage + scheduler_worker, and ``initialized``/``paused``/
    ``job_count``/``jobs[].next_run``/``jobs[].paused`` for the admin panel.
    """
    if not _scheduler:
        return {"running": False, "initialized": False, "paused": False,
                "total_jobs": 0, "job_count": 0, "jobs": []}
    jobs = _scheduler.get_jobs()
    # APScheduler 3.x: scheduler.state == STATE_PAUSED (2)
    try:
        from apscheduler.schedulers.base import STATE_PAUSED
        paused = _scheduler.state == STATE_PAUSED
    except Exception:
        paused = False
    return {
        "running": _scheduler.running,
        "initialized": True,
        "paused": paused,
        "total_jobs": len(jobs),
        "job_count": len(jobs),
        "jobs": [
            {
                "id": j.id,
                "name": j.name,
                "next_run_time": _nr.isoformat() if _nr else None,
                "next_run": _nr.isoformat() if _nr else None,
                "paused": _nr is None,
            }
            for j in jobs
            for _nr in (_job_next_run(j),)
        ],
    }


# ── Trigger builder ───────────────────────────────────────────────────────────

def _build_trigger(trigger_config: dict):
    from apscheduler.triggers.cron     import CronTrigger
    from apscheduler.triggers.interval import IntervalTrigger

    ttype = trigger_config.get("type")
    if ttype == "cron":
        expr = trigger_config.get("cron_expr", "")
        # Phase 4 (2026-08-23): STANDARD crontab weekday numerals.
        # CronTrigger.from_crontab passes day-of-week verbatim, but
        # APScheduler counts 0=Monday -- "0 8 * * 1-5" (documented in the
        # UI as weekdays) fired Tue-Sat.  core/cron_compat.py is the one
        # sanctioned constructor.
        from core.cron_compat import crontab_trigger
        return crontab_trigger(expr, timezone="UTC")
    elif ttype == "interval":
        # 2026-08-23 (Phase 4): WHITELIST the interval fields instead of
        # passing everything-but-"type" through.  A trigger_config that
        # carried a stray key (API callers can submit type="interval" WITH
        # cron_expr — exclude_none only strips None) raised TypeError at
        # registration, which the update endpoint used to swallow.  Also
        # refuse non-positive intervals: IntervalTrigger(minutes=-5) is a
        # misfire storm, not a schedule.
        kwargs = {k: int(trigger_config[k])
                  for k in ("hours", "minutes", "seconds")
                  if trigger_config.get(k) is not None}
        if not kwargs:
            raise ValueError(
                "Interval trigger needs at least one of hours/minutes/seconds")
        if any(v < 0 for v in kwargs.values()) or sum(kwargs.values()) <= 0:
            raise ValueError(
                f"Interval trigger must be a positive duration, got {kwargs}")
        return IntervalTrigger(**kwargs, timezone="UTC")
    raise ValueError(f"Unknown trigger type '{ttype}'. Use 'cron' or 'interval'.")


# ── Lazy executor reference (avoids circular import) ─────────────────────────

def _rpt_executor():
    from concurrent.futures import ThreadPoolExecutor
    # Use a module-level singleton so we don't create new pools each call
    if not hasattr(_rpt_executor, "_pool"):
        _rpt_executor._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="sched_run_now")
    return _rpt_executor._pool


# ── Broadcast helper (pluggable) ──────────────────────────────────────────────

def _broadcast(payload: dict):
    """Send a notification via the configured broadcast function.

    The actual delivery mechanism depends on how ``set_broadcast_fn()`` was called:
      • Embedded mode → direct WS broadcast
      • External mode → enqueue into ``pending_notifications`` table
    """
    if _broadcast_fn:
        try:
            _broadcast_fn(payload)
        except Exception as exc:
            logger.warning("scheduler broadcast failed: %s", exc, exc_info=True)


# ── Email helper ──────────────────────────────────────────────────────────────

def _send_schedule_email(
    schedule: dict,
    status: str,
    output_path: Optional[str] = None,
    row_count: Optional[int] = None,
    duration_seconds: Optional[float] = None,
    error_message: Optional[str] = None,
    run_at: Optional[str] = None,
) -> None:
    """Send email notification for a scheduled job if addresses are configured."""
    raw_emails = (schedule.get("notify_emails") or "").strip()
    if not raw_emails:
        return

    to_addresses = [e.strip() for e in raw_emails.split(",") if e.strip()]
    if not to_addresses:
        return

    try:
        from core.email_service import send_email, build_schedule_completion_email, is_email_enabled
        if not is_email_enabled():
            return
        subject, html = build_schedule_completion_email(
            schedule_name=schedule.get("name", "Unknown"),
            status=status,
            output_file=output_path,
            row_count=row_count,
            duration_seconds=duration_seconds,
            error_message=error_message,
            run_at=run_at,
        )
        send_email(to_addresses, subject, html)
    except Exception as exc:
        logger.warning("[scheduler] Email notification failed: %s", exc, exc_info=True)


# ── Webhook helper ─────────────────────────────────────────────────────────────

def _send_schedule_webhook(
    schedule: dict,
    status: str,
    output_path: Optional[str] = None,
    row_count: Optional[int] = None,
    duration_seconds: Optional[float] = None,
    error_message: Optional[str] = None,
    run_at: Optional[str] = None,
) -> None:
    """Fire webhook notification for a scheduled job if a webhook URL is configured."""
    url = (schedule.get("notify_webhook") or "").strip()
    if not url:
        return
    try:
        from core.webhook_service import fire_webhook
        fire_webhook(
            webhook_url=url,
            schedule_name=schedule.get("name", "Unknown"),
            status=status,
            output_file=output_path,
            row_count=row_count,
            duration_seconds=duration_seconds,
            error_message=error_message,
            run_at=run_at,
        )
    except Exception as exc:
        logger.warning("[scheduler] Webhook notification failed: %s", exc, exc_info=True)


# ── Cloud delivery (Phase 23H, wired 2026-08-30) ─────────────────────────────

def _deliver_to_cloud(schedule: dict, execution_id: str,
                      artifact_path: str, filename: str) -> None:
    """Deliver a successful run's artifact to the schedule's cloud config.

    2026-08-30 — THIS IS THE MISSING CONSUMER.  ``save_cloud_delivery_config``
    / ``get_cloud_delivery_config`` (core/database.py) and their REST routes
    (api/enterprise_reports_api.py) shipped with Phase 23H, an operator could
    configure S3 delivery and get a 200 — and NOTHING ever read the row, so
    the delivery silently never happened.  A value stored and then discarded
    is a defect, not a gap.

    DECISION: WIRE s3 (the repo already owns working S3 upload machinery —
    ``core.s3_utilities.make_s3_client_for_conn`` reuses the connection's
    cached handler, whose region flows through the single
    ``resolve_s3_region`` chokepoint; ambient-credential uploads mirror the
    proven burst path in api/burst_api.py).  azure / gcs are REFUSED — there
    is no Azure/GCS upload machinery anywhere in this codebase, and a stub
    that records "delivered" would be exactly the burst-CSV-as-PDF bug next
    door.  The config API now rejects them at save time; a legacy row that
    predates that refusal records a FAILED delivery naming the unsupported
    provider — never a silent skip.

    FAILURE SEMANTICS (decided, not defaulted):
      * The RUN's recorded status stays "success".  By the time this runs the
        artifact exists, is registered in DownloadFile and is downloadable —
        flipping the run to "failed" over a delivery error would declare a
        working download broken.
      * The DELIVERY failure is NOT swallowed: a delivery_history row with
        status='failed' + the error is written, the error is logged at ERROR,
        and a WebSocket event is broadcast.  ``status='delivered'`` is written
        ONLY after ``upload_file`` returned — never for an upload that did
        not happen.
      * Exceptions never escape this function (the caller's outer handler
        would otherwise mark the run failed and email "failed").

    The uploaded object keeps the artifact's REAL suffix even when the
    schedule's filename template claims another (the default template says
    .csv while report sources produce .parquet) — the delivered format is
    recorded as what it IS, not what the template named.

    Credentials: the config row holds only ``connection_id`` (a reference).
    Error text is scrubbed of any secret-valued connection fields before it
    reaches the log or the stored delivery row.
    """
    schedule_id = schedule.get("id")
    name = schedule.get("name", f"schedule:{schedule_id}")
    try:
        cfg = _db().get_cloud_delivery_config(schedule_id)
    except Exception as exc:
        logger.error("[scheduler] Cloud delivery config lookup failed for "
                     "schedule %s: %s", schedule_id, exc, exc_info=True)
        return
    if not cfg or not cfg.get("is_enabled"):
        return

    provider = (cfg.get("provider") or "").strip().lower()
    bucket = (cfg.get("bucket") or "").strip()

    # Secret scrubber — connection secrets must never reach the log or the
    # stored delivery row.  Populated once the connection config is loaded.
    _secret_vals: list = []

    def _scrub(msg: str) -> str:
        for v in _secret_vals:
            if v and isinstance(v, str) and len(v) >= 6 and v in msg:
                msg = msg.replace(v, "***")
        return msg

    def _fail(destination: str, error: str, file_format: str = None) -> None:
        error = _scrub(str(error))[:2000]
        logger.error("[scheduler] Cloud delivery FAILED for schedule %s '%s' "
                     "(exec %s) → %s: %s",
                     schedule_id, name, execution_id[:8], destination or "?",
                     error)
        try:
            _db().record_delivery(
                delivery_type=provider or "s3", destination=destination,
                status="failed", schedule_id=schedule_id,
                execution_id=execution_id, file_format=file_format,
                error_message=error,
            )
        except Exception as rec_exc:
            logger.error("[scheduler] Could not record failed delivery for "
                         "schedule %s: %s", schedule_id, rec_exc, exc_info=True)
        _broadcast({
            "type":          "cloud_delivery_failed",
            "schedule_id":   schedule_id,
            "schedule_name": name,
            "execution_id":  execution_id,
            "error":         error,
            "timestamp":     datetime.now(timezone.utc).isoformat(),
        })

    try:
        if provider != "s3":
            _fail(bucket, f"provider '{provider}' is not supported — only "
                          "'s3' delivery is implemented; this config was "
                          "stored before the API started refusing it")
            return
        if not bucket:
            _fail("", "cloud delivery config has no bucket")
            return

        src = Path(artifact_path)
        if not src.exists():
            _fail(f"s3://{bucket}", f"artifact '{artifact_path}' missing at "
                                    "delivery time")
            return

        # Object key: prefix template + template-derived filename with the
        # artifact's REAL suffix (never claim .csv for a parquet file).
        now = datetime.now(timezone.utc)
        safe_name = name.replace(" ", "_")
        prefix = (cfg.get("prefix_template") or "scheduled/{name}/{date}/")
        prefix = (prefix
                  .replace("{name}", safe_name)
                  .replace("{report_name}", safe_name)
                  .replace("{date}", now.strftime("%Y%m%d"))
                  .replace("{execution_id}", execution_id))
        obj_name = Path(filename).stem + src.suffix.lower()

        upload_path = src
        fmt = src.suffix.lstrip(".").lower() or None
        _tmp_zip = None
        if cfg.get("zip_bundle"):
            import tempfile
            import zipfile
            _tmp_zip = Path(tempfile.gettempdir()) / f"qs_cd_{execution_id}.zip"
            with zipfile.ZipFile(_tmp_zip, "w",
                                 compression=zipfile.ZIP_DEFLATED) as zf:
                zf.write(src, arcname=obj_name)
            upload_path = _tmp_zip
            obj_name = Path(obj_name).stem + ".zip"
            fmt = "zip"

        key = prefix.strip("/") + "/" + obj_name if prefix.strip("/") else obj_name
        destination = f"s3://{bucket}/{key}"

        try:
            conn_id = cfg.get("connection_id")
            if conn_id:
                conn_raw = _db().get_connection_raw(conn_id)
                if not conn_raw:
                    _fail(destination, f"connection {conn_id} not found", fmt)
                    return
                _ccfg = conn_raw.get("config") or {}
                _secret_vals = [v for k, v in _ccfg.items()
                                if isinstance(v, str) and any(
                                    t in k.lower() for t in
                                    ("secret", "password", "token", "key"))]
                # Chokepoint client: cached handler, creds + SSL + region via
                # resolve_s3_region — never re-derived here.
                from core.s3_utilities import make_s3_client_for_conn
                s3 = make_s3_client_for_conn(conn_raw)
            else:
                # Ambient pod credentials — the proven burst-delivery path.
                import boto3
                from botocore.config import Config as BotoConfig
                from core.proxy_utils import get_boto_proxies
                _px = get_boto_proxies()
                s3 = boto3.client(
                    "s3", config=BotoConfig(proxies=_px) if _px else None)
            s3.upload_file(str(upload_path), bucket, key)
        except Exception as exc:
            _fail(destination, str(exc), fmt)
            return
        finally:
            if _tmp_zip is not None:
                _size = upload_path.stat().st_size if upload_path.exists() else None
                try:
                    _tmp_zip.unlink(missing_ok=True)
                except Exception as _ul_exc:
                    logger.debug("[scheduler] temp zip cleanup failed: %s", _ul_exc)
            else:
                _size = upload_path.stat().st_size

        _db().record_delivery(
            delivery_type="s3", destination=destination, status="delivered",
            schedule_id=schedule_id, execution_id=execution_id,
            file_format=fmt, file_size_bytes=_size,
        )
        logger.info("[scheduler] Cloud delivery for schedule %s '%s' → %s "
                    "(%s bytes)", schedule_id, name, destination, _size)
        _broadcast({
            "type":          "cloud_delivery_completed",
            "schedule_id":   schedule_id,
            "schedule_name": name,
            "execution_id":  execution_id,
            "destination":   destination,
            "timestamp":     datetime.now(timezone.utc).isoformat(),
        })
    except Exception as exc:
        # Belt-and-braces: a bug in delivery code must never escape into the
        # run's failure path (which would mark a produced run "failed").
        _fail(f"s3://{bucket}" if bucket else "", f"cloud delivery error: {exc}")


# ── Job body — runs inside APScheduler's thread pool ─────────────────────────

SCHEDULED_REPORT_TASK = "scheduled_report"


def _run_scheduled_job(schedule_id: int, cancel_event=None, force: bool = False):
    """THE registered function of every user schedule (APScheduler fires it;
    ``run_now`` submits it).  2026-11-02 (core/responsibilities.py): the
    scheduler pod DECIDES the fire and the job-worker tier EXECUTES it.  In a
    process that owns background execution (a job-worker pod, a standalone
    install) the run happens here (``_execute_scheduled_job``); anywhere else
    the fire is ONE ``task_queue`` row of type ``scheduled_report`` that a
    job-worker claims (executor_worker.py).  Kept under its old name so the
    persisted APScheduler job rows, which reference it, keep firing."""
    from core import responsibilities as _resp
    if _resp.owns(_resp.BACKGROUND_EXECUTION):
        return _execute_scheduled_job(schedule_id, cancel_event=cancel_event, force=force)
    return _enqueue_scheduled_job(schedule_id, force=force)


def _enqueue_scheduled_job(schedule_id: int, *, force: bool = False) -> dict:
    """The fire as a queue row for the job-worker tier.  Never executes."""
    from core import responsibilities as _resp
    from core.queue_backend import get_task_queue
    task_id = str(uuid.uuid4())
    get_task_queue().enqueue_task(
        task_id=task_id,
        task_type=SCHEDULED_REPORT_TASK,
        payload={"schedule_id": int(schedule_id), "force": bool(force),
                 "fired_by": f"{socket.gethostname()}:{os.getpid()}",
                 "fired_at": datetime.now(timezone.utc).isoformat()},
        execution_id=None,
        created_by="scheduler",
        priority=0,
        max_retries=0,          # a schedule fires again; a re-driven report is a duplicate delivery
    )
    logger.info("[scheduler] Schedule %s fired -> queued as task %s for a job-worker pod (%s)",
                schedule_id, task_id[:8], _resp.why_not(_resp.BACKGROUND_EXECUTION))
    return {"queued": True, "task_id": task_id, "schedule_id": int(schedule_id)}


def _execute_scheduled_job(schedule_id: int, cancel_event=None, force: bool = False):
    """
    Runs ONE user schedule, here.  (Before 2026-11-02 this body WAS
    ``_run_scheduled_job``; the dispatcher above decides where it runs.)
    1. Loads schedule from DB
    2. Executes the source query with param_values
    3. Saves output to downloads directory
    4. Registers DownloadFile record
    5. Updates Schedule run tracking
    6. Broadcasts WebSocket notification

    ``force=True`` (run_now / Run-Now button) runs even when the schedule
    is paused: the pause gate exists to stop TRIGGER-fired runs on a row
    deactivated between fire and load, not to swallow an explicit user
    action into a silent no-op (2026-08-23, Phase 4).
    """
    schedule = _db().get_schedule(schedule_id)
    if not schedule:
        return
    if schedule.get("enabled") is False and not force:
        logger.info("[scheduler] Schedule %s is paused — trigger-fired run skipped",
                    schedule_id)
        return

    execution_id  = str(uuid.uuid4())
    source_type   = schedule["source_type"]
    source_id     = schedule["source_id"]
    param_values  = schedule.get("param_values") or {}
    name          = schedule.get("name", f"schedule:{schedule_id}")

    logger.info("[scheduler] Starting schedule %s '%s' → exec %s", schedule_id, name, execution_id[:8])

    _broadcast({
        "type":          "scheduled_job_started",
        "schedule_id":   schedule_id,
        "schedule_name": name,
        "execution_id":  execution_id,
        "timestamp":     datetime.now(timezone.utc).isoformat(),
    })

    try:
        from core.config import paths as _sched_paths
        output_dir = Path(str(_sched_paths.downloads_dir))
    except Exception:
        output_dir = Path("/usr/local/querystudioapi/nfs/data/downloads")
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        import time as _timer
        _exec_start = _timer.time()

        # Resolve business date shortcuts at job run time (today, month_start, -7d, etc.)
        from core.parameters import resolve_business_dates
        param_values = resolve_business_dates(param_values)

        if source_type == "saved_query":
            output_path, total_rows = _exec_parquet_query(source_id, param_values, execution_id, output_dir)
        elif source_type == "sql_query":
            output_path, total_rows = _exec_sql_query(source_id, param_values, execution_id, output_dir)
        elif source_type == "report":
            # FB-60 (2026-09-26): a schedule authored against the legacy
            # parametric entity fails BY NAME (recorded on the schedule row).
            from core.reports.legacy_parametric import refusal
            raise ValueError(refusal(
                "schedule source_type 'report'",
                instead="Re-create the schedule with source_type='business_report'."))
        elif source_type == "business_report":
            output_path, total_rows = _exec_business_report(source_id, param_values, execution_id, output_dir)
        else:
            raise ValueError(f"Unknown source_type '{source_type}'")

        # Build filename from template
        template = schedule.get("output_filename_template") or \
                   "sched_{name}_{date}.csv"
        filename = (
            template
            .replace("{name}", name.replace(" ", "_"))
            .replace("{date}", datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S"))
        )

        # Register in DownloadFile.
        # 2026-08-04 strategic redesign — SUCCESS IS DERIVED FROM A VERIFIED
        # ARTIFACT.  The old code silently SKIPPED registration when the file
        # was missing and still marked last_run_status="success" with a
        # last_run_file_id that had no record, then emailed "completed"
        # naming a nonexistent path (live for every scheduled raw-SQL
        # business report).  That silent-skip default WAS the defect: a run
        # must not claim success without the artifact it names.  Fail-closed.
        file_id = str(uuid.uuid4())
        csv_path = Path(output_path)
        if not csv_path.exists():
            raise RuntimeError(
                f"Scheduled run produced no result artifact at '{csv_path}' "
                f"(source_type={source_type}, exec {execution_id[:8]}) — "
                "refusing to report success without a verified output file"
            )
        _db().create_download_file(
            file_id=file_id,
            execution_id=execution_id,
            filename=filename,
            file_path=str(csv_path),
            file_size_bytes=csv_path.stat().st_size,
            expires_at=_download_expires_at(),
            # 2026-08-30 — the OWNER, not the machine.  This row's
            # created_by is the only thing that lets the schedule's owner
            # re-download their own run from the Download Centre now that
            # the service-execution allowance is withdrawn there; a
            # "scheduler:<name>" string matches no principal and left the
            # run readable by everyone or no one.  Provenance is already
            # on the execution record and the schedule itself.
            created_by=(schedule.get("created_by")
                        or f"scheduler:{name}"),
        )

        # Update schedule run status
        next_run = get_next_run(schedule.get("apscheduler_job_id", ""))
        _db().update_schedule(
            schedule_id,
            last_run_at=datetime.now(timezone.utc),
            last_run_status="success",
            last_run_file_id=file_id,
            last_error=None,
            next_run_at=next_run,
        )
        _db().increment_schedule_run_count(schedule_id)

        _broadcast({
            "type":          "scheduled_job_completed",
            "schedule_id":   schedule_id,
            "schedule_name": name,
            "execution_id":  execution_id,
            "file_id":       file_id,
            "total_rows":    total_rows,
            "timestamp":     datetime.now(timezone.utc).isoformat(),
        })
        logger.info(
            "[scheduler] Schedule %s completed: %d rows → %s",
            schedule_id, total_rows, filename,
        )
        _send_schedule_email(schedule, "completed",
                             output_path=str(csv_path),
                             row_count=total_rows,
                             run_at=datetime.now(timezone.utc).isoformat())
        _send_schedule_webhook(schedule, "completed",
                               output_path=str(csv_path),
                               row_count=total_rows,
                               run_at=datetime.now(timezone.utc).isoformat())

        # -- Phase 23H (wired 2026-08-30): cloud delivery of the artifact ----------
        # _deliver_to_cloud never raises, but the call is still shielded: the
        # run's success is already recorded and the artifact is real — a
        # delivery bug reaching the outer handler would overwrite an honest
        # "success" with "failed" and email a failure for a produced report.
        try:
            _deliver_to_cloud(schedule, execution_id, str(csv_path), filename)
        except Exception as _cd_exc:
            logger.error("[scheduler] Cloud delivery crashed for schedule %s "
                         "(run stays 'success'; delivery NOT performed): %s",
                         schedule_id, _cd_exc, exc_info=True)

        # -- Phase 38: Anomaly detection -------------------------------------------
        _exec_seconds = _timer.time() - _exec_start
        try:
            from core.anomaly_detector import check_anomalies
            _file_size = 0
            try:
                import os
                if output_path and os.path.exists(str(output_path)):
                    _file_size = os.path.getsize(str(output_path))
            except Exception as _sz_exc:
                logger.error("[scheduler] Failed to get output file size for schedule %d: %s",
                             schedule_id, _sz_exc, exc_info=True)

            _anomalies = check_anomalies(schedule_id, total_rows, _exec_seconds, _db())
            _anomaly_type = _anomalies[0].anomaly_type if _anomalies else None
            _anomaly_details = [a.to_dict() for a in _anomalies] if _anomalies else None

            # Store run stats
            _db().create_schedule_run_stats(
                schedule_id=schedule_id,
                row_count=total_rows,
                execution_seconds=round(_exec_seconds, 2),
                file_size_bytes=_file_size,
                anomaly_type=_anomaly_type,
                anomaly_details=_anomaly_details,
            )

            # Broadcast anomaly if detected
            if _anomalies:
                _broadcast({
                    "type": "schedule_anomaly_detected",
                    "schedule_id": schedule_id,
                    "schedule_name": name,
                    "anomalies": _anomaly_details,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
        except Exception as _anom_exc:
            logger.warning("[scheduler] Anomaly detection failed for schedule %d: %s",
                           schedule_id, _anom_exc, exc_info=True)

        # -- Phase 60: Auto-evaluate alert rules if enabled -------------------------
        try:
            from core.delivery_engine import evaluate_alerts_for_schedule
            _triggered = evaluate_alerts_for_schedule(schedule_id, {
                "total_rows": total_rows,
                "execution_id": execution_id,
                "file_id": file_id,
            })
            if _triggered:
                logger.info("[scheduler] %d alerts triggered for schedule %d",
                           len(_triggered), schedule_id)
        except Exception as _alert_exc:
            logger.warning("[scheduler] Alert evaluation failed for schedule %d: %s",
                           schedule_id, _alert_exc, exc_info=True)

    except Exception as exc:
        logger.exception("[scheduler] Schedule %s failed: %s", schedule_id, exc)
        _db().update_schedule(
            schedule_id,
            last_run_at=datetime.now(timezone.utc),
            last_run_status="failed",
            last_error=str(exc),
        )
        _broadcast({
            "type":          "scheduled_job_failed",
            "schedule_id":   schedule_id,
            "schedule_name": name,
            "error":         str(exc),
            "timestamp":     datetime.now(timezone.utc).isoformat(),
        })
        _send_schedule_email(schedule, "failed",
                             error_message=str(exc),
                             run_at=datetime.now(timezone.utc).isoformat())
        _send_schedule_webhook(schedule, "failed",
                               error_message=str(exc),
                               run_at=datetime.now(timezone.utc).isoformat())


# ── Subscription delivery processor (Phase 60) ──────────────────────────────

SUBSCRIPTION_DELIVERY_JOB_ID = "__subscription_delivery__"


def register_subscription_delivery_job(scheduler) -> bool:
    """The subscription delivery tick, on ``scheduler`` -- ONE registration
    shared by a standalone install (init_scheduler) and a job-worker pod
    (daemon_registry._reg_subscription_delivery)."""
    from apscheduler.triggers.interval import IntervalTrigger as _IT_sub
    from core import config as _del_cfg_ref
    _del_interval = _del_cfg_ref.delivery.check_interval_minutes
    scheduler.add_job(
        func=_process_subscriptions,
        trigger=_IT_sub(minutes=_del_interval),
        id=SUBSCRIPTION_DELIVERY_JOB_ID, jobstore="daemon",
        name="Subscription delivery processor",
        replace_existing=True,
        misfire_grace_time=300,
    )
    logger.info("Registered subscription delivery job (every %d min)", _del_interval)
    return True


def _process_subscriptions():
    """Process all pending subscription deliveries.

    2026-08-20 — passes THIS process's db explicitly (the
    `_exec_business_report` precedent): on a dedicated scheduler pod the
    delivery engine's module globals are not wired by main.py's lifespan,
    and the tick used to raise AttributeError on a None ``_db_manager``
    every run.  The chokepoint self-wires the standard engine when needed.
    """
    try:
        from core.delivery_engine import process_pending_subscriptions
        result = process_pending_subscriptions(db_manager=_db())
        if result.get("processed", 0) > 0:
            logger.info("Subscription delivery: %s", result)
        # 2026-11-02 the background-job ledger reads the tick's result: returning
        # nothing recorded every run-now as "unknown" (the release-check found it)
        return result
    except Exception as exc:
        logger.error("Subscription delivery processing failed: %s", exc, exc_info=True)
        return {"error": f"{type(exc).__name__}: {exc}"}


# ── Temp-file cleanup ─────────────────────────────────────────────────────────

def _cleanup_temp_files():
    """
    Delete stale files from the downloads directory:

    1. Raw execution CSVs/parquets (not registered in Download Center) older than 1 hour.
       These are temp files created by interactive SQL report runs for grid pagination.
       They accumulate fast with many users and are useless after the user closes
       the result grid.

    2. Download Center files whose expires_at has passed (user exports kept 7 days).

    2026-08-09 cross-pod completion #3 — the downloads dir is SHARED (NFS)
    across the API / reports / published-api pods, so this scheduler-pod job
    used to be able to delete a UUID-named artifact another pod was still
    serving ``/cube`` or paged results from (sync BR execution ids ARE bare
    UUIDs), while ``br_``-prefixed async artifacts never matched the pattern
    and were NEVER cleaned (unbounded disk leak).  Both halves fixed:

    * An artifact still REFERENCED by a live ``report_instances`` row (within
      ``instance_max_age_seconds``), a recent ``federation_executions`` row or
      a live ``br_async_jobs`` row (within ``artifact_retention_seconds``) is
      EXEMPT.  If the references cannot be loaded, deletion of execution
      artifacts is SKIPPED this round (references unknown = UNSAFE — deleting
      a referenced artifact is data loss for a live session; skipping a round
      only costs disk).
    * ``br_``/``pv_br_``-prefixed artifacts now HAVE a retention policy: once
      unreferenced and older than ``artifact_retention_seconds`` (a CAP,
      floored at 1 h and at ``async_execution_ttl_seconds``) they are deleted
      like any other execution artifact.
    """
    import re as _re
    # Use the configured path rather than a hardcoded relative path
    try:
        from core.config import paths as _cfg_paths
        downloads_dir = Path(_cfg_paths.downloads_dir)
    except Exception:
        downloads_dir = Path("/usr/local/querystudioapi/nfs/data/downloads")
    if not downloads_dir.exists():
        return

    now        = datetime.now(timezone.utc)
    cutoff     = now - timedelta(hours=1)   # raw temp files older than 1 hour
    deleted    = 0
    uuid_pat   = _re.compile(
        r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(csv|parquet|xlsx|json)$",
        _re.IGNORECASE,
    )
    # Async / PV-async execution artifacts ({execution_id}.parquet where
    # execution_id = "br_"+24 hex / "pv_br_"+12 hex — business_reports_api,
    # published_views_api).  Sized loosely so a prefix format tweak cannot
    # silently re-open the never-cleaned leak.
    # 2026-11-03 (query pods phase 4): a RETRY on another query pod writes
    # ``{execution_id}.a{n}.parquet`` (core/reports/pagination.py::
    # artifact_file_name) -- the optional ``.a<n>`` is part of the name, and
    # the reference check below strips it (a record references the file by
    # path and the execution by its id).
    br_pat = _re.compile(
        r"^(br_|pv_br_)[0-9a-f]{6,64}(\.a\d+)?\.(csv|parquet|xlsx|json)$",
        _re.IGNORECASE,
    )
    attempt_suffix = _re.compile(r"\.a\d+$")

    # Referenced-artifact exemption windows (CAPS, not gates).
    try:
        from core import config as _cpc_cfg
        _exec_retention_s = int(_cpc_cfg.business_reports.artifact_retention_seconds)
        _async_ttl_s = int(_cpc_cfg.business_reports.async_execution_ttl_seconds)
        _inst_window_s = int(_cpc_cfg.business_reports.instance_max_age_seconds)
    except Exception:
        _exec_retention_s, _async_ttl_s, _inst_window_s = 21600, 3600, 86400
    _exec_retention_s = max(_exec_retention_s, _async_ttl_s, 3600)
    # D4 (2026-08-09 adversarial cross-feature review):
    # instance_max_age_seconds=0 is DOCUMENTED as "disable age-based
    # aging" and the serve honours it — so the cleaner must honour it too.
    # The old `max(0, 3600)` flooring silently REINTERPRETED "never age
    # out" as "protect artifacts for one hour": pre-warmed instances lost
    # their bytes an hour after creation and every open degraded to a live
    # run while the rows looked healthy.  0 (or negative) now means NO age
    # bound (None) — an instance's artifact stays exempt for as long as a
    # live ready/stale row references it; row-lifetime bounds (retention
    # prune, expires_at, status demotion) still reclaim it when the row
    # dies, so the exemption cannot leak disk forever.  Positive values
    # keep the 1 h floor (sub-hour windows race the serve).
    _inst_window_s = max(_inst_window_s, 3600) if _inst_window_s > 0 else None
    br_cutoff = now - timedelta(seconds=_exec_retention_s)

    # Live references from federation_executions + report_instances +
    # br_async_jobs.  None = "could not load" → FAIL CLOSED for execution-
    # artifact deletion below.
    refs = None
    try:
        refs = _db().get_live_artifact_refs(
            execution_window_seconds=_exec_retention_s,
            instance_window_seconds=_inst_window_s,
        )
    except Exception as _refs_exc:
        logger.error(
            "[cleanup] Could not load live artifact references — SKIPPING "
            "execution-artifact deletion this round (fail-closed; deleting a "
            "referenced artifact would be data loss for a live session): %s",
            _refs_exc, exc_info=True)

    # Build set of file paths currently tracked in Download Center
    try:
        tracked = {
            r["file_path"]
            for r in (_db().list_download_files(status="available", limit=10000, offset=0) or [])
        }
    except Exception as _track_exc:
        logger.error("[cleanup] Failed to load tracked download files: %s", _track_exc, exc_info=True)
        tracked = set()

    for f in downloads_dir.iterdir():
        if not f.is_file():
            continue
        try:
            mtime = datetime.fromtimestamp(f.stat().st_mtime, tz=timezone.utc)
            str_path = str(f)

            # Case 1: execution artifact (UUID- or br_-named) not in the
            # Download Center → candidate for reclamation.
            is_uuid_artifact = bool(uuid_pat.match(f.name))
            is_br_artifact = bool(br_pat.match(f.name))
            if (is_uuid_artifact or is_br_artifact) and str_path not in tracked:
                if refs is None:
                    continue  # references unknown = UNSAFE → keep this round
                base_name = f.name.rsplit(".", 1)[0]
                stem = attempt_suffix.sub("", base_name)
                if str_path in refs["paths"]:
                    continue  # still referenced — another pod may be serving it
                if stem in refs["execution_ids"]:
                    # referenced by the execution id alone (a run still
                    # building): the file counts only if it is the record's
                    # ATTEMPT -- a dead attempt's file beside the retry's is
                    # the same name with another suffix, and nobody serves it
                    # (2026-11-03, fourth review).  No attempt known = kept.
                    file_attempt = int((attempt_suffix.search(base_name) or [".a1"])[0][2:])
                    record_attempt = (refs.get("attempts") or {}).get(stem)
                    if record_attempt is None or int(record_attempt) == file_attempt:
                        continue
                file_cutoff = br_cutoff if is_br_artifact else cutoff
                if mtime < file_cutoff:
                    f.unlink()
                    deleted += 1
                continue

            # Case 2: tracked but expired (expires_at column checked separately below)
        except OSError as exc:
            logging.getLogger(__name__).debug("%s failed: %s", "scheduler", exc, exc_info=True)

    # ── Download Centre reclamation — ONE declared owner ─────────────
    # This used to run unconditionally here, mixed in with the orphaned
    # execution-artifact sweep above.  They are different pods' jobs:
    # orphan artifacts belong to whoever wrote them, expired DOWNLOADS
    # belong to whoever serves them.  When the Download Centre pod is
    # deployed it owns its own retirement; running it in both places
    # would be two pods doing half a job each.
    ghost_count = 0
    try:
        from core.download_retention import (
            downloads_cleanup_owner, reclaim_downloads)
        _owner = downloads_cleanup_owner()
        if _owner == "scheduler":
            _counts = reclaim_downloads(_db())
            deleted += _counts.get("unlinked", 0)
            ghost_count = _counts.get("ghosts", 0)
        else:
            # Say it out loud: silence here is indistinguishable from a
            # sweep that is quietly not running anywhere.
            logger.info(
                "[cleanup] download reclamation SKIPPED — "
                "storage.downloads_cleanup_owner=%r owns it", _owner)
    except Exception as exc:
        logging.getLogger(__name__).warning(
            "download reclamation failed: %s", exc, exc_info=True)

    if deleted or ghost_count:
        logger.info("[cleanup] Deleted %d stale file(s), purged %d ghost record(s)", deleted, ghost_count)


def _cleanup_audit_log():
    """BF-411.3 — Trim audit_log rows older than `audit.retention_days`.

    Default retention: 90 days.  Set to 0 to disable (keeps everything —
    table grows unbounded).  Runs as a daily APScheduler job; deletes in
    batches to avoid long-running transactions on Postgres.

    BF-410-AUDIT-FOLLOWUP: Column is `timestamp` (AuditLog.timestamp at
    core/db/models.py:111), NOT `created_at`.  Initial BF-411.3 used the
    wrong column name and would have crashed every nightly run.  Also pass
    `cutoff` as a datetime object (not .isoformat()) so SQLAlchemy binds it
    with the correct dialect-aware type instead of relying on lexicographic
    string comparison of ISO timestamps.
    """
    try:
        from core.config import get_section as _gs
        _audit_cfg = _gs("audit") or {}
        retention_days = int(_audit_cfg.get("retention_days", 90) or 0)
        batch_size = int(_audit_cfg.get("cleanup_batch_size", 10000) or 10000)
    except Exception:
        retention_days = 90
        batch_size = 10000

    if retention_days <= 0:
        logger.debug("[cleanup-audit] disabled (audit.retention_days <= 0)")
        return
    if not _db():
        return

    cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
    total_deleted = 0
    try:
        from sqlalchemy import text as _sql_text
        with _db().engine.connect() as conn:
            # Loop in batches so a single huge DELETE doesn't block the DB
            while True:
                # SQLite + Postgres both honour LIMIT in DELETE via subquery.
                # Pass cutoff as a real datetime; SQLAlchemy binds it with
                # the right dialect type (Postgres TIMESTAMPTZ, SQLite TEXT
                # via Python's adapter).
                if getattr(_db(), "is_postgresql", False):
                    res = conn.execute(
                        _sql_text(
                            "DELETE FROM audit_log WHERE id IN ("
                            "  SELECT id FROM audit_log WHERE timestamp < :cutoff "
                            "  ORDER BY id LIMIT :n"
                            ")"
                        ),
                        {"cutoff": cutoff, "n": batch_size},
                    )
                else:
                    res = conn.execute(
                        _sql_text(
                            "DELETE FROM audit_log WHERE id IN ("
                            "  SELECT id FROM audit_log WHERE timestamp < :cutoff "
                            "  LIMIT :n"
                            ")"
                        ),
                        {"cutoff": cutoff, "n": batch_size},
                    )
                conn.commit()
                _batch = int(getattr(res, "rowcount", 0) or 0)
                total_deleted += _batch
                if _batch < batch_size:
                    break
        if total_deleted:
            logger.info(
                "[cleanup-audit] deleted %d audit_log rows older than %dd",
                total_deleted, retention_days,
            )
    except Exception as exc:
        logger.warning("[cleanup-audit] failed: %s", exc, exc_info=True)


def _cleanup_local_tables_orphans():
    """BF-411.2 — Delete files in local_tables/ that no longer have a DB row.

    Common cause: pod crashed mid-upload, or admin manually deleted a row
    without removing the file.  Without this, the NFS PVC fills up over time.
    """
    try:
        from core.config import paths as _cfg_paths
        local_tables_dir = Path(_cfg_paths.data_dir) / "local_tables"
    except Exception:
        return
    if not local_tables_dir.exists():
        return
    if not _db():
        return

    try:
        # BF-414 — LocalTable model uses ``storage_path`` (a directory like
        # ``data/local_tables/{id}``), NOT ``file_path``.  The previous code
        # read ``r.get("file_path", "")`` which always returned empty, so
        # ``tracked_paths`` was always an empty set and every file under
        # ``data/local_tables/`` older than 24 h would be unlinked on the
        # 03:00 sweep.  First overnight run wiped every uploaded local table.
        # Fix: track directories from ``storage_path``; a file is "tracked"
        # if it lives anywhere under one of those directories.  Also use
        # ``active_only=False`` so files of soft-deleted-but-not-yet-purged
        # rows aren't treated as orphans.
        if hasattr(_db(), "list_local_tables"):
            rows = _db().list_local_tables(active_only=False)
        else:
            rows = []
        tracked_dirs = set()
        for r in (rows or []):
            sp = (r or {}).get("storage_path")
            if not sp:
                continue
            try:
                tracked_dirs.add(str(Path(sp).resolve()))
            except (OSError, ValueError):
                continue
    except Exception as exc:
        logger.debug("[cleanup-local-tables] list failed: %s", exc)
        return

    # Defence-in-depth: if the DB has rows but we resolved zero tracked
    # directories (schema drift, model rename, etc.), refuse to delete
    # anything — better to leak disk than wipe user data.
    if (rows or []) and not tracked_dirs:
        logger.warning(
            "[cleanup-local-tables] DB has %d rows but resolved 0 tracked dirs; "
            "refusing to delete anything (would risk data loss). "
            "Check that LocalTable.storage_path is populated.", len(rows or []),
        )
        return

    deleted = 0
    cutoff_age = timedelta(hours=24)   # only delete orphans > 1 day old
    now = datetime.now(timezone.utc)
    for sub in local_tables_dir.iterdir():
        try:
            if not sub.is_dir():
                continue
            try:
                sub_resolved = str(sub.resolve())
            except (OSError, ValueError):
                continue
            # If this whole subdirectory is tracked, skip it entirely (its
            # files are owned by an active or soft-deleted LocalTable row).
            if sub_resolved in tracked_dirs:
                continue
            # Otherwise the directory itself is orphan; its files are
            # candidates for deletion if they're old enough.
            for f in sub.rglob("*"):
                if not f.is_file():
                    continue
                try:
                    age = now - datetime.fromtimestamp(
                        f.stat().st_mtime, tz=timezone.utc,
                    )
                except (OSError, ValueError):
                    continue
                if age > cutoff_age:
                    try:
                        f.unlink()
                        deleted += 1
                    except FileNotFoundError:
                        # BF-410-AUDIT-FOLLOWUP: TOCTOU race — another
                        # process deleted the file between our stat and
                        # unlink.  Benign: someone else cleaned up first.
                        logger.debug(
                            "[cleanup-local-tables] race: %s already gone", f,
                        )
                    except PermissionError as _pe:
                        # File may be locked by an active write — skip it,
                        # the next scheduled run will retry.
                        logger.debug(
                            "[cleanup-local-tables] locked: %s — %s", f, _pe,
                        )
        except OSError as exc:
            logger.debug("[cleanup-local-tables] iter failed: %s", exc)
    if deleted:
        logger.info("[cleanup-local-tables] removed %d orphan file(s)", deleted)


def _enforce_storage_quotas():
    """Enforce configurable disk quotas on cache and downloads directories.

    Called by APScheduler every 30 minutes.  Non-fatal — any exception is logged
    and swallowed so it never disrupts the scheduler thread.
    """
    try:
        from core.config import storage as _stg_cfg
        from core.query_cache import enforce_size_limit as _cache_quota

        # ── Cache quota ───────────────────────────────────────────────────────
        max_cache = _stg_cfg.max_cache_size_mb
        if max_cache > 0:
            freed = _cache_quota(max_cache)
            if freed:
                logger.info("[quota] Cache: freed %d MB (limit %d MB)", freed, max_cache)

        # ── Downloads quota ───────────────────────────────────────────────────
        max_dl = _stg_cfg.max_downloads_size_mb
        if _db() and max_dl > 0:
            dl_bytes = _db().get_downloads_size_bytes()
            dl_mb    = dl_bytes // (1024 * 1024)
            if dl_mb > max_dl:
                # 2026-08-22 — expire by BYTES.  This used to convert the byte
                # quota into a record count via the MEAN file size and then
                # evict by age, which under any skew deleted downloads that
                # were not the problem AND left the directory over quota
                # (1 GiB + 19 GiB against a 10 GiB quota expired the 1 GiB
                # one and freed nothing that mattered).  The files are
                # physically unlinked afterwards by _cleanup_temp_files, so
                # that was real user data.
                expired, freed = _db().expire_downloads_over_byte_quota(
                    max_dl * 1024 * 1024)
                if expired:
                    logger.warning(
                        "[quota] Downloads: expired %d record(s) freeing %d MB "
                        "to stay under %d MB (was %d MB)",
                        expired, freed // (1024 * 1024), max_dl, dl_mb)
                elif dl_mb > max_dl:
                    logger.warning(
                        "[quota] Downloads: %d MB exceeds the %d MB quota but "
                        "no record could be expired without emptying the "
                        "Download Centre — a single download is larger than "
                        "the whole quota. Raise storage.max_downloads_size_mb "
                        "or remove it manually.", dl_mb, max_dl)
    except Exception as exc:
        logger.warning("[quota] Storage quota enforcement error: %s", exc, exc_info=True)


def _scheduler_key_explicitly_configured(key: str) -> bool:
    """True when the operator SET ``scheduler.<key>`` — present in the
    loaded config.json (``core.config._file_cfg``) or as a QUERYSTUDIO_*
    env override — as opposed to inheriting the built-in default.

    2026-08-04 (item: cleanup window mismatch): needed because a knob set
    EXPLICITLY TO ITS OWN DEFAULT is invisible to a value comparison.
    Production config.json sets ``cleanup_temp_files_hours: 1`` with a
    comment describing a 1-hour window; 1 == the default, so the value
    test alone left the effective window at the 900 s ``…_seconds``
    default — operator mental model and behaviour disagreed.  Fail-safe:
    any error reads as "not explicitly configured" (built-in default wins).
    """
    try:
        from core import config as _cfg_mod
        if key in ((getattr(_cfg_mod, "_file_cfg", None) or {})
                   .get("scheduler") or {}):
            return True
    except Exception as exc:
        logger.debug("[cleanup] file-config explicitness probe failed "
                     "(treated as not configured): %s", exc)
    try:
        return f"QUERYSTUDIO_SCHEDULER_{key.upper()}" in os.environ
    except Exception as exc:
        logger.debug("[cleanup] env explicitness probe failed "
                     "(treated as not configured): %s", exc)
        return False


def _live_query_floor_seconds() -> int:
    """R2 (2026-08-03): minimum age below which the temp sweep must not
    delete anything while queries may still be in flight.

    S3 pre-download staging dirs (``mkdtemp`` under QS_DOWNLOAD_TEMP_DIR)
    and DuckDB spill files live at the TOP level of the swept directories
    with no per-query namespace, so the only safe age test is "older than
    the longest-running query that could still legitimately reference
    them".  Worker-pool timeouts are 1800–7200 s; a 900 s cutoff deleted
    files out from under any query that downloaded, then queued/computed
    for more than 15 minutes.

    Returns 0 only when the local worker pool is provably idle (an orphan
    can then be reclaimed at the operator-configured cadence — the BF-545
    fast path).  When DuckDB-bearing work is running or queued — or when
    that cannot be determined (pool not initialised in this process, e.g.
    an external scheduler pod sweeping a SHARED PVC that api pods spill
    onto; UNKNOWN = UNSAFE) — returns the longest default timeout among
    the DuckDB-bearing work types.  Never raises.
    """
    try:
        from core import worker_pool as _wp
        _types = _wp._DUCKDB_BEARING_TYPES
        pool = _wp._pool
        if pool is not None:
            with pool._slot_lock:
                _running = sum(pool._running_counts.get(wt, 0) for wt in _types)
            with pool._lock:
                _queued = sum(pool._queue_counts.get(wt, 0) for wt in _types)
            if (_running + _queued) == 0:
                return 0
            _cfgs = pool._type_cfgs
        else:
            _cfgs = _wp.DEFAULT_TYPE_CONFIGS
        return max(int(_cfgs[wt].default_timeout)
                   for wt in _types if wt in _cfgs)
    except Exception as exc:
        logger.debug(
            "[subprocess-tmp-cleanup] live-query floor probe failed "
            "(assuming live work): %s", exc)
        return 7200


def _cleanup_subprocess_temp_dirs():
    """Clean up orphaned DuckDB spill and presigned-download staging dirs.

    Called by APScheduler every 30 minutes.

    DuckDB cleans its own spill on normal exit, and the subprocess finally-block
    cleans download staging dirs.  But if a subprocess is OOM-killed or crashes
    hard, orphaned dirs remain on the PVC indefinitely.

    BF-545 (2026-05-28): cutoff tightened 3600 s → 900 s.  The previous
    1-hour age guard meant an orphan could persist 30 min (next sweep)
    + 1 h (age threshold) = up to 90 min on a PVC, easily wasting GBs.
    BF-542 now has the orphan-sidecar mechanism cleaning most orphans
    at parent-finally time, so the safety net here can be tighter.  15
    min still leaves plenty of room for legitimate long-running spills.
    Operator override via ``scheduler.cleanup_temp_files_seconds``.

    R2 (2026-08-03) — two defects fixed here:
      1. PHANTOM KNOB: this function read only the undocumented
         ``scheduler.cleanup_temp_files_seconds`` key, while config.json /
         core/config.py document ``scheduler.cleanup_temp_files_hours``
         (default 1) which NOTHING read — the operator believed the window
         was 1 h; it was silently 900 s.  The documented hours knob is now
         honoured; the explicit ``*_seconds`` key (BF-545) remains as the
         higher-precedence override.
      2. LIVE-QUERY SAFETY FLOOR: while DuckDB-bearing work is in flight
         (or unknowable), the effective cutoff is floored at the longest
         query timeout — see ``_live_query_floor_seconds``.  The sweep was
         deleting staging/spill files under queries with 1800–7200 s
         budgets.
    """
    import os as _os
    import shutil as _shutil
    import time as _time

    try:
        from core.config import get as _cfg_get
        # 2026-08-04 config-key reconciliation: this sweeper read
        # ``scheduler.cleanup_temp_files_seconds`` — a key that existed in
        # NO defaults and NO docs — while the documented
        # ``cleanup_temp_files_hours`` was read by NOTHING, so an operator
        # tuning the documented knob changed nothing.  ``…_seconds`` is now
        # a real, documented default (config.py) and stays authoritative;
        # when it is UNSET but the hours knob is EXPLICITLY configured
        # (present in config.json / env — even at its own default of 1, the
        # exact shape production ships with a "1-hour window" comment) or
        # tuned away from that default, honour the operator's intent.
        # Pre-fix, hours=1 was indistinguishable from "unset", so the
        # operator's documented 1 h window silently ran as 900 s.
        _cutoff_seconds = int(_cfg_get(
            "scheduler", "cleanup_temp_files_seconds", 900) or 900)
        _legacy_hours = _cfg_get("scheduler", "cleanup_temp_files_hours", 1)
        _seconds_explicit = (
            _cutoff_seconds != 900
            or _scheduler_key_explicitly_configured("cleanup_temp_files_seconds")
        )
        _hours_wins = not _seconds_explicit and (
            float(_legacy_hours or 1) != 1
            or _scheduler_key_explicitly_configured("cleanup_temp_files_hours")
        )
        if _hours_wins:
            _cutoff_seconds = int(float(_legacy_hours or 1) * 3600)
            logger.info(
                "[cleanup] using scheduler.cleanup_temp_files_"
                "hours=%s (%.0fs) — prefer cleanup_temp_files_seconds",
                _legacy_hours, float(_cutoff_seconds))
    except Exception:
        _cutoff_seconds = 900
    # Never sweep younger than a query that may still be running (R2).
    _cutoff_seconds = max(_cutoff_seconds, _live_query_floor_seconds())
    cutoff = _time.time() - _cutoff_seconds
    total_deleted = 0
    total_bytes = 0

    from core.config import paths as _paths_cfg
    for base in (str(_paths_cfg.duckdb_temp_dir), str(_paths_cfg.download_temp_dir)):
        if not base or not _os.path.isdir(base):
            continue
        try:
            for entry in _os.scandir(base):
                try:
                    mtime = entry.stat().st_mtime
                    if mtime < cutoff:
                        if entry.is_dir(follow_symlinks=False):
                            size = sum(
                                f.stat().st_size
                                for f in Path(entry.path).rglob("*")
                                if f.is_file()
                            )
                            _shutil.rmtree(entry.path, ignore_errors=True)
                            total_deleted += 1
                            total_bytes += size
                        elif entry.is_file(follow_symlinks=False):
                            total_bytes += entry.stat().st_size
                            _os.unlink(entry.path)
                            total_deleted += 1
                except OSError:
                    pass
        except OSError as exc:
            logger.debug("[subprocess-tmp-cleanup] Error scanning %s: %s", base, exc)

    if total_deleted:
        logger.info(
            "[subprocess-tmp-cleanup] Removed %d orphaned item(s), freed %.1f MB",
            total_deleted, total_bytes / (1024 * 1024),
        )


def _cleanup_execution_history():
    """Delete old QueryExecution rows AND their output parquet files.

    Called by APScheduler once daily.
    """
    try:
        from core.config import scheduler as _sched_cfg
        retention = _sched_cfg.execution_retention_days
        if _db() and retention > 0:
            deleted, file_paths = _db().cleanup_old_executions(retention_days=retention)
            # Delete the actual parquet output files so disk doesn't grow unbounded
            files_deleted = 0
            bytes_freed = 0
            for fp in file_paths:
                try:
                    p = Path(fp)
                    if p.exists():
                        bytes_freed += p.stat().st_size
                        p.unlink()
                        files_deleted += 1
                except OSError as _os_exc:
                    logger.error("[cleanup] Failed to delete execution output file %s: %s",
                                 fp, _os_exc, exc_info=True)
            if deleted:
                logger.info(
                    "[cleanup] Pruned %d execution records older than %d days; "
                    "deleted %d file(s) (%.1f MB freed)",
                    deleted, retention, files_deleted, bytes_freed / (1024 * 1024),
                )
    except Exception as exc:
        logger.warning("[cleanup] Execution history cleanup error: %s", exc, exc_info=True)


def _refresh_partition_caches():
    """Auto-refresh partition caches for ALL registered Iceberg tables.

    Called by APScheduler every 5 hours.  Scans ALL connections for
    registered Iceberg tables and pre-loads their partition metadata into
    the DB (L2) and in-memory (L1) caches.  This ensures every table's
    partition info is available instantly — even on cold start.
    """
    if not _db():
        return {"status": "skipped", "reason": "no db manager"}
    try:
        # 2026-10-07 -- the stats dict feeds the background-job ledger.
        return _do_refresh_all_partitions()
    except Exception as exc:
        logger.warning("[partition-cache] Partition cache refresh error: %s", exc, exc_info=True)
        return {"error": str(exc)[:300]}


def _do_refresh_all_partitions(connection_id: int = None):
    """Scan all (or one) connection's registered Iceberg tables and refresh partition caches.

    Returns dict with refresh stats.  Used by both the scheduled job and
    the on-demand API endpoint.
    """
    # Collect all Iceberg tables across all S3 connections
    # Use list_connections for IDs, then get_connection_raw for unmasked creds
    connections = _db().list_connections(limit=500)
    tables_to_refresh = []
    for conn_summary in connections:
        cid = conn_summary.get("id")
        if connection_id is not None and cid != connection_id:
            continue
        conn_raw = _db().get_connection_raw(cid)
        if not conn_raw:
            continue
        cfg = conn_raw.get("config", {})
        if not cfg.get("bucket_name"):
            continue
        reg_tables = cfg.get("registered_tables", [])
        for tdef in reg_tables:
            if tdef.get("format") == "iceberg":
                tables_to_refresh.append((cid, tdef["name"], conn_raw, tdef))

    if not tables_to_refresh:
        logger.debug("[partition-cache] No Iceberg tables found to refresh")
        return {"refreshed": 0, "total": 0, "errors": 0}

    refreshed = 0
    errors = 0
    for conn_id, tname, conn_raw, tdef in tables_to_refresh:
        try:
            cfg = conn_raw.get("config", {})
            from core.iceberg_reader import get_iceberg_partition_values
            try:
                from core.s3_utilities import make_s3_client_for_conn as _make_s3_client_for_conn
                s3 = _make_s3_client_for_conn(conn_raw)
            except Exception as exc:
                logger.warning("[partition-cache] S3 client failed for conn %s: %s", conn_id, exc, exc_info=True)
                errors += 1
                continue

            bucket = cfg["bucket_name"]
            s3_prefix = tdef.get("s3_prefix", "")
            result = get_iceberg_partition_values(
                s3, bucket, s3_prefix, full_scan=True
            )
            now_iso = datetime.now(timezone.utc).isoformat()
            stamped = {**result, "cached_at": now_iso}
            for stype in ("fast", "full"):
                _db().set_partition_cache(conn_id, tname, stype, stamped, s3_prefix=s3_prefix)

            # Update L1 in-memory cache too
            try:
                from core.iceberg_cache import partition_l1_set as _partition_l1_set
                for stype in ("fast", "full"):
                    _partition_l1_set(f"{conn_id}:{tname}:{s3_prefix}:{stype}", stamped)
            except Exception as _l1_exc:
                logger.error("[partition-cache] Failed to update L1 cache for %s:%s: %s",
                             conn_id, tname, _l1_exc, exc_info=True)

            refreshed += 1
            logger.info("[partition-cache] Refreshed %d/%d: %s",
                        refreshed, len(tables_to_refresh), tname)
        except Exception as exc:
            errors += 1
            logger.warning("[partition-cache] Error refreshing %s:%s — %s",
                           conn_id, tname, exc, exc_info=True)

    logger.info("[partition-cache] Refresh complete: %d/%d refreshed, %d errors",
                refreshed, len(tables_to_refresh), errors)
    return {"refreshed": refreshed, "total": len(tables_to_refresh), "errors": errors}


def _cleanup_expired_local_tables_job():
    """APScheduler job: auto-discard public local tables unused beyond their auto_discard_days."""
    if not _db():
        return
    try:
        # Delegate to main.py's cleanup function which has access to ws_manager
        from core.mv_manager import cleanup_expired_local_tables as _cleanup_expired_local_tables
        _cleanup_expired_local_tables()
    except Exception as exc:
        logger.warning("[local-table-cleanup] Error: %s", exc, exc_info=True)


def _sweep_stale_cache_entries():
    """Phase 104 — Background sweep: evict cache entries whose source data has changed.

    Iterates all cache entries that have a source_fingerprint, checks current
    snapshot/file-list against stored fingerprint, and evicts stale entries.
    Runs every N hours (configurable via cache.snapshot_sweep_interval_hours).
    """
    if not _db():
        return
    from core import config as _cfg
    if not _cfg.cache.partition_aware_invalidation:
        return

    try:
        from core.snapshot_fingerprint import check_cache_entry_staleness_multi
        from core.s3_utilities import make_s3_client_for_conn
        from core.query_cache import invalidate as _qc_invalidate

        entries = _db().list_cache_entries()
        entries_with_fp = [e for e in entries if e.get("source_fingerprint")]
        logger.info("[sweep] Checking %d/%d cache entries for staleness",
                    len(entries_with_fp), len(entries))

        evicted = 0
        errors = 0
        for entry in entries_with_fp:
            try:
                cache_key = entry.get("cache_key")
                if not cache_key:
                    continue
                conn_id = entry.get("connection_id")

                def _get_s3_for_conn(cid, tname, _db=_db(), _make=make_s3_client_for_conn):
                    try:
                        conn = _db.get_connection_raw(cid)
                        if not conn:
                            return None
                        cfg = conn.get("config", {})
                        bucket = cfg.get("bucket_name", "")
                        for tbl in cfg.get("registered_tables", []):
                            if tbl.get("name") == tname:
                                s3c = _make(conn)
                                return (s3c, bucket, tbl.get("s3_prefix", ""))
                        return None
                    except Exception:
                        return None

                is_stale, reason = check_cache_entry_staleness_multi(entry, _get_s3_for_conn)
                if is_stale:
                    logger.info("[sweep] Evicting stale cache entry key=%s reason=%s",
                                cache_key[:16], reason)
                    _qc_invalidate(cache_key)
                    evicted += 1
            except Exception as _entry_exc:
                logger.debug("[sweep] Entry check failed for %s: %s",
                             entry.get("cache_key", "?")[:16], _entry_exc)
                errors += 1

        logger.info("[sweep] Stale cache sweep complete: %d evicted, %d errors (of %d checked)",
                    evicted, errors, len(entries_with_fp))
    except Exception as exc:
        logger.warning("[sweep] Background sweep error: %s", exc, exc_info=True)


# ── Per-source execution helpers ──────────────────────────────────────────────

def _exec_parquet_query(query_id: int, param_values: dict,
                        execution_id: str, output_dir: Path):
    from core.parameters import substitute_filter_params

    saved_q = _db().get_query(query_id)
    if not saved_q:
        raise ValueError(f"Saved query {query_id} not found")

    qc = dict(saved_q["query_config"])
    if param_values and qc.get("filters"):
        qc["filters"] = substitute_filter_params(qc["filters"], param_values)

    # If the saved query was built against a SQL connector (Trino/Starburst etc.)
    # route it through the connector instead of the local parquet engine.
    conn_id = qc.get("connection_id")
    if conn_id:
        conn_record = _db().get_connection_raw(conn_id)
        if conn_record:
            _conn_type = conn_record.get("connection_type", "")
            # 2026-09-05 -- "is this a SQL connector" is asked from the
            # registry, not from a literal restated here.  This set had
            # drifted into one of FOUR answers to the same question; the
            # canonical one is DERIVED from core.connectors._REGISTRY, so
            # it can never name a type get_connector() would refuse.
            from core.connectors import SQL_EXECUTABLE_TYPES
            if _conn_type in SQL_EXECUTABLE_TYPES:
                from core.connectors import get_connector
                from core.parquet_engine_v2 import ParquetQueryEngine as _PQE
                connector = get_connector(_conn_type, conn_record.get("config", {}))
                # 2026-09-05 round 2 -- the SAME chokepoint the
                # interactive run and the preview use.  This was
                # ``files[0]`` verbatim.
                #
                # A background job that must not 500 on an old saved query
                # is a real consideration, and it is answered here the
                # other way ON PURPOSE: a scheduled export DELIVERS to
                # recipients, so the two outcomes are "the run fails and
                # someone is paged" versus "another table's rows are
                # delivered under a green status, and nobody ever finds
                # out".  ``QueryNotExpressible`` is a ValueError, which is
                # exactly what the line below already raised for a missing
                # table, so this fails the run the way this module already
                # fails it -- loudly, with the engine and the reason in the
                # message.
                from core.parquet_engine_v2 import (
                    native_from_ref as _native_from_ref_sched)
                table_ref = _native_from_ref_sched(
                    qc.get("files"), qc.get("joins"), _conn_type)
                if table_ref is None:
                    table_ref = qc.get("files", [None])[0]
                if not table_ref:
                    raise ValueError("No table specified in saved query config")
                # Build SQL using the parquet engine's SQL builder (safe — no file I/O)
                _build_eng = _PQE(base_path=".")
                # 2026-09-26 -- EVERY stored field crosses through the ONE
                # converter.  This site used to name nine of the seventeen
                # fields by hand and pass ``aggregations`` as the stored
                # dicts, which the builder reads as objects
                # (``agg.function``): a scheduled query with a SUM died
                # here with AttributeError, was caught by
                # ``_run_scheduled_job`` and reported "executed
                # successfully" with no file.  ``distinct`` / ``having`` /
                # ``filter_logic`` and the computed, CASE and window
                # columns were not passed at all.  The limit contract is
                # unchanged: the converter carries ``limit`` verbatim and
                # both builders omit LIMIT when it is falsy (no
                # ``or 1_000_000`` fold -- a scheduled export of a 70M-row
                # table once delivered 1M rows and looked fine).
                from core.query_converter import engine_config_from_stored
                engine_cfg = engine_config_from_stored(
                    qc, where=f"scheduled saved query {query_id}")
                engine_cfg.files = [table_ref]
                # 2026-08-19 -- dialect: see reports_api.  A scheduled
                # export on Databricks silently selected constant strings
                # without it.
                # 2026-08-19 -- type the filters; see reports_api.
                from core.column_types import (
                    annotate_from_connector as _annot_sched)
                _annot_sched(engine_cfg.filters, connector, table_ref,
                             conn_record.get("config") or {},
                             conn_record.get("id"))
                sql_str = _build_eng.build_query_sql(
                    engine_cfg, table_ref, dialect=_conn_type)

                # 2026-08-19 -- ROW SECURITY on the scheduled connector path.
                # grep secure_sql in this module returned ZERO hits: a
                # scheduled delivery built connector SQL here and streamed it
                # straight to parquet, so every scheduled export against
                # Trino/Snowflake/Databricks/Oracle/Athena ran UNFILTERED
                # while the same query run interactively was filtered.
                # Scheduled output goes to recipients, so this is the least
                # observable place for it to have been wrong.
                try:
                    from core.row_security import secure_sql as _rs_sched
                    _sched_secured = _rs_sched(
                        sql_str,
                        dialect=dialect_for_connection_type(_conn_type),
                        # The saved query's owner, resolved through the
                        # same AD lookup the interactive path uses; on
                        # failure it returns a principal marked
                        # rls_unresolved, which now REFUSES a governed table
                        # rather than silently widening it.
                        user_ctx=_resolve_owner_user_ctx(
                            str(saved_q.get("created_by") or "")),
                        connection_id=conn_record.get("id"),
                        request_id=execution_id,
                    )
                    if _sched_secured:
                        sql_str = _sched_secured
                except Exception as _rs_sched_exc:
                    # Fail-CLOSED: a scheduled job that cannot prove its
                    # filtering must not deliver.
                    logger.error(
                        "[scheduler] row-security rewrite FAILED for "
                        "execution %s (%s) -- aborting rather than "
                        "delivering unfiltered rows",
                        execution_id, _rs_sched_exc)
                    raise
                # Phase 154 strategic chokepoint -- the inline streaming
                # block here replicated execute_sql_to_parquet's logic.
                # Route through the chokepoint so cancel-event /
                # bounded-queue / dict-vs-tuple normalisation / empty-
                # result fallback are all consistent with cross_source +
                # federation engines.
                from core.connector_to_parquet import execute_sql_to_parquet
                output_path = str(output_dir / f"{execution_id}.parquet")
                _meta = execute_sql_to_parquet(
                    connector, sql_str, output_path, chunk_size=50_000,
                )
                return output_path, _meta.get("total_rows", 0)
            elif _conn_type in ("local", "s3"):
                from core.s3_storage import build_s3_config
                from core.parquet_engine_v2 import ParquetQueryEngine
                _cfg = conn_record.get("config", {})
                if _conn_type == "s3":
                    active_engine = ParquetQueryEngine(
                        s3_config=build_s3_config(_cfg),
                    )
                else:
                    active_engine = ParquetQueryEngine(
                        base_path=_cfg.get("base_path"),
                    )
                # 2026-09-26 -- the ONE converter (see the connector branch
                # above).  This site named SIX fields: a scheduled GROUP BY
                # query on an s3/local connection ran as ``SELECT * ...
                # WHERE`` and delivered its detail rows as success; an
                # ORDER BY was dropped the same way.  Falsy limit still
                # means UNLIMITED -- the converter carries it verbatim.
                #
                # 2026-09-26 (M4) -- and carrying the field was not RUNNING
                # it: ``ParquetQueryEngine.execute_query`` shapes each
                # chunk with pyarrow (filters / joins / projection / order)
                # and has no aggregate.  A ``local`` connection now takes
                # the one local road: the six-field shape keeps this
                # pyarrow reader, anything beyond it runs on DuckDB, and the
                # owner's row-security policies apply on that SQL.  The S3
                # branch reads through boto3 and has no DuckDB road (that
                # would need the presigned-URL view setup the interactive
                # path owns), so it REFUSES a shape it cannot express, by
                # name -- the one gap left, recorded in the plan.
                from core.query_converter import engine_config_from_stored
                config = engine_config_from_stored(
                    qc, where=f"scheduled saved query {query_id}")
                output_path = str(output_dir / f"{execution_id}.parquet")
                # Phase 154 strategic chokepoint -- bounded parquet write.
                # Stream the chunk generator straight through; concatenating
                # it first is what forced the old row cap.
                from core.connector_to_parquet import (
                    df_chunks_to_parquet_streaming,
                )
                from core.local_parquet_road import run_local_parquet, run_s3_parquet
                if _conn_type == "s3":
                    # 2026-09-26 (round 3) -- the S3 lane RUNS every shape:
                    # the five-field shape keeps the pyarrow reader over
                    # boto3 it always used; anything beyond it (or a policy
                    # rewrite) runs on DuckDB over the ONE S3 resolver
                    # (core.s3_access), registered tables as views named by
                    # their registered name.  No refusal is left here.
                    _run = run_s3_parquet(
                        qc, conn_record,
                        where=f"scheduled saved query {query_id}",
                        secure=_owner_secure_fn(saved_q, execution_id),
                        request_id=execution_id,
                        fast_path=lambda: active_engine.execute_query(config))
                else:
                    _run = run_local_parquet(
                        qc, data_dir=_cfg.get("base_path"),
                        where=f"scheduled saved query {query_id}",
                        secure=_owner_secure_fn(saved_q, execution_id),
                        request_id=execution_id, db=_db(),
                        fast_path=lambda _resolved: active_engine.execute_query(
                            engine_config_from_stored(
                                _resolved, where=f"scheduled saved query {query_id}")))
                logger.info("[scheduler] saved query %s ran on %s (%s)",
                            query_id, _run.engine, ",".join(_run.reasons) or "five-field")
                _meta = df_chunks_to_parquet_streaming(_run.chunks, output_path)
                return output_path, _meta.get("total_rows", 0)

    # Default: local parquet engine
    # 2026-09-15 -- this passed ``offset=`` to a dataclass that has NO such
    # field, so EVERY scheduled local-parquet run died with
    # ``TypeError: QueryConfig.__init__() got an unexpected keyword argument
    # 'offset'`` before reading a single row.  The exception is caught and
    # logged by ``_run_scheduled_job``, and APScheduler still reports the job
    # "executed successfully", so a schedule that has never once produced a
    # file looked like a working schedule.  Live on this branch since the
    # initial commit.
    #
    # ``optimized_engine`` has no concept of an offset (the word appears
    # nowhere in it), so the kwarg could never have been honoured.  Dropping
    # it silently would be worse than the crash for the one caller that means
    # it: a schedule asking to skip N rows would quietly get the FIRST N back
    # -- the wrong rows, reported as success.  So: support the case the engine
    # can actually serve, and REFUSE the one it cannot.
    #
    # 2026-09-26 -- and offset was only the field this branch CRASHED on.
    # ``group_by`` / ``aggregations`` / ``distinct`` / ``having`` /
    # ``filter_logic`` and the computed, CASE and window columns have no
    # field on ``OptQC`` either, and were dropped without a sound: a
    # scheduled GROUP BY query delivered its detail rows as success.
    #
    # 2026-09-26 (M4) -- and now it RUNS.  ``core.local_parquet_road`` is
    # the one road every local parquet door takes: the six-field shape
    # stays on the optimized engine (falsy limit = UNLIMITED, its early-stop
    # only fires on a truthy limit), anything beyond it -- including the
    # offset above -- runs on DuckDB through the same SQL the interactive
    # path builds, and the owner's row-security policies apply on that SQL
    # (fail-closed, as on the connector branch).
    from core.local_parquet_road import run_local_parquet
    _run = run_local_parquet(
        qc, data_dir=None, where=f"scheduled saved query {query_id}",
        secure=_owner_secure_fn(saved_q, execution_id),
        request_id=execution_id, db=_db())
    logger.info("[scheduler] saved query %s ran on %s (%s)",
                query_id, _run.engine, ",".join(_run.reasons) or "six-field")
    output_path = str(output_dir / f"{execution_id}.parquet")
    # Phase 154 strategic chokepoint -- bounded parquet write.
    # Stream the chunk generator straight through; concatenating it first is
    # what forced the old row cap.
    from core.connector_to_parquet import df_chunks_to_parquet_streaming
    _meta = df_chunks_to_parquet_streaming(_run.chunks, output_path)
    return output_path, _meta.get("total_rows", 0)


def _owner_secure_fn(saved_q: dict, execution_id: str):
    """The row-security rewrite for a scheduled LOCAL parquet run, as a
    ``sql -> sql`` callable for ``core.local_parquet_road``.

    Same principal and same fail-CLOSED posture as the connector branch
    above (2026-08-19): the saved query's owner, resolved through the AD
    lookup the interactive path uses; a rewrite that FAILS aborts the run
    rather than delivering unfiltered rows.  Until 2026-09-26 the local
    branches applied no row security at all -- the least observable place
    for it to be missing, since a scheduled file goes to recipients.
    """
    owner = str((saved_q or {}).get("created_by") or "")

    def _secure(sql: str) -> str:
        try:
            from core.row_security import secure_sql as _rs
            return _rs(sql, dialect="duckdb",
                       user_ctx=_resolve_owner_user_ctx(owner),
                       connection_id=None, request_id=execution_id)
        except Exception as _rs_exc:
            logger.error(
                "[scheduler] row-security rewrite FAILED for execution %s "
                "(%s) -- aborting rather than delivering unfiltered rows",
                execution_id, _rs_exc)
            raise
    return _secure


def _exec_sql_query(query_id: int, param_values: dict,
                    execution_id: str, output_dir: Path):
    from core.cross_source_engine import execute_single_source_query, execute_cross_source_sql
    from core.parameters import substitute_sql_params

    sql_q = _db().get_sql_query(query_id)
    if not sql_q:
        raise ValueError(f"SQL query {query_id} not found")

    primary_conn = _db().get_connection_raw(sql_q["primary_connection_id"])
    if not primary_conn:
        raise ValueError(f"Connection {sql_q['primary_connection_id']} not found")

    # 2026-08-29 BOUNDARY.  ``${user.<var>}`` resolves in REPORT SQL
    # (reports_api._run_sql_report), against the principal actually running
    # the report.  A scheduled ``sql_query`` job is a delivery job, not
    # somebody's session: there is no principal to resolve against, so the
    # tokens reach the database verbatim -- exactly as they always have,
    # which is why this WARNS rather than refusing or inventing an identity.
    # Say it out loud: the author otherwise gets an opaque driver syntax
    # error for a token the product resolves happily one surface over.
    # Advisory ONLY: nothing below consumes ``_unresolvable``.  A log line
    # must never be able to kill a delivery job that worked yesterday, so the
    # whole block is fail-open — an import or scan failure costs a debug line,
    # not the run.
    try:
        from core.reports.user_sql_vars import referenced_user_vars
        _unresolvable = (referenced_user_vars(sql_q.get("primary_sql"))
                         + referenced_user_vars(sql_q.get("secondary_sql")))
    except Exception as _uv_exc:
        logger.debug("[user-sql-vars] advisory scan skipped: %s", _uv_exc)
        _unresolvable = []
    if _unresolvable:
        logger.warning(
            "[user-sql-vars] scheduled sql_query %s references %s, which "
            "only resolve when a REPORT is executed for a principal. This "
            "job has no caller identity, so the tokens are sent to the "
            "database unchanged. Fix: schedule a report backed by this "
            "query instead.",
            query_id, ", ".join("${user.%s}" % n for n in _unresolvable))

    primary_sql = substitute_sql_params(sql_q["primary_sql"], param_values, [])

    is_cross = bool(sql_q.get("secondary_connection_id") and sql_q.get("secondary_sql"))
    if sql_q.get("secondary_connection_id") and not is_cross:
        # Never run the primary alone and deliver it as the cross answer.
        raise ValueError(
            f"SQL query {query_id} names secondary connection "
            f"{sql_q['secondary_connection_id']} but has no secondary SQL")
    if is_cross:
        secondary_conn = _db().get_connection_raw(sql_q["secondary_connection_id"])
        if not secondary_conn:
            raise ValueError(
                f"Secondary connection {sql_q['secondary_connection_id']} "
                f"not found -- refusing to deliver the primary side alone")
        secondary_sql  = substitute_sql_params(sql_q["secondary_sql"], param_values, [])
        # THE cross-source capability (2026-10-04), with the SQL page's own
        # spec -- same shape, same default (join), same UNION support -- so
        # a scheduled run of a saved query is the answer its author saw.
        from core.executors.cross_source_combine import saved_sql_query_spec
        result = execute_cross_source_sql(
            primary_conn=primary_conn,
            primary_sql=primary_sql,
            secondary_conn=secondary_conn,
            secondary_sql=secondary_sql,
            spec=saved_sql_query_spec(sql_q.get("combine_mode"),
                                      sql_q.get("join_config")),
            execution_id=execution_id,
            output_dir=str(output_dir),
            db_manager=_db(),
        )
    else:
        result = execute_single_source_query(
            conn_type=primary_conn["connection_type"],
            conn_config=primary_conn["config"],
            sql=primary_sql,
            execution_id=execution_id,
            output_dir=str(output_dir),
        )
    return result.output_path, result.total_rows


#: 2026-08-19 -- the scheduled connector path's row-security rewrite needed a
#: connection type -> sqlglot dialect answer and declared ``_RS_SCHED_DIALECTS``
#: here to get one.  2026-09-05 it asks ``dialect_for_connection_type``
#: instead: this copy knew eight types and not sqlserver / redshift / bigquery
#: / presto, so a scheduled export on one of those had its row-security
#: predicate rewritten in DuckDB grammar and then delivered to recipients --
#: the least observable place in the product for a query to be wrong.

def _resolved_scope(username: str, role: str, groups: list) -> dict:
    """A principal whose scope was actually ESTABLISHED, not fabricated.

    Deliberately a named constructor rather than a dict literal at each site.
    A fabricated principal must carry ``rls_unresolved`` -- a guard asserts
    that every fabrication site does -- and a resolved one must not, or a
    real user's own scope would be refused. Making the two shapes different
    CONSTRUCTS keeps that guard meaningful instead of teaching it exceptions.
    """
    return {"username": username, "role": role or "viewer",
            "groups": list(groups)}


def _local_groups_for(username: str) -> list:
    """Group NAMES for a user from the native group store.

    The same vocabulary policies bind to (``group:<name>``) and the same one
    ``${user.groups}`` renders, so a headless run and an interactive session
    resolve the owner to the same scope. Fail-quiet: an unreadable store
    yields no groups, which the caller turns into a marked refusal rather
    than an unfiltered read.
    """
    try:
        rows = _db().list_groups_for_user(username) or []
    except Exception as exc:
        logger.warning("[scheduler] native group lookup failed for %r: %s",
                       username, exc)
        return []
    names = [str(r.get("name")).strip() for r in rows if r.get("name")]
    return sorted({n for n in names if n})


def _resolve_owner_user_ctx(owner: Optional[str]) -> Dict[str, Any]:
    """Build the RLS principal for a scheduled business report.

    SECURITY (row-level security): a scheduled/delivered report has no live
    request identity, so previously the scheduler passed role="admin" / no
    user_ctx and the FederationEngine fail-OPENED — RLS was skipped and every
    recipient got the UNFILTERED row set.  We instead run the job at the report
    OWNER's RLS scope, so a scheduled run returns exactly what the owner would
    see running it interactively (same-bytes-to-all delivery model).

    Resolution mirrors the interactive auth path (deps.get_current_user):
      * groups + role come from a password-free AD lookup (lookup_ad_user →
        _resolve_role) — the identical source the interactive login uses, so
        role/group-scoped grants resolve the same way and we do not DROP rows
        the owner legitimately sees.

    FAIL-CLOSED: on any resolution failure (no owner, AD lookup unavailable,
    non-AD auth mode) we degrade to the owner's username with role='viewer'
    and no groups, AND mark the context ``rls_unresolved``.

    2026-08-19 -- this used to claim the degraded principal "can only ever
    restrict further (drop rows), never leak extra rows".  That is BACKWARDS
    in this engine.  Policies are bound to principals and a table with no
    MATCHING policy is skipped, i.e. left unfiltered -- so dropping the
    groups drops the bindings that were doing the restricting.  A policy
    bound to ``group:emea-only -> region = 'EU'`` simply stops matching, and
    the scheduled report delivers every region to its recipients.

    The ``rls_unresolved`` marker is what makes the docstring's original
    promise true: the rewriter now REFUSES a governed table rather than
    skipping it, so the failure is a failed execution an operator can see
    instead of a wider result set nobody notices.  Tables with no policies
    are unaffected.  We still never fall back to an admin/bypass principal.
    """
    owner = (owner or "").strip()
    if not owner:
        logger.warning(
            "[scheduler] business report has no recorded owner — running at a "
            "least-privilege RLS scope (role=viewer, no groups)"
        )
        return {"username": "scheduled", "role": "viewer", "groups": [],
                "rls_unresolved": True}

    try:
        from core.ad_auth import lookup_ad_user
        info = lookup_ad_user(owner)
        if info:
            ctx = {
                "username": info.get("username") or owner,
                "role": info.get("role") or "viewer",
                "groups": list(info.get("groups") or []),
            }
            if not ctx["groups"]:
                # 2026-08-29 — the directory answered but placed this owner in
                # NO groups.  Try the native group store before giving up: a
                # local-auth deployment keeps its memberships there, and
                # ``lookup_ad_user`` returns None unconditionally when auth is
                # not AD — so scope resolution silently depended on the AUTH
                # MODE rather than on whether the owner has a scope.
                ctx["groups"] = _local_groups_for(owner)
                if not ctx["groups"]:
                    # Resolved the PERSON but established no scope. Under a
                    # grant engine that is not least privilege -- it matches
                    # no binding, and an unmatched table is served UNFILTERED.
                    # Mark it so governed tables are refused instead.
                    logger.warning(
                        "[scheduler] owner %r resolved but belongs to no "
                        "groups — marking the scope unresolved so governed "
                        "tables are REFUSED rather than read unfiltered",
                        owner)
                    ctx["rls_unresolved"] = True
            # 2026-08-29 — carry the directory's harmless descriptive fields
            # so ``${user.email}`` / ``${user.display_name}`` resolve headless
            # too.  Without them a report the author validated INTERACTIVELY
            # (where the session principal carries these) was refused the
            # first time it ran on a schedule -- a runtime refusal of a report
            # that used to work, which the renderer's contract forbids.
            # Named fields only: copying the whole record would sweep any
            # future credential-ish key into the SQL vocabulary.
            for _k in ("display_name", "email"):
                if info.get(_k):
                    ctx[_k] = info[_k]
            return ctx
        else:
            local = _local_groups_for(owner)
            if local:
                logger.info(
                    "[scheduler] owner %r resolved from the native group "
                    "store (auth is not AD)", owner)
                return _resolved_scope(owner, "viewer", local)
        logger.info(
            "[scheduler] AD lookup returned no record for report owner %r "
            "(or auth is non-AD) and the native group store has none — "
            "using least-privilege RLS scope", owner,
        )
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning(
            "[scheduler] AD lookup for report owner %r failed — using "
            "least-privilege RLS scope (fail-closed): %s", owner, exc,
        )
    # Fail-closed fallback: owner identity, and MARKED unresolved.
    #
    # 2026-08-29 — this used to be described as "least-privilege viewer/no
    # groups — restricts, never widens".  That is false in a GRANT-shaped
    # engine: a principal with no groups matches no binding, and an unmatched
    # table is shipped UNFILTERED (see row_security/rewriter.py).  Dropping a
    # principal's groups therefore WIDENS.  The ``rls_unresolved`` marker is
    # what turns that into a refusal, so it belongs on every path that failed
    # to establish a scope — including one where the directory answered but
    # produced no groups at all.
    return {"username": owner, "role": "viewer", "groups": [],
            "rls_unresolved": True}


def _exec_business_report(report_id: int, param_values: dict,
                          execution_id: str, output_dir: Path):
    """Phase 111-F: Execute a business report from the scheduler.

    Handles all data_source_type values:
      - 'raw_sql' → _run_parquet_report / _run_sql_report (via adapter)
      - 'saved_query' / 'federation_view' / 'published_view' → FederationEngine

    SECURITY: runs at the report OWNER's row-security scope (see
    _resolve_owner_user_ctx) — never role="admin" — so scheduled delivery
    enforces the same RLS the owner sees interactively.
    """
    br = _db().get_business_report(report_id)
    if not br:
        raise ValueError(f"Business report {report_id} not found")

    # SECURITY (RLS): resolve the report OWNER as the principal so every
    # execution path enforces row-security at the owner's scope — the same
    # rows the owner would see running the report interactively.  Never
    # role="admin" (which would bypass RLS and leak all rows to recipients).
    owner_ctx = _resolve_owner_user_ctx(br.get("owner"))

    # Single shared chokepoint — the exact same executor subscription delivery
    # (core/delivery_engine via business_reports_api.run_business_report_to_df)
    # uses, so scheduled and delivered runs can never diverge on data-source
    # dispatch or RLS scope.
    from api.business_reports_api import _dispatch_business_report_execution
    return _dispatch_business_report_execution(
        br, param_values, execution_id, output_dir, owner_ctx, _db(),
    )

