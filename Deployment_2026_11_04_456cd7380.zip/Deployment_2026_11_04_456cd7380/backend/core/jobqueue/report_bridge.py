"""report_bridge -- a business REPORT run, and a report-backed PUBLISHED API
run, on the sized query-pod lane (query pods phase 4, 2026-11-03; design
``docs/QUERY_PODS_DESIGN_2026_10_29.html`` section 7, phase 4).

Today a report runs in-process DuckDB through the federation engine on the
reports pod (``api/business_reports_api.py::execute_report_async``) and a
report-backed published view in the published-api pod
(``api/published_views_api.py::_execute_view_business_report``) -- a different
seam from ``POST /api/execute``, which phases 1-3 put on query pods.  A heavy
report run can kill the pod it runs in (the owner's incident: a BQB run killed
the UAT API pod at 26 min / 1M rows).  This module is the SAME shape as
:mod:`core.jobqueue.execute_bridge`, for that seam:

**API side** -- :func:`maybe_enqueue_async_report` (the execute-async route)
and :func:`run_published_api_or_inline` (the published-view handler):

  * the switch ``query_pods.reports_lane`` OFF (the default), or no query-pod
    sizes configured, or queue mode not armed: ``None`` / the inline road --
    nothing changes, and nothing new is computed (the switch is read FIRST,
    before any serialisation);
  * ON: identity + the user's row-security context are captured AS DATA
    (``core.identity.derive_from_verified_user`` -> the job row's identity
    payload, the one mechanism the ad-hoc lane uses and the edges proof shows
    holding row security ON a pod), the run is PRICED by the one pricer with
    the report's DEFINITION as its plan (so a report's history is per report,
    not per run), ROUTED by the one decision (``execute_bridge.decide_route``:
    under ``query_pods.small_run_mb`` it stays where it is today), and queued
    as ONE job kind ``execute_report`` carrying the resolved report, the
    filters, the bindings, the row limit and the readiness verdict the API
    already computed and authorized -- the pod never re-derives any of it;
  * FAIL-OPEN where the ad-hoc bridge does: any failure BEFORE a job row
    exists -> loud log -> the inline road.  Once a row exists the run is a
    sized run and is NEVER absorbed into this pod (phase 2's rule: that is the
    restart the lane exists to stop); the sweeper bounds its wait when no pod
    of its size is alive, and a job can never run twice: the budgeted claim
    is the one guarded UPDATE that decides which pod runs it, and the run's
    own record is FENCED BY ATTEMPT (a pod that lost its lease while another
    pod runs the retry can no longer write the record);
  * too big for every size: refused with the numbers in plain words (the
    execute-async row is failed with the sentence; the published view answers
    413), exactly as ``POST /api/execute``.

**Executor side** -- :func:`handle_execute_report` (registered for kind
``execute_report`` beside ``execute_query``): rehydrates the identity from the
row, runs the EXISTING runners (``_run_async_report_job`` /
``_run_async_raw_sql_job`` for the execute-async surface -- the same body the
reports pod runs, terminal write, notification, WebSocket (fleet-relayed) and
instance write-through included -- and the published view's
``_run_report_query`` / ``_execute_raw_sql_report`` through the same admission
gate) on the bridge loop inside the job's memory reservation, and relays the
outcome.  The result artifact lands where every runner already writes it (the
shared downloads dir, ``{execution_id}.parquet``), so the status and result
routes the viewer polls read it from ANY pod exactly as they do today.
EVERY exception the handler does not classify becomes ONE plain sentence on
the job (never "handler crash: <traceback>" for a consumer to read, never a
re-run of a job whose crash was not the engine's).

**Three ways a run stops early, three different writes** (security reviews
2026-11-03): a REAL cancel (the job's flag) ends the record ``cancelled``
through the guarded door; this executor turning ZOMBIE (its lease fenced out:
another pod may already be running the retry) FENCES the execution in this
process (``fence_execution``: the runner's own failure write, "Query was
cancelled", can no longer reach the record) and THEN stops the local engine;
the run timeout ends the record ``failed`` with a plain sentence.  Every
write carries the attempt, and the door refuses an older one; the attempt is
stamped only over an older one (``attempt IS NULL OR attempt < mine``).

**Retry safety is a declaration** (CLAUDE.md section 4): a builder report is
a read only when every dataset SQL it reads is PROVEN one by
``core.jobqueue.retry_safety`` (a dataset's custom SQL is text this module can
classify); a raw-SQL report only when its text is; anything else gets one
attempt and the reaper fails it with the reason.

**A dead job reaches the run's own record two ways, one rule**
(:func:`record_verdict_from_job`): the queue sweep's
:func:`reconcile_dead_report_runs` walks every RUNNING record that names a
job, and the orphan rule in ``business_reports_api._mark_job_orphaned`` asks
the same question for the one record a poll just read -- so a dead job is
closed with or without a sweeper (queue mode disarmed, the lane rolled back),
and only a LIVE job (queued / leased / running) holds the clock off; a job
that is gone leaves the clock to decide, as for a run before the lane.  The
queue's own sentences are copied as they are, anything else is one fixed
sentence (the detail stays in the log).

**What a consumer may read back** (CWE-209): the published-API job's relayed
response holds only the execution id, the row count and the column names; the
artifact path travels on the server-side ``federation_executions`` row, never
through the jobs API; a failed job's ``error`` is a plain sentence, and
``api/jobs_api.py`` shows a report job's error only through
:func:`public_error`.
"""
from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from sqlalchemy import text as sa_text

from core.jobqueue.executor import (
    JobCancelled, JobContext, JobDeferred, JobHttpError, NonRetryableJobError, register_handler,
)
from core.jobqueue.queue import ClaimedJob, compute_plan_hash, get_job_queue
from core.query_pods.price import TooBigForQueryPods
from core.reports.versions import DEFINITION_FIELDS as _VERSION_DEFINITION_FIELDS

logger = logging.getLogger(__name__)

#: THE job kind -- one for both surfaces (the seam is the same: a report
#: definition + filters + a principal -> a parquet artifact on shared storage)
KIND = "execute_report"

SURFACE_REPORT_ASYNC = "report_async"      # POST /api/business-reports/{id}/execute-async
SURFACE_PUBLISHED_API = "published_api"    # a published view over a business report

RUNNER_REPORT = "report"                   # _run_report_query (saved query / merged / union)
RUNNER_PIVOT = "pivot"                     # _run_pivot_report_query
RUNNER_RAW_SQL = "raw_sql"                 # _execute_raw_sql_report

#: what the viewer reads while the run waits for a pod (business_report_async_jobs.waiting_for)
WAITING_FOR_QUERY_POD = "query_pod"

#: Fields of the version store's definition that are NOT the plan: a rename
#: or a new description changes none of the SQL a run executes, and must not
#: throw the report's price history away.  Said once, here.
NOT_A_PLAN_FIELD = ("name", "description", "refresh_on_open")

#: The fields of a report row that ARE its plan: the ONE tuple the version
#: store snapshots (``core/reports/versions.py``) minus the fields above, plus
#: the data-version pin a run carries.  Counters, timestamps and lifecycle
#: live beside them on the same row and change without the plan changing.
DEFINITION_FIELDS = tuple(f for f in _VERSION_DEFINITION_FIELDS if f not in NOT_A_PLAN_FIELD) \
    + ("_data_version",)

#: the published view's generic failure sentence (api/published_views_api.py) --
#: kept identical so a run on a pod fails the way an inline one does
PUBLISHED_API_FAILED_MESSAGE = "Query execution failed — contact administrator"

#: a cancel reached the HTTP caller of a published view while its run was on a pod
PUBLISHED_API_CANCELLED_MESSAGE = "The request was cancelled before the report finished."

#: the run outlived jobqueue.run_timeout_seconds on its pod
RUN_TIMEOUT_MESSAGE = ("This report took longer than the time allowed for one run, so it was "
                       "stopped. Narrow the dates or filters, or ask an admin to raise the limit.")

#: the run's record (and its job) when the pod's work ended with something
#: that is not one of the queue's own sentences (a crash on the pod, a payload
#: an older build cannot read): the cause is in the pod's log, never on the
#: user's screen
DEAD_RUN_MESSAGE = ("The query pod running this report stopped before it finished. Press Run "
                    "again; if it happens again, ask an admin to check the query pods.")

#: a query pod the reports module is not wired in (another pod will take it)
NOT_WIRED_MESSAGE = "This query pod cannot run reports; another query pod will take this run."

#: the run's record (and its job) when a previous attempt's task never ended
#: on the pod that keeps claiming the retry: the job was given back
#: MAX_DEFERRALS times and nothing can run it (fourth review)
STUCK_RUN_MESSAGE = ("An earlier try of this report is still stopping on its query pod, so the "
                     "report could not be run again. Press Run again; if it happens again, ask "
                     "an admin to check the query pods.")

_POLL_SECONDS = 0.5
_RUN_WATCH_SECONDS = 1.0
_DRAIN_SECONDS = 30.0
#: how many times a claimer may GIVE BACK one job unrun (``JobDeferred``,
#: counted on the row) before the run is failed in plain words instead
MAX_DEFERRALS = 3
#: how long a given-back job stays unclaimable (``query_jobs.not_before``):
#: the pod that let go would otherwise take it straight back
_DEFER_DELAY_SECONDS = 2.0
#: how often the overlap wait asks the queue whether the job was cancelled
#: (a database read; the local liveness check between reads is free)
_WAIT_CANCEL_POLL_SECONDS = 1.0

#: how a real cancel, a lost lease and the run timeout are told apart
STOP_CANCEL, STOP_ZOMBIE, STOP_TIMEOUT = "cancel", "zombie", "timeout"

#: how many RUNNING records one reconcile pass reads (running ones are few)
_RECONCILE_BATCH = 500


# ═══════════════════════════════════════════════════════════════════════
# THE RUN AS DATA
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class ReportRun:
    """Everything one report run needs, captured at the API boundary --
    the resolved report, the filters and bindings the API built, the row
    limit it decided, the readiness verdict it computed, and the user the
    row security is for.  Nothing here is re-derived on the pod."""
    surface: str
    runner: str
    report_id: int
    report: Dict[str, Any]
    execution_id: str
    user: Dict[str, Any]
    role: str = "viewer"
    combined_filters: List[Any] = field(default_factory=list)
    source_bindings: List[Any] = field(default_factory=list)
    row_limit: int = 0
    param_values: Dict[str, Any] = field(default_factory=dict)
    limit_override: Optional[int] = None
    override_column_ids: Optional[List[int]] = None
    force_refresh: bool = False
    instance_cacheable: bool = False
    body: Optional[Dict[str, Any]] = None          # the execute-async request, as sent
    admission_username: str = ""                   # whose capacity slot (published API)
    readiness: Optional[Dict[str, Any]] = None     # the verdict decided at submit (to_dict)

    def payload(self) -> Dict[str, Any]:
        """The job row's request payload (JSON; ``default=str`` on the write
        turns a stray date into its text, which every runner accepts)."""
        return {
            "surface": self.surface, "runner": self.runner, "report_id": int(self.report_id),
            "report": dict(self.report or {}), "execution_id": str(self.execution_id),
            "role": str(self.role or "viewer"),
            "combined_filters": list(self.combined_filters or []),
            "source_bindings": list(self.source_bindings or []),
            "row_limit": int(self.row_limit or 0),
            "param_values": dict(self.param_values or {}),
            "limit_override": self.limit_override,
            "override_column_ids": list(self.override_column_ids) if self.override_column_ids else None,
            "force_refresh": bool(self.force_refresh),
            "instance_cacheable": bool(self.instance_cacheable),
            "body": dict(self.body) if self.body is not None else None,
            "admission_username": str(self.admission_username or ""),
            "readiness": dict(self.readiness) if isinstance(self.readiness, dict) else None,
        }

    def plan_payload(self) -> Dict[str, Any]:
        """What the run is PRICED by and remembered under: the definition,
        the filters, the bindings and the limit -- never the execution id,
        never the report's name."""
        rep = self.report or {}
        return {
            "kind": KIND, "runner": self.runner, "report_id": int(self.report_id),
            "definition": {k: rep.get(k) for k in DEFINITION_FIELDS if rep.get(k) not in (None, [], {}, "")},
            "combined_filters": list(self.combined_filters or []),
            "source_bindings": list(self.source_bindings or []),
            "row_limit": int(self.row_limit or 0),
            "param_values": dict(self.param_values or {}),
            "override_column_ids": list(self.override_column_ids) if self.override_column_ids else None,
        }

    @classmethod
    def from_payload(cls, payload: Dict[str, Any], user: Dict[str, Any]) -> "ReportRun":
        p = dict(payload or {})
        return cls(
            surface=str(p.get("surface") or ""), runner=str(p.get("runner") or ""),
            report_id=int(p.get("report_id") or 0), report=dict(p.get("report") or {}),
            execution_id=str(p.get("execution_id") or ""), user=user,
            role=str(p.get("role") or "viewer"),
            combined_filters=list(p.get("combined_filters") or []),
            source_bindings=list(p.get("source_bindings") or []),
            row_limit=int(p.get("row_limit") or 0),
            param_values=dict(p.get("param_values") or {}),
            limit_override=p.get("limit_override"),
            override_column_ids=list(p["override_column_ids"]) if p.get("override_column_ids") else None,
            force_refresh=bool(p.get("force_refresh")),
            instance_cacheable=bool(p.get("instance_cacheable")),
            body=dict(p["body"]) if isinstance(p.get("body"), dict) else None,
            admission_username=str(p.get("admission_username") or ""),
            readiness=dict(p["readiness"]) if isinstance(p.get("readiness"), dict) else None,
        )


# ═══════════════════════════════════════════════════════════════════════
# THE SWITCH, THE DECLARATION
# ═══════════════════════════════════════════════════════════════════════

def lane_enabled() -> bool:
    """THE switch, read once per run: ``query_pods.reports_lane`` AND sizes
    configured (a lane needs pods of a size) AND queue mode armed (nothing
    claims a job otherwise).  Any of the three off = the run stays where it is
    today.  Never raises."""
    try:
        from core import config as _cfg
        if not bool(_cfg.query_pods.reports_lane):
            return False
        from core.query_pods import budget as _budget
        if not _budget.pricing_enabled():
            return False
        from core.industrialization import is_enabled
        return bool(is_enabled("queue_mode"))
    except Exception as exc:
        logger.warning("[report-lane] switch unreadable, the run stays in this pod: %s", exc)
        return False


def _dataset_sql_texts(run: ReportRun, db) -> Optional[List[str]]:
    """The custom SQL texts the builder report reads (each dataset's
    ``base_query``), or None when one cannot be read (unknown = unsafe)."""
    ids = [i for i in (run.report.get("dataset_id"), run.report.get("merged_dataset_id")) if i]
    texts: List[str] = []
    for did in ids:
        try:
            ds = db.get_dataset(int(did))
        except Exception as exc:
            logger.debug("[report-lane] dataset %s unreadable for the retry rule: %s", did, exc)
            return None
        if not ds:
            return None
        sql = (ds or {}).get("base_query")
        if isinstance(sql, str) and sql.strip():
            texts.append(sql)
    return texts


def retry_declaration(run: ReportRun, *, read_attempts: int, db=None) -> tuple:
    """``(max_attempts, why)`` -- RETRY SAFETY IS A DECLARATION.  A builder
    report (saved query / pivot) renders SELECTs over its datasets, and a
    dataset may carry CUSTOM SQL (``base_query``): the report is a read only
    when every such text is PROVEN one (``db`` given); a dataset that cannot
    be read is unknown, and unknown = unsafe.  A raw-SQL report is a read only
    when its text is proven one; a text this module cannot see (a file or a
    saved query it would have to load) is unknown (one attempt)."""
    from core.jobqueue.retry_safety import classify_sql
    attempts = max(1, int(read_attempts))
    if run.runner in (RUNNER_REPORT, RUNNER_PIVOT):
        if db is None:
            return 1, "a builder report whose dataset SQL was not checked (no database)"
        texts = _dataset_sql_texts(run, db)
        if texts is None:
            return 1, "a builder report over a dataset that could not be read"
        for sql in texts:
            ok, why = classify_sql(sql)
            if not ok:
                return 1, f"a dataset's own SQL is not proven a read ({why})"
        return attempts, ("a builder report (its datasets' SQL proven reads)" if texts
                          else "a builder report (reads by construction)")
    if run.runner == RUNNER_RAW_SQL:
        sql = (run.report or {}).get("raw_sql_override")
        if isinstance(sql, str) and sql.strip():
            ok, why = classify_sql(sql)
            return (attempts if ok else 1), why
        return 1, "a raw-SQL report whose text is loaded at run time (not proven a read)"
    return 1, f"unknown runner {run.runner!r}"


# ═══════════════════════════════════════════════════════════════════════
# API SIDE
# ═══════════════════════════════════════════════════════════════════════

def enqueue_report_run(run: ReportRun) -> Optional[str]:
    """Price, route and enqueue ONE report run.  Returns the job id, or None
    when the one routing decision says the run stays in this pod (priced
    under ``query_pods.small_run_mb``, or pricing answered no size).  Raises
    ``TooBigForQueryPods`` when no size holds it, and anything else on a
    failure before a row exists (the callers fail open on those)."""
    from core.identity import derive_from_verified_user
    from core.jobqueue import execute_bridge as _eb

    # the user dict is the VERIFIED principal the route already holds (the
    # published view's copy carries the entitlement scope it stamps server
    # side) -- the same boundary the ad-hoc bridge crosses; fail-closed
    identity = derive_from_verified_user(run.user)
    db = _eb._api_db_manager()
    queue = get_job_queue(db)
    plan = run.plan_payload()
    # ONE pricer, scoped to this user's own runs of this report (the
    # security review's rule: never another identity's history)
    price = _eb._price_request(plan, db, rls_key="", rls_shareable=False,
                               username=identity.username)
    route = _eb.decide_route(price, plan)
    if route.where == _eb.ROUTE_INLINE or not price.pod_class:
        logger.info("[report-lane] %s run of report %s stays in this pod: %s",
                    run.surface, run.report_id, route.reason)
        return None
    max_attempts, why = retry_declaration(
        run, read_attempts=int(_eb._cfg_num("max_attempts", 2)), db=db)
    job_id = queue.enqueue(
        kind=KIND, request_payload=run.payload(), identity=identity,
        # row security is enforced INSIDE the engine by principal; the run
        # is never shared with another job (a per-job fail-closed key)
        rls_failure="a report run is enforced inside the engine by principal; never shared",
        max_attempts=max_attempts,
        pod_class=price.pod_class, price_bytes=int(price.bytes), price_source=price.source,
        plan_hash=compute_plan_hash(plan),
    )
    logger.info("[report-lane] %s run of report %s queued as job %s for size %s "
                "(%s, %d MB; %d attempt(s): %s)", run.surface, run.report_id, job_id,
                price.pod_class.upper(), price.source, int(price.bytes) // (1024 ** 2),
                max_attempts, why)
    return job_id


def maybe_enqueue_async_report(run: ReportRun) -> Optional[str]:
    """The execute-async route's branch (sync; the route calls it off the
    loop, and only once ``lane_enabled`` said yes).  None = run it here as
    today (routed inline, or any failure before a row exists -- loud, never
    silent).  A job id = the run is on the lane and the viewer's row says it
    is waiting for a pod.  Raises only ``TooBigForQueryPods`` (the route
    fails the run with the sentence)."""
    if not lane_enabled():
        return None
    try:
        job_id = enqueue_report_run(run)
    except TooBigForQueryPods:
        raise
    except Exception as exc:
        logger.error("[report-lane] enqueue of report %s failed -- FAIL-OPEN, the run "
                     "stays in this pod (it is NOT lost): %s", run.report_id, exc, exc_info=True)
        return None
    if job_id is None:
        return None
    _say_waiting(run.execution_id, job_id)
    return job_id


def _say_waiting(execution_id: str, job_id: str) -> None:
    """The run's own record names its job (its liveness is the job's lease
    from here; a cancel reaches the job) and says it waits for a query pod
    (the status route shows ``status_detail`` while ``waiting_for`` is set).
    ONLY while the record is still waiting (``status = 'running' AND attempt
    IS NULL``): a pod may already have claimed and stamped the run by the
    time this write lands, and a waiting sentence must never re-cover a
    started or finished record."""
    try:
        from core.jobqueue import execute_bridge as _eb
        row = get_job_queue().get(job_id) or {}
        # the queue's own sentence, the one the ad-hoc lane shows: "Waiting
        # for a query pod (size M) -- 2nd in line", or "No query pod of size
        # M is running right now. ..." when none is alive
        sentence = row.get("waiting") or "Waiting for a query pod"
        with _eb._api_db_manager().get_session() as session:
            n = session.execute(sa_text(
                "UPDATE business_report_async_jobs SET job_id = :job, waiting_for = :w, "
                "status_detail = :s WHERE id = :id AND status = 'running' AND attempt IS NULL"
            ), {"job": job_id, "w": WAITING_FOR_QUERY_POD, "s": sentence, "id": execution_id}).rowcount
        if n != 1:
            logger.info("[report-lane] run %s was already started or finished when its waiting "
                        "sentence arrived -- not written", execution_id)
    except Exception as exc:
        logger.warning("[report-lane] record of %s not linked to job %s: %s", execution_id, job_id, exc)


def waiting_for_a_pod_or_capacity(entry: Dict[str, Any]) -> bool:
    """What the status route reports as ``waiting_for_capacity``: a run waiting
    for the pod's capacity OR for a query pod of its size -- a query pod IS
    capacity, and the viewer shows the row's sentence for either."""
    return (entry or {}).get("waiting_for") in ("capacity", WAITING_FOR_QUERY_POD)


def cancel_job_of_record(entry: Dict[str, Any]) -> Optional[str]:
    """The viewer's cancel route reaches the JOB too (2026-11-03): a run
    cancelled while it waits in line must give its place and its size's
    demand back, not sit queued until a pod finds the record cancelled.
    Returns the queue's answer, None when the record has no job.  Never
    raises (the record's cancel already landed)."""
    job_id = (entry or {}).get("job_id")
    if not job_id:
        return None
    try:
        return get_job_queue().cancel(str(job_id))
    except Exception as exc:
        logger.warning("[report-lane] job %s of run %s not cancelled: %s",
                       job_id, (entry or {}).get("execution_id"), exc)
        return None


async def run_published_api_or_inline(run: ReportRun,
                                      inline: Callable[[], Any]) -> Any:
    """The published-view handler's branch.  Switch off, routed inline, or a
    failure before a row exists -> ``await inline()`` (the handler's own
    admitted call, exactly as today).  Otherwise the run is queued and this
    coroutine waits for the pod's result -- never running it here once a row
    exists.  Errors come back with HTTP parity: what the runner would have
    raised inline (status, detail, headers), the queue's plain sentences as
    503, anything else the handler's own generic sentence.  A caller that
    goes away while the enqueue is in flight still cancels the job it made."""
    from fastapi import HTTPException

    if not lane_enabled():
        return await inline()
    loop = asyncio.get_running_loop()
    fut = loop.run_in_executor(None, enqueue_report_run, run)
    try:
        job_id = await asyncio.shield(fut)
    except asyncio.CancelledError:
        # the enqueue thread keeps going: whatever row it makes is cancelled
        fut.add_done_callback(_cancel_job_when_enqueued)
        raise
    except TooBigForQueryPods as too_big:
        logger.info("[report-lane] published-API run of report %s refused, too big for every "
                    "query pod: %s", run.report_id, too_big.price.as_dict())
        raise HTTPException(status_code=413, detail=str(too_big))
    except Exception as exc:
        logger.error("[report-lane] enqueue of the published-API run of report %s failed -- "
                     "FAIL-OPEN to this pod (the run is NOT lost): %s", run.report_id, exc,
                     exc_info=True)
        return await inline()
    if job_id is None:
        return await inline()
    return await _await_published_api_result(job_id)


def _cancel_job_when_enqueued(fut) -> None:
    try:
        job_id = fut.result()
    except Exception:
        return
    if job_id:
        logger.info("[report-lane] the caller went away while job %s was being queued: cancelled", job_id)
        _cancel_quietly(get_job_queue(), job_id)


async def _await_published_api_result(job_id: str) -> Dict[str, Any]:
    """Wait for the pod's result (the job's relayed response: execution id,
    row count, column names) and resolve the artifact path SERVER SIDE from
    the ``federation_executions`` row the pod wrote -- the path never rides
    the jobs API.  Parity: the runner's HTTP errors are re-raised as they
    were (status, detail, headers), a queue sentence (pod died, no pod of the
    size) is a 503 in those words, and a cancel of THIS request (the client
    went away) cancels the job so the pod stops.  Bounded by
    ``jobqueue.run_timeout_seconds``."""
    from fastapi import HTTPException
    from core.jobqueue import execute_bridge as _eb

    queue = get_job_queue()
    deadline = time.monotonic() + max(60.0, float(_eb._cfg_num("run_timeout_seconds", 7200)))
    try:
        while True:
            job = await asyncio.to_thread(_eb._safe_get, queue, job_id)
            if job is not None:
                status = job.get("status")
                if status == "succeeded" and job.get("response_json"):
                    resp = _eb._parse_json(job["response_json"])
                    handle = str((resp or {}).get("execution_id") or job.get("result_handle") or "")
                    path = await asyncio.to_thread(_artifact_path_of, handle) if handle else None
                    if isinstance(resp, dict) and path:
                        return {**resp, "output_path": path}
                    logger.error("[report-lane] job %s succeeded but its artifact path is unknown "
                                 "(execution %r)", job_id, handle)
                    raise HTTPException(500, PUBLISHED_API_FAILED_MESSAGE)
                if status == "failed":
                    raise _published_api_failure(job, HTTPException)
                if status == "cancelled":
                    raise HTTPException(409, PUBLISHED_API_CANCELLED_MESSAGE)
            if time.monotonic() >= deadline:
                await asyncio.to_thread(_cancel_quietly, queue, job_id)
                raise HTTPException(504, "The report did not finish on a query pod within the "
                                         "time allowed, so it was stopped.")
            await asyncio.sleep(_POLL_SECONDS)
    except asyncio.CancelledError:
        # the caller is gone: the pod must not keep working for nobody
        await asyncio.to_thread(_cancel_quietly, queue, job_id)
        raise


def _artifact_path_of(execution_id: str) -> Optional[str]:
    """The artifact path of a finished run, from the server-side execution
    row (``federation_executions``): written by the runner for a raw-SQL
    report and by the pod handler for a builder one."""
    from core.jobqueue import execute_bridge as _eb
    try:
        row = _eb._api_db_manager().get_federation_execution(execution_id) or {}
    except Exception as exc:
        logger.warning("[report-lane] execution row of %s unreadable: %s", execution_id, exc)
        return None
    path = row.get("output_path")
    return str(path) if path else None


def _cancel_quietly(queue, job_id: str) -> None:
    try:
        queue.cancel(job_id)
    except Exception as exc:
        logger.warning("[report-lane] job %s not cancelled: %s", job_id, exc)


def _published_api_failure(job: Dict[str, Any], http_exception_cls):
    """A failed job as the HTTPException the inline handler would raise."""
    from core.jobqueue import execute_bridge as _eb
    err = str(job.get("error") or "")
    parsed = _eb._parse_json(err)
    if isinstance(parsed, dict) and "__http__" in parsed:
        return _eb._relay_failure_http(job, http_exception_cls)
    if err == PUBLISHED_API_FAILED_MESSAGE:
        return http_exception_cls(status_code=500, detail=err)      # the handler's own 500
    if _is_queue_sentence(err):
        return http_exception_cls(status_code=503, detail=err)
    return http_exception_cls(status_code=500, detail=PUBLISHED_API_FAILED_MESSAGE)


def _is_queue_sentence(error: str) -> bool:
    """The plain-words sentences the QUEUE (or this module) writes -- a pod
    died, no pod of the size, stopped at its reservation, the run timeout,
    the fixed dead-run sentence, the generic failure: safe to show a person
    as they are."""
    from core.jobqueue.queue import POD_DIED_NOT_RETRIED_MESSAGE, POD_DIED_TWICE_MESSAGE
    text = str(error or "")
    return (text in (POD_DIED_NOT_RETRIED_MESSAGE, POD_DIED_TWICE_MESSAGE, RUN_TIMEOUT_MESSAGE,
                     DEAD_RUN_MESSAGE, PUBLISHED_API_FAILED_MESSAGE, PUBLISHED_API_CANCELLED_MESSAGE,
                     STUCK_RUN_MESSAGE)
            or text.startswith("No query pod of size")
            or "set aside for it" in text)


def public_error(job: Dict[str, Any]) -> Optional[str]:
    """A report job's ``error`` as the jobs API may show it to the person who
    enqueued it (CWE-209): a relayed HTTP error as it is (the runner's own
    400 / 403 / 503 words), one of the plain sentences as it is, anything
    else -- a crash text, a traceback, a driver's SQL -- the fixed dead-run
    sentence.  None stays None."""
    err = job.get("error")
    if not err:
        return err
    text = str(err)
    from core.jobqueue import execute_bridge as _eb
    parsed = _eb._parse_json(text)
    if isinstance(parsed, dict) and "__http__" in parsed:
        return text
    if _is_queue_sentence(text) or text.startswith("cancelled") or "requeued by orphan reaper" in text:
        return text
    return DEAD_RUN_MESSAGE


# ═══════════════════════════════════════════════════════════════════════
# EXECUTOR SIDE
# ═══════════════════════════════════════════════════════════════════════

def handle_execute_report(job: ClaimedJob, ctx: JobContext) -> Optional[str]:
    """Run one queued report run through the EXISTING runners, on the bridge
    loop, inside the job's memory reservation.

    execute-async surface: the run's own record (``business_report_async_jobs``,
    the row the viewer polls) is the contract -- the runner writes it exactly
    as the reports pod would, and this handler reads it back for the job's
    verdict.  The record is FENCED BY ATTEMPT: this attempt's number is
    stamped on it first (only over an older one), and every terminal write
    carries it, so a pod that lost its lease while this one runs the retry
    can no longer write.  A RETRY finds the record first: already finished ->
    nothing is run again; cancelled -> stop; still running -> the same
    execution id is run again.
    published-API surface: the runner's result (execution id, row count,
    column names) is relayed as the job's response for the waiting handler;
    the artifact path goes on the execution row, server side.

    EVERY exception not classified below leaves as ONE plain sentence
    (``NonRetryableJobError``): the job is not run again for a crash that was
    not the engine's, and the consumer never reads a traceback or a driver's
    SQL through the jobs API.  The one retryable case: this pod has no
    reports module wired -- another pod will take the run."""
    import api.business_reports_api as _br

    if _br._db_manager is None or _br._federation_engine is None:
        # retryable (another pod may be wired); the sentence is the public one
        raise RuntimeError(NOT_WIRED_MESSAGE)
    surface = str((job.request or {}).get("surface") or "")
    generic = PUBLISHED_API_FAILED_MESSAGE if surface == SURFACE_PUBLISHED_API else DEAD_RUN_MESSAGE
    try:
        user = ctx.user_dict()
        run = ReportRun.from_payload(job.request or {}, user)
        if run.surface not in (SURFACE_REPORT_ASYNC, SURFACE_PUBLISHED_API) or not run.execution_id:
            raise NonRetryableJobError(f"report job payload is not one this build runs "
                                       f"(surface {run.surface!r})")
        if ctx.cancel_requested():
            raise JobCancelled("cancelled before the report started")
        if run.surface == SURFACE_REPORT_ASYNC:
            return _run_async_surface(job, ctx, run, _br)
        return _run_published_api_surface(job, ctx, run, _br)
    except (JobCancelled, JobDeferred, JobHttpError, NonRetryableJobError):
        raise
    except Exception as exc:
        logger.error("[report-lane] job %s (report %s, %s) crashed outside the engine on this pod: %s",
                     job.id, (job.request or {}).get("report_id"), surface or "?", exc, exc_info=True)
        if surface == SURFACE_REPORT_ASYNC:
            _close_record_after_crash(_br, job)
        raise NonRetryableJobError(generic)


def _close_record_after_crash(_br, job: ClaimedJob) -> None:
    """The execute-async record after a crash outside the runner: failed
    with the plain sentence, through the door (a record the runner already
    finished is left as it is).  Never raises."""
    eid = str((job.request or {}).get("execution_id") or "")
    if not eid:
        return
    try:
        _br._finalize_br_async_job_guarded(_br._db_manager, eid, attempt=int(job.attempts or 1),
                                           status="failed", error=DEAD_RUN_MESSAGE)
    except Exception as exc:
        logger.warning("[report-lane] record of %s not closed after the crash: %s", eid, exc)


def _stop_reason(ctx: JobContext) -> Optional[str]:
    """Why this run must stop, if it must: a lost lease (zombie -- another
    pod may be running the retry: stop local work, write nothing) or a real
    cancel of the job.  None = keep going."""
    if ctx.is_zombie:
        return STOP_ZOMBIE
    try:
        if ctx.queue.is_cancel_requested(ctx.job.id):
            return STOP_CANCEL
    except Exception:
        return None            # unreadable flag: keep working, the lease protects us
    return None


#: the local tasks THIS process is running, by execution id -- the future of
#: the attempt's coroutine and WHEN it started, kept until it is really done
#: (the guard below)
_LOCAL_RUNS: Dict[str, Tuple[Any, float]] = {}
_LOCAL_RUNS_LOCK = threading.Lock()
#: how long a new attempt waits for the previous one's local task to end
#: before it gives the job back (the zombie's engine was told to stop at
#: once; its drain is 30 s)
_OVERLAP_WAIT_SECONDS = 60.0


def _abandoned_after_seconds() -> float:
    """A registered coroutine older than the run timeout plus its drain is
    no longer a live task the guard waits for: its engine ignored the stop
    (fourth review -- the registry had no timer, so one hung coroutine kept
    every retry of its execution waiting for ever).  The pool's own index
    (below) is not timed: it IS the slot."""
    from core.jobqueue import execute_bridge as _eb
    return float(_eb._cfg_num("run_timeout_seconds", 7200)) + _DRAIN_SECONDS


def _local_task_alive(execution_id: str) -> bool:
    """A live local task for ``execution_id`` in THIS process: the attempt's
    coroutine registered below (unless abandoned past the timer), or a
    worker-pool task carrying the id (the pool's index is one slot per id --
    the thing the guard protects)."""
    with _LOCAL_RUNS_LOCK:
        entry = _LOCAL_RUNS.get(execution_id)
    if entry is not None and not entry[0].done():
        if time.monotonic() - float(entry[1]) <= _abandoned_after_seconds():
            return True
        logger.warning("[report-lane] the local task of run %s is older than the run timeout and "
                       "still not done: no longer waited for", execution_id)
    try:
        from core.worker_pool import get_pool
        return get_pool().get_cancel_event(execution_id) is not None
    except Exception:
        return False                # no pool here: only the registry counts


def _wait_for_local_task_to_end(execution_id: str, attempt: int, job: ClaimedJob, ctx: JobContext,
                                *, on_cancel: Optional[Callable[[], None]] = None,
                                on_stuck: Optional[Callable[[], bool]] = None) -> None:
    """Attempt ``attempt`` may not start while another attempt of the same
    execution still has a live local task here.  Waits (bounded), then
    gives the job back untouched (``JobDeferred``: the attempt is handed
    back, the job unclaimable for ``_DEFER_DELAY_SECONDS``) -- or, once the
    job has been given back ``MAX_DEFERRALS`` times, fails it in plain
    words (``on_stuck`` closes the run's own record first; it answers False
    when the record turns out to have ENDED meanwhile -- the previous
    attempt finished it and only its coroutine is still draining -- and the
    wait then simply returns, so the caller reads the finished record and
    takes its normal path instead of failing a completed run).  A cancel of
    the job that arrives DURING the wait ends it at once (``JobCancelled``;
    ``on_cancel`` closes the record): the viewer who pressed Cancel is not
    kept waiting on a wait.  A claimer that loses its lease while waiting
    stops too, writing nothing.

    What the wait costs (fourth review, accepted): the claimer's lease is
    heartbeated while it waits, so an attempt is spent only if the lease
    is reaped during the wait -- then the reaper's re-queue counts it,
    bounded like any other attempt by ``max_attempts``."""
    deadline = time.monotonic() + _OVERLAP_WAIT_SECONDS
    waited = False
    next_poll = 0.0
    while _local_task_alive(execution_id):
        if not waited:
            logger.info("[report-lane] attempt %d of run %s waits: a previous attempt's task is "
                        "still live in this process", attempt, execution_id)
            waited = True
        stopped = None
        if time.monotonic() >= next_poll:              # the queue is asked once a second
            stopped = _stop_reason(ctx)
            next_poll = time.monotonic() + _WAIT_CANCEL_POLL_SECONDS
        if stopped == STOP_ZOMBIE:
            raise JobCancelled(f"this pod lost its lease on report run {execution_id} while waiting "
                               "for a previous attempt to end")
        if stopped == STOP_CANCEL:
            if on_cancel is not None:
                on_cancel()
            raise JobCancelled(f"cancelled while waiting for a previous attempt of report run "
                               f"{execution_id} to end")
        if time.monotonic() >= deadline:
            if int(job.deferrals or 0) >= MAX_DEFERRALS:
                logger.error("[report-lane] run %s: attempt %d given back %d times already and a "
                             "previous attempt's task still lives here -- failed in plain words",
                             execution_id, attempt, int(job.deferrals or 0))
                if on_stuck is not None and not on_stuck():
                    return                          # not stuck: the record ended meanwhile
                raise NonRetryableJobError(STUCK_RUN_MESSAGE)
            raise JobDeferred(f"a previous attempt of report run {execution_id} is still ending in "
                              f"this process; attempt {attempt} is given back to the queue",
                              delay_seconds=_DEFER_DELAY_SECONDS)
        time.sleep(0.2)


def _run_on_bridge_loop(job: ClaimedJob, ctx: JobContext, coro_factory: Callable[[], Any],
                        execution_id: str, *, on_stop: Callable[[str], None]) -> Any:
    """Drive one coroutine on the executor's persistent loop inside the
    reservation scope, watching for the three reasons to stop early.
    ``on_stop(reason)`` stops the work the way that reason requires; the
    coroutine is then DRAINED (bounded) and the reservation is kept until it
    is really done -- a run still holding memory is never counted as free.
    Returns the coroutine's result; raises JobCancelled for a cancel or a
    lost lease, NonRetryableJobError for the timeout."""
    from core.jobqueue import execute_bridge as _eb
    from core.query_pods.budget import forget_reservation, note_reservation, reservation_scope

    reserved = int(job.reserved_bytes or 0)
    owner = f"{job.id}/{int(job.attempts or 1)}"     # THIS attempt's note, not the execution's
    if reserved:
        note_reservation(execution_id, reserved, owner=owner)

    async def _inside():
        if reserved <= 0:
            return await coro_factory()
        with reservation_scope(reserved):
            return await coro_factory()

    loop = _eb._get_bridge_loop()
    deadline = time.monotonic() + float(_eb._cfg_num("run_timeout_seconds", 7200))
    fut = asyncio.run_coroutine_threadsafe(_inside(), loop)
    with _LOCAL_RUNS_LOCK:
        _LOCAL_RUNS[execution_id] = (fut, time.monotonic())   # live here until the coroutine really ends

    def _forget_run(_f):
        with _LOCAL_RUNS_LOCK:
            cur = _LOCAL_RUNS.get(execution_id)
            if cur is not None and cur[0] is fut:
                _LOCAL_RUNS.pop(execution_id, None)
    fut.add_done_callback(_forget_run)
    try:
        while True:
            try:
                return fut.result(timeout=_RUN_WATCH_SECONDS)
            except (TimeoutError, asyncio.TimeoutError):
                pass
            stopped = _stop_reason(ctx)
            if stopped is None and time.monotonic() >= deadline:
                stopped = STOP_TIMEOUT
            if stopped is None:
                continue
            try:
                on_stop(stopped)
            except Exception as exc:
                logger.warning("[report-lane] stop (%s) of %s not delivered: %s",
                               stopped, execution_id, exc)
            _drain(fut, execution_id)
            if stopped == STOP_TIMEOUT:
                raise NonRetryableJobError(RUN_TIMEOUT_MESSAGE)
            if stopped == STOP_ZOMBIE:
                raise JobCancelled(f"this pod lost its lease on report run {execution_id}; "
                                   "another pod may be running it")
            raise JobCancelled(f"cancelled while running report run {execution_id}")
    finally:
        if reserved and fut.done():
            forget_reservation(execution_id, owner=owner)
        elif reserved:
            logger.warning("[report-lane] run %s is still going after its stop: its reservation "
                           "stays noted until it ends", execution_id)
            # only THIS attempt's note: by the time this fires, a retry of
            # the same execution may have noted its own (fourth review)
            fut.add_done_callback(lambda _f: forget_reservation(execution_id, owner=owner))


def _drain(fut, execution_id: str) -> None:
    """Wait (bounded) for the stopped coroutine to really end."""
    try:
        fut.result(timeout=_DRAIN_SECONDS)
    except Exception as exc:
        logger.info("[report-lane] run %s after its stop: %s", execution_id, type(exc).__name__)


def _stamp_attempt(db, execution_id: str, attempt: int, job_id: str) -> bool:
    """THIS attempt takes the record -- only over NO attempt or an OLDER one
    (``attempt IS NULL OR attempt < :mine``) and only while it runs; the
    waiting sentence goes with it.  False = a newer attempt already owns the
    record (this one stalled past its lease before it got here) or the
    record is no longer running: nothing of this attempt may run."""
    with db.get_session() as session:
        n = session.execute(sa_text(
            "UPDATE business_report_async_jobs SET attempt = :a, job_id = :j, waiting_for = NULL, "
            "status_detail = NULL WHERE id = :id AND status = 'running' "
            "AND (attempt IS NULL OR attempt < :a)"
        ), {"a": int(attempt), "j": job_id, "id": execution_id}).rowcount
    return n == 1


def _run_async_surface(job: ClaimedJob, ctx: JobContext, run: ReportRun, _br) -> Optional[str]:
    from core.jobqueue import execute_bridge as _eb

    db = _br._db_manager
    eid = run.execution_id
    attempt = int(job.attempts or 1)
    # NEVER TWO ATTEMPTS OF ONE EXECUTION IN ONE PROCESS (third review): every
    # local handle -- the pool task, the capacity wait, the cancel event --
    # is keyed by the execution id, and the pool's index is one slot per id,
    # so attempt N+1 may not start here while attempt N's task still lives
    # (a zombie's engine, told to stop, may take a while to end).  Wait a
    # bounded time; then give the job back WITHOUT spending the attempt.
    # The record is read AFTER the wait: the previous attempt may have
    # finished it meanwhile, and a finished record is never run again.
    from core.cancel_router import signal_local_cancel as _signal_local_cancel

    def _cancelled_while_waiting():
        # the job's cancel reached us during the wait: THIS attempt takes
        # the record (the door refuses a write by an attempt that is not the
        # owner's, and a fence on the previous attempt refuses an unnumbered
        # one) and ends it cancelled through the door; the previous
        # attempt's local task is told to stop.  A record no longer running
        # (the viewer's cancel route wrote it already) is left as it is.
        if _stamp_attempt(db, eid, attempt, job.id):
            _br._finalize_br_async_job_guarded(db, eid, attempt=attempt, status="cancelled")
        _signal_local_cancel(eid)

    def _stuck_here() -> bool:
        # given back MAX_DEFERRALS times and the old task still lives: THIS
        # (newer) attempt takes the record (the door refuses a write by an
        # attempt that is not the owner's) and fails it in plain words, so
        # the stuck attempt's own late write cannot replace it; then the
        # stuck task is told to stop.  A record that ENDED meanwhile (the
        # previous attempt finished it; only its coroutine is draining) is
        # not stuck at all -- False, and the caller takes its normal path
        # (fifth review: the job used to fail while the record completed).
        if _stamp_attempt(db, eid, attempt, job.id):
            _br._finalize_br_async_job_guarded(db, eid, attempt=attempt, status="failed",
                                               error=STUCK_RUN_MESSAGE)
            _signal_local_cancel(eid)
            return True
        current = db.get_br_async_job(eid) or {}
        if str(current.get("status") or "") in ("completed", "failed", "cancelled"):
            return False
        _signal_local_cancel(eid)
        return True
    _wait_for_local_task_to_end(eid, attempt, job, ctx, on_cancel=_cancelled_while_waiting,
                                on_stuck=_stuck_here)
    row = db.get_br_async_job(eid)
    if row is None:
        raise NonRetryableJobError(
            f"the record of report run {eid} is gone, so nothing was run")
    status = str(row.get("status") or "")
    if status == "cancelled":
        raise JobCancelled(f"report run {eid} was cancelled before it started")
    if status in ("completed", "failed"):
        # a retry after the first pod finished the run just before it died:
        # the record is the truth, nothing is run twice
        logger.info("[report-lane] job %s attempt %d: report run %s already %s -- not run again",
                    job.id, attempt, eid, status)
        if status == "failed":
            raise NonRetryableJobError(str(row.get("error") or f"report run {eid} failed"))
        return eid
    if not _stamp_attempt(db, eid, attempt, job.id):
        raise JobCancelled(f"report run {eid} is owned by a newer attempt than {attempt}; "
                           "nothing of this one runs")
    ctx.stamp_response({"execution_id": eid, "status": "running", "attempt": attempt}, eid)
    # the run is live in THIS process (the orphan rule and the result route
    # read the cache), exactly as the route does before its background task
    _br._br_cache_set(eid, {"report_id": run.report_id, "result": None})

    body = _br.AsyncExecuteRequest(**(run.body or {}))
    fed = _br._federation_engine

    def _factory():
        if run.runner == RUNNER_RAW_SQL:
            return _br._run_async_raw_sql_job(
                db=db, report=run.report, report_id=run.report_id, body=body, user=run.user,
                execution_id=eid, instance_cacheable=run.instance_cacheable,
                attempt=attempt, readiness=run.readiness)
        return _br._run_async_report_job(
            db=db, fed=fed, report=run.report, report_id=run.report_id, body=body,
            user=run.user, execution_id=eid, combined_filters=run.combined_filters,
            source_bindings=run.source_bindings, row_limit=run.row_limit,
            instance_cacheable=run.instance_cacheable, attempt=attempt, readiness=run.readiness)

    def _on_stop(reason: str):
        from core.cancel_router import signal_local_cancel
        if reason == STOP_CANCEL:
            # the same two writes the viewer's cancel route makes, on THIS pod,
            # through the guarded door with this attempt's number
            _br._finalize_br_async_job_guarded(db, eid, attempt=attempt, status="cancelled")
        elif reason == STOP_TIMEOUT:
            _br._finalize_br_async_job_guarded(db, eid, attempt=attempt, status="failed",
                                               error=RUN_TIMEOUT_MESSAGE)
        else:
            # a lost lease (zombie): FENCE FIRST -- the engine, told to stop,
            # raises in the runner, whose own failure write must not reach a
            # record another pod may already own; then stop the local work
            _br.fence_execution(eid, attempt)
        signal_local_cancel(eid)              # only this attempt runs here (the guard above)

    _run_on_bridge_loop(job, ctx, _factory, eid, on_stop=_on_stop)

    after = db.get_br_async_job(eid) or {}
    if after.get("attempt") not in (None, attempt):
        raise JobCancelled(f"report run {eid} is owned by attempt {after.get('attempt')} now")
    final = str(after.get("status") or "")
    if final == "completed":
        _eb._record_actual_peak(job, ctx, eid, failed_with=None)
        return eid
    if final == "cancelled":
        _eb._record_actual_peak(job, ctx, eid, failed_with=None)
        raise JobCancelled(f"report run {eid} was cancelled")
    error = str(after.get("error") or f"report run {eid} did not finish")
    _eb._record_actual_peak(job, ctx, eid, failed_with=error)
    if job.reserved_bytes and _eb._looks_like_out_of_memory(error):
        error = _eb.over_budget_message(job)
        try:
            db.update_br_async_job(eid, error=error)
        except Exception as exc:
            logger.warning("[report-lane] could not reword run %s: %s", eid, exc)
    raise NonRetryableJobError(error)


def _http_error_for(exc: BaseException) -> Optional[JobHttpError]:
    """The HTTPException the inline published-view handler would have raised
    for ``exc``, as a JobHttpError (status, detail, headers) -- or None when
    the handler's answer is its generic 500.  THE SAME classifiers the
    handler calls: ``ReportAdmissionRefused.as_http`` (Retry-After; a 409
    for a wait the caller cancelled), ``raise_if_self_clearing`` (an open
    circuit breaker 503 in its own words, a scan refusal 422), row security
    refused 403."""
    from fastapi import HTTPException
    from core.reports.admission import ReportAdmissionRefused
    if isinstance(exc, JobHttpError):
        return exc
    if isinstance(exc, HTTPException):
        return JobHttpError(exc.status_code, exc.detail, headers=getattr(exc, "headers", None))
    if isinstance(exc, ReportAdmissionRefused):
        he = exc.as_http()
        return JobHttpError(he.status_code, he.detail, headers=getattr(he, "headers", None))
    from core.row_security.api import RowSecurityRefused
    if isinstance(exc, RowSecurityRefused):
        return JobHttpError(403, f"Row-security policy enforcement failed: {exc}")
    try:
        from api.connector_errors import raise_if_self_clearing
        raise_if_self_clearing(exc)
    except HTTPException as he:
        return JobHttpError(he.status_code, he.detail, headers=getattr(he, "headers", None))
    except Exception:
        pass
    return None


def _run_published_api_surface(job: ClaimedJob, ctx: JobContext, run: ReportRun, _br) -> Optional[str]:
    from core.jobqueue import execute_bridge as _eb
    from core.reports.admission import run_admitted
    from core.worker_pool import WorkType

    db, fed = _br._db_manager, _br._federation_engine
    eid = run.execution_id
    attempt = int(job.attempts or 1)
    from core.cancel_router import signal_local_cancel as _signal_local_cancel

    def _stop_the_old_task() -> bool:
        # fifth review: the stuck (or cancelled) previous attempt's task is
        # told to stop, so it cannot later reach the artifact write (which
        # is fenced by the job's current token anyway); there is no record
        # to close on this surface, so a stuck wait is always stuck
        _signal_local_cancel(eid)
        return True
    _wait_for_local_task_to_end(eid, attempt, job, ctx, on_cancel=_stop_the_old_task,
                                on_stuck=_stop_the_old_task)   # never two attempts here at once
    ctx.stamp_response({"execution_id": eid, "status": "running", "attempt": attempt}, eid)
    username = run.admission_username or run.user.get("username") or ""

    def _factory():
        from core.reports.pagination import artifact_attempt_scope

        async def _go():
            # the attempt is declared INSIDE the coroutine (fourth review: a
            # ``with`` around the un-awaited call had left the scope before
            # the engine ran, so a retry wrote the first attempt's file name)
            with artifact_attempt_scope(attempt):            # the file is per attempt
                if run.runner == RUNNER_RAW_SQL:
                    return await run_admitted(
                        WorkType.PUBLISHED_API, _br._execute_raw_sql_report,
                        run.report, dict(run.param_values or {}), run.row_limit, run.report_id, db,
                        run.role, run.user, execution_id=eid, username=username)
                return await run_admitted(
                    WorkType.PUBLISHED_API, _br._run_report_query,
                    fed, run.report, list(run.combined_filters or []), run.row_limit, eid, run.role,
                    user_ctx=run.user, source_bindings=run.source_bindings or None,
                    execution_id=eid, username=username)
        return _go()

    def _on_stop(reason: str):
        from core.cancel_router import signal_local_cancel
        signal_local_cancel(eid)

    try:
        result = _run_on_bridge_loop(job, ctx, _factory, eid, on_stop=_on_stop)
    except (JobCancelled, NonRetryableJobError):
        _eb._record_actual_peak(job, ctx, eid, failed_with=None)
        raise
    except Exception as exc:
        http = _http_error_for(exc)
        if http is not None:
            _eb._record_actual_peak(job, ctx, eid, failed_with=str(http.detail))
            raise http
        from core.error_sanitizer import sanitize_error
        error = sanitize_error(str(exc))
        _eb._record_actual_peak(job, ctx, eid, failed_with=error)
        if job.reserved_bytes and _eb._looks_like_out_of_memory(error):
            raise NonRetryableJobError(_eb.over_budget_message(job))
        # the cause stays HERE, in the pod's log; the consumer reads the
        # handler's generic sentence (CWE-209: the row is theirs to read)
        logger.error("[report-lane] published-API run of report %s (job %s) failed on this pod: %s",
                     run.report_id, job.id, error, exc_info=True)
        raise NonRetryableJobError(PUBLISHED_API_FAILED_MESSAGE)
    resp = result.to_dict() if hasattr(result, "to_dict") else result
    if not isinstance(resp, dict) or not resp.get("output_path"):
        raise NonRetryableJobError(PUBLISHED_API_FAILED_MESSAGE)
    handle = str(resp.get("execution_id") or eid)
    # the artifact's row and the relay: a database error here is a crash
    # outside the engine -- the handler turns it into the plain sentence
    _record_artifact(db, handle, run, resp, job=job)
    # what the waiting handler needs, and ALL the consumer may read back
    # through the jobs API: never the SQL, never the path
    ctx.stamp_response({"execution_id": handle, "total_rows": resp.get("total_rows"),
                        "columns": json.loads(json.dumps(resp.get("columns"), default=str))}, handle)
    _eb._record_actual_peak(job, ctx, eid, failed_with=None)
    return handle


def _record_artifact(db, execution_id: str, run: ReportRun, resp: Dict[str, Any], *,
                     job: ClaimedJob) -> None:
    """The artifact path on the server-side execution row (the raw-SQL
    runner already writes its own; a builder run gets one here), where the
    waiting handler reads it.  Raises when it cannot be written: a result
    nobody can locate is a failure, not a success.

    FENCED (fifth review): the row is written in ONE statement that holds
    only while ``job``'s fencing token is the job's current live lease --
    a zombie attempt whose lease was reaped (another pod runs the retry)
    writes nothing and leaves as JobCancelled, so its finished file can
    never become the row's answer beside the retry's partial one."""
    row = db.get_federation_execution(execution_id)
    if row is None:
        db.create_federation_execution(
            execution_id=execution_id, dataset_id=int(run.report.get("dataset_id") or 0),
            report_id=run.report_id, sql_generated="", column_ids=[],
            executed_by=str(run.user.get("username") or ""))
    with db.get_session() as session:
        n = session.execute(sa_text(
            "UPDATE federation_executions SET status = 'completed', output_path = :p, "
            "total_rows = :n, duration_seconds = :d WHERE execution_id = :e AND EXISTS ("
            "SELECT 1 FROM query_jobs WHERE id = :j AND fencing_token = :t "
            "AND status IN ('leased', 'running'))"
        ), {"p": str(resp["output_path"]), "n": resp.get("total_rows"),
            "d": resp.get("duration_seconds"), "e": execution_id,
            "j": job.id, "t": int(job.fencing_token)}).rowcount
    if n != 1:
        raise JobCancelled(f"this pod lost its lease on report run {execution_id} before its "
                           "artifact was recorded; another pod may be running it")


# ═══════════════════════════════════════════════════════════════════════
# A DEAD JOB'S VERDICT REACHES THE RUN'S OWN RECORD (one rule, two roads)
# ═══════════════════════════════════════════════════════════════════════

def record_verdict_from_job(db_manager, row: Dict[str, Any]) -> Optional[bool]:
    """THE rule for a RUNNING record that names a job (``job_id``):

      * the job is LIVE (queued / leased / running / attached) -> ``False``:
        leave the record alone, its lease is its liveness (the caller's
        clock does not apply);
      * the job ENDED (failed / cancelled / succeeded with the record still
        running) -> the record gets the job's verdict NOW through the guarded
        door and the result is returned (True = written);
      * the job is GONE (no row) -> ``None``: the caller's clock decides, as
        for a run before the lane.

    The queue's own sentences are copied as they are; any other job error (a
    crash, a payload an older build cannot read) becomes the fixed dead-run
    sentence and the detail is logged.  Called by the orphan rule on the one
    record a poll just read (a backstop that needs no sweeper) and by the
    sweep over every running record.  Never raises."""
    from core.jobqueue.queue import JobQueue
    eid = str((row or {}).get("execution_id") or "")
    job_id = str((row or {}).get("job_id") or "")
    if not eid or not job_id:
        return None
    try:
        job = JobQueue(db_manager).get(job_id)
    except Exception as exc:
        logger.debug("[report-lane] job %s of run %s unreadable: %s", job_id, eid, exc)
        return None
    if not job:
        return None
    status = str(job.get("status") or "")
    if status in ("queued", "leased", "running", "attached"):
        return False               # live: the record is left alone, the clock too
    try:
        import api.business_reports_api as _br
        if status == "cancelled":
            return _br._finalize_br_async_job_guarded(db_manager, eid, status="cancelled")
        raw = str(job.get("error") or "").strip()
        if status == "succeeded" and not raw:
            # the job finished but the record was never closed (the pod
            # died between the two): nobody can serve it -- said in words
            raw = DEAD_RUN_MESSAGE
        if _is_queue_sentence(raw):
            error = raw
        else:
            error = DEAD_RUN_MESSAGE
            logger.warning("[report-lane] run %s: its job %s ended with a detail the record will "
                           "not carry: %s", eid, job_id, raw[:300])
        return _br._finalize_br_async_job_guarded(db_manager, eid, status="failed", error=error)
    except Exception as exc:
        logger.warning("[report-lane] record of %s not reconciled with job %s: %s", eid, job_id, exc)
        return None


def reconcile_dead_report_runs(db_manager) -> int:
    """The sweep's road: every RUNNING record that names a job, through
    :func:`record_verdict_from_job`.  Reads the RECORDS (few: the runs in
    flight), not the queue's history -- a dead job is found whatever its
    payload says and however many jobs came after it.  Idempotent; N
    sweepers safe; returns how many records were written."""
    if db_manager is None:
        return 0
    try:
        rows = db_manager.list_br_async_jobs(status="running", limit=_RECONCILE_BATCH)
    except Exception as exc:
        logger.warning("[report-lane] running records unreadable for the reconcile: %s", exc)
        return 0
    written = 0
    for row in rows or []:
        if not (row or {}).get("job_id"):
            continue
        if record_verdict_from_job(db_manager, row):
            written += 1
    if written:
        logger.warning("[report-lane] %d report run(s) marked from their dead jobs", written)
    return written


# ── registration (idempotent) ───────────────────────────────────────────

_registered = False
_reg_lock = threading.Lock()


def ensure_handler_registered() -> None:
    """Idempotent -- and it checks the REGISTRY, not only its own flag: a
    registry emptied after the first registration (a test suite's reset)
    left the flag set and the kind unhandled ("no handler registered for
    job kind 'execute_report'" on every claim)."""
    global _registered
    from core.jobqueue.executor import get_handler
    with _reg_lock:
        if not _registered or get_handler(KIND) is not handle_execute_report:
            register_handler(KIND, handle_execute_report, replace=True)
            _registered = True


__all__ = [
    "DEAD_RUN_MESSAGE", "DEFINITION_FIELDS", "KIND", "NOT_A_PLAN_FIELD", "NOT_WIRED_MESSAGE",
    "PUBLISHED_API_CANCELLED_MESSAGE", "PUBLISHED_API_FAILED_MESSAGE", "RUNNER_PIVOT",
    "MAX_DEFERRALS", "RUNNER_RAW_SQL", "RUNNER_REPORT", "RUN_TIMEOUT_MESSAGE", "ReportRun",
    "STOP_CANCEL", "STUCK_RUN_MESSAGE",
    "STOP_TIMEOUT", "STOP_ZOMBIE", "SURFACE_PUBLISHED_API", "SURFACE_REPORT_ASYNC",
    "WAITING_FOR_QUERY_POD", "cancel_job_of_record", "enqueue_report_run",
    "ensure_handler_registered", "handle_execute_report", "lane_enabled",
    "maybe_enqueue_async_report", "public_error", "reconcile_dead_report_runs",
    "record_verdict_from_job", "retry_declaration", "run_published_api_or_inline",
    "waiting_for_a_pod_or_capacity",
]
