"""execute_bridge — where queue mode meets the EXISTING execution path.

Two halves, one file, zero changes to the inline path:

**API side** — :func:`maybe_queue_execute` is the single flag-gated branch
called at the very top of ``POST /api/execute``:

  * flag OFF (default): returns ``None`` after ONE ``is_enabled`` read —
    the inline path proceeds byte-for-byte as today.
  * flag ON: captures identity (Phase 1 boundary) + RLS + the request AS
    DATA, enqueues, then awaits the executor's submit-response (pure
    ``await asyncio.sleep`` polling — nothing blocks the event loop) and
    relays it verbatim: the client sees the SAME response shape, including
    HTTP errors, that inline submission would have produced (parity).
  * FAIL-OPEN: any queue failure → loud log → inline execution.  If the
    executor never picks the job up within ``jobqueue.submit_wait_seconds``
    the API *absorbs* the job (fenced claim of that specific row) and runs
    inline — a user's query is NEVER silently dropped, and a job can never
    run twice (absorb wins or the executor wins, decided by one guarded
    UPDATE).

**Executor side** — :func:`handle_execute_query` (registered for kind
``execute_query``) rehydrates the request + identity and drives the
EXISTING ``_execute_query_impl`` on a persistent private event loop, then
watches the execution row to its terminal state.  Contextvar-free: every
input comes from the job row.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import threading
import time
from typing import Any, Dict, Optional

from core.jobqueue.queue import (
    ClaimedJob, EnqueueOutcome, get_job_queue, make_owner_id,
)
from core.jobqueue.executor import (
    JobCancelled, JobContext, JobHttpError, NonRetryableJobError,
    register_handler,
)
from core.query_pods.budget import memory_words
from core.query_pods.price import TooBigForQueryPods, price_for_request

logger = logging.getLogger(__name__)

#: DuckDB's own words when a run passes its memory_limit (2026-10-31): the
#: run was stopped by the limit it was given, not by a defect.
_OOM_WORDS = ("out of memory", "outofmemory", "memory limit", "could not allocate")


def _looks_like_out_of_memory(text: Optional[str]) -> bool:
    low = str(text or "").lower()
    return any(w in low for w in _OOM_WORDS)


def over_budget_message(job: ClaimedJob) -> str:
    """Plain words for a run DuckDB stopped at its reservation."""
    size = f" on query pod size {job.pod_class.upper()}" if job.pod_class else ""
    return (f"This run needed more than the {memory_words(job.reserved_bytes)} set aside for "
            f"it{size}, so it was stopped to keep the other runs safe. The next run "
            f"of this query will be given more memory; or narrow the dates or filters.")

_POLL_SECONDS = 0.25          # API-side wait poll cadence (async sleep)
_EXEC_WATCH_SECONDS = 1.0     # executor-side execution-row poll cadence


# ═══════════════════════════════════════════════════════════════════════
# WHERE A RUN GOES (query pods phase 2, 2026-10-31; design §5.1)
# ═══════════════════════════════════════════════════════════════════════
#
# ONE decision point, fed by the ONE price (core/query_pods/price.py):
#
#   * no sizes configured      -> "queue" as before this date (queue mode
#                                 routes every run; byte-for-byte);
#   * a run priced under query_pods.small_run_mb -> "inline": it runs
#     where it does today, in the API pod, no queue hop, no extra second;
#   * anything else            -> "queue", sized: a query pod of its size
#                                 claims it when the price fits its budget;
#   * too big for every size   -> refused before this point (413).
#
# THE PRICE ALONE DECIDES (security review 2026-10-31).  The first version
# also sent a request carrying ``limit > 0`` inline "as a preview", whatever
# its price: client-controlled routing -- ``limit: 1`` on a heavy query put
# it back in the API pod, the failure this work exists to stop.  A LIMIT
# does not bound the work either: a sort / group / distinct / window still
# reads and holds everything, and on S3 a LIMIT does not shorten the scan
# ("SELECT * LIMIT 500 does NOT speed up S3 scans").  No request field
# routes; the pricer already sees the plan.  A page from a STORED result
# never arrives here (it is GET /api/executions/{id}/results, no query
# runs), so there is nothing to route for it.
#
# The decision is made ONCE, in _enqueue_from_request, right after the
# price -- never a second pricing, never a second place that answers it.

ROUTE_INLINE = "inline"
ROUTE_QUEUE = "queue"


class Route:
    __slots__ = ("where", "reason", "price")

    def __init__(self, where: str, reason: str, price=None):
        self.where, self.reason, self.price = where, reason, price

    def as_dict(self) -> Dict[str, Any]:
        return {"where": self.where, "reason": self.reason,
                "price": self.price.as_dict() if self.price is not None else None}


def small_run_bytes() -> int:
    """``query_pods.small_run_mb`` in bytes (0 = nothing is small; a negative
    value reads as 0 -- nothing is small).  The typed accessor is the reader."""
    from core import config as _cfg
    from core.query_pods.budget import MB
    return max(0, int(_cfg.query_pods.small_run_mb)) * MB


def decide_route(price, payload: Dict[str, Any]) -> Route:
    """THE routing decision, from the PRICE alone.  ``price`` is the Price
    the request was given (pod_class None with bytes 0 = pricing is off).
    ``payload`` is accepted for the log line only -- no field of it routes."""
    if price is None or not price.pod_class:
        return Route(ROUTE_QUEUE, "no query pod sizes configured: the queue as before", price)
    small = small_run_bytes()
    if small > 0 and int(price.bytes) < small:
        return Route(ROUTE_INLINE, f"priced {price.bytes // (1024 ** 2)} MB, under "
                                   f"query_pods.small_run_mb ({small // (1024 ** 2)} MB)", price)
    return Route(ROUTE_QUEUE, f"heavy: priced {price.bytes // (1024 ** 2)} MB for size "
                              f"{price.pod_class.upper()}", price)


class _RunInline(Exception):
    """Internal control flow: the route says inline -- the caller returns
    None and today's inline path runs the request, no queue hop."""

    def __init__(self, route: Route):
        super().__init__(route.reason)
        self.route = route

_TERMINAL_EXEC_OK = ("completed",)
_TERMINAL_EXEC_FAIL = ("failed",)
_TERMINAL_EXEC_CANCEL = ("cancelled",)


def _cfg_num(key: str, fallback):
    try:
        from core.config import get as _cfg_get
        v = _cfg_get("jobqueue", key, fallback)
        return type(fallback)(v) if v is not None else fallback
    except Exception:
        return fallback


# ═══════════════════════════════════════════════════════════════════════
# API SIDE
# ═══════════════════════════════════════════════════════════════════════

async def maybe_queue_execute(request, user: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The queue-mode branch for ``POST /api/execute``.

    Returns ``None`` → caller proceeds with today's inline path (flag off,
    or fail-open).  Returns a dict → that IS the submit response (relayed
    from the executor with parity).  Raises ``HTTPException`` only to
    relay an error the inline path would also have raised."""
    try:
        from core.industrialization import is_enabled
        if not is_enabled("queue_mode"):
            return None
    except Exception:
        return None  # flag machinery unavailable → inline (fail-open)

    # ── capture-as-data (identity is the security boundary) ────────────
    try:
        outcome = await asyncio.to_thread(_enqueue_from_request, request, user)
    except _RunInline as small:
        # 2026-10-31 (phase 2, §5.1): a SMALL run (a preview, or priced
        # under query_pods.small_run_mb) runs where it does today -- no
        # queue hop.  Not a fail-open: the ONE routing decision said so.
        logger.info("[jobqueue] run stays inline: %s", small.route.reason)
        return None
    except TooBigForQueryPods as too_big:
        # 2026-10-31 -- no query pod size can hold this run.  NOT the
        # fail-open below: running it inline would put it in the API pod's
        # memory, the 2026-10-28 restart.  Refused with the numbers.
        from fastapi import HTTPException as _HE
        logger.info("[jobqueue] run refused, too big for every query pod: %s",
                    too_big.price.as_dict())
        raise _HE(status_code=413, detail=str(too_big))
    except Exception as exc:
        logger.error(
            "[jobqueue] enqueue failed — FAIL-OPEN to inline execution "
            "(query is NOT lost): %s", exc, exc_info=True)
        return None

    # ── Phase 5 single-flight: this request ATTACHED to a live leader —
    # it awaits the shared result; while attached it never runs inline (a
    # follower owns no execution).  If sharing breaks, the follower is
    # DETACHED to an independent queued job and from there behaves exactly
    # like an ordinary submission — including the absorb-for-inline
    # fail-open when no executor picks it up.
    if outcome.attached_to:
        from fastapi import HTTPException as _HE
        try:
            return await _await_leader_result(outcome)
        except _AbsorbInline:
            return None   # detached follower absorbed — inline runs it
        except _HE:
            raise         # parity failure relay
        except Exception as exc:
            logger.error("[jobqueue] follower waiter failed for job %s: %s",
                         outcome.job_id, exc, exc_info=True)
            return {"job_id": outcome.job_id, "status": "queued",
                    "queued_via": "jobqueue", "single_flight": True,
                    "shared_with_job": outcome.attached_to,
                    "message": ("Query attached to an identical in-flight "
                                "execution; status polling hiccuped. Poll "
                                "GET /api/jobs/" + outcome.job_id)}
    job_id = outcome.job_id

    # ── await the executor's submit-response (non-blocking) ────────────
    from fastapi import HTTPException
    try:
        return await _await_submit_response(job_id)
    except _AbsorbInline:
        return None  # we own the job again; inline path runs it as today
    except HTTPException:
        raise      # parity error relay — exactly what inline would raise
    except Exception as exc:
        # Unexpected waiter failure AFTER enqueue: the job may already be
        # executor-owned, so inline fail-open is only safe if we can
        # absorb it (double-execution guard).
        logger.error("[jobqueue] submit waiter failed for job %s: %s",
                     job_id, exc, exc_info=True)
        queue = get_job_queue()
        absorbed = await asyncio.to_thread(_absorb, queue, job_id)
        if absorbed is not None:
            return None  # inline runs it; job row already terminal
        return {"job_id": job_id, "status": "queued", "queued_via": "jobqueue",
                "message": ("Query accepted by the job queue; status "
                            "polling hiccuped. Poll GET /api/jobs/" + job_id)}


class _AbsorbInline(Exception):
    """Internal control flow: the API absorbed the job — run inline."""


# ── rls_key shareability guard (2026-07-23 red-team C1 + S1) ────────────
#
# The rls_key is computed from ``raw_sql`` ONLY.  Any request whose
# enforcement surface is BIGGER than raw_sql must therefore never carry a
# shareable key:
#
#   * C1 — the cross-connection combine path (``secondary_raw_sql`` /
#     ``secondary_connection_id`` / ``secondary_query_config``) enforces a
#     SECOND SQL surface under the secondary connection's policies.  Two
#     users with different policies on the secondary table would otherwise
#     collide on the same raw_sql-only key → single-flight cross-user leak.
#   * S1 — ``{{param}}`` template substitution happens AFTER key
#     computation and splices RAW text into the SQL (a value-position
#     placeholder even PARSES, so the key computer would not refuse it);
#     the substituted SQL can reference tables the key never hashed.
#
# Fail-closed is the correct minimum: the job runs fine — only sharing is
# forfeited.  (Folding both SQL surfaces into one predicate set is a
# follow-up; until then non-shareable is the only safe answer.)

_SQL_TEMPLATE_RE = re.compile(r"\{\{\s*\w+\s*\}\}")

_SECONDARY_SURFACE_KEYS = ("secondary_raw_sql", "secondary_connection_id",
                           "secondary_query_config")


def _non_shareable_request_reason(payload: Any) -> Optional[str]:
    """Reason string when this request payload must NEVER carry a shareable
    rls_key (the key covers raw_sql only), else None."""
    if not isinstance(payload, dict):
        return None
    for k in _SECONDARY_SURFACE_KEYS:
        v = payload.get(k)
        if v not in (None, "", {}, []):
            return (f"request carries a second enforced SQL surface ({k}) "
                    "— the rls_key covers raw_sql only")
    raw_sql = payload.get("raw_sql")
    if isinstance(raw_sql, str) and _SQL_TEMPLATE_RE.search(raw_sql):
        return ("raw_sql contains {{param}} template placeholders — "
                "execution substitutes raw text after the key is computed")
    return None


def _enqueue_from_request(request, user: Dict[str, Any]) -> "EnqueueOutcome":
    """Sync worker: derive identity via the Phase 1 boundary, compute the
    rls_key leg of the content address, price + lane the job, then
    enqueue-or-attach.  Raises on any failure (caller fails open).

    rls_key wiring (HARD gate 1 — LIVE as of Phase 5):

      * predicates computed OK → the Phase-1 key rides the row and is
        SHAREABLE.  This includes the shared UNFILTERED key (admin bypass /
        row-security off / no matching policies): identical enforced SQL
        for everyone, safe to share by the rendering theorem.
      * ``RlsComputationError`` (DB blip, unparseable SQL, opaque render
        failure) or a request shape whose predicates we cannot compute
        (no ``raw_sql``) → FAIL-CLOSED: a UNIQUE per-job key, never
        shareable.  The job still runs — only sharing is forfeited.
      * neither ``single_flight`` nor ``rls_boundary_enabled`` armed →
        Phase-2 behavior byte-for-byte (empty key, runs unshared).

    Key/enforcement TOCTOU (Phase-1 decision #3, "single pass"): the
    predicates are computed ONCE here and captured as data on the job row
    (``rls_payload``); enforcement, however, resolves policies fresh at
    execution time inside the unchanged execution path.  The executor
    therefore RE-VERIFIES the key against its own resolver state
    immediately before AND after driving the execution (see
    ``_single_flight_guard_begin/_end``) and un-shares on any drift —
    sharing is only ever permitted for an execution whose enforcement
    state is PROVEN to match the key.  See the guard docstrings for the
    full argument.
    """
    from core.identity import derive_from_verified_user

    identity = derive_from_verified_user(user)   # fail-closed on forged/empty
    payload = request.model_dump(mode="json")

    db_manager = _api_db_manager()
    queue = get_job_queue(db_manager)

    try:
        from core.industrialization import is_enabled as _ind_enabled
        sf_armed = _ind_enabled("single_flight")
        rls_armed = _ind_enabled("rls_boundary_enabled")
        adm_armed = _ind_enabled("fleet_admission")
    except Exception:
        sf_armed = rls_armed = adm_armed = False

    rls = None
    rls_failure = None
    rls_fingerprint = ""
    if sf_armed or rls_armed:
        raw_sql = payload.get("raw_sql")
        unshareable = _non_shareable_request_reason(payload)
        if unshareable:
            # C1/S1 fail-closed: the enforcement surface exceeds what the
            # raw_sql-only key can prove — per-job key, never shared.
            logger.info("[jobqueue] request is non-shareable — fail-closed "
                        "per-job rls_key: %s", unshareable)
            rls_failure = f"non-shareable request: {unshareable}"[:500]
        elif raw_sql:
            try:
                from core.identity import (
                    EffectiveRlsComputer, RlsComputationError,
                    compute_policy_fingerprint,
                )
                # The TOCTOU chain anchor: the key computation is itself
                # SANDWICHED between two policy-set fingerprint reads so
                # the stored key is PROVABLY rendered under the stored
                # fingerprint's policy set.  Attach requires fingerprint
                # equality with the leader; the executor's sandwich
                # requires it unchanged through execution — so a shared
                # result is provably computed under the exact policy set
                # EVERY participant's key was rendered from.  Any
                # fingerprint failure/drift → fail-closed (per-job key,
                # unshared); rls_boundary-only mode skips the anchor
                # (nothing shares on it).
                if sf_armed:
                    rls_fingerprint = compute_policy_fingerprint(db_manager)
                rls = EffectiveRlsComputer(db_manager).compute(
                    raw_sql, identity=identity,
                    connection_id=payload.get("connection_id"))
                if sf_armed:
                    fp_after = compute_policy_fingerprint(db_manager)
                    if fp_after != rls_fingerprint:
                        raise RlsComputationError(
                            "policy set changed while computing the rls_key "
                            "— no stable anchor, refusing to share")
            except Exception as exc:
                # FAIL-CLOSED (hard gate 1): no key ⇒ no shared work for
                # this job — but the job itself runs fine.
                logger.info("[jobqueue] rls_key computation failed — job "
                            "gets a fail-closed per-job key (runs "
                            "unshared): %s", exc)
                rls, rls_fingerprint = None, ""
                rls_failure = f"rls_key computation failed: {exc}"[:500]
        else:
            rls_failure = ("predicates not computable for this request "
                           "shape (no raw_sql) — per-job key, unshared")
        if rls is None and not sf_armed:
            # Phase-2 parity when only the boundary flag is armed: keep
            # the legacy empty key (nothing consumes it yet).
            rls_failure = None

    lane = "interactive"
    cost_mb = 0
    if adm_armed:
        try:
            from core.jobqueue.fairness import lane_for_kind, price_for_plan
            from core.jobqueue.queue import compute_plan_hash
            lane = lane_for_kind("execute_query")
            cost_mb = price_for_plan(queue, compute_plan_hash(payload))
        except Exception as exc:
            logger.debug("[jobqueue] admission pricing failed (fail-open, "
                         "unpriced): %s", exc)

    # ── 2026-10-31: the PRICE before the run and its query-pod size ────
    # Off (no query_pods.classes) -> '' / 0, the row as before.  Too big for
    # every size -> TooBigForQueryPods, which maybe_queue_execute turns into
    # a refusal (never into the inline fail-open).
    # The calibration SCOPE (security review): the row's rls_key when it is
    # shareable (identical enforced SQL for everyone who carries it), and
    # always the user's own runs -- never another identity's history.
    price = _price_request(payload, db_manager,
                           rls_key=rls.rls_key() if rls is not None else "",
                           rls_shareable=rls is not None,
                           username=identity.username)
    # ── 2026-10-31 (phase 2): WHERE THE RUN GOES -- decided once, here ──
    route = decide_route(price, payload)
    if route.where == ROUTE_INLINE:
        raise _RunInline(route)

    return queue.enqueue_or_attach(
        kind="execute_query",
        request_payload=payload,
        identity=identity,
        rls_predicates=rls,
        rls_failure=rls_failure,
        rls_fingerprint=rls_fingerprint,
        lane=lane,
        admission_cost_mb=cost_mb,
        pod_class=price.pod_class or "",
        price_bytes=price.bytes if price.pod_class else 0,
        price_source=price.source if price.pod_class else "",
    )


def _price_request(payload: Dict[str, Any], db_manager, *, rls_key: str = "",
                   rls_shareable: bool = False, username: str = ""):
    """Price the run for the query pods (core/query_pods/price.py).  Pricing
    off -> an empty Price; a price no size holds -> TooBigForQueryPods; any
    other failure of the pricer -> an empty Price (the run is queued unsized,
    as before this date -- pricing is never the reason a run is lost).
    The scope arguments say whose calibration history the price may read."""
    from core.query_pods.price import Price
    try:
        from core.query_pods import budget as _budget
        settings = _budget.settings_or_none()
        if not _budget.pricing_enabled(settings):
            return Price(bytes=0, source="", pod_class=None)
        price = price_for_request(payload, db_manager, settings=settings, rls_key=rls_key,
                                  rls_shareable=rls_shareable, username=username)
    except Exception as exc:
        logger.warning("[jobqueue] query-pod pricing failed -- run queued "
                       "unsized: %s", exc)
        return Price(bytes=0, source="", pod_class=None)
    if price.too_big:
        raise TooBigForQueryPods(price)
    logger.info("[jobqueue] priced run: %s", price.as_dict())
    return price


async def _await_submit_response(job_id: str) -> Dict[str, Any]:
    """Poll the job row (async, event-loop friendly) until the executor
    relays the submit response, the job fails, or the wait budget expires
    → absorb + inline."""
    from fastapi import HTTPException

    queue = get_job_queue()
    wait_budget = _cfg_num("submit_wait_seconds", 30)
    deadline = time.monotonic() + max(1.0, float(wait_budget))

    while True:
        job = await asyncio.to_thread(_safe_get, queue, job_id)
        if job is not None:
            status = job.get("status")
            if job.get("response_json"):
                resp = _parse_json(job["response_json"]) or {}
                if not resp.pop("absorbed_inline", False):
                    resp["job_id"] = job_id
                    resp["queued_via"] = "jobqueue"
                    return resp
            if status == "failed":
                raise _relay_failure_http(job, HTTPException)
            if status == "cancelled":
                return {"job_id": job_id, "status": "cancelled",
                        "message": "Job was cancelled before execution"}
        if time.monotonic() >= deadline:
            break
        await asyncio.sleep(_POLL_SECONDS)

    # ── wait budget exhausted: fail OPEN to inline, without double-run ──
    # 2026-10-31: a run PRICED for a query pod size is never absorbed --
    # running it in the API pod's memory is the 2026-10-28 restart.  It
    # keeps its place in line; the client gets the job handle and the
    # sentence the screen shows.
    sized = await asyncio.to_thread(_safe_get, queue, job_id)
    if sized and sized.get("pod_class") and sized.get("status") == "queued":
        # queue.get() already carries position / waiting / pods_alive (phase
        # 2: "No query pod of size M is running right now" when none is --
        # a sized run never waits in silence; the sweeper bounds the wait).
        position = sized.get("position")
        sentence = sized.get("waiting") or "Waiting for a query pod"
        logger.info("[jobqueue] job %s stays in line for a query pod (%s; pods alive: %s)",
                    job_id, sentence, sized.get("pods_alive"))
        return {"job_id": job_id, "status": "queued", "queued_via": "jobqueue",
                "pod_class": sized.get("pod_class"), "position": position,
                "pods_alive": sized.get("pods_alive"),
                "message": sentence + ". Poll GET /api/jobs/" + job_id}
    absorbed = await asyncio.to_thread(_absorb, queue, job_id)
    if absorbed is not None:
        logger.warning(
            "[jobqueue] no executor picked up job %s within %ss — ABSORBED "
            "by the API pod; running inline (fail-open)", job_id, wait_budget)
        raise _AbsorbInline()
    # An executor owns it (claimed at the buzzer) — do NOT run inline
    # (double-execution guard).  Give it one more short grace, then hand
    # the client the job handle (loud, never silent).
    grace_deadline = time.monotonic() + 10.0
    while time.monotonic() < grace_deadline:
        job = await asyncio.to_thread(_safe_get, queue, job_id)
        if job and job.get("response_json"):
            resp = _parse_json(job["response_json"]) or {}
            if not resp.pop("absorbed_inline", False):
                resp["job_id"] = job_id
                resp["queued_via"] = "jobqueue"
                return resp
        if job and job.get("status") == "failed":
            from fastapi import HTTPException as _HE
            raise _relay_failure_http(job, _HE)
        await asyncio.sleep(_POLL_SECONDS)
    logger.warning("[jobqueue] job %s is executor-owned but slow to relay a "
                   "submit response — returning the job handle", job_id)
    return {"job_id": job_id, "status": "queued", "queued_via": "jobqueue",
            "message": ("Query accepted by the job queue; an executor is "
                        "working on it. Poll GET /api/jobs/" + job_id)}


async def _await_leader_result(outcome: EnqueueOutcome) -> Dict[str, Any]:
    """Phase 5 — the FOLLOWER waiter.

    The request attached to a live leader; no execution of its own exists.
    Poll the FOLLOWER row (the propagation sweep + this waiter resolve it
    from the leader's terminal state):

      * follower ``succeeded``  → serve the leader's relayed submit
        response (only possible via a ``share_verified`` leader — the
        propagation sweep enforces that);
      * follower ``failed``     → relay the leader's failure with HTTP
        parity (followers share the failure, never hang);
      * follower ``queued``     → the follower was DETACHED (leader
        unshared / cancelled / finished unverified) — hand over to the
        normal submit waiter: it now behaves exactly like an ordinary
        queued job (executor pickup or API absorb → inline);
      * follower ``cancelled``  → this user detached; report it;
      * wait budget exhausted   → return the follower's job handle (the
        jobs API serves the propagated result later).
    """
    from fastapi import HTTPException

    queue = get_job_queue()
    follower_id = outcome.job_id
    wait_budget = _cfg_num("submit_wait_seconds", 30)
    deadline = time.monotonic() + max(1.0, float(wait_budget))
    nudged = False

    while True:
        job = await asyncio.to_thread(_safe_get, queue, follower_id)
        if job is not None:
            status = job.get("status")
            if status == "succeeded" and job.get("response_json"):
                resp = _parse_json(job["response_json"]) or {}
                resp.pop("absorbed_inline", None)
                resp["job_id"] = follower_id
                resp["queued_via"] = "jobqueue"
                resp["single_flight"] = True
                resp["shared_with_job"] = outcome.attached_to
                return resp
            if status == "failed":
                raise _relay_failure_http(job, HTTPException)
            if status == "cancelled":
                return {"job_id": follower_id, "status": "cancelled",
                        "message": "Request detached from the shared execution"}
            if status == "queued":
                # Detached to independent execution — normal path from here.
                logger.info("[jobqueue] follower %s detached from leader %s "
                            "— continuing as an independent job",
                            follower_id, outcome.attached_to)
                return await _await_submit_response(follower_id)
            if status == "attached" and not nudged:
                # If the leader is already terminal, nudge propagation so
                # this waiter doesn't have to wait for the next reaper
                # sweep (idempotent; safe from any pod).
                leader = await asyncio.to_thread(_safe_get, queue,
                                                 outcome.attached_to)
                if leader and leader.get("status") in ("succeeded", "failed",
                                                       "cancelled"):
                    nudged = True
                    try:
                        await asyncio.to_thread(queue.propagate_single_flight)
                    except Exception as exc:
                        logger.warning("[jobqueue] propagation nudge failed "
                                       "(sweep will retry): %s", exc)
                    continue
        if time.monotonic() >= deadline:
            break
        await asyncio.sleep(_POLL_SECONDS)

    return {"job_id": follower_id, "status": "queued",
            "queued_via": "jobqueue", "single_flight": True,
            "shared_with_job": outcome.attached_to,
            "message": ("Query attached to an identical in-flight execution; "
                        "poll GET /api/jobs/" + follower_id)}


def _safe_get(queue, job_id: str) -> Optional[Dict[str, Any]]:
    try:
        return queue.get(job_id)
    except Exception as exc:
        logger.warning("[jobqueue] status poll failed for %s: %s", job_id, exc)
        return None


def _safe_position(queue, job_id: str) -> Optional[int]:
    try:
        return queue.queue_position(job_id)
    except Exception as exc:
        logger.warning("[jobqueue] queue position unreadable for %s: %s", job_id, exc)
        return None


def _absorb(queue, job_id: str) -> Optional[ClaimedJob]:
    """Claim the specific job for inline execution + immediately mark it
    terminal (the inline path owns the query from here — the job row is a
    tracking artifact, and a terminal row can never be reaped/requeued
    into a duplicate execution)."""
    try:
        claimed = queue.absorb_for_inline(job_id, make_owner_id("api-inline"))
        if claimed is None:
            return None
        queue.set_submit_response(
            job_id, claimed.fencing_token,
            response={"absorbed_inline": True}, result_handle=None)
        queue.complete(job_id, claimed.fencing_token, result_handle=None)
        return claimed
    except Exception as exc:
        logger.error("[jobqueue] absorb failed for %s: %s", job_id, exc)
        return None


def _relay_failure_http(job: Dict[str, Any], http_exception_cls):
    """Map a failed job to the HTTPException inline submission would have
    raised (parity error relay)."""
    err = job.get("error") or "job failed"
    parsed = _parse_json(err)
    if isinstance(parsed, dict) and "__http__" in parsed:
        h = parsed["__http__"] or {}
        headers = h.get("headers") if isinstance(h.get("headers"), dict) else None
        return http_exception_cls(status_code=int(h.get("status_code", 500)),
                                  detail=h.get("detail"), headers=headers)
    return http_exception_cls(status_code=500, detail=str(err)[:2000])


def _parse_json(raw):
    try:
        return json.loads(raw)
    except Exception:
        return None


def _api_db_manager():
    """The app-wide DatabaseManager, via the execute module's wiring."""
    try:
        from api import execute_api as _ea
        if _ea._db_manager is not None:
            return _ea._db_manager
    except Exception:
        pass
    import main as _main
    return _main.db_manager


# ═══════════════════════════════════════════════════════════════════════
# EXECUTOR SIDE
# ═══════════════════════════════════════════════════════════════════════

_loop_lock = threading.Lock()
_bridge_loop: Optional[asyncio.AbstractEventLoop] = None


def _get_bridge_loop() -> asyncio.AbstractEventLoop:
    """A persistent private event loop for the executor.  MUST outlive any
    single job: ``_execute_query_impl`` spawns the actual execution as a
    background task on the loop it runs on — ``asyncio.run`` would kill
    that task when the impl returns."""
    global _bridge_loop
    with _loop_lock:
        if _bridge_loop is None or _bridge_loop.is_closed():
            loop = asyncio.new_event_loop()
            t = threading.Thread(target=loop.run_forever,
                                 name="jobqueue-bridge-loop", daemon=True)
            t.start()
            _bridge_loop = loop
        return _bridge_loop


def handle_execute_query(job: ClaimedJob, ctx: JobContext) -> Optional[str]:
    """Run one queued query through the EXISTING execution path.

    Stage boundaries (cooperative cancel checked at each):
      1. rebuild the request from captured data;
      2. drive ``_execute_query_impl`` (the unchanged inline submit body)
         on the persistent bridge loop → submit response;
      3. relay the submit response onto the job row (API parity);
      4. watch the execution row to terminal state.
    """
    from api.models.query_models import ExecuteQueryRequest
    from api import execute_api as _ea

    if _ea._db_manager is None or _ea._engine is None:
        # This process isn't wired to execute queries (deps not set) —
        # retryable: another executor may be; quarantines at max_attempts.
        raise RuntimeError(
            "execute dependencies not initialized in this executor process "
            "(set_execute_dependencies has not run)")

    try:
        req = ExecuteQueryRequest(**(job.request or {}))
    except Exception as exc:
        raise NonRetryableJobError(f"request payload does not deserialize: {exc}")

    user = ctx.user_dict()

    if ctx.cancel_requested():
        raise JobCancelled("cancelled before submit")

    # ── Phase 5: single-flight key re-verification (pre-execution) ─────
    sf_guard = _single_flight_guard_begin(job, ctx)
    try:
        return _run_execute_query_stages(job, ctx, sf_guard, req, user)
    finally:
        # C3 (2026-07-23): the strict-resolution window armed by the guard
        # must NEVER outlive this job — guard_end releases it on the
        # success paths; this releases it on every raise (idempotent).
        _single_flight_guard_release(sf_guard)


def _run_execute_query_stages(job: ClaimedJob, ctx: JobContext, sf_guard,
                              req, user) -> Optional[str]:
    """Stages 2-4 of :func:`handle_execute_query` (split out so the strict
    resolution window is released by a single ``finally``)."""
    from fastapi import HTTPException
    from api import execute_api as _ea

    # ── 2. the existing submit body, unchanged ─────────────────────────
    # 2026-10-31: run INSIDE the job's reservation scope -- the task the
    # body spawns copies the context, so the DuckDB spawn deep in the
    # engine reads the reservation back and sets memory_limit to it
    # (core/query_pods/budget.py).  reserved_bytes 0 = no scope, as before.
    loop = _get_bridge_loop()
    submit_timeout = max(60.0, float(_cfg_num("submit_wait_seconds", 30)) * 4)
    reserved = int(job.reserved_bytes or 0)
    try:
        fut = asyncio.run_coroutine_threadsafe(
            _submit_with_reservation(_ea, req, user, reserved), loop)
        resp = fut.result(timeout=submit_timeout)
    except HTTPException as he:
        raise JobHttpError(he.status_code, he.detail)
    except JobHttpError:
        raise
    except Exception as exc:
        # Submit-shape crash — retryable (could be a transient dependency).
        raise RuntimeError(f"submit body failed: {exc}") from exc

    if not isinstance(resp, dict):
        resp = {"response": str(resp)}
    execution_id = resp.get("execution_id")
    if reserved and execution_id:
        from core.query_pods.budget import note_reservation
        note_reservation(str(execution_id), reserved)

    # ── 3. relay the submit response (parity for the API waiter) ──────
    ctx.stamp_response(resp, execution_id)
    # 2026-10-31 (phase 2, rule 4): this is a RETRY on another pod -- the
    # run the dead pod left behind is pointed at the one that continues, so
    # a page still following the old execution id reads where to look.
    if execution_id and job.attempts > 1 and job.previous_result_handle:
        _point_previous_run_here(ctx, job.previous_result_handle, str(execution_id))

    try:
        return _watch_execution(job, ctx, sf_guard, resp, execution_id)
    finally:
        if reserved and execution_id:
            from core.query_pods.budget import forget_reservation
            forget_reservation(str(execution_id))


def _point_previous_run_here(ctx: JobContext, previous_execution_id: str,
                             new_execution_id: str) -> bool:
    """The dead attempt's execution row (still unfinished, or already failed
    by the checkpoint sweep with the restart sentence) says in plain words
    that the query continued as ``new_execution_id``.  A run that FINISHED
    is never touched.  Never raises."""
    if not previous_execution_id or previous_execution_id == new_execution_id:
        return False
    try:
        from api import execute_api as _ea
        from core.jobqueue.queue import CONTINUED_ELSEWHERE_MESSAGE
        db = ctx.db_manager or _ea._db_manager
        ex = db.get_execution(previous_execution_id) if db else None
        if not ex:
            return False
        status = str(ex.get("status") or "").lower()
        if status in ("completed", "cancelled"):
            return False
        db.update_execution(previous_execution_id, status="failed",
                            error_message=CONTINUED_ELSEWHERE_MESSAGE.format(new=new_execution_id))
        logger.info("[jobqueue] job %s attempt %d: run %s pointed at its continuation %s",
                    ctx.job.id, ctx.job.attempts, previous_execution_id, new_execution_id)
        return True
    except Exception as exc:
        logger.warning("[jobqueue] previous run %s not annotated: %s", previous_execution_id, exc)
        return False


async def _submit_with_reservation(_ea, req, user, reserved_bytes: int):
    """The unchanged submit body, inside the run's reservation scope when
    it has one (one coroutine, one task: the scope's ContextVar is what
    every task the body creates inherits)."""
    if reserved_bytes <= 0:
        return await _ea._execute_query_impl(req, user)
    from core.query_pods.budget import reservation_scope
    with reservation_scope(reserved_bytes):
        return await _ea._execute_query_impl(req, user)


def _watch_execution(job: ClaimedJob, ctx: JobContext, sf_guard, resp,
                     execution_id) -> Optional[str]:
    """Stage 4: watch the execution row to a terminal state; on the way out
    (any terminal state) record the run's MEASURED peak memory so the next
    price of this plan is calibrated."""
    from api import execute_api as _ea

    if resp.get("status") == "completed" or not execution_id:
        # Fast paths (cache hit / metadata-only) finish inside submit.
        _maybe_stamp_passport(ctx, execution_id)
        _single_flight_guard_end(job, ctx, sf_guard)
        _maybe_publish_result_artifact(job, ctx, execution_id)
        return execution_id

    db = ctx.db_manager or _ea._db_manager
    run_timeout = float(_cfg_num("run_timeout_seconds", 7200))
    deadline = time.monotonic() + run_timeout
    _passport_stamped = False
    while True:
        if ctx.cancel_requested():
            _local_cancel_execution(db, execution_id, reason="job cancel requested")
            _record_actual_peak(job, ctx, execution_id, failed_with=None)
            raise JobCancelled(f"cancelled while running execution {execution_id}")
        # Phase 3 — the reader registers the plan-time passport under this
        # execution_id mid-flight; stamp it onto the job row (fenced) the
        # first time it appears.  Fail-open telemetry — never blocks the
        # watch loop.
        if not _passport_stamped:
            _passport_stamped = _maybe_stamp_passport(ctx, execution_id)
        try:
            ex = db.get_execution(execution_id)
        except Exception as exc:
            logger.warning("[jobqueue] execution poll failed for %s: %s",
                           execution_id, exc)
            ex = None
        if ex is not None:
            status = (ex.get("status") or "").lower()
            if status in _TERMINAL_EXEC_OK:
                if not _passport_stamped:
                    _maybe_stamp_passport(ctx, execution_id)
                _record_actual_peak(job, ctx, execution_id, failed_with=None)
                _single_flight_guard_end(job, ctx, sf_guard)
                _maybe_publish_result_artifact(job, ctx, execution_id)
                return execution_id
            if status in _TERMINAL_EXEC_FAIL:
                error = ex.get("error_message") or f"execution {execution_id} failed"
                _record_actual_peak(job, ctx, execution_id, failed_with=error)
                if job.reserved_bytes and _looks_like_out_of_memory(error):
                    # Stopped by the limit it was given: say so in plain
                    # words, on the job AND on the execution the user reads.
                    error = over_budget_message(job)
                    try:
                        db.update_execution(execution_id, error_message=error)
                    except Exception as exc:
                        logger.warning("[jobqueue] could not reword execution %s: %s",
                                       execution_id, exc)
                raise NonRetryableJobError(error)
            if status in _TERMINAL_EXEC_CANCEL:
                _record_actual_peak(job, ctx, execution_id, failed_with=None)
                raise JobCancelled(f"execution {execution_id} was cancelled")
        if time.monotonic() >= deadline:
            _local_cancel_execution(db, execution_id, reason="jobqueue run timeout")
            _record_actual_peak(job, ctx, execution_id, failed_with=None)
            raise NonRetryableJobError(
                f"execution {execution_id} exceeded jobqueue.run_timeout_seconds "
                f"({int(run_timeout)}s)")
        time.sleep(_EXEC_WATCH_SECONDS)


def _record_actual_peak(job: ClaimedJob, ctx: JobContext, execution_id: str,
                        *, failed_with: Optional[str]) -> Optional[int]:
    """Calibration (2026-10-31): the MEASURED peak of the run's DuckDB
    children (the resource governor's sampler) onto the job row.  A run
    DuckDB stopped at its memory_limit records at least its reservation --
    the real need was above it, so the next price goes up.  Never raises;
    returns what was recorded (None = nothing measured, nothing written)."""
    peak = 0
    try:
        from core.resource_governor import peak_rss_for_execution
        peak = int(peak_rss_for_execution(str(execution_id)) or 0)
    except Exception as exc:
        logger.debug("[jobqueue] peak unreadable for %s: %s", execution_id, exc)
    if job.reserved_bytes and failed_with and _looks_like_out_of_memory(failed_with):
        peak = max(peak, int(job.reserved_bytes))
    if peak <= 0:
        return None
    try:
        if ctx.queue.stamp_actual_peak(job.id, job.fencing_token, peak_bytes=peak):
            logger.info("[jobqueue] job %s peak memory %.2f GB recorded for the "
                        "next price", job.id, peak / 1024 ** 3)
            return peak
    except Exception as exc:
        logger.warning("[jobqueue] peak of job %s not recorded: %s", job.id, exc)
    return None


# ── Phase 5 — single-flight key/enforcement verification sandwich ───────
#
# THE TOCTOU ARGUMENT (Phase-1 decision #3, "one resolve feeds both"):
#
# The rls_key was computed at ENQUEUE from a fresh policy resolve and the
# predicates were captured as data.  Enforcement, however, happens inside
# the unchanged execution path at EXECUTION time, resolving policies
# through the rewriter's own resolver.  A policy edit in between could
# make enforcement render something the key never hashed — and a shared
# result under a stale key is a cross-user leak vector.  Rather than
# rewriting the working enforcement chokepoint to consume captured
# predicates (invasive, regression-prone), the executor PROVES agreement
# observationally and fails CLOSED to unshared on any doubt:
#
#   0. ENQUEUE (every participant): the key is computed from a fresh
#      policy resolve, and the policy-set FINGERPRINT at that instant
#      (DB-derived: counts + max ids + max updated_at over policies AND
#      bindings) is stored on the row.  ATTACH additionally requires
#      follower_fingerprint == leader_fingerprint — so every participant
#      keyed under the SAME policy set, or they never share at all.
#   1. BEGIN (before driving the execution, same process that will
#      enforce):
#        a. drop the row-security resolver cache (public invalidate_cache)
#           so enforcement's very next resolve reads the DATABASE, not a
#           possibly-30s-stale in-process cache;
#        b. the CURRENT fingerprint must equal the row's enqueue-time
#           fingerprint (nothing changed while queued);
#        c. recompute the rls_key from the REHYDRATED identity + captured
#           SQL; it must equal the enqueue-time key on the row.
#   2. Execution runs; enforcement resolves fresh (cache was dropped) —
#      i.e. from DB state bracketed by this sandwich.
#   3. END (after the execution succeeded): recompute key + fingerprint
#      again; both must STILL equal the row's enqueue-time values.
#
# The chain is gapless: the policy set is proven identical from every
# participant's key computation through the end of the execution.  A
# plain edit flips the key or the fingerprint; an edit-then-REVERT (ABA)
# still flips the fingerprint because updated_at bumps on the revert.
# Only then is ``share_verified`` stamped — and ONLY verified leaders
# ever fan a result out (propagation sweep + result-grant both check
# it).  Every other outcome → ``unshare_leader``: the leader keeps its
# own, self-consistently-enforced result; followers detach and
# re-execute under their own identities.  Residual exposure: none for
# sharing (that is the point); the leader itself always receives
# enforcement's fresh rendering, exactly like an inline run today.
#
# Cost: two strict policy resolves + two 3-aggregate queries per SHARED
# execution, only when ``single_flight`` is armed and the key is
# shareable.  The resolver-cache invalidation is process-wide and simply
# forces the next resolves to re-read the DB (how policy edits propagate
# anyway) — a bounded perf cost, never a correctness change.

def _single_flight_guard_begin(job: ClaimedJob, ctx) -> Optional[Dict[str, Any]]:
    """Pre-execution arm of the sandwich.  Returns the guard context, or
    None when single-flight verification is not applicable (flag off /
    key not shareable) or when the job was UN-shared (fail-closed)."""
    try:
        from core.industrialization import is_enabled
        if not is_enabled("single_flight") or not job.rls_key_shareable:
            return None
    except Exception:
        return None
    if not job.rls_fingerprint:
        # Shareable key but no anchor fingerprint (mixed-version enqueue)
        # → cannot prove the chain → fail closed to unshared.
        _unshare_safe(job, ctx, reason="no enqueue-time policy fingerprint")
        return None
    try:
        from core.row_security import invalidate_cache
        invalidate_cache()   # enforcement's next resolve reads the DB
    except Exception as exc:
        logger.warning("[jobqueue] single-flight: resolver-cache "
                       "invalidation failed — un-sharing job %s: %s",
                       job.id, exc)
        _unshare_safe(job, ctx, reason="resolver cache invalidation failed")
        return None
    try:
        fingerprint = _policy_fingerprint(ctx)
        key = _recompute_rls_key(job, ctx)
    except Exception as exc:
        _unshare_safe(job, ctx,
                      reason=f"pre-execution key re-verification failed: {exc}")
        return None
    if key != job.rls_key or fingerprint != job.rls_fingerprint:
        _unshare_safe(job, ctx,
                      reason="policy set changed between enqueue and "
                             "execution (key/fingerprint mismatch)")
        return None
    # C3 (2026-07-23): arm the STRICT resolution window for the duration
    # of this shareable leader's execution — a resolver DB failure inside
    # enforcement now RAISES (aborting the query) instead of silently
    # rendering an UNFILTERED result that the sandwich (which proves
    # policy-set stability, not enforcement outcome) would then certify
    # and fan out.  Released by _single_flight_guard_end / the handler's
    # finally (never leaks).
    try:
        from core.row_security.resolver import push_strict_resolution
        push_strict_resolution()
    except Exception as exc:
        _unshare_safe(job, ctx,
                      reason=f"could not arm strict policy resolution: {exc}")
        return None
    return {"verified_pre": True, "strict_pushed": True}


def _single_flight_guard_release(guard: Optional[Dict[str, Any]]) -> None:
    """Idempotently release the strict-resolution window a guard armed.
    Called by _single_flight_guard_end AND by the handler's ``finally`` —
    whichever runs first pops; the other is a no-op.  Never raises."""
    if not guard or not guard.pop("strict_pushed", None):
        return
    try:
        from core.row_security.resolver import pop_strict_resolution
        pop_strict_resolution()
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("[jobqueue] strict-resolution release failed: %s", exc)


def _single_flight_guard_end(job: ClaimedJob, ctx,
                             guard: Optional[Dict[str, Any]]) -> None:
    """Post-execution arm: stamp ``share_verified`` only when the key AND
    the policy-set fingerprint STILL equal the row's enqueue-time values
    (the policy set is then proven stable from every participant's key
    computation through the end of the execution)."""
    if guard is None:
        return
    _single_flight_guard_release(guard)   # strict window ends with execution
    try:
        fingerprint = _policy_fingerprint(ctx)
        key = _recompute_rls_key(job, ctx)
        if key == job.rls_key and fingerprint == job.rls_fingerprint:
            ok = ctx.queue.set_share_verified(job.id, job.fencing_token)
            if ok:
                logger.info("[jobqueue] single-flight: job %s share_verified "
                            "(key + policy set stable across execution)",
                            job.id)
            return
        reason = "policy set changed during execution"
    except Exception as exc:
        reason = f"post-execution key re-verification failed: {exc}"
    _unshare_safe(job, ctx, reason=reason)


def _recompute_rls_key(job: ClaimedJob, ctx) -> str:
    """Strict key recompute from the REHYDRATED identity + captured SQL —
    the same inputs enforcement will use.  Raises on any uncertainty."""
    from core.identity import EffectiveRlsComputer, RlsComputationError
    unshareable = _non_shareable_request_reason(job.request or {})
    if unshareable:
        # C1/S1 (2026-07-23): a legacy pre-fix row (or forged payload)
        # whose enforcement surface exceeds raw_sql can NEVER re-verify —
        # raising here fail-closes the sandwich (unshare, no fan-out).
        raise RlsComputationError(
            f"non-shareable request shape: {unshareable}")
    raw_sql = (job.request or {}).get("raw_sql")
    if not raw_sql:
        raise RlsComputationError("no raw_sql on the captured request")
    from api import execute_api as _ea
    db = ctx.db_manager or _ea._db_manager
    if db is None:
        raise RlsComputationError("no db_manager available in the executor")
    predicates = EffectiveRlsComputer(db).compute(
        raw_sql, identity=ctx.identity,
        connection_id=(job.request or {}).get("connection_id"))
    return predicates.rls_key()


def _policy_fingerprint(ctx) -> str:
    from core.identity import compute_policy_fingerprint
    from api import execute_api as _ea
    db = ctx.db_manager or _ea._db_manager
    return compute_policy_fingerprint(db)


def _unshare_safe(job: ClaimedJob, ctx, *, reason: str) -> None:
    """Fail-closed un-share; never raises (a zombie's un-share is refused
    by the fence — the newer lease owner runs its own sandwich)."""
    try:
        ctx.queue.unshare_leader(job.id, job.fencing_token, reason=reason)
    except Exception as exc:
        logger.warning("[jobqueue] unshare of job %s failed (%s) — original "
                       "reason: %s", job.id, exc, reason)


def _maybe_stamp_passport(ctx, execution_id: Optional[str]) -> bool:
    """Phase 3 — pop the passport the reader registered for this execution
    (process-local registry, contextvar-free) and stamp it onto the job
    row, filling the ``snapshot_id`` leg of the content address.  Returns
    True when stamped (or nothing to stamp will ever appear... it can only
    say 'stamped now'); False → caller may retry later.  Fail-open."""
    if not execution_id:
        return False
    try:
        from core.industrialization import passport_registry
        d = passport_registry.pop(str(execution_id))
        if not d:
            return False
        import json as _json
        ok = ctx.queue.stamp_passport(
            ctx.job.id, ctx.job.fencing_token,
            passport_json=_json.dumps(d, sort_keys=True,
                                      separators=(",", ":")),
            snapshot_id=str(d.get("snapshot_id") or ""))
        if ok:
            logger.info("[jobqueue] passport stamped on job %s "
                        "(snapshot=%s)", ctx.job.id, d.get("snapshot_id"))
        return True   # popped — nothing further to stamp either way
    except Exception as exc:
        logger.debug("[jobqueue] passport stamp failed (fail-open): %s", exc)
        return False


# ── Phase 6 — result-artifact publish (executor side) ───────────────────

def _maybe_publish_result_artifact(job: ClaimedJob, ctx,
                                   execution_id: Optional[str]) -> None:
    """On execution success, stream the result into the artifact store
    (Arrow IPC under the full content address) so any API pod can serve
    pages/ranges from it — the result never has to ride back through pod
    RAM or live on this executor's local disk only.

    Contract (flag-gated, ADDITIVE, fail-open):
      * ``industrialization.result_artifacts`` OFF → ONE flag read, no-op
        (byte-for-byte today's behavior);
      * results at/below ``industrialization_artifacts.inline_threshold_bytes``
        stay INLINE — no artifact, no extra hop (Trino serves small
        results on the coordinator channel for the same reason);
      * ANY failure → warning log, no artifact — the executor-local
        parquet + the existing s3_results fallback still serve the query
        exactly as today (a store hiccup can never lose a query);
      * the address is read FRESH from the job row (snapshot_id was
        stamped mid-flight by the passport; the rls_key may have been
        re-keyed fail-closed by an unshare) — HARD gate 1: never less
        than the full ``(plan_hash, snapshot_id, rls_key)`` triple.
    """
    try:
        from core.industrialization import is_enabled
        if not is_enabled("result_artifacts"):
            return
    except Exception:
        return
    if not execution_id or ctx.is_zombie:
        return
    try:
        from pathlib import Path
        from api import execute_api as _ea
        db = ctx.db_manager or _ea._db_manager
        ex = db.get_execution(execution_id) if db else None
        output_file = (ex or {}).get("output_file")
        if not output_file:
            logger.debug("[artifacts] execution %s has no output_file — "
                         "staying inline", execution_id)
            return
        p = Path(output_file)
        if not p.exists() or p.suffix.lower() != ".parquet":
            logger.debug("[artifacts] execution %s result is not a local "
                         "parquet (%s) — staying inline", execution_id,
                         output_file)
            return
        threshold = int(_cfg_artifact("inline_threshold_bytes", 5242880))
        size = p.stat().st_size
        if size <= threshold:
            logger.debug("[artifacts] execution %s result (%d bytes) is at/"
                         "below the inline threshold (%d) — staying inline",
                         execution_id, size, threshold)
            return
        # Freshest address legs off the job ROW: passport stamped
        # snapshot_id mid-flight; an unshare may have re-keyed rls_key to
        # the per-job fail-closed key.  M4 (2026-07-23): when the fresh
        # row cannot be read, the rls_key leg FAILS CLOSED to the per-job
        # key — the claim-time key may be a stale SHAREABLE key an unshare
        # already revoked, and an artifact must never be addressed under a
        # key the row no longer carries.  (plan_hash/snapshot_id are
        # immutable/additive — claim-time values remain correct for them.)
        row = None
        try:
            row = ctx.queue.get(job.id)
        except Exception:
            row = None
        plan_hash = (row or {}).get("plan_hash") or job.plan_hash
        snapshot_id = (row or {}).get("snapshot_id") or job.snapshot_id
        if row is None:
            from core.jobqueue.queue import failclosed_rls_key
            rls_key = failclosed_rls_key(job.id)
        else:
            rls_key = row.get("rls_key") or job.rls_key

        from core.artifacts import get_artifact_service
        svc = get_artifact_service(db)
        svc.publish_from_parquet(
            execution_id=str(execution_id), job_id=job.id,
            plan_hash=plan_hash, snapshot_id=snapshot_id, rls_key=rls_key,
            source_parquet=p, created_by=job.enqueued_by)
    except Exception as exc:
        logger.warning("[artifacts] result-artifact publish failed for "
                       "execution %s (FAIL-OPEN — inline delivery is "
                       "unaffected): %s", execution_id, exc)


def _cfg_artifact(key: str, fallback):
    try:
        from core.config import get as _cfg_get
        v = _cfg_get("industrialization_artifacts", key, fallback)
        return type(fallback)(v) if v is not None else fallback
    except Exception:
        return fallback


def _local_cancel_execution(db, execution_id: str, *, reason: str) -> None:
    """Best-effort cancel of the execution THIS process is running (the
    background task lives on the bridge loop / worker pool of this very
    process, so local signalling reaches it)."""
    try:
        from core.worker_pool import get_pool
        get_pool().cancel_by_execution_id(execution_id)
    except Exception:
        pass
    try:
        db.update_execution(execution_id, status="cancelled",
                            error_message=f"Cancelled: {reason}")
    except Exception as exc:
        logger.warning("[jobqueue] could not mark execution %s cancelled: %s",
                       execution_id, exc)


# ── registration (idempotent) ───────────────────────────────────────────

_registered = False
_reg_lock = threading.Lock()


def ensure_handler_registered() -> None:
    global _registered
    with _reg_lock:
        if not _registered:
            register_handler("execute_query", handle_execute_query, replace=True)
            _registered = True
