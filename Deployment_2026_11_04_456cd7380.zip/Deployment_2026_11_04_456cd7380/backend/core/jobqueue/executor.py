"""JobExecutor — the claim → rehydrate → execute → write-back loop (Phase 2).

Runs in an executor role process (SAME container image as the API; the
role is selected by environment — see :func:`start_in_process_executor_if_armed`).
The executor is **contextvar-free**: identity, RLS and the request are
rehydrated from the job row's captured payloads (Phase 1
``identity_from_payload``), never from ambient request state.

Mechanics (edge cases from the hardened plan):

* Heartbeat thread renews the DB-time lease every ``heartbeat_seconds``;
  the lease grace is ``lease_seconds`` (>= 3x heartbeat by default
  config) so a GC-stalled executor merely loses the lease — its later
  writes are fenced, and the reaper requeues the job.
* A heartbeat that returns False marks the executor a **zombie** for that
  job: the cooperative cancel signal fires and no write-back is attempted
  (and would be fenced out anyway).
* The reaper runs on the executor's cadence (idempotent conditional
  UPDATEs — N concurrent reapers are safe).
* On startup the executor force-expires leases recorded for THIS host
  whose pid is dead (leaked-lease hygiene after a pod restart) before
  taking new work.
* Poison jobs: retryable failures requeue via the fenced ``fail(...,
  requeue=True)`` which quarantines at ``max_attempts``.

Handlers are a registry (plugin pattern): ``register_handler(kind, fn)``
where ``fn(job, ctx) -> Optional[result_handle]``.  The Phase-2 handler
for ``execute_query`` lives in :mod:`core.jobqueue.execute_bridge` and
drives the EXISTING execution path unchanged.
"""
from __future__ import annotations

import logging
import os
import socket
import threading
import time
from typing import Any, Callable, Dict, Optional

from core.jobqueue.queue import (
    ClaimedJob, FencingError, JobQueue, make_owner_id,
)

logger = logging.getLogger(__name__)


# ── Handler outcome exceptions ──────────────────────────────────────────

class JobHttpError(Exception):
    """The job's submit-shape failed the way an HTTP endpoint would (e.g.
    validation 400).  Terminal — retrying identical input cannot succeed.
    The API waiter relays it to the client with full parity."""

    def __init__(self, status_code: int, detail: Any, headers: Optional[Dict[str, str]] = None):
        super().__init__(f"HTTP {status_code}")
        self.status_code = int(status_code)
        self.detail = detail
        # 2026-11-03: the headers the inline route would have sent with it
        # (Retry-After on an admission refusal) -- relayed with parity
        self.headers = dict(headers) if headers else None


class JobCancelled(Exception):
    """The job observed the cooperative cancel flag and stopped."""


class NonRetryableJobError(Exception):
    """Deterministic failure — do not requeue (e.g. the query itself
    failed and the failure is recorded on the execution row)."""


class JobDeferred(Exception):
    """The handler could not START the job here yet and gives the claim back
    (2026-11-03, query pods phase 4): the job returns to the queue with its
    attempt handed back (``JobQueue.release_claim``), nothing of it ran.  The
    one case: a previous attempt of the same execution still has a live
    local task in this process.  ``delay_seconds`` names how long the job
    stays unclaimable (``not_before``), so the same pod does not take it
    straight back; the row counts every give-back (``deferrals``)."""

    def __init__(self, message: str = "", *, delay_seconds: float = 0):
        super().__init__(message)
        self.delay_seconds = float(delay_seconds or 0)


# ── Handler registry (plugin pattern) ───────────────────────────────────

_HANDLERS: Dict[str, Callable[[ClaimedJob, "JobContext"], Optional[str]]] = {}
_handlers_lock = threading.Lock()


def register_handler(kind: str,
                     fn: Callable[[ClaimedJob, "JobContext"], Optional[str]],
                     *, replace: bool = False) -> None:
    with _handlers_lock:
        if kind in _HANDLERS and not replace:
            raise ValueError(f"job handler for kind {kind!r} already registered")
        _HANDLERS[kind] = fn


def get_handler(kind: str):
    with _handlers_lock:
        return _HANDLERS.get(kind)


class JobContext:
    """Everything a handler may touch — data + services, no ambient state."""

    def __init__(self, *, queue: JobQueue, job: ClaimedJob, identity,
                 db_manager=None):
        self.queue = queue
        self.job = job
        self.identity = identity            # EffectiveIdentity (rehydrated)
        self.db_manager = db_manager
        self._zombie = threading.Event()    # set when a heartbeat is fenced out

    # -- identity as data -------------------------------------------------

    def user_dict(self) -> Dict[str, Any]:
        """The rehydrated identity in the user-dict shape the existing
        execution path expects.  Secrets were stripped at capture."""
        ident = self.identity
        d = {k: v for k, v in dict(ident.attrs or {}).items()
             if not str(k).startswith("_")}
        d.update({
            "username": ident.username,
            "role": ident.role,
            "groups": list(ident.groups),
            "is_admin": bool(ident.is_admin),
        })
        return d

    # -- cooperative control ----------------------------------------------

    def mark_zombie(self) -> None:
        self._zombie.set()

    @property
    def is_zombie(self) -> bool:
        return self._zombie.is_set()

    def cancel_requested(self) -> bool:
        """True when the job was cancelled OR this executor lost its lease
        (either way: stop working)."""
        if self._zombie.is_set():
            return True
        try:
            return self.queue.is_cancel_requested(self.job.id)
        except Exception:
            return False  # can't read → keep working; the lease protects us

    # -- relay -------------------------------------------------------------

    def stamp_response(self, response: Dict[str, Any],
                       result_handle: Optional[str]) -> bool:
        return self.queue.set_submit_response(
            self.job.id, self.job.fencing_token,
            response=response, result_handle=result_handle)


class JobExecutor:
    """The pull loop.  One instance per executor thread/process."""

    def __init__(self, queue: JobQueue, *, owner: Optional[str] = None,
                 db_manager=None, pod_class: Optional[str] = None,
                 host: Optional[str] = None, concurrency: int = 1):
        self._queue = queue
        self._db = db_manager
        self.owner = owner or make_owner_id("executor")
        # 2026-10-31 -- a QUERY POD (query-pods chart: QS_QUERY_POD_CLASS)
        # claims only jobs of its size that fit its memory budget
        # (core/query_pods/budget.py); None = the plain executor, unchanged.
        self.pod_class = (str(pod_class).strip().lower() or None) if pod_class else None
        self.host = host or socket.gethostname()
        self._budget_said: Optional[str] = None
        self._stop = threading.Event()
        # 2026-10-31 (phase 2) -- SEVERAL RUNS PER POD: this many claim loops
        # run side by side (each claim is its own reservation, each run its
        # own DuckDB process); the budgeted claim, serialized per host, is
        # what bounds them, not this number.  A query pod uses its size's
        # runs_per_pod.
        self.concurrency = max(1, int(concurrency or 1))
        self._threads: list = []
        self._in_flight: set = set()
        self._claiming = 0
        self._in_flight_lock = threading.Lock()
        # DRAIN (phase 2): set on SIGTERM / the lifespan shutdown.  A draining
        # executor claims nothing new; its running jobs finish within the
        # drain budget; readiness reads it (core/jobqueue/executor.py::
        # executor_is_draining -> /health/ready 503).
        self._draining = threading.Event()
        self._last_beat = float("-inf")
        # 2026-09-26 -- -inf, not 0.0: every tick is DUE on the first loop.
        # 0.0 meant "due once time.monotonic() exceeds the cadence", i.e. the
        # host's uptime -- a freshly booted node (or CI VM) skipped the first
        # artifact GC / island tick for up to 10 minutes.
        self._last_reap = float("-inf")
        self._last_artifact_gc = float("-inf")
        self._last_island_tick = float("-inf")

    # -- config ------------------------------------------------------------

    @staticmethod
    def _cfg(key: str, fallback):
        try:
            from core.config import get as _cfg_get
            v = _cfg_get("jobqueue", key, fallback)
            return type(fallback)(v) if v is not None else fallback
        except Exception:
            return fallback

    # -- lifecycle ---------------------------------------------------------

    def stop(self) -> None:
        self._stop.set()

    def startup_hygiene(self) -> None:
        """Restarted-pod cleanup: force-expire leases recorded for this
        host whose executor pid is dead, then reap.  Best-effort."""
        try:
            host = socket.gethostname()
            alive = _alive_pids_on_this_host()
            if alive is not None:
                # Only when we can POSITIVELY enumerate live pids — an
                # incomplete guess would force-expire a LIVE executor's
                # lease (fencing keeps that correct, but it would waste a
                # duplicate execution).
                self._queue.expire_dead_local_leases(host, alive)
            self._queue.reap_orphans()
        except Exception as exc:
            logger.warning("[jobqueue] startup hygiene failed (non-fatal): %s", exc)

    def run_forever(self) -> None:
        poll = self._cfg("poll_interval_seconds", 1.0)
        logger.info("[jobqueue] executor loop starting (owner=%s, %d claim loop(s)%s)",
                    self.owner, self.concurrency,
                    f", query pod size {self.pod_class.upper()}" if self.pod_class else "")
        self.startup_hygiene()
        # the extra claim loops (several runs per pod); this thread is loop 0
        for i in range(1, self.concurrency):
            t = threading.Thread(target=self._loop, args=(poll, i),
                                 name=f"jobqueue-executor-{i}", daemon=True)
            t.start()
            self._threads.append(t)
        self._loop(poll, 0)
        for t in self._threads:
            t.join(timeout=5.0)
        self._forget_presence()
        logger.info("[jobqueue] executor loop stopped (owner=%s)", self.owner)

    def _loop(self, poll: float, index: int) -> None:
        while not self._stop.is_set():
            worked = False
            try:
                worked = self.run_once()
            except Exception as exc:
                logger.error("[jobqueue] executor loop iteration failed: %s",
                             exc, exc_info=True)
            if index == 0:
                self._maybe_reap()
                self._maybe_beat()
            if not worked:
                self._stop.wait(poll)

    # -- drain (phase 2) ---------------------------------------------------

    @property
    def draining(self) -> bool:
        return self._draining.is_set()

    def in_flight(self) -> int:
        """Runs this executor holds -- including a claim in progress."""
        with self._in_flight_lock:
            return len(self._in_flight) + self._claiming

    def begin_drain(self) -> None:
        """From now on: claim nothing new.  Readiness goes false (the probe
        reads ``executor_is_draining``); running jobs continue."""
        if not self._draining.is_set():
            self._draining.set()
            logger.warning("[jobqueue] DRAIN started (owner=%s): claiming nothing new, "
                           "%d run(s) still going", self.owner, self.in_flight())
            self._beat(force=True)

    def drain(self, timeout: float) -> bool:
        """Begin the drain and wait until every running job has finished or
        ``timeout`` seconds passed.  Returns True when drained.  A run still
        going when time runs out is left to its lease: the pod dies, the
        lease expires, the reaper retries a READ once on another pod or fails
        it with the reason (rule 4)."""
        self.begin_drain()
        deadline = time.monotonic() + max(0.0, float(timeout))
        while self.in_flight() > 0 and time.monotonic() < deadline:
            time.sleep(0.25)
        left = self.in_flight()
        if left:
            logger.warning("[jobqueue] drain budget (%.0fs) ran out with %d run(s) still going; "
                           "their leases will expire and the queue decides (retry a read "
                           "once, else fail with the reason)", timeout, left)
        else:
            logger.info("[jobqueue] drained: no runs in flight (owner=%s)", self.owner)
        self.stop()
        return left == 0

    # -- presence (phase 2) ------------------------------------------------

    def _maybe_beat(self) -> None:
        if not self.pod_class:
            return
        now = time.monotonic()
        if now - self._last_beat >= self._beat_seconds():
            self._beat()

    @staticmethod
    def _beat_seconds() -> float:
        return 5.0

    def _beat(self, force: bool = False) -> None:
        """This query pod's "I am alive" row (core/query_pods/presence.py)."""
        if not self.pod_class:
            return
        self._last_beat = time.monotonic()
        try:
            from core.query_pods import budget as _budget, presence
            pb = _budget.pod_budget(self.pod_class)
            if pb is None:
                # CONFIG DRIFT: this pod's size is not in ITS config, so it
                # claims nothing (phase 1).  It must not say "alive" either --
                # a waiting run would count on a pod that will never take it,
                # and the no-pod sweep would never fail it.  Not present.
                presence.forget(self._db or self._queue._db, self.host)
                return
            presence.beat(self._db or self._queue._db, host=self.host, pod_class=self.pod_class,
                          budget_bytes=pb.budget_bytes, in_flight=self.in_flight(),
                          draining=self.draining)
        except Exception as exc:
            logger.debug("[jobqueue] presence beat skipped: %s", exc)

    def _forget_presence(self) -> None:
        if not self.pod_class:
            return
        try:
            from core.query_pods import presence
            presence.forget(self._db or self._queue._db, self.host)
        except Exception as exc:
            logger.debug("[jobqueue] presence row not removed: %s", exc)

    def _maybe_reap(self) -> None:
        cadence = self._cfg("reap_interval_seconds", 30)
        now = time.monotonic()
        if now - self._last_reap >= cadence:
            self._last_reap = now
            try:
                self._queue.reap_orphans()
            except Exception as exc:
                logger.warning("[jobqueue] reap failed (non-fatal): %s", exc)
        # Phase 6 — result-artifact GC rides the executor/reaper loop on
        # its own (slower) cadence.  Flag OFF → one flag read inside the
        # tick, no-op.  Fail-open: the tick never raises.
        try:
            from core.config import get as _cfg_get
            gc_cadence = int(_cfg_get("industrialization_artifacts",
                                      "gc_interval_seconds", 300) or 300)
        except Exception:
            gc_cadence = 300
        if now - self._last_artifact_gc >= gc_cadence:
            self._last_artifact_gc = now
            try:
                from core.artifacts import artifact_gc_tick
                artifact_gc_tick(self._db)
            except Exception as exc:
                logger.warning("[jobqueue] artifact gc tick failed "
                               "(non-fatal): %s", exc)

        # Phase 8 — materialized-island background build + GC rides the
        # same executor/reaper loop on its own cadence.  Flag OFF → one
        # flag read inside the tick, no-op.  Fail-open: the tick never
        # raises.
        try:
            from core.config import get as _cfg_get
            island_cadence = int(_cfg_get("industrialization_materialized_islands",
                                          "gc_interval_seconds", 600) or 600)
        except Exception:
            island_cadence = 600
        if now - self._last_island_tick >= island_cadence:
            self._last_island_tick = now
            try:
                from core.materialized_islands import materialized_island_tick
                materialized_island_tick(self._db)
            except Exception as exc:
                logger.warning("[jobqueue] materialized-island tick failed "
                               "(non-fatal): %s", exc)

    # -- one claim+execute cycle (also the unit-test entrypoint) -----------

    def run_once(self) -> bool:
        """Claim and execute at most one job.  Returns True when a job was
        processed (success OR failure), False when the queue was empty."""
        # A claim IN PROGRESS counts as in flight: a drain that looked between
        # claim_next returning and the job being recorded would have seen
        # nothing in flight and let the process exit with a claimed run.
        with self._in_flight_lock:
            self._claiming += 1
        try:
            job = self.claim()
            if job is None:
                return False
            with self._in_flight_lock:
                self._in_flight.add(job.id)
        finally:
            with self._in_flight_lock:
                self._claiming -= 1
        try:
            self._execute_claimed(job)
        finally:
            with self._in_flight_lock:
                self._in_flight.discard(job.id)
        return True

    def claim(self) -> Optional[ClaimedJob]:
        """One claim: plain for an ordinary executor; BUDGETED for a query
        pod -- its size and its budget measured now (cgroup limit minus its
        own process minus the reserve), the idle budget being its size's.
        A query pod whose size is not configured claims NOTHING and says so
        once: an unknown budget is not an unlimited one.

        Phase 2: a DRAINING executor claims nothing.  A PLAIN executor on a
        fleet with sizes configured claims only UNSIZED jobs -- a sized job
        belongs to a pod of its size (design §5.1); taking it here would put
        the heavy run back in the API pod."""
        if self._draining.is_set():
            return None
        from core.query_pods import budget as _budget
        if not self.pod_class:
            if _budget.pricing_enabled():
                return self._queue.claim_next(self.owner, only_unsized=True)
            return self._queue.claim_next(self.owner)       # no sizes: the claim as before
        pb = _budget.pod_budget(self.pod_class)
        if pb is None:
            self._say_budget_once(
                f"query pod size {self.pod_class.upper()} is not in query_pods.classes "
                "-- this pod claims no runs until it is")
            return None
        self._say_budget_once(
            f"query pod size {pb.pod_class.upper()}: budget "
            f"{pb.budget_bytes / 1024 ** 3:.1f} GB for runs (limit "
            f"{pb.limit_bytes / 1024 ** 3:.1f} GB from {pb.limit_source}, "
            f"{pb.reserve_bytes / 1024 ** 2:.0f} MB kept for the pod itself)")
        job = self._queue.claim_next(
            self.owner, host=self.host, pod_class=pb.pod_class,
            budget_bytes=pb.budget_bytes, idle_budget_bytes=pb.idle_budget_bytes)
        if job is not None:
            try:
                free = _budget.free_bytes(self.host, self._db or self._queue._db, pb.budget_bytes)
                logger.info("[jobqueue] query pod %s took job %s: %.1f GB reserved (%s price), "
                            "%.1f GB of its budget still free", self.host, job.id,
                            job.reserved_bytes / 1024 ** 3, job.price_source or "unpriced",
                            max(0, free) / 1024 ** 3)
            except Exception as exc:
                logger.debug("[jobqueue] free budget unreadable after the claim: %s", exc)
        return job

    def _say_budget_once(self, sentence: str) -> None:
        if sentence != self._budget_said:
            self._budget_said = sentence
            logger.info("[jobqueue] %s", sentence)

    # -- internals ---------------------------------------------------------

    def _execute_claimed(self, job: ClaimedJob) -> None:
        token = job.fencing_token
        logger.info("[jobqueue] claimed job=%s kind=%s attempt=%d/%d token=%d",
                    job.id, job.kind, job.attempts, job.max_attempts, token)

        # 1. Rehydrate identity FROM DATA — fail-closed.  A malformed
        #    identity payload is terminal (retrying cannot fix data).
        try:
            from core.identity import identity_from_payload
            identity = identity_from_payload(job.identity_payload)
        except Exception as exc:
            self._safe_fail(job, token,
                            error=f"identity rehydration failed (refusing to run "
                                  f"without a verified identity): {exc}",
                            requeue=False)
            return

        ctx = JobContext(queue=self._queue, job=job, identity=identity,
                         db_manager=self._db)

        # 2. Resolve the handler.  Unknown kind → terminal failure (an
        #    older executor must not misinterpret a newer job kind).
        handler = get_handler(job.kind)
        if handler is None:
            self._safe_fail(job, token,
                            error=f"no handler registered for job kind "
                                  f"{job.kind!r} in this executor build",
                            requeue=False)
            return

        # 3. Pre-start cooperative cancel check (cheap stage boundary).
        try:
            if self._queue.is_cancel_requested(job.id):
                self._queue.mark_cancelled(job.id, token,
                                           note="cancelled before execution started")
                return
        except FencingError:
            return
        except Exception:
            pass  # unreadable flag → proceed; lease/fencing still protect us

        # 4. leased → running + heartbeat thread.
        try:
            self._queue.mark_running(job.id, token)
        except FencingError:
            logger.warning("[jobqueue] job %s reaped before start (token %d) — "
                           "abandoning claim", job.id, token)
            return
        hb_stop = threading.Event()
        hb_thread = threading.Thread(
            target=self._heartbeat_loop, args=(job, token, ctx, hb_stop),
            name=f"jobqueue-hb-{job.id[:8]}", daemon=True)
        hb_thread.start()

        # 5. Execute.
        try:
            result_handle = handler(job, ctx)
        except JobCancelled as jc:
            # Bind the note EAGERLY: `jc` is deleted when the except block
            # exits, so a lambda that closes over it would raise NameError
            # if _safe_terminal ever deferred or re-ran the callable.
            _cancel_note = str(jc) or "cancelled"
            self._safe_terminal(lambda: self._queue.mark_cancelled(
                job.id, token, note=_cancel_note), job, "cancel")
            return
        except JobHttpError as he:
            import json as _json
            http = {"status_code": he.status_code, "detail": he.detail}
            if he.headers:            # additive: an error without headers reads as before
                http["headers"] = he.headers
            payload = _json.dumps({"__http__": http}, default=str)
            self._safe_fail(job, token, error=payload, requeue=False)
            return
        except NonRetryableJobError as nre:
            self._safe_fail(job, token, error=str(nre), requeue=False)
            return
        except JobDeferred as deferred:
            _defer_note = str(deferred) or "deferred"
            _defer_delay = getattr(deferred, "delay_seconds", 0)
            logger.info("[jobqueue] job %s given back, not run: %s", job.id, _defer_note)
            self._safe_terminal(lambda: self._queue.release_claim(
                job.id, token, note=_defer_note,
                delay_seconds=_defer_delay), job, "release")
            return
        except Exception as exc:
            logger.error("[jobqueue] job %s crashed in handler: %s",
                         job.id, exc, exc_info=True)
            # Crash-shaped failure → retry up to max_attempts (Tardigrade-
            # style task retry); quarantines automatically at the bound.
            self._safe_fail(job, token, error=f"handler crash: {exc}", requeue=True)
            return
        finally:
            hb_stop.set()

        # 6. Terminal success (fenced — a zombie's complete is refused).
        self._safe_terminal(lambda: self._queue.complete(
            job.id, token, result_handle=result_handle), job, "complete")

    def _heartbeat_loop(self, job: ClaimedJob, token: int, ctx: JobContext,
                        stop: threading.Event) -> None:
        interval = self._cfg("heartbeat_seconds", 20)
        lease = self._cfg("lease_seconds", 120)
        while not stop.wait(interval):
            try:
                ok = self._queue.heartbeat(job.id, token, lease_seconds=lease)
            except Exception as exc:
                logger.warning("[jobqueue] heartbeat error for job %s: %s "
                               "(lease still valid until expiry)", job.id, exc)
                continue
            if not ok:
                logger.warning(
                    "[jobqueue] job %s heartbeat FENCED OUT (token %d) — this "
                    "executor is a zombie for the job; signalling stop",
                    job.id, token)
                ctx.mark_zombie()
                return

    def _safe_fail(self, job: ClaimedJob, token: int, *, error: str,
                   requeue: bool) -> None:
        try:
            status = self._queue.fail(job.id, token, error=error, requeue=requeue)
            logger.warning("[jobqueue] job %s -> %s (%s)", job.id, status,
                           error[:200])
        except FencingError:
            logger.warning("[jobqueue] job %s fail write fenced out (token %d) "
                           "— a newer lease owns it", job.id, token)
        except Exception as exc:
            logger.error("[jobqueue] job %s fail write errored: %s (reaper "
                         "will recover via lease expiry)", job.id, exc)

    @staticmethod
    def _safe_terminal(fn, job: ClaimedJob, what: str) -> None:
        try:
            fn()
        except FencingError:
            logger.warning("[jobqueue] job %s %s fenced out — a newer lease "
                           "owns it; zombie write refused", job.id, what)
        except Exception as exc:
            logger.error("[jobqueue] job %s %s write errored: %s (reaper will "
                         "recover via lease expiry)", job.id, what, exc)


# ── Role bootstrap (same image; role via env) ───────────────────────────

_started_lock = threading.Lock()
_started: Dict[str, Any] = {"executor": None, "thread": None}


def executor_role_enabled() -> bool:
    """Should THIS process run the executor loop?

    Precedence:
      1. ``QS_JOBQUEUE_EXECUTOR`` env — explicit operator choice
         (``1/true/yes`` → yes, ``0/false/no`` → no).
      2. Pod role: ``worker`` and ``hybrid`` run it (hybrid = single-pod
         dev, where queue mode must work out of the box); ``api`` does not
         (thin frontend — nothing heavy in-process).
    """
    env = os.environ.get("QS_JOBQUEUE_EXECUTOR", "").strip().lower()
    if env in ("1", "true", "yes", "on"):
        return True
    if env in ("0", "false", "no", "off"):
        return False
    try:
        from core.pod_role import current as _pod_role_current
        role = _pod_role_current().role
        return role in ("worker", "hybrid")
    except Exception:
        return True  # role machinery unavailable → default batteries-included


def start_in_process_executor_if_armed(db_manager) -> bool:
    """Startup hook (called from main.py after execute dependencies are
    wired).  Starts the executor daemon thread when — and only when —
    ``industrialization.queue_mode`` is armed AND this process's role says
    executor.  Flag OFF (the default) → no thread, byte-for-byte today.
    Never raises."""
    try:
        from core.industrialization import is_enabled
        if not is_enabled("queue_mode"):
            return False
        if not executor_role_enabled():
            logger.info("[jobqueue] queue_mode armed but this process's role "
                        "is not executor — not starting the loop")
            return False
        with _started_lock:
            if _started["thread"] is not None and _started["thread"].is_alive():
                return True
            # Ensure the execute_query handler is registered -- and (query
            # pods phase 4, 2026-11-03) the execute_report one, so a query
            # pod takes report runs beside ad-hoc queries.
            from core.jobqueue import execute_bridge, report_bridge
            execute_bridge.ensure_handler_registered()
            report_bridge.ensure_handler_registered()
            from core.jobqueue.queue import get_job_queue
            from core.query_pods.budget import pod_class_from_env
            queue = get_job_queue(db_manager)
            pod_class = pod_class_from_env()
            executor = JobExecutor(queue, db_manager=db_manager, pod_class=pod_class,
                                   concurrency=runs_per_pod_for(pod_class))
            thread = threading.Thread(target=executor.run_forever,
                                      name="jobqueue-executor", daemon=True)
            thread.start()
            _started["executor"] = executor
            _started["thread"] = thread
        logger.info("[jobqueue] in-process executor started (queue_mode armed)")
        return True
    except Exception as exc:
        logger.error("[jobqueue] executor bootstrap failed (queue mode will "
                     "fail open to inline execution): %s", exc, exc_info=True)
        return False


def runs_per_pod_for(pod_class: Optional[str]) -> int:
    """How many claim loops a query pod of ``pod_class`` runs: its size's
    ``runs_per_pod`` (the number both scalers divide by); 1 for a plain
    executor or an unknown size."""
    if not pod_class:
        return 1
    try:
        from core.query_pods.budget import settings_or_none
        s = settings_or_none()
        cls = s.by_name().get(str(pod_class).strip().lower()) if s else None
        return max(1, int(cls.runs_per_pod)) if cls else 1
    except Exception:
        return 1


def stop_in_process_executor() -> None:
    with _started_lock:
        ex = _started.get("executor")
        if ex is not None:
            ex.stop()


# ── drain (phase 2): the one entry the shutdown paths call ────────────────

def drain_seconds() -> float:
    """The drain budget: ``jobqueue.drain_seconds`` when set; else the pod's
    ``QS_TERMINATION_GRACE_SECONDS`` (the chart's terminationGracePeriodSeconds)
    minus 15 s of headroom for the exit itself; else 60 for a query pod and,
    for any other process running an executor (a hybrid API pod), the API's
    own ``server.shutdown_drain_seconds`` -- its grace is ~30 s, and a drain
    longer than the grace is a SIGKILL mid-write, not a drain."""
    try:
        from core.config import get as _cfg_get
        v = float(_cfg_get("jobqueue", "drain_seconds", 0) or 0)
        if v > 0:
            return v
    except Exception:
        pass
    try:
        grace = float(os.environ.get("QS_TERMINATION_GRACE_SECONDS", "") or 0)
        if grace > 0:
            return max(5.0, grace - 15.0)
    except ValueError:
        pass
    try:
        from core.query_pods.budget import pod_class_from_env
        if pod_class_from_env():
            return 60.0
        from core.config import server as _srv_cfg
        return float(max(1, min(int(getattr(_srv_cfg, "shutdown_drain_seconds", 25)), 120)))
    except Exception:
        return 25.0


def executor_is_draining() -> bool:
    """Readiness reads this: a draining query pod answers 503 so the Service
    stops routing to it while its runs finish."""
    ex = _started.get("executor")
    return bool(ex is not None and ex.draining)


def drain_in_process_executor(timeout: Optional[float] = None) -> Optional[bool]:
    """Begin the drain and wait for the running jobs (up to ``timeout``,
    default ``drain_seconds()``).  None when no executor runs here; else
    whether everything finished in time.  Idempotent; never raises."""
    ex = _started.get("executor")
    if ex is None:
        return None
    try:
        return ex.drain(drain_seconds() if timeout is None else float(timeout))
    except Exception as exc:
        logger.warning("[jobqueue] drain failed: %s", exc)
        return False


def _alive_pids_on_this_host():
    """Set of live pids when POSITIVELY enumerable, else ``None`` (skip
    dead-lease hygiene rather than guess — force-expiring a live lease
    would waste a duplicate execution)."""
    try:
        import psutil
        return set(psutil.pids())
    except Exception:
        pass
    try:  # POSIX fallback
        pids = {int(p) for p in os.listdir("/proc") if p.isdigit()}
        if pids:
            return pids
    except Exception:
        pass
    return None
