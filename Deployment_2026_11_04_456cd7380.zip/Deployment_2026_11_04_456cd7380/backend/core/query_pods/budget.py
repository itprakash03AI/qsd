"""A query pod's memory BUDGET, and the reservation a run carries into DuckDB.

Design: ``docs/QUERY_PODS_DESIGN_2026_10_29.html`` §5.3 (reserve, then run).

THE RULES, each the answer to one failure the 2026-10-28 UAT restart showed:

* A pod's budget is what its container may use minus what the pod's own
  process already uses minus a reserve -- never "75 % of the pod shared by
  whatever is running when this query starts".
* Nothing is reserved in memory.  The reservation IS the job row: a pod's
  held bytes are ``SUM(reserved_bytes)`` over the jobs it holds a LIVE lease
  on (``JobQueue.reserved_bytes_on_host``).  A pod that dies cannot leak:
  its leases expire and the bytes come back with them.  There is no
  release write to forget -- complete / fail / cancel / reaper all end the
  lease, and an ended lease is not counted.
* The run's DuckDB ``memory_limit`` is exactly its reservation (divided
  among the children ONE dispatch fans out to, never by the other queries
  on the pod).  The reservation reaches the spawn through a ContextVar set
  around the run and, for a hop that drops the context, a bounded registry
  keyed by execution id -- the same two roads the passport already uses.

Nothing here is read unless ``query_pods.classes`` is configured
(``pricing_enabled``): with no sizes, every function answers "no budget"
and the queue, the executor and the DuckDB spawn behave exactly as before.
"""
from __future__ import annotations

import contextlib
import contextvars
import logging
import os
import threading
from dataclasses import dataclass
from typing import Any, Dict, Iterator, Optional, Tuple

from core.query_pods.classes import PodClass, Settings, SettingsError, load_settings

logger = logging.getLogger(__name__)

GI = 1024 ** 3
MB = 1024 ** 2


def memory_words(n: int) -> str:
    """An amount of memory as a person reads it -- ONE wording for every
    query pod sentence.  Under 1 GB in MB (256 MB was printed "0.2 GB", which
    is not what was set aside); then one decimal of GB; whole GB from 10."""
    n = int(n or 0)
    if n < GI:
        return f"{round(n / MB)} MB"
    v = n / GI
    return f"{v:.0f} GB" if v >= 10 else f"{v:.1f} GB"

#: the Deployment of a size exports this (query-pods chart); unset = not a query pod
POD_CLASS_ENV = "QS_QUERY_POD_CLASS"

#: the smallest ``memory_limit`` worth handing one DuckDB child (the engine's
#: own floor -- ``core.duckdb_resource_limits.MIN_PER_CHILD_MEMORY_BYTES``)
MIN_CHILD_BYTES = 256 * MB


def cfg_number(key: str, fallback: float) -> float:
    try:
        from core.config import get_section
        raw = (get_section("query_pods") or {}).get(key, fallback)
        v = float(raw)
        return v if v >= 0 else fallback
    except Exception:
        return fallback


def settings_or_none() -> Optional[Settings]:
    """The configured sizes, or None (unreadable settings are LOGGED, and
    read as "no query pods" -- a pod must not price on a guess)."""
    try:
        return load_settings()
    except SettingsError as exc:
        logger.warning("[query-pods] settings cannot be used, pricing is off: %s", exc)
        return None
    except Exception as exc:
        logger.warning("[query-pods] settings unreadable, pricing is off: %s", exc)
        return None


def pricing_enabled(settings: Optional[Settings] = None) -> bool:
    """True when at least one query-pod size is configured -- THE switch."""
    s = settings if settings is not None else settings_or_none()
    return bool(s is not None and s.classes)


def pod_class_from_env() -> Optional[str]:
    """The size THIS process serves (``QS_QUERY_POD_CLASS``), or None."""
    v = os.environ.get(POD_CLASS_ENV, "").strip().lower()
    return v or None


def pod_reserve_bytes() -> int:
    """What a query pod keeps for its own process (config
    ``query_pods.pod_reserve_mb``, 1024)."""
    return int(cfg_number("pod_reserve_mb", 1024) * MB)


def class_budget_bytes(cls: PodClass) -> int:
    """The bytes a size can set aside for runs: its memory minus the pod's
    reserve.  The SAME number prices a run (which size fits) and bounds an
    idle pod's claim, so a run that fit at pricing can always start."""
    return max(0, int(cls.memory_gi * GI) - pod_reserve_bytes())


def smallest_class_that_fits(price_bytes: int, settings: Settings) -> Optional[PodClass]:
    for cls in sorted(settings.classes, key=lambda c: (c.memory_gi, c.name)):
        if class_budget_bytes(cls) >= int(price_bytes):
            return cls
    return None


def largest_class(settings: Settings) -> Optional[PodClass]:
    if not settings.classes:
        return None
    return max(settings.classes, key=lambda c: (c.memory_gi, c.name))


# ── this pod's budget ───────────────────────────────────────────────────────

def pod_memory_limit_bytes(cls: PodClass) -> Tuple[int, str]:
    """The container's memory limit and where it came from: the operator's
    ``query_pods.pod_memory_override_mb`` (``override``), the cgroup
    (``cgroup``, v1 or v2 -- the one reader the DuckDB limits already use),
    else the size the chart gave the Deployment (``class``)."""
    override = int(cfg_number("pod_memory_override_mb", 0) * MB)
    if override > 0:
        return override, "override"
    try:
        from core.duckdb_resource_limits import _read_cgroup_memory_limit_bytes
        v = _read_cgroup_memory_limit_bytes()
        if v and v > 0:
            return int(v), "cgroup"
    except Exception as exc:
        logger.debug("[query-pods] cgroup limit unreadable: %s", exc)
    return int(cls.memory_gi * GI), "class"


def process_rss_bytes() -> int:
    """This process's resident memory (0 when it cannot be measured)."""
    try:
        import psutil
        return int(psutil.Process().memory_info().rss)
    except Exception as exc:
        logger.debug("[query-pods] process RSS unreadable: %s", exc)
        return 0


@dataclass(frozen=True)
class PodBudget:
    pod_class: str
    limit_bytes: int
    limit_source: str
    reserve_bytes: int          # max(configured reserve, measured RSS)
    rss_bytes: int
    budget_bytes: int           # limit - reserve: what runs may hold at once
    idle_budget_bytes: int      # what an idle pod admits: the size's priced budget

    def as_dict(self) -> Dict[str, Any]:
        return {"pod_class": self.pod_class, "limit_bytes": self.limit_bytes,
                "limit_source": self.limit_source, "reserve_bytes": self.reserve_bytes,
                "rss_bytes": self.rss_bytes, "budget_bytes": self.budget_bytes,
                "idle_budget_bytes": self.idle_budget_bytes}


def pod_budget(pod_class: str, settings: Optional[Settings] = None) -> Optional[PodBudget]:
    """The budget this pod claims against RIGHT NOW, or None when the size is
    not configured (the pod then claims nothing and says so -- unknown is not
    "unlimited").

    ``budget_bytes`` = limit - max(reserve, measured RSS): a pod whose own
    process has grown past the reserve shrinks what it admits.
    ``idle_budget_bytes`` = the size's priced budget: a pod holding NO run
    admits any run priced for its size, so a run that fit when it was priced
    never waits forever for a pod whose RSS crept above the reserve (the
    reservation, not this bound, is what DuckDB is held to)."""
    s = settings if settings is not None else settings_or_none()
    if s is None:
        return None
    cls = s.by_name().get(str(pod_class or "").strip().lower())
    if cls is None:
        return None
    limit, source = pod_memory_limit_bytes(cls)
    rss = process_rss_bytes()
    reserve = max(pod_reserve_bytes(), rss)
    return PodBudget(pod_class=cls.name, limit_bytes=limit, limit_source=source,
                     reserve_bytes=reserve, rss_bytes=rss,
                     budget_bytes=max(0, limit - reserve),
                     idle_budget_bytes=class_budget_bytes(cls))


def free_bytes(host: str, db: Any, budget_bytes: int) -> int:
    """``budget_bytes`` minus what the pod ``host`` holds in live leases --
    DERIVED FROM ROWS every time (no counter).  For display and decisions
    outside the claim; the claim itself re-derives it under its lock."""
    from core.jobqueue.queue import JobQueue
    held = JobQueue(db).reserved_bytes_on_host(host)
    return int(budget_bytes) - int(held)


# ── the reservation a run carries into DuckDB ──────────────────────────────

_RESERVATION: "contextvars.ContextVar[int]" = contextvars.ContextVar(
    "qs_query_pod_reservation_bytes", default=0)

_MAX_NOTED = 256
_noted: Dict[str, Tuple[int, Optional[str]]] = {}
_noted_lock = threading.Lock()


@contextlib.contextmanager
def reservation_scope(reserved_bytes: int) -> Iterator[None]:
    """Run a block with ``reserved_bytes`` as THE reservation of the run it
    starts: every task the block creates copies the context, so the spawn
    deep in the engine reads it back with :func:`current_reservation_bytes`."""
    token = _RESERVATION.set(max(0, int(reserved_bytes or 0)))
    try:
        yield
    finally:
        _RESERVATION.reset(token)


def current_reservation_bytes() -> int:
    return int(_RESERVATION.get() or 0)


def note_reservation(execution_id: str, reserved_bytes: int, owner: Optional[str] = None) -> None:
    """Second road for a hop that drops the context (``run_in_executor``):
    the executor notes the run's reservation by execution id once it has
    one.  Bounded, like the passport registry.  ``owner`` (2026-11-03,
    fourth review) names WHICH attempt noted it: a retry of the same
    execution notes under its own owner, and the previous attempt's late
    ``forget_reservation`` (a done-callback that may fire after the retry
    started) cannot take the retry's note with it."""
    if not execution_id or int(reserved_bytes or 0) <= 0:
        return
    with _noted_lock:
        _noted[str(execution_id)] = (int(reserved_bytes), owner)
        while len(_noted) > _MAX_NOTED:
            _noted.pop(next(iter(_noted)), None)


def forget_reservation(execution_id: str, owner: Optional[str] = None) -> None:
    """Forget the note -- only the caller's own (``owner`` given and equal to
    the note's); ``owner`` None forgets whoever's note is there."""
    if not execution_id:
        return
    with _noted_lock:
        cur = _noted.get(str(execution_id))
        if cur is None:
            return
        if owner is None or cur[1] == owner:
            _noted.pop(str(execution_id), None)


def reservation_for(execution_id: Optional[str]) -> int:
    """The reservation for a spawn: the context's, else the noted one."""
    v = current_reservation_bytes()
    if v > 0:
        return v
    if not execution_id:
        return 0
    with _noted_lock:
        cur = _noted.get(str(execution_id))
    return int(cur[0]) if cur else 0


def max_children_for_reservation(reserved_bytes: int) -> int:
    """How many DuckDB children a reservation can hold at the engine's own
    floor (``MIN_CHILD_BYTES`` each), at least 1 -- THE bound the fan-out
    decision applies (``core/multi_worker_executor.py``).  0 = no
    reservation = no bound from here."""
    reserved = int(reserved_bytes or 0)
    if reserved <= 0:
        return 0
    return max(1, reserved // MIN_CHILD_BYTES)


def duckdb_memory_limit_for_spawn(execution_id: Optional[str], fan_out: int) -> int:
    """The ``memory_limit`` (MB) one DuckDB child of this run gets, or 0 when
    the run carries no reservation (the spawn then resolves as before).

    The reservation is split among the children ONE dispatch runs at once
    (``fan_out``; 0 / 1 = a single child) -- and NOT by the other queries on
    the pod: they hold their own reservations.

    THE RULE (security review 2026-10-31): the TOTAL handed to a run's
    children never exceeds its reservation.  The first version floored each
    child at the engine's minimum, so a wide fan-out made ``fan_out x floor``
    larger than the reservation -- the budget the pod admitted the run on was
    not what its processes could use.  The fan-out is bounded BEFORE the
    spawn, where it is decided (``max_children_for_reservation``, applied in
    the multi-worker executor); here a child's share is simply
    ``reservation // fan_out``, and a fan-out that somehow arrives wider
    than the reservation holds is logged and still divided -- never lifted."""
    reserved = reservation_for(execution_id)
    if reserved <= 0:
        return 0
    n = max(1, int(fan_out or 1))
    per_child = reserved // n
    if per_child < MIN_CHILD_BYTES:
        logger.warning("[query-pods] execution %s: %d children share a %.0f MB reservation "
                       "(%.0f MB each, under the engine's %.0f MB floor) -- the fan-out "
                       "should have been bounded where it was decided",
                       execution_id or "-", n, reserved / MB, per_child / MB, MIN_CHILD_BYTES / MB)
    return max(1, per_child // MB)


def waiting_sentence(position: Optional[int], pod_class: str = "") -> str:
    """What the screen says while a sized run waits for a pod: "Waiting for a
    query pod -- 2nd in line" (the size named when known)."""
    size = f" (size {pod_class.upper()})" if pod_class else ""
    if not position or position < 1:
        return f"Waiting for a query pod{size}"
    n = int(position)
    suffix = "th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"Waiting for a query pod{size} -- {n}{suffix} in line"


def clear_reservations_for_tests() -> None:
    with _noted_lock:
        _noted.clear()


__all__ = [
    "GI", "MB", "MIN_CHILD_BYTES", "POD_CLASS_ENV", "PodBudget",
    "class_budget_bytes", "clear_reservations_for_tests", "current_reservation_bytes",
    "duckdb_memory_limit_for_spawn", "forget_reservation", "free_bytes", "largest_class",
    "max_children_for_reservation", "note_reservation", "pod_budget", "pod_class_from_env",
    "pod_memory_limit_bytes",
    "pod_reserve_bytes", "pricing_enabled", "process_rss_bytes", "reservation_for",
    "reservation_scope", "settings_or_none", "smallest_class_that_fits", "waiting_sentence",
]
