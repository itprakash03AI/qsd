# Operator Pre-Deploy Checklist

Things this Helm tree **assumes** exist in the target cluster. Run
[bin/preflight.sh](bin/preflight.sh) to verify, or work through this list
manually before the first `deploy.sh`.

## 1. Cluster-wide CRDs + Operators

| Item | Required | Notes |
|---|---|---|
| **cert-manager** + `ClusterIssuer tpp-venafi-issuer-cluster-ca9` | yes (when `certs.enabled=true`) | Used by the api / ui / reports / downloads / published-api Certificate resources (every chart whose pod mounts `<fullname>-cert`; 2026-09-29). Without it, TLS Secrets never materialise and Routes serve HTTP. |
| **OpenShift Route CRD** (`routes.route.openshift.io`) | yes (when `route.enabled=true`) | Comes with OCP 4.x. On vanilla K8s replace with the `ingress.enabled` block — not currently in any chart, add via PR. |
| **BarcLoadBalancer CRD** (`bcp.barclays.com/v1`) | yes (when `blb.enabled=true`) | Barclays-specific. Outside Barclays infra set `blb.enabled=false` everywhere. |
| **Vault Sidecar Injector** (`vault-agent-injector` Deployment in `vault` or `cld` namespace) | yes (when `csm.enabled=true`) | Reads the `vault.hashicorp.com/*` pod annotations and injects keytab/AD password into pods. Without it the pod starts but Kerberos auth fails silently. |
| **Prometheus Operator** (`monitoring.coreos.com/v1`) | only when `serviceMonitor.enabled=true` | Off by default; flip on once Prometheus + Operator are confirmed in cluster. |
| **NetworkPolicy plugin** (Calico / Cilium / OCP SDN) | only when `networkPolicy.enabled=true` | NetworkPolicy resources without an enforcing plugin are silently ignored. Off by default. |
| **KEDA** (`keda.sh/v1alpha1`, chart `kedacore/keda` 2.16.1 is what the rig proves) | only when `querystudio.query_pods.scaler: keda` AND sizes are configured | One ScaledObject per query-pod size (PostgreSQL trigger on `query_jobs`). Without KEDA a `keda` size has no owner: QueryStudio's scheduler pod takes it over by itself and Component Health `dependency:query_pods` says so; `scaler: builtin` needs no KEDA at all. |

## 2. External services this chart talks to but does NOT provision

| Service | DNS / value referenced | Action |
|---|---|---|
| **PostgreSQL metadata DB** | `postgresqlnew-server-<env>-svc.<ns>.svc.cluster.local:5432` | Operator-managed StatefulSet. Create the DB `querystudio` and the user matching `appSecret.data.QS_DB_USER` before first deploy. |
| **KEDA's read-only login** (query pods, `scaler: keda` only) | `query-pods/values.yaml` `keda.postgresql.userName` = `querystudio_keda_ro`; Secret `querystudio-keda-pg` key `password` | On the metadata DB, after the first deploy created the tables: `CREATE ROLE querystudio_keda_ro LOGIN PASSWORD '<pw>'; GRANT CONNECT ON DATABASE querystudio TO querystudio_keda_ro; GRANT USAGE ON SCHEMA public TO querystudio_keda_ro; GRANT SELECT ON query_jobs TO querystudio_keda_ro;` then `kubectl -n <ns> create secret generic querystudio-keda-pg --from-literal=password='<pw>'`. SELECT on `query_jobs` only — the trigger query counts runs, nothing else (what `scripts/docker_proof/query_pod_keda_proof.py` does on the rig). |
| **Oracle (ETL polling queue)** | `oracle-np-svc:1521/QSPOLL` | External. `etl-polling/values.yaml` `config.oracle.*` controls the DSN. |
| **Starburst / Trino** | `starburst-np-svc:443` | External, used by ETL workflow runners. |
| **Vault server** | `https://cld-uk1.claude.com:8200` | External CSM. Audience `cld_PROD` must already trust this cluster's ServiceAccount tokens. |
| **NFS server + export** | `persistence.nfs.{server,path}` (defaults empty) | Either pre-create the PVC `querystudio-nfs` or set NFS server/path so the api chart provisions a static PV. |
| **Docker registry** | `claude-registry-np-v4-uk.claude.com:5000` | Pull secret `imagepullsecret` must contain `.dockerconfigjson` with valid auth. See section 3. |

## 3. Bootstrap secrets — three paths

Pick **one** strategy and set the matching `create:` flags in `api/values.yaml`.

### Path A — chart-managed (dev/POC)
```yaml
# api/values.yaml
secrets:
  appSecret:        { create: true, data: {...real values...} }
  workerAuthSecret: { create: true, value: "<random hex>" }
  imagePullSecret:
    create: true
    dockerconfigjson: "<base64 of ~/.docker/config.json>"
```
Pros: zero out-of-band setup.
Cons: secrets in git (or in Helm values), no rotation.

### Path B — pre-created Secrets (recommended for prod)
```bash
oc create secret generic querystudio-app-secret \
  --from-literal=QS_DB_USER=... \
  --from-literal=QS_DB_PASS=... \
  -n querystudio-prod

oc create secret generic qs-worker-auth \
  --from-literal=secret="$(openssl rand -hex 32)" \
  -n querystudio-prod

oc create secret docker-registry imagepullsecret \
  --docker-server=claude-registry-p-v4-uk.claude.com:5000 \
  --docker-username=... --docker-password=... \
  -n querystudio-prod
```
Then in `api/values.yaml`: set every `create: false`.

### Path C — External Secrets Operator (large fleets)
Install ESO, define `ExternalSecret` resources pointing at Vault / AWS Secrets
Manager. Set every chart's `secrets.*.create: false` and let ESO reconcile.

## 4. Image build inputs

The root `.gitlab-ci.yml` build jobs expect:

| File | Built into | Notes |
|---|---|---|
| `Dockerfile.api` | `querystudio-api` | Shared by api / worker / feed-worker / scheduler / published-api. Must include the `querystudio` Python package so `python -m querystudio webserver` / `feed-worker` / `scheduler` resolve. |
| `Dockerfile.ui` | `querystudio-ui` | nginx + React SPA. Must expose port 8080 and serve `/healthz`. |
| `ETL/Dockerfile.polling-service` | `querystudio-etl-polling` | Has `oracledb` + Instant Client baked in. |

Registry credentials for the build come from `${REGISTRY_USER}` / `${REGISTRY_PASSWORD}` CI variables — set them in **GitLab → Settings → CI/CD → Variables**.

## 5. CI/CD variables to populate

| Variable | Purpose |
|---|---|
| `KUBECONFIG_DEV_B64` | base64-encoded kubeconfig used by per-component deploy:dev jobs |
| `KUBECONFIG_UAT_B64` | same for UAT |
| `KUBECONFIG_PROD_B64` | same for prod |
| `OC_PROJECT_DEV` / `OC_PROJECT_UAT` / `OC_PROJECT_PROD` | per-env namespace names |
| `REGISTRY_USER` / `REGISTRY_PASSWORD` | for image build/push |

## 6. Cluster-side resource budget

Per the prod env overlay, minimum recommended cluster capacity:

| Pod class | Replicas (prod max) | CPU req (each) | Mem req (each) | Total max |
|---|---:|---:|---:|---:|
| api | 10 | 500m | 2 Gi | 5 cores / 20 GiB |
| ui | 4 | 100m | 256 Mi | 0.4 cores / 1 GiB |
| published-api | 8 | 500m | 1 Gi | 4 cores / 8 GiB |
| worker | 40 | 1 core | 4 Gi | 40 cores / 160 GiB |
| feed-worker | 10 | 500m | 2 Gi | 5 cores / 20 GiB |
| scheduler | 1 | 250m | 512 Mi | 0.25 cores / 0.5 GiB |
| spark-connect (driver) | 1 | 2 cores | 8 Gi | 2 cores / 8 GiB |
| spark-connect (executors) | 8 | 4 cores | 8 GiB | 32 cores / 64 GiB |
| etl-polling | 1 | 200m | 512 Mi | 0.2 cores / 0.5 GiB |
| **Total at HPA ceiling** | | | | **~89 cores / ~282 GiB** |

## 7. Run the preflight

```bash
./bin/preflight.sh querystudio-prod
```

Exits 0 if every check passes (or only warns); exits 1 if any blocking
prerequisite is missing.

## 8. Known limitations of this layout

- **No `ingress.yaml` for non-OpenShift clusters** — `route.yaml` is OCP-only. PR welcome.
- **`config.database.hostTemplate`** assumes the `<host>-server-<env>-svc` pattern; override `config.database.host` if your DB is elsewhere.
- **etl-polling depends on `querystudio-app-secret`** (created by api) when `qsPostgres.enabled=true`. Deploy api first or pre-create the Secret.
- **No StatefulSet for feed-worker shards** — feed-worker uses a Deployment, so every replica gets the same `QUERYSTUDIO_FEED_SHARD` from the ConfigMap. To shard horizontally, deploy N separate releases (`qs-feed-worker-0`, `qs-feed-worker-1`, …) each with its own `config.worker.shard` value, or upgrade the template to a StatefulSet with `valueFrom.fieldRef: metadata.name` to derive the shard index.
