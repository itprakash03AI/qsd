{{- define "qs-dl.name" -}}{{ default .Values.componentName }}{{- end -}}
{{- define "qs-dl.fullname" -}}{{ include "qs-dl.name" . | trunc 63 | trimSuffix "-" }}{{- end -}}
{{- define "qs-dl.labels" -}}
app.kubernetes.io/name: {{ include "qs-dl.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: reports
app.kubernetes.io/part-of: querystudio
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}
{{- define "qs-dl.selectorLabels" -}}
app.kubernetes.io/name: {{ include "qs-dl.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "qs-dl.routeHost" -}}
{{- if .Values.route.host -}}
{{- .Values.route.host -}}
{{- else -}}
{{- include "qs-dl.hostFor" (list . (include "qs-dl.name" .)) -}}
{{- end -}}
{{- end -}}

{{/*
qs.configJson -- THE config file the backend loader reads (2026-09-27).

core/config.py::_load_file reads ONE JSON file at $QUERYSTUDIO_CONFIG
(deployment.yaml sets it to /etc/querystudio/config.json, where this
ConfigMap is mounted read-only).  The document is the deep merge of

  .Values.querystudio      the ENVIRONMENT's overlay (env/<env>.yaml), in
                           core/config.py's own section.key vocabulary --
                           only that environment's deliberate differences
                           from _DEFAULTS, never a credential;
  .Values.querystudioRole  this chart's POD-ROLE overlay (values.yaml) --
                           the static config keys that make this pod its
                           role.  Role wins on a collision.

Three refusals, so a half-written environment cannot deploy:
  * app.environment must be present and equal .Values.environment
    (one deployment, one environment; the ui chart reads the same value);
  * a leaf that is still the placeholder __SET_PER_ENV__ fails the render
    and NAMES every such key (the loader would refuse the file too);
  * spark_connect.enabled=true without spark_connect.server_url fails
    (the code default is OFF; an environment turns it on only with a URL).

IDENTICAL in every backend chart's _helpers.tpl -- a shared library chart
would add a dependency to seven charts for 40 lines; instead
backend/tests/test_prod_config_overlay_2026_09_27.py asserts the copies are
byte-identical and that scripts/verify_prod_config.py's Python reader of
the same values agrees with what helm renders.
*/}}
{{/*
2026-11-03 -- every address is configuration (the owner, 2026-10-26: "self-installed per
team ... nothing hard-coded").  A host is the environment's hostPattern (env/<env>.yaml) with
{name} {namespace} {cluster} {datacentre} filled in; no pattern = the render stops and says so.
Called with (list $ "<component name>").
*/}}
{{- define "qs-dl.hostFor" -}}
{{- $root := index . 0 -}}
{{- $p := required "hostPattern is not set: every address is configuration -- set hostPattern in env/<env>.yaml, e.g. \"{name}-{namespace}.{cluster}-{datacentre}.example.com\"" $root.Values.hostPattern -}}
{{- $p | replace "{name}" (index . 1) | replace "{namespace}" (toString $root.Values.namespace) | replace "{cluster}" (toString $root.Values.cluster) | replace "{datacentre}" (toString $root.Values.datacentre) -}}
{{- end -}}

{{/* the certificate's host-name field: certHostName in env/<env>.yaml ({cluster} {datacentre} filled, datacentre lower case) */}}
{{- define "qs-dl.certHostName" -}}
{{- $p := required "certHostName is not set -- set it in env/<env>.yaml, e.g. \"{cluster}-{datacentre}.example\"" .Values.certHostName -}}
{{- $p | replace "{cluster}" (toString .Values.cluster) | replace "{datacentre}" (lower (toString .Values.datacentre)) -}}
{{- end -}}

{{- define "qs.placeholderPaths" -}}
{{- $prefix := .prefix -}}
{{- range $k, $v := .node -}}
{{- $p := $k -}}
{{- if $prefix }}{{ $p = printf "%s.%s" $prefix $k }}{{ end -}}
{{- if kindIs "map" $v -}}
{{- include "qs.placeholderPaths" (dict "node" $v "prefix" $p) -}}
{{- else if kindIs "slice" $v -}}
{{- range $v }}{{ if and (kindIs "string" .) (eq . "__SET_PER_ENV__") }}{{ printf "%s[] " $p }}{{ end }}{{ end -}}
{{- else if kindIs "string" $v -}}
{{- if eq $v "__SET_PER_ENV__" }}{{ printf "%s " $p }}{{ end -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "qs.configJson" -}}
{{- $env := deepCopy (.Values.querystudio | default dict) -}}
{{- $role := deepCopy (.Values.querystudioRole | default dict) -}}
{{- $declared := toString (dig "app" "environment" "" $env) -}}
{{- if not $declared -}}
{{- fail "querystudio.app.environment is required: env/<env>.yaml must declare the environment's overlay (querystudio: block)" -}}
{{- end -}}
{{- if ne $declared (toString .Values.environment) -}}
{{- fail (printf "querystudio.app.environment=%q disagrees with environment=%q -- one deployment, one environment" $declared (toString .Values.environment)) -}}
{{- end -}}
{{- $cfg := mergeOverwrite $env $role -}}
{{- $holes := include "qs.placeholderPaths" (dict "node" $cfg "prefix" "") | trim -}}
{{- if $holes -}}
{{- fail (printf "config.json still carries the placeholder __SET_PER_ENV__ at: %s -- this environment must supply these values (env/<env>.site.yaml, gitignored, or --set)" $holes) -}}
{{- end -}}
{{- if and (dig "spark_connect" "enabled" false $cfg) (not (dig "spark_connect" "server_url" "" $cfg)) -}}
{{- fail "spark_connect.enabled=true requires spark_connect.server_url -- the code default is OFF; an environment turns Spark Connect on only together with its URL" -}}
{{- end -}}
{{- /* TLS at the pod (2026-09-29).  certs.enabled mounts this chart's
       cert-manager Secret (keys tls.crt / tls.key) at certs.mountPath, and
       the process serves HTTPS only through server.ssl_certfile /
       server.ssl_keyfile read from THIS file (main.run_server;
       scheduler_worker.main).  Both keys are derived here from the SAME
       mount, so the listener, the probes' scheme (ternary on certs.enabled
       in deployment.yaml) and the volume cannot disagree.  Never as
       UVICORN_SSL_* env: that prefix is read by the uvicorn CLI alone (click
       auto_envvar_prefix) and every pod calls uvicorn.run(), which ignores
       it -- the charts carried those lines from 2026-06-30 to 2026-09-29
       while every pod served plain HTTP behind a passthrough Route.  An
       overlay that spells a different path fails the render: the pod serves
       the certificate it mounts. */ -}}
{{- if .Values.certs.enabled -}}
{{- $mount := toString .Values.certs.mountPath -}}
{{- $server := dig "server" (dict) $cfg -}}
{{- $certfile := printf "%s/tls.crt" $mount -}}
{{- $keyfile := printf "%s/tls.key" $mount -}}
{{- $hadCert := toString (dig "ssl_certfile" "" $server) -}}
{{- if and $hadCert (ne $hadCert $certfile) -}}
{{- fail (printf "server.ssl_certfile=%q disagrees with certs.mountPath=%q: the pod serves the certificate it mounts (%s) -- drop the overlay key or move the mount" $hadCert $mount $certfile) -}}
{{- end -}}
{{- $hadKey := toString (dig "ssl_keyfile" "" $server) -}}
{{- if and $hadKey (ne $hadKey $keyfile) -}}
{{- fail (printf "server.ssl_keyfile=%q disagrees with certs.mountPath=%q: the pod serves the key it mounts (%s) -- drop the overlay key or move the mount" $hadKey $mount $keyfile) -}}
{{- end -}}
{{- $_ := set $server "ssl_certfile" $certfile -}}
{{- $_ := set $server "ssl_keyfile" $keyfile -}}
{{- $_ := set $cfg "server" $server -}}
{{- end -}}
{{- /* Spark pods (2026-10-15).  The api and scheduler charts carry a
       sparkK8s block (namespace, ServiceAccount, submit mode, the job IMAGE,
       its pull policy / pull secrets, master URL, driver UID) -- the RBAC
       reads it, but until this date nothing put it into config.json, so an
       operator who set sparkK8s.image had every Spark pod still asking for
       the code default querystudio/spark-etl:latest (ImagePullBackOff on a
       real cluster).  With sparkK8s.enabled the chart's value IS the
       config key; an overlay that spells a different one fails the render
       (one value for the RBAC and the pods), and no image anywhere fails
       too.  Charts without sparkK8s are untouched. */ -}}
{{- $sk := .Values.sparkK8s | default dict -}}
{{- if $sk.enabled -}}
{{- $sparkCfg := dig "spark_k8s" (dict) $cfg -}}
{{- range $pair := list (list "namespace" "namespace") (list "serviceAccount" "service_account") (list "submitMode" "submit_mode") (list "image" "image") (list "imagePullPolicy" "image_pull_policy") (list "imagePullSecrets" "image_pull_secrets") (list "masterUrl" "master_url") (list "driverRunAsUser" "driver_run_as_user") -}}
{{- $v := index $sk (index $pair 0) -}}
{{- if and $v (not (or (kindIs "string" $v) (kindIs "slice" $v))) }}{{ $v = toString $v }}{{ end -}}
{{- if $v -}}
{{- $had := index $sparkCfg (index $pair 1) -}}
{{- if and $had (ne (toJson $had) (toJson $v)) -}}
{{- fail (printf "spark_k8s.%s=%s in the querystudio overlay disagrees with sparkK8s.%s=%s -- the RBAC and the Spark pods must use ONE value: set it in sparkK8s only" (index $pair 1) (toJson $had) (index $pair 0) (toJson $v)) -}}
{{- end -}}
{{- $_ := set $sparkCfg (index $pair 1) $v -}}
{{- end -}}
{{- end -}}
{{- if not (index $sparkCfg "image") -}}
{{- fail "sparkK8s.enabled=true requires sparkK8s.image -- the Spark job image in YOUR registry (built from spark/ in the release bundle), e.g. nexus.<company>/qs/spark-etl:<release>" -}}
{{- end -}}
{{- $_ := set $cfg "spark_k8s" $sparkCfg -}}
{{- end -}}
{{- toPrettyJson $cfg -}}
{{- end -}}
