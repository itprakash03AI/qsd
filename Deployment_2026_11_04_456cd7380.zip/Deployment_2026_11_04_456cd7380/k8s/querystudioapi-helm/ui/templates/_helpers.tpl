{{- define "qs-ui.name" -}}
{{- default .Values.componentName -}}
{{- end -}}

{{- define "qs-ui.fullname" -}}
{{- include "qs-ui.name" . | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "qs-ui.labels" -}}
app.kubernetes.io/name: {{ include "qs-ui.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: ui
app.kubernetes.io/part-of: querystudio
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "qs-ui.selectorLabels" -}}
app.kubernetes.io/name: {{ include "qs-ui.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "qs-ui.routeHost" -}}
{{- if .Values.route.host -}}
{{- .Values.route.host -}}
{{- else -}}
{{- include "qs-ui.hostFor" (list . (include "qs-ui.name" .)) -}}
{{- end -}}
{{- end -}}

{{- define "qs-ui.apiUrl" -}}
{{- if .Values.config.apiUrl -}}
{{- .Values.config.apiUrl -}}
{{- else if eq (toString .Values.config.product) "reports" -}}
{{- printf "https://%s" (include "qs-ui.hostFor" (list . "querystudio-reports")) -}}
{{- else -}}
{{- printf "https://%s" (include "qs-ui.hostFor" (list . "querystudio-api")) -}}
{{- end -}}
{{- end -}}

{{/*
2026-10-29 -- the reports and downloads pods were installed by deploy.sh in
every environment and received NO browser traffic: the SPA sends their paths
to them only when reportApiUrl / downloadApiUrl is set, and nothing set it.
A pod the environment deploys (config.reportsPod.enabled /
config.downloadsPod.enabled in env/<env>.yaml, the overlay every chart reads)
is now addressed by the host its own chart's Route derives -- the same
pattern as qs-rpt.routeHost / qs-dl.routeHost.  An explicit URL wins (a
Route given its own route.host must name it here too); neither = "" = every
call stays on apiUrl.
*/}}
{{- define "qs-ui.reportApiUrl" -}}
{{- if .Values.config.reportApiUrl -}}
{{- .Values.config.reportApiUrl -}}
{{- else if (.Values.config.reportsPod | default dict).enabled -}}
{{- printf "https://%s" (include "qs-ui.hostFor" (list . "querystudio-reports")) -}}
{{- end -}}
{{- end -}}

{{/* 2026-11-03: the Reports app links back to QueryStudio ("" in QueryStudio itself) */}}
{{- define "qs-ui.queryStudioUrl" -}}
{{- if .Values.config.queryStudioUrl -}}
{{- .Values.config.queryStudioUrl -}}
{{- else if eq (toString .Values.config.product) "reports" -}}
{{- printf "https://%s" (include "qs-ui.hostFor" (list . "querystudio-ui")) -}}
{{- end -}}
{{- end -}}

{{- define "qs-ui.downloadApiUrl" -}}
{{- if .Values.config.downloadApiUrl -}}
{{- .Values.config.downloadApiUrl -}}
{{- else if (.Values.config.downloadsPod | default dict).enabled -}}
{{- printf "https://%s" (include "qs-ui.hostFor" (list . "querystudio-downloads")) -}}
{{- end -}}
{{- end -}}

{{/*
2026-11-03 -- every address is configuration (the owner, 2026-10-26: "self-installed per
team ... nothing hard-coded").  A host is the environment's hostPattern (env/<env>.yaml) with
{name} {namespace} {cluster} {datacentre} filled in; no pattern = the render stops and says so.
Called with (list $ "<component name>").
*/}}
{{- define "qs-ui.hostFor" -}}
{{- $root := index . 0 -}}
{{- $p := required "hostPattern is not set: every address is configuration -- set hostPattern in env/<env>.yaml, e.g. \"{name}-{namespace}.{cluster}-{datacentre}.example.com\"" $root.Values.hostPattern -}}
{{- $p | replace "{name}" (index . 1) | replace "{namespace}" (toString $root.Values.namespace) | replace "{cluster}" (toString $root.Values.cluster) | replace "{datacentre}" (toString $root.Values.datacentre) -}}
{{- end -}}

{{/* the certificate's host-name field: certHostName in env/<env>.yaml ({cluster} {datacentre} filled, datacentre lower case) */}}
{{- define "qs-ui.certHostName" -}}
{{- $p := required "certHostName is not set -- set it in env/<env>.yaml, e.g. \"{cluster}-{datacentre}.example\"" .Values.certHostName -}}
{{- $p | replace "{cluster}" (toString .Values.cluster) | replace "{datacentre}" (lower (toString .Values.datacentre)) -}}
{{- end -}}
