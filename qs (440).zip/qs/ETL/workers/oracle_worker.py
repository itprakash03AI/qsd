import asyncio
from datetime import datetime
import importlib
import logging
import os
import yaml
from managers.oracle_metadata_manager import OracleMetadataManager
from workers.base_worker import BaseWorker
from managers.step_executor import StepExecutor
from typing import Any, Callable, Dict, List

logger = logging.getLogger(__name__)


class OracleWorker(BaseWorker):
    """Worker for the Starburst-to-Oracle workflow."""

    # 2026-06-22 -- canonical workflow key (matches step_mapping.yaml).
    # Added for consistency with FileWorker.WORKFLOW + FileToOracleWorker.WORKFLOW.
    # Older name "createJob" kept as alias inside load_step_mapping.
    WORKFLOW = "oracle"

    def __init__(self, starburst_clients: Dict[str, Any], oracle_data_manager: OracleMetadataManager, logger: logging.Logger = None):
        super().__init__(starburst_clients, oracle_data_manager, logger)
        # 2026-06-22 bug #19: REVERT to the original "oracle" workflow
        # name (was renamed to "createJob" in 2026-04-24 commit 11518f7
        # with no rationale, which broke operator deployments still on
        # the old yaml).  "createJob" + "starburst_to_oracle" kept as
        # aliases for back-compat with whichever yaml name a given
        # deployment happens to ship with.
        self.step_mapping = self.load_step_mapping(
            "oracle", aliases=("createJob", "starburst_to_oracle"),
        )

    def load_step_mapping(
        self,
        workflow: str,
        aliases: tuple = (),
    ) -> Dict[str, Callable]:
        """Load step mapping from YAML and dynamically import classes.

        Steps that fail to import are logged as warnings and skipped —
        they will fail at execution time with a clear 'Unsupported step' error.

        2026-06-22 -- accepts ``aliases``: tuple of alternate workflow
        keys to try if the primary key is missing.  Makes the worker
        resilient to yaml renames + deployment drift.  Multiple paths
        also tried for the yaml file itself (prod + local-dev fallback).
        """
        # 2026-06-22 bug #19: don't hardcode prod-only path; mirror the
        # oracle_config_loader pattern so local-dev / CI / Windows can
        # also load the yaml.
        candidate_paths = [
            "/usr/local/spark/pvc/code/configs/step_mapping.yaml",
            os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "configs", "step_mapping.yaml",
            ),
        ]
        mapping_path = next(
            (p for p in candidate_paths if os.path.exists(p)), None,
        )
        if mapping_path is None:
            raise FileNotFoundError(
                f"Step mapping file not found at any of: {candidate_paths}"
            )
        with open(mapping_path, "r") as f:
            mappings = yaml.safe_load(f) or {}

        # Try primary workflow key first, then aliases.
        for key in (workflow, *aliases):
            if key in mappings:
                if key != workflow:
                    self.logger.warning(
                        "Workflow %r not in step_mapping.yaml at %s; "
                        "using alias %r.  Recommend updating yaml to "
                        "use the canonical key.", workflow, mapping_path, key,
                    )
                workflow = key
                break
        else:
            available = sorted(mappings.keys())
            raise ValueError(
                f"No mapping found for workflow {workflow!r} (tried aliases "
                f"{aliases}) in {mapping_path}.  Available workflows in "
                f"this yaml: {available}.  Check that the yaml on the "
                f"Spark PVC mount is the latest version."
            )
        step_mapping = {}
        for step_name, details in mappings[workflow].items():
            try:
                module = importlib.import_module(details["module"])
                step_class = getattr(module, details["class"])
                step_mapping[step_name] = step_class
            except (ImportError, AttributeError) as e:
                self.logger.warning(f"Step {step_name} not available (will fail if invoked): {e}")
        self.logger.info(f"Loaded step mapping for {workflow}: {list(step_mapping.keys())}")
        return step_mapping

    async def execute_step(self, task: Dict, worker_connection_string: str, dest_connection_string: str, step_name: str) -> None:
        """Execute a single Oracle task step with retry logic."""
        task_id = task.get("run_id")
        logger.info(f"execute_step started executing step {step_name}")
        if not task_id or not worker_connection_string or not dest_connection_string or not step_name:
            raise ValueError("run_id, worker_connection_string, dest_connection_string, and step_name are required")
        step_executor = StepExecutor(self, self.logger)

        if step_name not in self.step_mapping:
            raise ValueError(f"Unsupported step name: {step_name}")
        step_class = self.step_mapping[step_name]
        try:
            logger.info(f"Executing step {step_name} for task {task_id} with DAG_ID: {task.get('fk_dag_id')} and FK_REPORT_ID: {task.get('fk_report_id')} (SEQ: {task.get('seq')})")
            await step_executor.execute_step_with_retry(
                step_class, task, worker_connection_string, dest_connection_string,
                step_name, event_id=str(task["seq"]),
                dag_run_id=task.get("dag_run_id", f"run_{task['run_id']}"),
                fk_report_id=task.get("fk_report_id"),
            )
        except Exception as ex:
            logger.error(f"Step {step_name} for task {task_id} failed after retries: {str(ex)}")
            raise  # Let the manager handle the failure and halt


# 2026-06-29 -- WORKFLOW_DEF moved to ETL/workflows/oracle.py + file.py
# (decoupled from this module's import chain so plugin discovery is
# robust to environment-specific issues in the worker class hierarchy).
# Per feedback_plugin_pattern.md.


