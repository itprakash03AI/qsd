"""S3 workflow worker -- shared base + per-workflow subclasses.

2026-06-22 -- canonical module home for the S3 workers (moved here from
``workers/s3_query_worker.py`` to match its content).

  * ``S3WorkflowWorker``  -- base class (workflow set by subclass)
  * ``S3ToFileWorker``    -- loads ``s3_to_file`` step-mapping section
  * ``S3ToOracleWorker``  -- loads ``s3_to_oracle`` step-mapping section
  * ``S3QueryWorker``     -- DEPRECATED shim that maps to S3ToFileWorker
                              with a WARN log (back-compat for legacy
                              OTG_DAG_ID values containing "s3_query").

Same mechanical loading + StepExecutor wiring across all subclasses --
the only thing that changes is which ``step_mapping.yaml`` section
gets imported.
"""
from __future__ import annotations

import importlib
import logging
import os
import warnings
from typing import Any, Callable, Dict

import yaml

from workers.base_worker import BaseWorker
from managers.step_executor import StepExecutor


logger = logging.getLogger(__name__)


class S3WorkflowWorker(BaseWorker):
    """Base for S3-source workflows.  Subclass sets ``WORKFLOW``."""

    # Subclass MUST override to one of the keys in step_mapping.yaml:
    # "s3_to_file" | "s3_to_oracle".
    WORKFLOW: str = ""

    _PROD_MAPPING_PATH = "/usr/local/spark/pvc/code/configs/step_mapping.yaml"
    _LOCAL_MAPPING_PATH = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "configs", "step_mapping.yaml",
    )
    DEFAULT_MAPPING_PATH = _PROD_MAPPING_PATH  # back-compat for callers

    def __init__(
        self,
        oracle_data_manager: Any,
        logger: logging.Logger = None,
        mapping_path: str = None,
    ):
        if not self.WORKFLOW:
            raise RuntimeError(
                f"{type(self).__name__}.WORKFLOW must be set (use "
                f"S3ToFileWorker or S3ToOracleWorker, not the base class)."
            )
        super().__init__(
            starburst_clients={},
            oracle_data_manager=oracle_data_manager,
            logger=logger,
        )
        if mapping_path is not None:
            self._mapping_path = mapping_path
        elif os.path.exists(self._PROD_MAPPING_PATH):
            self._mapping_path = self._PROD_MAPPING_PATH
        else:
            self._mapping_path = self._LOCAL_MAPPING_PATH
        self.step_mapping = self.load_step_mapping(self.WORKFLOW)

    def load_step_mapping(self, workflow: str) -> Dict[str, Callable]:
        """Load step mapping from YAML and dynamically import classes.

        Fails-OPEN per individual step: a step whose module isn't
        importable on this node (e.g., pyspark missing) is dropped from
        the mapping with a WARN; other steps stay executable.  The
        dispatcher only complains at run time when the missing step's
        TASK_TYPE is actually requested.
        """
        if not os.path.exists(self._mapping_path):
            raise FileNotFoundError(
                f"Step mapping file not found: {self._mapping_path}.  "
                f"Tried prod ({self._PROD_MAPPING_PATH}) + local "
                f"({self._LOCAL_MAPPING_PATH})."
            )
        with open(self._mapping_path, "r") as f:
            mappings = yaml.safe_load(f) or {}
        if workflow not in mappings:
            available = sorted(mappings.keys())
            raise ValueError(
                f"No mapping found for workflow {workflow!r} in "
                f"{self._mapping_path}.  Available workflows: {available}.  "
                f"Check the yaml on the Spark PVC mount is up-to-date."
            )

        step_mapping: Dict[str, Callable] = {}
        for step_name, details in mappings[workflow].items():
            try:
                module = importlib.import_module(details["module"])
                step_class = getattr(module, details["class"])
                step_mapping[step_name] = step_class
            except (ImportError, AttributeError) as exc:
                self.logger.warning(
                    f"Step {step_name} not available in this build: {exc}"
                )

        self.logger.info(
            f"Loaded step mapping for {workflow}: {list(step_mapping.keys())}"
        )
        return step_mapping

    async def execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
    ) -> None:
        """Execute a single pipeline step (retry-aware)."""
        task_id = task.get("run_id")
        self.logger.info(f"Executing step {step_name} for task {task_id}")

        if step_name not in self.step_mapping:
            raise ValueError(
                f"Unsupported step name for {self.WORKFLOW} workflow: "
                f"{step_name!r}.  Known: {list(self.step_mapping)}"
            )

        step_class = self.step_mapping[step_name]
        step_executor = StepExecutor(self, self.logger)

        await step_executor.execute_step_with_retry(
            step_class, task, worker_connection_string, dest_connection_string,
            step_name,
            event_id=str(task.get("seq", 0)),
            dag_run_id=task.get("dag_run_id", f"run_{task.get('run_id', 'unknown')}"),
            fk_report_id=task.get("fk_report_id"),
        )


class S3ToFileWorker(S3WorkflowWorker):
    """S3 (parquet OR iceberg) -> NFS file delivery pipeline."""
    WORKFLOW = "s3_to_file"


class S3ToOracleWorker(S3WorkflowWorker):
    """S3 (parquet OR iceberg) -> Oracle JDBC bulk load."""
    WORKFLOW = "s3_to_oracle"


# ──────────────────────────────────────────────────────────────────────
#  Deprecation shim: S3QueryWorker -> S3ToFileWorker
# ──────────────────────────────────────────────────────────────────────


class S3QueryWorker(S3ToFileWorker):
    """DEPRECATED: use S3ToFileWorker or S3ToOracleWorker explicitly.

    2026-06-22 -- the unified ``s3_query`` workflow was split into two
    proper workflows (s3_to_file + s3_to_oracle).  This class keeps
    legacy OTG_DAG_ID="s3_query*" rows running by routing to
    S3ToFileWorker (the more common case).  Update the DAG_ID to
    "s3_to_file" or "s3_to_oracle" to silence the warning.
    """

    def __init__(self, *args, **kwargs):
        warnings.warn(
            "S3QueryWorker is deprecated -- use S3ToFileWorker or "
            "S3ToOracleWorker.  Update OTG_DAG_ID to contain "
            "'s3_to_file' or 's3_to_oracle' instead of 's3_query'.",
            DeprecationWarning,
            stacklevel=2,
        )
        log = kwargs.get("logger") or args[1] if len(args) > 1 else logger
        if hasattr(log, "warning"):
            log.warning(
                "S3QueryWorker is DEPRECATED -- routing to S3ToFileWorker "
                "for back-compat.  Migrate OTG_DAG_ID to 's3_to_file' or "
                "'s3_to_oracle' as appropriate."
            )
        super().__init__(*args, **kwargs)


# 2026-06-29 -- WORKFLOW_DEFs moved to ETL/workflows/s3_to_file.py +
# s3_to_oracle.py + s3_query.py (manifests decoupled from this worker
# module's pyspark import chain so non-Spark workflows still register
# correctly).
