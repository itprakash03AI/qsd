"""Pipeline-level Spark lifecycle helpers.

2026-06-26 -- single chokepoint for stopping the SparkSession at the END
of a standalone pipeline (oracle_standalone, file_standalone, ...).

Before this:
  Per-step finally blocks called ``spark.stop()`` which killed the
  pod-shared SparkContext between sequential steps.  Sub-step failure:
  ``starburst_to_oracle_oncloud`` succeeded -> stopped SparkContext ->
  ``starburst_to_oracle_onprem`` getOrCreate() returned a dead session
  -> first ``df.collect()`` raised "SparkContext was shut down".

After this -- TWO release points:

  (1) Right after the LAST Spark-using step in the task list runs.
      For ``oracle`` workflow that's ``StarburstToOracle_OnPrem``.
      All downstream steps (CheckDataCompleteness, PostLoadProcess,
      SendEmailNotifications) are pure Oracle / pure Python so they
      don't need Spark executors and memory.  Releases ~GB of cluster
      resources roughly the duration of those tail steps.
  (2) Pipeline-level ``finally`` in standalone ``main()`` as the
      idempotent backstop -- catches the case where a Spark step
      raised before reaching (1), or where (1) was skipped because
      the task list shape changed underneath us.

Fail-open: if PySpark is not importable, or no active session exists,
both release points are no-ops.  Never raises -- a teardown error must
not mask the pipeline's actual outcome.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional


# ──────────────────────────────────────────────────────────────────────
# Step-name registry.
#
# These are the TASK_STEPS values (polling-row column) whose Python
# step class instantiates a SparkSession via ``_build_spark_session*``.
# Update this set when adding a new Spark-using step type.  Steps NOT
# in this set (CheckDependencies, ClearStaging, ProcessData, SAP* ...)
# are pure Oracle / pure Python and don't hold Spark resources.
#
# Verified against ETL/configs/step_mapping.yaml on 2026-06-26.
# ──────────────────────────────────────────────────────────────────────
SPARK_STEP_NAMES = frozenset({
    # oracle workflow
    "StarburstToOracle_OnCloud",
    "StarburstToOracle_OnPrem",
    # file workflow -- only the Spark JDBC variants (pure-trino-DBAPI
    # variants do NOT hold a SparkSession)
    "StarburstToFile_OnCloud_Spark",
    "StarburstToFile_OnPrem_Spark",
    # file_to_oracle workflow
    "DelimitedFileToOracle",
    "ParquetFileToOracle",
    "CsvFileToOracle",
    # s3_to_file workflow
    "IcebergToFile_OnCloud",
    "IcebergToFile_OnPrem",
    "HiveToFile_OnPrem",
    "ParquetToFile_OnCloud",
    "ParquetToFile_OnPrem",
    "S3IcebergQueryExtract",
    "S3ParquetQueryExtract",
    # s3_to_oracle workflow
    "IcebergToOracle_OnCloud",
    "IcebergToOracle_OnPrem",
    "HiveToOracle_OnPrem",
    "ParquetToOracle_OnCloud",
    "ParquetToOracle_OnPrem",
    "S3IcebergQueryToOracle",
    "S3ParquetQueryToOracle",
    "S3IcebergToOracle",
    "S3ParquetToOracle",
    "S3ToS3Transform",
    # oracle -> s3 (occasional)
    "OracleToS3Iceberg",
    "OracleToS3Parquet",
})


def stop_active_spark_session(logger: Optional[logging.Logger] = None) -> None:
    """Stop the active SparkSession if one exists.

    Safe to call multiple times and from finally blocks.  Swallows any
    exception so it never overrides the pipeline's real outcome.
    """
    log = logger or logging.getLogger("spark_lifecycle")
    try:
        from pyspark.sql import SparkSession  # type: ignore
    except ImportError:
        return

    try:
        session = SparkSession.getActiveSession()
    except Exception as exc:
        log.debug(f"getActiveSession raised (no JVM yet?): {exc}")
        return

    if session is None:
        log.debug("No active SparkSession to stop")
        return

    try:
        log.info("Stopping SparkSession (pipeline teardown)")
        session.stop()
    except Exception as exc:
        log.warning(f"Error stopping SparkSession (ignored): {exc}")


def install_pipeline_spark_release(
    tasks: List[Dict[str, Any]],
    logger: Optional[logging.Logger] = None,
) -> Callable[[int], None]:
    """Return a callable ``maybe_release(i)`` to invoke from the
    standalone's task-loop finally block.

    Walks the task list once, finds the LAST index whose
    ``task['task_steps']`` is in :data:`SPARK_STEP_NAMES`.  When the
    loop hits that index, ``maybe_release`` calls
    :func:`stop_active_spark_session` and debounces so subsequent calls
    are no-ops.

    Why pre-compute: failures in a Spark step shouldn't leak Spark
    resources through the tail of the pipeline.  The returned callable
    fires from a ``finally`` so it runs on success AND failure of the
    last Spark step.

    If the task list has no Spark steps at all (e.g., SAP OData
    pipeline), the returned callable is a permanent no-op.
    """
    log = logger or logging.getLogger("spark_lifecycle")
    last_idx = -1
    for i, t in enumerate(tasks):
        if t.get("task_steps") in SPARK_STEP_NAMES:
            last_idx = i

    if last_idx < 0:
        log.debug("No Spark-using steps in task list -- release is a no-op")

        def _noop(_i: int) -> None:
            return None

        return _noop

    state = {"last_idx": last_idx, "released": False}

    def maybe_release(i: int) -> None:
        if state["released"]:
            return
        if i == state["last_idx"]:
            log.info(
                f"Last Spark step (idx={i}) completed -- releasing "
                "Spark before tail steps run"
            )
            stop_active_spark_session(log)
            state["released"] = True

    return maybe_release
