"""ETL workflow plugin manifests.

Each module in this package declares a ``WORKFLOW_DEF`` constant
describing one workflow's routing + execution metadata.  The polling
service's ``WorkflowRegistry.discover()`` walks this package and
collects every manifest at startup.

Adding a new workflow is a TWO-FILE drop:
  1. ``workers/my_new_worker.py``      — the worker class (heavy imports)
  2. ``workflows/my_new_workflow.py``  — the lightweight manifest

The manifest module MUST stay lightweight: imports only ``WorkflowDefinition``
and uses a lazy loader function to defer the worker class import until
first use.  This decouples plugin discovery from the worker class's
own import chain, so a transient import failure in one worker module
(e.g. environment-specific dependency mismatch) does NOT silently
de-register every other workflow.

Per feedback_plugin_pattern.md + feedback_strategic_not_patch.md.
"""
