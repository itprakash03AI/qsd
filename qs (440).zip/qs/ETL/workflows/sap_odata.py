"""Manifest for the ``sap_odata`` workflow (SAP basic-auth + OData)."""
from polling_service.workflow_registry import PluginManifest


def _load() -> type:
    from workers.sap_odata_worker import SapOdataWorker
    return SapOdataWorker


WORKFLOW_DEF = PluginManifest(
    name="sap_odata",
    version="1.0.0",
    description="SAP S/4HANA OData extract via basic auth + paginated GET.",
    worker_cls_loader=_load,
    dag_id_patterns=("sap",),
    db_connection_patterns=("SAP",),
    needs_starburst_clients=False,
    lightweight_capable=True,
    priority=20,                # very specific name — match first
    capabilities=frozenset({"sap_odata", "rest_extract", "file_delivery"}),
    requires_packages=("requests",),
)
