"""Manifest for the ``oracle`` workflow (Starburst → Oracle).

Worker class: workers.oracle_worker.OracleWorker
Step mapping section: step_mapping.yaml -> oracle
"""
from polling_service.workflow_registry import PluginManifest


def _load() -> type:
    from workers.oracle_worker import OracleWorker
    return OracleWorker


WORKFLOW_DEF = PluginManifest(
    name="oracle",
    version="1.0.0",
    description="Starburst → Oracle pipeline (canonical Starburst-sourced workflow).",
    worker_cls_loader=_load,
    dag_id_patterns=("oracle", "createjob"),
    db_connection_patterns=("ORACLE", "CREATEJOB"),
    needs_starburst_clients=True,
    lightweight_capable=True,
    aliases=("createJob",),     # 2026-04-24 rename, reverted bug #19
    priority=80,                # generic — matched after specific patterns
    capabilities=frozenset({"starburst_query", "oracle_sink"}),
    requires_env=("ETL_ORACLE_CONN",),
    requires_packages=("oracledb",),
)
