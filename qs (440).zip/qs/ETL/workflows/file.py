"""Manifest for the ``file`` workflow (file delivery via OracleWorker
with the ``file`` step_mapping.yaml section)."""
from polling_service.workflow_registry import PluginManifest


def _load() -> type:
    from workers.oracle_worker import OracleWorker
    return OracleWorker


WORKFLOW_DEF = PluginManifest(
    name="file",
    version="1.0.0",
    description="Starburst → flat file delivery (CSV/Parquet/CTL).",
    worker_cls_loader=_load,
    dag_id_patterns=("file",),
    db_connection_patterns=("FILE",),
    needs_starburst_clients=True,
    lightweight_capable=True,
    priority=50,                # below file_to_oracle (priority 30)
    capabilities=frozenset({"starburst_query", "file_delivery"}),
    requires_env=("ETL_ORACLE_CONN",),
)
