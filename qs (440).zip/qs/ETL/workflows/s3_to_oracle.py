"""Manifest for the ``s3_to_oracle`` workflow (S3 → Oracle JDBC, Spark)."""
from polling_service.workflow_registry import PluginManifest


def _load():
    try:
        from workers.s3_worker import S3ToOracleWorker
        return S3ToOracleWorker
    except ImportError:
        return None


WORKFLOW_DEF = PluginManifest(
    name="s3_to_oracle",
    version="1.0.0",
    description="S3/Iceberg → Oracle via Spark JDBC sink (heavy workload).",
    worker_cls_loader=_load,
    dag_id_patterns=("s3_to_oracle", "s3tooracle"),
    db_connection_patterns=("S3_TO_ORACLE", "S3TOORACLE"),
    needs_starburst_clients=False,
    lightweight_capable=False,
    priority=10,
    capabilities=frozenset({"s3_source", "oracle_sink", "spark"}),
    requires_packages=("pyspark", "oracledb"),
)
