"""Manifest for the ``file_to_oracle`` workflow (JDBC sink, no Starburst).

Worker class: workers.file_to_oracle_worker.FileToOracleWorker
Step mapping section: step_mapping.yaml -> file_to_oracle
"""
from polling_service.workflow_registry import PluginManifest


def _load() -> type:
    from workers.file_to_oracle_worker import FileToOracleWorker
    return FileToOracleWorker


WORKFLOW_DEF = PluginManifest(
    name="file_to_oracle",
    version="1.0.0",
    description="Flat file → Oracle JDBC sink (Spark-free).",
    worker_cls_loader=_load,
    dag_id_patterns=("file_to_oracle", "filetooracle"),
    db_connection_patterns=("FILE_TO_ORACLE", "FILETOORACLE"),
    needs_starburst_clients=False,
    lightweight_capable=True,
    priority=30,                # MUST sort before "file" (priority 50)
    capabilities=frozenset({"file_source", "oracle_sink"}),
    requires_env=("ETL_ORACLE_CONN", "DEST_ORACLE_CONN"),
    requires_packages=("oracledb",),
)
