"""Manifest for the ``s3_to_file`` workflow (S3 → file via Spark JDBC).

REQUIRES pyspark — ``lightweight_capable=False``.
"""
from polling_service.workflow_registry import PluginManifest


def _load():
    try:
        from workers.s3_worker import S3ToFileWorker
        return S3ToFileWorker
    except ImportError:
        return None


WORKFLOW_DEF = PluginManifest(
    name="s3_to_file",
    version="1.0.0",
    description="S3/Iceberg → flat file via Spark (heavy workload path).",
    worker_cls_loader=_load,
    dag_id_patterns=("s3_to_file", "s3tofile"),
    db_connection_patterns=("S3_TO_FILE", "S3TOFILE"),
    needs_starburst_clients=False,
    lightweight_capable=False,
    priority=10,
    capabilities=frozenset({"s3_source", "file_delivery", "spark"}),
    requires_packages=("pyspark",),
)
