"""DEPRECATED manifest for the legacy ``s3_query`` workflow.

Routes to ``S3ToFileWorker`` via the S3QueryWorker shim with a WARN log.
Migrate OTG_DAG_ID to contain ``s3_to_file`` or ``s3_to_oracle`` and
delete this manifest once no DB row matches.
"""
from polling_service.workflow_registry import PluginManifest


def _load():
    try:
        from workers.s3_worker import S3QueryWorker
        return S3QueryWorker
    except ImportError:
        return None


WORKFLOW_DEF = PluginManifest(
    name="s3_query",
    version="0.9.0",
    description="Legacy s3_query alias → routes to S3ToFileWorker. Migrate OTG_DAG_ID.",
    worker_cls_loader=_load,
    dag_id_patterns=("s3_query", "s3query"),
    db_connection_patterns=("S3_QUERY", "S3QUERY"),
    needs_starburst_clients=False,
    lightweight_capable=False,
    priority=15,                # matched AFTER s3_to_* (priority 10)
    is_deprecated=True,
    deprecated_message="Use s3_to_file or s3_to_oracle.  Update OTG_DAG_ID to contain the new name.",
    replaced_by="s3_to_file",
    capabilities=frozenset({"s3_source", "file_delivery", "spark", "legacy_alias"}),
    requires_packages=("pyspark",),
)
