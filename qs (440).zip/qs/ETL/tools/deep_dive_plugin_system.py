"""Deep dive on the enterprise plugin system. Surfaces actual gaps.

Run from ETL/ root:
    python tools/deep_dive_plugin_system.py
"""
import sys, time, threading, logging, json
sys.path.insert(0, '.')

from polling_service.workflow_registry import (
    PluginManifest, PluginTelemetry, WorkflowRegistry,
    WorkflowDefinition, get_registry, reset_registry,
    PluginValidationError, StartupValidationError,
    CURRENT_MANIFEST_VERSION,
)

findings = []
def gap(severity, area, msg):
    findings.append((severity, area, msg))
    print(f"   [{severity}] {area}: {msg}")

def ok(area, msg):
    print(f"   [OK]   {area}: {msg}")


print("=" * 72)
print("DEEP DIVE 1: Concurrency safety")
print("=" * 72)
t = PluginTelemetry(name="x")
def _bump():
    for _ in range(1000):
        t.record_dispatch()
        t.record_success(0.01)
threads = [threading.Thread(target=_bump) for _ in range(8)]
for th in threads: th.start()
for th in threads: th.join()
snap = t.snapshot()
if snap["dispatched"] == 8000 and snap["completed"] == 8000:
    ok("concurrency", f"telemetry counters sum correctly under 8x1000 (got {snap['dispatched']}/{snap['completed']})")
else:
    gap("BLOCKER", "concurrency", f"telemetry race: dispatched={snap['dispatched']}/8000 completed={snap['completed']}/8000")

reg = WorkflowRegistry()
for i in range(5):
    reg.register(PluginManifest(
        name="p{}".format(i), worker_cls_loader=lambda: object,
        dag_id_patterns=("p{}".format(i),), priority=10 + i,
    ))
collected = []
mutated = False
try:
    for d in reg:
        collected.append(d.name)
        if d.name == "p2" and not mutated:
            reg.register(PluginManifest(name="late_addition", worker_cls_loader=lambda: object,
                                         dag_id_patterns=("late",)))
            mutated = True
    ok("concurrency", f"register-during-iteration survived (iterated {len(collected)})")
except RuntimeError as e:
    gap("SERIOUS", "concurrency", f"register-during-iteration raised: {e}")

import inspect
src = inspect.getsource(WorkflowRegistry.register)
if "lock" not in src.lower() and "Lock" not in src:
    gap("NIT", "concurrency", "WorkflowRegistry.register has NO lock; concurrent register() from threads could corrupt state. Acceptable since production fires register only at startup.")


print()
print("=" * 72)
print("DEEP DIVE 2: Memory bounds")
print("=" * 72)
t2 = PluginTelemetry(name="x")
for i in range(10000):
    t2.record_success(duration_s=i * 0.001)
if len(t2._durations) <= 32:
    ok("memory", f"telemetry deque bounded at maxlen=32 (got {len(t2._durations)})")
else:
    gap("BLOCKER", "memory", f"telemetry deque grew to {len(t2._durations)}")

reset_registry()
reg1 = get_registry(); rid1 = id(reg1)
reset_registry()
reg2 = get_registry(); rid2 = id(reg2)
if rid1 != rid2:
    ok("memory", "reset_registry() drops singleton")
else:
    gap("SERIOUS", "memory", "reset_registry() did NOT drop singleton")

t3 = PluginTelemetry(name="x")
huge = "x" * 100000
t3.record_failure(reason=huge)
held = len(t3.snapshot()["last_failure_reason"])
if held <= 500:
    ok("memory", f"last_failure_reason truncated to {held} chars")
else:
    gap("SERIOUS", "memory", f"last_failure_reason held {held} chars (should be <=500)")


print()
print("=" * 72)
print("DEEP DIVE 3: Backwards compat")
print("=" * 72)
if WorkflowDefinition is PluginManifest:
    ok("back-compat", "WorkflowDefinition is the same class as PluginManifest")
else:
    gap("SERIOUS", "back-compat", f"WorkflowDefinition is {WorkflowDefinition!r}")

try:
    old = WorkflowDefinition(
        name="legacy",
        worker_cls_loader=lambda: object,
        dag_id_patterns=("legacy",),
        db_connection_patterns=("LEGACY",),
        needs_starburst_clients=False,
        lightweight_capable=True,
        aliases=(),
        priority=50,
        is_deprecated=False,
    )
    ok("back-compat", "old-style WorkflowDefinition constructor still works")
except TypeError as e:
    gap("BLOCKER", "back-compat", f"old constructor broken: {e}")


print()
print("=" * 72)
print("DEEP DIVE 4: Routing edge cases")
print("=" * 72)
reset_registry()
reg = get_registry()
cases = [
    ((None, None), "None inputs"),
    (("", ""), "empty strings"),
    (("   ", "   "), "whitespace only"),
    (("\x00malicious\x00", None), "null bytes in dag_id"),
    (("file" * 1000, None), "very long dag_id (4000 chars)"),
    (("cafe_file_to_oracle", None), "ascii-only special chars"),
    (("FILE_TO_ORACLE", None), "uppercase form"),
    (("file_to_oracle", None), "exact lowercase match"),
    ((None, "FILE_TO_ORACLE"), "OTG_DAG_ID None, db_connection only"),
]
for (dag, dbc), why in cases:
    try:
        result = reg.route_dag_id(dag, dbc)
        ok("routing", f"{why}: routed to {result!r}")
    except Exception as e:
        gap("SERIOUS", "routing", f"{why}: raised {type(e).__name__}: {e}")


print()
print("=" * 72)
print("DEEP DIVE 5: Validation completeness")
print("=" * 72)
m1 = PluginManifest(name="orphan", worker_cls_loader=lambda: object,
                     dag_id_patterns=(), db_connection_patterns=())
errors = m1.validate()
if errors:
    ok("validation", f"empty patterns flagged: {errors}")
else:
    gap("SERIOUS", "validation",
        "manifest with NO patterns passes validation but can never match (silent orphan)")

m2 = PluginManifest(name="has spaces", worker_cls_loader=lambda: object)
if m2.validate():
    ok("validation", "name with whitespace flagged")
else:
    gap("BLOCKER", "validation", "name with whitespace passes validation")

m3 = PluginManifest(name="123abc", worker_cls_loader=lambda: object)
errors = m3.validate()
if not errors:
    gap("SERIOUS", "validation",
        "name '123abc' passes validation but is NOT a valid Python identifier")
else:
    ok("validation", "numeric-prefix name flagged")

try:
    m4 = PluginManifest(name="x", worker_cls_loader=lambda: object, priority="50")
    errors = m4.validate()
    if errors and any("priority" in e for e in errors):
        ok("validation", "string priority flagged")
    else:
        gap("SERIOUS", "validation", "string priority NOT flagged: " + str(errors))
except Exception as e:
    ok("validation", f"frozen dataclass rejected string priority: {type(e).__name__}")

m5 = PluginManifest(name="x", worker_cls_loader=lambda: object,
                     dag_id_patterns=("file", "file", "file"))
if m5.validate():
    ok("validation", "duplicate patterns within manifest flagged")
else:
    gap("NIT", "validation", "duplicate patterns within ONE manifest pass validation")


print()
print("=" * 72)
print("DEEP DIVE 6: Lifecycle hook timing + safety")
print("=" * 72)
captured = []
def _hook(manifest):
    captured.append(reg_t.get(manifest.name) is not None)
reg_t = WorkflowRegistry()
reg_t.register(PluginManifest(name="timing", worker_cls_loader=lambda: object,
                                dag_id_patterns=("timing",), on_register=_hook))
if captured == [True]:
    ok("lifecycle", "on_register fires AFTER manifest joins registry")
else:
    gap("SERIOUS", "lifecycle", f"on_register timing wrong: {captured}")

reg_b = WorkflowRegistry()
def _bad(mf): raise RuntimeError("boom")
reg_b.register(PluginManifest(name="bad_hook", worker_cls_loader=lambda: object,
                                dag_id_patterns=("bad_hook",), on_register=_bad))
if reg_b.get("bad_hook") is not None:
    ok("lifecycle", "on_register failure left manifest registered")
else:
    gap("BLOCKER", "lifecycle", "on_register failure rolled back registration")


print()
print("=" * 72)
print("DEEP DIVE 7: replaced_by validation timing")
print("=" * 72)
reg_d = WorkflowRegistry()
reg_d.register(PluginManifest(
    name="dep_x", worker_cls_loader=lambda: object,
    dag_id_patterns=("dep_x",),
    is_deprecated=True, replaced_by="nonexistent_target",
))
# register() did NOT validate replaced_by; discover() does at end of walk.
gap("NIT", "validation",
    "register() does not validate replaced_by (only discover() does post-walk). Direct register() with broken replaced_by is silent until discover-time.")


print()
print("=" * 72)
print("DEEP DIVE 8: Immutability")
print("=" * 72)
m = PluginManifest(name="x", worker_cls_loader=lambda: object, dag_id_patterns=("x",))
try:
    m.name = "mutated"
    gap("BLOCKER", "immutability", "frozen=True did not prevent mutation")
except (AttributeError, Exception) as e:
    ok("immutability", f"frozen dataclass rejects mutation: {type(e).__name__}")

class_a = type("A", (), {})
class_b = type("B", (), {})
state = [class_a]
m2 = PluginManifest(name="x", worker_cls_loader=lambda: state[0], dag_id_patterns=("x",))
first = m2.worker_cls(); state[0] = class_b; second = m2.worker_cls()
if first is not second:
    gap("NIT", "immutability",
        f"worker_cls_loader closure is mutable (first={first.__name__}, second={second.__name__}). Documented but could surprise.")
else:
    ok("immutability", "worker_cls_loader is consistent")


print()
print("=" * 72)
print("DEEP DIVE 9: Health endpoint JSON-serializable")
print("=" * 72)
from polling_service.health import _manifest_to_dict
m = PluginManifest(
    name="test", worker_cls_loader=lambda: object,
    dag_id_patterns=("test",),
    capabilities=frozenset({"a", "b"}),
    requires_env=("X", "Y"),
    is_deprecated=True, deprecated_message="use foo", replaced_by="foo",
)
d = _manifest_to_dict(m)
try:
    json.dumps(d)
    ok("health", "manifest dict is JSON-serializable")
except (TypeError, ValueError) as e:
    gap("BLOCKER", "health", f"manifest dict not JSON-serializable: {e}")


print()
print("=" * 72)
print("DEEP DIVE 10: Discovery determinism")
print("=" * 72)
orders = []
for _ in range(3):
    reset_registry()
    r = get_registry()
    orders.append(r.names())
if all(o == orders[0] for o in orders):
    ok("discovery", f"order stable across 3 discoveries: {orders[0]}")
else:
    gap("BLOCKER", "discovery", f"order varies: {orders}")


print()
print("=" * 72)
print("DEEP DIVE 11: Telemetry under load")
print("=" * 72)
t = PluginTelemetry(name="loadtest")
t0 = time.perf_counter()
for i in range(10000):
    t.record_dispatch()
    t.record_success(duration_s=i * 0.00001)
elapsed = time.perf_counter() - t0
ms_per_op = (elapsed * 1000) / 10000
if ms_per_op < 0.1:
    ok("telemetry", f"10k dispatch+success in {elapsed*1000:.1f}ms ({ms_per_op:.4f}ms/op)")
else:
    gap("SERIOUS", "telemetry", f"telemetry overhead {ms_per_op:.4f}ms/op")

t1 = time.perf_counter()
snap = t.snapshot()
snap_ms = (time.perf_counter() - t1) * 1000
if snap_ms < 5:
    ok("telemetry", f"snapshot() takes {snap_ms:.2f}ms")
else:
    gap("SERIOUS", "telemetry", f"snapshot() takes {snap_ms:.2f}ms — too slow for HTTP polling")


print()
print("=" * 72)
print("DEEP DIVE 12: CLI safety (read-only on a live pod)")
print("=" * 72)
import polling_service.plugins as cli_mod
import inspect as _inspect
cli_src = _inspect.getsource(cli_mod)
write_kw = ["register(", "reset_registry(", ".invalidate(", ".delete", ".pop", ".clear", ".register_runtime_override("]
dangerous = []
for kw in write_kw:
    if kw in cli_src:
        # reset_registry IS called by the CLI but only to re-read — that's not a write to user data
        if kw == "reset_registry(":
            continue  # known intentional
        dangerous.append(kw)
if not dangerous:
    ok("cli", "CLI uses only read-only registry methods (no register/invalidate/clear)")
else:
    gap("SERIOUS", "cli", f"CLI invokes write methods: {dangerous}")


print()
print("=" * 72)
print("SUMMARY")
print("=" * 72)
if findings:
    by_sev = {}
    for sev, area, msg in findings:
        by_sev.setdefault(sev, []).append((area, msg))
    for sev in ("BLOCKER", "SERIOUS", "NIT"):
        if sev in by_sev:
            print(f"\n{sev}: {len(by_sev[sev])} finding(s)")
            for area, msg in by_sev[sev]:
                print(f"  * [{area}] {msg}")
    print(f"\nTotal: {sum(len(v) for v in by_sev.values())} findings.")
else:
    print("All deep-dive checks passed cleanly.")
