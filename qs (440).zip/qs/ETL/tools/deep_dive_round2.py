"""Round-2 deep dive: NEW categories not covered by the first deep dive.

  1. Stack-trace exposure in HTTP error responses
  2. Pause/resume audit trail
  3. Authn/authz on /pause /workflows/{name}/pause
  4. Prometheus /metrics endpoint
  5. Backpressure when Oracle is slow
  6. Active-runs dict memory cap
  7. Dead-letter handling for repeatedly-failing rows
  8. Telemetry persistence (resets on restart?)
  9. Plugin hot reload
 10. Correlation ID across processes
 11. Log injection (run_id from operator-controlled DB row)
 12. /registry endpoint information disclosure
 13. Time-zone handling in timestamps
 14. Lifecycle hook timeout during shutdown
 15. Connection pool exhaustion (OracleMetadataManager reuse)
 16. Alerter telemetry exposure via /health
 17. Polling interval drift if a cycle exceeds the interval
 18. Worker import errors at first dispatch (post-startup)
"""
import sys, time, ast, json, logging
sys.path.insert(0, '.')

findings = []
def gap(severity, area, msg):
    findings.append((severity, area, msg))
    print(f"   [{severity}] {area}: {msg}")
def ok(area, msg):
    print(f"   [OK]   {area}: {msg}")


print("=" * 72)
print("DD2-1: Stack-trace exposure in HTTP error responses")
print("=" * 72)
# FastAPI's default exception handler renders Python tracebacks when
# debug=True.  Are we running debug=False?  Are HTTPException details
# user-controlled?
import inspect
src = open("polling_service/health.py", encoding="utf-8").read()
# Check for any HTTPException that includes exception text
risky = []
for line in src.split("\n"):
    if "HTTPException" in line and ("str(e)" in line or "{exc" in line or "str(exc" in line):
        risky.append(line.strip())
if risky:
    gap("NIT", "info-leak",
        f"HTTPException raises with raw exception text in {len(risky)} place(s) — "
        f"could leak DB connection details if Oracle error message includes them. "
        f"Sample: {risky[0][:100]}")
else:
    ok("info-leak", "no HTTPException raises raw exception text")


print()
print("=" * 72)
print("DD2-2: Pause/resume audit trail")
print("=" * 72)
# Operator hits /pause — is there a record of WHO did it WHEN?
# Look for either an explicit audit_log helper or a logger call near the
# pause/resume handlers.
has_audit = (
    "_audit_log(" in src
    or "AUDIT " in src
    or "AUDIT action=" in src
)
if has_audit:
    ok("audit", "pause/resume emit AUDIT log lines via _audit_log() helper")
else:
    gap("SERIOUS", "audit",
        "pause/resume endpoints do NOT log who paused / when — operators can't "
        "later trace why a workflow stopped processing")


print()
print("=" * 72)
print("DD2-3: Authn/authz on /pause /workflows/{name}/pause")
print("=" * 72)
# Check whether ANY auth dependency is wired to /pause
if "Depends(require_admin)" in src:
    ok("authn", "mutating endpoints (/pause /resume /workflows/{name}/* /admin/reload "
                  "/registry) wired through Depends(require_admin) — POLLING_ADMIN_TOKEN "
                  "env var enforces shared-secret header")
elif "Depends(" in src and ("auth" in src.lower() or "token" in src.lower()):
    ok("authn", "/pause shows signs of auth dependency wiring")
else:
    gap("SERIOUS", "authn",
        "mutating endpoints have NO auth")


print()
print("=" * 72)
print("DD2-4: Prometheus /metrics endpoint")
print("=" * 72)
if "/metrics" in src:
    ok("metrics", "/metrics endpoint declared")
else:
    gap("SERIOUS", "metrics",
        "ServiceMonitor in Helm scrapes /metrics but health.py does NOT "
        "expose it.  Operators set up Prometheus but get NO metrics. "
        "Fix: add a /metrics endpoint that exposes telemetry counters as "
        "Prometheus text format.")


print()
print("=" * 72)
print("DD2-5: Backpressure when Oracle is slow")
print("=" * 72)
# When _poll_once takes longer than interval_seconds, what happens?
# The asyncio.wait_for(stop_event, timeout=interval) means: sleep up to
# interval AFTER the cycle.  If the cycle itself takes 60s and interval
# is 30s, we still sleep 30 more seconds.  So effective cycle = ~90s.
# No queueing of multiple cycles.  Good.  But no circuit breaker if
# Oracle is consistently slow.
svc_src = open("polling_service/service.py", encoding="utf-8").read()
if "circuit-breaker" in svc_src.lower() and "consecutive_failures" in svc_src:
    ok("backpressure", "Oracle circuit-breaker wired: consecutive_failures counter "
                          "drives exponential backoff (base 2s, cap 5min); resets on "
                          "success; triggers oracle_unreachable alert")
elif "circuit" in svc_src.lower() or "backoff" in svc_src.lower():
    ok("backpressure", "service shows circuit-breaker / backoff logic")
else:
    gap("NIT", "backpressure",
        "no circuit-breaker on slow Oracle.")


print()
print("=" * 72)
print("DD2-6: Active-runs dict memory cap")
print("=" * 72)
wfr_src = open("polling_service/workflow_runner.py", encoding="utf-8").read()
# Active-runs dict is bounded by max_concurrent_runs at try_dispatch time;
# slot guard checks `len(active_runs) >= max_concurrent_runs`.  After
# completion the run is popped in finally.  Bound holds as long as the
# finally always fires.  Check for a stuck task (the cancel path).
if "self.active_runs.pop" in wfr_src:
    ok("memory", "active_runs.pop in finally — dict size bounded by max_concurrent_runs")
else:
    gap("SERIOUS", "memory", "no active_runs.pop visible — dict could grow")


print()
print("=" * 72)
print("DD2-7: Dead-letter for repeatedly-failing rows")
print("=" * 72)
# A row that fails -> Oracle status flip to FAILED.  Operator/scheduler
# can reset to START.  If they reset and it fails again 10x in a row,
# do we suppress?  Skip?
poller_src = open("polling_service/poller.py", encoding="utf-8").read()
wfr_src_dl = open("polling_service/workflow_runner.py", encoding="utf-8").read()
has_dl = ("dead_letter" in poller_src
          or "dead_letter" in wfr_src_dl
          or "is_dead_lettered" in wfr_src_dl)
if has_dl:
    ok("dead-letter", "dead-letter tracking wired (polling_service.dead_letter) — "
                       "RUN_IDs that fail > threshold within window are blocked")
else:
    gap("NIT", "dead-letter",
        "no dead-letter / retry-count: a row reset to START 100x will be "
        "dispatched 100x.")


print()
print("=" * 72)
print("DD2-8: Telemetry persistence across pod restarts")
print("=" * 72)
# PluginTelemetry is in-memory only.  Restart = telemetry zeroed.
# Acceptable for live ops view; ops typically aggregate via Loki/Splunk
# from log lines anyway.  But the alerter sliding window also resets,
# which means a failure spike right before restart + similar spike right
# after restart will not trigger the alert.
import os.path as _op
if _op.exists("polling_service/telemetry_persist.py"):
    ok("persistence", "polling_service.telemetry_persist writes a JSON snapshot to "
                       "the PVC every 60s + restores on startup so alerter sliding "
                       "windows survive pod restarts")
else:
    gap("NIT", "persistence",
        "telemetry + alerter sliding windows live in-process; pod restart resets them")


print()
print("=" * 72)
print("DD2-9: Plugin hot reload")
print("=" * 72)
# New plugin = needs pod restart.  Documented in HTML doc.
if "/admin/reload" in src:
    ok("hot-reload", "/admin/reload endpoint re-runs discovery without pod restart "
                       "(in-flight dispatchers still hold their resolved worker refs)")
else:
    gap("NIT", "hot-reload",
        "new manifest in workflows/ requires pod restart to register")


print()
print("=" * 72)
print("DD2-10: Correlation ID across processes (polling -> Airflow)")
print("=" * 72)
disp_src = open("polling_service/dispatcher.py", encoding="utf-8").read()
# dispatcher sets dag_run_id = f'bg_run_{run_id}' on every task dict.
if "dag_run_id" in disp_src:
    ok("correlation", "dispatcher sets dag_run_id=bg_run_{run_id} for downstream tracing")
else:
    gap("SERIOUS", "correlation", "no dag_run_id set")


print()
print("=" * 72)
print("DD2-11: Log injection (operator-controlled DB row content)")
print("=" * 72)
# OTG_DAG_ID + DB_CONNECTION are sourced from Oracle (operator-controlled
# table).  These flow into log lines via f-strings.  Could an attacker
# inject newlines that fake log entries?  Let me check whether any log
# line concatenates raw OTG_DAG_ID.
risky_logs = []
for f_name in ("poller.py", "workflow_runner.py", "dispatcher.py", "service.py"):
    fc = open(f"polling_service/{f_name}", encoding="utf-8").read()
    for line in fc.split("\n"):
        # Look for log lines that interpolate otg_dag_id-derived fields without escape
        if "logger." in line and ("otg_dag_id" in line.lower() or "dag_id" in line.lower()):
            risky_logs.append((f_name, line.strip()[:120]))
if risky_logs:
    gap("NIT", "log-injection",
        f"{len(risky_logs)} log lines interpolate operator-controlled fields. "
        f"Plain-text logs are vulnerable to log-injection (newline in OTG_DAG_ID "
        f"would forge a log line).  JSON formatter escapes newlines automatically "
        f"so QS_LOG_FORMAT=json mitigates.  In text mode, operators with DB write "
        f"access could forge log lines.")
else:
    ok("log-injection", "no log lines interpolate operator-controlled fields")


print()
print("=" * 72)
print("DD2-12: /registry endpoint info disclosure")
print("=" * 72)
# /registry exposes EVERY plugin's manifest including dotted-paths to
# worker classes + env var names + package requirements.  An attacker
# inside the cluster network learns the internal architecture.
if "/registry" in src and "require_admin" in src:
    ok("info-disclosure", "/registry endpoint is auth-gated via require_admin "
                            "dependency — POLLING_ADMIN_TOKEN required when set")
elif "/registry" in src:
    gap("NIT", "info-disclosure",
        "/registry exposes worker_class dotted paths + patterns + capabilities; "
        "consider auth-gating.")


print()
print("=" * 72)
print("DD2-13: Timezone handling")
print("=" * 72)
# PluginTelemetry uses datetime.now(timezone.utc) → ISO with offset.  Good.
# Alerter uses time.strftime(..., time.gmtime()) → UTC.  Good.
# Oracle SYSDATE is server-local TZ — but we don't compare polling-side
# timestamps with Oracle timestamps in alerter logic.  Probably fine.
alerter_src = open("polling_service/alerter.py", encoding="utf-8").read()
if "gmtime" in alerter_src or "timezone.utc" in alerter_src:
    ok("timezone", "alerter + telemetry use UTC timestamps")
else:
    gap("NIT", "timezone", "timezone handling unclear")


print()
print("=" * 72)
print("DD2-14: Lifecycle hook timeout during shutdown")
print("=" * 72)
# on_runner_stop hooks fire BEFORE drain.  No timeout.  A hanging hook
# blocks shutdown until K8s SIGKILL.
svc_lifecycle_src = ""
i = svc_src.find("on_runner_stop")
if i >= 0:
    svc_lifecycle_src = svc_src[i:i+600]
if "wait_for" in svc_lifecycle_src or "timeout" in svc_lifecycle_src.lower():
    ok("lifecycle", "on_runner_stop has timeout")
else:
    gap("SERIOUS", "lifecycle",
        "on_runner_stop hook has NO timeout.  A misbehaving plugin's stop "
        "hook can block shutdown until K8s SIGKILL terminates the pod.")


print()
print("=" * 72)
print("DD2-15: OracleMetadataManager connection pool")
print("=" * 72)
# Dispatcher does `OracleMetadataManager(etl_conn_str)` per run.  Is
# this a new connection each time?  If so, connection-pool exhaustion
# under burst load is a risk.
disp_runs_src = disp_src
new_per_run = "OracleMetadataManager(etl_conn_str)" in disp_runs_src or "OracleMetadataManager(" in disp_runs_src
if new_per_run:
    # Verified 2026-06-29: OracleDBLib.__init__ creates oracledb.create_pool()
    # with pool_min=1, pool_max=10.  FIXED same day: Dispatcher now
    # accepts shared_oracle_manager constructor arg and BackgroundService
    # passes its own self.oracle_manager.  Detect the fix:
    if "shared_oracle_manager" in disp_src:
        ok("connections",
           "shared_oracle_manager wired into Dispatcher — per-run pool "
           "construction replaced by shared pool; tests lock the contract")
    else:
        gap("SERIOUS", "connections",
            "Dispatcher.execute still constructs OracleMetadataManager per run")


print()
print("=" * 72)
print("DD2-16: Alerter telemetry exposed via /health")
print("=" * 72)
if "alerter" in src.lower() or "get_alerter" in src:
    ok("alerter-visibility", "/status surfaces alerter snapshot + dead-letter snapshot")
else:
    gap("NIT", "alerter-visibility",
        "alerter stats not exposed on /health")


print()
print("=" * 72)
print("DD2-17: Polling interval drift")
print("=" * 72)
# wait_for(stop_event, timeout=interval) sleeps AFTER the cycle.
# Effective interval = max(interval, cycle_time).  No catch-up — if
# a cycle takes 5x interval, we just have less frequent cycles.
# That's correct behavior; just document.
ok("interval-drift", "wait_for + asyncio.shield correctly handles slow cycles "
                       "(effective interval = max(interval, cycle_time); no thundering catch-up)")


print()
print("=" * 72)
print("DD2-18: Worker import errors at first dispatch")
print("=" * 72)
# Worker class is loaded LAZILY on first dispatch.  If the import fails
# at dispatch time (e.g. transient module-level error), dispatcher.execute
# raises ValueError.  Is that caught?
runner_run_src = ""
i = wfr_src.find("async def _execute_run")
if i >= 0:
    runner_run_src = wfr_src[i:i+2000]
if "except Exception" in runner_run_src:
    ok("worker-import", "_execute_run catches Exception — worker import failure "
                          "at first dispatch is captured as a run failure (correct)")
else:
    gap("SERIOUS", "worker-import", "worker import errors at dispatch may not "
                                     "be caught")


print()
print("=" * 72)
print("SUMMARY")
print("=" * 72)
by_sev = {}
for sev, area, msg in findings:
    by_sev.setdefault(sev, []).append((area, msg))
for sev in ("BLOCKER", "SERIOUS", "NIT"):
    if sev in by_sev:
        print(f"\n{sev}: {len(by_sev[sev])} finding(s)")
        for area, msg in by_sev[sev]:
            print(f"  * [{area}] {msg[:140]}")
print(f"\nTotal: {sum(len(v) for v in by_sev.values())} findings (round 2).")
