"""Shared NFS-backed logging helper for Airflow DAGs.

ONE truth for DAG log setup across every DAG that needs it (prewarm,
sod, dynamic-dag generator, future workflows).  Per [Single-chokepoint
pattern]: same setup logic replicated across N DAGs is a maintenance
hazard -- a fix to handler-de-dup or rotation policy must land in ONE
place, not 3+.

2026-07-01 hotfix -- LOGS MOVED FROM PVC TO NFS.  The PVC has a 2 GB
quota that a chatty parse cycle filled within hours (Airflow parses
DAG files every ~30s; a fleet of 100 DAGs emits GB/day of DAG-
generation logs alone).  NFS is the persistent shared filesystem
already mounted for ETL bulk output + polling service logs.  Module
filename kept as ``pvc_log.py`` for back-compat with callers that
import it by name; the substance is 100% NFS now.

Retention policy (2026-07-01 operator direction: "keep for 7 days"):
  * Daily rotation at midnight (``TimedRotatingFileHandler``).
  * Keeps the last 7 rotated files; older auto-deleted by the
    handler's own ``backupCount`` mechanism on each rollover.
  * Belt-and-braces: proactive age-based sweep on every ``setup_pvc_logging``
    call deletes files matching ``<log_name>.log*`` that are older
    than ``max_age_days`` (default 7) -- covers the edge case where
    a pod restart interrupts a rollover, leaving stale rotated files
    on NFS forever.
  * Idempotent across Airflow scheduler re-parses -- multiple imports
    of the same DAG file don't accumulate handlers.
  * Fails SILENT when NFS isn't writable on this pod -- Airflow's
    own task log path still captures everything; only the shared
    persistence layer degrades.
  * Logs land at ``/usr/local/spark/nfs/bcp/batch/logs/<log_name>.log``
    by default (override via the ``log_dir`` kwarg OR environment).

Env-var overrides (safe to redeploy without code change):
  * ``QS_DAG_LOG_DIR``           -- log directory (default as above).
                                    Legacy alias ``QS_PVC_LOG_DIR`` is
                                    still honoured for back-compat.
  * ``QS_DAG_LOG_BACKUP_DAYS``   -- days retained (default 7).
                                    Legacy ``QS_PVC_LOG_BACKUP_COUNT``
                                    also honoured.
  * ``QS_DAG_LOG_MAX_AGE_DAYS``  -- proactive-sweep age cap (default 7).
  * ``QS_DAG_LOG_DISABLE=1``     -- skip the shared handler entirely
                                    and rely on Airflow's own log
                                    path (recovery switch).

Usage from an Airflow DAG file:

    import sys
    _PVC = "/usr/local/spark/pvc/code"
    if _PVC not in sys.path:
        sys.path.insert(0, _PVC)
    from qs_credentials.pvc_log import setup_pvc_logging
    setup_pvc_logging("my_dag_name")
"""
from __future__ import annotations

import logging
import os
import time
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from typing import Optional, Union


# 2026-07-01 hotfix -- default moved OFF PVC (2 GB quota, filled up
# within hours under chatty parse cycles) ONTO NFS which is the
# already-mounted persistent shared filesystem for ETL bulk output +
# polling logs.  Env override ``QS_DAG_LOG_DIR`` supported;
# legacy ``QS_PVC_LOG_DIR`` kept for callers not-yet-updated.
DEFAULT_LOG_DIR      = "/usr/local/spark/nfs/bcp/batch/logs"
# Operator direction 2026-07-01: "keep for 7 days".
DEFAULT_BACKUP_DAYS  = 7
DEFAULT_MAX_AGE_DAYS = 7
DEFAULT_FORMAT       = "%(asctime)s %(levelname)s %(name)s: %(message)s"

# Legacy alias -- old callers pass ``backup_days`` OR ``backup_count``;
# both mean "how many rotated files to retain".
DEFAULT_BACKUP_COUNT = DEFAULT_BACKUP_DAYS


def _env_int(key: str, default: int) -> int:
    """Parse an int env var defensively; malformed values fall back
    to the default without raising."""
    raw = os.environ.get(key, "").strip()
    if not raw:
        return default
    try:
        v = int(raw)
        return v if v > 0 else default
    except (TypeError, ValueError):
        return default


def _sweep_old_logs(
    log_dir: str,
    log_name: str,
    max_age_days: int,
) -> int:
    """Proactively delete rotated log files older than ``max_age_days``.

    Covers the edge case where a pod restart interrupts a rollover
    (leaving ``<log_name>.log.2026-06-20`` on disk indefinitely) OR
    where ``backupCount`` doesn't fire because the file never gets
    rotated (e.g. low volume + frequent pod restarts).

    Best-effort: any file the pod can't stat / remove is silently
    skipped.  Returns count of files deleted for logging.
    """
    if max_age_days <= 0:
        return 0
    try:
        entries = os.listdir(log_dir)
    except OSError:
        return 0
    cutoff = time.time() - (max_age_days * 24 * 3600)
    prefix = f"{log_name}.log"
    removed = 0
    for entry in entries:
        # Match both the primary file and its rotated suffixes
        # (`<name>.log`, `<name>.log.2026-06-20`, `<name>.log.1`).
        if not entry.startswith(prefix):
            continue
        path = os.path.join(log_dir, entry)
        try:
            st = os.stat(path)
        except OSError:
            continue
        if st.st_mtime < cutoff:
            try:
                os.remove(path)
                removed += 1
            except OSError:
                pass
    return removed


def setup_pvc_logging(
    log_name: str,
    *,
    log_dir:      Optional[str] = None,
    backup_days:  Optional[int] = None,
    backup_count: Optional[int] = None,           # alias for backup_days
    max_age_days: Optional[int] = None,
    fmt:          str = DEFAULT_FORMAT,
    level:        int = logging.INFO,
) -> Optional[Union[TimedRotatingFileHandler, RotatingFileHandler]]:
    """Attach an NFS-backed daily-rotating file handler to the root
    logger, retaining the last ``backup_days`` files (default 7).

    Args:
      log_name:     file stem -- final file is ``<log_dir>/<log_name>.log``
      log_dir:      directory on the shared NFS mount.  Defaults resolve
                    via env ``QS_DAG_LOG_DIR`` then ``QS_PVC_LOG_DIR``
                    (legacy) then ``DEFAULT_LOG_DIR``.
      backup_days:  days retained (default 7 via env
                    ``QS_DAG_LOG_BACKUP_DAYS``).
      backup_count: alias for ``backup_days``.
      max_age_days: proactive-sweep age cap in days.  Files matching
                    the log's stem older than this are deleted at
                    setup time (default 7 via env
                    ``QS_DAG_LOG_MAX_AGE_DAYS``).
      fmt:          logging format string.
      level:        handler level (root level also bumped to >= this).

    Returns:
      The created handler on success, ``None`` if already wired,
      NFS isn't writable, or ``QS_DAG_LOG_DISABLE=1``.

    2026-07-01 hotfix -- rotation model set to daily
    ``TimedRotatingFileHandler(when="midnight", backupCount=7)``
    matching operator direction ("keep for 7 days"), + proactive
    age-based sweep to purge orphan rotated files that survived a
    pod restart.
    """
    # Recovery kill-switch: operator can disable the shared handler
    # entirely via env, e.g. when NFS is unmounted / read-only.
    # Airflow's own task log path still captures everything.
    # Legacy env name kept for back-compat.
    _disable = (
        os.environ.get("QS_DAG_LOG_DISABLE", "").strip()
        or os.environ.get("QS_PVC_LOG_DISABLE", "").strip()
    )
    if _disable in ("1", "true", "yes"):
        return None

    # Resolve defaults with env-var precedence.  Both the new
    # ``QS_DAG_LOG_*`` names and the legacy ``QS_PVC_LOG_*`` aliases
    # are honoured; the new name wins when both are set.
    log_dir_resolved = (
        log_dir
        or os.environ.get("QS_DAG_LOG_DIR", "").strip()
        or os.environ.get("QS_PVC_LOG_DIR", "").strip()
        or DEFAULT_LOG_DIR
    )
    backup_days_resolved = _env_int(
        "QS_DAG_LOG_BACKUP_DAYS",
        _env_int(
            "QS_PVC_LOG_BACKUP_COUNT",
            (
                backup_days if backup_days and backup_days > 0
                else backup_count if backup_count and backup_count > 0
                else DEFAULT_BACKUP_DAYS
            ),
        ),
    )
    max_age_days_resolved = _env_int(
        "QS_DAG_LOG_MAX_AGE_DAYS",
        max_age_days if max_age_days and max_age_days > 0 else DEFAULT_MAX_AGE_DAYS,
    )

    log_path = os.path.abspath(f"{log_dir_resolved}/{log_name}.log")
    root = logging.getLogger()

    # Idempotency: if ANY rotating handler is already pointed at the
    # same file, do nothing.  Scheduler re-parses would otherwise
    # stack up handlers and multiply log volume.
    for h in root.handlers:
        if (isinstance(h, (TimedRotatingFileHandler, RotatingFileHandler))
                and getattr(h, "baseFilename", "") == log_path):
            return None

    try:
        os.makedirs(log_dir_resolved, exist_ok=True)
    except OSError:
        return None  # NFS not writable / not mounted on this pod

    # Belt-and-braces age sweep: delete orphan rotated files
    # BEFORE attaching the handler so the pod starts clean.
    _sweep_old_logs(log_dir_resolved, log_name, max_age_days_resolved)

    try:
        fh = TimedRotatingFileHandler(
            log_path,
            when="midnight",
            interval=1,
            backupCount=backup_days_resolved,
            encoding="utf-8",
            delay=True,  # don't open the file until the first write
            utc=False,
        )
    except OSError:
        return None  # file not creatable -- give up silently

    fh.setFormatter(logging.Formatter(fmt))
    fh.setLevel(level)
    root.addHandler(fh)
    if root.level > level or root.level == logging.NOTSET:
        root.setLevel(level)
    return fh


__all__ = [
    "setup_pvc_logging",
    "DEFAULT_LOG_DIR",
    "DEFAULT_BACKUP_DAYS",
    "DEFAULT_BACKUP_COUNT",
    "DEFAULT_MAX_AGE_DAYS",
    "DEFAULT_FORMAT",
]
