"""Manual smoke / bootstrap CLI for the vault credential pre-warm.

Run BEFORE enabling the Airflow DAG to confirm the deploy is healthy:

    kubectl exec -it <airflow-worker-pod> -- \
        python -m qs_credentials.smoke_prewarm

OR (from a Spark driver pod with the same PVC mounted):

    python /usr/local/spark/pvc/code/qs_credentials/smoke_prewarm.py

What it does (same chokepoint as the DAG):
  1. Loads /usr/local/spark/pvc/code/configs/vault_config.yaml.
  2. Iterates secrets.refs.*, calls the shared resolver with retry.
  3. Verifies the on-disk cache file was written.
  4. **Round-trip** verifies every just-written entry is readable
     (catches Fernet key mismatch between pods -- the silent-killer
     prod incident this script exists to surface BEFORE you enable
     the DAG).
  5. Exits 0 on success, 1 on any failure with the actionable cause.

Use this as part of the standard deploy ritual:
  helm upgrade qs-etl --values prod-values.yaml ./helm/qs-etl
  kubectl exec airflow-worker-0 -- python -m qs_credentials.smoke_prewarm
  # ↑ if this passes, the DAG is safe to enable.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from typing import Any, Dict


def main(argv: list = None) -> int:
    parser = argparse.ArgumentParser(
        prog="smoke_prewarm",
        description=(
            "Smoke-test the vault prewarm against the real Vault.  "
            "Run BEFORE enabling the DAG."
        ),
    )
    parser.add_argument(
        "--vault-config", default=None,
        help="Override the vault_config.yaml path.  Default: "
             "/usr/local/spark/pvc/code/configs/vault_config.yaml",
    )
    parser.add_argument(
        "--pvc-code-root", default=None,
        help="Override the PVC code root added to sys.path.  Default: "
             "/usr/local/spark/pvc/code",
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Emit the summary as JSON to stdout (for automation).",
    )
    parser.add_argument(
        "--skip-round-trip", action="store_true",
        help="Skip the round-trip read-back verification.  ONLY use "
             "during early-bring-up when cryptography/Fernet may not "
             "yet be configured -- production deploys MUST run with "
             "round-trip enabled.",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    # Import after argparse so --help works even when qs_credentials is
    # not on sys.path yet (e.g., wrong PVC mount).
    if args.pvc_code_root and args.pvc_code_root not in sys.path:
        sys.path.insert(0, args.pvc_code_root)
    try:
        from qs_credentials.prewarm import (
            prewarm_vault_cache,
            DEFAULT_VAULT_CONFIG,
            DEFAULT_PVC_CODE_ROOT,
        )
    except ImportError as exc:
        print(
            f"[smoke] FAILED to import qs_credentials.prewarm: {exc}\n"
            "Likely the PVC isn't mounted at "
            f"{args.pvc_code_root or '/usr/local/spark/pvc/code'} OR "
            "qs_credentials/ wasn't deployed there.  Confirm "
            "  kubectl exec <pod> -- ls /usr/local/spark/pvc/code/qs_credentials",
            file=sys.stderr,
        )
        return 1

    vault_config_path = args.vault_config or DEFAULT_VAULT_CONFIG
    pvc_code_root     = args.pvc_code_root or DEFAULT_PVC_CODE_ROOT

    try:
        summary: Dict[str, Any] = prewarm_vault_cache(
            vault_config_path=vault_config_path,
            pvc_code_root=pvc_code_root,
            verify_round_trip=not args.skip_round_trip,
        )
    except Exception as exc:
        if args.json:
            print(json.dumps({"ok": False, "error": str(exc)},
                              default=str, indent=2))
        print(
            f"\n[smoke] FAILED: {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return 1

    if args.json:
        print(json.dumps(summary, default=str, indent=2))
    else:
        ok        = summary.get("ok", 0)
        failed    = summary.get("failed", 0)
        skipped   = summary.get("skipped", 0)
        cache     = summary.get("cache", {})
        rt        = summary.get("round_trip", {})
        print(f"\n[smoke] OK -- ok={ok} failed={failed} skipped={skipped}")
        print(f"[smoke] cache: path={cache.get('path')!r} "
                f"size={cache.get('size')} mtime={cache.get('mtime')}")
        print(f"[smoke] round-trip: checked={rt.get('checked')} "
                f"readable={rt.get('readable')} "
                f"not_readable={rt.get('not_readable')}")
        if failed:
            print(f"\n[smoke] WARN: {failed} ref(s) failed -- see logs.",
                    file=sys.stderr)
    # Exit non-zero on partial failure so CI / kubectl-exec wrappers
    # surface the partial degradation -- DAG behaviour deliberately
    # differs (DAG succeeds on partial; smoke is stricter because
    # it's the pre-enable gate).
    if summary.get("failed", 0) > 0:
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
