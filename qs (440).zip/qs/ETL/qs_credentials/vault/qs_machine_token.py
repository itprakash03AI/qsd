"""machine_token.py This module contains a class MachineToken for fetching Machine Identity"""

import json
import logging
import os

from .qs_utils import send_request

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class QSMachineToken:
    """QueryStudio Machine Identity Token helper.

    Phase 158 (2026-06-26) -- renamed from MachineToken to
    QSMachineToken to avoid collision with the vendor class.

    Utility class to retrieve machine token.

    Attributes:
    - configs (dict): Dictionary containing access configurations.
    - test_url (str): URL for retrieving machine identity token on test.

    Methods:
    - __init__(self, accessConfigs): Initializes the MachineToken
                                     instance with access configurations.
    - get_token(self): Retrieves machine token from the configured source.
    """

    # 2026-06-27 -- ``appName`` placeholder used to be a literal in the
    # URL string (never substituted -- the mock at 127.0.0.1:3003
    # received the raw text ``{appName}``).  Now formatted via
    # ``str.format`` with the per-instance app name (config-driven, or
    # ``querystudio`` default).
    _TEST_URL_TEMPLATE = "http://127.0.0.1:3003?appName={app_name}&Env=PROD"

    def __init__(self, access_configs):
        """
        Initializes the MachineToken instance.

        Args:
        - accessConfigs (dict): Dictionary containing access configurations.
        """
        self.configs = access_configs
        self.machine = self.configs.get("machine")
        # ``app_name`` resolution order: per-call config -> env var ->
        # backend admin-UI config (core.config.secrets.app_name) ->
        # default 'querystudio'.  ETL pod doesn't have core.config so
        # the import is guarded.
        explicit = (self.configs.get("app_name") or "").strip()
        if not explicit:
            explicit = os.environ.get("QS_VAULT_APP_NAME", "").strip()
        if not explicit:
            try:
                from core.config import secrets as _s
                explicit = str(getattr(_s, "app_name", "") or "").strip()
            except Exception:
                explicit = ""
        self.app_name = explicit or "querystudio"
        self.test_url = self._TEST_URL_TEMPLATE.format(app_name=self.app_name)

    def get_token(self):
        """
        Retrieves machine token from the configured source.

        Returns:
        - str or None: Machine token if successfully retrieved, None otherwise.
        """
        if self.machine == "test":
            logger.info("Retrieving machine identity token from test")
            # Phase 158 (2026-06-26) strategic fix -- send_request may
            # return None on network error; calling .data on it would
            # AttributeError.  Also, the parsed JSON is a dict so the
            # ``.data`` accessor (legacy bug) was wrong -- use the
            # standard dict lookup AND fall through cleanly when the
            # mock returns an unexpected shape.
            res = send_request(request_type="GET", url=self.test_url)
            if res is None:
                logger.error("Machine token: test mock unreachable")
                return None
            try:
                test_mid_token = json.loads(res.data)
            except Exception as exc:
                logger.error("Machine token: test mock returned non-JSON: %s", exc)
                return None
            if isinstance(test_mid_token, dict):
                return test_mid_token.get("data") or test_mid_token.get("token")
            if isinstance(test_mid_token, str):
                return test_mid_token
            return None

        if self.machine == "tprd":
            # 2026-06-27 -- probe multiple paths so the code "just works"
            # on standard K8s pods without any operator config.
            #
            # Probe order (first non-empty file wins):
            #   1. ETL_VAULT_TOKEN_PATH env var  -- explicit override
            #   2. /var/run/secrets/token/vault-token
            #      -- the dedicated projected-token mount that helm /
            #         pod-spec uses with a custom audience (preferred
            #         for prod where vault requires a specific JWT
            #         audience claim).
            #   3. /var/run/secrets/kubernetes.io/serviceaccount/token
            #      -- the DEFAULT K8s SA token, auto-created by kubelet
            #         on every pod with automountServiceAccountToken=true.
            #         Works without any pod-spec change.
            candidates = []
            override = os.environ.get("ETL_VAULT_TOKEN_PATH", "").strip()
            if override:
                candidates.append(override)
            candidates.append("/var/run/secrets/token/vault-token")
            candidates.append("/var/run/secrets/kubernetes.io/serviceaccount/token")

            tried = []
            for token_path in candidates:
                tried.append(token_path)
                try:
                    # Tokens are ASCII base64/JWT -- explicit encoding
                    # so Windows dev hosts don't trip cp1252.
                    with open(token_path, "r", encoding="utf-8") as file:
                        tprd_mid_token = file.read().strip()
                except FileNotFoundError:
                    continue
                except PermissionError as e:
                    logger.warning(
                        "Permission denied reading machine token at %s "
                        "(%s); trying next candidate...", token_path, e,
                    )
                    continue
                except Exception as e:
                    logger.warning(
                        "Error reading machine token at %s (%s); "
                        "trying next candidate...", token_path, e,
                    )
                    continue
                if not tprd_mid_token:
                    logger.warning(
                        "Machine token at %s is empty; trying next "
                        "candidate...", token_path,
                    )
                    continue
                logger.info(
                    "Machine identity token retrieved from %s "
                    "(length=%d)", token_path, len(tprd_mid_token),
                )
                return tprd_mid_token

            logger.error(
                "Machine token NOT found at any candidate path.  "
                "Tried: %s.  Either set ETL_VAULT_TOKEN_PATH to the "
                "right file, OR ensure the pod has "
                "automountServiceAccountToken=true (default).",
                tried,
            )
            return None
        logger.error("Please specify either tprd/test as the machine type!")
        return None
