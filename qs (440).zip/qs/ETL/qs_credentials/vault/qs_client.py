"""QSClient -- end-to-end pure-Python HashiCorp Vault client.

The single class that orchestrates the 3-step Vault dance:

    Step 1 (QSMachineToken)  -- pod K8s identity
    Step 2 (QSVaultToken)    -- exchange for Vault session token
    Step 3 (QSReadSecrets)   -- read the secret payload

Per [Single-chokepoint pattern]: orchestration lives in ONE place
(this class).  ``vault/__init__.py::fetch_secret`` is a thin adapter
that constructs QSClient, propagates state, and translates structured
failure state into an operator-actionable RuntimeError.  Step-by-step
INFO logs are emitted INSIDE this class so every caller -- ad-hoc
``resolve_secret()``, the cache layer, future smoke probes -- gets
the same diagnostics for free.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Optional

from .qs_machine_token import QSMachineToken
from .qs_vault_token import QSVaultToken
from .qs_read_secrets import QSReadSecrets

logger = logging.getLogger(__name__)


class QSClient:
    """End-to-end Vault client.

    Contract:
      * ``get_secrets()`` returns the secret payload on success, ``None``
        on any failure (fail-OPEN -- callers decide whether to raise).
      * Diagnostic state is surfaced on the instance after each call:
          - ``last_step_failed``        -- 0 on success, 1/2/3 on failure
          - ``last_step_exception``     -- the underlying exception, if any
          - ``last_step_reason``        -- short string ('empty'/'exception'/'invalid')
          - ``last_invalid_reason``     -- payload-validation reason (STEP 3)
          - ``last_payload_shape``      -- credential-safe shape description
          - ``last_lease_duration``     -- Vault's lease seconds (or None)
      * ``last_failure_message()`` formats the above into an
        operator-actionable message for callers that raise.

    Return shape by ``secret_type``:
      * ``AD_accounts`` -> ``(username, password)``
      * ``DB_accounts`` -> ``(username, password, tns_alias)``
      * ``kv_secrets``  -> the kv dict
    """

    # Step ordinals -- referenced by callers translating state into
    # operator-actionable messages.
    STEP_NONE            = 0
    STEP_MACHINE_TOKEN   = 1
    STEP_VAULT_TOKEN     = 2
    STEP_READ_SECRET     = 3
    # Sentinel for pre-flight input validation failure (caller passed
    # garbage to ``get_secrets``).  Kept distinct from the 3 real steps
    # so ``last_failure_message`` formats a calling-convention hint
    # instead of a misleading "check /var/run/secrets" K8s hint.
    STEP_INPUT_INVALID   = -1

    _STEP_NAMES = {
        STEP_NONE:            "(success)",
        STEP_INPUT_INVALID:   "input validation",
        STEP_MACHINE_TOKEN:   "machine identity token",
        STEP_VAULT_TOKEN:     "vault session token",
        STEP_READ_SECRET:     "read secret payload",
    }

    def __init__(self, access_configs: Optional[dict] = None):
        """``access_configs`` is held for forward-compat; the per-call
        ``secret_access_configs`` arg on ``get_secrets`` wins.

        State attrs documented in the class docstring -- all reset on
        each ``get_secrets()`` call so a fresh QSClient instance and a
        reused one behave identically.
        """
        self.access_configs = dict(access_configs or {})
        self._reset_state()

    def _reset_state(self) -> None:
        self.last_lease_duration:  Optional[int]           = None
        self.last_step_failed:     int                     = self.STEP_NONE
        self.last_step_exception:  Optional[BaseException] = None
        self.last_step_reason:     Optional[str]           = None
        self.last_invalid_reason:  Optional[str]           = None
        self.last_payload_shape:   Optional[str]           = None

    # ──────────────────────────────────────────────────────────────
    # Orchestration
    # ──────────────────────────────────────────────────────────────

    def get_secrets(
        self,
        *,
        machine: str = "tprd",
        secret_access_configs: Any,
        token_method: str = "JWT",
        secret_type: str = "AD_accounts",
        role_id: Optional[str] = None,
    ) -> Any:
        """End-to-end vault secret resolution.

        Returns the payload on success, ``None`` on any failure.  Read
        instance state afterwards (``last_step_failed`` etc.) for
        per-step diagnostic detail.

        Args:
          machine: ``tprd`` (read /var/run/secrets/token/vault-token)
                    or ``test`` (local 127.0.0.1:3003 mock).  ``openshift``
                    is mapped to ``tprd`` for back-compat.
          secret_access_configs: JSON-encoded string OR dict.
          token_method: ``JWT`` (single-step) or ``approle`` (two-step).
          secret_type:  ``AD_accounts`` | ``DB_accounts`` | ``kv_secrets``.
          role_id:      Only required when ``token_method='approle'``.
        """
        self._reset_state()

        # ── Normalise inputs ────────────────────────────────────────
        sac = self._normalise_sac(secret_access_configs)
        if sac is None:
            self.last_step_failed = self.STEP_INPUT_INVALID
            self.last_step_reason = "invalid_input"
            return None

        eff_machine = "tprd" if machine == "openshift" else machine

        cfg = dict(self.access_configs)
        cfg.update({
            "machine":               eff_machine,
            "token_method":          token_method,
            "secret_type":           secret_type,
            "role_id":               role_id,
            "secret_access_configs": sac,
        })

        # ── STEP 1 ──────────────────────────────────────────────────
        mid_token = self._run_step(
            self.STEP_MACHINE_TOKEN,
            lambda: QSMachineToken(cfg).get_token(),
        )
        if not mid_token:
            return None

        # ── STEP 2 ──────────────────────────────────────────────────
        vault_token = self._run_step(
            self.STEP_VAULT_TOKEN,
            lambda: QSVaultToken(cfg, mid_token).get_token(),
        )
        if not vault_token:
            return None

        # ── STEP 3 ──────────────────────────────────────────────────
        # The reader exposes lease_duration as side-channel state -- we
        # capture it on the QSClient instance so QSCredCache can drive
        # lease-aware cache TTL.
        try:
            reader = QSReadSecrets(cfg, vault_token)
            payload = reader.get_secrets()
            self.last_lease_duration = getattr(
                reader, "last_lease_duration", None,
            )
        except Exception as exc:
            self._record_step_failure(self.STEP_READ_SECRET, "exception", exc)
            logger.exception(
                "[vault] STEP 3: read secret payload FAILED with %s: %s",
                type(exc).__name__, exc,
            )
            return None

        # Validate + describe shape for diagnostics.  We DO NOT mark
        # STEP 3 as failed when the payload is merely invalid -- the
        # cache layer's retry-then-stale logic owns that decision.
        # Callers see last_invalid_reason and decide.
        self.last_payload_shape = describe_payload_shape(payload)
        self.last_invalid_reason = explain_invalid_payload(payload, secret_type)
        if self.last_invalid_reason is not None:
            logger.error(
                "[vault] STEP 3: read OK but payload INVALID -- %s.  "
                "Shape: %s", self.last_invalid_reason, self.last_payload_shape,
            )
        else:
            logger.info(
                "[vault] STEP 3: read secret payload OK (shape: %s)",
                self.last_payload_shape,
            )
        return payload

    # ──────────────────────────────────────────────────────────────
    # Internals
    # ──────────────────────────────────────────────────────────────

    def _normalise_sac(self, sac: Any) -> Optional[dict]:
        """Accept dict or JSON-string; log + return None on bad shape."""
        if isinstance(sac, dict):
            return dict(sac)
        if isinstance(sac, str):
            try:
                parsed = json.loads(sac)
            except Exception as exc:
                logger.error(
                    "QSClient.get_secrets: secret_access_configs is "
                    "not valid JSON: %s", exc,
                )
                return None
            if isinstance(parsed, dict):
                return parsed
            logger.error(
                "QSClient.get_secrets: secret_access_configs JSON "
                "decoded to %s, expected dict",
                type(parsed).__name__,
            )
            return None
        logger.error(
            "QSClient.get_secrets: secret_access_configs must be "
            "JSON string or dict, got %s",
            type(sac).__name__,
        )
        return None

    def _run_step(self, step: int, fn) -> Any:
        """Execute one step.  Logs + records failure state.  Returns
        the step's value on success, ``None`` on any failure."""
        step_name = self._STEP_NAMES[step]
        try:
            value = fn()
        except Exception as exc:
            self._record_step_failure(step, "exception", exc)
            logger.exception(
                "[vault] STEP %d: %s FAILED with %s: %s",
                step, step_name, type(exc).__name__, exc,
            )
            return None
        if not value:
            self._record_step_failure(step, "empty", None)
            logger.error(
                "[vault] STEP %d: %s returned EMPTY",
                step, step_name,
            )
            return None
        logger.info(
            "[vault] STEP %d: %s OK (length=%d)",
            step, step_name, len(str(value)),
        )
        return value

    def _record_step_failure(
        self, step: int, reason: str, exc: Optional[BaseException],
    ) -> None:
        self.last_step_failed = step
        self.last_step_reason = reason
        self.last_step_exception = exc

    # ──────────────────────────────────────────────────────────────
    # Diagnostic surface (consumed by ``fetch_secret`` adapter)
    # ──────────────────────────────────────────────────────────────

    def last_step_name(self) -> str:
        """Human-readable name of the last failed step (or '(success)')."""
        return self._STEP_NAMES.get(self.last_step_failed, "(unknown)")

    def last_failure_message(
        self,
        secret_ref: str,
        ref: dict,
        *,
        machine: str,
        eff_machine: str,
    ) -> str:
        """Format the last failure into an operator-actionable message.

        Builds the per-step hint inline since each step has different
        knobs an operator can check.  Centralised here so every caller
        (cache, smoke probes, ad-hoc resolves) gets the same wording.
        """
        step = self.last_step_failed
        if step == self.STEP_NONE:
            return f"secret_ref={secret_ref!r}: no failure recorded"

        exc = self.last_step_exception
        reason = self.last_step_reason or "empty"

        # Pre-flight input failure is NOT a Vault-dance step -- format
        # as a calling-convention error, not as STEP 1.
        if step == self.STEP_INPUT_INVALID:
            return (
                f"secret_ref={secret_ref!r}: input validation failed "
                f"({reason}).  secret_access_configs must be a dict OR "
                f"a JSON-string that decodes to a dict.  See preceding "
                f"ERROR log for the rejected type."
            )

        lines = [
            f"secret_ref={secret_ref!r}: STEP {step} "
            f"({self._STEP_NAMES[step]}) {reason}.",
        ]
        if exc is not None:
            lines.append(f"  Underlying: {type(exc).__name__}: {exc}")

        if step == self.STEP_MACHINE_TOKEN:
            if eff_machine == "tprd":
                lines.append(
                    "  Likely: /var/run/secrets/token/vault-token is "
                    "missing or unreadable on this pod.  Check the "
                    "K8s ServiceAccount has a projected token volume "
                    "mounted there, OR set ETL_VAULT_TOKEN_PATH to the "
                    "right file, OR ensure automountServiceAccountToken=true."
                )
            elif eff_machine == "test":
                lines.append(
                    "  Likely: local mock at http://127.0.0.1:3003 is "
                    "not running.  Start it with smoke_resolver.py."
                )
            else:
                lines.append(
                    f"  machine={machine!r} (eff={eff_machine!r}) is "
                    "not a recognised mode -- valid: tprd / openshift / test."
                )
        elif step == self.STEP_VAULT_TOKEN:
            lines.append(
                f"  Check: auth_url={ref.get('auth_url')!r} reachable; "
                f"role_name={ref.get('role_name')!r} registered in Vault; "
                f"role_type={ref.get('role_type')!r} matches the auth "
                "method (JWT for K8s service accounts)."
            )
        elif step == self.STEP_READ_SECRET:
            lines.append(
                f"  Check: secret_url={ref.get('secret_url')!r} reachable; "
                "vault role has read permission on that path; secret "
                "actually exists at that path."
            )
        return "\n".join(lines)


def resolve_secret(
    *,
    machine: str = "tprd",
    secret_access_configs: Any,
    token_method: str = "JWT",
    secret_type: str = "AD_accounts",
    role_id: Optional[str] = None,
) -> Any:
    """Thin functional wrapper -- equivalent to
    ``QSClient().get_secrets(...)`` for callers that prefer the
    call-site syntax over instantiation.  Same fail-OPEN contract:
    returns the payload on success, ``None`` on any failure.
    """
    return QSClient().get_secrets(
        machine=machine,
        secret_access_configs=secret_access_configs,
        token_method=token_method,
        secret_type=secret_type,
        role_id=role_id,
    )


# ──────────────────────────────────────────────────────────────────
#  Diagnostic helpers used by QSClient + re-exported from
#  ``qs_credentials.vault`` for callers that want the descriptors.
# ──────────────────────────────────────────────────────────────────


def explain_invalid_payload(payload: Any, secret_type: str) -> Optional[str]:
    """Return a one-line reason WHY ``payload`` is rejected, or
    ``None`` when it's valid.  Five distinct rejection reasons used
    to all collapse to "invalid/blank payload" -- callers now get
    operator-readable detail."""
    if payload is None:
        return "payload is None (Vault returned no result)"

    if secret_type in ("DB_accounts", "AD_accounts"):
        if not isinstance(payload, (tuple, list)):
            return (
                f"expected tuple/list for secret_type={secret_type!r}, "
                f"got {type(payload).__name__}"
            )
        if len(payload) < 2:
            return (
                f"secret_type={secret_type!r} requires (user, password) "
                f"tuple but payload has only {len(payload)} element(s)"
            )
        user = str(payload[0] or "").strip()
        password = str(payload[1] or "").strip()
        if not user and not password:
            return "BOTH user AND password fields are blank in Vault payload"
        if not user:
            return "user field is blank in Vault payload (password OK)"
        if not password:
            return (
                "password field is blank in Vault payload "
                "(user=%r OK) -- likely mid-rotation, retry in 60s "
                "OR check Vault secret was actually populated"
                % user
            )
        return None

    if secret_type == "kv_secrets":
        if not isinstance(payload, dict):
            return (
                f"expected dict for secret_type='kv_secrets', "
                f"got {type(payload).__name__}"
            )
        if not payload:
            return "kv_secrets payload is empty dict {}"
        if not any(str(v or "").strip() for v in payload.values()):
            return (
                f"kv_secrets payload has keys {sorted(payload.keys())} "
                "but ALL values are blank"
            )
        return None

    # Unknown type -- trust caller.
    return None


def describe_payload_shape(payload: Any) -> str:
    """Return a credential-safe one-line description of the payload's
    structure for logging.  Does NOT leak passwords / kv values.

    Examples:
      "tuple(len=2): user='abc' password=<8 chars>"
      "tuple(len=3): user='abc' password=<BLANK> tns_alias='xx'"
      "dict(keys=['access_key', 'secret_key']): 2/2 non-blank values"
      "None"
    """
    if payload is None:
        return "None"
    if isinstance(payload, tuple):
        parts = [f"tuple(len={len(payload)})"]
    elif isinstance(payload, list):
        parts = [f"list(len={len(payload)})"]
    elif isinstance(payload, dict):
        keys = sorted(str(k) for k in payload.keys())
        nonblank = sum(
            1 for v in payload.values() if str(v or "").strip()
        )
        return f"dict(keys={keys}): {nonblank}/{len(payload)} non-blank values"
    else:
        return f"{type(payload).__name__}"

    fields = []
    for i, v in enumerate(payload):
        if i == 0:  # user -- show literal (not a secret)
            fields.append(f"user={str(v or '<BLANK>')!r}")
        elif i == 1:  # password -- redact
            if v is None or not str(v).strip():
                fields.append("password=<BLANK>")
            else:
                fields.append(f"password=<{len(str(v))} chars>")
        elif i == 2:  # tns_alias -- show literal (DSN, not a secret)
            fields.append(f"tns_alias={str(v or '<BLANK>')!r}")
        else:
            fields.append(f"field{i}={type(v).__name__}")
    return parts[0] + ": " + " ".join(fields)
