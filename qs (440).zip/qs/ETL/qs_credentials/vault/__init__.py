"""qs_credentials.vault -- pure-Python HashiCorp Vault client.

DUAL-COPY: this subpackage + the sibling ``cache.py`` are
byte-identical between ``ETL/qs_credentials/`` and
``backend/core/qs_credentials/``.  CI ``TestSyncedCopies`` fails
when they drift; any edit MUST land in both copies.

Files in this subpackage:
  qs_client.py        -- QSClient (the orchestrator) + resolve_secret
                          + describe_payload_shape + explain_invalid_payload
  qs_machine_token.py -- step 1 (pod's K8s machine identity)
  qs_vault_token.py   -- step 2 (exchange for Vault session token)
  qs_read_secrets.py  -- step 3 (GET the secret payload)
  qs_utils.py         -- send_request (HTTP helper used by the steps)

Public surface (re-exported below):
  QSClient                  -- end-to-end client (owns orchestration
                                + step-by-step diagnostic state)
  resolve_secret            -- functional wrapper around QSClient
  QSMachineToken/Vault/Read -- the 3 step classes (advanced callers)
  fetch_secret              -- chokepoint consumed by QSCredCache:
                                converts QSClient None + state into
                                an operator-actionable RuntimeError
  is_valid_vault_payload    -- payload validator (rejects blank fields)
  explain_invalid_payload   -- per-rejection-reason variant
  describe_payload_shape    -- credential-safe shape descriptor
  describe_ref_for_log      -- credential-safe ref descriptor

Strategic shape (2026-06-27 Phase 158 R9):
  QSClient owns the orchestration + per-step instrumentation + state.
  ``fetch_secret`` is a ~20-line adapter: builds the access_cfg,
  delegates to QSClient, propagates lease/invalid/shape state via the
  ``_out`` side channel, and translates structured failure state into
  a RuntimeError for the cache layer.  Per [Single-chokepoint pattern]
  there is exactly ONE orchestration site.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from .qs_client import (
    QSClient,
    resolve_secret,
    describe_payload_shape,
    explain_invalid_payload,
)
from .qs_machine_token import QSMachineToken
from .qs_vault_token import QSVaultToken
from .qs_read_secrets import QSReadSecrets

logger = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────
#  Chokepoint helpers consumed by QSCredCache (qs_credentials.cache)
# ────────────────────────────────────────────────────────────────────


_REF_REQUIRED = ("type", "auth_url", "role_name", "role_type", "secret_url")


def _build_access_cfg(ref: dict) -> dict:
    """Map a SystemAccount / vault_config.yaml row to QSClient's
    access_cfg dict.

    AppRole-only fields are optional -- harmless to pass as None when
    ``token_method='JWT'``; required when ``token_method='approle'``.
    """
    return {
        "AUTH_URL":              ref.get("auth_url") or "",
        "ROLE_NAME":             ref.get("role_name") or "",
        "ROLE_TYPE":             ref.get("role_type") or "",
        "ROTATE_URL":            ref.get("rotate_url") or "",
        "SECRET_URL":            ref.get("secret_url") or "",
        "STEP_UP_NAME":          ref.get("step_up_name"),
        "STEP_UP_AUTH_URL":      ref.get("step_up_auth_url"),
        "APPROLE_SECRET_ID_URL": ref.get("approle_secret_id_url"),
        "APPROLE_AUTH_URL":      ref.get("approle_auth_url"),
    }


def describe_ref_for_log(ref: dict) -> str:
    """Return a credential-safe one-line description of the ref config
    for diagnostic log messages.  URLs are useful for debugging --
    they're operator-set, not secrets.  AppRole secret_id is redacted.
    """
    safe_keys = (
        "type", "role_name", "role_type",
        "auth_url", "secret_url", "rotate_url",
        "step_up_name", "step_up_auth_url",
        "approle_auth_url",
    )
    parts = []
    for k in safe_keys:
        v = ref.get(k)
        if v:
            parts.append(f"{k}={v!r}")
    if ref.get("role_id"):
        parts.append("role_id=<set>")
    return ", ".join(parts) or "<empty ref>"


def fetch_secret(
    name: str,
    ref: dict,
    *,
    machine: str = "tprd",
    token_method: str = "JWT",
    _out: Optional[dict] = None,
) -> Any:
    """Resolve ``ref`` via QSClient + raise an operator-actionable
    RuntimeError on any failed step.

    Args:
      name:         Logical secret_ref name (for log/error messages).
      ref:          Per-account ref dict (type / auth_url / role_name /
                    role_type / secret_url required; rotate_url +
                    AppRole fields optional).
      machine:      ``tprd`` (reads /var/run/secrets/token/vault-token)
                    or ``test`` (127.0.0.1:3003 mock).  Legacy slug
                    ``openshift`` is mapped to ``tprd``.
      token_method: ``JWT`` or ``approle``.
      _out:         Optional dict.  When passed, populated with:
                      lease_duration  -- Vault lease seconds (or None)
                      invalid_reason  -- payload-validation reason (None on valid)
                      payload_shape   -- credential-safe shape string
                    Drives lease-aware TTL + actionable cache errors.

    Returns the payload on success.  Raises ``RuntimeError`` with the
    QSClient-formatted operator-actionable message on any step failure.
    """
    eff_machine = "tprd" if machine == "openshift" else machine
    access_cfg = _build_access_cfg(ref)
    role_id = ref.get("role_id") if token_method == "approle" else None
    secret_type = ref.get("type") or ""

    logger.info(
        "[vault] STEP 0: secret_ref=%r machine=%r (eff=%r) token_method=%r",
        name, machine, eff_machine, token_method,
    )
    logger.info("[vault] STEP 0: ref: %s", describe_ref_for_log(ref))

    client = QSClient()
    payload = client.get_secrets(
        machine=eff_machine,
        secret_access_configs=access_cfg,
        token_method=token_method,
        secret_type=secret_type,
        role_id=role_id,
    )

    if _out is not None:
        _out["lease_duration"] = client.last_lease_duration
        _out["invalid_reason"] = client.last_invalid_reason
        _out["payload_shape"]  = client.last_payload_shape

    if client.last_step_failed != QSClient.STEP_NONE:
        raise RuntimeError(client.last_failure_message(
            name, ref, machine=machine, eff_machine=eff_machine,
        ))

    return payload


# Back-compat alias -- existing callers + tests still grep this name.
fetch_secret_with_vendor_fallback = fetch_secret


def is_valid_vault_payload(payload: Any, secret_type: str) -> bool:
    """Single source of truth for "what's a good Vault payload".

    Vault occasionally returns blank fields (transient mid-rotation,
    network glitch).  Cache MUST NEVER store these.  QSCredCache
    consults this before every cache write.

    For diagnostic detail when the payload is rejected, use
    :func:`explain_invalid_payload` -- both functions share the same
    rule set so they can't drift.
    """
    return explain_invalid_payload(payload, secret_type) is None


__all__ = [
    "QSClient",
    "QSMachineToken", "QSVaultToken", "QSReadSecrets",
    "resolve_secret",
    "fetch_secret",
    "fetch_secret_with_vendor_fallback",
    "is_valid_vault_payload",
    "explain_invalid_payload",
    "describe_payload_shape",
    "describe_ref_for_log",
]
