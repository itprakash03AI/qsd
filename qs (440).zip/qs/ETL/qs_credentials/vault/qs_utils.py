"""qs_utils.py -- HTTP transport for the QSClient vault dance.

2026-06-27 hardening (Phase 158 R9):
  * Module-level PoolManager singleton (was: new pool per call -- 3 TLS
    handshakes per secret read for the 3-step Vault dance).
  * No more global ``urllib3.util.ssl_.DEFAULT_CIPHERS`` mutation
    (was: poisoning the whole pod's TLS stack -- S3 / AWS SDK /
    requests all downgraded to SECLEVEL=1).
  * ``QS_VAULT_VERIFY_SSL`` env var lets operators opt INTO cert
    verification (default OFF for back-compat with self-signed Vault
    deployments behind corp CA).
  * ``QS_VAULT_TIMEOUT_SECONDS`` env var tunes the per-request timeout
    (default 3.0s -- preserves prior behaviour).
  * Broader exception capture: any urllib3 error returns None cleanly
    so step classes' ``if res is None`` short-circuit engages.
"""
import logging
import os
import ssl
import threading

import urllib3

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# ── Module-level singleton ──────────────────────────────────────────
# One PoolManager per process, lazily constructed on first send_request().
# Re-uses TCP / TLS connections across the 3-step Vault dance + across
# concurrent secret resolutions.
_POOL: urllib3.PoolManager = None
_POOL_LOCK = threading.Lock()


def _backend_config():
    """Lazy-import the QS pod's ``core.config.secrets`` accessor so
    runtime knobs are admin-UI-editable (no pod restart).  ETL pod
    doesn't have core.config -- catches ImportError and returns None
    (env-var-only mode preserved for ETL)."""
    try:
        from core.config import secrets as _s
        return _s
    except Exception:
        return None


def _verify_ssl() -> bool:
    """Operator-controlled TLS verification toggle.

    Resolution order (highest wins):
      1. ``QS_VAULT_VERIFY_SSL`` env var ('1'/'true'/'yes' = ON)
      2. ``core.config.secrets.verify_ssl`` (admin UI editable)
      3. Default OFF (back-compat with self-signed Vault behind corp CA)
    """
    env = os.environ.get("QS_VAULT_VERIFY_SSL", "").strip().lower()
    if env in ("1", "true", "yes"):
        return True
    if env in ("0", "false", "no"):
        return False
    cfg = _backend_config()
    if cfg is not None:
        try:
            return bool(cfg.verify_ssl)
        except Exception:
            pass
    return False


def _timeout_seconds() -> float:
    """Per-request HTTP timeout for vault calls.

    Resolution order: env var -> core.config.secrets.timeout_seconds -> 3.0s.
    """
    raw = os.environ.get("QS_VAULT_TIMEOUT_SECONDS", "").strip()
    if raw:
        try:
            return float(raw)
        except ValueError:
            logger.warning(
                "QS_VAULT_TIMEOUT_SECONDS=%r is not a float -- "
                "ignoring; falling through to config.", raw,
            )
    cfg = _backend_config()
    if cfg is not None:
        try:
            return float(cfg.timeout_seconds)
        except Exception:
            pass
    return 3.0


def _legacy_ciphers_enabled() -> bool:
    """SECLEVEL=1 opt-in for legacy Vault deployments.

    Resolution order: env -> core.config.secrets.legacy_ciphers -> False.
    """
    env = os.environ.get("QS_VAULT_LEGACY_CIPHERS", "").strip().lower()
    if env in ("1", "true", "yes"):
        return True
    if env in ("0", "false", "no"):
        return False
    cfg = _backend_config()
    if cfg is not None:
        try:
            return bool(cfg.legacy_ciphers)
        except Exception:
            pass
    return False


def _build_pool() -> urllib3.PoolManager:
    """Construct the module-level PoolManager.

    * Retry: 5 total, no raise_on_status (we inspect res.status), backoff 0.1.
    * Timeout: configurable via QS_VAULT_TIMEOUT_SECONDS (default 3s).
    * TLS: verify off by default; opt-in via QS_VAULT_VERIFY_SSL=1.
      When NOT verifying, suppress the urllib3 InsecureRequestWarning so
      operator log streams stay clean.
    * SECLEVEL: when SECLEVEL=1 is genuinely required (legacy Vault
      with weak ciphers), set via per-pool ssl_context -- NEVER mutate
      urllib3.util.ssl_.DEFAULT_CIPHERS (that poisoned the entire
      process's TLS stack).
    """
    retry = urllib3.Retry(total=5, raise_on_status=False, backoff_factor=0.1)
    timeout = urllib3.Timeout(_timeout_seconds())

    verify = _verify_ssl()
    cert_reqs = "CERT_REQUIRED" if verify else "CERT_NONE"
    if not verify:
        # Only suppress warnings on the no-verify path; verify=True
        # callers WANT to see cert errors.
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # SECLEVEL=1 legacy-Vault opt-in via ssl_context (scoped to THIS
    # pool, not the process).  Driven by ``_legacy_ciphers_enabled()``
    # which honors env > config > default.
    ssl_context = None
    if _legacy_ciphers_enabled():
        ssl_context = ssl.create_default_context()
        try:
            ssl_context.set_ciphers("DEFAULT@SECLEVEL=1")
        except ssl.SSLError as exc:
            logger.warning(
                "legacy_ciphers enabled but ssl.set_ciphers failed: %s "
                "-- continuing with default ciphers", exc,
            )
            ssl_context = None

    kwargs = dict(cert_reqs=cert_reqs, retries=retry, timeout=timeout)
    if ssl_context is not None:
        kwargs["ssl_context"] = ssl_context
    return urllib3.PoolManager(**kwargs)


def _get_pool() -> urllib3.PoolManager:
    """Return the module-level PoolManager, constructing on first call.

    Tests can call :func:`reset_pool` to force a rebuild between tests
    that need different env-var settings.
    """
    global _POOL
    if _POOL is None:
        with _POOL_LOCK:
            if _POOL is None:
                _POOL = _build_pool()
    return _POOL


def reset_pool() -> None:
    """Test hook: drop the cached PoolManager so the next send_request
    rebuilds it (picks up new env-var values).  Production callers
    never need this -- the env vars are read once at module init."""
    global _POOL
    with _POOL_LOCK:
        _POOL = None


def urllib3_client_builder():
    """Back-compat shim.  Existing call sites + tests grep this name.

    Old callers got a FRESH PoolManager per call; new callers share
    the module-level singleton.  Returning the singleton preserves the
    surface without re-introducing the per-call TLS-handshake overhead.
    """
    return _get_pool()


def send_request(request_type, url, headers=None, body=None, auth=None):
    """Send an HTTP request via the module-level PoolManager.

    Args:
      request_type: HTTP verb (GET / POST / ...).
      url:          target URL.
      headers:      dict of headers (optional).
      body:         request body bytes/str (optional).
      auth:         (user, password) tuple for basic auth (optional).

    Returns:
      urllib3 HTTPResponse on 2xx/3xx, ``None`` on any HTTP/network
      error.  Callers MUST check ``res is None`` before accessing
      attributes -- preserves the contract every QS step class relies
      on.
    """
    pool = _get_pool()
    try:
        if auth:
            # urllib3.make_headers refuses None args; coerce defensively.
            user = "" if auth[0] is None else str(auth[0])
            pw = "" if auth[1] is None else str(auth[1])
            headers = urllib3.make_headers(basic_auth=f"{user}:{pw}")
        res = pool.request(request_type, url, body=body, headers=headers)
        if res is None:
            return None
        if res.status >= 400:
            logger.warning(
                "HTTP %s %s -> status=%s (body bytes=%s)",
                request_type, url, res.status,
                len(getattr(res, "data", b"") or b""),
            )
            return None
        return res
    except urllib3.exceptions.HTTPError as exc:
        # Covers MaxRetryError / TimeoutError / ProtocolError /
        # NewConnectionError / LocationValueError -- all inherit from
        # urllib3.exceptions.HTTPError.
        logger.warning("urllib3.HTTPError for %s %s: %s", request_type, url, exc)
        return None
    except Exception as exc:
        # Defence in depth -- any other unhandled exception (e.g.,
        # malformed kwargs) MUST surface as None so the calling step
        # class's ``if res is None`` branch engages instead of crashing
        # the whole vault dance.
        logger.exception(
            "send_request: unexpected %s for %s %s: %s",
            type(exc).__name__, request_type, url, exc,
        )
        return None
