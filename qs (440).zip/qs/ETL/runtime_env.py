"""Per-pod-environment overrides for credential resolution.

2026-06-27 -- single chokepoint so every standalone (and any future
Airflow / spark-submit / local entrypoint) wires the SAME CLI args.

Two values the caller controls per pod, not per yaml:

  --machine          : 'tprd' | 'test' | 'openshift'
                       Where this program is running.  Drives which
                       endpoint qs_credentials hits to obtain the
                       machine identity token (1st leg of the 3-step
                       vault dance).
                         'openshift' -> reads /var/run/secrets/token/vault-token
                                       (production K8s projected token)
                         'tprd'      -> same as 'openshift' (alias)
                         'test'      -> hits local mock at
                                       http://127.0.0.1:3003

  --vault-token-method : 'JWT' | 'approle'
                       Which auth path to use against vault.  Defaults
                       to 'JWT' (the K8s service-account JWT exchange).

Both flags export to env vars (ETL_VAULT_MACHINE / ETL_VAULT_TOKEN_METHOD)
that qs_credentials/resolver.py reads -- ONE place owns the override.

Usage:

    parser = argparse.ArgumentParser(...)
    add_runtime_env_args(parser)
    args = parser.parse_args()
    apply_runtime_env_args(args)

After ``apply_runtime_env_args`` returns, the env vars are set and any
``from qs_credentials import resolve_...`` call inside the standalone
honours them.
"""
from __future__ import annotations

import argparse
import logging
import os
from typing import Optional


_logger = logging.getLogger("runtime_env")


# ──────────────────────────────────────────────────────────────────────
#  Argparse wiring
# ──────────────────────────────────────────────────────────────────────


def add_runtime_env_args(parser: argparse.ArgumentParser) -> None:
    """Register --machine + --vault-token-method on the parser.

    Call this from every standalone's ``main()`` BEFORE
    ``parser.parse_args()`` so the args show up in --help and Airflow
    DAG authors can wire them via spark-submit:

        spark-submit oracle_standalone.py \\
            --report_id 42 \\
            --business_date 2026-06-27 \\
            --dag_id ORACLE_DAG \\
            --machine tprd

    OR via env-var:

        spark-submit \\
            --conf spark.kubernetes.driverEnv.ETL_VAULT_MACHINE=tprd \\
            oracle_standalone.py ...
    """
    parser.add_argument(
        "--machine",
        type=str,
        default=None,
        choices=(None, "tprd", "openshift", "test"),
        help=(
            "Where this program is running.  Drives which endpoint "
            "QSClient hits for the machine identity token.  'tprd' / "
            "'openshift' read the pod's K8s projected token at "
            "/var/run/secrets/token/vault-token.  'test' hits the "
            "local mock at http://127.0.0.1:3003.  Overrides "
            "vault_config.yaml's secrets.vault.machine.  Equivalent "
            "to setting ETL_VAULT_MACHINE env var."
        ),
    )
    parser.add_argument(
        "--vault-token-method",
        type=str,
        default=None,
        choices=(None, "JWT", "approle"),
        help=(
            "Vault auth method.  Defaults to 'JWT' (K8s service-account "
            "JWT exchange).  Overrides vault_config.yaml's "
            "secrets.vault.token_method.  Equivalent to setting "
            "ETL_VAULT_TOKEN_METHOD env var."
        ),
    )


def apply_runtime_env_args(
    args: argparse.Namespace,
    *,
    logger: Optional[logging.Logger] = None,
) -> None:
    """Export the CLI args to env vars qs_credentials reads.

    Idempotent: when args.machine / args.vault_token_method is None
    (operator didn't pass the flag), env vars are LEFT ALONE -- a
    pre-existing ETL_VAULT_MACHINE in the pod env still wins.

    Resolution order at qs_credentials.resolver.py:282-296:
       CLI arg (this function) > env var > vault_config.yaml > "tprd"
    """
    log = logger or _logger

    machine = getattr(args, "machine", None)
    if machine:
        os.environ["ETL_VAULT_MACHINE"] = machine
        log.info("Runtime env: ETL_VAULT_MACHINE=%r (from --machine)", machine)
    elif os.environ.get("ETL_VAULT_MACHINE"):
        log.info(
            "Runtime env: ETL_VAULT_MACHINE=%r (from pre-existing env)",
            os.environ["ETL_VAULT_MACHINE"],
        )

    token_method = getattr(args, "vault_token_method", None)
    if token_method:
        os.environ["ETL_VAULT_TOKEN_METHOD"] = token_method
        log.info(
            "Runtime env: ETL_VAULT_TOKEN_METHOD=%r (from --vault-token-method)",
            token_method,
        )
