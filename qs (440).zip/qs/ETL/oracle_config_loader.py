"""Shared Oracle credential loader.

2026-06-12 — same pattern as ``starburst_config_loader``:
ONE shared config file is the fallback for both the polling-service
metadata DB connection AND the per-job destination Oracle (used by
``light_starburst_base`` / ``starburst_base`` for Starburst→Oracle
ingest).

Resolution order (per-job destination Oracle credentials):
  1. Per-job JSON (``oracle_url`` / ``oracle_user`` / ``oracle_password``)
  2. Shared ``configs/oracle_config.yaml`` -> ``oracle.dest_connection_string``
  3. ``DEST_ORACLE_CONN`` environment variable (already honoured by
     ``polling_service.config.load_config``)

The connection-string format is the existing one used by the
standalones: ``user/password@host:port/service``.  ``parse_dest_dsn``
splits it into the three fields the per-job JSON uses
(``oracle_url`` / ``oracle_user`` / ``oracle_password``) so the per-job
JSON can drop those keys and inherit them from the shared file.
"""
from __future__ import annotations

import logging
import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


_PROD_PATH = "/usr/local/spark/pvc/code/configs/oracle_config.yaml"
_LOCAL_PATH = str(
    Path(__file__).resolve().parent / "configs" / "oracle_config.yaml"
)

_logger = logging.getLogger("oracle_config_loader")


def _load_yaml() -> Dict[str, Any]:
    for path in (_PROD_PATH, _LOCAL_PATH):
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}
            except yaml.YAMLError as exc:
                _logger.warning(
                    "oracle_config.yaml at %s is malformed (%s) — "
                    "ignoring file, falling back to DEST_ORACLE_CONN env var.",
                    path, exc,
                )
                return {}
            except OSError as exc:
                _logger.warning(
                    "Cannot read oracle_config.yaml at %s (%s) — "
                    "falling back to env vars.", path, exc,
                )
                return {}
    return {}


@lru_cache(maxsize=1)
def load_shared_oracle_config() -> Dict[str, Any]:
    """Cached parse of the ``oracle`` top-level section."""
    return _load_yaml().get("oracle", {}) or {}


def reset_cache() -> None:
    """Drop the cached parse (test hook)."""
    load_shared_oracle_config.cache_clear()


_OLEDB_KEY_PATTERN = (
    "user id", "uid", "username", "user", "password", "pwd", "data source",
)


def _looks_like_oledb(raw_s: str) -> bool:
    """Detect OLEDB / .NET-style Oracle connection strings.

    Triggers on:
      * Starts with ``(DESCRIPTION=`` or ``(DATA SOURCE=`` etc., AND
      * Contains at least one recognised key=value pair like
        ``User Id=`` / ``UID=`` / ``Password=`` / ``Pwd=`` /
        ``User=`` / ``Username=``.

    Case-insensitive matching.  Used to route the string to the OLEDB
    parser vs the Easy-Connect parser.
    """
    if not raw_s.lstrip().startswith("("):
        return False
    lower = raw_s.lower()
    return any(f"{k}" in lower and "=" in lower for k in _OLEDB_KEY_PATTERN)


def parse_oracle_connection_string(raw: str) -> Dict[str, str]:
    """Public parser for Oracle connection strings.

    Returns ``{"user", "password", "dsn"}`` where ``dsn`` is the
    bare DSN (no ``jdbc:oracle:thin:@`` prefix).  Suitable for
    ``oracledb.connect(user=..., password=..., dsn=...)``.

    See :func:`parse_dest_dsn` for the JDBC-URL-wrapping variant used
    by Spark code paths.

    Accepts both Easy Connect / DSN form
    (``user/pwd@host:port/svc``) AND OLEDB form
    (``(DESCRIPTION=...); User Id = u; Password = p``).

    Returns empty strings on any parse failure.  Never logs the raw
    string (which may contain a plaintext password).
    """
    out = {"user": "", "password": "", "dsn": ""}
    if not raw:
        return out
    raw_s = str(raw).strip()
    if not raw_s:
        return out

    if _looks_like_oledb(raw_s):
        user, password, tns_part = _parse_oledb_connection_string(raw_s)
        if user and tns_part:
            out["user"] = user
            out["password"] = password
            out["dsn"] = tns_part
        return out

    try:
        user, rest = raw_s.split("/", 1)
        password, dsn_part = rest.split("@", 1)
        out["user"] = user.strip()
        out["password"] = password.strip()
        out["dsn"] = dsn_part.strip()
    except ValueError:
        pass
    return out


def parse_dest_dsn(dsn: str) -> Dict[str, str]:
    """Parse an Oracle connection string into the three fields the
    per-job JSON consumes: ``{"oracle_user", "oracle_password", "oracle_url"}``.

    Accepts TWO formats:

    1. **Easy Connect / DSN form** -- the python-oracledb native shape:

           user/password@host:port/service
           user/password@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=h)(PORT=p))(CONNECT_DATA=(SERVICE_NAME=s)))

    2. **OLEDB / .NET form** -- semicolon-separated key=value pairs, with
       the TNS descriptor as the data source and ``User Id`` / ``Password``
       as separate fields:

           (DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=h)(PORT=p))(CONNECT_DATA=(SERVICE_NAME=s)));
           User Id = test_dev; Password = sdfsdfsd f;

       (This is the canonical shape in the user's production
       ``etl_connection_string`` -- ETL n other steps work this way.)

    The Spark JDBC URL form (``oracle_url``) is built in code by
    prepending ``jdbc:oracle:thin:@`` to the DSN (host:port/service OR
    the full TNS descriptor).  Non-Spark consumers extract user +
    password + dsn from the same parse result.

    Returns empty strings on any parse failure -- the caller's
    missing-field check then fires with a clear message.
    """
    out = {"oracle_user": "", "oracle_password": "", "oracle_url": ""}
    if not dsn:
        return out
    raw = str(dsn).strip()
    if not raw:
        return out

    # Format 2 detection: starts with a TNS descriptor "(DESCRIPTION="
    # OR contains the OLEDB key markers "User Id" / "Password".
    is_oledb = raw.lstrip().startswith("(") and (
        "User Id" in raw or "user id" in raw.lower()
    )

    if _looks_like_oledb(raw):
        user, password, tns_part = _parse_oledb_connection_string(raw)
        if user and tns_part:
            out["oracle_user"] = user
            out["oracle_password"] = password
            out["oracle_url"] = f"jdbc:oracle:thin:@{tns_part}"
            return out
        # Don't echo the string -- it likely contains a password.
        _logger.warning(
            "oracle connection string looks like OLEDB but missing User "
            "Id / data source -- leaving fields empty (raw NOT logged)"
        )
        return out

    # Format 1: user/password@dsn (dsn = host:port/svc OR TNS descriptor).
    try:
        user, rest = raw.split("/", 1)
        password, dsn_part = rest.split("@", 1)
        out["oracle_user"] = user.strip()
        out["oracle_password"] = password.strip()
        out["oracle_url"] = f"jdbc:oracle:thin:@{dsn_part.strip()}"
    except ValueError:
        # Never log the raw string -- if it parsed at all, the
        # password would be visible.  Log only that we couldn't parse.
        _logger.warning(
            "oracle connection string is neither OLEDB nor the "
            "'user/password@host:port/service' shape (length=%d, "
            "starts with %r) -- leaving fields empty",
            len(raw), raw[:8],
        )
    return out


import re as _re


# Match ``key = value`` chunks where ``key`` is one of the recognised
# OLEDB key names.  Stops at ``;`` followed by another recognised key
# (so passwords containing ``;`` are NOT truncated mid-value).
_OLEDB_KV_RE = _re.compile(
    r"(?P<key>User\s*Id|UID|Username|User|Password|Pwd|Data\s*Source)"
    r"\s*=\s*"
    r"(?P<val>.*?)"
    r"(?=\s*;\s*(?:User\s*Id|UID|Username|User|Password|Pwd|Data\s*Source)\s*=|\s*;?\s*$)",
    _re.IGNORECASE | _re.DOTALL,
)


def _strip_quotes(s: str) -> str:
    """Strip a single matched pair of surrounding single or double
    quotes (the OLEDB convention for values containing ``;`` or ``=``).
    """
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ("'", '"'):
        return s[1:-1]
    return s


def _parse_oledb_connection_string(raw: str) -> tuple:
    """Parse the OLEDB / .NET-style Oracle connection string.

    Shape:
        (DESCRIPTION=(ADDRESS=...)(CONNECT_DATA=...)); User Id = u; Password = p;

    The data source is the bracket-balanced ``(DESCRIPTION=...)`` block
    at the head of the string; the rest is a list of ``Key = Value``
    pairs.

    Hardened against several real-world edge cases:
      * Password contains ``;`` -- regex lookahead prevents mid-value
        truncation.  (Pre-fix: ``Password = pa;ss;`` returned ``pa``.)
      * Quoted values: ``Password = "se;cret"`` strips surrounding
        single OR double quotes.
      * Case variation: ``UID`` / ``uid`` / ``USER ID`` / ``Username``
        all accepted as user-key aliases; ``Pwd`` as password alias.
      * Embedded newlines (yaml block scalar style) inside the TNS
        descriptor.  Whitespace is squeezed inside the descriptor.

    Returns ``(user, password, tns_descriptor)`` -- empty strings when
    a field can't be extracted.
    """
    raw = raw.strip()
    # Walk parens to find the end of the leading TNS descriptor.
    depth = 0
    end_idx = -1
    for i, ch in enumerate(raw):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                end_idx = i
                break
    if end_idx < 0:
        return "", "", ""
    tns_descriptor = raw[: end_idx + 1].strip()
    # Strip whitespace inside the descriptor for JDBC tolerance.
    tns_descriptor = "".join(tns_descriptor.split())
    rest = raw[end_idx + 1 :]

    user = password = ""
    for match in _OLEDB_KV_RE.finditer(rest):
        key_norm = match.group("key").lower().replace(" ", "")
        val = _strip_quotes(match.group("val").strip())
        if key_norm in ("userid", "uid", "user", "username"):
            user = val
        elif key_norm in ("password", "pwd"):
            password = val
    return user, password, tns_descriptor


def _dsn_host_part(section: Dict[str, Any]) -> str:
    """Return the DSN half of an Oracle connection string -- the part
    after the ``user/password@``.

    Two shapes accepted in the structured config section:

      1. ``dsn:`` -- full TNS descriptor.  Wins when set.  Whitespace
         is squeezed for JDBC tolerance.

      2. ``host`` + ``port`` + ``service`` -- composed into Easy
         Connect form ``host:port/service``.  Used when ``dsn:`` is
         blank.

    Returns ``""`` when neither path yields a usable DSN -- caller
    falls through to the next resolution layer.
    """
    if not isinstance(section, dict):
        return ""

    # Path 1: full TNS descriptor.
    dsn_raw = (section.get("dsn") or "").strip()
    if dsn_raw:
        if dsn_raw.lstrip().startswith("("):
            return "".join(dsn_raw.split())  # squeeze whitespace
        return dsn_raw  # bare host:port/service typed under dsn:

    # Path 2: host + port + service compose.
    host = (section.get("host") or "").strip()
    service = (section.get("service") or "").strip()
    if not host or not service:
        return ""
    try:
        port_num = int(section.get("port")) if section.get("port") else 1521
    except (TypeError, ValueError):
        port_num = 1521
    return f"{host}:{port_num}/{service}"


def _resolve_db_vault_or_raise(
    label: str,
    secret_ref: str,
    workflow_cfg: Dict[str, Any],
):
    """Single chokepoint for Oracle vault fetches with loud-fail
    semantics.  Reuses the same QSClient + cache layer the rest of
    the codebase consumes, but converts the silent fall-through into
    an actionable RuntimeError when ``secret_ref`` is intentionally set.

    Returns ``(user, password, tns_alias)`` on success.  Raises
    RuntimeError with a diagnostic checklist on any of:
      * qs_credentials module not importable
      * vault toggle disabled (env / per-workflow / global yaml)
      * QSClient / vault fetch failure (server, token, secret missing)
    """
    try:
        from qs_credentials import (
            resolve_db_account_with_tns,
            is_vault_enabled,
        )
    except ImportError as exc:
        raise RuntimeError(
            f"{label}: secret_ref={secret_ref!r} set in oracle_config.yaml "
            f"but qs_credentials module not importable ({exc}).  Either "
            f"install qs_credentials on this pod, OR blank 'secret_ref' "
            f"and use literal connection_string / structured "
            f"username+password (DEV) or env vars."
        ) from exc

    if not is_vault_enabled(workflow_cfg):
        raise RuntimeError(
            f"{label}: secret_ref={secret_ref!r} set but vault resolution "
            f"is DISABLED.  Enable ONE of:\n"
            f"  1. ETL_USE_VAULT=1 env var on this pod, OR\n"
            f"  2. oracle.vault_enabled: \"true\" in oracle_config.yaml, OR\n"
            f"  3. secrets.enabled: true in vault_config.yaml.\n"
            f"For dev: blank 'secret_ref' and use literal connection "
            f"string instead."
        )

    try:
        return resolve_db_account_with_tns(secret_ref, workflow_config=workflow_cfg)
    except (RuntimeError, ValueError) as exc:
        raise RuntimeError(
            f"{label}: VAULT FETCH FAILED for secret_ref={secret_ref!r}.  "
            f"Underlying QSClient/cache error: {exc}\nCheck:\n"
            f"  * configs/vault_config.yaml -> secrets.refs.{secret_ref} "
            f"has type / auth_url / role_name / secret_url filled\n"
            f"  * pod has machine-token mounted (default "
            f"/var/run/secrets/token/vault-token)\n"
            f"  * vault server reachable from pod (auth_url + secret_url)\n"
            f"  * the secret payload at vault has both user + password fields\n"
            f"Workaround: blank secret_ref + use literal connection_string "
            f"OR ETL_ORACLE_CONN / DEST_ORACLE_CONN env vars."
        ) from exc


def _connection_string_from_section(section: Dict[str, Any]) -> str:
    """Build a ``user/password@host:port/service`` connection string
    from a structured section (etl: or destination:) of oracle_config.yaml.

    Returns ``""`` when username + password + host + service are not
    jointly set -- caller falls through to the next resolution layer.
    """
    if not isinstance(section, dict):
        return ""
    username = (section.get("username") or "").strip()
    password = (section.get("password") or "").strip()
    if not username or not password:
        return ""
    host_part = _dsn_host_part(section)
    if not host_part:
        return ""
    return f"{username}/{password}@{host_part}"


def shared_dest_oracle_creds() -> Dict[str, str]:
    """Resolve destination Oracle credentials from the shared config.

    Returns ``{"oracle_user", "oracle_password", "oracle_url"}`` — keys
    match the per-job JSON fields exactly so the caller can do a
    setdefault-style merge.

    Spark JDBC sites consume the ``oracle_url`` form
    (``jdbc:oracle:thin:@host:port/service``).  Non-Spark sites (cx_Oracle
    / python-oracledb) prefer the bare DSN, which is recoverable by
    stripping ``jdbc:oracle:thin:@`` -- but the convention everywhere in
    this codebase is to consume ``oracle_url`` and use the DSN-style
    parts via ``parse_dest_dsn``.

    Resolution (highest priority wins):
      1. ``oracle.dest_connection_string`` literal compact DSN.
      2. ``oracle.destination`` STRUCTURED form (host/port/service +
         username/password).  2026-06-26.
      3. ``oracle.destination.secret_ref`` (vault) -- creds from vault,
         host:port/service from the structured ``destination`` block.
      4. ``DEST_ORACLE_CONN`` env var.
    """
    cfg = load_shared_oracle_config()

    # Layer 1: literal compact DSN.
    dsn = cfg.get("dest_connection_string") or ""
    if dsn:
        return parse_dest_dsn(str(dsn).strip())

    # Layer 2: structured form -- compose DSN from parts.
    dest = cfg.get("destination", {}) or {}
    structured_dsn = _connection_string_from_section(dest)
    if structured_dsn:
        return parse_dest_dsn(structured_dsn)

    # Layer 3: vault via secret_ref + structured host:port/service.
    # Loud-fail when vault is the chosen path (operator set secret_ref).
    secret_ref = (dest.get("secret_ref") or "").strip()
    if secret_ref:
        user, password, tns_alias = _resolve_db_vault_or_raise(
            "Oracle destination DB", secret_ref, cfg,
        )
        host_part = _dsn_host_part(dest) or (tns_alias or "").strip()
        if not host_part:
            raise RuntimeError(
                f"Oracle destination DB: vault returned creds but no "
                f"host/port/service is configured in "
                f"oracle.destination.dsn or .host/.port/.service.  "
                f"Fill the endpoint info in oracle_config.yaml."
            )
        return {
            "oracle_user":     str(user),
            "oracle_password": str(password),
            "oracle_url":      f"jdbc:oracle:thin:@{host_part}",
        }

    # Layer 4: env-var fallback.
    dsn = os.environ.get("DEST_ORACLE_CONN") or ""
    return parse_dest_dsn(str(dsn).strip())


def shared_etl_oracle_creds() -> Dict[str, str]:
    """Resolve ETL metadata Oracle DB credentials (the polling-task DB
    every standalone + polling service writes run_id status to).

    Returns ``{"oracle_user", "oracle_password", "oracle_url"}``.

    Resolution (highest priority wins):
      1. ``oracle.etl_connection_string`` literal compact DSN.
      2. ``oracle.etl`` STRUCTURED form (host/port/service +
         username/password).  2026-06-26.
      3. ``oracle.etl.secret_ref`` (vault) -- creds from vault,
         host:port/service from the structured ``etl`` block.
      4. ``ETL_ORACLE_CONN`` env var.
    """
    cfg = load_shared_oracle_config()

    # Layer 1: literal compact DSN.
    dsn = cfg.get("etl_connection_string") or ""
    if dsn:
        return parse_dest_dsn(str(dsn).strip())

    # Layer 2: structured form.
    etl = cfg.get("etl", {}) or {}
    structured_dsn = _connection_string_from_section(etl)
    if structured_dsn:
        return parse_dest_dsn(structured_dsn)

    # Layer 3: vault via secret_ref + structured host:port/service.
    # Loud-fail when vault is the chosen path.
    secret_ref = (etl.get("secret_ref") or "").strip()
    if secret_ref:
        user, password, tns_alias = _resolve_db_vault_or_raise(
            "Oracle ETL metadata DB", secret_ref, cfg,
        )
        host_part = _dsn_host_part(etl) or (tns_alias or "").strip()
        if not host_part:
            raise RuntimeError(
                f"Oracle ETL metadata DB: vault returned creds but no "
                f"host/port/service is configured in oracle.etl.dsn "
                f"or .host/.port/.service.  Fill the endpoint info in "
                f"oracle_config.yaml."
            )
        return {
            "oracle_user":     str(user),
            "oracle_password": str(password),
            "oracle_url":      f"jdbc:oracle:thin:@{host_part}",
        }

    # Layer 4: env-var fallback.
    dsn = os.environ.get("ETL_ORACLE_CONN") or ""
    return parse_dest_dsn(str(dsn).strip())


def resolve_etl_connection_string(config: Dict[str, Any]) -> str:
    """Return the ETL Oracle connection string for use by standalones.

    Resolution order (highest priority wins):
      1. ``oracle.etl_connection_string`` -- literal one-liner DSN
         (simplest path, DEV-friendly).
      2. ``oracle.etl`` STRUCTURED form (host + port + service +
         username + password).  2026-06-26 added to mirror
         starburst_config.yaml shape.
      3. ``oracle.etl.secret_ref`` via Vault -- creds from vault,
         host:port/service from the structured ``etl`` block.
      4. ``ETL_ORACLE_CONN`` env var.

    Returns ``"user/password@host:port/service"`` format (the DSN shape
    every standalone understands).  Empty string when nothing resolves
    -- caller should fail loud.

    Args:
      config: full oracle_config.yaml content (the ``{"oracle": {...}}``
        dict the standalones already load).  Used so callers don't
        re-parse the file -- just pass what they already have.
    """
    oracle = (config or {}).get("oracle", {}) or {}
    etl = oracle.get("etl", {}) or {}

    # Layer 1: literal compact DSN -- the one-liner path.
    dsn = (oracle.get("etl_connection_string") or "").strip()
    if dsn:
        return dsn

    # Layer 2: structured form -- host + port + service + username + password.
    structured = _connection_string_from_section(etl)
    if structured:
        return structured

    # Layer 3: vault via secret_ref + structured host:port/service.
    # Loud-fail when vault is the chosen path.
    secret_ref = (etl.get("secret_ref") or "").strip()
    if secret_ref:
        user, password, tns_alias = _resolve_db_vault_or_raise(
            "Oracle ETL metadata DB", secret_ref, oracle,
        )
        # Prefer the structured host:port/service; fall back to the
        # legacy ``dsn_host`` field then the vault-resolved tns_alias.
        host_part = _dsn_host_part(etl) \
            or (etl.get("dsn_host") or "").strip() \
            or (tns_alias or "").strip()
        if not host_part:
            raise RuntimeError(
                f"Oracle ETL metadata DB: vault returned creds for "
                f"secret_ref={secret_ref!r} but no host/port/service "
                f"is configured in oracle.etl.dsn or .host/.port/.service.  "
                f"Fill the endpoint info in oracle_config.yaml."
            )
        _logger.info(
            "ETL Oracle: fetched schema creds from VAULT "
            "(secret_ref=%r, user=%r, host=%r) via QSClient",
            secret_ref, user, host_part,
        )
        return f"{user}/{password}@{host_part}"

    # Layer 4: env-var fallback.
    env_dsn = (os.environ.get("ETL_ORACLE_CONN") or "").strip()
    return env_dsn


def resolve_dest_connection_string(config: Dict[str, Any]) -> str:
    """Destination Oracle equivalent of ``resolve_etl_connection_string``.

    Resolution order (highest priority wins):
      1. ``oracle.dest_connection_string`` -- literal one-liner DSN.
      2. ``oracle.destination`` STRUCTURED form.
      3. ``oracle.destination.secret_ref`` via Vault.
      4. ``DEST_ORACLE_CONN`` env var.
    """
    oracle = (config or {}).get("oracle", {}) or {}
    dest = oracle.get("destination", {}) or {}

    dsn = (oracle.get("dest_connection_string") or "").strip()
    if dsn:
        return dsn

    structured = _connection_string_from_section(dest)
    if structured:
        return structured

    # Layer 3: vault via secret_ref + structured host:port/service.
    # Loud-fail when vault is the chosen path.
    secret_ref = (dest.get("secret_ref") or "").strip()
    if secret_ref:
        user, password, tns_alias = _resolve_db_vault_or_raise(
            "Oracle destination DB", secret_ref, oracle,
        )
        host_part = _dsn_host_part(dest) \
            or (dest.get("dsn_host") or "").strip() \
            or (tns_alias or "").strip()
        if not host_part:
            raise RuntimeError(
                f"Oracle destination DB: vault returned creds for "
                f"secret_ref={secret_ref!r} but no host/port/service "
                f"is configured in oracle.destination.dsn or "
                f".host/.port/.service.  Fill the endpoint info in "
                f"oracle_config.yaml."
            )
        _logger.info(
            "Dest Oracle: fetched schema creds from VAULT "
            "(secret_ref=%r, user=%r, host=%r) via QSClient",
            secret_ref, user, host_part,
        )
        return f"{user}/{password}@{host_part}"

    return (os.environ.get("DEST_ORACLE_CONN") or "").strip()


def merge_shared_into_job_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """In-place merge of the shared destination Oracle creds into a
    per-job JSON config.  Per-job JSON wins; this only fills blanks.

    Used by ``light_starburst_base`` AND ``starburst_base`` so the
    per-job JSON can drop ``oracle_user`` / ``oracle_password`` /
    ``oracle_url`` and inherit them from the shared config.

    2026-06-26 -- catch narrowed from ``except Exception`` to filesystem
    errors only.  Vault RuntimeError / ValueError from the loud-fail
    wiring (commit e5a8201) MUST propagate so the operator sees the
    actionable diagnostic instead of silently proceeding with blanks
    that fail downstream.
    """
    try:
        shared = shared_dest_oracle_creds()
    except (FileNotFoundError, OSError):
        # Loader yaml truly absent (older deployment image) -- proceed
        # with per-job JSON only.
        return config
    for key in ("oracle_user", "oracle_password", "oracle_url"):
        if shared.get(key) and not config.get(key):
            config[key] = shared[key]
    return config
