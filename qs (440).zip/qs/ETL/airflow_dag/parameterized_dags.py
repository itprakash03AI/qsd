"""
Phase 131-A (v2): Parameterized DAGs — 3 entity trigger DAGs + 1 batch dispatcher.

Entity Trigger DAGs (3):
  Triggered by Kafka/API with entity_dag_id in dag_run.conf.
  Resolves entity config from Oracle (ONE entity lookup).
  Launches a SINGLE SparkSubmitOperator → oracle_standalone.py.
  oracle_standalone.py handles everything: polls tasks, runs steps in SEQ order.

Batch Dispatcher DAG (1):
  Scheduled or manual trigger for a full fact table run.
  Fetches ALL entities from Oracle, triggers individual entity DAG runs.
  This is where Dynamic Task Mapping is used (correctly — one run per entity).

Requires Airflow 2.3+ for Dynamic Task Mapping (.expand()) in batch dispatcher.
"""
import os
import re
import logging
from typing import List, Dict

import yaml
import oracledb
from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.operators.python import PythonOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.models.param import Param
from airflow.models import Variable
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# ── Config paths ─────────��───────────────────────────���────────────────────
FACT_TABLES_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "..", "config", "fact_tables.yaml"
)


def _load_fact_tables() -> dict:
    """Load static fact table definitions from YAML (no Oracle needed)."""
    with open(FACT_TABLES_PATH, "r") as f:
        return yaml.safe_load(f)


def _parse_oracle_connection_string(conn_str: str):
    """Parse Oracle connection string via the canonical ETL parser.

    2026-07-01 (operator report) -- was a strict regex requiring exact
    ``'DSN; User Id = X;Password =Y;'`` shape with hair-thin whitespace
    rules; the canonical ``oracle_config_loader.parse_oracle_connection_string``
    handles OLEDB + Easy Connect + any whitespace tolerantly.
    """
    import sys as _sys
    _PVC_CODE_ROOT = "/usr/local/spark/pvc/code"
    if _PVC_CODE_ROOT not in _sys.path:
        _sys.path.insert(0, _PVC_CODE_ROOT)
    from oracle_config_loader import parse_oracle_connection_string as _canonical
    parsed = _canonical(conn_str)
    dsn = (parsed.get("dsn") or "").strip()
    user = (parsed.get("user") or "").strip()
    password = (parsed.get("password") or "").strip()
    if not dsn or not user or not password:
        raise ValueError(
            f"Oracle connection string parsed incomplete "
            f"(dsn={bool(dsn)} user={bool(user)} password={bool(password)}).  "
            f"Check oracle_config.yaml -> oracle.etl_connection_string."
        )
    return dsn, user, password


def _load_db_config(yaml_file: str):
    """Load Oracle credentials via the canonical resolver.

    2026-07-01 (operator report) -- was reading raw yaml which crashed
    for dev DBs not on vault AND crashed in prod when creds are vault-
    filled with placeholders in yaml.  ``resolve_etl_connection_string``
    handles the 4-layer priority:
      1. literal ``oracle.etl_connection_string``
      2. structured ``oracle.etl.{host,port,service,username,password}``
      3. vault via ``oracle.etl.secret_ref`` (if set)
      4. ``ETL_ORACLE_CONN`` env var fallback
    Dev + prod both work with the SAME code -- differ only in which yaml
    layer is populated.
    """
    import sys as _sys
    _PVC_CODE_ROOT = "/usr/local/spark/pvc/code"
    if _PVC_CODE_ROOT not in _sys.path:
        _sys.path.insert(0, _PVC_CODE_ROOT)
    from oracle_config_loader import resolve_etl_connection_string
    with open(yaml_file, "r") as f:
        config = yaml.safe_load(f)
    conn_str = resolve_etl_connection_string(config)
    if not conn_str:
        raise ValueError(
            f"Oracle ETL connection string could not be resolved from "
            f"{yaml_file}.  Fill one of: "
            f"oracle.etl_connection_string (literal), "
            f"oracle.etl.{{host,port,service,username,password}} (structured), "
            f"oracle.etl.secret_ref (vault), or "
            f"ETL_ORACLE_CONN env var."
        )
    return _parse_oracle_connection_string(conn_str)


def _get_spark_confs(spark_conf_path: str, delimiter: str = ':::') -> Dict[str, str]:
    """Load Spark properties from file with ::: delimiter."""
    spark_conf = {
        'spark.kubernetes.driverEnv.SPARK_DIST_CLASSPATH': '/usr/local/spark/pvc/jars/*',
        'spark.kubernetes.executorEnv.SPARK_DIST_CLASSPATH': '/usr/local/spark/pvc/jars/*',
        'spark.kubernetes.driverEnv.PYTHONPATH': '/usr/local/spark/pvc:/usr/local/spark/pvc/code',
        'spark.kubernetes.executorEnv.PYTHONPATH': '/usr/local/spark/pvc:/usr/local/spark/pvc/code',
    }
    try:
        with open(spark_conf_path) as f:
            for line in f:
                line = line.strip()
                if line and delimiter in line:
                    key, value = line.split(delimiter, 1)
                    key, value = key.strip(), value.strip()
                    if key not in spark_conf:
                        spark_conf[key] = value
    except Exception as e:
        logger.error(f"Error reading spark properties from {spark_conf_path}: {e}")
    return spark_conf


# ═══════════════════════════════════════════════════════════════════════════
#  Resolve entity config — called at RUNTIME by PythonOperator
# ═══════════��══════════════════════════════��════════════════════════════════

def _resolve_entity_config(report_id: int, **context) -> Dict:
    """
    RUNTIME task: Resolve config for ONE entity from Oracle.

    Reads entity_dag_id from dag_run.conf (set by Kafka/API trigger).
    Queries VW_OTG_DAG_Gen_CONFIG for that specific entity's config.
    Pushes application_path, application_args, spark_conf to XCom
    so SparkSubmitOperator can use them.
    """
    dag_run_conf = context.get("dag_run").conf or {}
    entity_dag_id = dag_run_conf.get("entity_dag_id", "")

    if not entity_dag_id:
        raise ValueError(
            "entity_dag_id is required in dag_run.conf. "
            "Kafka/API trigger must provide conf={'entity_dag_id': '...'}. "
            "For batch runs, use the otg_batch_dispatcher DAG instead."
        )

    fact_config = _load_fact_tables()
    db_config_path = fact_config.get("db_config_path", "/usr/local/spark/pvc/code/db.yaml")
    dsn, user, password = _load_db_config(db_config_path)

    params = context.get("params", {})
    business_date = dag_run_conf.get(
        "business_date",
        params.get("business_date", Variable.get("default_business_date", "14-07-2025"))
    )
    business_event = dag_run_conf.get(
        "business_event",
        params.get("business_event", "SOD")
    )

    try:
        with oracledb.connect(user=user, password=password, dsn=dsn) as conn:
            with conn.cursor() as cursor:
                query = """
                    SELECT DISTINCT DAG_ID, FK_REPORT_ID, EXECUTABLE_FILE,
                        CONFIG_PATH, SPARK_PROPERTY, DAG_TYPE, SUPPORT_EMAIL_ID
                    FROM VW_OTG_DAG_Gen_CONFIG
                    WHERE DAG_ID = :entity_dag_id AND FK_REPORT_ID = :report_id
                """
                cursor.execute(query, {"entity_dag_id": entity_dag_id, "report_id": report_id})
                columns = [col[0].lower() for col in cursor.description]
                row = cursor.fetchone()

                if not row:
                    raise ValueError(
                        f"Entity '{entity_dag_id}' not found in VW_OTG_DAG_Gen_CONFIG "
                        f"for report_id={report_id}"
                    )

                row_dict = dict(zip(columns, row))
    except oracledb.Error as e:
        logger.error(f"Oracle error resolving entity {entity_dag_id}: {e}")
        raise

    # Build dag_id with optional finance suffix (report_id 76/77)
    resolved_dag_id = entity_dag_id
    if report_id == 76 and business_event in ("SOD", "EOD", "INTRADAY"):
        resolved_dag_id = f"{entity_dag_id}_finance_sl_balance_{business_event}"
    elif report_id == 77 and business_event in ("SOD", "EOD", "INTRADAY"):
        resolved_dag_id = f"{entity_dag_id}_finance_sl_balance_ext_{business_event}"

    # Build application args — same as oracle_standalone.py expects
    config_path = dag_run_conf.get("config_path", row_dict.get("config_path", ""))
    app_args = [
        '--report_id', str(report_id),
        '--business_date', business_date,
        '--dag_id', resolved_dag_id,
        '--config_path', config_path,
    ]

    # Load spark conf from properties file
    spark_conf_path = dag_run_conf.get(
        "spark_conf_path",
        row_dict.get("spark_property", fact_config.get("spark_conf_path_default", ""))
    )
    spark_conf = _get_spark_confs(spark_conf_path) if spark_conf_path else {}

    application_path = dag_run_conf.get(
        "application_path",
        row_dict.get("executable_file", fact_config.get("application_path_default", ""))
    )

    # Push to XCom for SparkSubmitOperator
    ti = context["ti"]
    ti.xcom_push(key="application_path", value=application_path)
    ti.xcom_push(key="application_args", value=app_args)
    ti.xcom_push(key="spark_conf", value=spark_conf)

    logger.info(
        f"Resolved entity config: entity_dag_id={entity_dag_id}, "
        f"resolved_dag_id={resolved_dag_id}, application={application_path}"
    )
    return {"entity_dag_id": entity_dag_id, "resolved_dag_id": resolved_dag_id}


# ══════���══════════════════════���═════════════════════════════════════════════
#  Batch: Fetch ALL entities for a report_id (used by batch dispatcher)
# ═════════════��══════════════════════════════���══════════════════════════════

def _fetch_all_entities(report_id: int, **context) -> List[Dict]:
    """
    Fetch ALL system entities for a report_id from Oracle.
    Returns list of trigger configs for TriggerDagRunOperator.
    """
    fact_config = _load_fact_tables()
    db_config_path = fact_config.get("db_config_path", "/usr/local/spark/pvc/code/db.yaml")
    dsn, user, password = _load_db_config(db_config_path)

    params = context.get("params", {})
    business_date = params.get(
        "business_date", Variable.get("default_business_date", "14-07-2025")
    )
    business_event = params.get("business_event", "SOD")

    entities = []
    try:
        with oracledb.connect(user=user, password=password, dsn=dsn) as conn:
            with conn.cursor() as cursor:
                query = """
                    SELECT DISTINCT DAG_ID, FK_REPORT_ID
                    FROM VW_OTG_DAG_Gen_CONFIG
                    WHERE FK_REPORT_ID = :report_id
                """
                cursor.execute(query, {"report_id": report_id})
                columns = [col[0].lower() for col in cursor.description]
                for row in cursor:
                    row_dict = dict(zip(columns, row))
                    dag_id = row_dict.get("dag_id")
                    if not dag_id:
                        continue

                    # Each entity becomes a separate DAG run
                    entities.append({
                        "entity_dag_id": dag_id,
                        "business_date": business_date,
                        "business_event": business_event,
                    })

        logger.info(f"Fetched {len(entities)} entities for report_id={report_id}")
    except Exception as e:
        logger.error(f"Error fetching entities for report_id={report_id}: {e}")
        raise

    return entities


def _get_default_args(email: str) -> Dict:
    """Default DAG arguments."""
    return {
        'owner': Variable.get("dag_owner", default_var="Output Gateway"),
        'depends_on_past': False,
        'start_date': datetime(2025, 7, 14),
        'retries': 0,
        'retry_delay': timedelta(minutes=5),
        'email_on_failure': True,
        'email': [e.strip() for e in email.split(',')] if email else ['etl-support@company.com'],
    }


# ════════��════════════════════��═════════════════════════���═══════════════════
#  Entity Trigger DAGs — 3 static DAGs, one per fact table
#  Kafka/API triggers these with conf={"entity_dag_id": "...", ...}
#  Each run processes ONE entity → ONE Spark pod
# ════════���══════════════════════════════════════════════════════════════════

fact_config = _load_fact_tables()

for fact in fact_config.get("fact_tables", []):
    _dag_id = fact["dag_id"]
    _report_id = fact["report_id"]

    dag = DAG(
        dag_id=_dag_id,
        default_args=_get_default_args(fact.get("email", "")),
        description=fact.get("description", f"ETL for report {_report_id}"),
        schedule_interval=None,  # Event-driven only — triggered by Kafka/API/batch
        catchup=False,
        is_paused_upon_creation=True,
        tags=fact.get("tags", ["etl"]),
        params={
            'report_id': Param(
                _report_id,
                type='integer',
                description='Report ID to process',
            ),
            'business_event': Param(
                default='SOD',
                type='string',
                title='Business Event',
                description='Business event type',
                enum=['SOD', 'EOD', 'INTRADAY'],
                values_display={
                    'SOD': 'Start of Day',
                    'EOD': 'End of Day',
                    'INTRADAY': 'Intraday',
                },
            ),
            'business_date': Param(
                Variable.get("default_business_date", default_var="14-07-2025"),
                type='string',
                description='Business date to process (DD-MM-YYYY)',
            ),
        },
        render_template_as_native_obj=True,
    )

    # ── Task 1: Resolve entity config from Oracle ────────────────────────
    # Lightweight PythonOperator — runs in Airflow worker (no Spark pods).
    # Reads entity_dag_id from dag_run.conf → queries ONE row from Oracle.
    resolve_config = PythonOperator(
        task_id="resolve_entity_config",
        python_callable=_resolve_entity_config,
        op_kwargs={"report_id": _report_id},
        dag=dag,
    )

    # ── Task 2: Launch Spark with resolved config ─────────���──────────────
    # ONE SparkSubmitOperator per DAG run → ONE Spark driver + executor pod.
    # oracle_standalone.py handles everything: polls tasks, runs steps in SEQ.
    spark_task = SparkSubmitOperator(
        task_id=fact.get("dag_type", "createJob"),
        application="{{ ti.xcom_pull(task_ids='resolve_entity_config', key='application_path') }}",
        application_args="{{ ti.xcom_pull(task_ids='resolve_entity_config', key='application_args') }}",
        conf="{{ ti.xcom_pull(task_ids='resolve_entity_config', key='spark_conf') }}",
        conn_id=Variable.get("spark_conn_id", default_var="spark_on_prem"),
        dag=dag,
    )

    resolve_config >> spark_task

    # Register DAG in globals — Airflow discovers it
    globals()[_dag_id] = dag


# ═════════════��═════════════════════════════════════════════════════��═══════
#  Batch Dispatcher DAG — triggers individual entity runs
#  Scheduled or manual trigger. Fetches ALL entities for each fact table,
#  then triggers individual DAG runs via TriggerDagRunOperator.
# ════════���══════════════════��═══════════════════════════════��═══════════════

batch_dag = DAG(
    dag_id="otg_batch_dispatcher",
    default_args=_get_default_args("etl-support@company.com"),
    description="Batch dispatcher — triggers entity DAG runs for all entities",
    schedule_interval=Variable.get("batch_schedule", default_var="@daily"),
    catchup=False,
    is_paused_upon_creation=True,
    tags=["etl", "batch", "dispatcher"],
    params={
        'business_event': Param(
            default='SOD',
            type='string',
            title='Business Event',
            enum=['SOD', 'EOD', 'INTRADAY'],
        ),
        'business_date': Param(
            Variable.get("default_business_date", default_var="14-07-2025"),
            type='string',
            description='Business date to process',
        ),
    },
    render_template_as_native_obj=True,
)

for fact in fact_config.get("fact_tables", []):
    _fact_dag_id = fact["dag_id"]
    _fact_report_id = fact["report_id"]

    # Task: Fetch all entities for this fact table
    fetch_task = PythonOperator(
        task_id=f"fetch_entities_{_fact_report_id}",
        python_callable=_fetch_all_entities,
        op_kwargs={"report_id": _fact_report_id},
        dag=batch_dag,
    )

    # Task: Trigger individual DAG runs — Dynamic Task Mapping (correct here!)
    # Each entity gets its own DAG run → own Spark driver + executor pods
    trigger_task = TriggerDagRunOperator.partial(
        task_id=f"trigger_{_fact_dag_id}",
        trigger_dag_id=_fact_dag_id,
        wait_for_completion=False,
        dag=batch_dag,
    ).expand(
        conf=fetch_task.output,
    )

    fetch_task >> trigger_task

globals()["otg_batch_dispatcher"] = batch_dag

logger.info(
    f"Created {len(fact_config.get('fact_tables', []))} entity trigger DAGs "
    f"+ 1 batch dispatcher DAG"
)
