# Vault Pre-Warm DAG — Helm Deploy Sample (Phase 158 R11)

Drop-in Helm-values snippets + deploy ritual for the
`vault_credential_prewarm` DAG.  Tested against Airflow 2.7+ Helm
chart; adapt to your existing chart shape.

---

## 1. Airflow worker pod env vars

```yaml
# values.yaml (Airflow chart)
workers:
  env:
    # Master enable for vault resolution on the Airflow worker.
    - name: ETL_USE_VAULT
      value: "1"

    # Disk-cache Fernet key.  MUST be IDENTICAL across:
    #   * Airflow worker pod (this one)
    #   * Spark driver / executor pods
    #   * polling-service pods
    # Otherwise pod B can't decrypt what pod A wrote and the DAG's
    # round-trip verification will FAIL on the next prewarm run.
    - name: ETL_SECRETS_KEY
      valueFrom:
        secretKeyRef:
          name: qs-etl-secrets
          key: vault-cache-fernet-key

    # In-pod periodic refresh daemon is now redundant -- the DAG IS
    # the central refresh authority.  Worst case: a leftover daemon
    # could invalidate the disk cache out of phase with the DAG
    # schedule, causing brief Vault hits between the wipe and the
    # next DAG run.
    - name: ETL_CRED_REFRESH_HOURS
      value: "0"

  extraVolumes:
    - name: pvc-code
      persistentVolumeClaim:
        # Same PVC that Spark driver + polling-service mount.
        # qs_credentials/ + configs/vault_config.yaml + the cache
        # file all live here.
        claimName: qs-etl-shared-code

  extraVolumeMounts:
    - name: pvc-code
      mountPath: /usr/local/spark/pvc/code
      # Read-write -- the DAG writes to .cache/etl_secrets.enc here.
      readOnly: false
```

---

## 2. K8s Secret holding the Fernet key

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: qs-etl-secrets
  namespace: qs-etl
type: Opaque
stringData:
  # Generate ONCE per cluster:
  #   python -c "from cryptography.fernet import Fernet; \
  #              print(Fernet.generate_key().decode())"
  # Then rotate ONLY by:
  #   1. Updating this secret across ALL pods at the same time
  #      (helm upgrade with --recreate-pods).
  #   2. Run smoke_prewarm afterwards to confirm round-trip passes.
  vault-cache-fernet-key: "<44-char base64 fernet key>"
```

---

## 3. Vault config yaml (on the PVC)

```yaml
# /usr/local/spark/pvc/code/configs/vault_config.yaml
secrets:
  enabled: true       # global master toggle
  vault:
    machine:        "openshift"
    token_method:   "JWT"
    cache_ttl_seconds:      900      # in-process 15-min
    # MUST be true (the DAG refuses to run otherwise).
    disk_cache_enabled:     true
    disk_cache_path:        "/usr/local/spark/pvc/code/.cache/etl_secrets.enc"
    # 30 hours -- gives a buffer past the 24h DAG schedule so a
    # delayed run doesn't expire the cache.
    disk_cache_ttl_seconds: 108000
    disk_cache_key_env:     "ETL_SECRETS_KEY"
  refs:
    # ... your per-secret entries, one per service account / DB user.
```

---

## 4. Deploy ritual (DO NOT SKIP)

```bash
# 1. Generate the Fernet key (ONCE per cluster).
KEY=$(python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
kubectl create secret generic qs-etl-secrets \
    --from-literal=vault-cache-fernet-key="$KEY" \
    --namespace qs-etl

# 2. Deploy the chart.
helm upgrade qs-etl --values prod-values.yaml ./helm/qs-etl

# 3. Wait for the Airflow worker pod to come up.
kubectl wait --for=condition=ready pod -l app=airflow-worker -n qs-etl

# 4. SMOKE TEST -- this MUST pass before you enable real workflows.
#    It runs the same code path as the DAG, including the round-trip
#    Fernet decrypt verification that catches cross-pod key drift.
kubectl exec -it airflow-worker-0 -n qs-etl -- \
    python -m qs_credentials.smoke_prewarm

# Expected output (success):
#   [smoke] OK -- ok=N failed=0 skipped=M
#   [smoke] cache: path='/usr/local/spark/pvc/code/.cache/etl_secrets.enc' size=... mtime=...
#   [smoke] round-trip: checked=N readable=N not_readable=[]
#
# If it fails, fix the cause BEFORE enabling the DAG -- otherwise
# workflows will fail with confusing decrypt errors after the cache
# expires.

# 5. The DAG ships with is_paused_upon_creation=False so it's active
#    immediately on import.  Confirm it fired:
kubectl exec airflow-worker-0 -- airflow dags list-runs -d vault_credential_prewarm

# 6. (Optional) Run a workflow that consumes a secret; confirm it
#    reads from cache (no Vault call) by grepping the pod log for
#    "[vault] STEP" lines -- absence = cache hit (good).
```

---

## 5. Operational runbook

* **"Workflows are failing with decrypt errors"** → run smoke_prewarm
  with `--skip-round-trip` to confirm Vault is reachable, then
  CHECK that ETL_SECRETS_KEY matches across ALL pods (Airflow +
  Spark + polling-service).  The most common cause is a Helm
  values drift after a partial chart change.

* **"DAG hasn't fired since deploy"** → check is_paused_upon_creation;
  newer Airflow versions can override this via `dags_are_paused_at_creation`
  in airflow.cfg.  If paused, unpause via UI.

* **"Vault rotated my secret mid-window, workflows started failing"**
  → manually trigger the DAG from Airflow UI (or run smoke_prewarm
  to refresh + verify in one step).

* **"I need to change the schedule"** → set the Airflow Variable
  `vault_prewarm_schedule` to a new cron.  Default `0 2 * * *`.

* **"Vault is down, workflows are still running off cache"** → that's
  the design.  The disk cache TTL (108000s above = 30h) is your
  outage tolerance window.  The DAG will continue failing during
  the outage and emit alerts; workflows keep reading the still-
  valid cache.  Once Vault is back, manually trigger the DAG to
  refresh + start the 30h window again.

* **"I want to rotate the Fernet key"** → see "K8s Secret" section
  above.  Sequence MUST be atomic across all pods OR you'll hit
  decrypt failures.
