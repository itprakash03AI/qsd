"""SOD Oracle proc DAG -- manual trigger only.  Cache-first creds via
shared qs_credentials chokepoint; DSN from oracle_config.yaml."""
from __future__ import annotations

import logging
import sys
from datetime import datetime, timedelta
from typing import Any, Dict

import oracledb
import pendulum
import yaml
from airflow import DAG
from airflow.models import Variable
from airflow.models.param import Param
from airflow.operators.python import PythonOperator


# Both PVCs mount on the Airflow worker.  qs_credentials + configs
# stay on the SPARK PVC -- one source of truth shared with Spark
# workflows (so they hit the same warm cache the prewarm DAG writes).
_PVC_CODE_ROOT      = "/usr/local/spark/pvc/code"
_ORACLE_CONFIG_PATH = f"{_PVC_CODE_ROOT}/configs/oracle_config.yaml"
_DEFAULT_SECRET_REF = "etl_oracle_meta"
_PROC_NAME          = "PKG_AIRFLOW_DAG_RUN.SOD_RUN"

BST    = pendulum.timezone("Europe/London")
logger = logging.getLogger(__name__)


# PVC log setup via the SHARED chokepoint (qs_credentials/pvc_log.py).
if _PVC_CODE_ROOT not in sys.path:
    sys.path.insert(0, _PVC_CODE_ROOT)
try:
    from qs_credentials.pvc_log import setup_pvc_logging
    setup_pvc_logging("sod_daily")
except Exception as _pvc_log_exc:  # noqa: BLE001
    logger.warning(
        "PVC log handler not attached (%s) -- Airflow's own task "
        "log path still captures task output", _pvc_log_exc,
    )


def _parse_business_date(raw: str):
    if not raw:
        return (datetime.now() - timedelta(days=1)).date()
    try:
        return datetime.strptime(raw, "%d-%m-%Y").date()
    except ValueError as exc:
        raise ValueError(
            f"business_date={raw!r} is not DD-MM-YYYY "
            f"(e.g. '29-06-2026'): {exc}"
        ) from exc


def _read_dsn() -> str:
    try:
        with open(_ORACLE_CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}
    except FileNotFoundError as exc:
        raise RuntimeError(
            f"oracle_config.yaml missing at {_ORACLE_CONFIG_PATH}"
        ) from exc
    conn_str = ((cfg.get("oracle") or {})
                  .get("etl_connection_string") or "").strip()
    if not conn_str:
        raise RuntimeError(
            f"{_ORACLE_CONFIG_PATH} -> oracle.etl_connection_string "
            "is missing or empty."
        )
    # Same parser the rest of ETL uses -- handles Easy Connect AND OLEDB.
    from oracle_config_loader import parse_oracle_connection_string
    dsn = (parse_oracle_connection_string(conn_str).get("dsn") or "").strip()
    if not dsn:
        raise RuntimeError("Could not parse DSN from etl_connection_string.")
    return dsn


def call_sod_procedure(**kwargs) -> Dict[str, Any]:
    # qs_credentials lives on the shared PVC -- import inside the task
    # so the scheduler can parse this DAG without the PVC mounted.
    if _PVC_CODE_ROOT not in sys.path:
        sys.path.insert(0, _PVC_CODE_ROOT)
    from qs_credentials.resolver import resolve_with_auth_retry

    params         = kwargs.get("params", {}) or {}
    business_date  = _parse_business_date(
        (params.get("business_date") or "").strip()
    )
    dest_app_id    = params.get("dest_app_id")
    otg_dag_id     = params.get("otg_dag_id")
    secret_ref     = (params.get("secret_ref")
                       or _DEFAULT_SECRET_REF).strip()

    logger.info(
        "[sod] business_date=%s dest_app_id=%s otg_dag_id=%s secret_ref=%s",
        business_date, dest_app_id, otg_dag_id, secret_ref,
    )
    dsn = _read_dsn()

    def _connect_and_run(creds):
        user     = (creds[0] or "").strip()
        password = (creds[1] or "").strip()
        # Refuse to attempt the connect with blank creds -- an empty
        # password gives ORA-01005 ("null password given") which is
        # less actionable than catching the cause here.
        if not user or not password:
            raise RuntimeError(
                f"[sod] qs_credentials returned blank creds for "
                f"secret_ref={secret_ref!r}  (user_blank={not user}, "
                f"password_blank={not password}).  Likely Vault is "
                "mid-rotation or the role lacks read permission.  "
                "NOT attempting Oracle connect."
            )
        logger.info("[sod] connecting Oracle user=%r", user)
        conn = oracledb.connect(user=user, password=password, dsn=dsn)
        try:
            with conn.cursor() as cursor:
                logger.info(
                    "[sod] callproc %s [%s, %s, %s]",
                    _PROC_NAME, business_date, dest_app_id, otg_dag_id,
                )
                cursor.callproc(
                    _PROC_NAME,
                    [business_date, dest_app_id, otg_dag_id],
                )
                conn.commit()
            logger.info("[sod] committed business_date=%s", business_date)
        finally:
            conn.close()
        return {
            "execution_date": business_date.isoformat(),
            "dest_app_id":    dest_app_id,
            "otg_dag_id":     otg_dag_id,
            "secret_ref":     secret_ref,
        }

    # resolve_with_auth_retry owns: cache HIT (mem/disk) -> immediate;
    # cache MISS -> QSClient against Vault + write back; ORA-01017 ->
    # drop cache + re-fetch + retry once.
    return resolve_with_auth_retry(
        secret_ref, _connect_and_run, secret_type="DB_accounts",
    )


_EMAIL_LIST = [
    e.strip()
    for e in (Variable.get("sod_email_list", default_var="") or "").split(",")
    if e.strip()
]


default_args = {
    "owner":                     Variable.get(
        "dag_owner", default_var="Output Gateway",
    ),
    "depends_on_past":           False,
    "retries":                   2,
    "retry_delay":               timedelta(minutes=5),
    "retry_exponential_backoff": True,
    "max_retry_delay":           timedelta(minutes=30),
    # Only enable email if a recipient list is configured -- empty
    # list + email_on_failure=True throws SMTP errors that mask the
    # real failure.
    "email_on_failure":          bool(_EMAIL_LIST),
    "email_on_retry":            False,
    "email":                     _EMAIL_LIST,
    "execution_timeout":         timedelta(hours=2),
}


with DAG(
    dag_id="sod_daily_dag",
    description="On-demand SOD Oracle proc; manual trigger only.",
    default_args=default_args,
    schedule_interval=None,
    start_date=pendulum.datetime(2025, 11, 12, tz=BST),
    catchup=False,
    tags=["sod", "manual", "oracle"],
    max_active_runs=1,
    is_paused_upon_creation=False,
    params={
        "business_date": Param(
            default="", type="string",
            description="DD-MM-YYYY (blank = yesterday)",
        ),
        "dest_app_id": Param(default=None, type=["null", "integer"]),
        "otg_dag_id":  Param(default=None, type=["null", "string"]),
        "secret_ref":  Param(
            default=_DEFAULT_SECRET_REF, type="string",
            description="vault_config.yaml ref for the ETL DB creds",
        ),
    },
) as dag:

    run_sod_procedure = PythonOperator(
        task_id="run_sod_procedure",
        python_callable=call_sod_procedure,
    )
