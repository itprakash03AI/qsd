"""Vault Credential Pre-Warm DAG (Phase 158 R11 -- 2026-06-28)

WHY THIS DAG EXISTS
───────────────────
The QSClient + QSCredCache disk-cache architecture is already
sharing-friendly: every pod on the PVC reads from the same Fernet-
encrypted cache at ``/usr/local/spark/pvc/code/.cache/etl_secrets.enc``.
But the cache is populated LAZILY -- the first workflow that needs a
secret pays the 3-HTTP-call Vault tax (machine token + vault token +
read).  If that first run happens during a Vault outage, or if the
machine identity token has just rotated out, the workflow fails.

This DAG pre-warms the cache on a 24h schedule so every workflow run
reads from a hot cache.  Vault load is centralised (one DAG, not N
workflows), and Vault outages are invisible to downstream workflows
as long as the cache is fresh.

ARCHITECTURE
────────────
* PythonOperator runs in the Airflow worker pod -- no Spark needed.
* The Airflow worker pod mounts the same PVC at
  ``/usr/local/spark/pvc/code/`` that Spark drivers + ETL pods already
  see, so the cache file written here is read by every downstream pod.
* All logic lives in ``qs_credentials.prewarm`` (no Airflow deps) so
  the same chokepoint is exercised by tests, the smoke harness, and a
  future admin "refresh now" endpoint.

SCHEDULE
────────
Every 24h at 02:00 UTC by default (low-load window).  The 24h disk
cache TTL in ``vault_config.yaml`` should be set with a small buffer
(e.g., 26h or 30h) so the cache never expires between runs even if a
DAG run is delayed.  Override the schedule via Airflow Variable
``vault_prewarm_schedule`` -- a tighter cron (e.g. ``0 */12 * * *``)
is recommended in environments where Vault rotations are frequent.

OPERATOR NOTES
──────────────
* Set ``ETL_USE_VAULT=1`` on the Airflow worker pod (Helm chart) so
  the resolver actually fires.
* Set ``ETL_SECRETS_KEY`` Helm-wide so the disk-cache Fernet key
  matches across Airflow + Spark + polling-service pods (otherwise pod
  B can't decrypt what pod A wrote).
* Set ``ETL_CRED_REFRESH_HOURS=0`` on every consumer pod once this DAG
  is in place -- the in-pod periodic-refresh daemon becomes redundant
  and at worst would invalidate the disk cache out of phase with the
  DAG schedule.
* Soft-disable a ref without removing it from the yaml: rename it
  ``_disabled_<original_name>``.  Smoke / dev refs with blank
  ``auth_url`` are auto-skipped.

FAILURE MODES
─────────────
* Single ref Vault outage:        per-ref retry (3 attempts, 0/2/8s);
                                   then logged + continues; DAG SUCCEEDS.
* ALL refs fail (Vault down):     DAG FAILS LOUDLY -> Airflow alert.
* yaml malformed / missing:       DAG FAILS at parse time with the
                                   actionable error from prewarm.py.
* Disk cache write silently fails: Post-run verification catches the
                                   mismatch ("N OK refs but cache file
                                   wasn't updated") and raises.

OBSERVABILITY
─────────────
* Per-ref outcome in task logs (status, attempt count, wall time, shape).
* XCom ``summary`` dict with counts (ok / failed / skipped) +
  post-run cache file stats (size, mtime).  Downstream dashboards /
  alerts consume the XCom.
* Per-task SLA of 30 minutes -- ops gets paged if the DAG is queued
  longer than that (cache might then expire before the run completes).
"""
from __future__ import annotations

import logging
import sys
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator

# Shared PVC mount.  IMPORTANT: do NOT mutate sys.path at module load --
# that would shadow any same-named module other DAGs import + persist
# the change for the lifetime of the Airflow worker.  The task function
# below does the mutation in its OWN scope, which is fine because the
# task runs in a forked / spawned subprocess (PythonOperator).
# Both PVCs are mounted on the Airflow worker (per operator).  Keep
# qs_credentials + configs + cache on the SPARK PVC so the same cache
# file is read by both Airflow tasks AND Spark workflows -- one
# source of truth.  DAG files themselves still live on the Airflow
# PVC at /usr/local/airflow/pvc/dags/.
_PVC_CODE_ROOT = "/usr/local/spark/pvc/code"


logger = logging.getLogger(__name__)


# PVC log setup via the SHARED chokepoint (qs_credentials/pvc_log.py)
# -- a fix to rotation / de-dup / fallback policy lands in ONE place
# across every DAG that uses it.  sys.path is mutated here at module
# load (not the in-task pattern) because the helper must run BEFORE
# the task fires so DAG-parse log lines are captured too.
if _PVC_CODE_ROOT not in sys.path:
    sys.path.insert(0, _PVC_CODE_ROOT)
try:
    from qs_credentials.pvc_log import setup_pvc_logging
    setup_pvc_logging("vault_prewarm")
except Exception as _pvc_log_exc:  # noqa: BLE001
    logger.warning(
        "PVC log handler not attached (%s) -- Airflow's own task "
        "log path still captures task output", _pvc_log_exc,
    )


def _run_prewarm(**context) -> dict:
    """Airflow task wrapper -- delegates to the pure chokepoint and
    pushes the structured summary to XCom.

    Inserts the shared PVC code root into ``sys.path`` HERE (not at
    DAG module load) so the mutation is scoped to the task subprocess
    and can't pollute the long-running Airflow scheduler / worker.
    """
    # Local import after sys.path mutation -- the qs_credentials module
    # lives on the shared PVC, not in the Airflow worker image.
    if _PVC_CODE_ROOT not in sys.path:
        sys.path.insert(0, _PVC_CODE_ROOT)
    from qs_credentials.prewarm import prewarm_vault_cache  # noqa: WPS433

    # Use the chokepoint defaults (both target the spark PVC) -- single
    # source of truth shared with non-Airflow callers (smoke CLI, future
    # admin "refresh now" endpoint).
    summary = prewarm_vault_cache()
    # Surface the summary as the task return value -- Airflow stores
    # it under XCom key 'return_value' which downstream tasks consume.
    return summary


# Operator-tunable schedule via Airflow Variable.  Default every 24h
# at 02:00 UTC (low-load window).  When you change ``disk_cache_ttl_seconds``
# in vault_config.yaml, ensure schedule_interval stays inside that TTL
# with a buffer so a delayed DAG run never expires the cache.
_SCHEDULE = Variable.get(
    "vault_prewarm_schedule", default_var="0 2 * * *",
)


default_args = {
    "owner":            "etl-platform",
    "depends_on_past":  False,
    "email_on_failure": True,
    "email_on_retry":   False,
    "retries":          2,
    "retry_delay":      timedelta(minutes=5),
    "sla":              timedelta(minutes=30),
    "execution_timeout": timedelta(minutes=20),
}


with DAG(
    dag_id="vault_credential_prewarm",
    description=(
        "Pre-warm the shared Vault credential cache on PVC every 24h."
    ),
    default_args=default_args,
    schedule_interval=_SCHEDULE,
    # ``start_date`` 1 day in the past + ``catchup=False`` together mean
    # the scheduler fires the FIRST run immediately on deploy (within one
    # scheduler tick).  Without this, a freshly-deployed pod might serve
    # a workflow BEFORE the DAG's first scheduled run, paying the very
    # Vault tax this DAG exists to eliminate.  See HELM_SAMPLE.md for the
    # deploy runbook.
    start_date=datetime(2026, 6, 27),
    catchup=False,
    max_active_runs=1,
    # Active immediately on deploy -- operator does NOT need to unpause
    # in the UI for the bootstrap run to fire.  Pause via UI later only
    # if intentionally disabling.
    is_paused_upon_creation=False,
    tags=["platform", "vault", "secrets", "cache"],
    doc_md=__doc__,
) as dag:

    prewarm = PythonOperator(
        task_id="prewarm_vault_cache",
        python_callable=_run_prewarm,
        provide_context=True,
        doc_md=(
            "Resolve every ``secrets.refs.*`` entry from "
            "``/usr/local/spark/pvc/code/configs/vault_config.yaml`` "
            "via the shared resolver.  Each successful resolve writes "
            "the validated payload to the Fernet-encrypted disk cache "
            "at ``/usr/local/spark/pvc/code/.cache/etl_secrets.enc`` "
            "so every downstream pod reads from a hot cache.  Per-ref "
            "retry (3 attempts, exponential backoff) absorbs transient "
            "Vault hiccups; post-run verification fails LOUDLY when "
            "the resolver reports success but the cache file wasn't "
            "actually written."
        ),
    )
