"""Tests for ``qs_credentials.prewarm`` -- the pure-Python chokepoint
behind the Vault credential pre-warm DAG.

Tests cover the production contract:
  * yaml parsing (missing / malformed / empty / good)
  * skip rules (_disabled_ prefix, blank auth_url, blank secret_url)
  * per-ref retry with backoff (failure on attempt 1 succeeds on 2)
  * exhausted retry returns structured failure
  * post-run cache file verification (exists / non-empty / mtime)
  * EVERY-eligible-ref-failed escalation
  * partial failure does NOT raise (the cache stays usable for the
    refs that succeeded; workflows consuming those keep working)
  * skip rules don't count toward the all-failed escalation
"""
from __future__ import annotations

import os
import sys
import time
from unittest.mock import patch

import pytest
import yaml


# Add ETL to sys.path so ``qs_credentials.prewarm`` is importable.
_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)

from qs_credentials import prewarm as pw  # noqa: E402


# ── yaml fixtures ────────────────────────────────────────────────────


def _write_yaml(path: str, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, default_flow_style=False)


def _good_yaml() -> dict:
    return {
        "secrets": {
            "enabled": True,
            "vault": {
                "machine":          "openshift",
                "token_method":     "JWT",
                "disk_cache_path":  "/tmp/test_etl_cache.enc",
            },
            "refs": {
                "ref_a": {
                    "type":       "AD_accounts",
                    "auth_url":   "https://vault.example.com/v1/auth/login",
                    "role_name":  "ref-a-reader",
                    "role_type":  "JWT",
                    "secret_url": "https://vault.example.com/v1/ad/creds/a",
                },
                "ref_b": {
                    "type":       "DB_accounts",
                    "auth_url":   "https://vault.example.com/v1/auth/login",
                    "role_name":  "ref-b-reader",
                    "role_type":  "JWT",
                    "secret_url": "https://vault.example.com/v1/db/creds/b",
                },
            },
        },
    }


# ── load_refs_from_yaml ──────────────────────────────────────────────


class TestLoadRefs:
    def test_missing_file_raises_file_not_found(self, tmp_path):
        missing = tmp_path / "nope.yaml"
        with pytest.raises(FileNotFoundError) as exc:
            pw.load_refs_from_yaml(str(missing))
        assert "vault_config.yaml not found" in str(exc.value)

    def test_malformed_yaml_raises_runtime_error(self, tmp_path):
        bad = tmp_path / "bad.yaml"
        bad.write_text("not: valid: yaml: at: all: :", encoding="utf-8")
        with pytest.raises(RuntimeError) as exc:
            pw.load_refs_from_yaml(str(bad))
        assert "malformed" in str(exc.value)

    def test_empty_refs_raises_value_error(self, tmp_path):
        empty = tmp_path / "empty.yaml"
        _write_yaml(str(empty), {"secrets": {"refs": {}}})
        with pytest.raises(ValueError) as exc:
            pw.load_refs_from_yaml(str(empty))
        assert "no ``secrets.refs`` entries" in str(exc.value)

    def test_refs_must_be_mapping(self, tmp_path):
        wrong = tmp_path / "wrong_type.yaml"
        _write_yaml(str(wrong), {"secrets": {"refs": ["a", "b"]}})
        with pytest.raises(RuntimeError) as exc:
            pw.load_refs_from_yaml(str(wrong))
        assert "must be a mapping" in str(exc.value)

    def test_good_yaml_returns_refs_and_vault(self, tmp_path):
        good = tmp_path / "good.yaml"
        _write_yaml(str(good), _good_yaml())
        parsed = pw.load_refs_from_yaml(str(good))
        assert set(parsed["refs"].keys()) == {"ref_a", "ref_b"}
        assert parsed["vault"]["machine"] == "openshift"


# ── _is_skippable ────────────────────────────────────────────────────


class TestSkipRules:
    def test_disabled_prefix_is_skipped(self):
        ref = {"auth_url": "https://x", "secret_url": "https://x"}
        assert pw._is_skippable("_disabled_foo", ref) == "disabled_prefix"

    def test_blank_auth_url_is_skipped(self):
        ref = {"auth_url": "", "secret_url": "https://x"}
        assert pw._is_skippable("smoke_a", ref) == "blank_auth_url"

    def test_blank_secret_url_is_skipped(self):
        ref = {"auth_url": "https://x", "secret_url": ""}
        assert pw._is_skippable("smoke_b", ref) == "blank_secret_url"

    def test_real_ref_not_skipped(self):
        ref = {"auth_url": "https://v/login",
                "secret_url": "https://v/creds/x"}
        assert pw._is_skippable("real_ref", ref) is None


# ── _resolve_one (with retry) ────────────────────────────────────────


class TestResolveOneRetry:
    def _ref(self):
        return {"type": "AD_accounts", "auth_url": "https://v/login",
                "secret_url": "https://v/creds/x"}

    def test_succeeds_on_first_attempt(self, monkeypatch):
        calls = []

        def fake_resolve(name):
            calls.append(name)
            return ("alice", "s3cret")

        monkeypatch.setattr(
            "qs_credentials.resolver._resolve_with_cache",
            fake_resolve,
            raising=False,
        )
        # Also patch the late-bound import inside _resolve_one by
        # injecting a stub module attribute the resolver imports from.
        # Easiest: stub the qs_credentials.resolver module's symbol.
        import qs_credentials.resolver as _resolver
        monkeypatch.setattr(_resolver, "_resolve_with_cache", fake_resolve)

        sleeps = []
        out = pw._resolve_one("ref_a", self._ref(),
                                retry_backoff=(0.0, 2.0, 8.0),
                                sleep=sleeps.append)
        assert out["status"] == "ok"
        assert out["attempts"] == 1
        assert out["shape"] == "tuple(len=2)"
        assert calls == ["ref_a"]
        # First attempt has backoff_s=0.0 so sleep is NOT called
        # (guard ``if backoff_s > 0``).  No 2s / 8s sleeps either
        # because attempt 1 succeeded.
        assert sleeps == []

    def test_succeeds_on_second_attempt(self, monkeypatch):
        n = {"i": 0}

        def fake_resolve(name):
            n["i"] += 1
            if n["i"] == 1:
                raise RuntimeError("transient vault hiccup")
            return ("alice", "s3cret")

        import qs_credentials.resolver as _resolver
        monkeypatch.setattr(_resolver, "_resolve_with_cache", fake_resolve)

        sleeps = []
        out = pw._resolve_one("ref_a", self._ref(),
                                retry_backoff=(0.0, 0.0, 0.0),
                                sleep=sleeps.append)
        assert out["status"] == "ok"
        assert out["attempts"] == 2

    def test_exhausts_retries_returns_failure(self, monkeypatch):
        import qs_credentials.resolver as _resolver

        def fake_resolve(name):
            raise RuntimeError("vault down")

        monkeypatch.setattr(_resolver, "_resolve_with_cache", fake_resolve)
        out = pw._resolve_one("ref_a", self._ref(),
                                retry_backoff=(0.0, 0.0, 0.0),
                                sleep=lambda s: None)
        assert out["status"] == "failed"
        assert out["attempts"] == 3
        assert "vault down" in out["error"]
        assert out["shape"] is None

    def test_dict_payload_shape_described_safely(self, monkeypatch):
        import qs_credentials.resolver as _resolver
        monkeypatch.setattr(
            _resolver, "_resolve_with_cache",
            lambda name: {"access_key": "AK", "secret_key": "SK"},
        )
        out = pw._resolve_one("ref_kv", self._ref(),
                                retry_backoff=(0.0,),
                                sleep=lambda s: None)
        # Shape must NOT contain the secret values.
        assert "AK" not in out["shape"]
        assert "SK" not in out["shape"]
        assert "access_key" in out["shape"]
        assert "secret_key" in out["shape"]


# ── _verify_cache_written ────────────────────────────────────────────


class TestVerifyCacheWritten:
    def test_no_path_skips_quietly(self):
        info = pw._verify_cache_written("", run_started_at=0,
                                          n_eligible_ok=1)
        assert "skipped" in info

    def test_missing_file_with_zero_ok_just_reports(self, tmp_path):
        path = str(tmp_path / "nope.enc")
        info = pw._verify_cache_written(path, run_started_at=time.time(),
                                          n_eligible_ok=0)
        assert info["exists"] is False

    def test_missing_file_with_ok_refs_raises(self, tmp_path):
        path = str(tmp_path / "nope.enc")
        with pytest.raises(RuntimeError) as exc:
            pw._verify_cache_written(path, run_started_at=time.time(),
                                       n_eligible_ok=2)
        assert "verification FAILED" in str(exc.value)
        assert "does not exist" in str(exc.value)

    def test_empty_file_raises(self, tmp_path):
        path = tmp_path / "empty.enc"
        path.write_bytes(b"")
        with pytest.raises(RuntimeError) as exc:
            pw._verify_cache_written(str(path),
                                       run_started_at=time.time(),
                                       n_eligible_ok=1)
        assert "is empty" in str(exc.value)

    def test_stale_mtime_with_ok_refs_raises(self, tmp_path):
        path = tmp_path / "stale.enc"
        path.write_bytes(b"some-cipher-bytes")
        # Force mtime well before now.
        old = time.time() - 3600
        os.utime(str(path), (old, old))
        with pytest.raises(RuntimeError) as exc:
            pw._verify_cache_written(str(path),
                                       run_started_at=time.time(),
                                       n_eligible_ok=1)
        assert "OLDER than this run" in str(exc.value)

    def test_fresh_mtime_passes(self, tmp_path):
        path = tmp_path / "fresh.enc"
        path.write_bytes(b"some-cipher-bytes")
        info = pw._verify_cache_written(str(path),
                                          run_started_at=time.time() - 60,
                                          n_eligible_ok=2)
        assert info["exists"] is True
        assert info["size"] > 0

    # ── 2026-07-02 audit: plain-served refs must NOT trip verify ──

    def test_missing_file_but_zero_vault_ok_does_not_raise(self, tmp_path):
        """Prod incident 2026-07-02: 2 refs resolved OK but every one
        was served from plain oracle_config.yaml (vault not touched).
        Zero vault writes -> cache file may not exist and that is
        CORRECT.  Verify must NOT raise."""
        path = str(tmp_path / "not_written.enc")
        info = pw._verify_cache_written(
            path, run_started_at=time.time(),
            n_eligible_ok=2, n_vault_ok=0,
        )
        assert info["exists"] is False
        assert "no cache expected" in info.get("skipped", "")

    def test_missing_file_with_vault_ok_still_raises(self, tmp_path):
        """When AT LEAST ONE ref was vault-fetched, cache absence IS
        a real bug -- verify must still raise."""
        path = str(tmp_path / "should_have_been_written.enc")
        with pytest.raises(RuntimeError) as exc:
            pw._verify_cache_written(
                path, run_started_at=time.time(),
                n_eligible_ok=3, n_vault_ok=1,
            )
        assert "vault-fetched OK" in str(exc.value)

    def test_legacy_signature_without_vault_ok_arg_still_works(self, tmp_path):
        """Callers pre-dating the n_vault_ok argument (older test suites,
        external tools) still get the pre-2026-07-02 strict behaviour."""
        path = str(tmp_path / "nope.enc")
        with pytest.raises(RuntimeError):
            # No n_vault_ok= kwarg -> default -1 -> back-compat strict
            pw._verify_cache_written(
                path, run_started_at=time.time(), n_eligible_ok=2,
            )


# ── prewarm_vault_cache end-to-end ───────────────────────────────────


class TestPrewarmEndToEnd:
    def _setup_yaml_and_cache(self, tmp_path, refs):
        yaml_path = tmp_path / "vault_config.yaml"
        cache_path = tmp_path / "etl_secrets.enc"
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": True,
                "vault": {"disk_cache_path": str(cache_path)},
                "refs": refs,
            },
        })
        return str(yaml_path), str(cache_path)

    def _stub_resolver_writes_cache(self, monkeypatch, cache_path):
        """Stub `_resolve_with_cache` so it writes to the cache file
        on each call (simulating the real disk_put side-effect)."""
        import qs_credentials.resolver as _resolver

        def fake(name):
            # Append-style write so the file always has FRESH mtime
            # after each call.
            with open(cache_path, "ab") as f:
                f.write(f"\n{name}_payload".encode("utf-8"))
            return ("alice", f"pw_for_{name}")

        monkeypatch.setattr(_resolver, "_resolve_with_cache", fake)

    def test_all_refs_succeed(self, tmp_path, monkeypatch):
        refs = {
            "ref_a": {"type": "AD_accounts",
                       "auth_url": "https://v/login",
                       "secret_url": "https://v/creds/a"},
            "ref_b": {"type": "DB_accounts",
                       "auth_url": "https://v/login",
                       "secret_url": "https://v/creds/b"},
        }
        yaml_path, cache_path = self._setup_yaml_and_cache(tmp_path, refs)
        self._stub_resolver_writes_cache(monkeypatch, cache_path)

        summary = pw.prewarm_vault_cache(
            vault_config_path=yaml_path,
            pvc_code_root="",  # don't pollute sys.path during tests
            retry_backoff=(0.0,),
            sleep=lambda s: None,
            verify_round_trip=False,  # resolver is stubbed; no real cache writes
        )
        assert summary["ok"] == 2
        assert summary["failed"] == 0
        assert summary["skipped"] == 0
        assert summary["cache"]["exists"] is True
        assert summary["cache"]["size"] > 0

    def test_disabled_and_blank_refs_skipped(self, tmp_path, monkeypatch):
        refs = {
            "_disabled_old":  {"type": "AD_accounts",
                                 "auth_url": "https://v/login",
                                 "secret_url": "https://v/creds/x"},
            "smoke_blank":    {"type": "AD_accounts",
                                 "auth_url": "",
                                 "secret_url": ""},
            "real_ref":       {"type": "AD_accounts",
                                 "auth_url": "https://v/login",
                                 "secret_url": "https://v/creds/r"},
        }
        yaml_path, cache_path = self._setup_yaml_and_cache(tmp_path, refs)
        self._stub_resolver_writes_cache(monkeypatch, cache_path)

        summary = pw.prewarm_vault_cache(
            vault_config_path=yaml_path,
            pvc_code_root="",
            retry_backoff=(0.0,),
            sleep=lambda s: None,
            verify_round_trip=False,
        )
        assert summary["ok"] == 1
        assert summary["skipped"] == 2
        assert summary["eligible"] == 1

    def test_all_eligible_fail_raises(self, tmp_path, monkeypatch):
        refs = {
            "ref_a": {"type": "AD_accounts",
                       "auth_url": "https://v/login",
                       "secret_url": "https://v/creds/a"},
            "ref_b": {"type": "AD_accounts",
                       "auth_url": "https://v/login",
                       "secret_url": "https://v/creds/b"},
        }
        yaml_path, _cache = self._setup_yaml_and_cache(tmp_path, refs)
        import qs_credentials.resolver as _resolver
        monkeypatch.setattr(
            _resolver, "_resolve_with_cache",
            lambda name: (_ for _ in ()).throw(
                RuntimeError("vault down")
            ),
        )
        with pytest.raises(RuntimeError) as exc:
            pw.prewarm_vault_cache(
                vault_config_path=yaml_path,
                pvc_code_root="",
                retry_backoff=(0.0,),
                sleep=lambda s: None,
            )
        assert "ALL 2 eligible refs failed" in str(exc.value)

    def test_partial_failure_does_not_raise(self, tmp_path, monkeypatch):
        """One bad ref shouldn't kill the whole prewarm -- workflows
        consuming the good refs keep working off the still-warm cache."""
        refs = {
            "good": {"type": "AD_accounts",
                      "auth_url": "https://v/login",
                      "secret_url": "https://v/creds/g"},
            "bad":  {"type": "AD_accounts",
                      "auth_url": "https://v/login",
                      "secret_url": "https://v/creds/b"},
        }
        yaml_path, cache_path = self._setup_yaml_and_cache(tmp_path, refs)

        def fake(name):
            if name == "bad":
                raise RuntimeError("only this one is broken")
            with open(cache_path, "ab") as f:
                f.write(b"\ngood_payload")
            return ("alice", "pw")

        import qs_credentials.resolver as _resolver
        monkeypatch.setattr(_resolver, "_resolve_with_cache", fake)

        summary = pw.prewarm_vault_cache(
            vault_config_path=yaml_path,
            pvc_code_root="",
            retry_backoff=(0.0,),
            sleep=lambda s: None,
            verify_round_trip=False,
        )
        assert summary["ok"] == 1
        assert summary["failed"] == 1

    def test_vault_globally_disabled_raises_loud(self, tmp_path, monkeypatch):
        """Single early refusal when secrets.enabled is false -- replaces
        the 'N copies of identical error' UX from the 2026-06-28 prod
        incident.  Operator now sees one actionable message naming the
        in-place sed fix instead of 20 lines of per-ref noise."""
        monkeypatch.delenv("ETL_USE_VAULT", raising=False)
        yaml_path = tmp_path / "vault_config.yaml"
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": False,  # master switch OFF
                "vault": {"disk_cache_enabled": True,
                           "disk_cache_path": str(tmp_path / "x.enc")},
                "refs": {"r1": {"type": "AD_accounts",
                                  "auth_url": "https://v/login",
                                  "secret_url": "https://v/creds/r1"},
                          "r2": {"type": "AD_accounts",
                                  "auth_url": "https://v/login",
                                  "secret_url": "https://v/creds/r2"}},
            },
        })
        with pytest.raises(RuntimeError) as exc:
            pw.prewarm_vault_cache(
                vault_config_path=str(yaml_path),
                pvc_code_root="",
                retry_backoff=(0.0,),
                sleep=lambda s: None,
                verify_round_trip=False,
            )
        msg = str(exc.value)
        assert "GLOBALLY DISABLED" in msg
        assert "secrets.enabled: true" in msg
        assert "sed -i" in msg  # actionable in-place fix

    def test_etl_use_vault_env_force_off_raises_loud(self, tmp_path,
                                                       monkeypatch):
        """ETL_USE_VAULT=0 forces OFF regardless of yaml.  Refuse early
        so the operator notices their env-var override."""
        monkeypatch.setenv("ETL_USE_VAULT", "0")
        yaml_path = tmp_path / "vault_config.yaml"
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": True,  # yaml says ON
                "vault": {"disk_cache_enabled": True,
                           "disk_cache_path": str(tmp_path / "x.enc")},
                "refs": {"r1": {"type": "AD_accounts",
                                  "auth_url": "https://v/login",
                                  "secret_url": "https://v/creds/r1"}},
            },
        })
        with pytest.raises(RuntimeError) as exc:
            pw.prewarm_vault_cache(
                vault_config_path=str(yaml_path),
                pvc_code_root="",
                retry_backoff=(0.0,),
                sleep=lambda s: None,
                verify_round_trip=False,
            )
        assert "ETL_USE_VAULT" in str(exc.value)
        assert "FALSE" in str(exc.value)

    def test_etl_use_vault_env_override_lets_disabled_yaml_through(
        self, tmp_path, monkeypatch,
    ):
        """ETL_USE_VAULT=1 wins over yaml secrets.enabled=false.
        Operator escape hatch -- yaml may be dev-default but pod env
        forces production behaviour."""
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        yaml_path = tmp_path / "vault_config.yaml"
        cache_path = tmp_path / "x.enc"
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": False,
                "vault": {"disk_cache_enabled": True,
                           "disk_cache_path": str(cache_path)},
                "refs": {"r1": {"type": "AD_accounts",
                                  "auth_url": "https://v/login",
                                  "secret_url": "https://v/creds/r1"}},
            },
        })

        def fake(name):
            with open(cache_path, "ab") as f:
                f.write(b"\nfake_payload")
            return ("alice", "pw")
        import qs_credentials.resolver as _resolver
        monkeypatch.setattr(_resolver, "_resolve_with_cache", fake)

        # No raise -- env-var override gets us through.
        summary = pw.prewarm_vault_cache(
            vault_config_path=str(yaml_path),
            pvc_code_root="",
            retry_backoff=(0.0,),
            sleep=lambda s: None,
            verify_round_trip=False,
        )
        assert summary["ok"] == 1

    def test_disk_cache_disabled_raises_loud(self, tmp_path, monkeypatch):
        """The whole point of the DAG is the disk cache.  If yaml has
        ``disk_cache_enabled: false``, refuse loudly so the misconfig
        is caught on the first DAG run."""
        yaml_path = tmp_path / "vault_config.yaml"
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": True,
                "vault": {
                    "disk_cache_enabled": False,
                    "disk_cache_path": "/tmp/whatever.enc",
                },
                "refs": {"real_ref": {"type": "AD_accounts",
                                       "auth_url": "https://v/login",
                                       "secret_url": "https://v/creds/r"}},
            },
        })
        with pytest.raises(RuntimeError) as exc:
            pw.prewarm_vault_cache(
                vault_config_path=str(yaml_path),
                pvc_code_root="",
                retry_backoff=(0.0,),
                sleep=lambda s: None,
                verify_round_trip=False,
            )
        assert "disk_cache_enabled" in str(exc.value)
        assert "FALSE" in str(exc.value)

    def test_disk_cache_path_empty_raises_loud(self, tmp_path):
        yaml_path = tmp_path / "vault_config.yaml"
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": True,
                "vault": {
                    "disk_cache_enabled": True,
                    "disk_cache_path": "",  # empty
                },
                "refs": {"r": {"type": "AD_accounts",
                                "auth_url": "https://v/login",
                                "secret_url": "https://v/creds/r"}},
            },
        })
        with pytest.raises(RuntimeError) as exc:
            pw.prewarm_vault_cache(
                vault_config_path=str(yaml_path),
                pvc_code_root="",
                retry_backoff=(0.0,),
                sleep=lambda s: None,
                verify_round_trip=False,
            )
        assert "disk_cache_path" in str(exc.value)

    def test_all_eligible_skipped_does_not_raise(self, tmp_path):
        """yaml with only smoke / disabled refs MUST NOT raise -- the
        DAG is configured but currently has nothing to warm."""
        refs = {
            "smoke_a": {"type": "AD_accounts",
                         "auth_url": "", "secret_url": ""},
        }
        yaml_path, _cache = self._setup_yaml_and_cache(tmp_path, refs)

        summary = pw.prewarm_vault_cache(
            vault_config_path=yaml_path,
            pvc_code_root="",
            retry_backoff=(0.0,),
            sleep=lambda s: None,
            verify_round_trip=False,
        )
        assert summary["ok"] == 0
        assert summary["eligible"] == 0
        assert summary["skipped"] == 1


# ── Round-trip verification (Phase 158 R11 P0 hardening) ─────────────


class TestRoundTripVerification:
    """Locks the round-trip read-back contract.  This is the silent-
    killer check that catches Fernet key mismatch between Airflow and
    Spark pods BEFORE downstream workflows fail with decrypt errors."""

    def test_verify_round_trip_skipped_when_no_resolved(self):
        info = pw._verify_round_trip([])
        assert info["checked"] == 0
        assert info["not_readable"] == []

    def test_verify_round_trip_raises_on_unreadable(self, monkeypatch):
        """Simulate the Fernet-key-mismatch incident: cache reports
        None for a name we just wrote.  Must RAISE with the actionable
        ETL_SECRETS_KEY diagnostic."""
        # Stub _cred_cache.disk_get_any -> None (cache empty / decrypt fail).
        import qs_credentials.resolver as _resolver

        class _FakeCache:
            def disk_get_any(self, name): return None

        monkeypatch.setattr(_resolver, "_cred_cache", _FakeCache())
        with pytest.raises(RuntimeError) as exc:
            pw._verify_round_trip(["ref_a", "ref_b"])
        msg = str(exc.value)
        assert "ROUND-TRIP" in msg
        assert "2/2" in msg
        assert "ETL_SECRETS_KEY" in msg
        assert "ref_a" in msg

    def test_verify_round_trip_swallows_decrypt_exception(self, monkeypatch):
        """A read-side exception (e.g., InvalidToken from Fernet decrypt
        with the wrong key) is treated as 'not readable' and surfaced
        in the error message rather than crashing the prewarm."""
        import qs_credentials.resolver as _resolver

        class _FakeCache:
            def disk_get_any(self, name):
                raise RuntimeError("simulated decrypt failure")

        monkeypatch.setattr(_resolver, "_cred_cache", _FakeCache())
        with pytest.raises(RuntimeError) as exc:
            pw._verify_round_trip(["ref_a"])
        assert "simulated decrypt failure" in str(exc.value)
        assert "ref_a" in str(exc.value)

    def test_verify_round_trip_passes_on_readable(self, monkeypatch):
        import qs_credentials.resolver as _resolver

        class _FakeCache:
            def disk_get_any(self, name): return ["alice", "pw"]

        monkeypatch.setattr(_resolver, "_cred_cache", _FakeCache())
        info = pw._verify_round_trip(["ref_a", "ref_b"])
        assert info["checked"] == 2
        assert info["readable"] == 2
        assert info["not_readable"] == []


# ── DAG file smoke-import (no Airflow runtime required) ──────────────


class TestDagFileSourceSanity:
    """Cheap source-grep contract test -- catches regressions in the
    DAG wrapper without requiring Airflow installed in the test env."""

    def _dag_src(self) -> str:
        with open(
            os.path.join(_ETL_ROOT, "airflow_dag",
                          "vault_prewarm_dag.py"),
            "r", encoding="utf-8",
        ) as f:
            return f.read()

    def test_dag_imports_pure_chokepoint(self):
        src = self._dag_src()
        # DAG MUST delegate to the pure module -- no inline yaml /
        # resolver / retry logic in the Airflow file (keep wrapper thin).
        assert "from qs_credentials.prewarm import prewarm_vault_cache" in src
        assert "schedule_interval" in src
        assert "max_active_runs=1" in src, (
            "Concurrent prewarm runs would race on the disk cache."
        )
        assert "catchup=False" in src, (
            "Catchup must be off -- no point in back-filling stale "
            "cache warms."
        )

    def test_dag_active_on_creation(self):
        """First-deploy bootstrap: the DAG must fire on its first
        scheduler tick without operator intervention.  Catches a
        regression where someone accidentally sets
        ``is_paused_upon_creation=True``."""
        src = self._dag_src()
        assert "is_paused_upon_creation=False" in src, (
            "DAG must be active on creation so the bootstrap run "
            "fires immediately after helm upgrade.  Without this, a "
            "freshly deployed pod could serve a workflow before the "
            "cache is warm -- defeating the entire point of the DAG."
        )

    def test_dag_does_not_mutate_syspath_at_module_load(self):
        """Module-level ``sys.path.insert`` would persist for the
        lifetime of the Airflow scheduler / worker, shadowing same-
        named modules other DAGs import.  Mutation MUST live inside
        the task function (subprocess-scoped)."""
        src = self._dag_src()
        # Find the sys.path.insert line and confirm it's INSIDE a
        # function definition (indented), not at module top level.
        lines = src.splitlines()
        for i, line in enumerate(lines):
            if "sys.path.insert" not in line:
                continue
            # Must be inside a function -- meaning the line is indented.
            # Module-level statements start at column 0.
            assert line[0].isspace(), (
                f"sys.path.insert at module-load level (line {i+1}): "
                f"{line!r}.  Move inside the task function."
            )


class TestResolverSourceSignal:
    """2026-07-02 -- ``get_last_resolve_source`` must report the
    correct source per branch so prewarm can distinguish
    "vault-fetched OK (cache write expected)" from "plain-served OK
    (no cache write)".
    """

    def test_plain_creds_path_reports_plain(self, monkeypatch):
        import log_config  # noqa: F401
        from qs_credentials import resolver
        monkeypatch.setenv("ETL_USE_VAULT", "0")
        resolver.reset_cache()
        resolver._cred_cache.reset_mem()
        try:
            resolver._cred_cache.disk_clear()
        except Exception:
            pass
        cfg = {"oracle": {"etl": {"username": "u", "password": "p"}}}
        # Call the resolver on a namespaced ref so the scoping fix
        # allows plain-serving from an unbound section.
        resolver._resolve_with_cache("etl_oracle_meta", workflow_config=cfg)
        assert resolver.get_last_resolve_source() == "plain"

    def test_mem_cache_hit_reports_mem(self, monkeypatch):
        from qs_credentials import resolver
        monkeypatch.setenv("ETL_USE_VAULT", "0")
        resolver.reset_cache()
        resolver._cred_cache.reset_mem()
        try:
            resolver._cred_cache.disk_clear()
        except Exception:
            pass
        cfg = {"oracle": {"etl": {"username": "u", "password": "p"}}}
        # Prime the cache with the first (plain) call.
        resolver._resolve_with_cache("etl_oracle_meta", workflow_config=cfg)
        assert resolver.get_last_resolve_source() == "plain"
        # Second call must hit the in-memory cache.
        resolver._resolve_with_cache("etl_oracle_meta", workflow_config=cfg)
        assert resolver.get_last_resolve_source() == "mem"
