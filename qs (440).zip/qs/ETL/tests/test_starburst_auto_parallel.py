"""Prod incident 2026-07-02 -- 30-min SERIAL write failed mid-flight.

The real fix (not band-aid): auto-parallelize the read so >5M-row
reads never fall back to SERIAL when the operator forgot the
per-job JSON knobs.  This test locks the behavior via source-grep
+ unit-level probe checks so a future refactor can't silently drop
it and reintroduce the 30-min blocker.
"""
from __future__ import annotations

import inspect
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


_HERE = Path(__file__).parent
_ETL_ROOT = _HERE.parent
if str(_ETL_ROOT) not in sys.path:
    sys.path.insert(0, str(_ETL_ROOT))


# ── Source-lock ────────────────────────────────────────────────────────


class TestAutoParallelizeWireIn:
    def _source(self) -> str:
        p = _ETL_ROOT / "steps" / "oracle" / "starburst_base.py"
        return p.read_text(encoding="utf-8")

    def test_auto_detect_helper_exists(self):
        src = self._source()
        assert "_auto_detect_partition_bounds" in src, (
            "auto-parallelize helper must exist"
        )
        assert "_probe_min_max" in src, (
            "MIN/MAX probe must be a separate method"
        )

    def test_read_calls_auto_detect_on_serial_large(self):
        """_read_from_trino must call _auto_detect_partition_bounds
        when SERIAL is chosen AND total_rows > threshold."""
        from steps.oracle import starburst_base as m
        src = inspect.getsource(m.StarburstBase._read_from_trino)
        assert "_auto_detect_partition_bounds" in src
        assert "auto_parallel_disable" in src, (
            "opt-out knob must be honoured"
        )
        assert "auto_parallel_threshold_rows" in src, (
            "threshold override knob must be honoured"
        )

    def test_supported_type_lists_defined_and_widened(self):
        """2026-07-02 -- type match is EXACT-set (not prefix).
        Widened to include TIMESTAMP (no tz) + DECIMAL(N, 0) because
        operators reported they can't touch per-job JSON."""
        from steps.oracle.starburst_base import StarburstBase
        assert hasattr(StarburstBase, "_AP_NUMERIC_TYPES")
        assert hasattr(StarburstBase, "_AP_DATE_TYPES")
        # Safe integer types must be present.
        assert {"int", "bigint", "integer"} <= StarburstBase._AP_NUMERIC_TYPES
        # Fractional-stride types must NOT be present -- they break
        # partitioning.
        assert "decimal" not in StarburstBase._AP_NUMERIC_TYPES
        assert "double" not in StarburstBase._AP_NUMERIC_TYPES
        assert "real" not in StarburstBase._AP_NUMERIC_TYPES
        # Date + TIMESTAMP (without tz) both accepted now.
        assert "date" in StarburstBase._AP_DATE_TYPES
        assert "timestamp" in StarburstBase._AP_DATE_TYPES

    def test_interval_type_not_matched_as_numeric(self):
        """Prevent the audit-caught bug: 'interval day to second'
        startswith 'int' — must NOT be selected as numeric."""
        from steps.oracle.starburst_base import StarburstBase
        step = StarburstBase.__new__(StarburstBase)
        # Access the same closures the code uses:
        # exact match via the frozenset.
        assert "interval day to second" not in StarburstBase._AP_NUMERIC_TYPES
        assert "interval" not in StarburstBase._AP_NUMERIC_TYPES


# ── Unit-level: mock Spark, verify branch logic ────────────────────────


def _make_probe_step():
    """Instantiate StarburstBase-shape object with mocked deps so we
    can exercise _auto_detect_partition_bounds without a real Spark
    cluster."""
    from steps.oracle.starburst_base import StarburstBase
    # Sidestep BaseStep constructor by using __new__.
    step = StarburstBase.__new__(StarburstBase)
    step.logger = MagicMock()
    return step


def _fake_schema_read(field_specs):
    """Build a mock Spark reader chain whose ``.load()`` returns a
    DataFrame with schema derived from ``field_specs``, which is a
    list of ``(name, simple_type_string)``."""
    class _Field:
        def __init__(self, name, simple):
            self.name = name
            class _DT:
                def simpleString(self):
                    return simple
            self.dataType = _DT()

    fields = [_Field(n, t) for n, t in field_specs]
    schema = MagicMock()
    schema.fields = fields
    df = MagicMock()
    df.schema = schema
    # MagicMock chains any number of ``.option(...)`` and returns the
    # same mock; use a fluent-style stub so tests don't have to
    # count option() invocations manually.
    reader = MagicMock()

    class _Chain:
        def option(self, *a, **kw):
            return self
        def format(self, *a, **kw):
            return self
        def load(self, *a, **kw):
            return df

    reader.format = lambda *a, **kw: _Chain()
    return reader


class TestAutoDetectPartitionBounds:
    def test_picks_first_numeric_column(self, monkeypatch):
        step = _make_probe_step()
        spark = MagicMock()

        # Fake schema probe returns 3 columns; only 2nd is numeric.
        def _fake_read(*a, **kw):
            reader = _fake_schema_read([
                ("name_col", "string"),
                ("id_col",   "bigint"),
                ("date_col", "date"),
            ])
            return reader

        # We must patch spark.read at the actual call site: the
        # method builds spark.read.format(...).option(...)*.load().
        spark.read = _fake_read()

        # Stub _probe_min_max so we don't need a second reader chain.
        step._probe_min_max = MagicMock(return_value=(1, 1000))

        col, lo, hi = step._auto_detect_partition_bounds(
            spark, "url", "user", "pwd",
            query="SELECT * FROM t",
            config={},
        )
        # Should have picked "id_col" (first numeric).
        assert col == "id_col"
        assert lo == 1
        assert hi == 1000

    def test_prefer_columns_wins_over_schema_order(self):
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("a", "bigint"),
            ("preferred_col", "date"),
        ])
        step._probe_min_max = MagicMock(return_value=("2026-01-01", "2026-06-30"))
        col, lo, hi = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={"auto_parallel_prefer_columns": ["preferred_col"]},
        )
        assert col == "preferred_col"

    def test_prefer_columns_as_csv_string(self):
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("a", "bigint"),
            ("event_dt", "timestamp"),
        ])
        step._probe_min_max = MagicMock(return_value=("2026-01-01", "2026-06-30"))
        col, _, _ = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={"auto_parallel_prefer_columns": "event_dt,other"},
        )
        assert col == "event_dt"

    def test_falls_back_when_no_numeric_or_date(self):
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("name",   "string"),
            ("desc",   "string"),
        ])
        step._probe_min_max = MagicMock(return_value=(1, 100))
        col, lo, hi = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        assert col is None
        assert lo is None
        assert hi is None

    def test_skips_candidate_when_min_equals_max(self):
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("stuck_col", "bigint"),
            ("real_col",  "bigint"),
        ])
        # First probe returns min=max (no spread); second returns spread.
        step._probe_min_max = MagicMock(side_effect=[(5, 5), (1, 999)])
        col, lo, hi = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        assert col == "real_col"
        assert (lo, hi) == (1, 999)

    def test_skips_candidate_when_bounds_null(self):
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("all_null_col", "bigint"),
            ("valid_col",    "bigint"),
        ])
        step._probe_min_max = MagicMock(side_effect=[(None, None), (0, 500)])
        col, lo, hi = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        assert col == "valid_col"

    def test_probe_failure_returns_none_triple(self):
        step = _make_probe_step()
        spark = MagicMock()

        # Schema probe raises.
        class _RaisingReader:
            def format(self, *a, **kw):
                raise RuntimeError("Trino unreachable")
        spark.read = _RaisingReader()

        col, lo, hi = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        assert (col, lo, hi) == (None, None, None)

    def test_opt_out_via_disable_flag_source_lock(self):
        """The read path must honour auto_parallel_disable."""
        from steps.oracle import starburst_base as m
        src = inspect.getsource(m.StarburstBase._read_from_trino)
        # Guard: config knob is consulted BEFORE auto-detect fires.
        assert "auto_parallel_disable" in src
        # And the gate is a conjunction: only auto-detect when NOT
        # disabled AND NOT already parallel AND over threshold.
        assert "not auto_disabled" in src


class TestCoverageWidening:
    """2026-07-02 -- operators can't touch per-job JSON, so
    auto-parallelize must work on more type shapes.  Locks the widened
    type set + env-var override."""

    def test_decimal_scale_zero_matches(self):
        """DECIMAL(N, 0) is integer-like -- Spark JDBC stride math
        works.  Must be treated as numeric."""
        from steps.oracle.starburst_base import StarburstBase
        assert StarburstBase._decimal_scale_zero("decimal(38,0)")
        assert StarburstBase._decimal_scale_zero("decimal(10,0)")
        assert not StarburstBase._decimal_scale_zero("decimal(38,10)")
        assert not StarburstBase._decimal_scale_zero("decimal(10,2)")
        # Not a decimal at all.
        assert not StarburstBase._decimal_scale_zero("bigint")
        assert not StarburstBase._decimal_scale_zero("")
        # Malformed decimal string -- returns False, doesn't raise.
        assert not StarburstBase._decimal_scale_zero("decimal(broken)")

    def test_timestamp_without_tz_accepted(self, tmp_path):
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("event_ts", "timestamp"),
            ("customer_id", "bigint"),
        ])
        step._probe_min_max = MagicMock(return_value=(
            "2026-06-01 00:00:00", "2026-07-01 00:00:00",
        ))
        col, lo, hi = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        # customer_id (bigint) picked first in schema order because
        # numeric comes before date in the ordering pass -- BUT
        # event_ts is a date/timestamp candidate.  Ordering: prefer
        # (none) -> numerics first (customer_id) -> dates (event_ts).
        # Test asserts numeric wins because that's the current order.
        assert col == "customer_id"

    def test_timestamp_only_still_picked(self):
        """When ONLY a timestamp column is available, it must still
        be picked (previously this fell back to SERIAL)."""
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("name", "string"),
            ("event_ts", "timestamp"),
        ])
        step._probe_min_max = MagicMock(return_value=(
            "2026-06-01 00:00:00", "2026-07-01 00:00:00",
        ))
        col, _, _ = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        assert col == "event_ts", (
            "timestamp must be picked when no integer/date candidate "
            "exists"
        )

    def test_timestamp_with_time_zone_rejected(self):
        """TZ-suffix parsing is driver-version dependent -- reject."""
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("name", "string"),
            ("event_tstz", "timestamp with time zone"),
        ])
        step._probe_min_max = MagicMock(return_value=(
            "2026-06-01 00:00:00+00:00", "2026-07-01 00:00:00+00:00",
        ))
        col, lo, hi = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        assert col is None
        assert lo is None
        assert hi is None

    def test_decimal_scale_zero_column_picked(self):
        """DECIMAL(38, 0) used for large IDs must be picked."""
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("name", "string"),
            ("account_id", "decimal(38,0)"),
        ])
        step._probe_min_max = MagicMock(return_value=(1, 999999))
        col, _, _ = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        assert col == "account_id"

    def test_decimal_with_scale_rejected(self):
        """DECIMAL(N, s>0) must NOT be picked (fractional stride
        breaks Spark JDBC partitioning)."""
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("name", "string"),
            ("amount", "decimal(18,2)"),
        ])
        step._probe_min_max = MagicMock(return_value=(100, 999999))
        col, lo, hi = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        assert col is None

    def test_env_var_overrides_json_hint(self, monkeypatch):
        """QS_AUTO_PARALLEL_PREFER_COLUMNS env var overrides per-job
        JSON hints so ops teams can hint without touching JSON."""
        monkeypatch.setenv("QS_AUTO_PARALLEL_PREFER_COLUMNS", "id_from_env")
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("id_from_env", "bigint"),
            ("id_from_json", "bigint"),
        ])
        step._probe_min_max = MagicMock(return_value=(1, 100))
        col, _, _ = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={"auto_parallel_prefer_columns": ["id_from_json"]},
        )
        # env var wins.
        assert col == "id_from_env"

    def test_env_var_csv_parsed(self, monkeypatch):
        monkeypatch.setenv(
            "QS_AUTO_PARALLEL_PREFER_COLUMNS", "col_a, col_b ,col_c",
        )
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("col_c", "bigint"),
            ("col_a", "bigint"),
        ])
        step._probe_min_max = MagicMock(return_value=(1, 100))
        col, _, _ = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={},
        )
        # col_a wins because env order is [col_a, col_b, col_c]
        # and col_a is present in the schema.
        assert col == "col_a"


class TestAuditHardening:
    """Regression locks for the 2026-07-02 adversarial-audit fixes."""

    def _source(self) -> str:
        from steps.oracle import starburst_base as m
        return inspect.getsource(m)

    def test_case_insensitive_prefer_lookup(self):
        """Operator hint 'BusinessDate' must match schema
        'businessdate' -- case-insensitive."""
        step = _make_probe_step()
        spark = MagicMock()
        spark.read = _fake_schema_read([
            ("a", "bigint"),
            ("businessdate", "date"),
        ])
        step._probe_min_max = MagicMock(return_value=("2026-01-01", "2026-06-30"))
        col, _, _ = step._auto_detect_partition_bounds(
            spark, "url", "u", "p",
            query="SELECT * FROM t",
            config={"auto_parallel_prefer_columns": ["BusinessDate"]},
        )
        assert col == "businessdate"

    def test_refuses_on_limit_in_base_query(self):
        """LIMIT in base query must skip auto-parallelize entirely."""
        src = self._source()
        assert "LIMIT" in src, "LIMIT detection must be present"
        assert "ORDER" in src, "ORDER BY detection must be present"
        assert "refusing to auto-parallelize" in src or \
               "would either break LIMIT semantics" in src

    def test_probe_failures_logged_at_warning(self):
        """Schema-probe failure must land at WARNING, not DEBUG --
        operators need to see auth / network / SQL errors."""
        src = self._source()
        # The schema-probe except block must call logger.warning.
        method_src = inspect.getsource(
            __import__(
                "steps.oracle.starburst_base",
                fromlist=["StarburstBase"],
            ).StarburstBase._auto_detect_partition_bounds
        )
        assert "logger.warning" in method_src, (
            "auto_detect must WARN on schema-probe failures"
        )
        assert "auth / network / SQL" in method_src or (
            "usually a Trino" in method_src
        ), "warning must hint at the real cause class"

    def test_final_fallback_names_tried_candidates(self):
        """When all candidates fail, the fallback WARN must list
        WHICH candidates were tried and WHY each failed."""
        src = self._source()
        # Source-lock: exhausted candidates message must include
        # 'Tried:' and the tried_reasons list.
        assert "tried_reasons" in src
        assert "Tried:" in src

    def test_threshold_defensive_int_parse(self):
        """Operator typo like ``"5000000 abc"`` in threshold must not
        crash the read -- falls back to 5_000_000."""
        src = self._source()
        assert "auto_parallel_threshold_rows" in src
        # Structural: the fallback default appears twice (once in
        # the try, once in the except).
        assert src.count("5_000_000") >= 2 or (
            "auto_threshold = 5_000_000" in src
        )

    def test_probe_timeout_option_wired(self):
        """Per-probe queryTimeout must be set on the JDBC reader so
        a slow Trino planner can't extend the pre-read stack."""
        src = self._source()
        assert "queryTimeout" in src, (
            "auto-parallel probes must set queryTimeout"
        )
        assert "auto_parallel_probe_timeout_seconds" in src

    def test_trailing_semicolon_stripped(self):
        """The wrap ``SELECT ... FROM (query) t`` must strip trailing
        semicolons on the inner query so ``SELECT ... FROM t;`` doesn't
        break parsing."""
        src = self._source()
        assert 'rstrip(";")' in src or "rstrip(';')" in src
