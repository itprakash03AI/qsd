"""Regression tests for Batch 2 production-readiness fixes
(2026-07-01 deep-dive audit).

Locks items #6-17 (SHOULD-FIX).
"""
from __future__ import annotations

import os
import sys

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ── #6 + #7 (source-lock) ───────────────────────────────────────────────


class TestCancelledReleasesLockAndFlipsStatus:
    """Item #6 -- workflow_runner CancelledError branch MUST release
    the DBMS_LOCK + flip STATUS back to START.  Source-lock so a
    future edit that removes either half fails visibly."""

    def test_source_calls_release_and_flips_status(self):
        import inspect
        from polling_service import workflow_runner
        # Grab the source of the try_dispatch method (or whichever
        # coroutine holds the CancelledError branch).
        src = inspect.getsource(workflow_runner)
        # After the CancelledError log line, both calls MUST appear.
        assert "release_run_claim" in src, (
            "workflow_runner.py must call self.oracle_manager."
            "release_run_claim(...) on external CancelledError to "
            "release the DBMS_LOCK.  Without this, drain-in-place "
            "leaves rows stranded."
        )
        assert 'update_otg_etl_batch_status' in src


class TestPollLoopDeadFlipsHealth:
    """Item #7 -- BackgroundService.poll_loop_dead attribute exists
    and health.py surfaces it as 503."""

    def test_service_declares_dead_flag(self):
        import inspect
        from polling_service.service import BackgroundService
        src = inspect.getsource(BackgroundService)
        # Attribute assigned in __init__:
        assert "self.poll_loop_dead = False" in src
        # Set when poll task raises:
        assert "self.poll_loop_dead = True" in src

    def test_health_endpoint_returns_503_when_poll_dead(self):
        import inspect
        from polling_service import health as health_mod
        src = inspect.getsource(health_mod.health)
        assert "poll_loop_dead" in src
        assert "status_code=503" in src


# ── #8 legacy path alerter feed ────────────────────────────────────────


class TestLegacyPollerFeedsCrossPodDegradation:
    """Item #8 -- poller.py legacy path MUST feed
    alerter.record_cross_pod_degradation on try_claim_run exceptions
    (previously silent -- multi-workflow path already did this)."""

    def test_source_calls_record_cross_pod_degradation(self):
        import inspect
        from polling_service import poller
        src = inspect.getsource(poller.BackgroundPoller._poll_once)
        assert "record_cross_pod_degradation" in src


# ── #10 pool init retry ─────────────────────────────────────────────────


class TestPoolInitRetries:
    """Item #10 -- OracleDBLib.__init__ MUST retry pool creation with
    backoff so a transient Oracle blip at pod start doesn't
    CrashLoopBackoff the deployment."""

    def test_source_contains_retry_loop(self):
        import inspect
        from managers.oracledblib import OracleDBLib
        src = inspect.getsource(OracleDBLib.__init__)
        # Retry loop signature.  We accept any structural form of a
        # retry as long as ``retry_attempts`` from the config appears
        # in the loop and there's a sleep between attempts.
        assert "retry_attempts" in src
        assert "sleep(" in src  # backoff between attempts


# ── #11 loud queries yaml error ─────────────────────────────────────────


class TestQueriesYamlLoudError:
    """Item #11 -- config.py must raise actionable error on missing/
    malformed queries yaml AND allow BG_POLLING_SQL env override."""

    def test_source_supports_env_override(self):
        import inspect
        from polling_service import config
        src = inspect.getsource(config.load_config)
        assert "BG_POLLING_SQL" in src
        # Actionable error message ingredients:
        assert "queries yaml not found" in src or "queries_path" in src


# ── #12 loud ImportError distinguishing ────────────────────────────────


class TestLoaderErrorSplitFromImport:
    """Item #12 -- config.py must distinguish between genuine
    ImportError (log INFO, silent fall-through) and real bugs inside
    oracle_config_loader (log ERROR, actionable message)."""

    def test_source_has_separate_except_branches(self):
        import inspect
        from polling_service import config
        src = inspect.getsource(config.load_config)
        # There must be an ``except Exception`` handler that logs at
        # ERROR level with exc_info so operators see the tracebac.
        assert "exc_info=True" in src
        assert "except Exception" in src
        assert "except ImportError" in src


# ── #13 boot-time swap validation ──────────────────────────────────────


class TestDispatcherValidatesSwapsAtBoot:
    """Item #13 -- Dispatcher MUST verify each lightweight swap
    target imports cleanly at __init__ so operators see failures at
    pod-start instead of at first dispatch."""

    def test_source_calls_validator(self):
        import inspect
        from polling_service.dispatcher import Dispatcher
        src = inspect.getsource(Dispatcher.__init__)
        assert "_validate_lightweight_swaps_available" in src

    def test_validator_defined(self):
        from polling_service.dispatcher import Dispatcher
        assert hasattr(Dispatcher, "_validate_lightweight_swaps_available")


# ── #14 total_record=None on timeout ───────────────────────────────────


class TestTimeoutPassesNoneNotZero:
    """Item #14 -- workflow_runner.py timeout branch must pass None
    for total_record so the Oracle proc doesn't overwrite the
    accumulated row count with 0."""

    def test_source_passes_none_on_timeout(self):
        import inspect
        from polling_service import workflow_runner
        src = inspect.getsource(workflow_runner)
        # Locate the timeout branch call to update_otg_etl_batch_status.
        # It should pass ``None`` for total_record now, not ``0``.
        # We do the check via a targeted substring, since inspect
        # returns the raw source with comments.
        # Find the FIRST update_otg_etl_batch_status call after
        # "TimeoutError" and confirm it uses None.
        idx_to = src.find("except asyncio.TimeoutError")
        assert idx_to > 0
        idx_call = src.find("update_otg_etl_batch_status", idx_to)
        assert idx_call > 0
        # Look far enough after the call site to survive the inline
        # comment blocks the fix added (they push the actual args
        # past the naive 500-char window).
        snippet = src[idx_call:idx_call + 2000]
        # The actual arg passed for total_record must be None.  Strip
        # comments from the snippet so a comment mentioning "None" or
        # "0" doesn't false-positive.
        import re as _re
        code_only = _re.sub(r"#[^\n]*", "", snippet)
        # After the fix, total_record is passed as ``None,`` (with a
        # trailing comma before the next positional arg).  Assert on
        # the literal.
        assert "None," in code_only, (
            "workflow_runner timeout branch must pass None for "
            f"total_record, got snippet:\n{code_only[:800]}"
        )


# ── #15 FileWorker signature ───────────────────────────────────────────


class TestFileWorkerDispatcherCompatible:
    """Item #15 -- FileWorker __init__ MUST accept the 3-arg
    positional signature the dispatcher uses for Starburst-needing
    workers: (starburst_clients, oracle_mgr, logger)."""

    def test_can_construct_with_dispatcher_signature(self):
        # We construct via the dispatcher's exact call shape and
        # confirm it does NOT raise TypeError.
        from unittest.mock import MagicMock
        from workers.file_worker import FileWorker
        starburst = {"cloud": MagicMock(), "onprem": MagicMock()}
        oracle_mgr = MagicMock()
        logger = MagicMock()
        try:
            fw = FileWorker(starburst, oracle_mgr, logger)
        except TypeError as exc:
            pytest.fail(
                f"FileWorker rejected dispatcher signature "
                f"(starburst_clients, oracle_mgr, logger): {exc}"
            )


# ── #16 router skips unloadable workers ────────────────────────────────


class TestRouterSkipsUnloadable:
    """Item #16 -- WorkflowRegistry.route_dag_id must skip plugins
    whose worker_cls_loader returns None (Spark-only worker on
    lightweight image)."""

    def test_unloadable_plugin_is_skipped(self):
        from polling_service.workflow_registry import (
            WorkflowRegistry, WorkflowDefinition, _WORKER_LOADABLE_CACHE,
        )
        _WORKER_LOADABLE_CACHE.clear()   # test isolation
        r = WorkflowRegistry(default_name="default_wf")
        # The default plugin is loadable...
        r.register(WorkflowDefinition(
            name="default_wf",
            worker_cls_loader=lambda: object,
            dag_id_patterns=("__never_matches__",),
        ))
        # The "oracle" plugin has an unloadable worker...
        r.register(WorkflowDefinition(
            name="oracle",
            worker_cls_loader=lambda: None,   # simulate Spark-missing
            dag_id_patterns=("oracle",),
        ))
        # ...so a matching row falls through to the default_wf.
        assert r.route_dag_id("oracle_row_123") == "default_wf"

    def test_no_capable_runner_sentinel_when_all_unloadable(self):
        from polling_service.workflow_registry import (
            WorkflowRegistry, WorkflowDefinition, _WORKER_LOADABLE_CACHE,
        )
        _WORKER_LOADABLE_CACHE.clear()
        r = WorkflowRegistry(default_name="oracle")
        r.register(WorkflowDefinition(
            name="oracle",
            worker_cls_loader=lambda: None,   # unloadable
            dag_id_patterns=("oracle",),
        ))
        # Router returns the sentinel + dispatcher's unrouted branch
        # handles it (already tested via existing find_runner tests).
        assert r.route_dag_id("something_unmatched") == "__no_capable_runner__"


# ── #17 log_safety scrubber ────────────────────────────────────────────


class TestScrubTaskForLog:
    """Item #17 -- polling-row credential fields (c_pwd, p_pwd, sapp,
    sapu) MUST be redactable before landing in a log statement."""

    def test_c_pwd_redacted(self):
        from polling_service.log_safety import scrub_task_for_log
        got = scrub_task_for_log({"c_pwd": "leaked-secret", "run_id": 42})
        assert got["c_pwd"] == "***"
        assert got["run_id"] == 42

    def test_p_pwd_redacted(self):
        from polling_service.log_safety import scrub_task_for_log
        got = scrub_task_for_log({"p_pwd": "svc-account-pass"})
        assert got["p_pwd"] == "***"

    def test_sapp_redacted(self):
        from polling_service.log_safety import scrub_task_for_log
        got = scrub_task_for_log({"SAPP": "sap-password", "SAPU": "sap-user"})
        assert got["SAPP"] == "***"
        # SAPU (username) IS in the substring list?  Let's confirm.
        # It is NOT -- we only redact passwords, not usernames.
        assert got["SAPU"] == "sap-user"

    def test_nested_dict_redacted(self):
        from polling_service.log_safety import scrub_task_for_log
        got = scrub_task_for_log({
            "config": {"api_key": "leaked", "url": "https://api"}
        })
        assert got["config"]["api_key"] == "***"
        assert got["config"]["url"] == "https://api"

    def test_original_not_mutated(self):
        from polling_service.log_safety import scrub_task_for_log
        orig = {"c_pwd": "secret", "run_id": 1}
        _ = scrub_task_for_log(orig)
        assert orig["c_pwd"] == "secret"

    def test_extra_sensitive_keys_honoured(self):
        from polling_service.log_safety import scrub_task_for_log
        got = scrub_task_for_log(
            {"custom_prod_secret": "boom"},
            extra_sensitive_keys=("custom_prod_secret",),
        )
        assert got["custom_prod_secret"] == "***"

    def test_non_dict_input_wrapped(self):
        from polling_service.log_safety import scrub_task_for_log
        got = scrub_task_for_log("not-a-dict")
        assert "_scrubbed_wrapper" in got
