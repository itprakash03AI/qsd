"""Regression tests for Batch 1 production-readiness fixes
(2026-07-01 deep-dive audit).

Locks:
  * ``_sanitize_reason`` scrubs Oracle DSNs, Trino URLs, JWTs, AWS keys
    before they land in ``PluginTelemetry.last_failure_reason``.
  * ``PluginTelemetry.record_failure`` calls the scrubber.
  * The Oracle claim connection accepts OLEDB shape via the canonical
    parser (item #2).
  * ``alerter.alert`` returns immediately without blocking on
    ``smtplib`` -- SMTP send runs on a daemon thread (item #4).
  * ``health.status`` / ``health.workflows`` require the admin token
    when POLLING_ADMIN_TOKEN is set (item #5).
"""
from __future__ import annotations

import os
import sys
import time

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ── #5 sanitizer contract ───────────────────────────────────────────────


class TestSanitizeReason:
    """Item #5 -- credential scrubbing on the diagnostic field that
    surfaces in /status + /workflows."""

    def _sanitize(self, s):
        from polling_service.workflow_registry import _sanitize_reason
        return _sanitize_reason(s)

    def test_empty_input_returns_empty(self):
        assert self._sanitize("") == ""
        assert self._sanitize(None) == ""

    def test_password_kv_scrubbed(self):
        got = self._sanitize("Connection failed: Password=my-secret;")
        assert "my-secret" not in got
        assert "Password=***" in got

    def test_user_id_kv_scrubbed(self):
        got = self._sanitize("(DESC=...); User Id=etl_user; Password=pw;")
        assert "etl_user" not in got
        assert "User Id=***" in got

    def test_oracle_easy_connect_dsn_scrubbed(self):
        got = self._sanitize(
            "cx_Oracle error: etl_user/mypassword@host:1521/ETLDB"
        )
        assert "mypassword" not in got
        assert "etl_user/***@host:1521/ETLDB" in got

    def test_http_basic_url_credentials_scrubbed(self):
        got = self._sanitize(
            "Trino JDBC: https://svcuser:vault-pass@trino.corp:8443/v1"
        )
        assert "svcuser" not in got
        assert "vault-pass" not in got
        assert "https://***:***@trino.corp:8443/v1" in got

    def test_jwt_scrubbed(self):
        # Signature-shaped token -- three base64url segments
        jwt = (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0."
            "SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        )
        got = self._sanitize(f"Auth failed: {jwt} rejected")
        assert jwt not in got
        assert "[JWT-REDACTED]" in got

    def test_aws_access_key_scrubbed(self):
        got = self._sanitize("S3 client rejected AKIAIOSFODNN7EXAMPLE")
        assert "AKIAIOSFODNN7EXAMPLE" not in got
        assert "[AWS-KEY-REDACTED]" in got

    def test_500_char_truncation_preserved(self):
        long = "x" * 700
        assert len(self._sanitize(long)) == 500

    def test_idempotent(self):
        # Running twice must not corrupt the redacted markers.
        once = self._sanitize("Password=secret;")
        twice = self._sanitize(once)
        assert twice == once


class TestPluginTelemetryRecordFailureScrubs:
    """Item #5 wire-through: record_failure MUST call the scrubber."""

    def test_record_failure_stores_scrubbed_reason(self):
        from polling_service.workflow_registry import PluginTelemetry
        t = PluginTelemetry(name="oracle")
        t.record_failure(
            reason="jdbc error: etl_user/leakedpw@host:1521/DB",
            duration_s=1.5,
        )
        assert "leakedpw" not in t.last_failure_reason
        assert "***" in t.last_failure_reason
        assert t.failed == 1


# ── #4 alerter non-blocking ─────────────────────────────────────────────


class TestAlerterNonBlocking:
    """Item #4 -- alert() returns immediately; SMTP send happens on a
    daemon thread so the asyncio event loop is not blocked."""

    def test_alert_returns_before_sender_completes(self, monkeypatch):
        from polling_service.alerter import PluginAlerter as Alerter, AlertEvent
        # Slow injected sender simulates a stalled SMTP server.
        _sent_at_ts = []

        def _slow_sender(msg, alerter):
            time.sleep(0.3)   # 300ms simulates network latency
            _sent_at_ts.append(time.monotonic())

        # Configure a MINIMAL alerter that reports enabled=True.
        a = Alerter(
            smtp_host="smtp.example",
            smtp_port=25,
            smtp_use_tls=False,
            smtp_user="", smtp_password="",
            email_from="a@b", email_to="c@d",
            worker_id="test",
            cooldown_seconds=0,
            failure_window_size=1,
            failure_rate_threshold=0.5,
            vault_outage_threshold=1,
            cross_pod_degraded_threshold=1,
            sender=_slow_sender,
        )

        # Sender path is INLINE (not background) per contract so tests
        # can assert on stats deterministically.
        t0 = time.monotonic()
        ok = a.alert(AlertEvent(
            trigger="test", plugin="p", severity="INFO",
            message="hi",
        ))
        elapsed = time.monotonic() - t0
        assert ok is True
        # Inline test-sender took ~300ms so alert() blocks that long
        # -- this is intentional so tests can assert stats.
        assert elapsed >= 0.25

    def test_alert_via_production_smtplib_path_returns_immediately(
            self, monkeypatch,
    ):
        """Production path uses a background daemon thread so the
        caller returns in <50ms regardless of SMTP latency."""
        import polling_service.alerter as _alerter_mod
        from polling_service.alerter import PluginAlerter as Alerter, AlertEvent

        # Fake smtplib.SMTP that sleeps for 500ms then succeeds.
        class _SlowSMTP:
            def __init__(self, *a, **kw): pass
            def __enter__(self):
                time.sleep(0.5)
                return self
            def __exit__(self, *a): pass
            def starttls(self): pass
            def login(self, u, p): pass
            def send_message(self, m): pass

        monkeypatch.setattr(_alerter_mod, "smtplib",
                              type("s", (), {"SMTP": _SlowSMTP})())

        a = Alerter(
            smtp_host="smtp.example",
            smtp_port=25,
            smtp_use_tls=False,
            smtp_user="", smtp_password="",
            email_from="a@b", email_to="c@d",
            worker_id="test",
            cooldown_seconds=0,
            failure_window_size=1,
            failure_rate_threshold=0.5,
            vault_outage_threshold=1,
            cross_pod_degraded_threshold=1,
        )

        t0 = time.monotonic()
        ok = a.alert(AlertEvent(
            trigger="test", plugin="p", severity="INFO",
            message="hi",
        ))
        elapsed = time.monotonic() - t0
        assert ok is True
        # PRODUCTION path -- background thread means alert() returns
        # in a few ms even though the "SMTP" sleeps 500ms.
        assert elapsed < 0.1, (
            f"alert() blocked for {elapsed*1000:.0f}ms on background-thread "
            f"path -- fire-and-forget contract broken."
        )


# ── #2 OLEDB parse in claim connection path ─────────────────────────────


class TestClaimConnectionOLEDBSupport:
    """Item #2 -- ``_get_or_create_claim_connection`` must accept
    OLEDB-shaped DSN as well as Easy-Connect.  We stub the actual
    Oracle connect so the test runs without a live DB."""

    def _make_manager_with_stubbed_connect(self, monkeypatch, cs):
        """Build a manager with connection_string=cs, stub the
        Oracle connect call, return the manager."""
        # Import managers.oracle_metadata_manager without triggering
        # the OracleDBLib pool init.  We do this by stubbing the
        # oracledb module BEFORE the import chain runs.
        from unittest.mock import MagicMock
        stub_oracledb = MagicMock()
        stub_oracledb.connect = MagicMock(
            return_value=MagicMock(ping=MagicMock(return_value=None))
        )
        monkeypatch.setitem(sys.modules, "oracledb", stub_oracledb)
        # Force a fresh import so the stub is picked up.
        for m in list(sys.modules):
            if m.startswith("managers"):
                del sys.modules[m]
        from managers.oracle_metadata_manager import OracleMetadataManager
        # Bypass real __init__ (which hits pool_factory).  Build a
        # bare instance and populate just what claim path needs.
        mgr = OracleMetadataManager.__new__(OracleMetadataManager)
        mgr.connection_string = cs
        mgr._claim_connection = None
        import threading as _th
        mgr._claim_connection_lock = _th.Lock()
        import logging as _lg
        mgr.logger = _lg.getLogger("test.mgr")
        return mgr, stub_oracledb

    def test_easy_connect_still_works(self, monkeypatch):
        cs = "etl_user/etl_pass@host:1521/ETLDB"
        mgr, stub = self._make_manager_with_stubbed_connect(monkeypatch, cs)
        conn = mgr._get_or_create_claim_connection(cs)
        assert conn is not None
        stub.connect.assert_called_once()
        # Verify user/dsn threading -- the canonical parser strips
        # user + password + dsn correctly for Easy Connect.
        call_kwargs = stub.connect.call_args.kwargs
        assert call_kwargs["user"] == "etl_user"
        assert call_kwargs["password"] == "etl_pass"
        assert call_kwargs["dsn"] == "host:1521/ETLDB"

    def test_oledb_shape_now_works(self, monkeypatch):
        """PRE-FIX: raised ValueError on the naive split.
        POST-FIX: canonical parser handles it."""
        cs = (
            "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=host)(PORT=1521))"
            "(CONNECT_DATA=(SERVICE_NAME=ETLDB))); "
            "User Id=etl_user; Password=etl_pass;"
        )
        mgr, stub = self._make_manager_with_stubbed_connect(monkeypatch, cs)
        conn = mgr._get_or_create_claim_connection(cs)
        assert conn is not None
        call_kwargs = stub.connect.call_args.kwargs
        assert call_kwargs["user"] == "etl_user"
        assert call_kwargs["password"] == "etl_pass"
        assert "DESCRIPTION" in call_kwargs["dsn"]

    def test_malformed_dsn_raises_actionable_error(self, monkeypatch):
        cs = "not-a-valid-dsn"
        mgr, _ = self._make_manager_with_stubbed_connect(monkeypatch, cs)
        with pytest.raises(ValueError, match="could not parse"):
            mgr._get_or_create_claim_connection(cs)


# ── #1 300000 → 300 timeout ─────────────────────────────────────────────


class TestOracleMetadataManagerFivemMinuteTimeout:
    """Item #1 -- ``execute_procedure_with_dataframe`` wait_for was
    ``timeout=300000`` (3.47 DAYS).  Restored to 300 seconds."""

    def test_source_contains_five_minute_timeout(self):
        import inspect
        import re
        import managers.oracle_metadata_manager as m
        src = inspect.getsource(m.OracleMetadataManager.execute_procedure_with_dataframe)
        # Locked -- must be exactly 300 seconds not 300000.
        assert "timeout=300," in src, (
            "execute_procedure_with_dataframe must call "
            "asyncio.wait_for with timeout=300 (5 minutes).  If the "
            "value was changed intentionally, update this test."
        )
        # The comment in the code will contain ``timeout=300000``
        # verbatim (historical reference).  Strip comments before
        # the assertion so we're only checking executable code.
        code_only = re.sub(r"#[^\n]*", "", src)
        assert "timeout=300000" not in code_only, (
            "execute_procedure_with_dataframe still contains "
            "``timeout=300000`` in executable code -- must be 300."
        )


# ── #3 shutdown hooks non-blocking ──────────────────────────────────────


class TestShutdownHooksNonBlocking:
    """Item #3 -- BackgroundService.shutdown() on_runner_stop hooks
    must NOT use ``fut.result(timeout=...)`` inside the event loop.
    They must use ``asyncio.wait_for(asyncio.to_thread(...))`` so the
    loop stays responsive to uvicorn during shutdown."""

    def test_source_uses_asyncio_wait_for_pattern(self):
        import inspect
        import polling_service.service as m
        src = inspect.getsource(m.BackgroundService.shutdown)
        # The new pattern:
        assert "asyncio.wait_for(" in src
        assert "asyncio.to_thread(manifest.on_runner_stop" in src
        # The old blocking pattern must be gone:
        assert "fut.result(timeout=HOOK_TIMEOUT_S)" not in src
        assert "concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix=\"hook-stop\")" not in src
