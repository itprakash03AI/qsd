"""2026-06-26 contract tests for the structured oracle_config.yaml.

Background:
  oracle_config.yaml previously carried ONLY the legacy compact form
  (``etl_connection_string`` / ``dest_connection_string``) as the
  one-liner DSN ``user/pwd@host:port/service``.

  Operator direction 2026-06-26: mirror starburst_config.yaml shape --
  each endpoint (etl + destination) carries username + password +
  host + port + service + secret_ref.  No separate ``url:`` field
  because Oracle's JDBC URL is just ``jdbc:oracle:thin:@{host}:{port}/{service}``
  derived at use time.

  Spark JDBC sites consume ``oracle_url`` (URL form).
  Non-Spark sites (cx_Oracle / oracledb) consume the bare DSN.
  The loader yields both shapes from the same yaml input.

These tests lock the new resolution chain:
  Layer 1: ``etl_connection_string`` / ``dest_connection_string``
           literal compact DSN wins (back-compat one-liner).
  Layer 2: structured ``etl`` / ``destination`` section.
  Layer 3: vault via ``secret_ref`` + structured host:port/service.
  Layer 4: ``ETL_ORACLE_CONN`` / ``DEST_ORACLE_CONN`` env vars.
"""
from __future__ import annotations

import os
import sys

import pytest


_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


@pytest.fixture(autouse=True)
def _reset_loader_cache():
    """The loader caches the yaml parse per-process.  Tests need a
    fresh state for each call so per-test yaml writes are observable."""
    from oracle_config_loader import reset_cache
    reset_cache()
    yield
    reset_cache()


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch):
    """Clear env-var layers so tests are deterministic."""
    for var in ("ETL_ORACLE_CONN", "DEST_ORACLE_CONN",
                "ETL_USE_VAULT", "ETL_SECRETS_KEY"):
        monkeypatch.delenv(var, raising=False)


def _point_loader_at(tmp_path, monkeypatch, yaml_text: str) -> None:
    """Write a yaml file and point the loader at it."""
    import oracle_config_loader as mod
    yaml_file = tmp_path / "oracle_config.yaml"
    yaml_file.write_text(yaml_text)
    monkeypatch.setattr(mod, "_PROD_PATH", str(tmp_path / "no.yaml"))
    monkeypatch.setattr(mod, "_LOCAL_PATH", str(yaml_file))
    mod.reset_cache()


# ──────────────────────────────────────────────────────────────────────
# Layer 1 -- literal compact DSN wins
# ──────────────────────────────────────────────────────────────────────


class TestLegacyConnectionStringWins:
    """The one-liner ``etl_connection_string`` / ``dest_connection_string``
    is the simplest path and beats every other layer.  Back-compat:
    pre-2026-06-26 deployments populate only these.
    """

    def test_etl_connection_string_wins_over_structured(self, tmp_path, monkeypatch):
        from oracle_config_loader import resolve_etl_connection_string
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  etl_connection_string: legacy_u/legacy_p@legacy.host:1521/LEGACY\n"
            "  etl:\n"
            "    username: structured_u\n"
            "    password: structured_p\n"
            "    host: structured.host\n"
            "    port: 1521\n"
            "    service: STRUCT\n"
        )
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        assert resolve_etl_connection_string(cfg) == \
            "legacy_u/legacy_p@legacy.host:1521/LEGACY"

    def test_dest_connection_string_wins_over_structured(self, tmp_path, monkeypatch):
        from oracle_config_loader import resolve_dest_connection_string
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  dest_connection_string: legacy_u/legacy_p@legacy:1531/LDB\n"
            "  destination:\n"
            "    username: s_u\n"
            "    password: s_p\n"
            "    host: shost\n"
            "    port: 1531\n"
            "    service: SDB\n"
        )
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        assert resolve_dest_connection_string(cfg) == \
            "legacy_u/legacy_p@legacy:1531/LDB"


# ──────────────────────────────────────────────────────────────────────
# Layer 2 -- structured form composes user/pwd@host:port/svc
# ──────────────────────────────────────────────────────────────────────


class TestStructuredFormComposes:
    """When the literal compact form is blank, the structured section
    composes a ``user/password@host:port/service`` connection string."""

    def test_etl_structured_composes_connection_string(self, tmp_path, monkeypatch):
        from oracle_config_loader import resolve_etl_connection_string
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  etl_connection_string: ''\n"
            "  etl:\n"
            "    username: alice\n"
            "    password: w0nd3r\n"
            "    host: oracle-etl.corp.internal\n"
            "    port: 1521\n"
            "    service: ETLDB\n"
        )
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        assert resolve_etl_connection_string(cfg) == \
            "alice/w0nd3r@oracle-etl.corp.internal:1521/ETLDB"

    def test_destination_structured_composes_connection_string(self, tmp_path, monkeypatch):
        from oracle_config_loader import resolve_dest_connection_string
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  dest_connection_string: ''\n"
            "  destination:\n"
            "    username: bob\n"
            "    password: builder\n"
            "    host: oracle-dest.corp.internal\n"
            "    port: 1531\n"
            "    service: DESTDB\n"
        )
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        assert resolve_dest_connection_string(cfg) == \
            "bob/builder@oracle-dest.corp.internal:1531/DESTDB"

    def test_default_port_when_omitted(self, tmp_path, monkeypatch):
        """Port defaults to 1521 when omitted from the structured form."""
        from oracle_config_loader import resolve_etl_connection_string
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  etl:\n"
            "    username: u\n"
            "    password: p\n"
            "    host: h\n"
            "    service: SVC\n"
        )
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        assert resolve_etl_connection_string(cfg) == "u/p@h:1521/SVC"


# ──────────────────────────────────────────────────────────────────────
# Spark URL form -- jdbc:oracle:thin:@host:port/svc derived for Spark
# ──────────────────────────────────────────────────────────────────────


class TestSparkUrlFormDerived:
    """Spark JDBC sites consume ``oracle_url``
    (``jdbc:oracle:thin:@host:port/service``) via
    ``shared_dest_oracle_creds`` / ``shared_etl_oracle_creds``.
    Non-Spark sites use the bare DSN.  Both come from the SAME yaml
    input -- the loader yields whichever shape the caller wants.
    """

    def test_shared_dest_yields_jdbc_url_from_structured(
        self, tmp_path, monkeypatch,
    ):
        from oracle_config_loader import shared_dest_oracle_creds
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  destination:\n"
            "    username: dest_u\n"
            "    password: dest_p\n"
            "    host: dh\n"
            "    port: 1531\n"
            "    service: DDB\n"
        )
        out = shared_dest_oracle_creds()
        assert out["oracle_user"] == "dest_u"
        assert out["oracle_password"] == "dest_p"
        assert out["oracle_url"] == "jdbc:oracle:thin:@dh:1531/DDB", (
            "Spark consumers expect the canonical jdbc-thin URL form"
        )

    def test_shared_etl_yields_jdbc_url_from_structured(
        self, tmp_path, monkeypatch,
    ):
        from oracle_config_loader import shared_etl_oracle_creds
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  etl:\n"
            "    username: etl_u\n"
            "    password: etl_p\n"
            "    host: eh\n"
            "    port: 1521\n"
            "    service: EDB\n"
        )
        out = shared_etl_oracle_creds()
        assert out["oracle_user"] == "etl_u"
        assert out["oracle_password"] == "etl_p"
        assert out["oracle_url"] == "jdbc:oracle:thin:@eh:1521/EDB"

    def test_shared_dest_yields_jdbc_url_from_legacy_compact(
        self, tmp_path, monkeypatch,
    ):
        """Back-compat: legacy ``dest_connection_string`` still yields
        ``jdbc:oracle:thin:@`` URL form for Spark consumers."""
        from oracle_config_loader import shared_dest_oracle_creds
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  dest_connection_string: u/p@h:1531/SVC\n"
        )
        out = shared_dest_oracle_creds()
        assert out["oracle_url"] == "jdbc:oracle:thin:@h:1531/SVC"


# ──────────────────────────────────────────────────────────────────────
# Layer 4 -- env var fallback when yaml is entirely empty
# ──────────────────────────────────────────────────────────────────────


class TestEnvVarFallback:
    def test_etl_env_var_when_all_yaml_empty(self, tmp_path, monkeypatch):
        from oracle_config_loader import resolve_etl_connection_string
        _point_loader_at(tmp_path, monkeypatch, "oracle: {}\n")
        monkeypatch.setenv("ETL_ORACLE_CONN", "envu/envp@envh:1521/ENV")
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        assert resolve_etl_connection_string(cfg) == \
            "envu/envp@envh:1521/ENV"

    def test_dest_env_var_when_all_yaml_empty(self, tmp_path, monkeypatch):
        from oracle_config_loader import resolve_dest_connection_string
        _point_loader_at(tmp_path, monkeypatch, "oracle: {}\n")
        monkeypatch.setenv("DEST_ORACLE_CONN", "du/dp@dh:1531/DENV")
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        assert resolve_dest_connection_string(cfg) == "du/dp@dh:1531/DENV"


# ──────────────────────────────────────────────────────────────────────
# Empty-everywhere case -- empty string return, caller fails loud
# ──────────────────────────────────────────────────────────────────────


class TestEmptyEverywhereReturnsEmpty:
    def test_empty_when_yaml_and_env_both_blank(self, tmp_path, monkeypatch):
        from oracle_config_loader import resolve_etl_connection_string
        _point_loader_at(tmp_path, monkeypatch, "oracle: {}\n")
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        assert resolve_etl_connection_string(cfg) == ""


# ──────────────────────────────────────────────────────────────────────
# Yaml shape contract -- locks the structured form's field names
# ──────────────────────────────────────────────────────────────────────


# ──────────────────────────────────────────────────────────────────────
# OLEDB connection string parsing -- the canonical ETL prod format
# ──────────────────────────────────────────────────────────────────────


class TestOledbConnectionStringFormat:
    """ETL prod uses an OLEDB / .NET-style connection string:

        (DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)
          (HOST=oracle-scan.intranet.corp.com)(PORT = 1531)))
          (CONNECT_DATA = (SERVER = DEDICATED)(SERVICE_NAME = TES)));
        User Id = test_dev; Password = sdfsdfsd f;

    The loader's parser must extract (user, password, dsn) and the
    Spark URL must be built in code as ``jdbc:oracle:thin:@<dsn>``.
    """

    OLEDB_SAMPLE = (
        "(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)"
        "(HOST=oracle-scan.intranet.corp.com)(PORT = 1531)))"
        "(CONNECT_DATA = (SERVER = DEDICATED)(SERVICE_NAME = TES)));"
        " User Id = test_dev; Password = sdfsdfsd f;"
    )

    def test_parse_oracle_connection_string_oledb(self):
        from oracle_config_loader import parse_oracle_connection_string
        parsed = parse_oracle_connection_string(self.OLEDB_SAMPLE)
        assert parsed["user"] == "test_dev"
        assert parsed["password"] == "sdfsdfsd f"
        # DSN keeps the TNS descriptor; whitespace is squeezed for
        # JDBC tolerance.
        assert "HOST=oracle-scan.intranet.corp.com" in parsed["dsn"]
        assert "PORT=1531" in parsed["dsn"]
        assert "SERVICE_NAME=TES" in parsed["dsn"]
        assert parsed["dsn"].startswith("(DESCRIPTION=")

    def test_parse_dest_dsn_oledb_yields_jdbc_url(self):
        from oracle_config_loader import parse_dest_dsn
        out = parse_dest_dsn(self.OLEDB_SAMPLE)
        assert out["oracle_user"] == "test_dev"
        assert out["oracle_password"] == "sdfsdfsd f"
        # Spark URL is built in code with the jdbc:oracle:thin:@ prefix
        # wrapped around the TNS descriptor.
        assert out["oracle_url"].startswith("jdbc:oracle:thin:@(DESCRIPTION=")
        assert "SERVICE_NAME=TES" in out["oracle_url"]

    def test_parse_oracle_connection_string_easy_connect(self):
        from oracle_config_loader import parse_oracle_connection_string
        parsed = parse_oracle_connection_string(
            "alice/p4ss@oracle.host:1521/ETLDB",
        )
        assert parsed["user"] == "alice"
        assert parsed["password"] == "p4ss"
        assert parsed["dsn"] == "oracle.host:1521/ETLDB"

    def test_parse_dest_dsn_easy_connect_yields_jdbc_url(self):
        from oracle_config_loader import parse_dest_dsn
        out = parse_dest_dsn("alice/p4ss@oracle.host:1521/ETLDB")
        assert out["oracle_user"] == "alice"
        assert out["oracle_password"] == "p4ss"
        assert out["oracle_url"] == "jdbc:oracle:thin:@oracle.host:1521/ETLDB"

    # ── Hardening edge cases (2026-06-26 production audit) ──────────

    def test_password_with_semicolon_not_truncated(self):
        """Real-world passwords contain ``;``.  The OLEDB regex must
        only split on ``;`` followed by another recognised key= -- it
        must NOT truncate mid-value."""
        from oracle_config_loader import parse_oracle_connection_string
        s = (
            "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=h)(PORT=1))"
            "(CONNECT_DATA=(SERVICE_NAME=s)));"
            " User Id = u; Password = pa;ss; "
        )
        out = parse_oracle_connection_string(s)
        assert out["password"] == "pa;ss", (
            "password containing ';' was truncated -- the OLEDB "
            "splitter must use a lookahead to only split on "
            "';' followed by a recognised key="
        )

    def test_quoted_password_strips_quotes(self):
        """OLEDB convention escapes ``;`` / ``=`` by quoting the value.
        The parser strips surrounding single or double quotes."""
        from oracle_config_loader import parse_oracle_connection_string
        for quote in ('"', "'"):
            s = (
                "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=h)(PORT=1))"
                "(CONNECT_DATA=(SERVICE_NAME=s)));"
                f" User Id = u; Password = {quote}se;cret{quote}; "
            )
            out = parse_oracle_connection_string(s)
            assert out["password"] == "se;cret", (
                f"{quote}-quoted password not unquoted"
            )

    @pytest.mark.parametrize("user_key,pwd_key", [
        ("User Id",  "Password"),
        ("UID",      "Pwd"),
        ("uid",      "pwd"),
        ("USER ID",  "PASSWORD"),
        ("Username", "Password"),
        ("USER",     "PWD"),
    ])
    def test_oledb_key_aliases(self, user_key, pwd_key):
        """OLEDB / .NET key aliases (``User Id``, ``UID``, ``Pwd``, ...)
        are all recognised case-insensitively."""
        from oracle_config_loader import parse_oracle_connection_string
        s = (
            "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=h)(PORT=1))"
            "(CONNECT_DATA=(SERVICE_NAME=s)));"
            f" {user_key}=alice; {pwd_key}=p4ss;"
        )
        out = parse_oracle_connection_string(s)
        assert out["user"] == "alice", f"key {user_key!r} not detected"
        assert out["password"] == "p4ss", f"key {pwd_key!r} not detected"

    def test_warning_never_logs_raw_connection_string(self, caplog):
        """A malformed connection string MUST NOT appear in the warning
        message -- it may contain a plaintext password."""
        import logging
        from oracle_config_loader import parse_dest_dsn
        caplog.set_level(logging.WARNING, logger="oracle_config_loader")
        secret = "supers3cretP4ss"
        bad = f"user/{secret}@malformed"
        # Easy Connect format actually parses this; force a real
        # malformed input that triggers the warning path.
        out = parse_dest_dsn("garbage_no_separator_at_all")
        assert out["oracle_user"] == ""
        # Check that no log message echoes the raw value verbatim.
        for record in caplog.records:
            assert "garbage_no_separator_at_all" not in record.getMessage(), (
                "warning leaked the raw connection string -- must not "
                "log raw since it may contain a password"
            )

    def test_password_redacted_when_oledb_partial(self, caplog):
        """When OLEDB is detected but missing User Id / data source,
        the warning must not echo the raw string."""
        import logging
        from oracle_config_loader import parse_dest_dsn
        caplog.set_level(logging.WARNING, logger="oracle_config_loader")
        # OLEDB-shape sniff (starts with paren) but no User Id.
        s = "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=h)(PORT=1)));"
        out = parse_dest_dsn(s)
        for record in caplog.records:
            assert s not in record.getMessage()
            assert "DESCRIPTION=" not in record.getMessage()

    def test_oledb_in_yaml_resolves_end_to_end(self, tmp_path, monkeypatch):
        """The OLEDB string in ``etl_connection_string`` flows
        unchanged through ``resolve_etl_connection_string`` (it's the
        raw form the standalones pass to OracleDBLib).
        """
        from oracle_config_loader import resolve_etl_connection_string
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            f"  etl_connection_string: '{self.OLEDB_SAMPLE}'\n"
        )
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        result = resolve_etl_connection_string(cfg)
        # Raw OLEDB string passes through to the OracleDBLib consumer
        # which parses it via the shared parser.
        assert "User Id = test_dev" in result
        assert "(DESCRIPTION" in result


# ──────────────────────────────────────────────────────────────────────
# Vault wiring contract -- LOUD FAIL when secret_ref is set
# ──────────────────────────────────────────────────────────────────────


class TestVaultLoudFail:
    """When the operator sets ``secret_ref`` and configures
    ``vault_enabled``, a vault failure MUST surface as a RuntimeError
    with an actionable diagnostic.  Pre-2026-06-26 behaviour swallowed
    ImportError / RuntimeError / ValueError and fell through to env
    vars -- the operator only saw 'password empty' downstream with no
    clue QSClient had been attempted.
    """

    def test_oracle_dest_vault_disabled_raises(self, tmp_path, monkeypatch):
        """secret_ref set but vault_enabled blank -> RuntimeError naming
        all three toggle locations."""
        from oracle_config_loader import resolve_dest_connection_string
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  vault_enabled: \"\"\n"
            "  destination:\n"
            "    secret_ref: \"acct_x\"\n"
            "    host: h\n"
            "    port: 1521\n"
            "    service: SVC\n"
        )
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        with pytest.raises(RuntimeError, match="vault resolution is DISABLED"):
            resolve_dest_connection_string(cfg)

    def test_oracle_etl_vault_secret_missing_raises(self, tmp_path, monkeypatch):
        """secret_ref set + vault enabled but ref not registered ->
        RuntimeError with vault_config.yaml fix hint."""
        from oracle_config_loader import resolve_etl_connection_string
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  vault_enabled: \"true\"\n"
            "  etl:\n"
            "    secret_ref: \"nonexistent_ref\"\n"
            "    host: h\n"
            "    port: 1521\n"
            "    service: SVC\n"
        )
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        with pytest.raises(RuntimeError) as excinfo:
            resolve_etl_connection_string(cfg)
        # Operator gets the actionable checklist + the original
        # qs_credentials error message included.
        msg = str(excinfo.value)
        assert "VAULT FETCH FAILED" in msg
        assert "secret_ref=" in msg
        assert "vault_config.yaml" in msg

    def test_oracle_no_secret_ref_no_vault_attempted(self, tmp_path, monkeypatch):
        """Conversely: when secret_ref is BLANK, vault must NOT be
        consulted at all -- falls through to env var.  Locks the
        path that DEV users rely on."""
        from oracle_config_loader import resolve_etl_connection_string
        _point_loader_at(tmp_path, monkeypatch, "oracle: {}\n")
        monkeypatch.setenv("ETL_ORACLE_CONN", "u/p@h:1521/SVC")
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        # Should NOT raise -- vault is not attempted.
        assert resolve_etl_connection_string(cfg) == "u/p@h:1521/SVC"


def test_yaml_shape_has_no_url_field_on_oracle_endpoints():
    """Oracle endpoints carry dsn + host + port + service + username +
    password + secret_ref.  The JDBC URL is DERIVED at use time
    (``jdbc:oracle:thin:@<dsn>``); there is NO standalone ``url:`` field.

    Locks the operator direction:
      "etl_connection_string, dest_connection_string keep actual
       connection string not url"
    """
    import yaml
    path = os.path.join(_ETL_ROOT, "configs", "oracle_config.yaml")
    with open(path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    oracle = cfg["oracle"]
    for section_name in ("etl", "destination"):
        section = oracle[section_name]
        assert "url" not in section, (
            f"oracle.{section_name} must NOT have a 'url:' field -- "
            "the JDBC URL is derived from dsn / host+port+service at "
            "use time.  Operator direction 2026-06-26: connection "
            "strings go in etl_connection_string / dest_connection_string."
        )
        # Required structured fields.  ``dsn`` was added 2026-06-26
        # to let the structured form express full TNS descriptors so
        # the vault path can attach creds to a complex endpoint.
        for fld in ("dsn", "host", "port", "service",
                    "username", "password", "secret_ref"):
            assert fld in section, (
                f"oracle.{section_name} must have '{fld}' field"
            )
    # Literal compact forms still present (back-compat).
    assert "etl_connection_string" in oracle
    assert "dest_connection_string" in oracle


class TestStructuredDsnField:
    """The structured ``dsn:`` field lets the operator paste a full
    TNS descriptor into oracle.etl / oracle.destination -- which is
    REQUIRED when the prod Oracle endpoint can only be reached via
    descriptor (multi-address SCAN setups, dedicated/shared server
    modes, custom listener names ...).  Without ``dsn:`` the
    structured form can only express Easy Connect (host:port/svc),
    which doesn't cover the prod sample.
    """

    TNS_DSN = (
        "(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)"
        "(HOST=claude-scan.intranet.corp.com)(PORT = 1531)))"
        "(CONNECT_DATA = (SERVER = DEDICATED)(SERVICE_NAME = TES)))"
    )

    def test_structured_dsn_wins_over_host_port_service(self, tmp_path, monkeypatch):
        from oracle_config_loader import resolve_etl_connection_string
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  etl:\n"
            f"    dsn: \"{self.TNS_DSN}\"\n"
            "    host: should-be-ignored\n"
            "    port: 9999\n"
            "    service: IGN\n"
            "    username: alice\n"
            "    password: w0nd3r\n"
        )
        from oracle_config_loader import load_shared_oracle_config
        cfg = {"oracle": load_shared_oracle_config()}
        result = resolve_etl_connection_string(cfg)
        # user/password@(DESCRIPTION=...) -- whitespace squeezed
        assert result.startswith("alice/w0nd3r@(DESCRIPTION=")
        assert "HOST=claude-scan.intranet.corp.com" in result
        assert "PORT=1531" in result
        assert "SERVICE_NAME=TES" in result
        # host:port/service from yaml is IGNORED when dsn is set.
        assert "should-be-ignored" not in result
        assert "9999" not in result

    def test_structured_dsn_yields_jdbc_url_for_spark(self, tmp_path, monkeypatch):
        from oracle_config_loader import shared_dest_oracle_creds
        _point_loader_at(tmp_path, monkeypatch,
            "oracle:\n"
            "  destination:\n"
            f"    dsn: \"{self.TNS_DSN}\"\n"
            "    username: bob\n"
            "    password: builder\n"
        )
        out = shared_dest_oracle_creds()
        assert out["oracle_user"] == "bob"
        assert out["oracle_password"] == "builder"
        # Spark consumers get the canonical jdbc-thin URL with the
        # full TNS descriptor.
        assert out["oracle_url"].startswith("jdbc:oracle:thin:@(DESCRIPTION=")
        assert "SERVICE_NAME=TES" in out["oracle_url"]
