"""Deep-dive #14 (2026-07-01): polling_service must resolve dev DB creds
from oracle_config.yaml, not just from polling_service_config.yaml or env.

Operator report follow-up: after fixing the resolver Layer 3 fast path,
the polling_service STILL didn't pick up dev creds because its shim in
``config.py`` passed an empty ``{"oracle": {}}`` dict to
``resolve_etl_connection_string`` -- and that function reads ONLY from
the config parameter (no yaml re-read).  So structured creds or literal
connection strings living in oracle_config.yaml were invisible.

Fix: the shim now loads the FULL oracle_config.yaml via
``load_shared_oracle_config()`` and merges polling_service_config.yaml
literals over it.  Priority preserved:
  1. polling_service_config.yaml literal
  2. env var (ETL_ORACLE_CONN / DEST_ORACLE_CONN)
  3. oracle_config.yaml -> etl_connection_string (literal)
  4. oracle_config.yaml -> etl.{host,port,service,username,password} (structured)
  5. oracle_config.yaml -> etl.secret_ref (vault)

Test coverage:
  * Literal in oracle_config.yaml (dev happy path)
  * Structured in oracle_config.yaml (alternative dev shape)
  * polling_service_config.yaml literal STILL WINS if set (back-compat)
  * env var STILL WINS over oracle_config.yaml (existing ops override)
  * Neither yaml has creds -> connection string returns empty (existing
    fail-loud behaviour preserved)
"""
from __future__ import annotations

import os
import sys
import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


@pytest.fixture(autouse=True)
def _reset_env(monkeypatch):
    """Clear connection-string env vars so tests don't inherit ambient
    state from the developer's shell."""
    monkeypatch.delenv("ETL_ORACLE_CONN", raising=False)
    monkeypatch.delenv("DEST_ORACLE_CONN", raising=False)
    monkeypatch.delenv("ETL_USE_VAULT", raising=False)
    # Clear the load_shared_oracle_config cache so each test's
    # monkeypatched yaml takes effect.  Ignore the case where the
    # function is currently monkeypatched with a plain lambda
    # (which doesn't have .cache_clear).
    from oracle_config_loader import reset_cache
    try:
        reset_cache()
    except AttributeError:
        pass
    yield
    try:
        reset_cache()
    except AttributeError:
        pass


def _write_polling_yaml(tmp_path, *, oracle_section=None):
    """Write a minimal polling_service_config.yaml (no oracle creds by
    default -- the whole point is they come from oracle_config.yaml).

    ``oracle_section`` when non-None is placed at TOP LEVEL of the yaml
    (matches config.py line 169: ``oracle = raw.get("oracle", {})``),
    NOT nested under ``polling``.  Older polling YAMLs put oracle
    creds at top level -- that's the back-compat path.
    """
    import yaml as _y
    p = tmp_path / "polling_service_config.yaml"
    body = {"polling": {"interval_seconds": 5,
                          "max_concurrent_runs": 3}}
    if oracle_section is not None:
        body["oracle"] = oracle_section
    p.write_text(_y.safe_dump(body), encoding="utf-8")
    return p


def _stub_shared_oracle_config(monkeypatch, oracle_dict):
    """Replace load_shared_oracle_config so the polling shim reads a
    canned oracle_config.yaml payload without touching disk.

    Wraps the stub with a fake .cache_clear() attribute so the reset
    hook doesn't crash on teardown.
    """
    import oracle_config_loader
    def _stub():
        return oracle_dict
    _stub.cache_clear = lambda: None
    monkeypatch.setattr(oracle_config_loader,
                          "load_shared_oracle_config", _stub)


class TestPollingServiceReadsOracleConfigYaml:
    def test_literal_etl_connection_string_from_oracle_config(
            self, tmp_path, monkeypatch,
    ):
        """Dev happy path: oracle_config.yaml has
        oracle.etl_connection_string; polling_service_config.yaml
        doesn't override; env var not set.  polling picks up creds
        from oracle_config.yaml."""
        polling_yaml = _write_polling_yaml(tmp_path)
        _stub_shared_oracle_config(monkeypatch, {
            "etl_connection_string":
                "(DESC=...); User Id=DEV_U; Password=DEV_P;",
            "dest_connection_string":
                "(DESC=...); User Id=DEST_U; Password=DEST_P;",
        })
        from polling_service.config import load_config
        cfg = load_config(str(polling_yaml))
        assert "DEV_U" in cfg.etl_connection_string
        assert "DEV_P" in cfg.etl_connection_string
        assert "DEST_U" in cfg.dest_connection_string

    def test_structured_form_from_oracle_config(self, tmp_path, monkeypatch):
        """Alternative dev shape: creds in oracle.etl.{host,port,service,
        username,password} instead of a single connection string."""
        polling_yaml = _write_polling_yaml(tmp_path)
        _stub_shared_oracle_config(monkeypatch, {
            "etl": {
                "host": "dev-host", "port": 1521, "service": "DEVDB",
                "username": "dev_user", "password": "dev_pass",
            },
            "destination": {
                "host": "dest-host", "port": 1521, "service": "DESTDB",
                "username": "dest_user", "password": "dest_pass",
            },
        })
        from polling_service.config import load_config
        cfg = load_config(str(polling_yaml))
        # resolve_etl_connection_string returns "user/pw@host:port/svc"
        assert "dev_user" in cfg.etl_connection_string
        assert "dev_pass" in cfg.etl_connection_string
        assert "dev-host:1521/DEVDB" in cfg.etl_connection_string
        assert "dest_user" in cfg.dest_connection_string

    def test_polling_yaml_literal_still_wins_over_oracle_config(
            self, tmp_path, monkeypatch,
    ):
        """Back-compat: if operator DID set etl_connection_string in
        polling_service_config.yaml (older deployments), it must WIN
        over oracle_config.yaml -- no silent regression."""
        polling_yaml = _write_polling_yaml(tmp_path, oracle_section={
            "etl_connection_string":
                "(DESC=...); User Id=POLLING_YAML_U; Password=POLLING_YAML_P;",
            "dest_connection_string":
                "(DESC=...); User Id=POLLING_DEST_U; Password=POLLING_DEST_P;",
        })
        _stub_shared_oracle_config(monkeypatch, {
            "etl_connection_string":
                "(DESC=...); User Id=SHOULD_LOSE_U; Password=SHOULD_LOSE_P;",
        })
        from polling_service.config import load_config
        cfg = load_config(str(polling_yaml))
        assert "POLLING_YAML_U" in cfg.etl_connection_string
        assert "SHOULD_LOSE_U" not in cfg.etl_connection_string

    def test_env_var_still_wins_over_oracle_config(
            self, tmp_path, monkeypatch,
    ):
        """Ops override: ETL_ORACLE_CONN env var wins over
        oracle_config.yaml (existing behaviour we mustn't regress)."""
        polling_yaml = _write_polling_yaml(tmp_path)
        monkeypatch.setenv("ETL_ORACLE_CONN",
                            "(DESC=...); User Id=ENV_U; Password=ENV_P;")
        _stub_shared_oracle_config(monkeypatch, {
            "etl_connection_string":
                "(DESC=...); User Id=SHOULD_LOSE_U; Password=SHOULD_LOSE_P;",
        })
        from polling_service.config import load_config
        cfg = load_config(str(polling_yaml))
        assert "ENV_U" in cfg.etl_connection_string
        assert "SHOULD_LOSE_U" not in cfg.etl_connection_string

    def test_nothing_configured_returns_empty(self, tmp_path, monkeypatch):
        """When no creds anywhere, polling connection strings are empty
        so main.py:90 raises the actionable error at startup instead of
        silently connecting with (None, None)."""
        polling_yaml = _write_polling_yaml(tmp_path)
        _stub_shared_oracle_config(monkeypatch, {})     # empty oracle_config
        from polling_service.config import load_config
        cfg = load_config(str(polling_yaml))
        assert cfg.etl_connection_string == ""
        assert cfg.dest_connection_string == ""

    def test_load_shared_oracle_config_failure_falls_through_gracefully(
            self, tmp_path, monkeypatch,
    ):
        """If load_shared_oracle_config raises (yaml missing / permission
        error), polling still falls through to env-var-only resolution
        -- doesn't crash startup with an unrelated exception."""
        polling_yaml = _write_polling_yaml(tmp_path)
        monkeypatch.setenv("ETL_ORACLE_CONN",
                            "(DESC=...); User Id=FALLBACK_U; Password=FALLBACK_P;")
        import oracle_config_loader
        def _boom():
            raise FileNotFoundError("oracle_config.yaml missing")
        monkeypatch.setattr(oracle_config_loader,
                              "load_shared_oracle_config", _boom)
        from polling_service.config import load_config
        cfg = load_config(str(polling_yaml))
        # env var honoured; polling doesn't crash on the yaml load failure
        assert "FALLBACK_U" in cfg.etl_connection_string
