"""Unit tests for the coercer used by SafeSparkSubmitOperator.

The wrapper class itself needs Airflow to instantiate, but the pure
coercion function ``_coerce_cmd_to_str_list`` is a plain Python
function that we CAN test without Airflow installed.

If these pass, we know the "int in the cmd list" bug from the
2026-07-01 prod incident is provably fixed AT THE COERCION LAYER --
regardless of which specific connection extras field is leaking.
"""
from __future__ import annotations

import os
import sys


_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# We import the coercer directly.  Importing the module runs its
# top-level imports (airflow, oracledb, yaml).  Since Airflow isn't
# installed in this test environment we need to stub the top-level
# Airflow imports before importing the DAG module.
import types

def _install_airflow_stubs():
    """Register minimal stub packages so the DAG file's Airflow
    imports resolve without the real Airflow installed."""
    if "airflow" in sys.modules:
        return
    airflow = types.ModuleType("airflow")
    airflow.DAG = type("DAG", (), {})
    sys.modules["airflow"] = airflow

    providers = types.ModuleType("airflow.providers")
    sys.modules["airflow.providers"] = providers
    apache = types.ModuleType("airflow.providers.apache")
    sys.modules["airflow.providers.apache"] = apache
    spark = types.ModuleType("airflow.providers.apache.spark")
    sys.modules["airflow.providers.apache.spark"] = spark
    operators = types.ModuleType("airflow.providers.apache.spark.operators")
    sys.modules["airflow.providers.apache.spark.operators"] = operators
    ss = types.ModuleType("airflow.providers.apache.spark.operators.spark_submit")
    class _StubSparkSubmitOperator:
        def __init__(self, *args, **kwargs):
            pass
        def execute(self, context):
            return None
    ss.SparkSubmitOperator = _StubSparkSubmitOperator
    sys.modules["airflow.providers.apache.spark.operators.spark_submit"] = ss

    models = types.ModuleType("airflow.models")
    class _Variable:
        @staticmethod
        def get(key, default_var=None):
            return default_var
    models.Variable = _Variable
    sys.modules["airflow.models"] = models

    param = types.ModuleType("airflow.models.param")
    class _Param:
        def __init__(self, *args, **kwargs):
            pass
    param.Param = _Param
    sys.modules["airflow.models.param"] = param


_install_airflow_stubs()

# Also stub oracledb since we don't need a real Oracle for these
# tests.  The DAG module imports it at top level.
if "oracledb" not in sys.modules:
    oracledb_stub = types.ModuleType("oracledb")
    def _stub_connect(**kwargs):
        raise RuntimeError("stub -- not a real connect")
    oracledb_stub.connect = _stub_connect
    sys.modules["oracledb"] = oracledb_stub

# Now we can import our coercer.
from airflow_dag.dynamic_dags_airflow import _coerce_cmd_to_str_list


# ── coercion invariants ─────────────────────────────────────────────────


class TestCoerceCmdToStrList:
    def test_all_strings_pass_through_unchanged(self):
        cmd = ["spark-submit", "--master", "k8s://api", "app.py"]
        assert _coerce_cmd_to_str_list(cmd) == cmd

    def test_int_in_position_gets_coerced(self):
        # THE ACTUAL PROD BUG: an int at index 21 blows up " ".join().
        cmd = ["spark-submit", "--master", "k8s://api",
               "--conf", "spark.foo=bar",
               "--num-executors", 5,           # int leak
               "app.py"]
        result = _coerce_cmd_to_str_list(cmd)
        assert result[6] == "5"
        assert all(isinstance(x, str) for x in result)
        # And crucially, " ".join() now works:
        assert " ".join(result) == (
            "spark-submit --master k8s://api --conf spark.foo=bar "
            "--num-executors 5 app.py"
        )

    def test_none_becomes_empty_string(self):
        cmd = ["--driver-memory", None, "app.py"]
        result = _coerce_cmd_to_str_list(cmd)
        assert result[1] == ""
        assert " ".join(result) == "--driver-memory  app.py"

    def test_mixed_types_all_coerced(self):
        # Every builtin int / float / bool / bytes / list / dict --
        # simulate the wild types that could leak from a connection
        # extras JSON parse.
        cmd = ["spark-submit", 5, 3.14, True, None,
               ["nested"], {"k": "v"}, b"bytes"]
        result = _coerce_cmd_to_str_list(cmd)
        assert all(isinstance(x, str) for x in result)
        # " ".join() must succeed for every element -- that's the
        # only invariant that matters.
        joined = " ".join(result)
        assert isinstance(joined, str)

    def test_empty_list(self):
        assert _coerce_cmd_to_str_list([]) == []

    def test_stringifiable_object_via_str(self):
        class _Cfg:
            def __str__(self):
                return "cfg-value"
        cmd = ["--conf", _Cfg()]
        assert _coerce_cmd_to_str_list(cmd) == ["--conf", "cfg-value"]

    def test_str_raises_falls_back_to_repr(self):
        class _Broken:
            def __str__(self):
                raise RuntimeError("boom in __str__")
            def __repr__(self):
                return "<Broken>"
        cmd = ["--flag", _Broken()]
        result = _coerce_cmd_to_str_list(cmd)
        assert result == ["--flag", "<Broken>"]

    def test_both_str_and_repr_raise_falls_back_to_placeholder(self):
        class _TrulyBroken:
            def __str__(self):
                raise RuntimeError("str fails")
            def __repr__(self):
                raise RuntimeError("repr also fails")
        cmd = ["--flag", _TrulyBroken()]
        result = _coerce_cmd_to_str_list(cmd)
        assert result == ["--flag", "<unstringifiable>"]
        # Critically -- " ".join() STILL works
        " ".join(result)


# ── the exact prod scenario ─────────────────────────────────────────────


class TestProd2026_07_01_Scenario:
    """Reproduces the exact traceback from the operator's log:
    ``TypeError: sequence item 21: expected str instance, int found``.
    Confirms our coercer fixes it deterministically."""

    def test_int_at_index_21_reproduced_and_fixed(self):
        # Build a plausible cmd list with an int at index 21,
        # matching the traceback.  This is what the connection
        # extras JSON typically loads into.
        cmd = [
            "spark-submit",                     # 0
            "--master", "k8s://api-server",     # 1, 2
            "--deploy-mode", "cluster",         # 3, 4
            "--conf", "spark.foo=1",            # 5, 6
            "--conf", "spark.bar=2",            # 7, 8
            "--conf", "spark.baz=3",            # 9, 10
            "--conf", "spark.qux=4",            # 11, 12
            "--conf", "spark.abc=5",            # 13, 14
            "--conf", "spark.def=6",            # 15, 16
            "--conf", "spark.ghi=7",            # 17, 18
            "--conf", "spark.jkl=8",            # 19, 20
            5,                                   # 21 -- the leaking int!
            "--executor-memory", "4g",
            "app.py",
        ]

        # Reproduce the crash the operator saw:
        import pytest
        with pytest.raises(TypeError, match="expected str instance, int found"):
            " ".join(cmd)

        # Now confirm the wrapper eliminates the crash:
        safe = _coerce_cmd_to_str_list(cmd)
        assert safe[21] == "5"
        joined = " ".join(safe)   # must not raise
        assert "5" in joined
