"""Log-file cleanup contract tests (2026-07-02 user directive).

User asked for two things -- lock both behind CI so a future refactor
can't silently reintroduce the mess:

  1. "keep only last 2 run logs and delete old ones"
     -> ``log_retention.prune_old_logs(keep=2)`` sweeps old files.

  2. "1 log per run per workflow"
     -> ``log_config.attach_step_logger`` pins every step to the SAME
        file when ``task['log_file']`` is set, AND falls back to a
        run-shared filename (no LOG_PREFIX fanout) when it isn't.

These tests only touch the log helpers -- they don't spin up steps or
Spark.  Cheap enough to run in every pre-commit sweep.
"""
from __future__ import annotations

import logging
import os
import sys
import time
from pathlib import Path

import pytest


_HERE = Path(__file__).parent
_ETL_ROOT = _HERE.parent
if str(_ETL_ROOT) not in sys.path:
    sys.path.insert(0, str(_ETL_ROOT))


# ── prune_old_logs ────────────────────────────────────────────────────


class TestPruneOldLogs:
    def _make(self, dirpath, name, age_seconds=0):
        p = dirpath / name
        p.write_text("x", encoding="utf-8")
        if age_seconds:
            past = time.time() - age_seconds
            os.utime(p, (past, past))
        return p

    def test_keeps_two_most_recent_and_deletes_older(self, tmp_path):
        from log_retention import prune_old_logs
        # 5 files, ages 5s / 4s / 3s / 2s / 1s ago.  Keep the 2 newest.
        files = []
        for i, age in enumerate([500, 400, 300, 200, 100]):
            files.append(self._make(tmp_path, f"file_flow_dag_A_1_2026-07-01_{i:06d}.log", age))
        deleted = prune_old_logs(
            log_dir=str(tmp_path),
            prefix="file_flow_dag_A_1_",
            keep=2,
        )
        assert len(deleted) == 3
        surviving = sorted(p.name for p in tmp_path.iterdir())
        # The 2 newest (indexes 3 + 4) survive.
        assert surviving == [
            "file_flow_dag_A_1_2026-07-01_000003.log",
            "file_flow_dag_A_1_2026-07-01_000004.log",
        ]

    def test_ignores_files_with_wrong_prefix(self, tmp_path):
        """A stray unrelated log MUST NOT be swept just because it lives
        in the same directory."""
        from log_retention import prune_old_logs
        self._make(tmp_path, "file_flow_dag_A_1_2026-07-01_000000.log", 500)
        self._make(tmp_path, "file_flow_dag_A_1_2026-07-02_000000.log", 400)
        self._make(tmp_path, "polling_service.log", 100)  # unrelated
        self._make(tmp_path, "totally_random.log", 100)
        deleted = prune_old_logs(
            log_dir=str(tmp_path), prefix="file_flow_dag_A_1_", keep=1,
        )
        surviving = sorted(p.name for p in tmp_path.iterdir())
        assert "polling_service.log" in surviving
        assert "totally_random.log" in surviving
        assert len(deleted) == 1  # only the older matching file

    def test_ignores_non_log_extensions(self, tmp_path):
        from log_retention import prune_old_logs
        self._make(tmp_path, "file_flow_dag_A_1_2026-07-01_000000.log", 500)
        self._make(tmp_path, "file_flow_dag_A_1_2026-07-01_000000.txt", 500)
        self._make(tmp_path, "file_flow_dag_A_1_2026-07-01_000000.log.gz", 500)
        deleted = prune_old_logs(
            log_dir=str(tmp_path), prefix="file_flow_dag_A_1_", keep=100,
        )
        # keep=100 huge, nothing deleted
        assert deleted == []

    def test_empty_prefix_refuses_to_sweep(self, tmp_path):
        """Empty prefix would match every .log -- treat as safety guard."""
        from log_retention import prune_old_logs
        self._make(tmp_path, "anything.log")
        assert prune_old_logs(str(tmp_path), prefix="", keep=1) == []
        assert (tmp_path / "anything.log").exists()

    def test_keep_zero_raises(self, tmp_path):
        from log_retention import prune_old_logs
        with pytest.raises(ValueError):
            prune_old_logs(str(tmp_path), prefix="x_", keep=0)

    def test_missing_dir_returns_empty(self, tmp_path):
        from log_retention import prune_old_logs
        missing = tmp_path / "does_not_exist"
        assert prune_old_logs(str(missing), prefix="x_", keep=2) == []

    def test_fewer_files_than_keep_is_noop(self, tmp_path):
        from log_retention import prune_old_logs
        # File tail must match _TAIL_RE (YYYY-MM-DD_HHMMSS.log) --
        # a non-matching name is now IGNORED by the safer tail check.
        self._make(tmp_path, "file_flow_x_1_2026-07-02_120000.log", 100)
        deleted = prune_old_logs(str(tmp_path), prefix="file_flow_x_1_", keep=2)
        assert deleted == []
        assert (tmp_path / "file_flow_x_1_2026-07-02_120000.log").exists()

    def test_prefix_collision_shorter_tuple_does_not_sweep_longer(self, tmp_path):
        """CRITICAL regression lock (audit finding 2026-07-02):

        prefix ``file_flow_MY_1_`` used to sweep BOTH
          * its own ``file_flow_MY_1_{date}_{ts}.log`` files
          * AND ``file_flow_MY_1_42_{date}_{ts}.log`` (a different
            (dag=MY_1, report=42) tuple whose files happen to share
            the shorter tuple's prefix as a string prefix).

        The tail regex now rejects ``42_{date}_{ts}.log`` because the
        tail starts with ``42_...`` not ``{date}_...``.  Files
        belonging to the longer sibling tuple must survive.
        """
        from log_retention import prune_old_logs
        # Sibling tuple's files -- MUST NOT be swept.
        self._make(tmp_path, "file_flow_MY_1_42_2026-07-01_000001.log", 500)
        self._make(tmp_path, "file_flow_MY_1_42_2026-07-02_000001.log", 400)
        self._make(tmp_path, "file_flow_MY_1_42_2026-07-03_000001.log", 300)
        # Our tuple (MY, 1) -- 3 files, keep 1.
        self._make(tmp_path, "file_flow_MY_1_2026-07-01_000001.log", 500)
        self._make(tmp_path, "file_flow_MY_1_2026-07-02_000001.log", 400)
        self._make(tmp_path, "file_flow_MY_1_2026-07-03_000001.log", 300)
        deleted = prune_old_logs(
            log_dir=str(tmp_path), prefix="file_flow_MY_1_", keep=1,
        )
        surviving = sorted(p.name for p in tmp_path.iterdir())
        # All 3 sibling files still present.
        assert "file_flow_MY_1_42_2026-07-01_000001.log" in surviving
        assert "file_flow_MY_1_42_2026-07-02_000001.log" in surviving
        assert "file_flow_MY_1_42_2026-07-03_000001.log" in surviving
        # Only the newest MY-1 file survived; older 2 deleted.
        assert "file_flow_MY_1_2026-07-03_000001.log" in surviving
        assert len(deleted) == 2

    def test_dot_separated_iso_date_matches(self, tmp_path):
        """2026-07-02 audit: business_date variants like ``2026.07.02``
        (dot-separated ISO) MUST match the tail regex.  Prior regex
        ``[\\d\\-]+`` silently rejected them -> retention no-op ->
        old logs accumulated forever."""
        from log_retention import prune_old_logs
        self._make(tmp_path, "file_flow_X_1_2026.07.01_000001.log", 300)
        self._make(tmp_path, "file_flow_X_1_2026.07.02_000001.log", 200)
        self._make(tmp_path, "file_flow_X_1_2026.07.03_000001.log", 100)
        deleted = prune_old_logs(
            log_dir=str(tmp_path), prefix="file_flow_X_1_", keep=1,
        )
        assert len(deleted) == 2
        surviving = sorted(p.name for p in tmp_path.iterdir())
        assert surviving == ["file_flow_X_1_2026.07.03_000001.log"]

    def test_prefix_collision_still_blocked_with_dot_dates(self, tmp_path):
        """Widened regex must NOT re-open the sibling-tuple collision
        the original regex was designed to close."""
        from log_retention import prune_old_logs
        self._make(tmp_path, "file_flow_MY_1_42_2026.07.02_000001.log", 200)
        self._make(tmp_path, "file_flow_MY_1_2026.07.02_000002.log", 100)
        deleted = prune_old_logs(
            log_dir=str(tmp_path), prefix="file_flow_MY_1_", keep=0
            if False else 100,
        )
        # keep=100 -> no deletions expected regardless; the important
        # check is that ONLY the MY-1 file was CONSIDERED a candidate.
        # Prove by checking with keep=0-equivalent via a different call.
        deleted = prune_old_logs(
            log_dir=str(tmp_path), prefix="file_flow_MY_1_", keep=1,
        )
        # Sibling 42-tuple file must survive (not swept as collateral).
        surviving = sorted(p.name for p in tmp_path.iterdir())
        assert "file_flow_MY_1_42_2026.07.02_000001.log" in surviving
        # The single MY-1 file survives (only 1 exists, keep=1).
        assert "file_flow_MY_1_2026.07.02_000002.log" in surviving
        assert deleted == []

    def test_ignores_files_with_non_matching_tail(self, tmp_path):
        """A file whose tail doesn't match {date}_{HHMMSS}.log is
        IGNORED even if the prefix matches -- covers stray operator
        files with different naming schemes."""
        from log_retention import prune_old_logs
        # Matching tail (normal shape).
        self._make(tmp_path, "file_flow_x_1_2026-07-02_120000.log", 100)
        # Non-matching: no HHMMSS.
        self._make(tmp_path, "file_flow_x_1_note.log", 100)
        # Non-matching: HHMMSS but no date.
        self._make(tmp_path, "file_flow_x_1_120000.log", 100)
        deleted = prune_old_logs(
            log_dir=str(tmp_path), prefix="file_flow_x_1_", keep=0
            if False else 100,
        )
        # keep large -- nothing deleted; also verify non-matching
        # tails are simply not considered candidates.
        assert deleted == []
        assert (tmp_path / "file_flow_x_1_note.log").exists()
        assert (tmp_path / "file_flow_x_1_120000.log").exists()


# ── attach_step_logger single-file behaviour ─────────────────────────


class TestContextVarIsolationAcrossConcurrentRuns:
    """CRITICAL regression lock (audit finding 2026-07-02):

    The polling dispatcher (polling_service/poller) runs multiple
    workflow instances in ONE pod via ``asyncio.gather(...)``.  If the
    run-log-file pin OR the workflow name were bare module globals,
    the last ``set_run_log_file`` call would wipe out the first, and
    any step whose task['log_file'] was dropped mid-flight would land
    in the OTHER run's log file.

    ContextVar isolates the value per asyncio Task.  Verify both:
      * concurrent tasks see distinct log-file pins
      * concurrent tasks see distinct workflow names
    """

    def _reset(self, name_prefix):
        import logging as _l
        for name in list(_l.Logger.manager.loggerDict):
            if name.startswith(name_prefix):
                lg = _l.getLogger(name)
                for h in list(lg.handlers):
                    lg.removeHandler(h)

    def test_run_log_file_isolates_between_asyncio_tasks(self, tmp_path):
        import asyncio
        import log_config
        log_config.reset_for_tests()

        seen: dict = {}

        async def _task(name: str, path: str, wrote: asyncio.Event, other_wrote: asyncio.Event):
            log_config.set_run_log_file(path)
            wrote.set()
            # Yield until the OTHER task has also written.  If the
            # pin were process-global, whichever ran last would
            # overwrite the first, and both tasks would see the same
            # (last-writer) value.  ContextVar isolates per-task so
            # each task reads its OWN pinned path.
            await other_wrote.wait()
            seen[name] = log_config.get_run_log_file()

        async def _run():
            wrote_a = asyncio.Event()
            wrote_b = asyncio.Event()

            async def _a():
                await _task("A", str(tmp_path / "run_A.log"), wrote_a, wrote_b)

            async def _b():
                await _task("B", str(tmp_path / "run_B.log"), wrote_b, wrote_a)

            await asyncio.gather(_a(), _b())

        asyncio.run(_run())
        # Each task must see its OWN pinned value, not the other's.
        assert seen["A"] == str(tmp_path / "run_A.log")
        assert seen["B"] == str(tmp_path / "run_B.log")

    def test_workflow_name_isolates_between_asyncio_tasks(self):
        import asyncio
        import log_config
        log_config.reset_for_tests()

        seen: dict = {}

        async def _task(name: str, workflow: str, wrote: asyncio.Event, other_wrote: asyncio.Event):
            log_config.set_workflow_name(workflow)
            wrote.set()
            await other_wrote.wait()
            seen[name] = log_config.get_workflow_name()

        async def _run():
            wrote_a = asyncio.Event()
            wrote_b = asyncio.Event()

            async def _a():
                await _task("A", "file_flow", wrote_a, wrote_b)

            async def _b():
                await _task("B", "sap_odata", wrote_b, wrote_a)

            await asyncio.gather(_a(), _b())

        asyncio.run(_run())
        assert seen["A"] == "file_flow"
        assert seen["B"] == "sap_odata"


class TestAttachStepLoggerSingleFile:
    def _reset(self, name_prefix):
        # Purge any loggers this test suite created so we can re-add
        # handlers cleanly.
        import logging as _l
        for name in list(_l.Logger.manager.loggerDict):
            if name.startswith(name_prefix):
                lg = _l.getLogger(name)
                for h in list(lg.handlers):
                    lg.removeHandler(h)

    def test_task_log_file_pins_all_steps(self, tmp_path):
        """Every step in a run must land in ONE file when
        task['log_file'] is set -- the primary user directive."""
        from log_config import attach_step_logger
        shared = tmp_path / "run.log"
        task = {"log_file": str(shared), "run_id": "R1"}
        self._reset("file_flow.")
        for step_name in ("check_dependencies", "generate_sql",
                          "starburst_to_file_oncloud", "consolidate_files",
                          "compress_file", "create_ctl_file"):
            log = attach_step_logger(f"file_flow.{step_name}", task)
            log.info("hi from %s", step_name)
        # ONE file, all step messages inside.
        assert shared.exists()
        body = shared.read_text(encoding="utf-8")
        for step_name in ("check_dependencies", "generate_sql",
                          "starburst_to_file_oncloud", "consolidate_files",
                          "compress_file", "create_ctl_file"):
            assert f"hi from {step_name}" in body
        # No sibling per-step .log files (fanout ban).
        log_files = list(tmp_path.iterdir())
        assert log_files == [shared]

    def test_fallback_uses_process_pin(self, tmp_path):
        """When task['log_file'] is missing, the process-level pin set
        by ``set_run_log_file(path)`` MUST take over -- otherwise every
        step gets its own file."""
        import log_config
        pinned = tmp_path / "pinned.log"
        log_config.set_run_log_file(str(pinned))
        try:
            self._reset("file_flow.")
            task = {"run_id": "R2"}  # no log_file
            log_a = log_config.attach_step_logger("file_flow.step_a", task)
            log_b = log_config.attach_step_logger("file_flow.step_b", task)
            log_a.info("A")
            log_b.info("B")
            body = pinned.read_text(encoding="utf-8")
            assert "A" in body and "B" in body
            assert list(tmp_path.iterdir()) == [pinned]
        finally:
            log_config.set_run_log_file("")

    def test_final_fallback_is_run_shared_not_step_prefixed(self, tmp_path, monkeypatch):
        """No task['log_file'], no process-pin -- the fallback filename
        MUST NOT include the step's LOG_PREFIX (that produced the
        per-step fanout that motivated this fix)."""
        import log_config
        log_config.reset_for_tests()
        monkeypatch.setenv("ETL_LOG_DIR", str(tmp_path))
        try:
            self._reset("file_flow.")
            task = {"run_id": "RUN99"}
            log_a = log_config.attach_step_logger("file_flow.step_a", task)
            log_b = log_config.attach_step_logger("file_flow.step_b", task)
            log_a.info("A")
            log_b.info("B")
            files = sorted(p.name for p in tmp_path.iterdir())
            # Expect exactly one file, shape: file_flow_run_RUN99_YYYY-MM-DD.log
            assert len(files) == 1, files
            assert files[0].startswith("file_flow_run_RUN99_"), files[0]
            assert files[0].endswith(".log")
            body = (tmp_path / files[0]).read_text(encoding="utf-8")
            assert "A" in body and "B" in body
        finally:
            log_config.reset_for_tests()

    def test_workflow_arg_controls_fallback_prefix(self, tmp_path, monkeypatch):
        """oracle_standalone callers pass workflow='oracle_standalone';
        the fallback filename must reflect that."""
        import log_config
        log_config.reset_for_tests()
        monkeypatch.setenv("ETL_LOG_DIR", str(tmp_path))
        try:
            self._reset("etl.")
            task = {"run_id": "OR1"}
            log = log_config.attach_step_logger(
                "etl.some_oracle_step", task, workflow="oracle_standalone",
            )
            log.info("hello")
            files = sorted(p.name for p in tmp_path.iterdir())
            assert len(files) == 1
            assert files[0].startswith("oracle_standalone_run_OR1_")
        finally:
            log_config.reset_for_tests()

    def test_integer_zero_run_id_preserved_not_promoted_to_unknown(self, tmp_path, monkeypatch):
        """Regression lock (audit finding 2026-07-02): the previous
        ``or`` chain silently converted a valid integer run_id of 0
        into the string "unknown".  Explicit ``is not None`` check
        preserves the numeric value."""
        import log_config
        log_config.reset_for_tests()
        monkeypatch.setenv("ETL_LOG_DIR", str(tmp_path))
        try:
            self._reset("file_flow.step_zero")
            task = {"run_id": 0}  # <-- valid integer zero
            log = log_config.attach_step_logger("file_flow.step_zero", task)
            log.info("hi")
            files = sorted(p.name for p in tmp_path.iterdir())
            assert len(files) == 1
            # Filename must contain literal "_run_0_" not "_run_unknown_".
            assert "_run_0_" in files[0], files[0]
            assert "_run_unknown_" not in files[0]
        finally:
            log_config.reset_for_tests()

    def test_partial_handler_recovery_reattaches_file_handler(self, tmp_path):
        """Audit finding 2026-07-02: if the first call attached the
        StreamHandler but the FileHandler open raised OSError (transient
        FS error), a re-call MUST attach the missing FileHandler
        rather than short-circuiting on ``logger.handlers`` truthiness.
        """
        import logging as _l
        from log_config import attach_step_logger
        # Manually seed the logger with only a StreamHandler to
        # simulate the "FileHandler failed last time" state.
        self._reset("file_flow.recover_test")
        pre = _l.getLogger("file_flow.recover_test")
        pre.addHandler(_l.StreamHandler())
        assert len(pre.handlers) == 1
        assert not any(isinstance(h, _l.FileHandler) for h in pre.handlers)
        task = {"log_file": str(tmp_path / "run.log"), "run_id": "R"}
        log = attach_step_logger("file_flow.recover_test", task)
        # Now MUST have BOTH stream + file handlers.
        has_file = any(isinstance(h, _l.FileHandler) for h in log.handlers)
        assert has_file, [type(h).__name__ for h in log.handlers]

    def test_relocation_detaches_old_file_handler(self, tmp_path):
        """2026-07-02 audit finding: when a step logger was primed at
        path A and then the standalone relocates the run log to path B,
        the next ``attach_step_logger`` call MUST close+remove the old
        FileHandler.  Otherwise every log line would double-write to
        both files.
        """
        import logging as _l
        from log_config import attach_step_logger
        self._reset("file_flow.reloc_test")
        path_a = tmp_path / "run_A.log"
        path_b = tmp_path / "run_B.log"
        # Prime at path A.
        log = attach_step_logger(
            "file_flow.reloc_test", {"log_file": str(path_a), "run_id": "R"},
        )
        log.info("hello A")
        file_handlers = [h for h in log.handlers if isinstance(h, _l.FileHandler)]
        assert len(file_handlers) == 1
        assert os.path.abspath(file_handlers[0].baseFilename) == os.path.abspath(str(path_a))
        # Re-attach with a different target path.
        log = attach_step_logger(
            "file_flow.reloc_test", {"log_file": str(path_b), "run_id": "R"},
        )
        log.info("hello B")
        file_handlers = [h for h in log.handlers if isinstance(h, _l.FileHandler)]
        assert len(file_handlers) == 1, (
            "attach_step_logger left an old FileHandler attached at a "
            "different path -- log lines would double-write"
        )
        assert os.path.abspath(file_handlers[0].baseFilename) == os.path.abspath(str(path_b))
        # And path_a must NOT have the "hello B" line (proves the old
        # handler was closed BEFORE the second info() call).
        body_a = path_a.read_text(encoding="utf-8")
        body_b = path_b.read_text(encoding="utf-8")
        assert "hello A" in body_a
        assert "hello B" not in body_a, (
            "old FileHandler received log line after relocation -- "
            "not detached"
        )
        assert "hello B" in body_b

    def test_idempotent_no_duplicate_handlers(self, tmp_path):
        """Calling attach_step_logger repeatedly for the same logger
        name MUST NOT stack handlers -- otherwise every log line
        multiplies across reruns of the step in the same process."""
        from log_config import attach_step_logger
        task = {"log_file": str(tmp_path / "run.log"), "run_id": "R"}
        self._reset("file_flow.step_x")
        log1 = attach_step_logger("file_flow.step_x", task)
        n_after_first = len(log1.handlers)
        log2 = attach_step_logger("file_flow.step_x", task)
        assert log2 is log1
        assert len(log2.handlers) == n_after_first


# ── Contract: normalize_business_date must produce digits+dashes only ──


class TestBusinessDateShapeMatchesPruneTail:
    """Contract lock: the ``_TAIL_RE`` in log_retention requires the
    business_date segment of the filename to be ``[\\d\\-]+`` (digits +
    dashes only).  ``normalize_business_date`` currently outputs
    ``DD-MM-YYYY`` (the default target_format) which matches -- but if
    a future PR flips target_format to include letters (``%d-%b-%Y``
    would produce ``14-Jul-2025``), retention silently stops working
    because the tail regex no longer matches the filenames.

    Lock the shape via a source grep so the coupling is explicit.
    """
    def test_default_target_format_uses_digits_and_dashes_only(self):
        from date_utils import normalize_business_date
        # Every accepted input variant must normalise to a shape that
        # matches _TAIL_RE's digit+dash allowance.
        import re as _re
        digit_dash = _re.compile(r"^[\d\-]+$")
        for sample in (
            "14-07-2025", "2025-07-14", "14/07/2025",
            "14-Jul-2025", "14-July-2025", "14 Jul 2025",
        ):
            out = normalize_business_date(sample)
            assert digit_dash.match(out), (
                f"normalize_business_date({sample!r}) -> {out!r} "
                "contains characters outside [\\d\\-]; log_retention "
                "tail regex will silently stop matching."
            )

    def test_source_lists_target_format_first_in_signature(self):
        """Cheap grep: the target_format default in the function
        signature must be ``%d-%m-%Y`` (or any pure-digits-and-dashes
        strftime pattern).  A future patch that flips it to ``%d-%b-%Y``
        would produce ``14-Jul-2025`` and break the retention tail.
        """
        src = (_ETL_ROOT / "date_utils.py").read_text(encoding="utf-8")
        assert 'target_format: str = "%d-%m-%Y"' in src, (
            "date_utils.normalize_business_date default target_format "
            "must stay digits+dashes only.  If you need a different "
            "output shape, update log_retention._TAIL_RE too."
        )


# ── End-to-end: file_standalone._build_log_file leaves exactly 2 total ──


class TestBuildLogFileEndToEnd:
    """Contract lock: after 3+ reruns of the same (dag, report), the
    log directory ends up with exactly 2 files -- the current one +
    ONE previous.  This is the primary user directive.
    """

    def _touch(self, dirpath, name, age_seconds=0):
        p = dirpath / name
        p.write_text("x", encoding="utf-8")
        if age_seconds:
            past = time.time() - age_seconds
            os.utime(p, (past, past))
        return p

    def test_file_standalone_build_log_file_keeps_two_total(self, tmp_path, monkeypatch):
        """Simulate 4 prior runs on disk, then call _build_log_file +
        actually create the new file.  Directory must end with 2 files.
        """
        import log_config
        log_config.reset_for_tests()
        monkeypatch.setenv("ETL_LOG_DIR", str(tmp_path))
        try:
            from file_standalone import _build_log_file
            # 4 prior logs, ages 400s..100s.
            for i, age in enumerate([400, 300, 200, 100]):
                self._touch(
                    tmp_path,
                    f"file_flow_MY_DAG_42_2026-07-01_00000{i}.log",
                    age,
                )
            # Prune runs BEFORE the new FileHandler; only 1 old file
            # will survive.  Then we open the new one.
            new_path = _build_log_file("MY/DAG", 42, "2026-07-02")
            assert new_path.endswith(".log")
            # Simulate FileHandler creation.
            Path(new_path).write_text("new run", encoding="utf-8")
            files = sorted(p.name for p in tmp_path.iterdir())
            assert len(files) == 2, files
            # The newest previous (index 3, age 100s) is the survivor.
            assert "file_flow_MY_DAG_42_2026-07-01_000003.log" in files
            # The new file is present.
            assert os.path.basename(new_path) in files
        finally:
            log_config.reset_for_tests()

    def test_oracle_standalone_wired_with_keep_one(self):
        """Source grep: oracle_standalone._build_log_file must call
        prune_old_logs with keep=1 (semantics: leave 1 existing + 1
        newly-created file = 2 total).  Import-guard the module by
        source-grepping instead of importing (oracle_standalone.py
        pulls in datasources/etc. at module scope)."""
        src = (_ETL_ROOT / "oracle_standalone.py").read_text(encoding="utf-8")
        # Look for the specific wire-in.
        assert "from log_retention import prune_old_logs" in src
        assert 'prefix=f"oracle_standalone_{safe_dag}_{report_id}_"' in src
        assert "keep=1" in src


# ── Contract test: no step _setup_logging still fans out on LOG_PREFIX ──


class TestNoStepPrefixFanoutInSources:
    """Source-grep contract lock: no ETL step _setup_logging is allowed
    to build a fallback filename that includes ``LOG_PREFIX``.

    That WAS the shape of the pre-2026-07-02 bug: when task['log_file']
    was missing (subprocess handoff, unit test, etc.), each step created
    its OWN file named ``file_flow_{LOG_PREFIX}_{run_id}_{date}.log`` --
    fanout across the run.  All step _setup_logging methods now
    delegate to log_config.attach_step_logger which owns the fallback
    and drops LOG_PREFIX from the filename.

    Locking as a source grep means a future patch that reintroduces
    inline FileHandler assembly with self.LOG_PREFIX in the filename
    fails CI.
    """
    # Every step dir shipped under ETL/steps.  Add new ones here when
    # a workflow is added.
    STEP_DIRS = (
        "steps/file",
        "steps/oracle",
        "steps/s3",
        "steps/s3_to_file",
        "steps/s3_to_oracle",
        "steps/file_to_oracle",
        "steps/sap",
    )

    def _iter_step_files(self):
        for d in self.STEP_DIRS:
            root = _ETL_ROOT / d
            if not root.is_dir():
                continue
            for p in root.iterdir():
                if p.suffix != ".py":
                    continue
                if p.name.endswith("_DEPRECATED.py"):
                    continue
                # Legacy CentralizedLogger prd_* / refer_* files are
                # opt-out (not on the modern step-executor path).
                if p.name.startswith("prd_") or p.name.startswith("refer_"):
                    continue
                yield p

    def test_no_step_builds_fanout_filename(self):
        # Ban BOTH shapes:
        #   * f"{workflow}_{self.LOG_PREFIX}..." (f-string substitution)
        #   * "{workflow}_" + self.LOG_PREFIX (string concatenation)
        # for every workflow shipped in the tree.  Any new workflow
        # added here also enforces the ban on its fallback shape.
        WORKFLOW_PREFIXES = (
            "file_flow", "etl", "sap_odata",
            "oracle_standalone", "file_to_oracle",
            "bg_poller", "s3_query", "s3_to_file",
            "s3_to_oracle", "s3_workflow",
        )
        offenders = []
        for p in self._iter_step_files():
            src = p.read_text(encoding="utf-8")
            for lineno, line in enumerate(src.splitlines(), start=1):
                stripped = line.strip()
                if stripped.startswith("#"):
                    continue
                for wf in WORKFLOW_PREFIXES:
                    # f-string substitution shape.
                    if f'f"{wf}_{{self.LOG_PREFIX}}' in line:
                        offenders.append(f"{p}:{lineno} [f\"{wf}_{{LOG_PREFIX}}\"]")
                    if f"f'{wf}_{{self.LOG_PREFIX}}" in line:
                        offenders.append(f"{p}:{lineno} [f'{wf}_{{LOG_PREFIX}}']")
                    # String-concat shape (both quote styles).
                    if f'"{wf}_" + self.LOG_PREFIX' in line:
                        offenders.append(f"{p}:{lineno} [\"{wf}_\" + LOG_PREFIX]")
                    if f"'{wf}_' + self.LOG_PREFIX" in line:
                        offenders.append(f"{p}:{lineno} ['{wf}_' + LOG_PREFIX]")
        assert not offenders, (
            "Per-step LOG_PREFIX fanout filename reintroduced in:\n  "
            + "\n  ".join(offenders)
            + "\nUse log_config.attach_step_logger instead."
        )


# ── Every standalone must call prune_old_logs ────────────────────────


class TestAllStandalonesWireRetention:
    """Contract lock: every ETL standalone that owns a ``_build_log_file``
    MUST call ``prune_old_logs`` from ``log_retention``.  Without this,
    the standalone's directory accumulates log files forever.
    """
    STANDALONES = (
        "file_standalone.py",
        "oracle_standalone.py",
        "s3_query_standalone.py",
        "file_to_oracle_standalone.py",
        "sap_odata_standalone.py",
        "s3_standalone_runner.py",  # backs s3_to_file + s3_to_oracle
        "polling_service/dispatcher.py",  # in-poller path
    )

    def test_each_standalone_calls_prune_old_logs(self):
        offenders = []
        for rel in self.STANDALONES:
            p = _ETL_ROOT / rel
            assert p.exists(), f"missing standalone: {rel}"
            src = p.read_text(encoding="utf-8")
            if "from log_retention import prune_old_logs" not in src:
                offenders.append(f"{rel}: no import of prune_old_logs")
                continue
            if "prune_old_logs(" not in src:
                offenders.append(f"{rel}: prune_old_logs never called")
        assert not offenders, (
            "Retention wire-in missing in:\n  " + "\n  ".join(offenders)
        )

    def test_each_standalone_pins_run_log(self):
        """Every standalone / poller-owned entry point MUST call
        ``set_run_log_file`` so any step whose task['log_file'] is
        missing falls through to the SAME file via the process-pin
        (attach_step_logger reads ``_RUN_LOG_FILE``).  Without this,
        the step's final fallback opens a run-shared but path-detached
        file.
        """
        WANTS_PIN = (
            "file_standalone.py",
            "oracle_standalone.py",
            "file_to_oracle_standalone.py",
            "sap_odata_standalone.py",
            "s3_query_standalone.py",
            "s3_standalone_runner.py",
            "polling_service/dispatcher.py",
        )
        offenders = []
        for rel in WANTS_PIN:
            p = _ETL_ROOT / rel
            assert p.exists(), f"missing entry point: {rel}"
            src = p.read_text(encoding="utf-8")
            if "set_run_log_file(" not in src:
                offenders.append(rel)
        assert not offenders, (
            "set_run_log_file not called in:\n  " + "\n  ".join(offenders)
        )

    def test_each_standalone_publishes_workflow_name(self):
        """Every standalone MUST publish the workflow name via
        ``set_workflow_name`` (ContextVar-scoped so concurrent runs in
        the same pod don't collide).  ``os.environ["ETL_WORKFLOW_NAME"]``
        mirror is also kept for back-compat but the ContextVar path
        is what protects concurrent runs.
        """
        WANTS_PUBLISH = (
            "file_standalone.py",
            "oracle_standalone.py",
            "file_to_oracle_standalone.py",
            "sap_odata_standalone.py",
            "s3_query_standalone.py",
            "s3_standalone_runner.py",
            "polling_service/dispatcher.py",
        )
        offenders = []
        for rel in WANTS_PUBLISH:
            p = _ETL_ROOT / rel
            src = p.read_text(encoding="utf-8")
            if "set_workflow_name(" not in src:
                offenders.append(rel)
        assert not offenders, (
            "set_workflow_name not called in:\n  " + "\n  ".join(offenders)
        )
