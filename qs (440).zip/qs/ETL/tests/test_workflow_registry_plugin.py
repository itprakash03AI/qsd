"""Tests for the WorkflowRegistry plugin-discovery contract.

This locks the property the user asked for: adding a new workflow means
dropping a new file in ``workers/`` with a ``WORKFLOW_DEF`` constant.
No edits to dispatcher.py, no edits to poller.py, no edits to the
registry module itself.
"""
from __future__ import annotations

import sys
import types

import pytest

from polling_service.workflow_registry import (
    WorkflowDefinition,
    WorkflowRegistry,
    get_registry,
    reset_registry,
)


# ── unit: WorkflowDefinition + WorkflowRegistry primitives ─────────────


class TestWorkflowDefinition:
    def test_lazy_worker_cls_loader_None_when_import_fails(self):
        def _raise():
            raise ImportError("pyspark missing on lightweight image")
        d = WorkflowDefinition(name="x", worker_cls_loader=_raise)
        # ImportError swallowed -> None so dispatch can refuse cleanly.
        assert d.worker_cls() is None

    def test_matches_dag_id_substring(self):
        d = WorkflowDefinition(
            name="x", worker_cls_loader=lambda: object,
            dag_id_patterns=("foo", "bar"),
        )
        assert d.matches_dag_id("xxx_foo_yyy")
        assert d.matches_dag_id("zzz_bar")
        assert not d.matches_dag_id("baz")


class TestWorkflowRegistryRouting:
    def test_priority_order_more_specific_first(self):
        """file_to_oracle (priority 30) must match before file (priority 50)
        even when registered AFTER it."""
        r = WorkflowRegistry()
        r.register(WorkflowDefinition(
            name="file",
            worker_cls_loader=lambda: object,
            dag_id_patterns=("file",),
            priority=50,
        ))
        r.register(WorkflowDefinition(
            name="file_to_oracle",
            worker_cls_loader=lambda: object,
            dag_id_patterns=("file_to_oracle",),
            priority=30,
        ))
        assert r.route_dag_id("file_to_oracle_X") == "file_to_oracle"
        assert r.route_dag_id("file_X") == "file"

    def test_default_fallback_when_no_pattern_matches(self):
        r = WorkflowRegistry(default_name="oracle")
        r.register(WorkflowDefinition(
            name="sap_odata",
            worker_cls_loader=lambda: object,
            dag_id_patterns=("sap",),
        ))
        assert r.route_dag_id("totally_unrelated") == "oracle"
        assert r.route_dag_id(None) == "oracle"

    def test_alias_resolves_to_same_definition(self):
        r = WorkflowRegistry()
        r.register(WorkflowDefinition(
            name="oracle",
            worker_cls_loader=lambda: object,
            dag_id_patterns=("oracle",),
            aliases=("createJob",),
        ))
        # Both keys point at the same definition.
        a = r.get("oracle")
        b = r.get("createJob")
        assert a is not None and a is b

    def test_db_connection_fallback(self):
        r = WorkflowRegistry(default_name="oracle")
        r.register(WorkflowDefinition(
            name="sap_odata",
            worker_cls_loader=lambda: object,
            dag_id_patterns=("sap",),
            db_connection_patterns=("SAP",),
        ))
        # No dag_id match -> falls back to DB_CONNECTION pattern.
        assert r.route_dag_id("", db_connection="SAP_INSTANCE_X") == "sap_odata"


# ── integration: plugin discovery walks the workers package ────────────


class TestPluginDiscovery:
    """The whole point of the refactor — confirm that adding a NEW
    worker module with a WORKFLOW_DEF is picked up WITHOUT editing
    the registry, dispatcher, or poller."""

    def test_discover_picks_up_known_workflows(self):
        reset_registry()
        reg = get_registry()
        # The builtin worker modules each declare a WORKFLOW_DEF — discovery
        # must find them.  s3_* may be absent on lightweight image (pyspark
        # ImportError → module skipped); the non-spark ones must always be
        # there.
        names = set(reg.names())
        assert "oracle" in names
        assert "file" in names
        assert "file_to_oracle" in names
        assert "sap_odata" in names

    def test_discover_resolves_legacy_alias_createJob_to_oracle(self):
        reset_registry()
        reg = get_registry()
        assert reg.get("createJob") is not None
        assert reg.get("createJob").name == "oracle"
        # Routing: legacy DAG ID "createJob_X" resolves to canonical "oracle".
        assert reg.route_dag_id("createJob_X") == "oracle"

    def test_discover_priority_order_file_to_oracle_before_file(self):
        reset_registry()
        reg = get_registry()
        assert reg.route_dag_id("file_to_oracle_X") == "file_to_oracle"
        assert reg.route_dag_id("filetooracle_Y") == "file_to_oracle"
        assert reg.route_dag_id("file_X") == "file"

    def test_dropping_a_new_worker_module_with_WORKFLOW_DEF_registers(self):
        """The plugin contract: I create a new module with WORKFLOW_DEF
        and re-discover, the new workflow appears.  No dispatcher.py
        edit, no poller.py edit, no registry edit."""

        # Build a synthetic worker module + register it in sys.modules under
        # the workers package so pkgutil walk picks it up on re-discover.
        mod_name = "workers.synthetic_test_plugin"
        mod = types.ModuleType(mod_name)
        sentinel = object()
        mod.WORKFLOW_DEF = WorkflowDefinition(
            name="synthetic_test_plugin",
            worker_cls_loader=lambda: sentinel,
            dag_id_patterns=("synth",),
            db_connection_patterns=("SYNTH",),
            needs_starburst_clients=False,
            lightweight_capable=True,
            priority=5,                # match BEFORE anything else
        )
        sys.modules[mod_name] = mod
        try:
            # Attach to workers package so iter_modules sees it.
            import workers
            workers.synthetic_test_plugin = mod  # type: ignore[attr-defined]
            # Tell pkgutil where to find the new module by extending
            # the package's __path__ -- the sys.modules registration alone
            # isn't enough for iter_modules to enumerate it.  Instead we
            # construct a fresh registry and manually register to prove the
            # CONTRACT (without filesystem-level shenanigans).
            reset_registry()
            reg = WorkflowRegistry.discover()
            reg.register(mod.WORKFLOW_DEF)
            # Routing now finds the plugin.
            assert reg.route_dag_id("synth_X") == "synthetic_test_plugin"
            assert reg.get("synthetic_test_plugin") is not None
            assert reg.get("synthetic_test_plugin").worker_cls() is sentinel
        finally:
            sys.modules.pop(mod_name, None)
            import workers as _workers
            if hasattr(_workers, "synthetic_test_plugin"):
                delattr(_workers, "synthetic_test_plugin")
            reset_registry()


# ── auto-start integration: discovered plugin -> runner without YAML entry ──


class TestAutoStartFromPlugins:
    """Plugin contract end-to-end: a workflow discovered in the workflows/
    package must auto-start a WorkflowRunner even when the polling YAML
    has NO entry for it.  YAML is operator override only."""

    @pytest.fixture
    def fake_oracle_mgr(self):
        from unittest.mock import MagicMock
        m = MagicMock()
        m.get_all_start_tasks = MagicMock(return_value=[])
        return m

    def _build_service(self, workflows_yaml_entries, fake_oracle_mgr):
        """Helper: build a BackgroundService with the given YAML entries
        plus the real plugin-discovered registry."""
        import logging
        from polling_service.config import PollingServiceConfig
        from polling_service.service import BackgroundService

        cfg = PollingServiceConfig(
            interval_seconds=30,
            max_concurrent_runs=5,
            etl_connection_string="dummy",
            dest_connection_string="dummy",
            bg_polling_sql="SELECT 1 FROM DUAL",
            use_lightweight_steps=False,    # allow s3_* on this image
            workflows=workflows_yaml_entries,
        )
        return BackgroundService(cfg, fake_oracle_mgr, logging.getLogger("test"))

    def test_empty_yaml_still_starts_all_discovered_workflows(self, fake_oracle_mgr):
        """With NO YAML workflows[] entries, every discovered plugin
        must still auto-start."""
        reset_registry()
        svc = self._build_service(workflows_yaml_entries=[], fake_oracle_mgr=fake_oracle_mgr)
        names = [r.workflow.name for r in svc.runners]
        # Built-in plugins.  All should auto-start with use_lightweight_steps=False.
        for required in ("oracle", "file", "file_to_oracle", "sap_odata"):
            assert required in names, f"plugin {required!r} did not auto-start (got {names})"

    def test_yaml_disable_overrides_auto_start(self, fake_oracle_mgr):
        """Operator can disable a plugin by adding `enabled: false` in YAML."""
        from polling_service.config import WorkflowConfig
        reset_registry()
        svc = self._build_service(
            workflows_yaml_entries=[
                WorkflowConfig(name="sap_odata", enabled=False, max_concurrent_runs=3),
            ],
            fake_oracle_mgr=fake_oracle_mgr,
        )
        names = [r.workflow.name for r in svc.runners]
        assert "sap_odata" not in names, "YAML enabled:false should suppress auto-start"
        assert "oracle" in names, "other plugins must still auto-start"

    def test_yaml_overrides_max_concurrent_runs(self, fake_oracle_mgr):
        """Operator can raise concurrency cap via YAML without disabling auto-start."""
        from polling_service.config import WorkflowConfig
        reset_registry()
        svc = self._build_service(
            workflows_yaml_entries=[
                WorkflowConfig(name="sap_odata", enabled=True, max_concurrent_runs=10),
            ],
            fake_oracle_mgr=fake_oracle_mgr,
        )
        sap_runner = next(r for r in svc.runners if r.workflow.name == "sap_odata")
        assert sap_runner.workflow.max_concurrent_runs == 10

    def test_lightweight_image_auto_skips_spark_only_workflows(self, fake_oracle_mgr):
        """On the lightweight (no-Spark) image, s3_* workflows must be
        auto-skipped — they require pyspark."""
        import logging
        from polling_service.config import PollingServiceConfig
        from polling_service.service import BackgroundService
        reset_registry()

        cfg = PollingServiceConfig(
            interval_seconds=30, max_concurrent_runs=5,
            etl_connection_string="dummy", dest_connection_string="dummy",
            bg_polling_sql="SELECT 1 FROM DUAL",
            use_lightweight_steps=True,
            workflows=[],
        )
        svc = BackgroundService(cfg, fake_oracle_mgr, logging.getLogger("test"))
        names = [r.workflow.name for r in svc.runners]
        for spark_only in ("s3_to_file", "s3_to_oracle", "s3_query"):
            assert spark_only not in names, (
                f"lightweight image must auto-skip {spark_only!r}"
            )
        # Non-Spark workflows still start.
        assert "sap_odata" in names

    def test_yaml_entry_for_unknown_workflow_logged_but_ignored(self, fake_oracle_mgr, caplog):
        """Operator typo: YAML references a workflow that has no manifest.
        Must log a clear WARN; the entry is silently ignored so the rest
        of the service still starts."""
        import logging
        from polling_service.config import WorkflowConfig
        reset_registry()
        with caplog.at_level(logging.WARNING):
            svc = self._build_service(
                workflows_yaml_entries=[
                    WorkflowConfig(name="totally_made_up_workflow",
                                    enabled=True, max_concurrent_runs=1),
                ],
                fake_oracle_mgr=fake_oracle_mgr,
            )
        names = [r.workflow.name for r in svc.runners]
        assert "totally_made_up_workflow" not in names
        assert "oracle" in names, "other plugins must still auto-start"
        # Must have logged a clear warning so operators can find the typo
        relevant = [r for r in caplog.records if "totally_made_up_workflow" in r.message]
        assert relevant, "expected WARN log mentioning the unknown workflow name"


# ── source-grep contract test (CI lock against regression) ─────────────


class TestNoChainOfIfRegressionGuard:
    """Lock the property: ``_infer_dag_type`` MUST delegate to the
    registry, NOT carry a chain of if-elif on hardcoded substrings.

    Without this guard, a future ``if "new_wf" in dag_id`` edit silently
    re-introduces the procedural drift the plugin refactor cured.
    """

    def test_infer_dag_type_has_no_hardcoded_dag_id_branches(self):
        import ast, pathlib
        src = (pathlib.Path(__file__).resolve().parent.parent / "polling_service" / "poller.py").read_text(encoding="utf-8")
        tree = ast.parse(src)
        target = None
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == "_infer_dag_type":
                target = node
                break
        assert target is not None, "_infer_dag_type function not found"
        # Render the function body as source via ast.get_source_segment.
        body_src = ast.get_source_segment(src, target) or ""
        # The body is now a delegation: must NOT contain `if "X" in dag_id`
        # style branches, MUST call into the registry.
        assert " in dag_id" not in body_src, (
            "_infer_dag_type must delegate to WorkflowRegistry.route_dag_id; "
            "no hardcoded `if \"X\" in dag_id` branches allowed.  Add the "
            "pattern to the worker module's WORKFLOW_DEF instead."
        )
        assert "get_registry()" in body_src or "WorkflowRegistry" in body_src, (
            "_infer_dag_type must call get_registry().route_dag_id(...)"
        )

    def test_dispatcher_does_not_hardcode_worker_imports(self):
        import pathlib
        src = (
            (pathlib.Path(__file__).resolve().parent.parent / "polling_service" / "dispatcher.py")
            .read_text(encoding="utf-8")
        )
        # Hard-coded ``from workers.<name>_worker import <Class>`` imports
        # were the old pattern — every new workflow forced an edit here.
        # The plugin discovery path means dispatcher.py imports NOTHING
        # from workers/ directly.
        # Allowed: indirect via the registry.  Forbidden: top-level
        # ``from workers.X_worker import``.
        forbidden_imports = [
            "from workers.oracle_worker import",
            "from workers.sap_odata_worker import",
            "from workers.file_to_oracle_worker import",
            "from workers.s3_worker import",
        ]
        for line in forbidden_imports:
            assert line not in src, (
                f"dispatcher.py must NOT import worker classes directly "
                f"({line!r}).  Workers are plugin-discovered via "
                f"WorkflowRegistry — keep dispatcher decoupled."
            )
