"""2026-06-27 contract tests for runtime_env.py chokepoint.

Background:
  qs_credentials reads ``secrets.vault.machine`` from vault_config.yaml
  to drive QSClient's machine-identity-token leg.  That value is
  per-pod-environment (Airflow driver pod = 'tprd', local dev = 'test',
  K8s = 'openshift'), not per-secret.  Pre-2026-06-27 the only way to
  change it was to mount a different vault_config.yaml per pod.

  Operator direction 2026-06-27:
    "i should pass ... from where this program running ... how can u
     missing machine parameter"

  ``runtime_env.py`` is the chokepoint: standalones declare CLI
  --machine / --vault-token-method via ``add_runtime_env_args``,
  ``apply_runtime_env_args`` exports them as env vars BEFORE any
  qs_credentials import.  resolver.py reads those env vars first.

These tests:
  1. Helper API present + correct.
  2. CLI args export to the right env vars.
  3. Pre-existing env vars are NOT clobbered when --machine omitted.
  4. resolver.py reads ETL_VAULT_MACHINE / ETL_VAULT_TOKEN_METHOD
     ahead of vault_config.yaml.
  5. Every Spark/Oracle-style standalone wires the chokepoint.
"""
from __future__ import annotations

import argparse
import os
import sys

import pytest


_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


@pytest.fixture(autouse=True)
def _clear_env(monkeypatch):
    for k in ("ETL_VAULT_MACHINE", "ETL_VAULT_TOKEN_METHOD"):
        monkeypatch.delenv(k, raising=False)


# ──────────────────────────────────────────────────────────────────────
# 1. Helper API
# ──────────────────────────────────────────────────────────────────────


def test_runtime_env_module_present():
    import runtime_env
    assert hasattr(runtime_env, "add_runtime_env_args")
    assert hasattr(runtime_env, "apply_runtime_env_args")


def test_add_runtime_env_args_registers_flags():
    from runtime_env import add_runtime_env_args
    parser = argparse.ArgumentParser()
    add_runtime_env_args(parser)
    # Parse a minimal command line to confirm the flags exist.
    args = parser.parse_args(["--machine", "tprd",
                              "--vault-token-method", "JWT"])
    assert args.machine == "tprd"
    assert args.vault_token_method == "JWT"


def test_add_runtime_env_args_choices_lock():
    """Invalid machine values must be rejected at the argparse layer
    so the operator gets a clear error before the program starts."""
    from runtime_env import add_runtime_env_args
    parser = argparse.ArgumentParser()
    add_runtime_env_args(parser)
    with pytest.raises(SystemExit):
        parser.parse_args(["--machine", "bogus"])


# ──────────────────────────────────────────────────────────────────────
# 2. apply_runtime_env_args -- CLI -> env var
# ──────────────────────────────────────────────────────────────────────


def test_cli_machine_exports_to_env():
    from runtime_env import add_runtime_env_args, apply_runtime_env_args
    parser = argparse.ArgumentParser()
    add_runtime_env_args(parser)
    args = parser.parse_args(["--machine", "tprd"])
    apply_runtime_env_args(args)
    assert os.environ["ETL_VAULT_MACHINE"] == "tprd"


def test_cli_token_method_exports_to_env():
    from runtime_env import add_runtime_env_args, apply_runtime_env_args
    parser = argparse.ArgumentParser()
    add_runtime_env_args(parser)
    args = parser.parse_args(["--vault-token-method", "approle"])
    apply_runtime_env_args(args)
    assert os.environ["ETL_VAULT_TOKEN_METHOD"] == "approle"


def test_no_cli_arg_does_not_clobber_existing_env(monkeypatch):
    """Pre-existing ETL_VAULT_MACHINE in pod env wins when --machine
    is omitted.  Operator may have set it via spark.driverEnv.* or
    Helm chart -- must not silently overwrite."""
    from runtime_env import add_runtime_env_args, apply_runtime_env_args
    monkeypatch.setenv("ETL_VAULT_MACHINE", "tprd")
    parser = argparse.ArgumentParser()
    add_runtime_env_args(parser)
    args = parser.parse_args([])  # no flags
    apply_runtime_env_args(args)
    assert os.environ["ETL_VAULT_MACHINE"] == "tprd"


# ──────────────────────────────────────────────────────────────────────
# 3. resolver.py reads env var ahead of vault_config.yaml
# ──────────────────────────────────────────────────────────────────────


def test_resolver_reads_env_var_first(monkeypatch, tmp_path):
    """Plant a vault_config.yaml with machine='openshift', set the
    env var to 'test', and confirm the env var wins.  Locks the
    resolver.py:282 precedence."""
    import qs_credentials.resolver as r
    import qs_credentials.cache as c

    # Plant yaml.
    yaml_text = (
        "secrets:\n"
        "  enabled: true\n"
        "  vault:\n"
        "    machine: openshift\n"
        "    token_method: JWT\n"
        "  refs:\n"
        "    test_ref:\n"
        "      type: AD_accounts\n"
        "      auth_url: x\n"
        "      role_name: r\n"
        "      role_type: JWT\n"
        "      secret_url: x\n"
    )
    yaml_file = tmp_path / "vault_config.yaml"
    yaml_file.write_text(yaml_text)

    # Stub the loader path to our temp file.
    original = r._VAULT_CONFIG_PATHS if hasattr(r, "_VAULT_CONFIG_PATHS") else None
    monkeypatch.setattr(r, "_load_vault_yaml",
                        lambda: {"enabled": True,
                                 "vault": {"machine": "openshift",
                                           "token_method": "JWT"},
                                 "refs": {"test_ref": {
                                     "type": "AD_accounts",
                                     "auth_url": "x",
                                     "role_name": "r",
                                     "role_type": "JWT",
                                     "secret_url": "x",
                                 }}})
    r._vault_settings.cache_clear()
    r._secret_refs.cache_clear()

    # Env var override.
    monkeypatch.setenv("ETL_VAULT_MACHINE", "test")

    captured = {}

    def _fake_fetch(self, name, ref, *, machine, token_method):
        captured["machine"] = machine
        captured["token_method"] = token_method
        return ("u", "p", "")

    monkeypatch.setattr(c.QSCredCache, "fetch_with_fallback", _fake_fetch)
    monkeypatch.setattr(r, "is_vault_enabled", lambda *a, **k: True)

    r._cred_cache.reset_mem()
    r._resolve_with_cache("test_ref", workflow_config={})

    assert captured["machine"] == "test", (
        "ETL_VAULT_MACHINE env var must override vault_config.yaml's "
        "secrets.vault.machine field"
    )


# ──────────────────────────────────────────────────────────────────────
# 4. Every standalone wires the chokepoint
# ──────────────────────────────────────────────────────────────────────


_STANDALONES = [
    "oracle_standalone.py",
    "file_standalone.py",
    "file_to_oracle_standalone.py",
    "s3_standalone_runner.py",
    "s3_query_standalone.py",
    "sap_odata_standalone.py",
]


@pytest.mark.parametrize("rel", _STANDALONES)
def test_standalone_wires_runtime_env_chokepoint(rel):
    """Each standalone must import + call BOTH halves of the chokepoint.
    Lock it with a source grep so a future refactor can't drop one
    half (e.g., add the arg but forget to apply it -> env var never set)."""
    path = os.path.join(_ETL_ROOT, rel)
    assert os.path.exists(path), f"{rel} missing"
    with open(path, encoding="utf-8") as f:
        src = f.read()
    assert "from runtime_env import" in src, (
        f"{rel}: must import from runtime_env to gain --machine support"
    )
    assert "add_runtime_env_args(parser)" in src, (
        f"{rel}: must call add_runtime_env_args(parser) before parse_args"
    )
    assert "apply_runtime_env_args(args" in src, (
        f"{rel}: must call apply_runtime_env_args(args) after parse_args -- "
        "without this, --machine has no effect on qs_credentials"
    )
