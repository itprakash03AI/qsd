"""Enterprise feature tests for the polling-service plugin system.

Covers:
  * Manifest schema validation (rejected at registration)
  * Per-plugin telemetry counters + percentiles
  * Lifecycle hooks (on_register / on_runner_start / on_runner_stop)
  * Priority collision detection (startup error)
  * Pattern overlap warnings (logged, not fatal)
  * Entry-points discovery contract
  * Diagnostic CLI subcommands
  * /workflows/<name> health endpoint shape
"""
from __future__ import annotations

import json
import logging
import subprocess
import sys
import time
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from polling_service.workflow_registry import (
    CURRENT_MANIFEST_VERSION,
    PluginManifest,
    PluginTelemetry,
    PluginValidationError,
    StartupValidationError,
    WorkflowRegistry,
    get_registry,
    reset_registry,
)


# ── manifest schema validation ──────────────────────────────────────────


class TestManifestValidation:
    """register() must reject malformed manifests with actionable errors."""

    def test_empty_name_rejected(self):
        m = PluginManifest(name="", worker_cls_loader=lambda: object)
        errors = m.validate()
        assert any("name" in e for e in errors)

    def test_invalid_name_rejected(self):
        m = PluginManifest(name="bad-name-with-dashes",
                            worker_cls_loader=lambda: object,
                            dag_id_patterns=("x",))
        errors = m.validate()
        assert any("identifier" in e for e in errors)

    def test_invalid_semver_rejected(self):
        m = PluginManifest(name="x", version="not-semver",
                            worker_cls_loader=lambda: object)
        errors = m.validate()
        assert any("semver" in e for e in errors)

    def test_future_manifest_version_rejected(self):
        m = PluginManifest(name="x",
                            manifest_version=CURRENT_MANIFEST_VERSION + 99,
                            worker_cls_loader=lambda: object)
        errors = m.validate()
        assert any("manifest_version" in e for e in errors)

    def test_non_callable_loader_rejected(self):
        m = PluginManifest(name="x", worker_cls_loader="not callable")
        errors = m.validate()
        assert any("callable" in e for e in errors)

    def test_negative_priority_rejected(self):
        m = PluginManifest(name="x", worker_cls_loader=lambda: object,
                            priority=-1)
        errors = m.validate()
        assert any("priority" in e for e in errors)

    def test_register_raises_PluginValidationError_on_bad_manifest(self):
        reg = WorkflowRegistry()
        bad = PluginManifest(name="", worker_cls_loader=lambda: object)
        with pytest.raises(PluginValidationError) as exc:
            reg.register(bad)
        assert "invalid" in str(exc.value).lower()

    # ── deep-dive-2 hardening: stricter validation rules ──────────────

    def test_name_starting_with_digit_rejected(self):
        """Deep-dive finding: '123abc' is alnum but NOT a valid Python
        identifier — would break import + step_mapping section lookup."""
        m = PluginManifest(name="123abc",
                            worker_cls_loader=lambda: object,
                            dag_id_patterns=("x",))
        errors = m.validate()
        assert any("identifier" in e for e in errors), \
            f"digit-prefix name should fail identifier check; got errors={errors}"

    def test_name_with_dash_rejected(self):
        m = PluginManifest(name="has-dash", worker_cls_loader=lambda: object,
                            dag_id_patterns=("x",))
        assert any("identifier" in e for e in m.validate())

    def test_name_with_dot_rejected(self):
        m = PluginManifest(name="has.dot", worker_cls_loader=lambda: object,
                            dag_id_patterns=("x",))
        assert any("identifier" in e for e in m.validate())

    def test_empty_patterns_AND_empty_db_patterns_rejected_as_orphan(self):
        """Deep-dive finding: a manifest with no patterns at all can
        never match a polling row.  Silent orphan — must fail."""
        m = PluginManifest(name="orphan",
                            worker_cls_loader=lambda: object,
                            dag_id_patterns=(),
                            db_connection_patterns=())
        errors = m.validate()
        assert any("no polling row will ever route" in e for e in errors), \
            f"orphan manifest should fail; got errors={errors}"

    def test_db_only_patterns_pass(self):
        """A manifest can route via DB_CONNECTION alone (no OTG_DAG_ID
        patterns) — that's a legitimate fallback path."""
        m = PluginManifest(name="db_only",
                            worker_cls_loader=lambda: object,
                            dag_id_patterns=(),
                            db_connection_patterns=("MY_DB",))
        errors = m.validate()
        assert not errors, f"db-only manifest should pass; got {errors}"

    def test_dag_only_patterns_pass(self):
        m = PluginManifest(name="dag_only",
                            worker_cls_loader=lambda: object,
                            dag_id_patterns=("mydag",),
                            db_connection_patterns=())
        errors = m.validate()
        assert not errors, f"dag-only manifest should pass; got {errors}"

    def test_duplicate_patterns_within_manifest_rejected(self):
        """Deep-dive finding: dag_id_patterns=('file', 'file', 'file')
        is wasteful — substring match short-circuits on first hit anyway.
        Refuse so authors fix the typo."""
        m = PluginManifest(name="dupe",
                            worker_cls_loader=lambda: object,
                            dag_id_patterns=("file", "file", "doc"))
        errors = m.validate()
        assert any("duplicate" in e for e in errors), \
            f"duplicate patterns should fail; got {errors}"


# ── telemetry ───────────────────────────────────────────────────────────


class TestPluginTelemetry:
    def test_counts_dispatched_completed_failed_timed_out(self):
        t = PluginTelemetry(name="x")
        t.record_dispatch(); t.record_dispatch(); t.record_dispatch()
        t.record_success(duration_s=1.0)
        t.record_failure(reason="boom", duration_s=0.5)
        t.record_timeout(duration_s=30.0)
        snap = t.snapshot()
        assert snap["dispatched"] == 3
        assert snap["completed"] == 1
        assert snap["failed"] == 1
        assert snap["timed_out"] == 1
        assert snap["last_failure_reason"]   # populated by failure OR timeout
        assert snap["success_rate"] == pytest.approx(1 / 3, rel=0.01)

    def test_p50_p99_computed_from_rolling_window(self):
        t = PluginTelemetry(name="x")
        for s in [0.1, 0.2, 0.5, 1.0, 2.0]:
            t.record_success(duration_s=s)
        snap = t.snapshot()
        assert snap["duration_sample_count"] == 5
        assert 0 < snap["duration_p50_s"] <= 2.0
        assert snap["duration_p99_s"] >= snap["duration_p50_s"]

    def test_thread_safe_counter(self):
        import threading
        t = PluginTelemetry(name="x")
        def _bump():
            for _ in range(1000):
                t.record_dispatch()
        threads = [threading.Thread(target=_bump) for _ in range(8)]
        for th in threads: th.start()
        for th in threads: th.join()
        assert t.snapshot()["dispatched"] == 8000


# ── lifecycle hooks ─────────────────────────────────────────────────────


class TestLifecycleHooks:
    def test_on_register_fires_after_registration(self):
        calls = []
        m = PluginManifest(
            name="hook_test",
            worker_cls_loader=lambda: object,
            dag_id_patterns=("hook_test",),
            on_register=lambda mf: calls.append(("reg", mf.name)),
        )
        reg = WorkflowRegistry()
        reg.register(m)
        assert calls == [("reg", "hook_test")]

    def test_on_register_failure_does_NOT_break_registration(self, caplog):
        def _boom(mf):
            raise RuntimeError("simulated hook crash")
        m = PluginManifest(
            name="bad_hook",
            worker_cls_loader=lambda: object,
            dag_id_patterns=("bad_hook",),
            on_register=_boom,
        )
        reg = WorkflowRegistry()
        with caplog.at_level(logging.WARNING):
            reg.register(m)
        # Manifest is still registered
        assert reg.get("bad_hook") is not None
        # Failure was logged
        assert any("on_register hook" in r.message for r in caplog.records)


# ── collision detection ────────────────────────────────────────────────


class TestCollisionDetection:
    def test_priority_collision_with_shared_pattern_is_startup_error(self):
        reg = WorkflowRegistry()
        reg.register(PluginManifest(
            name="a", worker_cls_loader=lambda: object,
            dag_id_patterns=("shared",), priority=50,
        ))
        reg.register(PluginManifest(
            name="b", worker_cls_loader=lambda: object,
            dag_id_patterns=("shared", "different"), priority=50,
        ))
        priority_collisions, _ = reg.detect_collisions()
        assert priority_collisions, "expected priority collision"
        assert priority_collisions[0][2] == 50    # priority
        assert "shared" in priority_collisions[0][3]

    def test_pattern_substring_overlap_warns_not_errors(self):
        reg = WorkflowRegistry()
        reg.register(PluginManifest(
            name="oracle", worker_cls_loader=lambda: object,
            dag_id_patterns=("oracle",), priority=80,
        ))
        reg.register(PluginManifest(
            name="s3_to_oracle", worker_cls_loader=lambda: object,
            dag_id_patterns=("s3_to_oracle",), priority=10,
        ))
        _, overlaps = reg.detect_collisions()
        assert overlaps, "expected pattern overlap detection"
        # oracle (pri 80) loses to s3_to_oracle (pri 10) when 'oracle' is
        # substring of 's3_to_oracle'.
        loser = overlaps[0][0]
        winner = overlaps[0][1]
        assert loser.name == "oracle"
        assert winner.name == "s3_to_oracle"

    def test_discover_with_strict_collisions_raises_StartupValidationError(self):
        """Plugin discovery uses strict_collisions=True by default.
        A priority collision in production plugins MUST stop startup."""
        # Build a registry with a known collision then re-validate.
        reg = WorkflowRegistry()
        reg.register(PluginManifest(name="a", worker_cls_loader=lambda: object,
                                     dag_id_patterns=("shared",), priority=50))
        reg.register(PluginManifest(name="b", worker_cls_loader=lambda: object,
                                     dag_id_patterns=("shared",), priority=50))
        # Mimic what discover()'s strict-collisions check does:
        from polling_service.workflow_registry import StartupValidationError
        priority_collisions, _ = reg.detect_collisions()
        assert priority_collisions
        # Simulate strict-mode raising
        with pytest.raises(StartupValidationError):
            if priority_collisions:
                raise StartupValidationError("simulated collision")


# ── entry-points contract ──────────────────────────────────────────────


class TestEntryPointsContract:
    def test_discover_skips_entry_points_when_disabled(self):
        # load_entry_points=False is the hermetic-test path
        reg = WorkflowRegistry.discover(load_entry_points=False,
                                          strict_collisions=False)
        # Built-in plugins still discovered
        assert "oracle" in reg
        # No entry-point-sourced plugins
        for d in reg:
            assert not d.source.startswith("entry_point"), (
                f"{d.name!r} should not be entry-point sourced when disabled"
            )

    def test_external_manifest_via_register_carries_source_tag(self):
        from dataclasses import replace
        reg = WorkflowRegistry()
        external = PluginManifest(
            name="external_test",
            worker_cls_loader=lambda: object,
            dag_id_patterns=("external_test",),
            source="entry_point:my_pkg.workflows:my_plugin",
        )
        reg.register(external)
        assert reg.get("external_test").source.startswith("entry_point:")


# ── diagnostic CLI ─────────────────────────────────────────────────────


class TestDiagnosticCLI:
    """Subprocess-driven tests for `python -m polling_service.plugins`.

    These run the actual CLI module so we catch importability issues +
    arg-parsing regressions that unit-level tests would miss.
    """

    @classmethod
    def _cli(cls, *args: str) -> subprocess.CompletedProcess:
        etl_root = Path(__file__).resolve().parent.parent
        return subprocess.run(
            [sys.executable, "-m", "polling_service.plugins", *args],
            cwd=str(etl_root),
            capture_output=True, text=True, timeout=20,
        )

    def test_cli_list_emits_table_with_known_plugins(self):
        r = self._cli("list")
        assert r.returncode == 0, f"CLI failed: {r.stderr}"
        assert "oracle" in r.stdout
        assert "sap_odata" in r.stdout
        assert "file_to_oracle" in r.stdout

    def test_cli_list_json_emits_parseable_payload(self):
        r = self._cli("--json", "list")
        assert r.returncode == 0, f"CLI failed: {r.stderr}"
        # The --json flag emits JSON to stdout AND startup logs to stderr;
        # the stdout must be parseable JSON.
        # Locate the first '[' to skip any logging noise.
        payload = r.stdout[r.stdout.index("["):]
        data = json.loads(payload)
        names = [r["name"] for r in data]
        assert "oracle" in names

    def test_cli_inspect_emits_manifest(self):
        r = self._cli("inspect", "oracle")
        assert r.returncode == 0
        payload = r.stdout[r.stdout.index("{"):]
        data = json.loads(payload)
        assert data["name"] == "oracle"
        assert data["version"]
        assert data["priority"] == 80

    def test_cli_inspect_unknown_returns_2(self):
        r = self._cli("inspect", "totally_unknown_plugin")
        assert r.returncode == 2

    def test_cli_validate_returns_zero_when_all_valid(self):
        r = self._cli("validate")
        assert r.returncode == 0, f"CLI failed: {r.stderr}"
        assert "valid:" in r.stdout

    def test_cli_routing_test_resolves_known_dag_id(self):
        r = self._cli("routing-test", "FILE_TO_ORACLE_TEST")
        assert r.returncode == 0
        assert "file_to_oracle" in r.stdout

    def test_cli_collisions_runs_clean_on_builtin_registry(self):
        # The built-in 7 plugins have substring overlaps but no priority
        # collisions, so collisions command should return 0.
        r = self._cli("collisions")
        assert r.returncode == 0


# ── health endpoint integration ────────────────────────────────────────


class TestWorkflowDetailHealthEndpoint:
    """Verify /workflows/<name> response shape."""

    def test_endpoint_returns_manifest_and_telemetry_keys(self, monkeypatch):
        # Construct the FastAPI app + inject a service so the endpoint
        # has something to query.
        from polling_service import health
        from polling_service.config import PollingServiceConfig
        from polling_service.service import BackgroundService

        reset_registry()
        cfg = PollingServiceConfig(
            interval_seconds=30, max_concurrent_runs=2,
            etl_connection_string="dummy", dest_connection_string="dummy",
            bg_polling_sql="SELECT 1 FROM DUAL",
            use_lightweight_steps=False,
            workflows=[],
        )
        fake_oracle = MagicMock()
        svc = BackgroundService(cfg, fake_oracle, logging.getLogger("test"))
        health.init_health_service(svc, fake_oracle, "dummy")

        from fastapi.testclient import TestClient
        client = TestClient(health.app)

        r = client.get("/workflows/oracle")
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["name"] == "oracle"
        assert body["registered"] is True
        assert body["manifest"] is not None
        assert body["manifest"]["version"] == "1.0.0"
        assert body["manifest"]["source"] == "builtin"
        assert "telemetry" in body
        # Telemetry block should have the standard keys (zeros, since no
        # dispatches yet).
        assert body["telemetry"]["dispatched"] == 0
        assert body["telemetry"]["completed"] == 0

    def test_endpoint_returns_404_for_unknown_plugin(self):
        from polling_service import health
        from polling_service.config import PollingServiceConfig
        from polling_service.service import BackgroundService

        reset_registry()
        cfg = PollingServiceConfig(
            interval_seconds=30, max_concurrent_runs=2,
            etl_connection_string="dummy", dest_connection_string="dummy",
            bg_polling_sql="SELECT 1 FROM DUAL",
            use_lightweight_steps=False, workflows=[],
        )
        svc = BackgroundService(cfg, MagicMock(), logging.getLogger("test"))
        health.init_health_service(svc, MagicMock(), "dummy")

        from fastapi.testclient import TestClient
        client = TestClient(health.app)

        r = client.get("/workflows/totally_unknown_plugin")
        assert r.status_code == 404
