"""Regression tests for the Batch 4 HOTFIX-2 (2026-07-01).

Locks each of the ~18 fixes surfaced by the four-lens adversarial
audit (security / K8s lifecycle / concurrency / data-plane).  Each
test is structural where a runtime test isn't possible without real
infrastructure (Oracle / SMTP / K8s).
"""
from __future__ import annotations

import inspect
import os
import re
import sys
import threading

import pytest


_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


def _read_main() -> str:
    with open(os.path.join(_ETL_ROOT, "polling_service", "main.py"),
              "r", encoding="utf-8") as f:
        return f.read()


# ── CRIT-CONC: pinned claim connection thread safety ────────────────────


class TestClaimConnSessionLock:
    def test_session_lock_attribute_exists(self):
        from managers import oracle_metadata_manager as omm
        # Constructor must initialise the session-lock placeholder.
        src = inspect.getsource(omm.OracleMetadataManager.__init__)
        assert "_claim_session_lock" in src

    def test_try_claim_uses_session_lock(self):
        from managers import oracle_metadata_manager as omm
        src = inspect.getsource(
            omm.OracleMetadataManager._try_claim_run_sync
        )
        assert "_get_claim_session_lock" in src, (
            "_try_claim_run_sync must serialise cursor ops via the "
            "pinned session lock -- oracledb Connection is not "
            "thread-safe across concurrent to_thread workers"
        )

    def test_release_claim_uses_session_lock(self):
        from managers import oracle_metadata_manager as omm
        src = inspect.getsource(
            omm.OracleMetadataManager._release_run_claim_sync
        )
        assert "_get_claim_session_lock" in src


# ── CRIT-DATA: claim connection reopen refuses when held ───────────────


class TestClaimConnReopenGuard:
    def test_get_or_create_refuses_reopen_when_held(self):
        from managers import oracle_metadata_manager as omm
        src = inspect.getsource(
            omm.OracleMetadataManager._get_or_create_claim_connection
        )
        # The refuse-reopen path must consult has_held_locks() and
        # raise (fail-CLOSED), NOT silently orphan.
        assert "has_held_locks" in src, (
            "reopen path must check has_held_locks before reopening"
        )
        assert "reopen refused" in src or "reopen (would orphan" in src

    def test_holds_set_updated_on_claim_and_release(self):
        from managers import oracle_metadata_manager as omm
        claim_src = inspect.getsource(
            omm.OracleMetadataManager._try_claim_run_sync
        )
        release_src = inspect.getsource(
            omm.OracleMetadataManager._release_run_claim_sync
        )
        assert "_register_held_lock" in claim_src, (
            "_try_claim_run_sync must register held locks so the "
            "reopen-guard knows we own them"
        )
        assert "_unregister_held_lock" in release_src, (
            "_release_run_claim_sync must unregister held locks so "
            "the reopen path is unblocked once we drain"
        )


# ── CRIT-DATA: telemetry snapshot restore guardrails ───────────────────


class TestSnapshotRestoreGuardrails:
    def test_worker_id_mismatch_rejected(self, tmp_path):
        from polling_service.telemetry_persist import (
            restore_snapshot, write_snapshot,
        )
        p = str(tmp_path / "snap.json")
        # write with worker_id=A, restore with expected=B -> refuse.
        write_snapshot(p, worker_id="worker_A")
        result = restore_snapshot(p, expected_worker_id="worker_B")
        assert result["restored"] == 0
        assert "worker_id" in result.get("reason", "").lower()

    def test_stale_snapshot_rejected(self, tmp_path, monkeypatch):
        import json
        p = str(tmp_path / "snap.json")
        # Craft a payload with a saved_at_utc from 2 years ago.
        payload = {
            "schema_version": 1,
            "saved_at_utc":   "2020-01-01T00:00:00+00:00",
            "worker_id":      "w1",
            "telemetry":      {},
            "dead_letter":    {},
        }
        with open(p, "w", encoding="utf-8") as f:
            json.dump(payload, f)

        from polling_service.telemetry_persist import restore_snapshot
        result = restore_snapshot(p, expected_worker_id="w1", max_age_s=60)
        assert result["restored"] == 0
        assert "old" in result.get("reason", "").lower()

    def test_absurd_counter_capped(self, tmp_path, monkeypatch):
        # Direct-check the _cap helper via a synthesised snapshot.
        # We build a snapshot with dispatched=10**20 and confirm the
        # per-field cap kicks in.
        from polling_service import telemetry_persist as tp
        assert hasattr(tp, "_MAX_COUNTER_VALUE")
        assert tp._MAX_COUNTER_VALUE < 10 ** 18


# ── CRIT-SEC: SQL injection guards on bulk_copy / load_csv ─────────────


class TestSqlInjectionGuards:
    def test_bulk_copy_validates_table_and_columns(self):
        from managers import oracledblib
        src = inspect.getsource(oracledblib.OracleDBLib.bulk_copy)
        assert "_validate_name(table_name)" in src, (
            "bulk_copy must validate table_name before interpolating"
        )
        assert "_validate_name(str(_col))" in src or "_validate_name(_col)" in src

    def test_load_csv_validates_table_and_header_columns(self):
        from managers import oracledblib
        src = inspect.getsource(oracledblib.OracleDBLib.load_csv_to_oracle)
        assert "_validate_name(table_name)" in src
        assert "for _col in columns" in src
        assert "_validate_name(_col)" in src


# ── CRIT-SEC: /workflows/{name} auth-gated ──────────────────────────────


class TestWorkflowDetailAuthed:
    def test_workflow_detail_has_require_admin(self):
        from polling_service import health
        src = inspect.getsource(health.workflow_detail)
        assert "require_admin" in src, (
            "/workflows/{name} must gate on require_admin -- response "
            "carries last_failure_reason that can leak Trino/Oracle "
            "URL fragments"
        )


# ── CRIT-SEC: prod-mode fail-CLOSED on missing token ────────────────────


class TestProdAuthFailClosed:
    def test_prod_no_token_raises(self, monkeypatch):
        monkeypatch.setenv("WORKFLOW_ENV", "prod")
        monkeypatch.delenv("POLLING_ADMIN_TOKEN", raising=False)

        from polling_service import auth
        import importlib
        importlib.reload(auth)
        with pytest.raises(auth.ProdAuthMisconfigured):
            auth.audit_prod_auth_posture()

    def test_prod_short_token_raises(self, monkeypatch):
        monkeypatch.setenv("WORKFLOW_ENV", "prod")
        monkeypatch.setenv("POLLING_ADMIN_TOKEN", "short")

        from polling_service import auth
        import importlib
        importlib.reload(auth)
        with pytest.raises(auth.ProdAuthMisconfigured):
            auth.audit_prod_auth_posture()

    def test_prod_valid_token_ok(self, monkeypatch):
        monkeypatch.setenv("WORKFLOW_ENV", "prod")
        monkeypatch.setenv(
            "POLLING_ADMIN_TOKEN", "a" * 32,   # 32 chars >= _MIN_TOKEN_LEN
        )

        from polling_service import auth
        import importlib
        importlib.reload(auth)
        # No raise.
        auth.audit_prod_auth_posture()


# ── CRIT-SEC: DSN scrubbed from parse-failure log ──────────────────────


class TestDsnNotLeakedFromParseFailure:
    def test_parse_failure_uses_type_not_str(self):
        from managers import oracle_metadata_manager as omm
        src = inspect.getsource(
            omm.OracleMetadataManager._get_or_create_claim_connection
        )
        # The failure message must include type(_parse_exc).__name__,
        # NOT the raw exception body.
        assert "type(_parse_exc).__name__" in src, (
            "parse-failure message must not echo the raw exception "
            "body (may include DSN with embedded creds)"
        )


# ── CRIT-K8S: readiness-fail-first + drain gate ────────────────────────


class TestReadinessFailFirst:
    def test_health_ready_checks_draining(self):
        from polling_service import health
        src = inspect.getsource(health.health_ready)
        assert "_is_draining" in src, (
            "/health/ready must consult drain state and 503 as soon "
            "as stop() fires so K8s removes the pod from endpoints"
        )

    def test_is_draining_reads_stopped_event(self):
        from polling_service import health
        src = inspect.getsource(health._is_draining)
        assert "_stopped_event" in src
        assert "_shutdown_done" in src


# ── CRIT-K8S: signal handlers install BEFORE Oracle connect ────────────


class TestSignalHandlersInstalledEarly:
    def test_signal_install_before_oracle(self):
        src = _read_main()
        # Find the byte-offset of the signal handler install and the
        # OracleMetadataManager construction; the former must come FIRST.
        idx_sig = src.find("_handle_signal_early")
        idx_ora = src.find("asyncio.to_thread(\n        OracleMetadataManager")
        idx_ora_flat = src.find("asyncio.to_thread(OracleMetadataManager")
        idx_ora_any = min(
            [i for i in (idx_ora, idx_ora_flat) if i != -1] + [10 ** 9]
        )
        assert idx_sig != -1, "main.py must install _handle_signal_early"
        assert idx_ora_any != 10 ** 9, (
            "main.py must construct OracleMetadataManager"
        )
        assert idx_sig < idx_ora_any, (
            "signal handlers must be installed BEFORE the Oracle "
            "connect so SIGTERM during pool retry is graceful"
        )


# ── HIGH-SEC: audit_log CRLF strip ──────────────────────────────────────


class TestAuditLogCrlfStrip:
    def test_sanitize_header_strips_crlf(self):
        from polling_service.health import _sanitize_header
        assert _sanitize_header("1.2.3.4\nAUDIT injected", 200) == (
            "1.2.3.4AUDIT injected"
        )
        assert _sanitize_header("safe-agent/1.0", 120) == "safe-agent/1.0"
        assert "\r" not in _sanitize_header("a\rb\nc", 10)

    def test_audit_log_applies_sanitizer(self):
        from polling_service import health
        src = inspect.getsource(health._audit_log)
        assert "_sanitize_header" in src


# ── HIGH-SEC: scrubber gap coverage ────────────────────────────────────


class TestScrubberExpandedPatterns:
    @pytest.mark.parametrize("secret,pattern", [
        ("Bearer eyJabcdefghij.eyJklmnopqrst.uvwxyz1234", "BEARER-REDACTED"),
        ("password=hunter2", "password=***"),
        ("pwd=hunter2",      "pwd=***"),
        ("api_key=abc123def456", "api_key=***"),
        ("client_secret=abc",    "client_secret=***"),
        ("AIzaSyDdI0hCZtE6vySjMm-WEfRq3CPzqKqqsHI", "GCP-KEY-REDACTED"),
        ("ghp_" + "a" * 40, "GITHUB-TOKEN-REDACTED"),
        ("xoxb-1234567890-abcdef", "SLACK-TOKEN-REDACTED"),
    ])
    def test_pattern_scrubs(self, secret, pattern):
        from polling_service.workflow_registry import _sanitize_reason
        out = _sanitize_reason(f"error context: {secret} more")
        assert pattern in out or "***" in out, (
            f"scrubber didn't redact {secret!r} -> {out!r}"
        )


# ── HIGH-SEC: alerter details scrubbed ─────────────────────────────────


class TestAlerterDetailsScrubbed:
    def test_record_vault_failure_scrubs(self):
        from polling_service import alerter as al
        src = inspect.getsource(al.PluginAlerter.record_vault_failure)
        assert "_scrub(error)" in src, (
            "record_vault_failure must scrub the caller-supplied error"
        )

    def test_record_cross_pod_scrubs(self):
        from polling_service import alerter as al
        src = inspect.getsource(al.PluginAlerter.record_cross_pod_degradation)
        assert "_scrub(reason)" in src


# ── HIGH-SEC: SMTP AUTH requires TLS ───────────────────────────────────


class TestSmtpAuthRequiresTls:
    def test_send_refuses_auth_without_tls(self):
        from polling_service import alerter as al
        src = inspect.getsource(al.PluginAlerter._send)
        # The refuse pattern must be present and BEFORE s.login().
        idx_refuse = src.find("Alerter refusing SMTP AUTH")
        idx_login  = src.find("s.login(self.smtp_user")
        assert idx_refuse != -1, (
            "_send must refuse to login over cleartext SMTP"
        )
        assert idx_login  != -1
        assert idx_refuse < idx_login, (
            "refuse-auth guard must precede s.login()"
        )


# ── HIGH-SEC: oracledblib doesn't mutate root logger ───────────────────


class TestOracleDbLibNoBasicConfig:
    def test_no_logging_basicconfig_at_module_scope(self):
        import managers.oracledblib as m
        src = inspect.getsource(m)
        # Strip comments first.
        exec_only = "\n".join(
            line for line in src.splitlines()
            if not line.lstrip().startswith("#")
        )
        assert "logging.basicConfig" not in exec_only, (
            "oracledblib must NOT call logging.basicConfig at import "
            "-- it stomps on the polling service's log_setup"
        )


# ── HIGH-SEC: /health/ready never echoes raw exception ─────────────────


class TestReadinessResponseSanitized:
    def test_ready_returns_canned_on_error(self):
        from polling_service import health
        src = inspect.getsource(health.health_ready)
        assert '"detail": str(e)' not in src, (
            "readiness must not echo raw Oracle exception text -- "
            "endpoint is UNAUTH by K8s convention"
        )


# ── HIGH-CONC: cache read under lock ───────────────────────────────────


class TestLoadableCacheReadUnderLock:
    def test_reader_takes_lock(self):
        from polling_service import workflow_registry as wr
        src = inspect.getsource(wr._worker_cls_loadable)
        # The .get() must appear INSIDE a `with lock:` block.
        # Grep the src for the pattern.
        m = re.search(
            r"with\s+_WORKER_LOADABLE_CACHE_LOCK:\s*\n\s*cached\s*=\s*_WORKER_LOADABLE_CACHE\.get",
            src,
        )
        assert m is not None, (
            "cache read must occur INSIDE _WORKER_LOADABLE_CACHE_LOCK"
        )


# ── HIGH-CONC: stop() thread-safe ─────────────────────────────────────


class TestStopThreadSafe:
    def test_stop_uses_call_soon_threadsafe(self):
        from polling_service import service as svc
        src = inspect.getsource(svc.BackgroundService.stop)
        assert "call_soon_threadsafe" in src, (
            "stop() must schedule .set() onto the loop thread via "
            "call_soon_threadsafe when called from a non-loop thread"
        )


# ── HIGH-CONC: call_timeout set on acquired connection ────────────────


class TestCallTimeoutSet:
    def test_get_connection_sets_call_timeout(self):
        from managers import oracledblib
        src = inspect.getsource(oracledblib.OracleDBLib._get_connection)
        assert "call_timeout" in src, (
            "_get_connection must set connection.call_timeout so "
            "hung Oracle round-trips get cancelled by the driver"
        )


# ── HIGH-DATA: dead-letter alerted-set + rolling window ────────────────


class TestDeadLetterAlertedSet:
    def test_alerted_set_exists(self):
        from polling_service.dead_letter import DeadLetterTracker
        t = DeadLetterTracker(threshold=2, window_seconds=10)
        assert hasattr(t, "_alerted")

    def test_alerts_only_once_per_run(self):
        from polling_service.dead_letter import DeadLetterTracker
        t = DeadLetterTracker(threshold=2, window_seconds=60)
        t.record_failure(42)
        t.record_failure(42)
        assert t.is_dead_lettered(42)
        assert t.emit_dead_letter(42) is True
        assert t.emit_dead_letter(42) is False, (
            "emit_dead_letter must dedup subsequent calls for same run_id"
        )

    def test_rolling_window_uses_last_failure(self):
        from polling_service.dead_letter import DeadLetterTracker
        import time
        t = DeadLetterTracker(threshold=2, window_seconds=1)
        t.record_failure(1)
        time.sleep(0.5)
        t.record_failure(1)               # last-failure=NOW; count=2
        assert t.is_dead_lettered(1)
        # Sleep just under the window from LAST failure -- must still
        # be tracked.
        time.sleep(0.5)
        assert t.is_dead_lettered(1), (
            "rolling window must be based on LAST failure, not first"
        )


class TestDeadLetterEvictClearsAlertedSet:
    def test_evict_removes_alerted_entry(self):
        from polling_service.dead_letter import DeadLetterTracker
        import time
        t = DeadLetterTracker(threshold=1, window_seconds=1)
        t.record_failure(99)
        t.emit_dead_letter(99)
        assert 99 in t._alerted
        time.sleep(1.2)
        # Any read triggers eviction.
        t.is_dead_lettered(99)
        assert 99 not in t._alerted


# ── HIGH-DATA: alerter throttle revert on submit failure ────────────────


class TestAlerterThrottleRevert:
    def test_alert_reverts_last_emit_on_submit_failure(self):
        from polling_service import alerter as al
        src = inspect.getsource(al.PluginAlerter.alert)
        assert "self._last_emit.pop(key" in src, (
            "alert() must revert the cooldown-slot consume when "
            "submit fails -- otherwise a run of failures silently "
            "swallows the whole cooldown window"
        )


# ── HIGH-K8S: _bg_executor shutdown inside main_async finally ─────────


class TestBgExecutorShutdownExplicit:
    def test_main_finally_shuts_down_bg_executor(self):
        src = _read_main()
        # Find the `finally:` after main_async's outer try, and
        # confirm _bg_executor.shutdown appears within it (not only
        # in the atexit lambda).
        idx_finally = src.find("        health_task.cancel()")
        assert idx_finally != -1
        tail = src[idx_finally: idx_finally + 3000]
        assert "_bg_executor.shutdown" in tail, (
            "main_async must shut down _bg_executor inside the "
            "outer finally, not only via atexit (atexit fires "
            "after the loop closes)"
        )
