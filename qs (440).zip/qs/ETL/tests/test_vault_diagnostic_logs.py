"""2026-06-27 contract tests for vault step-by-step diagnostic logs.

User direction: "need step by step logs when it goes... machine
resolve... token got/credential got... each step exception and proper
message needed" + "why u r not capture wht payload we are passing to
qsclient... exact error etc"

The fetch_secret chokepoint in qs_credentials.vault.__init__.py emits
[vault] STEP 0-3 INFO logs covering:

  STEP 0:  machine resolved + ref config (URLs, role_name -- sanitized)
  STEP 1:  machine identity token   OK (length)  / FAILED (reason)
  STEP 2:  vault session token      OK (length)  / FAILED (reason)
  STEP 3:  read secret payload      OK (shape)   / INVALID (reason)

These tests lock:
  * Helper API surface (explain_invalid_payload, describe_payload_shape,
    describe_ref_for_log)
  * explain_invalid_payload returns ONE specific reason per invalid case
    (not silent True/False)
  * describe_payload_shape never echoes the password verbatim
  * describe_ref_for_log redacts role_id but exposes URLs (operator
    needs URLs for debugging, URLs are not secrets)
  * Cache's final RuntimeError carries the captured diagnostic
"""
from __future__ import annotations

import logging
import os
import sys

import pytest


_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ──────────────────────────────────────────────────────────────────────
# 1. explain_invalid_payload -- one specific reason per rejection
# ──────────────────────────────────────────────────────────────────────


@pytest.mark.parametrize("payload,secret_type,expected_reason_fragment", [
    # AD/DB accounts -- tuple shape required
    (None,                  "AD_accounts", "payload is None"),
    ({"k": "v"},            "AD_accounts", "expected tuple/list"),
    (("user",),             "AD_accounts", "only 1 element"),
    (("", ""),              "AD_accounts", "BOTH user AND password"),
    (("", "pwd"),           "AD_accounts", "user field is blank"),
    (("user", ""),          "AD_accounts", "password field is blank"),
    # kv_secrets -- dict shape required
    (None,                  "kv_secrets",  "payload is None"),
    ([1, 2],                "kv_secrets",  "expected dict"),
    ({},                    "kv_secrets",  "empty dict"),
    ({"k1": "", "k2": ""},  "kv_secrets",  "ALL values are blank"),
])
def test_explain_invalid_payload_returns_specific_reason(
    payload, secret_type, expected_reason_fragment,
):
    from qs_credentials.vault import explain_invalid_payload
    reason = explain_invalid_payload(payload, secret_type)
    assert reason is not None, (
        f"payload {payload!r} for {secret_type!r} should be REJECTED "
        "but explain_invalid_payload returned None (valid)"
    )
    assert expected_reason_fragment.lower() in reason.lower(), (
        f"Expected reason to contain {expected_reason_fragment!r}, "
        f"got {reason!r}"
    )


@pytest.mark.parametrize("payload,secret_type", [
    (("user", "pwd"),                   "AD_accounts"),
    (("user", "pwd", "tns"),            "DB_accounts"),
    ({"access_key": "AKIA", "secret_key": "xyz"}, "kv_secrets"),
])
def test_explain_invalid_payload_returns_none_for_valid(payload, secret_type):
    from qs_credentials.vault import explain_invalid_payload
    assert explain_invalid_payload(payload, secret_type) is None


def test_is_valid_vault_payload_shares_rules_with_explainer():
    """The boolean wrapper must NEVER drift from the explainer --
    is_valid_vault_payload returns False iff explain_invalid_payload
    returns a reason.  Single source of truth."""
    from qs_credentials.vault import is_valid_vault_payload, explain_invalid_payload
    cases = [
        (None, "AD_accounts"),
        (("", ""), "AD_accounts"),
        (("u", "p"), "AD_accounts"),
        ({}, "kv_secrets"),
        ({"k": "v"}, "kv_secrets"),
    ]
    for payload, t in cases:
        assert is_valid_vault_payload(payload, t) is (
            explain_invalid_payload(payload, t) is None
        )


# ──────────────────────────────────────────────────────────────────────
# 2. describe_payload_shape -- credential-safe shape descriptions
# ──────────────────────────────────────────────────────────────────────


def test_describe_payload_shape_redacts_password():
    """Password value must NEVER appear literally in the shape
    description.  Always replaced with '<N chars>' or '<BLANK>'."""
    from qs_credentials.vault import describe_payload_shape
    secret = "very-secret-pwd-12345"
    shape = describe_payload_shape(("alice", secret))
    assert secret not in shape, (
        f"password leaked into shape description: {shape!r}"
    )
    assert "<21 chars>" in shape, (
        f"expected password length in shape, got {shape!r}"
    )


def test_describe_payload_shape_shows_user_literally():
    """User is NOT a secret -- show literally so operator can confirm
    the right account was returned by Vault."""
    from qs_credentials.vault import describe_payload_shape
    shape = describe_payload_shape(("alice_svc", "x"))
    assert "alice_svc" in shape


def test_describe_payload_shape_handles_kv_dict():
    """For kv_secrets dicts, show keys + count of non-blank values,
    NEVER the values themselves."""
    from qs_credentials.vault import describe_payload_shape
    secret_value = "AKIAVERYS3CRET"
    shape = describe_payload_shape({
        "access_key": secret_value,
        "secret_key": "another_secret_xyz",
    })
    assert "access_key" in shape    # key names are OK
    assert "secret_key" in shape
    assert secret_value not in shape  # values must NOT leak
    assert "another_secret_xyz" not in shape
    assert "2/2 non-blank" in shape


def test_describe_payload_shape_blank_password_marked():
    """Blank password produces ``<BLANK>`` marker, not ``<0 chars>``,
    so the operator sees this is the mid-rotation case."""
    from qs_credentials.vault import describe_payload_shape
    shape = describe_payload_shape(("alice", ""))
    assert "<BLANK>" in shape
    assert "alice" in shape


def test_describe_payload_shape_handles_none():
    from qs_credentials.vault import describe_payload_shape
    assert describe_payload_shape(None) == "None"


# ──────────────────────────────────────────────────────────────────────
# 3. describe_ref_for_log -- URL exposure + secret redaction
# ──────────────────────────────────────────────────────────────────────


def test_describe_ref_exposes_urls_for_debugging():
    """auth_url + secret_url + role_name are NOT secrets -- the
    operator needs them in the log to diagnose 'wrong vault path'
    misconfigurations.  Lock that they appear."""
    from qs_credentials.vault import describe_ref_for_log
    ref = {
        "type": "AD_accounts",
        "role_name": "starburst-reader",
        "role_type": "JWT",
        "auth_url": "https://vault.example/v1/auth/k8s/login",
        "secret_url": "https://vault.example/v1/ad/creds/starburst-sa",
        "rotate_url": "",
    }
    out = describe_ref_for_log(ref)
    assert "starburst-reader" in out
    assert "https://vault.example/v1/auth/k8s/login" in out
    assert "https://vault.example/v1/ad/creds/starburst-sa" in out
    assert "AD_accounts" in out


def test_describe_ref_redacts_role_id():
    """AppRole secret_id is a SECRET -- show it as ``<set>`` so the
    operator knows it's configured without leaking the value."""
    from qs_credentials.vault import describe_ref_for_log
    secret_role_id = "highly-secret-approle-id-12345"
    out = describe_ref_for_log({
        "type": "AD_accounts",
        "role_id": secret_role_id,
    })
    assert secret_role_id not in out, (
        f"role_id (AppRole secret) leaked: {out!r}"
    )
    assert "role_id=<set>" in out


# ──────────────────────────────────────────────────────────────────────
# 4. Cache final RuntimeError carries diagnostic
# ──────────────────────────────────────────────────────────────────────


def test_cache_error_includes_invalid_reason_and_shape(monkeypatch):
    """When Vault returns a blank password twice + no cache fallback,
    the final RuntimeError must carry:
      * the specific validation reason (e.g. 'password field is blank')
      * the redacted payload shape
      * the ref's URLs (operator needs them for debugging)
      * the machine + token_method used
    """
    from qs_credentials import cache as cache_mod
    import qs_credentials.vault as vault_mod

    # Stub fetch to return a blank-password payload twice.
    def _fake_fetch(name, ref, *, machine, token_method, _out=None):
        if _out is not None:
            _out["invalid_reason"] = "password field is blank in Vault payload"
            _out["payload_shape"] = "tuple(len=2): user='alice' password=<BLANK>"
        return ("alice", "")  # mid-rotation case

    # Cache.py imports lazily INSIDE the method (`from .vault import ...`),
    # so patch the source module so the late binding picks up the stub.
    monkeypatch.setattr(
        vault_mod, "fetch_secret_with_vendor_fallback", _fake_fetch,
    )
    # No cached fallback.
    cache = cache_mod.QSCredCache(
        settings_provider=lambda: {"enabled": False, "path": "/tmp/x", "ttl": 0,
                                    "key_env": "X", "mem_ttl": 0},
        plaintext_env_var="ETL_SECRETS_ALLOW_PLAINTEXT",
        logger=logging.getLogger("test"),
    )
    cache.reset_mem()

    ref = {
        "type": "AD_accounts",
        "role_name": "starburst-cloud-reader",
        "auth_url": "https://vault.corp/v1/auth/k8s/login",
        "secret_url": "https://vault.corp/v1/ad/creds/starburst-cloud-sa",
    }
    with pytest.raises(RuntimeError) as excinfo:
        cache.fetch_with_fallback(
            "starburst_cloud_acct", ref,
            machine="tprd", token_method="JWT",
        )

    msg = str(excinfo.value)
    # The operator-actionable diagnostic must appear:
    assert "starburst_cloud_acct" in msg
    assert "password field is blank" in msg
    assert "user='alice'" in msg          # shape
    assert "password=<BLANK>" in msg      # shape
    assert "https://vault.corp/v1/ad/creds/starburst-cloud-sa" in msg  # ref
    assert "'tprd'" in msg                # machine
    assert "Likely fixes" in msg          # actionable
    assert "STEP 0-3" in msg              # points operator to step logs


# ──────────────────────────────────────────────────────────────────────
# 5. Step-by-step INFO logs -- presence + content
# ──────────────────────────────────────────────────────────────────────


def test_step_logs_emit_with_machine_and_ref(monkeypatch, caplog):
    """fetch_secret must emit [vault] STEP 0 lines naming the resolved
    machine + sanitized ref details.  Locks the diagnostic contract."""
    from qs_credentials.vault import fetch_secret

    # 2026-06-28 -- after the R9 strategic refactor, QSClient owns the
    # orchestration and binds QSMachineToken / QSVaultToken /
    # QSReadSecrets at qs_client.py module load.  Patches must land on
    # ``qs_client`` -- patching the step submodule's own copy doesn't
    # redirect QSClient's reference (`from .x import Y` binds Y).
    import qs_credentials.vault.qs_client as qc_mod

    class _StubMT:
        def __init__(self, cfg): pass
        def get_token(self): return "mid-token-string"
    class _StubVT:
        def __init__(self, cfg, mt): pass
        def get_token(self): return "vault-token-string"
    class _StubRS:
        last_lease_duration = None
        def __init__(self, cfg, vt): pass
        def get_secrets(self): return ("alice", "pwd")

    monkeypatch.setattr(qc_mod, "QSMachineToken", _StubMT)
    monkeypatch.setattr(qc_mod, "QSVaultToken", _StubVT)
    monkeypatch.setattr(qc_mod, "QSReadSecrets", _StubRS)

    caplog.set_level(logging.INFO, logger="qs_credentials.vault")
    ref = {
        "type": "AD_accounts",
        "role_name": "test-reader",
        "auth_url": "https://vault.example/v1/auth/k8s/login",
        "secret_url": "https://vault.example/v1/ad/creds/test-sa",
    }
    fetch_secret("test_ref", ref, machine="tprd", token_method="JWT")

    messages = [r.getMessage() for r in caplog.records]
    joined = "\n".join(messages)
    # Each step gets a log line.
    assert "[vault] STEP 0" in joined
    assert "[vault] STEP 1" in joined
    assert "[vault] STEP 2" in joined
    assert "[vault] STEP 3" in joined
    # STEP 0 must name the machine + ref details.
    assert "machine='tprd'" in joined
    assert "test-reader" in joined
    # STEP 1/2 success markers.
    assert "STEP 1: machine identity token OK" in joined
    assert "STEP 2: vault session token OK" in joined
    # STEP 3 payload shape (no password leakage).
    assert "STEP 3: read secret payload OK" in joined
    assert "user='alice'" in joined
    assert "pwd" not in joined.replace("password", "")  # 'pwd' shouldn't leak as literal


# ──────────────────────────────────────────────────────────────────────
# vault_config.yaml local path -- regression guard
# ──────────────────────────────────────────────────────────────────────


def test_local_vault_config_path_points_at_etl_configs_dir():
    """2026-06-27 -- before this commit, _LOCAL_PATH pointed at
    ``ETL/qs_credentials/configs/vault_config.yaml`` (under THIS
    module's directory) which never existed.  The actual file lives
    at ``ETL/configs/vault_config.yaml`` alongside the other yamls.

    Symptom of the bug: secret_refs() returned {}, every resolve
    raised "secret_ref=... not found.  Available refs: []".
    """
    import os
    from qs_credentials.resolver import _LOCAL_PATH, _PROD_PATH
    # The local path must end at /ETL/configs/vault_config.yaml --
    # NOT at /ETL/qs_credentials/configs/vault_config.yaml.
    norm = _LOCAL_PATH.replace("\\", "/")
    assert norm.endswith("/configs/vault_config.yaml"), (
        f"_LOCAL_PATH should end at .../configs/vault_config.yaml, "
        f"got {norm!r}"
    )
    assert "/qs_credentials/configs/" not in norm, (
        f"_LOCAL_PATH must NOT point inside qs_credentials/configs/ "
        f"(no such directory exists in the repo).  Got {norm!r}"
    )
    # And the file should ACTUALLY exist in the repo (catches the
    # case where configs/ gets moved without updating the resolver).
    assert os.path.exists(_LOCAL_PATH), (
        f"_LOCAL_PATH resolves to {_LOCAL_PATH!r} but the file does "
        f"not exist.  Either the path resolution drifted again or the "
        f"yaml was deleted."
    )


def test_load_vault_yaml_logs_path_on_success(caplog):
    """When _load_vault_yaml finds a yaml, it must emit an INFO line
    naming the resolved path + the refs it registered.  Operators rely
    on this to confirm 'is it really reading my vault_config.yaml'."""
    import logging
    from qs_credentials.resolver import _load_vault_yaml, _vault_settings, _secret_refs
    _vault_settings.cache_clear()
    _secret_refs.cache_clear()

    caplog.set_level(logging.INFO, logger="qs_credentials.resolver")
    _load_vault_yaml()
    messages = "\n".join(r.getMessage() for r in caplog.records)
    assert "loaded vault_config.yaml from" in messages, (
        f"INFO log missing the path-resolved line.  Got: {messages!r}"
    )
    assert "refs registered:" in messages, (
        "INFO log must list the registered refs so operators can verify"
    )


def test_step1_failure_raises_with_actionable_message(monkeypatch, caplog):
    """When STEP 1 fails (e.g., /var/run/secrets/token/vault-token
    missing), the RuntimeError must name machine + tell the operator
    where to look."""
    from qs_credentials.vault import fetch_secret
    # 2026-06-28 -- patch on qs_client (QSClient orchestration owner).
    import qs_credentials.vault.qs_client as qc_mod

    class _StubMT:
        def __init__(self, cfg): pass
        def get_token(self): return None  # empty -> STEP 1 failure

    monkeypatch.setattr(qc_mod, "QSMachineToken", _StubMT)

    caplog.set_level(logging.INFO, logger="qs_credentials.vault")
    ref = {"type": "AD_accounts", "role_name": "r", "auth_url": "u",
           "secret_url": "s"}
    with pytest.raises(RuntimeError) as excinfo:
        fetch_secret("test_ref", ref, machine="tprd", token_method="JWT")

    msg = str(excinfo.value)
    # R9 message format -- operator-actionable, names the step + the
    # K8s-side file path operators should check.  ``machine='tprd'`` is
    # in the STEP 0 INFO log (asserted separately) but not in the
    # failure RuntimeError itself; the STEP 1 hint already implies tprd
    # (mentions /var/run/secrets/token/vault-token, the tprd token mount).
    assert "STEP 1" in msg
    assert "machine identity token" in msg
    assert "vault-token" in msg  # the file path operator should check
    # Same hint must surface 'machine' context via the STEP 0 INFO log
    # so operators grepping the log timeline see what machine was tried.
    log_text = "\n".join(r.getMessage() for r in caplog.records)
    assert "machine='tprd'" in log_text
