"""Prod incident 2026-07-02 -- 30 min silent .save() before failure.

Locks the write-side heartbeat in ``starburst_base._write_to_oracle``
so a future refactor can't silently drop it and reintroduce the
"is the JDBC write hung or making progress?" mystery.
"""
from __future__ import annotations

import inspect
import os
import sys
from pathlib import Path


_HERE = Path(__file__).parent
_ETL_ROOT = _HERE.parent
if str(_ETL_ROOT) not in sys.path:
    sys.path.insert(0, str(_ETL_ROOT))


class TestWriteHeartbeat:
    def _source(self) -> str:
        p = _ETL_ROOT / "steps" / "oracle" / "starburst_base.py"
        return p.read_text(encoding="utf-8")

    def test_write_has_heartbeat_thread(self):
        src = self._source()
        # The heartbeat thread must exist and target the write phase.
        assert "_write_heartbeat" in src, (
            "starburst_base._write_to_oracle MUST spawn a background "
            "heartbeat thread so a 30-min silent .save() is visible "
            "to operators (see prod incident 2026-07-02)"
        )
        assert "Phase 3/3: still writing to Oracle" in src, (
            "heartbeat log line must name the write phase so ops can "
            "grep for it"
        )

    def test_heartbeat_stops_on_write_exit(self):
        src = self._source()
        # The heartbeat's stop-signal must be wired through a finally
        # so it fires on both success and failure paths.
        assert "_wr_stop.set()" in src, (
            "heartbeat must stop when .save() returns (finally block)"
        )
        # Structural lock: the stop must be inside a `finally:` block.
        # Grep the source of _write_to_oracle for the pattern.
        from steps.oracle import starburst_base as m
        method_src = inspect.getsource(m.StarburstBase._write_to_oracle)
        assert "finally:" in method_src, (
            "_write_to_oracle must guard the heartbeat teardown in "
            "a finally so an in-flight .save() failure still stops it"
        )
        assert "_wr_stop.set()" in method_src

    def test_heartbeat_thread_is_daemon(self):
        """Daemon thread so a crashing driver process doesn't hold
        the JVM open waiting for the heartbeat to exit."""
        src = self._source()
        assert "daemon=True" in src, (
            "heartbeat thread must be daemon so it never blocks "
            "process exit"
        )

    def test_read_heartbeat_still_present(self):
        """Belt-and-suspenders -- read-side heartbeat that ships
        prior to Phase-3/3 write heartbeat must remain."""
        src = self._source()
        assert "still reading from Trino" in src, (
            "read-side heartbeat must not be removed; it's the "
            "symmetric counterpart to the write heartbeat"
        )
