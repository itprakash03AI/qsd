"""Regression tests for Batch 3 production-readiness hygiene fixes
(2026-07-01 deep-dive audit).
"""
from __future__ import annotations

import logging
import os
import sys

import pytest

_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ── env-var clamping ────────────────────────────────────────────────────


class TestConfigEnvVarClamping:
    """Config.load_config env-var overrides must:
      * Reject garbage ints without crashing
      * Clamp values below the safe minimum
      * Emit a WARNING per bad value (visible to operators)"""

    def test_garbage_int_env_falls_back_to_current(self, monkeypatch):
        # Isolate: pretend we have no yaml, no oracle_config_loader
        # so load_config takes only the env-var path.
        monkeypatch.setenv("CONFIG_PATH", "/definitely/does/not/exist.yaml")
        monkeypatch.setenv("BG_POLL_INTERVAL", "not-a-number")
        monkeypatch.setenv("BG_MAX_CONCURRENT", "also-garbage")
        monkeypatch.setenv("ETL_ORACLE_CONN", "u/p@h:1521/DB")
        monkeypatch.setenv("DEST_ORACLE_CONN", "u/p@h:1521/DB")
        monkeypatch.setenv("BG_POLLING_SQL", "SELECT 1 FROM DUAL")
        from polling_service.config import load_config
        cfg = load_config("")
        # Defaults preserved because env vars were rejected.
        assert cfg.interval_seconds == 30
        assert cfg.max_concurrent_runs == 5

    def test_below_minimum_clamped(self, monkeypatch):
        monkeypatch.setenv("CONFIG_PATH", "/definitely/does/not/exist.yaml")
        monkeypatch.setenv("BG_MAX_CONCURRENT", "0")
        monkeypatch.setenv("ETL_ORACLE_CONN", "u/p@h:1521/DB")
        monkeypatch.setenv("DEST_ORACLE_CONN", "u/p@h:1521/DB")
        monkeypatch.setenv("BG_POLLING_SQL", "SELECT 1 FROM DUAL")
        from polling_service.config import load_config
        cfg = load_config("")
        # 0 clamped to 1 (minimum).
        assert cfg.max_concurrent_runs == 1


# ── telemetry_persist sweep ─────────────────────────────────────────────


class TestPersistenceDaemonSweepsStaleTmp:
    """.tmp-telem-*.json siblings that never renamed (due to a
    previous pod crash mid-write) must be swept at daemon start."""

    def test_sweeps_stale_tmp_files(self, tmp_path):
        from polling_service.telemetry_persist import PersistenceDaemon
        # Seed the directory with stale files.
        for name in (
            ".tmp-telem-abc.json",
            ".tmp-telem-def.json",
            "not-a-tmp-file.json",   # unrelated — must survive
        ):
            (tmp_path / name).write_text("{}", encoding="utf-8")

        target = str(tmp_path / "snapshot.json")
        daemon = PersistenceDaemon(path=target, worker_id="test", interval_s=60)
        daemon._sweep_stale_tmp_files()

        # Stale .tmp-* files gone; unrelated file preserved.
        assert not (tmp_path / ".tmp-telem-abc.json").exists()
        assert not (tmp_path / ".tmp-telem-def.json").exists()
        assert (tmp_path / "not-a-tmp-file.json").exists()

    def test_missing_dir_does_not_raise(self, tmp_path):
        from polling_service.telemetry_persist import PersistenceDaemon
        target = str(tmp_path / "does_not_exist" / "snapshot.json")
        daemon = PersistenceDaemon(path=target, worker_id="test", interval_s=60)
        # Sweep on missing dir should be a silent no-op.
        daemon._sweep_stale_tmp_files()


# ── alerter TLS warning ─────────────────────────────────────────────────


class TestAlerterWarnsOnPlaintextCreds:
    """Setting SMTP_USER without SMTP_USE_TLS transmits creds in
    the clear.  Alerter must WARN at construction so operators
    catch the misconfig at pod-start."""

    def test_creds_without_tls_emits_warning(self, caplog):
        from polling_service.alerter import PluginAlerter
        with caplog.at_level(logging.WARNING, logger="bg_poller.alerter"):
            _ = PluginAlerter(
                smtp_host="smtp.example",
                smtp_user="etluser",
                smtp_password="secret",
                smtp_use_tls=False,
                email_from="a@b", email_to="c@d",
                worker_id="test",
            )
        # WARN line must mention TLS + cleartext.
        assert any(
            "SMTP_USE_TLS" in r.message and "cleartext" in r.message
            for r in caplog.records
        )

    def test_creds_with_tls_does_not_warn(self, caplog):
        from polling_service.alerter import PluginAlerter
        with caplog.at_level(logging.WARNING, logger="bg_poller.alerter"):
            _ = PluginAlerter(
                smtp_host="smtp.example",
                smtp_user="etluser",
                smtp_password="secret",
                smtp_use_tls=True,
                email_from="a@b", email_to="c@d",
                worker_id="test",
            )
        assert not any(
            "SMTP_USE_TLS" in r.message and "cleartext" in r.message
            for r in caplog.records
        )


# ── dispatcher's StarburstDataSource import logs actual reason ─────────


class TestDispatcherLogsStarburstImportReason:
    """When StarburstDataSource can't be imported, dispatcher module
    load must log the ACTUAL underlying exception at INFO so ops can
    debug 'no Starburst clients'."""

    def test_source_logs_specific_exception_message(self):
        import inspect
        with open(
            os.path.join(_ETL_ROOT, "polling_service", "dispatcher.py"),
            "r", encoding="utf-8",
        ) as f:
            src = f.read()
        # The improved import block must:
        #  * Capture the exception in a bound name (was previously discarded).
        #  * Emit at INFO (not silent).
        assert "except ImportError as _sb_imp_exc" in src
        assert "StarburstDataSource import failed" in src


# ── Windows SIGINT fallback (main.py) ──────────────────────────────────


class TestMainInstallsSigintFallbackOnWindows:
    """When ``loop.add_signal_handler`` isn't supported (Windows),
    main.py should install a classic ``signal.signal(SIGINT, ...)``
    fallback so Ctrl+C in dev still triggers graceful shutdown."""

    def test_source_has_windows_fallback(self):
        with open(
            os.path.join(_ETL_ROOT, "polling_service", "main.py"),
            "r", encoding="utf-8",
        ) as f:
            src = f.read()
        assert "signal.signal(" in src
        # And a comment explaining why + the specific limitation.
        assert "Windows" in src
