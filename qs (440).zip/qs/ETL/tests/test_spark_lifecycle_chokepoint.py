"""2026-06-26 contract tests for the Spark lifecycle chokepoint.

Background:
  Per-step ``finally: spark.stop()`` was killing the pod-shared
  SparkContext between sequential steps in a pipeline.  Symptom:
  ``starburst_to_oracle_oncloud`` succeeded -> stopped Spark ->
  ``starburst_to_oracle_onprem.df.collect()`` raised
  ``SparkException: Job 0 cancelled because SparkContext was shut down``.

Fix:
  TWO release points (set in :mod:`spark_lifecycle`):

    (1) Early release inside ``execute_tasks`` -- right after the LAST
        Spark-using step finishes.  Saves Spark executor+memory
        through the pure-Oracle / pure-Python tail (CheckCompleteness,
        ProcessData, Consolidate, Compress, CTL, Deliver ...).
    (2) Pipeline-level finally in standalone ``main()`` as an
        idempotent backstop -- catches exception paths and pipelines
        with unusual task-list shapes.

  Step files must NEVER call ``spark.stop()`` directly.

These tests:
  1. Lock the chokepoint API on ``spark_lifecycle``.
  2. Forbid real ``spark.stop()`` calls under ``ETL/steps/``.
  3. Require every standalone driver to import + call both release
     points (early-release in the task loop + main-finally backstop).
  4. Verify the early-release callable's success/no-op semantics.
"""
from __future__ import annotations

import os
import re

import pytest


_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)


def _read(rel_path: str) -> str:
    with open(os.path.join(_ETL_ROOT, rel_path), encoding="utf-8") as f:
        return f.read()


def _walk(rel_root: str):
    base = os.path.join(_ETL_ROOT, rel_root)
    for dirpath, _, fnames in os.walk(base):
        for n in fnames:
            if n.endswith(".py"):
                yield os.path.join(dirpath, n)


# ──────────────────────────────────────────────────────────────────────
# 1. spark_lifecycle.py exists and exposes the chokepoint helper
# ──────────────────────────────────────────────────────────────────────


def test_spark_lifecycle_module_present():
    path = os.path.join(_ETL_ROOT, "spark_lifecycle.py")
    assert os.path.exists(path), "ETL/spark_lifecycle.py must exist"
    body = _read("spark_lifecycle.py")
    assert "def stop_active_spark_session" in body, (
        "spark_lifecycle.py must expose stop_active_spark_session()"
    )
    assert "def install_pipeline_spark_release" in body, (
        "spark_lifecycle.py must expose install_pipeline_spark_release() "
        "so standalones can release Spark right after the LAST Spark "
        "step rather than holding it through the pure-Oracle tail."
    )
    assert "SPARK_STEP_NAMES" in body, (
        "spark_lifecycle.py must declare SPARK_STEP_NAMES (the "
        "TASK_STEPS values that hold a SparkSession)."
    )


def test_stop_active_spark_session_is_failopen():
    """Helper must swallow all exceptions -- a teardown error must not
    mask the pipeline's real outcome."""
    body = _read("spark_lifecycle.py")
    assert "except ImportError" in body, (
        "Helper must tolerate missing pyspark (no-op)"
    )
    assert "except Exception" in body, (
        "Helper must swallow session.stop() / getActiveSession() errors"
    )


def test_install_pipeline_spark_release_semantics():
    """The returned callable must:
      * No-op when no task in the list is Spark-using.
      * Fire exactly once on the LAST index whose task_steps is in
        SPARK_STEP_NAMES.
      * Be debounced -- repeat calls on the same index are no-ops.
      * Be safe to call on every index (non-matching = no-op).
    """
    import sys
    sys.path.insert(0, _ETL_ROOT)
    from spark_lifecycle import install_pipeline_spark_release  # noqa

    fire_count = {"n": 0}

    # Monkeypatch stop_active_spark_session via attribute so we can
    # observe firing without needing pyspark.
    import spark_lifecycle as _sl
    original = _sl.stop_active_spark_session
    _sl.stop_active_spark_session = lambda log=None: fire_count.__setitem__(
        "n", fire_count["n"] + 1,
    )
    try:
        tasks = [
            {"task_steps": "CheckDependencies"},
            {"task_steps": "StarburstToOracle_OnCloud"},
            {"task_steps": "StarburstToOracle_OnPrem"},
            {"task_steps": "CheckDataCompleteness"},
            {"task_steps": "PostLoadProcess"},
        ]
        release = install_pipeline_spark_release(tasks)
        for i in range(len(tasks)):
            release(i)
        assert fire_count["n"] == 1, (
            f"Expected exactly 1 release fire on idx 2 "
            f"(StarburstToOracle_OnPrem is the last Spark step), "
            f"got {fire_count['n']}"
        )

        # Repeat -- still 1 (debounced).
        for i in range(len(tasks)):
            release(i)
        assert fire_count["n"] == 1, (
            "Repeat calls must be debounced (no-op after first fire)"
        )

        # All-non-Spark task list -- never fires.
        fire_count["n"] = 0
        release2 = install_pipeline_spark_release([
            {"task_steps": "CheckDependencies"},
            {"task_steps": "SendEmailNotifications"},
        ])
        for i in range(2):
            release2(i)
        assert fire_count["n"] == 0, (
            "No-Spark task lists must never trigger Spark release"
        )
    finally:
        _sl.stop_active_spark_session = original


def test_spark_step_names_covers_known_workflow_steps():
    """SPARK_STEP_NAMES must include every TASK_STEPS value whose step
    class instantiates a SparkSession.  Regression guard: adding a new
    Spark step type without updating this set means Spark leaks past
    the end of the pipeline (the backstop catches it but the early
    release point is skipped).
    """
    import sys
    sys.path.insert(0, _ETL_ROOT)
    from spark_lifecycle import SPARK_STEP_NAMES  # noqa

    # Anchor steps from each workflow that MUST be in the set.
    must_include = {
        "StarburstToOracle_OnCloud",
        "StarburstToOracle_OnPrem",
        "DelimitedFileToOracle",
        "ParquetFileToOracle",
        "CsvFileToOracle",
        "IcebergToFile_OnCloud",
        "IcebergToFile_OnPrem",
        "HiveToFile_OnPrem",
        "IcebergToOracle_OnCloud",
        "IcebergToOracle_OnPrem",
        "HiveToOracle_OnPrem",
    }
    missing = must_include - set(SPARK_STEP_NAMES)
    assert not missing, (
        f"SPARK_STEP_NAMES is missing canonical Spark steps: {missing}.  "
        "Without these, the pipeline-level early-release callable will "
        "not fire for the affected workflow -- Spark leaks through the "
        "tail steps (CheckCompleteness, ProcessData, ...)."
    )


def _ast_node_uses_spark(tree) -> bool:
    """AST-based detection of actual Spark calls.

    Catches:
      * self._build_spark_session_xxx(...) / cls._build_spark_session(...)
      * SparkSession.builder...                  (attribute chain)
      * SparkSession.getActiveSession()          (or .stop() / .builder)
      * spark.stop() / session.stop() with Spark-ish names is NOT caught
        (too noisy); we rely on the call-site checks above instead.

    Comments and docstrings are invisible to AST -- so this skips both
    automatically.  No false positives from "_build_spark_session" in a
    docstring or comment.
    """
    import ast
    for node in ast.walk(tree):
        # Attribute access like SparkSession.builder / SparkSession.getActiveSession
        if isinstance(node, ast.Attribute):
            if isinstance(node.value, ast.Name) and node.value.id == "SparkSession":
                if node.attr in ("builder", "getActiveSession"):
                    return True
        # Call expressions: self._build_spark_session_xxx(...)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            attr = node.func.attr or ""
            if attr.startswith("_build_spark_session"):
                return True
    return False


def _module_or_base_uses_spark(module_dotted: str) -> bool:
    """Return True if the module's AST OR any ``from steps.X import``
    base module's AST contains a real Spark call.
    """
    import ast
    seen = set()
    queue = [module_dotted]
    while queue:
        mod = queue.pop()
        if mod in seen:
            continue
        seen.add(mod)
        rel = mod.replace(".", "/") + ".py"
        path = os.path.join(_ETL_ROOT, rel)
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding="utf-8") as f:
                src = f.read()
        except OSError:
            continue
        try:
            tree = ast.parse(src, filename=path)
        except SyntaxError:
            # Source has a syntax error -- can't analyse.  Don't mask
            # as Spark; let the actual import / py_compile test catch it.
            continue
        if _ast_node_uses_spark(tree):
            return True
        # Chase ``from steps.X.Y import ...`` base modules.
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                if node.module.startswith("steps.") and node.module not in seen:
                    queue.append(node.module)
    return False


def test_spark_step_names_auto_synced_with_yaml_and_source():
    """DRIFT-DETECTION TEST.

    Walks every (workflow, step_name, module) tuple in
    ``configs/step_mapping.yaml``.  For each step, reads the module's
    .py file AND its imported step bases under ``ETL/steps/`` looking
    for Spark instantiation markers (``_build_spark_session`` /
    ``SparkSession.builder`` / ``SparkSession.getActiveSession``).

    If a step's class USES Spark but its TASK_STEPS name is missing
    from :data:`spark_lifecycle.SPARK_STEP_NAMES`, fail loudly with
    the exact name to add.  This catches the case where a future PR
    ships a new Spark step type but forgets to update SPARK_STEP_NAMES
    -- without the update, the early-release callable wouldn't fire
    for that workflow and Spark would leak through the tail steps.
    """
    import sys
    import yaml
    sys.path.insert(0, _ETL_ROOT)
    from spark_lifecycle import SPARK_STEP_NAMES  # noqa

    # Modules in step_mapping that reference operator-PVC-only files
    # (NOT committed to repo).  Same allowlist used by the workflow
    # consistency audit -- can't introspect what's not on disk.
    intentionally_broken = {
        "steps.pre_data_validation",
        "steps.sb_to_file_poc",
    }

    body = _read("configs/step_mapping.yaml")
    workflows = yaml.safe_load(body) or {}

    spark_uses_by_step_name = {}
    for workflow, steps in workflows.items():
        if not isinstance(steps, dict):
            continue
        for step_name, details in steps.items():
            if not isinstance(details, dict):
                continue
            module = details.get("module") or ""
            if not module or module in intentionally_broken:
                continue
            uses_spark = _module_or_base_uses_spark(module)
            # Multiple workflows may register the same step_name; OR
            # any-True across registrations.
            spark_uses_by_step_name[step_name] = (
                spark_uses_by_step_name.get(step_name, False) or uses_spark
            )

    discovered = {n for n, uses in spark_uses_by_step_name.items() if uses}
    missing_from_registry = discovered - set(SPARK_STEP_NAMES)
    extras_in_registry = set(SPARK_STEP_NAMES) - discovered

    # Hard-fail on missing: a real Spark step that the chokepoint can't
    # see.  Spark would leak through the tail steps of that workflow.
    assert not missing_from_registry, (
        "SPARK_STEP_NAMES is out of sync with source code.  Step modules "
        f"use Spark but the registry doesn't list them: {sorted(missing_from_registry)}.\n\n"
        "Fix: add the missing step name(s) to SPARK_STEP_NAMES in "
        "ETL/spark_lifecycle.py.  Without this, the EARLY-release "
        "callable installed by install_pipeline_spark_release will not "
        "fire for the affected workflow -- Spark will hold cluster "
        "resources through CheckCompleteness / ProcessData / Send* / "
        "Consolidate / Compress / CTL / Deliver tail steps until the "
        "pipeline-level finally backstop in main() runs."
    )

    # Soft-fail on extras: registry lists a step name that no module
    # actually uses Spark for.  Could be (a) a typo, (b) a step type
    # whose Spark base was removed, or (c) a name in the registry for
    # a workflow that doesn't have that step in the yaml.  Print a
    # warning rather than fail, since extras are harmless (just redundant
    # entries -- they never fire because the step never runs).
    if extras_in_registry:
        print(
            "\nWARNING: SPARK_STEP_NAMES contains entries that don't "
            f"appear to use Spark in yaml-registered modules: "
            f"{sorted(extras_in_registry)}.  Likely safe (just redundant) "
            "but consider trimming the registry."
        )


# ──────────────────────────────────────────────────────────────────────
# 2. No real spark.stop() under ETL/steps/ (only commented sentinels)
# ──────────────────────────────────────────────────────────────────────


_LINE_COMMENT_RE = re.compile(r"^\s*#")


def test_no_step_level_spark_stop_calls():
    """Locate every ``spark.stop()`` mention under ETL/steps/ and assert
    it's either a comment line or a string literal -- never an actual
    call.  Step files surrender Spark lifecycle to the standalone driver.
    """
    offenders = []
    for path in _walk("steps"):
        with open(path, encoding="utf-8") as f:
            for ln, line in enumerate(f, 1):
                if "spark.stop()" not in line:
                    continue
                stripped = line.lstrip()
                if _LINE_COMMENT_RE.match(line):
                    continue
                # tolerate inline mention inside a #-comment after code
                code, _, _comment = line.partition("#")
                if "spark.stop()" not in code:
                    continue
                # tolerate string literal mention
                if (code.count('"') >= 2 or code.count("'") >= 2) and \
                   ('"spark.stop()"' in code or "'spark.stop()'" in code):
                    continue
                rel = os.path.relpath(path, _ETL_ROOT).replace("\\", "/")
                offenders.append(f"{rel}:{ln}: {stripped.rstrip()}")
    assert not offenders, (
        "ETL/steps/ must not call spark.stop() directly -- pipeline-level "
        "teardown happens via spark_lifecycle.stop_active_spark_session in "
        "the standalone main() finally.\n  "
        + "\n  ".join(offenders)
    )


# ──────────────────────────────────────────────────────────────────────
# 3. Every standalone driver wires the chokepoint
# ──────────────────────────────────────────────────────────────────────


# s3_to_file_standalone.py + s3_to_oracle_standalone.py are thin shims
# around s3_standalone_runner.run_pipeline, so we lock the runner instead.
_STANDALONE_DRIVERS = [
    "oracle_standalone.py",
    "file_standalone.py",
    "file_to_oracle_standalone.py",
    "s3_standalone_runner.py",
    "s3_query_standalone.py",
    "sap_odata_standalone.py",
]


@pytest.mark.parametrize("driver", _STANDALONE_DRIVERS)
def test_standalone_imports_spark_lifecycle(driver):
    body = _read(driver)
    assert "from spark_lifecycle import stop_active_spark_session" in body, (
        f"{driver} must import stop_active_spark_session from spark_lifecycle "
        "and invoke it in the pipeline-level finally."
    )
    assert "stop_active_spark_session(logger)" in body, (
        f"{driver} must call stop_active_spark_session(logger) -- "
        "without this, Spark leaks until pod exit and the next pipeline "
        "step in a long-running pod sees a dead SparkContext."
    )


# Standalones that orchestrate Spark-using workflows must also wire the
# EARLY-release point inside their task loop.  sap_odata_standalone is
# pure SAP OData HTTP / pyarrow -- never builds a SparkSession, so it
# doesn't need install_pipeline_spark_release.
_SPARK_PIPELINE_DRIVERS = [
    "oracle_standalone.py",
    "file_standalone.py",
    "file_to_oracle_standalone.py",
    "s3_standalone_runner.py",
    "s3_query_standalone.py",
]


@pytest.mark.parametrize("driver", _SPARK_PIPELINE_DRIVERS)
def test_standalone_wires_early_release(driver):
    body = _read(driver)
    assert "from spark_lifecycle import install_pipeline_spark_release" in body, (
        f"{driver} must import install_pipeline_spark_release -- without "
        "early release, Spark executors+memory are held through the "
        "pure-Oracle / pure-Python tail (CheckCompleteness, ProcessData, "
        "Consolidate, Compress, CTL, Deliver ...).  Wasteful in busy "
        "clusters."
    )
    assert "install_pipeline_spark_release(tasks" in body, (
        f"{driver} must call install_pipeline_spark_release(tasks, logger) "
        "to obtain the per-loop debounced release callable."
    )
    assert "maybe_release_spark(" in body, (
        f"{driver} must invoke the maybe_release_spark callable inside "
        "the task loop (finally or end-of-iteration) so it fires right "
        "after the LAST Spark-using step finishes."
    )
