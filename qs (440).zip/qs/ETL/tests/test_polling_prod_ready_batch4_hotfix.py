"""Regression tests for the Batch 4 HOTFIX (2026-07-01).

The initial Batch 4 commit shipped with a set of gaps caught by an
adversarial audit right after it landed.  This module locks each
hotfix so the exact same regressions can't reappear.

Hotfix items covered:
  * CRITICAL -- service.shutdown secondary-pool cleanup was DEAD CODE
    (wrong attribute name).  Locked by reading the shutdown source and
    asserting the correct attribute reference.
  * HIGH     -- workflow_registry.register was doing in-place
    ``.append()`` + ``.sort()`` on the same list unlocked readers were
    iterating.  Copy-on-write invariant locked structurally.
  * HIGH     -- ``_WORKER_LOADABLE_CACHE`` was unbounded (grew forever
    on ``/admin/reload``).  Locked by (a) a FIFO eviction test and
    (b) a bound-const presence check.
  * HIGH     -- alerter spawned a fresh daemon Thread per alert.
    Locked by asserting ``Alerter`` exposes ``_get_send_pool`` +
    ``shutdown`` + ``_send_pool_max_workers``.
  * HIGH     -- health.py used ``getattr(_service, "poll_loop_dead",
    False)`` which fails OPEN if the attribute is renamed.  Locked by
    grepping the source for the fail-open pattern.
  * HIGH     -- telemetry daemon was only stopped via ``atexit``.
    Locked by asserting ``BackgroundService.shutdown`` source
    references ``_telemetry_daemon``.
  * HIGH     -- ``OracleMetadataManager`` construction blocked the
    event loop.  Locked by asserting ``main.py`` uses
    ``asyncio.to_thread`` for the constructor.
"""
from __future__ import annotations

import inspect
import os
import sys
import threading

import pytest


_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


# ── CRITICAL: secondary-pool cleanup was dead code ──────────────────────


class TestSecondaryPoolCleanupNotDeadCode:
    def test_shutdown_uses_correct_attribute_name(self):
        """The shutdown branch that closes secondary pools MUST
        reference ``self.oracle_manager`` (the real attribute), NOT
        ``self.oracle_metadata_manager`` (which doesn't exist).

        We check the anti-pattern with a strict form
        (``getattr(self, "oracle_metadata_manager"``) so historical
        commentary that mentions the wrong name doesn't false-positive.
        """
        from polling_service import service as svc
        src = inspect.getsource(svc.BackgroundService.shutdown)
        # Must reference the real attribute name.
        assert "self.oracle_manager" in src, (
            "shutdown must reference self.oracle_manager for pool cleanup"
        )
        # The specific dead-code pattern that shipped: getattr with
        # the wrong string.  Must NOT reappear as executable code.
        # Strip comment lines first so historical commentary that
        # references the anti-pattern doesn't false-positive.
        executable = "\n".join(
            line for line in src.splitlines()
            if not line.lstrip().startswith("#")
        )
        assert 'getattr(self, "oracle_metadata_manager"' not in executable, (
            "shutdown must not reintroduce the dead-code getattr "
            "against the wrong attribute name (executable lines only)"
        )
        # close_secondary_pools must actually be referenced.
        assert "close_secondary_pools" in src, (
            "shutdown must call close_secondary_pools on the manager's "
            "oracle_db"
        )


# ── HIGH: workflow_registry copy-on-write ───────────────────────────────


class TestRegistryCopyOnWrite:
    def test_register_uses_copy_on_write(self):
        """register() must build a LOCAL sorted list and swap it into
        ``self._defs`` atomically, so unlocked readers finish
        iterating on their (older) reference safely.

        Positive-assertion form so historical comments naming the
        anti-pattern don't false-positive.
        """
        from polling_service import workflow_registry as wr
        src = inspect.getsource(wr.WorkflowRegistry.register)
        # The copy-on-write pattern: build a NEW list, sort IT, then
        # swap the reference.
        assert "new_defs.append" in src, (
            "register must build a local new_defs list and append to IT"
        )
        assert "new_defs.sort" in src, (
            "register must sort the local new_defs list, not self._defs"
        )
        assert "self._defs = new_defs" in src, (
            "register must atomically re-assign self._defs from the "
            "sorted local list"
        )

    def test_register_produces_correct_priority_order(self):
        """End-to-end sanity: registering out of priority order should
        still produce a priority-sorted _defs."""
        from polling_service import workflow_registry as wr

        # Build a minimal manifest surrogate directly on the registry
        # via the internal API — going through PluginManifest requires
        # a real workflow module we don't want to depend on here.
        # We use the actual PluginManifest class so field validation
        # runs.
        try:
            from polling_service.workflow_registry import PluginManifest
        except ImportError:
            pytest.skip("PluginManifest not importable in this environment")

        reg = wr.WorkflowRegistry(default_name="oracle")
        # Insert two plausible manifests with distinct priorities.
        # If PluginManifest construction requires more fields than we
        # know about, skip the test cleanly.
        try:
            m_lo = PluginManifest(
                name="test_low",
                dag_id_patterns=("test_low",),
                worker_loader=lambda: object,
                priority=100,
                source="test",
            )
            m_hi = PluginManifest(
                name="test_hi",
                dag_id_patterns=("test_hi",),
                worker_loader=lambda: object,
                priority=10,
                source="test",
            )
        except Exception:
            pytest.skip("PluginManifest constructor shape differs")

        reg.register(m_lo)
        reg.register(m_hi)
        # Low priority number = higher in the sorted list.
        priorities = [d.priority for d in reg._defs if d.name.startswith("test_")]
        assert priorities == sorted(priorities), (
            "self._defs must be priority-sorted after register()"
        )


class TestLoadableCacheBounded:
    def test_bound_constant_exists(self):
        from polling_service import workflow_registry as wr
        assert hasattr(wr, "_WORKER_LOADABLE_CACHE_MAX")
        assert wr._WORKER_LOADABLE_CACHE_MAX > 0
        assert hasattr(wr, "_WORKER_LOADABLE_CACHE_LOCK")
        assert isinstance(wr._WORKER_LOADABLE_CACHE_LOCK, type(threading.Lock()))

    def test_fifo_eviction_kicks_in(self, monkeypatch):
        """When the cache exceeds the bound, the OLDEST entry must be
        evicted so the cache size never exceeds MAX."""
        from polling_service import workflow_registry as wr

        # Small bound for the test.
        monkeypatch.setattr(wr, "_WORKER_LOADABLE_CACHE_MAX", 3)
        wr._clear_worker_loadable_cache()

        class FakeManifest:
            def __init__(self, name: str, loadable: bool = True) -> None:
                self.name = name
                self._loadable = loadable

            def worker_cls(self):
                return object if self._loadable else None

        # Insert 5 distinct manifests into a 3-slot cache.
        manifests = [FakeManifest(f"plugin_{i}") for i in range(5)]
        for m in manifests:
            wr._worker_cls_loadable(m)

        # Cache must be bounded at 3.
        assert len(wr._WORKER_LOADABLE_CACHE) <= 3, (
            f"cache exceeded bound: {len(wr._WORKER_LOADABLE_CACHE)}"
        )


# ── HIGH: alerter bounded pool + shutdown ───────────────────────────────


class TestAlerterBoundedPool:
    def test_alerter_exposes_pool_helpers(self):
        from polling_service import alerter as al
        # After the hotfix the Alerter must expose the pool plumbing.
        assert hasattr(al.PluginAlerter, "_get_send_pool"), (
            "Alerter must expose _get_send_pool for bounded SMTP sends"
        )
        assert hasattr(al.PluginAlerter, "shutdown"), (
            "Alerter must expose shutdown() so BackgroundService can "
            "release the bounded pool during graceful shutdown"
        )

    def test_alert_uses_pool_not_bare_thread(self):
        """The production dispatch path must dispatch via the bounded
        pool.  Positive assertion so historical comments naming the
        anti-pattern don't false-positive."""
        from polling_service import alerter as al
        src = inspect.getsource(al.PluginAlerter.alert)
        # The production branch must go through the pool submit.
        assert "_get_send_pool" in src, (
            "Alerter.alert must dispatch via _get_send_pool()"
        )
        assert "pool.submit" in src or "self._send_pool" in src, (
            "Alerter.alert must submit background sends via the pool"
        )

    def test_shutdown_is_idempotent(self):
        from polling_service.alerter import PluginAlerter

        a = PluginAlerter(smtp_host="localhost")     # no SMTP send in this test
        a.shutdown(wait=False)
        # Second call must not raise.
        a.shutdown(wait=False)


# ── HIGH: health.py fail-fast on poll_loop_dead ─────────────────────────


class TestHealthPollLoopDeadFailFast:
    def test_source_uses_direct_attribute(self):
        """The health endpoint must use direct attribute access on
        ``_service.poll_loop_dead`` so an accidental rename raises
        AttributeError → 500 → K8s restart, instead of silently
        returning healthy forever."""
        from polling_service import health as h
        src = inspect.getsource(h)
        # Positive assertion: direct attribute access is what we want.
        assert "_service.poll_loop_dead" in src, (
            "health.py must reference _service.poll_loop_dead directly"
        )
        # Structural: the SPECIFIC executable pattern that shipped in
        # the pre-hotfix code was
        # ``if getattr(_service, "poll_loop_dead", False)`` — that
        # exact line (a condition guard using the getattr fail-open
        # form) must not reappear.
        assert 'if getattr(_service, "poll_loop_dead", False)' not in src, (
            "health.py must not fail-open on poll_loop_dead attribute"
        )


# ── HIGH: telemetry daemon stopped in shutdown ──────────────────────────


class TestTelemetryDaemonStoppedInShutdown:
    def test_shutdown_stops_telemetry_daemon(self):
        from polling_service import service as svc
        src = inspect.getsource(svc.BackgroundService.shutdown)
        assert "_telemetry_daemon" in src, (
            "BackgroundService.shutdown must stop the telemetry "
            "daemon BEFORE the event loop closes; atexit alone races "
            "with the readiness executor teardown"
        )

    def test_main_attaches_daemon_to_service(self):
        # Read from disk so this test doesn't require uvicorn
        # (main.py top-level imports it).
        main_path = os.path.join(_ETL_ROOT, "polling_service", "main.py")
        with open(main_path, "r", encoding="utf-8") as f:
            src = f.read()
        assert "service._telemetry_daemon = _telemetry_daemon" in src, (
            "main.py must attach the daemon to service so shutdown "
            "can find + stop it (atexit remains as a backstop)"
        )


# ── HIGH: OracleMetadataManager off event loop ──────────────────────────


class TestOracleManagerOffEventLoop:
    def test_main_uses_to_thread_for_oracle_manager(self):
        """OracleDBLib.__init__ does synchronous ``time.sleep`` on
        pool-creation retry.  Constructing it directly on the asyncio
        loop can freeze the loop for tens of seconds during a
        rolling-upgrade Oracle blip.  main.py MUST wrap the
        construction in ``asyncio.to_thread``."""
        # Read from disk so this test doesn't require uvicorn.
        main_path = os.path.join(_ETL_ROOT, "polling_service", "main.py")
        with open(main_path, "r", encoding="utf-8") as f:
            src = f.read()
        assert "asyncio.to_thread(" in src, (
            "main.py must use asyncio.to_thread somewhere"
        )
        # And the two must occur close together in the source.
        # Accept any whitespace between them (single-line or wrapped).
        import re
        pattern = re.compile(
            r"asyncio\.to_thread\(\s*OracleMetadataManager", re.DOTALL
        )
        assert pattern.search(src), (
            "main.py must construct OracleMetadataManager on a worker "
            "thread so its pool-creation retry doesn't block the loop"
        )
