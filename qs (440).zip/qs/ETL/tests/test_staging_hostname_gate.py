"""Multi-pod staging-dir hostname gate (prod incident 2026-07-02).

Prior bug
---------
Pod A ran an extract, wrote to
    /nfs/output/.staging_874750_STARBURST_20260702_160403_p42
where 42 was Pod A's PID.

Pod B started a concurrent run, ran Layer-2 orphan cleanup, saw Pod A's
staging dir, called ``_is_pid_alive(42)`` which uses
``os.kill(pid, 0)`` -- but K8s PID namespaces are pod-local, so Pod B
had no PID 42 -> "orphan" -> ``shutil.rmtree(Pod A's staging)`` ->
Pod A's open chunk-file fd invalidated -> ``[Errno 116] Stale file
handle`` -> chunk failure -> "0 rows extracted before halt" -> run
FAILED.

Fix
---
1. Encode ``_h<hostname>`` in the staging dir name.
2. Layer-2 scan skips every dir whose ``_h<host>`` != our own
   ``socket.gethostname()``.  ``_is_pid_alive`` is only consulted for
   same-hostname dirs (where the pid namespace IS shared).
3. Legacy dirs (no ``_h`` segment) fall back to a conservative
   (run_id, DATASOURCE) match -- never nuked cross-run.

Also lock the RETRYABLE classification of ``[Errno 116] Stale file
handle`` so future transient stale-handles (mount rotation, NFS server
blip) surface as RETRYABLE instead of "Unknown".
"""
from __future__ import annotations

import re
import sys
from pathlib import Path


_HERE = Path(__file__).parent
_ETL_ROOT = _HERE.parent
if str(_ETL_ROOT) not in sys.path:
    sys.path.insert(0, str(_ETL_ROOT))


class TestStagingDirHostnameEmbedded:
    def test_source_encodes_hostname_in_staging_dir(self):
        """The staging dir builder must include ``_h<host>_p<pid>``.
        Locked as source-grep so any refactor that drops the hostname
        segment fails CI."""
        src = (_ETL_ROOT / "steps" / "file" / "starburst_file_base.py").read_text(encoding="utf-8")
        # The timestamp assembly must include _h<hostname>.
        assert '_h{_safe_host}_p' in src, (
            "staging dir timestamp must embed _h<host>_p<pid>; hostname "
            "gate is load-bearing for multi-pod correctness"
        )
        # And the cleanup scan must consult a hostname pattern.
        assert '_host_pid_pattern' in src, (
            "Layer-2 orphan scan must have a hostname-aware regex; "
            "PID-only match cross-namespaces = stale-handle bug"
        )

    def test_source_prefers_pod_name_env_over_gethostname(self):
        """K8s hostNetwork=true pods return the NODE name from
        ``socket.gethostname()`` -- all pods on that node collapse to
        the same hostname segment and the gate breaks.  ``POD_NAME``
        from the Downward API is always pod-unique."""
        src = (_ETL_ROOT / "steps" / "file" / "starburst_file_base.py").read_text(encoding="utf-8")
        assert 'os.environ.get("POD_NAME")' in src, (
            "hostname resolution must prefer POD_NAME env; "
            "hostNetwork=true pods otherwise collapse to node name"
        )

    def test_source_hashes_long_hostnames_not_truncates(self):
        """Simple ``[:40]`` truncation lets two StatefulSet pods sharing
        a long prefix collide.  Hash-suffix keeps collisions
        practically impossible."""
        src = (_ETL_ROOT / "steps" / "file" / "starburst_file_base.py").read_text(encoding="utf-8")
        assert "hashlib" in src, (
            "long-hostname handling must hash the full hostname; "
            "``[:40]`` truncation can collide across pods on the "
            "same replica set"
        )
        assert "_hashlib.sha1" in src, "expected sha1 for hostname hash"


class TestPodNameOverridesHostname:
    """When ``POD_NAME`` is exported (K8s Downward API), it must win
    over ``socket.gethostname()`` so hostNetwork=true / hostname-shared
    pods still produce distinct staging dirs."""

    def test_pod_name_env_takes_precedence(self, monkeypatch):
        import os as _os
        import socket as _socket
        # Simulate the (bad) case where gethostname returns node name.
        monkeypatch.setattr(_socket, "gethostname", lambda: "shared-node-name")
        monkeypatch.setenv("POD_NAME", "querystudio-etl-worker-a1b2c3")
        # Re-implement the tiny bit of logic under test to verify the
        # priority without importing the whole starburst_file_base
        # module (heavy Spark imports).
        host = _os.environ.get("POD_NAME") or _socket.gethostname()
        assert host == "querystudio-etl-worker-a1b2c3"

    def test_falls_back_to_gethostname_when_pod_name_unset(self, monkeypatch):
        import os as _os
        import socket as _socket
        monkeypatch.setattr(_socket, "gethostname", lambda: "dev-laptop")
        monkeypatch.delenv("POD_NAME", raising=False)
        host = _os.environ.get("POD_NAME") or _socket.gethostname()
        assert host == "dev-laptop"


class TestHostnameSanitizeToHyphen:
    """2026-07-02 audit finding: hostname sanitization used ``_`` as
    the replacement char, meaning raw underscores in the hostname
    (VMs / dev boxes: ``my_dev_box``) stayed as underscores in
    ``_safe_host`` -- and the Layer-2 orphan-scan regex
    ``_h([^_]+)_p\\d+$`` requires a non-underscore host segment.
    Silent fallback to legacy same-(run_id, DS) branch.

    Fix: sanitize to hyphen so underscore-carrying hostnames still
    produce a regex-matchable host segment.
    """

    def test_source_replacement_is_hyphen_not_underscore(self):
        src = (_ETL_ROOT / "steps" / "file" / "starburst_file_base.py").read_text(encoding="utf-8")
        assert 're.sub(r"[^A-Za-z0-9\\-]", "-", _host)' in src, (
            "hostname sanitization must replace with hyphen (not "
            "underscore) so ``my_dev_box`` becomes ``my-dev-box`` "
            "and matches the ``[^_]+`` host segment of the orphan-scan"
        )

    def test_underscored_hostname_matches_orphan_scan_regex(self):
        """Simulate a VM hostname with underscores; verify the
        sanitized value matches the same regex the Layer-2 scan uses."""
        import re
        raw = "my_dev_box"
        sanitized = re.sub(r"[^A-Za-z0-9\-]", "-", raw)
        assert sanitized == "my-dev-box"
        # Construct the dir name shape and confirm it matches the
        # host-pid regex.
        dir_name = (
            f".staging_874750_STARBURST_20260702_160403_000042"
            f"_h{sanitized}_p42"
        )
        m = re.match(r"^\.staging_.+_h([^_]+)_p(\d+)$", dir_name)
        assert m is not None
        assert m.group(1) == "my-dev-box"
        assert m.group(2) == "42"


class TestLayer2ScanGate:
    """Simulate the Layer-2 scan's regex against a mix of staging dir
    names to prove that other pods' dirs are filtered out."""

    HOST_PATTERN = re.compile(r"^\.staging_.+_h([^_]+)_p(\d+)$")
    LEGACY_PATTERN = re.compile(r"^\.staging_.+_p(\d+)$")

    def test_host_regex_matches_new_format(self):
        m = self.HOST_PATTERN.match(
            ".staging_874750_STARBURST_20260702_160403_000042_hquerystudio-etl-pod-a_p42"
        )
        assert m is not None
        assert m.group(1) == "querystudio-etl-pod-a"
        assert m.group(2) == "42"

    def test_host_regex_does_not_match_legacy_format(self):
        m = self.HOST_PATTERN.match(
            ".staging_874750_STARBURST_20260702_160403_000042_p42"
        )
        assert m is None

    def test_legacy_regex_matches_legacy_format(self):
        m = self.LEGACY_PATTERN.match(
            ".staging_874750_STARBURST_20260702_160403_000042_p42"
        )
        assert m is not None
        assert m.group(1) == "42"

    def test_cross_pod_hostnames_are_distinguishable(self):
        """Two same-run dirs from different pods must produce distinct
        hostname segments -- otherwise the gate collapses."""
        a = self.HOST_PATTERN.match(
            ".staging_874750_STARBURST_20260702_160403_000042_hpod-a_p42"
        )
        b = self.HOST_PATTERN.match(
            ".staging_874750_STARBURST_20260702_160403_000042_hpod-b_p42"
        )
        assert a and b
        assert a.group(1) != b.group(1)


class TestStarburstErrorClassifierESTALE:
    """Locking Errno 116 / ESTALE as RETRYABLE so a transient NFS
    stale-handle no longer falls into the ``Unknown`` bucket."""

    def _classify(self, msg: str):
        from steps.file.starburst_file_base import StarburstErrorClassifier
        return StarburstErrorClassifier.classify(OSError(msg))

    def test_errno_116_message_is_retryable(self):
        cls = self._classify("[Errno 116] Stale file handle")
        assert cls.is_retryable is True
        # Explicitly-recognised retry, not the catch-all Unknown bucket.
        assert "Retryable Starburst error" in cls.message
        assert "Unknown error" not in cls.message

    def test_bare_estale_string_is_retryable(self):
        cls = self._classify("ESTALE: fd invalidated by NFS server")
        assert cls.is_retryable is True

    def test_stale_file_handle_message_is_retryable(self):
        cls = self._classify("Stale file handle on /nfs/output/foo.csv")
        assert cls.is_retryable is True

    def test_should_not_stop_process(self):
        """A single chunk's stale-handle must NOT halt the whole run --
        retry the chunk; other chunks keep going."""
        cls = self._classify("[Errno 116] Stale file handle")
        assert cls.should_stop_process is False
