"""Regression lock for the 2026-06-29 prod incident:
``is_vault_enabled`` was reading ``secrets.vault.enabled`` (the inner
block) when both the docstring and the vault_config.yaml comments
documented ``secrets.enabled`` (top of the secrets block) as the master
switch.  Operators flipping ``secrets.enabled: true`` saw zero effect.

These tests lock the corrected resolution order so a future refactor
can't silently re-introduce the bug.
"""
from __future__ import annotations

import os
import sys
from unittest.mock import patch

import pytest
import yaml


_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)


def _write_yaml(path: str, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, default_flow_style=False, sort_keys=False)


@pytest.fixture
def isolated_resolver(monkeypatch, tmp_path):
    """Patch the resolver to read from a tmp yaml + clear all caches
    so each test starts from a clean state."""
    yaml_path = tmp_path / "vault_config.yaml"
    from qs_credentials import resolver as r
    monkeypatch.setattr(r, "_PROD_PATH", str(yaml_path))
    monkeypatch.setattr(r, "_LOCAL_PATH", str(yaml_path))
    monkeypatch.delenv("ETL_USE_VAULT", raising=False)
    r._vault_settings.cache_clear()
    r._secret_refs.cache_clear()
    yield yaml_path, r
    r._vault_settings.cache_clear()
    r._secret_refs.cache_clear()


class TestVaultEnabledKeyResolution:
    """Locks: ``secrets.enabled`` (documented location) is the master
    switch.  ``secrets.vault.enabled`` is honored as a back-compat
    fallback for deployments that worked around the bug."""

    def test_secrets_enabled_true_takes_effect(self, isolated_resolver):
        """The ACTUAL bug fix: setting secrets.enabled at the top of
        the secrets block (as docstring + yaml comments document)
        must return True from is_vault_enabled."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": True,  # documented location
                "vault": {"machine": "openshift", "token_method": "JWT"},
                "refs":  {"r1": {"type": "AD_accounts", "auth_url": "u",
                                  "secret_url": "s"}},
            },
        })
        assert r.is_vault_enabled() is True, (
            "secrets.enabled=true MUST enable vault.  This is the bug "
            "that silently caused prod prewarm failures on 2026-06-29."
        )

    def test_secrets_enabled_false_takes_effect(self, isolated_resolver):
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": False,
                "vault": {"machine": "openshift"},
                "refs":  {"r1": {"type": "AD_accounts", "auth_url": "u",
                                  "secret_url": "s"}},
            },
        })
        assert r.is_vault_enabled() is False

    def test_back_compat_secrets_vault_enabled_true(self, isolated_resolver):
        """Deployments that worked around the bug by placing ``enabled``
        inside the vault block MUST keep working."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {
            "secrets": {
                # No top-level "enabled" -- only the inner one.
                "vault": {"enabled": True, "machine": "openshift"},
                "refs":  {"r1": {"type": "AD_accounts", "auth_url": "u",
                                  "secret_url": "s"}},
            },
        })
        assert r.is_vault_enabled() is True, (
            "secrets.vault.enabled (the bug's accidental location) "
            "must remain honored as a back-compat fallback."
        )

    def test_top_level_wins_over_inner_when_both_present(
        self, isolated_resolver,
    ):
        """When BOTH keys exist, the documented (top-level) location
        wins -- otherwise a yaml with both wins the inner one and the
        bug-fix is undermined."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": True,    # documented: should win
                "vault": {"enabled": False},  # back-compat: must NOT win
                "refs":  {"r1": {"type": "AD_accounts", "auth_url": "u",
                                  "secret_url": "s"}},
            },
        })
        assert r.is_vault_enabled() is True, (
            "Top-level secrets.enabled MUST win over secrets.vault.enabled "
            "when both are present -- otherwise operators following the "
            "docstring continue to see no effect."
        )

    def test_env_var_still_overrides_yaml(self, isolated_resolver, monkeypatch):
        """Layer 3 (env var) wins over global yaml when no workflow_config
        supplies an explicit override at Layer 2."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": False,
                "vault": {"enabled": False},
                "refs":  {"r1": {"type": "AD_accounts", "auth_url": "u",
                                  "secret_url": "s"}},
            },
        })
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        assert r.is_vault_enabled() is True

        monkeypatch.setenv("ETL_USE_VAULT", "0")
        # Even with both yaml keys true, env=0 forces OFF (kill switch).
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": True,
                "vault": {"enabled": True},
                "refs":  {"r1": {"type": "AD_accounts", "auth_url": "u",
                                  "secret_url": "s"}},
            },
        })
        r._vault_settings.cache_clear()
        assert r.is_vault_enabled() is False


class TestMixedPostureOraclePlainStarburstVault:
    """2026-07-01 prod incident: operator set ``ETL_USE_VAULT=1`` on
    the pod (because Starburst needs vault) AND set
    ``oracle.vault_enabled: false`` in oracle_config.yaml (because
    Oracle DB uses literal creds).  Under the pre-fix priority the
    env var short-circuited BEFORE the per-workflow explicit flag,
    so Oracle silently tried vault too.

    These tests lock the corrected priority:
      * ETL_USE_VAULT=0 (kill)     wins over everything
      * per-workflow explicit true/false wins over ETL_USE_VAULT=1
      * ETL_USE_VAULT=1 acts as a DEFAULT (only when workflow silent)
    """

    def test_oracle_workflow_false_wins_over_env_one(
            self, isolated_resolver, monkeypatch,
    ):
        """The user's ACTUAL prod scenario: env=1 for Starburst, Oracle
        yaml explicitly opts out.  Oracle must return False."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {
            "secrets": {
                "enabled": False,   # global default off
                "refs":  {"r1": {"type": "AD_accounts", "auth_url": "u",
                                  "secret_url": "s"}},
            },
        })
        monkeypatch.setenv("ETL_USE_VAULT", "1")   # ops enable for starburst

        oracle_cfg = {"vault_enabled": False}       # oracle opts out
        assert r.is_vault_enabled(workflow_config=oracle_cfg) is False, (
            "Per-workflow explicit vault_enabled=false MUST win over "
            "ETL_USE_VAULT=1.  This is the 2026-07-01 prod incident: "
            "ops set the env var for Starburst but Oracle yaml said no."
        )

    def test_starburst_workflow_true_still_uses_vault(
            self, isolated_resolver, monkeypatch,
    ):
        """Same env=1 setup — Starburst workflow (either explicit true
        OR silent) still uses vault."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {
            "secrets": {"enabled": False, "refs": {}},
        })
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        # Silent (no vault_enabled key) → env=1 default takes effect
        assert r.is_vault_enabled(workflow_config={}) is True
        # Explicit true (belt-and-braces) still True
        assert r.is_vault_enabled(
            workflow_config={"vault_enabled": True},
        ) is True

    def test_oracle_workflow_string_false_wins_over_env_one(
            self, isolated_resolver, monkeypatch,
    ):
        """Yaml may parse `vault_enabled: false` as Python bool or
        `vault_enabled: "false"` as string.  Both must take effect."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {"secrets": {"refs": {}}})
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        for wf_flag in (False, "false", "0", "no", "False"):
            assert r.is_vault_enabled(
                workflow_config={"vault_enabled": wf_flag},
            ) is False, f"vault_enabled={wf_flag!r} must resolve to False"

    def test_workflow_blank_falls_through_to_env(
            self, isolated_resolver, monkeypatch,
    ):
        """When workflow_config has vault_enabled="" (the yaml default
        placeholder), Layer 2 must be SKIPPED so env var / global yaml
        takes effect.  Otherwise the default oracle yaml would opt out
        every deployment."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {"secrets": {"refs": {}}})
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        # blank string is the default in every yaml — must not opt out
        assert r.is_vault_enabled(
            workflow_config={"vault_enabled": ""},
        ) is True
        # None (key absent entirely) same story
        assert r.is_vault_enabled(workflow_config={}) is True

    def test_env_zero_kills_even_when_workflow_true(
            self, isolated_resolver, monkeypatch,
    ):
        """The kill switch stays absolute: env=0 wins over an
        explicit workflow_config vault_enabled=true.  Ops MUST be
        able to disable vault fleet-wide during an incident."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {"secrets": {"enabled": True, "refs": {}}})
        monkeypatch.setenv("ETL_USE_VAULT", "0")
        assert r.is_vault_enabled(
            workflow_config={"vault_enabled": True},
        ) is False
        assert r.is_vault_enabled(
            workflow_config={"vault_enabled": "true"},
        ) is False

    def test_env_one_default_when_workflow_silent_and_global_off(
            self, isolated_resolver, monkeypatch,
    ):
        """Regression: ETL_USE_VAULT=1 must still enable vault when
        workflow_config is silent (or None).  This is the ops opt-in
        default — Slice 4 fix must not accidentally break it."""
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {"secrets": {"enabled": False, "refs": {}}})
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        assert r.is_vault_enabled() is True                          # None
        assert r.is_vault_enabled(workflow_config=None) is True      # explicit None
        assert r.is_vault_enabled(workflow_config={}) is True        # silent dict


class TestResolveWithCacheThreadsAutoLoadedOracleConfig:
    """2026-07-01 second-order bug: ``_resolve_with_cache`` auto-loaded
    oracle_config.yaml for the plain-creds check but passed the
    ORIGINAL ``workflow_config`` (often None from DAG callers) to
    ``is_vault_enabled`` -- so ``oracle.vault_enabled: false`` was
    invisible.  Fix locks that ``cfg_for_lookup`` (the auto-loaded
    dict) is threaded to the vault-enabled check too.
    """

    def test_dag_call_with_none_still_sees_oracle_vault_enabled_false(
            self, isolated_resolver, monkeypatch, tmp_path,
    ):
        """Simulate a DAG that called ``resolve_db_account(secret_ref)``
        with NO workflow_config.  The resolver auto-loads oracle_config.
        Oracle yaml says vault_enabled=false.  Even with ETL_USE_VAULT=1,
        the DAG must NOT hit vault.

        Expected: resolver raises 'vault DISABLED' RuntimeError with
        actionable message (there are no plain creds to fall back to
        in this synthetic scenario).
        """
        yaml_path, r = isolated_resolver
        _write_yaml(str(yaml_path), {"secrets": {"enabled": False, "refs": {}}})
        monkeypatch.setenv("ETL_USE_VAULT", "1")

        # Provide a fake oracle_config.yaml with vault_enabled: false
        # and NO literal creds (secret_ref set) so we hit Layer 4.
        oracle_yaml_path = tmp_path / "oracle_config.yaml"
        _write_yaml(str(oracle_yaml_path), {
            "oracle": {
                "vault_enabled": False,
                "etl": {"secret_ref": "etl_oracle_meta"},
            },
        })

        # Force the auto-load to find our tmp yaml
        monkeypatch.setattr(r, "_DEFAULT_ORACLE_CONFIG_PATHS",
                            [str(oracle_yaml_path)])

        # Clear cache instance (both mem + disk) so the test starts fresh
        r._cred_cache.reset_mem()
        try:
            r._cred_cache.disk_clear()
        except Exception:
            pass

        with pytest.raises(RuntimeError) as exc_info:
            r.resolve_db_account("etl_oracle_meta")
        msg = str(exc_info.value)
        assert "DISABLED" in msg or "vault" in msg.lower(), (
            f"Expected vault-disabled error message, got: {msg}"
        )
