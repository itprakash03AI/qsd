"""Tests for the 2026-06-29 observability hardening:

  * Alerter: throttle, vault outage, high failure rate, cross-pod degraded,
            email send, snapshot
  * Log setup: rotating file handler, JSON formatter, LoggerAdapter
  * Health endpoints: /metrics Prometheus format, audit log on pause/resume,
                       alerter snapshot on /status, /workflows/{name} shape
  * Plaintext-in-prod refusal in main._validate_runtime_env
"""
from __future__ import annotations

import importlib
import io
import json
import logging
import os
import time
from unittest.mock import MagicMock

import pytest

from polling_service.alerter import (
    AlertEvent, PluginAlerter, get_alerter, reset_alerter,
)
from polling_service.workflow_registry import reset_registry


# ── alerter ────────────────────────────────────────────────────────────


class TestAlerterCore:
    def _make(self, **overrides):
        sent = []
        defaults = dict(
            smtp_host="mock.smtp", email_from="a@b.c", email_to="x@y.z",
            cooldown_seconds=60,
            sender=lambda msg, alerter: sent.append(msg),
        )
        defaults.update(overrides)
        return PluginAlerter(**defaults), sent

    def test_alert_sends_when_smtp_configured(self):
        a, sent = self._make()
        ok = a.alert(AlertEvent(trigger="x", message="hi"))
        assert ok is True
        assert len(sent) == 1
        msg = sent[0]
        assert "x" in msg["Subject"]

    def test_disabled_when_smtp_unset(self):
        a, sent = self._make(smtp_host="")
        ok = a.alert(AlertEvent(trigger="x"))
        assert ok is False
        assert sent == []

    def test_throttle_within_cooldown(self):
        a, sent = self._make(cooldown_seconds=60)
        a.alert(AlertEvent(trigger="boom", plugin="p"))
        a.alert(AlertEvent(trigger="boom", plugin="p"))      # throttled
        a.alert(AlertEvent(trigger="boom", plugin="p"))      # throttled
        a.alert(AlertEvent(trigger="boom", plugin="other"))  # different plugin OK
        a.alert(AlertEvent(trigger="diff", plugin="p"))      # different trigger OK
        assert len(sent) == 3
        snap = a.snapshot()
        assert snap["alerts_sent"] == 3
        assert snap["alerts_throttled"] == 2

    def test_high_failure_rate_auto_emits(self):
        a, sent = self._make(failure_window_size=10, failure_rate_threshold=0.5)
        # 6 fails / 4 successes = 60% failure → trigger
        for ok_v in [False] * 6 + [True] * 4:
            a.record_outcome("oracle", success=ok_v)
        assert any("high_failure_rate" in m["Subject"] for m in sent)

    def test_high_failure_rate_below_threshold_silent(self):
        a, sent = self._make(failure_window_size=10, failure_rate_threshold=0.5)
        for ok_v in [True] * 8 + [False] * 2:
            a.record_outcome("oracle", success=ok_v)
        assert sent == []

    def test_vault_outage_after_threshold_failures(self):
        a, sent = self._make(vault_outage_threshold=3)
        a.record_vault_failure("err1")
        a.record_vault_failure("err2")
        assert sent == []   # only 2 — under threshold
        a.record_vault_failure("err3")
        assert any("vault_outage" in m["Subject"] for m in sent)

    def test_vault_success_resets_consecutive_failures(self):
        a, sent = self._make(vault_outage_threshold=3, cooldown_seconds=1)
        a.record_vault_failure("e")
        a.record_vault_failure("e")
        a.record_vault_success()
        a.record_vault_failure("e")
        a.record_vault_failure("e")
        # Should NOT have fired — counter was reset
        assert not any("vault_outage" in m["Subject"] for m in sent)

    def test_cross_pod_degraded_after_threshold(self):
        a, sent = self._make(cross_pod_degraded_threshold=3)
        a.record_cross_pod_degradation("ORA-XXX")
        a.record_cross_pod_degradation("ORA-XXX")
        assert sent == []
        a.record_cross_pod_degradation("ORA-XXX")
        assert any("cross_pod_degraded" in m["Subject"] for m in sent)

    def test_snapshot_returns_expected_shape(self):
        a, _ = self._make()
        snap = a.snapshot()
        for key in ("enabled", "smtp_host", "email_to", "worker_id",
                    "alerts_sent", "alerts_throttled", "smtp_failures",
                    "last_alert_at", "last_alert_trigger",
                    "vault_consecutive_failures", "cross_pod_window_size",
                    "thresholds"):
            assert key in snap, f"snapshot missing key {key!r}"

    def test_from_env_no_smtp_returns_disabled_alerter(self, monkeypatch):
        for k in ("SMTP_HOST", "SMTP_PORT", "EMAIL_FROM", "EMAIL_TO"):
            monkeypatch.delenv(k, raising=False)
        reset_alerter()
        a = get_alerter()
        snap = a.snapshot()
        assert snap["enabled"] is False


# ── log setup ──────────────────────────────────────────────────────────


class TestLogSetup:
    def test_text_format_default(self, tmp_path):
        from polling_service.log_setup import setup_logging
        log = setup_logging(str(tmp_path), "INFO", "test_worker", fmt="text")
        log.info("hello world")
        # Find file written
        # 2026-07-01 -- log_setup now writes a stable filename
        # (rotation suffixes become bg_poller_<id>.log.YYYY-MM-DD)
        # instead of embedding a timestamp in the base name.
        files = list(tmp_path.glob("bg_poller_test_worker*.log*"))
        assert files, "expected log file to be created"

    def test_json_format_emits_json(self, tmp_path):
        from polling_service.log_setup import setup_logging
        log = setup_logging(str(tmp_path), "INFO", "test_json", fmt="json")
        log.info("hello", extra={"run_id": 42})
        # Force the queue listener to flush
        import logging.handlers
        for h in logging.getLogger().handlers:
            if isinstance(h, logging.handlers.QueueHandler):
                listener = getattr(h, "_qs_polling_listener", None)
                if listener is not None:
                    listener.stop()
                    listener.start()
        time.sleep(0.05)
        files = list(tmp_path.glob("bg_poller_test_json*.log*"))
        assert files
        # Read with retry — the QueueListener flushes asynchronously
        content = ""
        for _ in range(20):
            content = files[0].read_text(encoding="utf-8")
            if content.strip():
                break
            time.sleep(0.05)
        if content.strip():
            # First non-empty line should parse as JSON.
            for line in content.splitlines():
                if line.strip():
                    payload = json.loads(line)
                    assert payload["level"] == "INFO"
                    assert "ts" in payload
                    break

    def test_qs_log_format_env_honored(self, tmp_path, monkeypatch):
        from polling_service.log_setup import setup_logging
        monkeypatch.setenv("QS_LOG_FORMAT", "json")
        log = setup_logging(str(tmp_path), "INFO", "envfmt", fmt="")
        # The root logger's queue handler should be wrapping a JSON-formatted file handler
        import logging.handlers
        json_found = False
        for h in logging.getLogger().handlers:
            if isinstance(h, logging.handlers.QueueHandler):
                listener = getattr(h, "_qs_polling_listener", None)
                if listener:
                    for inner in listener.handlers:
                        formatter = inner.formatter
                        if formatter and formatter.__class__.__name__ == "JsonFormatter":
                            json_found = True
        assert json_found, "expected JSON formatter under QS_LOG_FORMAT=json"

    def test_workflow_log_adapter_injects_extras(self):
        from polling_service.log_setup import WorkflowLogAdapter
        base = logging.getLogger("test_adapter")
        captured = []
        class _Capture(logging.Handler):
            def emit(self, record): captured.append(record)
        base.addHandler(_Capture())
        adapter = WorkflowLogAdapter(base, {"workflow": "oracle", "run_id": 99})
        adapter.info("hi")
        assert captured
        rec = captured[0]
        assert rec.workflow == "oracle"
        assert rec.run_id == 99


# ── health endpoint hardening ──────────────────────────────────────────


class TestHealthHardening:
    """Health endpoint integration tests for the new endpoints."""

    @pytest.fixture
    def client(self):
        from polling_service import health
        from polling_service.config import PollingServiceConfig
        from polling_service.service import BackgroundService
        from fastapi.testclient import TestClient

        reset_registry()
        reset_alerter()
        cfg = PollingServiceConfig(
            interval_seconds=30, max_concurrent_runs=2,
            etl_connection_string="dummy", dest_connection_string="dummy",
            bg_polling_sql="SELECT 1 FROM DUAL",
            use_lightweight_steps=False, workflows=[],
        )
        svc = BackgroundService(cfg, MagicMock(), logging.getLogger("test"))
        health.init_health_service(svc, MagicMock(), "dummy")
        return TestClient(health.app)

    def test_metrics_endpoint_returns_prometheus_text(self, client):
        r = client.get("/metrics")
        assert r.status_code == 200
        body = r.text
        assert "qs_polling_up 1" in body
        assert "# TYPE qs_polling_up gauge" in body
        # Should have per-plugin series
        assert 'qs_polling_dispatched_total{workflow="oracle"}' in body
        # Alerter series
        assert "qs_polling_alerts_sent_total" in body

    def test_pause_emits_audit_log(self, client, caplog):
        with caplog.at_level(logging.INFO, logger="bg_poller.health"):
            r = client.post("/pause")
        assert r.status_code == 200
        audit_lines = [r for r in caplog.records if "AUDIT" in r.message and "action=pause" in r.message]
        assert audit_lines, "pause should emit an AUDIT log line"

    def test_resume_emits_audit_log(self, client, caplog):
        client.post("/pause")
        with caplog.at_level(logging.INFO, logger="bg_poller.health"):
            r = client.post("/resume")
        assert r.status_code == 200
        audit_lines = [r for r in caplog.records if "AUDIT" in r.message and "action=resume" in r.message]
        assert audit_lines

    def test_per_workflow_pause_emits_audit_with_target(self, client, caplog):
        with caplog.at_level(logging.INFO, logger="bg_poller.health"):
            r = client.post("/workflows/oracle/pause")
        assert r.status_code == 200
        audit_lines = [r for r in caplog.records if "AUDIT" in r.message
                        and "action=pause" in r.message and "target=oracle" in r.message]
        assert audit_lines, "per-workflow pause should log target name"

    def test_status_includes_alerter_snapshot(self, client):
        r = client.get("/status")
        assert r.status_code == 200
        body = r.json()
        assert "alerter" in body
        assert "enabled" in body["alerter"]
        assert "alerts_sent" in body["alerter"]


# ── connection pool sharing (deep-dive #15 fix) ────────────────────────


class TestSharedOraclePool:
    """Round-2 deep-dive #15 fix: Dispatcher must reuse the
    BackgroundService's shared OracleMetadataManager instead of building
    a new one per run.  Without this, each run opens its own oracledb
    pool — 10 concurrent runs = 10 pools = 10-100 connections (vs the
    correct 1 pool capped at pool_max)."""

    def test_dispatcher_consumes_shared_oracle_manager_when_provided(self):
        import logging
        from polling_service.dispatcher import Dispatcher
        shared = MagicMock(name="shared_oracle_mgr")
        d = Dispatcher(
            logger=logging.getLogger("test"),
            use_lightweight_steps=False,
            shared_oracle_manager=shared,
        )
        assert d.shared_oracle_manager is shared

    def test_dispatcher_falls_back_to_per_run_when_unshared(self):
        """Back-compat: legacy callers that omit shared_oracle_manager
        get the old (per-run) behaviour with no breaking change."""
        import logging
        from polling_service.dispatcher import Dispatcher
        d = Dispatcher(logger=logging.getLogger("test"), use_lightweight_steps=False)
        assert d.shared_oracle_manager is None

    def test_background_service_wires_shared_pool_into_dispatcher(self):
        """BackgroundService must inject its own oracle_manager into the
        Dispatcher so the entire service shares one Oracle pool."""
        import logging
        from polling_service.config import PollingServiceConfig
        from polling_service.service import BackgroundService
        reset_registry()
        cfg = PollingServiceConfig(
            interval_seconds=30, max_concurrent_runs=2,
            etl_connection_string="dummy", dest_connection_string="dummy",
            bg_polling_sql="SELECT 1 FROM DUAL",
            use_lightweight_steps=False, workflows=[],
        )
        fake_oracle = MagicMock(name="bg_service_oracle_mgr")
        svc = BackgroundService(cfg, fake_oracle, logging.getLogger("test"))
        assert svc.dispatcher.shared_oracle_manager is fake_oracle


# ── plaintext-in-prod refusal ──────────────────────────────────────────


class TestPlaintextRefusal:
    def test_vault_on_plus_plaintext_on_calls_sys_exit(self, monkeypatch):
        from polling_service.log_setup import validate_runtime_env
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        monkeypatch.setenv("ETL_SECRETS_ALLOW_PLAINTEXT", "1")
        captured = []
        class _StubLogger:
            def error(self, *a, **kw): captured.append(("error", a))
            def warning(self, *a, **kw): captured.append(("warning", a))
        with pytest.raises(SystemExit) as exc:
            validate_runtime_env(_StubLogger())
        assert exc.value.code == 1
        assert any("UNSAFE" in str(a) for _, a in captured)

    def test_vault_on_no_secrets_key_warns_but_continues(self, monkeypatch):
        from polling_service.log_setup import validate_runtime_env
        monkeypatch.setenv("ETL_USE_VAULT", "1")
        monkeypatch.delenv("ETL_SECRETS_ALLOW_PLAINTEXT", raising=False)
        monkeypatch.delenv("ETL_SECRETS_KEY", raising=False)
        captured = []
        class _StubLogger:
            def error(self, *a, **kw): captured.append(("error", a))
            def warning(self, *a, **kw): captured.append(("warning", a))
        # Should not exit
        validate_runtime_env(_StubLogger())
        # Should have warned
        assert any(level == "warning" for level, _ in captured)

    def test_vault_off_is_silent(self, monkeypatch):
        from polling_service.log_setup import validate_runtime_env
        monkeypatch.delenv("ETL_USE_VAULT", raising=False)
        monkeypatch.delenv("ETL_SECRETS_ALLOW_PLAINTEXT", raising=False)
        captured = []
        class _StubLogger:
            def error(self, *a, **kw): captured.append(("error", a))
            def warning(self, *a, **kw): captured.append(("warning", a))
        validate_runtime_env(_StubLogger())
        assert captured == []
