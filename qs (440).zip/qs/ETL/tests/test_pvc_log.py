"""Tests for the shared PVC logging chokepoint
(``qs_credentials.pvc_log``).  Locks the idempotency + degraded-mode
contract that prevents log-line multiplication on scheduler re-parses
and ensures a PVC-write failure doesn't crash DAG parse."""
from __future__ import annotations

import logging
import os
import sys
from logging.handlers import TimedRotatingFileHandler

import pytest


_HERE = os.path.dirname(os.path.abspath(__file__))
_ETL_ROOT = os.path.dirname(_HERE)
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)

from qs_credentials.pvc_log import setup_pvc_logging  # noqa: E402


@pytest.fixture
def isolated_root_logger():
    """Snapshot + restore root logger handlers so tests don't pollute
    each other."""
    root = logging.getLogger()
    saved_handlers = list(root.handlers)
    saved_level    = root.level
    yield root
    root.handlers = saved_handlers
    root.setLevel(saved_level)


class TestPvcLogSetup:
    def test_creates_rotating_handler(self, tmp_path, isolated_root_logger):
        h = setup_pvc_logging("dag_x", log_dir=str(tmp_path))
        assert isinstance(h, TimedRotatingFileHandler)
        assert h.when == "MIDNIGHT"
        assert h.backupCount == 7

    def test_idempotent_no_duplicate_on_re_parse(self, tmp_path,
                                                    isolated_root_logger):
        """Calling setup twice with the same name MUST NOT add a second
        handler -- scheduler re-parses (~5min default) would otherwise
        stack handlers and multiply log lines."""
        before = len(isolated_root_logger.handlers)
        h1 = setup_pvc_logging("dag_dup", log_dir=str(tmp_path))
        h2 = setup_pvc_logging("dag_dup", log_dir=str(tmp_path))
        after = len(isolated_root_logger.handlers)
        assert h1 is not None
        assert h2 is None, "Second call MUST return None (already wired)"
        assert after - before == 1, (
            f"Re-parse must not stack handlers; before={before} after={after}"
        )

    def test_different_names_get_separate_handlers(self, tmp_path,
                                                     isolated_root_logger):
        h_a = setup_pvc_logging("dag_a", log_dir=str(tmp_path))
        h_b = setup_pvc_logging("dag_b", log_dir=str(tmp_path))
        assert h_a is not None and h_b is not None
        assert h_a is not h_b
        assert h_a.baseFilename != h_b.baseFilename

    def test_log_dir_created_if_missing(self, tmp_path, isolated_root_logger):
        log_dir = tmp_path / "deep" / "nested" / "logs"
        assert not log_dir.exists()
        h = setup_pvc_logging("dag_y", log_dir=str(log_dir))
        assert h is not None
        assert log_dir.is_dir()

    def test_silent_no_op_when_dir_not_writable(self, monkeypatch,
                                                  isolated_root_logger,
                                                  tmp_path):
        """PVC isn't writable on the worker pod -> setup_pvc_logging
        MUST return None without raising.  DAG parse continues."""
        def _boom(*a, **kw):
            raise OSError("permission denied")
        monkeypatch.setattr(os, "makedirs", _boom)
        result = setup_pvc_logging("dag_z", log_dir="/forbidden")
        assert result is None

    def test_silent_no_op_when_file_handler_raises(
        self, monkeypatch, tmp_path, isolated_root_logger,
    ):
        """File creation failure -> silent no-op."""
        from qs_credentials import pvc_log as _mod

        class _FH:
            def __init__(self, *a, **kw):
                raise OSError("disk full")

        monkeypatch.setattr(_mod, "TimedRotatingFileHandler", _FH)
        result = setup_pvc_logging("dag_full", log_dir=str(tmp_path))
        assert result is None

    def test_handler_writes_to_pvc_file(self, tmp_path,
                                          isolated_root_logger):
        """Round-trip: setup the handler, log a line, confirm it
        landed in the expected file."""
        h = setup_pvc_logging("dag_round", log_dir=str(tmp_path))
        assert h is not None
        log = logging.getLogger("qs_test_round_trip")
        log.warning("hello pvc")
        # delay=True means the file may not exist until first write;
        # the warning above should have triggered a flush.
        for handler in logging.getLogger().handlers:
            handler.flush()
        log_path = tmp_path / "dag_round.log"
        assert log_path.exists()
        content = log_path.read_text(encoding="utf-8")
        assert "hello pvc" in content

    # ── 2026-07-01 hotfix regression tests ─────────────────────────────

    def test_default_log_dir_is_nfs_not_pvc(self):
        """2026-07-01 hotfix: default log dir was moved off the 2GB PVC
        onto the NFS mount already used for ETL bulk output."""
        from qs_credentials import pvc_log
        assert pvc_log.DEFAULT_LOG_DIR.startswith("/usr/local/spark/nfs/"), (
            f"default log dir must be under NFS mount; "
            f"got {pvc_log.DEFAULT_LOG_DIR!r}"
        )
        assert "/pvc/" not in pvc_log.DEFAULT_LOG_DIR, (
            "default log dir must not point at the 2GB PVC quota"
        )

    def test_backup_days_default_is_7(self):
        from qs_credentials import pvc_log
        assert pvc_log.DEFAULT_BACKUP_DAYS == 7

    def test_sweep_deletes_files_older_than_cap(
        self, tmp_path, isolated_root_logger,
    ):
        """Belt-and-braces age sweep must delete rotated files older
        than ``max_age_days`` even if backupCount never fired."""
        import time
        # Create a stale rotated file dated 30 days ago.
        stale = tmp_path / "dag_sweep.log.2026-06-01"
        stale.write_text("old data")
        old_time = time.time() - (30 * 24 * 3600)
        os.utime(stale, (old_time, old_time))

        # Also create a FRESH file that must be kept.
        fresh = tmp_path / "dag_sweep.log.today"
        fresh.write_text("recent")

        setup_pvc_logging(
            "dag_sweep", log_dir=str(tmp_path), max_age_days=7,
        )
        assert not stale.exists(), "stale file must be swept"
        assert fresh.exists(), "recent file must be kept"

    def test_sweep_ignores_other_logs(
        self, tmp_path, isolated_root_logger,
    ):
        """Sweep must NOT touch files from a different log stem."""
        import time
        # A file from another DAG's log stem -- must be untouched.
        other = tmp_path / "different_dag.log.2026-06-01"
        other.write_text("other")
        os.utime(other, (time.time() - 30 * 24 * 3600, time.time() - 30 * 24 * 3600))

        setup_pvc_logging(
            "dag_sweep_isolation", log_dir=str(tmp_path), max_age_days=7,
        )
        assert other.exists(), "sweep must not delete other DAG's logs"

    def test_disable_via_env(self, monkeypatch, tmp_path, isolated_root_logger):
        """QS_DAG_LOG_DISABLE=1 must skip attaching the handler."""
        monkeypatch.setenv("QS_DAG_LOG_DISABLE", "1")
        result = setup_pvc_logging("dag_off", log_dir=str(tmp_path))
        assert result is None

    def test_legacy_disable_env_still_honored(
        self, monkeypatch, tmp_path, isolated_root_logger,
    ):
        monkeypatch.setenv("QS_PVC_LOG_DISABLE", "true")
        result = setup_pvc_logging("dag_off_legacy", log_dir=str(tmp_path))
        assert result is None

    def test_env_override_log_dir(
        self, monkeypatch, tmp_path, isolated_root_logger,
    ):
        """QS_DAG_LOG_DIR env var must win over the default."""
        custom = tmp_path / "custom_nfs"
        monkeypatch.setenv("QS_DAG_LOG_DIR", str(custom))
        h = setup_pvc_logging("dag_env")
        assert h is not None
        assert h.baseFilename.startswith(str(custom))

    def test_env_override_backup_days(
        self, monkeypatch, tmp_path, isolated_root_logger,
    ):
        monkeypatch.setenv("QS_DAG_LOG_BACKUP_DAYS", "14")
        h = setup_pvc_logging("dag_env_backup", log_dir=str(tmp_path))
        assert h is not None
        assert h.backupCount == 14

    def test_legacy_backup_env_still_honored(
        self, monkeypatch, tmp_path, isolated_root_logger,
    ):
        monkeypatch.setenv("QS_PVC_LOG_BACKUP_COUNT", "5")
        h = setup_pvc_logging("dag_env_legacy_bc", log_dir=str(tmp_path))
        assert h is not None
        assert h.backupCount == 5

    def test_dag_consumers_use_shared_chokepoint(self):
        """Source-grep contract: each DAG file MUST import from the
        shared chokepoint.  Catches a regression where someone
        inlines a TimedRotatingFileHandler back into a DAG file
        instead of using the shared helper."""
        dags = [
            "vault_prewarm_dag.py",
            "daily_sod_dag.py",
            "dynamic_dags_airflow.py",
        ]
        for fname in dags:
            path = os.path.join(_ETL_ROOT, "airflow_dag", fname)
            text = open(path, "r", encoding="utf-8").read()
            assert "from qs_credentials.pvc_log import setup_pvc_logging" in text, (
                f"{fname}: must import from the shared chokepoint."
            )
            # Source-grep BAN on inline TimedRotatingFileHandler --
            # would mean someone re-introduced the duplicate.
            assert "TimedRotatingFileHandler(" not in text, (
                f"{fname}: inlines TimedRotatingFileHandler instead of "
                "delegating to qs_credentials.pvc_log.setup_pvc_logging."
            )
