"""Hive metastore -> file extract step (on-prem).

2026-06-22 -- on-prem reads from Hive metastore over S3-compatible
storage.  AWS S3 / OnCloud reads use iceberg (see iceberg_to_file.py).

Spark session built via the shared ``S3BaseStep._build_spark_session_s3``
with ``with_hive=True`` so this path inherits the full k8s + event-log
+ memory + arrow-enabled + adaptive-SQL config used by every other S3
step (single source of truth for Spark plumbing).

Config (per-environment, from configs/s3_config.yaml -> s3.onprem.hive):
  * hive_metastore_uris   (thrift://hive-metastore.host:9083)
  * hive_warehouse_dir    (hdfs://... or s3a://...)
  * hive_catalog_name     (defaults to "spark_catalog")

Per-job JSON drives:
  * query        -- the SQL (refs Hive table names directly, e.g.
                    "SELECT * FROM mydb.fact_table WHERE ...";
                    NOT the "source" temp view -- that's only for
                    iceberg/parquet extract steps)
  * output_path  -- destination file on NFS
  * output_format / delimiter / header / write_mode
  * num_partitions / spark_executor_memory / spark_driver_memory
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict

from steps.s3.s3_query_base import S3QueryBase


class HiveToFile_OnPrem(S3QueryBase):
    """On-prem Hive metastore -> NFS file via Spark SQL."""

    ENVIRONMENT = "onprem"
    REQUIRES_HIVE = True
    LOG_PREFIX = "hive_to_file_onprem"

    REQUIRED_FIELDS = [
        *S3QueryBase.BASE_REQUIRED_FIELDS,
        "output_path",
    ]

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config, with_hive=True)
            query = self._parameterize_query(config["query"], task)
            self.logger.info(f"Hive query:\n{query}")

            report_id = task.get("fk_report_id") or "hive_onprem"
            self._record_source_query(task, query, report_id)

            read_start = datetime.now()
            df = spark.sql(query)
            # Phase 152 parity: one Spark agg pass yields COUNT + SUM(col)
            # per checksum column.  Source SUMs stash on task for the
            # sink-side verify in _write_to_file (which re-reads the
            # written file + agg-verifies against these anchors).
            ck_cols = self._resolve_checksum_columns(config, task)
            row_count, source_sums = self._compute_source_anchors(df, ck_cols)
            task["_source_row_count"] = row_count
            task["_source_checksums"] = source_sums
            task["_checksum_columns"] = ck_cols
            read_time = (datetime.now() - read_start).total_seconds()
            self.logger.info(
                "Hive read complete: %s rows in %.1fs (checksum_columns=%s, source_sums=%s)",
                f"{row_count:,}", read_time, ck_cols,
                ", ".join(f"SUM({c})={v}" for c, v in source_sums.items()) or "(none)",
            )
            task["totalcount"] = row_count

            output_path, _ = self._write_to_file(df, config, task)
            self._set_delivery_chain_aliases(task, output_path)
            self._register_output_artifact(task, output_path)
            self._record_extract_counts(
                task, report_id, "ONPREM_HIVE", row_count, output_path,
            )

            if self.oracle_data_manager:
                await self.oracle_data_manager.update_otg_etl_batch_status(
                    task.get("run_id"), task.get("run_detail_id"),
                    "UPDATE_TASK_RECORDCOUNT", step_name,
                    row_count, "", worker_connection_string,
                )
            return row_count

        except Exception as exc:
            self.logger.error(f"JOB FAILED: {exc}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    pass  # 2026-06-26 -- spark.stop() removed; lifted to standalone main() finally (pod-shared SparkContext)
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
