"""Hive metastore -> Oracle extract+load step (on-prem).

2026-06-22 -- on-prem path.  Mirror of HiveToFile_OnPrem but writes the
resulting DataFrame to Oracle via Spark JDBC instead of a file.

Spark session built via the shared ``S3BaseStep._build_spark_session_s3``
with ``with_hive=True`` -- inherits full k8s + event-log config from
the same builder iceberg uses.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict

from steps.s3.s3_query_base import S3QueryBase


class HiveToOracle_OnPrem(S3QueryBase):
    """On-prem Hive metastore -> Oracle via Spark JDBC."""

    ENVIRONMENT = "onprem"
    REQUIRES_HIVE = True
    LOG_PREFIX = "hive_to_oracle_onprem"

    REQUIRED_FIELDS = [
        *S3QueryBase.BASE_REQUIRED_FIELDS,
        "oracle_url", "oracle_user", "oracle_password",
    ]

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config, with_hive=True)
            query = self._parameterize_query(config["query"], task)
            self.logger.info(f"Hive query:\n{query}")

            report_id = task.get("fk_report_id") or "hive_onprem_to_oracle"
            self._record_source_query(task, query, report_id)

            df = spark.sql(query)
            # Phase 152 parity: source COUNT + SUMs in one agg pass.
            # Oracle write path doesn't have a sink-side verify (Spark
            # JDBC write is atomic per partition + row count == truth),
            # but we stash the anchors on the task so result.html still
            # shows the checksum trail for audit.
            ck_cols = self._resolve_checksum_columns(config, task)
            row_count, source_sums = self._compute_source_anchors(df, ck_cols)
            task["_source_row_count"] = row_count
            task["_source_checksums"] = source_sums
            task["_checksum_columns"] = ck_cols
            self.logger.info(
                "Hive read complete: %s rows (checksum_columns=%s, source_sums=%s)",
                f"{row_count:,}", ck_cols,
                ", ".join(f"SUM({c})={v}" for c, v in source_sums.items()) or "(none)",
            )
            task["totalcount"] = row_count

            num_partitions = int(config.get("num_partitions", 10))
            batch_size = int(config.get("batch_size", 50000))
            dest_table = task.get("dest_table") or config.get("dest_table")
            if not dest_table:
                raise ValueError(
                    "dest_table missing in both polling-row task + per-job JSON"
                )
            self.logger.info(
                f"Writing {row_count:,} rows to Oracle.{dest_table} "
                f"({num_partitions} partitions, batch_size={batch_size})"
            )
            write_start = datetime.now()
            (
                df.repartition(num_partitions)
                .write.format("jdbc")
                .option("url", config["oracle_url"])
                .option("dbtable", dest_table)
                .option("user", config["oracle_user"])
                .option("password", config["oracle_password"])
                .option("driver", "oracle.jdbc.OracleDriver")
                .option("batchsize", str(batch_size))
                .option("isolationLevel", "NONE")
                .option("numPartitions", str(num_partitions))
                .mode("append")
                .save()
            )
            write_time = (datetime.now() - write_start).total_seconds()
            self.logger.info(f"Oracle write complete in {write_time:.1f}s")

            self._record_extract_counts(
                task, report_id, "ONPREM_HIVE", row_count, "",
            )

            if self.oracle_data_manager:
                await self.oracle_data_manager.update_otg_etl_batch_status(
                    task.get("run_id"), task.get("run_detail_id"),
                    "UPDATE_TASK_RECORDCOUNT", step_name,
                    row_count, "", worker_connection_string,
                )
            return row_count

        except Exception as exc:
            self.logger.error(f"JOB FAILED: {exc}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    pass  # 2026-06-26 -- spark.stop() removed; lifted to standalone main() finally (pod-shared SparkContext)
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
