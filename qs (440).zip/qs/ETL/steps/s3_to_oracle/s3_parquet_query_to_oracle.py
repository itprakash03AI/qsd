"""Phase 134-P — Parquet → Oracle via user SQL.

Reads parquet files from ``s3a://bucket/prefix``, runs the user's
SQL against them (Spark parquet row-group filter pushdown), writes
to Oracle via JDBC.  Parity with ``s3_parquet_to_oracle.py`` but
with projection + filter pushdown expressed as a SQL ``WHERE``
clause instead of read-everything-then-filter.
"""
from __future__ import annotations

from typing import Any, Dict

from steps.s3.s3_query_base import S3QueryBase


class S3ParquetQueryToOracle(S3QueryBase):
    """Read parquet via Spark SQL, sink to Oracle via JDBC."""

    LOG_PREFIX = "s3_parquet_query_to_oracle"

    REQUIRED_FIELDS = [
        *S3QueryBase.BASE_REQUIRED_FIELDS,
        "s3_prefix",
        "oracle_url", "oracle_user", "oracle_password",
    ]

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        oracle_table = self._get_dest_table(task, config)
        if not oracle_table:
            raise ValueError(
                "dest_table is required (set in the polling row or "
                "the per-task JSON config) for Oracle-sink steps"
            )
        batch_size = int(config.get("batch_size", 50000))
        num_partitions = int(config.get("num_partitions", 10))

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config, with_iceberg=False)
            df, total_rows, _read_time = self._read_parquet_with_query(spark, config, task)
            task["totalcount"] = total_rows

            self._write_to_oracle(df, config, oracle_table, batch_size, num_partitions)

            if self.oracle_data_manager:
                await self.oracle_data_manager.update_otg_etl_batch_status(
                    task.get("run_id"), task.get("run_detail_id"),
                    "UPDATE_TASK_RECORDCOUNT", step_name,
                    total_rows, "", worker_connection_string,
                )
            return total_rows

        except Exception as exc:
            self.logger.error(f"JOB FAILED: {exc}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    pass  # 2026-06-26 -- spark.stop() removed; lifted to standalone main() finally (pod-shared SparkContext)
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
