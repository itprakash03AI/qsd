"""
Shared base class for S3/Iceberg Spark steps.
Provides S3A configuration, Iceberg catalog setup, presigned URL fallback,
and common Spark session building with S3/Iceberg extensions.
"""
import os
import json
import logging
import sys
import tempfile
from datetime import datetime
from typing import Dict, Any, List, Optional

from pyspark.sql import SparkSession
from steps.BaseStep import BaseStep


class S3BaseStep(BaseStep):
    """Base class for S3/Iceberg steps with shared S3 config and Spark setup."""

    LOG_PREFIX: str = "s3_step"

    # Subclasses override these to drive yaml loading + validation:
    #   ENVIRONMENT      -- "oncloud" | "onprem"  (which s3_config.yaml section)
    #   REQUIRES_ICEBERG -- True for iceberg-table reads
    #   REQUIRES_HIVE    -- True for hive-metastore reads (on-prem)
    #
    # 2026-06-22 back-compat trap: legacy class names (S3IcebergQueryExtract,
    # S3ParquetQueryExtract, S3IcebergQueryToOracle, S3ParquetQueryToOracle)
    # inherit this default of "oncloud".  Existing on-prem deployments
    # using the legacy names will silently load oncloud yaml -- migrate
    # to the per-environment step names (IcebergToFile_OnPrem etc.) to
    # get the right env.
    ENVIRONMENT: str = "oncloud"
    REQUIRES_ICEBERG: bool = False
    REQUIRES_HIVE: bool = False

    def _load_and_validate_config(self, task: Dict, required_fields: List[str]) -> Dict:
        """Load JSON config, merge shared s3_config.yaml, validate fields.

        2026-06-22 -- environment-aware: picks the yaml ``s3.<ENVIRONMENT>``
        subsection so OnCloud (AWS, iceberg) and OnPrem (Hive today,
        iceberg later) steps get the right per-environment defaults
        without operator-side selection logic.
        """
        config_path = task.get('sql_query_path')
        if not config_path:
            raise ValueError("Task missing 'sql_query_path'")

        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Config file not found: {config_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in config {config_path}: {e}")

        # Shared AWS / S3 yaml fallback (per-environment section).
        try:
            from s3_config_loader import merge_shared_into_job_config as _merge_s3
            _merge_s3(
                config,
                environment=self.ENVIRONMENT,
                logger=getattr(self, "logger", None),
            )
        except Exception as exc:
            if getattr(self, "logger", None):
                self.logger.warning(
                    f"s3_config_loader unavailable ({exc}); using per-job "
                    f"JSON values + env vars only."
                )

        # Per-step required_fields check.
        missing = [f for f in required_fields if not config.get(f)]
        if missing:
            raise ValueError(
                f"Missing required config fields in {config_path}: {missing}.\n"
                f"Set them in the per-job JSON OR (for AWS / S3 fields) in "
                f"configs/s3_config.yaml -> s3.{self.ENVIRONMENT}."
            )

        # AWS / S3 / catalog cred validation.
        try:
            from s3_config_loader import validate_s3_yaml_for_job as _validate
            _validate(
                config,
                environment=self.ENVIRONMENT,
                requires_iceberg=self.REQUIRES_ICEBERG,
                requires_hive=self.REQUIRES_HIVE,
                logger=getattr(self, "logger", None),
            )
        except ImportError:
            pass

        return config

    def _setup_logging(self, task: Dict) -> None:
        """Configure a named logger for this step.

        2026-07-02 -- single chokepoint (log_config.attach_step_logger)
        so the S3 workflows (s3_to_file, s3_to_oracle, s3_query) share
        ONE log file per run.  Workflow arg resolved via
        ``get_workflow_name`` (ContextVar > module var > env var >
        default) so concurrent runs in the same pod stay isolated.
        """
        from log_config import attach_step_logger, get_workflow_name
        workflow = get_workflow_name(default="s3_workflow")
        self.logger = attach_step_logger(
            f"etl.{self.LOG_PREFIX}", task, workflow=workflow,
        )

    def _build_spark_session_s3(
        self,
        task: Dict,
        config: Dict,
        with_iceberg: bool = False,
        with_hive: bool = False,
    ) -> SparkSession:
        """Build SparkSession with S3A + optional Iceberg / Hive support.

        2026-06-22 -- ``with_hive`` added so HiveToFile_OnPrem /
        HiveToOracle_OnPrem inherit the same k8s + event-log + memory
        config as the iceberg path (was duplicated + drift-prone in a
        separate ``_build_hive_spark_session`` method).
        """
        run_id = task.get('run_id', 'unknown')
        run_detail_id = task.get('run_detail_id', 'unknown')
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')

        executor_memory = config.get('spark_executor_memory', '10g')
        driver_memory = config.get('spark_driver_memory', '3g')
        num_partitions = config.get('num_partitions', 10)
        spark_jars = config.get('spark_jars', '')

        try:
            from log_config import get_log_dir as _resolve_log_dir
            _evt_root = _resolve_log_dir()
        except Exception:
            _evt_root = "/usr/local/spark/nfs/bcp/batch/logs"
        event_log_dir = os.path.join(
            _evt_root, "event-logs",
            f"{run_id}_{run_detail_id}_{timestamp}",
        )
        os.makedirs(event_log_dir, exist_ok=True)

        builder = (
            SparkSession.builder
            .appName(f"{self.LOG_PREFIX}_{run_id}-{run_detail_id}")
            .config("spark.executor.cores", "1")
            .config("spark.kubernetes.executor.request.cores", "300m")
            .config("spark.kubernetes.executor.limit.cores", "1")
            .config("spark.executor.memory", executor_memory)
            .config("spark.driver.memory", driver_memory)
            .config("spark.executor.memoryOverhead", config.get('spark_executor_memory_overhead', '1g'))
            .config("spark.driver.memoryOverhead", config.get('spark_driver_memory_overhead', '1g'))
            .config("spark.executor.instances", "1")
            .config("spark.sql.shuffle.partitions", str(num_partitions))
            .config("spark.sql.execution.arrow.pyspark.enabled", "true")
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.dynamicAllocation.enabled", "false")
            .config("spark.eventLog.enabled", "true")
            .config("spark.eventLog.dir", event_log_dir)
        )

        if spark_jars:
            builder = builder.config("spark.jars", spark_jars)

        # S3A configuration -- both iceberg + hive paths still need
        # the S3A auth + endpoint settings for reading from object storage.
        builder = self._configure_s3a(builder, config)

        # Iceberg configuration (optional).
        if with_iceberg:
            builder = self._configure_iceberg_catalog(builder, config)

        # Hive metastore configuration (optional, on-prem catalog).
        if with_hive:
            builder = self._configure_hive_metastore(builder, config)

        return builder.getOrCreate()

    def _configure_hive_metastore(self, builder, config: Dict):
        """Wire Spark to an on-prem Hive metastore.

        2026-06-22 -- added for HiveToFile_OnPrem / HiveToOracle_OnPrem.
        Sets ``spark.hadoop.hive.metastore.uris`` + warehouse dir +
        catalog impl, then calls ``enableHiveSupport()`` so
        ``spark.sql("SELECT * FROM db.table")`` resolves against Hive.

        Required config (filled from ``s3.onprem.hive.*`` yaml):
          * hive_metastore_uris  (e.g. thrift://hive-metastore.host:9083)
          * hive_warehouse_dir   (e.g. hdfs://nn/warehouse OR s3a://...)
        """
        uris = config.get("hive_metastore_uris", "")
        warehouse = config.get("hive_warehouse_dir", "")
        if not uris:
            raise ValueError(
                "Hive Spark session requested but hive_metastore_uris is "
                "empty.  Fill configs/s3_config.yaml -> s3.onprem.hive."
                "metastore_uris OR set the field in per-job JSON."
            )
        builder = (
            builder
            .config("spark.hadoop.hive.metastore.uris", uris)
            .config("spark.sql.catalogImplementation", "hive")
        )
        if warehouse:
            builder = builder.config("spark.sql.warehouse.dir", warehouse)
        return builder.enableHiveSupport()

    def _configure_s3a(self, builder, config: Dict):
        """Configure Spark S3A FileSystem for AWS or on-prem S3.

        2026-06-20 -- now routes through ``ETL/aws_credentials.py`` which
        mirrors QS API's credential resolver contract.  Per-job JSON can
        set ``auth_mode`` to one of:

          * ``keys``        -- literal s3_access_key/secret in JSON (back-compat)
          * ``env``         -- read AWS_ACCESS_KEY_ID/SECRET_ACCESS_KEY from pod env
          * ``iam_role``    -- boto3 default chain (EKS IRSA / EC2 instance role)
          * ``profile``     -- named AWS CLI profile (``aws_profile`` field)
          * ``assume_role`` -- STS AssumeRole on ``role_arn``

        When ``auth_mode`` is unset AND keys are empty, falls back to the
        boto3 default chain so pod-identity / IRSA picks up automatically.

        For ``iam_role``, the Spark s3a client uses the same
        ``TemporaryAWSCredentialsProvider`` with the session token the
        resolver produced from boto3 -- works because Hadoop s3a accepts
        session-token-backed temporary credentials.
        """
        # Resolve credentials via the same chain QS API uses.  Returns
        # a copy with aws_access_key_id/secret/session_token populated
        # from whichever auth_mode the operator picked.
        try:
            from aws_credentials import resolve_s3_credentials as _resolve
            config = _resolve(config)
        except ImportError:
            # Resolver unavailable -- legacy literal-keys path.
            pass

        access_key = config.get('s3_access_key') or config.get('aws_access_key_id') or ''
        secret_key = config.get('s3_secret_key') or config.get('aws_secret_access_key') or ''
        session_token = config.get('s3_session_token') or config.get('aws_session_token') or ''
        endpoint = config.get('s3_endpoint_url') or config.get('endpoint_url') or ''
        path_style = (
            config.get('s3_path_style_access', None)
            if config.get('s3_path_style_access', None) is not None
            else config.get('path_style', False)
        )

        builder = (
            builder
            .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
        )
        if access_key and secret_key:
            builder = (
                builder
                .config("spark.hadoop.fs.s3a.access.key", access_key)
                .config("spark.hadoop.fs.s3a.secret.key", secret_key)
            )
            if session_token:
                # Temporary (STS / IRSA-derived) credentials need the
                # session-token provider so Hadoop s3a sends X-Amz-Security-Token.
                builder = (
                    builder
                    .config("spark.hadoop.fs.s3a.session.token", session_token)
                    .config(
                        "spark.hadoop.fs.s3a.aws.credentials.provider",
                        "org.apache.hadoop.fs.s3a.TemporaryAWSCredentialsProvider",
                    )
                )
        else:
            # No keys resolved -- let Hadoop s3a's default credential
            # provider chain pick up creds from instance metadata / env.
            self.logger.info(
                "S3A: no explicit credentials resolved -- relying on "
                "Hadoop's default credential provider chain (instance "
                "metadata / env / IRSA web-identity)."
            )

        if endpoint:
            # On-prem S3 (Dell ECS, MinIO, etc.)  OR VPC endpoint URL.
            builder = (
                builder
                .config("spark.hadoop.fs.s3a.endpoint", endpoint)
                .config("spark.hadoop.fs.s3a.path.style.access", str(path_style).lower())
                .config("spark.hadoop.fs.s3a.connection.ssl.enabled",
                         str(config.get('s3_ssl_enabled', True)).lower())
            )

        # 2026-06-22 -- HTTP proxy support for environments without VPC
        # endpoint.  Two layers need configuration:
        #   1. Hadoop S3A:  spark.hadoop.fs.s3a.proxy.*  (Spark bulk reads)
        #   2. JVM-wide:    -Dhttps.proxyHost / Port      (Iceberg REST
        #      catalog HTTP client + any other JVM HTTP traffic)
        # boto3 (Python) honors HTTP_PROXY / HTTPS_PROXY env vars
        # automatically -- no Spark config needed for the boto3 layer.
        # Yaml fields win; env vars fill blanks.
        builder = self._configure_proxy(builder, config)

        # 2026-06-22 bug #29 -- close honest gaps from session audit.
        #
        # Gap 1: STS token refresh during long-running Spark reads.
        # When operator's auth_mode is 'assume_role', Hadoop S3A's
        # AssumedRoleCredentialProvider does its OWN STS refresh
        # transparently (Hadoop 3.3+).  Switch to it when the resolver
        # produced session creds via assume_role (detected by presence
        # of role_arn in config) so a 4-hour Spark read doesn't die
        # mid-read with 403 ExpiredToken.
        if (config.get('auth_mode') == 'assume_role'
                or config.get('role_arn')):
            role_arn = config.get('role_arn') or config.get('aws_role_arn')
            if role_arn:
                builder = (
                    builder
                    .config(
                        "spark.hadoop.fs.s3a.aws.credentials.provider",
                        "org.apache.hadoop.fs.s3a.auth.AssumedRoleCredentialProvider",
                    )
                    .config("spark.hadoop.fs.s3a.assumed.role.arn", role_arn)
                    .config(
                        "spark.hadoop.fs.s3a.assumed.role.session.duration",
                        config.get('assume_role_session_duration', '1h'),
                    )
                )
                # The base provider AssumedRole uses to auth its STS call.
                # Default to InstanceProfileCredentialsProvider (EC2/EKS
                # node identity) -- works on IRSA + instance-role pods.
                builder = builder.config(
                    "spark.hadoop.fs.s3a.assumed.role.credentials.provider",
                    config.get(
                        'assume_role_base_provider',
                        "org.apache.hadoop.fs.s3a.auth.IAMInstanceCredentialsProvider",
                    ),
                )
                self.logger.info(
                    "S3A: AssumedRoleCredentialProvider engaged -- STS "
                    "auto-refresh active for role=%s.  Long-running "
                    "Spark reads survive token expiry.", role_arn,
                )

        # Gap 2: S3A throttling / retry hardening.  Defaults are
        # ok for light loads but flaky under heavy parquet/iceberg
        # parallelism.  Tunable per-job via config; sane defaults below.
        s3a_retry = {
            "spark.hadoop.fs.s3a.attempts.maximum":     config.get('s3a_attempts_max', "20"),
            "spark.hadoop.fs.s3a.retry.limit":          config.get('s3a_retry_limit', "10"),
            "spark.hadoop.fs.s3a.retry.interval":       config.get('s3a_retry_interval', "500ms"),
            "spark.hadoop.fs.s3a.retry.throttle.limit": config.get('s3a_throttle_retry_limit', "20"),
            "spark.hadoop.fs.s3a.retry.throttle.interval": config.get('s3a_throttle_interval', "1000ms"),
            "spark.hadoop.fs.s3a.connection.maximum":   config.get('s3a_connection_max', "200"),
            "spark.hadoop.fs.s3a.threads.max":          config.get('s3a_threads_max', "32"),
            "spark.hadoop.fs.s3a.connection.timeout":   config.get('s3a_connection_timeout', "200000"),
            # 'random' fadvise = better for parquet row-group reads
            # (sequential is for whole-file scans like CSV).
            "spark.hadoop.fs.s3a.experimental.input.fadvise":
                config.get('s3a_input_fadvise', "random"),
            # Multipart upload tuning (only matters for s3_to_oracle
            # paths that might write back to S3 via Spark; harmless otherwise).
            "spark.hadoop.fs.s3a.multipart.size":       config.get('s3a_multipart_size', "104857600"),
            "spark.hadoop.fs.s3a.fast.upload":          "true",
            # SSE-S3 default; operators can override per-job for SSE-KMS.
            "spark.hadoop.fs.s3a.server-side-encryption-algorithm":
                config.get('s3a_sse_algorithm', "AES256"),
        }
        for k, v in s3a_retry.items():
            builder = builder.config(k, str(v))

        return builder

    def _configure_proxy(self, builder, config: Dict):
        """Wire HTTP proxy settings for both Hadoop S3A + JVM-wide HTTP.

        2026-06-22 -- used when the pod can't reach S3 directly (no VPC
        endpoint).  Configures three layers:
          1. Hadoop S3A   -- spark.hadoop.fs.s3a.proxy.{host,port,...}
                            (drives parquet / iceberg manifest reads)
          2. JVM-wide      -- -Dhttps.proxyHost / -Dhttps.proxyPort /
                            -Dhttps.nonProxyHosts in driver+executor
                            extraJavaOptions (drives iceberg REST
                            catalog HTTP, hive metastore over HTTPS,
                            any other JVM HTTP traffic)
          3. boto3 Python  -- already auto-respects HTTP_PROXY /
                            HTTPS_PROXY env vars; no Spark config needed.

        Resolution order (per field):
          per-job JSON  >  yaml s3.<env>.proxy_*  >  HTTPS_PROXY env var

        Edge cases handled:
          * proxy_host set but proxy_port zero/blank -> ValueError
          * proxy_port=0 sentinel = "not configured"
          * authenticated proxy (proxy_username + proxy_password)
          * NO_PROXY env var -> -Dhttps.nonProxyHosts (JVM bypass list)
          * fully blank -> no-op (no proxy)
        """
        proxy_host = (config.get("s3_proxy_host") or "").strip()
        proxy_port_raw = config.get("s3_proxy_port") or 0
        proxy_user = (config.get("s3_proxy_username") or "").strip()
        proxy_pass = config.get("s3_proxy_password") or ""

        # Fall back to HTTPS_PROXY env var if yaml is fully blank.
        if not proxy_host:
            env_proxy = (
                os.environ.get("HTTPS_PROXY")
                or os.environ.get("https_proxy")
                or os.environ.get("HTTP_PROXY")
                or os.environ.get("http_proxy")
                or ""
            ).strip()
            if env_proxy:
                from urllib.parse import urlparse
                p = urlparse(
                    env_proxy if "://" in env_proxy else f"http://{env_proxy}"
                )
                proxy_host = p.hostname or ""
                proxy_port_raw = p.port or (443 if p.scheme == "https" else 80)
                if p.username and not proxy_user:
                    proxy_user = p.username
                if p.password and not proxy_pass:
                    proxy_pass = p.password

        if not proxy_host:
            return builder  # no proxy configured -- no-op

        try:
            proxy_port = int(proxy_port_raw)
        except (TypeError, ValueError):
            proxy_port = 0
        if proxy_port <= 0:
            raise ValueError(
                f"S3 proxy_host={proxy_host!r} is set but proxy_port "
                f"is empty / zero.  Set s3.<env>.proxy_port in yaml "
                f"(e.g. 3128) or fix the HTTPS_PROXY env var."
            )

        self.logger.info(
            "S3 proxy configured: host=%s port=%s auth=%s",
            proxy_host, proxy_port, "yes" if proxy_user else "no",
        )

        # Layer 1: Hadoop S3A.
        builder = (
            builder
            .config("spark.hadoop.fs.s3a.proxy.host", proxy_host)
            .config("spark.hadoop.fs.s3a.proxy.port", str(proxy_port))
        )
        if proxy_user:
            builder = (
                builder
                .config("spark.hadoop.fs.s3a.proxy.username", proxy_user)
                .config("spark.hadoop.fs.s3a.proxy.password", str(proxy_pass))
            )
        # Default to SSL if port == 443; otherwise HTTP.
        builder = builder.config(
            "spark.hadoop.fs.s3a.proxy.secured",
            "true" if proxy_port == 443 else "false",
        )

        # Layer 2: JVM-wide (-Dhttps.proxyHost etc.).  Set on BOTH
        # driver AND executor so iceberg REST + any other JVM HTTP
        # routes through the proxy too.
        jvm_opts = (
            f"-Dhttp.proxyHost={proxy_host} -Dhttp.proxyPort={proxy_port} "
            f"-Dhttps.proxyHost={proxy_host} -Dhttps.proxyPort={proxy_port}"
        )
        if proxy_user:
            # JVM proxy auth is fiddly -- requires java.net.Authenticator
            # (no env-var-based bypass).  We set the user/password
            # properties; ETL pods should bake an Authenticator in the
            # Spark image OR use unauthenticated proxy for JVM traffic.
            jvm_opts += (
                f" -Dhttp.proxyUser={proxy_user} -Dhttp.proxyPassword={proxy_pass} "
                f"-Dhttps.proxyUser={proxy_user} -Dhttps.proxyPassword={proxy_pass}"
            )

        # NO_PROXY bypass list -- JVM uses nonProxyHosts (pipe-separated).
        no_proxy = (
            os.environ.get("NO_PROXY")
            or os.environ.get("no_proxy")
            or ""
        ).strip()
        if no_proxy:
            # NO_PROXY is comma-separated (RFC); JVM expects pipe-separated.
            jvm_no_proxy = "|".join(
                h.strip() for h in no_proxy.split(",") if h.strip()
            )
            jvm_opts += f" -Dhttp.nonProxyHosts={jvm_no_proxy} -Dhttps.nonProxyHosts={jvm_no_proxy}"

        builder = (
            builder
            .config("spark.driver.extraJavaOptions", jvm_opts)
            .config("spark.executor.extraJavaOptions", jvm_opts)
        )
        return builder

    def _configure_iceberg_catalog(self, builder, config: Dict):
        """Configure Iceberg catalog (REST, Glue, or Hive)."""
        catalog_type = config.get('iceberg_catalog_type', 'rest')
        catalog_name = config.get('iceberg_catalog_name', 'iceberg_catalog')

        builder = (
            builder
            .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
            .config(f"spark.sql.catalog.{catalog_name}", "org.apache.iceberg.spark.SparkCatalog")
        )

        if catalog_type == 'rest':
            builder = (
                builder
                .config(f"spark.sql.catalog.{catalog_name}.type", "rest")
                .config(f"spark.sql.catalog.{catalog_name}.uri",
                         config.get('iceberg_catalog_uri', 'http://localhost:8181'))
            )
        elif catalog_type == 'glue':
            builder = (
                builder
                .config(f"spark.sql.catalog.{catalog_name}.catalog-impl",
                         "org.apache.iceberg.aws.glue.GlueCatalog")
            )
        elif catalog_type == 'hive':
            builder = (
                builder
                .config(f"spark.sql.catalog.{catalog_name}.type", "hive")
                .config(f"spark.sql.catalog.{catalog_name}.uri",
                         config.get('iceberg_catalog_uri', ''))
            )

        warehouse = config.get('iceberg_warehouse', '')
        if warehouse:
            builder = builder.config(f"spark.sql.catalog.{catalog_name}.warehouse", warehouse)

        return builder

    def _presigned_fallback(self, config: Dict, s3_paths: List[str]) -> List[str]:
        """Download S3 files via boto3 presigned URLs to local temp (on-prem fallback)."""
        import boto3

        s3_client = boto3.client(
            's3',
            endpoint_url=config.get('s3_endpoint_url', None),
            aws_access_key_id=config.get('s3_access_key', ''),
            aws_secret_access_key=config.get('s3_secret_key', ''),
        )

        local_paths = []
        temp_dir = tempfile.mkdtemp(prefix="s3_download_")

        for s3_path in s3_paths:
            # Parse s3://bucket/key
            path = s3_path.replace("s3://", "").replace("s3a://", "")
            bucket = path.split("/")[0]
            key = "/".join(path.split("/")[1:])

            local_file = os.path.join(temp_dir, os.path.basename(key))
            self.logger.info(f"Downloading {s3_path} → {local_file}")

            response = s3_client.get_object(Bucket=bucket, Key=key)
            with open(local_file, 'wb') as f:
                for chunk in response['Body'].iter_chunks(chunk_size=8 * 1024 * 1024):
                    f.write(chunk)

            local_paths.append(local_file)

        return local_paths

    def _parameterize_query(self, query: str, task: Dict) -> str:
        """Replace template variables in SQL query.

        2026-06-20 -- ALSO resolves the cross-engine ``{SOURCE}``
        placeholder to the Spark temp view name (default ``source``).
        That same placeholder is what the Starburst extract path
        resolves to ``<catalog>.<schema>.<table>``, so a single query
        with ``FROM {SOURCE}`` runs unchanged on both engines.
        """
        replacements = {
            "{BUSINESSDATE}": task.get('business_date', ''),
            "{SYSTEM_ENTITY}": task.get('system_entity', ''),
            "{EventCode}": task.get('eventcode', ''),
        }
        for placeholder, value in replacements.items():
            query = query.replace(placeholder, value)
        # Cross-engine {SOURCE} -- maps to Spark temp view.  Lazy import
        # keeps S3BaseStep free of a hard dep on the new adapter module
        # (so older ETL deployments without engine_sql_adapter.py still
        # parameterize the legacy placeholders cleanly).
        try:
            from engine_sql_adapter import (
                has_source_placeholder as _has_src,
                render_for_spark_s3 as _render_spk,
                validate_cross_engine_safe as _xeng_lint,
            )
            if _has_src(query):
                # SOURCE_VIEW_NAME is owned by S3QueryBase; subclass
                # overrides for multi-source steps.  Falls back to
                # the conventional "source" temp-view name.
                _view = getattr(self, "SOURCE_VIEW_NAME", None) or "source"
                query = _render_spk(query, source_view=_view, logger=self.logger)
                _xeng_lint(query, logger=self.logger)
        except ImportError:
            pass
        return query

    # ── Shared Oracle JDBC read/write (used by Oracle↔S3 steps) ──────────

    def _read_from_oracle(
        self, spark: SparkSession, config: Dict, query: str, num_partitions: int = 10
    ) -> tuple:
        """Read data from Oracle via JDBC. Returns (df, total_rows, read_time_seconds)."""
        oracle_url = config['oracle_url']
        oracle_user = config['oracle_user']
        oracle_password = config['oracle_password']
        fetchsize = config.get('fetchsize', '50000')

        # COUNT(*) pushdown
        count_query = f"SELECT COUNT(*) AS CNT FROM ({query}) t"
        self.logger.info("Fetching record count from Oracle via COUNT(*) pushdown...")
        cnt_df = (
            spark.read.format("jdbc")
            .option("url", oracle_url)
            .option("dbtable", f"({count_query}) as c")
            .option("user", oracle_user)
            .option("password", oracle_password)
            .option("driver", "oracle.jdbc.OracleDriver")
            .load()
        )
        total_rows = int(cnt_df.collect()[0]["CNT"])
        self.logger.info(f"Record count from Oracle = {total_rows}")

        # Read all data
        self.logger.info("Reading data from Oracle...")
        read_start = datetime.now()
        df = (
            spark.read.format("jdbc")
            .option("url", oracle_url)
            .option("dbtable", f"({query}) as subq")
            .option("user", oracle_user)
            .option("password", oracle_password)
            .option("driver", "oracle.jdbc.OracleDriver")
            .option("fetchsize", str(fetchsize))
            .option("numPartitions", str(num_partitions))
            .load()
        )
        read_time = (datetime.now() - read_start).total_seconds()
        self.logger.info(f"Read {total_rows} rows in {read_time:.2f}s")

        return df, total_rows, read_time

    def _write_to_oracle(
        self, df, config: Dict, table: str,
        batch_size: int = 50000, num_partitions: int = 10
    ) -> float:
        """Write DataFrame to Oracle via JDBC. Returns write_time_seconds."""
        oracle_url = config['oracle_url']
        oracle_user = config['oracle_user']
        oracle_password = config['oracle_password']

        self.logger.info(f"Repartitioning to {num_partitions} and writing to {table}")
        df = df.repartition(num_partitions)

        write_start = datetime.now()
        (
            df.write.format("jdbc")
            .option("url", oracle_url)
            .option("dbtable", table)
            .option("user", oracle_user)
            .option("password", oracle_password)
            .option("driver", "oracle.jdbc.OracleDriver")
            .option("batchsize", str(batch_size))
            .option("isolationLevel", "NONE")
            .option("numPartitions", str(num_partitions))
            .mode("append")
            .save()
        )
        write_time = (datetime.now() - write_start).total_seconds()
        self.logger.info(f"Write to {table} completed in {write_time:.2f}s")
        return write_time

    def _list_s3_files(self, config: Dict, bucket: str, prefix: str) -> List[str]:
        """List S3 parquet files in the given prefix via boto3 paginator."""
        import boto3

        s3_client = boto3.client(
            's3',
            endpoint_url=config.get('s3_endpoint_url', None),
            aws_access_key_id=config.get('s3_access_key', ''),
            aws_secret_access_key=config.get('s3_secret_key', ''),
        )

        files = []
        paginator = s3_client.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get('Contents', []):
                if obj['Key'].endswith('.parquet'):
                    files.append(f"s3://{bucket}/{obj['Key']}")

        self.logger.info(f"Found {len(files)} parquet files in s3://{bucket}/{prefix}")
        return files

    def _get_dest_table(self, task: Dict, config: Dict) -> str:
        """Get destination Oracle table — consistent across all steps."""
        return task.get("dest_table") or config.get("dest_table", "")
