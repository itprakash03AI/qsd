"""
Oracle → S3 Iceberg step.
Reads from Oracle via JDBC and writes to an Iceberg table on S3.
Creates the Iceberg table if it doesn't exist.
"""
from datetime import datetime
from typing import Dict, Any
from steps.s3.s3_base_step import S3BaseStep


class OracleToS3Iceberg(S3BaseStep):
    """Read from Oracle via JDBC and write to Iceberg table on S3."""

    LOG_PREFIX = "oracle_to_s3_iceberg"

    REQUIRED_FIELDS = [
        'oracle_url', 'oracle_user', 'oracle_password',
        's3_access_key', 's3_secret_key',
        'source_query', 'iceberg_table',
    ]

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        config = self._load_and_validate_config(task, self.REQUIRED_FIELDS)
        self._setup_logging(task)

        source_query = self._parameterize_query(config['source_query'], task)
        iceberg_table = config['iceberg_table']
        catalog_name = config.get('iceberg_catalog_name', 'iceberg_catalog')
        partition_cols = config.get('s3_partition_columns', [])
        num_partitions = config.get('num_partitions', 10)
        write_mode = config.get('write_mode', 'append')

        full_table = f"{catalog_name}.{iceberg_table}"

        spark = None
        try:
            spark = self._build_spark_session_s3(task, config, with_iceberg=True)

            # Read from Oracle via shared base method
            df, total_rows, read_time = self._read_from_oracle(spark, config, source_query, num_partitions)
            task['totalcount'] = total_rows

            # Write to Iceberg table
            self.logger.info(f"Writing to Iceberg table: {full_table}")
            write_start = datetime.now()

            writer = df.writeTo(full_table)
            if partition_cols:
                from pyspark.sql.functions import col
                writer = writer.partitionedBy(*[col(c) for c in partition_cols])

            if write_mode == 'overwrite':
                writer.createOrReplace()
            else:
                writer.append()

            write_time = (datetime.now() - write_start).total_seconds()
            self.logger.info(f"Write completed in {write_time:.2f}s")
            self.logger.info(f"TOTAL TIME: {read_time + write_time:.2f}s")

            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"), task.get("run_detail_id"),
                'UPDATE_TASK_RECORDCOUNT', step_name,
                total_rows, "", worker_connection_string
            )
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise
        finally:
            if spark:
                try:
                    pass  # 2026-06-26 -- spark.stop() removed; lifted to standalone main() finally (pod-shared SparkContext)
                except Exception as stop_err:
                    self.logger.warning(f"Error stopping Spark: {stop_err}")
