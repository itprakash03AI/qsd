"""
Shared base class for Starburst/Trino → Oracle Spark JDBC steps.
Subclasses override QUERY_KEY, TRINO_URL_KEY, and default memory settings.
"""
import os
import json
import logging
import sys
from datetime import datetime
from typing import Dict, Any, List

from pyspark.sql import SparkSession, DataFrame
from steps.BaseStep import BaseStep


class StarburstBase(BaseStep):
    """Base class for Starburst→Oracle steps with shared config, Spark, and JDBC logic."""

    # --- Subclass overrides ---
    QUERY_KEY: str = "query_on_cloud"           # config key for SQL query
    TRINO_URL_KEY: str = "trino_oncloud_url"    # config key for Trino JDBC URL
    DEFAULT_EXECUTOR_MEMORY: str = "10g"
    DEFAULT_DRIVER_MEMORY: str = "3g"
    LOG_PREFIX: str = "sb_to_oracle"

    # --- Required config fields (shared across OnPrem/OnCloud) ---
    COMMON_REQUIRED_FIELDS: List[str] = [
        'trino_user', 'trino_password',
        'oracle_url', 'oracle_user', 'oracle_password',
        'spark_jars',
    ]

    def _get_required_fields(self) -> List[str]:
        """Return full list of required config fields including subclass-specific keys."""
        return [self.QUERY_KEY, self.TRINO_URL_KEY] + self.COMMON_REQUIRED_FIELDS

    def _load_and_validate_config(self, task: Dict) -> Dict:
        """Load JSON config from task['sql_query_path'] and validate required fields.

        2026-06-12 — credentials and TRINO_URL fall back to the shared
        ``configs/starburst_config.yaml`` when the per-job JSON omits
        them.  Mirrors the same behaviour the non-Spark
        ``LightStarburstBase`` already implements, so the Spark and
        non-Spark Oracle paths read credentials from the SAME source.
        """
        config_path = task.get('sql_query_path')
        if not config_path:
            raise ValueError("Task missing 'sql_query_path'")

        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"Config file not found: {config_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in config {config_path}: {e}")

        # ── Shared Starburst credentials -- YAML WINS (2026-06-22) ──
        # 2026-06-26 -- catch narrowed to ImportError ONLY (original
        # intent per the comment: "Loader unavailable").  Vault
        # RuntimeError / ValueError from the loud-fail wiring must
        # propagate so the operator sees the actionable diagnostic.
        try:
            from starburst_config_loader import merge_shared_into_job_config as _merge_sb
        except ImportError as _exc:
            if getattr(self, "logger", None):
                self.logger.warning(
                    f"starburst_config_loader unavailable ({_exc}); "
                    f"using per-job JSON Starburst values only."
                )
        else:
            _merge_sb(
                config,
                trino_url_key=self.TRINO_URL_KEY,
                logger=getattr(self, "logger", None),
            )

        # ── Shared destination Oracle credentials fallback ──────────
        try:
            from oracle_config_loader import merge_shared_into_job_config as _merge_ora
        except ImportError:
            pass
        else:
            _merge_ora(config)

        # Treat empty strings as missing so a blank ``trino_user`` in
        # the per-job JSON falls through to the shared resolver above.
        required = self._get_required_fields()
        missing = [f for f in required if not config.get(f)]
        if missing:
            raise ValueError(
                f"Missing required config fields: {missing}. "
                f"Set them in the per-job JSON ({config_path}) OR in the "
                f"shared configs/starburst_config.yaml + STARBURST_* env vars."
            )

        return config

    def _parameterize_query(self, query: str, task: Dict) -> str:
        """Replace template variables in SQL query."""
        replacements = {
            "{BUSINESSDATE}": task.get('business_date', ''),
            "{SYSTEM_ENTITY}": task.get('system_entity', ''),
            "{EventCode}": task.get('eventcode', ''),
        }
        for placeholder, value in replacements.items():
            query = query.replace(placeholder, value)
        return query

    def _setup_logging(self, task: Dict) -> None:
        """Configure a named logger for this step.

        Uses shared pipeline log file from ``task['log_file']`` so all
        steps write to a single file.

        2026-07-02 -- delegated to ``log_config.attach_step_logger``:
        single chokepoint enforces "1 log per run per workflow", and
        the run-shared fallback (via ``get_run_log_file()``) prevents
        the LOG_PREFIX per-step fanout that fired when task['log_file']
        was ever missing.
        """
        from log_config import attach_step_logger
        self.logger = attach_step_logger(
            f"etl.{self.LOG_PREFIX}", task, workflow="oracle_standalone",
        )

    def _build_spark_session(self, task: Dict, config: Dict) -> SparkSession:
        """Build SparkSession with configurable memory and common settings."""
        run_id = task.get('run_id', 'unknown')
        run_detail_id = task.get('run_detail_id', 'unknown')
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')

        executor_memory = config.get('spark_executor_memory', self.DEFAULT_EXECUTOR_MEMORY)
        driver_memory = config.get('spark_driver_memory', self.DEFAULT_DRIVER_MEMORY)
        executor_overhead = config.get('spark_executor_memory_overhead', '1g')
        driver_overhead = config.get('spark_driver_memory_overhead', '1g')
        num_partitions = config.get('num_partitions', 10)
        spark_jars = config['spark_jars']

        try:
            from log_config import get_log_dir as _resolve_log_dir
            _evt_root = _resolve_log_dir()
        except Exception:
            _evt_root = "/usr/local/spark/nfs/bcp/batch/logs"
        event_log_dir = os.path.join(
            _evt_root, "event-logs",
            f"{run_id}_{run_detail_id}_{timestamp}",
        )
        os.makedirs(event_log_dir, exist_ok=True)

        spark = (
            SparkSession.builder
            .appName(f"{self.LOG_PREFIX}_{run_id}-{run_detail_id}")
            .config("spark.executor.cores", "1")
            .config("spark.kubernetes.executor.request.cores", "300m")
            .config("spark.kubernetes.executor.limit.cores", "1")
            .config("spark.executor.memory", executor_memory)
            .config("spark.driver.memory", driver_memory)
            .config("spark.executor.memoryOverhead", executor_overhead)
            .config("spark.driver.memoryOverhead", driver_overhead)
            .config("spark.executor.instances", "1")
            .config("spark.sql.shuffle.partitions", str(num_partitions))
            .config("spark.jars", spark_jars)
            .config("spark.sql.execution.arrow.pyspark.enabled", "true")
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.dynamicAllocation.enabled", "false")
            .config("spark.eventLog.enabled", "true")
            .config("spark.eventLog.dir", event_log_dir)
            .getOrCreate()
        )
        return spark

    # ── Trino types we accept as SAFE partition-column candidates.
    #
    # 2026-07-02 audit hardening -- EXACT type match (not prefix),
    # because ``interval day to second`` startswith ``int``.
    #
    # 2026-07-02 coverage widening -- operators reported they can't
    # touch per-job JSON, so auto-parallelize is the ONLY line of
    # defense.  Included the two most-common fact-table types
    # that safely partition:
    #   * Numeric core: TINYINT / SMALLINT / INTEGER / BIGINT.
    #     Spark JDBC's stride math is Long-based; these fit cleanly.
    #   * DECIMAL(N, 0) -- integer-like decimals used for large IDs.
    #     Detected via the ``decimal(...,0)`` pattern in
    #     ``simpleString()`` (see ``_decimal_scale_zero`` below).
    #   * Date core: DATE.
    #   * TIMESTAMP (without time zone).  Spark 3.x accepts
    #     ``YYYY-MM-DD HH:MM:SS`` ISO on both bounds via the driver's
    #     PreparedStatement.setTimestamp path -- reliable.  Excluded:
    #     ``timestamp with time zone`` (tz-suffix parsing is driver-
    #     version-dependent and silently skews partitions).
    # Types NOT accepted (fractional stride math + VARCHAR / MAP / ARRAY
    # etc.): REAL, DOUBLE, DECIMAL(N, s>0), VARCHAR, VARBINARY, ARRAY,
    # MAP, ROW, JSON, timestamp with time zone.
    _AP_NUMERIC_TYPES = frozenset({
        "tinyint", "smallint", "integer", "int", "bigint",
    })
    _AP_DATE_TYPES = frozenset({
        "date", "timestamp",
    })
    # DECIMAL columns are matched by _decimal_scale_zero(dt) not by
    # simple exact match, because simpleString() renders scale/prec.
    _AP_TZ_SUFFIX_MARKERS = ("with time zone", " tz")

    @staticmethod
    def _decimal_scale_zero(dt: str) -> bool:
        """True for ``decimal(N,0)`` shapes only.  Rejects fractional
        decimals (scale > 0) where Spark JDBC stride math breaks."""
        if not dt.startswith("decimal("):
            return False
        # simpleString() format: ``decimal(38,10)`` or ``decimal(38,0)``.
        # Parse the scale (second number after the comma).
        try:
            body = dt[len("decimal("):-1]  # e.g. "38,10"
            _, scale = body.split(",", 1)
            return int(scale.strip()) == 0
        except (ValueError, IndexError):
            return False

    # Kept as tuples for back-compat with any external test that
    # imported them; treat exact-set as source of truth.
    _AP_NUMERIC_PREFIXES = tuple(_AP_NUMERIC_TYPES)
    _AP_DATE_PREFIXES = tuple(_AP_DATE_TYPES)

    def _auto_detect_partition_bounds(
        self,
        spark: SparkSession,
        trino_url: str,
        trino_user: str,
        trino_password: str,
        query: str,
        config: Dict,
    ):
        """Probe Trino for a partition column + MIN/MAX bounds.

        Returns ``(column_name, lower_bound, upper_bound)`` on
        success; ``(None, None, None)`` when no suitable column
        exists.  Never raises -- caller falls back to SERIAL on any
        failure so a broken probe doesn't break the whole read.

        Selection order:
          1. Operator hint list ``auto_parallel_prefer_columns``
             (JSON list of column names) -- tried first, in order.
          2. Schema order: first NUMERIC column, then first DATE /
             TIMESTAMP column.
        """
        # Operator hints -- per-job JSON first, then env-var override.
        # Env var lets ops teams add hints without touching per-job
        # JSON files (which may be governance-locked or auto-
        # generated).  Env var wins over JSON when both are set --
        # matches the "operators need an out-of-band knob" pattern
        # elsewhere in the codebase.
        prefer = config.get("auto_parallel_prefer_columns") or []
        if isinstance(prefer, str):
            prefer = [c.strip() for c in prefer.split(",") if c.strip()]
        env_prefer = (os.environ.get("QS_AUTO_PARALLEL_PREFER_COLUMNS") or "").strip()
        if env_prefer:
            env_cols = [c.strip() for c in env_prefer.split(",") if c.strip()]
            self.logger.info(
                "auto_parallel: env var QS_AUTO_PARALLEL_PREFER_COLUMNS "
                "= %r overrides per-job JSON hints", env_cols,
            )
            prefer = env_cols

        # ── Schema probe: 0-row read to enumerate columns + types.
        # LIMIT 0 is a cheap Trino idiom -- pushes down as a
        # metadata-only fetch.
        #
        # 2026-07-02 audit hardening -- probe failures now WARN
        # (was DEBUG).  Operators need to see auth / network / SQL
        # errors here so they can distinguish "no suitable column"
        # from "couldn't reach Trino at all."
        # 2026-07-02 audit M2 -- per-probe queryTimeout so a slow
        # Trino planner doesn't extend the pre-read stack (three
        # round-trips: COUNT, LIMIT 0 schema, MIN/MAX).  Default 60s
        # per probe.  Operator override via
        # ``auto_parallel_probe_timeout_seconds``.
        _probe_timeout_s = 60
        try:
            _probe_timeout_s = int(
                config.get("auto_parallel_probe_timeout_seconds", 60) or 60
            )
            if _probe_timeout_s <= 0:
                _probe_timeout_s = 60
        except (TypeError, ValueError):
            pass

        schema_query = f"SELECT * FROM ({query.rstrip().rstrip(';')}) t LIMIT 0"
        try:
            schema_df = (
                spark.read.format("jdbc")
                .option("url", trino_url)
                .option("dbtable", f"({schema_query}) as ap_schema")
                .option("user", trino_user)
                .option("password", trino_password)
                .option("driver", "io.trino.jdbc.TrinoDriver")
                .option("queryTimeout", str(_probe_timeout_s))
                .load()
            )
        except Exception as exc:
            self.logger.warning(
                "auto_parallel: schema probe FAILED (%s: %s) -- "
                "falling back to SERIAL.  This is usually a Trino "
                "auth / network / SQL error, NOT a data-shape issue.  "
                "Original inner query start: %s",
                type(exc).__name__, exc, query[:200],
            )
            return None, None, None

        # Spark DataFrame schema -> list of (name, dataType.simpleString()).
        # dataType.simpleString() returns e.g. "int", "bigint",
        # "date", "timestamp", "string", "decimal(10,2)".
        try:
            field_list = [
                (f.name, str(f.dataType.simpleString()).lower())
                for f in schema_df.schema.fields
            ]
        except Exception as exc:
            self.logger.warning(
                "auto_parallel: schema.fields introspection FAILED "
                "(%s: %s) -- falling back to SERIAL.  Spark returned "
                "an unexpected DataFrame shape.",
                type(exc).__name__, exc,
            )
            return None, None, None

        def _is_numeric(dt: str) -> bool:
            # 2026-07-02 -- EXACT match, not startswith.  Fixes the
            # bug where "interval day to second" started with "int"
            # and slipped through.
            if dt in self._AP_NUMERIC_TYPES:
                return True
            # DECIMAL(N,0) also safe -- integer-like decimal used for
            # large IDs.  DECIMAL(N,s>0) rejected (fractional stride).
            return self._decimal_scale_zero(dt)

        def _is_date(dt: str) -> bool:
            # Reject timestamps with tz suffix -- Spark JDBC's tz-
            # parser is driver-version-dependent and skews partitions.
            if any(marker in dt for marker in self._AP_TZ_SUFFIX_MARKERS):
                return False
            return dt in self._AP_DATE_TYPES

        # Rank candidates: operator-preferred first, then numeric,
        # then date.  Duplicates deduped.  Case-insensitive lookup
        # on operator hints so ``"BusinessDate"`` matches Trino's
        # lowercased ``businessdate`` column.
        seen = set()
        ordered: list = []
        name_to_type = {n: t for n, t in field_list}
        name_ci = {n.lower(): n for n in name_to_type}
        for pref in prefer:
            actual = name_ci.get(str(pref).lower())
            if actual and actual not in seen:
                ordered.append(actual)
                seen.add(actual)
        for n, t in field_list:
            if _is_numeric(t) and n not in seen:
                ordered.append(n)
                seen.add(n)
        for n, t in field_list:
            if _is_date(t) and n not in seen:
                ordered.append(n)
                seen.add(n)

        if not ordered:
            # Give operators the type breakdown so they can extend
            # ``auto_parallel_prefer_columns`` if they know a column
            # is safe.
            self.logger.warning(
                "auto_parallel: no safe INTEGER / BIGINT / DATE "
                "column found in query schema (%d columns total: %s) "
                "-- SERIAL read.  To force parallelism, set "
                "partition_column / lower_bound / upper_bound in "
                "per-job JSON.",
                len(field_list),
                [f"{n}:{t}" for n, t in field_list[:20]],
            )
            return None, None, None

        # ── Try each candidate; first one with a valid (lo, hi)
        # spread wins.  Bounds probe = single tiny Trino query.
        # 2026-07-02 audit hardening -- ACCUMULATE per-candidate
        # reasons so the final fallback WARN names WHICH candidates
        # were tried and WHY each failed.
        tried_reasons: list = []
        for candidate in ordered:
            lo, hi = self._probe_min_max(
                spark, trino_url, trino_user, trino_password,
                query, candidate,
                probe_timeout_s=_probe_timeout_s,
            )
            if lo is None or hi is None:
                reason = f"{candidate}: MIN/MAX returned NULL"
                tried_reasons.append(reason)
                self.logger.info("auto_parallel: %s -- skipping", reason)
                continue
            if str(lo) == str(hi):
                reason = f"{candidate}: MIN==MAX={lo!r} (no spread)"
                tried_reasons.append(reason)
                self.logger.info("auto_parallel: %s -- skipping", reason)
                continue
            return candidate, lo, hi

        # Exhausted all candidates -- give operators the full picture.
        self.logger.warning(
            "auto_parallel: exhausted %d candidate(s) without finding "
            "a viable spread -- SERIAL read.  Tried: %s.  Set "
            "partition_column / lower_bound / upper_bound in per-job "
            "JSON to override.",
            len(ordered), tried_reasons,
        )
        return None, None, None

    def _probe_min_max(
        self,
        spark: SparkSession,
        trino_url: str,
        trino_user: str,
        trino_password: str,
        query: str,
        column: str,
        *,
        probe_timeout_s: int = 60,
    ):
        """Single-round-trip MIN/MAX probe on Trino.  Returns
        ``(lo, hi)`` or ``(None, None)`` on any failure."""
        # Quote the column so identifiers with unusual case survive
        # Trino's identifier rules.  Trino uses ``"col"`` for quoted
        # identifiers.
        col_q = '"{}"'.format(column.replace('"', '""'))
        # 2026-07-02 audit -- rtrim + strip trailing semicolons on the
        # inner query so ``SELECT ... FROM t;`` doesn't break the
        # wrap.
        clean_query = query.rstrip().rstrip(";")
        mm_query = (
            f"SELECT MIN({col_q}) AS ap_lo, MAX({col_q}) AS ap_hi "
            f"FROM ({clean_query}) t"
        )
        try:
            mm_df = (
                spark.read.format("jdbc")
                .option("url", trino_url)
                .option("dbtable", f"({mm_query}) as ap_mm")
                .option("user", trino_user)
                .option("password", trino_password)
                .option("driver", "io.trino.jdbc.TrinoDriver")
                .option("queryTimeout", str(probe_timeout_s))
                .load()
            )
            rows = mm_df.collect()
        except Exception as exc:
            self.logger.info(
                "_probe_min_max: candidate=%s raised %s: %s -- "
                "skipping",
                column, type(exc).__name__, exc,
            )
            return None, None
        if not rows:
            return None, None
        try:
            d = rows[0].asDict()
            lo = d.get("ap_lo") if "ap_lo" in d else d.get("AP_LO")
            hi = d.get("ap_hi") if "ap_hi" in d else d.get("AP_HI")
        except Exception:
            return None, None
        return lo, hi

    def _read_from_trino(
        self, spark: SparkSession, config: Dict, query: str, num_partitions: int = 10
    ) -> tuple:
        """Read data from Trino via JDBC. Returns (df, total_rows, read_time_seconds).

        2026-06-22 -- VISIBILITY OVERHAUL:
          * Log the FULL parameterised SQL before sending to Trino.
          * Warn loud on degenerate parameter substitution (e.g.,
            blank business_date -> ``CAST('' AS DATE)`` returns 0 rows
            silently, or in some Trino versions scans the whole table).
          * Time both COUNT(*) and the actual read.
          * Background heartbeat every 30s so the operator knows we're
            alive (or stuck).
          * Optional parallel read via ``partition_column`` +
            ``lower_bound`` / ``upper_bound`` from per-job JSON --
            without these, JDBC reads in a SINGLE task (slow for >5M rows).
        """
        import threading
        trino_url = config[self.TRINO_URL_KEY]
        trino_user = config['trino_user']
        trino_password = config['trino_password']
        fetchsize = config.get('fetchsize', '70000')

        self.logger.info(
            "Trino JDBC target: url=%s user=%s",
            trino_url, trino_user,
        )

        # ── Degenerate-query guard: if a polling-row substitution left
        #    a quoted empty value in the WHERE clause (e.g., ='' or
        #    =CAST('' AS DATE)), warn LOUD -- this is the #1 cause of
        #    "stuck forever / 0 rows" reports.
        for marker, label in (
            ("=CAST('' AS",  "empty business_date / date column"),
            ("=''",           "empty SYSTEM_ENTITY / EventCode / other param"),
            ("= ''",          "empty SYSTEM_ENTITY / EventCode / other param"),
        ):
            if marker in query:
                self.logger.warning(
                    "Trino query has %s -- the polling row may be "
                    "missing a required value.  Query will likely return "
                    "0 rows.  Marker: %r", label, marker,
                )

        # ── Log the FULL parameterised SQL.  Truncate ONLY if absurd.
        sql_to_log = query if len(query) < 4000 else query[:4000] + f"... (+{len(query) - 4000} chars)"
        self.logger.info("Trino query (parameterised):\n%s", sql_to_log)

        # 2026-06-22 -- TCP pre-flight is OPT-IN.  Operator hit production
        # outage when a strict preflight blocked otherwise-working
        # connects.  Default behaviour: skip the probe entirely -- the
        # JDBC driver does its own connect with its own timeout.  Enable
        # for debugging via env var TRINO_JDBC_ENABLE_PREFLIGHT=1.
        if os.environ.get("TRINO_JDBC_ENABLE_PREFLIGHT", "").lower() in ("1", "true", "yes"):
            try:
                from managers.trino_jdbc_preflight import tcp_preflight
                tcp_preflight(trino_url, timeout=5.0, logger=self.logger)
            except ImportError:
                pass

        # ── COUNT(*) pushdown with timing.
        #
        # 2026-07-03 -- NEVER WRAP the operator's query in
        # ``SELECT COUNT(*) FROM (query) t``.  Trino cannot prove the
        # wrapper's semantics without evaluating the subquery -- it
        # materialises every projected column of every row before
        # counting.  On large tables workers OOM/die; coordinator
        # reports "too many errors talking to a worker node" and the
        # entire extract fails BEFORE any real data is read.  Use the
        # AST helper from the file workflow's starburst_file_base
        # module -- it emits ``SELECT COUNT(*) FROM src WHERE ...``
        # for plain SELECT, sum-of-branches for UNION ALL, and
        # ("", "skip") for shapes it can't safely rewrite.
        #
        # On skip: DON'T do the pre-flight count.  We lose the
        # 0-row short-circuit optimisation, but running the extract
        # on an empty result is a couple of wasted JDBC round-trips
        # -- vs the wrap which OOMs the cluster.  Cheap loss.
        try:
            from steps.file.starburst_file_base import _derive_count_sql
            count_query, count_mode = _derive_count_sql(
                query, dialect="trino", logger=self.logger,
            )
        except Exception as _derive_exc:
            self.logger.warning(
                "AST derive_count import/call failed (%s) -- skipping "
                "pre-flight COUNT (never wrap).",
                _derive_exc,
            )
            count_query, count_mode = "", "skip"

        if count_mode == "skip" or not count_query:
            self.logger.info(
                "Phase 1/2: pre-flight COUNT SKIPPED (base_sql shape "
                "prevents cheap AST rewrite; wrap would OOM Trino "
                "workers).  Proceeding directly to read+write; "
                "0-row short-circuit disabled for this run.",
            )
            total_rows = -1
        else:
            self.logger.info(
                "Phase 1/2: COUNT(*) on Trino (mode=%s)...", count_mode,
            )
            count_start = datetime.now()
            cnt_df = (
                spark.read.format("jdbc")
                .option("url", trino_url)
                .option("dbtable", f"({count_query}) as c")
                .option("user", trino_user)
                .option("password", trino_password)
                .option("driver", "io.trino.jdbc.TrinoDriver")
                .load()
            )

            # 2026-06-26 -- defensive extraction (matches light variant).
            #   1. ``collect()`` returns ``[]`` -- treat as 0
            #   2. Column case mismatch -- try both CNT and cnt
            #   3. NULL in CNT column -- guard
            collected = cnt_df.collect()
            if not collected:
                self.logger.warning(
                    "Trino COUNT(*) returned no result row -- treating "
                    "as 0 (likely silent inner-query failure).  Inner "
                    "count query: %s", count_query[:500],
                )
                total_rows = 0
            else:
                row_dict = collected[0].asDict()
                # AST-mode emits ``SELECT COUNT(*) AS _col_0 FROM ...``
                # by default OR whatever sqlglot picks -- fetch the
                # single scalar column regardless of alias.
                if not row_dict:
                    total_rows = 0
                else:
                    _first_val = next(iter(row_dict.values()))
                    total_rows = int(_first_val) if _first_val is not None else 0

            count_time = (datetime.now() - count_start).total_seconds()
            self.logger.info(
                "Phase 1/2: COUNT(*) returned %s row(s) in %.1fs%s",
                f"{total_rows:,}", count_time,
                "  -- 0 rows: verify polling-row business_date/system_entity/eventcode"
                if total_rows == 0 else "",
            )

        # ── 0-row short-circuit (only when we got a real count).
        # total_rows == -1 signals "count skipped" -- must NOT
        # short-circuit; proceed with the extract.
        if total_rows == 0:
            self.logger.info(
                "Trino COUNT(*) = 0 -- skipping read + write phases. "
                "Step succeeds as a no-op."
            )
            return None, 0, 0.0

        # ── Read with optional parallel partitioning.
        #    Per-job JSON can specify:
        #      "partition_column": "BUSINESS_CLOSE_DATE"     (numeric / date col)
        #      "lower_bound":      "2025-09-01"
        #      "upper_bound":      "2025-10-01"
        #    Without these, JDBC uses a single task (serial).
        partition_column = config.get("partition_column") or ""
        lower_bound = str(config.get("lower_bound") or "")
        upper_bound = str(config.get("upper_bound") or "")
        parallel = bool(partition_column and lower_bound and upper_bound)

        # 2026-07-02 prod incident fix -- AUTO-PARALLELIZE.
        #
        # Before: >5M rows without partition config -> SERIAL read ->
        # 30 min write -> pod eviction / OOM mid-write -> whole
        # pipeline dies.  Symptomatic fix (heartbeat) landed as a
        # DIAGNOSTIC only; the REAL fix is to eliminate the 30-min
        # blocker entirely by auto-detecting a partition column +
        # bounds so the reader parallelises without operator input.
        #
        # Strategy:
        #   1. Only kick in when SERIAL would be slow (default: >5M
        #      rows).  Small reads stay SERIAL -- opening extra
        #      JDBC connections isn't worth it.
        #   2. Ask Trino for the column list of the query via a
        #      1-row PREPARE-style probe: ``SELECT * FROM (query) t
        #      LIMIT 0``.
        #   3. Pick the first NUMERIC or DATE column.  Prefer
        #      operator-hint via ``auto_parallel_prefer_columns``
        #      when set; else fall back to schema order.
        #   4. Ask Trino for MIN/MAX of that column in ONE fast
        #      round-trip.
        #   5. If the probe fails, MIN==MAX, or MIN/MAX are NULL,
        #      fall back to SERIAL (keeps the pre-fix behaviour --
        #      no regression on odd queries).
        #
        # Opt-out via ``auto_parallel_disable: true`` in per-job JSON
        # so operators with pathological data can skip.
        auto_disabled = bool(config.get("auto_parallel_disable"))
        # 2026-07-02 audit -- defensive parse.  Operator typos
        # (``"5000000 "`` with trailing text) must not kill the
        # read; fall back to the safe default.
        try:
            auto_threshold = int(config.get("auto_parallel_threshold_rows", 5_000_000))
            if auto_threshold <= 0:
                auto_threshold = 5_000_000
        except (TypeError, ValueError):
            self.logger.warning(
                "auto_parallel_threshold_rows=%r is not an int -- "
                "using default 5_000_000",
                config.get("auto_parallel_threshold_rows"),
            )
            auto_threshold = 5_000_000
        # 2026-07-02 audit C2 -- refuse auto-parallelize when the
        # base query contains LIMIT or ORDER BY.  Wrapping such a
        # query in a per-task ``WHERE partition_col BETWEEN...`` breaks
        # LIMIT semantics OR forces every one of the 10 tasks to
        # re-evaluate an ORDER BY + LIMIT scan against the source
        # (10x cost, not 10x speed).  Fall back to SERIAL cleanly.
        import re as _ap_re
        _query_upper_stripped = " ".join(query.split()).upper()
        _has_limit_or_order = (
            _ap_re.search(r"\bLIMIT\s+\d+", _query_upper_stripped) is not None
            or _ap_re.search(r"\bORDER\s+BY\b", _query_upper_stripped) is not None
        )
        if (
            not parallel
            and not auto_disabled
            and total_rows > auto_threshold
            and _has_limit_or_order
        ):
            self.logger.warning(
                "Auto-parallelize: base query contains LIMIT or "
                "ORDER BY -- refusing to auto-parallelize (would "
                "either break LIMIT semantics or force 10x planner "
                "cost).  Read stays SERIAL; add partition_column / "
                "lower_bound / upper_bound to per-job JSON with a "
                "rewritten query if you want parallel."
            )

        if (
            not parallel
            and not auto_disabled
            and total_rows > auto_threshold
            and not _has_limit_or_order
        ):
            self.logger.info(
                "Auto-parallelize: %s rows exceeds threshold %s and "
                "per-job JSON has no partition_column -- attempting "
                "auto-detection so the read runs in %d parallel tasks.",
                f"{total_rows:,}", f"{auto_threshold:,}", num_partitions,
            )
            try:
                ap_col, ap_lo, ap_hi = self._auto_detect_partition_bounds(
                    spark, trino_url, trino_user, trino_password,
                    query, config,
                )
            except Exception as _ap_exc:
                self.logger.warning(
                    "Auto-parallelize probe raised %s: %s -- falling "
                    "back to SERIAL read.  Add partition_column / "
                    "lower_bound / upper_bound to per-job JSON to "
                    "force parallelism.",
                    type(_ap_exc).__name__, _ap_exc,
                )
                ap_col = ap_lo = ap_hi = None
            if ap_col and ap_lo is not None and ap_hi is not None:
                partition_column = ap_col
                lower_bound = str(ap_lo)
                upper_bound = str(ap_hi)
                parallel = True
                self.logger.info(
                    "Auto-parallelize SUCCESS: partition_column=%r "
                    "lower_bound=%r upper_bound=%r -- reading in %d "
                    "parallel tasks.",
                    ap_col, ap_lo, ap_hi, num_partitions,
                )
            else:
                self.logger.warning(
                    "Auto-parallelize could not find a suitable "
                    "column -- falling back to SERIAL.  Add "
                    "partition_column / lower_bound / upper_bound to "
                    "per-job JSON to force parallelism."
                )

        if total_rows > auto_threshold and not parallel:
            self.logger.warning(
                "Trino COUNT = %s rows but no partition_column / "
                "lower_bound / upper_bound in per-job JSON -- read will "
                "use a SINGLE serial JDBC task.  Add those keys to "
                "query_fact_table.json to enable %dx parallel reads.",
                f"{total_rows:,}", num_partitions,
            )

        phase_label = (
            f"PARALLEL ({num_partitions} tasks on {partition_column})"
            if parallel else "SERIAL (single task)"
        )
        self.logger.info("Phase 2/2: READ from Trino [%s]...", phase_label)
        read_start = datetime.now()

        # ── Heartbeat thread: log every 30s so the operator knows we're alive.
        _stop = threading.Event()
        def _heartbeat():
            secs = 0
            while not _stop.is_set():
                if _stop.wait(30):
                    return
                secs += 30
                self.logger.info(
                    "Phase 2/2: still reading from Trino... elapsed=%ds "
                    "(SQL=%s rows expected)",
                    secs, f"{total_rows:,}",
                )
        hb = threading.Thread(target=_heartbeat, daemon=True)
        hb.start()

        try:
            reader = (
                spark.read.format("jdbc")
                .option("url", trino_url)
                .option("dbtable", f"({query}) as subq")
                .option("user", trino_user)
                .option("password", trino_password)
                .option("driver", "io.trino.jdbc.TrinoDriver")
                .option("fetchsize", str(fetchsize))
                .option("numPartitions", str(num_partitions))
            )
            if parallel:
                reader = (
                    reader
                    .option("partitionColumn", partition_column)
                    .option("lowerBound", lower_bound)
                    .option("upperBound", upper_bound)
                )
            df = reader.load()
        finally:
            _stop.set()

        read_time = (datetime.now() - read_start).total_seconds()
        self.logger.info(
            "Phase 2/2: READ DataFrame ready in %.1fs.  Note: actual "
            "row materialisation happens during the Oracle write.",
            read_time,
        )

        return df, total_rows, read_time

    def _write_to_oracle(
        self, df: DataFrame, config: Dict, table: str,
        batch_size: int = 50000, num_partitions: int = 10
    ) -> float:
        """Write DataFrame to Oracle via JDBC. Returns write_time_seconds.

        2026-07-02 prod incident -- write-side HEARTBEAT added.  Was
        symmetric-gap with read (line 346-360 fires every 30s).
        Without it, a long `.save()` produced 30 min of log silence
        before the failure line, making it impossible for operators
        to tell "Spark healthy + write in progress" vs "Py4J blocked".
        Now the operator sees an every-30s progress line so the moment
        Py4J STOPS responding is greppable.
        """
        oracle_url = config['oracle_url']
        oracle_user = config['oracle_user']
        oracle_password = config['oracle_password']

        self.logger.info(f"Repartitioning to {num_partitions} partitions before write...")
        df = df.repartition(num_partitions)

        self.logger.info(f"Writing to {table}")
        write_start = datetime.now()

        # ── Heartbeat thread mirroring the read-side pattern.
        # Every 30s while `.save()` blocks we log "still writing...
        # elapsed=Ns" so a 30-min silent write becomes 60 progress
        # lines.  A GAP in that stream (last heartbeat > 60s ago at
        # failure time) is a strong signal of driver-pod SIGTERM /
        # JVM shutdown vs slow-but-alive Oracle write.
        import threading as _wr_threading
        _wr_stop = _wr_threading.Event()

        def _write_heartbeat():
            secs = 0
            while not _wr_stop.is_set():
                if _wr_stop.wait(30):
                    return
                secs += 30
                self.logger.info(
                    "Phase 3/3: still writing to Oracle... elapsed=%ds "
                    "(table=%s, num_partitions=%d)",
                    secs, table, num_partitions,
                )

        _hb = _wr_threading.Thread(
            target=_write_heartbeat, daemon=True,
            name=f"oracle-write-hb-{self.LOG_PREFIX}",
        )
        _hb.start()
        try:
            (
                df.write.format("jdbc")
                .option("url", oracle_url)
                .option("dbtable", table)
                .option("user", oracle_user)
                .option("password", oracle_password)
                .option("driver", "oracle.jdbc.OracleDriver")
                .option("batchsize", str(batch_size))
                .option("isolationLevel", "NONE")
                .option("numPartitions", str(num_partitions))
                .mode("append")
                .save()
            )
        finally:
            _wr_stop.set()

        write_time = (datetime.now() - write_start).total_seconds()
        self.logger.info(f"Write completed in {write_time:.2f}s")
        return write_time

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args,
        **kwargs,
    ) -> int:
        """Execute the Starburst→Oracle step: read from Trino, write to Oracle."""
        config = self._load_and_validate_config(task)
        self._setup_logging(task)

        # Parameterize query
        raw_query = config[self.QUERY_KEY]
        trino_query = self._parameterize_query(raw_query, task)

        # 2026-06-12 — feed the parameterised SQL to the run report
        # when one is attached to the task dict.  Same plumbing as the
        # light variant; FileRunReport writes queries/<job_id>.sql + a
        # download link in the HTML.  No-op when no report is wired.
        run_report = task.get("_run_report")
        if run_report is not None:
            try:
                job_id = (
                    task.get("fk_dag_id")
                    or task.get("dag_id")
                    or task.get("run_id")
                    or self.LOG_PREFIX
                )
                run_report.add_sql_summary(str(job_id), trino_query)
            except Exception as exc:
                self.logger.warning(
                    f"Could not feed SQL to run_report: {exc}"
                )

        batch_size = config.get('batch_size', 50000)
        num_partitions = config.get('num_partitions', 10)
        oracle_table = task["dest_table"]

        # Build Spark session
        spark = None
        try:
            spark = self._build_spark_session(task, config)
        except Exception as e:
            self.logger.error(f"Spark session failed: {e}", exc_info=True)
            raise RuntimeError(f"Spark init failed: {e}") from e

        # 2026-06-12 — Spark job group so an outer cancel (polling
        # service timeout / pod shutdown) can stop the in-flight
        # JDBC scan on Starburst.  ``interruptOnCancel=True`` lets
        # SparkContext.cancelJobGroup actually interrupt the executor
        # thread that's blocked on the JDBC fetch.
        from starburst_cancellation import (
            StarburstCancellable, KIND_SPARK_JOB_GROUP,
            register_starburst_cancellable, unregister_starburst_cancellable,
        )
        run_id = task.get("run_id", "x")
        run_detail_id = task.get("run_detail_id", "x")
        sb_group_id = f"{self.LOG_PREFIX}_{run_id}_{run_detail_id}"
        try:
            spark.sparkContext.setJobGroup(
                sb_group_id,
                f"Starburst -> Oracle ({self.LOG_PREFIX}) run_id={run_id}",
                interruptOnCancel=True,
            )
        except Exception as exc:
            self.logger.warning(f"setJobGroup failed (cancel will degrade): {exc}")
        sb_cancellable = StarburstCancellable(
            KIND_SPARK_JOB_GROUP, spark=spark, group_id=sb_group_id,
            label=f"{self.LOG_PREFIX}.spark",
        )
        register_starburst_cancellable(task, sb_cancellable)

        try:
            # Read from Trino.  When COUNT(*) returns 0 rows,
            # _read_from_trino short-circuits: returns (None, 0, 0.0)
            # so the caller can skip the Oracle write entirely.
            df, total_rows, read_time = self._read_from_trino(
                spark, config, trino_query, num_partitions
            )
            task['totalcount'] = total_rows

            # 2026-06-26 -- 0-row short-circuit.  Skip the Oracle JDBC
            # write entirely when there's nothing to write.  Still
            # update OTG_ETL_BATCH_STATUS with totalcount=0 below so
            # downstream steps (CheckDataCompleteness, run report)
            # see the 0 explicitly rather than missing-status.
            if total_rows == 0:
                self.logger.info(
                    "Skipping Oracle write -- 0 rows from source.  "
                    "Step succeeds with totalcount=0."
                )
                write_time = 0.0
            else:
                # Write to Oracle
                write_time = self._write_to_oracle(
                    df, config, oracle_table, batch_size, num_partitions
                )

            total_time = read_time + write_time
            self.logger.info(f"TOTAL TIME: {total_time:.2f}s (read={read_time:.2f}s, write={write_time:.2f}s)")

            # Update record count in Oracle metadata (with 0 when applicable
            # so downstream completeness checks see the 0 explicitly).
            await self.oracle_data_manager.update_otg_etl_batch_status(
                task.get("run_id"), task.get("run_detail_id"),
                'UPDATE_TASK_RECORDCOUNT', step_name,
                total_rows, "", worker_connection_string
            )
            return total_rows

        except Exception as e:
            self.logger.error(f"JOB FAILED: {e}", exc_info=True)
            raise
        finally:
            unregister_starburst_cancellable(task, sb_cancellable)
            if spark:
                try:
                    spark.sparkContext.clearJobGroup()
                except Exception:
                    pass
                # 2026-06-26 -- DO NOT call spark.stop() here.
                #
                # Standalone runs sequentially: oncloud step -> onprem
                # step (-> any other follow-ups in the same SEQ chain).
                # All steps share the same JVM/SparkContext via
                # SparkSession.builder.getOrCreate().  Calling
                # spark.stop() in the oncloud finally killed the
                # SparkContext, then onprem's getOrCreate() returned a
                # SparkSession with a DEAD SparkContext -- onprem's
                # collect() crashed with "Job 0 cancelled because
                # SparkContext was shut down".  The prd reference
                # (prd_starburst_to_oracle_oncloud.py) never called
                # spark.stop() -- session leaks until the pod exits,
                # which is fine because the pod is one-shot.
