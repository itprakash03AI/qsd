"""CheckDependencies — TEMPLATE step for the FileToOracle workflow.

Pre-wired with the file-flow conventions (single-file logging, run
report, artifact registry).  Operator fills in tenant-specific
dependency checks in ``_check_one``.

Default coverage:

  1. Polling-row fields (run_id / run_detail_id / fk_report_id /
     fk_dag_id / sql_query_path / business_date) are populated.
  2. ``sql_query_path`` JSON is on disk + well-formed + has at least
     one job.
  3. Each job has the per-job keys this workflow consumes
     (report_id / source_file_location / source_file_name / dest_table
     / oracle_url / oracle_user / oracle_password).

Loud-fails with a descriptive ValueError so the standalone catches
the exception and the FAILED finish-email goes out.
"""
from __future__ import annotations

import json
import logging
import os
import sys
from datetime import datetime
from typing import Any, Dict, List

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import get_or_create_artifacts


class CheckDependencies(BaseStep):
    """Verify upstream / config prerequisites before the load runs."""

    LOG_PREFIX = "file_to_oracle_check_dependencies"

    REQUIRED_TASK_FIELDS = (
        "run_id",
        "run_detail_id",
        "fk_report_id",
        "fk_dag_id",
        "sql_query_path",
        "business_date",
    )
    REQUIRED_JOB_KEYS = (
        "report_id",
        "datasource_name",
        "source_file_location",
        "source_file_name",
        "dest_table",
    )

    def _setup_logging(self, task: Dict) -> None:
        # 2026-07-02 -- single chokepoint (log_config.attach_step_logger).
        from log_config import attach_step_logger
        self.logger = attach_step_logger(
            f"file_flow.{self.LOG_PREFIX}", task, workflow="file_to_oracle",
        )

    def _check_query_config(self, task: Dict) -> Dict[str, Any]:
        path = task.get("sql_query_path")
        if not path:
            raise ValueError("sql_query_path is empty on the polling row")
        if not os.path.exists(path):
            raise ValueError(f"sql_query_path does not exist on disk: {path!r}")
        with open(path, "r", encoding="utf-8") as f:
            try:
                cfg = json.load(f)
            except json.JSONDecodeError as exc:
                raise ValueError(f"sql_query_path JSON is malformed at {path}: {exc}")
        if not isinstance(cfg, dict) or "jobs" not in cfg:
            raise ValueError(
                f"sql_query_path JSON must be an object with a 'jobs' array: {path}"
            )
        if not isinstance(cfg["jobs"], list) or not cfg["jobs"]:
            raise ValueError(f"sql_query_path JSON 'jobs' is empty or not a list: {path}")
        return cfg

    def _check_one(self, task: Dict, query_cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []
        for job in query_cfg.get("jobs", []):
            missing = [k for k in self.REQUIRED_JOB_KEYS if not job.get(k)]
            ok = not missing
            detail = "all keys present" if ok else f"missing keys: {missing}"
            # Optional: verify file exists on disk if the dependency
            # check runs after Starburst→file completes (loop-back load).
            src = os.path.join(
                job.get("source_file_location", ""),
                job.get("source_file_name", ""),
            )
            if ok and src and not os.path.exists(src):
                ok = False
                detail = f"source file does not exist on disk: {src!r}"
            results.append({
                "name": f"job_{job.get('report_id', '?')}",
                "ok": ok,
                "detail": detail,
            })
        return results

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> int:
        self._setup_logging(task)
        get_or_create_artifacts(task, logger=self.logger)
        rr = task.get("_run_report")
        run_report: FileRunReport = rr if isinstance(rr, FileRunReport) else None

        self.logger.info("=" * 72)
        self.logger.info(
            "FileToOracle CheckDependencies for run_id=%s report_id=%s",
            task.get("run_id"), task.get("fk_report_id"),
        )
        self.logger.info("=" * 72)

        missing = [f for f in self.REQUIRED_TASK_FIELDS if not task.get(f)]
        if missing:
            raise ValueError(
                f"CheckDependencies: polling row missing required fields {missing}"
            )

        query_cfg = self._check_query_config(task)
        self.logger.info(
            "Query config OK: %s (%d job(s))",
            task.get("sql_query_path"), len(query_cfg.get("jobs", [])),
        )

        per_job = self._check_one(task, query_cfg)
        failed = [r for r in per_job if not r["ok"]]
        for r in per_job:
            level = self.logger.info if r["ok"] else self.logger.error
            level("  %-40s  %s  %s", r["name"], "OK" if r["ok"] else "FAIL", r["detail"])

        if failed:
            raise ValueError(
                f"CheckDependencies: {len(failed)} of {len(per_job)} job checks FAILED — "
                f"{[r['name'] for r in failed]}"
            )

        if run_report is not None:
            run_report.runtime_knobs.update({
                "file_to_oracle_check_pass_count": len(per_job) - len(failed),
                "file_to_oracle_check_total_count": len(per_job),
                "sql_query_path": task.get("sql_query_path"),
            })

        task["totalcount"] = 0
        return 0
