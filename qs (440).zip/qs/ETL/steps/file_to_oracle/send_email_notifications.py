"""SendEmailNotifications — TEMPLATE step (operator fills business logic).

The standalone already sends START + FINISH emails via
``FileRunReport.send_email()`` — those are pipeline-level alerts.

This step exists as a SEPARATE polling-row hook for operator-specific
notifications that should fire as a discrete workflow stage (e.g. a
tenant-specific email to a downstream consumer once ProcessData
finishes).  Default implementation re-sends the FileRunReport via the
SAME email config the standalone used, which is enough for most
operators.  Override ``_send_custom`` in a subclass for tenant rules.
"""
from __future__ import annotations

import logging
import os
import sys
from datetime import datetime
from typing import Any, Dict

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport


class SendEmailNotifications(BaseStep):
    """Operator-overridable email hook (default re-sends RunReport)."""

    LOG_PREFIX = "file_to_oracle_send_email"

    def _setup_logging(self, task: Dict) -> None:
        # 2026-07-02 -- single chokepoint (log_config.attach_step_logger).
        from log_config import attach_step_logger
        self.logger = attach_step_logger(
            f"file_flow.{self.LOG_PREFIX}", task, workflow="file_to_oracle",
        )

    def _build_email_config(self, task: Dict) -> Dict[str, Any]:
        """Read SMTP + recipient knobs from the polling-row columns."""
        cfg: Dict[str, Any] = {}
        for src, dst in (
            ("SEND_EMAIL", "send_email"),
            ("SMTP_HOST", "smtp_host"),
            ("SMTP_PORT", "smtp_port"),
            ("SMTP_USER", "smtp_user"),
            ("SMTP_PASSWORD", "smtp_password"),
            ("SMTP_USE_TLS", "smtp_use_tls"),
            ("EMAIL_FROM", "email_from"),
            ("EMAIL_TO", "email_to"),
            ("EMAIL_SUBJECT", "email_subject"),
        ):
            v = task.get(src) or task.get(src.lower())
            if v not in (None, "", 0):
                cfg[dst] = v
        return cfg

    def _send_custom(self, task: Dict, email_cfg: Dict[str, Any]) -> bool:
        """Operator extension point.  Default: re-send the RunReport.

        Override in a subclass to send a tenant-specific notification
        (custom subject + body, JSON webhook, Slack message, …).
        """
        rr = task.get("_run_report")
        if not isinstance(rr, FileRunReport):
            self.logger.warning(
                "SendEmailNotifications: no FileRunReport on task — nothing to send"
            )
            return False
        # Force a SUCCESS subject when called explicitly via this step
        # (the standalone may not have called mark_success yet).
        if rr.status == "START":
            rr.mark_success()
        return rr.send_email(email_cfg)

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> int:
        self._setup_logging(task)
        self.logger.info(f"{step_name} has been started")
        email_cfg = self._build_email_config(task)
        sent = self._send_custom(task, email_cfg)
        self.logger.info(
            f"{step_name} completed — email %s",
            "SENT" if sent else "SKIPPED (config disabled or missing)",
        )
        task["totalcount"] = 0
        return 0
