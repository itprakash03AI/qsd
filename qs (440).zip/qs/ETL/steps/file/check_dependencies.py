"""CheckDependencies — TEMPLATE step (operator fills business logic).

Pre-wired with the file-flow conventions so the operator only writes
the actual dependency-check logic in ``_check`` and ``_check_one``:

  * Single-file logging via ``log_config.build_module_logger`` so this
    step's output lands in the same log file as the rest of the run.
  * Run-report integration — registers a context entry + a per-job
    result so the HTML report shows which dependencies were verified.
  * Loud failure: a missing / unsatisfied dependency raises a clear
    ValueError; the standalone catches it and triggers
    RunArtifacts.cleanup_on_failure().

Typical responsibilities of a dependency check in this pipeline:

  1. Are the polling-row inputs (sql_query_path, output_file_location,
     server_name / port credentials) populated?
  2. Is the JSON config at sql_query_path well-formed + does it list
     at least one job for our datasource?
  3. Are upstream business-date prerequisites in OTG_DEPENDENCY met?
  4. Can we reach Starburst on the configured host:port?

The defaults below cover (1) and (2) so even an empty operator
override gets useful coverage.  Override / extend ``_check_one`` to
add (3) and (4) for your tenant.
"""
from __future__ import annotations

import json
import logging
import os
import sys
from datetime import datetime
from typing import Any, Dict, List

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import get_or_create_artifacts


class CheckDependencies(BaseStep):
    """Verify upstream / config prerequisites before the extract runs."""

    LOG_PREFIX = "check_dependencies"

    REQUIRED_TASK_FIELDS = (
        "run_id",
        "run_detail_id",
        "fk_report_id",
        "fk_dag_id",
        "sql_query_path",
        "business_date",
    )

    def _setup_logging(self, task: Dict) -> None:
        # 2026-07-02 -- single chokepoint (log_config.attach_step_logger)
        # so every step in the run appends to ONE file per user
        # directive: "1 log per run per workflow".
        from log_config import attach_step_logger
        self.logger = attach_step_logger(
            f"file_flow.{self.LOG_PREFIX}", task, workflow="file_flow",
        )

    def _check_required_task_fields(self, task: Dict) -> List[str]:
        missing = [f for f in self.REQUIRED_TASK_FIELDS if not task.get(f)]
        return missing

    def _check_query_config(self, task: Dict) -> Dict[str, Any]:
        path = task.get("sql_query_path")
        if not path:
            raise ValueError("sql_query_path is empty on the polling row")
        if not os.path.exists(path):
            raise ValueError(f"sql_query_path does not exist on disk: {path!r}")
        with open(path, "r", encoding="utf-8") as f:
            try:
                cfg = json.load(f)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"sql_query_path JSON is malformed at {path}: {exc}"
                )
        if not isinstance(cfg, dict) or "jobs" not in cfg:
            raise ValueError(
                f"sql_query_path JSON must be an object with a 'jobs' array: {path}"
            )
        if not isinstance(cfg["jobs"], list) or not cfg["jobs"]:
            raise ValueError(
                f"sql_query_path JSON 'jobs' is empty or not a list: {path}"
            )
        return cfg

    # ----- Hooks the operator can override -----------------------------

    def _check_one(self, task: Dict, query_cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Default per-job check — extend in a subclass for tenant-specific rules.

        Returns a list of {name, ok, detail} dicts that get folded into
        the run report.  Default checks: each job carries the minimum
        keys we need to extract (report_id, server_name, port,
        generated_sql, output_file_location, output_file_name).
        """
        required_job_keys = (
            "report_id", "datasource_name", "server_name", "port",
            "generated_sql", "output_file_location", "output_file_name",
        )
        results: List[Dict[str, Any]] = []
        for job in query_cfg.get("jobs", []):
            missing = [k for k in required_job_keys if not job.get(k)]
            ok = not missing
            detail = (
                f"all keys present" if ok
                else f"missing keys: {missing}"
            )
            results.append({
                "name": f"job_{job.get('report_id', '?')}_{job.get('datasource_name', '?')}",
                "ok": ok,
                "detail": detail,
            })
        return results

    # ----- BaseStep contract -------------------------------------------

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> int:
        self._setup_logging(task)
        get_or_create_artifacts(task, logger=self.logger)
        rr = task.get("_run_report")
        run_report: FileRunReport = rr if isinstance(rr, FileRunReport) else None

        self.logger.info("=" * 72)
        self.logger.info("CheckDependencies for run_id=%s report_id=%s",
                          task.get("run_id"), task.get("fk_report_id"))
        self.logger.info("=" * 72)

        # 1. Task-field presence
        missing_fields = self._check_required_task_fields(task)
        if missing_fields:
            raise ValueError(
                f"CheckDependencies: polling row missing required fields {missing_fields} — "
                f"populate them on the polling table or upstream query."
            )

        # 2. Query config presence + well-formed
        query_cfg = self._check_query_config(task)
        self.logger.info(
            "Query config OK: %s (%d job(s))",
            task.get("sql_query_path"), len(query_cfg.get("jobs", [])),
        )

        # 3. Per-job checks (operator extension point)
        per_job = self._check_one(task, query_cfg)
        failed = [r for r in per_job if not r["ok"]]
        for r in per_job:
            level = self.logger.info if r["ok"] else self.logger.error
            level("  %-40s  %s  %s", r["name"], "OK" if r["ok"] else "FAIL", r["detail"])

        if failed:
            raise ValueError(
                f"CheckDependencies: {len(failed)} of {len(per_job)} job checks FAILED — "
                f"{[r['name'] for r in failed]}.  See log for details."
            )

        # 4. Roll up into run report
        if run_report is not None:
            run_report.runtime_knobs.update({
                "check_dependencies_pass_count": len(per_job) - len(failed),
                "check_dependencies_total_count": len(per_job),
                "sql_query_path": task.get("sql_query_path"),
            })

        # totalcount is used by BaseStep for the Oracle status update;
        # CheckDependencies doesn't move rows so 0 is correct.
        task["totalcount"] = 0
        return 0
