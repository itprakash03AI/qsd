"""ConsolidateFiles — merge per-chunk files into one deliverable.

Single responsibility: take the ``chunk_files`` list the
Starburst-to-file step left on the task dict (or in the sidecar) and
concatenate them into ONE consolidated file at
``<output_dir>/<output_file_name>``.

Owns completeness gate G5:

    Consolidated row count  ==  G1 source pre-flight COUNT(*)

A mismatch raises before any downstream step (compress / ctl / deliver)
runs, so partial / corrupted data never ships.  The standalone catches
the raise and ``RunArtifacts.cleanup_on_failure()`` deletes every
chunk + the (incomplete) consolidated file.

Streams line-by-line: only one chunk file is open at a time + a single
output handle.  Header from the first non-empty chunk is written
once; subsequent chunks' headers are skipped.  This is safe because
every chunk file came from the SAME query (modulo partition predicate)
so all chunks share the same column order.

Chunk files are deleted after a successful merge (configurable via
job_config ``delete_chunks_after_merge``, default True).  Failure
leaves chunks on disk so the operator can re-merge manually.
"""
from __future__ import annotations

import os
import time
from collections import defaultdict
from typing import Any, Dict, List, Optional

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import (
    RunArtifacts,
    backup_if_exists,
    get_or_create_artifacts,
    hydrate_task_from_sidecar,
    save_task_state,
)


PROGRESS_INTERVAL = 250_000


class ConsolidateFiles(BaseStep):
    """Merge per-chunk files into one consolidated file per job."""

    LOG_PREFIX = "consolidate_files"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.run_report: Optional[FileRunReport] = None
        self.artifacts: Optional[RunArtifacts] = None

    # ----- Setup --------------------------------------------------------

    def _setup_logging(self, task: Dict) -> None:
        # 2026-07-02 -- single chokepoint (log_config.attach_step_logger).
        from log_config import attach_step_logger
        self.logger = attach_step_logger(
            f"file_flow.{self.LOG_PREFIX}", task, workflow="file_flow",
        )

    def _get_run_report(self, task: Dict) -> FileRunReport:
        rr = task.get("_run_report")
        if isinstance(rr, FileRunReport):
            return rr
        output_dir = task.get("output_dir") or ""
        rr = FileRunReport(output_dir=output_dir, logger=self.logger)
        rr.set_context(
            run_id=task.get("run_id"),
            run_detail_id=task.get("run_detail_id"),
            dag_id=task.get("fk_dag_id"),
            report_id=task.get("fk_report_id"),
            business_date=task.get("business_date"),
        )
        task["_run_report"] = rr
        return rr

    # ----- Merge core ---------------------------------------------------

    def _merge_chunks_for_job(
        self, job_result: Dict[str, Any],
    ) -> Dict[str, Any]:
        report_id = job_result.get("report_id")
        chunk_files: List[str] = job_result.get("chunk_files", []) or []
        output_dir = job_result.get("output_dir") or ""
        output_filename = job_result.get("output_filename") or ""
        # CompletenessProbe (2026-06-18) -- value-column SUM checksum.
        # When the Starburst step computed source_checksums against
        # (base_sql) AS t, we sum the SAME columns from the merged
        # output file as we stream.  Caller compares against
        # sum(source_checksums per source).  Detects row drop /
        # duplication that row-count G5 can miss when base_sql has
        # shape-affecting DISTINCT / GROUP BY.
        checksum_columns: List[str] = list(job_result.get("checksum_columns", []) or [])
        # Delimiter for CSV parsing during sum -- defaults to ``|``
        # (the engine's default).  Job result carries the actual
        # delimiter when known.
        delimiter: str = job_result.get("delimiter") or "|"
        if not chunk_files:
            raise ValueError(
                f"Job {report_id}: no chunk files recorded — the upstream "
                f"Starburst step did not register any output."
            )
        if not output_dir or not output_filename:
            raise ValueError(
                f"Job {report_id}: output_dir / output_filename missing on job result."
            )

        # Normalize the final filename (strip _CLOUD / _ONPREM suffixes
        # from the BASE so multi-source jobs collapse to a single file)
        final_filename = _strip_datasource_suffix(output_filename)
        final_path = os.path.join(output_dir, final_filename)

        # 2026-06-13 -- back up (or delete, per operator's flag) any
        # prior-run deliverable at this path BEFORE we overwrite it
        # with the new merge result.  No-op if nothing exists.
        # IMPORTANT: skip when final_path IS one of this run's input
        # chunks -- single-source workflow's chunk path can equal the
        # final consolidated path (no suffix to strip), and moving it
        # to backup would leave the merge with a missing source.  The
        # `.merging` tmp + os.replace pattern already handles the
        # source-equals-target overlap safely in that case.
        _final_abs = os.path.abspath(final_path)
        _chunk_abspaths = {os.path.abspath(c) for c in chunk_files}
        if _final_abs not in _chunk_abspaths:
            backup_if_exists(
                final_path,
                backup_ts=getattr(self, "_backup_ts", None),
                mode=getattr(self, "_prior_output_mode", "backup"),
                logger=self.logger,
            )

        non_empty_chunks = [c for c in chunk_files if os.path.exists(c) and os.path.getsize(c) > 0]
        missing = [c for c in chunk_files if not os.path.exists(c)]
        # 2026-06-12 — Issue #3 fix: a missing source file is a HARD error,
        # not a warning.  Previously we'd silently continue with the
        # remaining files and the G5 check would catch the row mismatch —
        # but if all chunks were missing (e.g. an upstream race) the
        # 'nothing to consolidate' branch fired with a confusing message.
        # Refuse loudly and name the missing files.
        if missing:
            raise ValueError(
                f"Job {report_id}: {len(missing)} chunk file(s) missing on disk: "
                f"{missing[:5]}{'...' if len(missing) > 5 else ''}.  "
                f"Refusing to merge a partial input set."
            )
        if not non_empty_chunks:
            raise ValueError(
                f"Job {report_id}: every chunk file is empty — "
                f"nothing to consolidate.  Upstream Starburst step likely "
                f"produced zero rows."
            )

        start = time.time()
        rows_written = 0
        header_written = False

        # Pre-flight: writable target.
        os.makedirs(output_dir, exist_ok=True)

        # 2026-06-12 — Issue #1+#3 fix: when a source file's path equals
        # the target path (e.g. the Starburst step's self-consolidated
        # file already lives at the final destination because no
        # _CLOUD/_ONPREM suffix existed to strip), opening the target
        # for write would TRUNCATE the source mid-read, leaving an empty
        # file.  Write to a sibling ``.merging`` tmp first then atomic
        # rename at the end — source/target overlap is now safe.
        tmp_path = final_path + ".merging"
        if os.path.exists(tmp_path):
            self.logger.info("Removing stale tmp %s before merge", tmp_path)
            os.remove(tmp_path)

        self.logger.info(
            "Merging %d chunk file(s) -> %s for report_id=%s",
            len(non_empty_chunks), final_path, report_id,
        )

        # CompletenessProbe sums per checksum column.
        import csv as _csv
        from decimal import Decimal, InvalidOperation
        _ck_sums: Dict[str, Any] = {c: Decimal(0) for c in checksum_columns}
        _ck_indices: Dict[str, int] = {}
        try:
            with open(tmp_path, "w", encoding="utf-8", newline="", buffering=4 * 1024 * 1024) as out:
                for i, chunk_path in enumerate(non_empty_chunks, start=1):
                    self.logger.info(
                        "Merging chunk %d/%d: %s", i, len(non_empty_chunks), chunk_path,
                    )
                    chunk_rows = 0
                    with open(chunk_path, "r", encoding="utf-8", newline="") as src:
                        header = src.readline()
                        if not header:
                            # Should NEVER happen — non_empty_chunks filter
                            # gated on getsize > 0.  Raise so the operator
                            # sees the contradiction instead of producing
                            # an empty file silently.
                            raise ValueError(
                                f"Chunk {chunk_path} reported non-empty but "
                                f"yielded no header — concurrent truncation?"
                            )
                        if not header_written:
                            out.write(header)
                            header_written = True
                            # Resolve checksum column indices once.
                            if checksum_columns:
                                hdr_cells = next(_csv.reader(
                                    [header.rstrip("\r\n")], delimiter=delimiter,
                                ))
                                _by_name = {n: idx for idx, n in enumerate(hdr_cells)}
                                missing = [c for c in checksum_columns if c not in _by_name]
                                if missing:
                                    self.logger.warning(
                                        "Checksum columns %s not present in merged "
                                        "header %s -- skipping those columns.",
                                        missing, hdr_cells,
                                    )
                                _ck_indices = {
                                    c: _by_name[c]
                                    for c in checksum_columns if c in _by_name
                                }
                                for c in list(_ck_sums.keys()):
                                    if c not in _ck_indices:
                                        _ck_sums.pop(c, None)
                        for line in src:
                            out.write(line)
                            rows_written += 1
                            chunk_rows += 1
                            if rows_written % PROGRESS_INTERVAL == 0:
                                self.logger.info(
                                    "  progress: %s rows merged...", f"{rows_written:,}",
                                )
                            # Accumulate value-column sums.
                            if _ck_indices:
                                try:
                                    row_cells = next(_csv.reader(
                                        [line.rstrip("\r\n")], delimiter=delimiter,
                                    ))
                                except (_csv.Error, StopIteration):
                                    continue
                                for col, idx in _ck_indices.items():
                                    if idx >= len(row_cells):
                                        continue
                                    cell = row_cells[idx].strip()
                                    if not cell:
                                        continue
                                    try:
                                        _ck_sums[col] += Decimal(cell)
                                    except (InvalidOperation, ValueError):
                                        if _ck_sums[col] == Decimal(0):
                                            self.logger.warning(
                                                "Checksum column %r non-numeric "
                                                "at row %d (%r) -- aborting "
                                                "checksum for this column.",
                                                col, rows_written, cell,
                                            )
                                        _ck_indices.pop(col, None)
                                        _ck_sums.pop(col, None)
                    self.logger.info(
                        "  chunk %d done: %s rows", i, f"{chunk_rows:,}",
                    )
                out.flush()
                try:
                    os.fsync(out.fileno())
                except OSError:
                    pass
            # Atomic move into place.  os.replace is rename-overwrite
            # on every platform Python supports — safe to run even if
            # the destination already exists.
            os.replace(tmp_path, final_path)
            # 2026-06-20 deep-dive fix: defeat NTFS file-name TUNNELING
            # on the FINAL cross-source merged file.  Per-source consolidated
            # files already get force_creation_time_now; the cross-source
            # final file was missing it, so on Windows downstream consumers
            # saw stale creation time inherited from a same-named file the
            # last run wrote.  ctime now matches mtime (this run's actual
            # write time).
            try:
                from steps.file.run_state import force_creation_time_now as _fct
                _fct(final_path, logger=self.logger)
            except ImportError:
                pass
        except Exception:
            # Failure mid-merge: drop the partial tmp.  The previous
            # final_path is untouched because the writes went to tmp.
            for p in (tmp_path, final_path + ".tmp"):
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
            raise

        duration = time.time() - start
        self.logger.info(
            "Merge complete: %s rows in %.1fs -> %s "
            "(ctime forced to now to defeat NTFS tunneling)",
            f"{rows_written:,}", duration, final_path,
        )

        # Register consolidated artifact BEFORE the G5 check so failure
        # cleanup also drops the partial file.
        self.artifacts.add(final_path, RunArtifacts.CONSOLIDATED)

        return {
            "report_id": report_id,
            "datasource": job_result.get("datasource"),
            "consolidated_file": final_path,
            "consolidated_rows": rows_written,
            "merged_chunks": len(non_empty_chunks),
            "expected_total": job_result.get("expected_total"),
            "control_template": job_result.get("control_template"),
            "zip_format": job_result.get("zip_format"),
            "filename": final_filename,
            "file_path": final_path,
            "duration_sec": duration,
            "status": "success",
            # CompletenessProbe -- value-column sums from the merged file.
            # Empty when checksum_columns wasn't requested or all cols
            # ended up skipped (missing / non-numeric).
            "checksum_columns": checksum_columns,
            "consolidated_checksums": {k: str(v) for k, v in _ck_sums.items()},
        }

    # ----- _execute_step ---------------------------------------------------

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> List[Dict[str, Any]]:
        self._setup_logging(task)
        self.artifacts = get_or_create_artifacts(task, logger=self.logger)
        self.run_report = self._get_run_report(task)
        # 2026-06-13 -- per-run backup timestamp + mode for the
        # "rename prior file to backup folder" feature.  Threaded from
        # the standalone via task["backup_ts"] + task["prior_output_mode"]
        # ("backup" or "delete") so every prior-run deliverable for
        # this run lands in ONE folder, or is purged directly when the
        # operator chose delete mode.
        self._backup_ts = task.get("backup_ts") or None
        self._prior_output_mode = task.get("prior_output_mode") or "backup"

        # Hydrate from sidecar if running on a fresh task dict (separate
        # polling row).
        base_dir = task.get("output_dir") or ""
        if not task.get("job_results"):
            hydrate_task_from_sidecar(task, base_dir, task.get("run_id"), logger=self.logger)

        job_results: List[Dict[str, Any]] = task.get("job_results", []) or []
        if not job_results:
            # Backwards-compat fallback: if upstream stuck a flat list of chunks
            # on task['chunk_files'] without a job_results envelope, treat as
            # one anonymous job.
            chunk_files = task.get("chunk_files", []) or []
            if not chunk_files:
                raise ValueError(
                    "ConsolidateFiles: no job_results and no chunk_files on task — "
                    "upstream Starburst step did not run or did not persist state."
                )
            job_results = [{
                "report_id": task.get("fk_report_id"),
                "datasource": "",
                "chunk_files": chunk_files,
                "output_dir": base_dir,
                "output_filename": f"report_{task.get('fk_report_id')}.csv",
                "expected_total": task.get("expected_total") or task.get("totalcount"),
            }]

        # If the same report_id appears under multiple datasources
        # (cloud + onprem split), group them so we merge cross-source.
        by_report = defaultdict(list)
        for jr in job_results:
            by_report[str(jr.get("report_id"))].append(jr)

        consolidation_results: List[Dict[str, Any]] = []
        total_consolidated = 0
        try:
            for report_id, group in by_report.items():
                # 2026-06-12 — prefer per-source consolidated files (one
                # per source from the Starburst step's self-consolidate
                # pass) over raw chunk files.  The cross-source merge
                # then handles 1 file per source instead of N chunks per
                # source.  Back-compat: when consolidated_file is absent
                # (upstream is older or wasn't a Starburst source step),
                # fall through to chunk_files via the existing path.
                source_files = [g.get("consolidated_file") for g in group
                                if g.get("consolidated_file")]
                if source_files and len(source_files) == len(group):
                    flat = dict(group[0])
                    flat["chunk_files"] = source_files
                    flat["expected_total"] = sum(
                        int(g.get("expected_total") or 0) for g in group
                    )
                    res = self._merge_chunks_for_job(flat)
                elif len(group) == 1:
                    res = self._merge_chunks_for_job(group[0])
                else:
                    # Multi-source — flatten chunk_files and pick the
                    # filename from the first job (post-suffix-strip
                    # the file names collapse to the same target).
                    merged_chunks = []
                    for g in group:
                        merged_chunks.extend(g.get("chunk_files", []))
                    flat = dict(group[0])
                    flat["chunk_files"] = merged_chunks
                    flat["expected_total"] = sum(int(g.get("expected_total") or 0) for g in group)
                    res = self._merge_chunks_for_job(flat)
                consolidation_results.append(res)
                total_consolidated += res["consolidated_rows"]
                self.run_report.add_output_file(res["consolidated_file"])

            # ----- G5 reconcile ------------------------------------------
            expected_total = sum(
                int(jr.get("expected_total") or 0) for jr in job_results
            )
            if expected_total and total_consolidated != expected_total:
                raise ValueError(
                    f"ConsolidateFiles: G5 reconcile FAILED — consolidated "
                    f"rows={total_consolidated:,} != expected_total={expected_total:,} "
                    f"(delta {total_consolidated - expected_total:+,}).  "
                    f"Rows were lost or duplicated between Starburst extract and "
                    f"file consolidation."
                )

            # ----- G5 VALUE-COLUMN CHECKSUM reconcile (CompletenessProbe) --
            # Robust against shape-affecting SQL (DISTINCT / GROUP BY)
            # because both source (`SUM(col) FROM (base_sql) AS t`) and
            # sink (sum of CSV cells in the merged file) run over the
            # SAME post-aggregation rows.  Mismatch = real data loss
            # the row count cannot catch.
            from decimal import Decimal
            ck_cols_set: set = set()
            for jr in job_results:
                for c in (jr.get("checksum_columns") or []):
                    ck_cols_set.add(c)
            for r in consolidation_results:
                for c in (r.get("checksum_columns") or []):
                    ck_cols_set.add(c)
            if ck_cols_set:
                # Expected = sum across sources of source_checksums.
                expected_sums: Dict[str, Decimal] = {c: Decimal(0) for c in ck_cols_set}
                for jr in job_results:
                    for c, v in (jr.get("source_checksums") or {}).items():
                        if c in expected_sums and v not in (None, "", "None"):
                            try:
                                expected_sums[c] += Decimal(str(v))
                            except Exception:
                                pass
                # Actual = sum across consolidation_results of consolidated_checksums.
                actual_sums: Dict[str, Decimal] = {c: Decimal(0) for c in ck_cols_set}
                for r in consolidation_results:
                    for c, v in (r.get("consolidated_checksums") or {}).items():
                        if c in actual_sums and v not in (None, "", "None"):
                            try:
                                actual_sums[c] += Decimal(str(v))
                            except Exception:
                                pass
                mismatches = []
                for c in ck_cols_set:
                    if expected_sums[c] != actual_sums[c]:
                        mismatches.append(
                            f"{c}: source={expected_sums[c]} "
                            f"vs consolidated={actual_sums[c]} "
                            f"(delta {actual_sums[c] - expected_sums[c]:+})"
                        )
                if mismatches:
                    raise ValueError(
                        f"ConsolidateFiles: G5 VALUE-COLUMN CHECKSUM FAILED "
                        f"on {len(mismatches)} column(s): "
                        f"{'; '.join(mismatches)}.  Rows were lost or "
                        f"duplicated between Trino aggregate and final "
                        f"consolidated file -- row count G5 may have "
                        f"passed if base_sql has DISTINCT / GROUP BY, "
                        f"but the value sums prove the data is incomplete."
                    )
                self.logger.info(
                    "G5 VALUE-COLUMN CHECKSUM OK on columns %s: %s",
                    sorted(ck_cols_set),
                    ", ".join(f"{c}={actual_sums[c]}" for c in sorted(ck_cols_set)),
                )

            self.run_report.set_counts(consolidated_total=total_consolidated)
            self.logger.info(
                "G5 OK: consolidated %s rows match expected %s",
                f"{total_consolidated:,}", f"{expected_total:,}",
            )

            # Delete chunk files after successful merge.
            delete_chunks = bool(task.get("delete_chunks_after_merge", True))
            if delete_chunks:
                self.artifacts.cleanup_chunks_only()

            # 2026-06-12 — Issue #2 fix: also clean up the per-source
            # consolidated files (CLOUD.dat / ONPREM.dat) once the
            # cross-source merge has produced the canonical deliverable.
            # They're intermediates from the Starburst step's
            # self-consolidate pass, NOT operator-facing artifacts.
            # Final consolidated file is in consolidation_results — skip
            # it so we don't delete what we just produced.
            delete_intermediates = bool(
                task.get("delete_intermediate_consolidated", True)
            )
            if delete_intermediates:
                final_paths = {
                    os.path.abspath(r["consolidated_file"])
                    for r in consolidation_results
                    if r.get("consolidated_file")
                }
                removed = 0
                for jr in job_results:
                    inter = jr.get("consolidated_file")
                    if not inter:
                        continue
                    inter_abs = os.path.abspath(inter)
                    if inter_abs in final_paths:
                        continue  # this IS the final deliverable
                    if os.path.exists(inter_abs):
                        try:
                            os.remove(inter_abs)
                            removed += 1
                        except OSError as exc:
                            self.logger.warning(
                                "Could not remove per-source intermediate %s: %s",
                                inter_abs, exc,
                            )
                if removed:
                    self.logger.info(
                        "Cleaned up %d per-source intermediate file(s) "
                        "after successful cross-source merge", removed,
                    )

            # Stash for downstream steps.
            task["consolidation_results"] = consolidation_results
            task["consolidated_file"] = (
                consolidation_results[0]["consolidated_file"] if consolidation_results else ""
            )
            task["consolidated_total"] = total_consolidated
            task["totalcount"] = total_consolidated
            task["artifact_paths"] = self.artifacts.snapshot()

            if consolidation_results and base_dir:
                save_task_state(task, base_dir, task.get("run_id"), logger=self.logger)
        finally:
            self.run_report.write()

        return consolidation_results


def _strip_datasource_suffix(name: str) -> str:
    """Remove _CLOUD / _ONPREM markers from a filename so multi-source
    deliverables collapse to one canonical name."""
    if "_CLOUD." in name:
        return name.replace("_CLOUD.", ".")
    if "_ONPREM." in name:
        return name.replace("_ONPREM.", ".")
    if name.endswith("_CLOUD"):
        return name[: -len("_CLOUD")]
    if name.endswith("_ONPREM"):
        return name[: -len("_ONPREM")]
    return name
