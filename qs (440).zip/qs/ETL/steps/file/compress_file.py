"""CompressFile — compress the consolidated file in a configurable format.

2026-06-12 — Merged with the reference implementation
(``refer_compresfile.py`` at the same path):

  From the reference:
    * Multi-format support (gzip / zip / tar / tar.gz).
    * Per-format compression statistics in the log (original size,
      compressed size, ratio, time).
    * Compressed-file integrity validation (re-open the archive after
      write).
    * ``compression_format`` task knob for selecting the algorithm.

  Preserved from the existing pipeline contract:
    * Reads ``task['consolidation_results']`` / ``task['consolidated_file']``
      (left by ConsolidateFiles); the legacy ``control_file_results``
      input from the reference is NOT used because the user's pipeline
      runs ConsolidateFiles -> CompressFile -> CreateControlFile, and
      CreateControlFile downstream reads ``compress_results`` from the
      task / sidecar.
    * Hydrates from the sidecar on entry so a fresh polling-row task
      dict picks up upstream state.
    * Returns the same shape (``compress_results`` with md5 + sha256
      checksums) the downstream CreateControlFile expects.
    * ``build_module_logger`` (via ``_setup_logging``) -- NEVER
      ``CentralizedLogger`` per the file-flow architecture rule.
    * Sidecar persistence + RunArtifacts registration.
"""
from __future__ import annotations

import gzip
import hashlib
import logging
import os
import sys
import tarfile
import time
import zipfile
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from steps.BaseStep import BaseStep
from steps.file.run_report import FileRunReport
from steps.file.run_state import (
    RunArtifacts, backup_if_exists, get_or_create_artifacts,
    save_task_state, hydrate_task_from_sidecar,
)


CHUNK_BYTES = 8 * 1024 * 1024  # 8 MB streaming buffer

# Supported compression formats — matches the reference's
# ``supported_formats`` list.  ``gzip`` is the default for back-compat
# with the existing pipeline.
SUPPORTED_FORMATS = ("gzip", "zip", "tar", "tar.gz")
DEFAULT_FORMAT = "gzip"


def _make_md5():
    # FIPS-strict hosts refuse hashlib.md5() without ``usedforsecurity=False``.
    # Used here for delivery checksum advertising, not crypto, so the kwarg is correct.
    try:
        return hashlib.md5(usedforsecurity=False)
    except TypeError:
        return hashlib.md5()


def _human_bytes(n: int) -> str:
    """Render a byte count as KB/MB/GB."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


class CompressFile(BaseStep):
    """Compress the consolidated file using the configured format."""

    LOG_PREFIX = "compress_file"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.artifacts: Optional[RunArtifacts] = None
        self.run_report: Optional[FileRunReport] = None
        # Mirror the reference's supported_formats — operators reading
        # the step instance see the same surface.
        self.supported_formats: Tuple[str, ...] = SUPPORTED_FORMATS

    # ---------- logging (build_module_logger pattern, NOT CentralizedLogger) --

    def _setup_logging(self, task: Dict) -> None:
        # 2026-07-02 -- single chokepoint (log_config.attach_step_logger).
        from log_config import attach_step_logger
        self.logger = attach_step_logger(
            f"file_flow.{self.LOG_PREFIX}", task, workflow="file_flow",
        )

    # ---------- format selection -------------------------------------------

    def _get_compression_format(self, task: Dict) -> str:
        """Pick the format from the task / per-job config.  Falls back
        to gzip for back-compat.  Mirrors the reference helper."""
        fmt = (task.get("compression_format") or DEFAULT_FORMAT).lower()
        if fmt not in self.supported_formats:
            raise ValueError(
                f"Unsupported compression_format: {fmt!r} (supported: "
                f"{list(self.supported_formats)})"
            )
        return fmt

    def _compressed_filename(self, source_file: str, fmt: str) -> str:
        """Build the per-format target filename for ``source_file``.
        Mirrors the reference ``_get_compressed_filename`` helper."""
        base = os.path.splitext(source_file)[0]
        if fmt == "gzip":
            return f"{source_file}.gz"
        if fmt == "zip":
            return f"{base}.zip"
        if fmt == "tar":
            return f"{base}.tar"
        if fmt == "tar.gz":
            return f"{base}.tar.gz"
        # Defensive — _get_compression_format already validated.
        return f"{source_file}.gz"

    # ---------- per-format compress workers -------------------------------

    def _compress_with_gzip(
        self, source_file: str, target_file: str, level: int,
    ) -> Dict[str, Any]:
        """Stream source -> gzip target.  Returns the per-format stats
        dict the reference returns (method/original_size/compressed_size/
        compression_ratio/time_taken)."""
        start = time.time()
        original_size = os.path.getsize(source_file)
        with open(source_file, "rb") as src, gzip.open(
            target_file, "wb", compresslevel=level,
        ) as dst:
            while True:
                buf = src.read(CHUNK_BYTES)
                if not buf:
                    break
                dst.write(buf)
        # 2026-06-21 audit bug #12: defeat NTFS tunneling on the .gz
        # output so its ctime matches THIS run (was inheriting the
        # first-ever-creation ctime).  No-op on POSIX.
        try:
            from steps.file.run_state import force_creation_time_now as _fct
            _fct(target_file, logger=self.logger)
        except Exception:
            pass
        compressed_size = os.path.getsize(target_file)
        ratio = ((1 - compressed_size / original_size) * 100.0) if original_size else 0.0
        duration = time.time() - start
        self.logger.info(
            "GZIP %s -> %s | %s -> %s | ratio %.1f%% | %.2fs",
            source_file, target_file,
            _human_bytes(original_size), _human_bytes(compressed_size),
            ratio, duration,
        )
        return {
            "method": "gzip",
            "original_size": original_size,
            "compressed_size": compressed_size,
            "compression_ratio": ratio,
            "time_taken": duration,
        }

    def _compress_with_zip(
        self, source_files: List[str], target_file: str, level: int,
    ) -> Dict[str, Any]:
        """ZIP one or more source files."""
        start = time.time()
        total_original = 0
        with zipfile.ZipFile(
            target_file, "w", zipfile.ZIP_DEFLATED, compresslevel=level,
        ) as zf:
            for src in source_files:
                if not os.path.exists(src):
                    self.logger.warning("ZIP: source missing, skipping: %s", src)
                    continue
                total_original += os.path.getsize(src)
                arcname = os.path.basename(src)
                zf.write(src, arcname)
                self.logger.debug("ZIP: added %s as %s", src, arcname)
        # 2026-06-21 audit bug #12: defeat NTFS tunneling on the .zip
        # output so its ctime matches THIS run.  No-op on POSIX.
        try:
            from steps.file.run_state import force_creation_time_now as _fct
            _fct(target_file, logger=self.logger)
        except Exception:
            pass
        compressed_size = os.path.getsize(target_file)
        ratio = ((1 - compressed_size / total_original) * 100.0) if total_original else 0.0
        duration = time.time() - start
        self.logger.info(
            "ZIP %d file(s) -> %s | %s -> %s | ratio %.1f%% | %.2fs",
            len(source_files), target_file,
            _human_bytes(total_original), _human_bytes(compressed_size),
            ratio, duration,
        )
        return {
            "method": "zip",
            "files_compressed": len(source_files),
            "original_size": total_original,
            "compressed_size": compressed_size,
            "compression_ratio": ratio,
            "time_taken": duration,
        }

    def _compress_with_tar(
        self, source_files: List[str], target_file: str, use_gzip: bool,
    ) -> Dict[str, Any]:
        """TAR (optionally gzipped) one or more source files."""
        start = time.time()
        total_original = 0
        mode = "w:gz" if use_gzip else "w"
        with tarfile.open(target_file, mode) as tar:
            for src in source_files:
                if not os.path.exists(src):
                    self.logger.warning("TAR: source missing, skipping: %s", src)
                    continue
                total_original += os.path.getsize(src)
                arcname = os.path.basename(src)
                tar.add(src, arcname=arcname)
                self.logger.debug("TAR: added %s as %s", src, arcname)
        compressed_size = os.path.getsize(target_file)
        ratio = ((1 - compressed_size / total_original) * 100.0) if total_original else 0.0
        duration = time.time() - start
        method = "tar.gz" if use_gzip else "tar"
        self.logger.info(
            "%s %d file(s) -> %s | %s -> %s | ratio %.1f%% | %.2fs",
            method.upper(), len(source_files), target_file,
            _human_bytes(total_original), _human_bytes(compressed_size),
            ratio, duration,
        )
        return {
            "method": method,
            "files_compressed": len(source_files),
            "original_size": total_original,
            "compressed_size": compressed_size,
            "compression_ratio": ratio,
            "time_taken": duration,
        }

    # ---------- integrity validation --------------------------------------

    def _validate_compressed_file(
        self, target_file: str, fmt: str,
    ) -> bool:
        """Re-open the archive and read enough to verify it's not
        corrupt.  Returns True on success.  Logs WARN + returns False
        on failure — caller decides whether to fail the run."""
        if not os.path.exists(target_file):
            self.logger.error("Validation: missing %s", target_file)
            return False
        if os.path.getsize(target_file) == 0:
            self.logger.error("Validation: zero-byte %s", target_file)
            return False
        try:
            if fmt == "gzip":
                with gzip.open(target_file, "rb") as f:
                    f.read(1)
            elif fmt == "zip":
                with zipfile.ZipFile(target_file, "r") as zf:
                    bad = zf.testzip()
                    if bad:
                        self.logger.error("Validation: corrupt entry %s in %s", bad, target_file)
                        return False
            elif fmt in ("tar", "tar.gz"):
                mode = "r:gz" if fmt == "tar.gz" else "r"
                with tarfile.open(target_file, mode) as tar:
                    tar.getnames()
        except Exception as exc:
            self.logger.error("Validation: failed for %s (%s): %s", target_file, fmt, exc)
            return False
        return True

    # ---------- one-source pipeline ---------------------------------------

    def _compress_one(
        self,
        source_file: str,
        fmt: str,
        level: int,
        delete_uncompressed: bool,
    ) -> Dict[str, Any]:
        """Compress a single consolidated file according to ``fmt``,
        compute md5 + sha256 of the produced archive (for the CTL's
        downstream advertising), validate integrity, optionally delete
        the source.

        Returns the result dict downstream CreateControlFile reads:
        ``{source_file, compressed_file, uncompressed_size,
            compressed_size, md5_checksum, sha256_checksum, format,
            compression_stats, status, validation_passed, duration_sec}``
        """
        if not os.path.exists(source_file):
            raise ValueError(f"CompressFile: source not found: {source_file}")
        if os.path.getsize(source_file) == 0:
            raise ValueError(f"CompressFile: source is empty: {source_file}")

        target_file = self._compressed_filename(source_file, fmt)
        # 2026-06-13 -- back up (or delete) any prior-run compressed
        # output at this path before we overwrite it.  Mode comes from
        # task["prior_output_mode"] threaded by the standalone.
        backup_if_exists(
            target_file,
            backup_ts=getattr(self, "_backup_ts", None),
            mode=getattr(self, "_prior_output_mode", "backup"),
            logger=self.logger,
        )

        try:
            if fmt == "gzip":
                stats = self._compress_with_gzip(source_file, target_file, level)
            elif fmt == "zip":
                stats = self._compress_with_zip([source_file], target_file, level)
            elif fmt == "tar":
                stats = self._compress_with_tar([source_file], target_file, use_gzip=False)
            elif fmt == "tar.gz":
                stats = self._compress_with_tar([source_file], target_file, use_gzip=True)
            else:
                # _get_compression_format already validated, defensive only.
                raise ValueError(f"Unsupported compression format: {fmt}")
        except Exception:
            if os.path.exists(target_file):
                try:
                    os.remove(target_file)
                except OSError:
                    pass
            raise

        # Checksums of the ARCHIVE (what consumers verify against).
        md5 = _make_md5()
        sha256 = hashlib.sha256()
        with open(target_file, "rb") as f:
            while True:
                buf = f.read(CHUNK_BYTES)
                if not buf:
                    break
                md5.update(buf)
                sha256.update(buf)

        # Integrity check.  Raise on validation failure so the standalone's
        # cleanup-on-failure walks the artifact registry and removes the
        # half-baked archive.
        ok = self._validate_compressed_file(target_file, fmt)
        if not ok:
            try:
                os.remove(target_file)
            except OSError:
                pass
            raise ValueError(
                f"CompressFile: integrity validation FAILED for {target_file} "
                f"(format={fmt})"
            )
        self.logger.info("Validation passed: %s", target_file)

        if delete_uncompressed:
            try:
                os.remove(source_file)
                self.logger.info("Removed uncompressed source: %s", source_file)
            except OSError as exc:
                self.logger.warning("Could not remove source %s: %s", source_file, exc)

        return {
            "source_file": source_file,
            "compressed_file": target_file,
            "uncompressed_size": stats["original_size"],
            "compressed_size": stats["compressed_size"],
            "md5_checksum": md5.hexdigest(),
            "sha256_checksum": sha256.hexdigest(),
            "format": fmt,
            "compression_stats": stats,
            "duration_sec": stats["time_taken"],
            "validation_passed": True,
            "status": "success",
        }

    # ---------- step entry -------------------------------------------------

    async def _execute_step(
        self,
        task: Dict,
        worker_connection_string: str,
        dest_connection_string: str,
        step_name: str,
        *args, **kwargs,
    ) -> List[Dict[str, Any]]:
        self._setup_logging(task)
        self.artifacts = get_or_create_artifacts(task, logger=self.logger)
        rr = task.get("_run_report")
        self.run_report = rr if isinstance(rr, FileRunReport) else None
        # 2026-06-13 -- prior-output handling threaded from standalone.
        self._backup_ts = task.get("backup_ts") or None
        self._prior_output_mode = task.get("prior_output_mode") or "backup"

        # Hydrate from the sidecar so upstream ConsolidateFiles state
        # (consolidation_results / consolidated_file) is visible on a
        # fresh polling-row task dict.  Same pattern ConsolidateFiles
        # uses to read the upstream Starburst step's job_results.
        base_dir = task.get("output_dir") or ""
        if not task.get("consolidation_results") and not task.get("consolidated_file"):
            hydrate_task_from_sidecar(task, base_dir, task.get("run_id"), logger=self.logger)

        fmt = self._get_compression_format(task)
        gzip_level = int(task.get("gzip_level", 6))
        delete_uncompressed = bool(task.get("delete_uncompressed", True))

        self.logger.info(
            "CompressFile starting: format=%s, level=%d, delete_source=%s",
            fmt, gzip_level, delete_uncompressed,
        )

        consolidation_results: List[Dict[str, Any]] = task.get("consolidation_results", []) or []
        if not consolidation_results:
            single = task.get("consolidated_file")
            if not single:
                raise ValueError(
                    "CompressFile: no consolidation_results and no consolidated_file "
                    "on task — ConsolidateFiles must run first."
                )
            consolidation_results = [{
                "consolidated_file": single,
                "report_id": task.get("fk_report_id"),
            }]

        results: List[Dict[str, Any]] = []
        for cr in consolidation_results:
            src = cr.get("consolidated_file")
            res = self._compress_one(src, fmt, gzip_level, delete_uncompressed)
            res["report_id"] = cr.get("report_id")
            res["control_template"] = cr.get("control_template")
            self.artifacts.add(res["compressed_file"], RunArtifacts.COMPRESSED)
            if self.run_report:
                self.run_report.add_output_file(res["compressed_file"])
            results.append(res)

        # Aggregate stats for the run-log summary (matches the
        # reference's "Overall compression" line).
        total_original = sum(r["uncompressed_size"] for r in results)
        total_compressed = sum(r["compressed_size"] for r in results)
        if total_original > 0:
            overall = (1 - total_compressed / total_original) * 100.0
            self.logger.info(
                "Overall compression: %s -> %s (%.1f%% reduction across %d file(s))",
                _human_bytes(total_original), _human_bytes(total_compressed),
                overall, len(results),
            )

        task["compress_results"] = results
        task["compressed_file"] = results[0]["compressed_file"] if results else ""
        task["compressed_size"] = results[0]["compressed_size"] if results else 0
        task["uncompressed_size"] = results[0]["uncompressed_size"] if results else 0
        task["md5_checksum"] = results[0]["md5_checksum"] if results else ""
        task["sha256_checksum"] = results[0]["sha256_checksum"] if results else ""
        task["artifact_paths"] = self.artifacts.snapshot()

        # Persist for downstream CreateControlFile.
        sidecar_dir = (
            task.get("output_dir") or
            (os.path.dirname(results[0]["compressed_file"]) if results else "")
        )
        if sidecar_dir:
            save_task_state(task, sidecar_dir, task.get("run_id"), logger=self.logger)
        if self.run_report:
            self.run_report.write()

        return results
