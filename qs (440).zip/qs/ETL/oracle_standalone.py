# ============================================================================
# PREFLIGHT BOOTSTRAP -- MUST run BEFORE any 3rd-party / project imports.
# 2026-06-21 bug #13.  See file_standalone.py for full explanation.
# ============================================================================
import os as _bootstrap_os
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_etl_root = str(_BootstrapPath(__file__).resolve().parent)
if _bootstrap_etl_root not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0, _bootstrap_etl_root)
try:
    from preflight import preflight_check as _preflight_check
    _preflight_check(
        workflow="oracle",
        auto_install=True,
        install_optional=True,
        fail_on_missing_required=True,
    )
except ImportError:
    pass
# === END PREFLIGHT BOOTSTRAP ===

import asyncio
import argparse
import logging
import os
import sys
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, List

import yaml

# Make ETL importable when invoked as a script.
#
# spark-submit uploads ONLY the entry script to a temp dir like
# ``/usr/local/spark/pvc/jars/spark-upload-<uuid>/oracle_standalone.py``
# and PythonRunner sets ``__file__`` to that path.  If we trust
# ``__file__.parent``, sys.path[0] becomes an empty upload dir and
# ``from workers.oracle_worker import ...`` fails (the rest of the
# etl tree lives at ``/usr/local/spark/pvc/code/`` per
# dynamic_dags.py's PYTHONPATH).
#
# Strategy: probe well-known roots in priority order and pick the
# first one that actually contains the ``log_config.py`` sentinel.
# Falls through to ``__file__.parent`` for local dev where the script
# IS co-located with the rest of the package.
_SENTINEL = "log_config.py"
_CANDIDATE_ROOTS: List[str] = []
_env_etl_home = os.environ.get("ETL_HOME")
if _env_etl_home:
    _CANDIDATE_ROOTS.append(_env_etl_home)
_CANDIDATE_ROOTS.extend([
    "/usr/local/spark/pvc/code",        # prod PVC code root (matches DAG PYTHONPATH)
    "/usr/local/spark/pvc/code/etl",    # prod with etl/ subpackage layout
    "/usr/local/spark/pvc",             # PVC root (matches DAG PYTHONPATH first entry)
    str(Path(__file__).resolve().parent),  # local-dev / co-located fallback
])
ETL_ROOT = next(
    (p for p in _CANDIDATE_ROOTS if p and os.path.isfile(os.path.join(p, _SENTINEL))),
    str(Path(__file__).resolve().parent),
)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)

from workers.oracle_worker import OracleWorker
from datasources.starburst_datasource import StarburstDataSource

# Resolve core_libs path and add to sys.path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
CORE_LIBS_PATH = os.path.join(CURRENT_DIR, "core_libs")

if CORE_LIBS_PATH not in sys.path:
    sys.path.insert(0, CORE_LIBS_PATH)

from managers.oracle_metadata_manager import OracleMetadataManager

from log_config import get_log_dir as _get_log_dir, set_run_log_file, set_workflow_name
LOG_DIR = _get_log_dir()
LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# ── Console-only logger at startup (file handler added after args parsed) ──
logger = logging.getLogger("oracle_standalone")
logger.setLevel(logging.INFO)
_sh = logging.StreamHandler(sys.stdout)
_sh.setFormatter(logging.Formatter(LOG_FMT))
logger.addHandler(_sh)

SPARK_UPLOAD_ROOT = Path("/usr/local/spark/pvc/jars")
MAX_AGE_HOURS = 1
PREFIX = "spark-upload-"


def _build_log_file(dag_id: str, report_id: int, business_date: str) -> str:
    """Build a log filename that identifies this batch execution.

    Format: oracle_standalone_{dag_id}_{report_id}_{business_date}_{HHMMSS}.log
    Example: oracle_standalone_GMI_APAC_71_2025-07-10_143022.log

    2026-07-02 -- retention sweep BEFORE returning: prune old
    ``oracle_standalone_{dag}_{report}_*.log`` files in LOG_DIR so
    only the most-recent (keep-1) survive.  When the caller opens the
    new log via FileHandler right after, the directory ends up with
    exactly ``keep`` files per (dag, report) tuple.  User directive:
    "keep only last 2 run logs and delete old ones".  Fail-open.
    """
    # Sanitize dag_id for filesystem (replace slashes, spaces, etc.)
    safe_dag = dag_id.replace("/", "_").replace("\\", "_").replace(" ", "_")[:60]
    ts = datetime.now().strftime("%H%M%S")
    safe_date = str(business_date).replace("/", "-").replace(" ", "_")[:20]
    filename = f"oracle_standalone_{safe_dag}_{report_id}_{safe_date}_{ts}.log"
    log_path = os.path.join(LOG_DIR, filename)
    # Retention: keep 1 EXISTING file per (dag, report) tuple.  Called
    # BEFORE the new file is created via FileHandler, so 1 existing +
    # 1 new = 2 total after this run starts logging.
    try:
        from log_retention import prune_old_logs
        prune_old_logs(
            log_dir=LOG_DIR,
            prefix=f"oracle_standalone_{safe_dag}_{report_id}_",
            keep=1,
            logger=logger,
        )
    except Exception as exc:
        try:
            logger.warning("Log retention sweep failed (ignored): %s", exc)
        except Exception:
            pass
    return log_path


def _attach_file_handler(log_file: str) -> None:
    """Add file handler to the module logger after we know the batch context.

    2026-07-02 -- encoding='utf-8' is mandatory.  Without it Windows
    FileHandler defaults to cp1252 and any non-ASCII char in a log
    line (SAP payload, accent, degree sign, smart quote from Oracle
    output) crashes the whole run with UnicodeEncodeError.  Same fix
    already lives in sap_odata_base._setup_logging; not applying it
    here left the standalone-side handler vulnerable.
    """
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(logging.Formatter(LOG_FMT))
        logger.addHandler(fh)
        logger.info(f"Logging to: {log_file}")
    except OSError as e:
        logger.warning(f"Cannot create log file {log_file}: {e} — console only")


def cleanup_old_spark_uploads() -> None:
    """Delete old spark-upload-* directories older than MAX_AGE_HOURS."""
    cutoff_timestamp = time.time() - (MAX_AGE_HOURS * 3600)
    try:
        for item in SPARK_UPLOAD_ROOT.iterdir():
            if item.is_dir() and item.name.startswith(PREFIX):
                if item.stat().st_atime < cutoff_timestamp:
                    logger.info(f"Deleting: {item}")
                    try:
                        import shutil
                        shutil.rmtree(item)
                    except Exception as e:
                        logger.error(f"Failed to delete {item}: {e}")
    except Exception as e:
        logger.error(f"cleanup_old_spark_uploads failed with error: {str(e)}")


async def execute_tasks(
    tasks: List[Dict],
    config: Dict,
    worker_connection_string: str,
    dest_connection_string: str,
    log_file: str,
    run_report=None,
    artifacts=None,
) -> None:
    """
    Execute all Oracle task steps for a given RUN ID based on dynamic sequence.

    Tasks are ordered by SEQ from the polling query. Each row is one step
    (ClearStaging SEQ=1, StarburstToOracle SEQ=2, ProcessData SEQ=3, etc.).
    All tasks share the same Starburst connection config, so we create
    StarburstDataSource clients and OracleWorker ONCE for the entire run.

    2026-06-20 -- accepts optional ``run_report`` + ``artifacts`` from the
    StandaloneRunLifecycle so every step gets result.html + cleanup-on-
    failure visibility (parity with the file-flow pipeline).  Steps that
    don't know about these keys silently ignore them.
    """
    if not tasks or not worker_connection_string or not dest_connection_string:
        raise ValueError(
            "Tasks, worker_connection_string, and dest_connection_string are required"
        )

    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # Build Starburst clients ONCE — same config for every task in the run.
    # 2026-06-12 — routed through the shared loader so polling-row
    # columns AND configs/starburst_config.yaml AND STARBURST_* env
    # vars all flow through ONE fallback chain (identical to the
    # dispatcher path in polling_service.dispatcher).
    first_task = tasks[0]
    from starburst_config_loader import build_starburst_clients_from_row
    starburst_clients = build_starburst_clients_from_row(
        first_task, StarburstDataSource, logger=logger,
    )

    # Create OracleWorker ONCE — reused for all steps in this run
    worker = OracleWorker(starburst_clients, oracle_data_manager, logger)

    # 2026-06-26 -- release Spark right after the LAST Spark-using step
    # (StarburstToOracle_OnPrem for the oracle workflow).  Downstream
    # steps (CheckDataCompleteness, PostLoadProcess, SendEmail...) are
    # pure Oracle / pure Python so holding Spark executors+memory
    # through them is pure waste.  Pipeline-level finally in main() is
    # the idempotent backstop.
    from spark_lifecycle import install_pipeline_spark_release
    maybe_release_spark = install_pipeline_spark_release(tasks, logger)

    for i, task in enumerate(tasks):
        # Attach shared starburst_clients to each task dict (steps may read it)
        task["starburst_clients"] = starburst_clients
        # Single log file for entire batch execution
        task["log_file"] = log_file
        # 2026-06-20 -- thread the run-report + artifacts so steps that
        # know how to add_job_result / add_output_file / register
        # artifacts surface in result.html.
        if run_report is not None:
            task["_run_report"] = run_report
        if artifacts is not None:
            task["_run_artifacts"] = artifacts

        logger.info(
            f"Executing task {task.get('run_id')} with DAG_ID: {task.get('fk_dag_id')} "
            f"and FK_REPORT_ID: {task.get('fk_report_id')} for step {task.get('task_steps')} "
            f"(SEQ: {task.get('seq')})"
        )

        try:
            await worker.execute_step(
                task,
                worker_connection_string,
                dest_connection_string,
                task["task_steps"],
            )
        except Exception as e:
            logger.error(
                f"Step {task['task_steps']} for task {task['run_id']} failed: {str(e)}"
            )
            # 2026-06-20 -- propagate so the StandaloneRunLifecycle context
            # manager marks the run failed + sends the failure email +
            # runs cleanup_on_failure.  Pre-fix this swallowed the error
            # with `break` which left the run permanently in "START"
            # state on result.html.
            raise
        finally:
            # Fire on success AND on failure of the last Spark step --
            # we never want Spark to leak past the last step that
            # needed it.  No-op for non-Spark steps.
            maybe_release_spark(i)


async def main() -> None:
    """Main function to execute an Oracle task based on command-line arguments."""
    cleanup_old_spark_uploads()

    parser = argparse.ArgumentParser(
        description="Execute an Oracle task for a specific report ID and business date."
    )
    parser.add_argument(
        "--report_id", type=int, required=True,
        help="The report ID to process.",
    )
    parser.add_argument(
        "--business_date", type=str, required=True,
        help='The business date to process (e.g., "2025-07-10").',
    )
    parser.add_argument(
        "--dag_id", type=str, required=True,
        help="The DAG ID to process.",
    )
    parser.add_argument(
        "--config_path", type=str,
        default="/usr/local/spark/pvc/code/configs/oracle_config.yaml",
        help="Path to the configuration file.",
    )
    # 2026-06-21 -- preflight package check + auto-install (default ON).
    # Airflow SparkSubmit driver pod may not have all deps; auto-install
    # at startup unblocks the run.  --no-auto-install for strict mode.
    parser.add_argument("--no-auto-install", action="store_true",
                          help="Skip auto-install of missing REQUIRED packages")
    parser.add_argument("--no-install-optional", action="store_true",
                          help="Skip auto-install of OPTIONAL packages")

    # 2026-06-27 -- --machine / --vault-token-method (per-pod-env override
    # for qs_credentials).  See runtime_env.py for full docs.
    from runtime_env import add_runtime_env_args, apply_runtime_env_args
    add_runtime_env_args(parser)

    args = parser.parse_args()

    # Export --machine / --vault-token-method to env vars BEFORE any
    # downstream qs_credentials import fires.  Resolver reads them.
    apply_runtime_env_args(args, logger=logger)

    # 2026-06-21 -- preflight already ran at top-of-file bootstrap.
    # Honour CLI opt-outs for explicit re-check + report.
    if args.no_auto_install or args.no_install_optional:
        try:
            from preflight import preflight_check
            preflight_check(
                workflow="oracle",
                auto_install=not args.no_auto_install,
                install_optional=not args.no_install_optional,
            )
        except ImportError:
            pass

    # ── Build batch-specific log file after args are known ──
    log_file = _build_log_file(args.dag_id, args.report_id, args.business_date)
    _attach_file_handler(log_file)
    # 2026-07-02 -- pin the run-log path so any step that consults
    # ``log_config.get_run_log_file()`` / ``attach_step_logger``
    # fallback lands in THIS file rather than a per-step name.
    try:
        set_run_log_file(log_file)
    except Exception:
        pass
    # ContextVar-scoped so concurrent workflow runs in the same pod
    # don't overwrite each other's value.  Fallback via os.environ
    # kept for back-compat with pre-2026-07-02 step code.
    set_workflow_name("oracle_standalone")
    os.environ["ETL_WORKFLOW_NAME"] = "oracle_standalone"

    logger.info(
        f"Starting Oracle batch: dag_id={args.dag_id}, "
        f"report_id={args.report_id}, business_date={args.business_date}"
    )

    # Load configuration
    config_path = args.config_path
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    if not config or "oracle" not in config:
        raise ValueError("Invalid configuration file: missing 'oracle' section")

    # Load queries from YAML
    queries_path = "/usr/local/spark/pvc/code/configs/etl_polling_task_query.yaml"
    if not os.path.exists(queries_path):
        raise FileNotFoundError(f"Queries file not found: {queries_path}")

    with open(queries_path, "r") as qf:
        queries = yaml.safe_load(qf)

    if "polling_query_sb_to_oracle" not in queries:
        raise ValueError(
            "polling_query_sb_to_oracle not found in etl_polling_task_query.yaml"
        )

    # Establish database connections -- 2026-06-22 routes through the
    # loader so vault-based secret_ref resolution fires when
    # ETL_USE_VAULT=1 on the pod.  Literal yaml values still win.
    from oracle_config_loader import (
        resolve_etl_connection_string,
        resolve_dest_connection_string,
    )
    worker_connection_string = resolve_etl_connection_string(config)
    dest_connection_string = resolve_dest_connection_string(config)
    if not worker_connection_string or not dest_connection_string:
        raise ValueError(
            "Oracle connection strings unresolved.\n"
            f"  ETL  conn: {'OK' if worker_connection_string else 'MISSING'}\n"
            f"  DEST conn: {'OK' if dest_connection_string else 'MISSING'}\n"
            "Set yaml literals OR oracle.{etl,destination}.secret_ref "
            "(vault) OR ETL_ORACLE_CONN / DEST_ORACLE_CONN env vars."
        )

    # Fetch all tasks from database using OracleMetadataManager
    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    # execute_query_asynch returns a DataFrame — convert to list of dicts
    tasks_df = await oracle_data_manager.execute_query_asynch(
        queries["polling_query_sb_to_oracle"],
        {
            "1": args.report_id,
            "2": args.business_date,
            "3": args.dag_id,
        },
        worker_connection_string,
    )

    if tasks_df is None or tasks_df.empty:
        logger.info(
            f"No tasks found for report_id {args.report_id}, "
            f"business_date {args.business_date}, dag_id {args.dag_id}"
        )
        return

    # Convert DataFrame rows to list of dicts for downstream consumption
    tasks = tasks_df.to_dict(orient='records')

    # Normalize column names to lowercase for consistent access
    tasks = [{k.lower(): v for k, v in row.items()} for row in tasks]

    # Normalize tasks
    for task in tasks:
        task["task_id"] = task["run_id"]
        task["dag_run_id"] = f"run_{task['run_id']}"

    # 2026-06-20 -- StandaloneRunLifecycle gives this pipeline operator-
    # facing parity with the file flow: result.html, start/finish email,
    # cleanup-on-failure registry.  Activation is gated on polling-row
    # SEND_EMAIL / smtp config -- safe defaults so local dev never mails
    # prod accidentally.
    from standalone_lifecycle import StandaloneRunLifecycle
    # 2026-06-26 -- Spark teardown lifted from per-step finally blocks
    # to this pipeline-level finally.  See spark_lifecycle.py header.
    from spark_lifecycle import stop_active_spark_session
    try:
        async with StandaloneRunLifecycle(
            pipeline="oracle",
            dag_id=args.dag_id,
            report_id=args.report_id,
            business_date=args.business_date,
            log_file=log_file,
            config=config,
            sample=tasks[0],
            logger=logger,
        ) as lc:
            await execute_tasks(
                tasks, config, worker_connection_string, dest_connection_string,
                log_file, run_report=lc.run_report, artifacts=lc.artifacts,
            )
    finally:
        stop_active_spark_session(logger)


if __name__ == "__main__":
    asyncio.run(main())
