"""Per-RUN_ID dead-letter tracking.

Use case: a polling row that fails gets STATUS=FAILED in Oracle.  An
operator (or a scheduler) may reset it to STATUS=START to retry.  If
the underlying problem hasn't been fixed, the same row fails again.
Without a guard, the polling service will dispatch the same broken row
100 times in 100 cycles, burning Oracle slots + emitting log noise.

This module tracks per-RUN_ID consecutive failures in-process.  When a
RUN_ID has failed >= threshold times within ``window_seconds``, the
WorkflowRunner skips dispatch + logs a structured "dead-lettered"
message.  An alert fires the FIRST time a RUN_ID is dead-lettered so
ops know human intervention is needed.

Reset semantics:
  * Successful run → counter cleared for that RUN_ID
  * Entry expires after ``window_seconds`` since the last failure
  * pod restart → counter cleared (acceptable: pod restart = fresh start)
"""
from __future__ import annotations

import collections
import threading
import time
from typing import Dict, Optional, Tuple


class DeadLetterTracker:
    """In-memory per-RUN_ID failure counter with TTL eviction.

    Thread-safe.  Bounded by the eviction TTL (entries older than
    ``window_seconds`` are dropped on every record_*).
    """

    def __init__(
        self,
        threshold: int = 5,
        window_seconds: int = 3600,
    ) -> None:
        self.threshold = max(1, int(threshold))
        self.window_seconds = max(1, int(window_seconds))
        # 2026-07-01 hotfix-2 -- track LAST failure timestamp so the
        # rolling window is "N failures within window_seconds of the
        # LAST failure" not "N failures within window_seconds of the
        # FIRST failure ever".  Previous impl let a slowly-failing row
        # (fail every 55 min with 60-min window) evict at
        # first_failure+60min even though it had crossed threshold.
        # Value: (failure_count, first_failure_at, last_failure_at).
        self._counts: Dict[int, Tuple[int, float, float]] = {}
        self._lock = threading.Lock()
        # 2026-07-01 hotfix-2 -- separate "alerted" set so the
        # "one alert per RUN_ID" invariant survives snapshot restore.
        # Previous impl encoded the alerted bit into the count
        # (count == threshold means fresh, count > threshold means
        # already alerted); that state was LOST on restore because
        # the snapshot only stored the count as an integer.
        self._alerted: set = set()
        # Stats
        self._dead_letters_emitted = 0

    # ── recording ──────────────────────────────────────────────────────

    def record_failure(self, run_id: int) -> int:
        """Increment failure counter for the given RUN_ID.  Returns the
        new count.  Evicts stale entries on the way."""
        now = time.time()
        with self._lock:
            self._evict_stale(now)
            entry = self._counts.get(run_id)
            if entry is None:
                count, first, last = 0, now, now
            else:
                count, first, last = entry
            count += 1
            self._counts[run_id] = (count, first, now)
            return count

    def record_success(self, run_id: int) -> None:
        """Clear failure counter for the RUN_ID — the row has recovered."""
        with self._lock:
            self._counts.pop(run_id, None)
            self._alerted.discard(int(run_id))

    def reset(self, run_id: int) -> None:
        """Explicit reset (e.g. operator override).  Same as record_success."""
        self.record_success(run_id)

    # ── querying ───────────────────────────────────────────────────────

    def is_dead_lettered(self, run_id: int) -> bool:
        """True when the RUN_ID has failed >= threshold times within
        the window — dispatch should be skipped."""
        now = time.time()
        with self._lock:
            self._evict_stale(now)
            entry = self._counts.get(run_id)
            if entry is None:
                return False
            count, _first, _last = entry
            return count >= self.threshold

    def failure_count(self, run_id: int) -> int:
        """Current failure count for inspection / logging."""
        with self._lock:
            entry = self._counts.get(run_id)
            return entry[0] if entry else 0

    # ── stats ──────────────────────────────────────────────────────────

    def emit_dead_letter(self, run_id: int) -> bool:
        """Mark that a dead-letter was emitted for this RUN_ID.  Returns
        True the FIRST time (so the runner can emit a one-shot alert)
        and False on subsequent dispatch-skips of the same RUN_ID.

        2026-07-01 note (documented limitation) -- this tracker is
        PROCESS-LOCAL.  If two polling pods are both running (rolling
        upgrade window, HA deploy), EACH will emit a dead-letter alert
        for the same RUN_ID because they don't share state.  Cross-pod
        dedup requires an external store (Oracle table, Redis) which
        is a larger design change.  In practice the throttle at the
        alerter layer collapses the duplicate emails within the
        ``cooldown_seconds`` window (default 5 min), so operators
        typically see ONE email per RUN_ID even in the multi-pod case.
        """
        with self._lock:
            entry = self._counts.get(run_id)
            if entry is None:
                return False
            count, _first, _last = entry
            if count < self.threshold:
                return False
            # 2026-07-01 hotfix-2 -- explicit alerted set survives
            # snapshot restore (previous impl encoded the bit into
            # the count, which was lost the moment the tracker was
            # rebuilt from persisted state).
            key = int(run_id)
            if key in self._alerted:
                return False
            self._alerted.add(key)
            self._dead_letters_emitted += 1
            return True

    def snapshot(self) -> Dict[str, object]:
        with self._lock:
            now = time.time()
            self._evict_stale(now)
            return {
                "threshold":            self.threshold,
                "window_seconds":       self.window_seconds,
                "tracked_run_ids":      len(self._counts),
                "dead_letters_emitted": self._dead_letters_emitted,
                "alerted_run_ids":      len(self._alerted),
                "currently_blocked": [
                    {
                        "run_id": rid,
                        "count":  c,
                        "first_failure_age_s": round(now - first, 1),
                        "last_failure_age_s":  round(now - last, 1),
                        "alerted":  rid in self._alerted,
                    }
                    for rid, (c, first, last) in self._counts.items()
                    if c >= self.threshold
                ],
            }

    # ── internals ──────────────────────────────────────────────────────

    def _evict_stale(self, now: float) -> None:
        """Evict entries whose LAST failure fell outside the rolling
        window.  2026-07-01 hotfix-2 -- was ``first < cutoff`` which
        meant a slowly-failing row (fails every ``window - 1s``)
        expired at ``first + window`` even though it crossed
        threshold; the entry disappeared and the alerter's dead-letter
        was silently un-fired.  Rolling-from-last matches operator
        intuition: 'N failures within any window'."""
        cutoff = now - self.window_seconds
        stale = [
            rid for rid, (_c, _first, last) in self._counts.items()
            if last < cutoff
        ]
        for rid in stale:
            self._counts.pop(rid, None)
            self._alerted.discard(rid)


# ── module-level singleton ──────────────────────────────────────────────


_singleton: Optional[DeadLetterTracker] = None
_singleton_lock = threading.Lock()


def get_tracker() -> DeadLetterTracker:
    """Process-wide DeadLetterTracker, lazily constructed."""
    global _singleton
    if _singleton is None:
        with _singleton_lock:
            if _singleton is None:
                import os
                threshold = int(os.environ.get("BG_DEAD_LETTER_THRESHOLD", "5") or 5)
                window = int(os.environ.get("BG_DEAD_LETTER_WINDOW_S", "3600") or 3600)
                _singleton = DeadLetterTracker(threshold=threshold, window_seconds=window)
    return _singleton


def reset_tracker() -> None:
    """Test hook — drop the singleton."""
    global _singleton
    with _singleton_lock:
        _singleton = None
