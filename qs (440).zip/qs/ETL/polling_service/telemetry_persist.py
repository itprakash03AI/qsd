"""Lightweight telemetry persistence for the polling service.

Why: telemetry + alerter sliding windows live in-process; pod restart
zeros them.  A failure spike spanning a restart becomes invisible to
the high_failure_rate trigger.  This module snapshots the registry's
telemetry to a JSON file on the writable cache PVC every N seconds.
On startup, it restores counters so the alerter has continuity.

Why not Prometheus push gateway / SQLite / Redis:
  * Prometheus already scrapes /metrics; this exists for the in-process
    alerter sliding-window continuity, not external metric persistence.
  * SQLite/Redis add a runtime dependency the polling image doesn't need.
  * JSON on PVC: zero deps, atomic write via os.replace, single-line
    schema; rotates as part of the existing log retention.

Schema (versioned for forward compat):
  {
    "schema_version": 1,
    "saved_at_utc":   "2026-06-29T14:32:18Z",
    "worker_id":      "bg_poller_1",
    "telemetry": {
      "oracle": {dispatched: 47, completed: 45, failed: 2, ...},
      "sap_odata": {...},
      ...
    },
    "dead_letter": {tracked_run_ids: [...], counts: {...}}
  }

Snapshots are RESTORED additively (not authoritative) — current pod's
in-process counters take precedence; the snapshot only fills zeroed
fields.  This is the "give the alerter continuity" mode, not the
"replicate state perfectly across restarts" mode.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


logger = logging.getLogger("bg_poller.telemetry_persist")


SCHEMA_VERSION = 1


def _utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def write_snapshot(path: str, worker_id: str = "") -> bool:
    """Snapshot the live registry telemetry to ``path`` (atomic write
    via ``os.replace``).  Returns True on success.  Failures are
    logged + non-fatal — telemetry persistence is best-effort."""
    try:
        from polling_service.workflow_registry import get_registry
        reg = get_registry()
        telem = {
            name: t.snapshot()
            for name, t in reg.all_telemetry().items()
        }
    except Exception as exc:
        logger.warning("Could not gather registry telemetry: %s", exc)
        return False

    try:
        from polling_service.dead_letter import get_tracker
        dl_snap = get_tracker().snapshot()
    except Exception:
        dl_snap = {}

    payload = {
        "schema_version": SCHEMA_VERSION,
        "saved_at_utc":   _utc_iso(),
        "worker_id":      worker_id,
        "telemetry":      telem,
        "dead_letter":    dl_snap,
    }

    try:
        dir_path = os.path.dirname(path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)
        # Atomic write WITHOUT tempfile (banned in runtime modules by
        # tests/test_no_tmp_fallback.py).  Write to a sibling .tmp-<uuid>
        # in the same directory, then os.replace to the final path.
        tmp_path = os.path.join(
            dir_path or ".",
            f".tmp-telem-{uuid.uuid4().hex}.json",
        )
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, separators=(",", ":"), default=str)
        os.replace(tmp_path, path)
        return True
    except OSError as exc:
        logger.warning("Telemetry snapshot write failed (%s): %s", path, exc)
        return False


def read_snapshot(path: str) -> Optional[Dict[str, Any]]:
    """Read + parse a snapshot file.  Returns None when missing /
    malformed / wrong schema_version.  Caller treats None as "no
    snapshot to restore"."""
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
    except (OSError, ValueError) as exc:
        logger.warning("Telemetry snapshot read failed (%s): %s", path, exc)
        return None

    if not isinstance(payload, dict):
        logger.warning("Telemetry snapshot at %s is not a dict — ignoring", path)
        return None
    sv = payload.get("schema_version")
    if sv != SCHEMA_VERSION:
        logger.info(
            "Telemetry snapshot at %s schema_version=%s != %s — skipping restore",
            path, sv, SCHEMA_VERSION,
        )
        return None
    return payload


# 2026-07-01 hotfix-2 -- snapshot-restore guardrails.
#   * worker_id mismatch      -> refuse (cross-pod poisoning)
#   * age > MAX_AGE_S         -> refuse (stale snapshot from stopped pod)
#   * per-field cap           -> refuse absurd counters (poisoned file)
_MAX_SNAPSHOT_AGE_S = 30 * 60                # 30 min -- pod restart budget
_MAX_COUNTER_VALUE  = 10 ** 8                # 100 M dispatches -- >> realistic


def restore_snapshot(
    path: str,
    expected_worker_id: str = "",
    max_age_s: int = _MAX_SNAPSHOT_AGE_S,
) -> Dict[str, Any]:
    """Restore telemetry counters into the live registry from a snapshot.

    Restore semantics:
      * Live counters that are ZERO are filled from the snapshot.
      * Live counters that are NON-zero (this pod already dispatched
        something) WIN — the snapshot is a hint, not authority.
      * Snapshot fields the live PluginTelemetry doesn't know about
        are silently ignored (forward-compat).

    Guardrails (2026-07-01 hotfix-2):
      * ``expected_worker_id`` — when set, reject snapshots whose
        ``worker_id`` differs.  Prevents cross-pod counter poisoning
        (operator copies bg_poller_1.json onto a fresh dev pod).
      * ``max_age_s`` — reject snapshots older than N seconds.
        Prevents "dead pod resurrected" resurrection of obsolete
        counters that would immediately trip the alerter's sliding
        window.
      * Per-field cap at ``_MAX_COUNTER_VALUE``.  A poisoned file with
        ``dispatched=10^18`` would silently break the alerter.

    Returns a diagnostic dict (counts restored, age of snapshot,
    optional ``reason`` when refused).
    """
    payload = read_snapshot(path)
    if payload is None:
        return {"restored": 0, "reason": "no snapshot"}

    # Guardrail 1: worker_id match.
    snap_worker_id = (payload.get("worker_id") or "").strip()
    if expected_worker_id and snap_worker_id and snap_worker_id != expected_worker_id:
        logger.warning(
            "Telemetry snapshot at %s belongs to worker_id=%r; this "
            "pod is %r -- refusing to restore (cross-pod poisoning "
            "guard).",
            path, snap_worker_id, expected_worker_id,
        )
        return {
            "restored": 0,
            "reason": "worker_id mismatch",
            "snapshot_worker_id": snap_worker_id,
            "expected_worker_id": expected_worker_id,
        }

    # Guardrail 2: age cap.
    age_s = _safe_snapshot_age(payload.get("saved_at_utc"))
    if age_s is not None and age_s > max_age_s:
        logger.warning(
            "Telemetry snapshot at %s is %ds old (cap=%ds) -- "
            "refusing to restore (stale-snapshot guard).",
            path, age_s, max_age_s,
        )
        return {
            "restored": 0,
            "reason": "snapshot too old",
            "snapshot_age_s": age_s,
            "max_age_s": max_age_s,
        }

    try:
        from polling_service.workflow_registry import get_registry
        reg = get_registry()
    except Exception as exc:
        return {"restored": 0, "reason": f"registry unavailable: {exc}"}

    def _cap(v) -> int:
        try:
            n = int(v)
        except (TypeError, ValueError):
            return 0
        if n < 0:
            return 0
        if n > _MAX_COUNTER_VALUE:
            return _MAX_COUNTER_VALUE
        return n

    restored = 0
    for plugin_name, snap in (payload.get("telemetry") or {}).items():
        t = reg.get_telemetry(plugin_name)
        if t is None:
            continue
        # 2026-07-01 hotfix-2 -- check t.dispatched == 0 UNDER the
        # lock (was outside; TOCTOU race with concurrent dispatch).
        with t._lock:
            if t.dispatched != 0:
                continue
            if not _cap(snap.get("dispatched", 0)):
                continue
            # Fresh pod, valid snapshot -- restore per-field capped.
            t.dispatched           = _cap(snap.get("dispatched", 0))
            t.completed            = _cap(snap.get("completed", 0))
            t.failed               = _cap(snap.get("failed", 0))
            t.timed_out            = _cap(snap.get("timed_out", 0))
            t.cancelled            = _cap(snap.get("cancelled", 0))
            t.skipped_cross_pod    = _cap(snap.get("skipped_cross_pod", 0))
            t.skipped_at_capacity  = _cap(snap.get("skipped_at_capacity", 0))
            t.last_dispatch_at     = snap.get("last_dispatch_at") or t.last_dispatch_at
            t.last_success_at      = snap.get("last_success_at")  or t.last_success_at
            t.last_failure_at      = snap.get("last_failure_at")  or t.last_failure_at
            t.last_failure_reason  = snap.get("last_failure_reason") or t.last_failure_reason
        restored += 1

    return {
        "restored":       restored,
        "snapshot_age_s": age_s,
        "worker_id":      snap_worker_id,
    }


def _safe_snapshot_age(saved_at_utc) -> Optional[int]:
    """Parse a saved_at_utc timestamp defensively.

    2026-07-01 hygiene -- the previous inline expression tried
    ``payload["saved_at_utc"].replace("Z", "+00:00")`` guarded by a
    truthy check.  An empty string would pass the truthy guard but
    fail ``fromisoformat``; a non-string truthy value would raise
    AttributeError on ``.replace``.  Any of these silently returned
    None via the caller's outer expression -- but ONLY because
    Python let the malformed string bubble past ``.replace`` to
    ``fromisoformat`` where the ValueError could surface.  Wrap in
    a try/except that returns None on any failure.
    """
    if not saved_at_utc:
        return None
    try:
        parsed = datetime.fromisoformat(str(saved_at_utc).replace("Z", "+00:00"))
        return int(time.time() - parsed.timestamp())
    except (ValueError, TypeError, AttributeError):
        return None


# ── periodic-snapshot daemon ────────────────────────────────────────────


class PersistenceDaemon:
    """Background thread that writes a snapshot every ``interval_s``.

    Lifetime: started by main.py after registry init; stopped via
    ``stop()`` from the shutdown path.  Idempotent.
    """

    def __init__(
        self,
        path: str,
        worker_id: str = "",
        interval_s: int = 60,
    ) -> None:
        self.path = path
        self.worker_id = worker_id
        self.interval_s = max(5, int(interval_s))
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        # 2026-07-01 -- sweep stale .tmp-telem-* siblings before
        # starting.  If a previous pod crashed mid-atomic-write, the
        # ``.tmp-telem-<uuid>.json`` files never got renamed and pile
        # up on the PVC forever.  On a small volume (128 MB
        # emptyDir isn't unusual for /var/cache mounts) this fills
        # disk after a few crash-loops.  Bounded work: only scans
        # the ONE directory the daemon writes to.
        self._sweep_stale_tmp_files()
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop,
            daemon=True,
            name="telemetry-persist",
        )
        self._thread.start()
        logger.info(
            "Telemetry persistence daemon started: path=%s interval=%ds",
            self.path, self.interval_s,
        )

    def _sweep_stale_tmp_files(self) -> None:
        """Delete leftover ``.tmp-telem-*.json`` files in the target
        directory.  Best-effort: any error is swallowed so a
        permission blip doesn't block daemon start."""
        try:
            dir_path = os.path.dirname(self.path) or "."
            if not os.path.isdir(dir_path):
                return
            _removed = 0
            for entry in os.listdir(dir_path):
                if entry.startswith(".tmp-telem-") and entry.endswith(".json"):
                    try:
                        os.remove(os.path.join(dir_path, entry))
                        _removed += 1
                    except OSError:
                        pass
            if _removed:
                logger.info(
                    "Telemetry persistence: swept %d stale .tmp-telem-* "
                    "file(s) from %s at daemon start",
                    _removed, dir_path,
                )
        except Exception as exc:                                # pragma: no cover
            logger.debug(
                "Telemetry persistence: sweep of %s failed: %s",
                self.path, exc,
            )

    def stop(self, join_timeout_s: float = 2.0) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=join_timeout_s)

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                write_snapshot(self.path, worker_id=self.worker_id)
            except Exception as exc:
                logger.warning("Telemetry persist loop iteration failed: %s", exc)
            self._stop.wait(self.interval_s)
