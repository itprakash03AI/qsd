"""
WorkflowRunner — per-workflow capacity gate + dispatcher.

2026-06-12 (revised) — single-query + Python routing design.

Each ``WorkflowRunner`` owns:
  - The workflow's concurrency cap, stats, active_runs dict, pause flag.
  - The cross-pod DBMS_LOCK claim before each dispatch.
  - The per-run timeout + STATUS-flip-on-timeout semantics.

What the runner does NOT own (vs the previous per-runner-polling design):
  - It has NO polling query.
  - It has NO poll loop.
  - It has NO interval.

The ``BackgroundService`` owns ONE polling loop, polls the single
shared ``bg_polling_query`` once per cycle, infers each row's dag_type
via ``polling_service.poller._infer_dag_type`` (the canonical mapping)
and calls ``runner.try_dispatch(run_id, tasks, claimer_id, etl_conn_str)``.

Why single-query routing:
  * One mapping place — no more N polling queries duplicating the
    OTG_DAG_ID→workflow logic (was leaking into etl_polling_task_query.yaml
    `bg_polling_query_<wf>` discriminators).
  * No discriminator drift — adding a new workflow no longer requires
    editing createJob's `NOT LIKE` exclusion list.
  * One Oracle round-trip per service tick — not N.
  * Per-workflow concurrency caps + stats preserved (each runner owns
    its slot pool — a SAP backlog still can't starve createJob).
"""
from __future__ import annotations

import asyncio
import logging
import socket
import time
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from polling_service.config import WorkflowConfig
    from polling_service.dispatcher import Dispatcher
    from managers.oracle_metadata_manager import OracleMetadataManager


class WorkflowRunner:
    """Per-workflow capacity gate + dispatcher.

    Lifecycle is purely reactive — the BackgroundService drives it via
    ``try_dispatch``.  No background asyncio.Task for the runner itself;
    only the ``_execute_run`` Tasks for each in-flight RUN_ID.
    """

    def __init__(
        self,
        workflow: "WorkflowConfig",
        etl_connection_string: str,
        dest_connection_string: str,
        oracle_manager: "OracleMetadataManager",
        dispatcher: "Dispatcher",
        logger: logging.Logger,
    ) -> None:
        self.workflow = workflow
        self.etl_connection_string = etl_connection_string
        self.dest_connection_string = dest_connection_string
        self.oracle_manager = oracle_manager
        self.dispatcher = dispatcher
        # Child logger tagged with the workflow name so multi-runner
        # log lines are filterable: ``[wf=sap_odata] ...``.
        self.logger = logger.getChild(f"wf.{workflow.name}")

        self.active_runs: Dict[int, asyncio.Task] = {}
        self.paused = False
        self.stats: Dict[str, int] = {
            "dispatched": 0,
            "completed": 0,
            "failed": 0,
            "skipped_cross_pod": 0,
            "timed_out": 0,
            "skipped_at_capacity": 0,
        }
        # 2026-06-29 — enterprise telemetry from the registry.  Each
        # dispatch / completion / failure / timeout updates the per-plugin
        # PluginTelemetry instance which is exposed via /workflows/<name>
        # health endpoint + (future) Prometheus metrics.
        self.telemetry = None
        try:
            from polling_service.workflow_registry import get_registry
            self.telemetry = get_registry().get_telemetry(workflow.name)
        except Exception as exc:
            self.logger.debug(
                "[wf=%s] telemetry unavailable (%s) — runner will work but "
                "/workflows/<name> will show empty telemetry", workflow.name, exc,
            )
        try:
            import os as _os
            self._claimer_id_suffix = f":{workflow.name}:{_os.getpid()}"
        except Exception:
            self._claimer_id_suffix = f":{workflow.name}"

    # ── operator control ─────────────────────────────────────────────

    def pause(self) -> None:
        self.paused = True
        self.logger.info(f"[wf={self.workflow.name}] paused")

    def resume(self) -> None:
        self.paused = False
        self.logger.info(f"[wf={self.workflow.name}] resumed")

    # ── cross-thread Starburst cancellation ──────────────────────────

    def _cancel_starburst_for_tasks(self, tasks: list) -> None:
        """Fire ``cancel_all_starburst`` on each task in the run.

        Called from the TimeoutError + CancelledError branches of
        ``_execute_run`` so the Starburst coordinator is told to stop
        the query at the same moment we give up locally.  Safe to call
        even when no step has registered a cancellable yet (e.g. a
        non-Starburst step in the workflow) — empty registry is a
        no-op inside ``cancel_all_starburst``.
        """
        try:
            from starburst_cancellation import cancel_all_starburst
        except Exception as exc:
            self.logger.warning(
                "[wf=%s] starburst_cancellation unavailable (%s) — "
                "in-flight Starburst queries will continue on the server",
                self.workflow.name, exc,
            )
            return
        for task in tasks or ():
            try:
                cancel_all_starburst(task, logger=self.logger)
            except Exception as exc:
                self.logger.warning(
                    "[wf=%s] cancel_all_starburst raised: %s",
                    self.workflow.name, exc,
                )

    # ── snapshot for /status endpoint ────────────────────────────────

    def snapshot(self) -> Dict[str, Any]:
        wf = self.workflow
        return {
            "name": wf.name,
            "enabled": wf.enabled,
            "paused": self.paused,
            "active_runs": len(self.active_runs),
            "active_run_ids": list(self.active_runs.keys()),
            "max_concurrent_runs": wf.max_concurrent_runs,
            "stats": dict(self.stats),
        }

    # ── public dispatch entry point ──────────────────────────────────

    async def try_dispatch(
        self,
        run_id: int,
        tasks: list,
        claimer_id_prefix: str,
        etl_connection_string: str,
    ) -> str:
        """Attempt to dispatch one RUN_ID.

        Returns a status string for the BackgroundService's poll-cycle
        log line:
          ``"dispatched"`` — new asyncio.Task created
          ``"already_active"`` — already running in this pod
          ``"paused"`` — runner is paused
          ``"at_capacity"`` — runner slot pool full
          ``"cross_pod"`` — another pod already claimed it

        Cross-pod claim semantics + per-run timeout + finally-cleanup
        match BackgroundPoller 1:1 (BF-595 contract preserved).
        """
        wf = self.workflow

        if run_id in self.active_runs:
            return "already_active"
        if self.paused:
            return "paused"
        if len(self.active_runs) >= wf.max_concurrent_runs:
            self.stats["skipped_at_capacity"] += 1
            if self.telemetry is not None:
                self.telemetry.record_capacity_skip()
            return "at_capacity"
        # Dead-letter check — skip rows that have failed too many times in
        # the recent window.  Operators must reset the row OR fix the
        # underlying problem before it dispatches again.  See
        # polling_service/dead_letter.py for the threshold + window env vars.
        try:
            from polling_service.dead_letter import get_tracker
            dl = get_tracker()
            if dl.is_dead_lettered(int(run_id)):
                fail_count = dl.failure_count(int(run_id))
                first_alert = dl.emit_dead_letter(int(run_id))
                self.logger.warning(
                    f"[wf={wf.name}] run_id={run_id} DEAD-LETTERED "
                    f"(failure_count={fail_count}, threshold={dl.threshold}, "
                    f"window={dl.window_seconds}s) — skipping dispatch.  "
                    f"Reset via DB OR fix the root cause."
                )
                if first_alert:
                    try:
                        from polling_service.alerter import AlertEvent, get_alerter
                        get_alerter().alert(AlertEvent(
                            trigger="dead_letter",
                            plugin=wf.name,
                            severity="ERROR",
                            message=(
                                f"run_id={run_id} dead-lettered after "
                                f"{fail_count} consecutive failures in "
                                f"{dl.window_seconds}s window — dispatch skipped"
                            ),
                            details={"run_id": str(run_id),
                                     "failure_count": str(fail_count),
                                     "threshold": str(dl.threshold)},
                        ))
                    except Exception:
                        pass
                return "dead_lettered"
        except Exception:
            pass    # tracker must NEVER break the dispatch path

        claimer_id = f"{claimer_id_prefix}{self._claimer_id_suffix}"
        try:
            claimed = await self.oracle_manager.try_claim_run(
                int(run_id), claimer_id, etl_connection_string,
            )
        except Exception as claim_exc:
            self.logger.warning(
                f"[wf={wf.name}] run_id={run_id} try_claim_run raised "
                f"{claim_exc!r} — proceeding without claim (degraded "
                f"cross-pod safety)"
            )
            claimed = True
            # Record degradation for alerter — auto-emits cross_pod_degraded
            # after N consecutive fail-opens.  Wrapped so any alerter glitch
            # never blocks dispatch.
            try:
                from polling_service.alerter import get_alerter
                get_alerter().record_cross_pod_degradation(
                    reason=f"try_claim_run({run_id}): {type(claim_exc).__name__}: {claim_exc}",
                )
            except Exception:
                pass
        if not claimed:
            self.stats["skipped_cross_pod"] += 1
            if self.telemetry is not None:
                self.telemetry.record_cross_pod_skip()
            self.logger.info(
                f"[wf={wf.name}] run_id={run_id} claimed by another pod"
            )
            return "cross_pod"

        self.stats["dispatched"] += 1
        if self.telemetry is not None:
            self.telemetry.record_dispatch()
        self.logger.info(
            f"[wf={wf.name}] dispatching run_id={run_id} steps={len(tasks)} "
            f"({len(self.active_runs) + 1}/{wf.max_concurrent_runs} slots)"
        )
        task = asyncio.create_task(
            self._execute_run(int(run_id), tasks),
            name=f"wf_{wf.name}_run_{run_id}",
        )
        self.active_runs[int(run_id)] = task
        return "dispatched"

    # ── per-run execution ────────────────────────────────────────────

    async def _execute_run(self, run_id: int, tasks: list) -> None:
        """Execute one RUN_ID via the shared dispatcher, with per-run timeout.

        Mirrors the original implementation — same Cancel / Timeout /
        Exception handling, same STATUS-flip on timeout, same finally
        cleanup.  AUDIT-3 CancelledError log line retained.
        """
        wf = self.workflow
        max_secs = int(wf.max_run_seconds)
        t0 = time.monotonic()
        try:
            coro = self.dispatcher.execute(
                run_id,
                tasks,
                wf.name,  # dag_type for WORKER_REGISTRY lookup
                self.etl_connection_string,
                self.dest_connection_string,
            )
            if max_secs > 0:
                await asyncio.wait_for(coro, timeout=max_secs)
            else:
                await coro
            self.stats["completed"] += 1
            duration_s = time.monotonic() - t0
            if self.telemetry is not None:
                self.telemetry.record_success(duration_s=duration_s)
            # Feed the alerter's sliding window — auto-emits high_failure_rate
            # if the recent window dips below the threshold.
            try:
                from polling_service.alerter import get_alerter
                get_alerter().record_outcome(wf.name, success=True)
            except Exception:
                pass    # alerter must NEVER break the dispatch path
            # Clear dead-letter counter on success — row recovered.
            try:
                from polling_service.dead_letter import get_tracker
                get_tracker().record_success(int(run_id))
            except Exception:
                pass
            self.logger.info(
                f"[wf={wf.name}] run_id={run_id} completed successfully "
                f"in {duration_s:.1f}s"
            )
        except asyncio.TimeoutError:
            self.stats["timed_out"] += 1
            duration_s = time.monotonic() - t0
            if self.telemetry is not None:
                self.telemetry.record_timeout(duration_s=duration_s)
            self.logger.error(
                f"[wf={wf.name}] run_id={run_id} TIMED OUT after {max_secs}s — "
                f"cancelling and flipping STATUS=FAILED"
            )
            # 2026-06-12 — propagate cancel to Starburst BEFORE we move
            # on.  Without this the query keeps running server-side
            # after we've given up, holding coordinator slots.
            self._cancel_starburst_for_tasks(tasks)
            first_task = tasks[0] if tasks else {}
            try:
                await self.oracle_manager.update_otg_etl_batch_status(
                    int(run_id),
                    int(first_task.get("run_detail_id", 0)),
                    "FAILED",
                    str(first_task.get("task_steps", "TIMEOUT")),
                    # 2026-07-01 fix (item #14) -- was ``0`` here which
                    # overwrote the actual row count in Oracle when a
                    # long-running dispatch timed out.  Downstream
                    # reports then showed 0 rows for what was actually
                    # a partially-completed job.  Pass None so the
                    # ETL_Batch_UPDATE proc keeps the previously
                    # recorded record count.
                    None,
                    f"workflow={wf.name} timeout: run exceeded {max_secs}s",
                    self.etl_connection_string,
                )
            except Exception as flip_exc:
                self.logger.warning(
                    f"[wf={wf.name}] run_id={run_id}: status-flip-to-FAILED "
                    f"after timeout raised {flip_exc!r}"
                )
        except asyncio.CancelledError:
            duration_s = time.monotonic() - t0
            if self.telemetry is not None:
                self.telemetry.record_cancelled()
            self.logger.warning(
                f"[wf={wf.name}] run_id={run_id} CANCELLED after {duration_s:.1f}s "
                f"(external) — flipping STATUS back to START so the next pod "
                f"cycle can retry.  Cross-pod DBMS_LOCK will also be released."
            )
            # Same Starburst cancel on external cancel (shutdown drain).
            self._cancel_starburst_for_tasks(tasks)
            # 2026-07-01 fix (item #6) -- release the DBMS_LOCK
            # explicitly + flip STATUS back to START so the row is
            # recoverable on the next poll cycle instead of stranded
            # in INPROGRESS with the lock silently held.  Both calls
            # are best-effort: if either fails the row still becomes
            # eligible for the natural session-end lock release, but
            # that requires the pod to actually die.  Under a plain
            # drain-in-place (SIGTERM during rolling upgrade) the
            # session survives -> lock stays held forever without
            # this cleanup.
            try:
                await self.oracle_manager.release_run_claim(
                    int(run_id),
                    self.etl_connection_string,
                )
            except Exception as _release_exc:
                self.logger.warning(
                    f"[wf={wf.name}] run_id={run_id}: DBMS_LOCK release "
                    f"failed on external cancel: {_release_exc!r} -- "
                    f"row will only be recoverable after pod restart."
                )
            try:
                first_task = tasks[0] if tasks else {}
                await self.oracle_manager.update_otg_etl_batch_status(
                    int(run_id),
                    int(first_task.get("run_detail_id", 0)),
                    "START",   # flip back so next cycle picks it up
                    str(first_task.get("task_steps", "CANCELLED")),
                    None,      # DO NOT overwrite total_record on cancel
                    f"workflow={wf.name} externally cancelled after "
                    f"{duration_s:.1f}s (retry on next cycle)",
                    self.etl_connection_string,
                )
            except Exception as _flip_exc:
                self.logger.warning(
                    f"[wf={wf.name}] run_id={run_id}: STATUS flip-to-START "
                    f"after cancel raised {_flip_exc!r} -- row is stranded "
                    f"in INPROGRESS until ops intervenes."
                )
            raise
        except Exception as exc:
            self.stats["failed"] += 1
            duration_s = time.monotonic() - t0
            if self.telemetry is not None:
                self.telemetry.record_failure(
                    reason=f"{type(exc).__name__}: {exc}",
                    duration_s=duration_s,
                )
            # Feed alerter — high_failure_rate auto-fires when threshold
            # exceeded.  Wrapped so alerter bugs never mask the real error.
            try:
                from polling_service.alerter import get_alerter
                get_alerter().record_outcome(wf.name, success=False)
            except Exception:
                pass
            # Bump dead-letter counter; threshold breach blocks future
            # dispatches of this RUN_ID until the operator resets.
            try:
                from polling_service.dead_letter import get_tracker
                get_tracker().record_failure(int(run_id))
            except Exception:
                pass
            self.logger.error(
                f"[wf={wf.name}] run_id={run_id} failed after {duration_s:.1f}s: {exc}",
                exc_info=True,
            )
        finally:
            self.active_runs.pop(int(run_id), None)
