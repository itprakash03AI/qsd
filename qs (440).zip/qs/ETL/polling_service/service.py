"""
BackgroundService — single polling loop + per-workflow runners.

2026-06-12 (revised) — strategic redesign around single-query + Python
routing.

ARCHITECTURE:

  Oracle (Vw_otg_dag_task)
        │
        │ bg_polling_query (one shared SQL, no per-workflow predicate)
        ▼
  BackgroundService._poll_once
        │ group rows by RUN_ID
        │ infer dag_type via polling_service.poller._infer_dag_type
        │   (the canonical OTG_DAG_ID → workflow mapping)
        ▼
  WorkflowRunner.try_dispatch(run_id, tasks, claimer_id, etl_conn_str)
        │ capacity check + cross-pod claim + per-run timeout
        ▼
  Dispatcher.execute(run_id, tasks, dag_type, ...)
        │ load step_mapping section, build worker, execute steps
        ▼
  Step.execute(task, ...)

WHY single-query + routing (vs the per-workflow polling queries of
the previous iteration):
  * ONE place owns the OTG_DAG_ID → workflow mapping (_infer_dag_type).
    The per-workflow polling SQLs had brittle negative discriminators
    on createJob (NOT LIKE %SAP% AND NOT LIKE %FILE% AND ...) that
    drifted any time a new workflow was added.
  * One Oracle round-trip per cycle (was N).
  * Each WorkflowRunner still owns its concurrency cap, stats, pause
    flag — a SAP backlog still can't starve createJob slots.

What is shared:
  * One ``OracleMetadataManager`` (poll + cross-pod claim).
  * One ``Dispatcher`` (the lightweight-vs-Spark image flag is
    service-level via cfg.use_lightweight_steps; per-workflow lightweight
    typing is explicitly rejected — OG DB stays agnostic).
  * One asyncio default-executor (bounded thread pool wired in main.py).
  * One log root + per-runner ``wf.<name>`` child loggers.
"""
from __future__ import annotations

import asyncio
import importlib
import logging
import os
import socket
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple

from polling_service.dispatcher import Dispatcher, WORKER_REGISTRY
from polling_service.poller import _infer_dag_type
from polling_service.workflow_runner import WorkflowRunner

if TYPE_CHECKING:
    from polling_service.config import PollingServiceConfig, WorkflowConfig
    from managers.oracle_metadata_manager import OracleMetadataManager


class BackgroundService:
    """Single polling loop; one ``WorkflowRunner`` per enabled workflow.

    Lifecycle:
      __init__   -> build runners + shared Dispatcher (no IO yet)
      start()    -> spawn ONE poll task; wait_for_stop() unblocks on stop()
      stop()     -> sets stop_event, signals every runner.pause-equivalent
      shutdown() -> drain in-flight RUN_ID tasks across runners up to
                    shutdown_timeout, then cancel stragglers
    """

    def __init__(
        self,
        config: "PollingServiceConfig",
        oracle_manager: "OracleMetadataManager",
        logger: logging.Logger,
    ) -> None:
        self.config = config
        self.oracle_manager = oracle_manager
        self.logger = logger
        self.runners: List[WorkflowRunner] = []
        self._poll_task: Optional[asyncio.Task] = None
        self._stopped_event: Optional[asyncio.Event] = None
        # 2026-07-01 hygiene -- guards lazy-build race in _ensure_stopped_event.
        import threading as _th
        self._event_lock = _th.Lock()
        # AUDIT-5 idempotency.
        self._started = False
        self._shutdown_done = False
        # Global pause — when True, the poll loop skips its cycle.
        # Per-runner pause is independent (set via runner.pause()).
        self.paused = False
        # 2026-07-01 (item #7) -- poll-loop-crash flag surfaced by
        # /health so K8s liveness probe returns 503 and the pod is
        # restarted.  Set by ``_on_poll_done`` when the loop dies
        # with an unhandled exception; never cleared (a service in
        # this state has no path back).
        self.poll_loop_dead = False
        self.poll_loop_dead_reason: str = ""

        # Service-level stats — was previously distributed across runners
        # because each owned its own poll loop.  Now centralised.
        self.stats: Dict[str, int] = {
            "polls": 0,
            "unrouted": 0,        # row whose dag_type has no enabled runner
        }

        # Cross-pod claim audit ID — host:pid.  Each runner adds its
        # ``:<workflow>:<pid>`` suffix when invoking try_claim_run so
        # the DBMS_LOCK audit line names the workflow.
        #
        # 2026-07-01 -- fallback now includes pid so two pods that
        # share worker_id (default ``bg_poller_1``) don't collide
        # in the audit line.  Previously the fallback set claimer_id
        # to the config.worker_id verbatim -- ambiguous when
        # socket.gethostname() failed on both pods.
        try:
            self._claimer_id = f"{socket.gethostname()}:{os.getpid()}"
        except Exception:
            self._claimer_id = f"{config.worker_id}:{os.getpid()}"

        self.dispatcher: Optional[Dispatcher] = None
        self._build_runners()

    def _ensure_stopped_event(self) -> asyncio.Event:
        # 2026-07-01 -- guarded lazy build.  Previously two concurrent
        # ``stop()`` + ``wait_for_stop()`` callers could each see
        # ``_stopped_event is None`` and create SEPARATE Event objects;
        # the one that set() wouldn't be the one that wait()ed and
        # shutdown would hang.  Guard with a threading.Lock kept from
        # module import time.  Race is only theoretical (start() is
        # called before any consumer), but a hardening one-liner
        # closes it permanently.
        if self._stopped_event is not None:
            return self._stopped_event
        with self._event_lock:
            if self._stopped_event is None:
                self._stopped_event = asyncio.Event()
        return self._stopped_event

    @property
    def stopped(self) -> bool:
        return self._stopped_event is not None and self._stopped_event.is_set()

    async def wait_for_stop(self) -> None:
        """Block until ``stop()`` is called."""
        await self._ensure_stopped_event().wait()

    # ── construction ─────────────────────────────────────────────────

    def _build_runners(self) -> None:
        """Materialise one ``WorkflowRunner`` per AVAILABLE workflow plugin.

        2026-06-29 — auto-start: every workflow plugin discovered in the
        ``workflows/`` package starts automatically on service startup.
        The polling YAML's ``polling.workflows[]`` list is now an
        OPERATOR OVERRIDE layer (disable a workflow, raise its concurrency
        cap, point at a custom worker class).  YAML entries are NOT
        required to start a plugin — drop a file in ``workflows/`` and
        next boot picks it up.

        Auto-skip rules:
          * Lightweight image (``use_lightweight_steps=True``) + workflow
            ``lightweight_capable=False`` (e.g. s3_*) -> the workflow is
            silently skipped (logged INFO).  Operator can flip
            ``enabled: true`` in YAML to force-attempt, but the worker
            class loader will return None and any dispatch refuses cleanly.
          * Worker class loader returns None at startup (e.g. pyspark
            missing) -> skipped with a WARN.
          * Explicit ``enabled: false`` in YAML -> skipped with INFO.

        Plugin manifest discovery happens once at __init__ (the
        ``get_registry()`` call inside ``Dispatcher.__init__``).  This
        method just consumes the registry.
        """
        from polling_service.config import WorkflowConfig
        from polling_service.workflow_registry import get_registry

        cfg = self.config

        # 2026-06-29 round-2 fix: share the BackgroundService's single
        # OracleMetadataManager into the Dispatcher so every run reuses
        # the SAME oracledb pool instead of opening one pool per run.
        # Under burst dispatch (max_concurrent_runs=10) this caps Oracle
        # connections at pool_max(10) total instead of 10 pools × 10 = 100.
        self.dispatcher = Dispatcher(
            logger=self.logger.getChild("dispatcher"),
            use_lightweight_steps=cfg.use_lightweight_steps,
            shared_oracle_manager=self.oracle_manager,
        )

        # Index any YAML overrides by canonical workflow name for fast lookup.
        yaml_overrides = {wf.name: wf for wf in cfg.workflows}

        registry = self.dispatcher.registry
        if len(registry) == 0:
            self.logger.warning(
                "BackgroundService: no workflow plugins discovered in the "
                "workflows/ package — service will idle.  Confirm the "
                "package is on PYTHONPATH and contains manifest files."
            )
            return

        for definition in registry:
            override = yaml_overrides.get(definition.name)

            # Decide whether this workflow should START.
            if override is not None and not override.enabled:
                self.logger.info(
                    f"[wf={definition.name}] DISABLED by polling YAML "
                    f"(enabled: false) — registered but not started"
                )
                continue

            # Auto-disable Spark-only workflows on the lightweight image
            # unless the operator explicitly overrode enabled=true.
            if (
                cfg.use_lightweight_steps
                and not definition.lightweight_capable
                and (override is None or not override.enabled)
            ):
                self.logger.info(
                    f"[wf={definition.name}] auto-skipped on lightweight "
                    f"image (requires Spark; set BG_USE_LIGHTWEIGHT=false "
                    f"on a Spark-capable image to enable, or override "
                    f"enabled: true in polling YAML to force-attempt)"
                )
                continue

            # Confirm the worker class actually loads on THIS image.
            worker_cls = definition.worker_cls()
            if worker_cls is None:
                self.logger.warning(
                    f"[wf={definition.name}] worker class loader returned "
                    f"None (likely missing optional dependency).  Skipping; "
                    f"dispatcher would refuse any row routed here anyway."
                )
                continue

            # Build the WorkflowConfig the runner needs.  Operator override
            # wins for max_concurrent_runs / max_run_seconds; otherwise use
            # service-level defaults so the runner has sensible caps.
            if override is not None:
                workflow_cfg = override
                # Honour worker_class_path override by re-registering the
                # plugin definition with a different worker class.
                if workflow_cfg.worker_class_path:
                    try:
                        registry.register_runtime_override(
                            workflow_cfg.name,
                            workflow_cfg.worker_class_path,
                            needs_starburst_clients=workflow_cfg.needs_starburst_clients,
                        )
                        self.logger.info(
                            f"[wf={workflow_cfg.name}] operator override "
                            f"worker_class_path={workflow_cfg.worker_class_path}"
                        )
                    except (ValueError, RuntimeError) as exc:
                        self.logger.error(
                            f"[wf={workflow_cfg.name}] STARTUP FAILURE — "
                            f"worker_class_path override invalid: {exc}"
                        )
                        raise
            else:
                workflow_cfg = WorkflowConfig(
                    name=definition.name,
                    enabled=True,
                    max_concurrent_runs=max(1, cfg.max_concurrent_runs),
                    max_run_seconds=cfg.max_run_seconds,
                )

            runner = WorkflowRunner(
                workflow=workflow_cfg,
                etl_connection_string=cfg.etl_connection_string,
                dest_connection_string=cfg.dest_connection_string,
                oracle_manager=self.oracle_manager,
                dispatcher=self.dispatcher,
                logger=self.logger,
            )
            self.runners.append(runner)

            # Fire plugin lifecycle hook so plugins can do one-time
            # per-runner setup (e.g. warm a connection pool, register
            # custom metrics).  Failures here are non-fatal — they're
            # logged but the runner still starts.
            if definition.on_runner_start is not None:
                try:
                    definition.on_runner_start(runner)
                except Exception as exc:
                    self.logger.warning(
                        f"[wf={definition.name}] on_runner_start hook raised "
                        f"{type(exc).__name__}: {exc} — runner started anyway"
                    )

        # Warn about YAML entries that reference workflows nobody discovered
        # (operator typo or stale entry after a manifest was removed).
        discovered = {d.name for d in registry}
        for name in yaml_overrides:
            if name not in discovered and registry.get(name) is None:
                self.logger.warning(
                    f"polling YAML references workflow {name!r} but no "
                    f"manifest exists in the workflows/ package.  The "
                    f"entry is ignored.  Either drop a manifest file or "
                    f"remove the YAML entry."
                )

        self.logger.info(
            f"BackgroundService: {len(self.runners)} workflow runner(s) "
            f"started: {[r.workflow.name for r in self.runners]} "
            f"(use_lightweight_steps={cfg.use_lightweight_steps}, "
            f"discovered={len(registry)}, "
            f"yaml_overrides={list(yaml_overrides.keys())})"
        )

    # ── lifecycle ────────────────────────────────────────────────────

    async def start(self) -> None:
        """Spawn the single poll task.  Idempotent."""
        if self._started:
            self.logger.warning(
                "BackgroundService.start(): already started — ignoring repeat call"
            )
            return
        self._started = True
        self._ensure_stopped_event()

        if not self.runners:
            self.logger.warning(
                "BackgroundService.start(): no enabled runners — service idle"
            )
            return

        self._poll_task = asyncio.create_task(
            self._poll_loop(), name="bg_poll_loop",
        )
        self._poll_task.add_done_callback(self._on_poll_done)
        self.logger.info(
            f"BackgroundService started — single poll loop, "
            f"interval={self.config.interval_seconds}s, "
            f"runners={[r.workflow.name for r in self.runners]}"
        )

    def _on_poll_done(self, task: asyncio.Task) -> None:
        """AUDIT-2 equivalent — log the poll loop's death loudly.

        The poll loop is the heartbeat of the whole service.  If it
        dies unexpectedly, EVERY runner becomes a zombie holding empty
        slots while nothing reads Oracle.  Surface this immediately +
        page ops via the alerter (no rate-limit on CRITICAL events
        within their own cooldown).
        """
        if task.cancelled():
            self.logger.info("Poll loop cancelled")
            return
        exc = task.exception()
        if exc is None:
            self.logger.info("Poll loop exited cleanly")
            return
        self.logger.error(
            f"Poll loop CRASHED unexpectedly — entire service is now blind; "
            f"NO new runs will be dispatched until the pod restarts.  "
            f"Last error: {exc!r}",
            exc_info=exc,
        )
        # 2026-07-01 (item #7) -- flip the dead flag so /health returns
        # 503 and K8s auto-restarts the pod on the next liveness probe.
        # Previous behaviour: health kept returning 200 and operators
        # only found out via user complaints hours later.
        self.poll_loop_dead = True
        self.poll_loop_dead_reason = f"{type(exc).__name__}: {exc}"[:500]
        # Fire CRITICAL alert — operators MUST see this.
        try:
            from polling_service.alerter import AlertEvent, get_alerter
            get_alerter().alert(AlertEvent(
                trigger="poll_loop_crash",
                severity="CRITICAL",
                message=(
                    f"{type(exc).__name__}: {exc} — poll loop died, "
                    f"NO new runs will dispatch until pod restarts"
                ),
                details={"worker_id": self.config.worker_id},
            ))
        except Exception as alert_exc:
            self.logger.error(
                "Failed to send poll_loop_crash alert: %s", alert_exc,
            )

    def stop(self) -> None:
        """Signal the poll loop + every runner to stop.  Idempotent.

        2026-07-01 hotfix-2 -- ``asyncio.Event.set()`` is NOT
        thread-safe from a non-loop thread.  ``stop()`` can be
        called from a signal handler thread OR from a FastAPI
        worker thread (via /pause).  Use
        ``loop.call_soon_threadsafe`` when a loop is available so
        the .set() is scheduled onto the loop thread.
        """
        if self.stopped:
            return
        evt = self._ensure_stopped_event()
        try:
            import asyncio as _asyncio
            loop = _asyncio.get_event_loop()
            if loop.is_running():
                loop.call_soon_threadsafe(evt.set)
                return
        except Exception:
            # No loop bound yet or loop closed -- fall through to
            # a direct .set() which is safe when we ARE the loop
            # thread (e.g. shutdown handler on the running loop).
            pass
        try:
            evt.set()
        except RuntimeError:                                          # pragma: no cover
            # Loop already closed / event was bound to a dead loop.
            # Nothing to stop -- interpreter exit follows.
            pass

    async def shutdown(self) -> None:
        """Drain in-flight RUN_ID tasks across runners, then exit.

        Same drain semantics as the previous iteration (AUDIT-1):
          1. Drain in-flight tasks up to ``shutdown_timeout_seconds``.
          2. Cancel stragglers.
          3. Await the poll loop (exits fast once stop_event fires).
        """
        if self._shutdown_done:
            return
        self._shutdown_done = True

        # Fire on_runner_stop lifecycle hooks BEFORE drain so plugins can
        # signal upstream consumers (close pools, flush metrics).  Each
        # hook is bounded by ``HOOK_TIMEOUT_S`` to prevent a misbehaving
        # plugin from blocking shutdown until K8s SIGKILL.  Hook failures
        # (incl. timeout) are non-fatal — drain proceeds.
        #
        # 2026-07-01 fix -- rewritten to use ``asyncio.to_thread +
        # asyncio.wait_for`` instead of the earlier
        # ``fut.result(timeout=...)`` which blocked the event loop for
        # up to HOOK_TIMEOUT_S per runner (7 runners × 5s = 35s of
        # frozen /health responses during shutdown).  This variant keeps
        # the event loop responsive so uvicorn can answer K8s
        # readiness/liveness probes during graceful shutdown.
        HOOK_TIMEOUT_S = 5
        for runner in self.runners:
            manifest = self.dispatcher.registry.get(runner.workflow.name) if self.dispatcher else None
            if manifest is None or manifest.on_runner_stop is None:
                continue
            try:
                await asyncio.wait_for(
                    asyncio.to_thread(manifest.on_runner_stop, runner),
                    timeout=HOOK_TIMEOUT_S,
                )
            except asyncio.TimeoutError:
                self.logger.warning(
                    f"[wf={runner.workflow.name}] on_runner_stop hook TIMED OUT "
                    f"after {HOOK_TIMEOUT_S}s — drain continues; the hook will "
                    f"keep running in the background until pod SIGKILL"
                )
            except Exception as exc:
                self.logger.warning(
                    f"[wf={runner.workflow.name}] on_runner_stop hook raised "
                    f"{type(exc).__name__}: {exc} — drain continues"
                )

        timeout = max(0, int(self.config.shutdown_timeout_seconds))

        # Phase 1: drain in-flight RUN_ID tasks across every runner.
        in_flight: List[Tuple[str, int, asyncio.Task]] = []
        for runner in self.runners:
            for rid, t in list(runner.active_runs.items()):
                if not t.done():
                    in_flight.append((runner.workflow.name, rid, t))

        if not in_flight:
            self.logger.info(
                "BackgroundService.shutdown: no in-flight runs to drain"
            )
        else:
            self.logger.info(
                f"BackgroundService.shutdown: draining {len(in_flight)} "
                f"in-flight run(s) across {len(self.runners)} runner(s) "
                f"(timeout={timeout}s) — "
                f"{[f'{w}:{r}' for w, r, _ in in_flight]}"
            )
            try:
                await asyncio.wait_for(
                    asyncio.gather(*[t for _, _, t in in_flight],
                                   return_exceptions=True),
                    timeout=timeout if timeout > 0 else None,
                )
                self.logger.info(
                    "BackgroundService.shutdown: in-flight runs drained cleanly"
                )
            except asyncio.TimeoutError:
                stragglers = [(w, r, t) for w, r, t in in_flight if not t.done()]
                self.logger.warning(
                    f"BackgroundService.shutdown: drain timeout exceeded — "
                    f"cancelling {len(stragglers)} straggler run(s): "
                    f"{[f'{w}:{r}' for w, r, _ in stragglers]}"
                )
                for _, _, t in stragglers:
                    t.cancel()
                # 2026-07-01 hygiene -- outer timeout on the post-cancel
                # gather so a straggler whose ``finally:`` block ignores
                # CancelledError (e.g. long Oracle round-trip) can't
                # hang shutdown until K8s SIGKILL.  5s is enough for
                # normal cancel cleanup; anything past that is a bug in
                # the straggler's teardown that we can't fix from here.
                try:
                    await asyncio.wait_for(
                        asyncio.gather(
                            *[t for _, _, t in stragglers],
                            return_exceptions=True,
                        ),
                        timeout=5.0,
                    )
                except asyncio.TimeoutError:
                    self.logger.warning(
                        "BackgroundService.shutdown: %d straggler(s) "
                        "still not done after cancel + 5s -- letting "
                        "K8s SIGKILL finish the job.",
                        sum(1 for _, _, t in stragglers if not t.done()),
                    )

        # Phase 2: await the poll loop.  Swallow any exception — it has
        # already been logged by _on_poll_done; re-raising would surface
        # the same error twice and bury the "shutdown clean" line.
        if self._poll_task is not None:
            try:
                await asyncio.wait_for(self._poll_task, timeout=5)
                self.logger.info(
                    "BackgroundService.shutdown: poll loop exited"
                )
            except asyncio.TimeoutError:
                self.logger.warning(
                    "BackgroundService.shutdown: poll loop did NOT exit "
                    "within 5s — cancelling"
                )
                self._poll_task.cancel()
                try:
                    await self._poll_task
                except (asyncio.CancelledError, Exception):
                    pass
            except Exception:
                # Done-callback already logged the crash; nothing else to do.
                pass

        # 2026-07-01 -- release any cached secondary Oracle pools built
        # during dispatch (item #30 in the audit).  Idempotent + best
        # effort; Oracle auto-releases sessions on process death, so
        # any exception here is logged and swallowed.
        # 2026-07-01 hotfix: previous version used
        # ``getattr(self, "oracle_metadata_manager", None)`` which
        # ALWAYS returned None because the attribute is actually
        # ``self.oracle_manager`` (set at __init__ line 80).  Cleanup
        # was silently a no-op every shutdown.
        try:
            manager = self.oracle_manager
            if manager is not None:
                inner = getattr(manager, "oracle_db", None)
                closer = getattr(inner, "close_secondary_pools", None)
                if callable(closer):
                    closer()
        except Exception as _sec_exc:                                # pragma: no cover
            self.logger.warning(
                f"BackgroundService.shutdown: secondary pool cleanup "
                f"raised {_sec_exc!r} — swallowing (auto-release on exit)"
            )

        # 2026-07-01 hotfix -- stop the telemetry persistence daemon
        # BEFORE the loop closes so it doesn't race snapshot writes
        # against the readiness executor teardown.  Optional attribute
        # (only present when main.py wired it in).
        try:
            _td = getattr(self, "_telemetry_daemon", None)
            if _td is not None:
                _td.stop()
        except Exception as _td_exc:                                 # pragma: no cover
            self.logger.warning(
                f"BackgroundService.shutdown: telemetry daemon stop "
                f"raised {_td_exc!r} — swallowing"
            )

        # 2026-07-01 hotfix -- release the alerter's bounded SMTP
        # thread pool so pending sends are cancelled during graceful
        # shutdown (K8s SIGTERM path).  Non-blocking so a hung SMTP
        # send can't wedge shutdown.
        try:
            from polling_service.alerter import get_alerter
            _alerter = get_alerter()
            if _alerter is not None and hasattr(_alerter, "shutdown"):
                _alerter.shutdown(wait=False)
        except Exception as _al_exc:                                 # pragma: no cover
            self.logger.warning(
                f"BackgroundService.shutdown: alerter shutdown raised "
                f"{_al_exc!r} — swallowing"
            )

        self.logger.info("BackgroundService shut down")

    # ── poll loop ────────────────────────────────────────────────────

    # Oracle circuit-breaker tuning (2026-06-29 round-3).  When a poll
    # cycle raises (Oracle unreachable, ORA-XXXXX, network glitch), we
    # back off the NEXT cycle exponentially so we don't hammer a dead
    # database.  Reset on first success.
    _CB_BACKOFF_BASE_S = 2          # first backoff = 2s on top of interval
    _CB_BACKOFF_MAX_S  = 300        # 5-min cap

    async def _poll_loop(self) -> None:
        """Single polling loop — drives every runner.

        2026-06-29 — Oracle circuit-breaker added.  Consecutive poll
        failures back off the next cycle exponentially (2s, 4s, 8s, …
        capped at 5 min) on top of the configured interval so we don't
        hammer a dead Oracle.  Reset on first successful cycle.
        Triggers an ``oracle_unreachable`` alert after the first error.
        """
        cfg = self.config
        stop_event = self._ensure_stopped_event()
        consecutive_failures = 0
        while not stop_event.is_set():
            cycle_failed = False
            if not self.paused:
                try:
                    await self._poll_once()
                    consecutive_failures = 0
                except Exception as exc:
                    cycle_failed = True
                    consecutive_failures += 1
                    self.logger.error(
                        f"Poll cycle error (consecutive failures={consecutive_failures}): "
                        f"{exc}", exc_info=True,
                    )
                    # First failure → page ops.  Subsequent failures throttled
                    # by the alerter's cooldown so we don't flood.
                    try:
                        from polling_service.alerter import AlertEvent, get_alerter
                        get_alerter().alert(AlertEvent(
                            trigger="oracle_unreachable",
                            severity="CRITICAL" if consecutive_failures >= 3 else "ERROR",
                            message=(
                                f"Poll cycle FAILED "
                                f"({consecutive_failures} consecutive): "
                                f"{type(exc).__name__}: {exc}"
                            ),
                            details={"worker_id": cfg.worker_id,
                                     "consecutive_failures": str(consecutive_failures)},
                        ))
                    except Exception:
                        pass
            # Compute effective sleep: interval + exponential backoff
            # on consecutive failures (2^N seconds, capped at MAX).
            base_sleep = max(1, int(cfg.interval_seconds))
            if consecutive_failures > 0:
                backoff = min(
                    self._CB_BACKOFF_MAX_S,
                    self._CB_BACKOFF_BASE_S * (2 ** (consecutive_failures - 1)),
                )
                self.logger.warning(
                    f"Oracle circuit-breaker: sleeping {base_sleep + backoff}s "
                    f"(interval={base_sleep}s + backoff={backoff}s for "
                    f"{consecutive_failures} consecutive failures)"
                )
                effective_sleep = base_sleep + backoff
            else:
                effective_sleep = base_sleep
            try:
                await asyncio.wait_for(
                    asyncio.shield(stop_event.wait()),
                    timeout=effective_sleep,
                )
            except asyncio.TimeoutError:
                pass
        self.logger.info(
            f"Poll loop stop signalled — active_runs_remaining="
            f"{sum(len(r.active_runs) for r in self.runners)}"
        )

    async def _poll_once(self) -> None:
        """One poll cycle: shared query → group by RUN_ID → route → dispatch."""
        cfg = self.config
        self.stats["polls"] += 1
        poll_num = self.stats["polls"]

        # Row limit sized to cover the union of runner caps so a hot
        # workflow doesn't starve its peers under SOD spikes.
        total_cap = max(1, sum(r.workflow.max_concurrent_runs for r in self.runners))
        row_limit = max(
            total_cap, total_cap * cfg.polling_query_limit_multiplier,
        )

        # 2026-07-01 -- per-poll Oracle timeout.  Previously the await
        # had no ceiling; a stalled Oracle session blocked the whole
        # poll cycle for the oracledb TCP timeout (5-10 min).  The
        # circuit-breaker only fires AFTER an exception, so the pod
        # would stop dispatching without alerting.  60s is generous
        # for a bounded polling query with ROWNUM cap.
        try:
            rows = await asyncio.wait_for(
                self.oracle_manager.get_all_start_tasks(
                    cfg.etl_connection_string,
                    cfg.bg_polling_sql,
                    row_limit=row_limit,
                ),
                timeout=60.0,
            )
        except asyncio.TimeoutError:
            self.logger.error(
                f"Poll cycle #{poll_num}: Oracle poll TIMED OUT after "
                f"60s -- skipping this cycle.  Oracle may be under load "
                f"or session pool exhausted; the next cycle will retry."
            )
            return
        if not rows:
            self.logger.debug(f"Poll cycle #{poll_num}: no START tasks")
            return

        # Group by RUN_ID — rows already sorted RUN_ID ASC, SEQ ASC.
        runs: Dict[int, list] = {}
        dropped_no_run_id = 0
        for row in rows:
            run_id = row.get("run_id")
            if run_id is None:
                dropped_no_run_id += 1
                continue
            runs.setdefault(run_id, []).append(row)

        if dropped_no_run_id:
            self.logger.warning(
                f"Poll cycle #{poll_num}: dropped {dropped_no_run_id} "
                f"row(s) with NULL run_id — check bg_polling_query"
            )

        self.logger.info(
            f"Poll cycle #{poll_num}: {len(rows)} task row(s) "
            f"across {len(runs)} run(s) (limit={row_limit})"
        )

        # Route + dispatch.  Tally outcomes for the cycle summary line.
        outcomes: Dict[str, int] = {}
        for run_id, tasks in runs.items():
            dag_type = _infer_dag_type(tasks[0])
            runner = self.find_runner(dag_type)
            if runner is None:
                self.stats["unrouted"] += 1
                outcomes["unrouted"] = outcomes.get("unrouted", 0) + 1
                self.logger.warning(
                    f"Poll cycle #{poll_num}: run_id={run_id} routed to "
                    f"dag_type={dag_type!r} but no enabled runner exists — "
                    f"row is left in STATUS=START.  Either enable the "
                    f"runner, or fix the OTG_DAG_ID prefix on the polling row."
                )
                continue
            outcome = await runner.try_dispatch(
                int(run_id), tasks,
                claimer_id_prefix=self._claimer_id,
                etl_connection_string=cfg.etl_connection_string,
            )
            outcomes[outcome] = outcomes.get(outcome, 0) + 1

        # Compact outcome summary — easier to scan than per-row INFOs.
        summary = ", ".join(f"{k}={v}" for k, v in sorted(outcomes.items()))
        if summary:
            self.logger.info(
                f"Poll cycle #{poll_num}: routing outcomes — {summary}"
            )

    # ── observability ────────────────────────────────────────────────

    def aggregate_stats(self) -> Dict[str, int]:
        """Service-level + per-runner counters merged into one dict."""
        agg = dict(self.stats)
        for runner in self.runners:
            for k, v in runner.stats.items():
                agg[k] = agg.get(k, 0) + int(v)
        return agg

    def total_active_runs(self) -> int:
        return sum(len(r.active_runs) for r in self.runners)

    def all_active_run_ids(self) -> List[int]:
        ids: List[int] = []
        for runner in self.runners:
            ids.extend(runner.active_runs.keys())
        return ids

    def workflow_snapshots(self) -> List[Dict]:
        return [r.snapshot() for r in self.runners]

    def find_runner(self, name: str) -> Optional[WorkflowRunner]:
        for r in self.runners:
            if r.workflow.name == name:
                return r
        return None

    # ── pause / resume ───────────────────────────────────────────────

    def pause_all(self) -> None:
        """Pause the global poll loop AND every runner.

        Two layers because:
          * Pausing the poll loop -> no Oracle hits, slot pipeline drains.
          * Pausing every runner -> if poll resumes (e.g. via single-runner
            resume) the per-runner pause still blocks dispatch.
        Calling `resume_all()` reverses both.
        """
        self.paused = True
        for r in self.runners:
            r.pause()

    def resume_all(self) -> None:
        self.paused = False
        for r in self.runners:
            r.resume()
