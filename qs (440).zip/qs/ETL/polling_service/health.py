"""
FastAPI health/status/control API for the ETL Background Polling Service.

Endpoints (port 9000):
  GET  /health           → 200 {"status": "ok", "active_runs": N, "paused": bool}
  GET  /health/ready     → 200 if Oracle reachable, else 503
  GET  /status           → aggregated stats; ``workflows`` key surfaces
                            per-runner state when multi-workflow mode is on
  GET  /workflows        → list of per-workflow snapshots (multi mode only)
  POST /pause            → pause polling (all runners in multi mode)
  POST /resume           → resume polling
  POST /workflows/{name}/pause   → pause a single runner (multi mode)
  POST /workflows/{name}/resume  → resume a single runner (multi mode)

2026-06-12 — multi-workflow mode.  ``init_health_service`` wires the
``BackgroundService`` instead of the legacy ``BackgroundPoller``.  Both
inject paths are mutually exclusive — main.py picks one based on
``cfg.workflows``.  All endpoints transparently fan out to whichever
backend is wired (back-compat preserved for the single-loop deploy).
"""
import asyncio
import logging
import time
from typing import TYPE_CHECKING, Optional

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse

from polling_service.auth import require_admin, is_auth_enabled

if TYPE_CHECKING:
    from polling_service.poller import BackgroundPoller
    from polling_service.service import BackgroundService
    from managers.oracle_metadata_manager import OracleMetadataManager

# Child of "bg_poller" — propagates to the root logger configured in main.py
# so health endpoint logs reach the same console + file as the rest of the service.
# getLogger(__name__) = "polling_service.health" would propagate to root only,
# which has no handlers until main.py runs → INFO logs silently lost.
logger = logging.getLogger("bg_poller.health")

app = FastAPI(title="ETL Background Polling Service", version="1.0.0")

# Injected at startup by main.py — at most ONE of (_poller, _service)
# is non-None for the life of the process.
_poller: "BackgroundPoller | None" = None
_service: "BackgroundService | None" = None
_oracle_manager: "OracleMetadataManager | None" = None
_etl_conn_str: str = ""


def init_health(poller: "BackgroundPoller", oracle_manager: "OracleMetadataManager", etl_conn_str: str) -> None:
    """Inject dependencies for the legacy single-loop path.

    2026-07-01 hygiene -- idempotency guard added.  Test suites that
    build multiple pollers in-process would silently overwrite the
    globals and leak references; now a re-init emits a WARN so
    unintended double-inits are visible.
    """
    global _poller, _service, _oracle_manager, _etl_conn_str
    if _poller is not None or _service is not None:
        logger.warning(
            "init_health re-invoked -- previous poller/service reference "
            "replaced.  Expected once per process; multi-init usually "
            "indicates a test leak."
        )
    _poller = poller
    _service = None
    _oracle_manager = oracle_manager
    _etl_conn_str = etl_conn_str


def init_health_service(service: "BackgroundService", oracle_manager: "OracleMetadataManager", etl_conn_str: str) -> None:
    """Inject dependencies for the multi-workflow path.

    2026-07-01 hygiene -- same idempotency guard as ``init_health``.
    """
    global _poller, _service, _oracle_manager, _etl_conn_str
    if _poller is not None or _service is not None:
        logger.warning(
            "init_health_service re-invoked -- previous poller/service "
            "reference replaced.  Expected once per process; multi-init "
            "usually indicates a test leak."
        )
    _poller = None
    _service = service
    _oracle_manager = oracle_manager
    _etl_conn_str = etl_conn_str


def _initialized() -> bool:
    return _poller is not None or _service is not None


@app.get("/health")
async def health() -> JSONResponse:
    """Liveness check.

    Returns 503 when the poll loop has crashed so K8s auto-restarts
    the pod (2026-07-01 item #7 fix -- previously kept returning
    200 even after ``_on_poll_done`` fired, so a crashed poll loop
    silently stopped dispatching until an operator noticed).
    Returns 200 otherwise.
    """
    if not _initialized():
        return JSONResponse(status_code=503, content={"status": "not_initialized"})
    if _service is not None:
        # Poll-loop-dead check gates the 200 response.  A dead poll
        # loop means no new dispatches happen; K8s must restart us.
        # 2026-07-01 hotfix -- use direct attribute access instead of
        # ``getattr(_service, "poll_loop_dead", False)``.  The default-
        # False fallback FAILS OPEN if the attribute is ever renamed
        # or dropped by a refactor: health silently returns 200
        # forever, exactly the bug this check was written to prevent.
        # Direct access raises AttributeError → 500 → K8s restarts.
        if _service.poll_loop_dead:
            return JSONResponse(
                status_code=503,
                content={
                    "status": "poll_loop_dead",
                    "mode": "multi",
                    "reason": _service.poll_loop_dead_reason,
                    "worker_id": _service.config.worker_id,
                    "admin_auth_enabled": is_auth_enabled(),
                },
            )
        return JSONResponse(content={
            "status": "ok",
            "mode": "multi",
            "active_runs": _service.total_active_runs(),
            "paused": _service.paused,
            "worker_id": _service.config.worker_id,
            "workflows": [r.workflow.name for r in _service.runners],
            "admin_auth_enabled": is_auth_enabled(),
        })
    return JSONResponse(content={
        "status": "ok",
        "mode": "single",
        "active_runs": len(_poller.active_runs),
        "paused": _poller.paused,
        "worker_id": _poller.config.worker_id,
        "admin_auth_enabled": is_auth_enabled(),
    })


def _is_draining() -> bool:
    """True when the service has begun graceful shutdown.  Readiness
    must return 503 immediately so K8s removes the pod from the
    endpoints slice (~0.5-5s propagation) BEFORE we finish draining
    in-flight runs.  Liveness (/health) keeps returning 200 during
    this window so K8s doesn't restart the pod mid-drain."""
    if _service is None:
        return False
    # BackgroundService flips ``_stopped_event`` (asyncio.Event) as
    # soon as ``stop()`` is called.  Read defensively -- during a
    # very early stop the event may not yet exist.
    evt = getattr(_service, "_stopped_event", None)
    if evt is not None:
        try:
            if evt.is_set():
                return True
        except Exception:
            pass
    # Also flip on the shutdown_done flag as a belt-and-braces
    # signal (shutdown() clears in-flight tasks).
    return bool(getattr(_service, "_shutdown_done", False))


@app.get("/health/ready")
async def health_ready() -> JSONResponse:
    """Readiness check — 503 if Oracle is unreachable OR the service
    has entered drain.  2026-07-01 hotfix-2: drain check added so
    K8s removes the pod from the endpoints slice at SIGTERM instead
    of continuing to route new traffic until the pod actually exits.
    """
    if not _initialized() or _oracle_manager is None:
        return JSONResponse(status_code=503, content={"status": "not_initialized"})
    # Drain gate: fail-first as soon as stop() fires.
    if _is_draining():
        return JSONResponse(
            status_code=503,
            content={
                "status": "draining",
                "detail": "SIGTERM received -- refusing new traffic while "
                          "draining in-flight runs",
            },
        )
    try:
        ok = await _oracle_check()
        if ok:
            return JSONResponse(content={"status": "ready"})
        return JSONResponse(status_code=503, content={"status": "oracle_unreachable"})
    except Exception as e:
        # 2026-07-01 hotfix-2 -- do NOT echo the raw exception text.
        # Oracle exceptions frequently include DSN fragments, and
        # /health/ready is UNAUTH by K8s convention.  Log the detail
        # server-side; return a canned status externally.
        logger.warning("Readiness check failed: %s", e)
        return JSONResponse(
            status_code=503,
            content={"status": "error"},
        )


def _alerter_snapshot() -> dict:
    """Try to grab the alerter snapshot; degrade gracefully if the
    alerter module didn't initialise (e.g. import-only test contexts)."""
    try:
        from polling_service.alerter import get_alerter
        return get_alerter().snapshot()
    except Exception as exc:
        logger.debug("Alerter snapshot unavailable: %s", exc)
        return {"enabled": False, "error": str(exc)[:200]}


def _dead_letter_snapshot() -> dict:
    """Same fail-safe pattern for the dead-letter tracker."""
    try:
        from polling_service.dead_letter import get_tracker
        return get_tracker().snapshot()
    except Exception as exc:
        logger.debug("Dead-letter snapshot unavailable: %s", exc)
        return {"error": str(exc)[:200]}


@app.get("/status")
async def status(_auth: None = Depends(require_admin)) -> JSONResponse:
    """Full stats snapshot — aggregated across runners in multi mode.

    2026-07-01 -- auth added.  Response reveals worker_id, active
    RUN_IDs, workflow-per-plugin last_failure_reason text (which
    could contain Trino / Oracle DSN fragments from arbitrary
    worker exception strings), and alerter SMTP config.  When
    ``POLLING_ADMIN_TOKEN`` env var is unset the endpoint stays
    open for back-compat.  In production ALWAYS set the token via
    the Helm secret so this endpoint is authenticated.
    """
    if not _initialized():
        return JSONResponse(status_code=503, content={"status": "not_initialized"})
    if _service is not None:
        return JSONResponse(content={
            **_service.aggregate_stats(),
            "mode": "multi",
            "active_runs": _service.total_active_runs(),
            "active_run_ids": _service.all_active_run_ids(),
            "paused": _service.paused,
            "worker_id": _service.config.worker_id,
            "workflows": _service.workflow_snapshots(),
            "alerter": _alerter_snapshot(),
            "dead_letter": _dead_letter_snapshot(),
        })
    return JSONResponse(content={
        **_poller.stats,
        "mode": "single",
        "active_runs": len(_poller.active_runs),
        "active_run_ids": list(_poller.active_runs.keys()),
        "paused": _poller.paused,
        "worker_id": _poller.config.worker_id,
        "interval_seconds": _poller.config.interval_seconds,
        "max_concurrent_runs": _poller.config.max_concurrent_runs,
        "alerter": _alerter_snapshot(),
        "dead_letter": _dead_letter_snapshot(),
    })


@app.get("/workflows")
async def workflows(_auth: None = Depends(require_admin)) -> JSONResponse:
    """Per-workflow snapshots (multi-workflow mode only).

    Returns 404 when running in legacy single-loop mode so operators
    get a clear signal instead of an empty list.

    2026-07-01 -- auth added.  Snapshot includes last_failure_reason
    which can carry Trino / Oracle URL fragments from worker
    exception strings.  When ``POLLING_ADMIN_TOKEN`` env var is
    unset the endpoint stays open (back-compat).
    """
    if not _initialized():
        raise HTTPException(status_code=503, detail="not initialized")
    if _service is None:
        raise HTTPException(
            status_code=404,
            detail="single-loop mode active — no per-workflow stats. "
                   "Configure polling.workflows in polling_service_config.yaml.",
        )
    return JSONResponse(content={"workflows": _service.workflow_snapshots()})


def _audit_log(action: str, target: str, request) -> None:
    """Emit an INFO-level audit line for every operator action.

    Captures the client IP + the API caller's user-agent so ops can
    trace WHO paused/resumed WHAT, WHEN.  In a trusted-cluster setup
    these are the only available identity hints (no auth layer); when
    auth is added later, swap the X-User header in.

    The line uses a recognizable AUDIT prefix so log aggregators can
    filter the audit stream cheaply.
    """
    try:
        client = getattr(request, "client", None)
        client_host = client.host if client and client.host else "unknown"
    except Exception:
        client_host = "unknown"
    try:
        ua = request.headers.get("user-agent", "")
        forwarded_for = request.headers.get("x-forwarded-for", "")
    except Exception:
        ua, forwarded_for = "", ""
    # 2026-07-01 hotfix-2 -- attacker-controlled headers must be
    # BOTH length-capped AND CRLF-stripped before entering the log
    # stream.  Without the strip an attacker can forge audit lines
    # by injecting ``\n`` into X-Forwarded-For (log injection /
    # CRLF).
    ua            = _sanitize_header(ua, 120)
    forwarded_for = _sanitize_header(forwarded_for, 200)
    client_host   = _sanitize_header(client_host, 64)
    logger.info(
        "AUDIT action=%s target=%s client=%s xff=%s ua=%s",
        action, target, client_host, forwarded_for, ua,
    )


def _sanitize_header(value: str, max_len: int) -> str:
    """Strip CRLF + control chars from a header value and cap length.
    Prevents log-injection when the value flows into a logger
    message.  Idempotent + never raises."""
    if not value:
        return ""
    try:
        s = str(value)
    except Exception:
        return ""
    # Drop everything below 0x20 except space; also drop 0x7f (DEL).
    s = "".join(ch for ch in s if (32 <= ord(ch) < 127) and ch not in "\r\n")
    if len(s) > max_len:
        s = s[:max_len] + "…"
    return s


@app.post("/pause", dependencies=[Depends(require_admin)])
async def pause(request: Request) -> JSONResponse:
    """Pause polling — every runner in multi mode."""
    if not _initialized():
        raise HTTPException(status_code=503, detail="not initialized")
    _audit_log("pause", "all", request)
    if _service is not None:
        _service.pause_all()
        return JSONResponse(content={
            "status": "paused",
            "active_runs": _service.total_active_runs(),
        })
    _poller.pause()
    return JSONResponse(content={"status": "paused", "active_runs": len(_poller.active_runs)})


@app.post("/resume", dependencies=[Depends(require_admin)])
async def resume(request: Request) -> JSONResponse:
    """Resume polling."""
    if not _initialized():
        raise HTTPException(status_code=503, detail="not initialized")
    _audit_log("resume", "all", request)
    if _service is not None:
        _service.resume_all()
        return JSONResponse(content={"status": "resumed"})
    _poller.resume()
    return JSONResponse(content={"status": "resumed"})


@app.get("/workflows/{name}")
async def workflow_detail(
    name: str, _auth: None = Depends(require_admin),
) -> JSONResponse:
    """Per-workflow detail: manifest metadata + live telemetry + runner state.

    Returns:
      manifest:   version, source, patterns, capabilities, deprecated flag
      runner:     enabled, paused, active runs, slot pool
      telemetry:  dispatched / completed / failed / latency p50+p99 /
                  last_dispatch / last_failure_reason

    2026-07-01 hotfix-2 -- auth added.  Response includes
    ``last_failure_reason`` which regularly carries Trino/Oracle URL
    fragments from worker exception strings.  When
    ``POLLING_ADMIN_TOKEN`` env var is unset the endpoint stays open
    (back-compat parity with /workflows list).
    """
    if not _initialized():
        raise HTTPException(status_code=503, detail="not initialized")
    if _service is None:
        raise HTTPException(
            status_code=404,
            detail="multi-workflow mode not active — single-loop mode has no per-workflow detail",
        )
    runner = _service.find_runner(name)
    if runner is None:
        # Plugin may be registered but disabled (auto-skipped on lightweight,
        # operator-disabled in YAML).  Surface the registry view so operators
        # can tell "no such plugin" from "registered but not running".
        from polling_service.workflow_registry import get_registry
        manifest = get_registry().get(name)
        if manifest is None:
            raise HTTPException(status_code=404, detail=f"no plugin '{name}'")
        return JSONResponse(content={
            "name": manifest.name,
            "registered": True,
            "running": False,
            "manifest": _manifest_to_dict(manifest),
            "runner": None,
            "telemetry": None,
        })
    from polling_service.workflow_registry import get_registry
    manifest = get_registry().get(name)
    telemetry = get_registry().get_telemetry(name)
    return JSONResponse(content={
        "name": name,
        "registered": True,
        "running": True,
        "manifest": _manifest_to_dict(manifest) if manifest else None,
        "runner": runner.snapshot(),
        "telemetry": telemetry.snapshot() if telemetry else None,
    })


def _manifest_to_dict(m) -> dict:
    """Serialise a PluginManifest for the health API.  Skips non-JSON-safe
    attributes (callables, hooks)."""
    return {
        "name":                m.name,
        "version":             m.version,
        "manifest_version":    m.manifest_version,
        "description":         m.description,
        "source":              m.source,
        "priority":            m.priority,
        "dag_id_patterns":     list(m.dag_id_patterns),
        "db_connection_patterns": list(m.db_connection_patterns),
        "aliases":             list(m.aliases),
        "capabilities":        sorted(m.capabilities),
        "needs_starburst_clients": m.needs_starburst_clients,
        "lightweight_capable": m.lightweight_capable,
        "is_deprecated":       m.is_deprecated,
        "deprecated_message":  m.deprecated_message,
        "replaced_by":         m.replaced_by,
        "requires_env":        list(m.requires_env),
        "requires_packages":   list(m.requires_packages),
    }


@app.get("/registry", dependencies=[Depends(require_admin)])
async def registry_diag() -> JSONResponse:
    """Registry-wide diagnostic snapshot for ops:
       * every plugin's manifest + load state
       * priority collisions + pattern overlaps
       * default routing fallback name
    Same data the CLI's ``plugins validate`` shows.  Auth-gated so an
    in-cluster attacker can't enumerate plugin internals."""
    if not _initialized():
        raise HTTPException(status_code=503, detail="not initialized")
    from polling_service.workflow_registry import get_registry
    return JSONResponse(content=get_registry().validate_all())


@app.post("/admin/reload", dependencies=[Depends(require_admin)])
async def admin_reload(request: Request) -> JSONResponse:
    """Drop the plugin singleton and re-discover.  Use after dropping a
    new manifest into ``workflows/`` WITHOUT restarting the pod.

    Caveats:
      * In-flight dispatchers continue to use the worker classes they
        already resolved.  New rows route through the fresh registry.
      * The runner set is NOT rebuilt.  A newly-discovered plugin will
        appear in the registry + /workflows/{name} but won't have a
        running runner until the pod restarts.  This endpoint is
        primarily for ops to inspect a hot-dropped manifest before
        triggering a full restart.

    Auth-gated.  Audit-logged.
    """
    _audit_log("reload", "registry", request)
    from polling_service.workflow_registry import reset_registry, get_registry
    reset_registry()
    reg = get_registry()
    return JSONResponse(content={
        "status": "reloaded",
        "plugin_count": len(reg),
        "names": reg.names(),
        "warning": (
            "Runner set was NOT rebuilt — new plugins are visible in the "
            "registry but won't dispatch until pod restart."
        ),
    })


@app.post("/workflows/{name}/pause", dependencies=[Depends(require_admin)])
async def workflow_pause(name: str, request: Request) -> JSONResponse:
    """Pause a single runner without affecting siblings."""
    if _service is None:
        raise HTTPException(status_code=404, detail="multi-workflow mode not active")
    runner = _service.find_runner(name)
    if runner is None:
        raise HTTPException(status_code=404, detail=f"no runner '{name}'")
    _audit_log("pause", name, request)
    runner.pause()
    return JSONResponse(content={"status": "paused", "workflow": name})


@app.post("/workflows/{name}/resume", dependencies=[Depends(require_admin)])
async def workflow_resume(name: str, request: Request) -> JSONResponse:
    if _service is None:
        raise HTTPException(status_code=404, detail="multi-workflow mode not active")
    runner = _service.find_runner(name)
    if runner is None:
        raise HTTPException(status_code=404, detail=f"no runner '{name}'")
    _audit_log("resume", name, request)
    runner.resume()
    return JSONResponse(content={"status": "resumed", "workflow": name})


# ── /metrics endpoint (Prometheus text format) ─────────────────────────
#
# ServiceMonitor in the Helm chart already scrapes /metrics (default
# path).  Without this endpoint, the scrape returns 404 and operators
# get NO metrics despite the monitoring being "set up".  This implements
# the standard Prometheus text format, no external dependency.
#
# Exposed series (one labelled per plugin):
#   qs_polling_dispatched_total{workflow="..."}
#   qs_polling_completed_total{workflow="..."}
#   qs_polling_failed_total{workflow="..."}
#   qs_polling_timed_out_total{workflow="..."}
#   qs_polling_skipped_cross_pod_total{workflow="..."}
#   qs_polling_skipped_at_capacity_total{workflow="..."}
#   qs_polling_duration_p50_seconds{workflow="..."}
#   qs_polling_duration_p99_seconds{workflow="..."}
#   qs_polling_active_runs{workflow="..."}
#   qs_polling_alerts_sent_total
#   qs_polling_alerts_throttled_total
#   qs_polling_vault_consecutive_failures
#   qs_polling_up                                  (always 1; presence check)
#
# This is intentionally a simple hand-rolled emitter — no client-library
# dependency keeps the lightweight image footprint zero.


def _prom_escape(s: str) -> str:
    """Escape characters that Prometheus labels disallow: backslash,
    double-quote, newline."""
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


@app.get("/metrics", response_class=PlainTextResponse)
async def metrics() -> PlainTextResponse:
    """Prometheus text format.  Always returns 200 with at least
    ``qs_polling_up 1`` so the scrape's UP series is positive even when
    no plugins are registered yet."""
    lines = [
        "# HELP qs_polling_up Polling service is responding (always 1).",
        "# TYPE qs_polling_up gauge",
        "qs_polling_up 1",
    ]
    if not _initialized():
        return PlainTextResponse("\n".join(lines) + "\n")

    # Per-plugin telemetry counters.
    try:
        from polling_service.workflow_registry import get_registry
        reg = get_registry()
        telem_by_plugin = reg.all_telemetry()
    except Exception as exc:
        logger.warning("Failed to gather telemetry for /metrics: %s", exc)
        telem_by_plugin = {}

    # Active runs per plugin (from the runner snapshots).
    active_by_plugin = {}
    if _service is not None:
        for snap in _service.workflow_snapshots():
            active_by_plugin[snap["name"]] = snap["active_runs"]

    counter_series = [
        ("dispatched", "Total runs dispatched (per plugin)"),
        ("completed", "Total runs completed successfully (per plugin)"),
        ("failed", "Total runs that raised (per plugin)"),
        ("timed_out", "Total runs that exceeded max_run_seconds (per plugin)"),
        ("skipped_cross_pod", "Total dispatches skipped due to cross-pod claim (per plugin)"),
        ("skipped_at_capacity", "Total dispatches skipped at runner capacity (per plugin)"),
    ]
    for key, help_text in counter_series:
        metric_name = f"qs_polling_{key}_total"
        lines.append(f"# HELP {metric_name} {help_text}")
        lines.append(f"# TYPE {metric_name} counter")
        for name, t in sorted(telem_by_plugin.items()):
            snap = t.snapshot()
            lines.append(f'{metric_name}{{workflow="{_prom_escape(name)}"}} {snap[key]}')

    gauge_series = [
        ("duration_p50_s", "duration_p50_seconds", "Median dispatch duration (rolling window)"),
        ("duration_p99_s", "duration_p99_seconds", "99th percentile dispatch duration (rolling window)"),
    ]
    for snap_key, metric_suffix, help_text in gauge_series:
        metric_name = f"qs_polling_{metric_suffix}"
        lines.append(f"# HELP {metric_name} {help_text}")
        lines.append(f"# TYPE {metric_name} gauge")
        for name, t in sorted(telem_by_plugin.items()):
            snap = t.snapshot()
            lines.append(f'{metric_name}{{workflow="{_prom_escape(name)}"}} {snap[snap_key]}')

    # Active runs gauge
    lines.append("# HELP qs_polling_active_runs Currently in-flight runs (per plugin)")
    lines.append("# TYPE qs_polling_active_runs gauge")
    for name in sorted(active_by_plugin.keys()):
        lines.append(f'qs_polling_active_runs{{workflow="{_prom_escape(name)}"}} {active_by_plugin[name]}')

    # Alerter stats
    try:
        from polling_service.alerter import get_alerter
        alerter_snap = get_alerter().snapshot()
        lines.append("# HELP qs_polling_alerts_sent_total Total alert emails sent")
        lines.append("# TYPE qs_polling_alerts_sent_total counter")
        lines.append(f"qs_polling_alerts_sent_total {alerter_snap['alerts_sent']}")
        lines.append("# HELP qs_polling_alerts_throttled_total Total alerts suppressed by cooldown")
        lines.append("# TYPE qs_polling_alerts_throttled_total counter")
        lines.append(f"qs_polling_alerts_throttled_total {alerter_snap['alerts_throttled']}")
        lines.append("# HELP qs_polling_smtp_failures_total Total SMTP send failures")
        lines.append("# TYPE qs_polling_smtp_failures_total counter")
        lines.append(f"qs_polling_smtp_failures_total {alerter_snap['smtp_failures']}")
        lines.append("# HELP qs_polling_vault_consecutive_failures Consecutive vault cred-resolve failures (resets on success)")
        lines.append("# TYPE qs_polling_vault_consecutive_failures gauge")
        lines.append(f"qs_polling_vault_consecutive_failures {alerter_snap['vault_consecutive_failures']}")
    except Exception as exc:
        logger.warning("Failed to gather alerter snapshot for /metrics: %s", exc)

    # Dead-letter tracker series
    try:
        from polling_service.dead_letter import get_tracker
        dl_snap = get_tracker().snapshot()
        lines.append("# HELP qs_polling_dead_letters_emitted_total Number of RUN_IDs blocked by dead-letter")
        lines.append("# TYPE qs_polling_dead_letters_emitted_total counter")
        lines.append(f"qs_polling_dead_letters_emitted_total {dl_snap.get('dead_letters_emitted', 0)}")
        lines.append("# HELP qs_polling_dead_letter_tracked_run_ids Currently tracked RUN_IDs with at least one failure")
        lines.append("# TYPE qs_polling_dead_letter_tracked_run_ids gauge")
        lines.append(f"qs_polling_dead_letter_tracked_run_ids {dl_snap.get('tracked_run_ids', 0)}")
    except Exception as exc:
        logger.warning("Failed to gather dead-letter snapshot for /metrics: %s", exc)

    return PlainTextResponse("\n".join(lines) + "\n")


# 2026-07-01 hygiene -- dedicated 1-thread executor for readiness so
# the probe doesn't fight the shared default pool (bounded at
# ``thread_pool_workers`` = 16 by default).  Under a burst of
# dispatches the shared pool saturates + readiness probes queue for
# minutes + K8s flips the pod out of the service.  Now the readiness
# path has its OWN thread guaranteeing sub-10-second response
# regardless of dispatcher load.
_readiness_executor: Optional["concurrent.futures.ThreadPoolExecutor"] = None
_last_readiness_result: Optional[bool] = None
_last_readiness_at: float = 0.0
_READINESS_CACHE_TTL_S = 5.0


def _get_readiness_executor():
    """Return the process-wide readiness executor.  Built lazily on
    first call so we don't spin up a thread when readiness isn't
    used (e.g. embedded tests)."""
    global _readiness_executor
    if _readiness_executor is None:
        import concurrent.futures as _cf
        _readiness_executor = _cf.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="readiness",
        )
    return _readiness_executor


async def _oracle_check() -> bool:
    """Lightweight Oracle connectivity check (async). Fail-open — returns False on any error.

    2026-07-01 hygiene -- results cached for
    ``_READINESS_CACHE_TTL_S`` seconds so a burst of K8s probes
    (they run every 10s by default) doesn't storm Oracle with
    ``SELECT 1 FROM DUAL`` under load.  Also uses a dedicated
    executor so the check thread never queues behind dispatcher
    work in the shared pool.
    """
    global _last_readiness_result, _last_readiness_at
    now = time.time()
    if (
        _last_readiness_result is not None
        and (now - _last_readiness_at) < _READINESS_CACHE_TTL_S
    ):
        return _last_readiness_result
    try:
        loop = asyncio.get_running_loop()
        result = await asyncio.wait_for(
            loop.run_in_executor(_get_readiness_executor(),
                                    _oracle_manager.health_check),
            timeout=10.0,
        )
        _last_readiness_result = bool(result)
        _last_readiness_at = now
        return _last_readiness_result
    except asyncio.TimeoutError:
        logger.warning("Oracle readiness check timed out (10s)")
        _last_readiness_result = False
        _last_readiness_at = now
        return False
    except Exception as e:
        logger.warning(f"Oracle readiness check failed: {e}")
        _last_readiness_result = False
        _last_readiness_at = now
        return False
