"""
Generic dispatcher — routes any dag_type to its registered worker class.

Adding a new pipeline type requires:
  1. One new entry in WORKER_REGISTRY below
  2. A new section in config/step_mapping.yaml

No other code changes needed.

BF-595 (2026-05-30): when ``use_lightweight_steps=True`` is passed to
the constructor, dag_type ``createJob`` is rerouted to the
``createJob_light`` step_mapping.yaml section, which uses the
non-Spark Trino→Oracle steps (``LightStarburstToOracle_OnCloud`` /
``LightStarburstToOracle_OnPrem``).  This is the polling-service
default — Spark removed for <500K-row workloads.
"""
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from managers.oracle_metadata_manager import OracleMetadataManager
from polling_service.workflow_registry import (
    WorkflowDefinition,
    WorkflowRegistry,
    get_registry,
)

try:
    from datasources.starburst_datasource import StarburstDataSource
except ImportError as _sb_imp_exc:
    # 2026-07-01 -- log the ACTUAL exception at module load so
    # operators debugging "no Starburst clients" see the underlying
    # reason (missing module vs. bad transitive import inside the
    # module vs. pyspark missing).  Previously silent None
    # assignment made the downstream "check PYTHONPATH" error
    # misleading.
    logging.getLogger("bg_poller.dispatcher").info(
        "StarburstDataSource import failed at dispatcher module load "
        "-- Starburst-dependent workflows will be unavailable on "
        "this image.  Reason: %s: %s",
        type(_sb_imp_exc).__name__, _sb_imp_exc,
    )
    StarburstDataSource = None

from log_config import get_log_dir as _get_log_dir
LOG_DIR = _get_log_dir()
LOG_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


# ── Back-compat shim for WORKER_REGISTRY ────────────────────────────────
#
# Older tests + a handful of third-party callers import
# ``polling_service.dispatcher.WORKER_REGISTRY`` directly as a
# ``Dict[str, (worker_cls, needs_starburst)]``.  We keep the name as a
# READ-ONLY view onto the plugin registry so the shape they expect is
# preserved without re-introducing module-level dict mutation.  New code
# MUST consume ``WorkflowRegistry`` / ``get_registry()`` directly.
class _WorkerRegistryView:
    """Mapping view: name -> (worker_cls, needs_starburst_clients).

    Backed by ``polling_service.workflow_registry.get_registry()``.  Read-only
    from this side; the registry itself is the single source of truth.
    Workflows whose ``worker_cls()`` resolved to None (lightweight image
    + Spark-only worker) are silently absent from this view, matching the
    legacy ``if S3ToFileWorker is not None: WORKER_REGISTRY[...] = ...``
    behaviour 1:1.
    """

    def _snapshot(self) -> Dict[str, Tuple]:
        out: Dict[str, Tuple] = {}
        reg = get_registry()
        for d in reg:
            cls = d.worker_cls()
            if cls is None:
                continue
            out[d.name] = (cls, d.needs_starburst_clients)
            for alias in d.aliases:
                out[alias] = (cls, d.needs_starburst_clients)
        return out

    def __getitem__(self, key: str) -> Tuple:
        return self._snapshot()[key]

    def __contains__(self, key: str) -> bool:
        return key in self._snapshot()

    def __iter__(self):
        return iter(self._snapshot())

    def __len__(self) -> int:
        return len(self._snapshot())

    def keys(self):
        return self._snapshot().keys()

    def items(self):
        return self._snapshot().items()

    def values(self):
        return self._snapshot().values()

    def get(self, key, default=None):
        return self._snapshot().get(key, default)

    def __setitem__(self, key: str, value: Tuple) -> None:
        # 2026-06-29 — legacy test path: ``WORKER_REGISTRY["new"] = (Cls, bool)``.
        # Forward to the registry as a runtime override so the legacy write
        # surface stays operational without re-introducing the dict mutation
        # pattern in production code.  Plugin discovery is still the right
        # path for NEW workflows.
        if (not isinstance(value, tuple)) or len(value) != 2:
            raise TypeError(
                f"WORKER_REGISTRY[{key!r}] = {value!r}: expected "
                "(worker_cls, needs_starburst_bool) tuple"
            )
        worker_cls, needs_sb = value
        reg = get_registry()
        existing = reg.get(key)
        reg.register(WorkflowDefinition(
            name=key,
            worker_cls_loader=(lambda c=worker_cls: c),
            dag_id_patterns=existing.dag_id_patterns if existing else (key.lower(),),
            db_connection_patterns=existing.db_connection_patterns if existing else (key.upper(),),
            needs_starburst_clients=bool(needs_sb),
            lightweight_capable=existing.lightweight_capable if existing else True,
            aliases=existing.aliases if existing else (),
            priority=existing.priority if existing else 100,
        ))


WORKER_REGISTRY = _WorkerRegistryView()


class Dispatcher:
    """Generic dispatcher — mirrors oracle_standalone.execute_tasks() exactly.

    For each run, instantiates the correct worker via WORKER_REGISTRY, builds
    Starburst clients (if needed), attaches shared context to each task dict,
    then executes each step sequentially — stopping on first failure.

    Note on step_mapping.yaml path: OracleWorker/SapOdataWorker load their
    step mappings from the path hardcoded in each worker class
    (/usr/local/spark/pvc/code/configs/step_mapping.yaml — the production PVC).
    The Dockerfile symlinks /app/config/step_mapping.yaml to that path for
    dev/test environments. No path override is needed here.

    BF-595 / BF-596: ``use_lightweight_steps`` controls Spark vs non-Spark
    routing.  Default False to preserve back-compat with sap_odata_standalone
    / oracle_standalone callers; polling service sets it True.

    BF-596 (2026-05-30): replaced the YAML-section-swap approach
    (createJob_light) with in-memory Python-class swaps via
    LIGHTWEIGHT_STEP_SWAPS.  Rationale: the DB row's TASK_TYPE column
    is the step name (per oracle_standalone.py:54 — ``TASK_TYPE AS
    Task_steps``), so any routing decision driven by a parallel YAML
    section would force operators to either maintain two YAMLs in
    sync OR add new DB rows.  Swapping in-memory keeps the YAML as
    a pure step-name → Python-class CONTRACT and lets the polling
    service flip Spark off via a single config flag, no YAML/DB
    changes required.
    """

    # BF-596: in-memory Python-class swaps applied AFTER
    # ``worker.load_step_mapping(dag_type)`` returns.  Operators do
    # NOT touch this — it's a dispatcher implementation detail.
    # Format: step_name (matches DB TASK_TYPE) → (module_path, class_name).
    # Lazy import via __import__ so the polling-service image doesn't
    # need to load the light step modules until they're actually needed.
    LIGHTWEIGHT_STEP_SWAPS: Dict[str, Tuple[str, str]] = {
        "StarburstToOracleOnCloud": (
            "steps.oracle.light_starburst_to_oracle_oncloud",
            "LightStarburstToOracle_OnCloud",
        ),
        "StarburstToOracleOnPrem": (
            "steps.oracle.light_starburst_to_oracle_onprem",
            "LightStarburstToOracle_OnPrem",
        ),
    }

    def __init__(
        self,
        logger: logging.Logger,
        use_lightweight_steps: bool = False,
        registry: Optional[WorkflowRegistry] = None,
        shared_oracle_manager: Optional["OracleMetadataManager"] = None,
    ):
        self.logger = logger
        self.use_lightweight_steps = bool(use_lightweight_steps)
        # 2026-06-29 — registry is the plugin-discovered single source of
        # truth for "name -> worker_cls + needs_starburst".  Default to the
        # process-wide singleton.  Tests can inject a custom registry for
        # isolation.
        self.registry = registry if registry is not None else get_registry()
        # 2026-06-29 deep-dive #2 fix: reuse a SHARED OracleMetadataManager
        # across runs so the underlying oracledb pool is shared, not one
        # pool per run.  When None (legacy callers + tests), the dispatcher
        # falls back to per-run construction (old behaviour, documented
        # as pool-leak risk under burst dispatch).
        self.shared_oracle_manager = shared_oracle_manager
        if self.use_lightweight_steps:
            self.logger.info(
                "Dispatcher: lightweight (no-Spark) mode enabled — "
                "step classes %s will be swapped to their Light* variants "
                "at runtime (YAML unchanged, DB unchanged).",
                sorted(self.LIGHTWEIGHT_STEP_SWAPS.keys()),
            )
            # 2026-07-01 fix (item #13) -- verify EVERY swap-target
            # module + class actually imports at boot so a missing
            # light variant surfaces at Dispatcher construction (early,
            # visible in the pod-start banner) rather than at the
            # first dispatch (which may happen hours after pod ready).
            # This is a smoke check: we import the modules but don't
            # keep references (no memory cost).  Failures become
            # RuntimeError with the same message _apply_lightweight_swaps
            # would raise later, so operators see identical guidance
            # whether the failure surfaces at boot or at first dispatch.
            self._validate_lightweight_swaps_available()

    def _validate_lightweight_swaps_available(self) -> None:
        """Verify every module + class listed in
        ``LIGHTWEIGHT_STEP_SWAPS`` can be imported.  Raises RuntimeError
        with an actionable message on any failure so pod-start crashes
        early instead of at first dispatch."""
        import importlib
        _import_errors = []
        for step_name, (module_path, class_name) in self.LIGHTWEIGHT_STEP_SWAPS.items():
            try:
                mod = importlib.import_module(module_path)
                _ = getattr(mod, class_name)
            except (ImportError, AttributeError) as exc:
                _import_errors.append(
                    f"  * {step_name}: {module_path}.{class_name} "
                    f"({type(exc).__name__}: {exc})"
                )
        if _import_errors:
            raise RuntimeError(
                "BF-596: lightweight step swap validation failed at "
                "Dispatcher init — one or more Light* variants cannot "
                "be imported.  The polling service would fail at first "
                "dispatch; raising now for early visibility.  Install "
                "the missing modules OR disable ``use_lightweight_steps`` "
                "(``BG_USE_LIGHTWEIGHT=false`` env var).  Failures:\n"
                + "\n".join(_import_errors)
            )
        self.logger.info(
            "Dispatcher: verified %d lightweight step swap(s) are "
            "importable at boot.", len(self.LIGHTWEIGHT_STEP_SWAPS),
        )

    def _apply_lightweight_swaps(self, step_mapping: dict) -> dict:
        """BF-596: overlay the lightweight Python classes on top of the
        YAML-loaded step_mapping for any step name in LIGHTWEIGHT_STEP_SWAPS.

        Returns the same dict object with selected entries replaced.
        Steps NOT in the swap table are left as-is (so polling-pod
        workflows that mix Trino→Oracle with other steps work normally
        — only the Spark-heavy ones get swapped).

        Lazy-imports the light modules to keep import-time cost zero
        when lightweight mode is disabled (e.g. unit-test loops that
        construct dispatchers in tight cycles).
        """
        if not step_mapping:
            return step_mapping
        import importlib
        swapped = []
        for step_name, (module_path, class_name) in self.LIGHTWEIGHT_STEP_SWAPS.items():
            if step_name not in step_mapping:
                # Step isn't in this workflow's mapping — nothing to swap.
                continue
            try:
                mod = importlib.import_module(module_path)
                light_class = getattr(mod, class_name)
                step_mapping[step_name] = light_class
                swapped.append(step_name)
            except (ImportError, AttributeError) as exc:
                # Hard fail — caller asked for lightweight mode and we
                # can't deliver.  Don't silently fall back to Spark
                # (would re-introduce the memory-bomb in a pod that
                # doesn't have the JVM).
                raise RuntimeError(
                    f"BF-596: lightweight swap for step '{step_name}' "
                    f"failed: cannot import {module_path}.{class_name} "
                    f"({exc}).  Either install the light variant or "
                    f"disable use_lightweight_steps."
                ) from exc
        if swapped:
            self.logger.info(
                f"Lightweight mode: swapped {len(swapped)} step class(es) "
                f"to Light* variants: {swapped}"
            )
        return step_mapping

    async def execute(
        self,
        run_id: int,
        tasks: List[dict],
        dag_type: str,
        etl_conn_str: str,
        dest_conn_str: str,
    ) -> None:
        """Execute all steps for one RUN_ID sequentially.

        Args:
            run_id: Oracle RUN_ID (for logging only; already in each task dict)
            tasks:  List of task dicts sorted by SEQ (from Oracle query)
            dag_type: Worker type key from WORKER_REGISTRY (createJob/file/sap_odata)
            etl_conn_str:  Oracle ETL connection string (worker DB)
            dest_conn_str: Oracle destination connection string
        """
        # 2026-06-29 — resolve via plugin WorkflowRegistry (single source).
        wf_def = self.registry.get(dag_type)
        if wf_def is None:
            raise ValueError(
                f"Unknown dag_type {dag_type!r} for run_id={run_id}. "
                f"Either drop a worker module with WORKFLOW_DEF={dag_type!r} "
                f"into the ``workers`` package (plugin auto-discovery) or "
                f"set worker_class_path on the polling YAML workflow entry."
            )
        worker_cls = wf_def.worker_cls()
        if worker_cls is None:
            raise ValueError(
                f"Workflow {dag_type!r} is registered but its worker class "
                f"cannot be loaded on this image (likely pyspark missing on "
                f"the lightweight pod).  Disable the workflow in polling YAML "
                f"or run on the Spark-capable image variant."
            )
        if wf_def.is_deprecated:
            self.logger.warning(
                "Workflow %r is DEPRECATED — migrate OTG_DAG_ID to the new "
                "naming.  See workers/s3_worker.py for the s3_query→s3_to_* "
                "split, etc.", dag_type,
            )
        needs_starburst = wf_def.needs_starburst_clients
        first_task = tasks[0]

        # 2026-06-29 — reuse the shared OracleMetadataManager when
        # BackgroundService injected one (modern path), else fall back to
        # per-run construction (legacy callers + tests).  Sharing avoids
        # one oracledb pool per run; the underlying pool is thread-safe.
        if self.shared_oracle_manager is not None:
            oracle_mgr = self.shared_oracle_manager
        else:
            oracle_mgr = OracleMetadataManager(etl_conn_str)

        # Build log file path (same format as oracle_standalone.py)
        log_file = _build_log_file(
            str(first_task.get("fk_dag_id", "unknown")),
            int(first_task.get("fk_report_id", 0)),
            str(first_task.get("business_date", "unknown")),
        )
        # 2026-07-02 -- pin the process-level run log so steps whose
        # task['log_file'] is dropped mid-flight (subprocess handoff,
        # legacy call sites) still land in THIS file rather than a
        # per-step LOG_PREFIX fallback filename.
        #
        # BOTH pins are ContextVar-scoped inside log_config so
        # concurrent workflow runs in this same pod (poller uses
        # asyncio.gather) keep distinct log-file + workflow-name
        # values per asyncio task.
        try:
            from log_config import set_run_log_file, set_workflow_name
            set_run_log_file(log_file)
            # Workflow name is dag_type at this point (createJob /
            # file / sap_odata / s3_to_file / s3_to_oracle / ...).
            set_workflow_name(str(dag_type) if dag_type else "bg_poller")
        except Exception:
            pass

        # BF-595 / BF-596: lightweight (no-Spark) mode does NOT touch
        # the YAML routing — `worker.load_step_mapping(dag_type)`
        # returns the standard ``createJob`` / ``file`` / ``sap_odata``
        # section.  Instead we overlay Python-class swaps in memory
        # via ``_apply_lightweight_swaps`` so the DB row's TASK_TYPE
        # column still drives selection AND operators don't maintain
        # a parallel YAML.
        if needs_starburst:
            # BF-595: the light Starburst→Oracle steps do NOT consume the
            # StarburstDataSource clients (they use trino-python-client
            # directly via the step's own config).  Skip the heavy client
            # build in lightweight mode — pass an empty dict to preserve
            # the task['starburst_clients'] contract for non-Starburst
            # steps in the same workflow (CheckDependencies, GenerateSQL, …).
            if self.use_lightweight_steps:
                starburst_clients = {}
            else:
                starburst_clients = _build_starburst_clients(first_task, self.logger)
            worker = worker_cls(starburst_clients, oracle_mgr, self.logger)
            worker.step_mapping = worker.load_step_mapping(dag_type)
            if self.use_lightweight_steps:
                worker.step_mapping = self._apply_lightweight_swaps(worker.step_mapping)
        else:
            worker = worker_cls(oracle_mgr, self.logger)
            starburst_clients = {}

        # Attach shared context to each task dict — steps may read these fields
        dag_run_id = f"bg_run_{run_id}"
        # 2026-06-12 — per-run STABLE sidecar location (decoupled from
        # per-row file_location).  See file_standalone.py for rationale:
        # different polling rows for CLOUD vs ONPREM vs ConsolidateFiles
        # vs CompressFile vs CreateControlFile can carry different
        # file_location values; the sidecar must live in ONE place
        # across them or cross-step state is lost.
        sidecar_dir = os.path.dirname(log_file) if log_file else ""
        # 2026-06-13 — per-run backup_ts for the "rename prior file to
        # backup folder" feature.  Same shape as the standalone.
        backup_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        # 2026-06-13 — prior-output handling: "backup" or "delete".
        # Polling row's PRIOR_OUTPUT_MODE column wins; default "backup".
        # 2026-07-01 hygiene -- ``PRIOR_OUTPUT_MODE`` uppercase branch
        # removed.  ``oracle_metadata_manager.get_all_start_tasks``
        # lowercases every polling-row column at line 714, so the
        # uppercase key is unreachable by construction.
        prior_output_mode = (
            first_task.get("prior_output_mode")
            or "backup"
        )
        for task in tasks:
            task["starburst_clients"] = starburst_clients
            task["log_file"] = log_file
            task["dag_run_id"] = dag_run_id
            task["task_id"] = task.get("run_id", run_id)
            # 2026-06-12 — promote the polling-row FILE_LOCATION (or
            # equivalent column) onto task["output_dir"] so the file
            # output lands where the polling row says it should.
            fl = (
                task.get("file_location")
                or task.get("output_file_location")
                or task.get("output_dir")
            )
            if fl:
                task["output_dir"] = fl
            # Sidecar location is stable across all tasks in this run;
            # save_task_state / hydrate_task_from_sidecar prefer this
            # over per-task output_dir.
            if sidecar_dir:
                task["sidecar_dir"] = sidecar_dir
            task["backup_ts"] = backup_ts
            task["prior_output_mode"] = prior_output_mode

        self.logger.info(
            f"run_id={run_id} dag_type={dag_type} steps={[t.get('task_steps') for t in tasks]}"
        )

        # 2026-06-12 -- pre-run sidecar hygiene (parity with standalones).
        # Back up any sidecar from a PRIOR failed run with the same run_id
        # so a fresh dispatch starts with a clean slate.  Reads at the
        # per-run-stable sidecar_dir (log dir); also covers legacy per-row
        # file_location sidecars from older builds.
        if sidecar_dir or first_task.get("file_location"):
            try:
                from steps.file.run_state import backup_stale_sidecar
                _seen_backups = set()
                for _t in tasks:
                    _bases = []
                    if sidecar_dir:
                        _bases.append(sidecar_dir)
                    _legacy = (
                        _t.get("file_location")
                        or _t.get("output_file_location")
                        or _t.get("output_dir")
                    )
                    if _legacy and _legacy not in _bases:
                        _bases.append(_legacy)
                    _rid = _t.get("run_id")
                    for _b in _bases:
                        _key = (_b, _rid)
                        if _key in _seen_backups:
                            continue
                        _seen_backups.add(_key)
                        try:
                            backup_stale_sidecar(_b, _rid, logger=self.logger)
                        except Exception as _bkp_exc:
                            # 2026-07-01 hygiene -- was uncaught inside
                            # the loop; a single bad row shape would
                            # bail on the entire sidecar sweep for the
                            # whole dispatch batch.  Isolate per-row.
                            self.logger.warning(
                                "Sidecar backup skipped for base=%s "
                                "run_id=%s: %s: %s",
                                _b, _rid,
                                type(_bkp_exc).__name__, _bkp_exc,
                            )
            except ImportError:
                # Non-file workflow -- steps.file.run_state doesn't
                # exist on this image.  Log at DEBUG (not silent) so
                # the reason is greppable when debugging "why isn't
                # my sidecar being backed up".
                self.logger.debug(
                    "Sidecar backup skipped: steps.file.run_state not "
                    "importable (non-file workflow)."
                )

        # Execute steps sequentially — same as oracle_standalone.execute_tasks()
        # _all_succeeded flips True only AFTER every task in the loop
        # completes without exception.  Using "did it succeed" rather
        # than "did it fail" so BaseException (KeyboardInterrupt,
        # asyncio.CancelledError) ALSO leaves the sidecar untouched --
        # cancellation mid-run is a forensic-keep case too.
        _all_succeeded = False
        try:
            for task in tasks:
                step_name = task.get("task_steps", "")
                if not step_name:
                    self.logger.warning(
                        f"run_id={run_id}: task row has no task_steps — skipping (seq={task.get('seq')})"
                    )
                    continue
                try:
                    await worker.execute_step(
                        task,
                        etl_conn_str,
                        dest_conn_str,
                        step_name,
                    )
                except Exception as e:
                    self.logger.error(
                        f"run_id={run_id} step={step_name} failed — halting run: {e}"
                    )
                    raise  # Poller._execute_run catches this and records failure
            _all_succeeded = True
        finally:
            # 2026-06-12 -- on SUCCESS, delete the sidecar (cross-step
            # handoff aid; once the run completes it's just clutter on
            # NFS).  On ANY non-success exit (Exception, KeyboardInterrupt,
            # CancelledError) keep it for forensics.  Parity with
            # standalones.
            if _all_succeeded:
                try:
                    from steps.file.run_state import delete_sidecar
                    _seen_deletes = set()
                    for _t in tasks:
                        _bases = []
                        _sd = _t.get("sidecar_dir")
                        if _sd:
                            _bases.append(_sd)
                        _fallback = _t.get("output_dir") or _t.get("file_location")
                        if _fallback and _fallback not in _bases:
                            _bases.append(_fallback)
                        _rid = _t.get("run_id")
                        for _b in _bases:
                            _key = (_b, _rid)
                            if _key in _seen_deletes:
                                continue
                            _seen_deletes.add(_key)
                            try:
                                delete_sidecar(_b, _rid, logger=self.logger)
                            except Exception as _del_exc:
                                # 2026-07-01 hygiene -- per-row isolate
                                # so one bad row doesn't skip cleanup
                                # for the rest of the batch.
                                self.logger.warning(
                                    "Sidecar delete skipped for base=%s "
                                    "run_id=%s: %s: %s",
                                    _b, _rid,
                                    type(_del_exc).__name__, _del_exc,
                                )
                except ImportError:
                    self.logger.debug(
                        "Sidecar delete skipped: steps.file.run_state "
                        "not importable (non-file workflow)."
                    )


def _build_log_file(dag_id: str, report_id: int, business_date: str) -> str:
    """Build a log filename that matches oracle_standalone.py format.

    2026-07-02 -- retention sweep BEFORE returning: keep 1 previous
    ``bg_poller_{dag}_{report}_*.log`` so the newly-created log makes
    exactly 2 total per (dag, report) tuple.  User directive:
    "keep only last 2 run logs and delete old ones".  Fail-open.
    """
    safe_dag = dag_id.replace("/", "_").replace("\\", "_").replace(" ", "_")[:60]
    ts = datetime.now().strftime("%H%M%S")
    safe_date = str(business_date).replace("/", "-").replace(" ", "_")[:20]
    filename = f"bg_poller_{safe_dag}_{report_id}_{safe_date}_{ts}.log"
    log_path = os.path.join(LOG_DIR, filename)
    try:
        from log_retention import prune_old_logs
        prune_old_logs(
            log_dir=LOG_DIR,
            prefix=f"bg_poller_{safe_dag}_{report_id}_",
            keep=1,
        )
    except Exception:
        pass
    return log_path


def _build_starburst_clients(first_task: dict, logger: logging.Logger) -> dict:
    """Build Starburst client dict from polling row + shared config fallback.

    2026-06-12 — delegates to ``starburst_config_loader.build_starburst_clients_from_row``
    so this path and ``oracle_standalone.execute_tasks`` use ONE merge
    implementation (single source of truth for the polling-row -> shared-YAML
    fallback chain).
    """
    if StarburstDataSource is None:
        raise RuntimeError(
            "StarburstDataSource could not be imported "
            "(check datasources/starburst_datasource.py is on PYTHONPATH). "
            "Required for createJob/file dag types."
        )
    from starburst_config_loader import build_starburst_clients_from_row
    return build_starburst_clients_from_row(
        first_task, StarburstDataSource, logger=logger,
    )
