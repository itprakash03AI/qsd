"""Service-level alerter — emails ops on critical polling conditions.

Triggers:
  * ``poll_loop_crash``      — fired by ``BackgroundService._on_poll_done``
                                when the poll loop dies unexpectedly
  * ``startup_failure``      — fired by ``main.py`` when discovery /
                                validation refuses to start the service
  * ``vault_outage``         — fired after N consecutive cred-resolve
                                failures (default 5) — Vault likely down
  * ``high_failure_rate``    — fired when a plugin's failure rate over
                                the recent sliding window exceeds the
                                configured threshold
  * ``cross_pod_degraded``   — fired when ``try_claim_run`` fail-opens
                                repeatedly — DBMS_LOCK is unhealthy
  * ``shutdown_hook_hang``   — fired when a lifecycle hook exceeds the
                                hook_timeout_seconds during shutdown

Rate limiting:
  * Each (trigger, plugin_name) pair is throttled to ONE email per
    ``cooldown_seconds`` (default 300 = 5 minutes) so an outage doesn't
    flood ops with duplicates.

Channels:
  * Email via stdlib ``smtplib`` — uses the SMTP_HOST / SMTP_PORT /
    EMAIL_FROM / EMAIL_TO / SMTP_USER / SMTP_PASSWORD env vars that the
    Helm configmap renders into runtime.env when ``config.email.enabled``.
  * Disabled (no-op) when SMTP_HOST is unset → dev / local runs work
    without SMTP config.

Persistence:
  * State (last-sent-at per (trigger, plugin), recent-failure window)
    lives in-process.  Restarting the pod resets the throttles —
    intentional, so a freshly-started pod can immediately raise an
    alert that was previously throttled.
"""
from __future__ import annotations

import collections
import logging
import os
import smtplib
import socket
import threading
import time
from email.mime.text import MIMEText
from typing import Deque, Dict, List, Optional, Tuple


logger = logging.getLogger(__name__)


def _scrub(text: str) -> str:
    """Apply the shared credential scrubber to arbitrary user-supplied
    text before it enters an alert payload.  Lazy import so the
    registry module doesn't need to be loaded when the alerter is
    used in a hermetic test.  Never raises."""
    if not text:
        return ""
    try:
        from polling_service.workflow_registry import _sanitize_reason
        return _sanitize_reason(str(text))
    except Exception:                                                # pragma: no cover
        # Fallback: return type + length so we never leak on error.
        return f"[unscrubbed-len={len(str(text))}]"


# ── trigger payload ────────────────────────────────────────────────────


class AlertEvent:
    """Lightweight DTO describing one alert event.

    Why not a dataclass: alert events are constructed at hot paths
    (every dispatch failure) — a frozen dataclass with field validation
    would add zero value at high QPS.  Plain object is fine."""

    __slots__ = ("trigger", "plugin", "message", "severity", "details")

    def __init__(
        self,
        trigger: str,
        plugin: str = "",
        message: str = "",
        severity: str = "ERROR",
        details: Optional[Dict[str, str]] = None,
    ) -> None:
        self.trigger = trigger
        self.plugin = plugin
        self.message = message
        self.severity = severity
        self.details = details or {}


# ── alerter ────────────────────────────────────────────────────────────


class PluginAlerter:
    """Send + throttle alerts on critical polling-service conditions.

    Construction:
      ``alerter = PluginAlerter.from_env()`` — reads SMTP_* env vars
                                                that runtime.env exports

    Usage from poll-loop / runner code:
      ``alerter.alert(AlertEvent(trigger="poll_loop_crash",
                                  message=str(exc), severity="CRITICAL"))``

    Sliding-window helper:
      ``alerter.record_outcome(plugin, success: bool)`` — feeds the
      per-plugin failure-rate sliding window.  When threshold is
      exceeded, the alerter auto-emits ``high_failure_rate``.

    Cross-pod degradation helper:
      ``alerter.record_cross_pod_degradation(reason)`` — feeds the
      cross-pod-claim degradation counter.  Threshold breach emits.

    Vault outage helper:
      ``alerter.record_vault_failure()`` — feeds the consecutive-vault-
      failure counter.  Threshold breach emits.  ``record_vault_success()``
      resets the counter.
    """

    DEFAULT_COOLDOWN_S = 300
    DEFAULT_FAILURE_WINDOW_SIZE = 20
    DEFAULT_FAILURE_RATE_THRESHOLD = 0.5      # 50% failures over window
    DEFAULT_VAULT_OUTAGE_THRESHOLD = 5         # 5 consecutive failures
    DEFAULT_CROSS_POD_DEGRADED_THRESHOLD = 10  # 10 fail-opens in window

    def __init__(
        self,
        smtp_host: str = "",
        smtp_port: int = 25,
        smtp_user: str = "",
        smtp_password: str = "",
        smtp_use_tls: bool = False,
        email_from: str = "",
        email_to: str = "",
        cooldown_seconds: int = DEFAULT_COOLDOWN_S,
        failure_window_size: int = DEFAULT_FAILURE_WINDOW_SIZE,
        failure_rate_threshold: float = DEFAULT_FAILURE_RATE_THRESHOLD,
        vault_outage_threshold: int = DEFAULT_VAULT_OUTAGE_THRESHOLD,
        cross_pod_degraded_threshold: int = DEFAULT_CROSS_POD_DEGRADED_THRESHOLD,
        worker_id: str = "",
        # Test hook: inject a fake sender to avoid hitting real SMTP.
        sender: Optional[callable] = None,
    ) -> None:
        self.smtp_host = smtp_host.strip()
        self.smtp_port = int(smtp_port or 25)
        self.smtp_user = smtp_user
        self.smtp_password = smtp_password
        self.smtp_use_tls = bool(smtp_use_tls)
        # 2026-07-01 -- WARN when creds are set but TLS isn't.  Plain
        # SMTP AUTH ships the credentials in cleartext -- if the
        # operator forgot to flip SMTP_USE_TLS=1 this is a real
        # security issue.  Log once at construction time so the
        # signal is visible in the pod-start banner.
        if (self.smtp_user or self.smtp_password) and not self.smtp_use_tls:
            logger.warning(
                "Alerter: SMTP_USER / SMTP_PASSWORD set but SMTP_USE_TLS "
                "is FALSE -- credentials will be transmitted in cleartext.  "
                "Set SMTP_USE_TLS=1 in the Helm chart to enable STARTTLS."
            )
        self.email_from = email_from
        self.email_to = email_to
        self.cooldown_seconds = cooldown_seconds
        self.failure_window_size = failure_window_size
        self.failure_rate_threshold = failure_rate_threshold
        self.vault_outage_threshold = vault_outage_threshold
        self.cross_pod_degraded_threshold = cross_pod_degraded_threshold
        self.worker_id = worker_id or socket.gethostname()
        self._sender = sender

        # Throttle state: (trigger, plugin) -> last-emit timestamp
        self._last_emit: Dict[Tuple[str, str], float] = {}
        self._lock = threading.Lock()

        # Sliding windows per plugin (1 = success, 0 = failure)
        self._outcome_windows: Dict[str, Deque[int]] = {}

        # Vault consecutive-failure counter
        self._vault_consecutive_failures = 0

        # Cross-pod degradation window
        self._cross_pod_window: Deque[float] = collections.deque(maxlen=cross_pod_degraded_threshold)

        # Stats — exposed via /health for ops visibility
        self.stats = {
            "alerts_sent": 0,
            "alerts_throttled": 0,
            "smtp_failures": 0,
            "last_alert_at": "",
            "last_alert_trigger": "",
            "smtp_saturated_drops": 0,
        }

        # 2026-07-01 hotfix -- BOUNDED SMTP send pool.  Previous
        # implementation spawned a fresh daemon Thread per alert.
        # Under a burst (poll_loop_crash + high_failure_rate +
        # cross_pod_degraded firing at once, each with a 30s SMTP
        # timeout) the thread count could grow unbounded — and threads
        # aren't free (each takes ~1 MB stack).  Cap at 4 concurrent
        # sends; overflow is DROPPED with a counter bump so bursts
        # don't starve the event loop / OOM the pod.  Lazy-built on
        # first send so unit tests injecting ``sender=`` (inline path)
        # never touch it.
        self._send_pool = None                                        # type: ignore[assignment]
        self._send_pool_lock = threading.Lock()
        self._send_pool_max_workers = 4

    # ── factory ──────────────────────────────────────────────────────

    @classmethod
    def from_env(cls, worker_id: str = "") -> "PluginAlerter":
        """Construct from the SMTP_* env vars that runtime.env exports
        when ``config.email.enabled=true`` in Helm.  Missing SMTP_HOST
        yields a no-op alerter (logs warnings but skips email send) so
        local / dev runs work without SMTP config."""
        # ``SMTP_USE_TLS`` is sometimes rendered as a Helm boolean ("true")
        # and sometimes as a string — accept both forms.
        use_tls = str(os.environ.get("SMTP_USE_TLS", "")).strip().lower() in (
            "1", "true", "yes", "on",
        )
        return cls(
            smtp_host=os.environ.get("SMTP_HOST", "").strip(),
            smtp_port=int(os.environ.get("SMTP_PORT", "25") or 25),
            smtp_user=os.environ.get("SMTP_USER", "") or "",
            smtp_password=os.environ.get("SMTP_PASSWORD", "") or "",
            smtp_use_tls=use_tls,
            email_from=os.environ.get("EMAIL_FROM", "") or "",
            email_to=os.environ.get("EMAIL_TO", "") or "",
            worker_id=worker_id,
        )

    # ── core alert path ──────────────────────────────────────────────

    def alert(self, event: AlertEvent) -> bool:
        """Send the alert if not throttled.  Returns True if sent,
        False if throttled / disabled / SMTP failed."""
        if not self._enabled():
            return False
        key = (event.trigger, event.plugin or "")
        now = time.time()
        with self._lock:
            last = self._last_emit.get(key, 0.0)
            if now - last < self.cooldown_seconds:
                self.stats["alerts_throttled"] += 1
                logger.debug(
                    "Alert THROTTLED: trigger=%s plugin=%s (last sent %ds ago, "
                    "cooldown %ds)",
                    event.trigger, event.plugin, int(now - last),
                    self.cooldown_seconds,
                )
                return False
            self._last_emit[key] = now

        # 2026-07-01 fix -- ``_send`` calls ``smtplib.SMTP(..., timeout=30)``
        # which is BLOCKING IO.  When invoked from a coroutine context
        # (workflow_runner.alert()) it blocks the asyncio event loop for
        # up to 30s per alert.  Under a burst (poll_loop_crash +
        # high_failure_rate + cross_pod_degraded firing at once) the
        # health / readiness endpoints time out and K8s marks the pod
        # NotReady -- exactly the wrong outcome during an incident.
        #
        # Fire the SMTP send on a background daemon thread so the
        # caller returns immediately.  Alert delivery is
        # fire-and-forget by design (record_outcome / record_vault_failure
        # feed this, they don't await the SMTP result).  Return value
        # loses meaning under this model: we optimistically report
        # ``True`` to keep the throttle-counter contract (last_emit
        # advances) and let the background sender log its own success
        # or failure.  Callers that were checking the return value
        # already treated False as "we tried but failed" -- our new
        # return of True says "we scheduled it".
        def _send_background():
            try:
                ok = self._send(event)
                with self._lock:
                    if ok:
                        self.stats["alerts_sent"] += 1
                        self.stats["last_alert_at"] = time.strftime(
                            "%Y-%m-%dT%H:%M:%SZ", time.gmtime()
                        )
                        self.stats["last_alert_trigger"] = event.trigger
                    else:
                        self.stats["smtp_failures"] += 1
            except Exception as exc:
                # Absolute worst case -- log + increment failure counter
                # so the caller never has a dangling thread that panics.
                logger.error(
                    "Alerter background send crashed: %s: %s",
                    type(exc).__name__, exc,
                )
                with self._lock:
                    self.stats["smtp_failures"] += 1

        # Test injection path: sync inline (kept for deterministic tests
        # that assert on stats immediately after alert()).
        if self._sender is not None:
            _send_background()
            return True

        # Production path: fire-and-forget onto a BOUNDED ThreadPool
        # (max=self._send_pool_max_workers) so a burst of triggers
        # can't spawn unbounded daemon threads.  Pool built lazily.
        pool = self._get_send_pool()
        try:
            pool.submit(_send_background)
        except RuntimeError:
            # Pool is being shut down (mid-service-shutdown burst) —
            # fall through to inline send so the alert isn't lost.
            _send_background()
        except Exception as _submit_exc:
            # Executor.submit raises when the internal work queue is
            # unavailable; log + count so ops can see saturation.
            logger.warning(
                "Alerter send-pool submit failed (%s: %s) — "
                "dropping alert '%s' to preserve pod stability",
                type(_submit_exc).__name__, _submit_exc, event.trigger,
            )
            # 2026-07-01 hotfix-2 -- REVERT the cooldown-slot consume
            # since we didn't actually schedule a send.  Without this
            # a run of submit failures would silently swallow the
            # entire cooldown window (5 min default) even though no
            # alert reached the operator.
            with self._lock:
                self.stats["smtp_saturated_drops"] += 1
                self._last_emit.pop(key, None)
            return False
        return True

    def _get_send_pool(self):
        """Lazily build the bounded ThreadPoolExecutor.  We cap the
        internal work queue implicitly at ``max_workers * 2`` by
        checking approximate pending-task count before submit — see
        the guard in ``alert()`` above."""
        with self._send_pool_lock:
            if self._send_pool is not None:
                return self._send_pool
            from concurrent.futures import ThreadPoolExecutor
            self._send_pool = ThreadPoolExecutor(
                max_workers=self._send_pool_max_workers,
                thread_name_prefix="alerter-send",
            )
            return self._send_pool

    def shutdown(self, wait: bool = False) -> None:
        """Release the bounded SMTP send pool.  Called from
        ``BackgroundService.shutdown``; best-effort — pool cleanup on
        interpreter exit is fine on its own for K8s SIGKILL."""
        with self._send_pool_lock:
            pool = self._send_pool
            self._send_pool = None
        if pool is not None:
            try:
                pool.shutdown(wait=wait, cancel_futures=True)
            except Exception as _shutdown_exc:                       # pragma: no cover
                logger.debug(
                    "Alerter._send_pool shutdown raised %r — swallowing",
                    _shutdown_exc,
                )

    # ── sliding-window helpers (auto-emit on threshold breach) ───────

    def record_outcome(self, plugin: str, success: bool) -> None:
        """Feed the per-plugin failure-rate sliding window.  Auto-emits
        ``high_failure_rate`` when the window's failure ratio exceeds
        ``failure_rate_threshold``."""
        if not plugin:
            return
        with self._lock:
            window = self._outcome_windows.setdefault(
                plugin,
                collections.deque(maxlen=self.failure_window_size),
            )
            window.append(1 if success else 0)
            if len(window) < self.failure_window_size:
                return  # need a full window before triggering
            failure_rate = 1.0 - (sum(window) / len(window))

        if failure_rate >= self.failure_rate_threshold:
            self.alert(AlertEvent(
                trigger="high_failure_rate",
                plugin=plugin,
                severity="ERROR",
                message=(
                    f"Plugin {plugin!r}: failure rate {failure_rate:.0%} "
                    f"over last {self.failure_window_size} dispatches "
                    f"(threshold {self.failure_rate_threshold:.0%})"
                ),
                details={"failure_rate": f"{failure_rate:.2%}",
                         "window_size": str(self.failure_window_size)},
            ))

    def record_vault_failure(self, error: str = "") -> None:
        """Feed consecutive-vault-failure counter.  Threshold breach
        emits ``vault_outage``."""
        with self._lock:
            self._vault_consecutive_failures += 1
            count = self._vault_consecutive_failures
        if count >= self.vault_outage_threshold:
            self.alert(AlertEvent(
                trigger="vault_outage",
                severity="CRITICAL",
                message=(
                    f"Vault appears DOWN: {count} consecutive cred-resolve "
                    f"failures (threshold {self.vault_outage_threshold}).  "
                    f"Every workflow that depends on vault creds will fail "
                    f"until Vault recovers."
                ),
                details={"consecutive_failures": str(count),
                         # 2026-07-01 hotfix-2 -- scrub before store,
                         # not just before log.  Prior version emitted
                         # the raw exception body verbatim into the
                         # SMTP payload -> JWT / DSN / token exposure.
                         "last_error": _scrub(error)[:200]},
            ))

    def record_vault_success(self) -> None:
        with self._lock:
            self._vault_consecutive_failures = 0

    def record_cross_pod_degradation(self, reason: str = "") -> None:
        """Feed the cross-pod claim degradation window.  Threshold
        breach emits ``cross_pod_degraded`` — DBMS_LOCK is unhealthy."""
        now = time.time()
        with self._lock:
            self._cross_pod_window.append(now)
            count = len(self._cross_pod_window)
        if count >= self.cross_pod_degraded_threshold:
            self.alert(AlertEvent(
                trigger="cross_pod_degraded",
                severity="ERROR",
                message=(
                    f"Cross-pod claim degraded: {count} fail-opens recorded.  "
                    f"DBMS_LOCK is failing — duplicate dispatches possible "
                    f"if a second polling pod is running."
                ),
                details={"last_reason": _scrub(reason)[:200]},
            ))

    # ── internals ────────────────────────────────────────────────────

    def _enabled(self) -> bool:
        return bool(self.smtp_host and self.email_from and self.email_to)

    def _send(self, event: AlertEvent) -> bool:
        if not self._enabled():
            logger.warning(
                "Alert NOT sent (SMTP not configured): %s plugin=%s msg=%s",
                event.trigger, event.plugin, event.message,
            )
            return False

        subject = (
            f"[{event.severity}] QS-ETL polling/{self.worker_id}: "
            f"{event.trigger}{(' [' + event.plugin + ']') if event.plugin else ''}"
        )
        body_lines = [
            f"Severity:    {event.severity}",
            f"Trigger:     {event.trigger}",
            f"Plugin:      {event.plugin or '(N/A)'}",
            f"Worker ID:   {self.worker_id}",
            f"Hostname:    {socket.gethostname()}",
            f"Time (UTC):  {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}",
            f"",
            f"Message:",
            f"  {event.message}",
        ]
        if event.details:
            body_lines.extend(["", "Details:"])
            for k, v in sorted(event.details.items()):
                body_lines.append(f"  {k}: {v}")
        body_lines.extend([
            "",
            "-- Sent by polling_service.alerter",
            "Throttle: one email per (trigger, plugin) every "
            f"{self.cooldown_seconds}s.",
        ])
        body = "\n".join(body_lines)

        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = self.email_from
        msg["To"] = self.email_to

        # Allow tests to inject a fake sender.
        if self._sender is not None:
            try:
                self._sender(msg, self)
                return True
            except Exception as exc:
                logger.error("Alerter sender raised: %s", exc)
                return False

        try:
            with smtplib.SMTP(self.smtp_host, self.smtp_port, timeout=30) as s:
                if self.smtp_use_tls:
                    s.starttls()
                if self.smtp_user and self.smtp_password:
                    # 2026-07-01 hotfix-2 -- REFUSE to log in over a
                    # plaintext channel.  Prior behaviour: warned at
                    # construction but sent creds anyway if
                    # smtp_use_tls=False, ie the operator "forgot"
                    # STARTTLS.  Fail-CLOSED: drop the send + count
                    # a failure so ops sees the misconfig.
                    if not self.smtp_use_tls:
                        logger.error(
                            "Alerter refusing SMTP AUTH: "
                            "SMTP_USER/SMTP_PASSWORD are set but "
                            "SMTP_USE_TLS is FALSE.  Sending "
                            "credentials over a plaintext SMTP "
                            "channel is forbidden.  Set "
                            "SMTP_USE_TLS=1 (STARTTLS) or use an "
                            "unauthenticated relay."
                        )
                        with self._lock:
                            self.stats["smtp_failures"] += 1
                        return False
                    s.login(self.smtp_user, self.smtp_password)
                s.send_message(msg)
            logger.info(
                "Alert email sent: trigger=%s plugin=%s to=%s",
                event.trigger, event.plugin, self.email_to,
            )
            return True
        except Exception as exc:
            logger.error(
                "Alert email FAILED (SMTP %s:%s): %s: %s — telemetry recorded",
                self.smtp_host, self.smtp_port, type(exc).__name__, exc,
            )
            return False

    # ── snapshot for /health ─────────────────────────────────────────

    def snapshot(self) -> Dict[str, object]:
        with self._lock:
            return {
                "enabled":                     self._enabled(),
                "smtp_host":                   self.smtp_host,
                "email_to":                    self.email_to,
                "worker_id":                   self.worker_id,
                "alerts_sent":                 self.stats["alerts_sent"],
                "alerts_throttled":            self.stats["alerts_throttled"],
                "smtp_failures":               self.stats["smtp_failures"],
                "last_alert_at":               self.stats["last_alert_at"],
                "last_alert_trigger":          self.stats["last_alert_trigger"],
                "vault_consecutive_failures":  self._vault_consecutive_failures,
                "cross_pod_window_size":       len(self._cross_pod_window),
                "thresholds": {
                    "cooldown_seconds":               self.cooldown_seconds,
                    "failure_window_size":            self.failure_window_size,
                    "failure_rate_threshold":         self.failure_rate_threshold,
                    "vault_outage_threshold":         self.vault_outage_threshold,
                    "cross_pod_degraded_threshold":   self.cross_pod_degraded_threshold,
                },
            }


# ── module-level singleton ──────────────────────────────────────────────


_singleton: Optional[PluginAlerter] = None
_singleton_lock = threading.Lock()


def get_alerter() -> PluginAlerter:
    """Return the process-wide PluginAlerter, lazily constructed from
    env on first call."""
    global _singleton
    if _singleton is None:
        with _singleton_lock:
            if _singleton is None:
                _singleton = PluginAlerter.from_env()
    return _singleton


def reset_alerter() -> None:
    """Test hook — drop the singleton so the next get_alerter() call
    re-reads env."""
    global _singleton
    with _singleton_lock:
        _singleton = None
