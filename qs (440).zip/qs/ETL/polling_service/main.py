"""
ETL Background Polling Service — asyncio entry point.

Starts two concurrent coroutines:
  1. BackgroundPoller.run()  — poll loop (Oracle discovery + dispatch)
  2. Uvicorn health API      — FastAPI on port 9000 (health/status/pause/resume)

Usage:
  python -m polling_service.main
  python -m polling_service.main --config /app/config/polling_service_config.yaml
  python -m polling_service.main --config /app/config/polling_service_config.yaml --port 9000
"""
import argparse
import asyncio
import logging
import os
import signal
import sys
from typing import Any, Dict, Optional

import uvicorn

# Add ETL root to sys.path so managers/workers/steps are importable
_ETL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ETL_ROOT not in sys.path:
    sys.path.insert(0, _ETL_ROOT)

from polling_service.config import load_config
from polling_service.dispatcher import Dispatcher
from polling_service.health import app as health_app, init_health, init_health_service
from polling_service.poller import BackgroundPoller
from polling_service.service import BackgroundService
from managers.oracle_metadata_manager import OracleMetadataManager

# 2026-06-29 -- logging setup moved to polling_service.log_setup.
# This wrapper preserves the old _build_logger() signature for tests +
# the rest of main_async().  See log_setup.py for: TimedRotatingFileHandler
# (14-day backupCount), JSON formatter (QS_LOG_FORMAT=json), QueueHandler
# (non-blocking file IO for the asyncio loop), WorkflowLogAdapter.

def _build_logger(log_dir: str, log_level: str, worker_id: str) -> logging.Logger:
    """Wrapper around polling_service.log_setup.setup_logging().  Kept
    for back-compat with the existing test fixtures."""
    from polling_service.log_setup import setup_logging
    return setup_logging(log_dir=log_dir, log_level=log_level, worker_id=worker_id)


# 2026-06-29 -- validator moved to polling_service.log_setup so tests
# can exercise it WITHOUT importing main.py (which pulls uvicorn).
def _validate_runtime_env(logger: logging.Logger) -> None:
    from polling_service.log_setup import validate_runtime_env
    return validate_runtime_env(logger)


async def _run_uvicorn(host: str, port: int) -> None:
    """Run uvicorn health API in the asyncio event loop."""
    config = uvicorn.Config(
        health_app,
        host=host,
        port=port,
        log_level="warning",
        access_log=False,
    )
    server = uvicorn.Server(config)
    await server.serve()


async def main_async(config_path: str, health_host: str, health_port: int) -> None:
    """Async entry point — starts poller + health API concurrently."""
    cfg = load_config(config_path)
    logger = _build_logger(cfg.log_dir, cfg.log_level, cfg.worker_id)

    # Refuse unsafe runtime env combinations before any IO happens.  This
    # MUST run after _build_logger so the refusal lands in the rotating
    # file + JSON stream (operators can grep prior pod startup attempts).
    _validate_runtime_env(logger)

    # 2026-07-01 hotfix-2 -- prod-mode auth is now MANDATORY.
    # ``audit_prod_auth_posture`` raises ProdAuthMisconfigured when
    # WORKFLOW_ENV=prod but POLLING_ADMIN_TOKEN is unset / too short.
    # We deliberately do NOT catch that -- fail-CLOSED is the point.
    # Non-prod environments continue to pass through silently.
    from polling_service.auth import audit_prod_auth_posture
    audit_prod_auth_posture(logger)

    logger.info("=" * 60)
    logger.info("ETL Background Polling Service starting")
    logger.info(f"  worker_id        : {cfg.worker_id}")
    logger.info(f"  interval_seconds : {cfg.interval_seconds}")
    logger.info(f"  max_concurrent   : {cfg.max_concurrent_runs}")
    logger.info(f"  thread_pool      : {cfg.thread_pool_workers}")
    logger.info(f"  lightweight_mode : {cfg.use_lightweight_steps}")
    logger.info(f"  max_run_seconds  : {cfg.max_run_seconds}")
    logger.info(f"  shutdown_timeout : {cfg.shutdown_timeout_seconds}s")
    logger.info(f"  health_api       : http://{health_host}:{health_port}")
    logger.info("=" * 60)

    if not cfg.etl_connection_string:
        logger.error("ETL_ORACLE_CONN / etl_connection_string is not set — cannot start")
        sys.exit(1)

    # BF-595 (SERIOUS #3): wire ``thread_pool_workers`` into a dedicated
    # executor + set it as the event loop's default executor.  Every
    # ``asyncio.to_thread(...)`` and ``loop.run_in_executor(None, ...)``
    # call (e.g. OracleMetadataManager's blocking Oracle round-trips)
    # now routes through this bounded pool instead of the unbounded
    # anyio default (~40 threads).  Bounded + dedicated == predictable
    # CPU/IO behaviour under load.
    import concurrent.futures as _cf_bg
    import atexit as _atexit_bg
    _bg_executor = _cf_bg.ThreadPoolExecutor(
        max_workers=max(1, int(cfg.thread_pool_workers)),
        thread_name_prefix="bg-poller-io",
    )
    asyncio.get_running_loop().set_default_executor(_bg_executor)
    _atexit_bg.register(
        lambda: _bg_executor.shutdown(wait=False, cancel_futures=True)
    )
    logger.info(
        f"Default asyncio executor: ThreadPoolExecutor(max_workers="
        f"{cfg.thread_pool_workers}, name='bg-poller-io')"
    )

    # 2026-07-01 hotfix-2 -- install signal handlers BEFORE the
    # potentially-slow Oracle connect.  A SIGTERM arriving during
    # the 60s pool-creation retry window would otherwise fall
    # through to Python's default handler = ungraceful exit,
    # in-flight Oracle transactions aborted.  We use a mutable
    # container so the handler closes over "future service" refs
    # that get populated after this point.
    _shutdown_targets: Dict[str, Any] = {
        "service": None,
        "poller": None,
        "early_stop": False,
    }
    _loop_early = asyncio.get_running_loop()

    def _handle_signal_early(sig_name: str) -> None:
        logger.info("Received %s — initiating graceful shutdown", sig_name)
        _shutdown_targets["early_stop"] = True
        svc = _shutdown_targets.get("service")
        pol = _shutdown_targets.get("poller")
        if svc is not None:
            svc.stop()
        if pol is not None:
            pol.stop()

    for _sig in (signal.SIGTERM, signal.SIGINT):
        try:
            _loop_early.add_signal_handler(
                _sig, lambda s=_sig.name: _handle_signal_early(s)
            )
        except (NotImplementedError, OSError):
            # Windows: SIGTERM not deliverable; SIGINT via Ctrl+C.
            if _sig == signal.SIGINT:
                try:
                    signal.signal(
                        signal.SIGINT,
                        lambda signum, frame: _handle_signal_early("SIGINT"),
                    )
                except Exception as _sig_exc:                        # pragma: no cover
                    logger.warning(
                        "Failed to install Windows SIGINT fallback: %s",
                        _sig_exc,
                    )

    # 2026-07-01 hotfix -- construct OracleMetadataManager on a worker
    # thread so its ``OracleDBLib.__init__`` (which does synchronous
    # ``time.sleep`` on pool-creation retry, up to
    # ~60s of backoff if Oracle is not-yet-ready during a rolling
    # upgrade) does NOT block the event loop.  A frozen event loop
    # here means the FastAPI /health endpoint can't answer probes
    # → K8s marks the pod unhealthy → CrashLoopBackoff feedback loop
    # before pool creation even finishes.
    oracle_manager = await asyncio.to_thread(
        OracleMetadataManager, cfg.etl_connection_string
    )

    # If SIGTERM arrived DURING Oracle connect, honour it immediately
    # rather than proceeding to build a service that will just be
    # torn down.
    if _shutdown_targets["early_stop"]:
        logger.info(
            "SIGTERM/SIGINT received during Oracle connect -- exiting "
            "before service startup"
        )
        return

    # 2026-06-12 — multi-workflow mode engages when the YAML declared
    # ``polling.workflows``.  Otherwise the legacy single-loop
    # BackgroundPoller path runs unchanged (BF-595 deploy preserved).
    multi_mode = bool(cfg.workflows)
    logger.info(
        "Service mode: %s",
        "multi-workflow (BackgroundService)" if multi_mode
        else "single-loop (BackgroundPoller, legacy)",
    )

    poller: Optional[BackgroundPoller] = None
    service: Optional[BackgroundService] = None

    if multi_mode:
        service = BackgroundService(
            config=cfg,
            oracle_manager=oracle_manager,
            logger=logger,
        )
        init_health_service(service, oracle_manager, cfg.etl_connection_string)

        # 2026-06-29 telemetry persistence — restore prior counters from
        # the writable cache PVC + start the snapshot daemon so the
        # alerter's sliding window survives pod restarts.  Path is
        # operator-configurable via BG_TELEMETRY_PERSIST_PATH (default
        # under /usr/local/spark/pvc/code/.cache/).  Disabled when the
        # path is empty or the directory is unwritable (logged + skipped).
        try:
            from polling_service.telemetry_persist import (
                PersistenceDaemon, restore_snapshot,
            )
            persist_path = os.environ.get(
                "BG_TELEMETRY_PERSIST_PATH",
                "/usr/local/spark/pvc/code/.cache/qs_polling_telemetry.json",
            ).strip()
            persist_interval = int(os.environ.get("BG_TELEMETRY_PERSIST_INTERVAL_S", "60") or 60)
            if persist_path:
                # 2026-07-01 hotfix-2 -- pass expected_worker_id so
                # snapshot restore refuses cross-pod poisoning.
                restore_info = restore_snapshot(
                    persist_path,
                    expected_worker_id=cfg.worker_id,
                )
                logger.info(
                    "Telemetry restore from %s: %s", persist_path, restore_info,
                )
                _telemetry_daemon = PersistenceDaemon(
                    path=persist_path,
                    worker_id=cfg.worker_id,
                    interval_s=persist_interval,
                )
                _telemetry_daemon.start()
                # 2026-07-01 hotfix -- attach to the service so
                # ``BackgroundService.shutdown`` stops the daemon
                # BEFORE the event loop closes.  atexit still fires
                # as a belt-and-suspenders backstop for the rare
                # path that never calls shutdown() (dev-run Ctrl-C).
                service._telemetry_daemon = _telemetry_daemon
                import atexit as _atexit
                _atexit.register(_telemetry_daemon.stop)
        except Exception as exc:
            logger.warning(
                "Telemetry persistence unavailable (%s) — alerter sliding "
                "windows will reset on pod restart", exc,
            )
    else:
        # BF-595: pass the lightweight-mode flag through to the dispatcher.
        dispatcher = Dispatcher(
            logger=logger,
            use_lightweight_steps=cfg.use_lightweight_steps,
        )
        poller = BackgroundPoller(
            config=cfg,
            oracle_manager=oracle_manager,
            dispatcher=dispatcher,
            logger=logger,
        )
        init_health(poller, oracle_manager, cfg.etl_connection_string)

    # 2026-07-01 hotfix-2 -- signal handlers already installed above
    # (before Oracle connect).  Now that ``service`` and ``poller``
    # exist, populate the shutdown-target refs so incoming SIGTERM
    # actually stops them.
    _shutdown_targets["service"] = service
    _shutdown_targets["poller"] = poller
    # Honour any SIGTERM that arrived DURING service construction --
    # otherwise the poll loop would kick off and immediately be torn
    # down.
    if _shutdown_targets["early_stop"]:
        if service is not None:
            service.stop()
        if poller is not None:
            poller.stop()

    # Run the poller / service + health API concurrently.
    health_task = asyncio.create_task(
        _run_uvicorn(health_host, health_port), name="health_api"
    )

    try:
        if service is not None:
            await service.start()
            # Block on the service's stop event (set by the SIGTERM/SIGINT
            # handler via service.stop()), then run the drain.  No busy-poll.
            await service.wait_for_stop()
            await service.shutdown()
        else:
            assert poller is not None
            await poller.run()
    finally:
        health_task.cancel()
        try:
            await health_task
        except asyncio.CancelledError:
            pass
        # 2026-07-01 hotfix-2 -- shut down the default asyncio
        # executor here, BEFORE the loop closes.  atexit runs after
        # ``asyncio.run`` closes the loop, so ``cancel_futures=True``
        # in the atexit path raised RuntimeError on in-flight
        # futures with no way to await them.  Explicit shutdown
        # inside the loop drains cleanly.  Best-effort; the atexit
        # backstop still catches dev-run Ctrl-C paths.
        try:
            _bg_executor.shutdown(wait=False, cancel_futures=True)
        except Exception as _bg_exc:                                 # pragma: no cover
            logger.debug(
                "_bg_executor shutdown raised %r during main_async "
                "finally -- backing off to atexit", _bg_exc,
            )

    logger.info("ETL Background Polling Service shut down cleanly")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="ETL Background Polling Service"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="",
        help="Path to polling_service_config.yaml. Defaults to CONFIG_PATH env var.",
    )
    parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Health API bind host (default: 0.0.0.0)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("HEALTH_PORT", "9000")),
        help="Health API port (default: 9000, env: HEALTH_PORT)",
    )
    args = parser.parse_args()

    asyncio.run(main_async(
        config_path=args.config or "",
        health_host=args.host,
        health_port=args.port,
    ))


if __name__ == "__main__":
    main()
