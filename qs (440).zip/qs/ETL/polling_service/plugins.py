"""Diagnostic CLI for the polling service plugin registry.

Usage (from an ETL pod or local dev shell):

    python -m polling_service.plugins list
    python -m polling_service.plugins inspect <name>
    python -m polling_service.plugins validate
    python -m polling_service.plugins collisions
    python -m polling_service.plugins telemetry          # service-not-running mode shows zeros
    python -m polling_service.plugins routing-test <OTG_DAG_ID> [DB_CONNECTION]

The CLI consults the SAME registry that the running polling service
uses (``polling_service.workflow_registry.get_registry()``), so output
is authoritative for the current image.  Safe to run on a live pod —
operations are read-only.
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import List, Optional

from polling_service.workflow_registry import (
    PluginManifest,
    PluginValidationError,
    StartupValidationError,
    WorkflowRegistry,
    get_registry,
    reset_registry,
)


# ── output helpers ──────────────────────────────────────────────────────


def _emit_json(payload: object) -> None:
    """Pretty-print JSON to stdout for machine consumption."""
    print(json.dumps(payload, indent=2, sort_keys=True, default=str))


def _emit_table(rows: List[dict], columns: List[str]) -> None:
    """Pretty-print rows as a fixed-width table."""
    if not rows:
        print("(no rows)")
        return
    widths = {c: max(len(c), max(len(str(r.get(c, ""))) for r in rows)) for c in columns}
    sep = "  "
    print(sep.join(c.ljust(widths[c]) for c in columns))
    print(sep.join("-" * widths[c] for c in columns))
    for r in rows:
        print(sep.join(str(r.get(c, "")).ljust(widths[c]) for c in columns))


# ── commands ────────────────────────────────────────────────────────────


def cmd_list(args: argparse.Namespace) -> int:
    reg = _load_registry(args)
    rows = []
    for d in reg:
        cls = d.worker_cls()
        rows.append({
            "name":        d.name,
            "version":     d.version,
            "priority":    d.priority,
            "source":      d.source,
            "installed":   "yes" if cls is not None else "NO",
            "lightweight": "yes" if d.lightweight_capable else "NO",
            "deprecated":  "yes" if d.is_deprecated else "",
            "patterns":    ",".join(d.dag_id_patterns),
        })
    if args.json:
        _emit_json(rows)
    else:
        _emit_table(rows, ["name", "version", "priority", "source", "installed",
                            "lightweight", "deprecated", "patterns"])
        print()
        print(f"{len(rows)} plugin(s) registered.")
    return 0


def cmd_inspect(args: argparse.Namespace) -> int:
    reg = _load_registry(args)
    d = reg.get(args.name)
    if d is None:
        print(f"ERROR: no plugin named {args.name!r}.  Run `plugins list` for the catalog.",
              file=sys.stderr)
        return 2
    cls = d.worker_cls()
    payload = {
        "name":                    d.name,
        "version":                 d.version,
        "manifest_version":        d.manifest_version,
        "description":             d.description,
        "source":                  d.source,
        "priority":                d.priority,
        "dag_id_patterns":         list(d.dag_id_patterns),
        "db_connection_patterns":  list(d.db_connection_patterns),
        "aliases":                 list(d.aliases),
        "capabilities":            sorted(d.capabilities),
        "needs_starburst_clients": d.needs_starburst_clients,
        "lightweight_capable":     d.lightweight_capable,
        "is_deprecated":           d.is_deprecated,
        "deprecated_message":      d.deprecated_message,
        "replaced_by":             d.replaced_by,
        "requires_env":            list(d.requires_env),
        "requires_packages":       list(d.requires_packages),
        "worker_class":            cls.__name__ if cls is not None else None,
        "worker_module":           cls.__module__ if cls is not None else None,
        "worker_loadable":         cls is not None,
        "has_on_register":         d.on_register is not None,
        "has_on_runner_start":     d.on_runner_start is not None,
        "has_on_runner_stop":      d.on_runner_stop is not None,
    }
    _emit_json(payload)
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    reg = _load_registry(args)
    report = reg.validate_all()
    if args.json:
        _emit_json(report)
    else:
        print(f"Validation report — {report['plugin_count']} plugin(s)")
        print(f"  valid:   {report['valid_count']}")
        print(f"  invalid: {report['invalid_count']}")
        print()
        for r in report["results"]:
            status = "OK " if r["valid"] else "FAIL"
            print(f"  [{status}] {r['name']:18s} v{r['version']:10s} source={r['source']:30s}",
                  end="")
            print(f" worker_loadable={r['worker_loadable']}",
                  end="")
            if r["is_deprecated"]:
                print(" [DEPRECATED]", end="")
            print()
            for err in r["errors"]:
                print(f"           ! {err}")
        if report["priority_collisions"]:
            print()
            print(f"PRIORITY COLLISIONS ({len(report['priority_collisions'])}):")
            for c in report["priority_collisions"]:
                print(f"  * {c['a']!r} vs {c['b']!r} @ priority={c['priority']}, "
                      f"shared_patterns={c['shared_patterns']}")
        if report["pattern_overlaps"]:
            print()
            print(f"PATTERN OVERLAPS ({len(report['pattern_overlaps'])}) — winner takes precedence:")
            for o in report["pattern_overlaps"]:
                print(f"  * {o['loser']!r} (pri={o['loser_priority']}) pattern {o['loser_pattern']!r} "
                      f"is substring of {o['winner']!r}'s pattern {o['winner_pattern']!r} "
                      f"(pri={o['winner_priority']})")
    return 0 if report["invalid_count"] == 0 else 1


def cmd_collisions(args: argparse.Namespace) -> int:
    reg = _load_registry(args)
    pri_colls, overlaps = reg.detect_collisions()
    payload = {
        "priority_collisions": [
            {"a": a, "b": b, "priority": pri, "shared_patterns": sorted(shared)}
            for a, b, pri, shared in pri_colls
        ],
        "pattern_overlaps": [
            {"loser": a.name, "loser_priority": a.priority, "loser_pattern": pa,
             "winner": b.name, "winner_priority": b.priority, "winner_pattern": pb}
            for a, b, pa, pb in overlaps
        ],
    }
    if args.json:
        _emit_json(payload)
    else:
        if not pri_colls and not overlaps:
            print("OK -- no priority collisions, no pattern overlaps.")
            return 0
        if pri_colls:
            print(f"PRIORITY COLLISIONS ({len(pri_colls)}):")
            for a, b, pri, shared in pri_colls:
                print(f"  * {a!r} vs {b!r} @ priority={pri}, shared_patterns={sorted(shared)}")
        if overlaps:
            print(f"PATTERN OVERLAPS ({len(overlaps)}):")
            for a, b, pa, pb in overlaps:
                print(f"  * {a.name!r} (pri={a.priority}) pattern {pa!r} is substring of "
                      f"{b.name!r}'s pattern {pb!r} (pri={b.priority})")
    return 0 if not pri_colls else 1


def cmd_telemetry(args: argparse.Namespace) -> int:
    reg = _load_registry(args)
    if args.name:
        t = reg.get_telemetry(args.name)
        if t is None:
            print(f"ERROR: no plugin named {args.name!r}", file=sys.stderr)
            return 2
        _emit_json({args.name: t.snapshot()})
        return 0
    payload = {name: t.snapshot() for name, t in reg.all_telemetry().items()}
    _emit_json(payload)
    return 0


def cmd_routing_test(args: argparse.Namespace) -> int:
    reg = _load_registry(args)
    name = reg.route_dag_id(args.otg_dag_id, args.db_connection)
    d = reg.get(name)
    print(f"OTG_DAG_ID={args.otg_dag_id!r} db_connection={args.db_connection!r}")
    print(f"  -> routes to: {name}")
    if d is not None:
        print(f"  worker:     {d.worker_cls()}")
        print(f"  source:     {d.source}")
        print(f"  priority:   {d.priority}")
        print(f"  patterns:   {list(d.dag_id_patterns)}")
        if d.is_deprecated:
            print(f"  WARN:       this plugin is DEPRECATED ({d.deprecated_message or 'no message'})")
    return 0


# ── runner ──────────────────────────────────────────────────────────────


def _load_registry(args: argparse.Namespace) -> WorkflowRegistry:
    """Build the registry the CLI inspects.  Always re-discovers so a
    long-running shell sees the latest state."""
    reset_registry()
    try:
        return WorkflowRegistry.discover(
            strict_collisions=False,         # CLI keeps going even with collisions
            load_entry_points=not args.no_entry_points,
        )
    except StartupValidationError as exc:
        print(f"STARTUP VALIDATION FAILED: {exc}", file=sys.stderr)
        sys.exit(3)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="polling_service.plugins",
        description="Diagnostic CLI for the ETL polling-service plugin registry.",
    )
    parser.add_argument("--no-entry-points", action="store_true",
                         help="Skip discovery of setuptools entry-point plugins.")
    parser.add_argument("--json", action="store_true",
                         help="Emit machine-readable JSON for the relevant subcommand.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="Show every discovered plugin (table form).")

    p_inspect = sub.add_parser("inspect", help="Show one plugin's full manifest.")
    p_inspect.add_argument("name", help="Canonical workflow name or alias.")

    sub.add_parser("validate", help="Validate every manifest + report errors.")
    sub.add_parser("collisions", help="Report priority collisions + pattern overlaps.")

    p_tel = sub.add_parser("telemetry", help="Dump telemetry counters (live registry only).")
    p_tel.add_argument("name", nargs="?", help="Optional plugin name to filter.")

    p_route = sub.add_parser("routing-test",
                              help="Show which plugin a given OTG_DAG_ID would route to.")
    p_route.add_argument("otg_dag_id")
    p_route.add_argument("db_connection", nargs="?", default="")

    args = parser.parse_args(argv)

    cmd_map = {
        "list":         cmd_list,
        "inspect":      cmd_inspect,
        "validate":     cmd_validate,
        "collisions":   cmd_collisions,
        "telemetry":    cmd_telemetry,
        "routing-test": cmd_routing_test,
    }
    return cmd_map[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
