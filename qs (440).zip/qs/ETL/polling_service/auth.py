"""Shared-secret auth for mutating + diagnostic health endpoints.

Design:
  * Read ``POLLING_ADMIN_TOKEN`` env var at startup (set via the Helm
    secret).  When unset, auth is DISABLED — back-compat with the
    trusted-cluster posture the service had before this addition.
  * When set, every protected endpoint checks the ``X-Admin-Token``
    header against the env-var value using ``hmac.compare_digest``
    (constant-time comparison; no timing leak).
  * Empty header / wrong header → 401.  Missing token AND no env var
    set → 200 (auth disabled).
  * Token is NEVER logged (would defeat the secret).  Failed-auth
    attempts ARE logged with client IP for ops to investigate brute
    forcing.

When to set the env var:
  * Production:   ALWAYS set via Helm secret (`secrets.appSecret.data.
                   POLLING_ADMIN_TOKEN: "<random 32-char hex>"`)
  * UAT:          set to confirm the wiring works before prod
  * Dev:          leave unset (trusted-developer-cluster)

Why a header token instead of K8s SA auth:
  * Zero external dependencies (no need for a sidecar OIDC proxy)
  * Works behind every ingress (no need to forward bearer tokens)
  * Simple to rotate (helm upgrade --set-string secrets.appSecret.data.POLLING_ADMIN_TOKEN=...)
  * If your cluster has stronger identity (OIDC, mTLS) you can layer
    that ON TOP — this is a baseline that should never be DISABLED in prod.
"""
from __future__ import annotations

import hmac
import logging
import os
from typing import Optional

from fastapi import Header, HTTPException, Request


logger = logging.getLogger("bg_poller.auth")


def _token_env() -> str:
    """Read the configured admin token from env each call.

    2026-07-01 doc fix -- the earlier docstring claimed "Helm upgrade
    picks up new values without pod restart" which is FALSE in
    practice.  Env vars are baked at pod start; changing the Helm
    secret requires a rolling restart for the new value to reach
    ``os.environ``.  This lookup is per-call because it's cheap
    and the token value is verified against the Helm-injected
    value in the running pod.
    """
    return os.environ.get("POLLING_ADMIN_TOKEN", "").strip()


class ProdAuthMisconfigured(RuntimeError):
    """Raised when WORKFLOW_ENV=prod but POLLING_ADMIN_TOKEN is unset
    or too short.  Fail-CLOSED at startup so operators cannot
    accidentally ship a prod pod with auth disabled."""


# Minimum token length to defeat brute-force even under a slow
# handler path.  32 hex chars = 128 bits of entropy.
_MIN_TOKEN_LEN = 24


def audit_prod_auth_posture(logger_arg=None) -> None:
    """One-shot startup check: if the environment claims to be prod
    (``WORKFLOW_ENV=prod``) but ``POLLING_ADMIN_TOKEN`` is unset (or
    too short), REFUSE to start.  2026-07-01 hotfix-2 upgraded this
    from "log an ERROR and continue" to fail-CLOSED because a prod
    deploy that forgets the Helm secret otherwise ships wide-open —
    /status, /workflows, /admin/reload all reachable without a
    header.

    Called from ``polling_service.main`` after logger setup.  Safe
    to call multiple times -- non-prod environments are always OK.
    """
    _log = logger_arg or logger
    env_name = os.environ.get("WORKFLOW_ENV", "").strip().lower()
    if env_name not in ("prod", "production"):
        return
    token = _token_env()
    if not token:
        msg = (
            "AUTH POSTURE FAILURE: WORKFLOW_ENV=%s but "
            "POLLING_ADMIN_TOKEN is UNSET.  Refusing to start the "
            "polling service in prod without an admin token -- "
            "/status, /workflows, /admin/reload would otherwise be "
            "reachable without any header.  Set POLLING_ADMIN_TOKEN "
            "via the Helm secret and redeploy." % env_name
        )
        _log.error(msg)
        raise ProdAuthMisconfigured(msg)
    if len(token) < _MIN_TOKEN_LEN:
        msg = (
            "AUTH POSTURE FAILURE: POLLING_ADMIN_TOKEN is only %d "
            "chars long; prod requires >= %d for adequate entropy.  "
            "Generate a fresh token via `openssl rand -hex 32` and "
            "redeploy." % (len(token), _MIN_TOKEN_LEN)
        )
        _log.error(msg)
        raise ProdAuthMisconfigured(msg)


def is_auth_enabled() -> bool:
    """True when POLLING_ADMIN_TOKEN env var is set (non-empty).
    Public so the health endpoint can surface auth state in /status."""
    return bool(_token_env())


async def require_admin(
    request: Request,
    x_admin_token: Optional[str] = Header(default=None, alias="X-Admin-Token"),
) -> None:
    """FastAPI dependency for mutating + diagnostic admin endpoints.

    Behaviour:
      * Auth disabled (env var unset) → pass through (back-compat).
      * Auth enabled + header missing or wrong → 401 + audit log.
      * Auth enabled + header matches → pass through silently.

    The audit log includes the client IP (when present) and a hint at
    the path so operators can correlate failed-auth attempts across
    the cluster.  The token itself is NEVER logged.
    """
    expected = _token_env()
    if not expected:
        return None  # auth disabled — trusted cluster posture

    provided = (x_admin_token or "").strip()
    if not provided:
        _log_unauthorised(request, reason="missing X-Admin-Token header")
        raise HTTPException(status_code=401, detail="X-Admin-Token header required")

    # Constant-time comparison to defeat timing attacks (per OWASP).
    if not hmac.compare_digest(provided, expected):
        _log_unauthorised(request, reason="X-Admin-Token mismatch")
        raise HTTPException(status_code=401, detail="invalid X-Admin-Token")
    return None


def _log_unauthorised(request: Request, reason: str) -> None:
    try:
        client = getattr(request, "client", None)
        client_host = client.host if client and client.host else "unknown"
    except Exception:
        client_host = "unknown"
    try:
        path = request.url.path
    except Exception:
        path = "?"
    logger.warning(
        "AUTH_DENIED path=%s client=%s reason=%s",
        path, client_host, reason,
    )
