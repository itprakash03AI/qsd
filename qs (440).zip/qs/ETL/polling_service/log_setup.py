"""Enterprise logging setup for the polling service.

Provides:
  * ``setup_logging(log_dir, log_level, worker_id, fmt="text"|"json")`` —
    configures the root logger with the right handler stack:
      - Console handler (stdout, always)
      - TimedRotatingFileHandler (midnight rotation, 14-day retention)
        wrapped in a QueueHandler+QueueListener so write IO never
        blocks the asyncio event loop.
      - JSON formatter when ``fmt='json'`` OR ``QS_LOG_FORMAT=json`` env
        is set — Loki/Splunk/ELK ready.
  * ``WorkflowLogAdapter(logger, extras)`` — LoggerAdapter that bakes
    ``run_id``, ``workflow``, ``dag_id`` into every record so downstream
    aggregators can filter by structured field instead of regex.

Replaces the inline _build_logger in main.py.  The old function still
exists as a thin wrapper for back-compat with the existing tests.
"""
from __future__ import annotations

import atexit
import json as _json
import logging
import logging.handlers
import os
import queue
import sys
from datetime import datetime, timezone
from typing import Any, Dict, MutableMapping, Optional, Tuple


# ── formatters ─────────────────────────────────────────────────────────


_TEXT_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


class JsonFormatter(logging.Formatter):
    """Render each LogRecord as a single-line JSON object.

    Includes standard fields (timestamp, level, logger, message) +
    any ``extra={...}`` fields the caller injected via LoggerAdapter
    or ``logger.info(..., extra={'run_id': 7})``.

    Why hand-rolled instead of python-json-logger: keeps zero
    dependencies — the polling image is intentionally lean.
    """

    # Fields LogRecord carries that we DON'T want repeated in the JSON
    # output (either redundant or noisy).
    _SKIP = {
        "name", "msg", "args", "levelname", "levelno", "pathname",
        "filename", "module", "exc_info", "exc_text", "stack_info",
        "lineno", "funcName", "created", "msecs", "relativeCreated",
        "thread", "threadName", "processName", "process", "message",
        "taskName",
    }

    def format(self, record: logging.LogRecord) -> str:
        payload: Dict[str, Any] = {
            "ts":      datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(timespec="milliseconds"),
            "level":   record.levelname,
            "logger":  record.name,
            "message": record.getMessage(),
        }
        # Process / thread for K8s pod identification
        payload["pid"] = record.process
        payload["tid"] = record.thread
        # Exception info, if any
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        # Any extras the caller injected via LoggerAdapter / extra={...}.
        for k, v in record.__dict__.items():
            if k in self._SKIP or k.startswith("_"):
                continue
            if k in payload:
                continue
            # Coerce non-JSON-safe values to repr.
            try:
                _json.dumps(v)
                payload[k] = v
            except (TypeError, ValueError):
                payload[k] = repr(v)
        return _json.dumps(payload, default=repr, separators=(",", ":"))


# ── LoggerAdapter ──────────────────────────────────────────────────────


class WorkflowLogAdapter(logging.LoggerAdapter):
    """LoggerAdapter that bakes contextual fields into every record.

    Usage::

        log = WorkflowLogAdapter(
            base_logger,
            extras={"workflow": "oracle", "run_id": 1234, "dag_id": "OTG_X"},
        )
        log.info("dispatch started")
        # JSON output:
        # {"ts":"...","level":"INFO","workflow":"oracle","run_id":1234,
        #  "dag_id":"OTG_X","message":"dispatch started"}

    The extras dict is merged into ``record.__dict__`` so both the
    text and JSON formatters can pick them up.  Mutating ``extras``
    after construction affects subsequent log calls (intentional —
    lets you update the run_id as dispatch progresses).
    """

    def __init__(self, logger: logging.Logger, extras: Dict[str, Any]) -> None:
        super().__init__(logger, extras)

    def process(
        self,
        msg: str,
        kwargs: MutableMapping[str, Any],
    ) -> Tuple[str, MutableMapping[str, Any]]:
        # Merge our extras into whatever the caller passed as extra=.
        existing = kwargs.get("extra") or {}
        merged = {**self.extra, **existing}
        kwargs["extra"] = merged
        return msg, kwargs


# ── handler factory ────────────────────────────────────────────────────


def _make_file_handler(
    log_file: str,
    backup_count: int = 14,
) -> Optional[logging.Handler]:
    """Build a rotating file handler.  Returns None when the path is
    unwritable (caller falls back to console-only).

    TimedRotatingFileHandler rotates at midnight UTC and keeps the last
    ``backup_count`` rotated files.  This caps disk usage at roughly
    ``backup_count * daily_log_size`` instead of growing forever.
    """
    try:
        handler = logging.handlers.TimedRotatingFileHandler(
            log_file,
            when="midnight",
            interval=1,
            backupCount=backup_count,
            encoding="utf-8",
            utc=True,
        )
        # Rotated suffix matches the date so files sort chronologically
        # in `ls`: bg_poller_X.log -> bg_poller_X.log.2026-06-29
        handler.suffix = "%Y-%m-%d"
        return handler
    except OSError as exc:
        logging.warning(
            "Cannot open log file %s: %s — console-only logging", log_file, exc,
        )
        return None


def _wrap_in_queue(handler: logging.Handler) -> Tuple[logging.Handler, logging.handlers.QueueListener]:
    """Wrap a handler in a QueueHandler+QueueListener pair so the asyncio
    event loop doesn't block on file IO.  Returns (queue_handler, listener).

    The listener thread is started and registered at exit so it drains
    pending records on shutdown — no lost lines."""
    q: queue.SimpleQueue = queue.SimpleQueue()
    qh = logging.handlers.QueueHandler(q)
    listener = logging.handlers.QueueListener(q, handler, respect_handler_level=True)
    listener.start()
    atexit.register(listener.stop)
    return qh, listener


# ── public setup ───────────────────────────────────────────────────────


def setup_logging(
    log_dir: str,
    log_level: str = "INFO",
    worker_id: str = "bg_poller",
    fmt: str = "",
) -> logging.Logger:
    """Configure root logger + return a child logger named ``bg_poller``.

    Args:
      log_dir:    directory for the rotating log file (falls back to
                   console-only when unwritable)
      log_level:  root level (DEBUG/INFO/WARNING/ERROR)
      worker_id:  baked into the log file name (one file per pod)
      fmt:        ``"json"`` for structured logs, ``"text"`` for the
                   legacy format, or ``""`` to honour the ``QS_LOG_FORMAT``
                   env var (default ``text``).

    Idempotent — safe to call multiple times; previous handlers are
    closed before new ones are installed.
    """
    level = getattr(logging, str(log_level).upper(), logging.INFO)
    if not fmt:
        fmt = os.environ.get("QS_LOG_FORMAT", "text").strip().lower()
    if fmt not in ("text", "json"):
        logging.warning("Unknown QS_LOG_FORMAT=%r — defaulting to text", fmt)
        fmt = "text"

    formatter: logging.Formatter = (
        JsonFormatter() if fmt == "json" else logging.Formatter(_TEXT_FMT)
    )

    try:
        os.makedirs(log_dir, exist_ok=True)
        # 2026-07-01 hygiene -- was embedding boot-date in filename
        # (``bg_poller_<id>_2026-06-30.log``) which meant the base
        # file's NAME never reflected the current date; ops looking
        # for today's log found yesterday's filename with today's
        # data.  TimedRotatingFileHandler handles rotation via a
        # suffix; base filename now stays stable across days.
        log_file = os.path.join(log_dir, f"bg_poller_{worker_id}.log")
    except OSError as exc:
        log_file = None
        logging.warning("Cannot create log dir %s: %s — console only", log_dir, exc)

    root = logging.getLogger()
    root.setLevel(level)

    # Idempotency: remove any handlers we previously installed AND
    # close the paired QueueListener so re-setup doesn't leak
    # listener threads.  Test suites that call setup_logging
    # repeatedly would otherwise accumulate a listener per call.
    for h in list(root.handlers):
        if getattr(h, "_qs_polling_setup", False):
            try:
                _listener = getattr(h, "_qs_polling_listener", None)
                if _listener is not None:
                    try:
                        _listener.stop()
                    except Exception:
                        pass
                h.close()
            except Exception:
                pass
            root.removeHandler(h)

    # Console handler (always)
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    console._qs_polling_setup = True   # type: ignore[attr-defined]
    root.addHandler(console)

    # File handler — wrapped in queue so async loop never blocks on IO.
    if log_file:
        file_handler = _make_file_handler(log_file)
        if file_handler is not None:
            file_handler.setFormatter(formatter)
            qh, listener = _wrap_in_queue(file_handler)
            qh._qs_polling_setup = True       # type: ignore[attr-defined]
            qh._qs_polling_listener = listener # type: ignore[attr-defined]
            root.addHandler(qh)

    # Silence noisy third-party loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.error").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)

    logger = logging.getLogger("bg_poller")
    logger.setLevel(level)
    return logger


# ── runtime env validation ─────────────────────────────────────────────


def validate_runtime_env(logger: logging.Logger) -> None:
    """Refuse to start when env vars indicate an unsafe combination.

    Lives in log_setup so the polling_service test suite can exercise it
    WITHOUT importing main.py (which transitively pulls uvicorn).

    Refuses ``ETL_USE_VAULT=1 + ETL_SECRETS_ALLOW_PLAINTEXT=1`` — that
    combination caches plaintext secrets to PVC under the guise of
    production vault mode.  Warns (does not refuse) when vault is on
    but no Fernet key is configured — disk cache is in-memory-only,
    which is functional but defeats the cluster-wide cache design.
    """
    import sys
    vault_on = os.environ.get("ETL_USE_VAULT", "").strip().lower() in (
        "1", "true", "yes", "on",
    )
    plaintext_on = os.environ.get("ETL_SECRETS_ALLOW_PLAINTEXT", "").strip().lower() in (
        "1", "true", "yes", "on",
    )
    if vault_on and plaintext_on:
        logger.error(
            "STARTUP REFUSED: ETL_USE_VAULT=1 + ETL_SECRETS_ALLOW_PLAINTEXT=1 "
            "is an UNSAFE combination — production vault path with the disk "
            "cache UNENCRYPTED.  Either:\n"
            "  * unset ETL_SECRETS_ALLOW_PLAINTEXT and provide ETL_SECRETS_KEY "
            "(a 44-char Fernet key), OR\n"
            "  * unset ETL_USE_VAULT if this pod doesn't need vault.\n"
            "This guard prevents a DEV-config-leaks-to-PROD incident from "
            "silently writing plaintext secrets to the PVC."
        )
        sys.exit(1)
    if vault_on:
        _secrets_key = os.environ.get("ETL_SECRETS_KEY", "").strip()
        if not _secrets_key and not plaintext_on:
            logger.warning(
                "ETL_USE_VAULT=1 but ETL_SECRETS_KEY is empty.  Disk cache "
                "encryption is DISABLED — vault hits will be cached in memory "
                "only (every pod fetches independently).  Provide a 44-char "
                "Fernet key in ETL_SECRETS_KEY OR set ETL_SECRETS_ALLOW_PLAINTEXT=1 "
                "for an explicit dev-mode acknowledgement."
            )
        elif _secrets_key:
            # 2026-07-01 hygiene -- verify the key LOOKS like a Fernet
            # key BEFORE the first decode attempt.  A malformed key
            # (typo, truncated copy, wrong encoding) previously caused
            # every vault-cache hit to fail with an opaque
            # cryptography error hours after boot.  Fernet keys are
            # url-safe base64 encoded 32 raw bytes -> 44 base64 chars
            # ending with ``=``.
            import base64
            _bad = False
            try:
                if len(_secrets_key) != 44:
                    _bad = True
                else:
                    _decoded = base64.urlsafe_b64decode(_secrets_key)
                    if len(_decoded) != 32:
                        _bad = True
            except Exception:
                _bad = True
            if _bad:
                logger.error(
                    "ETL_SECRETS_KEY does NOT look like a valid Fernet "
                    "key (expected 44 url-safe base64 chars decoding to "
                    "32 bytes; got %d chars).  Vault-cache decodes will "
                    "fail at runtime.  Generate a new key with "
                    "``python -c 'from cryptography.fernet import Fernet; "
                    "print(Fernet.generate_key().decode())'`` and re-inject "
                    "via the Helm secret.",
                    len(_secrets_key),
                )
