"""WorkflowRegistry — enterprise plugin system for ETL workflows.

Each workflow is a self-contained plugin that declares itself in a
manifest file.  The registry discovers, validates, registers, and
exposes telemetry/health for every plugin.

Design properties (2026-06-29 enterprise upgrade):

  * **Versioned manifest** — every plugin carries ``version`` (semver)
    + ``manifest_version`` (schema version).  Future schema changes
    can add fields without breaking older manifests.

  * **Schema validation at registration** — bad manifests are rejected
    LOUDLY at startup, not silently at first dispatch.  Validation
    runs through ``PluginManifest.validate()``.

  * **Collision detection** — two plugins competing for the same
    routing pattern at the same priority is a startup error
    (``StartupValidationError``).  Pattern-substring overlap that
    relies on priority is a startup WARN so operators can audit.

  * **Per-plugin telemetry** — ``PluginTelemetry`` records dispatch
    counts, success/fail/timeout, last-N latencies, last-failure
    reason.  Exposed via ``/workflows/<name>`` health endpoint AND
    Prometheus metrics when ServiceMonitor is enabled.

  * **Lifecycle hooks** — optional callbacks on the manifest:
    ``on_register`` (after the manifest joins the registry),
    ``on_runner_start`` (when BackgroundService spawns the runner),
    ``on_runner_stop`` (when the runner is being shut down).
    Plugins use these for one-time setup / connection pre-warm /
    teardown without polluting the dispatcher.

  * **Entry-point discovery** — in-tree ``workflows/`` package PLUS
    setuptools entry-points under the ``qs_etl.workflows`` group.
    A pip-installed package can register its own plugins without
    modifying ETL sources.

  * **Capabilities declared** — each plugin advertises what it CAN
    do (``starburst_query``, ``oracle_sink``, ``sap_odata``, …)
    so future routing decisions can ask "who can sink to Oracle?"
    instead of "what's its dag_id pattern?".

  * **Diagnostic CLI** — ``python -m polling_service.plugins {list,
    inspect, validate, collisions}`` exposes the registry without
    needing a running pod.

  * **Source provenance** — every manifest records its ``source``
    (``builtin``, ``entry_point:foo``, ``operator_override``) so
    incident response can identify where a problematic plugin came
    from.

Per feedback_plugin_pattern.md + feedback_strategic_not_patch.md +
feedback_single_chokepoint_pattern.md.
"""
from __future__ import annotations

import collections
import importlib
import importlib.metadata
import logging
import pkgutil
import re
import threading
import time
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from typing import (
    Any, Callable, Dict, FrozenSet, Iterable, List, Optional,
    Sequence, Tuple,
)

logger = logging.getLogger(__name__)


# ── exceptions ──────────────────────────────────────────────────────────


class PluginValidationError(ValueError):
    """Raised when a manifest fails schema validation."""


class StartupValidationError(RuntimeError):
    """Raised when registry-level invariants (collisions, missing
    required fields) are violated at service startup."""


# ── manifest schema ─────────────────────────────────────────────────────


CURRENT_MANIFEST_VERSION = 1
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+(?:[-+][\w\.\-]+)?$")
# 2026-06-29 -- name MUST be a real Python identifier.  ``isalnum()`` (used
# previously) accepts digit-prefix strings like "123abc" which break import
# paths + step_mapping section keys.  Identifier regex catches that.
NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


@dataclass(frozen=True)
class PluginManifest:
    """Immutable plugin manifest declared by each workflow.

    Required:
      name, worker_cls_loader

    Recommended for production plugins:
      version, description, capabilities, dag_id_patterns, priority

    Optional advanced fields:
      manifest_version (forward-compat), aliases, lifecycle hooks,
      deprecation metadata, requires_env / requires_packages.

    The constructor does NOT validate (frozen dataclass + zero-cost
    init).  Validation runs at registration time via
    ``WorkflowRegistry.register`` which calls ``manifest.validate()``.
    """

    # ── identity ────────────────────────────────────────────────────
    name: str
    version: str = "1.0.0"
    manifest_version: int = CURRENT_MANIFEST_VERSION
    description: str = ""

    # ── routing ─────────────────────────────────────────────────────
    dag_id_patterns: Tuple[str, ...] = ()
    db_connection_patterns: Tuple[str, ...] = ()
    aliases: Tuple[str, ...] = ()
    priority: int = 100

    # ── execution ───────────────────────────────────────────────────
    worker_cls_loader: Callable[[], Optional[type]] = field(
        default=lambda: None
    )
    needs_starburst_clients: bool = False
    lightweight_capable: bool = True

    # ── declared capabilities + requirements ────────────────────────
    capabilities: FrozenSet[str] = frozenset()
    requires_env: Tuple[str, ...] = ()
    requires_packages: Tuple[str, ...] = ()

    # ── lifecycle hooks (None = no-op) ──────────────────────────────
    on_register: Optional[Callable[["PluginManifest"], None]] = None
    on_runner_start: Optional[Callable[[Any], None]] = None
    on_runner_stop: Optional[Callable[[Any], None]] = None

    # ── deprecation ─────────────────────────────────────────────────
    is_deprecated: bool = False
    deprecated_message: str = ""
    replaced_by: str = ""

    # ── provenance ──────────────────────────────────────────────────
    source: str = "builtin"   # "builtin" | "entry_point:<ep>" | "operator_override"

    # ── back-compat alias ───────────────────────────────────────────
    # Old code references ``WorkflowDefinition.worker_cls()`` as a
    # method; expose it on the new class too for zero-friction migration.

    def worker_cls(self) -> Optional[type]:
        """Lazy-load the worker class.  Returns None if the loader
        raises ImportError (worker not installable on this image) so
        the dispatcher can refuse cleanly."""
        try:
            return self.worker_cls_loader()
        except ImportError as exc:
            logger.debug(
                "PluginManifest[%s].worker_cls() ImportError: %s",
                self.name, exc,
            )
            return None

    def matches_dag_id(self, dag_id_lower: str) -> bool:
        return any(p in dag_id_lower for p in self.dag_id_patterns)

    def matches_db_connection(self, db_conn_upper: str) -> bool:
        return any(p in db_conn_upper for p in self.db_connection_patterns)

    def has_capability(self, capability: str) -> bool:
        return capability in self.capabilities

    # ── validation ──────────────────────────────────────────────────

    def validate(self) -> List[str]:
        """Return a list of human-readable error strings.  Empty list
        means the manifest is valid.  Caller raises if non-empty."""
        errors: List[str] = []

        # name: required, must be a valid Python identifier (so it can
        # be used as a step_mapping section key + a CLI arg + a dotted
        # import path component).  Python identifier regex catches the
        # digit-prefix + whitespace + special-char cases that .isalnum()
        # incorrectly accepts.
        if not self.name:
            errors.append("name is required (non-empty string)")
        elif not NAME_RE.match(self.name):
            errors.append(
                f"name {self.name!r} must be a valid Python identifier "
                "(starts with letter/underscore, followed by letters/digits/"
                "underscores) so it can be used as a step_mapping section key "
                "and a CLI argument"
            )

        # version: must look like semver.
        if self.version and not SEMVER_RE.match(self.version):
            errors.append(
                f"version {self.version!r} is not valid semver "
                "(expected like '1.2.3' or '1.2.3-rc.1')"
            )

        # manifest_version: must be int and <= current.
        if not isinstance(self.manifest_version, int):
            errors.append("manifest_version must be int")
        elif self.manifest_version > CURRENT_MANIFEST_VERSION:
            errors.append(
                f"manifest_version={self.manifest_version} is newer than "
                f"this runtime supports ({CURRENT_MANIFEST_VERSION}).  "
                "Upgrade the polling service first."
            )

        # worker_cls_loader: must be callable.
        if not callable(self.worker_cls_loader):
            errors.append("worker_cls_loader must be callable")

        # priority: must be non-negative int.
        if not isinstance(self.priority, int) or self.priority < 0:
            errors.append(f"priority must be int >= 0 (got {self.priority!r})")

        # Pattern types — tuples of str.
        for field_name in ("dag_id_patterns", "db_connection_patterns", "aliases"):
            val = getattr(self, field_name)
            if not isinstance(val, tuple):
                errors.append(f"{field_name} must be a tuple (got {type(val).__name__})")
            elif not all(isinstance(p, str) and p for p in val):
                errors.append(f"{field_name} must contain only non-empty strings")
            elif len(val) != len(set(val)):
                # Duplicate entries are wasteful — same string matched twice.
                dupes = [p for p in val if val.count(p) > 1]
                errors.append(
                    f"{field_name} contains duplicate entries: {sorted(set(dupes))}"
                )

        # Routability — a manifest with NO dag_id_patterns AND NO
        # db_connection_patterns can never match a polling row.  Silent
        # orphans are confusing — refuse at registration so the operator
        # knows to add at least one pattern OR explicitly accept it (e.g.
        # via the default_name fallback).
        if not self.dag_id_patterns and not self.db_connection_patterns:
            errors.append(
                "manifest has NO dag_id_patterns AND NO db_connection_patterns; "
                "no polling row will ever route here.  Add at least one pattern "
                "OR (if this is the registry's default_name fallback) leave a "
                "comment in the manifest explaining the empty-pattern intent."
            )

        # Capabilities: frozenset of strings.
        if not isinstance(self.capabilities, (frozenset, set)):
            errors.append("capabilities must be a frozenset")
        elif not all(isinstance(c, str) for c in self.capabilities):
            errors.append("capabilities must contain only strings")

        # Deprecation: replaced_by must point at another known plugin
        # (deferred to registry-level validation since it needs the
        # registry to check).

        # Lifecycle hooks: callable or None.
        for hook in ("on_register", "on_runner_start", "on_runner_stop"):
            val = getattr(self, hook)
            if val is not None and not callable(val):
                errors.append(f"{hook} must be callable or None")

        return errors


# ── back-compat alias ───────────────────────────────────────────────────
#
# Existing 7 builtin manifests and tests reference ``WorkflowDefinition``.
# Keep the symbol as a thin alias of ``PluginManifest`` so they continue
# to work unchanged.

WorkflowDefinition = PluginManifest


# ── per-plugin telemetry ────────────────────────────────────────────────


# 2026-07-01 -- credential scrubber for ``last_failure_reason``.  Worker
# exceptions can carry Trino URLs (``https://user:pw@host``), Oracle
# DSNs (``user/password@host:port/svc``), JWT bearer tokens, and
# ``Password=...`` OLEDB trailers.  These surface in /status +
# /workflows JSON responses.  Even with auth gating those endpoints
# there's no reason to keep secrets in-memory in cleartext — the
# telemetry record is a diagnostic aid, not an audit log.
#
# Patterns aggressive-but-safe: false positives are fine (only harms
# readability), false negatives (secrets leaking) are the real risk.

_CRED_SCRUB_PATTERNS = (
    # Password=value trailers (OLEDB / SQLAlchemy DSN / properties files)
    (re.compile(r"(?i)(password\s*=\s*)([^\s;,'\"]+)"),      r"\1***"),
    (re.compile(r"(?i)(user\s*id\s*=\s*)([^\s;,'\"]+)"),     r"\1***"),
    # 2026-07-01 hotfix-2 -- expanded coverage for the gaps the
    # security auditor caught.
    (re.compile(r"(?i)(pwd\s*=\s*)([^\s;,'\"]+)"),           r"\1***"),
    (re.compile(r"(?i)(passwd\s*=\s*)([^\s;,'\"]+)"),        r"\1***"),
    (re.compile(r"(?i)(secret\s*=\s*)([^\s;,'\"]+)"),        r"\1***"),
    (re.compile(r"(?i)(client_secret\s*=\s*)([^\s;,'\"]+)"), r"\1***"),
    (re.compile(r"(?i)(api[_-]?key\s*=\s*)([^\s;,'\"]+)"),   r"\1***"),
    (re.compile(r"(?i)(private_key_pwd\s*=\s*)([^\s;,'\"]+)"), r"\1***"),
    (re.compile(r"(?i)(trust\s*=\s*)([^\s;,'\"]+)"),         r"\1***"),
    (re.compile(r"(?i)(wallet_location\s*=\s*)([^\s;,'\"\)]+)"), r"\1***"),
    # HTTP Authorization headers
    (re.compile(r"(?i)(Bearer\s+)([A-Za-z0-9\-_.]+)"),       r"\1[BEARER-REDACTED]"),
    (re.compile(r"(?i)(Basic\s+)([A-Za-z0-9+/=]{4,})"),      r"\1[BASIC-REDACTED]"),
    # http(s)://user:password@host  URL credentials
    (re.compile(r"(https?://)([^/@\s]+):([^/@\s]+)@"),        r"\1***:***@"),
    # jdbc:...  password= inside JDBC URLs (already caught above but be safe)
    # user/password@host DSN (Easy Connect) -- keep host + user, mask pw
    (re.compile(r"(?<![A-Za-z0-9])([A-Za-z0-9_.\-]{2,})/([^\s@'\"]+)(@[A-Za-z0-9._:/\-]+)"),
                                                              r"\1/***\3"),
    # JWT-shaped bearer tokens (three dot-separated base64 segments)
    (re.compile(r"eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}"),
                                                              r"[JWT-REDACTED]"),
    # AWS-shaped keys
    (re.compile(r"AKIA[0-9A-Z]{16}"),                        r"[AWS-KEY-REDACTED]"),
    # GCP API keys
    (re.compile(r"AIza[0-9A-Za-z\-_]{35}"),                  r"[GCP-KEY-REDACTED]"),
    # GitHub personal / OAuth tokens
    (re.compile(r"gh[pousr]_[A-Za-z0-9]{36,}"),              r"[GITHUB-TOKEN-REDACTED]"),
    # Slack tokens
    (re.compile(r"xox[baprs]-[A-Za-z0-9\-]{10,}"),           r"[SLACK-TOKEN-REDACTED]"),
    # PEM headers (private keys) — collapse the whole block.
    (re.compile(
        r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----"
    ),                                                        r"[PEM-KEY-REDACTED]"),
    # Fernet-style base64 keys (44 chars, usually preceded by `=` or space)
    (re.compile(r"(?<![A-Za-z0-9])[A-Za-z0-9_\-]{43}=(?![A-Za-z0-9])"),
                                                              r"[FERNET-KEY-REDACTED]"),
)


# 2026-07-01 (item #16) -- helper used by ``route_dag_id`` to skip
# plugins whose worker class can't be loaded on the current image
# (typically a Spark-only worker on the lightweight polling image).
# Result cached per manifest since the outcome is process-const --
# either the module imports or it doesn't; the answer never changes.

_WORKER_LOADABLE_CACHE: Dict[str, bool] = {}
_WORKER_LOADABLE_CACHE_MAX = 512   # ≫ realistic plugin count
_WORKER_LOADABLE_CACHE_LOCK = threading.Lock()


def _worker_cls_loadable(manifest) -> bool:
    """True when ``manifest.worker_cls()`` returns a real class on
    this image.  Cached PER-INSTANCE (by ``id(manifest)``) so
    repeated router calls don't retry a known-failing import, but
    RE-REGISTRATION with a fresh loader is picked up automatically
    (each re-register creates a new manifest object with a new id).
    Never raises.

    2026-07-01 hotfix -- previously the cache was UNBOUNDED.  Every
    ``/admin/reload`` (which builds a fresh PluginManifest each call)
    added a new entry that was never pruned; ``id()`` is reused after
    GC so stale bool values could also survive.  Bounded FIFO with
    lock-protected insert keeps hot-reload safe.
    """
    key = f"{manifest.name}:{id(manifest)}"
    # 2026-07-01 hotfix-2 -- LOCK the read too.  Prior version did
    # ``.get()`` unlocked while another thread was inside the write
    # branch, which can hit a mid-resize state on the dict during
    # FIFO eviction + insert.  CPython's GIL makes single ops atomic
    # but the get + eviction + insert bracketing here is not atomic
    # across threads.  Symptom: sporadic RuntimeError on
    # ``/admin/reload`` under load.
    with _WORKER_LOADABLE_CACHE_LOCK:
        cached = _WORKER_LOADABLE_CACHE.get(key)
    if cached is not None:
        return cached
    try:
        cls = manifest.worker_cls()
        loadable = cls is not None
    except Exception:
        loadable = False
    with _WORKER_LOADABLE_CACHE_LOCK:
        # Re-check under the lock in case another thread inserted
        # while we were computing (dedup).
        if key in _WORKER_LOADABLE_CACHE:
            return _WORKER_LOADABLE_CACHE[key]
        # FIFO eviction: drop the first-inserted entry if full.  Dict
        # insertion order is preserved (Python 3.7+).
        if len(_WORKER_LOADABLE_CACHE) >= _WORKER_LOADABLE_CACHE_MAX:
            try:
                old_key = next(iter(_WORKER_LOADABLE_CACHE))
                _WORKER_LOADABLE_CACHE.pop(old_key, None)
            except StopIteration:                                    # pragma: no cover
                pass
        _WORKER_LOADABLE_CACHE[key] = loadable
    return loadable


def _clear_worker_loadable_cache() -> None:
    """Test helper -- reset the memoisation dict.  Called from
    tests that re-register plugins with different loaders to avoid
    stale cache entries."""
    _WORKER_LOADABLE_CACHE.clear()


def _sanitize_reason(reason: str) -> str:
    """Strip credential-looking substrings from a failure reason then
    truncate to 500 chars (existing contract preserved).  Idempotent."""
    if not reason:
        return ""
    scrubbed = str(reason)
    for pattern, repl in _CRED_SCRUB_PATTERNS:
        scrubbed = pattern.sub(repl, scrubbed)
    return scrubbed[:500]


@dataclass
class PluginTelemetry:
    """Per-plugin counters + last-N latencies.  Thread-safe via lock.

    Integrates with WorkflowRunner — every dispatch / completion /
    failure / timeout updates the corresponding counter and (where
    appropriate) records the duration.

    Exposed via:
      * ``GET /workflows/<name>`` health endpoint
      * Aggregated into ``GET /status`` totals
      * (Future) Prometheus metrics when ServiceMonitor is enabled.
    """
    name: str

    dispatched: int = 0
    completed: int = 0
    failed: int = 0
    timed_out: int = 0
    cancelled: int = 0
    skipped_cross_pod: int = 0
    skipped_at_capacity: int = 0

    last_dispatch_at: Optional[str] = None
    last_success_at: Optional[str] = None
    last_failure_at: Optional[str] = None
    last_failure_reason: str = ""

    # Rolling window of last 32 dispatch durations (seconds) — keeps
    # memory bounded; p50/p99 computed on demand.
    _durations: "collections.deque[float]" = field(
        default_factory=lambda: collections.deque(maxlen=32)
    )

    _lock: threading.Lock = field(default_factory=threading.Lock)

    @staticmethod
    def _utc_iso() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")

    def record_dispatch(self) -> None:
        with self._lock:
            self.dispatched += 1
            self.last_dispatch_at = self._utc_iso()

    def record_success(self, duration_s: float = 0.0) -> None:
        with self._lock:
            self.completed += 1
            self.last_success_at = self._utc_iso()
            if duration_s > 0:
                self._durations.append(duration_s)

    def record_failure(self, reason: str = "", duration_s: float = 0.0) -> None:
        with self._lock:
            self.failed += 1
            self.last_failure_at = self._utc_iso()
            self.last_failure_reason = _sanitize_reason(reason)
            if duration_s > 0:
                self._durations.append(duration_s)

    def record_timeout(self, duration_s: float = 0.0) -> None:
        with self._lock:
            self.timed_out += 1
            self.last_failure_at = self._utc_iso()
            self.last_failure_reason = f"timeout after {duration_s:.0f}s"
            if duration_s > 0:
                self._durations.append(duration_s)

    def record_cross_pod_skip(self) -> None:
        with self._lock:
            self.skipped_cross_pod += 1

    def record_capacity_skip(self) -> None:
        with self._lock:
            self.skipped_at_capacity += 1

    def record_cancelled(self) -> None:
        with self._lock:
            self.cancelled += 1

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            durs = sorted(self._durations)
            n = len(durs)
            p50 = durs[int(n * 0.50)] if n else 0.0
            p99 = durs[max(0, int(n * 0.99) - 1)] if n else 0.0
            success_rate = (
                self.completed / max(1, self.dispatched)
                if self.dispatched else None
            )
            return {
                "dispatched": self.dispatched,
                "completed": self.completed,
                "failed": self.failed,
                "timed_out": self.timed_out,
                "cancelled": self.cancelled,
                "skipped_cross_pod": self.skipped_cross_pod,
                "skipped_at_capacity": self.skipped_at_capacity,
                "success_rate": (
                    round(success_rate, 4) if success_rate is not None else None
                ),
                "last_dispatch_at": self.last_dispatch_at,
                "last_success_at": self.last_success_at,
                "last_failure_at": self.last_failure_at,
                "last_failure_reason": self.last_failure_reason,
                "duration_p50_s": round(p50, 3),
                "duration_p99_s": round(p99, 3),
                "duration_sample_count": n,
            }


# ── registry ────────────────────────────────────────────────────────────


class WorkflowRegistry:
    """Plugin registry: discovery + routing + validation + telemetry.

    Lifecycle:
      ``WorkflowRegistry.discover()`` walks the in-tree ``workflows/``
      package AND any setuptools entry points under ``qs_etl.workflows``,
      validates each manifest, fires ``on_register`` hooks, and detects
      priority collisions.  Returns the populated registry.

      ``register(manifest)`` registers a single manifest with full
      validation.  Duplicate canonical names OVERRIDE prior entries.

      ``route_dag_id(otg_dag_id, db_connection)`` returns the canonical
      workflow name for a polling row (priority order).

      ``get_telemetry(name)`` returns the live ``PluginTelemetry``
      instance for a plugin.

      ``validate_all()`` returns a structured report of every plugin's
      validation status — used by the diagnostic CLI.

      ``detect_collisions()`` returns (priority_collisions,
      pattern_overlaps) for startup checks + CLI.
    """

    DEFAULT_FALLBACK = "oracle"
    ENTRY_POINT_GROUP = "qs_etl.workflows"

    def __init__(self, default_name: str = DEFAULT_FALLBACK) -> None:
        self._defs: List[PluginManifest] = []
        self._by_name: Dict[str, PluginManifest] = {}
        self._telemetry: Dict[str, PluginTelemetry] = {}
        self.default_name = default_name
        # Locks register / register_runtime_override so a /admin/reload
        # called concurrently with auto-discovery cannot corrupt _defs.
        # Read paths (get, route_dag_id, names, __iter__) are NOT locked
        # — they consume the list/dict atomically; a concurrent register
        # may mean a route_dag_id sees the pre- or post-register state,
        # which is acceptable.
        self._write_lock = threading.Lock()

    # ── discovery ──────────────────────────────────────────────────────

    @classmethod
    def discover(
        cls,
        package_name: str = "workflows",
        default_name: str = DEFAULT_FALLBACK,
        load_entry_points: bool = True,
        strict_collisions: bool = True,
    ) -> "WorkflowRegistry":
        """Discover every plugin from the in-tree package + entry points.

        Args:
          package_name:        in-tree manifest package (default: ``workflows``).
          default_name:        fallback returned when routing finds no match.
          load_entry_points:   also load plugins from setuptools entry
                                points under ``qs_etl.workflows``.  Pass
                                False for hermetic tests.
          strict_collisions:   raise ``StartupValidationError`` on priority
                                collisions (default).  Pass False to allow
                                soft launch (logged WARN only).
        """
        reg = cls(default_name=default_name)

        # 1. In-tree manifest package
        reg._discover_in_tree(package_name, source="builtin")

        # 2. Setuptools entry points (external plugins)
        if load_entry_points:
            reg._discover_entry_points()

        # 3. Startup validation: collisions + cross-manifest checks
        priority_collisions, pattern_overlaps = reg.detect_collisions()
        if priority_collisions:
            msg = "Priority collisions detected (two plugins competing for the same pattern at same priority):\n"
            for a, b, pri, shared in priority_collisions:
                msg += f"  * {a!r} vs {b!r} at priority={pri}, shared patterns={sorted(shared)}\n"
            msg += (
                "Fix: change one plugin's priority OR remove the duplicate pattern.  "
                "Set strict_collisions=False to convert this to a WARN."
            )
            if strict_collisions:
                raise StartupValidationError(msg)
            logger.warning(msg)
        for a, b, pat_a, pat_b in pattern_overlaps:
            logger.warning(
                "Pattern overlap: %r (priority=%d) carries pattern %r which is "
                "a substring of %r's pattern %r (priority=%d).  Higher-priority "
                "plugin will win — verify this is intentional.",
                a.name, a.priority, pat_a, b.name, pat_b, b.priority,
            )

        # 4. Cross-manifest deprecation validation: replaced_by must point
        # at an existing plugin.
        for d in reg._defs:
            if d.replaced_by and d.replaced_by not in reg._by_name:
                logger.warning(
                    "Plugin %r declares replaced_by=%r but no such plugin "
                    "is registered — deprecation message will be confusing.",
                    d.name, d.replaced_by,
                )

        logger.info(
            "WorkflowRegistry.discover: %d plugin(s) registered "
            "(in-tree=%d, entry_points=%d, default_fallback=%r)",
            len(reg._defs),
            sum(1 for d in reg._defs if d.source == "builtin"),
            sum(1 for d in reg._defs if d.source.startswith("entry_point")),
            default_name,
        )
        return reg

    def _discover_in_tree(self, package_name: str, source: str) -> None:
        try:
            pkg = importlib.import_module(package_name)
        except ImportError as exc:
            logger.error(
                "WorkflowRegistry.discover: cannot import package %r — "
                "no in-tree plugins registered (%s)", package_name, exc,
            )
            return
        if not hasattr(pkg, "__path__"):
            logger.warning(
                "WorkflowRegistry.discover: %r has no __path__", package_name,
            )
            return
        for module_info in pkgutil.iter_modules(pkg.__path__, prefix=f"{package_name}."):
            if module_info.ispkg:
                continue
            try:
                mod = importlib.import_module(module_info.name)
            except Exception as exc:
                # ONE manifest failing must NOT block the others.
                logger.warning(
                    "WorkflowRegistry.discover: skipping %s (%s: %s)",
                    module_info.name, type(exc).__name__, exc,
                )
                continue
            manifest = getattr(mod, "WORKFLOW_DEF", None)
            if not isinstance(manifest, PluginManifest):
                logger.warning(
                    "WorkflowRegistry.discover: %s has no module-level "
                    "WORKFLOW_DEF (or wrong type) — skipping", module_info.name,
                )
                continue
            # Tag with source provenance.
            tagged = replace(manifest, source=source)
            try:
                self.register(tagged)
            except PluginValidationError as exc:
                logger.error(
                    "WorkflowRegistry.discover: manifest %s.WORKFLOW_DEF "
                    "rejected (%s)", module_info.name, exc,
                )

    def _discover_entry_points(self) -> None:
        """Load external plugins published by pip packages under
        the ``qs_etl.workflows`` entry-point group.  Each entry point
        must resolve to a ``PluginManifest`` instance."""
        try:
            eps = importlib.metadata.entry_points(group=self.ENTRY_POINT_GROUP)
        except Exception as exc:
            # importlib.metadata API varies by Python version; fail-safe.
            logger.debug(
                "Entry-points discovery unavailable: %s: %s",
                type(exc).__name__, exc,
            )
            return
        for ep in eps:
            try:
                manifest = ep.load()
            except Exception as exc:
                logger.warning(
                    "Entry-point %r failed to load: %s: %s",
                    ep.name, type(exc).__name__, exc,
                )
                continue
            if not isinstance(manifest, PluginManifest):
                logger.warning(
                    "Entry-point %r resolved to %s, not PluginManifest — skipping",
                    ep.name, type(manifest).__name__,
                )
                continue
            tagged = replace(manifest, source=f"entry_point:{ep.name}")
            try:
                self.register(tagged)
                logger.info(
                    "Entry-point %r registered plugin %r (source=%s)",
                    ep.name, tagged.name, tagged.source,
                )
            except PluginValidationError as exc:
                logger.error(
                    "Entry-point %r manifest rejected: %s", ep.name, exc,
                )

    # ── registration + validation ──────────────────────────────────────

    def register(self, manifest: PluginManifest) -> None:
        """Validate + register a manifest.  Re-registering the same
        canonical name DROPS the prior + its aliases so override is
        clean.  Fires ``on_register`` lifecycle hook after registration.

        Note: ``replaced_by`` is NOT validated here because plugins may
        be registered in any order (alphabetical discovery, then entry
        points).  The cross-manifest replaced_by check is done at the
        end of ``discover()`` once every plugin has had its chance to
        register.
        """
        errors = manifest.validate()
        if errors:
            raise PluginValidationError(
                f"Manifest {manifest.name!r} (source={manifest.source!r}) is invalid:\n"
                + "\n".join(f"  * {e}" for e in errors)
            )

        with self._write_lock:
            prior = self._by_name.get(manifest.name)
            if prior is not None:
                new_defs = [d for d in self._defs if d.name != manifest.name]
                for alias in prior.aliases:
                    self._by_name.pop(alias, None)
            else:
                # 2026-07-01 hotfix -- copy-on-write.  Previous impl
                # did ``self._defs.append(manifest)`` + ``.sort(...)``
                # in place while unlocked readers iterated the same
                # list, which raises ``RuntimeError: list modified
                # during iteration`` under concurrent /admin/reload +
                # poll cycle.  Rebuild + sort a LOCAL list, then swap
                # the reference atomically — readers holding the old
                # reference finish their iteration cleanly.
                new_defs = list(self._defs)

            new_defs.append(manifest)
            new_defs.sort(key=lambda d: d.priority)
            self._defs = new_defs  # atomic swap on the read side

            self._by_name[manifest.name] = manifest
            for alias in manifest.aliases:
                self._by_name[alias] = manifest

            # Initialise telemetry slot.
            self._telemetry.setdefault(manifest.name, PluginTelemetry(name=manifest.name))

        # Fire lifecycle hook (after sort + telemetry init so the hook
        # sees a fully-registered registry state).
        if manifest.on_register is not None:
            try:
                manifest.on_register(manifest)
            except Exception as exc:
                logger.warning(
                    "on_register hook for %r raised %s: %s — registration "
                    "succeeded but the hook failed (non-fatal).",
                    manifest.name, type(exc).__name__, exc,
                )

    def get(self, name: str) -> Optional[PluginManifest]:
        """Resolve canonical name OR alias."""
        return self._by_name.get(name)

    def names(self) -> List[str]:
        """Canonical names in priority order."""
        return [d.name for d in self._defs]

    def installed_names(self) -> List[str]:
        """Canonical names whose worker_cls() resolves on THIS image."""
        return [d.name for d in self._defs if d.worker_cls() is not None]

    def __iter__(self) -> Iterable[PluginManifest]:
        return iter(self._defs)

    def __contains__(self, name: str) -> bool:
        return name in self._by_name

    def __len__(self) -> int:
        return len(self._defs)

    # ── routing ────────────────────────────────────────────────────────

    def route_dag_id(
        self,
        otg_dag_id: Optional[str],
        db_connection: Optional[str] = None,
    ) -> str:
        """Return the canonical workflow name for a polling row.

        2026-07-01 fix (item #16) -- when a plugin's ``worker_cls()``
        returns None on this image (Spark-only worker on lightweight
        image, or a plugin whose _load raised) the dispatcher raises
        ValueError at execute time.  Preferring an unroutable / no-worker
        outcome over a route to the wrong plugin.  The router now
        SKIPS plugins whose worker isn't loadable on this image, so
        the dispatcher's ``no_capable_runner`` branch fires -- audible
        via the poll_cycle ``unrouted`` counter.
        """
        dag_lower = (otg_dag_id or "").lower()
        for d in self._defs:
            if d.matches_dag_id(dag_lower):
                if _worker_cls_loadable(d):
                    return d.name
                # Keep looking -- there may be another plugin whose
                # pattern also matches AND whose worker IS loadable.
        db_upper = (db_connection or "").upper()
        if db_upper:
            for d in self._defs:
                if d.matches_db_connection(db_upper):
                    if _worker_cls_loadable(d):
                        return d.name
        # Default plugin: preserve back-compat -- if the default_name
        # isn't registered at all, return it verbatim (matches
        # long-standing behaviour where the default is a NAME hint,
        # not a plugin reference).  If it IS registered AND its
        # worker isn't loadable on this image, return the
        # ``__no_capable_runner__`` sentinel so dispatcher logs the
        # image-mismatch reason instead of raising an opaque
        # KeyError at execute time.
        default = self.get(self.default_name)
        if default is None:
            return self.default_name
        if _worker_cls_loadable(default):
            return self.default_name
        return "__no_capable_runner__"

    # ── telemetry ──────────────────────────────────────────────────────

    def get_telemetry(self, name: str) -> Optional[PluginTelemetry]:
        """Return the live telemetry instance for a plugin (canonical
        name or alias).  Returns None for unknown plugins."""
        manifest = self.get(name)
        if manifest is None:
            return None
        return self._telemetry.get(manifest.name)

    def all_telemetry(self) -> Dict[str, PluginTelemetry]:
        """Snapshot of every plugin's telemetry (canonical-name keyed)."""
        return dict(self._telemetry)

    # ── operator overrides (from polling YAML worker_class_path) ───────

    def register_runtime_override(
        self,
        name: str,
        worker_class_path: str,
        needs_starburst_clients: Optional[bool] = None,
    ) -> None:
        """Honour ``WorkflowConfig.worker_class_path`` by registering an
        override manifest that uses the dotted-path worker class."""
        module_path, _, class_name = worker_class_path.rpartition(".")
        if not module_path or not class_name:
            raise ValueError(
                f"[{name}] worker_class_path={worker_class_path!r} must be a "
                f"dotted import path like 'workers.oracle_worker.OracleWorker'"
            )

        def _load() -> Optional[type]:
            try:
                mod = importlib.import_module(module_path)
                return getattr(mod, class_name)
            except (ImportError, AttributeError) as exc:
                raise RuntimeError(
                    f"[{name}] cannot import worker_class_path="
                    f"{worker_class_path!r}: {exc}"
                ) from exc

        existing = self.get(name)
        needs_sb = needs_starburst_clients
        if needs_sb is None:
            needs_sb = (
                existing.needs_starburst_clients
                if existing is not None
                else ("Oracle" in class_name or "File" in class_name)
            )
        self.register(PluginManifest(
            name=name,
            version=(existing.version if existing else "1.0.0"),
            worker_cls_loader=_load,
            dag_id_patterns=existing.dag_id_patterns if existing else (name.lower(),),
            db_connection_patterns=existing.db_connection_patterns if existing else (name.upper(),),
            needs_starburst_clients=needs_sb,
            lightweight_capable=existing.lightweight_capable if existing else True,
            aliases=existing.aliases if existing else (),
            priority=existing.priority if existing else 100,
            description=(
                existing.description if existing else ""
            ),
            capabilities=existing.capabilities if existing else frozenset(),
            source="operator_override",
        ))

    # ── validation + diagnostic helpers ─────────────────────────────────

    def validate_all(self) -> Dict[str, Any]:
        """Run full validation across every registered manifest.  Returns
        a structured report consumed by the diagnostic CLI."""
        results: List[Dict[str, Any]] = []
        for d in self._defs:
            errors = d.validate()
            cls = d.worker_cls()
            results.append({
                "name": d.name,
                "version": d.version,
                "source": d.source,
                "manifest_version": d.manifest_version,
                "valid": not errors,
                "errors": errors,
                "worker_loadable": cls is not None,
                "worker_class": cls.__name__ if cls is not None else None,
                "is_deprecated": d.is_deprecated,
                "lightweight_capable": d.lightweight_capable,
            })
        priority_collisions, pattern_overlaps = self.detect_collisions()
        return {
            "plugin_count": len(self._defs),
            "valid_count": sum(1 for r in results if r["valid"]),
            "invalid_count": sum(1 for r in results if not r["valid"]),
            "results": results,
            "priority_collisions": [
                {"a": a, "b": b, "priority": pri, "shared_patterns": sorted(shared)}
                for a, b, pri, shared in priority_collisions
            ],
            "pattern_overlaps": [
                {"loser": a.name, "loser_priority": a.priority, "loser_pattern": pa,
                 "winner": b.name, "winner_priority": b.priority, "winner_pattern": pb}
                for a, b, pa, pb in pattern_overlaps
            ],
        }

    def detect_collisions(self) -> Tuple[
        List[Tuple[str, str, int, set]],
        List[Tuple[PluginManifest, PluginManifest, str, str]],
    ]:
        """Return (priority_collisions, pattern_overlaps).

        priority_collisions: two plugins at SAME priority that share at
        least one identical pattern.  Routing order between them is
        undefined → startup error.

        pattern_overlaps: plugin A's pattern is a substring of plugin B's
        pattern AND A has higher priority number (= lower precedence) →
        WARN so operator can confirm intent.
        """
        # Priority collisions
        by_priority: Dict[int, List[PluginManifest]] = {}
        for d in self._defs:
            by_priority.setdefault(d.priority, []).append(d)
        collisions: List[Tuple[str, str, int, set]] = []
        for priority, defs_at_p in by_priority.items():
            if len(defs_at_p) <= 1:
                continue
            for i, a in enumerate(defs_at_p):
                for b in defs_at_p[i + 1:]:
                    shared = set(a.dag_id_patterns) & set(b.dag_id_patterns)
                    if shared:
                        collisions.append((a.name, b.name, priority, shared))

        # Substring overlaps (only across different priorities — same
        # priority is the collision case above).
        overlaps: List[Tuple[PluginManifest, PluginManifest, str, str]] = []
        for a in self._defs:
            for b in self._defs:
                if a.name == b.name or a.priority == b.priority:
                    continue
                for pa in a.dag_id_patterns:
                    for pb in b.dag_id_patterns:
                        if pa == pb:
                            continue
                        # b wins if (a) priority < b.priority (no, lower = wins)
                        # so a "loses" if a.priority > b.priority.
                        if pa in pb and a.priority > b.priority:
                            overlaps.append((a, b, pa, pb))
        return collisions, overlaps


# ── module-level singleton for production callers ──────────────────────


_singleton: Optional[WorkflowRegistry] = None
_singleton_lock = threading.Lock()


def get_registry() -> WorkflowRegistry:
    """Return the process-wide WorkflowRegistry, lazily discovered on
    first call.  Tests should construct their own ``WorkflowRegistry()``
    instead of mutating this one.

    2026-07-01 hygiene -- protected under ``_singleton_lock`` so two
    concurrent boot-time callers don't each run discovery + double-fire
    every plugin's on_register hook.
    """
    global _singleton
    if _singleton is not None:
        return _singleton
    with _singleton_lock:
        if _singleton is None:
            _singleton = WorkflowRegistry.discover()
    return _singleton


def reset_registry() -> None:
    """Test hook — drop the singleton so the next get_registry() call
    re-runs discovery."""
    global _singleton
    with _singleton_lock:
        _singleton = None
