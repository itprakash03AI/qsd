"""Helpers to scrub credential-carrying fields out of polling-row
dicts + exception messages BEFORE they touch a log statement.

2026-07-01 (item #17 companion) -- the shared ``bg_polling_query``
selects ``C_PWD``, ``P_PWD``, ``SAPP``, ``SAPU`` unconditionally for
every row (union-of-all-workflows column set).  Non-SAP workers
ignore them but a stray ``self.logger.info(f"task={task}")`` line
would leak all four fields to the log stream.  The safer defence
is a per-key scrubber that log-emitting code can wrap around a task
dict before formatting -- see ``scrub_task_for_log``.

The list is CONSERVATIVE -- when in doubt, add the field.  A
redacted log line is annoying; a leaked credential is a security
event.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable


# Field-name substrings that suggest a credential.  Case-insensitive
# match against dict keys.  If ANY substring matches, the value is
# replaced with ``***``.  Redaction happens on a COPY -- the original
# task dict is never mutated.
_CRED_SUBSTRINGS = (
    "pwd",         # c_pwd, p_pwd
    "password",    # sap.password, oracle.password
    "sapp",        # SAP password field per bg_polling_query
    "secret",      # generic
    "token",       # oauth / bearer
    "api_key",     # generic
    "apikey",
    "auth",        # authorization headers
    "credential",  # generic
    "private_key",
)


def _is_sensitive_key(key: str) -> bool:
    kl = key.lower()
    return any(sub in kl for sub in _CRED_SUBSTRINGS)


def scrub_task_for_log(
    task: Any,
    *,
    extra_sensitive_keys: Iterable[str] = (),
) -> Dict[str, Any]:
    """Return a copy of ``task`` where every credential-shaped field
    is replaced with ``***``.  The input is not mutated.  Non-dict
    inputs pass through unchanged (with ``[non-dict]`` sentinel for
    downstream str formatting).

    ``extra_sensitive_keys`` -- exact key names to ALSO redact
    (workflow-specific hits the substring check would miss).
    """
    if not isinstance(task, dict):
        return {"_scrubbed_wrapper": "[non-dict task passed to scrub_task_for_log]"}
    extra = {k.lower() for k in extra_sensitive_keys}
    out: Dict[str, Any] = {}
    for k, v in task.items():
        if not isinstance(k, str):
            out[k] = v
            continue
        if _is_sensitive_key(k) or k.lower() in extra:
            out[k] = "***"
        elif isinstance(v, dict):
            out[k] = scrub_task_for_log(v, extra_sensitive_keys=extra_sensitive_keys)
        else:
            out[k] = v
    return out


__all__ = ["scrub_task_for_log"]
