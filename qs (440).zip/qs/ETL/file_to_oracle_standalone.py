"""File→Oracle standalone entry point.

Airflow triggers one pod per RUN_ID + business_date + dag_id; this
script pulls the polling rows that match, walks them in SEQ order, and
hands each to FileToOracleWorker.

Same lifecycle as ``file_standalone.py``:

  1. Pin a single log file via ``set_run_log_file``.
  2. Bootstrap a FileRunReport + RunArtifacts up-front; START email
     sent on entry; FINISH (SUCCESS / FAILED) email + HTML report
     ALWAYS written in ``finally``.
  3. On ANY exception, ``RunArtifacts.cleanup_on_failure()`` wipes
     every chunk / consolidated / compressed / ctl file we created
     (the source file is registered as REPORT category so it stays).
"""
from __future__ import annotations

# ============================================================================
# PREFLIGHT BOOTSTRAP -- MUST run BEFORE any 3rd-party / project imports.
# 2026-06-21 bug #13.  See file_standalone.py for full explanation.
# ============================================================================
import os as _bootstrap_os
import sys as _bootstrap_sys
from pathlib import Path as _BootstrapPath
_bootstrap_etl_root = str(_BootstrapPath(__file__).resolve().parent)
if _bootstrap_etl_root not in _bootstrap_sys.path:
    _bootstrap_sys.path.insert(0, _bootstrap_etl_root)
try:
    from preflight import preflight_check as _preflight_check
    _preflight_check(
        workflow="file_to_oracle",
        auto_install=True,
        install_optional=True,
        fail_on_missing_required=True,
    )
except ImportError:
    pass
# === END PREFLIGHT BOOTSTRAP ===

import argparse
import asyncio
import logging
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

import yaml

# spark-submit uploads ONLY this script to a temp dir like
# /usr/local/spark/pvc/jars/spark-upload-<uuid>/ -- so __file__.parent
# is an empty dir.  Probe well-known roots for the log_config sentinel
# instead of trusting __file__.parent.  See file_standalone.py for the
# full rationale.
_SENTINEL = "log_config.py"
_CANDIDATE_ROOTS: List[str] = []
_env_etl_home = os.environ.get("ETL_HOME")
if _env_etl_home:
    _CANDIDATE_ROOTS.append(_env_etl_home)
_CANDIDATE_ROOTS.extend([
    "/usr/local/spark/pvc/code",
    "/usr/local/spark/pvc/code/etl",
    "/usr/local/spark/pvc",
    str(Path(__file__).resolve().parent),
])
ETL_ROOT = next(
    (p for p in _CANDIDATE_ROOTS if p and os.path.isfile(os.path.join(p, _SENTINEL))),
    str(Path(__file__).resolve().parent),
)
if ETL_ROOT not in sys.path:
    sys.path.insert(0, ETL_ROOT)

from log_config import get_log_dir, set_run_log_file, set_workflow_name  # noqa: E402
from date_utils import normalize_business_date  # noqa: E402
from managers.oracle_metadata_manager import OracleMetadataManager  # noqa: E402
from workers.file_to_oracle_worker import FileToOracleWorker  # noqa: E402
from steps.file.run_report import FileRunReport  # noqa: E402
from steps.file.run_state import (  # noqa: E402
    RunArtifacts, get_or_create_artifacts,
    delete_sidecar, backup_stale_sidecar,
)


_PROD_CONFIG_PATH = "/usr/local/spark/pvc/code/configs/oracle_config.yaml"
_PROD_QUERIES_PATH = "/usr/local/spark/pvc/code/configs/etl_polling_task_query.yaml"
_LOCAL_CONFIG_PATH = os.path.join(ETL_ROOT, "configs", "oracle_config.yaml")
_LOCAL_QUERIES_PATH = os.path.join(ETL_ROOT, "configs", "etl_polling_task_query.yaml")


def _resolve_path(prod: str, local: str) -> str:
    return prod if os.path.exists(prod) else local


def _summarise_task_state(task: Dict[str, Any]) -> str:
    """Snapshot the task-dict keys that downstream steps inspect.
    Mirrors file_standalone._summarise_task_state so both standalones
    surface the same failure context.
    """
    def _short(v: Any) -> str:
        if isinstance(v, (list, tuple)):
            n = len(v)
            head = ", ".join(repr(x) for x in v[:2])
            tail = f", ... (+{n - 2})" if n > 2 else ""
            return f"[{head}{tail}] (len={n})"
        s = repr(v)
        return s[:200] + ("..." if len(s) > 200 else "")
    KEYS = (
        "run_id", "run_detail_id", "fk_dag_id", "fk_report_id",
        "task_steps", "seq",
        "output_dir", "log_file", "sql_query_path",
        "job_results", "chunk_files", "consolidated_file", "consolidated_total",
        "expected_total", "sum_partition_expected", "sum_chunk_actual",
        "totalcount", "artifact_paths",
    )
    return "\n".join(
        f"  {k}={_short(task.get(k))}" if k in task else f"  {k}=<absent>"
        for k in KEYS
    )


def _build_log_file(dag_id: str, report_id: int, business_date: str) -> str:
    """Per-batch log filename.

    2026-07-02 -- retention sweep BEFORE returning: keep 1 previous
    ``file_to_oracle_{dag}_{report}_*.log`` so the newly-created log
    makes exactly 2 total per (dag, report) tuple.  User directive:
    "keep only last 2 run logs and delete old ones".  Fail-open.
    """
    safe_dag = re.sub(r"[\\/\s]+", "_", str(dag_id))[:60]
    safe_date = re.sub(r"[\\/\s]+", "-", str(business_date))[:20]
    ts = datetime.now().strftime("%H%M%S")
    base_dir = get_log_dir()
    log_path = os.path.join(
        base_dir,
        f"file_to_oracle_{safe_dag}_{report_id}_{safe_date}_{ts}.log",
    )
    try:
        from log_retention import prune_old_logs
        prune_old_logs(
            log_dir=base_dir,
            prefix=f"file_to_oracle_{safe_dag}_{report_id}_",
            keep=1,
            logger=logger,
        )
    except Exception as exc:
        try:
            logger.warning("Log retention sweep failed (ignored): %s", exc)
        except Exception:
            pass
    return log_path


logger = logging.getLogger("file_to_oracle_standalone")
logger.setLevel(logging.INFO)
if not logger.handlers:
    _sh = logging.StreamHandler(sys.stdout)
    _sh.setFormatter(logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s"))
    logger.addHandler(_sh)


def _attach_file_handler(log_file: str) -> None:
    try:
        os.makedirs(os.path.dirname(log_file) or ".", exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s"))
        logger.addHandler(fh)
        logger.info("Logging pinned to: %s", log_file)
    except OSError as exc:
        logger.warning("Cannot create log file %s: %s — console only", log_file, exc)


def _email_config_from(config: Dict[str, Any], task: Dict[str, Any]) -> Dict[str, Any]:
    email_cfg: Dict[str, Any] = {}
    yaml_block = (config or {}).get("email", {}) or {}
    for k in (
        "send_email", "smtp_host", "smtp_port", "smtp_user", "smtp_password",
        "smtp_use_tls", "email_from", "email_to", "email_subject",
    ):
        if k in yaml_block:
            email_cfg[k] = yaml_block[k]
    for src, dst in (
        ("SEND_EMAIL", "send_email"),
        ("SMTP_HOST", "smtp_host"),
        ("SMTP_PORT", "smtp_port"),
        ("SMTP_USER", "smtp_user"),
        ("SMTP_PASSWORD", "smtp_password"),
        ("SMTP_USE_TLS", "smtp_use_tls"),
        ("EMAIL_FROM", "email_from"),
        ("EMAIL_TO", "email_to"),
        ("EMAIL_SUBJECT", "email_subject"),
    ):
        v = task.get(src) or task.get(src.lower())
        if v not in (None, "", 0):
            email_cfg[dst] = v
    return email_cfg


async def execute_tasks(
    tasks: List[Dict[str, Any]],
    config: Dict[str, Any],
    worker_connection_string: str,
    dest_connection_string: str,
    log_file: str,
    run_report: FileRunReport,
    artifacts: RunArtifacts,
) -> None:
    if not tasks or not worker_connection_string or not dest_connection_string:
        raise ValueError("execute_tasks: tasks + both connection strings required")
    oracle_data_manager = OracleMetadataManager(worker_connection_string)
    worker = FileToOracleWorker(
        oracle_data_manager=oracle_data_manager,
        logger=logger,
        load_config=config.get("file_to_oracle", {}) or {},
    )
    # 2026-06-12 — per-run STABLE sidecar location (decoupled from
    # per-row file_location).  See file_standalone.py for rationale.
    sidecar_dir = os.path.dirname(log_file) if log_file else ""
    # 2026-06-13 — per-run backup_ts for the "rename prior file to
    # backup folder" feature.  See file_standalone.py for rationale.
    backup_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    # 2026-06-13 — operator-controlled prior-output handling.
    # "backup" (default) or "delete".  Polling row > yaml > default.
    _sample = tasks[0]
    _file_cfg = (config.get("file_flow") or {}) if isinstance(config, dict) else {}
    prior_output_mode = (
        (_sample.get("prior_output_mode") or _sample.get("PRIOR_OUTPUT_MODE"))
        or _file_cfg.get("prior_output_mode")
        or "backup"
    )

    # 2026-06-26 -- release Spark right after the LAST Spark-using step
    # (DelimitedFileToOracle / ParquetFileToOracle) so the tail
    # (CheckCompleteness, ProcessData, SendEmail) doesn't hold Spark
    # executors+memory.
    from spark_lifecycle import install_pipeline_spark_release
    maybe_release_spark = install_pipeline_spark_release(tasks, logger)

    for i, task in enumerate(tasks):
        task["log_file"] = log_file
        task["_run_report"] = run_report
        task["_run_artifacts"] = artifacts
        # 2026-06-12 — set task["output_dir"] from polling-row columns
        # ONLY.  See file_standalone.py for the resolution order
        # rationale (file_location -> output_file_location -> output_dir).
        fl = (
            task.get("file_location")
            or task.get("output_file_location")
            or task.get("output_dir")
        )
        if fl:
            task["output_dir"] = fl
        # Sidecar location is stable across all tasks for this run --
        # save_task_state / hydrate_task_from_sidecar prefer this over
        # the per-task output_dir which varies per polling row.
        if sidecar_dir:
            task["sidecar_dir"] = sidecar_dir
        task["backup_ts"] = backup_ts
        task["prior_output_mode"] = prior_output_mode
        get_or_create_artifacts(task, logger=logger)
        step_name = task.get("task_steps")
        logger.info(
            "Dispatching: run_id=%s seq=%s step='%s' dag_id=%s report_id=%s",
            task.get("run_id"), task.get("seq"), step_name,
            task.get("fk_dag_id"), task.get("fk_report_id"),
        )
        try:
            await worker.execute_step(
                task, worker_connection_string, dest_connection_string, step_name,
            )
        except Exception as exc:
            # 2026-06-12 — full traceback + task-state snapshot.
            import traceback as _tb
            _state = _summarise_task_state(task)
            logger.error(
                "Step '%s' for task run_id=%s FAILED: %s\n"
                "TASK STATE AT FAILURE:\n%s\n"
                "TRACEBACK:\n%s",
                step_name, task.get("run_id"), exc, _state, _tb.format_exc(),
            )
            raise
        finally:
            maybe_release_spark(i)


async def main() -> None:
    parser = argparse.ArgumentParser(
        description="Execute a File→Oracle task for a specific report ID and business date.",
    )
    parser.add_argument("--report_id", type=int, required=True)
    parser.add_argument("--business_date", type=str, required=True,
                         help='Accepted: dd-MM-yyyy ("30-06-2025"), ISO ("2025-06-30"), '
                              'dd/MM/yyyy, dd-Mon-yyyy.  Normalised to DD-MM-YYYY for '
                              'the polling SQL bind.')
    parser.add_argument("--dag_id", type=str, required=True)
    parser.add_argument(
        "--config_path", type=str,
        default=_resolve_path(_PROD_CONFIG_PATH, _LOCAL_CONFIG_PATH),
    )
    parser.add_argument(
        "--queries_path", type=str,
        default=_resolve_path(_PROD_QUERIES_PATH, _LOCAL_QUERIES_PATH),
    )
    parser.add_argument("--no-auto-install", action="store_true",
                          help="Skip auto-install of missing REQUIRED packages")
    parser.add_argument("--no-install-optional", action="store_true",
                          help="Skip auto-install of OPTIONAL packages")

    # 2026-06-27 -- --machine / --vault-token-method for qs_credentials.
    from runtime_env import add_runtime_env_args
    add_runtime_env_args(parser)

    args = parser.parse_args()

    # Export --machine to env BEFORE any qs_credentials import fires.
    from runtime_env import apply_runtime_env_args
    apply_runtime_env_args(args, logger=logger)

    # 2026-06-21 -- preflight already ran at top-of-file bootstrap.
    # Honour CLI opt-outs for explicit re-check.
    if args.no_auto_install or args.no_install_optional:
        try:
            from preflight import preflight_check
            preflight_check(
                workflow="file_to_oracle",
                auto_install=not args.no_auto_install,
                install_optional=not args.no_install_optional,
            )
        except ImportError:
            pass

    # 2026-06-12 — tolerate common business_date input formats and
    # normalise to DD-MM-YYYY for the polling SQL bind.
    try:
        args.business_date = normalize_business_date(args.business_date)
    except ValueError as exc:
        parser.error(str(exc))

    log_file = _build_log_file(args.dag_id, args.report_id, args.business_date)
    _attach_file_handler(log_file)
    set_run_log_file(log_file)
    set_workflow_name("file_to_oracle")
    os.environ["ETL_WORKFLOW_NAME"] = "file_to_oracle"

    if not os.path.exists(args.config_path):
        raise FileNotFoundError(f"Configuration file not found: {args.config_path}")
    with open(args.config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
    if "oracle" not in config:
        raise ValueError(f"oracle_config.yaml missing 'oracle' section: {args.config_path}")

    if not os.path.exists(args.queries_path):
        raise FileNotFoundError(f"Queries file not found: {args.queries_path}")
    with open(args.queries_path, "r", encoding="utf-8") as f:
        queries = yaml.safe_load(f) or {}
    # Polling query is operator-provided.  Falls back to the same query
    # the file flow uses if a dedicated one isn't configured.
    query_key = "polling_query_file_to_oracle"
    if query_key not in queries:
        if "polling_query_sb_to_file" not in queries:
            raise ValueError(
                f"Neither {query_key} nor polling_query_sb_to_file found in "
                f"etl_polling_task_query.yaml — operator must populate one."
            )
        logger.warning(
            "polling_query_file_to_oracle not found — falling back to "
            "polling_query_sb_to_file.  Add a dedicated query when ready."
        )
        query_key = "polling_query_sb_to_file"

    # 2026-06-22 -- vault-aware ETL connection string resolution.
    from oracle_config_loader import resolve_etl_connection_string
    worker_connection_string = resolve_etl_connection_string(config)
    if not worker_connection_string:
        raise ValueError(
            "ETL Oracle connection string unresolved.  Set yaml literal, "
            "oracle.etl.secret_ref (vault), or ETL_ORACLE_CONN env var."
        )
    oracle_data_manager = OracleMetadataManager(worker_connection_string)

    tasks_df = await oracle_data_manager.execute_query_asynch(
        queries[query_key],
        {"1": args.report_id, "2": args.business_date, "3": args.dag_id},
        worker_connection_string,
    )
    if tasks_df is None or tasks_df.empty:
        logger.info(
            "No tasks for report_id=%s business_date=%s dag_id=%s",
            args.report_id, args.business_date, args.dag_id,
        )
        return
    tasks = tasks_df.to_dict(orient="records")
    tasks = [{(k.lower() if isinstance(k, str) else k): v for k, v in row.items()}
              for row in tasks]
    tasks.sort(key=lambda t: int(t.get("seq") or 0))

    for t in tasks:
        t["task_id"] = t.get("run_id")
        t["dag_run_id"] = f"run_{t.get('run_id')}"

    sample = tasks[0]
    output_dir = (
        sample.get("output_dir")
        or sample.get("source_file_location")
        or os.path.join(get_log_dir(), f"file_to_oracle_run_{args.report_id}_{args.business_date}")
    )
    try:
        os.makedirs(output_dir, exist_ok=True)
    except OSError as exc:
        logger.warning("Could not create output_dir %s: %s", output_dir, exc)

    # 2026-06-12 — every artefact filename / subdir comes from the
    # polling row first, then oracle_config.yaml's run_report block.
    _rr_cfg = (config.get("run_report") or {}) if isinstance(config, dict) else {}
    _rr_backup_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    _rr_file_cfg = (config.get("file_flow") or {}) if isinstance(config, dict) else {}
    _rr_prior_mode = (
        (sample.get("prior_output_mode") or sample.get("PRIOR_OUTPUT_MODE"))
        or _rr_file_cfg.get("prior_output_mode")
        or "backup"
    )
    run_report = FileRunReport(
        output_dir=output_dir,
        logger=logger,
        queries_subdir=(
            sample.get("queries_subdir")
            or _rr_cfg.get("queries_subdir", "")
        ),
        report_filename_html=(
            sample.get("report_filename_html")
            or _rr_cfg.get("report_filename_html", "")
        ),
        report_filename_txt=(
            sample.get("report_filename_txt")
            or _rr_cfg.get("report_filename_txt", "")
        ),
        sql_file_extension=(
            sample.get("sql_file_extension")
            or _rr_cfg.get("sql_file_extension", "")
        ),
        backup_ts=_rr_backup_ts,
        prior_output_mode=_rr_prior_mode,
    )
    run_report.set_context(
        run_id=sample.get("run_id"),
        run_detail_id=sample.get("run_detail_id"),
        dag_id=args.dag_id,
        report_id=args.report_id,
        business_date=args.business_date,
        log_file=log_file,
        output_dir=output_dir,
        workflow="file_to_oracle",
    )
    def _truthy_yaml(v):
        if isinstance(v, bool):
            return v
        if v is None:
            return False
        return str(v).strip().upper() in {"TRUE", "1", "YES", "Y", "T"}
    _preserve_chunks = _truthy_yaml(
        sample.get("preserve_chunks_on_failure")
        or sample.get("PRESERVE_CHUNKS_ON_FAILURE")
        or _rr_file_cfg.get("preserve_chunks_on_failure")
    )
    artifacts = RunArtifacts(
        logger=logger,
        preserve_chunks_on_failure=_preserve_chunks,
    )
    artifacts.add(log_file, RunArtifacts.REPORT)

    # 2026-06-12 -- pre-run sidecar hygiene.  See file_standalone.py
    # for the rationale.  Sidecar lives at log_dir (per-run stable);
    # also back up any legacy per-row file_location sidecar for older runs.
    _run_sidecar_dir = os.path.dirname(log_file) if log_file else ""
    _seen_backups = set()
    for _t in tasks:
        _bases = []
        if _run_sidecar_dir:
            _bases.append(_run_sidecar_dir)
        _legacy = (
            _t.get("file_location")
            or _t.get("output_file_location")
            or _t.get("output_dir")
        )
        if _legacy and _legacy not in _bases:
            _bases.append(_legacy)
        _rid = _t.get("run_id")
        for _b in _bases:
            _key = (_b, _rid)
            if _key in _seen_backups:
                continue
            _seen_backups.add(_key)
            backup_stale_sidecar(_b, _rid, logger=logger)

    run_report.mark_started()
    email_cfg = _email_config_from(config, sample)
    run_report.write()
    run_report.send_email(email_cfg)

    # 2026-06-22 -- vault-aware destination connection string.
    # Polling-row db_connection still wins.
    from oracle_config_loader import resolve_dest_connection_string
    dest_connection_string = (
        sample.get("db_connection")
        or resolve_dest_connection_string(config)
        or ""
    )

    exit_code = 0
    try:
        await execute_tasks(
            tasks=tasks,
            config=config,
            worker_connection_string=worker_connection_string,
            dest_connection_string=dest_connection_string,
            log_file=log_file,
            run_report=run_report,
            artifacts=artifacts,
        )
        run_report.mark_success()
        last = tasks[-1] if tasks else {}
        run_report.set_counts(
            expected_total=last.get("expected_total"),
            sum_partition_expected=last.get("expected_total"),
            sum_chunk_actual=last.get("sum_chunk_actual"),
            consolidated_total=last.get("consolidated_total"),
        )
        # 2026-06-12 -- delete sidecar on SUCCESS.  See file_standalone
        # for the rationale.  Sidecar is at the per-run sidecar_dir;
        # also clean any legacy per-row sidecars from older builds.
        _seen_deletes = set()
        for _t in tasks:
            _bases = []
            _sd = _t.get("sidecar_dir")
            if _sd:
                _bases.append(_sd)
            _fallback = _t.get("output_dir") or _t.get("file_location")
            if _fallback and _fallback not in _bases:
                _bases.append(_fallback)
            _rid = _t.get("run_id")
            for _b in _bases:
                _key = (_b, _rid)
                if _key in _seen_deletes:
                    continue
                _seen_deletes.add(_key)
                delete_sidecar(_b, _rid, logger=logger)
    except Exception as exc:
        import traceback
        # 2026-06-22 -- use the COMMON failure-handling helper from
        # StandaloneRunLifecycle.  Same code path as file_standalone +
        # oracle / s3_query / sap_odata (via __aexit__).
        from standalone_lifecycle import StandaloneRunLifecycle
        StandaloneRunLifecycle.handle_run_failure(
            run_report=run_report,
            exc=exc,
            traceback_text=traceback.format_exc(),
            logger=logger,
            log_file=log_file,
            artifacts=artifacts,
        )
        exit_code = 1
    finally:
        # Shared finalize helper -- writes report + sends finish email.
        from standalone_lifecycle import StandaloneRunLifecycle
        StandaloneRunLifecycle.finalise_run_report(
            run_report, email_cfg, logger,
        )
        # 2026-06-26 -- Spark teardown lifted from per-step finally blocks
        # to here.  See spark_lifecycle.py header.
        from spark_lifecycle import stop_active_spark_session
        stop_active_spark_session(logger)

    if exit_code:
        raise SystemExit(exit_code)


if __name__ == "__main__":
    asyncio.run(main())
