"""Per-workflow package pre-flight check.

2026-06-21 -- operator feedback: ImportError mid-run is a confusing
way to discover that a package is missing.  Each standalone now checks
its required + optional packages at startup and either:

  * REQUIRED missing  -> fail fast with the exact ``pip install ...``
                         command + a one-line explanation per package
  * OPTIONAL missing  -> log INFO with what feature degrades
  * --auto-install    -> opt-in pip install at runtime (dev convenience;
                         prod images should bake them in)

Strategic shape: per-workflow REQUIREMENTS dict lives in ONE place
(this module).  Standalones call ``preflight_check(workflow_name,
auto_install=...)`` at startup; never have to repeat the package list.
"""
from __future__ import annotations

import importlib
import logging
import os
import subprocess
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────
#  Per-workflow package requirements
#
#  REQUIRED  = hard dependency; standalone won't function without it
#  OPTIONAL  = degrades a specific feature when missing (logged INFO)
#
#  Each entry: (import_name, pip_name, one-line description)
#  ``import_name`` is what Python `import` looks for; ``pip_name`` is
#  what `pip install` uses (often the same, but e.g. ``yaml`` vs
#  ``pyyaml``).
# ──────────────────────────────────────────────────────────────────────


PackageSpec = Tuple[str, str, str]  # (import_name, pip_name, description)


_BASE_REQUIRED: List[PackageSpec] = [
    ("oracledb", "oracledb", "Oracle DSN client -- metadata polling + task state"),
    ("yaml", "pyyaml", "YAML config loader (oracle_config.yaml + polling-query-defs)"),
    ("pandas", "pandas", "DataFrame conversions for polling-query results"),
]

_BASE_OPTIONAL: List[PackageSpec] = [
    ("psutil", "psutil",
     "AutoPlan memory-aware concurrency sizing (falls back to cpu-only when missing)"),
    # 2026-06-22 -- Fernet encryption for the qs_credentials disk cache.
    # When ETL_USE_VAULT=1 on the pod, vault-resolved secrets are cached
    # at /tmp/.etl_secrets.enc encrypted with Fernet.  Without this
    # package, disk cache falls back to plaintext ONLY when operator
    # sets ETL_SECRETS_ALLOW_PLAINTEXT=1 -- otherwise disk cache is
    # disabled + every process restart re-hits vault.
    ("cryptography", "cryptography",
     "Fernet encryption for the persistent secret-resolver disk cache.  "
     "Needed when ETL_USE_VAULT=1 is set; without it, cache is either "
     "plaintext (with explicit opt-in) or disabled entirely."),
]

# 2026-06-26 -- sqlglot moved out of _BASE_OPTIONAL.  Originally added
# there for "auto-install everywhere convenience", but oracle /
# file_to_oracle / sap_odata workflows have ZERO sqlglot imports in
# their step modules.  Forcing them to install + import an unused
# 16-MB AST library on startup is wasted bootstrap time.  The
# workflows that ACTUALLY use sqlglot (file -- partition pushdown +
# generate_sql + 30+ uses in starburst_file_base; s3_query /
# s3_to_file / s3_to_oracle -- via s3_query_base + iceberg_file_pruner)
# add it to their own optional lists below.
_SQLGLOT_SPEC: PackageSpec = (
    "sqlglot", "sqlglot",
    "AST-mode SQL rewrites: ProbeQuery, partition pushdown, cross-engine "
    "{SOURCE}.  Without it, file / s3_query workflows fall back to "
    "OOM-unsafe legacy wraps (full-query subselect) -- STRONGLY "
    "recommended for those workflows.",
)

# Per-workflow overlays: workflow-specific required + optional packages.
WORKFLOW_REQUIREMENTS: Dict[str, Dict[str, List[PackageSpec]]] = {
    "file": {
        # workflow A: Starburst -> File
        "required": _BASE_REQUIRED + [
            ("trino", "trino",
             "Trino/Starburst DBAPI client -- source query execution"),
        ],
        "optional": _BASE_OPTIONAL + [
            _SQLGLOT_SPEC,    # partition pushdown + generate_sql AST rewrites
            ("boto3", "boto3",
             "AWS SDK -- only needed when output target is S3 (rare for "
             "file workflow); IAM/IRSA credential resolution"),
        ],
    },
    "oracle": {
        # workflow B: Starburst -> Oracle
        "required": _BASE_REQUIRED + [
            ("trino", "trino", "Trino/Starburst DBAPI client -- source"),
        ],
        "optional": _BASE_OPTIONAL,
    },
    "file_to_oracle": {
        # workflow C: File -> Oracle
        "required": _BASE_REQUIRED,
        "optional": _BASE_OPTIONAL,
    },
    "s3_query": {
        # DEPRECATED 2026-06-22: legacy alias.  Use s3_to_file or s3_to_oracle.
        "required": _BASE_REQUIRED + [
            ("pyspark", "pyspark",
             "Spark SQL engine -- iceberg / parquet reader + writer"),
        ],
        "optional": _BASE_OPTIONAL + [
            _SQLGLOT_SPEC,    # s3_query_base + iceberg_file_pruner AST work
            ("boto3", "boto3",
             "AWS SDK -- IAM/IRSA credential resolution + bucket ops"),
            ("pyarrow", "pyarrow",
             "Faster parquet I/O when Spark falls back to pyarrow"),
            ("pyiceberg", "pyiceberg",
             "Supplement-pruning path -- optional bypass of Spark+Iceberg "
             "reader for file-level pruning"),
        ],
    },
    "s3_to_file": {
        # workflow D1: S3 (parquet/iceberg) -> NFS file via Spark.
        "required": _BASE_REQUIRED + [
            ("pyspark", "pyspark",
             "Spark SQL engine -- iceberg / parquet reader + writer"),
        ],
        "optional": _BASE_OPTIONAL + [
            _SQLGLOT_SPEC,    # s3_query_base + iceberg_file_pruner AST work
            ("boto3", "boto3",
             "AWS SDK -- IAM/IRSA credential resolution + bucket ops"),
            ("pyarrow", "pyarrow",
             "Faster parquet I/O when Spark falls back to pyarrow"),
            ("pyiceberg", "pyiceberg",
             "Supplement-pruning path -- file-level pruning bypass for "
             "iceberg reads"),
        ],
    },
    "s3_to_oracle": {
        # workflow D2: S3 (parquet/iceberg) -> Oracle via Spark JDBC.
        "required": _BASE_REQUIRED + [
            ("pyspark", "pyspark",
             "Spark SQL engine -- iceberg / parquet reader"),
        ],
        "optional": _BASE_OPTIONAL + [
            _SQLGLOT_SPEC,    # s3_query_base + iceberg_file_pruner AST work
            ("boto3", "boto3",
             "AWS SDK -- IAM/IRSA credential resolution + bucket ops"),
            ("pyarrow", "pyarrow",
             "Faster parquet I/O when Spark falls back to pyarrow"),
            ("pyiceberg", "pyiceberg",
             "Supplement-pruning path -- file-level pruning bypass for "
             "iceberg reads"),
        ],
    },
    "sap_odata": {
        # workflow E: SAP OData -> file (HTTP)
        "required": _BASE_REQUIRED + [
            ("requests", "requests",
             "HTTP client -- SAP OData paged fetch"),
        ],
        "optional": _BASE_OPTIONAL,
    },
}


# ──────────────────────────────────────────────────────────────────────
#  Result + report
# ──────────────────────────────────────────────────────────────────────


@dataclass
class PreflightResult:
    workflow: str
    installed_required: List[str]
    missing_required: List[PackageSpec]
    installed_optional: List[str]
    missing_optional: List[PackageSpec]

    @property
    def ok(self) -> bool:
        return not self.missing_required

    def required_pip_command(self) -> str:
        if not self.missing_required:
            return ""
        pip_names = " ".join(spec[1] for spec in self.missing_required)
        return f"pip install {pip_names}"

    def optional_pip_command(self) -> str:
        if not self.missing_optional:
            return ""
        pip_names = " ".join(spec[1] for spec in self.missing_optional)
        return f"pip install {pip_names}"


def _try_import(name: str) -> bool:
    try:
        importlib.import_module(name)
        return True
    except ImportError:
        return False
    except Exception:
        # Module imports but raises -- treat as available (it's not a
        # missing-package situation; downstream will surface the real
        # error).
        return True


def check(workflow: str, log: Optional[logging.Logger] = None) -> PreflightResult:
    """Run the import check for a workflow without installing anything."""
    log = log or logger
    spec = WORKFLOW_REQUIREMENTS.get(workflow)
    if spec is None:
        log.warning(
            "preflight: unknown workflow %r -- no package check performed. "
            "Known workflows: %s",
            workflow, sorted(WORKFLOW_REQUIREMENTS.keys()),
        )
        return PreflightResult(workflow, [], [], [], [])

    inst_req: List[str] = []
    miss_req: List[PackageSpec] = []
    for s in spec["required"]:
        (inst_req if _try_import(s[0]) else miss_req).append(s if False else s[0])
    # The trick above just appends the import_name to one list or the spec to the other.
    # Re-do cleanly:
    inst_req = []
    miss_req = []
    for s in spec["required"]:
        if _try_import(s[0]):
            inst_req.append(s[0])
        else:
            miss_req.append(s)
    inst_opt: List[str] = []
    miss_opt: List[PackageSpec] = []
    for s in spec["optional"]:
        if _try_import(s[0]):
            inst_opt.append(s[0])
        else:
            miss_opt.append(s)
    return PreflightResult(
        workflow=workflow,
        installed_required=inst_req,
        missing_required=miss_req,
        installed_optional=inst_opt,
        missing_optional=miss_opt,
    )


def report(result: PreflightResult, log: Optional[logging.Logger] = None) -> None:
    """Pretty-log the result.  Required missing -> ERROR; optional
    missing -> INFO with degradation note."""
    log = log or logger
    log.info(
        "Preflight (%s): %d required installed, %d optional installed.",
        result.workflow,
        len(result.installed_required), len(result.installed_optional),
    )
    if result.missing_required:
        log.error(
            "Preflight FAILED for workflow '%s' -- %d REQUIRED package(s) missing:\n%s\n"
            "Install them with:\n  %s",
            result.workflow, len(result.missing_required),
            "\n".join(
                f"  * {imp_name} (pip: {pip_name}) -- {desc}"
                for imp_name, pip_name, desc in result.missing_required
            ),
            result.required_pip_command(),
        )
    if result.missing_optional:
        log.info(
            "Preflight: workflow '%s' has %d optional package(s) missing -- "
            "specific features will degrade:\n%s\n"
            "Install them with (optional):\n  %s",
            result.workflow, len(result.missing_optional),
            "\n".join(
                f"  * {imp_name} (pip: {pip_name}) -- {desc}"
                for imp_name, pip_name, desc in result.missing_optional
            ),
            result.optional_pip_command(),
        )


def _run_ensurepip(log: logging.Logger, timeout_seconds: int = 60) -> bool:
    """Run ``python -m ensurepip`` to bootstrap pip in environments
    where it might not be available OR where pip's install path needs
    re-derivation (some OpenShift pods need this).

    2026-06-22 -- user-validated pattern: their successful workaround
    ran ensurepip BEFORE every install, not just when pip was missing.
    Following that pattern verbatim.

    Returns True on success, False on failure (we still try the
    install regardless -- ensurepip failing doesn't always mean pip
    is broken)."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "ensurepip"],
            capture_output=True, text=True, timeout=timeout_seconds,
        )
        if result.returncode == 0:
            log.info("ensurepip OK")
            return True
        log.warning(
            "ensurepip exit=%d -- continuing to pip install anyway.\n"
            "STDOUT: %s\nSTDERR: %s",
            result.returncode,
            (result.stdout or "")[-500:], (result.stderr or "")[-500:],
        )
        return False
    except FileNotFoundError:
        log.warning("ensurepip module not available -- skipping bootstrap")
        return False
    except subprocess.TimeoutExpired:
        log.warning("ensurepip timed out -- continuing to pip install")
        return False
    except Exception as exc:
        log.warning("ensurepip raised %s: %s -- continuing", type(exc).__name__, exc)
        return False


def install_missing(
    specs: List[PackageSpec],
    log: Optional[logging.Logger] = None,
    timeout_seconds: int = 300,
) -> bool:
    """Install missing packages via `pip install`.

    2026-06-22 -- user-validated minimal pattern.  Mirrors operator's
    working OpenShift workaround:

        subprocess.check_call([python, '-m', 'ensurepip'])
        subprocess.check_call([python, '-m', 'pip', 'install', <pkg>])

    Plain pip install (no --user, no --target, no detection logic).
    The fancy fallback chain I tried first added flags that BROKE
    the install on the user's OpenShift pod -- their simple pattern
    is what actually worked.  Strategic fix (proper Dockerfile bake)
    deferred to later.

    Applies to ALL packages in `specs` in one batched pip call.
    Returns True on success, False on failure.  Never raises.
    """
    log = log or logger
    if not specs:
        return True
    pip_names = [s[1] for s in specs]
    log.warning(
        "Auto-installing %d package(s) via pip (DEV convenience -- "
        "prod images should pre-bake): %s",
        len(specs), pip_names,
    )

    # Log corp-nexus settings so operators can confirm pip picks them up.
    if os.environ.get("PIP_INDEX_URL"):
        log.info("Using PIP_INDEX_URL=%s", os.environ["PIP_INDEX_URL"])
    if os.environ.get("PIP_EXTRA_INDEX_URL"):
        log.info("Using PIP_EXTRA_INDEX_URL=%s", os.environ["PIP_EXTRA_INDEX_URL"])

    # Step 1: ensurepip (matches user's pattern -- runs ALWAYS, even
    # when pip is already present.  ensurepip re-derives pip's install
    # path which can resolve some OpenShift permission issues).  We
    # WARN on failure but continue -- the install might still work.
    _run_ensurepip(log)

    # Step 2: plain pip install -- no --user, no --target.  Let pip
    # figure out the right install path.
    cmd = [sys.executable, "-m", "pip", "install"]
    # --no-cache-dir prevents the '/.cache/pip not writable' warning
    # seen in user's OpenShift logs.  This is a UX win, not behavioural.
    cmd.append("--no-cache-dir")
    cmd.extend(pip_names)
    log.info("Running: %s", " ".join(cmd))

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout_seconds,
        )
        if result.returncode != 0:
            stderr_tail = (result.stderr or "")[-2000:]
            log.error(
                "pip install failed (exit=%d):\nSTDOUT:\n%s\nSTDERR:\n%s",
                result.returncode, (result.stdout or "")[-1000:], stderr_tail,
            )
            return False
        log.info("pip install OK -- %d package(s) installed.", len(specs))
        return True
    except FileNotFoundError:
        log.error(
            "pip executable not found.  Pre-bake packages into the "
            "container image OR install pip manually."
        )
        return False
    except subprocess.TimeoutExpired:
        log.error(
            "pip install timed out after %ds.  Check network OR pre-bake.",
            timeout_seconds,
        )
        return False
    except Exception as exc:
        log.error("pip install raised %s: %s", type(exc).__name__, exc)
        return False


def preflight_check(
    workflow: str,
    auto_install: bool = True,
    install_optional: bool = True,
    fail_on_missing_required: bool = True,
    log: Optional[logging.Logger] = None,
) -> PreflightResult:
    """Top-level: check, report, install (if any missing), optionally raise.

    2026-06-21 -- DEFAULT-ON auto-install based on operator feedback:
    these workflows run in TWO modes:
      1. Polling-service container (helm-managed) -- image pre-bakes deps
      2. Airflow SparkSubmit driver pod -- generic Spark image, may
         be MISSING workflow-specific deps (trino, oracledb, etc.)

    In mode 2, the SparkSubmit driver pod runs the standalone script
    directly without the QS helm image's pre-bake.  Auto-installing
    on first run gets the operator unblocked instead of "ImportError
    for trino" 10 minutes into a run.

    In mode 1, packages are already installed -- auto-install becomes
    a fast no-op (check passes, install_missing called with empty
    list).  Zero overhead.

    If pip install itself fails (no internet, pypi mirror down,
    read-only site-packages), we still hard-fail with the clear pip
    install command in the error -- operator can bake into image OR
    fix network.

    Operator surface:
      * Default: check + auto-install missing required + optional;
        raise SystemExit(1) if any required STILL missing after install
      * --no-auto-install: skip pip install (CI sanity check / strict mode)
      * --no-install-optional: skip optional installs only (keep heavier
        deps off when not needed)
      * fail_on_missing_required=False: skip SystemExit (tests)
    """
    log = log or logger
    result = check(workflow, log=log)
    report(result, log=log)

    if result.missing_required and auto_install:
        if install_missing(result.missing_required, log=log):
            # Re-check after install -- in case pip succeeded but the
            # package still doesn't import (edge case: different env).
            result = check(workflow, log=log)
            report(result, log=log)

    if result.missing_optional and install_optional:
        if install_missing(result.missing_optional, log=log):
            result = check(workflow, log=log)
            report(result, log=log)

    if result.missing_required and fail_on_missing_required:
        log.error(
            "Preflight: cannot start workflow '%s' without REQUIRED "
            "packages.  Install them (above command), then re-run.",
            workflow,
        )
        raise SystemExit(1)

    return result
