"""
Oracle database library using oracledb (python-oracledb).
Implements DatabaseInterface ABC: execute_procedure, execute_query,
bulk_copy, execute_transaction, fetch_procedure_data.
Plus utility methods: load_csv_to_oracle, load_parquet_to_oracle,
release_connection, fetch_dag_configs, fetch_dag_template_configs,
get_procedure_params.
"""
import csv
import json
import logging
import os
from abc import ABC, abstractmethod
from contextlib import contextmanager
from datetime import datetime
from typing import List, Optional, Dict, Any, Callable, Tuple

import oracledb
import pandas as pd
# 2026-07-01 -- pydantic v2 migration.
# * ``validator`` -> ``field_validator`` (v2 rename, requires
#   @classmethod stack) OR ``model_validator(mode='after')`` when the
#   check needs cross-field access (v2 field_validators only see
#   fields validated BEFORE them in declaration order).
# * ``BaseSettings`` moved out of core pydantic into the separate
#   ``pydantic-settings`` package.
# * ``class Config`` inside a settings class -> ``model_config =
#   SettingsConfigDict(...)``.
# Back-compat: pydantic v1 environments no longer supported; pin v1
# in requirements.txt if you must stay on v1.
try:
    from pydantic import BaseModel, ValidationError, field_validator, model_validator
    from pydantic_settings import BaseSettings, SettingsConfigDict
except ImportError as _pyd_exc:
    # 2026-07-01 hygiene -- upgrade the opaque pydantic ImportError
    # into an actionable message operators can act on immediately.
    # Previously the pod-start crash pointed at
    # ``from pydantic_settings import ...`` with no explanation.
    raise ImportError(
        f"pydantic v2 + pydantic-settings + tenacity are REQUIRED by "
        f"managers.oracledblib.  Original error: "
        f"{type(_pyd_exc).__name__}: {_pyd_exc}\n"
        f"Fix:\n"
        f"  pip install 'pydantic==2.5.0' 'pydantic-settings==2.1.0' "
        f"'tenacity==8.2.3'\n"
        f"Or rebuild the Docker image so requirements.txt takes effect."
    ) from _pyd_exc
from tenacity import retry, stop_after_attempt, wait_exponential

# 2026-07-01 hotfix-2 -- do NOT call ``logging.basicConfig`` at
# module import.  That mutates the ROOT logger unconditionally,
# which stomps on the polling service's carefully-configured
# JSON handler + QueueHandler wrapper from ``log_setup.py`` when
# ``oracledblib`` is imported before ``setup_logging`` runs (any
# test that touches this file first, plus any tool that imports
# the manager standalone).  Callers should configure their own
# handlers; this module only creates a NAMED logger.
logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════
#  ABC + Pydantic models
# ═══════════════════════════════════════════════════════════════════════

class DatabaseInterface(ABC):
    """Abstract base class defining the database operations interface."""

    @abstractmethod
    def execute_procedure(self, procedure_name: str, parameters: Optional[List[Dict]],
                          connection_string: Optional[str] = None) -> Dict:
        pass

    @abstractmethod
    def bulk_copy(self, table_name: str, data: pd.DataFrame,
                  batch_size: Optional[int] = None,
                  connection_string: Optional[str] = None) -> Dict:
        pass

    @abstractmethod
    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None,
                      connection_string: Optional[str] = None) -> pd.DataFrame:
        pass

    @abstractmethod
    def execute_transaction(self, statements: List[Tuple[str, Optional[Dict[str, Any]]]],
                            connection_string: Optional[str] = None) -> Dict:
        pass

    @abstractmethod
    def fetch_procedure_data(self, procedure_name: str, parameters: Optional[List[Dict]],
                             connection_string: Optional[str] = None) -> pd.DataFrame:
        pass


class Parameter(BaseModel):
    """Pydantic model for stored procedure parameters."""
    name: str
    value: Any
    direction: str
    type_hint: Optional[str] = None

    @field_validator('direction')
    @classmethod
    def validate_direction(cls, v):
        if v not in ('IN', 'OUT', 'IN OUT'):
            raise ValueError("Direction must be 'IN', 'OUT', or 'IN OUT'")
        return v

    @field_validator('type_hint')
    @classmethod
    def validate_type_hint(cls, v):
        if v and v.upper() not in OracleDBLib.TYPE_MAPPING:
            raise ValueError(f"Invalid type hint: {v}. Must be one of {list(OracleDBLib.TYPE_MAPPING.keys())}")
        return v.upper() if v else v

    # 2026-07-01 -- was a v1 ``@validator('value')`` reading ``values``
    # dict for cross-field access.  In pydantic v2 ``field_validator``
    # only sees fields validated BEFORE this one in declaration order
    # (``value`` is field #2, ``type_hint`` is field #4 -> not yet
    # available).  Switched to ``model_validator(mode='after')`` which
    # runs once every field is bound on the built instance.
    @model_validator(mode='after')
    def validate_json_value(self):
        if self.type_hint == 'JSON' and self.value is not None:
            if not isinstance(self.value, (dict, list)):
                raise ValueError("JSON type hint requires dict or list value")
            json.dumps(self.value)
        return self


class OracleConfig(BaseSettings):
    """Pydantic model for Oracle configuration."""
    pool_min: int = 1
    pool_max: int = 10
    batch_size: int = 1000
    retry_attempts: int = 3
    oracle_user: Optional[str] = None
    oracle_password: Optional[str] = None
    oracle_dsn: Optional[str] = None

    # 2026-07-01 -- pydantic v2 replaces ``class Config`` with
    # ``model_config = ConfigDict(...)``.  For settings classes
    # (BaseSettings) use ``SettingsConfigDict``.  Same keys work
    # (env_prefix, case_sensitive).
    model_config = SettingsConfigDict(
        env_prefix='ORACLE_',
        case_sensitive=False,
    )


# ═══════════════════════════════════════════════════════════════════════
#  OracleDBLib — concrete implementation
# ═══════════════════════════════════════════════════════════════════════

class OracleDBLib(DatabaseInterface):

    # 2026-07-01 -- resilient to oracledb version drift.  The RAW /
    # BINARY names have flipped across oracledb releases (2.0.x had
    # RAW; 4.0+ dropped it in favour of BINARY).  Use getattr with
    # a sensible fallback so this dict builds cleanly on both.  Type
    # constants that don't exist ANYWHERE fall through to STRING
    # (safe for bind hints).  A missing name is logged once at
    # import time so operators see version drift explicitly.
    _T = lambda *names: next(
        (getattr(oracledb, n) for n in names if hasattr(oracledb, n)),
        oracledb.STRING,
    )

    TYPE_MAPPING = {
        'NUMBER':        _T('NUMBER'),
        'VARCHAR2':      _T('STRING'),
        'CHAR':          _T('STRING'),
        'CLOB':          _T('CLOB'),
        'NCLOB':         _T('NCLOB'),
        'BLOB':          _T('BLOB'),
        'RAW':           _T('RAW', 'BINARY'),          # RAW in <=2.x, BINARY in 4.x+
        'DATE':          _T('DATETIME', 'DATE'),
        'TIMESTAMP':     _T('TIMESTAMP'),
        'BINARY_DOUBLE': _T('BINARY_DOUBLE', 'DB_TYPE_BINARY_DOUBLE'),
        'BINARY_FLOAT':  _T('BINARY_FLOAT', 'DB_TYPE_BINARY_FLOAT'),
        'INTERVAL_DS':   _T('INTERVAL_DS', 'DB_TYPE_INTERVAL_DS'),
        'INTERVAL_YM':   _T('INTERVAL_YM', 'DB_TYPE_INTERVAL_YM'),
        'JSON':          _T('JSON', 'DB_TYPE_JSON'),
        'XMLTYPE':       _T('CLOB'),
        'CURSOR':        _T('CURSOR', 'DB_TYPE_CURSOR'),
        'BOOLEAN':       _T('NUMBER'),
    }
    del _T   # class-scope helper, not part of the public API

    PYTHON_TO_ORACLE = {
        int: 'NUMBER',
        float: 'NUMBER',
        str: 'VARCHAR2',
        bytes: 'BLOB',
        bool: 'BOOLEAN',
        datetime: 'DATE',
        dict: 'JSON',
        list: 'JSON',
        None: 'VARCHAR2',
    }

    def __init__(
        self,
        connection_string: Optional[str] = None,
        logger: logging.Logger = logger,
        pool_factory: Callable = oracledb.create_pool,
        config: Optional[OracleConfig] = None,
    ):
        self.logger = logger
        self.pool_factory = pool_factory
        self.config = config or OracleConfig()
        self.default_connection_string = self._resolve_connection_string(connection_string)

        # 2026-07-01 item #30 -- secondary pool cache.  Previously
        # every ``_get_connection(connection_string=...)`` call built a
        # fresh (min=1, max=1) pool and closed it.  In the SAP
        # dispatcher path, each poll iteration threads a task-specific
        # ``dest_connection_string`` through several manager methods,
        # so ONE poll could open + close 4-5 short-lived pools.  Under
        # load this manifested as "Oracle session count sawtooth" —
        # sessions surging above pool_max because Oracle sees each pool
        # as a distinct session bucket.  Cache secondary pools by
        # (user, dsn) with a bounded LRU so identical overrides
        # reuse a pool across calls.
        import threading as _threading
        self._secondary_pools: "Dict[Tuple[str, str], Any]" = {}
        self._secondary_pools_lock = _threading.Lock()
        # Bound the cache so a runaway caller passing many distinct
        # dsns doesn't leak pool objects.  16 covers the realistic
        # ETL fan-out (default + dest + ~4-6 workflow-specific
        # overrides) with headroom.
        self._secondary_pools_max = 16

        # 2026-07-01 fix (item #10) -- pool creation retry.  Was a
        # single try/except that re-raised on any oracledb.Error, so
        # if Oracle happened to be unreachable at pod start
        # (K8s Oracle sidecar not-yet-ready during a rolling upgrade)
        # the polling service died at __init__ and K8s
        # CrashLoopBackoff'd forever.  Now retries up to
        # ``config.retry_attempts`` (default 3) with tenacity's
        # exponential backoff so a transient Oracle blip during pod
        # start doesn't wedge the deployment.  The final retry re-
        # raises so K8s CrashLoop still fires on genuine misconfig
        # (bad DSN, wrong creds).
        _pool_kwargs = dict(
            user=self.default_connection_string['user'],
            password=self.default_connection_string['password'],
            dsn=self.default_connection_string['dsn'],
            min=self.config.pool_min,
            max=self.config.pool_max,
            increment=1,
        )
        _attempts = max(1, int(self.config.retry_attempts or 3))
        for _attempt_no in range(1, _attempts + 1):
            try:
                self.pool = self.pool_factory(**_pool_kwargs)
                if _attempt_no > 1:
                    self.logger.info(
                        f"Default connection pool created successfully "
                        f"on attempt {_attempt_no}/{_attempts}"
                    )
                else:
                    self.logger.info("Default connection pool created successfully")
                break
            except oracledb.Error as e:
                if _attempt_no >= _attempts:
                    self.logger.error(
                        f"Failed to create default connection pool "
                        f"after {_attempts} attempts: {e}"
                    )
                    raise
                _backoff_s = min(30.0, 2.0 ** (_attempt_no - 1))
                self.logger.warning(
                    f"Pool creation attempt {_attempt_no}/{_attempts} "
                    f"failed: {e} — sleeping {_backoff_s:.1f}s + retrying"
                )
                import time as _time
                _time.sleep(_backoff_s)

    # ── Connection helpers ──────────────────────────────────────────────

    def _resolve_connection_string(self, connection_string: Optional[str]) -> Dict[str, str]:
        """Resolve connection string from input or config.

        Accepts BOTH formats via the shared parser in
        ``oracle_config_loader.parse_oracle_connection_string``:
          1. Easy Connect: ``user/password@host:port/service``
          2. OLEDB:        ``(DESCRIPTION=...); User Id = u; Password = p``

        ETL prod deployments use OLEDB.  See the loader for full
        format docs.
        """
        if connection_string:
            # Lazy import to avoid a hard cyclic dep at module-load.
            try:
                from oracle_config_loader import parse_oracle_connection_string
            except ImportError:
                parse_oracle_connection_string = None

            if parse_oracle_connection_string is not None:
                parsed = parse_oracle_connection_string(connection_string)
                if parsed["user"] and parsed["dsn"]:
                    return parsed
            # Fallback to the legacy Easy-Connect-only split if the
            # shared parser couldn't extract a user + dsn.
            try:
                user, rest = connection_string.split('/', 1)
                password, dsn = rest.split('@', 1)
                return {'user': user, 'password': password, 'dsn': dsn}
            except ValueError:
                raise ValueError(
                    "Invalid Oracle connection string.  Accepted formats:\n"
                    "  Easy Connect: user/password@host:port/service\n"
                    "  OLEDB:        (DESCRIPTION=...); User Id = u; Password = p;"
                )

        if self.config.oracle_user and self.config.oracle_password and self.config.oracle_dsn:
            return {
                'user': self.config.oracle_user,
                'password': self.config.oracle_password,
                'dsn': self.config.oracle_dsn,
            }

        raise ValueError("No valid connection string provided")

    def _get_or_create_secondary_pool(self, conn_details: Dict[str, str]):
        """2026-07-01 item #30 -- return a cached secondary pool for the
        given (user, dsn) triple, creating one lazily.  Bounded to
        ``_secondary_pools_max`` entries; oldest entry is evicted and
        closed on overflow.

        Thread-safe via ``_secondary_pools_lock``.  Pool creation
        happens INSIDE the lock only when the key is missing — the
        common cache-hit path is a plain dict lookup.
        """
        key = (conn_details['user'], conn_details['dsn'])
        with self._secondary_pools_lock:
            pool = self._secondary_pools.get(key)
            if pool is not None:
                return pool
            # Miss: create + insert under the lock so we don't get
            # duplicate pools for the same key racing at start.
            new_pool = self.pool_factory(
                user=conn_details['user'],
                password=conn_details['password'],
                dsn=conn_details['dsn'],
                min=1,
                max=max(1, min(self.config.pool_max, 4)),
                increment=1,
            )
            if len(self._secondary_pools) >= self._secondary_pools_max:
                # Bounded LRU: evict FIRST inserted key (insertion
                # order is preserved by Python dicts >=3.7).
                try:
                    old_key, old_pool = next(iter(self._secondary_pools.items()))
                    self._secondary_pools.pop(old_key, None)
                    try:
                        old_pool.close(force=True)
                    except Exception as _close_exc:
                        self.logger.warning(
                            f"Failed to close evicted secondary pool "
                            f"{old_key[0]}@{old_key[1]}: {_close_exc}"
                        )
                except StopIteration:                                # pragma: no cover
                    pass
            self._secondary_pools[key] = new_pool
            return new_pool

    def close_secondary_pools(self) -> None:
        """Explicit teardown for the secondary pool cache.  Called by
        the polling service shutdown path (best-effort — Oracle
        auto-releases on session-end so a missing call doesn't leak
        forever, but explicit close returns sessions promptly)."""
        with self._secondary_pools_lock:
            for key, pool in list(self._secondary_pools.items()):
                try:
                    pool.close(force=True)
                except Exception as _exc:
                    self.logger.warning(
                        f"Failed to close secondary pool {key[0]}@{key[1]}: {_exc}"
                    )
            self._secondary_pools.clear()

    @contextmanager
    def _get_connection(self, connection_string: Optional[str] = None):
        """Context manager for connection, supporting per-method connection strings.

        2026-07-01 item #30 -- secondary connection strings now go
        through a CACHED pool (see ``_get_or_create_secondary_pool``)
        instead of building a fresh min=1/max=1 pool per call.  This
        eliminates the "session sawtooth" observed under load where
        each poll iteration opened + closed 4-5 short-lived pools.
        """
        connection = None
        pool_used = None
        try:
            if connection_string:
                conn_details = self._resolve_connection_string(connection_string)
                pool_used = self._get_or_create_secondary_pool(conn_details)
            else:
                pool_used = self.pool
            connection = pool_used.acquire()
            # 2026-07-01 hotfix-2 -- set ``call_timeout`` on the
            # acquired connection so a hung Oracle round-trip actually
            # gets cancelled by the driver instead of dangling in the
            # background after the outer ``asyncio.wait_for`` timeout
            # fires (Python threads can't be externally cancelled).
            # Default: match the outer wait_for cap so an outer 300s
            # timeout is never delayed by an inner 3-day silence.
            try:
                # milliseconds; None / 0 == no timeout.
                _call_timeout_ms = int(
                    getattr(self.config, "call_timeout_seconds", 300) * 1000
                )
                if _call_timeout_ms > 0 and hasattr(connection, "call_timeout"):
                    connection.call_timeout = _call_timeout_ms
            except Exception as _to_exc:                             # pragma: no cover
                self.logger.debug(
                    "Could not set connection.call_timeout: %s", _to_exc
                )
            yield connection
        except oracledb.Error as e:
            self.logger.error(f"Failed to acquire connection: {str(e)}")
            raise
        finally:
            if connection is not None and pool_used is not None:
                try:
                    pool_used.release(connection)
                except Exception as release_err:
                    self.logger.warning(f"Error releasing connection: {release_err}")

    def release_connection(self, connection, connection_string: Optional[str] = None):
        """Release a connection back to the pool (for manual management)."""
        try:
            self.pool.release(connection)
        except Exception as e:
            self.logger.warning(f"Error releasing connection: {e}")

    # ── Validation helpers ──────────────────────────────────────────────

    def _validate_name(self, name: str) -> None:
        """Validate table or procedure name."""
        import re
        if not re.match(r'^[A-Za-z0-9_.]+$', name):
            raise ValueError(f"Invalid name format: {name}")

    def _get_parameter_type(self, value: Any, type_hint: Optional[str],
                            metadata_type: Optional[str]) -> Any:
        """Determine Oracle parameter type."""
        if type_hint and type_hint.upper() in self.TYPE_MAPPING:
            return self.TYPE_MAPPING[type_hint.upper()]
        if metadata_type and metadata_type.upper() in self.TYPE_MAPPING:
            return self.TYPE_MAPPING[metadata_type.upper()]
        return self.TYPE_MAPPING.get(
            self.PYTHON_TO_ORACLE.get(type(value), 'VARCHAR2')
        )

    def _fetch_procedure_metadata(self, procedure_name: str,
                                  connection_string: Optional[str] = None) -> Dict[str, Dict]:
        """Fetch parameter metadata from ALL_ARGUMENTS."""
        try:
            with self._get_connection(connection_string) as connection:
                cursor = connection.cursor()
                try:
                    parts = procedure_name.split('.')
                    if len(parts) == 2:
                        owner, proc_name = parts
                        query = """
                            SELECT ARGUMENT_NAME, DATA_TYPE, IN_OUT
                            FROM ALL_ARGUMENTS
                            WHERE OBJECT_NAME = :proc_name
                            AND PACKAGE_NAME IS NULL
                            AND OWNER = :owner
                            ORDER BY POSITION
                        """
                        cursor.execute(query, {'proc_name': proc_name, 'owner': owner})
                    elif len(parts) == 3:
                        # PKG_NAME.PROC_NAME format
                        owner_or_pkg, pkg_or_proc, proc_name = parts[0], parts[1], parts[2]
                        query = """
                            SELECT ARGUMENT_NAME, DATA_TYPE, IN_OUT
                            FROM ALL_ARGUMENTS
                            WHERE OBJECT_NAME = :proc_name
                            AND PACKAGE_NAME = :pkg_name
                            ORDER BY POSITION
                        """
                        cursor.execute(query, {'proc_name': proc_name, 'pkg_name': pkg_or_proc})
                    else:
                        return {}

                    metadata = {}
                    for row in cursor.fetchall():
                        param_name, data_type, in_out = row
                        if param_name:
                            metadata[param_name] = {'type': data_type, 'direction': in_out}
                    return metadata
                finally:
                    cursor.close()
        except oracledb.Error as e:
            self.logger.warning(f"Failed to fetch metadata for {procedure_name}: {str(e)}")
            return {}

    # ═══════════════════════════════════════════════════════════════════
    #  ABC implementations
    # ═══════════════════════════════════════════════════════════════════

    def execute_procedure(self, procedure_name: str, parameters: Optional[List[Dict]] = None,
                          connection_string: Optional[str] = None) -> Dict:
        """Execute an Oracle stored procedure.

        Parameters is a list of dicts:
          [{"name": "p_id", "value": 1, "direction": "IN", "type_hint": "NUMBER"}, ...]

        OUT parameters are updated in-place with their returned values.
        Returns {"status": "SUCCESS", "out_parameters": {name: value, ...}}
        """
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                # Fetch procedure metadata for type resolution
                metadata = self._fetch_procedure_metadata(procedure_name, connection_string)

                # Build cursor variables for each parameter
                call_params = {}
                out_vars = {}

                if parameters:
                    for param in parameters:
                        name = param['name']
                        value = param.get('value')
                        direction = param.get('direction', 'IN').upper()
                        type_hint = param.get('type_hint')
                        meta = metadata.get(name.upper(), {})
                        oracle_type = self._get_parameter_type(value, type_hint, meta.get('type'))

                        if direction in ('OUT', 'IN OUT'):
                            var = cursor.var(oracle_type)
                            if direction == 'IN OUT' and value is not None:
                                var.setvalue(0, value)
                            call_params[name] = var
                            out_vars[name] = var
                        else:
                            # IN parameter
                            if type_hint and type_hint.upper() == 'JSON' and isinstance(value, (dict, list)):
                                call_params[name] = json.dumps(value)
                            else:
                                call_params[name] = value

                cursor.callproc(procedure_name, keywordParameters=call_params)
                connection.commit()

                # Extract OUT values
                out_parameters = {}
                for name, var in out_vars.items():
                    out_val = var.getvalue()
                    out_parameters[name] = out_val
                    # Also update the original parameter dict in-place
                    if parameters:
                        for p in parameters:
                            if p['name'] == name:
                                p['value'] = out_val
                                break

                return {"status": "SUCCESS", "out_parameters": out_parameters}

            except oracledb.Error as e:
                connection.rollback()
                self.logger.error(f"Procedure {procedure_name} failed: {str(e)}")
                return {"status": "FAILED", "error_message": str(e)}
            finally:
                cursor.close()

    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None,
                      connection_string: Optional[str] = None) -> pd.DataFrame:
        """Execute a SQL query and return results as a pandas DataFrame."""
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                if parameters:
                    cursor.execute(query, parameters)
                else:
                    cursor.execute(query)

                if cursor.description:
                    columns = [col[0] for col in cursor.description]
                    rows = cursor.fetchall()
                    return pd.DataFrame(rows, columns=columns)
                return pd.DataFrame()

            except oracledb.Error as e:
                self.logger.error(f"Query failed: {str(e)}")
                raise
            finally:
                cursor.close()

    def bulk_copy(self, table_name: str, data: pd.DataFrame,
                  batch_size: Optional[int] = None,
                  connection_string: Optional[str] = None) -> Dict:
        """Bulk insert a DataFrame into an Oracle table.

        2026-07-01 hotfix-2 -- validate table_name AND every column
        name via ``_validate_name`` before string-interpolating into
        the INSERT SQL.  Previously a caller passing a hostile
        DataFrame with a column named ``x); DELETE FROM t; --``
        executed arbitrary SQL under the pool schema.  Fail-fast
        with ValueError so an audit test can lock the contract.
        """
        if data.empty:
            return {"status": "SUCCESS", "rows_inserted": 0}

        batch_size = batch_size or self.config.batch_size

        # SQL-injection guard: table_name + every column name must be
        # a plain identifier.  Applied BEFORE any string-interp.
        self._validate_name(table_name)
        columns = list(data.columns)
        for _col in columns:
            self._validate_name(str(_col))

        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                placeholders = ", ".join([f":{i+1}" for i in range(len(columns))])
                col_list = ", ".join(columns)
                insert_sql = f"INSERT INTO {table_name} ({col_list}) VALUES ({placeholders})"

                # Convert DataFrame to list of tuples
                rows = [tuple(row) for row in data.itertuples(index=False, name=None)]
                total_inserted = 0

                for i in range(0, len(rows), batch_size):
                    batch = rows[i:i + batch_size]
                    cursor.executemany(insert_sql, batch)
                    total_inserted += len(batch)
                    self.logger.info(
                        f"Inserted batch {i // batch_size + 1}: "
                        f"{len(batch)} rows (total: {total_inserted})"
                    )

                connection.commit()
                return {"status": "SUCCESS", "rows_inserted": total_inserted}

            except oracledb.Error as e:
                connection.rollback()
                self.logger.error(f"Bulk copy to {table_name} failed: {str(e)}")
                return {"status": "FAILED", "error_message": str(e), "rows_inserted": 0}
            finally:
                cursor.close()

    def execute_transaction(self, statements: List[Tuple[str, Optional[Dict[str, Any]]]],
                            connection_string: Optional[str] = None) -> Dict:
        """Execute multiple SQL statements in a single transaction."""
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                results = []
                for sql, params in statements:
                    if params:
                        cursor.execute(sql, params)
                    else:
                        cursor.execute(sql)
                    results.append({
                        "sql": sql[:100],
                        "rowcount": cursor.rowcount,
                    })

                connection.commit()
                return {"status": "SUCCESS", "statements": results}

            except oracledb.Error as e:
                connection.rollback()
                self.logger.error(f"Transaction failed: {str(e)}")
                return {"status": "FAILED", "error_message": str(e)}
            finally:
                cursor.close()

    def fetch_procedure_data(self, procedure_name: str, parameters: Optional[List[Dict]] = None,
                             connection_string: Optional[str] = None) -> pd.DataFrame:
        """Execute a stored procedure that returns a cursor, return as DataFrame."""
        result = self.execute_procedure(procedure_name, parameters, connection_string)

        if result["status"] != "SUCCESS":
            raise RuntimeError(
                f"Procedure {procedure_name} failed: {result.get('error_message', 'unknown')}"
            )

        # Find the cursor OUT parameter
        out_params = result.get("out_parameters", {})
        for name, value in out_params.items():
            if hasattr(value, 'fetchall') and hasattr(value, 'description'):
                columns = [col[0] for col in value.description]
                rows = value.fetchall()
                value.close()
                return pd.DataFrame(rows, columns=columns)

        return pd.DataFrame()

    # ═══════════════════════════════════════════════════════════════════
    #  Extra methods used by oracle_metadata_manager
    # ═══════════════════════════════════════════════════════════════════

    def get_procedure_params(self, procedure_name: str, p_dagid: str,
                             p_businessdate: str, procconfigid: int,
                             proctype: str, connection_string: Optional[str] = None) -> List[Dict]:
        """Fetch procedure params via stored procedure with cursor output."""
        params = [
            {"name": "p_dagid", "value": p_dagid, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "p_businessdate", "value": p_businessdate, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "p_procconfigid", "value": procconfigid, "direction": "IN", "type_hint": "NUMBER"},
            {"name": "p_proctype", "value": proctype, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "p_cursor", "value": None, "direction": "OUT", "type_hint": "CURSOR"},
        ]
        result = self.execute_procedure(procedure_name, params, connection_string)

        if result["status"] != "SUCCESS":
            raise RuntimeError(f"get_procedure_params failed: {result.get('error_message')}")

        cursor = result.get("out_parameters", {}).get("p_cursor")
        if cursor and hasattr(cursor, 'fetchall'):
            columns = [col[0] for col in cursor.description]
            rows = cursor.fetchall()
            cursor.close()
            return [dict(zip(columns, row)) for row in rows]
        return []

    def fetch_dag_configs(self, query1: str, query2: str,
                          connection_string: Optional[str] = None) -> Dict[str, Any]:
        """Fetch DAG configs from two views and merge."""
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                # Fetch main DAG configs
                cursor.execute(query1)
                columns1 = [col[0].lower() for col in cursor.description]
                rows1 = cursor.fetchall()
                configs = {}
                dag_ids = []
                for row in rows1:
                    row_dict = dict(zip(columns1, row))
                    dag_id = row_dict.get('dag_id')
                    if dag_id:
                        configs[dag_id] = row_dict
                        dag_ids.append(dag_id)

                # Fetch step configs for those DAG IDs
                if dag_ids and '{placeholders}' in query2:
                    placeholders = ", ".join([f":d{i}" for i in range(len(dag_ids))])
                    query2_resolved = query2.replace('{placeholders}', placeholders)
                    bind_vars = {f"d{i}": dag_id for i, dag_id in enumerate(dag_ids)}
                    cursor.execute(query2_resolved, bind_vars)
                    columns2 = [col[0].lower() for col in cursor.description]
                    for row in cursor.fetchall():
                        row_dict = dict(zip(columns2, row))
                        dag_id = row_dict.get('dag_id')
                        if dag_id and dag_id in configs:
                            configs[dag_id].setdefault('steps', []).append(row_dict)

                return configs
            except oracledb.Error as e:
                self.logger.error(f"fetch_dag_configs failed: {str(e)}")
                raise
            finally:
                cursor.close()

    def fetch_dag_template_configs(self, query: str,
                                   connection_string: Optional[str] = None) -> List[Dict]:
        """Fetch DAG template configs from view."""
        with self._get_connection(connection_string) as connection:
            cursor = connection.cursor()
            try:
                cursor.execute(query)
                columns = [col[0].lower() for col in cursor.description]
                rows = cursor.fetchall()
                return [dict(zip(columns, row)) for row in rows]
            except oracledb.Error as e:
                self.logger.error(f"fetch_dag_template_configs failed: {str(e)}")
                raise
            finally:
                cursor.close()

    def load_csv_to_oracle(self, table_name: str, csv_file: str,
                           dest_connection_string: Optional[str] = None,
                           schema: Optional[str] = None,
                           use_direct_path: bool = False) -> Dict:
        """Load CSV file into Oracle table using bulk insert.

        2026-07-01 hotfix-2 -- validate table_name, schema, AND every
        CSV column header before string-interpolating into the
        INSERT SQL.  Previously an attacker-authored CSV whose header
        contained ``x); DELETE FROM t; --`` executed arbitrary SQL.
        """
        # SQL-injection guard: table_name / schema.
        self._validate_name(table_name)
        if schema:
            self._validate_name(schema)
        target = f"{schema}.{table_name}" if schema else table_name

        with self._get_connection(dest_connection_string) as connection:
            cursor = connection.cursor()
            try:
                with open(csv_file, 'r', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    header = next(reader)
                    columns = [col.strip() for col in header]
                    # Guard EVERY column header derived from the file.
                    for _col in columns:
                        self._validate_name(_col)

                    placeholders = ", ".join([f":{i+1}" for i in range(len(columns))])
                    col_list = ", ".join(columns)
                    insert_sql = f"INSERT INTO {target} ({col_list}) VALUES ({placeholders})"

                    batch = []
                    total_rows = 0
                    batch_size = self.config.batch_size

                    for row in reader:
                        batch.append(tuple(row))
                        if len(batch) >= batch_size:
                            cursor.executemany(insert_sql, batch)
                            total_rows += len(batch)
                            batch = []

                    if batch:
                        cursor.executemany(insert_sql, batch)
                        total_rows += len(batch)

                connection.commit()
                self.logger.info(f"Loaded {total_rows} rows from {csv_file} into {target}")
                return {"status": "SUCCESS", "rows_inserted": total_rows}

            except Exception as e:
                connection.rollback()
                self.logger.error(f"CSV load to {target} failed: {str(e)}")
                return {"status": "FAILED", "error_message": str(e)}
            finally:
                cursor.close()

    def load_parquet_to_oracle(self, table_name: str, parquet_file: str,
                               dest_connection_string: Optional[str] = None,
                               schema: Optional[str] = None,
                               use_direct_path: bool = False) -> Dict:
        """Load Parquet file into Oracle table using bulk insert."""
        target = f"{schema}.{table_name}" if schema else table_name

        try:
            df = pd.read_parquet(parquet_file)
        except Exception as e:
            return {"status": "FAILED", "error_message": f"Failed to read parquet: {str(e)}"}

        return self.bulk_copy(target, df, self.config.batch_size, dest_connection_string)
