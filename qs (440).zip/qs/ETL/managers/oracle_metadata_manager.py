import asyncio
from typing import Dict, Any, List, Optional, Union, Tuple
from datetime import datetime
import logging
import traceback

import pandas as pd

# ── core_libs imports (PVC-mounted at runtime, stubs for local dev) ──
# CentralizedLogger removed — its TimedRotatingFileHandler breaks on
# Windows (PermissionError [WinError 32] when doRollover tries to
# rename the open file).  log_config.build_module_logger is the
# replacement on every platform.

try:
    from core_libs.entity.dag_template_config import DagTemplateConfig
except ImportError:
    DagTemplateConfig = None

try:
    from core_libs.entity.dag_config import DAGConfig
except ImportError:
    DAGConfig = None

try:
    from core_libs.entity.metadatarecord import MetadataRecord
except ImportError:
    MetadataRecord = None

try:
    from core_libs.entity.moduletype import ModuleType
except ImportError:
    ModuleType = None

try:
    from core_libs.entity.taskstatus import TaskStatus
except ImportError:
    TaskStatus = None

try:
    from core_libs.utils.decorators import retry_on_failure
except ImportError:
    def retry_on_failure(max_retries=3, delay=1.0):
        """Fallback no-op decorator when core_libs is unavailable."""
        def decorator(func):
            return func
        return decorator

# Always use LOCAL OracleDBLib (the core_libs one was truncated/broken)
from managers.oracledblib import OracleDBLib

import os

from log_config import get_log_dir as _get_log_dir, build_module_logger
LOG_DIR = _get_log_dir()


def _build_logger(name: str) -> logging.Logger:
    """Build a logger via the shared Windows-safe helper.

    Uses ``log_config.build_module_logger`` so we get stdlib FileHandler
    (no rotation, no rename) — CentralizedLogger's TimedRotatingFileHandler
    blows up on Windows with PermissionError because the OS refuses to
    rename an open file during ``doRollover``.
    """
    return build_module_logger(name, "oracle_metadata_manager")


class OracleMetadataManager:
    """
    High-level Oracle metadata/ETL operations.
    Wraps OracleDBLib for procedure calls, queries, bulk copy, etc.

    Constructor accepts a connection string (str) in ``user/password@host:port/service`` format.
    """

    def __init__(self, connection_string: str):
        self.connection_string = connection_string
        self.logger = _build_logger(self.__class__.__name__)
        self.oracle_db = OracleDBLib(self.connection_string)
        # BF-597 (2026-05-30): pinned connection for DBMS_LOCK.
        # DBMS_LOCK is session-scoped — the lock is released the moment
        # the connection returns to the pool.  Pooled connections defeat
        # cross-pod safety.  We acquire ONE connection at first-claim
        # time and HOLD it for the lifetime of this manager instance.
        # Locks acquired via this connection persist until the manager
        # is destroyed OR the pod dies (Oracle auto-releases on
        # session-end).  Lazy-init so we don't pay the cost when claims
        # aren't used (e.g. standalone Airflow operator paths).
        self._claim_connection = None
        self._claim_connection_lock = None  # threading.Lock lazy-init
        # 2026-07-01 hotfix-2 -- SESSION lock for the pinned connection.
        # oracledb ``Connection`` objects are NOT thread-safe by default
        # (only ``SessionPool`` is).  ``try_claim_run`` is wrapped in
        # ``asyncio.to_thread`` from the runner, so N concurrent runs
        # can each execute cursor operations on the SAME pinned
        # connection from DIFFERENT threadpool threads.  Without
        # serialization Oracle raises DPY-1002 (concurrent statement
        # execution on the same connection) or silently corrupts
        # session state.  This session lock serializes ALL cursor +
        # commit + rollback ops on ``self._claim_connection``.
        # Separate from ``_claim_connection_lock`` (which guards the
        # singleton-reference mutation) so a slow claim doesn't block
        # the reopen path.
        self._claim_session_lock = None  # threading.Lock lazy-init

    # ── Logging helpers (call Oracle stored procs) ─────────────────────

    def log_kafka(self, msg: str, src: str, iserr: int = 0, entity: int = 0,
                  connection_string: Optional[str] = None) -> None:
        """Log a message to OTG_KAFKA_LOGIT."""
        params = [
            {"name": "msg", "value": msg, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "src", "value": src, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "iserr", "value": iserr, "direction": "IN", "type_hint": "NUMBER"},
            {"name": "entity", "value": entity, "direction": "IN", "type_hint": "NUMBER"},
        ]
        try:
            db = self.oracle_db if not connection_string else OracleDBLib(connection_string)
            db.execute_procedure("otg_logManager.log_kafka", params)
        except Exception as e:
            self.logger.error(f"Failed to log Kafka message: {str(e)}")
            raise

    def log_etl(self, msg: str, src: str, iserr: int = 0, taskid: int = 0, dagid: int = 0,
                connection_string: Optional[str] = None) -> None:
        """Log a message to OTG_ETL_LOGIT."""
        params = [
            {"name": "msg", "value": msg, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "src", "value": src, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "iserr", "value": iserr, "direction": "IN", "type_hint": "NUMBER"},
            {"name": "taskid", "value": taskid, "direction": "IN", "type_hint": "NUMBER"},
            {"name": "dagid", "value": dagid, "direction": "IN", "type_hint": "NUMBER"},
        ]
        try:
            db = self.oracle_db if not connection_string else OracleDBLib(connection_string)
            db.execute_procedure("otg_logManager.log_etl", params)
        except Exception as e:
            self.logger.error(f"Failed to log ETL message: {str(e)}")
            raise

    def log_service(self, msg: str, src: str, iserr: int = 0, reportid: int = 0, dagid: int = 0,
                    connection_string: Optional[str] = None) -> None:
        params = [
            {"name": "msg", "value": msg, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "src", "value": src, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "iserr", "value": iserr, "direction": "IN", "type_hint": "NUMBER"},
            {"name": "reportid", "value": reportid, "direction": "IN", "type_hint": "NUMBER"},
            {"name": "dagid", "value": dagid, "direction": "IN", "type_hint": "NUMBER"},
        ]
        try:
            db = self.oracle_db if not connection_string else OracleDBLib(connection_string)
            db.execute_procedure("otg_logManager.log_service", params)
        except Exception as e:
            self.logger.error(f"Failed to log service message: {str(e)}")
            raise

    # ── Report / batch status ──────────────────────────────────────────

    def check_otg_report_status(self, report_id: int, fk_dag_id: str, run_id: str,
                                 business_date,
                                 connection_string: Optional[str] = None) -> str:
        """Check report status via PKG_OTG_BATCH_CONTROL.PR_CHECK_OTG_REPORT_STATUS."""
        params = [
            {"name": "p_report_id", "value": report_id, "direction": "IN", "type_hint": "NUMBER"},
            {"name": "p_fk_dag_id", "value": fk_dag_id, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "p_run_id", "value": run_id, "direction": "IN", "type_hint": "VARCHAR2"},
            {"name": "p_business_date", "value": business_date, "direction": "IN", "type_hint": "DATE"},
            {"name": "p_global_status", "value": None, "direction": "OUT", "type_hint": "VARCHAR2"},
        ]
        try:
            result = self.oracle_db.execute_procedure(
                "PKG_OTG_BATCH_CONTROL.PR_CHECK_OTG_REPORT_STATUS", params, connection_string
            )
            if result["status"] != "SUCCESS":
                raise RuntimeError(f"Report status check failed: {result.get('error_message')}")
            return result.get("out_parameters", {}).get("p_global_status", "UNKNOWN")
        except Exception as e:
            self.logger.error(f"Failed to check report status: {str(e)}")
            raise RuntimeError(f"Report status check failed: {str(e)}")

    async def update_otg_etl_batch_status(self, run_id: int, run_detail_id: int, command: str,
                                           step_name: str, total_record: Optional[int],
                                           error_desc: Optional[str], connection_string: str):
        """Call ETL_Batch_UPDATE procedure to update ETL batch status."""
        self.logger.info(
            f"Calling ETL_Batch_UPDATE for RUN_ID={run_id}, COMMAND={command}, RUN_DETAIL_ID={run_detail_id}"
        )
        await asyncio.to_thread(
            self.oracle_db.execute_procedure,
            procedure_name="PKG_OTG_BATCH_CONTROL.ETL_Batch_UPDATE",
            parameters=[
                {"name": "p_RUN_ID", "value": run_id, "direction": "IN", "type_hint": "NUMBER"},
                {"name": "p_RUN_DETAIL_ID", "value": run_detail_id, "direction": "IN", "type_hint": "NUMBER"},
                {"name": "p_COMMAND", "value": command, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_TOTAL_RECORD", "value": total_record, "direction": "IN", "type_hint": "NUMBER"},
                {"name": "p_ERROR_DESC", "value": error_desc, "direction": "IN", "type_hint": "VARCHAR2"},
            ],
            connection_string=connection_string,
        )

    async def execute_procedure_async(self, procedure_name: str, parameters: List[Dict],
                                       connection_string: str) -> Dict:
        """Execute a stored procedure asynchronously with retry."""
        self.logger.debug(f"Executing procedure {procedure_name} with parameters: {parameters}")
        return await asyncio.to_thread(
            self.oracle_db.execute_procedure,
            procedure_name=procedure_name,
            parameters=parameters,
            connection_string=connection_string,
        )

    async def bulk_copy(self, table_name: str, data: pd.DataFrame, batch_size: int,
                        dest_connection_string: str, worker_connection_string: str = None) -> Dict:
        if not table_name or not isinstance(data, pd.DataFrame) or batch_size <= 0:
            raise ValueError("Invalid bulk copy parameters")
        return await asyncio.to_thread(
            self.oracle_db.bulk_copy,
            table_name=table_name,
            data=data,
            batch_size=batch_size,
            connection_string=dest_connection_string,
        )

    # ── Query execution ────────────────────────────────────────────────

    async def get_procedure_params(self, proc_id: int, connection_string: str) -> List[Dict]:
        """Fetch procedure parameters from vw_getprocParam."""
        df = await asyncio.to_thread(
            self.oracle_db.execute_query,
            "SELECT PARAM_NAME, PARAM_VALUE, PARAM_TYPE, DIRECTION FROM vw_getprocParam WHERE PROC_ID = :1",
            {"1": proc_id},
            connection_string,
        )
        return [row.to_dict() for _, row in df.iterrows()]

    async def update_etl_batch(self, dag_run_id: str, task_id: int, fk_report_id: int,
                                task_event_id: str, status: str, event_name: str,
                                connection_string: str):
        """Update ETL batch status using a generic procedure."""
        self.logger.info(
            f"Updating ETL batch for DAG {dag_run_id}, task {task_id}, report {fk_report_id}, "
            f"event {event_name} to {status} at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )
        await asyncio.to_thread(
            self.oracle_db.execute_procedure,
            procedure_name="UPDATE_ETL_BATCH_STATUS",
            parameters=[
                {"name": "p_dag_run_id", "value": dag_run_id, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_task_id", "value": task_id, "direction": "IN", "type_hint": "NUMBER"},
                {"name": "p_fk_report_id", "value": fk_report_id, "direction": "IN", "type_hint": "NUMBER"},
                {"name": "p_task_event_id", "value": task_event_id, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_status", "value": status, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_event_name", "value": event_name, "direction": "IN", "type_hint": "VARCHAR2"},
            ],
            connection_string=connection_string,
        )

    async def execute_query_asynch(self, query: str, parameters: Dict[str, Any],
                                    connection_string: str) -> pd.DataFrame:
        """Execute a query asynchronously, returns DataFrame."""
        if not query or not isinstance(query, str):
            raise ValueError("Query must be a non-empty string")
        return await asyncio.to_thread(
            self.oracle_db.execute_query,
            query=query,
            parameters=parameters,
            connection_string=connection_string,
        )

    @retry_on_failure(max_retries=3, delay=1.0)
    def execute_query(self, query: str, params: Optional[Dict[str, Any]] = None,
                       target_app: str = 'internal',
                       connection_string: Optional[str] = None) -> pd.DataFrame:
        """Execute a query synchronously, returns DataFrame."""
        try:
            self.logger.info(f"Executing query on {target_app}: {query[:100]}...")
            if target_app == 'internal':
                db = self.oracle_db
            else:
                if not connection_string:
                    raise ValueError("connection_string must be provided for external target_app")
                db = OracleDBLib(connection_string)
            result = db.execute_query(query, params)
            self.logger.info(f"Query returned {len(result)} rows")
            return result
        except Exception as e:
            self.logger.error(f"Failed to execute query on {target_app}: {str(e)}")
            raise RuntimeError(f"Query execution failed: {str(e)}") from e

    # ── Metadata operations ────────────────────────────────────────────

    @retry_on_failure(max_retries=3, delay=1.0)
    def insert_metadata(self, metadata) -> bool:
        """Insert metadata using MetadataRecord dataclass."""
        try:
            parameters = metadata.to_parameters()
            self.oracle_db.execute_procedure(
                "INSERT_METADATA", parameters, self.connection_string
            )
            self.logger.info(
                f"Inserted metadata for DAG {metadata.dag_id}, "
                f"task {metadata.task_name}, execution_date {metadata.execution_date}"
            )
            return True
        except Exception as e:
            self.logger.error(f"Failed to insert metadata: {str(e)}")
            raise RuntimeError(f"Insert metadata failed: {str(e)}") from e

    def insert_metadata_legacy(self, dag_id: str, execution_date: datetime, business_date: str,
                                report_id: str, task_name: str, status: str,
                                total_records: int = 0, module: str = "TRANSFER",
                                file_name: str = "N/A", checksum: str = "N/A",
                                file_format: str = "N/A", file_path: str = "N/A",
                                error: Optional[str] = None) -> bool:
        if not TaskStatus or not ModuleType or not MetadataRecord:
            self.logger.warning("core_libs entity classes not available — skipping insert_metadata_legacy")
            return False
        try:
            status_enum = TaskStatus(status)
        except ValueError:
            self.logger.warning(f"Invalid status '{status}', defaulting to PENDING")
            status_enum = TaskStatus.PENDING
        try:
            module_enum = ModuleType(module)
        except ValueError:
            self.logger.warning(f"Invalid module '{module}', defaulting to TRANSFER")
            module_enum = ModuleType.TRANSFER
        metadata = MetadataRecord(
            dag_id=dag_id, execution_date=execution_date, business_date=business_date,
            report_id=report_id, task_name=task_name, status=status_enum,
            total_records=total_records, module=module_enum, file_name=file_name,
            checksum=checksum, file_format=file_format, file_path=file_path, error=error,
        )
        return self.insert_metadata(metadata)

    @retry_on_failure(max_retries=3, delay=1.0)
    def update_status(self, dag_id: str, execution_date: datetime, business_date: str,
                       report_id: str, task_name: str, status,
                       total_records: int, module=None,
                       error: Optional[str] = None) -> bool:
        try:
            if TaskStatus and isinstance(status, str):
                status = TaskStatus(status)
            if ModuleType and isinstance(module, str):
                module = ModuleType(module)

            status_val = status.value if hasattr(status, 'value') else str(status)
            module_val = module.value if hasattr(module, 'value') else str(module or "TRANSFER")

            parameters = [
                {"name": "p_dag_id", "value": dag_id, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_execution_date", "value": execution_date, "direction": "IN", "type_hint": "DATE"},
                {"name": "p_business_date", "value": business_date, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_report_id", "value": report_id, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_task_name", "value": task_name, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_status", "value": status_val, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_total_records", "value": total_records, "direction": "IN", "type_hint": "NUMBER"},
                {"name": "p_module", "value": module_val, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_error", "value": error, "direction": "IN", "type_hint": "VARCHAR2"},
            ]
            self.oracle_db.execute_procedure(
                "UPDATE_METADATA_STATUS", parameters, self.connection_string
            )
            self.logger.info(
                f"Updated status for DAG {dag_id}, task {task_name}, "
                f"execution_date {execution_date} to {status_val}"
            )
            return True
        except ValueError as ve:
            self.logger.error(f"Invalid enum value: {str(ve)}")
            raise ValueError(f"Invalid status or module value: {str(ve)}") from ve
        except Exception as e:
            self.logger.error(f"Failed to update status: {str(e)}")
            raise RuntimeError(f"Update status failed: {str(e)}") from e

    def _get_default_metadata(self) -> Dict[str, Any]:
        """Return default metadata values."""
        return {
            "file_name": "N/A", "total_records": 0, "checksum": "N/A",
            "file_format": "N/A", "file_path": "N/A", "business_date": None, "report_id": None,
        }

    # ── DAG management ─────────────────────────────────────────────────

    @retry_on_failure(max_retries=3, delay=1.0)
    def fetch_active_dag_ids(self, template_type: str) -> List[str]:
        """Fetch active DAG IDs with cursor output."""
        try:
            parameters = [
                {"name": "p_template_type", "value": template_type, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_dummy", "value": None, "direction": "IN", "type_hint": "VARCHAR2"},
                {"name": "p_cursor", "value": None, "direction": "OUT", "type_hint": "CURSOR"},
            ]
            result = self.oracle_db.execute_procedure(
                "FETCH_ACTIVE_DAG_IDS", parameters, self.connection_string
            )
            if result["status"] != "SUCCESS":
                raise RuntimeError(f"FETCH_ACTIVE_DAG_IDS failed: {result.get('error_message')}")

            cursor = result.get("out_parameters", {}).get("p_cursor")
            if cursor and hasattr(cursor, 'fetchall'):
                dag_ids = [row[0] for row in cursor.fetchall() if row and row[0]]
                cursor.close()
            else:
                dag_ids = []

            self.logger.info(f"Fetched {len(dag_ids)} active DAGs for template_type {template_type}")
            return dag_ids
        except Exception as e:
            self.logger.error(f"Failed to fetch active DAG IDs: {str(e)}")
            raise RuntimeError(f"Fetch active DAG IDs failed: {str(e)}") from e

    # ── Procedure helpers ──────────────────────────────────────────────

    def call_procedure_bool(self, procedure_name: str, params: Dict[str, Any],
                             target_app: str = 'internal',
                             connection_string: Optional[str] = None) -> bool:
        """Execute a stored procedure, return True on success."""
        try:
            self.logger.info(f"params: {params}")
            if target_app == 'internal':
                db = self.oracle_db
            else:
                db = OracleDBLib(connection_string)
            parameters = []
            for key, value in params.items():
                type_hint = self._get_oracle_type_hint(value)
                parameters.append({
                    "name": key, "value": value, "direction": "IN", "type_hint": type_hint,
                })
            db.execute_procedure(procedure_name, parameters)
            self.logger.info(
                f"Successfully called procedure {procedure_name} on {target_app}"
            )
            return True
        except Exception as e:
            self.logger.error(
                f"Failed to call procedure {procedure_name} on {target_app}: {str(e)}"
            )
            raise RuntimeError(f"Procedure call '{procedure_name}' failed: {str(e)}") from e

    def call_procedure(self, procedure_name: str, params: Dict[str, Any],
                        target_app: str = 'internal',
                        connection_string: Optional[str] = None) -> Dict[str, Any]:
        """Execute a stored procedure and return OUT parameter results."""
        try:
            if target_app == 'internal':
                db = self.oracle_db
            else:
                if not connection_string:
                    raise ValueError("connection_string must be provided for external target_app")
                db = OracleDBLib(connection_string)
            parameters = []
            out_params = {}
            for key, value in params.items():
                param = {'name': key, 'direction': 'IN'}
                if isinstance(value, dict) and 'direction' in value:
                    param.update(value)
                    if value.get('direction') == 'OUT':
                        out_params[key] = value.get('value', None)
                else:
                    param['value'] = value
                    param['type_hint'] = self._get_oracle_type_hint(value)
                parameters.append(param)
            result = db.execute_procedure(procedure_name, parameters)
            # Extract OUT values from result
            out_values = result.get("out_parameters", {})
            self.logger.info(
                f"Successfully called procedure {procedure_name} on {target_app}"
            )
            return out_values
        except Exception as e:
            self.logger.error(
                f"Failed to call procedure {procedure_name} on {target_app}: {str(e)}"
            )
            raise RuntimeError(f"Procedure call '{procedure_name}' failed: {str(e)}") from e

    async def get_procedure_params_async(self, p_dagid: str, p_businessdate: str,
                                          procconfigid: int, proctype: str,
                                          target_app: str, connection_string: str) -> List[Dict]:
        """Fetch procedure parameters from stored procedure with cursor output."""
        self.logger.info(
            f"Fetching procedure params for p_dagid: {p_dagid}, p_businessdate: {p_businessdate}, "
            f"procconfigid: {procconfigid}, proctype: {proctype}"
        )
        if target_app == 'internal':
            db = self.oracle_db
        else:
            if not connection_string:
                raise ValueError("connection_string must be provided for external target_app")
            db = OracleDBLib(connection_string)

        # get_procedure_params is sync — wrap in asyncio.to_thread
        results = await asyncio.to_thread(
            db.get_procedure_params,
            "PKG_OTG_BATCH_CONTROL.PR_GET_PROC_PARAM",
            p_dagid, p_businessdate, procconfigid, proctype, connection_string,
        )
        self.logger.info(f"results info {results}")
        return results

    def _execute_procedure_base(self, procedure_name: str, params: List[Dict[str, Any]],
                                 target_app: str = 'internal',
                                 connection_string: Optional[str] = None) -> Dict:
        """Base method for executing a stored procedure (sync)."""
        if target_app == 'internal':
            db = self.oracle_db
        else:
            if not connection_string:
                raise ValueError("connection_string must be provided for external target_app")
            db = OracleDBLib(connection_string)
        result = db.execute_procedure(procedure_name, params, connection_string)
        self.logger.debug(f"Raw procedure result for {procedure_name}: {result}")
        return result

    async def execute_procedure_with_dataframe(self, procedure_name: str,
                                                 params: List[Dict[str, Any]],
                                                 connection_string: str,
                                                 target_app: str = 'internal') -> pd.DataFrame:
        """Execute a procedure with cursor OUT param, return DataFrame."""
        cursor = None
        try:
            cursor_param = next(
                (p for p in params if p.get('direction') == 'OUT' and p.get('type_hint') == 'CURSOR'),
                None,
            )
            if not cursor_param:
                raise ValueError("No cursor OUT parameter defined for the procedure")
            cursor_param_name = cursor_param['name']
            # 2026-07-01 fix -- was ``timeout=300000`` (300000 seconds =
            # 3.47 days) -- clearly a units bug (should have been 300s =
            # 5min).  Under a real Oracle stall this suppressed the
            # cancel for 3+ days, blocking the event-loop task
            # indefinitely.  Restored to 5 minutes matching
            # sibling timeouts on other Oracle calls in this class.
            result = await asyncio.wait_for(
                asyncio.to_thread(
                    self._execute_procedure_base,
                    procedure_name, params, target_app, connection_string,
                ),
                timeout=300,
            )
            if result["status"] != "SUCCESS":
                raise RuntimeError(
                    f"Procedure {procedure_name} failed: "
                    f"{result.get('error_message', 'No error message provided')}"
                )
            out_params = result.get("out_parameters", {})
            cursor = out_params.get(cursor_param_name)
            if not cursor or not hasattr(cursor, 'fetchall'):
                raise ValueError(
                    f"No valid cursor returned by procedure {procedure_name} "
                    f"for parameter {cursor_param_name}"
                )
            df = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])
            self.logger.info(
                f"Successfully executed {procedure_name} with {len(df)} records as DataFrame"
            )
            return df
        except Exception as e:
            self.logger.error(
                f"Failed to execute procedure {procedure_name} on {target_app}: {str(e)}"
            )
            raise RuntimeError(f"Procedure call: {procedure_name} failed: {str(e)}") from e
        finally:
            if cursor and hasattr(cursor, 'close'):
                try:
                    cursor.close()
                except Exception as close_err:
                    self.logger.warning(f"Failed to close cursor: {close_err}")

    async def execute_procedure_with_scalar(self, procedure_name: str,
                                              params: List[Dict[str, Any]],
                                              connection_string: str,
                                              target_app: str = 'internal') -> Dict[str, Any]:
        """Execute a procedure with scalar OUT params."""
        try:
            result = await asyncio.wait_for(
                asyncio.to_thread(
                    self._execute_procedure_base,
                    procedure_name, params, target_app, connection_string,
                ),
                timeout=300,
            )
            if result["status"] != "SUCCESS":
                raise RuntimeError(
                    f"Procedure {procedure_name} failed: "
                    f"{result.get('error_message', 'No error message provided')}"
                )
            out_params = result.get("out_parameters", {})
            self.logger.info(
                f"Successfully executed {procedure_name} with {len(out_params)} scalar values"
            )
            return out_params
        except Exception as e:
            self.logger.error(
                f"Failed to execute procedure {procedure_name} on {target_app}: {str(e)}"
            )
            raise RuntimeError(f"Procedure call: {procedure_name} failed: {str(e)}") from e

    async def execute_procedure_with_status(self, procedure_name: str,
                                              params: List[Dict[str, Any]],
                                              connection_string: str,
                                              target_app: str = 'internal') -> str:
        """Execute a stored procedure and return the status string."""
        try:
            result = await asyncio.wait_for(
                asyncio.to_thread(
                    self._execute_procedure_base,
                    procedure_name, params, target_app, connection_string,
                ),
                timeout=300,
            )
            if result["status"] != "SUCCESS":
                raise RuntimeError(
                    f"Procedure {procedure_name} failed: "
                    f"{result.get('error_message', 'No error message provided')}"
                )
            status = result.get("out_parameters", {}).get("p_status", "SUCCESS")
            self.logger.info(f"Successfully executed {procedure_name} with status: {status}")
            return status
        except Exception as e:
            self.logger.error(
                f"Failed to execute procedure {procedure_name} on {target_app}: {str(e)}"
            )
            raise RuntimeError(f"Procedure call: {procedure_name} failed: {str(e)}") from e

    def execute_procedure_with_cursor(self, procedure_name: str,
                                        params: List[Dict[str, Any]],
                                        target_app: str = 'internal',
                                        connection_string: Optional[str] = None) -> List[Dict[str, Any]]:
        """Execute a stored procedure with cursor-based output, return list of dicts."""
        cursor = None
        try:
            if target_app == 'internal':
                db = self.oracle_db
            else:
                if not connection_string:
                    raise ValueError("connection_string must be provided for external target_app")
                db = OracleDBLib(connection_string)

            cursor_param = next(
                (p for p in params if p.get('direction') == 'OUT' and p.get('type_hint') == 'CURSOR'),
                None,
            )
            if not cursor_param:
                raise ValueError("No cursor OUT parameter defined for the procedure")
            cursor_param_name = cursor_param['name']

            result = db.execute_procedure(procedure_name, params, connection_string)

            if not isinstance(result, dict):
                raise ValueError(f"Unexpected result format: {type(result)}")

            if result["status"] != "SUCCESS":
                raise RuntimeError(
                    f"Procedure {procedure_name} failed: "
                    f"{result.get('error_message', 'No error message provided')}"
                )

            out_params = result.get("out_parameters", {})
            cursor = out_params.get(cursor_param_name)
            if not cursor or not hasattr(cursor, 'fetchall'):
                raise ValueError(
                    f"No valid cursor returned by procedure {procedure_name} "
                    f"for parameter {cursor_param_name}"
                )

            results = cursor.fetchall()
            self.logger.info(
                f"Successfully executed procedure {procedure_name} on {target_app}, "
                f"returned {len(results)} records"
            )
            return results

        except Exception as e:
            self.logger.error(
                f"Failed to execute procedure {procedure_name} on {target_app}: {str(e)}"
            )
            raise RuntimeError(f"Procedure call: {procedure_name} failed: {str(e)}") from e

        finally:
            if cursor and hasattr(cursor, 'close'):
                try:
                    cursor.close()
                except Exception as close_err:
                    self.logger.warning(f"Failed to close cursor: {close_err}")

    # ── Type helpers ───────────────────────────────────────────────────

    def _get_oracle_type_hint(self, value: Any) -> str:
        """Get appropriate Oracle type hint for Python value."""
        if isinstance(value, str):
            return "VARCHAR2"
        elif isinstance(value, (int, float)):
            return "NUMBER"
        elif isinstance(value, datetime):
            return "DATE"
        elif isinstance(value, bool):
            return "NUMBER"
        elif value is None:
            return "VARCHAR2"
        else:
            return "VARCHAR2"

    # ── Background polling service ─────────────────────────────────────

    async def get_all_start_tasks(
        self, conn_str: str, bg_polling_sql: str,
        row_limit: int = 1000,
    ) -> list:
        """Fetch tasks with STATUS='START' in one query.

        Returns list of lowercase-keyed dicts sorted by RUN_ID, SEQ.
        Caller groups by RUN_ID. No claim step needed at this layer —
        BaseStep.execute() calls ETL_Batch_UPDATE(INPROGRESS) on the
        first step, removing the run from STATUS='START' on the next
        poll cycle.  For cross-pod safety the polling service ALSO
        invokes ``try_claim_run`` (DBMS_LOCK) before dispatching.

        BF-595 (SERIOUS #5): ``row_limit`` caps the returned rowcount.
        The query binds ``:row_limit`` so a SOD spike doesn't slow
        every poll cycle to a crawl.  Default 1000 — plenty for the
        polling service's max_concurrent_runs × multiplier sizing.
        """
        df = await self.execute_query_asynch(
            bg_polling_sql, {"row_limit": int(row_limit)}, conn_str,
        )
        if df is None or df.empty:
            return []
        records = df.to_dict(orient="records")
        # Normalize column names to lowercase (Oracle returns upper-case)
        return [{k.lower(): v for k, v in row.items()} for row in records]

    # ── Phase 134-K — atomic run claim (audit SERIOUS #5) ─────────────────
    #
    # Two pods (e.g. an Airflow operator + a polling-service tick) can
    # both fetch the SAME polling row for the SAME RUN_ID before either
    # transitions STATUS to INPROGRESS.  Without a serialisation point
    # they both race through the 5-step pipeline, racing on output_dir,
    # .checkpoint.json, group_history.json — and double-deliver to S3 /
    # SFTP.
    #
    # Fix: an Oracle session-level advisory lock via DBMS_LOCK on a
    # name derived from RUN_ID.  Exclusive mode, non-blocking
    # (timeout=0), release-on-session-end (no commit-time release) so
    # a dead pod auto-releases the lock at session teardown.
    #
    # Requires EXECUTE on DBMS_LOCK (granted to the worker schema by
    # default in most installs).  When not granted, the wrapper catches
    # ORA-06550 / ORA-04068 and logs a warning — degraded behaviour but
    # no worse than today, and ops get a clear signal to ask the DBA.

    def _get_claim_session_lock(self):
        """Return the process-lifetime session lock for the pinned
        DBMS_LOCK connection.  Serializes cursor + execute + commit ops
        so concurrent asyncio.to_thread workers don't corrupt the
        oracledb Connection (which is not thread-safe)."""
        import threading as _threading
        if self._claim_session_lock is None:
            # Double-checked idiom under the outer singleton lock.
            if self._claim_connection_lock is None:
                self._claim_connection_lock = _threading.Lock()
            with self._claim_connection_lock:
                if self._claim_session_lock is None:
                    self._claim_session_lock = _threading.Lock()
        return self._claim_session_lock

    # 2026-07-01 hotfix-2 -- book-keeping for DBMS_LOCK ownership.
    # ``_held_locks`` tracks the set of run_ids we currently hold a
    # DBMS_LOCK for on the pinned session.  If the pinned session
    # dies (ping failure) and we reopen a fresh session, Oracle
    # releases EVERY lock the old session held — meaning another pod
    # can claim the same run_id BEFORE our still-in-flight worker
    # finishes → DOUBLE DISPATCH.  We use the set to (a) refuse
    # reopen while any lock is held (fail-CLOSED preserves
    # correctness at the cost of temporary dispatch skips), and
    # (b) clear entries on explicit release.
    def _register_held_lock(self, run_id: int) -> None:
        if self._claim_session_lock is None:
            self._get_claim_session_lock()
        if not hasattr(self, "_held_locks"):
            self._held_locks = set()
        self._held_locks.add(int(run_id))

    def _unregister_held_lock(self, run_id: int) -> None:
        if getattr(self, "_held_locks", None) is not None:
            self._held_locks.discard(int(run_id))

    def has_held_locks(self) -> bool:
        """True iff we still own DBMS_LOCKs.  Used by the reopen path
        to refuse a session-recreate that would orphan the locks."""
        held = getattr(self, "_held_locks", None)
        return bool(held)

    def _get_or_create_claim_connection(self, connection_string: str):
        """BF-597 (2026-05-30): get-or-create the pinned connection for
        DBMS_LOCK.  Held outside the pool for the manager's lifetime
        so locks acquired persist across multiple claim calls.

        Returns a raw oracledb Connection (NOT a context manager —
        caller must NOT close it).  Lazy-init + thread-safe via lock.

        2026-07-01: ping() runs OUTSIDE the critical section.  Ping is
        a synchronous round-trip to Oracle (can be tens of ms on a
        slow WAN), and holding the singleton lock during it serialized
        every claim attempt across the entire pod.  The lock now only
        guards the *replace-the-reference* operation (the compare-and-
        swap of ``self._claim_connection``), while probing / opening /
        closing happens lock-free on a local variable.
        """
        import oracledb as _ora
        import threading as _threading
        if self._claim_connection_lock is None:
            self._claim_connection_lock = _threading.Lock()

        # First-hand-off: snapshot the current connection under a
        # brief lock so we don't race with a concurrent reopen, then
        # release the lock BEFORE the potentially-slow ping().
        with self._claim_connection_lock:
            current = self._claim_connection
        if current is not None:
            try:
                current.ping()
                return current
            except Exception:
                # Dead connection.  Before reopening, refuse if we
                # still hold DBMS_LOCKs on the old session -- reopen
                # means Oracle releases every lock the old session
                # held, orphaning our in-flight active_runs and
                # allowing another pod to claim them (double
                # dispatch).  Fail-CLOSED by raising so the caller
                # sees a claim error + skips this poll cycle.
                # Once the in-flight runs drain (release_run_claim
                # unregisters) the reopen path is unblocked
                # automatically.
                # 2026-07-01 hotfix-2.
                if self.has_held_locks():
                    self.logger.error(
                        "Pinned DBMS_LOCK connection ping failed while "
                        "%d run_id lock(s) still held -- refusing to "
                        "reopen (would orphan the locks + allow "
                        "double-dispatch).  Waiting for in-flight "
                        "runs to drain.",
                        len(getattr(self, "_held_locks", set()) or set()),
                    )
                    raise RuntimeError(
                        "pinned claim connection dead but "
                        f"{len(getattr(self, '_held_locks', set()) or set())} "
                        "DBMS_LOCK(s) still held -- reopen refused"
                    )
                try:
                    current.close()
                except Exception:
                    pass
                with self._claim_connection_lock:
                    if self._claim_connection is current:
                        self._claim_connection = None

        # Take the lock for the actual reopen.  Re-check under the
        # lock in case another thread already opened a fresh
        # connection while we were probing / closing above.
        with self._claim_connection_lock:
            if self._claim_connection is not None:
                return self._claim_connection
            # First-call or reopen.  Delegate to the canonical parser
            # so BOTH Easy-Connect (``user/pw@host:port/svc``) and
            # OLEDB (``(DESCRIPTION=...); User Id=X; Password=Y;``)
            # shapes work.  2026-07-01 fix: previously the naive
            # ``split("/")`` + ``split("@")`` raised ValueError on
            # OLEDB strings, and the fail-open branch upstream turned
            # cross-pod claim OFF silently on vault-resolved
            # connections (which return the OLEDB shape).
            cs = connection_string or self.connection_string
            try:
                from oracle_config_loader import (
                    parse_oracle_connection_string as _parse,
                )
                parsed = _parse(cs)
                user     = (parsed.get("user") or "").strip()
                password = (parsed.get("password") or "").strip()
                dsn      = (parsed.get("dsn") or "").strip()
                if not (user and password and dsn):
                    raise ValueError(
                        f"parse returned incomplete triple: "
                        f"user={bool(user)} password={bool(password)} dsn={bool(dsn)}"
                    )
            except Exception as _parse_exc:
                # Fall back to the legacy naive parse for pure
                # Easy-Connect strings when the canonical parser
                # can't be imported (dev-box quirk).  If THIS also
                # fails we re-raise with the original loud message
                # so operators get an actionable error.
                try:
                    user, rest = cs.split("/", 1)
                    password, dsn = rest.split("@", 1)
                except ValueError:
                    # 2026-07-01 hotfix-2 -- do NOT echo the
                    # underlying parse exception body: it can
                    # legitimately include the DSN (with embedded
                    # user/password) that failed to parse.  Emit only
                    # the exception TYPE so operators still get a
                    # signal without leaking creds to logs.
                    raise ValueError(
                        f"_get_or_create_claim_connection: could not parse "
                        f"connection_string (tried canonical parser: "
                        f"{type(_parse_exc).__name__}; tried naive "
                        f"user/pass@dsn split: malformed).  Value "
                        f"shape={type(cs).__name__} "
                        f"len={len(cs) if cs else 0}."
                    )
            self._claim_connection = _ora.connect(
                user=user, password=password, dsn=dsn,
            )
            self.logger.info(
                "BF-597: pinned DBMS_LOCK connection opened for cross-pod claim"
            )
            return self._claim_connection

    def _try_claim_run_sync(self, run_id: int, claimer_id: str,
                            connection_string: str) -> bool:
        """BF-597: synchronous DBMS_LOCK attempt on the pinned connection.

        Runs the anonymous PL/SQL block via ``cursor.execute`` directly
        — NOT via the broken ``execute_procedure`` path (which calls
        ``cursor.callproc(name, ...)`` and only works for NAMED
        procedures, not anonymous DECLARE blocks).

        Returns True on claim success or fail-open conditions; False
        only when another pod definitively holds the lock.
        """
        if not run_id:
            self.logger.warning("try_claim_run: empty run_id, skipping claim")
            return True

        lock_name = f"SAP_RUN_{int(run_id)}"
        sql = """
        DECLARE
          lockh   VARCHAR2(128);
          result  INTEGER;
        BEGIN
          DBMS_LOCK.ALLOCATE_UNIQUE(
            lockname        => :lock_name,
            lockhandle      => lockh,
            expiration_secs => 86400
          );
          result := DBMS_LOCK.REQUEST(
            lockhandle        => lockh,
            lockmode          => DBMS_LOCK.X_MODE,
            timeout           => 0,
            release_on_commit => FALSE
          );
          :p_result := result;
        END;
        """
        try:
            conn = self._get_or_create_claim_connection(connection_string)
            # 2026-07-01 hotfix-2 -- SERIALIZE cursor ops on the pinned
            # connection.  oracledb Connection is not thread-safe;
            # concurrent runs each in their own asyncio.to_thread
            # threadpool worker would race here otherwise.
            with self._get_claim_session_lock():
                cur = conn.cursor()
                try:
                    result_var = cur.var(int)
                    cur.execute(sql, {"lock_name": lock_name,
                                      "p_result":  result_var})
                    code = result_var.getvalue()
                finally:
                    cur.close()
        except Exception as exc:
            # ORA-06550 / ORA-04068 / ORA-01031 — usually a DBA-side
            # privilege gap.  Fail-open so the run still goes through
            # (degraded cross-pod safety; logged loudly).
            self.logger.warning(
                "try_claim_run: DBMS_LOCK unavailable for run_id=%s (%s) — "
                "proceeding WITHOUT claim, two-worker race guard is "
                "degraded.  Grant EXECUTE ON DBMS_LOCK to the worker "
                "schema to fix.  claimer=%s",
                run_id, exc, claimer_id,
            )
            return True

        if code is None:
            self.logger.warning(
                "try_claim_run: DBMS_LOCK returned no code for run_id=%s "
                "claimer=%s — treating as UNCLAIMED",
                run_id, claimer_id,
            )
            return True
        if code == 0 or code == 4:
            # 2026-07-01 hotfix-2 -- track ownership so a session
            # reopen doesn't silently orphan the lock.
            try:
                self._register_held_lock(run_id)
            except Exception as _reg_exc:                            # pragma: no cover
                self.logger.debug(
                    "_register_held_lock failed for run_id=%s: %s",
                    run_id, _reg_exc,
                )
            self.logger.info(
                "Claimed run_id=%s as %s (DBMS_LOCK code=%s)",
                run_id, claimer_id, code,
            )
            return True
        if code == 1:
            self.logger.warning(
                "run_id=%s is claimed by another process (DBMS_LOCK code=1) "
                "— claimer=%s skipping this run",
                run_id, claimer_id,
            )
            return False
        self.logger.error(
            "try_claim_run: DBMS_LOCK returned unexpected code=%s for "
            "run_id=%s claimer=%s — skipping run to be safe",
            code, run_id, claimer_id,
        )
        return False

    async def try_claim_run(self, run_id: int, claimer_id: str,
                              connection_string: str) -> bool:
        """Try to claim ``run_id`` for this process via DBMS_LOCK.

        Returns:
            True  — lock acquired (or fail-open conditions met)
            False — another pod definitively holds the lock

        BF-597 (2026-05-30): rewritten end-to-end.  The previous
        implementation passed an anonymous PL/SQL block as
        ``procedure_name`` to ``execute_procedure`` which calls
        ``cursor.callproc()`` — that only works for NAMED procedures.
        The call would raise, get swallowed by the bare except, and
        return True silently.  ZERO cross-pod safety.

        Also: DBMS_LOCK is session-scoped.  Using a pooled connection
        meant the lock was released the moment the connection went
        back to the pool — same call.  BF-597 pins a dedicated
        connection on the OracleMetadataManager instance via
        ``_get_or_create_claim_connection`` so locks acquired here
        survive across calls until the manager / pod dies.

        Oracle auto-releases the lock on session close so a pod crash
        doesn't strand it forever.
        """
        return await asyncio.to_thread(
            self._try_claim_run_sync, run_id, claimer_id, connection_string,
        )

    def _release_run_claim_sync(self, run_id: int,
                                  connection_string: str) -> bool:
        """BF-597 companion (2026-07-01): explicit DBMS_LOCK release.

        Used by WorkflowRunner on external CancelledError so a rolling
        upgrade drain-in-place doesn't leave the lock silently held
        until the pod finally dies.  Returns True on success or
        fail-open conditions, False only on a definite release error
        that the caller should log.
        """
        if not run_id:
            return True
        lock_name = f"SAP_RUN_{int(run_id)}"
        sql = """
        DECLARE
          lockh  VARCHAR2(128);
          result INTEGER;
        BEGIN
          DBMS_LOCK.ALLOCATE_UNIQUE(
            lockname        => :lock_name,
            lockhandle      => lockh,
            expiration_secs => 86400
          );
          result := DBMS_LOCK.RELEASE(lockhandle => lockh);
          :p_result := result;
        END;
        """
        try:
            conn = self._get_or_create_claim_connection(connection_string)
            # 2026-07-01 hotfix-2 -- serialize on the session lock.
            with self._get_claim_session_lock():
                cur = conn.cursor()
                try:
                    result_var = cur.var(int)
                    cur.execute(sql, {"lock_name": lock_name,
                                      "p_result":  result_var})
                    code = result_var.getvalue()
                finally:
                    cur.close()
        except Exception as exc:
            self.logger.warning(
                "release_run_claim: DBMS_LOCK release failed for "
                "run_id=%s (%s) -- lock will only be released on "
                "session end (pod death).",
                run_id, exc,
            )
            return False
        # RELEASE codes: 0=success, 3=parameter error, 4=don't own lock, 5=illegal
        if code in (0, 4):
            # 4 means "we didn't own the lock" — fine, semantic success
            # (someone else already released or we never claimed).
            # 2026-07-01 hotfix-2 -- drop from held set on any success
            # outcome so the reopen guard doesn't over-refuse.
            try:
                self._unregister_held_lock(run_id)
            except Exception as _unreg_exc:                          # pragma: no cover
                self.logger.debug(
                    "_unregister_held_lock failed for run_id=%s: %s",
                    run_id, _unreg_exc,
                )
            self.logger.info(
                "Released DBMS_LOCK for run_id=%s (code=%s)",
                run_id, code,
            )
            return True
        self.logger.warning(
            "release_run_claim: DBMS_LOCK.RELEASE returned unexpected "
            "code=%s for run_id=%s -- lock may still be held.",
            code, run_id,
        )
        return False

    async def release_run_claim(self, run_id: int,
                                  connection_string: str) -> bool:
        """Async wrapper around ``_release_run_claim_sync``.  Called
        from WorkflowRunner's CancelledError branch during graceful
        drain to release the DBMS_LOCK explicitly, so drain-in-place
        pod upgrades don't leave rows stranded with the lock held
        until pod restart."""
        return await asyncio.to_thread(
            self._release_run_claim_sync, run_id, connection_string,
        )

    # ── Health check ───────────────────────────────────────────────────

    def health_check(self) -> bool:
        """Test Oracle connectivity with a lightweight query on BOTH
        the default pool AND the pinned claim connection (when one
        exists).

        2026-07-01 hygiene -- previously only the default pool was
        probed.  Oracle drops the two independently; a healthy pool
        + dead claim conn means readiness reports ok but every
        subsequent dispatch fails silently on the cross-pod claim
        step.  Now both must succeed.
        """
        try:
            df = self.oracle_db.execute_query("SELECT 1 FROM DUAL")
            if df is None or df.empty:
                self.logger.warning("Oracle health check returned empty result")
                return False
        except Exception as e:
            self.logger.error(f"Health check (default pool) failed: {e}")
            return False
        # Claim connection probe -- only if we've already opened one.
        # We do NOT open a fresh connection here (side-effecting from
        # a health probe is bad).  When the claim conn hasn't been
        # opened yet, treat that as "healthy so far" (the first
        # try_claim_run will open it and surface any real issue).
        if self._claim_connection is not None:
            try:
                self._claim_connection.ping()
            except Exception as _ping_exc:
                self.logger.warning(
                    "Claim connection health probe failed: %s -- next "
                    "dispatch will reopen it; readiness OK.",
                    _ping_exc,
                )
                # Not a hard failure -- the claim conn will re-open
                # on next use.  Report healthy so K8s doesn't restart
                # us for a transient session issue.
        self.logger.info("Oracle connection health check passed")
        return True

    # ── DAG config fetchers ────────────────────────────────────────────

    def fetch_dag_configs(self, target_app: str = 'internal',
                           connection_string: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
        try:
            vw_airflow_dag_config_query = """
                SELECT
                    dag_id, business_date, fk_report_id, created_date, description,
                    schedule_interval, tags, max_active_runs, concurrency,
                    fk_dag_templateid, fk_dest_appid,
                    otg_dag_id, dag_url, fk_otg_dag_id, on_cloud_appid, on_prem_appid,
                    dest_appid, dest_table, preload_task_proc_configid, postload_task_proc_configid,
                    c_appid, c_appname, c_env, c_hostname, c_port, c_username, c_catalog,
                    c_schemainfo, c_pwd, c_batch_size,
                    p_appid, p_appname, p_env, p_hostname, p_port,
                    p_username, p_catalog, p_schemainfo, p_pwd, p_batch_size,
                    o_appid, db_connection, o_batch_size
                FROM vw_airflow_dag_config
            """

            vw_otg_get_dag_config_query = """
                SELECT
                    dag_id, fk_report_id, description, schedule_interval, tags,
                    fk_dest_appid, otg_dag_id, template_id, template_name, task_type, seq
                FROM vw_otg_get_dag_config WHERE dag_id IN ({placeholders})
            """

            if target_app == 'internal':
                db = self.oracle_db
            else:
                if not connection_string:
                    raise ValueError("connection_string must be provided for external target_app")
                db = OracleDBLib(connection_string)
            result = db.fetch_dag_configs(vw_airflow_dag_config_query, vw_otg_get_dag_config_query)
            return result
        except Exception as e:
            self.logger.error(f"Query execution failed: {str(e)}")
            raise RuntimeError(f"Query execution failed: {str(e)}") from e

    def fetch_dag_template_configs(self, target_app: str = 'internal',
                                     connection_string: Optional[str] = None) -> List:
        try:
            vw_otg_get_dag_config_query = """
                SELECT
                    dag_id, fk_report_id, description, schedule_interval, tags,
                    fk_dest_appid, otg_dag_id, template_id, template_name, task_type, seq
                FROM vw_otg_get_dag_config
            """

            if target_app == 'internal':
                db = self.oracle_db
            else:
                if not connection_string:
                    raise ValueError("connection_string must be provided for external target_app")
                db = OracleDBLib(connection_string)
            result = db.fetch_dag_template_configs(vw_otg_get_dag_config_query)
            return result
        except Exception as e:
            self.logger.error(f"Query execution failed: {str(e)}")
            raise RuntimeError(f"Query execution failed: {str(e)}") from e

    # ── File loaders ───────────────────────────────────────────────────

    async def load_csv_to_oracle(self, table_name: str, csv_file: str,
                                   dest_connection_string: str,
                                   schema: Optional[str] = None,
                                   use_direct_path: bool = False) -> Dict:
        """Load CSV file into Oracle table (async wrapper around sync method)."""
        self.logger.debug(
            f"Loading CSV {csv_file} to {table_name}, use_direct_path={use_direct_path}"
        )
        try:
            result = await asyncio.to_thread(
                self.oracle_db.load_csv_to_oracle,
                table_name=table_name,
                csv_file=csv_file,
                dest_connection_string=dest_connection_string,
                schema=schema,
                use_direct_path=use_direct_path,
            )
            self.logger.debug(f"CSV load result: {result}")
            return result
        except Exception as e:
            self.logger.error(f"CSV load failed: {str(e)}\n{traceback.format_exc()}")
            raise

    async def load_parquet_to_oracle(self, table_name: str, parquet_file: str,
                                       dest_connection_string: str,
                                       schema: Optional[str] = None,
                                       use_direct_path: bool = False) -> Dict:
        """Load Parquet file into Oracle table (async wrapper)."""
        self.logger.debug(
            f"Loading Parquet {parquet_file} to {table_name}, use_direct_path={use_direct_path}"
        )
        try:
            result = await asyncio.to_thread(
                self.oracle_db.load_parquet_to_oracle,
                table_name=table_name,
                parquet_file=parquet_file,
                dest_connection_string=dest_connection_string,
                schema=schema,
                use_direct_path=use_direct_path,
            )
            self.logger.debug(f"Parquet load result: {result}")
            return result
        except Exception as e:
            self.logger.error(f"Parquet load failed: {str(e)}\n{traceback.format_exc()}")
            raise

    async def close_connection(self, connection: Any, dest_connection_string: str) -> None:
        if connection:
            await asyncio.to_thread(
                self.oracle_db.release_connection, connection, dest_connection_string
            )
            self.logger.info("Oracle connection released")
