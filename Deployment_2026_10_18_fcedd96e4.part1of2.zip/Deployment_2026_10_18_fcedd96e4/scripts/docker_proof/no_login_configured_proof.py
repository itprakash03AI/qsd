"""Nobody sees anything without a login when login is NOT configured (2026-10-18).

The owner's OpenShift ran Deployment_2026_10_15 with no auth settings: every
visitor was a guest ADMIN and saw every connection ("if someone not authorized
how come they can see everything").  Since this change an UNSET auth.type is
LOGIN REQUIRED.

On the release image itself (querystudio-local-api:latest), two throwaway API
containers with a config.json that has NO auth section (the owner's case):

  A. no login type anywhere      -> /auth/config says login required + not
     configured; every data route refuses an anonymous caller (401); the log
     says so;
  B. QUERYSTUDIO_AUTH_TYPE=none, set ON PURPOSE (the control) -> the same
     routes answer the guest.  B passing proves A's refusals are the rule,
     not a server that refuses everything.

    python scripts/docker_proof/no_login_configured_proof.py
"""
from __future__ import annotations

import json
import pathlib
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

IMAGE = "querystudio-local-api:latest"
RES = []
ROUTES = ["/api/connections", "/api/feeds", "/api/business-reports", "/api/dashboards", "/auth/me"]

#: routes that are public BY DESIGN: liveness, the login page's own needs, the
#: build/version stamp, the API docs.  Anything else answering anonymously is the
#: defect.  (A published API under /api/v1 answers only with an API key.)
_PUBLIC_EXACT = {"/health", "/health/live", "/health/ready", "/health/startup", "/auth/config",
                 "/auth/public-key", "/api/version", "/openapi.json", "/docs", "/redoc",
                 "/docs/oauth2-redirect", "/config.json", "/",
                 # the Kubernetes probes of a worker pod (no credentials; alive / ready only)
                 "/api/worker/health", "/api/worker/ready"}


def _public(path: str) -> bool:
    return path in _PUBLIC_EXACT or path.startswith("/health/")
#: the rig's writable data paths (the image's defaults point at an NFS mount)
PATHS = {k: f"/app/data/{v}" for k, v in {
    "QUERYSTUDIO_PATHS_DATA_DIR": "", "QUERYSTUDIO_PATHS_PARQUET_DIR": "parquet",
    "QUERYSTUDIO_PATHS_DOWNLOADS_DIR": "downloads", "QUERYSTUDIO_PATHS_DOWNLOAD_TEMP_DIR": "tmp/downloads",
    "QUERYSTUDIO_PATHS_DUCKDB_TEMP_DIR": "tmp/duckdb", "DUCKDB_TEMP_DIR": "tmp/duckdb",
    "QUERYSTUDIO_PATHS_UPLOAD_DIR": "uploads", "QUERYSTUDIO_PATHS_SECRET_KEY_FILE": "secret.key",
    "QUERYSTUDIO_AGG_CACHE_STORAGE_DIR": "agg_cache", "QUERYSTUDIO_FEDERATION_VIEWS_STORAGE_DIR": "federation_views",
    "QUERYSTUDIO_FEED_GENERATION_OUTPUT_DIR": "feeds", "QUERYSTUDIO_LOCAL_TABLES_STORAGE_DIR": "local_tables",
    "QUERYSTUDIO_MATERIALIZED_VIEWS_STORAGE_DIR": "materialized", "QUERYSTUDIO_PUBLISHED_VIEWS_CACHE_DIR": "published_cache",
    "QUERYSTUDIO_S3_LOCAL_CACHE_CACHE_DIR": "s3_cache", "QUERYSTUDIO_SQL_FILES_STORAGE_DIR": "sql_files"}.items()}


def check(name, ok, detail=""):
    RES.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + name + (f" -- {str(detail)[:500]}" if detail else ""), flush=True)
    return ok


def http(port, path):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=20) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:                                   # noqa: BLE001
        return None, str(e)


def start(name, port, cfg_dir, extra_env):
    subprocess.run(["docker", "rm", "-f", name], capture_output=True)
    env = []
    for k, v in {**PATHS, **extra_env}.items():
        env += ["-e", f"{k}={v}"]
    r = subprocess.run(["docker", "run", "-d", "--name", name, "-p", f"{port}:8000",
                        "-v", f"{cfg_dir}:/cfg:ro", "--tmpfs", "/app/data:mode=1777", "-e", "QUERYSTUDIO_CONFIG=/cfg/config.json",
                        "-e", "QUERYSTUDIO_SERVER_HOST=0.0.0.0", "-e", "QUERYSTUDIO_SERVER_PORT=8000",
                        *env, IMAGE, "python", "-m", "querystudio", "standalone"],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"docker run {name}: {r.stderr[-400:]}")
    deadline = time.time() + 240
    while time.time() < deadline:
        s, _ = http(port, "/health/live")
        if s == 200:
            return
        time.sleep(3)
    logs = subprocess.run(["docker", "logs", "--tail", "40", name], capture_output=True, text=True)
    raise SystemExit(f"{name} never became live: {(logs.stdout + logs.stderr)[-1500:]}")


def main():
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="qs_nologin_"))
    # the owner's case: a config that LOADS and carries the database, but no auth section
    (tmp / "config.json").write_text(json.dumps({
        "database": {"type": "sqlite"},
        "paths": {"db_file": "/app/data/qs_nologin.db"},
    }), encoding="utf-8")
    names = ["qs-proof-nologin-a", "qs-proof-nologin-b"]
    try:
        # ── A: nobody set a login type ────────────────────────────────────────
        start(names[0], 18091, tmp, {})
        s, body = http(18091, "/auth/config")
        cfg = json.loads(body) if s == 200 else {}
        check("A /auth/config answers", s == 200, (s, body[:200]))
        check("A the server says login is REQUIRED (type is not 'none')", cfg.get("type") not in (None, "", "none"), cfg)
        check("A the server says login is NOT CONFIGURED (the login page explains it)",
              cfg.get("not_configured") is True, cfg)
        for path in ROUTES:
            s, body = http(18091, path)
            check(f"A an anonymous {path} is refused (401), nothing shown", s == 401, (s, body[:160]))
        # EVERY GET route the server publishes (no path parameters), anonymously
        s, body = http(18091, "/openapi.json")
        spec = json.loads(body) if s == 200 else {"paths": {}}
        gets = sorted(p for p, m in spec.get("paths", {}).items() if "get" in m and "{" not in p)
        check(f"A the walk is not vacuous ({len(gets)} GET routes)", len(gets) > 200, len(gets))
        answered = {}
        for path in gets:
            s, body = http(18091, path)
            if s is not None and s < 400 and not _public(path):
                answered[path] = (s, body[:80])
        for k, v in sorted(answered.items()):
            print(f"   ANSWERED {k} {v[0]} {v[1][:70]!r}")
        check(f"A no route outside the public list answers an anonymous caller ({len(gets)} walked)",
              not answered, sorted(answered))
        logs = subprocess.run(["docker", "logs", names[0]], capture_output=True, text=True)
        text = logs.stdout + logs.stderr
        check("A the log says LOGIN REQUIRED but NOT CONFIGURED", "LOGIN REQUIRED but NOT CONFIGURED" in text)
        check("A no guest-admin mode was entered", "every request is a guest ADMIN" not in text
              and "SET ON PURPOSE" not in text)

        # ── B: the control -- 'none' chosen on purpose ────────────────────────
        start(names[1], 18092, tmp, {"QUERYSTUDIO_AUTH_TYPE": "none"})
        s, body = http(18092, "/auth/config")
        check("B (control) auth.type=none on purpose is reported as none",
              s == 200 and json.loads(body).get("type") == "none", (s, body[:200]))
        s, body = http(18092, "/auth/me")
        check("B (control) the deliberate no-login server answers the guest",
              s == 200 and json.loads(body).get("username") == "guest", (s, body[:200]))
        s, body = http(18092, "/api/connections")
        check("B (control) the same route A refused answers here (200)", s == 200, (s, body[:160]))
    finally:
        for n in names:
            subprocess.run(["docker", "rm", "-f", n], capture_output=True)
    left = subprocess.run(["docker", "ps", "-a", "--filter", "name=qs-proof-nologin", "--format", "{{.Names}}"],
                          capture_output=True, text=True).stdout.strip()
    check("nothing left running", not left, left)
    print(f"\n{sum(RES)}/{len(RES)} PASSED")
    sys.exit(0 if RES and all(RES) else 1)


if __name__ == "__main__":
    main()
