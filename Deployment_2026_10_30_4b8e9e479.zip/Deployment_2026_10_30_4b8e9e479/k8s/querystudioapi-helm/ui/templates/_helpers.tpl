{{- define "qs-ui.name" -}}
{{- default .Values.componentName -}}
{{- end -}}

{{- define "qs-ui.fullname" -}}
{{- include "qs-ui.name" . | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "qs-ui.labels" -}}
app.kubernetes.io/name: {{ include "qs-ui.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: ui
app.kubernetes.io/part-of: querystudio
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "qs-ui.selectorLabels" -}}
app.kubernetes.io/name: {{ include "qs-ui.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "qs-ui.routeHost" -}}
{{- if .Values.route.host -}}
{{- .Values.route.host -}}
{{- else -}}
{{- printf "%s-%s.%s-%s.apaas4.claude.intranet" (include "qs-ui.name" .) .Values.namespace .Values.cluster .Values.datacentre -}}
{{- end -}}
{{- end -}}

{{- define "qs-ui.apiUrl" -}}
{{- if .Values.config.apiUrl -}}
{{- .Values.config.apiUrl -}}
{{- else -}}
{{- printf "https://querystudio-api-%s.%s-%s.apaas4.claude.intranet" .Values.namespace .Values.cluster .Values.datacentre -}}
{{- end -}}
{{- end -}}

{{/*
2026-10-29 -- the reports and downloads pods were installed by deploy.sh in
every environment and received NO browser traffic: the SPA sends their paths
to them only when reportApiUrl / downloadApiUrl is set, and nothing set it.
A pod the environment deploys (config.reportsPod.enabled /
config.downloadsPod.enabled in env/<env>.yaml, the overlay every chart reads)
is now addressed by the host its own chart's Route derives -- the same
pattern as qs-rpt.routeHost / qs-dl.routeHost.  An explicit URL wins (a
Route given its own route.host must name it here too); neither = "" = every
call stays on apiUrl.
*/}}
{{- define "qs-ui.reportApiUrl" -}}
{{- if .Values.config.reportApiUrl -}}
{{- .Values.config.reportApiUrl -}}
{{- else if (.Values.config.reportsPod | default dict).enabled -}}
{{- printf "https://querystudio-reports-%s.%s-%s.apaas4.claude.intranet" .Values.namespace .Values.cluster .Values.datacentre -}}
{{- end -}}
{{- end -}}

{{- define "qs-ui.downloadApiUrl" -}}
{{- if .Values.config.downloadApiUrl -}}
{{- .Values.config.downloadApiUrl -}}
{{- else if (.Values.config.downloadsPod | default dict).enabled -}}
{{- printf "https://querystudio-downloads-%s.%s-%s.apaas4.claude.intranet" .Values.namespace .Values.cluster .Values.datacentre -}}
{{- end -}}
{{- end -}}
