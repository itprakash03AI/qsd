"""
Database models for query storage and download management
Using SQLAlchemy ORM with SQLite
"""

from sqlalchemy import create_engine, event as sa_event, text as sa_text
from core.table_prefix import canonical_prefix, prefix_matches, prefix_matches_any
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime, date, timezone, timedelta
from typing import Optional, List, Dict, Any, Tuple, Set
import json
import logging
import os
import re
import threading
from contextlib import contextmanager
from pathlib import Path
import sqlite3

# Python 3.12+ deprecates sqlite3's implicit default datetime/date
# adapters (scheduled for removal in a future Python).  Register the
# SAME conversions explicitly -- datetime -> isoformat(" "), date ->
# isoformat() -- so the stored text stays byte-identical to what the
# default adapters produced and the DeprecationWarning goes away.
# register_adapter() is process-global, so this one site covers every
# raw sqlite3 connection in the app.  (SQLAlchemy ORM columns never
# hit the adapter -- the SQLite dialect stringifies datetimes in its
# own bind processor -- but raw sa_text() parameters and raw sqlite3
# cursors do.)
sqlite3.register_adapter(datetime, lambda val: val.isoformat(" "))
sqlite3.register_adapter(date, lambda val: val.isoformat())

# Models extracted to core/db/models.py — import them here for backward compatibility
# Models extracted to core/db/models.py -- re-exported here so the
# long-standing ``from core.database import <Model>`` call sites keep
# working.  EXPLICIT since 2026-08-10: the wildcard form made every one
# of the 1,153 model-name USES in this file a ruff F405, which was 73%
# of the repo's entire lint total and buried 18 real defects underneath.
# Generated from core.db.models.__all__; a drift test keeps them equal.
from core.db.models import (  # noqa: F401
    AgentConfig, AgentDecisionLog, AgentRule, AggCacheEntry,  # noqa: F401
    AggCacheSuggestion, AggregationAwareness, AlertHistory, AlertRule,  # noqa: F401
    ApiAccessLog, ApiKey, ApiKeyRequest, AuditLog, BackgroundJobState,  # noqa: F401
    Base, BrainPruningMemo, BrainRouteOutcome, BurstJob, BurstTask,  # noqa: F401
    BusinessDataset, BusinessReport, BusinessReportAccessRequest,  # noqa: F401
    BusinessReportAsyncJob, BusinessReportCertificationRequest,  # noqa: F401
    BusinessReportGrant, BusinessReportPermissionEvent,  # noqa: F401
    BusinessReportShareToken, CalculatedMetric, CircuitBreakerState,  # noqa: F401
    CloudDeliveryConfig, ColumnLineageEntry, ColumnPolicy,  # noqa: F401
    ConditionalFormatRule, Connection, ConnectionAccess,  # noqa: F401
    ConnectionProfile, ConnectionProfileMapping, CustomBackgroundJob,  # noqa: F401
    Dashboard, DashboardShare, DashboardWidget, DataFlow,  # noqa: F401
    DataFlowApprovalRequest, DataFlowCustomStageType,  # noqa: F401
    DataFlowNotificationPolicy, DataFlowRun, DataFlowRunAnnotation,  # noqa: F401
    DataFlowRunStage, DataFlowSchedule, DataFlowStage,  # noqa: F401
    DataFlowStageType, DataFlowVariable, DataFlowWebhookTrigger,  # noqa: F401
    DataFreshness, DataQualityAlert, DataQualityResult, DataQualityRule,  # noqa: F401
    DatasetClass, DatasetColumn, DatasetRelationship, DeadLetterQueue,  # noqa: F401
    DeliveryHistory, DownloadFile, DrillHierarchy,  # noqa: F401
    DuckDBSubprocessCrash, EtlDependencyMapping, EtlDependencyTracking,  # noqa: F401
    EtlDependencyType, EtlPipelineConfig, EtlPipelineExecution,  # noqa: F401
    ExecutionCheckpoint, FederationExecution, FederationView,  # noqa: F401
    FeedCalendar, FeedConfig, FeedControlFileFormat, FeedExecution,  # noqa: F401
    FeedHoliday, FeedRowCountBaseline, FeedRun, IcebergBloomSidecar,  # noqa: F401
    IcebergColumnStatsSupplement, IcebergFileCache, IcebergFileStats,  # noqa: F401
    IcebergFreshnessReliability, IcebergManifestCache,  # noqa: F401
    IcebergMetadataContentCache, IcebergMetadataKeyCache, IcebergMirror,  # noqa: F401
    IcebergMirrorDualRunEvent, IcebergPrunabilityProfile,  # noqa: F401
    IcebergSnapshotCache, IcebergSnapshotFiles, IcebergSupplementBuild,  # noqa: F401
    IcebergWatcherChange, LineageSnapshot, LocalTable, LogicalTable,  # noqa: F401
    LogicalTableBinding, MaterializedIsland, MaterializedView,  # noqa: F401
    MergedDimension, NLConversation, NLFeedback, NLPattern,  # noqa: F401
    NLQueryHistory, NLSynonym, NotificationLog, PartitionCache,  # noqa: F401
    PassportCalibration, PendingNotification, PolicyBinding,  # noqa: F401
    PreDefinedCondition, PublishedApiAlertState, PublishedApiAlertThreshold, PublishedApiCallRollup,  # noqa: F401
    PublishedApiIngestHealth, PublishedApiRollupState,  # noqa: F401
    PublishedView, PublishedViewWebhook,  # noqa: F401
    QueryCacheEntry, QueryExecution, QueryJob, QueryPerformanceLog,  # noqa: F401
    QueryPruningHistory, QueryScanPlan, QueryShare, QueryUsageStat,  # noqa: F401
    PvBulkPrepareClaim, PvBulkPrepareJob, PvMaterialiseFlight,  # noqa: F401
    QueuedWaitCancel,  # noqa: F401
    QueryVersion, RLSPolicy, RateLimitWindow,  # noqa: F401
    ReconciliationEntity, ReconciliationRun,  # noqa: F401
    Report, ReportBookmark, ReportChangeLog, ReportComment,  # noqa: F401
    ReportEmbedToken, ReportFavorite, ReportFolder,  # noqa: F401
    ReportFolderAssignment, ReportInstance, ReportPDFConfig,  # noqa: F401
    ReportDependencyMapping, ReportReadinessRun, ReportReadinessSubject,  # noqa: F401
    ReportSlo, ReportSloBreach,  # noqa: F401
    ReportParameter, ReportSubscription, ReportTag, ReportTagAssignment,  # noqa: F401
    ReportView, RestQueryDef, ResultArtifact, RowLevelPolicy,  # noqa: F401
    RowSecurityAuditLog, SapTaskConfig, SavedQuery, Schedule,  # noqa: F401
    ScheduleRunStats, SchedulerLease, SchedulerLock, SchemaCache,  # noqa: F401
    SnapshotTracker, SparkConnectSession, SqlFile, SqlSavedQuery,  # noqa: F401
    SubscriptionDelivery, SuggestionCorrection, SuperAdmin,  # noqa: F401
    SystemAccount, SystemSetting, TableDescription, TableFavorite,  # noqa: F401
    TableLineageEntry, TaskQueue, UIComponentVisibility, UserDraft,  # noqa: F401
    UserGroup, UserGroupMember, UserPreference, UserSession,  # noqa: F401
    WatchedIcebergTable, WorkerHealthState, WorkerRegistration,  # noqa: F401
    DaemonHeartbeat, BackgroundJobTick,  # noqa: F401
    Workspace, WorkspaceMember  # noqa: F401
)

# Method mixins — extracted domain groups
from core.db.mixin_datasets import DatasetsMixin
from core.db.mixin_lineage import LineageMixin
from core.db.mixin_feeds import FeedsMixin
from core.db.mixin_user_groups import UserGroupsMixin
from core.db.mixin_feed_consumers import FeedConsumersMixin
from core.db.mixin_federation_views import FederationViewsMixin
from core.db.mixin_data_quality import DataQualityMixin
from core.db.mixin_super_admin import SuperAdminMixin
from core.db.mixin_webhooks import WebhooksMixin
from core.db.mixin_comments import CommentsMixin
from core.db.mixin_etl_pipelines import EtlPipelinesMixin
from core.db.mixin_reconciliation import ReconciliationMixin
from core.db.mixin_published_api import PublishedApiMixin
from core.db.mixin_release import ReleaseMixin
from core.db.mixin_component_health import ComponentHealthMixin
from core.db.mixin_row_security import RowSecurityMixin
from core.db.mixin_value_lists import ValueListsMixin
from core.db.mixin_user_drafts import UserDraftsMixin
from core.db.mixin_clockwork import ClockworkMixin
# 2026-09-28 -- business-date readiness on reports + report SLOs
from core.db.mixin_report_readiness import ReportReadinessMixin
from core.db.mixin_spark_job_reports import SparkJobReportsMixin
from core.roles import ADMIN_TIER_ROLES


# 2026-08-10 -- module logger.  ``logger`` was referenced at 12 sites and
# ``_init_log`` at 6 sites OUTSIDE ``__init__`` (where it is a LOCAL), with
# neither name ever bound at module level: every one of those calls raised
# ``NameError: name 'logger' is not defined``.
#
# All 18 sit inside ``except`` blocks, which is what made it invisible and
# what makes it worth fixing rather than silencing: the NameError REPLACED
# the exception being handled, so the operator saw a missing-name error from
# the error handler instead of the database failure it was reporting.  An
# error path that destroys the error is worse than no error path.
#
# Found by the pylint pass (E0602) once it was pointed at the right source
# root -- before that, an unresolvable ``core.*`` import buried these 18 real
# defects under 1,171 phantom ones from the wildcard import on line 18.
logger = logging.getLogger(__name__)


_DB_URL_CRED_RE = re.compile(r"://([^:/@]+)(:[^@/]*)?@")


def _mask_db_url(url: str) -> str:
    """Render a SQLAlchemy URL with both user AND password masked.

    Mask shape: ``scheme://***:***@host:port/db?...`` — preserves every
    diagnostic bit (driver, host, port, db, query string) while hiding
    creds.  For URLs without creds (sqlite:///, in-memory dialects), the
    input is returned unchanged.

    Falls back to the raw URL if the regex doesn't match — we'd rather
    log an unmasked URL once than swallow the only diagnostic we have.
    """
    def _sub(m):
        return "://***" + (":***" if m.group(2) else "") + "@"
    return _DB_URL_CRED_RE.sub(_sub, url, count=1)


# BF-407 — typed exception for system-account lookup failures so callers
# (credential_manager, agents, AWS portal client) can distinguish a DB
# error from a "not found" result.
class SystemAccountLookupError(RuntimeError):
    """Raised when get_system_account_raw fails for a non-"not found"
    reason (DB locked, table missing, file unreadable, etc.).  The
    original SQLAlchemy exception is chained as __cause__ for full debug.
    """


# ── Phase 149.10 — snapshot-change listener registry ────────────────────
#
# When ``update_watched_iceberg_sync`` detects a REAL snapshot roll
# (current != prior, not just a heartbeat), registered listeners get
# notified.  Used by the BrainFreshness module (core/brain_freshness.py)
# to dispatch a delta scan immediately instead of waiting for the next
# cron tick.  Listeners are best-effort: a listener exception NEVER
# blocks the watcher.
#
# Threading model: listeners are invoked synchronously from the watcher
# thread but each listener is responsible for spawning its own async
# work (e.g. ``ensure_fresh(..., blocking=False)``).  Listeners must
# return fast; long work belongs in a daemon thread.

import threading as _149_10_threading  # noqa: E402

_snapshot_change_listeners: list = []
_snapshot_change_listeners_lock = _149_10_threading.Lock()


def register_snapshot_change_listener(callback) -> None:
    """Register a ``callback(connection_id, bucket, table_prefix,
    old_snapshot_id, new_snapshot_id)`` to be invoked whenever a watched
    iceberg table's snapshot rolls forward.

    Idempotent: registering the same callable twice is treated as one
    registration (so re-running app startup in tests doesn't double-
    invoke listeners).
    """
    with _snapshot_change_listeners_lock:
        if callback not in _snapshot_change_listeners:
            _snapshot_change_listeners.append(callback)


def unregister_snapshot_change_listener(callback) -> bool:
    """Remove a previously-registered callback.  Returns True if found."""
    with _snapshot_change_listeners_lock:
        if callback in _snapshot_change_listeners:
            _snapshot_change_listeners.remove(callback)
            return True
        return False


def _fire_snapshot_change_listeners(
    *,
    connection_id: int,
    bucket: str,
    table_prefix: str,
    old_snapshot_id: Optional[str],
    new_snapshot_id: str,
) -> None:
    """Invoke every registered listener.  Exceptions are logged and
    swallowed so one bad listener can't block the watcher.

    ``old_snapshot_id`` is ``None`` for the FIRST snapshot a watched row
    ever records (2026-09-27) — a listener must treat that as a change."""
    with _snapshot_change_listeners_lock:
        listeners = list(_snapshot_change_listeners)
    for cb in listeners:
        try:
            cb(
                connection_id=connection_id,
                bucket=bucket,
                table_prefix=table_prefix,
                old_snapshot_id=old_snapshot_id,
                new_snapshot_id=new_snapshot_id,
            )
        except Exception as exc:
            try:
                logger.warning(
                    "[149.10] snapshot-change listener %r raised: %s",
                    getattr(cb, "__name__", str(cb)), exc,
                )
            except Exception:
                pass


class DatabaseManager(ValueListsMixin, ComponentHealthMixin, PublishedApiMixin, ReleaseMixin, SparkJobReportsMixin, ReportReadinessMixin, ClockworkMixin, UserDraftsMixin, RowSecurityMixin, EtlPipelinesMixin, ReconciliationMixin, CommentsMixin, WebhooksMixin, SuperAdminMixin, DataQualityMixin, FederationViewsMixin, FeedsMixin, UserGroupsMixin, LineageMixin, DatasetsMixin, FeedConsumersMixin):
    """Database manager for handling all database operations.

    Methods are organized via mixins:
    - LineageMixin: table/column lineage, snapshots, freshness, usage stats, NL, corrections, UI visibility
    - DatasetsMixin: datasets, federation, agg cache, business reports, parameters, subscriptions
    - SuperAdminMixin: break-glass admin accounts (Phase 107-D)
    - (remaining methods still inline — will be extracted incrementally)
    """

    # Shared migration dict — used by both SQLite and PostgreSQL migration methods.
    # Extend this whenever a new column is added to an existing model.
    _MIGRATIONS: dict = {
        # 2026-09-26 (F7 follow-up): the report-family discriminator on the
        # id-keyed enterprise tables.  NO server default on purpose: a row
        # that exists when the column arrives was written by a legacy-gated
        # route and must read as NULL (= legacy) for migrate_reports.py; the
        # ORM default stamps 'business' on everything written from now on.
        "report_bookmarks":         [("report_type", "VARCHAR(20)")],
        # 2026-10-29: the checkpoint heartbeat (core/checkpoint.py)
        "execution_checkpoints":    [("heartbeat_at", "FLOAT")],
        "report_pdf_configs":       [("report_type", "VARCHAR(20)")],
        "burst_jobs":               [("report_type", "VARCHAR(20)")],
        "alert_rules":              [("report_type", "VARCHAR(20)")],
        "conditional_format_rules": [("report_type", "VARCHAR(20)")],
        "legacy_report_migration_journal": [],   # fresh table
        "audit_log": [],
        # FB-45 (2026-09-20) -- a policy's composition class and the mode in
        # force on an audit row.  ONE key per table: a duplicate dict key
        # ships nothing and fails silently (tests/test_fb45_... pins it).
        "row_level_policies": [
            ("policy_class", "VARCHAR(20)"),
        ],
        "row_security_audit": [
            ("composition", "VARCHAR(20)"),
        ],
        # 2026-08-31 — author-curated dropdown values.  A new TABLE
        # self-creates; a new COLUMN does not, so it is declared here.
        "report_parameters": [
            ("static_values", "JSON"),
            # 2026-10-23 -- where a parameter's choices come from
            # (core/reports/param_values.py)
            ("values_source", "VARCHAR(20)"),
            # 2026-10-24 -- "values from another table"
            ("lov_source_connection_id", "INTEGER"),
            ("lov_source_table", "VARCHAR(500)"),
            ("lov_source_column", "VARCHAR(255)"),
            # 2026-10-24 -- values_source "list": a named value list
            ("value_list_id", "INTEGER"),
            # 2026-10-29 -- filter at the SOURCE: the key of a predicate in the
            # dataset's own SQL (core/source_filters.py)
            ("source_column", "VARCHAR(200)"),
        ],
        # 2026-10-24 -- value lists (core/value_lists.py); new tables self-create
        "value_lists": [],
        "value_list_items": [],
        "reports": [
            ("sql_saved_query_id",     "INTEGER"),
            ("sql_override",           "TEXT"),
            ("last_executed_at",       "TIMESTAMP"),
            ("cache_ttl_minutes",      "INTEGER DEFAULT 0"),
            ("schedule_config",        "JSON"),
            ("connection_override_id", "INTEGER"),
            ("workspace_id",           "INTEGER"),
        ],
        "schedules": [
            ("notify_emails",  "TEXT"),
            ("notify_webhook", "TEXT"),
            ("is_shared",      "BOOLEAN DEFAULT 0"),
            ("workspace_id",   "INTEGER"),
        ],
        "saved_queries": [
            ("is_favorite",       "BOOLEAN DEFAULT 0"),
            ("is_shared",         "BOOLEAN DEFAULT 0"),
            ("workspace_id",      "INTEGER"),
            ("folder",            "VARCHAR(200)"),
            ("tags",              "JSON"),
            ("param_definitions", "JSON"),   # Phase 86: runtime parameter definitions (JSON)
            ("release_key",       "VARCHAR(160)"),   # 2026-10-17: configuration-release identity
        ],
        "sql_saved_queries": [
            ("is_shared",    "BOOLEAN DEFAULT 0"),
            ("workspace_id", "INTEGER"),
            # 2026-10-04: cross-source UNION on the SQL page (NULL = join).
            ("combine_mode", "VARCHAR(20)"),
            ("release_key",  "VARCHAR(160)"),   # 2026-10-17: configuration-release identity
        ],
        # 2026-10-08 -- what the engine READ beside what the pruner KEPT
        # (core/query_diagnostic_store.record_files_read).  NULL = unknown.
        "query_pruning_history": [
            ("files_read",  "INTEGER"),
            ("read_reason", "VARCHAR(32)"),
        ],
        "connections": [
            ("is_shared",    "BOOLEAN DEFAULT 0"),
            ("created_by",   "VARCHAR(100)"),
            ("workspace_id", "INTEGER"),
        ],
        "dashboard_widgets": [
            ("release_key", "VARCHAR(160)"),   # 2026-10-17: configuration-release identity
        ],
        "dashboards": [
            ("created_by",   "VARCHAR(100)"),
            ("workspace_id", "INTEGER"),
            # 2026-09-25 -- dashboard-level filters (core/dashboard_params.py)
            ("filters",      "JSON"),
                    ("release_key", "VARCHAR(160)"),   # 2026-10-17: configuration-release identity
        ],
        "materialized_views": [
            ("workspace_id", "INTEGER"),
            # BF-430A — per-MV reader override (NULL = use global s3_readers config).
            ("reader_override", "VARCHAR(64)"),
        ],
        "local_tables": [
            ("workspace_id", "INTEGER"),
        ],
        "query_executions": [
            ("executed_by", "VARCHAR(100)"),
            ("files_metadata", "JSON"),
            # 2026-09-27 -- which engine answered (core/engine_attribution.py)
            ("engine", "VARCHAR(32)"),
        ],
        # 2026-09-15 -- the report a business-report execution belongs to;
        # /results/{exec_id} binds the URL's report_id to it (404 otherwise).
        "federation_executions": [
            ("report_id", "INTEGER"),
        ],
        "download_files": [
            ("created_by",     "VARCHAR(100)"),
            ("source_kind",    "VARCHAR(40)"),
            ("source_id",      "VARCHAR(64)"),
            ("source_dataset_id", "VARCHAR(32)"),
            ("rls_signature",  "VARCHAR(80)"),
            # 2026-09-03 — FR-DEL-10 feed-deliverable facts.  A new TABLE
            # self-creates through create_all; a new COLUMN does NOT, and
            # alembic is never invoked at runtime — so these four are
            # exactly as load-bearing as the model change above them.
            ("checksum",           "VARCHAR(128)"),
            ("checksum_algorithm", "VARCHAR(32)"),
            ("business_date",      "VARCHAR(10)"),
            ("build_id",           "VARCHAR(100)"),
        ],
        "query_shares": [
            ("created_by",  "VARCHAR(100)"),
        ],
        "dashboard_shares": [
            ("created_by",  "VARCHAR(100)"),
        ],
        "partition_cache": [
            ("s3_prefix", "VARCHAR(512) DEFAULT ''"),
        ],
        "worker_registry": [],  # fresh table, no migration columns needed
        "query_result_cache": [
            ("connection_id",      "INTEGER"),
            ("hit_count",          "INTEGER DEFAULT 0"),
            # Phase 104 — partition-aware cache invalidation
            ("source_fingerprint", "VARCHAR(64)"),
            ("source_tables_json", "JSON"),
        ],
        # Phase 104 — snapshot tracker (new table, no migration cols needed)
        "snapshot_tracker": [],
        # Phase 75 — Published Views API
        "published_views": [
            ("entitlement_mode",   "VARCHAR(10)"),  # 2026-10-24: data entitlement switch; NULL = the config default (2026-10-25)
            ("query_id",           "INTEGER"),            # Phase 75: FK → saved_queries.id
            ("connection_id",      "INTEGER"),            # Phase 75: FK → connections.id
            ("allowed_filters",    "JSON"),               # Phase 75: filterable columns (JSON)
            ("default_limit",      "INTEGER DEFAULT 1000"), # Phase 75: default row limit
            ("max_limit",          "INTEGER DEFAULT 50000"), # Phase 75: max row limit
            ("cache_ttl_seconds",  "INTEGER DEFAULT 300"), # Phase 75: cache TTL
            ("param_definitions",  "JSON"),               # Phase 80: runtime parameter definitions (JSON)
            ("allowed_ad_groups",  "JSON"),               # Phase 82: AD groups allowed to access (JSON)
            ("source_type",        "VARCHAR(20) DEFAULT 'saved_query'"),  # Phase 91
            ("business_report_id", "INTEGER"),            # Phase 91
            ("federation_view_id", "INTEGER"),            # Phase 93
            ("version",                "INTEGER DEFAULT 1"),   # Phase 98-D: auto-increment on query_config change
            ("query_hash",             "VARCHAR(64)"),         # Phase 98-D: SHA-256 of query_config JSON
            ("min_cache_age_seconds",  "INTEGER DEFAULT 60"),   # throttle guard (seconds) — prevents S3 hammering
            ("allow_cache_bypass",     "BOOLEAN DEFAULT 1"),   # consumers can always request fresh data
            ("cache_strategy",         "VARCHAR(20) DEFAULT 'ttl'"), # Phase 98-G: "ttl" | "live"
            ("sql_file_id",            "INTEGER"),                  # Phase 122C: FK → sql_files.id
            ("allowed_engine_connections", "JSON"),                 # Phase 146-A: JSON list[int] of connection_ids the PV consumer may pick via ?engine=. NULL = legacy behaviour (single connection_id).
            ("reader_override",        "VARCHAR(64)"),              # BF-430A: per-PV reader override (NULL = use snapshotted query_config / global config).
            # Phase 133-J — publish-time credential routing (curl-friendly).
            ("execution_connection_id", "INTEGER"),                   # publisher-picked execution connection. NULL = use query_config.connection_id (legacy).
            ("credential_mode",         "VARCHAR(20) DEFAULT 'consumer'"),  # consumer | publisher | shared
            ("publisher_username",      "VARCHAR(100)"),              # frozen at publish time; used when credential_mode='publisher'
            # 2026-10-17 -- the API lifecycle (core/published_api/lifecycle.py)
            ("api_lifecycle_status",     "VARCHAR(12)"),
            ("api_sunset_at",            "TIMESTAMP"),
            ("api_deprecation_note",     "TEXT"),
            ("api_successor",            "VARCHAR(220)"),
            ("api_lifecycle_changed_by", "VARCHAR(100)"),
            ("api_lifecycle_changed_at", "TIMESTAMP"),
        ],
        # Phase 81 — Business Reports enhancements
        # 2026-08-09 dataset self-service — group ownership (BusinessReport
        # owner_group_id parity) + admin certification governance.  Creating a
        # PRIVATE dataset is self-service; publishing and certifying stay
        # privileged, which is the anti-sprawl signal (many private models,
        # few certified shared ones).  WITHOUT these entries an EXISTING
        # install errors on business_datasets reads — fresh DBs are fine via
        # create_all, upgraded ones are not.
        "business_datasets": [
            ("owner_group_id", "INTEGER"),
            ("is_certified",   "BOOLEAN DEFAULT 0"),
            ("certified_by",   "VARCHAR(100)"),
            ("certified_at",   "TIMESTAMP"),
            # 2026-09-05 — dataset-level progressive-scan declaration.
            # Without this line the column exists only in the model and
            # never on a deployed pod: a SQL-mode dataset would 500 on
            # every read instead of gaining a knob.
            ("partition_config", "JSON"),
            # FB-49 (2026-09-20) -- the browser URL slug.  Nullable: the
            # table has rows; the backfill + unique index follow in
            # _ensure_dataset_slugs, which a bare ALTER cannot carry.
            ("slug",             "VARCHAR(220)"),
        ],
        "business_reports": [
            # 2026-09-20 -- the browser URL slug (nullable: rows exist; the
            # backfill + unique index follow in _ensure_report_slugs).
            # Merged into the EXISTING key -- see the note below.
            ("slug",               "VARCHAR(220)"),
            # 2026-09-18 -- the sample/demo flag behind the reports list's
            # Show-samples toggle.  Added to the EXISTING key: a second
            # "business_reports" entry elsewhere in this dict is silently
            # discarded (last key wins) and the column never ships.
            ("is_sample",          "BOOLEAN NOT NULL DEFAULT FALSE"),
            ("merged_dataset_column_ids", "JSON"),  # Phase 81: secondary dataset column IDs (JSON)
            ("is_certified",       "BOOLEAN DEFAULT 0"),           # Phase 85: report certification
            ("certified_by",       "VARCHAR(100)"),                # Phase 85
            ("certified_at",       "TIMESTAMP"),                   # Phase 85
            ("template_category",  "VARCHAR(100)"),                # Phase 85: template catalog
            ("cloned_from_id",     "INTEGER"),                     # Phase 85: cloned-from report ID
            ("data_source_type",   "VARCHAR(30) DEFAULT 'saved_query'"),  # Phase 93
            ("federation_view_id", "INTEGER"),            # Phase 93
            ("published_view_id",  "INTEGER"),            # Phase 100: FK → published_views.id
            # Phase 111: raw_sql source type (parametric report unification)
            ("raw_saved_query_id",      "INTEGER"),
            ("raw_sql_saved_query_id",  "INTEGER"),
            ("raw_sql_override",        "TEXT"),
            ("raw_parameters_schema",   "JSON"),       # JSON
            ("raw_schedule_config",     "JSON"),       # JSON
            ("raw_connection_override_id", "INTEGER"),
            ("legacy_report_id",        "INTEGER"),
            # Phase 131 deep-dive #10/#13: owner-group ACL for BusinessReport
            ("owner_group_id",          "INTEGER"),
            # Phase 131 deep-dive #13: SqlFile (published .sql) as report source
            ("raw_sql_file_id",         "INTEGER"),
            # 2026-10-17 -- the report's EXTERNAL-API lifecycle (the published_report
            # kind of the inventory, core/published_api/lifecycle.py)
            ("api_lifecycle_status",     "VARCHAR(12)"),
            ("api_sunset_at",            "TIMESTAMP"),
            ("api_deprecation_note",     "TEXT"),
            ("api_successor",            "VARCHAR(220)"),
            ("api_lifecycle_changed_by", "VARCHAR(100)"),
            ("api_lifecycle_changed_at", "TIMESTAMP"),
            # Phase 2 report-instance layer (2026-08-09) — BO "Refresh When
            # Open" parity.  0/NULL = serve latest instance when
            # business_reports.instance_serving_enabled is on; 1 = always
            # execute on open.
            ("refresh_on_open",         "BOOLEAN DEFAULT 0"),
            # 2026-08-11 cross-CONNECTION overrides for .sql-file-backed
            # reports.  Same names + types as sql_files and feed_configs so
            # the three read alike.  join_config MUST be declared "JSON", not
            # "TEXT": the model column is JSON and PostgreSQL has no
            # json->text assignment cast (tests/test_pg_dialect_audit).
            ("secondary_connection_id", "INTEGER"),
            ("combine_mode",            "VARCHAR(20)"),
            ("join_config",             "JSON"),
            # 2026-08-17 publish lifecycle — draft|published|archived|
            # deprecated.  Nullable, no default: NULL derives from
            # is_published at read time, so existing rows need no backfill.
            ("lifecycle_status",        "VARCHAR(20)"),
        ],
        # 2026-08-17 publish lifecycle — fresh table (created by create_all /
        # alembic 017), no migration columns needed.
        "business_report_versions": [],
        "api_keys": [
            ("encrypted_key", "VARCHAR(512)"),  # Fernet-encrypted raw key for admin retrieval
            # 2026-10-17 -- a key's FACE in the published-API inventory
            ("consumer",       "VARCHAR(200)"),
            ("owner_username", "VARCHAR(100)"),
            ("contact_email",  "VARCHAR(255)"),
        ],
        # 2026-10-17 -- who a requested key is FOR (copied onto the key at approval)
        # 2026-10-17 -- a key request's face (design §3.3); the table itself is
        # fresh (create_all).  The ONE entry for this table in the literal.
        "api_key_requests": [
            ("consumer",       "VARCHAR(200)"),
            ("contact_email",  "VARCHAR(255)"),
        ],
        # 2026-10-17 -- THE call record of every published API
        # (core/published_api/calls.py): the kind / id / slug, the consumer,
        # the endpoint, the cache status as a column, bytes, the refusal.
        # view_id goes NULLABLE through _migrate_api_access_log_view_id_nullable.
        "api_access_log": [
            ("api_kind",       "VARCHAR(30)"),
            ("api_id",         "INTEGER"),
            ("api_slug",       "VARCHAR(220)"),
            ("consumer",       "VARCHAR(200)"),
            ("auth_method",    "VARCHAR(20)"),
            ("endpoint",       "VARCHAR(40)"),
            ("format",         "VARCHAR(16)"),
            ("cache_status",   "VARCHAR(10)"),
            ("response_bytes", "BIGINT"),
            ("refusal",        "VARCHAR(40)"),
            ("pod",            "VARCHAR(64)"),
        ],
        # 2026-10-17 -- one row per access-log writer process (fresh table;
        # core/access_log_batcher.py, models.PublishedApiIngestHealth).
        "published_api_ingest_health": [],
        # 2026-10-17 -- the rollup buckets + their watermark (fresh tables;
        # core/published_api/rollup.py, models.PublishedApiCallRollup / RollupState).
        "published_api_call_rollups": [],
        "published_api_rollup_state": [],
        # 2026-10-17 -- alert thresholds (RELEASE rows) + each (threshold, API)'s
        # last verdict (fresh tables; core/published_api/alerts.py,
        # models.PublishedApiAlertThreshold / PublishedApiAlertState).
        "published_api_alert_thresholds": [],
        "published_api_alert_state": [],
        # Phase 76 — Feed File Generation
        # FR-DEP-08 (2026-09-02) — the upstream calendar that governs
        # a dependency.  Declared, not left to auto-migrate: a missing
        # column is a runtime "no such column" on every gate check.
        # FR-DEP-24 (2026-09-02) — the upstream's own row count, lifted
        # out of the message by the rule that named the field.  The table
        # itself self-creates, but a column added to an ALREADY-CREATED
        # table does not: without this entry the first arrival after the
        # deploy is a "no such column" on every insert.
        "dependency_events": [
            ("reported_rows", "BIGINT"),
            # 2026-10-08 -- WHICH declared source the arrival satisfies
            # (``kafka:<topic>``, ``iceberg:<bucket>/<prefix>``, a file
            # spec key).  NULL = for the dependency as a whole.  Without it
            # two Iceberg tables in one dependency were satisfied by the
            # first commit to either.
            ("source_key", "VARCHAR(500)"),
        ],
        "etl_dependency_mappings": [
            ("calendar_name", "VARCHAR(100)"),
            # FR-DEP-24 (2026-09-02) — the author's expected row count.
            # BIGINT, not INTEGER: an upstream position load is routinely
            # past 2,147,483,647 and this codebase has already taken a
            # production outage from an INTEGER counter overflowing.
            ("expected_rows", "BIGINT"),
            # 2026-09-27 — the DECLARED arrival sources and how they
            # combine (core/feed/arrival_sources.py).  NULL = no
            # declaration = the legacy any-evidence rule, so an existing
            # mapping changes nothing when the column arrives.
            ("arrival_sources", "JSON"),
            ("require_mode", "VARCHAR(10)"),
            # 2026-10-11 -- which SIDE of the feed this dependency's reported
            # row count certifies ('primary' / 'secondary'; NULL = none).
            # core/feed/reported_rows_certification.py judges it on both
            # lanes before any output.
            ("certifies_side", "VARCHAR(10)"),
            # 2026-10-15 -- does a new message of this dependency re-run a
            # delivered date (NULL = yes, the behaviour before;
            # core/feed/restatement.py).
            ("reruns_delivered", "BOOLEAN"),
        ],
        "feed_configs": [
            ("entitlement_mode",   "VARCHAR(10)"),  # 2026-10-24: data entitlement switch; NULL = the config default (2026-10-25)
            # Enterprise feed framework (Phase 130 — FEED_ENTERPRISE_PLAN.md)
            # Each column is additive + nullable so existing feed_configs
            # rows continue working unchanged; flag-driven activation
            # gates the new behaviour.
            # 2026-09-02 (FR-ID-01..03) — the editable LABEL, split from
            # ``name``, which is now identity: unique, bounded charset,
            # immutable once the feed has run.  Declared HERE and not
            # left to auto-migrate because a missing column is a runtime
            # "no such column" on every feed read (the system_accounts
            # lesson above), and the rename refusal is only acceptable
            # BECAUSE relabelling stays possible.
            ("display_name",            "VARCHAR(255)"),
            ("file_type_code",           "VARCHAR(100)"),
            # BF-473 (2026-05-19) — operator-facing categorization.
            # See FeedConfig.frequency_category in core/db/models.py
            # for vocabulary.  Indexed so the FeedTodayPage filter is
            # cheap on large feed sets.
            ("frequency_category",       "VARCHAR(50)"),
            ("priority",                 "INTEGER DEFAULT 5"),
            ("valid_from",               "DATE"),
            ("valid_until",              "DATE"),
            ("sla_from",                 "VARCHAR(20)"),
            ("sla_to",                   "VARCHAR(20)"),
            ("calendar_name",            "VARCHAR(100)"),
            ("action_condition_sql",     "TEXT"),
            ("control_file_template",    "VARCHAR(500)"),
            # Phase 130 hotfix-2 — cross-source feed support.  When
            # secondary_connection_id is set, _execute_native pulls
            # primary + secondary sides into temp parquets and combines
            # via core/executors/cross_source_combine.{union,join}.
            # The control file then describes the combined output.
            ("secondary_connection_id",  "INTEGER"),
            ("secondary_source_type",    "VARCHAR(50)"),
            ("secondary_source_id",      "INTEGER"),
            ("combine_mode",             "VARCHAR(20)"),
            ("join_config",              "JSON"),  # JSON
            # Phase 130 hotfix-4 — FK to feed_control_file_formats row.
            # NULL → use control_file_template + default field order
            # (existing behaviour preserved).  Non-null → DB-driven
            # field layout + checksum algorithm.
            ("control_file_format_id",   "INTEGER"),
            # Phase 130 hotfix-7 — group-based ownership.  When set,
            # any member of the named group can act on this feed in
            # addition to the individual created_by.  Null = single-
            # owner only (legacy behaviour).
            ("owner_group_id",           "INTEGER"),
            # 2026-09-02 — operational feed group (feed_groups.id), the
            # dashboard/action grouping axis, DISTINCT from the ACL
            # owner_group_id above.  Declared HERE because feed_configs
            # already exists on every deployed DB: the feed_groups TABLE
            # self-creates via create_all but a new COLUMN does not, and
            # alembic is never invoked at runtime — without this entry
            # every feed read after deploy is a runtime "no such column".
            # NULL = ungrouped (legacy rows unchanged).
            ("feed_group_id",            "INTEGER"),
            # 2026-09-05 — the feed pipeline STEP MODEL.  A feed names
            # ONE flow (feed_flows.id); the flow names the extra steps
            # and their parameters.  NULL = no flow, which is every
            # existing feed: it plans and records the engine spine and
            # runs EXACTLY as it does today.  Declared here because a
            # new COLUMN never reaches a deployed table via create_all
            # and alembic is not invoked at runtime.
            ("flow_id",                  "INTEGER"),
            # Phase 130 hotfix-13 — backend routing (auto/native/airflow)
            # + size-based handoff threshold for the "auto" router.
            ("execution_backend",        "VARCHAR(20) DEFAULT 'auto'"),
            ("size_threshold_rows",      "INTEGER"),
            # Phase 131 deep-dive #13 (round 8) — row-count tracker used
            # by the size-based router as a "previous run" estimate so
            # the backend choice converges over time without a costly
            # pre-flight COUNT(*).  Updated after each native execution.
            ("last_row_count",           "INTEGER"),
            ("estimated_row_count",      "INTEGER"),
            # 2026-09-02 (BRD §11 / §14.2) — multi-hop delivery chain
            # read by core/feed/delivery_hops.build_hop_plan.  Declared
            # HERE because feed_configs already exists on every deployed
            # DB: the table self-creates but a NEW COLUMN does not, and
            # alembic is never invoked at runtime — without this entry
            # the first feed read after the deploy is a runtime
            # "no such column".  NULL = legacy single-hop, unchanged.
            ("delivery_chain",           "JSON"),
            # BRD 2.1 (2026-09-02) — the five-kind schedule vocabulary.
            # Declared here for the same reason as every other entry:
            # feed_configs already exists on every deployed database, a
            # new COLUMN does not self-create, and alembic is never
            # invoked at runtime.
            ("schedule_declaration",     "JSON"),
            # 2026-09-03 (FR-SCH-06 / FR-SLA-01) — the SLA's explicit zone
            # and the declared-runtime fallback.  Until these existed the
            # decision ladder's fallback read a field on NO table, so
            # decision_deadline/warn_at were None on every production feed
            # and the "skip by 05:15 to make 06:00" alert could never fire.
            ("sla_timezone",             "VARCHAR(50)"),
            ("expected_runtime_seconds", "INTEGER"),
            # 2026-09-03 (FR-DEP-15) — row-count check shape: absolute
            # floor, asymmetric up/down tolerances, explicit expect-zero.
            # All nullable, no defaults: a feed with only the percentage
            # configured behaves exactly as before.
            ("row_count_min_rows",           "BIGINT"),
            ("row_count_threshold_pct_up",   "NUMERIC(5,2)"),
            ("row_count_threshold_pct_down", "NUMERIC(5,2)"),
            ("row_count_expect_zero",        "BOOLEAN"),
            # 2026-09-03 (FR-DEP-14) — maker/checker on dependency skips.
            # NULL/False = single approver (legacy, opt-in per feed).
            ("skip_requires_second_approver", "BOOLEAN"),
            # 2026-09-03 belt-and-braces — the Phase-131 control columns
            # were never declared here and relied entirely on the fail-open
            # auto-migrate sweep (which Oracle/MySQL deployments skip and
            # any earlier exception silently aborts).  Existence-guarded,
            # so on databases that already have them these are no-ops.
            ("etl_id",                    "INTEGER"),
            ("row_count_threshold_pct",   "NUMERIC(5,2)"),
            ("row_count_action",          "VARCHAR(20)"),
            ("integrity_check_enabled",   "BOOLEAN"),
            # 2026-09-28 -- the feed's CONSUMER groups (a JSON list of
            # user_groups ids): the audience of its delivery receipts on
            # the My Feeds page.  NULL = no declared consumers.
            ("consumer_group_ids",        "JSON"),
            # 2026-10-10 -- feed TEMPLATE membership (feed_templates): which
            # template rendered this feed and for which matrix row.
            ("template_id",               "INTEGER"),
            ("template_member_key",       "VARCHAR(255)"),
            # 2026-10-11 -- the feed's token BINDINGS (saved-query literal ->
            # {TOKEN}, per side), read by core/feed/sql_tokens.py on every lane.
            ("token_bindings",            "JSON"),
            # 2026-10-12 -- what the row-count check compares with
            # (baseline | previous), core/feed/variance_hold.py.
            ("row_count_compare_to",      "VARCHAR(20)"),
        ],
        "feed_executions": [
            # 2026-10-26 -- who cancelled the execution and when (the cancel
            # routes write them; files_metadata.cancel carries what the stop
            # reached at each source).
            ("cancelled_by",    "VARCHAR(100)"),
            ("cancelled_at",    "TIMESTAMP"),
            # Phase 130 hotfix-13 — per-stage observability columns.
            # Listed here for existing DBs that pre-date these fields;
            # fresh DBs get them via Base.metadata.create_all().
            ("stage_timings",   "JSON"),
            ("failed_stage",    "VARCHAR(50)"),
            # 2026-09-14 — the workload shape a spark_k8s run was
            # submitted as (spark_k8s.submit_mode=auto resolves it once).
            ("submit_mode",     "VARCHAR(24)"),
            # Phase 131 deep-dive #13 (round 16) — BQB-parity log+timeline.
            ("files_metadata",  "JSON"),
            # Foundation P (BRD 2026-09-02, FR-RUN-01/03) — build identity
            # + definition pin + reaper heartbeat.  All nullable: every
            # existing row stays valid; legacy creators write none of
            # these and keep the exact pre-P behaviour.
            ("business_date",     "DATE"),
            ("build_id",          "VARCHAR(40)"),
            ("pinned_version_id", "INTEGER"),
            ("pinned_git_commit", "VARCHAR(64)"),
            ("pinned_image_tag",  "VARCHAR(200)"),
            ("heartbeat_at",      "TIMESTAMP"),
            # 2026-10-07 -- the PRODUCED file on the shared output volume,
            # recorded whether or not it was delivered (a backfill without
            # delivery completed with no path anywhere; Download said 404).
            ("artifact_path",     "VARCHAR(1000)"),
            # 2026-10-07 -- the run's "do not deliver" decision, taken once
            # at creation and read by every lane (never re-derived).
            ("delivery_suppressed", "BOOLEAN"),
            # 2026-10-07 -- whether the EXECUTING pod streams the run's log
            # lines live ("live" | "none", core/feed/event_audience.py::
            # run_log_stream_of); NULL = unrecorded.  The UI's log view
            # reads it through ``run_log`` (core/feed/run_log_view.py).
            ("log_stream",        "VARCHAR(12)"),
        ],
        "feed_calendars": [
            # Phase 130 shipped this as a fresh table with no migration
            # columns.  FR-SCH-01 adds three (2026-09-03): a new TABLE
            # self-creates through create_all, a new COLUMN does not,
            # and alembic is never invoked at runtime.
            #
            # Added HERE rather than as a second "feed_calendars" entry
            # earlier in this dict: a duplicate key is LAST-WINS in
            # Python exactly as it is in a .properties file, so the
            # first attempt silently produced an EMPTY migration list
            # and no column would have been created.
            ("owner",       "VARCHAR(100)"),
            ("horizon_end", "DATE"),
            ("version",     "INTEGER DEFAULT 1"),
        ],
        # 2026-09-02 — operational feed groups.  Fresh table: self-creates
        # via create_all, so [] is the whole entry (the companion COLUMN
        # feed_configs.feed_group_id is declared above, where it must be).
        "feed_groups": [
            # 2026-09-27 -- the daily close-out digest's recipients.
            ("notification_email", "VARCHAR(500)"),
        ],
        # 2026-09-28 -- feed consumers (docs/FEATURE_STRATEGY_2026_09_28.html
        # #3).  The two tables feed_consumer_subscriptions /
        # feed_consumer_notices are fresh (create_all); the companion
        # COLUMN on feed_configs is declared in that table's own entry.
        "feed_consumer_subscriptions": [],
        "feed_consumer_notices": [],
        # 2026-10-12 -- which message fields IDENTIFY what a message is about
        # (a waiting dependency tile shows them; core/feed/message_fields.py)
        "feed_message_fields": [("identifies", "BOOLEAN")],
        # 2026-10-12 -- an Iceberg inspection says WHICH table and partition
        # (business event, system entity ...) and the data it saw there
        "iceberg_commit_inspections": [("table_name", "VARCHAR(512)"), ("partition_values", "JSON"),
                                       ("files_matched", "INTEGER"), ("rows_matched", "BIGINT")],
        "feed_holidays": [],             # fresh table (Phase 130)
        "feed_runs": [                   # fresh table (Phase 130) — daily SOD task table
            # 2026-10-26 -- who stopped the run and when.
            ("cancelled_by",      "VARCHAR(100)"),
            ("cancelled_at",      "TIMESTAMP"),
            # 2026-10-12 -- the lane a re-queued RE-RUN asked for.
            ("rerun_backend",     "VARCHAR(20)"),
            # 2026-10-12 -- re-run only the failed side: the kept side's record.
            ("rerun_reuse",       "JSON"),
            # Foundation P (BRD 2026-09-02) — see feed_executions above.
            ("build_id",          "VARCHAR(40)"),
            ("pinned_version_id", "INTEGER"),
            ("pinned_git_commit", "VARCHAR(64)"),
            ("pinned_image_tag",  "VARCHAR(200)"),
            ("pinned_at",         "TIMESTAMP"),
            ("heartbeat_at",      "TIMESTAMP"),
            # FR-OPS-06..09 (2026-09-02) — backfill run class.  Declared
            # HERE because a new COLUMN never reaches a deployed table via
            # create_all: a missing entry is a runtime "no such column" on
            # every feed-run read after deploy.
            ("run_type",          "VARCHAR(20)"),
            ("suppress_delivery", "BOOLEAN"),
            ("backfill_batch_id", "VARCHAR(40)"),
            # 2026-09-15 — the external trigger's Idempotency-Key (the
            # Clockwork fire key).  The partial UNIQUE index that goes with
            # it is created in _apply_postgresql_migrations below.
            ("idempotency_key",   "VARCHAR(320)"),
            # 2026-10-03 — ON COMPLETION OF: the upstream completion that
            # started a run (core/feed/upstream_completion.py).
            ("upstream_feed_name",    "VARCHAR(255)"),
            ("upstream_execution_id", "VARCHAR(100)"),
            ("upstream_feed_run_id",  "INTEGER"),
            # 2026-10-11 -- when the dependency gate released the run; the
            # queue worker's lookback is measured on it (and created_at).
            ("released_at",           "TIMESTAMP"),
        ],
        # Foundation P — fresh table (self-creates via create_all).
        "feed_definition_versions": [],
        # 2026-10-11 -- a DUE date SOD found with no run beyond its catch-up
        # window (fresh table, core/feed/sod_generator.py; models.FeedSodGap).
        "feed_sod_gaps": [],
        "feed_run_sql": [],
        # 2026-10-24 -- data entitlement (core/row_security/entitlement.py)
        "entitlement_dimensions": [],
        "entitlement_dimension_columns": [],
        "entitlement_values": [],
        "entitlement_uploads": [],
        # 2026-10-10 -- the parameterised feed template + its matrix (fresh
        # table; the two membership COLUMNS on feed_configs are above).
        # 2026-10-15 -- the WD1..WDn month end: the work-day window
        # (core/feed/restatement.py).
        "feed_restatement_policies": [
            ("window_workdays",    "INTEGER"),
        ],
        "feed_templates": [
            # 2026-10-10 (later) -- the apply as a JOB: the claim (one apply
            # at a time, a compare-and-swap on this column) and the job's
            # record (state, progress, heartbeat, the report) a poller on
            # any pod reads through GET /api/feed-templates/{id}/apply-status.
            ("apply_job_id",  "VARCHAR(64)"),
            ("apply_status",  "JSON"),
            # 2026-10-11 -- the template's auto-onboarding declaration
            # (core/feed/auto_onboard.py).
            ("auto_onboard",  "JSON"),
        ],
        # 2026-10-11 -- a new system entity a COMPLETE message named
        # (fresh table; core/feed/auto_onboard.py, models.FeedOnboardingRequest).
        "feed_onboarding_requests": [],
        # 2026-10-12 -- a file held for verification because its row count
        # moved beyond the threshold (fresh table; core/feed/variance_hold.py,
        # models.FeedVarianceHold).
        "feed_variance_holds": [],
        # 2026-10-17 -- THE alert road carries a SUBJECT that is not a feed
        # (core/feed/alert_subject.py): the alert row names its kind + key,
        # and a route may be scoped to a subject kind / one subject by key.
        "feed_alerts": [
            ("subject_kind", "VARCHAR(20)"),
            ("subject_key",  "VARCHAR(220)"),
        ],
        "feed_alert_routes": [
            ("scope_key",    "VARCHAR(220)"),
        ],
        # 2026-09-03 gap closure — three FRESH tables (self-create via
        # create_all; only a future new COLUMN on one of them would ever
        # need a row here):
        #   feed_runtime_profiles       — measured p95 runtime per feed
        #                                 (FR-SLA-01/05, the ladder's producer)
        #   feed_regeneration_decisions — replay-after-run decisions
        #                                 (FR-DEP-10/18/20)
        #   feed_skip_approvals         — maker/checker skip approvals
        #                                 (FR-DEP-14)
        "feed_runtime_profiles": [],
        "feed_regeneration_decisions": [],
        "feed_skip_approvals": [],
        # Foundation C (BRD 2026-09-02, §4.2/§9.3) — all FRESH tables
        # (self-create via create_all; a new TABLE needs no per-column
        # entry — only a new COLUMN on one of them ever will).
        "feed_file_runs": [],
        "connection_claims": [],
        "connection_concurrency_budgets": [],
        "feed_partition_declarations": [],
        # BRD §7.1 (step 6, 2026-09-02) — Kafka landing table.  Fresh
        # table: self-creates via create_all, so [] is the whole entry
        # (only a future new COLUMN on it would ever need a row here).
        "kafka_messages": [
            # 2026-10-25 -- the message tracker (core/feed/message_tracker.py)
            ("trk_business_date", "DATE"),
            ("trk_run_date",      "DATE"),
            ("trk_code",          "VARCHAR(200)"),
            ("trk_data_source",   "VARCHAR(200)"),
            ("trk_state",         "VARCHAR(60)"),
            ("trk_key",           "VARCHAR(64)"),
            ("trk_fields",        "TEXT"),
            ("trk_version",       "INTEGER"),
        ],
        # 2026-09-05 — feed pipeline steps (docs/FABLE_CONTEXT_STEPS…).
        # All FRESH tables: create_all makes them, so [] is the whole
        # entry.  They are listed rather than omitted so the next
        # person adding a column to one of them finds the place.
        "feed_step_types": [],
        "feed_custom_step_types": [],
        "feed_flows": [],
        "feed_flow_steps": [],
        "feed_run_steps": [],
        # BRD §15 — the deploy record.  2026-10-17 (config release): the
        # ledger row names the RELEASE that wrote it, what it did, and the
        # package checksum (core/release/engine.py).
        "config_deployments": [
            ("release_id",       "INTEGER"),
            ("action",           "VARCHAR(20)"),
            ("package_checksum", "VARCHAR(80)"),
        ],
        # 2026-10-17 -- fresh tables (create_all): the release header and
        # the environment mapping.  Declared so the coverage guard is honest.
        "config_releases": [],
        "release_mappings": [],
        # Phase 146-B — Logical Tables (multi-engine PV name bridge).
        # Fresh tables so no per-column migration entries needed; the
        # models are created via ``Base.metadata.create_all()`` in
        # ``_init_schema`` (see core/db/models.py::LogicalTable +
        # LogicalTableBinding).
        "logical_tables":            [],
        "logical_table_bindings":    [],
        "feed_control_file_formats": [], # fresh table (Phase 130 hotfix-4) — CTL format templates
        # Phase 130 hotfix-7 — entitlement groups
        "user_groups": [],               # fresh table — group definitions
        "user_group_members": [],        # fresh table — many-to-many user<->group
        # Phase 83 — Production Stability
        # 2026-09-28: the async run's wait-for-capacity state (see the model).
        "business_report_async_jobs": [
            ("waiting_for",   "VARCHAR(32)"),
            ("status_detail", "TEXT"),
        ],
        "circuit_breaker_states": [],     # fresh table
        "scheduler_lock": [],             # fresh table
        # Phase 2 report-instance layer (2026-08-09) — fresh table in
        # 514a65b4, but installs that ran that commit already HAVE it, so
        # every later column needs an entry here (house rule).  D1/D2
        # truncation-fidelity columns: all nullable, NO defaults — NULL is
        # the tri-state UNKNOWN for pre-fix rows and must stay NULL (a
        # DEFAULT 0/FALSE would stamp "definitely complete" onto rows whose
        # truncation state is unknowable — the exact lie the fix removes).
        "report_instances": [
            ("row_limit",           "INTEGER"),   # effective limit the run executed under
            ("truncated",           "BOOLEAN"),   # engine verdict; NULL = unknown
            ("unstable_truncation", "BOOLEAN"),   # no-ORDER-BY cut disclosure; NULL = unknown
        ],
        # 2026-09-28 -- commentary + sign-off on a report INSTANCE
        # (core/reports/signoff.py).  Both fresh tables; every later column
        # needs an entry here (house rule).
        "report_instance_signoffs": [],
        "report_instance_comments": [],
        # Phase 84 — NL Learning
        "nl_query_history": [],           # fresh table
        "nl_patterns": [],                # fresh table
        "nl_synonyms": [],                # fresh table
        # Phase 87 — System Accounts for auto-credential fetch
        # Phase 154 (2026-06-25) added 8 vault-resolver columns (use_vault
        # + secret_ref + secret_type + 5 vault_* URLs) to the SQLAlchemy
        # model.  Deep-dive #12 (2026-06-30) -- the operator hit runtime
        # "no such column: system_accounts.use_vault" because the
        # _MIGRATIONS entry stayed [].  ``_auto_migrate_from_models``
        # SHOULD add them on Postgres/SQLite but:
        #   * Oracle/MySQL DBs skip auto-migrate entirely (see docstring)
        #   * auto-migrate is fail-open -- ANY exception before this
        #     table is processed silently swallows the whole sweep
        #   * a rolling deploy on multi-pod can hit the read side before
        #     the write side has committed the ALTER
        # Explicit declarative entries here are the safety net: the
        # _MIGRATIONS sweep runs BEFORE auto-migrate, is per-table
        # transactional, and works on every dialect.  Every use_vault
        # entry uses ``NOT NULL DEFAULT 0`` server-default so SQLite's
        # ALTER-ADD-COLUMN limitation doesn't apply.
        "system_accounts": [
            ("use_vault",         "BOOLEAN NOT NULL DEFAULT 0"),
            ("secret_ref",        "VARCHAR(255)"),
            ("secret_type",       "VARCHAR(50)"),
            ("vault_auth_url",    "TEXT"),
            ("vault_role_name",   "VARCHAR(255)"),
            ("vault_role_type",   "VARCHAR(50)"),
            ("vault_secret_url",  "TEXT"),
            ("vault_rotate_url",  "TEXT"),
            # 2026-07-13 — ETL PARITY: AppRole / JWT-step-up ref fields.
            ("vault_step_up_name",          "VARCHAR(255)"),
            ("vault_step_up_auth_url",      "TEXT"),
            ("vault_approle_secret_id_url", "TEXT"),
            ("vault_approle_auth_url",      "TEXT"),
            ("vault_role_id",               "VARCHAR(255)"),
            # 2026-09-10 — Clockwork plan v2 §3.2.  FAIL-CLOSED default:
            # UNSPECIFIED is refused at fire time; it must never default
            # to NONPROD (a copied PROD row would read as non-prod).
            ("environment",                 "VARCHAR(20) NOT NULL DEFAULT 'UNSPECIFIED'"),
        ],
        # BF-410.4 — Scheduler lease (leader election).  Empty list because
        # the model now creates the table via Base.metadata.create_all();
        # listing it here tells the auto-migrate path the table is expected.
        "scheduler_lease": [],
        # Industrialization Phase 2 — PG job-queue substrate (fresh table;
        # created by Base.metadata.create_all from core.db.models.QueryJob;
        # future columns are additive-only and land via
        # _auto_migrate_from_models — rolling-deploy schema-skew rule).
        # Phase 5 (2026-07-23) — single-flight + fleet admission columns.
        # Explicit entries (not just auto-migrate) per the deep-dive #12
        # lesson: declarative migrations are the per-table transactional
        # safety net.  All NOT NULL columns carry server defaults so
        # SQLite's ALTER-ADD-COLUMN limitation doesn't apply.
        "query_jobs": [
            ("lane",               "VARCHAR(16) NOT NULL DEFAULT 'interactive'"),
            ("attached_to",        "VARCHAR(36)"),
            ("rls_fingerprint",    "VARCHAR(64) NOT NULL DEFAULT ''"),
            ("rls_key_shareable",  "BOOLEAN NOT NULL DEFAULT 0"),
            ("share_verified",     "BOOLEAN NOT NULL DEFAULT 0"),
            ("initiator_detached", "BOOLEAN NOT NULL DEFAULT 0"),
            ("admission_cost_mb",  "INTEGER NOT NULL DEFAULT 0"),
        ],
        # Industrialization Phase 6 (2026-07-23) — content-addressed result
        # artifacts (Arrow IPC in local FS / S3; metadata + refcount here).
        "result_artifacts": [],           # fresh table — create_all handles it
        # Phase 92 — Data Catalog v2
        "table_favorites": [],            # fresh table (model existed, now tracked in migrations)
        "table_descriptions": [],         # fresh table
        # Phase 93 — Multi-Source Federation Views
        # Phase 97 — Materialization state columns added to existing table
        "federation_views": [
            ("storage_path",      "VARCHAR(500)"),
            ("status",            "VARCHAR(30) DEFAULT 'virtual'"),
            ("last_materialized", "TIMESTAMP"),
            ("last_mat_duration", "FLOAT"),
            ("row_count",         "INTEGER"),
            ("column_count",      "INTEGER"),
            ("file_size_bytes",   "INTEGER"),
            ("last_error",        "TEXT"),
            ("schema_cache",      "JSON"),
            ("schema_cached_at",  "TIMESTAMP"),
        ],
        # Phase 99 — Data Quality Monitoring
        "dq_rules": [],               # fresh table
        # 2026-09-17 (FB-8b) -- the TABLE is fresh; this COLUMN is not, and
        # create_all never adds a column to an existing table.
        "dq_results": [
            ("outcome", "VARCHAR(16)"),
        ],
        # Phase 100 — Onboarding
        "user_preferences": [],       # fresh table
        # Phase 101 — Semantic Layer Enhancements
        "calculated_metrics": [],     # fresh table
        # Phase 102-E — Connection Access Control
        "connection_access": [],      # fresh table
        # Schema drift fix — report_favorites/report_views existed before report_type
        # column was added; older DBs need ALTER TABLE to add the missing column.
        "report_favorites": [
            ("report_type", "VARCHAR(20) DEFAULT 'parametric'"),
        ],
        "report_views": [
            ("report_type", "VARCHAR(20) DEFAULT 'parametric'"),
        ],
        # 2026-08-09 — reporting rewire Phase 5: RLS-aware aggregate cubes.
        # An aggregate may answer a row-security-scoped query only when the
        # caller's predicates can be APPLIED to it at its grain (the Power BI
        # rule); these columns are what let the serve path decide that.
        # NEW COLUMNS ON AN EXISTING TABLE — without these entries an upgraded
        # database raises "no such column" on the first cube routing pass.
        "agg_cache_entries": [
            ("rls_mode",                   "VARCHAR(20)"),   # open | security_dims | scoped
            # JSON (NOT "TEXT"): the model column is sqlalchemy JSON, and on
            # PostgreSQL+psycopg2 every bind for a JSON-typed column renders
            # ``%(...)s::JSON`` — PG has no json→text assignment cast, so a
            # column added here as TEXT makes EVERY agg_cache_entries INSERT
            # fail with DatatypeMismatch on an upgraded database (and reads
            # come back as str, not list).  SQLite treats the type name as an
            # affinity hint only — "JSON" is exactly what create_all renders
            # there too.  PG-dialect audit 2026-08-09; guard test:
            # tests/test_pg_dialect_audit_2026_08_09.py.
            ("security_dimension_col_ids", "JSON"),          # JSON: discriminator cols baked into GROUP BY
            ("policy_version",             "VARCHAR(80)"),   # content-derived fingerprint at build time
            ("rls_signature",              "VARCHAR(80)"),   # resolved-predicate signature for scoped entries
        ],
        # Phase 114 — Published API Hardening, DQ Alerting, NL Enhancement, Collaboration
        "published_view_webhooks": [],  # fresh table
        "dq_alerts": [],                # fresh table
        "nl_conversations": [],         # fresh table
        "report_comments": [],          # fresh table
        "report_change_log": [],        # fresh table
        # Phase 120 — Self-Healing Agents
        "agent_decisions": [],          # fresh table
        # Self-service API key request/approval workflow
        # api_key_requests: declared ONCE above (consumer / contact_email, 2026-10-17);
        # a second key in this literal would silently win and drop the earlier one.
        # BF-107 — Phase 124-B cross-connection columns for sql_files
        "sql_files": [
            ("secondary_connection_id",  "INTEGER"),
            ("combine_mode",             "VARCHAR(20)"),
            ("join_config",              "JSON"),
        ],
        # Spark Connect — per-user gRPC session audit
        "spark_connect_sessions": [],  # fresh table (no migration cols needed)
        # 2026-09-10 — Clockwork authoring plane (plan v2 §5).  Fresh
        # tables: create_all makes them; the entries exist so the FIRST
        # later column has a home.  The fire log and step tables are
        # CLOCKWORK-OWNED and are deliberately absent from this dict AND
        # from the models — core/clockwork/fire_log.py reflects them.
        # 2026-09-10 (integration) — the PROJECTION column: the definition
        # in the dispatcher core's grammar, derived by the row's one writer.
        # NULL = cannot dispatch; the dispatch view excludes it.
        "clockwork_jobs": [
            ("dispatch_definition", "JSON"),
        ],
        "clockwork_job_versions": [],
        # 2026-09-11 -- the template author's side-effect-free declaration
        # (audit remainder, item 3; models.ClockworkQueryTemplate).
        "clockwork_query_templates": [
            ("side_effect_free", "BOOLEAN DEFAULT 0"),
        ],
        "clockwork_task_types": [],
        "clockwork_deployments": [],
        "clockwork_settings": [],
        # 2026-09-10 (integration) — a manual request carries its OWN
        # identity fields and a projection snapshot, so the dispatch view
        # can project it and the dispatcher can rebuild its key.
        "clockwork_manual_requests": [
            ("tenant", "VARCHAR(40)"),
            ("scope", "VARCHAR(100)"),
            ("definition", "JSON"),
        ],
        "clockwork_alerts": [],
        # 2026-09-10 -- the delivery ledger beside the alerts (an alert is a
        # fact, a notification is a delivery; core/clockwork/notifier.py).
        "clockwork_alert_notifications": [],
        "clockwork_job_health": [],
        "clockwork_fire_resolutions": [],
        # 2026-10-10 -- how a plain-parquet mirror was built (flat /
        # hive_partition_by:<cols> / logical_manifest_only).  route_files
        # serves a row only when this DECLARES a physical COPY and at least
        # one data file was listed; NULL (pre-column rows) is unknown and
        # is not served.  core/plain_parquet_mirror.py.
        "iceberg_mirror_v1": [
            ("consolidation_mode", "VARCHAR(64)"),
        ],
        # 2026-10-10 -- the run lease a custom job's claim takes
        # (core/custom_jobs.py + claim_custom_job_run): set by the ONE
        # claim both the scheduler and POST .../run-now go through,
        # cleared when the run's outcome is recorded.  Two pods / two
        # clicks: one runs.
        "custom_background_jobs": [
            ("running_since", "TIMESTAMP"),
        ],
    }

    # 2026-08-09 metadata-scale audit finding 5 — list-pagination indexes on
    # business_reports, ONE definition shared by _apply_sqlite_migrations and
    # _apply_postgresql_migrations (they used to carry two copies of these
    # four statements).  Keep in sync with BusinessReport.__table_args__
    # (models.py).
    _BR_LIST_INDEX_SQL: tuple = (
        "CREATE INDEX IF NOT EXISTS ix_business_reports_updated_at "
        "ON business_reports(updated_at)",
        "CREATE INDEX IF NOT EXISTS ix_business_reports_name "
        "ON business_reports(name)",
        "CREATE INDEX IF NOT EXISTS ix_business_reports_published_updated "
        "ON business_reports(is_published, updated_at)",
        "CREATE INDEX IF NOT EXISTS ix_business_reports_owner_updated "
        "ON business_reports(owner, updated_at)",
    )

    # PostgreSQL-ONLY companion (PG-dialect audit 2026-08-09): the keyset
    # list orders by ``updated_at DESC NULLS LAST, id DESC``
    # (list_business_reports_page, mixin_datasets).  A default PG btree is
    # (ASC NULLS LAST); scanned backward it yields DESC NULLS FIRST — the
    # requested NULLS LAST ordering matches NEITHER direction, so the plain
    # ix_business_reports_updated_at above can never serve the ORDER BY on
    # PG and every page falls back to a top-N sort.  This index states the
    # exact ordering.  Not portable: SQLite rejects NULLS LAST inside CREATE
    # INDEX (and does not need it — SQLite's DESC index is natively
    # NULLS-last), hence a separate PG-only statement rather than a model
    # __table_args__ entry.
    _BR_KEYSET_INDEX_SQL_PG: str = (
        "CREATE INDEX IF NOT EXISTS ix_business_reports_keyset "
        "ON business_reports (updated_at DESC NULLS LAST, id DESC)"
    )

    def __init__(self, db_url: str = ""):
        """
        Initialize database manager.

        Supports SQLite (default), PostgreSQL, and Oracle backends.
        When type=postgresql and PG is unreachable, raises RuntimeError (no silent fallback).
        To switch to SQLite: set database.type=sqlite in config.json and restart.
        """
        import logging as _log
        _init_log = _log.getLogger(__name__)

        # An EXPLICIT db_url passed by the caller is an intentional override.
        _explicit_url = bool(db_url)

        # ── Resolve backend type from config (no hardcoded paths) ────────
        try:
            from core.config import database as _db_cfg
            db_type = _db_cfg.type
            if not db_url:
                db_url = _db_cfg.db_url  # resolves sqlite/postgresql/oracle from config
        except Exception as _cfg_exc:
            _init_log.warning("Could not load database config — falling back to SQLite: %s", _cfg_exc)
            db_type = "sqlite"
            _db_cfg = None
            if not db_url:
                db_url = "sqlite:///./data/parquet_query_engine.db"

        # An explicit sqlite:// URL from the caller WINS over ambient
        # config.database.type: constructing DatabaseManager("sqlite:///…")
        # must yield a SQLite manager even if global config says postgresql.
        # Without this, ambient config (or a test that left config.type=
        # postgresql) silently turns an explicitly-SQLite manager into the
        # postgresql branch — is_sqlite=False, engine ignores the given path.
        if _explicit_url and db_url.startswith("sqlite:"):
            db_type = "sqlite"
        # ...and the SAME must hold for an explicit PostgreSQL URL, for the
        # same reason.  It did not, and the asymmetry was invisible until
        # something passed one: with ambient config.database.type=sqlite,
        # DatabaseManager(db_url="postgresql://user:pw@host:5432/db") fell
        # through to the SQLite branch below, which treats db_url as a FILE
        # PATH — so the caller asked for a database and got
        # ``mkdir 'postgresql:\\user:pw@host:5432'`` (WinError 123).  The
        # branch is chosen by config TYPE, so an explicit URL of any dialect
        # has to say which branch it means.
        elif _explicit_url and db_url.startswith(("postgresql:", "postgres:")):
            db_type = "postgresql"

        is_sqlite = False
        is_postgresql = False

        # ``or _explicit_url``: when the caller HANDED us a postgresql:// URL
        # we do not need _db_cfg to have resolved one, and requiring it would
        # send a config-less caller (a script, a test) back to the SQLite
        # branch — the same silent-wrong-dialect bug this guard exists to stop.
        if db_type == "postgresql" and (_db_cfg or _explicit_url):
            # db_url was already resolved at line 409 by _db_cfg.db_url, which
            # honours the full BF-409 env-var ladder
            # (QUERYSTUDIO_DATABASE_URL / _CMD / _SECRET, then config.json
            # postgresql_url, then composed parts).  Do NOT re-override here
            # with _db_cfg.postgresql_url — that property only reads
            # config.json and would silently nuke an env-resolved URL,
            # forcing env-only K8s deploys into the SQLite fallback branch.
            is_postgresql = True
        elif db_type == "oracle":
            # Oracle path unchanged — db_url comes from _DatabaseCfg.db_url
            pass
        else:
            # SQLite (default)
            is_sqlite = True
            raw_path = db_url.replace("sqlite:///", "")
            db_path = Path(raw_path).resolve()
            _pre_existed = db_path.exists()
            _pre_size = db_path.stat().st_size if _pre_existed else 0
            _init_log.info(
                "SQLite DB path resolved: %s (pre-existing=%s, size=%d bytes, parent=%s, parent_exists=%s)",
                db_path, _pre_existed, _pre_size, db_path.parent, db_path.parent.exists(),
            )
            try:
                db_path.parent.mkdir(parents=True, exist_ok=True)
                _init_log.info("SQLite DB parent dir ready: %s (writable=%s)",
                               db_path.parent, os.access(db_path.parent, os.W_OK))
            except PermissionError as _perr:
                _init_log.error(
                    "SQLite DB parent dir NOT writable: %s (%s). "
                    "Fix: chown -R 1001:0 %s on the NFS server, or grant UID 1001 write access.",
                    db_path.parent, _perr, db_path.parent,
                )
                raise
            db_url = "sqlite:///" + db_path.as_posix()

        # ── Build engine kwargs per dialect ──────────────────────────────
        engine_kwargs: dict = {"pool_pre_ping": True}
        if is_sqlite:
            engine_kwargs["connect_args"] = {"check_same_thread": False}
            engine_kwargs["pool_size"] = 20
            engine_kwargs["max_overflow"] = 30
        elif is_postgresql and _db_cfg:
            # 2026-10-03 -- the pool sizes are the POD's share of Postgres
            # connections: an N-process server (main.run_server publishes N)
            # gives each process 1/N, so workers=2 does not double the pod's
            # connections against the server's max_connections.
            from core.process_topology import per_process_share as _pp_share
            engine_kwargs["pool_size"] = _pp_share(_db_cfg.postgresql_pool_size)
            # (<= 0 passes through unchanged: -1 is SQLAlchemy's "no
            # overflow limit", 0 is "none")
            engine_kwargs["max_overflow"] = _pp_share(_db_cfg.postgresql_max_overflow)
            engine_kwargs["pool_timeout"] = _db_cfg.postgresql_pool_timeout
        # 2026-10-03 -- on PostgreSQL a pooled connection is pinged only when
        # it has been IDLE longer than database.pool_ping_idle_seconds
        # (core/db/idle_ping.py says why that is safe for a failover); 0 keeps
        # SQLAlchemy's ping on EVERY checkout.  SQLite keeps pre-ping.
        _make_engine = create_engine
        if is_postgresql:
            from functools import partial as _partial
            from core.db import idle_ping as _idle_ping
            _make_engine = _partial(_idle_ping.create_engine, factory=create_engine)

        self.engine = _make_engine(db_url, **engine_kwargs)
        self.is_sqlite = is_sqlite
        self.is_postgresql = is_postgresql

        # ── BF-403 — slow-query event hook ───────────────────────────────
        # Logs any SQLAlchemy query that takes longer than the configured
        # threshold.  Threshold pulled from `database.slow_query_ms`
        # (default 1000 ms).  Set to 0 to log EVERY query at DEBUG —
        # useful for short-lived debugging, never leave on in production
        # (one log line per query → log volume balloons).
        #
        # Strictly safe to log:
        #   - statement TEMPLATE (with ? / :param placeholders, never literals)
        #   - elapsed ms
        # NOT logged:
        #   - parameter values (could contain PII / credentials)
        #   - result rows
        try:
            _slow_ms_threshold = 1000
            try:
                from core.config import get_section as _gs_db
                _slow_ms_threshold = int((_gs_db("database") or {}).get("slow_query_ms", 1000))
            except Exception:
                pass

            import logging as _logging
            import time as _t
            _sql_logger = _logging.getLogger("db.slow_query")

            @sa_event.listens_for(self.engine, "before_cursor_execute")
            def _t_start(conn, cursor, statement, parameters, context, executemany):
                context._qs_start_ts = _t.perf_counter()

            @sa_event.listens_for(self.engine, "after_cursor_execute")
            def _t_end(conn, cursor, statement, parameters, context, executemany):
                try:
                    _start = getattr(context, "_qs_start_ts", None)
                    if _start is None:
                        return
                    _ms = round((_t.perf_counter() - _start) * 1000.0, 1)
                    # Single-line, truncated to keep log volume sane.
                    # Statement is just the template — placeholders only.
                    _stmt = " ".join(str(statement).split())[:300]
                    # BF-412.1 — Suppress slow-query log for DDL statements.
                    # Migrations on a fresh Postgres can produce 50+ false-
                    # positive "slow query" warnings (CREATE TABLE / ALTER
                    # TABLE / CREATE INDEX are expected to take seconds).
                    # Skipping at WARNING level only; DEBUG mode still logs.
                    _upper_stmt = _stmt[:20].upper().lstrip()
                    _is_ddl = any(_upper_stmt.startswith(prefix) for prefix in (
                        "CREATE ", "ALTER ", "DROP ", "TRUNCATE ", "VACUUM",
                        "REINDEX", "ANALYZE", "PRAGMA",
                    ))
                    if _slow_ms_threshold > 0 and _ms >= _slow_ms_threshold and not _is_ddl:
                        _sql_logger.warning(
                            "[slow-query] %.1f ms  stmt=%s%s",
                            _ms, _stmt,
                            " (truncated)" if len(str(statement)) > 300 else "",
                        )
                    elif _slow_ms_threshold == 0:
                        _sql_logger.debug(
                            "[query] %.1f ms  stmt=%s%s",
                            _ms, _stmt,
                            " (truncated)" if len(str(statement)) > 300 else "",
                        )
                except Exception as _se:
                    # Telemetry must never break a real query
                    _sql_logger.debug("[slow-query] hook error: %s", _se)
        except Exception as _hook_err:
            # Don't crash startup if the hook setup itself fails
            import logging as _logging
            _logging.getLogger("db").warning(
                "Could not wire slow-query hook (%s) — queries will not be timed",
                _hook_err,
            )

        # ── SQLite-specific setup ────────────────────────────────────────
        if is_sqlite:
            # BF-408 — journal_mode + synchronous now config-driven.
            # On networked PVCs (NFS/GlusterFS/CephFS), WAL mode + NORMAL
            # sync is the standard recipe for "database disk image is
            # malformed" corruption.  Defaults preserved for local-disk
            # deploys; admins on network storage should set
            # database.sqlite_journal_mode='DELETE' +
            # database.sqlite_synchronous='FULL'.
            _journal_mode = "WAL"
            _sync_mode = "NORMAL"
            try:
                from core.config import get_section as _gs_sq
                _sq_cfg = _gs_sq("database") or {}
                _journal_mode = str(_sq_cfg.get("sqlite_journal_mode", "WAL") or "WAL").upper()
                _sync_mode = str(_sq_cfg.get("sqlite_synchronous", "NORMAL") or "NORMAL").upper()
            except Exception:
                pass
            # Validate against the SQLite-supported journal modes (silently
            # fall back to WAL on a typo — better than a corrupt DB).
            _VALID_JOURNAL = {"DELETE", "TRUNCATE", "PERSIST", "MEMORY", "WAL", "OFF"}
            _VALID_SYNC    = {"OFF", "NORMAL", "FULL", "EXTRA"}
            if _journal_mode not in _VALID_JOURNAL:
                _init_log.warning("Invalid sqlite_journal_mode=%r, falling back to WAL", _journal_mode)
                _journal_mode = "WAL"
            if _sync_mode not in _VALID_SYNC:
                _init_log.warning("Invalid sqlite_synchronous=%r, falling back to NORMAL", _sync_mode)
                _sync_mode = "NORMAL"

            # Networked-FS detection — emit a loud WARN if SQLite+WAL is
            # on NFS/Gluster/Ceph (the corruption recipe).
            try:
                from core.fs_detect import warn_if_unsafe_for_sqlite_wal
                warn_if_unsafe_for_sqlite_wal(str(db_path), _journal_mode)
            except Exception as _fs_err:
                _init_log.debug("[fs-detect] check skipped: %s", _fs_err)

            _init_log.info(
                "[sqlite] journal_mode=%s synchronous=%s busy_timeout=30000ms",
                _journal_mode, _sync_mode,
            )

            @sa_event.listens_for(self.engine, "connect")
            def _set_sqlite_pragmas(dbapi_conn, _conn_record):
                cursor = dbapi_conn.cursor()
                cursor.execute(f"PRAGMA journal_mode={_journal_mode}")
                cursor.execute(f"PRAGMA synchronous={_sync_mode}")
                cursor.execute("PRAGMA busy_timeout=30000")
                # 2026-07-02 -- Phase 146-B needs ON DELETE CASCADE to
                # fire on SQLite (default is OFF).  Without this, a
                # dropped logical_table leaves orphan bindings and a
                # dropped connection leaves orphan bindings both in
                # dev + prod SQLite deployments.  Postgres always
                # enforces FKs; this is a SQLite-specific safety.
                cursor.execute("PRAGMA foreign_keys=ON")
                # wal_autocheckpoint only meaningful in WAL mode
                if _journal_mode == "WAL":
                    cursor.execute("PRAGMA wal_autocheckpoint=1000")
                cursor.close()

            # BF-71: Ensure query_only is OFF when connections return to pool
            @sa_event.listens_for(self.engine, "checkin")
            def _reset_query_only(dbapi_conn, _conn_record):
                try:
                    cursor = dbapi_conn.cursor()
                    cursor.execute("PRAGMA query_only=OFF")
                    cursor.close()
                except Exception:
                    pass

            try:
                with self.engine.connect() as _conn:
                    _conn.execute(sa_text("PRAGMA wal_checkpoint(TRUNCATE)"))
                    _conn.commit()
                    _ic = _conn.execute(sa_text("PRAGMA integrity_check")).fetchone()
                    if _ic and _ic[0] != "ok":
                        raise RuntimeError(f"integrity_check failed: {_ic[0]}")
            except Exception as _db_err:
                _init_log.warning(
                    "SQLite DB corrupt or unreadable (%s) — backing up and recreating.", _db_err
                )
                self.engine.dispose()
                _ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                for _suffix in ("", "-wal", "-shm", "-journal"):
                    _f = Path(str(db_path) + _suffix)
                    if _f.exists():
                        _f.rename(_f.with_suffix(f".corrupt_{_ts}{_suffix}"))
                self.engine = create_engine(
                    db_url,
                    connect_args={"check_same_thread": False},
                    pool_pre_ping=True,
                    pool_size=20, max_overflow=30,
                )
                @sa_event.listens_for(self.engine, "connect")
                def _set_sqlite_pragmas_fresh(dbapi_conn, _conn_record):
                    cursor = dbapi_conn.cursor()
                    cursor.execute("PRAGMA journal_mode=WAL")
                    cursor.execute("PRAGMA synchronous=NORMAL")
                    cursor.execute("PRAGMA busy_timeout=30000")
                    # 2026-07-02 -- fresh-DB path also gets FK enforcement.
                    cursor.execute("PRAGMA foreign_keys=ON")
                    cursor.execute("PRAGMA wal_autocheckpoint=1000")
                    cursor.close()

                @sa_event.listens_for(self.engine, "checkin")
                def _reset_query_only_fresh(dbapi_conn, _conn_record):
                    try:
                        cursor = dbapi_conn.cursor()
                        cursor.execute("PRAGMA query_only=OFF")
                        cursor.close()
                    except Exception:
                        pass

        # ── PostgreSQL-specific setup ────────────────────────────────────
        # Auto-creates the database if PG server is reachable but DB doesn't
        # exist (like `airflow db init`). If PG server itself is unreachable,
        # fail fast so the pod crash-loops until PG is ready.
        if is_postgresql:
            # Log the full URL (password + user masked) so deploys can
            # confirm host/port/db/sslmode at a glance without leaking
            # credentials.  Also fixes the case where shell-expanded URLs
            # silently lose query params or pick up the wrong host.
            _init_log.info("PostgreSQL target URL: %s", _mask_db_url(db_url))
            try:
                with self.engine.connect() as _conn:
                    _conn.execute(sa_text("SELECT 1"))
                _init_log.info("PostgreSQL connection verified: %s",
                               db_url.split("@")[-1] if "@" in db_url else "(url masked)")
            except Exception as _pg_err:
                _pg_err_str = str(_pg_err).lower()
                # Check if the error is "database does not exist" — auto-create it
                if "does not exist" in _pg_err_str and "database" in _pg_err_str:
                    _init_log.warning(
                        "PostgreSQL database does not exist — auto-creating (like airflow db init)..."
                    )
                    _created = self._auto_create_pg_database(db_url)
                    if _created:
                        # Dispose the failed engine and rebuild with the new DB
                        self.engine.dispose()
                        self.engine = _make_engine(db_url, **engine_kwargs)
                        try:
                            with self.engine.connect() as _conn:
                                _conn.execute(sa_text("SELECT 1"))
                            _init_log.info("PostgreSQL database auto-created and verified.")
                        except Exception as _pg_err2:
                            self.engine.dispose()
                            raise RuntimeError(
                                f"PostgreSQL database was auto-created but connection still fails. "
                                f"Error: {_pg_err2}"
                            ) from _pg_err2
                    else:
                        # BF-409 — Auto-create failed (commonly: connecting user
                        # has no access to the 'postgres' system database, as is
                        # the case with managed Postgres like RDS-with-restricted-
                        # IAM, Crunchy Postgres operator, etc.).  Provide a clear
                        # actionable error WITHOUT crash-looping.
                        self.engine.dispose()
                        raise RuntimeError(
                            "PostgreSQL database does not exist AND auto-create failed.\n\n"
                            "Common cause: the connecting user has no access to the\n"
                            "'postgres' system database (typical for managed Postgres\n"
                            "with restricted IAM or operator-provisioned roles).\n\n"
                            "Two options:\n"
                            "  (1) Have a DBA pre-create the database:\n"
                            "        CREATE DATABASE querystudio;\n"
                            "        GRANT ALL PRIVILEGES ON DATABASE querystudio TO <user>;\n"
                            "  (2) Grant the user CREATE on the postgres system DB:\n"
                            "        GRANT CREATE ON DATABASE postgres TO <user>;\n\n"
                            f"Original error: {_pg_err}"
                        ) from _pg_err
                else:
                    self.engine.dispose()
                    _init_log.error(
                        "PostgreSQL connection failed: %s — database.type=postgresql but PG is unreachable. "
                        "Fix: ensure PG is running, or set database.type=sqlite in config.json to use SQLite.",
                        _pg_err,
                    )
                    raise RuntimeError(
                        f"PostgreSQL unreachable (database.type=postgresql). "
                        f"Set database.type=sqlite in config.json to switch to SQLite. Error: {_pg_err}"
                    ) from _pg_err

        # BF-409 — Postgres schema isolation: when database.postgresql_schema
        # is set, every connection runs SET search_path before any query so
        # the metadata tables live in that schema instead of public.  Also
        # CREATE SCHEMA IF NOT EXISTS at startup.  Enables multi-tenant
        # Postgres deployments (one DB, multiple schemas per tenant).
        if is_postgresql:
            _pg_schema = ""
            try:
                _pg_schema = str(getattr(_db_cfg, "postgresql_schema", "") or "").strip()
            except Exception:
                pass
            if _pg_schema:
                # Sanity-check schema name (no SQL injection — admin-controlled
                # config, but defense in depth)
                import re as _re
                if not _re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", _pg_schema):
                    raise RuntimeError(
                        f"Invalid postgresql_schema={_pg_schema!r}; must match "
                        r"^[A-Za-z_][A-Za-z0-9_]*$"
                    )
                # CREATE SCHEMA IF NOT EXISTS at startup
                try:
                    with self.engine.connect() as _conn:
                        _conn.execute(sa_text(f'CREATE SCHEMA IF NOT EXISTS "{_pg_schema}"'))
                        _conn.commit()
                    _init_log.info("PostgreSQL schema %r ready.", _pg_schema)
                except Exception as _sc_err:
                    _init_log.warning(
                        "Could not CREATE SCHEMA %r (may already exist or "
                        "no privilege): %s",
                        _pg_schema, _sc_err,
                    )
                # Install per-connection search_path
                @sa_event.listens_for(self.engine, "connect")
                def _set_search_path(dbapi_conn, _conn_record):
                    cursor = dbapi_conn.cursor()
                    try:
                        cursor.execute(f'SET search_path TO "{_pg_schema}", public')
                    finally:
                        cursor.close()

        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)

        # ── Read replica setup (Phase 43) ────────────────────────────────
        self._replica_engines: list = []
        self._replica_sessions: list = []
        self._replica_health: list = []
        self._replica_lock = __import__("threading").Lock()
        self._replica_index = 0
        self._replica_shutdown = __import__("threading").Event()

        if is_postgresql and _db_cfg:
            _rep_urls = _db_cfg.replica_urls
            # BF-409 — Apply same SSL mode + schema search_path to replicas
            _ssl_mode_rep = (getattr(_db_cfg, "postgresql_ssl_mode", "") or "").strip().lower()
            _schema_rep = (getattr(_db_cfg, "postgresql_schema", "") or "").strip()
            for _rep_url in _rep_urls:
                # Append SSL mode to replica URL if set and not already present
                if _ssl_mode_rep and _ssl_mode_rep != "prefer" and "sslmode=" not in _rep_url:
                    _sep = "&" if "?" in _rep_url else "?"
                    _rep_url_final = f"{_rep_url}{_sep}sslmode={_ssl_mode_rep}"
                else:
                    _rep_url_final = _rep_url
                try:
                    _rep_engine = _make_engine(
                        _rep_url_final,
                        pool_pre_ping=True,
                        pool_size=_db_cfg.replica_pool_size,
                        max_overflow=_db_cfg.replica_max_overflow,
                        pool_timeout=_db_cfg.replica_pool_timeout,
                    )
                    # Install search_path listener on the replica engine too
                    if _schema_rep:
                        import re as _re
                        if _re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", _schema_rep):
                            @sa_event.listens_for(_rep_engine, "connect")
                            def _set_replica_search_path(dbapi_conn, _conn_record):
                                cursor = dbapi_conn.cursor()
                                try:
                                    cursor.execute(f'SET search_path TO "{_schema_rep}", public')
                                finally:
                                    cursor.close()
                    with _rep_engine.connect() as _rc:
                        _rc.execute(sa_text("SELECT 1"))
                    self._replica_engines.append(_rep_engine)
                    self._replica_sessions.append(
                        sessionmaker(autocommit=False, autoflush=False, bind=_rep_engine)
                    )
                    self._replica_health.append(True)
                    _init_log.info("Read replica connected: %s",
                                   _rep_url.split("@")[-1] if "@" in _rep_url else "(masked)")
                except Exception as _rep_err:
                    _init_log.warning("Read replica failed to connect (%s): %s — skipping",
                                      _rep_url.split("@")[-1] if "@" in _rep_url else "(masked)", _rep_err)

            if self._replica_engines:
                self._replica_health_thread = __import__("threading").Thread(
                    target=self._replica_health_loop, daemon=True, name="replica-health"
                )
                self._replica_health_thread.start()
                _init_log.info("Read replica health checker started (%d replicas)", len(self._replica_engines))

        # Create tables (only creates tables that don't exist yet)
        _tables_before = 0
        if is_sqlite:
            try:
                with self.engine.connect() as _conn:
                    _tables_before = _conn.execute(
                        sa_text("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
                    ).scalar() or 0
            except Exception as e:
                _init_log.debug("Failed to count tables before schema creation: %s", e)
        _init_log.info("Running Base.metadata.create_all() — tables in DB before: %d", _tables_before)
        # 2026-10-28 -- qs_kafka_message is now a TABLE (the OG columns, core/db/models.py
        # QsKafkaMessage); a rig that ran 2026-10-27's read-only VIEW of that name drops it
        # first, or create_all would collide with it.  Never fatal.
        try:
            from core.feed.message_tracker import retire_kafka_message_view
            retire_kafka_message_view(self.engine)
        except Exception as _kmv_exc:
            _init_log.warning("the old qs_kafka_message view could not be dropped: %s", _kmv_exc)
        try:
            Base.metadata.create_all(bind=self.engine)
        except Exception as _ca_err:
            _init_log.error("Base.metadata.create_all() FAILED: %s", _ca_err, exc_info=True)
            raise
        if is_sqlite:
            try:
                with self.engine.connect() as _conn:
                    _tables_after = _conn.execute(
                        sa_text("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")
                    ).scalar() or 0
                _db_size = db_path.stat().st_size if db_path.exists() else 0
                _created = _tables_after - _tables_before
                if _created > 0:
                    _init_log.info(
                        "SQLite DB CREATED/UPDATED: %s (%d new tables, %d total, %d bytes)",
                        db_path, _created, _tables_after, _db_size,
                    )
                else:
                    _init_log.info(
                        "SQLite DB already initialized: %s (%d tables, %d bytes — no new tables created)",
                        db_path, _tables_after, _db_size,
                    )
            except Exception as _post_err:
                _init_log.warning("Post-create_all table count check failed: %s", _post_err)

        # Safe schema migration — add any columns that existing tables might
        # be missing when the schema is updated after initial creation.
        if is_sqlite:
            self._apply_sqlite_migrations()
        elif is_postgresql:
            self._apply_postgresql_migrations()
        try:
            # 2026-09-27 -- dependency_events.source gained 'iceberg_commit'.
            # A CHECK constraint on an EXISTING table is neither added by
            # create_all nor touched by the column sweep above, so the first
            # Iceberg-commit arrival on a deployed database would be refused
            # by the database while the Python vocabulary accepted it.
            self._migrate_dependency_events_source_check()
        except Exception as _ck_exc:
            _init_log.warning("dependency_events source CHECK migration "
                              "skipped: %s", _ck_exc, exc_info=True)
        try:
            # 2026-09-27 -- run_events.event_type gained two decision types
            # (a Run Now override, the WAIT escalation); same shape.
            self._migrate_run_events_type_check()
        except Exception as _ck_exc:
            _init_log.warning("run_events event_type CHECK migration "
                              "skipped: %s", _ck_exc, exc_info=True)
        try:
            # 2026-10-17 -- envelope encryption: in a SERVER process (the CLI
            # sets QS_DATA_KEYS_IN_DB) the first DatabaseManager binds THE
            # data-key store -- every component then encrypts with the data
            # keys in THIS database, opened by its master key (core/crypto.py).
            # Bound here, after create_all (the table exists) and before any
            # secret is written; once per process.
            if os.environ.get("QS_DATA_KEYS_IN_DB") == "1":
                from core import crypto as _crypto
                if _crypto._DATA_KEY_STORE is None:
                    from core.data_key_store import DataKeyStore
                    _crypto.bind_data_key_store(DataKeyStore(self))
        except Exception as _dk_exc:
            _init_log.error("encryption key: the data-key store could not be bound: %s",
                            _dk_exc, exc_info=True)
        try:
            # 2026-10-13 -- feed secrets are encrypted at rest (SecretJSON);
            # rows written before that still held PLAIN passwords.  Once per
            # start, idempotent: a row already encrypted is not touched.
            from core.secrets_at_rest import encrypt_stored_feed_secrets
            encrypt_stored_feed_secrets(self)
        except Exception as _sec_exc:
            _init_log.error("feed secrets: plain-text secrets could NOT be encrypted at "
                            "start-up: %s", _sec_exc, exc_info=True)
        # 2026-10-17 -- NO stored-credential sweep at start-up any more (it was
        # here since 2026-10-15).  Every component ran it: two API containers
        # resolving different keys rewrote each other's secrets in long
        # transactions and blocked on each other's row locks (the owner: "its
        # completely blocking").  Envelope encryption (core/crypto.py) makes
        # every component read the SAME data keys from the database, so there
        # is nothing to rotate at start; re-encrypting under the active data
        # key is an explicit admin job (POST /api/admin/encryption-key/
        # reencrypt: one process, a lock, batches).  What no key reads is
        # still NAMED by GET /api/admin/encryption-key.
        try:
            # 2026-10-10 -- kafka_messages.resolution gained 'unmatched'
            # (a templated rule rendered a dependency no feed declares).
            self._migrate_kafka_messages_resolution_check()
        except Exception as _ck_exc:
            _init_log.warning("kafka_messages resolution CHECK migration "
                              "skipped: %s", _ck_exc, exc_info=True)
        try:
            # 2026-10-17 -- config_deployments.object_type follows ONE
            # vocabulary (core/release/vocabulary.OBJECT_TYPES); a deployed
            # CHECK still spelling the old seven refuses every new kind.
            self._migrate_config_deployments_check()
        except Exception as _ck_exc:
            _init_log.warning("config_deployments object_type CHECK migration "
                              "skipped: %s", _ck_exc, exc_info=True)
        try:
            # 2026-10-17 -- a refused published-API call (before the view is
            # read) and a report's call have no view: the column goes nullable.
            self._migrate_api_access_log_view_id_nullable()
        except Exception as _vn_exc:
            _init_log.warning("api_access_log.view_id nullable migration skipped: %s",
                              _vn_exc, exc_info=True)
        try:
            # 2026-10-12 -- the environments + message tokens are DATA: a
            # fresh database starts with the seed rows, an edited one keeps
            # its rows (core/feed/environments.py, upstream_contract.py).
            self.seed_feed_contract_vocabulary()
            # 2026-10-12 -- restatement policies + alert kinds: DATA, seeded once
            self.seed_feed_alerting_vocabulary()
            # 2026-10-17 -- THE insert-missing-by-name seeder: a kind the seed
            # list gained after a database was first seeded (the component
            # kinds) lands in an already-seeded table; an edited row is never
            # touched.  seed_published_api_alerting below rides the same method.
            self.seed_missing_feed_alert_kinds()
            # 2026-10-17 -- the six published-API alert kinds (missing BY NAME --
            # a non-empty table gets them) + the default thresholds (empty table)
            self.seed_published_api_alerting()
            # 2026-10-12 -- a secret saved in plain text (a NESTED one, before
            # the at-rest rule walked nested settings) is encrypted now
            _enc_fixed = self.encrypt_plaintext_connection_secrets()
            if _enc_fixed:
                _init_log.warning("encrypted plain-text connection secrets at rest: connections %s",
                                  _enc_fixed)

        except Exception as _sv_exc:
            _init_log.warning("feed environments / message tokens seed skipped: %s", _sv_exc, exc_info=True)
        try:
            # 2026-10-12 -- a feed deactivated before deactivation closed its
            # never-started tasks left them pending ("No group" on the board).
            _closed = self.close_tasks_of_inactive_feeds()
            if _closed:
                _init_log.info("closed %d never-started task(s) of inactive feeds", _closed)
        except Exception as _cl_exc:
            _init_log.warning("closing inactive feeds' tasks skipped: %s", _cl_exc, exc_info=True)
        try:
            # 2026-09-20 -- every existing report gets its URL slug, then
            # the unique index (which a bare ALTER could not carry against
            # rows that had no slug yet).  Idempotent.
            self._ensure_report_slugs()
        except Exception as _slug_exc:
            _init_log.warning("report slug backfill skipped: %s", _slug_exc, exc_info=True)
        try:
            # FB-49 (2026-09-20) -- the same treatment for datasets: the
            # browser URL is /datasets/<slug>/query.  Separate try so a
            # failure on one entity cannot cost the other its backfill.
            # Idempotent.
            self._ensure_dataset_slugs()
        except Exception as _ds_slug_exc:
            _init_log.warning("dataset slug backfill skipped: %s",
                              _ds_slug_exc, exc_info=True)
        try:
            # FB-45 (2026-09-20) -- every row policy that predates policy
            # classes is stamped RESTRICTIVE explicitly, so its composed
            # result is byte-for-byte what it was before the upgrade.
            # Idempotent; only NULL classes are touched.
            self._ensure_policy_classes()
        except Exception as _cls_exc:
            _init_log.warning("row-policy class backfill skipped: %s", _cls_exc, exc_info=True)

        # 2026-08-20 — repair indexes whose DEPLOYED SHAPE drifted from the
        # model.  create_all() skips existing tables and every hand-written
        # bootstrap index uses CREATE INDEX IF NOT EXISTS, so NOTHING in the
        # startup path can correct an index that exists with the wrong
        # columns.  Alembic 019 can, but only where someone runs
        # `alembic upgrade head` — and migrations are not invoked from the
        # app, the compose files or the k8s manifests.  A repair that never
        # runs is not a repair.
        try:
            self._repair_drifted_indexes()
        except Exception as _ixr_exc:
            _init_log.warning("index shape repair skipped: %s", _ixr_exc)

        # 2026-08-09 metadata-scale audit (finding 6, perf half): trigram
        # GIN indexes so ilike '%q%' report search stops being two full
        # table scans on Postgres.  No-op on SQLite (documented in the
        # method); NEVER fatal at startup.
        try:
            self._ensure_search_trgm_indexes()
        except Exception as _trgm_exc:
            _init_log.warning("search trigram index setup skipped: %s", _trgm_exc)

        # Auto schema-drift detection: compare every SQLAlchemy model column to
        # the actual DB schema and ALTER TABLE for any missing column. Safety
        # net for the manual ``_MIGRATIONS`` dict — fail-open, never fatal.
        try:
            self._auto_migrate_from_models()
        except Exception as _auto_exc:
            _init_log.warning("Auto schema-drift detection failed: %s", _auto_exc, exc_info=True)

        # FR-OPS-10/12 (2026-09-02) — the priority DIRECTION migration is a
        # REINTERPRETATION, not a rewrite, and that decision is surfaced
        # here explicitly rather than left implicit.  Never fatal.
        try:
            self._log_feed_priority_direction_note()
        except Exception as _pd_exc:
            _init_log.warning("feed priority direction note skipped: %s", _pd_exc)

        # Deep-dive #12 (2026-06-30): explicit vault-column presence
        # check.  After migrations run, we verify the 8 vault columns
        # are ACTUALLY present on system_accounts (rather than trusting
        # migration success logs alone).  Logs a clear line the
        # operator can grep to confirm the fix landed, and if any
        # column is missing surfaces an actionable ALTER SQL they can
        # run manually.  This closes the loop the operator reported
        # ("looks like vault related columns are not added and its
        # failing for that") -- now they can `grep VAULT_COLUMN pod.log`
        # to see exactly what state the DB is in.
        try:
            self._verify_vault_columns_present()
        except Exception as _vc_exc:
            _init_log.warning("Vault-column presence check failed: %s", _vc_exc)

        # 2026-06-09 — widen query_result_cache.cache_key from VARCHAR(64)
        # to VARCHAR(128).  The model previously declared 64 but the
        # actual value (``base:`` prefix + 64-char sha256) is 69 chars.
        # Every cache write threw psycopg2.errors.StringDataRightTruncation.
        # Auto-migrate handles ADD COLUMN but not ALTER COLUMN TYPE, so
        # this widens explicitly.  Idempotent: only widens when current
        # type is < 128.  Same for source_fingerprint.
        try:
            self._auto_widen_cache_key_column()
        except Exception as _widen_exc:
            _init_log.warning(
                "cache_key column widen failed (cache writes may still "
                "truncate until manual ALTER): %s",
                _widen_exc, exc_info=True,
            )

        # Phase 132.28 — self-heal empty DataFlow tables that have schema
        # drift the SQLite auto-migrate cannot fix (NOT NULL columns added
        # to existing tables).  Safe because empty = no data loss.
        try:
            self._self_heal_empty_dataflow_tables()
        except Exception as _heal_exc:
            _init_log.warning("DataFlow self-heal failed: %s", _heal_exc, exc_info=True)

        # 2026-09-10 — the Clockwork DISPATCH PROJECTION: the two views the
        # scheduler's postgres backend reads (its jobs_table / manual_view),
        # projected from the authoring tables above.  create_all never makes
        # a view and alembic is never invoked, so they are (re)created HERE,
        # after the tables and the column migrations they select from.  The
        # helper never raises; a failure is logged at ERROR and reported by
        # /api/clockwork/health as "nothing dispatches, because ...".
        try:
            from core.clockwork.dispatch_views import ensure_views as _cw_ensure_views
            _cw_ensure_views(self.engine)
        except Exception as _cw_exc:
            _init_log.error("Clockwork dispatch projection setup failed: %s", _cw_exc,
                            exc_info=True)

        # 2026-09-11 -- the CLOCKWORK-OWNED DDL (the fire log, the step table
        # and every ALTER_* upgrade), applied from the INSTALLED clockwork
        # package's own sql/ directory in its declared manifest order.  Same
        # reason as the views: create_all makes neither, alembic is never
        # invoked, and the alternative is a psql step an operator meets two
        # commands later as a scheduler that refuses to start.
        #
        # The scheduler still PROVES that table and refuses rather than
        # creating it -- that refusal is what exactly-once rests on and it is
        # untouched.  Here, in the application that owns the database, the
        # decision to run a script is made by reading the catalogue against
        # the script's declared postcondition; nothing DROPs or rewrites.
        # Never fatal; a failure is an ERROR line naming the script and the
        # hand command, and /api/clockwork/schema says the same thing.
        try:
            from core.clockwork.schema_admin import ensure_schema as _cw_ensure_schema
            _cw_ensure_schema(self.engine, recorder=self.record_clockwork_schema_migration)
        except Exception as _cw_ddl_exc:
            _init_log.error("Clockwork DDL setup failed: %s", _cw_ddl_exc, exc_info=True)

    @staticmethod
    def _auto_create_pg_database(db_url: str) -> bool:
        """Auto-create the PostgreSQL database if it doesn't exist.

        Connects to the default ``postgres`` database on the same server,
        runs ``CREATE DATABASE <dbname>``, then disconnects.  This mirrors
        what ``airflow db init`` does — zero manual SQL needed.

        Returns True on success, False on failure (logged, never raises).
        """
        import logging as _logging
        _log = _logging.getLogger(__name__)
        try:
            from sqlalchemy import create_engine as _ce
            from sqlalchemy.engine import make_url
            _url = make_url(db_url)
            _target_db = _url.database
            if not _target_db:
                _log.error("Cannot auto-create PG database: no database name in URL")
                return False
            # Connect to the default 'postgres' database on the same server
            _admin_url = _url.set(database="postgres")
            _admin_engine = _ce(str(_admin_url), isolation_level="AUTOCOMMIT")
            try:
                with _admin_engine.connect() as _conn:
                    # Check if DB already exists (race-safe)
                    _exists = _conn.execute(
                        sa_text("SELECT 1 FROM pg_database WHERE datname = :db"),
                        {"db": _target_db},
                    ).fetchone()
                    if _exists:
                        _log.info("PostgreSQL database '%s' already exists.", _target_db)
                        return True
                    # CREATE DATABASE cannot run inside a transaction — that's why
                    # we use isolation_level=AUTOCOMMIT above.
                    _conn.execute(sa_text(f'CREATE DATABASE "{_target_db}"'))
                    _log.info("PostgreSQL database '%s' auto-created successfully.", _target_db)
                    return True
            finally:
                _admin_engine.dispose()
        except Exception as _exc:
            _log.error("Auto-create PostgreSQL database failed: %s", _exc, exc_info=True)
            return False

    def _log_feed_priority_direction_note(self):
        """FR-OPS-10 (2026-09-02) — make the priority-direction decision
        EXPLICIT at every boot that follows it.

        ``feed_configs.priority`` has documented "1-9, lower = higher
        priority" (the OG-ETL convention) since Phase 130, while the
        runtime served priority DESC and treated >= 8 as critical — the
        exact opposite.  The runtime now honours the documented
        direction (core/feed/claims.py is the single declaration).

        Stored values are REINTERPRETED, never rewritten: a feed saved
        at 8/9 was authored against the documented convention, so it
        always MEANT "least important" — it is now finally SERVED that
        way, and it is no longer critical.  A feed at 1/2 is now served
        first and IS critical.  This method logs the affected-row counts
        so an operator can see, per environment, which feeds change
        behaviour; it changes no data.
        """
        with self.get_session(read_only=True) as session:
            lowest = (session.query(FeedConfig.id)
                      .filter(FeedConfig.priority >= 8).count())
            critical = (session.query(FeedConfig.id)
                        .filter(FeedConfig.priority <= 2,
                                FeedConfig.priority.isnot(None)).count())
        import logging as _logging
        _plog = _logging.getLogger(__name__)
        msg = ("[priority] feed priority direction: 1 = HIGHEST "
               "(OG-ETL convention, authoritative since 2026-09-02; "
               "core/feed/claims.py).  Values are reinterpreted, not "
               "rewritten: %d feed(s) at 8-9 are now the LOWEST tier and "
               "no longer critical; %d feed(s) at 1-2 are now served "
               "first and ARE critical.")
        if lowest:
            _plog.warning(msg, lowest, critical)
        else:
            _plog.info(msg, lowest, critical)

    def _apply_sqlite_migrations(self):
        """Add columns that may be missing from older DB versions (SQLite only).

        Uses a raw sqlite3 connection (bypasses SQLAlchemy version differences)
        so this works identically with SQLAlchemy 1.x and 2.x.
        """
        import sqlite3 as _sqlite3
        db_file = str(self.engine.url).replace("sqlite:///", "")
        if not db_file or db_file == ":memory:":
            return

        import logging as _logging
        _mig_log = _logging.getLogger(__name__)
        try:
            con = _sqlite3.connect(db_file)
            cur = con.cursor()
            for table, columns in self._MIGRATIONS.items():
                try:
                    cur.execute(f"PRAGMA table_info({table})")
                    existing = {row[1] for row in cur.fetchall()}
                except Exception:
                    continue  # table doesn't exist yet — create_all will handle it
                for col_name, col_type in columns:
                    if col_name not in existing:
                        try:
                            cur.execute(
                                f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}"
                            )
                            _mig_log.info("Migration: added %s.%s (%s)", table, col_name, col_type)
                        except Exception as exc:
                            _mig_log.warning("Migration: failed to add %s.%s: %s", table, col_name, exc)
            # ── Index migrations (drop old + recreate with new columns) ─────
            # partition_cache: unique index must include s3_prefix (BF-15)
            try:
                cur.execute("PRAGMA table_info(partition_cache)")
                pc_cols = {row[1] for row in cur.fetchall()}
                if "s3_prefix" in pc_cols:
                    # Check if old index exists without s3_prefix — rebuild it
                    cur.execute("PRAGMA index_list(partition_cache)")
                    for idx_row in cur.fetchall():
                        idx_name = idx_row[1]
                        if idx_name == "ix_partition_cache_lookup":
                            cur.execute(f"PRAGMA index_info({idx_name})")
                            idx_cols = {row[2] for row in cur.fetchall()}
                            if "s3_prefix" not in idx_cols:
                                cur.execute("DROP INDEX IF EXISTS ix_partition_cache_lookup")
                                cur.execute(
                                    "CREATE UNIQUE INDEX ix_partition_cache_lookup "
                                    "ON partition_cache(connection_id, table_name, s3_prefix, scan_type)"
                                )
                                _mig_log.info("Migration: rebuilt ix_partition_cache_lookup with s3_prefix")
                            break
            except Exception as _idx_exc:
                _mig_log.warning("Index migration failed for partition_cache: %s", _idx_exc)

            # BF-ICEBERG-CACHE-ANY-CONN: add cache_id / object_key secondary
            # indexes so connection_id=None lookups (post-restart, untagged
            # client paths) use an index seek instead of a sequential scan.
            try:
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS ix_iceberg_metadata_key_cache_by_cache_id "
                    "ON iceberg_metadata_key_cache(cache_id)"
                )
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS ix_iceberg_metadata_content_cache_by_object_key "
                    "ON iceberg_metadata_content_cache(object_key)"
                )
                _mig_log.info("Migration: created BF-ICEBERG-CACHE-ANY-CONN secondary indexes (SQLite)")
            except Exception as _icc_idx_exc:
                _mig_log.warning("Iceberg cache secondary index migration failed: %s", _icc_idx_exc)

            # Industrialization Phase 5 — single-flight follower propagation
            # scan index (idempotent; existing DBs only — create_all covers
            # fresh ones).
            try:
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS ix_query_jobs_attached "
                    "ON query_jobs(attached_to)"
                )
            except Exception as _qj_idx_exc:
                _mig_log.warning("query_jobs attached index migration failed: %s",
                                 _qj_idx_exc)

            # 2026-08-09 metadata-scale audit finding 5 — list-pagination
            # indexes on business_reports (is_published / updated_at / name
            # had NO index; the paginated list keyset-sorts on
            # (updated_at, id) and filters is_published/owner).  Idempotent
            # + fail-open per statement: a failure only WARNs — startup can
            # never fail because of an index, the list just stays a scan.
            # Statements defined ONCE in _BR_LIST_INDEX_SQL (shared with the
            # PG path); keep in sync with BusinessReport.__table_args__.
            for _br_idx_sql in self._BR_LIST_INDEX_SQL:
                try:
                    cur.execute(_br_idx_sql)
                except Exception as _br_idx_exc:
                    _mig_log.warning("business_reports list-index migration "
                                     "failed (list falls back to scan): %s — %s",
                                     _br_idx_sql, _br_idx_exc)

            # ── Foundation P (2026-09-02, BRD §19 D6 / FR-RUN-01) ───────
            # Same create-new-then-drop-old swap as the PG path: the
            # one-active-per-FEED guard on feed_executions becomes three
            # partial indexes keyed on (feed_config_id, business_date,
            # build_id).  SQLite supports partial indexes since 3.8.
            # Live data is clean by construction (old guard was strictly
            # stricter; the new columns are NULL on every existing row).
            try:
                _p_new_exec = [
                    ("CREATE UNIQUE INDEX IF NOT EXISTS "
                     "ux_feed_executions_one_active_legacy "
                     "ON feed_executions (feed_config_id) "
                     "WHERE status IN ('pending','running') "
                     "AND business_date IS NULL"),
                    ("CREATE UNIQUE INDEX IF NOT EXISTS "
                     "ux_feed_executions_one_active_per_date "
                     "ON feed_executions (feed_config_id, business_date) "
                     "WHERE status IN ('pending','running') "
                     "AND business_date IS NOT NULL"),
                    ("CREATE UNIQUE INDEX IF NOT EXISTS "
                     "ux_feed_executions_identity "
                     "ON feed_executions "
                     "(feed_config_id, business_date, build_id) "
                     "WHERE build_id IS NOT NULL "
                     "AND business_date IS NOT NULL"),
                    ("CREATE UNIQUE INDEX IF NOT EXISTS "
                     "ux_feed_runs_one_per_feed_per_date_legacy "
                     "ON feed_runs (feed_config_id, business_date) "
                     "WHERE build_id IS NULL"),
                    ("CREATE UNIQUE INDEX IF NOT EXISTS "
                     "ux_feed_runs_identity "
                     "ON feed_runs (feed_config_id, business_date, build_id) "
                     "WHERE build_id IS NOT NULL"),
                ]
                for _p_stmt in _p_new_exec:
                    cur.execute(_p_stmt)
                # Old guard dropped only after every replacement exists —
                # the protection window never opens.
                cur.execute("DROP INDEX IF EXISTS "
                            "ux_feed_executions_one_active_per_feed")
                _mig_log.info("Migration: Foundation P run-identity indexes "
                              "in place (SQLite)")
            except Exception as _fp_idx_exc:
                _mig_log.error(
                    "Foundation P index swap failed on SQLite (%s) — the old "
                    "one-active-per-feed guard is kept; backfill/re-run of an "
                    "already-run date stays blocked on this DB.", _fp_idx_exc)
            # NOTE: a legacy SQLite file also carries the table-inline
            # UNIQUE(feed_config_id, business_date) constraint on feed_runs,
            # which SQLite cannot drop without a table rebuild.  On such a
            # file build-aware re-run rows are still refused; PostgreSQL
            # (every deployed pod) is fully migrated.  Fresh DBs get the
            # new shape from create_all().

            con.commit()
            con.close()
        except Exception as exc:
            _mig_log.error("SQLite migration failed: %s", exc, exc_info=True)

    @staticmethod
    def _pg_coltype(col_type: str) -> str:
        """SQLite-style migration DDL → PostgreSQL.  PG rejects an INTEGER
        default on a BOOLEAN column, and the NOT NULL may sit between the
        type and the DEFAULT, so the translation is substring-based (see
        the vault-column history in _apply_postgresql_migrations).  Pinned
        by tests/test_pg_dialect_audit_2026_08_09.py."""
        import re as _re
        if "BOOLEAN" in col_type.upper():
            col_type = _re.sub(r"(?i)\bDEFAULT\s+0\b", "DEFAULT FALSE", col_type)
            col_type = _re.sub(r"(?i)\bDEFAULT\s+1\b", "DEFAULT TRUE", col_type)
        return col_type

    @staticmethod
    def _json_columns_typed_as_text(inspector, existing_tables) -> list:
        """Return ``[(table, column)]`` for JSON model columns whose LIVE
        PostgreSQL type is text/varchar.

        Such a column makes every INSERT into its table fail: psycopg2
        renders ``%(x)s::JSON`` for a JSON-typed model column and PostgreSQL
        has no json→text assignment cast.  Only reachable on a database that
        received the column from a migration that declared it TEXT (fixed
        2026-08-10) — a fresh ``create_all`` always uses the model type.

        Pure and side-effect free so it is testable without a live PG.
        """
        import sqlalchemy as _sa
        from core.db.models import Base as _Base

        broken = []
        for table_name, t in _Base.metadata.tables.items():
            if table_name not in existing_tables:
                continue
            json_cols = {c.name for c in t.columns
                         if isinstance(c.type, _sa.JSON)}
            if not json_cols:
                continue
            try:
                live = {c["name"]: c for c in inspector.get_columns(table_name)}
            except Exception:
                continue
            for name in sorted(json_cols):
                col = live.get(name)
                if col is None:
                    continue            # not created yet — migration adds it
                tname = type(col["type"]).__name__.upper()
                if "JSON" in tname:
                    continue
                if any(k in tname for k in
                       ("TEXT", "VARCHAR", "CHAR", "STRING", "CLOB")):
                    broken.append((table_name, name))
        return broken

    @staticmethod
    def _int32_columns_needing_widening(inspector, existing_tables) -> list:
        """Return ``[(table, column)]`` for BigInteger model columns whose LIVE
        PostgreSQL type is still 32-bit (``integer`` / ``smallint``).

        Why this exists (2026-09-02).  Every measured byte- and row-counter in
        this schema was originally ``Integer``, which on PostgreSQL caps at
        2,147,483,647 -- i.e. **2 GB for a byte count**.  A feed that produces a
        file larger than that raises
        ``psycopg2.errors.NumericValueOutOfRange: integer out of range`` on the
        terminal UPDATE, so the run never reaches a terminal state at all: the
        real outcome is lost and the row is stranded.

        Widening the model alone CANNOT fix a deployed database.
        ``Base.metadata.create_all()`` creates missing tables and never alters
        existing ones, and alembic is not invoked at runtime -- so on every pod
        that already has these tables the column stays 32-bit until something
        issues an ``ALTER``.  That something is this method plus the repair
        below.

        Pure and side-effect free so it is testable without a live PostgreSQL.
        """
        import sqlalchemy as _sa
        from core.db.models import Base as _Base

        narrow = []
        for table_name, t in _Base.metadata.tables.items():
            if table_name not in existing_tables:
                continue
            big_cols = {c.name for c in t.columns
                        if isinstance(c.type, _sa.BigInteger)}
            if not big_cols:
                continue
            try:
                live = {c["name"]: c for c in inspector.get_columns(table_name)}
            except Exception:
                continue
            for name in sorted(big_cols):
                col = live.get(name)
                if col is None:
                    continue            # not created yet -- ADD COLUMN handles it
                tname = type(col["type"]).__name__.upper()
                # BIGINT is already correct.  Order matters: "BIGINTEGER"
                # contains "INTEGER", so the wide case must be excluded first.
                if "BIGINT" in tname:
                    continue
                if "INTEGER" in tname or tname in ("INT", "SMALLINT"):
                    narrow.append((table_name, name))
        return narrow

    def _apply_postgresql_migrations(self):
        """Add columns that may be missing from older DB versions (PostgreSQL).

        Uses SQLAlchemy inspect() for dialect-agnostic column introspection.
        """
        import logging as _logging
        _mig_log = _logging.getLogger(__name__)
        from sqlalchemy import inspect as sa_inspect

        # SQLite-style DDL → PostgreSQL.  PostgreSQL rejects an INTEGER default
        # on a BOOLEAN column (``BOOLEAN [NOT NULL] DEFAULT 0/1``).  The old
        # exact-string map missed ``BOOLEAN NOT NULL DEFAULT 0`` (the NOT NULL
        # sits between BOOLEAN and DEFAULT), so ``use_vault`` and the other 7
        # vault columns failed -- and because every ALTER shared ONE
        # transaction, that single failure aborted the txn and the final
        # commit rolled back EVERYTHING (all vault columns + the index
        # migrations).  Fix: translate the default on a substring basis, and
        # isolate each statement in a per-column SAVEPOINT with
        # ``ADD COLUMN IF NOT EXISTS`` -- exactly the proven pattern in
        # ``_auto_migrate_from_models``.  (Translation lives in the testable
        # staticmethod ``_pg_coltype`` — PG-dialect audit 2026-08-09.)
        _pg_coltype = self._pg_coltype

        # ``ADD COLUMN IF NOT EXISTS`` + the boolean-default translation are
        # PostgreSQL-only.  Guard on the ACTUAL engine dialect so the method is
        # correct even when a test drives it against a SQLite engine (SQLite
        # rejects ``IF NOT EXISTS`` on ADD COLUMN).
        is_pg = self.engine.dialect.name == "postgresql"
        _if_ne = " IF NOT EXISTS" if is_pg else ""

        try:
            inspector = sa_inspect(self.engine)
            existing_tables = set(inspector.get_table_names())

            with self.engine.connect() as conn:
                for table, columns in self._MIGRATIONS.items():
                    if table not in existing_tables or not columns:
                        continue
                    existing_cols = {c["name"] for c in inspector.get_columns(table)}
                    for col_name, col_type in columns:
                        if col_name in existing_cols:
                            continue
                        pg_type = _pg_coltype(col_type) if is_pg else col_type
                        try:
                            with conn.begin_nested():   # savepoint: one bad column can't abort the batch
                                conn.execute(sa_text(
                                    f"ALTER TABLE {table} ADD COLUMN{_if_ne} {col_name} {pg_type}"
                                ))
                            _mig_log.info("PG Migration: added %s.%s (%s)", table, col_name, pg_type)
                        except Exception as exc:
                            _msg = str(exc).lower()
                            if "duplicate column" in _msg or "already exists" in _msg:
                                _mig_log.debug("PG Migration: %s.%s already present", table, col_name)
                            else:
                                _mig_log.warning("PG Migration: failed to add %s.%s: %s", table, col_name, exc)
                # ── JSON-typed-as-text detection (2026-08-10) ───────────
                # Retyping _MIGRATIONS fixes every database that has yet to
                # RECEIVE these columns.  It cannot reach a database that
                # already carries them as text -- ADD COLUMN IF NOT EXISTS
                # skips those entirely -- and on PG that column makes every
                # INSERT fail with DatatypeMismatch (psycopg2 renders
                # ``%(x)s::JSON`` for a JSON model column; PG has no
                # json→text assignment cast).  Report it LOUDLY with the
                # exact repair rather than leaving it to be discovered as a
                # runtime 500.
                #
                # OPT-IN ONLY (QS_PG_JSON_AUTOREPAIR=1).  2026-08-10 audit:
                # "fix all open issues").  This was detection-only for one
                # revision because ``ALTER TABLE ... ALTER COLUMN TYPE``
                # rewrites the table under an ACCESS EXCLUSIVE lock.  That
                # concern is real but it is the SMALLER one: the alternative
                # is a table whose every INSERT raises DatatypeMismatch, i.e.
                # the feature is already down, and it stays down until someone
                # notices the log.  A lock during startup is a bounded outage;
                # a broken column is an unbounded one.
                #
                # Bounded and reversible in practice: each ALTER runs in its
                # OWN savepoint so one bad value cannot abort the migration
                # batch; the affected tables are metadata (reports, views,
                # schedules), not fact tables; and NULLIF(col,'') keeps a
                # legacy blank row -- which is NOT valid JSON -- from failing
                # the whole statement.
                #
                # QS_PG_JSON_AUTOREPAIR=0 skips the repair and logs the exact
                # statements instead, for an operator who wants a window.
                if is_pg:
                    _broken = []
                    try:
                        _broken = self._json_columns_typed_as_text(
                            inspector, existing_tables)
                    except Exception as _jexc:          # pragma: no cover
                        _mig_log.debug(
                            "JSON-as-text detection skipped: %s", _jexc)
                    if _broken:
                        _stmts = [
                            (t, c,
                             f"ALTER TABLE {t} ALTER COLUMN {c} "
                             f"TYPE json USING NULLIF({c}, '')::json")
                            for t, c in _broken
                        ]
                        _auto = os.environ.get(
                            "QS_PG_JSON_AUTOREPAIR", "0"
                        ).strip().lower() in ("1", "true", "yes", "on")
                        if not _auto:
                            _mig_log.error(
                                "PG SCHEMA REPAIR NEEDED (autorepair DISABLED "
                                "-- autorepair is OPT-IN): %d JSON "
                                "column(s) exist as text; every INSERT "
                                "touching them fails with DatatypeMismatch. "
                                "Run these in a maintenance window:\n%s",
                                len(_stmts),
                                "\n".join(f"  {s};" for _t, _c, s in _stmts),
                            )
                        else:
                            _mig_log.warning(
                                "PG SCHEMA REPAIR: %d JSON column(s) exist as "
                                "text (every INSERT touching them fails with "
                                "DatatypeMismatch).  Repairing now -- each "
                                "ALTER rewrites its table under an ACCESS "
                                "EXCLUSIVE lock (bounded to 3s by lock_timeout).  Unset "
                                "QS_PG_JSON_AUTOREPAIR to skip.", len(_stmts),
                            )
                            for _t, _c, _stmt in _stmts:
                                try:
                                    with conn.begin_nested():
                                        # An ALTER waiting on ACCESS
                                        # EXCLUSIVE also blocks every
                                        # SELECT that queues behind it
                                        # -- unbounded, mid pod-boot.
                                        conn.execute(sa_text(
                                            "SET LOCAL lock_timeout = '3s'"))
                                        conn.execute(sa_text(_stmt))
                                    _mig_log.warning(
                                        "PG repair: %s.%s text -> json", _t, _c)
                                except Exception as _rexc:
                                    _mig_log.error(
                                        "PG repair FAILED for %s.%s (%s) -- "
                                        "INSERTs into this table will KEEP "
                                        "failing.  Most likely a row holds a "
                                        "value that is not valid JSON; find "
                                        "it, fix it, then run:\n  %s;",
                                        _t, _c, _rexc, _stmt,
                                    )

                # ── 32-bit counter widening (2026-09-02) ────────────────
                # A measured byte/row counter left as 32-bit integer makes the
                # terminal UPDATE raise "integer out of range" the first time a
                # feed crosses 2 GB (or 2.1 bn rows), which strands the run
                # instead of failing it -- the outcome is never written at all.
                #
                # This runs unconditionally rather than behind an opt-in (as the
                # JSON repair does) because the failure it fixes is ALREADY
                # happening in production: a stranded terminal write is an
                # unbounded outage for that feed, while the ALTER is a bounded
                # one.  int -> bigint rewrites the table under ACCESS EXCLUSIVE,
                # so every statement is capped by lock_timeout and isolated in
                # its own savepoint; a column that cannot be taken now is logged
                # with the exact statement for a maintenance window and retried
                # on the next boot.  These are execution/metadata tables (one
                # row per run), not fact tables.
                if is_pg:
                    _narrow = []
                    try:
                        _narrow = self._int32_columns_needing_widening(
                            inspector, existing_tables)
                    except Exception as _nexc:          # pragma: no cover
                        _mig_log.debug(
                            "32-bit counter detection skipped: %s", _nexc)
                    if _narrow:
                        _mig_log.warning(
                            "PG SCHEMA REPAIR: %d counter column(s) are still "
                            "32-bit; a value above 2,147,483,647 (2 GB for a "
                            "byte count) fails the write with 'integer out of "
                            "range'.  Widening to bigint now.", len(_narrow),
                        )
                    for _t, _c in _narrow:
                        _stmt = (f"ALTER TABLE {_t} "
                                 f"ALTER COLUMN {_c} TYPE bigint")
                        try:
                            with conn.begin_nested():
                                # An ALTER waiting on ACCESS EXCLUSIVE also
                                # blocks every SELECT queued behind it --
                                # unbounded, mid pod-boot.
                                conn.execute(sa_text(
                                    "SET LOCAL lock_timeout = '3s'"))
                                conn.execute(sa_text(_stmt))
                            _mig_log.warning(
                                "PG repair: %s.%s integer -> bigint", _t, _c)
                        except Exception as _wexc:
                            _mig_log.error(
                                "PG repair FAILED for %s.%s (%s) -- writes of "
                                "a value above 2,147,483,647 to this column "
                                "will KEEP failing.  Run this in a maintenance "
                                "window:\n  %s;", _t, _c, _wexc, _stmt,
                            )

                # ── Feed-name uniqueness (2026-09-02, FR-ID-01) ─────────
                # ``feed_configs.name`` is indexed but NOT unique, so two
                # feeds can share a name.  The name is load-bearing in five
                # places that all assume uniqueness -- the Netcool AlertKey
                # and dedup Identifier, rendered filenames, the archive key
                # layout, git-backed definition filenames, and every support
                # conversation.  An index makes lookup fast; only a
                # constraint makes the name MEAN something.
                #
                # The API refuses a duplicate at authoring; this closes the
                # TOCTOU window where two concurrent creates both pass that
                # check.  Created ONLY when the live table is already clean:
                # a live database may hold duplicates from before the rule
                # existed, and refusing to start (or rewriting someone's feed
                # name) would be a far worse answer than reporting them.
                if is_pg and "feed_configs" in existing_tables:
                    try:
                        dupes = conn.execute(sa_text(
                            "SELECT lower(name) AS n, count(*) AS c "
                            "FROM feed_configs GROUP BY lower(name) "
                            "HAVING count(*) > 1"
                        )).fetchall()
                    except Exception as _dexc:
                        dupes = []
                        _mig_log.debug(
                            "feed-name duplicate scan skipped: %s", _dexc)
                    if dupes:
                        _mig_log.error(
                            "FEED NAME UNIQUENESS NOT ENFORCED: %d name(s) are "
                            "carried by more than one feed (%s).  A shared name "
                            "collapses two feeds into one console alert and lets "
                            "one overwrite the other's output file.  Rename the "
                            "duplicates, then restart to have the unique index "
                            "created.",
                            len(dupes), ", ".join(str(r[0]) for r in dupes[:10]),
                        )
                    else:
                        try:
                            with conn.begin_nested():
                                conn.execute(sa_text(
                                    "SET LOCAL lock_timeout = '3s'"))
                                conn.execute(sa_text(
                                    "CREATE UNIQUE INDEX IF NOT EXISTS "
                                    "ux_feed_configs_name_lower "
                                    "ON feed_configs (lower(name))"))
                            _mig_log.info(
                                "PG Migration: feed_configs name uniqueness "
                                "enforced (ux_feed_configs_name_lower)")
                        except Exception as _uexc:
                            _mig_log.warning(
                                "could not create ux_feed_configs_name_lower "
                                "(%s) — the API still refuses duplicates; only "
                                "the concurrent-create race stays open", _uexc)

                # ── Foundation P (2026-09-02, BRD §19 D6 / FR-RUN-01) ───
                # Replace the one-active-execution-per-FEED guard with
                # guards keyed on the new run identity
                # (feed_config_id, business_date, build_id).  ORDER
                # MATTERS: create the NEW indexes first, drop the OLD one
                # only after every new one exists — the protection window
                # never opens.  Live data is clean BY CONSTRUCTION for
                # each new index (the old guard was strictly stricter,
                # and the new columns are NULL on every existing row), so
                # no data scan is needed — but a create failure keeps the
                # old index in place and is logged with the exact
                # statement to run by hand.
                if is_pg and "feed_executions" in existing_tables:
                    _p_new_exec = [
                        ("CREATE UNIQUE INDEX IF NOT EXISTS "
                         "ux_feed_executions_one_active_legacy "
                         "ON feed_executions (feed_config_id) "
                         "WHERE status IN ('pending','running') "
                         "AND business_date IS NULL"),
                        ("CREATE UNIQUE INDEX IF NOT EXISTS "
                         "ux_feed_executions_one_active_per_date "
                         "ON feed_executions (feed_config_id, business_date) "
                         "WHERE status IN ('pending','running') "
                         "AND business_date IS NOT NULL"),
                        ("CREATE UNIQUE INDEX IF NOT EXISTS "
                         "ux_feed_executions_identity "
                         "ON feed_executions "
                         "(feed_config_id, business_date, build_id) "
                         "WHERE build_id IS NOT NULL "
                         "AND business_date IS NOT NULL"),
                    ]
                    _p_ok = True
                    for _p_stmt in _p_new_exec:
                        try:
                            with conn.begin_nested():
                                conn.execute(sa_text(
                                    "SET LOCAL lock_timeout = '3s'"))
                                conn.execute(sa_text(_p_stmt))
                        except Exception as _pexc:
                            _p_ok = False
                            _mig_log.error(
                                "Foundation P: could not create replacement "
                                "index (%s).  The old one-active-per-feed "
                                "index is KEPT so no protection is lost; "
                                "backfill/re-run of an already-run date "
                                "stays blocked until this runs cleanly:\n"
                                "  %s;", _pexc, _p_stmt)
                    if _p_ok:
                        try:
                            with conn.begin_nested():
                                conn.execute(sa_text(
                                    "SET LOCAL lock_timeout = '3s'"))
                                conn.execute(sa_text(
                                    "DROP INDEX IF EXISTS "
                                    "ux_feed_executions_one_active_per_feed"))
                            _mig_log.info(
                                "Foundation P: feed_executions guard now "
                                "keyed on (feed_config_id, business_date, "
                                "build_id) — D6 index replaced")
                        except Exception as _pdexc:
                            _mig_log.error(
                                "Foundation P: replacement indexes exist but "
                                "the old ux_feed_executions_one_active_per_"
                                "feed could not be dropped (%s) — the OLD "
                                "one-active-per-feed rule still applies.  "
                                "Run by hand:\n  DROP INDEX IF EXISTS "
                                "ux_feed_executions_one_active_per_feed;",
                                _pdexc)

                if is_pg and "feed_runs" in existing_tables:
                    _p_new_runs = [
                        ("CREATE UNIQUE INDEX IF NOT EXISTS "
                         "ux_feed_runs_one_per_feed_per_date_legacy "
                         "ON feed_runs (feed_config_id, business_date) "
                         "WHERE build_id IS NULL"),
                        ("CREATE UNIQUE INDEX IF NOT EXISTS "
                         "ux_feed_runs_identity "
                         "ON feed_runs (feed_config_id, business_date, "
                         "build_id) WHERE build_id IS NOT NULL"),
                    ]
                    _p_ok = True
                    for _p_stmt in _p_new_runs:
                        try:
                            with conn.begin_nested():
                                conn.execute(sa_text(
                                    "SET LOCAL lock_timeout = '3s'"))
                                conn.execute(sa_text(_p_stmt))
                        except Exception as _pexc:
                            _p_ok = False
                            _mig_log.error(
                                "Foundation P: could not create replacement "
                                "index (%s).  The old one-row-per-(feed,"
                                "date) constraint is KEPT so no protection "
                                "is lost.  Run by hand:\n  %s;",
                                _pexc, _p_stmt)
                    if _p_ok:
                        try:
                            with conn.begin_nested():
                                conn.execute(sa_text(
                                    "SET LOCAL lock_timeout = '3s'"))
                                conn.execute(sa_text(
                                    "ALTER TABLE feed_runs DROP CONSTRAINT "
                                    "IF EXISTS "
                                    "ux_feed_runs_one_per_feed_per_date"))
                                # Belt-and-braces: some historic DBs may
                                # carry it as a bare index instead.
                                conn.execute(sa_text(
                                    "DROP INDEX IF EXISTS "
                                    "ux_feed_runs_one_per_feed_per_date"))
                            _mig_log.info(
                                "Foundation P: feed_runs identity now "
                                "(feed_config_id, business_date, build_id)")
                        except Exception as _pdexc:
                            _mig_log.error(
                                "Foundation P: replacement indexes exist but "
                                "ux_feed_runs_one_per_feed_per_date could "
                                "not be dropped (%s) — re-run/backfill rows "
                                "for an existing date will still be "
                                "refused.  Run by hand:\n  ALTER TABLE "
                                "feed_runs DROP CONSTRAINT IF EXISTS "
                                "ux_feed_runs_one_per_feed_per_date;",
                                _pdexc)

                # 2026-09-15 — feed_runs.idempotency_key arbitration.  The
                # column above is added by the _MIGRATIONS sweep; the
                # partial UNIQUE index (one run per (feed, key)) is what
                # makes a replayed Idempotency-Key lose INSIDE the database
                # rather than by a read-then-write the route cannot make
                # atomic.  Guarded on the column being present so a
                # database where the ADD COLUMN failed logs that failure
                # and not a second, misleading one here.  The presence check
                # runs ON THIS CONNECTION: the ADD COLUMN above holds an
                # ACCESS EXCLUSIVE lock on feed_runs until this function's
                # commit, so a catalogue read through a SECOND connection
                # (``sa_inspect(self.engine)``) waits on our own lock -- seen
                # live 2026-09-15: one "idle in transaction" session blocked
                # every feed_runs reader in the estate for five minutes.
                if is_pg and "feed_runs" in existing_tables:
                    try:
                        _ik_present = conn.execute(sa_text(
                            "SELECT 1 FROM information_schema.columns "
                            "WHERE table_name = 'feed_runs' "
                            "AND column_name = 'idempotency_key'")).scalar()
                        if _ik_present:
                            with conn.begin_nested():
                                conn.execute(sa_text("SET LOCAL lock_timeout = '3s'"))
                                conn.execute(sa_text(
                                    "CREATE UNIQUE INDEX IF NOT EXISTS "
                                    "ux_feed_runs_idempotency_key ON feed_runs "
                                    "(feed_config_id, idempotency_key) "
                                    "WHERE idempotency_key IS NOT NULL"))
                            _mig_log.info("PG Migration: ux_feed_runs_idempotency_key in place")
                        else:
                            _mig_log.error(
                                "PG Migration: feed_runs.idempotency_key is ABSENT, so the "
                                "Idempotency-Key index was not created; a replayed external "
                                "trigger will start a second run until the column exists.  "
                                "Run by hand:\n  ALTER TABLE feed_runs ADD COLUMN "
                                "idempotency_key VARCHAR(320);")
                    except Exception as _ik_exc:
                        _mig_log.error(
                            "PG Migration: could not create ux_feed_runs_idempotency_key (%s).  "
                            "A replayed Idempotency-Key is then deduplicated by a read before "
                            "the insert only -- two concurrent replays can both start a run.  "
                            "Run by hand:\n  CREATE UNIQUE INDEX IF NOT EXISTS "
                            "ux_feed_runs_idempotency_key ON feed_runs (feed_config_id, "
                            "idempotency_key) WHERE idempotency_key IS NOT NULL;", _ik_exc)

                # ── Index migrations ────────────────────────────────────
                # partition_cache: unique index must include s3_prefix (BF-15)
                if "partition_cache" in existing_tables:
                    pc_cols = {c["name"] for c in inspector.get_columns("partition_cache")}
                    if "s3_prefix" in pc_cols:
                        try:
                            pc_indexes = inspector.get_indexes("partition_cache")
                            for idx in pc_indexes:
                                if idx["name"] == "ix_partition_cache_lookup":
                                    if "s3_prefix" not in idx.get("column_names", []):
                                        with conn.begin_nested():   # savepoint: don't roll back the columns above
                                            conn.execute(sa_text("DROP INDEX IF EXISTS ix_partition_cache_lookup"))
                                            conn.execute(sa_text(
                                                "CREATE UNIQUE INDEX ix_partition_cache_lookup "
                                                "ON partition_cache(connection_id, table_name, s3_prefix, scan_type)"
                                            ))
                                        _mig_log.info("PG Migration: rebuilt ix_partition_cache_lookup with s3_prefix")
                                    break
                        except Exception as _idx_exc:
                            _mig_log.warning("PG index migration failed for partition_cache: %s", _idx_exc)

                # BF-ICEBERG-CACHE-ANY-CONN: add cache_id / object_key secondary
                # indexes (idempotent — IF NOT EXISTS).  Without these, the
                # connection_id=None fallback lookups use a sequential scan
                # on Postgres, which negates the cache benefit.
                try:
                    with conn.begin_nested():   # savepoint: isolate from the column migrations
                        conn.execute(sa_text(
                            "CREATE INDEX IF NOT EXISTS ix_iceberg_metadata_key_cache_by_cache_id "
                            "ON iceberg_metadata_key_cache(cache_id)"
                        ))
                        conn.execute(sa_text(
                            "CREATE INDEX IF NOT EXISTS ix_iceberg_metadata_content_cache_by_object_key "
                            "ON iceberg_metadata_content_cache(object_key)"
                        ))
                    _mig_log.info("PG Migration: created BF-ICEBERG-CACHE-ANY-CONN secondary indexes")
                except Exception as _icc_idx_exc:
                    _mig_log.warning("PG iceberg cache secondary index migration failed: %s", _icc_idx_exc)

                # Industrialization Phase 5 — single-flight follower
                # propagation scan (leader terminal → attached followers).
                # Idempotent; new DBs get it from create_all, existing
                # deployments via this sweep.
                try:
                    with conn.begin_nested():
                        conn.execute(sa_text(
                            "CREATE INDEX IF NOT EXISTS ix_query_jobs_attached "
                            "ON query_jobs(attached_to)"
                        ))
                except Exception as _qj_idx_exc:
                    _mig_log.warning("PG query_jobs attached index migration "
                                     "failed: %s", _qj_idx_exc)

                # 2026-08-09 metadata-scale audit finding 5 — list-pagination
                # indexes on business_reports.  Idempotent; each in its own
                # SAVEPOINT so one failure never aborts the batch, and any
                # failure only WARNs (fail-open — the list falls back to a
                # scan).  Statements defined ONCE in _BR_LIST_INDEX_SQL;
                # keep in sync with BusinessReport.__table_args__.
                # On actual PostgreSQL the keyset ordering index is added —
                # the portable btrees cannot serve
                # ``ORDER BY updated_at DESC NULLS LAST, id DESC``
                # (see _BR_KEYSET_INDEX_SQL_PG).  Guarded on is_pg because
                # SQLite (which tests drive this method against) rejects
                # NULLS LAST inside CREATE INDEX.
                _br_idx_stmts = tuple(self._BR_LIST_INDEX_SQL)
                if is_pg:
                    _br_idx_stmts += (self._BR_KEYSET_INDEX_SQL_PG,)
                for _br_idx_sql in _br_idx_stmts:
                    try:
                        with conn.begin_nested():
                            conn.execute(sa_text(_br_idx_sql))
                    except Exception as _br_idx_exc:
                        _mig_log.warning(
                            "PG business_reports list-index migration failed "
                            "(list falls back to scan): %s — %s",
                            _br_idx_sql, _br_idx_exc)

                conn.commit()
        except Exception as exc:
            _mig_log.error("PostgreSQL migration failed: %s", exc, exc_info=True)

    #: Indexes whose DEPLOYED COLUMN LIST must match the model's, checked on
    #: every start.  Deliberately a short explicit list, not "every index":
    #: rebuilding an index is cheap but not free, and a UNIQUE rebuild has a
    #: failure mode (existing rows may violate a stricter key) that has to be
    #: handled per entry rather than assumed away.
    #:
    #: ``ix_iceberg_file_partition_seek`` earned its place.  A UAT database
    #: carried it WITHOUT ``file_path``:
    #:
    #:     duplicate key value violates unique constraint
    #:     "ix_iceberg_file_partition_seek"
    #:     DETAIL: Key (bucket, table_prefix, snapshot_id, part_key, part_value)=...
    #:
    #: Five columns instead of six asserts "at most ONE FILE per partition
    #: value", so the second file of every partition collided — permanently,
    #: because nothing in the startup path looks at an existing index's shape.
    _SHAPE_CRITICAL_INDEXES = ("ix_iceberg_file_partition_seek",)

    # ── 2026-09-27: dependency_events.source CHECK rewrite ─────────────────
    #
    # The ledger's source vocabulary is ONE tuple (models.DEPENDENCY_EVENT_
    # SOURCES) that builds both the Python refusal and the DDL CHECK.  A new
    # member reaches a NEW database through create_all and reaches an
    # EXISTING one through nothing at all: the column sweep adds columns, not
    # constraints.  So the first 'iceberg_commit' arrival on a deployed
    # estate would pass ledger.record_dependency_arrival's vocabulary check
    # and be REFUSED by the database -- logged as a failed write, arrival
    # lost, the feed waiting all night on data that had landed.
    #
    # PostgreSQL: drop + re-add the named constraint (a savepoint and a
    # 3s lock timeout, like every other DDL in this file).  SQLite cannot
    # drop a CHECK, so the table is rebuilt: rename, create the model's
    # current DDL, copy, drop.  Both are idempotent (the constraint text is
    # read first) and fail OPEN with the SQL to run by hand -- a failed
    # migration must never stop the API from booting.

    def _closed_vocabulary_check_is_current(self, conn, *, table_name: str,
                                            constraint: str,
                                            members: tuple) -> Optional[bool]:
        """True when the deployed CHECK on ``table_name`` admits every
        ``members`` value, False when it does not, None when it could not
        be read.  ONE probe for every closed-vocabulary CHECK (2026-09-27:
        dependency_events.source and run_events.event_type)."""
        try:
            if self.engine.dialect.name == "postgresql":
                ddl = conn.execute(sa_text(
                    "SELECT pg_get_constraintdef(c.oid) FROM pg_constraint c "
                    "JOIN pg_class t ON t.oid = c.conrelid "
                    "WHERE t.relname = :t AND c.conname = :c"),
                    {"t": table_name, "c": constraint}).scalar()
            else:
                ddl = conn.execute(sa_text(
                    "SELECT sql FROM sqlite_master WHERE type='table' "
                    "AND name=:t"), {"t": table_name}).scalar()
        except Exception as exc:
            logger.warning("%s CHECK could not be read: %s", table_name, exc)
            return None
        if not ddl:
            # No constraint at all (or no table): nothing refuses a value,
            # so there is nothing to rewrite.
            return True
        text = str(ddl)
        return all(f"'{s}'" in text for s in members)

    def _migrate_closed_vocabulary_check(self, *, table_name: str,
                                         column: str, constraint: str,
                                         members: tuple, model) -> bool:
        """Bring a closed-vocabulary CHECK up to the Python vocabulary.

        A CHECK constraint on an EXISTING table is neither added by
        create_all nor touched by the column sweep, so a value the Python
        vocabulary gained is refused by the database until this runs.
        PostgreSQL: drop/add the constraint.  SQLite: rebuild the table
        from the model DDL, keeping rows and indexes.  Idempotent.

        Returns True when the constraint is current afterwards (already was,
        or rewritten), False when it is not and the operator must act.
        """
        from sqlalchemy import inspect as sa_inspect
        # Read on its own connection: a read autobegins a transaction and
        # the rewrite below wants to OWN one (``engine.begin()``).
        with self.engine.connect() as conn:
            try:
                names = set(sa_inspect(conn).get_table_names())
            except Exception as exc:
                logger.warning("%s CHECK migration: tables unreadable: %s",
                               table_name, exc)
                return False
            if table_name not in names:
                return True
            current = self._closed_vocabulary_check_is_current(
                conn, table_name=table_name, constraint=constraint,
                members=members)
        if current is None:
            return False
        if current:
            return True
        member_sql = ", ".join(f"'{s}'" for s in members)
        if self.engine.dialect.name == "postgresql":
            try:
                with self.engine.begin() as conn:
                    conn.execute(sa_text("SET LOCAL lock_timeout = '3s'"))
                    conn.execute(sa_text(
                        f"ALTER TABLE {table_name} DROP CONSTRAINT "
                        f"IF EXISTS {constraint}"))
                    conn.execute(sa_text(
                        f"ALTER TABLE {table_name} ADD CONSTRAINT "
                        f"{constraint} CHECK ({column} IN ({member_sql}))"))
                logger.info("PG Migration: %s.%s CHECK now admits %s",
                            table_name, column, members)
                return True
            except Exception as exc:
                logger.error(
                    "PG Migration: %s.%s CHECK could not be rewritten (%s).  "
                    "Every '%s' row will be REFUSED by the database until it "
                    "is.  Run by hand:\n"
                    "  ALTER TABLE %s DROP CONSTRAINT IF EXISTS %s;\n"
                    "  ALTER TABLE %s ADD CONSTRAINT %s CHECK (%s IN (%s));",
                    table_name, column, exc, members[-1], table_name,
                    constraint, table_name, constraint, column, member_sql)
                return False
        # SQLite: rebuild.  Every statement in one transaction so a
        # failure part-way leaves the original table in place.
        table = model.__table__
        old = f"{table_name}__old"
        try:
            with self.engine.begin() as conn:
                # 2026-10-08 -- copy the columns the DEPLOYED table has, not
                # every column of the model: a column added to the model
                # after the deployed table was created (dependency_events.
                # source_key) made the copy fail with "no such column" and
                # the rebuild fail OPEN -- the new vocabulary member refused
                # for ever on exactly the databases this migration exists
                # for.  A model column the old table lacks is created by
                # ``table.create`` and left NULL, as the column sweep would.
                deployed = {row[1] for row in conn.execute(sa_text(
                    f"PRAGMA table_info({table_name})")).fetchall()}
                cols = ", ".join(c.name for c in table.columns
                                 if c.name in deployed)
                conn.execute(sa_text(f"ALTER TABLE {table_name} RENAME TO {old}"))
                for idx in conn.execute(sa_text(
                        f"PRAGMA index_list({old})")).fetchall():
                    idx_name = idx[1]
                    if not str(idx_name).startswith("sqlite_autoindex"):
                        conn.execute(sa_text(f'DROP INDEX IF EXISTS "{idx_name}"'))
                table.create(bind=conn)
                conn.execute(sa_text(
                    f"INSERT INTO {table_name} ({cols}) SELECT {cols} FROM {old}"))
                conn.execute(sa_text(f"DROP TABLE {old}"))
            logger.info("SQLite Migration: %s rebuilt; %s CHECK now admits %s",
                        table_name, column, members)
            return True
        except Exception as exc:
            logger.error(
                "SQLite Migration: %s could not be rebuilt for the new %s "
                "CHECK (%s).  '%s' rows will be refused by the database "
                "until the table is recreated with the current model DDL.",
                table_name, column, exc, members[-1])
            return False

    def _dependency_events_check_is_current(self, conn) -> Optional[bool]:
        from core.db.models import DEPENDENCY_EVENT_SOURCES
        return self._closed_vocabulary_check_is_current(
            conn, table_name="dependency_events",
            constraint="ck_dependency_events_source",
            members=DEPENDENCY_EVENT_SOURCES)

    def _migrate_dependency_events_source_check(self) -> bool:
        """dependency_events.source gained 'iceberg_commit' (2026-09-27)."""
        from core.db.models import DEPENDENCY_EVENT_SOURCES, DependencyEvent
        return self._migrate_closed_vocabulary_check(
            table_name="dependency_events", column="source",
            constraint="ck_dependency_events_source",
            members=DEPENDENCY_EVENT_SOURCES, model=DependencyEvent)

    def _run_events_check_is_current(self, conn) -> Optional[bool]:
        from core.db.models import RUN_EVENT_TYPES
        return self._closed_vocabulary_check_is_current(
            conn, table_name="run_events",
            constraint="ck_run_events_event_type", members=RUN_EVENT_TYPES)

    def _migrate_run_events_type_check(self) -> bool:
        """run_events.event_type gained 'dependencies_overridden' (a Run Now
        that went although the gate said not met) and
        'dependency_wait_escalated' (the 48 h escalation) on 2026-09-27."""
        from core.db.models import RUN_EVENT_TYPES, RunEvent
        return self._migrate_closed_vocabulary_check(
            table_name="run_events", column="event_type",
            constraint="ck_run_events_event_type",
            members=RUN_EVENT_TYPES, model=RunEvent)

    def _kafka_messages_check_is_current(self, conn) -> Optional[bool]:
        from core.db.models import KAFKA_MESSAGE_RESOLUTIONS
        return self._closed_vocabulary_check_is_current(
            conn, table_name="kafka_messages",
            constraint="ck_kafka_messages_resolution",
            members=KAFKA_MESSAGE_RESOLUTIONS)

    def _migrate_kafka_messages_resolution_check(self) -> bool:
        """kafka_messages.resolution gained 'unmatched' on 2026-10-10 (a
        templated resolver rule rendered a dependency no feed declares).
        Same shape as the two above: a deployed CHECK is rewritten to the
        Python vocabulary, idempotently."""
        from core.db.models import KAFKA_MESSAGE_RESOLUTIONS, KafkaMessage
        return self._migrate_closed_vocabulary_check(
            table_name="kafka_messages", column="resolution",
            constraint="ck_kafka_messages_resolution",
            members=KAFKA_MESSAGE_RESOLUTIONS, model=KafkaMessage)

    def _migrate_api_access_log_view_id_nullable(self) -> bool:
        """``api_access_log.view_id`` was NOT NULL when every row was a
        view's call; since 2026-10-17 a refusal raised before the view is
        read and a report-token call carry none (core/published_api/calls.py).
        PostgreSQL: ``ALTER COLUMN ... DROP NOT NULL`` once (idempotent: the
        inspector says whether it is still NOT NULL).  SQLite (dev / test):
        a fresh database is created nullable from the model; an existing
        one cannot ALTER a constraint in place -- the table is rebuilt only
        when EMPTY (the common dev case); otherwise the limitation is logged
        and a row with no view is REFUSED by that table's INSERT, which the
        batcher counts and reports as lost (never in production, which is
        PostgreSQL and altered in place)."""
        import sqlalchemy as _sa
        _log = logging.getLogger(__name__)
        # 2026-10-18 (found on the rig's PostgreSQL by the published-API proof):
        # the inspector's reads AUTOBEGIN a transaction on the connection, so a
        # later ``conn.begin()`` on the same connection raised "already
        # initialized a Transaction" -- the ALTER never ran, every refusal row
        # (view_id NULL) was rejected and, the batch INSERT being all-or-nothing,
        # valid rows in the same batch were lost with it.  SQLite tests could
        # not see it: a fresh database is born nullable.  The inspection and
        # the DDL now use SEPARATE connections, the DDL in its own
        # ``engine.begin()`` transaction (one rule for both dialects).
        try:
            with self.engine.connect() as conn:
                insp = _sa.inspect(conn)
                if "api_access_log" not in set(insp.get_table_names()):
                    return False
                col = next((c for c in insp.get_columns("api_access_log") if c["name"] == "view_id"), None)
                if col is None or col.get("nullable", True):
                    return False
                dialect = conn.dialect.name
                n_rows = None
                if dialect == "sqlite":
                    n_rows = int(conn.execute(_sa.text("SELECT COUNT(*) FROM api_access_log")).scalar() or 0)
            if dialect == "postgresql":
                with self.engine.begin() as ddl:
                    ddl.execute(_sa.text("ALTER TABLE api_access_log ALTER COLUMN view_id DROP NOT NULL"))
                _log.info("[migrate] api_access_log.view_id is now nullable")
                return True
            if dialect == "sqlite":
                if n_rows == 0:
                    from core.db.models import ApiAccessLog as _A
                    with self.engine.begin() as ddl:
                        ddl.execute(_sa.text("DROP TABLE api_access_log"))
                    _A.__table__.create(bind=self.engine)
                    _log.info("[migrate] api_access_log rebuilt (empty) with a nullable view_id")
                    return True
                _log.warning("[migrate] api_access_log.view_id stays NOT NULL on this SQLite "
                             "database (%d rows): a refusal row with no view is refused by the "
                             "INSERT and counted lost here; production (PostgreSQL) is altered "
                             "in place", n_rows)
                return False
            _log.warning("[migrate] api_access_log.view_id NOT NULL left as is on dialect %s", dialect)
            return False
        except Exception as exc:                        # noqa: BLE001 -- fail-open like every _MIGRATIONS leg
            _log.warning("[migrate] api_access_log.view_id nullable check failed: %s", exc)
            return False

    def _migrate_config_deployments_check(self) -> bool:
        """config_deployments.object_type gained every releasable kind on
        2026-10-17 (core/release/vocabulary.OBJECT_TYPES -- the one place
        the vocabulary is spelled).  Same shape as the checks above."""
        from core.db.models import GOVERNED_OBJECT_TYPES, ConfigDeployment
        return self._migrate_closed_vocabulary_check(
            table_name="config_deployments", column="object_type",
            constraint="ck_config_deployments_object_type",
            members=tuple(GOVERNED_OBJECT_TYPES), model=ConfigDeployment)

    def _repair_drifted_indexes(self) -> int:
        """Rebuild any _SHAPE_CRITICAL_INDEXES whose deployed columns differ
        from the model's.  Returns the number rebuilt.  Never raises.

        The expected shape is read from ``Base.metadata``, not restated here —
        restating it is how the deployed index and the model drifted apart in
        the first place.
        """
        import sqlalchemy as _sa
        from core.db.models import Base as _Base

        _log = logging.getLogger(__name__)
        want: Dict[str, Any] = {}
        for _tbl in _Base.metadata.tables.values():
            for _ix in _tbl.indexes:
                if _ix.name in self._SHAPE_CRITICAL_INDEXES:
                    want[_ix.name] = (
                        _tbl.name,
                        [c.name for c in _ix.columns],
                        bool(_ix.unique),
                    )
        if not want:
            return 0

        rebuilt = 0
        with self.engine.connect() as conn:
            insp = _sa.inspect(conn)
            try:
                present = set(insp.get_table_names())
            except Exception:
                return 0
            for ix_name, (tbl, cols, uniq) in want.items():
                if tbl not in present:
                    continue          # create_all will make it from the model
                try:
                    deployed = None
                    for _d in insp.get_indexes(tbl):
                        if _d.get("name") == ix_name:
                            deployed = _d
                            break
                    if deployed is not None:
                        _have = [c for c in (deployed.get("column_names") or []) if c]
                        # Order matters as much as membership: the leading
                        # columns ARE the seek key, and a reordered index
                        # answers the range seek far worse even when it covers
                        # the right set.
                        if _have == cols and bool(deployed.get("unique")) == uniq:
                            continue
                        if uniq and self._index_key_has_duplicates(conn, tbl, cols):
                            # Rebuilding would fail AFTER the drop and leave the
                            # table with no index at all.  Say so and stop --
                            # slower is survivable, unindexed-and-silent is not.
                            _log.error(
                                "index %s on %s is the WRONG SHAPE (deployed=%s, "
                                "model=%s) but the table already holds rows that "
                                "violate the model's key, so it cannot be rebuilt "
                                "automatically.  Left as-is; de-duplicate %s and "
                                "restart, or run `alembic upgrade head`.",
                                ix_name, tbl, _have, cols, tbl)
                            continue
                        _log.warning(
                            "index %s on %s has drifted (deployed=%s, model=%s) "
                            "— rebuilding", ix_name, tbl, _have, cols)
                        _drop = True
                    else:
                        _log.info("index %s on %s is missing — creating",
                                  ix_name, tbl)
                        _drop = False
                    # A SEPARATE write connection.  ``conn`` has already
                    # autobegun a transaction (the inspector and the duplicate
                    # probe both read through it), and calling begin() on top of
                    # that raises -- which is how the first cut of this method
                    # logged "rebuilding" and then rebuilt NOTHING.  Caught by
                    # restarting against a corrupted database and looking at the
                    # index afterwards, not by reading the code.
                    with self.engine.begin() as wconn:
                        if _drop:
                            wconn.execute(_sa.text(
                                f"DROP INDEX IF EXISTS {ix_name}"))
                        # Created from the model's own Index object, so the
                        # shape can only ever be the declared one.
                        for _tbl_obj in _Base.metadata.tables.values():
                            for _ix in _tbl_obj.indexes:
                                if _ix.name == ix_name:
                                    _ix.create(bind=wconn, checkfirst=True)
                    rebuilt += 1
                    _log.info("index %s on %s rebuilt as %s",
                              ix_name, tbl, cols)
                except Exception as _exc:
                    # An accelerator index is never worth failing a boot for.
                    _log.warning("index %s repair skipped: %s", ix_name, _exc)
        return rebuilt

    def _index_key_has_duplicates(self, conn, table: str, cols: list) -> bool:
        """True when ``table`` already holds rows that a UNIQUE index over
        ``cols`` would reject.  Used to refuse a rebuild that would drop a
        working index and then fail to recreate it."""
        import sqlalchemy as _sa
        try:
            _cols = ", ".join(f'"{c}"' for c in cols)
            row = conn.execute(_sa.text(
                f'SELECT 1 FROM (SELECT {_cols} FROM "{table}" '
                f"GROUP BY {_cols} HAVING COUNT(*) > 1) _d LIMIT 1"
            )).first()
            return row is not None
        except Exception:
            return True   # cannot prove it is safe -> do not touch the index

    def _ensure_search_trgm_indexes(self) -> None:
        """Metadata-scale audit finding 6, perf half (2026-08-09).

        ``search_reports`` / ``search_reports_unified`` filter with
        ``ilike '%q%'`` (leading wildcard) on reports.name/description and
        business_reports.name/description.  A btree can never serve a
        leading wildcard, so every search cost two full table scans.  The
        ACL half was fixed in cabf95b7; this is the index half.

        Per backend:
          * PostgreSQL — ``CREATE EXTENSION IF NOT EXISTS pg_trgm`` + GIN
            ``gin_trgm_ops`` indexes on the four searched columns (the
            standard index that serves LIKE/ILIKE with leading wildcards).
            Every statement runs in its own transaction and any failure
            only WARNs — an unprivileged role that may not CREATE
            EXTENSION leaves search exactly as fast/slow as it was, and
            startup can NEVER fail because of this.
          * SQLite — deliberately nothing: SQLite has no trigram opclass
            and its LIKE cannot use any index with a leading wildcard.
            SQLite deployments are dev/single-user scale where these
            metadata tables are small; the in-memory-speed scan IS the
            graceful degradation.  (FTS5 shadow tables were considered and
            rejected: they change tokenisation semantics vs substring
            match and add triggers to two hot tables for no measured
            need.)
        """
        if self.engine.dialect.name != "postgresql":
            return
        import logging as _logging
        _log = _logging.getLogger(__name__)
        try:
            with self.engine.begin() as conn:
                conn.execute(sa_text("CREATE EXTENSION IF NOT EXISTS pg_trgm"))
        except Exception as _ext_exc:
            _log.warning(
                "[search-trgm] pg_trgm extension unavailable (%s) — report "
                "search stays a sequential scan; ask a superuser to run "
                "'CREATE EXTENSION pg_trgm' to enable indexed search",
                _ext_exc,
            )
            return  # index DDL below would just fail 4x without the opclass
        stmts = (
            "CREATE INDEX IF NOT EXISTS ix_reports_name_trgm "
            "ON reports USING gin (name gin_trgm_ops)",
            "CREATE INDEX IF NOT EXISTS ix_reports_description_trgm "
            "ON reports USING gin (description gin_trgm_ops)",
            "CREATE INDEX IF NOT EXISTS ix_business_reports_name_trgm "
            "ON business_reports USING gin (name gin_trgm_ops)",
            "CREATE INDEX IF NOT EXISTS ix_business_reports_description_trgm "
            "ON business_reports USING gin (description gin_trgm_ops)",
        )
        created = 0
        for _sql in stmts:
            try:
                with self.engine.begin() as conn:   # one txn per index —
                    conn.execute(sa_text(_sql))     # a failure never aborts the rest
                created += 1
            except Exception as _idx_exc:
                _log.warning("[search-trgm] index DDL failed (search falls "
                             "back to scan): %s — %s", _sql, _idx_exc)
        if created == len(stmts):
            _log.info("[search-trgm] pg_trgm GIN indexes present on "
                      "reports/business_reports name+description")

    # ── Auto schema-drift detection ─────────────────────────────────────
    def _self_heal_empty_dataflow_tables(self) -> None:
        """Phase 132.28 — rebuild empty DataFlow tables that the auto-
        migrate couldn't fix (NOT NULL columns missing on legacy schemas).

        SQLite cannot ADD COLUMN with NOT NULL unless a server_default
        exists.  When a Phase-132 model gains a NOT NULL FK column after
        the table was already created, auto-migrate logs a warning and
        skips — but runtime INSERTs then fail.

        For DataFlow tables specifically, we know the data is
        operational state (no important user data in an empty install)
        and we can safely DROP + recreate.  We only touch tables that
        are (a) empty AND (b) actually drifted.
        """
        import logging as _logging
        _log = _logging.getLogger(__name__)
        dialect_name = self.engine.dialect.name
        if dialect_name != "sqlite":
            return   # PG can drop NOT NULL via ALTER COLUMN; only SQLite needs this
        from sqlalchemy import inspect as _inspect, text as _text
        insp = _inspect(self.engine)

        # All DataFlow tables in declaration order; we drop children
        # first (FK-respect even though SQLite is lax).
        dataflow_tables = [
            "dataflow_run_annotations",
            "dataflow_run_stages",
            "dataflow_runs",
            "dataflow_approval_requests",
            "dataflow_schedules",
            "dataflow_notification_policies",
            "dataflow_webhook_triggers",
            "dataflow_variables",
            "dataflow_stages",
            "dataflows",
        ]

        # Step 1: find drifted-and-empty tables
        to_rebuild: list = []
        for tbl_name in dataflow_tables:
            if not insp.has_table(tbl_name):
                continue
            model_tbl = Base.metadata.tables.get(tbl_name)
            if model_tbl is None:
                continue
            existing_cols = {c["name"] for c in insp.get_columns(tbl_name)}
            model_cols = {c.name for c in model_tbl.columns}
            missing_on_db = model_cols - existing_cols
            # Only care about NOT NULL missing — nullable cols already
            # get added by _auto_migrate_from_models.
            critical_missing = []
            for col in model_tbl.columns:
                if (col.name in missing_on_db and not col.nullable
                        and col.server_default is None
                        and not col.primary_key):
                    critical_missing.append(col.name)
            if not critical_missing:
                continue
            # Check emptiness
            try:
                with self.engine.connect() as conn:
                    n = conn.execute(_text(f"SELECT COUNT(*) FROM {tbl_name}")).scalar()
            except Exception:
                n = -1
            if n != 0:
                _log.warning(
                    "DataFlow self-heal: %s has %d rows but is missing NOT NULL "
                    "column(s) %s — refusing to rebuild (would lose data).  "
                    "Manual fix: drop the table or write a migration.",
                    tbl_name, n, critical_missing,
                )
                continue
            to_rebuild.append((tbl_name, critical_missing))

        if not to_rebuild:
            return

        # Step 2: drop + let create_all rebuild
        with self.engine.begin() as conn:
            for tbl_name, critical_missing in to_rebuild:
                _log.warning(
                    "DataFlow self-heal: DROPPING empty table %s (missing "
                    "NOT NULL %s) so create_all can rebuild it cleanly.",
                    tbl_name, critical_missing,
                )
                try:
                    conn.execute(_text(f"DROP TABLE IF EXISTS {tbl_name}"))
                except Exception as exc:
                    _log.warning("Could not drop %s: %s", tbl_name, exc)
        # Step 3: recreate via create_all (it skips existing tables)
        try:
            Base.metadata.create_all(bind=self.engine)
            _log.info("DataFlow self-heal: rebuilt %d table(s)", len(to_rebuild))
        except Exception as exc:
            _log.error("DataFlow self-heal: create_all after drop FAILED: %s",
                        exc, exc_info=True)

    def _verify_vault_columns_present(self) -> None:
        """Deep-dive #12 (2026-06-30) -- explicit vault-column presence
        check after migrations.

        Logs one of:
          * INFO  "VAULT_COLUMN_CHECK: all 8 vault columns present..."
            -- happy path; operator grep confirms fix landed.
          * ERROR "VAULT_COLUMN_CHECK: MISSING <n> vault columns: [...]"
            -- surfaces the exact columns still missing PLUS an
            actionable ALTER TABLE SQL the operator can run manually
            (in case auto-migrate hit a permission error or a dialect
            we don't cover).

        Fail-open: never raises.  Called after auto_migrate so it
        reports the FINAL state.
        """
        import logging as _logging
        _log = _logging.getLogger(__name__)
        VAULT_COLS = [
            "use_vault", "secret_ref", "secret_type",
            "vault_auth_url", "vault_role_name", "vault_role_type",
            "vault_secret_url", "vault_rotate_url",
        ]
        try:
            from sqlalchemy import inspect as _sa_inspect
            insp = _sa_inspect(self.engine)
            existing_tables = set(insp.get_table_names())
            if "system_accounts" not in existing_tables:
                _log.info(
                    "VAULT_COLUMN_CHECK: system_accounts table does not "
                    "exist yet (fresh DB) -- Base.metadata.create_all "
                    "will create it with all vault columns; skipping check."
                )
                return
            actual = {c["name"] for c in insp.get_columns("system_accounts")}
            missing = [c for c in VAULT_COLS if c not in actual]
            if not missing:
                _log.info(
                    "VAULT_COLUMN_CHECK: all 8 vault columns present on "
                    "system_accounts (dialect=%s) -- vault resolver will "
                    "work end-to-end.",
                    self.engine.dialect.name,
                )
                return
            # Some columns still missing -- surface actionable SQL.
            # Type mapping approximate; operator should adapt for
            # their dialect.
            _log.error(
                "VAULT_COLUMN_CHECK: MISSING %d vault columns on "
                "system_accounts (dialect=%s): %s.  Vault resolver "
                "code paths will crash with 'no such column' at "
                "runtime.  Auto-migrate should have added these; if "
                "you see this on a supported dialect check earlier "
                "startup logs for auto-migrate errors.  Manual fix:",
                len(missing), self.engine.dialect.name, missing,
            )
            for col in missing:
                if col == "use_vault":
                    ddl = "BOOLEAN NOT NULL DEFAULT FALSE"
                elif col in ("vault_auth_url", "vault_secret_url",
                              "vault_rotate_url"):
                    ddl = "TEXT"
                elif col == "secret_type" or col == "vault_role_type":
                    ddl = "VARCHAR(50)"
                else:
                    ddl = "VARCHAR(255)"
                _log.error(
                    "VAULT_COLUMN_CHECK:   ALTER TABLE system_accounts "
                    "ADD COLUMN %s %s;", col, ddl,
                )
        except Exception as _exc:
            _log.warning(
                "VAULT_COLUMN_CHECK: presence check failed (non-fatal) "
                "-- vault resolver may or may not work: %s", _exc,
            )

    def _auto_widen_cache_key_column(self) -> None:
        """One-shot widen of query_result_cache.cache_key + source_fingerprint
        from VARCHAR(64) to VARCHAR(128).  Idempotent: introspects current
        type and skips if already wide enough.

        Only runs on PostgreSQL (SQLite stores TEXT regardless of declared
        length; no widen needed)."""
        import logging as _logging
        _wlog = _logging.getLogger(__name__)
        if self.engine.dialect.name != "postgresql":
            return
        from sqlalchemy import text as _sql_text
        targets = [
            ("query_result_cache", "cache_key", 128),
            ("query_result_cache", "source_fingerprint", 128),
        ]
        with self.engine.begin() as conn:
            for table, col, want_len in targets:
                try:
                    row = conn.execute(_sql_text(
                        "SELECT character_maximum_length "
                        "FROM information_schema.columns "
                        "WHERE table_name = :t AND column_name = :c"
                    ), {"t": table, "c": col}).first()
                    if row is None:
                        continue   # column doesn't exist; skip
                    current_len = row[0] or 0
                    if current_len >= want_len:
                        continue
                    conn.execute(_sql_text(
                        f"ALTER TABLE {table} ALTER COLUMN {col} "
                        f"TYPE VARCHAR({want_len})"
                    ))
                    _wlog.info(
                        "cache_key widen: %s.%s VARCHAR(%d) -> VARCHAR(%d)",
                        table, col, current_len, want_len,
                    )
                except Exception as exc:
                    _wlog.warning(
                        "cache_key widen: %s.%s failed (will retry on "
                        "next startup): %s",
                        table, col, exc,
                    )

    def _auto_migrate_from_models(self):
        """Compare every SQLAlchemy model column to the actual DB schema and
        ALTER TABLE for any missing column.

        Safety net for the manual ``_MIGRATIONS`` dict — when a new column is
        added to a model, this auto-adds it to existing DBs on the next
        startup, eliminating the entire class of "no such column" bugs.

        Implementation notes:
        - Uses ``sqlalchemy.schema.CreateColumn`` to render each column DDL
          exactly as ``create_all()`` would (correct type, default, NOT NULL,
          dialect-aware) — no hand-rolled SQL, no manual escaping.
        - Uses ``dialect.identifier_preparer.quote()`` for table/column names
          (handles reserved words like ``user``, ``order``, ``type``).
        - Single batched introspection query (no N+1 round-trips).
        - **Steady-state fast path**: missing-column list is computed in pure
          Python BEFORE opening any write transaction — when nothing has
          drifted (the common case on every restart) we skip the
          ``engine.begin()`` entirely, avoiding an empty commit + WAL fsync.
        - PostgreSQL: ``ADD COLUMN IF NOT EXISTS`` + savepoints to survive
          rolling-deploy races and one-bad-column poisoning the txn.
        - SQLite: skips columns that are NOT NULL without a DEFAULT (SQLite
          limitation; logs WARNING so the developer knows manual migration
          is required).
        - Fail-open: top-level try/except so any unexpected error logs and
          startup continues.
        """
        import logging as _logging
        _mig_log = _logging.getLogger(__name__)

        dialect_name = self.engine.dialect.name
        # Deep-dive #12 (2026-06-30): extend to Oracle + MySQL so vault
        # columns (and any other model additions) actually land on those
        # dialects too.  Pre-fix an operator running on Oracle would
        # crash with "no such column: system_accounts.use_vault" because
        # NEITHER _apply_*_migrations NOR this auto-migrate handled
        # non-sqlite/postgres.  SQLAlchemy's CreateColumn renders
        # dialect-correct DDL (Oracle NUMBER(1) for Boolean, etc), so
        # extending the dialect list is safe.
        if dialect_name not in ("sqlite", "postgresql", "oracle", "mysql"):
            _mig_log.info(
                "Auto migration: dialect '%s' not supported "
                "-- manual schema management required.  Consider adding "
                "the dialect to the _auto_migrate_from_models allowlist.",
                dialect_name,
            )
            return
        is_pg = dialect_name == "postgresql"
        # Oracle + MySQL do NOT support ADD COLUMN IF NOT EXISTS; we
        # rely on the existing exception handler catching "duplicate
        # column" / "already exists" (line 1387 area) which already
        # covers both.
        _uses_if_not_exists = is_pg

        from sqlalchemy.schema import CreateColumn

        preparer = self.engine.dialect.identifier_preparer

        # ── Phase 1: introspect (read-only) ─────────────────────────────
        try:
            existing = self._fetch_all_columns_batched()
        except Exception as exc:
            _mig_log.warning("Auto migration: introspection failed: %s", exc, exc_info=True)
            return

        # ── Phase 2: build missing-column list in memory (no I/O) ───────
        # Only columns we can actually add are queued. Permanent-drift skips
        # (primary keys and SQLite NOT-NULL-without-DEFAULT) log at DEBUG
        # because the drift cannot be auto-healed and would otherwise spam
        # operator logs on every rolling-deploy pod restart. A single
        # INFO summary with counts is emitted at the end instead.
        missing: list = []  # list of (table_name, col, col_ddl)
        skipped_pk = 0
        skipped_not_null = 0
        for table_name, table_obj in Base.metadata.tables.items():
            existing_cols = existing.get(table_name)
            if existing_cols is None:
                continue  # table doesn't exist yet — create_all handles it
            for col in table_obj.columns:
                if col.name in existing_cols:
                    continue
                if col.primary_key:
                    _mig_log.debug(
                        "Auto migration: skipping primary key %s.%s (manual migration required)",
                        table_name, col.name,
                    )
                    skipped_pk += 1
                    continue
                # SQLite cannot ADD COLUMN with NOT NULL unless a server-level
                # DEFAULT exists. Note: ``col.default=`` is a Python-side default
                # only (applied at INSERT time by SQLAlchemy) — it is NOT rendered
                # in the CREATE/ALTER DDL. Only ``col.server_default`` ends up as
                # a SQL DEFAULT clause, so that's what we must check here.
                if (not is_pg and not col.nullable
                        and col.server_default is None):
                    # WARNING (not DEBUG) — silent skipping was the cause of
                    # the Phase 131 task_type "no such column" crash.  When
                    # auto-migrate can't add a column, the operator MUST see
                    # it on startup so the model can be fixed before users
                    # hit a runtime crash.
                    _mig_log.warning(
                        "Auto migration: CANNOT add %s.%s (NOT NULL without "
                        "server_default — SQLite ALTER TABLE limitation).  "
                        "Add server_default= to the model OR write a manual "
                        "migration.  Runtime INSERTs will fail until fixed.",
                        table_name, col.name,
                    )
                    skipped_not_null += 1
                    continue
                # SQLAlchemy renders the full column DDL: quoted-name + type + DEFAULT + NOT NULL
                try:
                    col_ddl = str(CreateColumn(col).compile(dialect=self.engine.dialect)).strip()
                except Exception as _cc_exc:
                    _mig_log.warning(
                        "Auto migration: cannot compile DDL for %s.%s: %s",
                        table_name, col.name, _cc_exc,
                    )
                    continue
                missing.append((table_name, col.name, col_ddl))

        if not missing:
            # Steady-state fast path — no transaction, no commit.
            if skipped_pk or skipped_not_null:
                _mig_log.debug(
                    "Auto migration: no drift; %d PK + %d NOT-NULL columns permanently skipped",
                    skipped_pk, skipped_not_null,
                )
            return

        # ── Phase 3: apply ALTER TABLEs (write transaction) ─────────────
        added = 0
        try:
            with self.engine.begin() as conn:
                for table_name, col_name, col_ddl in missing:
                    if_not_exists = " IF NOT EXISTS" if _uses_if_not_exists else ""
                    sql = (f"ALTER TABLE {preparer.quote(table_name)} "
                           f"ADD COLUMN{if_not_exists} {col_ddl}")
                    # PG: per-column savepoint so one failure doesn't poison
                    # the outer transaction. SQLite: no savepoint needed —
                    # DDL errors caught by the inner try/except don't cascade
                    # inside the enclosing explicit transaction, and each
                    # successful ALTER is preserved on the outer commit.
                    try:
                        if is_pg:
                            with conn.begin_nested():
                                conn.execute(sa_text(sql))
                        else:
                            conn.execute(sa_text(sql))
                        added += 1
                        _mig_log.info("Auto migration: added %s.%s", table_name, col_name)
                    except Exception as _alt_exc:
                        # Rolling-deploy race: two pods both decided to ADD
                        # the same column. The first wins; the second sees
                        # "duplicate column" / "already exists". Not an error.
                        _msg = str(_alt_exc).lower()
                        if "duplicate column" in _msg or "already exists" in _msg:
                            _mig_log.debug(
                                "Auto migration: %s.%s already present (race with another process)",
                                table_name, col_name,
                            )
                        else:
                            _mig_log.warning(
                                "Auto migration: failed to add %s.%s: %s",
                                table_name, col_name, _alt_exc,
                            )
            if added:
                _mig_log.info("Auto migration: added %d missing column(s) across all tables", added)
            if skipped_pk or skipped_not_null:
                _mig_log.debug(
                    "Auto migration: %d PK + %d NOT-NULL columns permanently skipped",
                    skipped_pk, skipped_not_null,
                )
        except Exception as exc:
            _mig_log.error("Auto migration: top-level failure: %s", exc, exc_info=True)

    def _fetch_all_columns_batched(self) -> Dict[str, set]:
        """Fetch every (table → set[column_name]) in a single query.

        Dialect is detected from ``self.engine`` — caller does not need to
        pass it. Returns an empty dict for unsupported dialects.

        - PostgreSQL: ``information_schema.columns`` filtered by current schema.
        - SQLite: ``pragma_table_info`` virtual table joined to ``sqlite_master``
          (SQLite >= 3.16, 2017).
        """
        dialect_name = self.engine.dialect.name
        if dialect_name == "postgresql":
            sql = sa_text(
                "SELECT table_name, column_name FROM information_schema.columns "
                "WHERE table_schema = current_schema()"
            )
        elif dialect_name == "sqlite":
            sql = sa_text(
                "SELECT m.name AS table_name, p.name AS column_name "
                "FROM sqlite_master m "
                "JOIN pragma_table_info(m.name) p "
                "WHERE m.type = 'table'"
            )
        else:
            return {}

        result: Dict[str, set] = {}
        with self.engine.connect() as conn:
            for row in conn.execute(sql):
                result.setdefault(row[0], set()).add(row[1])
        return result

    # ── Replica health & routing (Phase 43) ─────────────────────────────

    def _replica_health_loop(self):
        """Background thread: periodically check replica health + replication lag."""
        import logging as _rlog
        _rhl = _rlog.getLogger(__name__)
        try:
            from core.config import database as _db_cfg
            interval = _db_cfg.replica_health_interval_seconds
            max_lag = _db_cfg.replica_max_lag_seconds
        except Exception as _rcfg_exc:
            _rhl.info("Replica config unavailable, using defaults (30s/5s): %s", _rcfg_exc)
            interval, max_lag = 30, 5

        while not self._replica_shutdown.is_set():
            for idx, eng in enumerate(self._replica_engines):
                try:
                    with eng.connect() as conn:
                        row = conn.execute(sa_text(
                            "SELECT EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp()))"
                        )).fetchone()
                        lag = float(row[0]) if row and row[0] is not None else 0.0
                        healthy = lag <= max_lag
                        if not healthy and self._replica_health[idx]:
                            _rhl.warning("Replica %d lag %.1fs exceeds max %ds — marking unhealthy", idx, lag, max_lag)
                        elif healthy and not self._replica_health[idx]:
                            _rhl.info("Replica %d recovered (lag %.1fs) — marking healthy", idx, lag)
                        self._replica_health[idx] = healthy
                except Exception as e:
                    if self._replica_health[idx]:
                        _rhl.warning("Replica %d health check failed: %s — marking unhealthy", idx, e)
                    self._replica_health[idx] = False
            self._replica_shutdown.wait(interval)

    def _next_read_session(self):
        """Pick next healthy replica session via round-robin. Returns None if none available."""
        if not self._replica_engines:
            return None
        with self._replica_lock:
            n = len(self._replica_engines)
            for _ in range(n):
                idx = self._replica_index % n
                self._replica_index += 1
                if self._replica_health[idx]:
                    return self._replica_sessions[idx]()
        return None  # all unhealthy

    def get_replica_status(self) -> list:
        """Return health status of all replicas (for admin API)."""
        result = []
        for idx, eng in enumerate(self._replica_engines):
            info = {"index": idx, "healthy": self._replica_health[idx], "url": "(masked)"}
            try:
                url_str = str(eng.url)
                info["url"] = url_str.split("@")[-1] if "@" in url_str else url_str
            except Exception:
                pass
            try:
                with eng.connect() as conn:
                    row = conn.execute(sa_text(
                        "SELECT EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp()))"
                    )).fetchone()
                    info["lag_seconds"] = round(float(row[0]), 2) if row and row[0] is not None else 0.0
                    pool = eng.pool
                    info["pool_size"] = pool.size() if hasattr(pool, 'size') else -1
                    info["pool_checked_out"] = pool.checkedout() if hasattr(pool, 'checkedout') else -1
            except Exception as e:
                info["error"] = str(e)
            result.append(info)
        return result

    @contextmanager
    def get_session(self, read_only: bool = False) -> Session:
        """
        Context manager for database sessions.

        Args:
            read_only: If True and replicas are configured, route to a read replica.
                       Falls back to primary if no healthy replicas available.
        Yields:
            Database session
        """
        session = None
        _is_replica = False

        if read_only:
            try:
                from core.config import database as _db_cfg
                pref = _db_cfg.read_preference
            except Exception:
                pref = "primary"

            if pref != "primary" and self._replica_engines:
                session = self._next_read_session()
                if session is not None:
                    _is_replica = True
                    # BF-409 — emit a DEBUG line so operators can verify
                    # replica routing is firing (was silent before)
                    import logging as _logging
                    _logging.getLogger("db.replica_routing").debug(
                        "[replica] read-only session routed to replica idx=%d",
                        (self._replica_index - 1) % max(1, len(self._replica_engines)),
                    )

            if session is None:
                session = self.SessionLocal()

        if session is None:
            session = self.SessionLocal()

        try:
            yield session
            if not read_only:
                session.commit()
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()
    
    # SavedQuery operations
    def create_query(self, name: str, query_config: Dict[str, Any],
                    description: Optional[str] = None,
                    created_by: Optional[str] = None,
                    workspace_id: Optional[int] = None,
                    folder: Optional[str] = None,
                    tags: Optional[list] = None,
                    param_definitions: Optional[list] = None) -> SavedQuery:
        """Create a new saved query"""
        with self.get_session() as session:
            query = SavedQuery(
                name=name,
                description=description,
                query_config=query_config,
                created_by=created_by,
                workspace_id=workspace_id,
                folder=folder,
                tags=tags,
                param_definitions=param_definitions,
            )
            session.add(query)
            session.flush()
            session.refresh(query)
            return query.to_dict()
    
    def get_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a saved query by ID"""
        with self.get_session(read_only=True) as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            return query.to_dict() if query else None
    
    def list_queries(self, active_only: bool = True,
                    limit: int = 100, offset: int = 0,
                    workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """List all saved queries"""
        with self.get_session(read_only=True) as session:
            query = session.query(SavedQuery)
            if active_only:
                query = query.filter(SavedQuery.is_active)
            if workspace_id is not None:
                query = query.filter(
                    (SavedQuery.workspace_id == workspace_id) | (SavedQuery.workspace_id == None)  # noqa: E711  (SQLAlchemy: `is None` is always False on a Column)
                )
            query = query.order_by(SavedQuery.created_at.desc())
            query = query.limit(limit).offset(offset)
            return [q.to_dict() for q in query.all()]
    
    def update_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return None
            
            for key, value in kwargs.items():
                if hasattr(query, key):
                    setattr(query, key, value)
            
            query.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(query)
            return query.to_dict()

    def toggle_favorite(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Toggle is_favorite flag on a saved query."""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if not query:
                return None
            query.is_favorite = not query.is_favorite
            session.flush()
            session.refresh(query)
            return query.to_dict()

    def delete_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete a saved query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            
            if not query:
                return False
            
            if soft_delete:
                query.is_active = False
                query.updated_at = datetime.now(timezone.utc)
            else:
                session.delete(query)
            
            return True
    
    def increment_execution_count(self, query_id: int) -> None:
        """Increment execution count for a query"""
        with self.get_session() as session:
            query = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if query:
                query.execution_count += 1
                query.last_executed_at = datetime.now(timezone.utc)
    
    # QueryExecution operations
    def create_execution(self, execution_id: str, query_config: Dict[str, Any],
                        query_id: Optional[int] = None,
                        executed_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a new query execution record"""
        with self.get_session() as session:
            execution = QueryExecution(
                execution_id=execution_id,
                query_id=query_id,
                query_config=query_config,
                executed_by=executed_by
            )
            session.add(execution)
            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def update_execution(self, execution_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a query execution"""
        with self.get_session() as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            
            if not execution:
                return None

            # 2026-08-02 multi-pod cancel honesty: once a user's cancel has
            # been durably recorded (cancel_requested flag) and the row is
            # terminal 'cancelled', NO status write from the pod that kept
            # running the query may resurrect it.  The audit proved the
            # original two-state guard ('completed'/'failed' only) left a
            # hole: the owning pod's BF-589 status='processing' stamp
            # (api/execute_api.py, written as the query starts executing)
            # moved the row BACK to 'processing' — the UI showed the
            # cancelled query running again, and because the row was no
            # longer 'cancelled' a later 'completed' then landed too,
            # firing downstream delivery for a cancelled query.  'cancelled'
            # is therefore TERMINAL against EVERY transition (completed,
            # failed, processing, pending, ...); only an idempotent
            # 'cancelled' re-stamp passes.  Other fields (row counts,
            # output metadata) still apply.  N=1 fast-path cancels never
            # set cancel_requested, so this guard cannot trigger there.
            _new_status = kwargs.get("status")
            if (_new_status is not None and _new_status != "cancelled"
                    and (execution.status or "") == "cancelled"
                    and bool(getattr(execution, "cancel_requested", None))):
                import logging as _logging
                _logging.getLogger(__name__).info(
                    "[cancel-sticky] execution %s: refusing to overwrite "
                    "terminal 'cancelled' with '%s' (durable cancel request "
                    "recorded)", execution_id, _new_status)
                kwargs = {k: v for k, v in kwargs.items()
                          if k not in ("status", "error_message")}

            for key, value in kwargs.items():
                if hasattr(execution, key):
                    setattr(execution, key, value)

            if kwargs.get("status") in ["completed", "failed"]:
                execution.completed_at = datetime.now(timezone.utc)

            session.flush()
            session.refresh(execution)
            return execution.to_dict()
    
    def finalise_execution_if_pending(self, execution_id: str, *,
                                      status: str,
                                      error_message: str) -> bool:
        """Finalise a row no engine finalised: ``pending`` -> ``status``
        (``failed`` / ``cancelled``) with ``error_message``, in ONE
        conditional UPDATE.

        2026-10-07 (F11) -- the published-view handler wrote its row and then
        left by a door no engine stood behind (a refusal, a 4xx raised
        before the executor, a cancel); 150 rows sat ``pending`` forever.
        Conditional on ``status = 'pending'`` so it can never overwrite what
        an executor already wrote (``processing`` / ``completed`` /
        ``failed`` / a sticky ``cancelled``).  True when it finalised.
        """
        if status not in ("failed", "cancelled"):
            raise ValueError(f"not a terminal status: {status!r}")
        with self.get_session() as session:
            n = (session.query(QueryExecution)
                 .filter(QueryExecution.execution_id == execution_id,
                         QueryExecution.status == "pending")
                 .update({QueryExecution.status: status,
                          QueryExecution.error_message: error_message,
                          QueryExecution.completed_at: datetime.now(timezone.utc)},
                         synchronize_session=False))
            return bool(n)

    def fail_orphaned_executions(self, *, executed_by_prefix: str,
                                 statuses: Tuple[str, ...],
                                 started_before: datetime,
                                 error_message: str,
                                 limit: int = 10000) -> List[str]:
        """Fail rows of ONE lane (``executed_by`` starting with
        ``executed_by_prefix``) left in ``statuses``, started before
        ``started_before``, that hold NO execution checkpoint -- the rows
        startup checkpoint recovery cannot see, because nothing ever
        checkpointed them.  Returns the execution ids it failed.

        The age bound is the ownership rule (``core.checkpoint``): a row
        older than every legitimate query cannot belong to a live run on
        any pod.  A row WITH a checkpoint is left to ``recover_incomplete``,
        which scopes it by owner.  The UPDATE re-checks the status, so a
        row an executor finalised between the read and the write is kept.
        """
        like = executed_by_prefix.replace("\\", "\\\\").replace(
            "%", "\\%").replace("_", "\\_") + "%"
        with self.get_session() as session:
            has_cp = (session.query(ExecutionCheckpoint.execution_id)
                      .filter(ExecutionCheckpoint.execution_id
                              == QueryExecution.execution_id)
                      .exists())
            ids = [r[0] for r in (
                session.query(QueryExecution.execution_id)
                .filter(QueryExecution.status.in_(list(statuses)),
                        QueryExecution.executed_by.like(like, escape="\\"),
                        QueryExecution.started_at < started_before,
                        ~has_cp)
                .limit(limit)
                .all())]
            if not ids:
                return []
            (session.query(QueryExecution)
             .filter(QueryExecution.execution_id.in_(ids),
                     QueryExecution.status.in_(list(statuses)))
             .update({QueryExecution.status: "failed",
                      QueryExecution.error_message: error_message,
                      QueryExecution.completed_at: datetime.now(timezone.utc)},
                     synchronize_session=False))
            return ids

    def get_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Get execution by ID"""
        with self.get_session(read_only=True) as session:
            execution = session.query(QueryExecution).filter(
                QueryExecution.execution_id == execution_id
            ).first()
            return execution.to_dict() if execution else None

    def get_cancel_requested_executions(self, max_age_hours: float = 24.0,
                                        limit: int = 200) -> List[str]:
        """2026-08-02 multi-pod cancel routing: execution_ids with a durable
        cross-pod cancel request that may still have a live local task.

        Includes rows already marked 'cancelled' (the cancelling pod writes
        that status immediately) because the OWNING pod still has to observe
        the flag and stop its running engine.  Signalling is idempotent, and
        the ``started_at`` age window bounds the sweep so old rows age out.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
        with self.get_session(read_only=True) as session:
            rows = (session.query(QueryExecution.execution_id)
                    .filter(
                        QueryExecution.cancel_requested.is_(True),
                        QueryExecution.status.in_(
                            ["pending", "processing", "cancelled"]),
                        QueryExecution.started_at >= cutoff,
                    )
                    .limit(limit)
                    .all())
            return [r[0] for r in rows]

    def get_executions_by_ids(self, execution_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        """Bulk-fetch executions by ID — single ``WHERE execution_id IN (...)``
        query instead of N separate ``get_execution()`` calls.

        Used by the admin active-queries endpoint, which previously fired one
        query per live in-memory task ID not already in the batch result —
        an N+1 pattern that dominated AdminPage load time on busy systems.
        Returns a ``{execution_id: row_dict}`` map; missing IDs are simply
        absent from the map (no exception, no None entries).
        """
        if not execution_ids:
            return {}
        with self.get_session(read_only=True) as session:
            rows = session.query(QueryExecution).filter(
                QueryExecution.execution_id.in_(list(execution_ids))
            ).all()
            return {r.execution_id: r.to_dict() for r in rows}
    
    def get_last_successful_output_file(self, query_id: int) -> Optional[Dict]:
        """Return the most recent completed execution's output_file for a query_id.
        Only returns if the file still exists on disk (for stale-fallback use).
        """
        import os as _os
        with self.get_session(read_only=True) as session:
            row = (session.query(QueryExecution)
                   .filter(
                       QueryExecution.query_id == query_id,
                       QueryExecution.status == "completed",
                       QueryExecution.output_file.isnot(None),
                   )
                   .order_by(QueryExecution.completed_at.desc())
                   .first())
            if not row or not row.output_file:
                return None
            if not _os.path.exists(row.output_file):
                return None
            return {
                "output_file": row.output_file,
                "completed_at": row.completed_at.isoformat() if row.completed_at else None,
                "total_rows": row.total_rows or 0,
                "file_size_bytes": row.file_size_bytes or 0,
            }

    @staticmethod
    def _executions_filtered(query, status: Optional[str] = None,
                             executed_by: Optional[str] = None,
                             started_after: Optional[datetime] = None,
                             q: Optional[str] = None):
        """FB-49 (2026-09-20) -- the ONE place an executions filter is built.

        A page and its TOTAL are two reads of the same question; building
        the predicate twice is how a pager comes to say "51-100 of 40".
        """
        from sqlalchemy import or_ as _or
        if status:
            query = query.filter(QueryExecution.status == status)
        if executed_by:
            query = query.filter(QueryExecution.executed_by == executed_by)
        if started_after is not None:
            query = query.filter(QueryExecution.started_at >= started_after)
        term = (q or "").strip()
        if term:
            # What a search over executions can honestly reach: the id a
            # user pastes, who ran it, and the failure text.  query_config
            # is JSON and not portably searchable across sqlite/postgres --
            # so the UI names these three rather than implying more.
            like = f"%{term}%"
            query = query.filter(_or(
                QueryExecution.execution_id.ilike(like),
                QueryExecution.executed_by.ilike(like),
                QueryExecution.error_message.ilike(like),
            ))
        return query

    def list_executions(self, limit: int = 100, offset: int = 0,
                       status: Optional[str] = None,
                       executed_by: Optional[str] = None,
                       started_after: Optional[datetime] = None,
                       q: Optional[str] = None) -> List[Dict[str, Any]]:
        """List query executions, optionally filtered by user / status /
        start time / free-text ``q`` (execution id, who ran it, error text).

        ``started_after`` lets callers cap the scan to a recent time window
        (e.g. today's executions for the admin user-stats endpoint) without
        pulling thousands of historical rows just to filter them in Python.
        """
        with self.get_session(read_only=True) as session:
            query = self._executions_filtered(
                session.query(QueryExecution), status=status,
                executed_by=executed_by, started_after=started_after, q=q)

            query = query.order_by(QueryExecution.started_at.desc())
            query = query.limit(limit).offset(offset)

            return [e.to_dict() for e in query.all()]

    def count_executions(self, status: Optional[str] = None,
                         executed_by: Optional[str] = None,
                         started_after: Optional[datetime] = None,
                         q: Optional[str] = None) -> int:
        """How many executions ``list_executions`` would return unpaged.

        FB-49: /executions rendered 50 rows and offered no way to reach row
        51 -- execution history that ended at 50, with nothing on screen
        saying so.  A pager needs a total, and the total must come from the
        SAME predicate as the page (``_executions_filtered``).
        """
        from sqlalchemy import func as _func
        with self.get_session(read_only=True) as session:
            query = self._executions_filtered(
                session.query(_func.count(QueryExecution.id)), status=status,
                executed_by=executed_by, started_after=started_after, q=q)
            return int(query.scalar() or 0)
    
    # DownloadFile operations
    def create_download_file(self, file_id: str, filename: str, file_path: str,
                           file_size_bytes: int, execution_id: Optional[str] = None,
                           expires_at: Optional[datetime] = None,
                           created_by: Optional[str] = None,
                           source_kind: Optional[str] = None,
                           source_id: Optional[str] = None,
                           source_dataset_id: Optional[str] = None,
                           rls_signature: Optional[str] = None,
                           checksum: Optional[str] = None,
                           checksum_algorithm: Optional[str] = None,
                           business_date: Optional[str] = None,
                           build_id: Optional[str] = None) -> Dict[str, Any]:
        """Create a download file record.

        ``source_kind`` / ``source_id`` / ``rls_signature`` are the
        entitlement-sharing stamp (see ``core.download_sharing``).  Omitting
        them leaves the row creator-only, which is what every pre-2026-08-30
        caller gets.

        ``checksum`` / ``checksum_algorithm`` / ``business_date`` /
        ``build_id`` are the FR-DEL-10 feed-deliverable facts (2026-09-03).
        ``core.feed.archive.register_feed_download`` inspects this
        signature and passes exactly what it accepts, so widening the
        signature is what turns those facts on — they were being computed
        and dropped until this landed.
        """
        with self.get_session() as session:
            download_file = DownloadFile(
                file_id=file_id,
                execution_id=execution_id,
                filename=filename,
                file_path=file_path,
                file_size_bytes=file_size_bytes,
                expires_at=expires_at,
                created_by=created_by,
                source_kind=source_kind,
                source_id=source_id,
                source_dataset_id=source_dataset_id,
                rls_signature=rls_signature,
                checksum=checksum,
                checksum_algorithm=checksum_algorithm,
                business_date=business_date,
                build_id=build_id,
            )
            session.add(download_file)
            session.flush()
            session.refresh(download_file)
            return download_file.to_dict()
    
    def get_download_file(self, file_id: str) -> Optional[Dict[str, Any]]:
        """Get download file by ID"""
        with self.get_session(read_only=True) as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            return file.to_dict() if file else None
    
    def list_download_files(self, status: Optional[str] = "available",
                          limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """List download files.

        2026-06-24 -- LEFT JOIN with QueryExecution so the Download
        Center can show the SQL/query that produced each file.
        Operator pushed back: "why download center doesnt show full
        query...they should be able to show what query they have
        executed".  The SQL lives in QueryExecution.query_config
        (JSON); we extract the human-readable form here in ONE place
        so every API/UI consumer sees the same shape.  Adds these
        fields to each row:

          query_sql          -- the SQL text (raw_sql / sql / primary_sql
                                / _sql_resolved -- whichever the
                                query_config carries)
          query_kind         -- 'bqb' | 'cqb' | 'sql' | 'feed' | ...
                                (when query_config encodes it)
          total_rows         -- from QueryExecution
          duration_seconds   -- computed from started_at/completed_at
          format             -- inferred from filename
        """
        from core.db.models import QueryExecution as _QE
        with self.get_session(read_only=True) as session:
            query = session.query(DownloadFile, _QE).outerjoin(
                _QE, _QE.execution_id == DownloadFile.execution_id,
            )

            if status:
                query = query.filter(DownloadFile.status == status)

            query = query.order_by(DownloadFile.created_at.desc())
            query = query.limit(limit).offset(offset)

            rows: List[Dict[str, Any]] = []
            for download_file, qe in query.all():
                row = download_file.to_dict()
                # Enrich with execution metadata when available.
                if qe is not None:
                    try:
                        row["total_rows"] = int(qe.total_rows or 0)
                    except (TypeError, ValueError):
                        row["total_rows"] = 0
                    try:
                        if qe.completed_at and qe.started_at:
                            row["duration_seconds"] = round(
                                (qe.completed_at - qe.started_at)
                                .total_seconds(), 2,
                            )
                    except Exception:
                        pass
                    # Pull SQL out of query_config (best-effort across
                    # the shapes BQB / CQB / Run-SQL / Feed all use).
                    _qc = qe.query_config or {}
                    if isinstance(_qc, str):
                        try:
                            import json as _json
                            _qc = _json.loads(_qc) or {}
                        except Exception:
                            _qc = {}
                    if isinstance(_qc, dict):
                        # Try canonical SQL fields in order of
                        # specificity.  ``_sql_resolved`` is the
                        # post-substitution form (best for display);
                        # ``raw_sql`` / ``sql`` / ``primary_sql`` are
                        # the as-submitted forms.
                        for _sql_field in (
                            "_sql_resolved", "raw_sql", "sql",
                            "primary_sql", "user_sql",
                        ):
                            _v = _qc.get(_sql_field)
                            if isinstance(_v, str) and _v.strip():
                                row["query_sql"] = _v
                                break
                        # Source kind for the UI badge.
                        _kind = (
                            _qc.get("query_kind")
                            or _qc.get("source")
                            or _qc.get("mode")
                        )
                        if isinstance(_kind, str):
                            row["query_kind"] = _kind
                rows.append(row)
            return rows
    
    def update_download_file(self, file_id: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Update download file"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            
            if not file:
                return None
            
            for key, value in kwargs.items():
                if hasattr(file, key):
                    setattr(file, key, value)
            
            session.flush()
            session.refresh(file)
            return file.to_dict()
    
    def increment_download_count(self, file_id: str) -> None:
        """Increment download count"""
        with self.get_session() as session:
            file = session.query(DownloadFile).filter(
                DownloadFile.file_id == file_id
            ).first()
            if file:
                file.download_count += 1
                file.last_downloaded_at = datetime.now(timezone.utc)

    # ── Connection operations ──────────────────────────────────────────────────

    def create_connection(self, name: str, connection_type: str,
                         config: Dict[str, Any],
                         workspace_id: Optional[int] = None) -> Dict[str, Any]:
        """Create a new connection — encrypts sensitive config fields at rest."""
        from core.crypto import encrypt_config, mask_config
        with self.get_session() as session:
            connection = Connection(
                name=name,
                connection_type=connection_type,
                config=encrypt_config(config),
                workspace_id=workspace_id,
            )
            session.add(connection)
            session.flush()
            session.refresh(connection)
            d = connection.to_dict()
            d["config"] = mask_config(config)   # return masked to caller
            return d

    def get_connection(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials MASKED — safe for API responses to the browser.

        2026-10-02: masked by PRESENCE (``masked_for_client``), and a saved
        secret this process cannot decrypt is NAMED in
        ``credential_problems`` instead of coming back blank."""
        from core.crypto import masked_for_client, undecryptable_fields
        with self.get_session(read_only=True) as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["credential_problems"] = undecryptable_fields(d["config"])
            d["config"] = masked_for_client(d["config"])
            return d

    def encrypt_plaintext_connection_secrets(self) -> List[int]:
        """Encrypt every sensitive value a stored connection config still
        holds in PLAIN TEXT, at any depth (2026-10-12): the at-rest rule
        walked the top level only, so a nested secret
        (``unload_s3_access.aws_secret_access_key``) was saved readable.  Only
        those values change (``encrypt_config`` leaves an ``enc::`` value
        alone).  Idempotent; run at init.  Returns the connection ids fixed."""
        from core.crypto import _ENC_PREFIX, _sensitive_paths, encrypt_config
        fixed: List[int] = []
        with self.get_session() as session:
            for c in session.query(Connection).all():
                cfg = c.config if isinstance(c.config, dict) else None
                if not cfg:
                    continue
                if any(isinstance(v, str) and v and not v.startswith(_ENC_PREFIX)
                       for _, v in _sensitive_paths(cfg)):
                    c.config = encrypt_config(cfg)
                    fixed.append(int(c.id))
            session.flush()
        return fixed

    def get_connection_stored_config(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """The config AS STORED (sensitive fields still encrypted).  For the
        one caller that must keep a value it cannot decrypt rather than
        overwrite it -- the update route.  Never return it to a client."""
        with self.get_session(read_only=True) as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            return dict(c.to_dict().get("config") or {}) if c else None

    def get_connection_raw(self, connection_id: int) -> Optional[Dict[str, Any]]:
        """Get connection with credentials DECRYPTED — for internal engine/connector use only.
        Never return this directly to API clients."""
        from core.crypto import decrypt_config
        with self.get_session(read_only=True) as session:
            c = session.query(Connection).filter(Connection.id == connection_id).first()
            if not c:
                return None
            d = c.to_dict()
            d["config"] = decrypt_config(d["config"])
            return d

    def list_connections(self, active_only: bool = True,
                        limit: int = 100, offset: int = 0,
                        workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """List connections with credentials masked (by presence; see get_connection)."""
        from core.crypto import masked_for_client, undecryptable_fields
        with self.get_session(read_only=True) as session:
            q = session.query(Connection)
            if active_only:
                q = q.filter(Connection.is_active)
            if workspace_id is not None:
                q = q.filter(
                    (Connection.workspace_id == workspace_id) | (Connection.workspace_id == None)  # noqa: E711  (SQLAlchemy: `is None` is always False on a Column)
                )
            q = q.order_by(Connection.created_at.desc()).limit(limit).offset(offset)
            result = []
            for c in q.all():
                d = c.to_dict()
                d["credential_problems"] = undecryptable_fields(d["config"])
                d["config"] = masked_for_client(d["config"])
                result.append(d)
            return result

    def update_connection(self, connection_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a connection — re-encrypts config if provided."""
        from core.crypto import encrypt_config
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return None
            # Encrypt config before persisting
            if "config" in kwargs and isinstance(kwargs["config"], dict):
                kwargs["config"] = encrypt_config(kwargs["config"])
            for key, value in kwargs.items():
                if hasattr(connection, key):
                    setattr(connection, key, value)
            connection.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(connection)
            return connection.to_dict()

    def delete_connection(self, connection_id: int, soft_delete: bool = True) -> bool:
        """Delete a connection."""
        with self.get_session() as session:
            connection = session.query(Connection).filter(Connection.id == connection_id).first()
            if not connection:
                return False
            if soft_delete:
                connection.is_active = False
                connection.updated_at = datetime.now(timezone.utc)
            else:
                session.delete(connection)
            return True

    # ── Per-user resource counts (Phase 102-F) ────────────────────────────────

    def count_user_connections(self, username: str) -> int:
        """Count active connections owned by a user (is_active=True only)."""
        with self.get_session(read_only=True) as session:
            return (session.query(Connection)
                    .filter(Connection.created_by == username,
                            Connection.is_active)
                    .count())

    def count_user_schedules(self, username: str) -> int:
        """Count active schedules owned by a user."""
        from core.db.models import Schedule
        with self.get_session(read_only=True) as session:
            return (session.query(Schedule)
                    .filter(Schedule.created_by == username,
                            Schedule.is_active)
                    .count())

    def count_user_published_views(self, username: str) -> int:
        """Count active published views owned by a user."""
        from core.db.models import PublishedView
        with self.get_session(read_only=True) as session:
            return (session.query(PublishedView)
                    .filter(PublishedView.created_by == username,
                            PublishedView.is_active)
                    .count())

    def count_user_saved_queries(self, username: str) -> int:
        """Active saved queries owned by a user (FB-48, 2026-09-20).

        The counterpart to ``admin_governance.max_saved_queries_per_user``,
        which was declared, admin-settable, and read by nothing.  Counts the
        same way its siblings do: owner match, active rows only, so a
        deleted query frees a slot.
        """
        from core.db.models import SavedQuery
        with self.get_session(read_only=True) as session:
            return (session.query(SavedQuery)
                    .filter(SavedQuery.created_by == username,
                            SavedQuery.is_active)
                    .count())

    def count_user_sql_files(self, username: str) -> int:
        """Active SQL files owned by a user (FB-48, 2026-09-20).

        The counterpart to ``sql_files.max_files_per_user``, which was
        declared and read by nothing while ``sql_files.max_file_size``
        beside it WAS enforced -- so an operator who set a per-user cap had
        every reason to believe it applied.
        """
        from core.db.models import SqlFile
        with self.get_session(read_only=True) as session:
            return (session.query(SqlFile)
                    .filter(SqlFile.created_by == username,
                            SqlFile.is_active)
                    .count())

    # ── Connection ACL operations (Phase 102-E) ────────────────────────────────

    def grant_connection_access(self, connection_id: int, grant_type: str,
                                grantee: str, permission: str = "read",
                                created_by: Optional[str] = None) -> Dict[str, Any]:
        """Grant a user or role access to a connection.

        Upserts by (connection_id, grant_type, grantee) — re-granting just
        updates the permission level.
        """
        if grant_type not in ("user", "role"):
            raise ValueError(f"grant_type must be 'user' or 'role', got {grant_type!r}")
        if permission not in ("read", "execute", "manage"):
            raise ValueError(f"permission must be read|execute|manage, got {permission!r}")
        with self.get_session() as session:
            existing = (session.query(ConnectionAccess)
                        .filter(ConnectionAccess.connection_id == connection_id,
                                ConnectionAccess.grant_type == grant_type,
                                ConnectionAccess.grantee == grantee)
                        .first())
            if existing:
                existing.permission = permission
                session.flush()
                session.refresh(existing)
                return existing.to_dict()
            entry = ConnectionAccess(
                connection_id=connection_id,
                grant_type=grant_type,
                grantee=grantee,
                permission=permission,
                created_by=created_by,
            )
            session.add(entry)
            session.flush()
            session.refresh(entry)
            return entry.to_dict()

    def revoke_connection_access(self, access_id: int) -> bool:
        """Delete a single ACL row by id."""
        with self.get_session() as session:
            row = (session.query(ConnectionAccess)
                   .filter(ConnectionAccess.id == access_id).first())
            if not row:
                return False
            session.delete(row)
            return True

    def list_connection_access(self, connection_id: int) -> List[Dict[str, Any]]:
        """List all ACL grants for a single connection."""
        with self.get_session(read_only=True) as session:
            rows = (session.query(ConnectionAccess)
                    .filter(ConnectionAccess.connection_id == connection_id)
                    .order_by(ConnectionAccess.created_at.desc())
                    .all())
            return [r.to_dict() for r in rows]

    def list_connection_ids_for_user(self, username: str,
                                     roles: Optional[List[str]] = None) -> set:
        """Return the set of connection_ids this user may access via ACL grants.

        Combines direct user grants + role grants in a SINGLE query so ACL
        filtering stays O(1) regardless of how many connections a user owns.
        """
        from sqlalchemy import or_
        roles = roles or []
        with self.get_session(read_only=True) as session:
            conds = [(ConnectionAccess.grant_type == "user")
                     & (ConnectionAccess.grantee == username)]
            if roles:
                conds.append((ConnectionAccess.grant_type == "role")
                             & (ConnectionAccess.grantee.in_(roles)))
            rows = (session.query(ConnectionAccess.connection_id)
                    .filter(or_(*conds))
                    .distinct()
                    .all())
            return {int(r[0]) for r in rows}

    def user_has_connection_access(self, username: str, connection_id: int,
                                   roles: Optional[List[str]] = None) -> bool:
        """Check if a user (or any of their roles) has any ACL grant on a connection."""
        from sqlalchemy import or_
        roles = roles or []
        with self.get_session(read_only=True) as session:
            conds = [(ConnectionAccess.grant_type == "user")
                     & (ConnectionAccess.grantee == username)]
            if roles:
                conds.append((ConnectionAccess.grant_type == "role")
                             & (ConnectionAccess.grantee.in_(roles)))
            q = (session.query(ConnectionAccess.id)
                 .filter(ConnectionAccess.connection_id == connection_id)
                 .filter(or_(*conds))
                 .limit(1))
            return q.first() is not None

    # ── Connection Profile operations (Phase 24B) ──────────────────────────────

    def list_connection_profiles(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(ConnectionProfile).order_by(ConnectionProfile.name).all()
            return [r.to_dict() for r in rows]

    def get_active_profile(self) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            r = session.query(ConnectionProfile).filter(ConnectionProfile.is_active).first()
            return r.to_dict() if r else None

    def get_profile_mappings(self, profile_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == profile_id
            ).all()
            return [r.to_dict() for r in rows]

    def create_connection_profile(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            p = ConnectionProfile(**kwargs)
            session.add(p)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def update_connection_profile(self, profile_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            p = session.query(ConnectionProfile).filter(ConnectionProfile.id == profile_id).first()
            if not p:
                return None
            for k, v in kwargs.items():
                if hasattr(p, k):
                    setattr(p, k, v)
            p.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def activate_connection_profile(self, profile_id: int) -> bool:
        """Set one profile as active; deactivate all others (exclusive)."""
        with self.get_session() as session:
            session.query(ConnectionProfile).update({"is_active": False})
            p = session.query(ConnectionProfile).filter(ConnectionProfile.id == profile_id).first()
            if not p:
                return False
            p.is_active = True
            return True

    def deactivate_all_profiles(self) -> None:
        with self.get_session() as session:
            session.query(ConnectionProfile).update({"is_active": False})

    def delete_connection_profile(self, profile_id: int) -> bool:
        with self.get_session() as session:
            p = session.query(ConnectionProfile).filter(ConnectionProfile.id == profile_id).first()
            if not p:
                return False
            session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == profile_id
            ).delete()
            session.delete(p)
            return True

    def set_profile_mappings(self, profile_id: int, mappings: List[Dict]) -> List[Dict[str, Any]]:
        """Replace ALL mappings for a profile atomically."""
        with self.get_session() as session:
            session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == profile_id
            ).delete()
            created = []
            for m in mappings:
                obj = ConnectionProfileMapping(
                    profile_id=profile_id,
                    source_connection_id=m["source_connection_id"],
                    target_connection_id=m["target_connection_id"],
                    description=m.get("description"),
                )
                session.add(obj)
                session.flush()
                session.refresh(obj)
                created.append(obj.to_dict())
            return created

    def resolve_connection_via_profile(self, connection_id: int) -> int:
        """Return the mapped connection_id if active profile has a rule; else original.

        Returns connection_id unchanged when no profile is active or no mapping exists.
        """
        active = self.get_active_profile()
        if not active:
            return connection_id
        with self.get_session(read_only=True) as session:
            mapping = session.query(ConnectionProfileMapping).filter(
                ConnectionProfileMapping.profile_id == active["id"],
                ConnectionProfileMapping.source_connection_id == connection_id,
            ).first()
            return mapping.target_connection_id if mapping else connection_id

    # ── Schedule operations ────────────────────────────────────────────────────

    def create_schedule(self, **kwargs) -> Dict[str, Any]:
        """Create a new schedule record."""
        with self.get_session() as session:
            s = Schedule(**kwargs)
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_schedule(self, schedule_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            return s.to_dict() if s else None

    def list_schedules(self, active_only: bool = True,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        # PG-dialect audit 2026-08-09: ``id`` tiebreaker added.  The
        # scheduler bootstrap (_load_all_active_schedules) pages this query
        # with LIMIT/OFFSET; on PostgreSQL an ORDER BY with equal
        # created_at keys is NOT stable across queries, so page boundaries
        # could skip (silently never register) or repeat schedules created
        # in the same microsecond.  SQLite happened to be stable by rowid.
        with self.get_session(read_only=True) as session:
            q = session.query(Schedule)
            if active_only:
                q = q.filter(Schedule.is_active)
            rows = (q.order_by(Schedule.created_at.desc(), Schedule.id.desc())
                    .limit(limit).offset(offset).all())
            return [s.to_dict() for s in rows]

    def list_all_schedules(self, limit: int = 500, offset: int = 0) -> List[Dict[str, Any]]:
        # Same deterministic-pagination tiebreaker as list_schedules above.
        with self.get_session(read_only=True) as session:
            rows = (session.query(Schedule)
                    .order_by(Schedule.created_at.desc(), Schedule.id.desc())
                    .limit(limit).offset(offset).all())
            return [s.to_dict() for s in rows]

    def update_schedule(self, schedule_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(s, key):
                    setattr(s, key, value)
            s.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def delete_schedule(self, schedule_id: int) -> bool:
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if not s:
                return False
            session.delete(s)
            return True

    def increment_schedule_run_count(self, schedule_id: int):
        with self.get_session() as session:
            s = session.query(Schedule).filter(Schedule.id == schedule_id).first()
            if s:
                s.run_count = (s.run_count or 0) + 1

    def list_downloads_enriched(
        self,
        status: Optional[str] = "available",
        limit: int = 200,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Returns download files enriched with linked execution metadata.

        Single LEFT JOIN query — no N+1 lookups.
        Extra fields added to each record:
          - duration_seconds  (execution completed_at - started_at)
          - total_rows        (rows written by the query engine)
          - format            ('csv' | 'excel' | 'json' derived from filename)
        """
        with self.get_session() as session:
            query = (
                session.query(DownloadFile, QueryExecution)
                .outerjoin(
                    QueryExecution,
                    DownloadFile.execution_id == QueryExecution.execution_id,
                )
            )
            if status:
                query = query.filter(DownloadFile.status == status)

            query = (
                query.order_by(DownloadFile.created_at.desc())
                .limit(limit)
                .offset(offset)
            )

            result = []
            for dl, ex in query.all():
                d = dl.to_dict()

                # Execution metadata
                if ex:
                    if ex.started_at and ex.completed_at:
                        d["duration_seconds"] = round(
                            (ex.completed_at - ex.started_at).total_seconds(), 2
                        )
                    else:
                        d["duration_seconds"] = None
                    d["total_rows"] = ex.total_rows or 0
                else:
                    d["duration_seconds"] = None
                    d["total_rows"] = None

                # Derive format from filename extension
                fname = (d.get("filename") or "").lower()
                if fname.endswith(".xlsx"):
                    d["format"] = "excel"
                elif fname.endswith(".json"):
                    d["format"] = "json"
                else:
                    d["format"] = "csv"

                result.append(d)

            return result

    # ── SQL Saved Queries (Trino / Snowflake / Databricks) ────────────────────

    def create_sql_query(self, **kwargs) -> Dict[str, Any]:
        """Create a new SqlSavedQuery record."""
        with self.get_session() as session:
            q = SqlSavedQuery(**kwargs)
            session.add(q)
            session.flush()
            return q.to_dict()

    def list_sql_queries(self, active_only: bool = True, limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """List SQL saved queries, newest first."""
        with self.get_session(read_only=True) as session:
            query = session.query(SqlSavedQuery)
            if active_only:
                query = query.filter(SqlSavedQuery.is_active)
            rows = query.order_by(SqlSavedQuery.created_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def get_sql_query(self, query_id: int) -> Optional[Dict[str, Any]]:
        """Get a single SQL saved query by ID."""
        with self.get_session(read_only=True) as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            return q.to_dict() if q else None

    def update_sql_query(self, query_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update fields of an existing SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(q, key):
                    setattr(q, key, value)
            q.updated_at = datetime.now(timezone.utc)
            session.flush()
            return q.to_dict()

    def delete_sql_query(self, query_id: int, soft_delete: bool = True) -> bool:
        """Delete or soft-delete a SQL saved query."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not q:
                return False
            if soft_delete:
                q.is_active = False
            else:
                session.delete(q)
            return True

    def increment_sql_query_execution(self, query_id: int):
        """Bump execution counter and last_executed_at timestamp."""
        with self.get_session() as session:
            q = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if q:
                q.execution_count = (q.execution_count or 0) + 1
                q.last_executed_at = datetime.now(timezone.utc)

    # ── SQL File operations (Phase 122C) ─────────────────────────────────────

    def create_sql_file(self, **kwargs) -> Dict[str, Any]:
        """Create a new SqlFile record."""
        with self.get_session() as session:
            sf = SqlFile(**kwargs)
            session.add(sf)
            session.flush()
            return sf.to_dict()

    def get_sql_file(self, file_id: int) -> Optional[Dict[str, Any]]:
        """Get a single SQL file by ID."""
        with self.get_session(read_only=True) as session:
            sf = session.query(SqlFile).filter(SqlFile.id == file_id).first()
            return sf.to_dict() if sf else None

    def list_sql_files(self, connection_id: int = None, created_by: str = None,
                       include_shared: bool = True, active_only: bool = True,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """List SQL files, newest first, with optional filters."""
        with self.get_session(read_only=True) as session:
            query = session.query(SqlFile)
            if active_only:
                query = query.filter(SqlFile.is_active)
            if connection_id:
                query = query.filter(SqlFile.connection_id == connection_id)
            if created_by and include_shared:
                query = query.filter(
                    (SqlFile.created_by == created_by) | (SqlFile.is_shared)
                )
            elif created_by:
                query = query.filter(SqlFile.created_by == created_by)
            rows = query.order_by(SqlFile.updated_at.desc()).limit(limit).offset(offset).all()
            return [r.to_dict() for r in rows]

    def update_sql_file(self, file_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update fields of an existing SQL file."""
        with self.get_session() as session:
            sf = session.query(SqlFile).filter(SqlFile.id == file_id).first()
            if not sf:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(sf, key):
                    setattr(sf, key, value)
            sf.updated_at = datetime.now(timezone.utc)
            session.flush()
            return sf.to_dict()

    def delete_sql_file(self, file_id: int, soft_delete: bool = True) -> bool:
        """Delete or soft-delete a SQL file."""
        with self.get_session() as session:
            sf = session.query(SqlFile).filter(SqlFile.id == file_id).first()
            if not sf:
                return False
            if soft_delete:
                sf.is_active = False
            else:
                session.delete(sf)
            return True

    # ── Query Cache operations ─────────────────────────────────────────────────

    def get_cache_entry(self, cache_key: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            e = session.query(QueryCacheEntry).filter(QueryCacheEntry.cache_key == cache_key).first()
            return e.to_dict() if e else None

    def set_cache_entry(self, cache_key: str, file_path: str,
                        row_count: int = 0, file_size_bytes: int = 0,
                        expires_at: Optional[datetime] = None,
                        query_config: Optional[dict] = None,
                        connection_id: Optional[int] = None,
                        source_fingerprint: Optional[str] = None,
                        source_tables_json: Optional[list] = None) -> Dict[str, Any]:
        """Upsert a cache entry — safe for concurrent writers on the same key."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            # Try insert first; on PK conflict, update in place.
            try:
                e = QueryCacheEntry(
                    cache_key=cache_key, file_path=file_path,
                    row_count=row_count, file_size_bytes=file_size_bytes,
                    expires_at=expires_at, query_config=query_config,
                    connection_id=connection_id,
                    source_fingerprint=source_fingerprint,
                    source_tables_json=source_tables_json,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                # PK conflict — another thread inserted first; update instead.
                existing = session.query(QueryCacheEntry).filter(
                    QueryCacheEntry.cache_key == cache_key
                ).first()
                if existing:
                    existing.file_path = file_path
                    existing.row_count = row_count
                    existing.file_size_bytes = file_size_bytes
                    existing.expires_at = expires_at
                    existing.created_at = now
                    existing.query_config = query_config
                    existing.connection_id = connection_id
                    existing.source_fingerprint = source_fingerprint
                    existing.source_tables_json = source_tables_json
                    session.flush()
                    return existing.to_dict()
                # Extremely unlikely: another thread deleted between our
                # failed insert and this query — just retry the insert.
                e2 = QueryCacheEntry(
                    cache_key=cache_key, file_path=file_path,
                    row_count=row_count, file_size_bytes=file_size_bytes,
                    expires_at=expires_at, query_config=query_config,
                    connection_id=connection_id,
                    source_fingerprint=source_fingerprint,
                    source_tables_json=source_tables_json,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_cache_entry(self, cache_key: str) -> bool:
        with self.get_session() as session:
            e = session.query(QueryCacheEntry).filter(QueryCacheEntry.cache_key == cache_key).first()
            if not e:
                return False
            session.delete(e)
            return True

    def delete_expired_cache_entries(self) -> int:
        with self.get_session() as session:
            now = datetime.now(timezone.utc)
            expired = session.query(QueryCacheEntry).filter(
                QueryCacheEntry.expires_at != None,  # noqa: E711  (SQLAlchemy: `is None` is always False on a Column)
                QueryCacheEntry.expires_at < now,
            ).all()
            count = len(expired)
            for e in expired:
                session.delete(e)
            return count

    def list_cache_entries(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(QueryCacheEntry).order_by(QueryCacheEntry.created_at.desc()).all()
            return [e.to_dict() for e in rows]

    def increment_cache_hit(self, cache_key: str) -> None:
        """Increment the hit counter for a cache entry."""
        with self.get_session() as session:
            entry = session.query(QueryCacheEntry).filter_by(cache_key=cache_key).first()
            if entry:
                entry.hit_count = (entry.hit_count or 0) + 1
                session.flush()

    # ── Snapshot Tracker CRUD (Phase 104) ────────────────────────────────────

    def get_snapshot_tracker(self, connection_id: int, table_name: str) -> Optional[Dict[str, Any]]:
        """Return the SnapshotTracker entry for a (connection_id, table_name) pair, or None."""
        with self.get_session(read_only=True) as session:
            row = session.query(SnapshotTracker).filter_by(
                connection_id=connection_id, table_name=table_name
            ).first()
            return row.to_dict() if row else None

    def upsert_snapshot_tracker(self, connection_id: int, table_name: str,
                                 table_format: Optional[str] = None,
                                 snapshot_id: Optional[str] = None,
                                 file_list_hash: Optional[str] = None,
                                 file_count: Optional[int] = None,
                                 changed: bool = False) -> Dict[str, Any]:
        """Upsert the SnapshotTracker entry for a table. Set changed=True to update changed_at."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            row = session.query(SnapshotTracker).filter_by(
                connection_id=connection_id, table_name=table_name
            ).first()
            if row is None:
                row = SnapshotTracker(
                    connection_id=connection_id,
                    table_name=table_name,
                    table_format=table_format,
                    snapshot_id=snapshot_id,
                    file_list_hash=file_list_hash,
                    file_count=file_count,
                    checked_at=now,
                    changed_at=now if changed else None,
                )
                session.add(row)
            else:
                if table_format is not None:
                    row.table_format = table_format
                if snapshot_id is not None:
                    row.snapshot_id = snapshot_id
                if file_list_hash is not None:
                    row.file_list_hash = file_list_hash
                if file_count is not None:
                    row.file_count = file_count
                row.checked_at = now
                if changed:
                    row.changed_at = now
            session.flush()
            return row.to_dict()

    def list_snapshot_trackers(self, connection_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """List all SnapshotTracker entries, optionally filtered by connection_id."""
        with self.get_session(read_only=True) as session:
            q = session.query(SnapshotTracker)
            if connection_id is not None:
                q = q.filter_by(connection_id=connection_id)
            return [r.to_dict() for r in q.order_by(SnapshotTracker.table_name).all()]

    # ── Partition Cache operations ────────────────────────────────────────────

    def get_partition_cache(self, connection_id: int, table_name: str,
                            scan_type: str = "fast",
                            s3_prefix: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            e = session.query(PartitionCache).filter(
                PartitionCache.connection_id == connection_id,
                PartitionCache.table_name == table_name,
                prefix_matches(PartitionCache.s3_prefix, s3_prefix),
                PartitionCache.scan_type == scan_type,
            ).first()
            return e.to_dict() if e else None

    def set_partition_cache(self, connection_id: int, table_name: str,
                            scan_type: str, partition_data: dict,
                            s3_prefix: str = "") -> Dict[str, Any]:
        """Upsert partition cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            # 2026-09-26 -- LOOK UP FIRST, under either prefix spelling.  This
            # used to be insert-first and reach the both-spellings lookup only
            # on a unique-index conflict; a legacy row stored as ``p/`` never
            # conflicts with a canonical ``p`` insert, so the "upsert" wrote a
            # twin and the reader's ``.first()`` served whichever it met.
            existing = session.query(PartitionCache).filter(
                PartitionCache.connection_id == connection_id,
                PartitionCache.table_name == table_name,
                prefix_matches(PartitionCache.s3_prefix, s3_prefix),
                PartitionCache.scan_type == scan_type,
            ).first()
            if existing:
                existing.partition_data = partition_data
                existing.updated_at = now
                session.flush()
                return existing.to_dict()
            try:
                e = PartitionCache(
                    connection_id=connection_id, table_name=table_name,
                    s3_prefix=s3_prefix, scan_type=scan_type,
                    partition_data=partition_data,
                    created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(PartitionCache).filter(
                    PartitionCache.connection_id == connection_id,
                    PartitionCache.table_name == table_name,
                    prefix_matches(PartitionCache.s3_prefix, s3_prefix),
                    PartitionCache.scan_type == scan_type,
                ).first()
                if existing:
                    existing.partition_data = partition_data
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = PartitionCache(
                    connection_id=connection_id, table_name=table_name,
                    s3_prefix=s3_prefix, scan_type=scan_type,
                    partition_data=partition_data,
                    created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_partition_cache(self, connection_id: Optional[int] = None,
                               table_name: Optional[str] = None,
                               s3_prefix: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(PartitionCache)
            if connection_id is not None:
                q = q.filter(PartitionCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(PartitionCache.table_name == table_name)
            if s3_prefix is not None:
                q = q.filter(prefix_matches(PartitionCache.s3_prefix, s3_prefix))
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def delete_partition_cache_for_connection(self, connection_id: int) -> int:
        """Phase 78N: Delete all L2 partition cache entries for a connection. Returns count."""
        return self.delete_partition_cache(connection_id=connection_id)

    def count_partition_cache_entries(self, level: str = "l2") -> int:
        """Phase 78O: Count partition cache entries (level='l1' uses in-memory dict via API)."""
        with self.get_session(read_only=True) as session:
            return session.query(PartitionCache).count()

    def list_partition_cache_entries(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(PartitionCache).order_by(
                PartitionCache.updated_at.desc()
            ).all()
            return [e.to_dict() for e in rows]

    def get_connection_partitions(self, connection_id: int, table_name: str) -> List[Dict[str, str]]:
        """Return partition columns for a connection+table from partition cache.

        Returns list of dicts like [{"column": "businessdate"}, {"column": "code"}].
        Falls back to empty list if no cache entry exists.
        """
        for scan in ("fast", "full"):
            entry = self.get_partition_cache(connection_id, table_name, scan_type=scan)
            if entry:
                pdata = entry.get("partition_data") or {}
                cols = pdata.get("partition_columns", [])
                return [{"column": c.get("name", c.get("source_column", ""))} for c in cols if isinstance(c, dict)]
        return []

    # ── Iceberg File Cache operations ────────────────────────────────────────

    def get_iceberg_file_cache(self, connection_id: int, table_name: str,
                                filters_hash: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            e = session.query(IcebergFileCache).filter(
                IcebergFileCache.connection_id == connection_id,
                IcebergFileCache.table_name == table_name,
                IcebergFileCache.filters_hash == filters_hash,
            ).first()
            return e.to_dict() if e else None

    def set_iceberg_file_cache(self, connection_id: int, table_name: str,
                                filters_hash: str, file_list: list) -> Dict[str, Any]:
        """Upsert Iceberg file cache — safe for concurrent writers."""
        # SIZE GUARD (2026-07-22): SAME ~1 GB Postgres-value risk as the snapshot
        # cache — a huge (poorly-pruned) survivor list stored in one JSON column
        # raises psycopg2 "invalid memory alloc request size" on flush.  Skip
        # fail-open above the cap: no L2 cache for this query, correctness
        # unaffected (the reader re-derives the list).  Shares the snapshot
        # cache's file-count cap so one setting bounds both file-list caches.
        _n = len(file_list or [])
        try:
            from core.config import get as _cfg_g
            _cap = int(_cfg_g("iceberg", "snapshot_cache_max_files", 200000) or 0)
        except Exception:
            _cap = 200000
        if _cap > 0 and _n > _cap:
            import logging as _l
            _l.getLogger(__name__).warning(
                "set_iceberg_file_cache: SKIP — %d files exceeds cap %d for "
                "%s/%s (too large for one Postgres JSON value; fail-open, no L2).",
                _n, _cap, connection_id, table_name,
            )
            return {}
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = IcebergFileCache(
                    connection_id=connection_id, table_name=table_name,
                    filters_hash=filters_hash, file_list=file_list,
                    file_count=len(file_list), created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(IcebergFileCache).filter(
                    IcebergFileCache.connection_id == connection_id,
                    IcebergFileCache.table_name == table_name,
                    IcebergFileCache.filters_hash == filters_hash,
                ).first()
                if existing:
                    existing.file_list = file_list
                    existing.file_count = len(file_list)
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = IcebergFileCache(
                    connection_id=connection_id, table_name=table_name,
                    filters_hash=filters_hash, file_list=file_list,
                    file_count=len(file_list), created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def list_iceberg_file_cache(self, connection_id: Optional[int] = None) -> list:
        with self.get_session(read_only=True) as session:
            q = session.query(IcebergFileCache)
            if connection_id is not None:
                q = q.filter(IcebergFileCache.connection_id == connection_id)
            return [e.to_dict() for e in q.all()]

    def delete_iceberg_file_cache(self, connection_id: Optional[int] = None,
                                   table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(IcebergFileCache)
            if connection_id is not None:
                q = q.filter(IcebergFileCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(IcebergFileCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    # ── BF-296: Iceberg snapshot-keyed contents cache ────────────────────────

    # 2026-06-04 — same perf bug as manifest cache.  In-memory recency
    # dict; LRU eviction flushes back to DB column.
    _SNAPSHOT_CACHE_RECENCY: Dict[int, float] = {}
    _SNAPSHOT_CACHE_RECENCY_LOCK = threading.Lock()

    def get_iceberg_snapshot_cache(self, bucket: str, table_prefix: str,
                                     snapshot_id: str) -> Optional[Dict[str, Any]]:
        # 2026-06-09 — undefer files_data so the SELECT returns the
        # JSON column in ONE round-trip instead of triggering an N+1
        # lazy-load when the caller accesses .files_data below.  Pre-
        # fix the per-table snapshot read hit 12+ seconds (user log
        # 09:25:12) because SQLAlchemy did two queries: cheap row +
        # heavy lazy-load of the JSON.  One query = one network
        # round-trip = bounded latency.
        import time as _time
        from sqlalchemy.orm import undefer as _undefer
        with self.get_session(read_only=True) as session:
            e = session.query(IcebergSnapshotCache).options(
                _undefer(IcebergSnapshotCache.files_data)
            ).filter(
                IcebergSnapshotCache.bucket == bucket,
                prefix_matches(IcebergSnapshotCache.table_prefix, table_prefix),
                IcebergSnapshotCache.snapshot_id == str(snapshot_id),
            ).first()
            if not e:
                return None
            # In-memory recency stamp (no DB write).
            try:
                with DatabaseManager._SNAPSHOT_CACHE_RECENCY_LOCK:
                    DatabaseManager._SNAPSHOT_CACHE_RECENCY[e.id] = _time.time()
            except Exception:
                pass
            return {
                "id":            e.id,
                "bucket":        e.bucket,
                "table_prefix":  e.table_prefix,
                "snapshot_id":   e.snapshot_id,
                "files_data":    e.files_data,
                "storage_mode":  getattr(e, "storage_mode", "blob") or "blob",
                "file_count":    e.file_count,
                "bytes_total":   e.bytes_total,
                "created_at":    e.created_at.isoformat() if e.created_at else None,
                "last_accessed": e.last_accessed.isoformat() if e.last_accessed else None,
            }

    def set_iceberg_snapshot_cache(self, bucket: str, table_prefix: str,
                                     snapshot_id: str, files_data: list,
                                     file_count: int = 0,
                                     bytes_total: int = 0,
                                     storage_mode: str = "blob") -> Dict[str, Any]:
        """Upsert the snapshot-keyed contents cache header.  storage_mode='rows'
        writes a header/completeness marker (files_data None/[]); the per-file
        rows live in iceberg_snapshot_files."""
        now = datetime.now(timezone.utc)
        # 2026-06-04 — structured logging so a Postgres write storm
        # (encoder gap, constraint violation, transaction rollback) is
        # diagnosable from the log alone.
        import logging as _sc_log
        _logger_sc = _sc_log.getLogger(__name__)
        try:
            with self.get_session() as session:
                existing = session.query(IcebergSnapshotCache).filter(
                    IcebergSnapshotCache.bucket == bucket,
                    prefix_matches(IcebergSnapshotCache.table_prefix, table_prefix),
                    IcebergSnapshotCache.snapshot_id == str(snapshot_id),
                ).first()
                if existing:
                    _logger_sc.info(
                        "set_iceberg_snapshot_cache UPDATE: id=%s bucket=%r "
                        "table_prefix=%r snapshot_id=%r file_count=%d",
                        existing.id, bucket, table_prefix, snapshot_id,
                        int(file_count or len(files_data or [])),
                    )
                    existing.files_data    = files_data
                    existing.storage_mode  = storage_mode
                    existing.file_count    = int(file_count or len(files_data or []))
                    existing.bytes_total   = int(bytes_total or 0)
                    existing.last_accessed = now
                    session.flush()
                    _logger_sc.info(
                        "set_iceberg_snapshot_cache UPDATE-OK: id=%s",
                        existing.id,
                    )
                    return existing.to_dict()
                _logger_sc.info(
                    "set_iceberg_snapshot_cache INSERT: bucket=%r "
                    "table_prefix=%r snapshot_id=%r file_count=%d",
                    bucket, table_prefix, snapshot_id,
                    int(file_count or len(files_data or [])),
                )
                e = IcebergSnapshotCache(
                    bucket=bucket, table_prefix=table_prefix,
                    snapshot_id=str(snapshot_id), files_data=files_data,
                    storage_mode=storage_mode,
                    file_count=int(file_count or len(files_data or [])),
                    bytes_total=int(bytes_total or 0),
                    created_at=now, last_accessed=now,
                )
                session.add(e)
                session.flush()
                _logger_sc.info(
                    "set_iceberg_snapshot_cache COMMIT-OK: id=%s",
                    e.id,
                )
                return e.to_dict()
        except Exception as _sc_ins_exc:
            _logger_sc.error(
                "set_iceberg_snapshot_cache FAILED: bucket=%r "
                "table_prefix=%r snapshot_id=%r files=%d type=%s msg=%s",
                bucket, table_prefix, snapshot_id, len(files_data or []),
                type(_sc_ins_exc).__name__, str(_sc_ins_exc)[:400],
                exc_info=True,
            )
            raise

    def list_iceberg_snapshot_cache(self, bucket: Optional[str] = None,
                                      limit: int = 100) -> list:
        with self.get_session(read_only=True) as session:
            q = session.query(IcebergSnapshotCache)
            if bucket is not None:
                q = q.filter(IcebergSnapshotCache.bucket == bucket)
            q = q.order_by(IcebergSnapshotCache.last_accessed.desc()).limit(limit)
            return [e.to_dict() for e in q.all()]

    def iceberg_snapshot_cache_summary(self, bucket: Optional[str] = None) -> dict:
        """Fast aggregate (COUNT + SUMs) for the admin /stats endpoint.

        Replaces the slow path of fetching 1000 rows + summing in Python
        — that took ~10 s and was blocking the asyncio loop, starving
        WebSocket heartbeats.  This is a single SQL query: O(table size)
        on the DB engine but returns one row.
        """
        from sqlalchemy import func
        with self.get_session(read_only=True) as session:
            q = session.query(
                func.count(IcebergSnapshotCache.id),
                func.coalesce(func.sum(IcebergSnapshotCache.file_count), 0),
                func.coalesce(func.sum(IcebergSnapshotCache.bytes_total), 0),
            )
            if bucket is not None:
                q = q.filter(IcebergSnapshotCache.bucket == bucket)
            row = q.first()
            return {
                "l2_row_count":    int(row[0] or 0) if row else 0,
                "l2_total_files":  int(row[1] or 0) if row else 0,
                "l2_total_bytes":  int(row[2] or 0) if row else 0,
            }

    def delete_iceberg_snapshot_cache(self, *, bucket: Optional[str] = None,
                                        table_prefix: Optional[str] = None,
                                        snapshot_id: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(IcebergSnapshotCache)
            if bucket is not None:
                q = q.filter(IcebergSnapshotCache.bucket == bucket)
            if table_prefix is not None:
                q = q.filter(prefix_matches(IcebergSnapshotCache.table_prefix, table_prefix))
            if snapshot_id is not None:
                q = q.filter(IcebergSnapshotCache.snapshot_id == str(snapshot_id))
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            # 2026-09-25 (Docker E2E audit): the per-FILE rows and the island
            # index survived a clear.  Their store is insert-only per
            # snapshot (a file row that exists is skipped, and index rows are
            # written only for files inserted), so a clear re-stored the
            # header over the OLD file rows and the OLD index -- an index
            # written with a wrong value (form-encoded "MIDDLE+EAST") could
            # never be repaired short of a new snapshot.  A clear means every
            # layer, with the same filters.
            from core.db.models import (
                IcebergFilePartitionIndex as _PIX_CLR,
                IcebergSnapshotFiles as _SF_CLR,
            )
            for _model in (_PIX_CLR, _SF_CLR):
                q2 = session.query(_model)
                if bucket is not None:
                    q2 = q2.filter(_model.bucket == bucket)
                if table_prefix is not None:
                    q2 = q2.filter(prefix_matches(_model.table_prefix, table_prefix))
                if snapshot_id is not None:
                    q2 = q2.filter(_model.snapshot_id == str(snapshot_id))
                q2.delete(synchronize_session=False)
            return count

    # ── BF-COL-STATS: per-file column min/max/null supplement table ─────────

    # 2026-06-04 — hard cap on per-flush row count.  Postgres has a
    # 65535-bound-parameter ceiling per query; SQLAlchemy autoflush of
    # a session with N inserts on a model with M columns sends
    # N × M parameters.  With our 12-column row shape, ~5000 rows is
    # the per-flush ceiling.  Conservatively cap at 1000 so a fat
    # batch from a long-running scanner doesn't blow the connection
    # OR hold an oversize transaction lock.
    _COL_STATS_FLUSH_CHUNK = 1000

    def iceberg_file_stats_upsert_batch(
        self, records: list,
    ) -> int:
        """2026-07-13 — bulk upsert per-FILE stats rows (iceberg_file_stats_v3).

        ONE row per file, keyed on (bucket, table_prefix, snapshot_id,
        file_path).  Each record dict has: bucket, table_prefix, snapshot_id,
        file_path, column_stats (a dict {col_lower: {"lo","hi","nulls"}}),
        row_count, file_size, format; connection_id / table_name optional.

        Mirrors ``iceberg_col_stats_upsert_batch`` (chunking, in-batch dedup,
        one bulk-fetch, last-write-wins) but at the per-file grain — so a
        3000-file × 40-col scan writes 3000 rows here instead of 120,000.
        Idempotent; returns rows affected.
        """
        if not records:
            return 0
        if len(records) > self._COL_STATS_FLUSH_CHUNK:
            total = 0
            for i in range(0, len(records), self._COL_STATS_FLUSH_CHUNK):
                chunk = records[i : i + self._COL_STATS_FLUSH_CHUNK]
                try:
                    total += self.iceberg_file_stats_upsert_batch(chunk)
                except Exception as _ce:
                    logger.error(
                        "iceberg_file_stats_upsert_batch CHUNK-FAILED "
                        "offset=%d size=%d: %s", i, len(chunk), _ce,
                        exc_info=True,
                    )
            return total

        now = datetime.now(timezone.utc)
        affected = 0
        # Collapse duplicate (bucket, prefix, snapshot, file) keys within the
        # batch (last-write-wins) — session.add() won't detect an uncommitted
        # dup and would raise UNIQUE-constraint at flush.
        deduped: Dict[Tuple, dict] = {}
        for r in records:
            r["table_prefix"] = canonical_prefix(r.get("table_prefix"))
            key = (
                r.get("bucket") or "",
                r["table_prefix"],
                str(r.get("snapshot_id") or ""),
                r.get("file_path") or "",
            )
            if not key[3]:
                continue   # missing file_path
            deduped[key] = r

        with self.get_session() as session:
            keys_list = list(deduped.keys())
            existing_map: Dict[Tuple, IcebergFileStats] = {}
            if keys_list:
                buckets = {k[0] for k in keys_list}
                prefixes = {k[1] for k in keys_list}
                snapshots = {k[2] for k in keys_list}
                # 2026-08-24 — BOUNDED BY THE FILES BEING WRITTEN.  This
                # prefetch used to omit file_path, so it loaded every row for
                # the snapshot as a full ORM entity (each carrying its fat
                # column_stats JSON) and then threw most of them away in the
                # ``if rk in deduped`` test below.  The sibling function below
                # records this same shape as "a 22s blob rewrite"; its key-only
                # fix cannot be copied here because this path needs the entity
                # to merge into, so we bound the ROWS instead of the columns.
                #
                # Identical behaviour: every row this filter now excludes was
                # already discarded by the deduped test, so existing_map is
                # unchanged — only the bytes crossing the wire differ.
                #
                # Chunked at 800 (the _IN_CHUNK_SIZE convention in this file):
                # a batch is capped at 1000 records, and 1000 bind params plus
                # the three other IN lists can exceed SQLite's default
                # host-parameter limit, which the test suite runs on.
                _files = [k[3] for k in keys_list]
                _PREFETCH_IN_CHUNK = 800
                for _i in range(0, len(_files), _PREFETCH_IN_CHUNK):
                    rows = session.query(IcebergFileStats).filter(
                        IcebergFileStats.bucket.in_(buckets),
                        prefix_matches_any(IcebergFileStats.table_prefix, prefixes),
                        IcebergFileStats.snapshot_id.in_(snapshots),
                        IcebergFileStats.file_path.in_(
                            _files[_i:_i + _PREFETCH_IN_CHUNK]),
                    ).all()
                    for row in rows:
                        rk = (row.bucket, canonical_prefix(row.table_prefix),
                              str(row.snapshot_id), row.file_path)
                        if rk in deduped:
                            existing_map[rk] = row

            for key, r in deduped.items():
                try:
                    _cs = r.get("column_stats") or {}
                    existing = existing_map.get(key)
                    if existing:
                        # 2026-08-21 — MERGE, do not replace.  A scan with a
                        # narrow target_columns (the query-path footer capture
                        # asks only for the columns THIS query filters on)
                        # otherwise DELETES every other column's bounds from
                        # the row, so each query destroys the evidence the
                        # previous one captured.  A data file is immutable, so
                        # bounds captured earlier for other columns stay valid;
                        # a re-scan of the same column overwrites its own entry.
                        _prev = existing.column_stats
                        if isinstance(_prev, dict) and isinstance(_cs, dict):
                            _merged = dict(_prev)
                            _merged.update(_cs)
                            existing.column_stats = _merged
                        else:
                            existing.column_stats = _cs
                        existing.row_count = int(r.get("row_count") or 0)
                        existing.file_size = int(r.get("file_size") or 0)
                        existing.scanned_at = now
                        if r.get("connection_id") is not None:
                            existing.connection_id = r.get("connection_id")
                        if r.get("table_name"):
                            existing.table_name = r.get("table_name")
                        if r.get("format"):
                            existing.format = r.get("format")
                        # Level-1 partition index — set only when the incoming
                        # record carries it; NEVER null out an existing capture
                        # (a source without it must not erase a good value).
                        if r.get("partition_values"):
                            existing.partition_values = r.get("partition_values")
                    else:
                        session.add(IcebergFileStats(
                            bucket=r["bucket"],
                            table_prefix=r["table_prefix"],
                            connection_id=r.get("connection_id"),
                            table_name=r.get("table_name"),
                            snapshot_id=str(r["snapshot_id"]),
                            file_path=r["file_path"],
                            column_stats=_cs,
                            row_count=int(r.get("row_count") or 0),
                            file_size=int(r.get("file_size") or 0),
                            scanned_at=now,
                            format=r.get("format") or "iceberg",
                            partition_values=r.get("partition_values") or None,
                        ))
                    affected += 1
                except Exception as _e:
                    logger.debug("file_stats upsert skip: %s", _e)
            try:
                session.flush()
            except Exception as _flush_exc:
                logger.warning(
                    "file_stats batch flush failed: type=%s msg=%s count=%d "
                    "— rolled back (v3 mirror is best-effort)",
                    type(_flush_exc).__name__, str(_flush_exc)[:300],
                    len(deduped), exc_info=True,
                )
                session.rollback()
                affected = 0
        return affected

    def iceberg_snapshot_files_upsert_batch(self, records: list) -> int:
        """2026-07 — INSERT-ONLY bulk upsert of per-file snapshot enumeration
        rows (iceberg_snapshot_files).  ONE row per live data file, keyed
        (bucket, table_prefix, snapshot_id, file_path).

        Insert-only (not last-write-wins) BY DESIGN: a snapshot's file set is
        immutable, so a row that already exists is byte-identical — we prefetch
        ONLY the file_path keys for the snapshot (never load the fat entry_data
        of existing rows back) and skip files already present.  This makes a
        BF-500 force_fresh re-store a near-free no-op instead of a 22s blob
        rewrite.  Fat rows → chunk at 500.  Idempotent; returns rows inserted."""
        from core.db.models import IcebergFilePartitionIndex as _PIX
        from core.db.models import IcebergSnapshotFiles as _SF
        if not records:
            return 0
        _CHUNK = 500
        if len(records) > _CHUNK:
            total = 0
            for i in range(0, len(records), _CHUNK):
                total += self.iceberg_snapshot_files_upsert_batch(
                    records[i:i + _CHUNK])
            return total
        # in-batch dedup (last wins) so a manifest listing a file twice can't
        # raise UNIQUE at flush
        deduped: Dict[Tuple, dict] = {}
        for r in records:
            r["table_prefix"] = canonical_prefix(r.get("table_prefix"))
            deduped[(r.get("bucket") or "", r["table_prefix"],
                     str(r.get("snapshot_id") or ""), r.get("file_path") or "")] = r
        inserted = 0
        # (bucket, prefix, snapshot, part_key, part_value, file_path) -> True.
        # A dict, so duplicates within the batch collapse instead of becoming
        # two rows with the same unique key.
        _pix_rows = {}
        with self.get_session() as session:
            keys = list(deduped.keys())
            buckets = {k[0] for k in keys}
            prefixes = {k[1] for k in keys}
            snaps = {k[2] for k in keys}
            # KEY-ONLY prefetch — never pulls entry_data back.
            existing: set = set()
            if keys:
                for (b, tp, sn, fp) in session.query(
                        _SF.bucket, _SF.table_prefix, _SF.snapshot_id, _SF.file_path
                ).filter(_SF.bucket.in_(buckets),
                         prefix_matches_any(_SF.table_prefix, prefixes),
                         _SF.snapshot_id.in_(snaps)).all():
                    existing.add((b, canonical_prefix(tp), str(sn), fp))
            for key, r in deduped.items():
                if key in existing:
                    continue
                try:
                    session.add(_SF(
                        bucket=r["bucket"], table_prefix=r["table_prefix"],
                        snapshot_id=str(r["snapshot_id"]),
                        file_path=r["file_path"],
                        manifest_path=r.get("manifest_path"),
                        status=int(r.get("status") or 1),
                        record_count=int(r.get("record_count") or 0),
                        file_size=int(r.get("file_size") or 0),
                        partition_values=r.get("partition_values") or None,
                        entry_data=r.get("entry_data"),
                    ))
                    inserted += 1
                    # 2026-08-19 — mirror the partition tokens into the
                    # natively-indexed seek table.
                    #
                    # 2026-08-20 — COLLECTED HERE, WRITTEN SEPARATELY.  These
                    # rows used to be ``session.add``-ed into the SAME session
                    # as the file rows, which inverted the design this comment
                    # states.  The per-row ``try`` caught nothing: ``add()``
                    # does not touch the database, so a constraint violation
                    # surfaces at ``flush()`` — outside that try — where the
                    # handler rolls the whole session back.  One bad index row
                    # therefore DISCARDED EVERY FILE ROW IN THE BATCH.
                    #
                    # Field-observed, repeating every few seconds:
                    #     iceberg_snapshot_files batch flush failed:
                    #     duplicate key value violates unique constraint
                    #     "ix_iceberg_file_partition_seek" — rolled back
                    #
                    # The consequence is not a missing index, it is a SNAPSHOT
                    # FILE STORE THAT NEVER POPULATES: every query re-walks the
                    # manifests from S3, re-attempts the same doomed insert, and
                    # fails the same way forever.  The accelerator was taking
                    # the truth down with it.
                    #
                    # The file row is the truth and commits on its own.  The
                    # index is written afterwards, in its own transaction, and
                    # can fail without costing anything but speed — the reader
                    # uses the seek only when it can prove COMPLETE coverage,
                    # so a missing or partial index degrades to a scan.
                    _pv = r.get("partition_values") or {}
                    if isinstance(_pv, dict):
                        for _pk, _pval in _pv.items():
                            if _pk is None:
                                continue
                            # Keyed, so a duplicate cannot reach the DB.  Two
                            # spellings of one column ("Month"/"month") collapse
                            # to the same lowered part_key and would otherwise
                            # be two rows with identical index keys.
                            _pix_rows[(
                                r["bucket"], r["table_prefix"],
                                str(r["snapshot_id"]), str(_pk).lower(),
                                # None stays None -- the null partition.
                                # Skipping it would drop this table below full
                                # coverage and disable the seek.
                                (None if _pval is None else str(_pval)),
                                r["file_path"],
                            )] = True
                except Exception as _e:
                    logger.debug("snapshot_files insert skip: %s", _e)
            try:
                session.flush()
            except Exception as _flush_exc:
                # NOT truncated to 200 chars any more: Postgres names the
                # offending constraint AND lists its columns in the DETAIL
                # line, and the old cut landed mid-DETAIL — which is the
                # difference between "some duplicate" and "the deployed index
                # is missing file_path".
                logger.warning(
                    "iceberg_snapshot_files batch flush failed (%d rows) — "
                    "rolled back: %s",
                    inserted, str(_flush_exc)[:800])
                session.rollback()
                inserted = 0
                _pix_rows = {}
        # Outside the session: the file rows are committed, so nothing that
        # happens now can take them with it.
        if _pix_rows:
            self._iceberg_partition_index_mirror(_pix_rows)
        return inserted

    def _iceberg_partition_index_mirror(self, pix_keys) -> int:
        """Write partition seek-index rows in their OWN transaction.

        2026-08-20.  Deliberately isolated from ``iceberg_snapshot_files``:
        this table is an ACCELERATOR.  Losing a row here costs a query some
        time; losing the file rows costs a full manifest re-walk on every
        subsequent query, forever.  Those two must not share a fate, and
        before this they did.

        Never raises.  Returns rows written.
        """
        from core.db.models import IcebergFilePartitionIndex as _PIX
        if not pix_keys:
            return 0
        written = 0
        try:
            with self.get_session() as session:
                # Prefetch the keys that already exist for these snapshots.
                # The file-row loop only reaches here for files it is INSERTING
                # for the first time, but the index can legitimately be ahead
                # of it — iceberg_partition_index_backfill populates this table
                # from file rows that already exist, and a partial batch from
                # an earlier attempt leaves rows behind.  Without this probe
                # those become UNIQUE violations.
                _trips = {(k[0], k[1], k[2]) for k in pix_keys}
                existing = set()
                for _b, _tp, _sn in _trips:
                    for row in session.query(
                        _PIX.bucket, _PIX.table_prefix, _PIX.snapshot_id,
                        _PIX.part_key, _PIX.part_value, _PIX.file_path,
                    ).filter(_PIX.bucket == _b,
                             prefix_matches(_PIX.table_prefix, _tp),
                             _PIX.snapshot_id == _sn).all():
                        existing.add((row[0], canonical_prefix(row[1]),
                                      str(row[2]), row[3], row[4], row[5]))
                for key in pix_keys:
                    if key in existing:
                        continue
                    session.add(_PIX(
                        bucket=key[0], table_prefix=key[1],
                        snapshot_id=key[2], part_key=key[3],
                        part_value=key[4], file_path=key[5],
                    ))
                    written += 1
                try:
                    session.flush()
                except Exception as _pix_flush_exc:
                    # The file rows are already safe.  Say clearly that only
                    # the accelerator was lost, and name the constraint —
                    # a violation on ix_iceberg_file_partition_seek after the
                    # in-batch dedup and the existing-key probe above means
                    # the DEPLOYED INDEX IS NOT THE ONE THE MODEL DECLARES
                    # (see alembic 019).
                    logger.warning(
                        "partition seek-index mirror failed for %d row(s) — "
                        "rolled back.  File rows are UNAFFECTED; queries stay "
                        "correct and fall back to a scan.  Cause: %s",
                        written, str(_pix_flush_exc)[:800])
                    session.rollback()
                    return 0
        except Exception as _exc:
            logger.debug("partition seek-index mirror skipped: %s", _exc)
            return 0
        return written

    def _iceberg_partition_index_is_empty(
        self, bucket: str, table_prefix: str, snapshot_id: str,
    ) -> bool:
        """True when NO seek rows exist for this snapshot — i.e. it predates
        the index entirely, as opposed to being partially populated."""
        from core.db.models import IcebergFilePartitionIndex as _PIX
        with self.get_session(read_only=True) as session:
            return session.query(_PIX.id).filter(
                _PIX.bucket == bucket,
                prefix_matches(_PIX.table_prefix, table_prefix),
                _PIX.snapshot_id == str(snapshot_id),
            ).first() is None

    def iceberg_partition_index_backfill(
        self, bucket: str, table_prefix: str, snapshot_id: str,
        batch: int = 2000,
    ) -> int:
        """Populate the seek index from ``partition_values`` already stored on
        ``iceberg_snapshot_files``.  Returns rows written.

        Existing deployments have millions of file rows whose partition
        tokens were captured long before this index existed.  Re-walking the
        manifests to get them back would cost an S3 scan per table; the
        values are already in the database, so derive them there.

        Idempotent: rows already present are skipped, so this is safe to run
        repeatedly and safe to interrupt.  Writes nothing for files with no
        captured partition values — those keep the snapshot's coverage count
        below the file count, which is exactly the condition that makes the
        reader decline the index and fall back.
        """
        from core.db.models import IcebergFilePartitionIndex as _PIX
        from core.db.models import IcebergSnapshotFiles as _SF
        table_prefix = canonical_prefix(table_prefix)
        snap = str(snapshot_id)
        written = 0
        with self.get_session() as session:
            have = {
                (k, v, fp)
                for (k, v, fp) in session.query(
                    _PIX.part_key, _PIX.part_value, _PIX.file_path).filter(
                    _PIX.bucket == bucket,
                    prefix_matches(_PIX.table_prefix, table_prefix),
                    _PIX.snapshot_id == snap).all()
            }
            rows = session.query(_SF.file_path, _SF.partition_values).filter(
                _SF.bucket == bucket,
                prefix_matches(_SF.table_prefix, table_prefix),
                _SF.snapshot_id == snap,
            ).yield_per(batch)
            for file_path, pv in rows:
                if not isinstance(pv, dict) or not file_path:
                    continue
                for pk, pval in pv.items():
                    if pk is None:
                        continue
                    key = (str(pk).lower(),
                           None if pval is None else str(pval),
                           file_path)
                    if key in have:
                        continue
                    have.add(key)
                    session.add(_PIX(
                        bucket=bucket, table_prefix=table_prefix,
                        snapshot_id=snap, part_key=key[0],
                        part_value=key[1], file_path=file_path,
                    ))
                    written += 1
            if written:
                try:
                    session.flush()
                except Exception as exc:
                    logger.warning(
                        "partition-index backfill flush failed: %s — rolled "
                        "back (index stays absent, reads fall back)",
                        str(exc)[:200])
                    session.rollback()
                    return 0
        if written:
            logger.info(
                "[island-index] backfilled %d row(s) for %s/%s snapshot=%s",
                written, bucket, table_prefix, snap)
        return written

    def iceberg_partition_island_paths(
        self, bucket: str, table_prefix: str, snapshot_id: str,
        island_filters,
    ):
        """2026-08-19 — resolve the ISLAND by indexed seek, or decline.

        Returns the exact set of ``file_path`` values matching every entry of
        ``island_filters`` — legacy ``(col, [values])`` eq/IN entries and,
        since 2026-08-22 (design_s3_speed §4 Phase 1), ``(col, "range",
        payload)`` date-range entries answered as a ``part_value`` range scan
        on the SAME ``ix_iceberg_file_partition_seek`` index — or ``None``
        when the index cannot answer safely, in which case the caller keeps
        its existing behaviour unchanged.  Range bounds must be ISO-canonical
        date tokens (``core.filter_ops.island_range_bound_ops`` refuses
        anything else → decline); rows whose token is NULL or not shaped like
        an ISO date are ALWAYS kept by the range arm (fail-open superset —
        a token this arm cannot order must never be ordered OUT of the
        island).

        WHY THIS EXISTS.  ``partition_values`` is JSON and is in no index, so
        ``partition_values[col] IN (...)`` is a post-filter: seek the
        snapshot, then walk EVERY file row and JSON-extract the key from each.
        Pushing the predicate into SQL removed the transfer cost but not the
        scan — the ocean was still built before the island was found in it.
        Here the leading index columns ARE the seek key, so the database goes
        straight to the matching file paths.

        WHY IT DECLINES RATHER THAN GUESSES.  A pruning structure that is
        merely INCOMPLETE must never look authoritative: the failure mode is
        a silently dropped file, i.e. wrong results.  So for every filtered
        column we require that the number of distinct files carrying that key
        equals the number of files in the snapshot.  Anything less — an
        un-backfilled table, a half-written batch, a partition column that
        only some files declare — returns ``None`` and costs nothing but the
        two COUNTs.
        """
        from sqlalchemy import and_, or_

        from core.db.models import IcebergFilePartitionIndex as _PIX
        from core.db.models import IcebergSnapshotFiles as _SF
        from core.filter_ops import (
            ISO_DATE_SQL_LIKE,
            island_range_bound_ops,
            normalize_island_spec,
            range_symbol_func,
        )
        if not island_filters:
            return None
        table_prefix = canonical_prefix(table_prefix)
        snap = str(snapshot_id)
        try:
            # An entry this vocabulary does not recognise raises here and is
            # caught below → decline (fail-open to the caller's fallback).  A
            # spec must never be HALF-applied.
            _spec = normalize_island_spec(island_filters)
            with self.get_session(read_only=True) as session:
                _scope = (
                    _PIX.bucket == bucket,
                    prefix_matches(_PIX.table_prefix, table_prefix),
                    _PIX.snapshot_id == snap,
                )
                total_files = int(session.query(_SF.file_path).filter(
                    _SF.bucket == bucket,
                    prefix_matches(_SF.table_prefix, table_prefix),
                    _SF.snapshot_id == snap,
                ).distinct().count())
                if total_files <= 0:
                    return None

                keep: Optional[set] = None
                _cov_proven: set = set()
                for _col, _iop, _payload in _spec:
                    col = str(_col).lower()
                    if col not in _cov_proven:
                        covered = int(session.query(_PIX.file_path).filter(
                            *_scope, _PIX.part_key == col).distinct().count())
                        if covered != total_files:
                            # Partial coverage — cannot prove a non-match is a
                            # real non-match.  Decline; caller falls back.
                            logger.debug(
                                "partition-index declines %s/%s key=%r: covers "
                                "%d of %d files", bucket, table_prefix, col,
                                covered, total_files,
                            )
                            return None
                        _cov_proven.add(col)
                    # 2026-08-19 — MATCH THE LEGACY ARM'S FAIL-OPEN SUPERSET.
                    # The JSON path this accelerates keeps a file whose
                    # partition_values is NULL or lacks the key
                    # ("NULL / uncaptured partition_values always kept").
                    # A ``part_value IS NULL`` row counts toward coverage but
                    # can never satisfy ``IN (...)``, so such a file passed
                    # the coverage proof and was then EXCLUDED — the fast path
                    # returning fewer rows than the query it replaces.
                    #
                    # It also mattered directly: parse_hive_partition_values
                    # maps BOTH ``__HIVE_DEFAULT_PARTITION__`` and the EMPTY
                    # token to None, so a genuine ``region=`` directory
                    # queried with ``region = ''`` silently returned nothing.
                    if _iop == "range":
                        # 2026-08-22 — the RANGE arm (design_s3_speed §4
                        # Phase 1).  Same seek key, same index
                        # (ix_iceberg_file_partition_seek), the equality on
                        # part_value replaced by a range scan.  Bounds are
                        # refused unless ISO-canonical (token order == value
                        # order is the admission criterion); tokens NOT shaped
                        # like an ISO date are KEPT, not compared — a token
                        # this arm cannot order must never be ordered OUT.
                        _bops = island_range_bound_ops(_payload)
                        if _bops is None:
                            logger.info(
                                "partition-index declines %s/%s key=%r: range "
                                "payload %r is not ISO-canonical — falling "
                                "back to the unfiltered load.",
                                bucket, table_prefix, col, _payload,
                            )
                            return None
                        rows = session.query(_PIX.file_path).filter(
                            *_scope, _PIX.part_key == col,
                            or_(and_(*[range_symbol_func(_s)(
                                        _PIX.part_value, _b)
                                       for _s, _b in _bops]),
                                _PIX.part_value.is_(None),
                                _PIX.part_value.notlike(ISO_DATE_SQL_LIKE)),
                        ).distinct().all()
                    else:
                        rows = session.query(_PIX.file_path).filter(
                            *_scope, _PIX.part_key == col,
                            or_(_PIX.part_value.in_(
                                    [str(v) for v in _payload]),
                                _PIX.part_value.is_(None)),
                        ).distinct().all()
                    matched = {r[0] for r in rows if r and r[0]}
                    keep = matched if keep is None else (keep & matched)
                    if not keep:
                        break          # empty island — nothing can re-add
                return keep
        except Exception as exc:
            logger.debug("partition-index lookup failed (fail-open): %s", exc)
            return None

    def iceberg_snapshot_files_load(
        self, bucket: str, table_prefix: str, snapshot_id: str,
        island_filters=None,
    ):
        """2026-07 — stream per-file entry_data rows for a snapshot, optionally
        PARTITION-ISLAND filtered.  Returns a flat list of the decoded avro
        entries (the reader wraps them as one pseudo-manifest).  ``island_filters``
        is an island spec — legacy (col_lower, [str_values]) eq/IN entries
        and/or (col, "range", payload) date-range entries (2026-08-22) —
        pushed with the SAME fail-open superset arm as the v3 island load
        (NULL / uncaptured partition_values always kept; a range arm also
        keeps any token not shaped like an ISO date).  Returns None on error
        → caller falls back."""
        from core.db.models import IcebergSnapshotFiles as _SF
        from sqlalchemy import and_, or_

        from core.filter_ops import (
            ISO_DATE_SQL_LIKE,
            island_range_bound_ops,
            normalize_island_spec,
            range_symbol_func,
        )
        table_prefix = canonical_prefix(table_prefix)
        out: list = []

        # 2026-08-19 — FAST PATH: resolve the island by indexed seek first.
        # The JSON predicate below is correct but is a post-filter, so it
        # walks every file row of the snapshot to find the island inside it.
        # ``iceberg_partition_island_paths`` returns the exact file set from
        # an index range seek, or None when it cannot prove complete
        # coverage — in which case we fall through to exactly today's query.
        _island_paths = self.iceberg_partition_island_paths(
            bucket, table_prefix, snapshot_id, island_filters)
        if _island_paths is None and island_filters:
            # SELF-HEAL, ONCE.  Every snapshot stored before this index
            # existed has zero rows here, and snapshots are immutable — they
            # are written once and may never be re-stored, so nothing would
            # ever populate them and the seek would stay permanently unused
            # on exactly the tables that are big enough to need it.
            #
            # Completes an EMPTY or PARTIAL index (2026-08-19): the backfill
            # is idempotent and derives every row from partition_values
            # already stored on the file rows, so there is nothing to guess —
            # a partial index is an unfinished copy, not a suspect one.  The
            # coverage proof still gates the SEEK itself, so a snapshot that
            # genuinely cannot be covered keeps falling back.  The backfill reads
            # the same rows the fallback below is about to scan anyway, from
            # partition_values already in the database — no S3, no manifest
            # walk — so the first query pays roughly what it would have paid,
            # and every later one seeks.
            try:
                # 2026-08-19 — heal PARTIAL coverage too, not just empty.
                # `iceberg_snapshot_files_copy_forward` inserts _SF rows with
                # a raw INSERT..SELECT and no index mirror, so a snapshot that
                # mixes copied manifests with freshly decoded ones is
                # PARTIALLY indexed.  The old "only when EMPTY" rule meant the
                # seek declined forever on exactly the big, incrementally
                # fleet-synced tables it was built for — while still paying
                # two COUNT-DISTINCT probes per query.  The backfill is
                # idempotent (it skips rows already present), so completing a
                # partial index is the same safe operation as filling an empty
                # one; it reads partition_values already in the database.
                if self.iceberg_partition_index_backfill(
                        bucket, table_prefix, snapshot_id):
                        _island_paths = self.iceberg_partition_island_paths(
                            bucket, table_prefix, snapshot_id, island_filters)
            except Exception as _heal_exc:
                logger.debug("partition-index self-heal skipped: %s", _heal_exc)
        if _island_paths is not None:
            if not _island_paths:
                return []                      # provably empty island
            _paths = list(_island_paths)
            _CH = 800                          # keep the IN-list bindable
            with self.get_session(read_only=True) as session:
                for _i in range(0, len(_paths), _CH):
                    rows = session.query(_SF.entry_data).filter(
                        _SF.bucket == bucket,
                        prefix_matches(_SF.table_prefix, table_prefix),
                        _SF.snapshot_id == str(snapshot_id),
                        _SF.file_path.in_(_paths[_i:_i + _CH]),
                    ).yield_per(2000)
                    for (entry,) in rows:
                        if entry is not None:
                            out.append(entry)
            logger.info(
                "[island-index] %s/%s snapshot=%s: %d file(s) resolved by "
                "partition index seek (no snapshot scan)",
                bucket, table_prefix, snapshot_id, len(_paths),
            )
            return out

        with self.get_session(read_only=True) as session:
            q = session.query(_SF.entry_data).filter(
                _SF.bucket == bucket,
                prefix_matches(_SF.table_prefix, table_prefix),
                _SF.snapshot_id == str(snapshot_id))
            for _col, _iop, _payload in normalize_island_spec(
                    island_filters or []):
                _col_expr = _SF.partition_values[_col].as_string()
                if _iop == "range":
                    _bops = island_range_bound_ops(_payload)
                    if _bops is None:
                        # Non-canonical payload — skip THIS conjunct (wider =
                        # safe; the funnel applies the predicate exactly).
                        logger.warning(
                            "[island] range payload for %r not applicable "
                            "(%r) — conjunct skipped, wider load served.",
                            _col, _payload)
                        continue
                    q = q.filter(or_(
                        and_(*[range_symbol_func(_s)(_col_expr, _b)
                               for _s, _b in _bops]),
                        _SF.partition_values.is_(None),
                        _col_expr.is_(None),
                        _col_expr.notlike(ISO_DATE_SQL_LIKE)))
                else:
                    q = q.filter(or_(
                        _col_expr.in_([str(v) for v in _payload]),
                        _SF.partition_values.is_(None),
                        _col_expr.is_(None)))
            for (entry,) in q.yield_per(2000):
                if entry is not None:
                    out.append(entry)
        return out

    def iceberg_snapshot_file_paths(
        self, bucket: str, table_prefix: str, snapshot_id: str) -> list:
        """All file_paths of the snapshot's rows store — key-only SELECT
        (never pulls entry_data).  Phase 2 snapshot-arrival indexer uses
        this to hand `scan_files_to_supplement` the FULL file list; empty
        means the rows store is not written yet for this snapshot."""
        from core.db.models import IcebergSnapshotFiles as _SF
        table_prefix = canonical_prefix(table_prefix)
        with self.get_session(read_only=True) as session:
            return [r[0] for r in session.query(_SF.file_path).filter(
                _SF.bucket == bucket,
                prefix_matches(_SF.table_prefix, table_prefix),
                _SF.snapshot_id == str(snapshot_id)).all() if r and r[0]]

    def iceberg_snapshot_files_count(
        self, bucket: str, table_prefix: str, snapshot_id: str) -> int:
        """COUNT of per-file rows for the snapshot (completeness proof)."""
        from core.db.models import IcebergSnapshotFiles as _SF
        table_prefix = canonical_prefix(table_prefix)
        with self.get_session(read_only=True) as session:
            return int(session.query(_SF).filter(
                _SF.bucket == bucket,
                prefix_matches(_SF.table_prefix, table_prefix),
                _SF.snapshot_id == str(snapshot_id)).count())

    def iceberg_snapshot_files_count_for_manifest(
        self, bucket: str, table_prefix: str, snapshot_id: str,
        manifest_path: str) -> int:
        """Phase 3 (fleet syncer) — COUNT of per-file rows a snapshot holds
        for ONE manifest.  Used for the idempotent-resume short-circuit
        (rows already present → neither copy-forward nor decode)."""
        from core.db.models import IcebergSnapshotFiles as _SF
        table_prefix = canonical_prefix(table_prefix)
        with self.get_session(read_only=True) as session:
            return int(session.query(_SF).filter(
                _SF.bucket == bucket,
                prefix_matches(_SF.table_prefix, table_prefix),
                _SF.snapshot_id == str(snapshot_id),
                _SF.manifest_path == manifest_path).count())

    def iceberg_snapshot_files_copy_forward(
        self, bucket: str, table_prefix: str, *,
        from_snapshot: str, to_snapshot: str, manifest_path: str) -> int:
        """Phase 3 (fleet syncer, the O(delta) mechanic) — SQL copy-forward
        of one UNCHANGED manifest's per-file rows from an already-synced
        snapshot to a new one.  Iceberg manifest files are immutable, so a
        manifest reused verbatim by the new manifest list has BYTE-IDENTICAL
        entries — no S3 read, no Avro decode, one INSERT..SELECT.

        Idempotent by construction (``NOT EXISTS`` on the unique key) and
        portable (plain INSERT..SELECT, both SQLite + PostgreSQL; JSON
        columns copied verbatim).  Returns rows copied (0 when the prior
        snapshot has no rows for this manifest OR they were already copied
        — the caller distinguishes via the count-for-manifest check)."""
        from sqlalchemy import text as _sa_text
        table_prefix = canonical_prefix(table_prefix)
        now = datetime.now(timezone.utc)
        sql = _sa_text("""
            INSERT INTO iceberg_snapshot_files
                (bucket, table_prefix, snapshot_id, file_path, manifest_path,
                 status, record_count, file_size, partition_values,
                 entry_data, created_at)
            SELECT s.bucket, s.table_prefix, :to_snap, s.file_path,
                   s.manifest_path, s.status, s.record_count, s.file_size,
                   s.partition_values, s.entry_data, :now_ts
            FROM iceberg_snapshot_files s
            WHERE s.bucket = :bucket AND s.table_prefix IN (:tp, :tp_slash)
              AND s.snapshot_id = :from_snap AND s.manifest_path = :mp
              AND NOT EXISTS (
                  SELECT 1 FROM iceberg_snapshot_files t
                  WHERE t.bucket = s.bucket
                    AND t.table_prefix = s.table_prefix
                    AND t.snapshot_id = :to_snap
                    AND t.file_path = s.file_path)
        """)
        with self.get_session() as session:
            res = session.execute(sql, {
                "bucket": bucket, "tp": table_prefix, "tp_slash": table_prefix + "/",
                "from_snap": str(from_snapshot),
                "to_snap": str(to_snapshot),
                "mp": manifest_path, "now_ts": now,
            })
            return int(res.rowcount or 0)

    def iceberg_col_stats_upsert_batch(
        self, records: list,
    ) -> int:
        """Bulk upsert (file, column) → bounds rows.

        BF-COL-STATS-V2: keyed on (bucket, table_prefix, snapshot_id,
        file_path, column_name) so multiple connections pointing at the
        same S3 bucket share supplement rows.  Each record dict must have:
        bucket, table_prefix, snapshot_id, file_path, column_name,
        lower_bound, upper_bound, null_count, row_count.  connection_id
        and table_name are denormalized telemetry — optional.

        Idempotent: re-running with the same keys updates the bounds.
        Returns number of rows affected.

        2026-06-04 — chunked.  Callers may pass tens of thousands of
        records in one call (a full-table scan); pushing that into
        one transaction blows the parameter limit on Postgres and
        holds an oversize lock.  We chunk internally so the caller
        contract is unchanged.
        """
        if not records:
            return 0
        import logging as _ic_log
        _logger_ic = _ic_log.getLogger(__name__)
        _logger_ic.info(
            "iceberg_col_stats_upsert_batch START: received=%d",
            len(records),
        )

        # Phase 150.D (2026-06-04) — if the batch exceeds the per-flush
        # ceiling, chunk and recurse so each call hits the DB with a
        # bounded transaction.  One bad chunk no longer poisons all.
        if len(records) > self._COL_STATS_FLUSH_CHUNK:
            total_affected = 0
            total_failed_chunks = 0
            for i in range(0, len(records), self._COL_STATS_FLUSH_CHUNK):
                chunk = records[i : i + self._COL_STATS_FLUSH_CHUNK]
                try:
                    n = self.iceberg_col_stats_upsert_batch(chunk)
                    total_affected += n
                    _logger_ic.info(
                        "iceberg_col_stats_upsert_batch CHUNK-OK: "
                        "offset=%d size=%d affected=%d",
                        i, len(chunk), n,
                    )
                except Exception as _ce:
                    total_failed_chunks += 1
                    _logger_ic.error(
                        "iceberg_col_stats_upsert_batch CHUNK-FAILED: "
                        "offset=%d size=%d type=%s msg=%s sample=%r",
                        i, len(chunk), type(_ce).__name__,
                        str(_ce)[:300],
                        # sample so the operator sees what shape the
                        # row had — bucket/prefix/file/column names
                        {k: chunk[0].get(k) for k in (
                            "bucket", "table_prefix", "snapshot_id",
                            "file_path", "column_name")
                        } if chunk else {},
                        exc_info=True,
                    )
            _logger_ic.info(
                "iceberg_col_stats_upsert_batch DONE-CHUNKED: "
                "input=%d affected=%d failed_chunks=%d",
                len(records), total_affected, total_failed_chunks,
            )
            return total_affected

        now = datetime.now(timezone.utc)
        affected = 0

        # BF-COL-STATS dedup-fix: collapse duplicate composite keys WITHIN
        # the batch before touching the DB.  session.add() does not detect
        # a previously-added (uncommitted) row with the same unique key,
        # so two records with the same (bucket, prefix, snapshot, file,
        # column) in one batch cause "UNIQUE constraint failed" at flush
        # time.  Last-write-wins on dup — bounds are deterministic per
        # (file, column) anyway since we aggregate row-group stats first.
        deduped: Dict[Tuple, dict] = {}
        for r in records:
            r["table_prefix"] = canonical_prefix(r.get("table_prefix"))
            key = (
                r.get("bucket") or "",
                r["table_prefix"],
                str(r.get("snapshot_id") or ""),
                r.get("file_path") or "",
                r.get("column_name") or "",
            )
            if not key[3] or not key[4]:
                # Skip records missing the file_path or column_name
                continue
            deduped[key] = r

        with self.get_session() as session:
            # Bulk-fetch existing rows for this batch in ONE query —
            # avoids N+1 SELECT-per-record and is also more deterministic
            # under SQLAlchemy's autoflush.
            keys_list = list(deduped.keys())
            existing_map: Dict[Tuple, IcebergColumnStatsSupplement] = {}
            if keys_list:
                # Filter by the union of keys; this is a coarse fetch
                # (over-fetches rows for the same bucket+prefix+snapshot)
                # but the actual match is checked client-side.
                buckets = {k[0] for k in keys_list}
                prefixes = {k[1] for k in keys_list}
                snapshots = {k[2] for k in keys_list}
                rows = session.query(IcebergColumnStatsSupplement).filter(
                    IcebergColumnStatsSupplement.bucket.in_(buckets),
                    prefix_matches_any(IcebergColumnStatsSupplement.table_prefix, prefixes),
                    IcebergColumnStatsSupplement.snapshot_id.in_(snapshots),
                ).all()
                for row in rows:
                    rk = (row.bucket, canonical_prefix(row.table_prefix),
                          str(row.snapshot_id), row.file_path, row.column_name)
                    if rk in deduped:
                        existing_map[rk] = row

            for key, r in deduped.items():
                try:
                    existing = existing_map.get(key)
                    if existing:
                        existing.lower_bound = r.get("lower_bound")
                        existing.upper_bound = r.get("upper_bound")
                        existing.null_count = (
                            None if r.get("null_count") is None
                            else int(r.get("null_count")))
                        existing.row_count = int(r.get("row_count") or 0)
                        existing.scanned_at = now
                        # Refresh telemetry attribution on re-scan
                        if r.get("connection_id") is not None:
                            existing.connection_id = r.get("connection_id")
                        if r.get("table_name"):
                            existing.table_name = r.get("table_name")
                        # Phase 151.A — refresh format discriminator on
                        # re-scan so a switch from iceberg→parquet
                        # registration (rare) updates downstream reads.
                        if r.get("format"):
                            existing.format = r.get("format")
                    else:
                        row = IcebergColumnStatsSupplement(
                            bucket=r["bucket"],
                            table_prefix=r["table_prefix"],
                            connection_id=r.get("connection_id"),
                            table_name=r.get("table_name"),
                            snapshot_id=r["snapshot_id"],
                            file_path=r["file_path"],
                            column_name=r["column_name"],
                            lower_bound=r.get("lower_bound"),
                            upper_bound=r.get("upper_bound"),
                            null_count=(None if r.get("null_count") is None
                                        else int(r.get("null_count"))),
                            row_count=int(r.get("row_count") or 0),
                            scanned_at=now,
                            # Phase 151.A — defaults to 'iceberg' via the
                            # model so legacy callers stay correct.
                            format=r.get("format") or "iceberg",
                        )
                        session.add(row)
                    affected += 1
                except Exception as _e:
                    logger.debug("col_stats upsert skip: %s", _e)
            try:
                session.flush()
            except Exception as _flush_exc:
                # If the batch flush still fails (concurrent writer on
                # another pod, or a missed dup), fall back to per-row
                # commits inside a fresh session so individual failures
                # don't poison the whole batch.
                # 2026-06-04 — was a single-line warning that hid the
                # actual SQL error chain.  Now logs type, message, and
                # a sample of the first deduped row so the operator
                # can see what's being upserted (bucket / prefix /
                # snapshot / file_path / column_name — no values, just
                # shape).
                _sample = None
                if deduped:
                    _first_key, _first_row = next(iter(deduped.items()))
                    _sample = {
                        "bucket":       _first_row.get("bucket"),
                        "table_prefix": _first_row.get("table_prefix"),
                        "snapshot_id":  _first_row.get("snapshot_id"),
                        "file_path":    _first_row.get("file_path"),
                        "column_name":  _first_row.get("column_name"),
                    }
                logger.warning(
                    "col_stats batch flush failed: type=%s msg=%s "
                    "deduped_count=%d sample_keys=%r — falling back to "
                    "per-row upsert",
                    type(_flush_exc).__name__, str(_flush_exc)[:300],
                    len(deduped), _sample,
                    exc_info=True,
                )
                session.rollback()
                affected = self._iceberg_col_stats_upsert_one_by_one(deduped, now)
        return affected

    def _iceberg_col_stats_upsert_one_by_one(
        self, deduped: Dict[Tuple, dict], now: datetime,
    ) -> int:
        """Slow-path fallback when a batch flush fails — per-row session
        with explicit error swallow.  Used when concurrent writers race
        on the same composite key (different pods scanning same bucket).
        """
        affected = 0
        for key, r in deduped.items():
            try:
                with self.get_session() as session:
                    existing = session.query(IcebergColumnStatsSupplement).filter(
                        IcebergColumnStatsSupplement.bucket == key[0],
                        prefix_matches(IcebergColumnStatsSupplement.table_prefix, key[1]),
                        IcebergColumnStatsSupplement.snapshot_id == key[2],
                        IcebergColumnStatsSupplement.file_path == key[3],
                        IcebergColumnStatsSupplement.column_name == key[4],
                    ).first()
                    if existing:
                        existing.lower_bound = r.get("lower_bound")
                        existing.upper_bound = r.get("upper_bound")
                        existing.null_count = (
                            None if r.get("null_count") is None
                            else int(r.get("null_count")))
                        existing.row_count = int(r.get("row_count") or 0)
                        existing.scanned_at = now
                        if r.get("connection_id") is not None:
                            existing.connection_id = r.get("connection_id")
                        if r.get("table_name"):
                            existing.table_name = r.get("table_name")
                        if r.get("format"):
                            existing.format = r.get("format")
                    else:
                        session.add(IcebergColumnStatsSupplement(
                            bucket=r["bucket"],
                            table_prefix=r["table_prefix"],
                            connection_id=r.get("connection_id"),
                            table_name=r.get("table_name"),
                            snapshot_id=r["snapshot_id"],
                            file_path=r["file_path"],
                            column_name=r["column_name"],
                            lower_bound=r.get("lower_bound"),
                            upper_bound=r.get("upper_bound"),
                            null_count=(None if r.get("null_count") is None
                                        else int(r.get("null_count"))),
                            row_count=int(r.get("row_count") or 0),
                            scanned_at=now,
                            format=r.get("format") or "iceberg",
                        ))
                    affected += 1
            except Exception as _e:
                logger.debug("col_stats single-row upsert skipped: %s", _e)
        return affected

    def iceberg_col_stats_get_for_snapshot(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        column_names: list,
        file_paths: Optional[list] = None,
        format: str = "iceberg",
    ) -> Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int, int]]]:
        """Return {file_path: {column_name: (lower, upper, null_count, row_count)}}
        for a (bucket, prefix) + given columns.  Used by iceberg_reader
        to merge supplement bounds into the per-file pruning loop.

        BF-600g (2026-05-31): tuple extended from 3-element to 4-element
        to carry row_count.  Enables IS NOT NULL pruning at the
        supplement layer (file is empty for IS NOT NULL when
        null_count >= row_count).  Pre-BF-600g this returned 3-tuple
        which forced ``_file_matches_supplement_bounds`` to bail on
        IS NOT NULL.  row_count was already stored in the schema since
        the supplement table was created — only the read path lacked it.

        BF-370: snapshot_id is now ADVISORY, not a filter.  Iceberg data
        files are content-addressable + immutable — the same file_path
        carries the same bytes regardless of which snapshot references
        it.  Filtering by snapshot_id (as the original code did) would
        miss bounds whenever the table's current snapshot rolled forward
        after the scan, even though the underlying files are unchanged.

        When ``file_paths`` is provided, the query narrows to just those
        files — one fast index lookup instead of pulling all bounds for
        the table.  Recommended whenever the caller already has the file
        list.

        Shared identity (bucket + prefix) means rows scanned by ANY
        connection are visible to ALL connections pointing at the same
        S3 location.  Empty dict on miss.
        """
        if not column_names:
            return {}
        # snapshot_id retained in the signature for backward compat but
        # no longer applied as a SQL filter — see docstring rationale.
        _ = snapshot_id
        # 2026-07-13 CORE FIX: canonicalize prefix so a caller passing a
        # trailing slash matches rows stored stripped (and vice-versa).
        table_prefix = canonical_prefix(table_prefix)
        # BF-374: case-insensitive column matching.  Storage records
        # column_name verbatim from the parquet schema (could be any
        # case the writer chose).  Callers pass lowercase filter cols.
        # Use func.lower() on the column expression so the IN clause
        # matches regardless of stored case.
        from sqlalchemy import func as _sa_func
        _col_names_lower = [str(c).lower() for c in column_names]
        out: Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int]]] = {}

        # Deep-dive fix: chunk file_paths IN clause to stay under SQLite's
        # 999-parameter ceiling.  PostgreSQL handles ~32K but SQLite hard-
        # fails at 999.  User's case (2649 files) would have crashed silently.
        # Use 800 to leave headroom for the other parameters in the query.
        _IN_CHUNK_SIZE = 800

        def _query_chunk(session, file_chunk: Optional[list]):
            q = session.query(IcebergColumnStatsSupplement).filter(
                IcebergColumnStatsSupplement.bucket == bucket,
                prefix_matches(IcebergColumnStatsSupplement.table_prefix, table_prefix),
                IcebergColumnStatsSupplement.format == format,
                _sa_func.lower(IcebergColumnStatsSupplement.column_name).in_(_col_names_lower),
            )
            if file_chunk:
                q = q.filter(IcebergColumnStatsSupplement.file_path.in_(file_chunk))
            return q.all()

        with self.get_session(read_only=True) as session:
            if file_paths:
                files_list = list(file_paths)
                # Chunk if over the safe limit
                if len(files_list) > _IN_CHUNK_SIZE:
                    for start in range(0, len(files_list), _IN_CHUNK_SIZE):
                        chunk = files_list[start:start + _IN_CHUNK_SIZE]
                        for row in _query_chunk(session, chunk):
                            out.setdefault(row.file_path, {})[(row.column_name or "").lower()] = (
                                row.lower_bound, row.upper_bound,
                                (None if row.null_count is None else int(row.null_count)),
                                (None if row.row_count is None
                                 else int(row.row_count)),
                            )
                else:
                    # BF-CSL-TUPLE (2026-06-01): emit the SAME 4-tuple shape
                    # as the chunked branch above.  Previously this branch
                    # silently dropped ``row_count``, producing a 3-tuple
                    # that ``_file_matches_supplement_bounds`` would handle
                    # via its fallback (treating row_count as 0).  That made
                    # the IS NOT NULL pruning silently degrade AND polluted
                    # ``_supp_cols_lower_for_warn`` enough that the misleading
                    # "no min/max for system_id" warning fired even when the
                    # supplement covered the column — exactly the user-
                    # reported symptom.  One-line correctness fix.
                    for row in _query_chunk(session, files_list):
                        out.setdefault(row.file_path, {})[(row.column_name or "").lower()] = (
                            row.lower_bound, row.upper_bound,
                            (None if row.null_count is None else int(row.null_count)),
                                (None if row.row_count is None
                                 else int(row.row_count)),
                        )
            else:
                # No file filter — pull all stats for this bucket+prefix+cols.
                # Caller is responsible for not abusing this on huge tables.
                for row in _query_chunk(session, None):
                    out.setdefault(row.file_path, {})[(row.column_name or "").lower()] = (
                        row.lower_bound, row.upper_bound,
                        (None if row.null_count is None else int(row.null_count)),
                                (None if row.row_count is None
                                 else int(row.row_count)),
                    )
        return out

    def iceberg_col_stats_existing_files(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        format: str = "iceberg",
    ) -> list:
        """Return list of file_paths already scanned for (bucket, prefix).

        BF-370 follow-up: snapshot_id is ADVISORY, not a filter.  Iceberg
        data files are immutable + content-addressable; the same file_path
        carries the same bytes regardless of which snapshot references it.
        Filtering on snapshot_id here caused EVERY scan to re-scan EVERY
        file each time the table rolled forward to a new snapshot — a 2649-
        file table = 2649 wasted S3 footer reads per snapshot tick.  Now
        keyed on (bucket, prefix) only — re-scans skip everything already
        on disk, regardless of which snapshot first added it.

        Phase 151.A — ``format`` defaults to 'iceberg' to preserve the
        historical contract.  Plain-parquet sync passes 'parquet' so it
        only treats parquet-format rows as "already scanned".
        """
        _ = snapshot_id  # retained in signature for backward compat
        table_prefix = canonical_prefix(table_prefix)
        with self.get_session(read_only=True) as session:
            rows = session.query(
                IcebergColumnStatsSupplement.file_path,
            ).filter(
                IcebergColumnStatsSupplement.bucket == bucket,
                prefix_matches(IcebergColumnStatsSupplement.table_prefix, table_prefix),
                IcebergColumnStatsSupplement.format == format,
            ).distinct().all()
            return [r[0] for r in rows if r and r[0]]

    # ── 2026-07-13 per-file grain (iceberg_file_stats_v3) reads ────────

    def iceberg_file_stats_get_for_snapshot(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        column_names: Optional[list] = None,
        file_paths: Optional[list] = None,
        format: str = "iceberg",
    ) -> Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int, int]]]:
        """v3 per-FILE read — returns the SAME shape as
        ``iceberg_col_stats_get_for_snapshot``:
            {file_path: {col_lower: (lower, upper, null_count, row_count)}}
        so it is a drop-in for every consumer of the v2 read.

        Reads ONE row per file (unpacking its ``column_stats`` JSON) instead
        of N per-column rows.  ``column_names`` optionally narrows the
        returned columns (None = every column the file has).  snapshot_id is
        ADVISORY (immutable content-addressed files) — mirrors v2.
        """
        _ = snapshot_id
        table_prefix = canonical_prefix(table_prefix)
        _want = {str(c).lower() for c in column_names} if column_names else None
        out: Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int, int]]] = {}
        _IN_CHUNK_SIZE = 800

        def _q(session, file_chunk: Optional[list]):
            q = session.query(IcebergFileStats).filter(
                IcebergFileStats.bucket == bucket,
                prefix_matches(IcebergFileStats.table_prefix, table_prefix),
                IcebergFileStats.format == format,
            )
            if file_chunk:
                q = q.filter(IcebergFileStats.file_path.in_(file_chunk))
            return q.all()

        def _absorb(row):
            cs = row.column_stats or {}
            rc = int(row.row_count or 0)
            cols: Dict[str, Tuple] = {}
            for cname, st in (cs.items() if isinstance(cs, dict) else []):
                cl = str(cname).lower()
                if _want is not None and cl not in _want:
                    continue
                if not isinstance(st, dict):
                    continue
                cols[cl] = (st.get("lo"), st.get("hi"),
                            (None if st.get("nulls") is None
                             else int(st.get("nulls"))), rc)
            if cols:
                out[row.file_path] = cols

        with self.get_session(read_only=True) as session:
            if file_paths:
                fl = list(file_paths)
                for start in range(0, len(fl), _IN_CHUNK_SIZE):
                    for row in _q(session, fl[start:start + _IN_CHUNK_SIZE]):
                        _absorb(row)
            else:
                for row in _q(session, None):
                    _absorb(row)
        return out

    def iceberg_file_stats_columns_covered(
        self,
        bucket: str,
        table_prefix: str,
        column_names: list,
        *,
        format: str = "iceberg",
        sample_limit: int = 64,
    ) -> set:
        """Which of ``column_names`` already have stored bounds for this table.

        An EXISTENCE probe, not a data fetch.  Selects ONLY the
        ``column_stats`` map (never the ORM entity), reads at most
        ``sample_limit`` rows, and stops as soon as every requested column has
        been seen -- so the common "already covered" answer costs one row.

        Why bounded is safe HERE: the only caller
        (``duckdb_views._ensure_join_key_bounds_sync``) uses this to decide
        whether to warm a cache, and its own return value is discarded.  Being
        wrong is slower in both directions and incorrect in neither -- failing
        to prune reads more files, and a redundant scan is
        ``skip_already_scanned``.  A POSITIVE here is exact proof (the column
        was read out of a stored map); a NEGATIVE only means "not within the
        sample" and routes to the scan, which is the safe direction.

        Do NOT reuse this to gate correctness: a sampled negative is not a
        proof of absence.

        Fail-safe: any error returns an empty set, i.e. "nothing proven",
        which makes the caller scan.
        """
        _want = {str(c).split(".")[-1].lower() for c in (column_names or []) if c}
        if not (bucket and table_prefix and _want):
            return set()
        found: set = set()
        try:
            _prefix = canonical_prefix(table_prefix)
            _lim = max(1, min(int(sample_limit or 64), 1000))
            with self.get_session(read_only=True) as session:
                q = (session.query(IcebergFileStats.column_stats)
                     .filter(IcebergFileStats.bucket == bucket,
                             prefix_matches(IcebergFileStats.table_prefix, _prefix),
                             IcebergFileStats.format == format)
                     .limit(_lim))
                for (stats,) in q.all():
                    if not isinstance(stats, dict):
                        continue
                    found |= {str(k).lower() for k in stats} & _want
                    if found >= _want:
                        break        # every column proven — stop reading
        except Exception as exc:
            logger.debug("[stats-probe] coverage probe failed for %s/%s "
                         "(fail-safe, reporting nothing proven): %s",
                         bucket, table_prefix, exc)
            return set()
        return found

    def iceberg_file_stats_existing_files(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        format: str = "iceberg",
        required_columns: Optional[list] = None,
        file_paths: Optional[list] = None,
    ) -> list:
        """v3 skip-already-scanned: distinct file_paths already in v3 for
        (bucket, prefix).  snapshot_id ADVISORY (mirrors v2).

        ``required_columns`` (2026-08-21) — a file counts as "already scanned"
        ONLY when its stored ``column_stats`` holds EVERY one of these columns.
        Without it the skip set is per-FILE and column-blind, so the first
        narrow scan of a table (the query-path footer capture asks only for the
        columns THIS query filters on) marks every file "done" and every later
        query for a DIFFERENT column scans nothing, captures nothing, and still
        reports success.  A permanent no-op, not a first-run effect.

        ``file_paths`` bounds the lookup to the island the caller cares about,
        so the column check does not load the whole table's stats maps.
        """
        _ = snapshot_id
        table_prefix = canonical_prefix(table_prefix)
        _req = [str(c).lower() for c in (required_columns or []) if c]
        with self.get_session(read_only=True) as session:
            _cols = ((IcebergFileStats.file_path, IcebergFileStats.column_stats)
                     if _req else (IcebergFileStats.file_path,))
            q = session.query(*_cols).filter(
                IcebergFileStats.bucket == bucket,
                prefix_matches(IcebergFileStats.table_prefix, table_prefix),
                IcebergFileStats.format == format,
            )
            if file_paths:
                q = q.filter(IcebergFileStats.file_path.in_(list(file_paths)))
            if not _req:
                return [r[0] for r in q.distinct().all() if r and r[0]]
            out = []
            for r in q.all():
                if not r or not r[0]:
                    continue
                _have = r[1] if isinstance(r[1], dict) else {}
                _have_lower = {str(k).lower() for k in _have}
                if all(c in _have_lower for c in _req):
                    out.append(r[0])
            return out

    def iceberg_file_stats_list_files(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: Optional[str] = None,
        *,
        limit: int = 100,
        offset: int = 0,
        format: str = "iceberg",
    ) -> Dict[str, Any]:
        """2026-07-13 — admin drill-down: paginated per-FILE v3 rows for a
        (bucket, table_prefix[, snapshot]) so the UI can render a
        Starburst-style per-file column-stats view.

        Unlike ``iceberg_file_stats_get_for_snapshot`` (query-path shape that
        drops file_size / vals), this returns the FULL per-file record for
        display:
            {total, files: [{file_path, snapshot_id, row_count, file_size,
                             columns: int, scanned_at, column_stats}]}
        where ``column_stats`` is the raw {col: {lo,hi,nulls,vals,size}} map.
        Ordered by file_path for stable pagination.
        """
        table_prefix = canonical_prefix(table_prefix)
        limit = max(1, min(int(limit or 100), 1000))
        offset = max(0, int(offset or 0))
        with self.get_session(read_only=True) as session:
            base = session.query(IcebergFileStats).filter(
                IcebergFileStats.bucket == bucket,
                prefix_matches(IcebergFileStats.table_prefix, table_prefix),
                IcebergFileStats.format == format,
            )
            if snapshot_id is not None:
                base = base.filter(
                    IcebergFileStats.snapshot_id == str(snapshot_id))
            total = base.count()
            rows = (base.order_by(IcebergFileStats.file_path)
                        .offset(offset).limit(limit).all())
            files = []
            for r in rows:
                cs = r.column_stats if isinstance(r.column_stats, dict) else {}
                files.append({
                    "file_path":    r.file_path,
                    "snapshot_id":  r.snapshot_id,
                    "row_count":    int(r.row_count or 0),
                    "file_size":    int(r.file_size or 0),
                    "columns":      len(cs),
                    "scanned_at":   r.scanned_at.isoformat() if r.scanned_at else None,
                    "column_stats": cs,
                })
            return {"total": int(total), "files": files,
                    "limit": limit, "offset": offset}

    def iceberg_file_stats_clear(
        self,
        *,
        bucket: Optional[str] = None,
        table_prefix: Optional[str] = None,
        snapshot_id: Optional[str] = None,
        connection_id: Optional[int] = None,
        table_name: Optional[str] = None,
    ) -> int:
        """Delete v3 per-file rows.  At least one filter required."""
        if (bucket is None and table_prefix is None and snapshot_id is None
                and connection_id is None and table_name is None):
            raise ValueError("file_stats_clear requires at least one filter")
        with self.get_session() as session:
            q = session.query(IcebergFileStats)
            if bucket is not None:
                q = q.filter(IcebergFileStats.bucket == bucket)
            if table_prefix is not None:
                q = q.filter(prefix_matches(IcebergFileStats.table_prefix, table_prefix))
            if snapshot_id is not None:
                q = q.filter(IcebergFileStats.snapshot_id == str(snapshot_id))
            if connection_id is not None:
                q = q.filter(IcebergFileStats.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(IcebergFileStats.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def iceberg_file_stats_backfill_from_v2(
        self,
        *,
        bucket: Optional[str] = None,
        table_prefix: Optional[str] = None,
        snapshot_id: Optional[str] = None,
        format: str = "iceberg",
        allow_full_table: bool = False,
    ) -> int:
        """One-shot migration: read the v2 (file × column) supplement rows and
        write the per-file v3 rows (all columns grouped per file).  Lets a
        grain cutover to v3 be SEAMLESS — v3 is pre-populated from v2 so
        db-first engages immediately instead of falling back to S3 until the
        next scan.  Idempotent (v3 upsert).  Returns v3 rows written.

        Scope filters are recommended (backfill one table at a time).  2026-07-14
        DATA-SAFETY: an UNSCOPED call (no bucket/table_prefix/snapshot_id) reads
        the ENTIRE v2 supplement — potentially millions of (file×column) rows —
        into memory at once, which can OOM the pod.  Refused unless
        ``allow_full_table=True`` is passed explicitly (mirrors the
        at-least-one-filter guard on ``iceberg_file_stats_clear``), so an
        accidental empty-scope request from the admin UI cannot trigger a
        full-table migration.
        """
        if (bucket is None and table_prefix is None and snapshot_id is None
                and not allow_full_table):
            raise ValueError(
                "iceberg_file_stats_backfill_from_v2 requires at least one scope "
                "filter (bucket / table_prefix / snapshot_id), or "
                "allow_full_table=True to intentionally migrate the whole v2 table")
        from core.iceberg_column_stats import group_column_rows_to_file_stats
        v2_rows: list = []
        with self.get_session(read_only=True) as session:
            q = session.query(IcebergColumnStatsSupplement).filter(
                IcebergColumnStatsSupplement.format == format)
            if bucket is not None:
                q = q.filter(IcebergColumnStatsSupplement.bucket == bucket)
            if table_prefix is not None:
                q = q.filter(prefix_matches(IcebergColumnStatsSupplement.table_prefix, table_prefix))
            if snapshot_id is not None:
                q = q.filter(IcebergColumnStatsSupplement.snapshot_id == str(snapshot_id))
            # Stream the cursor (bounded fetch) instead of one giant materialise.
            for row in q.yield_per(2000):
                v2_rows.append({
                    "bucket": row.bucket, "table_prefix": row.table_prefix,
                    "snapshot_id": row.snapshot_id, "file_path": row.file_path,
                    "column_name": row.column_name,
                    "lower_bound": row.lower_bound, "upper_bound": row.upper_bound,
                    "null_count": (None if row.null_count is None
                                   else int(row.null_count)),
                    "row_count": int(row.row_count or 0),
                    "connection_id": row.connection_id, "table_name": row.table_name,
                    "format": row.format or "iceberg",
                })
        if not v2_rows:
            return 0
        file_rows = group_column_rows_to_file_stats(v2_rows)
        return self.iceberg_file_stats_upsert_batch(file_rows)

    def _restamp_snapshot_generic(
        self, _Model, *, bucket, table_prefix, file_paths, snapshot_id,
        format="iceberg", per_file_grain: bool,
    ) -> int:
        """2026-07-13 — advance existing rows' snapshot_id to the CURRENT
        snapshot for the given files, so the (snapshot-strict) completeness
        gate ENGAGES db-first on APPEND tables instead of perpetually falling
        back to the S3 manifest walk.  Iceberg data files are immutable +
        content-addressed, so a file carried into a new snapshot has the SAME
        bounds — only its snapshot label needs to move.  No footer re-read.

        CONFLICT-SAFE: guarantees exactly one snapshot-set per file under the
        target snapshot (the unique key includes snapshot_id, so a blind
        UPDATE could collide).  Per file: if a target-snapshot row already
        exists, drop the stale rows; else move ONE snapshot's row-set to the
        target and drop any other stale rows.  Returns rows touched.
        """
        if not file_paths:
            return 0
        table_prefix = canonical_prefix(table_prefix)
        target = str(snapshot_id)
        touched = 0
        CHUNK = 400
        fps = list(file_paths)
        with self.get_session() as session:
            for i in range(0, len(fps), CHUNK):
                chunk = fps[i:i + CHUNK]
                rows = session.query(_Model).filter(
                    _Model.bucket == bucket,
                    prefix_matches(_Model.table_prefix, table_prefix),
                    _Model.format == format,
                    _Model.file_path.in_(chunk),
                ).all()
                by_file: Dict[str, list] = {}
                for r in rows:
                    by_file.setdefault(r.file_path, []).append(r)
                for fp, frows in by_file.items():
                    has_target = any(str(r.snapshot_id) == target for r in frows)
                    if has_target:
                        # Already current — delete any stale-snapshot dups.
                        for r in frows:
                            if str(r.snapshot_id) != target:
                                session.delete(r)
                                touched += 1
                        continue
                    # Pick ONE snapshot to carry forward; move its rows to
                    # target, delete every other snapshot's rows for this file.
                    keep_snap = str(frows[0].snapshot_id)
                    for r in frows:
                        if str(r.snapshot_id) == keep_snap:
                            r.snapshot_id = target
                            touched += 1
                        else:
                            session.delete(r)
                            touched += 1
                    # per_file_grain is advisory (v3 has ≤1 row/file/snapshot);
                    # the loop above handles v2's many column-rows uniformly.
        return touched

    def iceberg_file_stats_restamp_snapshot(
        self, *, bucket, table_prefix, file_paths, snapshot_id,
        format="iceberg",
    ) -> int:
        """Re-stamp per-file (v3) rows to the current snapshot (see
        _restamp_snapshot_generic)."""
        return self._restamp_snapshot_generic(
            IcebergFileStats, bucket=bucket, table_prefix=table_prefix,
            file_paths=file_paths, snapshot_id=snapshot_id, format=format,
            per_file_grain=True)

    def iceberg_col_stats_restamp_snapshot(
        self, *, bucket, table_prefix, file_paths, snapshot_id,
        format="iceberg",
    ) -> int:
        """Re-stamp (file×column) v2 rows to the current snapshot."""
        return self._restamp_snapshot_generic(
            IcebergColumnStatsSupplement, bucket=bucket,
            table_prefix=table_prefix, file_paths=file_paths,
            snapshot_id=snapshot_id, format=format, per_file_grain=False)

    # ── Phase 4 (industrialization) — within-island supplement build
    #    single-flight claim + completeness marker.  See
    #    core/db/models.py::IcebergSupplementBuild for the invariant:
    #    the marker only controls BUILD scheduling — never keep/drop. ──

    def iceberg_supplement_build_claim(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        column_name: str,
        *,
        running_ttl_seconds: int = 1800,
        retry_seconds: int = 3600,
        files_total: int = 0,
        trigger: Optional[str] = None,
        connection_id: Optional[int] = None,
        table_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Try to claim the (bucket, prefix, snapshot, column) build.

        Returns ``{"claimed": bool, "status": str, "reason": str}``.

        Semantics (cross-pod safe):
          * no row            → INSERT status='running'  → claimed.
          * status='complete' → never re-claimed for this snapshot.
          * status='running'  → re-claimed ONLY when started_at is older
            than ``running_ttl_seconds`` (crashed builder — the doc's
            "partial supplement build" edge case).
          * status='failed'   → re-claimed ONLY after ``retry_seconds``
            cooldown (don't hammer a hard-broken table).
          * status='partial'  → immediately re-claimable (capped build
            drains over successive queries).

        The re-claim is an optimistic conditional UPDATE (rowcount-checked)
        and the fresh INSERT relies on the unique index — two racing pods
        get exactly one winner in both cases.  NEVER raises: any error
        returns claimed=False (fail-open → no build, today's behavior).
        """
        try:
            bucket = bucket or ""
            table_prefix = canonical_prefix(table_prefix)
            snapshot_id = str(snapshot_id or "")
            column_name = (column_name or "").lower()
            if not (bucket and table_prefix and column_name):
                return {"claimed": False, "status": "invalid",
                        "reason": "missing identity"}
            now = datetime.now(timezone.utc)

            def _age_seconds(ref):
                """Naive-vs-aware tolerant age (SQLite returns naive UTC)."""
                if ref is None:
                    return None
                if ref.tzinfo is None:
                    ref = ref.replace(tzinfo=timezone.utc)
                return (now - ref).total_seconds()

            with self.get_session() as session:
                row = session.query(IcebergSupplementBuild).filter(
                    IcebergSupplementBuild.bucket == bucket,
                    prefix_matches(IcebergSupplementBuild.table_prefix, table_prefix),
                    IcebergSupplementBuild.snapshot_id == snapshot_id,
                    IcebergSupplementBuild.column_name == column_name,
                ).first()
                if row is None:
                    try:
                        session.add(IcebergSupplementBuild(
                            bucket=bucket, table_prefix=table_prefix,
                            snapshot_id=snapshot_id, column_name=column_name,
                            status="running", requested_at=now, started_at=now,
                            files_total=int(files_total or 0),
                            trigger=trigger, connection_id=connection_id,
                            table_name=table_name,
                        ))
                        session.flush()
                        return {"claimed": True, "status": "running",
                                "reason": "new build claimed"}
                    except Exception:
                        # Unique-index race: another pod inserted first.
                        session.rollback()
                        return {"claimed": False, "status": "running",
                                "reason": "lost insert race"}
                prev_status = row.status or "running"
                if prev_status == "complete":
                    return {"claimed": False, "status": "complete",
                            "reason": "already complete for this snapshot"}
                if prev_status == "running":
                    age = _age_seconds(row.started_at or row.requested_at)
                    if age is not None and age < max(1, int(running_ttl_seconds)):
                        return {"claimed": False, "status": "running",
                                "reason": "build in flight"}
                if prev_status == "failed":
                    age = _age_seconds(row.finished_at)
                    if age is not None and age < max(1, int(retry_seconds)):
                        return {"claimed": False, "status": "failed",
                                "reason": "failed recently — retry cooldown"}
                # Re-claimable (partial / stale-running / retry-eligible
                # failed): optimistic conditional UPDATE — the WHERE re-checks
                # the status we read, so exactly one racing pod wins.
                updated = session.query(IcebergSupplementBuild).filter(
                    IcebergSupplementBuild.id == row.id,
                    IcebergSupplementBuild.status == prev_status,
                ).update({
                    "status": "running", "started_at": now,
                    "finished_at": None, "error": None,
                    "files_total": int(files_total or 0),
                    "trigger": trigger,
                    "connection_id": connection_id,
                    "table_name": table_name,
                }, synchronize_session=False)
                if updated == 1:
                    return {"claimed": True, "status": "running",
                            "reason": f"re-claimed after {prev_status}"}
                return {"claimed": False, "status": prev_status,
                        "reason": "lost re-claim race"}
        except Exception as exc:
            import logging as _logging
            _logging.getLogger(__name__).warning(
                "[within-island] supplement-build claim failed (fail-open, "
                "no build scheduled) for %s/%s snap=%s col=%s: %s",
                bucket, table_prefix, snapshot_id, column_name, exc,
            )
            return {"claimed": False, "status": "error", "reason": str(exc)}

    def iceberg_supplement_build_finish(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        column_name: str,
        *,
        status: str,
        files_scanned: int = 0,
        files_failed: int = 0,
        rows_inserted: int = 0,
        error: Optional[str] = None,
    ) -> bool:
        """Record a build outcome on the marker.  ``status`` must be one of
        complete | partial | failed.  Never raises."""
        try:
            if status not in ("complete", "partial", "failed"):
                status = "failed"
            table_prefix = canonical_prefix(table_prefix)
            column_name = (column_name or "").lower()
            with self.get_session() as session:
                updated = session.query(IcebergSupplementBuild).filter(
                    IcebergSupplementBuild.bucket == (bucket or ""),
                    prefix_matches(IcebergSupplementBuild.table_prefix, table_prefix),
                    IcebergSupplementBuild.snapshot_id == str(snapshot_id or ""),
                    IcebergSupplementBuild.column_name == column_name,
                ).update({
                    "status": status,
                    "finished_at": datetime.now(timezone.utc),
                    "files_scanned": int(files_scanned or 0),
                    "files_failed": int(files_failed or 0),
                    "rows_inserted": int(rows_inserted or 0),
                    "error": (str(error)[:2000] if error else None),
                }, synchronize_session=False)
                return updated > 0
        except Exception as exc:
            import logging as _logging
            _logging.getLogger(__name__).warning(
                "[within-island] supplement-build finish(%s) failed for "
                "%s/%s snap=%s col=%s: %s",
                status, bucket, table_prefix, snapshot_id, column_name, exc,
            )
            return False

    def iceberg_supplement_build_get(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: Optional[str] = None,
        column_name: Optional[str] = None,
    ) -> list:
        """Marker rows for admin/status + tests (dicts, newest first).
        Never raises — returns [] on any error."""
        try:
            table_prefix = canonical_prefix(table_prefix)
            with self.get_session(read_only=True) as session:
                q = session.query(IcebergSupplementBuild).filter(
                    IcebergSupplementBuild.bucket == (bucket or ""),
                    prefix_matches(IcebergSupplementBuild.table_prefix, table_prefix),
                )
                if snapshot_id is not None:
                    q = q.filter(
                        IcebergSupplementBuild.snapshot_id == str(snapshot_id))
                if column_name:
                    q = q.filter(
                        IcebergSupplementBuild.column_name == column_name.lower())
                return [r.to_dict() for r in
                        q.order_by(IcebergSupplementBuild.requested_at.desc())
                         .limit(500).all()]
        except Exception as exc:
            import logging as _logging
            _logging.getLogger(__name__).debug(
                "[within-island] supplement-build get failed: %s", exc)
            return []

    # ── Phase 149.4 bloom sidecar ─────────────────────────────────────

    def iceberg_bloom_get_for_snapshot(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        column_names: list,
        file_paths: Optional[list] = None,
        format: str = "iceberg",
        include_types: bool = False,
    ) -> Dict[str, Dict[str, tuple]]:
        """Return ``{file_path: {col_lower: (bloom_bits, num_bits, k)}}``
        for a (bucket, prefix) on the given cols.  Pass ``file_paths`` to
        narrow to a subset, or leave it None to pull every bloom row for
        the cols (snapshot-wide load — matches the supplement-bound
        path's behaviour).

        2026-07-15 type-parity guard — ``include_types=True`` returns
        4-tuples ``(bloom_bits, num_bits, k, column_type)`` where
        ``column_type`` is the recorded BUILD-side type string (None on
        legacy rows).  Default False keeps the historical 3-tuple shape
        so existing iceberg callers are byte-for-byte unchanged.

        Same content-identity model as
        ``iceberg_col_stats_get_for_snapshot``: snapshot_id is ADVISORY
        (Iceberg data files are immutable + content-addressable so the
        bloom built from one snapshot is valid for any snapshot that
        references the same file).

        Files / cols missing from the result simply have no bloom — the
        read path keeps those files (fail-open).
        """
        if not column_names:
            return {}
        _ = snapshot_id  # retained for back-compat; not a SQL filter
        from sqlalchemy import func as _sa_func
        _col_names_lower = [str(c).lower() for c in column_names]
        out: Dict[str, Dict[str, tuple]] = {}
        _IN_CHUNK_SIZE = 800   # mirror col-stats sqlite ceiling

        def _row_entry(row) -> tuple:
            base = (
                bytes(row.bloom_bits or b""),
                int(row.bloom_num_bits or 0),
                int(row.bloom_k or 7),
            )
            if not include_types:
                return base
            # getattr-with-default: survives pre-migration DBs where the
            # column_type attribute may be absent (fail-open -> None).
            return base + (getattr(row, "column_type", None),)

        def _query_chunk(session, file_chunk: Optional[list]):
            q = session.query(IcebergBloomSidecar).filter(
                IcebergBloomSidecar.bucket == bucket,
                prefix_matches(IcebergBloomSidecar.table_prefix, table_prefix),
                IcebergBloomSidecar.format == format,
                _sa_func.lower(IcebergBloomSidecar.column_name).in_(_col_names_lower),
            )
            if file_chunk:
                q = q.filter(IcebergBloomSidecar.file_path.in_(file_chunk))
            return q.all()

        with self.get_session(read_only=True) as session:
            if file_paths:
                files_list = list(file_paths)
                for start in range(0, len(files_list), _IN_CHUNK_SIZE):
                    chunk = files_list[start:start + _IN_CHUNK_SIZE]
                    for row in _query_chunk(session, chunk):
                        out.setdefault(row.file_path, {})[
                            (row.column_name or "").lower()
                        ] = _row_entry(row)
            else:
                # Snapshot-wide load — used when caller doesn't have the
                # file list yet (early-load pattern mirroring the
                # supplement-bound load).
                for row in _query_chunk(session, None):
                    out.setdefault(row.file_path, {})[
                        (row.column_name or "").lower()
                    ] = _row_entry(row)
        return out

    def iceberg_bloom_existing_keys(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        format: str = "iceberg",
    ) -> Set[Tuple[str, str]]:
        """Return ``{(file_path, column_name_lower), ...}`` already scanned
        for this (bucket, prefix, snapshot).  Lets the bloom scanner skip
        files+cols already covered on idempotent re-runs.

        Snapshot_id is ADVISORY (Iceberg files are immutable + content-
        addressable so the bloom built from one snapshot is valid for
        any snapshot that references the same file).  Filtering on it
        here would cause every scan to re-scan everything when the
        table rolls forward — same anti-pattern BF-370 fixed for the
        supplement table.  Keyed on (bucket, prefix) only.

        Phase 151.A — ``format`` defaults to 'iceberg' so existing
        iceberg bloom scanners are unaffected.  Plain-parquet scanner
        must pass 'parquet' explicitly.
        """
        _ = snapshot_id
        with self.get_session(read_only=True) as session:
            rows = session.query(
                IcebergBloomSidecar.file_path,
                IcebergBloomSidecar.column_name,
            ).filter(
                IcebergBloomSidecar.bucket == bucket,
                prefix_matches(IcebergBloomSidecar.table_prefix, table_prefix),
                IcebergBloomSidecar.format == format,
            ).all()
            return {
                (fp, (cn or "").lower())
                for fp, cn in rows
                if fp
            }

    def iceberg_bloom_upsert(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        file_path: str,
        column_name: str,
        bloom_bits: bytes,
        bloom_num_bits: int,
        bloom_k: int = 7,
        distinct_count: int = 0,
        connection_id: Optional[int] = None,
        table_name: Optional[str] = None,
        format: str = "iceberg",
        column_type: Optional[str] = None,
    ) -> None:
        """Upsert one (file × col) bloom row.  Idempotent — re-scan
        overwrites prior bloom for the same file+col within the same
        (bucket, prefix).  Best-effort: DB errors logged and swallowed
        so a scan crash on row 27 of 1000 doesn't abort the batch.

        Phase 151.A — ``format`` defaults to 'iceberg' to preserve the
        historical contract.  Future plain-parquet bloom scanner
        (Phase 151.C) passes 'parquet' so bloom reads can isolate per
        format the same way the supplement reads do.

        2026-07-15 type-parity guard — ``column_type`` records the
        parquet/arrow type the bloom was BUILT from so read paths can
        prove probe-encoding parity before trusting an "absent" verdict.
        None (legacy scanners) leaves the column NULL -> read side must
        treat the type as unknown and keep files (fail-open).
        """
        col_lower = (column_name or "").lower()
        if not (bucket and table_prefix and snapshot_id and file_path
                and col_lower and bloom_bits and bloom_num_bits > 0):
            return
        from sqlalchemy import func as _sa_func
        try:
            with self.get_session() as session:
                existing = (
                    session.query(IcebergBloomSidecar).filter(
                        IcebergBloomSidecar.bucket == bucket,
                        prefix_matches(IcebergBloomSidecar.table_prefix, table_prefix),
                        IcebergBloomSidecar.snapshot_id == str(snapshot_id),
                        IcebergBloomSidecar.file_path == file_path,
                        _sa_func.lower(IcebergBloomSidecar.column_name) == col_lower,
                    ).first()
                )
                if existing is not None:
                    existing.bloom_bits     = bloom_bits
                    existing.bloom_num_bits = int(bloom_num_bits)
                    existing.bloom_k        = int(bloom_k)
                    existing.distinct_count = int(distinct_count)
                    if connection_id is not None:
                        existing.connection_id = connection_id
                    if table_name is not None:
                        existing.table_name = table_name
                    if format:
                        existing.format = format
                    if column_type is not None:
                        existing.column_type = str(column_type)[:64]
                    existing.scanned_at = datetime.now(timezone.utc)
                else:
                    session.add(IcebergBloomSidecar(
                        bucket          = bucket,
                        table_prefix    = table_prefix,
                        snapshot_id     = str(snapshot_id),
                        file_path       = file_path,
                        column_name     = col_lower,
                        bloom_bits      = bloom_bits,
                        bloom_num_bits  = int(bloom_num_bits),
                        bloom_k         = int(bloom_k),
                        distinct_count  = int(distinct_count),
                        connection_id   = connection_id,
                        table_name      = table_name,
                        scanned_at      = datetime.now(timezone.utc),
                        format          = format or "iceberg",
                        column_type     = (str(column_type)[:64]
                                            if column_type is not None else None),
                    ))
        except Exception as exc:
            logger.warning(
                "iceberg_bloom_upsert failed for s3://%s/%s col=%s: %s",
                bucket, file_path, col_lower, exc,
            )

    def iceberg_col_stats_clear(
        self,
        *,
        bucket: Optional[str] = None,
        table_prefix: Optional[str] = None,
        snapshot_id: Optional[str] = None,
        connection_id: Optional[int] = None,
        table_name: Optional[str] = None,
    ) -> int:
        """Delete supplement rows.  At least one filter must be provided to
        prevent accidental wipe-all.

        Filters can be by bucket+prefix (the primary identity) OR by
        connection_id+table_name (the legacy / telemetry view — useful
        for "clear all rows attributed to my connection")."""
        if (bucket is None and table_prefix is None and snapshot_id is None
                and connection_id is None and table_name is None):
            raise ValueError("col_stats_clear requires at least one filter")
        if table_prefix is not None:
            table_prefix = canonical_prefix(table_prefix)
        with self.get_session() as session:
            q = session.query(IcebergColumnStatsSupplement)
            if bucket is not None:
                q = q.filter(IcebergColumnStatsSupplement.bucket == bucket)
            if table_prefix is not None:
                q = q.filter(prefix_matches(IcebergColumnStatsSupplement.table_prefix, table_prefix))
            if snapshot_id is not None:
                q = q.filter(IcebergColumnStatsSupplement.snapshot_id == str(snapshot_id))
            if connection_id is not None:
                q = q.filter(IcebergColumnStatsSupplement.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(IcebergColumnStatsSupplement.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
        # 2026-07-13 — an admin "clear" must wipe BOTH grains so a stale v3
        # row can't survive a v2 clear (or vice-versa).  Best-effort: a v3
        # clear failure never fails the v2 clear.
        try:
            count += self.iceberg_file_stats_clear(
                bucket=bucket, table_prefix=table_prefix,
                snapshot_id=snapshot_id, connection_id=connection_id,
                table_name=table_name)
        except Exception as _v3clr:
            logger.debug("file_stats_clear during col_stats_clear failed: %s",
                         _v3clr)
        return count

    def iceberg_col_stats_status(
        self,
        connection_id: Optional[int] = None,
        bucket: Optional[str] = None,
        include_distinct_counts: bool = False,
    ) -> list:
        """Return per-(bucket, table_prefix, snapshot) row counts so admin
        can see coverage at a glance.  Each row is the SHARED supplement
        identity, so a single bucket+prefix+snapshot row applies to every
        connection pointing at that S3 location.

        BF-359: ``include_distinct_counts=False`` (default) skips the
        expensive ``COUNT(DISTINCT file_path)`` + ``COUNT(DISTINCT column_name)``
        and returns only the cheap aggregates (row count + last_scanned).
        This is what the polling endpoint uses — sub-100ms on 13M rows.

        When admin needs the breakdown they pass include_distinct_counts=True
        which adds the slow distinct counts (5-30s on 13M rows).  Frontend
        should call this lazily, not on every poll.
        """
        from sqlalchemy import func
        # 2026-07-13 — grain-aware.  Under the per-file grain (default v3) the
        # v2 supplement is empty, so read the per-file table instead — else
        # the admin panel misleadingly shows 0 coverage while v3 is fully
        # populated.  v3 = one row per file (rows == files); "columns" is the
        # key-count of a representative column_stats JSON (per-file grain has
        # no column_name axis to COUNT DISTINCT).
        try:
            from core import config as _qs_cfg
            _grain = _qs_cfg.iceberg_file_stats_grain()
        except Exception:
            _grain = "v3"
        if _grain == "v3":
            return self._iceberg_file_stats_status_v3(
                connection_id=connection_id, bucket=bucket,
                include_distinct_counts=include_distinct_counts)
        with self.get_session(read_only=True) as session:
            cols = [
                IcebergColumnStatsSupplement.bucket,
                IcebergColumnStatsSupplement.table_prefix,
                IcebergColumnStatsSupplement.snapshot_id,
                func.max(IcebergColumnStatsSupplement.connection_id).label("connection_id"),
                func.max(IcebergColumnStatsSupplement.table_name).label("table_name"),
                func.count(IcebergColumnStatsSupplement.id).label("rows"),
                func.max(IcebergColumnStatsSupplement.scanned_at).label("last_scanned"),
            ]
            if include_distinct_counts:
                cols.insert(5, func.count(
                    func.distinct(IcebergColumnStatsSupplement.file_path)).label("files"))
                cols.insert(6, func.count(
                    func.distinct(IcebergColumnStatsSupplement.column_name)).label("columns"))
            q = session.query(*cols)
            if connection_id is not None:
                q = q.filter(IcebergColumnStatsSupplement.connection_id == connection_id)
            if bucket is not None:
                q = q.filter(IcebergColumnStatsSupplement.bucket == bucket)
            q = q.group_by(
                IcebergColumnStatsSupplement.bucket,
                IcebergColumnStatsSupplement.table_prefix,
                IcebergColumnStatsSupplement.snapshot_id,
            )
            out = []
            for r in q.all():
                if include_distinct_counts:
                    # Order: bucket, prefix, snapshot, conn_id, table_name,
                    # files, columns, rows, last_scanned
                    out.append({
                        "bucket":        r[0],
                        "table_prefix":  r[1],
                        "snapshot_id":   r[2],
                        "connection_id": r[3],
                        "table_name":    r[4],
                        "files":         int(r[5] or 0),
                        "columns":       int(r[6] or 0),
                        "rows":          int(r[7] or 0),
                        "last_scanned":  r[8].isoformat() if r[8] else None,
                    })
                else:
                    # Order: bucket, prefix, snapshot, conn_id, table_name,
                    # rows, last_scanned (no distinct counts)
                    out.append({
                        "bucket":        r[0],
                        "table_prefix":  r[1],
                        "snapshot_id":   r[2],
                        "connection_id": r[3],
                        "table_name":    r[4],
                        # Files / columns NOT computed in this fast path —
                        # frontend should display "—" or call with
                        # include_distinct_counts=true.
                        "files":         None,
                        "columns":       None,
                        "rows":          int(r[5] or 0),
                        "last_scanned":  r[6].isoformat() if r[6] else None,
                    })
            return out

    def _iceberg_file_stats_status_v3(
        self,
        connection_id: Optional[int] = None,
        bucket: Optional[str] = None,
        include_distinct_counts: bool = False,
    ) -> list:
        """Per-(bucket, prefix, snapshot) coverage from the per-file v3 table
        so the admin panel reflects v3 (not a misleading 0).  rows == files
        (one row per file); ``columns`` = key-count of a representative
        column_stats JSON (only when include_distinct_counts)."""
        from sqlalchemy import func
        with self.get_session(read_only=True) as session:
            q = session.query(
                IcebergFileStats.bucket,
                IcebergFileStats.table_prefix,
                IcebergFileStats.snapshot_id,
                func.max(IcebergFileStats.connection_id).label("connection_id"),
                func.max(IcebergFileStats.table_name).label("table_name"),
                func.count(IcebergFileStats.id).label("rows"),
                func.max(IcebergFileStats.scanned_at).label("last_scanned"),
            )
            if connection_id is not None:
                q = q.filter(IcebergFileStats.connection_id == connection_id)
            if bucket is not None:
                q = q.filter(IcebergFileStats.bucket == bucket)
            q = q.group_by(
                IcebergFileStats.bucket,
                IcebergFileStats.table_prefix,
                IcebergFileStats.snapshot_id,
            )
            out = []
            for r in q.all():
                _files = int(r[5] or 0)   # one row per file
                _columns = None
                if include_distinct_counts:
                    # Count columns from ONE representative file row (per-file
                    # grain packs all columns in the JSON — no SQL COUNT).
                    sample = session.query(IcebergFileStats.column_stats).filter(
                        IcebergFileStats.bucket == r[0],
                        prefix_matches(IcebergFileStats.table_prefix, r[1]),
                        IcebergFileStats.snapshot_id == r[2],
                    ).first()
                    _cs = (sample[0] if sample else None) or {}
                    _columns = len(_cs) if isinstance(_cs, dict) else 0
                out.append({
                    "bucket":        r[0],
                    "table_prefix":  r[1],
                    "snapshot_id":   r[2],
                    "connection_id": r[3],
                    "table_name":    r[4],
                    "files":         _files if include_distinct_counts else None,
                    "columns":       _columns,
                    "rows":          _files,
                    "last_scanned":  r[6].isoformat() if r[6] else None,
                    "grain":         "v3",
                })
            return out

    # ── BF-352: agent config + rules persisted in DB ────────────────────────

    def agent_config_get(self, key: str, fallback: Any = None) -> Any:
        """Read one agent config value by key.  Returns the JSON-decoded
        value, or ``fallback`` when the key is missing or unparseable."""
        import json as _json
        with self.get_session(read_only=True) as session:
            row = session.query(AgentConfig).filter(
                AgentConfig.key == key).first()
            if not row:
                return fallback
            try:
                return _json.loads(row.value_json)
            except Exception:
                return fallback

    def agent_config_get_all(self) -> Dict[str, Any]:
        """Return all stored agent settings as a flat dict {key: value}."""
        import json as _json
        with self.get_session(read_only=True) as session:
            out: Dict[str, Any] = {}
            for r in session.query(AgentConfig).all():
                try:
                    out[r.key] = _json.loads(r.value_json)
                except Exception:
                    out[r.key] = None
            return out

    def agent_config_set(self, key: str, value: Any,
                         description: Optional[str] = None,
                         updated_by: Optional[str] = None) -> Dict[str, Any]:
        """Upsert one agent config value."""
        import json as _json
        with self.get_session() as session:
            row = session.query(AgentConfig).filter(
                AgentConfig.key == key).first()
            if row:
                row.value_json = _json.dumps(value)
                if description is not None:
                    row.description = description
                row.updated_by = updated_by
                row.updated_at = datetime.now(timezone.utc)
            else:
                row = AgentConfig(
                    key=key,
                    value_json=_json.dumps(value),
                    description=description,
                    updated_by=updated_by,
                )
                session.add(row)
            session.flush()
            return row.to_dict()

    def agent_config_delete(self, key: str) -> bool:
        with self.get_session() as session:
            row = session.query(AgentConfig).filter(
                AgentConfig.key == key).first()
            if not row:
                return False
            session.delete(row)
            return True

    def agent_rules_list(self, kind: Optional[str] = None,
                         enabled_only: bool = False) -> list:
        """Return rules ordered by priority asc (low priority = checked first)."""
        with self.get_session(read_only=True) as session:
            q = session.query(AgentRule)
            if kind:
                q = q.filter(AgentRule.kind == kind)
            if enabled_only:
                q = q.filter(AgentRule.enabled == True)  # noqa: E712
            q = q.order_by(AgentRule.priority.asc(), AgentRule.id.asc())
            return [r.to_dict() for r in q.all()]

    def agent_rules_count(self, kind: Optional[str] = None) -> int:
        with self.get_session(read_only=True) as session:
            q = session.query(AgentRule)
            if kind:
                q = q.filter(AgentRule.kind == kind)
            return int(q.count())

    def agent_rules_upsert(self, rule_dict: Dict[str, Any],
                           updated_by: Optional[str] = None) -> Dict[str, Any]:
        """Insert or update a rule.  When dict contains 'id' the row is
        updated; otherwise a new row is inserted.  All fields are
        whitelisted to prevent column-injection."""
        ALLOWED = {"kind", "enabled", "priority", "name", "description",
                   "severity", "action", "pattern", "strategy", "max_retries",
                   "metric", "op", "threshold", "message"}
        with self.get_session() as session:
            rule_id = rule_dict.get("id")
            if rule_id:
                row = session.query(AgentRule).filter(
                    AgentRule.id == int(rule_id)).first()
                if not row:
                    raise ValueError(f"AgentRule id={rule_id} not found")
            else:
                row = AgentRule(
                    kind=rule_dict.get("kind", "query_fix"),
                    description=rule_dict.get("description") or "(no description)",
                )
                session.add(row)
            for k, v in rule_dict.items():
                if k in ALLOWED:
                    setattr(row, k, v)
            row.updated_by = updated_by
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def agent_rules_delete(self, rule_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(AgentRule).filter(
                AgentRule.id == int(rule_id)).first()
            if not row:
                return False
            session.delete(row)
            return True

    def agent_rules_seed_if_empty(self, kind: str, defaults: List[Dict[str, Any]]) -> int:
        """One-time seeder: insert built-in defaults when the table has no
        rows of this kind.  Returns the number of rows inserted (0 if
        already populated).  Idempotent — safe to call on every boot.

        Multi-pod safe: uses ``agent_config.key`` UNIQUE constraint as a
        sentinel.  If two pods race, exactly one INSERT succeeds (the
        other rolls back on IntegrityError) so the seed runs once total.
        """
        from sqlalchemy.exc import IntegrityError
        import json as _json
        sentinel_key = f"_seed_done_{kind}"

        # Fast path — sentinel already set, skip without opening a write txn.
        # Legacy-install case (rules exist but sentinel cleared) is handled
        # by the slow path's post-claim re-check below.
        with self.get_session(read_only=True) as session:
            if session.query(AgentConfig).filter(
                    AgentConfig.key == sentinel_key).first() is not None:
                return 0

        # Slow path — claim the sentinel via UNIQUE constraint.
        with self.get_session() as session:
            try:
                sentinel = AgentConfig(
                    key=sentinel_key,
                    value_json=_json.dumps(True),
                    description=f"Seed marker for {kind} rules — DO NOT DELETE",
                )
                session.add(sentinel)
                session.flush()
            except IntegrityError:
                # Another pod won the race; its seed is/will be visible.
                session.rollback()
                return 0

            # We claimed the sentinel — re-check the rules count under the
            # active transaction (defends against legacy installs where
            # rules exist but sentinel was cleared).
            existing_rows = session.query(AgentRule).filter(
                AgentRule.kind == kind).count()
            if existing_rows > 0:
                return 0

            inserted = 0
            for idx, d in enumerate(defaults):
                row = AgentRule(
                    kind=kind,
                    enabled=True,
                    priority=idx,        # preserve in-code ordering
                    is_seed=True,
                    description=d.get("description") or "(seed)",
                    severity=d.get("severity"),
                    action=d.get("action"),
                    pattern=d.get("pattern"),
                    strategy=d.get("strategy"),
                    max_retries=d.get("max_retries"),
                    metric=d.get("metric"),
                    op=d.get("op"),
                    threshold=d.get("threshold"),
                    message=d.get("message"),
                )
                session.add(row)
                inserted += 1
            session.flush()
            return inserted

    # The fields a seeded rule carries from the in-code defaults.
    _AGENT_RULE_SEED_FIELDS = ("description", "severity", "action", "pattern",
                               "strategy", "max_retries", "metric", "op",
                               "threshold", "message")

    def agent_rules_sync_seeds(self, kind: str, defaults: List[Dict[str, Any]]) -> int:
        """Bring the UNEDITED seeded rules of ``kind`` up to the in-code defaults.

        2026-10-07.  ``agent_rules_seed_if_empty`` copies the in-code rules
        ONCE; after that the DB rows are the ruleset (RulesEngine reads them
        first).  A pattern fixed in code therefore reached no seeded
        install: Trino's "must be an aggregate expression or appear in
        GROUP BY clause" was added to ``QUERY_FIX_RULES`` and every rig and
        deployment kept classifying it as nothing.

        Which rows follow the code: ``is_seed`` rows an admin never touched
        -- ``updated_by`` is NULL (the admin route always stamps it) and the
        row is still enabled.  An edited or disabled seed row is the admin's
        decision and is never rewritten.  Rows an admin added are never
        touched.  A seed row is matched to its default by (strategy, the
        n-th rule of that strategy) in insert order, so a rule inserted in
        code elsewhere in the list does not shift every row.  Matched and
        unedited -> rewritten in place (id kept); a default with no row ->
        inserted; an unedited seed row with no default -> deleted (the rule
        left the code).  An admin who DELETED a built-in rule gets it back
        when the in-code ruleset next changes -- disable it to keep it off.

        Runs once per ruleset: the digest of ``defaults`` is stamped in
        ``agent_config`` (``_seed_version_<kind>``), claimed with the same
        UNIQUE / compare-and-set discipline as the seed sentinel so two pods
        do not both rewrite.  Returns the number of rows changed.
        """
        import hashlib
        import json as _json
        from sqlalchemy.exc import IntegrityError
        fields = self._AGENT_RULE_SEED_FIELDS
        canon = [{f: d.get(f) for f in fields} for d in defaults]
        digest = hashlib.sha256(
            _json.dumps(canon, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()
        version_key = f"_seed_version_{kind}"
        stamped = _json.dumps(digest)

        with self.get_session(read_only=True) as session:
            row = session.query(AgentConfig).filter(
                AgentConfig.key == version_key).first()
            if row is not None and row.value_json == stamped:
                return 0
            prior = row.value_json if row is not None else None

        with self.get_session() as session:
            # Claim this ruleset version (compare-and-set, or the UNIQUE key).
            try:
                if prior is None:
                    session.add(AgentConfig(
                        key=version_key, value_json=stamped,
                        description=f"Digest of the in-code {kind} rules the seeded rows follow -- DO NOT EDIT",
                    ))
                    session.flush()
                else:
                    claimed = session.query(AgentConfig).filter(
                        AgentConfig.key == version_key,
                        AgentConfig.value_json == prior,
                    ).update({"value_json": stamped}, synchronize_session=False)
                    if not claimed:
                        return 0   # another pod synced this version
            except IntegrityError:
                session.rollback()
                return 0

            def _identity(strategy_or_metric: Any, seen: Dict[Any, int]) -> Tuple[Any, int]:
                n = seen.get(strategy_or_metric, 0)
                seen[strategy_or_metric] = n + 1
                return (strategy_or_metric, n)

            seed_rows = (session.query(AgentRule)
                         .filter(AgentRule.kind == kind, AgentRule.is_seed == True)  # noqa: E712
                         .order_by(AgentRule.id.asc()).all())
            seen_rows: Dict[Any, int] = {}
            by_identity: Dict[Tuple[Any, int], Any] = {}
            for r in seed_rows:
                by_identity[_identity(r.strategy or r.metric, seen_rows)] = r

            changed = 0
            seen_defaults: Dict[Any, int] = {}
            wanted = set()
            for idx, d in enumerate(defaults):
                ident = _identity(d.get("strategy") or d.get("metric"), seen_defaults)
                wanted.add(ident)
                r = by_identity.get(ident)
                if r is None:
                    session.add(AgentRule(
                        kind=kind, enabled=True, priority=idx, is_seed=True,
                        **{f: (d.get(f) if f != "description"
                               else (d.get(f) or "(seed)")) for f in fields},
                    ))
                    changed += 1
                    continue
                if r.updated_by is not None or not r.enabled:
                    continue   # the admin's decision
                differs = r.priority != idx or any(
                    getattr(r, f) != (d.get(f) if f != "description"
                                      else (d.get(f) or "(seed)"))
                    for f in fields)
                if differs:
                    for f in fields:
                        setattr(r, f, d.get(f) if f != "description"
                                else (d.get(f) or "(seed)"))
                    r.priority = idx
                    changed += 1
            for ident, r in by_identity.items():
                if ident not in wanted and r.updated_by is None and r.enabled:
                    session.delete(r)
                    changed += 1
            session.flush()
            if changed:
                logger.info("[agent-rules] %d seeded %s rule(s) brought up to the "
                            "in-code defaults (admin-edited rows untouched)",
                            changed, kind)
            return changed

    # ── BF-320: background_jobs paused-state persistence ─────────────────────

    def get_background_job_state(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(BackgroundJobState).filter(
                BackgroundJobState.name == name).first()
            return row.to_dict() if row else None

    def list_background_job_states(self) -> list:
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in session.query(BackgroundJobState).all()]

    def set_background_job_paused(self, name: str, paused: bool,
                                    paused_by: Optional[str] = None) -> None:
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            row = session.query(BackgroundJobState).filter(
                BackgroundJobState.name == name).first()
            if row:
                row.paused = bool(paused)
                row.paused_at = now if paused else None
                row.paused_by = paused_by if paused else None
                row.updated_at = now
            else:
                session.add(BackgroundJobState(
                    name=name, paused=bool(paused),
                    paused_at=now if paused else None,
                    paused_by=paused_by if paused else None,
                    updated_at=now,
                ))

    # ── 2026-09-01: per-pod daemon heartbeats (cross-pod admin visibility) ───

    def record_daemon_heartbeat(self, pod_id: str, pod_role: str,
                                 jobs: list) -> int:
        """Upsert this pod's view of its own daemons.  Returns rows written.

        Only the OWNING pod writes its rows, so the table is a set of
        first-hand reports rather than one pod's guess about another.
        Placeholders are filtered out by the caller for the same reason: a
        placeholder knows nothing, and a row saying "remote" would compete
        with the real report from the pod that runs it.
        """
        if not pod_id or not jobs:
            return 0
        now = datetime.now(timezone.utc)
        written = 0
        with self.get_session() as session:
            # One SELECT for the whole pod rather than one per daemon: this
            # runs every few seconds, and a per-row lookup made it ~28 round
            # trips a tick for an answer that fits in a single query.
            existing = {r.name: r for r in session.query(DaemonHeartbeat).filter(
                DaemonHeartbeat.pod_id == pod_id).all()}
            for j in jobs:
                name = j.get("name")
                if not name:
                    continue
                row = existing.get(name)
                if row is None:
                    row = DaemonHeartbeat(pod_id=pod_id, name=name)
                    session.add(row)
                row.pod_role      = pod_role
                row.status        = j.get("status")
                row.running       = bool(j.get("running"))
                row.paused        = bool(j.get("paused"))
                row.restart_count = int(j.get("restart_count") or 0)
                # Truncated: a traceback in a status table is a storage leak,
                # and the log already has the full text.
                err = j.get("last_error")
                row.last_error    = (str(err)[:2000] if err else None)
                row.updated_at    = now
                written += 1
        return written

    def list_daemon_heartbeats(self, max_age_seconds: Optional[int] = None) -> list:
        """Every pod's daemon rows.  ``max_age_seconds`` filters out pods
        that have stopped reporting.

        Filtering is done in Python rather than SQL because ``updated_at``
        is written from each pod's own clock: a pod whose clock runs ahead
        would otherwise be silently excluded by a WHERE clause, and a
        vanished daemon is precisely what must not be silently excluded.
        """
        with self.get_session(read_only=True) as session:
            rows = [r.to_dict() for r in session.query(DaemonHeartbeat).all()]
        if max_age_seconds is None:
            return rows
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=max_age_seconds)
        out = []
        for r in rows:
            ts = r.get("updated_at")
            if not ts:
                continue
            try:
                seen = datetime.fromisoformat(ts)
                if seen.tzinfo is None:
                    seen = seen.replace(tzinfo=timezone.utc)
            except Exception:
                out.append(r)      # unparseable: show it, do not hide it
                continue
            r["stale"] = seen < cutoff
            out.append(r)
        return out

    # ── Phase 130 hotfix-13: per-pod worker health heartbeats ────────────────

    def record_worker_health(self, pod_id: str, *,
                              last_tick_result: Optional[dict] = None,
                              inflight_count: int = 0,
                              shard: Optional[str] = None) -> None:
        """Upsert the per-pod heartbeat.  Called by the queue worker
        on every poll tick.  Multi-pod safe via primary-key upsert."""
        if not pod_id:
            return
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            row = session.query(WorkerHealthState).filter(
                WorkerHealthState.pod_id == pod_id).first()
            if row:
                row.last_tick_at      = now
                row.last_tick_result  = last_tick_result or {}
                row.inflight_count    = int(inflight_count or 0)
                if shard is not None:
                    row.shard         = shard
                row.updated_at        = now
            else:
                session.add(WorkerHealthState(
                    pod_id=pod_id,
                    last_tick_at=now,
                    last_tick_result=last_tick_result or {},
                    inflight_count=int(inflight_count or 0),
                    shard=shard,
                    updated_at=now,
                ))

    def list_worker_health(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in
                     session.query(WorkerHealthState)
                            .order_by(WorkerHealthState.pod_id).all()]

    def cleanup_stale_worker_health(self, stale_after_seconds: int = 3600) -> int:
        """Remove pod heartbeats older than ``stale_after_seconds``.
        Default 1h — much longer than the staleness threshold for
        "native unhealthy" (180 s) so we keep dead-pod evidence around
        long enough for ops to see it.  Returns number of rows pruned."""
        from datetime import timedelta
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=int(stale_after_seconds))
        with self.get_session() as session:
            n = session.query(WorkerHealthState).filter(
                WorkerHealthState.last_tick_at < cutoff,
            ).delete()
            return int(n or 0)

    # ── Phase 130 hotfix-13: generic admin-tunable runtime settings ─────────

    def get_system_setting(self, key: str, default: Any = None) -> Any:
        """Read a runtime setting from the DB.  Returns ``default`` when
        the key is absent.  Callers that need richer metadata
        (updated_by, updated_at) should use ``get_system_setting_meta``."""
        with self.get_session(read_only=True) as session:
            row = session.query(SystemSetting).filter(
                SystemSetting.key == key).first()
            if row is None:
                return default
            return row.value

    def get_system_setting_meta(self, key: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(SystemSetting).filter(
                SystemSetting.key == key).first()
            return row.to_dict() if row else None

    def set_system_setting(self, key: str, value: Any,
                            updated_by: Optional[str] = None,
                            description: Optional[str] = None) -> Dict[str, Any]:
        """Upsert a runtime setting.  ``value`` must be JSON-serialisable
        (str, int, float, bool, list, dict, None).  Returns the post-write
        row as a dict so callers can echo it back to the admin UI.

        Phase H (2026-06-08) — race-safe.  Two pods that bootstrap the
        same key concurrently used to hit ``UNIQUE`` constraint violation
        because the GET-then-INSERT-or-UPDATE pattern was not atomic.
        Now we catch IntegrityError on insert and retry as an update
        (idempotent: last-write-wins) so bootstrap from two pods doesn't
        crash either of them.
        """
        from sqlalchemy.exc import IntegrityError

        now = datetime.now(timezone.utc)
        # Defensive truncation to the VARCHAR column limits (description=500,
        # updated_by=100).  A long description (a verbose setting doc) must
        # NEVER raise StringDataRightTruncation on flush — that aborts the
        # transaction and cascades failures across a whole bootstrap batch
        # ("value too long for type character varying(500)").
        if isinstance(description, str) and len(description) > 500:
            description = description[:497] + "..."
        if isinstance(updated_by, str) and len(updated_by) > 100:
            updated_by = updated_by[:100]
        for _attempt in range(2):
            try:
                with self.get_session() as session:
                    row = session.query(SystemSetting).filter(
                        SystemSetting.key == key).first()
                    if row:
                        row.value = value
                        if description is not None:
                            row.description = description
                        row.updated_by = updated_by
                        row.updated_at = now
                    else:
                        row = SystemSetting(
                            key=key, value=value, description=description,
                            updated_by=updated_by, updated_at=now,
                        )
                        session.add(row)
                    session.flush()
                    return row.to_dict()
            except IntegrityError:
                # Peer pod inserted the row between our SELECT and INSERT.
                # Retry — the second iteration will find the row and do
                # an UPDATE instead of INSERT.
                if _attempt == 0:
                    # 2026-08-10 -- was ``self.logger``, which DatabaseManager
                    # has never defined (this was its only use in the file).
                    # Inside an IntegrityError handler, so the AttributeError
                    # replaced the IntegrityError it was reporting on.
                    logger.debug(
                        "set_system_setting(%s): IntegrityError on insert "
                        "(likely concurrent peer bootstrap) -- retrying as "
                        "update", key)
                    continue
                raise
        # Defensive: should never reach here
        raise RuntimeError(f"set_system_setting({key}) failed after retry")

    def system_settings_version(self, prefix: Optional[str] = None) -> Optional[str]:
        """Phase H (2026-06-08) -- DB-authoritative version stamp.

        Returns the latest ``updated_at`` across rows matching ``prefix``
        as an ISO string.  Used by iceberg_watcher / iceberg_db_first
        for cross-pod cache coherence -- bumps automatically when
        set_system_setting writes the column.

        Why this and not a wall-clock counter?  Two pods with clocks
        skewed apart could write timestamps that go BACKWARDS, defeating
        the version-compare logic.  DB's own ``onupdate`` always uses
        the DB server's clock, which is single-source-of-truth across
        pods.
        """
        try:
            from sqlalchemy import func, select
            with self.get_session(read_only=True) as session:
                q = select(func.max(SystemSetting.updated_at))
                if prefix:
                    q = q.where(SystemSetting.key.like(f"{prefix}%"))
                result = session.execute(q).scalar()
                if result is None:
                    return None
                # Normalise to UTC ISO for cross-pod comparison
                if result.tzinfo is None:
                    result = result.replace(tzinfo=timezone.utc)
                return result.isoformat()
        except Exception:
            return None

    def list_system_settings(self, prefix: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all settings, optionally filtered by key prefix
        (e.g. ``'feed_generation.'``).  Sorted by key."""
        with self.get_session(read_only=True) as session:
            q = session.query(SystemSetting)
            if prefix:
                q = q.filter(SystemSetting.key.like(f"{prefix}%"))
            return [r.to_dict() for r in q.order_by(SystemSetting.key).all()]

    def delete_system_setting(self, key: str) -> bool:
        with self.get_session() as session:
            row = session.query(SystemSetting).filter(
                SystemSetting.key == key).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── BF-312: custom background jobs ────────────────────────────────────────

    def create_custom_job(self, *, name: str, description: Optional[str],
                            job_type: str, parameters: dict,
                            cron_expression: str, enabled: bool = True,
                            created_by: Optional[str] = None) -> Dict[str, Any]:
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            row = CustomBackgroundJob(
                name=name, description=description, job_type=job_type,
                parameters=parameters or {}, cron_expression=cron_expression,
                enabled=bool(enabled), created_by=created_by,
                created_at=now, updated_at=now,
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def get_custom_job(self, job_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(CustomBackgroundJob).filter(
                CustomBackgroundJob.id == int(job_id)).first()
            return row.to_dict() if row else None

    def get_custom_job_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(CustomBackgroundJob).filter(
                CustomBackgroundJob.name == name).first()
            return row.to_dict() if row else None

    def list_custom_jobs(self, *, enabled_only: bool = False) -> list:
        with self.get_session(read_only=True) as session:
            q = session.query(CustomBackgroundJob)
            if enabled_only:
                q = q.filter(CustomBackgroundJob.enabled == True)  # noqa: E712
            return [r.to_dict() for r in q.order_by(CustomBackgroundJob.id.asc()).all()]

    def update_custom_job(self, job_id: int, **fields) -> Optional[Dict[str, Any]]:
        """Update mutable fields on a custom job.  Whitelist guards
        against client passing internal columns."""
        allowed = {
            "name", "description", "job_type", "parameters",
            "cron_expression", "enabled", "last_run_at", "last_status",
            "last_error", "last_duration_seconds", "last_output",
            "next_run_at", "run_count", "error_count",
            "running_since",     # released (None) when a run's outcome lands
        }
        with self.get_session() as session:
            row = session.query(CustomBackgroundJob).filter(
                CustomBackgroundJob.id == int(job_id)).first()
            if not row:
                return None
            for k, v in fields.items():
                if k in allowed:
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def delete_custom_job(self, job_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(CustomBackgroundJob).filter(
                CustomBackgroundJob.id == int(job_id)).first()
            if not row:
                return False
            session.delete(row)
            return True

    def list_due_custom_jobs(self, now: Optional[datetime] = None) -> list:
        """Return enabled jobs whose next_run_at <= now (or with next_run_at
        unset, meaning they need an initial schedule)."""
        with self.get_session(read_only=True) as session:
            ts = now or datetime.now(timezone.utc)
            q = session.query(CustomBackgroundJob).filter(
                CustomBackgroundJob.enabled == True,  # noqa: E712
            ).filter(
                (CustomBackgroundJob.next_run_at == None)  # noqa: E711
                | (CustomBackgroundJob.next_run_at <= ts)
            )
            return [r.to_dict() for r in q.all()]

    def claim_due_custom_job(
        self, job_id: int, *, new_next_run_at: datetime,
        now: Optional[datetime] = None,
    ) -> bool:
        """Atomically CLAIM a due custom job for exactly-once execution.

        Multi-pod safe — mirrors the proven queue_worker atomic-claim
        pattern (``UPDATE ... WHERE status='pending'``).  A single
        conditional UPDATE advances ``next_run_at`` to the job's NEXT
        firing, gated on the row still being due (``next_run_at`` NULL or
        ``<= now``) AND enabled.  The DB serialises concurrent UPDATEs on
        the same row, so only ONE pod's statement matches the still-due
        predicate (rowcount==1) and wins the claim; every other pod then
        sees the already-advanced ``next_run_at`` and matches 0 rows.

        Advancing ``next_run_at`` AS PART OF the claim is the crash-
        recovery guarantee: if the winning pod dies mid-run, the schedule
        is NOT lost — the row is already set to fire again at the next
        cron tick.  A crashed occurrence is skipped (never duplicated),
        the correct trade for non-idempotent job types (webhook / sql).

        Single-pod: the sole pod always matches the due predicate, so a
        legitimately-due job's claim ALWAYS succeeds — behaviour is
        identical to the pre-claim read-then-run path.

        Returns True iff THIS caller won the claim.

        2026-10-10: the scheduled spelling of :meth:`claim_custom_job_run`
        (``require_due=True``); kept so the loop and its tests read the
        same name.  The run-now route takes the SAME claim with
        ``require_due=False``.
        """
        return self.claim_custom_job_run(
            job_id, new_next_run_at=new_next_run_at, now=now, require_due=True)

    #: How long a run lease (``running_since``) is honoured before a later
    #: claim may take the job over.  A pod that dies mid-run leaves the
    #: lease set; until it ages out the job does NOT run again (a skipped
    #: occurrence is the correct trade for a webhook / SQL job -- unknown
    #: is unsafe), after it the next claim wins and logs the takeover.
    CUSTOM_JOB_RUN_LEASE_SECONDS = 3600

    def claim_custom_job_run(
        self, job_id: int, *, new_next_run_at: Optional[datetime],
        now: Optional[datetime] = None, require_due: bool = True,
        lease_seconds: Optional[int] = None,
    ) -> bool:
        """THE claim for one run of a custom job -- the scheduler loop and
        ``POST /api/admin/custom-jobs/{id}/run-now`` both take it (2026-10-10;
        the route used to read-then-run with no claim at all, so two clicks
        or two pods ran the same webhook / SQL twice, and a click during a
        scheduled run ran it beside that run).

        ONE conditional UPDATE, serialised by the database on the row:
        it takes the run LEASE (``running_since = now``) and, when given,
        advances ``next_run_at``; it matches only while the lease is free
        (NULL, or older than ``lease_seconds``) -- and, for the scheduled
        caller (``require_due``), only while the job is enabled and due.
        rowcount 1 = this caller runs; 0 = someone else does (another pod
        won the occurrence, or a run is in flight).  A run-now does not
        require ``due`` or ``enabled``: an admin may test a disabled job's
        configuration, one run at a time.

        The lease is released by recording the run's outcome
        (``update_custom_job(..., running_since=None)``, built once in
        ``core.custom_jobs.run_outcome_updates``).
        """
        from sqlalchemy import or_
        ts = now or datetime.now(timezone.utc)
        ttl = int(lease_seconds if lease_seconds is not None
                  else self.CUSTOM_JOB_RUN_LEASE_SECONDS)
        stale_before = ts - timedelta(seconds=max(1, ttl))
        filters = [
            CustomBackgroundJob.id == int(job_id),
            or_(
                CustomBackgroundJob.running_since == None,  # noqa: E711
                CustomBackgroundJob.running_since < stale_before,
            ),
        ]
        if require_due:
            filters.append(CustomBackgroundJob.enabled == True)  # noqa: E712
            filters.append(or_(
                CustomBackgroundJob.next_run_at == None,  # noqa: E711
                CustomBackgroundJob.next_run_at <= ts,
            ))
        values: Dict[str, Any] = {"running_since": ts}
        if new_next_run_at is not None:
            values["next_run_at"] = new_next_run_at
        with self.get_session() as session:
            # Takeover disclosure: a lease older than the TTL is a run that
            # never recorded its outcome (the pod died).  Say so.
            prior = session.query(CustomBackgroundJob.running_since).filter(
                CustomBackgroundJob.id == int(job_id)).first()
            count = session.query(CustomBackgroundJob).filter(*filters).update(
                values, synchronize_session=False)
            won = int(count or 0) > 0
            if won and prior is not None and prior[0] is not None:
                logger.warning(
                    "custom job %s: taking over a run lease held since %s "
                    "(older than %ds) -- the run that took it never "
                    "recorded an outcome", job_id, prior[0], ttl)
            return won

    # ── BF-299: watched tables registry ───────────────────────────────────────

    def upsert_watched_iceberg_table(self, *, connection_id: int, bucket: str,
                                       table_prefix: str,
                                       pinned: Optional[bool] = None,
                                       enabled: Optional[bool] = None,
                                       predownload_rule: Optional[dict] = None,
                                       column_stats_rule: Optional[dict] = None,
                                       mark_queried: bool = False
                                       ) -> Dict[str, Any]:
        """Insert if missing, otherwise touch ``last_queried_at`` (when
        ``mark_queried=True``) or update ``pinned``/``enabled`` flags.

        Called from the iceberg reader on first sight of a table so the
        sync job auto-discovers what to keep fresh.
        """
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            existing = session.query(WatchedIcebergTable).filter(
                WatchedIcebergTable.connection_id == connection_id,
                WatchedIcebergTable.bucket == bucket,
                prefix_matches(WatchedIcebergTable.table_prefix, table_prefix),
            ).first()
            if existing:
                if mark_queried:
                    existing.last_queried_at = now
                if pinned is not None:
                    existing.pinned = bool(pinned)
                if enabled is not None:
                    existing.enabled = bool(enabled)
                if predownload_rule is not None:
                    existing.predownload_rule = predownload_rule
                if column_stats_rule is not None:
                    existing.column_stats_rule = column_stats_rule
                session.flush()
                return existing.to_dict()
            row = WatchedIcebergTable(
                connection_id=connection_id, bucket=bucket,
                table_prefix=table_prefix,
                pinned=bool(pinned) if pinned is not None else False,
                enabled=bool(enabled) if enabled is not None else True,
                predownload_rule=predownload_rule,
                column_stats_rule=column_stats_rule,
                created_at=now, last_queried_at=now,
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def update_watched_iceberg_sync(self, *, connection_id: int, bucket: str,
                                      table_prefix: str,
                                      snapshot_id: Optional[str] = None,
                                      status: str = "ok",
                                      error: Optional[str] = None,
                                      duration_seconds: Optional[float] = None,
                                      files_count: Optional[int] = None
                                      ) -> Optional[Dict[str, Any]]:
        """Record the result of a sync attempt.

        149.10 (2026-06-09) — when ``snapshot_id`` differs from the
        previously-stored value, fire registered listeners (best-effort,
        async) so dependent systems (brain freshness, downstream caches)
        can react to the snapshot roll forward without polling.
        Heartbeat-style updates (snapshot unchanged) do NOT fire
        listeners.  Listeners are registered via
        ``register_snapshot_change_listener`` below.
        """
        now = datetime.now(timezone.utc)
        old_snapshot_id: Optional[str] = None
        with self.get_session() as session:
            row = session.query(WatchedIcebergTable).filter(
                WatchedIcebergTable.connection_id == connection_id,
                WatchedIcebergTable.bucket == bucket,
                prefix_matches(WatchedIcebergTable.table_prefix, table_prefix),
            ).first()
            if not row:
                return None
            # 149.10 — capture pre-update snapshot to detect a real roll
            old_snapshot_id = row.last_snapshot_id
            row.last_synced_at    = now
            row.last_sync_status  = status
            row.last_sync_error   = error
            row.last_sync_seconds = duration_seconds
            if snapshot_id is not None:
                row.last_snapshot_id = str(snapshot_id)
            if files_count is not None:
                row.last_files_count = int(files_count)
            session.flush()
            out = row.to_dict()
        # 149.10 — fire listeners OUTSIDE the DB session so a slow
        # listener can't hold the connection.  Only fire on a REAL
        # snapshot change; the watcher heartbeats every 5 min even
        # when nothing has changed.
        #
        # 2026-09-27 — the FIRST sync fires too.  Until now the condition
        # required ``old_snapshot_id is not None``, so a table's first
        # observed snapshot (a freshly registered table, or the first
        # commit to a table watched while empty) reached NO listener:
        # no warm, no freshness scan, no mirror mark, and — with the
        # Iceberg-commit arrival source — no dependency arrival for the
        # data that had just landed.  A snapshot the row has never seen
        # is a change from the row's point of view; listeners receive
        # ``old_snapshot_id=None`` and every existing one already tolerates
        # it (they stringify only when truthy).
        if (snapshot_id is not None
                and (old_snapshot_id is None
                     or str(snapshot_id) != str(old_snapshot_id))):
            _fire_snapshot_change_listeners(
                connection_id=connection_id,
                bucket=bucket,
                table_prefix=table_prefix,
                old_snapshot_id=(str(old_snapshot_id)
                                 if old_snapshot_id is not None else None),
                new_snapshot_id=str(snapshot_id),
            )
        return out

    def get_watched_iceberg_table(self, *, connection_id: int, bucket: str,
                                  table_prefix: str) -> Optional[Dict[str, Any]]:
        """One watched-table row, or None when the table is not watched.

        2026-09-27 — the Iceberg-commit arrival source and the registered-
        tables listing both ask "is this table observed?" per table; the
        1000-row listing they used to filter in Python is the wrong tool
        for a per-row question inside a gate evaluated every poll.
        """
        with self.get_session(read_only=True) as session:
            row = session.query(WatchedIcebergTable).filter(
                WatchedIcebergTable.connection_id == int(connection_id),
                WatchedIcebergTable.bucket == bucket,
                prefix_matches(WatchedIcebergTable.table_prefix, table_prefix),
            ).first()
            return row.to_dict() if row else None

    def list_watched_iceberg_tables(self, *,
                                     enabled_only: bool = True,
                                     limit: int = 1000,
                                     order_by: str = "recency") -> list:
        """List watched Iceberg tables.

        ``order_by`` (default ``"recency"``, backwards-compatible):
          * ``"recency"``      — most-recently-QUERIED first
            (``last_queried_at DESC``).  The hot-table bias used by the
            watcher and the metadata-sync tick's primary selection.
          * ``"stalest_sync"`` — least-recently-SYNCED first
            (``last_synced_at ASC``).  NULL (never synced) sorts FIRST under
            SQLite ASC ordering, so never-synced tables are treated as the
            stalest — exactly the forward-progress priority the fair
            cold-table scheduler (Item B) needs.  Ties broken by oldest
            ``last_queried_at`` so the ordering is deterministic.
        """
        with self.get_session(read_only=True) as session:
            q = session.query(WatchedIcebergTable)
            if enabled_only:
                q = q.filter(WatchedIcebergTable.enabled == True)  # noqa: E712
            if order_by == "stalest_sync":
                # SQLite sorts NULLs first on ASC — never-synced tables lead,
                # which is the desired "stalest" priority.
                q = q.order_by(
                    WatchedIcebergTable.last_synced_at.asc(),
                    WatchedIcebergTable.last_queried_at.asc(),
                )
            else:
                q = q.order_by(WatchedIcebergTable.last_queried_at.desc())
            q = q.limit(limit)
            return [r.to_dict() for r in q.all()]

    def delete_watched_iceberg_table(self, *, connection_id: int, bucket: str,
                                       table_prefix: str) -> bool:
        with self.get_session() as session:
            row = session.query(WatchedIcebergTable).filter(
                WatchedIcebergTable.connection_id == connection_id,
                WatchedIcebergTable.bucket == bucket,
                prefix_matches(WatchedIcebergTable.table_prefix, table_prefix),
            ).first()
            if not row:
                return False
            session.delete(row)
            return True

    # ── BF-298: Iceberg per-manifest content cache ────────────────────────────

    # 2026-06-04 user-reported critical perf bug — every cache LOOKUP
    # used to fire a sync `UPDATE iceberg_manifest_cache SET
    # last_accessed=?` inside the read.  Under load (100 manifests per
    # query setup × N concurrent queries) this serialised through the
    # SQLite write lock and produced 12,259-second statements blocking
    # the asyncio loop.  Replaced with an in-memory recency dict that
    # the LRU eviction job reads alongside the DB column — no per-
    # lookup DB write.  In-memory state is best-effort across pod
    # restarts (worst case: LRU temporarily picks a slightly-older
    # entry on the first eviction after restart — recovered on the
    # next access).
    _MANIFEST_CACHE_RECENCY: Dict[int, float] = {}   # cache_id → last_access_ts
    _MANIFEST_CACHE_RECENCY_LOCK = threading.Lock()

    def get_iceberg_manifest_cache(self, bucket: str, manifest_path: str
                                     ) -> Optional[Dict[str, Any]]:
        import time as _time
        from sqlalchemy.orm import undefer as _undefer
        with self.get_session(read_only=True) as session:
            # 2026-06-04 — IcebergManifestCache.entries is DEFERRED at the
            # model level so cheap existence checks don't pull the
            # multi-MB JSONB payload.  THIS call is the hot read path
            # that actually NEEDS entries, so undefer it in the original
            # query (single round-trip instead of N+1).
            e = session.query(IcebergManifestCache).options(
                _undefer(IcebergManifestCache.entries)
            ).filter(
                IcebergManifestCache.bucket == bucket,
                IcebergManifestCache.manifest_path == manifest_path,
            ).first()
            if not e:
                return None
            entries = e.entries
            # In-memory recency stamp (no DB write).  LRU job consults
            # this dict + the DB column and uses max() of both.
            try:
                with DatabaseManager._MANIFEST_CACHE_RECENCY_LOCK:
                    DatabaseManager._MANIFEST_CACHE_RECENCY[e.id] = _time.time()
            except Exception:
                pass
            return {
                "id":            e.id,
                "bucket":        e.bucket,
                "manifest_path": e.manifest_path,
                "entries":       entries,
                "entry_count":   e.entry_count,
                "bytes_stored":  e.bytes_stored,
                "created_at":    e.created_at.isoformat() if e.created_at else None,
                "last_accessed": e.last_accessed.isoformat() if e.last_accessed else None,
            }

    def set_iceberg_manifest_cache(self, bucket: str, manifest_path: str,
                                     entries: list,
                                     bytes_stored: int = 0) -> Dict[str, Any]:
        import time as _time
        now = datetime.now(timezone.utc)
        # 2026-06-04 — for the "already exists" branch, skip the write
        # entirely.  Manifests are immutable so the entry's data
        # hasn't changed; just record in-memory recency.  Eliminates
        # the second write storm.
        with self.get_session(read_only=True) as rsess:
            existing = rsess.query(IcebergManifestCache).filter(
                IcebergManifestCache.bucket == bucket,
                IcebergManifestCache.manifest_path == manifest_path,
            ).first()
            if existing:
                try:
                    with DatabaseManager._MANIFEST_CACHE_RECENCY_LOCK:
                        DatabaseManager._MANIFEST_CACHE_RECENCY[existing.id] = _time.time()
                except Exception:
                    pass
                return existing.to_dict()
        # Genuine insert — must take a write session.
        import logging as _ic_log
        _logger_ic = _ic_log.getLogger(__name__)
        try:
            with self.get_session() as session:
                # Double-check inside the write transaction (race-safe).
                existing = session.query(IcebergManifestCache).filter(
                    IcebergManifestCache.bucket == bucket,
                    IcebergManifestCache.manifest_path == manifest_path,
                ).first()
                if existing:
                    return existing.to_dict()
                _logger_ic.info(
                    "set_iceberg_manifest_cache INSERT: bucket=%r "
                    "manifest_path=%r entry_count=%d bytes_stored=%d",
                    bucket, manifest_path, len(entries), int(bytes_stored or 0),
                )
                e = IcebergManifestCache(
                    bucket=bucket, manifest_path=manifest_path,
                    entries=entries, entry_count=len(entries),
                    bytes_stored=int(bytes_stored or 0),
                    created_at=now, last_accessed=now,
                )
                session.add(e)
                session.flush()
                _logger_ic.info(
                    "set_iceberg_manifest_cache COMMIT-OK: id=%s bucket=%r "
                    "manifest_path=%r", e.id, bucket, manifest_path,
                )
                return e.to_dict()
        except Exception as _ic_ins_exc:
            # 2026-06-15 — concurrent-insert race: two workers scanning the
            # same iceberg table both check "does this exist?", both see
            # "no", both INSERT.  First wins, second hits the unique
            # constraint on (bucket, manifest_path).  This is FUNCTIONALLY
            # SUCCESS — the row is now in the DB — so re-query and return
            # the winning row instead of raising and spamming ERROR logs
            # (one per worker, scaled with workload size).
            from sqlalchemy.exc import IntegrityError as _IntegrityError
            if isinstance(_ic_ins_exc, _IntegrityError):
                _err_str = str(_ic_ins_exc).lower()
                # Be specific: only swallow when it's THIS table's unique
                # constraint.  FK / NOT NULL / other integrity errors must
                # still surface.
                if ("ix_iceberg_manifest_cache_lookup" in _err_str or
                    "iceberg_manifest_cache" in _err_str and "unique" in _err_str):
                    try:
                        with self.get_session(read_only=True) as _rs:
                            _winner = _rs.query(IcebergManifestCache).filter(
                                IcebergManifestCache.bucket == bucket,
                                IcebergManifestCache.manifest_path == manifest_path,
                            ).first()
                            if _winner:
                                _logger_ic.debug(
                                    "set_iceberg_manifest_cache lost-race "
                                    "(another worker won): bucket=%r "
                                    "manifest_path=%r — returning winner",
                                    bucket, manifest_path,
                                )
                                try:
                                    with DatabaseManager._MANIFEST_CACHE_RECENCY_LOCK:
                                        DatabaseManager._MANIFEST_CACHE_RECENCY[_winner.id] = _time.time()
                                except Exception:
                                    pass
                                return _winner.to_dict()
                    except Exception:
                        # Re-fetch itself failed — fall through to the
                        # loud-error path below so we don't silently
                        # swallow a deeper DB problem.
                        pass

            # 2026-06-04 — surface the EXACT SQL-side error for everything
            # else.  Without this, sequence advances on rolled-back inserts
            # (Postgres sequences are non-transactional) but the row never
            # lands — and the only signal was the dropped count.
            _logger_ic.error(
                "set_iceberg_manifest_cache FAILED: bucket=%r "
                "manifest_path=%r entries=%d type=%s msg=%s",
                bucket, manifest_path, len(entries),
                type(_ic_ins_exc).__name__, str(_ic_ins_exc)[:400],
                exc_info=True,
            )
            raise

    def list_iceberg_manifest_cache(self, bucket: Optional[str] = None,
                                      limit: int = 100) -> list:
        with self.get_session(read_only=True) as session:
            q = session.query(IcebergManifestCache)
            if bucket is not None:
                q = q.filter(IcebergManifestCache.bucket == bucket)
            q = q.order_by(IcebergManifestCache.last_accessed.desc()).limit(limit)
            return [e.to_dict() for e in q.all()]

    def delete_iceberg_manifest_cache(self, *, bucket: Optional[str] = None,
                                        manifest_path: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(IcebergManifestCache)
            if bucket is not None:
                q = q.filter(IcebergManifestCache.bucket == bucket)
            if manifest_path is not None:
                q = q.filter(IcebergManifestCache.manifest_path == manifest_path)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def evict_iceberg_manifest_cache_lru(self, max_entries: int = 5000) -> int:
        from datetime import datetime as _dt, timezone as _tz
        # 2026-06-04 — flush in-memory recency stamps into the DB column
        # FIRST so the eviction order honours recent accesses that the
        # async stamping has been collecting since the last sync.
        try:
            with DatabaseManager._MANIFEST_CACHE_RECENCY_LOCK:
                _recency_copy = dict(DatabaseManager._MANIFEST_CACHE_RECENCY)
        except Exception:
            _recency_copy = {}
        if _recency_copy:
            try:
                with self.get_session() as fsess:
                    # Bulk update — one SQL with VALUES would be ideal
                    # but back-compat across SQLite + Postgres uses a
                    # per-row UPDATE inside one transaction.  Bounded
                    # by the recency dict size (typically <5000).
                    _rows = fsess.query(IcebergManifestCache).filter(
                        IcebergManifestCache.id.in_(list(_recency_copy.keys()))
                    ).all()
                    for r in _rows:
                        ts = _recency_copy.get(r.id)
                        if ts is None:
                            continue
                        _dtv = _dt.fromtimestamp(ts, tz=_tz.utc)
                        if r.last_accessed is None or _dtv > r.last_accessed:
                            r.last_accessed = _dtv
                    fsess.flush()
                # Clear flushed entries — keeps the dict bounded.
                with DatabaseManager._MANIFEST_CACHE_RECENCY_LOCK:
                    for k in _recency_copy.keys():
                        DatabaseManager._MANIFEST_CACHE_RECENCY.pop(k, None)
            except Exception:
                # Flush failure must not break the eviction itself.
                pass
        with self.get_session() as session:
            total = session.query(IcebergManifestCache).count()
            if total <= max_entries:
                return 0
            n_to_drop = total - max_entries
            stale = session.query(IcebergManifestCache).order_by(
                IcebergManifestCache.last_accessed.asc()
            ).limit(n_to_drop).all()
            for r in stale:
                session.delete(r)
            return len(stale)

    def evict_iceberg_snapshot_cache_lru(self, max_entries: int = 200) -> int:
        """Drop the least-recently-accessed entries beyond ``max_entries``."""
        from datetime import datetime as _dt, timezone as _tz
        # 2026-06-04 — flush in-memory recency to DB column first.
        try:
            with DatabaseManager._SNAPSHOT_CACHE_RECENCY_LOCK:
                _recency_copy = dict(DatabaseManager._SNAPSHOT_CACHE_RECENCY)
        except Exception:
            _recency_copy = {}
        if _recency_copy:
            try:
                with self.get_session() as fsess:
                    _rows = fsess.query(IcebergSnapshotCache).filter(
                        IcebergSnapshotCache.id.in_(list(_recency_copy.keys()))
                    ).all()
                    for r in _rows:
                        ts = _recency_copy.get(r.id)
                        if ts is None:
                            continue
                        _dtv = _dt.fromtimestamp(ts, tz=_tz.utc)
                        if r.last_accessed is None or _dtv > r.last_accessed:
                            r.last_accessed = _dtv
                    fsess.flush()
                with DatabaseManager._SNAPSHOT_CACHE_RECENCY_LOCK:
                    for k in _recency_copy.keys():
                        DatabaseManager._SNAPSHOT_CACHE_RECENCY.pop(k, None)
            except Exception:
                pass
        with self.get_session() as session:
            total = session.query(IcebergSnapshotCache).count()
            if total <= max_entries:
                return 0
            n_to_drop = total - max_entries
            stale = session.query(IcebergSnapshotCache).order_by(
                IcebergSnapshotCache.last_accessed.asc()
            ).limit(n_to_drop).all()
            for r in stale:
                session.delete(r)
            return len(stale)

    # ── Schema cache ────────────────────────────────────────────────────────────

    def find_schema_cache_by_name(self, table_name: str) -> Optional[Dict[str, Any]]:
        """Find any cached schema matching table_name, regardless of connection."""
        with self.get_session(read_only=True) as session:
            e = session.query(SchemaCache).filter(
                SchemaCache.table_name == table_name
            ).order_by(SchemaCache.updated_at.desc()).first()
            return e.to_dict() if e else None

    _PHYSICAL_SCHEMA_WARNED: set = set()
    _PARTITION_RULE_WARNED: set = set()

    def _partition_rule_stale_row(self, connection_id: int, table_name: str,
                                  row: Dict[str, Any]) -> bool:
        """2026-10-06 -- a plain-parquet S3 schema recorded before the
        undeclared-partition-key rule (``core.hive_partition_types``) wrote
        every partition-only key VARCHAR unexamined, so a ``dt=2026-01-01``
        key would be declared a string to every read.  Such a row is a MISS
        (the physical-types pattern below): the next read records the decided
        types.  Only a row naming partition columns without the rule's marker
        pays the connection-type lookup; a lookup that fails is not stale."""
        from core.hive_partition_types import (
            recorded_partition_types_current, partition_rule_stale_reason)
        sd = row.get("schema_data")
        if not isinstance(sd, dict) or recorded_partition_types_current(sd) or not sd.get("partition_columns"):
            return False
        try:
            with self.get_session(read_only=True) as session:
                conn_type = session.query(Connection.connection_type).filter(
                    Connection.id == connection_id).scalar()
        except Exception as exc:  # noqa: BLE001 -- unknown is not stale
            logger.debug("schema_cache partition-rule check skipped conn=%s: %s",
                         connection_id, exc)
            return False
        reason = partition_rule_stale_reason(
            sd, connection_type=conn_type, table_format=row.get("table_format"))
        if not reason:
            return False
        key = (connection_id, table_name)
        if key not in DatabaseManager._PARTITION_RULE_WARNED:
            DatabaseManager._PARTITION_RULE_WARNED.add(key)
            logger.warning("schema_cache conn=%s table=%s %s -- served as a miss; "
                           "the next read records the decided types",
                           connection_id, table_name, reason)
        return True

    def schema_cache_partition_rule_stale(self, connection_id: int, table_name: str) -> bool:
        """True when the STORED row of this table exists and predates the
        undeclared-partition-key rule (see ``_partition_rule_stale_row``) --
        the column catalog asks this about its own copy of the same read."""
        with self.get_session(read_only=True) as session:
            e = session.query(SchemaCache).filter(
                SchemaCache.connection_id == connection_id,
                SchemaCache.table_name == table_name,
            ).first()
            row = e.to_dict() if e else None
        return bool(row) and self._partition_rule_stale_row(connection_id, table_name, row)

    def get_schema_cache(self, connection_id: int, table_name: str) -> Optional[Dict[str, Any]]:
        """The cached schema of one table, or None (a miss).

        2026-10-06 -- a row whose columns carry a parquet PHYSICAL type name
        (INT32 / BYTE_ARRAY / FIXED_LEN_BYTE_ARRAY ...) was written by the
        pre-2026-10-06 S3 parquet reader and is a MISS, not an answer: its
        DECIMAL read as VARCHAR and refused ``sum()`` in pre-validation, its
        DATE read as a number in the dataset wizard.  Every reader of this
        store treats a miss as "read the source", so the next read replaces
        the row with logical types -- the backfill is the first use.

        2026-10-06 (later) -- the same for a plain-parquet S3 row recorded
        before the undeclared-partition-key rule (``_partition_rule_stale_row``):
        its ``dt=2026-01-01`` key was recorded VARCHAR without a look."""
        with self.get_session(read_only=True) as session:
            e = session.query(SchemaCache).filter(
                SchemaCache.connection_id == connection_id,
                SchemaCache.table_name == table_name,
            ).first()
            row = e.to_dict() if e else None
        if row and self._partition_rule_stale_row(connection_id, table_name, row):
            return None
        if row:
            from core.parquet_utils import physical_type_columns
            bad = physical_type_columns((row.get("schema_data") or {}).get("columns")
                                        if isinstance(row.get("schema_data"), dict) else None)
            if bad:
                key = (connection_id, table_name)
                if key not in DatabaseManager._PHYSICAL_SCHEMA_WARNED:
                    DatabaseManager._PHYSICAL_SCHEMA_WARNED.add(key)
                    logger.warning(
                        "schema_cache conn=%s table=%s carries parquet PHYSICAL "
                        "types (%s ...) from the pre-2026-10-06 reader -- served "
                        "as a miss; the next read stores logical types",
                        connection_id, table_name, ", ".join(bad[:3]))
                return None
        return row

    def set_schema_cache(self, connection_id: int, table_name: str,
                         table_format: str, schema_data: dict) -> Dict[str, Any]:
        """Upsert schema cache — safe for concurrent writers."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = SchemaCache(
                    connection_id=connection_id, table_name=table_name,
                    table_format=table_format, schema_data=schema_data,
                    created_at=now, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(SchemaCache).filter(
                    SchemaCache.connection_id == connection_id,
                    SchemaCache.table_name == table_name,
                ).first()
                if existing:
                    existing.table_format = table_format
                    existing.schema_data = schema_data
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = SchemaCache(
                    connection_id=connection_id, table_name=table_name,
                    table_format=table_format, schema_data=schema_data,
                    created_at=now, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    def delete_schema_cache(self, connection_id: Optional[int] = None,
                            table_name: Optional[str] = None) -> int:
        with self.get_session() as session:
            q = session.query(SchemaCache)
            if connection_id is not None:
                q = q.filter(SchemaCache.connection_id == connection_id)
            if table_name is not None:
                q = q.filter(SchemaCache.table_name == table_name)
            rows = q.all()
            count = len(rows)
            for r in rows:
                session.delete(r)
            return count

    def list_schema_cache_entries(self, connection_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(SchemaCache)
            if connection_id is not None:
                q = q.filter(SchemaCache.connection_id == connection_id)
            return [e.to_dict() for e in q.order_by(SchemaCache.updated_at.desc()).all()]

    # ── Iceberg metadata-key persistent cache ──────────────────────────────────
    # Backs core.iceberg_reader._latest_metadata_key with a DB-persisted layer
    # so a fresh process / first-query-per-table doesn't pay the 27-30s
    # capped-LIST scan against S3 when a table has 15k+ metadata files.
    # See IcebergMetadataKeyCache model docstring for the why.

    def get_iceberg_metadata_key(self, connection_id: Optional[int], cache_id: str
                                 ) -> Optional[Dict[str, Any]]:
        """Return the persisted (metadata_key, updated_at) for this cache_id, or None.

        BF-ICEBERG-CACHE-ANY-CONN: when ``connection_id is None`` (caller's
        boto3 client wasn't tagged via ``make_s3_client_for_conn`` — e.g.
        admin refresh-table path, sync helpers, fallback client builds),
        look up by ``cache_id`` alone and return the freshest row.

        The cache value is content-addressed: ``cache_id`` is
        ``f"{bucket}/{meta_prefix}"`` and the answer (latest metadata.json
        S3 key) is identical regardless of which connection asks.  So
        skipping the connection_id filter on read is safe and lets a
        restart-recovery query hit the warm cache the sync job (or a
        prior pod) populated.
        """
        from core.db.models import IcebergMetadataKeyCache as _IMKC
        with self.get_session(read_only=True) as session:
            q = session.query(_IMKC).filter(_IMKC.cache_id == cache_id)
            if connection_id is not None:
                q = q.filter(_IMKC.connection_id == connection_id)
            else:
                # Pick the most recently refreshed row from any connection.
                q = q.order_by(_IMKC.updated_at.desc())
            e = q.first()
            return e.to_dict() if e else None

    # ── BF-516 Zombie-run scanner (FeedRun + DataFlowRun) ───────────────────────
    # When a worker pod crashes / is OOM-killed mid-execution, the run row keeps
    # ``status='running'`` forever — dashboards mis-report active load and
    # operators have no clean recovery signal.  These two helpers sweep stuck
    # rows and flip them to ``failed`` with an explicit zombie marker so
    # operations can investigate vs. silently re-trigger.

    def mark_zombie_feed_runs(self, max_runtime_seconds: int = 14400) -> int:
        """Flip ``feed_runs.status='running'`` rows older than max_runtime
        to ``failed`` with a zombie marker.  Returns row count.

        Cutoff is computed off ``started_at`` (the actual start of work) NOT
        ``created_at`` (queued-but-not-started rows should stay ``pending``).
        Rows with started_at IS NULL are SKIPPED — they're pending, not
        zombie.  Caller (BF-516 scheduler job) chooses max_runtime_seconds
        from config so admins can tune by feed workload size.
        """
        from core.db.models import FeedRun as _FR
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=int(max_runtime_seconds))
        zombie_msg = (
            f"[ZOMBIE] No heartbeat for >{max_runtime_seconds}s — likely "
            f"worker pod crashed / was OOM-killed mid-execution.  "
            f"Inspect logs around started_at and re-trigger if safe."
        )
        with self.get_session() as session:
            q = session.query(_FR).filter(
                _FR.status == "running",
                _FR.started_at != None,  # noqa: E711 — SQLAlchemy NOT NULL
                _FR.started_at < cutoff,
            )
            count = 0
            for row in q.all():
                row.status = "failed"
                row.error = zombie_msg
                row.completed_at = datetime.now(timezone.utc)
                count += 1
            if count:
                session.flush()
            return count

    def mark_zombie_dataflow_runs(self, max_runtime_seconds: int = 14400) -> int:
        """Same shape as ``mark_zombie_feed_runs`` for the DataFlow surface.

        DataFlow has a richer status set (succeeded | failed | cancelled |
        partial) so zombies always become ``failed`` to avoid colliding with
        the other terminal outcomes — operations can re-classify after
        triage.
        """
        from core.db.models import DataFlowRun as _DFR
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=int(max_runtime_seconds))
        zombie_msg = (
            f"[ZOMBIE] No heartbeat for >{max_runtime_seconds}s — likely "
            f"worker pod crashed / was OOM-killed mid-execution.  "
            f"Inspect logs around started_at and re-trigger if safe."
        )
        with self.get_session() as session:
            q = session.query(_DFR).filter(
                _DFR.status == "running",
                _DFR.started_at != None,  # noqa: E711
                _DFR.started_at < cutoff,
            )
            count = 0
            now_utc = datetime.now(timezone.utc)
            for row in q.all():
                row.status = "failed"
                row.error = zombie_msg
                row.ended_at = now_utc
                if row.started_at:
                    try:
                        # SQLAlchemy may store naive — coerce to aware so the
                        # subtraction never raises.
                        st = row.started_at
                        if st.tzinfo is None:
                            st = st.replace(tzinfo=timezone.utc)
                        row.duration_seconds = (now_utc - st).total_seconds()
                    except Exception as _dur_exc:
                        # Best-effort — zombie marking proceeds even if
                        # the cosmetic duration field can't be filled.
                        import logging as _zl
                        _zl.getLogger(__name__).debug(
                            "BF-516 duration compute failed for "
                            "dataflow_run id=%s: %s", row.id, _dur_exc)
                count += 1
            if count:
                session.flush()
            return count

    # ── BF-541 DuckDB subprocess crash event persistence ────────────────────
    def record_duckdb_subprocess_crash(
        self,
        *,
        execution_id: Optional[str] = None,
        pod_id: Optional[str] = None,
        connection_id: Optional[int] = None,
        returncode: Optional[int] = None,
        cause: Optional[str] = None,
        stderr_tail: Optional[str] = None,
        wall_seconds: Optional[float] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> Optional[int]:
        """Persist one subprocess crash event so operators can see the
        pattern via dashboards / ops UI instead of relying on log
        scraping.  Returns the new row id or None on best-effort
        failure (never raises — telemetry must not block the recovery
        path).
        """
        try:
            from core.db.models import DuckDBSubprocessCrash as _DDC
            with self.get_session() as session:
                row = _DDC(
                    execution_id=execution_id,
                    pod_id=pod_id,
                    connection_id=connection_id,
                    returncode=returncode,
                    cause=(cause or "")[:500],
                    stderr_tail=(stderr_tail or "")[:8000],
                    wall_seconds=wall_seconds,
                    extra=extra or {},
                )
                session.add(row)
                session.flush()
                return row.id
        except Exception as exc:
            import logging as _l
            _l.getLogger(__name__).debug(
                "BF-541 record_duckdb_subprocess_crash failed: %s", exc)
            return None

    def list_recent_duckdb_crashes(self, *, hours: int = 24,
                                     limit: int = 200) -> list:
        """Return crashes in the last ``hours`` ordered newest-first
        for the admin dashboard."""
        from core.db.models import DuckDBSubprocessCrash as _DDC
        cutoff = datetime.now(timezone.utc) - timedelta(hours=int(hours))
        with self.get_session(read_only=True) as session:
            q = (session.query(_DDC)
                 .filter(_DDC.occurred_at >= cutoff)
                 .order_by(_DDC.occurred_at.desc())
                 .limit(int(limit)))
            return [r.to_dict() for r in q.all()]

    def list_iceberg_metadata_keys_for_refresh(self, *, limit: int = 0,
                                                  exclude_sentinel: bool = True
                                                  ) -> list:
        """Return all ``IcebergMetadataKeyCache`` rows so the BF-512
        background refresh job can re-resolve them against S3.

        Args:
            limit: cap on rows returned (0 = unlimited).  Useful when the
                cache grows large and admins want bounded per-tick work.
            exclude_sentinel: when True (default), filters out the
                ``connection_id=0`` sentinel rows (inserted by admin
                tools / untagged paths — we cannot build an S3 client
                for them so a refresh would be a no-op).

        Returns the row list ordered by ``updated_at`` ASCENDING so the
        OLDEST rows refresh FIRST — that's where stale-cache risk is
        highest.  Each entry is a dict with ``connection_id``, ``cache_id``,
        ``metadata_key``, ``updated_at`` (see ``IcebergMetadataKeyCache.to_dict``).
        """
        from core.db.models import IcebergMetadataKeyCache as _IMKC
        with self.get_session(read_only=True) as session:
            q = session.query(_IMKC)
            if exclude_sentinel:
                q = q.filter(_IMKC.connection_id != 0)
            q = q.order_by(_IMKC.updated_at.asc())
            if limit and limit > 0:
                q = q.limit(int(limit))
            return [r.to_dict() for r in q.all()]

    def evict_iceberg_metadata_key(self, connection_id: Optional[int],
                                    cache_id: str) -> int:
        """Drop the persisted metadata-key row(s) for this cache_id.

        BF-511 (2026-05-28): when ``_latest_metadata_key`` detects via
        version-hint.text that the live Iceberg pointer has advanced past
        the cached row, the row must be evicted so a subsequent process
        / restart doesn't re-serve the same stale key.

        ``connection_id=None`` evicts ALL rows under this cache_id (across
        every connection AND the sentinel ``0`` row) because the cache key
        is content-addressed — the answer is identical regardless of which
        connection asked, so a single stale row poisons every reader.

        Returns the number of rows actually deleted.  Failures escalate
        to the caller via exception (eviction failure on a known-stale
        row is correctness-affecting; the caller decides whether to
        retry or fall through).
        """
        from core.db.models import IcebergMetadataKeyCache as _IMKC
        with self.get_session() as session:
            q = session.query(_IMKC).filter(_IMKC.cache_id == cache_id)
            if connection_id is not None:
                q = q.filter(_IMKC.connection_id == int(connection_id))
            deleted = q.delete(synchronize_session=False)
            session.flush()
            return int(deleted or 0)

    def set_iceberg_metadata_key(self, connection_id: Optional[int], cache_id: str,
                                 metadata_key: str) -> Dict[str, Any]:
        """Upsert the latest known metadata key for this cache_id.  Concurrent-writer-safe.

        BF-ICEBERG-CACHE-ANY-CONN: ``connection_id=None`` writes use the
        sentinel value ``0`` so the row coexists with per-connection rows
        without violating the unique (connection_id, cache_id) constraint.
        Subsequent reads with connection_id=None see the freshest entry.
        """
        eff_conn_id = 0 if connection_id is None else int(connection_id)
        from core.db.models import IcebergMetadataKeyCache as _IMKC
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = _IMKC(
                    connection_id=eff_conn_id, cache_id=cache_id,
                    metadata_key=metadata_key, updated_at=now,
                )
                session.add(e)
                session.flush()
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(_IMKC).filter(
                    _IMKC.connection_id == eff_conn_id,
                    _IMKC.cache_id == cache_id,
                ).first()
                if existing:
                    existing.metadata_key = metadata_key
                    existing.updated_at = now
                    session.flush()
                    return existing.to_dict()
                # Race: another writer just inserted between rollback and select.
                # Re-attempt insert; if THAT fails too, surface the error.
                e2 = _IMKC(
                    connection_id=eff_conn_id, cache_id=cache_id,
                    metadata_key=metadata_key, updated_at=now,
                )
                session.add(e2)
                session.flush()
                return e2.to_dict()

    # ── Iceberg metadata-content persistent cache ─────────────────────────────
    # Backs the in-memory `_metadata_content_cache` (60s TTL) in
    # core.iceberg_reader with a DB-persisted layer keyed by FULL immutable
    # S3 path (metadata.json files have UUIDs in their names; manifest-list
    # Avro files have snapshot-ids — never overwritten).  Caching forever
    # is safe; LRU eviction by row count keeps the table bounded.

    def get_iceberg_metadata_content(self, connection_id: Optional[int], object_key: str
                                      ) -> Optional[Dict[str, Any]]:
        """Return ``{content, content_kind, ...}`` for this object, or None.

        Bumps ``last_read_at`` on hit so LRU eviction keeps hot entries.

        BF-ICEBERG-CACHE-ANY-CONN: ``connection_id=None`` falls back to
        an ``object_key``-only lookup.  The Iceberg metadata bodies are
        content-addressed (UUID in filename / snapshot-id in path), so
        the answer is identical no matter which connection asks — pick
        the freshest row.  Without this fallback, any code path that
        builds an S3 client without tagging it (admin tools, sync
        fallback, restart-recovery first query) silently skips the DB
        cache and pays a full S3 round-trip.

        Deep-dive fix: read happens in a READ-ONLY session (no commit lock
        contention).  The last_read_at touch is performed in a separate
        cheap UPDATE so concurrent cache hits don't serialise on SQLite's
        write lock.  Errors on the touch are swallowed — losing one LRU
        update is harmless, but blocking the read is not.
        """
        from core.db.models import IcebergMetadataContentCache as _IMCC
        # Phase 1 — read-only fetch (no write lock).
        with self.get_session(read_only=True) as session:
            q = session.query(_IMCC).filter(_IMCC.object_key == object_key)
            if connection_id is not None:
                q = q.filter(_IMCC.connection_id == connection_id)
            else:
                # Cross-connection lookup — content is identical for the
                # same object_key, take the freshest entry.
                q = q.order_by(_IMCC.last_read_at.desc())
            e = q.first()
            if not e:
                return None
            result = e.to_dict()
            row_id = e.id

        # Phase 2 — best-effort LRU touch in a separate transaction.  Brief
        # write lock; if it fails the cache entry just doesn't get its
        # last_read_at refreshed — eviction may drop it earlier than ideal
        # but correctness is preserved.
        try:
            with self.get_session() as session:
                session.query(_IMCC).filter(_IMCC.id == row_id).update({
                    _IMCC.last_read_at: datetime.now(timezone.utc),
                })
        except Exception as _touch_err:
            logger.debug("[iceberg-cache] LRU touch failed (non-fatal): %s", _touch_err)
        return result

    def set_iceberg_metadata_content(self, connection_id: Optional[int], object_key: str,
                                      content: Any, content_kind: str = "json",
                                      content_size: int = 0,
                                      max_entries: Optional[int] = None
                                      ) -> Dict[str, Any]:
        """Upsert a metadata-content cache row.  Concurrent-writer-safe.

        BF-ICEBERG-CACHE-ANY-CONN: ``connection_id=None`` writes use the
        sentinel value ``0`` so the row coexists with per-connection rows
        without violating the unique constraint and stays discoverable
        by subsequent connection_id=None reads.

        When ``max_entries`` is provided AND the row count for this
        connection_id exceeds it, prune the oldest ``last_read_at`` entries
        down to the cap minus 10% headroom.  Pass None to skip pruning
        (caller controls cleanup separately).
        """
        eff_conn_id = 0 if connection_id is None else int(connection_id)
        from core.db.models import IcebergMetadataContentCache as _IMCC
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            try:
                e = _IMCC(
                    connection_id=eff_conn_id, object_key=object_key,
                    content_kind=content_kind, content=content,
                    content_size=content_size, cached_at=now, last_read_at=now,
                )
                session.add(e)
                session.flush()
                self._maybe_prune_metadata_content_cache(session, eff_conn_id, max_entries)
                return e.to_dict()
            except Exception:
                session.rollback()
                existing = session.query(_IMCC).filter(
                    _IMCC.connection_id == eff_conn_id,
                    _IMCC.object_key == object_key,
                ).first()
                if existing:
                    existing.content_kind = content_kind
                    existing.content = content
                    existing.content_size = content_size
                    existing.last_read_at = now
                    session.flush()
                    return existing.to_dict()
                e2 = _IMCC(
                    connection_id=eff_conn_id, object_key=object_key,
                    content_kind=content_kind, content=content,
                    content_size=content_size, cached_at=now, last_read_at=now,
                )
                session.add(e2)
                session.flush()
                self._maybe_prune_metadata_content_cache(session, eff_conn_id, max_entries)
                return e2.to_dict()

    def _maybe_prune_metadata_content_cache(self, session, connection_id: int,
                                             max_entries: Optional[int]) -> int:
        """Internal: LRU-prune the content cache for one connection_id when
        the row count exceeds ``max_entries``.  Returns count deleted (0 if
        no pruning ran).  Called inside an open session by ``set_*``."""
        if not max_entries or max_entries <= 0:
            return 0
        from core.db.models import IcebergMetadataContentCache as _IMCC
        total = session.query(_IMCC).filter(
            _IMCC.connection_id == connection_id,
        ).count()
        if total <= max_entries:
            return 0
        target = int(max_entries * 0.9)
        n_evict = total - target
        oldest = (session.query(_IMCC)
                  .filter(_IMCC.connection_id == connection_id)
                  .order_by(_IMCC.last_read_at.asc())
                  .limit(n_evict)
                  .all())
        for row in oldest:
            session.delete(row)
        return len(oldest)

    # ── Execution history cleanup ──────────────────────────────────────────────

    def cleanup_old_executions(self, retention_days: int = 30):
        """Delete QueryExecution records older than retention_days.

        Only removes records whose status is terminal (completed / failed /
        cancelled) and whose started_at is older than the retention window.
        Pending / processing rows are never touched (they may still be running).

        Returns (count, [output_file_paths]) so the caller can delete the files.
        """
        import datetime as _dt
        cutoff = datetime.now(timezone.utc) - _dt.timedelta(days=retention_days)
        with self.get_session() as session:
            terminal = ("completed", "failed", "cancelled")
            expired_rows = (
                session.query(QueryExecution)
                .filter(
                    QueryExecution.status.in_(terminal),
                    QueryExecution.started_at < cutoff,
                )
                .all()
            )
            # Collect file paths BEFORE deleting rows (so we can unlink them)
            file_paths = [r.output_file for r in expired_rows if r.output_file]
            count = len(expired_rows)
            for row in expired_rows:
                session.delete(row)
            return count, file_paths

    def get_downloads_size_bytes(self) -> int:
        """Return total file_size_bytes of available download records."""
        with self.get_session(read_only=True) as session:
            rows = (
                session.query(DownloadFile)
                .filter(DownloadFile.status == "available")
                .all()
            )
            return sum(r.file_size_bytes or 0 for r in rows)

    # ── Audit log ─────────────────────────────────────────────────────────────

    def audit(self, username: str, action: str,
              resource_type: str = None, resource_id: str = None,
              ip_address: str = None, user_agent: str = None,
              details: dict = None) -> None:
        """Append an immutable audit entry (fire-and-forget, never raises)."""
        try:
            with self.get_session() as session:
                session.add(AuditLog(
                    username=username or "unknown",
                    action=action,
                    resource_type=resource_type,
                    resource_id=str(resource_id) if resource_id is not None else None,
                    ip_address=ip_address,
                    user_agent=user_agent,
                    details=details,
                ))
        except Exception as e:
            logger.warning("Failed to log audit entry: %s", e)

    def list_audit_log(self, username: str = None, action: str = None,
                       limit: int = 200, offset: int = 0) -> List[Dict[str, Any]]:
        """Return audit entries newest-first, with optional filters."""
        with self.get_session(read_only=True) as session:
            q = session.query(AuditLog).order_by(AuditLog.timestamp.desc())
            if username:
                q = q.filter(AuditLog.username == username)
            if action:
                q = q.filter(AuditLog.action == action)
            return [r.to_dict() for r in q.offset(offset).limit(limit).all()]

    def list_known_usernames(self, *, since_days: Optional[int] = None,
                              limit: int = 1000) -> List[Dict[str, Any]]:
        """Phase 131 deep-dive #6 — distinct users who have ever
        interacted with the system, plus their last-seen timestamp.

        Source: ``audit_log.username`` (any action, including login) +
        ``user_group_members.username`` (mapped but maybe-not-yet-logged).
        Users are auto-created on first login by the auth layer; this
        helper lets the admin UI populate username autocompletes from
        what HAS happened, not from a separately-maintained registry.

        Returned dict shape: ``{"username": str, "last_seen": iso-str|None,
        "in_groups": int}``.  ``last_seen`` is None for users in groups
        who haven't yet logged in.
        """
        from sqlalchemy import func as _sa_func
        with self.get_session(read_only=True) as session:
            q = session.query(
                AuditLog.username.label("username"),
                _sa_func.max(AuditLog.timestamp).label("last_seen"),
            ).group_by(AuditLog.username)
            if since_days is not None and since_days > 0:
                cutoff = datetime.now(timezone.utc) - timedelta(days=int(since_days))
                q = q.filter(AuditLog.timestamp >= cutoff)
            rows = q.order_by(_sa_func.max(AuditLog.timestamp).desc()).limit(limit).all()
            users: Dict[str, Dict[str, Any]] = {}
            for r in rows:
                if not r.username:
                    continue
                users[r.username] = {
                    "username":  r.username,
                    "last_seen": r.last_seen.isoformat() if r.last_seen else None,
                    "in_groups": 0,
                }
            # Augment with users in groups who may not have logged in yet
            # (admin pre-mapped them so they're permission-ready on first login).
            try:
                group_users = session.query(
                    UserGroupMember.username.label("username"),
                    _sa_func.count(UserGroupMember.group_id).label("in_groups"),
                ).group_by(UserGroupMember.username).all()
                for r in group_users:
                    if not r.username:
                        continue
                    rec = users.setdefault(r.username, {
                        "username": r.username, "last_seen": None, "in_groups": 0,
                    })
                    rec["in_groups"] = int(r.in_groups or 0)
            except Exception:
                pass
        # Return newest-first by last_seen; never-logged-in users sort last.
        return sorted(
            users.values(),
            key=lambda u: (u["last_seen"] or "", u["username"]),
            reverse=True,
        )

    def mark_expired_downloads(self) -> int:
        """Mark download records as 'expired' where expires_at < now.

        Returns number of records marked expired.
        """
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(
                    DownloadFile.status == "available",
                    DownloadFile.expires_at != None,  # noqa: E711  (SQLAlchemy: `is None` is always False on a Column)
                    DownloadFile.expires_at < now,
                )
                .all()
            )
            for row in rows:
                row.status = "expired"
            return len(rows)

    def expire_oldest_downloads(self, keep_count: int) -> int:
        """Mark oldest download records as expired until only keep_count remain.

        Returns number of records expired.
        """
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(DownloadFile.status == "available")
                .order_by(DownloadFile.created_at.asc())
                .all()
            )
            to_expire = max(0, len(rows) - keep_count)
            for row in rows[:to_expire]:
                row.status = "expired"
            return to_expire

    def expire_downloads_over_byte_quota(self, quota_bytes: int) -> tuple:
        """Expire the OLDEST downloads until the total size fits ``quota_bytes``.

        2026-08-22 — replaces a count-based eviction that could not work.  The
        caller turned a BYTE quota into a record count using the MEAN file
        size, then expired by age.  With any skew that both destroys data
        needlessly and leaves the directory over quota:

            A: 1 GiB (Monday), B: 19 GiB (Tuesday), quota 10 GiB
            mean = 10 GiB -> keep = 1 -> expire A (the 1 GiB one)
            -> A's file is UNLINKED, and 19 GiB remains. Still over quota,
               and the user lost the download that was not the problem.

        Sizes are what the quota is denominated in, so sizes are what the
        eviction reads.  Oldest-first is kept: it is the policy users expect
        and the only one the created_at ordering can defend.

        Returns ``(records_expired, bytes_freed)``.
        """
        if quota_bytes is None or int(quota_bytes) <= 0:
            return (0, 0)                       # 0 = unlimited, product-wide
        quota_bytes = int(quota_bytes)
        with self.get_session() as session:
            rows = (
                session.query(DownloadFile)
                .filter(DownloadFile.status == "available")
                .order_by(DownloadFile.created_at.asc())
                .all()
            )
            if not rows:
                return (0, 0)
            total = sum(int(r.file_size_bytes or 0) for r in rows)
            if total <= quota_bytes:
                return (0, 0)

            # IS THE QUOTA REACHABLE AT ALL?  The newest record is never
            # expired — an empty Download Centre is not a quota outcome — so
            # the smallest total we can reach is its size.  When even that
            # exceeds the quota, expiring anything frees space without
            # reaching the goal: exactly the original failure (1 GiB deleted,
            # 19 GiB left, still over a 10 GiB quota) arrived at by a
            # different route.  Deleting a user's file for no benefit is worse
            # than reporting that the quota cannot be met.
            newest = int(rows[-1].file_size_bytes or 0)
            if newest > quota_bytes:
                return (0, 0)

            freed = 0
            expired = 0
            # Walk oldest -> newest, stopping the moment we fit.
            #
            # `rows[:-1]` is DEFENCE IN DEPTH, not live logic: given the
            # reachability check above, expiring everything older already
            # leaves exactly `newest` bytes, which is <= quota, so the break
            # fires before the last row either way.  A mutation sweep
            # confirmed it is currently unobservable.  It stays because it
            # states the invariant locally — if the check above is ever
            # relaxed, this is what still keeps the Download Centre from
            # being emptied.
            for row in rows[:-1]:
                if total - freed <= quota_bytes:
                    break
                row.status = "expired"
                freed += int(row.file_size_bytes or 0)
                expired += 1
            return (expired, freed)

    # ── Query Version operations ───────────────────────────────────────────────

    def create_query_version(self, query_id: int, name: str = None, description: str = None,
                              query_config: dict = None, changed_by: str = None,
                              change_note: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            # Get next version number
            last = (session.query(QueryVersion)
                    .filter(QueryVersion.query_id == query_id)
                    .order_by(QueryVersion.version_number.desc())
                    .first())
            next_ver = (last.version_number + 1) if last else 1
            v = QueryVersion(
                query_id=query_id, version_number=next_ver,
                name=name, description=description, query_config=query_config,
                changed_by=changed_by, change_note=change_note,
            )
            session.add(v)
            session.flush()
            session.refresh(v)
            return v.to_dict()

    def list_query_versions(self, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(QueryVersion)
                    .filter(QueryVersion.query_id == query_id)
                    .order_by(QueryVersion.version_number.desc())
                    .all())
            return [v.to_dict() for v in rows]

    def get_query_version(self, version_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            v = session.query(QueryVersion).filter(QueryVersion.id == version_id).first()
            return v.to_dict() if v else None

    # ── Query Share operations ─────────────────────────────────────────────────

    def create_share(self, query_id: int, created_by: str = None,
                     expires_at: Optional[datetime] = None) -> Dict[str, Any]:
        import uuid as _uuid
        with self.get_session() as session:
            s = QueryShare(
                token=_uuid.uuid4().hex,
                query_id=query_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            return s.to_dict() if s else None

    def increment_share_access(self, token: str) -> None:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            if s:
                s.access_count = (s.access_count or 0) + 1

    def list_shares(self, query_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(QueryShare)
                    .filter(QueryShare.query_id == query_id, QueryShare.is_active)
                    .order_by(QueryShare.created_at.desc())
                    .all())
            return [s.to_dict() for s in rows]

    def deactivate_share(self, token: str) -> bool:
        with self.get_session() as session:
            s = session.query(QueryShare).filter(QueryShare.token == token).first()
            if not s:
                return False
            s.is_active = False
            return True

    # ── Dashboard share operations ─────────────────────────────────────────────

    def create_dashboard_share(self, dashboard_id: int, created_by: str = None,
                               expires_at=None) -> Dict[str, Any]:
        import uuid as _uuid
        with self.get_session() as session:
            s = DashboardShare(
                token=_uuid.uuid4().hex,
                dashboard_id=dashboard_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(s)
            session.flush()
            session.refresh(s)
            return s.to_dict()

    def get_dashboard_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            s = session.query(DashboardShare).filter(DashboardShare.token == token).first()
            return s.to_dict() if s else None

    def increment_dashboard_share_access(self, token: str) -> None:
        with self.get_session() as session:
            s = session.query(DashboardShare).filter(DashboardShare.token == token).first()
            if s:
                s.access_count = (s.access_count or 0) + 1

    # ── Dashboard operations ───────────────────────────────────────────────────

    def create_dashboard(self, name: str, description: str = None,
                         created_by: str = None,
                         workspace_id: Optional[int] = None,
                         filters: Optional[list] = None) -> Dict[str, Any]:
        with self.get_session() as session:
            d = Dashboard(name=name, description=description, created_by=created_by,
                          workspace_id=workspace_id, filters=filters or None)
            session.add(d)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def get_dashboard(self, dashboard_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id, Dashboard.is_active).first()
            return d.to_dict() if d else None

    def list_dashboards(self, created_by: str = None, is_admin: bool = True,
                        workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(Dashboard).filter(Dashboard.is_active)
            if not is_admin and created_by:
                q = q.filter(Dashboard.created_by == created_by)
            if workspace_id is not None:
                q = q.filter(
                    (Dashboard.workspace_id == workspace_id) | (Dashboard.workspace_id == None)  # noqa: E711  (SQLAlchemy: `is None` is always False on a Column)
                )
            rows = q.order_by(Dashboard.updated_at.desc()).all()
            return [d.to_dict() for d in rows]

    def update_dashboard(self, dashboard_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if not d:
                return None
            for k, v in kwargs.items():
                if hasattr(d, k):
                    setattr(d, k, v)
            d.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def delete_dashboard(self, dashboard_id: int) -> bool:
        with self.get_session() as session:
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if not d:
                return False
            d.is_active = False
            return True

    # ── Dashboard Widget operations ────────────────────────────────────────────

    def create_widget(self, dashboard_id: int, widget_type: str, source_id: int,
                      title: str = None, layout: dict = None, chart_type: str = "grid",
                      chart_config: dict = None, param_values: dict = None) -> Dict[str, Any]:
        with self.get_session() as session:
            w = DashboardWidget(
                dashboard_id=dashboard_id, widget_type=widget_type, source_id=source_id,
                title=title, layout=layout or {"x": 0, "y": 0, "w": 6, "h": 4},
                chart_type=chart_type, chart_config=chart_config, param_values=param_values,
            )
            session.add(w)
            session.flush()
            session.refresh(w)
            # Touch parent dashboard updated_at
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if d:
                d.updated_at = datetime.now(timezone.utc)
            return w.to_dict()

    def list_widgets(self, dashboard_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(DashboardWidget)
                    .filter(DashboardWidget.dashboard_id == dashboard_id)
                    .order_by(DashboardWidget.id)
                    .all())
            return [w.to_dict() for w in rows]

    def get_widget(self, widget_id: int) -> Optional[Dict[str, Any]]:
        """One widget by id, with its ``dashboard_id`` -- the caller binds it
        to the dashboard it is acting for (2026-10-26, the shared-dashboard
        tile routes)."""
        with self.get_session(read_only=True) as session:
            w = session.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
            return w.to_dict() if w else None

    def update_widget(self, widget_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            w = session.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
            if not w:
                return None
            for k, v in kwargs.items():
                if hasattr(w, k):
                    setattr(w, k, v)
            w.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(w)
            return w.to_dict()

    def delete_widget(self, widget_id: int) -> bool:
        with self.get_session() as session:
            w = session.query(DashboardWidget).filter(DashboardWidget.id == widget_id).first()
            if not w:
                return False
            session.delete(w)
            return True

    def update_widget_layouts(self, dashboard_id: int, layouts: list) -> None:
        """Bulk update widget positions from react-grid-layout onChange."""
        with self.get_session() as session:
            layout_map = {str(item["i"]): item for item in layouts}
            widgets = (session.query(DashboardWidget)
                       .filter(DashboardWidget.dashboard_id == dashboard_id)
                       .all())
            for w in widgets:
                if str(w.id) in layout_map:
                    item = layout_map[str(w.id)]
                    w.layout = {"x": item.get("x", 0), "y": item.get("y", 0),
                                "w": item.get("w", 6), "h": item.get("h", 4)}
            d = session.query(Dashboard).filter(Dashboard.id == dashboard_id).first()
            if d:
                d.updated_at = datetime.now(timezone.utc)

    # ── Materialized Views ─────────────────────────────────────────────────

    def create_materialized_view(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            mv = MaterializedView(**kwargs)
            session.add(mv)
            session.flush()
            session.refresh(mv)
            return mv.to_dict()

    def get_materialized_view(self, mv_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            mv = session.query(MaterializedView).filter(MaterializedView.id == mv_id).first()
            return mv.to_dict() if mv else None

    def get_materialized_view_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            mv = session.query(MaterializedView).filter(MaterializedView.name == name).first()
            return mv.to_dict() if mv else None

    def list_materialized_views(self, connection_id: int = None,
                                 active_only: bool = True,
                                 workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(MaterializedView)
            if active_only:
                q = q.filter(MaterializedView.is_active)
            if connection_id is not None:
                q = q.filter(MaterializedView.connection_id == connection_id)
            if workspace_id is not None:
                q = q.filter(
                    (MaterializedView.workspace_id == workspace_id) | (MaterializedView.workspace_id == None)  # noqa: E711  (SQLAlchemy: `is None` is always False on a Column)
                )
            rows = q.order_by(MaterializedView.name).all()
            return [mv.to_dict() for mv in rows]

    def update_materialized_view(self, mv_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            mv = session.query(MaterializedView).filter(MaterializedView.id == mv_id).first()
            if not mv:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(mv, key):
                    setattr(mv, key, value)
            mv.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(mv)
            return mv.to_dict()

    def delete_materialized_view(self, mv_id: int) -> bool:
        with self.get_session() as session:
            mv = session.query(MaterializedView).filter(MaterializedView.id == mv_id).first()
            if not mv:
                return False
            session.delete(mv)
            return True

    # ── Local Tables ──────────────────────────────────────────────────────────

    def create_local_table(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            lt = LocalTable(**kwargs)
            session.add(lt)
            session.flush()
            session.refresh(lt)
            return lt.to_dict()

    def get_local_table(self, lt_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            return lt.to_dict() if lt else None

    def get_local_table_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            lt = session.query(LocalTable).filter(LocalTable.name == name).first()
            return lt.to_dict() if lt else None

    def list_local_tables(self, visibility: str = None,
                          created_by: str = None,
                          active_only: bool = True,
                          workspace_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(LocalTable)
            if active_only:
                q = q.filter(LocalTable.is_active)
            if visibility:
                q = q.filter(LocalTable.visibility == visibility)
            if created_by:
                q = q.filter(LocalTable.created_by == created_by)
            if workspace_id is not None:
                q = q.filter(
                    (LocalTable.workspace_id == workspace_id) | (LocalTable.workspace_id == None)  # noqa: E711  (SQLAlchemy: `is None` is always False on a Column)
                )
            rows = q.order_by(LocalTable.name).all()
            return [lt.to_dict() for lt in rows]

    def update_local_table(self, lt_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            if not lt:
                return None
            kwargs.pop("id", None)
            for key, value in kwargs.items():
                if hasattr(lt, key):
                    setattr(lt, key, value)
            lt.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(lt)
            return lt.to_dict()

    def delete_local_table(self, lt_id: int) -> bool:
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            if not lt:
                return False
            session.delete(lt)
            return True

    def touch_local_table(self, lt_id: int) -> None:
        """Update last_accessed_at to now."""
        with self.get_session() as session:
            lt = session.query(LocalTable).filter(LocalTable.id == lt_id).first()
            if lt:
                lt.last_accessed_at = datetime.now(timezone.utc)

    def list_expired_local_tables(self) -> List[Dict[str, Any]]:
        """Return public local tables that have not been accessed within their auto_discard_days."""
        with self.get_session(read_only=True) as session:
            now = datetime.now(timezone.utc)
            rows = (session.query(LocalTable)
                    .filter(LocalTable.is_active,
                            LocalTable.visibility == "public",
                            LocalTable.auto_discard_days > 0,
                            LocalTable.last_accessed_at != None)  # noqa: E711  (SQLAlchemy: `is None` is always False on a Column)
                    .all())
            expired = []
            for lt in rows:
                cutoff = now - timedelta(days=lt.auto_discard_days)
                if lt.last_accessed_at and lt.last_accessed_at < cutoff:
                    expired.append(lt.to_dict())
            return expired

    # ── TaskQueue operations ──────────────────────────────────────────────

    def enqueue_task(self, task_id: str, task_type: str, payload: dict,
                     execution_id: str = None, created_by: str = None,
                     priority: int = 5, timeout_seconds: int = 1800,
                     retry_count: int = 0, max_retries: int = 3,
                     delay_seconds: int = 0) -> Dict[str, Any]:
        """Enqueue a new task. Called by FastAPI when executor.mode='external'."""
        with self.get_session() as session:
            next_retry_at = None
            if delay_seconds > 0:
                next_retry_at = datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)
            task = TaskQueue(
                task_id=task_id, task_type=task_type,
                payload=payload, execution_id=execution_id,
                created_by=created_by, priority=priority,
                timeout_seconds=timeout_seconds,
                retry_count=retry_count, max_retries=max_retries,
                next_retry_at=next_retry_at,
            )
            session.add(task)
            session.flush()
            session.refresh(task)
            return task.to_dict()

    def claim_next_task(self, worker_id: str, task_types: list = None) -> Optional[Dict[str, Any]]:
        """Atomic claim: grab the highest-priority pending task.

        Uses raw SQL UPDATE ... WHERE for true atomicity — only one worker
        can claim a given task even under concurrent access.
        """
        with self.get_session() as session:
            from sqlalchemy import text as _text, or_ as _or
            now = datetime.now(timezone.utc)
            # Step 1: Find best candidate (skip tasks not yet eligible due to backoff delay)
            q = (session.query(TaskQueue)
                 .filter(TaskQueue.status == "pending")
                 .filter(_or(TaskQueue.next_retry_at.is_(None),
                             TaskQueue.next_retry_at <= now))
                 .order_by(TaskQueue.priority, TaskQueue.created_at))
            if task_types:
                q = q.filter(TaskQueue.task_type.in_(task_types))
            task = q.first()
            if not task:
                return None
            # Step 2: Atomic claim — UPDATE only if still pending (race-safe)
            result = session.execute(
                _text("""UPDATE task_queue
                         SET status = 'claimed', claimed_by = :worker, claimed_at = :now
                         WHERE id = :tid AND status = 'pending'"""),
                {"worker": worker_id, "now": now, "tid": task.id}
            )
            if result.rowcount == 0:
                return None  # Another worker got it first
            session.expire(task)
            session.refresh(task)
            return task.to_dict()

    def update_task_progress(self, task_id: str, progress_pct: int,
                             progress_detail: str = None) -> None:
        """Called by executor thread to report progress."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            if task:
                task.progress_pct = progress_pct
                if progress_detail is not None:
                    task.progress_detail = progress_detail
                if task.status == "claimed":
                    task.status = "processing"
                    task.started_at = datetime.now(timezone.utc)

    def complete_task(self, task_id: str, result: dict = None) -> None:
        """Mark task as completed."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            if task:
                task.status = "completed"
                task.progress_pct = 100
                task.result = result
                task.completed_at = datetime.now(timezone.utc)

    def fail_task(self, task_id: str, error_message: str) -> None:
        """Mark task as failed."""
        with self.get_session() as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            if task:
                task.status = "failed"
                task.error_message = error_message
                task.completed_at = datetime.now(timezone.utc)

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get a single task by task_id."""
        with self.get_session(read_only=True) as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            return task.to_dict() if task else None

    def list_tasks(self, status: str = None, limit: int = 50) -> List[Dict[str, Any]]:
        """List tasks, optionally filtered by status."""
        with self.get_session(read_only=True) as session:
            q = session.query(TaskQueue).order_by(TaskQueue.created_at.desc())
            if status:
                q = q.filter(TaskQueue.status == status)
            return [t.to_dict() for t in q.limit(limit).all()]

    def poll_active_tasks(self) -> List[Dict[str, Any]]:
        """Get tasks that are processing or recently completed/failed (for WS broadcast)."""
        with self.get_session() as session:
            return [t.to_dict() for t in
                    session.query(TaskQueue)
                    .filter(TaskQueue.status.in_(["processing", "completed", "failed"]))
                    .order_by(TaskQueue.created_at.desc())
                    .limit(100)
                    .all()]

    def reclaim_stale_tasks(self, stale_seconds: int = 600) -> int:
        """Re-set claimed/processing tasks that exceeded timeout back to pending.

        Called periodically by the executor for graceful degradation when
        a worker dies mid-task.
        """
        with self.get_session() as session:
            cutoff = datetime.now(timezone.utc) - timedelta(seconds=stale_seconds)
            stale = (session.query(TaskQueue)
                     .filter(TaskQueue.status.in_(["claimed", "processing"]),
                             TaskQueue.claimed_at < cutoff)
                     .all())
            count = 0
            for t in stale:
                if t.retry_count < t.max_retries:
                    t.status = "pending"
                    t.claimed_by = None
                    t.claimed_at = None
                    t.retry_count += 1
                else:
                    t.status = "failed"
                    t.error_message = "Executor timed out — max retries exceeded"
                    t.completed_at = datetime.now(timezone.utc)
                count += 1
            return count

    def cleanup_old_tasks(self, max_age_hours: int = 24) -> int:
        """Delete completed/failed tasks older than max_age_hours."""
        with self.get_session() as session:
            cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
            count = (session.query(TaskQueue)
                     .filter(TaskQueue.status.in_(["completed", "failed"]),
                             TaskQueue.completed_at < cutoff)
                     .delete(synchronize_session=False))
            return count

    # ── Dead-Letter Queue operations (Phase 22C) ──────────────────────────────

    def push_dead_letter(self, task: Dict[str, Any], error: str) -> None:
        """Move a permanently failed task to the DLQ."""
        with self.get_session() as session:
            dlq = DeadLetterQueue(
                task_id=task.get("task_id", ""),
                task_type=task.get("task_type", "unknown"),
                payload=task.get("payload", {}),
                execution_id=task.get("execution_id"),
                created_by=task.get("created_by") or (task.get("payload") or {}).get("executed_by"),
                original_error=error,
                retry_count=task.get("retry_count", 0),
                first_failed_at=datetime.now(timezone.utc),
            )
            session.merge(dlq)

    def list_dead_letter(self, resolved: Optional[bool] = False,
                         limit: int = 100) -> List[Dict[str, Any]]:
        """List DLQ entries. resolved=None returns all."""
        with self.get_session(read_only=True) as session:
            q = session.query(DeadLetterQueue)
            if resolved is not None:
                q = q.filter(DeadLetterQueue.resolved == int(resolved))
            q = q.order_by(DeadLetterQueue.dead_at.desc()).limit(limit)
            return [r.to_dict() for r in q.all()]

    def resolve_dead_letter(self, task_id: str, resolved_by: str) -> bool:
        """Mark a DLQ entry as resolved."""
        with self.get_session() as session:
            dlq = session.query(DeadLetterQueue).filter(
                DeadLetterQueue.task_id == task_id
            ).first()
            if not dlq:
                return False
            dlq.resolved = 1
            dlq.resolved_at = datetime.now(timezone.utc)
            dlq.resolved_by = resolved_by
            return True

    def request_task_cancel(self, execution_id: str) -> bool:
        """Request cancellation of a task by execution_id.

        Sets cancel_requested=1 so the executor worker picks it up.
        Returns True if a running task was found and flagged.
        """
        with self.get_session() as session:
            task = (session.query(TaskQueue)
                    .filter(TaskQueue.execution_id == execution_id,
                            TaskQueue.status.in_(["pending", "claimed", "processing"]))
                    .first())
            if not task:
                return False
            task.cancel_requested = 1
            if task.status == "pending":
                task.status = "cancelled"
                task.error_message = "Cancelled by user"
                task.completed_at = datetime.now(timezone.utc)
            return True

    def is_task_cancelled(self, task_id: str) -> bool:
        """Quick check — has cancellation been requested for this task?

        Called by executor worker between chunks for cooperative cancellation.
        """
        with self.get_session(read_only=True) as session:
            task = session.query(TaskQueue).filter(TaskQueue.task_id == task_id).first()
            return bool(task and task.cancel_requested)

    # ── TableFavorite operations ──────────────────────────────────────────

    def toggle_table_favorite(self, username: str, table_path: str,
                              table_name: str, connection_id: int = None,
                              table_type: str = None) -> bool:
        """Toggle favorite. Returns True if added, False if removed."""
        with self.get_session() as session:
            existing = (session.query(TableFavorite)
                        .filter(TableFavorite.username == username,
                                TableFavorite.table_path == table_path,
                                TableFavorite.connection_id == connection_id)
                        .first())
            if existing:
                session.delete(existing)
                return False
            fav = TableFavorite(
                username=username, table_path=table_path,
                table_name=table_name, connection_id=connection_id,
                table_type=table_type,
            )
            session.add(fav)
            return True

    def list_table_favorites(self, username: str,
                             connection_id: int = None) -> List[Dict[str, Any]]:
        """List user's favorited tables."""
        with self.get_session(read_only=True) as session:
            q = session.query(TableFavorite).filter(TableFavorite.username == username)
            if connection_id is not None:
                q = q.filter(TableFavorite.connection_id == connection_id)
            return [f.to_dict() for f in q.order_by(TableFavorite.created_at.desc()).all()]

    # ── TableDescription operations (Phase 92) ───────────────────────────────

    def get_table_description(self, connection_id: int, table_name: str) -> Optional[Dict[str, Any]]:
        """Return description row for a table, or None if not set."""
        with self.get_session(read_only=True) as session:
            row = (session.query(TableDescription)
                   .filter(TableDescription.connection_id == connection_id,
                           TableDescription.table_name == table_name)
                   .first())
            return row.to_dict() if row else None

    def upsert_table_description(self, connection_id: int, table_name: str,
                                  description: str, updated_by: str) -> Dict[str, Any]:
        """Create or update the description for a registered table."""
        with self.get_session() as session:
            row = (session.query(TableDescription)
                   .filter(TableDescription.connection_id == connection_id,
                           TableDescription.table_name == table_name)
                   .first())
            if row:
                row.description = description
                row.updated_by = updated_by
                row.updated_at = datetime.now(timezone.utc)
            else:
                row = TableDescription(
                    connection_id=connection_id, table_name=table_name,
                    description=description, updated_by=updated_by,
                    updated_at=datetime.now(timezone.utc),
                )
                session.add(row)
            session.commit()
            session.refresh(row)
            return row.to_dict()

    def list_table_descriptions(self) -> List[Dict[str, Any]]:
        """Return all table description rows (used to bulk-load for catalog response)."""
        with self.get_session(read_only=True) as session:
            rows = session.query(TableDescription).all()
            return [r.to_dict() for r in rows]

    def increment_table_preview_count(self, connection_id: int, table_name: str) -> None:
        """Increment the preview_count counter and update last_queried_at."""
        with self.get_session() as session:
            row = (session.query(TableDescription)
                   .filter(TableDescription.connection_id == connection_id,
                           TableDescription.table_name == table_name)
                   .first())
            if row:
                row.preview_count = (row.preview_count or 0) + 1
                row.last_queried_at = datetime.now(timezone.utc)
            else:
                row = TableDescription(
                    connection_id=connection_id, table_name=table_name,
                    preview_count=1,
                    last_queried_at=datetime.now(timezone.utc),
                )
                session.add(row)
            session.commit()

    # ── Notification Log ────────────────────────────────────────────────────

    def log_notification(self, event_type: str, channel: str, recipient: str,
                         status: str = "sent", title: str = None, message: str = None,
                         payload: dict = None, execution_id: str = None,
                         schedule_id: int = None, attempt_count: int = 1,
                         error_message: str = None) -> Dict[str, Any]:
        """Record a notification delivery attempt."""
        with self.get_session() as session:
            row = NotificationLog(
                event_type=event_type, channel=channel, recipient=recipient,
                status=status, title=title, message=message, payload=payload,
                error_message=error_message, attempt_count=attempt_count,
                execution_id=execution_id, schedule_id=schedule_id,
                delivered_at=datetime.now(timezone.utc) if status == "sent" else None,
            )
            session.add(row)
            session.commit()
            session.refresh(row)
            return row.to_dict()

    def update_notification_status(self, notif_id: int, status: str,
                                   error_message: str = None) -> None:
        """Update delivery status of a notification."""
        with self.get_session() as session:
            row = session.query(NotificationLog).get(notif_id)
            if row:
                row.status = status
                if error_message:
                    row.error_message = error_message
                if status == "sent":
                    row.delivered_at = datetime.now(timezone.utc)
                session.commit()

    def list_notifications(self, username: str, unread_only: bool = False,
                           limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
        """List notifications for a user (websocket channel, matched by recipient)."""
        with self.get_session(read_only=True) as session:
            q = session.query(NotificationLog).filter(
                NotificationLog.recipient == username,
                NotificationLog.channel == "websocket",
            )
            if unread_only:
                q = q.filter(NotificationLog.is_read == 0)
            rows = q.order_by(NotificationLog.created_at.desc()).offset(offset).limit(limit).all()
            return [r.to_dict() for r in rows]

    def count_unread_notifications(self, username: str) -> int:
        """Count unread websocket notifications for a user."""
        with self.get_session(read_only=True) as session:
            return session.query(NotificationLog).filter(
                NotificationLog.recipient == username,
                NotificationLog.channel == "websocket",
                NotificationLog.is_read == 0,
            ).count()

    def mark_notification_read(self, notif_id: int) -> None:
        """Mark a single notification as read."""
        with self.get_session() as session:
            row = session.query(NotificationLog).get(notif_id)
            if row and not row.is_read:
                row.is_read = 1
                row.read_at = datetime.now(timezone.utc)
                session.commit()

    def mark_all_notifications_read(self, username: str) -> int:
        """Mark all unread notifications as read for a user. Returns count."""
        with self.get_session() as session:
            now = datetime.now(timezone.utc)
            count = session.query(NotificationLog).filter(
                NotificationLog.recipient == username,
                NotificationLog.channel == "websocket",
                NotificationLog.is_read == 0,
            ).update({"is_read": 1, "read_at": now}, synchronize_session=False)
            session.commit()
            return count

    def cleanup_old_notifications(self, max_age_days: int = 30) -> int:
        """Delete notifications older than max_age_days. Returns count deleted."""
        with self.get_session() as session:
            cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
            count = session.query(NotificationLog).filter(
                NotificationLog.created_at < cutoff,
            ).delete(synchronize_session=False)
            session.commit()
            return count

    # ── Phase 23A: Report Catalog ─────────────────────────────────────────────

    def create_folder(self, name: str, description: str = None, parent_id: int = None,
                      created_by: str = None, icon: str = "folder",
                      color: str = "#1976d2") -> Dict[str, Any]:
        with self.get_session() as session:
            folder = ReportFolder(name=name, description=description, parent_id=parent_id,
                                  created_by=created_by, icon=icon, color=color)
            session.add(folder)
            session.flush()
            session.refresh(folder)
            return folder.to_dict()

    def list_folders(self, parent_id: Optional[int] = None,
                     all_folders: bool = False) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ReportFolder)
            if not all_folders:
                if parent_id is None:
                    q = q.filter(ReportFolder.parent_id.is_(None))
                else:
                    q = q.filter(ReportFolder.parent_id == parent_id)
            return [f.to_dict() for f in q.order_by(ReportFolder.name).all()]

    def update_folder(self, folder_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            folder = session.query(ReportFolder).filter(ReportFolder.id == folder_id).first()
            if not folder:
                return None
            for k, v in kwargs.items():
                if hasattr(folder, k):
                    setattr(folder, k, v)
            session.flush()
            session.refresh(folder)
            return folder.to_dict()

    def delete_folder(self, folder_id: int) -> bool:
        with self.get_session() as session:
            folder = session.query(ReportFolder).filter(ReportFolder.id == folder_id).first()
            if not folder:
                return False
            # Un-assign any reports in this folder
            session.query(ReportFolderAssignment).filter(
                ReportFolderAssignment.folder_id == folder_id
            ).delete(synchronize_session=False)
            # Re-parent child folders to this folder's parent
            session.query(ReportFolder).filter(
                ReportFolder.parent_id == folder_id
            ).update({"parent_id": folder.parent_id}, synchronize_session=False)
            session.delete(folder)
            return True

    def set_report_folder(self, report_id: int, folder_id: Optional[int],
                          report_type: str = "business") -> None:
        with self.get_session() as session:
            existing = session.query(ReportFolderAssignment).filter(
                ReportFolderAssignment.report_id == report_id,
                ReportFolderAssignment.report_type == report_type,
            ).first()
            if folder_id is None:
                if existing:
                    session.delete(existing)
            else:
                if existing:
                    existing.folder_id = folder_id
                else:
                    session.add(ReportFolderAssignment(
                        report_id=report_id, report_type=report_type, folder_id=folder_id))

    def get_report_folder(self, report_id: int,
                          report_type: str = "business") -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            assignment = session.query(ReportFolderAssignment).filter(
                ReportFolderAssignment.report_id == report_id,
                ReportFolderAssignment.report_type == report_type,
            ).first()
            if not assignment:
                return None
            folder = session.query(ReportFolder).filter(
                ReportFolder.id == assignment.folder_id
            ).first()
            return folder.to_dict() if folder else None

    def create_tag(self, name: str, color: str = "#666666",
                   created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            tag = ReportTag(name=name, color=color, created_by=created_by)
            session.merge(tag)  # merge handles unique constraint gracefully
            session.flush()
            existing = session.query(ReportTag).filter(ReportTag.name == name).first()
            return existing.to_dict() if existing else tag.to_dict()

    def list_tags(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [t.to_dict() for t in session.query(ReportTag).order_by(ReportTag.name).all()]

    def delete_tag(self, tag_id: int) -> bool:
        with self.get_session() as session:
            tag = session.query(ReportTag).filter(ReportTag.id == tag_id).first()
            if not tag:
                return False
            session.query(ReportTagAssignment).filter(
                ReportTagAssignment.tag_id == tag_id
            ).delete(synchronize_session=False)
            session.delete(tag)
            return True

    def assign_report_tags(self, report_id: int, tag_ids: List[int],
                           report_type: str = "business") -> None:
        with self.get_session() as session:
            session.query(ReportTagAssignment).filter(
                ReportTagAssignment.report_id == report_id,
                ReportTagAssignment.report_type == report_type,
            ).delete(synchronize_session=False)
            for tid in tag_ids:
                session.add(ReportTagAssignment(
                    report_id=report_id, report_type=report_type, tag_id=tid))

    def get_report_tags(self, report_id: int,
                        report_type: str = "business") -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            assignments = session.query(ReportTagAssignment).filter(
                ReportTagAssignment.report_id == report_id,
                ReportTagAssignment.report_type == report_type,
            ).all()
            tag_ids = [a.tag_id for a in assignments]
            if not tag_ids:
                return []
            tags = session.query(ReportTag).filter(ReportTag.id.in_(tag_ids)).all()
            return [t.to_dict() for t in tags]

    def toggle_report_favorite(self, report_id: int, username: str,
                               report_type: str = "business") -> bool:
        """Toggle. Returns True if added, False if removed."""
        with self.get_session() as session:
            existing = session.query(ReportFavorite).filter(
                ReportFavorite.report_id == report_id,
                ReportFavorite.report_type == report_type,
                ReportFavorite.username == username,
            ).first()
            if existing:
                session.delete(existing)
                return False
            session.add(ReportFavorite(
                report_id=report_id, report_type=report_type, username=username))
            return True

    def get_user_favorites(self, username: str,
                           report_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return list of favorited {report_id, report_type} for a user."""
        with self.get_session(read_only=True) as session:
            q = session.query(ReportFavorite).filter(
                ReportFavorite.username == username)
            if report_type:
                q = q.filter(ReportFavorite.report_type == report_type)
            rows = q.all()
            return [{"report_id": r.report_id, "report_type": r.report_type or "business"}
                    for r in rows]

    def record_report_view(self, report_id: int, username: str,
                           report_type: str = "business",
                           keep_last: int = 20) -> None:
        with self.get_session() as session:
            session.add(ReportView(
                report_id=report_id, report_type=report_type, username=username))
            session.flush()
            # Trim to last N views per user
            subq = (session.query(ReportView.id)
                    .filter(ReportView.username == username)
                    .order_by(ReportView.viewed_at.desc())
                    .offset(keep_last).all())
            old_ids = [r.id for r in subq]
            if old_ids:
                session.query(ReportView).filter(
                    ReportView.id.in_(old_ids)
                ).delete(synchronize_session=False)

    def get_recently_viewed(self, username: str, limit: int = 10,
                            report_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return list of recently viewed {report_id, report_type} (most recent first)."""
        with self.get_session(read_only=True) as session:
            q = session.query(ReportView).filter(ReportView.username == username)
            if report_type:
                q = q.filter(ReportView.report_type == report_type)
            rows = q.order_by(ReportView.viewed_at.desc()).limit(limit * 2).all()
            seen: set = set()
            result = []
            for r in rows:
                key = (r.report_id, r.report_type or "business")
                if key not in seen:
                    seen.add(key)
                    result.append({"report_id": r.report_id,
                                   "report_type": r.report_type or "business"})
                    if len(result) >= limit:
                        break
            return result

    # ── Portal helpers (Phase 59) ──────────────────────────────────────────────

    def count_user_reports(self, username: str, role: str) -> Dict[str, int]:
        """Count the finance reports accessible to a user.

        FB-60 (2026-09-26): the ``parametric`` half is gone -- the legacy
        ``reports`` table is no longer served, so it is not counted.

        2026-08-09 metadata-scale audit (finding 1): the non-admin branch
        used to materialize every own + every published BusinessReport id
        into two Python sets just to ``len()`` their union — and that pair
        of queries was a DRIFTED visibility rule (no role_whitelist gate,
        no Phase-157 grants), so the portal tile could disagree with what
        ``GET /api/business-reports`` actually lists.  Admin tier keeps the
        SQL COUNT; everyone else now counts through the ONE visibility
        chokepoint (``core.reports.authorization.
        list_visible_business_reports``) — never a third copy of the rule.
        """
        if role in ADMIN_TIER_ROLES:
            with self.get_session(read_only=True) as session:
                biz_count = session.query(BusinessReport).count()
            return {"business": biz_count, "total": biz_count}
        # Non-admin — outside the session above (the chokepoint opens its
        # own read sessions).  Fail-closed: a chokepoint error yields 0,
        # never an unfiltered count.
        try:
            from core.reports.authorization import list_visible_business_reports
            biz_count = len(list_visible_business_reports(
                self, {"username": username or "", "role": role or "viewer"}))
        except Exception as _cnt_exc:
            import logging as _logging
            _logging.getLogger(__name__).warning(
                "count_user_reports: visibility chokepoint failed "
                "(returning 0 business reports): %s", _cnt_exc)
            biz_count = 0
        return {"business": biz_count, "total": biz_count}

    def count_executions_today(self, username: str = None) -> int:
        """Count executions started today (UTC)."""
        today_start = datetime.now(timezone.utc).replace(
            hour=0, minute=0, second=0, microsecond=0)
        with self.get_session(read_only=True) as session:
            q = session.query(QueryExecution).filter(
                QueryExecution.started_at >= today_start)
            if username:
                q = q.filter(QueryExecution.executed_by == username)
            return q.count()

    def search_reports_unified(self, q: str, limit: int = 30,
                               viewer: Optional[Dict[str, Any]] = None,
                               ) -> List[Dict[str, Any]]:
        """Full-text search across finance reports (Phase 58; FB-60 removed the legacy half).

        ``viewer`` (2026-08-09, metadata-scale audit finding 6): the
        authenticated caller's user dict.  When provided, business-report
        rows are restricted to what that user may view — the SAME
        single-chokepoint rule as GET /api/business-reports (own /
        published-within-role_whitelist / owner-group / explicit grants).
        The bulk of the rule runs as a SQL predicate (owner / owner-group /
        grant / is_published); the role_whitelist trim on published rows is
        dict-only Python over an OVER-FETCHED, offset-paged window so a run
        of hidden rows cannot silently shrink the page below ``limit``
        while visible matches remain.  The caller's groups + grants are
        resolved ONCE per call (2 queries), never per row.

        ``viewer=None`` keeps the legacy UNFILTERED behavior for trusted
        internal/DB-level callers — API routes MUST pass the caller.
        """
        from sqlalchemy import or_
        # 2026-08-10 -- import hoisted out of the ``viewer is not None``
        # branch.  It was correct (``ctx`` is non-None only when the import
        # ran) but relied on two guards staying correlated: the later use is
        # under ``ctx is not None``, so anyone loosening that guard turns
        # this into a NameError at runtime.  Still function-level, so the
        # import cycle it was avoiding stays avoided.
        from core.reports.authorization import (can_view_business_report,
                                                resolve_viewer_context)
        ctx = None
        if viewer is not None:
            ctx = resolve_viewer_context(viewer, self)
        with self.get_session(read_only=True) as session:
            term = f"%{q}%"
            results: List[Dict[str, Any]] = []
            # Business reports.
            bq = (session.query(BusinessReport)
                  .filter(or_(BusinessReport.name.ilike(term),
                              BusinessReport.description.ilike(term))))
            if ctx is not None and not ctx.get("sees_all"):
                # Visibility predicate — candidate superset in SQL.  Only
                # published rows with a non-empty role_whitelist still need
                # the dict-only trim below; everything else is decided here.
                # 2026-08-09: clause building extracted to ONE chokepoint
                # (_br_visibility_clauses, mixin_datasets) shared with the
                # paginated list — never a second copy that can drift.
                bq = bq.filter(or_(*self._br_visibility_clauses(ctx)))
                # Over-fetch + trim: filtering AFTER a LIMIT silently
                # shrinks pages, so page through the predicate-narrowed
                # query until ``limit`` visible rows are found or the
                # candidates are exhausted.  The per-row check is dict-only
                # (ctx pre-resolved) — 0 SQL per row.
                b_dicts: List[Dict[str, Any]] = []
                offset, batch = 0, max(int(limit) * 3, 30)
                while len(b_dicts) < limit:
                    rows = (bq.order_by(BusinessReport.name, BusinessReport.id)
                            .limit(batch).offset(offset).all())
                    for r in rows:
                        d = r.to_dict()
                        if can_view_business_report(d, viewer, self, ctx=ctx):
                            b_dicts.append(d)
                            if len(b_dicts) >= limit:
                                break
                    if len(rows) < batch:
                        break
                    offset += batch
            else:
                # Admin-tier / support viewer, or legacy viewer=None caller.
                b_rows = (bq.order_by(BusinessReport.name)
                          .limit(limit).all())
                b_dicts = [r.to_dict() for r in b_rows]
            results.extend([{"report_type": "business", **d} for d in b_dicts])
            results.sort(key=lambda x: x.get("name", "").lower())
            return results[:limit]

    # ── Phase 58: Certification ──────────────────────────────────────────────

    def certify_business_report(self, report_id: int, certified_by: str,
                                template_category: Optional[str] = None) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            if not r:
                return None
            r.is_certified = True
            r.certified_by = certified_by
            r.certified_at = datetime.now(timezone.utc)
            if template_category is not None:
                r.template_category = template_category
            session.flush()
            return r.to_dict()

    def uncertify_business_report(self, report_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            r = session.query(BusinessReport).filter(BusinessReport.id == report_id).first()
            if not r:
                return None
            r.is_certified = False
            r.certified_by = None
            r.certified_at = None
            r.template_category = None
            session.flush()
            return r.to_dict()

    def list_certified_templates(self, category: Optional[str] = None,
                                 limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(BusinessReport).filter(
                BusinessReport.is_certified,
            )
            if category:
                q = q.filter(BusinessReport.template_category == category)
            rows = q.order_by(BusinessReport.name).limit(limit).all()
            return [r.to_dict() for r in rows]

    def list_template_categories(self) -> List[str]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(BusinessReport.template_category)
                    .filter(BusinessReport.is_certified,
                            BusinessReport.template_category.isnot(None))
                    .distinct().all())
            return sorted([r[0] for r in rows if r[0]])

    # ── Phase 58: Business Report Share Tokens ───────────────────────────────

    def create_business_report_share(self, report_id: int, created_by: str = None,
                                     expires_at=None) -> Dict[str, Any]:
        import uuid
        with self.get_session() as session:
            tok = BusinessReportShareToken(
                token=uuid.uuid4().hex + uuid.uuid4().hex[:32],
                report_id=report_id,
                created_by=created_by,
                expires_at=expires_at,
            )
            session.add(tok)
            session.flush()
            return tok.to_dict()

    def get_business_report_share_by_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            t = session.query(BusinessReportShareToken).filter(
                BusinessReportShareToken.token == token,
            ).first()
            return t.to_dict() if t else None

    def list_business_report_shares(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(BusinessReportShareToken).filter(
                BusinessReportShareToken.report_id == report_id,
                BusinessReportShareToken.is_active,
            ).order_by(BusinessReportShareToken.created_at.desc()).all()
            return [r.to_dict() for r in rows]

    def deactivate_business_report_share(self, token: str) -> bool:
        with self.get_session() as session:
            t = session.query(BusinessReportShareToken).filter(
                BusinessReportShareToken.token == token,
            ).first()
            if not t:
                return False
            t.is_active = False
            return True

    def increment_business_report_share_access(self, token: str) -> None:
        with self.get_session() as session:
            t = session.query(BusinessReportShareToken).filter(
                BusinessReportShareToken.token == token,
            ).first()
            if t:
                t.access_count = (t.access_count or 0) + 1

    # ── Phase 23B: Report Bookmarks ───────────────────────────────────────────

    def save_bookmark(self, report_id: int, username: str, name: str,
                      param_values: dict) -> Dict[str, Any]:
        with self.get_session() as session:
            bm = ReportBookmark(report_id=report_id, username=username,
                                name=name, param_values=param_values)
            session.add(bm)
            session.flush()
            session.refresh(bm)
            return bm.to_dict()

    def list_bookmarks(self, report_id: int,
                       username: str) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [b.to_dict() for b in
                    session.query(ReportBookmark)
                    .filter(ReportBookmark.report_id == report_id,
                            ReportBookmark.report_type == "business",
                            ReportBookmark.username == username)
                    .order_by(ReportBookmark.name).all()]

    def delete_bookmark(self, bookmark_id: int, username: str) -> bool:
        with self.get_session() as session:
            bm = session.query(ReportBookmark).filter(
                ReportBookmark.id == bookmark_id,
                ReportBookmark.username == username,
            ).first()
            if not bm:
                return False
            session.delete(bm)
            return True

    # ── Phase 23D: PDF Config ─────────────────────────────────────────────────

    def get_pdf_config(self, report_id: int) -> Dict[str, Any]:
        """The FINANCE report's config; a legacy row on the same number is
        not this report's (F7 follow-up, 2026-09-26)."""
        with self.get_session(read_only=True) as session:
            cfg = session.query(ReportPDFConfig).filter(
                ReportPDFConfig.report_id == report_id,
                ReportPDFConfig.report_type == "business",
            ).first()
            if not cfg:
                return ReportPDFConfig(report_id=report_id).to_dict()
            return cfg.to_dict()

    def save_pdf_config(self, report_id: int, **kwargs) -> Dict[str, Any]:
        """Upsert the FINANCE report's config.  ``report_id`` is UNIQUE on
        this table, so an unmigrated LEGACY row on the same number blocks the
        insert: refused by name rather than overwritten (the legacy row is
        the operator's; migrate_reports.py moves it off this id)."""
        with self.get_session() as session:
            cfg = session.query(ReportPDFConfig).filter(
                ReportPDFConfig.report_id == report_id,
                ReportPDFConfig.report_type == "business",
            ).first()
            if not cfg:
                blocker = session.query(ReportPDFConfig).filter(
                    ReportPDFConfig.report_id == report_id).first()
                if blocker is not None:
                    from core.reports.legacy_parametric import refusal
                    raise ValueError(refusal(
                        f"pdf-config for report {report_id}",
                        instead="A legacy parametric report's PDF config still "
                                "occupies this id; migrate it first."))
                cfg = ReportPDFConfig(report_id=report_id)
                session.add(cfg)
            for k, v in kwargs.items():
                if hasattr(cfg, k):
                    setattr(cfg, k, v)
            cfg.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(cfg)
            return cfg.to_dict()

    # ── Phase 23E: Report Bursting ────────────────────────────────────────────

    def create_burst_job(self, report_id: int, burst_column: str,
                         output_format: str = "pdf", delivery_type: str = "email",
                         base_params: dict = None, recipient_map: dict = None,
                         default_recipient: str = None, s3_prefix: str = None,
                         created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            job = BurstJob(report_id=report_id, burst_column=burst_column,
                           output_format=output_format, delivery_type=delivery_type,
                           base_params=base_params or {}, recipient_map=recipient_map,
                           default_recipient=default_recipient, s3_prefix=s3_prefix,
                           created_by=created_by)
            session.add(job)
            session.flush()
            session.refresh(job)
            return job.to_dict()

    def get_burst_job(self, job_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            job = session.query(BurstJob).filter(BurstJob.id == job_id).first()
            return job.to_dict() if job else None

    def list_burst_jobs(self, report_id: int,
                        limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [j.to_dict() for j in
                    session.query(BurstJob)
                    .filter(BurstJob.report_id == report_id,
                            BurstJob.report_type == "business")
                    .order_by(BurstJob.created_at.desc())
                    .limit(limit).all()]

    def update_burst_job(self, job_id: int, **kwargs) -> None:
        with self.get_session() as session:
            session.query(BurstJob).filter(BurstJob.id == job_id).update(
                kwargs, synchronize_session=False
            )

    def create_burst_tasks(self, job_id: int,
                           tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        with self.get_session() as session:
            created = []
            for t in tasks:
                bt = BurstTask(burst_job_id=job_id,
                               dimension_value=t["dimension_value"],
                               recipient=t.get("recipient"))
                session.add(bt)
                session.flush()
                session.refresh(bt)
                created.append(bt.to_dict())
            return created

    def list_burst_tasks(self, job_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [t.to_dict() for t in
                    session.query(BurstTask)
                    .filter(BurstTask.burst_job_id == job_id)
                    .order_by(BurstTask.dimension_value).all()]

    def update_burst_task(self, task_id: int, **kwargs) -> None:
        with self.get_session() as session:
            session.query(BurstTask).filter(BurstTask.id == task_id).update(
                kwargs, synchronize_session=False
            )

    # ── Phase 23F: Alert Rules ────────────────────────────────────────────────

    def create_alert_rule(self, report_id: int, name: str, column_name: str,
                          operator: str, threshold_value: float,
                          aggregation: str = "last", channels: list = None,
                          recipients: str = None, slack_webhook: str = None,
                          cooldown_minutes: int = 60,
                          created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            rule = AlertRule(
                report_id=report_id, name=name, column_name=column_name,
                operator=operator, threshold_value=threshold_value,
                aggregation=aggregation, channels=channels or [],
                recipients=recipients, slack_webhook=slack_webhook,
                cooldown_minutes=cooldown_minutes, created_by=created_by,
            )
            session.add(rule)
            session.flush()
            session.refresh(rule)
            return rule.to_dict()

    def get_alert_rule(self, rule_id: int) -> Optional[Dict[str, Any]]:
        """Single-rule fetch — added for the Phase 1 Part-1b owner-or-admin
        gate on alert-rule mutations (mirrors get_burst_job)."""
        with self.get_session(read_only=True) as session:
            rule = session.query(AlertRule).filter(AlertRule.id == rule_id).first()
            return rule.to_dict() if rule else None

    def list_alert_rules(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in
                    session.query(AlertRule)
                    .filter(AlertRule.report_id == report_id,
                            AlertRule.report_type == "business")
                    .order_by(AlertRule.name).all()]

    def update_alert_rule(self, rule_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            rule = session.query(AlertRule).filter(AlertRule.id == rule_id).first()
            if not rule:
                return None
            for k, v in kwargs.items():
                if hasattr(rule, k):
                    setattr(rule, k, v)
            session.flush()
            session.refresh(rule)
            return rule.to_dict()

    def delete_alert_rule(self, rule_id: int) -> bool:
        with self.get_session() as session:
            rule = session.query(AlertRule).filter(AlertRule.id == rule_id).first()
            if not rule:
                return False
            session.delete(rule)
            return True

    def record_alert(self, rule_id: int, actual_value: float,
                     threshold_value: float, channel: str, sent_to: str,
                     suppressed: bool = False) -> None:
        with self.get_session() as session:
            session.add(AlertHistory(
                rule_id=rule_id, actual_value=actual_value,
                threshold_value=threshold_value, channel=channel,
                sent_to=sent_to, was_suppressed=suppressed,
            ))
            if not suppressed:
                session.query(AlertRule).filter(AlertRule.id == rule_id).update(
                    {"last_triggered_at": datetime.now(timezone.utc)},
                    synchronize_session=False,
                )

    def list_alert_history(self, rule_id: int,
                           limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [h.to_dict() for h in
                    session.query(AlertHistory)
                    .filter(AlertHistory.rule_id == rule_id)
                    .order_by(AlertHistory.triggered_at.desc())
                    .limit(limit).all()]

    def evaluate_alert_rules(self, report_id: int,
                             result_df_dict: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Evaluate all enabled alert rules for a report against result rows.
        Returns list of triggered rule dicts (caller handles notification)."""
        rules = [r for r in self.list_alert_rules(report_id) if r.get("is_enabled")]
        triggered = []
        now = datetime.now(timezone.utc)

        for rule in rules:
            # Check cooldown
            last = rule.get("last_triggered_at")
            if last:
                try:
                    last_dt = datetime.fromisoformat(last)
                    if last_dt.tzinfo is None:
                        last_dt = last_dt.replace(tzinfo=timezone.utc)
                    elapsed_min = (now - last_dt).total_seconds() / 60
                    if elapsed_min < rule["cooldown_minutes"]:
                        continue  # Still in cooldown
                except Exception as e:
                    logger.debug("Failed to parse cooldown timestamp: %s", e)

            col = rule["column_name"]
            agg = rule.get("aggregation", "last")
            try:
                values = [float(r[col]) for r in result_df_dict
                          if r.get(col) is not None]
                if not values:
                    continue
                if agg == "last":
                    actual = values[-1]
                elif agg == "sum":
                    actual = sum(values)
                elif agg == "avg":
                    actual = sum(values) / len(values)
                elif agg == "max":
                    actual = max(values)
                elif agg == "min":
                    actual = min(values)
                elif agg == "count":
                    actual = float(len(values))
                else:
                    actual = values[-1]
            except (KeyError, ValueError, TypeError):
                continue

            op = rule["operator"]
            th = rule["threshold_value"]
            fired = (
                (op == ">"  and actual >  th) or
                (op == "<"  and actual <  th) or
                (op == ">=" and actual >= th) or
                (op == "<=" and actual <= th) or
                (op == "="  and actual == th) or
                (op == "!=" and actual != th)
            )
            if fired:
                triggered.append({**rule, "actual_value": actual})

        return triggered

    # ── Phase 23C: Conditional Formatting ────────────────────────────────────

    def save_conditional_formats(self, report_id: int,
                                 rules: List[Dict[str, Any]]) -> None:
        """Replace all conditional format rules for a FINANCE report (a legacy
        row on the same number is not touched)."""
        with self.get_session() as session:
            session.query(ConditionalFormatRule).filter(
                ConditionalFormatRule.report_id == report_id,
                ConditionalFormatRule.report_type == "business",
            ).delete(synchronize_session=False)
            for i, r in enumerate(rules):
                session.add(ConditionalFormatRule(
                    report_id=report_id,
                    column_name=r.get("column_name", ""),
                    rule_order=r.get("rule_order", i),
                    condition_type=r.get("condition_type", "value_range"),
                    condition_value=r.get("condition_value"),
                    bg_color=r.get("bg_color"),
                    text_color=r.get("text_color"),
                    icon=r.get("icon", "none"),
                    bold=r.get("bold", False),
                    is_enabled=r.get("is_enabled", True),
                ))

    def get_conditional_formats(self, report_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in
                    session.query(ConditionalFormatRule)
                    .filter(ConditionalFormatRule.report_id == report_id,
                            ConditionalFormatRule.report_type == "business")
                    .order_by(ConditionalFormatRule.column_name,
                               ConditionalFormatRule.rule_order)
                    .all()]

    # ── Phase 23H: Cloud Delivery ─────────────────────────────────────────────

    def save_cloud_delivery_config(self, schedule_id: int,
                                   **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            cfg = session.query(CloudDeliveryConfig).filter(
                CloudDeliveryConfig.schedule_id == schedule_id
            ).first()
            if not cfg:
                cfg = CloudDeliveryConfig(schedule_id=schedule_id,
                                          provider=kwargs.pop("provider", "s3"))
                session.add(cfg)
            for k, v in kwargs.items():
                if hasattr(cfg, k):
                    setattr(cfg, k, v)
            session.flush()
            session.refresh(cfg)
            return cfg.to_dict()

    def get_cloud_delivery_config(self,
                                  schedule_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            cfg = session.query(CloudDeliveryConfig).filter(
                CloudDeliveryConfig.schedule_id == schedule_id
            ).first()
            return cfg.to_dict() if cfg else None

    def record_delivery(self, delivery_type: str, destination: str,
                        status: str, schedule_id: int = None,
                        burst_task_id: int = None, execution_id: str = None,
                        file_format: str = None, file_size_bytes: int = None,
                        error_message: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            d = DeliveryHistory(
                schedule_id=schedule_id, burst_task_id=burst_task_id,
                execution_id=execution_id, delivery_type=delivery_type,
                destination=destination, file_format=file_format,
                file_size_bytes=file_size_bytes, status=status,
                error_message=error_message,
                delivered_at=datetime.now(timezone.utc) if status == "delivered" else None,
            )
            session.add(d)
            session.flush()
            session.refresh(d)
            return d.to_dict()

    def list_delivery_history(self, schedule_id: int = None,
                              burst_task_id: int = None,
                              limit: int = 100) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(DeliveryHistory)
            if schedule_id is not None:
                q = q.filter(DeliveryHistory.schedule_id == schedule_id)
            if burst_task_id is not None:
                q = q.filter(DeliveryHistory.burst_task_id == burst_task_id)
            return [d.to_dict() for d in
                    q.order_by(DeliveryHistory.attempted_at.desc()).limit(limit).all()]

    def cleanup_delivery_history(self, retention_days: int = 90) -> int:
        """Delete delivery_history rows older than ``retention_days``.

        2026-09-15 — ``delivery.delivery_history_retention_days`` shipped at
        90 and no sweep existed, so this table grew forever: one row per
        delivery attempt per schedule per burst recipient, which on a daily
        estate is the fastest-growing table nobody was watching.  The value
        was a promise with no mechanism.

        ``attempted_at`` is indexed, so the DELETE is bounded by age rather
        than by a cursor — which is also what makes it safe to run on more
        than one pod during a rolling upgrade.  0 = keep forever.
        """
        if retention_days <= 0:
            return 0
        cutoff = datetime.now(timezone.utc) - timedelta(days=int(retention_days))
        with self.get_session() as session:
            n = session.query(DeliveryHistory).filter(
                DeliveryHistory.attempted_at < cutoff
            ).delete(synchronize_session=False)
            return int(n or 0)

    # ── Workspaces (Phase 25) ─────────────────────────────────────────────────    # ── Workspaces (Phase 25) ─────────────────────────────────────────────────

    def ensure_default_workspace(self) -> Dict[str, Any]:
        """Create the Global workspace on first startup if none exist.

        Two corrections (2026-09-02), both found as intermittent
        ``UNIQUE constraint failed: workspaces.name`` SETUP ERRORS that
        roamed between test files under xdist and never reproduced alone:

        * the existence check looked for ANY ``is_active`` workspace, but
          the insert always creates ``Global``.  A deployment that had
          DEACTIVATED Global -- or that had only non-default workspaces
          left active -- tried to insert a second ``Global`` and hit the
          unique constraint.  The check now asks the question the insert
          answers: does the ``global`` slug exist, active or not;
        * check-then-insert is a RACE.  Two pods (or two xdist workers)
          starting together both see nothing and both insert.  The loser
          used to take an IntegrityError out of a startup path, which is
          how a first-boot flake becomes a pod that will not start.
          Losing the race is now a normal outcome: re-read and use the
          row the winner wrote.
        """
        from sqlalchemy.exc import IntegrityError

        with self.get_session() as session:
            existing = session.query(Workspace).filter(
                Workspace.slug == "global").first()
            if existing:
                return existing.to_dict()
            active = session.query(Workspace).filter(
                Workspace.is_active).first()
            if active:
                return active.to_dict()
        try:
            with self.get_session() as session:
                ws = Workspace(name="Global", slug="global",
                               description="Default workspace",
                               created_by="system")
                session.add(ws)
                session.flush()
                session.refresh(ws)
                return ws.to_dict()
        except IntegrityError:
            # Someone else seeded it between our check and our insert —
            # the desired state, reached by another writer.
            logger.info("[workspaces] default workspace was seeded "
                        "concurrently; using the existing row")
            with self.get_session(read_only=True) as session:
                existing = session.query(Workspace).filter(
                    Workspace.slug == "global").first()
                if existing is not None:
                    return existing.to_dict()
            raise

    def list_workspaces(self, username: str = None) -> List[Dict[str, Any]]:
        """Return workspaces the user is a member of, or all if username is None."""
        with self.get_session(read_only=True) as session:
            if username is None:
                wss = session.query(Workspace).filter(
                    Workspace.is_active
                ).order_by(Workspace.name).all()
                return [w.to_dict() for w in wss]
            # Workspaces where user is a member
            member_wids = [
                m.workspace_id for m in
                session.query(WorkspaceMember).filter(
                    WorkspaceMember.username == username
                ).all()
            ]
            wss = session.query(Workspace).filter(
                Workspace.id.in_(member_wids),
                Workspace.is_active,
            ).order_by(Workspace.name).all()
            return [w.to_dict() for w in wss]

    def get_workspace(self, workspace_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            ws = session.query(Workspace).filter(Workspace.id == workspace_id).first()
            return ws.to_dict() if ws else None

    def create_workspace(self, name: str, slug: str,
                         description: str = None,
                         created_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            ws = Workspace(name=name, slug=slug, description=description,
                           created_by=created_by)
            session.add(ws)
            session.flush()
            session.refresh(ws)
            # Auto-add creator as owner
            if created_by:
                m = WorkspaceMember(workspace_id=ws.id, username=created_by,
                                    role="owner", added_by=created_by)
                session.add(m)
                session.flush()
            return ws.to_dict()

    def update_workspace(self, workspace_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            ws = session.query(Workspace).filter(Workspace.id == workspace_id).first()
            if not ws:
                return None
            for k, v in kwargs.items():
                if hasattr(ws, k):
                    setattr(ws, k, v)
            ws.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(ws)
            return ws.to_dict()

    def delete_workspace(self, workspace_id: int) -> bool:
        with self.get_session() as session:
            ws = session.query(Workspace).filter(Workspace.id == workspace_id).first()
            if not ws:
                return False
            ws.is_active = False
            ws.updated_at = datetime.now(timezone.utc)
            return True

    def list_workspace_members(self, workspace_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            members = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id
            ).order_by(WorkspaceMember.added_at).all()
            return [m.to_dict() for m in members]

    def add_workspace_member(self, workspace_id: int, username: str,
                             role: str = "member",
                             added_by: str = None) -> Dict[str, Any]:
        with self.get_session() as session:
            # Upsert: update role if already member
            existing = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.username == username,
            ).first()
            if existing:
                existing.role = role
                session.flush()
                session.refresh(existing)
                return existing.to_dict()
            m = WorkspaceMember(workspace_id=workspace_id, username=username,
                                role=role, added_by=added_by)
            session.add(m)
            session.flush()
            session.refresh(m)
            return m.to_dict()

    def update_workspace_member_role(self, workspace_id: int,
                                     username: str, role: str) -> bool:
        with self.get_session() as session:
            m = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.username == username,
            ).first()
            if not m:
                return False
            m.role = role
            return True

    def remove_workspace_member(self, workspace_id: int,
                                username: str) -> bool:
        with self.get_session() as session:
            m = session.query(WorkspaceMember).filter(
                WorkspaceMember.workspace_id == workspace_id,
                WorkspaceMember.username == username,
            ).first()
            if not m:
                return False
            session.delete(m)
            return True

    # ── Report Embed Tokens (27) ──────────────────────────────────────────────

    def create_report_embed_token(self, report_id: int, created_by: str = None,
                                  expires_at=None, allowed_params=None,
                                  report_type: str = "business",
                                  allowed_ad_groups=None,
                                  allowed_user_groups=None) -> Dict[str, Any]:
        """Mint an embed token.

        2026-08-29 — ``allowed_ad_groups`` / ``allowed_user_groups`` are the
        optional per-group scope (see ``ReportEmbedToken``).  Stored as NULL
        rather than ``[]`` when empty so "never configured" and "configured
        empty" are the same state on read — the consumer path checks for a
        NON-EMPTY list, and an empty list must not read as a scope.
        """
        import uuid
        import json as _json
        with self.get_session() as session:
            tok = ReportEmbedToken(
                token=uuid.uuid4().hex,
                report_id=report_id,
                report_type=report_type,
                created_by=created_by,
                expires_at=expires_at,
                is_active=True,
                access_count=0,
                allowed_params=_json.dumps(allowed_params) if allowed_params else None,
                allowed_ad_groups=(list(allowed_ad_groups)
                                   if allowed_ad_groups else None),
                allowed_user_groups=(list(allowed_user_groups)
                                     if allowed_user_groups else None),
            )
            session.add(tok)
            session.flush()
            return tok.to_dict()

    def get_embed_token(self, token: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            t = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.token == token,
            ).first()
            return t.to_dict() if t else None

    def list_embed_tokens(self, report_id: int,
                          report_type: str = "business") -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.report_id == report_id,
                ReportEmbedToken.report_type == report_type,
            ).order_by(ReportEmbedToken.created_at.desc()).all()
            return [r.to_dict() for r in rows]

    def revoke_embed_token(self, token: str) -> bool:
        with self.get_session() as session:
            t = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.token == token,
            ).first()
            if not t:
                return False
            t.is_active = False
            return True

    def increment_embed_token_access(self, token: str) -> None:
        with self.get_session() as session:
            t = session.query(ReportEmbedToken).filter(
                ReportEmbedToken.token == token,
            ).first()
            if t:
                t.access_count = (t.access_count or 0) + 1

    # ── Audit & Compliance (28) ───────────────────────────────────────────────

    def get_audit_log_filtered(self, username: str = None, action: str = None,
                               resource_type: str = None, date_from: str = None,
                               date_to: str = None, limit: int = 200,
                               offset: int = 0) -> List[Dict[str, Any]]:
        """Return audit entries with extended filters."""
        with self.get_session(read_only=True) as session:
            q = session.query(AuditLog).order_by(AuditLog.timestamp.desc())
            if username:
                q = q.filter(AuditLog.username == username)
            if action:
                q = q.filter(AuditLog.action == action)
            if resource_type:
                q = q.filter(AuditLog.resource_type == resource_type)
            if date_from:
                try:
                    from dateutil.parser import parse as _parse
                    q = q.filter(AuditLog.timestamp >= _parse(date_from))
                except Exception as e:
                    logger.debug("Failed to parse date_from '%s': %s", date_from, e)
            if date_to:
                try:
                    from dateutil.parser import parse as _parse
                    q = q.filter(AuditLog.timestamp <= _parse(date_to))
                except Exception as e:
                    logger.debug("Failed to parse date_to '%s': %s", date_to, e)
            return [r.to_dict() for r in q.offset(offset).limit(limit).all()]

    def get_audit_action_summary(self, days: int = 7,
                                 username: str = None) -> List[Dict[str, Any]]:
        """Aggregate audit-log counts by action over the last N days (Phase 102-G).

        Returns [{action: "execute_query", count: 42, last_seen: "..."}] ordered by count desc.
        A single GROUP BY query — cheap even on large audit tables (action is indexed).
        """
        days = max(1, min(int(days or 7), 365))
        from datetime import timedelta
        since = datetime.now(timezone.utc) - timedelta(days=days)
        with self.get_session(read_only=True) as session:
            from sqlalchemy import func
            q = session.query(
                AuditLog.action,
                func.count(AuditLog.id).label("count"),
                func.max(AuditLog.timestamp).label("last_seen"),
            ).filter(AuditLog.timestamp >= since)
            if username:
                q = q.filter(AuditLog.username == username)
            rows = q.group_by(AuditLog.action).order_by(
                func.count(AuditLog.id).desc()
            ).all()
            return [{
                "action":    r.action,
                "count":     int(r.count or 0),
                "last_seen": r.last_seen.isoformat() if r.last_seen else None,
            } for r in rows]

    def get_audit_distinct_values(self, days: int = 30) -> Dict[str, List[str]]:
        """Return distinct usernames/actions/resource_types for UI dropdowns (Phase 102-G).

        Scoped to the last N days so obsolete values fade out of dropdowns naturally.
        """
        days = max(1, min(int(days or 30), 365))
        from datetime import timedelta
        since = datetime.now(timezone.utc) - timedelta(days=days)
        with self.get_session(read_only=True) as session:
            from sqlalchemy import distinct
            usernames = [r[0] for r in session.query(distinct(AuditLog.username))
                         .filter(AuditLog.timestamp >= since).all() if r[0]]
            actions = [r[0] for r in session.query(distinct(AuditLog.action))
                       .filter(AuditLog.timestamp >= since).all() if r[0]]
            resource_types = [r[0] for r in session.query(distinct(AuditLog.resource_type))
                              .filter(AuditLog.timestamp >= since).all() if r[0]]
            return {
                "usernames":      sorted(usernames),
                "actions":        sorted(actions),
                "resource_types": sorted(resource_types),
            }

    def get_data_access_summary(self) -> List[Dict[str, Any]]:
        """Return per-user aggregate data access statistics."""
        with self.get_session(read_only=True) as session:
            from sqlalchemy import func
            # Aggregate from query_executions
            exec_rows = session.query(
                QueryExecution.executed_by,
                func.count(QueryExecution.id).label("total_executions"),
                func.max(QueryExecution.started_at).label("last_active"),
                func.sum(QueryExecution.total_rows).label("total_rows"),
            ).filter(QueryExecution.executed_by.isnot(None)).group_by(
                QueryExecution.executed_by
            ).all()
            # Aggregate download count from audit_log
            download_rows = session.query(
                AuditLog.username,
                func.count(AuditLog.id).label("export_count"),
            ).filter(AuditLog.action.in_(["download_file", "export_csv"])).group_by(
                AuditLog.username
            ).all()
            dl_map = {r.username: r.export_count for r in download_rows}
            result = []
            for r in exec_rows:
                result.append({
                    "username": r.executed_by,
                    "total_executions": r.total_executions or 0,
                    "last_active": r.last_active.isoformat() if r.last_active else None,
                    "total_rows": r.total_rows or 0,
                    "export_count": dl_map.get(r.executed_by, 0),
                })
            return result

    # -- Schedule run stats (Phase 38 anomaly detection) -------------------------

    def create_schedule_run_stats(self, schedule_id: int, row_count: int = 0,
                                  execution_seconds: float = 0.0,
                                  file_size_bytes: int = 0,
                                  anomaly_type: str = None,
                                  anomaly_details: dict = None) -> dict:
        with self.get_session() as session:
            entry = ScheduleRunStats(
                schedule_id=schedule_id,
                row_count=row_count,
                execution_seconds=execution_seconds,
                file_size_bytes=file_size_bytes,
                anomaly_type=anomaly_type,
                anomaly_details=anomaly_details,
            )
            session.add(entry)
            session.commit()
            session.refresh(entry)
            return entry.to_dict()

    def get_schedule_run_stats(self, schedule_id: int, limit: int = 20) -> list:
        with self.get_session(read_only=True) as session:
            entries = (session.query(ScheduleRunStats)
                       .filter_by(schedule_id=schedule_id)
                       .order_by(ScheduleRunStats.run_at.desc())
                       .limit(limit)
                       .all())
            return [e.to_dict() for e in entries]

    def list_anomalies(self, schedule_id: int = None, limit: int = 50) -> list:
        with self.get_session(read_only=True) as session:
            q = session.query(ScheduleRunStats).filter(
                ScheduleRunStats.anomaly_type.isnot(None)
            )
            if schedule_id:
                q = q.filter_by(schedule_id=schedule_id)
            entries = q.order_by(ScheduleRunStats.run_at.desc()).limit(limit).all()
            return [e.to_dict() for e in entries]

    # ── Checkpoint methods (Phase 41) ────────────────────────────────────

    def set_checkpoint(self, execution_id: str, state: str, query_config: dict,
                       executed_by: str = "", query_id: int = None,
                       timestamp: float = 0, owner: str = None) -> None:
        """Insert or update a checkpoint record for an execution.

        ``owner`` (2026-08-02): identity of the pod running the execution —
        recovery is scoped to it so one pod's boot can't fail another pod's
        in-flight queries.  Optional/nullable for backward compatibility.
        """
        import time as _time
        with self.get_session() as session:
            cp = ExecutionCheckpoint(
                execution_id=execution_id, state=state,
                query_config=query_config, executed_by=executed_by,
                query_id=query_id, timestamp=timestamp or _time.time(),
                owner=owner or None, heartbeat_at=_time.time(),
            )
            session.merge(cp)

    def update_checkpoint(self, execution_id: str, state: str, timestamp: float = 0) -> None:
        """Update the state of an existing checkpoint."""
        import time as _time
        with self.get_session() as session:
            cp = session.query(ExecutionCheckpoint).filter_by(execution_id=execution_id).first()
            if cp:
                cp.state = state
                cp.timestamp = timestamp or _time.time()

    def touch_checkpoints(self, execution_ids, timestamp: float) -> int:
        """The heartbeat: stamp ``heartbeat_at`` on these executions' checkpoints."""
        ids = [str(i) for i in execution_ids or []]
        if not ids:
            return 0
        with self.get_session() as session:
            return session.query(ExecutionCheckpoint).filter(
                ExecutionCheckpoint.execution_id.in_(ids)).update(
                    {ExecutionCheckpoint.heartbeat_at: float(timestamp)},
                    synchronize_session=False)

    def delete_checkpoint(self, execution_id: str) -> None:
        """Remove a checkpoint record (execution finished)."""
        with self.get_session() as session:
            session.query(ExecutionCheckpoint).filter_by(execution_id=execution_id).delete()

    def get_all_checkpoints(self) -> list:
        """Return all checkpoint records (used during recovery on startup)."""
        with self.get_session(read_only=True) as session:
            rows = session.query(ExecutionCheckpoint).all()
            return [{"execution_id": r.execution_id, "state": r.state,
                     "query_config": r.query_config, "executed_by": r.executed_by,
                     "query_id": r.query_id, "timestamp": r.timestamp,
                     "owner": getattr(r, "owner", None),
                     "heartbeat_at": getattr(r, "heartbeat_at", None)} for r in rows]

    def get_user_data_export(self, username: str) -> Dict[str, Any]:
        """Return all data related to a user for GDPR subject export."""
        with self.get_session(read_only=True) as session:
            saved_queries = session.query(SavedQuery).filter(
                SavedQuery.created_by == username
            ).all()
            sql_queries = session.query(SqlSavedQuery).filter(
                SqlSavedQuery.created_by == username
            ).all()
            executions = session.query(QueryExecution).filter(
                QueryExecution.executed_by == username
            ).order_by(QueryExecution.started_at.desc()).limit(10000).all()
            downloads = session.query(DownloadFile).filter(
                DownloadFile.created_by == username
            ).order_by(DownloadFile.created_at.desc()).limit(10000).all()
            schedules = session.query(Schedule).filter(
                Schedule.created_by == username
            ).all()
            audit = session.query(AuditLog).filter(
                AuditLog.username == username
            ).order_by(AuditLog.timestamp.desc()).limit(50000).all()
            return {
                "username": username,
                "saved_queries": [q.to_dict() for q in saved_queries],
                "sql_queries": [q.to_dict() for q in sql_queries],
                "executions": [e.to_dict() for e in executions],
                "downloads": [d.to_dict() for d in downloads],
                "schedules": [s.to_dict() for s in schedules],
                "audit_log": [a.to_dict() for a in audit],
            }


    # ── Lineage + Intelligence methods → core/db/mixin_lineage.py ──────
    # ── Datasets + Federation + Business Reports → core/db/mixin_datasets.py


    # ── REST Query Definitions (Phase 61) ────────────────────────────────────

    def create_rest_query_def(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            rqd = RestQueryDef(**kwargs)
            session.add(rqd)
            session.flush()
            session.refresh(rqd)
            return rqd.to_dict()

    def get_rest_query_def(self, rqd_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rqd = session.query(RestQueryDef).filter(RestQueryDef.id == rqd_id).first()
            return rqd.to_dict() if rqd else None

    def list_rest_query_defs(self, connection_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rqds = session.query(RestQueryDef).filter(
                RestQueryDef.connection_id == connection_id,
                RestQueryDef.is_active,
            ).order_by(RestQueryDef.name).all()
            return [r.to_dict() for r in rqds]

    def update_rest_query_def(self, rqd_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            rqd = session.query(RestQueryDef).filter(RestQueryDef.id == rqd_id).first()
            if not rqd:
                return None
            for k, v in kwargs.items():
                if hasattr(rqd, k):
                    setattr(rqd, k, v)
            session.flush()
            session.refresh(rqd)
            return rqd.to_dict()

    def delete_rest_query_def(self, rqd_id: int) -> bool:
        with self.get_session() as session:
            rqd = session.query(RestQueryDef).filter(RestQueryDef.id == rqd_id).first()
            if not rqd:
                return False
            session.delete(rqd)
            return True

    # ── Phase 75: Published Views API ────────────────────────────────────────

    @staticmethod
    def _compute_query_hash(query_config: dict) -> str:
        """SHA-256 of canonicalised query_config JSON (Phase 98-D)."""
        import hashlib
        import json
        return hashlib.sha256(
            json.dumps(query_config, sort_keys=True, default=str).encode()
        ).hexdigest()

    def create_published_view(self, **kwargs) -> Dict[str, Any]:
        # Phase 98-D: compute initial query_hash and set version=1
        if "query_config" in kwargs and "query_hash" not in kwargs:
            kwargs["query_hash"] = self._compute_query_hash(kwargs["query_config"])
        kwargs.setdefault("version", 1)
        with self.get_session() as session:
            pv = PublishedView(**kwargs)
            session.add(pv)
            session.flush()
            session.refresh(pv)
            return pv.to_dict()

    def _with_effective_params(self, views: List[Dict[str, Any]], *,
                               report_db: Any = None) -> List[Dict[str, Any]]:
        """AQD-04 (2026-09-23) -- a view over a business report accepts the
        parameters of the report version it SERVES, not the ones it had at
        publish time.

        The publish-time snapshot (FB-25) meant a required parameter added to
        the report afterwards deadlocked the view: its parser did not know the
        name, the report refused without it.  Every reader of a published view
        comes through these three methods, so the inheritance is applied here
        once (``core.published_view_params``, the same function the publish
        uses) and no serving route can see the stale snapshot.  One lookup per
        distinct report, not per view.

        ``report_db`` (2026-10-03): the manager the report rows are resolved
        through -- ``get_published_view_by_slug`` passes one answering from
        the rows it read with the view (``core.reports.preloaded``), so the
        served parameters cost no further read.
        """
        from core.published_view_params import (
            effective_view_params, served_report_parameters,
        )
        report_ids = {v.get("business_report_id") for v in views
                      if v.get("source_type") == "business_report"
                      and v.get("business_report_id")}
        if not report_ids:
            return views
        # The parameters of the version the view SERVES (the published
        # snapshot), not the author's draft -- see served_report_parameters.
        # Resolved outside any session: resolving a snapshot may lazily
        # backfill a version row.  A lookup that FAILS leaves the stored
        # definitions as they are and says so; it never blanks them.
        by_report: Dict[int, Optional[List[Dict[str, Any]]]] = {}
        for rid in report_ids:
            try:
                by_report[rid] = served_report_parameters(report_db or self, int(rid))
            except Exception as exc:
                logger.warning(
                    "[published-view] report %s: served parameters could not be "
                    "read (%s: %s) -- serving the view's stored definitions",
                    rid, type(exc).__name__, exc)
                by_report[rid] = None
        for v in views:
            rid = v.get("business_report_id")
            if v.get("source_type") != "business_report" or by_report.get(rid) is None:
                continue
            defs, bad = effective_view_params(v.get("param_definitions"), by_report[rid])
            if bad:
                # Refusing a READ would take the view's management screen down
                # with it, which is where the publisher fixes this.  The
                # publish/republish refuse these names with a 400.
                logger.warning(
                    "[published-view] view %s: report %s parameter(s) %s cannot be "
                    "view parameters (^[a-zA-Z_][a-zA-Z0-9_]*$); the view cannot "
                    "accept them", v.get("slug"), rid, bad)
            v["param_definitions"] = defs
        return views

    def get_published_view(self, view_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            pv = session.query(PublishedView).filter(PublishedView.id == view_id).first()
            row = pv.to_dict() if pv else None
        return self._with_effective_params([row])[0] if row else None

    def get_published_view_by_slug(self, slug: str) -> Optional[Dict[str, Any]]:
        """The ACTIVE view named ``slug`` -- the door every published-API
        request comes through.

        2026-10-03 -- ONE statement: the view, its business report (when it
        names one) and that report's current version, outer-joined.  It was
        one read for the view and two more for its served parameters, and
        the serving route then re-read the same report and version for the
        cache key's lifecycle identity, the principal-varying check and, on
        a miss, the handler (6 report reads in one request, measured live).
        The result is a :class:`core.reports.preloaded.ServedView` -- a
        ``dict`` -- carrying the two report rows, which
        ``core.reports.preloaded.served_db_for`` hands to every one of those
        decisions.  Nothing is kept across requests.
        """
        from sqlalchemy import and_
        from core.db.models import BusinessReportVersion
        from core.reports.preloaded import PreloadedReportRows, ServedView
        with self.get_session(read_only=True) as session:
            hit = (
                session.query(PublishedView, BusinessReport, BusinessReportVersion)
                .outerjoin(BusinessReport,
                           BusinessReport.id == PublishedView.business_report_id)
                .outerjoin(BusinessReportVersion, and_(
                    BusinessReportVersion.report_id == BusinessReport.id,
                    BusinessReportVersion.is_current == True,  # noqa: E712
                ))
                .filter(PublishedView.slug == slug, PublishedView.is_active)
                # the newest current version, as get_current_business_report_version
                .order_by(BusinessReportVersion.version_no.desc())
                .first()
            )
            if not hit:
                return None
            pv, report, version = hit
            row = ServedView(pv.to_dict())
            if row.get("business_report_id"):
                row.report_rows = (int(row["business_report_id"]),
                                   report.to_dict() if report else None,
                                   version.to_dict() if version else None)
        report_db = None
        if row.report_rows:
            report_db = PreloadedReportRows(self, *row.report_rows)
        return self._with_effective_params([row], report_db=report_db)[0]

    def list_published_views(self, active_only: bool = True) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(PublishedView)
            if active_only:
                q = q.filter(PublishedView.is_active)
            rows = [pv.to_dict() for pv in q.order_by(PublishedView.name).all()]
        return self._with_effective_params(rows)

    def update_published_view(self, view_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            pv = session.query(PublishedView).filter(PublishedView.id == view_id).first()
            if not pv:
                return None
            # Phase 98-D: if query_config is being updated, recompute hash + bump version
            if "query_config" in kwargs and "query_hash" not in kwargs:
                new_hash = self._compute_query_hash(kwargs["query_config"])
                old_hash = pv.query_hash
                if new_hash != old_hash:
                    kwargs["query_hash"] = new_hash
                    kwargs["version"] = (pv.version or 1) + 1
            for k, v in kwargs.items():
                if hasattr(pv, k):
                    setattr(pv, k, v)
            session.flush()
            session.refresh(pv)
            return pv.to_dict()

    def deactivate_published_view(self, view_id: int) -> bool:
        with self.get_session() as session:
            pv = session.query(PublishedView).filter(PublishedView.id == view_id).first()
            if not pv:
                return False
            pv.is_active = False
            session.flush()
            return True

    # ── Phase 146-B: Logical Tables ─────────────────────────────────────────
    #
    # Class-based strategic pattern: DB CRUD lives on DatabaseManager
    # (matches every other model in the tree); higher-level resolution
    # + validation logic is encapsulated in
    # ``core/logical_table_service.LogicalTableService`` which
    # consumes these CRUD methods.  Keep CRUD purely I/O -- no
    # business logic here.

    def create_logical_table(
        self, logical_name: str, description: str = "",
        created_by: str = "",
    ) -> Dict[str, Any]:
        """Create a logical-table row.  Returns the created dict.
        Raises IntegrityError on duplicate logical_name."""
        with self.get_session() as session:
            lt = LogicalTable(
                logical_name=str(logical_name).strip(),
                description=description or None,
                created_by=created_by or None,
            )
            session.add(lt)
            session.flush()
            session.refresh(lt)
            return lt.to_dict()

    def get_logical_table(self, lt_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            lt = session.query(LogicalTable).filter(
                LogicalTable.id == int(lt_id),
            ).first()
            return lt.to_dict() if lt else None

    def get_logical_table_by_name(
        self, logical_name: str,
    ) -> Optional[Dict[str, Any]]:
        """Case-insensitive lookup by logical_name."""
        with self.get_session(read_only=True) as session:
            # Case-insensitive match: SQLite has no ILIKE portable
            # across dialects, so use ``func.lower`` on both sides.
            from sqlalchemy import func as _sa_func
            lt = session.query(LogicalTable).filter(
                _sa_func.lower(LogicalTable.logical_name)
                == str(logical_name).strip().lower(),
            ).first()
            return lt.to_dict() if lt else None

    def list_logical_tables(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [
                lt.to_dict()
                for lt in session.query(LogicalTable)
                                 .order_by(LogicalTable.logical_name)
                                 .all()
            ]

    def update_logical_table(
        self, lt_id: int, **kwargs,
    ) -> Optional[Dict[str, Any]]:
        # Whitelist mutable fields so a rogue caller can't overwrite id
        # or created_at.
        _allowed = {"logical_name", "description"}
        with self.get_session() as session:
            lt = session.query(LogicalTable).filter(
                LogicalTable.id == int(lt_id),
            ).first()
            if not lt:
                return None
            for k, v in kwargs.items():
                if k in _allowed:
                    setattr(lt, k, v)
            session.flush()
            session.refresh(lt)
            return lt.to_dict()

    def delete_logical_table(self, lt_id: int) -> bool:
        """Delete a logical table.  CASCADE drops bindings."""
        with self.get_session() as session:
            lt = session.query(LogicalTable).filter(
                LogicalTable.id == int(lt_id),
            ).first()
            if not lt:
                return False
            session.delete(lt)
            session.flush()
            return True

    # ── LogicalTableBinding CRUD ────────────────────────────────────────

    def create_logical_binding(
        self, logical_table_id: int, connection_id: int,
        physical_ref: str, created_by: str = "",
    ) -> Dict[str, Any]:
        """Create a per-connection binding.  UniqueConstraint on
        (logical_table_id, connection_id) means an upsert-style caller
        should update instead of re-create -- this method raises on
        duplicate."""
        with self.get_session() as session:
            b = LogicalTableBinding(
                logical_table_id=int(logical_table_id),
                connection_id=int(connection_id),
                physical_ref=str(physical_ref).strip(),
                created_by=created_by or None,
            )
            session.add(b)
            session.flush()
            session.refresh(b)
            return b.to_dict()

    def get_logical_binding(
        self, logical_table_id: int, connection_id: int,
    ) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            b = session.query(LogicalTableBinding).filter(
                LogicalTableBinding.logical_table_id == int(logical_table_id),
                LogicalTableBinding.connection_id == int(connection_id),
            ).first()
            return b.to_dict() if b else None

    def list_bindings_for_logical(
        self, logical_table_id: int,
    ) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [
                b.to_dict()
                for b in session.query(LogicalTableBinding)
                                .filter(
                                    LogicalTableBinding.logical_table_id
                                    == int(logical_table_id),
                                )
                                .order_by(LogicalTableBinding.connection_id)
                                .all()
            ]

    def list_bindings_for_connection(
        self, connection_id: int,
    ) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [
                b.to_dict()
                for b in session.query(LogicalTableBinding)
                                .filter(
                                    LogicalTableBinding.connection_id
                                    == int(connection_id),
                                )
                                .order_by(LogicalTableBinding.logical_table_id)
                                .all()
            ]

    def update_logical_binding(
        self, binding_id: int, **kwargs,
    ) -> Optional[Dict[str, Any]]:
        _allowed = {"physical_ref"}
        with self.get_session() as session:
            b = session.query(LogicalTableBinding).filter(
                LogicalTableBinding.id == int(binding_id),
            ).first()
            if not b:
                return None
            for k, v in kwargs.items():
                if k in _allowed:
                    setattr(b, k, v)
            session.flush()
            session.refresh(b)
            return b.to_dict()

    def delete_logical_binding(self, binding_id: int) -> bool:
        with self.get_session() as session:
            b = session.query(LogicalTableBinding).filter(
                LogicalTableBinding.id == int(binding_id),
            ).first()
            if not b:
                return False
            session.delete(b)
            session.flush()
            return True

    def upsert_logical_binding(
        self, logical_table_id: int, connection_id: int,
        physical_ref: str, created_by: str = "",
    ) -> Dict[str, Any]:
        """Idempotent create-or-update on (logical_table_id,
        connection_id).  Used by the bulk-add helper so operators can
        write "set bindings for these N connections" without pre-
        checking existence."""
        existing = self.get_logical_binding(logical_table_id, connection_id)
        if existing is None:
            return self.create_logical_binding(
                logical_table_id, connection_id, physical_ref, created_by,
            )
        return self.update_logical_binding(
            existing["id"], physical_ref=str(physical_ref).strip(),
        )

    # ── API Keys ─────────────────────────────────────────────────────────────

    def create_api_key(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            ak = ApiKey(**kwargs)
            session.add(ak)
            session.flush()
            session.refresh(ak)
            return ak.to_dict()

    def get_api_key(self, key_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            ak = session.query(ApiKey).filter(ApiKey.id == key_id).first()
            if not ak:
                return None
            d = ak.to_dict()
            d["encrypted_key"] = ak.encrypted_key  # include for admin reveal
            return d

    def get_api_key_by_hash(self, key_hash: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            ak = session.query(ApiKey).filter(ApiKey.key_hash == key_hash).first()
            return ak.to_dict() if ak else None

    def list_api_keys(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [ak.to_dict() for ak in session.query(ApiKey).order_by(ApiKey.created_at.desc()).all()]

    def api_key_exists_by_name(self, name: str, active_only: bool = True) -> bool:
        """BF-131: Check if an active API key with the given name exists (indexed query, not full scan)."""
        with self.get_session(read_only=True) as session:
            q = session.query(ApiKey.id).filter(ApiKey.name == name)
            if active_only:
                q = q.filter(ApiKey.is_active == True)  # noqa: E712
            return q.first() is not None

    def revoke_api_key_by_name(self, name: str) -> bool:
        """BF-132: Revoke an active API key by name. Returns True if a key was found and revoked."""
        with self.get_session() as session:
            ak = session.query(ApiKey).filter(ApiKey.name == name, ApiKey.is_active == True).first()  # noqa: E712
            if not ak:
                return False
            ak.is_active = False
            session.flush()
            return True

    def revoke_api_key(self, key_id: int) -> bool:
        with self.get_session() as session:
            ak = session.query(ApiKey).filter(ApiKey.id == key_id).first()
            if not ak:
                return False
            ak.is_active = False
            session.flush()
            return True

    def touch_api_key_usage(self, key_id: int) -> None:
        """Update last_used_at and increment usage_count (non-blocking)."""
        try:
            with self.get_session() as session:
                ak = session.query(ApiKey).filter(ApiKey.id == key_id).first()
                if ak:
                    ak.last_used_at = datetime.now(timezone.utc)
                    ak.usage_count = (ak.usage_count or 0) + 1
                    session.flush()
        except Exception:
            pass  # non-critical — don't fail the request

    # ── API Key Requests (self-service approval workflow) ───────────────────

    def create_api_key_request(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            req = ApiKeyRequest(**kwargs)
            session.add(req)
            session.flush()
            session.refresh(req)
            return req.to_dict()

    def get_api_key_request(self, request_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            req = session.query(ApiKeyRequest).filter(ApiKeyRequest.id == request_id).first()
            return req.to_dict() if req else None

    def list_api_key_requests(self, username: Optional[str] = None, status: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ApiKeyRequest)
            if username:
                q = q.filter(ApiKeyRequest.requested_by == username)
            if status:
                q = q.filter(ApiKeyRequest.status == status)
            return [r.to_dict() for r in q.order_by(ApiKeyRequest.created_at.desc()).limit(limit).all()]

    def update_api_key_request(self, request_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            req = session.query(ApiKeyRequest).filter(ApiKeyRequest.id == request_id).first()
            if not req:
                return None
            for k, v in kwargs.items():
                setattr(req, k, v)
            session.flush()
            session.refresh(req)
            return req.to_dict()

    def count_pending_api_key_requests(self) -> int:
        with self.get_session(read_only=True) as session:
            return session.query(ApiKeyRequest).filter(ApiKeyRequest.status == "pending").count()

    # ── API Access Log ───────────────────────────────────────────────────────

    def log_api_access(self, **kwargs) -> None:
        """Log ONE external API access, synchronously (the per-row path --
        ``published_views.access_log_mode = "sync"``).  The published API
        normally batches through ``core.access_log_batcher``."""
        try:
            with self.get_session() as session:
                session.add(ApiAccessLog(**kwargs))
                session.flush()
        except Exception as exc:
            # 2026-10-03 -- was ``pass``: a lost usage row was SILENT.
            logger.warning("[pv-access-log] access-log row LOST (sync write "
                           "failed: %s: %s)", type(exc).__name__, exc)

    def log_api_access_many(self, rows: List[Dict[str, Any]]) -> int:
        """Write a BATCH of access-log rows as one multi-row INSERT in one
        transaction (2026-10-03, ``core.access_log_batcher``).  Every row
        carries the same keys (``access_log_batcher.ROW_KEYS``).

        Retry safety, DECLARED: the INSERT is retried ONCE, on a fresh
        connection, only when it failed on a DEAD connection
        (``DBAPIError.connection_invalidated``) -- the transaction never
        reached the server's commit, so nothing can be written twice.  Any
        other error, and any error of the COMMIT itself (it may have
        landed), propagates: the caller counts the batch lost and says so.
        """
        if not rows:
            return 0
        from sqlalchemy import insert as _sa_insert
        from sqlalchemy.exc import DBAPIError as _DBAPIError
        stmt = _sa_insert(ApiAccessLog)

        def _quiet_rollback(trans):
            try:
                trans.rollback()
            except Exception as rb_exc:   # a dead connection cannot roll back
                logger.debug("[pv-access-log] rollback after a failed batch: %s", rb_exc)

        for attempt in (1, 2):
            with self.engine.connect() as conn:
                trans = conn.begin()
                try:
                    conn.execute(stmt, rows)
                except _DBAPIError as exc:
                    _quiet_rollback(trans)
                    if attempt == 1 and getattr(exc, "connection_invalidated", False):
                        logger.info("[pv-access-log] batch of %d hit a dead "
                                    "connection before commit -- retrying once "
                                    "on a fresh one", len(rows))
                        continue
                    raise
                except BaseException:
                    _quiet_rollback(trans)
                    raise
                trans.commit()          # an error HERE is ambiguous: not retried
                return len(rows)
        return 0                        # pragma: no cover - loop always returns/raises

    def list_api_access_logs(self, view_id: int, limit: int = 100) -> List[Dict[str, Any]]:
        # 2026-10-03 -- rows are written in batches off the request; write
        # what this process holds first, so a publisher reading the log sees
        # their own last call (another process's rows land within its flush
        # interval, published_views.access_log_flush_seconds).
        try:
            from core.access_log_batcher import flush_access_log
            flush_access_log(timeout=5.0)
        except Exception as exc:
            logger.warning("[pv-access-log] flush before read failed: %s", exc)
        with self.get_session(read_only=True) as session:
            logs = session.query(ApiAccessLog).filter(
                ApiAccessLog.view_id == view_id,
            ).order_by(ApiAccessLog.created_at.desc()).limit(limit).all()
            return [log.to_dict() for log in logs]

    # ── 2026-09-27: published-view SCHEMA versions (core/published_view_schema.py) ──

    def latest_pv_schema_version(self, view_id: int) -> Optional[Dict[str, Any]]:
        from core.db.models import PublishedViewSchemaVersion as _SV
        with self.get_session(read_only=True) as session:
            row = (session.query(_SV).filter(_SV.view_id == view_id)
                   .order_by(_SV.version_no.desc()).first())
            return row.to_dict() if row else None

    def list_pv_schema_versions(self, view_id: int, limit: int = 50) -> List[Dict[str, Any]]:
        from core.db.models import PublishedViewSchemaVersion as _SV
        with self.get_session(read_only=True) as session:
            rows = (session.query(_SV).filter(_SV.view_id == view_id)
                    .order_by(_SV.version_no.desc()).limit(limit).all())
            return [r.to_dict() for r in rows]

    def latest_pv_schema_versions(self, view_ids: List[int]) -> Dict[int, Dict[str, Any]]:
        """``{view_id: latest version dict}`` for the ids given -- one query,
        for the list route."""
        from core.db.models import PublishedViewSchemaVersion as _SV
        ids = [int(v) for v in (view_ids or []) if v is not None]
        if not ids:
            return {}
        out: Dict[int, Dict[str, Any]] = {}
        with self.get_session(read_only=True) as session:
            rows = (session.query(_SV).filter(_SV.view_id.in_(ids))
                    .order_by(_SV.view_id, _SV.version_no.desc()).all())
            for r in rows:
                if r.view_id not in out:
                    out[r.view_id] = r.to_dict()
        return out

    def add_pv_schema_version(self, view_id: int, *, columns: list, columns_hash: str,
                              changes: Optional[dict], reason: str,
                              changed_by: Optional[str] = None,
                              notified: Optional[dict] = None) -> Dict[str, Any]:
        from core.db.models import PublishedViewSchemaVersion as _SV
        with self.get_session() as session:
            last = (session.query(_SV.version_no).filter(_SV.view_id == view_id)
                    .order_by(_SV.version_no.desc()).first())
            row = _SV(view_id=view_id, version_no=(int(last[0]) + 1) if last else 1,
                      columns=list(columns or []), columns_hash=columns_hash,
                      changes=changes, reason=reason, changed_by=changed_by,
                      notified=notified)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def set_pv_schema_version_notified(self, version_id: int, notified: dict) -> None:
        from core.db.models import PublishedViewSchemaVersion as _SV
        with self.get_session() as session:
            row = session.query(_SV).filter(_SV.id == version_id).first()
            if row is not None:
                row.notified = notified

    def list_published_views_for_report(self, report_id: int) -> List[Dict[str, Any]]:
        """Every ACTIVE view sourced from ``report_id`` (source_type
        business_report)."""
        with self.get_session(read_only=True) as session:
            rows = (session.query(PublishedView)
                    .filter(PublishedView.business_report_id == report_id,
                            PublishedView.source_type == "business_report",
                            PublishedView.is_active == True)  # noqa: E712
                    .all())
            return [r.to_dict() for r in rows]

    def list_business_report_ids_for_dataset(self, dataset_id: int) -> List[int]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(BusinessReport.id)
                    .filter(BusinessReport.dataset_id == dataset_id).all())
            return [int(r[0]) for r in rows]

    def list_api_keys_for_view(self, view_id: int) -> List[Dict[str, Any]]:
        """Active keys that can CALL ``view_id`` -- by THE rule the gate
        applies (``core/published_api/consumers.key_can_call``: the explicit
        global marker or the view in the scope; an EMPTY scope grants NOTHING
        unless the legacy escape hatch is on).  Until 2026-10-17 this reader
        said an empty scope was EVERY view while the gate said none: the
        schema-change notices and "who can call this" named people who could
        call nothing.  ``scope`` is ``every_api`` | ``this_api`` (the old
        ``all`` / ``view`` spellings are gone with the disagreement)."""
        from core.published_api.consumers import keys_for_view
        with self.get_session(read_only=True) as session:
            rows = (session.query(ApiKey).filter(ApiKey.is_active == True)  # noqa: E712
                    .all())
            out = keys_for_view([ak.to_dict() for ak in rows], int(view_id))
            return out

    def cleanup_api_access_logs(self, retention_days: int = 90) -> int:
        """Delete access logs older than retention period. Returns count deleted."""
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        with self.get_session() as session:
            count = session.query(ApiAccessLog).filter(
                ApiAccessLog.created_at < cutoff,
            ).delete()
            return count

    # ── Phase 134: Query Performance Audit Log ──────────────────────────────

    def add_query_performance_log(self, data: dict) -> None:
        """Log a query performance record (fire-and-forget).

        Industrialization Phase 9: this is the ONE place every finished
        query's actual bytes-scanned telemetry already lands, so it
        doubles as the calibration-loop's write chokepoint (plan §Phase 9
        edge case: "actuals are stamped on the existing telemetry row, not
        a new per-request write path").  Best-effort + fail-open: the
        calibration fold runs in its OWN try/except so a calibration
        failure can never affect (or block) the performance-log write it
        rides on.
        """
        try:
            from core.db.models import QueryPerformanceLog
            with self.get_session() as session:
                session.add(QueryPerformanceLog(
                    execution_id=data.get("execution_id"),
                    username=data.get("username"),
                    connection_id=data.get("connection_id"),
                    tables=data.get("tables"),
                    duration_ms=data.get("duration_ms"),
                    files_listed=data.get("files_listed", 0),
                    files_after_partition_pruning=data.get("files_after_partition_pruning", 0),
                    files_after_footer_pruning=data.get("files_after_footer_pruning", 0),
                    files_downloaded=data.get("files_downloaded", 0),
                    bytes_downloaded=data.get("bytes_downloaded", 0),
                    bytes_from_cache=data.get("bytes_from_cache", 0),
                    rows_returned=data.get("rows_returned", 0),
                    cache_hit_rate=data.get("cache_hit_rate"),
                    partition_filters_used=data.get("partition_filters_used"),
                    source=data.get("source", "execute_api"),
                ))
                session.flush()
        except Exception:
            pass  # fire-and-forget
        self._phase9_fold_calibration_sample(data)

    def _phase9_fold_calibration_sample(self, data: dict) -> None:
        """Industrialization Phase 9 — peek the process-local passport
        registry for this execution (peek, not pop: other consumers, e.g.
        the Phase-2 job-queue bridge, still own popping it) and, when a
        usable estimate + a routed venue are both present, fold
        (estimate_bytes, actual_bytes) into the calibration EMA.  No-op
        when ``industrialization.cost_routing`` is OFF (checked inside
        ``calibration.record_actuals``) or when there's simply nothing to
        fold (no passport for this execution_id — the common case today).
        Fail-open: never raises, never affects the caller.
        """
        try:
            from core.industrialization import is_enabled as _ind_enabled
            if not _ind_enabled("cost_routing"):
                return   # one flag read and out -- byte-for-byte parity when OFF
            execution_id = data.get("execution_id")
            if not execution_id:
                return
            from core.industrialization import passport_registry as _preg
            pp_dict = _preg.peek(str(execution_id))
            if not isinstance(pp_dict, dict):
                return
            estimate = (pp_dict.get("estimate") or {})
            est_bytes = estimate.get("bytes")
            if not est_bytes:
                return
            venue = str(pp_dict.get("venue") or "")
            notes = pp_dict.get("notes") or {}
            bucket = str(notes.get("bucket") or "")
            table_prefix = str(notes.get("table_prefix") or "")
            if not bucket and not table_prefix:
                return
            actual_bytes = data.get("bytes_downloaded")
            if actual_bytes is None:
                return
            from core.industrialization.calibration import record_actuals
            record_actuals(
                self,
                bucket=bucket, table_prefix=table_prefix, venue=venue,
                estimate_bytes=int(est_bytes or 0),
                actual_bytes=int(actual_bytes or 0),
                is_spark_route=(venue == "spark_connect"),
            )
        except Exception:
            pass  # fail-open — calibration is telemetry, never a dependency

    def cleanup_query_performance_logs(self, retention_days: int = 90) -> int:
        """Delete performance logs older than retention period."""
        try:
            from core.db.models import QueryPerformanceLog
            cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
            with self.get_session() as session:
                count = session.query(QueryPerformanceLog).filter(
                    QueryPerformanceLog.created_at < cutoff,
                ).delete()
                return count
        except Exception:
            return 0

    # ── Phase 83A — Business Report Async Jobs ────────────────────────────────

    def create_br_async_job(self, execution_id: str, report_id: int,
                             created_by: Optional[str] = None) -> Dict[str, Any]:
        """Create a persistent async business report job record."""
        with self.get_session() as session:
            job = BusinessReportAsyncJob(
                id=execution_id, report_id=report_id,
                status="running", progress_pct=0, created_by=created_by,
            )
            session.add(job)
            session.flush()
            session.refresh(job)
            return job.to_dict()

    def update_br_async_job(self, execution_id: str, **kwargs) -> None:
        """Update any field on a business report async job."""
        with self.get_session() as session:
            job = session.query(BusinessReportAsyncJob).filter(
                BusinessReportAsyncJob.id == execution_id
            ).first()
            if not job:
                return
            for k, v in kwargs.items():
                if hasattr(job, k):
                    setattr(job, k, v)
            if kwargs.get("status") in ("completed", "failed", "cancelled"):
                job.completed_at = datetime.now(timezone.utc)
            session.flush()

    def get_br_async_job(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Get a business report async job by execution_id."""
        with self.get_session(read_only=True) as session:
            job = session.query(BusinessReportAsyncJob).filter(
                BusinessReportAsyncJob.id == execution_id
            ).first()
            return job.to_dict() if job else None

    def list_br_async_jobs(self, report_id: Optional[int] = None,
                            status: Optional[str] = None,
                            limit: int = 50,
                            created_by: Optional[str] = None
                            ) -> List[Dict[str, Any]]:
        """List business report async jobs, optionally filtered.

        SECURITY 2026-08-31: ``created_by`` restricts the result to one
        principal's jobs, the same way ``list_br_execution_history`` already
        does — a job row carries the report id and name, so an unscoped list
        tells any caller what everyone else is running.  Callers that serve a
        USER pass it; the system-wide orphan sweep deliberately does not,
        because reclaiming a stale job is not a per-user act.
        """
        with self.get_session(read_only=True) as session:
            q = session.query(BusinessReportAsyncJob)
            if report_id is not None:
                q = q.filter(BusinessReportAsyncJob.report_id == report_id)
            if status is not None:
                q = q.filter(BusinessReportAsyncJob.status == status)
            if created_by is not None:
                q = q.filter(BusinessReportAsyncJob.created_by == created_by)
            jobs = q.order_by(BusinessReportAsyncJob.created_at.desc()).limit(limit).all()
            return [j.to_dict() for j in jobs]

    def list_br_execution_history(self, report_id: int, page: int = 1,
                                    page_size: int = 20,
                                    created_by: Optional[str] = None) -> Dict[str, Any]:
        """Paginated execution history for a business report.

        SECURITY: when ``created_by`` is provided, results are restricted to
        executions that principal created.  The endpoint passes it for every
        non-owner/non-admin caller so a viewer of a published report cannot
        enumerate another user's ``execution_id`` (which would let them fetch
        that user's RLS-scoped cached rows).  Owner/admin pass ``None`` to see
        the full history.
        """
        with self.get_session(read_only=True) as session:
            q = session.query(BusinessReportAsyncJob).filter(
                BusinessReportAsyncJob.report_id == report_id,
            )
            if created_by is not None:
                q = q.filter(BusinessReportAsyncJob.created_by == created_by)
            total = q.count()
            offset = (page - 1) * page_size
            jobs = q.order_by(BusinessReportAsyncJob.created_at.desc()) \
                    .offset(offset).limit(page_size).all()
            return {
                "items": [j.to_dict() for j in jobs],
                "total": total,
                "page": page,
                "page_size": page_size,
                "total_pages": max(1, (total + page_size - 1) // page_size),
            }

    def delete_stale_br_async_jobs(self, ttl_seconds: int) -> int:
        """Delete completed/failed/cancelled jobs older than ttl_seconds. Returns count."""
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=ttl_seconds)
        with self.get_session() as session:
            count = session.query(BusinessReportAsyncJob).filter(
                BusinessReportAsyncJob.status.in_(["completed", "failed", "cancelled"]),
                BusinessReportAsyncJob.created_at < cutoff,
            ).delete(synchronize_session=False)
            return count

    def get_live_artifact_refs(self, *, execution_window_seconds: int,
                               instance_window_seconds: Optional[int],
                               ) -> Dict[str, Set[str]]:
        """2026-08-09 cross-pod completion #3 — the artifact cleaner's view of
        which execution artifacts are STILL REFERENCED and must not be
        deleted (deleting one is data loss for a live drill/paging session
        on ANOTHER pod).

        Three reference sources, each bounded so the exemption cannot
        become an unbounded disk leak:

        * ``federation_executions`` rows created within
          ``execution_window_seconds`` (or still ``running`` within 24 h) —
          sync BR / legacy report executions; ``/cube`` and the paged
          results endpoint resolve artifacts through these rows with no TTL
          of their own.
        * ``report_instances`` rows created within
          ``instance_window_seconds`` whose status is ready/stale and whose
          ``expires_at`` has not passed — the instance layer (de5dde60)
          serves artifacts for up to ``instance_max_age_seconds``.
          ``instance_window_seconds=None`` (D4, 2026-08-09 cross-feature
          review: ``instance_max_age_seconds=0`` = instances never age out)
          applies NO age bound — the exemption is then bounded by ROW
          LIFETIME instead (retention prune, ``expires_at``, status
          demotion): when the row dies, its artifact loses the exemption.
        * ``br_async_jobs`` rows (running/completed) created within
          ``execution_window_seconds`` — async BR retrieval requires the
          row, and the row itself is TTL-deleted by
          ``delete_stale_br_async_jobs``.

        Returns ``{"execution_ids": set[str], "paths": set[str]}``.
        Callers treat a RAISE as "references unknown" and must FAIL CLOSED
        (skip deletion), never fail open.
        """
        from sqlalchemy import and_, or_

        now = datetime.now(timezone.utc)
        exec_cutoff = now - timedelta(seconds=max(0, int(execution_window_seconds)))
        running_cutoff = now - timedelta(seconds=86400)   # stuck-'running' sanity bound
        inst_cutoff = (now - timedelta(seconds=max(0, int(instance_window_seconds)))
                       if instance_window_seconds is not None else None)

        exec_ids: Set[str] = set()
        paths: Set[str] = set()
        with self.get_session(read_only=True) as session:
            fe_rows = session.query(
                FederationExecution.execution_id,
                FederationExecution.output_path,
            ).filter(
                or_(
                    FederationExecution.created_at >= exec_cutoff,
                    and_(FederationExecution.status == "running",
                         FederationExecution.created_at >= running_cutoff),
                )
            ).all()
            ri_q = session.query(
                ReportInstance.execution_id,
                ReportInstance.artifact_path,
            ).filter(
                ReportInstance.status.in_(("ready", "stale")),
                or_(ReportInstance.expires_at.is_(None),
                    ReportInstance.expires_at > now),
            )
            if inst_cutoff is not None:
                ri_q = ri_q.filter(ReportInstance.created_at >= inst_cutoff)
            ri_rows = ri_q.all()
            job_rows = session.query(
                BusinessReportAsyncJob.id,
                BusinessReportAsyncJob.output_path,
            ).filter(
                BusinessReportAsyncJob.status.in_(("running", "completed")),
                BusinessReportAsyncJob.created_at >= exec_cutoff,
            ).all()
            # 2026-09-28 -- a SIGNED instance is evidence: its artifact is
            # exempt for as long as an ACTIVE sign-off references it, with
            # NO age, status or expires_at bound (the lock is a correctness
            # gate, not a cap).  Read from the sign-off rows themselves,
            # which copy the execution id and path, so the exemption holds
            # even if the instance row were somehow gone.  Revoking the
            # last sign-off returns the artifact to the ordinary windows.
            from core.db.models import ReportInstanceSignoff as _Signoff
            signed_rows = session.query(
                _Signoff.execution_id,
                _Signoff.artifact_path,
            ).filter(_Signoff.status == "active").all()

        for eid, path in (list(fe_rows) + list(ri_rows) + list(job_rows)
                          + list(signed_rows)):
            if eid:
                exec_ids.add(str(eid))
            if path:
                paths.add(str(path))
        return {"execution_ids": exec_ids, "paths": paths}

    # ── Phase 83B — Circuit Breaker State Persistence ────────────────────────

    def save_circuit_breaker_state(self, connection_id: int, state: str,
                                    failure_count: int, opened_at: Optional[Any],
                                    last_failure: Optional[Any],
                                    connection_name: str = "") -> None:
        """Upsert circuit breaker state for a connection."""
        try:
            from datetime import datetime as _dt, timezone as _tz
            opened_at_dt = None
            if opened_at:
                try:
                    opened_at_dt = _dt.fromtimestamp(opened_at, tz=_tz.utc)
                except Exception as e:
                    logger.debug("Failed to parse opened_at timestamp %s: %s", opened_at, e)
            last_failure_dt = None
            if last_failure:
                try:
                    last_failure_dt = _dt.fromtimestamp(last_failure, tz=_tz.utc)
                except Exception as e:
                    logger.debug("Failed to parse last_failure timestamp %s: %s", last_failure, e)
            with self.get_session() as session:
                existing = session.query(CircuitBreakerState).filter(
                    CircuitBreakerState.connection_id == connection_id
                ).first()
                if existing:
                    existing.state = state
                    existing.failure_count = failure_count
                    existing.opened_at = opened_at_dt
                    existing.last_failure = last_failure_dt
                    existing.connection_name = connection_name
                    existing.updated_at = _dt.now(_tz.utc)
                else:
                    session.add(CircuitBreakerState(
                        connection_id=connection_id, state=state,
                        failure_count=failure_count, opened_at=opened_at_dt,
                        last_failure=last_failure_dt, connection_name=connection_name,
                    ))
                session.flush()
        except Exception:
            pass  # non-critical

    def get_circuit_breaker_states(self) -> List[Dict[str, Any]]:
        """Return all non-CLOSED circuit breaker states."""
        try:
            with self.get_session(read_only=True) as session:
                rows = session.query(CircuitBreakerState).filter(
                    CircuitBreakerState.state != "CLOSED"
                ).all()
                result = []
                for r in rows:
                    result.append({
                        "connection_id": r.connection_id,
                        "state": r.state,
                        "failure_count": r.failure_count,
                        "opened_at": r.opened_at,
                        "last_failure": r.last_failure,
                        "connection_name": r.connection_name,
                        "updated_at": r.updated_at,
                    })
                return result
        except Exception:
            return []

    def delete_circuit_breaker_state(self, connection_id: int) -> None:
        """Remove circuit breaker state for a connection (on CLOSED transition)."""
        try:
            with self.get_session() as session:
                session.query(CircuitBreakerState).filter(
                    CircuitBreakerState.connection_id == connection_id
                ).delete()
                session.flush()
        except Exception:
            pass

    # ── Phase 83C — Scheduler Lock ────────────────────────────────────────────

    def try_acquire_scheduler_lock(self, worker_id: str,
                                    stale_threshold_seconds: int = 60) -> bool:
        """Try to acquire the scheduler lock. Returns True if acquired.

        2026-09-14 -- the STALE takeover had never worked.  ``heartbeat_at``
        is a naive ``DateTime`` column (PostgreSQL ``timestamp without time
        zone``; SQLite the same on the way out), ``stale_cutoff`` was
        timezone-aware, and Python refuses to order the two: ``TypeError:
        can't compare offset-naive and offset-aware datetimes``.  The bare
        ``except Exception: return False`` below then reported that as
        "another instance holds the lock" -- so after any holder died
        without its atexit release (kill -9, OOM, a failed liveness probe)
        NO pod ever ran APScheduler again: SOD, the queue worker and every
        cron daemon stayed off until someone deleted the row by hand.
        Found on the operator's machine: a row 74 minutes stale against a
        60-second threshold, and every restart logging "lock contended"
        forever.  A failed COMPARISON is a bug and is now logged as one;
        only a failed acquisition is "held".
        """
        try:
            now = datetime.now(timezone.utc)
            stale_cutoff = now - timedelta(seconds=stale_threshold_seconds)
            with self.get_session() as session:
                lock = session.query(SchedulerLock).filter(SchedulerLock.id == 1).first()
                if lock is None:
                    session.add(SchedulerLock(id=1, worker_id=worker_id))
                    session.flush()
                    return True
                hb = lock.heartbeat_at
                if hb is not None and hb.tzinfo is None:
                    # The column stores UTC (every writer passes an aware
                    # UTC value and the driver strips the zone); read it
                    # back as what it is.
                    hb = hb.replace(tzinfo=timezone.utc)
                if hb is None or hb < stale_cutoff:
                    lock.worker_id = worker_id
                    lock.acquired_at = now
                    lock.heartbeat_at = now
                    session.flush()
                    return True
                return False
        except Exception as exc:
            # Not acquiring is the SAFE direction, so the answer stays
            # False -- but a broken call must never be indistinguishable
            # from a held lock (that is exactly how the naive/aware
            # comparison hid for a year).
            logger.error(
                "try_acquire_scheduler_lock(%s) raised -- this is a BUG in "
                "the lock code or the DB, not a held lock: %s: %s",
                worker_id, type(exc).__name__, exc, exc_info=True)
            return False

    def release_scheduler_lock(self, worker_id: str) -> None:
        """Release the scheduler lock if held by this worker."""
        try:
            with self.get_session() as session:
                session.query(SchedulerLock).filter(
                    SchedulerLock.id == 1,
                    SchedulerLock.worker_id == worker_id,
                ).delete()
                session.flush()
        except Exception:
            pass

    def heartbeat_scheduler_lock(self, worker_id: str) -> None:
        """Update the heartbeat timestamp for the scheduler lock."""
        try:
            with self.get_session() as session:
                lock = session.query(SchedulerLock).filter(
                    SchedulerLock.id == 1,
                    SchedulerLock.worker_id == worker_id,
                ).first()
                if lock:
                    lock.heartbeat_at = datetime.now(timezone.utc)
                    session.flush()
        except Exception:
            pass

    # ── Phase 84 — NL Learning Engine ────────────────────────────────────────

    def record_nl_query(self, nl_query: str, generated_sql: Optional[str] = None,
                         intent: Optional[str] = None, schema_hash: Optional[str] = None,
                         username: Optional[str] = None,
                         connection_id: Optional[int] = None) -> Dict[str, Any]:
        """Record a new NL-to-SQL query to the history."""
        with self.get_session() as session:
            entry = NLQueryHistory(
                nl_query=nl_query, generated_sql=generated_sql, intent=intent,
                schema_hash=schema_hash, username=username, connection_id=connection_id,
            )
            session.add(entry)
            session.flush()
            session.refresh(entry)
            return entry.to_dict()

    def update_nl_query_feedback(self, history_id: int, was_edited: bool = False,
                                  executed_sql: Optional[str] = None,
                                  execution_success: Optional[bool] = None,
                                  feedback_score: Optional[int] = None) -> None:
        """Update feedback fields for an NL query history entry."""
        try:
            with self.get_session() as session:
                entry = session.query(NLQueryHistory).filter(
                    NLQueryHistory.id == history_id
                ).first()
                if not entry:
                    return
                entry.was_edited = was_edited
                if executed_sql is not None:
                    entry.executed_sql = executed_sql
                if execution_success is not None:
                    entry.execution_success = execution_success
                if feedback_score is not None:
                    entry.feedback_score = feedback_score
                session.flush()
        except Exception:
            pass

    def get_nl_query_history(self, limit: int = 1000,
                              username: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return NL query history, most recent first."""
        with self.get_session(read_only=True) as session:
            q = session.query(NLQueryHistory)
            if username:
                q = q.filter(NLQueryHistory.username == username)
            entries = q.order_by(NLQueryHistory.created_at.desc()).limit(limit).all()
            return [e.to_dict() for e in entries]

    def get_top_nl_patterns(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Return top NL patterns ordered by score DESC."""
        with self.get_session(read_only=True) as session:
            patterns = session.query(NLPattern).order_by(
                NLPattern.score.desc()
            ).limit(limit).all()
            return [p.to_dict() for p in patterns]

    def upsert_nl_synonym(self, user_term: str, schema_term: str,
                           column_id: Optional[int] = None) -> None:
        """Insert or increment score for a synonym mapping."""
        try:
            with self.get_session() as session:
                existing = session.query(NLSynonym).filter(
                    NLSynonym.user_term == user_term,
                    NLSynonym.schema_term == schema_term,
                ).first()
                if existing:
                    existing.score = (existing.score or 1.0) + 0.1
                    existing.hit_count = (existing.hit_count or 0) + 1
                else:
                    session.add(NLSynonym(
                        user_term=user_term, schema_term=schema_term,
                        column_id=column_id,
                    ))
                session.flush()
        except Exception:
            pass

    def get_nl_synonyms(self, user_term: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return NL synonyms, optionally filtered by user_term."""
        with self.get_session(read_only=True) as session:
            q = session.query(NLSynonym)
            if user_term:
                q = q.filter(NLSynonym.user_term == user_term)
            synonyms = q.order_by(NLSynonym.score.desc()).all()
            return [s.to_dict() for s in synonyms]

    def update_nl_pattern_score(self, pattern_id: int, delta: float) -> None:
        """Adjust score for an NL pattern."""
        try:
            with self.get_session() as session:
                pattern = session.query(NLPattern).filter(
                    NLPattern.id == pattern_id
                ).first()
                if pattern:
                    pattern.score = max(0.0, (pattern.score or 1.0) + delta)
                    session.flush()
        except Exception:
            pass

    def upsert_nl_pattern(self, pattern: str, template_sql: str,
                           intent: Optional[str] = None,
                           is_learned: bool = False) -> None:
        """Insert or update an NL pattern by (pattern, intent) key.
        Safe to call multiple times — uses upsert semantics (no duplicates).
        """
        try:
            with self.get_session() as session:
                existing = session.query(NLPattern).filter(
                    NLPattern.pattern == pattern
                ).first()
                if existing:
                    # Update template in case it changed; keep score/counts
                    existing.template_sql = template_sql
                    if intent:
                        existing.intent = intent
                else:
                    session.add(NLPattern(
                        pattern=pattern,
                        template_sql=template_sql,
                        intent=intent,
                        score=1.0,
                        is_learned=is_learned,
                    ))
                session.flush()
        except Exception:
            pass

    def delete_nl_pattern(self, pattern_id: int) -> bool:
        """Delete an NL pattern by id."""
        with self.get_session() as session:
            count = session.query(NLPattern).filter(
                NLPattern.id == pattern_id
            ).delete()
            return count > 0

    # ── Phase 87: System Account CRUD ────────────────────────────────────────

    def create_system_account(self, name: str, account_type: str,
                               username: str, password: str,
                               config: Optional[Dict[str, Any]] = None,
                               created_by: Optional[str] = None,
                               **vault_kwargs: Any) -> Dict[str, Any]:
        """Create a system account with encrypted password.

        Phase 154 (2026-06-25): ``**vault_kwargs`` accepts the optional
        vault-resolver fields (use_vault, secret_ref, secret_type,
        vault_auth_url, vault_role_name, vault_role_type,
        vault_secret_url, vault_rotate_url).  Each is set on the
        SystemAccount row via setattr ONLY when the model has the
        attribute -- silently drops unknown keys so an older alembic
        head doesn't reject a newer-payload caller.
        """
        from core.crypto import encrypt_value
        _ALLOWED_VAULT_FIELDS = {
            "use_vault", "secret_ref", "secret_type",
            "vault_auth_url", "vault_role_name", "vault_role_type",
            "vault_secret_url", "vault_rotate_url",
            # 2026-07-13 — ETL PARITY: AppRole / JWT-step-up fields.
            "vault_step_up_name", "vault_step_up_auth_url",
            "vault_approle_secret_id_url", "vault_approle_auth_url",
            "vault_role_id",
            # 2026-09-10 -- the account's ENVIRONMENT (plan v2 section 3.2).
            # The admin model accepted it and THIS set dropped it, so a
            # declared environment was stored as the fail-closed UNSPECIFIED
            # and the account was refused at fire time "until an operator
            # declares it" -- which they had.
            "environment",
        }
        with self.get_session() as session:
            acct = SystemAccount(
                name=name, account_type=account_type,
                username=username,
                password=encrypt_value(password),
                config=config, created_by=created_by,
            )
            for k, v in vault_kwargs.items():
                if k in _ALLOWED_VAULT_FIELDS and hasattr(acct, k):
                    setattr(acct, k, v)
            session.add(acct)
            session.flush()
            session.refresh(acct)
            d = acct.to_dict()
            d["password"] = "***"
            return d

    def get_system_account(self, account_id: int,
                           include_vault_refs: bool = False) -> Optional[Dict[str, Any]]:
        """Get system account with password MASKED — safe for API responses.

        ``include_vault_refs`` adds the saved vault ADDRESSES for the admin
        edit form (never the password or the AppRole role_id)."""
        with self.get_session(read_only=True) as session:
            acct = session.query(SystemAccount).filter(SystemAccount.id == account_id).first()
            if not acct:
                return None
            return acct.to_dict(include_vault_refs=include_vault_refs)

    def get_system_account_raw(self, account_id: int) -> Optional[Dict[str, Any]]:
        """Get system account with password DECRYPTED — internal use only.

        BF-407: explicitly catch sqlalchemy.exc.OperationalError so callers
        see a clear "system_accounts table missing" / "DB locked" / etc.
        instead of the raw SQLAlchemy `https://sqlalche.me/e/...` link
        that confuses production triage.
        """
        from core.crypto import decrypt_value
        from sqlalchemy.exc import OperationalError as _SqlOpErr, ProgrammingError as _SqlProgErr
        try:
            with self.get_session(read_only=True) as session:
                acct = session.query(SystemAccount).filter(SystemAccount.id == account_id).first()
                if not acct:
                    return None
                d = acct.to_dict(include_password=True)
                d["password"] = decrypt_value(d["password"])
                return d
        except (_SqlOpErr, _SqlProgErr) as exc:
            # Strip the cargo-cult SQLAlchemy URL so the actual error reads
            # plainly in the log.  Common causes:
            #   - "no such table: system_accounts" — migrations didn't run
            #   - "database is locked" — concurrent writer on SQLite
            #   - "unable to open database file" — PVC mount missing / RO
            _raw = str(exc.orig if hasattr(exc, "orig") and exc.orig else exc)
            _trim = _raw.split("(Background on this error at:")[0].strip()
            import logging as _logging
            _logging.getLogger("db.system_accounts").error(
                "[system-account-lookup] FAILED account_id=%d sqlite_error=%r — "
                "Check: (a) migrations ran on startup (look for 'system_accounts' "
                "in Base.metadata.create_all logs); (b) DB file is writable + on a "
                "PVC; (c) no other process is locking the SQLite WAL",
                account_id, _trim,
            )
            # Re-raise as a typed error the caller can catch cleanly.  Keep
            # the original exception chained for full debug detail.
            raise SystemAccountLookupError(
                f"system account {account_id} lookup failed: {_trim}"
            ) from exc

    # 2026-08-09 — removed a SECOND, DEAD ``get_system_account_by_name`` that
    # used to live here (Phase 154, returned the password DECRYPTED).  It was
    # shadowed by the masking definition ~60 lines below, so it had never run
    # since the day it was added; `core.qs_credentials.resolver` already
    # prefers ``get_system_account_by_name_raw`` and its own comment states
    # that "get_system_account_by_name MASKS on the real db_manager".  The
    # surviving pair (masked by name, `_raw` for decrypted) is the contract
    # every caller was already written against — deleting the shadowed copy
    # changes no behaviour, it only stops the file claiming two answers.

    def list_system_accounts(self, account_type: Optional[str] = None,
                              active_only: bool = True) -> List[Dict[str, Any]]:
        """List system accounts with passwords masked."""
        with self.get_session(read_only=True) as session:
            q = session.query(SystemAccount)
            if active_only:
                q = q.filter(SystemAccount.is_active)
            if account_type:
                q = q.filter(SystemAccount.account_type == account_type)
            accts = q.order_by(SystemAccount.name).all()
            return [a.to_dict() for a in accts]  # to_dict() masks password by default

    def update_system_account(self, account_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        """Update a system account. Password is re-encrypted if provided.

        2026-08-23 (P6 audit) — CREDENTIAL GUARD at the chokepoint: every
        read path returns ``password: "***"`` (to_dict), and this writer
        accepted that mask back, encrypting the literal ``***`` over the
        real credential.  The UI happened to filter it client-side — the
        one place the "never store the mask" fact lived.  A masked or
        empty password now means UNCHANGED (the connections sibling's
        semantics, api/connections_api.py:1016-1032), so no caller —
        UI regression, curl, future route — can destroy a credential by
        echoing what the API showed them.
        """
        from core.crypto import encrypt_value
        _pw = kwargs.get("password")
        if "password" in kwargs and (_pw is None or _pw == "***" or _pw == ""):
            kwargs.pop("password")
            logger.info("update_system_account(%s): masked/empty password "
                        "ignored — stored credential unchanged", account_id)
        with self.get_session() as session:
            acct = session.query(SystemAccount).filter(SystemAccount.id == account_id).first()
            if not acct:
                return None
            for key, val in kwargs.items():
                if key == "password":
                    val = encrypt_value(val)
                if hasattr(acct, key):
                    setattr(acct, key, val)
            session.flush()
            session.refresh(acct)
            return acct.to_dict()  # to_dict() masks password by default

    def delete_system_account(self, account_id: int) -> bool:
        """Delete a system account."""
        with self.get_session() as session:
            count = session.query(SystemAccount).filter(
                SystemAccount.id == account_id
            ).delete()
            return count > 0

    def get_system_account_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        """Look up system account by name — returns masked."""
        with self.get_session(read_only=True) as session:
            acct = session.query(SystemAccount).filter(SystemAccount.name == name).first()
            if not acct:
                return None
            return acct.to_dict()  # to_dict() masks password by default

    def get_system_account_by_name_raw(self, name: str) -> Optional[Dict[str, Any]]:
        """Look up system account by name with password DECRYPTED — internal use only."""
        from core.crypto import decrypt_value
        with self.get_session(read_only=True) as session:
            acct = session.query(SystemAccount).filter(SystemAccount.name == name).first()
            if not acct:
                return None
            d = acct.to_dict(include_password=True)
            d["password"] = decrypt_value(d["password"])
            return d

    def update_system_account_status(self, account_id: int,
                                      status: str, error: Optional[str] = None) -> None:
        """Update last_used_at, last_status, last_error for a system account."""
        try:
            with self.get_session() as session:
                acct = session.query(SystemAccount).filter(SystemAccount.id == account_id).first()
                if acct:
                    acct.last_used_at = datetime.now(timezone.utc)
                    acct.last_status = status
                    acct.last_error = error
                    session.flush()
        except Exception:
            pass

    # ── User Preferences (Phase 100) ──────────────────────────────────────────

    def get_user_preference(self, user_id: str, pref_key: str) -> Optional[str]:
        with self.get_session(read_only=True) as session:
            p = session.query(UserPreference).filter(
                UserPreference.user_id == user_id,
                UserPreference.pref_key == pref_key,
            ).first()
            return p.pref_value if p else None

    def set_user_preference(self, user_id: str, pref_key: str, pref_value: str) -> Dict[str, Any]:
        with self.get_session() as session:
            p = session.query(UserPreference).filter(
                UserPreference.user_id == user_id,
                UserPreference.pref_key == pref_key,
            ).first()
            if p:
                p.pref_value = pref_value
            else:
                p = UserPreference(user_id=user_id, pref_key=pref_key, pref_value=pref_value)
                session.add(p)
            session.flush()
            return p.to_dict()

    def get_user_preferences(self, user_id: str) -> Dict[str, str]:
        with self.get_session(read_only=True) as session:
            rows = session.query(UserPreference).filter(
                UserPreference.user_id == user_id
            ).all()
            return {r.pref_key: r.pref_value for r in rows}

    def delete_user_preference(self, user_id: str, pref_key: str) -> bool:
        with self.get_session() as session:
            p = session.query(UserPreference).filter(
                UserPreference.user_id == user_id,
                UserPreference.pref_key == pref_key,
            ).first()
            if not p:
                return False
            session.delete(p)
            return True

    # ── Phase 120: Agent Decision Audit Trail ─��────────────────────────────

    def create_agent_decision(self, data: Dict[str, Any]) -> Dict[str, Any]:
        with self.get_session() as session:
            row = AgentDecisionLog(
                agent_name=data["agent_name"],
                event_type=data["event_type"],
                execution_id=data.get("execution_id"),
                action=data["action"],
                reason=data["reason"],
                fix_applied=data.get("fix_applied"),
                confidence=data.get("confidence", 1.0),
                metadata_json=data.get("metadata_json"),
            )
            session.add(row)
            session.flush()
            return row.to_dict()

    def list_agent_decisions(self, limit: int = 100, agent_name: str = None) -> list:
        with self.get_session(read_only=True) as session:
            q = session.query(AgentDecisionLog).order_by(AgentDecisionLog.created_at.desc())
            if agent_name:
                q = q.filter(AgentDecisionLog.agent_name == agent_name)
            return [r.to_dict() for r in q.limit(limit).all()]

    def get_agent_stats(self) -> list:
        """Return agent decision stats as a flat list (frontend-compatible).

        Returns list of {agent_name, action, count} dicts, sorted by count desc.
        """
        with self.get_session(read_only=True) as session:
            rows = session.query(
                AgentDecisionLog.agent_name,
                AgentDecisionLog.action,
                sa_text("COUNT(*)")
            ).group_by(
                AgentDecisionLog.agent_name,
                AgentDecisionLog.action,
            ).all()
            return sorted(
                [{"agent_name": agent, "action": action, "count": count}
                 for agent, action, count in rows],
                key=lambda r: r["count"], reverse=True,
            )

    def get_agent_health(self) -> Dict[str, Dict[str, Any]]:
        """BF-352: per-agent health summary used by the admin UI status panel.

        Returns {agent_name: {last_decision_at, last_action, last_reason,
                              decisions_24h, errors_24h, success_rate}} —
        sourced entirely from agent_decisions so the endpoint is
        multi-pod safe (no in-memory state).

        Uses SQLAlchemy column-comparison expressions (NOT raw SQL CASE
        WHEN) so the same query runs on SQLite (boolean as int) AND
        PostgreSQL (native boolean) without dialect-specific tweaks.
        success IS NULL means "pending" — counted in total but not
        in either errors or successes.
        """
        from sqlalchemy import func
        cutoff_24h = datetime.now(timezone.utc) - timedelta(hours=24)
        out: Dict[str, Dict[str, Any]] = {}
        with self.get_session(read_only=True) as session:
            # Total decisions in last 24h (per agent)
            totals = session.query(
                AgentDecisionLog.agent_name,
                func.count(AgentDecisionLog.id),
            ).filter(
                AgentDecisionLog.created_at >= cutoff_24h,
            ).group_by(AgentDecisionLog.agent_name).all()
            # Errors (success=False) — separate query to avoid dialect-
            # sensitive CASE WHEN expressions
            errors = session.query(
                AgentDecisionLog.agent_name,
                func.count(AgentDecisionLog.id),
            ).filter(
                AgentDecisionLog.created_at >= cutoff_24h,
                AgentDecisionLog.success == False,  # noqa: E712
            ).group_by(AgentDecisionLog.agent_name).all()
            # Successes (success=True)
            successes = session.query(
                AgentDecisionLog.agent_name,
                func.count(AgentDecisionLog.id),
            ).filter(
                AgentDecisionLog.created_at >= cutoff_24h,
                AgentDecisionLog.success == True,   # noqa: E712
            ).group_by(AgentDecisionLog.agent_name).all()
            error_map = {n: int(c or 0) for n, c in errors}
            success_map = {n: int(c or 0) for n, c in successes}
            for name, total in totals:
                t = int(total or 0)
                e = error_map.get(name, 0)
                s = success_map.get(name, 0)
                # Success rate based on COMPLETED decisions only (excludes
                # pending success=NULL rows so a freshly-fired agent doesn't
                # show 0% before the outcome is recorded).
                completed = s + e
                out[name] = {
                    "decisions_24h": t,
                    "errors_24h":    e,
                    "successes_24h": s,
                    "pending_24h":   t - completed,
                    "success_rate":  (
                        round(s / completed * 100, 1) if completed else None
                    ),
                }
            # Latest decision per agent — separate query for compatibility
            # with sqlite (no DISTINCT ON).
            agents = session.query(AgentDecisionLog.agent_name).distinct().all()
            for (name,) in agents:
                latest = session.query(AgentDecisionLog).filter(
                    AgentDecisionLog.agent_name == name,
                ).order_by(AgentDecisionLog.created_at.desc()).first()
                if latest:
                    bucket = out.setdefault(name, {
                        "decisions_24h": 0, "errors_24h": 0,
                        "successes_24h": 0, "pending_24h": 0,
                        "success_rate": None,
                    })
                    bucket["last_decision_at"] = latest.created_at.isoformat() if latest.created_at else None
                    bucket["last_action"] = latest.action
                    bucket["last_reason"] = (latest.reason or "")[:200]
        return out

    def update_agent_decision(self, decision_id: int, success: bool) -> bool:
        """Mark an agent decision as succeeded/failed with completion timestamp."""
        with self.get_session() as session:
            row = session.get(AgentDecisionLog, decision_id)
            if not row:
                return False
            row.success = success
            row.completed_at = datetime.now(timezone.utc)
            return True

    def cleanup_agent_decisions(self, max_age_days: int = 30) -> int:
        """Delete agent decision log entries older than max_age_days."""
        from datetime import timedelta
        cutoff = datetime.now(timezone.utc) - timedelta(days=max_age_days)
        with self.get_session() as session:
            count = session.query(AgentDecisionLog).filter(
                AgentDecisionLog.created_at < cutoff
            ).delete()
            return count

    # ── Spark Connect session audit ───────────────────────────────────────

    def create_spark_connect_session(self, session_key: str, username: str,
                                     server_url: str, connection_id: Optional[int] = None) -> int:
        """Insert a new session audit row; returns row id."""
        with self.get_session() as db:
            row = SparkConnectSession(
                session_key=session_key,
                username=username,
                server_url=server_url,
                connection_id=connection_id,
                status="active",
            )
            db.add(row)
            db.flush()
            return row.id

    def close_spark_connect_session(self, session_key: str, close_reason: str = "shutdown",
                                    queries_executed: int = 0, total_rows: int = 0) -> None:
        """Mark session as closed in the audit table (fail-open: errors logged, not raised)."""
        try:
            with self.get_session() as db:
                row = db.query(SparkConnectSession).filter(
                    SparkConnectSession.session_key == session_key
                ).first()
                if row:
                    row.status = "closed"
                    row.closed_at = datetime.now(timezone.utc)
                    row.close_reason = close_reason
                    row.queries_executed = queries_executed
                    row.total_rows_returned = total_rows
        except Exception as _exc:
            import logging as _log
            _log.getLogger(__name__).warning("close_spark_connect_session DB write failed: %s", _exc)

    def get_spark_connect_sessions(self, username: Optional[str] = None,
                                   status: Optional[str] = None,
                                   limit: int = 100) -> list:
        """Return session audit rows, newest first."""
        with self.get_session() as db:
            q = db.query(SparkConnectSession)
            if username:
                q = q.filter(SparkConnectSession.username == username)
            if status:
                q = q.filter(SparkConnectSession.status == status)
            rows = q.order_by(SparkConnectSession.created_at.desc()).limit(limit).all()
            return [r.to_dict() for r in rows]

    # ── Phase 156 (2026-06-25) brain smarter ─────────────────────────

    def brain_memo_get(self, sql_hash: str, snapshot_id: str) -> Optional[dict]:
        """Phase 156.2: read a memoised pruned-file list.  Returns None
        on miss.  Bumps hit_count + last_hit_at on hit (fire-and-forget).
        """
        if not sql_hash or not snapshot_id:
            return None
        from core.db.models import BrainPruningMemo as _BPM
        try:
            with self.get_session() as db:
                row = db.query(_BPM).filter(
                    _BPM.sql_hash == sql_hash,
                    _BPM.snapshot_id == snapshot_id,
                ).first()
                if not row:
                    return None
                try:
                    files = json.loads(row.surviving_files or "[]")
                except Exception:
                    files = []
                # F4 guard (2026-08-22): rows persisted by the pre-fix
                # writer were silently TRUNCATED to 50,000 files while
                # surviving_count kept the true count — replaying such a
                # row serves a shorter file list as if complete: ROW LOSS.
                # A count/length mismatch is therefore a MISS, never a hit.
                if int(row.surviving_count or 0) != len(files):
                    import logging as _lg
                    _lg.getLogger(__name__).warning(
                        "[brain-memo] REFUSING memo row sql_hash=%s "
                        "snapshot=%s: surviving_count=%s but %d files "
                        "persisted (legacy truncation) — treating as a "
                        "miss so the walk recomputes the true list.",
                        sql_hash, snapshot_id, row.surviving_count,
                        len(files))
                    return None
                row.hit_count = (row.hit_count or 0) + 1
                row.last_hit_at = datetime.now(timezone.utc)
                db.commit()
                # F4: scan_meta rides INSIDE the existing pruning_breakdown
                # JSON column (no migration; Alembic is never auto-invoked
                # in this deployment, so a new column could not be relied
                # on).  Envelope: {"__breakdown__":…, "__scan_meta__":…}.
                _pb = row.pruning_breakdown
                _sm = None
                if isinstance(_pb, dict) and "__scan_meta__" in _pb:
                    _sm = _pb.get("__scan_meta__")
                    _pb = _pb.get("__breakdown__")
                return {
                    "sql_hash":          row.sql_hash,
                    "snapshot_id":       row.snapshot_id,
                    "bucket":            row.bucket,
                    "table_prefix":      row.table_prefix,
                    "surviving_files":   files,
                    "surviving_count":   row.surviving_count,
                    "pruning_breakdown": _pb,
                    "scan_meta":         _sm,
                    "hit_count":         row.hit_count,
                }
        except Exception:
            return None

    def brain_memo_put(self, *, sql_hash: str, snapshot_id: str,
                       bucket: str, table_prefix: str,
                       surviving_files: list, surviving_count: int,
                       pruning_breakdown: Optional[dict] = None,
                       scan_meta: Optional[dict] = None) -> None:
        """Phase 156.2: upsert a memoised pruned-file list.

        F4 (2026-08-22): ``scan_meta`` (join-key bounds, MoR delete-file
        lists, the completeness attestation) is stored inside the
        pruning_breakdown JSON column as an envelope — no migration, and
        this deployment never auto-runs Alembic."""
        if not sql_hash or not snapshot_id:
            return
        from core.db.models import BrainPruningMemo as _BPM
        _files_list = list(surviving_files or [])
        # F4 fix (2026-08-22): the old code TRUNCATED to [:50000] while
        # storing the full surviving_count — a silent lie a cross-process
        # replay would serve as row loss.  A size guard must REFUSE, not
        # truncate: skip the DB persist entirely (the in-process LRU still
        # holds the full entry; other pods just re-prune).
        if len(_files_list) > 50000:
            import logging as _lg
            _lg.getLogger(__name__).info(
                "[brain-memo] SKIP DB persist for sql_hash=%s snapshot=%s: "
                "%d survivors exceeds the 50,000 persist cap (was silently "
                "TRUNCATED before 2026-08-22 — a replay would lose rows).",
                sql_hash, snapshot_id, len(_files_list))
            return
        if scan_meta:
            pruning_breakdown = {"__breakdown__": pruning_breakdown,
                                 "__scan_meta__": scan_meta}
        try:
            # Phase 156 deep-dive R21 -- json.dumps with default=str so
            # an entry that smuggled in a datetime / UUID / set is
            # coerced rather than triggering silent persistence loss.
            files_json = json.dumps(_files_list, default=str)
        except Exception as _ser_exc:
            import logging as _lg
            _lg.getLogger(__name__).debug(
                "[brain-memo] serialize failed (skipping DB persist; "
                "in-process LRU still holds the entry): %s", _ser_exc,
            )
            return
        try:
            with self.get_session() as db:
                row = db.query(_BPM).filter(
                    _BPM.sql_hash == sql_hash,
                    _BPM.snapshot_id == snapshot_id,
                ).first()
                if row is None:
                    row = _BPM(
                        sql_hash=sql_hash, snapshot_id=snapshot_id,
                        bucket=bucket or "",
                        table_prefix=(table_prefix or "").rstrip("/"),
                        surviving_files=files_json,
                        surviving_count=int(surviving_count or 0),
                        pruning_breakdown=pruning_breakdown,
                    )
                    db.add(row)
                else:
                    row.bucket = bucket or row.bucket
                    row.table_prefix = (table_prefix or "").rstrip("/") or row.table_prefix
                    row.surviving_files = files_json
                    row.surviving_count = int(surviving_count or 0)
                    row.pruning_breakdown = pruning_breakdown
                db.commit()
        except Exception as _put_exc:
            # Phase 156 deep-dive R21 -- log at debug rather than total
            # silence so operators grepping for brain-memo can see when
            # persist fails (disk full, DB locked, schema drift).
            import logging as _lg
            _lg.getLogger(__name__).debug(
                "[brain-memo] DB persist failed (in-process LRU still "
                "holds the entry; survives until process restart): %s",
                _put_exc,
            )

    def brain_memo_invalidate_snapshot(self, snapshot_id: str) -> int:
        """Phase 156.2: drop every memo pinned to a snapshot.  Returns
        the count of deleted rows."""
        if not snapshot_id:
            return 0
        from core.db.models import BrainPruningMemo as _BPM
        try:
            with self.get_session() as db:
                deleted = db.query(_BPM).filter(
                    _BPM.snapshot_id == snapshot_id,
                ).delete(synchronize_session=False)
                db.commit()
                return int(deleted or 0)
        except Exception:
            return 0

    def brain_memo_evict_older_than(self, cutoff_iso: str) -> int:
        """Phase 156 cleanup daemon: drop rows whose last_hit_at (or
        created_at when last_hit_at is null) is older than cutoff."""
        from core.db.models import BrainPruningMemo as _BPM
        try:
            cutoff = datetime.fromisoformat(cutoff_iso)
        except Exception:
            return 0
        try:
            with self.get_session() as db:
                from sqlalchemy import or_ as _or, and_ as _and
                deleted = db.query(_BPM).filter(
                    _or(
                        _and(_BPM.last_hit_at != None,    # noqa: E711
                             _BPM.last_hit_at < cutoff),
                        _and(_BPM.last_hit_at == None,    # noqa: E711
                             _BPM.created_at < cutoff),
                    )
                ).delete(synchronize_session=False)
                db.commit()
                return int(deleted or 0)
        except Exception:
            return 0

    def brain_memo_stats(self) -> dict:
        """Phase 156: admin telemetry snapshot."""
        from core.db.models import BrainPruningMemo as _BPM
        from sqlalchemy import func as _f
        try:
            with self.get_session() as db:
                total = db.query(_f.count(_BPM.id)).scalar() or 0
                total_hits = db.query(_f.sum(_BPM.hit_count)).scalar() or 0
                return {
                    "entries":    int(total),
                    "total_hits": int(total_hits),
                }
        except Exception:
            return {"entries": 0, "total_hits": 0}

    def brain_route_outcome_record(self, *, sql_hash: str, bucket: str,
                                   table_prefix: str, engine: str,
                                   seconds: float, status: str = "completed",
                                   ema_alpha: float = 0.3) -> None:
        """Phase 156.3: record a route outcome.  EMA over wall-clock
        seconds per (sql_hash, table, engine).  Cheap upsert."""
        if not sql_hash or not engine:
            return
        # Phase 156 deep-dive R13 -- normalise engine so " single",
        # "single", and "SINGLE" don't create three separate rows.
        engine = engine.strip().lower()
        if not engine:
            return
        from core.db.models import BrainRouteOutcome as _BRO
        import math as _math
        try:
            try:
                seconds_f = float(seconds or 0.0)
            except Exception:
                return
            # Phase 156 deep-dive R12 -- clamp seconds.  Negative + NaN
            # + Inf would poison the EMA forever (one bad sample =>
            # every subsequent decision biased).  Drop the record
            # rather than persist garbage.
            if _math.isnan(seconds_f) or _math.isinf(seconds_f):
                return
            if seconds_f < 0:
                seconds_f = 0.0
            with self.get_session() as db:
                row = db.query(_BRO).filter(
                    _BRO.sql_hash == sql_hash,
                    _BRO.bucket == (bucket or ""),
                    prefix_matches(_BRO.table_prefix, table_prefix),
                    _BRO.engine == engine,
                ).first()
                if row is None:
                    row = _BRO(
                        sql_hash=sql_hash, bucket=bucket or "",
                        table_prefix=(table_prefix or "").rstrip("/"),
                        engine=engine,
                        ema_seconds=seconds_f,
                        sample_count=1,
                        last_seconds=seconds_f, last_status=status,
                    )
                    db.add(row)
                else:
                    a = float(ema_alpha or 0.3)
                    row.ema_seconds = (a * seconds_f
                                       + (1 - a) * (row.ema_seconds or 0.0))
                    row.sample_count = (row.sample_count or 0) + 1
                    row.last_seconds = seconds_f
                    row.last_status = status
                db.commit()
        except Exception:
            pass

    def brain_route_outcome_get(self, sql_hash: str, bucket: str,
                                table_prefix: str) -> Dict[str, dict]:
        """Phase 156.3: read prior outcomes for a SQL shape.  Returns
        ``{engine: {ema_seconds, sample_count, ...}}``.  Empty dict on
        miss."""
        if not sql_hash:
            return {}
        from core.db.models import BrainRouteOutcome as _BRO
        try:
            with self.get_session() as db:
                rows = db.query(_BRO).filter(
                    _BRO.sql_hash == sql_hash,
                    _BRO.bucket == (bucket or ""),
                    prefix_matches(_BRO.table_prefix, table_prefix),
                ).all()
                return {r.engine: r.to_dict() for r in rows}
        except Exception:
            return {}

    def brain_route_outcome_evict_older_than(self, cutoff_iso: str) -> int:
        """Phase 156 cleanup daemon."""
        from core.db.models import BrainRouteOutcome as _BRO
        try:
            cutoff = datetime.fromisoformat(cutoff_iso)
        except Exception:
            return 0
        try:
            with self.get_session() as db:
                deleted = db.query(_BRO).filter(
                    _BRO.last_seen_at < cutoff,
                ).delete(synchronize_session=False)
                db.commit()
                return int(deleted or 0)
        except Exception:
            return 0

    def brain_route_outcome_recent(self, limit: int = 50) -> list:
        """Phase 156: admin telemetry -- recently observed outcomes."""
        from core.db.models import BrainRouteOutcome as _BRO
        try:
            with self.get_session() as db:
                rows = db.query(_BRO).order_by(
                    _BRO.last_seen_at.desc(),
                ).limit(max(1, int(limit))).all()
                return [r.to_dict() for r in rows]
        except Exception:
            return []

    # ── 2026-07-15 Adaptive Freshness (audit Finding #2) ──────────────

    @staticmethod
    def _freshness_dt_to_epoch(dt) -> float:
        """Naive-vs-aware tolerant DateTime → epoch seconds (0.0 on None)."""
        if dt is None:
            return 0.0
        try:
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return float(dt.timestamp())
        except Exception:
            return 0.0

    def iceberg_freshness_get(self, bucket: str,
                              table_prefix: str) -> Optional[dict]:
        """Read the per-table freshness-reliability record.  Returns
        ``{"hint_lied_count": int, "last_anomaly_ts": epoch_float,
        "last_lied_ts": epoch_float}`` or None on miss.  Fail-safe:
        any error returns None (caller degrades to in-process state)."""
        if not bucket or not table_prefix:
            return None
        from core.db.models import IcebergFreshnessReliability as _IFR
        try:
            with self.get_session() as db:
                row = db.query(_IFR).filter(
                    _IFR.bucket == bucket,
                    prefix_matches(_IFR.table_prefix, table_prefix),
                ).first()
                if not row:
                    return None
                return {
                    "hint_lied_count": int(row.hint_lied_count or 0),
                    "last_anomaly_ts": self._freshness_dt_to_epoch(
                        row.last_anomaly_at),
                    "last_lied_ts":    self._freshness_dt_to_epoch(
                        row.last_lied_at),
                }
        except Exception:
            return None

    def iceberg_watcher_cert_put(self, bucket: str, table_prefix: str, *,
                                  observed_snapshot_id: Optional[str] = None,
                                  observed_metadata_key: Optional[str] = None,
                                  connection_id: Optional[int] = None,
                                  status: str = "ok",
                                  error: Optional[str] = None) -> bool:
        """Publish what the watcher just observed for one table.

        Called after EVERY poll -- changed or unchanged -- because the
        unchanged case is precisely the one the query path wants to hear
        about ("nothing moved, stop re-LISTing").

        NEVER raises and NEVER shares the caller's session.  The watcher's
        real work is cache invalidation; this is bookkeeping on top of it,
        and bookkeeping that can roll back real work is the 2026-08-20
        accelerator-index incident.  Returns True on write, False if the
        write was skipped or failed -- the watcher ignores the result.
        """
        if not bucket or not table_prefix:
            return False
        from core.db.models import IcebergWatcherCertificate as _IWC
        _prefix = canonical_prefix(table_prefix)
        try:
            now = datetime.now(timezone.utc)
            with self.get_session() as db:
                row = db.query(_IWC).filter(
                    _IWC.bucket == bucket,
                    prefix_matches(_IWC.table_prefix, _prefix),
                ).first()
                if row is None:
                    row = _IWC(bucket=bucket, table_prefix=_prefix)
                    db.add(row)
                row.connection_id = connection_id
                row.status = str(status or "ok")[:32]
                row.error = (str(error)[:500] if error else None)
                # Only advance the OBSERVATION on a good poll.  An errored
                # poll still stamps checked_at+status so the reader can see
                # the watcher is alive but unhappy, while the last good
                # snapshot id is left intact for diagnostics -- it must not
                # be trusted, and status!="ok" is what stops that.
                if status == "ok":
                    row.observed_snapshot_id = (
                        str(observed_snapshot_id)
                        if observed_snapshot_id is not None else None)
                    row.observed_metadata_key = (
                        str(observed_metadata_key)[:1024]
                        if observed_metadata_key else None)
                row.checked_at = now
                db.flush()
            return True
        except Exception as exc:
            logger.debug("[watcher-cert] put skipped for %s/%s "
                         "(fail-open): %s", bucket, _prefix, exc)
            return False

    def iceberg_watcher_cert_get(self, bucket: str,
                                 table_prefix: str) -> Optional[dict]:
        """Read one table's certificate, or None on miss/error.

        None means "no proof available" -- the reader must then do the
        capped LIST it does today.  Every failure mode therefore costs
        performance, never correctness.
        """
        if not bucket or not table_prefix:
            return None
        from core.db.models import IcebergWatcherCertificate as _IWC
        try:
            with self.get_session() as db:
                row = db.query(_IWC).filter(
                    _IWC.bucket == bucket,
                    prefix_matches(_IWC.table_prefix, table_prefix),
                ).first()
                if not row:
                    return None
                return {
                    "observed_snapshot_id":  row.observed_snapshot_id,
                    "observed_metadata_key": row.observed_metadata_key,
                    "status":                row.status,
                    "checked_at_epoch":      self._freshness_dt_to_epoch(
                        row.checked_at),
                    "connection_id":         row.connection_id,
                }
        except Exception:
            return None

    def iceberg_watcher_durable_state(self, *, cert_limit: int = 5000,
                                      change_limit: int = 50
                                      ) -> Optional[dict]:
        """2026-10-07 -- the watcher's DURABLE state, for the admin status
        route on whichever pod answers it.

        The watcher runs on the scheduler/worker pod; its in-process
        ``_LAST_TICK`` exists only there, so the API pod (which answers the
        admin screen in production) always showed ``ran_at: null,
        tables_polled: 0`` for a healthy watcher.  Every poll -- changed or
        not, ok or errored -- already stamps a certificate row, and every
        change already lands in ``iceberg_watcher_changes``; this reads both.

        ``None`` on a read failure (unknown -- never an empty "no tables").
        """
        from core.db.models import (IcebergWatcherCertificate as _IWC,
                                    IcebergWatcherChange as _IWCh)
        try:
            with self.get_session(read_only=True) as db:
                certs = (db.query(_IWC)
                         .order_by(_IWC.checked_at.desc())
                         .limit(max(1, int(cert_limit))).all())
                changes = (db.query(_IWCh)
                           .order_by(_IWCh.detected_at.desc())
                           .limit(max(1, int(change_limit))).all())
                out_c = []
                for r in certs:
                    d = r.to_dict()
                    d["checked_at_epoch"] = self._freshness_dt_to_epoch(
                        r.checked_at)
                    out_c.append(d)
                out_ch = []
                for r in changes:
                    d = r.to_dict()
                    d["detected_at_epoch"] = self._freshness_dt_to_epoch(
                        r.detected_at)
                    out_ch.append(d)
                return {"certificates": out_c, "changes": out_ch}
        except Exception as exc:
            logger.debug("[watcher-status] durable read failed: %s", exc)
            return None

    def iceberg_freshness_record(self, bucket: str, table_prefix: str, *,
                                 hint_lied: bool = False,
                                 anomaly: bool = False) -> None:
        """Upsert the per-table freshness-reliability record.

        ``hint_lied=True`` increments ``hint_lied_count`` (the resolved
        metadata pointer disagreed with newest-by-scan — the table is
        cross-checked permanently from then on).  ``anomaly=True`` stamps
        ``last_anomaly_at`` (Scan Ledger over/under-count).  Fail-safe:
        never raises."""
        if not bucket or not table_prefix or not (hint_lied or anomaly):
            return
        from core.db.models import IcebergFreshnessReliability as _IFR
        try:
            now = datetime.now(timezone.utc)
            with self.get_session() as db:
                row = db.query(_IFR).filter(
                    _IFR.bucket == bucket,
                    prefix_matches(_IFR.table_prefix, table_prefix),
                ).first()
                if row is None:
                    row = _IFR(
                        bucket=bucket,
                        table_prefix=(table_prefix or "").rstrip("/"),
                        hint_lied_count=0,
                    )
                    db.add(row)
                if hint_lied:
                    row.hint_lied_count = int(row.hint_lied_count or 0) + 1
                    row.last_lied_at = now
                if anomaly:
                    row.last_anomaly_at = now
                db.commit()
        except Exception as _fr_exc:
            import logging as _lg
            _lg.getLogger(__name__).debug(
                "[adaptive-freshness] reliability DB persist failed "
                "(in-process record still holds the signal): %s", _fr_exc,
            )

    # ── 2026-07-15 Prunability Profiles (audit Finding #3/#4) ─────────

    def iceberg_prunability_upsert(self, bucket: str, table_prefix: str,
                                   column_name: str, *,
                                   stats_coverage_pct: float,
                                   bounds_overlap_ratio: float,
                                   singleton_ratio: float,
                                   ndv_estimate: Optional[int] = None,
                                   ) -> Optional[dict]:
        """Running-average merge of one query's prunability observation
        into the per-(bucket, table_prefix, column) profile.

        Merge rule: ``new = (old * n + obs) / (n + 1)`` per ratio column,
        ``sample_count += 1``.  ``ndv_estimate`` (when provided) simply
        replaces the stored value — it comes from an authoritative scan,
        not a per-query estimate.

        Returns the MERGED row as a dict (so the caller can decide
        bloom-worthiness from accumulated evidence, not just this one
        query) or None on ANY error — fail-safe: a broken DB must never
        affect the query path.
        """
        if not bucket or not table_prefix or not column_name:
            return None
        from core.db.models import IcebergPrunabilityProfile as _IPP

        def _ratio(v) -> float:
            try:
                return min(1.0, max(0.0, float(v)))
            except (TypeError, ValueError):
                return 0.0

        try:
            _col = (str(column_name) or "").split(".")[-1].lower()
            if not _col:
                return None
            now = datetime.now(timezone.utc)
            with self.get_session() as db:
                row = db.query(_IPP).filter(
                    _IPP.bucket == bucket,
                    prefix_matches(_IPP.table_prefix, table_prefix),
                    _IPP.column_name == _col,
                ).first()
                if row is None:
                    row = _IPP(
                        bucket=bucket,
                        table_prefix=(table_prefix or "").rstrip("/"),
                        column_name=_col,
                        stats_coverage_pct=_ratio(stats_coverage_pct),
                        bounds_overlap_ratio=_ratio(bounds_overlap_ratio),
                        singleton_ratio=_ratio(singleton_ratio),
                        ndv_estimate=(int(ndv_estimate)
                                      if ndv_estimate is not None else None),
                        sample_count=1,
                    )
                    db.add(row)
                else:
                    n = max(0, int(row.sample_count or 0))
                    row.stats_coverage_pct = (
                        (float(row.stats_coverage_pct or 0.0) * n
                         + _ratio(stats_coverage_pct)) / (n + 1))
                    row.bounds_overlap_ratio = (
                        (float(row.bounds_overlap_ratio or 0.0) * n
                         + _ratio(bounds_overlap_ratio)) / (n + 1))
                    row.singleton_ratio = (
                        (float(row.singleton_ratio or 0.0) * n
                         + _ratio(singleton_ratio)) / (n + 1))
                    row.sample_count = n + 1
                    if ndv_estimate is not None:
                        row.ndv_estimate = int(ndv_estimate)
                    row.updated_at = now
                db.commit()
                db.refresh(row)
                return row.to_dict()
        except Exception as _pp_exc:
            import logging as _lg
            _lg.getLogger(__name__).debug(
                "[prunability] profile upsert failed (fail-safe, profile "
                "not persisted this query): %s", _pp_exc,
            )
            return None

    def iceberg_prunability_get(self, bucket: str, table_prefix: str,
                                column_names: Optional[List[str]] = None,
                                ) -> Dict[str, dict]:
        """Read prunability profiles for the given columns.  Returns
        ``{column_name_lower: profile_dict}``; ``{}`` on ANY error or
        when nothing is stored (fail-safe)."""
        if not bucket or not table_prefix or not column_names:
            return {}
        from core.db.models import IcebergPrunabilityProfile as _IPP
        try:
            _cols = [(str(c) or "").split(".")[-1].lower()
                     for c in column_names if c]
            if not _cols:
                return {}
            with self.get_session() as db:
                rows = db.query(_IPP).filter(
                    _IPP.bucket == bucket,
                    prefix_matches(_IPP.table_prefix, table_prefix),
                    _IPP.column_name.in_(_cols),
                ).all()
                return {r.column_name: r.to_dict() for r in rows}
        except Exception:
            return {}

    # ── 2026-07-15 Brain diagnostics (admin read-only list accessors) ─
    #
    # Additive, read-only, fail-soft ([] on ANY error).  They exist ONLY
    # to power the admin "Pruning Brain" diagnostics panel — they are
    # NEVER consulted by the query / pruning path, so they cannot change
    # any keep/drop verdict.

    def iceberg_prunability_list(self, bucket: Optional[str] = None,
                                 table_prefix: Optional[str] = None,
                                 limit: int = 200) -> List[dict]:
        """List recent prunability-profile rows (most-recently updated
        first) for the admin diagnostics panel.  Optional (bucket,
        table_prefix) narrowing; unfiltered otherwise.  Returns a list
        of ``to_dict()`` rows, ``[]`` on ANY error (fail-soft)."""
        from core.db.models import IcebergPrunabilityProfile as _IPP
        try:
            _lim = max(1, min(int(limit or 200), 2000))
            with self.get_session(read_only=True) as db:
                q = db.query(_IPP)
                if bucket:
                    q = q.filter(_IPP.bucket == bucket)
                if table_prefix:
                    q = q.filter(
                        prefix_matches(_IPP.table_prefix, table_prefix))
                rows = q.order_by(_IPP.updated_at.desc()).limit(_lim).all()
                return [r.to_dict() for r in rows]
        except Exception:
            return []

    def iceberg_freshness_list(self, limit: int = 200) -> List[dict]:
        """List per-table freshness-reliability rows for the admin
        diagnostics panel, most-recently-updated first.  Returns a list
        of ``to_dict()`` rows, ``[]`` on ANY error (fail-soft)."""
        from core.db.models import IcebergFreshnessReliability as _IFR
        try:
            _lim = max(1, min(int(limit or 200), 2000))
            with self.get_session(read_only=True) as db:
                rows = (db.query(_IFR)
                        .order_by(_IFR.updated_at.desc())
                        .limit(_lim).all())
                return [r.to_dict() for r in rows]
        except Exception:
            return []

    def iceberg_bloom_columns_present(self, bucket: str,
                                      table_prefix: str) -> Dict[str, dict]:
        """Return which columns already have bloom-sidecar rows for a
        (bucket, table_prefix), keyed by lower-cased column name:
        ``{col_lower: {"file_count": int, "last_scanned": iso|None,
        "table_name": str|None}}``.  Powers the built-vs-needed bloom
        coverage view.  ``{}`` on ANY error (fail-soft)."""
        if not bucket or not table_prefix:
            return {}
        from core.db.models import IcebergBloomSidecar as _IBS
        from sqlalchemy import func as _sa_func
        try:
            out: Dict[str, dict] = {}
            with self.get_session(read_only=True) as db:
                rows = (db.query(
                            _sa_func.lower(_IBS.column_name).label("col"),
                            _sa_func.count(_IBS.id).label("file_count"),
                            _sa_func.max(_IBS.scanned_at).label("last_scanned"),
                            _sa_func.max(_IBS.table_name).label("table_name"),
                        )
                        .filter(_IBS.bucket == bucket,
                                prefix_matches(_IBS.table_prefix, table_prefix))
                        .group_by(_sa_func.lower(_IBS.column_name))
                        .all())
                for r in rows:
                    _ls = r.last_scanned
                    out[str(r.col or "")] = {
                        "file_count":   int(r.file_count or 0),
                        "last_scanned": _ls.isoformat() if _ls else None,
                        "table_name":   r.table_name,
                    }
            return out
        except Exception:
            return {}

    # ── Phase 157 (2026-06-26) -- Report Permissions CRUD ────────────

    def user_groups_for_username(self, username: str) -> List[int]:
        """Phase 157 -- compact int-list helper used by the permissions
        chokepoint.  Mirrors list_groups_for_user but trims to ids
        only.  Fail-OPEN (empty list) so a lookup failure doesn't
        accidentally grant access."""
        if not username:
            return []
        try:
            rows = self.list_groups_for_user(username) or []
            return [int(r["id"]) for r in rows if r.get("id") is not None]
        except Exception:
            return []

    # BusinessReportGrant CRUD ------------------------------------------------

    def add_br_grant(self, *, report_id: int,
                     username: Optional[str], group_id: Optional[int],
                     level: str, granted_by: str,
                     grant_until: Optional[datetime] = None,
                     reason: Optional[str] = None) -> Dict[str, Any]:
        from core.db.models import BusinessReportGrant as _G
        with self.get_session() as db:
            row = _G(
                report_id=int(report_id), username=username,
                group_id=int(group_id) if group_id is not None else None,
                level=level, granted_by=granted_by,
                grant_until=grant_until, reason=reason,
            )
            db.add(row)
            db.commit()
            db.refresh(row)
            return row.to_dict()

    def list_br_grants(self, report_id: int) -> List[Dict[str, Any]]:
        from core.db.models import BusinessReportGrant as _G
        if not report_id:
            return []
        try:
            with self.get_session(read_only=True) as db:
                rows = db.query(_G).filter(
                    _G.report_id == int(report_id),
                ).order_by(_G.granted_at.desc()).all()
                return [r.to_dict() for r in rows]
        except Exception:
            return []

    def list_br_grants_for_user(self, username: str,
                                group_ids: Optional[List[int]] = None,
                                ) -> List[Dict[str, Any]]:
        """Phase 157 batch helper (2026-08-09, metadata-scale audit) — every
        grant whose subject is ``username`` OR one of ``group_ids``, in ONE
        query.  Lets list/search resolve a caller's grants once per REQUEST
        (``core.reports.authorization.resolve_viewer_context``) instead of
        once per report row.  Expiry (``grant_until``) is evaluated by the
        caller via ``_grant_is_active`` — same as ``list_br_grants``.
        Fail-OPEN to [] — grants are an additive access source."""
        from core.db.models import BusinessReportGrant as _G
        from sqlalchemy import or_
        gids = [int(g) for g in (group_ids or []) if g is not None]
        if not username and not gids:
            return []
        try:
            with self.get_session(read_only=True) as db:
                conds = []
                if username:
                    conds.append(_G.username == username)
                if gids:
                    conds.append(_G.group_id.in_(gids))
                rows = db.query(_G).filter(or_(*conds)).all()
                return [r.to_dict() for r in rows]
        except Exception:
            return []

    def get_br_grant(self, grant_id: int) -> Optional[Dict[str, Any]]:
        from core.db.models import BusinessReportGrant as _G
        try:
            with self.get_session(read_only=True) as db:
                row = db.get(_G, int(grant_id))
                return row.to_dict() if row else None
        except Exception:
            return None

    def delete_br_grant(self, grant_id: int) -> bool:
        from core.db.models import BusinessReportGrant as _G
        try:
            with self.get_session() as db:
                row = db.get(_G, int(grant_id))
                if not row:
                    return False
                db.delete(row)
                db.commit()
                return True
        except Exception:
            return False

    def list_br_grants_expired_before(self, when: datetime) -> List[Dict[str, Any]]:
        """Tier 3 cleanup tick -- return grants whose ``grant_until``
        is non-NULL and in the past relative to ``when``."""
        from core.db.models import BusinessReportGrant as _G
        try:
            with self.get_session(read_only=True) as db:
                rows = db.query(_G).filter(
                    _G.grant_until != None,    # noqa: E711
                    _G.grant_until < when,
                ).all()
                return [r.to_dict() for r in rows]
        except Exception:
            return []

    # BusinessReportAccessRequest CRUD ---------------------------------------

    def create_br_access_request(self, *, report_id: int,
                                  requester: str,
                                  requested_level: str = "view",
                                  reason: Optional[str] = None,
                                  ) -> Dict[str, Any]:
        from core.db.models import BusinessReportAccessRequest as _R
        with self.get_session() as db:
            row = _R(
                report_id=int(report_id), requester=requester,
                requested_level=requested_level, reason=reason,
                status="pending",
            )
            db.add(row)
            db.commit()
            db.refresh(row)
            return row.to_dict()

    def get_br_access_request(self, request_id: int) -> Optional[Dict[str, Any]]:
        from core.db.models import BusinessReportAccessRequest as _R
        try:
            with self.get_session(read_only=True) as db:
                row = db.get(_R, int(request_id))
                return row.to_dict() if row else None
        except Exception:
            return None

    def decide_br_access_request(self, *, request_id: int, status: str,
                                  decided_by: str,
                                  decision_note: Optional[str] = None,
                                  granted_id: Optional[int] = None,
                                  ) -> None:
        from core.db.models import BusinessReportAccessRequest as _R
        with self.get_session() as db:
            row = db.get(_R, int(request_id))
            if not row:
                return
            row.status = status
            row.decided_by = decided_by
            row.decided_at = datetime.now(timezone.utc)
            row.decision_note = decision_note
            if granted_id is not None:
                row.granted_id = int(granted_id)
            db.commit()

    def list_br_access_requests(self, report_id: Optional[int] = None,
                                 status: Optional[str] = None,
                                 limit: int = 100) -> List[Dict[str, Any]]:
        from core.db.models import BusinessReportAccessRequest as _R
        try:
            with self.get_session(read_only=True) as db:
                q = db.query(_R)
                if report_id is not None:
                    q = q.filter(_R.report_id == int(report_id))
                if status:
                    q = q.filter(_R.status == status)
                q = q.order_by(_R.created_at.desc()).limit(
                    max(1, min(int(limit), 500))
                )
                return [r.to_dict() for r in q.all()]
        except Exception:
            return []

    # BusinessReportCertificationRequest CRUD --------------------------------

    def create_br_cert_request(self, *, report_id: int, requested_by: str,
                                rationale: Optional[str] = None,
                                ) -> Dict[str, Any]:
        from core.db.models import BusinessReportCertificationRequest as _C
        with self.get_session() as db:
            row = _C(
                report_id=int(report_id), requested_by=requested_by,
                rationale=rationale, status="pending",
            )
            db.add(row)
            db.commit()
            db.refresh(row)
            return row.to_dict()

    def get_br_cert_request(self, request_id: int) -> Optional[Dict[str, Any]]:
        from core.db.models import BusinessReportCertificationRequest as _C
        try:
            with self.get_session(read_only=True) as db:
                row = db.get(_C, int(request_id))
                return row.to_dict() if row else None
        except Exception:
            return None

    def decide_br_cert_request(self, *, request_id: int, status: str,
                                reviewed_by: str,
                                review_note: Optional[str] = None) -> None:
        from core.db.models import BusinessReportCertificationRequest as _C
        with self.get_session() as db:
            row = db.get(_C, int(request_id))
            if not row:
                return
            row.status = status
            row.reviewed_by = reviewed_by
            row.reviewed_at = datetime.now(timezone.utc)
            row.review_note = review_note
            db.commit()

    def list_br_cert_requests(self, status: Optional[str] = None,
                               limit: int = 100) -> List[Dict[str, Any]]:
        from core.db.models import BusinessReportCertificationRequest as _C
        try:
            with self.get_session(read_only=True) as db:
                q = db.query(_C)
                if status:
                    q = q.filter(_C.status == status)
                q = q.order_by(_C.created_at.desc()).limit(
                    max(1, min(int(limit), 500))
                )
                return [r.to_dict() for r in q.all()]
        except Exception:
            return []

    def set_br_certified(self, *, report_id: int, certified: bool,
                          certified_by: Optional[str] = None) -> None:
        """Mirrors the existing certify endpoint's mutation but exposed
        as a chokepoint-callable helper."""
        from core.db.models import BusinessReport as _BR
        with self.get_session() as db:
            row = db.get(_BR, int(report_id))
            if not row:
                return
            row.is_certified = bool(certified)
            if certified:
                row.certified_by = certified_by
                row.certified_at = datetime.now(timezone.utc)
            else:
                row.certified_by = None
                row.certified_at = None
            db.commit()

    # BusinessReportPermissionEvent CRUD -------------------------------------

    def add_br_permission_event(self, *, report_id: int, event_type: str,
                                 actor: str,
                                 subject: Optional[str] = None,
                                 metadata: Optional[Dict[str, Any]] = None,
                                 ) -> None:
        from core.db.models import BusinessReportPermissionEvent as _E
        try:
            with self.get_session() as db:
                row = _E(
                    report_id=int(report_id), event_type=event_type,
                    actor=actor, subject=subject,
                    metadata_json=metadata or {},
                )
                db.add(row)
                db.commit()
        except Exception as exc:
            import logging as _lg
            _lg.getLogger(__name__).debug(
                "[br-perm] audit event persist failed (non-fatal): %s",
                exc,
            )

    def list_br_permission_events(self, report_id: int,
                                   limit: int = 200,
                                   ) -> List[Dict[str, Any]]:
        from core.db.models import BusinessReportPermissionEvent as _E
        try:
            with self.get_session(read_only=True) as db:
                rows = db.query(_E).filter(
                    _E.report_id == int(report_id),
                ).order_by(_E.created_at.desc()).limit(
                    max(1, min(int(limit), 1000))
                ).all()
                return [r.to_dict() for r in rows]
        except Exception:
            return []

    # Convenience -- share + embed token lists used by the
    # permissions chokepoint to render the "Who has access" panel.

    def list_br_share_tokens(self, report_id: int) -> List[Dict[str, Any]]:
        from core.db.models import BusinessReportShareToken as _T
        try:
            with self.get_session(read_only=True) as db:
                rows = db.query(_T).filter(
                    _T.report_id == int(report_id),
                ).order_by(_T.created_at.desc()).all()
                return [r.to_dict() for r in rows]
        except Exception:
            return []

    def list_br_embed_tokens(self, report_id: int) -> List[Dict[str, Any]]:
        try:
            from core.db.models import ReportEmbedToken as _T
        except ImportError:
            return []
        try:
            with self.get_session(read_only=True) as db:
                rows = db.query(_T).filter(
                    _T.report_id == int(report_id),
                ).order_by(_T.created_at.desc()).all()
                return [r.to_dict() for r in rows]
        except Exception:
            return []


# ─────────────────────────────────────────────────────────────────────────────
# BF-393 — shared DB-manager accessor
# ─────────────────────────────────────────────────────────────────────────────
#
# A small number of internal modules (worker pods, scheduled jobs, etc.) need
# a DB handle without going through FastAPI dependency injection.  Use this
# accessor instead of instantiating a new ``DatabaseManager`` per call site —
# it lazy-initialises ONE singleton off the same DATABASE_URL the coordinator
# is using and re-uses the connection pool.
#
# Coordinator code (main.py) sets ``_GLOBAL_DB_MANAGER`` at startup; non-FastAPI
# code calls ``get_db_manager()`` and gets whatever the coordinator already has.
# In standalone workers (no main.py boot) the accessor falls through to a
# fresh ``DatabaseManager()`` so unit tests + smoke scripts work too.

_GLOBAL_DB_MANAGER: Optional["DatabaseManager"] = None


def set_db_manager(mgr: "DatabaseManager") -> None:
    """Publish the coordinator's DatabaseManager so background workers /
    scheduled jobs / agent code can pick it up via ``get_db_manager()``.
    Called from ``main.py`` once at startup."""
    global _GLOBAL_DB_MANAGER
    _GLOBAL_DB_MANAGER = mgr


def get_db_manager() -> Optional["DatabaseManager"]:
    """Return the process-wide DatabaseManager.

    Lazy-initialises a fresh one from environment / config if nobody has
    published one yet — that way worker pods + scripts that don't boot
    main.py still get a working DB handle.  Returns ``None`` only when
    the config is misconfigured (caller must handle).
    """
    global _GLOBAL_DB_MANAGER
    if _GLOBAL_DB_MANAGER is not None:
        return _GLOBAL_DB_MANAGER
    try:
        import os
        db_url = os.environ.get("DATABASE_URL", "") or ""
        if db_url:
            _GLOBAL_DB_MANAGER = DatabaseManager(db_url=db_url)
        else:
            _GLOBAL_DB_MANAGER = DatabaseManager()
        return _GLOBAL_DB_MANAGER
    except Exception as exc:
        import logging as _log
        _log.getLogger(__name__).warning(
            "get_db_manager(): lazy init failed: %s", exc,
        )
        return None


class DbHandleUnavailable(RuntimeError):
    """No DatabaseManager in this process: nothing bound one and the
    process-wide manager could not be built (database misconfigured).  An
    AVAILABILITY statement -- a route maps it to 503 with this text, never
    to the generic 500."""


def resolve_db_manager(bound: Any = None, *, required: bool = False
                       ) -> Optional["DatabaseManager"]:
    """THE accessor for a module-level db handle (2026-10-08).

    THE CLASS THIS CLOSES.  Daemon modules keep a module global
    (``_db_manager`` / ``_DB_MANAGER``) that only their START function
    binds -- ``iceberg_manifest_watcher.start_background``,
    ``custom_jobs.init_custom_jobs``, ``scheduler.init_scheduler``, ... --
    and are ALSO reached by admin routes on a pod that never starts them.
    In production the api pod answers every ``/api/admin/*`` route and the
    scheduler pod owns the daemons, so the route found ``None``: ``PATCH
    /api/admin/iceberg-watcher/settings/...`` was a 500 and ``GET`` served
    registry defaults instead of the stored rows (found live 2026-10-08);
    ``POST /api/admin/custom-jobs/{id}/run-now`` raised "DB manager not
    wired".  ``core.query_diagnostic_store`` was fixed for the same class
    on 2026-09-06 with a private copy of the rule.

    The rule, in ONE place: what a start bound here wins (a test's fake,
    a worker's explicit handle); otherwise the process-wide manager
    ``main.py`` / ``scheduler_worker.py`` publish, which is the SAME rows
    the daemon pod reads and writes.  Each module reads its handle through
    a one-line ``_db()`` that delegates here; the guard
    ``tests/test_db_handle_one_accessor_2026_10_08.py`` refuses a bare
    read of a start-bound handle anywhere else.

    ``required=True`` raises :class:`DbHandleUnavailable` instead of
    returning None, for a write that must say why it did not happen.
    """
    if bound is not None:
        return bound
    mgr = get_db_manager()
    if mgr is None and required:
        raise DbHandleUnavailable(
            "no DatabaseManager in this process -- nothing bound one and "
            "get_db_manager() could not build the process-wide manager "
            "(database misconfigured); the setting was not persisted")
    return mgr
