"""``PutKafkaStage`` — NiFi ``PublishKafkaRecord`` equivalent.

Publishes one message per row from an input file (csv / parquet / json)
to a Kafka topic.

Connection model: matches the rest of QueryStudio — the user picks a
QueryStudio connection by id; the underlying Kafka bootstrap_servers
+ SASL config live on the connection (system-account credentials).
This keeps raw credentials OUT of the DAG config.

Two output modes:
* ``message_template``  — Jinja-style {col} substitution per row
* ``json_row``           — serialize the whole row as JSON

Idempotency: ``unsafe`` — re-running republishes every row.  The
``key_column`` config nominates a per-row key; downstream consumers
that deduplicate by key are recommended.
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_SINK, IDEMPOTENT_UNSAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register
from core.dataflow.runnability import Runnability, probe_python_package

#: kafka-python is extras-only (``requirements-extras/kafka.txt``); the
#: default image does not carry it.  Named once so the manifest reason,
#: validate_config and the execute-time error agree on what to install.
_KAFKA_INSTALL_HINT = "pip install -r requirements-extras/kafka.txt"


_READERS = {
    "csv":     "read_csv_auto",
    "parquet": "read_parquet",
    "json":    "read_json_auto",
}


@register
class PutKafkaStage(BaseStage):
    NAME = "put_kafka"
    DISPLAY_NAME = "Publish to Kafka"
    CATEGORY = CATEGORY_SINK
    IDEMPOTENCY = IDEMPOTENT_UNSAFE
    DESCRIPTION = ("Publish each row of an input file to a Kafka topic.  "
                    "Uses a QueryStudio Kafka connection (system-account "
                    "creds resolved at runtime, never in the DAG).")
    COST_SECONDS = 20
    COST_CENTS = 0
    CONFIG_SCHEMA = {
        "input_path":        {"type": "string",
                                "description": "Source file (supports {key})."},
        "input_format":      {"type": "string", "enum": ["csv", "parquet", "json"]},
        "connection_id":     {"type": "integer", "lookup": "connections",
                                "description": "QueryStudio Kafka connection id."},
        "topic":              {"type": "string", "description": "Target topic name."},
        "key_column":         {"type": "string",
                                "description": "Column whose value is used as the Kafka key. "
                                                "Optional — null means round-robin."},
        "value_mode":         {"type": "string", "enum": ["json_row", "template"]},
        "message_template":   {"type": "string",
                                "description": "When value_mode='template', Python-style "
                                                "{col} format string."},
        "batch_size":         {"type": "integer", "minimum": 1,
                                "description": "Rows to buffer before producer.flush() — default 5000."},
        "max_messages":       {"type": "integer", "minimum": 1,
                                "description": "Optional cap (testing/sampling).  Omit for all rows."},
    }

    @classmethod
    def runnability(cls) -> Runnability:
        """2026-09-15 — ``kafka-python`` is an extra; the default image
        cannot run this stage and the palette must say so before a run."""
        return probe_python_package("kafka", "kafka-python", _KAFKA_INSTALL_HINT)

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        # The runnability gate first: a stage this image cannot run is
        # refused at save / dry-run, not discovered at execute.
        errs: List[str] = cls.runnability().problems(cls.NAME)
        for k in ("input_path", "topic"):
            if not (config.get(k) or "").strip():
                errs.append(f"{k} is required")
        if not config.get("connection_id"):
            errs.append("connection_id is required")
        vm = (config.get("value_mode") or "json_row").lower()
        if vm not in ("json_row", "template"):
            errs.append("value_mode must be 'json_row' or 'template'")
        if vm == "template" and not (config.get("message_template") or "").strip():
            errs.append("message_template is required when value_mode='template'")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        def _fmt(s: str) -> str:
            try:
                return s.format(**ctx.run_context)
            except Exception:
                return s

        input_path = _fmt(ctx.get_config("input_path") or "")
        if not os.path.exists(input_path):
            return StageResult.failed(error=f"input not found: {input_path}")

        input_format = (ctx.get_config("input_format")
                         or self._guess_format(input_path))
        reader = _READERS.get(input_format)
        if reader is None:
            return StageResult.failed(error=f"unsupported input_format: {input_format}")

        topic = _fmt(ctx.get_config("topic") or "")
        key_column = ctx.get_config("key_column")
        value_mode = (ctx.get_config("value_mode") or "json_row").lower()
        message_template = ctx.get_config("message_template")
        batch_size = int(ctx.get_config("batch_size") or 5000)
        max_messages = ctx.get_config("max_messages")
        if max_messages is not None:
            max_messages = int(max_messages)
        connection_id = int(ctx.get_config("connection_id"))

        # Resolve Kafka connection.  Pattern: query the Connection row by
        # id, then decrypt the JSON config via core.crypto.decrypt_config.
        # Same model every other backend module uses (matches
        # connections_api.py + ETL/steps/*).  Credentials never end up in
        # the DAG config — they live on the connection row, encrypted.
        try:
            from core.db.models import Connection
            from core.crypto import decrypt_config
            from core.dataflow.engine import get_engine as _get_engine
            engine_ = _get_engine()
            db_manager = ctx.db_manager or (engine_.db if engine_ else None)
            if db_manager is None:
                return StageResult.failed(error="db_manager not available to resolve connection")
            with db_manager.get_session(read_only=True) as session:
                row = session.query(Connection).filter(Connection.id == connection_id).first()
                if row is None:
                    return StageResult.failed(error=f"connection_id {connection_id} not found")
                raw_cfg = dict(row.config or {})
                conn_type = row.connection_type
            conn = decrypt_config(raw_cfg)
        except Exception as exc:
            return StageResult.failed(
                error=f"could not resolve connection_id={connection_id}: {exc}"
            )
        bootstrap = (conn.get("bootstrap_servers")
                      or conn.get("host") or "").strip()
        if not bootstrap:
            return StageResult.failed(
                error=f"connection has no bootstrap_servers/host "
                       f"(type={conn_type}, keys={sorted(conn.keys())})"
            )

        # kafka-python is an optional dependency in this codebase — fail
        # loud with a clear message if missing so the operator knows what
        # to install.
        try:
            from kafka import KafkaProducer  # type: ignore
        except Exception as exc:
            return StageResult.failed(
                error=f"kafka-python not available — {_KAFKA_INSTALL_HINT} "
                       f"to use put_kafka ({exc})"
            )

        # Read input via DuckDB so we don't load the whole file into RAM.
        try:
            import duckdb
            con = duckdb.connect(database=":memory:")
        except Exception as exc:
            return StageResult.failed(error=f"DuckDB unavailable: {exc}")

        producer_kwargs: Dict[str, Any] = {
            "bootstrap_servers": [s.strip() for s in bootstrap.split(",") if s.strip()],
            "value_serializer": lambda v: v if isinstance(v, bytes) else str(v).encode("utf-8"),
            "key_serializer":   lambda k: None if k is None else str(k).encode("utf-8"),
            "acks": "all",
        }
        # Optional SASL — only enable when present on the connection
        sasl_mech = conn.get("sasl_mechanism") or conn.get("sasl_mechanisms")
        if sasl_mech:
            producer_kwargs["security_protocol"] = conn.get("security_protocol") or "SASL_SSL"
            producer_kwargs["sasl_mechanism"]    = sasl_mech

            # Phase 158 R5 (2026-06-26) -- route SASL creds through
            # qs_credentials when the connection has a system_account_id
            # / _name reference.  Literal username + password fields on
            # the connection ALWAYS win when set (back-compat).  This
            # closes the Kafka gap from the cred-path audit.
            sasl_user = (
                conn.get("username")
                or conn.get("sasl_username")
                or ""
            )
            sasl_pass = (
                conn.get("password")
                or conn.get("sasl_password")
                or ""
            )
            sa_ref = (
                conn.get("system_account_id")
                or conn.get("system_account_name")
            )
            if sa_ref and (not sasl_user or not sasl_pass):
                try:
                    from core.qs_credentials import resolve_system_account
                    creds = resolve_system_account(sa_ref)
                    if creds:
                        # 2026-10-29 -- THE pairing rule: with no typed
                        # password the account's name AND password go together
                        # (core/qs_credentials/login.py).
                        from core.qs_credentials.login import pair_login
                        _login = pair_login(sasl_user, sasl_pass,
                                            creds.get("username"), creds.get("password"))
                        sasl_user, sasl_pass = _login.user, _login.secret
                except Exception as exc:
                    # Fail-OPEN to literal yaml values -- KafkaProducer
                    # will surface the auth error downstream if
                    # creds end up blank.
                    import logging as _logging
                    _logging.getLogger(__name__).warning(
                        "Kafka SASL: qs_credentials lookup failed for "
                        "system_account=%r (%s) -- falling back to "
                        "literal yaml.", sa_ref, exc,
                    )
            producer_kwargs["sasl_plain_username"] = sasl_user
            producer_kwargs["sasl_plain_password"] = sasl_pass

        try:
            producer = KafkaProducer(**producer_kwargs)
        except Exception as exc:
            try:
                con.close()
            except Exception:
                pass
            return StageResult.failed(error=f"KafkaProducer init failed: {exc}")

        published = 0
        try:
            cursor = con.execute(
                f"SELECT * FROM {reader}('{input_path.replace(chr(39), chr(39)*2)}')"
            )
            col_names = [d[0] for d in cursor.description]
            batch = 0
            while True:
                rows = cursor.fetchmany(min(batch_size, 10_000))
                if not rows:
                    break
                for row in rows:
                    if max_messages is not None and published >= max_messages:
                        break
                    row_dict = dict(zip(col_names, row))
                    if value_mode == "json_row":
                        value = json.dumps(row_dict, default=str)
                    else:
                        try:
                            value = (message_template or "").format(**row_dict)
                        except Exception as exc:
                            ctx.log(f"template format failed at row {published}: {exc}")
                            value = json.dumps(row_dict, default=str)
                    key = row_dict.get(key_column) if key_column else None
                    producer.send(topic, value=value, key=key)
                    published += 1
                    batch += 1
                if batch >= batch_size:
                    producer.flush()
                    batch = 0
                if ctx.is_cancelled():
                    ctx.log("cancel requested — stopping early")
                    break
                if max_messages is not None and published >= max_messages:
                    break
            producer.flush()
        except Exception as exc:
            return StageResult.failed(error=f"publish failed after {published} message(s): {exc}")
        finally:
            try:
                producer.close(timeout=10)
            except Exception:
                pass
            try:
                con.close()
            except Exception:
                pass

        ctx.log(f"published {published} message(s) to topic {topic!r}")
        return StageResult.succeeded(outputs={
            "topic":          topic,
            "messages":       published,
            "input_path":     input_path,
            "connection_id":  connection_id,
        })

    @staticmethod
    def _guess_format(path: str) -> str:
        ext = (path.rsplit(".", 1)[-1] or "").lower()
        if ext in ("csv", "tsv", "txt"):
            return "csv"
        if ext == "parquet":
            return "parquet"
        if ext in ("json", "jsonl", "ndjson"):
            return "json"
        return "json"
