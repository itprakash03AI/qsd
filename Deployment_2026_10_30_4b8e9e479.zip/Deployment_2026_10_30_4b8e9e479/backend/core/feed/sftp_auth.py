"""How an SFTP delivery authenticates -- decided ONCE, before the socket opens.

MIRRORED byte-for-byte at ``spark/jobs/qs_sftp_auth.py`` (the Spark job cannot
import backend/core); a backend guard fails the suite if the copies differ.
Standard library + paramiko only, so the mirror can run in the job image.

AQD-10 / AQD-11 (2026-09-23).  ``feed_engine._sftp_connect`` used to decide
inline, and the decision had a hole in the middle of it:

    if key_path and os.path.exists(key_path):  -> key auth (RSA only)
    else:                                       -> PASSWORD auth

A destination CONFIGURED for key auth whose key file was missing (a secret
not mounted, a typo, a rotated path) silently downgraded to password auth --
with whatever password happened to be there, often a blank one -- and the log
never said which method ran.  The operator who configured a key saw "auth
failed" at best, and a delivery over a credential they believed was retired at
worst.  Ed25519 and ECDSA keys could not be used at all: ``RSAKey`` was the
only loader.  And a private key could come only from a FILE on the pod; the
vault system account that already supplies a username and password could not
supply one.

The rules now:

* A key that is CONFIGURED is the method.  If it cannot be loaded -- a path
  that does not exist, a blob that parses as no supported type, a wrong
  passphrase -- the delivery REFUSES with the reason.  It never falls back to
  a password: a correctness gate must fail, and an auth downgrade is not a
  throttle.
* Key material comes from (first wins): ``dest_config.private_key`` (the
  Spark lane's conf secret carries it there), the vault system account's
  ``private_key`` (a ``kv_secrets`` payload), then ``dest_config.key_path``.
  A passphrase comes from the same account (``private_key_passphrase`` or
  ``passphrase``) or ``dest_config.key_passphrase``.
* Ed25519, ECDSA and RSA are all accepted.
* No key and no password is a refusal too -- "authenticate with nothing" is
  not a method.
* The chosen method and where its credential came from are returned, logged
  and put on the delivery receipt.  The secret itself never is.
"""
from __future__ import annotations

import io
import logging
import os
from dataclasses import dataclass
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: The pair the mirror guard (tests/test_lane_mirrors_2026_10_07.py)
#: byte-compares.
MIRROR_PATHS = (
    "backend/core/feed/sftp_auth.py",
    "spark/jobs/qs_sftp_auth.py",
)


class SftpAuthRefused(ValueError):
    """The delivery cannot authenticate the way it was configured to.

    A ``ValueError`` because ``_deliver_to_destination`` treats that as a
    non-retryable CONFIGURATION error: a missing key file is not going to
    appear on the third attempt.
    """


@dataclass(frozen=True)
class SftpAuth:
    method: str                    # "publickey" | "password"
    username: str
    source: str                    # where the credential came from
    pkey: Any = None
    password: Optional[str] = None
    key_type: Optional[str] = None  # e.g. "ssh-ed25519"

    def describe(self) -> Dict[str, Any]:
        """What may be logged and stored -- never the secret."""
        return {"method": self.method, "username": self.username,
                "source": self.source, "key_type": self.key_type}


def _key_classes():
    import paramiko
    return [c for c in (getattr(paramiko, n, None)
                        for n in ("Ed25519Key", "ECDSAKey", "RSAKey")) if c]


def load_private_key(*, material: Optional[str] = None, path: Optional[str] = None,
                     passphrase: Optional[str] = None, origin: str = "") -> Any:
    """Load an Ed25519 / ECDSA / RSA private key from text or a file.

    Raises :class:`SftpAuthRefused` naming the origin and every type tried.
    A passphrase-protected key with no (or the wrong) passphrase says so.
    """
    import paramiko
    if path is not None and not os.path.isfile(path):
        raise SftpAuthRefused(
            f"SFTP key auth is configured ({origin}) but the key file {path!r} does "
            f"not exist on this pod.  Refusing rather than falling back to password "
            f"auth -- mount the key, fix the path, or remove key_path to use a "
            f"password deliberately.")
    pw = passphrase or None
    tried = []
    for cls in _key_classes():
        try:
            if path is not None:
                return cls.from_private_key_file(path, password=pw)
            return cls.from_private_key(io.StringIO(material or ""), password=pw)
        except paramiko.PasswordRequiredException as exc:
            raise SftpAuthRefused(
                f"SFTP private key ({origin}) is passphrase-protected and no "
                f"passphrase was supplied (dest_config.key_passphrase, or "
                f"private_key_passphrase on the system account): {exc}") from exc
        except (paramiko.SSHException, ValueError, TypeError, IndexError) as exc:
            tried.append(f"{cls.__name__}: {exc}")
    raise SftpAuthRefused(
        f"SFTP private key ({origin}) could not be loaded as Ed25519, ECDSA or RSA "
        f"(or its passphrase is wrong): " + "; ".join(tried))


def resolve_sftp_auth(dest_config: Dict[str, Any],
                      account: Optional[Dict[str, Any]] = None) -> SftpAuth:
    """Decide the method.  ``account`` is the resolved system account (or
    None); literal ``dest_config`` username / password win over it, as they
    always have (operator override beats vault)."""
    account = account or {}
    # 2026-10-29 -- a login is a PAIR: when the secret is the ACCOUNT's (no
    # key, key file or password typed on the destination), so is the name --
    # a typed username is not sent beside it.  This is
    # core/qs_credentials/login.py::pair_login written out here because this
    # file is mirrored into the Spark job, which has no core package; a test
    # holds the two to the same answers.
    _typed_secret = (dest_config.get("private_key") or (dest_config.get("key_path") or "").strip()
                     or dest_config.get("password") or "")
    _account_secret = account.get("private_key") or account.get("password") or ""
    if not _typed_secret and _account_secret:
        username = account.get("username") or dest_config.get("username") or ""
    else:
        username = dest_config.get("username") or account.get("username") or ""
    if not username:
        raise SftpAuthRefused(
            "SFTP delivery has no username (dest_config.username, or the system "
            "account's username).")

    key_material = dest_config.get("private_key") or account.get("private_key") or ""
    key_origin = ("dest_config.private_key" if dest_config.get("private_key")
                  else f"system account {account.get('id')!r} private_key "
                       f"({account.get('via', '?')})")
    key_path = (dest_config.get("key_path") or "").strip()
    passphrase = (dest_config.get("key_passphrase")
                  or account.get("private_key_passphrase")
                  or account.get("passphrase") or None)

    if key_material:
        pkey = load_private_key(material=key_material, passphrase=passphrase,
                                origin=key_origin)
        return SftpAuth("publickey", username, key_origin, pkey=pkey,
                        key_type=pkey.get_name())
    if key_path:
        origin = f"dest_config.key_path={key_path!r}"
        pkey = load_private_key(path=key_path, passphrase=passphrase, origin=origin)
        return SftpAuth("publickey", username, origin, pkey=pkey,
                        key_type=pkey.get_name())

    if dest_config.get("password"):
        return SftpAuth("password", username, "dest_config.password",
                        password=dest_config["password"])
    if account.get("password"):
        return SftpAuth("password", username,
                        f"system account {account.get('id')!r} password "
                        f"({account.get('via', '?')})",
                        password=account["password"])
    raise SftpAuthRefused(
        "SFTP delivery has no credential: no private key (system account "
        "private_key, or dest_config.key_path) and no password.")
