"""Headless business-report source executors — the plugin seam.

Every headless caller (scheduler, subscription delivery, future automation)
executes a business report through ONE function — :func:`execute_headless` —
which dispatches through a REGISTRY instead of ``if source_type ==``
branches.  Adding a new report source type costs exactly one executor
function + one :func:`register_source_executor` call; the scheduler,
delivery engine and every other headless caller pick it up with zero edits
and can never drift from each other on dispatch or RLS scope.

Contract (enforced here, not hoped for):

* UNKNOWN = UNSAFE — an unregistered ``data_source_type`` is a hard
  ``ValueError``, never a silent default.
* Success is derived from a VERIFIED artifact — every executor's claimed
  output is resolved through :func:`core.reports.contract.require_artifact`
  before this function returns.  A run that produced no retrievable file
  CANNOT report success, so the scheduler can no longer mark
  ``last_run_status="success"`` while emailing users a path that does not
  exist (the raw-SQL false-success defect this replaced).
* RLS — executors receive ``owner_ctx`` (the report OWNER's resolved
  principal, never role="admin") exactly as the F1 fix (commit bc5a639)
  established; the registry keeps scheduler and delivery byte-identical.

Executor signature::

    fn(br, param_values, execution_id, output_dir, owner_ctx, db)
        -> (claimed_path | None, total_rows)
        |  (claimed_path | None, total_rows, meta_dict)

``claimed_path`` may be ``None`` when the engine writes to the shared result
store keyed by ``execution_id`` (the raw-SQL cross-source engines do) — the
verification chokepoint resolves it either way.

``meta_dict`` (optional 3rd element, 2026-08-09 D1 follow-up) lets an
executor surface engine-level truth the serve log needs:

* ``row_limit`` — the EFFECTIVE cap the engine actually applied (after the
  federation ``max_result_rows`` clamp / ``default_row_limit`` fill-in),
  which can differ from ``br.row_limit`` in both directions.
* ``truncated`` — an engine-computed verdict (e.g. a merged query whose
  SIDE was cut, invisible to a ``total >= limit`` check).

Two-tuple executors stay fully supported — the meta is additive.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from core.reports.contract import ReportArtifactError, require_artifact

logger = logging.getLogger(__name__)

SourceExecutor = Callable[..., Tuple[Optional[str], int]]

_SOURCE_EXECUTORS: Dict[str, SourceExecutor] = {}


def register_source_executor(source_type: str, fn: SourceExecutor) -> None:
    """Register (or override) the headless executor for a source type."""
    _SOURCE_EXECUTORS[source_type] = fn


#: FB-46 (2026-09-20) -- second spellings of a registered source type.
#: ``dataset`` is what the business-query-builder's API contract calls a
#: dataset-backed report (frontend/src/types/api.ts) and what 54% of the
#: rig's reports carry; the backend's canonical spelling for the same shape
#: is ``saved_query``.  Every reader of ``data_source_type`` that decides a
#: capability -- headless execution, the subscription gate, calculated
#: metrics, the microcube grain -- goes through canonical_source_type(), so
#: an alias can never be "unknown" on one path and dataset-backed on another.
SOURCE_TYPE_ALIASES: Dict[str, str] = {"dataset": "saved_query"}


def canonical_source_type(source_type: Optional[str]) -> str:
    """The registry's spelling of ``source_type`` (empty -> saved_query)."""
    dst = str(source_type or "saved_query").strip().lower() or "saved_query"
    return SOURCE_TYPE_ALIASES.get(dst, dst)


def get_source_executor(source_type: str) -> Optional[SourceExecutor]:
    return _SOURCE_EXECUTORS.get(canonical_source_type(source_type))


def describe_schedulable_sources() -> str:
    """The advice a save-time refusal gives, DERIVED from the registry.

    FB-46: the subscription gate was rewired to ask the registry, but the
    sentence beside it still hardcoded "backed by a dataset or raw_sql" --
    and named ``dataset`` as both the problem and the recommendation.  A
    sentence spelled separately from the gate drifts exactly like a gate
    spelled separately from the runtime did; so the sentence is computed
    from the same registry, with each alias shown beside its target.
    """
    parts: List[str] = []
    for key in sorted(_SOURCE_EXECUTORS):
        aliases = sorted(a for a, t in SOURCE_TYPE_ALIASES.items() if t == key)
        parts.append(f"{key} (also spelled {', '.join(repr(a) for a in aliases)})"
                     if aliases else key)
    return ", ".join(parts) if parts else "(no headless executors are registered)"


# ── Built-in executors ───────────────────────────────────────────────────────

def _exec_raw_sql(br: dict, param_values: dict, execution_id: str,
                  output_dir: Path, owner_ctx: Dict[str, Any], db,
                  ) -> Tuple[Optional[str], int]:
    """raw_sql source — the raw_sql engines (api.reports_api) via _as_legacy_report.

    The parquet engine writes the file we name; the SQL/cross-source engines
    write into the data-grid result store keyed by ``execution_id`` — we
    return ``None`` and let the verification chokepoint resolve the REAL
    location (previously callers were handed a phantom path that never
    existed for this branch).

    2026-09-07 — ``db=db`` IS FORWARDED.  Both engine entry points take an
    optional ``db`` and fall back to ``api.reports_api._db_manager``, a
    module global that only ``main.py``'s API startup sets.  This registry
    is the HEADLESS seam: it is reached from the scheduler worker and from
    subscription delivery, i.e. from processes that may never have run that
    startup — and it is handed a live ``db`` in its own signature, which it
    was then throwing away to fall back on a global that could be ``None``.
    ``core.scheduler``'s hand-rolled sibling had passed ``db=`` since
    2026-08-20 (``_exec_business_report``'s precedent); this one, the
    registry that was built to stop those two drifting, had not. The
    failure mode is an ``AttributeError: 'NoneType' object has no attribute
    'get_sql_query'`` on a worker pod, i.e. a report that runs in the API
    process and cannot run where it is actually scheduled.
    """
    from api.reports_api import _run_parquet_report, _run_sql_report
    from api.business_reports_api import _as_legacy_report
    from core.parameters import (resolve_business_dates, seed_parameter_defaults,
                                 validate_param_values)

    legacy = _as_legacy_report(br)
    # 2026-09-26 (FB-60): this seam ran with NO default seeding and NO
    # validation -- a required parameter with a default (which the preflight
    # had approved) reached the SQL as an unsubstituted placeholder.  Same
    # rule as the interactive run and the preflight; a missing required
    # value is refused BY NAME so the schedule/subscription records why.
    schema = legacy.get("parameters") or []
    param_values = resolve_business_dates(
        seed_parameter_defaults(schema, param_values))
    errors = validate_param_values(schema, param_values)
    if errors:
        raise ValueError("Parameter validation failed: " + "; ".join(errors))
    noop_emit = lambda _msg: None  # noqa: E731
    if legacy["saved_query_id"]:
        output_path = str(Path(output_dir) / f"{execution_id}.parquet")
        total = _run_parquet_report(legacy, param_values, None, output_path,
                                    noop_emit, user_ctx=owner_ctx, db=db)
        return output_path, int(total or 0)
    if legacy["sql_saved_query_id"] or legacy.get("sql_override"):
        total = _run_sql_report(legacy, param_values, None, execution_id,
                                noop_emit, user_ctx=owner_ctx, db=db)
        return None, int(total or 0)   # artifact lives in the result store
    raise ValueError(f"Business report {br.get('id')} (raw_sql) has no source configured")


def _exec_federation(br: dict, param_values: dict, execution_id: str,
                     output_dir: Path, owner_ctx: Dict[str, Any], db,
                     ) -> Tuple[Optional[str], int]:
    """saved_query / federation_view / published_view — FederationEngine path."""
    from api.business_reports_api import (
        _build_report_filters, _build_source_bindings, _require_federation, _run_report_query,
    )
    fed = _require_federation()
    combined_filters = _build_report_filters(br, param_values, db, br["id"])
    # 2026-10-29 -- the report's SOURCE parameters (filter at the source), as
    # the engine's own argument, never inside the filter list
    source_bindings = _build_source_bindings(br, param_values, db, br["id"])
    # 2026-08-05 audit: parity with the interactive path — /execute caps at
    # business_reports.default_row_limit (500K) when the report sets no
    # row_limit, while this hardcoded 50000 silently made the SCHEDULED
    # file 10x shorter than the same report run interactively.
    from core import config as _cfg
    # 2026-08-13 -- through the SHARED resolver, not another ``or`` chain.
    # The 2026-08-05 note above fixed a hardcoded 50000 that made scheduled
    # files 10x shorter than interactive; the replacement kept the ``or``
    # idiom, which folds an explicit ``row_limit: 0`` (UNLIMITED) back into
    # the 500K default -- the same silent clipping in a new spelling, and
    # the scheduled path is where nobody is watching the row count.
    from api.business_reports_api import _resolve_report_row_limit
    row_limit = _resolve_report_row_limit(None, br, _cfg)
    result = _run_report_query(
        fed, br, combined_filters, row_limit, execution_id,
        owner_ctx.get("role") or "viewer", user_ctx=owner_ctx,
        source_bindings=source_bindings,
    )
    res = result.to_dict() if hasattr(result, "to_dict") else result
    # 2026-08-09 (D1 follow-up): surface the engine-stamped EFFECTIVE
    # row_limit + truncation verdict (FederationResult.to_dict emits them
    # only when stamped).  Fall back to the limit we REQUESTED — still
    # strictly better than br.row_limit alone, which is None whenever the
    # default_row_limit fill-in above applied.
    meta = {
        "row_limit": res.get("row_limit") or row_limit,
        "truncated": res.get("truncated"),
        # D1/D2 (2026-08-09 cross-feature review): the no-ORDER-BY-cut
        # disclosure must survive into the recorded instance, or every
        # serve of a pre-warmed artifact silently drops it.
        "unstable_truncation": res.get("unstable_truncation"),
    }
    return (res.get("output_path") or None), int(res.get("total_rows") or 0), meta


# ── PV / FV headless executors (2026-08-30) ─────────────────────────────────
#
# These two source types were registered to an honest refusal ("cannot run
# headlessly … interactive-only") because their engines are ASYNC page-
# envelope producers.  The capability always existed — the interactive path
# in api.business_reports_api executes both — so this is the bridge, not a
# new engine: same engines, same artifact helper, dispatched through this
# registry so scheduler and subscription delivery pick them up with zero
# edits and identical RLS scope.

def _run_coro_headless(coro):
    """Bridge an ASYNC view engine into the SYNC headless worker context.

    Every production headless caller (core.scheduler worker thread,
    core.delivery_engine via run_business_report_to_df) runs in a plain
    thread with NO event loop, so ``asyncio.run`` is the correct bridge —
    it creates a fresh loop, sets it as the thread's current loop for the
    duration (matching the manual ``new_event_loop``/``set_event_loop``
    pattern federation_views_api's materializer already uses) and tears it
    down.

    Defensive branch: if a future caller invokes execute_headless ON a
    thread whose loop is RUNNING (a sync call made from coroutine context),
    ``asyncio.run`` would raise "cannot be called from a running event
    loop" — instead the coroutine runs to completion on a private worker
    thread with its own loop.  That blocks the calling thread exactly as
    any sync call from a loop thread already does; it never nests or
    re-enters the caller's loop.
    """
    import asyncio
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="br-headless-bridge") as pool:
        return pool.submit(asyncio.run, coro).result()


def _require_owner_principal(br: dict, owner_ctx: Dict[str, Any]) -> Dict[str, Any]:
    """SECURITY — refuse a headless view run with no resolved principal.

    Both view engines have a FALLBACK principal for missing identities, and
    the PV one is WIDER than a refusal: ``_execute_view`` with an empty
    consumer ctx falls back to a synthetic ``pv:<slug>`` principal carrying
    ``groups=allowed_ad_groups`` and NO ``rls_unresolved`` marker — in this
    GRANT-shaped RLS engine an unmarked principal that matches no policy
    binding reads governed tables UNFILTERED (the escalation shape this
    codebase has shipped twice).  A username-less owner_ctx therefore
    REFUSES here, before any engine sees it.  A ctx that carries a username
    plus ``rls_unresolved=True`` is passed through untouched — the
    row-security rewriter turns that marker into a per-governed-table
    refusal, which is the intended fail-closed degradation.
    """
    if not isinstance(owner_ctx, dict) or not str(owner_ctx.get("username") or "").strip():
        raise ValueError(
            f"Business report {br.get('id')}: headless view execution refused "
            "— no resolved owner principal (owner_ctx carries no username). "
            "Running anyway would fall back to an unscoped engine principal "
            "and bypass row security (fail-closed)."
        )
    return owner_ctx


def _finish_view_execution(db, br: dict, result: Any,
                           owner_ctx: Dict[str, Any], execution_id: str,
                           row_limit: Optional[int],
                           ) -> Tuple[str, int, Dict[str, Any]]:
    """Shared PV/FV tail: verified artifact + truncation meta (fail-CLOSED).

    The interactive path persists the inline result through
    ``business_reports_api._persist_inline_result_artifact`` fail-OPEN (the
    artifact is additive there — the inline rows still reach the viewer).
    Headless has NO inline consumer: the artifact IS the deliverable, so a
    persist failure here is a run failure, never a silent success.
    """
    from api.business_reports_api import _persist_inline_result_artifact
    from core.reports.contract import resolve_cap

    res = result if isinstance(result, dict) else {}
    artifact_path = _persist_inline_result_artifact(
        db, br, res, str(owner_ctx.get("username") or ""), execution_id)
    if not artifact_path:
        raise ReportArtifactError(
            f"Business report {br.get('id')} ({br.get('data_source_type')}) "
            f"execution {execution_id} produced no persistable result artifact "
            "— the view engine returned no materialised rows or the artifact "
            "write failed (see the preceding warning log). Refusing to report "
            "success without the file delivery would ship."
        )
    meta = {
        # resolve_cap: first PRESENT cap wins — an engine-stamped 0
        # (unlimited) must not be folded into the requested cap by ``or``.
        "row_limit": resolve_cap(res.get("row_limit"), row_limit),
        "truncated": res.get("truncated"),
        "unstable_truncation": res.get("unstable_truncation"),
    }
    return artifact_path, int(res.get("total_rows") or 0), meta


def _exec_federation_view(br: dict, param_values: dict, execution_id: str,
                          output_dir: Path, owner_ctx: Dict[str, Any], db,
                          ) -> Tuple[Optional[str], int, Dict[str, Any]]:
    """federation_view source — the SAME engine the interactive path uses.

    Mirrors api.business_reports_api.execute_report's FV branch:
    ``execute_federation_view`` with the shared row-limit resolver, then the
    shared inline→parquet artifact helper (here fail-closed — see
    :func:`_finish_view_execution`).  ``param_values`` are deliberately not
    threaded: the interactive FV branch does not map report parameters into
    the view either, and headless must not silently mean something different
    from interactive.  IDENTITY: ``owner_ctx`` is passed as ``user_ctx``,
    which ``federation_views_api._fv_principal`` uses AS-IS on every side —
    the owner's username/role/groups (and any ``rls_unresolved`` marker)
    reach the row-security rewriter exactly as on the other headless paths.
    """
    from api.business_reports_api import _resolve_report_row_limit
    from api.federation_views_api import execute_federation_view
    from core import config as _cfg

    _require_owner_principal(br, owner_ctx)
    fv_id = br.get("federation_view_id")
    if not fv_id:
        raise ValueError(
            f"Business report {br.get('id')} has data_source_type="
            "'federation_view' but no federation_view_id — it cannot run "
            "headlessly (or interactively) until the view reference is "
            "configured."
        )
    fv = db.get_federation_view(fv_id)
    if not fv:
        raise ValueError(
            f"Business report {br.get('id')}: federation view {fv_id} not found"
        )
    row_limit = _resolve_report_row_limit(None, br, _cfg)
    result = _run_coro_headless(execute_federation_view(
        fv, limit=row_limit,
        username=str(owner_ctx.get("username") or ""),
        user_ctx=owner_ctx,
    ))
    return _finish_view_execution(db, br, result, owner_ctx, execution_id,
                                  row_limit)


def _exec_published_view(br: dict, param_values: dict, execution_id: str,
                         output_dir: Path, owner_ctx: Dict[str, Any], db,
                         ) -> Tuple[Optional[str], int, Dict[str, Any]]:
    """published_view source — the SAME handler the interactive path uses.

    Mirrors api.business_reports_api.execute_report's PV branch: the
    config gate, the active check, ``_map_report_params_to_pv`` for report
    parameters, ``_execute_view`` for execution, the shared artifact helper
    (fail-closed here).  IDENTITY: ``owner_ctx`` is passed as
    ``consumer_user`` — the report OWNER's resolved principal, exactly the
    RLS identity every other headless source runs under; the PV handlers
    stash it as ``_consumer_user_ctx`` and thread it into ``secure_sql`` /
    the engine's SQL-build site, where an ``rls_unresolved`` marker refuses
    governed tables instead of reading them unfiltered.
    """
    from api.business_reports_api import (
        _map_report_params_to_pv, _resolve_report_row_limit,
    )
    from api.published_views_api import _execute_view
    from core import config as _cfg

    _require_owner_principal(br, owner_ctx)
    pv_id = br.get("published_view_id")
    if not pv_id:
        raise ValueError(
            f"Business report {br.get('id')} has data_source_type="
            "'published_view' but no published_view_id — it cannot run "
            "headlessly (or interactively) until the view reference is "
            "configured."
        )
    if not _cfg.business_reports.enable_published_view_source:
        raise ValueError(
            f"Business report {br.get('id')}: Published View data source is "
            "disabled by configuration (business_reports."
            "enable_published_view_source)"
        )
    pv = db.get_published_view(pv_id)
    if not pv:
        raise ValueError(
            f"Business report {br.get('id')}: published view {pv_id} not found"
        )
    if not pv.get("is_active"):
        raise ValueError(
            f"Business report {br.get('id')}: published view {pv_id} is inactive"
        )
    pv_params = _map_report_params_to_pv(br, param_values or {}, db, br.get("id"))
    row_limit = _resolve_report_row_limit(None, br, _cfg)
    result = _run_coro_headless(_execute_view(
        pv=pv, filters=[], columns=None,
        sort_column=None, sort_dir="asc",
        limit=row_limit, offset=0, params=pv_params,
        consumer_user=owner_ctx,
    ))
    return _finish_view_execution(db, br, result, owner_ctx, execution_id,
                                  row_limit)


register_source_executor("raw_sql", _exec_raw_sql)
register_source_executor("saved_query", _exec_federation)
register_source_executor("federation_view", _exec_federation_view)
register_source_executor("published_view", _exec_published_view)


# ── The one headless entry point ─────────────────────────────────────────────

def execute_headless(br: dict, param_values: dict, execution_id: str,
                     output_dir, owner_ctx: Dict[str, Any], db,
                     ) -> Tuple[str, int]:
    """Execute a business report headlessly at the OWNER's RLS scope.

    Returns ``(verified_artifact_path, total_rows)``.  The path is GUARANTEED
    to exist (verified through :func:`require_artifact`); any failure —
    including "the engine claimed success but wrote nothing retrievable" —
    raises, so callers record a real failure instead of a phantom success.
    """
    report_id = br.get("id")

    # ── Publish lifecycle (2026-08-17) — THE delivery decision ───────────────
    # A subscription / scheduled delivery ships the CURRENT PUBLISHED VERSION
    # when one exists (enterprise semantics: a consumer's inbox must never
    # receive the author's half-edited draft).  A never-published report
    # keeps delivering the draft byte-identically to before, and ANY
    # resolution failure falls open to the draft — a version-store hiccup
    # must not turn a working delivery dark.  The RLS scope is untouched:
    # owner_ctx keeps governing row security exactly as F1 established.
    served_version = None
    try:
        from core.reports.versions import resolve_headless_report
        br, served_version = resolve_headless_report(db, br)
        if served_version:
            logger.info("[br-publish] headless run of report %s executes "
                        "published v%s", report_id,
                        served_version.get("version_no"))
    except Exception as exc:
        logger.warning("[br-publish] headless version resolution failed for "
                       "report %s — executing the draft (fail-open): %s",
                       report_id, exc)

    dst = canonical_source_type(br.get("data_source_type"))
    fn = _SOURCE_EXECUTORS.get(dst)
    if fn is None:
        raise ValueError(
            f"Business report {report_id}: unknown data_source_type {dst!r} — "
            "refusing to run (UNKNOWN=UNSAFE; register an executor via "
            "core.reports.sources.register_source_executor)"
        )
    try:
        out = fn(br, param_values or {}, execution_id,
                 Path(output_dir), owner_ctx, db)
    except (ValueError, ReportArtifactError):
        raise
    except Exception as exc:
        raise ValueError(f"Business report {report_id} execution failed: {exc}") from exc

    claimed_path, total_rows = out[0], out[1]
    # Optional executor meta (see module docstring) — 2-tuple executors
    # (including externally registered ones) keep working unchanged.
    exec_meta: Dict[str, Any] = (out[2] if len(out) > 2
                                 and isinstance(out[2], dict) else {})

    verified = require_artifact(execution_id, claimed_path)

    # 2026-08-05 audit: the one greppable [br-serve] line for every headless
    # run (scheduler + subscription delivery share this chokepoint).
    # 2026-08-09 (D1 follow-up, flagged in 122a8c30): prefer the EFFECTIVE
    # row_limit the engine stamped on its result over br.row_limit — the
    # br value under-reported a clamp (engine max_result_rows < br limit)
    # and reported "no cap" when the default_row_limit fill-in applied,
    # exactly the lie the contract path was cured of in 122a8c30.
    from core.reports.serve_log import log_report_serve
    # CORR-2 (2026-08-22): resolve + verdict through the ONE chokepoint.  The
    # old ``exec_meta.get("row_limit") or br.get("row_limit")`` skipped an
    # engine-stamped 0 (unlimited) and folded it into br's cap; the
    # ``int(_cap) if _cap else None`` then stored NULL for an unlimited run and
    # the verdict read UNKNOWN.  ``resolve_cap`` keeps a present 0;
    # ``truncation_verdict`` reads 0 as COMPLETE; ``normalize_row_limit`` stores
    # 0 (unlimited, known) distinct from None (absent, unknown).
    from core.reports.contract import (
        normalize_row_limit, resolve_cap, truncation_verdict,
    )
    _cap = resolve_cap(exec_meta.get("row_limit"), br.get("row_limit"))
    _stored_cap = normalize_row_limit(_cap)
    _truncated = exec_meta.get("truncated")
    if _truncated is None:
        _truncated = truncation_verdict(total_rows, _cap)
    log_report_serve(
        report_id=report_id, execution_id=execution_id,
        user=str(owner_ctx.get("username") or ""), rls="owner",
        surface="headless", fmt="artifact", rows=int(total_rows or 0),
        row_limit=_stored_cap,
        truncated=_truncated,
    )

    # Phase 2 report-instance layer (2026-08-09): headless runs PRE-WARM the
    # instance store — the 6am schedule produces the instance every 9am
    # interactive open serves for free (target architecture §5.3, the BO
    # model).  The chokepoint is fail-open + flag-gated (no-op while
    # business_reports.instance_serving_enabled is off), so a write-through
    # failure can never turn a verified successful run into a failure.
    # D1/D2 (2026-08-09 cross-feature review): persist the RUN's truncation
    # facts — the effective cap + verdict computed above for the serve log
    # are exactly what the instance must carry, or every serve of this
    # pre-warmed artifact recomputes a verdict against the BR limit and
    # resurrects the silent-truncation defect 122a8c30 killed.
    from core.reports.instances import record_report_instance
    record_report_instance(
        db, br, owner_ctx, param_values,
        execution_id=execution_id,
        artifact_path=str(verified),
        row_count=int(total_rows or 0),
        is_scheduled=True,
        row_limit=_stored_cap,
        truncated=_truncated,
        unstable_truncation=exec_meta.get("unstable_truncation"),
    )

    # 2026-09-28 -- a headless run (schedule, subscription) is THE run a
    # report SLO usually counts on ("served by 07:00"): record the readiness
    # it was served under.  Fail-open: the artifact is verified and the
    # run is a success whatever this ledger write does.
    _record_headless_readiness(db, br, param_values, execution_id,
                               str(owner_ctx.get("username") or ""))

    return str(verified), int(total_rows or 0)


def _record_headless_readiness(db, br: dict, param_values: dict,
                               execution_id: str, username: str) -> None:
    try:
        from api.business_reports_api import _resolve_param_value
        from core.reports.readiness import readiness_for_run, record_readiness_run
        rd = readiness_for_run(db, br, param_values or {},
                               resolve=_resolve_param_value)
        record_readiness_run(db, rd, execution_id=execution_id,
                             executed_by=username, surface="headless")
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[readiness] headless run %s of report %s: verdict not "
                       "recorded: %s", execution_id, br.get("id"), exc)
