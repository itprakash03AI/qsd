"""Which of a dataset's filters may be pushed INTO a registered-table view.

2026-10-02.  A CUSTOM-SQL dataset over an S3 connection (``base_query =
select id, dt, amt from trades``, ``trades`` a registered hive-partitioned
table) runs as ``WITH qs_base AS (<base_query>) SELECT ... WHERE "dt" =
'2026-06-15'``.  The registered table is bound as a DuckDB VIEW whose file
list comes from ``FederationEngine._table_to_expression`` -- the proven
pruning chokepoint -- but that call was made WITHOUT the dataset's
filters, because the filters sit OUTSIDE the base query and nothing had
proved they mean the same thing inside it.  So every file of the table was
listed, presigned and opened: 11-18 s per query on a 365-day x 5-region
tree, and the connection-exhaustion 500 at thousands of presigned files.
A TABLE-mode dataset with the same filter pruned to the matching files.

THE RISK IS ONE-DIRECTIONAL.  Forwarding too little is today's behaviour
(slow, correct).  Forwarding a filter whose dataset column is NOT the
table's own column, unchanged, is ROW LOSS behind a 200: ``select other
as dt`` filtered on ``dt`` would prune the files by the PATH's ``dt``
while the outer WHERE asks about ``other``.  So a filter is forwarded
ONLY when lineage PROVES the dataset column IS that table's column,
unchanged, and the statement has no clause whose answer changes when its
input is narrowed first.  Anything unparsed or unrecognised is declined,
and every decision is logged by the caller -- the system says what it
DECLINED, not only what it did.

THE RULE, exactly as implemented (``forwardable_filters``):

  statement
    * parses (DuckDB dialect) as ONE ``SELECT`` -- no UNION / INTERSECT /
      EXCEPT, no CTE, no subquery anywhere (a scalar subquery over the
      same table would be computed over the PRUNED view);
    * reads exactly ONE bare, unqualified table, by the registered name,
      with no JOIN, table function, sample, pivot or lateral;
    * carries no LIMIT / OFFSET (``TOP`` does not parse), no GROUP BY /
      HAVING / aggregate, no window function, no QUALIFY, no
      ``DISTINCT ON`` (plain DISTINCT is fine), and no function sqlglot
      does not recognise (``exp.Anonymous``);
    * WHERE and ORDER BY are fine -- the forwarded filter ANDs with the
      base WHERE, and an ORDER BY without a LIMIT changes no row.
  column
    * the filtered dataset column's physical name is projected by a bare
      ``*`` (no REPLACE / RENAME; not listed in EXCLUDE), by ``t.*`` on the
      table's own alias, or by a BARE column reference to the SAME name
      (case-insensitive; a qualifier must be the table or its alias; an
      alias is allowed only when it spells the same name);
    * and no OTHER projected expression is aliased to that name
      (``select *, x as dt`` makes the outer ``dt`` ambiguous).

The outer WHERE is ALWAYS applied unchanged by the caller: forwarding only
narrows the FILE LIST the view reads; it never replaces the predicate.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

#: ``Select`` args that cannot change the answer when the table is pruned
#: on an AND-ed predicate first.  Every OTHER non-empty arg declines the
#: statement -- a whitelist, so a clause this module has never heard of
#: (a future sqlglot, a DuckDB extension) is declined rather than ignored.
#: ``from_`` / ``with_`` are sqlglot >= 30's spellings; the bare ones are
#: kept for an older parser.
_ALLOWED_SELECT_ARGS = frozenset({"expressions", "from_", "from", "where",
                                  "order", "distinct"})
_FROM_KEYS = ("from_", "from")
_WITH_KEYS = ("with_", "with")
_STAR_EXCEPT_KEYS = ("except_", "except")
#: ``Table`` args a bare table reference may carry.  A sample, pivot,
#: lateral, version or join hanging off the table declines it.
_ALLOWED_TABLE_ARGS = frozenset({"this", "db", "catalog", "alias"})


@dataclass(frozen=True)
class Projection:
    """What the single-table SELECT passes through UNCHANGED."""
    star: bool                      #: a bare ``*`` / ``t.*`` projects everything
    excluded: frozenset             #: names a ``* EXCLUDE (...)`` removes
    columns: frozenset              #: bare column names projected as themselves
    shadowed: frozenset             #: output names an EXPRESSION is aliased to

    def passes_through(self, name: str) -> bool:
        key = (name or "").lower()
        if not key or key in self.shadowed:
            return False
        if key in self.columns:
            return True
        return self.star and key not in self.excluded


@dataclass(frozen=True)
class LineageVerdict:
    """The decision for one (base query, registered table) pair."""
    forwarded: List[Any] = field(default_factory=list)   #: FilterSpec copies
    declined: List[Tuple[str, str]] = field(default_factory=list)  #: (column, why)
    statement_reason: str = ""      #: non-empty = the whole statement declined

    @property
    def summary(self) -> str:
        if self.statement_reason:
            return f"declined ({self.statement_reason})"
        fwd = [getattr(f, "physical_name", "?") for f in self.forwarded]
        dec = [f"{c}:{why}" for c, why in self.declined]
        return f"forwarded {fwd}; declined {dec}"


def _arg(node: Any, *keys: str) -> Any:
    for k in keys:
        v = node.args.get(k)
        if v is not None:
            return v
    return None


def _clause_reason(tree: Any, exp: Any) -> str:
    """Is this ONE plain SELECT carrying only clauses pruning cannot change?"""
    if not isinstance(tree, exp.Select):
        return f"not_a_single_select:{type(tree).__name__}"
    for key, val in tree.args.items():
        if val and key not in _ALLOWED_SELECT_ARGS:
            return f"clause_not_allowed:{key}"
    distinct = tree.args.get("distinct")
    if distinct is not None and distinct.args.get("on"):
        return "distinct_on"
    return ""


def _source_reason(tree: Any, table_name: str, exp: Any) -> str:
    """Does it read exactly the registered table, bare, and nothing else?"""
    src = _arg(tree, *_FROM_KEYS)
    src = src.this if src is not None else None
    if not isinstance(src, exp.Table) or not isinstance(src.this, exp.Identifier):
        return "from_not_a_bare_table"
    if any(v for k, v in src.args.items() if k not in _ALLOWED_TABLE_ARGS):
        return "table_modifier"
    if src.db or src.catalog:
        return "from_qualified"
    if src.name.lower() != (table_name or "").lower():
        return f"from_other_table:{src.name}"
    return ""


def _body_reason(tree: Any, exp: Any) -> str:
    """Any construct whose answer depends on the UNPRUNED table?"""
    if any(n is not tree for n in tree.find_all(exp.Select)) or tree.find(exp.Subquery):
        return "subquery"
    if len(list(tree.find_all(exp.Table))) != 1:
        return "table_referenced_more_than_once"   # belt and braces: a join or
        # subquery is caught before this; it holds for any shape not yet named
    for kind, why in ((exp.Window, "window_function"), (exp.AggFunc, "aggregate"),
                      (exp.Anonymous, "unrecognised_function")):
        hit = tree.find(kind)
        if hit is not None:
            return f"{why}:{hit.sql(dialect='duckdb')[:60]}"
    return ""


def _statement_reason(tree: Any, table_name: str, exp: Any) -> str:
    """The reason the STATEMENT cannot host a pushed-in filter, or ''."""
    return (_clause_reason(tree, exp)
            or _source_reason(tree, table_name, exp)
            or _body_reason(tree, exp))


def _own(qualifier: str, table_name: str, alias: str) -> bool:
    q = (qualifier or "").lower()
    return not q or q in {(table_name or "").lower(), (alias or "").lower()}


def _classify(e: Any, table_name: str, alias: str, exp: Any) -> Tuple[str, Any]:
    """One projected expression -> ``("star", excluded_names)``,
    ``("column", name)``, ``("shadow", name)`` or ``("opaque", None)``."""
    if isinstance(e, exp.Star):
        if _arg(e, "replace", "rename"):
            return "opaque", None    # a rewritten star passes nothing through
        return "star", {c.name.lower() for c in (_arg(e, *_STAR_EXCEPT_KEYS) or [])}
    if isinstance(e, exp.Column) and isinstance(e.this, exp.Star):
        return ("star", set()) if _own(e.table, table_name, alias) else ("opaque", None)
    if isinstance(e, exp.Column):
        return ("column", e.name.lower()) if _own(e.table, table_name, alias) else ("opaque", None)
    if not isinstance(e, exp.Alias) or not e.alias:
        return "opaque", None
    inner = e.this
    same_name = (isinstance(inner, exp.Column) and not isinstance(inner.this, exp.Star)
                 and e.alias.lower() == inner.name.lower()
                 and _own(inner.table, table_name, alias))
    return ("column", e.alias.lower()) if same_name else ("shadow", e.alias.lower())


def _projection(tree: Any, table_name: str, exp: Any) -> Projection:
    """Classify each projected expression: a pass-through, or a shadow."""
    alias = _arg(tree, *_FROM_KEYS).this.alias or ""
    star, excluded, columns, shadowed = False, set(), set(), set()
    for e in tree.expressions:
        kind, payload = _classify(e, table_name, alias, exp)
        if kind == "star":
            star = True
            excluded |= payload
        elif kind == "column":
            columns.add(payload)
        elif kind == "shadow":
            shadowed.add(payload)
    return Projection(star=star, excluded=frozenset(excluded),
                      columns=frozenset(columns), shadowed=frozenset(shadowed))


def forwardable_filters(base_query: str, table_name: str,
                        filter_specs: Optional[Sequence[Any]]) -> LineageVerdict:
    """Decide which ``filter_specs`` may be pushed into the view of
    ``table_name`` that ``base_query`` reads.  Never raises: a parse failure
    is a declined statement, and the caller runs today's unpruned view."""
    if not filter_specs:
        return LineageVerdict()
    try:
        import sqlglot
        from sqlglot import exp
        tree = sqlglot.parse_one(str(base_query or "").strip().rstrip(";"),
                                 dialect="duckdb")
        reason = _statement_reason(tree, table_name, exp)
        if reason:
            return LineageVerdict(statement_reason=reason)
        projection = _projection(tree, table_name, exp)
    except Exception as exc:  # noqa: BLE001 - unparsed = unproven = declined
        return LineageVerdict(statement_reason=f"parse_failed:{type(exc).__name__}")
    forwarded: List[Any] = []
    declined: List[Tuple[str, str]] = []
    for f in filter_specs:
        name = getattr(f, "physical_name", "") or ""
        if projection.passes_through(name):
            forwarded.append(dataclasses.replace(f, source_table=table_name))
        else:
            declined.append((name, "not_the_tables_own_column_unchanged"))
    return LineageVerdict(forwarded=forwarded, declined=declined)


# ═══════════════════════════════════════════════════════════════════════════
# The base query's OWN WHERE (2026-10-02, second half)
# ═══════════════════════════════════════════════════════════════════════════
#
# The user's dataset IS ``select * from Plex where businessdate = '...'`` --
# the predicate lives in the base query, not in a dataset filter -- and the
# wizard's Preview / Columns steps run ``SELECT * FROM (<that>) __preview__
# LIMIT 10|1`` with no filters at all, so every file of the table was listed,
# presigned and opened (the Columns step took > 60 s on the rig).
#
# WHY IT IS EXACT.  A top-level AND-ed WHERE conjunct of a SELECT that reads
# ONE bare table excludes those rows from that SELECT's output whatever
# follows: GROUP BY, HAVING, window functions, QUALIFY, DISTINCT [ON], ORDER
# BY, LIMIT / OFFSET are all evaluated AFTER the WHERE, and a wrapper that
# only CONSUMES the SELECT's output (``SELECT * FROM (<it>) AS w LIMIT n``)
# can never see a row the inner WHERE removed.  So pruning the table's FILES
# by such a conjunct cannot lose a returned row.  What breaks the proof, and
# is therefore declined: the table referenced anywhere else (a self-join, a
# subquery over it -- the view is ONE object, so pruning it for the outer
# scope prunes it for every scope), a JOIN in that scope (the predicate may
# belong to the other side; OUTER joins change NULL semantics), a CTE, a set
# operation (each arm has its own WHERE), a predicate inside a subquery, and
# any conjunct that is not literally ``bare own column <op> literal(s)`` --
# ``lower(region) = 'emea'`` is unwrapped by the shared extractor for the
# Iceberg bound layer (which case-folds), but the hive PATH matcher compares
# ``str(path_value) != str(literal)`` and would drop ``region=EMEA``.
#
# THE EXTRACTOR IS THE EXTRACTOR.  The predicates come from
# ``core.sql_partition_extractor.extract_combined_filters_and_or_groups_for_
# iceberg`` -- the same call the query builder's raw-SQL road makes in
# ``core/duckdb_views.py`` -- in its own pruning-format vocabulary.  This
# module adds no second reading of the SQL: it computes, from the AST, the
# set of ``(col, op, value)`` keys a top-level simple conjunct PROVABLY
# yields (spelling values through the extractor's own ``_extract_literal_
# value`` / ``_flip_operator``) and lets through only the extractor's dicts
# that match one.  Everything else is declined with a reason, and the caller
# logs both lists.

#: A SELECT that merely CONSUMES a derived table's output may carry these.
_WRAPPER_ARGS = frozenset({"expressions", "from_", "from", "where", "order",
                           "distinct", "limit", "offset"})
#: The one SELECT that reads the table may additionally carry clauses that
#: are evaluated AFTER its WHERE.
_WHERE_SCOPE_ARGS = _WRAPPER_ARGS | frozenset({"group", "having", "qualify",
                                               "windows"})
_RANGE_OPS = {"EQ": "equals", "NEQ": "not_equals", "GT": "greater_than",
              "GTE": "greater_equals", "LT": "less_than", "LTE": "less_equals"}


@dataclass(frozen=True)
class WhereVerdict:
    """The base query's own WHERE, as pruning-format dicts the proof admits.

    ``or_groups`` (2026-10-08): the WHERE's top-level OR of AND-groups as
    the extractor's branches, admitted ONLY when every dict of every branch
    is a bare own-column leaf of THAT disjunct (or a top-level conjunct);
    ``or_reason`` says why they were declined.  The union of the branches'
    islands is then a superset of the rows the OR admits -- see
    ``core.filter_ops.disjunction_decision`` for the pruners' own gate."""
    forwarded: List[Dict[str, Any]] = field(default_factory=list)
    declined: List[Tuple[str, str]] = field(default_factory=list)  #: (col op val, why)
    statement_reason: str = ""
    or_groups: List[List[Dict[str, Any]]] = field(default_factory=list)
    or_reason: str = ""

    @property
    def summary(self) -> str:
        if self.statement_reason:
            return f"declined ({self.statement_reason})"
        fwd = [f"{d.get('col')} {d.get('op')} {d.get('val')!r}" for d in self.forwarded]
        dec = [f"{what}:{why}" for what, why in self.declined]
        if self.or_groups:
            orr = f"; OR branches forwarded {len(self.or_groups)}"
        elif self.or_reason:
            orr = f"; OR branches declined ({self.or_reason})"
        else:
            orr = ""
        return f"forwarded {fwd}; declined {dec}{orr}"


def _scope_reason(node: Any, table_name: str, exp: Any) -> str:
    """Why this SELECT cannot be the one whose WHERE prunes the table."""
    reason = _source_reason(node, table_name, exp)
    if reason:
        return reason
    if any(n is not node for n in node.find_all(exp.Select)) or node.find(exp.Subquery):
        return "subquery"
    return ""


#: A JOIN scope (2026-10-29) may carry its joins; everything else as the
#: single-table scope.  The owner's dataset is ``fact_tetb JOIN fact_tetb_ext
#: ... WHERE FACT_TETB.SYSTEM_ID IN (..) AND FACT_TETB.BUSINESS_CLOSE_DATE =
#: ..`` and this proof declined it as "table_referenced_more_than_once", so
#: BOTH tables read every file.  A top-level AND-ed conjunct QUALIFIED with
#: one table's alias excludes that table's rows from the join's output
#: whatever the join type: a row that survives the WHERE carries a value of
#: that table's column that satisfies the predicate, so a file of that table
#: whose partition cannot satisfy it contributes no surviving row.  What the
#: join type DOES change is NULL: an outer join manufactures NULLs the
#: predicate never saw in any file, so ``IS NULL`` / ``IS NOT NULL`` / ``<>``
#: / ``NOT IN`` / ``NOT BETWEEN`` are declined in a JOIN scope, and so is an
#: unqualified column (ambiguous between the sides).
_JOIN_SCOPE_ARGS = _WHERE_SCOPE_ARGS | frozenset({"joins"})
_JOIN_SAFE_OPS = frozenset({"equals", "in", "greater_than", "greater_equals",
                            "less_than", "less_equals"})


def _join_source(node: Any, table_name: str, exp: Any) -> Tuple[Any, str]:
    """``(the Table node for table_name, '')`` when the scope's FROM + JOINs
    read it exactly once, bare, every joined source a plain table."""
    src = _arg(node, *_FROM_KEYS)
    sources = [src.this] if src is not None else []
    for j in node.args.get("joins") or []:
        if not isinstance(j, exp.Join):
            return None, "join_not_a_join"
        sources.append(j.this)
    mine = []
    for t in sources:
        if not isinstance(t, exp.Table) or not isinstance(t.this, exp.Identifier):
            return None, "joined_source_not_a_bare_table"
        if any(v for k, v in t.args.items() if k not in _ALLOWED_TABLE_ARGS):
            return None, "table_modifier"
        if t.name.lower() == (table_name or "").lower():
            if t.db or t.catalog:
                return None, "from_qualified"
            mine.append(t)
    if len(mine) != 1:
        return None, ("table_referenced_more_than_once" if mine else "table_not_read")
    return mine[0], ""


def _where_scope(tree: Any, table_name: str, exp: Any) -> Tuple[Any, str, str, bool]:
    """Descend through output-consuming wrappers to the ONE SELECT that
    reads ``table_name`` bare -- alone, or (2026-10-29) once among its JOINs;
    ``(scope, '', alias, joined)``, or ``(None, reason, '', False)``."""
    refs = [t for t in tree.find_all(exp.Table)
            if isinstance(t.this, exp.Identifier) and t.name.lower() == (table_name or "").lower()]
    if len(refs) > 1:
        return None, "table_referenced_more_than_once", "", False
    # several tables, this one among them: the JOIN scope; none of them this
    # one: the single-table walk below names what the FROM is instead
    joined = len(list(tree.find_all(exp.Table))) > 1 and len(refs) == 1
    node = tree
    for _ in range(8):
        if not isinstance(node, exp.Select):
            return None, f"not_a_single_select:{type(node).__name__}", "", False
        src = _arg(node, *_FROM_KEYS)
        src = src.this if src is not None else None
        wrapper = isinstance(src, exp.Subquery)
        allowed = _WRAPPER_ARGS if wrapper else (_JOIN_SCOPE_ARGS if joined else _WHERE_SCOPE_ARGS)
        bad = next((k for k, v in node.args.items() if v and k not in allowed), None)
        if bad:
            return None, f"clause_not_allowed:{bad}", "", False
        if not wrapper:
            if joined:
                mine, reason = _join_source(node, table_name, exp)
                if reason:
                    return None, reason, "", False
                if any(n is not node for n in node.find_all(exp.Select)) or node.find(exp.Subquery):
                    return None, "subquery", "", False
                return node, "", (mine.alias or ""), True
            reason = _scope_reason(node, table_name, exp)
            if reason:
                return None, reason, "", False
            return node, "", (src.alias or ""), False
        node = src.this
    return None, "nested_too_deep", "", False


def _conjuncts(where_node: Any, exp: Any) -> List[Any]:
    """The top-level AND-ed terms of a WHERE, parentheses stripped."""
    out, stack = [], [where_node.this]
    while stack:
        n = stack.pop()
        if isinstance(n, exp.And):
            stack.extend((n.right, n.left))
        elif isinstance(n, exp.Paren):
            stack.append(n.this)
        else:
            out.append(n)
    return out


def _literal(node: Any, reader: Any) -> Any:
    """The literal's value as the extractor spells it, or None."""
    return reader(node) if node is not None else None


def _bare(node: Any, table_name: str, alias: str, exp: Any, strict: bool = False) -> Optional[str]:
    """The lower-cased name of a bare, own column reference, else None.
    ``strict`` (a JOIN scope): the column must be QUALIFIED with the table
    or its alias -- an unqualified name is ambiguous between the sides."""
    if isinstance(node, exp.Column) and isinstance(node.this, exp.Identifier) \
            and _own(node.table, table_name, alias) and not (strict and not node.table):
        return node.name.lower()
    return None


def _or_as_in(node: Any, table_name: str, alias: str, exp: Any, reader: Any) -> Optional[tuple]:
    """``c = a OR c = b`` on ONE bare column -> the ``in`` key the extractor
    collapses it to; None for any other disjunction."""
    col, vals = None, []
    stack = [node]
    while stack:
        n = stack.pop()
        if isinstance(n, exp.Or):
            stack.extend((n.right, n.left))
            continue
        if not isinstance(n, exp.EQ):
            return None
        c = _bare(n.left, table_name, alias, exp)
        v = _literal(n.right, reader)
        if c is None or v is None or isinstance(v, list) or (col not in (None, c)):
            return None
        col, vals = c, vals + [v]
    return (col, "in", tuple(str(v) for v in vals)) if col else None


def _in_key(col: str, inner: Any, negated: bool, reader: Any) -> List[tuple]:
    if inner.args.get("query"):
        return []
    vals = [_literal(e, reader) for e in inner.expressions]
    if not vals or any(v is None for v in vals):
        return []
    flat = [x for v in vals for x in (v if isinstance(v, list) else [v])]
    return [(col, "not_in" if negated else "in", tuple(str(v) for v in flat))]


def _between_key(col: str, inner: Any, negated: bool, reader: Any) -> List[tuple]:
    lo = _literal(inner.args.get("low"), reader)
    hi = _literal(inner.args.get("high"), reader)
    if lo is None or hi is None:
        return []
    if negated:
        return [(col, "not_between", (str(lo), str(hi)))]
    return [(col, "greater_equals", str(lo)), (col, "less_equals", str(hi))]


def _scalar(node: Any, reader: Any) -> Optional[str]:
    """A scalar literal's spelling, or None (a list is not a scalar)."""
    v = _literal(node, reader)
    return None if v is None or isinstance(v, list) else str(v)


def _range_key(inner: Any, op: str, table_name: str, alias: str, exp: Any,
               reader: Any, flip: Any, strict: bool = False) -> List[tuple]:
    """``column <op> literal`` either way round."""
    left = _bare(inner.left, table_name, alias, exp, strict)
    if left:
        v = _scalar(inner.right, reader)
        return [(left, op, v)] if v is not None else []
    right = _bare(inner.right, table_name, alias, exp, strict)
    if right:
        v = _scalar(inner.left, reader)
        return [(right, flip(op), v)] if v is not None else []
    return []


def _conjunct_keys(term: Any, table_name: str, alias: str, exp: Any,
                   reader: Any, flip: Any, strict: bool = False) -> List[tuple]:
    """The ``(col, op, value)`` key(s) one simple conjunct provably yields,
    spelled exactly as ``partition_filters_to_pruning_format`` spells them.
    ``strict`` (a JOIN scope): qualified columns and the positive operators
    only (``_JOIN_SAFE_OPS``)."""
    if isinstance(term, exp.Or):
        k = _or_as_in(term, table_name, alias, exp, reader) if not strict else None
        return [k] if k else []
    negated = isinstance(term, exp.Not)
    inner = term.this if negated else term
    col = _bare(getattr(inner, "this", None), table_name, alias, exp, strict)
    if col and isinstance(inner, exp.Is) and isinstance(inner.expression, exp.Null):
        keys = [(col, "is_not_null" if negated else "is_null", None)]
    elif col and isinstance(inner, exp.In):
        keys = _in_key(col, inner, negated, reader)
    elif col and isinstance(inner, exp.Between):
        keys = _between_key(col, inner, negated, reader)
    else:
        op = _RANGE_OPS.get(type(inner).__name__)
        if negated or not op:
            return []
        keys = _range_key(inner, op, table_name, alias, exp, reader, flip, strict)
    if strict:
        keys = [k for k in keys if k[1] in _JOIN_SAFE_OPS]
    return keys


def _disjunct_keys(or_node: Any, table_name: str, alias: str, exp: Any,
                   reader: Any, flip: Any) -> List[set]:
    """Per disjunct of a top-level OR (flattened left to right, parentheses
    stripped -- the extractor's own branch order), the provable keys of its
    AND-ed leaves.  A nested same-column OR inside a disjunct is the ``in``
    key the extractor collapses it to; any other nested OR yields no key, so
    a dict the extractor derived from it cannot be admitted."""
    disjuncts: List[Any] = []

    def _walk_or(n: Any) -> None:
        while isinstance(n, exp.Paren):
            n = n.this
        if isinstance(n, exp.Or):
            _walk_or(n.left)
            _walk_or(n.right)
        else:
            disjuncts.append(n)
    _walk_or(or_node)
    out: List[set] = []
    for d in disjuncts:
        leaves: List[Any] = []
        stack = [d]
        while stack:
            n = stack.pop()
            if isinstance(n, exp.And):
                stack.extend((n.right, n.left))
            elif isinstance(n, exp.Paren):
                stack.append(n.this)
            else:
                leaves.append(n)
        keys: set = set()
        for leaf in leaves:
            keys.update(_conjunct_keys(leaf, table_name, alias, exp, reader, flip))
        out.append(keys)
    return out


def _prove_or_groups(or_groups: Any, where: Any, provable: set, table_name: str,
                     alias: str, exp: Any, reader: Any, flip: Any) -> Tuple[list, str]:
    """``(branches, reason)``: the extractor's OR branches when EVERY dict of
    EVERY branch is a bare own-column leaf of that disjunct or a top-level
    conjunct; otherwise ``([], why)``.  Never raises."""
    if not or_groups:
        return [], ""
    or_terms = [t for t in _conjuncts(where, exp) if isinstance(t, exp.Or)]
    if len(or_terms) != 1:
        return [], f"top_level_or_terms:{len(or_terms)}"
    per_branch = _disjunct_keys(or_terms[0], table_name, alias, exp, reader, flip)
    if len(per_branch) != len(or_groups):
        return [], f"branch_count_mismatch:{len(per_branch)}!={len(or_groups)}"
    for i, branch in enumerate(or_groups):
        for d in branch or []:
            key = _dict_key(d)
            if key not in provable and key not in per_branch[i]:
                return [], (f"branch_{i}_dict_not_a_bare_own_column_leaf:"
                            f"{key[0]} {key[1]} {key[2]!r}")
        if not branch:
            return [], f"branch_{i}_empty"
    return [[dict(d) for d in b] for b in or_groups], ""


def _dict_key(d: Dict[str, Any]) -> tuple:
    """An extractor dict as a comparable ``(col, op, value)`` key."""
    v = d.get("val")
    if isinstance(v, (list, tuple)):
        value: Any = tuple(str(x) for x in v)
    elif v is None:
        value = None
    else:
        value = str(v)
    return (str(d.get("col") or "").lower(), d.get("op"), value)


def base_where_filters(base_query: str, table_name: str,
                       partition_columns: Optional[Sequence[str]]) -> WhereVerdict:
    """The base query's OWN top-level WHERE predicates on ``table_name``
    that may narrow its view's file list.  Never raises; a failed proof is
    a declined statement and the view reads every file as before."""
    try:
        import sqlglot
        from sqlglot import exp
        from core.sql_partition_extractor import (
            _extract_literal_value, _flip_operator,
            extract_combined_filters_and_or_groups_for_iceberg,
        )
        text = str(base_query or "").strip().rstrip(";")
        tree = sqlglot.parse_one(text, dialect="duckdb")
        scope, reason, alias, joined = _where_scope(tree, table_name, exp)
        if reason:
            return WhereVerdict(statement_reason=reason)
        where = scope.args.get("where")
        if where is None:
            return WhereVerdict(statement_reason="no_where")
        provable = set()
        for term in _conjuncts(where, exp):
            provable.update(_conjunct_keys(term, table_name, alias, exp,
                                           _extract_literal_value, _flip_operator,
                                           strict=joined))
        # THE extractor, on the scope's own SQL (the wrapper is already proven
        # to consume output only), with the registered partition columns.
        extracted, _or_groups = extract_combined_filters_and_or_groups_for_iceberg(
            scope.sql(dialect="duckdb"),
            {table_name: list(partition_columns or [])}, dialect="duckdb")
        # 2026-10-08: the OR branches, each dict proven a bare own-column
        # leaf of ITS disjunct (same proof as a conjunct, per branch).  In a
        # JOIN scope (2026-10-29) the branches are declined: a disjunct may
        # mix the sides, and the proof per branch is single-table.
        if joined:
            or_branches, or_reason = [], ("join_scope" if _or_groups else "")
        else:
            or_branches, or_reason = _prove_or_groups(
                _or_groups, where, provable, table_name, alias, exp,
                _extract_literal_value, _flip_operator)
    except Exception as exc:  # noqa: BLE001 - unparsed = unproven = declined
        return WhereVerdict(statement_reason=f"parse_failed:{type(exc).__name__}")
    # Attribution.  In the single-table scope every provable key came from a
    # column whose qualifier is that table or its alias, so the extractor's
    # ``table`` needs no check (a branch declining "another table" was
    # unreachable by construction, mutation-tested 2026-10-02).  In a JOIN
    # scope (2026-10-29) it is load-bearing: both of the owner's tables carry
    # ``business_close_date``, and the extractor also propagates a predicate
    # across the ON clause to the OTHER side -- a dict is admitted for THIS
    # table only when the extractor attributed it here.
    forwarded: List[Dict[str, Any]] = []
    declined: List[Tuple[str, str]] = []
    _mine = (table_name or "").lower()
    for d in extracted or []:
        key = _dict_key(d)
        if joined and str(d.get("table") or "").rsplit(".", 1)[-1].lower() != _mine:
            declined.append((f"{key[0]} {key[1]} {key[2]!r}", "attributed_to_another_table"))
        elif key in provable:
            forwarded.append(dict(d))
        else:
            declined.append((f"{key[0]} {key[1]} {key[2]!r}",
                             "not_a_top_level_bare_column_conjunct"
                             if not joined else "not_a_qualified_positive_conjunct"))
    return WhereVerdict(forwarded=forwarded, declined=declined,
                        or_groups=or_branches, or_reason=or_reason)
