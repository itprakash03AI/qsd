"""Filter at the SOURCE: a report parameter inside the dataset's own WHERE
(2026-10-29; docs/REPORT_SOURCE_FILTERS_2026_10_29.html).

The owner: "created dataset for reports is like hardcode values in where
clause for that query, it's not generic ... whatever where clause is there and
if user selects multiple values then that column should accept values as IN
clause and run directly on source ... two types of filter: filter data at
source and bring, and local filter."

A dataset's custom SQL carries literals in its WHERE::

    WHERE FACT_TETB.SYSTEM_ID IN ('SAPADB', 'MOTIFADJ')
      AND FACT_TETB.BUSINESS_CLOSE_DATE = CAST('2025-09-30' AS DATE)

A report on that dataset wraps the SQL from outside (``WITH qs_base AS (...)
SELECT .. WHERE <report filters>``), so until today a report could filter only
the formatted, already-grouped OUTPUT -- never those literals, and never a
column the query does not return (SYSTEM_ID).

This module makes the predicates of the WHERE *parameters*:

* :func:`discover` PARSES the SQL (sqlglot, never a regex) and lists each
  top-level AND-ed conjunct of the root SELECT's WHERE that is ``column <op>
  literal(s)`` as a :class:`SourcePredicate` -- its key (the column as the SQL
  spells it, lower-cased: ``fact_tetb.system_id``), its table (alias
  resolved), its operator, the literal values as text and their kind.  The
  literal IS the default: a report run without a value runs the query as
  written.
* :func:`apply` puts the values a report run supplies INTO those predicates:
  one value -> ``=``, several -> ``IN (...)``, a range -> ``BETWEEN``; the
  literal is rendered in the ORIGINAL literal's kind (a string quoted with its
  quotes doubled by sqlglot's own generator, a number that must parse as one,
  a DATE cast that must be an ISO date), and the new predicate's text is
  spliced into the author's SQL at the old conjunct's character span, so every
  other byte of the query is as written.  No binding -> the text untouched.
  An empty value NEVER removes the predicate (a partition predicate silently
  dropped would scan the ocean and return MORE rows); a predicate the SQL no
  longer has REFUSES (CLAUDE.md s4: a filter that cannot be rendered must
  refuse, never drop).
* :func:`split_filters` is how the federation engine tells a source binding
  (``{"source_column": key, ...}``) from a filter on an output column -- the
  ONE place the two kinds are told apart.

The decision (where a source parameter lives) is in the record: the
predicates are DERIVED from the dataset's SQL, never stored; the BINDING is a
report parameter's ``source_column``.  The dataset's SQL stays ONE text shared
by reports, published APIs, dashboards and feeds.
"""
from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from datetime import date as _date, datetime as _datetime
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

#: the key a filter dict carries when it binds a SOURCE predicate
SOURCE_KEY = "source_column"
#: the keys a source binding may carry
BINDING_KEYS = frozenset({SOURCE_KEY, "operator", "value", "value2"})

#: operators a predicate may have; ``in`` and ``eq`` take one value or many
COMPARISON_OPS = {"EQ": "eq", "NEQ": "neq", "GT": "gt", "GTE": "gte", "LT": "lt", "LTE": "lte"}
_FLIP = {"gt": "lt", "gte": "lte", "lt": "gt", "lte": "gte", "eq": "eq", "neq": "neq"}
_OP_WORDS = {"eq": "=", "neq": "<>", "gt": ">", "gte": ">=", "lt": "<", "lte": "<=",
             "in": "IN", "between": "BETWEEN"}

_DATE_KINDS = ("cast:DATE",)
_TIMESTAMP_PREFIXES = ("cast:TIMESTAMP", "cast:DATETIME")


class SourceFilterRefused(ValueError):
    """A source binding that cannot be rendered.  Always a sentence a support
    person can act on; the routes answer it as a 422."""


@dataclass(frozen=True)
class SourcePredicate:
    key: str                 #: ``fact_tetb.system_id`` (``#2`` suffixed when a column recurs)
    column: str              #: the column as spelled, ``SYSTEM_ID``
    qualifier: str           #: the qualifier as spelled, ``FACT_TETB`` ('' when bare)
    table: str               #: the real table's bare name, lower-cased ('' when unknown)
    table_ref: str           #: the table as the SQL spells it (``icbg.fins.fact_tetb``)
    op: str                  #: eq | in | between | gt | gte | lt | lte | neq
    values: Tuple[str, ...]  #: the literal(s) as text, in the query's order
    kind: str                #: string | number | boolean | cast:<TYPE>
    sql: str                 #: the conjunct as the query spells it
    index: int               #: its position among the WHERE's AND-ed conjuncts

    @property
    def is_date(self) -> bool:
        if self.kind in _DATE_KINDS:
            return True
        return self.kind == "string" and all(_iso_date(v) for v in self.values)

    @property
    def parameter_type(self) -> Optional[str]:
        """The report parameter type this predicate is offered as, or None
        when no parameter type carries its shape (a BETWEEN on a number)."""
        if self.op in ("eq", "in"):
            return "date" if self.is_date else "multi_select"
        if self.op == "between":
            return "date_range" if self.is_date else None
        if self.is_date:
            return "date"
        return "numeric" if self.kind == "number" else "text"

    @property
    def values_source(self) -> str:
        return "any" if self.is_date else "auto"

    @property
    def default_words(self) -> str:
        """Plain words for the screen: what the query uses without a value."""
        vals = ", ".join(self.values)
        if self.op == "between":
            return f"from {self.values[0]} to {self.values[1]}"
        if self.op in ("eq", "in"):
            return vals
        return f"{_OP_WORDS[self.op]} {vals}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key, "column": self.column, "qualifier": self.qualifier,
            "table": self.table, "table_ref": self.table_ref, "op": self.op, "values": list(self.values),
            "value_kind": self.kind, "sql": self.sql, "is_date": self.is_date,
            "parameter_type": self.parameter_type, "values_source": self.values_source,
            "offered": self.parameter_type is not None,
            "words": (f"Without a value the report uses what the query says: {self.default_words}"),
        }


@dataclass(frozen=True)
class Discovery:
    predicates: Tuple[SourcePredicate, ...] = ()
    declined: Tuple[Tuple[str, str], ...] = ()   #: (conjunct sql, why)
    reason: Optional[str] = None                 #: why NOTHING could be read

    def by_key(self) -> Dict[str, SourcePredicate]:
        return {p.key: p for p in self.predicates}

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"filters": [p.to_dict() for p in self.predicates],
                               "declined": [{"sql": s, "reason": r} for s, r in self.declined]}
        if self.reason:
            out["reason"] = self.reason
        return out


# ── reading the SQL ─────────────────────────────────────────────────────────

def _iso_date(text: str) -> bool:
    t = str(text or "")
    if len(t) < 10 or t[4] != "-" or t[7] != "-":
        return False
    try:
        _date.fromisoformat(t[:10])
    except ValueError:
        return False
    return True


def _conjuncts(where_node: Any, exp: Any) -> List[Any]:
    """The top-level AND-ed terms of a WHERE, parentheses stripped, in order."""
    out, stack = [], [where_node.this]
    while stack:
        n = stack.pop()
        if isinstance(n, exp.And):
            stack.extend((n.right, n.left))
        elif isinstance(n, exp.Paren):
            stack.append(n.this)
        else:
            out.append(n)
    return out


def _literal(node: Any, exp: Any, dialect: Optional[str]) -> Optional[Tuple[str, str]]:
    """``(text, kind)`` for a literal node, else None."""
    if isinstance(node, exp.Literal):
        return (str(node.this), "string" if node.is_string else "number")
    if isinstance(node, exp.Neg) and isinstance(node.this, exp.Literal) and not node.this.is_string:
        return (f"-{node.this.this}", "number")
    if isinstance(node, exp.Boolean):
        return ("true" if node.this else "false", "boolean")
    if isinstance(node, (exp.Cast, exp.TryCast)) and isinstance(node.this, exp.Literal) \
            and node.this.is_string and node.args.get("to") is not None:
        return (str(node.this.this), f"cast:{node.args['to'].sql(dialect=dialect).upper()}")
    # typed literals some dialects parse as wrapper nodes (DATE '..')
    if type(node).__name__ in ("Date", "DateStr") and isinstance(getattr(node, "this", None), exp.Literal):
        return (str(node.this.this), "cast:DATE")
    if type(node).__name__ in ("Timestamp", "TimeStr") and isinstance(getattr(node, "this", None), exp.Literal):
        return (str(node.this.this), "cast:TIMESTAMP")
    return None


def _column(node: Any, exp: Any) -> Optional[Tuple[str, str]]:
    """``(column, qualifier)`` as spelled for a bare column reference."""
    if isinstance(node, exp.Column) and isinstance(node.this, exp.Identifier):
        return (node.name, node.table or "")
    return None


def _alias_map(select: Any, exp: Any, dialect: Optional[str]) -> Tuple[Dict[str, Tuple[str, str]], str]:
    """``{alias_or_table_lower: (table_bare_lower, table as spelled)}`` for the
    root FROM / JOINs, and the one table's alias-or-name when the scope reads
    exactly one (else '')."""
    out: Dict[str, Tuple[str, str]] = {}
    tables: List[str] = []
    frm = select.args.get("from_") or select.args.get("from")
    nodes = [frm.this] if frm is not None else []
    for j in select.args.get("joins") or []:
        nodes.append(j.this)
    for t in nodes:
        if not isinstance(t, exp.Table):
            continue
        bare = str(t.name or "").lower()
        if not bare:
            continue
        ref = exp.Table(this=t.this, db=t.args.get("db"), catalog=t.args.get("catalog")).sql(dialect=dialect)
        tables.append(bare)
        out[bare] = (bare, ref)
        if t.alias:
            out[str(t.alias).lower()] = (bare, ref)
    return out, (tables[0] if len(tables) == 1 else "")


def _classify(term: Any, exp: Any, dialect: Optional[str]) -> Tuple[Optional[Dict[str, Any]], str]:
    """One conjunct -> ``(predicate fields, '')`` or ``(None, why declined)``."""
    if isinstance(term, exp.Or):
        return None, "an OR: the report cannot replace one branch of it"
    if isinstance(term, exp.Not):
        return None, "a NOT: not offered"
    if isinstance(term, exp.In):
        col = _column(term.this, exp)
        if not col:
            return None, "the left side is not a plain column"
        if term.args.get("query") is not None or not term.expressions:
            return None, "IN over a subquery: not offered"
        lits = [_literal(e, exp, dialect) for e in term.expressions]
        if any(l is None for l in lits):
            return None, "a value in the IN list is not a literal"
        kinds = {k for _, k in lits}
        if len(kinds) != 1:
            return None, "the IN list mixes kinds of literal"
        return {"col": col, "op": "in", "values": tuple(t for t, _ in lits), "kind": kinds.pop()}, ""
    if isinstance(term, exp.Between):
        col = _column(term.this, exp)
        lo, hi = _literal(term.args.get("low"), exp, dialect), _literal(term.args.get("high"), exp, dialect)
        if not col:
            return None, "the left side is not a plain column"
        if lo is None or hi is None or lo[1] != hi[1]:
            return None, "a BETWEEN bound is not a literal"
        return {"col": col, "op": "between", "values": (lo[0], hi[0]), "kind": lo[1]}, ""
    op = COMPARISON_OPS.get(type(term).__name__)
    if not op:
        return None, "not 'column <op> value'"
    col, lit = _column(term.left, exp), _literal(term.right, exp, dialect)
    if col is None or lit is None:
        col2, lit2 = _column(term.right, exp), _literal(term.left, exp, dialect)
        if col2 is None or lit2 is None:
            if _column(term.left, exp) and _column(term.right, exp):
                return None, "a column on both sides"
            return None, ("the column is inside a function or expression"
                          if term.find(exp.Column) is not None else "no column")
        col, lit, op = col2, lit2, _FLIP[op]
    return {"col": col, "op": op, "values": (lit[0],), "kind": lit[1]}, ""


def discover(sql: str, dialect: Optional[str] = None) -> Discovery:
    """The source predicates of ``sql``'s root SELECT WHERE.  Never raises."""
    try:
        import sqlglot
        from sqlglot import exp
    except Exception as exc:                                   # pragma: no cover
        return Discovery(reason=f"sqlglot is not available: {exc}")
    text = str(sql or "").strip().rstrip(";")
    if not text:
        return Discovery(reason="The dataset has no SQL of its own.")
    try:
        tree = sqlglot.parse_one(text, read=dialect)
    except Exception as exc:                                   # noqa: BLE001
        return Discovery(reason=f"The dataset's SQL could not be read: {str(exc).splitlines()[0][:200]}")
    if not isinstance(tree, exp.Select):
        return Discovery(reason=f"The dataset's SQL is not a single SELECT ({type(tree).__name__}), "
                                "so its conditions cannot be offered as parameters.")
    where = tree.args.get("where")
    if where is None:
        return Discovery(reason="The dataset's SQL has no WHERE, so there is no condition to open up.")
    aliases, single = _alias_map(tree, exp, dialect)
    predicates: List[SourcePredicate] = []
    declined: List[Tuple[str, str]] = []
    seen: Dict[str, int] = {}
    for i, term in enumerate(_conjuncts(where, exp)):
        fields, why = _classify(term, exp, dialect)
        shown = term.sql(dialect=dialect)
        if fields is None:
            declined.append((shown, why))
            continue
        column, qualifier = fields["col"]
        base_key = f"{qualifier}.{column}".lower() if qualifier else column.lower()
        n = seen.get(base_key, 0) + 1
        seen[base_key] = n
        key = base_key if n == 1 else f"{base_key}#{n}"
        table, table_ref = aliases.get(qualifier.lower() if qualifier else single,
                                       (qualifier.lower(), qualifier))
        predicates.append(SourcePredicate(
            key=key, column=column, qualifier=qualifier, table=table, table_ref=table_ref, op=fields["op"],
            values=tuple(fields["values"]), kind=fields["kind"], sql=shown, index=i))
    return Discovery(predicates=tuple(predicates), declined=tuple(declined))


_MEMO: Dict[Tuple[str, str], Discovery] = {}


def discover_cached(sql: str, dialect: Optional[str] = None) -> Discovery:
    """:func:`discover`, memoised by the text's digest (a pure function; the
    owner's 352-line query parses in tens of milliseconds, paid once)."""
    key = (hashlib.sha256(str(sql or "").encode("utf-8")).hexdigest(), str(dialect or ""))
    hit = _MEMO.get(key)
    if hit is None:
        if len(_MEMO) > 256:
            _MEMO.clear()
        hit = _MEMO[key] = discover(sql, dialect)
    return hit


# ── the bindings a run supplies ─────────────────────────────────────────────

def is_source_binding(f: Any) -> bool:
    return isinstance(f, dict) and bool(f.get(SOURCE_KEY))


def split_filters(raw: Optional[Iterable[Any]]) -> Tuple[List[Dict[str, Any]], List[Any]]:
    """``(source bindings, the other filters)``.  A binding with a key this
    module does not know is refused here, so a misspelt ``values`` can never
    pass as an empty one (the engine's own rule for its filters)."""
    bindings: List[Dict[str, Any]] = []
    rest: List[Any] = []
    for f in raw or []:
        if is_source_binding(f):
            unknown = sorted(set(f) - BINDING_KEYS)
            if unknown:
                raise SourceFilterRefused(
                    f"The source filter on {f.get(SOURCE_KEY)!r} carries key(s) {unknown} this "
                    f"report does not understand; it takes {sorted(BINDING_KEYS)}.")
            bindings.append(f)
        else:
            rest.append(f)
    return bindings, rest


def _values_of(binding: Dict[str, Any]) -> List[str]:
    v = binding.get("value")
    if isinstance(v, dict):
        v = [v.get("from"), v.get("to")]
    if isinstance(v, (list, tuple)):
        items = list(v)
    else:
        items = [v]
    if binding.get("value2") not in (None, ""):
        items.append(binding["value2"])
    return [str(x) for x in items if x is not None and str(x).strip() != ""]


def _range_of(binding: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    v = binding.get("value")
    if isinstance(v, dict):
        lo, hi = v.get("from"), v.get("to")
    elif isinstance(v, (list, tuple)):
        lo = v[0] if len(v) > 0 else None
        hi = v[1] if len(v) > 1 else binding.get("value2")
    else:
        lo, hi = v, binding.get("value2")
    clean = lambda x: None if x is None or str(x).strip() == "" else str(x)   # noqa: E731
    return clean(lo), clean(hi)


def _render_literal(text: str, pred: SourcePredicate, label: str, exp: Any, dialect: Optional[str]) -> Any:
    """A literal node of the predicate's ORIGINAL kind, or a refusal."""
    kind = pred.kind
    t = str(text).strip()
    if kind == "string":
        return exp.Literal.string(t)
    if kind == "number":
        try:
            float(t)
        except (TypeError, ValueError):
            raise SourceFilterRefused(f"{label} takes a number; {text!r} is not one.")
        return exp.Literal.number(t)
    if kind == "boolean":
        return exp.Boolean(this=t.lower() in ("true", "1", "yes", "y"))
    if kind.startswith("cast:"):
        to_type = kind[len("cast:"):]
        if kind in _DATE_KINDS:
            if not _iso_date(t):
                raise SourceFilterRefused(f"{label} takes a date as YYYY-MM-DD; {text!r} is not one.")
            t = t[:10]
        elif kind.startswith(_TIMESTAMP_PREFIXES):
            try:
                _datetime.fromisoformat(t.replace("T", " ").replace("Z", ""))
            except ValueError:
                raise SourceFilterRefused(f"{label} takes a date and time (YYYY-MM-DD HH:MM:SS); "
                                          f"{text!r} is not one.")
        return exp.Cast(this=exp.Literal.string(t), to=exp.DataType.build(to_type, dialect=dialect))
    raise SourceFilterRefused(f"{label}: a literal of kind {kind!r} cannot be rendered.")   # pragma: no cover


def _new_predicate(pred: SourcePredicate, binding: Dict[str, Any], exp: Any,
                   dialect: Optional[str]) -> Optional[Any]:
    """The replacement node, or None when the binding supplies no value."""
    label = f"The source filter on {pred.qualifier + '.' if pred.qualifier else ''}{pred.column}"
    col = exp.column(pred.column, table=pred.qualifier or None)
    if pred.op == "between":
        lo, hi = _range_of(binding)
        if lo is None and hi is None:
            return None
        lo_node = _render_literal(lo if lo is not None else pred.values[0], pred, label, exp, dialect)
        hi_node = _render_literal(hi if hi is not None else pred.values[1], pred, label, exp, dialect)
        return exp.Between(this=col, low=lo_node, high=hi_node)
    values = _values_of(binding)
    if not values:
        return None
    if pred.op in ("eq", "in"):
        lits = [_render_literal(v, pred, label, exp, dialect) for v in values]
        if len(lits) == 1:
            return exp.EQ(this=col, expression=lits[0])
        return exp.In(this=col, expressions=lits)
    if len(values) != 1:
        raise SourceFilterRefused(f"{label} compares with {_OP_WORDS[pred.op]} and takes ONE value; "
                                  f"{len(values)} were given.")
    cls = {"neq": exp.NEQ, "gt": exp.GT, "gte": exp.GTE, "lt": exp.LT, "lte": exp.LTE}[pred.op]
    return cls(this=col, expression=_render_literal(values[0], pred, label, exp, dialect))


_CLAUSE_END = ("GROUP_BY", "ORDER_BY", "HAVING", "LIMIT", "OFFSET", "QUALIFY", "WINDOW",
               "UNION", "INTERSECT", "EXCEPT", "FETCH", "SEMICOLON", "FOR")


def _conjunct_spans(text: str, dialect: Optional[str], conjuncts: List[Any],
                    exp: Any) -> Optional[List[Tuple[int, int]]]:
    """The character span of each top-level WHERE conjunct, in AST order, or
    None when the proof fails (then the caller regenerates the statement)."""
    try:
        import sqlglot
        from sqlglot.tokens import TokenType as T
        toks = sqlglot.tokenize(text, read=dialect)
    except Exception:                                          # noqa: BLE001
        return None
    ends = {getattr(T, n) for n in _CLAUSE_END if hasattr(T, n)}
    depth = 0
    where_at = None
    for i, tok in enumerate(toks):
        if tok.token_type == T.L_PAREN:
            depth += 1
        elif tok.token_type == T.R_PAREN:
            depth -= 1
        elif tok.token_type == T.WHERE and depth == 0:
            if where_at is not None:
                return None
            where_at = i
    if where_at is None:
        return None
    pieces: List[List[Any]] = [[]]
    depth = 0
    pending_between = 0
    for tok in toks[where_at + 1:]:
        if depth == 0 and tok.token_type in ends:
            break
        if tok.token_type == T.L_PAREN:
            depth += 1
        elif tok.token_type == T.R_PAREN:
            depth -= 1
        elif depth == 0 and tok.token_type == T.BETWEEN:
            pending_between += 1
        elif depth == 0 and tok.token_type == T.AND:
            if pending_between:
                pending_between -= 1
            else:
                pieces.append([])
                continue
        pieces[-1].append(tok)
    if any(not p for p in pieces) or len(pieces) != len(conjuncts):
        return None
    spans: List[Tuple[int, int]] = []
    for piece, node in zip(pieces, conjuncts):
        start, end = piece[0].start, piece[-1].end + 1
        try:
            parsed = sqlglot.parse_one(text[start:end], read=dialect)
        except Exception:                                      # noqa: BLE001
            return None
        while isinstance(parsed, exp.Paren):
            parsed = parsed.this
        if parsed.sql(dialect=dialect) != node.sql(dialect=dialect):
            return None
        spans.append((start, end))
    return spans


def apply(sql: str, dialect: Optional[str], bindings: Sequence[Dict[str, Any]]) -> str:
    """``sql`` with every bound predicate replaced.  Raises
    :class:`SourceFilterRefused`; with no effective binding returns ``sql``
    untouched (byte-identical)."""
    if not bindings:
        return sql
    disc = discover(sql, dialect)
    if disc.reason:
        raise SourceFilterRefused(
            f"The report's source filters cannot be applied: {disc.reason}")
    by_key = disc.by_key()
    import sqlglot
    from sqlglot import exp
    replacements: Dict[int, Any] = {}
    for b in bindings:
        key = str(b.get(SOURCE_KEY) or "").strip().lower()
        pred = by_key.get(key)
        if pred is None:
            raise SourceFilterRefused(
                f"The report's source filter {key!r} is not a condition of the dataset's query any "
                f"more. Conditions the query has: {', '.join(sorted(by_key)) or '(none)'}. Remove "
                f"the parameter or bind it to one of these; the report is not run unfiltered.")
        node = _new_predicate(pred, b, exp, dialect)
        if node is None:
            continue                       # no value: the query's own literal stands
        if pred.index in replacements:
            raise SourceFilterRefused(
                f"The source filter {key!r} was given twice in one run.")
        replacements[pred.index] = node
    if not replacements:
        return sql
    text = str(sql)
    body = text.rstrip()
    trailing = text[len(body):]
    semi = ""
    if body.endswith(";"):
        body, semi = body[:-1], ";"
    tree = sqlglot.parse_one(body, read=dialect)
    conjuncts = _conjuncts(tree.args["where"], exp)
    spans = _conjunct_spans(body, dialect, conjuncts, exp)
    if spans is not None:
        out = body
        for idx in sorted(replacements, reverse=True):
            start, end = spans[idx]
            out = out[:start] + replacements[idx].sql(dialect=dialect) + out[end:]
        return out + semi + trailing
    # the spans could not be proven (a nested AND group, a second depth-0
    # WHERE): the statement is regenerated by sqlglot in the same dialect
    logger.info("[source-filters] conjunct spans not provable; the statement is regenerated")
    for idx, node in replacements.items():
        conjuncts[idx].replace(node)
    return tree.sql(dialect=dialect) + semi + trailing


def bound_summary(bindings: Sequence[Dict[str, Any]]) -> str:
    """One line for the log: which predicates were bound, with how many values."""
    parts = []
    for b in bindings:
        vals = _values_of(b)
        parts.append(f"{b.get(SOURCE_KEY)}={len(vals)} value(s)")
    return ", ".join(parts)


def reset_for_tests() -> None:
    _MEMO.clear()


__all__ = [
    "SOURCE_KEY", "BINDING_KEYS", "SourceFilterRefused", "SourcePredicate", "Discovery",
    "discover", "discover_cached", "is_source_binding", "split_filters", "apply",
    "bound_summary", "reset_for_tests",
]
