/**
 * Report authoring model — the EXACT field shapes the backend persists and
 * renders, plus a client-side mirror of the conditional-format evaluator.
 *
 * Backend sources of truth (read, not guessed):
 *  - `backend/api/business_reports_api.py` ReportCreate/ReportUpdate:
 *      section_definitions: List[dict]   — {name, break_column_id,
 *          subtotal_measure_ids, show_count} (seeded sample reports use
 *          exactly these keys; the banded-PDF renderer resolves ids against
 *          dataset columns).  `page_break` is the per-section page-break
 *          flag for the banded PDF export.
 *      running_calculations: List[dict]  — {name, calc_type, measure_col_id,
 *          partition_col_id, format_pattern}; calc_type is one of
 *          running_sum | rank | percent_of_total | previous_value
 *          (`_running_calc_defs_for_export` refuses anything else, refuses a
 *          name colliding with a result column, and skips a measure/partition
 *          not present in the exported columns).
 *      metric_ids: List[int]             — top-level field on create/update;
 *          the backend validates it loudly (unknown metric, wrong dataset,
 *          inactive, alias collision, pivot/merged/custom-SQL refusals) and
 *          folds it into layout_config.metric_ids itself.
 *  - `_extract_style_and_formats` reads layout_config.style_config keys:
 *      header_bg, header_text, negative_format ('brackets'|'minus'|'red'),
 *      stripe_rows; the viewer additionally reads accent_color, subtotal_bg,
 *      grand_total_bg.  show_grand_total gates the grand-total band.
 *  - `_extract_fmt_rules` + `pdf_export_api._apply_conditional_formats` read
 *      style_config.conditional_formats: [{column_name, condition_type,
 *      condition_value, bg_color, text_color, bold, is_enabled, rule_order}]
 *      — rules are per-column, sorted by rule_order, FIRST MATCH WINS.
 *  - Per-column format patterns live on the DATASET COLUMN
 *      (`DatasetColumn.format_pattern`, PUT /api/datasets/columns/{id}) —
 *      that is what the viewer, PDF/Excel exports and the delivery engine
 *      all read (col_fmt_map).  They are not a per-report override.
 */

// ── Persisted shapes ─────────────────────────────────────────────────────────

export interface AuthoringColumn {
  id: number;
  physical_name: string;
  friendly_name?: string;
  column_type?: string;     // 'dimension' | 'measure' | 'kpi' | ...
  data_type?: string;
  format_pattern?: string;
}

export interface SectionDefinition {
  name: string;
  break_column_id: number;
  subtotal_measure_ids: number[];
  show_count: boolean;
  /** Start a new PDF page when this (outer) group changes. */
  page_break?: boolean;
}

export type RunningCalcType =
  | 'running_sum' | 'rank' | 'percent_of_total' | 'previous_value';

export interface RunningCalculation {
  name: string;
  calc_type: RunningCalcType;
  measure_col_id: number;
  partition_col_id: number | null;
  format_pattern: string;
}

export type ConditionType =
  | 'value_range' | 'equals' | 'contains' | 'not_null' | 'is_null'
  | 'top_n' | 'bottom_n';

export interface ConditionalFormatRule {
  column_name: string;
  condition_type: ConditionType;
  /** value_range → {min?, max?}; equals/contains → {text}; others → null. */
  condition_value: Record<string, any> | null;
  bg_color: string | null;
  text_color: string | null;
  bold: boolean;
  is_enabled: boolean;
  rule_order: number;
}

export interface ReportStyleConfig {
  header_bg: string;
  header_text: string;
  accent_color: string;
  negative_format: 'brackets' | 'minus' | 'red';
  stripe_rows: boolean;
  subtotal_bg: string;
  grand_total_bg: string;
  /** Render the grand-total band (screen preview + banded exports). */
  show_grand_total: boolean;
}

/** Everything this panel authors, in one draft object. */
export interface AuthoringDraft {
  sections: SectionDefinition[];
  runningCalcs: RunningCalculation[];
  rules: ConditionalFormatRule[];
  style: ReportStyleConfig;
  metricIds: number[];
  /** dataset column id → format_pattern edits (dataset-level, see header). */
  columnFormatEdits: Record<number, string>;
}

// ── Vocabularies (mirror the backend registries, never invent members) ───────

export const CALC_TYPES: Array<{ value: RunningCalcType; label: string; help: string }> = [
  { value: 'running_sum', label: 'Running Sum', help: 'Cumulative sum, top to bottom (resets per partition)' },
  { value: 'rank', label: 'Rank', help: 'Dense rank by value, 1 = highest (per partition)' },
  { value: 'percent_of_total', label: '% of Total', help: 'Row value ÷ column total × 100 (per partition)' },
  { value: 'previous_value', label: 'Previous Value', help: 'Value from the previous row (per partition)' },
];

export const CONDITION_TYPES: Array<{
  value: ConditionType; label: string; needs: 'range' | 'text' | 'none' | 'n';
  help?: string;
}> = [
  { value: 'value_range', label: 'Value in range', needs: 'range' },
  { value: 'equals', label: 'Equals', needs: 'text' },
  { value: 'contains', label: 'Contains', needs: 'text' },
  { value: 'not_null', label: 'Is not empty', needs: 'none' },
  { value: 'is_null', label: 'Is empty', needs: 'none' },
  // 2026-10-24 -- RANKED over the whole result (backend core/reports/format_rules.py):
  // the N largest / smallest numbers of the column, ties included.
  { value: 'top_n', label: 'Top N values', needs: 'n',
    help: 'The N largest numbers in the whole column (not just this page), ties included.' },
  { value: 'bottom_n', label: 'Bottom N values', needs: 'n',
    help: 'The N smallest numbers in the whole column (not just this page), ties included.' },
];

export const FORMAT_PRESETS: Array<{ value: string; label: string }> = [
  { value: '', label: 'None (raw value)' },
  { value: '$#,##0', label: 'Currency ($1,235)' },
  { value: '$#,##0.00', label: 'Currency ($1,234.56)' },
  { value: '#,##0', label: 'Integer (1,234)' },
  { value: '#,##0.00', label: 'Decimal (1,234.56)' },
  { value: '0%', label: 'Percent (12%)' },
  { value: '0.00%', label: 'Percent (12.34%)' },
  { value: 'YYYY-MM-DD', label: 'Date (2026-01-15)' },
];

export const DEFAULT_STYLE: ReportStyleConfig = {
  // Same defaults `_extract_style_and_formats` falls back to.
  header_bg: '#1976D2',
  header_text: '#FFFFFF',
  accent_color: '#1565C0',
  negative_format: 'brackets',
  stripe_rows: true,
  subtotal_bg: '#f5f5f5',
  grand_total_bg: '#e8eaf6',
  show_grand_total: true,
};

// Colors are interpolated into inline styles / openpyxl fills server-side;
// the backend drops anything failing ^#?[0-9a-zA-Z]{2,20}$ from the rule.
export const SAFE_COLOR_RE = /^#?[0-9a-zA-Z]{2,20}$/;

// ── Draft ⇄ report mapping ──────────────────────────────────────────────────

const asBool = (v: any, dflt: boolean): boolean => (v === undefined || v === null ? dflt : Boolean(v));

export function draftFromReport(report: any): AuthoringDraft {
  const lc = report?.layout_config || {};
  const sc = lc.style_config || {};
  const rawRules: any[] = Array.isArray(sc.conditional_formats) ? sc.conditional_formats : [];
  return {
    sections: (report?.section_definitions || []).map((s: any) => ({
      name: String(s?.name ?? ''),
      break_column_id: Number(s?.break_column_id),
      subtotal_measure_ids: Array.isArray(s?.subtotal_measure_ids)
        ? s.subtotal_measure_ids.map(Number) : [],
      show_count: asBool(s?.show_count, false),
      page_break: asBool(s?.page_break, false),
    })),
    runningCalcs: (report?.running_calculations || []).map((c: any) => ({
      name: String(c?.name ?? ''),
      calc_type: c?.calc_type as RunningCalcType,
      measure_col_id: Number(c?.measure_col_id),
      partition_col_id: c?.partition_col_id == null ? null : Number(c.partition_col_id),
      format_pattern: String(c?.format_pattern ?? ''),
    })),
    rules: rawRules
      .filter((r: any) => r && typeof r === 'object')
      .map((r: any, i: number) => ({
        column_name: String(r.column_name ?? ''),
        condition_type: (r.condition_type ?? 'value_range') as ConditionType,
        condition_value: (r.condition_value && typeof r.condition_value === 'object')
          ? r.condition_value : null,
        bg_color: r.bg_color ?? null,
        text_color: r.text_color ?? null,
        bold: asBool(r.bold, false),
        is_enabled: asBool(r.is_enabled, true),
        rule_order: typeof r.rule_order === 'number' ? r.rule_order : i,
      }))
      .sort((a: ConditionalFormatRule, b: ConditionalFormatRule) => a.rule_order - b.rule_order),
    style: {
      header_bg: sc.header_bg ?? DEFAULT_STYLE.header_bg,
      header_text: sc.header_text ?? DEFAULT_STYLE.header_text,
      accent_color: sc.accent_color ?? DEFAULT_STYLE.accent_color,
      negative_format: sc.negative_format ?? DEFAULT_STYLE.negative_format,
      stripe_rows: asBool(sc.stripe_rows, DEFAULT_STYLE.stripe_rows),
      subtotal_bg: sc.subtotal_bg ?? DEFAULT_STYLE.subtotal_bg,
      grand_total_bg: sc.grand_total_bg ?? DEFAULT_STYLE.grand_total_bg,
      show_grand_total: asBool(sc.show_grand_total, DEFAULT_STYLE.show_grand_total),
    },
    metricIds: Array.isArray(lc.metric_ids) ? lc.metric_ids.map(Number) : [],
    columnFormatEdits: {},
  };
}

/**
 * The PUT body for /api/business-reports/{id}.
 *
 * ReportUpdate applies exactly the fields sent (exclude_unset), but
 * layout_config is replaced WHOLESALE by the ORM — so it is merged here from
 * the report's stored layout_config to keep chart_config / column_order /
 * report_type intact.  metric_ids travels as the DECLARED top-level field:
 * the backend validates it and folds it into layout_config itself (sending
 * it inside layout_config would bypass `_validate_metric_selection`).
 */
export function buildUpdatePayload(report: any, draft: AuthoringDraft): any {
  const prevLc = report?.layout_config || {};
  const prevSc = prevLc.style_config || {};
  const rules = draft.rules.map((r, i) => ({ ...r, rule_order: i }));
  return {
    section_definitions: draft.sections,
    running_calculations: draft.runningCalcs,
    metric_ids: draft.metricIds,
    layout_config: {
      ...prevLc,
      style_config: {
        ...prevSc,
        ...draft.style,
        conditional_formats: rules,
      },
    },
  };
}

// ── Client mirror of the conditional-format evaluator ────────────────────────
// Mirrors backend `pdf_export_api._apply_conditional_formats` so the live
// preview predicts the export: per-column rules sorted by rule_order,
// disabled rules skipped, FIRST MATCHING RULE WINS.  Python treats
// None/''/'None' as "empty"; the numeric probe is float() with failures → no
// numeric match.

export interface RuleCellStyle {
  backgroundColor?: string;
  color?: string;
  fontWeight?: 'bold';
  /** index (in the given rules array) of the rule that matched, for UI hints */
  matchedIndex?: number;
}

const isEmptyValue = (v: any): boolean => v === null || v === undefined || v === '' || v === 'None';

/** A ranking rule's cut-off key: `<column>#<rule_order>` (the server's). */
export const cutoffKey = (r: { column_name: string; rule_order: number }) =>
  `${r.column_name}#${r.rule_order}`;

/** Cut-offs for top / bottom N rules from the rows in hand (the preview, a
 *  client-side result).  A server-paged result uses the server's
 *  `format_cutoffs` (the whole result) instead. */
export function cutoffsFromRows(rules: ConditionalFormatRule[], rows: any[]): Record<string, number> {
  const out: Record<string, number> = {};
  for (const r of rules) {
    if (!r.is_enabled || (r.condition_type !== 'top_n' && r.condition_type !== 'bottom_n')) continue;
    const nums = rows.map(row => parseFloat(String(row?.[r.column_name])))
      .filter(n => !isNaN(n));
    if (!nums.length) continue;
    nums.sort((a, b) => (r.condition_type === 'top_n' ? b - a : a - b));
    const n = Math.max(1, Number(r.condition_value?.n) || 10);
    out[cutoffKey(r)] = nums[Math.min(n, nums.length) - 1];
  }
  return out;
}

export function evaluateRuleStyle(
  value: any,
  columnName: string,
  rules: ConditionalFormatRule[],
  cutoffs: Record<string, number> = {},
): RuleCellStyle {
  const colRules = rules
    .map((r, idx) => ({ r, idx }))
    .filter(({ r }) => r.column_name === columnName && r.is_enabled)
    .sort((a, b) => a.r.rule_order - b.r.rule_order);

  for (const { r, idx } of colRules) {
    const cv = r.condition_value || {};
    let numeric: number | null = null;
    if (!isEmptyValue(value)) {
      const n = parseFloat(String(value));
      if (!isNaN(n)) numeric = n;
    }
    let matched = false;
    switch (r.condition_type) {
      case 'value_range': {
        if (numeric !== null) {
          const lo = cv.min ?? null;
          const hi = cv.max ?? null;
          if (lo !== null && hi !== null) matched = numeric >= lo && numeric <= hi;
          else if (lo !== null) matched = numeric >= lo;
          else if (hi !== null) matched = numeric <= hi;
        }
        break;
      }
      case 'equals':
        matched = String(value) === String(cv.text ?? '');
        break;
      case 'contains':
        matched = String(value ?? '').includes(String(cv.text ?? ''));
        break;
      case 'not_null':
        matched = !isEmptyValue(value);
        break;
      case 'is_null':
        matched = isEmptyValue(value);
        break;
      case 'top_n':
      case 'bottom_n': {
        // RANKED against the column's cut-off (the export's rule); an
        // unknown cut-off matches nothing -- never every number.
        const cut = cutoffs[cutoffKey(r)];
        if (numeric !== null && cut !== undefined) {
          matched = r.condition_type === 'top_n' ? numeric >= cut : numeric <= cut;
        }
        break;
      }
      default:
        matched = false;
    }
    if (matched) {
      const style: RuleCellStyle = { matchedIndex: idx };
      if (r.bg_color && SAFE_COLOR_RE.test(r.bg_color)) style.backgroundColor = r.bg_color;
      if (r.text_color && SAFE_COLOR_RE.test(r.text_color)) style.color = r.text_color;
      if (r.bold) style.fontWeight = 'bold';
      return style;   // first matching rule wins — exactly like the export
    }
  }
  return {};
}

// ── Save-time pre-checks (the backend's export path SKIPS a broken calc with
// only a server log line — warn the author before that happens) ─────────────

export function validateDraft(
  draft: AuthoringDraft,
  columns: AuthoringColumn[],
): string[] {
  const problems: string[] = [];
  const colById = new Map(columns.map(c => [c.id, c]));
  const physicalNames = new Set(columns.map(c => c.physical_name));

  draft.sections.forEach((s, i) => {
    if (!s.break_column_id || !colById.has(s.break_column_id)) {
      problems.push(`Section ${i + 1}: pick a group-by column.`);
    }
  });

  const takenNames = new Set<string>(physicalNames);
  draft.runningCalcs.forEach((c, i) => {
    const label = c.name?.trim() ? `"${c.name.trim()}"` : `#${i + 1}`;
    if (!c.name?.trim()) {
      problems.push(`Running calculation #${i + 1}: name is required (exports skip unnamed calculations).`);
    } else if (takenNames.has(c.name.trim())) {
      problems.push(`Running calculation ${label}: the name collides with an existing column — exports would skip it.`);
    } else {
      takenNames.add(c.name.trim());
    }
    if (!c.measure_col_id || !colById.has(c.measure_col_id)) {
      problems.push(`Running calculation ${label}: pick a measure column.`);
    }
  });

  draft.rules.forEach((r, i) => {
    if (!r.column_name) {
      problems.push(`Formatting rule #${i + 1}: pick a column (the renderer skips rules without one).`);
    }
    if (r.condition_type === 'value_range') {
      const cv = r.condition_value || {};
      if (cv.min == null && cv.max == null) {
        problems.push(`Formatting rule #${i + 1}: a value range needs a min and/or a max.`);
      }
    }
    if ((r.condition_type === 'equals' || r.condition_type === 'contains')
        && !(r.condition_value && String(r.condition_value.text ?? '') !== '')) {
      problems.push(`Formatting rule #${i + 1}: "${r.condition_type}" needs a comparison text.`);
    }
    if (!r.bg_color && !r.text_color && !r.bold) {
      problems.push(`Formatting rule #${i + 1}: choose at least one effect (background, text colour, or bold).`);
    }
  });

  return problems;
}

/** Display label for a column id ("Region (region)" or just physical name). */
export function columnLabel(colId: number, columns: AuthoringColumn[]): string {
  const c = columns.find(x => x.id === colId);
  if (!c) return `column ${colId}`;
  return c.friendly_name && c.friendly_name !== c.physical_name
    ? `${c.friendly_name} (${c.physical_name})` : c.physical_name;
}

export function isNumericColumn(c: AuthoringColumn): boolean {
  const t = (c.column_type || '').toLowerCase();
  if (t === 'measure' || t === 'kpi') return true;
  const dt = (c.data_type || '').toLowerCase();
  return ['integer', 'int', 'bigint', 'float', 'double', 'decimal', 'numeric', 'number'].includes(dt);
}


// ── Report parameters: the editor's identity model ───────────────────────────
//
// 2026-09-03.  Cascading prompts did not work, and the cause was an
// IDENTITY problem in the builder, not in the cascade.
//
// A batch save REPLACES every parameter, so while the author is editing,
// the rows they see have no stable server id: the saved ones are about to
// be deleted and the new ones do not exist.  The builder handled that by
// letting "which parameter is my parent?" be answered with EITHER a real
// id (for rows loaded from the server) OR an array index (for rows just
// added), and resolving both through one lookup table keyed by both.
//
// Two namespaces in one map collide.  Ids start at 1 and indices at 0, so
// for any report whose parameters were created together — every report —
// the index keys were overwritten by id keys of the same integer, and the
// third parameter resolved its parent to ITSELF.  A self-dependent
// parameter filters its own dropdown by its own unset value, so it comes
// back empty; that is what "cascading params don't work" looked like.
//
// The fix is to stop overloading ids.  While editing, a parameter's
// identity is `_key`: a client-side string that no server id can equal.
// Server ids are translated in on load and positions are translated out
// on save, and neither is ever the editor's notion of identity.

export interface ParamRow {
  /** Editor identity.  Stable across rename, reorder and neighbour
   *  removal; never sent to the server, never compared against an id. */
  _key: string;
  /** The server id, when this row came from one.  Retained for reference
   *  only — a batch save replaces the row and mints a new id. */
  id?: number | null;
  name: string;
  label: string;
  parameter_type: string;
  /** The column this parameter FILTERS (and, by default, sources its
   *  values from).  Applies to every parameter type: the backend skips
   *  any parameter without it when building filters. */
  lov_column_id: number | null;
  /** Author-curated choices.  When set, the viewer picks from these
   *  instead of the column's distinct values. */
  static_values: string[] | null;
  /** 2026-10-23 -- where the viewer's choices come from: 'auto' (a saved
   *  list if any, else a partition column's values from the table's
   *  metadata, else the column's distinct values) | 'data' | 'metadata' |
   *  'static'.  The rule: backend core/reports/param_values.py. */
  values_source: ValuesSource;
  /** 2026-10-24 -- values_source 'table': ANOTHER table's column supplies
   *  the choices (a company master); the pick still filters lov_column_id. */
  lov_source_connection_id: number | null;
  lov_source_table: string;
  lov_source_column: string;
  /** 2026-10-24 -- values_source 'list': a NAMED value list synced into
   *  QueryStudio (backend core/value_lists.py). */
  value_list_id: number | null;
  /** 2026-10-29 -- FILTER AT THE SOURCE: the key of a condition in the
   *  dataset's own SQL WHERE ('fact_tetb.system_id'; backend
   *  core/source_filters.py).  The value goes INTO that condition and the
   *  query runs on the source; the literal in the SQL is the default.  Such
   *  a parameter has no lov_column_id. */
  source_column: string | null;
  /** The PARENT'S `_key` — not its id, and not its index. */
  depends_on_key: string | null;
  /** Which column the parent's value filters when re-fetching this
   *  parameter's list. */
  cascade_filter_column_id: number | null;
  default_value: string;
  description: string;
  is_required: boolean;
}

/** 'any' (2026-10-29): a DATE parameter takes any day on a calendar. */
export type ValuesSource = 'auto' | 'data' | 'metadata' | 'static' | 'table' | 'list' | 'any';
export const VALUES_SOURCES: ValuesSource[] = ['auto', 'data', 'metadata', 'static', 'table', 'list', 'any'];
const asValuesSource = (v: any): ValuesSource =>
  (VALUES_SOURCES as string[]).includes(String(v || '').toLowerCase())
    ? String(v).toLowerCase() as ValuesSource : 'auto';

let _paramKeySeq = 0;

/** A fresh editor identity.  The `p:` prefix is what makes it impossible
 *  to confuse with a numeric server id if the two ever meet. */
export function newParamKey(): string {
  _paramKeySeq += 1;
  return `p:${_paramKeySeq}`;
}

export function newParamRow(): ParamRow {
  return {
    _key: newParamKey(),
    id: null,
    name: '',
    label: '',
    parameter_type: 'dropdown',
    lov_column_id: null,
    static_values: null,
    values_source: 'auto',
    lov_source_connection_id: null,
    lov_source_table: '',
    lov_source_column: '',
    value_list_id: null,
    source_column: null,
    depends_on_key: null,
    cascade_filter_column_id: null,
    default_value: '',
    description: '',
    // 2026-10-25 (the owner: "it should run with any values"): a new parameter
    // left empty means ALL values; the author ticks Required when it must be set
    is_required: false,
  };
}

/** Server rows -> editor rows: ids in, `_key` out. */
export function paramRowsFromServer(list: any[] | undefined | null): ParamRow[] {
  const rows: ParamRow[] = (list || []).map((p: any) => ({
    _key: newParamKey(),
    id: p.id ?? null,
    name: p.name || '',
    label: p.label || '',
    parameter_type: p.parameter_type || 'dropdown',
    lov_column_id: p.lov_column_id ?? null,
    static_values: Array.isArray(p.static_values) && p.static_values.length
      ? p.static_values : null,
    values_source: asValuesSource(p.values_source),
    lov_source_connection_id: p.lov_source_connection_id ?? null,
    lov_source_table: p.lov_source_table || '',
    lov_source_column: p.lov_source_column || '',
    value_list_id: p.value_list_id ?? null,
    source_column: p.source_column || null,
    depends_on_key: null,
    cascade_filter_column_id: p.cascade_filter_column_id ?? null,
    default_value: p.default_value || '',
    description: p.description || '',
    is_required: p.is_required ?? true,
  }));
  // Second pass: every `_key` now exists, so parents can be resolved.
  const byId = new Map<number, string>();
  (list || []).forEach((p: any, i: number) => {
    if (p.id != null) byId.set(Number(p.id), rows[i]._key);
  });
  (list || []).forEach((p: any, i: number) => {
    if (p.depends_on_param_id != null) {
      // A parent that is not in this report's own parameter list is a
      // dangling reference; drop it rather than carry it back unchanged,
      // which would re-save a link to a row that no longer exists.
      rows[i].depends_on_key = byId.get(Number(p.depends_on_param_id)) || null;
    }
  });
  return rows;
}

/** Editor rows -> the batch-save payload.  The parent is named by
 *  POSITION, which is the only reference both sides can agree on before
 *  the ids exist; the backend resolves it inside the one transaction that
 *  creates them (`replace_report_parameters`). */
export function paramRowsToBatchItems(rows: ParamRow[]): any[] {
  const indexOfKey = new Map<string, number>();
  rows.forEach((r, i) => indexOfKey.set(r._key, i));
  return rows.map((p, i) => {
    const parent = p.depends_on_key != null
      ? indexOfKey.get(p.depends_on_key) : undefined;
    return {
      name: p.name,
      label: p.label,
      parameter_type: p.parameter_type,
      lov_column_id: p.lov_column_id || null,
      static_values: (p.static_values && p.static_values.length)
        ? p.static_values : null,
      values_source: p.values_source && p.values_source !== 'auto' ? p.values_source : null,
      // the other table travels only with its source (a stale pick is not saved)
      lov_source_connection_id: p.values_source === 'table' ? (p.lov_source_connection_id || null) : null,
      lov_source_table: p.values_source === 'table' ? (p.lov_source_table || null) : null,
      lov_source_column: p.values_source === 'table' ? (p.lov_source_column || null) : null,
      value_list_id: p.values_source === 'list' ? (p.value_list_id || null) : null,
      // filter at the source: the condition of the dataset's query it fills
      source_column: p.source_column || null,
      // A cascade needs BOTH halves: who the parent is, and which column
      // the parent's value filters.  Sending one without the other is a
      // configuration the backend ignores, so they travel together.
      depends_on_index: parent === undefined ? null : parent,
      cascade_filter_column_id: parent === undefined
        ? null : (p.cascade_filter_column_id || null),
      default_value: p.default_value || null,
      description: p.description || null,
      is_required: p.is_required ?? true,
      sort_order: i,
    };
  });
}

/** Remove one row and repair every reference to it.
 *
 *  A child left pointing at a removed parent used to keep a stale id that
 *  resolved to whatever row happened to take that number — a cascade
 *  filtered by the wrong column, with nothing to see in the UI. */
export function removeParamRow(rows: ParamRow[], idx: number): ParamRow[] {
  const goneKey = rows[idx]?._key;
  return rows
    .filter((_, i) => i !== idx)
    .map(r => (r.depends_on_key === goneKey
      ? { ...r, depends_on_key: null, cascade_filter_column_id: null }
      : r));
}
