#!/usr/bin/env bash
# QueryStudio — per-component Helm deploy wrapper.
# Usage: ./deploy.sh <env> [release-prefix]
#   env            dev | uat | prod  (matches env/<env>.yaml)
#   release-prefix Helm release prefix; defaults to "qs"
set -euo pipefail

ENV="${1:?usage: deploy.sh <env> [release-prefix]}"
PREFIX="${2:-qs}"
CHART_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VALS="${CHART_ROOT}/env/${ENV}.yaml"
[[ -f "${VALS}" ]] || { echo "missing ${VALS}"; exit 1; }

# 2026-09-27: the environment's SITE values -- the __SET_PER_ENV__ answers
# (AD server/groups, hosts) that live outside git.  Applied AFTER the
# reviewed env file so it can only fill placeholders, never redefine the
# reviewed topology.  Without it, every backend chart's render FAILS naming
# the placeholders it still carries (templates/_helpers.tpl qs.configJson);
# that is the intended stop, not a warning.
SITE="${CHART_ROOT}/env/${ENV}.site.yaml"
SITE_ARGS=()
if [[ -f "${SITE}" ]]; then
  SITE_ARGS=(-f "${SITE}")
  echo "[deploy] site values: ${SITE}"
else
  echo "[deploy] no ${SITE} -- placeholders in ${VALS} must be supplied with --set or the render fails"
fi

# Derive namespace from the env overlay (single source of truth).
NS="$(awk '/^namespace:/ {gsub(/"/, "", $2); print $2; exit}' "${VALS}")"
[[ -n "${NS}" ]] || { echo "namespace missing in ${VALS}"; exit 1; }
echo "[deploy] env=${ENV} ns=${NS} prefix=${PREFIX}"

deploy() {
  local name="$1"; local chart="$2"; shift 2
  echo "[deploy] -> ${PREFIX}-${name} (${chart})"
  helm upgrade --install "${PREFIX}-${name}" "${CHART_ROOT}/${chart}" \
    -f "${VALS}" "${SITE_ARGS[@]}" \
    --namespace "${NS}" \
    --create-namespace \
    --wait --timeout 10m \
    "$@"
}

# Order matters — api first (owns the shared NFS PVC + secrets by default).
# Each chart is self-contained; flip persistence.create / secrets.appSecret.create
# in values to move ownership elsewhere.
#
# 2026-10-25: every `deploy <name> <chart>` line names a chart directory that
# EXISTS here, and every chart directory is deployed unless it is declared
# disabled below -- backend/tests/test_deploy_script_matches_charts_2026_10_25.py
# holds both.  This list used to install `spark-connect` and `etl-polling`
# (no such charts in this tree: the Spark Connect server is the plain
# manifests under k8s/spark-connect/, ETL polling has no chart) and omitted
# `reports` and `downloads` -- so `helm upgrade --install` died on the first
# missing chart and the two surface pods were never installed by it.
deploy api            api
# worker (the multi-pod "Worker Pool"): RETIRED 2026-11-02, chart removed -- a
# heavy query goes to a query pod (query-pods below), the one road
# (docs/COMPONENT_RESPONSIBILITIES_2026_11_02.html §5).  `helm uninstall qs-worker`
# on an estate that still runs it.
deploy feed-worker    feed-worker
# job-worker (2026-11-02, core/responsibilities.py): the ONE worker tier for every
# background execution that is not a feed -- scheduled reports and deliveries,
# data-quality rules, pipelines, DataFlow, custom jobs, value lists, mirrors --
# and the claimer of task_queue rows.  It replaces the executor Deployment an
# environment ran from its own manifest (same process, new name).
deploy job-worker     job-worker
deploy scheduler      scheduler
# query-pods (2026-10-29): one Deployment per size from querystudio.query_pods
# in env/<env>.yaml; renders NOTHING until sizes are configured there.
deploy query-pods     query-pods
deploy published-api  published-api
# reports / downloads: the opt-in surface pods.  Installed, but they receive
# browser traffic only once their route.enabled is true with a dedicated host
# AND the ui chart's config.reportApiUrl / config.downloadApiUrl point at it
# (see each chart's values.yaml `route:` comment).
deploy reports        reports
deploy downloads      downloads
deploy ui             ui

echo "[deploy] all components installed in ${NS}"
helm list -n "${NS}" -f "^${PREFIX}-"
