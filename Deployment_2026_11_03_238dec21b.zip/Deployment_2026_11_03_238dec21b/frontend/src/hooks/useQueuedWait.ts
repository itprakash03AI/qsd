/**
 * H1 (2026-10-07) -- make a run's wait for a slot VISIBLE while its execute
 * POST is still pending, and cancellable.
 *
 * At the pod's global cap (or the user's own cap) the backend holds the
 * execute POST in a fair queue and tells the waiter its place over the
 * WebSocket (`execution_queued`).  But a screen learns its execution id only
 * from the POST's ANSWER -- and the POST is what waits -- so it could not
 * tell which queued event was its own, and the user saw a bare spinner for
 * up to `queue_wait_timeout_seconds`.  Cancel could not reach the wait
 * either: no id, and no execution row for `/api/executions/{id}/cancel`.
 *
 * The screen now mints a correlation id per run (`client_request_id`) and
 * sends it with the POST.  The backend echoes it in every `execution_queued`
 * event (delivered to this user's sockets only), and
 * `POST /api/execute/queued/cancel` ends the wait by it.
 *
 * One hook for the three screens that submit runs (BusinessQueryBuilder,
 * CompleteQueryBuilder, SqlQueryPage):
 *
 *   const qw = useQueuedWait();
 *   const sub = await qw.submit((crid) => api.executeQuery({ ...payload, client_request_id: crid }));
 *   if (sub.cancelled) { if (sub.current) resetSpinner(); return; }
 *   ...sub.response as before...
 *
 *   {qw.queued && <Alert role="status">{queuedWaitLabel(qw.queued)}</Alert>}
 *   onCancel: if (!qw.cancel()) api.cancelExecution(executionId)
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';

export interface QueuedWait {
  /** 1 = next to run. */
  position: number;
  /** How many wait in the same queue (>= position). */
  length: number;
  /** The server's words ("Waiting for server capacity -- 1 ahead of you"). */
  message: string;
  /** The server's id for the run (the POST's answer will carry the same). */
  executionId: string | null;
  /** 2026-11-01: the run waits for a QUERY POD (the POST answered with a job
   *  handle); `message` is the server's sentence and is shown as it is. */
  forQueryPod?: boolean;
}

/** How often a run waiting for a query pod asks how it is doing. */
export const QUERY_POD_POLL_MS = 2000;
/** Unreadable answers in a row before the screen says it lost track. */
const QUERY_POD_MAX_MISSES = 5;

/** The server's waiting sentence without the API hint it ends with. */
export function podWaitingWords(j: any): string {
  const raw = String(j?.waiting || j?.message || 'Waiting for a query pod');
  const at = raw.indexOf('Poll GET /api/jobs/');
  return (at < 0 ? raw : raw.slice(0, at)).trim().replace(/\.$/, '');
}

/** True when an execute POST answered "queued for a query pod": a job
 *  handle and no execution yet. */
export function isQueryPodHandle(r: any): boolean {
  return !!(r?.job_id && !r.execution_id && r.status === 'queued');
}

export interface SubmitOutcome<T> {
  /** The POST's answer; null when it failed after the user cancelled. */
  response: T | null;
  /** The run ended cancelled while it waited (by this user's Cancel, or the
   *  server answered `status: "cancelled"`) -- no execution to follow. */
  cancelled: boolean;
  /** This run is still the screen's run (not cancelled by the user, not
   *  superseded by a newer submit) -- only then may the caller touch the
   *  screen's state. */
  current: boolean;
}

/** A fresh correlation id: [A-Za-z0-9_-], <= 64 chars (the backend's pattern). */
export function newClientRequestId(): string {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
  } catch { /* fall through to the non-crypto id */ }
  return `cr-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
}

/** "Queued — position 2 of 3" -- one wording for every screen. */
export function queuedWaitLabel(w: QueuedWait): string {
  if (w.forQueryPod) return w.message;
  return `Queued — position ${w.position} of ${Math.max(w.length, w.position)}`;
}

/** The queued event for `clientRequestId`, or undefined when `msg` is not one. */
export function readQueuedEvent(msg: any, clientRequestId: string | null): QueuedWait | null | undefined {
  if (!msg || msg.type !== 'execution_queued' || !clientRequestId) return undefined;
  if (msg.client_request_id !== clientRequestId) return undefined;
  const position = Number(msg.data?.queue_position ?? 0);
  if (!(position > 0)) return null;                // 0 = the slot was granted
  const length = Number(msg.data?.queue_length ?? 0);
  return {
    position,
    length: Number.isFinite(length) && length >= position ? length : position,
    message: String(msg.data?.message ?? ''),
    executionId: msg.execution_id ? String(msg.execution_id) : null,
  };
}

/** The WebSocket context, or null outside a provider (H1 item 5).  Here the
 *  socket is an ACCELERATION: the POST is the source of truth, so a screen
 *  rendered without a provider (a dataset panel in a test, an embed) still
 *  runs -- it just cannot show the wait.  (`useOptionalWebSocket` is the
 *  same idea, but a test that mocks the context module with `useWebSocket`
 *  alone would make that import throw; `useWebSocket` always calls
 *  useContext before it throws, so the hook order is unchanged.) */
function useWebSocketIfAny(): ReturnType<typeof useWebSocket> | null {
  try {
    return useWebSocket();
  } catch {
    return null;
  }
}

export function useQueuedWait() {
  // The run whose POST is pending (null = none).  A ref, so the WebSocket
  // listener and a late POST answer read the CURRENT run, not a stale closure.
  const pendingRef = useRef<string | null>(null);
  // Runs the user cancelled while their POST was pending.
  const cancelledRef = useRef<Set<string>>(new Set());
  const [queued, setQueued] = useState<QueuedWait | null>(null);

  // H1 item 6 (2026-10-07): EVERY message, through the WebSocket context's
  // listener -- not `lastMessage`.  lastMessage is React state: two messages
  // in one tick render once, so a position update followed by any other
  // event (another run's progress, a heartbeat) was simply never seen.  The
  // listener is called once per message, in arrival order; the last
  // position set in a tick is the one on screen.
  const ws = useWebSocketIfAny();
  const addListener = (ws as { addListener?: unknown } | null)?.addListener;
  const lastMessage = ws?.lastMessage ?? null;
  const apply = useCallback((msg: unknown) => {
    const w = readQueuedEvent(msg, pendingRef.current);
    if (w !== undefined) setQueued(w);
  }, []);
  useEffect(() => {
    if (typeof addListener !== 'function') return undefined;
    return (addListener as (cb: (m: unknown) => void) => () => void)(apply);
  }, [addListener, apply]);
  // A context without a listener (a test double) still gets lastMessage.
  useEffect(() => {
    if (typeof addListener !== 'function') apply(lastMessage);
  }, [addListener, lastMessage, apply]);

  /** End the pending run's wait.  True when a POST was pending (the caller
   *  has nothing else to cancel); false when none was -- the caller cancels
   *  its execution id as before. */
  const cancel = useCallback((): boolean => {
    const id = pendingRef.current;
    if (!id) return false;
    pendingRef.current = null;
    cancelledRef.current.add(id);
    setQueued(null);
    api.cancelQueuedExecution(id).catch(() => { /* the POST's answer is the fallback */ });
    return true;
  }, []);

  const submit = useCallback(async <T extends { execution_id?: string; status?: string }>(
    post: (clientRequestId: string) => Promise<T>,
  ): Promise<SubmitOutcome<T>> => {
    cancel();                                    // a newer run supersedes a pending one
    const id = newClientRequestId();
    pendingRef.current = id;
    setQueued(null);
    const settle = (response: T | null): SubmitOutcome<T> => {
      const current = pendingRef.current === id;
      const userCancelled = cancelledRef.current.delete(id);
      if (current) {
        pendingRef.current = null;
        setQueued(null);
      }
      if (userCancelled && response?.execution_id && response.status !== 'cancelled') {
        // The wait was already over when Cancel arrived: the run started.
        // Its id is in this answer -- cancel THAT.
        api.cancelExecution(response.execution_id).catch(() => { /* fail-open */ });
      }
      return { response, cancelled: userCancelled || response?.status === 'cancelled', current };
    };
    // 2026-11-01 (query pods): a run priced for a query pod size may answer
    // with a JOB HANDLE and no execution -- it keeps its place in line.  Show
    // the server's sentence, follow the job until a pod starts it (then the
    // answer carries the execution id, as an inline run's does), and let
    // Cancel reach it while it waits.  Before this a screen set an undefined
    // execution id and spun with no words.
    const followQueryPod = async (first: T): Promise<T> => {
      if (!isQueryPodHandle(first)) return first;
      const jobId = String((first as any).job_id);
      const show = (j: any) => setQueued({
        position: Number(j?.position) || 0, length: Number(j?.position) || 0,
        message: podWaitingWords(j), executionId: null, forQueryPod: true,
      });
      const cancelled = (): T => {
        api.cancelQueryJob(jobId).catch(() => { /* the job's own lease ends it */ });
        return { status: 'cancelled' } as unknown as T;
      };
      show(first);
      let misses = 0;
      for (;;) {
        if (cancelledRef.current.has(id)) return cancelled();
        await new Promise((r) => setTimeout(r, QUERY_POD_POLL_MS));
        if (cancelledRef.current.has(id)) return cancelled();
        let j: any;
        try {
          j = await api.getQueryJob(jobId);
          misses = 0;
        } catch {
          misses += 1;
          if (misses >= QUERY_POD_MAX_MISSES) {
            throw new Error(`Lost track of the run waiting for a query pod (job ${jobId}): the server did not `
              + 'answer. It may still run -- look in your recent runs before starting it again.');
          }
          continue;
        }
        const started = j?.response?.execution_id;
        if (started) return { ...j.response, job_id: jobId } as unknown as T;
        if (j?.status === 'succeeded' && j?.result_handle) {
          return { execution_id: j.result_handle, job_id: jobId, status: 'completed' } as unknown as T;
        }
        if (j?.status === 'failed') {
          throw new Error(String(j?.error || 'The run failed on its query pod.'));
        }
        if (j?.status === 'cancelled') return { status: 'cancelled' } as unknown as T;
        if (j?.status === 'queued') show(j);
        else setQueued({ position: 0, length: 0, executionId: null, forQueryPod: true,
                         message: 'A query pod has taken your run -- starting it now' });
      }
    };
    let response: T;
    try {
      response = await followQueryPod(await post(id));
    } catch (err) {
      const outcome = settle(null);
      if (outcome.cancelled) return outcome;     // the user stopped it; no error to show
      throw err;
    }
    return settle(response);
  }, [cancel]);

  return { queued, submit, cancel };
}
