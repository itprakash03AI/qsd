/**
 * A small reader for the Arrow IPC STREAM the report cube answers with
 * (2026-10-30, the canvas drawing fast; the transport is services/api/cubeArrow.ts).
 *
 * The cube writes Arrow only in the shapes `backend/core/reports/cube_arrow.py`
 * chooses -- float64, utf8, bool and the null type, one or more record
 * batches, no dictionaries, no compression -- so this reader handles exactly
 * those (plus the plain integer and float32 types, which cost nothing) and
 * REFUSES anything else with an error.  A refusal is never a wrong value: the
 * caller asks again for JSON.  No dependency is added for it (the full
 * apache-arrow library is ~200 KB for a job of ~200 lines).
 *
 * Format: https://arrow.apache.org/docs/format/Columnar.html#ipc-streaming-format
 * Each message = 0xFFFFFFFF, int32 metadata length, a flatbuffer `Message`,
 * then its body; a length of 0 ends the stream.
 */

export interface ArrowField { name: string; type: string; }
export interface ArrowDecoded {
  fields: ArrowField[];
  rows: Record<string, any>[];
  metadata: Record<string, string>;
}

const CONTINUATION = 0xffffffff;
// Message.header union
const HEADER_SCHEMA = 1;
const HEADER_DICTIONARY = 2;
const HEADER_RECORD_BATCH = 3;
// Type union
const T_NULL = 1;
const T_INT = 2;
const T_FLOAT = 3;
const T_UTF8 = 5;
const T_BOOL = 6;

class Fb {
  constructor(readonly dv: DataView) {}
  /** a table at `pos`: the position of field `i` in it, or 0 when absent */
  field(pos: number, i: number): number {
    const vt = pos - this.dv.getInt32(pos, true);
    const vtLen = this.dv.getUint16(vt, true);
    const o = 4 + 2 * i;
    if (o >= vtLen) return 0;
    const off = this.dv.getUint16(vt + o, true);
    return off ? pos + off : 0;
  }
  u8(pos: number, i: number, dflt = 0): number { const p = this.field(pos, i); return p ? this.dv.getUint8(p) : dflt; }
  i16(pos: number, i: number, dflt = 0): number { const p = this.field(pos, i); return p ? this.dv.getInt16(p, true) : dflt; }
  i32(pos: number, i: number, dflt = 0): number { const p = this.field(pos, i); return p ? this.dv.getInt32(p, true) : dflt; }
  i64(pos: number, i: number, dflt = 0): number { const p = this.field(pos, i); return p ? int64(this.dv, p) : dflt; }
  /** follow the offset stored in field `i` (a table, a vector, a string) */
  ref(pos: number, i: number): number {
    const p = this.field(pos, i);
    return p ? p + this.dv.getUint32(p, true) : 0;
  }
  str(at: number): string {
    if (!at) return '';
    const len = this.dv.getUint32(at, true);
    return utf8(new Uint8Array(this.dv.buffer, this.dv.byteOffset + at + 4, len));
  }
  vecLen(at: number): number { return at ? this.dv.getUint32(at, true) : 0; }
  /** element `k` of a vector of tables */
  vecTable(at: number, k: number): number {
    const p = at + 4 + 4 * k;
    return p + this.dv.getUint32(p, true);
  }
}

function int64(dv: DataView, p: number): number {
  const lo = dv.getUint32(p, true);
  const hi = dv.getInt32(p + 4, true);
  return hi * 4294967296 + lo;
}

const decoder = typeof TextDecoder !== 'undefined' ? new TextDecoder('utf-8') : null;
function utf8(bytes: Uint8Array): string {
  if (decoder) return decoder.decode(bytes);
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return decodeURIComponent(escape(s));
}

interface FieldSpec { name: string; typeId: number; bitWidth: number; signed: boolean; precision: number; }

function readSchema(fb: Fb, schema: number): { fields: FieldSpec[]; metadata: Record<string, string> } {
  const fieldsVec = fb.ref(schema, 1);
  const fields: FieldSpec[] = [];
  for (let k = 0; k < fb.vecLen(fieldsVec); k++) {
    const f = fb.vecTable(fieldsVec, k);
    const name = fb.str(fb.ref(f, 0));
    const typeId = fb.u8(f, 2);
    const type = fb.ref(f, 3);
    if (fb.ref(f, 4)) throw new Error(`Arrow: dictionary-encoded field "${name}" is not read here`);
    if (fb.vecLen(fb.ref(f, 5)) > 0) throw new Error(`Arrow: nested field "${name}" is not read here`);
    let bitWidth = 0; let signed = true; let precision = 2;
    if (typeId === T_INT) { bitWidth = fb.i32(type, 0); signed = !!fb.u8(type, 1); }
    else if (typeId === T_FLOAT) { precision = fb.i16(type, 0); }
    else if (![T_NULL, T_UTF8, T_BOOL].includes(typeId)) {
      throw new Error(`Arrow: field "${name}" has a type this reader does not know (${typeId})`);
    }
    if (typeId === T_FLOAT && precision === 0) throw new Error(`Arrow: half floats are not read here ("${name}")`);
    fields.push({ name, typeId, bitWidth, signed, precision });
  }
  const metadata: Record<string, string> = {};
  const md = fb.ref(schema, 2);
  for (let k = 0; k < fb.vecLen(md); k++) {
    const kv = fb.vecTable(md, k);
    metadata[fb.str(fb.ref(kv, 0))] = fb.str(fb.ref(kv, 1));
  }
  return { fields, metadata };
}

const typeName = (f: FieldSpec) =>
  f.typeId === T_NULL ? 'null' : f.typeId === T_BOOL ? 'bool' : f.typeId === T_UTF8 ? 'utf8'
    : f.typeId === T_FLOAT ? (f.precision === 2 ? 'float64' : 'float32') : `int${f.bitWidth}`;

function readBatch(fb: Fb, batch: number, body: number, fields: FieldSpec[], rows: Record<string, any>[]) {
  const dv = fb.dv;
  if (fb.ref(batch, 3)) throw new Error('Arrow: compressed batches are not read here');
  const length = fb.i64(batch, 0);
  const nodes = fb.ref(batch, 1);
  const bufs = fb.ref(batch, 2);
  const buffer = (k: number) => {
    const p = bufs + 4 + 16 * k;
    return { offset: body + int64(dv, p), length: int64(dv, p + 8) };
  };
  const start = rows.length;
  for (let i = 0; i < length; i++) rows.push({});
  let b = 0;
  fields.forEach((f, fi) => {
    const nodeLen = int64(dv, nodes + 4 + 16 * fi);
    if (nodeLen !== length) throw new Error(`Arrow: field "${f.name}" has ${nodeLen} values for ${length} rows`);
    if (f.typeId === T_NULL) {               // no buffers at all
      for (let i = 0; i < length; i++) rows[start + i][f.name] = null;
      return;
    }
    const validity = buffer(b++);
    const valid = (i: number) => validity.length === 0
      || ((dv.getUint8(validity.offset + (i >> 3)) >> (i & 7)) & 1) === 1;
    if (f.typeId === T_UTF8) {
      const offs = buffer(b++);
      const data = buffer(b++);
      for (let i = 0; i < length; i++) {
        if (!valid(i)) { rows[start + i][f.name] = null; continue; }
        const s = dv.getInt32(offs.offset + 4 * i, true);
        const e = dv.getInt32(offs.offset + 4 * (i + 1), true);
        rows[start + i][f.name] = utf8(new Uint8Array(dv.buffer, dv.byteOffset + data.offset + s, e - s));
      }
      return;
    }
    const values = buffer(b++);
    for (let i = 0; i < length; i++) {
      let v: any = null;
      if (valid(i)) {
        const at = values.offset;
        if (f.typeId === T_BOOL) v = ((dv.getUint8(at + (i >> 3)) >> (i & 7)) & 1) === 1;
        else if (f.typeId === T_FLOAT) v = f.precision === 2 ? dv.getFloat64(at + 8 * i, true) : dv.getFloat32(at + 4 * i, true);
        else if (f.bitWidth === 8) v = f.signed ? dv.getInt8(at + i) : dv.getUint8(at + i);
        else if (f.bitWidth === 16) v = f.signed ? dv.getInt16(at + 2 * i, true) : dv.getUint16(at + 2 * i, true);
        else if (f.bitWidth === 32) v = f.signed ? dv.getInt32(at + 4 * i, true) : dv.getUint32(at + 4 * i, true);
        else v = f.signed ? int64(dv, at + 8 * i) : dv.getUint32(at + 8 * i, true) + dv.getUint32(at + 8 * i + 4, true) * 4294967296;
      }
      rows[start + i][f.name] = v;
    }
  });
}

/** Every row of an Arrow IPC stream, as plain objects (the JSON's shape). */
export function decodeArrowStream(buf: ArrayBuffer): ArrowDecoded {
  const dv = new DataView(buf);
  const fb = new Fb(dv);
  let pos = 0;
  let fields: FieldSpec[] | null = null;
  let metadata: Record<string, string> = {};
  const rows: Record<string, any>[] = [];
  while (pos + 4 <= dv.byteLength) {
    let metaLen = dv.getUint32(pos, true);
    pos += 4;
    if (metaLen === CONTINUATION) {
      if (pos + 4 > dv.byteLength) break;
      metaLen = dv.getUint32(pos, true);
      pos += 4;
    }
    if (metaLen === 0) break;                 // end of stream
    const msg = pos + dv.getUint32(pos, true);
    const headerType = fb.u8(msg, 1);
    const header = fb.ref(msg, 2);
    const bodyLength = fb.i64(msg, 3);
    const body = pos + metaLen;
    if (headerType === HEADER_SCHEMA) {
      const s = readSchema(fb, header);
      fields = s.fields;
      metadata = s.metadata;
    } else if (headerType === HEADER_RECORD_BATCH) {
      if (!fields) throw new Error('Arrow: a record batch came before the schema');
      readBatch(fb, header, body, fields, rows);
    } else if (headerType === HEADER_DICTIONARY) {
      throw new Error('Arrow: dictionary batches are not read here');
    } else {
      throw new Error(`Arrow: unknown message (${headerType})`);
    }
    pos = body + bodyLength;
  }
  if (!fields) throw new Error('Arrow: the stream has no schema');
  return { fields: fields.map(f => ({ name: f.name, type: typeName(f) })), rows, metadata };
}

/** The cube's JSON envelope back from its Arrow answer ({...meta, rows}). */
export function decodeCubeArrow(buf: ArrayBuffer): any {
  const { rows, metadata } = decodeArrowStream(buf);
  const meta = metadata.qs_cube ? JSON.parse(metadata.qs_cube) : {};
  return { ...meta, rows };
}
