/**
 * Phase 157 (2026-06-26) -- Business Report Permissions tab.
 *
 * "Who has access" panel for the BR editor.  Operators can:
 *   * See effective access surface (owner, owner group, role_whitelist,
 *     active grants, share tokens, embed tokens) at a glance
 *   * Add per-user / per-group grants with optional grant_until
 *   * Remove grants
 *   * Review pending access requests + approve/deny
 *   * Request certification + see review status
 *   * View append-only audit log of permission changes
 *
 * Backed by the Phase 157 chokepoint endpoints under
 * /api/business-reports/{id}/permissions/* + /admin/business-reports/*.
 */
import { appConfirm, appPrompt } from './common/appDialogs';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import ListPager, { clientPage } from './common/ListPager';
import {
  Box, Paper, Typography, Button, Stack, Chip, Alert, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Select, MenuItem, FormControl, InputLabel, IconButton,
  Tooltip, CircularProgress,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Refresh as RefreshIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
  CheckCircle as ApproveIcon,
  Cancel as DenyIcon,
  Schedule as TimerIcon,
  Verified as CertifyIcon,
  History as AuditIcon,
} from '@mui/icons-material';
import { safeFetch } from '../services/api/core';

interface Props {
  reportId: number;
  addNotification?: (n: { type: string; title: string; message: string }) => void;
}

interface Grant {
  id: number;
  username?: string | null;
  group_id?: number | null;
  level: string;
  grant_until?: string | null;
  reason?: string | null;
  granted_by: string;
  granted_at?: string | null;
}

interface ShareToken { id: number; token?: string; expires_at?: string; created_at?: string }
interface EmbedToken { id: number; token?: string; expires_at?: string; created_at?: string }

interface AccessRequest {
  id: number;
  requester: string;
  requested_level: string;
  reason?: string | null;
  status: string;
  decided_by?: string | null;
  decided_at?: string | null;
  decision_note?: string | null;
  created_at?: string | null;
}

interface PermEvent {
  id: number;
  event_type: string;
  actor: string;
  subject?: string | null;
  metadata?: any;
  created_at?: string | null;
}

interface PermissionsSnapshot {
  owner?: string;
  owner_group_id?: number | null;
  role_whitelist?: string[];
  is_published?: boolean;
  is_certified?: boolean;
  my_level: string;
  can_share: boolean;
  grants?: Grant[];
  share_tokens?: ShareToken[];
  embed_tokens?: EmbedToken[];
}

const LEVELS = ['view', 'runner', 'editor', 'owner'];

const BusinessReportPermissionsTab: React.FC<Props> = ({ reportId, addNotification }) => {
  const [snapshot, setSnapshot] = useState<PermissionsSnapshot | null>(null);
  const [pending, setPending] = useState<AccessRequest[]>([]);
  const [audit, setAudit] = useState<PermEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Add-grant dialog
  const [grantOpen, setGrantOpen] = useState(false);
  const [grantTarget, setGrantTarget] = useState<'user' | 'group'>('user');
  const [grantSubject, setGrantSubject] = useState('');
  const [grantLevel, setGrantLevel] = useState('view');
  const [grantUntil, setGrantUntil] = useState('');
  const [grantReason, setGrantReason] = useState('');
  const [grantSaving, setGrantSaving] = useState(false);

  // Certification dialog
  const [certOpen, setCertOpen] = useState(false);
  const [certRationale, setCertRationale] = useState('');
  const [certSaving, setCertSaving] = useState(false);

  // Pages (2026-10-13, "pagination in all grids"): access requests, grants
  // and the audit log grow with use; the browser holds each list whole.
  const [reqPage, setReqPage] = useState(1);
  const [reqPageSize, setReqPageSize] = useState(50);
  const [grantPage, setGrantPage] = useState(1);
  const [grantPageSize, setGrantPageSize] = useState(50);
  const [auditPage, setAuditPage] = useState(1);
  const [auditPageSize, setAuditPageSize] = useState(50);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // safeFetch returns the parsed body and throws ApiError on non-2xx
      // — it is NOT a fetch Response.  Permissions are REQUIRED (let a
      // failure reject); requests + audit are OPTIONAL (swallow to null
      // so a failure there doesn't blank the whole tab).
      const [perms, reqRes, auditRes] = await Promise.all([
        safeFetch<any>(`/api/business-reports/${reportId}/permissions`),
        safeFetch<any>(`/api/business-reports/${reportId}/permissions/access-requests?status=pending`).catch(() => null),
        safeFetch<any>(`/api/business-reports/${reportId}/permissions/audit?limit=50`).catch(() => null),
      ]);
      setSnapshot(perms);
      if (reqRes) setPending((reqRes.entries || []) as AccessRequest[]);
      if (auditRes) setAudit((auditRes.entries || []) as PermEvent[]);
    } catch (e: any) {
      setError(e?.message || 'load failed');
    } finally {
      setLoading(false);
    }
  }, [reportId]);

  useEffect(() => { load(); }, [load]);

  const handleAddGrant = async () => {
    if (!grantSubject.trim()) {
      addNotification?.({ type: 'error', title: 'Subject required', message: 'Enter a user / group id' });
      return;
    }
    setGrantSaving(true);
    try {
      const body: any = { level: grantLevel, reason: grantReason || null };
      if (grantTarget === 'user') body.username = grantSubject.trim();
      else body.group_id = Number(grantSubject.trim());
      if (grantUntil) body.grant_until = new Date(grantUntil).toISOString();
      // safeFetch throws ApiError on non-2xx — caught below.
      await safeFetch(`/api/business-reports/${reportId}/permissions/grants`, {
        method: 'POST', body: JSON.stringify(body),
        headers: { 'Content-Type': 'application/json' },
      });
      addNotification?.({ type: 'success', title: 'Grant added', message: `${grantLevel} for ${grantSubject}` });
      setGrantOpen(false);
      setGrantSubject(''); setGrantUntil(''); setGrantReason('');
      load();
    } catch (e: any) {
      addNotification?.({ type: 'error', title: 'Add failed', message: e?.message || 'Unknown' });
    } finally { setGrantSaving(false); }
  };

  const handleRemoveGrant = async (g: Grant) => {
    if (!await appConfirm(`Remove ${g.level} grant for ${g.username || `group:${g.group_id}`}?`)) return;
    try {
      // safeFetch throws ApiError on non-2xx — caught below.
      await safeFetch(`/api/business-reports/permissions/grants/${g.id}`, { method: 'DELETE' });
      addNotification?.({ type: 'success', title: 'Grant removed', message: '' });
      load();
    } catch (e: any) {
      addNotification?.({ type: 'error', title: 'Remove failed', message: e?.message || 'Unknown' });
    }
  };

  const handleDecide = async (req: AccessRequest, approve: boolean) => {
    const note = await appPrompt(`${approve ? 'Approval' : 'Denial'} note (optional):`) || '';
    try {
      const path = approve
        ? `/api/business-reports/permissions/access-requests/${req.id}/approve`
        : `/api/business-reports/permissions/access-requests/${req.id}/deny`;
      // safeFetch throws ApiError on non-2xx — success falls through.
      await safeFetch(path, {
        method: 'POST',
        body: JSON.stringify({ decision_note: note }),
        headers: { 'Content-Type': 'application/json' },
      });
      addNotification?.({
        type: 'success',
        title: approve ? 'Access approved' : 'Access denied',
        message: req.requester,
      });
      load();
    } catch (e: any) {
      addNotification?.({ type: 'error', title: 'Decision failed', message: e?.message || 'Unknown' });
    }
  };

  const handleRequestCert = async () => {
    setCertSaving(true);
    try {
      // safeFetch throws ApiError on non-2xx — success falls through.
      await safeFetch(`/api/business-reports/${reportId}/permissions/certification-request`, {
        method: 'POST',
        body: JSON.stringify({ rationale: certRationale }),
        headers: { 'Content-Type': 'application/json' },
      });
      addNotification?.({ type: 'success', title: 'Certification requested', message: 'Pending admin review' });
      setCertOpen(false); setCertRationale('');
      load();
    } catch (e: any) {
      addNotification?.({ type: 'error', title: 'Request failed', message: e?.message || 'Unknown' });
    } finally { setCertSaving(false); }
  };

  const formattedDate = (s?: string | null) => s ? new Date(s).toLocaleString() : '—';

  const shownPending = clientPage(pending, reqPage, reqPageSize);
  const shownGrants = clientPage(snapshot?.grants || [], grantPage, grantPageSize);
  const shownAudit = clientPage(audit, auditPage, auditPageSize);

  return (
    <Box sx={{ p: 2 }}>
      <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 2 }}>
        <Typography variant="h5" sx={{ flex: 1 }}>Permissions</Typography>
        <Button startIcon={loading ? <CircularProgress size={14} /> : <RefreshIcon />}
                onClick={load} variant="outlined" size="small">Refresh</Button>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

      {/* Effective access summary */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="overline" color="text.secondary">Effective access</Typography>
        <Stack direction="row" flexWrap="wrap" spacing={1} sx={{ mt: 1 }}>
          {snapshot?.owner && <Chip label={`Owner: ${snapshot.owner}`} color="primary" />}
          {snapshot?.owner_group_id != null && <Chip label={`Owner group #${snapshot.owner_group_id}`} />}
          {snapshot?.is_published && <Chip label="Published" color="success" />}
          {snapshot?.is_certified && <Chip icon={<CertifyIcon />} label="Certified" color="success" variant="outlined" />}
          {(snapshot?.role_whitelist || []).map((r, i) =>
            <Chip key={i} label={`Role: ${r}`} size="small" variant="outlined" />)}
          <Chip label={`You: ${snapshot?.my_level || 'no access'}`}
                color={snapshot?.my_level ? 'success' : 'default'} />
        </Stack>
      </Paper>

      {/* Pending access requests */}
      {snapshot?.can_share && pending.length > 0 && (
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="overline" color="text.secondary">
            Pending access requests ({pending.length})
          </Typography>
          <TableContainer sx={{ mt: 1 }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Requester</TableCell>
                  <TableCell>Level</TableCell>
                  <TableCell>Reason</TableCell>
                  <TableCell>Requested at</TableCell>
                  <TableCell align="right">Decision</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {shownPending.rows.map(req => (
                  <TableRow key={req.id}>
                    <TableCell>{req.requester}</TableCell>
                    <TableCell><Chip size="small" label={req.requested_level} /></TableCell>
                    <TableCell><Typography variant="caption">{req.reason || '—'}</Typography></TableCell>
                    <TableCell><Typography variant="caption">{formattedDate(req.created_at)}</Typography></TableCell>
                    <TableCell align="right">
                      <Tooltip title="Approve">
                        <IconButton size="small" color="success" onClick={() => handleDecide(req, true)}>
                          <ApproveIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Deny">
                        <IconButton size="small" color="error" onClick={() => handleDecide(req, false)}>
                          <DenyIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <ListPager paging={shownPending.paging} onPage={setReqPage} onPageSize={setReqPageSize}
                     testid="perm-requests-pager" />
        </Paper>
      )}

      {/* Active grants */}
      {snapshot?.can_share && (
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Stack direction="row" alignItems="center" sx={{ mb: 1 }}>
            <Typography variant="overline" color="text.secondary" sx={{ flex: 1 }}>
              Active grants ({snapshot.grants?.length || 0})
            </Typography>
            <Button size="small" variant="outlined" startIcon={<AddIcon />}
                    onClick={() => setGrantOpen(true)}>Add grant</Button>
          </Stack>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Subject</TableCell>
                  <TableCell>Level</TableCell>
                  <TableCell>Expires</TableCell>
                  <TableCell>Reason</TableCell>
                  <TableCell>Granted by</TableCell>
                  <TableCell align="right">Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {shownGrants.rows.map(g => (
                  <TableRow key={g.id}>
                    <TableCell>{g.username || `group:${g.group_id}`}</TableCell>
                    <TableCell><Chip size="small" label={g.level} /></TableCell>
                    <TableCell>
                      {g.grant_until
                        ? <Chip size="small" icon={<TimerIcon />} label={formattedDate(g.grant_until)} />
                        : <Typography variant="caption">permanent</Typography>}
                    </TableCell>
                    <TableCell><Typography variant="caption">{g.reason || '—'}</Typography></TableCell>
                    <TableCell><Typography variant="caption">{g.granted_by}</Typography></TableCell>
                    <TableCell align="right">
                      <IconButton aria-label="Delete" size="small" color="error" onClick={() => handleRemoveGrant(g)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                {(!snapshot.grants || snapshot.grants.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={6}>
                      <Typography variant="caption" color="text.secondary">
                        No explicit grants. Use Add grant to share with a specific user or group.
                      </Typography>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          {shownGrants.paging.total > 0 && (
            <ListPager paging={shownGrants.paging} onPage={setGrantPage} onPageSize={setGrantPageSize}
                       testid="perm-grants-pager" />
          )}
        </Paper>
      )}

      {/* Share + embed tokens */}
      {snapshot?.can_share && ((snapshot.share_tokens?.length || 0) + (snapshot.embed_tokens?.length || 0)) > 0 && (
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
          <Typography variant="overline" color="text.secondary">
            Public share + embed tokens
          </Typography>
          <Stack spacing={1} sx={{ mt: 1 }}>
            {(snapshot.share_tokens || []).map(t => (
              <Chip key={`s-${t.id}`} label={`share #${t.id} created ${formattedDate(t.created_at)}`} />
            ))}
            {(snapshot.embed_tokens || []).map(t => (
              <Chip key={`e-${t.id}`} label={`embed #${t.id} created ${formattedDate(t.created_at)}`} />
            ))}
          </Stack>
        </Paper>
      )}

      {/* Certification */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" alignItems="center" spacing={1}>
          <CertifyIcon color={snapshot?.is_certified ? 'success' : 'disabled'} />
          <Typography variant="body2" sx={{ flex: 1 }}>
            {snapshot?.is_certified
              ? 'Certified — visible in the report catalog as trusted'
              : 'Not certified. Request certification to mark this report as trusted.'}
          </Typography>
          {!snapshot?.is_certified && (
            <Button size="small" variant="outlined" onClick={() => setCertOpen(true)}>
              Request certification
            </Button>
          )}
        </Stack>
      </Paper>

      {/* Audit log */}
      {snapshot?.can_share && (
        <Paper variant="outlined" sx={{ p: 2 }}>
          <Stack direction="row" alignItems="center" sx={{ mb: 1 }}>
            <AuditIcon fontSize="small" sx={{ mr: 1 }} />
            <Typography variant="overline" color="text.secondary" sx={{ flex: 1 }}>
              Audit log
            </Typography>
          </Stack>
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>When</TableCell>
                  <TableCell>Event</TableCell>
                  <TableCell>Actor</TableCell>
                  <TableCell>Subject</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {shownAudit.rows.map(ev => (
                  <TableRow key={ev.id}>
                    <TableCell>
                      <Typography variant="caption">{formattedDate(ev.created_at)}</Typography>
                    </TableCell>
                    <TableCell><Chip size="small" label={ev.event_type} variant="outlined" /></TableCell>
                    <TableCell><Typography variant="caption">{ev.actor}</Typography></TableCell>
                    <TableCell><Typography variant="caption">{ev.subject || '—'}</Typography></TableCell>
                  </TableRow>
                ))}
                {audit.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4}>
                      <Typography variant="caption" color="text.secondary">No events yet.</Typography>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          {shownAudit.paging.total > 0 && (
            <ListPager paging={shownAudit.paging} onPage={setAuditPage} onPageSize={setAuditPageSize}
                       testid="perm-audit-pager" />
          )}
        </Paper>
      )}

      {/* Add grant dialog */}
      <AppDialog open={grantOpen}
        onClose={() => setGrantOpen(false)}
        size="sm"
        title="Add grant"
        actions={<>
          <Button onClick={() => setGrantOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={grantSaving} onClick={handleAddGrant}>
            {grantSaving ? <CircularProgress size={16} /> : 'Add grant'}
          </Button>
        </>}>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <FormControl size="small">
              <InputLabel id="sel-businessreportpermissionstab-target">Target</InputLabel>
              <Select labelId="sel-businessreportpermissionstab-target" value={grantTarget} label="Target"
                      onChange={e => setGrantTarget(e.target.value as 'user' | 'group')}>
                <MenuItem value="user">User (username)</MenuItem>
                <MenuItem value="group">Group (group id)</MenuItem>
              </Select>
            </FormControl>
            <TextField size="small" label={grantTarget === 'user' ? 'Username' : 'Group id'}
                       value={grantSubject} onChange={e => setGrantSubject(e.target.value)} />
            <FormControl size="small">
              <InputLabel id="sel-businessreportpermissionstab-level">Level</InputLabel>
              <Select labelId="sel-businessreportpermissionstab-level" value={grantLevel} label="Level"
                      onChange={e => setGrantLevel(e.target.value as string)}>
                {LEVELS.map(l => <MenuItem key={l} value={l}>{l}</MenuItem>)}
              </Select>
            </FormControl>
            <TextField size="small" type="datetime-local" label="Expires (optional)"
                       InputLabelProps={{ shrink: true }}
                       value={grantUntil} onChange={e => setGrantUntil(e.target.value)} />
            <TextField size="small" label="Reason (optional)" multiline minRows={2}
                       value={grantReason} onChange={e => setGrantReason(e.target.value)} />
          </Stack>
      </AppDialog>

      {/* Certification request dialog */}
      <AppDialog open={certOpen}
        onClose={() => setCertOpen(false)}
        size="sm"
        title="Request certification"
        actions={<>
          <Button onClick={() => setCertOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={certSaving} onClick={handleRequestCert}>
            {certSaving ? <CircularProgress size={16} /> : 'Submit request'}
          </Button>
        </>}>
          <Typography variant="caption" color="text.secondary">
            Certification marks this report as trusted in the catalog. An admin reviews + approves.
          </Typography>
          <TextField size="small" label="Rationale" multiline minRows={3} fullWidth sx={{ mt: 2 }}
                     value={certRationale} onChange={e => setCertRationale(e.target.value)} />
      </AppDialog>
    </Box>
  );
};

export default BusinessReportPermissionsTab;
