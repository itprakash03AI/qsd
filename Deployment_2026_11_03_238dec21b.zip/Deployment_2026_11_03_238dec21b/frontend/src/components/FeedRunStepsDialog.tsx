/**
 * FeedRunStepsDialog — per-run step timeline (2026-09-02; step model 2026-09-05).
 *
 * Driven by GET /api/feed-runs/{run_id}/steps.  Renders the steps the
 * BACKEND sends — names and states are never invented client-side.
 * For a failed run the failing step must be identifiable at a glance:
 * it gets the error treatment plus an explicit "failed here" marker.
 *
 * "Could not load" and "no steps recorded" are OPPOSITE findings and
 * render differently: a fetch error shows an error alert with a Retry
 * button; an empty steps list shows an informational empty state.
 *
 * WHAT `source` MEANS, and why it is on the screen (2026-09-05).
 * A run executed since the step model shipped has a ROW per step, with
 * real wall-clock boundaries, a record count, the pod and the attempt.
 * A run that predates it gets the old timing PROJECTION, where every
 * started_at is null because durations have no boundaries.  The route
 * says which one it gave, and so does this dialog: presenting a
 * projection as a record is how a timeline stops being trustworthy.
 * A server that says nothing is reported as "not stated" — never
 * silently assumed to be the good case.
 *
 * THE RE-RUN BUTTON.  Enabled/disabled comes from
 * GET /api/feed-runs/{id}/steps/rerun-verdicts, and the tooltip shows the
 * server's own `reason` verbatim.  The UI does not infer a reason from
 * the status: re-run safety is TRI-STATE (undeclared is a refusal with
 * its own reason, which is NOT the same finding as "declared unsafe"),
 * and a second opinion computed here would be a decision made twice.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, IconButton, Stack, Tooltip, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  CheckCircle as DoneIcon, Error as FailIcon,
  HourglassTop as PendingIcon, Block as SkipIcon,
  Schedule as RunningIcon, Replay as RetryIcon,
  Warning as RefusedIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { StopCircle as StopIcon } from '@mui/icons-material';
import { cancelledWords, confirmStopRun, STOP_REQUESTED } from './feeds/stopRun';
import type { FeedRunStepsResponse, FeedRunStep } from '../services/api/feedDependencies';
import type { RerunVerdict } from '../services/api/feedSteps';
import { decisionWords } from './feedDecisions';
import RunProgressBar from './feeds/RunProgressBar';

const STEP_ICON: Record<string, React.ReactElement> = {
  pending:   <PendingIcon fontSize="small" color="disabled" />,
  running:   <RunningIcon fontSize="small" color="info" />,
  completed: <DoneIcon fontSize="small" color="success" />,
  failed:    <FailIcon fontSize="small" color="error" />,
  // A REFUSAL is a verdict the step reached deliberately ("0 rows, floor
  // is 1"), not something that broke.  Same severity, different reading,
  // so it gets its own treatment rather than being drawn as a crash.
  refused:   <RefusedIcon fontSize="small" color="warning" />,
  skipped:   <SkipIcon fontSize="small" color="disabled" />,
  cancelled: <SkipIcon fontSize="small" color="disabled" />,
};

const STEP_CHIP_COLOR: Record<string, 'default' | 'success' | 'error' | 'warning' | 'info'> = {
  pending: 'default', running: 'info', completed: 'success',
  failed: 'error', refused: 'warning', skipped: 'default',
  cancelled: 'default',
};

const fmtSeconds = (s: number | null): string => {
  if (s == null) return '—';
  if (s < 60) return `${s.toFixed(s < 10 ? 1 : 0)}s`;
  const mm = Math.floor(s / 60);
  const ss = Math.round(s % 60);
  return `${mm}m ${ss}s`;
};

const fmtRows = (n: number): string => n.toLocaleString('en-US');

/** Verdict lookup for one step, as a THREE-way answer.  `undefined` is
 *  "the server said nothing about this step", which is not a refusal —
 *  and the two must not render the same. */
type VerdictState =
  | { kind: 'verdict'; verdict: RerunVerdict }
  | { kind: 'unreadable'; error: string }
  | { kind: 'absent' };

interface Props {
  /** Run whose steps to show; null = closed (unless executionId is set). */
  runId: number | null;
  /** 2026-09-14 — open by EXECUTION instead (the Feeds page lists
   *  executions, not runs).  The server answers with the run the rows
   *  were recorded under, so re-run verdicts still work when there is
   *  one; a manual Run Now has none and gets the projection. */
  executionId?: number | null;
  runName?: string | null;
  onClose: () => void;
}

const fmtDuration = (a: string | null | undefined, b: string | null | undefined, secs?: number | null): string => {
  if (typeof secs === 'number') return fmtSeconds(secs);
  if (!a || !b) return '—';
  const ms = new Date(b).getTime() - new Date(a).getTime();
  return Number.isFinite(ms) && ms >= 0 ? fmtSeconds(ms / 1000) : '—';
};

const FeedRunStepsDialog: React.FC<Props> = ({
  runId, executionId = null, runName, onClose,
}) => {
  const [loading, setLoading] = useState(false);
  // 2026-09-14 -- the driver pod's log, fetched on demand (spark_k8s only).
  const [driverLog, setDriverLog] = useState<{
    state: 'idle' | 'loading' | 'shown' | 'unavailable' | 'error';
    lines: string[]; pod?: string; kubectl?: string; reason?: string;
  }>({ state: 'idle', lines: [] });
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<FeedRunStepsResponse | null>(null);
  const [verdicts, setVerdicts] = useState<RerunVerdict[] | null>(null);
  const [verdictError, setVerdictError] = useState<string | null>(null);
  const [rerunning, setRerunning] = useState<string | null>(null);
  const [rerunError, setRerunError] = useState<string | null>(null);
  const [rerunNote, setRerunNote] = useState<string | null>(null);

  const loadVerdicts = useCallback(async (id: number) => {
    setVerdictError(null);
    try {
      const resp = await api.feedSteps.getRerunVerdicts(id);
      setVerdicts(Array.isArray(resp?.verdicts) ? resp.verdicts : []);
    } catch (e: any) {
      // Could-not-read is not "nothing may be re-run".  Keep the list
      // null so every button reports UNKNOWN rather than a refusal.
      setVerdicts(null);
      setVerdictError(e?.message || String(e));
    }
  }, []);

  const load = useCallback(async (id: number, byExecution = false) => {
    setLoading(true);
    setError(null);
    try {
      const resp = byExecution
        ? await api.getFeedExecutionSteps(id)
        : await api.getFeedRunSteps(id);
      setData(resp);
      // Verdicts only exist where the run has real step ROWS.  Asking for
      // them on a timing projection would return an empty list, which a
      // reader could mistake for "nothing may be re-run".  By execution,
      // the run to ask about is the one the SERVER named.
      const verdictRun = byExecution ? resp?.run_id : id;
      if (resp?.source === 'recorded' && verdictRun != null) await loadVerdicts(verdictRun);
      else { setVerdicts(null); setVerdictError(null); }
    } catch (e: any) {
      // Fetch failure must NOT render as "no steps" — keep data null and
      // surface the error explicitly.
      setData(null);
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, [loadVerdicts]);

  useEffect(() => {
    setDriverLog({ state: 'idle', lines: [] });
    if (runId == null && executionId == null) {
      setData(null); setError(null); setVerdicts(null); setVerdictError(null);
      setRerunError(null); setRerunNote(null);
      return;
    }
    if (runId != null) void load(runId);
    else void load(executionId as number, true);
  }, [runId, executionId, load]);

  /** The run the re-run buttons act on: the prop, or the run the server
   *  resolved for an execution.  null = nothing can be re-run. */
  const effectiveRunId: number | null = runId ?? (data?.run_id ?? null);
  const reload = useCallback(() => {
    if (runId != null) void load(runId);
    else if (executionId != null) void load(executionId, true);
  }, [runId, executionId, load]);

  // While the run is going, re-read it every 15 s: the dialog shows where
  // the run IS, not where it was when it opened (2026-10-14).
  const running = data?.execution?.status === 'running' || data?.execution?.status === 'pending';
  useEffect(() => {
    if (!running) return;
    const h = setInterval(() => {
      if (runId != null) void api.getFeedRunSteps(runId).then(setData).catch(() => undefined);
      else if (executionId != null) void api.getFeedExecutionSteps(executionId).then(setData).catch(() => undefined);
    }, 15000);
    return () => clearInterval(h);
  }, [running, runId, executionId]);

  const steps: FeedRunStep[] = data?.steps ?? [];
  const source = data?.source;
  const execution = data?.execution ?? null;

  const loadDriverLog = useCallback(async () => {
    if (!execution) return;
    setDriverLog({ state: 'loading', lines: [] });
    try {
      const resp = await api.getFeedExecutionDriverLog(execution.id, 400);
      if (resp.available) {
        setDriverLog({ state: 'shown', lines: resp.lines, pod: resp.pod, kubectl: resp.kubectl });
      } else {
        setDriverLog({ state: 'unavailable', lines: [], pod: resp.pod, reason: resp.reason });
      }
    } catch (e: any) {
      // The server's refusal, verbatim (409 not a Spark run, 503 cluster
      // unreachable) -- never an empty log presented as "nothing logged".
      setDriverLog({ state: 'error', lines: [], reason: e?.message || String(e) });
    }
  }, [execution]);

  const verdictFor = useCallback((name: string): VerdictState => {
    if (verdictError !== null) return { kind: 'unreadable', error: verdictError };
    const v = (verdicts || []).find(x => x.alias === name);
    if (v) return { kind: 'verdict', verdict: v };
    return { kind: 'absent' };
  }, [verdicts, verdictError]);

  const onRerun = useCallback(async (name: string) => {
    if (effectiveRunId == null) return;
    setRerunning(name);
    setRerunError(null);
    setRerunNote(null);
    try {
      const resp = await api.feedSteps.rerunStep(effectiveRunId, name);
      const status = resp?.result?.status;
      setRerunNote(
        status
          ? `Re-ran ${name} (attempt ${resp.attempt}) — the server reports: ${status}`
          : `Re-ran ${name} (attempt ${resp?.attempt ?? '?'}).`,
      );
      reload();
    } catch (e: any) {
      // The server's refusal, verbatim.  It names WHICH condition failed.
      setRerunError(e?.message || String(e));
    } finally {
      setRerunning(null);
    }
  }, [effectiveRunId, reload]);

  /** Steps grouped by their declared LEVEL, in level order.  Steps sharing
   *  a level had no declared dependency between them — they may have run
   *  at the same time, and a flat list says the opposite.  A payload with
   *  no levels at all (the timing projection) keeps its single ordered
   *  group and no level headings are drawn. */
  const levelled = useMemo(() => {
    const hasLevels = steps.some(s => typeof s.level === 'number');
    if (!hasLevels) return [{ level: null as number | null, items: steps }];
    const byLevel = new Map<number, FeedRunStep[]>();
    steps.forEach(s => {
      const lvl = typeof s.level === 'number' ? s.level : -1;
      if (!byLevel.has(lvl)) byLevel.set(lvl, []);
      byLevel.get(lvl)!.push(s);
    });
    return Array.from(byLevel.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([level, items]) => ({ level, items }));
  }, [steps]);

  return (
    <AppDialog open={runId != null || executionId != null}
      onClose={onClose}
      size="md"
      title={<>
        <Stack direction="row" alignItems="center" spacing={1}>
          <Typography component="span" sx={{ fontWeight: 600 }}>
            Steps — {runName || (runId != null ? `run #${runId}` : `execution #${executionId ?? ''}`)}
          </Typography>
          {data && (
            <Chip
              size="small"
              variant="outlined"
              label={data.terminal ? 'finished' : 'in progress'}
              color={data.terminal ? 'default' : 'info'}
              sx={{ height: 20, fontSize: '0.65rem' }}
            />
          )}
        </Stack>
      </>}
      actions={<>
        <Button onClick={onClose}>Close</Button>
      </>}>
        {loading && (
          <Stack direction="row" spacing={1} alignItems="center" sx={{ py: 2 }}>
            <CircularProgress size={18} />
            <Typography variant="body2">Loading steps…</Typography>
          </Stack>
        )}

        {!loading && error && (
          <Alert
            severity="error"
            action={
              <Button
                size="small" color="inherit" startIcon={<RetryIcon />}
                onClick={reload}
              >Retry</Button>
            }
          >
            Could not load steps for this run — the list below is NOT empty,
            it is unavailable. {error}
          </Alert>
        )}

        {/* WHICH answer this is.  A projection presented as a record is the
            defect this banner exists to prevent. */}
        {!loading && !error && data && (
          <Box sx={{ mb: 1.5 }} data-testid="feed-steps-source">
            {source === 'recorded' && (
              <Chip
                size="small" color="success" variant="outlined"
                label="recorded steps — real start/end times, counts and pods"
                sx={{ height: 20, fontSize: '0.65rem' }}
              />
            )}
            {source === 'derived' && (
              <Alert severity="info" sx={{ py: 0 }}>
                {/* 2026-09-14 — a manual Run Now's timeline is every
                    duration blank and every start null, which LOOKS
                    broken and is working as designed.  Say so in plain
                    words first; the server's own reason follows. */}
                {data.run_id == null && (
                  <Typography variant="body2" sx={{ fontWeight: 600, mb: 0.5 }} data-testid="feed-steps-manual-note">
                    This execution ran without a scheduled run record (a manual Run Now does not
                    create one), so per-step timings were not recorded. The steps below are
                    derived from stage durations.
                  </Typography>
                )}
                <Typography variant={data.run_id == null ? 'caption' : 'body2'} component="div">
                  {data.source_reason
                    ? `Derived from this run's stage durations, not from recorded steps — ${data.source_reason}. Start and end times are not known and no step can be re-run individually.`
                    : "Derived from this run's stage durations, not from recorded steps — this run predates the step model, so start and end times are not known and no step can be re-run individually."}
                </Typography>
              </Alert>
            )}
            {source === 'unavailable' && (
              <Alert severity="warning" sx={{ py: 0 }}>
                The recorded step rows could not be READ for this run. What
                follows is the timing projection, which is a smaller answer —
                not the record, and not proof this run had no steps.
              </Alert>
            )}
            {source === undefined && (
              <Typography variant="caption" color="text.secondary">
                This server did not state whether these are recorded steps or
                a timing projection.
              </Typography>
            )}
          </Box>
        )}

        {/* "Ran as" -- the facts an operator validates a run by, from the
            execution row, so a Spark run is verified here and not in a
            terminal.  Every value is the server's; the cluster state says
            when it was NOT checked rather than guessing. */}
        {!loading && !error && execution && (
          <Box data-testid="feed-run-ran-as" sx={{ mb: 1.5, p: 1, border: '1px solid', borderColor: 'divider', borderRadius: 1 }}>
            <Typography variant="overline" sx={{ display: 'block', color: 'text.secondary', letterSpacing: 1 }}>
              Ran as
            </Typography>
            <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap" useFlexGap>
              <Chip size="small" label={execution.execution_backend || 'backend unknown'} color="primary" variant="outlined" sx={{ height: 20, fontSize: '0.65rem' }} />
              <Chip size="small" label={execution.status || 'status unknown'}
                    color={execution.status === 'completed' ? 'success' : execution.status === 'failed' ? 'error' : 'default'}
                    sx={{ height: 20, fontSize: '0.65rem', textTransform: 'uppercase' }} />
              <Chip size="small" variant="outlined"
                    label={typeof execution.total_rows === 'number' ? `${fmtRows(execution.total_rows)} rows` : 'rows unknown'}
                    sx={{ height: 20, fontSize: '0.65rem' }} />
              <Chip size="small" variant="outlined"
                    label={`duration ${fmtDuration(execution.started_at, execution.completed_at, execution.duration_seconds)}`}
                    sx={{ height: 20, fontSize: '0.65rem' }} />
              {execution.completeness && (
                <Chip size="small" variant="outlined" label={`completeness ${execution.completeness}`} sx={{ height: 20, fontSize: '0.65rem' }} />
              )}
              {/* 2026-10-26 -- a running execution can be STOPPED from here:
                  the query at the source, the processes and the pod go with it */}
              {(execution.status === 'running' || execution.status === 'pending') && (
                <Button size="small" color="warning" variant="outlined" startIcon={<StopIcon />}
                        data-testid="feed-run-stop" sx={{ ml: 'auto' }}
                        onClick={async () => {
                          if (!await confirmStopRun(runName)) return;
                          try {
                            await api.cancelFeedExecution(execution.id);
                            setRerunNote(`${runName || 'This run'}: ${STOP_REQUESTED}`);
                            reload();
                          } catch (e: any) {
                            setRerunError(e?.message || 'The run could not be stopped');
                          }
                        }}>Stop this run</Button>
              )}
            </Stack>
            {execution.status === 'cancelled' && (
              <Alert severity="warning" icon={<StopIcon />} sx={{ mt: 1 }} data-testid="feed-run-cancelled-words">
                <Typography variant="body2" sx={{ fontWeight: 700 }}>
                  {cancelledWords(execution.cancelled_by, execution.cancelled_at)}
                </Typography>
                {execution.error_message && (
                  <Typography variant="caption" component="div">{execution.error_message}</Typography>
                )}
                {execution.cancel?.all_reached === false && (
                  <Typography variant="caption" component="div" sx={{ fontWeight: 700 }}>
                    Check the source: a query there may still be running.
                  </Typography>
                )}
              </Alert>
            )}
            <Typography variant="caption" sx={{ display: 'block', mt: 0.5, fontFamily: 'monospace', color: 'text.secondary' }}>
              execution {execution.execution_id}
              {execution.trigger_type ? ` · trigger ${execution.trigger_type}` : ''}
              {execution.triggered_by ? ` by ${execution.triggered_by}` : ''}
            </Typography>
            {/* 2026-10-14 -- WHERE the run is, while it runs (and the last
                report it made, after); a run that never reported says so. */}
            {(execution.status === 'running' || execution.status === 'pending') && (
              <Box sx={{ mt: 1 }} data-testid="feed-run-progress">
                {execution.progress
                  ? <RunProgressBar progress={execution.progress} />
                  : <Typography variant="caption" color="text.secondary">
                      No progress reported yet{execution.execution_backend === 'native'
                        ? ' (this run shows its current step on the board and in its live log)'
                        : ' — a Spark run reports every 30 s once its pod starts'}.
                    </Typography>}
              </Box>
            )}
            {execution.destination_path && (
              <Typography variant="caption" sx={{ display: 'block', fontFamily: 'monospace', color: 'text.secondary', wordBreak: 'break-all' }}>
                delivered to {execution.destination_path}
              </Typography>
            )}
            {/* 2026-10-07 -- a completed run that delivered NOTHING by
                design (backfill without delivery / policy / dry run) says
                so, and where the produced file is kept. */}
            {!execution.destination_path && (execution.delivery_verdict === 'suppressed' || execution.delivery_verdict === 'dry_run') && (
              <Typography variant="caption" data-testid="feed-run-not-delivered"
                          sx={{ display: 'block', color: 'warning.main', wordBreak: 'break-all' }}>
                NOT delivered — {execution.delivery_verdict === 'dry_run'
                  ? 'a dry run sends nothing'
                  : (execution.delivery_reason || 'delivery was suppressed for this run')}
                {execution.artifact_path ? `; the produced file is kept at ${execution.artifact_path}` : ''}
              </Typography>
            )}
            {!execution.artifact_path && execution.artifact_unavailable_reason && (
              <Typography variant="caption" data-testid="feed-run-no-artifact"
                          sx={{ display: 'block', color: 'text.secondary', wordBreak: 'break-all' }}>
                no downloadable file — {execution.artifact_unavailable_reason}
              </Typography>
            )}
            {execution.spark && (
              <Box sx={{ mt: 0.5 }} data-testid="feed-run-spark-pod">
                <Typography variant="caption" sx={{ display: 'block', fontFamily: 'monospace', wordBreak: 'break-all' }}>
                  driver pod <strong>{execution.spark.driver_pod}</strong> (namespace {execution.spark.namespace})
                </Typography>
                {execution.spark.submit_mode && (
                  <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }} data-testid="feed-run-submit-mode">
                    submitted as {execution.spark.submit_mode === 'driver_pod'
                      ? 'a plain driver Pod (no spark-operator)'
                      : 'a SparkApplication (spark-operator)'}
                    {execution.spark.submit_mode_declared === 'auto' ? ' — resolved by auto' : ''}
                  </Typography>
                )}
                <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }}>
                  {execution.spark.checked
                    ? `on the cluster now: ${execution.spark.cluster_state}${execution.spark.reason ? ` — ${execution.spark.reason}` : ''}`
                    : `cluster state ${execution.spark.reason || 'not checked'}`}
                  {' · '}<code>{execution.spark.kubectl}</code>
                </Typography>
                {execution.webhook_verification && (
                  <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary' }}>
                    webhook: reported {typeof execution.webhook_verification.reported_rows === 'number' ? fmtRows(execution.webhook_verification.reported_rows) : '?'} rows
                    {execution.webhook_verification.recountable === false && execution.webhook_verification.reason
                      ? ` — ${execution.webhook_verification.reason}` : ''}
                  </Typography>
                )}
                <Box sx={{ mt: 0.5 }}>
                  {driverLog.state === 'idle' && (
                    <Button size="small" variant="outlined" onClick={() => void loadDriverLog()} data-testid="feed-run-driver-log-btn">
                      View driver log
                    </Button>
                  )}
                  {driverLog.state === 'loading' && (
                    <Stack direction="row" spacing={1} alignItems="center"><CircularProgress size={14} /><Typography variant="caption">Fetching the driver log…</Typography></Stack>
                  )}
                  {driverLog.state === 'unavailable' && (
                    <Alert severity="info" sx={{ py: 0 }}>
                      Driver log not available: {driverLog.reason}
                    </Alert>
                  )}
                  {driverLog.state === 'error' && (
                    <Alert severity="warning" sx={{ py: 0 }}>
                      Driver log could not be read — {driverLog.reason}
                    </Alert>
                  )}
                  {driverLog.state === 'shown' && (
                    <Box data-testid="feed-run-driver-log">
                      <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                        {driverLog.pod} · last {driverLog.lines.length} lines · <code>{driverLog.kubectl}</code>
                      </Typography>
                      <Box component="pre" sx={{ m: 0, mt: 0.5, p: 1, maxHeight: 320, overflow: 'auto', fontSize: '0.72rem', bgcolor: 'action.hover', borderRadius: 1, whiteSpace: 'pre' }}>
                        {driverLog.lines.join('\n')}
                      </Box>
                    </Box>
                  )}
                </Box>
              </Box>
            )}
          </Box>
        )}

        {/* 2026-10-03 — ON COMPLETION OF: what started this run, and what
            this run's completion started.  The sentences are the server's. */}
        {!loading && !error && data?.trigger && (
          <Alert severity="info" sx={{ mb: 1 }} data-testid="feed-steps-trigger">
            {data.trigger.text}
          </Alert>
        )}
        {!loading && !error && data && data.downstream === null && (
          <Alert severity="warning" sx={{ mb: 1 }} data-testid="feed-steps-downstream-unreadable">
            What this run's completion started could not be read — this is
            not the same as it having started nothing.
          </Alert>
        )}
        {!loading && !error && (data?.downstream?.length ?? 0) > 0 && (
          <Box sx={{ mb: 1.5 }} data-testid="feed-steps-downstream">
            <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5 }}>
              Feeds that run on this feed's completion
            </Typography>
            <Stack spacing={0.5}>
              {data!.downstream!.map((rec, i) => (
                <Alert key={`${rec.event_type}-${i}`}
                  severity={rec.event_type === 'downstream_triggered' ? 'success' : 'info'}
                  sx={{ py: 0 }}>
                  {rec.reason && (
                    <Typography variant="caption" sx={{ display: 'block' }}>{rec.reason}</Typography>
                  )}
                  {rec.downstream.map(d => (
                    <Typography key={`${d.feed_id}-${d.outcome}`} variant="caption" sx={{ display: 'block' }}>
                      <strong>{d.feed_name}</strong>: {d.outcome.replace(/_/g, ' ')}
                      {d.run_id ? ` (run ${d.run_id}${d.status ? `, ${d.status}` : ''})` : ''}
                      {d.reason && d.outcome !== 'created' ? ` — ${d.reason}` : ''}
                    </Typography>
                  ))}
                  {rec.queue_consumer && !rec.queue_consumer.present && (
                    <Typography variant="caption" sx={{ display: 'block' }}>
                      No queue consumer was found: {rec.queue_consumer.detail}
                    </Typography>
                  )}
                </Alert>
              ))}
            </Stack>
          </Box>
        )}

        {/* 2026-09-27 — the operator DECISIONS stamped for this run: a
            dependency skipped with a reason, a Run Now that went although
            the gate said not met, the WAIT escalation.  From the ledger,
            never inferred from the steps.  null = could not be read. */}
        {!loading && !error && data && data.decisions === null && (
          <Alert severity="warning" sx={{ mb: 1 }} data-testid="feed-steps-decisions-unreadable">
            The decisions recorded for this run (skips, overrides) could not
            be read — this is not the same as there being none.
          </Alert>
        )}
        {!loading && !error && data && (data.decisions?.length ?? 0) > 0 && (
          <Box sx={{ mb: 1.5 }} data-testid="feed-steps-decisions">
            <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5 }}>
              Decisions on this run
            </Typography>
            <Stack spacing={0.5}>
              {data.decisions!.map((d, i) => {
                const w = decisionWords(d);
                return (
                  <Alert key={`${d.event_type}-${d.dependency_key}-${i}`} severity={w.color}
                    sx={{ py: 0 }} data-testid={`feed-steps-decision-${d.event_type}`}>
                    <strong>{w.title}</strong>
                    <Typography variant="caption" sx={{ display: 'block' }}>{w.detail}</Typography>
                  </Alert>
                );
              })}
            </Stack>
          </Box>
        )}

        {!loading && !error && data && steps.length === 0 && (
          <Alert severity="info">
            No steps recorded for this run yet.
          </Alert>
        )}

        {rerunError && (
          <Alert severity="error" sx={{ mb: 1 }} onClose={() => setRerunError(null)}>
            {rerunError}
          </Alert>
        )}
        {rerunNote && (
          <Alert severity="success" sx={{ mb: 1 }} onClose={() => setRerunNote(null)}>
            {rerunNote}
          </Alert>
        )}
        {verdictError && steps.length > 0 && (
          <Alert severity="warning" sx={{ mb: 1 }}>
            Re-run availability could not be read ({verdictError}). Every
            button below is therefore UNKNOWN, not refused.
          </Alert>
        )}

        {!loading && !error && steps.length > 0 && (
          <Box>
            {levelled.map(group => (
              <Box key={group.level ?? 'flat'} sx={{ mb: 1 }}>
                {group.level != null && (
                  <Typography
                    variant="overline"
                    data-testid={`feed-step-level-${group.level}`}
                    sx={{ display: 'block', color: 'text.secondary', letterSpacing: 1 }}
                  >
                    Level {group.level} · {group.items.length}{' '}
                    {group.items.length === 1
                      ? 'step'
                      : 'steps with no dependency between them (may run in parallel)'}
                  </Typography>
                )}
                {group.items.map((s, i) => {
                  const isCurrent = data?.current === s.name && !data?.terminal;
                  const isFailed = s.state === 'failed';
                  const vs = verdictFor(s.name);
                  const canRerun = vs.kind === 'verdict' && vs.verdict.allowed;
                  const rerunReason =
                    vs.kind === 'verdict' ? vs.verdict.reason
                    : vs.kind === 'unreadable'
                      ? `The re-run verdict could not be read (${vs.error}) — this is unknown, not a refusal.`
                      : 'The server returned no re-run verdict for this step.';
                  return (
                    <Stack
                      key={`${s.name}-${i}`}
                      direction="row"
                      spacing={1.25}
                      alignItems="flex-start"
                      data-testid={`feed-step-${s.name}`}
                      sx={{
                        py: 0.75, px: 1,
                        borderLeft: '3px solid',
                        borderLeftColor:
                          isFailed ? 'error.main'
                          : s.state === 'completed' ? 'success.main'
                          : s.state === 'running' ? 'info.main'
                          : 'divider',
                        bgcolor: isFailed ? 'error.lighter' : (isCurrent ? 'action.selected' : 'transparent'),
                        borderRadius: 0.5,
                        mb: 0.25,
                      }}
                    >
                      <Box sx={{ mt: 0.25 }}>{STEP_ICON[s.state] ?? STEP_ICON.pending}</Box>
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap">
                          <Typography variant="body2" sx={{ fontWeight: isFailed || isCurrent ? 700 : 500 }}>
                            {s.name}
                          </Typography>
                          <Chip
                            size="small"
                            label={s.state}
                            color={STEP_CHIP_COLOR[s.state] ?? 'default'}
                            variant={isFailed ? 'filled' : 'outlined'}
                            sx={{ height: 18, fontSize: '0.62rem', textTransform: 'uppercase' }}
                          />
                          {isFailed && (
                            <Chip
                              size="small"
                              label="failed here"
                              color="error"
                              sx={{ height: 18, fontSize: '0.62rem', fontWeight: 700 }}
                            />
                          )}
                          {isCurrent && !isFailed && (
                            <Chip
                              size="small" label="current" color="info" variant="outlined"
                              sx={{ height: 18, fontSize: '0.62rem' }}
                            />
                          )}
                          {typeof s.attempt === 'number' && (
                            <Chip
                              size="small" variant="outlined"
                              label={`attempt ${s.attempt}${
                                typeof s.max_attempts === 'number' ? ` of ${s.max_attempts}` : ''}`}
                              sx={{ height: 18, fontSize: '0.62rem' }}
                            />
                          )}
                          {typeof s.rows_out === 'number' && (
                            <Chip
                              size="small" variant="outlined"
                              label={`${fmtRows(s.rows_out)} rows out`}
                              sx={{ height: 18, fontSize: '0.62rem' }}
                            />
                          )}
                          {typeof s.rows_in === 'number' && (
                            <Chip
                              size="small" variant="outlined"
                              label={`${fmtRows(s.rows_in)} rows in`}
                              sx={{ height: 18, fontSize: '0.62rem' }}
                            />
                          )}
                        </Stack>
                        {(s.started_at || s.worker_node) && (
                          <Typography
                            variant="caption"
                            sx={{ display: 'block', color: 'text.secondary', fontFamily: 'monospace' }}
                          >
                            {s.started_at ? `${s.started_at} → ${s.ended_at || '…'}` : ''}
                            {s.started_at && s.worker_node ? '  ·  ' : ''}
                            {s.worker_node ? `on ${s.worker_node}` : ''}
                          </Typography>
                        )}
                        {s.detail && (
                          <Typography
                            variant="caption"
                            sx={{
                              display: 'block',
                              color: isFailed ? 'error.dark' : 'text.secondary',
                              whiteSpace: 'pre-wrap', wordBreak: 'break-word',
                            }}
                          >
                            {s.detail}
                          </Typography>
                        )}
                        {/* A step that BROKE is the one an operator is
                            here to re-run.  When it may not be, the
                            server's reason is on the screen rather than
                            behind a hover — and it is the server's, not a
                            friendlier one composed here. */}
                        {source === 'recorded' && !canRerun
                          && (s.state === 'failed' || s.state === 'refused') && (
                          <Typography
                            variant="caption"
                            data-testid={`feed-step-rerun-reason-${s.name}`}
                            sx={{ display: 'block', color: 'text.secondary', fontStyle: 'italic' }}
                          >
                            cannot re-run: {rerunReason}
                          </Typography>
                        )}
                      </Box>
                      <Typography variant="caption" sx={{ color: 'text.secondary', whiteSpace: 'nowrap', mt: 0.25 }}>
                        {fmtSeconds(s.seconds)}
                      </Typography>
                      {source === 'recorded' && (
                        <Tooltip title={rerunReason}>
                          {/* span: a disabled button emits no events, so the
                              tooltip carrying the SERVER's reason would be
                              unreachable without a wrapper. */}
                          <span>
                            <IconButton
                              size="small"
                              aria-label={`re-run step ${s.name}`}
                              disabled={!canRerun || rerunning != null}
                              onClick={() => void onRerun(s.name)}
                            >
                              <RetryIcon fontSize="small" />
                            </IconButton>
                          </span>
                        </Tooltip>
                      )}
                    </Stack>
                  );
                })}
              </Box>
            ))}
          </Box>
        )}
    </AppDialog>
  );
};

export default FeedRunStepsDialog;
