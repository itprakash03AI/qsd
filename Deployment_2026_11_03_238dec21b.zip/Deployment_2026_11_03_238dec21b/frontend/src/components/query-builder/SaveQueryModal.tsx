import React, { useState, useEffect } from 'react';
import {
  Accordion, AccordionDetails, AccordionSummary,
  Box, Typography, Button, Paper, TextField, Chip, Stack, Alert, Divider,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import {
  Save as SaveIcon, Check as CheckIcon,
  CloudUpload as PublishIcon, RssFeed as RssIcon, TableChart as DatasetIcon,
  NoteAdd as NewIcon,
} from '@mui/icons-material';
import { ExpandMore as ExpandMoreIcon } from '@mui/icons-material';
import api from '../../services/api';
import { useNotifications } from '../../context/NotificationContext';
import PartitionConfigEditor, { type ColumnChoices }
  from '../common/PartitionConfigEditor';
import type { PartitionConfig } from '../../types/api';

interface SaveQueryModalProps {
  open: boolean;
  queryConfig: any;
  sqlPreview: string;
  editingQueryId: number | null;
  editingQueryName: string;
  paramDefinitions?: any[];   // Phase 86: detected param definitions to store with query
  onClose: () => void;
  onSaved: (id: number, name: string) => void;
  /** 2026-09-01 — what the user almost always wants NEXT.  Optional: an
   *  absent callback simply omits that action, matching the toolbar's
   *  visibility contract. */
  onPublish?: () => void;
  onCreateFeed?: () => void;
  onCreateDataset?: () => void;
  /** Drop the "currently editing" binding so the next save CREATES. */
  onStartAnother?: () => void;
  /** Hand the edited partition declaration BACK to the builder that owns
   *  `queryConfig`.  Without it the builder rebuilds the config from its own
   *  state on every render, this dialog re-seeds from that config each time it
   *  opens, and a declaration made here would be gone the second time the
   *  dialog was opened -- present in the saved row, absent on screen.  One
   *  owner, one value. */
  onPartitionConfigChange?: (cfg: PartitionConfig | null) => void;
  /** Open on the "What next" step for a query that is ALREADY saved --
   *  the user came back from Create Dataset / Create Feed with Cancel and
   *  should see the same choices again (utils/returnTo.ts). */
  initialSavedAs?: { id: number; name: string } | null;
}

/** The message a user can act on, out of whatever the API threw.
 *  FastAPI validation errors arrive as `detail: [{loc, msg}]`, and reading
 *  `.message` off that object yields undefined — which is why a rejected
 *  save could look like nothing happening at all. */
const readableError = (err: any): string => {
  const d = err?.detail ?? err?.body?.detail;
  if (Array.isArray(d)) {
    return d.map((e: any) => {
      const where = Array.isArray(e?.loc) ? e.loc.slice(1).join('.') : '';
      return where ? `${where}: ${e?.msg || 'invalid'}` : (e?.msg || 'invalid');
    }).join('; ');
  }
  if (typeof d === 'string' && d) return d;
  if (err?.message) return err.message;
  return 'The save was rejected and the server gave no reason.';
};

const SaveQueryModal = ({
  open, queryConfig, sqlPreview, editingQueryId, editingQueryName,
  paramDefinitions, onClose, onSaved,
  onPublish, onCreateFeed, onCreateDataset, onStartAnother,
  onPartitionConfigChange, initialSavedAs = null,
}: SaveQueryModalProps) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  /** Non-null once THIS dialog has saved something — switches the body to
   *  the "what next" step instead of closing and leaving the user to hunt
   *  for Publish / Feed / Dataset in the toolbar. */
  const [savedAs, setSavedAs] = useState<{ id: number; name: string } | null>(null);
  /** The PUBLISHED-VIEW lane's producer.  A published view reads its
   *  partition config out of the frozen `query_config` it snapshots from this
   *  saved query at publish time, so THIS dialog is where the declaration has
   *  to be made -- there is nowhere later.  Seeded from the incoming config so
   *  updating a query that already declares one does not quietly drop it. */
  const [partitionConfig, setPartitionConfig] =
    useState<PartitionConfig | null>(null);
  const { addNotification } = useNotifications();

  useEffect(() => {
    if (open) {
      setName(editingQueryName || '');
      setDescription('');
      setError(null);
      setSavedAs(initialSavedAs);
      const declared = (queryConfig || {}).partition_config;
      setPartitionConfig(
        declared && typeof declared === 'object' ? declared : null);
    }
    // `queryConfig` is rebuilt on every render of the builder above, so it is
    // deliberately NOT a dependency: re-seeding on every keystroke would
    // overwrite what the author is typing here with the last saved value.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editingQueryName]);

  /** @param asNew force a CREATE even while editing an existing query. */
  const doSave = async (asNew: boolean) => {
    if (!name.trim()) { setError('Give the query a name first.'); return; }
    setBusy(true);
    setError(null);
    try {
      // The declaration rides INSIDE query_config, which is the shape
      // `published_views_api._partition_config` reads back and the shape
      // `QueryConfigModel.partition_config` declares.  Absent means absent:
      // writing `partition_config: null` when there is none would put a key
      // in the document that the author never asked for.
      const cfgOut: any = { ...(queryConfig || {}) };
      if (partitionConfig) cfgOut.partition_config = partitionConfig;
      else delete cfgOut.partition_config;
      const basePayload: any = {
        name: name.trim(),
        description: description || null,
        query_config: cfgOut,
      };
      if (paramDefinitions && paramDefinitions.length > 0) {
        basePayload.param_definitions = paramDefinitions;
      }
      const updating = !!editingQueryId && !asNew;
      const result = updating
        ? await api.updateQuery(editingQueryId as number, basePayload)
        : await api.saveQuery(basePayload);

      const id = result?.id ?? editingQueryId;
      addNotification({
        type: 'success',
        title: updating ? 'Query Updated' : 'Query Saved',
        message: `"${name.trim()}" ${updating ? 'updated' : 'saved'} successfully`,
      });
      if (onSaved && id) onSaved(id, name.trim());
      setSavedAs({ id, name: name.trim() });
    } catch (_err) {
      const msg = readableError(_err);
      setError(msg);
      addNotification({ type: 'error', title: 'Save Error', message: msg });
    } finally {
      setBusy(false);
    }
  };

  const isEditing = !!editingQueryId;

  /** The columns this query already names.  They come from the config the
   *  builder just handed over, so there is nothing to fetch and no failure
   *  mode -- but a query whose columns are not enumerated (SELECT *, a raw
   *  statement) genuinely offers no choices, and that is 'ready with none',
   *  not 'could not read'.  freeSolo means a qualified name can still be
   *  typed. */
  const columnChoices: ColumnChoices = {
    state: 'ready',
    columns: (Array.isArray(queryConfig?.columns) ? queryConfig.columns : [])
      .map((c: any) => String(c || '')).filter(Boolean),
  };

  /** Backdrop clicks do NOT dismiss: this dialog holds typing that is not
   *  recoverable once the tree unmounts, and a stray click beside a modal is
   *  the easiest gesture in the world to make by accident.  Escape and the
   *  explicit controls still close it. */
  const handleDialogClose = (_e: unknown, reason?: string) => {
    if (reason === 'backdropClick') return;
    onClose();
  };

  const nextAction = (label: string, icon: React.ReactNode, fn?: () => void) =>
    fn ? (
      <Button size="small" variant="outlined" startIcon={icon}
              onClick={() => { fn(); onClose(); }}>
        {label}
      </Button>
    ) : null;

  return (
    <AppDialog open={open}
      onClose={handleDialogClose}
      size="sm"
      icon={savedAs ? <CheckIcon color="success" /> : <SaveIcon />}
      title={savedAs ? 'Saved' : isEditing ? 'Update Query' : 'Save Query'}
      titleExtra={isEditing && !savedAs && (
            <Chip label="Editing" size="small" color="warning" />
      )}
      // Always-present close affordance -- the only way out when the
      // backdrop no longer dismisses.
      closeButton
      actions={<>
        {savedAs ? (
          <>
            <Button
              startIcon={<NewIcon />}
              onClick={() => {
                // Unbind from the query just saved so the NEXT save creates
                // a second one instead of renaming this one.
                onStartAnother?.();
                setSavedAs(null);
                setName('');
                setDescription('');
              }}>
              Save another
            </Button>
            <Button variant="contained" onClick={onClose}>Done</Button>
          </>
        ) : (
          <>
            <Button onClick={onClose} disabled={busy}>Cancel</Button>
            {isEditing && (
              <Button onClick={() => doSave(true)} disabled={busy}>
                Save as new
              </Button>
            )}
            <Button variant="contained" onClick={() => doSave(false)}
                    disabled={busy} startIcon={<SaveIcon />}>
              {busy ? 'Saving…' : isEditing ? 'Update Query' : 'Save Query'}
            </Button>
          </>
        )}
      </>}>
        {savedAs ? (
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Alert severity="success" sx={{ py: 0.5 }}>
              <strong>{savedAs.name}</strong> is saved. It is yours — other
              users do not see it unless you share it.
            </Alert>
            <Box>
              <Typography variant="caption" color="text.secondary"
                          sx={{ fontWeight: 600, display: 'block', mb: 1 }}>
                WHAT NEXT
              </Typography>
              <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
                {nextAction('Publish as API', <PublishIcon fontSize="small" />, onPublish)}
                {nextAction('Create Feed', <RssIcon fontSize="small" />, onCreateFeed)}
                {nextAction('Create Dataset', <DatasetIcon fontSize="small" />, onCreateDataset)}
              </Stack>
            </Box>
            <Divider />
            <Typography variant="caption" color="text.secondary">
              Your SQL is still in the editor — nothing was cleared. Choose
              "Save another" to write a second query from it without leaving
              this page.
            </Typography>
          </Stack>
        ) : (
          <Stack spacing={2} sx={{ mt: 1 }}>
            {error && <Alert severity="error" sx={{ py: 0.5 }}>{error}</Alert>}
            {isEditing && (
              <Alert severity="info" sx={{ py: 0.5 }}>
                This will UPDATE "{editingQueryName}". To keep that one and
                write a new query instead, use <strong>Save as new</strong>.
              </Alert>
            )}
            <TextField
              label="Query Name" required fullWidth autoFocus
              value={name}
              onChange={e => { setName(e.target.value); setError(null); }}
              placeholder="e.g., Monthly Sales Report"
              onKeyDown={e => e.key === 'Enter' && !busy && doSave(false)}
            />
            <TextField
              label="Description" fullWidth multiline rows={2}
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Optional description"
            />
            <Accordion disableGutters elevation={0}
                       TransitionProps={{ unmountOnExit: true }}
                       sx={{ border: 1, borderColor: 'divider' }}>
              <AccordionSummary expandIcon={<ExpandMoreIcon />}
                                data-testid="save-query-partition-section">
                <Typography variant="body2" fontWeight={600}>
                  Progressive partition loading
                </Typography>
                {partitionConfig?.column && (
                  <Chip size="small" sx={{ ml: 1 }}
                        label={`column: ${partitionConfig.column}`} />
                )}
              </AccordionSummary>
              <AccordionDetails>
                <PartitionConfigEditor
                  testIdPrefix="save-query-partition"
                  value={partitionConfig}
                  columns={columnChoices}
                  onChange={next => {
                    setPartitionConfig(next);
                    onPartitionConfigChange?.(next);
                  }}
                  reachNote={(
                    <Alert severity="info" sx={{ py: 0.25 }}
                           data-testid="save-query-partition-reach">
                      This declaration is snapshotted into a published view
                      when the query is published, and it is read on the
                      view’s bulk build. A saved query run from the
                      editor does not go through that build, so setting a
                      column here changes nothing until the query is
                      published.
                    </Alert>
                  )} />
              </AccordionDetails>
            </Accordion>
            <Paper sx={{ p: 2, bgcolor: 'grey.50' }}>
              <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>
                SQL Preview
              </Typography>
              <Box component="pre" sx={{ fontFamily: 'monospace', fontSize: 12, m: 0, whiteSpace: 'pre-wrap', color: 'text.primary', maxHeight: 120, overflowY: 'auto' }}>
                {sqlPreview}
              </Box>
            </Paper>
          </Stack>
        )}
    </AppDialog>
  );
};

export default SaveQueryModal;
