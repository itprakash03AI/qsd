import React from 'react';
import {
  Box, Typography, Button, Card, CardContent, Checkbox, Chip, Stack,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import {
  TableChart as TableIcon, Warning as WarningIcon,
} from '@mui/icons-material';
import { clickable } from '../../utils/clickable';

interface TableSelectorModalProps {
  open: boolean;
  files: any[];
  selectedTables: any[];
  onUpdate: (tables: any[]) => void;
  onClose: () => void;
}

const TableSelectorModal = ({ open, files, selectedTables, onUpdate, onClose }: TableSelectorModalProps) => {
  const toggleTable = (file: any) => {
    const exists = selectedTables.find(t => t.path === file.path);
    if (exists) {
      onUpdate(selectedTables.filter(t => t.path !== file.path));
    } else {
      onUpdate([...selectedTables, file]);
    }
  };

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="sm"
      icon={<TableIcon />}
      title="Select Tables"
      actions={<>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={onClose}>
          Done ({selectedTables.length})
        </Button>
      </>}>
        <Stack spacing={1}>
          {files.length === 0 && (
            <Typography variant="body2" color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
              No parquet files found in this data source.
            </Typography>
          )}
          {files.map(file => {
            const isSelected = selectedTables.find(t => t.path === file.path);
            return (
              <Card
                key={file.path}
                variant="outlined"
                sx={{
                  cursor: 'pointer',
                  bgcolor: isSelected ? 'action.selected' : 'background.paper',
                  borderColor: isSelected ? 'primary.main' : 'divider',
                  '&:hover': { bgcolor: 'action.hover' },
                }}
                // 2026-09-25 (Docker E2E crawl): the card was a mouse-only div
                // -- no role, no tab stop, so a keyboard user could not select
                // a table here -- and its checkbox was an unnamed control on
                // every card (72 on the Trino tpch catalogue).  The CARD is the
                // toggle; the checkbox only shows its state.
                {...clickable(() => toggleTable(file), {
                  pressed: !!isSelected,
                  label: file.folder ? `${file.name} (${file.folder})` : file.name,
                })}
              >
                <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 1.5, py: 1.5, '&:last-child': { pb: 1.5 } }}>
                  <Checkbox checked={!!isSelected} readOnly tabIndex={-1} inputProps={{ 'aria-hidden': true }} />
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'medium' }}>
                      {file.name}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
                      {file.folder && (
                        <Typography variant="body2" color="text.disabled" sx={{ fontSize: 11 }}>
                          {file.folder}/
                        </Typography>
                      )}
                      <Typography variant="body2" color="text.secondary">
                        {file.num_rows?.toLocaleString()} rows &middot; {file.num_columns} cols
                      </Typography>
                      {file.num_rows > 1000000 && (
                        <Chip
                          icon={<WarningIcon />}
                          label="Large"
                          size="small"
                          color="warning"
                          variant="outlined"
                        />
                      )}
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            );
          })}
        </Stack>
    </AppDialog>
  );
};

export default TableSelectorModal;
