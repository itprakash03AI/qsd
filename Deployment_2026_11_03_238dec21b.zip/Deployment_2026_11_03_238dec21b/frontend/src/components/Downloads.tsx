/**
 * Download Center — Query Studio
 * Shows all exports (CSV auto-generated + explicit Excel/JSON exports).
 * Features: format badge, duration, row count, preview dialog, stats bar.
 */
import { appAlert } from './common/appDialogs';
import React, { useState, useEffect, useMemo } from 'react';
import {
  Box, Typography, Button, Paper, Chip, Stack, Divider,
  ToggleButtonGroup, ToggleButton, CircularProgress, IconButton, Tooltip,
  TextField, InputAdornment, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TableSortLabel, TablePagination, Alert,
  FormControl, InputLabel, Select, MenuItem,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import { STICKY_ACTIONS_SX } from './common/stickyActions';
import {
  Download as DownloadIcon,
  Delete as DeleteIcon,
  Refresh as RefreshIcon,
  InsertDriveFile as FileIcon,
  TableChart as ExcelIcon,
  DataObject as JsonIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  Visibility as PreviewIcon,
  Storage as StorageIcon,
  CheckCircleOutline as AvailableIcon,
  TimerOutlined as TimerIcon,
  CleaningServices as CleanupIcon,
  FolderOpen as FolderIcon,
  Code as CodeIcon,
  ContentCopy as CopyIcon,
} from '@mui/icons-material';
import { TableChart as TableChartIcon } from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { useWebSocket } from '../context/WebSocketContext';
import { useAuth } from '../context/AuthContext';
import { isAdminLike } from '../utils/reportLifecycle';
import api from '../services/api';
import { safeFetch, openDownload } from '../services/api/core';
import DataGridViewer from './DataGridViewer';
import FloatingWindow from './common/FloatingWindow';

// ─────────────────────────────────────────────────────────────
// Formatters
// ─────────────────────────────────────────────────────────────
const fmtSize = (bytes) => {
  if (!bytes) return '—';
  const k = 1024, sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
};

const fmtDate = (s) => {
  if (!s) return '—';
  return new Date(s).toLocaleString(undefined, {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
};

const fmtDuration = (secs) => {
  if (secs == null || secs === '') return '—';
  const n = Number(secs);
  if (isNaN(n)) return '—';
  if (n < 60) return `${n.toFixed(1)}s`;
  const m = Math.floor(n / 60), s = Math.floor(n % 60);
  return `${m}m ${s}s`;
};

const fmtRows = (n) =>
  n != null && n !== '' ? Number(n).toLocaleString() : '—';

const statusColor = {
  available: 'success',
  downloaded: 'info',
  expired: 'warning',
  deleted: 'error',
};

const FORMAT_META = {
  excel:   { label: 'EXCEL',   color: 'success' },
  json:    { label: 'JSON',    color: 'info'    },
  csv:     { label: 'CSV',     color: 'default' },
  parquet: { label: 'PARQUET', color: 'warning' },
};

// BF-272: Detect format from filename extension, not by defaulting to CSV.
// The DownloadFile DB model has no `format` column so frontend has to
// infer from filename — which means the order matters and parquet must
// be checked.  Without this, every execute_api auto-created
// query_result_*.parquet row was rendered as CSV in the download center,
// making users think their CSV export had succeeded when in reality
// the export job's CSV row was either still pending or had silently
// failed and they were clicking the original parquet result.
const inferFormat = (filename) => {
  const lower = (filename || '').toLowerCase();
  if (lower.endsWith('.xlsx') || lower.endsWith('.xls')) return 'excel';
  if (lower.endsWith('.json'))    return 'json';
  if (lower.endsWith('.parquet')) return 'parquet';
  if (lower.endsWith('.csv'))     return 'csv';
  return 'csv';  // unknown — last-resort fallback for legacy rows
};

const FileTypeIcon = ({ filename, format }) => {
  const fmt = format || inferFormat(filename);
  if (fmt === 'excel')   return <ExcelIcon sx={{ color: '#217346', fontSize: 22 }} />;
  if (fmt === 'json')    return <JsonIcon  sx={{ color: '#00AFEC', fontSize: 22 }} />;
  if (fmt === 'parquet') return <StorageIcon sx={{ color: '#f97316', fontSize: 22 }} />;
  return <FileIcon sx={{ color: 'text.secondary', fontSize: 22 }} />;
};

const ROWS_PER_PAGE_OPTIONS = [25, 50, 100];

// The Download Center preview: THE floating window (common/FloatingWindow.tsx,
// 2026-10-27 -- the same window the feed form uses), NOT modal: the list
// behind it stays usable while a file is previewed.
const FloatingPreviewWindow = ({ open, onClose, download }) => {
  const canPreview = !!(download?.execution_id || download?.file_id);
  return (
    <FloatingWindow open={open} onClose={onClose} title={download?.filename || 'File Preview'}
                    titleIcon={<FileTypeIcon filename={download?.filename} format={download?.format} />}
                    headerActions={!download?.execution_id && download?.file_id ? (
                      <Chip label="file" size="small" variant="outlined"
                        sx={{ height: 16, fontSize: 9, color: 'rgba(255,255,255,0.55)', borderColor: 'rgba(255,255,255,0.25)' }} />
                    ) : undefined}
                    data-testid="download-preview-window">
      {!canPreview && (
        <Alert severity="info" sx={{ m: 2 }}>No file linked — preview unavailable.</Alert>
      )}
      {/* Prefer file_id mode — works for CSV, Excel, and JSON exports.
          Fall back to executionId only when there is no file_id (legacy). */}
      {canPreview && download?.file_id && (
        <DataGridViewer key={download.file_id} fileId={download.file_id} embedded />
      )}
      {canPreview && !download?.file_id && download?.execution_id && (
        <DataGridViewer key={download.execution_id} executionId={download.execution_id} embedded />
      )}
    </FloatingWindow>
  );
};

// ─────────────────────────────────────────────────────────────
// Main Component
// ─────────────────────────────────────────────────────────────
const Downloads = () => {
  const [downloads,    setDownloads]    = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [filter,       setFilter]       = useState('available');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [previewTarget,setPreviewTarget]= useState(null);
  const [sqlTarget,    setSqlTarget]    = useState(null);   // 2026-06-24 -- show SQL dialog
  const [search,       setSearch]       = useState('');
  const [sortField,    setSortField]    = useState('created_at');
  const [sortDir,      setSortDir]      = useState('desc');
  const [page,         setPage]         = useState(0);
  const [rowsPerPage,  setRowsPerPage]  = useState(25);
  const [storage,      setStorage]      = useState<any>(null);
  const [cleanupBusy,  setCleanupBusy]  = useState(false);

  const [promoteDialogOpen, setPromoteDialogOpen] = useState(false);
  const [promoteFile, setPromoteFile] = useState<any>(null);
  const [promoteName, setPromoteName] = useState('');
  const [promoteDescription, setPromoteDescription] = useState('');
  const [promoteVisibility, setPromoteVisibility] = useState('public');
  const [promoteLoading, setPromoteLoading] = useState(false);
  const [retentionTarget, setRetentionTarget] = useState<any>(null);
  const [retentionDays, setRetentionDays] = useState(7);

  const { addNotification } = useNotifications();
  const { addListener }     = useWebSocket();
  // 2026-09-24 -- GET /api/admin/storage is ``require_admin`` and feeds the
  // "Storage Usage" panel only.  /downloads is open to every role, and the
  // real-browser walk saw viewers and analysts asking for it on load (403 +
  // console error).  Ask only when the answer can be used.
  const { user } = useAuth();
  const canSeeStorage = isAdminLike(user);

  // ── Data loading ─────────────────────────────────────────
  const loadDownloads = async () => {
    setLoading(true);
    try {
      const qs  = filter ? `?status=${filter}` : '';
      const data = await safeFetch(`/api/exports${qs}`);
      setDownloads(data || []);
    } catch (_e) {
      const err = _e as Error;
      addNotification({ type: 'error', title: 'Error Loading Downloads', message: err.message });
      setDownloads([]);
    } finally {
      setLoading(false);
    }
  };

  const loadStorage = async () => {
    if (!canSeeStorage) return;  // admin-only figure; nothing here can show it
    try {
      setStorage(await safeFetch('/api/admin/storage'));
    } catch { /* non-fatal */ }
  };

  const handleCleanup = async () => {
    setCleanupBusy(true);
    try {
      await safeFetch('/api/admin/storage/cleanup', { method: 'POST' });
      addNotification({ type: 'success', title: 'Cleanup Complete', message: 'Stale files removed' });
      await Promise.all([loadDownloads(), loadStorage()]);
    } catch (e: any) {
      addNotification({ type: 'error', title: 'Cleanup Failed', message: e.message });
    } finally {
      setCleanupBusy(false);
    }
  };

  // Mount: load + subscribe to WS
  useEffect(() => {
    loadDownloads();
    loadStorage();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // WS listener — re-register when filter changes so reload uses current filter
  useEffect(() => {
    const remove = addListener(msg => {
      if (['export_completed', 'execution_completed'].includes(msg.type)) {
        setTimeout(loadDownloads, 1500);
      }
      // BF-272: surface export failures.  Without this, a failed CSV
      // export was silent — the user just saw the Downloads page never
      // grow a CSV row and assumed the auto-created parquet IS their CSV.
      if (msg.type === 'export_failed') {
        const m = msg as { format?: string; execution_id?: string; error?: string };
        const fmtLabel = (m.format || 'export').toUpperCase();
        const execShort = (m.execution_id || '').slice(0, 8);
        addNotification({
          type: 'error',
          title: 'Export Failed',
          message: `${fmtLabel} for execution ${execShort}…: ${m.error || 'unknown error'}`,
        });
      }
    });
    return () => remove();
  }, [filter]); // eslint-disable-line react-hooks/exhaustive-deps

  // Reload when filter changes
  useEffect(() => {
    loadDownloads();
    setPage(0);
  }, [filter]); // eslint-disable-line react-hooks/exhaustive-deps

  // Reset pagination on search change
  useEffect(() => { setPage(0); }, [search]);

  // ── Handlers ─────────────────────────────────────────────
  const handleDownload = async (fileId, filename) => {
    try {
      await openDownload(`/api/downloads/${fileId}/download`);
      addNotification({ type: 'success', title: 'Download Started', message: filename || 'File download initiated' });
      setTimeout(loadDownloads, 2000);
    } catch (_e) {
      const err = _e as Error;
      addNotification({ type: 'error', title: 'Download Failed', message: err.message });
      // 2026-08-31: refresh on failure too.  Retention is enforced when
      // the file is SERVED, so a row can be listed and then 410 on click
      // (it lapsed, or another session deleted it).  Leaving the stale
      // row on screen invites the same click again; reloading makes the
      // list agree with what the server will actually hand over.
      loadDownloads();
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteDownload(deleteTarget.file_id);
      addNotification({ type: 'success', title: 'Deleted', message: `"${deleteTarget.filename}" deleted` });
      loadDownloads();
    } catch (_e) {
      const err = _e as Error;
      addNotification({ type: 'error', title: 'Delete Failed', message: err.message });
    }
    setDeleteTarget(null);
  };

  // ── Retention ────────────────────────────────────────────
  // The user chooses how long their own file is kept.  The operator
  // maximum lives server-side and its 400 names the limit, so the UI
  // surfaces that message rather than restating a number it cannot know.
  const handleSetRetention = async (fileId: string, days: number) => {
    try {
      await api.setDownloadRetention(fileId, days);
      addNotification({ type: 'success', title: 'Retention Updated',
        message: `Kept for ${days} day${days === 1 ? '' : 's'} from now` });
      loadDownloads();
    } catch (_e) {
      const err = _e as Error;
      addNotification({ type: 'error', title: 'Could Not Change Retention',
        message: err.message });
    }
    setRetentionTarget(null);
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
    setPage(0);
  };

  // ── Derived data ─────────────────────────────────────────
  const stats = useMemo(() => {
    const available  = downloads.filter(d => d.status === 'available').length;
    const totalSize  = downloads.reduce((s, d) => s + (d.file_size_bytes || 0), 0);
    const excelCount = downloads.filter(d => d.format === 'excel').length;
    return { total: downloads.length, available, totalSize, excelCount };
  }, [downloads]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    let rows = q
      ? downloads.filter(d =>
          (d.filename     || '').toLowerCase().includes(q) ||
          (d.execution_id || '').toLowerCase().includes(q) ||
          (d.format       || '').toLowerCase().includes(q)
        )
      : downloads;

    return [...rows].sort((a, b) => {
      let av = a[sortField] ?? '';
      let bv = b[sortField] ?? '';
      const numericFields = ['file_size_bytes', 'download_count', 'total_rows', 'duration_seconds'];
      if (numericFields.includes(sortField)) {
        av = Number(av) || 0;
        bv = Number(bv) || 0;
      }
      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ?  1 : -1;
      return 0;
    });
  }, [downloads, search, sortField, sortDir]);

  const paginated = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  // ── Sort header helper ────────────────────────────────────
  const SortHeader = ({ field, label, align = 'left', width }: { field: string; label: string; align?: 'left' | 'right' | 'center'; width?: string | number }) => (
    <TableCell
      align={align}
      sx={{ fontWeight: 700, whiteSpace: 'nowrap', bgcolor: 'grey.50', width }}
    >
      <TableSortLabel
        active={sortField === field}
        direction={sortField === field ? (sortDir as 'asc' | 'desc') : 'asc'}
        onClick={() => handleSort(field)}
      >
        {label}
      </TableSortLabel>
    </TableCell>
  );

  // ── Render ────────────────────────────────────────────────
  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>

      {/* ── Page header ── */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
        <Box>
          <Typography variant="h5" fontWeight={700}>Download Center</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
            All exported files — CSV results, Excel, and JSON exports
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          {/* storage cleanup is an admin endpoint (2026-09-25: offered to an
              analyst, it answered 403) */}
          {canSeeStorage && (
          <Button
            variant="outlined"
            size="small"
            startIcon={cleanupBusy ? <CircularProgress size={14} /> : <CleanupIcon />}
            onClick={handleCleanup}
            disabled={cleanupBusy}
            color="warning"
          >
            Clean Up Now
          </Button>
          )}
          <Button
            variant="outlined"
            size="small"
            startIcon={<RefreshIcon />}
            onClick={() => { loadDownloads(); loadStorage(); }}
            disabled={loading}
          >
            Refresh
          </Button>
        </Box>
      </Box>

      {/* ── Storage summary ── */}
      {storage && (
        <Paper variant="outlined" sx={{ p: 2, mb: 3 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.5 }}>
            <StorageIcon fontSize="small" color="primary" />
            <Typography variant="subtitle2" fontWeight={700}>Storage Usage</Typography>
            {storage.disk?.used_pct != null && (
              <Chip
                size="small"
                label={`${storage.disk.used_pct}% disk used · ${storage.disk.free_gb} GB free`}
                color={storage.disk.free_gb < 5 ? 'error' : storage.disk.free_gb < 20 ? 'warning' : 'default'}
                variant="outlined"
              />
            )}
            <Box sx={{ flex: 1 }} />
            <Typography variant="caption" color="text.secondary">
              Downloads expire after {storage.settings?.downloads_expiry_days}d ·
              Execution history kept {storage.settings?.execution_retention_days}d ·
              Cleanup runs every 30 min
            </Typography>
          </Box>
          <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
            {Object.entries(storage.directories || {}).map(([name, info]: [string, any]) => (
              <Box key={name} sx={{ display: 'flex', alignItems: 'center', gap: 0.75, minWidth: 160 }}>
                <FolderIcon sx={{ fontSize: 16, color: 'text.secondary' }} />
                <Box>
                  <Typography variant="caption" color="text.secondary" sx={{ textTransform: 'capitalize' }}>
                    {name}
                  </Typography>
                  <Typography variant="body2" fontWeight={600}>
                    {info.size_mb} MB
                    <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.5 }}>
                      ({info.file_count} files)
                    </Typography>
                  </Typography>
                </Box>
              </Box>
            ))}
          </Stack>
        </Paper>
      )}

      {/* ── Stats bar ── */}
      {!loading && downloads.length > 0 && (
        <Paper
          variant="outlined"
          sx={{ display: 'flex', mb: 3, overflow: 'hidden', borderRadius: 2 }}
        >
          {[
            {
              icon: <StorageIcon sx={{ color: 'text.secondary' }} />,
              value: stats.total,
              label: 'Total Files',
            },
            {
              icon: <AvailableIcon color="success" />,
              value: stats.available,
              label: 'Available',
              color: 'success.main',
            },
            {
              icon: <DownloadIcon color="primary" />,
              value: fmtSize(stats.totalSize),
              label: 'Total Size',
              color: 'primary.main',
            },
            {
              icon: <ExcelIcon sx={{ color: '#217346' }} />,
              value: stats.excelCount,
              label: 'Excel Exports',
            },
          ].map((s, i, arr) => (
            <Box
              key={i}
              sx={{
                flex: 1, px: 3, py: 2,
                display: 'flex', alignItems: 'center', gap: 1.5,
                borderRight: i < arr.length - 1 ? '1px solid' : 'none',
                borderColor: 'divider',
              }}
            >
              {s.icon}
              <Box>
                <Typography variant="h6" fontWeight={700} color={s.color || 'text.primary'} lineHeight={1.2}>
                  {s.value}
                </Typography>
                <Typography variant="caption" color="text.secondary">{s.label}</Typography>
              </Box>
            </Box>
          ))}
        </Paper>
      )}

      {/* ── Toolbar ── */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2.5, flexWrap: 'wrap' }}>
        <ToggleButtonGroup
          value={filter}
          exclusive
          onChange={(_, val) => val !== null && setFilter(val)}
          size="small"
        >
          <ToggleButton value="available">Available</ToggleButton>
          <ToggleButton value="downloaded">Downloaded</ToggleButton>
          <ToggleButton value="expired">Expired</ToggleButton>
          <ToggleButton value="">All</ToggleButton>
        </ToggleButtonGroup>

        <TextField
          size="small"
          placeholder="Search filename, execution ID, or format…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          sx={{ flex: 1, minWidth: 260, maxWidth: 460 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon sx={{ fontSize: 18 }} />
              </InputAdornment>
            ),
            endAdornment: search ? (
              <InputAdornment position="end">
                <IconButton aria-label="Clear" size="small" onClick={() => setSearch('')}>
                  <ClearIcon sx={{ fontSize: 16 }} />
                </IconButton>
              </InputAdornment>
            ) : null,
          }}
        />

        <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto' }}>
          {loading
            ? 'Loading…'
            : `${filtered.length} of ${downloads.length} file${downloads.length !== 1 ? 's' : ''}`}
        </Typography>
      </Box>

      {/* ── Content ── */}
      {loading ? (
        <Box sx={{ textAlign: 'center', py: 10 }}>
          <CircularProgress />
        </Box>

      ) : downloads.length === 0 ? (
        <Paper sx={{ p: 8, textAlign: 'center', border: '2px dashed', borderColor: 'divider', borderRadius: 2 }}>
          <DownloadIcon sx={{ fontSize: 64, color: 'text.disabled', mb: 2 }} />
          <Typography variant="h6" gutterBottom>No downloads yet</Typography>
          <Typography color="text.secondary" sx={{ maxWidth: 420, mx: 'auto' }}>
            Run a query — the result CSV appears here automatically. Use the{' '}
            <strong>Export</strong> button in the Results viewer to also create
            Excel (.xlsx) or JSON exports.
          </Typography>
        </Paper>

      ) : filtered.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center', borderRadius: 2 }}>
          <Typography variant="h6" gutterBottom>No results for "{search}"</Typography>
          <Button onClick={() => setSearch('')}>Clear search</Button>
        </Paper>

      ) : (
        <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2 }}>
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                {/* Icon column */}
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', width: 44, pl: 2 }} />
                <SortHeader field="filename"    label="File"     />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', whiteSpace: 'nowrap' }}>Format</TableCell>
                <SortHeader field="total_rows"       label="Rows"     align="right" />
                <SortHeader field="file_size_bytes"  label="Size"     align="right" />
                <SortHeader field="duration_seconds" label="Duration" align="right" />
                <SortHeader field="created_at"       label="Created"  />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50' }}>Status</TableCell>
                <SortHeader field="download_count"   label="DLs"      align="center" />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', whiteSpace: 'nowrap' }}>Expires</TableCell>
                <TableCell sx={[STICKY_ACTIONS_SX, { fontWeight: 700, bgcolor: 'grey.50', pr: 2, zIndex: 3 }]}>Actions</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {paginated.map(d => {
                // BF-272: infer from filename instead of defaulting to CSV
                // so parquet auto-rows are clearly labeled.
                const fmt     = d.format || inferFormat(d.filename);
                const fmtMeta = FORMAT_META[fmt] || FORMAT_META.csv;
                const expired = d.expires_at && new Date(d.expires_at) < new Date();

                return (
                  <TableRow key={d.file_id} hover sx={{ '&:last-child td': { border: 0 } }}>

                    {/* Icon */}
                    <TableCell sx={{ pl: 2, py: 1 }}>
                      <FileTypeIcon filename={d.filename} format={fmt} />
                    </TableCell>

                    {/* File name + execution ID */}
                    <TableCell sx={{ maxWidth: 280 }}>
                      <Typography variant="body2" fontWeight={500} noWrap title={d.filename}>
                        {d.filename || '—'}
                      </Typography>
                      {d.execution_id && (
                        <Typography
                          variant="caption"
                          color="text.disabled"
                          sx={{ display: 'block', fontFamily: 'monospace' }}
                        >
                          {d.execution_id.substring(0, 13)}…
                        </Typography>
                      )}
                    </TableCell>

                    {/* Format badge */}
                    <TableCell>
                      <Chip
                        label={fmtMeta.label}
                        size="small"
                        color={fmtMeta.color}
                        variant="outlined"
                        sx={{ fontWeight: 700, fontSize: 10, height: 20, letterSpacing: 0.5 }}
                      />
                    </TableCell>

                    {/* Row count */}
                    <TableCell align="right">
                      <Typography variant="body2">{fmtRows(d.total_rows)}</Typography>
                    </TableCell>

                    {/* File size */}
                    <TableCell align="right">
                      <Typography variant="body2">{fmtSize(d.file_size_bytes)}</Typography>
                    </TableCell>

                    {/* Query duration */}
                    <TableCell align="right">
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 0.5 }}>
                        {d.duration_seconds != null && (
                          <TimerIcon sx={{ fontSize: 13, color: 'text.disabled' }} />
                        )}
                        <Typography variant="body2" color="text.secondary">
                          {fmtDuration(d.duration_seconds)}
                        </Typography>
                      </Box>
                    </TableCell>

                    {/* Created at */}
                    <TableCell sx={{ whiteSpace: 'nowrap' }}>
                      <Typography variant="body2">{fmtDate(d.created_at)}</Typography>
                    </TableCell>

                    {/* Status */}
                    <TableCell>
                      <Chip
                        label={d.status}
                        size="small"
                        color={statusColor[d.status] || 'default'}
                        variant="outlined"
                      />
                    </TableCell>

                    {/* Download count */}
                    <TableCell align="center">
                      <Typography variant="body2">{d.download_count ?? 0}</Typography>
                    </TableCell>

                    {/* Expires — click to choose how long to keep it.
                        Only for rows that are still live: a lapsed or deleted
                        row is refused server-side (410) rather than being
                        resurrected past the policy that retired it. */}
                    <TableCell sx={{ whiteSpace: 'nowrap' }}>
                      {d.status === 'available' && !expired ? (
                        <Tooltip title="Change how long this file is kept">
                          <Button
                            size="small"
                            variant="text"
                            startIcon={<TimerIcon fontSize="small" />}
                            aria-label={`Change retention for ${d.filename}`}
                            onClick={() => { setRetentionDays(7); setRetentionTarget(d); }}
                            sx={{ textTransform: 'none', minWidth: 0, p: 0.25 }}
                          >
                            <Typography variant="caption" color="text.secondary">
                              {d.expires_at ? new Date(d.expires_at).toLocaleDateString() : '—'}
                            </Typography>
                          </Button>
                        </Tooltip>
                      ) : (
                        <Typography
                          variant="caption"
                          color={expired ? 'error.main' : 'text.secondary'}
                        >
                          {d.expires_at ? new Date(d.expires_at).toLocaleDateString() : '—'}
                        </Typography>
                      )}
                    </TableCell>

                    {/* Actions -- pinned right so Download is never off-screen */}
                    <TableCell sx={[STICKY_ACTIONS_SX, { pr: 2 }]}>
                      {/* Preview — works with execution_id OR file_id directly */}
                      {(d.execution_id || d.file_id) && d.status === 'available' && (
                        <Tooltip title="Preview data">
                          <IconButton size="small" onClick={() => setPreviewTarget(d)}>
                            <PreviewIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}

                      {/* 2026-06-24 — View SQL.  Works whenever the
                          backend supplied query_sql (any execution
                          that had a SQL form).  Pure-frontend tap;
                          no API call. */}
                      {d.query_sql && (
                        <Tooltip title="View SQL">
                          <IconButton size="small" onClick={() => setSqlTarget(d)}>
                            <CodeIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}

                      {/* Download — only if file is available */}
                      {d.status === 'available' && (
                        <Tooltip title="Download file">
                          <IconButton
                            size="small"
                            color="primary"
                            onClick={() => handleDownload(d.file_id, d.filename)}
                          >
                            <DownloadIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}

                      {/* Register as Local Table — only for .parquet files that are available/downloaded */}
                      {d.filename?.endsWith('.parquet') && ['available', 'downloaded'].includes(d.status) && (
                        <Tooltip title="Register as Local Table">
                          <IconButton size="small" onClick={() => {
                            setPromoteFile(d);
                            setPromoteName(d.filename.replace('.parquet', '').replace(/[^a-zA-Z0-9_]/g, '_'));
                            setPromoteDescription('');
                            setPromoteVisibility('public');
                            setPromoteDialogOpen(true);
                          }}>
                            <TableChartIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      )}

                      {/* Delete */}
                      <Tooltip title="Delete">
                        <IconButton size="small" color="error" onClick={() => setDeleteTarget(d)}>
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>

                  </TableRow>
                );
              })}
            </TableBody>
          </Table>

          <TablePagination
            component="div"
            count={filtered.length}
            page={page}
            onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          />
        </TableContainer>
      )}

      {/* ── Floating preview window (non-modal, draggable/resizable) ── */}
      <FloatingPreviewWindow
        open={!!previewTarget}
        onClose={() => setPreviewTarget(null)}
        download={previewTarget}
      />

      {/* 2026-06-24 — SQL viewer dialog.  Shows the FULL query that
          produced the download.  Operator pushback: "why download
          center doesnt show full query...they should be able to
          show what query they have executed".  Backend joins
          download_files with query_executions and extracts the SQL
          from query_config; the dialog renders it with monospace +
          copy-to-clipboard. */}
      <AppDialog open={!!sqlTarget}
        onClose={() => setSqlTarget(null)}
        size="lg"
        title={<>
          <CodeIcon fontSize="small" />
          <span>Executed SQL</span>
          {sqlTarget?.query_kind && (
            <Chip
              label={sqlTarget.query_kind}
              size="small"
              variant="outlined"
              sx={{ height: 20, fontSize: 11, ml: 1 }}
            />
          )}
          {sqlTarget?.filename && (
            <Typography
              variant="caption"
              color="text.secondary"
              sx={{ ml: 1, flex: 1, textAlign: 'right' }}
              noWrap
              title={sqlTarget.filename}
            >
              {sqlTarget.filename}
            </Typography>
          )}
        </>}
        actions={<>
          <Button
            startIcon={<CopyIcon />}
            onClick={() => {
              if (sqlTarget?.query_sql) {
                try {
                  navigator.clipboard.writeText(sqlTarget.query_sql);
                } catch {
                  // clipboard API not available -- silently skip;
                  // user can still select + copy from the dialog.
                }
              }
            }}
            disabled={!sqlTarget?.query_sql}
          >
            Copy
          </Button>
          <Button onClick={() => setSqlTarget(null)}>Close</Button>
        </>}>
          <Box
            component="pre"
            sx={{
              p: 2,
              bgcolor: 'grey.50',
              border: '1px solid',
              borderColor: 'divider',
              borderRadius: 1,
              fontFamily: 'Menlo, Monaco, "Courier New", monospace',
              fontSize: 13,
              lineHeight: 1.55,
              whiteSpace: 'pre-wrap',     // wrap long lines
              wordBreak: 'break-word',
              overflowX: 'auto',
              maxHeight: '60vh',
              overflowY: 'auto',
              m: 0,
            }}
          >
            {sqlTarget?.query_sql || '— no SQL captured for this execution —'}
          </Box>
          {sqlTarget?.execution_id && (
            <Typography
              variant="caption"
              color="text.disabled"
              sx={{ display: 'block', mt: 1, fontFamily: 'monospace' }}
            >
              execution_id: {sqlTarget.execution_id}
            </Typography>
          )}
      </AppDialog>

      {/* ── Delete confirmation ── */}
      {/* Retention — how long the user wants to keep this file.
          The presets are conveniences, not the rule: the operator maximum is
          enforced server-side, and its 400 response names the limit, so a
          request above it fails with a message that explains itself rather
          than the UI hard-coding a ceiling it cannot know. */}
      <AppDialog open={!!retentionTarget}
        onClose={() => setRetentionTarget(null)}
        size="xs"
        title="Keep This File"
        actions={<>
          <Button onClick={() => setRetentionTarget(null)}>Cancel</Button>
          <Button
            variant="contained"
            onClick={() => handleSetRetention(retentionTarget.file_id, retentionDays)}
          >
            Save
          </Button>
        </>}>
          <Typography variant="body2" sx={{ mb: 2 }}>
            <strong>{retentionTarget?.filename}</strong> is currently kept until{' '}
            {retentionTarget?.expires_at
              ? new Date(retentionTarget.expires_at).toLocaleDateString()
              : 'the default retention'}.
          </Typography>
          <FormControl fullWidth size="small">
            <InputLabel id="retention-days-label">Keep for</InputLabel>
            <Select
              labelId="retention-days-label"
              label="Keep for"
              value={retentionDays}
              inputProps={{ 'aria-label': 'Keep for' }}
              onChange={(e) => setRetentionDays(Number(e.target.value))}
            >
              <MenuItem value={1}>1 day</MenuItem>
              <MenuItem value={7}>7 days</MenuItem>
              <MenuItem value={14}>14 days</MenuItem>
              <MenuItem value={30}>30 days</MenuItem>
            </Select>
          </FormControl>
          <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
            Counted from now. Your administrator sets the maximum.
          </Typography>
      </AppDialog>

      <AppDialog open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        size="xs"
        title="Delete Download"
        actions={<>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDelete}>Delete</Button>
        </>}>
          <Typography>
            Delete <strong>{deleteTarget?.filename}</strong>? This cannot be undone.
          </Typography>
      </AppDialog>

      {/* ── Register as Local Table dialog ── */}
      <AppDialog open={promoteDialogOpen}
        onClose={() => setPromoteDialogOpen(false)}
        size="sm"
        title="Register as Local Table"
        actions={<>
          <Button onClick={() => setPromoteDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={!promoteName.trim() || promoteLoading}
            onClick={async () => {
              setPromoteLoading(true);
              try {
                await api.promoteToLocalTable({
                  file_id: promoteFile.file_id,
                  name: promoteName.trim(),
                  description: promoteDescription.trim() || undefined,
                  visibility: promoteVisibility,
                });
                setPromoteDialogOpen(false);
              } catch (err: any) {
                void appAlert(err.message || 'Failed to promote');
              } finally {
                setPromoteLoading(false);
              }
            }}>
            {promoteLoading ? 'Processing...' : 'Register'}
          </Button>
        </>}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            This will copy the parquet file and register it as a queryable local table.
          </Typography>
          <TextField fullWidth label="Table Name" value={promoteName}
            onChange={e => setPromoteName(e.target.value)} sx={{ mb: 2 }} />
          <TextField fullWidth label="Description" value={promoteDescription}
            onChange={e => setPromoteDescription(e.target.value)} multiline rows={2} sx={{ mb: 2 }} />
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel id="sel-downloads-visibility">Visibility</InputLabel>
            <Select labelId="sel-downloads-visibility" value={promoteVisibility} label="Visibility"
              onChange={e => setPromoteVisibility(e.target.value)}>
              <MenuItem value="public">Public</MenuItem>
              <MenuItem value="private">Private</MenuItem>
            </Select>
          </FormControl>
      </AppDialog>

    </Box>
  );
};

export default Downloads;
