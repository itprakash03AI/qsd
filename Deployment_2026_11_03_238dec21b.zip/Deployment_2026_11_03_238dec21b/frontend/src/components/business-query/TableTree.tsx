/**
 * Phase 130-E — Table/column tree panel extracted from BusinessQueryBuilder.
 * Phase 134  — Type filter chips, MV/FED/ICE badges, favorites, context menu.
 */
import React, { useState, useCallback, useMemo } from 'react';
import {
  Box, Typography, Paper, TextField, Select, MenuItem,
  FormControl, Chip, IconButton, Accordion, AccordionSummary,
  AccordionDetails, Checkbox, InputAdornment, Tooltip,
  CircularProgress, SelectChangeEvent, Menu, Autocomplete,
  Dialog, Button,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SearchIcon from '@mui/icons-material/Search';
import RefreshIcon from '@mui/icons-material/Refresh';
import StorageIcon from '@mui/icons-material/Storage';
import TableChartIcon from '@mui/icons-material/TableChart';
import BoltIcon from '@mui/icons-material/Bolt';
import LinkIcon from '@mui/icons-material/Link';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import StarIcon from '@mui/icons-material/Star';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import PreviewIcon from '@mui/icons-material/Preview';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import type { MappedColumn, TableOption, ConnectionOption } from './types';
import { AGG_MEASURE, AGG_DIMENSION, TRANSFORMS } from './types';
import { tinySelectSx } from './utils';
import api from '../../services/api';
import { clickable } from '../../utils/clickable';

// ── Badge config per table type ──────────────────────────────────
const TYPE_BADGES: Record<string, { label: string; color: string; bg: string }> = {
  registered:   { label: 'REG', color: '#1e40af', bg: '#dbeafe' },
  materialized: { label: 'MV',  color: '#7c3aed', bg: '#ede9fe' },
  local:        { label: 'LOCAL', color: '#d97706', bg: '#fef3c7' },
  federation:   { label: 'FED', color: '#047857', bg: '#d1fae5' },
  iceberg:      { label: 'ICE', color: '#0e7490', bg: '#cffafe' },
};

/**
 * Display label for a table entry.
 *
 * SQL-connector tables arrive fully qualified (``hive.sales.orders``) because
 * that is what the backend must be given back; only the last segment
 * identifies the table to a human.  File/S3 paths are left alone — their
 * dots are file extensions, not qualification, and truncating
 * ``trades.parquet`` to ``parquet`` would be worse than useless.
 */
export const shortTableLabel = (name: string): string => {
  const s = String(name ?? '');
  if (s.includes('/') || s.includes('\\') || s.startsWith('__')) return s;
  const parts = s.split('.');
  if (parts.length < 3) return s;          // needs catalog.schema.table
  return parts[parts.length - 1] || s;
};

const TYPE_FILTER_CHIPS = [
  { key: 'all', label: 'ALL' },
  { key: 'registered', label: 'REG' },
  { key: 'materialized', label: 'MV' },
  { key: 'local', label: 'LOCAL' },
  { key: 'federation', label: 'FED' },
  { key: 'iceberg', label: 'ICE' },
];

export interface TableTreeProps {
  tables: TableOption[];
  selectedTables: TableOption[];
  onToggleTable: (t: TableOption) => void;
  tableSearch: string;
  onTableSearchChange: (v: string) => void;
  selectedConnId: number | null;
  connName: (id: number | null) => string;
  loadingColumns: boolean;
  columnsByTable: Record<string, Record<string, MappedColumn[]>>;
  selectedPhysical: Set<string>;
  onToggleColumn: (name: string) => void;
  onToggleCategory: (cat: string, cols: MappedColumn[]) => void;
  columnAggregations: Record<string, string>;
  onAggChange: (col: string, val: string) => void;
  columnTransforms: Record<string, string>;
  onTransformChange: (col: string, val: string) => void;
  panelOpen: boolean;
  onPanelToggle: () => void;
  // Cross-connection
  /** When false the whole "2nd Source" section is not rendered — set from
   * the `business_query_builder.cross_connection` visibility key (declutter,
   * not a permission). Defaults to true. */
  crossConnEnabled?: boolean;
  showCrossConn: boolean;
  onToggleCrossConn: () => void;
  crossConnId: number | null;
  onCrossConnChange: (id: number | null) => void;
  connections: ConnectionOption[];
  crossTables: TableOption[];
  selectedCrossTables: TableOption[];
  onToggleCrossTable: (t: TableOption) => void;
  crossConnMode?: 'union' | 'join';
  onCrossConnModeChange?: (mode: 'union' | 'join') => void;
  crossJoinLeftOn?: string;
  crossJoinRightOn?: string;
  onCrossJoinLeftOnChange?: (col: string) => void;
  onCrossJoinRightOnChange?: (col: string) => void;
  crossJoinHow?: string;
  onCrossJoinHowChange?: (how: string) => void;
  allColumnNames?: string[];
  filteredTables: TableOption[];
  filteredCrossTables: TableOption[];
  // Phase 134 — type filter + favorites + smart defaults
  tableTypeFilter?: string;
  onTypeFilterChange?: (v: string) => void;
  tableFavorites?: Set<string>;
  frequentColumns?: Record<string, Set<string>>;
  // User-triggered schema refresh — mirrors CQB's schema-refresh
  // button.  Forces a fresh live S3 read AND bypasses both the
  // browser-side ``columnCache`` and the backend's L1/L2 cache.
  // No-op when no tables are selected.
  onRefreshSchema?: () => void;
  /**
   * 2026-08-13 — SQL-connector BROWSE (catalog → schema → table).
   *
   * A Starburst/Trino connection has thousands of tables across many
   * catalogs and schemas.  Listing them flat as ``catalog.schema.table``
   * strings — which is what BQB did, merging the registered-tables endpoint
   * with the file listing — is unusable, and is not how Starburst's own UI
   * presents a catalog.  When ``sqlBrowse`` is on, the panel offers the two
   * selectors instead and the table list holds SHORT names for the chosen
   * catalog + schema.
   *
   * Absent/false leaves every non-SQL connection (S3, local, …) exactly as
   * it was — those genuinely are flat lists.
   */
  sqlBrowse?: boolean;
  catalogs?: string[];
  schemas?: string[];
  browseCatalog?: string;
  browseSchema?: string;
  onBrowseCatalogChange?: (v: string) => void;
  onBrowseSchemaChange?: (v: string) => void;
  browseLoading?: boolean;
  /**
   * 2026-10-04 -- the SECOND source browses the same way.  A SQL-connector
   * secondary (Snowflake, Trino, Oracle ...) used to be listed through the
   * registered-tables endpoint, which answers schemas instead of tables when
   * the connection has no default schema -- so the 2nd-source list was EMPTY
   * for exactly the cloud/on-prem pairs the backend now combines.
   */
  crossSqlBrowse?: boolean;
  crossCatalogs?: string[];
  crossSchemas?: string[];
  crossCatalog?: string;
  crossSchema?: string;
  onCrossCatalogChange?: (v: string) => void;
  onCrossSchemaChange?: (v: string) => void;
}

interface ColumnsForTableProps {
  tablePath: string;
  catGroups: Record<string, MappedColumn[]>;
  selectedPhysical: Set<string>;
  onToggleColumn: (name: string) => void;
  onToggleCategory: (cat: string, cols: MappedColumn[]) => void;
  columnAggregations: Record<string, string>;
  onAggChange: (col: string, val: string) => void;
  columnTransforms: Record<string, string>;
  onTransformChange: (col: string, val: string) => void;
  frequentCols?: Set<string>;
  searchQuery?: string;
}

// ── ColumnRow — memoized per-column renderer ─────────────────────────────────
// Phase 138 fix: with 1000+ columns, "select all" was unresponsive because the
// Set identity change forced ColumnsForTable to re-render every row.  Each row
// has Checkbox + 2 Typography + (when checked) 2 Selects + Chip + Tooltip ≈ 6
// MUI components — 1000 rows × 6 = 6000 React elements per click.
//
// Splitting the row into its own React.memo'd component with PRIMITIVE props
// (isChecked: boolean, currentAgg: string, currentTransform: string) means
// memo's shallow-equality check short-circuits unchanged rows — only the row
// whose isChecked actually flipped re-renders.  Select-all on a category
// toggles every row's isChecked, but the inner Box JSX is identical so the
// render is fast.
/**
 * The ONE name a column goes by in this tree -- its checkbox, its Agg and its
 * Fn dropdowns.  2026-10-07 (F4, found on the Docker rig): the dropdowns were
 * named from `friendly_name` ALONE while the checkbox fell back to the
 * physical name, so a column without a business name had a checkbox a test
 * (or a screen reader user) could find and dropdowns it could not.
 */
export const columnDisplayName = (col: Pick<MappedColumn, 'friendly_name' | 'physical_name'>): string =>
  String(col.friendly_name || col.physical_name || '').trim() || String(col.physical_name ?? '');

interface ColumnRowProps {
  col: MappedColumn;
  isChecked: boolean;
  currentAgg: string;
  currentTransform: string;
  isFrequent: boolean;
  searchQuery?: string;
  onToggle: (name: string) => void;
  onAggChange: (col: string, val: string) => void;
  onTransformChange: (col: string, val: string) => void;
}

export const ColumnRow = React.memo<ColumnRowProps>(({
  col, isChecked, currentAgg, currentTransform, isFrequent, searchQuery,
  onToggle, onAggChange, onTransformChange,
}) => {
  const aggOptions = col.column_type === 'measure' ? AGG_MEASURE : AGG_DIMENSION;
  const transformOptions = TRANSFORMS[col.data_type] || [''];
  const displayName = columnDisplayName(col);
  const matches = !!(searchQuery && searchQuery.length >= 2 &&
    (col.physical_name.toLowerCase().includes(searchQuery) ||
     (col.friendly_name || '').toLowerCase().includes(searchQuery)));
  return (
    <Box
      sx={{
        display: 'flex', alignItems: 'center', py: 0.1, px: 0.25,
        cursor: 'pointer', borderRadius: 0.5,
        '&:hover': { bgcolor: 'action.hover' },
      }}
      onClick={() => onToggle(col.physical_name)}
    >
      <Checkbox size="small" checked={isChecked} sx={{ p: 0.1, mr: 0.25 }}
        inputProps={{ 'aria-label': `Column ${displayName}` }} />
      <Box sx={{ flexGrow: 1, minWidth: 0 }}>
        <Typography variant="caption" noWrap
          sx={{
            fontWeight: 500, display: 'block', lineHeight: 1.3, fontSize: '0.72rem',
            ...(matches ? { bgcolor: 'warning.light', color: 'warning.contrastText', px: 0.3, borderRadius: 0.5 } : {}),
          }}>
          {col.friendly_name}
          {isFrequent && (
            <Tooltip title="Frequently used column">
              <StarIcon sx={{ fontSize: 10, color: 'warning.main', ml: 0.3, verticalAlign: 'middle' }} />
            </Tooltip>
          )}
        </Typography>
        <Typography variant="caption" color="text.secondary" noWrap
          sx={{ fontSize: '0.6rem', display: 'block', lineHeight: 1.1, opacity: 0.7 }}>
          {col.physical_name}
        </Typography>
      </Box>

      {/* Inline aggregation dropdown (only when checked) */}
      {isChecked && aggOptions.length > 1 && (
        <Tooltip title="Aggregation (SUM, AVG, COUNT...)" describeChild>
          <Select inputProps={{ 'aria-label': `Aggregation for ${displayName}` }}
            value={currentAgg} displayEmpty size="small"
            renderValue={v => v || 'Agg'}
            onClick={e => e.stopPropagation()}
            onChange={e => { e.stopPropagation(); onAggChange(col.physical_name, e.target.value); }}
            sx={{
              ...tinySelectSx, ml: 0.25,
              bgcolor: currentAgg ? 'primary.50' : undefined,
              color: currentAgg ? 'primary.main' : 'text.secondary',
              fontWeight: currentAgg ? 600 : 400,
            }}
          >
            <MenuItem value="" sx={{ fontSize: '0.65rem', color: 'text.secondary' }}>None</MenuItem>
            {aggOptions.filter(o => o).map(o => (
              <MenuItem key={o} value={o} sx={{ fontSize: '0.65rem' }}>{o}</MenuItem>
            ))}
          </Select>
        </Tooltip>
      )}

      {/* Inline transform dropdown */}
      {isChecked && transformOptions.length > 1 && (
        <Tooltip title="Transform (YEAR, UPPER, ROUND...)" describeChild>
          <Select inputProps={{ 'aria-label': `Transform for ${displayName}` }}
            value={currentTransform} displayEmpty size="small"
            renderValue={v => v || 'Fn'}
            onClick={e => e.stopPropagation()}
            onChange={e => { e.stopPropagation(); onTransformChange(col.physical_name, e.target.value); }}
            sx={{
              ...tinySelectSx, ml: 0.25,
              bgcolor: currentTransform ? 'secondary.50' : undefined,
              color: currentTransform ? 'secondary.main' : 'text.secondary',
              fontWeight: currentTransform ? 600 : 400,
            }}
          >
            <MenuItem value="" sx={{ fontSize: '0.65rem', color: 'text.secondary' }}>None (raw value)</MenuItem>
            {transformOptions.filter(t => t).map(t => (
              <MenuItem key={t} value={t} sx={{ fontSize: '0.65rem' }}>{t}</MenuItem>
            ))}
          </Select>
        </Tooltip>
      )}

      {col.is_partition && (
        <Tooltip title="Partition column">
          <BoltIcon sx={{ fontSize: 12, color: 'warning.main', ml: 0.25 }} />
        </Tooltip>
      )}
      <Chip
        label={col.column_type === 'measure' ? 'M' : 'D'}
        size="small"
        color={col.column_type === 'measure' ? 'primary' : 'default'}
        sx={{ height: 14, fontSize: '0.55rem', ml: 0.25, minWidth: 16 }}
      />
    </Box>
  );
});
ColumnRow.displayName = 'ColumnRow';

/** Render category > column tree for a single table.
 * React.memo prevents re-renders when unrelated BQB state (sqlText, etc.) changes. */
const ColumnsForTable = React.memo<ColumnsForTableProps>(({
  catGroups, selectedPhysical, onToggleColumn, onToggleCategory,
  columnAggregations, onAggChange, columnTransforms, onTransformChange,
  frequentCols, searchQuery,
}) => {
  // 2026-10-07 (G3, Docker proof on fact_tetb): partition columns are ALSO
  // listed in their own "Partition" group, placed first -- so "open the first
  // group" opened only the 3 partition columns and left "All (95)" (the
  // amounts and accounts users actually pick) collapsed behind a click.  The
  // partition group is a shortcut, never the only open group: the first
  // group that holds data columns opens too.
  const entries = Object.entries(catGroups);
  const firstDataGroup = entries.findIndex(([, cols]) => !cols.every(c => c.is_partition));
  return (
  <>
    {entries.map(([catName, cols], catIndex) => {
      const allSelected = cols.every(c => selectedPhysical.has(c.physical_name));
      const someSelected = cols.some(c => selectedPhysical.has(c.physical_name));
      // Auto-expand categories when searching and columns match
      const hasSearchMatch = searchQuery && searchQuery.length >= 2 && cols.some(c =>
        c.physical_name.toLowerCase().includes(searchQuery) ||
        c.friendly_name.toLowerCase().includes(searchQuery)
      );
      return (
        // The FIRST group opens too (2026-10-02): a ticked table opened onto
        // closed groups, so the columns were still one more click away.
        <Accordion key={catName}
          defaultExpanded={!!hasSearchMatch || catIndex === 0 || catIndex === firstDataGroup}
          disableGutters
          sx={{ '&:before': { display: 'none' }, boxShadow: 'none' }}>
          <AccordionSummary expandIcon={<ExpandMoreIcon sx={{ fontSize: 14 }} />}
            sx={{ minHeight: 24, pl: 2, pr: 0.5,
              '& .MuiAccordionSummary-content': { m: 0, alignItems: 'center' } }}>
            <Checkbox size="small" checked={allSelected}
              inputProps={{ 'aria-label': `Every column in ${catName}` }}
              indeterminate={someSelected && !allSelected}
              onClick={e => { e.stopPropagation(); onToggleCategory(catName, cols); }}
              sx={{ p: 0.1, mr: 0.25 }} />
            <Typography variant="caption" sx={{ fontWeight: 600, flexGrow: 1, fontSize: '0.72rem' }}>
              {catName}
            </Typography>
            <Chip label={cols.length} size="small" sx={{ height: 14, fontSize: '0.55rem' }} />
          </AccordionSummary>
          <AccordionDetails sx={{ p: 0, pl: 2.5 }}>
            {cols.map(col => (
              <ColumnRow
                key={col.physical_name}
                col={col}
                isChecked={selectedPhysical.has(col.physical_name)}
                currentAgg={columnAggregations[col.physical_name] || ''}
                currentTransform={columnTransforms[col.physical_name] || ''}
                isFrequent={!!frequentCols?.has(col.physical_name)}
                searchQuery={searchQuery}
                onToggle={onToggleColumn}
                onAggChange={onAggChange}
                onTransformChange={onTransformChange}
              />
            ))}
          </AccordionDetails>
        </Accordion>
      );
    })}
  </>
  );
});

ColumnsForTable.displayName = 'ColumnsForTable';

const TableTree: React.FC<TableTreeProps> = ({
  selectedTables, onToggleTable, tableSearch, onTableSearchChange,
  selectedConnId, connName, loadingColumns, columnsByTable,
  selectedPhysical, onToggleColumn, onToggleCategory,
  columnAggregations, onAggChange, columnTransforms, onTransformChange,
  panelOpen, onPanelToggle,
  crossConnEnabled = true,
  showCrossConn, onToggleCrossConn, crossConnId, onCrossConnChange,
  connections, crossTables, selectedCrossTables, onToggleCrossTable,
  filteredTables, filteredCrossTables,
  crossConnMode = 'union', onCrossConnModeChange,
  crossJoinLeftOn = '', crossJoinRightOn = '', onCrossJoinLeftOnChange, onCrossJoinRightOnChange,
  crossJoinHow = 'inner', onCrossJoinHowChange,
  allColumnNames = [],
  tableTypeFilter = 'all', onTypeFilterChange,
  tableFavorites = new Set(),
  frequentColumns = {},
  onRefreshSchema,
  sqlBrowse = false,
  catalogs = [],
  schemas = [],
  browseCatalog = '',
  browseSchema = '',
  onBrowseCatalogChange,
  onBrowseSchemaChange,
  browseLoading = false,
  crossSqlBrowse = false,
  crossCatalogs = [],
  crossSchemas = [],
  crossCatalog = '',
  crossSchema = '',
  onCrossCatalogChange,
  onCrossSchemaChange,
}) => {
  // ── Column search across ALL tables ──────────────────────────
  const columnSearchMatch = useMemo(() => {
    const q = tableSearch.trim().toLowerCase();
    if (!q || q.length < 2) return null;
    // Check if search matches column names across all tables in columnsByTable
    const matchingTables: string[] = [];
    for (const [tablePath, catGroups] of Object.entries(columnsByTable)) {
      for (const cols of Object.values(catGroups)) {
        if (cols.some(c =>
          c.physical_name.toLowerCase().includes(q) ||
          c.friendly_name.toLowerCase().includes(q)
        )) {
          matchingTables.push(tablePath);
          break;
        }
      }
    }
    return matchingTables.length > 0 ? { query: q, tables: matchingTables } : null;
  }, [tableSearch, columnsByTable]);

  // ── Context menu state ────────────────────────────────────────
  const [ctxMenu, setCtxMenu] = useState<{ anchorEl: HTMLElement; table: TableOption } | null>(null);
  // 2026-10-02 -- "hard to find the columns": a ticked table's columns sat
  // behind a collapsed accordion with only a small chevron to say so.  A
  // ticked table now OPENS once its columns are known; the chevron still
  // collapses it, and that choice is remembered until it is unticked.
  const [collapsedTables, setCollapsedTables] = useState<Set<string>>(new Set());
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewData, setPreviewData] = useState<{ name: string; rows: any[]; columns: string[]; error?: string } | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);

  const handleContextMenu = useCallback((e: React.MouseEvent<HTMLElement>, table: TableOption) => {
    e.preventDefault();
    e.stopPropagation();
    setCtxMenu({ anchorEl: e.currentTarget, table });
  }, []);

  const handlePreview = useCallback(async (table: TableOption) => {
    // 2026-10-18 (the owner: "no table giving preview -- Preview: fact_tetb_month_end",
    // "right click option doesn't work from BQB").  Three defects: the query was sent
    // WITHOUT the connection (a registered table '__registered__:<name>' is unknown
    // without it: HTTP 400 "File not found"), the results were read at once while the
    // execution was still running, and every failure became an empty "No data".
    setCtxMenu(null);
    setPreviewData({ name: table.name, rows: [], columns: [] });
    setPreviewLoading(true);
    setPreviewOpen(true);
    try {
      const res = await api.executeQuery({
        query_config: { files: [table.path], columns: ['*'], limit: 100 },
        raw_sql: `SELECT * FROM ${table.path.startsWith('__') ? table.name : table.path} LIMIT 100`,
        ...(selectedConnId ? { connection_id: Number(selectedConnId) } : {}),
        output_format: 'json',
      } as any);
      if (!res?.execution_id) throw new Error('the server started no execution');
      // wait for the execution to finish (bounded), as the builder's own run does
      let st: any = null;
      for (let i = 0; i < 240; i++) {
        st = await api.getExecutionStatus(res.execution_id);
        if (['completed', 'failed', 'error', 'cancelled'].includes(String(st?.status))) break;
        await new Promise(r => setTimeout(r, 500));
      }
      if (String(st?.status) !== 'completed') {
        throw new Error(st?.error || st?.error_message
          || (st?.status ? `the preview ${st.status}` : 'the preview did not finish within 2 minutes'));
      }
      const data = await api.getExecutionResults(res.execution_id, 1, 100);
      const rows = data?.rows || data?.data || [];
      const columns = data?.columns?.map((c: any) => c.name || c) || (rows[0] ? Object.keys(rows[0]) : []);
      setPreviewData({ name: table.name, rows: rows.slice(0, 100), columns });
    } catch (e: any) {
      const detail = e?.message || String(e);
      setPreviewData({ name: table.name, rows: [], columns: [], error: detail });
    } finally {
      setPreviewLoading(false);
    }
  }, [selectedConnId]);

  const handleToggleFavorite = useCallback(async (table: TableOption) => {
    setCtxMenu(null);
    try {
      await api.toggleTableFavorite({
        table_path: table.path,
        table_name: table.name,
        connection_id: selectedConnId || undefined,
      });
    } catch { /* silently fail */ }
  }, [selectedConnId]);

  const handleCopyName = useCallback((table: TableOption) => {
    navigator.clipboard.writeText(table.name);
    setCtxMenu(null);
  }, []);

  // The connection's own tables vs uploaded LOCAL tables (no connection).
  // With no connection chosen there is no "connection group": the list is
  // shown as before under the no-connection note.
  const localTables = useMemo(
    () => (selectedConnId ? filteredTables.filter(t => t._type === 'local') : []),
    [filteredTables, selectedConnId]);
  const connectionTables = useMemo(
    () => (selectedConnId ? filteredTables.filter(t => t._type !== 'local') : filteredTables),
    [filteredTables, selectedConnId]);

  // One table row (checkbox, badge, name, its columns when ticked) --
  // rendered in the connection's group and in the local-tables group.
  const renderTableRow = (t: TableOption) => {
    const isSelected = selectedTables.some(s => s.path === t.path);
    const hasColumns = !!columnsByTable[t.path];
    const badge = t._type ? TYPE_BADGES[t._type] : null;
    const isFav = tableFavorites.has(t.path);
    return (
      <Accordion key={t.path} disableGutters
        expanded={isSelected && hasColumns && !collapsedTables.has(t.path)}
        onChange={(_e, open) => setCollapsedTables(prev => {
          const next = new Set(prev);
          if (open) next.delete(t.path); else next.add(t.path);
          return next;
        })}
        sx={{ '&:before': { display: 'none' }, boxShadow: 'none' }}>
        <AccordionSummary
          expandIcon={isSelected && hasColumns ? <ExpandMoreIcon sx={{ fontSize: 16 }} /> : <Box sx={{ width: 16 }} />}
          sx={{
            minHeight: 28, px: 0.5, pl: 1.5,
            '& .MuiAccordionSummary-content': { m: 0, alignItems: 'center' },
          }}
          onContextMenu={(e) => handleContextMenu(e, t)}
        >
          <Checkbox size="small" checked={isSelected}
            inputProps={{ 'aria-label': `Table ${t.name || t.path}` }}
            onClick={e => {
              e.stopPropagation();
              // a fresh tick opens the table again
              setCollapsedTables(prev => { const n = new Set(prev); n.delete(t.path); return n; });
              onToggleTable(t);
            }}
            sx={{ p: 0.1, mr: 0.25 }} />
          {isFav && (
            <StarIcon sx={{ fontSize: 12, color: 'warning.main', mr: 0.25 }} />
          )}
          <TableChartIcon sx={{ fontSize: 14, mr: 0.5, opacity: 0.5 }} />
          {badge && (
            <Chip label={badge.label} size="small"
              sx={{
                height: 14, fontSize: '0.5rem', fontWeight: 700, mr: 0.3,
                color: badge.color, bgcolor: badge.bg, border: 'none',
              }}
            />
          )}
          {/* 2026-08-10 -- show the SHORT name.  A SQL connector
              (Trino/Starburst/Snowflake) names its tables
              ``catalog.schema.table``, and in this narrow sidebar
              ``noWrap`` truncated exactly the part that identifies
              the table, leaving a column of near-identical
              ``hive.sales…`` entries.  The full name stays in the
              tooltip, and ``t.path`` — the identity used for
              selection, columns and favourites — is untouched. */}
          <Typography variant="caption" noWrap title={t.name}
            sx={{ fontWeight: isSelected ? 600 : 400, flexGrow: 1, fontSize: '0.78rem' }}>
            {shortTableLabel(t.name)}
          </Typography>
          {t.num_rows && (
            <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.6rem', ml: 0.5 }}>
              {t.num_rows.toLocaleString()}
            </Typography>
          )}
        </AccordionSummary>
        {isSelected && hasColumns && (
          <AccordionDetails sx={{ p: 0 }}>
            <ColumnsForTable
              tablePath={t.path}
              catGroups={columnsByTable[t.path]}
              selectedPhysical={selectedPhysical}
              onToggleColumn={onToggleColumn}
              onToggleCategory={onToggleCategory}
              columnAggregations={columnAggregations}
              onAggChange={onAggChange}
              columnTransforms={columnTransforms}
              onTransformChange={onTransformChange}
              frequentCols={frequentColumns[t.path]}
              searchQuery={tableSearch.trim().toLowerCase()}
            />
          </AccordionDetails>
        )}
      </Accordion>
    );
  };

  // Closed state: width:0 (fully hidden — matches CQB's behaviour).  The
  // re-open button is rendered by the parent (BusinessQueryBuilder) in the
  // toolbar so the user always has a way back without a 36px stub eating
  // result-grid real estate.
  if (!panelOpen) {
    return (
      <Box sx={{
        width: 0, minWidth: 0,
        transition: 'width 0.2s, min-width 0.2s',
        overflow: 'hidden',
      }} />
    );
  }

  return (
    <Paper elevation={1} sx={{
      width: 300, minWidth: 280,
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
      transition: 'width 0.2s, min-width 0.2s',
    }}>
      {/* Panel header */}
      <Box sx={{
        display: 'flex', alignItems: 'center', px: 0.5, py: 0.25,
        borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'grey.50',
      }}>
        <IconButton size="small" onClick={onPanelToggle} sx={{ mr: 0.5 }} aria-label="Hide objects panel">
          <ChevronLeftIcon fontSize="small" />
        </IconButton>
        <Typography variant="caption" sx={{ fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, flexGrow: 1 }}>
          Objects
        </Typography>
        {selectedPhysical.size > 0 && (
          <Chip label={`${selectedPhysical.size} cols`} size="small" color="primary"
            sx={{ height: 16, fontSize: '0.6rem' }} />
        )}
      </Box>

      {/* Body — early-return at top handles the closed state, so the rest of
          the panel always renders. */}
      <>
          {/* ── SQL connector: browse catalog → schema ─────────────
              Only for connections the backend can actually browse.  A
              Starburst catalog holds far too many tables to list flat, and
              a flat ``catalog.schema.table`` dump is not how Starburst
              itself presents them. */}
          {selectedConnId && sqlBrowse && (
            <Box sx={{ px: 0.5, py: 0.5, borderBottom: '1px solid',
                       borderColor: 'divider', display: 'flex', gap: 0.5,
                       alignItems: 'center' }}>
              <FormControl size="small" sx={{ flex: 1, minWidth: 0 }}>
                <Select
                  displayEmpty
                  value={catalogs.includes(browseCatalog) ? browseCatalog : ''}
                  onChange={(e: SelectChangeEvent) => onBrowseCatalogChange?.(e.target.value)}
                  disabled={browseLoading || catalogs.length === 0}
                  inputProps={{ 'aria-label': 'Catalog' }}
                  SelectDisplayProps={{ 'aria-label': 'Catalog' } as React.HTMLAttributes<HTMLDivElement>}
                  sx={{ fontSize: 12 }}
                >
                  <MenuItem value="" disabled sx={{ fontSize: 12 }}>
                    {catalogs.length ? 'Catalog…' : 'No catalogs'}
                  </MenuItem>
                  {catalogs.map(c => (
                    <MenuItem key={c} value={c} sx={{ fontSize: 12 }}>{c}</MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl size="small" sx={{ flex: 1, minWidth: 0 }}>
                <Select
                  displayEmpty
                  value={schemas.includes(browseSchema) ? browseSchema : ''}
                  onChange={(e: SelectChangeEvent) => onBrowseSchemaChange?.(e.target.value)}
                  disabled={browseLoading || !browseCatalog || schemas.length === 0}
                  inputProps={{ 'aria-label': 'Schema' }}
                  SelectDisplayProps={{ 'aria-label': 'Schema' } as React.HTMLAttributes<HTMLDivElement>}
                  sx={{ fontSize: 12 }}
                >
                  <MenuItem value="" disabled sx={{ fontSize: 12 }}>
                    {!browseCatalog ? 'Pick a catalog' : (schemas.length ? 'Schema…' : 'No schemas')}
                  </MenuItem>
                  {schemas.map(s => (
                    <MenuItem key={s} value={s} sx={{ fontSize: 12 }}>{s}</MenuItem>
                  ))}
                </Select>
              </FormControl>
              {browseLoading && <CircularProgress size={14} />}
            </Box>
          )}

          {/* Search + Refresh schema */}
          {selectedConnId && (
            <Box sx={{ px: 0.5, py: 0.25, borderBottom: '1px solid', borderColor: 'divider',
                       display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <TextField
                size="small" fullWidth placeholder="Search tables & columns..."
                value={tableSearch} onChange={e => onTableSearchChange(e.target.value)}
                InputProps={{
                  startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment>,
                }}
                sx={{ '& .MuiInputBase-root': { height: 28, fontSize: '0.8rem' } }}
              />
              {/* Mirrors the CQB schema-refresh button.  Disabled when no
                  table is selected (nothing to refresh) or when a load is
                  already in flight.  Backend's stale-while-revalidate
                  means a transient S3 503 returns the previous cached
                  schema instead of crashing. */}
              {onRefreshSchema && (
                <Tooltip title={
                  selectedTables.length === 0
                    ? 'Select a table to refresh its schema'
                    : 'Refresh schema + partitions (forces fresh S3 read)'
                }>
                  <span>
                    <IconButton
                      size="small"
                      onClick={onRefreshSchema}
                      disabled={selectedTables.length === 0 || loadingColumns}
                      aria-label="Refresh schema"
                      sx={{ p: 0.5 }}
                    >
                      <RefreshIcon sx={{ fontSize: 16 }} />
                    </IconButton>
                  </span>
                </Tooltip>
              )}
            </Box>
          )}

          {/* Column search match indicator */}
          {columnSearchMatch && (
            <Box sx={{ px: 0.5, py: 0.2, bgcolor: 'info.50', borderBottom: '1px solid', borderColor: 'divider' }}>
              <Typography variant="caption" sx={{ fontSize: '0.65rem', color: 'info.main', fontWeight: 600 }}>
                {columnSearchMatch.tables.length} table{columnSearchMatch.tables.length > 1 ? 's' : ''} have column matching "{columnSearchMatch.query}"
              </Typography>
            </Box>
          )}

          {/* Type filter chips */}
          {selectedConnId && onTypeFilterChange && (
            <Box sx={{
              display: 'flex', gap: 0.3, px: 0.5, py: 0.3, flexWrap: 'wrap',
              borderBottom: '1px solid', borderColor: 'divider',
            }}>
              {TYPE_FILTER_CHIPS.map(chip => (
                <Chip
                  key={chip.key}
                  label={chip.label}
                  size="small"
                  variant={tableTypeFilter === chip.key ? 'filled' : 'outlined'}
                  color={tableTypeFilter === chip.key ? 'primary' : 'default'}
                  onClick={() => onTypeFilterChange(chip.key)}
                  sx={{
                    height: 18, fontSize: '0.6rem', fontWeight: 600,
                    cursor: 'pointer',
                    ...(chip.key !== 'all' && TYPE_BADGES[chip.key] ? {
                      borderColor: TYPE_BADGES[chip.key].color,
                      ...(tableTypeFilter === chip.key ? { bgcolor: TYPE_BADGES[chip.key].bg, color: TYPE_BADGES[chip.key].color } : {}),
                    } : {}),
                  }}
                />
              ))}
            </Box>
          )}

          {/* Scrollable tree */}
          <Box sx={{ flexGrow: 1, overflow: 'auto' }}>
            {!selectedConnId && (
              <Typography variant="caption" color="text.secondary" sx={{ p: 1.5, display: 'block' }}
                          data-testid="tabletree-no-connection">
                {/* 2026-09-25: it said "Select a connection above" over a list
                    of tables -- the local and registered ones, which need none */}
                {filteredTables.length > 0
                  ? 'No connection chosen: these are local and registered tables. Pick a connection above to browse a source.'
                  : 'Select a connection above'}
              </Typography>
            )}

            {loadingColumns && (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 2 }}>
                <CircularProgress size={20} />
              </Box>
            )}

            {/* Primary source header */}
            {selectedConnId && (
              <Box sx={{ px: 1, py: 0.4, bgcolor: 'action.hover', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <StorageIcon sx={{ fontSize: 14, color: 'primary.main' }} />
                <Typography variant="caption" sx={{ fontWeight: 700, fontSize: '0.72rem' }}>
                  {connName(selectedConnId)}
                </Typography>
              </Box>
            )}

            {/* 2026-10-07 (F5, the BQB audit): a Trino connection listed the
                LOCAL uploaded tables directly under its own name while its
                catalog picker sat empty -- a user who had just picked Trino
                saw unrelated tables and none of Trino's.  The connection's
                own tables sit under its name; uploaded (local) tables, which
                belong to no connection, are their own labelled group. */}
            {connectionTables.map(renderTableRow)}

            {connectionTables.length === 0 && selectedConnId && !loadingColumns && (
              <Typography variant="caption" color="text.secondary" sx={{ p: 1, pl: 1.5, display: 'block' }}
                          data-testid="tabletree-connection-empty">
                {sqlBrowse && (!browseCatalog || !browseSchema)
                  ? (catalogs.length ? 'Pick a catalog and schema above to list its tables' : 'This connection lists no catalogs')
                  : (tableSearch.trim() ? 'No tables match' : 'No tables on this connection')}
              </Typography>
            )}

            {localTables.length > 0 && (
              <Box data-testid="tabletree-local-group" role="group" aria-label="Uploaded tables (local)">
                <Box sx={{ px: 1, py: 0.4, mt: 0.5, bgcolor: 'action.hover', display: 'flex', alignItems: 'center', gap: 0.5,
                           borderTop: '1px solid', borderColor: 'divider' }}>
                  <TableChartIcon sx={{ fontSize: 14, color: TYPE_BADGES.local.color }} />
                  <Typography variant="caption" sx={{ fontWeight: 700, fontSize: '0.72rem', flexGrow: 1 }}>
                    Uploaded tables (local)
                  </Typography>
                  <Tooltip title="Files uploaded to QueryStudio. They belong to no connection and run on the local engine.">
                    <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.6rem' }}>
                      not on {connName(selectedConnId) || 'this connection'}
                    </Typography>
                  </Tooltip>
                </Box>
                {localTables.map(renderTableRow)}
              </Box>
            )}

            {/* 2nd Source section — omitted entirely (incl. from the
                accessibility tree) when the cross_connection sub-feature is
                admin-hidden for this role */}
            {crossConnEnabled && (
            <Box sx={{ borderTop: '1px solid', borderColor: 'divider', mt: 0.5 }}>
              <Box
                sx={{
                  px: 1, py: 0.4, display: 'flex', alignItems: 'center', gap: 0.5,
                  cursor: 'pointer',
                  bgcolor: showCrossConn ? 'secondary.50' : 'action.hover',
                  '&:hover': { bgcolor: 'action.selected' },
                }}
                {...clickable(onToggleCrossConn, { label: '2nd Source', pressed: showCrossConn })}
              >
                <LinkIcon sx={{ fontSize: 14, color: showCrossConn ? 'secondary.main' : 'text.disabled' }} />
                <Typography variant="caption" sx={{ fontWeight: 700, flexGrow: 1, fontSize: '0.72rem' }}>
                  2nd Source
                </Typography>
                <Typography variant="caption" color={showCrossConn ? 'secondary' : 'text.secondary'}
                  sx={{ fontWeight: 600, fontSize: '0.65rem' }}>
                  {showCrossConn ? 'ON' : 'OFF'}
                </Typography>
              </Box>

              {showCrossConn && (
                <>
                  <Box sx={{ px: 0.5, py: 0.25 }}>
                    <FormControl size="small" fullWidth>
                      <Select inputProps={{ 'aria-label': 'Second connection' }} value={crossConnId || ''} displayEmpty
                        onChange={(e: SelectChangeEvent<number | string>) => {
                          onCrossConnChange(Number(e.target.value) || null);
                        }}
                        sx={{ height: 28, fontSize: '0.8rem' }}>
                        <MenuItem value="" disabled><em>Select connection...</em></MenuItem>
                        {connections.filter(c => c.id !== selectedConnId).map(c => (
                          <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Box>
                  {crossConnId && crossSqlBrowse && (
                    <Box sx={{ px: 0.5, py: 0.25, display: 'flex', gap: 0.5 }}>
                      <FormControl size="small" sx={{ flex: 1, minWidth: 0 }}>
                        <Select
                          displayEmpty
                          value={crossCatalogs.includes(crossCatalog) ? crossCatalog : ''}
                          onChange={(e: SelectChangeEvent) => onCrossCatalogChange?.(e.target.value)}
                          disabled={crossCatalogs.length === 0}
                          inputProps={{ 'aria-label': 'Second source catalog' }}
                          sx={{ height: 26, fontSize: '0.72rem' }}
                        >
                          <MenuItem value="" disabled sx={{ fontSize: 12 }}>
                            {crossCatalogs.length ? 'Catalog…' : 'No catalogs'}
                          </MenuItem>
                          {crossCatalogs.map(c => (
                            <MenuItem key={c} value={c} sx={{ fontSize: 12 }}>{c}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                      <FormControl size="small" sx={{ flex: 1, minWidth: 0 }}>
                        <Select
                          displayEmpty
                          value={crossSchemas.includes(crossSchema) ? crossSchema : ''}
                          onChange={(e: SelectChangeEvent) => onCrossSchemaChange?.(e.target.value)}
                          disabled={!crossCatalog || crossSchemas.length === 0}
                          inputProps={{ 'aria-label': 'Second source schema' }}
                          sx={{ height: 26, fontSize: '0.72rem' }}
                        >
                          <MenuItem value="" disabled sx={{ fontSize: 12 }}>
                            {!crossCatalog ? 'Pick a catalog' : (crossSchemas.length ? 'Schema…' : 'No schemas')}
                          </MenuItem>
                          {crossSchemas.map(s => (
                            <MenuItem key={s} value={s} sx={{ fontSize: 12 }}>{s}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Box>
                  )}

                  {crossConnId && (
                    <>
                      {/* Mode toggle: UNION ALL / JOIN */}
                      <Box sx={{ px: 0.5, py: 0.25, display: 'flex', gap: 0.5 }}>
                        <Chip label="UNION ALL" size="small"
                          color={crossConnMode === 'union' ? 'secondary' : 'default'}
                          variant={crossConnMode === 'union' ? 'filled' : 'outlined'}
                          onClick={() => onCrossConnModeChange?.('union')}
                          sx={{ fontSize: '0.65rem', height: 22 }} />
                        <Chip label="JOIN" size="small"
                          color={crossConnMode === 'join' ? 'secondary' : 'default'}
                          variant={crossConnMode === 'join' ? 'filled' : 'outlined'}
                          onClick={() => onCrossConnModeChange?.('join')}
                          sx={{ fontSize: '0.65rem', height: 22 }} />
                      </Box>
                      {/* JOIN config */}
                      {crossConnMode === 'join' && (
                        <Box sx={{ px: 0.5, py: 0.25, display: 'flex', flexDirection: 'column', gap: 0.3 }}>
                          <FormControl size="small" fullWidth>
                            <Select inputProps={{ 'aria-label': 'Join type' }} value={crossJoinHow === 'outer' ? 'full' : crossJoinHow} onChange={(e) => onCrossJoinHowChange?.(e.target.value)}
                              sx={{ height: 24, fontSize: '0.72rem' }}>
                              <MenuItem value="inner">INNER JOIN</MenuItem>
                              <MenuItem value="left">LEFT JOIN</MenuItem>
                              <MenuItem value="right">RIGHT JOIN</MenuItem>
                              {/* "full" is the one spelling the backend's join
                                  vocabulary uses ("outer" is read as it too). */}
                              <MenuItem value="full">FULL OUTER JOIN</MenuItem>
                            </Select>
                          </FormControl>
                          <Autocomplete size="small" freeSolo options={allColumnNames}
                            value={crossJoinLeftOn} onChange={(_e, v) => onCrossJoinLeftOnChange?.(v || '')}
                            onInputChange={(_e, v) => onCrossJoinLeftOnChange?.(v || '')}
                            renderInput={(params) => <TextField {...params} placeholder="Left key column" sx={{ '& .MuiInputBase-root': { height: 24, fontSize: '0.72rem' } }} />}
                          />
                          <Autocomplete size="small" freeSolo options={allColumnNames}
                            value={crossJoinRightOn} onChange={(_e, v) => onCrossJoinRightOnChange?.(v || '')}
                            onInputChange={(_e, v) => onCrossJoinRightOnChange?.(v || '')}
                            renderInput={(params) => <TextField {...params} placeholder="Right key column" sx={{ '& .MuiInputBase-root': { height: 24, fontSize: '0.72rem' } }} />}
                          />
                        </Box>
                      )}
                      <Box sx={{ px: 1, py: 0.3, bgcolor: 'action.hover', display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <StorageIcon sx={{ fontSize: 14, color: 'secondary.main' }} />
                        <Typography variant="caption" sx={{ fontWeight: 700, fontSize: '0.72rem' }}>
                          {connName(crossConnId)}
                        </Typography>
                      </Box>
                      {filteredCrossTables.map(t => {
                        const isSelected = selectedCrossTables.some(s => s.path === t.path);
                        return (
                          <Box key={t.path} sx={{
                            display: 'flex', alignItems: 'center', py: 0.1, px: 0.5, pl: 1.5,
                            cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' },
                          }}
                            onClick={() => onToggleCrossTable(t)}>
                            <Checkbox size="small" checked={isSelected} sx={{ p: 0.1, mr: 0.25 }}
                              inputProps={{ 'aria-label': `Join table ${t.name || t.path}` }} />
                            <TableChartIcon sx={{ fontSize: 14, mr: 0.5, opacity: 0.5 }} />
                            <Typography variant="caption" noWrap sx={{ fontWeight: isSelected ? 600 : 400, fontSize: '0.78rem' }}>
                              {t.name}
                            </Typography>
                          </Box>
                        );
                      })}
                    </>
                  )}
                </>
              )}
            </Box>
            )}
          </Box>
        </>

      {/* ── Context Menu ── */}
      <Menu
        open={!!ctxMenu}
        onClose={() => setCtxMenu(null)}
        anchorEl={ctxMenu?.anchorEl}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <MenuItem dense onClick={() => { if (ctxMenu) handlePreview(ctxMenu.table); }}>
          <PreviewIcon sx={{ fontSize: 14, mr: 1 }} /> Preview (100 rows)
        </MenuItem>
        <MenuItem dense onClick={() => { if (ctxMenu) { onToggleTable(ctxMenu.table); setCtxMenu(null); } }}>
          <AddCircleOutlineIcon sx={{ fontSize: 14, mr: 1 }} /> Add to Query
        </MenuItem>
        <MenuItem dense onClick={() => { if (ctxMenu) handleToggleFavorite(ctxMenu.table); }}>
          {ctxMenu && tableFavorites.has(ctxMenu.table.path)
            ? <StarIcon sx={{ fontSize: 14, mr: 1, color: 'warning.main' }} />
            : <StarBorderIcon sx={{ fontSize: 14, mr: 1 }} />}
          {ctxMenu && tableFavorites.has(ctxMenu.table.path) ? 'Unfavorite' : 'Favorite'}
        </MenuItem>
        <MenuItem dense onClick={() => { if (ctxMenu) handleCopyName(ctxMenu.table); }}>
          <ContentCopyIcon sx={{ fontSize: 14, mr: 1 }} /> Copy Name
        </MenuItem>
      </Menu>

      {/* ── Preview Dialog ── */}
      <AppDialog open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        size="lg"
        title={<>Preview: {previewData?.name || '...'}</>}
        contentSx={{ p: 0 }}
        actions={<>
          <Button onClick={() => setPreviewOpen(false)}>Close</Button>
        </>}>
          {previewLoading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
              <CircularProgress />
            </Box>
          ) : previewData && previewData.rows.length > 0 ? (
            <Box sx={{ overflow: 'auto', maxHeight: 400 }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.75rem' }}>
                <thead>
                  <tr>
                    {previewData.columns.map(col => (
                      <th key={col} style={{
                        padding: '4px 8px', textAlign: 'left', borderBottom: '2px solid #ddd',
                        position: 'sticky', top: 0, background: '#f5f5f5', fontWeight: 600,
                      }}>{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {previewData.rows.map((row: any, i: number) => (
                    <tr key={i} style={{ background: i % 2 === 0 ? '#fff' : '#fafafa' }}>
                      {previewData.columns.map(col => (
                        <td key={col} style={{ padding: '3px 8px', borderBottom: '1px solid #eee' }}>
                          {row[col] != null ? String(row[col]) : ''}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </Box>
          ) : previewData?.error ? (
            <Typography variant="body2" color="error" sx={{ p: 3 }} data-testid="table-preview-error">
              The preview could not be read: {previewData.error}
            </Typography>
          ) : (
            <Typography variant="body2" color="text.secondary" sx={{ p: 3, textAlign: 'center' }}>
              The table answered with no rows
            </Typography>
          )}
      </AppDialog>
    </Paper>
  );
};

export default React.memo(TableTree);
