/**
 * FeedStepPlanDialog — "what will run tonight", before any run exists.
 *
 * GET /api/feeds/{id}/step-plan answers this as a READ: the ordered plan,
 * the SKIPS WITH THEIR REASONS, and any refusals.  It is answerable on a
 * feed that has never run, which is what makes this a question rather
 * than a feature.
 *
 * THE SKIPS ARE THE POINT.  A plan that shows only what it will run looks
 * complete while missing a gate; the system logging what it did and never
 * what it declined to do is the failure this codebase keeps hitting.  So
 * the skipped list is rendered with the server's reason for each one, and
 * it is never collapsed away to make the screen tidier.
 *
 * A REFUSAL IS NOT A SKIP.  A skip means the step's own predicate did not
 * hold for this feed.  A refusal means the plan was supposed to run
 * something and now cannot — and when `is_fatal` the run will not proceed.
 * They are separate sections with separate severities.
 *
 * Every reason on this screen is the SERVER's.  Nothing here infers why a
 * step is missing.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Divider, MenuItem, Paper, Select, Stack,
  TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import { Replay as RetryIcon } from '@mui/icons-material';
import api from '../services/api';
import type {
  FeedFlow, FeedStepPlanResponse, PlannedStep,
} from '../services/api/feedSteps';

interface Props {
  /** Feed whose plan to show; null = closed. */
  feedId: number | null;
  feedName?: string | null;
  onClose: () => void;
}

const FeedStepPlanDialog: React.FC<Props> = ({ feedId, feedName, onClose }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [plan, setPlan] = useState<FeedStepPlanResponse | null>(null);
  const [businessDate, setBusinessDate] = useState('');
  const [flows, setFlows] = useState<FeedFlow[] | null>(null);
  const [flowsError, setFlowsError] = useState<string | null>(null);
  const [assigning, setAssigning] = useState(false);
  const [assignError, setAssignError] = useState<string | null>(null);

  const load = useCallback(async (id: number, date: string) => {
    setLoading(true);
    setError(null);
    try {
      const resp = await api.feedSteps.getStepPlan(id, date || null);
      setPlan(resp);
    } catch (e: any) {
      // A plan that could not be READ is not a feed with no steps.
      setPlan(null);
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (feedId == null) {
      setPlan(null); setError(null); setBusinessDate('');
      setAssignError(null);
      return;
    }
    void load(feedId, '');
    api.feedSteps.listFlows()
      .then(r => {
        // A 200 with no flow list in it is a defect, not an empty estate:
        // keeping `flows` null leaves the picker disabled and says why,
        // rather than offering "(no flow)" as if that were the truth.
        if (!Array.isArray(r?.flows)) throw new Error('the server returned no flow list');
        setFlows(r.flows); setFlowsError(null);
      })
      .catch((e: any) => { setFlows(null); setFlowsError(e?.message || String(e)); });
  }, [feedId, load]);

  const onAssignFlow = useCallback(async (value: string) => {
    if (feedId == null) return;
    setAssigning(true);
    setAssignError(null);
    try {
      await api.feedSteps.assignFlow(feedId, value === '' ? null : Number(value));
      await load(feedId, businessDate);
    } catch (e: any) {
      // The server owns this refusal (permission, unknown flow, inactive
      // flow) and states which.  Shown verbatim.
      setAssignError(e?.message || String(e));
    } finally {
      setAssigning(false);
    }
  }, [feedId, businessDate, load]);

  /** The plan in level order.  Steps sharing a level have no declared
   *  dependency between them. */
  const levelled = useMemo(() => {
    const byLevel = new Map<number, PlannedStep[]>();
    (plan?.steps || []).forEach(s => {
      const lvl = typeof s.level === 'number' ? s.level : 0;
      if (!byLevel.has(lvl)) byLevel.set(lvl, []);
      byLevel.get(lvl)!.push(s);
    });
    return Array.from(byLevel.entries()).sort((a, b) => a[0] - b[0]);
  }, [plan]);

  const mappedFlowMissing = plan?.flow_id != null
    && !(flows || []).some(f => f.id === plan.flow_id);

  const skipped = plan?.skipped || [];
  const refusals = plan?.refusals || [];
  const unknownFacts = plan?.profile?.unknown || [];

  return (
    <AppDialog open={feedId != null}
      onClose={onClose}
      size="md"
      title={<>
        <Stack direction="row" alignItems="center" spacing={1} flexWrap="wrap">
          <Typography component="span" sx={{ fontWeight: 600 }}>
            What will run — {feedName || `feed #${feedId ?? ''}`}
          </Typography>
          {plan && (
            <Chip
              size="small" variant="outlined"
              label={plan.flow_id == null ? 'no flow mapped' : `flow #${plan.flow_id}`}
              sx={{ height: 20, fontSize: '0.65rem' }}
            />
          )}
        </Stack>
      </>}
      actions={<>
        <Button onClick={onClose}>Close</Button>
      </>}>
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }} flexWrap="wrap">
          <TextField
            size="small" type="date" label="Business date (optional)"
            InputLabelProps={{ shrink: true }}
            value={businessDate}
            inputProps={{ 'aria-label': 'business date' }}
            onChange={e => setBusinessDate(e.target.value)}
          />
          <Button
            size="small" variant="outlined"
            onClick={() => feedId != null && void load(feedId, businessDate)}
          >
            Show plan
          </Button>
          <Box sx={{ flex: 1 }} />
          <Box>
            <Tooltip title="Map this feed to a flow. The steps a flow declares are planned in addition to the engine spine.">
              <span>
                <Select
                  size="small" displayEmpty
                  data-testid="feed-plan-flow-select"
                  inputProps={{ 'aria-label': 'flow mapped to this feed' }}
                  disabled={flows == null || assigning}
                  value={plan?.flow_id == null ? '' : String(plan.flow_id)}
                  onChange={e => void onAssignFlow(String(e.target.value))}
                  sx={{ minWidth: 220 }}
                >
                  <MenuItem value="">(no flow)</MenuItem>
                  {/* The feed is mapped to a flow the list does not contain
                      — because the list is unreadable, or because the flow
                      is gone.  Rendering it as "(no flow)" would state the
                      opposite of what the feed is configured to do. */}
                  {mappedFlowMissing && (
                    <MenuItem value={String(plan?.flow_id)}>
                      flow #{plan?.flow_id} — not in the flow list
                    </MenuItem>
                  )}
                  {(flows || []).map(f => (
                    <MenuItem key={f.id} value={String(f.id)}>
                      {f.name}{f.is_active ? '' : ' (inactive)'}
                    </MenuItem>
                  ))}
                </Select>
              </span>
            </Tooltip>
            {/* A disabled picker with no explanation reads as "there are no
                flows".  Say which it is. */}
            {flowsError && (
              <Typography variant="caption" color="warning.main"
                          data-testid="feed-plan-flows-unreadable"
                          sx={{ display: 'block', maxWidth: 260 }}>
                The flow list could not be read ({flowsError}) — unknown, not
                &quot;no flows exist&quot;.
              </Typography>
            )}
          </Box>
        </Stack>

        {assignError && (
          <Alert severity="error" sx={{ mb: 1 }} onClose={() => setAssignError(null)}>
            {assignError}
          </Alert>
        )}

        {loading && (
          <Stack direction="row" spacing={1} alignItems="center" sx={{ py: 2 }}>
            <CircularProgress size={18} />
            <Typography variant="body2">Reading the plan…</Typography>
          </Stack>
        )}

        {!loading && error && (
          <Alert
            severity="error"
            action={(
              <Button
                size="small" color="inherit" startIcon={<RetryIcon />}
                onClick={() => feedId != null && void load(feedId, businessDate)}
              >Retry</Button>
            )}
          >
            Could not read this feed's step plan — that is NOT the same as
            the feed having no steps. {error}
          </Alert>
        )}

        {!loading && !error && plan && (
          <>
            {refusals.length > 0 && (
              <Alert severity={plan.is_fatal ? 'error' : 'warning'} sx={{ mb: 2 }}>
                <Typography variant="body2" sx={{ fontWeight: 700 }}>
                  {plan.is_fatal
                    ? 'This plan REFUSES — the run will not proceed:'
                    : 'This plan carries refusals:'}
                </Typography>
                <ul style={{ margin: '4px 0 0 16px', padding: 0 }}>
                  {refusals.map((r, i) => (
                    <li key={i}>
                      <Typography variant="caption">{r}</Typography>
                    </li>
                  ))}
                </ul>
              </Alert>
            )}

            {unknownFacts.length > 0 && (
              <Alert severity="info" sx={{ mb: 2 }} data-testid="feed-plan-unknown-facts">
                Facts this feed could not resolve: {unknownFacts.join(', ')}.
                A predicate reading an unresolved fact is not read as false —
                the plan says so instead of guessing.
              </Alert>
            )}

            <Typography variant="overline" sx={{ display: 'block', color: 'text.secondary' }}>
              Will run · {plan.steps.length} step{plan.steps.length === 1 ? '' : 's'}
              {plan.level_count ? ` in ${plan.level_count} level${plan.level_count === 1 ? '' : 's'}` : ''}
            </Typography>

            {plan.steps.length === 0 ? (
              <Alert severity="info" sx={{ mb: 2 }}>
                This plan contains no steps.
              </Alert>
            ) : (
              <Box sx={{ mb: 2 }}>
                {levelled.map(([level, items]) => (
                  <Box key={level} sx={{ mb: 1 }}>
                    <Typography
                      variant="caption"
                      data-testid={`feed-plan-level-${level}`}
                      sx={{ display: 'block', color: 'text.secondary', letterSpacing: 1 }}
                    >
                      LEVEL {level} · {items.length}{' '}
                      {items.length === 1
                        ? 'step'
                        : 'steps with no dependency between them (may run in parallel)'}
                    </Typography>
                    {items.map(s => (
                      <Paper
                        key={s.alias} variant="outlined"
                        data-testid={`feed-plan-step-${s.alias}`}
                        sx={{ p: 1, mb: 0.5 }}
                      >
                        <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap">
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {s.seq}. {s.alias}
                          </Typography>
                          <Chip size="small" variant="outlined" label={s.step_type}
                                sx={{ height: 18, fontSize: '0.62rem' }} />
                          <Chip size="small" variant="outlined"
                                label={s.executor === 'engine' ? 'engine spine' : 'runner'}
                                sx={{ height: 18, fontSize: '0.62rem' }} />
                          <Chip size="small" variant="outlined" label={`from ${s.source}`}
                                sx={{ height: 18, fontSize: '0.62rem' }} />
                          {/* Tri-state, spelled as three states.  "never
                              declared" is a refusal with its own reason and
                              must not read as "declared unsafe". */}
                          <Chip
                            size="small" variant="outlined"
                            color={s.rerunnable === true ? 'success' : 'default'}
                            label={
                              s.rerunnable === true ? 're-runnable'
                              : s.rerunnable === false ? 'declared NOT re-runnable'
                              : 're-run safety never declared'
                            }
                            sx={{ height: 18, fontSize: '0.62rem' }}
                          />
                        </Stack>
                        {s.depends_on.length > 0 && (
                          <Typography variant="caption" color="text.secondary"
                                      sx={{ display: 'block' }}>
                            after: {s.depends_on.join(', ')}
                          </Typography>
                        )}
                        {s.description && (
                          <Typography variant="caption" color="text.secondary"
                                      sx={{ display: 'block' }}>
                            {s.description}
                          </Typography>
                        )}
                      </Paper>
                    ))}
                  </Box>
                ))}
              </Box>
            )}

            <Divider sx={{ my: 2 }} />

            <Typography variant="overline" sx={{ display: 'block', color: 'text.secondary' }}>
              Will NOT run · {skipped.length} skipped
            </Typography>
            {skipped.length === 0 ? (
              <Typography variant="body2" color="text.secondary">
                Nothing was declined for this feed.
              </Typography>
            ) : (
              <Stack spacing={0.5} data-testid="feed-plan-skipped">
                {skipped.map(s => (
                  <Paper key={s.alias} variant="outlined"
                         data-testid={`feed-plan-skipped-${s.alias}`}
                         sx={{ p: 1, bgcolor: 'action.hover' }}>
                    <Stack direction="row" spacing={0.75} alignItems="center">
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{s.alias}</Typography>
                      <Chip size="small" variant="outlined" label={s.step_type}
                            sx={{ height: 18, fontSize: '0.62rem' }} />
                    </Stack>
                    <Typography variant="caption" color="text.secondary"
                                sx={{ display: 'block', whiteSpace: 'pre-wrap' }}>
                      {s.reason}
                    </Typography>
                  </Paper>
                ))}
              </Stack>
            )}
          </>
        )}
    </AppDialog>
  );
};

export default FeedStepPlanDialog;
