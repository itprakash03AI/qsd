/**
 * Phase 85A — Dataset Creation Wizard
 * Usability rework 2026-08-22 — operator report: "could not read any columns
 * for the selected tables" / "no option select saved query" / work lost on
 * errors.  Four changes:
 *
 *  1. SAVED QUERY is a first-class (and default) source.  Pick a saved query
 *     (BQB or classic), its connection + SQL + columns carry through — the
 *     same picker surface Feed Generation uses (common/SavedQueryPicker).
 *  2. Columns come from the LOCAL CATALOG first (GET /api/catalog/columns)
 *     with provenance (source / stale / last_refreshed_at) and a "Refresh
 *     columns" action.  Presence-guarded: until the endpoint ships, the
 *     wizard silently degrades to the old source-direct schema reads.
 *  3. An empty or failed column load EXPLAINS ITSELF (reason + Retry +
 *     Refresh) — never the old dead-end "No columns loaded. Go back".
 *  4. NO WORK IS LOST: wizard state persists as a server draft
 *     (useServerDraft key `dataset.wizard`), restored on reopen; a failed
 *     column load keeps the previous columns; user column edits survive
 *     back/forward navigation and reloads merge instead of overwrite.
 *
 * Steps:
 *  1. Basic Info — Name, Subject, Description, Owner
 *  2. Source     — Saved query (default) OR connection+table OR custom SQL
 *  3. Columns    — Checkbox column list with editable friendly name, type, aggregation
 *  4. Joins      — Optional secondary source + join key pickers
 *  5. Review     — Summary + final preview + Create button
 */
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Dialog, Button, Stepper,
  Step, StepLabel, TextField, Box, Typography, FormControl, InputLabel,
  Select, MenuItem, Checkbox, Table, TableHead, TableRow, TableCell,
  TableBody, CircularProgress, Alert, Chip, Tooltip, IconButton,
  Stack, Divider, Paper,
  Autocomplete,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  PlayArrow as PreviewIcon,
  SkipNext as SkipIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useConnectionTables } from '../hooks/useConnectionTables';
import { useServerDraft } from '../hooks/useServerDraft';
import SavedQueryPicker, { type SavedQueryOption } from './common/SavedQueryPicker';
import { previewColumns as fetchSqlPreviewColumns } from './common/sqlPreviewApi';
import ListPager, { clientPage, PAGE_SIZES } from './common/ListPager';

// ── Constants ────────────────────────────────────────────────────────────────

const STEPS = ['Basic Info', 'Source', 'Columns', 'Joins (Optional)', 'Review & Create'];

const COLUMN_TYPES = ['dimension', 'measure', 'detail', 'kpi'] as const;
type ColumnType = typeof COLUMN_TYPES[number];

const AGGREGATIONS = ['', 'sum', 'avg', 'count', 'min', 'max', 'count_distinct'] as const;

const JOIN_TYPES = ['inner', 'left', 'right', 'full'] as const;

const DATA_TYPE_COLORS: Record<string, string> = {
  string: '#1976d2',
  number: '#388e3c',
  date: '#f57c00',
  boolean: '#7b1fa2',
};

/** Server-draft key — see the naming convention list in useServerDraft. */
const DRAFT_KEY = 'dataset.wizard';

// ── Interfaces ────────────────────────────────────────────────────────────────

interface WizardColumn {
  physical_name: string;
  friendly_name: string;
  column_type: ColumnType;
  data_type: string;
  aggregation: string;
  selected: boolean;
  /** Catalog-provided description (carried into the created column). */
  description?: string;
}

interface JoinConfig {
  connection_id: number | '';
  table_name: string;
  join_type: string;
  left_key: string;
  right_key: string;
}

interface PreviewResult {
  columns: string[];
  rows: Record<string, any>[];
}

/**
 * Provenance of the column list, from GET /api/catalog/columns.
 * Field names match the backend catalog contract exactly — every read is
 * presence-guarded so a backend that doesn't ship a field (or the endpoint
 * at all) degrades to the legacy source-direct path.
 */
interface CatalogMeta {
  source: 'catalog' | 'source' | 'none';
  last_refreshed_at: string | null;
  stale: boolean;
  row_estimate: number | null;
  message: string;
}

/** Deep-link seed — "Create dataset" from the Business Query Builder. */
export interface WizardInitialSource {
  sourceType: 'saved_query' | 'sql_file';
  sourceId: number;
  name?: string;
}

interface DatasetCreationWizardProps {
  open: boolean;
  onClose: () => void;
  onCreated: (dataset: any) => void;
  initialSource?: WizardInitialSource | null;
}

/** Everything the user can type or pick — persisted so nothing is lost. */
interface WizardDraft {
  step: number;
  name: string;
  subject: string;
  description: string;
  owner: string;
  sourceMode: 'saved_query' | 'table' | 'sql';
  sourceConnectionId: number | '';
  selectedTable: string;
  customSql: string;
  savedQueryId: number | '';
  columns: WizardColumn[];
  joins: JoinConfig[];
  loadedColsKey: string;
  savedAt: string;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function inferDataType(colName: string, dbType: string): string {
  const lt = (dbType || '').toLowerCase();
  const ln = (colName || '').toLowerCase();
  if (/int|bigint|smallint|tinyint|numeric|decimal|float|double|real|number/.test(lt)) return 'number';
  if (/date|time|timestamp/.test(lt)) return 'date';
  if (/bool/.test(lt)) return 'boolean';
  // Name-based fallback
  if (/date|_at$|_on$|timestamp/.test(ln)) return 'date';
  if (/id$|count$|amount$|price$|qty$|quantity$|total$|revenue$/.test(ln)) return 'number';
  return 'string';
}

function inferColumnType(colName: string, dataType: string): ColumnType {
  const ln = colName.toLowerCase();
  if (dataType === 'number') {
    if (/id$|_id$/.test(ln)) return 'dimension';
    return 'measure';
  }
  if (dataType === 'date') return 'detail';
  return 'dimension';
}

function inferAggregation(colType: ColumnType): string {
  if (colType === 'measure') return 'sum';
  return '';
}

/** The columns a preview answered, WITH the types it reported.
 *  2026-10-02 -- `/api/datasets/preview` returns `column_types` beside the
 *  names (int64 / float64 / datetime64 / VARCHAR...) and the wizard threw them
 *  away, typing every column by its NAME alone: `amt` (a double) became a
 *  string dimension, so a report could not SUM it.  Names-only answers keep
 *  working -- a missing type falls back to the name heuristic as before. */
function previewSchema(res: any): { name: string; type: string }[] {
  const types = (res && typeof res.column_types === 'object' && res.column_types) || {};
  return (res?.columns || []).map((col: any) => {
    const name = typeof col === 'string' ? col : (col?.name ?? '');
    const type = typeof col === 'string' ? (types[col] || '') : (col?.type || types[name] || '');
    return { name, type: String(type || '') };
  });
}

/** Strip trailing semicolons so the SQL can be wrapped as a subquery. */
function stripTrailingSemicolons(sql: string): string {
  return (sql || '').trim().replace(/;+\s*$/, '');
}

/** "3 min ago" / "2 h ago" / "5 d ago" — '' for unparseable input. */
function formatAge(iso: string | null | undefined): string {
  if (!iso || typeof iso !== 'string') return '';
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return '';
  const secs = Math.max(0, (Date.now() - t) / 1000);
  if (secs < 90) return 'just now';
  if (secs < 3600) return `${Math.round(secs / 60)} min ago`;
  if (secs < 86400) return `${Math.round(secs / 3600)} h ago`;
  return `${Math.round(secs / 86400)} d ago`;
}

/**
 * Presence guard for the local-catalog response.  The endpoint may not be
 * deployed yet (safeFetch throws, or an SPA catch-all returns `{}`), so the
 * caller only trusts the payload when it carries the contract's two
 * load-bearing fields: a `columns` array and a recognised `source`.
 */
function parseCatalogResponse(res: any): { columns: any[]; meta: CatalogMeta } | null {
  if (!res || typeof res !== 'object') return null;
  if (!Array.isArray(res.columns)) return null;
  if (res.source !== 'catalog' && res.source !== 'source' && res.source !== 'none') return null;
  return {
    columns: res.columns,
    meta: {
      source: res.source,
      last_refreshed_at: typeof res.last_refreshed_at === 'string' ? res.last_refreshed_at : null,
      stale: res.stale === true,
      row_estimate: typeof res.row_estimate === 'number' ? res.row_estimate : null,
      message: typeof res.message === 'string' ? res.message : '',
    },
  };
}

// ── Mini Preview Table ────────────────────────────────────────────────────────

const PreviewTable: React.FC<{ result: PreviewResult | null; loading: boolean; error: string }> = ({
  result, loading, error,
}) => {
  if (loading) return <Box sx={{ py: 2, textAlign: 'center' }}><CircularProgress size={24} /></Box>;
  if (error) return <Alert severity="warning" sx={{ mt: 1 }}>{error}</Alert>;
  if (!result) return null;
  return (
    <Box sx={{ overflowX: 'auto', mt: 1 }}>
      <Table size="small">
        <TableHead>
          <TableRow>
            {result.columns.map(col => (
              <TableCell key={col} sx={{ fontWeight: 700, whiteSpace: 'nowrap', fontSize: 11 }}>{col}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {result.rows.slice(0, 10).map((row, idx) => (
            <TableRow key={idx}>
              {result.columns.map(col => (
                <TableCell key={col} sx={{ fontSize: 11, whiteSpace: 'nowrap' }}>
                  {row[col] === null || row[col] === undefined ? (
                    <span style={{ color: '#aaa' }}>null</span>
                  ) : String(row[col]).substring(0, 60)}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block' }}>
        Preview (first {Math.min(result.rows.length, 10)} rows — table may contain more data)
      </Typography>
    </Box>
  );
};

// ── Main Component ────────────────────────────────────────────────────────────

/** One join key: pick from the table's columns, or type when the source
 *  cannot answer.  `freeSolo` is the fallback, not the default — an empty
 *  dropdown that blocks the author would trade one bad experience for
 *  another. */
const JoinKeyPicker: React.FC<{
  label: string;
  value: string;
  onChange: (v: string) => void;
  columns: any[];
  loading: boolean;
  onOpen: () => void;
  emptyHint: string;
}> = ({ label, value, onChange, columns, loading, onOpen, emptyHint }) => {
  const options = columns
    .map((c: any) => String(c?.physical_name ?? c?.name ?? c ?? ''))
    .filter(Boolean);
  return (
    <Autocomplete
      freeSolo
      size="small"
      options={options}
      loading={loading}
      onOpen={onOpen}
      value={value || ''}
      onInputChange={(_e, v) => onChange(v)}
      sx={{ flex: 1 }}
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          placeholder={options.length ? 'Pick a column' : 'Column name'}
          helperText={options.length ? undefined : emptyHint}
        />
      )}
    />
  );
};

const DatasetCreationWizard: React.FC<DatasetCreationWizardProps> = ({
  open, onClose, onCreated, initialSource = null,
}) => {
  const { user } = useAuth();

  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [globalError, setGlobalError] = useState('');

  // ── Step 1: Basic Info ───────────────────────────────────────────────────
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [owner, setOwner] = useState(user?.username || '');

  // ── Step 2: Source ───────────────────────────────────────────────────────
  const [connections, setConnections] = useState<any[]>([]);
  const [connectionsLoading, setConnectionsLoading] = useState(false);
  const [sourceMode, setSourceMode] = useState<'saved_query' | 'table' | 'sql'>('saved_query');
  const [sourceConnectionId, setSourceConnectionId] = useState<number | ''>('');
  const [selectedTable, setSelectedTable] = useState('');
  const [customSql, setCustomSql] = useState('');
  const [previewResult, setPreviewResult] = useState<PreviewResult | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState('');

  // Saved-query source (operator: "no option select saved query...its
  // biggest issues") — id picked in the shared picker, detail fetched here.
  const [savedQueryId, setSavedQueryId] = useState<number | ''>('');
  const [savedQuery, setSavedQuery] = useState<any | null>(null);
  const [savedQueryLoading, setSavedQueryLoading] = useState(false);
  const [savedQueryError, setSavedQueryError] = useState('');
  const [savedQueryFetchNonce, setSavedQueryFetchNonce] = useState(0);

  // ── Step 3: Columns ──────────────────────────────────────────────────────
  const [columns, setColumns] = useState<WizardColumn[]>([]);
  // The column list of a 1,000-column table is paged.  Another set of
  // columns (another source, a re-detect) goes back to page 1; editing a
  // friendly name on page 3 does not.
  const [colPage, setColPage] = useState(1);
  const [colPageSize, setColPageSize] = useState(50);
  const columnSetKey = columns.map(c => c.physical_name).join('\u0001');
  useEffect(() => { setColPage(1); }, [columnSetKey]);
  const [columnsLoading, setColumnsLoading] = useState(false);
  // WHY the column list is empty / possibly wrong — rendered, never swallowed.
  const [columnsError, setColumnsError] = useState('');
  // Set only when the LOCAL CATALOG answered — drives provenance UI.
  const [catalogMeta, setCatalogMeta] = useState<CatalogMeta | null>(null);
  const [catalogRefreshing, setCatalogRefreshing] = useState(false);
  // Source signature whose columns loaded successfully — prevents a
  // back/forward hop from wiping the user's column edits.
  const [loadedColsKey, setLoadedColsKey] = useState('');
  const attemptedColsKeyRef = useRef('');

  // ── Step 4: Joins ────────────────────────────────────────────────────────
  const [joins, setJoins] = useState<JoinConfig[]>([]);
  const [joinTables, setJoinTables] = useState<Record<number, any[]>>({});
  // 2026-09-04 -- the join keys used to be free-text boxes ("e.g.,
  // customer_id"), directly under two dropdowns that had already
  // established WHICH connection and WHICH table.  A typo produced a
  // relationship the engine could not resolve, and nothing said so until
  // a report on the dataset failed.
  //
  // The columns were never unknown: GET /api/datasets/connections/{id}/
  // schema/{table} answers for ANY source through the L1/L2/L3 catalog
  // cache -- the same seam auto-detect uses -- so a picker costs one
  // cached call.  Keyed by `${connectionId}::${table}` and fetched once.
  const [joinColumns, setJoinColumns] = useState<Record<string, any[]>>({});
  const [joinColsLoading, setJoinColsLoading] = useState<Record<string, boolean>>({});
  const joinColsAsked = useRef<Set<string>>(new Set());

  // The primary table, spelled the way the API stores it.  handleCreate
  // strips the same `__registered__:` marker; keeping one derivation
  // means the picker and the save cannot disagree about which table the
  // left-hand key belongs to.
  const primaryTableName = (sourceMode === 'table' && selectedTable)
    ? (selectedTable.startsWith('__registered__:')
        ? selectedTable.replace('__registered__:', '')
        : selectedTable)
    : '';

  const colsKeyFor = (connId: number | '' | undefined, table: string) =>
    (connId && table) ? `${connId}::${table}` : '';

  const ensureJoinColumns = useCallback(
    (connId: number | '' | undefined, table: string) => {
      const key = colsKeyFor(connId, table);
      if (!key || joinColsAsked.current.has(key)) return;
      joinColsAsked.current.add(key);
      setJoinColsLoading(prev => ({ ...prev, [key]: true }));
      api.getDatasetTableSchema(Number(connId), table)
        .then((res: any) => {
          const cols = Array.isArray(res?.columns) ? res.columns : [];
          setJoinColumns(prev => ({ ...prev, [key]: cols }));
        })
        .catch(() => {
          // A source that cannot answer must not block the join: the
          // field falls back to free text (freeSolo) rather than
          // becoming an empty dropdown the user cannot get past.
          setJoinColumns(prev => ({ ...prev, [key]: [] }));
        })
        .finally(() => setJoinColsLoading(prev => ({ ...prev, [key]: false })));
    }, []);

  // ── Draft persistence (operator: "dont loose any work") ──────────────────
  // Server-side draft via the house-standard hook.  Mirrored FROM state on
  // every change; restored INTO state once per open (unless a BQB deep link
  // seeds the wizard, which wins over the draft for that open).
  const [draft, setDraft, draftMeta] = useServerDraft<WizardDraft | null>(
    DRAFT_KEY, null, { disabled: !open });
  const [draftRestored, setDraftRestored] = useState(false);
  const restoreAttemptedRef = useRef(false);
  const draftMirrorReadyRef = useRef(false);
  const suppressSourceResetRef = useRef(false);

  const resetAllState = useCallback((keepDraftNotice = false) => {
    setStep(0);
    setName('');
    setSubject('');
    setDescription('');
    setOwner(user?.username || '');
    setSourceMode('saved_query');
    setSourceConnectionId('');
    setSelectedTable('');
    setCustomSql('');
    setSavedQueryId('');
    setSavedQuery(null);
    setSavedQueryError('');
    setPreviewResult(null);
    setPreviewError('');
    setColumns([]);
    setColumnsError('');
    setCatalogMeta(null);
    setLoadedColsKey('');
    attemptedColsKeyRef.current = '';
    setJoins([]);
    setGlobalError('');
    if (!keepDraftNotice) setDraftRestored(false);
  }, [user?.username]);

  // ── Reset + seed on open ──────────────────────────────────────────────────
  useEffect(() => {
    if (!open) {
      restoreAttemptedRef.current = false;
      draftMirrorReadyRef.current = false;
      return;
    }
    resetAllState();
    if (initialSource && initialSource.sourceId) {
      // Deep link from the Query Builder — the user already picked their
      // source there; never make them re-pick it.  Wins over any draft.
      restoreAttemptedRef.current = true;
      if (initialSource.name) setName(initialSource.name);
      if (initialSource.sourceType === 'saved_query') {
        setSourceMode('saved_query');
        setSavedQueryId(initialSource.sourceId);
      } else {
        setSourceMode('sql');
        api.sqlFiles.get(initialSource.sourceId)
          .then((f: any) => {
            if (!f) return;
            if (typeof f.content === 'string') setCustomSql(f.content);
            if (f.connection_id) setSourceConnectionId(f.connection_id);
            if (f.name) setName(prev => prev.trim() ? prev : f.name);
          })
          .catch(() => setGlobalError('Could not load the .sql file this dataset was started from — enter the SQL below.'));
      }
    }
  }, [open, initialSource, resetAllState]);

  // ── Draft restore (once per open, after the server GET settles) ──────────
  useEffect(() => {
    if (!open || draftMeta.loading) return;
    if (!restoreAttemptedRef.current) {
      restoreAttemptedRef.current = true;
      if (draft && typeof draft === 'object') {
        suppressSourceResetRef.current = true;
        if (typeof draft.step === 'number' && draft.step >= 0 && draft.step < STEPS.length) setStep(draft.step);
        if (typeof draft.name === 'string') setName(draft.name);
        if (typeof draft.subject === 'string') setSubject(draft.subject);
        if (typeof draft.description === 'string') setDescription(draft.description);
        if (typeof draft.owner === 'string' && draft.owner) setOwner(draft.owner);
        if (draft.sourceMode === 'saved_query' || draft.sourceMode === 'table' || draft.sourceMode === 'sql') {
          setSourceMode(draft.sourceMode);
        }
        if (typeof draft.sourceConnectionId === 'number') setSourceConnectionId(draft.sourceConnectionId);
        if (typeof draft.selectedTable === 'string') setSelectedTable(draft.selectedTable);
        if (typeof draft.customSql === 'string') setCustomSql(draft.customSql);
        if (typeof draft.savedQueryId === 'number') setSavedQueryId(draft.savedQueryId);
        if (Array.isArray(draft.columns)) setColumns(draft.columns.filter(c => c && c.physical_name));
        if (Array.isArray(draft.joins)) setJoins(draft.joins);
        if (typeof draft.loadedColsKey === 'string') {
          setLoadedColsKey(draft.loadedColsKey);
          attemptedColsKeyRef.current = draft.loadedColsKey;
        }
        setDraftRestored(true);
      }
    }
    draftMirrorReadyRef.current = true;
  }, [open, draftMeta.loading, draft]);

  const isDirty = !!(name.trim() || subject.trim() || description.trim()
    || sourceConnectionId || selectedTable || customSql.trim() || savedQueryId
    || columns.length > 0 || joins.length > 0);

  // ── Draft mirror — persist every meaningful change (hook debounces) ──────
  useEffect(() => {
    if (!open || draftMeta.loading || !draftMirrorReadyRef.current) return;
    if (!isDirty) return;
    setDraft({
      step, name, subject, description, owner,
      sourceMode, sourceConnectionId, selectedTable, customSql,
      savedQueryId,
      columns, joins, loadedColsKey,
      savedAt: new Date().toISOString(),
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, step, name, subject, description, owner, sourceMode,
      sourceConnectionId, selectedTable, customSql, savedQueryId,
      columns, joins, loadedColsKey]);

  const handleStartFresh = useCallback(() => {
    resetAllState();
    draftMeta.reset();
    setDraftRestored(false);
  }, [resetAllState, draftMeta]);

  // ── Load connections on open ──────────────────────────────────────────────
  useEffect(() => {
    if (!open) return;
    setConnectionsLoading(true);
    api.listConnections(true)
      .then((data: any[]) => setConnections(Array.isArray(data) ? data : []))
      .catch(() => {})
      .finally(() => setConnectionsLoading(false));
  }, [open]);

  // ── Saved-query detail fetch ─────────────────────────────────────────────
  useEffect(() => {
    if (!open || sourceMode !== 'saved_query' || !savedQueryId) {
      setSavedQuery(null);
      setSavedQueryError('');
      return;
    }
    let cancelled = false;
    setSavedQueryLoading(true);
    setSavedQueryError('');
    api.getSavedQuery(String(savedQueryId)).then((sq: any) => {
      if (cancelled) return;
      if (!sq) {
        // api.getSavedQuery swallows errors into null — cover both causes.
        setSavedQuery(null);
        setSavedQueryError('Could not load this saved query — it may have been deleted, or the server is unreachable.');
        return;
      }
      setSavedQuery(sq);
      const qc = sq.query_config || {};
      if (qc.connection_id) setSourceConnectionId(qc.connection_id);
      if (sq.name) setName(prev => prev.trim() ? prev : sq.name);
    }).finally(() => {
      if (!cancelled) setSavedQueryLoading(false);
    });
    return () => { cancelled = true; };
  }, [open, sourceMode, savedQueryId, savedQueryFetchNonce]);

  /** SQL body of the picked saved query ('' for visual-only queries). */
  const savedQuerySql: string = useMemo(() => {
    const qc = savedQuery?.query_config || {};
    const sql = qc.raw_sql || qc.custom_sql || '';
    return typeof sql === 'string' ? sql : '';
  }, [savedQuery]);

  // ── Load tables when connection changes (table mode only) ─────────────────
  //
  // 2026-08-10 -- was ``api.listRegisteredTables`` only, which is why the
  // semantic layer reported "no registered tables found for your connection"
  // on a healthy Starburst connection: you never REGISTER anything against a
  // SQL connection, you BROWSE it (catalog -> schema -> table).  The cascade,
  // the correct ``{tables: [...]}`` unwrap, and the fallback for file/S3
  // connections all live in ``useConnectionTables`` -- see that hook for the
  // full reasoning.  Same hook as the report builder's data-source step, so
  // the two screens can no longer drift apart.
  const picker = useConnectionTables(
    sourceMode === 'table' ? (sourceConnectionId || null) : null);
  const isSqlConn = picker.mode === 'sql';

  useEffect(() => {
    // Draft restore sets connection + table in one batch; this clearing
    // effect fires right after and must not undo the restored table.
    if (suppressSourceResetRef.current) {
      suppressSourceResetRef.current = false;
      return;
    }
    setSelectedTable('');
    setPreviewResult(null);
    // NOTE deps: connection only.  Catalog/schema changes clear the table in
    // their own onChange handlers below — the hook AUTO-selects a lone
    // catalog, and that must not wipe a draft-restored table selection.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sourceConnectionId]);

  // ── Preview source data ───────────────────────────────────────────────────
  const handlePreview = useCallback(async () => {
    if (!sourceConnectionId) return;
    setPreviewLoading(true);
    setPreviewError('');
    setPreviewResult(null);
    try {
      let sql = '';
      if (sourceMode === 'saved_query') {
        if (!savedQuerySql.trim()) {
          setPreviewError('This saved query has no SQL body to preview.');
          setPreviewLoading(false);
          return;
        }
        sql = `SELECT * FROM (${stripTrailingSemicolons(savedQuerySql)}) __preview__ LIMIT 10`;
      } else if (sourceMode === 'sql' && customSql.trim()) {
        sql = `SELECT * FROM (${stripTrailingSemicolons(customSql)}) __preview__ LIMIT 10`;
      } else if (selectedTable) {
        const tableName = selectedTable.startsWith('__registered__:')
          ? selectedTable.replace('__registered__:', '')
          : selectedTable;
        sql = `SELECT * FROM "${tableName}" LIMIT 10`;
      } else {
        setPreviewError('Select a table or enter SQL first');
        setPreviewLoading(false);
        return;
      }
      // Use dataset preview endpoint if available, otherwise fall back to execute
      const res = await api.previewDatasetSource({
        connection_id: Number(sourceConnectionId),
        sql,
        limit: 10,
      });
      setPreviewResult({ columns: res.columns || [], rows: res.rows || [] });
    } catch (e: any) {
      setPreviewError(e.message || 'Preview failed');
    } finally {
      setPreviewLoading(false);
    }
  }, [sourceConnectionId, sourceMode, customSql, selectedTable, savedQuerySql]);

  // ── Column loading ───────────────────────────────────────────────────────

  /** Identity of the current source — column loads are keyed on this so
   *  revisiting step 3 with an unchanged source never refetches (and never
   *  wipes the user's per-column edits). */
  const sourceKey = useMemo(() => {
    if (sourceMode === 'saved_query') return `sq:${savedQueryId}`;
    if (sourceMode === 'sql') return `raw:${sourceConnectionId}:${customSql.trim()}`;
    return `tbl:${sourceConnectionId}:${selectedTable}`;
  }, [sourceMode, savedQueryId, sourceConnectionId, customSql, selectedTable]);

  /** Merge freshly detected columns with the user's existing edits — a
   *  reload must refresh the catalog facts, not revert renames/selections. */
  const buildWizardColumns = useCallback((schemaData: any[]): WizardColumn[] => {
    const prevByName = new Map(columns.map(c => [c.physical_name, c]));
    return schemaData.map((col: any, idx: number) => {
      const physName = col.physical_name || col.name || col.column_name || String(idx);
      const prev = prevByName.get(physName);
      const dbType = col.data_type || col.type || col.dtype || '';
      const dataType = inferDataType(physName, dbType);
      const colType = inferColumnType(physName, dataType);
      const catalogDescription = typeof col.description === 'string' ? col.description : '';
      if (prev) {
        // Keep every user-editable field; only refresh the description.
        return { ...prev, description: catalogDescription || prev.description };
      }
      return {
        physical_name: physName,
        friendly_name: col.friendly_name || physName.replace(/_/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase()),
        column_type: colType,
        data_type: dataType,
        aggregation: inferAggregation(colType),
        selected: !col.is_hidden,
        description: catalogDescription,
      };
    });
  }, [columns]);

  const loadColumns = useCallback(async (force: boolean) => {
    if (sourceMode === 'table' && (!sourceConnectionId || !selectedTable)) return;
    if (sourceMode === 'sql' && (!sourceConnectionId || !customSql.trim())) return;
    if (sourceMode === 'saved_query') {
      if (!savedQueryId) return;
      // Detail fetch still in flight (or failed) — do NOT mark this source
      // as attempted; the columns effect re-fires when the fetch settles.
      if (savedQueryLoading || !savedQuery) return;
    }
    if (!force && attemptedColsKeyRef.current === sourceKey) return;
    attemptedColsKeyRef.current = sourceKey;

    setColumnsLoading(true);
    setColumnsError('');
    try {
      let schemaData: any[] = [];
      let meta: CatalogMeta | null = null;

      if (sourceMode === 'table' && selectedTable) {
        const tableName = selectedTable.startsWith('__registered__:')
          ? selectedTable.replace('__registered__:', '')
          : selectedTable;
        // 1) LOCAL CATALOG — authoritative when the endpoint exists.  Fast,
        //    works when the source is slow/unreachable, and self-describing
        //    (source/stale/last_refreshed_at/message).
        try {
          const res = await api.getCatalogColumns(Number(sourceConnectionId), tableName);
          const parsed = parseCatalogResponse(res);
          if (parsed) {
            meta = parsed.meta;
            schemaData = [...parsed.columns]
              .filter((c: any) => c && (c.name || c.physical_name))
              .sort((a: any, b: any) => {
                const ao = typeof a.ordinal === 'number' ? a.ordinal : 0;
                const bo = typeof b.ordinal === 'number' ? b.ordinal : 0;
                return ao - bo;
              });
          }
        } catch { /* endpoint not deployed / failed → legacy path below */ }

        if (!meta) {
          // 2) LEGACY source-direct reads — today's behaviour, kept intact
          //    until the catalog endpoint lands everywhere.
          try {
            const res = await api.getRegisteredTableSchema(String(sourceConnectionId), tableName);
            schemaData = Array.isArray(res) ? res : (res?.columns || res?.schema || []);
          } catch {
            const res2 = await api.previewDatasetColumns(Number(sourceConnectionId), tableName);
            schemaData = res2?.columns || [];
          }
          if (!Array.isArray(schemaData) || schemaData.length === 0) {
            throw new Error(
              `The source returned no columns for "${tableName}". The table may be empty, `
              + 'unreachable, or your connection may lack metadata permissions.');
          }
        }
      } else if (sourceMode === 'saved_query') {
        const qc = savedQuery.query_config || {};
        if (savedQuerySql.trim()) {
          // 1) sqlglot parse on the backend — no source round-trip.
          const parsed = await fetchSqlPreviewColumns(
            savedQuerySql, 'duckdb', Number(sourceConnectionId) || qc.connection_id || null);
          // 2026-09-04 -- use parsed.PROJECTION, not parsed.columns.
          //
          // `columns` is every column the statement REFERENCES, including
          // WHERE / GROUP BY / ORDER BY / JOIN ON -- correct for the filter
          // editor that endpoint was built for, and wrong for a dataset's
          // OUTPUT SHAPE.  A reported Starburst query projected 23 columns
          // and named three more only in its WHERE; the dataset was created
          // with 26, every report on it selected all 26, and the engine
          // emitted `SELECT "system_id" ... FROM _base` -- COLUMN_NOT_FOUND
          // at the source, naming one column and explaining nothing.
          //
          // A column a query FILTERS ON is not a column it RETURNS.
          const projected: string[] = Array.isArray(parsed?.projection)
            ? parsed.projection.filter(Boolean) : [];
          if (projected.length > 0) {
            const typeByName = new Map<string, string>();
            Object.values(parsed.columns_by_table || {}).forEach((arr: any) => {
              (arr as any[]).forEach((c: any) => {
                if (c?.name && c?.type) typeByName.set(String(c.name).toLowerCase(), String(c.type));
              });
            });
            schemaData = projected.map((name: string) => ({
              name,
              type: typeByName.get(String(name).toLowerCase()) || '',
            }));
          } else {
            // 2) No projection the parser can name (SELECT *, or SQL it cannot
            //    read): only the SOURCE knows the output shape, so ask it --
            //    the one-row execution preview the SQL mode uses.
            //
            //    2026-10-02 -- there was a middle branch here that fell back
            //    to `parsed.columns`, the columns the statement REFERENCES,
            //    guarded by "no column named '*'".  The parser never reports
            //    '*' as a column, so for `select * from trades where dt = ...`
            //    the guard passed and the wizard offered ONE column -- `dt`,
            //    the WHERE column -- for an 11-column query: the 2026-09-04
            //    defect above, through its own fallback.  Found by the Docker
            //    browser journey (e2e/docker-storage-dataset-journey.spec.ts).
            const res = await api.previewDatasetSource({
              connection_id: Number(sourceConnectionId) || qc.connection_id,
              sql: `SELECT * FROM (${stripTrailingSemicolons(savedQuerySql)}) __preview__ LIMIT 1`,
              limit: 1,
            });
            schemaData = previewSchema(res);
          }
        } else {
          // Visual saved query — its selected columns ARE the output shape.
          const names: string[] = [];
          (Array.isArray(qc.columns) ? qc.columns : []).forEach((c: any) => {
            if (typeof c === 'string' && c) names.push(c);
          });
          (Array.isArray(qc.selectedColumns) ? qc.selectedColumns : []).forEach((c: any) => {
            const n = typeof c === 'string' ? c : c?.columnName;
            if (n && !names.includes(n)) names.push(n);
          });
          if (names.length === 0) {
            throw new Error('This saved query has no SQL body and no selected columns — open it in the '
              + 'Query Builder and save it again, or pick a different query.');
          }
          schemaData = names.map(n => ({ name: n, type: '' }));
        }
        if (schemaData.length === 0) {
          throw new Error('Could not determine the columns of this saved query. '
            + 'Use Preview on the Source step to check the query still runs.');
        }
      } else if (sourceMode === 'sql' && customSql.trim()) {
        const res = await api.previewDatasetSource({
          connection_id: Number(sourceConnectionId),
          sql: `SELECT * FROM (${stripTrailingSemicolons(customSql)}) __preview__ LIMIT 1`,
          limit: 1,
        });
        schemaData = previewSchema(res);
        if (schemaData.length === 0) {
          throw new Error('The SQL ran but returned no columns — check the statement.');
        }
      }

      setCatalogMeta(meta);
      if (meta && meta.source === 'none') {
        // The catalog answered "I have nothing yet" — that is NOT an error;
        // step 3 renders meta.message plus a Refresh-columns action.
        setColumns([]);
        setLoadedColsKey('');
      } else {
        setColumns(buildWizardColumns(schemaData));
        setLoadedColsKey(sourceKey);
      }
    } catch (e: any) {
      // NEVER wipe what the user already has — keep previous columns and
      // explain what happened + how to move forward.
      setColumnsError(e?.message || 'Failed to load columns');
    } finally {
      setColumnsLoading(false);
    }
  }, [sourceMode, sourceConnectionId, selectedTable, customSql, savedQueryId,
      savedQuery, savedQueryLoading, savedQueryError, savedQuerySql, sourceKey,
      buildWizardColumns]);

  // Auto-load whenever the Columns step is shown (covers Next-navigation,
  // draft restore straight into step 3, and source changes).
  useEffect(() => {
    if (!open || step !== 2) return;
    loadColumns(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, step, sourceKey, savedQuery]);

  /** POST /api/catalog/columns/refresh then re-read — the way out of the
   *  "no columns in the catalog yet" and "stale" states. */
  const handleCatalogRefresh = useCallback(async () => {
    if (sourceMode !== 'table' || !sourceConnectionId || !selectedTable) return;
    const tableName = selectedTable.startsWith('__registered__:')
      ? selectedTable.replace('__registered__:', '')
      : selectedTable;
    setCatalogRefreshing(true);
    setColumnsError('');
    try {
      await api.refreshCatalogColumns({
        connection_id: Number(sourceConnectionId),
        table: tableName,
      });
      await loadColumns(true);
    } catch (e: any) {
      setColumnsError(e?.message || 'Column refresh failed — the source may be unreachable.');
    } finally {
      setCatalogRefreshing(false);
    }
  }, [sourceMode, sourceConnectionId, selectedTable, loadColumns]);

  // ── Step navigation ───────────────────────────────────────────────────────
  const handleNext = () => {
    if (step === 0) {
      // Validate basic info
      if (!name.trim() || !subject.trim()) {
        setGlobalError('Name and Subject are required');
        return;
      }
      setGlobalError('');
    }
    if (step === 1) {
      // Validate source
      if (sourceMode === 'saved_query') {
        if (!savedQueryId) {
          setGlobalError('Pick a saved query');
          return;
        }
        if (savedQueryError) {
          setGlobalError(savedQueryError);
          return;
        }
      } else if (!sourceConnectionId) {
        setGlobalError('Select a connection');
        return;
      } else if (sourceMode === 'table' && !selectedTable) {
        setGlobalError('Select a table');
        return;
      } else if (sourceMode === 'sql' && !customSql.trim()) {
        setGlobalError('Enter custom SQL');
        return;
      }
      setGlobalError('');
    }
    setStep(s => s + 1);
  };

  const handleBack = () => {
    setGlobalError('');
    setStep(s => s - 1);
  };

  // ── Column updates ────────────────────────────────────────────────────────
  const updateColumn = (idx: number, field: keyof WizardColumn, value: any) => {
    setColumns(prev => prev.map((col, i) => {
      if (i !== idx) return col;
      const updated = { ...col, [field]: value };
      // Auto-set aggregation when type changes to measure
      if (field === 'column_type') {
        updated.aggregation = inferAggregation(value as ColumnType);
      }
      return updated;
    }));
  };

  const toggleAllColumns = (checked: boolean) => {
    setColumns(prev => prev.map(col => ({ ...col, selected: checked })));
  };

  // ── Join management ───────────────────────────────────────────────────────
  const addJoin = () => {
    setJoins(prev => [...prev, {
      connection_id: '',
      table_name: '',
      join_type: 'inner',
      left_key: '',
      right_key: '',
    }]);
  };

  const removeJoin = (idx: number) => {
    setJoins(prev => prev.filter((_, i) => i !== idx));
  };

  const updateJoin = (idx: number, field: keyof JoinConfig, value: any) => {
    setJoins(prev => prev.map((j, i) => i !== idx ? j : { ...j, [field]: value }));
    // The secondary table just changed -- its columns are what the
    // right-hand key must come from.
    if (field === 'table_name' && value) {
      const j = joins[idx];
      ensureJoinColumns(j?.connection_id, String(value));
    }
    // Load tables for the join connection
    if (field === 'connection_id' && value) {
      api.listRegisteredTables(String(value))
        .then((data: any) => {
          const tables = Array.isArray(data) ? data : (data?.tables || []);
          // 2026-08-10 -- drop ``_is_schema`` rows.  When a SQL connection has
          // no default schema configured this endpoint returns the SCHEMAS
          // flagged that way, and they rendered here as pickable "tables"
          // called ``catalog.schema`` that no join could ever resolve.
          setJoinTables(prev => ({
            ...prev,
            [value as number]: tables.filter((t: any) => !t?._is_schema),
          }));
        })
        .catch(() => {});
    }
  };

  // ── Create dataset ────────────────────────────────────────────────────────
  const handleCreate = async () => {
    if (sourceMode === 'saved_query' && !savedQuery) {
      setGlobalError('The saved query details never loaded — go back to the Source step and re-pick it.');
      return;
    }
    setSaving(true);
    setGlobalError('');
    try {
      const tableName = sourceMode === 'table' && selectedTable
        ? (selectedTable.startsWith('__registered__:')
            ? selectedTable.replace('__registered__:', '')
            : selectedTable)
        : '';

      // Build source_tables + base_query per source mode
      const sourceTables: any[] = [];
      let baseQuery = '';
      if (sourceMode === 'table' && sourceConnectionId && tableName) {
        sourceTables.push({
          connection_id: Number(sourceConnectionId),
          table: tableName,
          alias: 't1',
        });
      } else if (sourceMode === 'sql') {
        baseQuery = customSql.trim();
      } else if (sourceMode === 'saved_query') {
        // A saved query becomes the dataset's base query; a visual query
        // with no SQL body maps its first source file/table instead.
        const qc = savedQuery?.query_config || {};
        if (savedQuerySql.trim()) {
          baseQuery = savedQuerySql.trim();
        } else if (sourceConnectionId && Array.isArray(qc.files) && qc.files.length > 0) {
          sourceTables.push({
            connection_id: Number(sourceConnectionId),
            table: String(qc.files[0]),
            alias: 't1',
          });
        }
      }

      // Build relationships from joins
      const relationships: any[] = joins
        .filter(j => j.connection_id && j.table_name && j.left_key && j.right_key)
        .map((j) => ({
          left_table: tableName || 'main',
          right_table: j.table_name,
          join_keys: [{ left: j.left_key, right: j.right_key }],
          join_type: j.join_type,
          cardinality: 'many_to_one',
        }));

      // Create the dataset
      const dataset = await api.createDataset({
        name: name.trim(),
        subject: subject.trim(),
        description: description.trim(),
        connection_ids: sourceConnectionId ? [Number(sourceConnectionId)] : [],
        source_tables: sourceTables,
        base_query: baseQuery,
        is_published: false,
      });

      const datasetId = dataset.id;

      // Bulk-create selected columns
      const selectedCols = columns.filter(c => c.selected);
      if (selectedCols.length > 0) {
        await api.bulkCreateDatasetColumns(datasetId, selectedCols.map((col, idx) => ({
          physical_name: col.physical_name,
          friendly_name: col.friendly_name,
          column_type: col.column_type,
          data_type: col.data_type,
          aggregation: col.aggregation || '',
          description: col.description || '',
          sort_order: idx,
          is_hidden: false,
        })));
      }

      // Create relationships
      for (const rel of relationships) {
        try {
          await api.createDatasetRelationship(datasetId, rel);
        } catch { /* ignore */ }
      }

      // Success — the draft has served its purpose.
      draftMeta.reset();
      onCreated(dataset);
      onClose();
    } catch (e: any) {
      // Dialog stays open, every field keeps its value — the user fixes
      // the problem and clicks Create again.
      setGlobalError(e.message || 'Failed to create dataset');
    } finally {
      setSaving(false);
    }
  };

  // ── Close guard — closing must never cost the user their work ────────────
  const handleDialogClose = (_evt: object, reason?: string) => {
    if ((reason === 'backdropClick' || reason === 'escapeKeyDown') && isDirty) {
      // Ignore accidental dismissals once anything is entered; the explicit
      // Close button below is always available (and the draft survives).
      return;
    }
    onClose();
  };

  const handleCancelClick = () => {
    // Push any pending draft write NOW so a same-second reopen restores it.
    if (isDirty) void draftMeta.flush();
    onClose();
  };

  // ── Step content renderers ────────────────────────────────────────────────

  const renderStep1 = () => (
    <Stack spacing={2} sx={{ mt: 1 }}>
      <TextField
        label="Dataset Name *"
        value={name}
        onChange={e => setName(e.target.value)}
        fullWidth size="small"
        placeholder="e.g., Sales Analytics"
        error={!!globalError && !name.trim()}
      />
      <TextField
        label="Subject / Domain *"
        value={subject}
        onChange={e => setSubject(e.target.value)}
        fullWidth size="small"
        placeholder="e.g., Finance, Sales, HR"
        error={!!globalError && !subject.trim()}
        helperText="Used to group datasets in the Business Portal"
      />
      <TextField
        label="Description"
        value={description}
        onChange={e => setDescription(e.target.value)}
        fullWidth size="small" multiline rows={3}
        placeholder="Describe what data this dataset contains and its purpose"
      />
      <TextField
        label="Owner"
        value={owner}
        onChange={e => setOwner(e.target.value)}
        fullWidth size="small"
        placeholder="username or team name"
      />
    </Stack>
  );

  const renderSavedQuerySource = () => (
    <Stack spacing={2}>
      <SavedQueryPicker
        value={savedQueryId}
        onChange={(q: SavedQueryOption | null) => {
          setSavedQueryId(q ? q.id : '');
          setPreviewResult(null);
          setPreviewError('');
        }}
        helperTextWhenEmpty="No saved queries available — create one in the Query Builder first."
      />
      {savedQueryLoading && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <CircularProgress size={16} />
          <Typography variant="caption" color="text.secondary">Loading query details…</Typography>
        </Box>
      )}
      {savedQueryError && (
        <Alert severity="error"
               action={<Button size="small" onClick={() => setSavedQueryFetchNonce(n => n + 1)}>Retry</Button>}>
          {savedQueryError}
        </Alert>
      )}
      {savedQuery && !savedQueryError && (
        <Paper variant="outlined" sx={{ p: 1.5 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
            <Typography variant="body2" fontWeight={600}>{savedQuery.name}</Typography>
            <Chip
              size="small"
              label={connections.find(c => c.id === sourceConnectionId)?.name
                || (sourceConnectionId ? `Connection #${sourceConnectionId}` : 'Connection: from query')}
            />
            {!savedQuerySql.trim() && (
              <Chip size="small" color="info" label="visual query" />
            )}
          </Box>
          {savedQuery.description && (
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
              {savedQuery.description}
            </Typography>
          )}
          {savedQuerySql.trim() && (
            <Box sx={{
              mt: 1, p: 1, bgcolor: 'action.hover', borderRadius: 1,
              maxHeight: 120, overflow: 'auto',
              fontFamily: 'monospace', fontSize: 12, whiteSpace: 'pre-wrap',
            }}>
              {savedQuerySql}
            </Box>
          )}
        </Paper>
      )}
    </Stack>
  );

  const renderStep2 = () => (
    <Stack spacing={2} sx={{ mt: 1 }}>
      {/* Source mode toggle — saved query FIRST: it is the path where the
          user has already done the hard work somewhere else. */}
      <Box sx={{ display: 'flex', gap: 1 }}>
        <Button
          variant={sourceMode === 'saved_query' ? 'contained' : 'outlined'}
          size="small"
          onClick={() => { setSourceMode('saved_query'); setPreviewResult(null); }}
        >
          Saved Query
        </Button>
        <Button
          variant={sourceMode === 'table' ? 'contained' : 'outlined'}
          size="small"
          onClick={() => { setSourceMode('table'); setPreviewResult(null); }}
        >
          Table / File
        </Button>
        <Button
          variant={sourceMode === 'sql' ? 'contained' : 'outlined'}
          size="small"
          onClick={() => { setSourceMode('sql'); setPreviewResult(null); }}
        >
          Custom SQL
        </Button>
      </Box>

      {sourceMode === 'saved_query' && renderSavedQuerySource()}

      {/* Connection selector (table + SQL modes; a saved query brings its own) */}
      {sourceMode !== 'saved_query' && (
        <FormControl fullWidth size="small">
          <InputLabel id="sel-datasetcreationwizard-connection">Connection *</InputLabel>
          <Select labelId="sel-datasetcreationwizard-connection"
            value={sourceConnectionId}
            label="Connection *"
            onChange={e => setSourceConnectionId(e.target.value as number)}
            disabled={connectionsLoading}
          >
            <MenuItem value="">— Select Connection —</MenuItem>
            {connections.map(c => (
              <MenuItem key={c.id} value={c.id}>
                {c.name} ({c.connection_type})
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      )}

      {/* Table selector */}
      {sourceMode === 'table' && sourceConnectionId && (
        <>
          {isSqlConn && (
            <Box sx={{ display: 'flex', gap: 1, mb: 1.5, flexWrap: 'wrap' }}>
              <FormControl size="small" sx={{ minWidth: 170 }}>
                <InputLabel id="sel-datasetcreationwizard-catalog">Catalog</InputLabel>
                <Select labelId="sel-datasetcreationwizard-catalog" label="Catalog" value={picker.catalog}
                        onChange={e => {
                          picker.setCatalog(String(e.target.value));
                          setSelectedTable('');
                          setPreviewResult(null);
                        }}>
                  {picker.catalogs.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                </Select>
              </FormControl>
              <FormControl size="small" sx={{ minWidth: 170 }} disabled={!picker.catalog}>
                <InputLabel id="sel-datasetcreationwizard-schema">Schema</InputLabel>
                <Select labelId="sel-datasetcreationwizard-schema" label="Schema" value={picker.schema}
                        onChange={e => {
                          picker.setSchema(String(e.target.value));
                          setSelectedTable('');
                          setPreviewResult(null);
                        }}>
                  {picker.schemas.map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
                </Select>
              </FormControl>
              <TextField size="small" label="Filter tables" value={picker.filter}
                         onChange={e => picker.setFilter(e.target.value)}
                         disabled={!picker.schema} sx={{ minWidth: 180 }} />
            </Box>
          )}
          {picker.error && (
            <Alert severity="error" sx={{ mb: 1.5 }}
                   action={<Button size="small" onClick={picker.reload}>Retry</Button>}>
              {picker.error}
            </Alert>
          )}
          {isSqlConn && picker.needsSelection && !picker.error && !selectedTable && (
            <Alert severity="info" sx={{ mb: 1.5 }}>
              Pick a catalog and schema to list its tables.
            </Alert>
          )}
          <FormControl fullWidth size="small">
            <InputLabel id="sel-datasetcreationwizard-table-file">Table / File *</InputLabel>
            <Select labelId="sel-datasetcreationwizard-table-file"
              value={selectedTable}
              label="Table / File *"
              onChange={e => { setSelectedTable(e.target.value); setPreviewResult(null); }}
              disabled={picker.loading || (picker.needsSelection && !selectedTable)}
              endAdornment={picker.loading ? <CircularProgress size={16} sx={{ mr: 2 }} /> : null}
            >
              <MenuItem value="">— Select Table —</MenuItem>
              {/* A restored draft may reference a table the picker hasn't
                  re-listed yet (catalog/schema not re-chosen).  Surface it so
                  the user's choice stays visible instead of a blank field. */}
              {selectedTable && !picker.filteredTables.some(t =>
                (isSqlConn ? t.qualified : `__registered__:${t.qualified}`) === selectedTable) && (
                <MenuItem value={selectedTable}>
                  {selectedTable.replace('__registered__:', '').split('.').pop() || selectedTable}
                </MenuItem>
              )}
              {picker.filteredTables.map(t => {
                // A browsed SQL table is already fully qualified, so it needs
                // no ``__registered__:`` marker; a registered one keeps it so
                // the existing strip-on-save logic is untouched.
                const key = isSqlConn ? t.qualified : `__registered__:${t.qualified}`;
                return (
                  <MenuItem key={key} value={key}>
                    {/* SHORT label — the catalog and schema are already chosen. */}
                    {t.name}
                    {t.raw?.description && (
                      <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                        {t.raw.description}
                      </Typography>
                    )}
                  </MenuItem>
                );
              })}
            </Select>
          </FormControl>
        </>
      )}

      {/* Custom SQL editor */}
      {sourceMode === 'sql' && (
        <TextField
          label="SQL Query"
          value={customSql}
          onChange={e => setCustomSql(e.target.value)}
          fullWidth
          multiline
          rows={6}
          size="small"
          placeholder="SELECT * FROM my_table WHERE ..."
          InputProps={{ sx: { fontFamily: 'monospace', fontSize: 13 } }}
        />
      )}

      {/* Preview button */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Button
          variant="outlined"
          size="small"
          startIcon={previewLoading ? <CircularProgress size={14} /> : <PreviewIcon />}
          onClick={handlePreview}
          disabled={previewLoading || !sourceConnectionId
            || (sourceMode === 'table' && !selectedTable)
            || (sourceMode === 'sql' && !customSql.trim())
            || (sourceMode === 'saved_query' && !savedQuerySql.trim())}
        >
          Preview (10 rows)
        </Button>
        {previewResult && (
          <Chip size="small" color="success" label={`${previewResult.columns.length} columns, ${previewResult.rows.length} rows`} />
        )}
      </Box>

      <PreviewTable result={previewResult} loading={false} error={previewError} />
    </Stack>
  );

  const renderColumnsProvenance = () => {
    if (!catalogMeta || catalogMeta.source === 'none') return null;
    const age = formatAge(catalogMeta.last_refreshed_at);
    return (
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1, flexWrap: 'wrap' }}>
        <Chip
          size="small"
          color={catalogMeta.stale ? 'warning' : 'default'}
          label={catalogMeta.source === 'catalog'
            ? `Columns from catalog${age ? ` · refreshed ${age}` : ''}${catalogMeta.stale ? ' · stale' : ''}`
            : `Columns read from source${age ? ` · ${age}` : ''}`}
        />
        {typeof catalogMeta.row_estimate === 'number' && (
          <Typography variant="caption" color="text.secondary">
            ~{catalogMeta.row_estimate.toLocaleString()} rows
          </Typography>
        )}
        <Button
          size="small"
          startIcon={catalogRefreshing ? <CircularProgress size={12} /> : <RefreshIcon />}
          onClick={handleCatalogRefresh}
          disabled={catalogRefreshing}
        >
          Refresh columns
        </Button>
      </Box>
    );
  };

  const renderColumnsEmptyState = () => {
    // Ranked: a load error explains itself first; then the catalog's own
    // "nothing here yet" message; a bare fallback should be unreachable.
    const effectiveError = columnsError
      || (sourceMode === 'saved_query' ? savedQueryError : '');
    if (effectiveError) {
      return (
        <Alert
          severity="error"
          action={
            <Stack direction="row" spacing={1}>
              <Button color="inherit" size="small" onClick={() => {
                if (sourceMode === 'saved_query' && savedQueryError) {
                  setSavedQueryFetchNonce(n => n + 1);
                }
                loadColumns(true);
              }}>Retry</Button>
              {sourceMode === 'table' && (
                <Button color="inherit" size="small" onClick={handleCatalogRefresh}
                        disabled={catalogRefreshing}>
                  Refresh columns
                </Button>
              )}
            </Stack>
          }
        >
          {effectiveError}
        </Alert>
      );
    }
    if (catalogMeta && catalogMeta.source === 'none') {
      return (
        <Alert
          severity="info"
          action={
            <Button color="inherit" size="small" onClick={handleCatalogRefresh}
                    disabled={catalogRefreshing}
                    startIcon={catalogRefreshing ? <CircularProgress size={12} color="inherit" /> : <RefreshIcon />}>
              Refresh columns
            </Button>
          }
        >
          {catalogMeta.message
            || 'No column metadata in the catalog for this table yet — click "Refresh columns" to fetch it from the source.'}
        </Alert>
      );
    }
    return (
      <Alert severity="info"
             action={<Button color="inherit" size="small" onClick={() => loadColumns(true)}>Load columns</Button>}>
        No columns loaded yet for this source.
      </Alert>
    );
  };

  const savedQueryDetailPending = sourceMode === 'saved_query' && !!savedQueryId
    && !savedQuery && !savedQueryError;

  const renderStep3 = () => (
    <Box>
      {(columnsLoading || savedQueryDetailPending) ? (
        <Box sx={{ py: 3, textAlign: 'center' }}><CircularProgress /></Box>
      ) : columns.length === 0 ? (
        renderColumnsEmptyState()
      ) : (
        <>
          {columnsError && (
            <Alert severity="warning" sx={{ mb: 1 }}
                   action={<Button color="inherit" size="small" onClick={() => loadColumns(true)}>Retry</Button>}>
              {columnsError} — showing the previously loaded columns.
            </Alert>
          )}
          {renderColumnsProvenance()}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 1 }}>
            <Typography variant="body2" color="text.secondary">
              {columns.filter(c => c.selected).length} of {columns.length} columns selected
            </Typography>
            <Button size="small" onClick={() => toggleAllColumns(true)}>Select All</Button>
            <Button size="small" onClick={() => toggleAllColumns(false)}>Deselect All</Button>
          </Box>
          <Box sx={{ overflowX: 'auto' }}>
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell padding="checkbox" sx={{ bgcolor: 'grey.50' }}>
                    <Checkbox
                      size="small"
                      indeterminate={columns.some(c => c.selected) && !columns.every(c => c.selected)}
                      checked={columns.every(c => c.selected)}
                      onChange={e => toggleAllColumns(e.target.checked)}
                      inputProps={{ 'aria-label': 'Select all columns' }}
                    />
                  </TableCell>
                  <TableCell sx={{ bgcolor: 'grey.50', fontWeight: 700, fontSize: 12 }}>Column</TableCell>
                  <TableCell sx={{ bgcolor: 'grey.50', fontWeight: 700, fontSize: 12 }}>Friendly Name</TableCell>
                  <TableCell sx={{ bgcolor: 'grey.50', fontWeight: 700, fontSize: 12 }}>Type</TableCell>
                  <TableCell sx={{ bgcolor: 'grey.50', fontWeight: 700, fontSize: 12 }}>Aggregation</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {clientPage(columns.map((col, idx) => ({ col, idx })), colPage, colPageSize).rows.map(({ col, idx }) => (
                  <TableRow key={col.physical_name} hover sx={{ opacity: col.selected ? 1 : 0.5 }}>
                    <TableCell padding="checkbox">
                      <Checkbox
                        size="small"
                        checked={col.selected}
                        onChange={e => updateColumn(idx, 'selected', e.target.checked)}
                        inputProps={{ 'aria-label': `Include column ${col.physical_name}` }}
                      />
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Tooltip title={col.description || ''} disableHoverListener={!col.description}>
                          <Typography sx={{ fontFamily: 'monospace', fontSize: 12 }}>{col.physical_name}</Typography>
                        </Tooltip>
                        <Chip
                          label={col.data_type}
                          size="small"
                          sx={{
                            height: 16,
                            fontSize: 9,
                            bgcolor: DATA_TYPE_COLORS[col.data_type] || '#757575',
                            color: '#fff',
                            '& .MuiChip-label': { px: 0.5 },
                          }}
                        />
                      </Box>
                    </TableCell>
                    <TableCell>
                      <TextField
                        size="small"
                        value={col.friendly_name}
                        onChange={e => updateColumn(idx, 'friendly_name', e.target.value)}
                        sx={{ minWidth: 160 }}
                        inputProps={{ 'aria-label': `Friendly name for ${col.physical_name}`,
                                      style: { fontSize: 12, padding: '4px 8px' } }}
                      />
                    </TableCell>
                    <TableCell>
                      <FormControl size="small" sx={{ minWidth: 110 }}>
                        <Select inputProps={{ 'aria-label': `Column type for ${col.friendly_name || col.physical_name || 'column'}` }}
                          value={col.column_type}
                          onChange={e => updateColumn(idx, 'column_type', e.target.value)}
                          sx={{ fontSize: 12 }}
                        >
                          {COLUMN_TYPES.map(t => (
                            <MenuItem key={t} value={t} sx={{ fontSize: 12 }}>{t}</MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </TableCell>
                    <TableCell>
                      <FormControl size="small" sx={{ minWidth: 100 }}>
                        <Select inputProps={{ 'aria-label': `Aggregation for ${col.friendly_name || col.physical_name || 'column'}` }}
                          value={col.aggregation}
                          onChange={e => updateColumn(idx, 'aggregation', e.target.value)}
                          disabled={col.column_type !== 'measure'}
                          sx={{ fontSize: 12 }}
                        >
                          {AGGREGATIONS.map(a => (
                            <MenuItem key={a || 'none'} value={a} sx={{ fontSize: 12 }}>
                              {a || 'NONE'}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Box>
          {/* Only when there is something to page: a list that fits the
              smallest page needs no pager, and the wizard's own Back / Next
              sit right below it. */}
          {columns.length > PAGE_SIZES[0] && (
            <ListPager paging={clientPage(columns, colPage, colPageSize).paging}
                       onPage={setColPage} onPageSize={setColPageSize}
                       testid="wizard-columns-pager" />
          )}
        </>
      )}
    </Box>
  );

  const renderStep4 = () => (
    <Stack spacing={2} sx={{ mt: 1 }}>
      <Alert severity="info" sx={{ mb: 1 }}>
        Joins are optional. They link this dataset to another source on a matching key column.
        You can also add relationships later from the Dataset Manager.
      </Alert>

      {joins.map((join, idx) => (
        <Paper key={idx} variant="outlined" sx={{ p: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1.5 }}>
            <Typography variant="subtitle2">Join #{idx + 1}</Typography>
            <IconButton aria-label="Delete" size="small" color="error" onClick={() => removeJoin(idx)}>
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Box>
          <Stack spacing={1.5}>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <FormControl size="small" sx={{ flex: 1 }}>
                <InputLabel id="sel-datasetcreationwizard-connection-2">Connection</InputLabel>
                <Select labelId="sel-datasetcreationwizard-connection-2"
                  value={join.connection_id}
                  label="Connection"
                  onChange={e => updateJoin(idx, 'connection_id', e.target.value)}
                >
                  <MenuItem value="">— Select —</MenuItem>
                  {connections.map(c => (
                    <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>
                  ))}
                </Select>
              </FormControl>
              <FormControl size="small" sx={{ minWidth: 100 }}>
                <InputLabel id="sel-datasetcreationwizard-join-type">Join Type</InputLabel>
                <Select labelId="sel-datasetcreationwizard-join-type"
                  value={join.join_type}
                  label="Join Type"
                  onChange={e => updateJoin(idx, 'join_type', e.target.value)}
                >
                  {JOIN_TYPES.map(t => (
                    <MenuItem key={t} value={t}>{t.toUpperCase()}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Box>

            <FormControl fullWidth size="small">
              <InputLabel id="sel-datasetcreationwizard-secondary-table">Secondary Table</InputLabel>
              <Select labelId="sel-datasetcreationwizard-secondary-table"
                value={join.table_name}
                label="Secondary Table"
                onChange={e => updateJoin(idx, 'table_name', e.target.value)}
                disabled={!join.connection_id}
              >
                <MenuItem value="">— Select Table —</MenuItem>
                {(joinTables[join.connection_id as number] || []).map((t: any) => (
                  // Value stays FULLY QUALIFIED (the backend has to resolve
                  // it); only the label is shortened.
                  <MenuItem key={t.name} value={t.name} title={t.name}>
                    {String(t.name).split('.').pop() || t.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            {/* 2026-09-04 -- both keys are COLUMNS of tables already
                chosen above, so they are picked, not typed.  freeSolo is
                kept deliberately: when a source cannot answer for its
                schema the author must still be able to name the column
                rather than be blocked by an empty dropdown -- but the
                normal case is a list. */}
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <JoinKeyPicker
                label="Primary Key Column"
                value={join.left_key}
                onChange={v => updateJoin(idx, 'left_key', v)}
                columns={joinColumns[colsKeyFor(sourceConnectionId, primaryTableName)] || []}
                loading={!!joinColsLoading[colsKeyFor(sourceConnectionId, primaryTableName)]}
                onOpen={() => ensureJoinColumns(sourceConnectionId, primaryTableName)}
                emptyHint={primaryTableName
                  ? 'No columns could be read for the primary table'
                  : 'Pick the primary table on the Source step first'}
              />
              <Typography variant="body2" color="text.secondary">=</Typography>
              <JoinKeyPicker
                label="Secondary Key Column"
                value={join.right_key}
                onChange={v => updateJoin(idx, 'right_key', v)}
                columns={joinColumns[colsKeyFor(join.connection_id, join.table_name)] || []}
                loading={!!joinColsLoading[colsKeyFor(join.connection_id, join.table_name)]}
                onOpen={() => ensureJoinColumns(join.connection_id, join.table_name)}
                emptyHint={join.table_name
                  ? 'No columns could be read for this table'
                  : 'Pick the secondary table first'}
              />
            </Box>
          </Stack>
        </Paper>
      ))}

      <Button
        variant="outlined"
        startIcon={<AddIcon />}
        onClick={addJoin}
        size="small"
        sx={{ alignSelf: 'flex-start' }}
      >
        Add Secondary Source
      </Button>
    </Stack>
  );

  const renderStep5 = () => {
    const selectedCols = columns.filter(c => c.selected);
    const dimensions = selectedCols.filter(c => c.column_type === 'dimension').length;
    const measures = selectedCols.filter(c => c.column_type === 'measure').length;
    const details = selectedCols.filter(c => ['detail', 'kpi'].includes(c.column_type)).length;
    const validJoins = joins.filter(j => j.connection_id && j.table_name && j.left_key && j.right_key);

    return (
      <Stack spacing={2} sx={{ mt: 1 }}>
        <Alert severity="success">
          Ready to create your dataset. Review the summary below, then click Create.
        </Alert>

        {/* Summary cards */}
        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1.5 }}>
          <Paper variant="outlined" sx={{ p: 1.5 }}>
            <Typography variant="caption" color="text.secondary">Source</Typography>
            <Typography variant="body2" fontWeight={600}>
              {sourceMode === 'saved_query'
                ? (savedQuery?.name || `Saved query #${savedQueryId}`)
                : (connections.find(c => c.id === sourceConnectionId)?.name || '—')}
            </Typography>
            <Typography variant="caption">
              {sourceMode === 'saved_query'
                ? `Saved query on ${connections.find(c => c.id === sourceConnectionId)?.name || 'its own connection'}`
                : sourceMode === 'sql' ? 'Custom SQL' : (
                  selectedTable.replace('__registered__:', '')
                )}
            </Typography>
          </Paper>
          <Paper variant="outlined" sx={{ p: 1.5 }}>
            <Typography variant="caption" color="text.secondary">Columns</Typography>
            <Typography variant="body2" fontWeight={600}>{selectedCols.length} selected</Typography>
            <Typography variant="caption">
              {dimensions} dim · {measures} measure · {details} other
            </Typography>
          </Paper>
          <Paper variant="outlined" sx={{ p: 1.5 }}>
            <Typography variant="caption" color="text.secondary">Dataset</Typography>
            <Typography variant="body2" fontWeight={600}>{name}</Typography>
            <Typography variant="caption">{subject}</Typography>
          </Paper>
          <Paper variant="outlined" sx={{ p: 1.5 }}>
            <Typography variant="caption" color="text.secondary">Joins</Typography>
            <Typography variant="body2" fontWeight={600}>{validJoins.length} configured</Typography>
            {validJoins.length > 0 && (
              <Typography variant="caption">
                {validJoins.map(j => j.table_name).join(', ')}
              </Typography>
            )}
          </Paper>
        </Box>

        {/* Editable name/description for last-minute changes */}
        <Divider />
        <TextField
          label="Name"
          value={name}
          onChange={e => setName(e.target.value)}
          fullWidth size="small"
        />
        <TextField
          label="Description"
          value={description}
          onChange={e => setDescription(e.target.value)}
          fullWidth size="small" multiline rows={2}
        />
      </Stack>
    );
  };

  // ── Render ────────────────────────────────────────────────────────────────

  const stepContent: Record<number, () => React.ReactNode> = {
    0: renderStep1,
    1: renderStep2,
    2: renderStep3,
    3: renderStep4,
    4: renderStep5,
  };

  const canProceed = (): boolean => {
    if (step === 0) return !!(name.trim() && subject.trim());
    if (step === 1) {
      if (sourceMode === 'saved_query') return !!savedQueryId && !savedQueryLoading;
      if (!sourceConnectionId) return false;
      if (sourceMode === 'table') return !!selectedTable;
      return !!customSql.trim();
    }
    return true;
  };

  return (
    <AppDialog open={open}
      onClose={handleDialogClose}
      size="md"
      title={<>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="h6">Create Dataset</Typography>
          <Typography variant="caption" color="text.secondary">
            Step {step + 1} of {STEPS.length}
          </Typography>
        </Box>
      </>}
      actions={<>
        <Tooltip describeChild
                 title={isDirty ? 'Your entries are kept as a draft and restored next time you open this wizard.' : ''}>
          <Button onClick={handleCancelClick}>Cancel</Button>
        </Tooltip>
        {isDirty && (
          <Typography variant="caption" color="text.secondary">
            Draft auto-saved
          </Typography>
        )}

        {step > 0 && (
          <Button onClick={handleBack}>Back</Button>
        )}

        {/* Skip button for optional steps */}
        {step === 3 && (
          <Tooltip title="Skip optional joins and go to Review">
            <Button
              variant="outlined"
              startIcon={<SkipIcon />}
              onClick={() => setStep(4)}
            >
              Skip Joins
            </Button>
          </Tooltip>
        )}

        <Box sx={{ flexGrow: 1 }} />

        {step < STEPS.length - 1 ? (
          <Button
            variant="contained"
            onClick={handleNext}
            disabled={!canProceed()}
          >
            Next
          </Button>
        ) : (
          <Button
            variant="contained"
            color="success"
            onClick={handleCreate}
            disabled={saving || !name.trim() || !subject.trim()}
            startIcon={saving ? <CircularProgress size={16} color="inherit" /> : undefined}
          >
            {saving ? 'Creating...' : 'Create Dataset'}
          </Button>
        )}
      </>}>
        {/* Stepper */}
        <Stepper activeStep={step} sx={{ mb: 3 }} alternativeLabel>
          {STEPS.map((label, idx) => (
            <Step key={label} completed={idx < step}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        {/* Restored-draft notice */}
        {draftRestored && (
          <Alert
            severity="info" sx={{ mb: 2 }}
            onClose={() => setDraftRestored(false)}
            action={
              <Stack direction="row" spacing={1}>
                <Button color="inherit" size="small" onClick={handleStartFresh}>Start fresh</Button>
              </Stack>
            }
          >
            Restored your in-progress dataset draft — continue where you left off.
          </Alert>
        )}

        {/* Global error */}
        {globalError && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setGlobalError('')}>
            {globalError}
          </Alert>
        )}

        {/* Step content */}
        {(stepContent[step] || renderStep1)()}
    </AppDialog>
  );
};

export default DatasetCreationWizard;
