import React, { useState, useEffect, useMemo } from 'react';
import {
  Box, Typography, Button, Paper, Chip, CircularProgress, Skeleton,
  Dialog, Autocomplete,
  TextField, MenuItem, InputAdornment, IconButton, Tooltip,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TableSortLabel, TablePagination, ToggleButton, ToggleButtonGroup,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Refresh as RefreshIcon, PlayArrow as PlayIcon, Visibility as ViewIcon,
  Delete as DeleteIcon, Search as SearchIcon, Clear as ClearIcon,
  ViewList as ListIcon, GridView as GridIcon, Edit as EditIcon,
  History as HistoryIcon, Share as ShareIcon, LockOpen as SharedIcon,
  Star as StarIcon, StarBorder as StarBorderIcon,
  FolderOpen as FolderIcon, Label as TagIcon,
  CloudUpload as PublishApiIcon,
} from '@mui/icons-material';
import QueryVersionHistory from './QueryVersionHistory';
import PublishViewDialog from './PublishViewDialog';
import RowActions from './common/RowActions';
import { useNavigate } from 'react-router-dom';
import { useNotifications } from '../context/NotificationContext';
import { useAuth } from '../context/AuthContext';
import api, { ApiError } from '../services/api';
import { toArray } from '../utils/toArray';

const fmtDate = (s) => s ? new Date(s).toLocaleString() : '—';
const fmtDateShort = (s) => s ? new Date(s).toLocaleDateString() : '—';

const ROWS_PER_PAGE_OPTIONS = [25, 50, 100];

const SavedQueries = () => {
  const [queries, setQueries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedQuery, setSelectedQuery] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [versionTarget, setVersionTarget] = useState<any>(null);

  // Search / sort / pagination
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState('created_at');
  const [sortDir, setSortDir] = useState('desc');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);
  const [viewMode, setViewMode] = useState('table'); // 'table' | 'grid'
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [folderFilter, setFolderFilter] = useState('');
  const [tagFilter, setTagFilter] = useState('');
  const [allFolders, setAllFolders] = useState<string[]>([]);
  const [allTags, setAllTags] = useState<string[]>([]);

  // Phase 85C-1: Publish as API state
  const [publishDialogOpen, setPublishDialogOpen] = useState(false);
  const [publishQueryId, setPublishQueryId] = useState<number | null>(null);
  const [publishQueryName, setPublishQueryName] = useState('');

  const { addNotification } = useNotifications();
  const navigate = useNavigate();
  const { user } = useAuth();

  const canToggleShare = (query) =>
    user && query.created_by === user.username && ['admin', 'analyst', 'super_admin'].includes(user.role);
  // The backend mints / revokes a public link for the query's OWNER or an
  // admin only (queries_api._require_query_own); offering it to anyone else
  // produced a 403 on click.
  const canMintLink = (query) =>
    !!user && (query.created_by === user.username
      || (user as any).role === 'admin' || (user as any).role === 'super_admin');

  useEffect(() => { loadQueries(); loadOrganization(); }, []);

  const loadOrganization = async () => {
    const [folders, tags] = await Promise.all([api.listQueryFolders(), api.listQueryTags()]);
    setAllFolders(folders);
    setAllTags(tags);
  };
  // Reset page when search changes
  useEffect(() => { setPage(0); }, [search]);

  const loadQueries = async () => {
    try {
      setLoading(true);
      const data = await api.listQueries({ active_only: true });
      setQueries(toArray(data));  // BF-428P
    } catch (_err) {
      const error = _err as Error;
      addNotification({ type: 'error', title: 'Error Loading Queries', message: error.message });
    } finally {
      setLoading(false);
    }
  };

  const executeQuery = async (queryId, queryName, connectionId?) => {
    try {
      const payload: any = { query_id: queryId, output_format: 'csv' };
      if (connectionId) payload.connection_id = connectionId;
      const response = await api.executeQuery(payload);
      addNotification({ type: 'success', title: 'Query Started', message: `"${queryName}" — ID: ${response.execution_id.substring(0, 8)}...` });
    } catch (_err) {
      const error = _err as any;
      const isTokenExpired = error instanceof ApiError && error.errorCode === 'TOKEN_EXPIRED';
      addNotification({
        type: 'error',
        title: isTokenExpired ? 'Session Token Expired' : 'Execution Error',
        message: error.message,
        ...(isTokenExpired ? { action: { label: 'Update Connection', href: '/connections' } } : {}),
      });
    }
  };

  const handleEdit = (query) => {
    // The query builder is what consumes `loadQuery` (BusinessQueryTabManager).
    // '/' is the home portal, which ignores it: "Edit" landed on the home
    // page with nothing opened, since the first commit (2026-10-02).
    navigate('/smart-query', { state: { loadQuery: query } });
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.deleteQuery(deleteTarget.id);
      addNotification({ type: 'success', title: 'Query Deleted', message: `"${deleteTarget.name}" deleted` });
      loadQueries();
    } catch (_err) {
      const error = _err as Error;
      addNotification({ type: 'error', title: 'Delete Error', message: error.message });
    }
    setDeleteTarget(null);
  };

  const handleShare = async (queryId: number | string) => {
    try {
      const share = await api.shareQuery(queryId, {});
      const url = `${window.location.origin}/shared/${share.token}`;
      await navigator.clipboard.writeText(url);
      addNotification({ type: 'success', title: 'Share Link Copied', message: url });
    } catch (_err) {
      addNotification({ type: 'error', title: 'Share Error', message: 'Could not create share link' });
    }
  };

  const handleToggleShared = async (query) => {
    try {
      const updated = await api.patchQuery(query.id, { is_shared: !query.is_shared });
      setQueries(prev => prev.map(q => q.id === updated.id ? updated : q));
      addNotification({
        type: 'success',
        title: updated.is_shared ? 'Query Shared' : 'Query Unshared',
        message: `"${query.name}" is now ${updated.is_shared ? 'shared' : 'private'}`,
      });
    } catch (_err) {
      addNotification({ type: 'error', title: 'Error', message: 'Could not toggle sharing' });
    }
  };

  const handleToggleFavorite = async (queryId: number | string) => {
    try {
      const updated = await api.toggleFavorite(queryId);
      setQueries(prev => prev.map(q => q.id === updated.id ? updated : q));
    } catch (_err) {
      addNotification({ type: 'error', title: 'Error', message: 'Could not toggle favorite' });
    }
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
    setPage(0);
  };

  // Filter + sort + paginate
  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    let rows = q
      ? queries.filter(r =>
          r.name.toLowerCase().includes(q) ||
          (r.description || '').toLowerCase().includes(q)
        )
      : queries;

    if (showFavoritesOnly) {
      rows = rows.filter(r => r.is_favorite);
    }
    if (folderFilter) {
      rows = rows.filter(r => r.folder === folderFilter);
    }
    if (tagFilter) {
      rows = rows.filter(r => (r.tags || []).includes(tagFilter));
    }

    rows = [...rows].sort((a, b) => {
      // Favorites always sort first
      if (a.is_favorite && !b.is_favorite) return -1;
      if (!a.is_favorite && b.is_favorite) return 1;
      let av = a[sortField] ?? '';
      let bv = b[sortField] ?? '';
      if (sortField === 'execution_count') { av = Number(av); bv = Number(bv); }
      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
    return rows;
  }, [queries, search, sortField, sortDir, showFavoritesOnly, folderFilter, tagFilter]);

  const paginated = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  const SortHeader = ({ field, label, align = 'left' }: { field: string; label: string; align?: 'left' | 'right' | 'center' | 'inherit' | 'justify' }) => (
    <TableCell align={align} sx={{ fontWeight: 700, whiteSpace: 'nowrap', bgcolor: 'grey.50' }}>
      <TableSortLabel
        active={sortField === field}
        direction={sortField === field ? (sortDir as 'asc' | 'desc') : 'asc'}
        onClick={() => handleSort(field)}
      >
        {label}
      </TableSortLabel>
    </TableCell>
  );

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h5">Saved Queries</Typography>
          <Typography variant="subtitle2" color="text.secondary">
            {loading ? 'Loading…' : `${filtered.length} of ${queries.length} queries`}
          </Typography>
        </Box>
        <Button variant="outlined" startIcon={<RefreshIcon />} onClick={loadQueries} disabled={loading}>
          Refresh
        </Button>
      </Box>

      {/* Toolbar: Search + view toggle */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
        <TextField
          size="small"
          placeholder="Search by name or description…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          sx={{ flex: 1, maxWidth: 480 }}
          InputProps={{
            startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 18 }} /></InputAdornment>,
            endAdornment: search
              ? <InputAdornment position="end">
                  <IconButton aria-label="Clear" size="small" onClick={() => setSearch('')}><ClearIcon sx={{ fontSize: 16 }} /></IconButton>
                </InputAdornment>
              : null,
          }}
        />
        <Chip
          icon={showFavoritesOnly ? <StarIcon sx={{ fontSize: '16px !important' }} /> : <StarBorderIcon sx={{ fontSize: '16px !important' }} />}
          label="Favorites"
          variant={showFavoritesOnly ? 'filled' : 'outlined'}
          color={showFavoritesOnly ? 'warning' : 'default'}
          onClick={() => { setShowFavoritesOnly(v => !v); setPage(0); }}
          sx={{ cursor: 'pointer' }}
        />
        {allFolders.length > 0 && (
          <TextField
            select size="small" label="Folder" value={folderFilter}
            onChange={e => { setFolderFilter(e.target.value); setPage(0); }}
            sx={{ minWidth: 130 }}
            InputProps={{ startAdornment: <InputAdornment position="start"><FolderIcon sx={{ fontSize: 16 }} /></InputAdornment> }}
          >
            <MenuItem value="">All Folders</MenuItem>
            {allFolders.map(f => <MenuItem key={f} value={f}>{f}</MenuItem>)}
          </TextField>
        )}
        {allTags.length > 0 && (
          <TextField
            select size="small" label="Tag" value={tagFilter}
            onChange={e => { setTagFilter(e.target.value); setPage(0); }}
            sx={{ minWidth: 120 }}
            InputProps={{ startAdornment: <InputAdornment position="start"><TagIcon sx={{ fontSize: 16 }} /></InputAdornment> }}
          >
            <MenuItem value="">All Tags</MenuItem>
            {allTags.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
          </TextField>
        )}
        <TextField
          select size="small" label="Sort by" value={sortField}
          onChange={e => { setSortField(e.target.value); setPage(0); }}
          sx={{ minWidth: 160 }}
        >
          <MenuItem value="created_at">Date Created</MenuItem>
          <MenuItem value="updated_at">Last Modified</MenuItem>
          <MenuItem value="last_executed_at">Last Executed</MenuItem>
          <MenuItem value="execution_count">Run Count</MenuItem>
          <MenuItem value="name">Name</MenuItem>
        </TextField>
        <ToggleButtonGroup
          size="small"
          value={viewMode}
          exclusive
          onChange={(_, v) => v && setViewMode(v)}
        >
          <ToggleButton value="table" aria-label="Table view"><Tooltip title="Table view"><ListIcon /></Tooltip></ToggleButton>
          <ToggleButton value="grid" aria-label="Card view"><Tooltip title="Card view"><GridIcon /></Tooltip></ToggleButton>
        </ToggleButtonGroup>
      </Box>

      {/* Content */}
      {loading ? (
        <Box sx={{ p: 2 }}>
          {[1, 2, 3, 4, 5].map(i => (
            <Skeleton key={i} variant="rounded" height={44} sx={{ mb: 1, borderRadius: 1 }} />
          ))}
        </Box>
      ) : queries.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>No saved queries</Typography>
          <Typography color="text.secondary">Create and save queries in the Query Builder</Typography>
        </Paper>
      ) : filtered.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>No results for "{search}"</Typography>
          <Button onClick={() => setSearch('')}>Clear search</Button>
        </Paper>
      ) : viewMode === 'table' ? (
        /* ── TABLE VIEW (best for 1000+ queries) ── */
        <TableContainer component={Paper} variant="outlined">
          <Table size="small" stickyHeader>
            <TableHead>
              <TableRow>
                <SortHeader field="name" label="Name" />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50' }}>Description</TableCell>
                <SortHeader field="execution_count" label="Runs" align="right" />
                <SortHeader field="created_at" label="Created" />
                <SortHeader field="last_executed_at" label="Last Run" />
                <TableCell sx={{ fontWeight: 700, bgcolor: 'grey.50', whiteSpace: 'nowrap' }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginated.map(query => (
                <TableRow
                  key={query.id}
                  hover
                  sx={{ '&:last-child td': { border: 0 } }}
                >
                  <TableCell sx={{ fontWeight: 600, maxWidth: 280 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, flexWrap: 'wrap' }}>
                      <Typography variant="body2" fontWeight={600} noWrap>{query.name}</Typography>
                      {query.is_shared && (
                        <Chip icon={<SharedIcon sx={{ fontSize: '14px !important' }} />} label="Shared" size="small" color="info" variant="outlined" sx={{ height: 20, '& .MuiChip-label': { px: 0.5, fontSize: '0.7rem' } }} />
                      )}
                      {query.folder && (
                        <Chip icon={<FolderIcon sx={{ fontSize: '12px !important' }} />} label={query.folder} size="small" variant="outlined"
                          sx={{ height: 18, '& .MuiChip-label': { px: 0.4, fontSize: '0.65rem' } }}
                          onClick={() => { setFolderFilter(query.folder); setPage(0); }} />
                      )}
                      {(query.tags || []).map((t: string) => (
                        <Chip key={t} icon={<TagIcon sx={{ fontSize: '12px !important' }} />} label={t} size="small" color="secondary" variant="outlined"
                          sx={{ height: 18, '& .MuiChip-label': { px: 0.4, fontSize: '0.65rem' } }}
                          onClick={() => { setTagFilter(t); setPage(0); }} />
                      ))}
                    </Box>
                  </TableCell>
                  <TableCell sx={{ maxWidth: 320 }}>
                    <Typography variant="body2" color="text.secondary" noWrap>
                      {query.description || '—'}
                    </Typography>
                  </TableCell>
                  <TableCell align="right">
                    <Chip label={query.execution_count} size="small" variant="outlined" />
                  </TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>
                    <Typography variant="caption">{fmtDateShort(query.created_at)}</Typography>
                  </TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>
                    <Typography variant="caption">{fmtDateShort(query.last_executed_at)}</Typography>
                  </TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap' }}>
                    {/* 2026-09-24 (screen walk): this row carried NINE unlabelled
                        icon buttons, among them two different "share" icons side
                        by side (one toggles the read grant for other users, the
                        other mints a public link) and a cloud that meant "publish
                        as API".  The favourite star stays visible because it is
                        a state indicator; Run and Edit stay one click away; the
                        rest is a labelled menu (common/RowActions). */}
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}>
                      <Tooltip title={query.is_favorite ? 'Remove from favorites' : 'Add to favorites'}>
                        <IconButton size="small" onClick={() => handleToggleFavorite(query.id)}
                          aria-label={`${query.is_favorite ? 'Remove from favorites' : 'Add to favorites'} — ${query.name}`}
                          sx={{ color: query.is_favorite ? 'warning.main' : 'action.disabled' }}>
                          {query.is_favorite ? <StarIcon fontSize="small" /> : <StarBorderIcon fontSize="small" />}
                        </IconButton>
                      </Tooltip>
                      <RowActions rowName={query.name}
                        primary={[
                          { label: 'Run', icon: <PlayIcon fontSize="small" color="success" />,
                            onClick: () => executeQuery(query.id, query.name, query.query_config?.connection_id) },
                          { label: 'Edit', icon: <EditIcon fontSize="small" color="primary" />,
                            onClick: () => handleEdit(query) },
                        ]}
                        more={[
                          { label: 'View details', icon: <ViewIcon fontSize="small" />,
                            description: 'Run count, dates and the stored query configuration',
                            onClick: () => setSelectedQuery(query) },
                          { label: 'Version history', icon: <HistoryIcon fontSize="small" />,
                            description: 'Earlier versions of this query; restore one',
                            onClick: () => setVersionTarget(query) },
                          ...(canToggleShare(query) ? [{
                            label: query.is_shared ? 'Stop sharing with users' : 'Share with users',
                            icon: query.is_shared ? <SharedIcon fontSize="small" color="info" /> : <ShareIcon fontSize="small" />,
                            dividerBefore: true,
                            description: query.is_shared
                              ? 'Other signed-in users can see this query now; make it yours only'
                              : 'Let other signed-in users see this query (read-only)',
                            onClick: () => handleToggleShared(query) }] : []),
                          { label: 'Copy share link', icon: <ShareIcon fontSize="small" />,
                            dividerBefore: !canToggleShare(query),
                            description: 'Mint a public link to this query and copy it to the clipboard',
                            disabled: !canMintLink(query),
                            disabledReason: "Only the query's owner or an admin can create a share link",
                            onClick: () => handleShare(query.id) },
                          { label: 'Publish as API', icon: <PublishApiIcon fontSize="small" />, dividerBefore: true,
                            description: 'Expose this query as a Published View endpoint',
                            onClick: () => {
                              setPublishQueryId(query.id);
                              setPublishQueryName(query.name);
                              setPublishDialogOpen(true);
                            } },
                          { label: 'Delete', icon: <DeleteIcon fontSize="small" />, danger: true,
                            onClick: () => setDeleteTarget(query) },
                        ]} />
                    </Box>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <TablePagination
            component="div"
            count={filtered.length}
            page={page}
            onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          />
        </TableContainer>
      ) : (
        /* ── GRID VIEW ── */
        <>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 2 }}>
            {paginated.map(query => (
              <Paper key={query.id} variant="outlined" sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <IconButton aria-label="Favorite" size="small" onClick={() => handleToggleFavorite(query.id)}
                    sx={{ color: query.is_favorite ? 'warning.main' : 'action.disabled', mr: 0.5, mt: -0.5 }}>
                    {query.is_favorite ? <StarIcon fontSize="small" /> : <StarBorderIcon fontSize="small" />}
                  </IconButton>
                  <Typography variant="subtitle2" fontWeight={700} sx={{ flexGrow: 1, mr: 1 }} noWrap>
                    {query.name}
                  </Typography>
                  {query.is_shared && (
                    <Chip icon={<SharedIcon sx={{ fontSize: '14px !important' }} />} label="Shared" size="small" color="info" variant="outlined" sx={{ height: 20, '& .MuiChip-label': { px: 0.5, fontSize: '0.7rem' }, mr: 0.5 }} />
                  )}
                  <Chip label={`${query.execution_count} runs`} size="small" variant="outlined" />
                </Box>
                {query.description && (
                  <Typography variant="body2" color="text.secondary" sx={{
                    display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden'
                  }}>
                    {query.description}
                  </Typography>
                )}
                <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', mt: 'auto', pt: 0.5 }}>
                  <Typography variant="caption" color="text.disabled">Created: {fmtDateShort(query.created_at)}</Typography>
                  {query.last_executed_at && (
                    <Typography variant="caption" color="text.disabled">Run: {fmtDateShort(query.last_executed_at)}</Typography>
                  )}
                </Box>
                <Box sx={{ display: 'flex', gap: 0.5, pt: 0.5, borderTop: 1, borderColor: 'divider' }}>
                  <Button size="small" variant="contained" startIcon={<PlayIcon />} onClick={() => executeQuery(query.id, query.name, query.query_config?.connection_id)}>
                    Execute
                  </Button>
                  <Button size="small" startIcon={<EditIcon />} onClick={() => handleEdit(query)}>
                    Edit
                  </Button>
                  <Button size="small" startIcon={<ViewIcon />} onClick={() => setSelectedQuery(query)}>
                    View
                  </Button>
                  <Box sx={{ flexGrow: 1 }} />
                  <Tooltip title="Version History">
                    <IconButton size="small" onClick={() => setVersionTarget(query)}>
                      <HistoryIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  {canToggleShare(query) && (
                    <Tooltip title={query.is_shared ? 'Unshare query' : 'Share query'}>
                      <IconButton size="small" onClick={() => handleToggleShared(query)}
                        sx={{ color: query.is_shared ? 'info.main' : 'action.disabled' }}>
                        {query.is_shared ? <SharedIcon fontSize="small" /> : <ShareIcon fontSize="small" />}
                      </IconButton>
                    </Tooltip>
                  )}
                  <Tooltip title="Share (copy link)">
                    <IconButton size="small" onClick={() => handleShare(query.id)}>
                      <ShareIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Delete">
                    <IconButton size="small" color="error" onClick={() => setDeleteTarget(query)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Box>
              </Paper>
            ))}
          </Box>
          <TablePagination
            component="div"
            count={filtered.length}
            page={page}
            onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          />
        </>
      )}

      {/* Details Dialog */}
      <AppDialog open={!!selectedQuery} onClose={() => setSelectedQuery(null)} size="md"
        title={selectedQuery?.name}
        actions={selectedQuery && <>
              <Button onClick={() => setSelectedQuery(null)}>Close</Button>
              <Button startIcon={<EditIcon />} onClick={() => { handleEdit(selectedQuery); setSelectedQuery(null); }}>
                Edit in Builder
              </Button>
              <Button variant="contained" onClick={() => { executeQuery(selectedQuery.id, selectedQuery.name, selectedQuery.query_config?.connection_id); setSelectedQuery(null); }}>
                Execute Query
              </Button>
        </>}>
        {selectedQuery && (
          <>
              {selectedQuery.description && (
                <Typography color="text.secondary" sx={{ mb: 2 }}>{selectedQuery.description}</Typography>
              )}
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5, mb: 3 }}>
                {[
                  ['Query ID', selectedQuery.id],
                  ['Executions', selectedQuery.execution_count],
                  ['Created', fmtDate(selectedQuery.created_at)],
                  ['Updated', fmtDate(selectedQuery.updated_at)],
                  selectedQuery.last_executed_at ? ['Last Executed', fmtDate(selectedQuery.last_executed_at)] : null,
                ].filter(Boolean).map(([k, v]) => (
                  <Box key={k}>
                    <Typography variant="caption" color="text.secondary">{k}</Typography>
                    <Typography variant="body2" fontWeight={500}>{v}</Typography>
                  </Box>
                ))}
              </Box>
              <Typography variant="subtitle2" gutterBottom>Query Configuration</Typography>
              <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50', overflow: 'auto', maxHeight: 400 }}>
                <pre style={{ margin: 0, fontSize: '0.8125rem', fontFamily: 'monospace' }}>
                  {JSON.stringify(selectedQuery.query_config, null, 2)}
                </pre>
              </Paper>
          </>
        )}
      </AppDialog>

      {/* Delete Confirmation */}
      <AppDialog open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        size="xs"
        title="Delete Query"
        actions={<>
          <Button onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button variant="contained" color="error" onClick={handleDelete}>Delete</Button>
        </>}>
          <Typography>Delete <strong>{deleteTarget?.name}</strong>? It is switched off, not erased -- an admin or its owner can switch it back on under Admin -&gt; Switched off.</Typography>
      </AppDialog>

      {/* Version History */}
      <QueryVersionHistory
        queryId={versionTarget?.id}
        queryName={versionTarget?.name || ''}
        open={Boolean(versionTarget)}
        onClose={() => setVersionTarget(null)}
        onRestored={loadQueries}
      />

      {/* Phase 85C-1: Publish as API Dialog */}
      {publishDialogOpen && publishQueryId !== null && (
        <PublishViewDialog
          open={publishDialogOpen}
          onClose={() => { setPublishDialogOpen(false); setPublishQueryId(null); setPublishQueryName(''); }}
          queryId={publishQueryId}
          queryName={publishQueryName}
          columns={[]}
        />
      )}
    </Box>
  );
};

export default SavedQueries;
