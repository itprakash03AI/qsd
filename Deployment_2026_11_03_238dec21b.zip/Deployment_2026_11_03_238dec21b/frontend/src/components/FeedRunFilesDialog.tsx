/**
 * FeedRunFilesDialog — a fan-out run's per-file children, with selective
 * reset ("re-run file 738 of 1,000") — 2026-09-03.
 *
 * GET  /api/feed-runs/{id}/files        — children + status counts
 * POST /api/feed-runs/{id}/files/reset  — reset chosen children to
 *      'pending'; the parent re-run then executes ONLY pending children.
 *
 * Rules honoured here:
 *   * a FAILED load never renders like "no children" — the two are
 *     opposite findings;
 *   * the confirm names exactly which partitions will be reset before
 *     anything is sent;
 *   * the response is PER-ITEM (reset / refused_not_terminal /
 *     lost_race) and is rendered per item — a "done" that hid a racing
 *     child would hide exactly what the operator needed;
 *   * resetting a completed/cancelled child requires NAMING it — the
 *     "reset all failed" shortcut sends partition_keys: null, which the
 *     backend scopes to failed children only.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, CircularProgress, Stack, Table, TableBody,
  TableCell, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Replay as ResetIcon, Refresh as RefreshIcon,
  PlayArrow as RerunIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type {
  FeedRunFilesResponse, FeedRunFilesResetResponse,
} from '../services/api/feedOperations';
import ListPager, { clientPage } from './common/ListPager';

export interface FilesRunRef { id: number; feed_name?: string | null; }

const TERMINAL = new Set(['completed', 'failed', 'cancelled']);

const STATUS_COLOR: Record<string, 'success' | 'error' | 'warning' | 'info' | 'default'> = {
  completed: 'success', failed: 'error', running: 'info',
  pending: 'warning', cancelled: 'default',
};

type LoadState =
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; data: FeedRunFilesResponse };

type ResetState =
  | { phase: 'idle' }
  /** keys === null means "every failed child" (the backend's scope). */
  | { phase: 'confirm'; keys: string[] | null }
  | { phase: 'busy' }
  | { phase: 'done'; result: FeedRunFilesResetResponse };

const FeedRunFilesDialog: React.FC<{
  run: FilesRunRef | null;
  onClose: () => void;
  /** Called after a rerun was triggered so the caller can refresh. */
  onRerun?: () => void;
}> = ({ run, onClose, onRerun }) => {
  const [load, setLoad] = useState<LoadState>({ phase: 'loading' });
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [reset, setReset] = useState<ResetState>({ phase: 'idle' });
  const [resetReason, setResetReason] = useState('');
  const [rerunMsg, setRerunMsg] = useState<string | null>(null);
  const [rerunErr, setRerunErr] = useState<string | null>(null);
  const [resetError, setResetError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const loadFiles = async (runId: number) => {
    setLoad({ phase: 'loading' });
    try {
      const data = await api.listFeedRunFiles(runId);
      setLoad({ phase: 'ready', data });
    } catch (e: any) {
      setLoad({ phase: 'error', message: e?.message || String(e) });
    }
  };

  useEffect(() => {
    if (run != null) {
      setSelected(new Set());
      setReset({ phase: 'idle' });
      setResetReason('');
      setRerunMsg(null);
      setRerunErr(null);
      setResetError(null);
      setPage(1);
      void loadFiles(run.id);
    }
  }, [run?.id]);

  const children = load.phase === 'ready' ? load.data.children : [];
  const pg = clientPage(children, page, pageSize);
  const failedCount = useMemo(
    () => children.filter(c => c.status === 'failed').length, [children]);

  const toggle = (key: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  const doReset = async (keys: string[] | null) => {
    if (!run) return;
    setReset({ phase: 'busy' });
    try {
      const result = await api.resetFeedRunFiles(run.id, {
        partition_keys: keys,
        ...(resetReason.trim() ? { reason: resetReason.trim() } : {}),
      });
      setReset({ phase: 'done', result });
      setSelected(new Set());
      void loadFiles(run.id);
    } catch (e: any) {
      setReset({ phase: 'idle' });
      setResetError(e?.message || String(e));
    }
  };

  const doRerun = async () => {
    if (!run) return;
    setRerunErr(null);
    try {
      await api.rerunFeedRun(run.id);
      setRerunMsg('Re-run triggered — only pending (reset) children will '
        + 'execute; the parent status stays derived from its children.');
      onRerun?.();
    } catch (e: any) {
      setRerunErr(e?.message || String(e));
    }
  };

  const confirmNamed: string[] | null | undefined =
    reset.phase === 'confirm' ? reset.keys : undefined;

  return (
    <AppDialog open={run != null}
      onClose={onClose}
      size="md"
      title={<>Files of run #{run?.id}{run?.feed_name ? ` — ${run.feed_name}` : ''}</>}
      actions={<>
        <Button onClick={onClose}>Close</Button>
        {load.phase === 'ready' && children.length > 0
          && reset.phase !== 'confirm' && (
          <>
            <Button
              startIcon={reset.phase === 'busy'
                ? <CircularProgress size={14} /> : <ResetIcon />}
              disabled={reset.phase === 'busy' || failedCount === 0}
              onClick={() => setReset({ phase: 'confirm', keys: null })}
              data-testid="run-files-reset-all-failed"
            >
              Reset all failed ({failedCount})
            </Button>
            <Button
              variant="contained"
              startIcon={reset.phase === 'busy'
                ? <CircularProgress size={14} /> : <ResetIcon />}
              disabled={reset.phase === 'busy' || selected.size === 0}
              onClick={() =>
                setReset({ phase: 'confirm', keys: [...selected] })}
              data-testid="run-files-reset-selected"
            >
              Reset selected ({selected.size})
            </Button>
          </>
        )}
      </>}>
        {load.phase === 'loading' && (
          <Stack alignItems="center" sx={{ py: 3 }}>
            <CircularProgress size={22} />
          </Stack>
        )}

        {load.phase === 'error' && (
          <Alert
            severity="error" data-testid="run-files-load-error"
            action={
              <Button color="inherit" size="small"
                      onClick={() => run && void loadFiles(run.id)}>
                Retry
              </Button>
            }
          >
            Could not load this run&apos;s files — children may exist but
            cannot be shown. {load.message}
          </Alert>
        )}

        {load.phase === 'ready' && children.length === 0 && (
          <Alert severity="info" data-testid="run-files-empty">
            This run has no per-file children — it is not a fan-out run.
            Use the ordinary re-run to execute it again.
          </Alert>
        )}

        {load.phase === 'ready' && children.length > 0 && (
          <>
            <Stack direction="row" spacing={1} sx={{ mb: 1.5 }}
                   alignItems="center" flexWrap="wrap">
              {Object.entries(load.data.status_counts).map(([s, n]) => (
                <Chip key={s} size="small" label={`${s}: ${n}`}
                      color={STATUS_COLOR[s] ?? 'default'}
                      variant="outlined" />
              ))}
              <Box sx={{ flex: 1 }} />
              <Button size="small" startIcon={<RefreshIcon />}
                      onClick={() => run && void loadFiles(run.id)}>
                Refresh
              </Button>
            </Stack>

            <Box sx={{ maxHeight: 320, overflow: 'auto' }}>
              <Table size="small" data-testid="run-files-table">
                <TableHead>
                  <TableRow>
                    <TableCell padding="checkbox" />
                    <TableCell>Partition</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell align="right">Rows</TableCell>
                    <TableCell align="right">Attempts</TableCell>
                    <TableCell>Error</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {pg.rows.map(c => {
                    const terminal = TERMINAL.has(c.status);
                    return (
                      <TableRow key={c.partition_key} hover>
                        <TableCell padding="checkbox">
                          <Tooltip title={terminal
                            ? '' : `${c.status} — already on its way; a reset would race the worker`}>
                            <span>
                              <Checkbox
                                size="small"
                                checked={selected.has(c.partition_key)}
                                disabled={!terminal}
                                onChange={() => toggle(c.partition_key)}
                                slotProps={{ input: {
                                  'aria-label': `select ${c.partition_key}`,
                                  } as any }}
                              />
                            </span>
                          </Tooltip>
                        </TableCell>
                        <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.75rem' }}>
                          {c.partition_key}
                        </TableCell>
                        <TableCell>
                          <Chip size="small" label={c.status}
                                color={STATUS_COLOR[c.status] ?? 'default'}
                                sx={{ height: 20, fontSize: '0.68rem' }} />
                        </TableCell>
                        <TableCell align="right">
                          {c.row_count ?? '—'}
                        </TableCell>
                        <TableCell align="right">{c.attempt_count}</TableCell>
                        <TableCell sx={{ maxWidth: 260 }}>
                          <Typography variant="caption" color="error"
                                      sx={{ wordBreak: 'break-word' }}>
                            {c.error || ''}
                          </Typography>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </Box>
            <ListPager paging={pg.paging} onPage={setPage} onPageSize={setPageSize} testid="run-files-pager" />
          </>
        )}

        {resetError && (
          <Alert severity="error" sx={{ mt: 1.5 }}
                 onClose={() => setResetError(null)}
                 data-testid="run-files-reset-error">
            Reset failed — nothing was changed. {resetError}
          </Alert>
        )}

        {reset.phase === 'done' && (
          <Box sx={{ mt: 1.5 }} data-testid="run-files-reset-outcomes">
            <Alert
              severity={reset.result.refused_count > 0 ? 'warning' : 'success'}
              sx={{ mb: 1 }}
            >
              {reset.result.reset_count} partition(s) reset to pending,
              {' '}{reset.result.refused_count} refused.  Re-run the parent
              to execute exactly the reset partitions.
            </Alert>
            {reset.result.outcomes.map(o => (
              <Typography key={o.partition_key} variant="caption"
                          sx={{ display: 'block' }}
                          color={o.outcome === 'reset' ? 'text.secondary' : 'error'}>
                {o.outcome === 'reset' ? '✓' : '✗'} {o.partition_key} —
                {' '}{o.outcome}{o.detail ? `: ${o.detail}` : ''}
              </Typography>
            ))}
            {rerunMsg
              ? <Alert severity="success" sx={{ mt: 1 }}>{rerunMsg}</Alert>
              : (
                <Button size="small" variant="contained" sx={{ mt: 1 }}
                        startIcon={<RerunIcon />}
                        onClick={() => void doRerun()}
                        data-testid="run-files-rerun">
                  Re-run now (pending children only)
                </Button>
              )}
            {rerunErr && (
              <Alert severity="error" sx={{ mt: 1 }}>
                Re-run could not be triggered: {rerunErr}
              </Alert>
            )}
          </Box>
        )}

        {/* ── Confirm step: name what will be reset BEFORE sending ── */}
        {reset.phase === 'confirm' && (
          <Alert severity="warning" sx={{ mt: 1.5 }}
                 data-testid="run-files-reset-confirm">
            <Typography variant="body2" sx={{ mb: 1 }}>
              {confirmNamed === null
                ? <>Every <strong>failed</strong> child of this run
                    ({failedCount}) will be reset to pending.</>
                : <>These {confirmNamed.length} partition(s) will be reset
                    to pending and <strong>re-produced from scratch</strong> on
                    the next re-run: {confirmNamed.join(', ')}</>}
              {' '}Nothing executes until the parent is re-run.
            </Typography>
            <TextField
              label="Reason (optional, recorded)"
              value={resetReason} size="small" fullWidth
              onChange={e => setResetReason(e.target.value)}
              inputProps={{ 'data-testid': 'run-files-reset-reason' }}
              sx={{ mb: 1 }}
            />
            <Stack direction="row" spacing={1}>
              <Button size="small"
                      onClick={() => setReset({ phase: 'idle' })}>
                Cancel
              </Button>
              <Button size="small" variant="contained" color="warning"
                      onClick={() => void doReset(confirmNamed)}
                      data-testid="run-files-reset-go">
                Reset {confirmNamed === null
                  ? `${failedCount} failed` : confirmNamed.length} partition(s)
              </Button>
            </Stack>
          </Alert>
        )}
    </AppDialog>
  );
};

export default FeedRunFilesDialog;
