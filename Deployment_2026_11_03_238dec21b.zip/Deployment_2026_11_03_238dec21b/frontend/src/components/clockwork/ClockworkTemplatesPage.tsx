/**
 * Query templates — the admin page (2026-09-11).
 *
 * A ``sql_scalar`` step may name a declared query template (plan v2 §5,
 * shape 2): admin-authored SQL whose binds the job supplies.  Until today
 * the templates had CRUD routes, an audit trail and a version, and NO page
 * — a feature reachable only by curl, the class the previous round spent
 * itself closing.  This page lists them for everyone who may see the
 * scheduler and lets an admin (the routes are ``require_admin``) create,
 * edit, retire / reactivate and delete one.
 *
 * What the SERVER decides, this page only renders: the statement rules
 * (ONE SELECT, no comment, Oracle only — refused with `problems` by path,
 * the same words the dispatcher uses before a claim), the derived `binds`,
 * the version bump, and the 409 when a job snapshots a template that is
 * being deleted (the jobs are named; retire instead).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, FormControlLabel,
  IconButton, Paper,
  Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import api from '../../services/api';
import type { ClockworkQueryTemplate, ClockworkTemplateDraft } from '../../services/api/clockwork';
import { useClockworkAccess } from '../../context/ClockworkAccessContext';
import { detailFromError, problemsFromError } from './clockworkRules';
import ListPager, { clientPage } from '../common/ListPager';

type ListState =
  | { phase: 'loading' }
  | { phase: 'ready'; data: ClockworkQueryTemplate[] }
  | { phase: 'forbidden'; message: string }
  | { phase: 'failed'; message: string };

const EMPTY: ClockworkTemplateDraft = { name: '', description: '', connection_type: 'oracle', sql_text: '', side_effect_free: false };

function messageOf(err: unknown): string {
  const d = detailFromError(err);
  if (d && typeof d.reason === 'string') return d.reason;
  if (d && typeof d.message === 'string') return d.message;
  const m = (err as { message?: unknown })?.message;
  return typeof m === 'string' && m ? m : 'request failed';
}

export default function ClockworkTemplatesPage() {
  const access = useClockworkAccess();
  const [list, setList] = useState<ListState>({ phase: 'loading' });
  const [editing, setEditing] = useState<{ id: number | null; draft: ClockworkTemplateDraft } | null>(null);
  const [problems, setProblems] = useState<Array<{ path: string; message: string }>>([]);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ kind: 'error' | 'success'; text: string } | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const load = useCallback(async () => {
    setList({ phase: 'loading' });
    try {
      const r = await api.clockwork.listTemplates();
      setList({ phase: 'ready', data: Array.isArray(r?.templates) ? r.templates : [] });
    } catch (err) {
      const status = (err as { status?: number })?.status;
      if (status === 403) setList({ phase: 'forbidden', message: messageOf(err) });
      else setList({ phase: 'failed', message: messageOf(err) });
    }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const shown = clientPage(list.phase === 'ready' ? list.data : [], page, pageSize);

  const problemsAt = (path: string) => problems.filter(p => p.path === path).map(p => p.message);

  const save = async () => {
    if (!editing) return;
    setSaving(true); setProblems([]); setSaveError(null);
    try {
      const body = { ...editing.draft, description: editing.draft.description || null };
      if (editing.id === null) await api.clockwork.createTemplate(body);
      else await api.clockwork.updateTemplate(editing.id, body);
      setEditing(null);
      setNotice({ kind: 'success', text: editing.id === null ? 'template created' : 'template saved — jobs snapshotting it were re-projected' });
      await load();
    } catch (err) {
      const p = problemsFromError(err);
      if (p && p.length) setProblems(p); else setSaveError(messageOf(err));
    } finally { setSaving(false); }
  };

  const setActive = async (t: ClockworkQueryTemplate, isActive: boolean) => {
    setNotice(null);
    try {
      await api.clockwork.updateTemplate(t.id, { is_active: isActive });
      setNotice({ kind: 'success', text: isActive
        ? `${t.name} reactivated — jobs bound to it are projected again`
        : `${t.name} retired (switched off) — a job that uses it stops running and raises an alert until it is moved to another template or this one is switched back on under Switched Off` });
      await load();
    } catch (err) { setNotice({ kind: 'error', text: messageOf(err) }); }
  };

  const remove = async (t: ClockworkQueryTemplate) => {
    setNotice(null);
    try {
      await api.clockwork.deleteTemplate(t.id);
      setNotice({ kind: 'success', text: `${t.name} switched off, not erased -- an admin can switch it back on under Admin -> Switched off.` });
      await load();
    } catch (err) {
      const d = detailFromError(err);
      const jobs = Array.isArray(d?.jobs) ? (d!.jobs as Array<{ id?: unknown; name?: unknown }>) : [];
      if ((err as { status?: number })?.status === 409 && jobs.length) {
        setNotice({ kind: 'error', text: `${t.name} is snapshotted by ${jobs.length} job(s) — ${jobs.map(j => `${String(j.name)} (#${String(j.id)})`).join(', ')} — retire it, or unbind the jobs first` });
      } else setNotice({ kind: 'error', text: messageOf(err) });
    }
  };

  return (
    <Box sx={{ p: 3 }} data-testid="clockwork-templates-page">
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
        <Box>
          <Typography variant="h5">Query Templates</Typography>
          <Typography variant="body2" color="text.secondary">
            Declared SQL a <code>sql_scalar</code> pre-check may run: ONE SELECT on an Oracle connection, every value a
            bind the job supplies, one row × one column × a number.  The dispatcher refuses anything else before a claim;
            this page refuses it at save, in the same words.
          </Typography>
        </Box>
        {access.canAdmin && (
          <Button variant="contained" onClick={() => { setProblems([]); setSaveError(null); setEditing({ id: null, draft: { ...EMPTY } }); }}
                  data-testid="new-template">New template</Button>
        )}
      </Stack>
      {!access.canAdmin && access.source !== 'pending' && (
        <Alert severity="info" sx={{ mb: 2 }} data-testid="templates-read-only">
          Templates are authored by an administrator; you can see which exist and what they bind.
        </Alert>
      )}
      {notice && <Alert severity={notice.kind} sx={{ mb: 2 }} onClose={() => setNotice(null)} data-testid="templates-notice">{notice.text}</Alert>}

      {list.phase === 'loading' && <Typography variant="body2" color="text.secondary">loading…</Typography>}
      {list.phase === 'forbidden' && (
        <Alert severity="warning" data-testid="templates-forbidden">The template list is hidden from you: {list.message}</Alert>
      )}
      {list.phase === 'failed' && (
        <Alert severity="error" data-testid="templates-unreachable">The templates could not be listed — they may exist: {list.message}</Alert>
      )}
      {list.phase === 'ready' && list.data.length === 0 && (
        <Alert severity="info" data-testid="templates-empty">No query templates exist yet.  A <code>sql_scalar</code> step can still use a structured COUNT predicate without one.</Alert>
      )}
      {list.phase === 'ready' && list.data.length > 0 && (
        <Paper variant="outlined">
          <Table size="small" data-testid="templates-table">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell><TableCell>Connection type</TableCell><TableCell>Version</TableCell>
                <TableCell>Binds</TableCell><TableCell>Status</TableCell><TableCell>SQL</TableCell>
                {access.canAdmin && <TableCell align="right">Actions</TableCell>}
              </TableRow>
            </TableHead>
            <TableBody>
              {shown.rows.map(t => (
                <TableRow key={t.id} data-testid={`template-row-${t.id}`}>
                  <TableCell>
                    <Typography variant="body2" fontWeight={600}>{t.name}</Typography>
                    {t.description && <Typography variant="caption" color="text.secondary">{t.description}</Typography>}
                  </TableCell>
                  <TableCell>{t.connection_type}</TableCell>
                  <TableCell>v{t.version}</TableCell>
                  <TableCell>{t.binds.length ? t.binds.map(b => <Chip key={b} size="small" label={`:${b}`} sx={{ mr: 0.5 }} />) : <em>none</em>}</TableCell>
                  <TableCell>
                    <Chip size="small" color={t.is_active ? 'success' : 'default'} label={t.is_active ? 'active' : 'retired'} />
                    {t.side_effect_free === true && (
                      <Chip size="small" variant="outlined" label="declared side-effect-free" sx={{ ml: 0.5 }}
                            data-testid={`template-${t.id}-side-effect-free`}
                            title="An execution-time error on this template is FAILED, not an UNKNOWN page" />
                    )}
                  </TableCell>
                  <TableCell sx={{ maxWidth: 420 }}>
                    <Typography variant="caption" sx={{ fontFamily: 'monospace', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{t.sql_text}</Typography>
                  </TableCell>
                  {access.canAdmin && (
                    <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
                      <Tooltip title="edit (bumps the version and re-projects the jobs that snapshot it)">
                        <IconButton size="small" aria-label={`edit ${t.name}`}
                                    onClick={() => { setProblems([]); setSaveError(null); setEditing({ id: t.id, draft: { name: t.name, description: t.description || '', connection_type: t.connection_type, sql_text: t.sql_text, side_effect_free: t.side_effect_free === true } }); }}>
                          <EditIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Button size="small" onClick={() => void setActive(t, !t.is_active)} aria-label={`${t.is_active ? 'retire' : 'reactivate'} ${t.name}`}>
                        {t.is_active ? 'retire' : 'reactivate'}
                      </Button>
                      <Tooltip title="delete — refused while a job snapshots it">
                        <IconButton size="small" aria-label={`delete ${t.name}`} onClick={() => void remove(t)}>
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <ListPager paging={shown.paging} onPage={setPage} onPageSize={setPageSize}
                     testid="clockwork-templates-pager" />
        </Paper>
      )}

      <AppDialog open={editing !== null}
        onClose={() => !saving && setEditing(null)}
        size="md"
        title={<>{editing?.id === null ? 'New query template' : `Edit ${editing?.draft.name ?? ''}`}</>}
        actions={<>
          <Button onClick={() => setEditing(null)} disabled={saving}>Cancel</Button>
          <Button variant="contained" onClick={() => void save()} disabled={saving} data-testid="save-template">Save</Button>
        </>}>
          {editing && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField label="Name" size="small" value={editing.draft.name} inputProps={{ 'aria-label': 'template name' }}
                         onChange={e => setEditing({ ...editing, draft: { ...editing.draft, name: e.target.value } })}
                         error={problemsAt('name').length > 0} helperText={problemsAt('name').join('; ') || 'a plain identifier the job editor lists'} />
              <TextField label="Description" size="small" value={editing.draft.description ?? ''} inputProps={{ 'aria-label': 'template description' }}
                         onChange={e => setEditing({ ...editing, draft: { ...editing.draft, description: e.target.value } })} />
              <TextField label="Connection type" size="small" value={editing.draft.connection_type} disabled
                         helperText="oracle — the dispatcher runs a template on an Oracle session only" />
              <TextField label="SQL" multiline minRows={6} value={editing.draft.sql_text} inputProps={{ 'aria-label': 'template sql' }}
                         onChange={e => setEditing({ ...editing, draft: { ...editing.draft, sql_text: e.target.value } })}
                         error={problemsAt('sql_text').length > 0}
                         helperText={problemsAt('sql_text').join('; ') || 'ONE SELECT (or WITH … SELECT); no “;”, no comment; each :name bind is supplied by the job'}
                         sx={{ '& textarea': { fontFamily: 'monospace' } }} />
              <Box>
                <FormControlLabel
                  control={<Checkbox checked={editing.draft.side_effect_free === true} inputProps={{ 'aria-label': 'template side effect free' }}
                                     onChange={e => setEditing({ ...editing, draft: { ...editing.draft, side_effect_free: e.target.checked } })} />}
                  label="Declared side-effect-free" />
                <Typography variant="caption" color="text.secondary" display="block">
                  A declaration, by you: this SELECT reaches no function, view, virtual column or VPD/FGA policy that
                  writes (an autonomous transaction cannot be seen from the text). With it, an error Oracle raises
                  DURING execution is recorded FAILED and nobody is paged to confirm; without it, such an error is
                  UNKNOWN and pages CRITICAL. A lost answer stays UNKNOWN either way.
                </Typography>
              </Box>
              {problems.filter(p => !['name', 'sql_text'].includes(p.path)).map((p, i) => (
                <Alert key={i} severity="error" data-testid="template-problem">{p.path}: {p.message}</Alert>
              ))}
              {saveError && <Alert severity="error" data-testid="template-save-error">{saveError}</Alert>}
            </Stack>
          )}
      </AppDialog>
    </Box>
  );
}
