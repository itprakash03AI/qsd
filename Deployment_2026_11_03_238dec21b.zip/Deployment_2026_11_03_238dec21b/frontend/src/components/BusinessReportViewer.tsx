/**
 * Phase 56+81 — Business Report Viewer
 *
 * Phase 81 enhancements:
 *  - Server-side pagination (page/page_size query params)
 *  - Column header sorting (clickable, cyclic null→asc→desc→null)
 *  - Grand totals footer row (sum numeric cols)
 *  - Better data-type cell formatting (numbers, dates, booleans, nulls)
 *  - Async execution with progress bar + Cancel button
 *
 * Reporting rewire Phase 3 (2026-08-09): the presentation engine is chosen
 * by the SERVER's `engine` verdict on the result contract (a row-count CAP,
 * config.business_reports.client_engine_max_rows):
 *  - "client" (or absent): fetchAllRows + useReportEngine — byte-identical
 *    to the pre-rewire flow; useReportEngine is KEPT as the small-result
 *    engine and the availability fallback.
 *  - "server": drill/expand/slicer/sort/page gestures each issue ONE bounded
 *    POST .../results/{exec_id}/cube query; fetchAllRows never runs.  422
 *    non_additive_measures responses are surfaced per measure (withheld,
 *    named, explained — never a silently wrong number), and truncation is
 *    disclosed at EVERY drill level (drill audit D6).
 * Engine parity is gated by the golden corpus
 * (useReportEngine.parity.test.ts ↔ backend test_report_engine_parity_*).
 */
import React, { useState, useEffect, useCallback, useMemo, useRef, useSyncExternalStore } from 'react';
// 2026-10-30 -- only the rows on screen are drawn (a 5,000-row page is ~40 <tr>s)
import VirtualRows from './reports/canvas/canvasRender/VirtualRows';
import { useExportRetention } from './reports/useExportRetention';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Box, Paper, Typography, Button, IconButton, Chip, Divider,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TablePagination,
  TableFooter, CircularProgress, Alert, TextField, Select, MenuItem, Menu, FormControl,
  InputLabel, Collapse, Breadcrumbs, Link, Tooltip, Badge, LinearProgress,
  FormControlLabel, Switch, ListItemIcon, ListItemText, Snackbar,
  ToggleButtonGroup, ToggleButton, useMediaQuery, Checkbox, Popover, Drawer,
  Dialog, DialogTitle, DialogContent, DialogActions,
} from '@mui/material';
import { alpha, useTheme } from '@mui/material/styles';
import {
  DashboardCustomize as AddToDashboardIcon,
  PlayArrow as PlayIcon,
  Edit as EditIcon,
  Palette as FormattingIcon,
  ColorLens as ViewThemeIcon,
  GetApp as ExportIcon,
  ViewColumn as ViewColumnIcon,
  PictureAsPdf as PdfIcon,
  TableView as ExcelIcon,
  ExpandMore as ExpandIcon,
  ExpandLess as CollapseIcon,
  Bolt as BoltIcon,
  NavigateNext as NavNextIcon,
  FilterList as FilterIcon,
  ContentCopy as DuplicateIcon,
  CheckCircle as CertifiedIcon,
  Link as ShareLinkIcon,
  Code as EmbedCodeIcon,
  Email as EmailIcon,
  ArrowUpward as SortAscIcon,
  ArrowDownward as SortDescIcon,
  UnfoldMore as SortNoneIcon,
  Cancel as CancelIcon,
  Refresh as RefreshIcon,
  FlashOn as FlashOnIcon,
  InfoOutlined as InfoOutlinedIcon,
  Public as PublishApiIcon,
  History as HistoryIcon,
  KeyboardArrowUp as DrillUpIcon,
  KeyboardDoubleArrowDown as ExpandNextLevelIcon,
  AccountTree as GoNextLevelIcon,
  TouchApp as DrillClickIcon,
  ChatBubbleOutline as CommentIcon,
  Timeline as TimelineIcon,
  Lock as PermissionsIcon,
  WarningAmber as TruncatedIcon,
  TableChart as TableViewToggleIcon,
  BarChart as ChartViewToggleIcon,
  FactCheck as ReadinessIcon,
  MoreHoriz as MoreIcon,
  Bookmarks as BookmarksIcon,
  ManageSearch as DiagnosticsIcon,
} from '@mui/icons-material';
import {
  DndContext, closestCenter, PointerSensor, useSensor, useSensors,
} from '@dnd-kit/core';
import {
  SortableContext, horizontalListSortingStrategy, useSortable, arrayMove,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import api from '../services/api';
// Read from the payload the server sends, not from a status code alone —
// see the progressive-serving notes on the pin below.
import { isSnapshotMoved } from '../services/api/businessReports';
import { applyFormatPattern, formatAccounting } from '../utils/formatters';
import { resolveParamDefaults } from '../utils/parameterUtils';
import {
  InstanceInfo, parseInstanceInfo, parseInstanceProbe, formatAsOf,
  truncationMessage, truncationChipLabel, asOfShort, asOfHoverText, staleWords,
  emptyResultInfo, describeExecutionError,
} from '../utils/reportViewerMessages';
import { useWebSocket } from '../context/WebSocketContext';
import { useQueuedWait, queuedWaitLabel } from '../hooks/useQueuedWait';
import { useAuth } from '../context/AuthContext';
import { canAuthorReports, canEditReport } from '../utils/reportLifecycle';
import ReportLifecycleControls, { ReportLifecycleBanner, type LifecycleMenuAction } from './ReportLifecycleControls';
import SubscriptionManager from './SubscriptionManager';
import AddToDashboardDialog from './dashboard/AddToDashboardDialog';
import PublishViewDialog from './PublishViewDialog';
import ReportCommentPanel from './ReportCommentPanel';
import ReportChangeHistory from './ReportChangeHistory';
import BusinessReportPermissionsTab from './BusinessReportPermissionsTab';
import ReportFormattingPanel from './reports/ReportFormattingPanel';
import { draftFromReport, evaluateRuleStyle, cutoffsFromRows } from './reports/reportAuthoringModel';
import InstanceSignoffHeader from './reports/InstanceSignoffHeader';
import ReportCanvasView from './reports/canvas/ReportCanvasView';
import { CanvasBandContext } from './reports/canvas/CanvasOutlineTile';
import {
  CanvasThemeContext, DEFAULT_THEME_NAME, SHIPPED_THEMES, contrastRatio, isHex, resolveTheme, shippedThemeName,
} from './reports/canvas/canvasTheme';
import ThemeGallery from './reports/ThemeGallery';
import { CanvasCompareContext, compareFrom } from './reports/canvas/canvasCompare';
import { applyViewerLayout, useViewerLayout, ViewerLayoutBar } from './reports/canvas/viewerLayout';
import { createLinkStore, linksExportParam, reportTableLinks, withLinkSlicers } from './reports/canvas/canvasLinks';
import { recordRenderStats } from './reports/canvas/canvasRender/renderStats';
import { pageTransportOf } from '../services/api/pageArrow';
import { CanvasActionsProvider } from './reports/canvas/canvasActions';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import { effectiveCanvas, isTableOnlyCanvas, rowsAreGrouped, type CanvasColumn } from './reports/canvas/canvasModel';
import CompletenessBadge from './CompletenessBadge';
import EngineChip from './common/EngineChip';
import ScanDisclosureChip from './common/ScanDisclosureChip';
import ReportDiagnosticsPanel from './reports/ReportDiagnosticsPanel';
import EntitlementChip from './common/EntitlementChip';
// 2026-09-28 -- "is this number final?" (the feed gate, read for the
// report) and the report's promise; both self-hide when there is nothing
// to say.  Editors declare both in ReportReadinessSloDialog.
import ReadinessChip from './reports/ReadinessChip';
// 2026-11-01 -- the run panel's "Data version" (Iceberg tables only) + what the run read
import { buildDataVersion, DataVersionBandCell, type DataVersionChoices } from './reports/ReportDataVersionControl';
import type { ReportDataVersions } from '../services/api/businessReports';
import ReportBand, { BandControlsContext, bandParams, type BandControls } from './reports/ReportBand';
import { VersionsReadLine } from './common/tableVersionWords';
import ReportSloChip from './reports/ReportSloChip';
import ReportReadinessSloDialog from './reports/ReportReadinessSloDialog';
import ReportBookmarks from './reports/ReportBookmarks';
import ReportChartView, { parseChartConfig, resolveChartConfig } from './ReportChartView';
import useReportEngine, { SectionDef, RunningCalcDef, DrillState, BandedRow, MeasureAggConfig } from '../hooks/useReportEngine';
import { reportEditPath, useResolvedReportId } from '../utils/reportUrls';
import { clickable } from '../utils/clickable';

// ── Constants ────────────────────────────────────────────────────────────────

const DEFAULT_PAGE_SIZE = 500;
const PAGE_SIZE_OPTIONS = [100, 200, 500, 1000, 2000, 5000];

// Default style config (used when report has no layout_config.style_config)
interface StyleConfig {
  header_bg: string; header_text: string; accent_color: string;
  negative_format: 'brackets' | 'minus' | 'red';
  stripe_rows: boolean; subtotal_bg: string; grand_total_bg: string;
}
const DEFAULT_STYLE: StyleConfig = {
  header_bg: '#1976D2', header_text: '#FFFFFF', accent_color: '#e3f2fd',
  negative_format: 'brackets', stripe_rows: true,
  subtotal_bg: '#f5f5f5', grand_total_bg: '#e8eaf6',
};

const getRowStyles = (sc: StyleConfig): Record<string, any> => ({
  header: { bgcolor: sc.accent_color, fontWeight: 'bold' },
  subtotal: { bgcolor: sc.subtotal_bg, fontWeight: 'bold', fontStyle: 'italic' },
  grand_total: { bgcolor: sc.grand_total_bg, fontWeight: 'bold' },
  data: {},
});

// ── Data type helpers ─────────────────────────────────────────────────────────

function detectColType(colName: string, sampleValue: any): 'integer' | 'float' | 'date' | 'datetime' | 'boolean' | 'string' {
  if (typeof sampleValue === 'boolean') return 'boolean';
  if (typeof sampleValue === 'number') {
    return Number.isInteger(sampleValue) ? 'integer' : 'float';
  }
  if (typeof sampleValue === 'string') {
    // ISO date: YYYY-MM-DD
    if (/^\d{4}-\d{2}-\d{2}$/.test(sampleValue)) return 'date';
    // ISO datetime
    if (/^\d{4}-\d{2}-\d{2}T/.test(sampleValue)) return 'datetime';
  }
  return 'string';
}

function formatCellValue(
  value: any, colType: string, formatPattern?: string, dataType?: string,
  negativeFormat: 'brackets' | 'minus' | 'red' = 'brackets',
): React.ReactNode {
  if (value === null || value === undefined) return <span style={{ color: '#aaa' }}>—</span>;

  // Phase 101: apply semantic layer format pattern if available
  if (formatPattern) {
    const formatted = applyFormatPattern(value, formatPattern, dataType);
    if (formatted !== null) {
      // Wrap negative numbers in styling
      const num = typeof value === 'number' ? value : parseFloat(String(value));
      if (!isNaN(num) && num < 0) {
        const display = negativeFormat === 'brackets'
          ? formatted.replace(/^-/, '').replace(/^(.*)$/, '($1)')
          : formatted;
        return <span style={{ color: '#d32f2f' }}>{display}</span>;
      }
      return formatted;
    }
  }

  if (colType === 'boolean') return value ? '✓' : '✗';

  // Numeric columns — apply negative formatting
  if (colType === 'integer' || colType === 'float') {
    const num = typeof value === 'number' ? value : parseFloat(String(value));
    if (isNaN(num)) return String(value);
    const decimals = colType === 'float' ? 2 : 0;
    if (num < 0) {
      const display = negativeFormat === 'brackets'
        ? formatAccounting(num, decimals)
        : num.toLocaleString(undefined, { maximumFractionDigits: decimals });
      return <span style={{ color: '#d32f2f' }}>{display}</span>;
    }
    return num.toLocaleString(undefined, { maximumFractionDigits: decimals });
  }

  if (colType === 'date') {
    try { return new Date(String(value)).toLocaleDateString(); }
    catch { return String(value); }
  }
  if (colType === 'datetime') {
    try { return new Date(String(value)).toLocaleString(); }
    catch { return String(value); }
  }
  return String(value);
}

// ── Component ────────────────────────────────────────────────────────────────

// 2026-11-03 -- "View in another theme": a viewer's pick, remembered per viewer per
// report in this browser.  Storage may be missing (a private window, blocked site
// data): every read and write is guarded and the page works without it.
const VIEW_THEME_PREFIX = 'qs.report.viewTheme.';
export const viewThemeKey = (username: string | null | undefined, reportId: any) =>
  `${VIEW_THEME_PREFIX}${username || 'guest'}.${reportId}`;
function readViewTheme(key: string): string | null {
  try {
    const v = window.localStorage.getItem(key);
    return v && v.length <= 100 ? v : null;
  } catch { return null; }
}
function writeViewTheme(key: string, name: string | null): void {
  try {
    if (name) window.localStorage.setItem(key, name);
    else window.localStorage.removeItem(key);
  } catch { /* not remembered; this visit still shows it */ }
}

const BusinessReportViewer: React.FC = () => {
  const navigate = useNavigate();
  // 2026-09-20 -- the route param carries the SLUG; the numeric id comes
  // from the identity the route element resolved (or a numeric param when
  // this component is mounted alone, as its tests do).
  const reportId = useResolvedReportId();
  const { addListener } = useWebSocket();
  // H1 item 5 (2026-10-07): the SYNC execute POST's wait for a server slot
  // (the async path shows its own capacity wait) -- shown, and cancellable,
  // by the run's correlation id.
  const queuedWait = useQueuedWait();
  const { user } = useAuth();

  // ── Mobile consumption (2026-08-09) ──────────────────────────────────────
  // Executives open report links on phones.  Same raw-query convention as
  // Layout.tsx.  What changes on mobile: compact chrome, a horizontally
  // scrollable table with a PINNED first column (row identity stays visible
  // while measures scroll), and larger touch targets.  What must NOT change:
  // the trust banners — "Data as of", truncation, provenance, certified —
  // render identically at every width.
  const isMobile = useMediaQuery('(max-width:600px)');
  const muiTheme = useTheme();

  // Report state
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');

  // Subscription dialog
  const [subOpen, setSubOpen] = useState(false);

  // Phase 91: Publish as API dialog
  const [publishApiOpen, setPublishApiOpen] = useState(false);

  // Formatting & calculations authoring panel (2026-08-30)
  const [formattingOpen, setFormattingOpen] = useState(false);
  // 2026-09-28 -- the Readiness & SLO declaration (editors only)
  const [readinessOpen, setReadinessOpen] = useState(false);
  const [sloRefresh, setSloRefresh] = useState(0);

  // Execution state
  const [executing, setExecuting] = useState(false);
  const [asyncExecId, setAsyncExecId] = useState<string | null>(null);
  const [asyncProgress, setAsyncProgress] = useState(0);
  // 2026-09-29 -- an admitted async run waiting for server capacity says so
  // (status_detail from the server), instead of a bar stuck at 0%.
  const [capacityWait, setCapacityWait] = useState<string | null>(null);
  // 2026-08-31 -- "we stopped watching, it is still running".  A DIFFERENT
  // state from an error: nothing failed, and the run will finish and notify.
  // Rendering it as an error is what made the old ten-minute timeout read as
  // a failure when it was really the browser giving up on a healthy job.
  const [stillRunning, setStillRunning] = useState(false);
  // WS wakeup: resolve the polling sleep early when WS message arrives
  const wsPollWakeup = useRef<(() => void) | null>(null);
  const [executionResult, setExecutionResult] = useState<any>(null);
  // 2026-11-01 -- the Data version choices (one per Iceberg table) and the
  // server's refusal of the last run's data_version (a 422, in its words)
  const [dataVersionChoices, setDataVersionChoices] = useState<DataVersionChoices>({});
  const [versionRefusal, setVersionRefusal] = useState<string | null>(null);
  const [rawRows, setRawRows] = useState<any[]>([]);
  const [resultColumns, setResultColumns] = useState<string[]>([]);
  // All rows for client-side drill (loaded once after execution)
  const [allRows, setAllRows] = useState<any[]>([]);
  const [allRowsLoading, setAllRowsLoading] = useState(false);

  // Pagination
  const [page, setPage] = useState(0);  // 0-indexed for MUI
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [totalRows, setTotalRows] = useState(0);
  // the results table's scroll box -- the virtual rows watch it
  const resultsScrollRef = useRef<HTMLDivElement | null>(null);
  // 2026-10-24 -- the cut-off of each top / bottom N format, computed by the
  // server over the WHOLE result (format_cutoffs on every page).
  const [formatCutoffs, setFormatCutoffs] = useState<Record<string, number>>({});

  // Truncation disclosure (2026-08-05): tri-state — true = row limit reached
  // (result may be incomplete), false = complete w.r.t. the limit, null =
  // unknown (older backend / metadata unavailable). Never silently degrade.
  const [truncated, setTruncated] = useState<boolean | null>(null);
  const [truncRowLimit, setTruncRowLimit] = useState<number | null>(null);

  // ── Instance provenance (Phase 2 UX, 2026-08-09) ─────────────────────────
  // Non-null when the current result was SERVED FROM A STORED INSTANCE
  // (BusinessObjects consumption model): the "Data as of <time> · Refresh"
  // banner + provenance chip render from this.  A user must never mistake
  // stored data for live — this is the disclosure the backend's
  // served_from_instance / as_of / freshness / stale keys exist for.
  const [instanceInfo, setInstanceInfo] = useState<InstanceInfo | null>(null);

  // ── Auto-open (2026-08-09): open = render latest instance when FREE ──────
  // On load the viewer probes GET /instances/latest with the parameters the
  // user will actually run.  200 = the serve path would answer from a
  // stored instance, so opening costs nothing → auto-execute (which serves
  // that instance instantly, banner included).  404 / ANY error = opening
  // would fire a live source query → do NOT auto-execute; wait for the
  // user, exactly as before.  The probe result carries the instance row so
  // the "Data as of" banner renders provisionally BEFORE the execute
  // completes.
  const autoOpenAttempted = useRef(false);
  // a run already started (by a click, a band pick, the open itself): the open's own run stands
  // down -- read from a ref, because a probe that resolves in the same tick as a click would
  // otherwise see the render from before the click and start a second run
  const runStarted = useRef(false);
  const [pendingAutoOpen, setPendingAutoOpen] = useState<{
    params: Record<string, any>;
    provisional: InstanceInfo | null;
  } | null>(null);

  // ── Waiting management (research §5: 1s flow / 10s attention limits) ─────
  const [elapsedSec, setElapsedSec] = useState(0);   // execute wait, seconds
  const [cubeSlow, setCubeSlow] = useState(false);   // drill gesture > 10s
  const [exporting, setExporting] = useState<null | 'excel' | 'pdf' | 'csv'>(null);

  // Sorting (Phase 81 FIX 3)
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc' | null>(null);

  // Grand totals (Phase 81 FIX 9)
  const [showTotals, setShowTotals] = useState(true);

  // Parameter state
  const [paramValues, setParamValues] = useState<Record<string, any>>({});
  const [addToDashOpen, setAddToDashOpen] = useState(false);
  const [paramsPanelOpen, setParamsPanelOpen] = useState(true);

  // Slicer state
  const [slicerValues, setSlicerValues] = useState<Record<string, any[]>>({});

  // Chart view (2026-08-09): the report's saved visualisation config
  // (layout_config.chart_config) renders through the same microcube the
  // table drills with.  viewMode only matters when a chart is configured.
  // 'both' (2026-09-25): the chart above the table, dashboard-style -- the
  // same data, the same drill state, both at once.
  const [viewMode, setViewMode] = useState<'table' | 'chart' | 'both'>('table');

  // Drill state
  const [drillState, setDrillState] = useState<DrillState>({ level: 0, filters: [] });
  const [drillHierarchyLevels, setDrillHierarchyLevels] = useState<Array<{ column_name: string; label: string }>>([]);
  const [drillClickMode, setDrillClickMode] = useState(false); // when true, clicking a row drills down
  // expandedLevels: how many hierarchy levels to show as columns (0 = just report columns)
  const [expandedLevels, setExpandedLevels] = useState(0);

  // ── Reporting rewire Phase 3 (2026-08-09): server-engine mode ────────────
  // The SERVER stamps engine:"client"|"server" on the result contract from
  // the footer-derived row count (config.business_reports.client_engine_max_rows,
  // a CAP — it decides WHERE banding/drill runs, never whether).  Absent
  // verdict (older backend / unknown rows) = "client" = exactly today's flow.
  const [engineVerdict, setEngineVerdict] = useState<'client' | 'server' | null>(null);
  // Truncation-stability disclosure (contract key unstable_truncation): the
  // cut had no ORDER BY, so WHICH rows were kept is nondeterministic.
  const [unstableTruncation, setUnstableTruncation] = useState<boolean | null>(null);

  // ── Progressive serving (2026-09-05) ─────────────────────────────────────
  // A report whose query declares a partition column lands its rows as
  // immutable PARTS while it is still running.  The backend has served those
  // parts since 2026-09-05; nothing here asked for them, so the user still
  // saw nothing until the last bucket landed ("if query returning 100K then
  // it will not show result till the time 100K written").
  //
  // THE PIN IS THE CORRECTNESS CORE.  The parts dataset GROWS between two
  // page requests, so a session that does not echo `dataset_version` is
  // served page N and page N+1 from two different datasets — measured at 17
  // duplicated and 32 skipped rows over eight pages.  `pinRef` is the source
  // of truth (the poll loop and the page effect both read it outside React's
  // render cycle); `datasetVersion` mirrors it for rendering only.
  const pinRef = useRef<string | null>(null);
  const [datasetVersion, setDatasetVersion] = useState<string | null>(null);
  // What the SERVER disclosed about the build behind the rows on screen.
  // null = not a progressive result, which is every ordinary report.
  const [progressive, setProgressive] = useState<{
    building: boolean;
    moreExpected: boolean;
    totalMode: 'exact' | 'at_least';
    partsReady: number;
    partsPinned: number;
    sortScope: string | null;
    refreshAvailable: boolean;
    refreshReason: string | null;
  } | null>(null);
  // The server's own words for a snapshot that moved under us (409
  // result_snapshot_moved).  Rendered verbatim — `consolidated` (the build
  // finished, the answer is intact) and `rebuilt` (those rows are gone) are
  // not paraphrases of each other, so neither is composed here.
  const [snapshotMoved, setSnapshotMoved] = useState<
    { reason: string; message: string } | null>(null);
  // True once this execution has shown PARTIAL rows, so completion offers a
  // Refresh instead of swapping the rows out from under the reader.
  const partialShownRef = useRef(false);
  // Rows the build has made durable so far, as the STATUS poll reports them
  // (manifest-only server-side — one small JSON read).  This is a different
  // number from `totalRows`, which counts the PINNED prefix on screen, and
  // the gap between the two is the whole reason a Refresh is offered.
  const [rowsReady, setRowsReady] = useState(0);
  const pinnedRowsRef = useRef(0);
  // Server-cube page state (drill gestures answered by POST .../cube).
  const [cubeRows, setCubeRows] = useState<BandedRow[]>([]);
  const [cubeColumns, setCubeColumns] = useState<string[]>([]);
  const [cubeTotalRows, setCubeTotalRows] = useState(0);
  const [cubeGrandTotals, setCubeGrandTotals] = useState<Record<string, number> | null>(null);
  const [cubeLoading, setCubeLoading] = useState(false);
  const [cubeError, setCubeError] = useState('');
  // 422 non_additive_measures payload — each withheld measure and WHY.  The
  // BusinessObjects #TOREFRESH posture: name the measure, never show a wrong
  // number, never silently drop it.
  const [refusedMeasures, setRefusedMeasures] = useState<Array<{ column: string; reason: string }>>([]);
  // DISTINCT slicer options served by the cube (client mode extracts them
  // from the fully-fetched rows; server mode must not fetch all rows).
  const [serverSlicerOptions, setServerSlicerOptions] = useState<Record<string, string[]>>({});

  // Column metadata (for resolving names)
  const [datasetColumns, setDatasetColumns] = useState<any[]>([]);
  // Column display order (drag-drop reorder in viewer, persisted to layout_config)
  const [columnOrder, setColumnOrder] = useState<string[] | null>(null);
  const saveOrderTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pollAbort = useRef(false);

  // Cleanup timers on unmount
  useEffect(() => {
    return () => {
      if (saveOrderTimer.current) clearTimeout(saveOrderTimer.current);
      pollAbort.current = true;
    };
  }, []);

  // Elapsed-seconds ticker while an execution is running (10s+ waits owe
  // the user a progress indicator AND context — research §5).
  useEffect(() => {
    if (!executing) { setElapsedSec(0); return; }
    const startedAt = Date.now();
    const t = setInterval(
      () => setElapsedSec(Math.floor((Date.now() - startedAt) / 1000)), 1000);
    return () => clearInterval(t);
  }, [executing]);

  // Drill/cube gestures are designed to answer within ~1s; if one exceeds
  // 10s, say so honestly (there is no server-side cancel for a bounded
  // cube query, so we disclose rather than fake a cancel button).
  useEffect(() => {
    if (!cubeLoading) { setCubeSlow(false); return; }
    const t = setTimeout(() => setCubeSlow(true), 10000);
    return () => clearTimeout(t);
  }, [cubeLoading]);

  // ── Per-report session memory (sessionStorage) ────────────────────────────
  // Remembers the user's last parameter values, slicer selections and drill
  // path for THIS report within the browser session, so navigating away and
  // back doesn't restart their analysis.  Convenience only — corrupt or
  // missing state silently falls back to defaults.
  const viewStateRestored = useRef(false);

  // Execution history
  const [historyOpen, setHistoryOpen] = useState(false);
  const [historyItems, setHistoryItems] = useState<any[]>([]);
  const [historyTotal, setHistoryTotal] = useState(0);
  const [historyPage, setHistoryPage] = useState(0); // 0-indexed for MUI
  const [historyPageSize, setHistoryPageSize] = useState(10);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Phase 114-L: Collaboration panel
  const [collabTab, setCollabTab] = useState<'comments' | 'history' | 'permissions'>('comments');
  const [collabOpen, setCollabOpen] = useState(false);
  const [commentCount, setCommentCount] = useState(0);

  const loadHistory = useCallback(async (pg: number, ps: number) => {
    if (!reportId) return;
    setHistoryLoading(true);
    try {
      const res = await api.getExecutionHistory(reportId, pg + 1, ps);
      setHistoryItems(res.items || []);
      setHistoryTotal(res.total || 0);
    } catch { /* ignore */ }
    finally { setHistoryLoading(false); }
  }, [reportId]);

  useEffect(() => {
    if (historyOpen) loadHistory(historyPage, historyPageSize);
  }, [historyOpen, historyPage, historyPageSize, loadHistory]);

  // ── WS listener: wake up polling early on report execution events ─────────
  useEffect(() => {
    return addListener((msg: any) => {
      if (!msg || !msg.type) return;
      if ((msg.type === 'report_execution_completed' || msg.type === 'report_execution_failed')
          && msg.report_id === reportId) {
        // Wake up polling sleep immediately
        if (wsPollWakeup.current) wsPollWakeup.current();
      }
    });
  }, [addListener, reportId]);

  // ── Load report ───────────────────────────────────────────────────────────

  useEffect(() => {
    if (!reportId) return;
    setLoading(true);
    (async () => {
      try {
        const r = await api.getBusinessReport(reportId);
        setReport(r);
        // Restore saved column order from layout_config (reset if none saved)
        const savedOrder = r.layout_config?.column_order;
        setColumnOrder(Array.isArray(savedOrder) && savedOrder.length > 0 ? savedOrder : null);
        // Chart view: honour the author's saved default view (chart_config
        // is parsed defensively — garbage silently means "no chart").
        const storedChart = parseChartConfig(r.layout_config?.chart_config);
        if (storedChart?.default_view === 'chart' || storedChart?.default_view === 'both') {
          setViewMode(storedChart.default_view);
        }
        // Init param values with defaults (resolve @TODAY etc. for date
        // types; a business-calendar token is resolved by the SERVER)
        const defaults: Record<string, any> =
          await resolveParamDefaults(r.parameters || [], api.previewDateToken);
        // Init slicer values
        const sv: Record<string, any[]> = {};
        for (const colId of (r.slicer_column_ids || [])) {
          sv[String(colId)] = [];
        }
        // Load dataset columns + drill hierarchies.
        //
        // 2026-08-25 — dataset_id is a SENTINEL 0 for reports that are not
        // dataset-backed: business_reports_api.py:937-942 stores 0 for
        // raw_sql, published_view and federation_view. This called
        // getDataset(0) unguarded, inside the main load try, so GET
        // /api/datasets/0 returned 404, the outer catch matched "404" and
        // rendered "Report not found. It may have been deleted." — about a
        // report that exists, is published, and executes perfectly well. The
        // message was not merely unhelpful, it was false, and it sent people
        // looking for a deletion that never happened.
        //
        // A dataset-less report has no dataset columns by definition, so the
        // honest value is an empty list, not an error.
        // 2026-09-25: read through the REPORT (its view rule), not GET
        // /api/datasets/{id} -- that refuses a consumer of a published report
        // whose dataset is unpublished, and the refusal landed in this try's
        // catch as "Failed to load report" about a report they may open.
        const ds = r.dataset_id ? await api.getBusinessReportDatasetMeta(r.id ?? reportId) : null;
        const cols = ds?.columns || [];
        setDatasetColumns(cols);
        // Resolve drill hierarchy levels to physical column names
        let resolvedLevels: Array<{ column_name: string; label: string }> = [];
        if (r.drill_hierarchy_id && ds?.hierarchies) {
          const h = (ds.hierarchies as any[]).find((h: any) => h.id === r.drill_hierarchy_id);
          if (h?.levels) {
            resolvedLevels = (h.levels as any[]).map((lv: any) => {
              const col = cols.find((c: any) => c.id === lv.column_id);
              return { column_name: col?.physical_name || '', label: lv.label || col?.friendly_name || '' };
            }).filter((lv: any) => lv.column_name);
            setDrillHierarchyLevels(resolvedLevels);
            setDrillState({ level: 0, filters: [], hierarchy_levels: resolvedLevels });
          }
        }
        // Session restore — last params / slicers / drill path for this
        // report (per-session convenience; anything invalid is ignored).
        try {
          const raw = sessionStorage.getItem(`qs-br-viewstate-${reportId}`);
          const saved = raw ? JSON.parse(raw) : null;
          if (saved && typeof saved === 'object') {
            if (saved.paramValues && typeof saved.paramValues === 'object') {
              for (const p of (r.parameters || [])) {
                if (saved.paramValues[p.name] !== undefined) {
                  defaults[p.name] = saved.paramValues[p.name];
                }
              }
            }
            if (saved.slicerValues && typeof saved.slicerValues === 'object') {
              for (const k of Object.keys(sv)) {
                if (Array.isArray(saved.slicerValues[k])) sv[k] = saved.slicerValues[k];
              }
            }
            // Chart/table choice persists per session (only meaningful when
            // a chart is configured; harmless otherwise).
            if (saved.viewMode === 'chart' || saved.viewMode === 'table' || saved.viewMode === 'both') {
              setViewMode(saved.viewMode);
            }
            // Drill path only restores when the hierarchy is unchanged.
            const sig = resolvedLevels.map(l => l.column_name).join('|');
            if (sig && saved.drillSignature === sig
                && saved.drillState && typeof saved.drillState.level === 'number'
                && Array.isArray(saved.drillState.filters)) {
              setDrillState({
                level: Math.min(saved.drillState.level, resolvedLevels.length),
                filters: saved.drillState.filters,
                hierarchy_levels: resolvedLevels,
              });
              if (typeof saved.expandedLevels === 'number') {
                setExpandedLevels(Math.max(0, saved.expandedLevels));
              }
            }
          }
        } catch { /* corrupt session state — fall back to defaults */ }
        setParamValues(defaults);
        setSlicerValues(sv);
        viewStateRestored.current = true;
        // Auto-open probe — fire-and-forget so a slow/dead backend never
        // delays first paint.  Probes with the SESSION-RESTORED params (the
        // values the user will actually run), skipped when a required
        // parameter has no value (executing would just error).
        // 2026-11-01 (the owner: "never a blank page on open"): a stored result
        // for these values opens at once; with none, the report RUNS with them.
        if (!autoOpenAttempted.current) {
          autoOpenAttempted.current = true;
          const isEmptyVal = (v: any) =>
            v == null || v === '' || (Array.isArray(v) && v.length === 0);
          const missingRequired = (r.parameters || []).some((p: any) =>
            p.is_required && isEmptyVal(defaults[p.name]) && isEmptyVal(p.default_value));
          if (!missingRequired) {
            const probeParams = { ...defaults };
            api.probeLatestReportInstance(reportId, probeParams)
              .then((row: any) => setPendingAutoOpen({
                params: probeParams,
                provisional: parseInstanceProbe(row),
              }))
              .catch(() => setPendingAutoOpen({ params: probeParams, provisional: null }));
          }
        }
      } catch (err: any) {
        const msg = (err?.message || '').toLowerCase();
        if (msg.includes('access denied') || msg.includes('403')) setError('Access denied: you do not have permission to view this report.');
        else if (msg.includes('not found') || msg.includes('404')) setError('Report not found. It may have been deleted.');
        else setError('Failed to load report');
      } finally {
        setLoading(false);
      }
    })();
  }, [reportId]);

  // Phase 114-L: Load comment count
  // Comments are an admin/analyst feature (report_comments_api:
  // require_role("admin", "analyst")); a viewer's page asked anyway and got
  // 403s (2026-09-25 viewer crawl).
  useEffect(() => {
    if (!reportId || !canAuthorReports(user)) return;
    api.countReportComments(reportId).then((r: any) => setCommentCount(r?.count || 0)).catch(() => {});
  }, [reportId, user]);

  // Session save — persists params / slicers / drill path per report.  Only
  // after the restore pass, so defaults never clobber a saved state.
  useEffect(() => {
    if (!reportId || !viewStateRestored.current) return;
    try {
      sessionStorage.setItem(`qs-br-viewstate-${reportId}`, JSON.stringify({
        paramValues,
        slicerValues,
        drillState: { level: drillState.level, filters: drillState.filters },
        expandedLevels,
        viewMode,
        drillSignature: drillHierarchyLevels.map(l => l.column_name).join('|'),
      }));
    } catch { /* sessionStorage disabled/full — memory is best-effort */ }
  }, [reportId, paramValues, slicerValues, drillState, expandedLevels, drillHierarchyLevels, viewMode]);

  // Fire the auto-open exactly once, after the report state has committed
  // (handleExecute reads `report`, which is not yet set inside the load
  // effect).  Guarded against double-execution: consumed-then-checked, so
  // a user who already pressed Execute before the probe resolved wins and
  // the auto-open silently stands down.
  useEffect(() => {
    if (!pendingAutoOpen || !report) return;
    const { params, provisional } = pendingAutoOpen;
    setPendingAutoOpen(null);
    if (runStarted.current || executing || executionResult) return; // the user beat us to it
    handleExecute(params, { provisionalInstance: provisional ?? undefined });
  }, [pendingAutoOpen, report]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Parameter values: the report's own LOV route (ReportParamControl) ────
  const paramValuesFetch = useCallback(
    (body: { parameter_id: number; parent_values: Record<string, any> }) =>
      api.getBusinessReportParamValues(reportId, body),
    [reportId]);

  // ── Column name resolver ──────────────────────────────────────────────────

  const getColDisplayName = useCallback((colId: number): string => {
    const col = datasetColumns.find((c: any) => c.id === colId);
    return col ? (col.friendly_name || col.physical_name) : `Col #${colId}`;
  }, [datasetColumns]);

  // 2026-10-26 -- the report canvas (layout_config.canvas).  Only a canvas
  // with a tile BESIDE the report's own table changes the page.
  // 2026-10-30 -- EVERY report is a canvas: one with none stored opens as ONE
  // tile, its own table (derived here, nothing written) -- the same page as before.
  const canvas = useMemo(() => effectiveCanvas(report?.layout_config), [report?.layout_config]);
  // 2026-11-01 (FD-03 / FD-10): this person's own arrangement, when the author allows it
  const mine = useViewerLayout(reportId, !!report?.layout_config?.viewers_may_rearrange);
  const shownCanvas = useMemo(() => (mine.allowed ? applyViewerLayout(canvas, mine.layout) : canvas), [canvas, mine.allowed, mine.layout]);
  const canvasOn = canvas.tiles.some(t => t.kind !== 'report');
  // linked canvas tiles (2026-10-30): the clicked values, read by the exports
  const [canvasLinkStore] = useState(() => createLinkStore());
  // the linked-tile clicks in force, for the canvas ACTIONS (a 'from: link' value sends the chip)
  const canvasLinks = useSyncExternalStore(canvasLinkStore.subscribe, canvasLinkStore.get, canvasLinkStore.get);
  // the clicks that filter the report's OWN table: its pages are then the matching rows
  // of the stored result (the server's report_table_links.py) -- undefined = as before
  const tableLinks = useMemo(() => (canvasOn ? reportTableLinks(canvasLinks, canvas) : []), [canvasOn, canvasLinks, canvas]);
  const tableLinksParam = useMemo(() => linksExportParam(tableLinks), [tableLinks]);
  const tableLinksRef = useRef<string | undefined>(undefined);
  tableLinksRef.current = tableLinksParam;
  // what the server said about the table under the links (a refusal, or "does not follow")
  const [tableLinkNote, setTableLinkNote] = useState<{ kind: 'refused' | 'not_following'; words: string } | null>(null);
  const canvasCols = useMemo(() => new Map<number, CanvasColumn>(datasetColumns.map((c: any) => [Number(c.id), {
    id: Number(c.id), physical_name: c.physical_name, label: c.friendly_name || c.physical_name,
    data_type: c.data_type, column_type: c.column_type, aggregation: c.aggregation,
    format_pattern: c.format_pattern,
  } as CanvasColumn])), [datasetColumns]);
  const canvasGrouped = useMemo(() => rowsAreGrouped([...canvasCols.values()], false), [canvasCols]);

  const [historyAnchor, setHistoryAnchor] = useState<HTMLElement | null>(null);
  // 2026-11-01 -- the separate "Report controls" form is gone: the parameters are the
  // BAND's cells (reports/ReportBand.tsx) and every other action is in the More menu,
  // so nothing above the report needs hiding.
  const controlsOpen = true;
  const [moreAnchor, setMoreAnchor] = useState<HTMLElement | null>(null);
  // 2026-11-03 -- "View in another theme" (the owner): ANY viewer may look at the report
  // in another theme.  Only this viewer's screen changes (and the Excel / PDF it downloads);
  // the report's saved layout is never written.  The pick is a theme NAME, resolved by
  // resolveTheme (an unknown name = the report's own theme, as the server does).
  const myViewThemeKey = viewThemeKey((user as any)?.username, reportId);
  const [viewTheme, setViewTheme] = useState<string | null>(() => readViewTheme(myViewThemeKey));
  useEffect(() => { setViewTheme(readViewTheme(myViewThemeKey)); }, [myViewThemeKey]);
  const [themeDialogOpen, setThemeDialogOpen] = useState(false);
  // the organisation's own themes: read when the gallery opens, or when the remembered
  // pick is not a shipped name (it may be one of the library's)
  const [themeLibrary, setThemeLibrary] = useState<Record<string, any> | null>(null);
  const needLibrary = themeDialogOpen || (!!viewTheme && !SHIPPED_THEMES[shippedThemeName(viewTheme)]);
  useEffect(() => {
    if (themeLibrary !== null || !needLibrary) return undefined;
    let live = true;
    const list = (api as any).listReportThemes;
    if (typeof list !== 'function') { setThemeLibrary({}); return undefined; }
    Promise.resolve(list()).then((r: any) => {
      const lib: Record<string, any> = {};
      for (const t of r?.library || []) if (t && typeof t.name === 'string') lib[t.name] = t.theme;
      if (live) setThemeLibrary(lib);
    }).catch(() => { if (live) setThemeLibrary({}); /* the shipped themes are still offered */ });
    return () => { live = false; };
  }, [needLibrary, themeLibrary]);
  const viewThemeKnown = !!viewTheme && (!!SHIPPED_THEMES[shippedThemeName(viewTheme)] || !!themeLibrary?.[viewTheme]);
  const pickViewTheme = (name: string | null) => { setViewTheme(name); writeViewTheme(myViewThemeKey, name); };
  const [bookmarksAnchor, setBookmarksAnchor] = useState<HTMLElement | null>(null);
  const [diagOpenKey, setDiagOpenKey] = useState(0);
  // the publishing actions (Republish, Unpublish, Archive, Certify ...) live in the ONE More menu
  const [lifecycleItems, setLifecycleItems] = useState<LifecycleMenuAction[]>([]);
  // the Data version listing, read ONCE: the band draws its cell only when the report
  // reads a source that keeps versions
  const [dataVersions, setDataVersions] = useState<ReportDataVersions | null>(null);
  useEffect(() => {
    let live = true;
    const get = (api as any).getReportDataVersions;
    if (!reportId || typeof get !== 'function') return undefined;
    Promise.resolve(get(reportId)).then((a: ReportDataVersions) => { if (live) setDataVersions(a); }).catch(() => { /* no cell */ });
    return () => { live = false; };
  }, [reportId]);

  const getColPhysicalName = useCallback((colId: number): string => {
    const col = datasetColumns.find((c: any) => c.id === colId);
    return col?.physical_name || `col_${colId}`;
  }, [datasetColumns]);

  // ── Build engine input ────────────────────────────────────────────────────

  const sectionDefs: SectionDef[] = useMemo(() => {
    if (!report?.section_definitions) return [];
    return report.section_definitions.map((s: any) => ({
      ...s,
      break_column_name: getColPhysicalName(s.break_column_id),
      subtotal_measure_names: (s.subtotal_measure_ids || []).map((id: number) => getColPhysicalName(id)),
    }));
  }, [report?.section_definitions, getColPhysicalName]);

  const runningCalcs: RunningCalcDef[] = useMemo(() => {
    if (!report?.running_calculations) return [];
    return report.running_calculations.map((c: any) => ({
      ...c,
      measure_col_name: getColPhysicalName(c.measure_col_id),
      partition_col_name: c.partition_col_id ? getColPhysicalName(c.partition_col_id) : undefined,
    }));
  }, [report?.running_calculations, getColPhysicalName]);

  // Resolve style config from report's layout_config (or use defaults)
  const styleConfig: StyleConfig = useMemo(() => {
    const sc = report?.layout_config?.style_config;
    return sc ? { ...DEFAULT_STYLE, ...sc } : DEFAULT_STYLE;
  }, [report?.layout_config]);

  const rowTypeStyles = useMemo(() => getRowStyles(styleConfig), [styleConfig]);
  // 2026-10-24 (the owner: "conditional formatting does not work on the
  // report") -- the author's rules, applied to the cells ON SCREEN with the
  // same evaluator the preview and the exports use (they were applied only
  // in those two, never here).
  const formatRules = useMemo(() => draftFromReport(report || {}).rules, [report]);

  // Map slicer column IDs to physical names for the engine
  const slicerByName = useMemo(() => {
    const mapped: Record<string, any[]> = {};
    for (const [colIdStr, vals] of Object.entries(slicerValues)) {
      const physName = getColPhysicalName(Number(colIdStr));
      mapped[physName] = vals;
    }
    return mapped;
  }, [slicerValues, getColPhysicalName]);

  // Measure column physical names + aggregation configs for client-side drill grouping
  const measureColNames = useMemo(() =>
    datasetColumns
      .filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi')
      .map((c: any) => c.physical_name),
    [datasetColumns]
  );
  const measureAggConfigs = useMemo(() =>
    datasetColumns
      .filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi')
      .map((c: any) => ({
        column: c.physical_name,
        aggregation: (c.aggregation || 'sum') as any,
      })),
    [datasetColumns]
  );

  // Drill-capable report (hierarchy resolved)
  const hasDrill = Boolean(report?.drill_hierarchy_id) && drillHierarchyLevels.length > 0;

  // ── Chart view (2026-08-09) ───────────────────────────────────────────────
  // The saved visualisation config, resolved to physical columns.  The chart
  // is answered by the SAME cube machinery as the table (one bounded drill
  // query per gesture) — see ReportChartView.
  const chartConfig = useMemo(
    () => resolveChartConfig(parseChartConfig(report?.layout_config?.chart_config), datasetColumns),
    [report?.layout_config, datasetColumns]);
  const chartActive = Boolean(chartConfig) && (viewMode === 'chart' || viewMode === 'both')
    && Boolean(executionResult);
  // Rows for the chart's availability fallback (cube 404 = no artifact):
  // ONLY when the FULL result is provably in the browser — a single page
  // would aggregate into a confidently wrong chart.
  const chartClientRows = useMemo(() => {
    if (allRows.length > 0 && !allRowsLoading) return allRows;
    if (rawRows.length > 0 && totalRows > 0 && rawRows.length >= totalRows) return rawRows;
    return null;
  }, [allRows, allRowsLoading, rawRows, totalRows]);

  // Reporting rewire Phase 3: the mode is driven by the SERVER's engine
  // verdict, not by drill_hierarchy_id alone.
  //  - engine:"server" → gestures go to /cube; fetchAllRows must NOT run.
  //  - engine:"client" or absent → byte-identical to the pre-rewire flow.
  const serverEngineActive = engineVerdict === 'server' && hasDrill;

  // Client-side mode: drill report with all rows loaded (below-threshold path)
  const isClientSide = hasDrill && !serverEngineActive
    && allRows.length > 0 && !allRowsLoading;

  const engineOutput = useReportEngine({
    rows: isClientSide ? allRows : rawRows,
    columns: resultColumns,
    sectionDefs,
    runningCalcs,
    slicerValues: slicerByName,
    drillState: isClientSide ? drillState : { level: 0, filters: [] },
    drillHierarchyLevels: isClientSide ? drillHierarchyLevels : undefined,
    measureColumns: isClientSide ? measureColNames : undefined,
    measureAggConfigs: isClientSide ? measureAggConfigs : undefined,
    expandedLevels: isClientSide ? expandedLevels : undefined,
    sortColumn: isClientSide ? (sortColumn ?? undefined) : undefined,
    sortDirection: isClientSide ? sortDirection : undefined,
  });

  // ── Detect column types from first data row ───────────────────────────────

  const colTypeMap = useMemo((): Record<string, string> => {
    const cols = serverEngineActive && cubeColumns.length > 0
      ? cubeColumns
      : resultColumns.concat(engineOutput.calculatedColumns);
    const sampleRow = (serverEngineActive && cubeRows.length > 0
      ? cubeRows[0]
      : (allRows.length > 0 ? allRows[0] : rawRows[0])) || {};
    const map: Record<string, string> = {};
    for (const col of cols) {
      map[col] = detectColType(col, sampleRow[col]);
    }
    return map;
  }, [rawRows, allRows, resultColumns, engineOutput.calculatedColumns,
      serverEngineActive, cubeColumns, cubeRows]);

  // ── Grand totals computation (Phase 81 FIX 9) ────────────────────────────
  // Use engine grand totals when available (respects slicer filters), fall back to local computation

  const grandTotals = useMemo(() => {
    // Server-engine mode: totals come from the cube (computed over the FULL
    // artifact, slicer-aware) — the client engine only ever saw one page.
    if (serverEngineActive) {
      return cubeGrandTotals && Object.keys(cubeGrandTotals).length > 0
        ? cubeGrandTotals : null;
    }
    // Engine computes slicer-aware grand totals — prefer them when available
    if (engineOutput.grandTotals && Object.keys(engineOutput.grandTotals).length > 0) {
      return engineOutput.grandTotals;
    }
    const allCols = resultColumns.concat(engineOutput.calculatedColumns);
    const dataRows = rawRows;
    if (dataRows.length === 0) return null;
    const hasNumeric = allCols.some(c => ['integer', 'float'].includes(colTypeMap[c] || ''));
    if (!hasNumeric) return null;

    const totals: Record<string, any> = {};
    for (const col of allCols) {
      const t = colTypeMap[col];
      if (t === 'integer' || t === 'float') {
        const sum = dataRows.reduce((acc: number, row: any) => {
          const v = row[col];
          return acc + (typeof v === 'number' ? v : 0);
        }, 0);
        totals[col] = sum;
      } else {
        totals[col] = null;
      }
    }
    return totals;
  }, [rawRows, resultColumns, engineOutput.calculatedColumns, engineOutput.grandTotals,
      colTypeMap, serverEngineActive, cubeGrandTotals]);

  // ── Sort column handler (Phase 81 FIX 3) ─────────────────────────────────

  const handleSortColumn = (col: string) => {
    setSortColumn(prev => {
      if (prev !== col) {
        setSortDirection('asc');
        return col;
      }
      setSortDirection(d => {
        if (d === 'asc') return 'desc';
        setSortColumn(null);
        return null;
      });
      return prev;
    });
    setPage(0);
  };

  // ── Fetch page of results (Phase 81 FIX 2) ───────────────────────────────

  /**
   * Adopt what a page said about itself.
   *
   * A progressive page carries the pin to echo next, how much of the build
   * it covers, and whether more is coming.  An ordinary page carries none of
   * those keys — and CLEARING the progressive state on such a page is the
   * point: once the merged file answers, "still building" must stop being
   * shown, and the pin must stop being sent (it would 409).
   */
  const adoptPageDisclosure = useCallback((data: any) => {
    if (data?.progressive === true) {
      if (data.dataset_version) {
        pinRef.current = data.dataset_version;
        setDatasetVersion(data.dataset_version);
      }
      setProgressive({
        building: data.building === true,
        moreExpected: data.more_expected === true,
        totalMode: data.total_mode === 'exact' ? 'exact' : 'at_least',
        partsReady: Number(data.parts_ready ?? 0),
        partsPinned: Number(data.parts_pinned ?? 0),
        sortScope: typeof data.sort_scope === 'string' ? data.sort_scope : null,
        refreshAvailable: data.refresh_available === true,
        refreshReason: typeof data.refresh_reason === 'string' ? data.refresh_reason : null,
      });
    } else {
      pinRef.current = null;
      setDatasetVersion(null);
      setProgressive(null);
    }
  }, []);

  /**
   * What the STATUS poll says about the build behind the rows on screen.
   *
   * Two numbers come from the server and neither is computed here:
   * `rows_ready` (rows the build has made durable) and `total_rows` on the
   * page (rows in the PINNED prefix being shown).  When the first has
   * overtaken the second, rows exist that this snapshot does not contain —
   * which is the ``more_rows`` refresh, and the only way to notice it
   * without making the user click first (a page's own `refresh_available`
   * can only arrive on a request they have not made).  The pin is NEVER
   * taken from here: the status payload's `dataset_version` names the whole
   * current manifest, not this session's prefix.
   */
  const setProgressiveProgress = useCallback((statusRes: any) => {
    const ready = Number(statusRes.rows_ready ?? 0);
    setRowsReady(ready);
    setProgressive(prev => {
      const building = statusRes.build_complete !== true;
      const behind = ready > pinnedRowsRef.current;
      return {
        building,
        moreExpected: building,
        totalMode: statusRes.total_mode === 'exact' ? 'exact' : 'at_least',
        partsReady: Number(statusRes.parts_ready ?? prev?.partsReady ?? 0),
        partsPinned: prev?.partsPinned ?? 0,
        sortScope: prev?.sortScope ?? null,
        refreshAvailable: behind || (prev?.refreshAvailable ?? false),
        refreshReason: behind ? 'more_rows' : (prev?.refreshReason ?? null),
      };
    });
  }, []);

  const fetchResultsPage = useCallback(async (
    execResult: any,
    targetPage: number,
    targetPageSize: number,
    targetSortCol: string | null,
    targetSortDir: string | null,
  ) => {
    if (!execResult?.execution_id) return;
    // ONE request, at one pin.  Returns the page so the caller can react to
    // a server-side refusal without re-reading React state that has not
    // committed yet.
    const load = async (pin: string | null) => {
      // 2026-10-30: the clicked values of the canvas's other tiles (the table
      // follows them) and Arrow for an unpinned page (services/api/pageArrow.ts;
      // the server keeps a page with an exact DECIMAL in JSON).  Neither = the
      // request exactly as before.
      const links = tableLinksRef.current;
      const fast = (api as any).getBusinessReportPagedResultsFast;
      const data = !pin && fast
        ? await fast(reportId, execResult.execution_id, targetPage + 1, targetPageSize, targetSortCol, targetSortDir, links)
        : links
          ? await api.getBusinessReportPagedResults(reportId, execResult.execution_id, targetPage + 1, targetPageSize,
              targetSortCol, targetSortDir, pin, links)
          : await api.getBusinessReportPagedResults(
              reportId,
              execResult.execution_id,
              targetPage + 1,  // MUI is 0-indexed, API is 1-indexed
              targetPageSize,
              targetSortCol,
              targetSortDir,
              pin,
            );
      // A page the server REFUSED to serve is not a page of zero rows.  The
      // backend refuses a deep page that carries no pin over a still-growing
      // build (it would draw rows from a different prefix than the page
      // before it) and names the remedy: restart the session at page 1 with
      // the pin it hands back.  Do exactly that rather than rendering the
      // refusal as an empty result.  Never reached from this component's own
      // paging, which always echoes the pin — this is the backstop that
      // makes that guarantee not depend on this file staying correct.
      if (data?.unpinned_page_refused === true && data.dataset_version) {
        pinRef.current = data.dataset_version;
        setDatasetVersion(data.dataset_version);
        const restartPage = Math.max(0, Number(data.restart_from_page ?? 1) - 1);
        setPage(restartPage);
        const restarted = await api.getBusinessReportPagedResults(
          reportId, execResult.execution_id, restartPage + 1, targetPageSize,
          targetSortCol, targetSortDir, data.dataset_version);
        applyPageRows(restarted);
        return;
      }
      applyPageRows(data);
    };
    const applyPageRows = (data: any) => {
      // the table under the canvas's clicked values: does it follow them, and if not, why
      setTableLinkNote(data?.linked && data.linked.applied === false && data.linked.words
        ? { kind: 'not_following', words: String(data.linked.words) } : null);
      const t = pageTransportOf(data);
      if (t) recordRenderStats({ tileId: 'report', renderer: 'table', rows: (data.rows || []).length,
        sourceRows: Number(data.total_rows ?? 0), marks: (data.rows || []).length, bytes: t.bytes, format: t.format,
        formatReason: t.reason, renderMs: null, at: Date.now() });
      setRawRows(data.rows || []);
      setResultColumns(data.columns || []);
      setTotalRows(data.total_rows ?? (data.rows?.length || 0));
      setFormatCutoffs(data.format_cutoffs || {});
      pinnedRowsRef.current = Number(data.total_rows ?? 0);
      // Truncation metadata travels with the page when the backend knows it.
      if (data.truncated !== undefined) setTruncated(data.truncated);
      if (data.row_limit !== undefined) setTruncRowLimit(data.row_limit);
      adoptPageDisclosure(data);
    };
    const pinInUse = pinRef.current;
    try {
      await load(pinInUse);
      setSnapshotMoved(null);
    } catch (err: any) {
      // 409 result_snapshot_moved — the snapshot this session was reading is
      // no longer servable.  Drop the pin and ask again, and tell the user
      // WHICH of the two it was IN THE SERVER'S OWN WORDS: `consolidated`
      // means the build finished and the same answer is now one file (their
      // rows are intact); `rebuilt` means a different run replaced it and
      // the rows they were reading are gone.  Composing one message for both
      // would be inventing a reason.
      if (isSnapshotMoved(err) && pinInUse) {
        pinRef.current = null;
        setDatasetVersion(null);
        setSnapshotMoved({
          reason: String(err.detail?.reason || ''),
          message: String(err.detail?.message || err.message || ''),
        });
        try {
          await load(null);
          return;
        } catch (retryErr: any) {
          setError(describeExecutionError(retryErr));
          return;
        }
      }
      // 2026-10-30: the table cannot follow the clicked values (a field the run
      // lacks, a result with no stored file, a run still building) -- say so ON
      // the table and show no rows; never every row under a filter the user set
      if (tableLinksRef.current && (err?.status === 409 || err?.status === 422)) {
        setRawRows([]);
        setTotalRows(0);
        setTableLinkNote({ kind: 'refused', words: String(err?.payload?.message || err?.detail?.message || err?.message || '') });
        return;
      }
      // Expired executions are the common case here — name the next step.
      setError(describeExecutionError(err));
    }
  }, [reportId, adoptPageDisclosure]);

  /**
   * "Refresh" on a progressive result — the operator's ask, verbatim: "if
   * all chunks merged ask users to click on refresh".
   *
   * Drops the pin and re-reads page 1 of whatever the result IS now: a
   * bigger prefix while the build is still running, the merged file once it
   * has landed.  It does NOT re-run the query — the rows already exist —
   * which is what separates it from the as-of banner's Refresh (that one
   * forces a live execution).
   */
  const handleProgressiveRefresh = useCallback(async () => {
    if (!executionResult?.execution_id) return;
    pinRef.current = null;
    setDatasetVersion(null);
    setSnapshotMoved(null);
    if (page !== 0) {
      // The page effect re-fetches, and it now reads a cleared pin.
      setPage(0);
      return;
    }
    await fetchResultsPage(executionResult, 0, pageSize, sortColumn, sortDirection);
  }, [executionResult, page, pageSize, sortColumn, sortDirection, fetchResultsPage]);

  // Fetch all rows for client-side drill (runs once after execution for drill reports)
  const fetchAllRows = useCallback(async (execResult: any, knownTotalRows: number) => {
    if (!execResult?.execution_id || knownTotalRows <= 0) return;
    setAllRowsLoading(true);
    try {
      const fetchSize = 5000;
      const totalPages = Math.ceil(knownTotalRows / fetchSize);
      const allFetched: any[] = [];
      // Fetch in batches of 4 for controlled concurrency
      for (let i = 0; i < totalPages; i += 4) {
        const batch = [];
        for (let j = i; j < Math.min(i + 4, totalPages); j++) {
          // 2026-10-30: the table follows the canvas's clicked values here too
          const links = tableLinksRef.current;
          if (links) {
            batch.push(api.getBusinessReportPagedResults(reportId, execResult.execution_id, j + 1, fetchSize,
                                                         null, null, pinRef.current, links));
            continue;
          }
          batch.push(
            // THE OTHER PAGING CALLER, pinned on the same terms.  These
            // batches are pages 1..N of ONE dataset and are concatenated into
            // a single client-side result — if they were drawn from a growing
            // parts dataset without the pin, the drill grid would be built
            // out of two snapshots.  Null (every ordinary report) sends
            // nothing and is byte-identical to before.
            api.getBusinessReportPagedResults(reportId, execResult.execution_id,
                                              j + 1, fetchSize, null, null,
                                              pinRef.current)
          );
        }
        const results = await Promise.all(batch);
        for (const data of results) {
          allFetched.push(...(data.rows || []));
        }
      }
      setAllRows(allFetched);
    } catch (err: any) {
      console.error('Failed to fetch all rows for client-side drill:', err);
      setError('Failed to load all rows for instant drill-down. Drill functionality may be limited.');
    } finally {
      setAllRowsLoading(false);
    }
  }, [reportId]);

  // Re-fetch when page, pageSize, or sort changes (server-side pagination
  // only — in server-ENGINE mode the cube effect below owns paging).
  useEffect(() => {
    if (executionResult && !isClientSide && !serverEngineActive) {
      fetchResultsPage(executionResult, page, pageSize, sortColumn, sortDirection);
    }
  }, [page, pageSize, sortColumn, sortDirection]); // eslint-disable-line react-hooks/exhaustive-deps

  // 2026-10-30 -- a click on another canvas tile (or clearing it) re-reads the
  // table: its pages are the matching rows of the SAME stored result -- no new
  // run.  The server-engine table re-asks through buildCubeLevelBody.
  const linksSeen = useRef<string | undefined>(undefined);
  useEffect(() => {
    if (linksSeen.current === tableLinksParam) return;
    linksSeen.current = tableLinksParam;
    if (!tableLinksParam) setTableLinkNote(null);
    if (!executionResult?.execution_id || serverEngineActive) return;
    if (hasDrill && Number(executionResult.total_rows) > 0) fetchAllRows(executionResult, executionResult.total_rows);
    if (page !== 0) { setPage(0); return; }     // the page effect above reads the new links
    fetchResultsPage(executionResult, 0, pageSize, sortColumn, sortDirection);
  }, [tableLinksParam]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Server-engine mode: every gesture is ONE bounded /cube query ──────────
  // (reporting rewire Phase 3).  Drill / expand / slicer / sort / page all
  // land here; fetchAllRows never runs in this mode.  The client sends STATE
  // only — column semantics live in the stored report + dataset rows.

  const buildCubeLevelBody = useCallback(() => {
    const levels = drillHierarchyLevels;
    const level = Math.min(drillState.level, Math.max(0, levels.length - 1));
    const endLevel = Math.min(level + expandedLevels, levels.length - 1);
    // At the deepest level the client engine shows detail rows; the server
    // equivalent is the finest remaining hierarchy grain (leaf "show detail"
    // via the paged endpoint + filters is a follow-up — see arch doc §2.4).
    const dimensions = levels.slice(level, endLevel + 1).map(l => l.column_name);
    const slicers: Record<string, any[]> = {};
    for (const [col, vals] of Object.entries(slicerByName)) {
      if (vals && vals.length > 0) slicers[col] = vals;
    }
    const base: any = {
      dimensions,
      measures: measureAggConfigs.map(m => ({ column: m.column, aggregation: m.aggregation })),
      path_filters: drillState.filters.map(f => ({ column: f.column, value: f.value })),
      slicers,
      sort_column: sortColumn ?? null,
      sort_direction: sortDirection ?? null,
      page: page + 1,           // MUI 0-indexed → API 1-indexed
      page_size: pageSize,
    };
    if (runningCalcs.length > 0) {
      base.operation = 'running_calcs';
      base.calcs = runningCalcs.map(c => ({
        name: c.name,
        calc_type: c.calc_type,
        measure_col_name: c.measure_col_name,
        partition_col_name: c.partition_col_name ?? null,
      }));
    } else {
      base.operation = 'drill';
    }
    // 2026-10-30: the canvas's clicked values filter the table here too (the
    // tiles' rule: slicers + clicked paths); none = the body exactly as before
    return tableLinks.length ? withLinkSlicers(base, tableLinks, canvasCols) : base;
  }, [drillHierarchyLevels, drillState, expandedLevels, slicerByName,
      measureAggConfigs, runningCalcs, sortColumn, sortDirection, page, pageSize, tableLinks, canvasCols]);

  useEffect(() => {
    if (!serverEngineActive || !executionResult?.execution_id) return;
    let cancelled = false;
    const execId = executionResult.execution_id;

    (async () => {
      setCubeLoading(true);
      setCubeError('');
      try {
        const body = buildCubeLevelBody();
        let pageRes: any;
        let usedMeasures: Array<{ column: string; aggregation: string }> = body.measures;
        try {
          pageRes = await api.queryReportCube(reportId, execId, body);
          if (!cancelled) setRefusedMeasures([]);
        } catch (err: any) {
          if (err?.status === 422 && err?.detail?.error === 'non_additive_measures') {
            // Correctness GATE: the server refuses measures it cannot compute
            // exactly at this grain.  Surface each one BY NAME with its
            // reason (never silently drop, never show a wrong number), then
            // re-query for the measures that remain computable.
            const refused: Array<{ column: string; reason: string }> =
              err.detail.refused || [];
            if (!cancelled) setRefusedMeasures(refused);
            const refusedCols = new Set(refused.map(r => r.column));
            usedMeasures = body.measures.filter((m: any) => !refusedCols.has(m.column));
            const retry: any = { ...body, measures: usedMeasures };
            if (retry.operation === 'running_calcs') {
              retry.calcs = (retry.calcs || []).filter(
                (c: any) => !refusedCols.has(c.measure_col_name));
              if (retry.calcs.length === 0) {
                retry.operation = 'drill';
                delete retry.calcs;
              }
            }
            pageRes = await api.queryReportCube(reportId, execId, retry);
          } else {
            throw err;
          }
        }
        if (cancelled) return;
        setCubeRows((pageRes.rows || []).map((r: any) => ({ ...r, _rowType: 'data' as const })));
        setCubeColumns(pageRes.columns || []);
        setCubeTotalRows(pageRes.total_rows ?? (pageRes.rows?.length || 0));

        // Grand totals = the same query at grain () — computed over the FULL
        // artifact (slicer-aware), with the measures that survived the gate.
        if (usedMeasures.length > 0) {
          try {
            const gt = await api.queryReportCube(reportId, execId, {
              operation: 'drill',
              dimensions: [],
              measures: usedMeasures,
              path_filters: body.path_filters,
              slicers: body.slicers,
              ...(body.link_paths ? { link_paths: body.link_paths } : {}),
              page: 1,
              page_size: 1,
            });
            if (!cancelled) setCubeGrandTotals(gt.rows?.[0] || null);
          } catch { if (!cancelled) setCubeGrandTotals(null); }
        } else if (!cancelled) {
          setCubeGrandTotals(null);
        }
      } catch (err: any) {
        if (cancelled) return;
        if (err?.status === 404) {
          // Availability fail-open (never numbers): no artifact behind /cube
          // → fall back to the client engine exactly as before the rewire.
          setEngineVerdict('client');
          if (executionResult?.total_rows > 0) {
            fetchAllRows(executionResult, executionResult.total_rows);
          }
        } else {
          setCubeError(err?.message || 'Server drill query failed');
        }
      } finally {
        if (!cancelled) setCubeLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [serverEngineActive, executionResult, buildCubeLevelBody, reportId, fetchAllRows]);

  // Slicer OPTIONS in server mode — DISTINCT per slicer column over the
  // current drill path (client mode reads them from the fully-fetched rows).
  useEffect(() => {
    if (!serverEngineActive || !executionResult?.execution_id) return;
    const ids: number[] = report?.slicer_column_ids || [];
    if (ids.length === 0) return;
    let cancelled = false;
    const execId = executionResult.execution_id;
    (async () => {
      const opts: Record<string, string[]> = {};
      for (const colId of ids) {
        const phys = getColPhysicalName(colId);
        try {
          const res = await api.queryReportCube(reportId, execId, {
            operation: 'slicer_options',
            column: phys,
            path_filters: drillState.filters.map(f => ({ column: f.column, value: f.value })),
          });
          opts[phys] = (res.options || []).map((v: any) => String(v));
        } catch { /* options are presentation — the slicer just shows none */ }
      }
      if (!cancelled) setServerSlicerOptions(opts);
    })();
    return () => { cancelled = true; };
  }, [serverEngineActive, executionResult, drillState.filters,
      report?.slicer_column_ids, getColPhysicalName, reportId]);

  // ── Execute report (async path) ───────────────────────────────────────────

  const handleExecute = async (
    overrideParamValues?: Record<string, any>,
    opts?: { forceRefresh?: boolean; provisionalInstance?: InstanceInfo },
  ) => {
    if (!report) return;
    runStarted.current = true;
    const effectiveParams = overrideParamValues || paramValues;
    // 2026-11-01 -- the Data version control's choice (undefined = "As saved"
    // for every table: the body carries nothing, the old request)
    const dataVersion = buildDataVersion(dataVersionChoices);
    setVersionRefusal(null);
    // A manual run supersedes any probe-queued auto-open (double-execute guard).
    setPendingAutoOpen(null);
    // Validate required params before execute
    const params = (report.parameters || []) as any[];
    const isEmptyVal = (v: any) => v == null || v === '';
    const missing = params.filter((p: any) => p.is_required && isEmptyVal(effectiveParams[p.name]) && isEmptyVal(p.default_value))
      .map((p: any) => p.label || p.name);
    if (missing.length > 0) {
      setError(`Required parameter(s) missing: ${missing.join(', ')}`);
      return;
    }
    setExecuting(true);
    setError('');
    // H1 item 5: true when the sync fallback's run was cancelled or replaced
    // while it waited -- its finally must not reset the newer run's state.
    let superseded = false;
    setAsyncExecId(null);
    setAsyncProgress(0);
    setCapacityWait(null);
    setPage(0);
    setTruncated(null);
    setTruncRowLimit(null);
    setSortColumn(null);
    setSortDirection(null);
    setAllRows([]);  // Reset client-side data
    setDrillState(prev => ({ ...prev, level: 0, filters: [] }));
    setExpandedLevels(0);
    // Reset server-engine state — the verdict belongs to ONE execution.
    setEngineVerdict(null);
    setUnstableTruncation(null);
    // A pin names a snapshot of ONE execution's parts.  Carrying it into the
    // next run would send a pin the new build cannot name — a 409 on the
    // first page of a report that is perfectly healthy.
    pinRef.current = null;
    pinnedRowsRef.current = 0;
    partialShownRef.current = false;
    setDatasetVersion(null);
    setProgressive(null);
    setSnapshotMoved(null);
    setRowsReady(0);
    // Provenance belongs to ONE execution.  An auto-open passes the PROBE's
    // instance row here so "Data as of" renders BEFORE the serve completes
    // (instant, not a flash); the execute response's authoritative metadata
    // then replaces it — including clearing it if the serve missed after
    // all (probe→serve race) and the run went live.
    setInstanceInfo(opts?.provisionalInstance ?? null);
    setCubeRows([]);
    setCubeColumns([]);
    setCubeTotalRows(0);
    setCubeGrandTotals(null);
    setCubeError('');
    setRefusedMeasures([]);
    setServerSlicerOptions({});
    setStillRunning(false);
    pollAbort.current = false;

    const isDrillReport = Boolean(report.drill_hierarchy_id) && drillHierarchyLevels.length > 0;

    try {
      // Start async execution — no drill overrides; always fetch full detail data
      const startRes = await api.executeBusinessReportAsync(reportId, {
        parameter_values: effectiveParams,
        ...(opts?.forceRefresh ? { force_refresh: true } : {}),
        ...(dataVersion ? { data_version: dataVersion } : {}),
      });
      const execId = startRes.execution_id;
      setAsyncExecId(execId);
      setAsyncProgress(10);
      // Phase 2 UX (2026-08-09): the start response says WHERE the data is
      // coming from.  served_from_instance=true means the backend answered
      // from a stored instance and the job row is ALREADY completed — no
      // sleep, no spinner; the disclosure banner renders from this state.
      // Set UNCONDITIONALLY: a live run (null) must clear any provisional
      // probe-derived banner — the serve missed, this data will be live.
      setInstanceInfo(parseInstanceInfo(startRes));

      // Poll status (WS can wake us up early via wsPollWakeup ref).
      // First checks come fast (research §5: 1s is the flow budget — a
      // fixed 2s first sleep made even instant reports feel slow), then
      // back off to 2s.
      let done = false;
      let pollResult: any = null;
      let pollCount = 0;
      const POLL_DELAYS_MS = [300, 700, 1500];
      // Instance serves complete at start — skip the first sleep entirely.
      let skipFirstSleep = startRes.status === 'completed';
      const pollStart = Date.now();
      // 2026-08-31 — after ten minutes we STOP WATCHING.  We do not stop the
      // report.
      //
      // This used to call cancelBusinessReportAsync here, so a run that
      // legitimately took longer than ten minutes — a cross-source S3 +
      // on-prem Starburst report, say — could never finish: the browser
      // killed it on the way past. The work runs server-side and the job row
      // is only swept as orphaned after an hour
      // (business_reports.async_running_stale_after_seconds, default 3600),
      // so leaving it alone is safe and it will complete on its own.
      //
      // Completion now writes a durable notification, so the user is told
      // wherever they are. Detaching without that would have been the worse
      // failure: a run nobody is watching and nobody is told about.
      const POLL_TIMEOUT_MS = 10 * 60 * 1000; // stop WATCHING after 10 minutes
      while (!done) {
        if (pollAbort.current) break;
        if (Date.now() - pollStart > POLL_TIMEOUT_MS) {
          setStillRunning(true);
          break;
        }
        if (skipFirstSleep) {
          skipFirstSleep = false;
        } else {
          const delay = POLL_DELAYS_MS[pollCount] ?? 2000;
          await new Promise<void>(resolve => {
            const timer = setTimeout(resolve, delay);
            wsPollWakeup.current = () => { clearTimeout(timer); resolve(); };
          });
          wsPollWakeup.current = null;
        }
        pollCount += 1;
        if (pollAbort.current) break;
        const statusRes = await api.getBusinessReportAsyncStatus(reportId, execId);
        setAsyncProgress(statusRes.progress_pct || 0);
        setCapacityWait((statusRes as any).waiting_for_capacity
          ? ((statusRes as any).status_detail || 'Waiting for server capacity') : null);
        // 2026-09-05 PROGRESSIVE — start showing rows as soon as the build
        // has made some durable, not when the last bucket lands.  The status
        // poll is where a client learns it can: `partial_results_available`
        // is stamped only when a parts dataset actually exists beside the
        // (not yet written) artifact, so a report that never partitions
        // never enters this branch and takes exactly the path it took
        // before.  Page 1 here MINTS the pin; every later page echoes it.
        if (statusRes.partial_results_available === true
            && !partialShownRef.current
            && statusRes.status !== 'completed') {
          partialShownRef.current = true;
          setProgressiveProgress(statusRes);
          const partialResult = {
            execution_id: execId,
            total_rows: statusRes.rows_ready ?? 0,
            // engine stays NULL until the run completes.  The server-engine
            // path answers every drill gesture with a /cube query over the
            // finished artifact; pointing it at an execution that is still
            // running would turn a healthy partial view into a red "server
            // drill query failed".  Client mode over the pinned page is what
            // this state can actually honour.
            engine: null,
          };
          setExecutionResult(partialResult);
          await fetchResultsPage(partialResult, 0, pageSize, sortColumn, sortDirection);
        } else if (statusRes.partial_results_available === true
                   && statusRes.status !== 'completed') {
          // Keep the "N rows ready so far" disclosure honest between pages
          // without re-fetching rows the user did not ask to move away from.
          setProgressiveProgress(statusRes);
        }
        if (statusRes.status === 'completed') {
          done = true;
          if (partialShownRef.current) {
            // THE MERGE LANDED WHILE THEY WERE READING.  Do not swap the
            // rows out from under them — the operator asked for exactly the
            // opposite ("if all chunks merged ask users to click on
            // refresh").  Their pinned page stays; the banner offers the
            // refresh and says which of the two reasons it is.
            setProgressive(prev => ({
              building: false,
              moreExpected: false,
              totalMode: prev?.totalMode ?? 'at_least',
              partsReady: prev?.partsReady ?? 0,
              partsPinned: prev?.partsPinned ?? 0,
              sortScope: prev?.sortScope ?? null,
              refreshAvailable: true,
              refreshReason: 'build_complete',
            }));
            setEngineVerdict(v => {
              const verdict = (statusRes as any).engine ?? null;
              return verdict === 'server' ? 'server' : verdict === 'client' ? 'client' : v;
            });
            pollResult = {
              execution_id: execId,
              total_rows: statusRes.total_rows ?? statusRes.rows_ready ?? 0,
              engine: (statusRes as any).engine ?? null,
              readiness: (statusRes as any).readiness ?? (startRes as any).readiness ?? null,
              // 2026-11-01 -- which version each table was read at, and which rule decided
              iceberg_versions: (statusRes as any).iceberg_versions ?? null,
            };
            continue;
          }
          // Fetch initial page
          // 2026-10-30: Arrow preferred, and the canvas's clicked values (still set
          // from before this run) filter the table's first page too
          const fastFirst = (api as any).getBusinessReportPagedResultsFast;
          const firstLinks = tableLinksRef.current;
          const initialPageRes = fastFirst
            ? await fastFirst(reportId, execId, 1, pageSize, null, null, firstLinks)
            : firstLinks
              ? await api.getBusinessReportPagedResults(reportId, execId, 1, pageSize, null, null, null, firstLinks)
              : await api.getBusinessReportPagedResults(reportId, execId, 1, pageSize);
          setRawRows(initialPageRes.rows || []);
          setResultColumns(initialPageRes.columns || []);
          setTotalRows(initialPageRes.total_rows ?? 0);
          setFormatCutoffs(initialPageRes.format_cutoffs || {});
          setTruncated(initialPageRes.truncated ?? null);
          setTruncRowLimit(initialPageRes.row_limit ?? null);
          // Server-stamped engine verdict + truncation-stability disclosure —
          // read from whichever response carries them (older backends: none →
          // null → client mode, exactly the pre-rewire behaviour).
          const verdict = (statusRes as any).engine ?? initialPageRes.engine ?? null;
          setEngineVerdict(verdict === 'server' ? 'server' : verdict === 'client' ? 'client' : null);
          setUnstableTruncation(
            initialPageRes.unstable_truncation ?? (statusRes as any).unstable_truncation ?? null);
          pollResult = {
            execution_id: execId,
            total_rows: initialPageRes.total_rows,
            engine: verdict,
            // 2026-09-29 -- the run's business-date readiness rides on the
            // status (and start) envelope; a result rebuilt without it hid
            // the Partial chip on every async run (found on the Docker rig).
            readiness: (statusRes as any).readiness ?? (startRes as any).readiness ?? null,
            // 2026-11-01 -- which version each table was read at, and which rule decided
            iceberg_versions: (statusRes as any).iceberg_versions ?? null,
          };
        } else if (statusRes.status === 'failed') {
          done = true;
          setError(statusRes.error || 'Report execution failed');
        } else if (statusRes.status === 'cancelled') {
          // A cancelled run must terminate the poll immediately — previously
          // only completed/failed exited, so a cancelled execution spun the
          // client for the full 10-minute timeout and then lied "timed out".
          done = true;
          setError('Report execution was cancelled.');
        }
      }
      if (pollResult) {
        setExecutionResult(pollResult);
        // For drill reports BELOW the threshold: fetch ALL rows for
        // client-side drill (background).  Above it (engine:"server") the
        // /cube effect serves every gesture — fetchAllRows must NOT run
        // (it is the 250-300K-row ceiling being retired).
        if (isDrillReport && pollResult.total_rows > 0 && pollResult.engine !== 'server') {
          fetchAllRows(pollResult, pollResult.total_rows);
        }
      }
    } catch (err: any) {
      // Fallback: try synchronous execution
      try {
        const sub = await queuedWait.submit((crid) => api.executeBusinessReport(reportId, {
          parameter_values: effectiveParams,
          ...(opts?.forceRefresh ? { force_refresh: true } : {}),
          ...(dataVersion ? { data_version: dataVersion } : {}),
          client_request_id: crid,
        }));
        if (sub.cancelled) {
          // Cancelled while it waited for a slot: nothing ran.  A run the
          // user cancelled (or replaced) leaves the screen to whoever owns it.
          superseded = !sub.current;
          return;
        }
        const result: any = sub.response;
        setExecutionResult(result);
        setTruncated(result.truncated ?? null);
        setTruncRowLimit(result.row_limit ?? null);
        // Sync path: instance provenance travels on the envelope itself.
        // Unconditional for the same reason as the async path — a live
        // envelope must clear any provisional probe banner.
        setInstanceInfo(parseInstanceInfo(result));
        // Sync execute returns the ReportEnvelope wire form — the engine
        // verdict travels on it directly.
        const syncVerdict = result.engine === 'server' ? 'server'
          : result.engine === 'client' ? 'client' : null;
        setEngineVerdict(syncVerdict);
        setUnstableTruncation(result.unstable_truncation ?? null);
        if (result.data && Array.isArray(result.data)) {
          setRawRows(result.data);
          // the server's cut-offs when it sent them; else the rows in hand
          // ARE the result shown, so rank them
          setFormatCutoffs(result.format_cutoffs || cutoffsFromRows(formatRules, result.data));
          const cols = Array.isArray(result.columns)
            ? result.columns.map((c: any) => typeof c === 'string' ? c : c.name || c.column_name || '')
            : [];
          setResultColumns(cols);
          setTotalRows(result.total_rows ?? result.data.length);
          // For drill reports with sync results below the threshold, use the
          // data directly; above it the /cube effect drives every gesture.
          if (isDrillReport && syncVerdict !== 'server') {
            setAllRows(result.data);
          }
        } else if (result.execution_id) {
          await fetchResultsPage(result, 0, pageSize, null, null);
          if (isDrillReport && result.total_rows && syncVerdict !== 'server') {
            fetchAllRows(result, result.total_rows);
          }
        }
      } catch (err2: any) {
        // 2026-11-01 -- the server refused the Data version (422): its sentence
        // is shown beside the control that asked for it
        if (dataVersion && err2?.status === 422) setVersionRefusal(err2?.message || String(err2));
        // Name a next step, not just the failure (403/404/expired mapped).
        setError(describeExecutionError(err2));
      }
    } finally {
      if (!superseded) {
        setExecuting(false);
        setAsyncExecId(null);
        setAsyncProgress(0);
        setCapacityWait(null);
        if (historyOpen) loadHistory(historyPage, historyPageSize);
      }
    }
  };

  const handleCancelExecution = async () => {
    // H1 item 5: a SYNC run still waiting for a slot is cancelled by its
    // correlation id -- it has no async execution id.
    if (queuedWait.cancel()) {
      setExecuting(false);
      return;
    }
    if (!asyncExecId) return;
    // Stop the poll loop deterministically — cancelling only server-side left
    // the loop polling a cancelled execution until the 10-minute timeout.
    pollAbort.current = true;
    try {
      await api.cancelBusinessReportAsync(reportId, asyncExecId);
    } catch { /* ignore */ }
    setExecuting(false);
    setAsyncExecId(null);
    setAsyncProgress(0);
    setCapacityWait(null);
  };

  // ── Export menu ──────────────────────────────────────────────────────────
  const [exportAnchor, setExportAnchor] = useState<null | HTMLElement>(null);
  // One retention control, shared by every export menu (2026-08-30).
  const { retainDays, retentionControl } = useExportRetention();
  // 2026-08-31 — runtime column choice.  A dataset can carry 200+ columns
  // and the author curates a subset into the report; a viewer narrows that
  // further for the screen.  Empty set = show everything, so a report
  // nobody has narrowed behaves exactly as before.
  const [hiddenCols, setHiddenCols] = useState<Set<string>>(new Set());
  const actionLinkChips = useMemo(() => canvasLinks.map(l => ({ column_id: l.column_id, value: l.value ?? null })),
    [canvasLinks]);
  const [colMenuAnchor, setColMenuAnchor] = useState<null | HTMLElement>(null);

  // Exports are synchronous downloads with no progress channel — the honest
  // move is to say so up front (research §5: past 10s you owe the user an
  // indicator), keep the button visibly busy, and confirm on completion.
  // There is no server-side cancel for an export in flight.
  const EXPORT_LABELS: Record<'excel' | 'pdf' | 'csv', string> = {
    excel: 'Excel', pdf: 'PDF', csv: 'CSV',
  };
  const handleExport = async (fmt: 'excel' | 'pdf' | 'csv') => {
    setExportAnchor(null);
    setExporting(fmt);
    setToast(`Preparing ${EXPORT_LABELS[fmt]} export — the download starts automatically when it is ready. Large exports can take a minute.`);
    try {
      // The file must match the screen: send the columns actually shown.
      // undefined when nothing is hidden, so an un-narrowed report exports
      // byte-identically to before.
      const cols = hiddenCols.size > 0 ? allCols.join(',') : undefined;
      const links = canvasOn ? linksExportParam(canvasLinkStore.get()) : undefined;
      // the file follows the screen: a theme this viewer picked travels as its NAME
      const theme = viewThemeKnown && viewTheme ? viewTheme : undefined;
      if (fmt === 'excel') await api.downloadBusinessReportExcel(reportId, paramValues, retainDays, cols, links, theme);
      else if (fmt === 'pdf') await api.downloadBusinessReportPDF(reportId, paramValues, retainDays, cols, links, theme);
      else await api.downloadBusinessReportCSV(reportId, paramValues, retainDays, cols);
      setToast(`${EXPORT_LABELS[fmt]} export downloaded.`);
    } catch (e: any) {
      setToast(e?.message
        ? `${EXPORT_LABELS[fmt]} export failed: ${e.message}`
        : `${EXPORT_LABELS[fmt]} export failed`);
    } finally {
      setExporting(null);
    }
  };

  // ── Drill handlers (instant client-side below the threshold; /cube-driven
  //    above it — hasDrill is declared with the engine-mode gates above) ────

  const canDrillDeeper = hasDrill && drillState.level < drillHierarchyLevels.length;
  const canDrillUp = drillState.level > 0;

  // Drill down on click — click a specific row value to see its children
  const handleDrillDown = (_clickedColumn: string, value: any, row: any) => {
    const levels = drillHierarchyLevels;
    setDrillState(prev => {
      if (levels.length > 0 && prev.level < levels.length) {
        const drillCol = levels[prev.level].column_name;
        const drillVal = row[drillCol] ?? value;
        return { ...prev, level: prev.level + 1, filters: [...prev.filters, { column: drillCol, value: drillVal }], hierarchy_levels: levels };
      }
      return { ...prev, level: prev.level + 1, filters: [...prev.filters, { column: _clickedColumn, value }] };
    });
    setExpandedLevels(0);
    setPage(0);
  };

  // Go to next level — show next hierarchy level for ALL data (no filter added)
  const handleGoToNextLevel = () => {
    if (!canDrillDeeper) return;
    setDrillState(prev => ({ ...prev, level: prev.level + 1 }));
    setExpandedLevels(0);
    setPage(0);
  };

  // Expand to next level — add next hierarchy column alongside current columns
  const handleExpandNextLevel = () => {
    if (!canDrillDeeper) return;
    setExpandedLevels(prev => Math.min(prev + 1, drillHierarchyLevels.length - drillState.level));
    setPage(0);
  };

  // Drill up — go back one level
  const handleDrillUp = (toLevel: number) => {
    setDrillState(prev => ({ ...prev, level: toLevel, filters: prev.filters.slice(0, toLevel) }));
    setExpandedLevels(0);
    setPage(0);
  };

  // ── DnD sensors for column header reorder ────────────────────────────────
  const dndSensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 8 } }));

  // Sortable table header cell — keyboard-sortable (Enter/Space), announces
  // its sort state via aria-sort, and keeps a visible focus ring.
  const SortableHeaderCell: React.FC<{ col: string }> = ({ col }) => {
    const colType = colTypeMap[col] || 'string';
    const isNumeric = ['integer', 'float'].includes(colType);
    const friendly = datasetColumns.find((c: any) => c.physical_name === col)?.friendly_name || col;
    const ariaSort = sortColumn === col
      ? (sortDirection === 'asc' ? 'ascending' : 'descending')
      : 'none';
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: col });
    return (
      <TableCell
        ref={setNodeRef}
        sx={{
          fontWeight: 'bold', whiteSpace: 'nowrap', cursor: 'pointer', userSelect: 'none',
          textAlign: isNumeric ? 'right' : 'left',
          '&:hover': { opacity: 0.85 },
          opacity: isDragging ? 0.5 : 1,
          transform: CSS.Transform.toString(transform), transition,
          '&:focus-visible': { outline: '2px solid', outlineColor: 'secondary.main', outlineOffset: -2 },
        }}
        onClick={() => handleSortColumn(col)}
        {...attributes} {...listeners}
        role="columnheader"
        aria-sort={ariaSort as any}
        aria-label={`${friendly} — press Enter to sort`}
        tabIndex={0}
        onKeyDown={(e: React.KeyboardEvent) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleSortColumn(col);
          }
        }}
      >
        <Box sx={{ display: 'inline-flex', alignItems: 'center' }}>
          {friendly}
          <SortIcon col={col} />
        </Box>
      </TableCell>
    );
  };

  // ── Sort icon helper ──────────────────────────────────────────────────────

  const SortIcon: React.FC<{ col: string }> = ({ col }) => {
    if (sortColumn !== col) return <SortNoneIcon sx={{ fontSize: 14, opacity: 0.3, ml: 0.5 }} />;
    if (sortDirection === 'asc') return <SortAscIcon sx={{ fontSize: 14, color: 'primary.main', ml: 0.5 }} />;
    return <SortDescIcon sx={{ fontSize: 14, color: 'primary.main', ml: 0.5 }} />;
  };

  // (a HOOK: above the early returns below)
  // a client-side result holds every row: rank them here; a server-paged one
  // uses the server's cut-offs over the whole result
  const cellCutoffs = useMemo(() => (isClientSide
    ? cutoffsFromRows(formatRules, engineOutput.bandedRows.filter((r: any) => !r._rowType || r._rowType === 'data'))
    : formatCutoffs), [isClientSide, formatRules, engineOutput.bandedRows, formatCutoffs]);

  // ── Render ────────────────────────────────────────────────────────────────

  if (loading) {
    return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}><CircularProgress /></Box>;
  }

  if (!report) {
    return <Alert severity="error" sx={{ mt: 4, mx: 4 }}>Report not found</Alert>;
  }

  // ── Consumer vs author (2026-08-17) ──────────────────────────────────────
  // A consumer opening a published report gets a clean read / interact /
  // export surface — Edit and publish-as-API are AUTHORING chrome, gated the
  // same way PivotReportViewer already gates its Edit button.  Admin tier
  // additionally unlocks Certify / Uncertify in the lifecycle menu.
  const canEdit = canEditReport(report, user);
  // 2026-09-20 -- may this principal CREATE reports at all?  Duplicate is
  // gated on this rather than on canEdit: an analyst who cannot edit
  // someone's published report may still start their own from a copy;
  // a viewer never authors.
  const canAuthor = canAuthorReports(user);
  const isAdminLike = (user as any)?.role === 'admin' || (user as any)?.role === 'super_admin';
  const mayShare = isAdminLike || (report as any)?.owner === (user as any)?.username;

  // ── the band (2026-11-01): generic -- the report's parameter definitions, its theme ──
  const reportTheme = viewThemeKnown && viewTheme
    ? resolveTheme({ theme: { name: viewTheme } }, themeLibrary)
    : resolveTheme(report?.layout_config);
  // the header (2026-11-03): the theme's title colour when it reads on the page (light
  // AND dark mode), else the app's own text colour; the theme's band colour as the accent
  const pageBg = muiTheme.palette.background.default;
  const readsOnPage = (c: string, min: number) => !isHex(pageBg) || (isHex(c) && contrastRatio(c, pageBg) >= min);
  const headerTitleColor = readsOnPage(reportTheme.title.color, 3) ? reportTheme.title.color : muiTheme.palette.text.primary;
  const headerAccent = readsOnPage(reportTheme.band.bg, 3) ? reportTheme.band.bg : muiTheme.palette.primary.main;
  const dark = muiTheme.palette.mode === 'dark';
  const tint = (c: string, a: number) => { try { return alpha(c, a); } catch { return 'transparent'; } };
  const bandCtrl: BandControls = {
    params: report.parameters || [],
    values: paramValues,
    fetchValues: paramValuesFetch,
    onPick: (next) => { setParamValues(next); handleExecute(next); },
    businessDay: typeof (api as any).getReportBusinessDay === 'function'
      ? (d, step, name) => (api as any).getReportBusinessDay(reportId, d, step, name) : undefined,
    extras: dataVersions?.supported && dataVersions.tables?.length ? (
      <DataVersionBandCell key="data-version" reportId={reportId} answer={dataVersions} choices={dataVersionChoices}
        onChange={setDataVersionChoices} theme={reportTheme} onApply={() => handleExecute()} />
    ) : undefined,
  };
  const topBand = (() => {
    // ONE band (the owner, 2026-11-01): with a band tile on the canvas, every visible parameter
    // is a cell of THAT band -- the ones no tile lists are appended at the end of the first one --
    // and the page draws no band of its own; without one, the page's band holds them all
    const bandTiles = canvasOn ? (shownCanvas.tiles || []).filter((t: any) => t.kind === 'band') : [];
    const visible = bandParams(report.parameters || [], paramValues);
    if (!bandTiles.length) {
      return { show: true, names: null as string[] | null, hasBandTile: false, append: null as { tileId: string; names: string[] } | null };
    }
    let all = false;
    const covered = new Set<string>();
    for (const t of bandTiles as any[]) {
      const wanted: string[] | null = t.parameters && t.parameters.length ? t.parameters : (reportTheme.band.show || null);
      if (!wanted) all = true; else wanted.forEach(n => covered.add(n));
    }
    const rest = all ? [] : visible.filter(p => !covered.has(p.name)).map(p => p.name);
    return { show: false, names: [] as string[], hasBandTile: true, append: { tileId: String((bandTiles[0] as any).id), names: rest } };
  })();

  // Base columns (may change during drill grouping).  Server-engine mode:
  // the cube response's columns ARE the active columns (dims + measures +
  // calculated columns).
  const baseCols = (serverEngineActive && cubeColumns.length > 0)
    ? cubeColumns
    : (isClientSide && engineOutput.activeColumns.length > 0)
      ? engineOutput.activeColumns.concat(engineOutput.calculatedColumns)
      : resultColumns.concat(engineOutput.calculatedColumns);

  // Apply user-defined column order if set, falling back to base order
  const allCols = (() => {
    // Hidden columns are filtered at DISPLAY, never upstream: the report
    // engine still computes bands, subtotals and running calculations over
    // the full result, so hiding the column a running total is based on
    // does not silently change the numbers that remain.
    const visible = (cols: string[]) => cols.filter(c => !hiddenCols.has(c));
    if (!columnOrder) return visible(baseCols);
    // Keep only columns that still exist in baseCols, in the user-specified order
    const baseSet = new Set(baseCols);
    const ordered = columnOrder.filter(c => baseSet.has(c));
    // Append any new columns not in the user order
    for (const c of baseCols) {
      if (!ordered.includes(c)) ordered.push(c);
    }
    return visible(ordered);
  })();

  // Server-engine mode: the cube page is ALREADY the requested page of the
  // grouped result — render it as-is.  Client-side mode: slice banded rows.
  const paginatedRows = serverEngineActive
    ? cubeRows
    : isClientSide
      ? engineOutput.bandedRows.slice(page * pageSize, (page + 1) * pageSize)
      : engineOutput.bandedRows;

  // Total row count for pagination display
  // In client-side mode, use bandedRows.length (includes headers/subtotals) for correct pagination
  const displayTotalRows = serverEngineActive
    ? cubeTotalRows
    : isClientSide ? engineOutput.bandedRows.length : totalRows;

  // 2026-10-24 (the owner: "pagination always on top, not on bottom -- it's
  // hard to find").  ONE pager, rendered above the table AND below it, so a
  // user never scrolls to find it.  Client-side for drill reports,
  // server-side otherwise; on mobile the toolbar wraps and drops the
  // rows-per-page label so nothing overflows a 390px viewport.
  const resultPager = (where: 'top' | 'bottom') => (
    <TablePagination
      component="div"
      data-testid={`report-pager-${where}`}
      count={displayTotalRows}
      page={page}
      onPageChange={(_, newPage) => setPage(newPage)}
      rowsPerPage={pageSize}
      onRowsPerPageChange={e => {
        setPageSize(Number(e.target.value));
        setPage(0);
      }}
      rowsPerPageOptions={isMobile ? [100, 500, 1000] : PAGE_SIZE_OPTIONS}
      labelRowsPerPage={isMobile ? '' : undefined}
      sx={isMobile ? {
        '& .MuiTablePagination-toolbar': { flexWrap: 'wrap', px: 0.5 },
        '& .MuiTablePagination-displayedRows': { m: 0 },
      } : undefined}
      labelDisplayedRows={({ from, to, count }) =>
        `Rows ${from.toLocaleString()}–${to.toLocaleString()} of ${
          count === -1 ? 'many'
            : progressive?.totalMode === 'at_least'
              // The build is open: this count is a floor, not a total.
              ? `at least ${count.toLocaleString()}`
              : count.toLocaleString()}`
      }
    />
  );

  // 2026-10-26 -- the results area is ONE element: alone it is the report as
  // before; on a canvas it is the "report" tile beside the other tiles.
  const resultsRegion = (
    <>
        {/* 2026-10-30 -- the table under the canvas's clicked values: refused in
            words (no rows shown), or "does not follow" with the reason */}
        {tableLinkNote && tableLinks.length > 0 && (
          <Alert severity={tableLinkNote.kind === 'refused' ? 'warning' : 'info'} sx={{ mb: 1, py: 0 }}
            data-testid={tableLinkNote.kind === 'refused' ? 'report-table-links-refused' : 'report-table-not-following'}>
            {tableLinkNote.words || 'The table cannot follow the clicked values.'}
          </Alert>
        )}
        {/* Execution Result Badges -- inside the report controls (2026-10-26) */}
        {executionResult && controlsOpen && (
          <Box sx={{ display: 'flex', gap: 1, mb: 2, flexWrap: 'wrap', alignItems: 'center' }}>
            {/* Table / Chart toggle — only when the report carries a saved
                chart config.  The chart is the same data through the same
                cube; the toggle never changes drill/slicer/parameter state. */}
            {chartConfig && (
              <ToggleButtonGroup size="small" exclusive value={viewMode}
                onChange={(_, v) => { if (v) setViewMode(v); }}
                aria-label="Result view" data-testid="view-toggle">
                <ToggleButton value="table" aria-label="Table view" sx={{ px: 1.25, py: 0.5 }}>
                  <TableViewToggleIcon sx={{ fontSize: 18, mr: 0.5 }} /> Table
                </ToggleButton>
                <ToggleButton value="chart" aria-label="Chart view" sx={{ px: 1.25, py: 0.5 }}>
                  <ChartViewToggleIcon sx={{ fontSize: 18, mr: 0.5 }} /> Chart
                </ToggleButton>
                <ToggleButton value="both" aria-label="Chart and table view" sx={{ px: 1.25, py: 0.5 }}>
                  <ChartViewToggleIcon sx={{ fontSize: 18, mr: 0.25 }} />
                  <TableViewToggleIcon sx={{ fontSize: 18, mr: 0.5 }} /> Both
                </ToggleButton>
              </ToggleButtonGroup>
            )}
            {/* AT_LEAST IS NOT A TOTAL.  While the build is open the count is a
                floor, and rendering it as "12,000 rows" would state a total the
                server explicitly declined to state. */}
            <Chip size="small" data-testid="rowcount-chip"
              label={progressive?.totalMode === 'at_least'
                ? `at least ${displayTotalRows.toLocaleString()} rows so far`
                : `${displayTotalRows.toLocaleString()} rows${serverEngineActive ? ' (server engine)' : isClientSide ? ' (client-side)' : ''}`} />
            <Chip size="small" label={`Page ${page + 1} — Rows ${(page * pageSize + 1).toLocaleString()}–${Math.min((page + 1) * pageSize, displayTotalRows).toLocaleString()}`} />
            {/* 2026-08-05: never silently degrade — a capped result says so. */}
            {truncated === true && (
              <Tooltip title={truncationMessage({ rowLimit: truncRowLimit, unstable: unstableTruncation, hasDrill })}>
                <Chip size="small" color="warning" icon={<TruncatedIcon />}
                  label={truncationChipLabel(truncRowLimit)} />
              </Tooltip>
            )}
            {/* Provenance chip (2026-08-09): WHERE the numbers came from —
                stored instance vs cache vs live — because trust in the numbers
                starts with knowing their origin (research §5). */}
            {instanceInfo ? (
              <Tooltip title={
                `Served instantly from a saved result${instanceInfo.isScheduled ? ' produced by a scheduled run' : ''}` +
                `${instanceInfo.createdBy ? ` (run by ${instanceInfo.createdBy})` : ''}. Press Refresh at the top to read the source again.`}>
                <Chip size="small" color={instanceInfo.stale ? 'warning' : 'default'}
                  icon={<HistoryIcon />} data-testid="provenance-chip"
                  label={`Saved result · ${formatAsOf(instanceInfo.asOf)}`} />
              </Tooltip>
            ) : executionResult.cache_hit ? (
              <Tooltip title="Served from the aggregate cache — precomputed from the same source data.">
                <Chip size="small" icon={<BoltIcon />} color="success" data-testid="provenance-chip"
                  label={`Cache Hit (${executionResult.cache_grain || 'cached'})`} />
              </Tooltip>
            ) : (
              <Tooltip title={serverEngineActive
                ? 'Fresh execution — drill and totals are computed on the server over the full result.'
                : 'Fresh execution against the source.'}>
                <Chip size="small" variant="outlined" label="Live query" data-testid="provenance-chip" />
              </Tooltip>
            )}
            {/* Fail-closed completeness verdict (self-hides when absent) */}
            <CompletenessBadge certificate={executionResult?.certificate} />
            {/* 2026-09-27 -- which engine answered (self-hides when the run
                recorded none), and the scan disclosure: files read of listed,
                manifests, engine, cache -- each part "not recorded" when the
                server did not say, never 0. */}
            <EngineChip engine={executionResult?.execution_engine}
              label={executionResult?.execution_engine_label} />
            <ScanDisclosureChip reportId={reportId}
              executionId={executionResult?.execution_id || null}
              envelope={executionResult} />
            {/* 2026-10-30 -- how this run applied each parameter (owner / editors; viewers when allowed) */}
            <ReportDiagnosticsPanel reportId={reportId} executionId={executionResult?.execution_id || null}
              canOpen={canEdit || !!report?.layout_config?.diagnostics_for_viewers} openKey={diagOpenKey} />
            {/* 2026-10-24 -- whose values these rows are limited to */}
            <EntitlementChip />
            {/* 2026-09-28 -- is the DATA for the business date complete (the
                feed gate's answer for this run), and the report's promise. */}
            <ReadinessChip readiness={executionResult?.readiness} showUndeclared={canEdit} />
            {/* 2026-11-01 -- which version each Iceberg table was read at, and which rule decided */}
            <VersionsReadLine versions={executionResult?.iceberg_versions} testId="report-versions-read" />
            <ReportSloChip reportId={reportId}
              businessDate={executionResult?.readiness?.business_date || null}
              refreshKey={`${executionResult?.execution_id || ''}:${sloRefresh}`} />
            {/* Grand totals toggle */}
            {grandTotals && (
              <FormControlLabel
                control={<Switch checked={showTotals} onChange={e => setShowTotals(e.target.checked)} size="small" />}
                label="Totals"
                sx={{ ml: 1 }}
              />
            )}
          </Box>
        )}

        {/* Truncation disclosure (drill audit D6 + 2026-08-09 rewording): the
            warning travels with EVERY view of a truncated result — plain words,
            the numbers we actually know, and the stability caveat when the cut
            had no ORDER BY.  Announced to screen readers (role=alert default),
            icon + text, never a colour-only signal. */}
        {executionResult && truncated === true && (
          <Alert severity="warning" sx={{ mb: 2 }} icon={<TruncatedIcon />}
            data-testid="truncation-banner"
            action={
              <Button color="inherit" size="small" disabled={exporting !== null}
                onClick={() => handleExport('csv')} data-testid="truncation-export-all">
                Export every row (CSV)
              </Button>
            }>
            {truncationMessage({ rowLimit: truncRowLimit, unstable: unstableTruncation, hasDrill })}
          </Alert>
        )}

        {/* 422 non_additive_measures — the BusinessObjects #TOREFRESH posture:
            name each withheld measure and WHY.  Never a silent drop, never a
            wrong number. */}
        {serverEngineActive && refusedMeasures.length > 0 && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
              {refusedMeasures.length === 1
                ? '1 measure cannot be shown at this level'
                : `${refusedMeasures.length} measures cannot be shown at this level`}
              {' '}— computing it from this result would give a wrong number, so it is withheld:
            </Typography>
            {refusedMeasures.map(m => (
              <Typography key={m.column} variant="caption" component="div" sx={{ mt: 0.5 }}>
                <b>{datasetColumns.find((c: any) => c.physical_name === m.column)?.friendly_name || m.column}</b>: {m.reason}
              </Typography>
            ))}
            <Typography variant="caption" component="div" sx={{ mt: 0.5 }}>
              Drill back up to the report's original level to see these measures again.
            </Typography>
          </Alert>
        )}

        {/* Server-engine gesture failure (numbers unavailable — shown loudly,
            never rendered as an empty-but-plausible page) */}
        {serverEngineActive && cubeError && (
          <Alert severity="error" sx={{ mb: 2 }} onClose={() => setCubeError('')}>{cubeError}</Alert>
        )}

        {/* Server-engine gesture in flight — honest slow-path note past 10s
            (there is no server-side cancel for a bounded cube query, so we
            disclose rather than fake a cancel button). */}
        {serverEngineActive && cubeLoading && (
          <Box sx={{ mb: 2 }} role="status" aria-live="polite">
            <LinearProgress />
            <Typography variant="caption" color="text.secondary">
              Computing this view on the server…
              {cubeSlow ? ' still working — aggregating over the full result.' : ''}
            </Typography>
          </Box>
        )}

        {/* Loading all rows indicator for client-side drill */}
        {allRowsLoading && (
          <Alert severity="info" sx={{ mb: 2 }}>Loading all rows for instant drill-down...</Alert>
        )}

        {/* Chart view — the same drill/slicer state, a different renderer.
            Every gesture is ONE bounded cube query; a chart click drills
            through the SAME handleDrillDown as a table row click, so both
            land in the same breadcrumb state. */}
        {chartActive && chartConfig ? (
          <ReportChartView
            reportId={reportId}
            executionId={executionResult?.execution_id || null}
            config={chartConfig}
            drillFilters={drillState.filters}
            drillLevelColumn={hasDrill
              ? drillHierarchyLevels[Math.min(drillState.level, drillHierarchyLevels.length - 1)]?.column_name || null
              : null}
            drillLevelLabel={hasDrill
              ? drillHierarchyLevels[Math.min(drillState.level, drillHierarchyLevels.length - 1)]?.label || null
              : null}
            canDrillDeeper={canDrillDeeper && !executing}
            onDrillDown={handleDrillDown}
            onSwitchToTable={() => setViewMode('table')}
            slicers={slicerByName}
            truncated={truncated}
            truncationText={truncated === true
              ? truncationMessage({ rowLimit: truncRowLimit, unstable: unstableTruncation, hasDrill })
              : null}
            clientRows={chartClientRows}
            isMobile={isMobile}
            // ONE engine verdict drives BOTH surfaces.  Without this the chart
            // queried /cube while the table below the 50K threshold rendered
            // client-engine numbers — and those provably disagree (NULL/'' merge,
            // Number(null)=0 understating averages, avg-of-avgs grand totals).
            // Two values for one measure on one screen is a trust failure.
            engine={engineVerdict}
          />
        ) : null}
        {/* The table: alone, or under the chart in the 'both' view */}
        {(!(chartActive && chartConfig) || viewMode === 'both') ? (paginatedRows.length > 0 ? (
          <>
            {resultPager('top')}
            <DndContext sensors={dndSensors} collisionDetection={closestCenter}
              onDragEnd={(event) => {
                const { active, over } = event;
                if (over && active.id !== over.id) {
                  const oldIdx = allCols.indexOf(String(active.id));
                  const newIdx = allCols.indexOf(String(over.id));
                  const newOrder = arrayMove(allCols, oldIdx, newIdx);
                  setColumnOrder(newOrder);
                  // Debounced persist to backend
                  if (saveOrderTimer.current) clearTimeout(saveOrderTimer.current);
                  saveOrderTimer.current = setTimeout(() => {
                    if (reportId) api.updateViewerPrefs(reportId, { column_order: newOrder }).catch(() => {});
                  }, 1000);
                }
              }}>
            <TableContainer component={Paper} ref={resultsScrollRef} data-testid="report-results-scroll"
              sx={{
                // inside a canvas tile the TILE's height bounds the box (the tile view sets
                // --qs-tile-h), so this box scrolls and the header stays (2026-11-01)
                maxHeight: canvasOn ? 'calc(var(--qs-tile-h, 100vh) - 96px)' : isMobile ? 'calc(100vh - 260px)' : 'calc(100vh - 420px)',
                // Mobile table strategy: horizontal scroll with a PINNED first
                // column.  Chosen over a stacked-card layout because business
                // report rows are cross-comparable numbers — cards destroy
                // column alignment, and banded subtotal/grand-total rows have
                // no card equivalent.  Pinning the first column keeps the row
                // identity (the dimension) visible while measures scroll,
                // which is what mobile BI tools converge on.
                ...(isMobile ? {
                  '& td:first-of-type, & th:first-of-type': {
                    position: 'sticky', left: 0, zIndex: 2,
                    bgcolor: 'background.paper',
                    borderRight: '1px solid', borderRightColor: 'divider',
                  },
                  // Header corner keeps the report's header colour and sits
                  // above both sticky axes.
                  '& th:first-of-type': { zIndex: 3, bgcolor: styleConfig.header_bg },
                } : {}),
              }}>
              <Table size="small" stickyHeader aria-label="Report results"
                aria-rowcount={displayTotalRows}>
                <TableHead>
                  <TableRow sx={{ '& th': { bgcolor: styleConfig.header_bg, color: styleConfig.header_text } }}>
                    <SortableContext items={allCols} strategy={horizontalListSortingStrategy}>
                      {allCols.map(col => (
                        <SortableHeaderCell key={col} col={col} />
                      ))}
                    </SortableContext>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <VirtualRows count={paginatedRows.length} scrollRef={resultsScrollRef} colSpan={allCols.length}
                    renderRow={(idx: number) => {
                    const row = paginatedRows[idx];
                    const style = rowTypeStyles[row._rowType] || {};
                    if (row._rowType === 'header') {
                      return (
                        <TableRow key={idx} sx={{ ...style }}>
                          <TableCell colSpan={allCols.length} sx={{ fontWeight: 'bold', fontSize: '0.95rem' }}>
                            {row._sectionValue}
                            {row._sectionCount != null && (
                              <Chip size="small" label={`${row._sectionCount} rows`} sx={{ ml: 1 }} />
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    }
                    const isStripe = styleConfig.stripe_rows && row._rowType === 'data' && idx % 2 === 1;
                    // Keyboard drill: when click-to-drill is armed, every data
                    // row is focusable and Enter/Space drills into it.
                    const isDrillableRow = row._rowType === 'data' && drillClickMode && canDrillDeeper;
                    const drillLevelCol = drillHierarchyLevels[drillState.level]?.column_name;
                    return (
                      <TableRow key={idx}
                        sx={{
                          ...style, ...(isStripe ? { bgcolor: '#f9f9f9' } : {}),
                          ...(isDrillableRow ? { '&:focus-visible': { outline: '2px solid', outlineColor: 'primary.main', outlineOffset: -2 } } : {}),
                        }}
                        hover={row._rowType === 'data'}
                        tabIndex={isDrillableRow ? 0 : undefined}
                        aria-label={isDrillableRow && drillLevelCol
                          ? `Drill into ${String(row[drillLevelCol] ?? '')}` : undefined}
                        onKeyDown={isDrillableRow ? (e: React.KeyboardEvent) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            const col = drillLevelCol || allCols[0];
                            handleDrillDown(col, row[col], row);
                          }
                        } : undefined}>
                        {allCols.map(col => {
                          const colType = colTypeMap[col] || 'string';
                          const isNumeric = ['integer', 'float'].includes(colType);
                          const dsMeta = datasetColumns.find((c: any) => c.physical_name === col);
                          const ruleStyle = formatRules.length && (!row._rowType || row._rowType === 'data')
                            ? evaluateRuleStyle(row[col], col, formatRules, cellCutoffs) : null;
                          return (
                            <TableCell key={col} data-rule-styled={ruleStyle?.matchedIndex !== undefined ? 'true' : undefined} sx={{
                              whiteSpace: 'nowrap',
                              ...(ruleStyle?.backgroundColor ? { backgroundColor: ruleStyle.backgroundColor } : {}),
                              ...(ruleStyle?.color ? { color: ruleStyle.color } : {}),
                              fontWeight: ruleStyle?.fontWeight || style.fontWeight,
                              fontStyle: style.fontStyle,
                              textAlign: isNumeric ? 'right' : 'left',
                              cursor: row._rowType === 'data' && drillClickMode && canDrillDeeper ? 'pointer' : 'default',
                            }}
                              onClick={() => {
                                if (row._rowType === 'data' && drillClickMode && canDrillDeeper) {
                                  handleDrillDown(col, row[col], row);
                                }
                              }}
                            >
                              {formatCellValue(row[col], colType, dsMeta?.format_pattern, dsMeta?.data_type, styleConfig.negative_format)}
                              {row._rowType === 'subtotal' && col === allCols[0] && row._sectionValue && (
                                <Typography component="span" variant="caption" sx={{ ml: 1 }}>
                                  Subtotal: {row._sectionValue}
                                </Typography>
                              )}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    );
                  }} />
                </TableBody>
                {/* Grand totals footer row (Phase 81 FIX 9) */}
                {showTotals && grandTotals && (
                  <TableFooter>
                    <TableRow sx={{ bgcolor: styleConfig.grand_total_bg }}>
                      {allCols.map((col, idx) => {
                        const colType = colTypeMap[col] || 'string';
                        const isNumeric = ['integer', 'float'].includes(colType);
                        const val = grandTotals[col];
                        return (
                          <TableCell key={col} sx={{ fontWeight: 'bold', textAlign: isNumeric ? 'right' : 'left' }}>
                            {idx === 0 ? 'Total' : (val !== null && val !== undefined ? formatCellValue(val, colType, undefined, undefined, styleConfig.negative_format) : '')}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  </TableFooter>
                )}
              </Table>
            </TableContainer>
            </DndContext>

            {/* 2026-10-24 -- the SAME pager under the table as above it
                (resultPager): a user on a long page finds it at either end. */}
            {resultPager('bottom')}
          </>
        ) : progressive?.moreExpected ? (
          /* NO ROWS YET IS NOT NO ROWS.  The build has started and has none
             durable at this moment — rendering that with the finished-report
             empty state ("returned no rows … adjust the parameters above")
             would blame the user's parameters for a report that has not
             answered yet.  `more_expected` is the field that separates them. */
          <Alert severity="info" sx={{ mt: 2 }} data-testid="progressive-empty"
            data-empty-kind={totalRows > 0 ? 'end_of_snapshot' : 'nothing_yet'}>
            <strong>
              {totalRows > 0
                // Reached the end of the SNAPSHOT — not the end of the report.
                ? 'No more rows in this snapshot — the report is still building.'
                : 'No rows yet — this report is still building.'}
            </strong>
            {' '}Rows appear here as each chunk is written
            {rowsReady > 0 ? ` (${rowsReady.toLocaleString()} ready so far)` : ''}.
          </Alert>
        ) : !executing && executionResult && !(serverEngineActive && cubeLoading) ? (
          (() => {
            // Empty result — say WHY it is empty when we can tell, and offer
            // the one-click way out (clear slicers / drill back up).
            const emptyInfo = emptyResultInfo({
              hasActiveSlicers: Object.values(slicerByName).some(v => (v || []).length > 0),
              hasDrillFilters: drillState.filters.length > 0,
              totalRowsBeforeFilters: serverEngineActive ? 0
                : (isClientSide ? allRows.length : rawRows.length),
            });
            return (
              <Alert severity="info" sx={{ mt: 2 }} data-testid="empty-result"
                action={
                  emptyInfo.showClearSlicers ? (
                    <Button color="inherit" size="small"
                      onClick={() => setSlicerValues(prev =>
                        Object.fromEntries(Object.keys(prev).map(k => [k, []])))}>
                      Clear slicers
                    </Button>
                  ) : emptyInfo.showDrillUp ? (
                    <Button color="inherit" size="small" onClick={() => handleDrillUp(0)}>
                      Back to top level
                    </Button>
                  ) : undefined
                }>
                {emptyInfo.message}
              </Alert>
            );
          })()
        ) : !executing ? (
          <Paper elevation={1} sx={{ p: 4, textAlign: 'center', mt: 2 }}>
            <Typography variant="h6" color="text.secondary">
              Press Run to see this report
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              {report.parameters?.length > 0 ? 'Choose the values in the band above, then press Run.' : 'The numbers will appear here.'}
            </Typography>
          </Paper>
        ) : null) : null}
    </>
  );

  return (
    <Box sx={{ p: isMobile ? 1.5 : 3 }} data-mobile-layout={isMobile ? 'true' : 'false'}>
      {/* 2026-11-01 -- THE TOP OF A REPORT (the owner: "report top level icons can be
          shown with a three-dots click ... looks so weird"): the title, then ONE slim
          line -- "Data as of", Refresh, Export, Edit (authors only) and More, which
          holds every other action with its icon AND its name.  Under the title one
          small muted line: the publish state, the sign-off of this run, the history. */}
      {/* 2026-11-03 -- TWO tight lines (the owner: "unnecessary taking space ... do we need back
          arrow here"): the title, its description filling the gap in small muted text, and the
          actions at the right; under them the small publish / sign-off / comments / history tags.
          No back arrow -- the side menu and the browser's Back do that.  The inner rows are
          `display: contents`, so their pieces flow in this one flex box (order sets where; the
          tags take a whole line).  On a narrow screen the line wraps. */}
      <Box sx={{ mb: 1.5, display: 'flex', alignItems: 'center', columnGap: 1.25, rowGap: 0.5, flexWrap: 'wrap' }}
        data-testid="report-header" data-theme-name={reportTheme.name}>
        <Box sx={{ display: 'contents' }}>
          <Typography variant="h6" component="h1" data-testid="report-title"
            sx={{ order: 0, minWidth: 0, fontFamily: reportTheme.title.font, color: headerTitleColor,
                  fontWeight: 700, letterSpacing: '-0.015em', lineHeight: 1.25, fontSize: isMobile ? '1.1rem' : '1.3rem' }}>
            {report.name}
          </Typography>
          {!topBand.hasBandTile && !topBand.show && canvas.report_code && reportTheme.title.code_position !== 'hidden' && (
            <Typography data-testid="report-code" sx={{ color: reportTheme.title.color, whiteSpace: 'nowrap' }}>[{canvas.report_code}]</Typography>
          )}
          {report.is_certified && (
            <Tooltip title={
              `Certified${report.certified_by ? ` by ${report.certified_by}` : ''}` +
              `${report.certified_at ? ` on ${new Date(report.certified_at).toLocaleDateString()}` : ''}` +
              ' — reviewed and approved as a trusted, authoritative report.'}>
              <Chip icon={<CertifiedIcon />} label="Certified" size="small" color="success" variant="outlined" />
            </Tooltip>
          )}
          {/* the slim toolbar */}
          <Box sx={{ order: 2, display: 'flex', alignItems: 'center', gap: 0.5, flexWrap: 'wrap', ml: 'auto' }} data-testid="report-toolbar"
            role="toolbar" aria-label="Report actions">
            {instanceInfo && (executionResult || executing) && (
              <Tooltip title={asOfHoverText(instanceInfo)}>
                <Typography variant="body2" color={instanceInfo.stale ? 'warning.main' : 'text.secondary'} tabIndex={0}
                  data-testid="asof-banner" aria-label={asOfHoverText(instanceInfo)}
                  sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.5, mr: 0.5, whiteSpace: 'nowrap',
                        px: 1.25, py: 0.25, borderRadius: 999, fontSize: 12.5, fontWeight: 500,
                        bgcolor: instanceInfo.stale ? tint(muiTheme.palette.warning.main, dark ? 0.2 : 0.12)
                          : tint(muiTheme.palette.text.primary, dark ? 0.1 : 0.06) }}>
                  <HistoryIcon sx={{ fontSize: 16 }} /> Data as of {asOfShort(instanceInfo.asOf)}
                </Typography>
              </Tooltip>
            )}
            <Button size="small" variant="text" data-testid="report-refresh"
              startIcon={executing ? <CircularProgress size={14} /> : executionResult ? <RefreshIcon /> : <PlayIcon />}
              disabled={executing}
              onClick={() => (executionResult ? handleExecute(undefined, { forceRefresh: true }) : handleExecute())}>
              {executing ? 'Running…' : executionResult ? 'Refresh' : 'Run'}
            </Button>
            {executing && asyncExecId && (
              <Tooltip title="Stop this run">
                <IconButton size="small" aria-label="Stop this run" onClick={handleCancelExecution} color="error"><CancelIcon fontSize="small" /></IconButton>
              </Tooltip>
            )}
            <Button size="small" variant="text"
              startIcon={exporting ? <CircularProgress size={14} /> : <ExportIcon />}
              onClick={(e) => setExportAnchor(e.currentTarget)}
              disabled={!executionResult || exporting !== null}
              aria-label={exporting ? `Preparing ${EXPORT_LABELS[exporting]} export` : 'Export report'}>
              {exporting ? 'Exporting…' : 'Export'}
            </Button>
            <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)}
              onClose={() => setExportAnchor(null)}>
              <MenuItem onClick={() => handleExport('excel')}>
                <ListItemIcon><ExcelIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Excel (formatted)</ListItemText>
              </MenuItem>
              <MenuItem onClick={() => handleExport('pdf')}>
                <ListItemIcon><PdfIcon fontSize="small" /></ListItemIcon>
                <ListItemText>PDF (max 10k rows)</ListItemText>
              </MenuItem>
              <MenuItem onClick={() => handleExport('csv')}>
                <ListItemIcon><ExportIcon fontSize="small" /></ListItemIcon>
                <ListItemText>CSV (raw data)</ListItemText>
              </MenuItem>
              {retentionControl}
            </Menu>
            {/* Edit is AUTHORING chrome -- consumers of a published report never see it. */}
            {canEdit && (
              <Button size="small" variant="text" startIcon={<EditIcon />} aria-label="Edit report" data-testid="report-edit"
                onClick={() => navigate(reportEditPath(reportId))}>Edit</Button>
            )}
            <Tooltip title="More actions">
              <IconButton size="small" aria-label="More actions" data-testid="report-more" aria-haspopup="menu"
                aria-expanded={Boolean(moreAnchor)} onClick={(e) => setMoreAnchor(e.currentTarget)}>
                <MoreIcon />
              </IconButton>
            </Tooltip>
            {/* no fade: the items are readable the moment the menu shows (the rig's screenshot
                caught every item half-faded mid-animation) */}
            <Menu anchorEl={moreAnchor} open={Boolean(moreAnchor)} onClose={() => setMoreAnchor(null)}
              transitionDuration={0}
              slotProps={{ paper: { 'data-testid': 'report-more-menu' } as any }}>
              {/* a run already going: only "run with the defaults" waits, and says why */}
              <MenuItem data-testid="report-more-run-defaults" aria-disabled={executing || undefined}
                title={executing ? 'A run is already going -- wait for it to finish, or stop it, then run with the defaults.' : undefined}
                sx={executing ? { opacity: 0.6, cursor: 'not-allowed' } : undefined}
                onClick={async () => {
                if (executing) return;
                setMoreAnchor(null);
                // the default values (a business-calendar token is resolved by the SERVER)
                const defaults: Record<string, any> =
                  await resolveParamDefaults(report?.parameters || [], api.previewDateToken);
                setParamValues(defaults);
                await handleExecute(defaults);
              }}>
                <ListItemIcon><FlashOnIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Run with the default values</ListItemText>
              </MenuItem>
              {baseCols.length > 1 && (
                <MenuItem data-testid="report-more-columns" aria-label="Choose columns"
                  onClick={() => { setColMenuAnchor(moreAnchor); setMoreAnchor(null); }}>
                  <ListItemIcon><ViewColumnIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Columns{hiddenCols.size > 0 ? ` (${allCols.length} of ${baseCols.length} shown)` : ''}</ListItemText>
                </MenuItem>
              )}
              <MenuItem data-testid="report-more-view-theme"
                onClick={() => { setThemeDialogOpen(true); setMoreAnchor(null); }}>
                <ListItemIcon><ViewThemeIcon fontSize="small" /></ListItemIcon>
                <ListItemText>View in another theme</ListItemText>
              </MenuItem>
              {(report.parameters || []).length > 0 && (
                <MenuItem data-testid="report-more-bookmarks" onClick={() => { setBookmarksAnchor(moreAnchor); setMoreAnchor(null); }}>
                  <ListItemIcon><BookmarksIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Bookmarks (saved values)</ListItemText>
                </MenuItem>
              )}
              {lifecycleItems.length > 0 && <Divider />}
              {lifecycleItems.map(a => (
                <MenuItem key={a.key} data-testid={`report-more-lifecycle-${a.key}`} aria-disabled={a.disabled || undefined}
                  title={a.disabled ? 'Another publishing step is still being saved -- try again in a moment.' : undefined}
                  onClick={() => { if (a.disabled) return; setMoreAnchor(null); a.onSelect(); }}>
                  <ListItemIcon>{a.icon}</ListItemIcon>
                  <ListItemText primary={a.label} secondary={a.secondary} />
                </MenuItem>
              ))}
              {lifecycleItems.length > 0 && <Divider />}
              <MenuItem data-testid="report-more-history" onClick={() => { setHistoryAnchor(moreAnchor); setHistoryOpen(true); setMoreAnchor(null); }}>
                <ListItemIcon><HistoryIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Run history</ListItemText>
              </MenuItem>
              {executionResult && (canEdit || !!report?.layout_config?.diagnostics_for_viewers) && (
                <MenuItem data-testid="report-more-diagnostics" onClick={() => { setDiagOpenKey(k => k + 1); setMoreAnchor(null); }}>
                  <ListItemIcon><DiagnosticsIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>How this run worked{canEdit ? ' (with the SQL)' : ''}</ListItemText>
                </MenuItem>
              )}
              <Divider />
              <MenuItem data-testid="report-more-email" onClick={() => { setSubOpen(true); setMoreAnchor(null); }}>
                <ListItemIcon><EmailIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Email it on a schedule</ListItemText>
              </MenuItem>
              <MenuItem data-testid="report-more-dashboard" aria-label="Add to a dashboard" onClick={() => { setAddToDashOpen(true); setMoreAnchor(null); }}>
                <ListItemIcon><AddToDashboardIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Add to a dashboard</ListItemText>
              </MenuItem>
              {/* minting share links / embed tokens is owner-or-admin on the backend */}
              {mayShare && (
                <MenuItem data-testid="report-more-share" onClick={async () => {
                  setMoreAnchor(null);
                  try {
                    const share = await api.createBusinessReportShare(reportId);
                    const url = `${window.location.origin}/shared-business-report/${share.token}`;
                    navigator.clipboard.writeText(url);
                    setToast('Share link copied to clipboard!');
                  } catch (e: any) { setToast(`Share error: ${e.message}`); }
                }}>
                  <ListItemIcon><ShareLinkIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Copy a share link</ListItemText>
                </MenuItem>
              )}
              {mayShare && (
                <MenuItem data-testid="report-more-embed" onClick={async () => {
                  setMoreAnchor(null);
                  try {
                    const tok = await api.createBusinessReportEmbed(reportId);
                    const url = `${window.location.origin}/embedded-business-report/${tok.token}`;
                    const html = `<iframe src="${url}" width="100%" height="600" frameBorder="0"></iframe>`;
                    navigator.clipboard.writeText(html);
                    setToast('Embed HTML copied to clipboard!');
                  } catch (e: any) { setToast(`Embed error: ${e.message}`); }
                }}>
                  <ListItemIcon><EmbedCodeIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Copy embed code (for another web page)</ListItemText>
                </MenuItem>
              )}
              {canEdit && (
                <MenuItem data-testid="report-more-publish-api" onClick={() => { setPublishApiOpen(true); setMoreAnchor(null); }}>
                  <ListItemIcon><PublishApiIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Publish as an API</ListItemText>
                </MenuItem>
              )}
              {canAuthor && (
                <MenuItem data-testid="report-more-comments" onClick={() => { setCollabTab('comments'); setCollabOpen(true); setMoreAnchor(null); }}>
                  <ListItemIcon><Badge badgeContent={commentCount} color="primary" max={99}><CommentIcon fontSize="small" /></Badge></ListItemIcon>
                  <ListItemText>Comments</ListItemText>
                </MenuItem>
              )}
              <MenuItem data-testid="report-more-changes" onClick={() => { setCollabTab('history'); setCollabOpen(true); setMoreAnchor(null); }}>
                <ListItemIcon><TimelineIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Change history</ListItemText>
              </MenuItem>
              {canEdit && <Divider />}
              {canEdit && (
                <MenuItem data-testid="edit-on-canvas" aria-label="Edit on the canvas"
                  onClick={() => { setMoreAnchor(null); navigate(reportEditPath(report?.slug ? { id: reportId, slug: report.slug } : reportId, 'design')); }}>
                  <ListItemIcon><DashboardCustomizeIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Design the tiles and charts</ListItemText>
                </MenuItem>
              )}
              {canEdit && !canvasOn && (
                <MenuItem data-testid="add-a-tile"
                  onClick={() => { setMoreAnchor(null); navigate(reportEditPath(report?.slug ? { id: reportId, slug: report.slug } : reportId, 'design')); }}>
                  <ListItemIcon><AddToDashboardIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Add a tile</ListItemText>
                </MenuItem>
              )}
              {canEdit && (
                <MenuItem data-testid="report-more-theme"
                  onClick={() => { setMoreAnchor(null); navigate(reportEditPath(report?.slug ? { id: reportId, slug: report.slug } : reportId, 'look')); }}>
                  <ListItemIcon><FormattingIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Theme and colours</ListItemText>
                </MenuItem>
              )}
              {canEdit && (
                <MenuItem data-testid="report-more-formatting" aria-label="formatting and calculations"
                  onClick={() => { setFormattingOpen(true); setMoreAnchor(null); }}>
                  <ListItemIcon><FormattingIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Formatting and calculations</ListItemText>
                </MenuItem>
              )}
              {canEdit && (
                <MenuItem data-testid="report-more-readiness" aria-label="readiness and SLO"
                  onClick={() => { setReadinessOpen(true); setMoreAnchor(null); }}>
                  <ListItemIcon><ReadinessIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>When the data is ready, and the deadline</ListItemText>
                </MenuItem>
              )}
              {canEdit && (
                <MenuItem data-testid="report-more-permissions" onClick={() => { setCollabTab('permissions'); setCollabOpen(true); setMoreAnchor(null); }}>
                  <ListItemIcon><PermissionsIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Who can see this report</ListItemText>
                </MenuItem>
              )}
              {/* Duplicate CREATES a report: an authoring act, hidden from a consumer role. */}
              {canAuthor && (
                <MenuItem data-testid="report-more-duplicate" onClick={async () => {
                  setMoreAnchor(null);
                  try {
                    const dup = await api.duplicateBusinessReport(reportId);
                    navigate(reportEditPath(dup));
                  } catch { /* the list says so */ }
                }}>
                  <ListItemIcon><DuplicateIcon fontSize="small" /></ListItemIcon>
                  <ListItemText>Make a copy</ListItemText>
                </MenuItem>
              )}
            </Menu>
            {/* Columns (2026-08-31): narrows the screen; the export follows */}
            <Menu anchorEl={colMenuAnchor} open={Boolean(colMenuAnchor)}
                  onClose={() => setColMenuAnchor(null)}>
              <MenuItem dense onClick={() => setHiddenCols(new Set())}>
                <ListItemText primaryTypographyProps={{ variant: 'body2', fontWeight: 600 }}>
                  Show all ({baseCols.length})
                </ListItemText>
              </MenuItem>
              <Divider />
              {baseCols.map((c) => {
                const shown = !hiddenCols.has(c);
                const lastOne = shown && allCols.length === 1;
                return (
                  <MenuItem key={c} dense disabled={lastOne}
                    onClick={() => setHiddenCols(prev => {
                      const next = new Set(prev);
                      // Never hide the last visible column: an empty grid is
                      // not a narrower report, it is a broken one -- the same
                      // rule the server applies to ?columns=.
                      if (shown) { if (!lastOne) next.add(c); } else next.delete(c);
                      return next;
                    })}>
                    <Checkbox checked={shown} size="small" sx={{ p: 0.5, mr: 1 }} />
                    <ListItemText primaryTypographyProps={{ variant: 'body2' }}>{c}</ListItemText>
                  </MenuItem>
                );
              })}
            </Menu>
            <Popover open={Boolean(bookmarksAnchor)} anchorEl={bookmarksAnchor} onClose={() => setBookmarksAnchor(null)}
              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }} transformOrigin={{ vertical: 'top', horizontal: 'right' }}
              slotProps={{ paper: { sx: { p: 1.5, width: { xs: '95vw', sm: 420 } }, 'data-testid': 'report-bookmarks' } as any }}>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>Bookmarks</Typography>
              {/* applying sets the values and runs the report, like a pick in the band */}
              <ReportBookmarks reportId={reportId} paramValues={paramValues}
                onApply={vals => { const next = { ...paramValues, ...vals }; setParamValues(next); setBookmarksAnchor(null); handleExecute(next); }} />
            </Popover>
          </Box>
        </Box>
        {report.description && (
          <Tooltip title={report.description}>
            <Typography variant="body2" data-testid="report-description" noWrap
              sx={{ order: 1, minWidth: 0, flex: { xs: '1 1 100%', sm: '1 1 0' }, fontStyle: 'italic',
                    color: 'text.secondary', fontSize: 13 }}>
              {report.description}
            </Typography>
          </Tooltip>
        )}
        <Dialog open={themeDialogOpen} onClose={() => setThemeDialogOpen(false)} maxWidth="md" fullWidth fullScreen={isMobile}
          aria-labelledby="view-theme-title" slotProps={{ paper: { 'data-testid': 'view-theme-dialog' } as any }}>
          <DialogTitle id="view-theme-title">View in another theme</DialogTitle>
          <DialogContent dividers>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
              Pick a look for your screen. Only you see it, and the Excel and PDF you download from here
              use it too. The report itself does not change for anyone else.
            </Typography>
            {themeDialogOpen && (
              <ThemeGallery library={themeLibrary || {}}
                picked={viewThemeKnown && viewTheme ? viewTheme : String(report?.layout_config?.theme?.name || DEFAULT_THEME_NAME)}
                onPick={(name) => { pickViewTheme(name); setThemeDialogOpen(false); }} />
            )}
          </DialogContent>
          <DialogActions>
            <Button data-testid="view-theme-own" disabled={!viewTheme}
              onClick={() => { pickViewTheme(null); setThemeDialogOpen(false); }}>
              Use the report's own theme
            </Button>
            <Button onClick={() => setThemeDialogOpen(false)}>Close</Button>
          </DialogActions>
        </Dialog>
        {canEdit && formattingOpen && (
          <ReportFormattingPanel reportId={reportId} open={formattingOpen}
            onClose={() => setFormattingOpen(false)}
            onSaved={(updated: any) => setReport(updated)} />
        )}
        {canEdit && readinessOpen && (
          <ReportReadinessSloDialog open={readinessOpen} reportId={reportId}
            reportName={report?.name}
            onClose={() => setReadinessOpen(false)}
            onSaved={() => setSloRefresh(n => n + 1)} />
        )}
        {/* the quieter line: publish state as a tag, this run's sign-off, the instance, the run history */}
        <Box sx={{ order: 3, flexBasis: '100%', display: 'flex', alignItems: 'center', columnGap: 1, rowGap: 0.5, flexWrap: 'wrap',
                   color: 'text.secondary', '& .MuiChip-root': { height: 22, fontSize: 12 },
                   // the publish state: a small rounded tag (green tint = published, neutral = draft)
                   '& [data-testid="lifecycle-state-chip"]': { borderRadius: 999, fontWeight: 600, letterSpacing: '0.02em' },
                   '& [data-testid="lifecycle-state-chip"].MuiChip-colorSuccess': {
                     bgcolor: tint(muiTheme.palette.success.main, dark ? 0.22 : 0.12),
                     color: dark ? muiTheme.palette.success.light : muiTheme.palette.success.dark,
                     border: '1px solid', borderColor: tint(muiTheme.palette.success.main, 0.4) },
                   '& [data-testid="lifecycle-state-chip"].MuiChip-colorWarning': {
                     bgcolor: tint(muiTheme.palette.warning.main, dark ? 0.22 : 0.14),
                     color: dark ? muiTheme.palette.warning.light : muiTheme.palette.warning.dark },
                   '& [data-testid="lifecycle-state-chip"].MuiChip-outlinedDefault': {
                     bgcolor: tint(muiTheme.palette.text.primary, dark ? 0.1 : 0.05), borderColor: 'divider' },
                   // the instance and when it ran: one small, quiet line after a soft dot
                   '& [data-testid="signoff-instance"]': {
                     fontSize: 12, letterSpacing: '0.02em', fontVariantNumeric: 'tabular-nums', color: 'text.secondary',
                     display: 'inline-flex', alignItems: 'center',
                     '&::before': { content: '"\\2022"', mr: 1, opacity: 0.45 } } }}
          data-testid="report-status-line">
          {report.template_category && (
            <Chip label={report.template_category} size="small" variant="outlined"
              sx={{ borderRadius: 999, color: headerAccent, borderColor: tint(headerAccent, 0.5), bgcolor: tint(headerAccent, dark ? 0.16 : 0.07) }} />
          )}
          {viewThemeKnown && viewTheme && (
            <Tooltip title="Only your screen shows this theme. Click to go back to the report's own theme.">
              <Chip size="small" variant="outlined" icon={<ViewThemeIcon />} clickable data-testid="view-theme-chip"
                label={`Shown in the theme ${viewTheme}`} onDelete={() => pickViewTheme(null)}
                onClick={() => setThemeDialogOpen(true)}
                sx={{ borderRadius: 999, borderColor: tint(headerAccent, 0.5) }} />
            </Tooltip>
          )}
          <ReportLifecycleControls report={report} canEdit={canEdit}
            isAdmin={isAdminLike} onReportChange={setReport} onNotify={setToast} onMenuItems={setLifecycleItems} />
          {executionResult && !executing && (
            <InstanceSignoffHeader compact
              reportId={reportId}
              instanceId={instanceInfo?.instanceId ?? null}
              executionId={executionResult.execution_id ?? null}
              paramValues={paramValues}
              defaultBusinessDate={(() => {
                const p = (report.parameters || []).find((x: any) => x.parameter_type === 'date');
                const v = p ? paramValues[p.name] : null;
                return typeof v === 'string' && /^\d{4}-\d{2}-\d{2}/.test(v) ? v.slice(0, 10) : null;
              })()}
              refreshKey={executionResult.execution_id} />
          )}
          <Chip size="small" variant="outlined" icon={<HistoryIcon />} clickable
            label={`History${historyTotal > 0 ? ` (${historyTotal})` : ''}`}
            data-testid="history-chip" aria-label="Execution History"
            onClick={(e) => { setHistoryAnchor(e.currentTarget); setHistoryOpen(true); }} />
          <Popover open={Boolean(historyAnchor)} anchorEl={historyAnchor}
            onClose={() => { setHistoryAnchor(null); setHistoryOpen(false); }}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
            slotProps={{ paper: { sx: { width: { xs: '95vw', sm: 640 }, maxHeight: 480 } } }}>
            <Typography variant="subtitle2" sx={{ px: 2, pt: 1.5 }}>Run history</Typography>

            {historyLoading ? (
              <Box sx={{ p: 2, textAlign: 'center' }}><CircularProgress size={20} /></Box>
            ) : historyItems.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ px: 2, pb: 2 }}>
                This report has not been run yet.
              </Typography>
            ) : (
              <>
                <TableContainer>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Status</TableCell>
                        <TableCell>Started</TableCell>
                        <TableCell>Completed</TableCell>
                        <TableCell align="right">Rows</TableCell>
                        <TableCell>Run By</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {historyItems.map((h: any) => (
                        <TableRow key={h.execution_id} hover>
                          <TableCell>
                            <Chip
                              size="small"
                              label={h.status}
                              color={h.status === 'completed' ? 'success' : h.status === 'failed' ? 'error' : h.status === 'running' ? 'warning' : 'default'}
                              variant="outlined"
                            />
                          </TableCell>
                          <TableCell sx={{ whiteSpace: 'nowrap' }}>
                            {h.created_at ? new Date(h.created_at).toLocaleString() : '—'}
                          </TableCell>
                          <TableCell sx={{ whiteSpace: 'nowrap' }}>
                            {h.completed_at ? new Date(h.completed_at).toLocaleString() : '—'}
                          </TableCell>
                          <TableCell align="right">
                            {h.total_rows != null ? h.total_rows.toLocaleString() : '—'}
                          </TableCell>
                          <TableCell>{h.created_by || '—'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
                {historyTotal > historyPageSize && (
                  <TablePagination
                    component="div"
                    count={historyTotal}
                    page={historyPage}
                    onPageChange={(_, p) => setHistoryPage(p)}
                    rowsPerPage={historyPageSize}
                    onRowsPerPageChange={e => { setHistoryPageSize(Number(e.target.value)); setHistoryPage(0); }}
                    rowsPerPageOptions={[10, 25, 50]}
                  />
                )}
              </>
            )}
          </Popover>
        </Box>
      </Box>

      {/* Deprecated / archived disclosure — viewers must never consume a
          retired report without being told. */}
      <ReportLifecycleBanner report={report} />

      {/* Phase 114-L: Collaboration Panel (Comments / Change History).
          2026-10-26: a side drawer over the page -- it never pushes the report down. */}
      <Drawer anchor="right" open={collabOpen} onClose={() => setCollabOpen(false)}
        slotProps={{ paper: { sx: { width: { xs: '100%', sm: 460 } } } }}>
        <Paper elevation={0} sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
          <Box sx={{ display: 'flex', borderBottom: '1px solid', borderColor: 'divider' }}>
            {canAuthor && (
            <Button size="small" sx={{ flex: 1, borderRadius: 0, fontWeight: collabTab === 'comments' ? 700 : 400,
              borderBottom: collabTab === 'comments' ? '2px solid' : 'none', borderColor: 'primary.main' }}
              onClick={() => setCollabTab('comments')}>
              Comments {commentCount > 0 ? `(${commentCount})` : ''}
            </Button>
            )}
            <Button size="small" sx={{ flex: 1, borderRadius: 0, fontWeight: collabTab === 'history' ? 700 : 400,
              borderBottom: collabTab === 'history' ? '2px solid' : 'none', borderColor: 'primary.main' }}
              onClick={() => setCollabTab('history')}>
              Change History
            </Button>
            {canEdit && (
            <Button size="small" sx={{ flex: 1, borderRadius: 0, fontWeight: collabTab === 'permissions' ? 700 : 400,
              borderBottom: collabTab === 'permissions' ? '2px solid' : 'none', borderColor: 'primary.main' }}
              onClick={() => setCollabTab('permissions')}>
              Permissions
            </Button>
            )}
          </Box>
          <Box sx={{ flex: 1, overflowY: 'auto' }}>
            {collabTab === 'comments' && canAuthor && <ReportCommentPanel reportId={reportId} />}
            {collabTab === 'history' && <ReportChangeHistory reportId={reportId} />}
            {collabTab === 'permissions' && (
              <BusinessReportPermissionsTab reportId={reportId} addNotification={(n) => setToast(n.message)} />
            )}
          </Box>
        </Paper>
      </Drawer>


      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}
      {/* 2026-08-31 -- INFO, not error: nothing failed. The run is
          healthy and continues server-side; we simply stopped
          watching it after ten minutes. */}
      {stillRunning && (
        <Alert severity="info" sx={{ mb: 2 }} onClose={() => setStillRunning(false)}>
          This report is taking a while and is still running in the background.
          You can leave this page &mdash; you&rsquo;ll get a notification when it&rsquo;s
          ready, and opening the report again will show the finished result.
        </Alert>
      )}

      {/* 2026-09-05 — THE SNAPSHOT THIS SESSION WAS READING HAS MOVED (409
          result_snapshot_moved).  The server's own message is rendered,
          never a paraphrase, because the two reasons lead to opposite
          conclusions: `consolidated` means the build finished and the same
          answer is now one file (nothing was lost); `rebuilt` means a
          different run replaced it and the rows on screen before this were
          from a result that no longer exists. */}
      {snapshotMoved && (
        <Alert
          severity={snapshotMoved.reason === 'consolidated' ? 'info' : 'warning'}
          sx={{ mb: 2 }}
          data-testid="snapshot-moved"
          data-reason={snapshotMoved.reason}
          onClose={() => setSnapshotMoved(null)}>
          <strong>
            {snapshotMoved.reason === 'consolidated'
              ? 'The result finished building while you were reading it.'
              : snapshotMoved.reason === 'rebuilt'
                ? 'This report was re-run while you were reading it.'
                : 'The result you were reading has moved.'}
          </strong>
          {' '}{snapshotMoved.message}
        </Alert>
      )}

      {/* 2026-09-05 — PROGRESSIVE SERVING.  A partitioned build lands its
          rows as immutable parts, and this viewer shows them as they arrive
          instead of waiting for the last one ("if query returning 100K then
          it will not show result till the time 100K written").  Everything
          stated here is the server's disclosure: the rows on screen are ONE
          pinned snapshot (paging cannot skip or repeat), the total is a
          floor while `total_mode` is at_least, and the refresh is offered
          with the REASON the server gave — `more_rows` and `build_complete`
          are different facts and a user acts differently on each. */}
      {progressive && executionResult && (
        <Alert
          severity="info"
          sx={{ mb: 2 }}
          role="status"
          data-testid="progressive-banner"
          data-state={progressive.building ? 'building' : 'build_complete'}
          data-refresh-reason={progressive.refreshReason || ''}
          action={progressive.refreshAvailable ? (
            <Button color="inherit" size="small" startIcon={<RefreshIcon />}
              data-testid="progressive-refresh"
              onClick={handleProgressiveRefresh}>
              Refresh
            </Button>
          ) : undefined}>
          {progressive.building ? (
            <>
              <strong>Still building — showing the first {totalRows.toLocaleString()} rows.</strong>
              {' '}These are a fixed snapshot of the rows produced so far, so paging
              through them cannot skip or repeat a row. More rows are still being
              produced{rowsReady > totalRows
                ? ` — ${rowsReady.toLocaleString()} are ready now`
                : ''}.
            </>
          ) : (
            <>
              <strong>All chunks have been merged.</strong>
              {' '}The rows below are the snapshot you have been reading. Refresh to
              load the complete result.
            </>
          )}
          {progressive.refreshAvailable && progressive.refreshReason === 'more_rows' && (
            <Typography variant="caption" component="div" sx={{ mt: 0.5 }}
              data-testid="progressive-refresh-reason">
              Refresh loads the rows produced since this page was pinned.
            </Typography>
          )}
          {progressive.refreshAvailable && progressive.refreshReason === 'build_complete' && (
            <Typography variant="caption" component="div" sx={{ mt: 0.5 }}
              data-testid="progressive-refresh-reason">
              Refresh loads the finished result in place of this snapshot.
            </Typography>
          )}
          {sortColumn && progressive.sortScope === 'pinned_prefix' && (
            <Typography variant="caption" component="div" sx={{ mt: 0.5 }}
              data-testid="progressive-sort-scope">
              Sorted over the rows produced so far — a row that arrives later can
              still sort above these.
            </Typography>
          )}
        </Alert>
      )}

      {/* Phase 2 UX (2026-08-09): instance disclosure — "Data as of <time> ·
          Refresh".  Always visible when serving a stored instance; stored
          data must never be mistakable for live.  Staleness is a CAP: the
          data still shows, the banner just escalates to warning.  Unknown
          freshness is disclosed as unknown, never rendered as fresh.
          Also shown DURING an auto-open execute (probe-derived provisional
          info) so the open feels instant rather than flashing; a manual or
          Refresh run starts with instanceInfo=null, so no banner then. */}
      {instanceInfo && instanceInfo.stale && (executionResult || executing) && (
        <Alert severity="warning" icon={<HistoryIcon fontSize="inherit" />} role="status"
          data-testid="asof-stale" sx={{ mb: 2 }}>
          {staleWords(instanceInfo)}
        </Alert>
      )}

      {/* 2026-09-28: commentary + sign-off on THIS instance.  The header
          asks the server which instance this view is (the served instance's
          id, else the live run's execution id), what the caller may do and
          what is visible to their row-security scope.  A run that was not
          recorded as an instance says "nothing to sign". */}

      {executing && !asyncExecId && queuedWait.queued && (
        /* H1 item 5: the sync run waits for a server slot -- its place,
           told under the correlation id it sent. */
        <Alert severity="warning" role="status" data-testid="queued-wait" sx={{ mb: 2 }}
          action={<Button color="inherit" size="small" onClick={handleCancelExecution}>Cancel</Button>}>
          <strong>{queuedWaitLabel(queuedWait.queued)}</strong> &middot; waiting for a free slot &mdash; the report starts automatically.
        </Alert>
      )}

      {/* Async progress bar — with elapsed time, a cancel affordance, and an
          honest "still working" note past the 10s attention limit (§5). */}
      {executing && asyncExecId && (
        <Box sx={{ mb: 2 }} role="status" aria-live="polite">
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
            <Typography variant="body2" color="text.secondary">
              Running report... {asyncProgress}%{elapsedSec > 0 ? ` · ${elapsedSec}s elapsed` : ''}
            </Typography>
            <Button size="small" color="error" startIcon={<CancelIcon />}
              onClick={handleCancelExecution}>
              Cancel
            </Button>
          </Box>
          {capacityWait && (
            <Typography variant="body2" color="warning.main" data-testid="capacity-wait" sx={{ mb: 0.5 }}>
              {capacityWait}
            </Typography>
          )}
          <LinearProgress variant={capacityWait ? 'indeterminate' : 'determinate'} value={asyncProgress} />
          {/* A partitioned build makes rows durable long before it finishes.
              "0 rows so far" is a different statement from "no rows", and
              this is the only place the difference can be shown before the
              first page arrives. */}
          {progressive?.building && (
            <Typography variant="caption" color="text.secondary" component="div"
              data-testid="progressive-progress">
              {rowsReady.toLocaleString()} rows ready so far
              {progressive.partsReady > 0 ? ` (${progressive.partsReady} chunk${progressive.partsReady === 1 ? '' : 's'})` : ''}
              {' '}— shown below as they arrive.
            </Typography>
          )}
          {elapsedSec >= 10 && (
            <Typography variant="caption" color="text.secondary">
              Still working — large reports can take a while. You can keep waiting, or cancel and narrow the parameters.
            </Typography>
          )}
        </Box>
      )}

      {/* 2026-11-01 -- THE BAND IS THE CONTROL: every visible parameter is a cell; a
          click opens its picker, a pick re-runs the report.  A canvas band tile draws
          the cells it lists itself (BandControlsContext); this band holds the rest. */}
      {topBand.show && (
        <ReportBand ctrl={bandCtrl} theme={reportTheme} names={topBand.names} withExtras code={canvas.report_code ?? null} />
      )}
      {versionRefusal && (
        <Alert severity="error" data-testid="data-version-refusal" sx={{ mb: 1.5 }} onClose={() => setVersionRefusal(null)}>{versionRefusal}</Alert>
      )}

      {/* Phase 85D-4: Slicer Bar — improved label */}
      {report.slicer_column_ids && report.slicer_column_ids.length > 0 && rawRows.length > 0 && (
        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 1, mb: 1 }}>
            <Typography variant="subtitle2">Filter Results By:</Typography>
            <Typography variant="caption" color="text.secondary">
              (applies after data loads — no re-query needed)
            </Typography>
          </Box>
        <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
          {report.slicer_column_ids.map((colId: number) => {
            const physName = getColPhysicalName(colId);
            const options = (serverEngineActive
              ? serverSlicerOptions[physName]
              : engineOutput.slicerOptions[physName]) || [];
            const selected = slicerValues[String(colId)] || [];
            return (
              <FormControl key={colId} size="small" sx={{ minWidth: 160 }}>
                <InputLabel id="sel-businessreportviewer-field-2">{getColDisplayName(colId)}</InputLabel>
                <Select labelId="sel-businessreportviewer-field-2"
                  multiple value={selected} label={getColDisplayName(colId)}
                  onChange={e => setSlicerValues(prev => ({ ...prev, [String(colId)]: e.target.value as string[] }))}
                  renderValue={(sel: string[]) => sel.length === 0 ? 'All' : sel.join(', ')}
                >
                  {options.map((v: string) => (
                    <MenuItem key={v} value={v}>{v}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            );
          })}
        </Box>
        </Box>
      )}

      {/* Drill-Down Controls (Power BI style).  On mobile the buttons grow
          to comfortable touch-target size (40px+). */}
      {hasDrill && executionResult && (
        <Box sx={{ mb: 2, display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
          <Box sx={{ display: 'flex', gap: 0.5, border: '1px solid', borderColor: 'divider', borderRadius: 1, p: 0.5 }}>
            <Tooltip title="Drill up one level">
              <span><IconButton size={isMobile ? 'medium' : 'small'} disabled={!canDrillUp || executing}
                aria-label="Drill up one level"
                onClick={() => handleDrillUp(Math.max(0, drillState.level - 1))}>
                <DrillUpIcon fontSize="small" />
              </IconButton></span>
            </Tooltip>
            <Tooltip title={`Go to next level${canDrillDeeper ? ': ' + drillHierarchyLevels[drillState.level]?.label : ''}`}>
              <span><IconButton size={isMobile ? 'medium' : 'small'} disabled={!canDrillDeeper || executing}
                aria-label="Go to next drill level"
                onClick={handleGoToNextLevel}>
                <GoNextLevelIcon fontSize="small" />
              </IconButton></span>
            </Tooltip>
            <Tooltip title="Expand — add next hierarchy column alongside current">
              <span><IconButton size={isMobile ? 'medium' : 'small'} disabled={!canDrillDeeper || executing}
                aria-label="Expand next hierarchy level as a column"
                onClick={handleExpandNextLevel}>
                <ExpandNextLevelIcon fontSize="small" />
              </IconButton></span>
            </Tooltip>
            <Tooltip title={drillClickMode ? 'Click-to-drill is ON — click any row to drill into it' : 'Enable click-to-drill mode'}>
              <IconButton size={isMobile ? 'medium' : 'small'}
                color={drillClickMode ? 'primary' : 'default'}
                aria-label={drillClickMode ? 'Disable click-to-drill mode' : 'Enable click-to-drill mode'}
                aria-pressed={drillClickMode}
                onClick={() => setDrillClickMode(!drillClickMode)}>
                <DrillClickIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Box>
          {/* Hierarchy level indicator */}
          <Typography variant="caption" color="text.secondary">
            {drillHierarchyLevels[drillState.level]?.label || 'Detail'}
            {expandedLevels > 0 && ` + ${expandedLevels} level${expandedLevels > 1 ? 's' : ''}`}
          </Typography>
          {/* Breadcrumb trail */}
          {drillState.filters.length > 0 && (
            <Breadcrumbs separator={<NavNextIcon sx={{ fontSize: 14 }} />} sx={{ ml: 1 }}>
              <Link component="button" variant="caption" underline="hover"
                onClick={() => handleDrillUp(0)}>All</Link>
              {drillState.filters.map((f, idx) => {
                const lvLabel = drillHierarchyLevels[idx]?.label || f.column;
                return (
                  <Link key={idx} component="button" variant="caption" underline="hover"
                    onClick={() => handleDrillUp(idx + 1)}>
                    {lvLabel}: {f.value}
                  </Link>
                );
              })}
            </Breadcrumbs>
          )}
        </Box>
      )}

      {canvasOn ? (
        <Box sx={{ mt: 1 }}>
          {/* 2026-10-30 -- a header band tile shows the values the RUN used (its own record,
              CanvasOutlineTile.useBandValues); the page's values only when there is no run, said so */}
          <CanvasThemeContext.Provider value={reportTheme}>
          <CanvasCompareContext.Provider value={compareFrom(canvas, (report?.parameters || []).map((p: any) => ({ name: p.name, value: paramValues[p.name], label: p.label })), report?.parameters || [])}>
          <CanvasBandContext.Provider value={{
            reportName: report?.name ?? '', reportCode: canvas.report_code ?? null,
            parameters: (report?.parameters || []).map((p: any) => ({
              name: p.name, label: p.label || p.name, value: paramValues[p.name] })),
            reportId, executionId: executing ? null : (executionResult?.execution_id ?? null),
          }}>
          <BandControlsContext.Provider value={{ ...bandCtrl, append: topBand.append }}>
          <CanvasActionsProvider reportId={reportId} canvas={canvas} parameterValues={paramValues} links={actionLinkChips}
            executionId={executing ? null : (executionResult?.execution_id ?? null)}>
          {mine.allowed && <ViewerLayoutBar hasOwn={mine.hasOwn} reset={mine.reset} note={mine.note} />}
          <ReportCanvasView canvas={shownCanvas} reportId={reportId} cols={canvasCols}
            grouped={canvasGrouped} reportTable={resultsRegion} linkStore={canvasLinkStore}
            rearrange={mine.allowed} onLayout={mine.allowed ? mine.onLayout : undefined} onPickFields={mine.allowed ? mine.onFields : undefined}
            run={{
              executionId: executing ? null : (executionResult?.execution_id ?? null),
              totalRows: executionResult ? (typeof totalRows === 'number' ? totalRows : null) : null,
              truncated: truncated === true,
              rowLimit: report?.row_limit ?? null,
            }} />
          </CanvasActionsProvider>
          </BandControlsContext.Provider>
          </CanvasBandContext.Provider>
          </CanvasCompareContext.Provider>
          </CanvasThemeContext.Provider>
        </Box>
      ) : (
        // every report is a canvas: this one is its own table alone (the page exactly as before)
        // (a stored canvas with no tile at all shows the table too, as it always did)
        <ReportCanvasView canvas={isTableOnlyCanvas(canvas) ? canvas : effectiveCanvas(null)} reportId={reportId}
          cols={canvasCols} grouped={canvasGrouped}
          reportTable={resultsRegion} run={{ executionId: null, totalRows: null, truncated: false, rowLimit: null }} />
      )}

      {report && (
        <AddToDashboardDialog open={addToDashOpen} onClose={() => setAddToDashOpen(false)}
          reportId={reportId} reportName={report.name} paramValues={paramValues} />
      )}

      {/* Subscription Manager Dialog */}
      <SubscriptionManager
        open={subOpen}
        onClose={() => setSubOpen(false)}
        reportId={reportId}
        reportType="business_report"
        reportName={report?.name || `Report ${reportId}`}
      />

      {/* Phase 91: Publish as external API dialog */}
      {publishApiOpen && (
        <PublishViewDialog
          open={publishApiOpen}
          onClose={() => setPublishApiOpen(false)}
          queryName={report?.name || ''}
          sourceType="business_report"
          businessReportId={reportId}
        />
      )}
      <Snackbar
        open={!!toast}
        autoHideDuration={3000}
        onClose={() => setToast('')}
        message={toast}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      />
    </Box>
  );
};

export default BusinessReportViewer;
