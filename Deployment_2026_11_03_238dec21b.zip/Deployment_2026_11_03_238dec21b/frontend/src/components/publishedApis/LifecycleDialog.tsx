/**
 * Move a published API through its lifecycle (2026-10-17, design §3.4):
 * draft / active / deprecated (with a sunset date and a successor) / retired.
 * Deprecating or retiring tells the consumers; the server validates (a
 * successor must exist and not be retired; retired -> anything is the
 * admin's act) and this dialog repeats what it answered.
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Autocomplete, Button, FormControl,
  InputLabel, MenuItem, Select, Stack, TextField, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import api from '../../services/api';
import type { LifecycleStatus, PublishedApiRow } from './types';

interface Props {
  api: PublishedApiRow | null;
  /** every API of the same kind (successor candidates) */
  siblings: PublishedApiRow[];
  onClose: () => void;
  onSaved: (result: any) => void;
}

const STATUS_WORDS: Record<LifecycleStatus, string> = {
  draft: 'Draft — not offered to consumers yet',
  active: 'Active — offered',
  deprecated: 'Deprecated — still answers, with Deprecation / Sunset / Link headers',
  retired: 'Retired — answers 410 Gone (consumers are told)',
};

const toLocalInput = (iso?: string | null): string => {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

export default function LifecycleDialog({ api: row, siblings, onClose, onSaved }: Props) {
  const [status, setStatus] = useState<LifecycleStatus>('active');
  const [sunset, setSunset] = useState('');
  const [note, setNote] = useState('');
  const [successor, setSuccessor] = useState<string>('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!row) return;
    const lc = row.lifecycle || ({} as any);
    setStatus((lc.status as LifecycleStatus) || 'active');
    setSunset(toLocalInput(lc.sunset_at));
    setNote(lc.deprecation_note || '');
    setSuccessor(lc.successor || '');
    setError(null);
  }, [row]);

  const save = async () => {
    if (!row) return;
    setSaving(true);
    setError(null);
    try {
      const body: any = { status };
      if (status === 'deprecated' && sunset) body.sunset_at = new Date(sunset).toISOString();
      if (status === 'deprecated' || status === 'retired') {
        body.deprecation_note = note || null;
        body.successor = successor || null;
      }
      const res = await (api as any).setPublishedApiLifecycle(row.api_kind, row.api_id, body);
      onSaved(res);
    } catch (e: any) {
      setError(e?.message || 'The lifecycle change was refused');
    } finally {
      setSaving(false);
    }
  };

  const candidates = siblings.filter(s => s.api_id !== row?.api_id && (s.lifecycle?.status || 'active') !== 'retired');

  return (
    <AppDialog open={!!row}
      onClose={onClose}
      size="sm"
      title={<>Lifecycle: {row?.name}</>}
      actions={<>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={save} disabled={saving} data-testid="lifecycle-save">
          {saving ? 'Saving...' : 'Save'}
        </Button>
      </>}>
        <Stack spacing={2} sx={{ mt: 1 }}>
          {error && <Alert severity="error" data-testid="lifecycle-error">{error}</Alert>}
          <Typography variant="caption" color="text.secondary">
            Now: <strong>{row?.lifecycle?.status || 'active'}</strong>
            {row?.lifecycle?.sunset_at ? ` · sunset ${new Date(row.lifecycle.sunset_at).toLocaleString()}` : ''}
            {row?.lifecycle?.changed_by ? ` · changed by ${row.lifecycle.changed_by}` : ''}
          </Typography>
          <FormControl size="small" fullWidth>
            <InputLabel id="lifecycle-status-label">Status</InputLabel>
            <Select labelId="lifecycle-status-label" label="Status" value={status}
                    onChange={e => setStatus(e.target.value as LifecycleStatus)}
                    inputProps={{ 'data-testid': 'lifecycle-status' }}>
              {(Object.keys(STATUS_WORDS) as LifecycleStatus[]).map(s => (
                <MenuItem key={s} value={s}>{STATUS_WORDS[s]}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {status === 'deprecated' && (
            <TextField label="Sunset (when it stops answering)" type="datetime-local" size="small"
                       value={sunset} onChange={e => setSunset(e.target.value)}
                       InputLabelProps={{ shrink: true }}
                       helperText="Consumers get a Sunset header; the daemon retires the API at this time and tells them again before" />
          )}
          {(status === 'deprecated' || status === 'retired') && (
            <>
              <Autocomplete freeSolo size="small" options={candidates.map(c => c.key)}
                            value={successor}
                            onChange={(_, v) => setSuccessor((v as string) || '')}
                            onInputChange={(_, v, reason) => { if (reason === 'input') setSuccessor(v); }}
                            renderInput={p => <TextField {...p} label="Successor (key of the API to use instead)" />} />
              <TextField label="Note to consumers" size="small" multiline rows={2} value={note}
                         onChange={e => setNote(e.target.value)} />
            </>
          )}
        </Stack>
    </AppDialog>
  );
}
