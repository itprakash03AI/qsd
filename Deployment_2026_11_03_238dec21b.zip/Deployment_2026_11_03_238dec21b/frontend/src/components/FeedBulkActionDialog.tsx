/**
 * FeedBulkActionDialog — bulk cancel / bulk skip-dependencies (2026-09-02).
 *
 * Two rules this dialog exists to enforce:
 *   1. A bulk action shows what it WILL affect before it runs — the
 *      preview lists every selected run and says which are eligible
 *      and which will be left alone (and why).
 *   2. It reports PER-ITEM outcomes after — one aggregate "done" hides
 *      the ones that failed.  Each run gets its own success/failure row.
 *
 * Bulk skip-dependencies additionally requires a typed reason (same
 * plain-words warning as the single-run flow: these feeds will run
 * WITHOUT their blocking inputs confirmed) and sends one
 * POST /api/feed-runs/{id}/skip-dependencies per run with
 * `dependencies: null` (all blocking) — the per-run dialog is the place
 * for cherry-picking individual dependencies.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Stack, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Cancel as CancelIcon, CheckCircle as DoneIcon, Error as FailIcon,
  RemoveCircleOutline as SkipDepIcon, Warning as WarnIcon,
} from '@mui/icons-material';
import api from '../services/api';
import SkipReasonFields, { useSkipReason } from './common/SkipReasonFields';

export type FeedBulkMode = 'cancel' | 'skip-deps';

export interface BulkRunTarget {
  id: number;
  feed_name?: string | null;
  feed_config_id: number;
  status: string;
  can_rerun?: boolean;
}

interface ItemOutcome {
  id: number;
  label: string;
  ok: boolean;
  message: string;
}

interface Props {
  mode: FeedBulkMode | null;
  runs: BulkRunTarget[];
  onClose: () => void;
  /** Called once after the batch finishes (any mix of outcomes) so the parent refreshes. */
  onDone: () => void;
}

const labelOf = (r: BulkRunTarget) => r.feed_name || `Feed #${r.feed_config_id}`;

const FeedBulkActionDialog: React.FC<Props> = ({ mode, runs, onClose, onDone }) => {
  const reason = useSkipReason();
  const [busy, setBusy] = useState(false);
  const [outcomes, setOutcomes] = useState<ItemOutcome[] | null>(null);

  useEffect(() => {
    if (mode) { reason.reset(); setOutcomes(null); }
  }, [mode]);  // eslint-disable-line react-hooks/exhaustive-deps

  // Eligibility — cancel only makes sense for not-yet-started runs the
  // user can act on; skip-deps targets any selected run (the server is
  // the authority and refusals surface as per-item failures).
  const { eligible, ineligible } = useMemo(() => {
    if (mode === 'cancel') {
      const ok: BulkRunTarget[] = [];
      const no: { run: BulkRunTarget; why: string }[] = [];
      for (const r of runs) {
        if (!(r.status === 'pending' || r.status === 'skipped')) {
          no.push({ run: r, why: `status is ${r.status}` });
        } else if (!r.can_rerun) {
          no.push({ run: r, why: 'view-only (not your feed)' });
        } else {
          ok.push(r);
        }
      }
      return { eligible: ok, ineligible: no };
    }
    return { eligible: runs, ineligible: [] as { run: BulkRunTarget; why: string }[] };
  }, [mode, runs]);

  const needsReason = mode === 'skip-deps';

  const execute = async () => {
    if (eligible.length === 0 || (needsReason && !reason.valid)) return;
    setBusy(true);
    const results: ItemOutcome[] = [];
    // Sequential on purpose: outcomes arrive in the order previewed and a
    // saturated backend is not hammered with N parallel mutations.
    for (const r of eligible) {
      try {
        if (mode === 'cancel') {
          await api.cancelFeedRun(r.id);
          results.push({ id: r.id, label: labelOf(r), ok: true, message: 'cancelled' });
        } else {
          const resp = await api.skipFeedRunDependencies(r.id, {
            ...reason.body,
            dependencies: null,
          });
          const gate = resp?.gate_now;
          results.push({
            id: r.id, label: labelOf(r), ok: true,
            message: gate?.admitted
              ? `skipped ${resp.skipped?.join(', ') || 'deps'} — gate now admits`
              : `skipped — still blocked by ${gate?.blocking?.join(', ') || 'other gates'}`,
          });
        }
      } catch (e: any) {
        results.push({ id: r.id, label: labelOf(r), ok: false, message: e?.message || String(e) });
      }
    }
    setOutcomes(results);
    setBusy(false);
    onDone();
  };

  const failedCount = outcomes?.filter(o => !o.ok).length ?? 0;

  return (
    <AppDialog open={mode != null}
      onClose={busy ? undefined : onClose}
      size="sm"
      title={<>{mode === 'cancel' ? 'Bulk cancel' : 'Bulk skip dependencies'} — {runs.length} selected</>}
      actions={<>
        {outcomes ? (
          <Button variant="contained" onClick={onClose}>Close</Button>
        ) : (
          <>
            <Button onClick={onClose} disabled={busy}>Back</Button>
            <Button
              variant="contained"
              color={mode === 'cancel' ? 'warning' : 'warning'}
              onClick={() => void execute()}
              disabled={busy || eligible.length === 0 || (needsReason && !reason.valid)}
              startIcon={busy
                ? <CircularProgress size={14} />
                : mode === 'cancel' ? <CancelIcon /> : <SkipDepIcon />}
            >
              {mode === 'cancel'
                ? `Cancel ${eligible.length} run${eligible.length === 1 ? '' : 's'}`
                : `Skip deps for ${eligible.length} feed${eligible.length === 1 ? '' : 's'}`}
            </Button>
          </>
        )}
      </>}>
        {outcomes ? (
          <Box data-testid="bulk-outcomes">
            <Alert severity={failedCount === 0 ? 'success' : 'warning'} sx={{ mb: 1.5 }}>
              {outcomes.length - failedCount} succeeded, {failedCount} failed.
            </Alert>
            {outcomes.map(o => (
              <Stack key={o.id} direction="row" spacing={1} alignItems="flex-start" sx={{ mb: 0.5 }}>
                {o.ok
                  ? <DoneIcon fontSize="small" color="success" />
                  : <FailIcon fontSize="small" color="error" />}
                <Typography variant="body2" sx={{ fontWeight: 600, minWidth: 140 }}>
                  {o.label}
                </Typography>
                <Typography variant="body2" color={o.ok ? 'text.secondary' : 'error'}>
                  {o.message}
                </Typography>
              </Stack>
            ))}
          </Box>
        ) : (
          <>
            {mode === 'skip-deps' && (
              <Alert severity="warning" icon={<WarnIcon />} sx={{ mb: 2 }}>
                <strong>{eligible.length} feed{eligible.length === 1 ? '' : 's'} will run
                WITHOUT their blocking inputs confirmed.</strong>  ALL currently-blocking
                dependencies of each selected run are skipped.  Output may be produced
                from incomplete upstream data; this is recorded with your name and the
                reason below.
              </Alert>
            )}
            {mode === 'cancel' && (
              <Alert severity="info" sx={{ mb: 2 }}>
                {eligible.length} pending run{eligible.length === 1 ? '' : 's'} will be cancelled.
              </Alert>
            )}

            <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5 }}>
              Will be affected ({eligible.length}):
            </Typography>
            <Box sx={{ maxHeight: 160, overflowY: 'auto', mb: 1.5 }}>
              {eligible.length === 0 && (
                <Typography variant="caption" color="text.secondary">
                  None of the selected runs can be {mode === 'cancel' ? 'cancelled' : 'skipped'}.
                </Typography>
              )}
              {eligible.map(r => (
                <Stack key={r.id} direction="row" spacing={0.75} alignItems="center">
                  <Typography variant="body2">• {labelOf(r)}</Typography>
                  <Chip size="small" label={r.status} variant="outlined"
                        sx={{ height: 16, fontSize: '0.6rem' }} />
                </Stack>
              ))}
            </Box>

            {ineligible.length > 0 && (
              <>
                <Typography variant="caption" sx={{ fontWeight: 700, display: 'block', mb: 0.5 }}>
                  Left alone ({ineligible.length}):
                </Typography>
                <Box sx={{ maxHeight: 120, overflowY: 'auto', mb: 1.5 }}>
                  {ineligible.map(({ run, why }) => (
                    <Typography key={run.id} variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                      • {labelOf(run)} — {why}
                    </Typography>
                  ))}
                </Box>
              </>
            )}

            {needsReason && (
              <SkipReasonFields
                state={reason}
                disabled={busy}
                textTestId="bulk-skip-reason"
                categoryTestId="bulk-skip-reason-category"
                textPlaceholder="Why is it safe for these feeds to proceed without their inputs?"
              />
            )}
          </>
        )}
    </AppDialog>
  );
};

export default FeedBulkActionDialog;
