/**
 * Phase 56+111 — Unified Reports List Page
 *
 * Lists ALL report types (Tabular, Pivot, Saved Query) in one place.
 * Phase 111: consolidated from separate report pages.
 * 2026-10-27 (the owner: "sample reports should be based on real tables and
 * queries, not seeded anymore"): no demo cards and no seeding.  A SAMPLE is any
 * real report its owner (or an admin) marks as one from the row menu; "Show
 * samples" lists them with a Sample label.
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useVirtualizer } from '@tanstack/react-virtual';
import {
  Box, Paper, Typography, Button, IconButton, Chip, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, Tooltip, CircularProgress,
  Alert, TextField, InputAdornment, Skeleton,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as ViewIcon,
  ContentCopy as DuplicateIcon,
  Search as SearchIcon,
  Bookmark as SampleIcon,
  CheckCircle as CertifiedIcon,
  CloudUpload as PublishIcon,
  CloudOff as UnpublishIcon,
  Visibility as VisibilityIcon,
  VisibilityOff as VisibilityOffIcon,
  DriveFileRenameOutline as RenameIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { canAuthorReports, isAdminLike } from '../utils/reportLifecycle';
import { getLifecycleState, isEndpointMissing } from '../utils/reportLifecycle';
import { NEW_REPORT_FROM_TEMPLATE_PATH, NEW_REPORT_PATH, reportEditPath, reportPath } from '../utils/reportUrls';
import RowActions, { RowAction } from './common/RowActions';

const PAGE_SIZE = 100;

/** Accept both response shapes: the paginated envelope, and the legacy
 *  full array (older servers / test mocks). */
const normalizeListResponse = (data: any) => Array.isArray(data)
  ? { items: data, next_cursor: null as string | null, has_more: false }
  : {
      items: Array.isArray(data?.items) ? data.items : [],
      next_cursor: (data?.next_cursor ?? null) as string | null,
      has_more: !!data?.has_more,
    };

const ReportsListPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [notice, setNotice] = useState('');
  const tableContainerRef = useRef<HTMLDivElement | null>(null);
  // Monotonic request sequence — a slow first-page response must never
  // clobber the results of a newer search.
  const reqSeqRef = useRef(0);

  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  // 2026-09-24: New Report and Duplicate CREATE a report -- an analyst/admin
  // act the API now enforces.  A viewer is not offered a button that 403s.
  const canAuthor = canAuthorReports(user);
  const username = user?.username || '';

  // 2026-09-18 — sample/demo reports are hidden by default (the server
  // does the filtering, inside the paginated query) so they cannot bury the
  // real ones.  The preference is per-browser; it is a view choice, not data.
  const [showSamples, setShowSamples] = useState<boolean>(() => {
    try { return localStorage.getItem('qs.reports.showSamples') === 'true'; }
    catch { return false; }
  });
  const toggleSamples = useCallback((next: boolean) => {
    setShowSamples(next);
    try { localStorage.setItem('qs.reports.showSamples', String(next)); }
    catch { /* private window — the toggle still works for this session */ }
  }, []);

  const loadReports = useCallback((q: string) => {
    const seq = ++reqSeqRef.current;
    setLoading(true);
    api.listBusinessReports({ limit: PAGE_SIZE, q: q || undefined,
                              include_samples: showSamples })
      .then((data: any) => {
        if (seq !== reqSeqRef.current) return;   // stale response
        const n = normalizeListResponse(data);
        setReports(n.items);
        setNextCursor(n.next_cursor);
        setHasMore(n.has_more);
      })
      .catch(() => { if (seq === reqSeqRef.current) setError('Failed to load reports'); })
      .finally(() => { if (seq === reqSeqRef.current) setLoading(false); });
  }, [showSamples]);

  // Debounced server-side search — 300 ms, the ReportCatalogPage precedent.
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  // Initial load (debouncedSearch starts '') + reload on each search change.
  useEffect(() => { loadReports(debouncedSearch); }, [debouncedSearch, loadReports]);

  const loadMore = useCallback(() => {
    if (!nextCursor || loadingMore) return;
    const seq = reqSeqRef.current;   // page-walk belongs to the current query
    setLoadingMore(true);
    api.listBusinessReports({
      limit: PAGE_SIZE, cursor: nextCursor,
      q: debouncedSearch || undefined,
      include_samples: showSamples,
    })
      .then((data: any) => {
        if (seq !== reqSeqRef.current) return;   // query changed mid-flight
        const n = normalizeListResponse(data);
        setReports(prev => [...prev, ...n.items]);
        setNextCursor(n.next_cursor);
        setHasMore(n.has_more);
      })
      .catch(() => { if (seq === reqSeqRef.current) setError('Failed to load more reports'); })
      .finally(() => setLoadingMore(false));
  }, [nextCursor, loadingMore, debouncedSearch, showSamples]);

  // ── Virtualized table body — render only the visible window ──────────
  const rowVirtualizer = useVirtualizer({
    count: reports.length,
    getScrollElement: () => tableContainerRef.current,
    estimateSize: () => 53,   // MUI Table size="small", two-line name cell
    overscan: 20,
  });
  const virtualRows = rowVirtualizer.getVirtualItems();
  const totalVirtualHeight = rowVirtualizer.getTotalSize();
  // Unmeasurable viewport (container measures 0 — SSR, hidden-tab mount,
  // happy-dom tests): virtual-core sets its range to null and yields NO
  // rows, which would blank the table.  Fall back to rendering the loaded
  // rows directly, bounded so the DOM stays small either way.
  const unmeasured = virtualRows.length === 0 && reports.length > 0;
  const renderRows: Array<{ index: number }> = unmeasured
    ? reports.slice(0, 200).map((_r, i) => ({ index: i }))
    : virtualRows;
  const vPaddingTop = !unmeasured && virtualRows.length > 0 ? (virtualRows[0]?.start ?? 0) : 0;
  const vPaddingBottom = !unmeasured && virtualRows.length > 0
    ? totalVirtualHeight - (virtualRows[virtualRows.length - 1]?.end ?? 0)
    : 0;

  // Infinite scroll: when the window nears the end of loaded rows, fetch
  // the next page (the Load More button below stays as explicit fallback).
  useEffect(() => {
    const last = renderRows[renderRows.length - 1];
    if (last && hasMore && !loadingMore && last.index >= reports.length - 15) {
      loadMore();
    }
  }, [renderRows, hasMore, loadingMore, reports.length, loadMore]);

  // 2026-09-27 -- a report served by live published views is refused with a
  // 409 naming them; the dialog shows that and offers Delete anyway.  Any
  // other failure is shown with the server's reason, never a bare "failed".
  const [deleteBlocked, setDeleteBlocked] = useState<string | null>(null);
  const closeDelete = () => { setDeleteId(null); setDeleteBlocked(null); };
  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await api.deleteBusinessReport(deleteId, deleteBlocked !== null);
      setReports(prev => prev.filter(r => r.id !== deleteId));
    } catch (e: any) {
      if (e?.status === 409 && deleteBlocked === null) {
        setDeleteBlocked(String(e?.message || 'Published views serve this report.'));
        return;
      }
      setError(`Failed to delete report: ${e?.message || 'unknown error'}`);
    }
    closeDelete();
  };

  // 2026-10-23 -- the owner: "Report name edit not available".  The name was
  // editable only on step 6 of 6 of Edit; Rename is now one action on the row.
  const [renameTarget, setRenameTarget] = useState<any | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [renameError, setRenameError] = useState<string | null>(null);
  const [renaming, setRenaming] = useState(false);
  const openRename = (r: any) => { setRenameTarget(r); setRenameValue(r.name || ''); setRenameError(null); };
  const closeRename = () => { if (!renaming) { setRenameTarget(null); setRenameError(null); } };
  const renameTrimmed = renameValue.trim();
  const handleRename = async () => {
    if (!renameTarget || !renameTrimmed || renameTrimmed === renameTarget.name) return;
    setRenaming(true);
    setRenameError(null);
    try {
      const saved = await api.updateBusinessReport(renameTarget.id, { name: renameTrimmed });
      const name = saved?.name ?? renameTrimmed;
      setReports(prev => prev.map(x => (x.id === renameTarget.id ? { ...x, name } : x)));
      setRenameTarget(null);
    } catch (e: any) {
      setRenameError(e?.message || 'The report could not be renamed.');
    } finally {
      setRenaming(false);
    }
  };

  const handleDuplicate = async (id: number) => {
    try {
      const dup = await api.duplicateBusinessReport(id);
      if (dup?.id) navigate(reportEditPath(dup));
    } catch { setError('Failed to duplicate report'); }
  };

  // ── Publish / unpublish from the list (2026-08-17) ───────────────────────
  // First reachable publish affordance in the product.  Unpublish prefers the
  // lifecycle endpoint and falls back to the legacy POST /publish TOGGLE when
  // the backend predates it (safe: only offered while currently published).
  const [lifecycleBusyId, setLifecycleBusyId] = useState<number | null>(null);
  const handleTogglePublish = async (r: any) => {
    setLifecycleBusyId(r.id);
    try {
      if (r.is_published) {
        try {
          await api.unpublishBusinessReport(r.id);
        } catch (e: any) {
          if (isEndpointMissing(e)) await api.publishBusinessReport(r.id, 'unpublish');
          else throw e;
        }
      } else {
        await api.publishBusinessReport(r.id);
      }
      // Re-fetch the single row — publish may have minted a version / state
      // the slim list projection doesn't carry.
      const fresh = await api.getBusinessReport(r.id);
      setReports(prev => prev.map(x => (x.id === r.id ? { ...x, ...fresh } : x)));
    } catch (e: any) {
      setError(e?.message || 'Failed to update publish state');
    } finally {
      setLifecycleBusyId(null);
    }
  };

  /* ── Mark / unmark a real report as a sample ────────────────────────── */
  const [sampleBusyId, setSampleBusyId] = useState<number | null>(null);
  const handleToggleSample = async (r: any) => {
    const next = !r.is_sample;
    setSampleBusyId(r.id);
    try {
      await api.updateBusinessReport(r.id, { is_sample: next });
      if (next && !showSamples) {
        // samples are listed only while "Show samples" is on
        setReports(prev => prev.filter(x => x.id !== r.id));
        setNotice(`"${r.name}" is now a sample. Turn on Show samples to see it.`);
      } else {
        setReports(prev => prev.map(x => (x.id === r.id ? { ...x, is_sample: next } : x)));
      }
    } catch (e: any) {
      setError(e?.message || 'The report could not be updated.');
    } finally {
      setSampleBusyId(null);
    }
  };

  if (loading) {
    return (
      <Box sx={{ p: 3 }}>
        <Skeleton variant="text" width={200} height={40} sx={{ mb: 2 }} />
        {[0, 1, 2, 3, 4, 5].map(i => (
          <Skeleton key={i} variant="rectangular" height={40} sx={{ mb: 1, borderRadius: 1 }} />
        ))}
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
        <Typography variant="h5" sx={{ flexGrow: 1, fontWeight: 600 }}>Reports</Typography>
        {(reports.length > 0 || search.trim() !== '') && (
          <TextField
            size="small" placeholder="Search reports..."
            value={search} onChange={e => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment> }}
            sx={{ width: 250 }}
          />
        )}
        {canAuthor && (
        <Button variant="contained" startIcon={<AddIcon />}
          onClick={() => navigate(NEW_REPORT_PATH)}>
          New Report
        </Button>
        )}
        {/* 2026-10-26 -- the canvas builder: tiles on a page, Business Objects / Power BI style */}
        {canAuthor && (
        <Button variant="outlined" startIcon={<AddIcon />} data-testid="new-canvas-report"
          onClick={() => navigate('/finance-reports/new/canvas')}>
          New canvas report
        </Button>
        )}
        {/* 2026-11-02 -- a report started from a design: template -> dataset -> slots -> name + theme */}
        {canAuthor && (
        <Button variant="outlined" startIcon={<AddIcon />} data-testid="new-report-from-template"
          onClick={() => navigate(NEW_REPORT_FROM_TEMPLATE_PATH)}>
          New report from a template
        </Button>
        )}
        <Tooltip title={showSamples
          ? 'Hide seeded demo and sample reports'
          : 'Show seeded demo and sample reports'}>
          <Button
            variant={showSamples ? 'contained' : 'outlined'}
            color={showSamples ? 'secondary' : 'inherit'}
            startIcon={showSamples ? <VisibilityOffIcon /> : <VisibilityIcon />}
            onClick={() => toggleSamples(!showSamples)}
            // 2026-09-18 - the Tooltip's title becomes the button's ACCESSIBLE
            // NAME, replacing the visible label.  A screen reader then
            // announced "Show seeded demo and sample reports" for a button
            // that reads "Show samples", and voice control saying "click Show
            // samples" matched nothing (WCAG 2.5.3, Label in Name).  Naming it
            // explicitly keeps the visible text inside the accessible name.
            aria-label={showSamples ? 'Hide samples' : 'Show samples'}
            data-testid={showSamples ? 'samples-hide' : 'samples-show'}
          >
            {showSamples ? 'Hide samples' : 'Show samples'}
          </Button>
        </Tooltip>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}
      {notice && <Alert severity="info" sx={{ mb: 2 }} onClose={() => setNotice('')}>{notice}</Alert>}

      {/* Reports table — server-paginated + virtualized (audit finding 3).
          Shown whenever rows are loaded OR a search is active (a zero-hit
          search must keep the search box and show the empty message). */}
      {(reports.length > 0 || search.trim() !== '') && (
        <>
          {reports.length === 0 ? (
            <Paper sx={{ p: 4, textAlign: 'center', mb: 4 }}>
              <Typography color="text.secondary">No matching reports found.</Typography>
            </Paper>
          ) : (
            <TableContainer component={Paper} ref={tableContainerRef}
              sx={{ mb: 1, maxHeight: 'calc(100vh - 230px)', minHeight: 240, overflow: 'auto' }}>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 'bold' }}>Name</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Type</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Owner</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Executions</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Last Executed</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Updated</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }} align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {/* Top spacer — keeps the scroll thumb honest (same
                      padding-row pattern as DataGridViewer) */}
                  {vPaddingTop > 0 && (
                    <TableRow><TableCell colSpan={8} sx={{ height: vPaddingTop, p: 0, border: 0 }} /></TableRow>
                  )}
                  {renderRows.map(virtualRow => {
                    const r = reports[virtualRow.index];
                    if (!r) return null;
                    return (
                    <TableRow key={r.id} hover sx={{ cursor: 'pointer' }}
                      onClick={() => navigate(reportPath(r))}>
                      <TableCell>
                        <Typography variant="body2" fontWeight="bold">{r.name}</Typography>
                        {r.description && (
                          <Typography variant="caption" color="text.secondary">{r.description.slice(0, 60)}</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        {/* Slim list projection carries a derived
                            `report_type`; legacy full payloads carry
                            layout_config — support both. */}
                        <Chip size="small" variant="outlined"
                          label={
                            r.data_source_type === 'raw_sql' ? 'Saved Query' :
                            ((r.report_type ?? r.layout_config?.report_type) === 'pivot') ? 'Pivot' :
                            'Tabular'
                          }
                          color={
                            r.data_source_type === 'raw_sql' ? 'info' :
                            ((r.report_type ?? r.layout_config?.report_type) === 'pivot') ? 'secondary' :
                            'default'
                          }
                        />
                      </TableCell>
                      <TableCell>{r.owner}</TableCell>
                      <TableCell>
                        {/* Lifecycle-aware status (2026-08-17): archived /
                            deprecated surface here too, tolerant of the
                            boolean-only backend via getLifecycleState. */}
                        {(() => {
                          const st = getLifecycleState(r);
                          return st === 'published'
                            ? <Chip size="small" label="Published" color="success" />
                            : st === 'deprecated'
                              ? <Chip size="small" label="Deprecated" color="warning" />
                              : st === 'archived'
                                ? <Chip size="small" label="Archived" variant="outlined" />
                                : <Chip size="small" label="Draft" variant="outlined" />;
                        })()}
                        {/* Certified tier (2026-08-09): the org-vetted trust
                            signal, surfaced where users choose what to open. */}
                        {r.is_sample && (
                          <Chip size="small" label="Sample" variant="outlined" sx={{ ml: 0.5 }} data-testid="report-sample-chip" />
                        )}
                        {r.is_certified && (
                          <Tooltip title={
                            `Certified${r.certified_by ? ` by ${r.certified_by}` : ''} — reviewed and approved as a trusted, authoritative report.`}>
                            <Chip size="small" icon={<CertifiedIcon />} label="Certified"
                              color="success" variant="outlined" sx={{ ml: 0.5 }} />
                          </Tooltip>
                        )}
                      </TableCell>
                      <TableCell>{r.execution_count || 0}</TableCell>
                      <TableCell>
                        {r.last_executed_at ? new Date(r.last_executed_at).toLocaleString() : '-'}
                      </TableCell>
                      <TableCell>
                        {r.updated_at ? new Date(r.updated_at).toLocaleDateString() : '-'}
                      </TableCell>
                      <TableCell align="right" onClick={e => e.stopPropagation()}>
                        {(() => {
                          const mine = r.owner === username || isAdmin;
                          const more: RowAction[] = [];
                          if (mine) more.push({ label: 'Rename', icon: <RenameIcon fontSize="small" />,
                            description: 'Change the report name', onClick: () => openRename(r) });
                          if (mine) more.push({
                            label: r.is_published ? 'Unpublish' : 'Publish',
                            icon: lifecycleBusyId === r.id ? <CircularProgress size={16} />
                              : r.is_published ? <UnpublishIcon fontSize="small" /> : <PublishIcon fontSize="small" />,
                            description: r.is_published ? 'Remove from the consumer portal' : 'Make visible in the consumer portal',
                            disabled: lifecycleBusyId === r.id, onClick: () => handleTogglePublish(r) });
                          if (mine) more.push({
                            label: r.is_sample ? 'Not a sample' : 'Mark as sample',
                            icon: sampleBusyId === r.id ? <CircularProgress size={16} /> : <SampleIcon fontSize="small" />,
                            description: r.is_sample ? 'List it with the other reports again'
                              : 'List it under Show samples, as an example others can open',
                            disabled: sampleBusyId === r.id, onClick: () => handleToggleSample(r) });
                          if (canAuthor) more.push({ label: 'Duplicate', icon: <DuplicateIcon fontSize="small" />,
                            description: 'Copy it as a new report', onClick: () => handleDuplicate(r.id) });
                          if (mine) more.push({ label: 'Delete', icon: <DeleteIcon fontSize="small" />, danger: true,
                            onClick: () => setDeleteId(r.id) });
                          const primary: RowAction[] = [
                            { label: 'Open', icon: <ViewIcon fontSize="small" />, onClick: () => navigate(reportPath(r)) }];
                          if (mine) primary.push({ label: 'Edit', icon: <EditIcon fontSize="small" />,
                            onClick: () => navigate(reportEditPath(r)) });
                          return <RowActions rowName={r.name} primary={primary} more={more} />;
                        })()}
                      </TableCell>
                    </TableRow>
                    );
                  })}
                  {/* Bottom spacer */}
                  {vPaddingBottom > 0 && (
                    <TableRow><TableCell colSpan={8} sx={{ height: vPaddingBottom, p: 0, border: 0 }} /></TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          )}
          {reports.length > 0 && (
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2, mb: 4 }}>
              <Typography variant="caption" color="text.secondary">
                {reports.length} report{reports.length === 1 ? '' : 's'} loaded{hasMore ? ' — scroll or load more' : ''}
              </Typography>
              {hasMore && (
                <Button size="small" variant="outlined" onClick={loadMore}
                  disabled={loadingMore}
                  startIcon={loadingMore ? <CircularProgress size={14} /> : undefined}>
                  {loadingMore ? 'Loading…' : 'Load more'}
                </Button>
              )}
            </Box>
          )}
        </>
      )}

      {/* 2026-10-27 (the owner: "hide all times Enterprise P&L and Position Reporting,
          remove all unwanted details"): no banner and no sales text.  Nothing yet is one
          plain line (New Report is in the toolbar). */}
      {reports.length === 0 && search.trim() === '' && (
        <Box sx={{ textAlign: 'center', my: 4 }} data-testid="reports-empty">
          {canAuthor ? (
            <Typography variant="body1" color="text.secondary">No reports yet.</Typography>
          ) : (
            <Typography variant="body2" color="text.secondary" data-testid="reports-empty-consumer">
              No reports have been shared with you yet. Ask a report owner or an admin for access.
            </Typography>
          )}
        </Box>
      )}
      <AppDialog open={renameTarget !== null}
        onClose={closeRename}
        size="sm"
        title="Rename report"
        actions={<>
          <Button onClick={closeRename} disabled={renaming}>Cancel</Button>
          <Button variant="contained" onClick={handleRename} data-testid="rename-report-save"
            disabled={renaming || !renameTrimmed || renameTrimmed === renameTarget?.name}>
            {renaming ? 'Saving…' : 'Rename'}
          </Button>
        </>}>
          <TextField autoFocus fullWidth margin="dense" label="Report name" value={renameValue}
            inputProps={{ 'data-testid': 'rename-report-input', maxLength: 255 }}
            onChange={e => setRenameValue(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') handleRename(); }}
            helperText={renameTrimmed ? 'Links, published APIs and schedules keep working: they use the report id, not its name.'
              : 'A report needs a name.'}
            error={!renameTrimmed} />
          {renameError && (
            <Alert severity="error" sx={{ mt: 1 }} data-testid="rename-report-error">{renameError}</Alert>
          )}
      </AppDialog>

      {/* Delete confirmation dialog */}
      <AppDialog open={deleteId !== null}
        onClose={closeDelete}
        size="xs"
        dividers={false}
        title="Delete Report"
        actions={<>
          <Button onClick={closeDelete}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDelete}>
            {deleteBlocked !== null ? 'Delete anyway' : 'Delete'}
          </Button>
        </>}>
          <Typography>
            Delete this report? It is switched off, not erased -- an admin or its owner can switch it
            back on under Admin -&gt; Switched off. Its share and embed links stop working and stay off;
            share it again after switching it on.
          </Typography>
          {deleteBlocked !== null && (
            <Alert severity="warning" sx={{ mt: 2 }} data-testid="delete-report-dependents">
              {deleteBlocked}
            </Alert>
          )}
      </AppDialog>
    </Box>
  );
};

export default ReportsListPage;
