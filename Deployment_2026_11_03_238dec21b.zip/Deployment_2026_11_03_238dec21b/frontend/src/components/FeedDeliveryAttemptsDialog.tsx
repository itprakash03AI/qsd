/**
 * FeedDeliveryAttemptsDialog — operator view of a feed's delivery
 * attempts + the three hop-level actions (2026-09-03; backend
 * api/feed_ops_api.py, FR-DEL-02/13).
 *
 * The contract this UI mirrors — deliberately, with no escape hatch:
 *   * RETRY re-sends ONE hop over the SAME certified manifest.  A
 *     non-idempotent target (sftp, oracle …) REQUIRES a typed reason —
 *     a duplicate send is a second regulatory submission — and there is
 *     NO force flag: a 409 refusal is final until a human marks the
 *     in-doubt attempt lost (out-of-band verification, named evidence).
 *   * MARK LOST resolves an INDETERMINATE ('running') attempt only,
 *     with a typed reason recording what was verified and how.
 *   * ACKNOWLEDGMENT records the counterparty's verdict
 *     (received / rejected) on the latest successful delivery.
 *
 * A failed load never renders like "no attempts".
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, MenuItem, Stack, Table, TableBody,
  TableCell, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Refresh as RefreshIcon, Replay as RetryIcon,
  ReportProblem as LostIcon, FactCheck as AckIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type {
  DeliveryAttemptRow, DeliveryAttemptsResponse,
} from '../services/api/feedOperations';
import ListPager, { clientPage } from './common/ListPager';

export interface DeliveryFeedRef { id: number; name: string; }

const STATUS_COLOR: Record<string, 'success' | 'error' | 'warning' | 'info' | 'default'> = {
  succeeded: 'success', failed: 'error', running: 'info',
  refused: 'warning', suppressed: 'default', skipped: 'default',
};

const ACK_COLOR: Record<string, 'success' | 'error' | 'warning' | 'default'> = {
  received: 'success', rejected: 'error', expected: 'warning',
  not_required: 'default',
};

type LoadState =
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; data: DeliveryAttemptsResponse };

type Action =
  | { kind: 'retry'; attempt: DeliveryAttemptRow }
  | { kind: 'mark-lost'; attempt: DeliveryAttemptRow }
  | { kind: 'ack'; attempt: DeliveryAttemptRow };

const fmtBytes = (n: number | null): string => {
  if (n == null) return '—';
  if (n >= 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  if (n >= 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${n} B`;
};

/** One action's inline form — reason rules depend on the action. */
const ActionPanel: React.FC<{
  action: Action;
  onDone: (message: string) => void;
  onCancel: () => void;
}> = ({ action, onDone, onCancel }) => {
  const [reason, setReason] = useState('');
  const [ackState, setAckState] = useState<'received' | 'rejected'>('received');
  const [detail, setDetail] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const a = action.attempt;
  const nonIdempotentRetry = action.kind === 'retry' && !a.idempotent;
  const reasonRequired = nonIdempotentRetry || action.kind === 'mark-lost';
  const blocked = reasonRequired && !reason.trim();

  const run = async () => {
    setBusy(true);
    setError(null);
    try {
      if (action.kind === 'retry') {
        const r = await api.retryDeliveryAttempt(
          a.id, reason.trim() || undefined);
        onDone(`Hop '${r.label}' re-sent as attempt ${r.attempt} — status `
          + `${r.status}${r.uri ? `, ${r.uri}` : ''}.`);
      } else if (action.kind === 'mark-lost') {
        await api.markDeliveryAttemptLost(a.id, reason.trim());
        onDone(`Attempt #${a.id} marked lost — a reasoned retry of this `
          + 'hop is now possible.');
      } else {
        const r = await api.recordDeliveryAcknowledgment(a.id, {
          state: ackState, ...(detail.trim() ? { detail: detail.trim() } : {}),
        });
        onDone(`Acknowledgment '${r.acknowledgment}' recorded for `
          + `${a.target} @ ${a.manifest_version}.`);
      }
    } catch (e: any) {
      setError(e?.message || String(e));
      setBusy(false);
    }
  };

  return (
    <Alert
      severity={action.kind === 'ack' ? 'info' : 'warning'}
      sx={{ mt: 1.5 }} data-testid={`delivery-action-${action.kind}`}
    >
      {action.kind === 'retry' && (
        <Typography variant="body2" sx={{ mb: 1 }}>
          Re-send hop <strong>{a.target}</strong> ({a.target_type}) — the SAME
          certified file (manifest {a.manifest_version}), one hop only, nothing
          regenerated.{' '}
          {a.idempotent
            ? 'This target is idempotent — a duplicate send overwrites the same file.'
            : <strong>This target is NOT idempotent: a duplicate send is a
                second regulatory submission.  A typed reason is required and
                there is no force option — if the last attempt is in doubt,
                verify out-of-band and mark it lost first.</strong>}
        </Typography>
      )}
      {action.kind === 'mark-lost' && (
        <Typography variant="body2" sx={{ mb: 1 }}>
          Record that attempt #{a.id} ({a.target}) <strong>never landed</strong>,
          verified out-of-band.  This is the only path that unlocks a manual
          retry of a non-idempotent hop — say what was verified and how.
        </Typography>
      )}
      {action.kind === 'ack' && (
        <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
          <TextField
            select size="small" label="Counterparty verdict" value={ackState}
            onChange={e =>
              setAckState(e.target.value as 'received' | 'rejected')}
            sx={{ minWidth: 160 }}
          >
            <MenuItem value="received">received</MenuItem>
            <MenuItem value="rejected">rejected</MenuItem>
          </TextField>
          <TextField
            size="small" label="Evidence / detail" value={detail} fullWidth
            placeholder="e.g. rejected by BNP ops, malformed header, ticket INC0041"
            onChange={e => setDetail(e.target.value)}
            inputProps={{ 'data-testid': 'delivery-ack-detail' }}
          />
        </Stack>
      )}
      {action.kind !== 'ack' && (
        <TextField
          label={reasonRequired ? 'Reason (required)' : 'Reason (optional, recorded)'}
          value={reason} onChange={e => setReason(e.target.value)}
          fullWidth multiline minRows={2} size="small" disabled={busy}
          error={blocked}
          placeholder={action.kind === 'mark-lost'
            ? "e.g. counterparty inbox listing 09:14 shows no file; confirmed by their ops desk"
            : "e.g. counterparty confirmed nothing landed; attempt 2 marked lost after out-of-band check"}
          inputProps={{ 'data-testid': 'delivery-action-reason' }}
          sx={{ mb: 1 }}
        />
      )}
      {error && (
        <Alert severity="error" sx={{ mb: 1 }}
               data-testid="delivery-action-refusal">
          {action.kind === 'retry'
            ? 'Refused — nothing was sent. ' : 'Refused. '}{error}
        </Alert>
      )}
      <Stack direction="row" spacing={1}>
        <Button size="small" onClick={onCancel} disabled={busy}>Cancel</Button>
        <Button
          size="small" variant="contained"
          color={action.kind === 'ack' ? 'primary' : 'warning'}
          disabled={busy || blocked}
          onClick={() => void run()}
          startIcon={busy ? <CircularProgress size={12} /> : undefined}
          data-testid="delivery-action-go"
        >
          {action.kind === 'retry' && 'Re-send this hop'}
          {action.kind === 'mark-lost' && 'Mark lost'}
          {action.kind === 'ack' && 'Record acknowledgment'}
        </Button>
      </Stack>
    </Alert>
  );
};

const FeedDeliveryAttemptsDialog: React.FC<{
  feed: DeliveryFeedRef | null;
  onClose: () => void;
}> = ({ feed, onClose }) => {
  const [load, setLoad] = useState<LoadState>({ phase: 'loading' });
  const [action, setAction] = useState<Action | null>(null);
  const [doneMsg, setDoneMsg] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const loadAttempts = async (feedId: number) => {
    setLoad({ phase: 'loading' });
    try {
      const data = await api.listFeedDeliveryAttempts(feedId);
      setLoad({ phase: 'ready', data });
    } catch (e: any) {
      setLoad({ phase: 'error', message: e?.message || String(e) });
    }
  };

  useEffect(() => {
    if (feed != null) {
      setAction(null);
      setDoneMsg(null);
      setPage(1);
      void loadAttempts(feed.id);
    }
  }, [feed?.id]);

  const attempts = load.phase === 'ready' ? load.data.attempts : [];
  const pg = clientPage(attempts, page, pageSize);

  return (
    <AppDialog open={feed != null}
      onClose={onClose}
      size="lg"
      title={<>Delivery attempts — {feed?.name}</>}
      actions={<>
        <Button onClick={onClose}>Close</Button>
      </>}>
        {load.phase === 'loading' && (
          <Stack alignItems="center" sx={{ py: 3 }}>
            <CircularProgress size={22} />
          </Stack>
        )}

        {load.phase === 'error' && (
          <Alert
            severity="error" data-testid="delivery-load-error"
            action={
              <Button color="inherit" size="small"
                      onClick={() => feed && void loadAttempts(feed.id)}>
                Retry
              </Button>
            }
          >
            Could not load delivery attempts — attempts may exist but cannot
            be shown. {load.message}
          </Alert>
        )}

        {load.phase === 'ready' && attempts.length === 0 && (
          <Alert severity="info" data-testid="delivery-empty">
            No delivery attempts recorded for this feed — nothing has been
            sent (or suppressed) through the delivery-hop ledger yet.
          </Alert>
        )}

        {doneMsg && (
          <Alert severity="success" sx={{ mb: 1.5 }}
                 onClose={() => setDoneMsg(null)}>
            {doneMsg}
          </Alert>
        )}

        {load.phase === 'ready' && attempts.length > 0 && (
          <>
            <Stack direction="row" sx={{ mb: 1 }} alignItems="center">
              <Typography variant="caption" color="text.secondary">
                {attempts.length} attempt(s), newest first.
              </Typography>
              <Box sx={{ flex: 1 }} />
              <Button size="small" startIcon={<RefreshIcon />}
                      onClick={() => feed && void loadAttempts(feed.id)}>
                Refresh
              </Button>
            </Stack>
            <Box sx={{ maxHeight: 340, overflow: 'auto' }}>
              <Table size="small" data-testid="delivery-attempts-table">
                <TableHead>
                  <TableRow>
                    <TableCell>Date</TableCell>
                    <TableCell>Hop</TableCell>
                    <TableCell>#</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Idempotent</TableCell>
                    <TableCell>Sent</TableCell>
                    <TableCell>Ack</TableCell>
                    <TableCell>Detail</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {pg.rows.map(a => (
                    <TableRow key={a.id} hover>
                      <TableCell>{a.business_date}</TableCell>
                      <TableCell>
                        <Typography variant="body2">{a.target}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {a.target_type}
                        </Typography>
                      </TableCell>
                      <TableCell>{a.attempt}</TableCell>
                      <TableCell>
                        <Chip size="small" label={a.status}
                              color={STATUS_COLOR[a.status] ?? 'default'}
                              sx={{ height: 20, fontSize: '0.68rem' }} />
                      </TableCell>
                      <TableCell>
                        {a.idempotent
                          ? <Typography variant="caption">yes</Typography>
                          : (
                            <Tooltip title="A duplicate send is a second regulatory submission — retrying requires a typed reason; there is no force option.">
                              <Chip size="small" label="NO" color="warning"
                                    variant="outlined"
                                    sx={{ height: 20, fontSize: '0.68rem' }} />
                            </Tooltip>
                          )}
                      </TableCell>
                      <TableCell>
                        <Typography variant="caption">
                          {fmtBytes(a.bytes_sent)}
                          {a.files_sent != null ? ` / ${a.files_sent} file(s)` : ''}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Chip size="small" label={a.acknowledgment}
                              color={ACK_COLOR[a.acknowledgment] ?? 'default'}
                              variant="outlined"
                              sx={{ height: 20, fontSize: '0.68rem' }} />
                      </TableCell>
                      <TableCell sx={{ maxWidth: 240 }}>
                        <Typography variant="caption"
                                    color={a.error_message ? 'error' : 'text.secondary'}
                                    sx={{ wordBreak: 'break-word' }}>
                          {a.error_message
                            || a.verification_detail
                            || a.destination_uri || ''}
                        </Typography>
                      </TableCell>
                      <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
                        <Tooltip title="Re-send this hop (same certified file)">
                          <Button size="small" startIcon={<RetryIcon />}
                                  onClick={() => { setDoneMsg(null); setAction({ kind: 'retry', attempt: a }); }}
                                  aria-label={`retry attempt ${a.id}`}>
                            Retry
                          </Button>
                        </Tooltip>
                        {a.status === 'running' && (
                          <Tooltip title="Human verified out-of-band that this in-doubt attempt never landed">
                            <Button size="small" color="warning"
                                    startIcon={<LostIcon />}
                                    onClick={() => { setDoneMsg(null); setAction({ kind: 'mark-lost', attempt: a }); }}
                                    aria-label={`mark attempt ${a.id} lost`}>
                              Mark lost
                            </Button>
                          </Tooltip>
                        )}
                        <Tooltip title="Record the counterparty's verdict on this delivery">
                          <Button size="small" startIcon={<AckIcon />}
                                  onClick={() => { setDoneMsg(null); setAction({ kind: 'ack', attempt: a }); }}
                                  aria-label={`acknowledge attempt ${a.id}`}>
                            Ack
                          </Button>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
            <ListPager paging={pg.paging} onPage={setPage} onPageSize={setPageSize} testid="delivery-attempts-pager" />
          </>
        )}

        {action && (
          <ActionPanel
            action={action}
            onCancel={() => setAction(null)}
            onDone={(msg) => {
              setAction(null);
              setDoneMsg(msg);
              if (feed) void loadAttempts(feed.id);
            }}
          />
        )}
    </AppDialog>
  );
};

export default FeedDeliveryAttemptsDialog;
