/**
 * Phase 138 — Visual EXPLAIN viewer.
 *
 * Renders DuckDB's EXPLAIN / EXPLAIN ANALYZE output as:
 *   1. A flat indented operator tree with per-node row estimates
 *   2. The raw plan text (collapsed by default) for power users
 *
 * Opens via a Dialog so it doesn't disrupt the editor layout.  Powered by
 * the new POST /api/execute/explain endpoint which runs DuckDB locally — no
 * S3 round-trip when only EXPLAIN (without ANALYZE) is requested.
 */
import React, { useState } from 'react';
import {
  Dialog,
  Button, IconButton, Box, Typography, Stack, Chip,
  CircularProgress, Alert, ToggleButton, ToggleButtonGroup,
  Tooltip,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import CloseIcon from '@mui/icons-material/Close';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import SpeedIcon from '@mui/icons-material/Speed';
import api from '../services/api';

interface OperatorNode {
  name: string;
  rows_estimate: number | null;
  indent: number;
}

const engineName = (e: string) => e.charAt(0).toUpperCase() + e.slice(1);

interface ExplainResponse {
  available: boolean;
  reason?: string;
  plan_text?: string;
  operators?: OperatorNode[];
  analyzed?: boolean;
  /** Set when the plan came from a SQL connection's own engine. */
  engine?: string;
}

export interface ExplainViewerProps {
  open: boolean;
  onClose: () => void;
  /** SQL to explain — usually the contents of the SQL editor */
  sql?: string | null;
  /** Optional structured query config (EXPLAIN endpoint accepts either) */
  queryConfig?: any;
  connectionId?: number | null;
  /**
   * 2026-10-07 (F8 cross-source): a cross-source run is TWO statements on
   * TWO connections.  Each side is explained on its own connection; the
   * dialog offers the choice.  Absent = the single `sql` / `connectionId`.
   */
  sides?: ExplainSide[] | null;
}

export interface ExplainSide {
  key: string;
  label: string;
  sql: string;
  connectionId: number | null;
}

const fmtRows = (n: number | null): string => {
  if (n == null) return '—';
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`;
  return n.toLocaleString();
};

const ExplainViewer: React.FC<ExplainViewerProps> = ({
  open, onClose, sql: sqlProp, queryConfig, connectionId: connProp, sides,
}) => {
  const [sideKey, setSideKey] = useState<string | null>(null);
  const side = sides && sides.length
    ? (sides.find(x => x.key === sideKey) || sides[0]) : null;
  const sql = side ? side.sql : sqlProp;
  const connectionId = side ? side.connectionId : connProp;
  const [data, setData] = useState<ExplainResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<'plan' | 'analyze'>('plan');
  const [showRaw, setShowRaw] = useState(false);

  const runExplain = async (analyzeMode: boolean, over?: ExplainSide | null) => {
    const _sql = over ? over.sql : sql;
    const _conn = over ? over.connectionId : connectionId;
    setLoading(true);
    setError(null);
    setData(null);
    try {
      const res = await api.explainQuery({
        raw_sql: _sql || undefined,
        query_config: !_sql ? queryConfig : undefined,
        connection_id: _conn || undefined,
        analyze: analyzeMode,
      });
      setData(res);
      if (!res?.available) {
        setError(res?.reason || 'Plan unavailable');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to fetch plan');
    } finally {
      setLoading(false);
    }
  };

  // Auto-fetch on open
  React.useEffect(() => {
    if (open && (sql || queryConfig)) {
      runExplain(mode === 'analyze');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const handleSideChange = (_e: any, key: string | null) => {
    if (!key || !sides) return;
    const next = sides.find(x => x.key === key) || null;
    setSideKey(key);
    runExplain(mode === 'analyze', next);
  };

  const handleModeChange = (_e: any, newMode: 'plan' | 'analyze' | null) => {
    if (!newMode || newMode === mode) return;
    setMode(newMode);
    runExplain(newMode === 'analyze');
  };

  const operators = data?.operators || [];

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="md"
      title={<>
        <Stack direction="row" alignItems="center" spacing={1}>
          <AccountTreeIcon color="primary" />
          <Typography variant="h6" sx={{ flexGrow: 1 }}>Query plan</Typography>
          {sides && sides.length > 1 && (
            <ToggleButtonGroup
              size="small" value={side?.key ?? null} exclusive onChange={handleSideChange}
              aria-label="Statement to explain"
              sx={{ '& .MuiToggleButton-root': { px: 1.5, py: 0.25, fontSize: '0.75rem', textTransform: 'none' } }}
            >
              {sides.map(x => (
                <ToggleButton key={x.key} value={x.key} aria-label={`Explain ${x.label}`}>{x.label}</ToggleButton>
              ))}
            </ToggleButtonGroup>
          )}
          <ToggleButtonGroup
            size="small" value={mode} exclusive onChange={handleModeChange}
            sx={{ '& .MuiToggleButton-root': { px: 1.5, py: 0.25, fontSize: '0.75rem' } }}
          >
            <ToggleButton value="plan">EXPLAIN</ToggleButton>
            <Tooltip title="Runs the query to gather actual row counts (slower)">
              <ToggleButton value="analyze">
                <SpeedIcon fontSize="small" sx={{ mr: 0.5 }} />
                ANALYZE
              </ToggleButton>
            </Tooltip>
          </ToggleButtonGroup>
          <IconButton aria-label="Close explain plan" size="small" onClick={onClose}>
            <CloseIcon fontSize="small" />
          </IconButton>
        </Stack>
      </>}
      contentSx={{ minHeight: 320 }}
      actions={<>
        <Button onClick={onClose}>Close</Button>
      </>}>
        {loading && (
          <Stack alignItems="center" spacing={1} sx={{ py: 4 }}>
            <CircularProgress size={28} />
            <Typography variant="caption" color="text.secondary">
              {mode === 'analyze' ? 'Running query for ANALYZE…' : 'Building plan…'}
            </Typography>
          </Stack>
        )}

        {!loading && error && (
          <Alert severity="warning" sx={{ mb: 2 }}>
            <Typography variant="body2">{error}</Typography>
          </Alert>
        )}

        {!loading && data?.available && operators.length > 0 && (
          <Box sx={{ mb: 2 }}>
            <Typography variant="caption" color="text.secondary" sx={{ mb: 1, display: 'block' }}>
              Operator tree · {operators.length} node{operators.length === 1 ? '' : 's'}
              {data.analyzed ? ' · ANALYZE (real measurements)' : ' · estimates only'}
            </Typography>
            <Stack spacing={0.5}>
              {operators.map((op, i) => (
                <Box
                  key={i}
                  sx={{
                    display: 'flex', alignItems: 'center', gap: 1,
                    pl: op.indent * 2,
                    py: 0.5, px: 1,
                    borderRadius: 1,
                    bgcolor: i % 2 === 0 ? 'action.hover' : 'transparent',
                    fontFamily: 'monospace',
                  }}
                >
                  <Typography variant="body2" sx={{ flexGrow: 1, fontWeight: 600, fontSize: '0.78rem' }}>
                    {'  '.repeat(op.indent)}↳ {op.name}
                  </Typography>
                  {op.rows_estimate != null && (
                    <Chip
                      label={`${fmtRows(op.rows_estimate)} rows`}
                      size="small"
                      sx={{
                        height: 18, fontSize: '0.65rem',
                        bgcolor: op.rows_estimate > 1_000_000 ? 'warning.lighter' : undefined,
                      }}
                    />
                  )}
                </Box>
              ))}
            </Stack>
          </Box>
        )}

        {!loading && data?.available && operators.length === 0 && data.plan_text && (
          <Alert severity="info" sx={{ mb: 2 }}>
            {data.engine
              // 2026-10-03 -- a SQL connection's plan comes from ITS engine
              // (Snowflake, Trino...) in that engine's own words; the tree
              // view reads only DuckDB's layout, so the text IS the plan.
              ? `The ${engineName(data.engine)} plan, as ${engineName(data.engine)} reports it:`
              : "Couldn't extract a structured tree from this plan — see raw output below."}
          </Alert>
        )}

        {!loading && data?.plan_text && (
          <Box>
            {!data.engine && <Button
              size="small" variant="text"
              onClick={() => setShowRaw(s => !s)}
              sx={{ textTransform: 'none', fontSize: '0.75rem', mb: 0.5 }}
            >
              {showRaw ? 'Hide raw plan' : 'Show raw plan'}
            </Button>}
            {(showRaw || !!data.engine) && (
              <Box
                component="pre"
                sx={{
                  fontFamily: 'monospace', fontSize: '0.7rem',
                  bgcolor: 'grey.100', p: 1, borderRadius: 1,
                  overflow: 'auto', maxHeight: 320,
                  m: 0, whiteSpace: 'pre-wrap',
                }}
              >
                {data.plan_text}
              </Box>
            )}
          </Box>
        )}
    </AppDialog>
  );
};

export default ExplainViewer;
