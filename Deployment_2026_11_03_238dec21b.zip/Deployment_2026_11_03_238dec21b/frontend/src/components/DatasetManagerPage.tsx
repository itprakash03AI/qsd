/**
 * Dataset Manager — Semantic Layer (Phase 53; self-service 2026-08-09)
 *
 * Self-service page for defining Business Datasets (BO Universe
 * equivalent).  Any analyst can model datasets over connections they are
 * entitled to; a dataset stays PRIVATE to its owner (and owner group)
 * until an admin publishes it org-wide.  Publishing, certification, and
 * semantic-layer config remain admin-only — the backend enforces all of
 * this; the UI mirrors it so users aren't offered actions that will 403.
 * Manages: datasets, classes, columns, relationships, drill hierarchies,
 * pre-defined conditions, and aggregation awareness rules.
 *
 * Route: /datasets
 */
import { appConfirm } from './common/appDialogs';
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Paper, Button, CircularProgress, IconButton, Skeleton,
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow,
  TextField, Dialog,
  Chip, Alert, Divider, Tooltip, Stack, Switch, FormControlLabel,
  Select, MenuItem, FormControl, InputLabel, Tabs, Tab,
  Accordion, AccordionSummary, AccordionDetails,
  List, ListItem, ListItemText, ListItemSecondaryAction,
  LinearProgress, Checkbox, ListItemIcon,
  Stepper, Step, StepLabel, Autocomplete,
  TablePagination, InputAdornment,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Refresh as RefreshIcon,
  Publish as PublishIcon,
  AutoFixHigh as AutoDetectIcon,
  ExpandMore as ExpandMoreIcon,
  Settings as SettingsIcon,
  Save as SaveIcon,
  Schema as SchemaIcon,
  Category as ClassIcon,
  ViewColumn as ColumnIcon,
  Link as RelIcon,
  AccountTree as HierarchyIcon,
  FilterAlt as ConditionIcon,
  Speed as AggIcon,
  PlayArrow as QueryIcon,
  Cached as CachedIcon,
  Build as BuildNowIcon,
  Storage as SourceIcon,
  Search as BrowseIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  RemoveCircleOutline as RemoveRowIcon,
  Assessment as ReportIcon,
} from '@mui/icons-material';
import { alpha } from '@mui/material/styles';
import api from '../services/api';
import { useNotifications } from '../context/NotificationContext';
import { useAuth } from '../context/AuthContext';
import { useLocation, useNavigate } from 'react-router-dom';
import { ReturnTrip, returnTripFrom, returnState } from '../utils/returnTo';
import { datasetQueryPath } from '../utils/datasetUrls';
import { newReportForDatasetPath } from '../utils/reportUrls';
import { canAuthorReports } from '../utils/reportLifecycle';
import DatasetCreationWizard, { type WizardInitialSource } from './DatasetCreationWizard';
import PartitionConfigEditor, { type ColumnChoices } from './common/PartitionConfigEditor';
import PartitionScanVerdict, { type VerdictState } from './common/PartitionScanVerdict';
import type { PartitionConfig } from '../types/api';
import { clickableRow } from '../utils/clickable';

/* ── Notification helper ───────────────────────────────────────────────── */
const notify = (addNotification: Function, msg: string, type: 'success' | 'error' | 'info' = 'info') =>
  addNotification({ type, title: type === 'error' ? 'Error' : type === 'success' ? 'Success' : 'Info', message: msg });

/* ── Constants ─────────────────────────────────────────────────────────── */
const COLUMN_TYPES = ['dimension', 'measure', 'detail', 'kpi'] as const;
const DATA_TYPES   = ['string', 'number', 'date', 'boolean'] as const;
const JOIN_TYPES   = ['inner', 'left', 'right', 'full'] as const;
const CARDINALITIES = ['one_to_one', 'one_to_many', 'many_to_one', 'many_to_many'] as const;
const AGGREGATIONS = ['', 'sum', 'avg', 'count', 'min', 'max', 'count_distinct'] as const;
const GRAIN_LABELS = ['daily', 'weekly', 'monthly', 'quarterly', 'yearly', 'custom'] as const;
const SCHEDULE_TYPES = ['none', 'cron', 'interval'] as const;

/* ── Types ─────────────────────────────────────────────────────────────── */
interface Dataset {
  id: number; name: string; description: string; subject: string;
  owner: string; owner_group_id?: number | null;
  connection_ids: number[]; source_tables: any[];
  base_query: string; is_published: boolean;
  // 2026-09-05 — the DATASET-LEVEL progressive-scan declaration.
  // Absent/null means NOT DECLARED; `{}` is how the server stores a
  // withdrawn one, and every reader treats both the same way.
  partition_config?: PartitionConfig | null;
  is_certified?: boolean; certified_by?: string | null;
  created_at: string; updated_at: string;
  classes?: any[]; columns?: any[]; relationships?: any[];
  hierarchies?: any[]; conditions?: any[]; agg_awareness?: any[];
}

/* ── Component ─────────────────────────────────────────────────────────── */
export default function DatasetManagerPage() {
  const { addNotification } = useNotifications();
  const { user } = useAuth();
  const navigate = useNavigate();
  // Self-service (2026-08-09): the backend authorizes per-dataset; these
  // flags only keep the UI honest about what will succeed.
  const isAdmin = !!(user?.is_admin || user?.role === 'admin' || user?.role === 'super_admin');
  const username = user?.username || '';
  const ownsDataset = (ds: Dataset) =>
    !!username && (ds.owner || '').toLowerCase() === username.toLowerCase();
  const canMutate = (ds: Dataset) => isAdmin || ownsDataset(ds);
  // 2026-10-23 -- the owner: "once create data set not option to create
  // report...process flow is breaking".  A dataset leads to a report.
  const canReport = canAuthorReports(user);
  const [createdNext, setCreatedNext] = useState<{ dataset: any; trip: ReturnTrip | null } | null>(null);
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [detail, setDetail] = useState<Dataset | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailTab, setDetailTab] = useState(0);
  const [createOpen, setCreateOpen] = useState(false);
  const [wizardOpen, setWizardOpen] = useState(false);
  // Seed for the creation wizard when navigated from the Query Builder's
  // "Create Dataset…" action — the user has already picked their source
  // there and must never re-pick it here.
  const [wizardInitialSource, setWizardInitialSource] = useState<WizardInitialSource | null>(null);
  // Where the hand-off came from: a CANCEL goes back there (utils/returnTo.ts);
  // a dataset actually created stays here and opens it.
  const returnTripRef = React.useRef<ReturnTrip | null>(null);
  const wizardCreatedRef = React.useRef(false);

  // ── Deep-link support (mirrors FeedConfigsPage's contract):
  //     /datasets?source_type=saved_query&source_id=42&name=my-query
  //     /datasets?source_type=sql_file&source_id=7
  // Consumes the params ONCE, opens the wizard pre-seeded, then strips the
  // query string so refresh / back-button doesn't re-trigger.
  const location = useLocation();
  const [configOpen, setConfigOpen] = useState(false);
  const [config, setConfig] = useState<Record<string, any>>({});

  // ── Connections list (shared across create + source tab) ────────────
  const [connections, setConnections] = useState<any[]>([]);
  const [connectionsLoaded, setConnectionsLoaded] = useState(false);

  // ── Create form state ───────────────────────────────────────────────
  const [formName, setFormName] = useState('');
  const [formSubject, setFormSubject] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formConnectionId, setFormConnectionId] = useState<number | ''>('');
  const [formSourceTable, setFormSourceTable] = useState('');
  // 2026-09-01 -- the connection's REGISTERED TABLES, offered as options.
  // This was a bare text box: QueryStudio already knows which tables a
  // connection has, and asking the author to retype one by hand invites
  // exactly the typo that later reads as "source returned no columns".
  const [sourceTableOptions, setSourceTableOptions] = useState<string[]>([]);
  const [formBaseQuery, setFormBaseQuery] = useState('');
  const [createStep, setCreateStep] = useState(0);
  const [previewCols, setPreviewCols] = useState<any[]>([]);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState('');

  // ── Auto-detect preview dialog (for existing datasets) ────────────
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [previewDialogCols, setPreviewDialogCols] = useState<any[]>([]);
  const [previewDialogLoading, setPreviewDialogLoading] = useState(false);

  // ── Source tab state ──────────────────────────────────────────────
  const [sourceTables, setSourceTables] = useState<any[]>([]);
  const [sourceBaseQuery, setSourceBaseQuery] = useState('');
  // 2026-09-05 — the DATASET-LEVEL scan declaration
  // (`business_datasets.partition_config`).  A SQL-mode dataset has a
  // base_query and NO source tables, so the per-entry editor below has
  // nothing to attach to and such a dataset could not declare a
  // partition column at all — which is the case progressive loading
  // exists for.
  const [datasetPartitionConfig, setDatasetPartitionConfig] =
    useState<PartitionConfig | null>(null);
  const [sourceSaving, setSourceSaving] = useState(false);
  // The server's own refusal text, held where the user can read it.  A 422
  // from _validate_partition_configs NAMES the offending key ("'max_bucket'
  // is not a partition_config setting") and a toast that has faded is not a
  // place to read a key name from.
  const [sourceError, setSourceError] = useState<string | null>(null);
  // Has anything ASKED for the source's columns yet?  Without this the
  // untouched initial state ([] and no message) renders as "the source has
  // no columns" -- unknown wearing the clothes of empty.
  const [sourceColsAsked, setSourceColsAsked] = useState(false);
  // Progressive partition loading: what the reports on this dataset would
  // actually do, and what the last run's plan decided.  Both are fetched
  // only when the section is opened -- the columns read can reach the source.
  const [reachState, setReachState] =
    useState<{ state: 'idle' | 'loading' | 'ready' | 'failed';
               reports: any[]; message: string }>(
      { state: 'idle', reports: [], message: '' });
  const [verdict, setVerdict] = useState<VerdictState>({ state: 'loading' });
  const [browseConnId, setBrowseConnId] = useState<number | null>(null);
  const [browseFiles, setBrowseFiles] = useState<any[]>([]);
  const [browseLoading, setBrowseLoading] = useState(false);
  const [browseOpen, setBrowseOpen] = useState(false);
  const [browseTarget, setBrowseTarget] = useState<'create' | 'source'>('source');
  const [browseTargetIndex, setBrowseTargetIndex] = useState(-1);

  // ── Column edit dialog ──────────────────────────────────────────────
  const [colDialogOpen, setColDialogOpen] = useState(false);
  // 2026-09-04 -- the source's own columns, so "Physical Name" is a
  // choice rather than free text.  A typed name that does not exist in
  // the source is accepted, stored, and fails later as "column not
  // found"; on Starburst, where quoted identifiers are case-sensitive
  // and unquoted ones are folded, a plausible-looking typo is the normal
  // outcome.  GET /api/datasets/{id}/source-columns answers for ANY
  // source through the same resolution auto-detect uses, and writes
  // nothing.
  const [sourceCols, setSourceCols] = useState<any[]>([]);
  const [sourceColsMsg, setSourceColsMsg] = useState('');
  const [sourceColsLoading, setSourceColsLoading] = useState(false);
  const [editingCol, setEditingCol] = useState<any>(null);

  // ── Agg Cache state ───────────────────────────────────────────────
  const [aggCacheEntries, setAggCacheEntries] = useState<any[]>([]);
  const [aggCacheLoading, setAggCacheLoading] = useState(false);

  // ── Agg Cache Create/Edit dialog ─────────────────────────────────
  const [cacheDialogOpen, setCacheDialogOpen] = useState(false);
  const [cacheEditId, setCacheEditId] = useState<number | null>(null);
  const [cacheName, setCacheName] = useState('');
  const [cacheDesc, setCacheDesc] = useState('');
  const [cacheDimIds, setCacheDimIds] = useState<number[]>([]);
  const [cacheMeasureIds, setCacheMeasureIds] = useState<number[]>([]);
  const [cacheGrain, setCacheGrain] = useState<string>('daily');
  const [cacheConditionIds, setCacheConditionIds] = useState<number[]>([]);
  const [cacheScheduleType, setCacheScheduleType] = useState<string>('none');
  const [cacheCron, setCacheCron] = useState('0 2 * * *');
  const [cacheIntervalHours, setCacheIntervalHours] = useState(6);
  const [cacheIncremental, setCacheIncremental] = useState(false);
  const [cacheIncrementalCol, setCacheIncrementalCol] = useState('');
  const [cacheSaving, setCacheSaving] = useState(false);

  /* ── Data fetching ──────────────────────────────────────────────────── */
  // FB-49 (2026-09-20) -- this list had no search and no pager: 15 rows
  // today, and every row of every dataset anyone ever made tomorrow.
  // Paging is CLIENT-side here, unlike /executions, and deliberately: GET
  // /api/datasets returns the caller's COMPLETE visible list in one read
  // (the visibility predicate is already in the SQL), so slicing a loaded
  // array is the truth.  /executions could not do this -- its list is
  // capped server-side, so a client slice there would have been a pager
  // over a lie.
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(25);

  const loadDatasets = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.listDatasets();
      setDatasets(Array.isArray(data) ? data : []);
    } catch (e: any) {
      notify(addNotification, 'Failed to load datasets: ' + e.message, 'error');
    } finally { setLoading(false); }
  }, [addNotification]);

  /** FB-49 -- the rows that match the search box, over the COMPLETE list. */
  const filteredDatasets = React.useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return datasets;
    return datasets.filter((ds: any) => (
      String(ds.name || '').toLowerCase().includes(term)
      || String(ds.description || '').toLowerCase().includes(term)
      || String(ds.subject || '').toLowerCase().includes(term)
      || String(ds.owner || '').toLowerCase().includes(term)
    ));
  }, [datasets, search]);

  const pagedDatasets = React.useMemo(
    () => filteredDatasets.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage),
    [filteredDatasets, page, rowsPerPage]);

  // a narrowed list has fewer pages; staying on page 4 of 1 shows nothing
  useEffect(() => { setPage(0); }, [search, rowsPerPage]);

  const loadDetail = useCallback(async (id: number) => {
    setDetailLoading(true);
    try {
      const data = await api.getDataset(id);
      setDetail(data);
      setSelectedId(id);
    } catch (e: any) {
      notify(addNotification, 'Failed to load dataset: ' + e.message, 'error');
    } finally { setDetailLoading(false); }
  }, [addNotification]);

  // Deep links are handled HERE, after loadDetail exists — the
  // ?dataset= branch calls it.
  const _deepLinkAppliedRef = React.useRef(false);
  useEffect(() => {
    if (_deepLinkAppliedRef.current) return;
    const params = new URLSearchParams(location.search);
    // ?dataset=<id> — open an EXISTING dataset straight into its detail
    // view.  Added 2026-09-03: a report author looking at a broken or
    // column-less dataset had no way to reach it from the report, and
    // "view the query" / "fix the dataset" is exactly what they need to
    // do next.  Handled before the wizard deep-link below because the
    // two are different intents: this opens something that exists.
    const dsParam = params.get('dataset');
    if (dsParam) {
      const dsId = Number(dsParam);
      if (Number.isFinite(dsId) && dsId > 0) {
        _deepLinkAppliedRef.current = true;
        const tab = params.get('tab');
        // tab 0 is Source, which carries the base_query — the thing a
        // report author following this link came to look at.
        setDetailTab(tab === null ? 0 : Number(tab) || 0);
        loadDetail(dsId);
        navigate(location.pathname, { replace: true });
        return;
      }
    }
    const stype = params.get('source_type');
    const sid = params.get('source_id');
    const suggestedName = params.get('name');
    if (!stype || !sid) return;
    if (!['saved_query', 'sql_file'].includes(stype)) return;
    const sidNum = Number(sid);
    if (!Number.isFinite(sidNum) || sidNum <= 0) return;
    _deepLinkAppliedRef.current = true;
    returnTripRef.current = returnTripFrom(params);
    wizardCreatedRef.current = false;
    setWizardInitialSource({
      sourceType: stype as 'saved_query' | 'sql_file',
      sourceId: sidNum,
      name: suggestedName || undefined,
    });
    setWizardOpen(true);
    navigate(location.pathname, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search, loadDetail]);

  const loadConnections = useCallback(async () => {
    if (connectionsLoaded) return;
    try {
      const data = await api.listConnections(true);
      setConnections(Array.isArray(data) ? data : []);
      setConnectionsLoaded(true);
    } catch { /* ignore */ }
  }, [connectionsLoaded]);

  useEffect(() => { loadDatasets(); }, [loadDatasets]);

  // Load connections on first need (create dialog or source tab)
  useEffect(() => {
    if (createOpen || (detailTab === 0 && detail)) loadConnections();
  }, [createOpen, detailTab, detail, loadConnections]);

  // Sync source tab state when detail loads or source tab selected
  useEffect(() => {
    if (detailTab === 0 && detail) {
      setSourceTables(detail.source_tables || []);
      setSourceBaseQuery(detail.base_query || '');
      setDatasetPartitionConfig(
        (detail.partition_config as PartitionConfig) || null);
      setSourceError(null);
    }
  }, [detailTab, detail]);

  // Load agg cache entries when the Agg Cache tab is selected
  useEffect(() => {
    if (detailTab === 7 && detail?.id) {
      setAggCacheLoading(true);
      api.listAggCacheEntries(detail.id)
        .then((resp: any) => setAggCacheEntries(resp.entries || []))
        .catch(() => {})
        .finally(() => setAggCacheLoading(false));
    }
  }, [detailTab, detail?.id]);

  /* ── Agg Cache Dialog helpers ────────────────────────────────────────── */
  const openCacheCreateDialog = () => {
    setCacheEditId(null);
    setCacheName('');
    setCacheDesc('');
    setCacheDimIds([]);
    setCacheMeasureIds([]);
    setCacheGrain('daily');
    setCacheConditionIds([]);
    setCacheScheduleType('none');
    setCacheCron('0 2 * * *');
    setCacheIntervalHours(6);
    setCacheIncremental(false);
    setCacheIncrementalCol('');
    setCacheDialogOpen(true);
  };

  const openCacheEditDialog = (entry: any) => {
    setCacheEditId(entry.id);
    setCacheName(entry.name || '');
    setCacheDesc(entry.description || '');
    setCacheDimIds(entry.dimension_col_ids || []);
    setCacheMeasureIds(entry.measure_col_ids || []);
    setCacheGrain(entry.grain_label || 'custom');
    setCacheConditionIds(entry.condition_ids || []);
    const sched = entry.schedule_config;
    if (sched?.type === 'cron') {
      setCacheScheduleType('cron');
      setCacheCron(sched.cron_expr || '0 2 * * *');
    } else if (sched?.type === 'interval') {
      setCacheScheduleType('interval');
      setCacheIntervalHours(sched.hours || 6);
    } else {
      setCacheScheduleType('none');
    }
    setCacheIncremental(entry.incremental_enabled || false);
    setCacheIncrementalCol(entry.incremental_column || '');
    setCacheDialogOpen(true);
  };

  const handleCacheSave = async () => {
    if (!detail?.id || !cacheName.trim() || cacheDimIds.length === 0 || cacheMeasureIds.length === 0) return;
    setCacheSaving(true);
    try {
      const scheduleConfig = cacheScheduleType === 'cron'
        ? { type: 'cron', cron_expr: cacheCron }
        : cacheScheduleType === 'interval'
          ? { type: 'interval', hours: cacheIntervalHours }
          : null;
      const payload: any = {
        name: cacheName.trim(),
        description: cacheDesc.trim(),
        dimension_col_ids: cacheDimIds,
        measure_col_ids: cacheMeasureIds,
        grain_label: cacheGrain,
        condition_ids: cacheConditionIds,
        schedule_config: scheduleConfig,
        incremental_enabled: cacheIncremental,
        incremental_column: cacheIncremental ? cacheIncrementalCol : null,
        is_enabled: true,
      };
      if (cacheEditId) {
        await api.updateAggCacheEntry(cacheEditId, payload);
        notify(addNotification, `Cache entry "${cacheName}" updated`, 'success');
      } else {
        await api.createAggCacheEntry(detail.id, payload);
        notify(addNotification, `Cache entry "${cacheName}" created`, 'success');
      }
      setCacheDialogOpen(false);
      // Refresh list
      const resp = await api.listAggCacheEntries(detail.id);
      setAggCacheEntries(resp.entries || []);
    } catch (e: any) {
      notify(addNotification, `Save failed: ${e.message}`, 'error');
    } finally { setCacheSaving(false); }
  };

  // Helpers: dimension & measure columns from current dataset
  const dimensionCols = (detail?.columns || []).filter((c: any) => c.column_type === 'dimension');
  const measureCols = (detail?.columns || []).filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi');
  const dateCols = (detail?.columns || []).filter((c: any) => c.data_type === 'date');
  const conditionsList = detail?.conditions || [];

  /* ── Source helpers ──────────────────────────────────────────────────── */
  const browseForTable = async (connId: number, target: 'create' | 'source', idx = -1) => {
    setBrowseConnId(connId);
    setBrowseTarget(target);
    setBrowseTargetIndex(idx);
    setBrowseLoading(true);
    setBrowseOpen(true);
    try {
      const files = await api.listConnectionFiles(String(connId));
      setBrowseFiles(Array.isArray(files) ? files : []);
    } catch { setBrowseFiles([]); }
    finally { setBrowseLoading(false); }
  };

  const selectBrowseFile = (filePath: string) => {
    if (browseTarget === 'create') {
      setFormSourceTable(filePath);
    } else {
      // Update source table at index
      if (browseTargetIndex >= 0) {
        setSourceTables(prev => prev.map((st, i) =>
          i === browseTargetIndex ? { ...st, table: filePath } : st
        ));
      }
    }
    setBrowseOpen(false);
  };

  const addSourceTable = () => {
    setSourceTables(prev => [...prev, { connection_id: '', table: '', alias: '' }]);
  };

  const removeSourceTable = (idx: number) => {
    setSourceTables(prev => prev.filter((_, i) => i !== idx));
  };

  const updateSourceTable = (idx: number, field: string, value: any) => {
    setSourceTables(prev => prev.map((st, i) =>
      i === idx ? { ...st, [field]: value } : st
    ));
  };

  // partition_config is DELETED when it empties, never stored as null: both
  // readers (dataset_partition_config, _carry_scan_config) treat an ABSENT
  // key as "no declaration", and a stored null would be a third shape they
  // would each have to know about.
  const setPartitionConfig = (idx: number, next: PartitionConfig | null) => {
    setSourceTables(prev => prev.map((st, i) => {
      if (i !== idx) return st;
      const copy: any = { ...st };
      if (next) copy.partition_config = next;
      else delete copy.partition_config;
      return copy;
    }));
  };

  // What the SERVER currently holds -- deliberately read off `detail`, not
  // off the edited `sourceTables`.  A column typed but not yet saved is not
  // a declaration, and asking "why did my declared column run whole?" about
  // a declaration the server has never seen is a question with no answer.
  const savedPartitionConfig: PartitionConfig | null = React.useMemo(() => {
    // The dataset-level declaration first, because it is the only home a
    // SQL-mode dataset has: reading only source_tables would render every
    // such dataset as "declares no partition config" while the server was
    // holding one — a UI stating the opposite of the stored fact.
    const dsLevel: any = detail?.partition_config;
    if (dsLevel && typeof dsLevel === 'object'
        && String(dsLevel.column || '').trim()) {
      return dsLevel as PartitionConfig;
    }
    for (const st of ((detail?.source_tables || []) as any[])) {
      const pc = st && st.partition_config;
      if (pc && typeof pc === 'object' && String(pc.column || '').trim()) {
        return pc as PartitionConfig;
      }
    }
    return null;
  }, [detail]);

  // The choices the partition picker offers, and -- when there are none --
  // WHICH kind of none.  `sourceColsAsked` is what keeps a never-fetched
  // state from rendering as "this source has no columns".
  const partitionColumnChoices: ColumnChoices =
    (!sourceColsAsked || sourceColsLoading)
      ? { state: 'loading' }
      : sourceColsMsg
        ? { state: 'unavailable', message: sourceColsMsg }
        : { state: 'ready',
            columns: sourceCols
              .map((c: any) => String(c?.physical_name || ''))
              .filter(Boolean) };

  // Which reports actually run on this dataset, so the reach note can quote
  // their stored row limits instead of implying an effect nobody will get.
  const loadReach = useCallback(() => {
    if (!selectedId) return;
    setReachState({ state: 'loading', reports: [], message: '' });
    api.listBusinessReports({ dataset_id: selectedId })
      .then((res: any) => {
        const items = Array.isArray(res) ? res : (res?.items || []);
        setReachState({ state: 'ready', reports: items, message: '' });
      })
      .catch((e: any) => setReachState({
        state: 'failed', reports: [],
        message: e?.message || 'the request failed',
      }));
  }, [selectedId]);

  // The plan's OWN verdict for the most recent execution.  Every branch
  // here ends in a different statement, because "no execution yet", "your
  // role cannot read it", "that run never reached the planner" and "the
  // planner refused, here is why" are four different things to do next.
  const loadVerdict = useCallback(async () => {
    if (!selectedId) return;
    setVerdict({ state: 'loading' });
    try {
      const execs: any = await api.listDatasetExecutions(selectedId, 1);
      const rows = Array.isArray(execs) ? execs : (execs?.executions || []);
      const eid = rows[0]?.execution_id;
      if (!eid) {
        setVerdict({ state: 'unavailable',
          reason: 'This dataset has no recorded executions yet, so no plan '
                + 'has been stamped. Run a report on it and come back.' });
        return;
      }
      // 2026-09-05 — the EXECUTION'S OWN RECORD, which any principal the
      // execution belongs to may read (`_check_execution_access`: the
      // executor, an editor of the parent dataset, or an admin).  Until
      // this the only reader was the admin diagnose route, so the author
      // who declared the column and got a whole-query run was told the
      // reason existed and was unreadable.  The admin route stays below
      // as the fallback it already was.
      let recordReason = '';
      try {
        const rec: any = await api.getFederationExecutionDetail(eid);
        if (rec?.scan_plan) {
          setVerdict({ state: 'verdict', plan: rec.scan_plan,
                       completeness: rec.scan_completeness || null });
          return;
        }
      } catch (recErr: any) {
        // NOT a verdict: it says why there is nothing to read.
        recordReason = recErr?.message || 'the request failed';
      }
      if (!isAdmin) {
        setVerdict({ state: 'unavailable',
          reason: recordReason
            ? `The record for execution ${eid} could not be read, so `
              + `whether it split or ran whole is unknown. The server `
              + `said: ${recordReason}`
            : `Execution ${eid} recorded no progressive-scan plan. That `
              + 'is not a refusal: only the pure SQL-connector route reads '
              + 'the declaration, so a cached run, an S3/DuckDB run or a '
              + 'hybrid run never reaches the planner at all.' });
        return;
      }
      const diag: any = await api.getQueryDiagnostic(eid);
      const summary = diag?.pruning?.summary || {};
      if (!summary.scan_plan) {
        setVerdict({ state: 'unavailable',
          reason: `Execution ${eid} recorded no progressive-scan plan. That `
                + 'is not a refusal: only the pure SQL-connector route reads '
                + 'the declaration, so a cached run, an S3/DuckDB run or a '
                + 'hybrid run never reaches the planner at all.' });
        return;
      }
      setVerdict({ state: 'verdict', plan: summary.scan_plan,
                   completeness: summary.scan_completeness || null });
    } catch (e: any) {
      setVerdict({ state: 'unavailable',
        reason: `The server answered: ${e?.message || 'the request failed'}` });
    }
  }, [selectedId, isAdmin]);

  // The verdict panel is on screen the moment the Source tab is, so it has
  // to be READING the moment it is on screen: an initial "loading" that
  // nothing resolves is a spinner claiming a read that never started.  Only
  // for a dataset that actually declares something -- for the rest the panel
  // renders the undeclared statement and asks the server nothing.
  //
  // Declared HERE rather than beside the other Source-tab effects, because
  // both of its dependencies are consts defined above this line and below
  // those: a dependency ARRAY is evaluated during render, so naming them
  // earlier is a temporal-dead-zone ReferenceError, not a hoist.
  useEffect(() => {
    if (detailTab === 0 && savedPartitionConfig) loadVerdict();
  }, [detailTab, savedPartitionConfig, loadVerdict]);

  const saveSourceConfig = async () => {
    if (!detail?.id) return;
    setSourceSaving(true);
    setSourceError(null);
    try {
      const connIds = [...new Set(sourceTables.filter(st => st.connection_id).map(st => Number(st.connection_id)))];
      await api.updateDataset(detail.id, {
        connection_ids: connIds,
        source_tables: sourceTables.filter(st => st.connection_id && st.table),
        base_query: sourceBaseQuery.trim(),
        // `{}` is how a declaration is WITHDRAWN — the handler drops
        // null fields, so sending null would silently keep the old one.
        partition_config: datasetPartitionConfig || {},
      });
      notify(addNotification, 'Source configuration saved', 'success');
      loadDetail(detail.id);
    } catch (e: any) {
      // VERBATIM.  A 422 from _validate_partition_configs names the source
      // table and the key it refused; re-wording it here would lose the one
      // detail the author needs, and pre-validating to avoid it would put a
      // second, drifting opinion of "legal" in the client.
      setSourceError(e?.message || 'The save was rejected and the server '
        + 'gave no reason.');
      notify(addNotification, `Save failed: ${e.message}`, 'error');
    } finally { setSourceSaving(false); }
  };

  const connName = (id: number) => connections.find(c => c.id === id)?.name || `#${id}`;

  // BE HONEST ABOUT REACH.  A report only takes the partitioned path when
  // its row limit is 0: the planner refuses a capped run by name
  // (`row_limit_in_force`) because a cap is defined over the WHOLE result
  // and there is no correct way to spend it across N buckets.  The default
  // limit is not zero, so a partition column set on a dataset whose reports
  // are all capped changes nothing, and a form that stayed quiet about that
  // would be implying an effect nobody gets.
  //
  // The row limits below are the SERVER's stored values, listed rather than
  // judged one by one; the only claim made is the planner's own rule, and it
  // is made once.
  const renderReachNote = () => {
    if (reachState.state === 'idle' || reachState.state === 'loading') {
      return (
        <Typography variant="caption" color="text.secondary"
                    data-testid="partition-reach-loading">
          Checking which reports run on this dataset—
        </Typography>
      );
    }
    if (reachState.state === 'failed') {
      return (
        <Alert severity="warning" sx={{ py: 0.25 }}
               data-testid="partition-reach-failed">
          The reports on this dataset could not be read, so whether a
          declaration here would take effect is UNKNOWN— not "it will".
          The server answered: <strong>{reachState.message}</strong>
        </Alert>
      );
    }
    const reports = reachState.reports || [];
    if (reports.length === 0) {
      return (
        <Alert severity="info" sx={{ py: 0.25 }}
               data-testid="partition-reach-none">
          No business report runs on this dataset yet. A declaration is
          stored and will be planned the first time one does.
        </Alert>
      );
    }
    const capped = reports.filter((r: any) => Number(r?.row_limit) > 0);
    return (
      <Alert severity={capped.length === reports.length ? 'warning' : 'info'}
             sx={{ py: 0.25 }} data-testid="partition-reach-reports">
        A report takes the partitioned path only when its row limit is 0
        (unlimited); with a cap in force the planner refuses by name
        (<code>row_limit_in_force</code>) and the query runs whole.
        {capped.length === reports.length && (
          <strong data-testid="partition-reach-all-capped">
            {' '}All {reports.length} report(s) on this dataset carry a row
            limit, so as things stand none of them will split.
          </strong>
        )}
        <Box component="ul" sx={{ pl: 2, my: 0.5 }}>
          {reports.map((r: any) => (
            <li key={r.id}>
              <Typography variant="caption">
                {r.name} — row limit {String(r.row_limit)}
              </Typography>
            </li>
          ))}
        </Box>
      </Alert>
    );
  };

  /* ── Dataset CRUD ───────────────────────────────────────────────────── */
  useEffect(() => {
    if (!formConnectionId) { setSourceTableOptions([]); return; }
    let cancelled = false;
    api.listRegisteredTables(String(formConnectionId))
      .then((rows: any) => {
        if (cancelled) return;
        const names = (Array.isArray(rows) ? rows : [])
          .map((t: any) => t?.name || t?.table_name || t?.table || '')
          .filter(Boolean);
        setSourceTableOptions(names);
      })
      .catch(() => { if (!cancelled) setSourceTableOptions([]); });
    return () => { cancelled = true; };
  }, [formConnectionId]);

  const handleCreate = async () => {
    if (!formName.trim() || !formSubject.trim()) return;
    try {
      const initialSourceTables = (formConnectionId && formSourceTable.trim())
        ? [{ connection_id: Number(formConnectionId), table: formSourceTable.trim(), alias: '' }]
        : [];
      const initialConnIds = formConnectionId ? [Number(formConnectionId)] : [];
      const result = await api.createDataset({
        name: formName.trim(), subject: formSubject.trim(),
        description: formDesc.trim(),
        connection_ids: initialConnIds,
        source_tables: initialSourceTables,
        base_query: formBaseQuery.trim(),
      });
      // If user previewed columns in Step 2, bulk-create them
      if (previewCols.length > 0) {
        try {
          await api.bulkCreateDatasetColumns(result.id, previewCols);
          notify(addNotification, `Dataset "${result.name}" created with ${previewCols.length} columns`, 'success');
        } catch {
          notify(addNotification, `Dataset created but column creation failed — use Auto-Detect later`, 'error');
        }
      } else {
        notify(addNotification, `Dataset "${result.name}" created`, 'success');
      }
      setCreateOpen(false);
      setCreateStep(0); setPreviewCols([]); setPreviewError('');
      setFormName(''); setFormSubject(''); setFormDesc('');
      setFormConnectionId(''); setFormSourceTable(''); setFormBaseQuery('');
      loadDatasets();
      loadDetail(result.id);
    } catch (e: any) {
      notify(addNotification, 'Create failed: ' + (e.message || e), 'error');
    }
  };

  const fetchPreviewColumns = async () => {
    if (!formConnectionId || !formSourceTable.trim()) {
      setPreviewCols([]);
      setPreviewError('');
      return;
    }
    setPreviewLoading(true);
    setPreviewError('');
    try {
      const result = await api.previewDatasetColumns(Number(formConnectionId), formSourceTable.trim());
      setPreviewCols(result.columns || []);
    } catch (e: any) {
      setPreviewError(e.message || 'Failed to read schema');
      setPreviewCols([]);
    } finally { setPreviewLoading(false); }
  };

  const updatePreviewCol = (idx: number, field: string, value: any) => {
    setPreviewCols(prev => prev.map((c, i) => i === idx ? { ...c, [field]: value } : c));
  };

  const handleDelete = async (id: number) => {
    if (!await appConfirm('Delete this dataset? It is switched off, not erased -- an admin or its owner can switch it back on under Admin -> Switched off, with its columns as they were. If a report uses it, nothing changes and you are told which reports.')) return;
    try {
      await api.deleteDataset(id);
      notify(addNotification, 'Dataset deleted', 'success');
      if (selectedId === id) { setSelectedId(null); setDetail(null); }
      loadDatasets();
    } catch (e: any) { notify(addNotification, 'Delete failed: ' + e.message, 'error'); }
  };

  const handleTogglePublish = async (id: number) => {
    try {
      const result = await api.toggleDatasetPublish(id);
      notify(addNotification, result.is_published ? 'Dataset published' : 'Dataset unpublished', 'success');
      loadDatasets();
      if (selectedId === id) loadDetail(id);
    } catch (e: any) { notify(addNotification, 'Publish toggle failed: ' + e.message, 'error'); }
  };

  const handleAutoDetect = async (id: number) => {
    if (!detail) return;
    const src = (detail.source_tables || [])[0];
    if (!src?.connection_id || !src?.table) {
      notify(addNotification, 'No source table configured — add one in the Source tab first', 'error');
      return;
    }
    setPreviewDialogOpen(true);
    setPreviewDialogLoading(true);
    setPreviewDialogCols([]);
    try {
      const result = await api.previewDatasetColumns(Number(src.connection_id), src.table);
      setPreviewDialogCols(result.columns || []);
    } catch (e: any) {
      notify(addNotification, 'Preview failed: ' + e.message, 'error');
      setPreviewDialogOpen(false);
    } finally { setPreviewDialogLoading(false); }
  };

  const confirmAutoDetect = async () => {
    if (!selectedId || previewDialogCols.length === 0) return;
    try {
      await api.bulkCreateDatasetColumns(selectedId, previewDialogCols);
      notify(addNotification, `Created ${previewDialogCols.length} columns`, 'success');
      setPreviewDialogOpen(false);
      loadDetail(selectedId);
    } catch (e: any) { notify(addNotification, 'Create failed: ' + e.message, 'error'); }
  };

  const updatePreviewDialogCol = (idx: number, field: string, value: any) => {
    setPreviewDialogCols(prev => prev.map((c, i) => i === idx ? { ...c, [field]: value } : c));
  };

  /* ── Column CRUD ────────────────────────────────────────────────────── */
  // ONE reader of /source-columns for the two editors that need choices
  // (the column dialog, and the partition column picker on the Source tab).
  // Two copies would be two answers to "what does this source have".
  const loadSourceColumns = useCallback(() => {
    if (!selectedId) return;
    setSourceColsAsked(true);
    setSourceColsLoading(true);
    setSourceColsMsg('');
    api.getDatasetSourceColumns(selectedId)
      .then((res: any) => {
        setSourceCols(Array.isArray(res?.columns) ? res.columns : []);
        // "could not read" and "has no columns" are different answers
        // and the editor must show which one it got.
        setSourceColsMsg(res?.message || '');
      })
      .catch((e: any) => {
        setSourceCols([]);
        setSourceColsMsg(e?.message || ('The source could not be read just '
          + 'now — type the column name if you know it.'));
      })
      .finally(() => setSourceColsLoading(false));
  }, [selectedId]);

  const openColumnDialog = (col?: any) => {
    setEditingCol(col || {
      physical_name: '', friendly_name: '', column_type: 'dimension',
      data_type: 'string', aggregation: '', format_pattern: '',
      description: '', synonyms: [], role_whitelist: [], is_hidden: false,
    });
    setColDialogOpen(true);
    // Fetched when the dialog opens, not on page load: it can reach the
    // source, and the vast majority of visits to this page never open it.
    loadSourceColumns();
  };

  const saveColumn = async () => {
    if (!editingCol || !selectedId) return;
    try {
      if (editingCol.id) {
        await api.updateDatasetColumn(editingCol.id, editingCol);
      } else {
        await api.createDatasetColumn(selectedId, editingCol);
      }
      notify(addNotification, 'Column saved', 'success');
      setColDialogOpen(false);
      loadDetail(selectedId);
    } catch (e: any) { notify(addNotification, 'Save failed: ' + e.message, 'error'); }
  };

  const deleteColumn = async (colId: number) => {
    if (!await appConfirm('Delete this column?')) return;
    try {
      await api.deleteDatasetColumn(colId);
      notify(addNotification, 'Column deleted', 'success');
      if (selectedId) loadDetail(selectedId);
    } catch (e: any) { notify(addNotification, 'Delete failed: ' + e.message, 'error'); }
  };

  /* ── Config ─────────────────────────────────────────────────────────── */
  const loadConfig = async () => {
    try {
      const c = await api.getSemanticLayerConfig();
      setConfig(c);
      setConfigOpen(true);
    } catch (e: any) { notify(addNotification, 'Failed to load config', 'error'); }
  };

  const saveConfig = async () => {
    try {
      await api.setSemanticLayerConfig(config);
      notify(addNotification, 'Config saved', 'success');
      setConfigOpen(false);
    } catch (e: any) { notify(addNotification, 'Save failed: ' + e.message, 'error'); }
  };

  /* ── Render ─────────────────────────────────────────────────────────── */
  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, gap: 2 }}>
        <SchemaIcon sx={{ fontSize: 32, color: 'primary.main' }} />
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5" fontWeight={700}>Semantic Layer</Typography>
          <Typography variant="body2" color="text.secondary">
            Model your own business datasets over connections you can access — each dataset stays
            private to you until an admin publishes it for everyone
          </Typography>
        </Box>
        {isAdmin && (
          <Button startIcon={<SettingsIcon />} onClick={loadConfig} variant="outlined" size="small">
            Config
          </Button>
        )}
        <Button startIcon={<AddIcon />}
                onClick={() => { setWizardInitialSource(null); setWizardOpen(true); }}
                variant="contained" size="small">
          New Dataset
        </Button>
      </Box>

      {/* Search (FB-49) */}
      <TextField
        size="small"
        value={search}
        onChange={e => setSearch(e.target.value)}
        placeholder="Search datasets"
        inputProps={{ 'aria-label': 'Search datasets' }}
        sx={{ mb: 2, minWidth: 320 }}
        InputProps={{
          startAdornment: (
            <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>
          ),
          endAdornment: search ? (
            <InputAdornment position="end">
              <IconButton size="small" aria-label="Clear search" onClick={() => setSearch('')}>
                <ClearIcon fontSize="small" />
              </IconButton>
            </InputAdornment>
          ) : null,
        }}
      />

      {/* Dataset List */}
      <Paper sx={{ mb: 3 }}>
        {loading ? (
          <Box sx={{ p: 2 }}>
            {[1, 2, 3].map(i => (
              <Skeleton key={i} variant="rounded" height={48} sx={{ mb: 1, borderRadius: 1 }} />
            ))}
          </Box>
        ) : filteredDatasets.length === 0 ? (
          <Box sx={{ p: 4, textAlign: 'center' }}>
            <Typography color="text.secondary">
              {datasets.length === 0
                ? 'No datasets yet. Create your first business dataset.'
                : `No dataset matches "${search.trim()}".`}
            </Typography>
          </Box>
        ) : (
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 700 }}>Name</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Subject</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Owner</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>Updated</TableCell>
                  <TableCell align="right" sx={{ fontWeight: 700 }}>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {pagedDatasets.map(ds => (
                  <TableRow key={ds.id} hover
                    selected={selectedId === ds.id}
                    {...clickableRow(() => loadDetail(ds.id), { label: ds.name, selected: selectedId === ds.id })}
                    sx={{ cursor: 'pointer' }}>
                    <TableCell>
                      <Typography fontWeight={600}>{ds.name}</Typography>
                      {ds.description && (
                        <Typography variant="caption" color="text.secondary">{ds.description}</Typography>
                      )}
                    </TableCell>
                    <TableCell><Chip label={ds.subject} size="small" /></TableCell>
                    <TableCell>
                      {ds.owner}
                      {ownsDataset(ds) && (
                        <Chip label="you" size="small" color="primary" variant="outlined"
                              sx={{ ml: 0.5, height: 18 }} />
                      )}
                    </TableCell>
                    <TableCell>
                      <Tooltip title={ds.is_published
                        ? 'Published — visible to everyone in the org'
                        : 'Private — only you (and admins) can see and use it'}>
                        <Chip label={ds.is_published ? 'Published' : 'Private'}
                              color={ds.is_published ? 'success' : 'default'} size="small" />
                      </Tooltip>
                      {ds.is_certified && (
                        <Tooltip title={`Certified${ds.certified_by ? ` by ${ds.certified_by}` : ''} — admin-endorsed shared model`}>
                          <Chip label="Certified" size="small" color="info" variant="outlined"
                                sx={{ ml: 0.5 }} />
                        </Tooltip>
                      )}
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">
                        {ds.updated_at ? new Date(ds.updated_at).toLocaleDateString() : '-'}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      {canReport && (
                        <Tooltip title="Create a report on this dataset">
                          <IconButton size="small" aria-label={`Create report — ${ds.name}`}
                                      data-testid={`dataset-create-report-${ds.id}`}
                                      onClick={(e) => { e.stopPropagation(); navigate(newReportForDatasetPath(ds.id)); }}>
                            <ReportIcon color="primary" />
                          </IconButton>
                        </Tooltip>
                      )}
                      <Tooltip title="Query this dataset">
                        <IconButton size="small" onClick={(e) => { e.stopPropagation(); navigate(datasetQueryPath(ds)); }}>
                          <QueryIcon color="primary" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title={isAdmin
                        ? (ds.is_published ? 'Unpublish' : 'Publish for everyone')
                        : 'Publishing a dataset org-wide requires an admin'}>
                        <span>
                          <IconButton aria-label="Publish" size="small" disabled={!isAdmin}
                                      onClick={(e) => { e.stopPropagation(); handleTogglePublish(ds.id); }}>
                            <PublishIcon color={!isAdmin ? 'disabled' : ds.is_published ? 'success' : 'action'} />
                          </IconButton>
                        </span>
                      </Tooltip>
                      <Tooltip title={canMutate(ds)
                        ? 'Delete'
                        : 'Only the owner or an admin can delete this dataset'}>
                        <span>
                          <IconButton aria-label={canMutate(ds)
                        ? 'Delete'
                        : 'Only the owner or an admin can delete this dataset'} size="small" disabled={!canMutate(ds)}
                                      onClick={(e) => { e.stopPropagation(); handleDelete(ds.id); }}>
                            <DeleteIcon color={canMutate(ds) ? 'error' : 'disabled'} />
                          </IconButton>
                        </span>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <TablePagination
              component="div"
              count={filteredDatasets.length}
              page={page}
              onPageChange={(_, p) => setPage(p)}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={e => setRowsPerPage(parseInt(e.target.value, 10))}
              rowsPerPageOptions={[10, 25, 50, 100]}
            />
          </TableContainer>
        )}
      </Paper>

      {/* Detail Panel */}
      {selectedId && (
        <Paper sx={{ p: 0 }}>
          {detailLoading ? (
            <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>
          ) : detail ? (
            <>
              <Box sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 2,
                         bgcolor: (t) => alpha(t.palette.primary.main, 0.04) }}>
                <Typography variant="h6" fontWeight={700} sx={{ flex: 1 }}>
                  {detail.name}
                  <Chip label={detail.subject} size="small" sx={{ ml: 1 }} />
                </Typography>
                <Button startIcon={<AutoDetectIcon />} size="small" variant="outlined"
                        onClick={() => handleAutoDetect(detail.id)}>
                  Auto-Detect Columns
                </Button>
                <Button startIcon={<RefreshIcon />} size="small"
                        onClick={() => loadDetail(detail.id)}>
                  Refresh
                </Button>
              </Box>

              <Tabs value={detailTab} onChange={(_, v) => setDetailTab(v)}
                    variant="scrollable" scrollButtons="auto"
                    sx={{ borderBottom: 1, borderColor: 'divider', px: 2 }}>
                <Tab icon={<SourceIcon />} iconPosition="start"
                     label={`Source (${(detail.source_tables || []).length})`} />
                <Tab icon={<ColumnIcon />} iconPosition="start" label={`Columns (${(detail.columns || []).length})`} />
                <Tab icon={<ClassIcon />} iconPosition="start" label={`Classes (${(detail.classes || []).length})`} />
                <Tab icon={<RelIcon />} iconPosition="start" label={`Relationships (${(detail.relationships || []).length})`} />
                <Tab icon={<HierarchyIcon />} iconPosition="start" label={`Hierarchies (${(detail.hierarchies || []).length})`} />
                <Tab icon={<ConditionIcon />} iconPosition="start" label={`Conditions (${(detail.conditions || []).length})`} />
                <Tab icon={<AggIcon />} iconPosition="start" label={`Agg Awareness (${(detail.agg_awareness || []).length})`} />
                <Tab icon={<CachedIcon />} iconPosition="start" label="Agg Cache" />
              </Tabs>

              {/* Tab: Source Configuration */}
              {detailTab === 0 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Connect this dataset to physical data sources — S3 buckets, Snowflake databases, or other connections.
                    The federation engine uses these to build and execute queries.
                  </Alert>

                  {/* Source tables list */}
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>Source Tables</Typography>
                  {sourceTables.map((st: any, idx: number) => (
                    <Paper key={idx} variant="outlined" sx={{ p: 1.5, mb: 1 }}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <FormControl size="small" sx={{ minWidth: 200 }}>
                          <InputLabel id="sel-datasetmanagerpage-connection">Connection</InputLabel>
                          <Select labelId="sel-datasetmanagerpage-connection" value={st.connection_id || ''} label="Connection"
                                  onChange={e => updateSourceTable(idx, 'connection_id', e.target.value)}>
                            {connections.map(c => (
                              <MenuItem key={c.id} value={c.id}>
                                {c.name} ({c.connection_type})
                              </MenuItem>
                            ))}
                          </Select>
                        </FormControl>
                        <TextField size="small" label="Table / Path" value={st.table || ''}
                                   onChange={e => updateSourceTable(idx, 'table', e.target.value)}
                                   sx={{ flex: 1 }}
                                   placeholder="s3://bucket/path/file.parquet or schema.table" />
                        <Tooltip title="Browse files">
                          <span>
                            <IconButton aria-label="Browse files" size="small" disabled={!st.connection_id}
                                        onClick={() => browseForTable(Number(st.connection_id), 'source', idx)}>
                              <BrowseIcon fontSize="small" />
                            </IconButton>
                          </span>
                        </Tooltip>
                        <TextField size="small" label="Alias" value={st.alias || ''}
                                   onChange={e => updateSourceTable(idx, 'alias', e.target.value)}
                                   sx={{ width: 120 }}
                                   placeholder="e.g. sales" />
                        <IconButton aria-label="Remove row" size="small" color="error" onClick={() => removeSourceTable(idx)}>
                          <RemoveRowIcon fontSize="small" />
                        </IconButton>
                      </Stack>

                      {/* Progressive partition loading (2026-09-05).
                          Collapsed and UNMOUNTED until opened: the column
                          picker's read can reach the source, and most visits
                          to this tab are not about partitioning. */}
                      <Accordion disableGutters elevation={0} sx={{ mt: 1 }}
                                 TransitionProps={{ unmountOnExit: true }}
                                 onChange={(_e, expanded) => {
                                   if (!expanded) return;
                                   loadSourceColumns();
                                   loadReach();
                                 }}>
                        <AccordionSummary expandIcon={<ExpandMoreIcon />}
                                          data-testid={`partition-section-${idx}`}>
                          <Typography variant="body2" fontWeight={600}>
                            Progressive partition loading
                          </Typography>
                          {st.partition_config?.column && (
                            <Chip size="small" sx={{ ml: 1 }}
                                  label={`column: ${st.partition_config.column}`} />
                          )}
                        </AccordionSummary>
                        <AccordionDetails>
                          {(st.connection_id && st.table) ? (
                            <PartitionConfigEditor
                              testIdPrefix={`partition-config-${idx}`}
                              value={st.partition_config || null}
                              columns={partitionColumnChoices}
                              disabled={!canMutate(detail)}
                              onChange={next => setPartitionConfig(idx, next)}
                              reachNote={renderReachNote()} />
                          ) : (
                            <Alert severity="info" sx={{ py: 0.5 }}
                                   data-testid={`partition-unstorable-${idx}`}>
                              This entry names no connection and table, and
                              this tab only writes entries that name both
                              — a declaration made here would not be
                              stored. Give the entry a connection and a table
                              first.
                            </Alert>
                          )}
                        </AccordionDetails>
                      </Accordion>
                    </Paper>
                  ))}

                  {/* 2026-09-05 — the DATASET-LEVEL declaration.
                      Rendered unconditionally, because the lane that
                      needs it most (custom SQL) has NO source table
                      entries at all, so anything hung off the list
                      above is unreachable for it.  Same editor, same
                      PartitionConfigModel on the server: a typo is a
                      422 that names the key, never a stored setting
                      nothing reads. */}
                  <Accordion disableGutters elevation={0} sx={{ mb: 1 }}
                             TransitionProps={{ unmountOnExit: true }}
                             onChange={(_e, expanded) => {
                               if (!expanded) return;
                               loadSourceColumns();
                               loadReach();
                             }}>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />}
                                      data-testid="partition-section-dataset">
                      <Typography variant="body2" fontWeight={600}>
                        Progressive partition loading (whole dataset)
                      </Typography>
                      {datasetPartitionConfig?.column && (
                        <Chip size="small" sx={{ ml: 1 }}
                              label={`column: ${datasetPartitionConfig.column}`} />
                      )}
                    </AccordionSummary>
                    <AccordionDetails>
                      <Alert severity="info" sx={{ mb: 1, py: 0.25 }}
                             data-testid="partition-dataset-scope">
                        Declared for the dataset as a whole — the only home a
                        custom-SQL dataset has, since it names no source
                        tables. One dataset has one partition plan: if this
                        and a source table above declare different plans the
                        server refuses both and runs the query whole.
                      </Alert>
                      <PartitionConfigEditor
                        testIdPrefix="partition-config-dataset"
                        value={datasetPartitionConfig}
                        columns={partitionColumnChoices}
                        disabled={!canMutate(detail)}
                        onChange={next => setDatasetPartitionConfig(next)}
                        reachNote={renderReachNote()} />
                    </AccordionDetails>
                  </Accordion>

                  {/* The plan's own verdict for the last run. */}
                  <Paper variant="outlined" sx={{ p: 1.5, mb: 1 }}>
                    <Stack direction="row" alignItems="center" sx={{ mb: 1 }}>
                      <Typography variant="subtitle2" sx={{ flex: 1 }}>
                        Last run's scan plan
                      </Typography>
                      <Button size="small" startIcon={<RefreshIcon />}
                              onClick={loadVerdict}
                              disabled={!savedPartitionConfig}>
                        Re-read
                      </Button>
                    </Stack>
                    <PartitionScanVerdict
                      subject="dataset"
                      declaredColumn={savedPartitionConfig?.column}
                      status={savedPartitionConfig
                        ? verdict
                        : { state: 'undeclared' }} />
                  </Paper>

                  <Button startIcon={<AddIcon />} size="small" variant="outlined"
                          onClick={addSourceTable} sx={{ mb: 2 }}>
                    Add Source Table
                  </Button>

                  {/* Base Query override */}
                  <Divider sx={{ my: 2 }} />
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>
                    Base Query (optional — overrides source table auto-resolution)
                  </Typography>
                  <TextField fullWidth multiline rows={4} value={sourceBaseQuery}
                             onChange={e => setSourceBaseQuery(e.target.value)}
                             placeholder="SELECT * FROM sales_fact WHERE year >= 2024"
                             InputProps={{ sx: { fontFamily: 'monospace', fontSize: '0.85rem' } }} />

                  {/* Connection summary */}
                  {sourceTables.length > 0 && (
                    <Box sx={{ mt: 2 }}>
                      <Typography variant="caption" color="text.secondary">
                        Connections used: {[...new Set(sourceTables.filter(s => s.connection_id).map(s => connName(Number(s.connection_id))))].join(', ') || 'none'}
                      </Typography>
                    </Box>
                  )}

                  {sourceError && (
                    <Alert severity="error" sx={{ mt: 2 }}
                           data-testid="source-save-error"
                           onClose={() => setSourceError(null)}>
                      {sourceError}
                    </Alert>
                  )}

                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                    <Button variant="contained" startIcon={<SaveIcon />}
                            onClick={saveSourceConfig} disabled={sourceSaving}>
                      {sourceSaving ? <CircularProgress size={20} /> : 'Save Source Config'}
                    </Button>
                  </Box>
                </Box>
              )}

              {/* Tab: Columns */}
              {detailTab === 1 && (
                <Box sx={{ p: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 1 }}>
                    <Button startIcon={<AddIcon />} size="small" variant="outlined"
                            onClick={() => openColumnDialog()}>Add Column</Button>
                  </Box>
                  <TableContainer>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 700 }}>Physical Name</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Friendly Name</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Type</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Data Type</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Aggregation</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Synonyms</TableCell>
                          <TableCell align="right" sx={{ fontWeight: 700 }}>Actions</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {(detail.columns || []).map((col: any) => (
                          <TableRow key={col.id} hover>
                            <TableCell>
                              <Typography variant="body2" fontFamily="monospace">{col.physical_name}</Typography>
                            </TableCell>
                            <TableCell>
                              <Typography fontWeight={500}>{col.friendly_name}</Typography>
                            </TableCell>
                            <TableCell>
                              <Chip label={col.column_type} size="small"
                                    color={col.column_type === 'measure' ? 'primary'
                                         : col.column_type === 'kpi' ? 'warning'
                                         : col.column_type === 'detail' ? 'info' : 'default'} />
                            </TableCell>
                            <TableCell>{col.data_type}</TableCell>
                            <TableCell>{col.aggregation || '-'}</TableCell>
                            <TableCell>
                              {(col.synonyms || []).slice(0, 3).map((s: string) => (
                                <Chip key={s} label={s} size="small" sx={{ mr: 0.5 }} variant="outlined" />
                              ))}
                            </TableCell>
                            <TableCell align="right">
                              <IconButton aria-label="Edit" size="small" onClick={() => openColumnDialog(col)}>
                                <EditIcon fontSize="small" />
                              </IconButton>
                              <IconButton aria-label="Delete" size="small" onClick={() => deleteColumn(col.id)}>
                                <DeleteIcon fontSize="small" color="error" />
                              </IconButton>
                            </TableCell>
                          </TableRow>
                        ))}
                        {(detail.columns || []).length === 0 && (
                          <TableRow>
                            <TableCell colSpan={7} align="center" sx={{ py: 3 }}>
                              <Typography color="text.secondary">
                                No columns yet. Click "Auto-Detect Columns" or "Add Column".
                              </Typography>
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              )}

              {/* Tab: Classes */}
              {detailTab === 2 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Classes group columns logically (e.g. "Customer", "Time", "Product") — like BO Universe classes.
                  </Alert>
                  <List>
                    {(detail.classes || []).map((cls: any) => (
                      <ListItem key={cls.id} divider>
                        <ListItemText primary={cls.label || cls.name}
                                      secondary={`Name: ${cls.name} | Sort: ${cls.sort_order}`} />
                        <ListItemSecondaryAction>
                          <IconButton aria-label="Edit" size="small"><EditIcon fontSize="small" /></IconButton>
                        </ListItemSecondaryAction>
                      </ListItem>
                    ))}
                  </List>
                  {(detail.classes || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No classes defined.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Relationships */}
              {detailTab === 3 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Define how source tables join within this dataset. Used by the federation engine.
                  </Alert>
                  <TableContainer>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 700 }}>Left Table</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Join Type</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Right Table</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Join Keys</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Cardinality</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {(detail.relationships || []).map((rel: any) => (
                          <TableRow key={rel.id} hover>
                            <TableCell><Typography fontFamily="monospace" variant="body2">{rel.left_table}</Typography></TableCell>
                            <TableCell><Chip label={rel.join_type.toUpperCase()} size="small" /></TableCell>
                            <TableCell><Typography fontFamily="monospace" variant="body2">{rel.right_table}</Typography></TableCell>
                            <TableCell>
                              {(rel.join_keys || []).map((jk: any, i: number) => (
                                <Typography key={i} variant="caption" fontFamily="monospace">
                                  {jk.left} = {jk.right}{i < rel.join_keys.length - 1 ? ', ' : ''}
                                </Typography>
                              ))}
                            </TableCell>
                            <TableCell>{rel.cardinality.replace(/_/g, ' ')}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                  {(detail.relationships || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No relationships defined.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Hierarchies */}
              {detailTab === 4 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Drill hierarchies define click-to-expand paths (e.g. Year → Quarter → Month → Day).
                  </Alert>
                  {(detail.hierarchies || []).map((h: any) => (
                    <Paper key={h.id} variant="outlined" sx={{ p: 2, mb: 1 }}>
                      <Typography fontWeight={600}>{h.name}</Typography>
                      <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                        {(h.levels || []).map((lvl: any, i: number) => (
                          <React.Fragment key={i}>
                            <Chip label={lvl.label || `Level ${i + 1}`} size="small" color="primary" variant="outlined" />
                            {i < h.levels.length - 1 && <Typography sx={{ alignSelf: 'center' }}>→</Typography>}
                          </React.Fragment>
                        ))}
                      </Stack>
                    </Paper>
                  ))}
                  {(detail.hierarchies || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No drill hierarchies defined.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Conditions */}
              {detailTab === 5 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Pre-defined conditions are reusable WHERE clauses business users can apply with one click.
                  </Alert>
                  {(detail.conditions || []).map((c: any) => (
                    <Paper key={c.id} variant="outlined" sx={{ p: 2, mb: 1 }}>
                      <Typography fontWeight={600}>{c.label || c.name}</Typography>
                      {c.description && <Typography variant="body2" color="text.secondary">{c.description}</Typography>}
                      <Typography variant="body2" fontFamily="monospace" sx={{ mt: 0.5, color: 'primary.main' }}>
                        WHERE {c.where_clause}
                      </Typography>
                    </Paper>
                  ))}
                  {(detail.conditions || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No pre-defined conditions.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Agg Awareness */}
              {detailTab === 6 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Aggregation awareness maps measures to pre-aggregated tables for faster query routing.
                  </Alert>
                  {(detail.agg_awareness || []).map((a: any) => (
                    <Paper key={a.id} variant="outlined" sx={{ p: 2, mb: 1 }}>
                      <Typography fontWeight={600}>Measure Column ID: {a.measure_col_id}</Typography>
                      <Typography variant="body2" fontFamily="monospace">Table: {a.agg_table}</Typography>
                      <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                        {(a.agg_dimensions || []).map((d: string) => (
                          <Chip key={d} label={d} size="small" variant="outlined" />
                        ))}
                      </Stack>
                    </Paper>
                  ))}
                  {(detail.agg_awareness || []).length === 0 && (
                    <Typography color="text.secondary" align="center" sx={{ py: 2 }}>
                      No aggregation awareness rules.
                    </Typography>
                  )}
                </Box>
              )}

              {/* Tab: Agg Cache (Phase 55) */}
              {detailTab === 7 && (
                <Box sx={{ p: 2 }}>
                  <Alert severity="info" sx={{ mb: 2 }}>
                    Pre-computed aggregation caches deliver sub-second query results. Define dimension + measure rollups
                    and schedule automatic refreshes.
                  </Alert>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2, gap: 1 }}>
                    <Button size="small" variant="contained" startIcon={<AddIcon />}
                            onClick={openCacheCreateDialog}>
                      Create Rollup
                    </Button>
                    <Button size="small" startIcon={<RefreshIcon />}
                            disabled={aggCacheLoading}
                            onClick={async () => {
                              setAggCacheLoading(true);
                              try {
                                const resp = await api.listAggCacheEntries(detail.id);
                                setAggCacheEntries(resp.entries || []);
                              } catch { /* ignore */ } finally { setAggCacheLoading(false); }
                            }}>
                      Refresh
                    </Button>
                  </Box>
                  {aggCacheLoading && <LinearProgress sx={{ mb: 1 }} />}
                  {aggCacheEntries.length > 0 ? (
                    <TableContainer component={Paper} variant="outlined">
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell sx={{ fontWeight: 700 }}>Name</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Grain</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Rows</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Hits</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Last Built</TableCell>
                            <TableCell sx={{ fontWeight: 700 }}>Actions</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {aggCacheEntries.map((ce: any) => {
                            const statusColor: Record<string, 'success' | 'warning' | 'error' | 'info' | 'default'> = {
                              ready: 'success', building: 'info', stale: 'warning',
                              expired: 'error', failed: 'error', pending: 'default',
                            };
                            return (
                              <TableRow key={ce.id} hover>
                                <TableCell>
                                  <Typography variant="body2" fontWeight={600}>{ce.name}</Typography>
                                  <Typography variant="caption" color="text.secondary">
                                    {(ce.dimension_col_ids || []).length} dims, {(ce.measure_col_ids || []).length} measures
                                  </Typography>
                                </TableCell>
                                <TableCell><Chip label={ce.grain_label} size="small" variant="outlined" /></TableCell>
                                <TableCell>
                                  <Chip label={ce.status} size="small"
                                        color={statusColor[ce.status] || 'default'}
                                        variant={ce.status === 'ready' ? 'filled' : 'outlined'} />
                                </TableCell>
                                <TableCell>{ce.row_count?.toLocaleString() || '—'}</TableCell>
                                <TableCell>{ce.hit_count || 0}</TableCell>
                                <TableCell sx={{ fontSize: '0.75rem' }}>
                                  {ce.last_built_at ? new Date(ce.last_built_at).toLocaleString() : '—'}
                                </TableCell>
                                <TableCell>
                                  <Tooltip title="Edit">
                                    <IconButton size="small" onClick={() => openCacheEditDialog(ce)}>
                                      <EditIcon fontSize="small" />
                                    </IconButton>
                                  </Tooltip>
                                  <Tooltip title="Build Now">
                                    <IconButton size="small" color="primary"
                                                onClick={async () => {
                                                  try {
                                                    await api.triggerAggCacheBuild(ce.id);
                                                    notify(addNotification, `Build triggered for ${ce.name}`, 'success');
                                                  } catch { notify(addNotification, 'Build trigger failed', 'error'); }
                                                }}>
                                      <BuildNowIcon fontSize="small" />
                                    </IconButton>
                                  </Tooltip>
                                  <Tooltip title="Delete">
                                    <IconButton size="small" color="error"
                                                onClick={async () => {
                                                  try {
                                                    await api.deleteAggCacheEntry(ce.id);
                                                    setAggCacheEntries(prev => prev.filter(e => e.id !== ce.id));
                                                    notify(addNotification, 'Cache entry deleted', 'success');
                                                  } catch { notify(addNotification, 'Delete failed', 'error'); }
                                                }}>
                                      <DeleteIcon fontSize="small" />
                                    </IconButton>
                                  </Tooltip>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  ) : (
                    <Typography color="text.secondary" align="center" sx={{ py: 3 }}>
                      No aggregation cache entries. Create rollup definitions to enable sub-second queries.
                    </Typography>
                  )}
                </Box>
              )}
            </>
          ) : null}
        </Paper>
      )}

      {/* ── Create Dataset Dialog (3-Step Wizard) ─────────────────────── */}
      <AppDialog open={createOpen}
        onClose={() => { setCreateOpen(false); setCreateStep(0); setPreviewCols([]); setPreviewError(''); }}
        size="md"
        title="Create Business Dataset"
        actions={<>
          <Button onClick={() => { setCreateOpen(false); setCreateStep(0); setPreviewCols([]); setPreviewError(''); }}>
            Cancel
          </Button>
          {createStep > 0 && (
            <Button onClick={() => setCreateStep(s => s - 1)}>Back</Button>
          )}
          {createStep < 2 ? (
            <Button variant="contained"
                    disabled={createStep === 0 && (!formName.trim() || !formSubject.trim())}
                    onClick={() => {
                      const next = createStep + 1;
                      setCreateStep(next);
                      if (next === 2 && formConnectionId && formSourceTable.trim()) {
                        fetchPreviewColumns();
                      }
                    }}>
              Next
            </Button>
          ) : (
            <Button variant="contained" onClick={handleCreate}>
              Create{previewCols.length > 0 ? ` (${previewCols.length} columns)` : ''}
            </Button>
          )}
        </>}>
          <Stepper activeStep={createStep} sx={{ mb: 3, mt: 1 }}>
            <Step><StepLabel>Basics</StepLabel></Step>
            <Step><StepLabel>Data Source</StepLabel></Step>
            <Step><StepLabel>Preview Columns</StepLabel></Step>
          </Stepper>

          {/* Step 0: Basics */}
          {createStep === 0 && (
            <Stack spacing={2}>
              <TextField label="Dataset Name" fullWidth required value={formName}
                         onChange={e => setFormName(e.target.value)}
                         placeholder="e.g. Sales Analysis" />
              <TextField label="Subject" fullWidth required value={formSubject}
                         onChange={e => setFormSubject(e.target.value)}
                         placeholder="e.g. Sales, HR, Finance" />
              <TextField label="Description" fullWidth multiline rows={2}
                         value={formDesc} onChange={e => setFormDesc(e.target.value)}
                         placeholder="Brief description for business users" />
            </Stack>
          )}

          {/* Step 1: Data Source */}
          {createStep === 1 && (
            <Stack spacing={2}>
              <FormControl fullWidth>
                <InputLabel id="sel-datasetmanagerpage-connection-2">Connection</InputLabel>
                <Select labelId="sel-datasetmanagerpage-connection-2" value={formConnectionId} label="Connection"
                        onChange={e => setFormConnectionId(e.target.value as number)}>
                  <MenuItem value="">— none (configure later) —</MenuItem>
                  {connections.map(c => (
                    <MenuItem key={c.id} value={c.id}>
                      {c.name} ({c.connection_type})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              {formConnectionId && (
                <Stack direction="row" spacing={1} alignItems="center">
                  <Autocomplete
                    freeSolo fullWidth options={sourceTableOptions}
                    value={formSourceTable}
                    onInputChange={(_e, v) => setFormSourceTable(v || '')}
                    renderInput={(params) => (
                      <TextField {...params} label="Table / Path"
                        placeholder="s3://bucket/folder/file.parquet  or  catalog.schema.table"
                        helperText={sourceTableOptions.length
                          ? `${sourceTableOptions.length} registered table(s) on this connection`
                          : 'No registered tables found — type a path or browse'} />
                    )}
                  />
                  <Tooltip title="Browse connection files/tables">
                    <IconButton onClick={() => browseForTable(Number(formConnectionId), 'create')}>
                      <BrowseIcon />
                    </IconButton>
                  </Tooltip>
                </Stack>
              )}

              <TextField label="Base Query (optional)" fullWidth multiline rows={3}
                         value={formBaseQuery} onChange={e => setFormBaseQuery(e.target.value)}
                         placeholder="Optional: SELECT * FROM my_table WHERE active = true"
                         InputProps={{ sx: { fontFamily: 'monospace', fontSize: '0.85rem' } }}
                         helperText="Overrides auto-resolution from source table. Leave empty to auto-resolve." />

              {!formConnectionId && (
                <Alert severity="info" variant="outlined">
                  No connection selected — you can skip this step and configure a data source later in the Source tab.
                </Alert>
              )}
            </Stack>
          )}

          {/* Step 2: Preview Columns */}
          {createStep === 2 && (
            <Box>
              {previewLoading && <LinearProgress sx={{ mb: 2 }} />}
              {previewError && (
                <Alert severity="error" sx={{ mb: 2 }}>
                  {previewError}
                  <Button size="small" sx={{ ml: 1 }} onClick={fetchPreviewColumns}>Retry</Button>
                </Alert>
              )}
              {!formConnectionId || !formSourceTable.trim() ? (
                <Alert severity="info" variant="outlined">
                  No data source selected — dataset will be created without columns. You can use Auto-Detect later from the detail panel.
                </Alert>
              ) : previewCols.length > 0 ? (
                <>
                  <Alert severity="success" sx={{ mb: 2 }}>
                    Detected <strong>{previewCols.length}</strong> columns:&nbsp;
                    {previewCols.filter(c => c.column_type === 'dimension' && c.data_type !== 'date').length} dimensions,&nbsp;
                    {previewCols.filter(c => c.column_type === 'measure').length} measures,&nbsp;
                    {previewCols.filter(c => c.data_type === 'date').length} dates
                    {previewCols.filter(c => c.is_hidden).length > 0 &&
                      <>,&nbsp;{previewCols.filter(c => c.is_hidden).length} hidden (IDs)</>}
                  </Alert>
                  <TableContainer sx={{ maxHeight: 360 }}>
                    <Table size="small" stickyHeader>
                      <TableHead>
                        <TableRow>
                          <TableCell sx={{ fontWeight: 700 }}>Physical Name</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Friendly Name</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Type</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Data Type</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Aggregation</TableCell>
                          <TableCell sx={{ fontWeight: 700 }}>Hidden</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {previewCols.map((col, idx) => (
                          <TableRow key={idx} sx={{ opacity: col.is_hidden ? 0.55 : 1 }}>
                            <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>{col.physical_name}</TableCell>
                            <TableCell>
                              <TextField size="small" variant="standard" value={col.friendly_name}
                                         onChange={e => updatePreviewCol(idx, 'friendly_name', e.target.value)}
                                         sx={{ width: 140 }} />
                            </TableCell>
                            <TableCell>
                              <Select inputProps={{ 'aria-label': `Column type for ${col.friendly_name || col.physical_name || 'column'}` }} size="small" variant="standard" value={col.column_type}
                                      onChange={e => {
                                        const v = e.target.value;
                                        updatePreviewCol(idx, 'column_type', v);
                                        if (v === 'dimension' || v === 'detail') updatePreviewCol(idx, 'aggregation', '');
                                        if ((v === 'measure' || v === 'kpi') && !col.aggregation) updatePreviewCol(idx, 'aggregation', 'sum');
                                      }}>
                                {COLUMN_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Select inputProps={{ 'aria-label': `Data type for ${col.friendly_name || col.physical_name || 'column'}` }} size="small" variant="standard" value={col.data_type}
                                      onChange={e => updatePreviewCol(idx, 'data_type', e.target.value)}>
                                {DATA_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                              </Select>
                            </TableCell>
                            <TableCell>
                              {(col.column_type === 'measure' || col.column_type === 'kpi') ? (
                                <Select inputProps={{ 'aria-label': `Aggregation for ${col.friendly_name || col.physical_name || 'column'}` }} size="small" variant="standard" value={col.aggregation || ''}
                                        onChange={e => updatePreviewCol(idx, 'aggregation', e.target.value)}>
                                  {AGGREGATIONS.filter(a => a).map(a => <MenuItem key={a} value={a}>{a}</MenuItem>)}
                                </Select>
                              ) : <Typography variant="body2" color="text.secondary">—</Typography>}
                            </TableCell>
                            <TableCell>
                              <Checkbox size="small" checked={!!col.is_hidden}
                                        onChange={e => updatePreviewCol(idx, 'is_hidden', e.target.checked)} />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </>
              ) : !previewLoading && !previewError ? (
                <Alert severity="info" variant="outlined">
                  Loading column preview...
                </Alert>
              ) : null}
            </Box>
          )}
      </AppDialog>

      {/* ── Column Edit Dialog ─────────────────────────────────────────── */}
      <AppDialog open={colDialogOpen}
        onClose={() => setColDialogOpen(false)}
        size="sm"
        title={editingCol?.id ? 'Edit Column' : 'Add Column'}
        actions={<>
          <Button onClick={() => setColDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" startIcon={<SaveIcon />} onClick={saveColumn}
                  disabled={!editingCol?.physical_name || !editingCol?.friendly_name}>Save</Button>
        </>}>
          {editingCol && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              {/* freeSolo on purpose: a source that cannot answer must
                  not block the author, and a computed column may
                  legitimately not exist in the source yet.  The list is
                  the default; typing is the fallback. */}
              <Autocomplete
                freeSolo
                fullWidth
                options={sourceCols.map((c: any) => String(c.physical_name || ''))}
                loading={sourceColsLoading}
                value={editingCol.physical_name || ''}
                onInputChange={(_e, v) =>
                  setEditingCol({ ...editingCol, physical_name: v })}
                onChange={(_e, v) => {
                  const picked = sourceCols.find(
                    (c: any) => String(c.physical_name) === String(v));
                  // Picking a real column brings its TYPE with it — the
                  // author had to guess that too, and a wrong data_type
                  // is how a date column ends up compared as a string.
                  setEditingCol((prev: any) => ({
                    ...prev,
                    physical_name: String(v || ''),
                    friendly_name: prev?.friendly_name
                      || picked?.friendly_name || '',
                    data_type: picked?.data_type || prev?.data_type,
                    column_type: picked?.column_type || prev?.column_type,
                  }));
                }}
                renderOption={(props, option) => {
                  const c = sourceCols.find(
                    (x: any) => String(x.physical_name) === option);
                  return (
                    <li {...props} key={option}>
                      <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                        <span>{option}</span>
                        {c?.data_type && (
                          <Chip size="small" variant="outlined"
                                label={c.data_type} />
                        )}
                        {c?.already_mapped && (
                          <Chip size="small" color="default"
                                label="already added" />
                        )}
                      </Box>
                    </li>
                  );
                }}
                renderInput={(params) => (
                  <TextField {...params} label="Physical Name"
                    placeholder={sourceCols.length
                      ? 'Pick a column from the source'
                      : 'e.g. cust_rev_net_usd'}
                    helperText={sourceCols.length
                      ? "The source's columns — picking one fills in its type"
                      : (sourceColsMsg || undefined)} />
                )}
              />
              <TextField label="Friendly Name" fullWidth value={editingCol.friendly_name}
                         onChange={e => setEditingCol({ ...editingCol, friendly_name: e.target.value })}
                         placeholder="e.g. Net Revenue" />
              <Stack direction="row" spacing={2}>
                <FormControl fullWidth>
                  <InputLabel id="sel-datasetmanagerpage-column-type">Column Type</InputLabel>
                  <Select labelId="sel-datasetmanagerpage-column-type" value={editingCol.column_type} label="Column Type"
                          onChange={e => setEditingCol({ ...editingCol, column_type: e.target.value })}>
                    {COLUMN_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                  </Select>
                </FormControl>
                <FormControl fullWidth>
                  <InputLabel id="sel-datasetmanagerpage-data-type">Data Type</InputLabel>
                  <Select labelId="sel-datasetmanagerpage-data-type" value={editingCol.data_type} label="Data Type"
                          onChange={e => setEditingCol({ ...editingCol, data_type: e.target.value })}>
                    {DATA_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                  </Select>
                </FormControl>
              </Stack>
              {(editingCol.column_type === 'measure' || editingCol.column_type === 'kpi') && (
                <FormControl fullWidth>
                  <InputLabel id="sel-datasetmanagerpage-default-aggregation">Default Aggregation</InputLabel>
                  <Select labelId="sel-datasetmanagerpage-default-aggregation" value={editingCol.aggregation || ''} label="Default Aggregation"
                          onChange={e => setEditingCol({ ...editingCol, aggregation: e.target.value })}>
                    {AGGREGATIONS.map(a => <MenuItem key={a} value={a}>{a || '(none)'}</MenuItem>)}
                  </Select>
                </FormControl>
              )}
              <TextField label="Format Pattern" fullWidth value={editingCol.format_pattern || ''}
                         onChange={e => setEditingCol({ ...editingCol, format_pattern: e.target.value })}
                         placeholder="e.g. $#,##0.00" />
              <TextField label="Description" fullWidth multiline rows={2}
                         value={editingCol.description || ''}
                         onChange={e => setEditingCol({ ...editingCol, description: e.target.value })} />
              <TextField label="Synonyms (comma-separated)" fullWidth
                         value={(editingCol.synonyms || []).join(', ')}
                         onChange={e => setEditingCol({
                           ...editingCol,
                           synonyms: e.target.value.split(',').map((s: string) => s.trim()).filter(Boolean),
                         })}
                         placeholder="e.g. revenue, sales_amount, net_rev" />
              <FormControlLabel
                control={<Switch checked={editingCol.is_hidden || false}
                                 onChange={e => setEditingCol({ ...editingCol, is_hidden: e.target.checked })} />}
                label="Hidden from business users" />
            </Stack>
          )}
      </AppDialog>

      {/* ── Auto-Detect Preview Dialog (for existing datasets) ────────── */}
      <AppDialog open={previewDialogOpen}
        onClose={() => setPreviewDialogOpen(false)}
        size="md"
        title="Auto-Detect Columns — Preview"
        actions={<>
          <Button onClick={() => setPreviewDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={confirmAutoDetect}
                  disabled={previewDialogCols.length === 0 || previewDialogLoading}>
            Create {previewDialogCols.length} Columns
          </Button>
        </>}>
          {previewDialogLoading ? (
            <Box sx={{ py: 4, textAlign: 'center' }}><CircularProgress /><Typography sx={{ mt: 1 }}>Reading schema...</Typography></Box>
          ) : previewDialogCols.length > 0 ? (
            <>
              <Alert severity="success" sx={{ mb: 2 }}>
                Detected <strong>{previewDialogCols.length}</strong> columns:&nbsp;
                {previewDialogCols.filter(c => c.column_type === 'dimension' && c.data_type !== 'date').length} dimensions,&nbsp;
                {previewDialogCols.filter(c => c.column_type === 'measure').length} measures,&nbsp;
                {previewDialogCols.filter(c => c.data_type === 'date').length} dates
                {previewDialogCols.filter(c => c.is_hidden).length > 0 &&
                  <>,&nbsp;{previewDialogCols.filter(c => c.is_hidden).length} hidden (IDs)</>}
              </Alert>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                Review and edit column types before creating. Changes apply before columns are saved.
              </Typography>
              <TableContainer sx={{ maxHeight: 360 }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 700 }}>Physical Name</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Friendly Name</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Type</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Data Type</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Aggregation</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Hidden</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {previewDialogCols.map((col, idx) => (
                      <TableRow key={idx} sx={{ opacity: col.is_hidden ? 0.55 : 1 }}>
                        <TableCell sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>{col.physical_name}</TableCell>
                        <TableCell>
                          <TextField size="small" variant="standard" value={col.friendly_name}
                                     onChange={e => updatePreviewDialogCol(idx, 'friendly_name', e.target.value)}
                                     sx={{ width: 140 }} />
                        </TableCell>
                        <TableCell>
                          <Select inputProps={{ 'aria-label': `Column type for ${col.friendly_name || col.physical_name || 'column'}` }} size="small" variant="standard" value={col.column_type}
                                  onChange={e => {
                                    const v = e.target.value;
                                    updatePreviewDialogCol(idx, 'column_type', v);
                                    if (v === 'dimension' || v === 'detail') updatePreviewDialogCol(idx, 'aggregation', '');
                                    if ((v === 'measure' || v === 'kpi') && !col.aggregation) updatePreviewDialogCol(idx, 'aggregation', 'sum');
                                  }}>
                            {COLUMN_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                          </Select>
                        </TableCell>
                        <TableCell>
                          <Select inputProps={{ 'aria-label': `Data type for ${col.friendly_name || col.physical_name || 'column'}` }} size="small" variant="standard" value={col.data_type}
                                  onChange={e => updatePreviewDialogCol(idx, 'data_type', e.target.value)}>
                            {DATA_TYPES.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
                          </Select>
                        </TableCell>
                        <TableCell>
                          {(col.column_type === 'measure' || col.column_type === 'kpi') ? (
                            <Select inputProps={{ 'aria-label': `Aggregation for ${col.friendly_name || col.physical_name || 'column'}` }} size="small" variant="standard" value={col.aggregation || ''}
                                    onChange={e => updatePreviewDialogCol(idx, 'aggregation', e.target.value)}>
                              {AGGREGATIONS.filter(a => a).map(a => <MenuItem key={a} value={a}>{a}</MenuItem>)}
                            </Select>
                          ) : <Typography variant="body2" color="text.secondary">—</Typography>}
                        </TableCell>
                        <TableCell>
                          <Checkbox size="small" checked={!!col.is_hidden}
                                    onChange={e => updatePreviewDialogCol(idx, 'is_hidden', e.target.checked)} />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          ) : (
            <Typography color="text.secondary" align="center" sx={{ py: 4 }}>
              No columns detected from source schema.
            </Typography>
          )}
      </AppDialog>

      {/* ── Config Dialog ──────────────────────────────────────────────── */}
      <AppDialog open={configOpen}
        onClose={() => setConfigOpen(false)}
        size="sm"
        title="Semantic Layer Configuration"
        actions={<>
          <Button onClick={() => setConfigOpen(false)}>Cancel</Button>
          <Button variant="contained" startIcon={<SaveIcon />} onClick={saveConfig}>Save</Button>
        </>}>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <FormControlLabel control={<Switch checked={config.enabled ?? true}
              onChange={e => setConfig({ ...config, enabled: e.target.checked })} />}
              label="Semantic Layer Enabled" />
            <FormControlLabel control={<Switch checked={config.auto_detect_column_types ?? true}
              onChange={e => setConfig({ ...config, auto_detect_column_types: e.target.checked })} />}
              label="Auto-detect column types on create" />
            <FormControlLabel control={<Switch checked={config.cascading_prompts_enabled ?? true}
              onChange={e => setConfig({ ...config, cascading_prompts_enabled: e.target.checked })} />}
              label="Cascading prompts (report builder)" />
            <FormControlLabel control={<Switch checked={config.drill_hierarchies_enabled ?? true}
              onChange={e => setConfig({ ...config, drill_hierarchies_enabled: e.target.checked })} />}
              label="Drill hierarchies" />
            <FormControlLabel control={<Switch checked={config.aggregation_awareness_enabled ?? true}
              onChange={e => setConfig({ ...config, aggregation_awareness_enabled: e.target.checked })} />}
              label="Aggregation awareness routing" />
            <FormControlLabel control={<Switch checked={config.synonym_matching_enabled ?? true}
              onChange={e => setConfig({ ...config, synonym_matching_enabled: e.target.checked })} />}
              label="NL synonym matching" />
            <TextField label="Max Datasets" type="number" fullWidth
                       value={config.max_datasets ?? 100}
                       onChange={e => setConfig({ ...config, max_datasets: Number(e.target.value) })} />
            <TextField label="Max Columns per Dataset" type="number" fullWidth
                       value={config.max_columns_per_dataset ?? 500}
                       onChange={e => setConfig({ ...config, max_columns_per_dataset: Number(e.target.value) })} />
            <TextField label="Default Row Limit" type="number" fullWidth
                       value={config.default_row_limit ?? 10000}
                       onChange={e => setConfig({ ...config, default_row_limit: Number(e.target.value) })} />
          </Stack>
      </AppDialog>

      {/* ── Agg Cache Create/Edit Dialog ────────────────────────────────── */}
      <AppDialog open={cacheDialogOpen}
        onClose={() => setCacheDialogOpen(false)}
        size="md"
        title={cacheEditId ? 'Edit Cache Rollup' : 'Create Cache Rollup'}
        actions={<>
          <Button onClick={() => setCacheDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" startIcon={cacheEditId ? <SaveIcon /> : <AddIcon />}
                  onClick={handleCacheSave}
                  disabled={cacheSaving || !cacheName.trim() || cacheDimIds.length === 0 || cacheMeasureIds.length === 0}>
            {cacheSaving ? <CircularProgress size={20} /> : cacheEditId ? 'Save Changes' : 'Create & Build'}
          </Button>
        </>}>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField label="Rollup Name" fullWidth required value={cacheName}
                       onChange={e => setCacheName(e.target.value)}
                       placeholder="e.g. Monthly Sales Rollup" />
            <TextField label="Description" fullWidth multiline rows={2} value={cacheDesc}
                       onChange={e => setCacheDesc(e.target.value)}
                       placeholder="What this cache covers" />

            {/* Dimension columns multi-select */}
            <Typography variant="subtitle2" sx={{ mt: 1, mb: 0 }}>
              Dimensions — GROUP BY columns (pick at least 1)
            </Typography>
            <Paper variant="outlined" sx={{ maxHeight: 180, overflow: 'auto' }}>
              {dimensionCols.length > 0 ? (
                <List dense disablePadding>
                  {dimensionCols.map((col: any) => (
                    <ListItem key={col.id} dense disablePadding
                              sx={{ cursor: 'pointer' }}
                              onClick={() => setCacheDimIds(prev =>
                                prev.includes(col.id) ? prev.filter(id => id !== col.id) : [...prev, col.id]
                              )}>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <Checkbox edge="start" size="small" checked={cacheDimIds.includes(col.id)} tabIndex={-1} />
                      </ListItemIcon>
                      <ListItemText primary={col.friendly_name || col.physical_name}
                                    secondary={col.physical_name} />
                    </ListItem>
                  ))}
                </List>
              ) : (
                <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
                  No dimension columns defined. Add columns with type "dimension" first.
                </Typography>
              )}
            </Paper>

            {/* Measure columns multi-select */}
            <Typography variant="subtitle2" sx={{ mt: 1, mb: 0 }}>
              Measures — aggregated values (pick at least 1)
            </Typography>
            <Paper variant="outlined" sx={{ maxHeight: 180, overflow: 'auto' }}>
              {measureCols.length > 0 ? (
                <List dense disablePadding>
                  {measureCols.map((col: any) => (
                    <ListItem key={col.id} dense disablePadding
                              sx={{ cursor: 'pointer' }}
                              onClick={() => setCacheMeasureIds(prev =>
                                prev.includes(col.id) ? prev.filter(id => id !== col.id) : [...prev, col.id]
                              )}>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <Checkbox edge="start" size="small" checked={cacheMeasureIds.includes(col.id)} tabIndex={-1} />
                      </ListItemIcon>
                      <ListItemText primary={col.friendly_name || col.physical_name}
                                    secondary={`${col.physical_name} — ${col.aggregation || 'sum'}`} />
                    </ListItem>
                  ))}
                </List>
              ) : (
                <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
                  No measure/kpi columns defined. Add columns with type "measure" first.
                </Typography>
              )}
            </Paper>

            <Divider />

            {/* Grain + Schedule */}
            <Stack direction="row" spacing={2}>
              <FormControl fullWidth>
                <InputLabel id="sel-datasetmanagerpage-grain">Grain</InputLabel>
                <Select labelId="sel-datasetmanagerpage-grain" value={cacheGrain} label="Grain"
                        onChange={e => setCacheGrain(e.target.value)}>
                  {GRAIN_LABELS.map(g => <MenuItem key={g} value={g}>{g}</MenuItem>)}
                </Select>
              </FormControl>
              <FormControl fullWidth>
                <InputLabel id="sel-datasetmanagerpage-refresh-schedule">Refresh Schedule</InputLabel>
                <Select labelId="sel-datasetmanagerpage-refresh-schedule" value={cacheScheduleType} label="Refresh Schedule"
                        onChange={e => setCacheScheduleType(e.target.value)}>
                  {SCHEDULE_TYPES.map(s => (
                    <MenuItem key={s} value={s}>
                      {s === 'none' ? 'Manual only' : s === 'cron' ? 'Cron expression' : 'Fixed interval'}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Stack>

            {cacheScheduleType === 'cron' && (
              <TextField label="Cron Expression" fullWidth value={cacheCron}
                         onChange={e => setCacheCron(e.target.value)}
                         helperText="e.g. 0 2 * * * = daily at 2 AM" />
            )}
            {cacheScheduleType === 'interval' && (
              <TextField label="Interval (hours)" type="number" fullWidth
                         value={cacheIntervalHours}
                         onChange={e => setCacheIntervalHours(Number(e.target.value))}
                         inputProps={{ min: 1, max: 168 }}
                         helperText="Refresh every N hours" />
            )}

            {/* Pre-defined conditions */}
            {conditionsList.length > 0 && (
              <>
                <Typography variant="subtitle2">Pre-baked Conditions (optional)</Typography>
                <Paper variant="outlined" sx={{ maxHeight: 120, overflow: 'auto' }}>
                  <List dense disablePadding>
                    {conditionsList.map((cond: any) => (
                      <ListItem key={cond.id} dense disablePadding
                                sx={{ cursor: 'pointer' }}
                                onClick={() => setCacheConditionIds(prev =>
                                  prev.includes(cond.id) ? prev.filter(id => id !== cond.id) : [...prev, cond.id]
                                )}>
                        <ListItemIcon sx={{ minWidth: 36 }}>
                          <Checkbox edge="start" size="small" checked={cacheConditionIds.includes(cond.id)} tabIndex={-1} />
                        </ListItemIcon>
                        <ListItemText primary={cond.name} secondary={cond.where_clause} />
                      </ListItem>
                    ))}
                  </List>
                </Paper>
              </>
            )}

            <Divider />

            {/* Incremental refresh */}
            <FormControlLabel
              control={<Switch checked={cacheIncremental}
                               onChange={e => setCacheIncremental(e.target.checked)} />}
              label="Incremental refresh (Tableau-style)" />
            {cacheIncremental && (
              <FormControl fullWidth>
                <InputLabel id="sel-datasetmanagerpage-incremental-column">Incremental Column</InputLabel>
                <Select labelId="sel-datasetmanagerpage-incremental-column" value={cacheIncrementalCol} label="Incremental Column"
                        onChange={e => setCacheIncrementalCol(e.target.value)}>
                  {dateCols.map((col: any) => (
                    <MenuItem key={col.id} value={col.physical_name}>
                      {col.friendly_name || col.physical_name}
                    </MenuItem>
                  ))}
                  {/* Also allow dimension cols */}
                  {dimensionCols.filter((c: any) => c.data_type === 'number').map((col: any) => (
                    <MenuItem key={col.id} value={col.physical_name}>
                      {col.friendly_name || col.physical_name} (numeric)
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
          </Stack>
      </AppDialog>

      {/* ── Browse Files/Tables Dialog ──────────────────────────────────── */}
      <AppDialog open={browseOpen}
        onClose={() => setBrowseOpen(false)}
        size="sm"
        title={<>Browse {browseConnId ? connName(browseConnId) : 'Connection'} — Select Table/File</>}
        actions={<>
          <Button onClick={() => setBrowseOpen(false)}>Cancel</Button>
        </>}>
          {browseLoading ? (
            <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>
          ) : browseFiles.length === 0 ? (
            <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
              No files or tables found for this connection.
            </Typography>
          ) : (
            <List dense sx={{ maxHeight: 400, overflow: 'auto' }}>
              {browseFiles.map((f: any, i: number) => {
                const label = f.path || f.name || f.key || '';
                return (
                  <ListItem key={i} disablePadding
                            sx={{ cursor: 'pointer', '&:hover': { bgcolor: 'action.hover' } }}
                            onClick={() => selectBrowseFile(label)}>
                    <ListItemText
                      primary={f.name || label}
                      secondary={`${f.folder || ''} ${f.num_rows != null ? `— ${f.num_rows} rows` : ''} ${f.table_type || ''}`}
                    />
                  </ListItem>
                );
              })}
            </List>
          )}
      </AppDialog>

      {/* ── Phase 85A: Dataset Creation Wizard ───────────────────────── */}
      <DatasetCreationWizard
        open={wizardOpen}
        initialSource={wizardInitialSource}
        onClose={() => {
          setWizardOpen(false);
          const trip = returnTripRef.current;
          returnTripRef.current = null;
          if (trip && !wizardCreatedRef.current) {
            navigate(trip.path, { state: returnState(trip) });
          }
          wizardCreatedRef.current = false;
        }}
        onCreated={(dataset) => {
          wizardCreatedRef.current = true;
          notify(addNotification, `Dataset "${dataset.name}" created successfully`, 'success');
          loadDatasets();
          setWizardOpen(false);
          // Open the new dataset detail
          if (dataset.id) loadDetail(dataset.id);
          // ... and say what comes next: a report on it, or back to where the
          // author came from (the trip was dropped after a save).
          const trip = returnTripRef.current;
          returnTripRef.current = null;
          if (dataset.id && (canReport || trip)) setCreatedNext({ dataset, trip });
        }}
      />

      <AppDialog open={createdNext !== null}
        onClose={() => setCreatedNext(null)}
        size="xs"
        data-testid="dataset-created-next"
        title={<>Dataset "{createdNext?.dataset?.name}" is ready</>}
        actions={<>
          <Button onClick={() => setCreatedNext(null)}>Stay here</Button>
          {createdNext?.trip && (
            <Button data-testid="dataset-created-back" onClick={() => {
              const trip = createdNext.trip!;
              setCreatedNext(null);
              navigate(trip.path, { state: returnState(trip) });
            }}>Back to where you were</Button>
          )}
          {canReport && (
            <Button variant="contained" startIcon={<ReportIcon />} data-testid="dataset-created-report"
                    onClick={() => {
                      const id = createdNext!.dataset.id;
                      setCreatedNext(null);
                      navigate(newReportForDatasetPath(id));
                    }}>
              Create a report on it
            </Button>
          )}
        </>}>
          <Typography variant="body2" color="text.secondary">
            What would you like to do next?
          </Typography>
      </AppDialog>
    </Box>
  );
}
