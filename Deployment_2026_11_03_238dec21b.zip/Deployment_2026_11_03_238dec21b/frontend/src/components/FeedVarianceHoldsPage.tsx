/**
 * Variance holds -- files the row-count check HELD instead of delivering
 * (2026-10-12, owner request R2).
 *
 * A feed declaring "Row-count check: Hold the file for verification" whose
 * count moved beyond its threshold (vs the previous business date's delivery,
 * or the rolling average) is produced and KEPT; nothing goes to SFTP.  This
 * page is the release group's queue: the numbers, the file's first lines, and
 * the two decisions -- Release (the SAME file is sent through the feed's
 * delivery chain) or Reject (nothing is ever sent for it).  Who may decide is
 * the server's answer PER HOLD (`can_decide` + `decision_authority`: an admin,
 * the feed's owner, or a mapped approver group -- 2026-10-12); a row the
 * viewer may not decide shows its buttons disabled with that reason.  "Who
 * can approve" opens the mappings (components/feeds/HoldApprovers.tsx).
 *
 * Backed by GET /api/feed-variance-holds (+ /{id}/preview, /release, /reject).
 */
import { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, IconButton, Paper, Stack, Table, TableBody, TableCell, TableHead, TableRow,
  TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Refresh as RefreshIcon, Send as SendIcon, Block as RejectIcon, Visibility as InspectIcon,
  People as PeopleIcon,
} from '@mui/icons-material';
import api from '../services/api';
import RowActions from './common/RowActions';
import HoldApprovers from './feeds/HoldApprovers';
import ListPager, { type Paging } from './common/ListPager';

export interface VarianceHold {
  id: number;
  feed_config_id: number;
  feed_name: string | null;
  execution_id: string | null;
  business_date: string | null;
  actual_rows: number | null;
  baseline_rows: number | null;
  baseline_kind: string | null;
  baseline_business_date: string | null;
  delta_pct: number | null;
  direction: string | null;
  threshold_pct: number | null;
  reason: string | null;
  artifact_path: string | null;
  file_size_bytes: number | null;
  status: string;
  held_at: string | null;
  decided_by: string | null;
  decided_at: string | null;
  decision_reason: string | null;
  delivery_verdict: string | null;
  delivered_uri: string | null;
  release_error: string | null;
  /** may the CALLER decide this hold, and why (the server's rule) */
  can_decide?: boolean;
  decision_authority?: string;
}

interface HoldsResponse {
  holds: VarianceHold[];
  counts: Record<string, number>;
  release_group: string;
  can_decide: boolean;
  decision_authority: string;
  paging?: Paging;
}

const STATUS_FILTERS: { key: string; label: string; value: string }[] = [
  { key: 'open', label: 'Awaiting decision', value: 'held,release_failed,releasing' },
  { key: 'released', label: 'Released', value: 'released' },
  { key: 'rejected', label: 'Rejected', value: 'rejected' },
  { key: 'superseded', label: 'Superseded', value: 'superseded' },
  { key: 'all', label: 'All', value: '' },
];

const STATUS_COLOR: Record<string, 'warning' | 'success' | 'error' | 'default' | 'info'> = {
  held: 'warning', releasing: 'info', released: 'success', release_failed: 'error',
  rejected: 'error', superseded: 'default',
};

/** "10 vs 3 delivered on 2026-09-28 (+233.3%)" -- the comparison in words. */
export function comparisonLine(h: VarianceHold): string {
  const actual = h.actual_rows ?? '?';
  if (h.reason === 'below_absolute_floor') return `${actual} rows — below the declared floor`;
  if (h.reason === 'previous_was_zero') return `${actual} rows after a day that delivered 0`;
  const base = h.baseline_kind === 'previous_business_date'
    ? `${h.baseline_rows ?? '?'} delivered on ${h.baseline_business_date ?? '?'}`
    : `rolling average ${h.baseline_rows ?? '?'}`;
  const pct = h.delta_pct == null ? '' : ` (${h.direction === 'down' ? '-' : '+'}${h.delta_pct}%)`;
  return `${actual} vs ${base}${pct}`;
}

export default function FeedVarianceHoldsPage() {
  const [filter, setFilter] = useState('open');
  const [businessDate, setBusinessDate] = useState('');
  const [data, setData] = useState<HoldsResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [inspect, setInspect] = useState<{ hold: VarianceHold; lines?: string[]; note?: string; error?: string } | null>(null);
  const [decide, setDecide] = useState<{ hold: VarianceHold; action: 'release' | 'reject' } | null>(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [decideError, setDecideError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [showApprovers, setShowApprovers] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const status = STATUS_FILTERS.find(f => f.key === filter)?.value || undefined;
      const res = await api.varianceHolds({ status, business_date: businessDate || undefined, page, page_size: pageSize });
      setData(res as HoldsResponse);
    } catch (e: any) {
      setData(null);
      setError(e?.message || 'Could not read the variance holds');
    } finally {
      setLoading(false);
    }
  }, [filter, businessDate, page, pageSize]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [filter, businessDate]);

  const openInspect = async (hold: VarianceHold) => {
    setInspect({ hold });
    try {
      const r: any = await api.varianceHoldPreview(hold.id, 20);
      setInspect({ hold, lines: r.lines || [], note: r.binary ? r.detail : undefined });
    } catch (e: any) {
      setInspect({ hold, error: e?.message || 'Could not read the held file' });
    }
  };

  const submitDecision = async () => {
    if (!decide) return;
    setBusy(true);
    setDecideError(null);
    try {
      const fn = decide.action === 'release' ? api.releaseVarianceHold : api.rejectVarianceHold;
      const row: any = await fn(decide.hold.id, reason);
      setNotice(decide.action === 'release'
        ? (row.status === 'released'
          ? `${row.feed_name} ${row.business_date}: released and delivered to ${row.delivered_uri}`
          : `${row.feed_name} ${row.business_date}: release FAILED — ${row.release_error}`)
        : `${row.feed_name} ${row.business_date}: rejected — nothing will be sent`);
      setDecide(null);
      setReason('');
      load();
    } catch (e: any) {
      setDecideError(e?.message || 'The decision was refused');
    } finally {
      setBusy(false);
    }
  };

  const isOpen = (h: VarianceHold) => h.status === 'held' || h.status === 'release_failed';

  return (
    <Box sx={{ p: 2 }} data-testid="variance-holds-page">
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
        <Typography variant="h5" sx={{ flexGrow: 1 }}>Variance holds</Typography>
        <TextField
          type="date" size="small" label="Business date" value={businessDate}
          onChange={(e) => setBusinessDate(e.target.value)} InputLabelProps={{ shrink: true }}
          inputProps={{ 'data-testid': 'vh-business-date' }}
        />
        <Button size="small" startIcon={<PeopleIcon />} onClick={() => setShowApprovers(s => !s)}
                data-testid="vh-approvers-toggle" aria-expanded={showApprovers}>
          Who can approve
        </Button>
        <Tooltip title="Refresh">
          <IconButton aria-label="Refresh" onClick={load}><RefreshIcon /></IconButton>
        </Tooltip>
      </Stack>
      {showApprovers && <HoldApprovers />}
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Files whose row count moved beyond the feed's threshold. Nothing has been sent
        downstream; a release sends the same file, a reject sends nothing.
      </Typography>

      {data && (
        <Alert severity={data.can_decide ? 'success' : 'info'} sx={{ mb: 1 }} data-testid="vh-authority">
          {data.can_decide
            ? 'You can decide the holds marked below. '
            : "You can see these holds; deciding them is for an admin, the feed's owner or a mapped approver. "}
          <Button size="small" onClick={() => setShowApprovers(true)} sx={{ py: 0 }}>Who can approve?</Button>
        </Alert>
      )}
      {notice && <Alert severity="success" onClose={() => setNotice(null)} sx={{ mb: 1 }}
                        data-testid="vh-notice">{notice}</Alert>}
      {error && <Alert severity="error" sx={{ mb: 1 }} data-testid="vh-error">{error}</Alert>}

      <Stack direction="row" spacing={1} sx={{ mb: 1, flexWrap: 'wrap' }}>
        {STATUS_FILTERS.map(f => (
          <Chip key={f.key} label={f.label} clickable
                color={filter === f.key ? 'primary' : 'default'}
                variant={filter === f.key ? 'filled' : 'outlined'}
                onClick={() => setFilter(f.key)} data-testid={`vh-filter-${f.key}`} />
        ))}
      </Stack>

      <Paper variant="outlined">
        {loading && !data ? (
          <Box sx={{ p: 3, textAlign: 'center' }}><CircularProgress size={24} /></Box>
        ) : (
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Feed</TableCell>
                <TableCell>Business date</TableCell>
                <TableCell>Rows</TableCell>
                <TableCell>Threshold</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Decision</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {(data?.holds || []).length === 0 && !error && (
                <TableRow><TableCell colSpan={7}>
                  <Typography variant="body2" color="text.secondary" data-testid="vh-empty">
                    No held files for this filter.
                  </Typography>
                </TableCell></TableRow>
              )}
              {(data?.holds || []).map(h => {
                const why = !h.can_decide ? (h.decision_authority || 'You may not decide this hold')
                  : !isOpen(h) ? `This file is ${h.status}` : undefined;
                return (
                  <TableRow key={h.id} data-testid="vh-row">
                    <TableCell>
                      {h.feed_name}
                      {h.can_decide && h.decision_authority && (
                        <Typography variant="caption" color="text.secondary" component="div" data-testid="vh-why-you">
                          you decide: {h.decision_authority}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>{h.business_date}</TableCell>
                    <TableCell data-testid="vh-comparison">{comparisonLine(h)}</TableCell>
                    <TableCell>{h.threshold_pct == null ? '-' : `${h.threshold_pct}%`}</TableCell>
                    <TableCell>
                      <Chip size="small" label={h.status} color={STATUS_COLOR[h.status] || 'default'}
                            data-testid="vh-status" />
                    </TableCell>
                    <TableCell>
                      {h.decided_by ? (
                        <Typography variant="caption" data-testid="vh-decision">
                          {h.decided_by}: {h.decision_reason}
                          {h.delivered_uri ? ` -> ${h.delivered_uri}` : ''}
                          {h.release_error ? ` (failed: ${h.release_error})` : ''}
                        </Typography>
                      ) : '-'}
                    </TableCell>
                    <TableCell align="right">
                      <RowActions
                        rowName={`${h.feed_name} ${h.business_date}`}
                        primary={[
                          { label: 'Inspect file', icon: <InspectIcon />, onClick: () => openInspect(h) },
                          { label: 'Release', icon: <SendIcon />, disabled: !!why, disabledReason: why,
                            onClick: () => { setReason(''); setDecideError(null); setDecide({ hold: h, action: 'release' }); } },
                        ]}
                        more={[
                          { label: 'Reject', icon: <RejectIcon />, danger: true, disabled: !!why,
                            disabledReason: why, description: 'Never send this file',
                            onClick: () => { setReason(''); setDecideError(null); setDecide({ hold: h, action: 'reject' }); } },
                        ]}
                      />
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
        <ListPager paging={data?.paging} onPage={setPage} onPageSize={setPageSize} testid="holds-pager" />
      </Paper>

      <AppDialog open={!!inspect}
        onClose={() => setInspect(null)}
        size="md"
        title={<>Held file — {inspect?.hold.feed_name} {inspect?.hold.business_date}</>}
        actions={<><Button onClick={() => setInspect(null)}>Close</Button>
        </>}>
          <Typography variant="body2" sx={{ mb: 1 }}>{inspect && comparisonLine(inspect.hold)}</Typography>
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 1 }}>
            {inspect?.hold.artifact_path} ({inspect?.hold.file_size_bytes ?? '?'} bytes)
          </Typography>
          {inspect?.error && <Alert severity="error">{inspect.error}</Alert>}
          {inspect?.note && <Alert severity="info">{inspect.note}</Alert>}
          {inspect && !inspect.lines && !inspect.error && <CircularProgress size={20} />}
          {inspect?.lines && (
            <Box component="pre" data-testid="vh-preview"
                 sx={{ fontSize: 12, bgcolor: 'action.hover', p: 1, overflow: 'auto', maxHeight: 400 }}>
              {inspect.lines.join('\n')}
            </Box>
          )}
      </AppDialog>

      <AppDialog open={!!decide}
        onClose={() => !busy && setDecide(null)}
        size="sm"
        title={<>{decide?.action === 'release' ? 'Release' : 'Reject'} — {decide?.hold.feed_name} {decide?.hold.business_date}</>}
        actions={<>
          <Button onClick={() => setDecide(null)} disabled={busy}>Cancel</Button>
          <Button variant="contained" color={decide?.action === 'release' ? 'primary' : 'error'}
                  onClick={submitDecision} disabled={busy || reason.trim().length < 10}
                  data-testid="vh-confirm">
            {busy ? 'Working...' : decide?.action === 'release' ? 'Release and send' : 'Reject'}
          </Button>
        </>}>
          <Typography variant="body2" sx={{ mb: 1 }}>{decide && comparisonLine(decide.hold)}</Typography>
          <Alert severity={decide?.action === 'release' ? 'warning' : 'info'} sx={{ mb: 1 }}>
            {decide?.action === 'release'
              ? 'The held file (the same bytes) is sent now through the feed\'s delivery chain.'
              : 'Nothing will ever be sent for this file. A corrected file comes from a rerun, which is checked again.'}
          </Alert>
          <TextField
            label="Reason (recorded)" fullWidth multiline minRows={2} value={reason}
            onChange={(e) => setReason(e.target.value)}
            helperText="At least 10 characters — why this file may (or may not) go"
            inputProps={{ 'data-testid': 'vh-reason' }}
          />
          {decideError && <Alert severity="error" sx={{ mt: 1 }} data-testid="vh-decide-error">{decideError}</Alert>}
      </AppDialog>
    </Box>
  );
}
