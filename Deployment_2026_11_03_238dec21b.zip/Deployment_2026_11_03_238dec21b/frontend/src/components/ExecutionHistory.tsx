import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Chip, CircularProgress, ToggleButtonGroup, ToggleButton,
  Dialog, Alert, Tooltip,
  TablePagination, TextField, InputAdornment, IconButton,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Refresh as RefreshIcon,
  Cancel as CancelIcon,
  Info as InfoIcon,
  TableChart as OpenIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { useWebSocket } from '../context/WebSocketContext';
import api from '../services/api';
import DataGridViewer from './DataGridViewer';
import EngineChip from './common/EngineChip';

const fmtDate = (s) => s ? new Date(s).toLocaleString() : '-';
const fmtDuration = (start, end) => {
  if (!start) return '-';
  const ms = (end ? new Date(end) : new Date()).getTime() - new Date(start).getTime();
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60000).toFixed(1)}m`;
};
const fmtSize = (bytes) => {
  if (!bytes) return '-';
  const k = 1024, sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return (bytes / Math.pow(k, i)).toFixed(1) + ' ' + sizes[i];
};
const isRunning = (status) => status === 'pending' || status === 'processing';

const statusProps = {
  pending:    { label: 'Pending',   color: 'warning' },
  processing: { label: 'Running',  color: 'info' },
  completed:  { label: 'Completed', color: 'success' },
  failed:     { label: 'Failed',    color: 'error' },
  cancelled:  { label: 'Cancelled', color: 'default' },
};

const FILTERS = ['', 'pending', 'processing', 'completed', 'failed', 'cancelled'];
const LABELS  = ['All', 'Pending', 'Running', 'Completed', 'Failed', 'Cancelled'];
const ROWS_PER_PAGE_OPTIONS = [25, 50, 100, 200];

const ExecutionHistory = () => {
  const [executions, setExecutions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [selectedExecution, setSelected] = useState(null);
  const [killing, setKilling] = useState({});
  // FB-49 (2026-09-20) -- this page rendered 50 rows and offered no way to
  // reach row 51.  The 50 was not even a visible choice: the API CLIENT
  // defaulted limit=50 and nothing on screen said the history was cut.
  // Paging is SERVER-side here, unlike /downloads: the list is not fully
  // loaded, so a client-side slice would have been a pager over a lie.
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  //: a WebSocket execution message refetches; so does a page change.  The
  //  sequence guard drops a slow earlier answer that would otherwise land
  //  on top of a newer page (the same stale-response trap ReportsListPage
  //  has a reqSeqRef for).
  const reqSeqRef = useRef(0);
  // Phase 142 — click-to-open: reopen a past execution's cached result
  // in DataGridViewer without re-running the query.  Saves the user
  // from waiting again when they just want to re-look at their data.
  const [openedResult, setOpenedResult] = useState<any>(null);
  const { addNotification } = useNotifications();
  const { addListener } = useWebSocket();

  // debounce the search box -- 300ms, the same as the reports list
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 300);
    return () => clearTimeout(t);
  }, [search]);

  // a narrowed list has fewer pages; staying on page 7 of 2 shows nothing
  useEffect(() => { setPage(0); }, [filter, debouncedSearch, rowsPerPage]);

  const loadExecutions = useCallback(async () => {
    const seq = ++reqSeqRef.current;
    try {
      setLoading(true);
      const data = await api.listExecutions({
        limit: rowsPerPage,
        offset: page * rowsPerPage,
        status: filter || undefined,
        q: debouncedSearch || undefined,
      });
      if (seq !== reqSeqRef.current) return;      // a newer request won
      setExecutions(data.items || []);
      setTotal(data.total ?? 0);
    } catch (_err) {
      if (seq !== reqSeqRef.current) return;
      const error = _err as Error;
      // "could not read" and "has none" lead to opposite investigations:
      // the list is cleared AND the failure is said, never an empty table
      // that reads as "no executions".
      setExecutions([]);
      setTotal(0);
      addNotification({ type: 'error', title: 'Error Loading Executions', message: error.message });
    } finally {
      if (seq === reqSeqRef.current) setLoading(false);
    }
  }, [filter, page, rowsPerPage, debouncedSearch, addNotification]);

  useEffect(() => {
    loadExecutions();
    const remove = addListener(msg => {
      if (msg.type?.includes('execution')) loadExecutions();
    });
    return () => remove();
  }, [loadExecutions, addListener]);

  const viewDetails = async (executionId) => {
    try {
      const execution = await api.getExecution(executionId);
      setSelected(execution);
    } catch (_err) {
      const error = _err as Error;
      addNotification({ type: 'error', title: 'Error', message: error.message });
    }
  };

  const killExecution = async (executionId) => {
    setKilling(prev => ({ ...prev, [executionId]: true }));
    try {
      await api.cancelExecution(executionId);
      addNotification({ type: 'success', title: 'Cancelled', message: `Execution ${executionId.substring(0, 8)} cancelled` });
      loadExecutions();
      if (selectedExecution?.execution_id === executionId) setSelected(null);
    } catch (_err) {
      const error = _err as Error;
      addNotification({ type: 'error', title: 'Cancel Failed', message: error.message });
    } finally {
      setKilling(prev => ({ ...prev, [executionId]: false }));
    }
  };

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box>
          <Typography variant="h5">Execution History</Typography>
          <Typography variant="subtitle2" color="text.secondary">Monitor and manage query executions</Typography>
        </Box>
        <Button variant="outlined" startIcon={<RefreshIcon />} onClick={loadExecutions}>Refresh</Button>
      </Box>

      {/* Filters + search (FB-49) */}
      <Box sx={{ display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap', mb: 3 }}>
        <ToggleButtonGroup
          value={filter}
          exclusive
          onChange={(_, val) => val !== null && setFilter(val)}
          size="small"
        >
          {FILTERS.map((f, i) => (
            <ToggleButton key={f} value={f}>{LABELS[i]}</ToggleButton>
          ))}
        </ToggleButtonGroup>
        <TextField
          size="small"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search id, user or error"
          inputProps={{ 'aria-label': 'Search executions' }}
          sx={{ minWidth: 280 }}
          helperText="Matches execution id, who ran it, and error text"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment>
            ),
            endAdornment: search ? (
              <InputAdornment position="end">
                <IconButton size="small" aria-label="Clear search" onClick={() => setSearch('')}>
                  <ClearIcon fontSize="small" />
                </IconButton>
              </InputAdornment>
            ) : null,
          }}
        />
      </Box>

      {/* Content */}
      {loading ? (
        <Box sx={{ textAlign: 'center', py: 8 }}><CircularProgress /></Box>
      ) : executions.length === 0 ? (
        <Paper sx={{ p: 6, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>No executions found</Typography>
          <Typography color="text.secondary">
            {(debouncedSearch || filter)
              ? 'No execution matches this search or status filter.'
              : 'Execute queries in the Query Builder or Reports page'}
          </Typography>
        </Paper>
      ) : (
        <TableContainer component={Paper}>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ '& th': { fontWeight: 600, bgcolor: 'grey.50' } }}>
                <TableCell>ID</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Started</TableCell>
                <TableCell>Duration</TableCell>
                <TableCell>Engine</TableCell>
                <TableCell align="right">Rows</TableCell>
                <TableCell align="right">Size</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {executions.map(ex => {
                const sp = statusProps[ex.status] || statusProps.pending;
                return (
                  <TableRow key={ex.execution_id} hover
                    sx={isRunning(ex.status) ? { backgroundColor: 'rgba(37, 99, 235, 0.04)' } : {}}
                  >
                    <TableCell>
                      <Typography variant="body2" fontFamily="monospace" fontSize="0.8125rem">
                        {ex.execution_id.substring(0, 8)}...
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip label={sp.label} color={sp.color} size="small" variant="outlined" />
                    </TableCell>
                    <TableCell><Typography variant="body2">{fmtDate(ex.started_at)}</Typography></TableCell>
                    <TableCell><Typography variant="body2">{fmtDuration(ex.started_at, ex.completed_at)}</Typography></TableCell>
                    <TableCell>
                      {/* 2026-09-27 -- which engine answered; a row that
                          recorded none (older rows, a lane that stamps
                          nothing) says so rather than defaulting */}
                      {ex.status === 'completed'
                        ? <EngineChip engine={ex.engine} label={ex.engine_label} showUnknown />
                        : <EngineChip engine={ex.engine} label={ex.engine_label} />}
                    </TableCell>
                    <TableCell align="right"><Typography variant="body2">{ex.total_rows?.toLocaleString() || '-'}</Typography></TableCell>
                    <TableCell align="right"><Typography variant="body2">{fmtSize(ex.file_size_bytes)}</Typography></TableCell>
                    <TableCell align="right">
                      {ex.status === 'completed' && ex.total_rows > 0 && (
                        <Tooltip title="Open cached result without re-running">
                          <Button
                            size="small"
                            startIcon={<OpenIcon />}
                            onClick={() => setOpenedResult({
                              executionId: ex.execution_id,
                              totalRows: ex.total_rows,
                              startedAt: ex.started_at,
                            })}
                          >
                            Open
                          </Button>
                        </Tooltip>
                      )}
                      <Button size="small" startIcon={<InfoIcon />} onClick={() => viewDetails(ex.execution_id)}>
                        Details
                      </Button>
                      {isRunning(ex.status) && (
                        <Button
                          size="small"
                          color="error"
                          startIcon={killing[ex.execution_id] ? <CircularProgress size={14} /> : <CancelIcon />}
                          onClick={() => killExecution(ex.execution_id)}
                          disabled={killing[ex.execution_id]}
                        >
                          Kill
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <TablePagination
            component="div"
            count={total}
            page={page}
            onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => setRowsPerPage(parseInt(e.target.value, 10))}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
          />
        </TableContainer>
      )}

      {/* Details Dialog */}
      <AppDialog open={!!selectedExecution} onClose={() => setSelected(null)} size="md"
        title="Execution Details"
        titleExtra={selectedExecution && (
              <Chip
                label={(statusProps[selectedExecution.status] || statusProps.pending).label}
                color={(statusProps[selectedExecution.status] || statusProps.pending).color}
                size="small"
              />
        )}
        secondaryActions={selectedExecution && isRunning(selectedExecution.status) && (
                <Button color="error" onClick={() => killExecution(selectedExecution.execution_id)}>
                  Kill Execution
                </Button>
        )}
        actions={<Button onClick={() => setSelected(null)}>Close</Button>}>
        {selectedExecution && (
          <>
              {selectedExecution.error_message && (
                <Alert severity="error" sx={{ mb: 2 }}>{selectedExecution.error_message}</Alert>
              )}
              <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5, mb: 3 }}>
                {[
                  ['Execution ID', selectedExecution.execution_id],
                  ['Started', fmtDate(selectedExecution.started_at)],
                  ['Completed', fmtDate(selectedExecution.completed_at)],
                  ['Duration', fmtDuration(selectedExecution.started_at, selectedExecution.completed_at)],
                  ['Total Rows', selectedExecution.total_rows?.toLocaleString() || '0'],
                  ['File Size', fmtSize(selectedExecution.file_size_bytes)],
                  ['Query ID', selectedExecution.query_id || '-'],
                ].map(([k, v]) => (
                  <Box key={k}>
                    <Typography variant="caption" color="text.secondary">{k}</Typography>
                    <Typography variant="body2" fontWeight={500} sx={{ fontFamily: k === 'Execution ID' ? 'monospace' : 'inherit' }}>
                      {v}
                    </Typography>
                  </Box>
                ))}
              </Box>
              <Typography variant="subtitle2" gutterBottom>Query Configuration</Typography>
              <Paper variant="outlined" sx={{ p: 2, bgcolor: 'grey.50', overflow: 'auto', maxHeight: 300 }}>
                <pre style={{ margin: 0, fontSize: '0.8125rem', fontFamily: 'monospace' }}>
                  {JSON.stringify(selectedExecution.query_config, null, 2)}
                </pre>
              </Paper>
          </>
        )}
      </AppDialog>

      {/* Phase 142 — click-to-open: reopen cached result without re-running */}
      <AppDialog open={!!openedResult}
        onClose={() => setOpenedResult(null)}
        size={false}
        paperSx={{ width: '90vw', height: '85vh' }}
        title={<>
          Result viewer
          {openedResult && (
            <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
              executed {fmtDate(openedResult.startedAt)} — {openedResult.totalRows?.toLocaleString()} rows
            </Typography>
          )}
        </>}
        contentSx={{ p: 0, display: 'flex', flexDirection: 'column' }}
        actions={<>
          <Button onClick={() => setOpenedResult(null)}>Close</Button>
        </>}>
          {openedResult && (
            <DataGridViewer
              executionId={openedResult.executionId}
              embedded={true}
            />
          )}
      </AppDialog>
    </Box>
  );
};

export default ExecutionHistory;
