/**
 * FeedTestAsFeedDialog -- TEST AS FEED (2026-10-24).
 *
 * Shows, BEFORE the feed runs, what it would deliver under its OWN principal
 * -- the owner group's data entitlement when entitlement_mode is apply --
 * for a chosen business date: each side's row count and first N rows, the
 * SQL as the run would execute it, and which entitlement dimensions /
 * values applied for which principal, or WHY none (off / no active
 * dimension / no governed table / engine off), or that it could not be
 * determined (an unreadable store is never shown as "not filtered").
 *
 * Every word comes from the server (core/feed/test_as_feed.py, which calls
 * the run's own functions); nothing is inferred here.  Nothing is delivered
 * and no run is created -- the dialog says so.  The date defaults to the
 * next task's (GET .../test-as-feed/dates) and the preview runs on a click,
 * never on open.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Collapse, Divider, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  FactCheck as TestIcon, ExpandMore as ExpandIcon, ExpandLess as CollapseIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type { TestAsFeedDates, TestAsFeedResult, TestAsFeedSide } from '../services/api/feeds';

export interface TestAsFeedRef { id: number; name?: string | null }

interface Props {
  feed: TestAsFeedRef | null;
  onClose: () => void;
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/** The server's one-word verdict, in plain words and a colour. */
export const entitlementWords = (state: string | null | undefined): { label: string; color: 'success' | 'warning' | 'error' | 'info' | 'default' } => {
  switch (state) {
    case 'applied': return { label: 'Filtered by the owner group’s entitlement', color: 'success' };
    case 'off': return { label: 'Not filtered — data entitlement is off for this feed', color: 'default' };
    case 'no_active_dimension': return { label: 'Not filtered — no active entitlement dimension exists', color: 'info' };
    case 'not_governed': return { label: 'Not filtered — no table it reads carries an entitled column', color: 'info' };
    case 'engine_off': return { label: 'NOT FILTERED — row security is not enforcing on this pod', color: 'warning' };
    case 'refused': return { label: 'The run would be REFUSED', color: 'error' };
    case 'could_not_be_determined': return { label: 'Could not be determined — the run would be refused', color: 'warning' };
    default: return { label: state ? String(state).split('_').join(' ') : 'unknown', color: 'default' };
  }
};

const valuesText = (v: unknown): string => {
  if (Array.isArray(v)) return v.length ? v.join(', ') : 'none';
  if (v === null || v === undefined) return 'none';
  return String(v);
};

const SideBlock: React.FC<{ side: TestAsFeedSide; single: boolean }> = ({ side, single }) => {
  const [sqlOpen, setSqlOpen] = useState(false);
  const title = single ? 'The query' : `${side.side === 'primary' ? 'Primary' : 'Secondary'} side`;
  const countWords = side.row_count === null || side.row_count === undefined
    ? (side.truncated ? `more than ${side.rows_shown ?? 0} rows (count unavailable)` : 'row count unknown')
    : `${side.row_count.toLocaleString()} row${side.row_count === 1 ? '' : 's'}${side.truncated ? ` — first ${side.rows_shown} shown` : ''}`;
  return (
    <Box data-testid={`taf-side-${side.side}`} sx={{ border: 1, borderColor: 'divider', borderRadius: 1, p: 1.5 }}>
      <Stack direction="row" alignItems="center" spacing={1} flexWrap="wrap">
        <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{title}</Typography>
        {side.connection_name && (
          <Chip size="small" variant="outlined"
            label={`${side.connection_name}${side.connection_type ? ` (${side.connection_type})` : ''}`} />
        )}
        {!side.error && (
          <Chip size="small" color="primary" variant="outlined" label={countWords}
            data-testid={`taf-count-${side.side}`} />
        )}
        {typeof side.elapsed_ms === 'number' && (
          <Typography variant="caption" color="text.secondary">{side.elapsed_ms} ms</Typography>
        )}
      </Stack>
      {side.error && (
        <Alert severity="error" sx={{ mt: 1 }} data-testid={`taf-error-${side.side}`}>{side.error}</Alert>
      )}
      {(side.notes || []).map((n, i) => (
        <Alert key={i} severity="info" sx={{ mt: 1, py: 0 }}>{n}</Alert>
      ))}
      {side.row_security?.entitlements?.length ? (
        <Stack direction="row" spacing={0.5} flexWrap="wrap" sx={{ mt: 1 }} useFlexGap>
          {side.row_security.entitlements.map((e, i) => (
            <Tooltip key={i} title={`table ${e.table}; columns ${(e.columns || []).join(', ')}; principal ${(e.principals || []).join(', ')}`}>
              <Chip size="small" color="success" variant="outlined"
                label={`${e.dimension} in (${valuesText(e.values)})`} />
            </Tooltip>
          ))}
        </Stack>
      ) : null}
      {side.row_security && side.row_security.examined && !(side.row_security.entitlements?.length) && !side.error && (
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
          No entitlement filter on this side
          {side.row_security.tables?.some(t => t.row_policies?.length)
            ? ` (stored row policies: ${side.row_security.tables.flatMap(t => t.row_policies || []).join(', ')})` : ''}.
        </Typography>
      )}
      {side.sql_as_executed && (
        <Box sx={{ mt: 1 }}>
          <Button size="small" onClick={() => setSqlOpen(o => !o)}
            startIcon={sqlOpen ? <CollapseIcon /> : <ExpandIcon />} data-testid={`taf-sql-toggle-${side.side}`}>
            SQL as the run would execute it
          </Button>
          <Collapse in={sqlOpen}>
            <Box component="pre" data-testid={`taf-sql-${side.side}`}
              sx={{ fontFamily: 'monospace', fontSize: 12, whiteSpace: 'pre-wrap', m: 0, p: 1,
                    bgcolor: 'action.hover', borderRadius: 1, maxHeight: 240, overflow: 'auto' }}>
              {side.sql_as_executed}
            </Box>
          </Collapse>
        </Box>
      )}
      {side.columns && side.rows && (
        <Box sx={{ mt: 1, overflow: 'auto', maxHeight: 320 }}>
          <Table size="small" data-testid={`taf-rows-${side.side}`}>
            <TableHead>
              <TableRow>
                {side.columns.map(c => (
                  <TableCell key={c.name} sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>
                    {c.name}<Typography component="span" variant="caption" color="text.secondary"> {c.type}</Typography>
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {side.rows.length === 0 && (
                <TableRow><TableCell colSpan={Math.max(1, side.columns.length)}>
                  <Typography variant="body2" color="text.secondary">No rows for this date under this principal.</Typography>
                </TableCell></TableRow>
              )}
              {side.rows.map((r, i) => (
                <TableRow key={i}>
                  {r.map((cell, j) => (
                    <TableCell key={j} sx={{ whiteSpace: 'nowrap' }}>
                      {cell === null || cell === undefined
                        ? <Typography component="span" variant="caption" color="text.disabled">NULL</Typography>
                        : String(cell)}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      )}
    </Box>
  );
};

const FeedTestAsFeedDialog: React.FC<Props> = ({ feed, onClose }) => {
  const [dates, setDates] = useState<TestAsFeedDates | null>(null);
  const [datesError, setDatesError] = useState<string | null>(null);
  const [businessDate, setBusinessDate] = useState('');
  const [limit, setLimit] = useState<string>('');
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<TestAsFeedResult | null>(null);

  // the default date comes from the server (the next task's); reset per feed
  useEffect(() => {
    if (!feed) return;
    let cancelled = false;
    setDates(null); setDatesError(null); setResult(null); setError(null); setLimit('');
    api.getTestAsFeedDates(feed.id)
      .then(d => { if (!cancelled) { setDates(d); setBusinessDate(d.default || ''); } })
      .catch(e => { if (!cancelled) { setDatesError(e?.message || String(e)); setBusinessDate(new Date().toISOString().slice(0, 10)); } });
    return () => { cancelled = true; };
  }, [feed?.id]);  // eslint-disable-line react-hooks/exhaustive-deps

  const run = useCallback(async () => {
    if (!feed) return;
    setRunning(true); setError(null); setResult(null);
    try {
      const body: { business_date?: string; limit?: number } = {};
      if (DATE_RE.test(businessDate)) body.business_date = businessDate;
      const n = parseInt(limit, 10);
      if (Number.isFinite(n) && n > 0) body.limit = n;
      setResult(await api.testAsFeed(feed.id, body));
    } catch (e: any) {
      setError(e?.detail || e?.message || String(e));
    } finally {
      setRunning(false);
    }
  }, [feed, businessDate, limit]);

  const ent = result?.entitlement;
  const words = useMemo(() => entitlementWords(ent?.state), [ent?.state]);
  const single = (result?.sides?.length ?? 0) <= 1;
  const groupName = result?.principal?.owner_group?.name;

  return (
    <AppDialog open={feed != null}
      onClose={running ? undefined : onClose}
      size="lg"
      title={<>
        <TestIcon fontSize="small" /> Test as feed: {feed?.name || ''}
      </>}
      actions={<>
        <Button onClick={onClose} disabled={running}>Close</Button>
      </>}>
        <Stack spacing={2}>
          <Typography variant="body2" color="text.secondary">
            Runs this feed&apos;s source query as the FEED would &mdash; its own principal, its owner
            group&apos;s data entitlement when it is on, its parameters for the chosen business date &mdash;
            bounded, and shows what the run would deliver. Nothing is delivered and no run is created.
          </Typography>
          <Stack direction="row" spacing={2} alignItems="flex-start" flexWrap="wrap" useFlexGap>
            <TextField
              label="Business date" type="date" size="small" value={businessDate}
              onChange={e => setBusinessDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              inputProps={{ 'data-testid': 'taf-date' }}
              helperText={dates
                ? (dates.source === 'next_task' && dates.next
                    ? `Default: the next task's date (runs on ${dates.next.run_day}).${dates.current ? ` Today's task is for ${dates.current.business_date}.` : ''}`
                    : dates.source === 'current' ? 'Default: the date today’s task is for.'
                    : 'Default: today (this feed has no date rule).')
                : datesError ? `The dates could not be read (${datesError}); today is offered.` : 'Reading the next task’s date…'}
            />
            <TextField
              label="Rows to show" type="number" size="small" value={limit}
              onChange={e => setLimit(e.target.value)}
              inputProps={{ min: 1, max: 500, 'data-testid': 'taf-limit' }}
              helperText="Blank = the deployment's default (100); at most 500"
              sx={{ width: 170 }}
            />
            <Button variant="contained" onClick={() => void run()} disabled={running || !feed}
              startIcon={running ? <CircularProgress size={14} /> : <TestIcon />} data-testid="taf-run">
              {running ? 'Running…' : 'Run as the feed'}
            </Button>
          </Stack>

          {error && <Alert severity="error" data-testid="taf-error">{error}</Alert>}

          {result && (
            <>
              <Divider />
              <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
                <Chip size="small" label={`Business date ${result.business_date.value}`} />
                <Chip size="small" variant="outlined"
                  label={result.business_date.source === 'requested' ? 'the date you chose'
                    : result.business_date.source === 'next_task' ? `the next task's date (runs on ${result.business_date.run_day})`
                    : result.business_date.source === 'current' ? 'today’s task’s date' : 'today'} />
                <Chip size="small" variant="outlined" data-testid="taf-principal"
                  label={`Principal: ${result.principal.username}${groupName ? ` · owner group ${groupName}` : ' · no owner group'}`} />
                <Chip size="small" variant="outlined" label={`entitlement_mode ${result.entitlement_mode}`} />
              </Stack>

              <Alert severity={words.color === 'default' ? 'info' : words.color} data-testid="taf-entitlement"
                icon={false}>
                <Typography variant="subtitle2" sx={{ fontWeight: 700 }} data-testid="taf-entitlement-state">
                  {words.label}
                </Typography>
                {ent?.reason && <Typography variant="body2">{ent.reason}</Typography>}
                {ent?.state === 'applied' && ent.dimensions?.length ? (
                  <Stack spacing={0.5} sx={{ mt: 1 }} data-testid="taf-dimensions">
                    {ent.dimensions.map((d, i) => (
                      <Typography key={i} variant="body2">
                        <strong>{d.dimension}</strong> on {d.table}
                        {d.columns?.length ? ` (${d.columns.join(', ')})` : ''}: values <strong>{valuesText(d.values)}</strong>
                        {d.principals?.length ? ` — for ${d.principals.join(', ')}` : ''}
                      </Typography>
                    ))}
                  </Stack>
                ) : null}
                {ent?.holds && ent.holds.length > 0 && (
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
                    The owner group holds: {ent.holds.map(h => `${h.dimension} = ${valuesText(h.values)}`).join('; ')}
                  </Typography>
                )}
                {ent?.holds_unavailable && (
                  <Typography variant="caption" sx={{ display: 'block', mt: 1 }}>
                    What the owner group holds could not be read: {ent.holds_unavailable}
                  </Typography>
                )}
              </Alert>

              {result.cross_source && (
                <Typography variant="caption" color="text.secondary">
                  Two sides, each read on its own connection and secured against it; the run merges them
                  by column name{result.combine_mode ? ` (${result.combine_mode})` : ''}.
                </Typography>
              )}
              {result.sides.map(s => <SideBlock key={s.side} side={s} single={single} />)}

              {Object.keys(result.params || {}).length > 0 && (
                <Box>
                  <Typography variant="caption" color="text.secondary">Parameters resolved as the run would</Typography>
                  <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap sx={{ mt: 0.5 }} data-testid="taf-params">
                    {Object.entries(result.params).slice(0, 40).map(([k, v]) => (
                      <Chip key={k} size="small" variant="outlined" label={`${k} = ${v === null ? 'NULL' : String(v)}`} />
                    ))}
                  </Stack>
                </Box>
              )}
              <Typography variant="caption" color="text.secondary" data-testid="taf-note">{result.note}</Typography>
            </>
          )}
        </Stack>
    </AppDialog>
  );
};

export default FeedTestAsFeedDialog;
