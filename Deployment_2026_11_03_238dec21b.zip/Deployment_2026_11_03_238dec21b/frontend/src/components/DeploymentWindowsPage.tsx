/**
 * DeploymentWindowsPage — change windows that block run STARTS
 * (2026-09-03; backend GET /api/deployment-windows, admin POST/DELETE,
 * core/feed/deployment_window.py, FR-OPS-04).
 *
 * A window blocks new starts only — runs in flight are never touched —
 * and a blocked start elsewhere in the product returns a 409 naming
 * the window, its reason and end time.  This page is where an operator
 * sees WHY a run will not start, and where an admin declares/removes
 * windows.  Readable by every authenticated user by design.
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, MenuItem, Paper, Stack, Table, TableBody,
  TableCell, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Add as AddIcon, Delete as DeleteIcon, EventBusy as WindowIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type {
  DeploymentWindowRow, DeploymentWindowsResponse,
} from '../services/api/feedOperations';
import { useAuth } from '../context/AuthContext';
import ListPager, { clientPage } from './common/ListPager';

type LoadState =
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; data: DeploymentWindowsResponse };

const scopeText = (w: DeploymentWindowRow): string =>
  w.scope === 'global' ? 'platform-wide'
    : w.scope === 'group' ? `feed group ${w.scope_id}`
      : `feed ${w.scope_id}`;

const DeploymentWindowsPage: React.FC = () => {
  const { user } = useAuth();
  const isAdmin = !!user?.is_admin;

  const [load, setLoad] = useState<LoadState>({ phase: 'loading' });

  // create form
  const [createOpen, setCreateOpen] = useState(false);
  const [scope, setScope] = useState<'global' | 'group' | 'feed'>('global');
  const [scopeId, setScopeId] = useState('');
  const [startsAt, setStartsAt] = useState('');
  const [endsAt, setEndsAt] = useState('');
  const [reason, setReason] = useState('');
  const [createBusy, setCreateBusy] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // delete flow
  const [deleting, setDeleting] = useState<DeploymentWindowRow | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const loadWindows = async () => {
    setLoad({ phase: 'loading' });
    try {
      const data = await api.listDeploymentWindows();
      setLoad({ phase: 'ready', data });
    } catch (e: any) {
      setLoad({ phase: 'error', message: e?.message || String(e) });
    }
  };

  useEffect(() => { void loadWindows(); }, []);

  const data = load.phase === 'ready' ? load.data : null;
  const active = (data?.active_or_upcoming ?? [])
    .filter(w => w.status === 'active');
  const shown = clientPage(data?.windows ?? [], page, pageSize);

  const doCreate = async () => {
    setCreateBusy(true);
    setCreateError(null);
    try {
      await api.createDeploymentWindow({
        scope,
        ...(scope !== 'global' && scopeId.trim()
          ? { scope_id: Number(scopeId) } : {}),
        starts_at: startsAt,
        ends_at: endsAt,
        reason: reason.trim(),
      });
      setCreateOpen(false);
      setScope('global'); setScopeId('');
      setStartsAt(''); setEndsAt(''); setReason('');
      void loadWindows();
    } catch (e: any) {
      setCreateError(e?.message || String(e));
    } finally {
      setCreateBusy(false);
    }
  };

  const doDelete = async () => {
    if (!deleting) return;
    setDeleteBusy(true);
    setDeleteError(null);
    try {
      await api.deleteDeploymentWindow(deleting.id);
      setDeleting(null);
      void loadWindows();
    } catch (e: any) {
      setDeleteError(e?.message || String(e));
    } finally {
      setDeleteBusy(false);
    }
  };

  const createBlocked = !startsAt || !endsAt || !reason.trim()
    || (scope !== 'global' && !scopeId.trim());

  return (
    <Box sx={{ p: 2 }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <WindowIcon color="primary" />
        <Typography variant="h5" sx={{ fontWeight: 700 }}>
          Deployment Windows
        </Typography>
        <Box sx={{ flex: 1 }} />
        <Button size="small" startIcon={<RefreshIcon />}
                onClick={() => void loadWindows()}>
          Refresh
        </Button>
        {isAdmin && (
          <Button variant="contained" size="small" startIcon={<AddIcon />}
                  onClick={() => { setCreateError(null); setCreateOpen(true); }}
                  data-testid="window-create">
            Declare window
          </Button>
        )}
      </Stack>

      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        While a window is active, runs in its scope must not START — SOD
        creation, re-runs and backfills are refused with the window named.
        Runs already in flight are never touched.
      </Typography>

      {load.phase === 'loading' && (
        <Stack alignItems="center" sx={{ py: 4 }}>
          <CircularProgress size={24} />
        </Stack>
      )}

      {load.phase === 'error' && (
        <Alert
          severity="error" data-testid="windows-load-error"
          action={
            <Button color="inherit" size="small"
                    onClick={() => void loadWindows()}>Retry</Button>
          }
        >
          Could not load deployment windows — a window may be in force but
          cannot be shown here. {load.message}
        </Alert>
      )}

      {data && (
        <>
          {active.length > 0 ? (
            <Alert severity="warning" sx={{ mb: 2 }}
                   data-testid="windows-active-banner">
              {active.length} window(s) ACTIVE right now — new runs in their
              scope will not start until they end.
            </Alert>
          ) : (
            <Alert severity="success" sx={{ mb: 2 }}
                   data-testid="windows-none-active">
              No deployment window is active — nothing is blocking run
              starts.
            </Alert>
          )}

          {data.windows.length === 0 ? (
            <Alert severity="info" data-testid="windows-empty">
              No deployment windows are stored.
            </Alert>
          ) : (
            <Paper>
              <Table size="small" data-testid="windows-table">
                <TableHead>
                  <TableRow>
                    <TableCell>Status</TableCell>
                    <TableCell>Scope</TableCell>
                    <TableCell>Starts</TableCell>
                    <TableCell>Ends</TableCell>
                    <TableCell>Reason</TableCell>
                    <TableCell>By</TableCell>
                    {isAdmin && <TableCell align="right">Remove</TableCell>}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {shown.rows.map(w => {
                    const surface = data.active_or_upcoming
                      .find(s => s.id === w.id);
                    const status = surface?.status
                      ?? (new Date(w.ends_at) < new Date() ? 'past' : 'scheduled');
                    return (
                      <TableRow key={w.id} hover>
                        <TableCell>
                          <Chip size="small" label={status}
                                color={status === 'active' ? 'warning'
                                  : status === 'upcoming' ? 'info' : 'default'}
                                sx={{ height: 20, fontSize: '0.68rem' }} />
                        </TableCell>
                        <TableCell>{scopeText(w)}</TableCell>
                        <TableCell>
                          <Typography variant="caption">{w.starts_at}</Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="caption">{w.ends_at}</Typography>
                        </TableCell>
                        <TableCell sx={{ maxWidth: 280 }}>
                          <Typography variant="caption">{w.reason}</Typography>
                        </TableCell>
                        <TableCell>
                          <Typography variant="caption">
                            {w.created_by ?? '—'}
                          </Typography>
                        </TableCell>
                        {isAdmin && (
                          <TableCell align="right">
                            <Tooltip title="Delete this window (run starts resume immediately)">
                              <Button size="small" color="error"
                                      startIcon={<DeleteIcon />}
                                      aria-label={`delete window ${w.id}`}
                                      onClick={() => {
                                        setDeleteError(null);
                                        setDeleting(w);
                                      }}>
                                Delete
                              </Button>
                            </Tooltip>
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              <ListPager paging={shown.paging} onPage={setPage} onPageSize={setPageSize}
                         testid="deployment-windows-pager" />
            </Paper>
          )}
        </>
      )}

      {/* ── Create dialog (admin) ── */}
      <AppDialog open={createOpen}
        onClose={createBusy ? undefined : () => setCreateOpen(false)}
        size="xs"
        title="Declare a deployment window"
        actions={<>
          <Button onClick={() => setCreateOpen(false)} disabled={createBusy}>
            Cancel
          </Button>
          <Button variant="contained" disabled={createBusy || createBlocked}
                  onClick={() => void doCreate()}
                  data-testid="window-create-go">
            Declare window
          </Button>
        </>}>
          <Alert severity="info" sx={{ mb: 1.5 }}>
            While this window is in force, runs in its scope will be refused
            at start with the window, its reason and end time named.
          </Alert>
          <TextField select label="Scope" value={scope} size="small" fullWidth
                     onChange={e => setScope(e.target.value as any)}
                     sx={{ mb: 1.5 }}>
            <MenuItem value="global">Global (whole platform)</MenuItem>
            <MenuItem value="group">One feed group</MenuItem>
            <MenuItem value="feed">One feed</MenuItem>
          </TextField>
          {scope !== 'global' && (
            <TextField
              label={scope === 'group' ? 'Feed group id' : 'Feed id'}
              value={scopeId} size="small" fullWidth type="number"
              onChange={e => setScopeId(e.target.value)}
              sx={{ mb: 1.5 }}
              inputProps={{ 'data-testid': 'window-scope-id' }}
            />
          )}
          <TextField label="Starts at (UTC)" type="datetime-local"
                     value={startsAt} size="small" fullWidth
                     onChange={e => setStartsAt(e.target.value)}
                     InputLabelProps={{ shrink: true }} sx={{ mb: 1.5 }}
                     inputProps={{ 'data-testid': 'window-starts' }} />
          <TextField label="Ends at (UTC)" type="datetime-local"
                     value={endsAt} size="small" fullWidth
                     onChange={e => setEndsAt(e.target.value)}
                     InputLabelProps={{ shrink: true }} sx={{ mb: 1.5 }}
                     inputProps={{ 'data-testid': 'window-ends' }} />
          <TextField label="Reason (required)" value={reason} size="small"
                     fullWidth multiline minRows={2}
                     placeholder="e.g. core banking release CB-2026-41"
                     onChange={e => setReason(e.target.value)}
                     inputProps={{ 'data-testid': 'window-reason' }} />
          {createError && (
            <Alert severity="error" sx={{ mt: 1.5 }}
                   data-testid="window-create-error">
              Nothing was stored. {createError}
            </Alert>
          )}
      </AppDialog>

      {/* ── Delete confirm ── */}
      <AppDialog open={deleting != null}
        onClose={deleteBusy ? undefined : () => setDeleting(null)}
        size="xs"
        title="Delete deployment window?"
        actions={<>
          <Button onClick={() => setDeleting(null)} disabled={deleteBusy}>
            Cancel
          </Button>
          <Button variant="contained" color="error" disabled={deleteBusy}
                  onClick={() => void doDelete()}
                  data-testid="window-delete-go">
            Delete window
          </Button>
        </>}>
          <Typography variant="body2" sx={{ mb: 1 }}>
            {deleting ? scopeText(deleting) : ''} — {deleting?.reason}
          </Typography>
          <Alert severity="warning">
            Run starts in this scope resume immediately; anything the window
            was protecting is no longer protected.
          </Alert>
          {deleteError && (
            <Alert severity="error" sx={{ mt: 1 }}
                   data-testid="window-delete-error">{deleteError}</Alert>
          )}
      </AppDialog>
    </Box>
  );
};

export default DeploymentWindowsPage;
