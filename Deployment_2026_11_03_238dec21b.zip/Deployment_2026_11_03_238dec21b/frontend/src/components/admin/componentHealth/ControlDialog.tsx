/**
 * One dialog for every control: the computed CONSEQUENCE (a dry run of the
 * POST), a mandatory reason, an expiry for a drain.  The API refuses an
 * empty reason too (400); the dialog just saves the round trip.
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Button, Stack, TextField, Typography,
} from '@mui/material';
import AppDialog from '../../common/AppDialog';
import { safeFetch } from '../../../services/api/core';
import { CONTROL_LABELS } from './types';

export interface ControlRequest {
  control: string;
  component_id: string;
  label: string;
  target_pod_id?: string | null;
}

interface Props {
  request: ControlRequest | null;
  onClose: () => void;
  onDone: (message: string) => void;
}

const ControlDialog: React.FC<Props> = ({ request, onClose, onDone }) => {
  const [reason, setReason] = useState('');
  const [expires, setExpires] = useState<number>(120);
  const [consequence, setConsequence] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setReason(''); setError(null); setConsequence(null);
    if (!request) return;
    let alive = true;
    safeFetch('/api/admin/component-health/controls', {
      method: 'POST', retryOnTimeout: false,
      body: JSON.stringify({ control: request.control, component_id: request.component_id,
                             target_pod_id: request.target_pod_id || undefined, reason: 'dry run', dry_run: true }),
    }).then((r: any) => { if (alive) setConsequence(r?.consequence || ''); })
      .catch((e: any) => { if (alive) setConsequence(`consequence could not be computed: ${e?.message || e}`); });
    return () => { alive = false; };
  }, [request]);

  if (!request) return null;
  const isDrain = request.control === 'drain';

  const submit = async () => {
    if (!reason.trim()) { setError('A reason is required.'); return; }
    setBusy(true); setError(null);
    try {
      const body: Record<string, any> = { control: request.control, component_id: request.component_id, reason: reason.trim() };
      if (request.target_pod_id) body.target_pod_id = request.target_pod_id;
      if (isDrain) body.expires_in_minutes = expires;
      const r: any = await safeFetch('/api/admin/component-health/controls', {
        method: 'POST', retryOnTimeout: false, body: JSON.stringify(body) });
      onDone(r?.intent ? `${CONTROL_LABELS[request.control]} requested (intent #${r.intent.id}, ${r.intent.status})`
                       : `${CONTROL_LABELS[request.control]} applied (${r?.applied || 'ok'})`);
      onClose();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AppDialog open
      onClose={onClose}
      size="sm"
      aria-labelledby="control-dialog-title"
      titleId="control-dialog-title"
      title={<>
        {CONTROL_LABELS[request.control] || request.control} — {request.label}
        {request.target_pod_id ? ` on ${request.target_pod_id}` : ''}
      </>}
      actions={<>
        <Button onClick={onClose} disabled={busy}>Cancel</Button>
        <Button onClick={submit} variant="contained" disabled={busy || !reason.trim()} data-testid="control-confirm">
          Confirm
        </Button>
      </>}>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <Alert severity={isDrain ? 'warning' : 'info'} data-testid="control-consequence">
            <Typography variant="body2"><b>What happens:</b> {consequence === null ? 'computing…' : (consequence || 'no side effect beyond the control itself')}</Typography>
          </Alert>
          <TextField label="Reason (required, audited)" value={reason} onChange={e => setReason(e.target.value)}
            multiline minRows={2} fullWidth required inputProps={{ 'aria-label': 'reason' }} />
          {isDrain && (
            <TextField label="Expires after (minutes; 0 = until undrained)" type="number" value={expires}
              onChange={e => setExpires(Math.max(0, Number(e.target.value) || 0))} fullWidth
              inputProps={{ 'aria-label': 'expires minutes', min: 0 }} />
          )}
          {error && <Alert severity="error">{error}</Alert>}
        </Stack>
    </AppDialog>
  );
};

export default ControlDialog;
