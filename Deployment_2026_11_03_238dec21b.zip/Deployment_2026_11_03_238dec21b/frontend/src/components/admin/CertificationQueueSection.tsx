/**
 * Admin Panel — Report Certification review queue (2026-08-17).
 *
 * The backend has had the request → review → approve workflow since Phase 157
 * (GET /api/admin/business-reports/certification-queue + approve/deny), but no
 * screen ever called it — authors could REQUEST certification from the report
 * Permissions tab and the request went into a void.  This section is the
 * review side of that loop: pending requests, the rationale the author gave,
 * approve/deny with a review note, and a link to open the report itself.
 */
import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Alert, Box, Button, Chip, CircularProgress, Stack, Tab, Table, TableBody, TableCell,
  TableContainer, TableHead, TableRow, Tabs, TextField, Tooltip, Typography,
  IconButton,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import {
  CheckCircle as ApproveIcon,
  Cancel as DenyIcon,
  Refresh as RefreshIcon,
  OpenInNew as OpenIcon,
  Verified as CertifiedIcon,
} from '@mui/icons-material';
import api from '../../services/api';
import { reportPath } from '../../utils/reportUrls';
import ListPager, { clientPage } from '../common/ListPager';

interface CertRequest {
  id: number;
  report_id: number;
  requested_by: string;
  rationale?: string | null;
  status: string;
  reviewed_by?: string | null;
  reviewed_at?: string | null;
  review_note?: string | null;
  created_at?: string | null;
}

/** Tab index → backend status filter ('' = all). */
const STATUS_TABS = ['pending', 'approved', 'denied', ''] as const;

const statusColor = (s: string): 'warning' | 'success' | 'error' | 'default' =>
  s === 'pending' ? 'warning' : s === 'approved' ? 'success' : s === 'denied' ? 'error' : 'default';

const CertificationQueueSection: React.FC = () => {
  const navigate = useNavigate();
  const [entries, setEntries] = useState<CertRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState(0);
  const [certPage, setCertPage] = useState(1);
  const [certSize, setCertSize] = useState(50);

  // Decision dialog (shared by approve + deny — the note is the only input)
  const [decision, setDecision] = useState<{ req: CertRequest; approve: boolean } | null>(null);
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const resp: any = await api.listCertificationQueue(STATUS_TABS[tab]);
      // {entries: [...]} today; tolerate a bare array from a future backend.
      const rows = Array.isArray(resp) ? resp : (resp?.entries || []);
      setEntries(rows as CertRequest[]);
    } catch (e: any) {
      // NO silent [] here — an unreadable queue must never read as "no
      // pending requests" (the misleading-empty-state trap).
      setError(e?.message || 'Failed to load the certification queue');
      setEntries([]);
    } finally {
      setLoading(false);
    }
  }, [tab]);

  useEffect(() => { load(); }, [load]);

  const handleDecide = async () => {
    if (!decision) return;
    setSubmitting(true);
    try {
      if (decision.approve) {
        await api.approveCertificationRequest(decision.req.id, note.trim() || undefined);
      } else {
        await api.denyCertificationRequest(decision.req.id, note.trim() || undefined);
      }
      setDecision(null);
      setNote('');
      load();
    } catch (e: any) {
      setError(e?.message || 'Decision failed');
      setDecision(null);
    } finally {
      setSubmitting(false);
    }
  };

  const fmt = (s?: string | null) => (s ? new Date(s).toLocaleString() : '—');

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <CertifiedIcon color="success" />
          <Typography variant="h6" fontWeight={600}>Report Certification Queue</Typography>
        </Box>
        <Button startIcon={<RefreshIcon />} onClick={load} size="small">Refresh</Button>
      </Box>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Report owners request certification from the report&apos;s Permissions
        tab; approving stamps the Certified badge everywhere the report is
        listed. To certify a report directly (without a request), open it and
        use the lifecycle menu in its header.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}
          action={<Button size="small" onClick={load}>Retry</Button>}>
          {error}
        </Alert>
      )}

      <Tabs value={tab} onChange={(_, v) => { setTab(v); setCertPage(1); }} sx={{ mb: 2 }}>
        <Tab label="Pending" />
        <Tab label="Approved" />
        <Tab label="Denied" />
        <Tab label="All" />
      </Tabs>

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
      ) : error ? (
        // The Alert above already says what went wrong — rendering the empty
        // state as well would claim "no requests" when the truth is "we could
        // not ask".
        null
      ) : entries.length === 0 ? (
        <Typography color="text.secondary" sx={{ py: 2 }}>
          {tab === 0 ? 'No pending certification requests.' : 'No requests found.'}
        </Typography>
      ) : (
        <TableContainer sx={{ overflowX: 'auto' }}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell><strong>Report</strong></TableCell>
                <TableCell><strong>Requested by</strong></TableCell>
                <TableCell><strong>Rationale</strong></TableCell>
                <TableCell><strong>Requested at</strong></TableCell>
                <TableCell><strong>Status</strong></TableCell>
                <TableCell><strong>Reviewed</strong></TableCell>
                <TableCell align="right"><strong>Actions</strong></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {clientPage(entries, certPage, certSize).rows.map(req => (
                <TableRow key={req.id} hover>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                      <Typography variant="body2">#{req.report_id}</Typography>
                      <Tooltip title="Open report">
                        <IconButton size="small"
                          aria-label={`Open report ${req.report_id}`}
                          onClick={() => navigate(reportPath(req.report_id))}>
                          <OpenIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </TableCell>
                  <TableCell>{req.requested_by}</TableCell>
                  <TableCell>
                    <Typography variant="caption" sx={{
                      maxWidth: 280, display: 'block',
                      overflow: 'hidden', textOverflow: 'ellipsis',
                    }} title={req.rationale || ''}>
                      {req.rationale || '—'}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="caption">{fmt(req.created_at)}</Typography>
                  </TableCell>
                  <TableCell>
                    <Chip label={req.status} size="small" color={statusColor(req.status)} />
                  </TableCell>
                  <TableCell>
                    {req.reviewed_by ? (
                      <Tooltip title={`${fmt(req.reviewed_at)}${req.review_note ? ` — ${req.review_note}` : ''}`}>
                        <Typography variant="caption">by {req.reviewed_by}</Typography>
                      </Tooltip>
                    ) : (
                      <Typography variant="caption" color="text.disabled">—</Typography>
                    )}
                  </TableCell>
                  <TableCell align="right">
                    {req.status === 'pending' && (
                      <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                        <Button size="small" color="success" startIcon={<ApproveIcon />}
                          onClick={() => { setDecision({ req, approve: true }); setNote(''); }}>
                          Approve
                        </Button>
                        <Button size="small" color="error" startIcon={<DenyIcon />}
                          onClick={() => { setDecision({ req, approve: false }); setNote(''); }}>
                          Deny
                        </Button>
                      </Stack>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <ListPager paging={clientPage(entries, certPage, certSize).paging}
                     onPage={setCertPage} onPageSize={setCertSize} testid="certification-queue-pager" />
        </TableContainer>
      )}

      {/* Decision dialog */}
      <AppDialog open={!!decision}
        onClose={() => setDecision(null)}
        size="sm"
        title={decision?.approve ? 'Approve certification' : 'Deny certification'}
        actions={<>
          <Button onClick={() => setDecision(null)}>Cancel</Button>
          <Button variant="contained"
            color={decision?.approve ? 'success' : 'error'}
            disabled={submitting}
            startIcon={submitting
              ? <CircularProgress size={14} />
              : decision?.approve ? <ApproveIcon /> : <DenyIcon />}
            onClick={handleDecide}>
            {decision?.approve ? 'Approve' : 'Deny'}
          </Button>
        </>}>
          {decision && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <Typography>
                Report <strong>#{decision.req.report_id}</strong>, requested by{' '}
                <strong>{decision.req.requested_by}</strong>
              </Typography>
              {decision.req.rationale && (
                <Typography variant="body2" color="text.secondary">
                  Rationale: {decision.req.rationale}
                </Typography>
              )}
              {decision.approve && (
                <Alert severity="info">
                  Approving marks the report as certified — the org-vetted
                  trust badge shown wherever users choose what to open.
                </Alert>
              )}
              <TextField label="Review note (optional)" value={note}
                onChange={e => setNote(e.target.value)}
                fullWidth size="small" multiline rows={2} />
            </Stack>
          )}
      </AppDialog>
    </Box>
  );
};

export default CertificationQueueSection;
