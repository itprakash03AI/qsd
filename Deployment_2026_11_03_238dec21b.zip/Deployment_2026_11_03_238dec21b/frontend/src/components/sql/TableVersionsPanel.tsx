/**
 * "Table version" -- ONE row per Iceberg table the SQL reads (2026-11-01).
 *
 * The owner: "how will the user know what versions are available, and if
 * there are two tables in the query then?"  Each row has its own picker:
 * "Latest (default)" plus that table's versions, newest first (version
 * number, commit time, what the commit did, rows added / total rows / files).
 * Choosing one asks the server to put `FOR VERSION AS OF <id>` after that
 * table in the SQL (or remove it for Latest) -- the SQL text stays the single
 * truth; nothing here decides which version is read.  A source that keeps no
 * versions says so.  Backend: POST /api/sql/table-versions
 * (core/iceberg_versions.py).
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  Alert, Box, CircularProgress, FormControl, InputLabel, MenuItem, Select, TextField, Typography,
} from '@mui/material';
import api from '../../services/api';
import {
  asOfInputValue, shortTime, versionMenuItems, versionWords, VersionsReadLine,
  type TableVersionRow,
} from '../common/tableVersionWords';

// the shared pieces (2026-11-01): one listing, the same words on the SQL page
// and the report run panel's Data version control
export { asOfInputValue, shortTime, versionWords, VersionsReadLine };
export type { TableVersionRow };

export interface TableVersionsAnswer {
  sql: string;
  connection?: { id: number; name?: string; type?: string };
  capability?: { supported: string; reason?: string | null; how_listed?: string | null };
  reason?: string | null;
  tables: Array<{
    table: string;
    snapshot_id: string | null;
    as_of_ms: number | null;
    current_snapshot_id?: string | null;
    versions: TableVersionRow[] | null;
    /** Snowflake: the table's Time Travel window (days); versions are not listed */
    retention_days?: number | null;
    reason?: string | null;
    error?: string;
  }>;
}

export const LATEST = '__latest__';
export const AS_OF = '__as_of__';

/** The words a row shows when its source keeps no versions. */
export function noVersionsWords(reason?: string | null): string {
  return `This source keeps no versions${reason ? ` -- ${reason}` : '.'}`;
}

interface Props {
  connectionId: number | null | undefined;
  sql: string;
  onSqlChange: (sql: string) => void;
  /** connection name, shown on each row (the side the table is read on) */
  sideLabel?: string;
}

const TableVersionsPanel: React.FC<Props> = ({ connectionId, sql, onSqlChange, sideLabel }) => {
  const [answer, setAnswer] = useState<TableVersionsAnswer | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const seq = useRef(0);

  useEffect(() => {
    if (!connectionId || !sql.trim()) { setAnswer(null); return; }
    const mine = ++seq.current;
    const t = setTimeout(() => {
      api.sqlTableVersions({ connection_id: connectionId, sql })
        .then((a: TableVersionsAnswer) => { if (mine === seq.current) { setAnswer(a); setError(null); } })
        .catch((e: any) => { if (mine === seq.current) setError(e?.message || String(e)); });
    }, 500);
    return () => clearTimeout(t);
  }, [connectionId, sql]);

  const [asOfOpen, setAsOfOpen] = useState<Record<string, boolean>>({});

  const choose = async (table: string, value: string, asOf?: string) => {
    if (!connectionId) return;
    if (value === AS_OF && !asOf) { setAsOfOpen((o) => ({ ...o, [table]: true })); return; }
    setBusy(true);
    try {
      const a: TableVersionsAnswer = await api.sqlTableVersions({
        connection_id: connectionId, sql,
        set: asOf
          ? { table, snapshot_id: null, as_of: new Date(asOf).toISOString() }
          : { table, snapshot_id: value === LATEST ? null : value },
      });
      if (asOf) setAsOfOpen((o) => ({ ...o, [table]: false }));
      setAnswer(a);
      setError(null);
      if (a.sql !== sql) onSqlChange(a.sql);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  if (!connectionId) return null;
  if (error) {
    return <Alert severity="warning" data-testid="table-versions-error" sx={{ mx: 1, my: 0.5, py: 0 }}>{error}</Alert>;
  }
  if (!answer) return null;
  // an answer without its tables list (an error body, an older server) draws
  // nothing -- it must never take the whole SQL page down (vitest gate 2026-11-01)
  const tables: TableVersionsAnswer['tables'] = Array.isArray(answer.tables) ? answer.tables : [];
  const cap = answer.capability;
  const side = sideLabel ? ` (${sideLabel})` : '';
  if (cap && cap.supported === 'none') {
    // 2026-11-01: SAID, never hidden -- a clause typed here is refused on Run
    return (
      <Typography variant="caption" color="text.secondary" data-testid="table-versions-none"
                  sx={{ px: 1.5, display: 'block' }}>
        {`Table version${side}: ${noVersionsWords(cap.reason)}`}
      </Typography>
    );
  }
  if (!tables.length) {
    if (cap && cap.supported !== 'none' && answer.reason === undefined && answer.connection?.type !== 's3') {
      return (
        <Typography variant="caption" color="text.secondary" data-testid="table-versions-native"
                    sx={{ px: 1.5, display: 'block' }}>
          Table versions on this source{side}: write FOR VERSION AS OF / FOR TIMESTAMP AS OF in the SQL
          ({cap.how_listed}).
        </Typography>
      );
    }
    return null;
  }
  const timeOnly = cap?.supported === 'timestamp';
  return (
    <Box data-testid="table-versions" sx={{ px: 1, py: 0.5, display: 'flex', flexWrap: 'wrap', gap: 1, alignItems: 'center', flexShrink: 0 }}>
      <Typography variant="caption" sx={{ fontWeight: 600 }}>{`Table version${side}`}</Typography>
      {tables.map((t) => {
        const value = t.snapshot_id || LATEST;
        const id = `table-version-${t.table}`;
        const label = sideLabel ? `${t.table} (${sideLabel})` : t.table;
        const open = !!asOfOpen[t.table] || (!!t.as_of_ms && !t.snapshot_id);
        return (
          <Box key={t.table} sx={{ display: 'flex', gap: 1, alignItems: 'center' }} data-testid={`table-version-row-${t.table}`}>
            <FormControl size="small" sx={{ minWidth: 260 }}>
              <InputLabel id={`${id}-label`}>{label}</InputLabel>
              <Select
                labelId={`${id}-label`}
                label={label}
                value={t.as_of_ms ? AS_OF : value}
                disabled={busy || (t.versions === null && !timeOnly && !t.error)}
                onChange={(e) => choose(t.table, String(e.target.value))}
                inputProps={{ 'data-testid': id }}
                renderValue={(v) => (v === LATEST ? 'Latest (default)'
                  : v === AS_OF ? `As of ${t.as_of_ms ? shortTime(new Date(t.as_of_ms).toISOString()) : 'a time'}`
                  : `Version ${v}`)}
              >
                <MenuItem value={LATEST}>Latest (default)</MenuItem>
                <MenuItem value={AS_OF} data-testid={`table-version-as-of-${t.table}`}>
                  {timeOnly && t.retention_days != null
                    ? `As of a time (inside the last ${t.retention_days} day(s))`
                    : 'As of a time...'}
                </MenuItem>
                {versionMenuItems(t.versions, 'table-version-option')}
                {t.snapshot_id && !(t.versions || []).some((v) => v.snapshot_id === t.snapshot_id) ? (
                  <MenuItem value={t.snapshot_id} disabled>{`Version ${t.snapshot_id} (no longer kept)`}</MenuItem>
                ) : null}
              </Select>
              {t.error ? (
                <Typography variant="caption" color="error" data-testid={`table-version-error-${t.table}`}>{t.error}</Typography>
              ) : null}
              {!t.error && t.versions === null && t.reason ? (
                <Typography variant="caption" color="text.secondary" data-testid={`table-version-reason-${t.table}`}>{t.reason}</Typography>
              ) : null}
            </FormControl>
            {open ? (
              <TextField
                size="small" type="datetime-local" label="As of (UTC)"
                InputLabelProps={{ shrink: true }}
                defaultValue={asOfInputValue(t.as_of_ms)}
                inputProps={{ 'data-testid': `table-version-as-of-input-${t.table}`, 'aria-label': `As of time for ${t.table}` }}
                disabled={busy}
                onBlur={(e) => { if (e.target.value) choose(t.table, AS_OF, e.target.value + ':00Z'); }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    const v = (e.target as HTMLInputElement).value;
                    if (v) choose(t.table, AS_OF, v + ':00Z');
                  }
                }}
              />
            ) : null}
          </Box>
        );
      })}
      {busy ? <CircularProgress size={14} /> : null}
    </Box>
  );
};

export default TableVersionsPanel;
