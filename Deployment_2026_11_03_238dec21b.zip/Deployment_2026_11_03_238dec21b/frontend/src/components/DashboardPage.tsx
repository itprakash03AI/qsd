import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import GridLayout from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import {
  Box, Button, Typography, IconButton, Dialog, TextField, Select, MenuItem,
  FormControl, InputLabel, Paper, CircularProgress, Chip,
  Tooltip, Menu, Divider, Alert, Snackbar, alpha, Skeleton,
  ToggleButtonGroup, ToggleButton, Stack, useMediaQuery,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon,
  Dashboard as DashboardIcon, BarChart as BarChartIcon,
  PieChart as PieChartIcon, ShowChart as LineIcon,
  TableChart as TableIcon, Refresh as RefreshIcon,
  MoreVert as MoreIcon, GridView as GridIcon,
  DragIndicator as DragIcon, AreaChart as AreaChartIcon,
  Settings as ConfigIcon, TrendingUp as KpiIcon,
  Link as LinkIcon, ContentCopy as CopyIcon,
  ViewModule as LayoutIcon, Palette as PaletteIcon,
  Print as PrintIcon, FilterList as FilterIcon,
  FileDownload as ExportIcon, Autorenew as AutoRefreshIcon,
} from '@mui/icons-material';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area,
  PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip,
  Legend, ResponsiveContainer,
} from 'recharts';
import api from '../services/api';
import { markExecutionQuiet } from '../context/NotificationContext';
// 2026-09-28 -- a finance-report tile wears the readiness of its business date
import ReadinessChip from './reports/ReadinessChip';
import { useServerDraft } from '../hooks/useServerDraft';
import { safeStringify } from '../utils/safeStringify';
import { toArray } from '../utils/toArray';
import { openDownload } from '../services/api/core';
import {
  bindableParams, defaultFilterValues, effectiveWidgetParams, missingRequired,
  type DashboardFilter, type DeclaredParam,
} from './dashboard/dashboardParams';
import { DashboardFilterBar, FiltersEditorDialog, ParamInputs } from './dashboard/DashboardFilters';
import { clickable } from '../utils/clickable';
import ReportCanvasTile from './reports/canvas/ReportCanvasTile';

/** A dashboard tile's source kinds, in the order the Add dialog offers them.
 *  A finance report comes first: it is what a business user builds. */
export const WIDGET_SOURCES: { value: string; label: string }[] = [
  { value: 'business_report', label: 'Finance Report' },
  { value: 'sql_query',       label: 'SQL Query' },
  { value: 'saved_query',     label: 'Parquet / S3 Query' },
];

const nonEmptyParams = (vals: Record<string, any>) =>
  Object.fromEntries(Object.entries(vals || {}).filter(([, v]) => v !== '' && v != null));

// ── Palette ────────────────────────────────────────────────────────────────────
const COLORS = ['#1565c0','#2e7d32','#c62828','#e65100','#6a1b9a',
                '#00838f','#ff6f00','#558b2f','#ad1457','#4527a0'];
const fmtNum = (n: any): string => {
  if (typeof n !== 'number' && isNaN(Number(n))) return String(n ?? '');
  const num = Number(n);
  const abs = Math.abs(num);
  const s = abs >= 1_000_000 ? `${(abs/1_000_000).toFixed(1)}M`
           : abs >= 1_000   ? `${(abs/1_000).toFixed(1)}K`
           : abs.toLocaleString();
  return num < 0 ? `(${s})` : s;
};

// JSX helper: renders negative numbers in red with () notation
const FmtCell = ({ v, isNum }: { v: any; isNum: boolean }) => {
  if (!isNum) return v == null
    ? <span style={{ color:'#94a3b8', fontStyle:'italic' }}>null</span>
    : <>{String(v)}</>;
  const n = Number(v);
  if (isNaN(n)) return <>{String(v ?? '')}</>;
  const formatted = fmtNum(n);
  if (n < 0) return <span style={{ color:'#c62828', fontWeight:600 }}>{formatted}</span>;
  return <>{formatted}</>;
};

// ── Helpers ────────────────────────────────────────────────────────────────────
function isNumCol(rows: Record<string, any>[], col: string): boolean {
  const sample = rows.slice(0, 20).map(r => r[col]).filter(v => v != null);
  return sample.length > 0 && sample.every(v => !isNaN(Number(v)));
}

function aggregateRows(rows: Record<string, any>[], xKey: string, yKey: string, aggFn = 'sum') {
  const map = new Map();
  rows.forEach(r => {
    const k = String(r[xKey] ?? '(blank)');
    const v = Number(r[yKey]);
    if (!map.has(k)) map.set(k, []);
    if (!isNaN(v)) map.get(k).push(v);
  });
  return Array.from(map.entries())
    .map(([name, vals]) => {
      let value = 0;
      if (aggFn === 'sum')   value = vals.reduce((a, b) => a + b, 0);
      if (aggFn === 'avg')   value = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      if (aggFn === 'count') value = vals.length;
      if (aggFn === 'max')   value = vals.length ? Math.max(...vals) : 0;
      if (aggFn === 'min')   value = vals.length ? Math.min(...vals) : 0;
      return { name, value: Math.round(value * 100) / 100 };
    })
    .sort((a, b) => b.value - a.value)
    .slice(0, 40);
}

// ── Layout presets ─────────────────────────────────────────────────────────────
const PRESET_LAYOUTS = [
  {
    id: 'full',     name: 'Full Width',   desc: 'One widget per row, full width',
    slots: [{ x:0,y:0,w:12,h:6 },{ x:0,y:6,w:12,h:6 },{ x:0,y:12,w:12,h:6 }],
  },
  {
    id: '2col',     name: '2 Column',     desc: 'Two equal columns side by side',
    slots: [{ x:0,y:0,w:6,h:5 },{ x:6,y:0,w:6,h:5 },{ x:0,y:5,w:6,h:5 },{ x:6,y:5,w:6,h:5 }],
  },
  {
    id: '3col',     name: '3 Column',     desc: 'Three equal columns',
    slots: [{ x:0,y:0,w:4,h:5 },{ x:4,y:0,w:4,h:5 },{ x:8,y:0,w:4,h:5 },
            { x:0,y:5,w:4,h:5 },{ x:4,y:5,w:4,h:5 },{ x:8,y:5,w:4,h:5 }],
  },
  {
    id: 'kpi-row',  name: 'KPI + Chart',  desc: '4 metric cards on top, large chart below',
    slots: [{ x:0,y:0,w:3,h:3 },{ x:3,y:0,w:3,h:3 },{ x:6,y:0,w:3,h:3 },{ x:9,y:0,w:3,h:3 },
            { x:0,y:3,w:12,h:7 }],
  },
  {
    id: 'featured', name: 'Featured',     desc: 'Hero widget on top, three panels below',
    slots: [{ x:0,y:0,w:12,h:6 },{ x:0,y:6,w:4,h:5 },{ x:4,y:6,w:4,h:5 },{ x:8,y:6,w:4,h:5 }],
  },
  {
    id: 'sidebar',  name: 'Wide + Sidebar', desc: 'Large main content, two sidebar widgets',
    slots: [{ x:0,y:0,w:8,h:10 },{ x:8,y:0,w:4,h:5 },{ x:8,y:5,w:4,h:5 }],
  },
  {
    id: 'mosaic',   name: 'Mosaic',       desc: 'Varied sizes for visual richness',
    slots: [{ x:0,y:0,w:7,h:6 },{ x:7,y:0,w:5,h:3 },{ x:7,y:3,w:5,h:3 },
            { x:0,y:6,w:4,h:4 },{ x:4,y:6,w:4,h:4 },{ x:8,y:6,w:4,h:4 }],
  },
  {
    id: 'exec',     name: 'Executive',    desc: 'Wide overview + two detail panels',
    slots: [{ x:0,y:0,w:12,h:5 },{ x:0,y:5,w:6,h:6 },{ x:6,y:5,w:6,h:6 }],
  },
];

// ── Dashboard style themes ─────────────────────────────────────────────────────
const DASH_STYLES = [
  { id:'default',  name:'Classic',    dot:'#e2e8f0', canvasBg:'#f0f4f8',     headerBg:'linear-gradient(135deg,#f8fafc,#f1f5f9)',  dark:false },
  { id:'indigo',   name:'Indigo',     dot:'#818cf8', canvasBg:'#eef2ff',     headerBg:'linear-gradient(135deg,#e0e7ff,#c7d2fe)',  dark:false },
  { id:'teal',     name:'Teal',       dot:'#2dd4bf', canvasBg:'#f0fdfa',     headerBg:'linear-gradient(135deg,#ccfbf1,#99f6e4)',  dark:false },
  { id:'rose',     name:'Rose',       dot:'#fb7185', canvasBg:'#fff1f2',     headerBg:'linear-gradient(135deg,#ffe4e6,#fecdd3)',  dark:false },
  { id:'amber',    name:'Amber',      dot:'#fbbf24', canvasBg:'#fffbeb',     headerBg:'linear-gradient(135deg,#fef3c7,#fde68a)',  dark:false },
  { id:'slate',    name:'Slate',      dot:'#94a3b8', canvasBg:'#e9eff6',     headerBg:'linear-gradient(135deg,#dde6f0,#c8d7e8)',  dark:false },
  { id:'charcoal', name:'Dark',       dot:'#334155', canvasBg:'#0f172a',     headerBg:'linear-gradient(135deg,#1e293b,#0f172a)',  dark:true  },
  { id:'midnight', name:'Midnight',   dot:'#312e81', canvasBg:'#1e1b4b',     headerBg:'linear-gradient(135deg,#312e81,#1e1b4b)',  dark:true  },
];

// ── Layout visual preview ──────────────────────────────────────────────────────
function LayoutPreview({ slots, active }) {
  const maxY = Math.max(...slots.map(s => s.y + s.h));
  const W = 150, H = 80;
  return (
    <Box sx={{ position:'relative', width:W, height:H, bgcolor:'#f1f5f9',
               borderRadius:1, overflow:'hidden', flexShrink:0 }}>
      {slots.map((s, i) => (
        <Box key={i} sx={{
          position:'absolute',
          left:  `${(s.x/12)*100}%`,  top:  `${(s.y/maxY)*100}%`,
          width: `${(s.w/12)*100}%`,  height:`${(s.h/maxY)*100}%`,
          p:'2px',
        }}>
          <Box sx={{ width:'100%', height:'100%', borderRadius:0.5,
                     bgcolor: active ? 'primary.main' : '#94a3b8',
                     opacity: 0.7 + i * 0.03, display:'flex',
                     alignItems:'center', justifyContent:'center' }}>
            <Typography sx={{ color:'#fff', fontSize:9, fontWeight:700, lineHeight:1 }}>{i+1}</Typography>
          </Box>
        </Box>
      ))}
    </Box>
  );
}

// ── Layout Picker Dialog ───────────────────────────────────────────────────────
function LayoutPickerDialog({ open, onClose, onApply, currentLayout }: { open: boolean; onClose: () => void; onApply: (preset: any) => Promise<void>; currentLayout?: any }) {
  const [hovered, setHovered] = useState<string | null>(null);
  return (
    <AppDialog open={open}
      onClose={onClose}
      size="md"
      title={<>
        Choose Layout
        <Typography variant="body2" color="text.secondary" sx={{ fontWeight:400, mt:0.5 }}>
          Selecting a layout will rearrange your existing widgets to fit the chosen grid.
        </Typography>
      </>}
      actions={<>
        <Button onClick={onClose}>Cancel</Button>
      </>}>
        <Box sx={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:1.5 }}>
          {PRESET_LAYOUTS.map(preset => (
            <Paper key={preset.id} elevation={hovered === preset.id ? 4 : 1}
              onMouseEnter={() => setHovered(preset.id)}
              onMouseLeave={() => setHovered(null)}
              {...clickable(() => { onApply(preset); onClose(); }, { label: preset.name })}
              sx={{ p:1.5, cursor:'pointer', border:2,
                    borderColor: hovered === preset.id ? 'primary.main' : 'transparent',
                    borderRadius:2, transition:'all .15s', display:'flex',
                    flexDirection:'column', gap:1, alignItems:'center' }}>
              <LayoutPreview slots={preset.slots} active={hovered === preset.id} />
              <Box sx={{ textAlign:'center' }}>
                <Typography variant="body2" fontWeight={700} sx={{ fontSize:13 }}>{preset.name}</Typography>
                <Typography variant="caption" color="text.secondary">{preset.desc}</Typography>
              </Box>
            </Paper>
          ))}
        </Box>
    </AppDialog>
  );
}

// ── Cross-filter types ────────────────────────────────────────────────────────
// A cross-filter says "column X has value Y, applied by widget Z"
type CrossFilter = { column: string; value: string; sourceWidgetId: number };

// Apply active cross-filters to a widget's rows (exclude filters from self)
function applyCrossFilters(rows: any[], filters: CrossFilter[], widgetId: number) {
  const applicable = filters.filter(f => f.sourceWidgetId !== widgetId);
  if (applicable.length === 0) return rows;
  return rows.filter(row =>
    applicable.every(f => String(row[f.column] ?? '') === f.value)
  );
}

// ── Chart renderer ─────────────────────────────────────────────────────────────
function ChartRenderer({ chartType, rows, config, onNeedConfig, onCrossFilter }: any) {
  if (!rows || rows.length === 0) {
    return (
      <Box sx={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100%' }}>
        <Typography variant="caption" color="text.secondary">The query ran and returned no rows.</Typography>
      </Box>
    );
  }

  const cols   = Object.keys(rows[0] || {});
  const numCols = cols.filter(c => isNumCol(rows, c));
  const strCols = cols.filter(c => !isNumCol(rows, c));

  const xKey  = config?.x_field  || strCols[0] || cols[0];
  const yKey  = config?.y_field  || numCols[0] || cols[1] || cols[0];
  const aggFn = config?.agg_fn   || 'sum';

  // Table view — no config needed
  if (chartType === 'grid') {
    return (
      <Box sx={{ overflowX:'auto', overflowY:'auto', height:'100%' }}>
        <Box sx={{ mb: 0.5, px: 1 }}>
          <Typography variant="caption" color="text.secondary">
            {rows.length.toLocaleString()} rows · {cols.length} columns
          </Typography>
        </Box>
        <table style={{ borderCollapse:'collapse', fontSize:12, width:'100%' }}>
          <thead>
            <tr>
              {cols.map(c => (
                <th key={c} style={{ background:'#f8fafc', padding:'5px 10px',
                  borderBottom:'2px solid #e2e8f0', textAlign:'left',
                  whiteSpace:'nowrap', fontWeight:700, fontSize:11, color:'#64748b' }}>
                  {c}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, 100).map((row, i) => (
              <tr key={i} style={{ background: i % 2 ? '#f8fafc' : '#fff' }}>
                {cols.map(c => (
                  <td key={c} style={{ padding:'4px 10px', borderBottom:'1px solid #f1f5f9',
                    maxWidth:180, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
                    textAlign: isNumCol(rows, c) ? 'right' : 'left' }}>
                    <FmtCell v={row[c]} isNum={isNumCol(rows, c)} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length > 100 && (
          <Box sx={{ p: 1, textAlign:'center' }}>
            <Typography variant="caption" color="text.disabled">
              Showing first 100 of {rows.length.toLocaleString()} rows
            </Typography>
          </Box>
        )}
      </Box>
    );
  }

  // KPI metric
  if (chartType === 'metric') {
    const val = rows[0]?.[yKey] ?? rows[0]?.[cols[0]] ?? '—';
    const label = yKey || cols[0];
    const total = numCols.includes(yKey)
      ? rows.reduce((s, r) => s + Number(r[yKey] || 0), 0)
      : null;
    return (
      <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                 justifyContent:'center', height:'100%', gap:1, p:2 }}>
        <Typography variant="h2" fontWeight={800} color="primary.main" sx={{ lineHeight:1 }}>
          {fmtNum(typeof val === 'number' ? val : Number(val) || val)}
        </Typography>
        <Typography variant="body2" color="text.secondary" fontWeight={600}>{label}</Typography>
        {total !== null && rows.length > 1 && (
          <Chip label={`Total: ${fmtNum(total)} across ${rows.length} rows`}
                size="small" variant="outlined" sx={{ fontSize:11 }} />
        )}
      </Box>
    );
  }

  // Charts need a numeric y column
  if (!numCols.includes(yKey) && numCols.length === 0) {
    return (
      <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                 justifyContent:'center', height:'100%', gap:1, p:2 }}>
        <ConfigIcon sx={{ fontSize:32, color:'text.disabled' }} />
        <Typography variant="caption" color="text.secondary" textAlign="center">
          No numeric columns found. Switch to Table view or edit the widget to configure columns.
        </Typography>
        <Button size="small" startIcon={<ConfigIcon />} onClick={onNeedConfig}>Configure</Button>
      </Box>
    );
  }

  // Aggregate
  const agg = aggregateRows(rows, xKey, yKey, aggFn);
  const xProps = { dataKey:'name', tick:{ fontSize:11 }, angle:-30, textAnchor:'end' as const, interval:0 };
  const yProps = { tick:{ fontSize:11 }, tickFormatter: fmtNum, width:58 };
  const tip    = <ReTooltip formatter={(v: any) => [fmtNum(Number(v)), `${aggFn.toUpperCase()}(${yKey})`]}
                             labelFormatter={(l: any) => `${xKey}: ${l}`} />;
  const common = { data:agg, margin:{ top:8, right:12, left:0, bottom:56 } };
  const handleChartClick = (data: any) => {
    if (onCrossFilter && data?.name) onCrossFilter(xKey, data.name);
  };

  if (chartType === 'bar') return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart {...common} onClick={(e: any) => e?.activePayload?.[0] && handleChartClick(e.activePayload[0].payload)}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis {...xProps} />
        <YAxis {...yProps} />
        {tip}
        <Bar dataKey="value" radius={[4,4,0,0]} maxBarSize={48} style={{ cursor:'pointer' }}>
          {agg.map((_,i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );

  if (chartType === 'line') return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart {...common} onClick={(e: any) => e?.activePayload?.[0] && handleChartClick(e.activePayload[0].payload)}>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis {...xProps} />
        <YAxis {...yProps} />
        {tip}
        <Line type="monotone" dataKey="value" stroke={COLORS[0]} strokeWidth={2}
              dot={{ r:3, fill:COLORS[0] }} style={{ cursor:'pointer' }} />
      </LineChart>
    </ResponsiveContainer>
  );

  if (chartType === 'area') return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart {...common} onClick={(e: any) => e?.activePayload?.[0] && handleChartClick(e.activePayload[0].payload)}>
        <defs>
          <linearGradient id={`ag_${yKey}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor={COLORS[0]} stopOpacity={0.3} />
            <stop offset="95%" stopColor={COLORS[0]} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis {...xProps} />
        <YAxis {...yProps} />
        {tip}
        <Area type="monotone" dataKey="value" stroke={COLORS[0]}
              fill={`url(#ag_${yKey})`} strokeWidth={2} style={{ cursor:'pointer' }} />
      </AreaChart>
    </ResponsiveContainer>
  );

  if (chartType === 'pie') return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart margin={{ top:8, right:8, bottom:8, left:8 }}>
        <Pie data={agg} dataKey="value" nameKey="name" cx="50%" cy="45%"
             outerRadius="65%"
             label={({ name, percent }) => `${name}: ${(percent*100).toFixed(1)}%`}
             labelLine onClick={(_, idx) => handleChartClick(agg[idx])}>
          {agg.map((_,i) => <Cell key={i} fill={COLORS[i % COLORS.length]} style={{ cursor:'pointer' }} />)}
        </Pie>
        <ReTooltip formatter={(v) => [fmtNum(v), yKey]} />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );

  return null;
}

// ── Edit Widget Dialog ─────────────────────────────────────────────────────────
function EditWidgetDialog({ open, widget, rows, onClose, onSave }: { open: boolean; widget: any; rows: any[]; onClose: () => void; onSave: (data: any) => void }) {
  const [title,     setTitle]     = useState('');
  const [chartType, setChartType] = useState('grid');
  const [xField,    setXField]    = useState('');
  const [yField,    setYField]    = useState('');
  const [aggFn,     setAggFn]     = useState('sum');
  const [saving,    setSaving]    = useState(false);
  const [paramVals, setParamVals] = useState<Record<string, any>>({});
  const declared: DeclaredParam[] = widget?.declared_params || [];

  const cols    = rows?.length ? Object.keys(rows[0]) : [];
  const numCols = cols.filter(c => isNumCol(rows || [], c));
  const strCols = cols.filter(c => !isNumCol(rows || [], c));

  useEffect(() => {
    if (!open || !widget) return;
    setTitle(widget.title || '');
    setChartType(widget.chart_type || 'grid');
    setXField(widget.chart_config?.x_field || strCols[0] || cols[0] || '');
    setYField(widget.chart_config?.y_field || numCols[0] || '');
    setAggFn(widget.chart_config?.agg_fn   || 'sum');
    setParamVals({ ...(widget.param_values || {}) });
  }, [open, widget]);

  const handleSave = async () => {
    setSaving(true);
    await onSave({
      title:        title || widget.title,
      chart_type:   chartType,
      chart_config: { x_field: xField, y_field: yField, agg_fn: aggFn },
      ...(declared.length ? { param_values: nonEmptyParams(paramVals) } : {}),
    });
    setSaving(false);
    onClose();
  };

  const needsAxes = chartType !== 'grid';

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="sm"
      title="Edit Widget"
      contentSx={{ display:'flex', flexDirection:'column', gap:2, pt:2 }}
      actions={<>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave} variant="contained" disabled={saving}
                startIcon={saving ? <CircularProgress size={14} /> : null}>
          Save Changes
        </Button>
      </>}>

        <TextField label="Widget Title" size="small" fullWidth
                   value={title} onChange={e => setTitle(e.target.value)} />

        {declared.length > 0 && (
          <>
            <Divider><Typography variant="caption" color="text.secondary">Parameter values</Typography></Divider>
            <Typography variant="caption" color="text.secondary" sx={{ mt: -1 }}>
              A dashboard filter on the same parameter overrides the value set here.
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
              <ParamInputs idPrefix={`edit-w-${widget?.id}`} params={declared} values={paramVals}
                           onChange={(n, v) => setParamVals(prev => ({ ...prev, [n]: v }))} />
            </Box>
          </>
        )}

        <FormControl size="small" fullWidth>
          <InputLabel id="sel-dashboardpage-chart-type">Chart Type</InputLabel>
          <Select labelId="sel-dashboardpage-chart-type" value={chartType} label="Chart Type" onChange={e => setChartType(e.target.value)}>
            <MenuItem value="grid">   📋  Table / Grid</MenuItem>
            <MenuItem value="bar">    📊  Bar Chart</MenuItem>
            <MenuItem value="line">   📈  Line Chart</MenuItem>
            <MenuItem value="area">   🏔   Area Chart</MenuItem>
            <MenuItem value="pie">    🥧  Pie Chart</MenuItem>
            <MenuItem value="metric"> 🔢  KPI / Single Metric</MenuItem>
          </Select>
        </FormControl>

        {needsAxes && (
          <>
            <Divider><Typography variant="caption" color="text.secondary">Axis Configuration</Typography></Divider>

            <FormControl size="small" fullWidth>
              <InputLabel id="sel-dashboardpage-x-axis-category-column">X-Axis / Category column</InputLabel>
              <Select labelId="sel-dashboardpage-x-axis-category-column" value={xField} label="X-Axis / Category column"
                      onChange={e => setXField(e.target.value)}>
                {cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
              </Select>
            </FormControl>

            <FormControl size="small" fullWidth>
              <InputLabel id="sel-dashboardpage-y-axis-value-column">Y-Axis / Value column</InputLabel>
              <Select labelId="sel-dashboardpage-y-axis-value-column" value={yField} label="Y-Axis / Value column"
                      onChange={e => setYField(e.target.value)}>
                {numCols.length > 0
                  ? numCols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)
                  : cols.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)
                }
              </Select>
            </FormControl>

            <FormControl size="small" fullWidth>
              <InputLabel id="sel-dashboardpage-aggregation">Aggregation</InputLabel>
              <Select labelId="sel-dashboardpage-aggregation" value={aggFn} label="Aggregation"
                      onChange={e => setAggFn(e.target.value)}>
                <MenuItem value="sum">Sum</MenuItem>
                <MenuItem value="avg">Average</MenuItem>
                <MenuItem value="count">Count</MenuItem>
                <MenuItem value="max">Maximum</MenuItem>
                <MenuItem value="min">Minimum</MenuItem>
              </Select>
            </FormControl>

            {xField && yField && (
              <Alert severity="info" sx={{ fontSize:12 }}>
                Will show: <strong>{aggFn.toUpperCase()}({yField})</strong> grouped by <strong>{xField}</strong> · top 40 groups
              </Alert>
            )}
          </>
        )}
    </AppDialog>
  );
}

// ── Widget card ────────────────────────────────────────────────────────────────
function WidgetCard({ widget, loadDelay = 0, onDelete, onEdit, onChartTypeChange, cardStyle,
                      crossFilters = [], onCrossFilter, filterValues, refreshToken = 0 }: any) {
  const [rows,      setRows]      = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState('');
  const [chartType, setChartType] = useState(widget.chart_type || 'grid');
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [needs,     setNeeds]     = useState<DeclaredParam[]>([]);
  // 2026-09-28 -- the readiness verdict the last run of a finance-report
  // tile was served under (from the execute envelope); null for other tiles
  const [readiness, setReadiness] = useState<any>(null);
  // 2026-10-26 -- a finance report's run, for its canvas (ReportCanvasTile)
  const [brRun, setBrRun] = useState<{ id: string; total: number | null; truncated: boolean } | null>(null);
  // The values this tile runs with: its own, then each dashboard filter it
  // declares (dashboardParams.ts -- the export applies the same rule).
  const effective = useMemo(
    () => effectiveWidgetParams(widget, widget.declared_params, filterValues),
    [widget.param_values, widget.declared_params, filterValues]);
  const effectiveKey = JSON.stringify(effective);

  useEffect(() => {
    if (loadDelay === 0) { loadData(); return; }
    const t = setTimeout(() => loadData(), loadDelay);
    return () => clearTimeout(t);
  }, [widget.source_id, widget.widget_type, effectiveKey, refreshToken]);

  // Sync chart type when parent updates it
  useEffect(() => { setChartType(widget.chart_type || 'grid'); }, [widget.chart_type]);

  const loadData = async () => {
    setLoading(true);
    setError('');
    // A required parameter with no value: say which, instead of running (a
    // report refuses; a query would compare against the placeholder text).
    const missing = missingRequired(widget.declared_params, effective);
    setNeeds(missing);
    if (missing.length) { setRows([]); setLoading(false); return; }
    try {
      if (widget.widget_type === 'business_report') {
        const run = await api.executeBusinessReport(widget.source_id, { parameter_values: effective });
        if (run?.execution_id) markExecutionQuiet(run.execution_id);
        setReadiness(run?.readiness || null);
        const page = await api.getBusinessReportPagedResults(widget.source_id, run.execution_id, 1, 500);
        setRows(page?.rows || []);
        setBrRun(run?.execution_id ? { id: run.execution_id,
          total: typeof page?.total_rows === 'number' ? page.total_rows : null, truncated: page?.truncated === true } : null);
        setLastUpdated(new Date());
        return;
      }
      if (widget.widget_type === 'report') {
        // FB-60 (2026-09-26): a tile saved against the retired parametric
        // entity.  Say so in the tile; never spin or show an empty grid.
        setError('This tile used a retired report type (legacy parametric). '
          + 'Remove it and add the report as a Finance Report tile.');
        setRows([]); setLoading(false); return;
      }
      let execResp;
      const hasParams = Object.keys(effective).length > 0;
      if (widget.widget_type === 'saved_query')
        execResp = await api.executeQuery({ query_id: widget.source_id, ...(hasParams ? { params: effective } : {}) });
      else if (widget.widget_type === 'sql_query')
        execResp = await api.executeSqlQuery({ query_id: widget.source_id });

      if (!execResp) { setLoading(false); return; }
      // rendered in place: its completion is logged, not toasted
      markExecutionQuiet(execResp.execution_id);

      const fetchResults = async (execId) => {
        const res = await api.getExecutionResults(execId, 1, 500);
        setRows(res?.rows || res?.data || []);
        setLastUpdated(new Date());
      };

      if (execResp.status === 'completed' || execResp.cache_hit) {
        await fetchResults(execResp.execution_id);
        setLoading(false);
        return;
      }

      const execId = execResp.execution_id;
      for (let i = 0; i < 30; i++) {
        await new Promise(r => setTimeout(r, 1000));
        const status = await api.getExecutionStatus(execId);
        if (status?.status === 'completed') { await fetchResults(execId); break; }
        if (status?.status === 'failed') { setError(status.error_message || 'Query failed'); break; }
      }
    } catch (e) {
      setError(e.message || 'Failed to load');
    } finally {
      setLoading(false);
    }
  };

  const handleChartType = (_, val) => {
    if (!val) return;
    setChartType(val);
    onChartTypeChange(widget.id, val);
  };

  const cols    = rows.length ? Object.keys(rows[0]) : [];
  const numCols = cols.filter(c => isNumCol(rows, c));
  const strCols = cols.filter(c => !isNumCol(rows, c));

  // Summary stat / axis description for header
  const headerStat = useMemo(() => {
    if (!rows.length) return null;
    const cfg = widget.chart_config || {};
    const ct  = widget.chart_type || chartType;
    const xKey = cfg.x_field || strCols[0] || cols[0];
    const yKey = cfg.y_field || numCols[0] || cols[1] || cols[0];
    const aggFn = cfg.agg_fn || 'sum';
    // For chart types show "SUM(col) by col · N groups"
    if (ct !== 'grid' && ct !== 'metric' && xKey && yKey && numCols.includes(yKey)) {
      const agg = aggregateRows(rows, xKey, yKey, aggFn);
      const total = agg.reduce((s, r) => s + r.value, 0);
      return `${aggFn.toUpperCase()}(${yKey}) by ${xKey} · ${agg.length} groups · ${fmtNum(Math.round(total * 100) / 100)} total`;
    }
    if (cfg.y_field && numCols.includes(cfg.y_field)) {
      const sum = rows.reduce((s, r) => s + Number(r[cfg.y_field] || 0), 0);
      return `${fmtNum(Math.round(sum * 100) / 100)} total · ${rows.length.toLocaleString()} rows`;
    }
    return `${rows.length.toLocaleString()} rows · ${cols.length} columns`;
  }, [rows, widget.chart_config, widget.chart_type, chartType]);

  const hdrBg   = cardStyle?.headerBg || 'linear-gradient(135deg,#f8fafc 0%,#f1f5f9 100%)';
  const isDark  = cardStyle?.dark || false;
  const txtCol  = isDark ? '#f1f5f9' : undefined;
  const subCol  = isDark ? '#94a3b8' : 'text.secondary';

  return (
    <Paper elevation={2} sx={{ height:'100%', display:'flex', flexDirection:'column',
                                overflow:'hidden', borderRadius:2,
                                bgcolor: isDark ? '#1e293b' : undefined }}>
      {/* Header */}
      <Box sx={{ px:1.5, py:0.75, borderBottom:1,
                 borderColor: isDark ? 'rgba(255,255,255,0.1)' : 'divider',
                 display:'flex', alignItems:'center', gap:0.5, minHeight:42,
                 background: hdrBg }}>
        <DragIcon fontSize="small" sx={{ color:'text.disabled', cursor:'grab', flexShrink:0 }}
                  className="drag-handle" />

        <Box sx={{ flex:1, overflow:'hidden', mr:0.5 }}>
          <Typography variant="subtitle2" fontWeight={700} fontSize={13} noWrap
                      sx={{ color: txtCol }}>
            {widget.title || 'Untitled Widget'}
          </Typography>
          {!loading && headerStat && (
            <Typography variant="caption" color={subCol}
                        sx={{ display:'block', lineHeight:1.2 }}>
              {headerStat}
              {lastUpdated && ` · ${lastUpdated.toLocaleTimeString()}`}
            </Typography>
          )}
        </Box>
        {/* 2026-09-28 -- is the data for the business date complete? The
            chip self-hides for tiles that are not finance reports, and for
            a report that declares nothing (nothing is claimed). */}
        {!loading && readiness && (
          <ReadinessChip readiness={readiness} compact sx={{ height: 20, fontSize: 11, mr: 0.5 }} />
        )}

        {/* Chart type toggles */}
        <ToggleButtonGroup size="small" value={chartType} exclusive onChange={handleChartType}
                           sx={{ '& .MuiToggleButton-root':{ py:0, px:0.4, minWidth:26, fontSize:11 } }}>
          <ToggleButton value="grid" aria-label="Table"><Tooltip title="Table"><TableIcon    sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="bar" aria-label="Bar chart"><Tooltip title="Bar Chart"><BarChartIcon sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="line" aria-label="Line chart"><Tooltip title="Line Chart"><LineIcon      sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="area" aria-label="Area chart"><Tooltip title="Area Chart"><AreaChartIcon sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="pie" aria-label="Pie chart"><Tooltip title="Pie Chart"><PieChartIcon  sx={{ fontSize:13 }} /></Tooltip></ToggleButton>
          <ToggleButton value="metric" aria-label="KPI"><Tooltip title="KPI"><Typography variant="caption" fontWeight={700}>KPI</Typography></Tooltip></ToggleButton>
        </ToggleButtonGroup>

        <Tooltip title="Refresh"><IconButton size="small" onClick={loadData}><RefreshIcon sx={{ fontSize:14 }} /></IconButton></Tooltip>
        <IconButton aria-label="More actions" size="small" onClick={e => setMenuAnchor(e.currentTarget)}><MoreIcon sx={{ fontSize:14 }} /></IconButton>

        <Menu anchorEl={menuAnchor} open={Boolean(menuAnchor)} onClose={() => setMenuAnchor(null)}>
          <MenuItem onClick={() => { setMenuAnchor(null); onEdit(widget, rows); }}>
            <EditIcon fontSize="small" sx={{ mr:1 }} /> Edit &amp; Configure
          </MenuItem>
          <MenuItem onClick={() => { setMenuAnchor(null); loadData(); }}>
            <RefreshIcon fontSize="small" sx={{ mr:1 }} /> Refresh data
          </MenuItem>
          <Divider />
          <MenuItem onClick={() => { setMenuAnchor(null); onDelete(widget.id); }}
                    sx={{ color:'error.main' }}>
            <DeleteIcon fontSize="small" sx={{ mr:1 }} /> Remove widget
          </MenuItem>
        </Menu>
      </Box>

      {/* Config hint banner — shown when chart needs axes but none configured */}
      {!loading && !error && rows.length > 0 && chartType !== 'grid' &&
       !widget.chart_config?.x_field && (
        <Box sx={{ px:1.5, py:0.5, bgcolor:'info.50', borderBottom:1, borderColor:'info.200',
                   display:'flex', alignItems:'center', justifyContent:'space-between', gap:1 }}>
          <Typography variant="caption" color="info.dark">
            Auto-detected axes — click <strong>Edit &amp; Configure</strong> to set precise columns
          </Typography>
          <Button size="small" variant="text" sx={{ py:0, fontSize:11 }}
                  onClick={() => onEdit(widget, rows)}>Configure</Button>
        </Box>
      )}

      {/* Content */}
      <Box sx={{ flex:1, overflow:'hidden', p: chartType === 'grid' ? 0 : 1, minHeight:0 }}>
        {loading ? (
          <Box sx={{ p:1.5 }}>
            <Skeleton variant="rectangular" height={30} sx={{ mb:1, borderRadius:1 }} />
            <Skeleton variant="rectangular" height={80} sx={{ mb:1, borderRadius:1 }} />
            <Skeleton variant="rectangular" height={50} sx={{ borderRadius:1 }} />
          </Box>
        ) : error ? (
          <Box sx={{ p:1 }}>
            <Alert severity="error" sx={{ fontSize:12 }}>{error}</Alert>
          </Box>
        ) : needs.length ? (
          <Box sx={{ p:1 }} data-testid="widget-needs-values">
            <Alert severity="info" sx={{ fontSize:12 }}
                   action={<Button size="small" onClick={() => onEdit(widget, rows)}>Set values</Button>}>
              This tile needs a value for {needs.map(p => p.label || p.name).join(', ')}.
              Set it in the dashboard filters, or in this tile's settings.
            </Alert>
          </Box>
        ) : widget.widget_type === 'business_report' && brRun ? (
          <ReportCanvasTile reportId={widget.source_id} executionId={brRun.id} totalRows={brRun.total}
            truncated={brRun.truncated}
            fallback={
              <ChartRenderer
                chartType={chartType}
                rows={applyCrossFilters(rows, crossFilters || [], widget.id)}
                config={widget.chart_config || {}}
                onNeedConfig={() => onEdit(widget, rows)}
                onCrossFilter={onCrossFilter ? (col: string, val: string) => onCrossFilter(widget.id, col, val) : undefined}
              />} />
        ) : (
          <ChartRenderer
            chartType={chartType}
            rows={applyCrossFilters(rows, crossFilters || [], widget.id)}
            config={widget.chart_config || {}}
            onNeedConfig={() => onEdit(widget, rows)}
            onCrossFilter={onCrossFilter ? (col: string, val: string) => onCrossFilter(widget.id, col, val) : undefined}
          />
        )}
      </Box>
    </Paper>
  );
}

// ── Placeholder slot card ──────────────────────────────────────────────────────
function PlaceholderCard({ slotIndex, onAdd, isDark }) {
  return (
    <Box {...clickable(onAdd, { label: `Add a widget to slot ${slotIndex + 1}` })} sx={{
      height: '100%', borderRadius: 2, cursor: 'pointer',
      border: '2px dashed', borderColor: isDark ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.15)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      gap: 1, bgcolor: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(255,255,255,0.55)',
      transition: 'all .2s',
      '&:hover': {
        borderColor: 'primary.main', bgcolor: 'primary.50',
        '& .slot-icon': { transform: 'scale(1.15)', color: 'primary.main' },
      },
    }}>
      <Box className="slot-icon" sx={{
        width: 44, height: 44, borderRadius: '50%',
        bgcolor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all .2s',
      }}>
        <AddIcon sx={{ fontSize: 22, color: isDark ? 'rgba(255,255,255,0.4)' : 'text.disabled' }} />
      </Box>
      <Typography variant="caption" fontWeight={600}
                  sx={{ color: isDark ? 'rgba(255,255,255,0.5)' : 'text.secondary' }}>
        Slot {slotIndex + 1}
      </Typography>
      <Typography variant="caption" sx={{ fontSize: 10,
                  color: isDark ? 'rgba(255,255,255,0.3)' : 'text.disabled' }}>
        Click to add widget
      </Typography>
    </Box>
  );
}

// ── Add Widget Dialog ──────────────────────────────────────────────────────────
function AddWidgetDialog({ open, onClose, onAdd, slotPosition }: { open: boolean; onClose: () => void; onAdd: (data: any) => void; slotPosition: any }) {
  const [queries,    setQueries]    = useState([]);
  const [sqlQueries, setSqlQueries] = useState([]);
  const [finReports, setFinReports] = useState([]);
  const [params,     setParams]     = useState<DeclaredParam[]>([]);
  const [paramVals,  setParamVals]  = useState<Record<string, any>>({});
  const [type,       setType]       = useState('business_report');
  const [sourceId,   setSourceId]   = useState('');
  const [title,      setTitle]      = useState('');
  const [chartType,  setChartType]  = useState('grid');

  useEffect(() => {
    if (!open) return;
    // BF-428P: toArray defends against backend wrapper / null / 401-error
    api.listQueries().then(d => setQueries(toArray(d))).catch(() => {});
    api.listSqlQueries().then(d => setSqlQueries(toArray(d))).catch(() => {});
    api.listBusinessReports({ limit: 200, include_samples: true })
      .then(d => setFinReports(toArray(d))).catch(() => {});
    setSourceId(''); setTitle(''); setChartType('grid'); setParams([]); setParamVals({});
  }, [open]);

  const sources = type === 'saved_query' ? queries
    : type === 'business_report' ? finReports : sqlQueries;

  // The chosen source's parameters, so the tile is not added unable to run.
  useEffect(() => {
    setParams([]); setParamVals({});
    if (!sourceId) return;
    if (type === 'business_report') {
      api.listBusinessReportParams(Number(sourceId)).then((rows: any) => {
        setParams(toArray(rows).map((p: any) => ({
          name: p.name, label: p.label || p.name, type: p.parameter_type,
          required: !!p.is_required, default: p.default_value,
          options: p.static_values || [],
          lov: p.lov_column_id && !p.static_values ? { report_id: Number(sourceId), parameter_id: p.id } : null,
        })));
      }).catch(() => {});
    }
  }, [type, sourceId]);

  const handleAdd = () => {
    if (!sourceId) return;
    const src = sources.find(s => String(s.id) === String(sourceId));
    const layout = slotPosition
      ? { x: slotPosition.x, y: slotPosition.y, w: slotPosition.w, h: slotPosition.h }
      : { x: 0, y: 0, w: 6, h: 5 };
    onAdd({
      widget_type:  type,
      source_id:    Number(sourceId),
      title:        title || src?.name || 'Widget',
      chart_type:   chartType,
      chart_config: {},
      ...(params.length ? { param_values: nonEmptyParams(paramVals) } : {}),
      layout,
    });
    onClose();
  };

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="sm"
      title={<>{slotPosition ? `Fill Slot — ${slotPosition.w}×${slotPosition.h} panel` : 'Add Widget'}</>}
      contentSx={{ display:'flex', flexDirection:'column', gap:2, pt:2 }}
      actions={<>
        <Button onClick={onClose}>Cancel</Button>
        <Button onClick={handleAdd} variant="contained" disabled={!sourceId}>
          Add Widget
        </Button>
      </>}>
        <FormControl size="small" fullWidth>
          <InputLabel id="sel-dashboardpage-source-type">Source Type</InputLabel>
          <Select labelId="sel-dashboardpage-source-type" value={type} label="Source Type"
                  onChange={e => { setType(e.target.value); setSourceId(''); }}>
            {WIDGET_SOURCES.map(o => <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>)}
          </Select>
        </FormControl>

        <FormControl size="small" fullWidth>
          <InputLabel id="sel-dashboardpage-select-query-report">Select Query / Report</InputLabel>
          <Select labelId="sel-dashboardpage-select-query-report" value={sourceId} label="Select Query / Report"
                  onChange={e => setSourceId(e.target.value)}>
            {sources.map(s => (
              <MenuItem key={s.id} value={String(s.id)}>
                {s.name}
                {s.description && (
                  <Typography variant="caption" color="text.secondary" sx={{ ml:1 }}>
                    — {s.description}
                  </Typography>
                )}
              </MenuItem>
            ))}
            {sources.length === 0 && (
              <MenuItem disabled>None found</MenuItem>
            )}
          </Select>
        </FormControl>

        {params.length > 0 && (
          <Box>
            <Typography variant="caption" color="text.secondary">
              Parameter values (a dashboard filter on the same parameter overrides these)
            </Typography>
            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mt: 1 }}>
              <ParamInputs idPrefix="add-w" params={params} values={paramVals}
                           onChange={(n, v) => setParamVals(prev => ({ ...prev, [n]: v }))} />
            </Box>
          </Box>
        )}

        <TextField label="Widget Title (optional)" size="small" fullWidth
                   value={title} onChange={e => setTitle(e.target.value)}
                   placeholder="Leave blank to use query name" />

        <FormControl size="small" fullWidth>
          <InputLabel id="sel-dashboardpage-initial-view">Initial View</InputLabel>
          <Select labelId="sel-dashboardpage-initial-view" value={chartType} label="Initial View"
                  onChange={e => setChartType(e.target.value)}>
            <MenuItem value="grid">   📋  Table (recommended — configure chart after)</MenuItem>
            <MenuItem value="bar">    📊  Bar Chart</MenuItem>
            <MenuItem value="line">   📈  Line Chart</MenuItem>
            <MenuItem value="area">   🏔   Area Chart</MenuItem>
            <MenuItem value="pie">    🥧  Pie Chart</MenuItem>
            <MenuItem value="metric"> 🔢  KPI / Single Metric</MenuItem>
          </Select>
        </FormControl>

        <Alert severity="info" sx={{ fontSize:12 }}>
          After adding the widget, use <strong>⋮ → Edit &amp; Configure</strong> to set exact X/Y axes and aggregation for charts.
        </Alert>
    </AppDialog>
  );
}

// ── Share Links Dialog ─────────────────────────────────────────────────────────
// 2026-08-23: a public dashboard link had no lifecycle UI — every "Share" click
// minted a fresh token and there was no way to see or REVOKE the ones already
// out.  This dialog lists a dashboard's share tokens and lets the owner/admin
// mint a new link, copy any active link, and revoke any link (the concrete
// control for a leaked/over-shared link, or a departed user's shares).
function ShareLinksDialog({ open, dashboardId, onClose, onNotify }:
    { open: boolean; dashboardId: number | null; onClose: () => void; onNotify: (m: string) => void }) {
  const [shares,  setShares]  = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy,    setBusy]    = useState(false);

  const load = useCallback(async () => {
    if (dashboardId == null) return;
    setLoading(true);
    try { setShares(toArray(await api.listDashboardShares(dashboardId))); }
    finally { setLoading(false); }
  }, [dashboardId]);

  useEffect(() => { if (open) load(); }, [open, load]);

  const linkFor = (token: string) => `${window.location.origin}/shared-dashboard/${token}`;
  const isExpired = (s: any) => s.expires_at && new Date(s.expires_at) < new Date();

  const handleCreate = async () => {
    if (dashboardId == null) return;
    setBusy(true);
    try {
      const share = await api.createDashboardShare(dashboardId);
      await navigator.clipboard.writeText(linkFor(share.token)).catch(() => {});
      onNotify('New public link created and copied to clipboard.');
      await load();
    } catch (_) { onNotify('Failed to create share link'); }
    finally { setBusy(false); }
  };

  const handleCopy = async (token: string) => {
    await navigator.clipboard.writeText(linkFor(token)).catch(() => {});
    onNotify('Link copied to clipboard.');
  };

  const handleRevoke = async (token: string) => {
    if (dashboardId == null) return;
    setBusy(true);
    try {
      await api.revokeDashboardShare(dashboardId, token);
      onNotify('Link revoked — it can no longer open this dashboard.');
      await load();
    } catch (_) { onNotify('Failed to revoke link'); }
    finally { setBusy(false); }
  };

  const active = shares.filter(s => s.is_active && !isExpired(s));

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="sm"
      title={<>
        <LinkIcon fontSize="small" /> Public share links
      </>}
      actions={<>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" startIcon={<LinkIcon />} disabled={busy}
                onClick={handleCreate}>
          Create link
        </Button>
      </>}>
        <Alert severity="info" sx={{ mb: 2 }}>
          Anyone with an active link can view this dashboard without signing in.
          Revoke a link to cut off access immediately.
        </Alert>
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}><CircularProgress size={26} /></Box>
        ) : shares.length === 0 ? (
          <Typography color="text.secondary" sx={{ py: 2, textAlign: 'center' }}>
            No share links yet. Create one to share this dashboard publicly.
          </Typography>
        ) : (
          <Stack spacing={1}>
            {shares.map((s) => {
              const dead = !s.is_active || isExpired(s);
              return (
                <Paper key={s.token} variant="outlined"
                       sx={{ p: 1.25, display: 'flex', alignItems: 'center', gap: 1,
                             opacity: dead ? 0.6 : 1 }}>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography variant="body2" fontFamily="monospace" noWrap>
                      …/{String(s.token).slice(0, 12)}…
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {s.created_by ? `by ${s.created_by} · ` : ''}
                      {s.access_count ?? 0} view{(s.access_count ?? 0) === 1 ? '' : 's'}
                      {s.expires_at ? ` · expires ${new Date(s.expires_at).toLocaleDateString()}` : ''}
                    </Typography>
                  </Box>
                  {!s.is_active
                    ? <Chip size="small" label="Revoked" color="default" />
                    : isExpired(s)
                      ? <Chip size="small" label="Expired" color="warning" />
                      : <Chip size="small" label="Active" color="success" />}
                  <Tooltip title="Copy link">
                    <span>
                      <IconButton aria-label="Copy link" size="small" disabled={dead || busy}
                                  onClick={() => handleCopy(s.token)}>
                        <CopyIcon fontSize="small" />
                      </IconButton>
                    </span>
                  </Tooltip>
                  <Tooltip title="Revoke link">
                    <span>
                      <IconButton aria-label="Revoke link" size="small" color="error" disabled={!s.is_active || busy}
                                  onClick={() => handleRevoke(s.token)}>
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </span>
                  </Tooltip>
                </Paper>
              );
            })}
          </Stack>
        )}
        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 2 }}>
          {active.length} active link{active.length === 1 ? '' : 's'}.
        </Typography>
    </AppDialog>
  );
}

// ── Main DashboardPage ─────────────────────────────────────────────────────────
export default function DashboardPage() {
  // Mobile consumption (2026-08-09): a phone REFLOWS the dashboard into a
  // single stacked column instead of horizontally scrolling the 12-col
  // desktop grid.  Same raw-query convention as Layout.tsx.
  const isPhone = useMediaQuery('(max-width:600px)');
  const [searchParams, setSearchParams] = useSearchParams();
  const [dashboards,    setDashboards]    = useState([]);
  const [selected,      setSelected]      = useState(null);
  const [widgets,       setWidgets]       = useState([]);
  const [layouts,       setLayouts]       = useState([]);
  const [addOpen,       setAddOpen]       = useState(false);
  const [createOpen,    setCreateOpen]    = useState(false);
  const [editWidget,    setEditWidget]    = useState(null);   // {widget, rows}
  // Phase 142 — persist new-dashboard draft so user can come back to
  // a half-named dashboard after refresh / pod restart.
  const [newName, setNewName] = useServerDraft<string>('dashboard.new.name', '');
  const [newDesc, setNewDesc] = useServerDraft<string>('dashboard.new.desc', '');
  const [snack,         setSnack]         = useState('');
  const [containerWidth, setContainerWidth] = useState(1200);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [layoutOpen,    setLayoutOpen]    = useState(false);
  const [pendingSlot,   setPendingSlot]   = useState(null);   // slot clicked from placeholder
  const [newTemplate,   setNewTemplate]   = useState(null);   // chosen during create dialog
  const [crossFilters, setCrossFilters] = useState<CrossFilter[]>([]);
  const [filterValues, setFilterValues] = useState<Record<string, any>>({});
  const [filtersOpen,  setFiltersOpen]  = useState(false);
  const [refreshToken, setRefreshToken] = useState(0);
  const [autoRefresh,  setAutoRefresh]  = useState(0);          // minutes; 0 = off
  const [exportAnchor, setExportAnchor] = useState(null);
  const [styleMenuAnchor, setStyleMenuAnchor] = useState(null);
  const [dashStyle,     setDashStyle]     = useState(() => {
    try { return JSON.parse(localStorage.getItem('qs_dash_style') || 'null') || DASH_STYLES[0]; }
    catch { return DASH_STYLES[0]; }
  });
  const containerRef = useRef(null);

  useEffect(() => { loadDashboards(); }, []);

  // Auto-select dashboard from URL param ?dashboard=ID
  const urlDashId = searchParams.get('dashboard');
  useEffect(() => {
    if (!urlDashId || !dashboards.length) return;
    const target = dashboards.find(d => String(d.id) === urlDashId);
    if (target) setSelected(target);
  }, [urlDashId, dashboards]);

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(entries => {
      setContainerWidth(entries[0]?.contentRect.width || 1200);
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    if (selected) { loadWidgets(selected.id); setCrossFilters([]); }
  }, [selected]);

  // A dashboard opens on its filters' defaults; the auto-refresh choice is
  // remembered per dashboard in this browser.
  useEffect(() => {
    setFilterValues(defaultFilterValues(selected?.filters));
    let m = 0;
    try { m = Number(localStorage.getItem(`qs_dash_autorefresh_${selected?.id}`) || 0); } catch { /* storage blocked */ }
    setAutoRefresh(Number.isFinite(m) ? m : 0);
  }, [selected?.id]);

  useEffect(() => {
    if (!autoRefresh) return;
    const t = setInterval(() => setRefreshToken(n => n + 1), autoRefresh * 60_000);
    return () => clearInterval(t);
  }, [autoRefresh]);

  const chooseAutoRefresh = (m: number) => {
    setAutoRefresh(m);
    try { localStorage.setItem(`qs_dash_autorefresh_${selected?.id}`, String(m)); } catch { /* storage blocked */ }
  };

  const saveFilters = async (filters: DashboardFilter[]) => {
    if (!selected) return;
    const d = await api.updateDashboard(selected.id, { filters });
    const next = { ...selected, filters: d?.filters ?? filters };
    setSelected(next);
    setDashboards(prev => prev.map(x => (x.id === next.id ? { ...x, filters: next.filters } : x)));
    setFilterValues(defaultFilterValues(next.filters));
    setSnack('Filters saved');
  };

  const exportDashboard = async (fmt: 'excel' | 'csv') => {
    setExportAnchor(null);
    if (!selected) return;
    const qs = Object.keys(filterValues).length
      ? `?filter_values=${encodeURIComponent(JSON.stringify(filterValues))}` : '';
    // each path spelled whole: the API-path guard matches literal routes
    const path = fmt === 'excel'
      ? `/api/dashboards/${selected.id}/download-excel`
      : `/api/dashboards/${selected.id}/download-csv`;
    try { await openDownload(`${path}${qs}`); }
    catch (e: any) { setSnack(e?.message || 'Export failed'); }
  };

  const loadDashboards = async () => {
    try {
      const list = await api.listDashboards();
      setDashboards(list);
      if (list.length && !selected) setSelected(list[0]);
    } catch (_) {}
  };

  const loadWidgets = async (dashId) => {
    try {
      const wList = await api.listDashboardWidgets(dashId);
      setWidgets(wList);
      setLayouts(wList.map(w => ({
        i: String(w.id),
        x: w.layout?.x ?? 0, y: w.layout?.y ?? 0,
        w: w.layout?.w ?? 6,  h: w.layout?.h ?? 5,
        minW: 2, minH: 3,
      })));
    } catch (_) {}
  };

  const handleLayoutChange = useCallback(async (newLayout) => {
    setLayouts(newLayout);
    if (!selected) return;
    try { await api.updateDashboardLayout(selected.id, newLayout); } catch (_) {}
  }, [selected]);

  const handleAddWidget = async (data) => {
    if (!selected) return;
    try {
      const w = await api.createWidget(selected.id, data);
      setWidgets(prev => [...prev, w]);
      // the new tile's parameters are now bindable by a filter
      setLayouts(prev => [...prev, {
        i: String(w.id), x:0, y:Infinity,
        w: data.layout?.w || 6, h: data.layout?.h || 5, minW:2, minH:3,
      }]);
      setSnack('Widget added');
    } catch (e) { setSnack('Failed to add widget'); }
  };

  const handleDeleteWidget = async (widgetId) => {
    if (!selected) return;
    try {
      await api.deleteWidget(selected.id, widgetId);
      setWidgets(prev => prev.filter(w => w.id !== widgetId));
      setLayouts(prev => prev.filter(l => l.i !== String(widgetId)));
      setSnack('Widget removed');
    } catch (_) {}
  };

  const handleChartTypeChange = async (widgetId, chartType) => {
    if (!selected) return;
    try {
      await api.updateWidget(selected.id, widgetId, { chart_type: chartType });
      setWidgets(prev => prev.map(w =>
        w.id === widgetId ? { ...w, chart_type: chartType } : w
      ));
    } catch (_) {}
  };

  const handleEditOpen = (widget, rows) => {
    setEditWidget({ widget, rows });
  };

  const handleEditSave = async (updates) => {
    if (!editWidget || !selected) return;
    const { widget } = editWidget;
    try {
      const updated = await api.updateWidget(selected.id, widget.id, updates);
      setWidgets(prev => prev.map(w => w.id === widget.id
        ? { ...w, ...updates, declared_params: w.declared_params } : w));
      setSnack('Widget updated');
    } catch (_) { setSnack('Failed to save'); }
  };

  const handleCreateDashboard = async () => {
    if (!newName.trim()) return;
    try {
      const d = await api.createDashboard({ name: newName.trim(), description: newDesc.trim() });
      // Store chosen template for this dashboard
      if (newTemplate) localStorage.setItem(`qs_dash_tpl_${d.id}`, newTemplate.id);
      setDashboards(prev => [...prev, d]);
      setSelected(d);
      setWidgets([]); setLayouts([]);
      setNewName(''); setNewDesc(''); setNewTemplate(null);
      setCreateOpen(false);
      setSnack(newTemplate ? `Dashboard created with ${newTemplate.name} layout` : 'Dashboard created');
    } catch (_) {}
  };

  const handleApplyLayout = async (preset) => {
    if (!selected) return;
    // Store as active template for placeholders
    localStorage.setItem(`qs_dash_tpl_${selected.id}`, preset.id);
    if (widgets.length) {
      const newLayouts = widgets.map((w, i) => {
        const slot = preset.slots[i] || { x:0, y: Math.floor(i/2)*5, w:6, h:5 };
        return { i: String(w.id), ...slot, minW:2, minH:3 };
      });
      setLayouts(newLayouts);
      try { await api.updateDashboardLayout(selected.id, newLayouts); } catch (_) {}
    }
    setSnack(`Template applied: ${preset.name} — click slots to fill them`);
  };

  const handleSetStyle = (style) => {
    setDashStyle(style);
    // BF-427: safeStringify — style param is loosely typed and is sometimes
    // forwarded straight from a menu onClick handler.
    try { localStorage.setItem('qs_dash_style', safeStringify(style)); } catch {}
    setStyleMenuAnchor(null);
  };

  const handleCrossFilter = useCallback((sourceWidgetId: number, column: string, value: string) => {
    setCrossFilters(prev => {
      // Toggle: if same filter exists, remove it; otherwise add it
      const existing = prev.findIndex(f => f.column === column && f.value === value && f.sourceWidgetId === sourceWidgetId);
      if (existing >= 0) return prev.filter((_, i) => i !== existing);
      return [...prev, { column, value, sourceWidgetId }];
    });
  }, []);

  const clearCrossFilters = useCallback(() => setCrossFilters([]), []);


  const handleDeleteDashboard = async () => {
    if (!selected) return;
    try {
      await api.deleteDashboard(selected.id);
      const remaining = dashboards.filter(d => d.id !== selected.id);
      setDashboards(remaining);
      setSelected(remaining[0] || null);
      setWidgets([]); setLayouts([]);
      setSnack('Dashboard deleted');
    } catch (_) {}
  };

  return (
    <Box sx={{ p: { xs: 1, sm: 2 }, height:'100%', display:'flex', flexDirection:'column', gap:0, overflow:'auto' }}>

      {/* Header */}
      <Box sx={{ display:'flex', alignItems:'center', gap:1, mb:1.5, flexWrap:'wrap' }}>
        <DashboardIcon color="primary" />
        <Typography variant="h5" fontWeight={700} sx={{ flex:1 }}>Dashboards</Typography>

        {/* Dashboard selector chips */}
        <Box sx={{ display:'flex', gap:0.5, flexWrap:'wrap', alignItems:'center' }}>
          {dashboards.map(d => (
            <Chip key={d.id} label={d.name}
                  onClick={() => setSelected(d)}
                  variant={selected?.id === d.id ? 'filled' : 'outlined'}
                  color={selected?.id === d.id ? 'primary' : 'default'}
                  size="small" />
          ))}
        </Box>

        {/* Style selector */}
        <Tooltip title={`Dashboard style: ${dashStyle.name}`}>
          <Button size="small" variant="outlined" startIcon={<PaletteIcon />}
                  onClick={e => setStyleMenuAnchor(e.currentTarget)}
                  sx={{ minWidth:0, gap:0.5 }}>
            <Box sx={{ width:12, height:12, borderRadius:'50%', bgcolor:dashStyle.dot, flexShrink:0 }} />
            {dashStyle.name}
          </Button>
        </Tooltip>
        <Menu anchorEl={styleMenuAnchor} open={Boolean(styleMenuAnchor)}
              onClose={() => setStyleMenuAnchor(null)}>
          {DASH_STYLES.map(s => (
            <MenuItem key={s.id} selected={s.id === dashStyle.id}
                      onClick={() => handleSetStyle(s)}
                      sx={{ display:'flex', alignItems:'center', gap:1.5, minWidth:160 }}>
              <Box sx={{ width:18, height:18, borderRadius:'50%', bgcolor:s.dot,
                         border:2, borderColor: s.id===dashStyle.id ? 'primary.main' : 'transparent',
                         flexShrink:0 }} />
              <Box>
                <Typography variant="body2" fontWeight={s.id===dashStyle.id ? 700 : 400}>{s.name}</Typography>
                <Box sx={{ width:80, height:6, borderRadius:1,
                           background: s.headerBg, mt:0.3 }} />
              </Box>
            </MenuItem>
          ))}
        </Menu>

        <Button startIcon={<AddIcon />} variant="outlined" size="small"
                onClick={() => setCreateOpen(true)}>
          New Dashboard
        </Button>

        {selected && (
          <>
            <Button startIcon={<AddIcon />} variant="contained" size="small"
                    onClick={() => { setPendingSlot(null); setAddOpen(true); }}>
              Add Widget
            </Button>
            <Tooltip title="Filters that set a parameter on every tile using it">
              <Button startIcon={<FilterIcon />} variant="outlined" size="small"
                      onClick={() => setFiltersOpen(true)}>
                Filters{selected.filters?.length ? ` (${selected.filters.length})` : ''}
              </Button>
            </Tooltip>
            <Tooltip title="Run every tile again">
              <Button startIcon={<RefreshIcon />} variant="outlined" size="small"
                      onClick={() => setRefreshToken(n => n + 1)}>
                Refresh all
              </Button>
            </Tooltip>
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <InputLabel id="sel-dashboardpage-auto-refresh">Auto-refresh</InputLabel>
              <Select labelId="sel-dashboardpage-auto-refresh" label="Auto-refresh" value={autoRefresh}
                      startAdornment={<AutoRefreshIcon sx={{ fontSize: 16, mr: 0.5, color: 'text.secondary' }} />}
                      onChange={e => chooseAutoRefresh(Number(e.target.value))}>
                <MenuItem value={0}>Off</MenuItem>
                <MenuItem value={1}>Every minute</MenuItem>
                <MenuItem value={5}>Every 5 min</MenuItem>
                <MenuItem value={15}>Every 15 min</MenuItem>
                <MenuItem value={60}>Every hour</MenuItem>
              </Select>
            </FormControl>
            <Button startIcon={<ExportIcon />} variant="outlined" size="small"
                    onClick={e => setExportAnchor(e.currentTarget)}>
              Export
            </Button>
            <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)} onClose={() => setExportAnchor(null)}>
              <MenuItem onClick={() => exportDashboard('excel')}>Excel -- one sheet per tile</MenuItem>
              <MenuItem onClick={() => exportDashboard('csv')}>CSV -- a zip, one file per tile</MenuItem>
            </Menu>
            {/* Layout templates and print are desktop authoring tools — on a
                phone the grid is reflowed to one column anyway. */}
            {!isPhone && (
              <Tooltip title="Apply a layout template to arrange widgets">
                <Button startIcon={<LayoutIcon />} variant="outlined" size="small"
                        onClick={() => setLayoutOpen(true)}>
                  Layout
                </Button>
              </Tooltip>
            )}
            {!isPhone && (
              <Tooltip title="Print dashboard as PDF (browser print dialog)">
                <Button startIcon={<PrintIcon />} variant="outlined" size="small"
                        onClick={() => window.print()}>
                  Print
                </Button>
              </Tooltip>
            )}
            <Tooltip title="Manage public share links for this dashboard">
              <Button startIcon={<LinkIcon />} variant="outlined" size="small"
                      onClick={() => setShareDialogOpen(true)}>
                Share
              </Button>
            </Tooltip>
            <Tooltip title="Delete this dashboard">
              <IconButton size="small" color="error" onClick={handleDeleteDashboard}>
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </>
        )}
      </Box>

      {/* Selected dashboard description */}
      {selected?.description && (
        <Typography variant="body2" color="text.secondary" sx={{ mb:1, pl:0.5 }}>
          {selected.description}
        </Typography>
      )}

      {/* Dashboard filters -- 2026-09-25 */}
      {selected?.filters?.length > 0 && (
        <DashboardFilterBar filters={selected.filters} values={filterValues}
                            onApply={setFilterValues} />
      )}
      <FiltersEditorDialog open={filtersOpen} filters={selected?.filters || []}
                           bindable={bindableParams(widgets)}
                           onClose={() => setFiltersOpen(false)} onSave={saveFilters} />

      {/* Cross-filter chips bar — Phase 63 */}
      {crossFilters.length > 0 && (
        <Box sx={{ display:'flex', gap:0.5, mb:1, flexWrap:'wrap', alignItems:'center', px:0.5 }}>
          <FilterIcon sx={{ fontSize:16, color:'text.secondary' }} />
          <Typography variant="caption" color="text.secondary" sx={{ mr:0.5 }}>Filters:</Typography>
          {crossFilters.map((f, i) => (
            <Chip key={`${f.column}-${f.value}-${i}`} size="small" variant="outlined" color="primary"
                  label={`${f.column} = ${f.value}`}
                  onDelete={() => setCrossFilters(prev => prev.filter((_, j) => j !== i))} />
          ))}
          <Chip size="small" label="Clear all" onClick={clearCrossFilters} variant="outlined" color="default" />
        </Box>
      )}

      {/* Canvas */}
      {(() => {
        const tplId = selected ? localStorage.getItem(`qs_dash_tpl_${selected.id}`) : null;
        const activeTpl = tplId ? PRESET_LAYOUTS.find(p => p.id === tplId) : null;
        // Slots not yet occupied — widgets fill from slot[0] upwards
        const emptySlots = activeTpl ? activeTpl.slots.slice(widgets.length) : [];
        const placeholderLayouts = emptySlots.map((slot, i) => ({
          i: `slot-${i}`, x: slot.x, y: slot.y, w: slot.w, h: slot.h, minW:2, minH:3,
        }));
        const combinedLayouts = [...layouts, ...placeholderLayouts];
        const showGrid = widgets.length > 0 || emptySlots.length > 0;

        return (
          <Box ref={containerRef} sx={{ flex:1, overflow:'auto', borderRadius:2, p:1, minHeight:0,
                                         background: dashStyle.canvasBg, transition:'background .3s' }}>
            {!selected ? (
              <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                         justifyContent:'center', height:300, gap:2 }}>
                <DashboardIcon sx={{ fontSize:56, color:'text.disabled' }} />
                <Typography color="text.secondary">No dashboards yet — create one to get started</Typography>
                <Button variant="contained" startIcon={<AddIcon />} onClick={() => setCreateOpen(true)}>
                  Create Dashboard
                </Button>
              </Box>
            ) : !showGrid ? (
              /* No template, no widgets — prompt to pick a template or add freely */
              <Box sx={{ display:'flex', flexDirection:'column', alignItems:'center',
                         justifyContent:'center', height:300, gap:2 }}>
                <GridIcon sx={{ fontSize:56, color:'text.disabled' }} />
                <Typography color="text.secondary" textAlign="center">
                  Start by picking a layout template, or add widgets freely
                </Typography>
                <Box sx={{ display:'flex', gap:1 }}>
                  <Button variant="contained" startIcon={<LayoutIcon />}
                          onClick={() => setLayoutOpen(true)}>
                    Pick Template
                  </Button>
                  <Button variant="outlined" startIcon={<AddIcon />} onClick={() => { setPendingSlot(null); setAddOpen(true); }}>
                    Add Widget
                  </Button>
                </Box>
              </Box>
            ) : isPhone ? (
              /* Phone: REFLOW into one stacked column — never horizontally
                 scroll the 12-col desktop grid.  Drag/resize is a desktop
                 authoring affordance; consumption keeps refresh, chart-type
                 toggles and cross-filters. */
              <Box data-testid="dashboard-stacked"
                sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                {widgets.map((w, i) => (
                  <Box key={String(w.id)} sx={{ height: 340, width: '100%' }}>
                    <WidgetCard
                      widget={w}
                      loadDelay={i * 400}
                      onDelete={handleDeleteWidget}
                      onEdit={handleEditOpen}
                      onChartTypeChange={handleChartTypeChange}
                      cardStyle={dashStyle}
                      crossFilters={crossFilters}
                      onCrossFilter={handleCrossFilter}
                      filterValues={filterValues}
                      refreshToken={refreshToken}
                    />
                  </Box>
                ))}
                {emptySlots.map((slot, i) => (
                  <Box key={`slot-${i}`} sx={{ height: 140, width: '100%' }}>
                    <PlaceholderCard
                      slotIndex={widgets.length + i}
                      isDark={dashStyle.dark}
                      onAdd={() => { setPendingSlot(slot); setAddOpen(true); }}
                    />
                  </Box>
                ))}
              </Box>
            ) : (
              <GridLayout
                className="layout"
                layout={combinedLayouts}
                {...{ cols: 12 } as any}
                rowHeight={55}
                width={containerWidth - 16}
                onLayoutChange={newLayout => {
                  // Only persist real widget positions
                  const widgetLayouts = newLayout.filter(l => !l.i.startsWith('slot-'));
                  handleLayoutChange(widgetLayouts);
                }}
                draggableHandle=".drag-handle"
                margin={[10, 10]}
              >
                {widgets.map((w, i) => (
                  <div key={String(w.id)}>
                    <WidgetCard
                      widget={w}
                      loadDelay={i * 400}
                      onDelete={handleDeleteWidget}
                      onEdit={handleEditOpen}
                      onChartTypeChange={handleChartTypeChange}
                      cardStyle={dashStyle}
                      crossFilters={crossFilters}
                      onCrossFilter={handleCrossFilter}
                      filterValues={filterValues}
                      refreshToken={refreshToken}
                    />
                  </div>
                ))}
                {emptySlots.map((slot, i) => (
                  <div key={`slot-${i}`}>
                    <PlaceholderCard
                      slotIndex={widgets.length + i}
                      isDark={dashStyle.dark}
                      onAdd={() => { setPendingSlot(slot); setAddOpen(true); }}
                    />
                  </div>
                ))}
              </GridLayout>
            )}
          </Box>
        );
      })()}

      {/* Create Dashboard — name + template picker */}
      <AppDialog open={createOpen}
        onClose={() => { setCreateOpen(false); setNewTemplate(null); }}
        size="md"
        title="New Dashboard"
        contentSx={{ display:'flex', flexDirection:'column', gap:2, pt:1.5 }}
        actions={<>
          <Button onClick={() => { setCreateOpen(false); setNewTemplate(null); }}>Cancel</Button>
          <Button onClick={handleCreateDashboard} variant="contained" disabled={!newName.trim()}>
            Create Dashboard
          </Button>
        </>}>
          <Box sx={{ display:'flex', gap:2 }}>
            <TextField label="Dashboard Name" size="small" required sx={{ flex:1 }}
                       value={newName} onChange={e => setNewName(e.target.value)}
                       onKeyDown={e => e.key === 'Enter' && handleCreateDashboard()} />
            <TextField label="Description (optional)" size="small" sx={{ flex:1 }}
                       value={newDesc} onChange={e => setNewDesc(e.target.value)} />
          </Box>

          <Typography variant="subtitle2" fontWeight={700} sx={{ mt:0.5 }}>
            Choose a Layout Template
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ mt:-1.5 }}>
            Pick a frame for your dashboard. You'll click each slot to fill it with data.
          </Typography>

          <Box sx={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(170px,1fr))', gap:1.5 }}>
            {/* Blank option */}
            <Paper elevation={newTemplate === null ? 3 : 1}
              {...clickable(() => setNewTemplate(null), { label: 'Blank', pressed: newTemplate === null })}
              sx={{ p:1.5, cursor:'pointer', border:2, borderRadius:2,
                    borderColor: newTemplate === null ? 'primary.main' : 'transparent',
                    display:'flex', flexDirection:'column', gap:1, alignItems:'center',
                    transition:'all .15s' }}>
              <Box sx={{ width:150, height:80, bgcolor:'#f1f5f9', borderRadius:1,
                         display:'flex', alignItems:'center', justifyContent:'center' }}>
                <Typography variant="caption" color="text.secondary">Free-form (no template)</Typography>
              </Box>
              <Typography variant="body2" fontWeight={700} fontSize={13}>Blank</Typography>
              <Typography variant="caption" color="text.secondary">Drag widgets freely</Typography>
            </Paper>

            {PRESET_LAYOUTS.map(preset => (
              <Paper key={preset.id} elevation={newTemplate?.id === preset.id ? 3 : 1}
                {...clickable(() => setNewTemplate(preset), { label: preset.name, pressed: newTemplate?.id === preset.id })}
                sx={{ p:1.5, cursor:'pointer', border:2, borderRadius:2,
                      borderColor: newTemplate?.id === preset.id ? 'primary.main' : 'transparent',
                      display:'flex', flexDirection:'column', gap:1, alignItems:'center',
                      transition:'all .15s' }}>
                <LayoutPreview slots={preset.slots} active={newTemplate?.id === preset.id} />
                <Box sx={{ textAlign:'center' }}>
                  <Typography variant="body2" fontWeight={700} fontSize={13}>{preset.name}</Typography>
                  <Typography variant="caption" color="text.secondary">{preset.desc}</Typography>
                </Box>
              </Paper>
            ))}
          </Box>
      </AppDialog>

      {/* Add Widget */}
      <AddWidgetDialog
        open={addOpen}
        onClose={() => { setAddOpen(false); setPendingSlot(null); }}
        onAdd={handleAddWidget}
        slotPosition={pendingSlot}
      />

      {/* Public share links */}
      <ShareLinksDialog
        open={shareDialogOpen}
        dashboardId={selected?.id ?? null}
        onClose={() => setShareDialogOpen(false)}
        onNotify={setSnack}
      />

      {/* Layout Picker */}
      <LayoutPickerDialog
        open={layoutOpen}
        onClose={() => setLayoutOpen(false)}
        onApply={handleApplyLayout}
      />

      {/* Edit Widget */}
      <EditWidgetDialog
        open={Boolean(editWidget)}
        widget={editWidget?.widget}
        rows={editWidget?.rows || []}
        onClose={() => setEditWidget(null)}
        onSave={handleEditSave}
      />

      <Snackbar open={!!snack} autoHideDuration={3000} onClose={() => setSnack('')}
                message={snack} anchorOrigin={{ vertical:'bottom', horizontal:'right' }} />
    </Box>
  );
}
