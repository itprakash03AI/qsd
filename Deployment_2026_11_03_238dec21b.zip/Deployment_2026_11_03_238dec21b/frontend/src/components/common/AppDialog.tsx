/**
 * THE dialog frame -- one look for every fixed dialog in the app (2026-11-01).
 *
 * The owner: "why connection popup doesn't follow same popup ... even query
 * editor popup".  Each screen had built its own MUI Dialog: a title here with
 * an icon, there with a close X, padding 2 here and 3 there, Cancel left of
 * Save in one and right of it in the next.  The look the owner chose is the
 * report DETAIL POPUP (2026-10-31, reports/canvas/canvasActions.tsx), and
 * every dialog now draws through this frame:
 *
 *   - the TITLE BAR: an optional icon, the title (the dialog's accessible
 *     name -- ``aria-labelledby`` points at it), an optional muted subtitle,
 *     optional controls at its right (``titleExtra``) and, when
 *     ``closeButton`` is set, a close X at the far right;
 *   - an optional ``header`` band under the title bar (a Tabs strip) that stays
 *     put while the body scrolls;
 *   - the BODY: MUI's padded DialogContent, divided from the title and the
 *     footer by a rule (``dividers``), scrolling inside the dialog;
 *   - the FOOTER: ``secondaryActions`` on the LEFT (downloads, "Back", a
 *     helper link), then a gap, then ``actions`` on the RIGHT -- Cancel /
 *     Close first, the main (contained) button last;
 *   - anything else MUI's Dialog takes (TransitionProps, keepMounted,
 *     onKeyDown, data-testid ...) is passed straight through;
 *   - the SIZES: ``size`` is MUI's maxWidth (xs confirm, sm short form, md
 *     form / picker, lg detail view, xl workbench), always ``fullWidth``.
 *
 * The frame never owns a field, a validation or a submit: the caller's
 * children and buttons are rendered as they are, so moving a dialog onto it
 * changes how it LOOKS and nothing it does.
 *
 * A movable / resizable window (Feed Run Status, the feed form, the Download
 * Centre preview) is ``FloatingWindow`` -- a different kind of popup; a
 * yes / no / OK question is ``appConfirm`` / ``appAlert`` / ``appPrompt``
 * (appDialogs.tsx), which draws through this frame too.
 */
import React, { useId } from 'react';
import {
  Box, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Typography,
} from '@mui/material';
import type { DialogProps } from '@mui/material';
import type { SxProps, Theme } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';

export type AppDialogSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

export interface AppDialogProps extends Omit<DialogProps, 'open' | 'onClose' | 'title' | 'maxWidth' | 'children'> {
  open: boolean;
  /** called by Escape, a click outside (unless ``closeOnBackdrop`` is false) and the close X */
  onClose?: (event?: unknown, reason?: 'backdropClick' | 'escapeKeyDown' | 'closeButton') => void;
  /** the dialog's name: shown in the title bar and announced as the dialog's accessible name */
  title?: React.ReactNode;
  /** an icon before the title */
  icon?: React.ReactNode;
  /** a muted line under the title */
  subtitle?: React.ReactNode;
  /** controls at the right of the title bar (before the close X) */
  titleExtra?: React.ReactNode;
  /** a band between the title bar and the body that does not scroll with it (a Tabs strip) */
  header?: React.ReactNode;
  /** a close X at the right of the title bar, named ``closeLabel`` */
  closeButton?: boolean;
  closeLabel?: string;
  /** footer, right-hand side: Cancel / Close first, the main button last */
  actions?: React.ReactNode;
  /** footer, left-hand side: secondary buttons */
  secondaryActions?: React.ReactNode;
  size?: AppDialogSize | false;
  fullScreen?: boolean;
  /** false: a click outside does not close (a form with unsaved edits) */
  closeOnBackdrop?: boolean;
  disableEscapeKeyDown?: boolean;
  /** the rule between title / body / footer (default on, the detail popup's look) */
  dividers?: boolean;
  /** ``data-testid`` of the dialog; the title gets ``<testId>-title`` unless ``titleTestId`` says otherwise */
  testId?: string;
  titleTestId?: string;
  /** the title element's id (the dialog's ``aria-labelledby``); generated when absent */
  titleId?: string;
  /** a plain-text accessible name when the title is not plain text, or there is no title */
  ariaLabel?: string;
  paperSx?: SxProps<Theme>;
  titleSx?: SxProps<Theme>;
  contentSx?: SxProps<Theme>;
  actionsSx?: SxProps<Theme>;
  children?: React.ReactNode;
}

/** The footer's padding: the body's horizontal padding, so buttons line up with the content. */
export const APP_DIALOG_ACTIONS_SX = { px: 3, py: 1.5, gap: 1, flexWrap: 'wrap', '& > :not(style) ~ :not(style)': { ml: 0 } } as const;

export default function AppDialog({
  open, onClose, title, icon, subtitle, titleExtra, header, closeButton = false, closeLabel = 'Close',
  actions, secondaryActions, size = 'sm', fullScreen, closeOnBackdrop = true, disableEscapeKeyDown,
  dividers = true, testId, titleTestId, titleId, ariaLabel, paperSx, titleSx, contentSx, actionsSx,
  children, PaperProps: extraPaper, slotProps, ...restDialog
}: AppDialogProps) {
  const autoId = useId();
  const headId = titleId || (testId ? `${testId}-title` : `app-dialog-title-${autoId.replace(/:/g, '')}`);
  const hasTitle = title != null && title !== false && title !== '';
  const handleClose: DialogProps['onClose'] = (event, reason) => {
    if (reason === 'backdropClick' && !closeOnBackdrop) return;
    onClose?.(event, reason);
  };
  // the frame's paper look first, then the caller's: PaperProps (older callers) and slotProps.paper
  const callerPaper: any = { ...(extraPaper || {}), ...(((slotProps as any)?.paper && typeof (slotProps as any).paper === 'object') ? (slotProps as any).paper : {}) };
  const paper = {
    ...callerPaper,
    sx: [{ borderRadius: fullScreen ? 0 : 2 }, ...toArray(paperSx), ...toArray((extraPaper as any)?.sx), ...toArray((slotProps as any)?.paper?.sx)],
  };
  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth={size}
      fullWidth
      fullScreen={fullScreen}
      disableEscapeKeyDown={disableEscapeKeyDown}
      aria-labelledby={hasTitle && !ariaLabel ? headId : undefined}
      aria-label={ariaLabel}
      data-testid={testId}
      {...restDialog}
      slotProps={{ ...(slotProps || {}), paper }}
    >
      {(hasTitle || closeButton || titleExtra) && (
        <DialogTitle
          component="div"
          sx={[{ display: 'flex', alignItems: 'center', gap: 1, py: 1.75, pr: closeButton ? 1.5 : 3 }, ...toArray(titleSx)]}
        >
          {icon && <Box sx={{ display: 'flex', alignItems: 'center', color: 'primary.main' }} aria-hidden>{icon}</Box>}
          <Box sx={{ flex: 1, minWidth: 0 }}>
            {hasTitle && (
              <Typography component="h2" variant="h6" id={headId}
                data-testid={titleTestId ?? (testId ? `${testId}-title` : undefined)}
                sx={{ fontSize: '1.125rem', fontWeight: 600, lineHeight: 1.35, wordBreak: 'break-word' }}>
                {title}
              </Typography>
            )}
            {subtitle && (
              <Typography component="div" variant="body2" color="text.secondary" sx={{ mt: 0.25 }}>
                {subtitle}
              </Typography>
            )}
          </Box>
          {titleExtra}
          {closeButton && (
            <IconButton aria-label={closeLabel} size="small" onClick={e => onClose?.(e, 'closeButton')}
              data-testid={testId ? `${testId}-close-x` : undefined}>
              <CloseIcon fontSize="small" />
            </IconButton>
          )}
        </DialogTitle>
      )}
      {header}
      <DialogContent dividers={dividers} sx={contentSx}>
        {children}
      </DialogContent>
      {(actions || secondaryActions) && (
        <DialogActions sx={[APP_DIALOG_ACTIONS_SX, ...toArray(actionsSx)]}>
          {secondaryActions}
          <Box sx={{ flex: 1 }} />
          {actions}
        </DialogActions>
      )}
    </Dialog>
  );
}

function toArray(sx: any): any[] {
  if (sx == null) return [];
  return Array.isArray(sx) ? sx : [sx];
}
