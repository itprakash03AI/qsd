/**
 * Table VERSIONS -- the pieces every version picker shares (2026-11-01).
 *
 * The SQL page's "Table version" row (components/sql/TableVersionsPanel.tsx)
 * and the report run panel's "Data version" control
 * (components/reports/ReportDataVersionControl.tsx) list the same thing --
 * one Iceberg table's versions, newest first -- from the same server listing
 * (backend connections_api.storage_table_versions), so they read it with the
 * same words: the option text, the time, the as-of input and the "Read at"
 * line that names what a run read and which rule decided.
 */
import React from 'react';
import { MenuItem, Typography } from '@mui/material';

/** One version as the server lists it (core/table_version_access.LISTED_FIELDS). */
export interface TableVersionRow {
  committed_at: string | null;
  snapshot_id: string;
  operation: string | null;
  is_current: boolean;
  added_rows: number | null;
  total_rows: number | null;
  total_files: number | null;
  parent_id?: string | null;
  committed_at_ms?: number | null;
}

/** An ISO time for the date-time input ("2026-10-30T14:02") from epoch ms (UTC). */
export function asOfInputValue(ms: number | null | undefined): string {
  if (!ms) return '';
  return new Date(ms).toISOString().slice(0, 16);
}

/** "2026-10-30 14:02 UTC" from an ISO time; "time not recorded" otherwise. */
export function shortTime(iso: string | null | undefined): string {
  if (!iso) return 'time not recorded';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toISOString().slice(0, 16).replace('T', ' ') + ' UTC';
}

const n = (v: number | null | undefined) => (v === null || v === undefined ? '?' : v.toLocaleString());

/** One option's words: what a support person reads in the list.  A listing
 *  whose counts the server withheld (the person's access to the table's rows
 *  is limited) shows none rather than three question marks. */
export function versionWords(v: TableVersionRow): string {
  const what = v.operation ? `${v.operation}` : 'change';
  const noCounts = v.added_rows == null && v.total_rows == null && v.total_files == null;
  return `${v.snapshot_id} · ${shortTime(v.committed_at)} · ${what}`
    + (noCounts ? '' : ` · +${n(v.added_rows)} rows, ${n(v.total_rows)} rows in ${n(v.total_files)} files`)
    + (v.is_current ? ' · current' : '');
}

/** The MenuItems of a version list (MUI's Select reads its children directly,
 *  so this is a function, not a component). */
export function versionMenuItems(versions: TableVersionRow[] | null | undefined,
                                 testIdPrefix: string, disabled = false): React.ReactNode[] {
  return (versions || []).map((v) => (
    <MenuItem key={v.snapshot_id} value={v.snapshot_id} disabled={disabled}
              data-testid={`${testIdPrefix}-${v.snapshot_id}`}>
      {versionWords(v)}
    </MenuItem>
  ));
}

/** One table of a run record (the server's iceberg_versions entries). */
export interface VersionRead { view?: string; table?: string; words: string; decided_words?: string | null }

/** The result header: which version each table was read at, and which rule decided. */
export const VersionsReadLine: React.FC<{
  versions?: VersionRead[] | null;
  sideLabel?: string;
  testId?: string;
}> = ({ versions, sideLabel, testId = 'versions-read' }) => {
  if (!versions || !versions.length) return null;
  const line = versions.map((v) => (v.decided_words ? `${v.words} (${v.decided_words})` : v.words)).join(' · ');
  return (
    <Typography variant="caption" color="text.secondary" data-testid={testId} sx={{ display: 'block' }}>
      {`Read at${sideLabel ? ` (${sideLabel})` : ''}: ${line}`}
    </Typography>
  );
};
