/**
 * ColumnValuePicker -- a value is PICKED from what the column holds.
 *
 * 2026-10-03 (owner, real Snowflake): "filter value should popup n fill
 * dropdown....cant hardcoded parameter values", "if it's a date it should
 * come from whatever data is available in the table", "even same ways
 * cascading columns".  A report's filter value, a parameter's default and a
 * viewer's parameter choice were free-text boxes and a free calendar, so the
 * author typed how they THOUGHT the data spelled a value -- and an untouched
 * row saved `REGION = ''`, 0 rows behind a 200.
 *
 * One control, every place a value is chosen from a column:
 *
 *  - the list is the column's DISTINCT values from the source, asked for
 *    when the control is opened (never on render -- a DISTINCT scan per
 *    control would sit behind opening a screen) unless `eager`;
 *  - the caller supplies `fetchValues` (the dataset LOV route in the
 *    builder, the report's parameter route in a viewer) and a `fetchKey`
 *    naming WHAT it asks (column + cascade parent selection): a new key
 *    drops the old list and asks again -- that is how a cascade child
 *    refetches when its parent changes;
 *  - LOADING, an ERROR and "no values" are three different states, each
 *    said in words (unknown is not empty);
 *  - a cut list says "first N values -- more exist", and only THEN (or when
 *    the list could not be read) may the author type a value of their own;
 *    a complete list is the whole truth, and a value outside it matches
 *    nothing;
 *  - a DATE column offers the dates that exist (newest first, YYYY-MM-DD,
 *    searchable by typing "2026-09"); when that list is cut it states the
 *    range the data covers and refuses a typed date outside it;
 *  - (2026-11-01, the owner: "dropdown should allow multi select") a
 *    MULTI-select stays OPEN after each pick, shows a checkbox per value,
 *    has "Select all" (the values shown) and "Clear" at the top of its list,
 *    searches as you type (the box IS the search), and shows the picks as
 *    chips -- three, then "+N".
 */
import React from 'react';
import { Autocomplete, Box, Button, Checkbox, Chip, CircularProgress, Paper, TextField, Typography } from '@mui/material';
import { CheckBox as CheckedIcon, CheckBoxOutlineBlank as UncheckedIcon } from '@mui/icons-material';

export interface ValueListAnswer {
  values?: any[];
  truncated?: boolean;
  limit?: number;
  range?: { min: any; max: any } | null;
  range_error?: string;
  /** "nothing was configured to supply values" -- the server's words. */
  reason?: string;
  /** the source could not answer -- the server's words. */
  error?: string;
  /** 2026-10-24 -- WHERE the list came from: static | metadata | table | data,
   *  the table it was read from, whether it was served from the cache, and
   *  the server's note when it had to read elsewhere. */
  source?: string;
  table?: string;
  cached?: boolean;
  source_note?: string;
  /** 2026-10-24 -- a value list's LABEL per key ("GB01" -> "UK Ltd"): shown
   *  beside the key, never sent (the choice filters by the key). */
  labels?: Record<string, string>;
}

/** "From fact_tetb.region · cached" -- where a list came from, in words. */
export function sourceWords(res: ValueListAnswer | null | undefined): string {
  if (!res) return '';
  const cached = res.cached ? ' · cached' : '';
  switch (res.source) {
    case 'static': return 'A saved list';
    // (rig 2026-11-01) a parameter's own list says "From QueryStudio's stored list for Region (refreshed 07:18)"
    // (the server's list_words), never its internal name; a NAMED list people made keeps its name
    case 'list': return (res as any).list_words || `The list ${(res as any).list || ''}${(res as any).synced_at ? ` (refreshed ${String((res as any).synced_at).slice(11, 16)})` : ''}`;
    case 'list-live': return (res as any).list_words || `The list ${(res as any).list || ''}, read live for you`;
    case 'metadata': return `From the partitions of ${res.table || 'the table'}${cached}`;
    case 'table': return `From ${res.table || 'a table'}${cached}`;
    case 'data': return `From the report's data${cached}`;
    default: return '';
  }
}

export type ValueListFetcher = () => Promise<ValueListAnswer>;

type Status = 'idle' | 'loading' | 'ready' | 'error';

interface ListState {
  status: Status;
  values: string[];
  truncated: boolean;
  limit?: number;
  range: { min: string; max: string } | null;
  rangeError: string;
  reason: string;
  error: string;
  sourceLabel: string;
  sourceNote: string;
  labels: Record<string, string>;
}

const IDLE: ListState = {
  status: 'idle', values: [], truncated: false, range: null,
  rangeError: '', reason: '', error: '', sourceLabel: '', sourceNote: '', labels: {},
};

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/** A value as a filter sends it: dates as YYYY-MM-DD, everything a string. */
export function valueToText(v: any): string {
  if (v === null || v === undefined) return '';
  const s = String(v);
  // a midnight timestamp from an older server reads as its date
  const m = /^(\d{4}-\d{2}-\d{2})[T ]00:00:00(\.0+)?Z?$/.exec(s);
  return m ? m[1] : s;
}

export function readValueList(res: ValueListAnswer | null | undefined): ListState {
  if (res?.error) {
    return { ...IDLE, status: 'error', error: String(res.error) };
  }
  const values = (res?.values || []).map(valueToText).filter(v => v !== '');
  const r = res?.range;
  return {
    status: 'ready',
    values,
    truncated: !!res?.truncated,
    limit: res?.limit,
    range: r && r.min != null && r.max != null
      ? { min: valueToText(r.min), max: valueToText(r.max) } : null,
    rangeError: res?.range_error ? String(res.range_error) : '',
    reason: res?.reason ? String(res.reason) : '',
    error: '',
    sourceLabel: sourceWords(res),
    sourceNote: res?.source_note ? String(res.source_note) : '',
    labels: res?.labels || {},
  };
}

/** The control's value in the shape the Autocomplete holds. */
export function currentValue(value: any, multiple: boolean): string | string[] {
  if (multiple) {
    if (Array.isArray(value)) return value.map(valueToText);
    return value ? String(value).split(',').map(x => x.trim()).filter(Boolean) : [];
  }
  if (value === null || value === undefined || Array.isArray(value)) return '';
  return valueToText(value);
}

function readyNote(list: ListState, isDate: boolean, searchable = false): string {
  const parts: string[] = [];
  if (list.sourceLabel) parts.push(`${list.sourceLabel}.`);
  if (list.sourceNote) parts.push(list.sourceNote);
  if (list.reason) parts.push(list.reason);
  else if (!list.values.length) parts.push('The source has no values for this selection.');
  if (list.truncated) {
    // 2026-10-25 (the owner: "parameter values should come from the list, why
    // ask to enter values"): with a server search the person PICKS -- typing
    // searches every value; only without one can a value be entered by hand
    parts.push(searchable
      ? `First ${list.limit ?? list.values.length} values shown -- type to search all of them.`
      : `First ${list.limit ?? list.values.length} values shown -- more exist; type to search or enter another.`);
  }
  if (isDate && list.range) {
    parts.push(`Dates in the data: ${list.range.min} to ${list.range.max}.`);
  } else if (isDate && list.truncated && list.rangeError) {
    parts.push(`The date range could not be read: ${list.rangeError}.`);
  }
  return parts.join(' ');
}

/** What the helper line says: loading, an ERROR, "no values", a cut list
 *  and a date range are each said in words -- unknown is not empty. */
export function describeList(list: ListState, isDate: boolean,
                             typedError: string, searchable = false): { note: string; isError: boolean } {
  if (typedError) return { note: typedError, isError: true };
  switch (list.status) {
    case 'loading': return { note: 'Loading values from the source…', isError: false };
    case 'error':
      return { note: `Could not load the values: ${list.error}. You can type a value instead.`,
               isError: true };
    case 'ready': return { note: readyNote(list, isDate, searchable), isError: false };
    default: return { note: '', isError: false };
  }
}

export interface ColumnValuePickerProps {
  label: string;
  fetchValues: ValueListFetcher;
  /** What the list is OF (column, cascade parent selection).  A new key
   *  drops the list and asks again. */
  fetchKey: string;
  value: string | string[] | null | undefined;
  onChange: (value: any) => void;
  multiple?: boolean;
  /** Date/time column: the dates that exist, a typed date checked. */
  isDate?: boolean;
  /** Ask as soon as it renders (a viewer's prompt), not on open. */
  eager?: boolean;
  /** Always accept a typed value (e.g. a default that may be a token). */
  allowAnyValue?: boolean;
  required?: boolean;
  error?: boolean;
  helperText?: React.ReactNode;
  placeholder?: string;
  disabled?: boolean;
  size?: 'small' | 'medium';
  sx?: any;
  testId?: string;
  /** 2026-10-24 -- type to search ON THE SERVER once the list is cut, so a
   *  value past the first N can still be found (debounced). */
  searchValues?: (q: string) => Promise<ValueListAnswer>;
}

/** The header of a multi-select list: Select all (what is shown) / Clear.
 *  mousedown is swallowed so the list stays open. */
function MultiPickPaper({ children, onAll, onClear, picked, shown, ...rest }: any) {
  return (
    <Paper {...rest}>
      <Box data-testid="multi-pick-bar" onMouseDown={(e: any) => e.preventDefault()}
        sx={{ display: 'flex', alignItems: 'center', gap: 1, px: 1, py: 0.5, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Button size="small" onClick={onAll} disabled={!shown} data-testid="multi-pick-all">Select all</Button>
        <Button size="small" onClick={onClear} disabled={!picked} data-testid="multi-pick-clear">Clear</Button>
        <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto' }} data-testid="multi-pick-count">
          {picked ? `${picked} picked` : 'Pick one or more'}
        </Typography>
      </Box>
      {children}
    </Paper>
  );
}

export function ColumnValuePicker(props: ColumnValuePickerProps) {
  const {
    label, fetchValues, fetchKey, value, onChange, multiple, isDate, eager,
    allowAnyValue, required, error, helperText, placeholder, disabled,
    size = 'small', sx, testId, searchValues,
  } = props;
  const [found, setFound] = React.useState<{ q: string; values: string[]; status: Status } | null>(null);
  const [foundLabels, setFoundLabels] = React.useState<Record<string, string>>({});
  const searchTimer = React.useRef<any>(null);
  React.useEffect(() => () => clearTimeout(searchTimer.current), []);
  const [list, setList] = React.useState<ListState>(IDLE);
  const [typedError, setTypedError] = React.useState('');
  const keyRef = React.useRef(fetchKey);
  const fetchRef = React.useRef(fetchValues);
  fetchRef.current = fetchValues;

  const load = React.useCallback(() => {
    const key = keyRef.current;
    setList(prev => ({ ...prev, status: 'loading', error: '' }));
    fetchRef.current().then(
      res => { if (keyRef.current === key) setList(readValueList(res)); },
      (e: any) => {
        if (keyRef.current !== key) return;
        const msg = typeof e === 'string' ? e
          : (e?.message || e?.detail || 'the values could not be read');
        setList({ ...IDLE, status: 'error', error: String(msg) });
      });
  }, []);

  // A new key is a different question: drop the old answer.
  React.useEffect(() => {
    keyRef.current = fetchKey;
    setList(IDLE);
    setFound(null);
    setTypedError('');
    if (eager && !disabled) load();
  }, [fetchKey, eager, disabled, load]);

  const ensureLoaded = () => {
    if (list.status === 'idle' || list.status === 'error') load();
  };

  // A complete list is the whole truth; a cut or unreadable one is not --
  // but a cut list the SERVER can search is still the truth: typing searches
  // it and the person picks (2026-10-25).  Free typing only when nothing can
  // say which values exist (no search, or the search failed).
  const canType = allowAnyValue || list.status === 'idle'
    || list.status === 'error' || (list.truncated && (isDate || !searchValues || found?.status === 'error'));
  // (a DATE inside the data's range may always be typed: dates are a range, not a list)

  const checkTyped = (v: string): string => {
    if (!isDate || allowAnyValue) return '';
    if (!DATE_RE.test(v)) return `"${v}" is not a date -- use YYYY-MM-DD.`;
    if (list.range && (v < list.range.min || v > list.range.max)) {
      return `${v} is outside the dates in the data (${list.range.min} to ${list.range.max}).`;
    }
    return '';
  };

  const current = currentValue(value, !!multiple);
  // The value already chosen stays visible as an option even when the list
  // (a cut one, or a restored session) does not hold it.
  const chosen = (Array.isArray(current) ? current : [current]).filter(v => v !== '');
  const shown = found && found.status === 'ready' ? found.values : list.values;
  const options = [...shown, ...chosen.filter(v => !shown.includes(v))];

  // Searching on the server only matters for a CUT list: a whole list is
  // already all here and the box filters it as you type.
  const onType = (q: string, reason: string) => {
    if (reason !== 'input' || !searchValues || !list.truncated) return;
    clearTimeout(searchTimer.current);
    const text = q.trim();
    if (!text) { setFound(null); return; }
    searchTimer.current = setTimeout(() => {
      setFound({ q: text, values: [], status: 'loading' });
      searchValues(text).then(
        res => {
          setFoundLabels(prev => ({ ...prev, ...(res?.labels || {}) }));
          setFound(cur => (cur && cur.q === text
            ? { q: text, values: readValueList(res).values, status: 'ready' } : cur));
        },
        () => setFound(cur => (cur && cur.q === text ? { q: text, values: [], status: 'error' } : cur)));
    }, 300);
  };

  const labelOf = (k: string): string => list.labels[k] || foundLabels[k] || '';
  const shownAs = (o: any): string => {
    const k = String(o ?? '');
    const lab = labelOf(k);
    return lab ? `${k} — ${lab}` : k;
  };
  // What the box shows is "KEY — label"; the CHOICE is the key.  A typing box
  // (a cut list) commits its TEXT on blur -- after a pick that is the shown
  // "e71c0 — cb6c0", and the report ran filtered by it: no rows (rig
  // 2026-10-24, the owner's companies on S3).  Shown text -> its key; a label
  // typed exactly that names ONE key -> that key; anything else stays typed.
  const keyOf = (t: any): any => {
    if (typeof t !== 'string' || options.includes(t)) return t;
    const byShown = options.find(o => shownAs(o) === t);
    if (byShown !== undefined) return byShown;
    const byLabel = Object.keys({ ...list.labels, ...foundLabels }).filter(k => labelOf(k) === t);
    return byLabel.length === 1 ? byLabel[0] : t;
  };

  const commit = (raw: any) => {
    const next = multiple ? (raw as any[]).map(keyOf) : keyOf(raw);
    const typed = multiple
      ? (next as string[]).filter(v => !options.includes(v))
      : (next && !options.includes(next) ? [next] : []);
    for (const t of typed) {
      if (!canType) {
        setTypedError(searchValues && list.truncated
          ? `"${t}" is not one of the values -- pick one from the list (type to search all values).`
          : `"${t}" is not a value of this column.`);
        return;
      }
      const problem = checkTyped(String(t));
      if (problem) { setTypedError(problem); return; }
    }
    setTypedError('');
    onChange(next);
  };

  const { note, isError: noteIsError } = describeList(list, !!isDate, typedError, !!searchValues && !isDate);
  const shownHelper = note || helperText;

  return (
    <Autocomplete
      multiple={!!multiple}
      freeSolo={canType}
      autoSelect={canType && !multiple}
      size={size}
      disabled={disabled}
      options={options}
      loading={list.status === 'loading' || found?.status === 'loading'}
      onInputChange={(_e, q, reason) => onType(q, reason)}
      getOptionLabel={shownAs}
      filterOptions={found ? (opts) => opts : undefined}
      value={current as any}
      onOpen={ensureLoaded}
      onChange={(_e, v) => commit(multiple ? (v as string[]) : (v ?? ''))}
      // a multi-select: the list stays open, every value shows its tick
      disableCloseOnSelect={!!multiple}
      filterSelectedOptions={false}
      limitTags={3}
      {...(multiple ? {
        PaperComponent: (pp: any) => (
          <MultiPickPaper {...pp} picked={chosen.length} shown={shown.length}
            onAll={() => commit([...new Set([...chosen, ...shown])])} onClear={() => commit([])} />),
        renderOption: (optProps: any, option: any, { selected }: any) => {
          const { key, ...rest } = optProps;
          return (
            <li key={key ?? String(option)} {...rest} data-testid="multi-pick-option">
              <Checkbox size="small" icon={<UncheckedIcon fontSize="small" />} checkedIcon={<CheckedIcon fontSize="small" />}
                checked={selected} sx={{ mr: 0.5, p: 0.25 }} tabIndex={-1} />
              {shownAs(option)}
            </li>
          );
        },
        renderTags: (tags: any[], getTagProps: any) => tags.map((t, i) => {
          const { key, ...tp } = getTagProps({ index: i });
          return <Chip key={key ?? String(t)} size="small" label={shownAs(t)} {...tp} />;
        }),
      } : {})}
      noOptionsText={found?.status === 'loading' ? 'Searching…'
        : found?.status === 'ready' ? `No value contains "${found.q}"`
        : found?.status === 'error' ? 'The search could not be run'
        : list.status === 'error' ? 'Could not load the values'
        : list.status === 'loading' ? 'Loading…'
        : list.reason || 'No values in the source'}
      sx={sx}
      data-testid={testId}
      renderInput={(params) => (
        <TextField
          {...params}
          label={label}
          required={required}
          placeholder={placeholder ?? (isDate ? 'Pick a date that has data' : 'Pick a value')}
          error={!!error || noteIsError}
          helperText={shownHelper || undefined}
          FormHelperTextProps={{
            role: noteIsError ? 'alert' : undefined,
            'data-testid': testId ? `${testId}-note` : undefined,
          } as any}
          onFocus={ensureLoaded}
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <>
                {list.status === 'loading' ? <CircularProgress color="inherit" size={16} /> : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
        />
      )}
    />
  );
}

export default ColumnValuePicker;
