/**
 * The report screens' ONE control set (2026-11-01; the owner: "use html controls
 * nicer across").  Consistent, modern, named for a screen reader, themed by MUI:
 *
 *  - MultiPick      several values with checkboxes, Select all / Clear and search
 *                   (ColumnValuePicker in its multiple form -- one implementation)
 *  - DatePick       one date (a calendar), with an optional "token" text mode
 *  - DateRangePick  From / To
 *  - Segmented      one of a few choices as buttons (a period, a mode)
 *  - NumberRange    From / To numbers
 *  - YesNo          a switch with its words
 *
 * The report viewer, the parameter editor and the parameter panel render
 * THESE; nothing draws its own ad-hoc input any more.
 */
import React from 'react';
import { Box, FormControlLabel, Switch, TextField, ToggleButton, ToggleButtonGroup, Typography } from '@mui/material';
import ColumnValuePicker, { ColumnValuePickerProps } from '../ColumnValuePicker';

export function MultiPick(props: Omit<ColumnValuePickerProps, 'multiple'>) {
  return <ColumnValuePicker {...props} multiple />;
}

export function DatePick({ label, value, onChange, testId, error, helperText, sx }: {
  label: string; value: string; onChange: (v: string) => void; testId?: string; error?: boolean; helperText?: React.ReactNode; sx?: any;
}) {
  const token = typeof value === 'string' && value.startsWith('@');
  return (
    <TextField size="small" type={token ? 'text' : 'date'} label={label} value={value || ''} error={error} helperText={helperText}
      InputLabelProps={{ shrink: true }} inputProps={{ 'data-testid': testId }} onChange={e => onChange(e.target.value)}
      sx={{ minWidth: 180, ...sx }} />
  );
}

export function DateRangePick({ label, value, onChange, testId, error, helperText }: {
  label: string; value: { from?: string; to?: string } | null | undefined; onChange: (v: { from: string; to: string }) => void;
  testId?: string; error?: boolean; helperText?: React.ReactNode;
}) {
  const cur = value || {};
  return (
    <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }} data-testid={testId}>
      <DatePick label={`${label} From`} value={cur.from || ''} onChange={v => onChange({ from: v, to: cur.to || '' })} testId={testId ? `${testId}-from` : undefined} error={error} helperText={helperText} />
      <DatePick label={`${label} To`} value={cur.to || ''} onChange={v => onChange({ from: cur.from || '', to: v })} testId={testId ? `${testId}-to` : undefined} />
    </Box>
  );
}

export function Segmented<T extends string>({ label, value, options, onChange, testId }: {
  label: string; value: T | ''; options: { value: T; label: string; help?: string }[]; onChange: (v: T) => void; testId?: string;
}) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }} data-testid={testId}>
      <Typography variant="caption" color="text.secondary">{label}</Typography>
      <ToggleButtonGroup size="small" exclusive value={value} onChange={(_e, v) => { if (v) onChange(v); }} aria-label={label}>
        {options.map(o => <ToggleButton key={o.value} value={o.value} title={o.help} data-testid={testId ? `${testId}-${o.value}` : undefined}>{o.label}</ToggleButton>)}
      </ToggleButtonGroup>
    </Box>
  );
}

export function NumberRange({ label, value, onChange, testId, error, helperText }: {
  label: string; value: { from?: any; to?: any } | null | undefined; onChange: (v: { from: any; to: any }) => void;
  testId?: string; error?: boolean; helperText?: React.ReactNode;
}) {
  const cur = value || {};
  return (
    <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }} data-testid={testId}>
      <TextField size="small" type="number" label={`${label} from`} value={cur.from ?? ''} error={error} helperText={helperText}
        inputProps={{ 'data-testid': testId ? `${testId}-from` : undefined }} onChange={e => onChange({ from: e.target.value, to: cur.to ?? '' })} sx={{ width: 150 }} />
      <TextField size="small" type="number" label={`${label} to`} value={cur.to ?? ''}
        inputProps={{ 'data-testid': testId ? `${testId}-to` : undefined }} onChange={e => onChange({ from: cur.from ?? '', to: e.target.value })} sx={{ width: 150 }} />
    </Box>
  );
}

export function YesNo({ label, value, onChange, testId, words }: {
  label: string; value: boolean | null | undefined; onChange: (v: boolean) => void; testId?: string; words?: [string, string];
}) {
  const [yes, no] = words || ['Yes', 'No'];
  return (
    <FormControlLabel control={<Switch checked={!!value} onChange={e => onChange(e.target.checked)} slotProps={{ input: { 'data-testid': testId } as any }} />}
      label={`${label}: ${value ? yes : no}`} />
  );
}
