/**
 * ReportStudioPage -- the ONE editor of a report (2026-11-01).
 *
 * The owner: "edit report doesn't have option to design report tiles".  The
 * pencil went to /edit (columns, filters, parameters, layout -- no tiles) and
 * tile design hid behind an unlabelled icon to /canvas.  Two editors, two
 * roads, and the second one was not found.
 *
 * Now /finance-reports/:id/design is the editor, with tabs:
 *   Data        the dataset, columns, filters            (the tabular builder)
 *   Parameters  what the report asks for, where the choices come from
 *   Design      the tiles: finance grid, numbers, charts, the band (the canvas builder)
 *   Look        the theme: band / title / grid / palette (canvasTheme)
 *   Actions     popups and detail downloads             (the canvas builder, actions in view)
 *   Settings    name, code, sharing, schedule           (the builder's Review & Save)
 * A report that already has tiles opens on Design; the others on Data.
 * /edit and /canvas REDIRECT here (App.tsx), so every old link still works.
 * Each tab renders the EXISTING builder -- no third editor was written; the
 * builders keep their own Save.  The tab is the URL (?tab=), so a reload and
 * a link keep it.
 */
import React, { Suspense, lazy, useEffect, useMemo, useState } from 'react';
import { Box, CircularProgress, Tab, Tabs, Typography } from '@mui/material';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import api from '../../services/api';
import { STUDIO_TABS, StudioTab, reportPath } from '../../utils/reportUrls';
import { isTableOnlyCanvas, readCanvas } from './canvas/canvasModel';

const UnifiedReportBuilder = lazy(() => import('../UnifiedReportBuilder'));
const CanvasReportBuilder = lazy(() => import('./canvas/CanvasReportBuilder'));
const ReportLookPanel = lazy(() => import('./ReportLookPanel'));

export const TAB_LABEL: Record<StudioTab, string> = {
  data: 'Data', parameters: 'Parameters', design: 'Design', look: 'Look', actions: 'Actions', settings: 'Settings',
};
export const TAB_HELP: Record<StudioTab, string> = {
  data: 'The dataset, the columns and the filters.',
  parameters: 'What the report asks for when it runs, and where each list of choices comes from.',
  design: 'The tiles: finance grid, numbers, charts and the parameter band.',
  look: 'Colours, fonts and number styles -- a theme, or this report\'s own.',
  actions: 'What a click on a value does: a popup with the detail, or a download.',
  settings: 'Name, report code, sharing and the schedule.',
};

/** Which tab a report opens on when the URL names none. */
export function defaultTab(report: any | null): StudioTab {
  if (!report) return 'data';
  const canvas = readCanvas(report.layout_config);
  return canvas && !isTableOnlyCanvas(canvas) ? 'design' : 'data';
}

/** The URL tab, or the report's default; an unknown word is the default. */
export function tabOf(param: string | null, report: any | null): StudioTab {
  const t = String(param || '').toLowerCase() as StudioTab;
  return STUDIO_TABS.includes(t) ? t : defaultTab(report);
}

export default function ReportStudioPage() {
  const { id } = useParams<{ id: string }>();
  const [sp, setSp] = useSearchParams();
  const navigate = useNavigate();
  const [report, setReport] = useState<any | null>(null);
  const [loadErr, setLoadErr] = useState('');
  useEffect(() => {
    let off = false;
    if (!id) return;
    const read = /^\d+$/.test(id) ? api.getBusinessReport(Number(id)) : api.getBusinessReportBySlug(id);
    read.then((r: any) => { if (!off) setReport(r); })
      .catch((e: any) => { if (!off) setLoadErr(String(e?.message || 'The report could not be read.')); });
    return () => { off = true; };
  }, [id]);
  const tab = useMemo(() => tabOf(sp.get('tab'), report), [sp, report]);
  const go = (t: StudioTab) => { const n = new URLSearchParams(sp); n.set('tab', t); setSp(n, { replace: true }); };

  const body = () => {
    switch (tab) {
      case 'design': return <CanvasReportBuilder key="design" />;
      case 'actions': return <CanvasReportBuilder key="actions" />;
      case 'look': return <ReportLookPanel report={report} onSaved={(r: any) => setReport(r)} />;
      default: return <UnifiedReportBuilder key={tab} />;   // data / parameters / settings: ?step= picks the step
    }
  };
  // the builders read their step / focus from the URL: keep it in step with the tab
  useEffect(() => {
    const n = new URLSearchParams(sp);
    const want = tab === 'parameters' ? 'parameters' : tab === 'settings' ? 'settings' : tab === 'data' ? 'data' : null;
    const focus = tab === 'actions' ? 'actions' : null;
    let changed = false;
    if ((n.get('step') || null) !== want) { want ? n.set('step', want) : n.delete('step'); changed = true; }
    if ((n.get('focus') || null) !== focus) { focus ? n.set('focus', focus) : n.delete('focus'); changed = true; }
    if (changed) setSp(n, { replace: true });
  }, [tab]);   // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <Box data-testid="report-studio">
      <Box sx={{ borderBottom: 1, borderColor: 'divider', px: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
        <Tabs value={tab} onChange={(_e, v) => go(v)} aria-label="Report editor sections" variant="scrollable" allowScrollButtonsMobile>
          {STUDIO_TABS.map(t => <Tab key={t} value={t} label={TAB_LABEL[t]} data-testid={`studio-tab-${t}`} title={TAB_HELP[t]} />)}
        </Tabs>
        <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto', display: { xs: 'none', md: 'block' } }} data-testid="studio-tab-help">
          {TAB_HELP[tab]}
        </Typography>
        {report && (
          <Typography variant="caption" sx={{ cursor: 'pointer', color: 'primary.main' }} onClick={() => navigate(reportPath(report))}
            data-testid="studio-open-report">Open the report</Typography>
        )}
      </Box>
      {loadErr && <Typography color="error" sx={{ p: 2 }} data-testid="studio-load-error">{loadErr}</Typography>}
      <Suspense fallback={<Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>}>
        {body()}
      </Suspense>
    </Box>
  );
}
