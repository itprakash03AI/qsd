/**
 * ReportLookPanel -- the "Look" tab of the one editor (2026-11-01).
 *
 * The owner: "blue band ... is configurable right so colour can be anything".
 * A report's look is `layout_config.theme`: a THEME picked by name (a shipped
 * one, picked from the gallery (ThemeGallery: 28 themes on shelves) -- or one of the library an admin
 * keeps) and any field changed for this report alone.  Every colour is a
 * colour picker with its hex beside it; the preview is the real band and three
 * grid rows drawn by the same rule the report uses (canvasTheme.resolveTheme);
 * a contrast that would be hard to read is said in plain words, one that
 * cannot be read refuses Save (the server refuses it too).  Save PUTs the
 * whole layout_config with the theme (the PUT replaces layout_config).
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, FormControlLabel, MenuItem, Paper, Stack, TextField, Typography,
} from '@mui/material';
import api from '../../services/api';
import {
  APP, CODE_POSITIONS, DENSITIES, KPI_STYLES, KPI_STYLE_WORDS, NEGATIVE_STYLES, NEGATIVE_WORDS, ReportTheme, SCALES, SHIPPED_THEMES, TAB_STYLES,
  TAB_STYLE_WORDS, ThemeSpec, DEFAULT_THEME_NAME, appColour, isHex, kpiFill, kpiGradient, negativeIsRed, negativeText, resolveTheme, themeWords,
} from './canvas/canvasTheme';

/** A page / card colour: a picker, or "As the app draws it" (theme v2). */
export function AppColourField({ label, value, onChange, testId }: { label: string; value: string; onChange: (v: string) => void; testId: string }) {
  const isApp = value === APP;
  return (
    <Stack direction="row" spacing={1} alignItems="center">
      <FormControlLabel sx={{ mr: 0 }} control={<Checkbox size="small" checked={isApp} onChange={e => onChange(e.target.checked ? APP : appColour(value))}
        inputProps={{ 'data-testid': `${testId}-app` } as any} />} label={<Typography variant="caption">As the app draws it</Typography>} />
      {!isApp && <ColourField label={label} value={value} onChange={onChange} testId={testId} />}
      {isApp && <Typography variant="body2" color="text.secondary">{label}</Typography>}
    </Stack>
  );
}
import ThemeGallery from './ThemeGallery';

interface Props { report: any | null; onSaved?: (report: any) => void }

/** One colour: a picker + its hex, named for a screen reader. */
export function ColourField({ label, value, onChange, testId }: { label: string; value: string; onChange: (v: string) => void; testId: string }) {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  const bad = !isHex(text);
  return (
    <Stack direction="row" spacing={1} alignItems="center">
      <input type="color" value={isHex(text) ? text : '#000000'} aria-label={`${label} colour picker`}
        onChange={e => { setText(e.target.value); onChange(e.target.value); }} data-testid={`${testId}-picker`}
        style={{ width: 36, height: 32, border: '1px solid #ccc', borderRadius: 6, padding: 0, background: 'none' }} />
      <TextField size="small" label={label} value={text} error={bad} helperText={bad ? 'A colour like #1e6fd9' : undefined}
        onChange={e => { setText(e.target.value); if (isHex(e.target.value)) onChange(e.target.value); }}
        inputProps={{ 'data-testid': testId, maxLength: 7 }} sx={{ width: 150 }} />
    </Stack>
  );
}

/** The band and three grid rows, drawn by the report's own rule. */
/** The report's own name, code and band labels when known (2026-11-02, the owner on "[RPT-01]": a preview
 *  never shows a code the report does not have); the grid rows are a sample, said as such. */
export function ThemePreview({ theme, code, title, bandLabels }: { theme: ReportTheme; code?: string | null; title?: string; bandLabels?: string[] }) {
  const neg = (n: string) => (
    <span style={{ color: negativeIsRed(theme.grid.negative) ? '#d32f2f' : undefined }}>{negativeText(n, theme.grid.negative)}</span>
  );
  const row = (cells: React.ReactNode[], style?: { bg: string; fg: string; bold: boolean }, zebra?: boolean) => (
    <tr style={{ background: style?.bg ?? (zebra ? '#f7f8fa' : '#fff'), color: style?.fg, fontWeight: style?.bold ? 700 : 400 }}>
      {cells.map((c, i) => <td key={i} style={{ padding: theme.grid.density === 'compact' ? '2px 8px' : theme.grid.density === 'normal' ? '6px 8px' : '10px 8px', textAlign: i ? 'right' : 'left', borderBottom: '1px solid #eee' }}>{c}</td>)}
    </tr>
  );
  // theme v2: the preview sits on the theme's page, in its card, with one KPI card in its style
  const fill = kpiFill(theme, 0);
  const kpiSx = theme.kpi.style === 'plain'
    ? { bgcolor: appColour(theme.card.bg), color: appColour(theme.card.fg, true), border: '1px solid', borderColor: appColour(theme.card.border) }
    : { background: theme.kpi.style === 'gradient' ? kpiGradient(fill) : fill, color: theme.kpi.value_fg };
  return (
    <Box sx={{ bgcolor: appColour(theme.page.bg), p: theme.page.bg === APP ? 0 : 1.5, borderRadius: 1 }} data-testid="theme-preview-page">
    <Box data-testid="theme-preview-kpi" sx={{ ...kpiSx, borderRadius: `${theme.tiles.radius}px`, p: 1.25, mb: 1, width: 200, boxShadow: theme.tiles.shadow ? 2 : 0 }}>
      <Typography sx={{ fontSize: 12, color: theme.kpi.style === 'plain' ? appColour(theme.card.title_fg, true) : theme.kpi.label_fg }}>Assets</Typography>
      <Typography sx={{ fontSize: 24, fontWeight: 700, lineHeight: 1.1 }}>7.63M</Typography>
      <Typography sx={{ fontSize: 12, color: theme.kpi.style === 'plain' ? theme.kpi.up_fg : theme.kpi.value_fg }}>▲ 9% vs 6.99M before</Typography>
    </Box>
    <Paper variant="outlined" sx={{ p: 1.5, borderRadius: `${theme.tiles.radius}px`, boxShadow: theme.tiles.shadow ? 2 : 0,
      bgcolor: theme.card.bg === APP ? undefined : theme.card.bg, color: theme.card.fg === APP ? undefined : theme.card.fg,
      borderColor: theme.card.border === APP ? undefined : theme.card.border }} data-testid="theme-preview">
      <Stack direction="row" alignItems="baseline" spacing={1}>
        <Typography sx={{ flex: 1, fontFamily: theme.title.font, fontSize: theme.title.size, color: theme.title.color }} noWrap>{title || 'Report title'}</Typography>
        {code && theme.title.code_position !== 'hidden' && <Typography sx={{ color: theme.title.color, fontSize: 14 }} data-testid="preview-code">[{code}]</Typography>}
      </Stack>
      <Box sx={{ display: 'flex', bgcolor: theme.band.bg, color: theme.band.fg, borderRadius: 0.5, mt: 0.5, fontFamily: theme.band.font }}>
        {(bandLabels && bandLabels.length ? bandLabels.slice(0, 4).map(l => [l, '…']) : [['Business date', '31-JUL-2026'], ['Period', 'Daily']]).map(([l, v]) => (
          <Box key={l} sx={{ px: 1.5, py: 0.5, borderRight: '2px solid #fff' }}>
            <div style={{ fontSize: 11, color: theme.band.label_fg }}>{l}</div><div style={{ fontSize: 15 }}>{v}</div>
          </Box>
        ))}
      </Box>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 8, fontSize: 13 }}>
        <thead><tr style={{ background: theme.grid.header_bg, color: theme.grid.header_fg }}>
          {['PRODUCT AREA', 'FORMAL PNL', 'CARRY'].map(h => <th key={h} style={{ padding: '4px 8px', textAlign: h === 'PRODUCT AREA' ? 'left' : 'right', fontSize: 12 }}>{h}</th>)}
        </tr></thead>
        <tbody>
          {row(['EM Credit', neg('108,615'), '5,728'])}
          {row(['Structured Credit', '52', neg('2')], undefined, theme.grid.zebra)}
          {row(['Business Area Total', neg('108,563'), '5,725'], theme.grid.subtotal)}
          {row(['Grand Total', neg('108,563'), '5,725'], theme.grid.grand)}
        </tbody>
      </table>
      <Typography variant="caption" color="text.secondary">Sample rows, to show the colours. Chart colours:</Typography>
      <Stack direction="row" spacing={0.5} sx={{ mt: 0.5 }} data-testid="theme-palette">
        {theme.palette.map((c, i) => <Box key={i} sx={{ width: 18, height: 18, bgcolor: c, borderRadius: 0.5 }} title={c} />)}
      </Stack>
    </Paper>
    </Box>
  );
}

export default function ReportLookPanel({ report, onSaved }: Props) {
  const [library, setLibrary] = useState<Record<string, any>>({});
  const [libNote, setLibNote] = useState('');
  const [spec, setSpec] = useState<ThemeSpec>({});
  const [insights, setInsights] = useState<{ assistant: boolean; tone: string; length: string }>({ assistant: false, tone: 'plain', length: 'short' });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState('');
  const [err, setErr] = useState('');
  const [importNote, setImportNote] = useState('');
  useEffect(() => {
    (api as any).listReportThemes?.().then((r: any) => {
      const lib: Record<string, any> = {};
      for (const t of r?.library || []) lib[t.name] = t.theme;
      setLibrary(lib);
      if (r?.note) setLibNote(String(r.note));
    }).catch((e: any) => setLibNote(`The theme library could not be read (${e?.message || 'unknown'}); the shipped themes are offered.`));
  }, []);
  useEffect(() => {
    setSpec(report?.layout_config?.theme && typeof report.layout_config.theme === 'object' ? report.layout_config.theme : {});
    const ins = report?.layout_config?.insights;
    setInsights({ assistant: !!ins?.assistant, tone: ins?.tone === 'analyst' ? 'analyst' : 'plain', length: ins?.length === 'medium' ? 'medium' : 'short' });
  }, [report?.id, report?.updated_at]);
  const theme = useMemo(() => resolveTheme({ theme: spec }, library), [spec, library]);
  const words = useMemo(() => themeWords(theme), [theme]);
  const names = [...Object.keys(SHIPPED_THEMES), ...Object.keys(library)];
  const set = (path: string[], v: any) => setSpec(s => {
    const out: any = JSON.parse(JSON.stringify(s));
    let cur = out;
    for (const k of path.slice(0, -1)) { cur[k] = cur[k] && typeof cur[k] === 'object' ? cur[k] : {}; cur = cur[k]; }
    cur[path[path.length - 1]] = v;
    return out;
  });
  const reset = () => setSpec(s => (s.name ? { name: s.name } : {}));
  const save = async () => {
    if (!report?.id) return;
    setSaving(true); setErr(''); setSaved('');
    try {
      const layout = { ...(report.layout_config || {}), theme: Object.keys(spec).length ? spec : undefined, insights };
      const r = await api.updateBusinessReport(report.id, { layout_config: layout, expected_updated_at: report.updated_at });
      setSaved('The look is saved. Every viewer, and Excel / PDF, use it from now.');
      onSaved?.(r && r.id ? r : { ...report, layout_config: layout, updated_at: r?.updated_at ?? report.updated_at });
    } catch (e: any) {
      const d = e?.payload || e?.detail;
      setErr(d?.message || e?.message || 'The look could not be saved.');
    } finally { setSaving(false); }
  };
  if (!report) return <Typography sx={{ p: 2 }} color="text.secondary">Reading the report…</Typography>;
  const overridden = Object.keys(spec).filter(k => k !== 'name').length > 0;
  return (
    <Box sx={{ p: 2, display: 'grid', gridTemplateColumns: { xs: '1fr', md: '420px 1fr' }, gap: 2 }} data-testid="report-look">
      <Stack spacing={2}>
        {/* 2026-11-03 the owner: "save the look button so down ... hard to find" -- the actions stay
            at the top of the column while the settings scroll beneath them */}
        <Box data-testid="look-actions" sx={{ position: 'sticky', top: 0, zIndex: 2, bgcolor: 'background.paper',
          py: 1, borderBottom: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>Look</Typography>
          <Button variant="contained" onClick={save} disabled={saving || words.problems.length > 0} data-testid="look-save">Save the look</Button>
          <Button onClick={reset} disabled={!overridden} data-testid="look-reset">Back to the theme</Button>
          {words.problems.length > 0 && <Typography variant="caption" color="error.main" sx={{ width: '100%' }}>Fix the problems at the bottom of this column first.</Typography>}
          {err && <Alert severity="error" data-testid="look-error" sx={{ width: '100%' }}>{err}</Alert>}
          {saved && <Alert severity="success" data-testid="look-saved" sx={{ width: '100%' }}>{saved}</Alert>}
        </Box>
        <Typography variant="body2" color="text.secondary">
          Pick a theme, then change anything for this report. Colours come from the picker or a hex like #1e6fd9. Excel and PDF print the same colours.
        </Typography>
        {libNote && <Alert severity="warning" data-testid="look-library-note">{libNote}</Alert>}
        <ThemeGallery picked={spec.name || DEFAULT_THEME_NAME} library={library}
          onPick={n => { setImportNote(''); setSpec({ name: n === DEFAULT_THEME_NAME ? undefined : n }); }}
          onImport={(imported, note) => { setSpec(s => ({ ...(s.name ? { name: s.name } : {}), ...imported })); setImportNote(note); }} />
        {importNote && <Alert severity="info" data-testid="look-import-note">{importNote}</Alert>}
        <TextField select size="small" label="Theme" value={spec.name || DEFAULT_THEME_NAME} inputProps={{ 'data-testid': 'look-theme' }}
          onChange={e => setSpec({ name: e.target.value === DEFAULT_THEME_NAME ? undefined : e.target.value })}
          helperText={overridden ? 'This report changes some of its fields (below).' : 'As the theme defines it.'}>
          {names.map(n => <MenuItem key={n} value={n}>{n}{SHIPPED_THEMES[n] ? '' : ' (library)'}</MenuItem>)}
        </TextField>

        <Typography variant="subtitle2">The parameter band</Typography>
        <ColourField label="Band background" value={theme.band.bg} onChange={v => set(['band', 'bg'], v)} testId="look-band-bg" />
        <ColourField label="Band text" value={theme.band.fg} onChange={v => set(['band', 'fg'], v)} testId="look-band-fg" />
        <ColourField label="Band labels" value={theme.band.label_fg} onChange={v => set(['band', 'label_fg'], v)} testId="look-band-label" />
        <TextField size="small" label="Band font" value={theme.band.font} onChange={e => set(['band', 'font'], e.target.value)} inputProps={{ 'data-testid': 'look-band-font' }} helperText="A font name, e.g. Georgia, serif. 'inherit' = the app's font." />

        <Typography variant="subtitle2">The title</Typography>
        <ColourField label="Title colour" value={theme.title.color} onChange={v => set(['title', 'color'], v)} testId="look-title-color" />
        <Stack direction="row" spacing={1}>
          <TextField size="small" label="Title font" value={theme.title.font} onChange={e => set(['title', 'font'], e.target.value)} inputProps={{ 'data-testid': 'look-title-font' }} sx={{ flex: 1 }} />
          <TextField size="small" type="number" label="Size" value={theme.title.size} onChange={e => set(['title', 'size'], Number(e.target.value))} inputProps={{ min: 10, max: 48, 'data-testid': 'look-title-size' }} sx={{ width: 90 }} />
        </Stack>
        <TextField select size="small" label="Report code sits" value={theme.title.code_position} onChange={e => set(['title', 'code_position'], e.target.value)} inputProps={{ 'data-testid': 'look-code-position' }}>
          {CODE_POSITIONS.map(p => <MenuItem key={p} value={p}>{p === 'right' ? 'Top right' : p === 'left' ? 'Top left' : p === 'under' ? 'Under the title' : 'Hidden'}</MenuItem>)}
        </TextField>

        <Typography variant="subtitle2">The grid</Typography>
        <ColourField label="Header background" value={theme.grid.header_bg} onChange={v => set(['grid', 'header_bg'], v)} testId="look-header-bg" />
        <ColourField label="Header text" value={theme.grid.header_fg} onChange={v => set(['grid', 'header_fg'], v)} testId="look-header-fg" />
        <ColourField label="Subtotal row background" value={theme.grid.subtotal.bg} onChange={v => set(['grid', 'subtotal', 'bg'], v)} testId="look-subtotal-bg" />
        <ColourField label="Subtotal row text" value={theme.grid.subtotal.fg} onChange={v => set(['grid', 'subtotal', 'fg'], v)} testId="look-subtotal-fg" />
        <FormControlLabel control={<Checkbox checked={theme.grid.subtotal.bold} onChange={e => set(['grid', 'subtotal', 'bold'], e.target.checked)} />} label="Subtotal rows in bold" />
        <ColourField label="Grand total background" value={theme.grid.grand.bg} onChange={v => set(['grid', 'grand', 'bg'], v)} testId="look-grand-bg" />
        <ColourField label="Grand total text" value={theme.grid.grand.fg} onChange={v => set(['grid', 'grand', 'fg'], v)} testId="look-grand-fg" />
        <FormControlLabel control={<Checkbox checked={theme.grid.grand.bold} onChange={e => set(['grid', 'grand', 'bold'], e.target.checked)} />} label="Grand total in bold" />
        <TextField select size="small" label="Negative numbers" value={theme.grid.negative} onChange={e => set(['grid', 'negative'], e.target.value)} inputProps={{ 'data-testid': 'look-negative' }}>
          {NEGATIVE_STYLES.map(n => <MenuItem key={n} value={n}>{NEGATIVE_WORDS[n]}</MenuItem>)}
        </TextField>
        <FormControlLabel control={<Checkbox checked={theme.grid.zebra} onChange={e => set(['grid', 'zebra'], e.target.checked)} />} label="Zebra rows (every other row shaded)" />
        <TextField select size="small" label="Row density" value={theme.grid.density} onChange={e => set(['grid', 'density'], e.target.value)} inputProps={{ 'data-testid': 'look-density' }}>
          {DENSITIES.map(d => <MenuItem key={d} value={d}>{d[0].toUpperCase() + d.slice(1)}</MenuItem>)}
        </TextField>

        <Typography variant="subtitle2">Numbers (every value, unless a tile says otherwise)</Typography>
        <Stack direction="row" spacing={1}>
          <TextField size="small" type="number" label="Decimals" value={theme.numbers.decimals} onChange={e => set(['numbers', 'decimals'], Number(e.target.value))} inputProps={{ min: 0, max: 10, 'data-testid': 'look-decimals' }} sx={{ width: 110 }} />
          <TextField select size="small" label="Shown in" value={theme.numbers.scale} onChange={e => set(['numbers', 'scale'], e.target.value)} inputProps={{ 'data-testid': 'look-scale' }} sx={{ width: 150 }}>
            {SCALES.map(s => <MenuItem key={s} value={s}>{s === 'none' ? 'Units' : s === 'K' ? 'Thousands (K)' : s === 'M' ? 'Millions (M)' : 'Billions (B)'}</MenuItem>)}
          </TextField>
          <TextField size="small" label="Currency symbol" value={theme.numbers.currency} onChange={e => set(['numbers', 'currency'], e.target.value)} inputProps={{ maxLength: 4, 'data-testid': 'look-currency' }} sx={{ width: 140 }} />
        </Stack>
        <FormControlLabel control={<Checkbox checked={theme.numbers.thousands} onChange={e => set(['numbers', 'thousands'], e.target.checked)} />} label="Thousands separator" />

        <Typography variant="subtitle2">The page and the cards</Typography>
        <Typography variant="caption" color="text.secondary">The colour behind the tiles, the bar that holds the page tabs, and every tile&apos;s card. &quot;As the app draws it&quot; keeps today&apos;s look.</Typography>
        <AppColourField label="Page background" value={theme.page.bg} onChange={v => set(['page', 'bg'], v)} testId="look-page-bg" />
        <AppColourField label="Header bar background" value={theme.page.header_bg} onChange={v => set(['page', 'header_bg'], v)} testId="look-page-header-bg" />
        <ColourField label="Header bar text" value={theme.page.header_fg} onChange={v => set(['page', 'header_fg'], v)} testId="look-page-header-fg" />
        <TextField select size="small" label="Page tabs look like" value={theme.page.tabs} onChange={e => set(['page', 'tabs'], e.target.value)} inputProps={{ 'data-testid': 'look-page-tabs' }}>
          {TAB_STYLES.map(s => <MenuItem key={s} value={s}>{TAB_STYLE_WORDS[s]}</MenuItem>)}
        </TextField>
        <AppColourField label="Card background" value={theme.card.bg} onChange={v => set(['card', 'bg'], v)} testId="look-card-bg" />
        <AppColourField label="Card border" value={theme.card.border} onChange={v => set(['card', 'border'], v)} testId="look-card-border" />
        <AppColourField label="Card text" value={theme.card.fg} onChange={v => set(['card', 'fg'], v)} testId="look-card-fg" />
        <AppColourField label="Card title" value={theme.card.title_fg} onChange={v => set(['card', 'title_fg'], v)} testId="look-card-title-fg" />
        <TextField select size="small" label="Card title sits" value={theme.card.title_align} onChange={e => set(['card', 'title_align'], e.target.value)} inputProps={{ 'data-testid': 'look-card-title-align' }}>
          <MenuItem value="left">Left</MenuItem><MenuItem value="center">In the centre</MenuItem>
        </TextField>

        <Typography variant="subtitle2">KPI cards (the number tiles)</Typography>
        <TextField select size="small" label="Style" value={theme.kpi.style} onChange={e => set(['kpi', 'style'], e.target.value)} inputProps={{ 'data-testid': 'look-kpi-style' }}>
          {KPI_STYLES.map(s => <MenuItem key={s} value={s}>{KPI_STYLE_WORDS[s]}</MenuItem>)}
        </TextField>
        <Typography variant="caption" color="text.secondary">Fill colours, one per card in turn (a filled or gradient card; a plain card uses the first as its icon colour).</Typography>
        <Stack direction="row" flexWrap="wrap" gap={1}>
          {theme.kpi.fills.map((c, i) => (
            <input key={i} type="color" value={c} aria-label={`KPI fill ${i + 1}`} data-testid={`look-kpi-fill-${i}`}
              onChange={e => set(['kpi', 'fills'], theme.kpi.fills.map((x, j) => j === i ? e.target.value : x))}
              style={{ width: 34, height: 30, border: '1px solid #ccc', borderRadius: 6, padding: 0, background: 'none' }} />
          ))}
        </Stack>
        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
          <ColourField label="Value text on a fill" value={theme.kpi.value_fg} onChange={v => set(['kpi', 'value_fg'], v)} testId="look-kpi-value-fg" />
          <ColourField label="Label text on a fill" value={theme.kpi.label_fg} onChange={v => set(['kpi', 'label_fg'], v)} testId="look-kpi-label-fg" />
        </Stack>
        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
          <ColourField label="A good change" value={theme.kpi.up_fg} onChange={v => set(['kpi', 'up_fg'], v)} testId="look-kpi-up" />
          <ColourField label="A bad change" value={theme.kpi.down_fg} onChange={v => set(['kpi', 'down_fg'], v)} testId="look-kpi-down" />
        </Stack>

        <Typography variant="subtitle2">Insights written by the assistant</Typography>
        <Typography variant="caption" color="text.secondary">
          The QueryStudio assistant can write a short story from an insight tile's numbers -- what moved, what drove it, what to check. It may use only numbers that are in the data; otherwise the standard sentence is shown and says why.
        </Typography>
        <FormControlLabel control={<Checkbox checked={!!insights.assistant} onChange={e => setInsights({ ...insights, assistant: e.target.checked })} inputProps={{ 'data-testid': 'look-insights-assistant' } as any} />} label="Let the assistant write the insight stories" />
        <Stack direction="row" spacing={1}>
          <TextField select size="small" label="Tone" value={insights.tone} onChange={e => setInsights({ ...insights, tone: e.target.value })} inputProps={{ 'data-testid': 'look-insights-tone' }} sx={{ width: 160 }}>
            <MenuItem value="plain">Plain words</MenuItem><MenuItem value="analyst">Analyst</MenuItem>
          </TextField>
          <TextField select size="small" label="Length" value={insights.length} onChange={e => setInsights({ ...insights, length: e.target.value })} inputProps={{ 'data-testid': 'look-insights-length' }} sx={{ width: 160 }}>
            <MenuItem value="short">Short</MenuItem><MenuItem value="medium">Medium</MenuItem>
          </TextField>
        </Stack>

        <Typography variant="subtitle2">Chart colours</Typography>
        <Stack direction="row" flexWrap="wrap" gap={1}>
          {theme.palette.map((c, i) => (
            <input key={i} type="color" value={c} aria-label={`Chart colour ${i + 1}`} data-testid={`look-palette-${i}`}
              onChange={e => set(['palette'], theme.palette.map((x, j) => j === i ? e.target.value : x))}
              style={{ width: 34, height: 30, border: '1px solid #ccc', borderRadius: 6, padding: 0, background: 'none' }} />
          ))}
        </Stack>

        {words.warnings.map((w, i) => <Alert key={i} severity="warning" data-testid="look-warning">{w}</Alert>)}
        {words.problems.map((w, i) => <Alert key={i} severity="error" data-testid="look-problem">{w}</Alert>)}
      </Stack>
      <Box>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Preview</Typography>
        <ThemePreview theme={theme} code={report?.layout_config?.canvas?.report_code || null} title={report?.name}
          bandLabels={(report?.parameters || []).filter((p: any) => p?.visible !== false).map((p: any) => String(p.label || p.name))} />
      </Box>
    </Box>
  );
}
