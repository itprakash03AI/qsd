/**
 * "What changed since I signed?" (2026-09-28) — renders the SERVER's keyed
 * diff of the current instance against the signed one
 * (`GET /api/business-reports/{id}/instances/{iid}/diff`).
 *
 * A 200 whose `refused` is set IS the answer: the reason is shown as the
 * finding, never as an error.  A definition change is stated FIRST.  A
 * report with no key gets the column totals and the sentence saying why.
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Table, TableBody, TableCell, TableHead, TableRow, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import api from '../../services/api';
import type { InstanceDiff } from '../../services/api/businessReports';

interface Props {
  open: boolean;
  onClose: () => void;
  reportId: number;
  instanceId: number;
  /** the signed instance; omitted = the server picks the signed run under the same key */
  againstId?: number | null;
}

const fmt = (v: any): string => {
  if (v === null || v === undefined) return '—';
  if (typeof v === 'number') return v.toLocaleString(undefined, { maximumFractionDigits: 4 });
  return String(v);
};

const signed = (v: number | null | undefined): string => {
  if (v === null || v === undefined) return '—';
  const s = v.toLocaleString(undefined, { maximumFractionDigits: 4 });
  return v > 0 ? '+' + s : s;
};

export default function InstanceDiffDialog({ open, onClose, reportId, instanceId, againstId }: Props) {
  const [diff, setDiff] = useState<InstanceDiff | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return;
    let alive = true;
    setLoading(true); setError(''); setDiff(null);
    api.diffReportInstances(reportId, instanceId, againstId ?? null)
      .then(d => { if (alive) setDiff(d); })
      .catch(e => { if (alive) setError(e?.message || 'Could not compute the diff'); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [open, reportId, instanceId, againstId]);

  const rows = diff?.rows;
  return (
    <AppDialog open={open}
      onClose={onClose}
      size="md"
      aria-labelledby="instance-diff-title"
      titleId="instance-diff-title"
      title="What changed since the signed run"
      actions={<><Button onClick={onClose}>Close</Button>
      </>}>
        {loading && <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}><CircularProgress size={18} /><Typography>Comparing…</Typography></Box>}
        {error && <Alert severity="error" data-testid="diff-error">{error}</Alert>}
        {diff?.refused && (
          <Alert severity="warning" data-testid="diff-refused">Not compared: {diff.refused}</Alert>
        )}
        {diff && !diff.refused && (
          <Box data-testid="diff-body">
            {diff.definition_changed && (
              <Alert severity="info" sx={{ mb: 1 }} data-testid="diff-definition-changed">
                The report definition changed between the two runs
                {(diff.columns_added?.length || diff.columns_removed?.length)
                  ? ` — columns added: ${diff.columns_added?.join(', ') || 'none'}; removed: ${diff.columns_removed?.join(', ') || 'none'}.`
                  : '.'} The columns both runs share are compared below.
              </Alert>
            )}
            {/* 2026-11-01 -- did the DATA move between the two runs: the version
                each Iceberg table was read at, in the diff's own words
                (core/reports/instance_diff.data_versions_changed) */}
            {diff.data_versions && (
              <Alert severity={diff.data_versions.known && diff.data_versions.changed.length ? 'warning' : 'info'}
                sx={{ mb: 1 }} data-testid="diff-data-versions"
                data-known={diff.data_versions.known ? 'yes' : 'no'}>
                {diff.data_versions.words}
              </Alert>
            )}
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
              Signed run #{diff.base?.instance_id} vs this run #{diff.current?.instance_id}
              {' · '}{fmt(rows?.base)} rows then, {fmt(rows?.current)} rows now
            </Typography>
            {diff.keyed ? (
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }} data-testid="diff-row-counts">
                <Chip size="small" label={`key: ${diff.key_columns?.join(' + ')}`} />
                <Chip size="small" color="success" label={`${fmt(rows?.added)} added`} />
                <Chip size="small" color="error" label={`${fmt(rows?.removed)} removed`} />
                <Chip size="small" color="warning" label={`${fmt(rows?.changed)} changed`} />
                <Chip size="small" variant="outlined" label={`${fmt(rows?.unchanged)} unchanged`} />
              </Box>
            ) : (
              <Alert severity="info" sx={{ mb: 2 }} data-testid="diff-not-keyed">
                Rows were not matched: {diff.key_reason}
              </Alert>
            )}
            {diff.measures && diff.measures.length > 0 && (
              <Table size="small" aria-label="Measure totals" sx={{ mb: 2 }}>
                <TableHead><TableRow>
                  <TableCell>Measure</TableCell><TableCell align="right">Signed</TableCell>
                  <TableCell align="right">Now</TableCell><TableCell align="right">Delta</TableCell>
                </TableRow></TableHead>
                <TableBody>
                  {diff.measures.map(m => (
                    <TableRow key={m.column}>
                      <TableCell>{m.column}</TableCell>
                      <TableCell align="right">{fmt(m.base_sum)}</TableCell>
                      <TableCell align="right">{fmt(m.current_sum)}</TableCell>
                      <TableCell align="right">{signed(m.delta)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
            {diff.top_movers && diff.top_movers.length > 0 && (
              <Table size="small" aria-label="Top movers">
                <TableHead><TableRow>
                  <TableCell>Row</TableCell><TableCell>Measure</TableCell>
                  <TableCell align="right">Signed</TableCell><TableCell align="right">Now</TableCell>
                  <TableCell align="right">Delta</TableCell>
                </TableRow></TableHead>
                <TableBody>
                  {diff.top_movers.map((m, i) => (
                    <TableRow key={`${m.column}-${i}`}>
                      <TableCell>{Object.entries(m.key).map(([k, v]) => `${k}=${fmt(v)}`).join(', ')}</TableCell>
                      <TableCell>{m.column}</TableCell>
                      <TableCell align="right">{fmt(m.before)}</TableCell>
                      <TableCell align="right">{fmt(m.after)}</TableCell>
                      <TableCell align="right">{signed(m.delta)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
            {!diff.keyed && diff.column_summary && diff.column_summary.length > 0 && (
              <Table size="small" aria-label="Column totals">
                <TableHead><TableRow>
                  <TableCell>Column</TableCell><TableCell align="right">Rows then / now</TableCell>
                  <TableCell align="right">Nulls</TableCell><TableCell align="right">Distinct</TableCell>
                  <TableCell align="right">Sum then / now</TableCell>
                </TableRow></TableHead>
                <TableBody>
                  {diff.column_summary.map(c => (
                    <TableRow key={c.column}>
                      <TableCell>{c.column}</TableCell>
                      <TableCell align="right">{fmt(c.base.count)} / {fmt(c.current.count)}</TableCell>
                      <TableCell align="right">{fmt(c.base.nulls)} / {fmt(c.current.nulls)}</TableCell>
                      <TableCell align="right">{fmt(c.base.distinct)} / {fmt(c.current.distinct)}</TableCell>
                      <TableCell align="right">{c.numeric ? `${fmt(c.base.sum)} / ${fmt(c.current.sum)}` : '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Box>
        )}
    </AppDialog>
  );
}
