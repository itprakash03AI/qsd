/**
 * Parameter bookmarks on a finance report viewer (2026-09-27).
 *
 * `/api/reports/{id}/bookmarks` (per user, finance-keyed) had no viewer
 * using it.  This control lists the person's bookmarks for the report,
 * applies one (hands its `param_values` to the viewer's parameter state),
 * saves the CURRENT values under a name, and deletes one.  Server side the
 * rows are the caller's alone (list filters by username; delete refuses
 * another user's row), so nothing here needs to hide anything.
 *
 * Every control is named: the menu opens from "Bookmarks", each entry is a
 * menu item named by its bookmark, its delete is "Delete bookmark — {name}".
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Button, Menu, MenuItem, ListItemText, ListItemIcon, Divider, TextField, IconButton, Typography, Tooltip,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import BookmarkIcon from '@mui/icons-material/BookmarkBorder';
import BookmarkAddIcon from '@mui/icons-material/BookmarkAdd';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import api from '../../services/api';

export interface ReportBookmark {
  id: number;
  name: string;
  param_values: Record<string, any>;
  created_at?: string | null;
}

interface Props {
  reportId: number;
  /** the viewer's current parameter values — what "Save current" stores */
  paramValues: Record<string, any>;
  /** hand a bookmark's values back to the viewer */
  onApply: (values: Record<string, any>) => void;
  /** disable saving when the viewer has no parameters to bookmark */
  disabled?: boolean;
  size?: 'small' | 'medium';
}

export default function ReportBookmarks({ reportId, paramValues, onApply, disabled, size = 'small' }: Props) {
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const [items, setItems] = useState<ReportBookmark[]>([]);
  const [loadError, setLoadError] = useState('');
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveName, setSaveName] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');

  const load = useCallback(async () => {
    setLoadError('');
    try {
      const res: any = await api.listReportBookmarks(reportId);
      setItems(Array.isArray(res?.bookmarks) ? res.bookmarks : []);
    } catch (e: any) {
      // "could not read" and "has none" lead to opposite investigations
      setItems([]);
      setLoadError(e?.message || 'Bookmarks could not be loaded');
    }
  }, [reportId]);

  useEffect(() => { load(); }, [load]);

  const open = (e: React.MouseEvent<HTMLElement>) => { setAnchor(e.currentTarget); load(); };
  const close = () => setAnchor(null);

  const apply = (bm: ReportBookmark) => {
    close();
    onApply({ ...(bm.param_values || {}) });
  };

  const remove = async (bm: ReportBookmark, ev: React.MouseEvent) => {
    ev.stopPropagation();
    try {
      await api.deleteReportBookmark(bm.id);
      setItems(prev => prev.filter(b => b.id !== bm.id));
    } catch (e: any) {
      setLoadError(e?.message || 'Delete failed');
    }
  };

  const save = async () => {
    const name = saveName.trim();
    if (!name) { setSaveError('Give the bookmark a name'); return; }
    setSaving(true); setSaveError('');
    try {
      const bm: any = await api.saveReportBookmark(reportId, name, paramValues || {});
      setItems(prev => [...prev.filter(b => b.id !== bm?.id), bm].sort((a, b) => a.name.localeCompare(b.name)));
      setSaveOpen(false); setSaveName('');
    } catch (e: any) {
      setSaveError(e?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const describe = (v: Record<string, any>) => {
    const keys = Object.keys(v || {});
    if (!keys.length) return 'no parameter values';
    return keys.map(k => {
      const val = v[k];
      const s = Array.isArray(val) ? val.join(', ')
        : (val && typeof val === 'object') ? Object.values(val).join(' → ')
          : String(val ?? '');
      return `${k}=${s}`;
    }).join(' · ');
  };

  return (
    <>
      <Button size={size} variant="outlined" startIcon={<BookmarkIcon />} onClick={open}
        aria-label="Bookmarks" aria-haspopup="menu" data-testid="bookmarks-button">
        Bookmarks{items.length ? ` (${items.length})` : ''}
      </Button>
      <Menu anchorEl={anchor} open={Boolean(anchor)} onClose={close}
        MenuListProps={{ 'aria-label': 'Parameter bookmarks' }}>
        <MenuItem onClick={() => { close(); setSaveOpen(true); setSaveError(''); }}
          disabled={disabled} aria-label="Save current parameters as a bookmark">
          <ListItemIcon><BookmarkAddIcon fontSize="small" /></ListItemIcon>
          <ListItemText primary="Save current parameters…"
            secondary={disabled ? 'This report has no parameters to save' : describe(paramValues)} />
        </MenuItem>
        <Divider />
        {loadError && (
          <MenuItem disabled><ListItemText primary={loadError} /></MenuItem>
        )}
        {!loadError && items.length === 0 && (
          <MenuItem disabled><ListItemText primary="No bookmarks yet" secondary="Bookmarks are yours alone; other users cannot see them." /></MenuItem>
        )}
        {items.map(bm => (
          <MenuItem key={bm.id} onClick={() => apply(bm)} aria-label={`Apply bookmark — ${bm.name}`}
            data-testid={`bookmark-${bm.id}`}>
            <ListItemText primary={bm.name} secondary={describe(bm.param_values)}
              secondaryTypographyProps={{ sx: { maxWidth: 360, whiteSpace: 'normal' } }} />
            <Tooltip title="Delete this bookmark">
              <IconButton size="small" edge="end" sx={{ ml: 1 }}
                aria-label={`Delete bookmark — ${bm.name}`}
                onClick={(ev) => remove(bm, ev)}>
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </MenuItem>
        ))}
      </Menu>

      <AppDialog open={saveOpen}
        onClose={() => setSaveOpen(false)}
        size="xs"
        title="Save parameters as a bookmark"
        actions={<>
          <Button onClick={() => setSaveOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={save} disabled={saving}>Save bookmark</Button>
        </>}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
            {describe(paramValues)}
          </Typography>
          <TextField autoFocus fullWidth size="small" label="Bookmark name" value={saveName}
            onChange={e => setSaveName(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') save(); }}
            error={Boolean(saveError)} helperText={saveError || ' '} />
      </AppDialog>
    </>
  );
}
