/**
 * ChoicesListBox -- a parameter's OWN list in QueryStudio's database (2026-11-01).
 *
 * The owner: "each dropdown should have query etc ... user should be able to
 * define distinct column's values on source table without where clause".
 * The server makes the list on save (core/reports/param_lists.py): the column
 * traced to its source table, `SELECT DISTINCT col FROM table` -- no WHERE --
 * or the recorded partition values.  The editor SEES the query, may change it
 * (and the key / label columns), presses Refresh now, and sets the schedule;
 * the words say how many values, when, and why it is read live under a row
 * policy.  Edits go through the value lists' own route (PUT /api/value-lists/{id}).
 */
import React, { useState } from 'react';
import { Alert, Box, Button, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { safeFetch } from '../../services/api/core';
import { safeStringify } from '../../utils/safeStringify';

export interface ChoicesListInfo {
  has_list: boolean; id?: number; name?: string; source_type?: string; source_sql?: string | null;
  key_column?: string | null; label_column?: string | null; parent_column?: string | null;
  sync_mode?: string | null; sync_every_hours?: number | null; last_status?: string | null;
  last_synced_at?: string | null; value_count?: number; last_error?: string | null; live_reason?: string | null;
  words: string;
}

export default function ChoicesListBox({ info, paramId, onChanged }: { info: ChoicesListInfo; paramId: number | null; onChanged?: (i: ChoicesListInfo) => void }) {
  const [sql, setSql] = useState(info.source_sql || '');
  const [key, setKey] = useState(info.key_column || '');
  const [label, setLabel] = useState(info.label_column || '');
  const [mode, setMode] = useState(info.sync_mode || 'daily');
  const [busy, setBusy] = useState<'' | 'save' | 'refresh'>('');
  const [note, setNote] = useState<{ kind: 'success' | 'error' | 'info'; text: string } | null>(null);
  const dirty = sql !== (info.source_sql || '') || key !== (info.key_column || '') || label !== (info.label_column || '') || mode !== (info.sync_mode || 'daily');

  const refresh = async () => {
    if (!paramId) { setNote({ kind: 'info', text: 'Save the report first; the list is made when the parameter is saved.' }); return; }
    setBusy('refresh'); setNote(null);
    try {
      const r: ChoicesListInfo = await safeFetch(`/api/business-reports/parameters/${paramId}/choices/refresh`, { method: 'POST' });
      onChanged?.(r);
      setNote({ kind: r.last_status === 'failed' ? 'error' : 'success', text: r.words });
    } catch (e: any) { setNote({ kind: 'error', text: e?.message || 'The list could not be refreshed.' }); }
    finally { setBusy(''); }
  };
  const save = async () => {
    if (!info.id) return;
    setBusy('save'); setNote(null);
    try {
      await safeFetch(`/api/value-lists/${info.id}`, { method: 'PUT', body: safeStringify({
        source_sql: sql, key_column: key || null, label_column: label || null, sync_mode: mode }) });
      await refresh();
    } catch (e: any) { setNote({ kind: 'error', text: e?.message || 'The query could not be saved.' }); setBusy(''); }
  };
  return (
    <Box data-testid="choices-list-box" sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 1, p: 1, mt: 0.5 }}>
      <Typography variant="caption" color="text.secondary" component="div" data-testid="choices-list-words">
        {info.has_list ? `This parameter's own list, kept in QueryStudio's database. ${info.words}` : info.words}
      </Typography>
      {info.has_list && info.source_type !== 'partition' && (
        <Stack spacing={1} sx={{ mt: 1 }}>
          <TextField size="small" multiline minRows={2} label="The list's query (no WHERE needed -- every value of the column)" value={sql}
            onChange={e => setSql(e.target.value)} inputProps={{ 'data-testid': 'choices-list-sql' }} />
          <Stack direction="row" spacing={1}>
            <TextField size="small" label="Value column" value={key} onChange={e => setKey(e.target.value)} inputProps={{ 'data-testid': 'choices-list-key' }} sx={{ flex: 1 }} />
            <TextField size="small" label="Name column (optional)" value={label} onChange={e => setLabel(e.target.value)} inputProps={{ 'data-testid': 'choices-list-label' }} sx={{ flex: 1 }} />
            <TextField select size="small" label="Refreshed" value={mode} onChange={e => setMode(e.target.value)} inputProps={{ 'data-testid': 'choices-list-mode' }} sx={{ width: 150 }}>
              <MenuItem value="daily">Every day</MenuItem>
              <MenuItem value="manual">Only when asked</MenuItem>
            </TextField>
          </Stack>
        </Stack>
      )}
      {info.has_list && info.source_type === 'partition' && (
        <Typography variant="caption" component="div" sx={{ mt: 0.5 }} data-testid="choices-list-partition">
          Its values are the table's recorded partitions -- no data is scanned. To use a different list, change "Choices come from" to another table or a saved list.
        </Typography>
      )}
      <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
        <Button size="small" variant="outlined" onClick={refresh} disabled={!!busy} data-testid="choices-list-refresh">Refresh now</Button>
        {info.has_list && info.source_type !== 'partition' && (
          <Button size="small" onClick={save} disabled={!!busy || !dirty} data-testid="choices-list-save">Save the query and refresh</Button>
        )}
      </Stack>
      {note && <Alert severity={note.kind} sx={{ mt: 1, py: 0 }} data-testid="choices-list-note">{note.text}</Alert>}
    </Box>
  );
}
