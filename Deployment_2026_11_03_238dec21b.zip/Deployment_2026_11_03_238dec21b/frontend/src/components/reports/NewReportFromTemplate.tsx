/**
 * NewReportFromTemplate -- a report started from a design (2026-11-02; the owner: "along
 * with some report templates").  Template cards (a wireframe each) -> the dataset -> the slots
 * (prefilled from the column types, editable) -> a name and a theme (the gallery) -> Create.
 *
 * The server builds the payloads (POST /api/report-templates/{id}/build, a pure function)
 * and the report is created through the EXISTING routes -- POST /api/business-reports, then
 * PUT .../parameters/batch -- exactly as the editor saves by hand, so a template can never
 * save what the product refuses.  If the parameters fail after the report was created, the
 * half-made report is switched off (DELETE = switch off) and the reason shown.
 */
import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Alert, Autocomplete, Box, Button, Chip, CircularProgress, Paper, Stack, Step, StepLabel, Stepper, TextField, Typography,
} from '@mui/material';
import api from '../../services/api';
import ThemeGallery from './ThemeGallery';
import { DEFAULT_THEME_NAME, SHIPPED_THEMES, resolveTheme } from './canvas/canvasTheme';
import { reportPath } from '../../utils/reportUrls';

export interface TemplateSlot { id: string; kind: 'date' | 'category' | 'amount'; label: string; min: number; max: number; help: string }
export interface Template { id: string; name: string; description: string; theme: string; slots: TemplateSlot[]; preview: { kind: string; x: number; y: number; w: number; h: number }[]; pages: string[] }
interface SlotColumn { id: number; label: string; physical_name?: string; kind: 'date' | 'category' | 'amount' | null; hidden?: boolean }

const KIND_WORDS: Record<string, string> = { date: 'a date column', category: 'a text column', amount: 'a number column' };
const STEPS = ['Design', 'Data', 'Columns', 'Name and look'];

/** A small picture of the design: its tiles on the 12-column grid, a kind each. */
export function TemplateWireframe({ template, theme, width = 220 }: { template: Template; theme?: string; width?: number }) {
  const t = resolveTheme({ theme: { name: theme || template.theme } });
  const rows = Math.max(1, ...template.preview.map(p => p.y + p.h));
  const unit = width / 12;
  const h = rows * unit * 0.8 + 4;
  const fill = (kind: string, i: number) => {
    if (kind === 'band') return t.band.bg;
    if (kind === 'number') return t.kpi.fills[i % t.kpi.fills.length];
    if (kind === 'report' || kind === 'table') return t.grid.header_bg;
    return t.palette[i % t.palette.length];
  };
  const pageBg = t.page.bg === 'app' ? '#f4f6fa' : t.page.bg;
  return (
    <svg width={width} height={h} viewBox={`0 0 ${width} ${h}`} role="img" aria-label={`${template.name} design`} data-testid={`template-wireframe-${template.id}`}>
      <rect x={0} y={0} width={width} height={h} rx={6} fill={pageBg} />
      {template.preview.map((p, i) => (
        <g key={i}>
          <rect x={p.x * unit + 2} y={p.y * unit * 0.8 + 2} width={p.w * unit - 4} height={p.h * unit * 0.8 - 4} rx={3}
            fill={t.card.bg === 'app' ? '#ffffff' : t.card.bg} stroke="#d9dde5" />
          {p.kind === 'band' && <rect x={p.x * unit + 2} y={p.y * unit * 0.8 + 2} width={p.w * unit - 4} height={p.h * unit * 0.8 - 4} rx={3} fill={fill('band', i)} />}
          {p.kind === 'number' && <rect x={p.x * unit + 5} y={p.y * unit * 0.8 + 5} width={p.w * unit - 10} height={p.h * unit * 0.8 - 10} rx={3} fill={fill('number', i)} opacity={0.9} />}
          {['bar', 'hbar', 'stacked_bar', 'waterfall'].includes(p.kind) && [0.2, 0.45, 0.7].map((f, k) => (
            <rect key={k} x={p.x * unit + 6 + k * ((p.w * unit - 12) / 3)} y={p.y * unit * 0.8 + 6 + (p.h * unit * 0.8 - 12) * (1 - f) * 0.6}
              width={(p.w * unit - 12) / 3 - 4} height={(p.h * unit * 0.8 - 12) * f * 0.6 + 4} fill={fill(p.kind, k)} />))}
          {p.kind === 'line' && <polyline points={`${p.x * unit + 6},${p.y * unit * 0.8 + p.h * unit * 0.8 - 8} ${p.x * unit + p.w * unit / 3},${p.y * unit * 0.8 + 10} ${p.x * unit + 2 * p.w * unit / 3},${p.y * unit * 0.8 + p.h * unit * 0.4} ${p.x * unit + p.w * unit - 6},${p.y * unit * 0.8 + 8}`} fill="none" stroke={fill('line', 0)} strokeWidth={2} />}
          {['donut', 'treemap', 'heatmap'].includes(p.kind) && <circle cx={p.x * unit + p.w * unit / 2} cy={p.y * unit * 0.8 + p.h * unit * 0.4} r={Math.min(p.w * unit, p.h * unit * 0.8) / 3} fill="none" stroke={fill(p.kind, 1)} strokeWidth={6} />}
          {['table', 'report', 'outline'].includes(p.kind) && [0, 1, 2].map(k => (
            <rect key={k} x={p.x * unit + 6} y={p.y * unit * 0.8 + 6 + k * 7} width={p.w * unit - 12} height={4} fill={k === 0 ? fill('table', 0) : '#e3e6ec'} />))}
        </g>
      ))}
    </svg>
  );
}

export default function NewReportFromTemplate() {
  const navigate = useNavigate();
  const [templates, setTemplates] = useState<Template[] | null>(null);
  const [loadError, setLoadError] = useState('');
  const [picked, setPicked] = useState<Template | null>(null);
  const [datasets, setDatasets] = useState<any[]>([]);
  const [dataset, setDataset] = useState<any | null>(null);
  const [columns, setColumns] = useState<SlotColumn[]>([]);
  const [slots, setSlots] = useState<Record<string, number[]>>({});
  const [words, setWords] = useState<string[]>([]);
  const [name, setName] = useState('');
  const [theme, setTheme] = useState<string>('');
  const [library, setLibrary] = useState<Record<string, any>>({});
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');
  const [notes, setNotes] = useState<string[]>([]);
  const step = !picked ? 0 : !dataset ? 1 : 2;

  useEffect(() => {
    api.listReportTemplates().then((r: any) => setTemplates(r?.templates || [])).catch((e: any) => setLoadError(e?.message || 'The designs could not be read.'));
    api.listDatasets().then((r: any) => setDatasets(Array.isArray(r) ? r : r?.items || r?.datasets || [])).catch(() => setDatasets([]));
    (api as any).listReportThemes?.().then((r: any) => { const lib: Record<string, any> = {}; for (const t of r?.library || []) lib[t.name] = t.theme; setLibrary(lib); }).catch(() => undefined);
  }, []);

  const pickDataset = async (ds: any | null) => {
    setDataset(ds); setSlots({}); setColumns([]); setWords([]); setError('');
    if (!ds || !picked) return;
    setBusy('Looking at the columns…');
    try {
      const r = await api.suggestReportTemplateSlots(picked.id, ds.id);
      setColumns(r?.columns || []);
      setSlots(r?.slots || {});
      setWords(r?.words || []);
      if (!name) setName(`${picked.name} — ${ds.name}`);
    } catch (e: any) { setError(e?.payload?.message || e?.detail?.message || e?.message || 'The dataset could not be read.'); }
    finally { setBusy(''); }
  };

  const slotProblems = useMemo(() => {
    if (!picked) return [];
    const out: string[] = [];
    for (const s of picked.slots) {
      const n = (slots[s.id] || []).length;
      if (n < s.min) out.push(`'${s.label}' needs at least ${s.min} column${s.min > 1 ? 's' : ''}.`);
      if (n > s.max) out.push(`'${s.label}' takes at most ${s.max} column${s.max > 1 ? 's' : ''}.`);
    }
    const all = Object.values(slots).flat();
    if (new Set(all).size !== all.length) out.push('The same column fills two slots; pick a different column for one of them.');
    return out;
  }, [picked, slots]);

  // what the design will say about this deployment (e.g. no business calendar) -- a preview build, nothing written
  useEffect(() => {
    if (!picked || !dataset || slotProblems.length || !columns.length) { setNotes([]); return; }
    let live = true;
    api.buildReportFromTemplate(picked.id, { dataset_id: dataset.id, slots, name: 'Preview', theme: theme || undefined })
      .then((b: any) => { if (live) setNotes(b?.notes || []); }).catch(() => { if (live) setNotes([]); });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [picked?.id, dataset?.id, JSON.stringify(slots), theme, columns.length]);

  const create = async () => {
    if (!picked || !dataset) return;
    setError(''); setBusy('Building the report…');
    let created: any = null;
    try {
      const built = await api.buildReportFromTemplate(picked.id, { dataset_id: dataset.id, slots, name: name.trim(), theme: theme || undefined });
      setBusy('Creating the report…');
      created = await api.createBusinessReport(built.report);
      if (built.parameters?.length) {
        setBusy('Adding its parameters…');
        await api.batchSaveBusinessReportParams(created.id, built.parameters);
      }
      navigate(reportPath(created));
    } catch (e: any) {
      const why = e?.payload?.message || e?.detail?.message || e?.payload?.detail?.message || e?.message || 'The report could not be created.';
      if (created?.id) {
        // a half-created report is never left behind: switched off (not erased), the reason shown
        try { await api.deleteBusinessReport(created.id); } catch { /* the reason below is what matters */ }
        setError(`The report was created but its parameters could not be saved, so it was switched off again. ${why}`);
      } else {
        setError(why);
      }
    } finally { setBusy(''); }
  };

  const columnsOf = (kind: string) => columns.filter(c => !c.hidden && (c.kind === kind || kind === 'any'));
  const label = (id: number) => columns.find(c => c.id === id)?.label ?? `column #${id}`;

  return (
    <Box sx={{ p: 2, maxWidth: 1200, mx: 'auto' }} data-testid="new-report-from-template">
      <Typography variant="h5" sx={{ mb: 0.5 }}>New report from a template</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Pick a design, pick the data, say which columns fill its slots, name it. The report is created like any other and can be changed afterwards.
      </Typography>
      <Stepper activeStep={step} sx={{ mb: 2 }}>{STEPS.map(s => <Step key={s}><StepLabel>{s}</StepLabel></Step>)}</Stepper>
      {loadError && <Alert severity="error">{loadError}</Alert>}
      {templates === null && !loadError && <CircularProgress size={22} />}

      {templates && (
        <Stack direction="row" flexWrap="wrap" gap={1.5} sx={{ mb: 2 }} data-testid="template-cards">
          {templates.map(t => (
            <Paper key={t.id} variant="outlined" role="button" tabIndex={0} aria-pressed={picked?.id === t.id} data-testid={`template-card-${t.id}`}
              onClick={() => { setPicked(t); setTheme(''); setDataset(null); setSlots({}); setError(''); }}
              onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setPicked(t); } }}
              sx={{ width: 236, p: 1, cursor: 'pointer', borderColor: picked?.id === t.id ? 'primary.main' : 'divider', borderWidth: picked?.id === t.id ? 2 : 1 }}>
              <TemplateWireframe template={t} />
              <Typography variant="subtitle2" sx={{ mt: 0.5 }}>{t.name}</Typography>
              <Typography variant="caption" color="text.secondary" component="div">{t.description}</Typography>
              {t.pages.length > 0 && <Stack direction="row" gap={0.5} sx={{ mt: 0.5 }}>{t.pages.map(p => <Chip key={p} size="small" label={p} />)}</Stack>}
            </Paper>
          ))}
        </Stack>
      )}

      {picked && (
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }} data-testid="template-data">
          <Typography variant="subtitle1">{picked.name}: the data</Typography>
          <Autocomplete size="small" options={datasets} getOptionLabel={(d: any) => d?.name ?? ''} value={dataset} onChange={(_, v) => pickDataset(v)}
            renderInput={p => <TextField {...p} label="Dataset" inputProps={{ ...p.inputProps, 'data-testid': 'template-dataset' }} />} sx={{ maxWidth: 480, mt: 1 }} />
          {busy && <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }} data-testid="template-busy">{busy}</Typography>}
        </Paper>
      )}

      {picked && dataset && columns.length > 0 && (
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }} data-testid="template-slots">
          <Typography variant="subtitle1">Which columns fill the design</Typography>
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 1 }}>Proposed from the column types; change any of them.</Typography>
          {words.map((w, i) => <Alert key={i} severity="warning" sx={{ mb: 1 }} data-testid="template-slot-words">{w}</Alert>)}
          <Stack spacing={1.25}>
            {picked.slots.map(s => (
              <Autocomplete key={s.id} multiple={s.max > 1} size="small" options={columnsOf(s.kind).map(c => c.id)} getOptionLabel={id => label(id as number)}
                value={s.max > 1 ? (slots[s.id] || []) : ((slots[s.id] || [])[0] ?? null)}
                onChange={(_, v) => setSlots(prev => ({ ...prev, [s.id]: v == null ? [] : Array.isArray(v) ? (v as number[]) : [v as number] }))}
                renderInput={p => <TextField {...p} label={`${s.label} (${s.min === s.max ? s.min : `${s.min} to ${s.max}`}; ${KIND_WORDS[s.kind]})`} helperText={s.help}
                  inputProps={{ ...p.inputProps, 'data-testid': `template-slot-${s.id}` }} />} />
            ))}
          </Stack>
          {slotProblems.map((p, i) => <Alert key={i} severity="error" sx={{ mt: 1 }} data-testid="template-slot-problem">{p}</Alert>)}
        </Paper>
      )}

      {picked && dataset && columns.length > 0 && (
        <Paper variant="outlined" sx={{ p: 2, mb: 2 }} data-testid="template-name">
          <Typography variant="subtitle1">Name and look</Typography>
          <TextField size="small" label="Report name" value={name} onChange={e => setName(e.target.value)} sx={{ maxWidth: 480, mt: 1, display: 'block' }}
            inputProps={{ maxLength: 200, 'data-testid': 'template-report-name' }} fullWidth />
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 1.5, mb: 0.5 }}>
            The look: the design suggests <b>{picked.theme}</b>; pick any theme.
          </Typography>
          <ThemeGallery picked={theme || picked.theme || DEFAULT_THEME_NAME} library={library} onPick={n => setTheme(n)} onImport={() => undefined} />
          {theme && !SHIPPED_THEMES[theme] && !library[theme] && <Alert severity="warning" sx={{ mt: 1 }}>There is no theme named {theme}.</Alert>}
          {notes.map((n, i) => <Alert key={i} severity="info" sx={{ mt: 1 }} data-testid="template-note">{n}</Alert>)}
          {error && <Alert severity="error" sx={{ mt: 1 }} data-testid="template-error">{error}</Alert>}
          <Stack direction="row" spacing={1} sx={{ mt: 2 }}>
            <Button variant="contained" onClick={create} disabled={!!busy || !name.trim() || slotProblems.length > 0} data-testid="template-create">Create the report</Button>
            <Button onClick={() => navigate('/finance-reports')}>Cancel</Button>
            {busy && <CircularProgress size={20} sx={{ alignSelf: 'center' }} />}
          </Stack>
        </Paper>
      )}
    </Box>
  );
}
