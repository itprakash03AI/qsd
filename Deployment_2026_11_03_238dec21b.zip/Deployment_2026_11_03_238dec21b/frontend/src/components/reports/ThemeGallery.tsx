/**
 * ThemeGallery -- pick a report's look from cards, not a list of names (2026-11-02).
 *
 * The owner: "create some predefined themes for report by following power bi so
 * easy to choose for users ... or any enterprise level reporting".  Every shipped
 * theme (shippedThemes.json, the file the server holds too) is a card on its
 * shelf (THEME_GROUPS): a strip of the band, the grid header and the chart
 * colours, the name and one line on what it is good for.  The organisation's own
 * themes (the library) are a shelf of their own.  A click picks the theme; the
 * fields below the gallery still change anything for this report alone.
 *
 * "Use a Power BI theme file" reads a Power BI report theme (.json:
 * `dataColors`, `tableAccent`, `foreground`, `background`) in the browser and
 * turns it into this report's colours -- nothing is uploaded; Save stores it
 * like any other change, and the same contrast rules apply.
 */
import React, { useRef, useState } from 'react';
import { Alert, Box, Button, Stack, Tooltip, Typography } from '@mui/material';
import {
  DEFAULT_THEME_NAME, SHIPPED_THEMES, THEME_GROUPS, ThemeSpec, appColour, contrastRatio, isHex, kpiFill, kpiGradient,
  resolveTheme, sanitizeTheme,
} from './canvas/canvasTheme';

const OTHER = 'Other';

function Card({ name, theme, picked, onPick }: { name: string; theme: any; picked: boolean; onPick: () => void }) {
  const t = resolveTheme({ theme: { name } }, null);
  // a library theme's body overrides the shipped look of the same name (the resolver's rule)
  const look = sanitizeTheme({ ...t, ...(theme || {}), name });
  const band = look.band;
  const grid = look.grid;
  const palette: string[] = look.palette;
  // theme v2: the page behind the cards, a card, and a KPI card in the theme's style
  const fill = kpiFill(look, 0);
  const kpiSx = look.kpi.style === 'plain'
    ? { bgcolor: appColour(look.card.bg), color: appColour(look.card.fg, true), border: '1px solid', borderColor: appColour(look.card.border) === '#ffffff' ? '#e0e0e0' : appColour(look.card.border) }
    : { background: look.kpi.style === 'gradient' ? kpiGradient(fill) : fill, color: look.kpi.value_fg };
  return (
    <Tooltip title={(theme && theme.description) || look.description || ''} placement="top" arrow disableInteractive>
      <Box role="button" tabIndex={0} aria-pressed={picked} aria-label={`Theme ${name}`} data-testid={`theme-card-${name}`}
        onClick={onPick} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onPick(); } }}
        sx={{ width: 150, cursor: 'pointer', borderRadius: 1.5, overflow: 'hidden', bgcolor: '#fff',
              border: picked ? '2px solid' : '1px solid', borderColor: picked ? 'primary.main' : 'divider',
              boxShadow: picked ? 3 : 0, '&:hover': { boxShadow: 2 }, '&:focus-visible': { outline: '2px solid', outlineColor: 'primary.main' } }}>
        <Box sx={{ bgcolor: band.bg, color: band.fg, px: 1, py: 0.5, fontSize: 11, fontFamily: band.font, whiteSpace: 'nowrap', overflow: 'hidden' }}>
          Date&nbsp;&nbsp;Period&nbsp;&nbsp;Currency
        </Box>
        <Box data-testid={`theme-card-page-${name}`} sx={{ bgcolor: appColour(look.page.bg), p: 0.5, display: 'flex', gap: 0.5 }}>
          <Box data-testid={`theme-card-kpi-${name}`} data-kpi-style={look.kpi.style} sx={{ ...kpiSx, flex: 1, borderRadius: `${Math.min(8, look.tiles.radius)}px`, px: 0.75, py: 0.25, fontSize: 10, lineHeight: 1.2 }}>
            <div style={{ fontSize: 8, opacity: 0.85 }}>Assets</div><div style={{ fontWeight: 700 }}>7.6M <span style={{ color: look.kpi.style === 'plain' ? look.kpi.up_fg : undefined }}>▲ 9%</span></div>
          </Box>
          <Box sx={{ flex: 1, bgcolor: appColour(look.card.bg), color: appColour(look.card.fg, true), borderRadius: `${Math.min(8, look.tiles.radius)}px`, overflow: 'hidden', border: '1px solid', borderColor: appColour(look.card.border) === '#ffffff' ? '#e0e0e0' : appColour(look.card.border) }}>
            <Box sx={{ bgcolor: grid.header_bg, color: grid.header_fg, px: 0.5, fontSize: 8, fontWeight: 700 }}>AREA&nbsp;&nbsp;PNL</Box>
            <Box sx={{ px: 0.5, fontSize: 8 }}>EM&nbsp;&nbsp;(108)</Box>
          </Box>
        </Box>
        <Stack direction="row" spacing={0.25} sx={{ px: 1, py: 0.75 }}>
          {palette.slice(0, 8).map((c, i) => <Box key={i} sx={{ width: 14, height: 14, bgcolor: c, borderRadius: 0.5 }} />)}
        </Stack>
        <Typography sx={{ px: 1, pb: 0.75, fontSize: 12, fontWeight: picked ? 700 : 500 }} noWrap>{name}</Typography>
      </Box>
    </Tooltip>
  );
}

/** A Power BI report theme -> this report's colours (the fields a Power BI theme
 *  file carries; anything else in it is ignored and said). */
export function fromPowerBiTheme(file: any): { spec: ThemeSpec; note: string } {
  if (!file || typeof file !== 'object') throw new Error('This is not a Power BI theme file (it should be JSON with "dataColors").');
  const colours: string[] = (Array.isArray(file.dataColors) ? file.dataColors : []).map((c: any) => String(c || '').trim().toLowerCase())
    .map((c: string) => (/^#[0-9a-f]{3}$/.test(c) ? `#${c[1]}${c[1]}${c[2]}${c[2]}${c[3]}${c[3]}` : c)).filter(isHex);
  if (!colours.length) throw new Error('The file has no "dataColors" in the form #rrggbb, so there are no colours to use.');
  const pick = (v: any) => (isHex(String(v || '').toLowerCase()) ? String(v).toLowerCase() : '');
  const accent = pick(file.tableAccent) || colours[0];
  const text = (bg: string) => (contrastRatio('#ffffff', bg) >= contrastRatio('#111111', bg) ? '#ffffff' : '#111111');
  const fg = pick(file.foreground);
  const title = fg && contrastRatio(fg, '#ffffff') >= 4.5 ? fg : (contrastRatio(accent, '#ffffff') >= 4.5 ? accent : '#1f2933');
  const palette = [...colours];
  const def = SHIPPED_THEMES[DEFAULT_THEME_NAME].palette;
  for (const c of def) { if (palette.length >= 8) break; if (!palette.includes(c)) palette.push(c); }
  const spec: ThemeSpec = {
    band: { bg: accent, fg: text(accent), label_fg: text(accent) },
    title: { color: title },
    grid: { header_bg: accent, header_fg: text(accent), subtotal: { fg: title }, grand: { bg: '#f3f5f8', fg: title } },
    palette: palette.slice(0, 8),
  };
  const name = typeof file.name === 'string' && file.name.trim() ? `"${file.name.trim().slice(0, 60)}"` : 'the file';
  const extra = colours.length > 8 ? ` It has ${colours.length} chart colours; the first 8 are used.` : '';
  return { spec, note: `The colours of ${name} are applied to this report: the band and grid header use its table accent, the charts its data colours.${extra} Press Save to keep them.` };
}

export default function ThemeGallery({ picked, library, onPick, onImport }: {
  picked: string; library: Record<string, any>; onPick: (name: string) => void;
  /** absent = no "Use a Power BI theme file" (the viewer's "View in another theme" only names a theme) */
  onImport?: (spec: ThemeSpec, note: string) => void;
}) {
  const [err, setErr] = useState('');
  const fileRef = useRef<HTMLInputElement | null>(null);
  const shelves: Record<string, string[]> = {};
  for (const [name, t] of Object.entries(SHIPPED_THEMES)) {
    const g = THEME_GROUPS.includes((t as any).group) ? (t as any).group : OTHER;
    (shelves[g] = shelves[g] || []).push(name);
  }
  const order = [...THEME_GROUPS, OTHER].filter(g => shelves[g]?.length);
  const libNames = Object.keys(library || {});
  const read = (f: File) => {
    setErr('');
    f.text().then(txt => {
      const { spec, note } = fromPowerBiTheme(JSON.parse(txt));
      onImport?.(spec, note);
    }).catch((e: any) => setErr(e instanceof SyntaxError ? 'The file could not be read as JSON. A Power BI theme file is a .json file.' : (e?.message || 'The file could not be used.')));
  };
  return (
    <Stack spacing={1.5} data-testid="theme-gallery">
      {libNames.length > 0 && (
        <Box>
          <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Your organisation's themes</Typography>
          <Stack direction="row" flexWrap="wrap" gap={1}>
            {libNames.map(n => <Card key={n} name={n} theme={library[n]} picked={picked === n} onPick={() => onPick(n)} />)}
          </Stack>
        </Box>
      )}
      {order.map(g => (
        <Box key={g} data-testid={`theme-shelf-${g}`}>
          <Typography variant="subtitle2" sx={{ mb: 0.5 }}>{g}</Typography>
          <Stack direction="row" flexWrap="wrap" gap={1}>
            {shelves[g].map(n => <Card key={n} name={n} theme={SHIPPED_THEMES[n]} picked={picked === n} onPick={() => onPick(n)} />)}
          </Stack>
        </Box>
      ))}
      {onImport && <Box>
        <input ref={fileRef} type="file" accept=".json,application/json" hidden data-testid="theme-powerbi-file"
          onChange={e => { const f = e.target.files?.[0]; if (f) read(f); e.target.value = ''; }} />
        <Button size="small" variant="outlined" onClick={() => fileRef.current?.click()} data-testid="theme-powerbi-import">
          Use a Power BI theme file…
        </Button>
        {err && <Alert severity="error" sx={{ mt: 1 }} data-testid="theme-powerbi-error">{err}</Alert>}
      </Box>}
    </Stack>
  );
}
