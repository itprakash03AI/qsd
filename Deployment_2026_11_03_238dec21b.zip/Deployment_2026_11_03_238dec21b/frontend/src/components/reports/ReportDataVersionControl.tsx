/**
 * "Data version" -- on the report viewer's run panel (2026-11-01).
 *
 * Shown ONLY when the report reads a source that keeps versions: the server
 * says so (GET /api/business-reports/{id}/data-versions, `supported`); a
 * report over anything else draws nothing.  One row per table per side:
 *
 *   As saved (default)  -- nothing is sent; the dataset's own pin, else latest
 *   Latest              -- "latest": the current version, even over a saved pin
 *   a version           -- {snapshot_id}: id · commit time · what it did · rows
 *   As of a time...     -- {as_of}: a date-time, in UTC
 *
 * The choice travels as `data_version` on the run body, the shape
 * business_reports_api._with_data_version reads (`{table: ...}`); the server
 * checks it and a refusal (422) is shown here in its own words.  A table name
 * on two sides takes ONE key, so a version number (which belongs to one side's
 * table) is not offered for it -- a time or Latest is.
 *
 * The option words, the time and the as-of input are the SQL page's
 * (components/common/tableVersionWords.tsx).
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, FormControl, InputLabel, MenuItem, Select, TextField, Typography,
} from '@mui/material';
import api from '../../services/api';
import type { ReportDataVersions, ReportDataVersionTable } from '../../services/api/businessReports';
import { asOfInputValue, shortTime, versionMenuItems } from '../common/tableVersionWords';
import { BandCell } from './ReportBand';
import type { ReportTheme } from './canvas/canvasTheme';

export const AS_SAVED = '__as_saved__';
export const LATEST = '__latest__';
export const AS_OF = '__as_of__';

/** One table's choice: a sentinel above, or a snapshot id; `asOf` an ISO time (UTC). */
export interface DataVersionChoice { value: string; asOf?: string | null }
export type DataVersionChoices = Record<string, DataVersionChoice>;

/** The key a table takes in `data_version` (the server reads names case-blind). */
export const tableKey = (t: { table: string }) => String(t.table).toLowerCase();

/** The run body's `data_version` from the choices; undefined when every
 *  table is "As saved" (the body then carries nothing -- the old request). */
export function buildDataVersion(choices: DataVersionChoices): Record<string, any> | undefined {
  const out: Record<string, any> = {};
  for (const [key, c] of Object.entries(choices || {})) {
    if (!c || c.value === AS_SAVED) continue;
    if (c.value === LATEST) out[key] = 'latest';
    else if (c.value === AS_OF) { if (c.asOf) out[key] = { as_of: c.asOf }; }
    else out[key] = { snapshot_id: c.value };
  }
  return Object.keys(out).length ? out : undefined;
}

/** "As saved (version 123 from the query)" / "As saved (latest)". */
export function asSavedWords(t: ReportDataVersionTable): string {
  const s = t.saved;
  if (s?.snapshot_id) return `As saved (version ${s.snapshot_id}, pinned in the query)`;
  if (s?.as_of_ms) return `As saved (as of ${shortTime(new Date(s.as_of_ms).toISOString())}, pinned in the query)`;
  return 'As saved (latest)';
}

interface Props {
  reportId: number;
  choices: DataVersionChoices;
  onChange: (choices: DataVersionChoices) => void;
  /** the server's refusal of the last run's data_version (a 422), shown in its words */
  refusal?: string | null;
  /** 2026-11-01 -- the listing already read (the band cell reads it once) */
  answer?: ReportDataVersions | null;
}

const ReportDataVersionControl: React.FC<Props> = ({ reportId, choices, onChange, refusal, answer: given }) => {
  const [read, setAnswer] = useState<ReportDataVersions | null>(null);
  const [failed, setFailed] = useState<string | null>(null);
  const answer = given ?? read;

  useEffect(() => {
    let live = true;
    const get = (api as any).getReportDataVersions;
    if (given || !reportId || typeof get !== 'function') return undefined;
    Promise.resolve(get(reportId))
      .then((a: ReportDataVersions) => { if (live) { setAnswer(a); setFailed(null); } })
      .catch((e: any) => { if (live) setFailed(e?.message || String(e)); });
    return () => { live = false; };
  }, [reportId, given]);

  // nothing to choose: a source without versions, or a server without the route
  if (!answer || !answer.supported || !answer.tables?.length) {
    return refusal ? <Alert severity="error" data-testid="data-version-refusal" sx={{ mb: 1 }}>{refusal}</Alert> : null;
  }

  const set = (key: string, c: DataVersionChoice) => onChange({ ...choices, [key]: c });

  return (
    <Box data-testid="data-version" sx={{ px: 1.5, py: 1, display: 'flex', flexDirection: 'column', gap: 1 }}>
      <Typography variant="body2" color="text.secondary">Data version</Typography>
      {failed ? (
        <Typography variant="caption" color="error" data-testid="data-version-failed">
          {`The versions could not be read: ${failed}`}
        </Typography>
      ) : null}
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.5 }}>
        {answer.tables.map((t) => {
          const key = tableKey(t);
          const rowId = `${key}-${t.connection_id}`;
          const c = choices[key] || { value: AS_SAVED };
          const label = `${t.table} (${t.side})`;
          const versionsOff = !!t.on_several_sides;
          return (
            <Box key={rowId} sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}
                 data-testid={`data-version-row-${rowId}`}>
              <FormControl size="small" sx={{ minWidth: 300 }}>
                <InputLabel id={`dv-${rowId}-label`}>{label}</InputLabel>
                <Select
                  labelId={`dv-${rowId}-label`}
                  label={label}
                  value={c.value}
                  onChange={(e) => set(key, { value: String(e.target.value), asOf: null })}
                  inputProps={{ 'data-testid': `data-version-${rowId}`, 'aria-label': `Data version of ${label}` }}
                  renderValue={(v) => (v === AS_SAVED ? asSavedWords(t)
                    : v === LATEST ? 'Latest'
                    : v === AS_OF ? (c.asOf ? `As of ${shortTime(c.asOf)}` : 'As of a time...')
                    : `Version ${v}`)}
                >
                  <MenuItem value={AS_SAVED} data-testid={`data-version-as-saved-${rowId}`}>{asSavedWords(t)}</MenuItem>
                  <MenuItem value={LATEST} data-testid={`data-version-latest-${rowId}`}>Latest</MenuItem>
                  <MenuItem value={AS_OF} data-testid={`data-version-as-of-${rowId}`}>As of a time...</MenuItem>
                  {versionMenuItems(t.versions, `data-version-option-${rowId}`, versionsOff)}
                </Select>
                {versionsOff ? (
                  <Typography variant="caption" color="text.secondary" data-testid={`data-version-several-${rowId}`}>
                    {`${t.table} is read on more than one side; a version number belongs to one side, so pick a time or Latest.`}
                  </Typography>
                ) : null}
                {t.access_words ? (
                  <Typography variant="caption" color="text.secondary" data-testid={`data-version-access-${rowId}`}>{t.access_words}</Typography>
                ) : null}
                {t.versions === null && (t.reason || t.error) ? (
                  <Typography variant="caption" color={t.error ? 'error' : 'text.secondary'}
                              data-testid={`data-version-reason-${rowId}`}>{t.error || t.reason}</Typography>
                ) : null}
              </FormControl>
              {c.value === AS_OF ? (
                <TextField
                  size="small" type="datetime-local" label="As of (UTC)"
                  InputLabelProps={{ shrink: true }}
                  defaultValue={c.asOf ? asOfInputValue(Date.parse(c.asOf)) : ''}
                  inputProps={{ 'data-testid': `data-version-as-of-input-${rowId}`, 'aria-label': `As of time for ${label}` }}
                  onBlur={(e) => {
                    if (e.target.value) set(key, { value: AS_OF, asOf: new Date(e.target.value + ':00Z').toISOString() });
                  }}
                />
              ) : null}
            </Box>
          );
        })}
      </Box>
      {refusal ? <Alert severity="error" data-testid="data-version-refusal">{refusal}</Alert> : null}
    </Box>
  );
};

/** The band cell's words: "As saved" / "Latest" / "Version 123" / "As of 18:12" / "2 tables set". */
export function dataVersionWords(choices: DataVersionChoices): string {
  const set = Object.values(choices || {}).filter(c => c && c.value !== AS_SAVED && !(c.value === AS_OF && !c.asOf));
  if (!set.length) return 'As saved';
  if (set.length > 1) return `${set.length} tables set`;
  const c = set[0];
  if (c.value === LATEST) return 'Latest';
  if (c.value === AS_OF) return `As of ${shortTime(c.asOf as string)}`;
  return `Version ${c.value}`;
}

/** 2026-11-01 -- "Data version" as a cell of the report's band: drawn ONLY when
 *  the report reads a source that keeps versions (the server says so -- the page
 *  reads the listing once and hands it here); the picker is the control above;
 *  "Run with this version" re-runs the report. */
export function DataVersionBandCell({ reportId, answer, choices, onChange, theme, onApply }: {
  reportId: number; answer: ReportDataVersions | null; choices: DataVersionChoices; onChange: (c: DataVersionChoices) => void;
  theme: ReportTheme; onApply: () => void;
}) {
  if (!answer || !answer.supported || !answer.tables?.length) return null;
  return (
    <BandCell label="Data version" value={dataVersionWords(choices)} testId="band-cell-data-version" theme={theme} popoverWidth={560}>
      {(close) => (
        <Box sx={{ pb: 1 }}>
          <ReportDataVersionControl reportId={reportId} choices={choices} onChange={onChange} answer={answer} />
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', px: 1.5 }}>
            <Button variant="contained" size="small" data-testid="band-cell-data-version-apply"
              onClick={() => { close(); onApply(); }}>Run with this version</Button>
          </Box>
        </Box>
      )}
    </BandCell>
  );
}

export default ReportDataVersionControl;
