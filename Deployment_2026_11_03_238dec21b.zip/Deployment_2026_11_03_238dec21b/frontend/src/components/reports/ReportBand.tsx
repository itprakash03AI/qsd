/**
 * ReportBand -- THE BAND IS THE CONTROL (2026-11-01).
 *
 * The owner: "don't see parameters to select, it can't be always the same
 * business date ... how generic parameters work is still a black box".  The
 * themed band at the top of a report used to SHOW the values while a separate
 * "Report controls" form above it took them.  Now every VISIBLE parameter of
 * the report is one cell of the band -- the label small on top, the value big
 * below, in the report theme's band colours -- and a click on a cell opens its
 * picker right under it (an MUI Popover: keyboard reachable, Esc closes):
 *
 *   a business date   the dates the source HAS (the parameter's own list, newest
 *                     first, searchable), "Pick from calendar" for a far date,
 *                     and arrows in the cell: previous / next business day on the
 *                     REPORT's calendar (GET .../business-day, the server's rule)
 *   a period          its buttons
 *   a dropdown        a searchable list, "All" first
 *   a multi-select    a searchable checkbox list, All / Clear, Apply
 *   anything else     the report's own small input (ReportParamControl), Apply
 *
 * Picking re-runs the report (`onPick(next values)`).  Nothing here is about one
 * report: the cells come from the report's parameter definitions (order, label,
 * type, list, default, visibility) and the colours from its theme.  Hidden
 * parameters are never drawn (they always run with their default); a cell never
 * shows an empty value ("All", "Not set", "Any" instead).
 *
 * The canvas band tile draws the same cells when the page provides
 * `BandControlsContext` (CanvasOutlineTile.CanvasBandTile); the viewer draws a
 * `ReportBand` for every parameter no band tile shows.
 */
import React, { createContext, useEffect, useMemo, useRef, useState } from 'react';
import {
  Box, Button, ButtonBase, Checkbox, CircularProgress, IconButton, Link, List, ListItemButton,
  ListItemIcon, ListItemText, Popover, TextField, Tooltip, Typography,
} from '@mui/material';
import { alpha } from '@mui/material/styles';
import {
  ArrowDropDown as ArrowDropDownIcon, ChevronLeft as PrevIcon, ChevronRight as NextIcon,
} from '@mui/icons-material';
import { readValueList, valueToText } from '../common/ColumnValuePicker';
import ReportParamControl, {
  PERIOD_OPTIONS, applyParamChange, paramShown, type ParamValuesFetch,
} from './ReportParamControl';
import type { ReportTheme } from './canvas/canvasTheme';
import { MAX_CHIP_CHOICES } from './canvas/canvasOutline';

// ── words ─────────────────────────────────────────────────────────────────

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
const ISO_DAY = /^(\d{4})-(\d{2})-(\d{2})$/;

/** "2026-10-30" -> "30-OCT-2026"; anything else as it is. */
export function bandDate(v: any): string {
  const s = valueToText(v);
  const m = ISO_DAY.exec(s.slice(0, 10));
  if (!m || s.length > 10 && !/^[T ]00:00/.test(s.slice(10))) return s;
  return `${m[3]}-${MONTHS[Number(m[2]) - 1] ?? m[2]}-${m[1]}`;
}

/** "30-OCT-2026", "30 oct 2026", "2026-10-30" -> "2026-10-30" (null = not a date). */
export function parseTypedDate(text: string): string | null {
  const t = text.trim();
  if (ISO_DAY.test(t)) return t;
  const m = /^(\d{1,2})[-\s/]([A-Za-z]{3})[A-Za-z]*[-\s/](\d{4})$/.exec(t);
  if (!m) return null;
  const mi = MONTHS.indexOf(m[2].toUpperCase());
  if (mi < 0) return null;
  return `${m[3]}-${String(mi + 1).padStart(2, '0')}-${m[1].padStart(2, '0')}`;
}

const isEmpty = (v: any) => v == null || v === '' || (Array.isArray(v) && v.length === 0)
  || (typeof v === 'object' && !Array.isArray(v) && !Object.values(v).some(x => x != null && x !== ''));

/** The words a cell shows for a parameter's value -- never empty. */
export function bandCellWords(p: any, v: any, labels?: Record<string, string>): string {
  const t = p.parameter_type;
  const lab = (k: any) => (labels && labels[String(k)]) || String(k);
  if (t === 'period') {
    const o = PERIOD_OPTIONS.find(x => x.value === String(v || '').toLowerCase());
    return o ? o.label.toUpperCase() : (v ? String(v) : 'Not set');
  }
  if (t === 'multi_select') {
    const list: any[] = Array.isArray(v) ? v.filter(x => x != null && x !== '') : (v ? [v] : []);
    if (!list.length) return 'All';
    return list.length <= 2 ? list.map(lab).join(', ') : `${list.length} selected`;
  }
  if (t === 'date') return isEmpty(v) ? 'Not set' : bandDate(v);
  if (t === 'date_range') {
    if (isEmpty(v)) return 'Any dates';
    const f = v?.from ? bandDate(v.from) : '…', to = v?.to ? bandDate(v.to) : '…';
    return `${f} – ${to}`;
  }
  if (t === 'cob_compare') {
    if (isEmpty(v)) return 'Not set';
    return `${v?.a ? bandDate(v.a) : '…'} vs ${v?.b ? bandDate(v.b) : '…'}`;
  }
  if (t === 'number_range') {
    if (isEmpty(v)) return 'Any';
    return `${v?.min ?? v?.from ?? '…'} – ${v?.max ?? v?.to ?? '…'}`;
  }
  if (t === 'boolean') return v === true || String(v).toLowerCase() === 'true' ? 'Yes' : (isEmpty(v) ? 'Any' : 'No');
  if (t === 'hierarchy') {
    const parts = v && typeof v === 'object' ? Object.values(v).filter(x => x != null && x !== '') : [];
    return parts.length ? parts.map(String).join(' › ') : 'All';
  }
  if (isEmpty(v)) {
    if (p.source_column) return 'As in the query';
    return ['dropdown', 'multi_select'].includes(t) || p.lov_column_id ? 'All' : 'Any';
  }
  return Array.isArray(v) ? v.map(lab).join(', ') : lab(v);
}

// ── what the page hands the band ──────────────────────────────────────────

export interface BusinessDayAnswer { date: string; calendar_words?: string }

export interface BandControls {
  /** every parameter of the report, in the report's order */
  params: any[];
  values: Record<string, any>;
  fetchValues: ParamValuesFetch;
  /** a pick: the next values -- the page sets them and re-runs */
  onPick: (next: Record<string, any>) => void;
  /** previous / next business day on the report's calendar (the server's rule) */
  businessDay?: (date: string, step: 1 | -1, paramName: string) => Promise<BusinessDayAnswer>;
  /** cells the page adds at the end (the Data version cell) -- drawn only when given */
  extras?: React.ReactNode;
  /** 2026-11-01 -- ONE band: the visible parameters no band tile lists are appended at the
   *  end of THIS tile's band (the first band tile), never drawn as a second band */
  append?: { tileId: string; names: string[] } | null;
}

/** The date ◀ ▶ moves to in a list of dates that HAVE data: the previous / next one
 *  (a value not in the list moves to the nearest one on that side).  null + why at an end. */
export function stepInList(dates: string[], current: string, dir: 1 | -1, truncated = false): { date: string | null; why: string } {
  const asc = [...new Set(dates.filter(d => ISO_DAY.test(d)))].sort();
  if (!asc.length) return { date: null, why: 'No dates with data are listed.' };
  if (dir === 1) {
    const next = asc.find(d => d > current);
    return next ? { date: next, why: '' } : { date: null, why: 'This is the newest date that has data.' };
  }
  const prev = [...asc].reverse().find(d => d < current);
  if (prev) return { date: prev, why: '' };
  return { date: null, why: truncated
    ? 'This is the oldest date in the list -- open the list and search, or pick from the calendar.'
    : 'This is the oldest date that has data.' };
}

export const BandControlsContext = createContext<BandControls | null>(null);

/** The parameters a band draws: visible ones (hidden / show-when-not-met never). */
export function bandParams(params: any[], values: Record<string, any>, names?: string[] | null): any[] {
  const shown = (params || []).filter(p => paramShown(p, values));
  if (!names || !names.length) return shown;
  return names.map(n => shown.find(p => p.name === n)).filter(Boolean) as any[];
}

// ── a cell ────────────────────────────────────────────────────────────────

export function BandCell({ label, value, testId, theme, children, prev, next, busy, popoverWidth }: {
  label: string; value: string; testId: string; theme: ReportTheme;
  /** the picker; given `close` */
  children: (close: () => void) => React.ReactNode;
  prev?: { onClick: () => void; title: string; disabled?: boolean } | null;
  next?: { onClick: () => void; title: string; disabled?: boolean } | null;
  busy?: boolean;
  popoverWidth?: number;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  const sep = alpha(theme.band.fg, 0.55);
  const arrowSx = { color: theme.band.fg, p: 0.25, borderRadius: 0.5, '&:hover': { bgcolor: alpha(theme.band.fg, 0.15) } };
  return (
    <Box ref={ref} role="group" aria-label={label} data-testid={testId}
      sx={{ display: 'flex', alignItems: 'center', borderRight: `2px solid ${sep}`, '&:last-of-type': { borderRight: 'none' } }}>
      {prev && (
        <Tooltip title={prev.title}>
          <span><IconButton size="small" aria-label={prev.title} data-testid={`${testId}-prev`} onClick={prev.onClick} disabled={busy || !!prev.disabled} sx={{ ...arrowSx, ml: 0.5 }}>
            <PrevIcon fontSize="small" />
          </IconButton></span>
        </Tooltip>
      )}
      <ButtonBase focusRipple aria-haspopup="dialog" aria-expanded={open} data-testid={`${testId}-open`}
        aria-label={`${label}: ${value}. Change`}
        onClick={() => setOpen(true)}
        sx={{ display: 'block', textAlign: 'left', px: 1.5, py: 0.5, color: 'inherit', fontFamily: 'inherit', borderRadius: 0.5,
              '&:hover, &.Mui-focusVisible': { bgcolor: alpha(theme.band.fg, 0.12) } }}>
        <Typography component="div" sx={{ fontSize: 11, color: theme.band.label_fg, fontFamily: 'inherit', whiteSpace: 'nowrap' }}
          data-testid={`${testId}-label`}>{label}</Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.25 }}>
          <Typography component="div" sx={{ fontFamily: 'inherit', fontSize: 17, fontWeight: 500, whiteSpace: 'nowrap' }}
            data-testid={`${testId}-value`}>{value}</Typography>
          {busy ? <CircularProgress size={12} sx={{ color: theme.band.fg, ml: 0.5 }} /> : <ArrowDropDownIcon sx={{ fontSize: 18, opacity: 0.85 }} />}
        </Box>
      </ButtonBase>
      {next && (
        <Tooltip title={next.title}>
          <span><IconButton size="small" aria-label={next.title} data-testid={`${testId}-next`} onClick={next.onClick} disabled={busy || !!next.disabled} sx={{ ...arrowSx, mr: 0.5 }}>
            <NextIcon fontSize="small" />
          </IconButton></span>
        </Tooltip>
      )}
      <Popover open={open} anchorEl={ref.current} onClose={close}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }} transformOrigin={{ vertical: 'top', horizontal: 'left' }}
        slotProps={{ paper: { 'data-testid': `${testId}-picker`, 'aria-label': `Choose ${label}`, role: 'dialog',
                              sx: { mt: 0.5, width: popoverWidth ?? 320, maxWidth: '95vw' } } as any }}>
        {open ? children(close) : null}
      </Popover>
    </Box>
  );
}

// ── the pickers ───────────────────────────────────────────────────────────

/** The parameter's own list (the report's parameter route): a searchable list
 *  -- checkboxes for a multi-select -- of the values the source has. */
function ListPicker({ p, ctrl, testId, multiple, isDate, onDone }: {
  p: any; ctrl: BandControls; testId: string; multiple: boolean; isDate: boolean;
  onDone: (value: any) => void;
}) {
  const parent = p.depends_on_param_id ? ctrl.params.find((x: any) => x.id === p.depends_on_param_id) : null;
  const parentValues: Record<string, any> = parent ? { [parent.name]: ctrl.values[parent.name] } : {};
  const [state, setState] = useState<{ loading: boolean; values: string[]; labels: Record<string, string>; truncated: boolean; note: string; error: string }>(
    { loading: true, values: [], labels: {}, truncated: false, note: '', error: '' });
  const [q, setQ] = useState('');
  const [found, setFound] = useState<string[] | null>(null);
  const [calendar, setCalendar] = useState(false);
  const [calDate, setCalDate] = useState('');
  const initial: string[] = Array.isArray(ctrl.values[p.name]) ? ctrl.values[p.name].map(valueToText) : [];
  const [picked, setPicked] = useState<string[]>(initial);

  useEffect(() => {
    let live = true;
    Promise.resolve(ctrl.fetchValues({ parameter_id: p.id, parent_values: parentValues }))
      .then((res) => {
        if (!live) return;
        const l = readValueList(res);
        let vals = l.values;
        if (isDate && vals.every(v => ISO_DAY.test(v))) vals = [...vals].sort().reverse();
        if (isDate && !vals.length) setCalendar(true);   // no dates listed: the calendar is the way in
        setState({ loading: false, values: vals, labels: l.labels || {}, truncated: l.truncated,
                   note: l.reason || (vals.length ? '' : 'The source has no values for this selection.'),
                   error: l.status === 'error' ? l.error : '' });
      })
      .catch((e: any) => { if (live) setState(s => ({ ...s, loading: false, error: e?.message || String(e) })); });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.id, JSON.stringify(parentValues)]);

  // a cut list searches the SERVER (every value), else the list in hand
  useEffect(() => {
    if (!state.truncated || !q.trim()) { setFound(null); return undefined; }
    const t = setTimeout(() => {
      Promise.resolve(ctrl.fetchValues({ parameter_id: p.id, parent_values: parentValues, search: q.trim() }))
        .then(res => setFound(readValueList(res).values)).catch(() => setFound(null));
    }, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, state.truncated]);

  const words = (v: string) => (isDate ? bandDate(v) : (state.labels[v] ? `${v} — ${state.labels[v]}` : v));
  const shown = useMemo(() => {
    if (found) return found;
    const needle = q.trim().toLowerCase();
    if (!needle) return state.values;
    return state.values.filter(v => v.toLowerCase().includes(needle) || words(v).toLowerCase().includes(needle)
      || (state.labels[v] || '').toLowerCase().includes(needle));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [found, q, state.values, state.labels]);
  const typed = isDate ? parseTypedDate(q) : null;
  const current = valueToText(ctrl.values[p.name]);

  return (
    <Box sx={{ p: 1 }}>
      <TextField autoFocus size="small" fullWidth placeholder={isDate ? 'Search, or type a date' : 'Search'}
        value={q} onChange={e => setQ(e.target.value)}
        inputProps={{ 'data-testid': `${testId}-search`, 'aria-label': `Search ${p.label || p.name}` }} />
      {multiple && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.5 }}>
          <Button size="small" data-testid={`${testId}-all`} onClick={() => setPicked(Array.from(new Set([...picked, ...shown])))}>All</Button>
          <Button size="small" data-testid={`${testId}-clear`} onClick={() => setPicked([])}>Clear</Button>
          <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto' }} data-testid={`${testId}-count`}>
            {picked.length ? `${picked.length} picked` : 'None picked = all'}
          </Typography>
        </Box>
      )}
      <Box sx={{ maxHeight: 280, overflowY: 'auto', mt: 0.5 }}>
        {state.loading && <Typography variant="body2" color="text.secondary" sx={{ p: 1 }} data-testid={`${testId}-loading`}>Loading the values…</Typography>}
        {!state.loading && state.error && (
          <Typography variant="body2" color="error" sx={{ p: 1 }} data-testid={`${testId}-error`}>The values could not be read: {state.error}</Typography>
        )}
        <List dense disablePadding role={multiple ? 'group' : 'listbox'} aria-label={`${p.label || p.name} values`}>
          {!multiple && !isDate && !p.is_required && !q && (
            <ListItemButton selected={!current} data-testid={`${testId}-option-all`} onClick={() => onDone('')}>
              <ListItemText primary={p.source_column ? 'As in the query' : 'All'} />
            </ListItemButton>
          )}
          {typed && !shown.includes(typed) && (
            <ListItemButton data-testid={`${testId}-use-typed`} onClick={() => onDone(typed)}>
              <ListItemText primary={`Use ${bandDate(typed)}`} secondary="Not in the list of dates that have data" />
            </ListItemButton>
          )}
          {shown.map(v => (multiple ? (
            <ListItemButton key={v} dense data-testid={`${testId}-option-${v}`} role="checkbox" aria-checked={picked.includes(v)}
              onClick={() => setPicked(prev => (prev.includes(v) ? prev.filter(x => x !== v) : [...prev, v]))}>
              <ListItemIcon sx={{ minWidth: 32 }}><Checkbox edge="start" size="small" checked={picked.includes(v)} tabIndex={-1} disableRipple /></ListItemIcon>
              <ListItemText primary={words(v)} />
            </ListItemButton>
          ) : (
            <ListItemButton key={v} selected={v === current} role="option" aria-selected={v === current}
              data-testid={`${testId}-option-${v}`} onClick={() => onDone(v)}>
              <ListItemText primary={words(v)} />
            </ListItemButton>
          )))}
          {!state.loading && !state.error && !shown.length && (
            <Typography variant="body2" color="text.secondary" sx={{ p: 1 }} data-testid={`${testId}-none`}>
              {q ? 'Nothing matches.' : state.note}
            </Typography>
          )}
        </List>
      </Box>
      {isDate && (
        <Box sx={{ mt: 0.5 }}>
          {!calendar ? (
            <Link component="button" variant="body2" data-testid={`${testId}-calendar-link`} onClick={() => setCalendar(true)}>Pick from calendar</Link>
          ) : (
            <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
              <TextField size="small" type="date" value={calDate} onChange={e => setCalDate(e.target.value)}
                InputLabelProps={{ shrink: true }} label="Date"
                inputProps={{ 'data-testid': `${testId}-calendar`, 'aria-label': `Pick ${p.label || p.name} from a calendar` }} />
              <Button size="small" variant="contained" disabled={!ISO_DAY.test(calDate)} data-testid={`${testId}-calendar-use`}
                onClick={() => onDone(calDate)}>Use</Button>
            </Box>
          )}
        </Box>
      )}
      {multiple && (
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 1 }}>
          <Button variant="contained" size="small" data-testid={`${testId}-apply`} onClick={() => onDone(picked)}>Apply</Button>
        </Box>
      )}
    </Box>
  );
}

/** Any other kind: the report's own small input over a draft, then Apply. */
function DraftPicker({ p, ctrl, testId, onDone }: {
  p: any; ctrl: BandControls; testId: string; onDone: (next: Record<string, any>) => void;
}) {
  const [draft, setDraft] = useState<Record<string, any>>(ctrl.values);
  return (
    <Box sx={{ p: 1.5, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
      <ReportParamControl param={{ ...p, visible: true, show_when: null }} params={ctrl.params} values={draft}
        onValues={(u) => setDraft(prev => u(prev))} fetchValues={ctrl.fetchValues} />
      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Button variant="contained" size="small" data-testid={`${testId}-apply`} onClick={() => onDone(draft)}>Apply</Button>
      </Box>
    </Box>
  );
}

function PeriodPicker({ p, ctrl, testId, onDone }: { p: any; ctrl: BandControls; testId: string; onDone: (v: string) => void }) {
  const allowed: string[] | null = Array.isArray(p.static_values) && p.static_values.length
    ? p.static_values.map((x: any) => String(typeof x === 'object' ? x.value ?? x.key : x).toLowerCase()) : null;
  const opts = allowed ? PERIOD_OPTIONS.filter(o => allowed.includes(o.value)) : PERIOD_OPTIONS;
  const cur = String(ctrl.values[p.name] || '').toLowerCase();
  return (
    <List dense role="listbox" aria-label={`${p.label || p.name} choices`}>
      {opts.map(o => (
        <ListItemButton key={o.value} selected={o.value === cur} role="option" aria-selected={o.value === cur}
          data-testid={`${testId}-option-${o.value}`} onClick={() => onDone(o.value)}>
          <ListItemText primary={o.label} secondary={o.help} />
        </ListItemButton>
      ))}
    </List>
  );
}

// ── the cells of one band ─────────────────────────────────────────────────

/** A parameter drawn as CHIPS (2026-11-02): its choices in a row, the chosen one filled; a dropdown with
 *  more than MAX_CHIP_CHOICES choices keeps its cell (`fallback`), said in the builder's words. */
function ChipCell({ p, ctrl, theme, testId, fallback }: { p: any; ctrl: BandControls; theme: ReportTheme; testId: string; fallback: () => React.ReactNode }) {
  const isPeriod = p.parameter_type === 'period';
  const [state, setState] = useState<{ loading: boolean; values: string[]; labels: Record<string, string>; tooMany: boolean }>(
    { loading: !isPeriod, values: [], labels: {}, tooMany: false });
  useEffect(() => {
    if (isPeriod) return;
    let live = true;
    const parent = p.depends_on_param_id ? ctrl.params.find((x: any) => x.id === p.depends_on_param_id) : null;
    Promise.resolve(ctrl.fetchValues({ parameter_id: p.id, parent_values: parent ? { [parent.name]: ctrl.values[parent.name] } : {} }))
      .then(res => { if (!live) return; const l = readValueList(res); setState({ loading: false, values: l.values, labels: l.labels ?? {}, tooMany: l.truncated || l.values.length > MAX_CHIP_CHOICES }); })
      .catch(() => { if (live) setState({ loading: false, values: [], labels: {}, tooMany: true }); });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.id, p.depends_on_param_id ? JSON.stringify(ctrl.values[ctrl.params.find((x: any) => x.id === p.depends_on_param_id)?.name]) : '']);
  if (state.loading) return <>{fallback()}</>;
  const allowed: string[] | null = isPeriod && Array.isArray(p.static_values) && p.static_values.length
    ? p.static_values.map((x: any) => String(typeof x === 'object' ? x.value ?? x.key : x).toLowerCase()) : null;
  const choices: { value: string; label: string }[] = isPeriod
    ? (allowed ? PERIOD_OPTIONS.filter(o => allowed.includes(o.value)) : PERIOD_OPTIONS).map(o => ({ value: o.value, label: o.label }))
    : state.values.map(v => ({ value: v, label: state.labels[v] ? `${v} — ${state.labels[v]}` : v }));
  if (state.tooMany || choices.length > MAX_CHIP_CHOICES || choices.length === 0) return <>{fallback()}</>;
  const cur = String(ctrl.values[p.name] ?? '');
  const sep = alpha(theme.band.fg, 0.55);
  return (
    <Box role="group" aria-label={p.label || p.name} data-testid={`${testId}-chips`}
      sx={{ display: 'flex', flexDirection: 'column', px: 1.5, py: 0.5, borderRight: `2px solid ${sep}`, '&:last-of-type': { borderRight: 'none' } }}>
      <Typography component="div" sx={{ fontSize: 11, color: theme.band.label_fg, fontFamily: 'inherit', whiteSpace: 'nowrap' }}>{p.label || p.name}</Typography>
      <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', mt: 0.25 }}>
        {choices.map(c => {
          const on = isPeriod ? c.value === cur.toLowerCase() : c.value === cur;
          return (
            <ButtonBase key={c.value} focusRipple role="radio" aria-checked={on} data-testid={`${testId}-chip-${c.value}`}
              onClick={() => ctrl.onPick(applyParamChange(ctrl.params, ctrl.values, p, c.value))}
              sx={{ px: 1.25, py: 0.25, borderRadius: 999, fontSize: 13, fontFamily: 'inherit', fontWeight: on ? 700 : 500,
                    bgcolor: on ? theme.band.fg : alpha(theme.band.fg, 0.14), color: on ? theme.band.bg : theme.band.fg,
                    '&:hover, &.Mui-focusVisible': { bgcolor: on ? theme.band.fg : alpha(theme.band.fg, 0.28) } }}>
              {c.label}
            </ButtonBase>
          );
        })}
      </Box>
    </Box>
  );
}

export function ParamBandCells({ ctrl, theme, names, withExtras = true, onError, chips }: {
  ctrl: BandControls; theme: ReportTheme; names?: string[] | null; withExtras?: boolean;
  onError?: (words: string | null) => void;
  /** the parameters drawn as chips (a band tile's `chips`, 2026-11-02) */
  chips?: string[] | null;
}) {
  const [busy, setBusy] = useState<string | null>(null);
  const shown = bandParams(ctrl.params, ctrl.values, names);
  const pick = (p: any, value: any) => ctrl.onPick(applyParamChange(ctrl.params, ctrl.values, p, value));
  // a business date that OWNS a list (the dates that have data): ◀ ▶ step through that list,
  // so they never land on a day without data; read once per parameter (and its parent's value)
  const ownsList = (p: any) => p.parameter_type === 'date' && (!!p.lov_column_id || !!p.source_column || !!p.value_list_id);
  const listKey = shown.filter(ownsList).map((p: any) => {
    const parent = p.depends_on_param_id ? ctrl.params.find((x: any) => x.id === p.depends_on_param_id) : null;
    return `${p.id}:${parent ? JSON.stringify(ctrl.values[parent.name] ?? null) : ''}`;
  }).join('|');
  const [dateLists, setDateLists] = useState<Record<string, { dates: string[]; truncated: boolean } | 'none'>>({});
  useEffect(() => {
    let live = true;
    for (const p of shown.filter(ownsList)) {
      const parent = p.depends_on_param_id ? ctrl.params.find((x: any) => x.id === p.depends_on_param_id) : null;
      const parentValues = parent ? { [parent.name]: ctrl.values[parent.name] } : {};
      Promise.resolve(ctrl.fetchValues({ parameter_id: p.id, parent_values: parentValues }))
        .then((res) => {
          if (!live) return;
          const l = readValueList(res);
          const dates = l.values.filter(v => ISO_DAY.test(v));
          setDateLists(prev => ({ ...prev, [p.name]: dates.length ? { dates, truncated: l.truncated } : 'none' }));
        })
        .catch(() => { if (live) setDateLists(prev => ({ ...prev, [p.name]: 'none' })); });
    }
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [listKey]);
  return (
    <>
      {shown.map((p) => {
        const testId = `band-cell-${p.name}`;
        const label = p.label || p.name;
        const v = ctrl.values[p.name];
        const t = p.parameter_type;
        // a business date bound to a column ALWAYS opens on the dates that have data (the owner:
        // "never a free-text box as the first thing"); "Pick from calendar" reaches any other day
        const listed = ['dropdown', 'multi_select'].includes(t) || ownsList(p);
        const iso = typeof v === 'string' && ISO_DAY.test(v.slice(0, 10)) ? v.slice(0, 10) : null;
        const list = dateLists[p.name];
        let prev: { onClick: () => void; title: string; disabled?: boolean } | null = null;
        let next: typeof prev = null;
        if (t === 'date' && iso && list && list !== 'none') {
          // THE LIST: previous / next date that has data
          const back = stepInList(list.dates, iso, -1, list.truncated);
          const fwd = stepInList(list.dates, iso, 1, list.truncated);
          prev = { onClick: () => { if (back.date) pick(p, back.date); }, disabled: !back.date,
                   title: back.date ? `Previous date with data: ${bandDate(back.date)}` : back.why };
          next = { onClick: () => { if (fwd.date) pick(p, fwd.date); }, disabled: !fwd.date,
                   title: fwd.date ? `Next date with data: ${bandDate(fwd.date)}` : fwd.why };
        } else if (t === 'date' && iso && ctrl.businessDay && (!ownsList(p) || list === 'none')) {
          // no list: the business calendar (the server's rule)
          const step = (dir: 1 | -1) => async () => {
            setBusy(p.name); onError?.(null);
            try {
              const a = await ctrl.businessDay!(iso, dir, p.name);
              if (a?.date) pick(p, a.date);
            } catch (e: any) {
              onError?.(e?.message || String(e));
            } finally { setBusy(null); }
          };
          prev = { onClick: step(-1), title: `Previous business day for ${label}` };
          next = { onClick: step(1), title: `Next business day for ${label}` };
        }
        const cell = () => (
          <BandCell key={p.name} label={label} value={bandCellWords(p, v)} testId={testId} theme={theme}
            busy={busy === p.name} prev={prev} next={next}
            popoverWidth={t === 'cob_compare' || t === 'hierarchy' || t === 'date_range' || t === 'number_range' ? 520 : undefined}>
            {(close) => {
              if (t === 'period') return <PeriodPicker p={p} ctrl={ctrl} testId={testId} onDone={(x) => { close(); pick(p, x); }} />;
              if (listed) {
                return <ListPicker p={p} ctrl={ctrl} testId={testId} multiple={t === 'multi_select'} isDate={t === 'date'}
                  onDone={(x) => { close(); pick(p, x); }} />;
              }
              return <DraftPicker p={p} ctrl={ctrl} testId={testId} onDone={(nv) => { close(); ctrl.onPick(nv); }} />;
            }}
          </BandCell>
        );
        // chips (2026-11-02): a period or a dropdown named in the band tile's `chips` draws its choices in a row
        if (chips?.includes(p.name) && (t === 'period' || t === 'dropdown')) {
          return <ChipCell key={p.name} p={p} ctrl={ctrl} theme={theme} testId={testId} fallback={cell} />;
        }
        return cell();
      })}
      {withExtras ? ctrl.extras : null}
    </>
  );
}

/** A band of its own (the viewer's top band): the cells on the theme's band colours. */
export function ReportBand({ ctrl, theme, names, withExtras = true, testId = 'report-band', code }: {
  ctrl: BandControls; theme: ReportTheme; names?: string[] | null; withExtras?: boolean; testId?: string;
  /** the report code, drawn ONCE at the band's right (the theme says where; hidden = not drawn) */
  code?: string | null;
}) {
  const [err, setErr] = useState<string | null>(null);
  const cells = bandParams(ctrl.params, ctrl.values, names);
  if (!cells.length && !(withExtras && ctrl.extras)) return null;
  return (
    <Box sx={{ mb: 1.5 }}>
      <Box data-testid={testId} role="toolbar" aria-label="Report parameters"
        sx={{ display: 'inline-flex', maxWidth: '100%', flexWrap: 'wrap', bgcolor: theme.band.bg, color: theme.band.fg,
              fontFamily: theme.band.font, borderRadius: 0.5 }}>
        <ParamBandCells ctrl={ctrl} theme={theme} names={names} withExtras={withExtras} onError={setErr} />
      </Box>
      {code && theme.title.code_position !== 'hidden' && (
        <Typography component="span" data-testid="report-code" sx={{ color: theme.title.color, ml: 1.5, whiteSpace: 'nowrap', verticalAlign: 'middle' }}>
          [{code}]
        </Typography>
      )}
      {err && <Typography variant="caption" color="error" component="div" data-testid="band-error">{err}</Typography>}
    </Box>
  );
}

export default ReportBand;
