/**
 * ReportReadinessSloDialog (2026-09-28) -- an editor declares what "final"
 * means for a report, and what it promises.
 *
 * Readiness: which parameter carries the business date, and the
 * dependencies the data waits on -- in the SAME vocabulary a feed uses
 * (the dependency catalogue, a key, the upstream calendar, the declared
 * arrival sources: kafka / etl / file / an Iceberg table's commit).  Saved
 * through PUT /api/business-reports/{id}/readiness/dependencies, which
 * refuses a bad type, calendar or parameter BY NAME (shown here).
 *
 * SLO: "fresh and served by HH:MM <zone>" on the business days of a
 * calendar.  Saved through PUT .../slo, which refuses a promise on a report
 * with no readiness dependencies -- 'fresh' cannot be measured otherwise --
 * and a time or zone it cannot resolve.  Every refusal is shown verbatim.
 *
 * The dialog writes nothing on open; Save writes the declaration, then the
 * promise (only when the promise form is on).  Remove clears the promise.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, CircularProgress, Divider, FormControlLabel, IconButton, ListItemText,
  MenuItem, Stack, Switch, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import { Add as AddIcon, DeleteOutline as RemoveIcon } from '@mui/icons-material';
import api from '../../services/api';
import type {
  ReportDependencyItem, ReportReadinessDependencies, ReportSloPayload,
} from '../../services/api/reportReadiness';
import type { ArrivalSourcesVocabulary, DeclaredArrivalSource } from '../../services/api/feedDependencies';
import { toArray } from '../../utils/toArray';
import { sloStatusLabel } from '../../utils/reportReadiness';

interface Props {
  open: boolean;
  reportId: number;
  reportName?: string;
  onClose: () => void;
  /** called after a successful save, with the SLO payload (null when none) */
  onSaved?: (slo: ReportSloPayload | null) => void;
}

type Row = {
  dependency_type_id: number | '';
  dependency_key: string;
  description: string;
  calendar_name: string;
  kinds: string[];
  iceberg: { connection_id: number | ''; table: string; date_column: string };
  require_mode: 'all' | 'any';
  is_active: boolean;
};

const COMMON_ZONES = ['Europe/London', 'UTC', 'America/New_York', 'Asia/Singapore', 'Asia/Hong_Kong',
  'Asia/Tokyo', 'Europe/Frankfurt', 'Europe/Paris', 'Australia/Sydney'];

function rowFromItem(it: ReportDependencyItem): Row {
  const sources = Array.isArray(it.arrival_sources) ? it.arrival_sources : [];
  const ice = sources.find(s => s.kind === 'iceberg_commit');
  return {
    dependency_type_id: it.dependency_type_id ?? '',
    dependency_key: it.dependency_key || '',
    description: it.description || '',
    calendar_name: it.calendar_name || '',
    kinds: sources.map(s => s.kind),
    iceberg: { connection_id: ice?.connection_id ?? '', table: ice?.table || '', date_column: ice?.date_column || '' },
    require_mode: (it.require_mode === 'any' ? 'any' : 'all'),
    is_active: it.is_active !== false,
  };
}

function itemFromRow(r: Row): ReportDependencyItem {
  const sources: DeclaredArrivalSource[] = r.kinds.map(kind => (
    kind === 'iceberg_commit'
      ? { kind, connection_id: r.iceberg.connection_id === '' ? undefined : Number(r.iceberg.connection_id),
          table: r.iceberg.table, date_column: r.iceberg.date_column }
      : { kind }));
  return {
    dependency_type_id: Number(r.dependency_type_id),
    dependency_key: r.dependency_key.trim(),
    description: r.description.trim() || null,
    calendar_name: r.calendar_name || null,
    arrival_sources: sources.length ? sources : null,
    require_mode: sources.length ? r.require_mode : null,
    is_active: r.is_active,
  };
}

const emptyRow = (typeId: number | ''): Row => ({
  dependency_type_id: typeId, dependency_key: '', description: '', calendar_name: '',
  kinds: [], iceberg: { connection_id: '', table: '', date_column: '' }, require_mode: 'all', is_active: true,
});

export default function ReportReadinessSloDialog({ open, reportId, reportName, onClose, onSaved }: Props) {
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [decl, setDecl] = useState<ReportReadinessDependencies | null>(null);
  const [rows, setRows] = useState<Row[]>([]);
  const [dateParam, setDateParam] = useState<string>('');
  const [calendars, setCalendars] = useState<string[]>([]);
  const [vocab, setVocab] = useState<ArrivalSourcesVocabulary | null>(null);
  const [connections, setConnections] = useState<{ id: number; name: string }[]>([]);
  const [sloOn, setSloOn] = useState(false);
  const [hadSlo, setHadSlo] = useState(false);
  const [serveBy, setServeBy] = useState('07:00');
  const [zone, setZone] = useState('Europe/London');
  const [sloCalendar, setSloCalendar] = useState('');
  const [sloActive, setSloActive] = useState(true);
  const [sloPayload, setSloPayload] = useState<ReportSloPayload | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setLoadError(null); setSaveError(null); setSaved(null);
    try {
      const [d, s] = await Promise.all([
        api.getReportReadinessDependencies(reportId),
        api.getReportSlo(reportId),
      ]);
      setDecl(d);
      setRows((d.items || []).map(rowFromItem));
      setDateParam(d.business_date_param || '');
      setSloPayload(s);
      const slo = s?.slo || null;
      setHadSlo(!!slo); setSloOn(!!slo);
      if (slo) {
        setServeBy(slo.serve_by); setZone(slo.timezone);
        setSloCalendar(slo.calendar_name || ''); setSloActive(slo.is_active !== false);
      }
    } catch (e: any) {
      setLoadError(e?.message || 'the declaration could not be read');
    } finally {
      setLoading(false);
    }
    // the lists behind the pickers: each failure leaves that picker empty and says so in place
    api.listFeedCalendarsReadonly()
      .then((r: any) => setCalendars(toArray(r).map((c: any) => String(c.name)).filter(Boolean)))
      .catch(() => setCalendars([]));
    api.getFeedArrivalSources().then((v: ArrivalSourcesVocabulary) => setVocab(v)).catch(() => setVocab(null));
    api.listConnections()
      .then((r: any) => setConnections(toArray(r).map((c: any) => ({ id: Number(c.id), name: String(c.name || c.id) }))))
      .catch(() => setConnections([]));
  }, [reportId]);

  useEffect(() => { if (open) void load(); }, [open, load]);

  const update = (i: number, patch: Partial<Row>) =>
    setRows(prev => prev.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  const save = async () => {
    setSaving(true); setSaveError(null); setSaved(null);
    try {
      const d = await api.putReportReadinessDependencies(reportId, {
        business_date_param: dateParam || null,
        dependencies: rows.map(itemFromRow),
      });
      setDecl(d); setRows((d.items || []).map(rowFromItem));
      let sloOut: ReportSloPayload | null = sloPayload;
      if (sloOn) {
        sloOut = await api.putReportSlo(reportId, {
          serve_by: serveBy.trim(), timezone: zone.trim(),
          calendar_name: sloCalendar || null, is_active: sloActive,
        });
        setSloPayload(sloOut); setHadSlo(true);
      } else if (hadSlo) {
        await api.deleteReportSlo(reportId);
        sloOut = { report_id: reportId, slo: null, status: null, breaches: [], business_date: null };
        setSloPayload(sloOut); setHadSlo(false);
      }
      setSaved(`Saved: ${d.items.length} dependenc${d.items.length === 1 ? 'y' : 'ies'}`
        + (sloOn ? `, promise ${serveBy} ${zone}` : hadSlo && !sloOn ? ', promise removed' : ''));
      onSaved?.(sloOut);
    } catch (e: any) {
      setSaveError(e?.message || 'save failed');
    } finally {
      setSaving(false);
    }
  };

  const types = decl?.available_types || [];
  // 2026-10-07 -- `file` is not offered here: its producer (the file
  // watcher, core/feed/file_arrival_source.py) lists for WAITING FEED RUNS,
  // and a report has none, so a report-only file source could never be met.
  // (It needs a connection and a path too, which this dialog does not ask.)
  const kinds = (vocab?.kinds || []).filter(k => k.kind !== 'file');
  const firstType = types[0]?.id ?? '';

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="md"
      aria-labelledby="readiness-slo-title"
      titleId="readiness-slo-title"
      title={<>Readiness &amp; SLO{reportName ? ` — ${reportName}` : ''}</>}
      actions={<>
        <Button onClick={onClose}>Close</Button>
        <Button variant="contained" onClick={save} disabled={saving || loading || !!loadError}>
          {saving ? 'Saving…' : 'Save'}
        </Button>
      </>}>
        {loading && <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}><CircularProgress /></Box>}
        {loadError && <Alert severity="error" data-testid="readiness-load-error">{loadError}</Alert>}
        {!loading && !loadError && decl && (
          <Stack gap={2}>
            <Typography variant="body2" color="text.secondary">
              The report is <b>complete</b> for a business date when every dependency below is met — the
              same gate the feeds wait on. A dependency that cannot be read is <b>could not tell</b>, never
              complete. Declare nothing and nothing is claimed.
            </Typography>

            <TextField select size="small" label="Business date parameter" value={dateParam}
              onChange={e => setDateParam(e.target.value)} sx={{ maxWidth: 360 }}
              helperText={decl.date_parameters.length
                ? 'blank = the first date parameter; a report with none uses today'
                : 'this report has no date parameter: today is used'}>
              <MenuItem value="">(first date parameter)</MenuItem>
              {decl.parameters.map(p => (
                <MenuItem key={p.name} value={p.name}>
                  {p.label || p.name} ({p.name}{p.parameter_type ? `, ${p.parameter_type}` : ''})
                </MenuItem>
              ))}
            </TextField>

            <Divider><Typography variant="overline">Dependencies</Typography></Divider>
            {rows.length === 0 && (
              <Typography variant="body2" color="text.secondary" data-testid="readiness-no-rows">
                No dependencies declared.
              </Typography>
            )}
            {rows.map((r, i) => (
              <Box key={i} data-testid={`readiness-row-${i}`}
                sx={{ p: 1.5, border: 1, borderColor: 'divider', borderRadius: 1 }}>
                <Stack direction={{ xs: 'column', md: 'row' }} gap={1} alignItems="flex-start">
                  <TextField select size="small" label="Type" value={r.dependency_type_id}
                    onChange={e => update(i, { dependency_type_id: Number(e.target.value) })} sx={{ minWidth: 160 }}>
                    {types.map(t => <MenuItem key={t.id} value={t.id}>{t.dependency_type}</MenuItem>)}
                  </TextField>
                  <TextField size="small" label="Dependency key" value={r.dependency_key} required
                    onChange={e => update(i, { dependency_key: e.target.value })} sx={{ minWidth: 220 }}
                    inputProps={{ 'aria-label': `Dependency key ${i + 1}` }} />
                  <TextField select size="small" label="Upstream calendar" value={r.calendar_name}
                    onChange={e => update(i, { calendar_name: e.target.value })} sx={{ minWidth: 170 }}
                    helperText="not expected on its holidays">
                    <MenuItem value="">(expected every day)</MenuItem>
                    {calendars.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                  </TextField>
                  <TextField select size="small" label="Evidence sources" value={r.kinds}
                    SelectProps={{ multiple: true,
                      renderValue: (v: any) => (v as string[]).length ? (v as string[]).join(', ') : 'any evidence' }}
                    onChange={e => update(i, { kinds: (e.target.value as unknown) as string[] })}
                    sx={{ minWidth: 200 }} helperText="blank = any evidence by name">
                    {kinds.map(k => (
                      <MenuItem key={k.kind} value={k.kind}>
                        <Checkbox size="small" checked={r.kinds.includes(k.kind)} tabIndex={-1} aria-hidden />
                        <ListItemText primary={k.label} />
                      </MenuItem>
                    ))}
                  </TextField>
                  {r.kinds.length > 1 && (
                    <TextField select size="small" label="Require" value={r.require_mode}
                      onChange={e => update(i, { require_mode: e.target.value as 'all' | 'any' })} sx={{ minWidth: 100 }}>
                      <MenuItem value="all">all</MenuItem>
                      <MenuItem value="any">any</MenuItem>
                    </TextField>
                  )}
                  <Tooltip title={`Remove dependency ${r.dependency_key || i + 1}`}>
                    <IconButton size="small" aria-label={`Remove dependency ${r.dependency_key || i + 1}`}
                      onClick={() => setRows(prev => prev.filter((_, j) => j !== i))}>
                      <RemoveIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </Stack>
                {r.kinds.includes('iceberg_commit') && (
                  <Stack direction={{ xs: 'column', md: 'row' }} gap={1} sx={{ mt: 1 }}>
                    <TextField select size="small" label="Iceberg connection" value={r.iceberg.connection_id}
                      onChange={e => update(i, { iceberg: { ...r.iceberg, connection_id: Number(e.target.value) } })}
                      sx={{ minWidth: 200 }}>
                      {connections.map(c => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
                    </TextField>
                    <TextField size="small" label="Registered table" value={r.iceberg.table}
                      onChange={e => update(i, { iceberg: { ...r.iceberg, table: e.target.value } })} />
                    <TextField size="small" label="Date column" value={r.iceberg.date_column}
                      onChange={e => update(i, { iceberg: { ...r.iceberg, date_column: e.target.value } })} />
                  </Stack>
                )}
                <TextField size="small" label="Description" value={r.description} fullWidth sx={{ mt: 1 }}
                  onChange={e => update(i, { description: e.target.value })} />
              </Box>
            ))}
            <Box>
              <Button size="small" startIcon={<AddIcon />} onClick={() => setRows(prev => [...prev, emptyRow(firstType)])}
                disabled={types.length === 0} aria-label="Add dependency">
                Add dependency
              </Button>
              {types.length === 0 && (
                <Typography variant="caption" color="error" sx={{ ml: 1 }}>
                  the dependency catalogue is empty — an admin seeds it under Feeds
                </Typography>
              )}
            </Box>

            <Divider><Typography variant="overline">Promise (SLO)</Typography></Divider>
            <FormControlLabel
              control={<Switch checked={sloOn} onChange={e => setSloOn(e.target.checked)} />}
              label="This report promises to be fresh and served by a time" />
            {sloOn && (
              <Stack direction={{ xs: 'column', md: 'row' }} gap={1} alignItems="flex-start">
                <TextField size="small" label="Served by (local time)" value={serveBy} required
                  onChange={e => setServeBy(e.target.value)} placeholder="07:00" sx={{ minWidth: 160 }}
                  helperText="HH:MM" />
                <TextField select size="small" label="Timezone" value={COMMON_ZONES.includes(zone) ? zone : '__custom'}
                  onChange={e => { if (e.target.value !== '__custom') setZone(e.target.value); }} sx={{ minWidth: 200 }}>
                  {COMMON_ZONES.map(z => <MenuItem key={z} value={z}>{z}</MenuItem>)}
                  <MenuItem value="__custom">other (type below)</MenuItem>
                </TextField>
                <TextField size="small" label="IANA zone" value={zone} onChange={e => setZone(e.target.value)}
                  sx={{ minWidth: 200 }} helperText="e.g. Europe/London; UTC is never assumed" />
                <TextField select size="small" label="Business calendar" value={sloCalendar}
                  onChange={e => setSloCalendar(e.target.value)} sx={{ minWidth: 170 }}
                  helperText="no promise on its holidays">
                  <MenuItem value="">(every day)</MenuItem>
                  {calendars.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
                </TextField>
                <FormControlLabel
                  control={<Switch checked={sloActive} onChange={e => setSloActive(e.target.checked)} />}
                  label="active" />
              </Stack>
            )}
            {sloPayload?.status && sloPayload.slo && (
              <Stack direction="row" gap={1} alignItems="center" flexWrap="wrap">
                <Typography variant="caption" color="text.secondary">Today:</Typography>
                <Chip size="small" variant="outlined" label={sloStatusLabel(sloPayload.status)}
                  data-testid="readiness-slo-today" />
              </Stack>
            )}
            {sloPayload?.breaches && sloPayload.breaches.length > 0 && (
              <Box data-testid="readiness-slo-breaches">
                <Typography variant="caption" color="text.secondary">Recent misses:</Typography>
                {sloPayload.breaches.slice(0, 8).map(b => (
                  <Typography key={b.id} variant="body2">
                    {b.business_date} — {b.cause.replace(/_/g, ' ')}{b.state === 'served_late' ? ' (served late)' : ' (open)'}
                  </Typography>
                ))}
              </Box>
            )}
            {saveError && <Alert severity="error" data-testid="readiness-save-error">{saveError}</Alert>}
            {saved && <Alert severity="success" data-testid="readiness-saved">{saved}</Alert>}
          </Stack>
        )}
    </AppDialog>
  );
}
