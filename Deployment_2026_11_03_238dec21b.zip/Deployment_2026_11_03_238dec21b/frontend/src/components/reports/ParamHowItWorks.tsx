/**
 * "How this works" -- one plain card per parameter in the report editor
 * (2026-11-01, the owner: "how generic parameters work is still a black box
 * for me").
 *
 * Five questions, each answered from what the SERVER stores and does (the rules
 * are backend core/reports/param_contract.py `targets_of` / `run_value`,
 * core/reports/param_lists.py `describe`, core/source_filters.py):
 *
 *   Where its choices come from   its own list in QueryStudio's database (how many,
 *                                 the query, when refreshed -- Refresh now / Edit
 *                                 this query), the recorded partitions, a named
 *                                 value list, another table, a typed list, any day
 *   What it filters               which column / which condition of the dataset's
 *                                 query / which {TOKEN} -- and WHERE: "at the
 *                                 source" (inside the dataset's own query) or "on
 *                                 the dataset's results"
 *   Its default                   the value, or the rule (latest with data, ...)
 *   Who sees it                   a cell of the band, or hidden (always its default),
 *                                 or shown only when another has a value
 *   What it depends on            the cascade parent and the column it narrows
 */
import React, { useState } from 'react';
import { Box, Button, Link, Typography } from '@mui/material';
import { HelpOutline as HowIcon } from '@mui/icons-material';
import { safeFetch } from '../../services/api/core';
import type { ParamRow } from './reportAuthoringModel';
import type { SourceFilter } from '../../utils/reportFilters';
import { PERIOD_OPTIONS } from './ReportParamControl';

const LIST_TYPES = ['dropdown', 'multi_select'];

/** The parameter's targets -- backend param_contract.targets_of, the same rule. */
export function targetsOf(p: Pick<ParamRow, 'applies' | 'lov_column_id' | 'source_column'>): any[] {
  const out = Array.isArray(p.applies) ? p.applies.filter(t => t && typeof t === 'object') : [];
  if (out.length) return out;
  if (p.source_column) return [{ to: 'source', source_column: p.source_column }];
  if (p.lov_column_id) return [{ to: 'result', column_id: p.lov_column_id }];
  return [];
}

const when = (iso: any) => (iso ? String(iso).slice(0, 16).replace('T', ' ') : '');

/** "Where its choices come from", in words. */
export function choicesWords(p: ParamRow, colName: (id: number | null) => string, rows: ParamRow[]): string {
  const t = p.parameter_type;
  if (t === 'period') {
    const anchor = rows.find(r => r._key === p.depends_on_key);
    return `A fixed set of choices: ${PERIOD_OPTIONS.map(o => o.label).join(', ')}`
      + (anchor ? `, counted back from ${anchor.label || anchor.name}.` : ', counted back from today.');
  }
  if (t === 'cob_compare') return 'Two dates of the person\'s own, or a quick pick (this month-end vs the previous one, ...).';
  if (t === 'boolean') return 'Yes or No.';
  if (t === 'number_range') return 'A From and a To number, typed by the person.';
  if (p.values_source === 'any' && (t === 'date' || t === 'date_range')) return 'Any day on a calendar.';
  if (p.values_source === 'static' || (p.static_values?.length && (p.values_source || 'auto') === 'auto')) {
    return `${p.static_values?.length || 0} values typed into this report.`;
  }
  if (p.values_source === 'list') return p.value_list_id ? `A named value list (number ${p.value_list_id}) kept in QueryStudio's database.` : 'A named value list -- none picked yet.';
  if (p.values_source === 'table') {
    return p.lov_source_table ? `The values of ${p.lov_source_column || 'a column'} in ${p.lov_source_table}, read from that table.` : 'Another table -- none picked yet.';
  }
  const cl = p.choices_list;
  if (cl?.has_list) {
    const n = Number(cl.value_count || 0).toLocaleString();
    if (cl.source_type === 'partition') {
      return `${n} values, kept in QueryStudio's database, from the table's recorded partitions (no data is read)`
        + (cl.last_synced_at ? ` -- refreshed ${when(cl.last_synced_at)}.` : '.');
    }
    if (cl.last_status === 'failed') return `${n} values, kept in QueryStudio's database. The last refresh failed (${cl.last_error || 'no reason given'}); the earlier values are still offered.`;
    if (cl.last_status !== 'ok') return `Its own list in QueryStudio's database is being filled for the first time${cl.source_sql ? `, from: ${cl.source_sql}` : ''}.`;
    return `${n} values, kept in QueryStudio's database, from: ${cl.source_sql || 'the column\'s source table'}`
      + (cl.last_synced_at ? ` -- refreshed ${when(cl.last_synced_at)}.` : '.')
      + (cl.live_reason ? ` For people under a row policy it is read live and filtered for them (${cl.live_reason}).` : '');
  }
  if (cl && !cl.has_list && cl.words) return String(cl.words);
  if (p.source_column) return `The values of ${p.source_column} in its source table.`;
  if (p.lov_column_id) {
    return LIST_TYPES.includes(t) || t === 'date' || t === 'date_range'
      ? `The values of ${colName(p.lov_column_id)}. Its own list is made in QueryStudio's database when the report is saved.`
      : 'Typed by the person running the report.';
  }
  return 'Typed by the person running the report.';
}

/** "What it filters", in words -- one sentence per target. */
export function filtersWords(p: ParamRow, colName: (id: number | null) => string, sourceWords: (key: string) => string | null): string[] {
  const many = p.parameter_type === 'multi_select';
  const range = p.parameter_type === 'date_range' || p.parameter_type === 'number_range';
  const how = range ? 'is between your From and To' : many ? 'is one of your choices' : 'is your choice';
  const out: string[] = [];
  for (const t of targetsOf(p)) {
    if (t.to === 'result') {
      out.push(`Rows where ${colName(t.column_id ?? null)} ${how} -- applied to the dataset's results (around its query).`);
    } else if (t.to === 'source') {
      const now = sourceWords(String(t.source_column || ''));
      out.push(`Rows where ${t.source_column} ${how} -- applied at the source, inside the dataset's own query, so the source sends back fewer rows.`
        + ` Left empty, the query runs as written${now ? ` (${now})` : ''}.`);
    } else if (t.to === 'token') {
      out.push(`Fills {${t.token}} in the query's text.`);
    } else if (t.to === 'api' || t.to === 'popup') {
      out.push(`Is given to the detail action "${t.action_id || ''}" when someone clicks a value.`);
    } else if (t.to === 'compare') {
      out.push('Picks the two dates the comparison tiles set side by side.');
    } else if (t.to === 'period') {
      out.push('Picks the period (the dates the report reads).');
    }
  }
  if (p.parameter_type === 'period' && !out.length) out.push('Picks the dates the report reads, counted back from the business date.');
  if (!out.length) out.push('Nothing yet -- pick the column it filters, or the person\'s value changes nothing.');
  return out;
}

const RULE_WORDS: Record<string, string> = {
  latest_with_data: 'The newest value that has data (from its own list), worked out when the report opens.',
  entitlement: 'The value the person is entitled to, when they hold exactly one.',
  last_picked: 'What this person picked last time.',
};

export function defaultWords(p: ParamRow): string {
  if (p.default_rule && RULE_WORDS[p.default_rule]) return RULE_WORDS[p.default_rule];
  const v = (p.default_value || '').trim();
  if (v) return v.startsWith('@') ? `${v} -- a date worked out on the business calendar each day.` : v;
  if (p.source_column) return 'As written in the query.';
  return p.parameter_type === 'multi_select' || LIST_TYPES.includes(p.parameter_type) ? 'None -- all values.' : 'None.';
}

export function whoWords(p: ParamRow, rows: ParamRow[]): string {
  if (p.visible === false) return `Hidden. It always runs with its default (${defaultWords(p)}); a value sent for it is ignored.`;
  const sw = p.show_when;
  if (sw && sw.param) {
    const o = rows.find(r => r.name === sw.param);
    const label = o ? (o.label || o.name) : sw.param;
    return Array.isArray(sw.equals) && sw.equals.length
      ? `Shown only when ${label} is ${sw.equals.join(' or ')}; otherwise it is not applied.`
      : `Shown only when ${label} has a value; otherwise it is not applied.`;
  }
  return `Shown to everyone who opens the report, as a cell of the report's band${p.is_required ? ' (a value is required)' : ''}.`;
}

export function dependsWords(p: ParamRow, rows: ParamRow[], colName: (id: number | null) => string): string | null {
  if (!p.depends_on_key) return null;
  const parent = rows.find(r => r._key === p.depends_on_key);
  const pl = parent ? (parent.label || parent.name) : 'the parameter above';
  if (p.parameter_type === 'period') return `Counted back from the value of ${pl}.`;
  return p.cascade_filter_column_id
    ? `${pl}: its list narrows to the rows where ${colName(p.cascade_filter_column_id)} is the value picked for ${pl}. Changing ${pl} clears this one.`
    : `${pl} -- but no column is picked for the narrowing, so its list does not narrow yet.`;
}

export default function ParamHowItWorks({ p, idx, rows, columns, sourceFilters, onChoicesList }: {
  p: ParamRow; idx: number; rows: ParamRow[]; columns: any[]; sourceFilters: SourceFilter[];
  onChoicesList?: (info: any) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const colName = (id: number | null) => {
    const c = columns.find((x: any) => x.id === id);
    return c ? (c.friendly_name || c.physical_name) : id != null ? `column ${id}` : 'a column';
  };
  const sourceWords = (key: string) => sourceFilters.find(f => f.key === key)?.words ?? null;
  const depends = dependsWords(p, rows, colName);
  const cl = p.choices_list;
  const refresh = async () => {
    if (!p.id) { setNote('Save the report first -- the list is made when the parameter is saved.'); return; }
    setBusy(true); setNote(null);
    try {
      const r = await safeFetch(`/api/business-reports/parameters/${p.id}/choices/refresh`, { method: 'POST' });
      onChoicesList?.(r);
      setNote(r?.words || 'Refreshed.');
    } catch (e: any) { setNote(e?.message || 'The list could not be refreshed.'); }
    finally { setBusy(false); }
  };
  const row = (key: string, title: string, body: React.ReactNode) => (
    <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '200px 1fr' }, gap: { xs: 0, sm: 1.5 }, py: 0.5 }}
      data-testid={`param-${idx}-how-${key}`}>
      <Typography variant="body2" sx={{ fontWeight: 600 }}>{title}</Typography>
      <Box>{body}</Box>
    </Box>
  );
  return (
    <Box data-testid={`param-${idx}-how`} aria-label={`How ${p.label || p.name || 'this parameter'} works`} role="region"
      sx={{ width: '100%', mt: 1, p: 1.5, borderRadius: 1, bgcolor: 'action.hover' }}>
      <Typography variant="subtitle2" sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 0.5 }}>
        <HowIcon fontSize="small" color="action" /> How this works
      </Typography>
      {row('choices', 'Where its choices come from', (
        <>
          <Typography variant="body2">{choicesWords(p, colName, rows)}</Typography>
          {cl?.has_list && (
            <Box sx={{ display: 'flex', gap: 1.5, alignItems: 'center', mt: 0.25 }}>
              <Button size="small" onClick={refresh} disabled={busy} data-testid={`param-${idx}-how-refresh`}>{busy ? 'Refreshing…' : 'Refresh now'}</Button>
              {cl.source_type !== 'partition' && (
                <Link component="button" variant="body2" data-testid={`param-${idx}-how-edit-query`}
                  onClick={() => document.getElementById(`param-${idx}-choices-list`)?.scrollIntoView({ behavior: 'smooth', block: 'center' })}>
                  Edit this query
                </Link>
              )}
            </Box>
          )}
          {note && <Typography variant="caption" color="text.secondary" component="div" data-testid={`param-${idx}-how-note`}>{note}</Typography>}
        </>
      ))}
      {row('filters', 'What it filters', filtersWords(p, colName, sourceWords).map((w, i) => (
        <Typography key={i} variant="body2">{w}</Typography>
      )))}
      {row('default', 'Its default', <Typography variant="body2">{defaultWords(p)}</Typography>)}
      {row('who', 'Who sees it', <Typography variant="body2">{whoWords(p, rows)}</Typography>)}
      {depends && row('depends', 'What it depends on', <Typography variant="body2">{depends}</Typography>)}
    </Box>
  );
}
