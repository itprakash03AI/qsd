/**
 * The report Diagnostics panel (2026-10-30) -- "why is this number different?"
 * answered on the screen, for the CURRENT run.
 *
 * Reads `GET /api/business-reports/{id}/executions/{exec}/diagnostics`
 * (backend `core/reports/diagnostics.py`): every fact is what the run
 * RECORDED -- per parameter its value and where it was applied (inside the
 * dataset's own query, on the results, or not applied and why), per run the
 * engine that read the data, the SQL sent (owner / editors), time, rows,
 * cache, the files read; the canvas tiles (what each tile drew, from
 * `canvasTileFacts`) and the action runs.  Anything not recorded SAYS so.
 *
 * Shown to the report's owner, editors and admins; to a person who may only
 * view the report when the owner turned "viewers may open" on (the server is
 * the gate -- its refusal is shown in its own words).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress,
  FormControlLabel, Switch, Table, TableBody, TableCell, TableHead, TableRow, Tooltip, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import ManageSearchIcon from '@mui/icons-material/ManageSearch';
import api from '../../services/api';
import { useTileFacts, TileFacts } from './canvas/canvasTileFacts';
import { allRenderStats, subscribeRenderStats, TileRenderStats } from './canvas/canvasRender/renderStats';

/** "Drawn as a chart (SVG): 1,000 of 200,000 points · 12 ms · 40.1 KB (Arrow)" -- what drawing the tile cost. */
export function drawingWords(s: TileRenderStats | undefined): string {
  if (!s) return 'Not drawn on this screen yet.';
  const how = s.renderer === 'table' ? 'a table'
    : s.renderer === 'canvas' ? 'a chart (one picture, many points)'
    : s.renderer === 'webgl' ? 'a chart drawn by the graphics card (WebGL)' : 'a chart (SVG)';
  const what = s.renderer === 'table' ? 'rows' : 'points';
  const count = s.sourceRows > s.rows
    ? (s.tileId === 'report'
      ? `${s.rows.toLocaleString()} of ${s.sourceRows.toLocaleString()} ${what} (one page)`
      : `${s.rows.toLocaleString()} of ${s.sourceRows.toLocaleString()} ${what} (the rest left out to fit the width)`)
    : `${s.rows.toLocaleString()} ${what}`;
  const parts = [`Drawn as ${how}: ${count}`];
  if (s.renderMs != null) parts.push(`${s.renderMs.toLocaleString()} ms`);
  if (s.bytes != null) {
    const kb = s.bytes < 1024 ? `${s.bytes} bytes` : s.bytes < 1048576 ? `${(s.bytes / 1024).toFixed(1)} KB` : `${(s.bytes / 1048576).toFixed(1)} MB`;
    // a page that stayed JSON when Arrow was asked says why (e.g. "exact decimals: amount")
    const fmt = s.format === 'arrow' ? 'Arrow' : s.format === 'json' ? (s.formatReason ? `JSON, ${s.formatReason}` : 'JSON') : '';
    parts.push(`${kb}${fmt ? ` (${fmt})` : ''}`);
  }
  return parts.join(' · ');
}

/** Every tile's drawing cost on this screen, kept current (canvasRender/renderStats). */
export function useRenderStats(): TileRenderStats[] {
  const [list, setList] = useState<TileRenderStats[]>(() => allRenderStats());
  useEffect(() => subscribeRenderStats(() => setList(allRenderStats())), []);
  return list;
}

const NOT_RECORDED = 'not recorded';

export interface DiagnosticsParameter {
  name: string; label: string; type: string | null;
  value: any; value_words: string; from_default: boolean; default: string | null;
  placement: 'source' | 'result' | 'not_applied_empty' | 'not_applied_unbound' | 'replaced_by_period' | null;
  where_words: string | null; condition: string | null; condition_before: string | null;
  why_not_at_source: string | null;
  effect: { words: string; files_read: number | null; files_total: number | null } | null;
}

export interface RunDiagnostics {
  recorded: boolean;
  reason?: string;
  recorded_at?: string | null;
  sql_shown?: boolean;
  parameters: DiagnosticsParameter[];
  other_filters: { condition: string | null; where_words: string }[];
  run: {
    engine: string | null; engine_label?: string | null; read_by_words: string;
    sql: string | null; sql_words: string; sql_cut_at?: number | null;
    duration_seconds: number | null; rows: number | null;
    cache: { words: string } | null; scan_words: string;
    truncated?: boolean | null; row_limit?: number | null;
  };
  tiles: { id: string; kind: string; title: string | null; linked_setting: boolean | null }[];
  actions?: { available: boolean; runs: any[]; words: string };
  for_viewers?: boolean;
  may_change_access?: boolean;
}

const PLACEMENT_CHIP: Record<string, { label: string; color: 'success' | 'info' | 'default' | 'warning' }> = {
  source: { label: 'At the source', color: 'success' },
  result: { label: 'On the results', color: 'info' },
  not_applied_empty: { label: 'Not applied', color: 'default' },
  not_applied_unbound: { label: 'Filtered nothing', color: 'warning' },
  replaced_by_period: { label: 'As of (the period filters)', color: 'default' },
};

/** "1.2 s", "not recorded" */
export function secondsWords(s: number | null | undefined): string {
  if (s == null || !Number.isFinite(s)) return NOT_RECORDED;
  return s < 10 ? `${s.toFixed(2)} s` : `${Math.round(s)} s`;
}

export function countWords(n: number | null | undefined): string {
  return n == null ? NOT_RECORDED : n.toLocaleString();
}

function filtersWords(f: Record<string, any[]>): string {
  const parts = Object.entries(f).map(([k, v]) => `${k} = ${v.map(x => (x == null ? '(no value)' : String(x))).join(', ')}`);
  return parts.join('; ');
}

/** One canvas tile's line: what it drew, and the filters its request carried. */
export function tileLine(t: { id: string; kind: string; title: string | null; linked_setting: boolean | null },
                         f: TileFacts | undefined): { rows: string; totals: string; linked: string } {
  if (!f) {
    return { rows: NOT_RECORDED, totals: NOT_RECORDED,
             linked: t.linked_setting === false ? 'Not linked' : 'Not drawn yet on this screen' };
  }
  if (f.error) return { rows: '—', totals: '—', linked: `The tile could not be read: ${f.error}` };
  const totals = f.totals
    ? Object.values(f.totals).map(v => v.toLocaleString(undefined, { maximumFractionDigits: 2 })).join(' · ')
    : (f.rows != null && f.rows > f.shown ? `not all rows read (${f.shown} of ${f.rows})` : NOT_RECORDED);
  const fw = filtersWords(f.filters);
  const linked = t.linked_setting === false ? 'Not linked'
    : (fw ? `Filtered by ${fw}` : 'No linked filter applied');
  return { rows: countWords(f.rows), totals, linked };
}

interface Props {
  reportId: number;
  executionId: string | null;
  /** the caller's view of "may this person open it" -- the server decides */
  canOpen: boolean;
  size?: 'small' | 'medium';
  /** 2026-11-01 -- the viewer's More actions menu opens the panel: each new number opens it */
  openKey?: number;
}

export function ReportDiagnosticsContent({ d, tileFacts, renderStats, onAccess, accessBusy }: {
  d: RunDiagnostics; tileFacts: TileFacts[]; renderStats?: TileRenderStats[];
  onAccess?: (v: boolean) => void; accessBusy?: boolean;
}) {
  const byTile = new Map(tileFacts.map(f => [f.tileId, f]));
  const drawnBy = new Map((renderStats || []).map(s => [s.tileId, s]));
  const linkedRows = new Map<string, { values: string; tiles: number }>();
  tileFacts.forEach(f => Object.entries(f.filters || {}).forEach(([k, v]) => {
    const key = `${k}=${JSON.stringify(v)}`;
    const cur = linkedRows.get(key);
    linkedRows.set(key, { values: `${k} = ${v.map(x => String(x)).join(', ')}`, tiles: (cur?.tiles || 0) + 1 });
  }));
  const run = d.run || ({} as RunDiagnostics['run']);
  return (
    <Box data-testid="report-diagnostics" sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {!d.recorded && <Alert severity="info" data-testid="diag-not-recorded">{d.reason}</Alert>}

      <Box>
        <Typography variant="subtitle2" gutterBottom>Parameters</Typography>
        {d.parameters.length === 0 && d.other_filters.length === 0 && linkedRows.size === 0 ? (
          <Typography variant="body2" color="text.secondary" data-testid="diag-no-parameters">
            {d.recorded ? 'This report has no parameters.' : 'How each parameter was applied was not recorded.'}
          </Typography>
        ) : (
          <Table size="small" data-testid="diag-parameters">
            <TableHead>
              <TableRow>
                <TableCell>Parameter</TableCell><TableCell>Value</TableCell>
                <TableCell>Applied where</TableCell><TableCell>Effect</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {d.parameters.map(p => {
                const chip = PLACEMENT_CHIP[p.placement || ''];
                return (
                  <TableRow key={p.name} data-testid={`diag-param-${p.name}`} data-placement={p.placement || ''}>
                    <TableCell>{p.label}</TableCell>
                    <TableCell data-testid={`diag-param-${p.name}-value`}>
                      {p.value_words}
                      {p.from_default && (
                        <Typography variant="caption" color="text.secondary" component="div">
                          the report's default{p.default ? `: ${p.default}` : ''}
                        </Typography>)}
                    </TableCell>
                    <TableCell>
                      {chip && <Chip size="small" color={chip.color} label={chip.label} sx={{ mr: 1, mb: 0.5 }} />}
                      <Typography variant="body2" component="span" data-testid={`diag-param-${p.name}-where`}>
                        {p.where_words || NOT_RECORDED}
                      </Typography>
                      {p.condition && (
                        <Box component="code" data-testid={`diag-param-${p.name}-condition`}
                          sx={{ display: 'block', fontSize: 12, mt: 0.5, whiteSpace: 'pre-wrap' }}>
                          {p.condition}
                        </Box>)}
                      {p.condition_before && p.condition_before !== p.condition && (
                        <Typography variant="caption" color="text.secondary" component="div">
                          The query says: <code>{p.condition_before}</code>
                        </Typography>)}
                      {p.why_not_at_source && (
                        <Typography variant="caption" color="text.secondary" component="div"
                          data-testid={`diag-param-${p.name}-why`}>
                          Why not at the source: {p.why_not_at_source}
                        </Typography>)}
                    </TableCell>
                    <TableCell data-testid={`diag-param-${p.name}-effect`}>
                      <Typography variant="body2">{p.effect?.words || '—'}</Typography>
                    </TableCell>
                  </TableRow>
                );
              })}
              {d.other_filters.map((f, i) => (
                <TableRow key={`other-${i}`} data-testid={`diag-other-${i}`}>
                  <TableCell>Report filter</TableCell><TableCell>—</TableCell>
                  <TableCell>
                    <Chip size="small" color="info" label="On the results" sx={{ mr: 1 }} />
                    <Typography variant="body2" component="span">{f.where_words}</Typography>
                    {f.condition && <Box component="code" sx={{ display: 'block', fontSize: 12, mt: 0.5 }}>{f.condition}</Box>}
                  </TableCell>
                  <TableCell>—</TableCell>
                </TableRow>
              ))}
              {[...linkedRows.values()].map((l, i) => (
                <TableRow key={`linked-${i}`} data-testid={`diag-linked-${i}`}>
                  <TableCell>Linked</TableCell><TableCell>{l.values}</TableCell>
                  <TableCell>
                    <Chip size="small" color="info" label="On the result" sx={{ mr: 1 }} />
                    <Typography variant="body2" component="span">
                      on the stored result, for {l.tiles} tile{l.tiles === 1 ? '' : 's'} (no new query to the source)
                    </Typography>
                  </TableCell>
                  <TableCell>—</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Box>

      <Box data-testid="diag-run">
        <Typography variant="subtitle2" gutterBottom>This run</Typography>
        <Table size="small">
          <TableBody>
            <TableRow><TableCell sx={{ width: 160 }}>Read by</TableCell>
              <TableCell data-testid="diag-run-read-by">{run.read_by_words}</TableCell></TableRow>
            <TableRow><TableCell>Time</TableCell>
              <TableCell data-testid="diag-run-time">{secondsWords(run.duration_seconds)}</TableCell></TableRow>
            <TableRow><TableCell>Rows</TableCell>
              <TableCell data-testid="diag-run-rows">
                {countWords(run.rows)}{run.truncated ? ` (cut at the row limit${run.row_limit ? ` of ${run.row_limit.toLocaleString()}` : ''})` : ''}
              </TableCell></TableRow>
            <TableRow><TableCell>Cache or fresh</TableCell>
              <TableCell data-testid="diag-run-cache">{run.cache?.words || NOT_RECORDED}</TableCell></TableRow>
            <TableRow><TableCell>Files read</TableCell>
              <TableCell data-testid="diag-run-scan">{run.scan_words}</TableCell></TableRow>
            <TableRow><TableCell>SQL sent</TableCell>
              <TableCell>
                <Typography variant="caption" color="text.secondary" component="div">{run.sql_words}</Typography>
                {run.sql && (
                  <Box component="pre" data-testid="diag-run-sql"
                    sx={{ fontSize: 12, maxHeight: 240, overflow: 'auto', bgcolor: 'action.hover', p: 1, m: 0, whiteSpace: 'pre-wrap' }}>
                    {run.sql}
                  </Box>)}
                {run.sql_cut_at && (
                  <Typography variant="caption" color="warning.main">Shown up to {run.sql_cut_at.toLocaleString()} characters.</Typography>)}
              </TableCell></TableRow>
          </TableBody>
        </Table>
      </Box>

      {d.tiles && d.tiles.length > 0 && (
        <Box>
          <Typography variant="subtitle2" gutterBottom>Tiles</Typography>
          <Table size="small" data-testid="diag-tiles">
            <TableHead><TableRow>
              <TableCell>Tile</TableCell><TableCell>Rows</TableCell><TableCell>Totals</TableCell><TableCell>Linked filters</TableCell><TableCell>Drawing</TableCell>
            </TableRow></TableHead>
            <TableBody>
              {d.tiles.map(t => {
                const line = tileLine(t, byTile.get(t.id));
                return (
                  <TableRow key={t.id} data-testid={`diag-tile-${t.id}`}>
                    <TableCell>{t.title || t.kind}</TableCell>
                    <TableCell>{line.rows}</TableCell>
                    <TableCell>{line.totals}</TableCell>
                    <TableCell>{line.linked}</TableCell>
                    <TableCell data-testid={`diag-tile-drawing-${t.id}`}>{drawingWords(drawnBy.get(t.id))}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </Box>
      )}

      <Box data-testid="diag-actions">
        <Typography variant="subtitle2" gutterBottom>Actions</Typography>
        {!d.actions || !d.actions.runs?.length ? (
          <Typography variant="body2" color="text.secondary">{d.actions?.words || 'No action runs.'}</Typography>
        ) : (
          <Table size="small">
            <TableHead><TableRow>
              <TableCell>What</TableCell><TableCell>Sent</TableCell><TableCell>Answer</TableCell><TableCell>File</TableCell>
            </TableRow></TableHead>
            <TableBody>
              {d.actions.runs.map((a: any, i: number) => (
                <TableRow key={a.id || i} data-testid={`diag-action-${i}`}>
                  <TableCell>{a.label || a.action_id || 'Action'}{a.username ? ` · ${a.username}` : ''}</TableCell>
                  <TableCell><code style={{ fontSize: 12 }}>{a.query_string || NOT_RECORDED}</code></TableCell>
                  <TableCell>{a.message || a.status || NOT_RECORDED}
                    {a.row_count != null ? ` · ${Number(a.row_count).toLocaleString()} rows` : ''}</TableCell>
                  <TableCell>{a.file_name || '—'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Box>

      {d.may_change_access && onAccess && (
        <FormControlLabel data-testid="diag-access"
          control={<Switch size="small" checked={!!d.for_viewers} disabled={accessBusy}
            onChange={e => onAccess(e.target.checked)} inputProps={{ 'aria-label': 'Viewers may open this panel' }} />}
          label="People who can only view this report may open this panel (they never see the SQL)" />
      )}
    </Box>
  );
}

export default function ReportDiagnosticsPanel({ reportId, executionId, canOpen, size = 'small', openKey }: Props) {
  const [open, setOpen] = useState(false);
  useEffect(() => { if (openKey && executionId) setOpen(true); }, [openKey]);  // eslint-disable-line react-hooks/exhaustive-deps
  const [d, setD] = useState<RunDiagnostics | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const tileFacts = useTileFacts(executionId);
  const renderStats = useRenderStats();

  const load = useCallback(() => {
    if (!executionId) return;
    setLoading(true); setError('');
    api.getReportRunDiagnostics(reportId, executionId)
      .then((res: any) => setD(res as RunDiagnostics))
      .catch((e: any) => { setD(null); setError(String(e?.message || 'The diagnostics could not be read.')); })
      .finally(() => setLoading(false));
  }, [reportId, executionId]);

  useEffect(() => { if (open) load(); }, [open, load]);
  useEffect(() => { setD(null); }, [executionId]);

  if (!canOpen) return null;
  const onAccess = async (v: boolean) => {
    setBusy(true);
    try {
      await api.setReportDiagnosticsAccess(reportId, v);
      setD(prev => (prev ? { ...prev, for_viewers: v } : prev));
    } catch (e: any) {
      setError(String(e?.message || 'The setting could not be saved.'));
    } finally { setBusy(false); }
  };
  return (
    <>
      <Tooltip title={executionId ? 'How this run applied each parameter, which engine read the data, and what each tile shows'
        : 'Run the report first'}>
        <span>
          <Button size={size} variant="outlined" startIcon={<ManageSearchIcon />} disabled={!executionId}
            onClick={() => setOpen(true)} data-testid="report-diagnostics-button">
            Diagnostics
          </Button>
        </span>
      </Tooltip>
      <AppDialog open={open}
        onClose={() => setOpen(false)}
        size="lg"
        aria-labelledby="report-diagnostics-title"
        titleId="report-diagnostics-title"
        title="Diagnostics — this run"
        actions={<>
          <Button onClick={load} disabled={loading || !executionId}>Refresh</Button>
          <Button onClick={() => setOpen(false)}>Close</Button>
        </>}>
          {loading && <CircularProgress size={20} />}
          {error && <Alert severity="warning" data-testid="diag-error">{error}</Alert>}
          {d && !loading && (
            <ReportDiagnosticsContent d={d} tileFacts={tileFacts} renderStats={renderStats} onAccess={onAccess} accessBusy={busy} />)}
      </AppDialog>
    </>
  );
}
