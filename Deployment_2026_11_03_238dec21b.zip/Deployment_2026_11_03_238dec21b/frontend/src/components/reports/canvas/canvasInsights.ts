/**
 * Insight tiles on the report canvas (2026-10-30, the owner: "even Power BI
 * report show insights").
 *
 * A tile of kind 'insight' carries `insight` (its `dimensions` / `measures`
 * stay empty -- the canvas version stays 1):
 *
 *   explain_change  why the value moved between A and B, member by member, each
 *                   field's list adding up EXACTLY to the change ("Everything else"
 *                   holds the rest)
 *   top_movers      the biggest rises and falls between A and B
 *   decomposition   the total split by a field, biggest first, opened level by level
 *   anomalies       values along a date outside their usual range (median / spread
 *                   of the previous N; too few points = no flags)
 *   summary         a short written summary of the numbers on screen (fixed wording)
 *
 * A and B: two values of a date / period field of the result, or this run against
 * the previous stored run (same report, same access to rows); the tile says which.
 * Everything is computed by the server over the run's ONE stored, row-secured
 * result (cube operation 'insight', backend core/reports/canvas_insights.py) --
 * never a new query to the source.  `insightProblems` holds the same rules as the
 * server's save check.
 */
import type { Aggregation, CanvasColumn, CanvasTile } from './canvasModel';

export type InsightKind = 'explain_change' | 'top_movers' | 'decomposition' | 'anomalies' | 'summary';
export type CompareBasis = 'column' | 'previous_run' | 'auto';

export interface InsightCompare { basis: CompareBasis; column_id?: number | null; a?: any; b?: any }
export interface InsightConfig {
  kind: InsightKind;
  measure: { column_id: number; aggregation: Aggregation } | null;
  dimensions: number[];
  compare?: InsightCompare | null;
  date_column?: number | null;
  window?: number | null;
  threshold?: number | null;
  top_n?: number | null;
}
/** one opened level of a decomposition (request only, never stored) */
export interface InsightPathStep { column_id: number; value: any }

export const INSIGHT_KINDS: InsightKind[] = ['explain_change', 'top_movers', 'decomposition', 'anomalies', 'summary'];
/** kinds that split a value into parts: the value must be added up */
export const SPLITTING: InsightKind[] = ['explain_change', 'top_movers', 'decomposition', 'summary'];
export const INSIGHT_LABEL: Record<InsightKind, string> = {
  explain_change: 'Why it changed', top_movers: 'Biggest movers', decomposition: 'What it is made of',
  anomalies: 'Unusual values', summary: 'Summary',
};
export const INSIGHT_HELP: Record<InsightKind, string> = {
  explain_change: 'Which members of each field explain the change between A and B. Each list adds up exactly to the change.',
  top_movers: 'The biggest rises and falls between A and B, by the fields you choose together.',
  decomposition: 'The total split by the first field, biggest first; click a row to open the next field.',
  anomalies: 'Values along a date that are outside their usual range, judged against the values before them.',
  summary: 'A short written summary of these numbers: the change, its biggest part, unusual values.',
};
export const BASIS_LABEL: Record<CompareBasis, string> = {
  auto: 'Two dates in the result, else the previous run',
  column: 'Two values of a date or period field',
  previous_run: 'This run against the previous run',
};
export const MAX_FIELDS = 6;
export const MAX_TOP_N = 100;
export const WINDOW_RANGE: [number, number] = [3, 60];
export const THRESHOLD_RANGE: [number, number] = [1, 10];
const AGGS = ['sum', 'avg', 'count', 'min', 'max', 'count_distinct'];
const NUMERIC = /int|decimal|numeric|double|float|real|number|money/i;
const isNumeric = (c?: CanvasColumn | null) =>
  !!c && (NUMERIC.test(String(c.data_type || '')) || c.column_type === 'measure' || c.column_type === 'kpi');
const emitsAggregate = (c?: CanvasColumn | null) =>
  !!c && (c.column_type === 'measure' || c.column_type === 'kpi') && AGGS.includes(String(c.aggregation || '').toLowerCase());

/** A new insight of this kind (the builder starts here). */
export function newInsight(kind: InsightKind, measure: CanvasColumn | null = null): InsightConfig {
  return {
    kind,
    measure: measure ? { column_id: measure.id, aggregation: 'sum' } : null,
    dimensions: [],
    compare: kind === 'explain_change' || kind === 'top_movers' ? { basis: 'auto' } : null,
    date_column: null, window: null, threshold: null, top_n: null,
  };
}

/** Read a stored insight (anything unreadable becomes null: the tile then says what to choose). */
export function readInsight(raw: any): InsightConfig | null {
  if (!raw || typeof raw !== 'object') return null;
  const num = (v: any) => (v === null || v === undefined || v === '' ? null : Number(v));
  return {
    kind: raw.kind,
    measure: raw.measure && typeof raw.measure === 'object'
      ? { column_id: Number(raw.measure.column_id), aggregation: raw.measure.aggregation } : null,
    dimensions: Array.isArray(raw.dimensions) ? raw.dimensions.map(Number) : [],
    compare: raw.compare && typeof raw.compare === 'object'
      ? { basis: raw.compare.basis ?? 'auto', column_id: num(raw.compare.column_id),
          ...(raw.compare.a != null ? { a: raw.compare.a } : {}), ...(raw.compare.b != null ? { b: raw.compare.b } : {}) }
      : null,
    date_column: num(raw.date_column), window: num(raw.window), threshold: num(raw.threshold), top_n: num(raw.top_n),
  };
}

/** Every column an insight tile needs the report's query to return. */
export function insightColumnIds(ins: InsightConfig | null | undefined): number[] {
  if (!ins) return [];
  const ids = [
    ...(ins.measure ? [ins.measure.column_id] : []), ...ins.dimensions,
    ...(ins.compare?.column_id != null ? [ins.compare.column_id] : []),
    ...(ins.date_column != null ? [ins.date_column] : []),
  ];
  return [...new Set(ids.filter(i => Number.isFinite(i)))];
}

export function insightTitle(t: CanvasTile, cols: Map<number, CanvasColumn>): string {
  if (t.title.trim()) return t.title.trim();
  const ins = t.insight;
  const head = ins && INSIGHT_LABEL[ins.kind] ? INSIGHT_LABEL[ins.kind] : 'Insight';
  const m = ins?.measure ? cols.get(ins.measure.column_id)?.label : '';
  return m ? `${head}: ${m}` : head;
}

/**
 * Everything wrong with one insight tile (the canvas prefixes the tile's name).
 * The same rules as backend core/reports/canvas_insights.py::insight_problems.
 */
export function insightProblems(t: CanvasTile, cols: Map<number, CanvasColumn>,
                                grouped: boolean, selected: Set<number> | null): string[] {
  const out: string[] = [];
  const ins = t.insight;
  if (!ins) return ['choose what the insight shows.'];
  if (!INSIGHT_KINDS.includes(ins.kind)) return [`"${ins.kind}" is not a kind of insight.`];
  const field = (id: number | null | undefined, role: string): CanvasColumn | null => {
    if (id == null || !cols.has(id)) {
      out.push(`its ${role} is a field that is no longer in the data (${id != null ? `column #${id}` : 'none chosen'}).`);
      return null;
    }
    const c = cols.get(id)!;
    if (selected && !selected.has(id)) out.push(`${c.label} is not one of the report's columns, so the report does not return it. Add it to the report.`);
    return c;
  };
  let measureCol: CanvasColumn | null = null;
  if (!ins.measure) {
    out.push('choose the value it explains.');
  } else {
    measureCol = field(ins.measure.column_id, 'value');
    const agg = ins.measure.aggregation;
    const name = measureCol?.label ?? `column #${ins.measure.column_id}`;
    if (!AGGS.includes(agg)) out.push(`"${agg}" is not a way to add up values.`);
    else if (measureCol) {
      if ((agg === 'sum' || agg === 'avg') && !isNumeric(measureCol)) {
        out.push(`${name} is not a number, so it cannot be ${agg === 'sum' ? 'added up' : 'averaged'}.`);
      } else if (grouped && agg === 'count') {
        out.push("this report's rows are already added up, so counting them would count groups, not the underlying rows. Use a count measure of the data (shown as Sum).");
      } else if (grouped && agg === 'avg') {
        out.push(`this report's rows are already added up, so an average of ${name} here would be an average of averages -- a wrong number. Use the Sum.`);
      } else if (grouped && agg === 'count_distinct' && emitsAggregate(measureCol)) {
        out.push(`${name} is added up in this report's rows, so its different values cannot be counted.`);
      } else if (SPLITTING.includes(ins.kind) && !(agg === 'sum' || (agg === 'count' && !grouped))) {
        out.push(`${name} must be added up (Sum) here: only a value that is added up splits into parts that add up to the whole.`);
      }
    }
  }
  ins.dimensions.forEach(d => field(d, 'field'));
  if (new Set(ins.dimensions).size !== ins.dimensions.length) out.push('the same field is used twice.');
  if (ins.dimensions.length > MAX_FIELDS) out.push(`it can split by at most ${MAX_FIELDS} fields.`);
  if (measureCol && ins.measure && ins.dimensions.includes(ins.measure.column_id)) {
    out.push('its value cannot also be one of the fields that split it.');
  }
  if (['explain_change', 'top_movers', 'decomposition'].includes(ins.kind) && ins.dimensions.length === 0) {
    out.push('choose at least one field to split it by.');
  }
  const cmp = ins.compare;
  if ((ins.kind === 'explain_change' || ins.kind === 'top_movers') && !cmp) {
    out.push('choose what to compare: two values of a date or period field, or the previous run.');
  }
  if (cmp) {
    const basis = cmp.basis || 'auto';
    if (!['column', 'previous_run', 'auto'].includes(basis)) out.push(`"${basis}" is not a way to compare.`);
    if (basis === 'column' && cmp.column_id == null) out.push('choose the date or period field whose two values are compared.');
    if (cmp.column_id != null) {
      field(cmp.column_id, 'comparison field');
      if (ins.dimensions.includes(cmp.column_id)) out.push('the field being compared cannot also split the change.');
    }
    if ((cmp.a == null) !== (cmp.b == null)) out.push('name both values to compare, or neither (the latest two are used).');
  }
  if (ins.kind === 'anomalies' && ins.date_column == null) out.push('choose the date field the values run along.');
  if (ins.date_column != null) field(ins.date_column, 'date field');
  const range = (v: number | null | undefined, [lo, hi]: [number, number], words: string, whole: boolean) => {
    if (v == null) return;
    if (!Number.isFinite(v) || v < lo || v > hi || (whole && !Number.isInteger(v))) {
      out.push(`the ${words} must be between ${lo} and ${hi}.`);
    }
  };
  range(ins.window, WINDOW_RANGE, 'earlier points each point is judged against', true);
  range(ins.threshold, THRESHOLD_RANGE, 'spreads that count as unusual', false);
  range(ins.top_n, [1, MAX_TOP_N], 'rows it lists', true);
  return out;
}

/** The body of the cube 'insight' request for a tile. */
export function insightCubeBody(ins: InsightConfig, path: InsightPathStep[] = [],
                                filters: { column: string; value: any }[] = []) {
  const insight: any = { ...ins };
  if (ins.kind === 'decomposition') insight.path = path;
  return { operation: 'insight', insight, path_filters: filters, slicers: {} };
}

/** The plain sentence for a failed insight request. */
export function insightErrorWords(err: any): string {
  const status = err?.status;
  const detail = err?.detail;
  if (status === 422 && detail?.error === 'insight_refused') return String(detail.message);
  if (status === 422 && detail?.error === 'insight_problems') return (detail.problems as string[]).join(' ');
  if (status === 422 && detail?.refused) {
    return `This value cannot be shown here. ${(detail.refused as any[]).map(r => r.reason).join('; ')}`;
  }
  if (status === 409) return String(err?.message || 'This run’s result is not ready yet. Try again shortly.');
  if (status === 400) return 'This run does not have every field this insight uses (the report changed after it ran). Run the report again.';
  if (status === 404) return 'This run’s result is no longer available. Run the report again.';
  if (status === 403) return 'You do not have access to this run’s result.';
  return String(err?.message || 'The insight could not be read.');
}

/** A field dropped on an insight tile: a measure becomes its value, any other field splits it. */
export function addFieldToInsight(ins: InsightConfig, col: CanvasColumn): InsightConfig {
  if (col.column_type === 'measure' || col.column_type === 'kpi') {
    return { ...ins, measure: { column_id: col.id, aggregation: 'sum' } };
  }
  if (ins.kind === 'anomalies') return ins.date_column == null ? { ...ins, date_column: col.id } : ins;
  if (ins.dimensions.includes(col.id) || ins.dimensions.length >= MAX_FIELDS) return ins;
  return { ...ins, dimensions: [...ins.dimensions, col.id] };
}
