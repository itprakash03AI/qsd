/**
 * The report canvas (2026-10-26, owner-approved design
 * docs/REPORT_CANVAS_DESIGN_2026_10_25.html).
 *
 * A report still runs ONE query: its columns are every field any tile uses.
 * Each tile is a view of that ONE result -- the stored, row-secured result
 * of the run -- never a second query to the source:
 *
 *   report  the report's own table (every existing feature: formatting,
 *           drill, slicers, paging through every row)
 *   table   chosen columns; with measures it is grouped by the other columns
 *   pivot   rows x one column field x measures
 *   bar / line / pie   one category field (+ an optional series) x a measure
 *   number  one measure over the whole result
 *
 * Tiles name columns by COLUMN ID (a renamed label cannot break a tile); the
 * physical name is resolved when the tile renders.  ``canvasProblems`` is the
 * ONE reading of what is wrong with a canvas, the builder shows it on the
 * tile it concerns, and the server applies the same rules on save
 * (backend/core/reports/canvas.py).
 */
import {
  OutlineTileFields, outlineProblems, readCanvasExtras, readOutlineFields, TileFormat,
} from './canvasOutline';

import { readActions, type CanvasAction } from './canvasActions';

import { InsightConfig, insightColumnIds, insightProblems, insightTitle, readInsight } from './canvasInsights';
// the KPI card's fields on a number tile (2026-11-02, canvasKpi.ts)
import { KpiFields, kpiColumnIds, kpiProblems, readKpiFields } from './canvasKpi';
// chart options: labels on the marks, the donut's centre, the two-dates overlay (2026-11-02, canvasChartOptions.ts)
import { ChartOptionFields, chartOptionProblems, readChartOptions } from './canvasChartOptions';
import { DerivedValue, derivedProblems, derivedRequest, readDerived } from './canvasDerived';

export type TileKind = 'report' | 'number' | 'table' | 'pivot' | 'heatmap'
  | 'bar' | 'hbar' | 'stacked_bar' | 'line' | 'area' | 'stacked_area' | 'combo' | 'radar'
  | 'pie' | 'donut' | 'treemap' | 'funnel' | 'waterfall' | 'scatter' | 'bubble'
  | 'outline' | 'band'
  | 'insight';  // canvasInsights.ts (2026-10-30)
export type Aggregation = 'sum' | 'avg' | 'count' | 'min' | 'max' | 'count_distinct';

export const TILE_KINDS: TileKind[] = ['report', 'number', 'table', 'pivot', 'heatmap',
  'bar', 'hbar', 'stacked_bar', 'line', 'area', 'stacked_area', 'combo', 'radar',
  'pie', 'donut', 'treemap', 'funnel', 'waterfall', 'scatter', 'bubble', 'outline', 'band', 'insight'];
/** one category, 1..8 values (each a series) OR one value split by a series field */
export const SERIES_CHARTS: TileKind[] = ['bar', 'hbar', 'stacked_bar', 'line', 'area', 'stacked_area', 'radar'];
/** one category, one value */
export const ONE_VALUE_CHARTS: TileKind[] = ['pie', 'donut', 'treemap', 'funnel', 'waterfall'];
/** parts of a whole / a running total: the value is added up */
export const SUM_ONLY: TileKind[] = ['pie', 'donut', 'treemap', 'waterfall'];
export const CHART_KINDS: TileKind[] = [...SERIES_CHARTS, ...ONE_VALUE_CHARTS, 'combo', 'scatter', 'bubble'];
export const MAX_SERIES_VALUES = 8;
/** a waterfall with NO category is a BRIDGE (2026-11-03): one step per value, then the total */
export const MAX_BRIDGE_STEPS = 8;
export const isBridge = (t: { kind: string; dimensions?: number[]; measures?: unknown[] }) =>
  t.kind === 'waterfall' && (t.dimensions ?? []).length === 0 && (t.measures ?? []).length >= 2;
export const isChart = (k: TileKind) => CHART_KINDS.includes(k);
export const AGGREGATIONS: Aggregation[] = ['sum', 'avg', 'count', 'min', 'max', 'count_distinct'];
export const GRID_COLS = 12;
/** the deepest a canvas goes (grid rows); the server refuses and clamps to the same */
export const MAX_GRID_ROWS = 2000;
export const MAX_TILES = 40;
/** a chart draws at most this many categories; more are told, never dropped in silence */
export const MAX_CHART_POINTS = 500;
/** a line / area with no series, or a scatter, may hold this many points (the server's
 *  canvas.MAX_DENSE_POINTS / MANY_POINT_KINDS): drawn from ~1 point per pixel, a big
 *  scatter painted with WebGL (canvasRender/drawingLadder.ts) */
export const MAX_DENSE_POINTS = 250_000;
export const MANY_POINT_KINDS: TileKind[] = ['line', 'area', 'scatter'];
/** How many categories a chart tile of this kind may draw (the server's max_points_of). */
export const maxPointsOf = (kind: TileKind, series: number | null | undefined) =>
  MANY_POINT_KINDS.includes(kind) && series == null ? MAX_DENSE_POINTS : MAX_CHART_POINTS;
export const DEFAULT_CHART_POINTS = 25;
/** a pivot spreads at most this many column values across; more are told */
export const MAX_PIVOT_COLUMNS = 200;

export const KIND_LABEL: Record<TileKind, string> = {
  report: "The report's table", number: 'Number', table: 'Table', pivot: 'Pivot', heatmap: 'Heat map',
  bar: 'Bar chart', hbar: 'Bar chart (sideways)', stacked_bar: 'Stacked bars', line: 'Line chart',
  area: 'Area chart', stacked_area: 'Stacked areas', combo: 'Bars + lines', radar: 'Radar',
  pie: 'Pie chart', donut: 'Donut', treemap: 'Treemap', funnel: 'Funnel', waterfall: 'Waterfall',
  scatter: 'Scatter (x / y)', bubble: 'Bubble (x / y / size)',
  outline: 'Outline (open and close rows)', band: 'Header band (chosen values)', insight: 'Insight',
};
export const AGG_LABEL: Record<Aggregation, string> = {
  sum: 'Sum', avg: 'Average', count: 'Count', min: 'Smallest', max: 'Largest',
  count_distinct: 'Count of different values',
};

/** `label` (2026-11-01): what the tile SHOWS for this value ("Trades"), else the column's words */
export interface TileMeasure { column_id: number; aggregation: Aggregation; label?: string }
export interface TileLayout { x: number; y: number; w: number; h: number }
export interface CanvasTile extends OutlineTileFields, KpiFields, ChartOptionFields {
  id: string;
  kind: TileKind;
  title: string;
  /** table: its columns; pivot: its row fields; chart: [category]; number: [] */
  dimensions: number[];
  measures: TileMeasure[];
  /** pivot: the column field; bar/line: an optional series field */
  series: number | null;
  /** 'measure' sorts by the first measure; 'derived' by a table's worked-out value
   *  (``index``, ``abs`` = by size whatever the sign); otherwise a column id */
  sort: { by: 'measure' | 'derived' | number; dir: 'asc' | 'desc'; index?: number; abs?: boolean } | null;
  /** table: values worked out from two of its values (canvasDerived.ts) */
  derived?: DerivedValue[];
  /** charts: how many categories to draw (the rest are counted and told) */
  top_n: number | null;
  layout: TileLayout;
  /** kind 'insight' only: what it shows (canvasInsights.ts) */
  insight?: InsightConfig | null;
  /** follows clicks on other tiles (linked tiles, canvasLinks.ts); absent = true */
  linked?: boolean;
}
export interface ReportCanvas {
  version: 1;
  tiles: CanvasTile[];
  /** a click on a tile filters the others (canvasLinks.ts); absent = on */
  links?: { enabled: boolean };
  /** the report's short code shown in the header band (canvasOutline.ts) */
  report_code?: string;
  /** what a click can do (canvasActions.tsx), e.g. Download detail */
  actions?: CanvasAction[];
  /** 2026-11-01 drill-down (canvasDrill.tsx): the declared paths and the fields a viewer may add */
  hierarchies?: Hierarchy[];
  drill_columns?: number[];
  /** 2026-11-01 the COB comparison (canvasCompare.tsx): the 'two dates to compare' parameter */
  compare?: { parameter: string };
  /** 2026-11-02 PAGES: tabs in the header, each a list of tile ids; a tile on no page sits on the first; none = one page */
  pages?: CanvasPage[];
}
export interface CanvasPage { id: string; title: string; tiles: string[] }
export const MAX_PAGES = 12;
export const MAX_PAGE_TITLE = 60;

/** THE ONE READING of a canvas's pages (the server's canvas.pages_of): the stored pages with every
 *  tile on no page added to the first; a canvas without pages is one page of every tile. */
export function pagesOf(c: Pick<ReportCanvas, 'tiles' | 'pages'>): { id: string; title: string; tile_ids: string[] }[] {
  const ids = c.tiles.map(t => t.id);
  const pages = Array.isArray(c.pages) ? c.pages : [];
  if (!pages.length) return [{ id: 'page1', title: '', tile_ids: [...ids] }];
  // tolerant of a stored shape the rules refuse (a non-list) -- the rules say so; this never throws
  const out = pages.filter(p => p && typeof p === 'object').map((p, i) => ({ id: p.id || `page${i + 1}`, title: p.title || '', tile_ids: Array.isArray(p.tiles) ? p.tiles.filter(x => ids.includes(x)) : [] }));
  if (!out.length) return [{ id: 'page1', title: '', tile_ids: [...ids] }];
  const placed = new Set(out.flatMap(p => p.tile_ids));
  out[0].tile_ids = [...out[0].tile_ids, ...ids.filter(i => !placed.has(i))];
  return out;
}
/** The page (index) a tile sits on. */
export const pageOfTile = (c: Pick<ReportCanvas, 'tiles' | 'pages'>, tileId: string): number =>
  Math.max(0, pagesOf(c).findIndex(p => p.tile_ids.includes(tileId)));

/** The server's words (canvas_outline.pages_problems). */
export function pagesProblems(c: ReportCanvas, say: (t: CanvasTile | null, message: string) => void): void {
  const pages: any = c.pages;
  if (pages == null) return;
  if (!Array.isArray(pages)) { say(null, 'The pages must be a list, each with a title and its tiles.'); return; }
  if (pages.length > MAX_PAGES) say(null, `A report can have ${MAX_PAGES} pages; this one has ${pages.length}.`);
  const ids = new Set(c.tiles.map(t => t.id));
  const seen = new Set<string>();
  const placed = new Set<string>();
  pages.forEach((p: any, i: number) => {
    const k = i + 1;
    if (!p || typeof p !== 'object') { say(null, `Page ${k} must have a title and its tiles.`); return; }
    if (typeof p.id !== 'string' || !/^[A-Za-z0-9_-]{1,64}$/.test(p.id) || seen.has(p.id)) say(null, `Page ${k}'s id is missing or used twice.`);
    seen.add(String(p.id));
    if (typeof p.title !== 'string' || !p.title.trim() || p.title.length > MAX_PAGE_TITLE || /[\x00-\x1f\x7f]/.test(p.title)) say(null, `Page ${k} needs a title of at most ${MAX_PAGE_TITLE} characters.`);
    if (!Array.isArray(p.tiles)) { say(null, `Page ${k}'s tiles must be a list of tile ids.`); return; }
    for (const tid of p.tiles) {
      if (!ids.has(String(tid))) say(null, `Page ${k} names a tile that is not on the canvas (${tid}).`);
      else if (placed.has(String(tid))) say(null, `A tile is on two pages (${tid}); a tile sits on one page.`);
      placed.add(String(tid));
    }
  });
}

/** The facts about a column a tile needs. */
export interface CanvasColumn {
  id: number;
  physical_name: string;
  label: string;
  data_type?: string | null;
  /** 'dimension' | 'measure' | 'kpi' | ... from the dataset */
  column_type?: string | null;
  aggregation?: string | null;
  /** the dataset column's display format (applyFormatPattern) */
  format_pattern?: string | null;
  /** a tile's own number format for this column (canvasOutline.withTileFormats) */
  tile_format?: TileFormat | null;
  /** (rig 2026-11-01) a hidden dataset column: still in the data (a tile may count it), not offered as a field */
  hidden?: boolean;
}

export interface CanvasProblem { tileId: string | null; message: string }

const NUMERIC = /int|decimal|numeric|double|float|real|number|money/i;
export const isNumericColumn = (c?: CanvasColumn | null) =>
  !!c && (NUMERIC.test(String(c.data_type || '')) || c.column_type === 'measure' || c.column_type === 'kpi');
export const isMeasureColumn = (c?: CanvasColumn | null) =>
  !!c && (c.column_type === 'measure' || c.column_type === 'kpi');

let _seq = 0;
export const newTileId = (kind: TileKind) =>
  `${kind}_${Date.now().toString(36)}${(_seq++).toString(36)}`;

const DATASET_AGGS = ['sum', 'avg', 'count', 'min', 'max', 'count_distinct'];
/** Does the query ADD UP this column (a measure with an aggregation)? */
export const emitsAggregate = (c?: CanvasColumn | null) =>
  !!c && isMeasureColumn(c) && DATASET_AGGS.includes(String(c.aggregation || '').toLowerCase());

/**
 * The server's grain rule (core/reports/canvas.py, the microcube): a dataset
 * that adds up any measure, or has a calculated metric, stores GROUPED rows.
 */
export function rowsAreGrouped(columns: CanvasColumn[], hasMetrics: boolean): boolean {
  return hasMetrics || columns.some(emitsAggregate);
}

/**
 * The ways a tile may add this column up that give an EXACT number for this
 * report.  Over grouped rows: an added-up measure is re-added (a count
 * measure too -- its "Total"), or its smallest / largest row taken; any other
 * column can be counted by its different values or its smallest / largest.
 * Over detail rows everything is exact; text cannot be added up or averaged.
 */
export function allowedAggregations(c: CanvasColumn | undefined | null, grouped: boolean): Aggregation[] {
  if (!c) return [];
  if (grouped) return emitsAggregate(c) ? ['sum', 'min', 'max'] : ['count_distinct', 'min', 'max'];
  return isNumericColumn(c) ? [...AGGREGATIONS] : ['count', 'count_distinct', 'min', 'max'];
}

/** How a tile adds this column up when it is first dropped. */
export function defaultAggregation(c: CanvasColumn | undefined | null, grouped = true): Aggregation {
  const allowed = allowedAggregations(c, grouped);
  const own = String(c?.aggregation || '').toLowerCase() as Aggregation;
  if (allowed.includes(own)) return own;
  if (allowed.includes('sum')) return 'sum';
  return allowed[0] ?? 'count_distinct';
}

/** The words for one value of a tile: "Amount (sum)", a count measure re-added is its "Total". */
export function measureWords(m: TileMeasure, cols: Map<number, CanvasColumn>, grouped: boolean): string {
  if (m.label && m.label.trim()) return m.label.trim();
  const c = cols.get(m.column_id);
  const name = c?.label ?? `column #${m.column_id}`;
  if (grouped && m.aggregation === 'sum' && String(c?.aggregation || '').toLowerCase() === 'count') return name;
  if (m.aggregation === 'sum' && emitsAggregate(c)) return name;
  return `${name} (${AGG_LABEL[m.aggregation]?.toLowerCase() ?? m.aggregation})`;
}

/** Size a new tile of this kind starts with. */
export function defaultSize(kind: TileKind): { w: number; h: number } {
  if (kind === 'insight') return { w: 6, h: 7 };
  if (kind === 'number') return { w: 3, h: 2 };
  if (kind === 'band') return { w: 12, h: 2 };
  if (kind === 'report' || kind === 'table' || kind === 'pivot' || kind === 'heatmap' || kind === 'outline') return { w: 12, h: 7 };
  return { w: 6, h: 5 };
}

/** The first free row under every tile. */
export function nextRow(tiles: CanvasTile[]): number {
  return tiles.reduce((m, t) => Math.max(m, t.layout.y + t.layout.h), 0);
}

export function makeTile(kind: TileKind, partial: Partial<CanvasTile>, tiles: CanvasTile[]): CanvasTile {
  const size = defaultSize(kind);
  return {
    id: newTileId(kind), kind, title: '', dimensions: [], measures: [], series: null,
    sort: isChart(kind) && !['line', 'area', 'stacked_area', 'waterfall', 'scatter', 'bubble'].includes(kind)
      ? { by: 'measure', dir: 'desc' } : null,
    // a dense kind (line / area / scatter) starts with NO cap: every point, the
    // server sends about a point per pixel (2026-11-01, the 25-of-94 defect)
    top_n: isChart(kind) && !MANY_POINT_KINDS.includes(kind) ? DEFAULT_CHART_POINTS : null,
    ...partial,
    layout: partial.layout ?? { x: 0, y: nextRow(tiles), ...size },
  };
}

/** An existing report (no canvas yet) opens as ONE tile: its own table (the server's
 *  core/reports/canvas.py::default_canvas, the same tile at 0,0 12 x 7). */
export function defaultCanvas(): ReportCanvas {
  return { version: 1, tiles: [makeTile('report', { id: 'report', title: '', layout: { x: 0, y: 0, w: 12, h: 7 } }, [])] };
}

/**
 * EVERY REPORT IS A CANVAS (2026-10-30, the owner: "we should mix both rather
 * than categorizing canvas n normal reports").  The ONE reading of a report's
 * canvas: the stored one, else ONE report tile -- derived here, never written
 * (nothing is stored until someone saves).  The server's effective_canvas.
 */
export function effectiveCanvas(layoutConfig: any): ReportCanvas {
  return readCanvas(layoutConfig) ?? defaultCanvas();
}

/** A canvas of the report's own table and nothing else: it looks and exports exactly as a report always did. */
export const isTableOnlyCanvas = (c: ReportCanvas | null | undefined) =>
  !!c && c.tiles.length > 0 && c.tiles.every(t => t.kind === 'report');

/** The report's own table on the canvas, if it is placed. */
export const reportTileOf = (c: ReportCanvas | null | undefined) => c?.tiles.find(t => t.kind === 'report') ?? null;

/** Read whatever is stored; anything unreadable becomes the default canvas. */
export function readCanvas(layoutConfig: any): ReportCanvas | null {
  const c = layoutConfig?.canvas;
  if (!c || typeof c !== 'object' || !Array.isArray(c.tiles)) return null;
  return {
    version: 1, ...readCanvasExtras(c), ...readDrill(c),
    tiles: c.tiles.filter((t: any) => t && typeof t === 'object').map((t: any) => ({
      ...readOutlineFields(t),
      ...(t.kind === 'number' ? readKpiFields(t) : {}),
      ...(CHART_KINDS.includes(t.kind) ? readChartOptions(t) : {}),
      id: String(t.id ?? ''), kind: t.kind, title: String(t.title ?? ''),
      dimensions: Array.isArray(t.dimensions) ? t.dimensions.map(Number) : [],
      measures: Array.isArray(t.measures)
        ? t.measures.map((m: any) => ({ column_id: Number(m?.column_id), aggregation: m?.aggregation,
                                        ...(typeof m?.label === 'string' && m.label.trim() ? { label: m.label.trim() } : {}) }))
        : [],
      series: t.series == null ? null : Number(t.series),
      sort: t.sort && typeof t.sort === 'object'
        ? (t.sort.by === 'derived'
          ? { by: 'derived', dir: t.sort.dir === 'asc' ? 'asc' : 'desc', index: Number(t.sort.index),
              ...(typeof t.sort.abs === 'boolean' ? { abs: t.sort.abs } : {}) }
          : { by: t.sort.by === 'measure' ? 'measure' : Number(t.sort.by), dir: t.sort.dir === 'asc' ? 'asc' : 'desc' })
        : null,
      ...(readDerived(t) ? { derived: readDerived(t) } : {}),
      top_n: t.top_n == null ? null : Number(t.top_n),
      ...(t.kind === 'insight' ? { insight: readInsight(t.insight) } : {}),
      layout: {
        x: Number(t.layout?.x ?? 0), y: Number(t.layout?.y ?? 0),
        w: Number(t.layout?.w ?? 6), h: Number(t.layout?.h ?? 4),
      },
      ...(typeof t.linked === 'boolean' ? { linked: t.linked } : {}),
    })),
    ...(c.links && typeof c.links.enabled === 'boolean' ? { links: { enabled: c.links.enabled } } : {}),
    ...(Array.isArray(c.pages) ? { pages: c.pages.filter((p: any) => p && typeof p === 'object').map((p: any) => ({ id: String(p.id ?? ''), title: String(p.title ?? ''), tiles: Array.isArray(p.tiles) ? p.tiles.map(String) : [] })) } : {}),
    ...(Array.isArray(c.actions) ? { actions: readActions(c.actions) } : {}),   // canvas actions (canvasActions.tsx)
  };
}

// ── drill-down (2026-11-01, canvasDrill.tsx renders it) ────────────────────
export interface Hierarchy { name: string; levels: number[] }
export interface DrillConfig { hierarchies?: Hierarchy[]; drill_columns?: number[] }
export const MAX_HIERARCHY_NAME = 60;
export const MAX_LEVELS = 8;

/** The stored drill fields (readCanvas keeps only what is read here). */
export function readDrill(c: any): DrillConfig {
  const out: DrillConfig = {};
  if (Array.isArray(c?.hierarchies)) {
    out.hierarchies = c.hierarchies.filter((h: any) => h && typeof h === 'object')
      .map((h: any) => ({ name: String(h.name ?? ''), levels: Array.isArray(h.levels) ? h.levels.map(Number) : [] }));
  }
  if (Array.isArray(c?.drill_columns)) out.drill_columns = c.drill_columns.map(Number);
  return out;
}

/** The server's words (core/reports/canvas_outline.py), said on the canvas. */
export function drillProblems(canvas: DrillConfig, cols: Map<number, CanvasColumn>, selected: Set<number> | null,
                              say: (t: CanvasTile | null, message: string) => void): void {
  const okCol = (id: number) => cols.has(id) && (!selected || selected.has(id));
  for (const h of canvas.hierarchies ?? []) {
    if (!h.name.trim() || h.name.length > MAX_HIERARCHY_NAME) say(null, `A drill path needs a name of at most ${MAX_HIERARCHY_NAME} characters.`);
    if (h.levels.length < 2 || h.levels.length > MAX_LEVELS) say(null, `The drill path "${h.name}" needs 2 to ${MAX_LEVELS} levels.`);
    if (new Set(h.levels).size !== h.levels.length) say(null, `The drill path "${h.name}" names the same field twice.`);
    for (const id of h.levels) if (!okCol(id)) say(null, `The drill path "${h.name}" uses a field that is not one of the report's columns (#${id}).`);
  }
  for (const id of canvas.drill_columns ?? []) if (!okCol(id)) say(null, `An approved drill field is not one of the report's columns (#${id}).`);
}

/** The hierarchy a tile drills along: the one whose FIRST level is the tile's first (only) field. */
export function hierarchyFor(drill: DrillConfig, tile: CanvasTile): Hierarchy | null {
  const first = tile.dimensions[0];
  if (first == null || tile.series != null || tile.dimensions.length !== 1) return null;
  if (!(CHART_KINDS.includes(tile.kind) || tile.kind === 'table')) return null;
  return (drill.hierarchies ?? []).find(h => h.levels[0] === first && h.levels.length >= 2) ?? null;
}

/** Every column id a canvas needs the report's query to return. */
export function canvasColumnIds(canvas: ReportCanvas): number[] {
  const ids = new Set<number>();
  (canvas.hierarchies ?? []).forEach(h => h.levels.forEach(i => ids.add(i)));
  (canvas.drill_columns ?? []).forEach(i => ids.add(i));
  for (const t of canvas.tiles) {
    t.dimensions.forEach(i => ids.add(i));
    t.measures.forEach(m => ids.add(m.column_id));
    if (t.series != null) ids.add(t.series);
    if (t.sort && typeof t.sort.by === 'number') ids.add(t.sort.by);
    (t.levels ?? []).forEach(i => ids.add(i));
    insightColumnIds(t.insight).forEach(i => ids.add(i));
    if (t.kind === 'number') kpiColumnIds(t).forEach(i => ids.add(i));
  }
  return [...ids];
}

/** What is wrong with ONE value of a tile (the aggregation, the grain rule) -- the server's canvas.measure_problems. */
export function measureProblems(m: { column_id: number; aggregation: Aggregation }, cols: Map<number, CanvasColumn>, grouped: boolean): string[] {
  if (!AGGREGATIONS.includes(m.aggregation)) return [`"${m.aggregation}" is not a way to add up values.`];
  const c = cols.get(m.column_id);
  const out: string[] = [];
  if (c && ['sum', 'avg'].includes(m.aggregation) && !isNumericColumn(c)) {
    out.push(`${c.label} is not a number, so it cannot be ${m.aggregation === 'sum' ? 'added up' : 'averaged'}. Use Count of different values instead.`);
  } else if (c && grouped && m.aggregation === 'count') {
    out.push('this report\'s rows are already added up, so counting them would count groups, not the underlying rows. Use a count measure of the data, or Count of different values.');
  } else if (c && grouped && m.aggregation === 'avg') {
    out.push(`this report's rows are already added up, so an average of ${c.label} here would be an average of averages -- a wrong number. Show the Sum instead.`);
  } else if (c && grouped && m.aggregation === 'count_distinct' && emitsAggregate(c)) {
    out.push(`${c.label} is added up in this report's rows, so its different values cannot be counted.`);
  }
  return out;
}

export function tileName(t: CanvasTile, cols: Map<number, CanvasColumn>): string {
  if (t.title.trim()) return t.title.trim();
  if (t.kind === 'report') return 'Report';
  if (t.kind === 'insight') return insightTitle(t, cols);
  const m = t.measures[0] ? cols.get(t.measures[0].column_id)?.label : '';
  const d = t.dimensions[0] ? cols.get(t.dimensions[0])?.label : '';
  if (t.kind === 'number') return m || 'Number';
  if (m && d) return `${m} by ${d}`;
  return m || d || KIND_LABEL[t.kind];
}

/**
 * Everything wrong with a canvas, each said once on the tile it concerns.
 * ``columns`` are the fields the report can show (its dataset's columns).
 * An empty list = nothing stops a save.
 */
export function canvasProblems(canvas: ReportCanvas, columns: CanvasColumn[],
                               opts: { grouped?: boolean; selected?: number[] | null } = {}): CanvasProblem[] {
  const grouped = opts.grouped ?? true;
  const selected = opts.selected ? new Set(opts.selected) : null;
  const out: CanvasProblem[] = [];
  const cols = new Map(columns.map(c => [c.id, c]));
  const say = (t: CanvasTile | null, message: string) =>
    out.push({ tileId: t ? t.id : null, message: t ? `${tileName(t, cols)}: ${message}` : message });

  if (canvas.tiles.length === 0) say(null, 'The report has no tiles. Add at least one.');
  if (canvas.tiles.length > MAX_TILES) say(null, `A report can hold ${MAX_TILES} tiles; this one has ${canvas.tiles.length}.`);
  if (canvas.tiles.filter(t => t.kind === 'report').length > 1) say(null, "The report's own table can be placed once.");
  const seen = new Set<string>();
  for (const t of canvas.tiles) {
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(t.id) || seen.has(t.id)) say(t, 'its id is missing or used twice.');
    seen.add(t.id);
    if (!TILE_KINDS.includes(t.kind)) { say(t, `"${t.kind}" is not a kind of tile.`); continue; }
    if (t.title.length > 200) say(t, 'its title is longer than 200 characters.');
    const { x, y, w, h } = t.layout;
    if (![x, y, w, h].every(Number.isInteger) || x < 0 || y < 0 || w < 1 || h < 1 || x + w > GRID_COLS || h > 60 || y + h > MAX_GRID_ROWS) {
      say(t, 'its place on the page is outside the 12-column grid.');
    }
    if (t.kind === 'insight') { insightProblems(t, cols, grouped, selected).forEach(m => say(t, m)); continue; }
    const fields = [...t.dimensions, ...t.measures.map(m => m.column_id), ...(t.series != null ? [t.series] : [])];
    for (const id of fields) {
      if (!cols.has(id)) say(t, `it uses a field that is no longer in the data (column #${id}). Remove it from the tile.`);
      else if (selected && !selected.has(id)) say(t, `${cols.get(id)!.label} is not one of the report's columns, so the report does not return it. Add it to the report.`);
    }
    if (new Set(t.dimensions).size !== t.dimensions.length) say(t, 'the same field is used twice.');
    for (const m of t.measures) measureProblems(m, cols, grouped).forEach(msg => say(t, msg));
    if (t.kind === 'number') kpiProblems(t, cols, selected, grouped, canvas, say, m => measureProblems(m, cols, grouped));
    if (isChart(t.kind)) chartOptionProblems(t, canvas, say);
    const cap = maxPointsOf(t.kind, t.series);
    if (t.top_n != null && (!Number.isInteger(t.top_n) || t.top_n < 1 || t.top_n > cap)) {
      say(t, `it can draw between 1 and ${cap.toLocaleString('en-US')} values.`);
    }
    switch (t.kind) {
      case 'report': break;
      case 'table':
        if (t.dimensions.length === 0 && t.measures.length === 0) say(t, 'add at least one field.');
        derivedProblems(t, m => say(t, m));   // values worked out from two others (2026-11-03)
        break;
      case 'pivot':
        if (t.dimensions.length === 0) say(t, 'needs at least one row field.');
        if (t.series == null) say(t, 'needs a column field to spread across.');
        if (t.series != null && t.dimensions.includes(t.series)) say(t, 'the column field is also a row field.');
        if (t.measures.length === 0) say(t, 'needs a value to show.');
        break;
      case 'heatmap':
        if (t.dimensions.length !== 1) say(t, 'needs one row field.');
        if (t.series == null) say(t, 'needs a column field to spread across.');
        else if (t.dimensions.includes(t.series)) say(t, 'the column field is also the row field.');
        if (t.measures.length !== 1) say(t, 'needs exactly one value to colour the cells by.');
        break;
      case 'number':
        if (t.measures.length !== 1 || t.dimensions.length > 0) say(t, 'shows exactly one value and no fields.');
        break;
      default:
        if (!isChart(t.kind)) break;
        if (t.kind === 'waterfall' && t.dimensions.length === 0 && t.measures.length !== 1) {
          // a bridge: one step per value (no category); every value added up
          if (t.measures.length < 2 || t.measures.length > MAX_BRIDGE_STEPS) say(t, `a waterfall of values (no category) needs 2 to ${MAX_BRIDGE_STEPS} values, one per step.`);
          if (t.series != null) say(t, 'cannot be split into series.');
          if (t.measures.some(m => m.aggregation !== 'sum')) say(t, 'a waterfall adds its values up as it goes, so each value must be added up (Sum).');
          break;
        }
        if (t.dimensions.length !== 1) {
          say(t, t.kind === 'scatter' || t.kind === 'bubble' ? 'needs one field that names each point.' : 'needs exactly one category field.');
        }
        if (SERIES_CHARTS.includes(t.kind)) {
          if (t.measures.length < 1 || t.measures.length > MAX_SERIES_VALUES) say(t, `draws between 1 and ${MAX_SERIES_VALUES} values.`);
          if (t.series != null && t.measures.length > 1) say(t, 'can be split by a series field OR show several values -- not both.');
        } else if (ONE_VALUE_CHARTS.includes(t.kind)) {
          if (t.measures.length !== 1) say(t, 'needs exactly one value to draw.');
          if (t.series != null) say(t, 'cannot be split into series.');
          if (SUM_ONLY.includes(t.kind) && t.measures.some(m => m.aggregation !== 'sum')) {
            say(t, `${t.kind === 'waterfall' ? 'a waterfall adds its values up as it goes' : 'shows parts of a whole'}, so its value must be added up (Sum).`);
          }
        } else if (t.kind === 'combo') {
          if (t.measures.length < 2 || t.measures.length > MAX_SERIES_VALUES) say(t, `needs 2 to ${MAX_SERIES_VALUES} values: the first as bars, the rest as lines.`);
          if (t.series != null) say(t, 'cannot be split into series.');
        } else if (t.kind === 'scatter' && t.measures.length !== 2) {
          say(t, 'needs two values: across (x) and up (y).');
        } else if (t.kind === 'bubble' && t.measures.length !== 3) {
          say(t, 'needs three values: across (x), up (y) and the bubble size.');
        }
        if ((t.kind === 'scatter' || t.kind === 'bubble') && t.series != null) say(t, 'cannot be split into series.');
        if (t.series != null && t.dimensions.includes(t.series)) say(t, 'the series field is also the category.');
    }
  }
  outlineProblems(canvas, cols, selected, grouped, say);   // the outline / band / formats (2026-10-30)
  drillProblems(canvas, cols, selected, say);               // the drill paths (2026-11-01)
  if (canvas.compare !== undefined && (!canvas.compare || typeof canvas.compare.parameter !== 'string' || !canvas.compare.parameter.trim() || canvas.compare.parameter.length > 100)) {
    say(null, "The comparison must name the parameter that holds the two dates (a 'two dates to compare' parameter).");
  }
  pagesProblems(canvas, say);                               // the pages (2026-11-02)
  // overlapping tiles: the grid never stores them, a hand-edited canvas might; tiles on different PAGES may
  const pageOf = new Map(pagesOf(canvas).flatMap((p, k) => p.tile_ids.map(id => [id, k] as [string, number])));
  for (let i = 0; i < canvas.tiles.length; i++) {
    for (let j = i + 1; j < canvas.tiles.length; j++) {
      if (pageOf.get(canvas.tiles[i].id) !== pageOf.get(canvas.tiles[j].id)) continue;
      const a = canvas.tiles[i].layout, b = canvas.tiles[j].layout;
      if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) {
        say(canvas.tiles[j], `it sits on top of ${tileName(canvas.tiles[i], cols)}.`);
      }
    }
  }
  return out;
}

/** The output name of a tile's i-th value (never collides with a column name). */
export const measureAlias = (i: number) => `v${i}__`;

/** The body of one cube 'drill' call for a tile (null = the tile does not use the cube). */
export function tileCubeBody(t: CanvasTile, cols: Map<number, CanvasColumn>, page = 1, pageSize = 500) {
  if (t.kind === 'report' || t.kind === 'outline' || t.kind === 'band' || t.kind === 'insight') return null;   // they read their own way
  const name = (id: number) => cols.get(id)?.physical_name || '';
  const dims = [...t.dimensions, ...(t.series != null ? [t.series] : [])].map(name);
  const measures = t.measures.map((m, i) => ({ column: name(m.column_id), aggregation: m.aggregation, alias: measureAlias(i) }));
  const firstMeasure = measures[0] ? measures[0].alias : null;
  let sortColumn: string | null = null;
  let sortDir: 'asc' | 'desc' = 'asc';
  const dv = derivedRequest(t);
  if (dv.sort) {
    sortColumn = dv.sort.column;
    sortDir = dv.sort.dir;
  } else if (t.sort && t.sort.by !== 'derived') {
    sortColumn = t.sort.by === 'measure' ? firstMeasure : name(t.sort.by);
    sortDir = t.sort.dir;
  } else if (['line', 'area', 'stacked_area', 'waterfall', 'pivot', 'heatmap', 'table'].includes(t.kind)) {
    sortColumn = dims[0] || null;
  }
  return {
    operation: 'drill', dimensions: dims, measures, path_filters: [], slicers: {},
    sort_column: sortColumn, sort_direction: sortDir, page, page_size: pageSize,
    ...(dv.derived.length ? { derived: dv.derived, sort_abs: !!dv.sort?.abs } : {}),
  };
}
