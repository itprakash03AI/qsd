/**
 * canvasCompare -- the COB comparison on the canvas (2026-11-01; FD-04/05/06).
 *
 * `canvas.compare = { parameter }` names a "two dates to compare" parameter.
 * The run binds its column IN (A, B) (backend core/reports/period.py), so the
 * ONE stored result holds both dates; a tile with values reads each side
 * through the cube with a slicer on that column:
 *  - a NUMBER tile shows B, with its change against A (arrow, colour, %);
 *  - a TABLE tile shows, per value, A · B · Variance · % Variance.
 * Decimal arithmetic on the cube's text numbers (the JSON road: exact).
 * The server's twin for the exports: core/reports/canvas_compare.py.
 */
import React, { useContext, useEffect, useMemo, useState } from 'react';
import { Box, Table, TableBody, TableCell, TableHead, TableRow, Typography } from '@mui/material';
import api from '../../../services/api';
import { CanvasColumn, CanvasTile, measureAlias, measureWords, tileCubeBody } from './canvasModel';
import { CanvasBandContext } from './CanvasOutlineTile';
import { formatValue } from './CanvasTileView';
import type { CubeFetch, TileRunInfo } from './CanvasTileView';
import { useCanvasTheme, negativeIsRed, negativeText } from './canvasTheme';
import { useCanvasTileActions } from './canvasActions';
import KpiCard from './KpiCard';
import { deltaWords, kpiLook, useKpiIndex } from './canvasKpi';

export interface CompareSetting { column_id: number; a: string; b: string; words: string }

/** The comparison the page runs under, read from the band's parameters (the viewer / the builder give them). */
export function compareFrom(canvas: { compare?: { parameter?: string } } | null | undefined,
                            params: { name: string; value: any; label?: string }[] | null | undefined,
                            paramRows: any[] | null | undefined): CompareSetting | { error: string } | null {
  const name = canvas?.compare?.parameter;
  if (!name) return null;
  const row = (paramRows || []).find(p => p.name === name);
  if (!row || row.parameter_type !== 'cob_compare' || !row.lov_column_id) {
    return { error: `The comparison names '${name}', which is not a 'two dates to compare' parameter bound to a date column.` };
  }
  let v = (params || []).find(p => p.name === name)?.value;
  if (typeof v === 'string' && v.includes('..')) { const [a, b] = v.split('..'); v = { a: a.trim(), b: b.trim() }; }
  if (!v || typeof v !== 'object' || !v.a || !v.b) return { error: `The comparison '${row.label || name}' has no two dates yet.` };
  return { column_id: Number(row.lov_column_id), a: String(v.a), b: String(v.b), words: `${row.label || name}: ${v.a} (A) vs ${v.b} (B)` };
}

const toDec = (v: any): number | null => (v === null || v === undefined || v === '' ? null : Number(v));
/** B - A and the percentage (null when A is 0 / missing). */
export function variance(a: any, b: any): { variance: number | null; pct: number | null } {
  const da = toDec(a), db = toDec(b);
  if (da === null && db === null) return { variance: null, pct: null };
  const A = da ?? 0, B = db ?? 0;
  const v = B - A;
  return { variance: v, pct: A === 0 ? null : Math.round((v / Math.abs(A)) * 10000) / 100 };
}

export const CanvasCompareContext = React.createContext<CompareSetting | { error: string } | null>(null);
export function useCanvasCompare() { return useContext(CanvasCompareContext); }

function useTwoSides(tile: CanvasTile, reportId: number | null, cols: Map<number, CanvasColumn>, run: TileRunInfo,
                     setting: CompareSetting | null, cubeFetch?: CubeFetch) {
  const [state, setState] = useState<{ loading: boolean; error: string; a: any[]; b: any[] }>({ loading: false, error: '', a: [], b: [] });
  const key = JSON.stringify([tile.dimensions, tile.measures, run.executionId, setting]);
  useEffect(() => {
    if (!setting || !reportId || !run.executionId) { setState({ loading: false, error: '', a: [], b: [] }); return; }
    const colName = cols.get(setting.column_id)?.physical_name;
    if (!colName) { setState({ loading: false, error: "The comparison's date column is not in this run.", a: [], b: [] }); return; }
    const fetch: CubeFetch = cubeFetch ?? ((r, e, b) => api.queryReportCube(r, e, b));
    const base: any = tileCubeBody(tile, cols, 1, tile.kind === 'number' ? 1 : 500);
    if (!base) return;
    let off = false;
    setState(s => ({ ...s, loading: true, error: '' }));
    // a NUMBER tile reads both dates in ONE drill BY the date column: a date with no rows is
    // simply absent (a SUM over no rows comes back 0 -- a made-up previous value)
    const read = tile.kind === 'number'
      ? fetch(reportId, run.executionId!, { ...base, dimensions: [colName], page_size: 4, sort_column: colName, sort_direction: 'asc',
          slicers: { ...(base.slicers || {}), [colName]: [setting.a, setting.b] } })
        .then(res => {
          const side = (d: string) => (res.rows || []).filter((r: any) => String(r[colName]).slice(0, 10) === d.slice(0, 10));
          return [{ rows: side(setting.a) }, { rows: side(setting.b) }];
        })
      : Promise.all(['a', 'b'].map(side => fetch(reportId, run.executionId!, { ...base, slicers: { ...(base.slicers || {}), [colName]: [setting[side as 'a' | 'b']] } })));
    read.then(([ra, rb]) => { if (!off) setState({ loading: false, error: '', a: ra.rows || [], b: rb.rows || [] }); })
      .catch(e => { if (!off) setState({ loading: false, error: String(e?.message || 'The comparison could not be read.'), a: [], b: [] }); });
    return () => { off = true; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, reportId, cubeFetch]);
  return state;
}

/** A number or table tile under a comparison. */
export default function CompareTile({ tile, reportId, cols, grouped, run, cubeFetch, setting, width = 300, height = 120 }: {
  tile: CanvasTile; reportId: number | null; cols: Map<number, CanvasColumn>; grouped: boolean; run: TileRunInfo;
  cubeFetch?: CubeFetch; setting: CompareSetting; width?: number; height?: number;
}) {
  const theme = useCanvasTheme();
  const kpiIndex = useKpiIndex(tile.id);
  const act = useCanvasTileActions(tile, cols);    // (rig 2026-11-01) the Book cell's popup works here too
  const { loading, error, a, b } = useTwoSides(tile, reportId, cols, run, setting, cubeFetch);
  const [explain, setExplain] = useState<{ busy: boolean; sentence?: string; story?: any; error?: string } | null>(null);
  const dimNames = tile.dimensions.map(id => cols.get(id)?.physical_name || '');
  const red = negativeIsRed(theme.grid.negative);
  const neg = (n: number, text: string) => (n < 0 ? <span style={{ color: red ? '#d32f2f' : undefined }}>{negativeText(text.replace(/^-/, ''), theme.grid.negative)}</span> : text);
  const fmt = (v: any, c?: CanvasColumn) => (v === null || v === undefined ? '—' : formatValue(v, c));
  if (!run.executionId) return <Typography variant="body2" color="text.secondary" data-testid="tile-not-run">Run the report to see this.</Typography>;
  if (error) return <Typography variant="body2" color="warning.main" data-testid="compare-error">{error}</Typography>;
  if (loading && !a.length && !b.length) return <Typography variant="caption" color="text.secondary">Reading both dates…</Typography>;
  const explainThis = async () => {
    if (!reportId || !run.executionId) return;
    setExplain({ busy: true });
    try {
      const fetch: CubeFetch = cubeFetch ?? ((r, e, b) => api.queryReportCube(r, e, b));
      const dims = tile.kind === 'number' ? [] : tile.dimensions.slice(0, 1);
      const res = await fetch(reportId, run.executionId, { operation: 'insight', tile_id: tile.id, insight: {
        kind: 'explain_change', measure: { column_id: tile.measures[0].column_id, aggregation: tile.measures[0].aggregation },
        dimensions: dims, compare: { basis: 'column', column_id: setting.column_id, a: setting.a, b: setting.b } } });
      setExplain({ busy: false, sentence: res?.sentence, story: res?.story });
    } catch (e: any) { setExplain({ busy: false, error: String(e?.message || 'The explanation could not be read.') }); }
  };
  const words = (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: explain ? 'wrap' : 'nowrap', minWidth: 0 }}>
      {/* (rig 2026-11-02) ONE line, cut with an ellipsis (the full words on hover): wrapped in a narrow KPI card it took the card's room and the change line was cut off */}<Typography variant="caption" color="text.secondary" component="div" data-testid="compare-words" noWrap title={setting.words} sx={{ flex: '1 1 auto', minWidth: 0 }}>{setting.words}</Typography>
      <Typography variant="caption" sx={{ cursor: 'pointer', color: 'primary.main', flexShrink: 0, whiteSpace: 'nowrap' }} component="button" onClick={explainThis} data-testid="compare-explain"
        style={{ background: 'none', border: 'none', padding: 0 }}>Explain this</Typography>
      {explain?.busy && <Typography variant="caption" color="text.secondary">Working it out…</Typography>}
      {explain?.error && <Typography variant="caption" color="warning.main" data-testid="compare-explain-error">{explain.error}</Typography>}
      {!explain?.busy && (explain?.story?.text || explain?.sentence) && (
        <Typography variant="caption" component="div" sx={{ width: '100%' }} data-testid="compare-explain-words">
          {explain.story?.source === 'assistant' ? explain.story.text : explain.sentence}
          {explain.story?.source === 'assistant' ? ' -- written by the QueryStudio assistant from these numbers.' : explain.story?.reason ? ` ${explain.story.reason}` : ''}
        </Typography>
      )}
    </Box>
  );
  if (tile.kind === 'number') {
    const m = tile.measures[0];
    const c = cols.get(m.column_id);
    const va = a[0]?.[measureAlias(0)], vb = b[0]?.[measureAlias(0)];
    // the KPI card (2026-11-02): B as the value, its change against A, in the theme's card style
    const change = deltaWords(vb, va, tile.good_when ?? 'up');
    return (
      <Box data-testid="compare-number" sx={{ height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <Box sx={{ flex: 1, minHeight: 0 }} data-testid="compare-b" data-value={fmt(vb, c)}>
          <KpiCard valueText={run.totalRows === 0 ? 'No rows' : fmt(vb, c)} muted={run.totalRows === 0 || vb == null} label={`${measureWords(m, cols, grouped)} on ${setting.b}`}
            change={change} previousWords={`vs ${setting.a}`} previousText={fmt(va, c)} look={kpiLook(tile, kpiIndex, theme)} theme={theme}
            icon={tile.icon ?? null} width={width} height={Math.max(60, height - 40)} fmtAbs={v => fmt(v, c)} />
        </Box>
        <Box sx={{ display: 'none' }} data-testid="compare-delta">{change.direction === 'none' ? 'no change to show' : `${change.direction === 'up' ? '▲' : change.direction === 'down' ? '▼' : '•'} ${fmt(Math.abs(change.variance ?? 0), c)}${change.pct === null ? '' : ` (${change.pct > 0 ? '+' : ''}${change.pct}%)`} vs ${setting.a}`}</Box>
        {words}
      </Box>
    );
  }
  // a table: rows joined by their dimension values -- each side indexed ONCE, O(|A| + |B|)
  const key = (r: any) => JSON.stringify(dimNames.map(d => r[d]));
  const byA = new Map<string, any>();
  for (const r of a) if (!byA.has(key(r))) byA.set(key(r), r);
  const byB = new Map<string, any>();
  for (const r of b) if (!byB.has(key(r))) byB.set(key(r), r);
  const order = [...byA.keys(), ...[...byB.keys()].filter(k => !byA.has(k))];
  const rows: { dims: any[]; cells: { va: any; vb: any; v: ReturnType<typeof variance> }[] }[] = order.map(k => {
    const ra = byA.get(k), rb = byB.get(k);
    const src = ra ?? rb;
    return { dims: dimNames.map(d => src[d]), cells: tile.measures.map((_m, i) => ({ va: ra?.[measureAlias(i)], vb: rb?.[measureAlias(i)], v: variance(ra?.[measureAlias(i)], rb?.[measureAlias(i)]) })) };
  });
  return (
    <Box sx={{ overflow: 'auto', height: '100%' }} data-testid="compare-table">
      {words}
      <Table size="small" stickyHeader sx={{ '& thead th': { bgcolor: theme.grid.header_bg, color: theme.grid.header_fg, fontWeight: 700, whiteSpace: 'nowrap' } }}>
        <TableHead>
          <TableRow>
            {tile.dimensions.map(id => <TableCell key={id}>{cols.get(id)?.label}</TableCell>)}
            {tile.measures.map((m, i) => [`${setting.a}`, `${setting.b}`, 'Variance', '% Variance'].map(h => (
              <TableCell key={`${i}-${h}`} align="right">{measureWords(m, cols, grouped)} · {h}</TableCell>)))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((r, i) => (
            <TableRow key={i} data-testid="compare-row">
              {r.dims.map((d, j) => <TableCell key={j}>{act.cell(Object.fromEntries(dimNames.map((n, x) => [n, r.dims[x]])), cols.get(tile.dimensions[j]), fmt(d, cols.get(tile.dimensions[j])))}</TableCell>)}
              {r.cells.map((c, j) => {
                const col = cols.get(tile.measures[j].column_id);
                return (
                  <React.Fragment key={j}>
                    <TableCell align="right">{fmt(c.va, col)}</TableCell>
                    <TableCell align="right">{fmt(c.vb, col)}</TableCell>
                    <TableCell align="right" data-testid="compare-variance">{c.v.variance === null ? '—' : neg(c.v.variance, fmt(c.v.variance, col))}</TableCell>
                    <TableCell align="right">{c.v.pct === null ? '—' : neg(c.v.pct, `${c.v.pct}%`)}</TableCell>
                  </React.Fragment>
                );
              })}
            </TableRow>
          ))}
          {rows.length === 0 && <TableRow><TableCell colSpan={tile.dimensions.length + 4 * tile.measures.length}><Typography variant="body2" color="text.secondary">No rows on either date.</Typography></TableCell></TableRow>}
        </TableBody>
      </Table>
      {act.ui}
    </Box>
  );
}

/** The builder: which 'two dates to compare' parameter the canvas compares on. */
export function CompareSettings({ canvas, params, onChange }: {
  canvas: { compare?: { parameter: string } }; params: { name: string; label?: string; parameter_type?: string }[];
  onChange: (f: (c: any) => any) => void;
}) {
  const choices = params.filter(p => p.parameter_type === 'cob_compare');
  return (
    <Box sx={{ mt: 1 }} data-testid="compare-settings">
      <Typography variant="subtitle2">Compare two dates</Typography>
      <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 0.5 }}>
        Every number and table shows A, B, the variance and the %; a number tile shows B with its change. Needs a parameter of kind "Two dates to compare".
      </Typography>
      <select aria-label="Compare on" data-testid="compare-parameter" value={canvas.compare?.parameter ?? ''}
        onChange={e => onChange(c => { const { compare: _c, ...rest } = c; return e.target.value ? { ...rest, compare: { parameter: e.target.value } } : rest; })}
        style={{ padding: 6, borderRadius: 6, border: '1px solid #ccc', minWidth: 220 }}>
        <option value="">No comparison</option>
        {choices.map(p => <option key={p.name} value={p.name}>{p.label || p.name}</option>)}
      </select>
      {choices.length === 0 && <Typography variant="caption" color="text.secondary" component="div">Add a parameter of kind "Two dates to compare" first ("+ Ask for a value").</Typography>}
    </Box>
  );
}
