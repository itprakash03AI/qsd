/** The KPI card icons: a fixed set of business icons, named in canvasKpi.KPI_ICONS (the server's list). */
import React from 'react';
import AttachMoney from '@mui/icons-material/AttachMoney';
import AccountBalance from '@mui/icons-material/AccountBalance';
import BarChart from '@mui/icons-material/BarChart';
import TrendingUp from '@mui/icons-material/TrendingUp';
import TrendingDown from '@mui/icons-material/TrendingDown';
import Percent from '@mui/icons-material/Percent';
import People from '@mui/icons-material/People';
import Person from '@mui/icons-material/Person';
import Business from '@mui/icons-material/Business';
import Public from '@mui/icons-material/Public';
import CalendarMonth from '@mui/icons-material/CalendarMonth';
import Schedule from '@mui/icons-material/Schedule';
import Warning from '@mui/icons-material/Warning';
import CheckCircle from '@mui/icons-material/CheckCircle';
import Flag from '@mui/icons-material/Flag';
import Star from '@mui/icons-material/Star';
import ShoppingCart from '@mui/icons-material/ShoppingCart';
import Inventory2 from '@mui/icons-material/Inventory2';
import LocalShipping from '@mui/icons-material/LocalShipping';
import Factory from '@mui/icons-material/Factory';
import Work from '@mui/icons-material/Work';
import AccountBalanceWallet from '@mui/icons-material/AccountBalanceWallet';
import CreditCard from '@mui/icons-material/CreditCard';
import Receipt from '@mui/icons-material/Receipt';
import Balance from '@mui/icons-material/Balance';
import Shield from '@mui/icons-material/Shield';
import Bolt from '@mui/icons-material/Bolt';
import TrackChanges from '@mui/icons-material/TrackChanges';
import PieChart from '@mui/icons-material/PieChart';
import TableChart from '@mui/icons-material/TableChart';
import Savings from '@mui/icons-material/Savings';
import Payments from '@mui/icons-material/Payments';
import CurrencyExchange from '@mui/icons-material/CurrencyExchange';
import Insights from '@mui/icons-material/Insights';
import Speed from '@mui/icons-material/Speed';
import Assessment from '@mui/icons-material/Assessment';
import type { KpiIcon } from './canvasKpi';

export const KPI_ICON_PARTS: Record<KpiIcon, React.ElementType> = {
  money: AttachMoney, bank: AccountBalance, chart: BarChart, trend_up: TrendingUp, trend_down: TrendingDown, percent: Percent,
  people: People, person: Person, building: Business, globe: Public, calendar: CalendarMonth, clock: Schedule, warning: Warning,
  check: CheckCircle, flag: Flag, star: Star, cart: ShoppingCart, box: Inventory2, truck: LocalShipping, factory: Factory,
  briefcase: Work, wallet: AccountBalanceWallet, card: CreditCard, receipt: Receipt, scale: Balance, shield: Shield, bolt: Bolt,
  target: TrackChanges, pie: PieChart, table: TableChart, savings: Savings, payments: Payments, exchange: CurrencyExchange,
  insights: Insights, speed: Speed, assessment: Assessment,
};

export const KPI_ICON_WORDS: Record<KpiIcon, string> = {
  money: 'Money', bank: 'Bank', chart: 'Bar chart', trend_up: 'Trend up', trend_down: 'Trend down', percent: 'Percent',
  people: 'People', person: 'Person', building: 'Building', globe: 'Globe', calendar: 'Calendar', clock: 'Clock', warning: 'Warning',
  check: 'Tick', flag: 'Flag', star: 'Star', cart: 'Cart', box: 'Box', truck: 'Truck', factory: 'Factory', briefcase: 'Briefcase',
  wallet: 'Wallet', card: 'Card', receipt: 'Receipt', scale: 'Scales', shield: 'Shield', bolt: 'Bolt', target: 'Target',
  pie: 'Pie chart', table: 'Table', savings: 'Savings', payments: 'Payments', exchange: 'Exchange', insights: 'Insights',
  speed: 'Speed', assessment: 'Assessment',
};

export function KpiIconPicture({ icon, size = 22, color }: { icon: KpiIcon; size?: number; color?: string }) {
  const Part = KPI_ICON_PARTS[icon];
  if (!Part) return null;
  return <Part sx={{ fontSize: size, color }} titleAccess={KPI_ICON_WORDS[icon]} data-testid={`kpi-icon-${icon}`} />;
}
