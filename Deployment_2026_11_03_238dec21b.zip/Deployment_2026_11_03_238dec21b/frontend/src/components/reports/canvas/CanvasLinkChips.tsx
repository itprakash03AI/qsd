/**
 * Linked canvas tiles (2026-10-30): the chips under the report header, the
 * caption on each tile, and the two switches in the builder.  The rule and
 * the state live in canvasLinks.ts; these are only their words on screen.
 */
import React from 'react';
import { Box, Button, Chip, FormControlLabel, Switch, Typography } from '@mui/material';
import type { CanvasColumn, CanvasTile, ReportCanvas } from './canvasModel';
import { linksEnabled, linkValueWords, linkWords, useCanvasLinks } from './canvasLinks';

/** "Linked: Product Area = Credit ✕  Business Area = FI Credit ✕  Clear" -- nothing when no link. */
export default function CanvasLinkChips({ cols }: { cols: Map<number, CanvasColumn> }) {
  const { enabled, all, remove, clear } = useCanvasLinks();
  if (!enabled || all.length === 0) return null;
  return (
    <Box data-testid="canvas-links" role="region" aria-label="Linked values"
      sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 0.75, mb: 1, px: 1, py: 0.75,
            borderRadius: 1, bgcolor: 'action.hover' }}>
      <Typography variant="body2" sx={{ fontWeight: 600 }}>Linked:</Typography>
      {all.map((l, i) => {
        // a clicked path is ONE chip (its steps joined by ›); ✕ takes the whole path
        if (l.path && all.findIndex(x => x.path === l.path) !== i) return null;
        const steps = l.path ? all.filter(x => x.path === l.path) : [l];
        const words = steps.map(s => `${cols.get(s.column_id)?.label ?? `column #${s.column_id}`} = ${linkValueWords(s.value)}`).join(' › ');
        return (
          <Chip key={`${l.column_id}-${i}`} size="small" color="primary" variant="outlined" label={words}
            data-testid="canvas-link-chip" onDelete={() => remove(l)}
            deleteIcon={<span aria-label={`Remove ${words}`} data-testid="canvas-link-remove" style={{ fontSize: 14, lineHeight: 1 }}>✕</span>} />
        );
      })}
      <Button size="small" onClick={clear} data-testid="canvas-links-clear">Clear</Button>
      <Typography variant="caption" color="text.secondary">
        Every linked tile shows only this. Click a value again to remove it; Ctrl-click adds another.
      </Typography>
    </Box>
  );
}

/** The one line on a tile while links are set: what filters it, or that it does not follow them. */
export function TileLinkCaption({ cols }: { cols: Map<number, CanvasColumn> }) {
  const { enabled, all, filters, unlinked } = useCanvasLinks();
  if (!enabled || all.length === 0) return null;
  if (unlinked) {
    return <Typography variant="caption" color="text.secondary" data-testid="tile-unlinked">Not linked: shows every row.</Typography>;
  }
  if (filters.length === 0) return null;
  const words = linkWords(filters, cols);
  return (
    <Typography variant="caption" color="primary" noWrap title={`Filtered by ${words}`} data-testid="tile-filtered">
      Filtered by {words}
    </Typography>
  );
}

/** The builder: the canvas-wide switch. */
export function CanvasLinksSwitch({ canvas, onChange }: { canvas: ReportCanvas; onChange: (enabled: boolean) => void }) {
  return (
    <FormControlLabel sx={{ mb: 1 }}
      control={<Switch size="small" checked={linksEnabled(canvas)} onChange={e => onChange(e.target.checked)}
        inputProps={{ 'aria-label': 'Clicking a tile filters the other tiles' }} data-testid="canvas-links-enabled" />}
      label={<Typography variant="body2">Clicking a tile filters the other tiles</Typography>} />
  );
}

/** The builder: one tile's switch. */
export function TileLinkedSwitch({ tile, onChange }: { tile: CanvasTile; onChange: (linked: boolean) => void }) {
  // the report's own table follows clicks too (2026-10-30), so it has the switch as well
  return (
    <FormControlLabel
      control={<Switch size="small" checked={tile.linked !== false} onChange={e => onChange(e.target.checked)}
        data-testid="tile-linked" />}
      label={<Typography variant="body2">Follows clicks on other tiles</Typography>} />
  );
}

/** A canvas / tile with the switch set: ``linked`` is stored only when OFF, ``links`` only when off,
 *  so a canvas nobody switched stays byte-identical to before. */
export const setTileLinked = (t: CanvasTile, linked: boolean): CanvasTile => {
  const { linked: _old, ...rest } = t;
  return linked ? rest : { ...rest, linked: false };
};
export const setCanvasLinks = (c: ReportCanvas, enabled: boolean): ReportCanvas => {
  const { links: _old, ...rest } = c;
  return enabled ? rest : { ...rest, links: { enabled: false } };
};
