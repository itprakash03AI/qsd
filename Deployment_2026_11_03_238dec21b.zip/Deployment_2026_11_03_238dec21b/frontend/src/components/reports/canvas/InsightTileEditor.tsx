/**
 * The builder's settings for an insight tile (2026-10-30) -- see canvasInsights.ts.
 * Plain words; only the choices that give an exact answer are offered.
 */
import React from 'react';
import { Autocomplete, MenuItem, Stack, TextField, Typography } from '@mui/material';
import type { Aggregation, CanvasColumn, CanvasTile } from './canvasModel';
import {
  BASIS_LABEL, CompareBasis, INSIGHT_HELP, INSIGHT_KINDS, INSIGHT_LABEL, InsightConfig, InsightKind, MAX_FIELDS,
  MAX_TOP_N, newInsight, SPLITTING, THRESHOLD_RANGE, WINDOW_RANGE,
} from './canvasInsights';

const isMeasure = (c?: CanvasColumn) => !!c && (c.column_type === 'measure' || c.column_type === 'kpi');
const isDateish = (c?: CanvasColumn) => !!c && /date|time|period|month|year/i.test(`${c.data_type ?? ''} ${c.physical_name} ${c.label}`);

export default function InsightTileEditor({ tile, columns, cols, grouped, onChange }: {
  tile: CanvasTile; columns: CanvasColumn[]; cols: Map<number, CanvasColumn>; grouped: boolean;
  onChange: (f: (t: CanvasTile) => CanvasTile) => void;
}) {
  const ins: InsightConfig = tile.insight ?? newInsight('explain_change');
  const set = (patch: Partial<InsightConfig>) => onChange(t => ({ ...t, insight: { ...(t.insight ?? ins), ...patch } }));
  const label = (id: number) => cols.get(id)?.label ?? `column #${id}`;
  const measures = columns.filter(isMeasure);
  const fields = columns.filter(c => !isMeasure(c));
  const dates = [...fields.filter(isDateish), ...fields.filter(c => !isDateish(c))];
  const splitting = SPLITTING.includes(ins.kind);
  const aggs: Aggregation[] = splitting ? (grouped ? ['sum'] : ['sum', 'count']) : (grouped ? ['sum', 'min', 'max'] : ['sum', 'avg', 'count', 'min', 'max']);
  const needsCompare = ins.kind === 'explain_change' || ins.kind === 'top_movers' || ins.kind === 'summary';
  const num = (v: string) => (v === '' ? null : Number(v));

  return (
    <Stack spacing={1.25} data-testid="insight-editor">
      <TextField select size="small" label="This insight shows" value={ins.kind}
        onChange={e => {
          const kind = e.target.value as InsightKind;
          set({ kind, compare: kind === 'explain_change' || kind === 'top_movers' ? (ins.compare ?? { basis: 'auto' }) : kind === 'summary' ? ins.compare ?? null : null });
        }} inputProps={{ 'data-testid': 'insight-kind' }}>
        {INSIGHT_KINDS.map(k => <MenuItem key={k} value={k}>{INSIGHT_LABEL[k]}</MenuItem>)}
      </TextField>
      <Typography variant="caption" color="text.secondary">{INSIGHT_HELP[ins.kind]}</Typography>

      <Stack direction="row" spacing={0.5}>
        <TextField select size="small" fullWidth label="Value" value={ins.measure?.column_id ?? ''}
          onChange={e => set({ measure: { column_id: Number(e.target.value), aggregation: ins.measure?.aggregation && aggs.includes(ins.measure.aggregation) ? ins.measure.aggregation : 'sum' } })}
          inputProps={{ 'data-testid': 'insight-measure' }}>
          {(measures.length ? measures : columns).map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
        </TextField>
        <TextField select size="small" label="Add up as" value={ins.measure?.aggregation ?? 'sum'} sx={{ width: 130 }}
          disabled={!ins.measure}
          onChange={e => ins.measure && set({ measure: { ...ins.measure, aggregation: e.target.value as Aggregation } })}>
          {aggs.map(a => <MenuItem key={a} value={a}>{{ sum: 'Sum', avg: 'Average', count: 'Count', min: 'Smallest', max: 'Largest', count_distinct: 'Different values' }[a]}</MenuItem>)}
        </TextField>
      </Stack>

      {ins.kind !== 'anomalies' && (
        <Autocomplete multiple size="small" options={fields.map(c => c.id)} value={ins.dimensions}
          getOptionLabel={i => label(i)} onChange={(_, v) => set({ dimensions: v.slice(0, MAX_FIELDS) })}
          renderInput={p => <TextField {...p} label={ins.kind === 'decomposition' ? 'Levels (in order)' : ins.kind === 'top_movers' ? 'Split by (together)' : 'Split by'}
            inputProps={{ ...p.inputProps, 'data-testid': 'insight-fields' }} />} />
      )}

      {needsCompare && (
        <>
          <TextField select size="small" label="Compare" value={ins.compare ? ins.compare.basis : 'none'}
            onChange={e => set({ compare: e.target.value === 'none' ? null : { ...(ins.compare ?? {}), basis: e.target.value as CompareBasis } })}
            inputProps={{ 'data-testid': 'insight-basis' }}>
            {ins.kind === 'summary' && <MenuItem value="none">Do not compare</MenuItem>}
            {(['auto', 'column', 'previous_run'] as CompareBasis[]).map(b => <MenuItem key={b} value={b}>{BASIS_LABEL[b]}</MenuItem>)}
          </TextField>
          {ins.compare && ins.compare.basis !== 'previous_run' && (
            <TextField select size="small" label="Date or period field" value={ins.compare.column_id ?? ''}
              onChange={e => set({ compare: { ...ins.compare!, column_id: e.target.value === '' ? null : Number(e.target.value) } })}
              helperText="The latest two values in the result are compared."
              inputProps={{ 'data-testid': 'insight-compare-field' }}>
              {ins.compare.basis === 'auto' && <MenuItem value="">None (use the previous run)</MenuItem>}
              {dates.map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
            </TextField>
          )}
        </>
      )}

      {(ins.kind === 'anomalies' || ins.kind === 'summary') && (
        <TextField select size="small" label={ins.kind === 'summary' ? 'Look for unusual values along (optional)' : 'Along the date field'}
          value={ins.date_column ?? ''} onChange={e => set({ date_column: e.target.value === '' ? null : Number(e.target.value) })}
          inputProps={{ 'data-testid': 'insight-date' }}>
          {ins.kind === 'summary' && <MenuItem value="">None</MenuItem>}
          {dates.map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
        </TextField>
      )}
      {(ins.kind === 'anomalies' || (ins.kind === 'summary' && ins.date_column != null)) && (
        <Stack direction="row" spacing={0.5}>
          <TextField size="small" type="number" label="Judge against the previous" value={ins.window ?? 7}
            inputProps={{ min: WINDOW_RANGE[0], max: WINDOW_RANGE[1] }}
            onChange={e => set({ window: num(e.target.value) })} helperText="points" />
          <TextField size="small" type="number" label="Unusual beyond" value={ins.threshold ?? 3}
            inputProps={{ min: THRESHOLD_RANGE[0], max: THRESHOLD_RANGE[1], step: 0.5 }}
            onChange={e => set({ threshold: num(e.target.value) })} helperText="typical spreads" />
        </Stack>
      )}
      {ins.kind !== 'anomalies' && (
        <TextField size="small" type="number" label="Rows to list" value={ins.top_n ?? (ins.kind === 'top_movers' ? 5 : 10)}
          inputProps={{ min: 1, max: MAX_TOP_N }} onChange={e => set({ top_n: num(e.target.value) })}
          helperText={ins.kind === 'top_movers' ? 'rises and falls each' : 'the rest are one row, "Everything else"'} />
      )}
      {grouped && splitting && (
        <Typography variant="caption" color="text.secondary">
          This report&apos;s rows are already added up, so the value is split as a Sum (the exact way).
        </Typography>
      )}
    </Stack>
  );
}
