/**
 * viewerLayout -- a VIEWER's own arrangement of a report (2026-11-01; FD-03 / FD-10).
 *
 * When the author allows it (Design -> "Viewers may rearrange"), a person who
 * may only view the report moves / resizes its tiles and picks the fields a
 * table, pivot, chart or finance grid shows -- from the APPROVED columns
 * (canvas.drill_columns) and the tile's own.  The layout is kept PER PERSON
 * on the server (GET / PUT / DELETE .../my-layout; backend
 * core/reports/viewer_layout.py), reset in one click, and that person's
 * Excel / PDF use it.  The author's canvas is never written.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Button, Checkbox, Menu, MenuItem, Stack, Typography } from '@mui/material';
import { safeFetch } from '../../../services/api/core';
import { safeStringify } from '../../../utils/safeStringify';
import { CanvasColumn, CanvasTile, ReportCanvas, TileLayout } from './canvasModel';

export interface ViewerLayout {
  tiles?: Record<string, TileLayout>;
  fields?: Record<string, { dimensions?: number[]; series?: number | null; levels?: number[] }>;
}

/** The canvas as this viewer sees it (a copy; the server's `viewer_layout.apply`). */
export function applyViewerLayout(canvas: ReportCanvas, layout: ViewerLayout | null | undefined): ReportCanvas {
  if (!layout) return canvas;
  return {
    ...canvas,
    tiles: canvas.tiles.map(t => {
      const pos = layout.tiles?.[t.id];
      const f = layout.fields?.[t.id];
      return {
        ...t,
        ...(pos ? { layout: { ...t.layout, ...pos } } : {}),
        ...(f?.dimensions ? { dimensions: [...f.dimensions] } : {}),
        ...(f?.levels ? { levels: [...f.levels] } : {}),
        ...(f && 'series' in f ? { series: f.series ?? null } : {}),
      };
    }),
  };
}

/** The columns a viewer may put on a tile: the approved ones and the tile's own. */
export function approvedFor(canvas: ReportCanvas, tile: CanvasTile): number[] {
  const own = new Set<number>([...tile.dimensions, ...(tile.levels ?? []), ...(tile.series != null ? [tile.series] : [])]);
  (canvas.drill_columns ?? []).forEach(c => own.add(c));
  return [...own];
}

export function useViewerLayout(reportId: number | null, enabledHint: boolean) {
  const [allowed, setAllowed] = useState(false);
  const [layout, setLayout] = useState<ViewerLayout | null>(null);
  const [note, setNote] = useState('');
  const timer = useRef<any>(null);
  useEffect(() => {
    if (!reportId) return;
    let off = false;
    safeFetch(`/api/business-reports/${reportId}/my-layout`).then((r: any) => {
      if (off) return;
      setAllowed(!!r?.allowed);
      setLayout(r?.layout && typeof r.layout === 'object' ? r.layout : null);
    }).catch(() => { if (!off) setAllowed(enabledHint); });
    return () => { off = true; };
  }, [reportId, enabledHint]);
  const save = useCallback((next: ViewerLayout) => {
    setLayout(next);
    if (!reportId) return;
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      safeFetch(`/api/business-reports/${reportId}/my-layout`, { method: 'PUT', body: safeStringify({ layout: next }) })
        .then(() => setNote('Your layout is kept.'))
        .catch((e: any) => setNote(e?.payload?.message || e?.message || 'Your layout could not be kept.'));
    }, 600);
  }, [reportId]);
  const onLayout = useCallback((layouts: Record<string, TileLayout>) => {
    save({ ...(layout || {}), tiles: { ...(layout?.tiles || {}), ...layouts } });
  }, [layout, save]);
  const onFields = useCallback((tileId: string, f: { dimensions?: number[]; series?: number | null; levels?: number[] }) => {
    save({ ...(layout || {}), fields: { ...(layout?.fields || {}), [tileId]: { ...(layout?.fields?.[tileId] || {}), ...f } } });
  }, [layout, save]);
  const reset = useCallback(async () => {
    if (!reportId) return;
    try { await safeFetch(`/api/business-reports/${reportId}/my-layout`, { method: 'DELETE' }); } catch { /* said below */ }
    setLayout(null); setNote('Back to the report\'s own layout.');
  }, [reportId]);
  return { allowed, layout, onLayout, onFields, reset, note, hasOwn: !!layout && (Object.keys(layout.tiles || {}).length > 0 || Object.keys(layout.fields || {}).length > 0) };
}

/** The "Fields" menu on a tile: tick the approved columns the tile shows. */
export function FieldsMenu({ tile, canvas, cols, onFields }: {
  tile: CanvasTile; canvas: ReportCanvas; cols: Map<number, CanvasColumn>;
  onFields: (tileId: string, f: { dimensions?: number[]; series?: number | null; levels?: number[] }) => void;
}) {
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const approved = useMemo(() => approvedFor(canvas, tile).filter(id => cols.has(id)), [canvas, tile, cols]);
  const key: 'levels' | 'dimensions' = tile.kind === 'outline' ? 'levels' : 'dimensions';
  const current = (key === 'levels' ? tile.levels : tile.dimensions) ?? [];
  if (!approved.length || tile.kind === 'number' || tile.kind === 'band' || tile.kind === 'report' || tile.kind === 'insight') return null;
  const single = !['table', 'outline', 'pivot'].includes(tile.kind);   // a chart has one category
  return (
    <>
      <Button size="small" onClick={e => setAnchor(e.currentTarget)} data-testid={`viewer-fields-${tile.id}`} sx={{ alignSelf: 'flex-start', py: 0, minWidth: 0 }}>Fields</Button>
      <Menu open={!!anchor} anchorEl={anchor} onClose={() => setAnchor(null)}>
        <Typography variant="caption" color="text.secondary" sx={{ px: 2 }}>{single ? 'The field this chart shows' : 'The fields this tile shows (approved columns)'}</Typography>
        {approved.map(id => {
          const on = current.includes(id);
          return (
            <MenuItem key={id} data-testid={`viewer-field-${tile.id}-${id}`} onClick={() => {
              const next = single ? [id] : on ? current.filter(x => x !== id) : [...current, id];
              if (!next.length) return;
              onFields(tile.id, { [key]: next });
              if (single) setAnchor(null);
            }}>
              <Checkbox size="small" checked={on} tabIndex={-1} sx={{ p: 0.25, mr: 1 }} />{cols.get(id)?.label ?? `#${id}`}
            </MenuItem>
          );
        })}
      </Menu>
    </>
  );
}

export function ViewerLayoutBar({ hasOwn, reset, note }: { hasOwn: boolean; reset: () => void; note: string }) {
  return (
    <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.5 }} data-testid="viewer-layout-bar">
      <Typography variant="caption" color="text.secondary">You may move and resize the tiles and pick their fields; your arrangement is kept for you and used by your Excel / PDF.</Typography>
      {hasOwn && <Button size="small" onClick={reset} data-testid="viewer-layout-reset">Back to the report&apos;s own layout</Button>}
      {note && <Typography variant="caption" color="text.secondary" data-testid="viewer-layout-note">{note}</Typography>}
    </Stack>
  );
}
