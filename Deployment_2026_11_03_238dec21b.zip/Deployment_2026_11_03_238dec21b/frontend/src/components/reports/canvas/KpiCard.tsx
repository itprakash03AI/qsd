/**
 * KpiCard -- what a number tile DRAWS (2026-11-02): an icon, the big value, its
 * label, and the change line against a previous value ("▲ 1,234 (+9.1%) vs
 * 30-Oct-2026", green when good, red when bad by `good_when`; "No previous value"
 * when the comparison cannot be computed), on a plain / filled / gradient card in
 * the theme's colours, with an optional sparkline.  Pure presentation: the
 * numbers come from CanvasTileView (the cube) or CompareTile (the two dates).
 */
import React from 'react';
import { Box, Typography } from '@mui/material';
import { appColour, kpiGradient, type ReportTheme } from './canvasTheme';
import { changeText, type KpiChange, type KpiIcon, type KpiLook } from './canvasKpi';
import { KpiIconPicture } from './kpiIcons';

export interface KpiCardProps {
  /** the value as shown ("7.63M", "No value", "No rows") and whether it is a real number */
  valueText: string;
  muted?: boolean;
  label: string;
  /** the comparison, when the tile has one: the change and the words after it */
  change?: KpiChange | null;
  previousWords?: string;
  previousText?: string;
  look: KpiLook;
  theme: ReportTheme;
  icon?: KpiIcon | null;
  /** the sparkline's points (the value by an ordered column), oldest first */
  spark?: (number | null)[] | null;
  width: number;
  height: number;
  fmtAbs: (v: number) => string;
  /** a red negative value (the tile format) */
  valueSx?: any;
}

export function sparkPath(points: (number | null)[], w: number, h: number): string {
  const ys = points.filter((p): p is number => p !== null && Number.isFinite(p));
  if (ys.length < 2) return '';
  const lo = Math.min(...ys), hi = Math.max(...ys);
  const span = hi - lo || 1;
  const n = points.length;
  return points.map((p, i) => (p === null || !Number.isFinite(p) ? null : `${(i * w / Math.max(1, n - 1)).toFixed(1)},${(h - 1 - (p - lo) / span * (h - 2)).toFixed(1)}`))
    .filter(Boolean).join(' ');
}

export default function KpiCard(p: KpiCardProps) {
  const { look, theme } = p;
  const filled = look.style === 'filled' || look.style === 'gradient';
  const fg = filled ? look.value_fg : appColour(theme.card.fg, true);
  const labelFg = filled ? look.label_fg : appColour(theme.card.title_fg, true);
  const words = changeText(p.change, p.fmtAbs, p.previousWords ?? '');
  const good = p.change?.good;
  const changeFg = filled ? look.value_fg : good === true ? look.up_fg : good === false ? look.down_fg : labelFg;
  const extra = (words ? 1 : 0) + (p.spark && p.spark.length >= 2 ? 1 : 0);
  // the number FITS its card: the font follows the width and the length
  const byWidth = (p.width - 16 - (p.icon ? 34 : 0)) / Math.max(4, p.valueText.length * 0.62);
  const size = Math.max(14, Math.min(44, (p.height - extra * 18) / 3, byWidth));
  const sparkW = Math.max(40, p.width - 16), sparkH = 22;
  return (
    <Box data-testid="kpi-card" data-kpi-style={look.style} data-good={good === null || good === undefined ? undefined : String(good)}
      sx={{ height: '100%', display: 'flex', gap: 1, alignItems: 'flex-start', borderRadius: `${theme.tiles.radius}px`,
            ...(filled ? { background: look.style === 'gradient' ? kpiGradient(look.fill) : look.fill, color: look.value_fg, p: 1, m: -0.5 } : {}) }}>
      {p.icon && (
        <Box data-testid="kpi-icon" sx={{ flexShrink: 0, width: 34, height: 34, borderRadius: 1.5, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  bgcolor: filled ? 'rgba(255,255,255,0.18)' : `${look.fill}22` }}>
          <KpiIconPicture icon={p.icon} color={filled ? look.value_fg : look.fill} />
        </Box>
      )}
      <Box sx={{ minWidth: 0, flex: 1 }}>
        <Typography title={p.valueText} noWrap data-testid="kpi-value"
          sx={{ fontSize: size, fontWeight: 700, lineHeight: 1.1, color: p.muted ? (filled ? look.value_fg : 'text.secondary') : fg, opacity: p.muted ? 0.8 : 1, ...(filled ? {} : (p.valueSx ?? {})) }}>
          {p.valueText}
        </Typography>
        <Typography variant="caption" data-testid="kpi-label" sx={{ color: labelFg, opacity: filled ? 0.9 : 1, display: 'block' }} noWrap>{p.label}</Typography>
        {words && (
          <Typography variant="body2" data-testid="kpi-change" sx={{ color: changeFg, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}
            title={p.previousText ? `Previous value: ${p.previousText}` : undefined}>
            {words}
          </Typography>
        )}
        {p.spark && p.spark.length >= 2 && (
          <svg width={sparkW} height={sparkH} viewBox={`0 0 ${sparkW} ${sparkH}`} data-testid="kpi-spark" style={{ display: 'block', marginTop: 2 }}>
            <polyline points={sparkPath(p.spark, sparkW, sparkH)} fill="none" stroke={filled ? look.value_fg : look.fill} strokeWidth={1.5} />
          </svg>
        )}
      </Box>
    </Box>
  );
}
