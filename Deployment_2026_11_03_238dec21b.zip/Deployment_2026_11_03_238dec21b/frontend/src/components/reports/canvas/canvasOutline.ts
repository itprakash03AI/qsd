/**
 * The canvas OUTLINE tile, the header BAND tile, number formats and the
 * report code (2026-10-30; plan docs/REPORT_OUTLINE_AND_DETAIL_LINKS_2026_10_30.html
 * sections 1-3).  The same rules as backend/core/reports/canvas_outline.py.
 *
 *   outline  {kind:'outline', levels:[column ids, top first], measures,
 *             totals:{levels:[on/off per level], grand, labels:{"<i>"|"grand": text}},
 *             open_level (1 = only the top level shows)}
 *   band     {kind:'band', parameters?:[names]} -- the run's chosen values
 *   any tile formats:{"<column id>": {decimals, thousands, negative, zero}}
 *   canvas   report_code -- shown top right of the band
 *
 * Every row of an outline is a cube drill over the report's ONE stored,
 * row-secured result -- opening a row never asks the source again.  A total
 * row is the parent's own group, so it equals the sum of its children.
 */
import type { Aggregation, CanvasColumn, CanvasTile, ReportCanvas } from './canvasModel';
import { emitsAggregate, isMeasureColumn } from './canvasModel';

export type NegativeStyle = 'minus' | 'brackets' | 'red_brackets';
export type ZeroStyle = 'show' | 'blank';
export type RuleOp = 'eq' | 'ne' | 'gt' | 'lt' | 'ge' | 'le' | 'between';
export type RuleColor = 'amber' | 'red' | 'green' | 'blue';
/** A colour rule: "Unexplained <> 0 -> amber" (the server's canvas_outline.rule_color, the same answer). */
export interface ColorRule { op: RuleOp; value: number | string; value2?: number | string | null; color: RuleColor }
export interface TileFormat {
  decimals?: number; thousands?: boolean; negative?: NegativeStyle; zero?: ZeroStyle;
  /** colour rules, the first that holds colours the cell's background */
  rules?: ColorRule[];
  /** colour by value (2026-11-02): the cell's background between two colours by where its value sits
   *  between the tile's smallest and largest shown value */
  scale?: { low: string; high: string };
  /** a value above zero in the theme's 'up' colour, below zero in its 'down' colour */
  sign_colour?: boolean;
}
/** The server's SIGN_UP / SIGN_DOWN when no theme is on the page. */
export const SIGN_UP = '#1a7f4b';
export const SIGN_DOWN = '#c62828';
export const RULE_OPS: RuleOp[] = ['eq', 'ne', 'gt', 'lt', 'ge', 'le', 'between'];
export const RULE_OP_LABEL: Record<RuleOp, string> = {
  eq: 'is equal to', ne: 'is not equal to', gt: 'is above', lt: 'is below', ge: 'is at least', le: 'is at most',
  between: 'is between',
};
/** the cell backgrounds -- the SAME hexes as canvas_outline.RULE_FILLS (Excel / PDF) */
export const RULE_FILLS: Record<RuleColor, string> = { amber: '#FFE0A3', red: '#F8D0D0', green: '#D5F0DC', blue: '#D6E6FB' };
export const RULE_COLOR_LABEL: Record<RuleColor, string> = { amber: 'Amber', red: 'Red', green: 'Green', blue: 'Blue' };
export const MAX_RULES = 20;
export interface OutlineTotals { levels?: boolean[]; grand?: boolean; labels?: Record<string, string> }
/** The fields the outline / band tiles and the formats add to a tile. */
export interface OutlineTileFields {
  levels?: number[];
  totals?: OutlineTotals;
  open_level?: number;
  formats?: Record<string, TileFormat>;
  /** band: the parameters it shows, in order (none = every one) */
  parameters?: string[];
  /** band (2026-11-02): the dropdown / period parameters drawn as CHIPS (their choices in a row, at most MAX_CHIP_CHOICES) */
  chips?: string[];
  /** a pie / donut / treemap: fold the rest into "Everything else" (default) or show the top N only */
  other_mode?: 'fold' | 'none';
  /** the most of the picture "Everything else" may take (0.05..0.9; default 0.25) */
  other_max_share?: number;
  /** bars coloured by sign (green above zero, red below) -- set by the pie / treemap fallback for a signed amount */
  sign_bars?: boolean;
  /** 2026-11-01 (FD-08): a trend over the date column, driven by a PERIOD parameter (its name) */
  trend_of?: string;
}

export const NEGATIVE_LABEL: Record<NegativeStyle, string> = {
  minus: '-1,234', brackets: '(1,234)', red_brackets: '(1,234) in red',
};
export const MAX_DECIMALS = 10;
export const MAX_LABEL = 100;
export const MAX_REPORT_CODE = 40;
export const MAX_BAND_PARAMETERS = 50;
/** a parameter with more choices than this keeps its cell (the server's canvas_outline.MAX_CHIP_CHOICES) */
export const MAX_CHIP_CHOICES = 8;
/** a level the viewer reads at once; more are said on the tile */
export const OUTLINE_PAGE = 2000;

const isInt = (v: any) => typeof v === 'number' && Number.isInteger(v);

/** Keep the new fields of a stored tile (readCanvas would drop them). */
export function readOutlineFields(t: any): OutlineTileFields {
  const out: OutlineTileFields = {};
  if (Array.isArray(t?.levels)) out.levels = t.levels.map(Number);
  if (t?.totals && typeof t.totals === 'object') {
    out.totals = {
      ...(Array.isArray(t.totals.levels) ? { levels: t.totals.levels.map((x: any) => x === true) } : {}),
      ...(t.totals.grand != null ? { grand: t.totals.grand === true } : {}),
      ...(t.totals.labels && typeof t.totals.labels === 'object' ? { labels: { ...t.totals.labels } } : {}),
    };
  }
  if (t?.open_level != null) out.open_level = Number(t.open_level);
  if (t?.formats && typeof t.formats === 'object') out.formats = { ...t.formats };
  if (Array.isArray(t?.parameters)) out.parameters = t.parameters.map(String);
  if (Array.isArray(t?.chips)) out.chips = t.chips.map(String);
  // (rig 2026-11-01) a part-of-a-whole chart's remainder: folded into "Everything else" or not,
  // and how much of the picture it may take
  if (t?.other_mode === 'fold' || t?.other_mode === 'none') out.other_mode = t.other_mode;
  if (typeof t?.other_max_share === 'number') out.other_max_share = t.other_max_share;
  if (typeof t?.trend_of === 'string' && t.trend_of) out.trend_of = t.trend_of;
  return out;
}

/** The canvas-level fields (the report code, the comparison), kept when a canvas is read. */
export function readCanvasExtras(c: any): Pick<ReportCanvas, 'report_code' | 'compare'> {
  return {
    ...(typeof c?.report_code === 'string' && c.report_code ? { report_code: c.report_code } : {}),
    ...(c?.compare && typeof c.compare === 'object' && typeof c.compare.parameter === 'string' ? { compare: { parameter: c.compare.parameter } } : {}),
  };
}

// ── number formats: the same words as the server's ───────────────────────

export function formatProblems(f: any): string[] {
  if (!f || typeof f !== 'object' || Array.isArray(f)) return ['a number format must say its decimals, thousands, negatives and zero.'];
  const out: string[] = [];
  const unknown = Object.keys(f).filter(k => !['decimals', 'thousands', 'negative', 'zero', 'rules', 'scale', 'sign_colour'].includes(k)).sort();
  if (unknown.length) out.push(`a number format has settings it does not know: ${unknown.join(', ')}.`);
  if (f.decimals != null && (!isInt(f.decimals) || f.decimals < 0 || f.decimals > MAX_DECIMALS)) out.push(`decimals must be a whole number from 0 to ${MAX_DECIMALS}.`);
  if (f.thousands != null && typeof f.thousands !== 'boolean') out.push('the thousands separator is either on or off.');
  if (f.negative != null && !['minus', 'brackets', 'red_brackets'].includes(f.negative)) out.push('negatives show with a minus, in brackets, or red in brackets.');
  if (f.zero != null && !['show', 'blank'].includes(f.zero)) out.push('a zero is either shown or left blank.');
  out.push(...ruleProblems(f.rules));
  if (f.scale != null) {
    const sc = f.scale;
    const hex = (v: any) => typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v);
    if (!sc || typeof sc !== 'object' || Array.isArray(sc) || !hex(sc.low) || !hex(sc.high) || Object.keys(sc).some(k => k !== 'low' && k !== 'high')) {
      out.push('a colour scale names its two colours, low and high, like #ffffff and #1e6fd9.');
    }
  }
  if (f.sign_colour != null && typeof f.sign_colour !== 'boolean') out.push('colouring the sign (green above zero, red below) is on or off.');
  return out;
}

/** What is wrong with a column's colour rules -- the server's words. */
export function ruleProblems(rules: any): string[] {
  if (rules == null) return [];
  if (!Array.isArray(rules)) return ['its colour rules must be a list.'];
  if (rules.length > MAX_RULES) return [`a value can have at most ${MAX_RULES} colour rules; this one has ${rules.length}.`];
  const out: string[] = [];
  rules.forEach((r: any, k: number) => {
    const i = k + 1;
    if (!r || typeof r !== 'object' || Array.isArray(r)) { out.push(`colour rule ${i} must say when and which colour.`); return; }
    const unknown = Object.keys(r).filter(x => !['op', 'value', 'value2', 'color'].includes(x)).sort();
    if (unknown.length) out.push(`colour rule ${i} has settings it does not know: ${unknown.join(', ')}.`);
    if (!RULE_OPS.includes(r.op)) out.push(`colour rule ${i}: choose when it applies (equal to, not equal to, above, below, at least, at most, or between).`);
    if (!(r.color in RULE_FILLS)) out.push(`colour rule ${i}: the colour is amber, red, green or blue.`);
    const a = decimalString(r.value);
    if (a == null) out.push(`colour rule ${i}: the value to compare with must be a number.`);
    if (r.op === 'between') {
      const b = decimalString(r.value2);
      if (b == null) out.push(`colour rule ${i}: between needs a second number.`);
      else if (a != null && compareDecimal(b, a) < 0) out.push(`colour rule ${i}: between goes from the smaller number to the larger.`);
    } else if (r.value2 != null) {
      out.push(`colour rule ${i}: only between takes a second number.`);
    }
  });
  return out;
}

/** Compare two exact decimal strings (-1 / 0 / 1) -- never through a float. */
export function compareDecimal(a: string, b: string): number {
  const norm = (s: string) => {
    const neg = s.startsWith('-');
    const [ip, fp = ''] = (neg ? s.slice(1) : s).split('.');
    const int = ip.replace(/^0+(?=\d)/, '');
    const frac = fp.replace(/0+$/, '');
    const zero = /^0*$/.test(int + frac);
    return { neg: neg && !zero, int, frac, zero };
  };
  const x = norm(a); const y = norm(b);
  if (x.neg !== y.neg) return x.neg ? -1 : 1;
  const sign = x.neg ? -1 : 1;
  if (x.int.length !== y.int.length) return (x.int.length > y.int.length ? 1 : -1) * sign;
  if (x.int !== y.int) return (x.int > y.int ? 1 : -1) * sign;
  const n = Math.max(x.frac.length, y.frac.length);
  const fx = x.frac.padEnd(n, '0'); const fy = y.frac.padEnd(n, '0');
  if (fx === fy) return 0;
  return (fx > fy ? 1 : -1) * sign;
}

/** The colour of the first rule a value meets (null = none, or no number).  The value as stored, not as rounded. */
export function ruleColor(v: any, f?: TileFormat | null): RuleColor | null {
  const rules = f?.rules;
  if (!rules || !rules.length) return null;
  const d = decimalString(v);
  if (d == null) return null;
  for (const r of rules) {
    const a = decimalString(r?.value);
    if (a == null) continue;
    let hit = false;
    if (r.op === 'between') {
      const b = decimalString(r.value2);
      hit = b != null && compareDecimal(d, a) >= 0 && compareDecimal(d, b) <= 0;
    } else {
      const c = compareDecimal(d, a);
      hit = r.op === 'eq' ? c === 0 : r.op === 'ne' ? c !== 0 : r.op === 'gt' ? c > 0
        : r.op === 'lt' ? c < 0 : r.op === 'ge' ? c >= 0 : r.op === 'le' ? c <= 0 : false;
    }
    if (hit && r.color in RULE_FILLS) return r.color;
  }
  return null;
}

/** MUI style for a cell a colour rule colours (undefined = none). */
export const ruleSx = (v: any, c?: CanvasColumn | null) => {
  const color = ruleColor(v, c?.tile_format);
  return color ? { bgcolor: RULE_FILLS[color] } : undefined;
};

/** `low` mixed towards `high` by `f` (0..1) -- the server's mix_hex (six hex digits, '#'). */
export function mixHex(low: string, high: string, f: number): string {
  const t = Math.max(0, Math.min(1, f));
  const a = low.replace('#', ''), b = high.replace('#', '');
  return '#' + [0, 2, 4].map(i => { const x = parseInt(a.slice(i, i + 2), 16), y = parseInt(b.slice(i, i + 2), 16); return Math.round(x + (y - x) * t).toString(16).padStart(2, '0'); }).join('');
}

/** The smallest and largest number among `values` (null = none). */
export function scaleStats(values: any[]): { min: number; max: number } | null {
  let min = Infinity, max = -Infinity;
  for (const v of values) { const d = decimalString(v); if (d == null) continue; const n = Number(d); if (n < min) min = n; if (n > max) max = n; }
  return min === Infinity ? null : { min, max };
}

/** The background of a scaled cell (undefined = no scale / no number / no range). */
export function scaleColour(v: any, f?: TileFormat | null, stats?: { min: number; max: number } | null): string | undefined {
  const sc = f?.scale;
  if (!sc || !stats) return undefined;
  const d = decimalString(v);
  if (d == null) return undefined;
  const n = Number(d);
  return mixHex(sc.low, sc.high, stats.max === stats.min ? 0 : (n - stats.min) / (stats.max - stats.min));
}

/** The text colour of a signed value: 'up' above zero, 'down' below (undefined = none). */
export function signColour(v: any, f?: TileFormat | null, colours?: { up: string; down: string }): string | undefined {
  if (!f?.sign_colour) return undefined;
  const d = decimalString(v);
  if (d == null || compareDecimal(d, '0') === 0) return undefined;
  return compareDecimal(d, '0') > 0 ? (colours?.up ?? SIGN_UP) : (colours?.down ?? SIGN_DOWN);
}

/** ONE style for a value cell: the rule's fill, else the scale's colour; the sign's colour, else a red negative. */
export function valueSx(v: any, c?: CanvasColumn | null, stats?: { min: number; max: number } | null, colours?: { up: string; down: string }) {
  const f = c?.tile_format;
  const out: any = {};
  const rule = ruleColor(v, f);
  const bg = rule ? RULE_FILLS[rule] : scaleColour(v, f, stats);
  if (bg) out.bgcolor = bg;
  const sign = signColour(v, f, colours);
  if (sign) out.color = sign;
  else if (isRedNegative(v, f)) out.color = 'error.main';
  return Object.keys(out).length ? out : undefined;
}

/** A number as an exact decimal string (no float drift), or null. */
export function decimalString(v: any): string | null {
  if (v === null || v === undefined || typeof v === 'boolean' || v === '') return null;
  let s: string;
  if (typeof v === 'number') {
    if (!Number.isFinite(v)) return null;
    s = String(v);
    if (/e/i.test(s)) s = v.toFixed(20).replace(/\.?0+$/, '');
  } else {
    s = String(v).trim();
  }
  return /^-?\d+(\.\d+)?$/.test(s) ? s : null;
}

/** Round a decimal string half up (away from zero) to ``d`` places. */
function roundHalfUp(s: string, d: number): { neg: boolean; int: string; frac: string } {
  const neg = s.startsWith('-');
  const [ip, fp = ''] = (neg ? s.slice(1) : s).split('.');
  const digits = (ip + (fp + '0'.repeat(d + 1)).slice(0, d + 1)).split('').map(Number);
  const up = digits.pop()! >= 5;
  if (up) {
    let i = digits.length - 1;
    while (i >= 0) { if (digits[i] === 9) { digits[i] = 0; i--; } else { digits[i]++; break; } }
    if (i < 0) digits.unshift(1);
  }
  const all = digits.join('');
  const int = (all.slice(0, all.length - d) || '0').replace(/^0+(?=\d)/, '');
  return { neg, int, frac: d ? all.slice(all.length - d) : '' };
}

/** The words for a number in a tile format (null = not a number). */
export function formatNumber(v: any, f: TileFormat): string | null {
  const s = decimalString(v);
  if (s == null) return null;
  const d = f.decimals ?? 2;
  const r = roundHalfUp(s, d);
  const zero = /^0*$/.test(r.int + r.frac);
  if (zero && f.zero === 'blank') return '';
  const grouped = f.thousands === false ? r.int : r.int.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  const body = d ? `${grouped}.${r.frac}` : grouped;
  if (!r.neg || zero) return body;
  return f.negative === 'brackets' || f.negative === 'red_brackets' ? `(${body})` : `-${body}`;
}

/** Is this value shown red (red brackets and below zero once rounded)? */
export function isRedNegative(v: any, f?: TileFormat | null): boolean {
  if (!f || f.negative !== 'red_brackets') return false;
  const s = decimalString(v);
  if (s == null) return false;
  const r = roundHalfUp(s, f.decimals ?? 2);
  return r.neg && !/^0*$/.test(r.int + r.frac);
}

/** The tile's columns, each carrying the tile's own format when it has one. */
export function withTileFormats(tile: CanvasTile, cols: Map<number, CanvasColumn>): Map<number, CanvasColumn> {
  const fmts = tile.formats;
  if (!fmts || Object.keys(fmts).length === 0) return cols;
  const out = new Map(cols);
  for (const [k, f] of Object.entries(fmts)) {
    const c = cols.get(Number(k));
    if (c && formatProblems(f).length === 0) out.set(c.id, { ...c, tile_format: f });
  }
  return out;
}

/** MUI style for a red negative (undefined = none). */
export const negativeSx = (v: any, c?: CanvasColumn | null) =>
  (isRedNegative(v, c?.tile_format) ? { color: 'error.main' } : undefined);

// ── save-time checks (the server's rules) ────────────────────────────────

export function outlineProblems(canvas: ReportCanvas, cols: Map<number, CanvasColumn>, selected: Set<number> | null,
                                grouped: boolean, say: (t: CanvasTile | null, message: string) => void): void {
  const code = canvas.report_code;
  if (code != null && (typeof code !== 'string' || code.length > MAX_REPORT_CODE || /[\x00-\x1f\x7f]/.test(code))) {
    say(null, `The report code is text of at most ${MAX_REPORT_CODE} characters.`);
  }
  const label = (id: number) => cols.get(id)?.label ?? `column #${id}`;
  for (const t of canvas.tiles) {
    if (t.formats != null) {
      if (t.kind === 'report') {
        say(t, "the report's own table keeps the number formats of its columns (set them on the dataset); number formats here apply to the other tiles.");
      } else {
        for (const [k, f] of Object.entries(t.formats)) {
          const id = Number(k);
          if (!cols.has(id)) { say(t, `it has a number format for a field that is not in the data (column #${k}).`); continue; }
          for (const p of formatProblems(f)) say(t, `${label(id)}: ${p}`);
        }
      }
    }
    if (t.kind === 'outline') {
      const levels = t.levels ?? [];
      if (levels.length === 0) { say(t, 'an outline needs at least one level (the field its rows are grouped by).'); continue; }
      const measureIds = new Set(t.measures.map(m => m.column_id));
      for (const id of levels) {
        const c = cols.get(id);
        if (!c) { say(t, `a level is a field that is no longer in the data (column #${id}). Remove it from the outline.`); continue; }
        if (selected && !selected.has(id)) say(t, `${c.label} is not one of the report's columns, so the report does not return it. Add it to the report.`);
        if (measureIds.has(id)) say(t, `${c.label} is both a level and a value.`);
        if (grouped && emitsAggregate(c)) say(t, `${c.label} is added up in this report's rows, so it cannot be a level.`);
      }
      if (new Set(levels).size !== levels.length) say(t, 'the same field is a level twice.');
      if (t.dimensions.length > 0 || t.series != null) say(t, 'an outline takes its fields as levels and values only.');
      if (t.measures.length === 0) say(t, 'an outline needs at least one value to show.');
      const n = levels.length;
      if (t.open_level != null && (!isInt(t.open_level) || t.open_level < 1 || t.open_level > n)) say(t, `it opens to a level from 1 to ${n}.`);
      const tl = t.totals?.levels;
      if (tl != null && tl.length > n) say(t, `its totals say on or off for each of its ${n} levels.`);
      for (const [k, v] of Object.entries(t.totals?.labels ?? {})) {
        const ki = Number(k);
        if (!(k === 'grand' || (String(ki) === k && ki >= 0 && ki < n))) say(t, `a total is named for a level it does not have ("${k}").`);
        else if (typeof v !== 'string' || v.length > MAX_LABEL) say(t, `the name of a total is text of at most ${MAX_LABEL} characters.`);
      }
    } else if (t.kind === 'band') {
      if (t.dimensions.length || t.measures.length || t.series != null) say(t, "the band shows the report's chosen values; it takes no fields.");
      const ps = t.parameters;
      if (ps && ps.length > MAX_BAND_PARAMETERS) say(t, `the band lists up to ${MAX_BAND_PARAMETERS} parameters by name.`);
      else if (ps && new Set(ps).size !== ps.length) say(t, 'the band lists a parameter twice.');
      const ch: any = t.chips;
      if (ch != null && (!Array.isArray(ch) || ch.length > MAX_BAND_PARAMETERS || !ch.every((c: any) => typeof c === 'string' && c.length > 0 && c.length <= 200))) {
        say(t, `the band's chips are up to ${MAX_BAND_PARAMETERS} parameter names (a dropdown or a period with at most ${MAX_CHIP_CHOICES} choices).`);
      } else if (ch && new Set(ch).size !== ch.length) say(t, 'the band names a parameter twice as chips.');
    }
  }
}

/** A field dropped on an outline: a measure becomes a value, anything else the next level. */
export function addFieldToOutline(t: CanvasTile, col: CanvasColumn, aggregation: Aggregation): CanvasTile {
  const levels = t.levels ?? [];
  if (levels.includes(col.id) || t.measures.some(m => m.column_id === col.id)) return t;
  if (isMeasureColumn(col)) return { ...t, measures: [...t.measures, { column_id: col.id, aggregation }] };
  return { ...t, levels: [...levels, col.id] };
}

/** The fields a new tile of these kinds starts with. */
export function newOutlineFields(kind: string): OutlineTileFields {
  if (kind === 'outline') return { levels: [], totals: { levels: [], grand: true }, open_level: 1 };
  return {};
}

// ── the outline's rows: one reading for the viewer ────────────────────────

export const pathKey = (path: any[]) => JSON.stringify(path);

export function totalLabel(t: CanvasTile, level: number, cols: Map<number, CanvasColumn>): string {
  const own = t.totals?.labels?.[String(level)];
  if (own && own.trim()) return own.trim();
  const id = (t.levels ?? [])[level];
  return `${cols.get(id)?.label ?? `column #${id}`} Total`;
}

export function grandLabel(t: CanvasTile): string {
  const own = t.totals?.labels?.grand;
  return own && own.trim() ? own.trim() : 'Grand Total';
}

export const openLevelOf = (t: CanvasTile) =>
  Math.min(Math.max(isInt(t.open_level) ? t.open_level! : 1, 1), Math.max(1, (t.levels ?? []).length));

export interface OutlineLine {
  kind: 'row' | 'total' | 'grand' | 'loading' | 'more';
  key: string;
  level: number;
  /** the level's value (row) or the total's words (total / grand) */
  value: any;
  /** the values shown on the line; null = shown on its total row */
  values: any[] | null;
  open: boolean;
  canOpen: boolean;
  path: any[];
  /** 'more': rows read / rows there are */
  shown?: number;
  total?: number;
}

export interface OutlineBranch { rows: any[]; total: number }

/**
 * The lines of an outline: its open rows' children under them, a total row
 * under an open row whose level has its total on (that row then shows its
 * values there), the grand total last.  ``branches`` maps a parent path
 * (pathKey) to the cube rows of its children.
 */
export function outlineLines(t: CanvasTile, levelNames: string[], branches: Map<string, OutlineBranch>,
                             expanded: Set<string>, grand: any | null, cols: Map<number, CanvasColumn>): OutlineLine[] {
  const n = levelNames.length;
  const totalsOn = (t.totals?.levels ?? []).map(Boolean);
  const vals = (r: any) => t.measures.map((_, i) => r[`v${i}__`]);
  const out: OutlineLine[] = [];
  const walk = (path: any[], k: number) => {
    const b = branches.get(pathKey(path));
    if (!b) { out.push({ kind: 'loading', key: `${pathKey(path)}#loading`, level: k, value: null, values: null, open: false, canOpen: false, path }); return; }
    for (const r of b.rows) {
      const p = [...path, r[levelNames[k]]];
      const key = pathKey(p);
      const canOpen = k + 1 < n;
      const open = canOpen && expanded.has(key);
      const totalRow = open && !!totalsOn[k];
      out.push({ kind: 'row', key, level: k, value: r[levelNames[k]], values: totalRow ? null : vals(r), open, canOpen, path: p });
      if (open) {
        walk(p, k + 1);
        if (totalRow) out.push({ kind: 'total', key: `${key}#total`, level: k, value: totalLabel(t, k, cols), values: vals(r), open: false, canOpen: false, path: p });
      }
    }
    if (b.total > b.rows.length) {
      out.push({ kind: 'more', key: `${pathKey(path)}#more`, level: k, value: null, values: null, open: false, canOpen: false, path, shown: b.rows.length, total: b.total });
    }
  };
  walk([], 0);
  if (grand && t.totals?.grand) out.push({ kind: 'grand', key: '#grand', level: 0, value: grandLabel(t), values: vals(grand), open: false, canOpen: false, path: [] });
  return out;
}

/** Group one level's cube rows (dims = the first k+1 levels) by their parent path. */
export function branchesOfLevel(rows: any[], levelNames: string[], k: number): Map<string, any[]> {
  const out = new Map<string, any[]>();
  for (const r of rows) {
    const key = pathKey(levelNames.slice(0, k).map(c => r[c]));
    if (!out.has(key)) out.set(key, []);
    out.get(key)!.push(r);
  }
  return out;
}
