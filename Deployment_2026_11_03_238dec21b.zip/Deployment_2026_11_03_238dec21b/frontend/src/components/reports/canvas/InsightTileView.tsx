/**
 * One insight tile of the report canvas (2026-10-30) -- see canvasInsights.ts.
 *
 * Every number is the server's, computed over the run's stored, row-secured
 * result (cube operation 'insight'); the tile shows it, never recomputes it.
 * Each tile says in words what A and B are, the rule it used, and what it
 * cannot show (one date only, no earlier run, a value that is not added up).
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Breadcrumbs, CircularProgress, Link, Table, TableBody, TableCell, TableHead, TableRow, Typography,
} from '@mui/material';
import { CartesianGrid, Line, LineChart, Tooltip as ReTooltip, XAxis, YAxis } from 'recharts';
import api from '../../../services/api';
import { applyFormatPattern } from '../../../utils/formatters';
import type { CanvasColumn, CanvasTile } from './canvasModel';
import { insightCubeBody, insightErrorWords, insightTitle, InsightPathStep } from './canvasInsights';
import { publishTileFacts } from './canvasTileFacts';
import { clickableRow } from '../../../utils/clickable';
import { lttbIndices } from './canvasRender/lttb';
import { maxPointsFor } from './canvasRender/drawingLadder';

/** The anomaly chart's width (px). */
const ANOMALY_CHART_W = 520;

/**
 * The points the anomaly CHART draws (2026-10-30 integration, the fast-drawing
 * road where it fits): at most about one per pixel, chosen by LTTB (the same
 * choices as the server's core/reports/lttb.py) -- and EVERY unusual point
 * kept, so no flagged value ever disappears from the picture.  Only the
 * picture: the sentence, the flagged table and every amount stay the server's
 * exact (Decimal) answer, read as JSON -- an insight never takes the Arrow
 * road (float64).
 */
export function anomalyChartPoints<T extends { v: number; flag?: any }>(points: T[], widthPx = ANOMALY_CHART_W): T[] {
  const max = maxPointsFor(widthPx);
  if (points.length <= max) return points;
  const keep = new Set(lttbIndices(points.map(p => p.v), max));
  points.forEach((p, i) => { if (p.flag) keep.add(i); });
  return [...keep].sort((a, b) => a - b).map(i => points[i]);
}

type CubeFetch = (reportId: number, executionId: string, body: any) => Promise<any>;

interface Props {
  tile: CanvasTile;
  reportId: number | null;
  cols: Map<number, CanvasColumn>;
  run: { executionId: string | null; truncated?: boolean; rowLimit?: number | null };
  cubeFetch?: CubeFetch;
  /** linked tiles (canvasLinks): the clicked values, applied to this tile too */
  linkFilters?: { column: string; value: any }[];
  /** linked tiles: changes whenever the clicks a `cubeFetch` applies change (CanvasTileView) */
  linkKey?: string;
  /** the builder: the preview ran without some of this tile's fields */
  stale?: boolean;
}

const UP = '#2e7d32';
const DOWN = '#c62828';

/** An amount in the value's own format, else a readable number. */
export function amountWords(v: any, c?: CanvasColumn | null): string {
  if (v === null || v === undefined) return '(no value)';
  if (c?.format_pattern) {
    const f = applyFormatPattern(v, c.format_pattern, c.data_type || undefined);
    if (f != null) return f;
  }
  const n = typeof v === 'number' ? v : Number(v);
  if (!Number.isFinite(n)) return String(v);
  return n.toLocaleString(undefined, { maximumFractionDigits: 2, minimumFractionDigits: Number.isInteger(n) ? 0 : 2 });
}
const signed = (v: any, c?: CanvasColumn | null) => {
  const n = Number(v);
  return (n > 0 ? '+' : '') + amountWords(v, c);
};
const pct = (p: any) => (p === null || p === undefined ? '' : `${Number(p).toFixed(2)}%`);
const tone = (v: any) => (Number(v) > 0 ? UP : Number(v) < 0 ? DOWN : undefined);

export default function InsightTileView({ tile, reportId, cols, run, cubeFetch, linkFilters, linkKey, stale }: Props) {
  const cube = cubeFetch ?? ((r: number, e: string, b: any) => api.queryReportCube(r, e, b));
  const [path, setPath] = useState<InsightPathStep[]>([]);
  const [state, setState] = useState<{ loading: boolean; error: string; data: any }>({ loading: false, error: '', data: null });
  const ins = tile.insight;
  const key = JSON.stringify([ins, run.executionId, path, linkFilters ?? [], linkKey ?? '']);
  useEffect(() => { setPath([]); }, [run.executionId, JSON.stringify(ins)]);  // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!ins || !reportId || !run.executionId || stale) { setState({ loading: false, error: '', data: null }); return; }
    let cancelled = false;
    setState(s => ({ ...s, loading: true, error: '' }));
    cube(reportId, run.executionId, insightCubeBody(ins, path, linkFilters ?? []))
      .then(data => { if (!cancelled) { setState({ loading: false, error: '', data }); publishTileFacts(run.executionId, tile, data); } })
      .catch(err => { if (!cancelled) setState({ loading: false, error: insightErrorWords(err), data: null }); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, reportId, stale]);

  const title = insightTitle(tile, cols);
  const mcol = ins?.measure ? cols.get(ins.measure.column_id) : null;
  const { loading, error, data } = state;

  let body: React.ReactNode = null;
  if (stale && run.executionId) {
    body = <Typography variant="body2" color="text.secondary" data-testid="tile-stale">Press Preview again to see this insight.</Typography>;
  } else if (!ins) {
    body = <Typography variant="body2" color="text.secondary">Choose what this insight shows.</Typography>;
  } else if (!run.executionId) {
    body = <Typography variant="body2" color="text.secondary" data-testid="tile-not-run">Run the report to see this.</Typography>;
  } else if (error) {
    body = <Alert severity="info" data-testid="insight-refused" sx={{ py: 0 }}>{error}</Alert>;
  } else if (loading && !data) {
    body = <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}><CircularProgress size={20} /></Box>;
  } else if (data) {
    body = renderBody();
  }

  function sentence() {
    // 2026-11-01 -- a story the assistant wrote FROM these numbers (grounded on the
    // server; backend core/reports/insight_story.py), else the standard sentence + why
    const story = data.story;
    if (story && story.source === 'assistant' && story.text) {
      return (
        <Box sx={{ mb: 0.75 }} data-testid="insight-story">
          <Typography variant="body2">{story.text}</Typography>
          <Typography variant="caption" color="text.secondary">Written by the QueryStudio assistant from these numbers.</Typography>
        </Box>
      );
    }
    return (
      <Box sx={{ mb: 0.75 }}>
        <Typography variant="body2" data-testid="insight-sentence">{data.sentence}</Typography>
        {story?.reason && <Typography variant="caption" color="text.secondary" data-testid="insight-story-reason">{story.reason}</Typography>}
      </Box>
    );
  }
  function basisLine() {
    return data.basis ? (
      <Typography variant="caption" color="text.secondary" component="div" data-testid="insight-basis">{data.basis.words}</Typography>
    ) : null;
  }
  function notes() {
    return (data.notes || []).map((n: string, i: number) => (
      <Typography key={i} variant="caption" color="text.secondary" component="div">{n}</Typography>
    ));
  }

  function renderBody(): React.ReactNode {
    const kind = data.kind;
    if (kind === 'explain_change') {
      const b = data.basis;
      return (
        <Box data-testid="insight-explain">
          {sentence()}
          {data.sections.map((s: any) => (
            <Table key={s.column_id} size="small" sx={{ mb: 1 }}>
              <TableHead><TableRow>
                <TableCell>{s.field}</TableCell>
                <TableCell align="right">{b.a_words}</TableCell>
                <TableCell align="right">{b.b_words}</TableCell>
                <TableCell align="right">Change</TableCell>
                <TableCell align="right">% of the change</TableCell>
              </TableRow></TableHead>
              <TableBody>
                {[...s.members, ...(s.rest ? [s.rest] : [])].map((m: any, i: number) => (
                  <TableRow key={i} data-testid="insight-member">
                    <TableCell>{m.label}{m.count ? ` (${m.count})` : ''}</TableCell>
                    <TableCell align="right">{amountWords(m.a, mcol)}</TableCell>
                    <TableCell align="right">{amountWords(m.b, mcol)}</TableCell>
                    <TableCell align="right" sx={{ color: tone(m.change) }}>{signed(m.change, mcol)}</TableCell>
                    <TableCell align="right">{pct(m.share_pct)}</TableCell>
                  </TableRow>
                ))}
                <TableRow sx={{ '& td': { fontWeight: 700 } }}>
                  <TableCell>Total</TableCell>
                  <TableCell align="right">{amountWords(data.total.a, mcol)}</TableCell>
                  <TableCell align="right">{amountWords(data.total.b, mcol)}</TableCell>
                  <TableCell align="right" sx={{ color: tone(data.total.change) }} data-testid="insight-total-change">{signed(data.total.change, mcol)}</TableCell>
                  <TableCell align="right">{Number(data.total.change) !== 0 ? '100.00%' : ''}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          ))}
          {basisLine()}{notes()}
        </Box>
      );
    }
    if (kind === 'top_movers') {
      const b = data.basis;
      const list = (rows: any[], more: number, words: string, testid: string) => (
        <Box sx={{ mb: 1 }} data-testid={testid}>
          <Typography variant="caption" sx={{ fontWeight: 600 }}>{words}</Typography>
          {rows.length === 0 ? <Typography variant="body2" color="text.secondary">None.</Typography> : (
            <Table size="small">
              <TableHead><TableRow>
                <TableCell>{data.fields.join(' › ')}</TableCell>
                <TableCell align="right">{b.a_words}</TableCell><TableCell align="right">{b.b_words}</TableCell>
                <TableCell align="right">Change</TableCell><TableCell align="right">% change</TableCell>
              </TableRow></TableHead>
              <TableBody>
                {rows.map((m: any, i: number) => (
                  <TableRow key={i} data-testid="insight-mover">
                    <TableCell>{m.label}{m.new ? ' (new)' : m.gone ? ' (gone)' : ''}</TableCell>
                    <TableCell align="right">{amountWords(m.a, mcol)}</TableCell>
                    <TableCell align="right">{amountWords(m.b, mcol)}</TableCell>
                    <TableCell align="right" sx={{ color: tone(m.change) }}>{signed(m.change, mcol)}</TableCell>
                    <TableCell align="right">{m.change_pct == null ? (m.new ? 'new' : '') : pct(m.change_pct)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
          {more > 0 && <Typography variant="caption" color="text.secondary">{more} more not listed.</Typography>}
        </Box>
      );
      return (
        <Box data-testid="insight-movers">
          {sentence()}
          {list(data.increases, data.increases_more, 'Biggest rises', 'insight-rises')}
          {list(data.decreases, data.decreases_more, 'Biggest falls', 'insight-falls')}
          {basisLine()}{notes()}
        </Box>
      );
    }
    if (kind === 'decomposition') {
      return (
        <Box data-testid="insight-decomposition">
          {sentence()}
          {path.length > 0 && (
            <Breadcrumbs sx={{ fontSize: 12, mb: 0.5 }}>
              <Link component="button" onClick={() => setPath([])} data-testid="insight-crumb-0">All</Link>
              {data.path.map((c: any, i: number) => (
                <Link key={i} component="button" onClick={() => setPath(path.slice(0, i + 1))}>{c.field}: {c.label}</Link>
              ))}
            </Breadcrumbs>
          )}
          <Table size="small">
            <TableHead><TableRow>
              <TableCell>{data.field}</TableCell>
              <TableCell align="right">{data.measure.words}</TableCell>
              <TableCell align="right">Share</TableCell>
            </TableRow></TableHead>
            <TableBody>
              {data.members.map((m: any, i: number) => (
                <TableRow key={i} hover={data.has_next} data-testid="insight-part"
                  {...(data.has_next ? clickableRow(() => setPath([...path, { column_id: data.column_id, value: m.value }]),
                    { label: `Open ${m.label}` }) : {})}
                  sx={{ cursor: data.has_next ? 'pointer' : undefined }}>
                  <TableCell>{data.has_next ? '⊞ ' : ''}{m.label}</TableCell>
                  <TableCell align="right">{amountWords(m.amount, mcol)}</TableCell>
                  <TableCell align="right">{pct(m.share_pct)}</TableCell>
                </TableRow>
              ))}
              {data.rest && (
                <TableRow><TableCell>{data.rest.label} ({data.rest.count})</TableCell>
                  <TableCell align="right">{amountWords(data.rest.amount, mcol)}</TableCell>
                  <TableCell align="right">{pct(data.rest.share_pct)}</TableCell></TableRow>
              )}
              <TableRow sx={{ '& td': { fontWeight: 700 } }}>
                <TableCell>Total</TableCell>
                <TableCell align="right" data-testid="insight-level-total">{amountWords(data.total, mcol)}</TableCell>
                <TableCell align="right">{Number(data.total) !== 0 ? '100.00%' : ''}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
          {data.has_next && <Typography variant="caption" color="text.secondary">Click a row to open {data.levels[data.level + 1]?.field}.</Typography>}
          {notes()}
        </Box>
      );
    }
    if (kind === 'anomalies') {
      const all = (data.points || []).map((p: any) => ({ ...p, v: Number(p.value) }));
      const points = anomalyChartPoints(all);
      return (
        <Box data-testid="insight-anomalies">
          {sentence()}
          {points.length > 0 && (
            <LineChart width={ANOMALY_CHART_W} height={160} data={points} margin={{ top: 4, right: 8, bottom: 4, left: 8 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="label" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} width={60} />
              <ReTooltip />
              <Line dataKey="v" name={data.measure.words} stroke="#1e6fd9" isAnimationActive={false}
                dot={(p: any) => (
                  <circle key={p.index} cx={p.cx} cy={p.cy} r={p.payload.flag ? 5 : 2.5}
                    fill={p.payload.flag ? DOWN : '#1e6fd9'} className={p.payload.flag ? 'point flagged' : 'point'} />
                )} />
            </LineChart>
          )}
          {points.length < all.length && (
            <Typography variant="caption" color="text.secondary" component="div" data-testid="insight-drawn-from">
              Drawn from {points.length.toLocaleString()} of its {all.length.toLocaleString()} points (every unusual one kept).
            </Typography>
          )}
          {data.flagged.length > 0 && (
            <Table size="small">
              <TableHead><TableRow>
                <TableCell>{data.field}</TableCell><TableCell align="right">{data.measure.words}</TableCell>
                <TableCell align="right">Usual range</TableCell><TableCell>Unusual</TableCell>
              </TableRow></TableHead>
              <TableBody>
                {data.flagged.map((p: any, i: number) => (
                  <TableRow key={i} data-testid="insight-flagged">
                    <TableCell>{p.label}</TableCell>
                    <TableCell align="right">{amountWords(p.value, mcol)}</TableCell>
                    <TableCell align="right">{amountWords(p.low, mcol)} to {amountWords(p.high, mcol)}</TableCell>
                    <TableCell sx={{ color: DOWN }}>{p.flag}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
          <Typography variant="caption" color="text.secondary" component="div" data-testid="insight-rule">{data.rule}</Typography>
          {notes()}
        </Box>
      );
    }
    return (
      <Box data-testid="insight-summary">
        {(data.sentences || []).map((s: string, i: number) => <Typography key={i} variant="body2" sx={{ mb: 0.5 }}>{s}</Typography>)}
        {notes()}
      </Box>
    );
  }

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0 }} data-testid={`tile-${tile.id}`}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
        <Typography variant="subtitle2" noWrap sx={{ flex: 1 }} title={title}>{title}</Typography>
        {loading && data && <CircularProgress size={12} />}
      </Box>
      {run.truncated && run.executionId && (
        <Typography variant="caption" color="warning.main" data-testid="tile-truncated">
          Based on the first {run.rowLimit ? run.rowLimit.toLocaleString() : ''} rows only.
        </Typography>
      )}
      <Box sx={{ flex: 1, minHeight: 0, overflow: 'auto' }}>{body}</Box>
    </Box>
  );
}
