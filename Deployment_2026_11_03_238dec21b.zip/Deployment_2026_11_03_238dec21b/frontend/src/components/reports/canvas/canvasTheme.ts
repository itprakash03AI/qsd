/**
 * canvasTheme -- the LOOK of a report is configuration (2026-11-01).
 *
 * The owner: "blue band ... is configurable right so colour can be anything".
 * The band's blue, the title's serif and the header grey were literals in the
 * band tile.  Now a theme is DATA (the server's core/reports/themes.py is the
 * rule; this file is its browser twin):
 *
 *   layout_config.theme = { name: 'Finance Blue', ...overrides }
 *
 * `name` picks the base -- a theme of the library (GET /api/report-themes) or
 * a SHIPPED one (shippedThemes.json, the same file the server holds; a test
 * pins them equal) -- and every other key overrides a field.  No theme = the
 * default ('QueryStudio'), byte for byte.  `resolveTheme` is THE resolver; the
 * band, the finance grid, the number tiles and every chart read it through
 * `useCanvasTheme()` from the provider the viewer and the builder mount.
 * `contrastRatio` / `themeWarnings` say in plain words when text would be hard
 * to read; the server refuses under 3:1 and warns under 4.5:1 -- the same rule.
 */
import { createContext, useContext } from 'react';
import shipped from './shippedThemes.json';

export type NegativeStyle = 'red_brackets' | 'brackets' | 'red' | 'minus';
export type CodePosition = 'right' | 'left' | 'under' | 'hidden';
export type Density = 'compact' | 'normal' | 'comfortable';
export type NumberScale = 'none' | 'K' | 'M' | 'B';

export interface RowStyle { bg: string; fg: string; bold: boolean }
/** theme v2 (2026-11-02): a KPI card is plain (on the card), filled, or a gradient of its fill */
export type KpiStyle = 'plain' | 'filled' | 'gradient';
export type TabStyle = 'bar' | 'chips' | 'plain';
export type TitleAlign = 'left' | 'center';
/** a page / card colour: a hex, or 'app' = as the app draws it (today's look) */
export type AppColour = string;
export interface ReportTheme {
  name: string;
  /** the gallery's words: which shelf, and one line on what it is good for */
  group?: string;
  description?: string;
  band: { bg: string; fg: string; label_fg: string; font: string; show: string[] | null };
  title: { font: string; size: number; color: string; code_position: CodePosition };
  grid: { header_bg: string; header_fg: string; subtotal: RowStyle; grand: RowStyle;
          negative: NegativeStyle; zebra: boolean; density: Density };
  numbers: { decimals: number; thousands: boolean; scale: NumberScale; currency: string };
  palette: string[];
  tiles: { radius: number; shadow: boolean; other_fill: string };
  /** the page behind the cards and the header bar that holds the page tabs */
  page: { bg: AppColour; header_bg: AppColour; header_fg: string; tabs: TabStyle };
  /** every tile's card */
  card: { bg: AppColour; border: AppColour; fg: AppColour; title_fg: AppColour; title_align: TitleAlign };
  /** the number tiles drawn as KPI cards */
  kpi: { style: KpiStyle; fills: string[]; value_fg: string; label_fg: string; up_fg: string; down_fg: string };
}
/** what a report STORES: a name and / or any subset of the fields */
export type ThemeSpec = { name?: string } & { [K in Exclude<keyof ReportTheme, 'name'>]?: Partial<ReportTheme[K]> | any };

export const DEFAULT_THEME_NAME = 'QueryStudio';
export const SHIPPED_THEMES: Record<string, Omit<ReportTheme, 'name'>> = shipped as any;
/** a shipped theme's OLD name -> its name now (the server's themes.RENAMED: "PLEX" was a
 *  team's report, not a theme; a report saved with it opens with the same look) */
export const RENAMED_THEMES: Record<string, string> = { PLEX: 'Finance Blue' };
export const shippedThemeName = (name: string): string => RENAMED_THEMES[name] || name;
/** the gallery's shelves, in order (a theme with no group goes under Other) */
export const THEME_GROUPS = ['Dashboards', 'Everyday', 'Finance and statements', 'Executive', 'Analytics', 'Colour moods', 'Accessible', 'Print'];
export const NEGATIVE_STYLES: NegativeStyle[] = ['red_brackets', 'brackets', 'red', 'minus'];
export const CODE_POSITIONS: CodePosition[] = ['right', 'left', 'under', 'hidden'];
export const DENSITIES: Density[] = ['compact', 'normal', 'comfortable'];
export const SCALES: NumberScale[] = ['none', 'K', 'M', 'B'];
export const KPI_STYLES: KpiStyle[] = ['plain', 'filled', 'gradient'];
export const TAB_STYLES: TabStyle[] = ['bar', 'chips', 'plain'];
export const TITLE_ALIGNS: TitleAlign[] = ['left', 'center'];
export const MAX_KPI_FILLS = 8;
/** "as the app draws it" -- a page / card colour only */
export const APP = 'app';
/** a gradient KPI card runs from its fill to the fill this much darker (the server's GRADIENT_SHADE) */
export const GRADIENT_SHADE = 0.22;
/** what 'app' stands for when a contrast is judged: the app's light surface and its text */
export const APP_BG = '#ffffff';
export const APP_FG = '#1d1d1f';
export const CONTRAST_REFUSE = 3.0;
export const CONTRAST_WARN = 4.5;
export const KPI_STYLE_WORDS: Record<KpiStyle, string> = { plain: 'Plain (on the card)', filled: 'Filled with a colour', gradient: 'A colour gradient' };
export const TAB_STYLE_WORDS: Record<TabStyle, string> = { bar: 'A bar across the page', chips: 'Round chips', plain: 'Plain tabs' };

export const NEGATIVE_WORDS: Record<NegativeStyle, string> = {
  red_brackets: 'Red, in brackets: (108,615)', brackets: 'In brackets: (108,615)', red: 'Red, with a minus: -108,615', minus: 'A minus sign: -108,615',
};

const HEX = /^#[0-9a-fA-F]{6}$/;
export const isHex = (v: any): v is string => typeof v === 'string' && HEX.test(v);
// SECURITY (review 2026-11-01): a theme value reaches `sx` -- the SAME rules as the
// server's core/reports/themes.py: a font is letters, digits, spaces, commas,
// quotes and hyphens (no ; { } ( ) : / \ < > or url()), a radius 0..32, a
// shadow on / off, a currency symbol <= 4 characters with no metacharacter.
// Anything else is the DEFAULT theme's value, whatever the server sent.
const FONT = /^[A-Za-z0-9 ,'\-]{1,80}$/;
const CURRENCY_BAD = /[<>&"'`;{}()\\/:=]/;
export const MAX_RADIUS = 32;
export const MAX_CURRENCY = 4;
export const isFont = (v: any): v is string => typeof v === 'string' && FONT.test(v);
export const isCurrency = (v: any): v is string => typeof v === 'string' && v.length <= MAX_CURRENCY && !CURRENCY_BAD.test(v);
export const isRadius = (v: any): v is number => Number.isInteger(v) && v >= 0 && v <= MAX_RADIUS;
export const isHexOrApp = (v: any): v is string => v === APP || isHex(v);

/** `hex` mixed towards black by `amount` (0..1) -- the darker end of a gradient (the server's `shade`). */
export function shade(hex: string, amount: number): string {
  const h = hex.replace('#', '');
  const c = (i: number) => Math.round(parseInt(h.slice(i, i + 2), 16) * (1 - amount));
  return '#' + [0, 2, 4].map(i => c(i).toString(16).padStart(2, '0')).join('');
}
/** A page / card colour as a CSS value: 'app' = the app's own (undefined, so MUI draws it). */
export const cssColour = (v: AppColour): string | undefined => (v === APP ? undefined : v);
/** A page / card colour as a hex for a contrast check: 'app' = the app's surface (or its text). */
export const appColour = (v: AppColour, fg = false): string => (v === APP ? (fg ? APP_FG : APP_BG) : v);
/** The i-th KPI fill of a theme (cycling), and its gradient. */
export const kpiFill = (t: ReportTheme, i: number): string => t.kpi.fills[i % Math.max(1, t.kpi.fills.length)] ?? '#1e6fd9';
export const kpiGradient = (fill: string): string => `linear-gradient(135deg, ${fill} 0%, ${shade(fill, GRADIENT_SHADE)} 100%)`;

/** A RESOLVED theme made safe for a style: every field checked, the default where it is not. */
export function sanitizeTheme(t: any): ReportTheme {
  const d = SHIPPED_THEMES[DEFAULT_THEME_NAME];
  const hex = (v: any, def: string) => (isHex(v) ? v : def);
  const hexApp = (v: any, def: string) => (isHexOrApp(v) ? v : def);
  const sec = (v: any) => (v && typeof v === 'object' && !Array.isArray(v) ? v : {});
  const band = sec(t?.band), title = sec(t?.title), grid = sec(t?.grid), nums = sec(t?.numbers), tiles = sec(t?.tiles);
  const page = sec(t?.page), card = sec(t?.card), kpi = sec(t?.kpi);
  const row = (r: any, def: RowStyle): RowStyle => ({ bg: hex(sec(r).bg, def.bg), fg: hex(sec(r).fg, def.fg), bold: typeof sec(r).bold === 'boolean' ? sec(r).bold : def.bold });
  const pal = Array.isArray(t?.palette) ? t.palette.filter(isHex).slice(0, 16) : [];
  const fills = Array.isArray(kpi.fills) ? kpi.fills.filter(isHex).slice(0, MAX_KPI_FILLS) : [];
  return {
    name: typeof t?.name === 'string' && t.name ? t.name.slice(0, 60) : DEFAULT_THEME_NAME,
    band: { bg: hex(band.bg, d.band.bg), fg: hex(band.fg, d.band.fg), label_fg: hex(band.label_fg, d.band.label_fg),
            font: isFont(band.font) ? band.font : d.band.font,
            show: Array.isArray(band.show) ? band.show.filter((x: any) => typeof x === 'string' && x) : null },
    title: { font: isFont(title.font) ? title.font : d.title.font,
             size: typeof title.size === 'number' && title.size >= 10 && title.size <= 48 ? title.size : d.title.size,
             color: hex(title.color, d.title.color),
             code_position: CODE_POSITIONS.includes(title.code_position) ? title.code_position : d.title.code_position },
    grid: { header_bg: hex(grid.header_bg, d.grid.header_bg), header_fg: hex(grid.header_fg, d.grid.header_fg),
            subtotal: row(grid.subtotal, d.grid.subtotal), grand: row(grid.grand, d.grid.grand),
            negative: NEGATIVE_STYLES.includes(grid.negative) ? grid.negative : d.grid.negative,
            zebra: typeof grid.zebra === 'boolean' ? grid.zebra : d.grid.zebra,
            density: DENSITIES.includes(grid.density) ? grid.density : d.grid.density },
    numbers: { decimals: Number.isInteger(nums.decimals) && nums.decimals >= 0 && nums.decimals <= 10 ? nums.decimals : d.numbers.decimals,
               thousands: typeof nums.thousands === 'boolean' ? nums.thousands : d.numbers.thousands,
               scale: SCALES.includes(nums.scale) ? nums.scale : d.numbers.scale,
               currency: isCurrency(nums.currency) ? nums.currency : '' },
    palette: pal.length ? pal : [...d.palette],
    tiles: { radius: isRadius(tiles.radius) ? tiles.radius : d.tiles.radius, shadow: typeof tiles.shadow === 'boolean' ? tiles.shadow : d.tiles.shadow,
             other_fill: hex(tiles.other_fill, d.tiles.other_fill) },
    page: { bg: hexApp(page.bg, d.page.bg), header_bg: hexApp(page.header_bg, d.page.header_bg), header_fg: hex(page.header_fg, d.page.header_fg),
            tabs: TAB_STYLES.includes(page.tabs) ? page.tabs : d.page.tabs },
    card: { bg: hexApp(card.bg, d.card.bg), border: hexApp(card.border, d.card.border), fg: hexApp(card.fg, d.card.fg),
            title_fg: hexApp(card.title_fg, d.card.title_fg), title_align: TITLE_ALIGNS.includes(card.title_align) ? card.title_align : d.card.title_align },
    kpi: { style: KPI_STYLES.includes(kpi.style) ? kpi.style : d.kpi.style, fills: fills.length ? fills : [...d.kpi.fills],
           value_fg: hex(kpi.value_fg, d.kpi.value_fg), label_fg: hex(kpi.label_fg, d.kpi.label_fg),
           up_fg: hex(kpi.up_fg, d.kpi.up_fg), down_fg: hex(kpi.down_fg, d.kpi.down_fg) },
  };
}

function deepMerge<T>(base: T, over: any): T {
  const out: any = Array.isArray(base) ? [...(base as any)] : { ...(base as any) };
  for (const k of Object.keys(over || {})) {
    const v = over[k];
    if (v === null || v === undefined) continue;
    if (v && typeof v === 'object' && !Array.isArray(v) && out[k] && typeof out[k] === 'object' && !Array.isArray(out[k])) out[k] = deepMerge(out[k], v);
    else out[k] = Array.isArray(v) ? [...v] : v;
  }
  return out;
}

/** THE resolved theme of a report: base (library, else shipped, else default) + overrides. */
export function resolveTheme(layoutConfig: any, library?: Record<string, any> | null): ReportTheme {
  const spec: ThemeSpec | null = layoutConfig && typeof layoutConfig === 'object' && layoutConfig.theme
    && typeof layoutConfig.theme === 'object' ? layoutConfig.theme : null;
  const def = deepMerge({} as any, SHIPPED_THEMES[DEFAULT_THEME_NAME]);
  if (!spec) return sanitizeTheme({ ...def, name: DEFAULT_THEME_NAME });
  const name = String(spec.name || '').trim();
  const base = (library && library[name]) || SHIPPED_THEMES[shippedThemeName(name)] || null;
  const { name: _n, ...overrides } = spec;
  return sanitizeTheme({ ...deepMerge(deepMerge(def, base || {}), overrides), name: name || DEFAULT_THEME_NAME });
}

// ── contrast (WCAG), the same numbers as the server ──
const lin = (c: number) => { c /= 255; return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
export function luminance(hex: string): number {
  const h = hex.replace('#', '');
  return 0.2126 * lin(parseInt(h.slice(0, 2), 16)) + 0.7152 * lin(parseInt(h.slice(2, 4), 16)) + 0.0722 * lin(parseInt(h.slice(4, 6), 16));
}
export function contrastRatio(a: string, b: string): number {
  const la = luminance(a), lb = luminance(b);
  const hi = Math.max(la, lb), lo = Math.min(la, lb);
  return Math.round(((hi + 0.05) / (lo + 0.05)) * 100) / 100;
}

/** The pairs a theme must keep readable, each judged on the RESOLVED theme. */
export function contrastChecks(t: ReportTheme): { words: string; fg: string; bg: string; ratio: number; level: 'ok' | 'warn' | 'refuse' }[] {
  // the SAME pairs as the server's themes.contrast_pairs
  const pairs: [string, string, string][] = [
    ["the band's text on its background", t.band.fg, t.band.bg],
    ["the band's labels on its background", t.band.label_fg, t.band.bg],
    ["the grid header's text on its background", t.grid.header_fg, t.grid.header_bg],
    ["the subtotal row's text on its background", t.grid.subtotal.fg, t.grid.subtotal.bg],
    ["the grand total's text on its background", t.grid.grand.fg, t.grid.grand.bg],
    ["the page header's text on its bar", t.page.header_fg, appColour(t.page.header_bg)],
    ["a card's text on the card", appColour(t.card.fg, true), appColour(t.card.bg)],
    ["a card's title on the card", appColour(t.card.title_fg, true), appColour(t.card.bg)],
    ["the 'up' colour on a card", t.kpi.up_fg, appColour(t.card.bg)],
    ["the 'down' colour on a card", t.kpi.down_fg, appColour(t.card.bg)],
  ];
  t.kpi.fills.forEach((f, i) => {
    pairs.push([`a KPI card's value on fill ${i + 1}`, t.kpi.value_fg, f]);
    pairs.push([`a KPI card's label on fill ${i + 1}`, t.kpi.label_fg, f]);
    pairs.push([`a KPI card's value on the darker end of fill ${i + 1}`, t.kpi.value_fg, shade(f, GRADIENT_SHADE)]);
  });
  return pairs.map(([words, fg, bg]) => {
    const ratio = isHex(fg) && isHex(bg) ? contrastRatio(fg, bg) : 21;
    return { words, fg, bg, ratio, level: ratio < CONTRAST_REFUSE ? 'refuse' : ratio < CONTRAST_WARN ? 'warn' : 'ok' };
  });
}
/** Plain words for a person: the problems (refused on save) and the warnings. */
export function themeWords(t: ReportTheme): { problems: string[]; warnings: string[] } {
  const problems: string[] = [], warnings: string[] = [];
  for (const c of contrastChecks(t)) {
    if (c.level === 'refuse') problems.push(`${c.words} (${c.fg} on ${c.bg}) cannot be read -- contrast ${c.ratio}:1, at least ${CONTRAST_REFUSE}:1 is needed.`);
    else if (c.level === 'warn') warnings.push(`${c.words} (${c.fg} on ${c.bg}) would be hard to read -- contrast ${c.ratio}:1; ${CONTRAST_WARN}:1 reads comfortably.`);
  }
  return { problems, warnings };
}

/** A negative number in the theme's style (the sign already removed from `body`). */
export function negativeText(body: string, style: NegativeStyle): string {
  return style === 'brackets' || style === 'red_brackets' ? `(${body})` : `-${body}`;
}
export const negativeIsRed = (style: NegativeStyle) => style === 'red' || style === 'red_brackets';

/** A number scaled by the theme: 1,234,567 -> "1.2M" when scale = M. */
export function scaleNumber(v: number, scale: NumberScale, decimals: number): { text: string; suffix: string } {
  const div = scale === 'K' ? 1e3 : scale === 'M' ? 1e6 : scale === 'B' ? 1e9 : 1;
  const n = v / div;
  return { text: Math.abs(n).toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }), suffix: scale === 'none' ? '' : scale };
}

export const DENSITY_PY: Record<Density, number> = { compact: 0.25, normal: 0.6, comfortable: 1 };

export const CanvasThemeContext = createContext<ReportTheme | null>(null);
/** The theme of the report on the page (the default when nothing mounted one). */
export function useCanvasTheme(): ReportTheme {
  return useContext(CanvasThemeContext) ?? resolveTheme(null);
}
