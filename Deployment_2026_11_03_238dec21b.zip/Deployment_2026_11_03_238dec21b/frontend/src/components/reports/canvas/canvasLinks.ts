/**
 * Linked canvas tiles (2026-10-30, plan docs/REPORT_OUTLINE_AND_DETAIL_LINKS_2026_10_30.html §4).
 *
 * A click on a tile (a table or outline row, a bar, a slice, a point) filters
 * every OTHER tile of the canvas to that value, or that path (Product Area =
 * Credit > Business Area = FI Credit) -- Power BI's cross-filter.  Every
 * number is answered from the report's ONE stored, row-secured result
 * through the cube's ``slicers`` -- never a new query to the source.
 *
 * THE STATE is a list of ``{column_id, value, tile_id}`` entries (a path is
 * several entries; ``tile_id`` is the tile that was clicked):
 *   - entries naming the SAME field are alternatives (any of them),
 *     different fields must all hold;
 *   - the clicked tile is not filtered by its own click (it keeps every
 *     value to click);
 *   - a tile with ``linked: false`` and a canvas with ``links: {enabled: false}``
 *     are not filtered.  The report's OWN table follows the links too
 *     (2026-10-30, every report a canvas): the viewer asks its pages with
 *     ``links`` and the server answers the matching rows of the stored result
 *     (backend/core/reports/report_table_links.py).
 * The server applies the SAME rule to an export (backend/core/reports/canvas_links.py).
 *
 * FOR A TILE (outline, insight, any new kind) -- one hook, nothing else:
 *
 *     const { filters, toggle, togglePath, isSelected } = useCanvasLinks();
 *     // filters: the entries that apply to THIS tile (send them as the cube's
 *     //          slicers with ``linkSlicers(filters, cols)``)
 *     // toggle(column_id, value, additive): a click; additive = Ctrl / Cmd
 *     // togglePath([{column_id, value}, ...], additive): a clicked row of
 *     //          several levels
 *
 * Outside a canvas (a test, a lone tile) the hook answers "no links" and its
 * calls do nothing.
 */
import React, { createContext, useCallback, useContext, useMemo, useState, useSyncExternalStore } from 'react';
import type { CanvasColumn, CanvasTile, ReportCanvas } from './canvasModel';

export interface CanvasLink {
  column_id: number;
  value: any;
  /** the tile that was clicked (null = from outside any tile) */
  tile_id?: string | null;
  /** a click of SEVERAL levels (an outline row): the id its steps share -- see linkFilter */
  path?: string;
}
export interface LinkStep { column_id: number; value: any; path?: string }

const same = (a: LinkStep, b: LinkStep) =>
  a.column_id === b.column_id && JSON.stringify(a.value ?? null) === JSON.stringify(b.value ?? null)
  && (a.path ?? null) === (b.path ?? null);

/** The id a multi-level click stamps on its steps (the steps themselves, so the same row = the same id). */
export const pathId = (steps: LinkStep[]) => JSON.stringify(steps.map(s => [s.column_id, s.value ?? null]));

/** Are links on for this canvas? (on unless it says ``links: {enabled: false}``) */
export const linksEnabled = (canvas?: Pick<ReportCanvas, 'links'> | null) => canvas?.links?.enabled !== false;

/** Does this tile follow clicks on other tiles?  (The report's own table too, since 2026-10-30.) */
export const tileFollowsLinks = (t: Pick<CanvasTile, 'kind' | 'linked'>) => t.linked !== false;

/** The links that filter the report's OWN table on this canvas ([] when it does not follow, or is not placed). */
export function reportTableLinks(links: CanvasLink[], canvas: ReportCanvas | null | undefined): CanvasLink[] {
  const t = canvas?.tiles.find(x => x.kind === 'report') ?? null;
  return linksForTile(links, t, linksEnabled(canvas));
}

/**
 * One click.  Plain: the clicked steps replace every link -- and clicking
 * exactly what is already selected un-selects it.  Additive (Ctrl / Cmd):
 * the steps are added -- or, when every one is already there, taken away.
 */
export function toggleLinks(links: CanvasLink[], steps: LinkStep[], additive: boolean,
                            tileId: string | null): CanvasLink[] {
  // a click of several levels is ONE path: its steps share an id, so two
  // Ctrl-added paths are "this path OR that path" (linkFilter), not widened
  const pid = steps.length > 1 ? pathId(steps) : undefined;
  const stamped: CanvasLink[] = steps.map(s => ({ column_id: s.column_id, value: s.value ?? null, tile_id: tileId,
    ...(pid ? { path: pid } : {}) }));
  if (stamped.length === 0) return links;
  const allThere = stamped.every(s => links.some(l => same(l, s)));
  if (!additive) {
    const exact = allThere && links.length === stamped.length;
    return exact ? [] : stamped;
  }
  if (allThere) return links.filter(l => !stamped.some(s => same(l, s)));
  return [...links, ...stamped.filter(s => !links.some(l => same(l, s)))];
}

/** The entries that filter this tile. */
export function linksForTile(links: CanvasLink[], tile: Pick<CanvasTile, 'id' | 'kind' | 'linked'> | null,
                             enabled = true): CanvasLink[] {
  if (!enabled || !tile || !tileFollowsLinks(tile)) return [];
  return links.filter(l => l.tile_id == null || l.tile_id !== tile.id);
}

/** Entries -> the cube's ``slicers`` ({physical_name: [values]}).  A field the
 *  report does not have is an Error (never a silently dropped filter). */
export function linkSlicers(links: CanvasLink[], cols: Map<number, CanvasColumn>): Record<string, any[]> {
  const out: Record<string, any[]> = {};
  for (const l of links) {
    const name = cols.get(l.column_id)?.physical_name;
    if (!name) throw new Error(`A linked value names a field that is not in this report (column #${l.column_id}). Clear the linked values.`);
    const vals = (out[name] ??= []);
    if (!vals.some(v => JSON.stringify(v) === JSON.stringify(l.value ?? null))) vals.push(l.value ?? null);
  }
  return out;
}

/** A tile's own slicers AND the linked ones: a field in both keeps the values in both. */
export function mergeSlicers(own: Record<string, any[]> | undefined | null,
                             linked: Record<string, any[]>): Record<string, any[]> {
  const out: Record<string, any[]> = { ...linked };
  for (const [k, v] of Object.entries(own || {})) {
    out[k] = k in linked ? v.filter(x => linked[k].some(y => JSON.stringify(y) === JSON.stringify(x))) : v;
  }
  return out;
}

export interface CubePathStepBody { column: string; value: any }

/**
 * THE RULE (the server's canvas_links.tile_groups, the same answer): the
 * clicks of a tile that has a multi-level path are ONE clause -- its paths
 * are alternatives (OR), each path all of its steps (AND); a one-level click
 * on that tile is a path of one step.  Every other tile's clicks are
 * `plain` (same field = any of the values, fields = all).  Clauses AND.
 */
export function linkGroups(links: CanvasLink[]): { plain: CanvasLink[]; clauses: CanvasLink[][][] } {
  const byTile = new Map<string, CanvasLink[]>();
  for (const l of links) {
    const k = String(l.tile_id ?? '\u0000');
    if (!byTile.has(k)) byTile.set(k, []);
    byTile.get(k)!.push(l);
  }
  const plain: CanvasLink[] = [];
  const clauses: CanvasLink[][][] = [];
  for (const group of byTile.values()) {
    if (!group.some(l => l.path)) { plain.push(...group); continue; }
    const paths = new Map<string, CanvasLink[]>();
    group.forEach((l, i) => {
      const k = l.path ?? `#single${i}`;
      if (!paths.has(k)) paths.set(k, []);
      paths.get(k)!.push(l);
    });
    clauses.push([...paths.values()]);
  }
  return { plain, clauses };
}

/** Entries -> the cube's `slicers` + `link_paths` (one OR-of-ANDs clause per tile with paths). */
export function linkFilter(links: CanvasLink[], cols: Map<number, CanvasColumn>):
  { slicers: Record<string, any[]>; link_paths: CubePathStepBody[][][] } {
  const { plain, clauses } = linkGroups(links);
  const name = (id: number) => {
    const n = cols.get(id)?.physical_name;
    if (!n) throw new Error(`A linked value names a field that is not in this report (column #${id}). Clear the linked values.`);
    return n;
  };
  return {
    slicers: linkSlicers(plain, cols),
    link_paths: clauses.map(c => c.map(p => p.map(l => ({ column: name(l.column_id), value: l.value ?? null })))),
  };
}

/** A cube body with the links that filter a tile added (unchanged when none). */
export function withLinkSlicers<T extends { slicers?: Record<string, any[]>; link_paths?: CubePathStepBody[][][] }>(
  body: T, filters: CanvasLink[], cols: Map<number, CanvasColumn>): T {
  if (!filters.length) return body;
  const f = linkFilter(filters, cols);
  const out: T = { ...body };
  if (Object.keys(f.slicers).length) out.slicers = mergeSlicers(body.slicers, f.slicers);
  if (f.link_paths.length) out.link_paths = [...(body.link_paths ?? []), ...f.link_paths];
  return out;
}

/** A clicked row of several levels: its value at each of the tile's grouping fields. */
export function rowSteps(columnIds: number[], values: any[]): LinkStep[] {
  return columnIds.map((column_id, i) => ({ column_id, value: values[i] ?? null }));
}

/** The words for one value on a chip. */
export function linkValueWords(v: any): string {
  if (v === null || v === undefined) return '(no value)';
  if (v === '') return '(blank)';
  const s = String(v);
  return /^\d{4}-\d{2}-\d{2}T00:00:00/.test(s) ? s.slice(0, 10) : s;
}

/** "Region = EMEA or AMER; Product = A" -- in the order the fields were clicked. */
export function linkWords(links: CanvasLink[], cols: Map<number, CanvasColumn>): string {
  const { plain, clauses } = linkGroups(links);
  const label = (id: number) => cols.get(id)?.label ?? `column #${id}`;
  const parts = plain.length ? [plainWords(plain, cols)] : [];
  for (const clause of clauses) {
    parts.push(clause.map(p => {
      const w = p.map(l => `${label(l.column_id)} = ${linkValueWords(l.value)}`).join(' and ');
      return clause.length > 1 && p.length > 1 ? `(${w})` : w;
    }).join(' or '));
  }
  return parts.join('; ');
}

function plainWords(links: CanvasLink[], cols: Map<number, CanvasColumn>): string {
  const order: number[] = [];
  const vals = new Map<number, string[]>();
  for (const l of links) {
    if (!vals.has(l.column_id)) { order.push(l.column_id); vals.set(l.column_id, []); }
    const w = linkValueWords(l.value);
    if (!vals.get(l.column_id)!.includes(w)) vals.get(l.column_id)!.push(w);
  }
  return order.map(id => `${cols.get(id)?.label ?? `column #${id}`} = ${vals.get(id)!.join(' or ')}`).join('; ');
}

/** The export request's ``links`` value; undefined when none (the old export, byte for byte). */
export function linksExportParam(links: CanvasLink[] | null | undefined): string | undefined {
  if (!links || links.length === 0) return undefined;
  return JSON.stringify(links.map(l => ({ column_id: l.column_id, value: l.value ?? null, tile_id: l.tile_id ?? null,
    ...(l.path ? { path: l.path } : {}) })));
}

// ── the store: one per canvas on screen ─────────────────────────────────────

export interface CanvasLinkStore {
  get: () => CanvasLink[];
  set: (links: CanvasLink[]) => void;
  subscribe: (fn: () => void) => () => void;
}

/** A page that needs the links outside the canvas (its export button) makes the store and hands it down. */
export function createLinkStore(initial: CanvasLink[] = []): CanvasLinkStore {
  let links = initial;
  const subs = new Set<() => void>();
  return {
    get: () => links,
    set: (next) => { if (next !== links) { links = next; subs.forEach(f => f()); } },
    subscribe: (fn) => { subs.add(fn); return () => { subs.delete(fn); }; },
  };
}

interface LinksCtx { store: CanvasLinkStore; enabled: boolean }
const LinksContext = createContext<LinksCtx | null>(null);
interface TileCtx { id: string; kind: CanvasTile['kind']; linked?: boolean }
const TileContext = createContext<TileCtx | null>(null);

/** The canvas's links (ReportCanvasView mounts it; ``store`` from the page when it exports). */
export function CanvasLinksProvider({ store, enabled = true, children }:
  { store?: CanvasLinkStore; enabled?: boolean; children?: React.ReactNode }) {
  const [own] = useState(() => createLinkStore());
  const s = store ?? own;
  const value = useMemo(() => ({ store: s, enabled }), [s, enabled]);
  return React.createElement(LinksContext.Provider, { value }, children);
}

/** Wraps one tile so ``useCanvasLinks`` knows which tile is asking. */
export function CanvasLinkTileScope({ tile, children }:
  { tile: Pick<CanvasTile, 'id' | 'kind' | 'linked'>; children?: React.ReactNode }) {
  const value = useMemo(() => ({ id: tile.id, kind: tile.kind, linked: tile.linked }), [tile.id, tile.kind, tile.linked]);
  return React.createElement(TileContext.Provider, { value }, children);
}

const NO_LINKS: CanvasLink[] = [];
const noSub = () => () => {};
const noGet = () => NO_LINKS;

export interface UseCanvasLinks {
  /** links work here (inside a canvas that has them on) */
  enabled: boolean;
  /** every link on the canvas (the chips) */
  all: CanvasLink[];
  /** the links that filter THIS tile */
  filters: CanvasLink[];
  /** this tile does not follow clicks (``linked: false``) */
  unlinked: boolean;
  toggle: (column_id: number, value: any, additive?: boolean) => void;
  togglePath: (steps: LinkStep[], additive?: boolean) => void;
  remove: (link: LinkStep) => void;
  clear: () => void;
  /** is this value one THIS tile clicked (to highlight it) */
  isSelected: (column_id: number, value: any) => boolean;
  /** has THIS tile clicked anything (to dim what is not selected) */
  hasSelection: boolean;
}

export function useCanvasLinks(): UseCanvasLinks {
  const ctx = useContext(LinksContext);
  const tile = useContext(TileContext);
  const all = useSyncExternalStore(ctx?.store.subscribe ?? noSub, ctx?.store.get ?? noGet, ctx?.store.get ?? noGet);
  const enabled = !!ctx && ctx.enabled;
  const filters = useMemo(() => (tile ? linksForTile(all, tile, enabled) : NO_LINKS), [all, tile, enabled]);
  const tileId = tile?.id ?? null;
  const togglePath = useCallback((steps: LinkStep[], additive = false) => {
    if (!ctx || !ctx.enabled) return;
    ctx.store.set(toggleLinks(ctx.store.get(), steps, additive, tileId));
  }, [ctx, tileId]);
  const toggle = useCallback((column_id: number, value: any, additive = false) =>
    togglePath([{ column_id, value }], additive), [togglePath]);
  const remove = useCallback((link: LinkStep) => {
    if (!ctx) return;
    // a step of a clicked path takes its whole path with it (half a path would widen it)
    ctx.store.set(ctx.store.get().filter(l => (link.path ? l.path !== link.path : !same(l, link))));
  }, [ctx]);
  const clear = useCallback(() => { ctx?.store.set([]); }, [ctx]);
  const mine = useMemo(() => all.filter(l => tileId != null && l.tile_id === tileId), [all, tileId]);
  const isSelected = useCallback((column_id: number, value: any) =>
    mine.some(l => same({ ...l, path: undefined }, { column_id, value })), [mine]);
  return {
    enabled, all: enabled ? all : NO_LINKS, filters, unlinked: !!tile && !tileFollowsLinks(tile),
    toggle, togglePath, remove, clear, isSelected, hasSelection: enabled && mine.length > 0,
  };
}
