/**
 * Canvas ACTIONS (2026-10-30) -- "Download detail" through a Published API.
 *
 * Plan docs/REPORT_OUTLINE_AND_DETAIL_LINKS_2026_10_30.html section 5.  An
 * action is defined once on the canvas (layout_config.canvas.actions) and
 * shown on tile columns (a ⤓ link on the cell) and on charts (right-click).
 * A click sends only WHICH row it was -- the dimension values of the clicked
 * cell -- and the server reads every value it sends from the run's stored,
 * row-secured result, calls the Published API as the person, and keeps the
 * CSV in the Download Centre.  The tile shows "Preparing ..." and then the
 * file's name, rows and size with Preview (the app's own dialog), Download and
 * Download Centre; a failure is said in words.
 *
 * Backend: api/canvas_actions_api.py, core/reports/canvas_actions.py.
 *
 * Linked tiles: the chips in force come in through the provider's `links`
 * prop (canvasLinks.ts `useCanvasLinks()` when it is on the page; the viewer
 * passes them).  An action with a `from: 'link'` value sends the chip on that
 * column; the server checks the value is one the person's result holds.
 */
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Divider, FormControlLabel,
  IconButton, Link, Menu, MenuItem, Stack, Table, TableBody, TableCell, TableHead, TablePagination, TableRow,
  TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from '../../common/AppDialog';
import DownloadIcon from '@mui/icons-material/FileDownloadOutlined';
import DetailIcon from '@mui/icons-material/TableViewOutlined';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import { useNavigate } from 'react-router-dom';
import { openDownload, safeFetch } from '../../../services/api/core';
import type { CanvasColumn, CanvasTile, ReportCanvas } from './canvasModel';

// ── the model ──────────────────────────────────────────────────────────────

export type ActionSource = 'row' | 'parameter' | 'link' | 'fixed';
/** Where the detail comes from (2026-10-31): a Published API, or a query on a dataset. */
export type ActionRoad = 'published_api' | 'query';
/** What a click does: show the detail in a popup, or make a file. */
export type ActionShow = 'popup' | 'download';
export interface ActionParam {
  /** What the value is given to: an API name / `filter.<col>`; on the query road a
   *  dataset column or `where.<key>` (a condition of the dataset's own query). */
  target?: string;
  /** The saved actions' spelling of `target` (kept as it was stored). */
  api_param?: string;
  from: ActionSource;
  column_id?: number | null;
  parameter?: string | null;
  value?: string | null;
}
export interface CanvasAction {
  id: string;
  kind: 'detail_download';
  label: string;
  view_slug: string;
  /** missing = 'published_api' (a saved action is unchanged) */
  source?: ActionRoad;
  dataset_id?: number | null;
  /** missing = 'download' (a saved action is unchanged); a NEW action is 'popup' */
  show?: ActionShow;
  /** 2026-11-01 -- the detail ALSO takes the report's own parameters and filters (the run's values,
   *  read by the server from the run); missing = on for a query on the report's own dataset */
  pass_parameters?: boolean;
  params: ActionParam[];
  file_name?: string | null;
  on: { tile_id: string; column_id?: number | null }[];
}
export interface LinkChip { column_id: number; value: any }

export const DEFAULT_FILE_NAME = '{report_code}_{value}_{business_date}.csv';

export const targetOf = (p: ActionParam): string => (p.target || p.api_param || '');
export const sourceOf = (a: CanvasAction): ActionRoad => (a.source ?? 'published_api');
export const showOf = (a: CanvasAction): ActionShow => (a.show ?? 'download');

/** The canvas's actions as stored; anything unreadable is dropped.  A field the
 *  stored action does not have is not added (it saves back as it was). */
export function readActions(raw: any): CanvasAction[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter(a => a && typeof a === 'object').map((a: any) => ({
    id: String(a.id ?? ''),
    kind: 'detail_download',
    label: String(a.label ?? ''),
    view_slug: String(a.view_slug ?? ''),
    ...(a.source != null ? { source: a.source } : {}),
    ...(a.dataset_id != null ? { dataset_id: Number(a.dataset_id) } : {}),
    ...(a.show != null ? { show: a.show } : {}),
    ...(typeof a.pass_parameters === 'boolean' ? { pass_parameters: a.pass_parameters } : {}),
    params: Array.isArray(a.params) ? a.params.filter((p: any) => p && typeof p === 'object').map((p: any) => ({
      ...(p.target != null && p.target !== '' ? { target: String(p.target) } : {}),
      ...(p.api_param != null || p.target == null || p.target === '' ? { api_param: String(p.api_param ?? '') } : {}),
      from: p.from,
      column_id: p.column_id == null ? null : Number(p.column_id),
      parameter: p.parameter ?? null, value: p.value ?? null,
    })) : [],
    file_name: a.file_name ?? null,
    on: Array.isArray(a.on) ? a.on.filter((o: any) => o && typeof o === 'object').map((o: any) => ({
      tile_id: String(o.tile_id ?? ''), column_id: o.column_id == null ? null : Number(o.column_id),
    })) : [],
  }));
}

/** The actions shown on a tile's column (null column = the whole tile, e.g. a chart). */
export function actionsOn(actions: CanvasAction[], tileId: string, columnId?: number | null): CanvasAction[] {
  return actions.filter(a => a.on.some(o => o.tile_id === tileId
    && (columnId === undefined || o.column_id == null || o.column_id === columnId)));
}

/** The fields a tile's ROWS are made of: an outline's levels, else its dimensions
 *  (the server's canvas_actions.row_field_ids). */
export const rowFieldIds = (tile: CanvasTile): number[] =>
  (tile.kind === 'outline' ? (tile.levels ?? []) : tile.dimensions);

/** The clicked row's KEY: every row field the tile shows, by column id (it only names the row). */
export function rowKey(tile: CanvasTile, cols: Map<number, CanvasColumn>, row: Record<string, any>): Record<string, any> {
  const key: Record<string, any> = {};
  for (const id of rowFieldIds(tile)) {
    const name = cols.get(id)?.physical_name;
    if (name && name in row) key[String(id)] = row[name];
  }
  return key;
}

/** The file name a person will get (the builder's preview; the server makes the real one). */
export function fileNamePreview(template: string | null | undefined, facts: {
  report_code: string; value: string; business_date?: string | null; label?: string;
}): string {
  const tpl = (template || '').trim() || DEFAULT_FILE_NAME;
  let name = tpl.replace(/\{([A-Za-z_][A-Za-z0-9_.]*)\}/g, (_m, tok: string) => {
    const v = (facts as any)[tok];
    return v == null ? `<${tok}>` : String(v);
  });
  name = name.replace(/[\\/:*?"<>|]+/g, '-').replace(/_+(\.csv)$/i, '$1').replace(/_{2,}/g, '_');
  return name.toLowerCase().endsWith('.csv') ? name : `${name}.csv`;
}

export const sizeWords = (n?: number | null) => {
  if (n == null) return '';
  if (n < 1024) return `${n} bytes`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
};

// ── the server ─────────────────────────────────────────────────────────────

export interface ActionRun {
  run_id: string;
  status: 'preparing' | 'ready' | 'empty' | 'failed' | 'refused' | 'shown';
  run_kind?: 'file' | 'view';
  file_format?: 'csv' | 'xlsx' | 'parquet' | null;
  source?: ActionRoad;
  message?: string | null;
  label?: string | null;
  tile_id?: string | null;
  file_name?: string | null;
  row_count?: number | null;
  total_rows?: number | null;
  file_size_bytes?: number | null;
  size_words?: string;
  download_id?: string | null;
}
export interface ActionApi {
  slug: string; name: string; description?: string;
  params: { name: string; type: string; required: boolean; label?: string }[];
  filters: { name: string; column: string }[];
}

export const actionsApi = {
  listApis: (reportId: number): Promise<{ items: ActionApi[] }> =>
    safeFetch(`/api/business-reports/${reportId}/actions/apis`),
  run: (reportId: number, actionId: string, body: any): Promise<{ run: ActionRun; joined: boolean }> =>
    safeFetch(`/api/business-reports/${reportId}/actions/${encodeURIComponent(actionId)}/run`,
      { method: 'POST', body: JSON.stringify(body) }),
  status: (reportId: number, runId: string): Promise<{ run: ActionRun }> =>
    safeFetch(`/api/business-reports/${reportId}/actions/runs/${runId}`, { retryOnTimeout: false }),
  preview: (fileId: string): Promise<any> =>
    safeFetch(`/api/downloads/${fileId}/preview?page=1&page_size=100`),
  // the detail popup (2026-10-31)
  view: (reportId: number, actionId: string, body: any, pageSize = 50): Promise<{ run: ActionRun; view: DetailView }> =>
    safeFetch(`/api/business-reports/${reportId}/actions/${encodeURIComponent(actionId)}/view?page_size=${pageSize}`,
      { method: 'POST', body: JSON.stringify(body) }),
  rows: (reportId: number, runId: string, page: number, pageSize: number): Promise<{ run: ActionRun; view: DetailView }> =>
    safeFetch(`/api/business-reports/${reportId}/actions/runs/${runId}/rows?page=${page}&page_size=${pageSize}`),
  /** `background: true` = a full read, made in the Download Centre (a capped view's "now" too) */
  file: (reportId: number, runId: string, body: { format: DetailFormat; deliver: 'now' | 'download_centre' }):
    Promise<{ run: ActionRun; background?: boolean; message?: string | null }> =>
    safeFetch(`/api/business-reports/${reportId}/actions/runs/${runId}/file`, { method: 'POST', body: JSON.stringify(body) }),
  listDatasets: (reportId: number): Promise<{ items: { id: number; name: string; description?: string }[] }> =>
    safeFetch(`/api/business-reports/${reportId}/actions/datasets`),
  dataset: (reportId: number, datasetId: number): Promise<ActionDataset> =>
    safeFetch(`/api/business-reports/${reportId}/actions/datasets/${datasetId}`),
};

export type DetailFormat = 'csv' | 'xlsx' | 'parquet';
export interface DetailView {
  title: string;
  words: string;
  /** `label` (2026-11-01) = the dataset's display name for the header */
  columns: { name: string; type: string; label?: string }[];
  rows: any[][];
  page: number;
  page_size: number;
  pages: number;
  /** null = more than the cap and not counted ("there are more than N") */
  total_rows: number | null;
  shown_rows: number;
  capped: boolean;
  /** the stored detail holds every row: a download is made at once */
  complete?: boolean;
  source?: ActionRoad;
  sent: { sent: { target: string; value: any; from: string; where: string; words: string }[];
          not_sent: { target: string; words: string }[] };
}
export interface ActionDataset {
  id: number; name: string;
  columns: { name: string; label: string; data_type: string }[];
  conditions: { name: string; column: string; words: string }[];
  conditions_reason?: string | null;
}

const TERMINAL = ['ready', 'empty', 'failed', 'refused', 'shown'];

// ── the viewer: one provider per canvas ───────────────────────────────────

interface Ctx {
  reportId: number | null;
  actions: CanvasAction[];
  executionId: string | null;
  runs: ActionRun[];
  start: (action: CanvasAction, tile: CanvasTile, key: Record<string, any>, what: string) => void;
  /** a `show: 'popup'` action: open the detail popup for the clicked row */
  openPopup: (action: CanvasAction, tile: CanvasTile, key: Record<string, any>, what: string) => void;
  dismiss: (runId: string) => void;
}

interface PopupState { action: CanvasAction; tileId: string; what: string; body: any }
const CanvasActionsContext = createContext<Ctx | null>(null);

interface ProviderProps {
  reportId: number | null;
  canvas: ReportCanvas | null;
  executionId: string | null;
  parameterValues?: Record<string, any>;
  /** linked-tile chips in force (canvasLinks.ts); none = no chips */
  links?: LinkChip[];
  children: React.ReactNode;
}

export function CanvasActionsProvider({ reportId, canvas, executionId, parameterValues, links, children }: ProviderProps) {
  const actions = useMemo(() => readActions((canvas as any)?.actions), [canvas]);
  const [runs, setRuns] = useState<ActionRun[]>([]);
  const timers = useRef<Record<string, any>>({});
  useEffect(() => () => { Object.values(timers.current).forEach(clearTimeout); }, []);
  // a new run of the report: the notes of the old one go
  useEffect(() => { setRuns([]); }, [executionId]);

  const upsert = useCallback((r: ActionRun) => {
    // the tile it was clicked on stays with it (the note shows on that tile)
    setRuns(rs => [{ ...r, tile_id: r.tile_id ?? rs.find(x => x.run_id === r.run_id)?.tile_id },
      ...rs.filter(x => x.run_id !== r.run_id)].slice(0, 6));
  }, []);

  const poll = useCallback((runId: string, delay = 1500) => {
    if (!reportId) return;
    timers.current[runId] = setTimeout(async () => {
      try {
        const { run } = await actionsApi.status(reportId, runId);
        upsert(run);
        if (!TERMINAL.includes(run.status)) poll(runId, Math.min(5000, delay + 500));
      } catch (e: any) {
        upsert({ run_id: runId, status: 'failed', message: e?.message || 'The download could not be followed. Look in the Download Centre.' });
      }
    }, delay);
  }, [reportId, upsert]);

  const start = useCallback(async (action: CanvasAction, tile: CanvasTile, key: Record<string, any>, what: string) => {
    if (!reportId || !executionId) return;
    const pending: ActionRun = { run_id: `local-${Date.now()}`, status: 'preparing', tile_id: tile.id,
                                 label: what, message: `Preparing ${what} detail…` };
    upsert(pending);
    try {
      const { run } = await actionsApi.run(reportId, action.id, {
        execution_id: executionId, tile_id: tile.id, row_key: key,
        links: links ?? [], parameter_values: parameterValues ?? {},
      });
      setRuns(rs => [{ ...run, tile_id: tile.id }, ...rs.filter(x => x.run_id !== pending.run_id && x.run_id !== run.run_id)]);
      if (!TERMINAL.includes(run.status)) poll(run.run_id);
    } catch (e: any) {
      setRuns(rs => [{ ...pending, status: 'failed', message: e?.message || 'The detail could not be prepared.' },
        ...rs.filter(x => x.run_id !== pending.run_id)]);
    }
  }, [reportId, executionId, links, parameterValues, upsert, poll]);

  const [popup, setPopup] = useState<PopupState | null>(null);
  const openPopup = useCallback((action: CanvasAction, tile: CanvasTile, key: Record<string, any>, what: string) => {
    if (!reportId || !executionId) return;
    setPopup({ action, tileId: tile.id, what, body: {
      execution_id: executionId, tile_id: tile.id, row_key: key,
      links: links ?? [], parameter_values: parameterValues ?? {},
    } });
  }, [reportId, executionId, links, parameterValues]);
  /** "Send to Download Centre" from the popup: the tile shows the note, as for a file click */
  const track = useCallback((run: ActionRun, tileId: string) => {
    upsert({ ...run, tile_id: tileId });
    if (!TERMINAL.includes(run.status)) poll(run.run_id);
  }, [upsert, poll]);

  const dismiss = useCallback((runId: string) => setRuns(rs => rs.filter(r => r.run_id !== runId)), []);
  const value = useMemo(() => ({ reportId, actions, executionId, runs, start, openPopup, dismiss }),
    [reportId, actions, executionId, runs, start, openPopup, dismiss]);
  return (
    <CanvasActionsContext.Provider value={value}>
      {children}
      {popup && reportId && (
        <DetailPopup reportId={reportId} action={popup.action} what={popup.what} body={popup.body}
          onBackground={run => track(run, popup.tileId)} onClose={() => setPopup(null)} />
      )}
    </CanvasActionsContext.Provider>
  );
}

const FORMATS: { format: DetailFormat; label: string }[] = [
  { format: 'csv', label: 'Download CSV' },
  { format: 'xlsx', label: 'Download Excel' },
  { format: 'parquet', label: 'Download Parquet' },
];

/**
 * The detail POPUP (2026-10-31): the clicked row's detail read once by the
 * server (from the Published API or the dataset's query, as the person), paged
 * on the server, with what was sent and from where, and every download --
 * CSV / Excel / Parquet of ALL its rows (the same rows), or the Download Centre
 * for a big one (a background file with the tile note and the bell).
 */
export function DetailPopup({ reportId, action, what, body, onBackground, onClose }: {
  reportId: number; action: CanvasAction; what: string; body: any;
  onBackground: (run: ActionRun) => void; onClose: () => void;
}) {
  const [view, setView] = useState<DetailView | null>(null);
  const [runId, setRunId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tooBig, setTooBig] = useState(false);
  const [pageSize, setPageSize] = useState(50);
  const [busy, setBusy] = useState<string>('');
  const [note, setNote] = useState<{ severity: 'success' | 'info' | 'warning'; text: string } | null>(null);
  const bodyKey = JSON.stringify(body);
  useEffect(() => {
    let off = false;
    setLoading(true); setError(''); setTooBig(false);
    actionsApi.view(reportId, action.id, JSON.parse(bodyKey)).then(r => {
      if (off) return;
      setView(r.view); setRunId(r.run.run_id); setLoading(false);
    }).catch((e: any) => {
      if (off) return;
      setError(e?.message || 'The detail could not be read.');
      setRunId(e?.payload?.run_id ?? null);
      setTooBig(!!e?.payload?.too_big);
      setLoading(false);
    });
    return () => { off = true; };
  }, [reportId, action.id, bodyKey]);

  const goTo = (page: number, size = view?.page_size ?? pageSize) => {
    if (!runId) return;
    setLoading(true);
    actionsApi.rows(reportId, runId, page, size).then(r => { setView(r.view); setLoading(false); })
      .catch((e: any) => { setError(e?.message || 'The page could not be read.'); setLoading(false); });
  };
  const download = async (format: DetailFormat) => {
    if (!runId) return;
    setBusy(format); setNote(null);
    try {
      const res = await actionsApi.file(reportId, runId, { format, deliver: 'now' });
      const run = res.run;
      if (res.background) {
        // more rows than the popup read: the whole file is made in the Download Centre
        onBackground(run);
        setNote({ severity: 'info', text: res.message || 'The file is being made in the Download Centre. You will be told when it is ready.' });
        return;
      }
      if (run.download_id) await openDownload(`/api/downloads/${run.download_id}/download`);
      setNote({ severity: 'success', text: run.message || `${run.file_name} is downloaded.` });
    } catch (e: any) {
      setNote({ severity: 'warning', text: e?.message || 'The file could not be made.' });
    } finally { setBusy(''); }
  };
  const toCentre = async () => {
    if (!runId) return;
    setBusy('centre'); setNote(null);
    try {
      const { run } = await actionsApi.file(reportId, runId, { format: 'csv', deliver: 'download_centre' });
      onBackground(run);
      setNote({ severity: 'info', text: 'The file is being made in the Download Centre. You will be told when it is ready.' });
    } catch (e: any) {
      setNote({ severity: 'warning', text: e?.message || 'The file could not be started.' });
    } finally { setBusy(''); }
  };
  const title = view?.title || `${what} detail`;
  const canFile = !!runId && !!view && !tooBig;
  return (
    <AppDialog open onClose={onClose} size="lg" testId="detail-popup" title={title}
      secondaryActions={<>
        {FORMATS.map(f => (
          <Button key={f.format} size="small" disabled={!canFile || !!busy} onClick={() => download(f.format)}
            data-testid={`detail-download-${f.format}`}>{busy === f.format ? 'Making the file…' : f.label}</Button>
        ))}
        <Button size="small" disabled={!runId || !!busy} onClick={toCentre} data-testid="detail-send-centre">
          Send to Download Centre
        </Button>
      </>}
      actions={<Button onClick={onClose} data-testid="detail-popup-close">Close</Button>}>
        {loading && !view && <Typography variant="body2" data-testid="detail-popup-loading">Reading the detail…</Typography>}
        {error && <Alert severity="warning" sx={{ mb: 1 }} data-testid="detail-popup-error">{error}</Alert>}
        {view && (
          <>
            <Typography variant="body2" sx={{ mb: 1 }} data-testid="detail-popup-words">{view.words}</Typography>
            <Box sx={{ overflow: 'auto', maxHeight: '50vh' }}>
              <Table size="small" stickyHeader aria-label={title} data-testid="detail-popup-table">
                <TableHead><TableRow>{view.columns.map(c => <TableCell key={c.name} sx={{ fontWeight: 700 }} title={c.name}>{c.label || c.name}</TableCell>)}</TableRow></TableHead>
                <TableBody>
                  {view.rows.map((r, i) => (
                    <TableRow key={i}>{r.map((v, j) => <TableCell key={j}>{v == null ? '' : String(v)}</TableCell>)}</TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
            {view.shown_rows > 0 && (
              <TablePagination component="div" count={view.shown_rows} page={Math.max(0, view.page - 1)}
                rowsPerPage={view.page_size} rowsPerPageOptions={[25, 50, 100, 500]}
                onPageChange={(_e, p) => goTo(p + 1)}
                onRowsPerPageChange={e => { const n = Number(e.target.value); setPageSize(n); goTo(1, n); }}
                labelRowsPerPage="Rows on a page" data-testid="detail-popup-pages" />
            )}
            <Divider sx={{ my: 1 }} />
            <Box data-testid="detail-popup-sent">
              <Typography variant="caption" color="text.secondary">What was asked for</Typography>
              {view.sent.sent.map(s => <Typography key={s.target} variant="body2">{s.words}</Typography>)}
              {view.sent.not_sent.map(s => <Typography key={s.target} variant="body2" color="text.secondary">{s.words}</Typography>)}
              <Typography variant="caption" color="text.secondary" component="div" data-testid="detail-popup-road">
                {sourceOf(action) === 'query' ? 'Read by running the dataset’s query as you.' : 'Read from the Published API as you.'}
                {view.sent.sent.some(s => s.from === 'report') ? ' The report’s own parameters and filters applied too (listed above).' : ''}
              </Typography>
            </Box>
          </>
        )}
        {note && <Alert severity={note.severity} sx={{ mt: 1 }} data-testid="detail-popup-note">{note.text}</Alert>}
    </AppDialog>
  );
}

/** The preview popup: the first 100 rows of the file, from the Download Centre. */
export function DetailPreviewDialog({ fileId, title, onClose }: { fileId: string | null; title: string; onClose: () => void }) {
  const [state, setState] = useState<{ loading: boolean; error: string; columns: string[]; rows: any[][]; total: number | null }>(
    { loading: false, error: '', columns: [], rows: [], total: null });
  useEffect(() => {
    if (!fileId) return;
    let off = false;
    setState(s => ({ ...s, loading: true, error: '' }));
    actionsApi.preview(fileId).then((p: any) => {
      if (off) return;
      const columns: string[] = (p?.columns || []).map((c: any) => (typeof c === 'string' ? c : c?.name ?? String(c)));
      const rows: any[][] = (p?.rows || []).map((r: any) => (Array.isArray(r) ? r : columns.map(c => r?.[c])));
      setState({ loading: false, error: '', columns, rows, total: typeof p?.total_rows === 'number' ? p.total_rows : null });
    }).catch((e: any) => { if (!off) setState(s => ({ ...s, loading: false, error: e?.message || 'The preview could not be read.' })); });
    return () => { off = true; };
  }, [fileId]);
  return (
    <AppDialog open={!!fileId} onClose={onClose} size="lg" testId="action-preview-dialog" title={title}
      actions={<Button onClick={onClose}>Close</Button>}>
        {state.loading && <Typography variant="body2">Reading the file…</Typography>}
        {state.error && <Alert severity="warning">{state.error}</Alert>}
        {!state.loading && !state.error && (
          <>
            <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 1 }}>
              {state.total != null && state.total > state.rows.length
                ? `The first ${state.rows.length.toLocaleString()} of ${state.total.toLocaleString()} rows.`
                : `${state.rows.length.toLocaleString()} rows.`}
            </Typography>
            <Box sx={{ overflow: 'auto', maxHeight: '60vh' }}>
              <Table size="small" stickyHeader aria-label={title}>
                <TableHead><TableRow>{state.columns.map(c => <TableCell key={c} sx={{ fontWeight: 700 }}>{c}</TableCell>)}</TableRow></TableHead>
                <TableBody>
                  {state.rows.map((r, i) => (
                    <TableRow key={i}>{r.map((v, j) => <TableCell key={j}>{v == null ? '' : String(v)}</TableCell>)}</TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
          </>
        )}
    </AppDialog>
  );
}

/** One tile's note: "Preparing ...", then the file with Preview / Download / Download Centre. */
function RunNote({ run, onPreview, onDismiss }: { run: ActionRun; onPreview: (r: ActionRun) => void; onDismiss: () => void }) {
  const navigate = useNavigate();
  const [dlError, setDlError] = useState('');
  if (run.status === 'preparing') {
    return <Alert severity="info" sx={{ py: 0, mt: 0.5 }} data-testid="action-note-preparing">{run.message || `Preparing ${run.label} detail…`}</Alert>;
  }
  if (run.status === 'ready' && run.download_id) {
    return (
      <Alert severity="success" sx={{ py: 0, mt: 0.5 }} onClose={onDismiss} data-testid="action-note-ready">
        <Typography variant="body2" component="span" data-testid="action-note-file">
          {run.label} detail is ready — {run.file_name} · {(run.row_count ?? 0).toLocaleString()} rows · {run.size_words || sizeWords(run.file_size_bytes)}
        </Typography>
        {run.total_rows != null && run.row_count != null && run.total_rows > run.row_count && (
          <Typography variant="caption" component="div">The API gives at most {run.row_count.toLocaleString()} rows in one file; it has {run.total_rows.toLocaleString()}.</Typography>
        )}
        <Stack direction="row" gap={1} sx={{ mt: 0.5 }}>
          <Button size="small" onClick={() => onPreview(run)} data-testid="action-preview">Preview</Button>
          <Button size="small" onClick={() => { setDlError(''); openDownload(`/api/downloads/${run.download_id}/download`).catch((e: any) => setDlError(e?.message || 'The file could not be downloaded.')); }}
            data-testid="action-download">Download</Button>
          <Button size="small" onClick={() => navigate('/downloads')} data-testid="action-download-centre">Download Centre</Button>
        </Stack>
        {dlError && <Typography variant="caption" color="error">{dlError}</Typography>}
      </Alert>
    );
  }
  return (
    <Alert severity={run.status === 'empty' ? 'info' : 'warning'} sx={{ py: 0, mt: 0.5 }} onClose={onDismiss} data-testid={`action-note-${run.status}`}>
      {run.message || 'The detail could not be prepared.'}
    </Alert>
  );
}

/**
 * A tile's actions: `cell` puts the ⤓ link beside a value, `chartProps` adds
 * the right-click menu to a chart, `ui` is the tile's notes + menu + preview.
 * Without a provider (a share link, the builder) every part is a no-op.
 */
export function useCanvasTileActions(tile: CanvasTile, cols: Map<number, CanvasColumn>) {
  const ctx = useContext(CanvasActionsContext);
  const [menu, setMenu] = useState<{ x: number; y: number; row: Record<string, any> } | null>(null);
  const [preview, setPreview] = useState<ActionRun | null>(null);
  const tileActions = useMemo(() => (ctx ? actionsOn(ctx.actions, tile.id) : []), [ctx, tile.id]);
  const live = !!ctx && !!ctx.executionId && tileActions.length > 0;

  const what = useCallback((action: CanvasAction, row: Record<string, any>) => {
    const p = action.params.find(x => x.from === 'row' && x.column_id != null);
    const c = p ? cols.get(p.column_id!) : undefined;
    const v = c ? row[c.physical_name] : undefined;
    return `${c?.label ?? 'Row'} ${v == null ? '' : String(v)}`.trim();
  }, [cols]);

  const fire = useCallback((action: CanvasAction, row: Record<string, any>) => {
    if (showOf(action) === 'popup') ctx?.openPopup(action, tile, rowKey(tile, cols, row), what(action, row));
    else ctx?.start(action, tile, rowKey(tile, cols, row), what(action, row));
  }, [ctx, tile, cols, what]);

  const cell = useCallback((row: Record<string, any>, col: CanvasColumn | undefined, content: React.ReactNode) => {
    if (!live || !col) return content;
    const here = actionsOn(ctx!.actions, tile.id, col.id).filter(a => a.on.some(o => o.tile_id === tile.id && o.column_id === col.id));
    if (!here.length || row[col.physical_name] == null) return content;
    // 2026-11-01 -- the VALUE itself opens the first action (the lead clicked
    // "BK0218" and the row's cross-filter won); the icons stay for each action.
    // The click never reaches the row, so a linked tile is not re-filtered.
    const first = here[0];
    return (
      <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.5 }}>
        <Tooltip title={`Opens: ${first.label}`}>
          <Box component="button" type="button" data-testid={`action-value-${first.id}`}
            aria-label={`${first.label} — ${what(first, row)}`}
            onClick={e => { e.stopPropagation(); fire(first, row); }}
            sx={{ all: 'unset', cursor: 'pointer', color: 'primary.main', textDecoration: 'underline',
                  textDecorationStyle: 'dotted', textUnderlineOffset: 3, '&:hover': { textDecorationStyle: 'solid' } }}>
            {content}
          </Box>
        </Tooltip>
        {here.map(a => (
          <Tooltip key={a.id} title={`${a.label}: ${what(a, row)}`}>
            <IconButton size="small" sx={{ p: 0.25 }} aria-label={`${a.label} — ${what(a, row)}`}
              data-testid={`action-link-${a.id}`} onClick={e => { e.stopPropagation(); fire(a, row); }}>
              {showOf(a) === 'popup' ? <DetailIcon sx={{ fontSize: 16 }} /> : <DownloadIcon sx={{ fontSize: 16 }} />}
            </IconButton>
          </Tooltip>
        ))}
      </Box>
    );
  }, [live, ctx, tile.id, what, fire]);

  /** for a recharts chart: right-click a bar / slice / point -> the actions for its row */
  const chartProps = useCallback((rows: Record<string, any>[]) => {
    if (!live) return {};
    return {
      onContextMenu: (state: any, e: any) => {
        const i = Number(state?.activeIndex ?? state?.activeTooltipIndex);
        const row = Number.isInteger(i) ? rows[i] : undefined;
        if (!row) return;
        e?.preventDefault?.();
        setMenu({ x: e?.clientX ?? 0, y: e?.clientY ?? 0, row });
      },
    };
  }, [live]);

  /** open the menu for one row at the pointer (a treemap cell, a radar point ...) */
  const openAt = useCallback((e: any, row: Record<string, any> | undefined) => {
    if (!live || !row) return;
    e?.preventDefault?.();
    e?.stopPropagation?.();
    setMenu({ x: e?.clientX ?? 0, y: e?.clientY ?? 0, row });
  }, [live]);

  /**
   * For a recharts ITEM (a scatter point, a funnel step, a waterfall bar):
   * right-click -> the actions for its row.  recharts calls an item's handler
   * with (entry, index, event); `rowOf(index, entry)` names the row.
   */
  const itemProps = useCallback((rowOf: (index: number, entry?: any) => Record<string, any> | undefined) => {
    if (!live) return {};
    return {
      onContextMenu: (...args: any[]) => {
        const e = args.find(a => a && typeof a === 'object' && typeof a.preventDefault === 'function');
        const i = args.find(a => typeof a === 'number');
        openAt(e, rowOf(Number(i), args[0]));
      },
    };
  }, [live, openAt]);

  const mine = ctx ? ctx.runs.filter(r => r.tile_id === tile.id) : [];
  const ui = ctx ? (
    <>
      {mine.length > 0 && (
        <Box data-testid={`action-notes-${tile.id}`}>
          {mine.slice(0, 2).map(r => <RunNote key={r.run_id} run={r} onPreview={setPreview} onDismiss={() => ctx.dismiss(r.run_id)} />)}
        </Box>
      )}
      <Menu open={!!menu} onClose={() => setMenu(null)} anchorReference="anchorPosition"
        anchorPosition={menu ? { top: menu.y, left: menu.x } : undefined} data-testid="action-menu">
        {menu && tileActions.map(a => (
          <MenuItem key={a.id} onClick={() => { fire(a, menu.row); setMenu(null); }}>
            {a.label}: {what(a, menu.row)}
          </MenuItem>
        ))}
      </Menu>
      <DetailPreviewDialog fileId={preview?.download_id ?? null} title={preview ? `${preview.file_name} — first 100 rows` : ''}
        onClose={() => setPreview(null)} />
    </>
  ) : null;
  /** the drill's lowest level (canvasDrill.tsx): open the tile's FIRST action for a row; false = none */
  const openFirst = useCallback((row: Record<string, any>) => {
    const a = tileActions[0];
    if (!live || !a) return false;
    fire(a, row);
    return true;
  }, [live, tileActions, fire]);

  return { cell, chartProps, itemProps, openAt, openFirst, live, ui };
}

// ── the builder ────────────────────────────────────────────────────────────

interface EditorProps {
  reportId: number | null;
  canvas: ReportCanvas;
  setCanvas: (f: (c: ReportCanvas) => ReportCanvas) => void;
  cols: Map<number, CanvasColumn>;
  /** the report's parameters (name + label) */
  parameters: { name: string; label?: string }[];
  reportCode?: string;
  /** the report's dataset: the default of 'also apply the report's parameters' (on for the same dataset) */
  reportDatasetId?: number | null;
}

const NOT_SENT = '';

/** The names a source takes, for the mapping rows: an API's parameters and
 *  `filter.<col>`, or a dataset's columns and the conditions of its query. */
export function targetNames(action: CanvasAction, api: ActionApi | undefined, ds: ActionDataset | undefined):
  { name: string; required: boolean; label: string }[] {
  if (sourceOf(action) === 'query') {
    if (!ds) return [];
    return [...ds.columns.map(c => ({ name: c.name, required: false, label: `column ${c.label}` })),
            ...ds.conditions.map(c => ({ name: c.name, required: false, label: c.words }))];
  }
  if (!api) return [];
  return [...api.params.map(p => ({ name: p.name, required: p.required, label: p.label || p.name })),
          ...api.filters.map(f => ({ name: f.name, required: false, label: `filter on ${f.column}` }))];
}

/**
 * Actions of the canvas, in the builder's properties panel (2026-10-31: one
 * model, two roads).  Pick where the detail comes from -- a Published API (only
 * the ones you may call) or a query on a dataset (only the ones you may read)
 * -- then for each of ITS names where the value comes from: a column of the
 * clicked row, a report parameter, a linked filter, or a fixed value; then what
 * a click does: show the detail in a popup (with every download) or make a file.
 * Names are never typed.
 */
export function CanvasActionsEditor({ reportId, canvas, setCanvas, cols, parameters, reportCode, reportDatasetId }: EditorProps) {
  const actions = readActions((canvas as any).actions);
  const [apis, setApis] = useState<ActionApi[] | null>(null);
  const [apiError, setApiError] = useState('');
  const [datasets, setDatasets] = useState<{ id: number; name: string }[] | null>(null);
  const [dsInfo, setDsInfo] = useState<Record<number, ActionDataset | string>>({});
  const [open, setOpen] = useState<number | null>(null);
  useEffect(() => {
    if (!reportId) return;
    actionsApi.listApis(reportId).then(r => setApis(r.items || []))
      .catch((e: any) => setApiError(e?.message || 'The Published APIs could not be listed.'));
    actionsApi.listDatasets(reportId).then(r => setDatasets(r.items || []))
      .catch((e: any) => setApiError(e?.message || 'The datasets could not be listed.'));
  }, [reportId]);
  // each dataset an action runs: its columns and conditions (once)
  const wantDs = actions.filter(a => sourceOf(a) === 'query' && a.dataset_id != null).map(a => a.dataset_id as number);
  const wantKey = [...new Set(wantDs)].sort().join(',');
  useEffect(() => {
    if (!reportId || !wantKey) return;
    for (const id of wantKey.split(',').map(Number)) {
      if (dsInfo[id] !== undefined) continue;
      actionsApi.dataset(reportId, id).then(d => setDsInfo(m => ({ ...m, [id]: d })))
        .catch((e: any) => setDsInfo(m => ({ ...m, [id]: e?.message || 'This dataset could not be read.' })));
    }
  }, [reportId, wantKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const write = (next: CanvasAction[]) => setCanvas(c => ({ ...(c as any), actions: next }) as ReportCanvas);
  const update = (i: number, f: (a: CanvasAction) => CanvasAction) => write(actions.map((a, j) => (j === i ? f(a) : a)));
  const dimTiles = canvas.tiles.filter(t => t.kind !== 'report' && rowFieldIds(t).length > 0);

  const add = () => {
    const first = dimTiles[0];
    const col = first ? rowFieldIds(first)[rowFieldIds(first).length - 1] : undefined;
    write([...actions, {
      id: `detail_${Date.now().toString(36)}`, kind: 'detail_download', label: 'Show detail', view_slug: '',
      source: 'published_api', show: 'popup',
      params: [], file_name: null, on: first ? [{ tile_id: first.id, column_id: col ?? null }] : [],
    }]);
    setOpen(actions.length);
  };

  if (!reportId) {
    return <Typography variant="body2" color="text.secondary">Save the report first; then a click can show or download the detail of a row.</Typography>;
  }
  return (
    <Box data-testid="canvas-actions-editor">
      <Stack direction="row" alignItems="center" sx={{ mb: 0.5 }}>
        <Typography variant="subtitle2" sx={{ flex: 1 }}>Actions on a click</Typography>
        <Button size="small" startIcon={<AddIcon />} onClick={add} data-testid="canvas-action-add">Detail on a click</Button>
      </Stack>
      {apiError && <Alert severity="warning" sx={{ py: 0 }}>{apiError}</Alert>}
      {actions.length === 0 && (
        <Typography variant="body2" color="text.secondary">
          None yet. A detail action puts a link on a column (e.g. Book ID): a click shows that row&apos;s detail
          in a popup, from a Published API or a dataset&apos;s query, with CSV, Excel and Parquet downloads.
        </Typography>
      )}
      {actions.map((a, i) => {
        const road = sourceOf(a);
        const api = apis?.find(x => x.slug === a.view_slug);
        const dsRaw = a.dataset_id != null ? dsInfo[a.dataset_id] : undefined;
        const ds = typeof dsRaw === 'object' ? dsRaw : undefined;
        const dsName = datasets?.find(d => d.id === a.dataset_id)?.name;
        const names = targetNames(a, api, ds);
        const picked = road === 'query' ? !!ds : !!api;
        const firstRow = a.params.find(p => p.from === 'row' && p.column_id != null);
        const preview = fileNamePreview(a.file_name, {
          report_code: reportCode || 'REPORT', value: firstRow ? `<${cols.get(firstRow.column_id!)?.label ?? 'value'}>` : '<value>',
          business_date: '2026-07-31', label: a.label,
        });
        const setParam = (name: string, p: Omit<ActionParam, 'target' | 'api_param'> | null) => update(i, x => {
          const old = x.params.find(q => targetOf(q) === name);
          // a saved entry keeps its spelling (api_param); a new one names its target
          const key = old && old.api_param && !old.target ? { api_param: name } : { target: name };
          return { ...x, params: [...x.params.filter(q => targetOf(q) !== name), ...(p ? [{ ...key, ...p } as ActionParam] : [])] };
        });
        return (
          <Box key={a.id} sx={{ border: 1, borderColor: 'divider', borderRadius: 1, p: 1, mb: 1 }} data-testid={`canvas-action-${a.id}`}>
            <Stack direction="row" alignItems="center" gap={1}>
              <Link component="button" variant="body2" onClick={() => setOpen(open === i ? null : i)} sx={{ flex: 1, textAlign: 'left' }}>
                {a.label || 'Unnamed action'}{road === 'query' ? (dsName ? ` → ${dsName}` : '') : (api ? ` → ${api.name}` : '')}
              </Link>
              <Tooltip title="Remove this action">
                <IconButton size="small" aria-label={`Remove action ${a.label}`} onClick={() => write(actions.filter((_, j) => j !== i))}>
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            </Stack>
            {open === i && (
              <Box sx={{ mt: 1 }}>
                <TextField size="small" fullWidth label="Name on the link" value={a.label} sx={{ mb: 1 }}
                  onChange={e => update(i, x => ({ ...x, label: e.target.value }))} />
                <TextField select size="small" fullWidth label="Where the detail comes from" value={road} sx={{ mb: 1 }}
                  inputProps={{ 'data-testid': 'canvas-action-source' }}
                  onChange={e => update(i, x => ({ ...x, source: e.target.value as ActionRoad, params: [],
                    ...(e.target.value === 'query' ? { view_slug: '' } : { dataset_id: null }) }))}>
                  <MenuItem value="published_api">A Published API</MenuItem>
                  <MenuItem value="query">Run a query on a dataset</MenuItem>
                </TextField>
                {road === 'published_api' ? (
                  <TextField select size="small" fullWidth label="Published API" value={a.view_slug} sx={{ mb: 1 }}
                    inputProps={{ 'data-testid': 'canvas-action-api' }}
                    helperText={apis && apis.length === 0 ? 'You may not call any Published API.' : 'Only the APIs you may call are listed.'}
                    onChange={e => update(i, x => ({ ...x, view_slug: e.target.value, params: [] }))}>
                    {(apis || []).map(v => <MenuItem key={v.slug} value={v.slug}>{v.name}</MenuItem>)}
                    {a.view_slug && !api && <MenuItem value={a.view_slug}>{a.view_slug} (not available to you)</MenuItem>}
                  </TextField>
                ) : (
                  <TextField select size="small" fullWidth label="Dataset" value={a.dataset_id ?? ''} sx={{ mb: 1 }}
                    inputProps={{ 'data-testid': 'canvas-action-dataset' }}
                    helperText={typeof dsRaw === 'string' ? dsRaw
                      : 'Its query runs as the person who clicks: their access and row security apply.'}
                    onChange={e => update(i, x => ({ ...x, dataset_id: Number(e.target.value), params: [] }))}>
                    {(datasets || []).map(d => <MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
                    {a.dataset_id != null && !dsName && <MenuItem value={a.dataset_id}>Dataset {a.dataset_id} (not available to you)</MenuItem>}
                  </TextField>
                )}
                {picked && (
                  <>
                    <Typography variant="caption" color="text.secondary">
                      {road === 'query' ? 'What the query is narrowed by' : 'What the API is given'}
                    </Typography>
                    {road === 'query' && ds && ds.conditions.length === 0 && ds.conditions_reason && (
                      <Typography variant="caption" color="text.secondary" component="div">{ds.conditions_reason}</Typography>
                    )}
                    {names.map(n => {
                      const p = a.params.find(q => targetOf(q) === n.name);
                      const choice = !p ? NOT_SENT : p.from === 'row' ? `row:${p.column_id}` : p.from === 'link' ? `link:${p.column_id}`
                        : p.from === 'parameter' ? `parameter:${p.parameter}` : 'fixed';
                      return (
                        <Stack key={n.name} direction="row" gap={1} alignItems="center" sx={{ mt: 0.75 }} data-testid={`canvas-action-target-${n.name}`}>
                          <Typography variant="body2" sx={{ width: 140, flexShrink: 0 }} noWrap title={n.label}>
                            {n.name}{n.required ? ' *' : ''}
                          </Typography>
                          <TextField select size="small" fullWidth value={choice} inputProps={{ 'aria-label': `Value for ${n.name}` }}
                            onChange={e => {
                              const v = e.target.value;
                              if (v === NOT_SENT) return setParam(n.name, null);
                              const [kind, rest] = [v.split(':')[0], v.split(':').slice(1).join(':')];
                              if (kind === 'row' || kind === 'link') return setParam(n.name, { from: kind as ActionSource, column_id: Number(rest) });
                              if (kind === 'parameter') return setParam(n.name, { from: 'parameter', parameter: rest });
                              return setParam(n.name, { from: 'fixed', value: p?.value ?? '' });
                            }}>
                            <MenuItem value={NOT_SENT}>Not sent</MenuItem>
                            {[...cols.values()].map(c => <MenuItem key={`r${c.id}`} value={`row:${c.id}`}>Clicked row: {c.label}</MenuItem>)}
                            {parameters.map(q => <MenuItem key={`p${q.name}`} value={`parameter:${q.name}`}>Report parameter: {q.label || q.name}</MenuItem>)}
                            {[...cols.values()].map(c => <MenuItem key={`l${c.id}`} value={`link:${c.id}`}>Linked filter: {c.label}</MenuItem>)}
                            <MenuItem value="fixed">A fixed value</MenuItem>
                          </TextField>
                          {p?.from === 'fixed' && (
                            <TextField size="small" label="Value" value={p.value ?? ''} sx={{ width: 140 }}
                              onChange={e => setParam(n.name, { from: 'fixed', value: e.target.value })} />
                          )}
                        </Stack>
                      );
                    })}
                  </>
                )}
                {road === 'query' && (
                  <FormControlLabel sx={{ display: 'flex', mt: 0.5 }}
                    control={<Checkbox size="small" checked={a.pass_parameters ?? (reportDatasetId != null && a.dataset_id === reportDatasetId)}
                      onChange={e => update(i, x => ({ ...x, pass_parameters: e.target.checked }))}
                      inputProps={{ 'data-testid': 'canvas-action-pass-parameters' } as any} />}
                    label={<Typography variant="body2">Also narrow the detail by the report&apos;s own parameters and filters (the values the run used, read by the server; the popup lists which applied)</Typography>} />
                )}
                <Divider sx={{ my: 1 }} />
                <TextField select size="small" fullWidth label="When the link is clicked" value={showOf(a)} sx={{ mb: 1 }}
                  inputProps={{ 'data-testid': 'canvas-action-show' }}
                  onChange={e => update(i, x => ({ ...x, show: e.target.value as ActionShow }))}>
                  <MenuItem value="popup">Show the detail in a popup (with CSV, Excel and Parquet downloads)</MenuItem>
                  <MenuItem value="download">Make a CSV file in the Download Centre</MenuItem>
                </TextField>
                <TextField size="small" fullWidth label="File name" value={a.file_name ?? ''} placeholder={DEFAULT_FILE_NAME}
                  helperText={`The file will be called ${preview}`} sx={{ mb: 1 }}
                  onChange={e => update(i, x => ({ ...x, file_name: e.target.value || null }))} />
                <Typography variant="caption" color="text.secondary">Shown on</Typography>
                {dimTiles.map(t => rowFieldIds(t).map(cid => {
                  const on = a.on.some(o => o.tile_id === t.id && o.column_id === cid);
                  return (
                    <FormControlLabel key={`${t.id}-${cid}`} sx={{ display: 'flex' }}
                      control={<Checkbox size="small" checked={on} onChange={() => update(i, x => ({
                        ...x, on: on ? x.on.filter(o => !(o.tile_id === t.id && o.column_id === cid))
                          : [...x.on, { tile_id: t.id, column_id: cid }],
                      }))} />}
                      label={<Typography variant="body2">{t.title || t.id}: {cols.get(cid)?.label ?? `#${cid}`}</Typography>} />
                  );
                }))}
              </Box>
            )}
          </Box>
        );
      })}
    </Box>
  );
}
