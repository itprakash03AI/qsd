/**
 * Table rows drawn only where the eye is (2026-10-30).
 *
 * Inside a <TableBody>: the rows on screen (plus OVERSCAN_ROWS each side) are
 * real <tr>s, measured as they draw (a section header or a subtotal row may be
 * taller); the rest is one spacer row above and one below that keep the
 * scroll bar honest.  The table stays a table: its sticky header, its column
 * widths, its row stripes (each row keeps its own index), aria-rowcount on the
 * <table> -- only the DOM is smaller.
 *
 * Fewer than VIRTUALIZE_MIN_ROWS rows are drawn whole (nothing to gain, and a
 * small table behaves exactly as before).  Where the scroll box has no size
 * yet (not laid out, a test page) the visible height is taken as
 * FALLBACK_VIEW_PX, so it still draws a screenful -- never nothing.
 */
import React, { useCallback } from 'react';
import { TableCell, TableRow } from '@mui/material';
import { observeElementRect, useVirtualizer, type Virtualizer } from '@tanstack/react-virtual';

/** at or above this many rows the table body is virtualized */
export const VIRTUALIZE_MIN_ROWS = 200;
/** rows drawn beyond each edge of the visible window */
export const OVERSCAN_ROWS = 10;
/** an MUI size="small" row (px) until measured */
export const ESTIMATED_ROW_PX = 33;
/** the visible height assumed while the scroll box has none */
export const FALLBACK_VIEW_PX = 600;

interface Props {
  count: number;
  /** the scrolling element around the table (TableContainer / a tile's box) */
  scrollRef: React.RefObject<HTMLElement | null>;
  /** one row; it must return a TableRow (its ref and data-index are set here) */
  renderRow: (index: number) => React.ReactElement;
  colSpan: number;
  estimateRowPx?: number;
}

function observeWithFallback(instance: Virtualizer<any, any>, cb: (rect: { width: number; height: number }) => void) {
  return observeElementRect(instance, rect => cb(rect.height > 0 ? rect : { width: rect.width, height: FALLBACK_VIEW_PX }));
}

function Spacer({ height, colSpan, testid }: { height: number; colSpan: number; testid: string }) {
  if (height <= 0) return null;
  return (
    <TableRow aria-hidden="true" data-testid={testid} sx={{ height, '& td': { p: 0, border: 0 } }}>
      <TableCell colSpan={colSpan} />
    </TableRow>
  );
}

function Virtualized({ count, scrollRef, renderRow, colSpan, estimateRowPx }: Props) {
  const estimate = estimateRowPx ?? ESTIMATED_ROW_PX;
  const v = useVirtualizer({
    count,
    getScrollElement: () => scrollRef.current,
    estimateSize: () => estimate,
    // a row with no height yet (not laid out) keeps its estimate: a 0 would
    // put every row "on screen" and draw them all
    measureElement: el => {
      const h = el.getBoundingClientRect().height;
      return h > 0 ? h : estimate;
    },
    overscan: OVERSCAN_ROWS,
    observeElementRect: observeWithFallback,
    initialRect: { width: 0, height: FALLBACK_VIEW_PX },
  });
  const items = v.getVirtualItems();
  const total = v.getTotalSize();
  const padTop = items.length ? items[0].start : 0;
  const padBottom = items.length ? total - items[items.length - 1].end : 0;
  const measure = useCallback((el: Element | null) => { if (el) v.measureElement(el); }, [v]);
  return (
    <>
      <Spacer height={padTop} colSpan={colSpan} testid="virtual-rows-above" />
      {items.map(it => React.cloneElement(renderRow(it.index), { key: it.key, ref: measure, 'data-index': it.index }))}
      <Spacer height={padBottom} colSpan={colSpan} testid="virtual-rows-below" />
    </>
  );
}

export default function VirtualRows(props: Props) {
  if (props.count < VIRTUALIZE_MIN_ROWS) {
    return <>{Array.from({ length: props.count }, (_, i) => React.cloneElement(props.renderRow(i), { key: i }))}</>;
  }
  return <Virtualized {...props} />;
}
