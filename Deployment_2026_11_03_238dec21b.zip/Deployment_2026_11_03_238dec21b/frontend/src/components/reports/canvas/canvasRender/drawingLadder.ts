/**
 * The drawing ladder of a canvas tile (2026-10-30, the owner: "how html can
 * be faster n memory efficient ... vector based or what?").
 *
 * Rule: never send or draw more than the eye can see.
 *
 * - Up to SVG_MAX_MARKS marks a chart is SVG (recharts): crisp, hoverable,
 *   printable -- one DOM node per mark is cheap at this size.
 * - Above it the marks are painted on ONE <canvas> (2D): the page holds one
 *   element however many points there are.  The kinds the canvas painter
 *   draws are CANVAS_KINDS; any other kind stays SVG (it never reaches the
 *   ladder's top: its categories are capped at 500).
 * - A line / area never draws more than about one point per pixel of its
 *   width: LTTB (lttb.ts; the server's `max_points` when it can) keeps the
 *   shape -- first, last, highest, lowest.
 * - Above WEBGL_MIN_MARKS a scatter or a heat map is drawn by the graphics
 *   card (WebGL, webglPainter.ts): one buffer of floats, one draw call.  When
 *   the browser has no WebGL the tile takes the rung below (a scatter on the 2D
 *   canvas, a heat map as its table) -- never no tile.
 * - The server's PDF / Excel always draw SVG / native charts (their own LTTB:
 *   EXPORT_MAX_POINTS in core/reports/canvas_export.py).
 *
 * A mark is one drawn thing: a point of a line, a bar, a dot.  The count is
 * the SOURCE's (before down-sampling) -- the ladder is about how much data a
 * tile holds, so a 100,000-point line paints on canvas even though it is
 * drawn from ~1 point per pixel.
 */

/** above this many marks a tile paints on a canvas instead of SVG */
export const SVG_MAX_MARKS = 5_000;
/** a line / area keeps about this many points per pixel of its width */
export const POINTS_PER_PIXEL = 1;
/** the kinds the canvas painter draws */
export const CANVAS_KINDS = ['line', 'area', 'bar', 'scatter'] as const;
/** the kinds whose long series are down-sampled (one value, in order) */
export const DOWNSAMPLE_KINDS = ['line', 'area'];

/** at or above this many marks a scatter / heat map is painted with WebGL (when the browser has it) */
export const WEBGL_MIN_MARKS = 100_000;
/** the kinds the WebGL painter draws */
export const WEBGL_KINDS = ['scatter', 'heatmap'] as const;

export type Renderer = 'svg' | 'canvas' | 'webgl';

/** How many marks a chart of `categories` x `series` draws. */
export const markCount = (categories: number, series: number) => Math.max(0, categories) * Math.max(1, series);

/** SVG, canvas or WebGL for this tile.  `webgl` = the browser can draw with it
 *  (webglPainter.webglAvailable); without it a WebGL kind takes the rung below. */
export function chooseRenderer(kind: string, marks: number, opts: { webgl?: boolean } = {}): Renderer {
  if (opts.webgl && marks >= WEBGL_MIN_MARKS && (WEBGL_KINDS as readonly string[]).includes(kind)) return 'webgl';
  return marks > SVG_MAX_MARKS && (CANVAS_KINDS as readonly string[]).includes(kind) ? 'canvas' : 'svg';
}

/** The most points a line / area of this pixel width draws. */
export const maxPointsFor = (widthPx: number) => Math.max(16, Math.round(widthPx * POINTS_PER_PIXEL));
