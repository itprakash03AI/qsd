/**
 * The canvas painter (2026-10-30): a line / area / bar / scatter chart painted
 * on ONE <canvas> 2D context -- the top rung of the drawing ladder
 * (drawingLadder.ts), for tiles with more marks than SVG draws comfortably.
 *
 * Pure: `paintChart` takes any object with the 2D-context calls it uses
 * (`Paint2D`), so a test records every mark it would draw without a browser.
 * A line / area paints at most about one point per pixel of the plot's width
 * per series (LTTB: first, last, highest and lowest always kept).
 */
import { lttbIndices } from './lttb';
import { POINTS_PER_PIXEL } from './drawingLadder';

export type PaintKind = 'line' | 'area' | 'bar' | 'scatter';

export interface PaintSeries { name: string; color: string; values: ArrayLike<number | null>; }

export interface PaintSpec {
  kind: PaintKind;
  /** one label per position (line / area / bar); a scatter's point names */
  categories: string[];
  series: PaintSeries[];
  /** scatter: the across value of each point (series[0].values is up) */
  xs?: ArrayLike<number | null>;
}

/** The part of CanvasRenderingContext2D the painter uses. */
export interface Paint2D {
  fillStyle: any; strokeStyle: any; lineWidth: number; globalAlpha: number; font: string;
  textAlign: any; textBaseline: any;
  beginPath(): void; moveTo(x: number, y: number): void; lineTo(x: number, y: number): void;
  closePath(): void; stroke(): void; fill(): void;
  fillRect(x: number, y: number, w: number, h: number): void;
  clearRect(x: number, y: number, w: number, h: number): void;
  fillText(text: string, x: number, y: number): void;
  save(): void; restore(): void;
}

export interface PaintResult {
  /** marks actually painted (line vertices, bars, dots) */
  pointsDrawn: number;
  /** per series, the positions painted (line / area / bar) */
  kept: number[][];
  plot: { left: number; top: number; width: number; height: number };
  yMin: number; yMax: number;
}

export const PLOT_MARGIN = { left: 56, right: 10, top: 8, bottom: 22 };

const compact = (v: number) => {
  try { return v.toLocaleString(undefined, { notation: 'compact', maximumFractionDigits: 1 } as any); }
  catch { return String(Math.round(v)); }
};

function range(values: ArrayLike<number | null>[], withZero: boolean): [number, number] {
  let lo = Infinity; let hi = -Infinity;
  for (const vs of values) {
    for (let i = 0; i < vs.length; i++) {
      const v = vs[i];
      if (v === null || v === undefined || !Number.isFinite(v)) continue;
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
  }
  if (lo === Infinity) { lo = 0; hi = 1; }
  if (withZero) { lo = Math.min(lo, 0); hi = Math.max(hi, 0); }
  if (lo === hi) { lo -= 1; hi += 1; }
  return [lo, hi];
}

/** A no-op context: the painter's arithmetic without a canvas (counts only). */
export function countingContext(): Paint2D & { marks: number } {
  const c: any = { marks: 0, fillStyle: '', strokeStyle: '', lineWidth: 1, globalAlpha: 1, font: '', textAlign: '', textBaseline: '' };
  for (const m of ['beginPath', 'moveTo', 'lineTo', 'closePath', 'stroke', 'fill', 'fillRect', 'clearRect', 'fillText', 'save', 'restore']) {
    c[m] = () => {};
  }
  return c;
}

/** Paint the chart; returns what was painted. */
export function paintChart(ctx: Paint2D, spec: PaintSpec, width: number, height: number): PaintResult {
  const left = PLOT_MARGIN.left;
  const top = PLOT_MARGIN.top;
  const pw = Math.max(10, width - PLOT_MARGIN.left - PLOT_MARGIN.right);
  const ph = Math.max(10, height - PLOT_MARGIN.top - PLOT_MARGIN.bottom);
  const n = spec.kind === 'scatter' ? (spec.xs?.length ?? 0) : spec.categories.length;
  const [yMin, yMax] = range(spec.series.map(s => s.values), spec.kind === 'bar' || spec.kind === 'area');
  const yPx = (v: number) => top + ph - ((v - yMin) / (yMax - yMin)) * ph;
  const result: PaintResult = { pointsDrawn: 0, kept: [], plot: { left, top, width: pw, height: ph }, yMin, yMax };

  ctx.save();
  ctx.clearRect(0, 0, width, height);
  // the scale: four lines across, their values on the left
  ctx.font = '11px sans-serif';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';
  ctx.lineWidth = 1;
  for (let t = 0; t <= 4; t++) {
    const v = yMin + ((yMax - yMin) * t) / 4;
    const y = Math.round(yPx(v)) + 0.5;
    ctx.strokeStyle = '#e1e0d9';
    ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(left + pw, y); ctx.stroke();
    ctx.fillStyle = '#666';
    ctx.fillText(compact(v), left - 4, y);
  }

  if (spec.kind === 'scatter') {
    const xs = spec.xs ?? [];
    const [xMin, xMax] = range([xs], false);
    const ys = spec.series[0]?.values ?? [];
    ctx.fillStyle = spec.series[0]?.color ?? '#2a78d6';
    ctx.globalAlpha = 0.7;
    for (let i = 0; i < xs.length; i++) {
      const x = xs[i]; const y = ys[i];
      if (x === null || y === null || x === undefined || y === undefined) continue;
      ctx.fillRect(left + ((x - xMin) / (xMax - xMin)) * pw - 1.5, yPx(y) - 1.5, 3, 3);
      result.pointsDrawn++;
    }
    ctx.globalAlpha = 1;
    labelsX(ctx, [compact(xMin), compact(xMax)], left, top + ph, pw);
    ctx.restore();
    return result;
  }

  const xPx = (i: number) => n <= 1 ? left + pw / 2 : left + (i / (n - 1)) * pw;
  if (spec.kind === 'bar') {
    const groupW = pw / Math.max(1, n);
    const barW = Math.max(1, (groupW * 0.8) / Math.max(1, spec.series.length));
    const base = yPx(Math.max(yMin, Math.min(0, yMax)));
    spec.series.forEach((s, si) => {
      ctx.fillStyle = s.color;
      const kept: number[] = [];
      for (let i = 0; i < n; i++) {
        const v = s.values[i];
        if (v === null || v === undefined || !Number.isFinite(v)) continue;
        const x = left + i * groupW + groupW * 0.1 + si * barW;
        const y = yPx(v);
        ctx.fillRect(x, Math.min(y, base), barW, Math.max(1, Math.abs(base - y)));
        kept.push(i);
        result.pointsDrawn++;
      }
      result.kept.push(kept);
    });
  } else {
    const budget = Math.max(2, Math.round(pw * POINTS_PER_PIXEL));
    const base = yPx(Math.max(yMin, Math.min(0, yMax)));
    spec.series.forEach(s => {
      const idx = lttbIndices(s.values, budget);
      result.kept.push(idx);
      // runs between NULLs are drawn apart (a gap is a gap, never a slope)
      const runs: number[][] = [];
      let run: number[] = [];
      for (const i of idx) {
        const v = s.values[i];
        if (v === null || v === undefined || !Number.isFinite(v)) { if (run.length) runs.push(run); run = []; continue; }
        run.push(i);
      }
      if (run.length) runs.push(run);
      ctx.strokeStyle = s.color;
      ctx.lineWidth = 1.5;
      for (const r of runs) {
        if (spec.kind === 'area') {
          ctx.fillStyle = s.color;
          ctx.globalAlpha = 0.3;
          ctx.beginPath();
          ctx.moveTo(xPx(r[0]), base);
          for (const i of r) ctx.lineTo(xPx(i), yPx(s.values[i] as number));
          ctx.lineTo(xPx(r[r.length - 1]), base);
          ctx.closePath();
          ctx.fill();
          ctx.globalAlpha = 1;
        }
        ctx.beginPath();
        r.forEach((i, k) => {
          const x = xPx(i); const y = yPx(s.values[i] as number);
          if (k === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        });
        if (r.length === 1) ctx.fillRect(xPx(r[0]) - 1, yPx(s.values[r[0]] as number) - 1, 2, 2);
        ctx.stroke();
        result.pointsDrawn += r.length;
      }
    });
  }
  if (n > 0) {
    const picks = n === 1 ? [0] : [0, Math.floor((n - 1) / 2), n - 1];
    ctx.font = '11px sans-serif';
    ctx.fillStyle = '#666';
    ctx.textBaseline = 'top';
    picks.forEach((i, k) => {
      ctx.textAlign = k === 0 ? 'left' : k === picks.length - 1 ? 'right' : 'center';
      ctx.fillText(String(spec.categories[i] ?? '').slice(0, 24), spec.kind === 'bar' ? left + (i + 0.5) * (pw / n) : xPx(i), top + ph + 4);
    });
  }
  ctx.restore();
  return result;
}

function labelsX(ctx: Paint2D, words: string[], left: number, y: number, pw: number) {
  ctx.fillStyle = '#666';
  ctx.textBaseline = 'top';
  ctx.textAlign = 'left';
  ctx.fillText(words[0], left, y + 4);
  ctx.textAlign = 'right';
  ctx.fillText(words[1], left + pw, y + 4);
}

/** The position under a pixel x of the plot (for the hover readout). */
export function positionAt(px: number, spec: PaintSpec, width: number): number | null {
  const n = spec.categories.length;
  if (n === 0 || spec.kind === 'scatter') return null;
  const pw = Math.max(10, width - PLOT_MARGIN.left - PLOT_MARGIN.right);
  const f = (px - PLOT_MARGIN.left) / pw;
  if (f < 0 || f > 1) return null;
  return spec.kind === 'bar' ? Math.min(n - 1, Math.floor(f * n)) : Math.round(f * (n - 1));
}
