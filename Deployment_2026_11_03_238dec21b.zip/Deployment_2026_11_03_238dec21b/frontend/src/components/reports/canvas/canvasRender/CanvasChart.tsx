/**
 * A chart painted on ONE <canvas> (2026-10-30) -- the drawing ladder's top
 * rung (drawingLadder.ts).  The page holds one element however many marks the
 * tile has; a hover reads the value under the pointer; a legend in words
 * names each series.  `data-renderer="canvas"` and `data-points-drawn` say
 * what was painted (the e2e spec and the diagnostics read them).
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Box, Typography } from '@mui/material';
import { countingContext, paintChart, PaintResult, PaintSpec, positionAt } from './canvasPainter';

interface Props {
  spec: PaintSpec;
  width: number;
  height: number;
  /** a value in the tile's own format (the hover readout) */
  format?: (v: number | null) => string;
}

export default function CanvasChart({ spec, width, height, format }: Props) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const [hover, setHover] = useState<number | null>(null);
  const legendH = spec.series.length > 1 ? 20 : 0;
  const h = Math.max(60, height - legendH);
  // the painter's arithmetic once per spec / size: what it paints is known
  // even where the browser has no 2D context (a test, a print preview)
  const planned: PaintResult = useMemo(() => paintChart(countingContext(), spec, width, h), [spec, width, h]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let ctx: CanvasRenderingContext2D | null = null;
    try { ctx = el.getContext('2d'); } catch { ctx = null; }
    if (!ctx) return;
    const dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
    el.width = Math.round(width * dpr);
    el.height = Math.round(h * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    paintChart(ctx as any, spec, width, h);
  }, [spec, width, h]);

  const fmt = format ?? ((v: number | null) => (v == null ? '(no value)' : v.toLocaleString()));
  const readout = hover == null ? '' : `${spec.categories[hover] ?? ''}: ${spec.series
    .map(s => `${spec.series.length > 1 ? `${s.name} ` : ''}${fmt(s.values[hover] ?? null)}`).join(' · ')}`;

  return (
    <Box data-renderer="canvas" data-points-drawn={planned.pointsDrawn} data-testid="tile-canvas-chart"
      sx={{ position: 'relative' }}>
      <canvas ref={ref} width={width} height={h} role="img"
        aria-label={`${spec.kind} chart of ${spec.series.map(s => s.name).join(', ')}, ${spec.kind === 'scatter' ? spec.xs?.length ?? 0 : spec.categories.length} points`}
        style={{ width, height: h, display: 'block' }}
        onMouseMove={e => {
          const r = (e.target as HTMLCanvasElement).getBoundingClientRect();
          setHover(positionAt(e.clientX - r.left, spec, width));
        }}
        onMouseLeave={() => setHover(null)} />
      {legendH > 0 && (
        <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'nowrap', overflow: 'hidden', height: legendH, alignItems: 'center' }}>
          {spec.series.map(s => (
            <Typography key={s.name} variant="caption" noWrap sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <Box component="span" sx={{ width: 10, height: 10, bgcolor: s.color, display: 'inline-block' }} />{s.name}
            </Typography>
          ))}
        </Box>
      )}
      {readout && (
        <Typography variant="caption" component="div" noWrap data-testid="tile-canvas-readout"
          sx={{ position: 'absolute', top: 0, right: 0, maxWidth: '80%', px: 0.5, bgcolor: 'background.paper', opacity: 0.92, pointerEvents: 'none' }}>
          {readout}
        </Typography>
      )}
    </Box>
  );
}
