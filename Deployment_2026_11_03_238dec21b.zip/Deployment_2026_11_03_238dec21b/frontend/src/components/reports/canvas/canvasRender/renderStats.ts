/**
 * What drawing a tile cost (2026-10-30): the cube answer's bytes and format,
 * its rows, the renderer the ladder chose, the marks painted and the ms from
 * the answer arriving to the tile drawn.  Cheap: a Map and a listener list.
 *
 * Read by the canvas diagnostics (`subscribeRenderStats` / `renderStatsOf`)
 * and visible on every chart tile as data-* attributes
 * (data-renderer, data-render-ms, data-rows, data-bytes, data-format).
 */
export interface TileRenderStats {
  tileId: string;
  renderer: 'svg' | 'canvas' | 'webgl' | 'table';
  rows: number;
  /** rows the source had before down-sampling (the server's or ours) */
  sourceRows: number;
  marks: number;
  bytes: number | null;
  format: 'arrow' | 'json' | null;
  /** why an answer stayed JSON when Arrow was asked (e.g. "exact decimals: amount") */
  formatReason?: string | null;
  renderMs: number | null;
  at: number;
}

const stats = new Map<string, TileRenderStats>();
const listeners = new Set<(s: TileRenderStats) => void>();

export function recordRenderStats(s: TileRenderStats): void {
  stats.set(s.tileId, s);
  listeners.forEach(l => { try { l(s); } catch { /* a listener never breaks a tile */ } });
}

export const renderStatsOf = (tileId: string): TileRenderStats | undefined => stats.get(tileId);
export const allRenderStats = (): TileRenderStats[] => [...stats.values()];

export function subscribeRenderStats(l: (s: TileRenderStats) => void): () => void {
  listeners.add(l);
  return () => { listeners.delete(l); };
}

const now = () => (typeof performance !== 'undefined' && performance.now ? performance.now() : Date.now());
export { now as renderClock };
