/**
 * A tile below the fold is not drawn -- nor its data asked for -- until it is
 * scrolled near the screen (2026-10-30).  Until then a placeholder of the
 * SAME size holds its place, so the layout never jumps.  Once drawn it stays
 * drawn (scrolling back up costs nothing).
 *
 * The first answer comes from where the tile is at mount: a tile already on
 * (or within OFFSCREEN_MARGIN_PX of) the screen draws at once.  Where the
 * browser has no IntersectionObserver every tile draws at once (never a tile
 * that cannot appear).
 */
import React, { useLayoutEffect, useRef, useState } from 'react';
import { Box, Typography } from '@mui/material';

/** a tile this close to the screen (px) is drawn before it is reached */
export const OFFSCREEN_MARGIN_PX = 200;

function onScreenNow(el: HTMLElement | null): boolean {
  if (!el || typeof window === 'undefined') return true;
  const r = el.getBoundingClientRect();
  const vh = window.innerHeight || document.documentElement.clientHeight || 0;
  if (!vh) return true;
  return r.top <= vh + OFFSCREEN_MARGIN_PX && r.bottom >= -OFFSCREEN_MARGIN_PX;
}

interface Props {
  tileId: string;
  width: number;
  height: number;
  /** draw at once wherever it is (the report's own table: its rows are virtualized instead) */
  eager?: boolean;
  children: React.ReactNode;
}

export default function DrawWhenSeen({ tileId, width, height, eager = false, children }: Props) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [seen, setSeen] = useState(() => eager || typeof IntersectionObserver === 'undefined');
  // a layout effect: a tile on the screen is drawn before the first paint (no flash)
  useLayoutEffect(() => {
    if (seen) return;
    if (onScreenNow(ref.current)) { setSeen(true); return; }
    const io = new IntersectionObserver(entries => {
      if (entries.some(e => e.isIntersecting)) { setSeen(true); io.disconnect(); }
    }, { rootMargin: `${OFFSCREEN_MARGIN_PX}px 0px` });
    if (ref.current) io.observe(ref.current);
    return () => io.disconnect();
  }, [seen]);
  if (seen) return <>{children}</>;
  return (
    <Box ref={ref} data-testid={`tile-offscreen-${tileId}`} aria-busy="true"
      sx={{ width: '100%', maxWidth: width, height, minHeight: height, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Typography variant="caption" color="text.secondary">Drawn when you scroll to it.</Typography>
    </Box>
  );
}
