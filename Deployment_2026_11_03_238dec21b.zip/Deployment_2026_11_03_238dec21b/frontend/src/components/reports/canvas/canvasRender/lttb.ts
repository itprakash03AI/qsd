/**
 * Largest-Triangle-Three-Buckets down-sampling (2026-10-30) -- the browser's
 * copy of `backend/core/reports/lttb.py`, the same rules:
 *
 * - at most `threshold` points (never fewer than MIN_THRESHOLD asked for);
 * - the first and the last point always kept;
 * - the series' highest and lowest point ALWAYS kept (two slots reserved),
 *   so a spike never vanishes because the picture got smaller;
 * - x is the POSITION (the category order), a missing y counts as 0 when
 *   choosing.
 *
 * The server does it when it can (`max_points` on the cube); this one covers
 * what reaches the browser long anyway (a share link's cube, a split series).
 */
export const MIN_THRESHOLD = 4;

const num = (v: any): number => {
  if (v === null || v === undefined || typeof v === 'boolean') return 0;
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : 0;
};

/** The positions to keep, ascending. */
export function lttbIndices(ys: ArrayLike<any>, threshold: number): number[] {
  const n = ys.length;
  const t = Math.max(Math.floor(threshold), MIN_THRESHOLD);
  if (n <= t) return Array.from({ length: n }, (_, i) => i);
  const y = new Float64Array(n);
  let hi = 0; let lo = 0;
  for (let i = 0; i < n; i++) {
    y[i] = num(ys[i]);
    if (y[i] > y[hi]) hi = i;
    if (y[i] < y[lo]) lo = i;
  }
  const extremes = new Set<number>([hi, lo]);
  extremes.delete(0);
  extremes.delete(n - 1);
  const k = t - extremes.size;
  const keep = new Set<number>([0, n - 1, ...extremes]);
  if (k > 2) {
    const every = (n - 2) / (k - 2);
    let a = 0;
    for (let i = 0; i < k - 2; i++) {
      const start = Math.floor(i * every) + 1;
      const end = Math.floor((i + 1) * every) + 1;
      const nStart = end;
      const nEnd = Math.min(Math.floor((i + 2) * every) + 1, n);
      let avgX: number; let avgY: number;
      if (nStart >= nEnd) { avgX = n - 1; avgY = y[n - 1]; } else {
        avgX = (nStart + nEnd - 1) / 2;
        let s = 0;
        for (let j = nStart; j < nEnd; j++) s += y[j];
        avgY = s / (nEnd - nStart);
      }
      const ax = a; const ay = y[a];
      let best = start; let bestArea = -1;
      for (let j = start; j < Math.min(end, n - 1); j++) {
        const area = Math.abs((ax - avgX) * (y[j] - ay) - (ax - j) * (avgY - ay));
        if (area > bestArea) { bestArea = area; best = j; }
      }
      keep.add(best);
      a = best;
    }
  }
  return [...keep].sort((p, q) => p - q);
}

/** The items LTTB keeps, in their order (`items` itself when short enough). */
export function lttb<T>(items: T[], yOf: (item: T) => any, threshold: number): T[] {
  if (items.length <= Math.max(Math.floor(threshold), MIN_THRESHOLD)) return items;
  return lttbIndices(items.map(yOf), threshold).map(i => items[i]);
}
