/**
 * A scatter or heat map drawn with WebGL (2026-10-30) -- the drawing ladder's
 * top rung (drawingLadder.ts, webglPainter.ts).  ONE <canvas>; its marks are
 * one buffer of floats the graphics card draws in one call.  When this browser
 * cannot draw with WebGL (no context, a shader that does not compile), the
 * `fallback` is drawn instead -- the rung below -- and `data-webgl` says why.
 *
 * `data-renderer="webgl"` and `data-points-drawn` say what was painted (the
 * e2e spec and the diagnostics read them).
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Box, Typography } from '@mui/material';
import { MarkBuffer, paintMarks, webglContext } from './webglPainter';

interface Props {
  /** the marks to upload (scatterBuffer / heatmapBuffer) */
  buffer: MarkBuffer;
  width: number;
  height: number;
  color: string;
  heat?: boolean;
  /** words under the picture (the scale) */
  caption?: string;
  /** what to draw when WebGL is not available here */
  fallback: React.ReactNode;
  /** told which renderer actually drew (the tile's render stats) */
  onDrawn?: (renderer: 'webgl' | 'fallback') => void;
}

export default function WebGLChart({ buffer, width, height, color, heat = false, caption, fallback, onDrawn }: Props) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const [failed, setFailed] = useState<string | null>(null);
  const h = Math.max(60, height - (caption ? 18 : 0));
  const key = useMemo(() => `${buffer.count}:${width}:${h}:${color}:${heat}`, [buffer, width, h, color, heat]);

  useEffect(() => {
    const el = ref.current;
    const gl = webglContext(el);
    if (!el || !gl) { setFailed('This browser cannot draw with WebGL here.'); onDrawn?.('fallback'); return; }
    const dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
    el.width = Math.round(width * dpr);
    el.height = Math.round(h * dpr);
    try {
      paintMarks(gl, buffer, width, h, { color, heat, dpr });
      onDrawn?.('webgl');
    } catch (e: any) {
      setFailed(String(e?.message || 'WebGL could not draw this chart.'));
      onDrawn?.('fallback');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  if (failed) {
    return <Box data-webgl="unavailable" title={failed}>{fallback}</Box>;
  }
  return (
    <Box data-renderer="webgl" data-points-drawn={buffer.count} data-testid="tile-webgl-chart" sx={{ position: 'relative' }}>
      <canvas ref={ref} width={width} height={h} role="img"
        aria-label={`${heat ? 'heat map' : 'scatter chart'} of ${buffer.count.toLocaleString('en-US')} ${heat ? 'cells' : 'points'}`}
        style={{ width, height: h, display: 'block' }} />
      {caption && <Typography variant="caption" color="text.secondary" component="div" noWrap>{caption}</Typography>}
    </Box>
  );
}
