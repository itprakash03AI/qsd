/**
 * The WebGL painter (2026-10-30, the owner: "how html can be faster n memory
 * efficient ... vector based or what?") -- the drawing ladder's top rung
 * (drawingLadder.ts): a scatter of more than WEBGL_MIN_MARKS points, or a heat
 * map of that many cells, is ONE <canvas> whose marks the graphics card draws in
 * one call.  The page holds one element and one buffer of floats, whatever the
 * count.  Small and hand-written: no graphics library.
 *
 * Two halves, so a test checks what is drawn without a graphics card:
 *   - `scatterBuffer` / `heatmapBuffer` (pure): the marks as the floats that are
 *     uploaded -- x, y in clip space (-1..1) and a colour strength 0..1 per mark;
 *   - `paintMarks(gl, buffer, ...)`: compiles two tiny shaders, uploads the
 *     buffer, draws it as points.  `webglContext(canvas)` is null when the
 *     browser has no WebGL (jsdom, a locked-down desktop) -- then the tile
 *     paints on the 2D canvas instead (the rung below).
 */
import { PLOT_MARGIN } from './canvasPainter';

/** floats per mark in the uploaded buffer: x, y, strength */
export const FLOATS_PER_MARK = 3;

export interface MarkBuffer {
  /** x, y (clip space) and strength (0..1) per mark */
  data: Float32Array;
  /** marks in `data` (NULLs are not drawn) */
  count: number;
  /** a heat map's cell size in pixels (a scatter's dot size) */
  pointSize: number;
  /** what the axes span, for the scale words */
  xMin: number; xMax: number; yMin: number; yMax: number;
}

function span(values: ArrayLike<number | null>): [number, number] {
  let lo = Infinity; let hi = -Infinity;
  for (let i = 0; i < values.length; i++) {
    const v = values[i];
    if (v === null || v === undefined || !Number.isFinite(v)) continue;
    if (v < lo) lo = v;
    if (v > hi) hi = v;
  }
  if (lo === Infinity) { lo = 0; hi = 1; }
  if (lo === hi) { lo -= 1; hi += 1; }
  return [lo, hi];
}

/** The plot's place in clip space (the same margins as the 2D painter). */
export function plotBox(width: number, height: number) {
  const pw = Math.max(10, width - PLOT_MARGIN.left - PLOT_MARGIN.right);
  const ph = Math.max(10, height - PLOT_MARGIN.top - PLOT_MARGIN.bottom);
  const toClipX = (px: number) => (px / width) * 2 - 1;
  const toClipY = (py: number) => 1 - (py / height) * 2;
  return { pw, ph, toClipX, toClipY };
}

/** A scatter: one mark per (x, y) pair with both values; strength 1. */
export function scatterBuffer(xs: ArrayLike<number | null>, ys: ArrayLike<number | null>,
                              width: number, height: number): MarkBuffer {
  const n = Math.min(xs.length, ys.length);
  const [xMin, xMax] = span(xs);
  const [yMin, yMax] = span(ys);
  const { pw, ph, toClipX, toClipY } = plotBox(width, height);
  const data = new Float32Array(n * FLOATS_PER_MARK);
  let k = 0;
  for (let i = 0; i < n; i++) {
    const x = xs[i]; const y = ys[i];
    if (x === null || y === null || x === undefined || y === undefined || !Number.isFinite(x) || !Number.isFinite(y)) continue;
    const px = PLOT_MARGIN.left + ((x - xMin) / (xMax - xMin)) * pw;
    const py = PLOT_MARGIN.top + ph - ((y - yMin) / (yMax - yMin)) * ph;
    data[k * 3] = toClipX(px);
    data[k * 3 + 1] = toClipY(py);
    data[k * 3 + 2] = 1;
    k++;
  }
  return { data: data.subarray(0, k * 3), count: k, pointSize: 3, xMin, xMax, yMin, yMax };
}

export interface HeatCell { row: number; col: number; value: number | null }

/** A heat map: one square mark per cell with a value, strength = its place between the smallest and the largest. */
export function heatmapBuffer(cells: HeatCell[], nRows: number, nCols: number, width: number, height: number): MarkBuffer {
  const { pw, ph, toClipX, toClipY } = plotBox(width, height);
  // only the cells that are drawn set the colour scale
  const drawn = cells.filter(c => c.value !== null && Number.isFinite(c.value)
    && c.row >= 0 && c.col >= 0 && c.row < nRows && c.col < nCols);
  const [vMin, vMax] = span(drawn.map(c => c.value));
  const cw = pw / Math.max(1, nCols);
  const chh = ph / Math.max(1, nRows);
  const data = new Float32Array(drawn.length * FLOATS_PER_MARK);
  let k = 0;
  for (const c of drawn) {
    if (c.value === null) continue;
    const px = PLOT_MARGIN.left + (c.col + 0.5) * cw;
    const py = PLOT_MARGIN.top + (c.row + 0.5) * chh;
    data[k * 3] = toClipX(px);
    data[k * 3 + 1] = toClipY(py);
    data[k * 3 + 2] = (c.value - vMin) / (vMax - vMin);
    k++;
  }
  return { data: data.subarray(0, k * 3), count: k, pointSize: Math.max(1, Math.ceil(Math.min(cw, chh))),
           xMin: 0, xMax: nCols, yMin: vMin, yMax: vMax };
}

/** The part of WebGLRenderingContext the painter uses (a test passes a recorder). */
export interface GL {
  VERTEX_SHADER: number; FRAGMENT_SHADER: number; ARRAY_BUFFER: number; STATIC_DRAW: number;
  FLOAT: number; POINTS: number; COLOR_BUFFER_BIT: number; COMPILE_STATUS: number; LINK_STATUS: number;
  BLEND: number; SRC_ALPHA: number; ONE_MINUS_SRC_ALPHA: number;
  createShader(t: number): any; shaderSource(s: any, src: string): void; compileShader(s: any): void;
  getShaderParameter(s: any, p: number): any; createProgram(): any; attachShader(p: any, s: any): void;
  linkProgram(p: any): void; getProgramParameter(p: any, q: number): any; useProgram(p: any): void;
  createBuffer(): any; bindBuffer(t: number, b: any): void; bufferData(t: number, d: Float32Array, u: number): void;
  getAttribLocation(p: any, n: string): number; enableVertexAttribArray(i: number): void;
  vertexAttribPointer(i: number, size: number, type: number, norm: boolean, stride: number, off: number): void;
  getUniformLocation(p: any, n: string): any; uniform1f(l: any, v: number): void; uniform3f(l: any, a: number, b: number, c: number): void;
  uniform1i(l: any, v: number): void;
  viewport(x: number, y: number, w: number, h: number): void; clearColor(r: number, g: number, b: number, a: number): void;
  clear(m: number): void; enable(c: number): void; blendFunc(a: number, b: number): void;
  drawArrays(mode: number, first: number, count: number): void;
}

const VERTEX = `attribute vec2 a_pos; attribute float a_strength; uniform float u_size; varying float v_strength;
void main() { gl_Position = vec4(a_pos, 0.0, 1.0); gl_PointSize = u_size; v_strength = a_strength; }`;
const FRAGMENT = `precision mediump float; uniform vec3 u_color; uniform int u_heat; varying float v_strength;
void main() { float a = u_heat == 1 ? 0.08 + 0.72 * v_strength : 0.7; gl_FragColor = vec4(u_color, a); }`;

/** "#2a78d6" -> [r, g, b] 0..1 */
export function rgb(hex: string): [number, number, number] {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex.trim());
  if (!m) return [0.165, 0.471, 0.839];
  return [parseInt(m[1], 16) / 255, parseInt(m[2], 16) / 255, parseInt(m[3], 16) / 255];
}

/** Draw the marks: one buffer upload, one draw call.  Throws when a shader does not compile (the caller falls back). */
export function paintMarks(gl: GL, buf: MarkBuffer, width: number, height: number,
                           opts: { color: string; heat: boolean; dpr?: number }): void {
  const dpr = opts.dpr ?? 1;
  const shader = (type: number, src: string) => {
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('A WebGL shader did not compile.');
    return s;
  };
  const prog = gl.createProgram();
  gl.attachShader(prog, shader(gl.VERTEX_SHADER, VERTEX));
  gl.attachShader(prog, shader(gl.FRAGMENT_SHADER, FRAGMENT));
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error('The WebGL program did not link.');
  gl.useProgram(prog);
  const vbo = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  gl.bufferData(gl.ARRAY_BUFFER, buf.data, gl.STATIC_DRAW);
  const stride = FLOATS_PER_MARK * 4;
  const aPos = gl.getAttribLocation(prog, 'a_pos');
  gl.enableVertexAttribArray(aPos);
  gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, stride, 0);
  const aStr = gl.getAttribLocation(prog, 'a_strength');
  gl.enableVertexAttribArray(aStr);
  gl.vertexAttribPointer(aStr, 1, gl.FLOAT, false, stride, 8);
  gl.uniform1f(gl.getUniformLocation(prog, 'u_size'), buf.pointSize * dpr);
  const [r, g, b] = rgb(opts.color);
  gl.uniform3f(gl.getUniformLocation(prog, 'u_color'), r, g, b);
  gl.uniform1i(gl.getUniformLocation(prog, 'u_heat'), opts.heat ? 1 : 0);
  gl.viewport(0, 0, Math.round(width * dpr), Math.round(height * dpr));
  gl.clearColor(0, 0, 0, 0);
  gl.clear(gl.COLOR_BUFFER_BIT);
  gl.enable(gl.BLEND);
  gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
  gl.drawArrays(gl.POINTS, 0, buf.count);
}

/** The canvas's WebGL context, or null (no WebGL here: jsdom, a locked-down browser). */
export function webglContext(el: HTMLCanvasElement | null): GL | null {
  if (!el || typeof el.getContext !== 'function') return null;
  try {
    return ((el.getContext('webgl', { preserveDrawingBuffer: true }) as any)
      || (el.getContext('experimental-webgl') as any) || null) as GL | null;
  } catch {
    return null;
  }
}

let _available: boolean | null = null;
/** Can this browser draw with WebGL?  Asked once.  `setWebglAvailableForTests` overrides it. */
export function webglAvailable(): boolean {
  if (_available !== null) return _available;
  try {
    if (typeof document === 'undefined') { _available = false; return false; }
    // jsdom has no canvas: its getContext is a "not implemented" stub that writes to the console
    if (typeof navigator !== 'undefined' && /jsdom/i.test(navigator.userAgent || '')) { _available = false; return false; }
    _available = webglContext(document.createElement('canvas')) !== null;
  } catch {
    _available = false;
  }
  return _available;
}

export function setWebglAvailableForTests(v: boolean | null): void { _available = v; }
