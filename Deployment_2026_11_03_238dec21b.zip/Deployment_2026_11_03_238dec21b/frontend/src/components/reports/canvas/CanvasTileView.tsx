/**
 * One tile of the report canvas (2026-10-26).
 *
 * Every number comes from the run's STORED, row-secured result through the
 * microcube (POST /results/{exec_id}/cube 'drill') -- the same answer the
 * exports and the API give; nothing is recomputed in the browser.  What a
 * tile cannot show is said in words on the tile: no run yet, no rows, a value
 * that cannot be shown at this level (422), a result still being built (409),
 * a run older than a field the tile uses (400), more categories than drawn.
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { noteTileRequests, publishTileError, publishTileFacts } from './canvasTileFacts';
import {
  Alert, Box, CircularProgress, Table, TableBody, TableCell, TableHead, TableRow,
  TableSortLabel, Tooltip, Typography,
} from '@mui/material';
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, ComposedChart, Funnel, FunnelChart, LabelList, Legend,
  Line, LineChart, Pie, PieChart, PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, Scatter,
  ScatterChart, Tooltip as ReTooltip, Treemap, XAxis, YAxis, ZAxis,
} from 'recharts';
import api from '../../../services/api';
import { applyFormatPattern } from '../../../utils/formatters';
import ListPager, { type Paging } from '../../common/ListPager';
import { cssColour, useCanvasTheme } from './canvasTheme';
import {
  CanvasColumn, CanvasTile, isBridge, MAX_DENSE_POINTS, MAX_PIVOT_COLUMNS, measureAlias, measureWords, SERIES_CHARTS, tileCubeBody, tileName,
} from './canvasModel';
import CanvasOutlineTile, { stickyLeft } from './CanvasOutlineTile';
import { derivedAlias, derivedFormat } from './canvasDerived';
import { formatNumber, negativeSx, ruleSx, scaleStats, valueSx, withTileFormats } from './canvasOutline';
import { CanvasLink, rowSteps, useCanvasLinks, withLinkSlicers } from './canvasLinks';
import { TileLinkCaption } from './CanvasLinkChips';
import { useCanvasTileActions } from './canvasActions';
import InsightTileView from './InsightTileView';
import KpiCard from './KpiCard';
import { deltaWords, kpiLook, useKpiIndex } from './canvasKpi';
import { overlayWanted, percentOf } from './canvasChartOptions';
import { useCanvasCompare } from './canvasCompare';
// 2026-10-30 -- drawing fast: the ladder (SVG -> canvas), LTTB, virtual rows, the cost of each tile
import CanvasChart from './canvasRender/CanvasChart';
import WebGLChart from './canvasRender/WebGLChart';
import { heatmapBuffer, scatterBuffer, webglAvailable } from './canvasRender/webglPainter';
import VirtualRows from './canvasRender/VirtualRows';
import { chooseRenderer, DOWNSAMPLE_KINDS, markCount, maxPointsFor } from './canvasRender/drawingLadder';
import { lttb } from './canvasRender/lttb';
import { recordRenderStats, renderClock } from './canvasRender/renderStats';
import { transportOf } from '../../../services/api/cubeArrow';

/** kinds whose categories read in their own order (time, a sequence), not largest first */
const ORDERED = ['line', 'area', 'stacked_area', 'waterfall'];
/** a part-of-a-whole chart: its remainder is "Everything else" */
const WHOLE = ['pie', 'donut', 'treemap'];

export interface TileRunInfo {
  /** the run whose stored result the tiles read; null = not run yet */
  executionId: string | null;
  /** rows in that result (0 = the run returned nothing) */
  totalRows: number | null;
  /** the result was cut by a row limit: every tile says so */
  truncated: boolean;
  rowLimit?: number | null;
}

interface Props {
  tile: CanvasTile;
  reportId: number | null;
  cols: Map<number, CanvasColumn>;
  grouped: boolean;
  run: TileRunInfo;
  /** the report's own table (kind 'report') -- rendered as is */
  reportTable?: React.ReactNode;
  width: number;
  height: number;
  /** a share link / embed asks ITS cube route with its handle (default: the signed-in route) */
  cubeFetch?: CubeFetch;
  /** the builder: this tile uses fields the shown preview ran WITHOUT (their names) */
  staleFields?: string[];
  /** 2026-11-01 drill-down (canvasDrill.tsx): a click on a category goes one level down;
   *  at the lowest level it opens the tile's first action, or says there is none */
  drill?: { onPick: (value: any) => boolean; atBottom: boolean; onNoAction: () => void };
}

/** One cube request for a tile; the signed-in road is api.queryReportCube. */
export type CubeFetch = (reportId: number, executionId: string, body: any) => Promise<any>;

const MAX_SERIES = 8;
const PIVOT_FETCH = 50_000;

/** A cell's words: the column's own format, else a readable number; NULL is "(no value)". */
export function formatValue(v: any, c?: CanvasColumn | null): string {
  if (v === null || v === undefined) return '(no value)';
  if (v === '') return '(blank)';
  if (c?.tile_format) {                                    // the tile's own number format (2026-10-30)
    const own = formatNumber(v, c.tile_format);
    if (own != null) return own;
  }
  const pattern = c?.format_pattern;
  if (pattern) {
    const f = applyFormatPattern(v, pattern, c?.data_type || undefined);
    if (f != null) return f;
  }
  if (typeof v === 'number') return v.toLocaleString(undefined, { maximumFractionDigits: 2 });
  if (typeof v === 'string' && /^-?\d+(\.\d+)?$/.test(v) && v.length < 16) {
    return Number(v).toLocaleString(undefined, { maximumFractionDigits: 2 });
  }
  if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T00:00:00/.test(v)) return v.slice(0, 10);
  return String(v);
}

/** The shared pager's block for one page of a tile (first / last are 1-based; none when empty). */
export function pagingFor(total: number, page: number, pageSize: number, shown: number): Paging {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const first = total === 0 ? 0 : (page - 1) * pageSize + 1;
  return { total, page, page_size: pageSize, pages, first, last: total === 0 ? 0 : first + Math.max(0, shown) - 1 };
}

const toNum = (v: any): number | null => {
  if (v === null || v === undefined || v === '') return null;
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : null;
};

/** The plain sentence for a failed tile request. */
export function tileErrorWords(err: any, cols: Map<number, CanvasColumn>): string {
  const status = err?.status;
  const detail = err?.detail;
  if (status === 422 && detail?.refused) {
    const names = (detail.refused as any[]).map(r => {
      const c = [...cols.values()].find(x => x.physical_name === r.column);
      return `${c?.label ?? r.column}: ${r.reason}`;
    });
    return `This value cannot be shown at this level. ${names.join('; ')}`;
  }
  if (status === 409) return String(err?.message || 'This run’s result is not ready yet. Try again shortly.');
  if (status === 400) {
    return 'This run does not have every field this tile uses (the report changed after it ran). Run the report again.';
  }
  if (status === 404) return 'This run’s result is no longer available. Run the report again.';
  if (status === 403) return 'You do not have access to this run’s result.';
  return String(err?.message || 'The tile could not be read.');
}

function useTileData(tile: CanvasTile, reportId: number | null, cols: Map<number, CanvasColumn>,
                     run: TileRunInfo, page: number, pageSize: number, sort: { col: string; dir: 'asc' | 'desc' } | null,
                     cubeFetch?: CubeFetch, links: CanvasLink[] = [], maxPoints: number | null = null,
                     overlay: { column: string; a: string; b: string } | null = null) {
  // the signed-in road prefers Arrow (2026-10-30); a link / embed keeps its own route
  const fast = (api as any).queryReportCubeFast;
  // 2026-10-30 Diagnostics: every cube call is noted with the body it SENT
  const ask = noteTileRequests(tile.id, cubeFetch ?? ((r: number, e: string, b: any) => (fast ? fast(r, e, b) : api.queryReportCube(r, e, b))));
  // linked tiles: every cube call of this tile carries the clicked values as slicers
  const cube = (r: number, e: string, b: any) => ask(r, e, withLinkSlicers(b, links, cols));
  const [state, setState] = useState<{ loading: boolean; error: string; data: any | null; extra: any | null; at?: number }>(
    { loading: false, error: '', data: null, extra: null });
  const key = JSON.stringify([tile.kind, tile.dimensions, tile.measures, tile.series, tile.sort, tile.top_n,
    run.executionId, page, pageSize, sort, links, maxPoints, overlay]);
  useEffect(() => {
    if (tile.kind === 'report' || tile.kind === 'outline' || tile.kind === 'band' || tile.kind === 'insight' || !reportId || !run.executionId) {
      setState({ loading: false, error: '', data: null, extra: null });
      return;
    }
    let cancelled = false;
    const exec = run.executionId;
    (async () => {
      setState(s => ({ ...s, loading: true, error: '' }));
      try {
        const base: any = tileCubeBody(tile, cols, 1, 500);
        if (!base) throw new Error('This tile has nothing to show yet.');
        let data: any;
        let extra: any = null;
        if (tile.kind === 'number') {
          // the KPI card (2026-11-02): a second value in the SAME drill, and the sparkline's last N points
          const body: any = { ...base, dimensions: [], page: 1, page_size: 1 };
          if (tile.compare?.kind === 'measure') {
            body.measures = [...body.measures, { column: cols.get(tile.compare.column_id)?.physical_name || '', aggregation: tile.compare.aggregation, alias: measureAlias(1) }];
          }
          data = await cube(reportId, exec, body);
          if (tile.sparkline && cols.get(tile.sparkline.column_id)) {
            const sc = cols.get(tile.sparkline.column_id)!.physical_name;
            const sp = await cube(reportId, exec, { ...base, dimensions: [sc], measures: base.measures.slice(0, 1), sort_column: sc, sort_direction: 'desc',
              page: 1, page_size: Math.max(2, Math.min(100, tile.sparkline.points)) });
            extra = { spark: [...(sp.rows || [])].reverse().map((r: any) => toNum(r[measureAlias(0)])) };
          }
        } else if (tile.kind === 'table') {
          const body = { ...base, page, page_size: pageSize };
          if (sort) { body.sort_column = sort.col; body.sort_direction = sort.dir; }
          data = await cube(reportId, exec, body);
        } else if (tile.kind === 'pivot' || tile.kind === 'heatmap') {
          // a heat map the graphics card draws (WebGL) may hold as many cells as a dense chart
          const fetchCells = tile.kind === 'heatmap' && webglAvailable() ? MAX_DENSE_POINTS : PIVOT_FETCH;
          data = await cube(reportId, exec, { ...base, page: 1, page_size: fetchCells });
        } else if (isBridge(tile)) {
          // a waterfall of values (2026-11-03): the whole result's total of each value, one step each
          data = await cube(reportId, exec, { ...base, dimensions: [], page: 1, page_size: 1 });
        } else {
          // charts: the top categories first, then (with a series) only those categories
          const cat = cols.get(tile.dimensions[0])?.physical_name || '';
          // 2026-11-01 -- a line / area over a date with no top_n drew 25 of 94 days:
          // a dense kind (no series) asks for EVERY point and the server sends
          // about a point per pixel (LTTB); category kinds keep the top 25
          const dense = tile.series == null && DOWNSAMPLE_KINDS.includes(tile.kind);
          const topN = tile.top_n ?? (dense ? MAX_DENSE_POINTS : 25);
          const catBody = { ...base, dimensions: [cat], page: 1, page_size: topN };
          if (ORDERED.includes(tile.kind) && !tile.sort) { catBody.sort_column = cat; catBody.sort_direction = 'asc'; }
          // the two-dates overlay (2026-11-02): B's categories as the marks, A's values for the SAME categories as a dotted line
          if (overlay) catBody.slicers = { ...(catBody.slicers || {}), [overlay.column]: [overlay.b] };
          // a long line / area comes back as about a point per pixel (LTTB on the server)
          if (maxPoints != null && tile.series == null && DOWNSAMPLE_KINDS.includes(tile.kind) && topN > maxPoints) {
            catBody.max_points = maxPoints;
          }
          data = await cube(reportId, exec, catBody);
          if (overlay) {
            const shown = (data.rows || []).map((r: any) => r[cat]).filter((v: any) => v !== null);
            const sideA = await cube(reportId, exec, { ...base, dimensions: [cat], page: 1, page_size: Math.max(1, shown.length),
              sort_column: cat, sort_direction: 'asc', slicers: { ...(base.slicers || {}), [overlay.column]: [overlay.a], [cat]: shown } });
            const byCat = new Map<string, any>((sideA.rows || []).map((r: any) => [JSON.stringify(r[cat]), r]));
            extra = { overlay: { a: overlay.a, b: overlay.b, byCat } };
          }
          if (tile.series != null && SERIES_CHARTS.includes(tile.kind)) {
            const ser = cols.get(tile.series)?.physical_name || '';
            const shown = (data.rows || []).map((r: any) => r[cat]);
            const seriesTotals = await cube(reportId, exec, {
              ...base, dimensions: [ser], page: 1, page_size: MAX_SERIES,
              sort_column: measureAlias(0), sort_direction: 'desc',
            });
            const pairs = await cube(reportId, exec, {
              ...base, dimensions: [cat, ser], page: 1, page_size: Math.max(1, shown.length) * MAX_SERIES * 4,
              slicers: { [cat]: shown.filter((v: any) => v !== null), [ser]: (seriesTotals.rows || []).map((r: any) => r[ser]).filter((v: any) => v !== null) },
            });
            extra = { seriesTotals, pairs, cat, ser };
          }
          if (WHOLE.includes(tile.kind)) {
            extra = { ...(extra || {}), whole: await cube(reportId, exec, { ...base, dimensions: [], page: 1, page_size: 1 }) };
          }
        }
        if (!cancelled) { setState({ loading: false, error: '', data, extra, at: renderClock() }); publishTileFacts(exec, tile, data); }
      } catch (err: any) {
        if (!cancelled) { setState({ loading: false, error: tileErrorWords(err, cols), data: null, extra: null }); publishTileError(exec, tile, tileErrorWords(err, cols)); }
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, reportId]);
  return state;
}

export default function CanvasTileView({ tile, reportId, cols: rawCols, grouped, run, reportTable, width, height, cubeFetch, staleFields, drill }: Props) {
  const cols = useMemo(() => withTileFormats(tile, rawCols), [tile, rawCols]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [sort, setSort] = useState<{ col: string; dir: 'asc' | 'desc' } | null>(null);
  const links = useCanvasLinks();
  const linkKey = JSON.stringify(links.filters);
  useEffect(() => { setPage(1); }, [run.executionId, pageSize, sort, linkKey]);
  const stale = !!staleFields && staleFields.length > 0;
  // a line / area asks for about a point per pixel; the width is bucketed so a
  // resize by a few pixels does not ask again
  const maxPoints = DOWNSAMPLE_KINDS.includes(tile.kind) ? maxPointsFor(Math.ceil(width / 100) * 100) : null;
  // the two-dates overlay reads the page's comparison (canvasCompare.tsx); none / an error = the plain chart
  const cmpSetting = useCanvasCompare();
  const overlay = overlayWanted(tile, cmpSetting) && cmpSetting && !('error' in cmpSetting) && cols.get(cmpSetting.column_id)
    ? { column: cols.get(cmpSetting.column_id)!.physical_name, a: cmpSetting.a, b: cmpSetting.b } : null;
  const { loading, error, data, extra, at } = useTileData(tile, reportId, cols,
    stale ? { ...run, executionId: null } : run, page, pageSize, sort, cubeFetch, links.filters, maxPoints, overlay);
  // linked tiles: a click picks a value (Ctrl / Cmd adds); the modifier is read
  // in the capture phase so a chart's own click handler sees it
  const additive = useRef(false);
  const act = useCanvasTileActions(tile, cols);   // canvas actions: ⤓ on a cell, right-click on a chart
  const canPick = (links.enabled || !!drill) && tile.kind !== 'number';
  const pick = (columnIds: number[], values: any[], row?: Record<string, any>) => {
    if (drill) {      // a drill path: down one level, or the popup at the bottom
      if (!drill.atBottom) { drill.onPick(values[0]); return; }
      if (!act.openFirst(row ?? {})) drill.onNoAction();
      return;
    }
    if (links.enabled && columnIds.length) links.togglePath(rowSteps(columnIds, values), additive.current);
  };
  const dimmed = (columnIds: number[], values: any[]) =>
    links.hasSelection && !columnIds.every((id, i) => links.isSelected(id, values[i] ?? null));
  const title = tileName(tile, cols);
  const theme = useCanvasTheme();                   // the look is configuration (canvasTheme.ts)
  const kpiIndex = useKpiIndex(tile.id);            // the KPI card's fill, in turn (ReportCanvasView)
  // an INSIGHT tile reads its own way: its cube calls carry the linked clicks
  // (slicers + clicked paths) and are noted for the Diagnostics panel
  const linkedCube: CubeFetch = useMemo(() => {
    const ask = noteTileRequests(tile.id, cubeFetch ?? ((r: number, e: string, b: any) => api.queryReportCube(r, e, b)));
    return (r: number, e: string, b: any) => ask(r, e, withLinkSlicers(b, links.filters, cols));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cubeFetch, tile.id, linkKey]);
  const tableScrollRef = useRef<HTMLDivElement | null>(null);
  const tileRef = useRef<HTMLDivElement | null>(null);
  // what this render drew (set while drawing, read after the commit)
  const drawn = useRef<{ renderer: 'svg' | 'canvas' | 'webgl' | 'table'; rows: number; sourceRows: number; marks: number } | null>(null);
  drawn.current = null;
  useEffect(() => {
    if (!data || !drawn.current || at == null) return;
    const t = transportOf(data);
    const ms = Math.max(0, Math.round(renderClock() - at));
    tileRef.current?.setAttribute('data-render-ms', String(ms));
    recordRenderStats({ tileId: tile.id, ...drawn.current, bytes: t?.bytes ?? null, format: t?.format ?? null,
      renderMs: ms, at: Date.now() });
  });

  // the report's own table inside a tile: the tile's height reaches the table's
  // scroll box as a CSS variable, so the table (not the tile frame) scrolls and
  // its sticky header has something to stick to (defect 6, 2026-11-01)
  if (tile.kind === 'report') return <Box sx={{ '--qs-tile-h': `${height}px` } as any}><TileLinkCaption cols={cols} />{reportTable}</Box>;
  if (tile.kind === 'outline' || tile.kind === 'band') {
    return <CanvasOutlineTile tile={tile} reportId={reportId} cols={cols} grouped={grouped} height={height}
      run={stale ? { ...run, executionId: null } : run} cubeFetch={cubeFetch} />;
  }
  if (tile.kind === 'insight') {
    return <><TileLinkCaption cols={cols} /><InsightTileView tile={tile} reportId={reportId} cols={cols} run={run}
      cubeFetch={linkedCube} linkKey={linkKey} stale={stale} /></>;
  }

  let body: React.ReactNode = null;
  if (stale && run.executionId) {
    body = (
      <Typography variant="body2" color="text.secondary" data-testid="tile-stale">
        Press Preview again to see this tile: {staleFields!.join(', ')} {staleFields!.length === 1 ? 'was' : 'were'} added
        after the preview ran.
      </Typography>
    );
  } else if (!run.executionId) {
    body = <Typography variant="body2" color="text.secondary" data-testid="tile-not-run">Run the report to see this.</Typography>;
  } else if (error) {
    body = <Alert severity="warning" data-testid="tile-error" sx={{ py: 0 }}>{error}</Alert>;
  } else if (loading && !data) {
    body = <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}><CircularProgress size={20} /></Box>;
  } else if (data) {
    body = renderBody();
  }

  function renderBody(): React.ReactNode {
    const rows: any[] = data.rows || [];
    const dimNames = tile.dimensions.map(id => cols.get(id)?.physical_name || '');
    if (tile.kind === 'number') {
      // the KPI card (2026-11-02, KpiCard.tsx): the value, a second value's change, the card style
      const m = tile.measures[0];
      const c = cols.get(m.column_id);
      const v = rows[0]?.[measureAlias(0)];
      const noRows = run.totalRows === 0;
      const text = noRows ? 'No rows' : v === null || v === undefined ? 'No value' : formatValue(v, c);
      const cmp = tile.compare;
      const prev = cmp?.kind === 'measure' ? rows[0]?.[measureAlias(1)] : undefined;
      const prevCol = cmp?.kind === 'measure' ? cols.get(cmp.column_id) : undefined;
      const prevWords = cmp?.kind === 'measure'
        ? `vs ${cmp.label?.trim() || measureWords({ column_id: cmp.column_id, aggregation: cmp.aggregation }, cols, grouped)}`
        : cmp?.kind === 'parameter' ? 'vs the previous date' : '';
      const change = cmp && !noRows ? deltaWords(v, prev, tile.good_when ?? 'up') : null;
      return (
        <Box data-testid="tile-number" data-value={text} sx={{ height: '100%' }}>
          <KpiCard valueText={text} muted={noRows || v == null} label={measureWords(m, cols, grouped)} change={change} previousWords={prevWords}
            previousText={prev == null ? undefined : formatValue(prev, prevCol ?? c)} look={kpiLook(tile, kpiIndex, theme)} theme={theme}
            icon={tile.icon ?? null} spark={extra?.spark ?? null} width={width} height={height} valueSx={negativeSx(v, c)}
            fmtAbs={x => formatValue(x, c)} />
        </Box>
      );
    }
    if (tile.kind === 'table') {
      const total = data.total_rows ?? rows.length;
      drawn.current = { renderer: 'table', rows: rows.length, sourceRows: total, marks: rows.length };
      const headers = [
        ...tile.dimensions.map(id => ({ key: cols.get(id)?.physical_name || '', label: cols.get(id)?.label || `#${id}`, col: cols.get(id) })),
        ...tile.measures.map((m, i) => ({ key: measureAlias(i), label: measureWords(m, cols, grouped), col: cols.get(m.column_id) })),
        // values worked out from two others (2026-11-03): the microcube's numbers, in their own format
        ...(tile.derived ?? []).map((d, i) => ({ key: derivedAlias(i), label: d.label,
          col: { id: -(i + 1), physical_name: derivedAlias(i), label: d.label, data_type: 'decimal',
                 tile_format: derivedFormat(tile, d) ?? null } as CanvasColumn })),
      ];
      // colour by value (2026-11-02): a scaled column's range over the rows on this page
      const stats = new Map(headers.filter(h => h.col?.tile_format?.scale).map(h => [h.key, scaleStats(rows.map(r => r[h.key]))]));
      const signColours = { up: theme.kpi.up_fg, down: theme.kpi.down_fg };
      return (
        <Box sx={{ overflow: 'auto', height: '100%' }} ref={tableScrollRef}>
          <Table size="small" stickyHeader aria-label={title} aria-rowcount={total}>
            <TableHead>
              <TableRow>
                {headers.map(h => (
                  <TableCell key={h.key} sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>
                    <TableSortLabel active={sort?.col === h.key} direction={sort?.col === h.key ? sort.dir : 'asc'}
                      onClick={() => setSort(s => s?.col === h.key ? { col: h.key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { col: h.key, dir: 'asc' })}>
                      {h.label}
                    </TableSortLabel>
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.length === 0 && (
                <TableRow><TableCell colSpan={headers.length}>
                  <Typography variant="body2" color="text.secondary">No rows.</Typography>
                </TableCell></TableRow>
              )}
              <VirtualRows count={rows.length} scrollRef={tableScrollRef} colSpan={headers.length}
                renderRow={i => {
                  const r = rows[i];
                  return (
                    <TableRow hover data-testid={`tile-row-${tile.id}`}
                      {...(canPick && tile.dimensions.length ? {
                        onClick: () => pick(tile.dimensions, dimNames.map(d => r[d]), r),
                        selected: links.hasSelection && !dimmed(tile.dimensions, dimNames.map(d => r[d])),
                        sx: { cursor: 'pointer' },
                      } : {})}>
                      {headers.map((h, j) => (
                        <TableCell key={h.key} align={j >= tile.dimensions.length ? 'right' : 'left'} sx={{ whiteSpace: 'nowrap', ...valueSx(r[h.key], h.col, stats.get(h.key), signColours) }}
                          data-rule={ruleSx(r[h.key], h.col) ? 'on' : undefined} data-scale={h.col?.tile_format?.scale && valueSx(r[h.key], h.col, stats.get(h.key))?.bgcolor ? 'on' : undefined}
                          data-sign={valueSx(r[h.key], h.col, stats.get(h.key), signColours)?.color && valueSx(r[h.key], h.col, stats.get(h.key), signColours)?.color !== 'error.main' ? 'on' : undefined}>
                          {act.cell(r, j < tile.dimensions.length ? h.col : undefined, formatValue(r[h.key], h.col))}
                        </TableCell>
                      ))}
                    </TableRow>
                  );
                }} />
            </TableBody>
          </Table>
          <ListPager paging={pagingFor(total, page, pageSize, rows.length)}
            onPage={setPage} onPageSize={setPageSize} testid={`tile-pager-${tile.id}`} />
        </Box>
      );
    }
    if (tile.kind === 'pivot' || tile.kind === 'heatmap') {
      const ser = cols.get(tile.series!)?.physical_name || '';
      const heat = tile.kind === 'heatmap';
      const heatVals = heat ? rows.map(r => toNum(r[measureAlias(0)])).filter((x): x is number => x != null) : [];
      const hMin = heatVals.length ? Math.min(...heatVals) : 0;
      const hMax = heatVals.length ? Math.max(...heatVals) : 0;
      const heatBg = (v: any) => {
        const n = toNum(v);
        if (!heat || n == null || hMax === hMin) return undefined;
        const f = (n - hMin) / (hMax - hMin);
        return `rgba(42, 120, 214, ${(0.08 + 0.72 * f).toFixed(2)})`;
      };
      const seriesVals: any[] = [];
      const seen = new Set<string>();
      for (const r of rows) {
        const k = JSON.stringify(r[ser]);
        if (!seen.has(k)) { seen.add(k); seriesVals.push(r[ser]); }
      }
      seriesVals.sort((a, b) => (a === null ? 1 : b === null ? -1 : String(a).localeCompare(String(b), undefined, { numeric: true })));
      const shownSeries = seriesVals.slice(0, MAX_PIVOT_COLUMNS);
      const byRow = new Map<string, { keys: any[]; cells: Map<string, any> }>();
      for (const r of rows) {
        const rk = JSON.stringify(dimNames.map(d => r[d]));
        if (!byRow.has(rk)) byRow.set(rk, { keys: dimNames.map(d => r[d]), cells: new Map() });
        byRow.get(rk)!.cells.set(JSON.stringify(r[ser]), r);
      }
      const total = data.total_rows ?? rows.length;
      const pivotStats = new Map(tile.measures.map((m, mi) => [mi, cols.get(m.column_id)?.tile_format?.scale ? scaleStats(rows.map(r => r[measureAlias(mi)])) : null]));
      const pivotSigns = { up: theme.kpi.up_fg, down: theme.kpi.down_fg };
      const tableView = (
        <Box sx={{ overflow: 'auto', height: '100%' }}>
          {(seriesVals.length > MAX_PIVOT_COLUMNS || total > rows.length) && (
            <Typography variant="caption" color="warning.main" component="div" data-testid="tile-pivot-cut">
              {seriesVals.length > MAX_PIVOT_COLUMNS
                ? `Showing ${MAX_PIVOT_COLUMNS} of ${seriesVals.length} columns. `
                : ''}
              {total > rows.length ? `Showing ${rows.length.toLocaleString()} of ${total.toLocaleString()} combinations -- narrow the report with a parameter to see the rest here, or export it.` : ''}
            </Typography>
          )}
          <Table size="small" stickyHeader aria-label={title}>
            <TableHead>
              <TableRow>
                {tile.dimensions.map((id, j) => <TableCell key={id} sx={{ fontWeight: 700, ...stickyLeft(j) }}>{cols.get(id)?.label}</TableCell>)}
                {shownSeries.map(sv => tile.measures.map((m, i) => (
                  <TableCell key={`${JSON.stringify(sv)}-${i}`} align="right" sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>
                    {formatValue(sv, cols.get(tile.series!))}{tile.measures.length > 1 ? ` · ${measureWords(m, cols, grouped)}` : ''}
                  </TableCell>
                )))}
              </TableRow>
            </TableHead>
            <TableBody>
              {[...byRow.values()].slice((page - 1) * pageSize, page * pageSize).map((row, i) => (
                <TableRow key={i} hover data-testid={`tile-row-${tile.id}`}
                  {...(canPick ? {
                    onClick: () => pick(tile.dimensions, row.keys),
                    selected: links.hasSelection && !dimmed(tile.dimensions, row.keys),
                    sx: { cursor: 'pointer' },
                  } : {})}>
                  {row.keys.map((k, j) => <TableCell key={j} sx={stickyLeft(j, true)}>{act.cell(Object.fromEntries(dimNames.map((d, x) => [d, row.keys[x]])), cols.get(tile.dimensions[j]), formatValue(k, cols.get(tile.dimensions[j])))}</TableCell>)}
                  {shownSeries.map(sv => tile.measures.map((m, mi) => {
                    const cell = row.cells.get(JSON.stringify(sv));
                    return (
                      <TableCell key={`${JSON.stringify(sv)}-${mi}`} align="right"
                        sx={{ ...(heat && cell ? { bgcolor: heatBg(cell[measureAlias(mi)]) } : {}), ...(cell ? valueSx(cell[measureAlias(mi)], cols.get(m.column_id), pivotStats.get(mi), pivotSigns) : {}) }}>
                        {cell ? formatValue(cell[measureAlias(mi)], cols.get(m.column_id)) : ''}
                      </TableCell>
                    );
                  }))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {/* the rows are PAGED: a pivot of 9,000 rows x 200 columns drawn at
              once froze the browser (the owner's JOIN, 2026-10-26) */}
          <ListPager paging={pagingFor(byRow.size, page, pageSize, Math.min(pageSize, Math.max(0, byRow.size - (page - 1) * pageSize)))}
            onPage={setPage} onPageSize={setPageSize} testid={`tile-pager-${tile.id}`} />
        </Box>
      );
      // 2026-10-30 -- a heat map of WEBGL_MIN_MARKS cells or more is ONE picture the
      // graphics card draws; without WebGL it stays the table above (the rung below)
      if (heat && chooseRenderer('heatmap', rows.length, { webgl: webglAvailable() }) === 'webgl') {
        const rowIndex = new Map<string, number>();
        [...byRow.keys()].forEach((k, i) => rowIndex.set(k, i));
        const colIndex = new Map<string, number>();
        shownSeries.forEach((sv, i) => colIndex.set(JSON.stringify(sv), i));
        const cells = rows.map(r => ({ row: rowIndex.get(JSON.stringify(dimNames.map(d => r[d]))) ?? -1,
          col: colIndex.get(JSON.stringify(r[ser])) ?? -1, value: toNum(r[measureAlias(0)]) }));
        drawn.current = { renderer: 'webgl', rows: rows.length, sourceRows: total, marks: rows.length };
        return (
          <Box data-testid="tile-chart" data-kind="heatmap" data-renderer="webgl" data-rows={rows.length}>
            <WebGLChart buffer={heatmapBuffer(cells, byRow.size, shownSeries.length, width, Math.max(80, height - 58))}
              width={width} height={Math.max(80, height - 58)} color={theme.palette[0]} heat fallback={tableView}
              caption={`${byRow.size.toLocaleString('en-US')} rows x ${shownSeries.length} columns; darker = larger.`}
              onDrawn={r => { if (r === 'fallback' && drawn.current) drawn.current.renderer = 'table'; }} />
          </Box>
        );
      }
      return tableView;
    }
    // charts -- every kind (2026-10-26, the owner: "all type of charts")
    const cat = dimNames[0];
    const catCol = cols.get(tile.dimensions[0]);
    const mCol = cols.get(tile.measures[0]?.column_id);
    const total = data.total_rows ?? rows.length;
    const catLabel = (v: any) => formatValue(v, catCol);
    // room under the chart for its one-line note ("Showing 25 of N ...")
    const chartH = Math.max(80, height - 58);
    const color = (i: number) => theme.palette[i % theme.palette.length];   // the report's own palette (canvasTheme)
    const compact = (v: any) => Number(v).toLocaleString(undefined, { notation: 'compact' });
    // a down-sampled line / area is not CUT -- its own note says "Drawn from N of M"
    const cutNote = total > rows.length && !data.downsampled
      ? `Showing ${rows.length} of ${total.toLocaleString()} ${catCol?.label ?? 'values'}${tile.sort?.by === 'measure' ? (tile.sort.dir === 'desc' ? ', largest first' : ', smallest first') : ''}.`
      : '';
    const note = (extraWords = '') => (cutNote || extraWords)
      ? <Typography variant="caption" color="text.secondary" data-testid="tile-chart-cut">{cutNote}{extraWords}</Typography>
      : null;
    const tip = <ReTooltip formatter={(v: any) => formatValue(v, mCol)} />;
    // linked tiles: a click on a category picks it; what is not picked fades
    const pickCat = (i: any) => {
      if (i === null || i === undefined || i === '') return;
      const n = Number(i);
      if (Number.isInteger(n) && n >= 0 && n < rows.length) pick([tile.dimensions[0]], [rows[n][cat]], rows[n]);
    };
    const fade = (i: number) => (i < rows.length && dimmed([tile.dimensions[0]], [rows[i]?.[cat]]) ? 0.35 : 1);
    const chartClick = canPick ? { onClick: (s: any) => pickCat(s?.activeTooltipIndex ?? s?.activeIndex) } : {};
    const barClick = canPick ? { onClick: (d: any, i: number) => pickCat(d?.payload?.__i ?? i) } : {};
    const pickHint = canPick ? { 'data-pick': 'on', sx: { cursor: 'pointer' } } : {};

    // ── one value per category ──
    if (['pie', 'donut', 'treemap', 'funnel'].includes(tile.kind)) {
      const vals = rows.map(r => ({ name: catLabel(r[cat]), value: toNum(r[measureAlias(0)]) ?? 0 }));
      if (tile.kind !== 'funnel' && vals.some(v => v.value < 0)) {
        // (rig 2026-11-02) a share of a SIGNED amount (P&L) has no slices: the same values are
        // drawn as ranked bars and the tile SAYS why -- an empty box with advice helped nobody
        return <Box data-testid="tile-pie-negative">
          <CanvasTileView tile={{ ...tile, kind: 'hbar', sign_bars: true, labels: tile.labels === 'percent' ? 'values' : tile.labels,
            sort: tile.sort ?? { by: 'measure', dir: 'desc' } }} reportId={reportId} cols={rawCols} grouped={grouped} run={run}
            reportTable={reportTable} width={width} height={Math.max(80, height - 22)} cubeFetch={cubeFetch} staleFields={staleFields} drill={drill} />
          <Typography variant="caption" color="text.secondary" data-testid="tile-pie-negative-note">
            Shown as bars: some values are below zero, and a {tile.kind === 'treemap' ? 'treemap' : 'pie'} can only show parts of a positive whole.
          </Typography>
        </Box>;
      }
      const whole = toNum(extra?.whole?.rows?.[0]?.[measureAlias(0)]);
      const shownSum = vals.reduce((a, b) => a + b.value, 0);
      // (rig 2026-11-01) the remainder: folded unless the tile says "top N only", never more than
      // other_max_share (default 25 %) of the picture -- the real rest is said in the note
      const foldOthers = (tile.other_mode ?? 'fold') !== 'none';
      const restReal = foldOthers && WHOLE.includes(tile.kind) && whole != null && total > rows.length && whole - shownSum > 0 ? whole - shownSum : 0;
      const share = Math.min(0.9, Math.max(0.05, tile.other_max_share ?? 0.25));
      const restCap = shownSum > 0 ? shownSum * share / (1 - share) : restReal;
      const rest = restReal > 0 ? Math.min(restReal, restCap) : 0;
      const restMore = total - rows.length;
      if (rest) vals.push({ name: 'Everything else', value: rest });
      const fill = (v: { name: string }, i: number) => v.name === 'Everything else' ? theme.tiles.other_fill : color(i);
      // chart options (2026-11-02): the words on each slice and the donut's centre total
      const pieTotal = vals.reduce((a, b) => a + b.value, 0);
      const sliceLabel = tile.labels && tile.labels !== 'none'
        ? (e: any) => (tile.labels === 'percent' ? percentOf(e.value, pieTotal) ?? '' : formatValue(e.value, mCol))
        : undefined;
      const centreTotal = tile.kind === 'donut' && tile.centre === 'total' ? formatValue(pieTotal, mCol) : null;
      let chart: React.ReactNode;
      if (tile.kind === 'treemap') {
        chart = (
          <Treemap width={width} height={chartH} data={vals.map((v, i) => ({ ...v, fill: fill(v, i) }))} dataKey="value"
            nameKey="name" isAnimationActive={false} stroke="#fff"
            content={(props: any) => (
              <g onClick={canPick ? () => pickCat(props.index) : undefined} data-testid="tile-treemap-cell"
                onContextMenu={act.live ? (e: any) => act.openAt(e, rows[Number(props.index)]) : undefined}>
                <rect x={props.x} y={props.y} width={props.width} height={props.height} fill={props.fill ?? color(props.index ?? 0)} stroke="#fff"
                  fillOpacity={fade(props.index ?? 0)} />
                {props.width > 50 && props.height > 18 && (
                  <text x={props.x + 4} y={props.y + 14} fontSize={11} fill="#fff">{String(props.name ?? '').slice(0, 24)}</text>
                )}
              </g>
            )}>
            {tip}
          </Treemap>
        );
      } else if (tile.kind === 'funnel') {
        chart = (
          <FunnelChart width={width} height={chartH}>
            {tip}
            <Funnel data={vals.map((v, i) => ({ ...v, fill: color(i), fillOpacity: fade(i) }))} dataKey="value" nameKey="name" isAnimationActive={false}
              {...(canPick ? { onClick: (_d: any, i: number) => pickCat(i) } : {})} {...act.itemProps(i => rows[i])}>
              <LabelList position="right" fill="#333" stroke="none" dataKey="name" fontSize={11} />
            </Funnel>
          </FunnelChart>
        );
      } else {
        const r = Math.max(30, Math.min(width, chartH) / 2 - 20);
        chart = (
          <PieChart width={width} height={chartH} {...act.chartProps(rows)}>
            <Pie data={vals} dataKey="value" nameKey="name" outerRadius={r} innerRadius={tile.kind === 'donut' ? r * 0.55 : 0}
              isAnimationActive={false} {...(canPick ? { onClick: (_d: any, i: number) => pickCat(i) } : {})}
              {...(sliceLabel ? { label: (e: any) => sliceLabel(e), labelLine: false } : {})}>
              {vals.map((v, i) => <Cell key={i} fill={fill(v, i)} fillOpacity={fade(i)} />)}
            </Pie>
            {tip}
            <Legend />
          </PieChart>
        );
      }
      if (centreTotal !== null) {
        chart = (
          <Box sx={{ position: 'relative', width, height: chartH }}>
            {chart}
            <Typography data-testid="tile-donut-centre" sx={{ position: 'absolute', left: 0, top: 'calc(50% - 18px)', width, transform: 'translateY(-50%)', textAlign: 'center', fontWeight: 700, fontSize: Math.max(12, Math.min(22, (Math.min(width, chartH) / 2 - 20) * 0.3)), pointerEvents: 'none' }}>{centreTotal}</Typography>
          </Box>
        );
      }
      return <Box data-testid="tile-chart" data-kind={tile.kind} data-labels={tile.labels ?? undefined} {...pickHint}>{chart}{note(rest
        ? ` The other ${restMore.toLocaleString()} are one muted part, "Everything else"${rest < restReal ? ` (drawn smaller than its ${compact(restReal)} so it does not hide the rest)` : ''}.`
        : !foldOthers && total > rows.length ? ` The top ${rows.length} only; the other ${restMore.toLocaleString()} are not drawn.` : '')}</Box>;
    }

    // ── points: scatter (x, y) and bubble (x, y, size) ──
    if (tile.kind === 'scatter' || tile.kind === 'bubble') {
      const pts = rows.map((r, i) => ({ name: catLabel(r[cat]), x: toNum(r[measureAlias(0)]), y: toNum(r[measureAlias(1)]),
                                   z: tile.kind === 'bubble' ? toNum(r[measureAlias(2)]) : 1, __i: i }))
        .filter(p => p.x != null && p.y != null);
      const words = tile.measures.map(m => measureWords(m, cols, grouped));
      const scatterOn = tile.kind === 'scatter' ? chooseRenderer('scatter', pts.length, { webgl: webglAvailable() }) : 'svg';
      drawn.current = { renderer: scatterOn, rows: rows.length, sourceRows: rows.length, marks: pts.length };
      const canvasScatter = (
        <CanvasChart width={width} height={chartH} format={v => formatValue(v, mCol)}
          spec={{ kind: 'scatter', categories: pts.map(p => p.name), xs: pts.map(p => p.x),
                  series: [{ name: words[1] ?? '', color: color(0), values: pts.map(p => p.y) }] }} />
      );
      if (scatterOn === 'webgl') {
        // 2026-10-30 -- the graphics card draws the points; no WebGL here -> the 2D canvas
        return (
          <Box data-testid="tile-chart" data-kind={tile.kind} data-renderer="webgl" data-rows={rows.length}>
            <WebGLChart buffer={scatterBuffer(pts.map(p => p.x), pts.map(p => p.y), width, chartH)}
              width={width} height={chartH} color={color(0)} fallback={canvasScatter}
              onDrawn={r => { if (r === 'fallback' && drawn.current) drawn.current.renderer = 'canvas'; }} />
            {note(` Across: ${words[0]}; up: ${words[1]}.`)}
          </Box>
        );
      }
      if (scatterOn === 'canvas') {
        return (
          <Box data-testid="tile-chart" data-kind={tile.kind} data-renderer="canvas" data-rows={rows.length}>
            {canvasScatter}
            {note(` Across: ${words[0]}; up: ${words[1]}.`)}
          </Box>
        );
      }
      return (
        <Box data-testid="tile-chart" data-kind={tile.kind} data-renderer="svg" {...pickHint}>
          <ScatterChart width={width} height={chartH} margin={{ top: 8, right: 12, bottom: 8, left: 8 }}>
            <CartesianGrid stroke="#e1e0d9" />
            <XAxis type="number" dataKey="x" name={words[0]} tick={{ fontSize: 11 }} tickFormatter={compact} />
            <YAxis type="number" dataKey="y" name={words[1]} tick={{ fontSize: 11 }} tickFormatter={compact} width={56} />
            {tile.kind === 'bubble' && <ZAxis type="number" dataKey="z" name={words[2]} range={[40, 900]} />}
            <ReTooltip cursor={{ strokeDasharray: '3 3' }}
              formatter={(v: any, n: any) => [formatValue(v, mCol), n]}
              labelFormatter={() => ''} />
            <Scatter data={pts} fill={color(0)} isAnimationActive={false} {...barClick}
              {...act.itemProps((i, d) => rows[d?.payload?.__i ?? d?.__i ?? pts[i]?.__i])}>
              {pts.map((p, i) => <Cell key={i} fillOpacity={fade(p.__i)} />)}
            </Scatter>
          </ScatterChart>
          {note(` Across: ${words[0]}; up: ${words[1]}${tile.kind === 'bubble' ? `; size: ${words[2]}` : ''}.`)}
        </Box>
      );
    }

    // ── a running total ──
    if (tile.kind === 'waterfall') {
      // a bridge (no category, 2026-11-03): one step per value, in the tile's order
      const bridge = isBridge(tile);
      const src = bridge
        ? tile.measures.map((m, i) => ({ label: measureWords(m, cols, grouped), v: toNum(rows[0]?.[measureAlias(i)]) ?? 0 }))
        : rows.map(r => ({ label: catLabel(r[cat]), v: toNum(r[measureAlias(0)]) ?? 0 }));
      let run = 0;
      const steps = src.map(({ label, v }) => {
        const start = run;
        run += v;
        return { __cat: label, base: Math.min(start, run), up: v >= 0 ? v : 0, down: v < 0 ? -v : 0 };
      });
      steps.push({ __cat: 'Total', base: Math.min(0, run), up: run >= 0 ? run : 0, down: run < 0 ? -run : 0 });
      return (
        <Box data-testid="tile-chart" data-kind="waterfall" {...pickHint}>
          <BarChart width={width} height={chartH} data={steps} margin={{ top: 4, right: 8, bottom: 4, left: 8 }} {...(bridge ? {} : chartClick)} {...(bridge ? {} : act.chartProps(rows))}>
            <CartesianGrid stroke="#e1e0d9" vertical={false} />
            <XAxis dataKey="__cat" tick={{ fontSize: 11 }} interval="preserveStartEnd" />
            <YAxis tick={{ fontSize: 11 }} tickFormatter={compact} width={56} />
            <ReTooltip formatter={(v: any, n: any) => (n === 'base' ? null : [formatValue(v, mCol), n === 'up' ? 'Up' : 'Down'])} />
            <Bar dataKey="base" stackId="w" fill="transparent" isAnimationActive={false} />
            <Bar dataKey="up" stackId="w" fill="#1baf7a" isAnimationActive={false} {...(bridge ? {} : act.itemProps(i => rows[i]))} />
            <Bar dataKey="down" stackId="w" fill="#e34948" isAnimationActive={false} {...(bridge ? {} : act.itemProps(i => rows[i]))} />
          </BarChart>
          {note(bridge ? ' Each value is a step; the last bar is their total.' : ' Each bar starts where the one before it ended; the last bar is the total.')}
        </Box>
      );
    }

    // ── categories x one or more series ──
    let chartData: any[];
    let seriesKeys: string[];
    let seriesNames: string[];
    let seriesNote = '';
    if (extra?.pairs) {
      const ser = extra.ser;
      const serVals: any[] = (extra.seriesTotals.rows || []).map((r: any) => r[ser]);
      seriesKeys = serVals.map(v => formatValue(v, cols.get(tile.series!)));
      seriesNames = seriesKeys;
      const byCat = new Map<string, any>();
      rows.forEach((r, i) => byCat.set(JSON.stringify(r[cat]), { __cat: catLabel(r[cat]), __i: i }));
      for (const p of extra.pairs.rows || []) {
        const e = byCat.get(JSON.stringify(p[cat]));
        if (e) e[formatValue(p[ser], cols.get(tile.series!))] = toNum(p[measureAlias(0)]);
      }
      chartData = [...byCat.values()];
      const totalSeries = extra.seriesTotals.total_rows ?? serVals.length;
      if (totalSeries > serVals.length) seriesNote = ` ${serVals.length} of ${totalSeries} ${cols.get(tile.series!)?.label ?? 'series'} shown (the largest).`;
    } else {
      seriesKeys = tile.measures.map((_, i) => measureAlias(i));
      seriesNames = tile.measures.map(m => measureWords(m, cols, grouped));
      chartData = rows.map((r, i) => {
        const o: any = { __cat: catLabel(r[cat]), __i: i };
        for (const k of seriesKeys) o[k] = toNum(r[k]);
        if (extra?.overlay) { const ra = extra.overlay.byCat.get(JSON.stringify(r[cat])); for (const k of seriesKeys) o[`${k}a`] = ra ? toNum(ra[k]) : null; }
        return o;
      });
      if (extra?.overlay) seriesNames = seriesNames.map(n => `${n} ${extra.overlay.b}`);
    }
    // chart options (2026-11-02): the words on each mark
    const barTotal = chartData.reduce((a, d) => a + Math.abs(Number(d[seriesKeys[0]]) || 0), 0);
    const markLabel = tile.labels && tile.labels !== 'none' && !extra?.pairs
      ? <LabelList dataKey={seriesKeys[0]} position="top" fontSize={10} formatter={(v: any) => (tile.labels === 'percent' ? percentOf(toNum(v), barTotal) ?? '' : formatValue(v, mCol))} />
      : null;
    // ── the drawing ladder (2026-10-30): how many marks the SOURCE holds decides SVG or canvas ──
    const sourceRows: number = data.downsampled?.from ?? rows.length;
    const marks = markCount(sourceRows, seriesKeys.length);
    if (DOWNSAMPLE_KINDS.includes(tile.kind) && !extra?.pairs && chartData.length > maxPointsFor(width)) {
      // what reached the browser long anyway (a link's cube): about a point per pixel, the shape kept
      chartData = lttb(chartData, d => d[seriesKeys[0]], maxPointsFor(width));
    }
    const sampledNote = sourceRows > chartData.length && DOWNSAMPLE_KINDS.includes(tile.kind)
      ? ` Drawn from ${chartData.length.toLocaleString()} of ${sourceRows.toLocaleString()} points, chosen to keep the shape.` : '';
    const legend = seriesKeys.length > 1 ? <Legend /> : null;
    // values of very different size (an amount next to a quantity): the small
    // ones go on their own scale on the right, so their line keeps its shape.
    // Only for several VALUES -- series of one value share one scale.
    const peak = (k: string) => Math.max(0, ...chartData.map(d => Math.abs(Number(d[k]) || 0)));
    const top = Math.max(0, ...seriesKeys.map(peak));
    const onRight = new Set<string>(
      tile.kind === 'combo' ? seriesKeys.slice(1)
        : !extra?.pairs && seriesKeys.length > 1 && !['stacked_bar', 'stacked_area'].includes(tile.kind)
          ? seriesKeys.filter(k => top > 0 && peak(k) > 0 && top / peak(k) > 20) : []);
    const margin = { top: 4, right: 8, bottom: 4, left: 8 };
    const renderer = onRight.size === 0 && !['stacked_bar', 'stacked_area'].includes(tile.kind) && !extra?.overlay
      ? chooseRenderer(tile.kind, marks) : 'svg';
    drawn.current = { renderer, rows: rows.length, sourceRows, marks };
    const meta = { 'data-renderer': renderer, 'data-rows': rows.length, 'data-source-rows': sourceRows };
    if (renderer === 'canvas') {
      return (
        <Box data-testid="tile-chart" data-kind={tile.kind} {...meta}>
          <CanvasChart width={width} height={chartH} format={v => formatValue(v, mCol)}
            spec={{ kind: tile.kind as any, categories: chartData.map(d => d.__cat),
                    series: seriesKeys.map((k, i) => ({ name: seriesNames[i], color: color(i), values: chartData.map(d => d[k] ?? null) })) }} />
          {note(seriesNote + sampledNote)}
        </Box>
      );
    }
    let chart: React.ReactNode;
    if (tile.kind === 'radar') {
      chart = (
        <RadarChart width={width} height={chartH} data={chartData} outerRadius={Math.max(30, Math.min(width, chartH) / 2 - 30)} {...chartClick} {...act.chartProps(rows)}>
          <PolarGrid />
          <PolarAngleAxis dataKey="__cat" tick={{ fontSize: 11 }} />
          <PolarRadiusAxis tick={{ fontSize: 10 }} tickFormatter={compact} />
          {tip}{legend}
          {seriesKeys.map((k, i) => <Radar key={k} dataKey={k} name={seriesNames[i]} stroke={color(i)} fill={color(i)} fillOpacity={0.25} isAnimationActive={false}
            dot={act.live ? (p: any) => (
              <circle key={`${k}-${p.index}`} cx={p.cx} cy={p.cy} r={3} fill={color(i)} data-testid="tile-radar-point"
                onContextMenu={(e: any) => act.openAt(e, rows[chartData[p.index]?.__i ?? p.index])} />
            ) : false} />)}
        </RadarChart>
      );
    } else if (tile.kind === 'hbar') {
      chart = (
        <BarChart width={width} height={chartH} data={chartData} layout="vertical" margin={margin} {...act.chartProps(rows)}>
          <CartesianGrid stroke="#e1e0d9" horizontal={false} />
          <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={compact} />
          <YAxis type="category" dataKey="__cat" tick={{ fontSize: 11 }} width={Math.min(160, Math.max(60, width * 0.25))} />
          {tip}{legend}
          {seriesKeys.map((k, i) => (
            <Bar key={k} dataKey={k} name={seriesNames[i]} fill={color(i)} isAnimationActive={false} {...barClick}>
              {chartData.map((d, j) => <Cell key={j} fillOpacity={fade(d.__i)}
                {...(tile.sign_bars ? { fill: Number(d[k]) < 0 ? '#c62828' : '#2e7d32' } : {})} />)}
            </Bar>
          ))}
        </BarChart>
      );
    } else {
      const stacked = tile.kind === 'stacked_bar' || tile.kind === 'stacked_area';
      const Chart: any = tile.kind === 'combo' ? ComposedChart
        : tile.kind === 'line' ? LineChart
        : tile.kind === 'area' || tile.kind === 'stacked_area' ? AreaChart : BarChart;
      chart = (
        <Chart width={width} height={chartH} data={chartData} margin={margin} {...(tile.kind === 'combo' || tile.kind === 'line' || tile.kind === 'area' || tile.kind === 'stacked_area' ? chartClick : {})} {...act.chartProps(rows)}>
          <CartesianGrid stroke="#e1e0d9" vertical={false} />
          <XAxis dataKey="__cat" tick={{ fontSize: 11 }} interval="preserveStartEnd" />
          <YAxis yAxisId="left" tick={{ fontSize: 11 }} tickFormatter={compact} width={56} />
          {onRight.size > 0 && <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} tickFormatter={compact} width={56} />}
          {tip}{legend}
          {seriesKeys.map((k, i) => {
            const name = seriesNames[i];
            const axis = onRight.has(k) ? 'right' : 'left';
            const label = onRight.has(k) ? `${name} (right)` : name;
            const dottedA = extra?.overlay
              ? <Line key={`${k}a`} yAxisId={axis} type="monotone" dataKey={`${k}a`} name={`${seriesNames[i].replace(` ${extra.overlay.b}`, '')} ${extra.overlay.a}`} stroke={color(i)} strokeDasharray="4 3" dot={false} isAnimationActive={false} connectNulls={false} className="overlay-a" />
              : null;
            if (tile.kind === 'line' || (tile.kind === 'combo' && i > 0)) {
              return [<Line key={k} yAxisId={axis} type="monotone" dataKey={k} name={label} stroke={color(i)} dot={false} isAnimationActive={false} connectNulls={false}>{i === 0 ? markLabel : null}</Line>, dottedA];
            }
            if (tile.kind === 'area' || tile.kind === 'stacked_area') {
              return <Area key={k} yAxisId={axis} type="monotone" dataKey={k} name={label} stroke={color(i)} fill={color(i)} fillOpacity={0.3}
                stackId={stacked ? 'a' : undefined} isAnimationActive={false} />;
            }
            if (tile.kind === 'combo') {
              return [<Bar key={k} yAxisId={axis} dataKey={k} name={label} fill={color(i)} isAnimationActive={false}>{markLabel}</Bar>, dottedA];
            }
            return [
              <Bar key={k} yAxisId={axis} dataKey={k} name={label} fill={color(i)} stackId={stacked ? 'a' : undefined} isAnimationActive={false} {...barClick}>
                {chartData.map((d, j) => <Cell key={j} fillOpacity={fade(d.__i)} />)}
                {i === 0 ? markLabel : null}
              </Bar>, dottedA];
          })}
        </Chart>
      );
    }
    return <Box data-testid="tile-chart" data-kind={tile.kind} data-labels={tile.labels ?? undefined} data-overlay={extra?.overlay ? 'on' : undefined} {...meta} {...pickHint}>{chart}{note(seriesNote + sampledNote + (extra?.overlay ? ` ${extra.overlay.b} as the ${tile.kind === 'line' ? 'line' : 'bars'}, ${extra.overlay.a} as the dotted line.` : ''))}</Box>;
  }

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0 }} data-testid={`tile-${tile.id}`} ref={tileRef}
      onClickCapture={e => { additive.current = e.ctrlKey || e.metaKey; }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
        {/* theme v2: the card's title colour and alignment ('app' = as before) */}
        {/* the pie / treemap fallback (sign_bars) is drawn INSIDE its own tile, which already shows the title */}
        {!tile.sign_bars && <Typography variant="subtitle2" noWrap sx={{ flex: 1, color: cssColour(theme.card.title_fg), textAlign: theme.card.title_align }} title={title}>{title}</Typography>}
        {loading && data && <CircularProgress size={12} />}
      </Box>
      {run.truncated && run.executionId && (
        <Tooltip title="The report has a row limit; this tile adds up only the rows the run kept.">
          <Typography variant="caption" color="warning.main" data-testid="tile-truncated">
            Based on the first {run.rowLimit ? run.rowLimit.toLocaleString() : ''} rows only.
          </Typography>
        </Tooltip>
      )}
      <TileLinkCaption cols={cols} />
      <Box sx={{ flex: 1, minHeight: 0 }}>{body}</Box>
      {act.ui}
    </Box>
  );
}
