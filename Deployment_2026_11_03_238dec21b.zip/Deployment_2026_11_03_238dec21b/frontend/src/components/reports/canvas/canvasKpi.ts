/**
 * canvasKpi -- the KPI card: a number tile with an icon, a comparison and a style
 * (2026-11-02; docs/REPORT_DESIGN_UPGRADE_PLAN_2026_11_02.html step 2).  The server's
 * twin is backend/core/reports/canvas_kpi.py (the same words, the same numbers).
 *
 *   icon       one of KPI_ICONS (kpiIcons.tsx maps the name to a picture)
 *   compare    {kind:'parameter'}  the canvas's "two dates to compare" parameter
 *              {kind:'measure', column_id, aggregation, label?}  a second value of the SAME result
 *   good_when  'up' | 'down' (a cost going up is red); default up
 *   style      'theme' | 'plain' | 'filled' | 'gradient'; default theme = the theme's kpi.style
 *   fill       '#rrggbb', this card's own fill (else the theme's fills in turn)
 *   sparkline  {column_id, points: 2..100}  the value by that column, its last N points
 *
 * The comparison is computed from the report's ONE stored result through the cube
 * (the second value in the same drill, or the two dates as slicers) -- never a
 * second query; one that cannot be computed says "No previous value".
 */
import { createContext, useContext } from 'react';
import type { Aggregation, CanvasColumn, CanvasTile, ReportCanvas } from './canvasModel';
import { isHex, kpiFill, type ReportTheme } from './canvasTheme';
import { variance } from './canvasCompare';

export const KPI_ICONS = ['money', 'bank', 'chart', 'trend_up', 'trend_down', 'percent', 'people', 'person', 'building', 'globe',
  'calendar', 'clock', 'warning', 'check', 'flag', 'star', 'cart', 'box', 'truck', 'factory', 'briefcase', 'wallet', 'card',
  'receipt', 'scale', 'shield', 'bolt', 'target', 'pie', 'table', 'savings', 'payments', 'exchange', 'insights', 'speed', 'assessment'] as const;
export type KpiIcon = typeof KPI_ICONS[number];
export type GoodWhen = 'up' | 'down';
export type KpiTileStyle = 'theme' | 'plain' | 'filled' | 'gradient';
export const GOOD_WHEN: GoodWhen[] = ['up', 'down'];
export const KPI_TILE_STYLES: KpiTileStyle[] = ['theme', 'plain', 'filled', 'gradient'];
export const KPI_TILE_STYLE_WORDS: Record<KpiTileStyle, string> = { theme: 'As the theme says', plain: 'Plain (on the card)', filled: 'Filled with a colour', gradient: 'A colour gradient' };
export const MIN_SPARK_POINTS = 2;
export const MAX_SPARK_POINTS = 100;
export const MAX_COMPARE_LABEL = 60;
export const NO_PREVIOUS = 'No previous value';

export type KpiCompare = { kind: 'parameter' } | { kind: 'measure'; column_id: number; aggregation: Aggregation; label?: string };
export interface KpiFields {
  icon?: KpiIcon;
  compare?: KpiCompare;
  good_when?: GoodWhen;
  style?: KpiTileStyle;
  fill?: string;
  sparkline?: { column_id: number; points: number };
}

/** The stored KPI fields of a number tile (readCanvas keeps only what is read here). */
export function readKpiFields(t: any): KpiFields {
  const out: KpiFields = {};
  if (typeof t?.icon === 'string') out.icon = t.icon;
  if (t?.compare && typeof t.compare === 'object') {
    out.compare = t.compare.kind === 'measure'
      ? { kind: 'measure', column_id: Number(t.compare.column_id), aggregation: t.compare.aggregation,
          ...(typeof t.compare.label === 'string' && t.compare.label.trim() ? { label: t.compare.label.trim() } : {}) }
      : { kind: t.compare.kind };
  }
  if (typeof t?.good_when === 'string') out.good_when = t.good_when;
  if (typeof t?.style === 'string') out.style = t.style;
  if (typeof t?.fill === 'string') out.fill = t.fill;
  if (t?.sparkline && typeof t.sparkline === 'object') out.sparkline = { column_id: Number(t.sparkline.column_id), points: Number(t.sparkline.points) };
  return out;
}

/** The columns a number tile's KPI fields need the report's ONE query to return. */
export function kpiColumnIds(t: CanvasTile): number[] {
  const out: number[] = [];
  if (t.compare?.kind === 'measure' && Number.isFinite(t.compare.column_id)) out.push(t.compare.column_id);
  if (t.sparkline && Number.isFinite(t.sparkline.column_id)) out.push(t.sparkline.column_id);
  return out;
}

/** The server's words for a number tile's KPI fields (canvas_kpi.kpi_problems). */
export function kpiProblems(t: CanvasTile, cols: Map<number, CanvasColumn>, selected: Set<number> | null, grouped: boolean,
                            canvas: Pick<ReportCanvas, 'compare'>, say: (t: CanvasTile | null, message: string) => void,
                            measureProblems: (m: { column_id: number; aggregation: Aggregation }) => string[]): void {
  const label = (id: number) => cols.get(id)?.label ?? `column #${id}`;
  if (t.icon != null && !(KPI_ICONS as readonly string[]).includes(t.icon)) say(t, `"${t.icon}" is not one of the card icons.`);
  if (t.good_when != null && !GOOD_WHEN.includes(t.good_when)) say(t, 'a good change is up or down.');
  if (t.style != null && !KPI_TILE_STYLES.includes(t.style)) say(t, 'a card is drawn as the theme says, plain, filled or as a gradient.');
  if (t.fill != null && !isHex(t.fill)) say(t, "the card's fill must be a colour like #1e6fd9.");
  const cmp: any = t.compare;
  if (cmp != null) {
    if (typeof cmp !== 'object' || !['parameter', 'measure'].includes(cmp.kind)) {
      say(t, "the comparison is with the report's two dates, or with another value.");
    } else if (cmp.kind === 'parameter') {
      if (!canvas.compare) say(t, 'it compares with the report\'s two dates, but the canvas has no "two dates to compare" parameter set.');
    } else {
      const id = Number(cmp.column_id);
      if (!cols.has(id)) say(t, 'the value it compares with is no longer in the data. Pick another.');
      else {
        if (selected && !selected.has(id)) say(t, `${label(id)} is not one of the report's columns, so the report does not return it. Add it to the report.`);
        for (const m of measureProblems({ column_id: id, aggregation: cmp.aggregation })) say(t, m);
      }
      if (cmp.label != null && (typeof cmp.label !== 'string' || cmp.label.trim().length > MAX_COMPARE_LABEL)) {
        say(t, `the comparison's name must be text of at most ${MAX_COMPARE_LABEL} characters.`);
      }
    }
  }
  const sp: any = t.sparkline;
  if (sp != null) {
    if (typeof sp !== 'object') say(t, 'a sparkline names the column its points follow and how many points.');
    else {
      const id = Number(sp.column_id);
      if (!cols.has(id)) say(t, 'the sparkline follows a column that is no longer in the data.');
      else if (selected && !selected.has(id)) say(t, `${label(id)} is not one of the report's columns, so the report does not return it. Add it to the report.`);
      else if (t.measures.some(m => m.column_id === id)) say(t, "the sparkline follows the card's own value; pick a date or an ordered column.");
      if (!Number.isInteger(sp.points) || sp.points < MIN_SPARK_POINTS || sp.points > MAX_SPARK_POINTS) {
        say(t, `a sparkline draws between ${MIN_SPARK_POINTS} and ${MAX_SPARK_POINTS} points.`);
      }
    }
  }
}

export interface KpiChange { variance: number | null; pct: number | null; direction: 'up' | 'down' | 'flat' | 'none'; good: boolean | null }

/** The card's change line (the server's canvas_kpi.delta_words): none when there is no previous value. */
export function deltaWords(value: any, previous: any, goodWhen: GoodWhen): KpiChange {
  if (previous === null || previous === undefined || previous === '' || !Number.isFinite(Number(previous))) {
    return { variance: null, pct: null, direction: 'none', good: null };
  }
  const vv = variance(previous, value);
  if (vv.variance === null) return { variance: null, pct: null, direction: 'none', good: null };
  const direction = vv.variance > 0 ? 'up' : vv.variance < 0 ? 'down' : 'flat';
  return { variance: vv.variance, pct: vv.pct, direction, good: direction === 'flat' ? null : direction === goodWhen };
}

export interface KpiLook { style: 'plain' | 'filled' | 'gradient'; fill: string; value_fg: string; label_fg: string; up_fg: string; down_fg: string }

/** The card's style and fill: the tile's own over the theme's; `index` = its place among the number tiles (fills in turn). */
export function kpiLook(t: Pick<CanvasTile, 'style' | 'fill'>, index: number, theme: ReportTheme): KpiLook {
  const style = t.style && t.style !== 'theme' ? t.style : theme.kpi.style;
  return { style, fill: isHex(t.fill) ? t.fill! : kpiFill(theme, index), value_fg: theme.kpi.value_fg, label_fg: theme.kpi.label_fg,
           up_fg: theme.kpi.up_fg, down_fg: theme.kpi.down_fg };
}

/** The KPI cards take the theme's fills IN TURN, in reading order (the exports count the same
 *  way): tile id -> its place among the number tiles; ReportCanvasView mounts it. */
export const KpiIndexContext = createContext<Map<string, number> | null>(null);
export function kpiOrder(tiles: CanvasTile[]): Map<string, number> {
  const out = new Map<string, number>();
  [...tiles].filter(t => t.kind === 'number').sort((a, b) => a.layout.y - b.layout.y || a.layout.x - b.layout.x)
    .forEach((t, i) => out.set(t.id, i));
  return out;
}
export function useKpiIndex(tileId: string): number {
  return useContext(KpiIndexContext)?.get(tileId) ?? 0;
}

/** "▲ 1,234 (+9.1%) vs 30-Oct-2026" / "No previous value" / "". */
export function changeText(change: KpiChange | null | undefined, fmtAbs: (v: number) => string, previousWords: string): string {
  if (!change) return '';
  if (change.direction === 'none') return NO_PREVIOUS;
  const arrow = change.direction === 'up' ? '▲' : change.direction === 'down' ? '▼' : '•';
  const pct = change.pct === null ? '' : ` (${change.pct > 0 ? '+' : ''}${change.pct}%)`;
  return `${arrow} ${fmtAbs(Math.abs(change.variance ?? 0))}${pct} ${previousWords}`.trim();
}
