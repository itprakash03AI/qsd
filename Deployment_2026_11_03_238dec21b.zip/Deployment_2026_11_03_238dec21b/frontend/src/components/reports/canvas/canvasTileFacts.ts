/**
 * What each canvas tile DREW for a run -- for the Diagnostics panel (2026-10-30).
 *
 * A tile reads the run's stored result through the cube route; the server does
 * not record per-tile figures, so the tile itself publishes what it received
 * (its rows, its totals when it holds every row, and the filters its request
 * carried -- a linked tile's chips travel as `slicers` / `path_filters`).  The
 * panel shows exactly that, never a second computation.  A tile that has not
 * drawn (off screen, still loading) has no facts and the panel says so.
 *
 * Two hooks in `CanvasTileView.tsx`: `noteTileRequests` wraps the tile's cube
 * call (each answer remembers the request that asked for it, so the facts of
 * the tile's own data carry ITS filters even when loads overlap), and
 * `publishTileFacts` / `publishTileError` after the load.
 */
import { useSyncExternalStore } from 'react';

export interface TileFacts {
  tileId: string;
  title: string;
  kind: string;
  /** rows in the tile's own answer (the cube's total_rows), null = not told */
  rows: number | null;
  /** rows the tile received */
  shown: number;
  /** per value column, the sum over the rows -- only when the tile holds them all */
  totals: Record<string, number> | null;
  /** the filters the tile's request carried: column -> values */
  filters: Record<string, any[]>;
  error?: string;
  at: number;
}

type Listener = () => void;
const facts = new Map<string, Map<string, TileFacts>>();   // execution id -> tile id -> facts
const bodyOf = new WeakMap<object, any>();                  // a cube answer -> the request that asked for it
const lastBody = new Map<string, any>();                    // tile id -> its latest request (for a failure)
const listeners = new Set<Listener>();
let version = 0;

function emit() {
  version += 1;
  listeners.forEach(l => l());
}

/** Wrap a tile's cube call so each answer remembers the request that asked for it. */
export function noteTileRequests<F extends (r: number, e: string, b: any) => Promise<any>>(tileId: string, fetch: F): F {
  return (((r: number, e: string, b: any) => {
    lastBody.set(tileId, b);
    return Promise.resolve(fetch(r, e, b)).then((res: any) => {
      if (res && typeof res === 'object') bodyOf.set(res, b);
      return res;
    });
  }) as unknown) as F;
}

function requestFilters(body: any): Record<string, any[]> {
  const out: Record<string, any[]> = {};
  const sl = body?.slicers;
  if (sl && typeof sl === 'object') {
    for (const [k, v] of Object.entries(sl)) {
      const vals = Array.isArray(v) ? v : [v];
      if (vals.length) out[k] = vals;
    }
  }
  for (const pf of Array.isArray(body?.path_filters) ? body.path_filters : []) {
    const col = pf?.column ?? pf?.dimension;
    if (col != null) out[String(col)] = [...(out[String(col)] || []), pf?.value];
  }
  // linked clicked paths (canvasLinks.linkFilter): one entry per clause, in words
  for (const clause of Array.isArray(body?.link_paths) ? body.link_paths : []) {
    if (!Array.isArray(clause)) continue;
    const words = clause.map((p: any[]) => (Array.isArray(p) ? p : [])
      .map((s: any) => `${s?.column} = ${s?.value ?? '(no value)'}`).join(' and ')).join(' or ');
    out['clicked paths'] = [...(out['clicked paths'] || []), words];
  }
  return out;
}

function totalsOf(rows: any[], body: any): Record<string, number> | null {
  const aliases: string[] = (body?.measures || []).map((m: any) => m?.alias).filter(Boolean);
  if (!aliases.length) return null;
  const out: Record<string, number> = {};
  for (const a of aliases) {
    let sum = 0;
    for (const r of rows) {
      const n = typeof r?.[a] === 'number' ? r[a] : Number(r?.[a]);
      if (Number.isFinite(n)) sum += n;
    }
    out[a] = sum;
  }
  return out;
}

function put(executionId: string, f: TileFacts) {
  let m = facts.get(executionId);
  if (!m) { m = new Map(); facts.set(executionId, m); }
  m.set(f.tileId, f);
  emit();
}

/** After a tile's load: what it drew. */
export function publishTileFacts(executionId: string | null, tile: { id: string; title?: string; kind: string }, data: any) {
  const body = data && typeof data === 'object' ? bodyOf.get(data) : undefined;
  if (!executionId) return;
  const rows: any[] = Array.isArray(data?.rows) ? data.rows : [];
  const total = typeof data?.total_rows === 'number' ? data.total_rows : null;
  const complete = total != null && total <= rows.length;
  put(executionId, {
    tileId: tile.id, title: tile.title || '', kind: tile.kind, rows: total, shown: rows.length,
    totals: complete ? totalsOf(rows, body) : null, filters: requestFilters(body), at: Date.now(),
  });
}

/** After a tile's load failed: the sentence it showed. */
export function publishTileError(executionId: string | null, tile: { id: string; title?: string; kind: string }, error: string) {
  const body = lastBody.get(tile.id);
  if (!executionId) return;
  put(executionId, {
    tileId: tile.id, title: tile.title || '', kind: tile.kind, rows: null, shown: 0, totals: null,
    filters: requestFilters(body), error, at: Date.now(),
  });
}

export function tileFactsFor(executionId: string | null): TileFacts[] {
  if (!executionId) return [];
  return [...(facts.get(executionId)?.values() || [])];
}

/** The facts of a run's tiles, re-rendering when a tile publishes. */
export function useTileFacts(executionId: string | null): TileFacts[] {
  useSyncExternalStore(
    (l: Listener) => { listeners.add(l); return () => { listeners.delete(l); }; },
    () => version,
  );
  return tileFactsFor(executionId);
}

/** Tests only. */
export function resetTileFactsForTests() {
  facts.clear(); lastBody.clear(); emit();
}
