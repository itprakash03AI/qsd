/**
 * canvasChartOptions -- labels on the marks, the donut's centre total, the
 * two-dates overlay (2026-11-02; the server's twin is backend/core/reports/canvas_chart_options.py).
 *
 *   labels           'none' | 'values' | 'percent'   values on the marks; percent = the share of the chart's total
 *   centre           'none' | 'total'                a donut writes its total in the middle
 *   compare_overlay  true                            under the canvas's two-dates comparison a bar / line / combo
 *                                                    draws B as its marks and A as a DOTTED line
 */
import type { CanvasTile, ReportCanvas, TileKind } from './canvasModel';

export type LabelMode = 'none' | 'values' | 'percent';
export type CentreMode = 'none' | 'total';
export const LABEL_MODES: LabelMode[] = ['none', 'values', 'percent'];
export const CENTRE_MODES: CentreMode[] = ['none', 'total'];
export const LABEL_KINDS: TileKind[] = ['bar', 'hbar', 'stacked_bar', 'line', 'area', 'combo', 'pie', 'donut', 'funnel', 'treemap', 'waterfall'];
export const PERCENT_KINDS: TileKind[] = ['bar', 'hbar', 'pie', 'donut', 'funnel', 'treemap'];
export const OVERLAY_KINDS: TileKind[] = ['bar', 'line', 'combo'];
export const LABEL_WORDS: Record<LabelMode, string> = { none: 'No labels', values: 'The values', percent: 'The share of the total (%)' };

export interface ChartOptionFields { labels?: LabelMode; centre?: CentreMode; compare_overlay?: boolean }

/** The stored chart options of a tile (readCanvas keeps only what is read here). */
export function readChartOptions(t: any): ChartOptionFields {
  const out: ChartOptionFields = {};
  if (typeof t?.labels === 'string') out.labels = t.labels;
  if (typeof t?.centre === 'string') out.centre = t.centre;
  if (typeof t?.compare_overlay === 'boolean') out.compare_overlay = t.compare_overlay;
  return out;
}

/** The server's words (canvas_chart_options.chart_option_problems). */
export function chartOptionProblems(t: CanvasTile, canvas: Pick<ReportCanvas, 'compare'>, say: (t: CanvasTile | null, message: string) => void): void {
  const lm: any = t.labels;
  if (lm != null) {
    if (!LABEL_MODES.includes(lm)) say(t, 'labels on the marks are off, the values, or the share of the total.');
    else if (!LABEL_KINDS.includes(t.kind)) say(t, 'this kind of chart cannot write labels on its marks.');
    else if (lm === 'percent' && !PERCENT_KINDS.includes(t.kind)) say(t, 'the share of the total can be written on bars, a pie, a donut, a funnel or a treemap.');
  }
  const c: any = t.centre;
  if (c != null) {
    if (!CENTRE_MODES.includes(c)) say(t, 'the centre of a donut is empty or shows the total.');
    else if (t.kind !== 'donut') say(t, 'only a donut has a centre to write the total in.');
  }
  const ov: any = t.compare_overlay;
  if (ov != null) {
    if (typeof ov !== 'boolean') say(t, 'the two-dates overlay is on or off.');
    else if (ov && !OVERLAY_KINDS.includes(t.kind)) say(t, 'the two-dates overlay (B as the marks, A as a dotted line) draws on a bar, a line or a bars-and-lines chart.');
    else if (ov && t.series != null) say(t, 'the two-dates overlay cannot be drawn on a chart split into series.');
    else if (ov && !canvas.compare) say(t, 'it draws the two-dates overlay, but the canvas has no "two dates to compare" parameter set.');
  }
}

/** Does this tile draw B as its marks and A as a dotted line for this run? */
export const overlayWanted = (t: CanvasTile, setting: { a: string; b: string } | { error: string } | null | undefined): boolean =>
  t.compare_overlay === true && OVERLAY_KINDS.includes(t.kind) && t.series == null && !!setting && !('error' in setting);

/** "12.5%" -- the share of `v` in `total` (null when there is no total). */
export function percentOf(v: number | null, total: number): string | null {
  if (v === null || !Number.isFinite(v) || !total) return null;
  return `${(Math.abs(v) / Math.abs(total) * 100).toFixed(1)}%`;
}
