/**
 * The canvas OUTLINE tile and the header BAND tile (2026-10-30; plan
 * docs/REPORT_OUTLINE_AND_DETAIL_LINKS_2026_10_30.html sections 1-3, after the
 * owner's Power BI matrix).
 *
 * OUTLINE: one column per level, then the values.  A plus / minus on every row
 * that has rows under it; several branches open at once; Open all / Close all;
 * the tile opens to its starting level.  Every level and every opened row is a
 * cube drill (POST .../results/{exec_id}/cube) over the report's ONE stored,
 * row-secured result -- never a new query to the source.  A total row is the
 * parent's own group, so it equals the sum of its children exactly.  Values
 * use the tile's number format (red brackets for negatives, a blank zero).
 *
 * BAND: the report's chosen parameter values in a blue band, the report code
 * top right.  The values come from the page (CanvasBandContext): the viewer
 * gives the values the report ran with, the builder the preview's.
 * 2026-11-01 -- THE BAND IS THE CONTROL: when the page provides
 * BandControlsContext (the viewer does), each value is a cell that opens its
 * picker and re-runs the report (reports/ReportBand.tsx); without it (the
 * builder, a share link) the band shows the values only.
 */
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Alert, Box, Button, CircularProgress, IconButton, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, Typography } from '@mui/material';
import AddBoxOutlinedIcon from '@mui/icons-material/AddBoxOutlined';
import IndeterminateCheckBoxOutlinedIcon from '@mui/icons-material/IndeterminateCheckBoxOutlined';
import api from '../../../services/api';
import { CanvasColumn, CanvasTile, measureWords } from './canvasModel';
import type { CubeFetch, TileRunInfo } from './CanvasTileView';
import { formatValue, tileErrorWords } from './CanvasTileView';
import { DENSITY_PY, useCanvasTheme } from './canvasTheme';
import { useCanvasDrill } from './canvasDrill';
import { Menu, MenuItem } from '@mui/material';
import {
  branchesOfLevel, negativeSx, OUTLINE_PAGE, OutlineBranch, outlineLines, openLevelOf, pathKey, ruleSx, scaleStats, valueSx,
} from './canvasOutline';
import { rowSteps, useCanvasLinks, withLinkSlicers } from './canvasLinks';
import { useCanvasCompare } from './canvasCompare';
import { useCanvasTileActions } from './canvasActions';
import { noteTileRequests, publishTileError, publishTileFacts } from './canvasTileFacts';
import { clickableRow } from '../../../utils/clickable';
import { BandControlsContext, ParamBandCells } from '../ReportBand';

// ── the band ──────────────────────────────────────────────────────────────

export interface BandParameter { name: string; label: string; value: any; value_words?: string }
export interface BandInfo {
  reportName: string;
  reportCode?: string | null;
  /** the values on the page (the viewer) / the preview's (the builder); null = none to show */
  parameters: BandParameter[] | null;
  /**
   * The viewer (2026-10-30 integration): the run on the screen.  When given,
   * the band shows the values THAT RUN USED, read from the run's own record
   * (GET .../executions/{exec}/parameters, the Diagnostics record) -- not the
   * page's inputs, which may have been changed since.  null = no run yet: the
   * page's values with "Not run with these values yet."  Absent (the builder)
   * = `parameters` as given.
   */
  executionId?: string | null;
  reportId?: number | null;
}

type BandSource = 'run' | 'page_no_run' | 'page_unrecorded' | 'given';

/** The band's values: the run's recorded values when the page names a run, else the page's (said so). */
function useBandValues(info: BandInfo | null): { params: BandParameter[] | null; source: BandSource; loading: boolean } {
  const exec = info?.executionId;
  const rid = info?.reportId;
  const [rec, setRec] = useState<{ exec: string; params: BandParameter[] | null } | null>(null);
  useEffect(() => {
    if (!exec || !rid) { setRec(null); return; }
    let off = false;
    (api as any).getReportRunParameterValues(rid, exec).then((r: any) => {
      if (off) return;
      setRec({ exec, params: r?.recorded ? (r.parameters || []).map((p: any) => ({
        name: p.name, label: p.label || p.name, value: p.value, value_words: p.value_words })) : null });
    }).catch(() => { if (!off) setRec({ exec, params: null }); });
    return () => { off = true; };
  }, [exec, rid]);
  if (!info) return { params: null, source: 'given', loading: false };
  if (info.executionId === undefined) return { params: info.parameters, source: 'given', loading: false };
  if (!exec) return { params: info.parameters, source: 'page_no_run', loading: false };
  if (!rec || rec.exec !== exec) return { params: null, source: 'run', loading: true };
  if (rec.params) return { params: rec.params, source: 'run', loading: false };
  return { params: info.parameters, source: 'page_unrecorded', loading: false };
}
/** 2026-11-01 (the owner: "header is not sticky") -- the first level column of a
 *  wide grid stays on screen while the measures scroll; the header corner sits
 *  above both axes. */
export function stickyLeft(levelIndex: number, body = false): Record<string, any> {
  if (levelIndex !== 0) return {};
  return { position: 'sticky', left: 0, zIndex: body ? 1 : 3, bgcolor: 'background.paper',
           boxShadow: 'inset -1px 0 0 rgba(0,0,0,0.08)' };
}

/** The page tells its band tiles what to show (viewer: the run's values). */
export const CanvasBandContext = createContext<BandInfo | null>(null);

export function bandValueWords(v: any): string {
  if (v === null || v === undefined || v === '' || (Array.isArray(v) && v.length === 0)) return 'All';
  if (Array.isArray(v)) return v.length > 3 ? `${v.slice(0, 3).join(', ')} +${v.length - 3} more` : v.join(', ');
  if (typeof v === 'object') return Object.values(v).filter(x => x != null && x !== '').join(' to ');
  return String(v);
}

/** Under this height the band's title, cells and code sit in ONE row: the
 *  sample's band tile was one grid row high and the blue band was clipped
 *  under the title (the owner saw an empty "Selections"). */
export const BAND_STACKED_MIN_PX = 110;

export function CanvasBandTile({ tile, height }: { tile: CanvasTile; height?: number }) {
  const compact = height != null && height < BAND_STACKED_MIN_PX;
  const theme = useCanvasTheme();     // the look is configuration (canvasTheme.ts)
  const codeHidden = theme.title.code_position === 'hidden';
  const codeLeft = theme.title.code_position === 'left';
  const info = useContext(CanvasBandContext);
  const controls = useContext(BandControlsContext);
  const band = useBandValues(controls ? null : info);
  const [bandError, setBandError] = useState<string | null>(null);
  const codeEl = info?.reportCode && !codeHidden ? (
    <Typography data-testid="canvas-report-code" sx={{ color: theme.title.color, fontSize: compact ? 15 : 16, whiteSpace: 'nowrap', flexShrink: 0 }}>
      [{info.reportCode}]
    </Typography>
  ) : null;
  const all = band.params ?? [];
  const wanted = tile.parameters && tile.parameters.length ? tile.parameters : (theme.band.show || null);
  const shown: (BandParameter & { missing?: boolean })[] = wanted
    ? wanted.map(n => all.find(p => p.name === n) ?? { name: n, label: n, value: null, missing: true })
    : all;
  const title = tile.title.trim() || info?.reportName || 'Report';
  return (
    <Box data-testid="canvas-band" data-compact={compact ? 'yes' : undefined}
      sx={{ height: '100%', display: 'flex', flexDirection: compact ? 'row' : 'column', alignItems: compact ? 'center' : 'stretch', gap: compact ? 1.5 : 0.5, minHeight: 0 }}>
      <Stack direction={theme.title.code_position === 'under' ? 'column' : 'row'} alignItems={theme.title.code_position === 'under' ? 'flex-start' : 'baseline'} spacing={1}
        sx={compact ? { flexShrink: 0, maxWidth: '40%' } : undefined}>
        {codeLeft && !compact && codeEl}
        <Typography sx={{ flex: 1, fontFamily: theme.title.font, fontSize: compact ? Math.min(18, theme.title.size) : theme.title.size, color: theme.title.color }} noWrap title={title}>
          {title}
        </Typography>
        {!codeLeft && !compact && codeEl}
      </Stack>
      {controls ? (
        <Box data-testid="canvas-band-controls" role="toolbar" aria-label="Report parameters"
          sx={{ display: 'flex', flexWrap: 'wrap', width: 'fit-content', maxWidth: '100%', bgcolor: theme.band.bg, color: theme.band.fg, fontFamily: theme.band.font, borderRadius: 0.5, minWidth: 0 }}>
          {/* ONE band: the first band tile also carries the visible parameters no tile lists */}
          <ParamBandCells ctrl={controls} theme={theme} onError={setBandError} chips={tile.chips ?? null}
            names={controls.append?.tileId === tile.id && wanted ? [...wanted, ...controls.append.names.filter(n => !wanted.includes(n))] : wanted}
            withExtras={!controls.append || controls.append.tileId === tile.id} />
        </Box>
      ) : (
      <Box sx={{ display: 'flex', bgcolor: theme.band.bg, color: theme.band.fg, fontFamily: theme.band.font, borderRadius: 0.5, overflowX: 'auto', flex: compact ? 1 : undefined, minWidth: 0 }}>
        {band.loading && (
          <Typography sx={{ px: 1.5, py: 0.5 }} variant="body2" data-testid="band-loading">Reading the values this run used…</Typography>
        )}
        {!band.loading && band.params == null && (
          <Typography sx={{ px: 1.5, py: 0.5 }} variant="body2" data-testid="band-no-values">
            {info ? 'Run the report to see the chosen values.' : "The chosen values are shown on the report's own page."}
          </Typography>
        )}
        {band.params != null && shown.length === 0 && (
          <Typography sx={{ px: 1.5, py: 0.5 }} variant="body2">This report asks for no values.</Typography>
        )}
        {band.params != null && shown.map(p => (
          <Box key={p.name} data-testid={`band-param-${p.name}`} sx={{ px: 1.5, py: 0.5, borderRight: '2px solid #fff', whiteSpace: 'nowrap' }}>
            <Typography component="div" sx={{ fontSize: 11, color: theme.band.label_fg }}>{p.label}</Typography>
            <Typography component="div" sx={{ fontFamily: 'inherit', fontSize: 16 }}>
              {p.missing ? '(not asked by this report)' : (p.value_words ?? bandValueWords(p.value))}
            </Typography>
          </Box>
        ))}
      </Box>
      )}
      {controls && bandError && <Typography variant="caption" color="error" data-testid="band-error">{bandError}</Typography>}
      {!controls && band.source === 'page_no_run' && band.params != null && (
        <Typography variant="caption" color="text.secondary" data-testid="band-not-run">
          Not run with these values yet -- these are the values on the page. Run the report to see its numbers for them.
        </Typography>
      )}
      {!controls && band.source === 'run' && band.params != null && !compact && (
        <Typography variant="caption" color="text.secondary" data-testid="band-run-values">The values this run used.</Typography>
      )}
      {compact && codeEl}
    </Box>
  );
}

// ── the outline ───────────────────────────────────────────────────────────

interface Props {
  tile: CanvasTile;
  reportId: number | null;
  cols: Map<number, CanvasColumn>;
  grouped: boolean;
  run: TileRunInfo;
  cubeFetch?: CubeFetch;
}

export function CanvasOutline({ tile, reportId, cols, grouped, run, cubeFetch }: Props) {
  const theme = useCanvasTheme();     // header / subtotal / grand-total rows in the report's look
  // linked tiles (canvasLinks.ts): every read of this outline carries the clicks
  // on the OTHER tiles; a click on a row here filters them (a path of its levels)
  const links = useCanvasLinks();
  const linkKey = JSON.stringify(links.filters);
  const act = useCanvasTileActions(tile, cols);     // canvas actions: the ⤓ on a Book cell
  // 2026-11-03 -- under a two-dates comparison the ONE stored result holds BOTH dates, and the
  // grid added them together (A + B in every cell).  It now reads B, as a number tile shows B;
  // the export gives the same grid as A, B, Variance and % (canvas_compare.compare_entry).
  const cmp = useCanvasCompare();
  const cmpCol = cmp && !('error' in cmp) ? cols.get(cmp.column_id)?.physical_name || '' : '';
  const cmpB = cmp && !('error' in cmp) && cmpCol ? { column: cmpCol, b: cmp.b } : null;
  const cmpKey = JSON.stringify(cmpB);
  const cube = useMemo(() => {
    // the Diagnostics panel notes the body each read SENT (the linked filters included)
    const ask = noteTileRequests(tile.id, cubeFetch ?? ((r: number, e: string, b: any) => api.queryReportCube(r, e, b)));
    const sideB = (b: any) => (cmpB ? { ...b, slicers: { ...(b.slicers || {}), [cmpB.column]: [cmpB.b] } } : b);
    return (r: number, e: string, b: any) => ask(r, e, withLinkSlicers(sideB(b), links.filters, cols));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cubeFetch, tile.id, linkKey, cmpKey]);
  // 2026-11-01 drill-down: an APPROVED field (canvas.drill_columns) added as the
  // next level for THIS session -- nothing saved; the rows above keep their numbers
  const drillCfg = useCanvasDrill();
  const [extraLevels, setExtraLevels] = useState<number[]>([]);
  const [drillAnchor, setDrillAnchor] = useState<HTMLElement | null>(null);
  const levelIds = [...(tile.levels ?? []), ...extraLevels];
  const drillable = (drillCfg.drill_columns ?? []).filter(id => !levelIds.includes(id) && cols.has(id));
  const levelNames = levelIds.map(id => cols.get(id)?.physical_name || '');
  const measures = tile.measures.map((m, i) => ({ column: cols.get(m.column_id)?.physical_name || '', aggregation: m.aggregation, alias: `v${i}__` }));
  const [branches, setBranches] = useState<Map<string, OutlineBranch>>(new Map());
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [grand, setGrand] = useState<any | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const exec = run.executionId;
  const key = JSON.stringify([levelIds, tile.measures, tile.totals?.grand, tile.open_level, exec, reportId, linkKey]);

  const drill = useCallback(async (k: number, path: any[] = []) => cube(reportId!, exec!, {
    operation: 'drill', dimensions: levelNames.slice(0, k + 1), measures, slicers: {},
    path_filters: path.map((v, i) => ({ column: levelNames[i], value: v })),
    sort_column: levelNames[k], sort_direction: 'asc', page: 1, page_size: OUTLINE_PAGE,
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [key]);

  /** Read every row of levels 0..upTo (one drill per level) and open them. */
  const openTo = useCallback(async (upTo: number) => {
    const next = new Map<string, OutlineBranch>();
    const open = new Set<string>();
    let cut = '';
    for (let k = 0; k <= upTo; k++) {
      const res = await drill(k);
      const rows: any[] = res.rows || [];
      const total = res.total_rows ?? rows.length;
      if (total > rows.length && k > 0) {
        cut = `There are ${total.toLocaleString()} rows at ${cols.get(levelIds[k])?.label ?? 'this level'} -- too many to open at once. Open the rows you need one by one.`;
        break;
      }
      const byParent = branchesOfLevel(rows, levelNames, k);
      if (k === 0) next.set(pathKey([]), { rows, total });
      else byParent.forEach((rs, pk) => next.set(pk, { rows: rs, total: rs.length }));
      if (k > 0) byParent.forEach((_, pk) => open.add(pk));
    }
    return { next, open, cut };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drill]);

  useEffect(() => {
    setBranches(new Map()); setExpanded(new Set()); setGrand(null); setError(''); setNotice('');
    if (!reportId || !exec || levelIds.length === 0 || tile.measures.length === 0) return;
    let cancelled = false;
    (async () => {
      setBusy(true);
      try {
        const { next, open, cut } = await openTo(openLevelOf(tile) - 1);
        const g = tile.totals?.grand ? await cube(reportId, exec, {
          operation: 'drill', dimensions: [], measures, slicers: {}, path_filters: [], page: 1, page_size: 1 }) : null;
        if (cancelled) return;
        setBranches(next); setExpanded(open); setGrand(g?.rows?.[0] ?? null); setNotice(cut);
        // the panel's tile facts: the outline's grand total when it has one, else its top level
        publishTileFacts(exec, tile, g ?? { rows: next.get(pathKey([]))?.rows ?? [], total_rows: next.get(pathKey([]))?.total });
      } catch (e: any) {
        if (!cancelled) { setError(tileErrorWords(e, cols)); publishTileError(exec, tile, tileErrorWords(e, cols)); }
      } finally {
        if (!cancelled) setBusy(false);
      }
    })();
    return () => { cancelled = true; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const toggle = async (path: any[]) => {
    const k = pathKey(path);
    if (expanded.has(k)) { setExpanded(s => { const n = new Set(s); n.delete(k); return n; }); return; }
    setExpanded(s => new Set(s).add(k));
    if (branches.has(k)) return;
    try {
      const res = await drill(path.length, path);
      setBranches(b => new Map(b).set(k, { rows: res.rows || [], total: res.total_rows ?? (res.rows || []).length }));
    } catch (e: any) {
      setExpanded(s => { const n = new Set(s); n.delete(k); return n; });
      setError(tileErrorWords(e, cols));
    }
  };

  const openAll = async () => {
    setBusy(true); setError('');
    try {
      const { next, open, cut } = await openTo(levelIds.length - 1);
      setBranches(b => { const m = new Map(b); next.forEach((v, k2) => m.set(k2, v)); return m; });
      setExpanded(open); setNotice(cut);
    } catch (e: any) {
      setError(tileErrorWords(e, cols));
    } finally {
      setBusy(false);
    }
  };

  if (levelIds.length === 0 || tile.measures.length === 0) {
    return <Typography variant="body2" color="text.secondary" data-testid="outline-empty">
      Pick the levels (the fields the rows open into) and at least one value.
    </Typography>;
  }
  if (!exec) return <Typography variant="body2" color="text.secondary" data-testid="tile-not-run">Run the report to see this.</Typography>;
  if (error) return <Alert severity="warning" data-testid="tile-error" sx={{ py: 0 }}>{error}</Alert>;
  if (busy && branches.size === 0) return <Box sx={{ display: 'flex', justifyContent: 'center', py: 2 }}><CircularProgress size={20} /></Box>;

  const lines = outlineLines(tile, levelNames, branches, expanded, grand, cols);
  const words = (v: any, c?: CanvasColumn | null) => (v === null || v === undefined ? '' : formatValue(v, c));
  // colour by value (2026-11-02): a scaled value's range over the lines on screen (totals included)
  const lineStats = new Map(tile.measures.map((m, i) => [i, cols.get(m.column_id)?.tile_format?.scale ? scaleStats(lines.filter(l => l.values).map(l => l.values![i])) : null]));
  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }} data-testid="canvas-outline">
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.5 }}>
        <Button size="small" onClick={openAll} disabled={busy} data-testid="outline-expand-all">Open all</Button>
        <Button size="small" onClick={() => setExpanded(new Set())} disabled={busy} data-testid="outline-collapse-all">Close all</Button>
        {(drillable.length > 0 || extraLevels.length > 0) && (
          <>
            <Button size="small" onClick={e => setDrillAnchor(e.currentTarget)} disabled={busy || drillable.length === 0} data-testid="outline-drill-into">Drill into…</Button>
            {extraLevels.length > 0 && (
              <Button size="small" onClick={() => setExtraLevels([])} data-testid="outline-drill-reset">Back to the saved levels</Button>
            )}
            <Menu open={!!drillAnchor} anchorEl={drillAnchor} onClose={() => setDrillAnchor(null)}>
              {drillable.map(id => (
                <MenuItem key={id} data-testid={`outline-drill-${id}`} onClick={() => { setExtraLevels(x => [...x, id]); setDrillAnchor(null); }}>
                  {cols.get(id)?.label ?? `#${id}`}
                </MenuItem>
              ))}
            </Menu>
          </>
        )}
        {busy && <CircularProgress size={14} />}
        {run.truncated && (
          <Typography variant="caption" color="warning.main" data-testid="tile-truncated">
            Based on the first {run.rowLimit ? Number(run.rowLimit).toLocaleString() : ''} rows only -- the report&apos;s row limit cut the result.
          </Typography>
        )}
      </Stack>
      {notice && <Typography variant="caption" color="warning.main" data-testid="outline-notice">{notice}</Typography>}
      {cmpB && <Typography variant="caption" color="text.secondary" data-testid="outline-compare-note">
        Showing {cmpB.b} (B). The download shows both dates side by side with the change.</Typography>}
      <Box sx={{ overflow: 'auto', flex: 1, minHeight: 0 }}>
        <Table size="small" stickyHeader aria-label={tile.title || 'Outline'}
          sx={{ '& thead th': { bgcolor: theme.grid.header_bg, color: theme.grid.header_fg },
                '& tbody td': { py: DENSITY_PY[theme.grid.density] },
                ...(theme.grid.zebra ? { '& tbody tr[data-testid="outline-row"]:nth-of-type(even) td': { bgcolor: 'action.hover' } } : {}) }}>
          <TableHead>
            <TableRow>
              {levelIds.map((id, j) => <TableCell key={id} sx={{ fontWeight: 700, whiteSpace: 'nowrap', textTransform: 'uppercase', fontSize: 12, ...stickyLeft(j) }}>{cols.get(id)?.label ?? `#${id}`}</TableCell>)}
              {tile.measures.map((m, i) => (
                <TableCell key={i} align="right" sx={{ fontWeight: 700, whiteSpace: 'nowrap', textTransform: 'uppercase', fontSize: 12 }}>
                  {measureWords(m, cols, grouped)}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {lines.map(l => {
              if (l.kind === 'loading') {
                return <TableRow key={l.key}><TableCell colSpan={levelIds.length + tile.measures.length} sx={{ pl: 2 + l.level * 2 }}><CircularProgress size={12} /></TableCell></TableRow>;
              }
              if (l.kind === 'more') {
                return (
                  <TableRow key={l.key} data-testid="outline-more">
                    <TableCell colSpan={levelIds.length + tile.measures.length}>
                      <Typography variant="caption" color="warning.main">
                        Showing {l.shown!.toLocaleString()} of {l.total!.toLocaleString()} rows here -- narrow the report with a parameter, or export it, to see the rest.
                      </Typography>
                    </TableCell>
                  </TableRow>
                );
              }
              const isTotal = l.kind === 'total' || l.kind === 'grand';
              // the row's levels by name: the Book cell's action and the link click read them
              const rowRec = Object.fromEntries(levelNames.slice(0, l.path.length).map((n, i) => [n, l.path[i]]));
              const pickable = links.enabled && l.kind === 'row';
              const picked = pickable && links.hasSelection
                && l.path.every((v, i) => links.isSelected(levelIds[i], v ?? null));
              return (
                <TableRow key={l.key} hover data-testid={l.kind === 'row' ? 'outline-row' : l.kind === 'grand' ? 'outline-grand' : 'outline-total'}
                  data-level={l.level} selected={picked}
                  {...(pickable ? clickableRow((e: any) => links.togglePath(
                    rowSteps(levelIds.slice(0, l.path.length), l.path), !!(e?.ctrlKey || e?.metaKey)),
                    { label: `Show only ${l.path.map(v => (v == null ? '(no value)' : String(v))).join(' › ')} on the other tiles`,
                      selected: picked }) : {})}
                  sx={isTotal ? { '& td': {
                      fontWeight: (l.kind === 'grand' ? theme.grid.grand : theme.grid.subtotal).bold ? 700 : 400,
                      bgcolor: (l.kind === 'grand' ? theme.grid.grand : theme.grid.subtotal).bg,
                      borderTop: '1px solid', borderTopColor: 'divider', py: DENSITY_PY[theme.grid.density] },
                    // the row's text colour; a RED negative keeps its red (the theme's negative style wins)
                    '& td:not([data-negative="yes"])': { color: (l.kind === 'grand' ? theme.grid.grand : theme.grid.subtotal).fg } }
                    : pickable ? { cursor: 'pointer' } : undefined}>
                  {levelIds.map((id, j) => (
                    <TableCell key={id} sx={{ whiteSpace: 'nowrap', color: isTotal ? undefined : 'primary.dark', ...stickyLeft(j, true) }}>
                      {j === l.level && (
                        <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center' }}>
                          {l.kind === 'row' && l.canOpen && (
                            <IconButton size="small" sx={{ p: 0, mr: 0.5 }} onClick={e => { e.stopPropagation(); toggle(l.path); }}
                              aria-label={`${l.open ? 'Close' : 'Open'} ${words(l.value, cols.get(id)) || '(no value)'}`}
                              data-testid={`outline-toggle-${l.level}-${String(l.value)}`}>
                              {l.open ? <IndeterminateCheckBoxOutlinedIcon fontSize="inherit" /> : <AddBoxOutlinedIcon fontSize="inherit" />}
                            </IconButton>
                          )}
                          {l.kind === 'row' ? act.cell(rowRec, cols.get(id), formatValue(l.value, cols.get(id))) : String(l.value)}
                        </Box>
                      )}
                    </TableCell>
                  ))}
                  {tile.measures.map((m, i) => {
                    const v = l.values ? l.values[i] : null;
                    const c = cols.get(m.column_id);
                    return (
                      <TableCell key={i} align="right" sx={{ whiteSpace: 'nowrap', ...(l.values ? (valueSx(v, c, lineStats.get(i), { up: theme.kpi.up_fg, down: theme.kpi.down_fg }) ?? {}) : (negativeSx(v, c) ?? {})) }}
                        data-rule={l.values && ruleSx(v, c) ? 'on' : undefined}
                        data-negative={negativeSx(v, c) ? 'yes' : undefined}
                        data-testid={`outline-value-${i}`}>
                        {l.values ? words(v, c) : ''}
                      </TableCell>
                    );
                  })}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Box>
      {act.ui}
    </Box>
  );
}

/** The one entry the tile view hands an outline or band tile to. */
export default function CanvasOutlineTile(props: Props & { height?: number }) {
  return props.tile.kind === 'band' ? <CanvasBandTile tile={props.tile} height={props.height} /> : <CanvasOutline {...props} />;
}
