/**
 * Values DERIVED from two of a table tile's values (2026-11-03) -- the browser's
 * twin of backend/core/reports/canvas_derived.py.
 *
 * Limit usage (the headroom, the usage %) and a break report (two sides, only the
 * rows that do not match) are a value worked out from two values of the SAME row
 * after they are added up.  The microcube works it out (a difference counts a
 * missing side as 0; a ratio is 100 * a / b, no value when b is 0), so the screen
 * and the documents read the same numbers.
 */
import { formatProblems, type TileFormat } from './canvasOutline';

export const DERIVED_OPS = ['difference', 'ratio'] as const;
export type DerivedOp = typeof DERIVED_OPS[number];
export const MAX_DERIVED = 4;
export const MAX_DERIVED_LABEL = 60;
/** a ratio reads as a percentage with one decimal unless the tile says otherwise */
export const RATIO_FORMAT: TileFormat = { decimals: 1, thousands: true, negative: 'minus', zero: 'show' };

export interface DerivedValue {
  label: string;
  op: DerivedOp;
  /** indexes into the tile's measures */
  a: number;
  b: number;
  /** only the rows where it is not zero */
  nonzero?: boolean;
  format?: TileFormat;
}

export const derivedAlias = (i: number) => `d${i}__`;

const idx = (v: any): number | null => (Number.isInteger(v) && typeof v !== 'boolean' ? v : null);

/** A stored tile's derived values, read safely (a table's only). */
export function readDerived(t: any): DerivedValue[] | undefined {
  if (t?.kind !== 'table' || !Array.isArray(t.derived)) return undefined;
  return t.derived.filter((d: any) => d && typeof d === 'object').map((d: any) => ({
    label: String(d.label ?? ''), op: d.op, a: Number(d.a), b: Number(d.b),
    ...(typeof d.nonzero === 'boolean' ? { nonzero: d.nonzero } : {}),
    ...(d.format && typeof d.format === 'object' ? { format: d.format } : {}),
  }));
}

/** Every problem in plain words (the server's derived_problems says the same). */
export function derivedProblems(t: { kind: string; measures: unknown[]; derived?: any; sort?: any },
                                say: (msg: string) => void): void {
  const raw = t.derived;
  if (raw === undefined || raw === null) return;
  if (t.kind !== 'table') { say('only a table can show values worked out from two others.'); return; }
  if (!Array.isArray(raw) || raw.length > MAX_DERIVED) { say(`it can show at most ${MAX_DERIVED} values worked out from two others.`); return; }
  const n = t.measures.length;
  raw.forEach((d: any, k: number) => {
    const i = k + 1;
    if (!d || typeof d !== 'object') { say(`worked-out value ${i} must say how it is worked out.`); return; }
    const unknown = Object.keys(d).filter(x => !['label', 'op', 'a', 'b', 'nonzero', 'format'].includes(x)).sort();
    if (unknown.length) say(`worked-out value ${i} has settings it does not know: ${unknown.join(', ')}.`);
    if (typeof d.label !== 'string' || !d.label.trim() || d.label.trim().length > MAX_DERIVED_LABEL) {
      say(`worked-out value ${i} needs a name of at most ${MAX_DERIVED_LABEL} characters.`);
    }
    if (!DERIVED_OPS.includes(d.op)) say(`worked-out value ${i} is either a difference (first minus second) or a ratio (first as a % of second).`);
    const a = idx(d.a), b = idx(d.b);
    if (a === null || b === null || a < 0 || a >= n || b < 0 || b >= n || a === b) say(`worked-out value ${i} reads two different values of this table.`);
    if (d.nonzero !== undefined && typeof d.nonzero !== 'boolean') say(`worked-out value ${i}: showing only the rows where it is not zero is on or off.`);
    if (d.format !== undefined) formatProblems(d.format).forEach(m => say(`worked-out value ${i}: ${m}`));
  });
  const s = t.sort;
  if (s && s.by === 'derived') {
    const k = idx(s.index);
    if (k === null || k < 0 || k >= raw.length) say('it is sorted by a worked-out value it does not have.');
    if (s.abs !== undefined && typeof s.abs !== 'boolean') say('sorting by size whatever the sign is on or off.');
  }
}

/** The cube body's `derived` list, and the sort a derived value asks for (null = none). */
export function derivedRequest(t: { kind: string; derived?: DerivedValue[]; sort?: any }) {
  const ds = t.kind === 'table' ? (t.derived ?? []) : [];
  const derived = ds.map((d, i) => ({ alias: derivedAlias(i), op: d.op, a: `v${d.a}__`, b: `v${d.b}__`, nonzero: !!d.nonzero }));
  const s = t.sort;
  const sort = s && s.by === 'derived' && Number.isInteger(s.index) && s.index >= 0 && s.index < ds.length
    ? { column: derivedAlias(s.index), dir: (s.dir === 'asc' ? 'asc' : 'desc') as 'asc' | 'desc', abs: !!s.abs }
    : null;
  return { derived, sort };
}

/** The number format a derived value shows with: its own, else a ratio's percentage,
 *  else (a difference) the tile's format of the value it starts from. */
export function derivedFormat(t: { measures: { column_id: number }[]; formats?: Record<string, TileFormat> | null },
                              d: DerivedValue): TileFormat | undefined {
  if (d.format) return d.format;
  if (d.op === 'ratio') return RATIO_FORMAT;
  const m = t.measures[d.a];
  return m ? t.formats?.[String(m.column_id)] : undefined;
}
