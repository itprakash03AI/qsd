/**
 * DateDefaultPicker (2026-09-28) — a date parameter's DEFAULT as one stored
 * @-token, with the business-calendar tokens offered beside the plain ones,
 * the calendar and the N as their own controls, and a PREVIEW of what the
 * token resolves to today from the server (GET /api/date-tokens/preview —
 * the same resolvers a run uses, core/business_calendar_tokens.py).
 *
 * Nothing here resolves a calendar client-side: the calendar is the
 * server's, and a token that cannot be rendered shows the SERVER's refusal
 * in red (unknown calendar, no deployment default declared, beyond the
 * calendar's horizon) instead of a quietly wrong date.
 */
import React from 'react';
import {
  Box, FormControl, InputLabel, MenuItem, Select, TextField, Typography,
} from '@mui/material';
import api from '../../services/api';
import type { DateTokensVocabulary } from '../../services/api/dateTokens';
import {
  isBusinessCalendarToken, joinDateToken, splitDateToken, tokenNeedsN,
} from '../../utils/dateTokens';

export interface DateDefaultOption { value: string; label: string }

interface Props {
  value: string;
  onChange: (v: string) => void;
  /** The picker's options, including '' (no default) and '__custom__'. */
  options: DateDefaultOption[];
  /** Unique per row: the label/select ids derive from it. */
  idBase: string;
  /** The field's label (default "Default"); a date range has "Default from" / "Default to". */
  label?: string;
}

// One vocabulary fetch per page, shared by every row; a failure is retried
// on the next mount rather than cached.
let vocabPromise: Promise<DateTokensVocabulary> | null = null;
const loadVocab = (): Promise<DateTokensVocabulary> => {
  if (!vocabPromise) {
    vocabPromise = api.listDateTokens().catch((err: any) => {
      vocabPromise = null;
      throw err;
    });
  }
  return vocabPromise;
};
/** TEST SEAM — forget the cached vocabulary between tests. */
export function resetDateTokenVocabularyForTests(): void { vocabPromise = null; }

const DateDefaultPicker: React.FC<Props> = ({ value, onChange, options, idBase, label = 'Default' }) => {
  const parts = splitDateToken(value);
  const isBusiness = isBusinessCalendarToken(parts.base);
  const known = options.some(o => o.value === parts.base && o.value !== '__custom__');
  const selectValue = known ? parts.base : (value ? '__custom__' : '');

  const [vocab, setVocab] = React.useState<DateTokensVocabulary | null>(null);
  const [vocabError, setVocabError] = React.useState<string | null>(null);
  const [preview, setPreview] = React.useState<{ text: string; refused: boolean } | null>(null);

  React.useEffect(() => {
    if (!isBusiness) return;
    let alive = true;
    loadVocab()
      .then(v => { if (alive) { setVocab(v); setVocabError(null); } })
      .catch((e: any) => { if (alive) setVocabError(e?.message || String(e)); });
    return () => { alive = false; };
  }, [isBusiness]);

  React.useEffect(() => {
    const v = String(value || '').trim();
    if (!v.startsWith('@')) { setPreview(null); return; }
    let alive = true;
    api.previewDateToken(v)
      .then(p => {
        if (!alive) return;
        if (p.refused) setPreview({ text: `cannot resolve: ${p.refused}`, refused: true });
        else if (p.resolved) {
          setPreview({
            text: p.kind === 'calendar' && p.explanation ? `→ ${p.explanation}` : `→ ${p.resolved}`,
            refused: false,
          });
        } else setPreview(null);
      })
      .catch((e: any) => {
        if (alive) setPreview({ text: `preview unavailable: ${e?.message || String(e)}`, refused: true });
      });
    return () => { alive = false; };
  }, [value]);

  const calendars = vocab?.calendars || [];
  const calendarValue = parts.calendar || '';

  return (
    <Box sx={{ display: 'flex', gap: 0.5, alignItems: 'center', flexWrap: 'wrap' }}>
      <FormControl size="small" sx={{ minWidth: 200 }}>
        <InputLabel id={`${idBase}-label`}>{label}</InputLabel>
        <Select
          labelId={`${idBase}-label`} id={idBase}
          value={selectValue}
          label={label}
          onChange={e => {
            const v = e.target.value as string;
            if (v === '__custom__') return;
            // Switching between business tokens keeps the calendar and N.
            onChange(isBusinessCalendarToken(v) ? joinDateToken(v, parts.n, parts.calendar) : v);
          }}
        >
          {options.map(o => (
            <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>
          ))}
        </Select>
      </FormControl>
      {value && selectValue === '__custom__' && (
        <TextField size="small" label="Custom default"
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder="YYYY-MM-DD" sx={{ width: 130 }} />
      )}
      {isBusiness && tokenNeedsN(parts.base) && (
        <TextField size="small" type="number" label="Business day N"
          value={parts.n ?? ''}
          inputProps={{ min: 1, 'aria-label': 'Business day N' }}
          onChange={e => onChange(joinDateToken(
            parts.base, e.target.value ? parseInt(e.target.value, 10) : null, parts.calendar))}
          sx={{ width: 130 }} />
      )}
      {isBusiness && (
        <FormControl size="small" sx={{ minWidth: 200 }}>
          <InputLabel id={`${idBase}-cal-label`}>Calendar</InputLabel>
          <Select
            labelId={`${idBase}-cal-label`} id={`${idBase}-cal`}
            label="Calendar"
            value={calendarValue}
            onChange={e => onChange(joinDateToken(parts.base, parts.n, (e.target.value as string) || null))}
          >
            <MenuItem value="">
              {vocab?.default_calendar
                ? `Deployment default (${vocab.default_calendar})`
                : 'Deployment default (none declared)'}
            </MenuItem>
            {calendars.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
            {calendarValue && !calendars.includes(calendarValue) && (
              <MenuItem value={calendarValue}>
                {vocab ? `${calendarValue} (not an active calendar)` : calendarValue}
              </MenuItem>
            )}
          </Select>
        </FormControl>
      )}
      {vocabError && (
        <Typography variant="caption" color="error" data-testid={`${idBase}-calendars-error`}>
          calendars unavailable: {vocabError}
        </Typography>
      )}
      {preview && (
        <Typography variant="caption" color={preview.refused ? 'error' : 'text.secondary'}
                    data-testid={`${idBase}-preview`}>
          {preview.text}
        </Typography>
      )}
    </Box>
  );
};

export default DateDefaultPicker;
