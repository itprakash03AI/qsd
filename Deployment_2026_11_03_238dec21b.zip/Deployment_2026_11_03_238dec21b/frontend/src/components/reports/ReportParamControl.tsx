/**
 * ReportParamControl -- ONE prompt for one report parameter, in every viewer.
 *
 * 2026-10-03 (owner): "report parameter should be GENERIC and should come
 * from table distinct values", "if it's a date it should come from whatever
 * data is available in the table", "even same ways cascading columns".
 *
 * BusinessReportViewer, PivotReportViewer and SharedBusinessReportPage each
 * rendered their own copy of the prompt panel: a Select over a list loaded
 * up front for dropdowns, and a free calendar / free text box for everything
 * else -- so a date parameter bound to TRADES.DT let the viewer pick any day,
 * including the ones with no data.
 *
 * Now a parameter bound to a column (or carrying a curated list) is a
 * ColumnValuePicker over the report's own parameter route
 * (`POST /api/business-reports/{id}/parameter-values`, or the shared/embed
 * token twin): the column's distinct values under the viewer's row security,
 * a date parameter's dates newest first with the range said when the list is
 * cut, and a CASCADE child asked again whenever its parent's value changes
 * (the parent's value is part of the picker's fetch key).  A parameter bound
 * to nothing keeps the plain input -- there is nothing to list.
 */
import React from 'react';
import { Box, MenuItem, TextField, Tooltip, Typography } from '@mui/material';
import { InfoOutlined as InfoOutlinedIcon } from '@mui/icons-material';
import ColumnValuePicker, { ValueListAnswer } from '../common/ColumnValuePicker';
import { DateRangePick, NumberRange, Segmented, YesNo } from '../common/controls';
import { normalizeCompareValue } from '../../utils/parameterUtils';

export type ParamValuesFetch = (body: {
  parameter_id: number; parent_values: Record<string, any>;
  /** 2026-10-24 -- type to search on the server (a cut list) */
  search?: string;
}) => Promise<ValueListAnswer>;

/** Every parameter that (transitively) depends on `paramId`. */
export function cascadeDescendants(params: any[], paramId: number): any[] {
  const out: any[] = [];
  const queue = [paramId];
  while (queue.length) {
    const id = queue.shift();
    for (const c of params) {
      if (c.depends_on_param_id === id && !out.includes(c)) {
        out.push(c);
        queue.push(c.id);
      }
    }
  }
  return out;
}

const emptyFor = (p: any) => (p.parameter_type === 'multi_select' ? []
  : p.parameter_type === 'date_range' || p.parameter_type === 'cob_compare' ? {} : '');

/** 2026-11-01 -- the periods (backend core/reports/period.py PERIOD_KINDS), in the viewer's words. */
export const PERIOD_OPTIONS: { value: string; label: string; help: string }[] = [
  { value: 'daily', label: 'Daily', help: 'The business date itself' },
  { value: 'mtd', label: 'MTD', help: 'Month to date' },
  { value: 'qtd', label: 'QTD', help: 'Quarter to date' },
  { value: 'ytd', label: 'YTD', help: 'Year to date' },
  { value: 'daily_month', label: 'Month, daily', help: 'Every day of the business date\'s month' },
  { value: 'month_ends_12', label: '12 month-ends', help: 'The last twelve month-ends' },
  { value: 'year_ends_3', label: '3 year-ends', help: 'The last three year-ends' },
];
/** The quick picks of a comparison (calendar tokens the server resolves on the report's calendar). */
export const COMPARE_PRESETS: { value: string; label: string; a: string; b: string }[] = [
  { value: 'month_end_vs_previous', label: 'This month-end vs the previous month-end', a: '@PREV_BUSINESS_MONTH_END', b: '@BUSINESS_MONTH_END' },
  { value: 'day_vs_previous_day', label: 'Today vs the previous business day', a: '@PREV_BUSINESS_DAY', b: '@TODAY' },
];

/** The next values after `p` changes: its cascade children (and theirs)
 *  are cleared -- a child chosen under the old parent may not exist under
 *  the new one. */
export function applyParamChange(params: any[], prev: Record<string, any>,
                                 p: any, value: any): Record<string, any> {
  const next = { ...prev, [p.name]: value };
  // 2026-11-01 (the owner: "changing Business Date turned Period into Not set"): a PERIOD is
  // anchored on its date, it is not chosen from a list under it -- Daily stays Daily on any
  // date, so a period (and what hangs under it) keeps its value
  const keeps = (c: any) => c.parameter_type === 'period';
  const skip = new Set<number>();
  for (const c of params) if (keeps(c) && c.depends_on_param_id === p.id) skip.add(c.id);
  for (const child of cascadeDescendants(params, p.id)) {
    if (keeps(child) || [...skip].some(id => cascadeDescendants(params, id).includes(child))) continue;
    next[child.name] = emptyFor(child);
  }
  return next;
}

export interface ReportParamControlProps {
  param: any;
  params: any[];
  values: Record<string, any>;
  onValues: (updater: (prev: Record<string, any>) => Record<string, any>) => void;
  fetchValues: ParamValuesFetch;
  showRequiredError?: boolean;
}

/** 2026-11-01 -- a hidden parameter is never shown; a 'show when' parameter only when the other has a value. */
export function paramShown(p: any, values: Record<string, any>): boolean {
  if (p.visible === false) return false;
  const sw = p.show_when;
  if (!sw || typeof sw !== 'object' || !sw.param) return true;
  const v = values[sw.param];
  const empty = v == null || v === '' || (Array.isArray(v) && !v.length) || (typeof v === 'object' && !Array.isArray(v) && !Object.values(v).some(x => x != null && x !== ''));
  if (Array.isArray(sw.equals)) {
    const vals = Array.isArray(v) ? v : [v];
    return vals.some(x => x != null && x !== '' && sw.equals.map(String).includes(String(x)));
  }
  return !empty;
}

export function ReportParamControl({
  param: p, params, values, onValues, fetchValues, showRequiredError,
}: ReportParamControlProps) {
  if (!paramShown(p, values)) return null;
  const label = p.is_required ? `${p.label || p.name} *` : (p.label || p.name);
  const parent = p.depends_on_param_id
    ? params.find((x: any) => x.id === p.depends_on_param_id) : null;
  const parentValues: Record<string, any> = parent ? { [parent.name]: values[parent.name] } : {};
  const fetchKey = `${p.id}|${JSON.stringify(parentValues)}`;
  const fetch = () => fetchValues({ parameter_id: p.id, parent_values: parentValues });
  const search = (q: string) => fetchValues({ parameter_id: p.id, parent_values: parentValues, search: q });
  const set = (v: any) => onValues(prev => applyParamChange(params, prev, p, v));
  // A list-shaped prompt always ASKS: the server says where the values come
  // from (a curated list, the column) or why there are none -- the 2026-09-03
  // rule of the hook this replaces (a parameter with a static list was never
  // asked for).  Any other prompt is a list exactly when bound to a column.
  const isDate = p.parameter_type === 'date' || p.parameter_type === 'date_range';
  // 2026-10-29 (owner): a date may be "any date" -- a calendar, not the
  // dates found in the data.  The column still says what the date filters.
  const anyDate = isDate && p.values_source === 'any';
  // 2026-10-29 -- a parameter that filters AT THE SOURCE (`source_column`,
  // backend core/source_filters.py) is listed from the source table's column
  // and, left empty, runs the query as written: the prompt SAYS so
  const atSource = !!p.source_column;
  const listed = !anyDate && (['dropdown', 'multi_select'].includes(p.parameter_type)
    || !!p.lov_column_id || atSource);
  const sourceDefault: string[] = Array.isArray(p.source_default) ? p.source_default.map(String) : [];
  const emptyWords = atSource
    ? (sourceDefault.length ? `As in the query: ${sourceDefault.join(', ')}` : 'As in the query')
    : 'All';
  const help = p.description ? (
    <Tooltip title={p.description} placement="top">
      <InfoOutlinedIcon sx={{ fontSize: 14, color: 'text.secondary', cursor: 'help', ml: 0.5, mt: 1 }} />
    </Tooltip>
  ) : null;
  const requiredText = showRequiredError ? 'This parameter is required'
    : p.source_missing ? String(p.source_missing)
    : (atSource && !p.is_required ? `Empty: ${emptyWords.charAt(0).toLowerCase()}${emptyWords.slice(1)}` : undefined);

  if (p.parameter_type === 'period') {
    // (rig 2026-11-01) nothing is highlighted unless a value (or a default) IS set --
    // the control shows what the run uses and what the band says
    const cur = String(values[p.name] || p.default_value || '').toLowerCase();
    return (
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Segmented label={p.label || p.name} value={cur as any} options={PERIOD_OPTIONS} onChange={v => set(v)} testId={`param-${p.name}`} />
        {!cur && <Typography variant="caption" color="text.secondary" data-testid={`param-${p.name}-period-none`}>Not set: the dates apply as chosen</Typography>}
        {help}
      </Box>
    );
  }
  if (p.parameter_type === 'number_range') {
    return <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
      <NumberRange label={label} value={values[p.name]} onChange={v => set(v)} testId={`param-${p.name}-range`} error={showRequiredError} helperText={showRequiredError ? 'Required' : undefined} />{help}
    </Box>;
  }
  if (p.parameter_type === 'boolean') {
    return <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
      <YesNo label={p.label || p.name} value={values[p.name] === true || String(values[p.name]).toLowerCase() === 'true'} onChange={v => set(v)} testId={`param-${p.name}-yesno`} />{help}
    </Box>;
  }
  if (p.parameter_type === 'hierarchy') {
    // one picker per level (the parameter's result targets, top first), each narrowed by the levels above
    const levels: number[] = (Array.isArray(p.applies) ? p.applies : []).filter((t: any) => t?.to === 'result' && t.column_id != null).map((t: any) => Number(t.column_id));
    const cur: Record<string, any> = values[p.name] && typeof values[p.name] === 'object' ? values[p.name] : {};
    return (
      <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start', flexWrap: 'wrap' }} data-testid={`param-${p.name}-hierarchy`}>
        {levels.map((cid, i) => {
          const above = Object.fromEntries(levels.slice(0, i).map(c => [String(c), cur[String(c)]]));
          const key = `${p.id}|h${i}|${JSON.stringify(above)}`;
          return (
            <ColumnValuePicker key={cid} eager={i === 0 || !!cur[String(levels[i - 1])]} label={`${p.label || p.name} level ${i + 1}`} testId={`param-${p.name}-level-${i}`}
              fetchValues={() => fetchValues({ parameter_id: p.id, parent_values: { __hierarchy__: { column_id: cid, path: above } } } as any)}
              fetchKey={key} value={cur[String(cid)] || ''} disabled={i > 0 && !cur[String(levels[i - 1])]}
              onChange={v => { const next: Record<string, any> = { ...cur, [String(cid)]: v || '' }; levels.slice(i + 1).forEach(c => { next[String(c)] = ''; }); set(next); }}
              sx={{ minWidth: 180 }} />
          );
        })}
        {help}
      </Box>
    );
  }
  if (p.parameter_type === 'cob_compare') {
    // (rig 2026-11-01) whatever shape the value arrives in (a stored '@A..@B' default, JSON, a pair),
    // the boxes show the two dates in force -- the same class of defect as the period control
    const cur: any = normalizeCompareValue(values[p.name]);
    const preset = COMPARE_PRESETS.find(x => x.a === cur.a && x.b === cur.b)?.value ?? '';
    return (
      <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start', flexWrap: 'wrap' }} data-testid={`param-${p.name}-compare`}>
        <TextField size="small" select label="Quick pick" value={preset} sx={{ minWidth: 260 }}
          inputProps={{ 'data-testid': `param-${p.name}-preset` }}
          onChange={e => { const x = COMPARE_PRESETS.find(y => y.value === e.target.value); set(x ? { a: x.a, b: x.b } : {}); }}>
          <MenuItem value="">Two dates of your own</MenuItem>
          {COMPARE_PRESETS.map(x => <MenuItem key={x.value} value={x.value}>{x.label}</MenuItem>)}
        </TextField>
        <TextField size="small" type={String(cur.a || '').startsWith('@') ? 'text' : 'date'} label={`${label} A (before)`} InputLabelProps={{ shrink: true }}
          value={cur.a || ''} inputProps={{ 'data-testid': `param-${p.name}-a` }} error={showRequiredError}
          onChange={e => set({ ...cur, a: e.target.value })} sx={{ minWidth: 190 }} />
        <TextField size="small" type={String(cur.b || '').startsWith('@') ? 'text' : 'date'} label={`${p.label || p.name} B (after)`} InputLabelProps={{ shrink: true }}
          value={cur.b || ''} inputProps={{ 'data-testid': `param-${p.name}-b` }} error={showRequiredError}
          helperText={showRequiredError ? 'Both dates are needed' : 'Each value shows A, B, the variance and the %'}
          onChange={e => set({ ...cur, b: e.target.value })} sx={{ minWidth: 190 }} />
        {help}
      </Box>
    );
  }
  if (!listed && p.parameter_type === 'date_range') {
    return <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
      <DateRangePick label={label} value={values[p.name]} onChange={v => set(v)} testId={`param-${p.name}`} error={showRequiredError || !!p.source_missing} helperText={showRequiredError ? 'Required' : requiredText} />{help}
    </Box>;
  }
  if (listed && p.parameter_type === 'date_range') {
    const cur = values[p.name] || {};
    return (
      <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
        <ColumnValuePicker eager isDate label={`${label} From`} testId={`param-${p.name}-from`}
          fetchValues={fetch} fetchKey={fetchKey} searchValues={search} value={cur.from || ''}
          onChange={v => set({ ...(values[p.name] || {}), from: v || '' })}
          error={showRequiredError} helperText={requiredText} sx={{ minWidth: 190 }} />
        <ColumnValuePicker eager isDate label={`${p.label || p.name} To`} testId={`param-${p.name}-to`}
          fetchValues={fetch} fetchKey={fetchKey} searchValues={search} value={cur.to || ''}
          onChange={v => set({ ...(values[p.name] || {}), to: v || '' })}
          sx={{ minWidth: 190 }} />
        {help}
      </Box>
    );
  }
  if (listed) {
    return (
      <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>
        <ColumnValuePicker eager isDate={isDate} label={label} testId={`param-${p.name}`}
          multiple={p.parameter_type === 'multi_select'}
          fetchValues={fetch} fetchKey={fetchKey} searchValues={search}
          value={values[p.name] ?? (p.parameter_type === 'multi_select' ? [] : '')}
          onChange={v => set(v ?? '')}
          error={showRequiredError || !!p.source_missing} helperText={requiredText}
          placeholder={p.is_required ? undefined : emptyWords}
          sx={{ minWidth: 200 }} />
        {help}
      </Box>
    );
  }
  // Bound to nothing (the editor warns the author that such a parameter
  // filters nothing), or a date that takes any day: a calendar.
  if (isDate) {
    return (
      <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}>
        <TextField size="small" type="date" label={label + (p.parameter_type === 'date_range' ? ' From' : '')}
          error={showRequiredError || !!p.source_missing}
          helperText={showRequiredError ? 'Required' : requiredText}
          inputProps={{ 'data-testid': `param-${p.name}-date` }}
          InputLabelProps={{ shrink: true }}
          value={p.parameter_type === 'date_range' ? (values[p.name]?.from || '') : (values[p.name] || '')}
          onChange={e => set(p.parameter_type === 'date_range'
            ? { ...(values[p.name] || {}), from: e.target.value } : e.target.value)} />
        {p.parameter_type === 'date_range' && (
          <TextField size="small" type="date" label={`${p.label || p.name} To`}
            InputLabelProps={{ shrink: true }} value={values[p.name]?.to || ''}
            onChange={e => set({ ...(values[p.name] || {}), to: e.target.value })} />
        )}
        {help}
      </Box>
    );
  }
  return (
    <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
      <TextField size="small" label={label}
        type={p.parameter_type === 'numeric' ? 'number' : 'text'}
        error={showRequiredError} helperText={showRequiredError ? 'Required' : undefined}
        value={values[p.name] || ''}
        onChange={e => set(e.target.value)} />
      {help}
    </Box>
  );
}

export default ReportParamControl;
