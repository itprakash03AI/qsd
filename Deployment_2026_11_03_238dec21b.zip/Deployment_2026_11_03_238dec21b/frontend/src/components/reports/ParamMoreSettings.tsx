/**
 * ParamMoreSettings -- the general parameter model's settings, in words (2026-11-01).
 *
 * The owner: "how dynamically we can configure any parameters without
 * developments".  Everything here is a column of report_parameters (backend
 * core/reports/param_contract.py is the rule, the save refuses in plain words):
 * where the value goes (several targets), how the default is decided (a rule),
 * shown or hidden, a heading, shown only when another parameter has a value,
 * the validation rules, and a TEMPLATE of the library ("Business date (LDN)")
 * whose change applies to every report.
 */
import { appPrompt } from '../common/appDialogs';
import React, { useEffect, useState } from 'react';
import { Box, Button, Checkbox, Chip, FormControlLabel, MenuItem, Stack, TextField, Typography } from '@mui/material';
import { safeFetch } from '../../services/api/core';
import { safeStringify } from '../../utils/safeStringify';
import { ParamRow } from './reportAuthoringModel';

export const TARGET_WORDS: Record<string, string> = {
  result: 'Filter the results on a column', source: "Fill a condition of the dataset's own query",
  token: 'Fill a {TOKEN} in the SQL', api: 'Give it to a Published API action', popup: 'Give it to a detail popup',
  compare: 'Drive the two-date comparison', period: 'Drive the period',
};
export const DEFAULT_RULE_WORDS: Record<string, string> = {
  value: 'The value written here (a calendar token is allowed)',
  latest_with_data: "The latest value with data (the parameter's own list)",
  entitlement: "The viewer's entitled value (when they hold exactly one)",
  last_picked: 'What this viewer picked last time',
};

export interface MoreSettingsProps {
  p: ParamRow; idx: number; rows: ParamRow[];
  columns: any[]; sourceKeys: string[]; actionIds: string[]; tokens: string[];
  update: (idx: number, field: keyof ParamRow, value: any) => void;
}

export default function ParamMoreSettings({ p, idx, rows, columns, sourceKeys, actionIds, tokens, update }: MoreSettingsProps) {
  const [templates, setTemplates] = useState<{ id: number; name: string }[]>([]);
  const [tplNote, setTplNote] = useState('');
  useEffect(() => {
    safeFetch('/api/report-parameter-templates').then((r: any) => setTemplates(r?.templates || [])).catch(() => setTplNote('The template library could not be read.'));
  }, []);
  const applies: any[] = Array.isArray(p.applies) ? p.applies : [];
  const setApplies = (next: any[]) => update(idx, 'applies', next.length ? next : null);
  const v: any = p.validation && typeof p.validation === 'object' ? p.validation : {};
  const setV = (k: string, val: any) => {
    const next: any = { ...v };
    if (val === '' || val === null || val === undefined || (Array.isArray(val) && !val.length)) delete next[k]; else next[k] = val;
    update(idx, 'validation', Object.keys(next).length ? next : null);
  };
  const sw: any = p.show_when && typeof p.show_when === 'object' ? p.show_when : null;
  const others = rows.filter(r => r !== p && r.name);
  const colLabel = (id: number) => columns.find((c: any) => c.id === id)?.friendly_name || columns.find((c: any) => c.id === id)?.physical_name || `#${id}`;
  const saveAsTemplate = async () => {
    const name = await appPrompt('Name for the template (e.g. "Business date (LDN)")', p.label || p.name);
    if (!name) return;
    const definition: any = { parameter_type: p.parameter_type, lov_column_id: p.lov_column_id, static_values: p.static_values,
      values_source: p.values_source === 'auto' ? null : p.values_source, value_list_id: p.value_list_id, source_column: p.source_column,
      default_value: p.default_value || null, description: p.description || null, is_required: p.is_required, applies: p.applies || null,
      default_rule: p.default_rule || null, visible: p.visible ?? true, group_label: p.group_label || null, show_when: p.show_when || null,
      validation: p.validation || null, label: p.label };
    try {
      const t: any = await safeFetch('/api/report-parameter-templates', { method: 'POST', body: safeStringify({ name, definition }) });
      setTemplates(x => [...x, { id: t.id, name: t.name }]);
      update(idx, 'template_id', t.id);
      setTplNote(`Saved as the template "${t.name}" and attached: a change to the template applies to every report using it.`);
    } catch (e: any) { setTplNote(e?.payload?.message || e?.message || 'The template could not be saved.'); }
  };
  return (
    <Box data-testid={`param-${idx}-more`} sx={{ width: '100%', border: '1px dashed', borderColor: 'divider', borderRadius: 1, p: 1, mt: 0.5 }}>
      <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 0.5 }}>More settings -- everything is configuration; nothing here needs a developer.</Typography>

      {/* where the value goes */}
      <Typography variant="caption" component="div"><b>Where the value goes</b> (one parameter may reach several places)</Typography>
      <Stack direction="row" spacing={0.5} flexWrap="wrap" sx={{ mb: 0.5 }}>
        {applies.map((t, i) => (
          <Chip key={i} size="small" data-testid={`param-${idx}-target-${i}`}
            label={`${TARGET_WORDS[t.to] || t.to}${t.column_id ? `: ${colLabel(t.column_id)}` : t.source_column ? `: ${t.source_column}` : t.token ? `: {${t.token}}` : t.action_id ? `: ${t.action_id}` : ''}`}
            onDelete={() => setApplies(applies.filter((_x, j) => j !== i))} />
        ))}
        {applies.length === 0 && <Typography variant="caption" color="text.secondary">{p.source_column ? 'The condition of the query it fills.' : p.lov_column_id ? 'Its filter column (the results).' : 'Nowhere yet -- add a target.'}</Typography>}
      </Stack>
      <Stack direction="row" spacing={1} flexWrap="wrap" sx={{ mb: 1 }}>
        <TextField select size="small" label="+ Filter the results on" value="" sx={{ minWidth: 200 }} inputProps={{ 'data-testid': `param-${idx}-add-result` }}
          onChange={e => e.target.value && setApplies([...applies, { to: 'result', column_id: Number(e.target.value) }])}>
          {columns.map((c: any) => <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>)}
        </TextField>
        {sourceKeys.length > 0 && (
          <TextField select size="small" label="+ Fill a condition of the query" value="" sx={{ minWidth: 220 }} inputProps={{ 'data-testid': `param-${idx}-add-source` }}
            onChange={e => e.target.value && setApplies([...applies, { to: 'source', source_column: e.target.value }])}>
            {sourceKeys.map(k => <MenuItem key={k} value={k}>{k}</MenuItem>)}
          </TextField>
        )}
        {tokens.length > 0 && (
          <TextField select size="small" label="+ Fill a {TOKEN}" value="" sx={{ minWidth: 180 }} inputProps={{ 'data-testid': `param-${idx}-add-token` }}
            onChange={e => e.target.value && setApplies([...applies, { to: 'token', token: e.target.value }])}>
            {tokens.map(k => <MenuItem key={k} value={k}>{`{${k}}`}</MenuItem>)}
          </TextField>
        )}
        {actionIds.length > 0 && (
          <TextField select size="small" label="+ Give it to an action" value="" sx={{ minWidth: 200 }} inputProps={{ 'data-testid': `param-${idx}-add-action` }}
            onChange={e => e.target.value && setApplies([...applies, { to: 'popup', action_id: e.target.value }])}>
            {actionIds.map(a => <MenuItem key={a} value={a}>{a}</MenuItem>)}
          </TextField>
        )}
      </Stack>

      {/* the default, as a rule */}
      <Stack direction="row" spacing={1} flexWrap="wrap" alignItems="center" sx={{ mb: 1 }}>
        <TextField select size="small" label="The default is" value={p.default_rule || 'value'} sx={{ minWidth: 300 }} inputProps={{ 'data-testid': `param-${idx}-default-rule` }}
          onChange={e => update(idx, 'default_rule', e.target.value === 'value' ? null : e.target.value)}>
          {Object.entries(DEFAULT_RULE_WORDS).map(([k, w]) => <MenuItem key={k} value={k}>{w}</MenuItem>)}
        </TextField>
        <FormControlLabel control={<Checkbox checked={p.visible !== false} onChange={e => update(idx, 'visible', e.target.checked)} inputProps={{ 'data-testid': `param-${idx}-visible` } as any} />}
          label={p.visible === false ? 'Hidden: always runs with its default (a default is required), never shown' : 'Shown to the viewer'} />
        <TextField size="small" label="Heading (groups parameters)" value={p.group_label || ''} onChange={e => update(idx, 'group_label', e.target.value || null)}
          inputProps={{ 'data-testid': `param-${idx}-group`, maxLength: 100 }} sx={{ width: 220 }} />
      </Stack>

      {/* shown when */}
      <Stack direction="row" spacing={1} flexWrap="wrap" alignItems="center" sx={{ mb: 1 }}>
        <TextField select size="small" label="Shown only when" value={sw?.param || ''} sx={{ minWidth: 200 }} inputProps={{ 'data-testid': `param-${idx}-show-when` }}
          onChange={e => update(idx, 'show_when', e.target.value ? { param: e.target.value, has_value: true } : null)}>
          <MenuItem value="">Always</MenuItem>
          {others.map(o => <MenuItem key={o._key} value={o.name}>{o.label || o.name} has a value</MenuItem>)}
        </TextField>
        {sw?.param && (
          <TextField size="small" label="... equals (comma-separated, optional)" value={(sw.equals || []).join(', ')} sx={{ minWidth: 240 }}
            inputProps={{ 'data-testid': `param-${idx}-show-when-equals` }}
            onChange={e => { const vals = e.target.value.split(',').map(x => x.trim()).filter(Boolean); update(idx, 'show_when', vals.length ? { param: sw.param, equals: vals } : { param: sw.param, has_value: true }); }} />
        )}
      </Stack>

      {/* validation */}
      <Stack direction="row" spacing={1} flexWrap="wrap" alignItems="center" sx={{ mb: 1 }}>
        {p.parameter_type === 'date_range' && (
          <TextField size="small" type="number" label="At most N days" value={v.max_days ?? ''} onChange={e => setV('max_days', e.target.value ? Number(e.target.value) : '')} inputProps={{ min: 1, 'data-testid': `param-${idx}-max-days` }} sx={{ width: 140 }} />
        )}
        {p.parameter_type === 'multi_select' && (
          <>
            <TextField size="small" type="number" label="At least N picks" value={v.min_picks ?? ''} onChange={e => setV('min_picks', e.target.value ? Number(e.target.value) : '')} inputProps={{ min: 1, 'data-testid': `param-${idx}-min-picks` }} sx={{ width: 140 }} />
            <TextField size="small" type="number" label="At most N picks" value={v.max_picks ?? ''} onChange={e => setV('max_picks', e.target.value ? Number(e.target.value) : '')} inputProps={{ min: 1, 'data-testid': `param-${idx}-max-picks` }} sx={{ width: 140 }} />
          </>
        )}
        <TextField select size="small" label="Required together with" value="" sx={{ minWidth: 200 }} inputProps={{ 'data-testid': `param-${idx}-required-together` }}
          onChange={e => e.target.value && setV('required_together', [...(v.required_together || []), e.target.value])}>
          {others.filter(o => !(v.required_together || []).includes(o.name)).map(o => <MenuItem key={o._key} value={o.name}>{o.label || o.name}</MenuItem>)}
        </TextField>
        {(v.required_together || []).map((n: string) => <Chip key={n} size="small" label={n} onDelete={() => setV('required_together', (v.required_together || []).filter((x: string) => x !== n))} />)}
      </Stack>

      {/* templates */}
      <Stack direction="row" spacing={1} flexWrap="wrap" alignItems="center">
        <TextField select size="small" label="Template" value={p.template_id ?? ''} sx={{ minWidth: 240 }} inputProps={{ 'data-testid': `param-${idx}-template` }}
          onChange={e => update(idx, 'template_id', e.target.value ? Number(e.target.value) : null)}
          helperText={p.template_id ? 'Attached: the template defines this parameter; label, order, required, hidden and default may still be changed here.' : 'None -- this report defines the parameter itself.'}>
          <MenuItem value="">None</MenuItem>
          {templates.map(t => <MenuItem key={t.id} value={t.id}>{t.name}</MenuItem>)}
        </TextField>
        <Button size="small" onClick={saveAsTemplate} data-testid={`param-${idx}-save-template`}>Save as a template</Button>
        {tplNote && <Typography variant="caption" color="text.secondary">{tplNote}</Typography>}
      </Stack>
    </Box>
  );
}
