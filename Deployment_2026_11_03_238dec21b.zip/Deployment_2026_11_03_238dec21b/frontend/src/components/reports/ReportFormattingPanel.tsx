/**
 * Report formatting & calculations — the authoring surface for everything a
 * business report persists beyond column selection:
 *
 *   - Grouping & bands  → `section_definitions`
 *   - Running calcs     → `running_calculations`
 *   - Conditional rules → `layout_config.style_config.conditional_formats`
 *   - Column formats    → dataset-column `format_pattern` (the store every
 *                          renderer reads) + style toggles in style_config
 *   - Calculated metrics→ `metric_ids` (validated server-side)
 *
 * A LIVE PREVIEW runs the saved report once through the execute endpoint and
 * applies the DRAFT config client-side with the same engine the viewer uses,
 * so the author sees bands / calcs / rules / formats before saving.  (The
 * execute endpoint only runs the STORED definition — there is no
 * execute-with-overrides API — so data-shape changes like a new metric are
 * called out as "visible after save & run" rather than faked.)
 *
 * Backend 400s (unknown metric, wrong dataset, alias collision, pivot
 * refusals, section/calc caps) are surfaced verbatim — safeFetch already
 * carries `detail` as the error message.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, CircularProgress, Divider, Grid, IconButton, Tab, Tabs,
  Tooltip, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import CloseIcon from '@mui/icons-material/Close';
import RefreshIcon from '@mui/icons-material/Refresh';
import api from '../../services/api';
import {
  AuthoringColumn, AuthoringDraft, buildUpdatePayload, draftFromReport,
  validateDraft,
} from './reportAuthoringModel';
import GroupingBandsTab from './GroupingBandsTab';
import RunningCalcsTab from './RunningCalcsTab';
import ConditionalFormatsTab from './ConditionalFormatsTab';
import ColumnFormatsStyleTab from './ColumnFormatsStyleTab';
import MetricsTab, { DatasetMetric } from './MetricsTab';
import FormattingPreview from './FormattingPreview';

const PREVIEW_ROW_CAP = 200;

export interface ReportFormattingPanelProps {
  reportId: number;
  open: boolean;
  onClose: () => void;
  /** Called with the updated report after a successful save. */
  onSaved?: (updatedReport: any) => void;
}

const ReportFormattingPanel: React.FC<ReportFormattingPanelProps> = ({
  reportId, open, onClose, onSaved,
}) => {
  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState('');
  const [datasetColumns, setDatasetColumns] = useState<AuthoringColumn[]>([]);
  const [metrics, setMetrics] = useState<DatasetMetric[]>([]);
  const [draft, setDraft] = useState<AuthoringDraft | null>(null);
  const [tab, setTab] = useState(0);

  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [previewCols, setPreviewCols] = useState<string[]>([]);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState('');

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [formatSaveError, setFormatSaveError] = useState('');

  const isDatasetBacked = !!report
    && (report.data_source_type || 'saved_query') === 'saved_query'
    && Number(report.dataset_id) > 0;
  const isPivot = report?.layout_config?.report_type === 'pivot';

  // Columns the report actually selects, in report order — a band or calc on
  // an unselected column can never render, so only these are offered.
  const reportColumns: AuthoringColumn[] = useMemo(() => {
    if (!report || !isDatasetBacked) return [];
    const byId = new Map(datasetColumns.map(c => [c.id, c]));
    return (report.column_ids || [])
      .map((id: number) => byId.get(id))
      .filter((c: AuthoringColumn | undefined): c is AuthoringColumn => !!c);
  }, [report, datasetColumns, isDatasetBacked]);

  // Result columns rules can target: dataset physical names (when known)
  // else the executed result's columns; plus running-calc output columns.
  // 2026-10-24 -- a PIVOT's rules colour its MEASURE cells: the value
  // fields, by their physical names (what PivotReportViewer keys cells by).
  const pivotMeasureNames: string[] = useMemo(() => {
    const vfs = report?.layout_config?.pivot_config?.value_fields || [];
    const byId = new Map(datasetColumns.map(c => [c.id, c]));
    return vfs.map((vf: any) => byId.get(vf.column_id)?.physical_name).filter(Boolean);
  }, [report, datasetColumns]);

  const ruleColumnNames: string[] = useMemo(() => {
    const base = reportColumns.length > 0
      ? reportColumns.map(c => c.physical_name)
      : previewCols;
    const calcNames = (draft?.runningCalcs || [])
      .map(c => c.name.trim()).filter(Boolean);
    return Array.from(new Set([...base, ...calcNames]));
  }, [reportColumns, previewCols, draft?.runningCalcs]);

  const loadPreview = useCallback(async (rep: any) => {
    setPreviewLoading(true);
    setPreviewError('');
    try {
      const result = await api.executeBusinessReport(rep.id, {
        parameter_values: {}, limit_override: PREVIEW_ROW_CAP,
      });
      if (result?.data && Array.isArray(result.data)) {
        setPreviewRows(result.data);
        setPreviewCols(Array.isArray(result.columns)
          ? result.columns.map((c: any) =>
              typeof c === 'string' ? c : c?.name || c?.column_name || '')
          : (result.data[0] ? Object.keys(result.data[0]) : []));
      } else if (result?.execution_id) {
        const page = await api.getBusinessReportPagedResults(
          rep.id, result.execution_id, 1, PREVIEW_ROW_CAP);
        setPreviewRows(page.rows || []);
        setPreviewCols(page.columns || []);
      } else {
        setPreviewRows([]);
        setPreviewCols([]);
      }
    } catch (err: any) {
      // Named backend refusal (missing required parameter, source down…) —
      // the preview is honest about why it has no rows.
      setPreviewError(err?.message || 'Preview execution failed');
      setPreviewRows([]);
      setPreviewCols([]);
    } finally {
      setPreviewLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    setLoading(true);
    setLoadError('');
    setSaveError('');
    setFormatSaveError('');
    (async () => {
      try {
        const rep = await api.getBusinessReport(reportId);
        if (cancelled) return;
        setReport(rep);
        setDraft(draftFromReport(rep));
        const dsBacked = (rep.data_source_type || 'saved_query') === 'saved_query'
          && Number(rep.dataset_id) > 0;
        if (dsBacked) {
          const [ds, mx] = await Promise.all([
            api.getDataset(rep.dataset_id),
            api.listDatasetMetrics(rep.dataset_id).catch(() => []),
          ]);
          if (cancelled) return;
          setDatasetColumns(ds?.columns || []);
          setMetrics(Array.isArray(mx) ? mx : []);
        } else {
          setDatasetColumns([]);
          setMetrics([]);
        }
        loadPreview(rep);
      } catch (err: any) {
        if (!cancelled) setLoadError(err?.message || 'Failed to load report');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [open, reportId, loadPreview]);

  const problems = useMemo(
    () => (draft ? validateDraft(draft, reportColumns) : []),
    [draft, reportColumns]);

  const handleSave = async () => {
    if (!report || !draft) return;
    setSaving(true);
    setSaveError('');
    setFormatSaveError('');
    try {
      const payload = buildUpdatePayload(report, draft);
      const updated = await api.updateBusinessReport(report.id, payload);

      // Dataset-column format patterns save separately (dataset store) —
      // a permission failure there must not mask the successful report save.
      const editEntries = Object.entries(draft.columnFormatEdits);
      const formatFailures: string[] = [];
      for (const [colId, pattern] of editEntries) {
        try {
          await api.updateDatasetColumn(Number(colId), { format_pattern: pattern });
        } catch (err: any) {
          const col = datasetColumns.find(c => c.id === Number(colId));
          formatFailures.push(
            `${col?.physical_name || colId}: ${err?.message || 'save failed'}`);
        }
      }
      if (formatFailures.length > 0) {
        setFormatSaveError(
          'Report saved, but column format patterns were not: '
          + formatFailures.join('; ')
          + ' (format patterns live on the dataset and need dataset edit rights).');
        setReport(updated);
        setDraft(d => (d ? { ...d, columnFormatEdits: {} } : d));
        onSaved?.(updated);
        return;   // keep the dialog open so the message is read
      }
      onSaved?.(updated);
      onClose();
    } catch (err: any) {
      // The backend names the problem (unknown metric, alias collision,
      // section cap, pivot refusal…) — show it verbatim, never a generic
      // failure.
      setSaveError(err?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const tabs: Array<{ label: string; content: React.ReactNode }> = [];
  if (draft) {
    if (isDatasetBacked && !isPivot) {
      tabs.push({
        label: 'Grouping & Bands',
        content: (
          <GroupingBandsTab
            sections={draft.sections}
            onChange={sections => setDraft({ ...draft, sections })}
            showGrandTotal={draft.style.show_grand_total}
            onShowGrandTotalChange={v =>
              setDraft({ ...draft, style: { ...draft.style, show_grand_total: v } })}
            columns={reportColumns}
          />
        ),
      });
      tabs.push({
        label: 'Running Calculations',
        content: (
          <RunningCalcsTab
            calcs={draft.runningCalcs}
            onChange={runningCalcs => setDraft({ ...draft, runningCalcs })}
            columns={reportColumns}
          />
        ),
      });
    }
    tabs.push({
      label: 'Conditional Formatting',
      content: (
        <ConditionalFormatsTab
          rules={draft.rules}
          onChange={rules => setDraft({ ...draft, rules })}
          columnNames={ruleColumnNames}
        />
      ),
    });
    tabs.push({
      label: 'Formats & Style',
      content: (
        <ColumnFormatsStyleTab
          columns={reportColumns}
          formatEdits={draft.columnFormatEdits}
          onFormatEditsChange={columnFormatEdits => setDraft({ ...draft, columnFormatEdits })}
          style={draft.style}
          onStyleChange={style => setDraft({ ...draft, style })}
          showColumnFormats={isDatasetBacked}
        />
      ),
    });
    if (isDatasetBacked && !isPivot) {
      tabs.push({
        label: 'Calculated Metrics',
        content: (
          <MetricsTab
            metrics={metrics}
            selectedIds={draft.metricIds}
            onChange={metricIds => setDraft({ ...draft, metricIds })}
          />
        ),
      });
    }
  }

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="xl"
      title={<>
        <Box sx={{ flex: 1 }}>
          Formatting &amp; Calculations
          {report && (
            <Typography variant="body2" color="text.secondary" component="span" sx={{ ml: 1 }}>
              {report.name}
            </Typography>
          )}
        </Box>
        <IconButton onClick={onClose} aria-label="close formatting panel"><CloseIcon /></IconButton>
      </>}
      titleSx={{ display: 'flex', alignItems: 'center', pr: 1 }}
      actions={<>
        {problems.length > 0 && (
          <Alert severity="warning" data-testid="draft-problems" sx={{ width: '100%' }}>
            {problems.map((p, i) => <div key={i}>{p}</div>)}
          </Alert>
        )}
        {saveError && (
          <Alert severity="error" data-testid="save-error" sx={{ width: '100%' }}>{saveError}</Alert>
        )}
        {formatSaveError && (
          <Alert severity="warning" data-testid="format-save-error" sx={{ width: '100%' }}>
            {formatSaveError}
          </Alert>
        )}
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="contained" onClick={handleSave}
            disabled={saving || loading || !draft || !!loadError || isPivot || problems.length > 0}>
            {saving ? 'Saving…' : 'Save'}
          </Button>
        </Box>
      </>}>
        {loading && (
          <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>
        )}
        {!loading && loadError && <Alert severity="error">{loadError}</Alert>}
        {!loading && !loadError && report && isPivot && draft && (
          // 2026-10-24 -- a pivot had NO conditional formatting anywhere (this
          // panel sent its author to the pivot builder, which has none).  Its
          // rules colour the measure cells; top / bottom N rank every cell of
          // that measure.  Bands and running calculations stay tabular-only.
          <Box data-testid="pivot-conditional-formats">
            <Alert severity="info" sx={{ mb: 1 }} icon={false}>
              Rules colour the pivot's value cells. Top / bottom N rank every cell of that value.
            </Alert>
            <ConditionalFormatsTab
              rules={draft.rules}
              onChange={rules => setDraft({ ...draft, rules })}
              columnNames={pivotMeasureNames}
            />
          </Box>
        )}
        {!loading && !loadError && draft && report && !isPivot && (
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: 6 }}>
              {!isDatasetBacked && (
                <Alert severity="info" sx={{ mb: 1 }} icon={false}>
                  This report is not dataset-backed, so grouping, running
                  calculations and calculated metrics (which resolve dataset
                  columns) are not available — conditional formatting and
                  style apply to its result columns.
                </Alert>
              )}
              <Tabs value={Math.min(tab, tabs.length - 1)}
                onChange={(_, v) => setTab(v)} variant="scrollable"
                scrollButtons="auto" sx={{ mb: 1 }}>
                {tabs.map(t => <Tab key={t.label} label={t.label} />)}
              </Tabs>
              {tabs[Math.min(tab, tabs.length - 1)]?.content}
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                <Typography variant="subtitle2" sx={{ flex: 1 }}>Live preview</Typography>
                <Tooltip title="Re-run the report for fresh preview rows">
                  <span>
                    <IconButton size="small" onClick={() => loadPreview(report)}
                      disabled={previewLoading} aria-label="refresh preview">
                      <RefreshIcon fontSize="small" />
                    </IconButton>
                  </span>
                </Tooltip>
              </Box>
              <Divider sx={{ mb: 1 }} />
              <FormattingPreview
                rows={previewRows}
                columns={previewCols}
                datasetColumns={datasetColumns}
                draft={draft}
                loading={previewLoading}
                error={previewError}
                rowCap={PREVIEW_ROW_CAP}
              />
              {draft.metricIds.length > 0 && (
                <Typography variant="caption" color="text.secondary">
                  Calculated metrics are computed by the engine — their columns
                  appear after save &amp; run.
                </Typography>
              )}
            </Grid>
          </Grid>
        )}
    </AppDialog>
  );
};

export default ReportFormattingPanel;
