/**
 * FeedLifecycleDialog — governance state + actions for one feed
 * (2026-09-03; backend api/feed_api.py lifecycle routes).
 *
 * The "path to live" is shown, not discovered through mystery 422s: a
 * NEW feed cannot enable its schedule until its PII is declared and its
 * acceptance is signed off — the panel names which step is missing.
 *
 * Actions mirrored 1:1 with the backend's own refusals:
 *   * retire      — typed reason required; quarantine window; unretire
 *                   restores within it (schedule stays disabled);
 *   * PII         — contains_pii=true REQUIRES named categories
 *                   ("PII, somewhere" is not a declaration);
 *   * legal hold  — admin-only both directions; placing needs a reason;
 *                   deletion is blocked while it stands;
 *   * sign-off    — requires a COMPLETED run and an explicit
 *                   contract_confirmed=true.
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, CircularProgress, Divider, FormControlLabel,
  Stack, Switch, TextField, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Gavel as HoldIcon, TaskAlt as SignOffIcon,
  DeleteForever as RetireIcon, PrivacyTip as PiiIcon,
  Restore as UnretireIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type { FeedLifecycleState } from '../services/api/feedOperations';
import { useAuth } from '../context/AuthContext';

export interface LifecycleFeedRef { id: number; name: string; }

type LoadState =
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; lifecycle: FeedLifecycleState };

const StepChip: React.FC<{ done: boolean; label: string }> =
  ({ done, label }) => (
    <Chip size="small" label={label}
          color={done ? 'success' : 'warning'}
          variant={done ? 'filled' : 'outlined'}
          sx={{ height: 22, fontSize: '0.7rem' }} />
  );

const FeedLifecycleDialog: React.FC<{
  feed: LifecycleFeedRef | null;
  onClose: () => void;
  /** Called after any successful state change so the caller can refresh. */
  onChanged?: () => void;
}> = ({ feed, onClose, onChanged }) => {
  const { user } = useAuth();
  const isAdmin = !!user?.is_admin;

  const [load, setLoad] = useState<LoadState>({ phase: 'loading' });
  const [panel, setPanel] =
    useState<'none' | 'retire' | 'pii' | 'hold' | 'signoff'>('none');
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [doneMsg, setDoneMsg] = useState<string | null>(null);

  // retire form
  const [retireReason, setRetireReason] = useState('');
  const [ackDependents, setAckDependents] = useState(false);
  // pii form
  const [containsPii, setContainsPii] = useState(false);
  const [piiCategories, setPiiCategories] = useState('');
  const [piiNotes, setPiiNotes] = useState('');
  // hold form
  const [holdReason, setHoldReason] = useState('');
  const [holdReference, setHoldReference] = useState('');
  // sign-off form
  const [contractConfirmed, setContractConfirmed] = useState(false);
  const [signOffNotes, setSignOffNotes] = useState('');
  const [signOffTicket, setSignOffTicket] = useState('');

  const loadLifecycle = async (feedId: number) => {
    setLoad({ phase: 'loading' });
    try {
      const resp = await api.getFeedLifecycle(feedId);
      setLoad({ phase: 'ready', lifecycle: resp.lifecycle || {} });
    } catch (e: any) {
      setLoad({ phase: 'error', message: e?.message || String(e) });
    }
  };

  useEffect(() => {
    if (feed != null) {
      setPanel('none');
      setBusy(false);
      setActionError(null);
      setDoneMsg(null);
      setRetireReason(''); setAckDependents(false);
      setContainsPii(false); setPiiCategories(''); setPiiNotes('');
      setHoldReason(''); setHoldReference('');
      setContractConfirmed(false); setSignOffNotes(''); setSignOffTicket('');
      void loadLifecycle(feed.id);
    }
  }, [feed?.id]);

  const lc = load.phase === 'ready' ? load.lifecycle : null;
  const piiDeclared = lc?.pii != null;
  const signedOff = !!lc?.acceptance?.accepted_by;
  const retiring = lc?.retirement != null;
  const holdActive = !!lc?.legal_hold?.active;

  const act = async (fn: () => Promise<any>, message: string) => {
    if (!feed) return;
    setBusy(true);
    setActionError(null);
    try {
      await fn();
      setDoneMsg(message);
      setPanel('none');
      void loadLifecycle(feed.id);
      onChanged?.();
    } catch (e: any) {
      setActionError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const piiCategoriesList = piiCategories
    .split(',').map(s => s.trim()).filter(Boolean);
  const piiBlocked = containsPii && piiCategoriesList.length === 0;

  return (
    <AppDialog open={feed != null}
      onClose={busy ? undefined : onClose}
      size="sm"
      title={<>Lifecycle — {feed?.name}</>}
      actions={<>
        <Button onClick={onClose} disabled={busy}>Close</Button>
      </>}>
        {load.phase === 'loading' && (
          <Stack alignItems="center" sx={{ py: 3 }}>
            <CircularProgress size={22} />
          </Stack>
        )}
        {load.phase === 'error' && (
          <Alert
            severity="error" data-testid="lifecycle-load-error"
            action={
              <Button color="inherit" size="small"
                      onClick={() => feed && void loadLifecycle(feed.id)}>
                Retry
              </Button>
            }
          >
            Could not load the lifecycle state — it exists but cannot be
            shown. {load.message}
          </Alert>
        )}

        {doneMsg && (
          <Alert severity="success" sx={{ mb: 1.5 }}
                 onClose={() => setDoneMsg(null)}>
            {doneMsg}
          </Alert>
        )}

        {lc && (
          <>
            {/* ── Path to live ── */}
            <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
              Path to live
            </Typography>
            <Stack direction="row" spacing={1} sx={{ mb: 1 }} flexWrap="wrap">
              <StepChip done={piiDeclared} label={piiDeclared
                ? 'PII declared' : '1. Declare PII'} />
              <StepChip done={signedOff} label={signedOff
                ? 'Acceptance signed off' : '2. Acceptance run + sign-off'} />
              <StepChip done={signedOff && piiDeclared}
                        label="3. Enable schedule" />
            </Stack>
            {!piiDeclared || !signedOff ? (
              <Typography variant="caption" color="text.secondary"
                          sx={{ display: 'block', mb: 1.5 }}>
                A new feed cannot go live until its PII declaration is
                recorded and a completed acceptance run is signed off —
                enable-schedule refuses until both exist.
              </Typography>
            ) : null}

            <Divider sx={{ mb: 1.5 }} />

            {/* ── Current state ── */}
            {retiring && (
              <Alert severity="warning" sx={{ mb: 1 }} data-testid="lifecycle-retiring">
                Retiring — requested by {lc.retirement?.requested_by},
                quarantined until {lc.retirement?.quarantine_until}
                {lc.retirement?.quarantine_remaining_days != null
                  ? ` (${lc.retirement.quarantine_remaining_days} day(s) left)` : ''}.
                Reason: {lc.retirement?.reason}
                <Box sx={{ mt: 0.5 }}>
                  <Button size="small" startIcon={<UnretireIcon />}
                          disabled={busy}
                          onClick={() => void act(
                            () => api.unretireFeed(feed!.id),
                            'Retirement cancelled — feed reactivated; the '
                            + 'schedule stays disabled until explicitly '
                            + 're-enabled.')}>
                    Unretire (restore)
                  </Button>
                </Box>
              </Alert>
            )}
            {holdActive && (
              <Alert severity="error" sx={{ mb: 1 }} data-testid="lifecycle-hold">
                LEGAL HOLD — placed by {lc.legal_hold?.placed_by}
                {lc.legal_hold?.reference ? ` (${lc.legal_hold.reference})` : ''}:
                {' '}{lc.legal_hold?.reason}.  Deletion is blocked while it
                stands.
              </Alert>
            )}
            {lc.pii && (
              <Typography variant="caption" sx={{ display: 'block', mb: 0.5 }}>
                <strong>PII:</strong> {lc.pii.contains_pii
                  ? `contains PII (${(lc.pii.categories || []).join(', ')})`
                  : 'declared free of PII'} — by {lc.pii.declared_by}
              </Typography>
            )}
            {lc.acceptance?.accepted_by && (
              <Typography variant="caption" sx={{ display: 'block', mb: 0.5 }}>
                <strong>Acceptance:</strong> signed off by
                {' '}{lc.acceptance.accepted_by}
                {lc.acceptance.ticket ? ` (${lc.acceptance.ticket})` : ''}
              </Typography>
            )}

            <Divider sx={{ my: 1.5 }} />

            {/* ── Actions ── */}
            <Stack direction="row" spacing={1} flexWrap="wrap">
              <Button size="small" startIcon={<PiiIcon />}
                      onClick={() => { setActionError(null); setPanel('pii'); }}>
                {piiDeclared ? 'Update PII declaration' : 'Declare PII'}
              </Button>
              <Button size="small" startIcon={<SignOffIcon />}
                      disabled={signedOff}
                      onClick={() => { setActionError(null); setPanel('signoff'); }}>
                Acceptance sign-off
              </Button>
              {isAdmin && (
                <Button size="small" startIcon={<HoldIcon />}
                        color={holdActive ? 'error' : 'inherit'}
                        onClick={() => { setActionError(null); setPanel('hold'); }}>
                  {holdActive ? 'Release legal hold' : 'Place legal hold'}
                </Button>
              )}
              {!retiring && (
                <Button size="small" color="error" startIcon={<RetireIcon />}
                        onClick={() => { setActionError(null); setPanel('retire'); }}>
                  Retire…
                </Button>
              )}
            </Stack>

            {actionError && (
              <Alert severity="error" sx={{ mt: 1.5 }}
                     data-testid="lifecycle-action-error"
                     onClose={() => setActionError(null)}>
                Refused — nothing was changed. {actionError}
              </Alert>
            )}

            {/* ── PII panel ── */}
            {panel === 'pii' && (
              <Alert severity="info" sx={{ mt: 1.5 }} icon={<PiiIcon />}>
                <FormControlLabel
                  control={
                    <Switch checked={containsPii}
                            onChange={e => setContainsPii(e.target.checked)}
                            slotProps={{ input: { 'data-testid': 'pii-contains' } as any }} />
                  }
                  label="This feed's output contains PII"
                />
                {containsPii && (
                  <TextField
                    label="Categories (comma-separated, required)"
                    placeholder="e.g. name, account_number, email"
                    value={piiCategories} fullWidth size="small"
                    onChange={e => setPiiCategories(e.target.value)}
                    error={piiBlocked}
                    helperText={piiBlocked
                      ? "Name WHAT is PII — 'PII, somewhere' cannot drive handling or review."
                      : undefined}
                    inputProps={{ 'data-testid': 'pii-categories' }}
                    sx={{ my: 1 }}
                  />
                )}
                <TextField
                  label="Notes (optional)" value={piiNotes} fullWidth
                  size="small" onChange={e => setPiiNotes(e.target.value)}
                  sx={{ my: 1 }}
                />
                <Stack direction="row" spacing={1}>
                  <Button size="small" onClick={() => setPanel('none')}
                          disabled={busy}>Cancel</Button>
                  <Button size="small" variant="contained"
                          disabled={busy || piiBlocked}
                          data-testid="pii-save"
                          onClick={() => void act(
                            () => api.setFeedPiiDeclaration(feed!.id, {
                              contains_pii: containsPii,
                              ...(containsPii
                                ? { categories: piiCategoriesList } : {}),
                              ...(piiNotes.trim()
                                ? { notes: piiNotes.trim() } : {}),
                            }),
                            'PII declaration recorded.')}>
                    Record declaration
                  </Button>
                </Stack>
              </Alert>
            )}

            {/* ── Sign-off panel ── */}
            {panel === 'signoff' && (
              <Alert severity="info" sx={{ mt: 1.5 }} icon={<SignOffIcon />}>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  Sign-off asserts the acceptance output <strong>matched the
                  agreed contract</strong> (format, naming, checksum, column
                  order, volume) — not merely that a file appeared.  It
                  requires a COMPLETED run; the backend refuses otherwise.
                </Typography>
                <FormControlLabel
                  control={
                    <Checkbox checked={contractConfirmed}
                              onChange={e =>
                                setContractConfirmed(e.target.checked)}
                              slotProps={{ input: { 'data-testid': 'signoff-confirm' } as any }} />
                  }
                  label="The consumer verified the output against the agreed contract terms"
                />
                <TextField label="Notes (optional)" value={signOffNotes}
                           fullWidth size="small" sx={{ my: 1 }}
                           onChange={e => setSignOffNotes(e.target.value)} />
                <TextField label="Ticket (optional)" value={signOffTicket}
                           fullWidth size="small" sx={{ mb: 1 }}
                           onChange={e => setSignOffTicket(e.target.value)} />
                <Stack direction="row" spacing={1}>
                  <Button size="small" onClick={() => setPanel('none')}
                          disabled={busy}>Cancel</Button>
                  <Button size="small" variant="contained"
                          disabled={busy || !contractConfirmed}
                          data-testid="signoff-go"
                          onClick={() => void act(
                            () => api.signOffFeedAcceptance(feed!.id, {
                              contract_confirmed: true,
                              ...(signOffNotes.trim()
                                ? { notes: signOffNotes.trim() } : {}),
                              ...(signOffTicket.trim()
                                ? { ticket: signOffTicket.trim() } : {}),
                            }),
                            'Acceptance recorded — the schedule can now be '
                            + 'enabled.')}>
                    Record sign-off
                  </Button>
                </Stack>
              </Alert>
            )}

            {/* ── Legal hold panel ── */}
            {panel === 'hold' && (
              <Alert severity={holdActive ? 'info' : 'warning'}
                     sx={{ mt: 1.5 }} icon={<HoldIcon />}>
                {holdActive ? (
                  <>
                    <Typography variant="body2" sx={{ mb: 1 }}>
                      Release the legal hold — deletion becomes possible
                      again.
                    </Typography>
                    <TextField label="Release reason (optional)"
                               value={holdReason} fullWidth size="small"
                               onChange={e => setHoldReason(e.target.value)}
                               sx={{ mb: 1 }} />
                  </>
                ) : (
                  <>
                    <Typography variant="body2" sx={{ mb: 1 }}>
                      Place a legal hold — deletion is blocked (423) while it
                      stands, and it binds the owner too.
                    </Typography>
                    <TextField label="Reason / matter (required)"
                               value={holdReason} fullWidth size="small"
                               error={!holdReason.trim()}
                               onChange={e => setHoldReason(e.target.value)}
                               inputProps={{ 'data-testid': 'hold-reason' }}
                               sx={{ mb: 1 }} />
                    <TextField label="Reference (optional)"
                               value={holdReference} fullWidth size="small"
                               onChange={e => setHoldReference(e.target.value)}
                               sx={{ mb: 1 }} />
                  </>
                )}
                <Stack direction="row" spacing={1}>
                  <Button size="small" onClick={() => setPanel('none')}
                          disabled={busy}>Cancel</Button>
                  <Button size="small" variant="contained"
                          color={holdActive ? 'primary' : 'error'}
                          disabled={busy || (!holdActive && !holdReason.trim())}
                          data-testid="hold-go"
                          onClick={() => void act(
                            () => api.setFeedLegalHold(feed!.id, {
                              active: !holdActive,
                              ...(holdReason.trim()
                                ? { reason: holdReason.trim() } : {}),
                              ...(holdReference.trim()
                                ? { reference: holdReference.trim() } : {}),
                            }),
                            holdActive
                              ? 'Legal hold released.'
                              : 'Legal hold placed — deletion is now blocked.')}>
                    {holdActive ? 'Release hold' : 'Place hold'}
                  </Button>
                </Stack>
              </Alert>
            )}

            {/* ── Retire panel ── */}
            {panel === 'retire' && (
              <Alert severity="warning" sx={{ mt: 1.5 }} icon={<RetireIcon />}>
                <Typography variant="body2" sx={{ mb: 1 }}>
                  Retiring <strong>deactivates the feed and removes its
                  schedule</strong>, quarantined pending deletion.  Within the
                  quarantine, Unretire restores it.  Run and delivery history
                  outlive the feed by design.
                </Typography>
                <TextField
                  label="Reason (required)" value={retireReason} fullWidth
                  size="small" multiline minRows={2}
                  error={!retireReason.trim()}
                  onChange={e => setRetireReason(e.target.value)}
                  inputProps={{ 'data-testid': 'retire-reason' }}
                  sx={{ mb: 1 }}
                />
                <FormControlLabel
                  control={
                    <Checkbox checked={ackDependents}
                              onChange={e =>
                                setAckDependents(e.target.checked)} />
                  }
                  label="I acknowledge any dependent (downstream) feeds"
                />
                <Stack direction="row" spacing={1} sx={{ mt: 0.5 }}>
                  <Button size="small" onClick={() => setPanel('none')}
                          disabled={busy}>Cancel</Button>
                  <Button size="small" variant="contained" color="error"
                          disabled={busy || !retireReason.trim()}
                          data-testid="retire-go"
                          onClick={() => void act(
                            () => api.retireFeed(feed!.id, {
                              reason: retireReason.trim(),
                              acknowledge_dependents: ackDependents,
                            }),
                            'Feed retired — deactivated and quarantined '
                            + 'pending deletion.')}>
                    Retire this feed
                  </Button>
                </Stack>
              </Alert>
            )}
          </>
        )}
    </AppDialog>
  );
};

export default FeedLifecycleDialog;
