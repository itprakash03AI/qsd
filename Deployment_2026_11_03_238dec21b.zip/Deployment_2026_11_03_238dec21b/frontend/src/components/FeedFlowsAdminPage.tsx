/**
 * FeedFlowsAdminPage — administer feed step FLOWS.
 *
 * A flow is a named, reusable set of extra steps a feed can be MAPPED to:
 * "if someone using just map these steps".  The flow does NOT carry order
 * — order is derived at plan time from the steps' own REQUIRES/PRODUCES
 * declarations, so `seq` here is only a deterministic tie-break between
 * steps the artifact graph leaves independent.  That is why this page has
 * no drag-to-reorder: there is nothing to order.
 *
 * Each step's parameter form is rendered FROM ITS `config_schema` by
 * `components/common/ConfigSchemaForm`, the same renderer the DataFlow
 * catalogue's manifests feed — the two catalogues publish the same
 * manifest shape on purpose.  A step registered from the DATABASE alone
 * therefore gets a working form with no frontend deploy.
 *
 * EVERY REFUSAL ON THIS PAGE IS THE SERVER'S.  Adding a step is validated
 * where the author can fix it (unknown step type, a step that is part of
 * the engine's own spine, a duplicate alias, a required parameter with no
 * value) and the server's message is shown verbatim.  This page does not
 * pre-judge a save, because a second opinion computed here would be a
 * decision made twice — and the one that runs at 03:00 is the server's.
 *
 * The same rule governs the three lifecycle actions added on 2026-09-05:
 *
 *   • EDIT sends what the form holds and shows whatever comes back.
 *     Deactivating is not cosmetic — an inactive flow makes every feed
 *     mapped to it REFUSE every run — so the server refuses it while
 *     feeds are mapped, NAMING them.  "Deactivate anyway" appears only
 *     because the SERVER said an acknowledgement is what it wants
 *     (`error_code: flow_deactivation_affects_feeds`); this screen never
 *     decides that a deactivation is safe.
 *   • DELETE opens on the server's USAGE read, so the operator sees who
 *     is mapped before there is a button to press.  The button is
 *     enabled by the server's own `delete_verdict`, and disabled with
 *     the server's own reason.
 *   • And the three states stay three: LOADING, "could not read the
 *     usage" and "nothing references this flow" render differently.  The
 *     middle one must never look like the last, because the last is what
 *     makes a delete safe.
 */
import { appConfirm } from './common/appDialogs';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Divider, FormControlLabel, IconButton,
  MenuItem, Paper, Select, Stack, Switch, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Add as AddIcon, Delete as DeleteIcon, DeleteForever as DeleteFlowIcon,
  Edit as EditIcon, Refresh as RefreshIcon, Replay as RetryIcon,
} from '@mui/icons-material';
import api from '../services/api';
import ConfigSchemaForm from './common/ConfigSchemaForm';
import type {
  FeedFlow, FeedFlowUsage, FeedStepManifest, FeedStepTypesResponse,
} from '../services/api/feedSteps';
import { describeLoadError } from '../utils/loadError';

export default function FeedFlowsAdminPage() {
  const [flows, setFlows] = useState<FeedFlow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [catalogue, setCatalogue] = useState<FeedStepTypesResponse | null>(null);
  const [catalogueError, setCatalogueError] = useState<string | null>(null);

  const [actionError, setActionError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Create-flow dialog
  const [newFlowOpen, setNewFlowOpen] = useState(false);
  const [newFlowName, setNewFlowName] = useState('');
  const [newFlowDesc, setNewFlowDesc] = useState('');

  // Edit-flow dialog
  const [editFlow, setEditFlow] = useState<FeedFlow | null>(null);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editActive, setEditActive] = useState(true);
  const [editError, setEditError] = useState<string | null>(null);
  // Set ONLY when the server comes back saying an acknowledgement is what
  // it wants.  Never inferred from the form's own state — deciding here
  // that a deactivation is safe would be the second opinion this page
  // exists not to have.
  const [ackWanted, setAckWanted] = useState(false);

  // Delete-flow dialog, which opens on the server's USAGE read.
  // `usage === null` with no error and not loading is the "not asked yet"
  // state; the three below are kept apart deliberately.
  const [usageFlow, setUsageFlow] = useState<FeedFlow | null>(null);
  const [usage, setUsage] = useState<FeedFlowUsage | null>(null);
  const [usageLoading, setUsageLoading] = useState(false);
  const [usageError, setUsageError] = useState<string | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Add-step dialog
  const [stepFlow, setStepFlow] = useState<FeedFlow | null>(null);
  const [stepType, setStepType] = useState('');
  const [stepAlias, setStepAlias] = useState('');
  const [stepSeq, setStepSeq] = useState(100);
  const [stepParams, setStepParams] = useState<Record<string, unknown>>({});

  const loadFlows = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const resp = await api.feedSteps.listFlows();
      if (!Array.isArray(resp?.flows)) {
        // A 200 with nothing useful in it is a defect, not an empty
        // estate.  Refuse to render it as "no flows exist".
        throw new Error('the server returned no flow list');
      }
      setFlows(resp.flows);
    } catch (e: any) {
      // Keep flows null: "could not read" must not render as "none exist".
      setFlows(null);
      setError(describeLoadError(e).message);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadCatalogue = useCallback(async () => {
    try {
      const resp = await api.feedSteps.listStepTypes();
      setCatalogue(resp);
      setCatalogueError(null);
    } catch (e: any) {
      setCatalogue(null);
      setCatalogueError(describeLoadError(e).message);
    }
  }, []);

  useEffect(() => { void loadFlows(); void loadCatalogue(); },
    [loadFlows, loadCatalogue]);

  const stepTypes: FeedStepManifest[] = useMemo(
    () => catalogue?.step_types || [], [catalogue]);
  const manifestOf = useCallback(
    (name: string) => stepTypes.find(s => s.name === name),
    [stepTypes]);

  const selectedManifest = stepType ? manifestOf(stepType) : undefined;

  const openAddStep = (flow: FeedFlow) => {
    setStepFlow(flow);
    setStepType('');
    setStepAlias('');
    setStepSeq(100);
    setStepParams({});
    setActionError(null);
  };

  const onPickStepType = (name: string) => {
    setStepType(name);
    setStepAlias(name);
    // Seed the form with the schema's declared defaults, so what the
    // author sees is what the step would run with.
    const schema = manifestOf(name)?.config_schema || {};
    const seeded: Record<string, unknown> = {};
    Object.entries(schema).forEach(([k, decl]) => {
      if (decl && decl.default !== undefined) seeded[k] = decl.default;
    });
    setStepParams(seeded);
  };

  const onCreateFlow = async () => {
    setBusy(true);
    setActionError(null);
    try {
      await api.feedSteps.createFlow({
        name: newFlowName.trim(),
        description: newFlowDesc.trim() || null,
        is_active: true,
      });
      setNewFlowOpen(false);
      setNewFlowName('');
      setNewFlowDesc('');
      await loadFlows();
    } catch (e: any) {
      setActionError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const onAddStep = async () => {
    if (!stepFlow) return;
    setBusy(true);
    setActionError(null);
    try {
      await api.feedSteps.addFlowStep(stepFlow.id, {
        step_type: stepType,
        alias: stepAlias.trim() || null,
        params: stepParams,
        seq: stepSeq,
        enabled: true,
      });
      setStepFlow(null);
      await loadFlows();
    } catch (e: any) {
      // Verbatim: the server names WHICH condition failed.
      setActionError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const openEdit = (flow: FeedFlow) => {
    setEditFlow(flow);
    setEditName(flow.name);
    setEditDesc(flow.description || '');
    setEditActive(flow.is_active);
    setEditError(null);
    setAckWanted(false);
    setActionError(null);
  };

  const onSaveFlow = async (acknowledge: boolean) => {
    if (!editFlow) return;
    setBusy(true);
    setEditError(null);
    try {
      await api.feedSteps.updateFlow(editFlow.id, {
        name: editName.trim(),
        description: editDesc.trim() || null,
        is_active: editActive,
        ...(acknowledge ? { acknowledge_affected_feeds: true } : {}),
      });
      setEditFlow(null);
      setAckWanted(false);
      await loadFlows();
    } catch (e: any) {
      // Verbatim. The server names the feeds a deactivation would stop.
      setEditError(e?.message || String(e));
      // The server, not this screen, says an acknowledgement is the way
      // through. A 503 ("could not tell which feeds") deliberately does
      // NOT offer one — acknowledging a list nobody could produce
      // acknowledges nothing.
      setAckWanted(e?.errorCode === 'flow_deactivation_affects_feeds');
    } finally {
      setBusy(false);
    }
  };

  const loadUsage = useCallback(async (flowId: number) => {
    setUsageLoading(true);
    setUsageError(null);
    try {
      const resp = await api.feedSteps.getFlowUsage(flowId);
      setUsage(resp);
    } catch (e: any) {
      // Keep usage null: "could not read who uses this" must never
      // render as "nobody uses this", which is the answer that makes a
      // delete look safe.
      setUsage(null);
      setUsageError(e?.message || String(e));
    } finally {
      setUsageLoading(false);
    }
  }, []);

  const openDelete = (flow: FeedFlow) => {
    setUsageFlow(flow);
    setUsage(null);
    setUsageError(null);
    setDeleteError(null);
    setActionError(null);
    void loadUsage(flow.id);
  };

  const onDeleteFlow = async () => {
    if (!usageFlow) return;
    setBusy(true);
    setDeleteError(null);
    try {
      await api.feedSteps.deleteFlow(usageFlow.id);
      setUsageFlow(null);
      setUsage(null);
      await loadFlows();
    } catch (e: any) {
      setDeleteError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const onRemoveStep = async (flowId: number, stepId: number, alias: string) => {
    if (!await appConfirm(`Remove step "${alias}" from this flow?`)) return;
    setBusy(true);
    setActionError(null);
    try {
      await api.feedSteps.removeFlowStep(flowId, stepId);
      await loadFlows();
    } catch (e: any) {
      setActionError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5">Feed Step Flows</Typography>
          <Typography variant="caption" color="text.secondary">
            A flow is a named set of steps a feed maps to. Order is derived
            from what each step requires and produces, so a step cannot be
            added in the wrong place — seq only breaks ties between steps
            that are independent.
          </Typography>
        </Box>
        <Button startIcon={<AddIcon />} variant="contained"
                onClick={() => { setNewFlowOpen(true); setActionError(null); }}>
          New flow
        </Button>
        <Tooltip title="Refresh">
          <IconButton aria-label="refresh flows" onClick={() => void loadFlows()}>
            <RefreshIcon />
          </IconButton>
        </Tooltip>
      </Stack>

      {catalogueError && (
        <Alert
          severity="warning" sx={{ mb: 2 }}
          data-testid="flows-catalogue-error"
          action={(
            <Button size="small" color="inherit" startIcon={<RetryIcon />}
                    onClick={() => void loadCatalogue()}>Retry</Button>
          )}
        >
          The step catalogue could not be read ({catalogueError}). Steps
          cannot be added until it can — this is unknown, not an empty
          catalogue.
        </Alert>
      )}

      {actionError && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setActionError(null)}>
          {actionError}
        </Alert>
      )}

      {loading && (
        <Stack direction="row" spacing={1} alignItems="center" sx={{ py: 2 }}>
          <CircularProgress size={18} />
          <Typography variant="body2">Loading flows…</Typography>
        </Stack>
      )}

      {!loading && error && (
        <Alert
          severity="error"
          action={(
            <Button size="small" color="inherit" startIcon={<RetryIcon />}
                    onClick={() => void loadFlows()}>Retry</Button>
          )}
        >
          Could not load flows — that is NOT the same as there being none.
          {' '}{error}
        </Alert>
      )}

      {!loading && !error && flows && flows.length === 0 && (
        <Alert severity="info" data-testid="feed-flows-empty">
          No flows exist yet. Create one, then map steps into it.
        </Alert>
      )}

      {!loading && !error && (flows || []).map(flow => (
        <Paper key={flow.id} variant="outlined" sx={{ p: 2, mb: 2 }}
               data-testid={`feed-flow-${flow.id}`}>
          <Stack direction="row" alignItems="center" spacing={1}>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Stack direction="row" spacing={1} alignItems="center">
                <Typography variant="h6" sx={{ fontSize: 16 }}>{flow.name}</Typography>
                <Chip size="small" variant="outlined"
                      color={flow.is_active ? 'success' : 'default'}
                      label={flow.is_active ? 'active' : 'inactive'}
                      sx={{ height: 18, fontSize: '0.62rem' }} />
                <Chip size="small" variant="outlined"
                      label={`${flow.steps.length} step${flow.steps.length === 1 ? '' : 's'}`}
                      sx={{ height: 18, fontSize: '0.62rem' }} />
              </Stack>
              {flow.description && (
                <Typography variant="caption" color="text.secondary">
                  {flow.description}
                </Typography>
              )}
            </Box>
            <Button size="small" startIcon={<AddIcon />}
                    disabled={catalogue == null}
                    onClick={() => openAddStep(flow)}>
              Map a step
            </Button>
            <Tooltip title="Rename, re-describe, activate or deactivate">
              <IconButton size="small" disabled={busy}
                          aria-label={`edit flow ${flow.name}`}
                          onClick={() => openEdit(flow)}>
                <EditIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            <Tooltip title="Delete this flow — shows who references it first">
              <IconButton size="small" color="error" disabled={busy}
                          aria-label={`delete flow ${flow.name}`}
                          onClick={() => openDelete(flow)}>
                <DeleteFlowIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Stack>

          <Divider sx={{ my: 1.5 }} />

          {flow.steps.length === 0 ? (
            <Typography variant="body2" color="text.secondary">
              This flow maps no steps. A feed mapped to it runs the engine
              spine and nothing extra.
            </Typography>
          ) : (
            <Stack spacing={1}>
              {flow.steps.map(step => {
                const manifest = manifestOf(step.step_type);
                const paramKeys = Object.keys(step.params || {});
                return (
                  <Paper key={step.id} variant="outlined" sx={{ p: 1.5 }}
                         data-testid={`feed-flow-step-${step.alias}`}>
                    <Stack direction="row" alignItems="flex-start" spacing={1}>
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Stack direction="row" spacing={0.75} alignItems="center" flexWrap="wrap">
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {step.alias}
                          </Typography>
                          <Chip size="small" variant="outlined" label={step.step_type}
                                sx={{ height: 18, fontSize: '0.62rem' }} />
                          <Chip size="small" variant="outlined" label={`seq ${step.seq}`}
                                sx={{ height: 18, fontSize: '0.62rem' }} />
                          {!step.enabled && (
                            <Chip size="small" color="default" label="disabled"
                                  sx={{ height: 18, fontSize: '0.62rem' }} />
                          )}
                          {manifest == null && (
                            <Chip size="small" color="warning" label="step type not in the catalogue"
                                  sx={{ height: 18, fontSize: '0.62rem' }} />
                          )}
                        </Stack>
                        {paramKeys.length === 0 ? (
                          <Typography variant="caption" color="text.secondary">
                            no parameters set
                          </Typography>
                        ) : (
                          <Typography variant="caption" color="text.secondary"
                                      sx={{ fontFamily: 'monospace', display: 'block' }}>
                            {paramKeys.map(k => `${k}=${JSON.stringify(step.params[k])}`).join('  ')}
                          </Typography>
                        )}
                      </Box>
                      <Tooltip title="Remove this step from the flow">
                        <IconButton
                          size="small" color="error" disabled={busy}
                          aria-label={`remove step ${step.alias}`}
                          onClick={() => void onRemoveStep(flow.id, step.id, step.alias)}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </Paper>
                );
              })}
            </Stack>
          )}
        </Paper>
      ))}

      {/* Edit a flow */}
      <AppDialog open={editFlow != null}
        onClose={() => setEditFlow(null)}
        size="sm"
        title={<>Edit {editFlow?.name}</>}
        actions={<>
          <Button onClick={() => setEditFlow(null)}>Cancel</Button>
          {ackWanted && (
            <Button color="warning" disabled={busy}
                    onClick={() => void onSaveFlow(true)}>
              Deactivate anyway
            </Button>
          )}
          <Button variant="contained" disabled={!editName.trim() || busy}
                  onClick={() => void onSaveFlow(false)}>
            Save
          </Button>
        </>}>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="Name" required fullWidth value={editName}
              helperText="Nothing references a flow by name — feeds hold its
                          id and run records hold the step's alias — so a
                          rename leaves every run readable."
              inputProps={{ 'aria-label': 'edit flow name' }}
              onChange={e => setEditName(e.target.value)}
            />
            <TextField
              label="Description" fullWidth multiline minRows={2}
              value={editDesc}
              inputProps={{ 'aria-label': 'edit flow description' }}
              onChange={e => setEditDesc(e.target.value)}
            />
            <FormControlLabel
              control={(
                <Switch
                  checked={editActive}
                  onChange={e => { setEditActive(e.target.checked);
                                   setAckWanted(false); }}
                />
              )}
              label="Active"
            />
            <Alert severity="info" sx={{ py: 0 }}>
              Deactivating is not cosmetic: a feed mapped to an inactive
              flow cannot plan, so it REFUSES every run. The server names
              the feeds that would stop before it lets this through.
            </Alert>
            {editError && (
              <Alert severity={ackWanted ? 'warning' : 'error'}
                     data-testid="flow-edit-error">
                {editError}
              </Alert>
            )}
          </Stack>
      </AppDialog>

      {/* Delete a flow — opens on the server's usage read */}
      <AppDialog open={usageFlow != null}
        onClose={() => setUsageFlow(null)}
        size="sm"
        title={<>Delete {usageFlow?.name}?</>}
        actions={<>
          <Button onClick={() => setUsageFlow(null)}>Cancel</Button>
          {/* Usage is a snapshot: a feed can be mapped to this flow from
              another screen while this dialog is open, which is exactly
              how a refused DELETE arrives after an "allowed" verdict.
              Re-checking must be able to REPLACE a good answer with a
              failed one — a stale "no feed references this" left on
              screen would be the same lie as an empty one. */}
          <Button disabled={busy || usageLoading}
                  onClick={() => usageFlow && void loadUsage(usageFlow.id)}>
            Re-check
          </Button>
          {/* Enabled by the SERVER's verdict, disabled with the SERVER's
              reason.  While the usage is unread or unreadable there is
              nothing to enable it — an unknown is not a permission. */}
          <Button
            variant="contained" color="error"
            disabled={busy || usage?.delete_verdict?.allowed !== true}
            onClick={() => void onDeleteFlow()}
          >
            Delete flow
          </Button>
        </>}>
          <Stack spacing={2} sx={{ mt: 1 }}>
            {usageLoading && (
              <Stack direction="row" spacing={1} alignItems="center"
                     data-testid="flow-usage-loading">
                <CircularProgress size={18} />
                <Typography variant="body2">
                  Reading which feeds reference this flow…
                </Typography>
              </Stack>
            )}

            {!usageLoading && usageError && (
              <Alert
                severity="error" data-testid="flow-usage-unreadable"
                action={(
                  <Button size="small" color="inherit" startIcon={<RetryIcon />}
                          onClick={() => usageFlow && void loadUsage(usageFlow.id)}>
                    Retry
                  </Button>
                )}
              >
                Could not read which feeds reference this flow — that is NOT
                the same as none referencing it, so there is no delete to
                offer. {usageError}
              </Alert>
            )}

            {!usageLoading && !usageError && usage && (
              <>
                {usage.feeds_known === false && (
                  <Alert severity="error" data-testid="flow-usage-unknown">
                    {usage.feeds_unknown_reason
                      || 'the server could not determine which feeds use this flow'}
                  </Alert>
                )}

                {usage.feeds_known && (usage.feeds || []).length === 0 && (
                  <Alert severity="success" data-testid="flow-usage-none">
                    No feed references this flow. Deleting it removes it and
                    its {usage.step_count} mapped step
                    {usage.step_count === 1 ? '' : 's'}.
                  </Alert>
                )}

                {usage.feeds_known && (usage.feeds || []).length > 0 && (
                  <Alert severity="warning" data-testid="flow-usage-feeds">
                    <Typography variant="body2" sx={{ fontWeight: 600, mb: 0.5 }}>
                      {usage.feed_count} feed
                      {usage.feed_count === 1 ? '' : 's'} reference this flow
                    </Typography>
                    <Stack spacing={0.25}>
                      {(usage.feeds || []).map(f => (
                        <Typography key={f.id} variant="caption"
                                    data-testid={`flow-usage-feed-${f.id}`}>
                          {f.name} (#{f.id}){f.is_active ? '' : ' — inactive'}
                        </Typography>
                      ))}
                    </Stack>
                  </Alert>
                )}

                {/* Not a count of zero.  Run records do not name the flow
                    that mapped a step, and saying "0 runs" would be the
                    lie that makes a delete look safe. */}
                <Alert severity="info" sx={{ py: 0 }}
                       data-testid="flow-usage-history">
                  Historical runs: unknown. {usage.historical_runs.reason}
                </Alert>

                <Alert severity={usage.delete_verdict.allowed ? 'success' : 'error'}
                       data-testid="flow-delete-verdict">
                  {usage.delete_verdict.reason}
                </Alert>

                {usage.delete_verdict.allowed && (
                  <Typography variant="body2" data-testid="flow-delete-switched-off">
                    The flow is switched off, not erased — its steps are kept, and
                    an admin can switch it back on under Admin -&gt; Switched off.
                  </Typography>
                )}
              </>
            )}

            {deleteError && (
              <Alert severity="error" data-testid="flow-delete-error">
                {deleteError}
              </Alert>
            )}
          </Stack>
      </AppDialog>

      {/* Create flow */}
      <AppDialog open={newFlowOpen}
        onClose={() => setNewFlowOpen(false)}
        size="sm"
        title="New flow"
        actions={<>
          <Button onClick={() => setNewFlowOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={!newFlowName.trim() || busy}
                  onClick={() => void onCreateFlow()}>
            Create
          </Button>
        </>}>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <TextField
              label="Name" required fullWidth value={newFlowName}
              inputProps={{ 'aria-label': 'flow name' }}
              onChange={e => setNewFlowName(e.target.value)}
            />
            <TextField
              label="Description" fullWidth multiline minRows={2}
              value={newFlowDesc}
              inputProps={{ 'aria-label': 'flow description' }}
              onChange={e => setNewFlowDesc(e.target.value)}
            />
          </Stack>
      </AppDialog>

      {/* Map a step into a flow */}
      <AppDialog open={stepFlow != null}
        onClose={() => setStepFlow(null)}
        size="sm"
        title={<>Map a step into {stepFlow?.name}</>}
        actions={<>
          <Button onClick={() => setStepFlow(null)}>Cancel</Button>
          <Button variant="contained" disabled={!stepType || busy}
                  onClick={() => void onAddStep()}>
            Map step
          </Button>
        </>}>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Box>
              <Typography variant="caption" color="text.secondary">Step type</Typography>
              <Select
                fullWidth size="small" displayEmpty value={stepType}
                data-testid="flow-step-type-select"
                inputProps={{ 'aria-label': 'step type' }}
                onChange={e => onPickStepType(String(e.target.value))}
              >
                <MenuItem value="">(choose a step)</MenuItem>
                {stepTypes.map(s => (
                  <MenuItem
                    key={s.name} value={s.name}
                    // A spine step already runs on every feed; the server
                    // refuses it with that reason, and the manifest's own
                    // `executor` says so here before the round trip.
                    disabled={s.executor === 'engine'}
                  >
                    {s.display_name || s.name}
                    {s.executor === 'engine' ? ' — engine spine, runs on every feed' : ''}
                  </MenuItem>
                ))}
              </Select>
            </Box>

            {selectedManifest && (
              <Alert severity="info" sx={{ py: 0 }}>
                {selectedManifest.description || 'No description.'}
                {' '}Requires: {selectedManifest.requires.length
                  ? selectedManifest.requires.join(', ') : 'nothing'}.
                {' '}Produces: {selectedManifest.produces.length
                  ? selectedManifest.produces.join(', ') : 'nothing'}.
              </Alert>
            )}

            <Stack direction="row" spacing={2}>
              <TextField
                label="Alias" fullWidth size="small" value={stepAlias}
                helperText="The run row's identity within this flow. Two steps cannot share one."
                inputProps={{ 'aria-label': 'step alias' }}
                onChange={e => setStepAlias(e.target.value)}
              />
              <TextField
                label="Seq" type="number" size="small" value={stepSeq}
                helperText="Tie-break only"
                inputProps={{ 'aria-label': 'step seq' }}
                onChange={e => setStepSeq(Number(e.target.value))}
                sx={{ width: 140 }}
              />
            </Stack>

            <Box>
              <Typography variant="caption" color="text.secondary"
                          sx={{ display: 'block', mb: 1 }}>
                Parameters
              </Typography>
              {stepType === '' ? (
                <Typography variant="caption" color="text.secondary"
                            sx={{ fontStyle: 'italic' }}>
                  Choose a step type to see its parameters.
                </Typography>
              ) : (
                <ConfigSchemaForm
                  schema={selectedManifest?.config_schema}
                  values={stepParams}
                  onChange={setStepParams}
                  blankMeans="(no value)"
                  emptyText="This step takes no parameters."
                  testIdPrefix="flow-step-param"
                />
              )}
            </Box>

            <FormControlLabel
              control={<Switch checked disabled />}
              label="Enabled (a flow step is added enabled; disable it by removing it)"
            />
          </Stack>
      </AppDialog>
    </Box>
  );
}
