/**
 * "Run on" for the SQL page (2026-11-01).
 *
 * The owner: "on query editor need option to use same query across source".
 * Decided: pick the source, same SQL.  The person writes the SQL once; "Run
 * on" picks a connection (AWS S3 direct, Trino, Starburst, on-prem Hive ...)
 * and each table name in the SQL is mapped to THAT source's table -- like a
 * feed's table map.  The server decides which table each name reads
 * (backend core/editor_run_on.py, `POST /api/sql/run-on/tables`); this panel
 * shows that answer and lets the person change a table.  It decides nothing:
 * a table the server cannot place is shown with the server's sentence, and the
 * run would refuse with the same sentence.
 *
 * Kept in its own folder so the SQL page itself changes as little as possible.
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  Button, Alert, Box, Chip, CircularProgress, MenuItem, Stack, TextField, Tooltip, Typography,
} from '@mui/material';
import api from '../../services/api';

export interface RunOnConnection {
  id: number;
  name: string;
  connection_type: string;
}

export interface RunOnTable {
  name: string;
  reads: string | null;
  how: string | null;
  how_words: string | null;
  problem: string | null;
  /** a same-short-name table on the source -- offered, never read until chosen */
  suggested?: string | null;
}

export interface RunOnPlan {
  source: { id: number; name: string; type: string; engine?: string | null; engine_label?: string | null };
  tables: RunOnTable[];
  unused_entries: string[];
  ok: boolean;
  refusal: string | null;
}

/** Per source (connection id as a string): {table as written: table there}. */
export type SourceMaps = Record<string, Record<string, string>>;

/** The run-on part of a `POST /api/sql/execute` body -- nothing when the
 *  query runs on its own connection (the page's old behaviour, unchanged). */
export function runOnPayload(runOnId: number | null | undefined, homeId: number | null | undefined,
                             sourceMaps: SourceMaps): Record<string, unknown> {
  if (!runOnId || runOnId === homeId) return {};
  return { run_on_connection_id: runOnId, table_map: sourceMaps[String(runOnId)] || {} };
}

/** True when "Run on" sends the query somewhere other than its own connection. */
export function runOnIsActive(runOnId: number | null | undefined, homeId: number | null | undefined): boolean {
  return !!runOnId && runOnId !== homeId;
}

/** The saved query's maps, cut to the tables the SQL still reads -- so a map
 *  never keeps a table the person deleted from the query. */
export function pruneSourceMaps(sourceMaps: SourceMaps, runOnId: number | null | undefined,
                                plan: RunOnPlan | null): SourceMaps {
  if (!runOnId || !plan) return sourceMaps;
  const key = String(runOnId);
  const mine = sourceMaps[key];
  if (!mine) return sourceMaps;
  const live = new Set(plan.tables.map(t => t.name.toLowerCase()));
  const kept = Object.fromEntries(Object.entries(mine).filter(([k]) => live.has(k.toLowerCase())));
  return { ...sourceMaps, [key]: kept };
}

interface PanelProps {
  connections: RunOnConnection[];
  homeConnectionId: number | null;
  sql: string;
  runOnId: number | null;
  onRunOnChange: (id: number | null) => void;
  sourceMaps: SourceMaps;
  onSourceMapsChange: (maps: SourceMaps) => void;
  /** reports the server's latest answer (the page shows it on the result) */
  onPlan?: (plan: RunOnPlan | null) => void;
  /** wait this long after typing before asking the server (tests pass 0) */
  debounceMs?: number;
}

export default function RunOnPanel({
  connections, homeConnectionId, sql, runOnId, onRunOnChange, sourceMaps, onSourceMapsChange,
  onPlan, debounceMs = 600,
}: PanelProps) {
  const [plan, setPlan] = useState<RunOnPlan | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const seq = useRef(0);
  const active = runOnIsActive(runOnId, homeConnectionId);
  const map = (runOnId && sourceMaps[String(runOnId)]) || {};
  const mapKey = JSON.stringify(map);
  const home = connections.find(c => c.id === homeConnectionId);

  useEffect(() => {
    if (!active || !runOnId || !sql.trim()) {
      setPlan(null); setError(null); onPlan?.(null);
      return undefined;
    }
    const mine = ++seq.current;
    const timer = setTimeout(() => {
      setLoading(true);
      api.sqlRunOnTables({ sql, home_connection_id: homeConnectionId, run_on_connection_id: runOnId,
                           table_map: map })
        .then((p: RunOnPlan) => {
          if (mine !== seq.current) return;
          setPlan(p); setError(null); onPlan?.(p);
        })
        .catch((e: any) => {
          if (mine !== seq.current) return;
          // the server's sentence (a 400 says what is wrong with the SQL or the map)
          setPlan(null); setError(e?.message || 'The tables could not be checked.'); onPlan?.(null);
        })
        .finally(() => { if (mine === seq.current) setLoading(false); });
    }, debounceMs);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, runOnId, homeConnectionId, sql, mapKey, debounceMs]);

  const setTable = (name: string, value: string) => {
    if (!runOnId) return;
    const key = String(runOnId);
    const next = { ...(sourceMaps[key] || {}) };
    if (value.trim()) next[name] = value.trim(); else delete next[name];
    onSourceMapsChange({ ...sourceMaps, [key]: next });
  };

  return (
    <Box data-testid="run-on-panel" sx={{ mt: 1 }}>
      <TextField
        select fullWidth size="small" label="Run on"
        value={runOnId && runOnId !== homeConnectionId ? runOnId : ''}
        onChange={e => onRunOnChange(e.target.value ? Number(e.target.value) : null)}
        inputProps={{ 'data-testid': 'run-on-select' }}
        helperText={active ? 'The same SQL, each table read from this source' : undefined}
      >
        <MenuItem value="">
          <em>{home ? `Its own connection (${home.name})` : 'Its own connection'}</em>
        </MenuItem>
        {connections.filter(c => c.id !== homeConnectionId).map(c => (
          <MenuItem key={c.id} value={c.id} data-testid={`run-on-option-${c.id}`}>
            {c.name} ({c.connection_type})
          </MenuItem>
        ))}
      </TextField>

      {active && (
        <Box data-testid="run-on-tables" sx={{ mt: 1, p: 1, border: 1, borderColor: 'divider', borderRadius: 1 }}>
          <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 0.5 }}>
            <Typography variant="caption" sx={{ fontWeight: 600 }}>Tables on this source</Typography>
            {loading && <CircularProgress size={12} />}
          </Stack>
          {error && (
            <Alert severity="error" sx={{ fontSize: 12, py: 0.25 }} data-testid="run-on-error">{error}</Alert>
          )}
          {plan && plan.tables.map(t => (
            <Box key={t.name} data-testid={`run-on-table-${t.name}`} sx={{ mb: 0.75 }}>
              <Typography variant="caption" sx={{ display: 'block', fontFamily: 'monospace' }}>
                {t.name}
              </Typography>
              <TextField
                fullWidth size="small" variant="standard"
                placeholder="the table it reads here"
                value={map[t.name] ?? t.reads ?? ''}
                onChange={e => setTable(t.name, e.target.value)}
                error={!!t.problem}
                inputProps={{ 'data-testid': `run-on-reads-${t.name}`, style: { fontFamily: 'monospace', fontSize: 12 } }}
                helperText={t.problem || (t.how_words ? `reads this table -- ${t.how_words}` : undefined)}
                FormHelperTextProps={{ sx: { fontSize: 11 } } as any}
              />
              {t.suggested && !map[t.name] && (
                <Button size="small" sx={{ textTransform: 'none', fontSize: 11, p: 0, minWidth: 0 }}
                        data-testid={`run-on-use-${t.name}`}
                        onClick={() => setTable(t.name, t.suggested as string)}>
                  Use '{t.suggested}' (it has the same name -- check it holds the same data)
                </Button>
              )}
            </Box>
          ))}
          {plan && plan.unused_entries.length > 0 && (
            <Typography variant="caption" color="text.secondary" data-testid="run-on-unused">
              Not in the query any more (left out when you save): {plan.unused_entries.join(', ')}
            </Typography>
          )}
        </Box>
      )}
    </Box>
  );
}

/** Above the results: which source and which engine read the data. */
export function RunOnResultHeader({ plan, engineLabel }: { plan: RunOnPlan | null; engineLabel?: string | null }) {
  if (!plan) return null;
  const engine = engineLabel || plan.source.engine_label;
  return (
    <Box data-testid="run-on-result-header" sx={{ px: 1.5, pt: 1, display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap' }}>
      <Typography variant="body2" sx={{ fontWeight: 600 }}>
        Read from {plan.source.name}
      </Typography>
      <Chip size="small" variant="outlined" label={plan.source.type} />
      {engine && (
        <Tooltip title="The engine that read the data for this run" arrow>
          <Chip size="small" color="primary" variant="outlined" label={`by ${engine}`} data-testid="run-on-engine" />
        </Tooltip>
      )}
    </Box>
  );
}
