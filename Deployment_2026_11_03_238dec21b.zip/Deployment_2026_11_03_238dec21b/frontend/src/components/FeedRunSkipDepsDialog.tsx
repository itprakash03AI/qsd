/**
 * FeedRunSkipDepsDialog — let ONE run proceed without unconfirmed inputs.
 *
 * POST /api/feed-runs/{run_id}/skip-dependencies (2026-09-02 contract).
 * The confirmation says in plain words that the feed will ship WITHOUT
 * the named inputs confirmed, and stays disabled until a reason is
 * typed (the server refuses an empty reason too — the UI must never
 * send one).
 *
 * When the parent has the reverse index loaded it passes the names of
 * the dependencies blocking this run (`knownDeps`); the operator can
 * then deselect some and skip only a subset (body carries the explicit
 * array).  When the names are unknown the dialog is explicit about the
 * blast radius — ALL currently-blocking dependencies — and sends
 * `dependencies: null` per the contract.
 *
 * 2026-09-27 — the reason is a CATEGORY (upstream holiday / outage / data
 * not needed / other) plus free text with a minimum length, through the
 * shared SkipReasonFields; Confirm stays disabled until it is valid and
 * the server refuses the same things with a 422.
 *
 * After success the dialog shows what the gate says NOW (gate_now):
 * admitted, or still blocked by what.
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, CircularProgress, FormControlLabel, FormGroup,
  Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Warning as WarnIcon, RemoveCircleOutline as SkipDepIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type { SkipRunDependenciesResponse } from '../services/api/feedDependencies';
import SkipReasonFields, { useSkipReason } from './common/SkipReasonFields';

export interface SkipRunTarget {
  id: number;
  feed_name?: string | null;
  feed_config_id: number;
}

interface Props {
  run: SkipRunTarget | null;
  /**
   * Names of the dependencies currently blocking this run, when the
   * reverse index has them; null = unknown (index not loaded or the
   * run was not listed) → the skip targets ALL blocking dependencies.
   */
  knownDeps: string[] | null;
  onClose: () => void;
  /** Called after a successful skip so the parent can refresh the table. */
  onDone: () => void;
}

const FeedRunSkipDepsDialog: React.FC<Props> = ({ run, knownDeps, onClose, onDone }) => {
  const reason = useSkipReason();
  const [selected, setSelected] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SkipRunDependenciesResponse | null>(null);

  // Reset the form each time the dialog opens for a run.
  useEffect(() => {
    if (run) {
      reason.reset();
      setError(null);
      setResult(null);
    }
  }, [run?.id]);  // eslint-disable-line react-hooks/exhaustive-deps

  // Seed / re-seed the checkbox list — also when the reverse index
  // finishes loading AFTER the dialog opened (knownDeps null → array).
  useEffect(() => {
    if (run) setSelected(knownDeps ?? []);
  }, [run?.id, knownDeps]);  // eslint-disable-line react-hooks/exhaustive-deps

  const feedLabel = run?.feed_name || (run ? `Feed #${run.feed_config_id}` : '');
  const listKnown = (knownDeps?.length ?? 0) > 0;
  const nothingSelected = listKnown && selected.length === 0;

  const toggle = (name: string) => {
    setSelected(prev => prev.includes(name)
      ? prev.filter(n => n !== name)
      : [...prev, name]);
  };

  const handleConfirm = async () => {
    if (!run || !reason.valid || nothingSelected) return;
    setBusy(true);
    setError(null);
    try {
      const resp = await api.skipFeedRunDependencies(run.id, {
        ...reason.body,
        // Explicit names when the operator saw and (de)selected them;
        // null = all blocking, used only when the names were unknown.
        dependencies: listKnown ? selected : null,
      });
      setResult(resp);
      onDone();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AppDialog open={run != null}
      onClose={busy ? undefined : onClose}
      size="sm"
      title={<>Skip dependencies — {feedLabel}</>}
      actions={<>
        {result ? (
          <Button variant="contained" onClick={onClose}>Close</Button>
        ) : (
          <>
            <Button onClick={onClose} disabled={busy}>Cancel</Button>
            <Button
              variant="contained"
              color="warning"
              onClick={() => void handleConfirm()}
              disabled={busy || !reason.valid || nothingSelected}
              startIcon={busy ? <CircularProgress size={14} /> : <SkipDepIcon />}
            >
              Skip and let it run
            </Button>
          </>
        )}
      </>}>
        {result ? (
          <Box>
            <Alert severity="success" sx={{ mb: 1.5 }}>
              Skipped {result.skipped.length > 0 ? result.skipped.join(', ') : 'dependencies'}
              {' '}for run #{result.run_id} (recorded by {result.asserted_by}).
            </Alert>
            {result.gate_now.admitted ? (
              <Alert severity="success" data-testid="gate-now-admitted">
                The gate now admits this run — it will proceed.
              </Alert>
            ) : (
              <Alert severity="warning" data-testid="gate-now-blocked">
                The run is STILL blocked
                {result.gate_now.blocking.length > 0
                  ? <> by: <strong>{result.gate_now.blocking.join(', ')}</strong></>
                  : ''}.
              </Alert>
            )}
          </Box>
        ) : (
          <>
            <Alert severity="warning" icon={<WarnIcon />} sx={{ mb: 2 }}>
              <strong>{feedLabel} will run WITHOUT
              {listKnown
                ? ' these inputs confirmed'
                : ' ALL of its currently-blocking inputs confirmed'}.</strong>{' '}
              Its output may be produced from incomplete upstream data.  This is
              recorded with your name and the reason below.
            </Alert>

            {listKnown ? (
              <FormGroup sx={{ mb: 1.5 }}>
                <Typography variant="caption" sx={{ fontWeight: 700, mb: 0.5 }}>
                  Dependencies to skip:
                </Typography>
                {knownDeps!.map(name => (
                  <FormControlLabel
                    key={name}
                    control={
                      <Checkbox
                        size="small"
                        checked={selected.includes(name)}
                        onChange={() => toggle(name)}
                        disabled={busy}
                      />
                    }
                    label={<Typography variant="body2">{name}</Typography>}
                  />
                ))}
                {nothingSelected && (
                  <Typography variant="caption" color="error">
                    Select at least one dependency to skip.
                  </Typography>
                )}
              </FormGroup>
            ) : (
              <Alert severity="info" sx={{ mb: 1.5 }}>
                The individual blocking inputs could not be listed —
                <strong> every dependency currently blocking this run</strong> will
                be skipped.
              </Alert>
            )}

            <SkipReasonFields
              state={reason}
              disabled={busy}
              textTestId="run-skip-reason"
              categoryTestId="run-skip-reason-category"
              textPlaceholder="Why is it safe to proceed without this input?"
            />
            {error && <Alert severity="error" sx={{ mt: 1.5 }}>{error}</Alert>}
          </>
        )}
    </AppDialog>
  );
};

export default FeedRunSkipDepsDialog;
