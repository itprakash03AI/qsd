/**
 * FeedBackfillDialog — calendar-aware backfill with preview-first launch
 * (2026-09-03; backend api/feed_ops_api.py §8, FR-OPS-06..09).
 *
 * The point of the flow: PREVIEW BEFORE LAUNCH.  The operator sees the
 * per-date verdicts (will_run / non_business_day / condition_skip /
 * outside_validity_window / already_active / error) before any run row
 * exists, and Launch sends EXACTLY the previewed range — editing a date
 * after previewing disables Launch until a fresh preview.
 *
 * Delivery is OFF by default (FR-OPS-08: re-delivering a month of files
 * to a counterparty is the incident this prevents).  Turning it on
 * requires a typed reason, and the Launch button says which mode it is
 * in — enabling delivery by accident must be impossible.
 *
 * The launch response carries PER-ITEM outcomes (created / error / the
 * skip verdict) — rendered per date, never as one aggregate "done".
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Divider, FormControl, FormControlLabel,
  InputLabel, MenuItem, Select, Stack, Switch, Table, TableBody,
  TableCell, TableHead, TableRow, TextField, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  History as BackfillIcon, PlayArrow as LaunchIcon,
  Visibility as PreviewIcon, Warning as WarnIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type {
  BackfillPlan, BackfillPlanItem,
} from '../services/api/feedOperations';
import ListPager, { clientPage } from './common/ListPager';

export interface BackfillFeedRef { id: number; name: string; }

type PreviewState =
  | { phase: 'idle' }
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | {
      phase: 'ready'; plan: BackfillPlan;
      for: { start: string; end: string; order: string };
    };

type LaunchState =
  | { phase: 'idle' }
  | { phase: 'launching' }
  | { phase: 'error'; message: string }
  | { phase: 'done'; plan: BackfillPlan };

const VERDICT_COLOR: Record<string, 'success' | 'warning' | 'error' | 'default'> = {
  will_run: 'success',
  already_active: 'warning',
  error: 'error',
  non_business_day: 'default',
  condition_skip: 'default',
  outside_validity_window: 'default',
};

const OUTCOME_COLOR: Record<string, 'success' | 'error' | 'default'> = {
  created: 'success',
  error: 'error',
};

const VerdictChip: React.FC<{ item: BackfillPlanItem; launched: boolean }> =
  ({ item, launched }) => {
    const label = launched ? (item.outcome ?? item.verdict) : item.verdict;
    const color = launched
      ? (OUTCOME_COLOR[label] ?? 'default')
      : (VERDICT_COLOR[label] ?? 'default');
    return <Chip size="small" label={label} color={color}
                 variant={color === 'default' ? 'outlined' : 'filled'}
                 sx={{ height: 20, fontSize: '0.68rem' }} />;
  };

const FeedBackfillDialog: React.FC<{
  feed: BackfillFeedRef | null;
  onClose: () => void;
  /** Called after a launch created at least one run, so the caller can
   *  refresh run lists. */
  onLaunched?: () => void;
}> = ({ feed, onClose, onLaunched }) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [order, setOrder] =
    useState<'oldest_first' | 'newest_first'>('oldest_first');
  const [deliver, setDeliver] = useState(false);
  const [reason, setReason] = useState('');
  const [preview, setPreview] = useState<PreviewState>({ phase: 'idle' });
  const [launch, setLaunch] = useState<LaunchState>({ phase: 'idle' });
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  // A fresh feed = a fresh dialog.  Delivery ALWAYS re-opens OFF.
  useEffect(() => {
    if (feed != null) {
      setStartDate(''); setEndDate('');
      setOrder('oldest_first');
      setDeliver(false); setReason('');
      setPreview({ phase: 'idle' });
      setLaunch({ phase: 'idle' });
      setPage(1);
    }
  }, [feed?.id]);

  const busy = preview.phase === 'loading' || launch.phase === 'launching';
  const launched = launch.phase === 'done';

  /** Launch must send EXACTLY what was previewed: stale = disabled. */
  const previewFresh = preview.phase === 'ready'
    && preview.for.start === startDate
    && preview.for.end === endDate
    && preview.for.order === order;

  const reasonMissing = deliver && !reason.trim();

  const handlePreview = async () => {
    if (!feed || !startDate || !endDate) return;
    setPreview({ phase: 'loading' });
    setLaunch({ phase: 'idle' });
    try {
      const plan = await api.previewFeedBackfill(feed.id, {
        start_date: startDate, end_date: endDate, order,
      });
      setPreview({
        phase: 'ready', plan,
        for: { start: startDate, end: endDate, order },
      });
      setPage(1);
    } catch (e: any) {
      setPreview({ phase: 'error', message: e?.message || String(e) });
    }
  };

  const handleLaunch = async () => {
    if (!feed || !previewFresh || reasonMissing) return;
    setLaunch({ phase: 'launching' });
    try {
      const plan = await api.launchFeedBackfill(feed.id, {
        // The PREVIEWED values, verbatim — not re-read from the form.
        start_date: preview.phase === 'ready' ? preview.for.start : startDate,
        end_date: preview.phase === 'ready' ? preview.for.end : endDate,
        order: (preview.phase === 'ready'
          ? preview.for.order : order) as 'oldest_first' | 'newest_first',
        deliver,
        ...(deliver ? { reason: reason.trim() } : {}),
      });
      setLaunch({ phase: 'done', plan });
      setPage(1);
      if ((plan.summary?.created ?? 0) > 0) onLaunched?.();
    } catch (e: any) {
      setLaunch({ phase: 'error', message: e?.message || String(e) });
    }
  };

  const plan: BackfillPlan | null =
    launch.phase === 'done' ? launch.plan
      : preview.phase === 'ready' ? preview.plan : null;

  const willRun = plan?.summary.will_run ?? 0;
  const pg = clientPage(plan?.items ?? [], page, pageSize);

  return (
    <AppDialog open={feed != null}
      onClose={busy ? undefined : onClose}
      size="md"
      title={<>
        <Stack direction="row" spacing={1} alignItems="center">
          <BackfillIcon fontSize="small" />
          <span>Backfill — {feed?.name}</span>
        </Stack>
      </>}
      actions={<>
        <Button onClick={onClose} disabled={busy}>
          {launched ? 'Close' : 'Cancel'}
        </Button>
        {!launched && (
          <>
            <Button
              onClick={() => void handlePreview()}
              disabled={busy || !startDate || !endDate}
              startIcon={preview.phase === 'loading'
                ? <CircularProgress size={14} /> : <PreviewIcon />}
            >
              Preview
            </Button>
            <Button
              variant="contained"
              color={deliver ? 'warning' : 'primary'}
              onClick={() => void handleLaunch()}
              disabled={busy || !previewFresh || reasonMissing || willRun === 0}
              startIcon={launch.phase === 'launching'
                ? <CircularProgress size={14} /> : <LaunchIcon />}
              data-testid="backfill-launch"
            >
              {deliver
                ? `Launch ${willRun} run(s) AND DELIVER`
                : `Launch ${willRun} run(s) (delivery suppressed)`}
            </Button>
          </>
        )}
      </>}>
        <Stack direction="row" spacing={2} sx={{ mb: 2, mt: 0.5 }} flexWrap="wrap">
          <TextField
            label="Start date" type="date" value={startDate}
            onChange={e => setStartDate(e.target.value)}
            InputLabelProps={{ shrink: true }} size="small"
            disabled={busy || launched}
            inputProps={{ 'data-testid': 'backfill-start' }}
          />
          <TextField
            label="End date" type="date" value={endDate}
            onChange={e => setEndDate(e.target.value)}
            InputLabelProps={{ shrink: true }} size="small"
            disabled={busy || launched}
            inputProps={{ 'data-testid': 'backfill-end' }}
          />
          <FormControl size="small" sx={{ minWidth: 160 }}>
            <InputLabel id="backfill-order-label">Execution order</InputLabel>
            <Select
              labelId="backfill-order-label" label="Execution order"
              value={order} disabled={busy || launched}
              onChange={e =>
                setOrder(e.target.value as 'oldest_first' | 'newest_first')}
            >
              <MenuItem value="oldest_first">Oldest first</MenuItem>
              <MenuItem value="newest_first">Newest first</MenuItem>
            </Select>
          </FormControl>
        </Stack>

        {/* ── Delivery: OFF by default, reasoned override (FR-OPS-08) ── */}
        <Box sx={{ mb: 2 }}>
          <FormControlLabel
            control={
              <Switch checked={deliver} color="warning"
                      disabled={busy || launched}
                      onChange={e => setDeliver(e.target.checked)}
                      slotProps={{ input: { 'data-testid': 'backfill-deliver' } as any }} />
            }
            label="Also DELIVER the produced files"
          />
          {!deliver && (
            <Typography variant="caption" color="text.secondary"
                        sx={{ display: 'block' }}>
              Default: files are produced but every delivery hop is recorded
              as SUPPRESSED — nothing reaches a counterparty.  A specific
              file can be sent later via a reasoned delivery-hop retry.
            </Typography>
          )}
          {deliver && (
            <>
              <Alert severity="warning" icon={<WarnIcon />} sx={{ my: 1 }}>
                Every date this backfill creates will <strong>send its files to
                the feed&apos;s real destinations</strong> — for a month-long
                range that is a month of files re-delivered to counterparties.
                This choice is audited with your name and the reason below.
              </Alert>
              <TextField
                label="Reason for delivering (required)"
                placeholder="Why is re-delivering these files safe and intended?"
                value={reason} onChange={e => setReason(e.target.value)}
                fullWidth multiline minRows={2} disabled={busy || launched}
                error={reasonMissing}
                inputProps={{ 'data-testid': 'backfill-deliver-reason' }}
              />
            </>
          )}
        </Box>

        <Divider sx={{ mb: 2 }} />

        {preview.phase === 'error' && (
          <Alert severity="error" sx={{ mb: 2 }} data-testid="backfill-preview-error">
            Preview failed — nothing was launched and the plan below (if any)
            is stale. {preview.message}
          </Alert>
        )}
        {launch.phase === 'error' && (
          <Alert severity="error" sx={{ mb: 2 }} data-testid="backfill-launch-error">
            Launch refused — no runs were created by this attempt.
            {' '}{launch.message}
          </Alert>
        )}
        {launched && launch.phase === 'done' && (
          <Alert
            severity={(launch.plan.summary.errors ?? 0) > 0 ? 'warning' : 'success'}
            sx={{ mb: 2 }} data-testid="backfill-launch-summary"
          >
            Backfill batch <code>{launch.plan.batch_id}</code>:
            {' '}{launch.plan.summary.created ?? 0} run(s) created,
            {' '}{launch.plan.summary.errors ?? 0} error(s),
            {' '}{launch.plan.summary.skipped} date(s) skipped.
            {' '}Delivery {launch.plan.deliver
              ? 'ENABLED — files will be sent.'
              : 'suppressed (files produced, nothing sent).'}
          </Alert>
        )}

        {plan && (
          <>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>
              {launched
                ? 'Per-date outcomes'
                : <>Preview — <strong>{willRun}</strong> of
                    {' '}{plan.summary.total_dates} date(s) will run
                    ({plan.order === 'newest_first'
                      ? 'newest first' : 'oldest first'})
                    {plan.calendar_name
                      ? `, calendar '${plan.calendar_name}'`
                      : ', no business calendar'}</>}
            </Typography>
            <Box sx={{ maxHeight: 300, overflow: 'auto' }}>
              <Table size="small" data-testid="backfill-plan-table">
                <TableHead>
                  <TableRow>
                    <TableCell>Business date</TableCell>
                    <TableCell>{launched ? 'Outcome' : 'Verdict'}</TableCell>
                    <TableCell>Detail</TableCell>
                    <TableCell align="right">
                      {launched ? 'Run' : 'Prior runs'}
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {pg.rows.map(item => (
                    <TableRow key={item.business_date}>
                      <TableCell>{item.business_date}</TableCell>
                      <TableCell>
                        <VerdictChip item={item} launched={launched} />
                      </TableCell>
                      <TableCell sx={{ maxWidth: 360 }}>
                        <Typography variant="caption"
                          color={(launched ? item.outcome : item.verdict) === 'error'
                            ? 'error' : 'text.secondary'}>
                          {item.reason || ''}
                        </Typography>
                      </TableCell>
                      <TableCell align="right">
                        {launched
                          ? (item.run_id != null ? `#${item.run_id}` : '—')
                          : item.prior_runs}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
            <ListPager paging={pg.paging} onPage={setPage} onPageSize={setPageSize} testid="backfill-plan-pager" />
          </>
        )}

        {!launched && preview.phase === 'ready' && !previewFresh && (
          <Alert severity="info" sx={{ mt: 1 }} data-testid="backfill-stale-preview">
            The dates or order changed since this preview — preview again
            before launching.  Launch always runs exactly what was previewed.
          </Alert>
        )}
    </AppDialog>
  );
};

export default FeedBackfillDialog;
