/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Local Tables Management Page
 *
 * CRUD interface for user-uploaded / promoted local tables.
 * Upload, create, edit, and delete local tables.
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { getUserFriendlyError } from '../utils/errorMessages';
import {
  Alert, Box, Button, Chip, CircularProgress, Dialog, FormControl, IconButton, InputLabel,
  LinearProgress, MenuItem, Paper, Select, TextField, Tooltip,
  Typography, Table, TableBody, TableCell, TableHead, TableRow, TableContainer,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon,
  Refresh as RefreshIcon, Close as CloseIcon,
  CheckCircle as ReadyIcon, Error as FailIcon, HourglassEmpty as PendingIcon,
  CloudUpload as UploadIcon, TableChart as TableChartIcon,
  Public as PublicIcon, Lock as PrivateIcon,
  OpenInNew as OpenInQueryIcon,
  PlaylistAdd as AppendIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import { useWebSocket } from '../context/WebSocketContext';
import ListPager, { clientPage } from './common/ListPager';

// ─── Helpers ──────────────────────────────────────────────────────────────

const fmtDate = (iso: string | null) => {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' }); }
  catch { return iso; }
};

const fmtBytes = (b: number) => {
  if (!b) return '0 B';
  if (b < 1024) return `${b} B`;
  if (b < 1048576) return `${(b / 1024).toFixed(1)} KB`;
  if (b < 1073741824) return `${(b / 1048576).toFixed(1)} MB`;
  return `${(b / 1073741824).toFixed(2)} GB`;
};

const fmtRows = (n: number) => {
  if (!n) return '0';
  if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
  return String(n);
};

const statusChip = (s: string, lastError?: string) => {
  switch (s) {
    case 'ready':
      return <Chip icon={<ReadyIcon sx={{ fontSize: '14px !important' }} />} label="Ready" color="success" size="small" variant="outlined" sx={{ fontSize: 10 }} />;
    case 'processing':
      return <Chip icon={<CircularProgress size={12} sx={{ ml: '2px' }} />} label="Processing" color="info" size="small" variant="outlined" sx={{ fontSize: 10 }} />;
    case 'failed':
      return (
        <Tooltip title={lastError || 'Unknown error'}>
          <Chip icon={<FailIcon sx={{ fontSize: '14px !important' }} />} label="Failed" color="error" size="small" variant="outlined" sx={{ fontSize: 10 }} />
        </Tooltip>
      );
    default:
      return <Chip icon={<PendingIcon sx={{ fontSize: '14px !important' }} />} label="Pending" size="small" variant="outlined" sx={{ fontSize: 10 }} />;
  }
};

const ACCEPTED_FILE_TYPES = '.csv,.tsv,.txt,.dat,.xlsx,.xls,.json,.parquet';

// ─── Component ────────────────────────────────────────────────────────────

const LocalTablesPage = () => {
  const { lastMessage } = useWebSocket();
  const navigate = useNavigate();

  const [tables, setTables] = useState<any[]>([]);
  const [storage, setStorage] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [filterVisibility, setFilterVisibility] = useState<string>('');
  const [filterSource, setFilterSource] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  // A new search or filter goes back to page 1.
  useEffect(() => { setPage(1); }, [search, filterVisibility, filterSource, filterStatus]);

  // Upload dialog state
  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadForm, setUploadForm] = useState<any>({
    name: '', description: '', visibility: 'public', auto_discard_days: 10,
  });
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [excelSheets, setExcelSheets] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [loadingSheets, setLoadingSheets] = useState(false);

  // Edit dialog state
  const [editOpen, setEditOpen] = useState(false);
  const [editingTable, setEditingTable] = useState<any>(null);
  const [editForm, setEditForm] = useState<any>({
    name: '', description: '', visibility: 'public', auto_discard_days: 10,
  });
  const [saving, setSaving] = useState(false);

  // Append dialog state
  const [appendTarget, setAppendTarget] = useState<any>(null);
  const [appendFile, setAppendFile] = useState<File | null>(null);
  const [appending, setAppending] = useState(false);
  const appendFileRef = useRef<HTMLInputElement>(null);
  const [appendSheets, setAppendSheets] = useState<string[]>([]);
  const [appendSelectedSheet, setAppendSelectedSheet] = useState<string>('');
  const [appendLoadingSheets, setAppendLoadingSheets] = useState(false);

  // Delete dialog state
  const [deleteConfirm, setDeleteConfirm] = useState<any>(null);

  // Polling for processing tables
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ─── Load data ──────────────────────────────────────────────────────────

  const loadAll = useCallback(async () => {
    try {
      const [tbs, stor] = await Promise.all([
        api.listLocalTables(),
        api.getLocalTablesStorage(),
      ]);
      setTables(tbs || []);
      setStorage(stor);
      setError('');
    } catch (e: any) {
      setError(getUserFriendlyError(e, 'Failed to load'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  // Poll for processing tables
  useEffect(() => {
    const processing = tables.filter(t => t.status === 'processing' || t.status === 'pending');
    if (processing.length > 0 && !pollRef.current) {
      pollRef.current = setInterval(() => loadAll(), 5000);
    } else if (processing.length === 0 && pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    return () => { if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; } };
  }, [tables, loadAll]);

  // WebSocket updates
  useEffect(() => {
    if (
      lastMessage?.type === 'local_table_ready' ||
      lastMessage?.type === 'local_table_failed' ||
      lastMessage?.type === 'local_table_deleted'
    ) {
      loadAll();
    }
  }, [lastMessage, loadAll]);

  // ─── Upload dialog helpers ─────────────────────────────────────────────

  const openUpload = () => {
    setUploadFile(null);
    setUploadForm({ name: '', description: '', visibility: 'public', auto_discard_days: 10 });
    setUploadOpen(true);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadFile(file);
      setExcelSheets([]);
      setSelectedSheet('');
      // Auto-fill name from filename minus extension
      const nameWithoutExt = file.name.replace(/\.[^/.]+$/, '');
      setUploadForm((f: any) => ({ ...f, name: f.name || nameWithoutExt }));

      // If Excel file, fetch sheet names
      const ext = file.name.split('.').pop()?.toLowerCase();
      if (ext === 'xlsx' || ext === 'xls') {
        setLoadingSheets(true);
        try {
          const sheets = await api.listExcelSheets(file);
          setExcelSheets(sheets);
          if (sheets.length === 1) setSelectedSheet(sheets[0]);
        } catch (err: any) {
          console.warn('Failed to list Excel sheets:', err);
        } finally {
          setLoadingSheets(false);
        }
      }
    }
  };

  const handleUpload = async () => {
    if (!uploadFile || !uploadForm.name.trim()) return;
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', uploadFile);
      formData.append('name', uploadForm.name.trim());
      if (uploadForm.description.trim()) formData.append('description', uploadForm.description.trim());
      formData.append('visibility', uploadForm.visibility);
      formData.append('auto_discard_days', String(uploadForm.auto_discard_days));
      if (selectedSheet) formData.append('sheet_name', selectedSheet);
      await api.uploadLocalTable(formData);
      setUploadOpen(false);
      setExcelSheets([]);
      setSelectedSheet('');
      loadAll();
    } catch (e: any) {
      setError(getUserFriendlyError(e, 'Upload failed'));
    } finally {
      setUploading(false);
    }
  };

  // ─── Edit dialog helpers ───────────────────────────────────────────────

  const openEdit = (tbl: any) => {
    setEditingTable(tbl);
    setEditForm({
      name: tbl.name,
      description: tbl.description || '',
      visibility: tbl.visibility || 'public',
      auto_discard_days: tbl.auto_discard_days ?? 10,
    });
    setEditOpen(true);
  };

  const handleSave = async () => {
    if (!editingTable) return;
    setSaving(true);
    try {
      await api.updateLocalTable(editingTable.id, {
        name: editForm.name.trim(),
        description: editForm.description.trim() || null,
        visibility: editForm.visibility,
        auto_discard_days: Number(editForm.auto_discard_days),
      });
      setEditOpen(false);
      loadAll();
    } catch (e: any) {
      setError(getUserFriendlyError(e, 'Save failed'));
    } finally {
      setSaving(false);
    }
  };

  // ─── Append helpers ────────────────────────────────────────────────────

  const handleAppendFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setAppendFile(file);
    setAppendSheets([]);
    setAppendSelectedSheet('');
    if (file) {
      const ext = file.name.split('.').pop()?.toLowerCase();
      if (ext === 'xlsx' || ext === 'xls') {
        setAppendLoadingSheets(true);
        try {
          const sheets = await api.listExcelSheets(file);
          setAppendSheets(sheets);
          if (sheets.length === 1) setAppendSelectedSheet(sheets[0]);
        } catch (err: any) {
          console.warn('Failed to list Excel sheets for append:', err);
        } finally {
          setAppendLoadingSheets(false);
        }
      }
    }
  };

  const handleAppend = async () => {
    if (!appendTarget || !appendFile) return;
    setAppending(true);
    try {
      const formData = new FormData();
      formData.append('file', appendFile);
      if (appendSelectedSheet) formData.append('sheet_name', appendSelectedSheet);
      await api.appendToLocalTable(appendTarget.id, formData);
      setAppendTarget(null);
      setAppendFile(null);
      setAppendSheets([]);
      setAppendSelectedSheet('');
      loadAll();
    } catch (e: any) {
      setError(getUserFriendlyError(e, 'Append failed'));
    } finally {
      setAppending(false);
    }
  };

  // ─── Delete helpers ────────────────────────────────────────────────────

  const handleDelete = async () => {
    if (!deleteConfirm) return;
    try {
      await api.deleteLocalTable(deleteConfirm.id);
      setDeleteConfirm(null);
      loadAll();
    } catch (e: any) {
      setError(getUserFriendlyError(e, 'Delete failed'));
    }
  };

  // ─── Filter tables ─────────────────────────────────────────────────────

  const filtered = tables.filter(t => {
    if (search && !t.name.toLowerCase().includes(search.toLowerCase())) return false;
    if (filterVisibility && t.visibility !== filterVisibility) return false;
    if (filterSource && t.source_type !== filterSource) return false;
    if (filterStatus && t.status !== filterStatus) return false;
    return true;
  });
  // Filter first, page second.
  const shown = clientPage(filtered, page, pageSize);

  // ─── Render ─────────────────────────────────────────────────────────────

  return (
    <Box sx={{ p: 3, maxWidth: 1400, mx: 'auto' }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 2 }}>
        <TableChartIcon color="primary" />
        <Typography variant="h5" fontWeight={700} sx={{ flex: 1 }}>Local Tables</Typography>
        <Button variant="outlined" startIcon={<UploadIcon />} onClick={openUpload} size="small">
          Upload
        </Button>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => {
          // Create via promote — for now open upload as the primary creation path
          openUpload();
        }} size="small">
          Create
        </Button>
        <Tooltip title="Refresh list">
          <IconButton size="small" onClick={loadAll}><RefreshIcon /></IconButton>
        </Tooltip>
      </Box>

      {/* Storage summary */}
      {storage && (
        <Box sx={{ display: 'flex', gap: 3, mb: 2, flexWrap: 'wrap' }}>
          <Chip label={`Tables: ${tables.length} / ${storage.max_tables || 100}`} size="small" variant="outlined" />
          <Chip label={`${fmtBytes(storage.total_size_bytes || 0)} / ${fmtBytes(storage.max_size_bytes || 10737418240)}`} size="small" variant="outlined"
            color={(storage.usage_pct || 0) > 80 ? 'warning' : 'default'} />
          {(storage.usage_pct || 0) > 0 && (
            <Box sx={{ flex: 1, minWidth: 200, maxWidth: 400, display: 'flex', alignItems: 'center', gap: 1 }}>
              <LinearProgress variant="determinate" value={Math.min(storage.usage_pct || 0, 100)}
                sx={{ flex: 1, height: 6, borderRadius: 3 }}
                color={(storage.usage_pct || 0) > 80 ? 'warning' : 'primary'} />
              <Typography variant="caption" color="text.secondary">{storage.usage_pct || 0}%</Typography>
            </Box>
          )}
        </Box>
      )}

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {/* Filters */}
      <Box sx={{ display: 'flex', gap: 1.5, mb: 2, flexWrap: 'wrap' }}>
        <TextField size="small" placeholder="Search tables..." value={search}
          onChange={e => setSearch(e.target.value)} sx={{ minWidth: 200 }} />
        <FormControl size="small" sx={{ minWidth: 130 }}>
          <InputLabel id="sel-localtablespage-visibility">Visibility</InputLabel>
          <Select labelId="sel-localtablespage-visibility" value={filterVisibility} label="Visibility" onChange={e => setFilterVisibility(e.target.value)}>
            <MenuItem value="">All</MenuItem>
            <MenuItem value="public">Public</MenuItem>
            <MenuItem value="private">Private</MenuItem>
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 130 }}>
          <InputLabel id="sel-localtablespage-source">Source</InputLabel>
          <Select labelId="sel-localtablespage-source" value={filterSource} label="Source" onChange={e => setFilterSource(e.target.value)}>
            <MenuItem value="">All</MenuItem>
            <MenuItem value="download">Download</MenuItem>
            <MenuItem value="upload">Upload</MenuItem>
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 120 }}>
          <InputLabel id="sel-localtablespage-status">Status</InputLabel>
          <Select labelId="sel-localtablespage-status" value={filterStatus} label="Status" onChange={e => setFilterStatus(e.target.value)}>
            <MenuItem value="">All</MenuItem>
            <MenuItem value="ready">Ready</MenuItem>
            <MenuItem value="processing">Processing</MenuItem>
            <MenuItem value="pending">Pending</MenuItem>
            <MenuItem value="failed">Failed</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Table */}
      {loading ? <LinearProgress /> : (
        <Paper variant="outlined">
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow sx={{ '& th': { fontWeight: 700, fontSize: 11, color: 'text.secondary' } }}>
                  <TableCell>Name</TableCell>
                  <TableCell>Source</TableCell>
                  <TableCell align="right">Rows</TableCell>
                  <TableCell align="right">Size</TableCell>
                  <TableCell>Visibility</TableCell>
                  <TableCell>Last Used</TableCell>
                  <TableCell>Auto-Discard</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filtered.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} align="center" sx={{ py: 4 }}>
                      <Typography color="text.secondary">
                        {tables.length === 0 ? 'No local tables yet. Upload a file or create one to get started.' : 'No tables match filters.'}
                      </Typography>
                    </TableCell>
                  </TableRow>
                ) : shown.rows.map(tbl => (
                  <TableRow key={tbl.id} hover>
                    <TableCell>
                      <Typography variant="body2" fontWeight={600}>{tbl.name}</Typography>
                      {tbl.description && (
                        <Typography variant="caption" color="text.secondary" noWrap sx={{ maxWidth: 200, display: 'block' }}>
                          {tbl.description}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell>
                      <Chip
                        label={tbl.source_type === 'upload' ? 'Upload' : 'Download'}
                        size="small"
                        variant="outlined"
                        sx={{ fontSize: 10 }}
                        color={tbl.source_type === 'upload' ? 'info' : 'default'}
                      />
                    </TableCell>
                    <TableCell align="right">
                      <Typography variant="body2">{fmtRows(tbl.row_count)}</Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Typography variant="body2">{fmtBytes(tbl.size_bytes)}</Typography>
                    </TableCell>
                    <TableCell>
                      <Chip
                        icon={tbl.visibility === 'public'
                          ? <PublicIcon sx={{ fontSize: '14px !important' }} />
                          : <PrivateIcon sx={{ fontSize: '14px !important' }} />}
                        label={tbl.visibility === 'public' ? 'Public' : 'Private'}
                        size="small"
                        variant="outlined"
                        sx={{ fontSize: 10 }}
                        color={tbl.visibility === 'public' ? 'success' : 'default'}
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">{fmtDate(tbl.last_used_at)}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="caption">
                        {tbl.auto_discard_days === 0 ? 'Never' : `${tbl.auto_discard_days} days`}
                      </Typography>
                    </TableCell>
                    <TableCell>{statusChip(tbl.status, tbl.last_error)}</TableCell>
                    <TableCell align="center">
                      <Box sx={{ display: 'flex', gap: 0.5, justifyContent: 'center' }}>
                        {tbl.status === 'ready' && (
                          <Tooltip title="Append data">
                            <IconButton size="small" color="secondary"
                              onClick={() => { setAppendTarget(tbl); setAppendFile(null); }}>
                              <AppendIcon sx={{ fontSize: 16 }} />
                            </IconButton>
                          </Tooltip>
                        )}
                        {tbl.status === 'ready' && (
                          <Tooltip title="Open in Query Builder">
                            <IconButton size="small" color="primary"
                              onClick={() => navigate('/', { state: { openLocalTable: tbl.name } })}>
                              <OpenInQueryIcon sx={{ fontSize: 16 }} />
                            </IconButton>
                          </Tooltip>
                        )}
                        <Tooltip title="Edit">
                          <IconButton size="small" onClick={() => openEdit(tbl)}>
                            <EditIcon sx={{ fontSize: 16 }} />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton size="small" color="error" onClick={() => setDeleteConfirm(tbl)}>
                            <DeleteIcon sx={{ fontSize: 16 }} />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <ListPager paging={shown.paging} onPage={setPage} onPageSize={setPageSize}
                     testid="local-tables-pager" />
        </Paper>
      )}

      {/* Upload Dialog */}
      <AppDialog open={uploadOpen}
        onClose={() => setUploadOpen(false)}
        size="sm"
        title={<>
          <UploadIcon color="primary" fontSize="small" />
          Upload Local Table
          <Box sx={{ flex: 1 }} />
          <Tooltip title="Cancel upload"><IconButton size="small" onClick={() => setUploadOpen(false)}><CloseIcon /></IconButton></Tooltip>
        </>}
        contentSx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}
        actions={<>
          <Button onClick={() => setUploadOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleUpload}
            disabled={uploading || !uploadFile || !uploadForm.name.trim()}>
            {uploading ? <CircularProgress size={18} /> : 'Upload'}
          </Button>
        </>}>
          {/* File picker */}
          <Box>
            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPTED_FILE_TYPES}
              style={{ display: 'none' }}
              onChange={handleFileSelect}
            />
            <Button variant="outlined" startIcon={<UploadIcon />} onClick={() => fileInputRef.current?.click()}>
              {uploadFile ? uploadFile.name : 'Choose File'}
            </Button>
            <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
              .csv, .tsv, .txt, .dat, .xlsx, .xls, .json, .parquet
            </Typography>
          </Box>

          {/* Excel sheet picker — shown only for multi-sheet Excel files */}
          {loadingSheets && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <CircularProgress size={16} />
              <Typography variant="body2" color="text.secondary">Loading worksheets…</Typography>
            </Box>
          )}
          {excelSheets.length > 1 && (
            <FormControl size="small" fullWidth>
              <InputLabel id="sel-localtablespage-worksheet">Worksheet</InputLabel>
              <Select labelId="sel-localtablespage-worksheet" value={selectedSheet} label="Worksheet"
                onChange={e => setSelectedSheet(e.target.value as string)}>
                {excelSheets.map(s => (
                  <MenuItem key={s} value={s}>{s}</MenuItem>
                ))}
              </Select>
            </FormControl>
          )}

          <TextField label="Name" size="small" required fullWidth
            value={uploadForm.name}
            onChange={e => setUploadForm({ ...uploadForm, name: e.target.value })} />
          <TextField label="Description" size="small" fullWidth multiline rows={2}
            value={uploadForm.description}
            onChange={e => setUploadForm({ ...uploadForm, description: e.target.value })} />

          {/* Visibility */}
          <FormControl size="small" fullWidth>
            <InputLabel id="sel-localtablespage-visibility-2">Visibility</InputLabel>
            <Select labelId="sel-localtablespage-visibility-2" value={uploadForm.visibility} label="Visibility"
              onChange={e => setUploadForm({ ...uploadForm, visibility: e.target.value })}>
              <MenuItem value="public">Public</MenuItem>
              <MenuItem value="private">Private</MenuItem>
            </Select>
          </FormControl>

          {/* Auto-discard days */}
          <TextField label="Auto-discard days" size="small" type="number" fullWidth
            value={uploadForm.auto_discard_days}
            onChange={e => setUploadForm({ ...uploadForm, auto_discard_days: e.target.value })}
            helperText="Number of days before auto-discard. 0 = never discard." />
      </AppDialog>

      {/* Edit Dialog */}
      <AppDialog open={editOpen}
        onClose={() => setEditOpen(false)}
        size="sm"
        title={<>
          <TableChartIcon color="primary" fontSize="small" />
          Edit Local Table
          <Box sx={{ flex: 1 }} />
          <Tooltip title="Close edit dialog"><IconButton size="small" onClick={() => setEditOpen(false)}><CloseIcon /></IconButton></Tooltip>
        </>}
        contentSx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: '16px !important' }}
        actions={<>
          <Button onClick={() => setEditOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSave}
            disabled={saving || !editForm.name.trim()}>
            {saving ? <CircularProgress size={18} /> : 'Save Changes'}
          </Button>
        </>}>
          <TextField label="Name" size="small" required fullWidth
            value={editForm.name}
            onChange={e => setEditForm({ ...editForm, name: e.target.value })} />
          <TextField label="Description" size="small" fullWidth multiline rows={2}
            value={editForm.description}
            onChange={e => setEditForm({ ...editForm, description: e.target.value })} />

          {/* Visibility */}
          <FormControl size="small" fullWidth>
            <InputLabel id="sel-localtablespage-visibility-3">Visibility</InputLabel>
            <Select labelId="sel-localtablespage-visibility-3" value={editForm.visibility} label="Visibility"
              onChange={e => setEditForm({ ...editForm, visibility: e.target.value })}>
              <MenuItem value="public">Public</MenuItem>
              <MenuItem value="private">Private</MenuItem>
            </Select>
          </FormControl>

          {/* Auto-discard days */}
          <TextField label="Auto-discard days" size="small" type="number" fullWidth
            value={editForm.auto_discard_days}
            onChange={e => setEditForm({ ...editForm, auto_discard_days: e.target.value })}
            helperText="Number of days before auto-discard. 0 = never discard." />
      </AppDialog>

      {/* Append Data Dialog */}
      <AppDialog open={!!appendTarget}
        onClose={() => setAppendTarget(null)}
        size="sm"
        title={<>
          Append Data to "{appendTarget?.name}"
          <Tooltip title="Cancel append"><IconButton size="small" onClick={() => setAppendTarget(null)}><CloseIcon /></IconButton></Tooltip>
        </>}
        contentSx={{ pt: 2 }}
        actions={<>
          <Button onClick={() => setAppendTarget(null)}>Cancel</Button>
          <Button variant="contained" startIcon={appending ? <CircularProgress size={16} /> : <AppendIcon />}
            onClick={handleAppend} disabled={appending || !appendFile}>
            {appending ? 'Appending…' : 'Append'}
          </Button>
        </>}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Upload a file to append rows to this table. The new file must have compatible columns.
            Current: <strong>{fmtRows(appendTarget?.row_count || 0)} rows</strong>, {fmtBytes(appendTarget?.size_bytes || 0)}.
          </Typography>
          <Button variant="outlined" component="label" startIcon={<UploadIcon />} fullWidth>
            {appendFile ? appendFile.name : 'Choose File'}
            <input ref={appendFileRef} type="file" hidden
              accept=".csv,.tsv,.txt,.dat,.xlsx,.xls,.json,.parquet"
              onChange={handleAppendFileSelect} />
          </Button>
          {appendFile && (
            <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
              {fmtBytes(appendFile.size)} · {appendFile.name}
            </Typography>
          )}
          {appendLoadingSheets && (
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 1 }}>
              <CircularProgress size={16} />
              <Typography variant="body2" color="text.secondary">Loading worksheets…</Typography>
            </Box>
          )}
          {appendSheets.length > 1 && (
            <FormControl size="small" fullWidth sx={{ mt: 1 }}>
              <InputLabel id="sel-localtablespage-worksheet-2">Worksheet</InputLabel>
              <Select labelId="sel-localtablespage-worksheet-2" value={appendSelectedSheet} label="Worksheet"
                onChange={e => setAppendSelectedSheet(e.target.value as string)}>
                {appendSheets.map(s => (
                  <MenuItem key={s} value={s}>{s}</MenuItem>
                ))}
              </Select>
            </FormControl>
          )}
      </AppDialog>

      {/* Delete Confirmation */}
      <AppDialog open={!!deleteConfirm}
        onClose={() => setDeleteConfirm(null)}
        size="xs"
        title="Delete Local Table"
        actions={<>
          <Button onClick={() => setDeleteConfirm(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={handleDelete}>Delete</Button>
        </>}>
          <Typography>
            Delete <strong>{deleteConfirm?.name}</strong>? This will remove all local data files ({fmtBytes(deleteConfirm?.size_bytes || 0)}).
          </Typography>
      </AppDialog>
    </Box>
  );
};

export default LocalTablesPage;
