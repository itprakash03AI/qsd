/**
 * SFTP destination settings — one component for the feed's destination AND
 * every SFTP hop of a delivery chain (2026-09-24).
 *
 * Why it exists.  The feed form offered host / port / username / password /
 * remote directory and nothing else, while delivery REFUSES a server whose
 * host key is not pinned (the MITM guard).  So an SFTP feed authored in the UI
 * could never deliver, key auth and vault-held accounts could not be authored
 * at all, and — worse — saving an EXISTING feed rebuilt its config from those
 * five fields and silently dropped the pinned key: the next run failed.
 *
 * The contract with its caller:
 *   * ``value`` is the COMPLETE stored config; every key this form does not
 *     show is carried through untouched (``onChange`` always returns the full
 *     object).  Only switching the sign-in method clears the other method's
 *     keys — that is a decision the user made on screen.
 *   * Server identity is pinned from a fingerprint the user confirms
 *     ("Fetch from server"), never trusted silently.
 *   * "Test connection" runs the SAME code path delivery uses, on the server.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, CircularProgress, FormControl, FormControlLabel, FormHelperText, InputLabel,
  MenuItem, Radio, RadioGroup, Select, Stack, TextField, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import { safeFetch } from '../../services/api/core';
import {
  AUTH_KEYS, sftpAuthModeOf, sftpConfigProblems, type SftpAuthMode,
} from './sftpRules';

export { sftpAuthModeOf, sftpConfigProblems } from './sftpRules';
export type { SftpAuthMode } from './sftpRules';

/** SHA-256 fingerprint of a base64 host key, in OpenSSH's spelling. */
async function fingerprintOf(b64: string): Promise<string> {
  try {
    const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    const s = btoa(String.fromCharCode(...new Uint8Array(digest)));
    return 'SHA256:' + s.replace(/=+$/, '');
  } catch {
    return '';
  }
}

interface SftpAccount { id: number; name: string; environment?: string | null }
interface HostKeyAnswer {
  key_type: string; host_key_b64: string; fingerprint_sha256: string; note?: string;
}
interface TestAnswer {
  ok: boolean; stage?: string; reason?: string; message?: string;
  auth?: { method?: string; source?: string; key_type?: string | null };
}

export interface SftpDestinationFieldsProps {
  value: Record<string, any>;
  onChange: (next: Record<string, any>) => void;
  /** Stored feed id, so "Test connection" can use a stored (masked) password. */
  feedId?: number | null;
  /** The delivery-chain hop label, when this is a hop. */
  hopLabel?: string | null;
  /** Prefix for field labels (e.g. "Hop 2 "). */
  labelPrefix?: string;
}

export default function SftpDestinationFields({
  value, onChange, feedId, hopLabel, labelPrefix = '',
}: SftpDestinationFieldsProps) {
  const cfg = value || {};
  const mode = sftpAuthModeOf(cfg);
  /** "Host" alone, "Hop 2 host" with a prefix -- the labels each editor had. */
  const L = (text: string) =>
    labelPrefix ? `${labelPrefix}${text.charAt(0).toLowerCase()}${text.slice(1)}` : text;
  const set = (patch: Record<string, any>) => onChange({ ...cfg, ...patch });

  const [accounts, setAccounts] = useState<SftpAccount[] | null>(null);
  const [accountsError, setAccountsError] = useState('');
  const [pinnedFp, setPinnedFp] = useState('');
  const [fetching, setFetching] = useState(false);
  const [fetched, setFetched] = useState<HostKeyAnswer | null>(null);
  const [fetchError, setFetchError] = useState('');
  const [testing, setTesting] = useState(false);
  const [test, setTest] = useState<TestAnswer | null>(null);

  useEffect(() => {
    let live = true;
    if (cfg.host_key_b64) fingerprintOf(String(cfg.host_key_b64)).then(fp => live && setPinnedFp(fp));
    else setPinnedFp('');
    return () => { live = false; };
  }, [cfg.host_key_b64]);

  useEffect(() => {
    if (mode !== 'vault_account' || accounts !== null) return;
    safeFetch<SftpAccount[]>('/api/feed-destinations/sftp/accounts')
      .then(rows => setAccounts(Array.isArray(rows) ? rows : []))
      .catch(e => { setAccounts([]); setAccountsError(String(e?.message || e)); });
  }, [mode, accounts]);

  const switchMode = (next: SftpAuthMode) => {
    const cleared = { ...cfg };
    (Object.keys(AUTH_KEYS) as SftpAuthMode[])
      .filter(m => m !== next)
      .forEach(m => AUTH_KEYS[m].forEach(k => { delete cleared[k]; }));
    if (next === 'vault_account') cleared.system_account_id = '';
    if (next === 'key_file') cleared.key_path = cleared.key_path || '';
    onChange(cleared);
    setTest(null);
  };

  const fetchKey = async () => {
    setFetching(true); setFetchError(''); setFetched(null);
    try {
      const ans = await safeFetch<HostKeyAnswer>('/api/feed-destinations/sftp/host-key', {
        method: 'POST',
        body: JSON.stringify({ host: String(cfg.host || '').trim(), port: Number(cfg.port || 22) }),
      });
      setFetched(ans);
    } catch (e: any) {
      setFetchError(String(e?.message || e));
    } finally {
      setFetching(false);
    }
  };

  const runTest = async () => {
    setTesting(true); setTest(null);
    try {
      const ans = await safeFetch<TestAnswer>('/api/feed-destinations/sftp/test', {
        method: 'POST',
        body: JSON.stringify({
          destination_config: cfg,
          ...(feedId ? { feed_id: feedId } : {}),
          ...(hopLabel ? { hop_label: hopLabel } : {}),
        }),
        timeoutMs: 30000,
      });
      setTest(ans);
    } catch (e: any) {
      setTest({ ok: false, stage: 'request', reason: String(e?.message || e) });
    } finally {
      setTesting(false);
    }
  };

  const problems = useMemo(() => sftpConfigProblems(cfg), [cfg]);
  const passwordStored = cfg.password === '***';

  return (
    <Stack spacing={1.5} data-testid="sftp-destination-fields">
      <Stack direction="row" spacing={1}>
        <TextField label={L(`Host`)} size="small" required sx={{ flex: 3 }}
                   value={cfg.host ?? ''} onChange={e => set({ host: e.target.value })}
                   helperText="Server name or IP, as the delivery pod reaches it" />
        <TextField label={L(`Port`)} size="small" sx={{ flex: 1 }}
                   value={cfg.port ?? 22}
                   onChange={e => set({ port: e.target.value === '' ? '' : Number(e.target.value) })} />
      </Stack>
      <TextField label={L(`Remote directory`)} size="small" fullWidth required
                 value={cfg.remote_dir ?? '/'} onChange={e => set({ remote_dir: e.target.value })}
                 helperText="Where files are written; the upload lands as .part and is renamed when complete" />

      <Box>
        <Typography variant="subtitle2">Sign-in method</Typography>
        <RadioGroup row value={mode} onChange={e => switchMode(e.target.value as SftpAuthMode)}>
          <FormControlLabel value="password" control={<Radio size="small" />} label="Password" />
          <FormControlLabel value="key_file" control={<Radio size="small" />} label="Private key file" />
          <FormControlLabel value="vault_account" control={<Radio size="small" />} label="Vault SFTP account" />
        </RadioGroup>
      </Box>

      {mode === 'password' && (
        <Stack direction="row" spacing={1}>
          <TextField label={L(`Username`)} size="small" sx={{ flex: 1 }}
                     value={cfg.username ?? ''} onChange={e => set({ username: e.target.value })} />
          <TextField label={L(`Password`)} type="password" size="small" sx={{ flex: 1 }}
                     value={cfg.password ?? ''} onChange={e => set({ password: e.target.value })}
                     helperText={passwordStored ? 'A password is stored — leave as is to keep it' : ' '} />
        </Stack>
      )}
      {mode === 'key_file' && (
        <Stack spacing={1}>
          <Stack direction="row" spacing={1}>
            <TextField label={L(`Username`)} size="small" sx={{ flex: 1 }}
                       value={cfg.username ?? ''} onChange={e => set({ username: e.target.value })} />
            <TextField label={L(`Key file path`)} size="small" sx={{ flex: 2 }}
                       value={cfg.key_path ?? ''} onChange={e => set({ key_path: e.target.value })}
                       helperText="On the delivery pods (a mounted secret). Ed25519, ECDSA or RSA." />
          </Stack>
          <TextField label={L(`Key passphrase (if the key has one)`)} type="password" size="small"
                     value={cfg.key_passphrase ?? ''} onChange={e => set({ key_passphrase: e.target.value })} />
          <FormHelperText>
            A missing or unreadable key file makes delivery REFUSE — it never falls back to a password.
          </FormHelperText>
        </Stack>
      )}
      {mode === 'vault_account' && (
        <Stack spacing={1}>
          <FormControl size="small" fullWidth>
            <InputLabel id={`${labelPrefix}sftp-acct`}>{L(`SFTP account`)}</InputLabel>
            <Select labelId={`${labelPrefix}sftp-acct`} label={L(`SFTP account`)}
                    value={cfg.system_account_id ?? ''}
                    onChange={e => set({ system_account_id: e.target.value === '' ? '' : Number(e.target.value) })}>
              {(accounts || []).map(a => (
                <MenuItem key={a.id} value={a.id}>
                  {a.name}{a.environment ? ` (${a.environment})` : ''}
                </MenuItem>
              ))}
            </Select>
            <FormHelperText>
              {accounts === null ? 'Loading accounts…'
                : accountsError ? `Could not load accounts: ${accountsError}`
                : accounts.length === 0 ? 'No SFTP accounts yet — an admin adds one under System Accounts (type "SFTP Login").'
                : 'The account holds the username and the private key (or password) in the vault.'}
            </FormHelperText>
          </FormControl>
          <TextField label={L(`Username override (optional)`)} size="small"
                     value={cfg.username ?? ''} onChange={e => set({ username: e.target.value })}
                     helperText="Leave empty to use the account's username" />
        </Stack>
      )}

      <Box sx={{ p: 1.5, border: 1, borderColor: 'divider', borderRadius: 1 }}>
        <Typography variant="subtitle2">Server identity (host key)</Typography>
        {cfg.host_key_b64 ? (
          <Typography variant="body2" sx={{ fontFamily: 'monospace', wordBreak: 'break-all' }}
                      data-testid="sftp-pinned-fingerprint">
            Pinned: {pinnedFp || '(fingerprint unavailable)'}
          </Typography>
        ) : (
          <Typography variant="body2" color="warning.main">
            Not pinned — delivery refuses a server it cannot identify.
          </Typography>
        )}
        <TextField label={L(`Host key`)} size="small" fullWidth sx={{ mt: 1 }}
                   value={cfg.host_key_b64 ?? ''}
                   onChange={e => set({ host_key_b64: e.target.value.trim() || undefined })}
                   InputProps={{ sx: { fontFamily: 'monospace', fontSize: 12 } }}
                   helperText={'Paste the key from the server\'s owner (the last field of '
                     + 'ssh-keyscan output), or use "Fetch from server" and confirm the fingerprint'} />
        <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
          <Button size="small" variant="outlined" onClick={fetchKey}
                  disabled={fetching || !String(cfg.host || '').trim()}>
            {fetching ? <CircularProgress size={16} /> : 'Fetch from server'}
          </Button>
          {cfg.host_key_b64 && (
            <Button size="small" color="warning" onClick={() => set({ host_key_b64: undefined })}>
              Unpin
            </Button>
          )}
        </Stack>
        {fetchError && <Alert severity="error" sx={{ mt: 1 }}>{fetchError}</Alert>}
      </Box>

      <Stack direction="row" spacing={1} alignItems="center">
        <Button size="small" variant="contained" onClick={runTest}
                disabled={testing || problems.length > 0}
                data-testid="sftp-test-connection">
          {testing ? <CircularProgress size={16} /> : 'Test connection'}
        </Button>
        {problems.length > 0 && (
          <Typography variant="caption" color="text.secondary">
            Complete the settings below to test.
          </Typography>
        )}
      </Stack>
      {problems.length > 0 && (
        <Alert severity="warning" data-testid="sftp-problems">
          {problems.map(p => <div key={p}>{p}</div>)}
        </Alert>
      )}
      {test && (
        <Alert severity={test.ok ? 'success' : 'error'} data-testid="sftp-test-result">
          {test.ok
            ? test.message
            : <>Failed at <strong>{test.stage}</strong>: {test.reason}</>}
        </Alert>
      )}

      <AppDialog open={!!fetched}
        onClose={() => setFetched(null)}
        size="sm"
        title="Pin this server's key?"
        actions={<>
          <Button onClick={() => setFetched(null)}>Cancel</Button>
          <Button variant="contained" data-testid="sftp-pin-key"
                  onClick={() => { set({ host_key_b64: fetched?.host_key_b64 }); setFetched(null); setTest(null); }}>
            Fingerprint matches — pin it
          </Button>
        </>}>
          <Typography variant="body2" gutterBottom>
            {String(cfg.host)}:{String(cfg.port || 22)} presented a <strong>{fetched?.key_type}</strong> key:
          </Typography>
          <Typography variant="body1" sx={{ fontFamily: 'monospace', wordBreak: 'break-all', my: 1 }}
                      data-testid="sftp-fetched-fingerprint">
            {fetched?.fingerprint_sha256}
          </Typography>
          <Alert severity="info">
            Compare this fingerprint with the one the server's owner gives you before pinning.
            Pinning the wrong key is exactly what this check exists to prevent.
          </Alert>
      </AppDialog>
    </Stack>
  );
}
