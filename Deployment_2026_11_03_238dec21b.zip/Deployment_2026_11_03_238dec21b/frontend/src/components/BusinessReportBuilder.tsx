/**
 * Phase 56 — Business Report Builder
 *
 * 6-step wizard for creating/editing business reports on top of the semantic layer.
 * Steps: Subject → Columns → Filters → Parameters → Layout → Review & Save
 */
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import {
  Box, Paper, Typography, Stepper, Step, StepLabel, StepButton, Button, TextField,
  Chip, Checkbox, FormControlLabel, FormHelperText, Radio, RadioGroup, Select, MenuItem, InputLabel, FormControl,
  IconButton, Dialog,
  Alert, CircularProgress, Divider, Tooltip, Switch, Grid, Stack,
  Table, TableBody, TableCell, TableHead, TableRow, Autocomplete,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  ArrowBack as ArrowBackIcon,
  ArrowForward as ArrowForwardIcon,
  Save as SaveIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  DragIndicator as DragIcon,
  InfoOutlined as InfoOutlinedIcon,
  PlayArrow as PreviewReportIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  OpenInNew as OpenInNewIcon,
  KeyboardArrowUp as MoveUpIcon,
  KeyboardArrowDown as MoveDownIcon,
} from '@mui/icons-material';
import {
  ParamRow, newParamRow, paramRowsFromServer, paramRowsToBatchItems,
} from './reports/reportAuthoringModel';
import ReportParameterEditor from './reports/ReportParameterEditor';
import {
  DndContext, closestCenter, PointerSensor, useSensor, useSensors,
} from '@dnd-kit/core';
import {
  SortableContext, verticalListSortingStrategy, useSortable, arrayMove,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import api from '../services/api';
import { rowLimitWords } from '../utils/reportViewerMessages';
import { useAuth } from '../context/AuthContext';
import { isAdminLike } from '../utils/reportLifecycle';
import { useServerDraft } from '../hooks/useServerDraft';
import { useRevealError } from '../hooks/useRevealError';
import { REPORTS_PATH, reportPath, startDatasetIdFrom, useResolvedReportId } from '../utils/reportUrls';
import { clickable } from '../utils/clickable';
import ReportFilterValueInput, { changeFilterField } from './reports/ReportFilterValueInput';
import { ASKABLE_OPERATORS, SourceFilter, askedParameter, filterForSave, sourceFilterWords, sourceParameter, unfilledFilterProblems } from '../utils/reportFilters';
import {
  NEW_REPORT_DRAFT_KEY, ReportWizardDraft, draftSourceLabel,
  keepColumnsOf, readWizardDraft,
} from './reports/reportWizardDraft';

// ── Constants ────────────────────────────────────────────────────────────────

const WIZARD_STEPS = ['Subject', 'Columns', 'Filters & Conditions', 'Parameters', 'Layout', 'Review & Save'];

// FIX 5 (Phase 81): Relative date macro options available as default values for date/date_range params
const COLUMN_TYPE_COLORS: Record<string, string> = {
  dimension: '#2196f3',
  measure: '#4caf50',
  detail: '#ff9800',
  kpi: '#e91e63',
};

const FILTER_OPERATORS = [
  { value: 'eq', label: '= Equals' },
  { value: 'neq', label: '!= Not Equals' },
  { value: 'gt', label: '> Greater Than' },
  { value: 'gte', label: '>= Greater or Equal' },
  { value: 'lt', label: '< Less Than' },
  { value: 'lte', label: '<= Less or Equal' },
  { value: 'in', label: 'In List' },
  { value: 'not_in', label: 'Not In List' },
  { value: 'between', label: 'Between' },
  { value: 'like', label: 'Contains (LIKE)' },
  { value: 'not_like', label: 'Not Contains' },
  { value: 'starts_with', label: 'Starts With' },
  { value: 'ends_with', label: 'Ends With' },
  { value: 'is_null', label: 'Is Null' },
  { value: 'is_not_null', label: 'Is Not Null' },
];

// Phase 85D-5: Running calculation types with descriptions for tooltips
const CALC_TYPES = [
  { value: 'running_sum', label: 'Running Sum', description: 'Cumulative sum from first row to current row' },
  { value: 'rank', label: 'Rank', description: 'Row rank by value (1 = highest)' },
  { value: 'percent_of_total', label: '% of Total', description: "This row's value ÷ column total × 100" },
  { value: 'previous_value', label: 'Previous Value', description: 'Value from the previous row for comparison' },
];

// ── Helper types ─────────────────────────────────────────────────────────────

interface FilterEntry {
  column_id: number;
  operator: string;
  value: any;
  value2?: any;
  /** asked when the report runs (saved as a parameter on the column) */
  ask_at_run?: boolean;
}

interface SectionDef {
  name: string;
  break_column_id: number;
  subtotal_measure_ids: number[];
  show_count: boolean;
}

interface RunningCalcDef {
  name: string;
  calc_type: string;
  measure_col_id: number;
  partition_col_id: number | null;
  format_pattern: string;
}


// ── Component ────────────────────────────────────────────────────────────────

const BusinessReportBuilder: React.FC = () => {
  const navigate = useNavigate();
  const { id: editId } = useParams<{ id: string }>();
  const isEdit = !!editId;
  // 2026-09-20 -- editId is the SLUG in the URL; the numeric id is resolved
  // by the route element (ReportIdentityContext) or a numeric param.
  const editReportId = useResolvedReportId();
  // 2026-10-23 -- a NEW report started from a dataset (?dataset_id=N, the
  // dataset screens' "Create report"): that dataset chosen, Columns step.
  const location = useLocation();
  const startDatasetId = isEdit ? null : startDatasetIdFrom(location.search);
  const startAppliedRef = useRef(false);

  // Wizard state
  const [activeStep, setActiveStep] = useState(0);
  // 2026-11-01 -- the one editor (ReportStudioPage) opens a step by name:
  // ?step=parameters / settings (Review & Save) / data (Columns)
  const stepParam = new URLSearchParams(useLocation().search).get('step');
  useEffect(() => {
    if (!stepParam) return;
    const want = stepParam.toLowerCase();
    const i = want === 'settings' ? WIZARD_STEPS.length - 1 : want === 'data' ? 1
      : WIZARD_STEPS.findIndex(n => n.toLowerCase().startsWith(want));
    if (i >= 0) setActiveStep(i);
  }, [stepParam]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  // a refusal on Save (bottom of the page) must be SEEN (the Alert is at the top)
  const errorRef = useRevealError(error);
  const [loading, setLoading] = useState(false);

  // Step 0: Subject
  const [dataSourceType, setDataSourceType] = useState<'saved_query' | 'published_view'>('saved_query');
  const [datasets, setDatasets] = useState<any[]>([]);
  const [selectedDatasetId, setSelectedDatasetId] = useState<number | null>(null);
  // 2026-10-24 -- a SECOND dataset whose same-named columns are stacked under
  // the first (UNION ALL, e.g. the same table on cloud and on-prem).  Stored
  // as merged_dataset_id + merge_config {merge_type: 'union'}; the server maps
  // the columns and the filters by name (core/reports/union_of_datasets.py).
  const [unionDatasetId, setUnionDatasetId] = useState<number | null>(null);
  // a report merged by a JOIN (API-made) is kept exactly as it is
  const [keptJoinMerge, setKeptJoinMerge] = useState(false);
  const [unionOpen, setUnionOpen] = useState(false);
  const [dataset, setDataset] = useState<any>(null);
  // 2026-10-29 -- the conditions of the dataset's own SQL WHERE ("Filter at
  // the source", backend core/source_filters.py) and the ones ticked to be
  // asked when the report runs (saved as parameters bound to the condition)
  const [sourceFilters, setSourceFilters] = useState<SourceFilter[]>([]);
  const [sourceFiltersNote, setSourceFiltersNote] = useState('');
  const [askedSource, setAskedSource] = useState<string[]>([]);
  const [publishedViews, setPublishedViews] = useState<any[]>([]);
  const [selectedPvId, setSelectedPvId] = useState<number | null>(null);

  // Step 1: Columns
  const [allColumns, setAllColumns] = useState<any[]>([]);
  const [allClasses, setAllClasses] = useState<any[]>([]);
  const [selectedColumnIds, setSelectedColumnIds] = useState<number[]>([]);
  const [columnSearch, setColumnSearch] = useState('');

  // Step 2: Filters & Conditions
  const [filters, setFilters] = useState<FilterEntry[]>([]);
  const [conditions, setConditions] = useState<any[]>([]);
  const [selectedConditionIds, setSelectedConditionIds] = useState<number[]>([]);
  const [orderBy, setOrderBy] = useState<Array<{ column_id: number; direction: string }>>([]);
  // 2026-10-24 -- null = no limit of its own (the server's ceiling applies).
  const [rowLimit, setRowLimit] = useState<number | null>(null);
  const [rowCeiling, setRowCeiling] = useState<number | null>(null);
  useEffect(() => {
    api.getReportLimits().then((l: any) => setRowCeiling(l?.default_row_limit ?? null));
  }, []);
  // Phase 2 instance layer (2026-08-09) — BO "Refresh When Open" parity.
  // false (default) = opening the report may serve the latest saved result
  // instantly (with a "Data as of" banner + Refresh); true = every open
  // runs a fresh query against the source.
  const [refreshOnOpen, setRefreshOnOpen] = useState(false);

  // Step 3: Parameters
  const [params, setParams] = useState<ParamRow[]>([]);
  // 2026-08-31 -- partition columns of the selected dataset, and whether
  // detection could answer at all.  `detected === false` means "could not
  // tell", which is a different fact from "there are none" and must not be
  // rendered as if the source were unpartitioned.
  const [partitionCols, setPartitionCols] = useState<any[]>([]);
  const [partitionDetected, setPartitionDetected] = useState<boolean | null>(null);
  const [partitionWarnings, setPartitionWarnings] = useState<string[]>([]);

  // Step 4: Layout
  const [sections, setSections] = useState<SectionDef[]>([]);
  const [runningCalcs, setRunningCalcs] = useState<RunningCalcDef[]>([]);
  const [slicerColumnIds, setSlicerColumnIds] = useState<number[]>([]);
  const [hierarchies, setHierarchies] = useState<any[]>([]);
  const [drillHierarchyId, setDrillHierarchyId] = useState<number | null>(null);

  // Step 4c: Chart view (2026-08-09) — the report's saved visualisation.
  // Stored in layout_config.chart_config (same JSON home as pivot_config /
  // style_config — no schema change) and rendered by the viewer through the
  // server microcube, so the chart obeys the same correctness gates as the
  // table (non-additive 422, truncation disclosure).
  const [chartEnabled, setChartEnabled] = useState(false);
  const [chartType, setChartType] = useState<string>('bar');
  const [chartDimensionId, setChartDimensionId] = useState<number | ''>('');
  const [chartSplitId, setChartSplitId] = useState<number | ''>('');
  const [chartMeasureIds, setChartMeasureIds] = useState<number[]>([]);
  const [chartLineMeasureIds, setChartLineMeasureIds] = useState<number[]>([]);
  const [chartSecondaryAxis, setChartSecondaryAxis] = useState(false);
  const [chartKpiComparisonId, setChartKpiComparisonId] = useState<number | ''>('');
  const [chartDefaultView, setChartDefaultView] = useState<'table' | 'chart' | 'both'>('table');

  // Step 4b: Report Style
  const [styleConfig, setStyleConfig] = useState({
    header_bg: '#1976D2',
    header_text: '#FFFFFF',
    accent_color: '#1565C0',
    negative_format: 'brackets' as 'brackets' | 'minus' | 'red',
    stripe_rows: true,
    subtotal_bg: '#F5F5F5',
    grand_total_bg: '#E8EAF6',
  });
  const updateStyle = (key: string, value: any) =>
    setStyleConfig(prev => ({ ...prev, [key]: value }));

  // Preserved layout_config from existing report (edit mode) — merged on save
  const [existingLayoutConfig, setExistingLayoutConfig] = useState<Record<string, any>>({});

  // Step 5: Review.
  const [reportName, setReportName] = useState('');
  const [reportDescription, setReportDescription] = useState('');

  // Phase 142 persistence -- a half-built NEW report survives a refresh.
  // 2026-10-03: ONE draft, bound to its data source, OFFERED never applied,
  // untouched while editing, deleted on create (see reportWizardDraft.ts --
  // the old global name draft pre-filled every new report with a stale name).
  const [storedDraft, setStoredDraft, draftMeta] =
    useServerDraft<ReportWizardDraft | null>(NEW_REPORT_DRAFT_KEY, null, { disabled: isEdit });
  // 'pending' until the stored draft (if any) is resumed or discarded; the
  // draft is not overwritten while the offer is open.
  const [draftDecision, setDraftDecision] = useState<'pending' | 'offered' | 'decided'>(
    isEdit ? 'decided' : 'pending');
  const [draftOffer, setDraftOffer] = useState<ReportWizardDraft | null>(null);
  const [draftNotice, setDraftNotice] = useState('');
  const resumeRef = useRef<ReportWizardDraft | null>(null);
  const savedRef = useRef(false);
  // Phase 131 deep-dive #12 — group-based ownership (entitlement parity
  // with Report / FeedConfig / PublishedView).  Picker on Review step;
  // null = single-owner only (legacy behaviour preserved).
  const [ownerGroupId, setOwnerGroupId] = useState<number | ''>('');
  const [userGroups, setUserGroups] = useState<Array<{id: number; name: string; description?: string|null}>>([]);
  // 2026-09-24 -- GET /api/admin/user-groups is ``require_admin``; only an
  // admin asks for the list (see the effect below and the picker's text).
  const { user: authUser } = useAuth();
  const canListGroups = isAdminLike(authUser);

  // Phase 85D-6: Preview report in review step
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [previewCols, setPreviewCols] = useState<string[]>([]);
  const [previewError, setPreviewError] = useState('');

  // ── Load datasets on mount ────────────────────────────────────────────────

  useEffect(() => {
    // 2026-08-31 -- do NOT re-filter by is_published here.  /api/datasets is
    // already scoped to what this user may see, and the backend imposes no
    // publication requirement on a report's dataset, so this client-side
    // filter was a restriction that existed nowhere else: a user created a
    // dataset, UnifiedReportBuilder counted it and let them in, and then this
    // screen said "ask an admin to publish a dataset first".  A dead end
    // built out of two screens disagreeing about the same rule.
    api.listDatasets().then((data: any) => {
      setDatasets(Array.isArray(data) ? data : []);
    }).catch(() => setError(
      'Could not load datasets. This is a load failure, not an empty list — '
      + 'retry, and check you still have access to them.'));
    // Phase 100: load published views for PV data source option
    api.listPublishedViews().then((data: any) => {
      const active = (Array.isArray(data) ? data : []).filter((v: any) => v.is_active);
      setPublishedViews(active);
    }).catch(() => {});
    // Phase 131 deep-dive #12 — load user groups for the ownership
    // picker.  Same admin endpoint used by FeedConfigsPage.
    // 2026-09-24: ``require_admin`` -- found in passing while fixing the
    // same class on /feeds.  Only an admin asks; for anyone else the list
    // is unknown (not empty) and the picker's helper text says so.
    if (canListGroups) {
      (api as any).listUserGroups?.({ is_active: true })
        .then((groups: any) => setUserGroups(Array.isArray(groups) ? groups : []))
        .catch(() => setUserGroups([]));
    }
  }, [canListGroups]);

  // ── Load existing report for editing ──────────────────────────────────────

  useEffect(() => {
    if (!editId) return;
    setLoading(true);
    api.getBusinessReport(editReportId).then((report: any) => {
      // Phase 100: restore data source type and PV selection
      if (report.data_source_type === 'published_view') {
        setDataSourceType('published_view');
        setSelectedPvId(report.published_view_id || null);
      }
      setSelectedDatasetId(report.dataset_id);
      if (report.merged_dataset_id && String(report.merge_config?.merge_type || '').toLowerCase() === 'union') {
        setUnionDatasetId(report.merged_dataset_id);
      } else if (report.merged_dataset_id) {
        setKeptJoinMerge(true);
      }
      setSelectedColumnIds(report.column_ids || []);
      setFilters(report.filter_specs || []);
      setSelectedConditionIds(report.condition_ids || []);
      setOrderBy(report.order_by || []);
      // 2026-10-24 -- by PRESENCE: 0 (every row) used to read back as 50,000
      // and be saved over the author's choice.
      setRowLimit(report.row_limit ?? null);
      setRefreshOnOpen(Boolean(report.refresh_on_open));
      setSections(report.section_definitions || []);
      setRunningCalcs(report.running_calculations || []);
      setSlicerColumnIds(report.slicer_column_ids || []);
      setDrillHierarchyId(report.drill_hierarchy_id);
      // Preserve full layout_config for merge on save (keeps column_order, report_type, etc.)
      if (report.layout_config) setExistingLayoutConfig(report.layout_config);
      const sc = report.layout_config?.style_config;
      if (sc) setStyleConfig(prev => ({ ...prev, ...sc }));
      // Hydrate the saved chart view (defensive — garbage means "no chart")
      const cc = report.layout_config?.chart_config;
      if (cc && typeof cc === 'object' && cc.enabled !== false && cc.chart_type) {
        setChartEnabled(true);
        setChartType(String(cc.chart_type));
        setChartDimensionId(cc.dimension_col_id ?? '');
        setChartSplitId(cc.split_col_id ?? '');
        setChartMeasureIds(Array.isArray(cc.measure_col_ids) ? cc.measure_col_ids : []);
        setChartLineMeasureIds(Array.isArray(cc.line_measure_col_ids) ? cc.line_measure_col_ids : []);
        setChartSecondaryAxis(cc.secondary_axis === true);
        setChartKpiComparisonId(cc.kpi_comparison_col_id ?? '');
        setChartDefaultView(cc.default_view === 'chart' || cc.default_view === 'both' ? cc.default_view : 'table');
      }
      setReportName(report.name || '');
      setReportDescription(report.description || '');
      // Phase 131 deep-dive #12 — hydrate group ownership on edit.
      setOwnerGroupId((report.owner_group_id ?? '') || '');
      if (report.parameters) {
        setParams(paramRowsFromServer(report.parameters));
      }
    }).catch(() => setError('Failed to load report'))
      .finally(() => setLoading(false));
  }, [editId]);

  // ── Partition columns: the predicate the report must always carry ─────────
  //
  // 2026-08-31.  A report that runs with no predicate on the partition column
  // reads the whole table.  Published views already prevent that -- their
  // publish dialog turns detected partition columns into REQUIRED params, so
  // the view cannot be opened without a fixed WHERE clause -- and feed configs
  // carry the same idea.  Business reports had no equivalent, so the same
  // query behind a report scanned everything.
  //
  // Enforcement is deliberately the REQUIRED PARAMETER, not a new refusal:
  // the execution path already rejects a run whose required parameter has no
  // value ("Required parameter(s) missing"), so seeding one here makes the
  // partition predicate unavoidable through every path at once -- execute,
  // exports, schedules and shared links -- with no second gate to keep in
  // step with the first.
  useEffect(() => {
    if (!selectedDatasetId) {
      setPartitionCols([]); setPartitionDetected(null); setPartitionWarnings([]);
      return;
    }
    let cancelled = false;
    (api as any).getDatasetPartitionColumns(selectedDatasetId)
      .then((res: any) => {
        if (cancelled) return;
        const cols = Array.isArray(res?.partition_columns) ? res.partition_columns : [];
        setPartitionCols(cols);
        setPartitionDetected(res?.detected === true);
        setPartitionWarnings(Array.isArray(res?.warnings) ? res.warnings : []);
        if (!cols.length) return;
        // Seed one required prompt per partition column, but never clobber
        // what the author already has: an existing parameter on the same
        // column is theirs, including its default and its label.
        setParams(prev => {
          const bound = new Set(prev.map(p => p.lov_column_id));
          const add = cols
            .filter((c: any) => !bound.has(c.column_id))
            .map((c: any) => ({
              ...newParamRow(),
              // a partition prompt stays REQUIRED (the whole-table guard above)
              is_required: true,
              name: `p_${c.name}`,
              label: c.friendly_name || c.name,
              parameter_type: (c.data_type === 'date' ? 'date' : 'text'),
              // a partition DATE takes any day on a calendar (2026-10-29)
              values_source: (c.data_type === 'date' ? 'any' : 'auto'),
              lov_column_id: c.column_id,
              description: `${c.friendly_name || c.name} partitions the source. `
                + 'Every run must supply it, so the report reads one partition '
                + 'instead of the whole table.',
            }));
          return add.length ? [...prev, ...add] : prev;
        });
      })
      .catch(() => {
        if (cancelled) return;
        // Fail OPEN for authoring, but do NOT report "no partitions".
        setPartitionCols([]); setPartitionDetected(false);
        setPartitionWarnings(['Partition columns could not be determined, so '
          + 'this report will not be forced to filter on one.']);
      });
    return () => { cancelled = true; };
  }, [selectedDatasetId]);

  // ── Load dataset detail when selected ─────────────────────────────────────

  useEffect(() => {
    if (!selectedDatasetId) return;
    let cancelled = false;
    const apply = (ds: any) => {
      if (cancelled) return;
      setDataset(ds);
      setAllColumns(ds.columns || []);
      // the dataset's own conditions a report may open up (a table dataset
      // or a query with no WHERE SAYS so; a failed read says so too)
      api.getDatasetSourceFilters(ds.id)
        .then((r: any) => {
          if (cancelled) return;
          setSourceFilters((r?.filters || []).filter((f: any) => f.offered));
          setSourceFiltersNote(r?.reason || '');
        })
        .catch((e: any) => { if (!cancelled) { setSourceFilters([]); setSourceFiltersNote(e?.message || 'The conditions of the dataset\'s query could not be read.'); } });
      setAllClasses(ds.classes || []);
      setConditions(ds.conditions || []);
      setHierarchies(ds.hierarchies || []);
      // A RESUMED draft's selections land only now, checked against the
      // dataset's CURRENT columns -- an id it no longer has never survives.
      const pending = resumeRef.current;
      if (pending && pending.source.dataset_id === selectedDatasetId) {
        resumeRef.current = null;
        const kept = keepColumnsOf(
          pending, new Set((ds.columns || []).map((c: any) => Number(c.id))));
        const condIds = new Set((ds.conditions || []).map((c: any) => Number(c.id)));
        setSelectedColumnIds(kept.column_ids);
        setFilters(kept.filters);
        setOrderBy(kept.order_by);
        setSections(kept.sections);
        setSelectedConditionIds(pending.condition_ids.filter(id => condIds.has(id)));
        setDraftNotice(kept.dropped.length
          ? `Resumed your draft. ${kept.dropped.length} column(s) it used are no longer `
            + `on this dataset and were left out (column id ${kept.dropped.join(', ')}).`
          : 'Resumed your draft.');
        setDraftDecision('decided');
      }
    };
    api.getDataset(selectedDatasetId).then(async (ds: any) => {
      // 2026-08-31 -- a dataset with ZERO columns used to render as an empty
      // Columns step and, worse, an empty column dropdown in the Filters
      // step, which is why authors ended up typing column names by hand.
      // An empty list here nearly always means "nobody ever detected them",
      // not "this dataset has none" -- several creation paths leave columns
      // empty when the source was unreachable at the time.
      //
      // Auto-detect now reads the dataset's own SQL (sqlglot, no source
      // round-trip), so recovery is cheap and works even while the source
      // is still down.  Try it once, then re-read.  If it cannot help
      // (SELECT *, or a table-sourced dataset), SAY so with the reason
      // rather than presenting an empty picker as if it were the answer.
      if (!ds?.columns?.length) {
        try {
          const res: any = await (api as any).autoDetectColumns(selectedDatasetId);
          if (res?.created > 0) {
            const healed = await api.getDataset(selectedDatasetId);
            apply(healed);
            return;
          }
        } catch (e: any) {
          if (!cancelled) {
            setError('This dataset has no columns yet, and they could not be '
              + 'detected automatically: '
              + (e?.message || 'the source could not be read')
              + '. Open it in Dataset Manager and add columns, or fix the '
              + 'source and retry.');
          }
        }
      }
      apply(ds);
    }).catch((e: any) => {
      if (cancelled) return;
      if (resumeRef.current?.source.dataset_id === selectedDatasetId) {
        // The draft's dataset cannot be read: nothing of it is applied.
        resumeRef.current = null;
        setDraftDecision('decided');
      }
      // 2026-09-25 (analyst crawl): a dataset that EXISTS but is not shared
      // with this author answered 403, and the page said "check if the
      // dataset still exists" -- sending them to look for a deletion.
      const status = e?.status;
      if (status === 403) {
        setError('This report is built on a dataset that is not shared with you, so it cannot be '
          + 'edited here. Ask the dataset’s owner to publish or share it. The report itself still runs.');
      } else if (status === 404) {
        setError('This report’s dataset no longer exists. Choose another data source below.');
      } else {
        setError(`The dataset’s columns could not be loaded: ${e?.message || 'unknown error'}`);
      }
    });
    return () => { cancelled = true; };
  }, [selectedDatasetId]);

  // ── The new-report draft: offered, bound to its source ───────────────────

  useEffect(() => {
    if (isEdit || draftDecision !== 'pending' || draftMeta.loading) return;
    const d = readWizardDraft(storedDraft);
    // Started from a dataset: a draft on ANOTHER source is not offered -- the
    // author asked for a report on this dataset (a draft on it still is).
    if (d && startDatasetId != null
        && !(d.source.type === 'saved_query' && d.source.dataset_id === startDatasetId)) {
      setDraftDecision('decided');
      return;
    }
    if (d) {
      setDraftOffer(d);
      setDraftDecision('offered');
    } else {
      setDraftDecision('decided');
    }
  }, [isEdit, draftDecision, draftMeta.loading, storedDraft, startDatasetId]);

  useEffect(() => {
    if (startDatasetId == null || startAppliedRef.current) return;
    startAppliedRef.current = true;
    setDataSourceType('saved_query');
    setSelectedDatasetId(startDatasetId);
    setActiveStep(1);
  }, [startDatasetId]);

  const wizardSnapshot = useMemo<ReportWizardDraft | null>(() => {
    const source = {
      type: dataSourceType,
      dataset_id: dataSourceType === 'saved_query' ? selectedDatasetId : null,
      published_view_id: dataSourceType === 'published_view' ? selectedPvId : null,
    };
    if (source.type === 'saved_query' ? !source.dataset_id : !source.published_view_id) {
      return null;
    }
    return {
      v: 1, source, name: reportName, description: reportDescription,
      column_ids: selectedColumnIds, filters, condition_ids: selectedConditionIds,
      order_by: orderBy, sections,
    };
  }, [dataSourceType, selectedDatasetId, selectedPvId, reportName, reportDescription,
      selectedColumnIds, filters, selectedConditionIds, orderBy, sections]);

  useEffect(() => {
    // Written only once the stored one is resumed or discarded (and never
    // while editing, nor after the report was created).
    if (isEdit || draftDecision !== 'decided' || savedRef.current) return;
    setStoredDraft(wizardSnapshot);
  }, [isEdit, draftDecision, wizardSnapshot, setStoredDraft]);

  const discardDraft = () => {
    setDraftOffer(null);
    setDraftDecision('decided');
    draftMeta.reset();
  };

  const resumeDraft = () => {
    const d = draftOffer;
    if (!d) return;
    setDraftOffer(null);
    setReportName(d.name);
    setReportDescription(d.description);
    if (d.source.type === 'published_view') {
      setDataSourceType('published_view');
      setSelectedPvId(d.source.published_view_id);
      setDraftNotice('Resumed your draft.');
      setDraftDecision('decided');
    } else {
      setDataSourceType('saved_query');
      // the selections land when the dataset's columns do (see apply above)
      resumeRef.current = d;
      setSelectedDatasetId(d.source.dataset_id);
    }
  };

  /** Everything picked FROM a dataset's columns.  Another dataset's column
   *  ids must never ride into a report on this one (the server refuses
   *  them with 422, but the author should not get that far). */
  const clearDatasetSelections = () => {
    setAllColumns([]); setDataset(null);
    setSelectedColumnIds([]); setFilters([]); setSelectedConditionIds([]);
    setOrderBy([]); setSections([]); setRunningCalcs([]);
    setSlicerColumnIds([]); setDrillHierarchyId(null);
    setChartEnabled(false); setChartDimensionId(''); setChartSplitId('');
    setChartMeasureIds([]); setChartLineMeasureIds([]); setChartKpiComparisonId('');
    setParams([]);
  };

  const chooseDataset = (id: number) => {
    if (draftDecision === 'offered') discardDraft();
    if (id !== selectedDatasetId) clearDatasetSelections();
    if (id === unionDatasetId) setUnionDatasetId(null);
    setSelectedDatasetId(id);
  };

  // ── Column helpers ────────────────────────────────────────────────────────

  const dimensions = allColumns.filter((c: any) => c.column_type === 'dimension');
  const measures = allColumns.filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi');
  const selectedCols = allColumns.filter((c: any) => selectedColumnIds.includes(c.id));
  const selectedDims = selectedCols.filter((c: any) => c.column_type === 'dimension');
  const selectedMeasures = selectedCols.filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi');

  const getColName = (colId: number) => {
    const col = allColumns.find((c: any) => c.id === colId);
    return col ? (col.friendly_name || col.physical_name) : `Col #${colId}`;
  };

  // ── Toggle column selection ───────────────────────────────────────────────

  const toggleColumn = (colId: number) => {
    setSelectedColumnIds(prev =>
      prev.includes(colId) ? prev.filter(id => id !== colId) : [...prev, colId]
    );
  };

  // ── Filter management ─────────────────────────────────────────────────────

  const addFilter = () => {
    if (allColumns.length === 0) return;
    setFilters(prev => [...prev, { column_id: allColumns[0].id, operator: 'eq', value: '' }]);
  };

  // A new column or a change of operand kind drops the value
  // (ReportFilterValueInput.changeFilterField).
  const updateFilter = (idx: number, field: string, val: any) => {
    setFilters(prev => prev.map((f, i) => (i === idx ? changeFilterField(f, field, val) : f)));
  };

  // 2026-10-03 -- an unfilled row is not a filter; it is never submitted.
  const filterProblems = unfilledFilterProblems(filters, allColumns);

  const removeFilter = (idx: number) => {
    setFilters(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Parameter management ──────────────────────────────────────────────────

  // ── Section management ────────────────────────────────────────────────────

  const addSection = () => {
    if (selectedDims.length === 0) return;
    setSections(prev => [...prev, {
      name: `Section ${prev.length + 1}`,
      break_column_id: selectedDims[0].id,
      subtotal_measure_ids: [],
      show_count: true,
    }]);
  };

  const updateSection = (idx: number, field: string, val: any) => {
    setSections(prev => prev.map((s, i) => i === idx ? { ...s, [field]: val } : s));
  };

  const removeSection = (idx: number) => {
    setSections(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Running calc management ───────────────────────────────────────────────

  const addRunningCalc = () => {
    if (selectedMeasures.length === 0) return;
    setRunningCalcs(prev => [...prev, {
      name: `Calc ${prev.length + 1}`,
      calc_type: 'running_sum',
      measure_col_id: selectedMeasures[0].id,
      partition_col_id: null,
      format_pattern: '',
    }]);
  };

  const updateCalc = (idx: number, field: string, val: any) => {
    setRunningCalcs(prev => prev.map((c, i) => i === idx ? { ...c, [field]: val } : c));
  };

  const removeCalc = (idx: number) => {
    setRunningCalcs(prev => prev.filter((_, i) => i !== idx));
  };

  // ── Save report ───────────────────────────────────────────────────────────

  const handleSave = async () => {
    // 2026-10-25 -- an "ask when the report runs" row is a PARAMETER on its
    // column (one per column: a parameter already bound to it is kept)
    const askedRows = filters.filter(f => f.ask_at_run);
    const keptFilters = filters.filter(f => !f.ask_at_run);
    const bound = new Set(params.map(p => p.lov_column_id));
    const paramsToSave = [...params];
    for (const f of askedRows) {
      if (bound.has(f.column_id)) continue;
      bound.add(f.column_id);
      const a = askedParameter(f, allColumns.find((c: any) => c.id === f.column_id));
      paramsToSave.push({ ...newParamRow(), ...a, is_required: false });
    }
    // 2026-10-29 -- a ticked "Filter at the source" condition is a PARAMETER
    // bound to that condition of the dataset's query (one per condition)
    const boundSource = new Set(params.map(p => p.source_column).filter(Boolean));
    for (const key of askedSource) {
      const sf = sourceFilters.find(f => f.key === key);
      if (!sf || boundSource.has(key)) continue;
      boundSource.add(key);
      paramsToSave.push({ ...newParamRow(), ...sourceParameter(sf) });
    }
    if (!reportName.trim()) {
      setError('Report name is required');
      return;
    }
    // Phase 100: for PV source, skip dataset/column validation
    if (dataSourceType === 'saved_query') {
      if (!selectedDatasetId) {
        setError('Please select a dataset');
        return;
      }
      if (selectedColumnIds.length === 0) {
        setError('Please select at least one column');
        return;
      }
    } else if (dataSourceType === 'published_view') {
      if (!selectedPvId) {
        setError('Please select a published view');
        return;
      }
    }
    // 2026-10-03 -- never submit an unfilled filter row (the owner's report
    // saved `REGION = ''` and returned 0 rows); say which row instead.
    if (filterProblems.length) {
      setError(filterProblems.join(' '));
      return;
    }

    setSaving(true);
    setError('');

    // Assemble layout_config: merge preserved keys, then set/remove the
    // chart view.  Disabling the chart REMOVES the key (a stale config must
    // not resurrect later).
    const layoutConfig: Record<string, any> = {
      ...existingLayoutConfig, style_config: styleConfig,
    };
    if (chartEnabled && chartMeasureIds.length > 0) {
      layoutConfig.chart_config = {
        enabled: true,
        chart_type: chartType,
        dimension_col_id: chartDimensionId === '' ? null : Number(chartDimensionId),
        split_col_id: chartSplitId === '' ? null : Number(chartSplitId),
        measure_col_ids: chartMeasureIds,
        line_measure_col_ids: chartType === 'combo' ? chartLineMeasureIds : [],
        secondary_axis: chartType === 'combo' ? chartSecondaryAxis : false,
        kpi_comparison_col_id:
          chartType === 'kpi' && chartKpiComparisonId !== '' ? Number(chartKpiComparisonId) : null,
        default_view: chartDefaultView,
      };
    } else {
      delete layoutConfig.chart_config;
    }

    const data: any = {
      name: reportName.trim(),
      description: reportDescription.trim(),
      dataset_id: selectedDatasetId || 0,
      data_source_type: dataSourceType,
      published_view_id: dataSourceType === 'published_view' ? selectedPvId : null,
      column_ids: selectedColumnIds,
      filter_specs: keptFilters.map(f => filterForSave(f)),
      condition_ids: selectedConditionIds,
      order_by: orderBy,
      row_limit: rowLimit,
      refresh_on_open: refreshOnOpen,
      section_definitions: sections,
      running_calculations: runningCalcs,
      slicer_column_ids: slicerColumnIds,
      drill_hierarchy_id: drillHierarchyId,
      layout_config: layoutConfig,
      // Phase 131 deep-dive #12 — group ownership.  null clears it.
      owner_group_id: ownerGroupId === '' ? null : Number(ownerGroupId),
    };
    if (!keptJoinMerge && dataSourceType === 'saved_query') {
      data.merged_dataset_id = unionDatasetId;
      data.merge_config = unionDatasetId ? { merge_type: 'union' } : null;
    }

    try {
      let report: any;
      if (isEdit) {
        report = await api.updateBusinessReport(editReportId, data);
      } else {
        report = await api.createBusinessReport(data);
      }

      // Save parameters in ONE atomic call.
      //
      // 2026-09-03 -- this was two passes: batch-create, then PUT each
      // cascading child with its parent's freshly-minted id, resolved
      // through a map keyed by BOTH old ids and array indices.  Those are
      // two namespaces in one dict and they collided: ids start at 1 and
      // indices at 0, so for any report whose parameters were created
      // together -- every report -- the index keys were overwritten and
      // the third parameter resolved its parent to ITSELF.  A parameter
      // that depends on itself filters its own dropdown by its own unset
      // value, which is exactly what "cascading prompts don't work"
      // looked like.  The second pass also broke the atomicity the batch
      // endpoint exists to provide: a failure between the two left the
      // parameters saved and the cascade unlinked.
      //
      // The parent now travels as a POSITION and the backend resolves it
      // inside the transaction that mints the ids.
      if (report && report.id) {
        await api.batchSaveBusinessReportParams(
          report.id, paramRowsToBatchItems(paramsToSave));
        // what the author sees next is what was saved: the asked rows are
        // the report's parameters now
        if (askedRows.length) { setFilters(keptFilters); setParams(paramsToSave); }
        if (!isEdit) {
          // The draft became a report: it must never pre-fill the next one.
          savedRef.current = true;
          draftMeta.reset();
        }
        navigate(reportPath(report));
      }
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Failed to save report');
    } finally {
      setSaving(false);
    }
  };

  // ── Step validation ───────────────────────────────────────────────────────

  const canProceed = (step: number): boolean => {
    switch (step) {
      case 0: return dataSourceType === 'published_view' ? selectedPvId !== null : (selectedDatasetId !== null && selectedDatasetId > 0);
      case 1: return dataSourceType === 'published_view' || selectedColumnIds.length > 0;
      case 2: return filterProblems.length === 0;
      case 5: return reportName.trim().length > 0 && filterProblems.length === 0;
      default: return true;
    }
  };

  const proceedHint = (step: number): string => {
    switch (step) {
      case 0:
        if (dataSourceType === 'published_view') return selectedPvId === null ? 'Select a published view to continue' : '';
        return selectedDatasetId === null ? 'Select a data source to continue' : '';
      case 1: return dataSourceType !== 'published_view' && selectedColumnIds.length === 0 ? 'Select at least one column' : '';
      case 2: return filterProblems.join(' ');
      case 5: return reportName.trim().length === 0 ? 'Enter a report name to save' : filterProblems.join(' ');
      default: return '';
    }
  };

  // ── Render steps ──────────────────────────────────────────────────────────

  const renderStep0_Subject = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Select Data Source</Typography>

      {/* Phase 100: Data source type selector */}
      <RadioGroup row value={dataSourceType}
        onChange={e => {
          const newType = e.target.value as 'saved_query' | 'published_view';
          if (draftDecision === 'offered') discardDraft();
          setDataSourceType(newType);
          if (newType === 'published_view') {
            setSelectedDatasetId(null);
            clearDatasetSelections();
          } else {
            setSelectedPvId(null);
          }
        }}
        sx={{ mb: 2 }}>
        <FormControlLabel value="saved_query" control={<Radio size="small" />} label="Dataset (Query)" />
        <FormControlLabel value="published_view" control={<Radio size="small" />} label="Published View (Cached API)" />
      </RadioGroup>

      {dataSourceType === 'saved_query' ? (
        <>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Choose a dataset as the data source for your report.
          </Typography>
          {datasets.length === 0 ? (
            <Alert severity="info">No datasets available yet. Create one from a saved query,
              or ask an admin to share one with you.</Alert>
          ) : (
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
              {datasets.map((ds: any) => (
                <Paper
                  key={ds.id}
                  elevation={selectedDatasetId === ds.id ? 4 : 1}
                  sx={{
                    p: 2, cursor: 'pointer',
                    border: selectedDatasetId === ds.id ? '2px solid #1976d2' : '2px solid transparent',
                    '&:hover': { bgcolor: 'action.hover' },
                  }}
                  {...clickable(() => chooseDataset(ds.id), { label: ds.name, pressed: selectedDatasetId === ds.id })}
                >
                  <Box sx={{ display: 'flex', alignItems: 'flex-start',
                             justifyContent: 'space-between', gap: 1 }}>
                    <Box sx={{ minWidth: 0 }}>
                      <Typography variant="subtitle1" fontWeight="bold">{ds.name}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {ds.description || 'No description'} — {ds.subject || 'General'}
                      </Typography>
                    </Box>
                    {/* 2026-09-03 — a report author looking at a dataset that
                        returns nothing, or whose columns are wrong, had NO way
                        to reach it: "view query" and "modify dataset" both live
                        in Dataset Manager and nothing linked there.  Opens in a
                        NEW TAB deliberately — this builder holds unsaved report
                        state, and navigating away to inspect a dataset would
                        discard it. */}
                    <Tooltip title="Open this dataset in a new tab — view its query, columns and source">
                      <IconButton
                        size="small"
                        aria-label={`Open dataset ${ds.name}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open(`/datasets?dataset=${ds.id}&tab=0`,
                                      '_blank', 'noopener');
                        }}
                      >
                        <OpenInNewIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </Paper>
              ))}
            </Box>
          )}
          {selectedDatasetId && !keptJoinMerge && !unionOpen && unionDatasetId == null && (
            <Button size="small" sx={{ mt: 1.5 }} data-testid="br-union-open" onClick={() => setUnionOpen(true)}>
              + Stack a second dataset under it (UNION ALL)
            </Button>
          )}
          {selectedDatasetId && !keptJoinMerge && (unionOpen || unionDatasetId != null) && (
            <Paper variant="outlined" sx={{ p: 2, mt: 2 }} data-testid="br-union-section">
              <Typography variant="subtitle2">Stack a second dataset under it (UNION ALL)</Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                For the same data on another connection (e.g. cloud and on-prem): every column you pick
                is read from both datasets by its name, your filters are applied to each, and totals are
                computed over both.
              </Typography>
              <TextField select size="small" label="Second dataset" sx={{ minWidth: 320 }}
                         value={unionDatasetId ?? ''}
                         onChange={e => setUnionDatasetId(e.target.value === '' ? null : Number(e.target.value))}
                         SelectProps={{ native: true }} InputLabelProps={{ shrink: true }}
                         inputProps={{ 'data-testid': 'br-union-dataset' }}>
                <option value="">None -- this dataset only</option>
                {datasets.filter((d: any) => d.id !== selectedDatasetId).map((d: any) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </TextField>
            </Paper>
          )}
          {keptJoinMerge && (
            <Alert severity="info" sx={{ mt: 2 }}>
              This report JOINS a second dataset (set through the API); that setting is kept as it is.
            </Alert>
          )}
        </>
      ) : (
        <>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Choose a Published View. Reports using Published Views benefit from 8-hour cache, ETag support, and shared data across reports.
          </Typography>
          {publishedViews.length === 0 ? (
            <Alert severity="info">No active published views available.</Alert>
          ) : (
            <Autocomplete
              options={publishedViews}
              getOptionLabel={(v: any) => `${v.name} (${v.slug})`}
              value={publishedViews.find((v: any) => v.id === selectedPvId) || null}
              onChange={(_e, val) => {
                if (draftDecision === 'offered') discardDraft();
                setSelectedPvId(val ? val.id : null);
              }}
              renderInput={(params) => <TextField {...params} label="Published View" placeholder="Search by name or slug..." />}
              sx={{ maxWidth: 500 }}
            />
          )}
          {selectedPvId && (
            <Alert severity="success" sx={{ mt: 2 }}>
              Published View selected. Columns and filters will be controlled by the view configuration.
              You can still add report parameters to pass to the view.
            </Alert>
          )}
        </>
      )}
    </Box>
  );

  // DnD sensors for column reorder
  const dndSensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  // 2026-10-29 (owner: "how to change order of columns in report") -- drag
  // was the only way; every row also moves up / down by a button.
  const moveColumn = (colId: number, by: number) => setSelectedColumnIds(prev => {
    const i = prev.indexOf(colId);
    const j = i + by;
    return i < 0 || j < 0 || j >= prev.length ? prev : arrayMove(prev, i, j);
  });

  // Sortable column item for the reorder list
  const SortableColumnItem: React.FC<{ colId: number }> = ({ colId }) => {
    const col = allColumns.find((c: any) => c.id === colId);
    const pos = selectedColumnIds.indexOf(colId);
    const name = col?.friendly_name || col?.physical_name || `Col #${colId}`;
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: String(colId) });
    return (
      <Box ref={setNodeRef}
        sx={{
          display: 'flex', alignItems: 'center', gap: 1, px: 1, py: 0.5,
          bgcolor: isDragging ? 'action.hover' : 'background.paper',
          border: '1px solid', borderColor: 'divider', borderRadius: 1,
          opacity: isDragging ? 0.5 : 1,
          transform: CSS.Transform.toString(transform), transition,
        }}
        {...attributes}
      >
        <Box {...listeners} sx={{ cursor: 'grab', display: 'flex', color: 'text.secondary' }}>
          <DragIcon fontSize="small" />
        </Box>
        <Chip size="small" label={col?.column_type || '?'}
          sx={{ bgcolor: COLUMN_TYPE_COLORS[col?.column_type] || '#999', color: '#fff', fontSize: 10, height: 20 }} />
        <Typography variant="body2" sx={{ flexGrow: 1 }}>
          {pos + 1}. {name}
        </Typography>
        <Tooltip title="Move up">
          <span><IconButton size="small" aria-label={`Move ${name} up`} data-testid={`col-order-up-${colId}`}
            disabled={pos <= 0} onClick={() => moveColumn(colId, -1)}><MoveUpIcon fontSize="small" /></IconButton></span>
        </Tooltip>
        <Tooltip title="Move down">
          <span><IconButton size="small" aria-label={`Move ${name} down`} data-testid={`col-order-down-${colId}`}
            disabled={pos < 0 || pos >= selectedColumnIds.length - 1} onClick={() => moveColumn(colId, 1)}><MoveDownIcon fontSize="small" /></IconButton></span>
        </Tooltip>
        <Tooltip title="Remove column from report">
          <IconButton size="small" onClick={() => toggleColumn(colId)}><DeleteIcon fontSize="small" /></IconButton>
        </Tooltip>
      </Box>
    );
  };

  const renderStep1_Columns = () => {
    // PV mode: columns are controlled by the Published View
    if (dataSourceType === 'published_view') {
      return (
        <Box>
          <Typography variant="h6" sx={{ mb: 2 }}>Columns</Typography>
          <Alert severity="info" sx={{ mb: 2 }}>
            Column selection is controlled by the Published View configuration.
            Click Next to continue to filters and layout.
          </Alert>
        </Box>
      );
    }
    // Group columns by class
    const byClass: Record<string, any[]> = { 'Ungrouped': [] };
    for (const cls of allClasses) {
      byClass[cls.label || cls.name] = [];
    }
    for (const col of allColumns) {
      if (col.is_hidden) continue;
      const cls = allClasses.find((c: any) => c.id === col.class_id);
      const key = cls ? (cls.label || cls.name) : 'Ungrouped';
      if (!byClass[key]) byClass[key] = [];
      byClass[key].push(col);
    }

    // Filter columns by search term
    const searchLower = columnSearch.toLowerCase().trim();
    const filteredByClass: Record<string, any[]> = {};
    for (const [className, cols] of Object.entries(byClass)) {
      const filtered = searchLower
        ? cols.filter((c: any) =>
            (c.friendly_name || '').toLowerCase().includes(searchLower) ||
            (c.physical_name || '').toLowerCase().includes(searchLower))
        : cols;
      if (filtered.length > 0) filteredByClass[className] = filtered;
    }
    const visibleColIds = Object.values(filteredByClass).flat().map((c: any) => c.id);

    return (
      <Box>
        <Typography variant="h6" sx={{ mb: 1 }}>Select Columns</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Pick the dimensions and measures to include in your report. Drag to reorder below.
        </Typography>

        {/* Search + bulk actions */}
        <Box sx={{ display: 'flex', gap: 1, mb: 2, alignItems: 'center', flexWrap: 'wrap' }}>
          <TextField
            size="small" placeholder="Search columns..." value={columnSearch}
            onChange={e => setColumnSearch(e.target.value)}
            sx={{ minWidth: 240 }}
            InputProps={{
              startAdornment: <SearchIcon sx={{ mr: 0.5, fontSize: 18, color: 'text.secondary' }} />,
              endAdornment: columnSearch ? (
                <Tooltip title="Clear search"><IconButton size="small" onClick={() => setColumnSearch('')}><ClearIcon sx={{ fontSize: 16 }} /></IconButton></Tooltip>
              ) : null,
            }}
          />
          <Chip label={`${selectedColumnIds.length} selected`} size="small" color="primary" />
          <Button size="small" variant="outlined"
            onClick={() => {
              const dims = allColumns.filter((c: any) => c.column_type === 'dimension').map((c: any) => c.id);
              setSelectedColumnIds(prev => [...new Set([...prev, ...dims])]);
            }}>All Dimensions</Button>
          <Button size="small" variant="outlined"
            onClick={() => {
              const meas = allColumns.filter((c: any) => c.column_type === 'measure' || c.column_type === 'kpi').map((c: any) => c.id);
              setSelectedColumnIds(prev => [...new Set([...prev, ...meas])]);
            }}>All Measures</Button>
          {visibleColIds.length > 0 && searchLower && (
            <Button size="small" variant="outlined"
              onClick={() => setSelectedColumnIds(prev => [...new Set([...prev, ...visibleColIds])])}>
              Select Visible ({visibleColIds.length})
            </Button>
          )}
          {selectedColumnIds.length > 0 && (
            <Button size="small" color="error" onClick={() => setSelectedColumnIds([])}>Clear All</Button>
          )}
        </Box>

        {Object.entries(filteredByClass).map(([className, cols]) => (
          <Box key={className} sx={{ mb: 2 }}>
            <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 0.5 }}>
              {className} ({cols.length})
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {cols.map((col: any) => (
                <Chip
                  key={col.id}
                  label={col.friendly_name || col.physical_name}
                  size="small"
                  variant={selectedColumnIds.includes(col.id) ? 'filled' : 'outlined'}
                  onClick={() => toggleColumn(col.id)}
                  sx={{
                    borderColor: COLUMN_TYPE_COLORS[col.column_type] || '#999',
                    bgcolor: selectedColumnIds.includes(col.id)
                      ? COLUMN_TYPE_COLORS[col.column_type] || '#999' : 'transparent',
                    color: selectedColumnIds.includes(col.id) ? '#fff' : 'inherit',
                    '&:hover': { opacity: 0.85 },
                  }}
                />
              ))}
            </Box>
          </Box>
        ))}
        {searchLower && Object.keys(filteredByClass).length === 0 && (
          <Alert severity="info" sx={{ mt: 1 }}>No columns match "{columnSearch}"</Alert>
        )}

        {/* Column order — drag to reorder */}
        {selectedColumnIds.length > 0 && (
          <Box sx={{ mt: 3 }}>
            <Divider sx={{ mb: 2 }} />
            <Typography variant="subtitle2" sx={{ mb: 1 }}>Column order -- the report shows the columns in this order (drag a row, or use the arrows)</Typography>
            <DndContext sensors={dndSensors} collisionDetection={closestCenter}
              onDragEnd={(event) => {
                const { active, over } = event;
                if (over && active.id !== over.id) {
                  setSelectedColumnIds(prev => {
                    const oldIdx = prev.indexOf(Number(active.id));
                    const newIdx = prev.indexOf(Number(over.id));
                    return arrayMove(prev, oldIdx, newIdx);
                  });
                }
              }}>
              <SortableContext items={selectedColumnIds.map(String)} strategy={verticalListSortingStrategy}>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, maxWidth: 480 }}>
                  {selectedColumnIds.map(colId => (
                    <SortableColumnItem key={colId} colId={colId} />
                  ))}
                </Box>
              </SortableContext>
            </DndContext>
          </Box>
        )}
      </Box>
    );
  };

  const renderStep2_Filters = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 1 }}>Filters & Conditions</Typography>

      {dataSourceType === 'published_view' && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Filters configured on the Published View will be applied automatically.
          You can add additional report-level filters below if needed.
        </Alert>
      )}

      {/* 2026-10-29 -- TWO kinds of filter (the owner: "filter data at
          source and bring, and local filter").  The dataset's own query
          already has conditions in its WHERE; each can be asked when the
          report runs -- the value goes INTO the condition and the query runs
          on the source.  Without a value the query runs as written. */}
      {dataSourceType === 'saved_query' && (sourceFilters.length > 0 || sourceFiltersNote) && (
        <Box sx={{ mt: 2, mb: 2 }} data-testid="source-filters">
          <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Filter at the source</Typography>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
            These conditions are in the dataset's own query and run on the source. Tick one to let the
            person running the report choose its value; left empty, the report uses what the query says.
          </Typography>
          {sourceFilters.map(sf => {
            const saved = params.find(p => p.source_column === sf.key);
            const checked = !!saved || askedSource.includes(sf.key);
            return (
              <Box key={sf.key} sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                <FormControlLabel sx={{ mr: 0 }}
                  label={<Typography variant="body2">{sourceFilterWords(sf)}</Typography>}
                  control={<Checkbox size="small" checked={checked}
                    inputProps={{ 'aria-label': `Ask when the report runs: ${sf.column}`,
                                  'data-testid': `source-filter-${sf.key}-ask` } as any}
                    onChange={e => {
                      if (e.target.checked) setAskedSource(prev => prev.includes(sf.key) ? prev : [...prev, sf.key]);
                      else {
                        setAskedSource(prev => prev.filter(k => k !== sf.key));
                        if (saved) setParams(prev => prev.filter(p => p.source_column !== sf.key));
                      }
                    }} />} />
                <Typography variant="caption" color="text.secondary" data-testid={`source-filter-${sf.key}-words`}>
                  {checked
                    ? (sf.is_date ? 'Asked when the report runs: any date on a calendar.' : 'Asked when the report runs: one value or several (several run as IN).')
                    : 'Runs as written.'}
                </Typography>
              </Box>
            );
          })}
          {sourceFilters.length === 0 && sourceFiltersNote && (
            <Typography variant="caption" color="text.secondary">{sourceFiltersNote}</Typography>
          )}
        </Box>
      )}

      {/* Static filters */}
      <Typography variant="subtitle2" sx={{ mt: 2, mb: 1 }}>Filter the results</Typography>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
        These filters apply to the rows the report returns.
      </Typography>
      {filters.map((f, idx) => (
        <Box key={idx} sx={{ display: 'flex', gap: 1, mb: 1, alignItems: 'center' }}>
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <Select inputProps={{ 'aria-label': 'Filter column' }} value={f.column_id} onChange={e => updateFilter(idx, 'column_id', e.target.value)}>
              {allColumns.map((c: any) => (
                <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 130 }}>
            <Select inputProps={{ 'aria-label': 'Filter operator' }} value={f.operator} onChange={e => updateFilter(idx, 'operator', e.target.value)}>
              {FILTER_OPERATORS.map(op => (
                <MenuItem key={op.value} value={op.value}>{op.label}</MenuItem>
              ))}
            </Select>
          </FormControl>
          {/* Operator-specific value inputs -- or asked when the report runs */}
          {f.ask_at_run ? (
            <Typography variant="body2" color="text.secondary" sx={{ minWidth: 260 }} data-testid={`filter-${idx}-asked`}>
              {String(allColumns.find((c: any) => c.id === f.column_id)?.data_type || '').toLowerCase() === 'date'
                ? 'The person running the report picks any date on a calendar. Left empty: all dates.'
                : 'The person running the report picks the value from the data. Left empty: all values.'}
            </Typography>
          ) : (
          <ReportFilterValueInput filter={f} index={idx} columns={allColumns}
            datasetId={dataSourceType === 'saved_query' ? selectedDatasetId : null}
            unfilled={filterProblems.some(p => p.startsWith(`Filter ${idx + 1} `))}
            onChange={(field, v) => updateFilter(idx, field, v)} />
          )}
          <Tooltip title={ASKABLE_OPERATORS.includes(f.operator || 'eq')
            ? 'Do not pick a value now: whoever runs the report chooses it'
            : 'Only for "equals", "is one of" and "between"'}>
            <span>
              <FormControlLabel sx={{ ml: 0.5, mr: 0 }} label={<Typography variant="caption">Ask when the report runs</Typography>}
                control={<Checkbox size="small" checked={!!f.ask_at_run}
                                   disabled={!ASKABLE_OPERATORS.includes(f.operator || 'eq')}
                                   inputProps={{ 'aria-label': 'Ask when the report runs', 'data-testid': `filter-${idx}-ask` } as any}
                                   onChange={e => updateFilter(idx, 'ask_at_run', e.target.checked)} />} />
            </span>
          </Tooltip>
          <Tooltip title="Remove this filter">
            <IconButton size="small" onClick={() => removeFilter(idx)}><DeleteIcon fontSize="small" /></IconButton>
          </Tooltip>
        </Box>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addFilter}>Add Filter</Button>
      {filterProblems.length > 0 && (
        <Alert severity="warning" sx={{ mt: 1 }} data-testid="unfilled-filters">
          {filterProblems.join(' ')}
        </Alert>
      )}

      {/* Pre-defined conditions */}
      {conditions.length > 0 && (
        <>
          <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Pre-defined Conditions</Typography>
          {conditions.map((c: any) => (
            <FormControlLabel
              key={c.id}
              control={
                <Checkbox
                  checked={selectedConditionIds.includes(c.id)}
                  onChange={() => {
                    setSelectedConditionIds(prev =>
                      prev.includes(c.id) ? prev.filter(id => id !== c.id) : [...prev, c.id]
                    );
                  }}
                />
              }
              label={c.label || c.name}
            />
          ))}
        </>
      )}

      {/* Order by */}
      <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Sort Order</Typography>
      {orderBy.map((ob, idx) => (
        <Box key={idx} sx={{ display: 'flex', gap: 1, mb: 1, alignItems: 'center' }}>
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <Select inputProps={{ 'aria-label': 'Sort column' }} value={ob.column_id} onChange={e => {
              const newOb = [...orderBy];
              newOb[idx] = { ...newOb[idx], column_id: Number(e.target.value) };
              setOrderBy(newOb);
            }}>
              {selectedCols.map((c: any) => (
                <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 100 }}>
            <Select inputProps={{ 'aria-label': 'Sort direction' }} value={ob.direction} onChange={e => {
              const newOb = [...orderBy];
              newOb[idx] = { ...newOb[idx], direction: e.target.value };
              setOrderBy(newOb);
            }}>
              <MenuItem value="asc">Ascending</MenuItem>
              <MenuItem value="desc">Descending</MenuItem>
            </Select>
          </FormControl>
          <Tooltip title="Remove sort">
            <IconButton size="small" onClick={() => setOrderBy(prev => prev.filter((_, i) => i !== idx))}>
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={() => {
        if (selectedCols.length > 0)
          setOrderBy(prev => [...prev, { column_id: selectedCols[0].id, direction: 'asc' }]);
      }}>Add Sort</Button>

      {/* Row limit */}
      <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Rows</Typography>
      <RadioGroup value={rowLimit === null ? 'all' : 'max'} aria-label="Rows"
        onChange={e => setRowLimit(e.target.value === 'all' ? null : (rowLimit || 50000))}>
        <FormControlLabel value="all" control={<Radio size="small" />}
          label={rowLimitWords(null, rowCeiling)} />
        <FormControlLabel value="max" control={<Radio size="small" />} label={
          <Stack direction="row" spacing={1} alignItems="center">
            <span>At most</span>
            <TextField size="small" type="number" value={rowLimit ?? ''} disabled={rowLimit === null}
              inputProps={{ 'aria-label': 'At most this many rows', min: 1 }} sx={{ width: 140 }}
              onChange={e => setRowLimit(Math.max(1, Number(e.target.value) || 1))} />
            <span>rows</span>
          </Stack>} />
      </RadioGroup>

      {/* Data freshness — Phase 2 instance layer (2026-08-09) */}
      <Typography variant="subtitle2" sx={{ mt: 3, mb: 1 }}>Data Freshness</Typography>
      <FormControlLabel
        control={
          <Switch checked={refreshOnOpen} size="small"
            onChange={e => setRefreshOnOpen(e.target.checked)}
            inputProps={{ 'aria-label': 'Always run live on open' }} />
        }
        label="Always run live on open"
      />
      <Typography variant="caption" color="text.secondary" display="block" sx={{ maxWidth: 640 }}>
        Off (default): when a saved result from an earlier run matches, opening this report
        shows it instantly with a “Data as of” banner and a Refresh button. On: every open
        runs a fresh query against the source — choose this when up-to-the-minute data
        matters more than opening speed.
      </Typography>
    </Box>
  );

  const renderStep3_Parameters = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 1 }}>Parameters (Cascading Prompts)</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Define input controls that users fill in before running the report.
        Dropdown parameters can cascade (e.g., Country selection filters Region list).
      </Typography>

      {/* 2026-08-31 -- say WHY a prompt was added on the author's behalf.  A
          required parameter that appears by itself, with no explanation, reads
          as a bug; the same prompt with its reason reads as the guard rail it
          is. */}
      {partitionCols.length > 0 && (
        <Alert severity="info" sx={{ mb: 2 }}>
          <strong>
            {partitionCols.map((c: any) => c.friendly_name || c.name).join(', ')}
          </strong>
          {partitionCols.length === 1 ? ' partitions ' : ' partition '}
          this dataset, so a required prompt has been added for
          {partitionCols.length === 1 ? ' it' : ' each'}. Every run then reads
          one partition instead of the whole table. Removing the prompt is
          allowed — the report will scan everything.
        </Alert>
      )}
      {partitionDetected === false && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          Partition columns could not be determined for this dataset, so no
          partition prompt was added and the report is not forced to filter on
          one. This is not the same as “this source has no partitions”.
          {partitionWarnings.length > 0 && (
            <Box component="ul" sx={{ m: 0, mt: 1, pl: 2 }}>
              {partitionWarnings.slice(0, 3).map((w, i) => (
                <li key={i}><Typography variant="caption">{w}</Typography></li>
              ))}
            </Box>
          )}
        </Alert>
      )}

      <ReportParameterEditor rows={params} onChange={setParams}
                             columns={allColumns}
                             datasetId={selectedDatasetId} />
    </Box>
  );

  const renderStep4_Layout = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Layout & Calculations</Typography>

      {dataSourceType === 'published_view' && (
        <Alert severity="info" sx={{ mb: 2 }}>
          Layout options like section breaks, running calculations, and slicers are optional for
          Published View reports. They operate on the columns returned by the view.
        </Alert>
      )}

      {/* Section Breaks */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Section Breaks (Subtotals)</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Group rows by a dimension with section headers and subtotals per group.
      </Typography>
      {sections.map((s, idx) => (
        <Paper key={idx} elevation={1} sx={{ p: 1.5, mb: 1 }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
            <TextField size="small" label="Section Name" value={s.name}
              onChange={e => updateSection(idx, 'name', e.target.value)} sx={{ width: 160 }} />
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel id="sel-businessreportbuilder-break-column">Break Column</InputLabel>
              <Select labelId="sel-businessreportbuilder-break-column" value={s.break_column_id} label="Break Column"
                onChange={e => updateSection(idx, 'break_column_id', e.target.value)}>
                {selectedDims.map((c: any) => (
                  <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 200 }}>
              <InputLabel id="sel-businessreportbuilder-subtotal-measures">Subtotal Measures</InputLabel>
              <Select labelId="sel-businessreportbuilder-subtotal-measures" multiple value={s.subtotal_measure_ids} label="Subtotal Measures"
                onChange={e => updateSection(idx, 'subtotal_measure_ids', e.target.value)}
                renderValue={(sel: number[]) => sel.map(id => getColName(id)).join(', ')}>
                {selectedMeasures.map((c: any) => (
                  <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControlLabel
              control={<Checkbox checked={s.show_count} onChange={e => updateSection(idx, 'show_count', e.target.checked)} />}
              label="Count"
            />
            <Tooltip title="Remove this section break"><IconButton size="small" onClick={() => removeSection(idx)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
          </Box>
        </Paper>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addSection}
        disabled={selectedDims.length === 0}>Add Section Break</Button>

      <Divider sx={{ my: 3 }} />

      {/* Running Calculations */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Running Calculations</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Post-query computed columns: running sum, rank, % of total, previous value.
      </Typography>
      {runningCalcs.map((c, idx) => (
        <Paper key={idx} elevation={1} sx={{ p: 1.5, mb: 1 }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
            <TextField size="small" label="Name" value={c.name}
              onChange={e => updateCalc(idx, 'name', e.target.value)} sx={{ width: 140 }} />
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              <FormControl size="small" sx={{ minWidth: 140 }}>
                <InputLabel id="sel-businessreportbuilder-type">Type</InputLabel>
                <Select labelId="sel-businessreportbuilder-type" value={c.calc_type} label="Type"
                  onChange={e => updateCalc(idx, 'calc_type', e.target.value)}>
                  {CALC_TYPES.map(ct => (
                    <MenuItem key={ct.value} value={ct.value}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        {ct.label}
                      </Box>
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              {/* Phase 85D-5: Tooltip for selected calc type */}
              {(() => {
                const selectedCalcType = CALC_TYPES.find(ct => ct.value === c.calc_type);
                return selectedCalcType ? (
                  <Tooltip title={selectedCalcType.description} placement="top">
                    <InfoOutlinedIcon sx={{ fontSize: 16, color: 'info.main', cursor: 'help' }} />
                  </Tooltip>
                ) : null;
              })()}
            </Box>
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel id="sel-businessreportbuilder-measure">Measure</InputLabel>
              <Select labelId="sel-businessreportbuilder-measure" value={c.measure_col_id} label="Measure"
                onChange={e => updateCalc(idx, 'measure_col_id', e.target.value)}>
                {selectedMeasures.map((col: any) => (
                  <MenuItem key={col.id} value={col.id}>{col.friendly_name || col.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 160 }}>
              <InputLabel id="sel-businessreportbuilder-partition-by">Partition By</InputLabel>
              <Select labelId="sel-businessreportbuilder-partition-by" value={c.partition_col_id || ''} label="Partition By"
                onChange={e => updateCalc(idx, 'partition_col_id', e.target.value || null)}>
                <MenuItem value="">None (Global)</MenuItem>
                {selectedDims.map((col: any) => (
                  <MenuItem key={col.id} value={col.id}>{col.friendly_name || col.physical_name}</MenuItem>
                ))}
              </Select>
            </FormControl>
            <Tooltip title="Remove this calculation"><IconButton size="small" onClick={() => removeCalc(idx)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
          </Box>
        </Paper>
      ))}
      <Button size="small" startIcon={<AddIcon />} onClick={addRunningCalc}
        disabled={selectedMeasures.length === 0}>Add Calculation</Button>

      <Divider sx={{ my: 3 }} />

      {/* Slicer Columns */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Slicer Columns (Cross-Filter)</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Viewers can filter report results instantly by selecting slicer values.
      </Typography>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
        {selectedDims.map((c: any) => (
          <Chip
            key={c.id}
            label={c.friendly_name || c.physical_name}
            size="small"
            variant={slicerColumnIds.includes(c.id) ? 'filled' : 'outlined'}
            color={slicerColumnIds.includes(c.id) ? 'primary' : 'default'}
            onClick={() => {
              setSlicerColumnIds(prev =>
                prev.includes(c.id) ? prev.filter(id => id !== c.id) : [...prev, c.id]
              );
            }}
          />
        ))}
      </Box>

      <Divider sx={{ my: 3 }} />

      {/* Drill Hierarchy */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Drill Hierarchy</Typography>
      {hierarchies.length > 0 ? (
        <FormControl size="small" sx={{ minWidth: 250 }}>
          <InputLabel id="sel-businessreportbuilder-drill-hierarchy">Drill Hierarchy</InputLabel>
          <Select labelId="sel-businessreportbuilder-drill-hierarchy" value={drillHierarchyId || ''} label="Drill Hierarchy"
            onChange={e => setDrillHierarchyId(e.target.value ? Number(e.target.value) : null)}>
            <MenuItem value="">None</MenuItem>
            {hierarchies.map((h: any) => (
              <MenuItem key={h.id} value={h.id}>{h.name}</MenuItem>
            ))}
          </Select>
        </FormControl>
      ) : (
        <Typography variant="body2" color="text.secondary">
          No drill hierarchies defined for this dataset.
        </Typography>
      )}

      <Divider sx={{ my: 3 }} />

      {/* Chart View (2026-08-09) — saved visualisation over the cube */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Chart View</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
        Give this report a chart. Viewers get a Table / Chart toggle; the chart is
        aggregated on the server over the full result and supports click-to-drill,
        exactly like the table.
      </Typography>
      <FormControlLabel
        control={<Switch checked={chartEnabled}
          onChange={e => {
            setChartEnabled(e.target.checked);
            // Sensible first-time defaults from the current selection
            if (e.target.checked && chartMeasureIds.length === 0 && selectedMeasures.length > 0) {
              setChartMeasureIds([selectedMeasures[0].id]);
            }
            if (e.target.checked && chartDimensionId === '' && selectedDims.length > 0) {
              setChartDimensionId(selectedDims[0].id);
            }
          }} />}
        label="Enable chart view"
      />
      {chartEnabled && (
        <Paper elevation={1} sx={{ p: 1.5, mt: 1, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'center' }}>
            <FormControl size="small" sx={{ minWidth: 220 }}>
              <InputLabel id="sel-businessreportbuilder-chart-type">Chart Type</InputLabel>
              <Select labelId="sel-businessreportbuilder-chart-type" value={chartType} label="Chart Type"
                onChange={e => setChartType(e.target.value)}>
                <MenuItem value="bar">Bar — compare categories</MenuItem>
                <MenuItem value="bar_horizontal">Horizontal bar — long category labels</MenuItem>
                <MenuItem value="bar_grouped">Grouped bar — series side by side</MenuItem>
                <MenuItem value="bar_stacked">Stacked bar — part-to-whole per category</MenuItem>
                <MenuItem value="line">Line — trend over an ordered dimension</MenuItem>
                <MenuItem value="combo">Combo — bars with a line overlay</MenuItem>
                <MenuItem value="donut">Donut — share of total (max 6 slices + Other)</MenuItem>
                <MenuItem value="kpi">KPI — one number, with optional comparison</MenuItem>
              </Select>
            </FormControl>
            <FormControl size="small" sx={{ minWidth: 180 }}>
              <InputLabel id="sel-businessreportbuilder-default-view">Default View</InputLabel>
              <Select labelId="sel-businessreportbuilder-default-view" value={chartDefaultView} label="Default View"
                onChange={e => setChartDefaultView(e.target.value as 'table' | 'chart' | 'both')}>
                <MenuItem value="table">Open on Table</MenuItem>
                <MenuItem value="chart">Open on Chart</MenuItem>
                <MenuItem value="both">Open on Chart + Table</MenuItem>
              </Select>
            </FormControl>
          </Box>
          {chartType !== 'kpi' && (
            <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'center' }}>
              <FormControl size="small" sx={{ minWidth: 200 }}>
                <InputLabel id="sel-businessreportbuilder-category-x-axis">Category (X axis)</InputLabel>
                <Select labelId="sel-businessreportbuilder-category-x-axis" value={chartDimensionId} label="Category (X axis)"
                  onChange={e => {
                    const v = e.target.value as number | '';
                    setChartDimensionId(v === '' ? '' : Number(v));
                  }}>
                  {selectedDims.map((c: any) => (
                    <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                  ))}
                </Select>
                {drillHierarchyId && (
                  <FormHelperText>
                    While drilling, the chart follows the drill level instead.
                  </FormHelperText>
                )}
              </FormControl>
              {['bar_grouped', 'bar_stacked', 'line'].includes(chartType) && (
                <FormControl size="small" sx={{ minWidth: 200 }}>
                  <InputLabel id="sel-businessreportbuilder-split-series-by">Split series by</InputLabel>
                  <Select labelId="sel-businessreportbuilder-split-series-by" value={chartSplitId} label="Split series by"
                    onChange={e => {
                      const v = e.target.value as number | '';
                      setChartSplitId(v === '' ? '' : Number(v));
                    }}>
                    <MenuItem value="">None (one series per measure)</MenuItem>
                    {selectedDims.filter((c: any) => c.id !== chartDimensionId).map((c: any) => (
                      <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>
                    With a split, only the first measure is plotted (max 8 series).
                  </FormHelperText>
                </FormControl>
              )}
            </Box>
          )}
          <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap', alignItems: 'center' }}>
            <FormControl size="small" sx={{ minWidth: 240 }}>
              <InputLabel id="sel-businessreportbuilder-field">{chartType === 'kpi' ? 'KPI Measure' : 'Measures (Y axis)'}</InputLabel>
              <Select labelId="sel-businessreportbuilder-field" multiple={!['kpi', 'donut'].includes(chartType)}
                value={['kpi', 'donut'].includes(chartType)
                  ? (chartMeasureIds[0] ?? '') : chartMeasureIds}
                label={chartType === 'kpi' ? 'KPI Measure' : 'Measures (Y axis)'}
                onChange={e => {
                  const v = e.target.value as any;
                  setChartMeasureIds(Array.isArray(v) ? v.map(Number) : (v === '' ? [] : [Number(v)]));
                }}
                renderValue={(sel: any) => (Array.isArray(sel) ? sel : [sel])
                  .map((id: number) => getColName(Number(id))).join(', ')}>
                {selectedMeasures.map((c: any) => (
                  <MenuItem key={c.id} value={c.id}>
                    {c.friendly_name || c.physical_name}
                    <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                      ({c.aggregation || 'sum'})
                    </Typography>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {chartType === 'combo' && (
              <>
                <FormControl size="small" sx={{ minWidth: 220 }}>
                  <InputLabel id="sel-businessreportbuilder-draw-as-line">Draw as line</InputLabel>
                  <Select labelId="sel-businessreportbuilder-draw-as-line" multiple value={chartLineMeasureIds} label="Draw as line"
                    onChange={e => setChartLineMeasureIds((e.target.value as any[]).map(Number))}
                    renderValue={(sel: number[]) => sel.map(id => getColName(id)).join(', ')}>
                    {chartMeasureIds.map((id: number) => (
                      <MenuItem key={id} value={id}>{getColName(id)}</MenuItem>
                    ))}
                  </Select>
                  <FormHelperText>The remaining measures render as bars.</FormHelperText>
                </FormControl>
                <Tooltip title="Puts the line measure on its own right-hand scale (tinted and named after its series). Use only when the line's scale is genuinely different — a second axis can suggest correlations that are not in the data.">
                  <FormControlLabel
                    control={<Switch checked={chartSecondaryAxis}
                      onChange={e => setChartSecondaryAxis(e.target.checked)} />}
                    label="Secondary axis for the line"
                  />
                </Tooltip>
              </>
            )}
            {chartType === 'kpi' && (
              <FormControl size="small" sx={{ minWidth: 220 }}>
                <InputLabel id="sel-businessreportbuilder-compare-against">Compare against</InputLabel>
                <Select labelId="sel-businessreportbuilder-compare-against" value={chartKpiComparisonId} label="Compare against"
                  onChange={e => {
                    const v = e.target.value as number | '';
                    setChartKpiComparisonId(v === '' ? '' : Number(v));
                  }}>
                  <MenuItem value="">No comparison</MenuItem>
                  {selectedMeasures.filter((c: any) => c.id !== chartMeasureIds[0]).map((c: any) => (
                    <MenuItem key={c.id} value={c.id}>{c.friendly_name || c.physical_name}</MenuItem>
                  ))}
                </Select>
                <FormHelperText>e.g. a target or prior-period measure.</FormHelperText>
              </FormControl>
            )}
          </Box>
          {chartMeasureIds.length === 0 && (
            <Alert severity="info" sx={{ fontSize: 12 }}>
              Pick at least one measure — the chart is not saved without one.
            </Alert>
          )}
        </Paper>
      )}

      <Divider sx={{ my: 3 }} />

      {/* Report Style */}
      <Typography variant="subtitle1" sx={{ mb: 1 }}>Report Style</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Customize colors and number formatting for the report viewer and exports.
      </Typography>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mb: 2 }}>
        {/* Color pickers */}
        {([
          ['header_bg', 'Header Background'],
          ['header_text', 'Header Text'],
          ['accent_color', 'Section Header'],
          ['subtotal_bg', 'Subtotal Row'],
          ['grand_total_bg', 'Grand Total Row'],
        ] as [string, string][]).map(([key, label]) => (
          <Box key={key} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            <input
              type="color"
              value={(styleConfig as any)[key]}
              onChange={e => updateStyle(key, e.target.value)}
              style={{ width: 32, height: 32, border: '1px solid #ccc', borderRadius: 4, cursor: 'pointer', padding: 0 }}
            />
            <TextField
              size="small"
              label={label}
              value={(styleConfig as any)[key]}
              onChange={e => updateStyle(key, e.target.value)}
              sx={{ width: 120 }}
              inputProps={{ style: { fontFamily: 'monospace', fontSize: 13 } }}
            />
          </Box>
        ))}
      </Box>
      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, alignItems: 'center' }}>
        <FormControl size="small" sx={{ minWidth: 200 }}>
          <InputLabel id="sel-businessreportbuilder-negative-numbers">Negative Numbers</InputLabel>
          <Select labelId="sel-businessreportbuilder-negative-numbers" value={styleConfig.negative_format} label="Negative Numbers"
            onChange={e => updateStyle('negative_format', e.target.value)}>
            <MenuItem value="brackets">Brackets (1,234)</MenuItem>
            <MenuItem value="minus">Minus Sign -1,234</MenuItem>
            <MenuItem value="red">Red Color Only</MenuItem>
          </Select>
        </FormControl>
        <FormControlLabel
          control={<Switch checked={styleConfig.stripe_rows} onChange={e => updateStyle('stripe_rows', e.target.checked)} />}
          label="Striped Rows"
        />
      </Box>
    </Box>
  );

  // Phase 85D-6: Preview report (only if already saved as edit)
  const handlePreviewReport = async () => {
    if (!editId) return;
    setPreviewLoading(true);
    setPreviewError('');
    setPreviewRows([]);
    setPreviewCols([]);
    setPreviewDialogOpen(true);
    try {
      const result = await api.executeBusinessReport(editReportId, {
        parameter_values: {},
        extra_filters: [],
        limit: 10,
      });
      const rows = result?.rows || [];
      const cols = result?.columns || (rows[0] ? Object.keys(rows[0]) : []);
      setPreviewRows(rows.slice(0, 10));
      setPreviewCols(cols);
    } catch (e: any) {
      setPreviewError(e.message || 'Preview failed');
    } finally {
      setPreviewLoading(false);
    }
  };

  const renderStep5_Review = () => (
    <Box>
      <Typography variant="h6" sx={{ mb: 2 }}>Review & Save</Typography>

      <TextField
        fullWidth label="Report Name" value={reportName}
        onChange={e => setReportName(e.target.value)}
        sx={{ mb: 2 }} required error={!reportName.trim()}
        helperText={!reportName.trim() ? 'Name is required' : ''}
      />
      <TextField
        fullWidth label="Description" value={reportDescription}
        onChange={e => setReportDescription(e.target.value)}
        multiline rows={2} sx={{ mb: 3 }}
      />

      {/* Phase 131 deep-dive #12 — group ownership.  Entitlement parity
          with FeedConfigsPage Step 4 + Report.owner_group_id.  Members
          of the picked group get rerun/edit access per their access
          level (read_only / read_write). */}
      <FormControl fullWidth size="small" sx={{ mb: 3 }}>
        <InputLabel id="br-owner-group-label">Owner Group (optional)</InputLabel>
        <Select
          labelId="br-owner-group-label"
          label="Owner Group (optional)"
          value={ownerGroupId === '' ? '' : String(ownerGroupId)}
          onChange={(e) => {
            const v = e.target.value;
            setOwnerGroupId(v === '' ? '' : Number(v));
          }}
        >
          <MenuItem value=""><em>No group — solo (only creator + admins)</em></MenuItem>
          {userGroups.map((g) => (
            <MenuItem key={g.id} value={String(g.id)}>
              {g.name}{g.description ? ` — ${g.description}` : ''}
            </MenuItem>
          ))}
        </Select>
        <FormHelperText>
          {canListGroups
            ? 'Group members get view/edit access per their access level (read_only vs read_write).'
            : 'Only an admin can list and assign entitlement groups; an existing assignment is kept.'}
        </FormHelperText>
      </FormControl>

      <Divider sx={{ mb: 2 }} />

      {/* Phase 85D-6: Preview button (only for existing saved reports) */}
      {isEdit && (
        <Box sx={{ mb: 2 }}>
          <Button
            variant="outlined"
            size="small"
            startIcon={previewLoading ? <CircularProgress size={14} /> : <PreviewReportIcon />}
            onClick={handlePreviewReport}
            disabled={previewLoading}
          >
            Preview Report (10 rows)
          </Button>
        </Box>
      )}

      <Typography variant="subtitle2" gutterBottom>Summary</Typography>

      <Table size="small">
        <TableBody>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold', width: 180 }}>
              {dataSourceType === 'published_view' ? 'Published View' : 'Dataset'}
            </TableCell>
            <TableCell>
              {dataSourceType === 'published_view'
                ? (publishedViews.find((v: any) => v.id === selectedPvId)?.name || `PV #${selectedPvId}`)
                : (dataset?.name || selectedDatasetId)}
            </TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Columns</TableCell>
            <TableCell>{selectedColumnIds.length} selected ({selectedDims.length} dims, {selectedMeasures.length} measures)</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Filters</TableCell>
            <TableCell>{filters.length} filters, {selectedConditionIds.length} conditions</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Parameters</TableCell>
            <TableCell>{params.length} input controls</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Section Breaks</TableCell>
            <TableCell>{sections.length} sections</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Running Calculations</TableCell>
            <TableCell>{runningCalcs.length} calculations</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Slicers</TableCell>
            <TableCell>{slicerColumnIds.length} slicer columns</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Drill Hierarchy</TableCell>
            <TableCell>{drillHierarchyId ? hierarchies.find((h: any) => h.id === drillHierarchyId)?.name || 'Selected' : 'None'}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Rows</TableCell>
            <TableCell>{rowLimitWords(rowLimit, rowCeiling)}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold' }}>Data Freshness</TableCell>
            <TableCell>
              {refreshOnOpen
                ? 'Always run live on open'
                : 'Saved results allowed (instant open with "Data as of" banner)'}
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </Box>
  );

  // ── Main render ───────────────────────────────────────────────────────────

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  const stepRenderers = [
    renderStep0_Subject,
    renderStep1_Columns,
    renderStep2_Filters,
    renderStep3_Parameters,
    renderStep4_Layout,
    renderStep5_Review,
  ];

  return (
    <Box sx={{ maxWidth: 1600, mx: 'auto', p: 3 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
        <Tooltip title="Back to Finance Reports list">
          <IconButton onClick={() => navigate(REPORTS_PATH)} sx={{ mr: 1 }}>
            <ArrowBackIcon />
          </IconButton>
        </Tooltip>
        <Typography variant="h5">{isEdit ? 'Edit Report' : 'New Finance Report'}</Typography>
      </Box>

      {/* 2026-10-23 -- a step is a BUTTON: while editing, any step (the name is
          on the last one); a new report goes back freely and forward only past
          completed steps. */}
      <Stepper nonLinear activeStep={activeStep} alternativeLabel sx={{ mb: 3 }}>
        {WIZARD_STEPS.map((label, i) => {
          const reachable = isEdit || i <= activeStep
            || Array.from({ length: i }, (_, k) => k).every(k => canProceed(k));
          return (
            <Step key={label} completed={isEdit ? false : i < activeStep}>
              <StepButton onClick={() => setActiveStep(i)} disabled={!reachable}
                          data-testid={`report-step-${i}`}>{label}</StepButton>
            </Step>
          );
        })}
      </Stepper>

      {error && <Alert ref={errorRef} severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {/* 2026-10-03 -- a stored draft is OFFERED, never applied: it belongs
          to the data source it was built on (reportWizardDraft.ts). */}
      {draftOffer && (
        <Alert severity="info" sx={{ mb: 2 }} data-testid="report-draft-offer"
          action={
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button size="small" variant="contained" onClick={resumeDraft}>Resume draft</Button>
              <Button size="small" onClick={discardDraft}>Discard</Button>
            </Box>
          }>
          You have an unsaved report draft
          {draftOffer.name ? <> “<strong>{draftOffer.name}</strong>”</> : null} on{' '}
          {draftSourceLabel(draftOffer, datasets, publishedViews)}. Resume it, or
          discard it — choosing a data source below starts a new report and
          discards the draft.
        </Alert>
      )}
      {draftNotice && (
        <Alert severity={/left out/.test(draftNotice) ? 'warning' : 'success'} sx={{ mb: 2 }}
               onClose={() => setDraftNotice('')} data-testid="report-draft-notice">
          {draftNotice}
        </Alert>
      )}

      <Paper elevation={2} sx={{ p: 3, mb: 3, minHeight: 300 }}>
        {stepRenderers[activeStep]()}
      </Paper>

      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Button
          disabled={activeStep === 0}
          startIcon={<ArrowBackIcon />}
          onClick={() => setActiveStep(prev => prev - 1)}
        >
          Back
        </Button>

        {activeStep < WIZARD_STEPS.length - 1 ? (
          <Tooltip title={proceedHint(activeStep)} placement="top">
            <span>
              <Button
                variant="contained"
                endIcon={<ArrowForwardIcon />}
                disabled={!canProceed(activeStep)}
                onClick={() => setActiveStep(prev => prev + 1)}
              >
                Next
              </Button>
            </span>
          </Tooltip>
        ) : (
          <Tooltip title={proceedHint(activeStep)} placement="top">
            <span>
              <Button
                variant="contained"
                color="primary"
                startIcon={saving ? <CircularProgress size={16} /> : <SaveIcon />}
                disabled={saving || !canProceed(activeStep)}
                onClick={handleSave}
              >
                {saving ? 'Saving...' : (isEdit ? 'Update Report' : 'Create Report')}
              </Button>
            </span>
          </Tooltip>
        )}
      </Box>

      {/* Phase 85D-6: Preview Report Dialog */}
      <AppDialog open={previewDialogOpen}
        onClose={() => setPreviewDialogOpen(false)}
        size="lg"
        title="Preview Report (10 rows)"
        actions={<>
          <Button onClick={() => setPreviewDialogOpen(false)}>Close</Button>
        </>}>
          {previewLoading ? (
            <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
          ) : previewError ? (
            <Alert severity="error">{previewError}</Alert>
          ) : previewRows.length === 0 ? (
            <Typography color="text.secondary">No rows returned from preview.</Typography>
          ) : (
            <Box sx={{ overflowX: 'auto' }}>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    {previewCols.map(col => (
                      <TableCell key={col} sx={{ fontWeight: 700, fontSize: 12, whiteSpace: 'nowrap' }}>{col}</TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {previewRows.map((row, idx) => (
                    <TableRow key={idx}>
                      {previewCols.map(col => (
                        <TableCell key={col} sx={{ fontSize: 12, whiteSpace: 'nowrap' }}>
                          {row[col] === null || row[col] === undefined
                            ? <span style={{ color: '#aaa' }}>null</span>
                            : String(row[col]).substring(0, 60)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
          )}
      </AppDialog>
    </Box>
  );
};

export default BusinessReportBuilder;
