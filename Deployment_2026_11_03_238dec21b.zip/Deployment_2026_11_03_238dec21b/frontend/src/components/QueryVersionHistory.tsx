import React, { useState, useEffect } from 'react';
import { Button,
  Table, TableHead, TableRow, TableCell, TableBody,
  Typography, IconButton, Tooltip, CircularProgress,
  Box, Alert, Chip,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import { Restore as RestoreIcon, History as HistoryIcon } from '@mui/icons-material';
import api from '../services/api';
import { toArray } from '../utils/toArray';
import ListPager, { clientPage } from './common/ListPager';

interface Props {
  queryId: number | string;
  queryName: string;
  open: boolean;
  onClose: () => void;
  onRestored: () => void;
}

export default function QueryVersionHistory({ queryId, queryName, open, onClose, onRestored }: Props) {
  const [versions, setVersions] = useState<any[]>([]);
  const [loading, setLoading]   = useState(false);
  const [restoring, setRestoring] = useState<number | null>(null);
  const [error, setError]       = useState('');
  // Pages (2026-10-13, "pagination in all grids"): a version per save.
  const [page, setPage]         = useState(1);
  const [pageSize, setPageSize] = useState(50);

  useEffect(() => {
    if (open && queryId) {
      setLoading(true);
      setError('');
      setPage(1);
      api.listQueryVersions(queryId)
        .then(d => setVersions(toArray(d)))
        .catch(() => setError('Failed to load version history'))
        .finally(() => setLoading(false));
    }
  }, [open, queryId]);

  const handleRestore = async (versionId: number) => {
    setRestoring(versionId);
    try {
      await api.restoreQueryVersion(queryId, versionId);
      onRestored();
      onClose();
    } catch {
      setError('Failed to restore version');
    } finally {
      setRestoring(null);
    }
  };

  const shown = clientPage(versions, page, pageSize);
  // The newest version (the list's first row) keeps its highlight on page 1 only.
  const offset = shown.paging.first ? shown.paging.first - 1 : 0;

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="md"
      title={<>
        <HistoryIcon color="primary" />
        Version History — {queryName}
      </>}
      actions={<>
        <Button onClick={onClose}>Close</Button>
      </>}>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
            <CircularProgress />
          </Box>
        ) : versions.length === 0 ? (
          <Typography color="text.secondary" sx={{ p: 2, textAlign: 'center' }}>
            No version history yet. Versions are saved automatically each time you update a query.
          </Typography>
        ) : (
          <>
          <Table size="small">
            <TableHead>
              <TableRow sx={{ background: '#f8fafc' }}>
                <TableCell sx={{ fontWeight: 600 }}>Version</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Name</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Changed By</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Date</TableCell>
                <TableCell sx={{ fontWeight: 600 }}>Note</TableCell>
                <TableCell />
              </TableRow>
            </TableHead>
            <TableBody>
              {shown.rows.map((v: any, idx: number) => (
                <TableRow key={v.id} hover>
                  <TableCell>
                    <Chip label={`v${v.version_number}`} size="small"
                          color={offset + idx === 0 ? 'primary' : 'default'} />
                  </TableCell>
                  <TableCell>{v.name || '—'}</TableCell>
                  <TableCell>{v.changed_by || '—'}</TableCell>
                  <TableCell sx={{ whiteSpace: 'nowrap', fontSize: 12 }}>
                    {v.changed_at
                      ? new Date(v.changed_at).toLocaleString()
                      : '—'}
                  </TableCell>
                  <TableCell sx={{ fontSize: 12, color: 'text.secondary' }}>
                    {v.change_note || '—'}
                  </TableCell>
                  <TableCell>
                    <Tooltip title="Restore this version">
                      <span>
                        <IconButton aria-label="Restore this version"
                          size="small"
                          onClick={() => handleRestore(v.id)}
                          disabled={restoring === v.id}
                        >
                          {restoring === v.id
                            ? <CircularProgress size={16} />
                            : <RestoreIcon fontSize="small" />}
                        </IconButton>
                      </span>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <ListPager paging={shown.paging} onPage={setPage} onPageSize={setPageSize}
                     testid="query-versions-pager" />
          </>
        )}
    </AppDialog>
  );
}
