/**
 * BF-403 — Re-authentication modal overlay.
 *
 * Renders ON TOP of the existing app when AuthContext signals reauthRequired
 * (triggered by a 401 from any API call).  After successful re-login, the
 * modal closes and the user keeps:
 *   - their typed query in BQB/CQB
 *   - any in-flight execution (resumes via localStorage)
 *   - open tabs, scroll position, filter panel state
 *
 * Architectural principle: HTTP errors NEVER unmount the React tree.
 */
import React, { useState } from 'react';
import {
  TextField, Button, Alert, Box, Typography, CircularProgress,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import { useAuth } from '../context/AuthContext';

const ReauthModal: React.FC = () => {
  const { reauthRequired, clearReauthRequired, login, user } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Pre-fill username from the previously-authenticated session if available
  // — admin doesn't have to retype their own name
  React.useEffect(() => {
    if (reauthRequired && user?.username && !username) {
      setUsername(user.username);
    }
  }, [reauthRequired, user, username]);

  if (!reauthRequired) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) return;
    setLoading(true);
    setError(null);
    try {
      await login(username.trim(), password);
      // Success — close the modal.  Nothing else unmounts.
      setPassword('');
      clearReauthRequired();
    } catch (err) {
      const msg = (err as Error).message || 'Login failed';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppDialog
      open
      size="xs"
      disableEscapeKeyDown
      // No onClose handler — user MUST re-auth to dismiss.  Backdrop click
      // also cannot close (no onClose = backdrop is inert).
      slotProps={{
        paper: { sx: { borderTop: '4px solid', borderColor: 'warning.main' } },
      }}
      icon={<LockOutlinedIcon color="warning" />}
      title="Session expired"
      actions={
        <Button
          variant="contained"
          onClick={handleSubmit}
          disabled={loading || !username.trim() || !password}
          startIcon={loading ? <CircularProgress size={16} /> : <LockOutlinedIcon />}
        >
          {loading ? 'Signing in...' : 'Sign in'}
        </Button>
      }
    >
        <Alert severity="info" sx={{ mb: 2 }}>
          Your authentication session expired during the request. Sign in again
          to continue — <strong>your typed query, in-flight executions, and open tabs are preserved.</strong>
        </Alert>
        <Box component="form" onSubmit={handleSubmit} noValidate>
          <TextField
            label="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            fullWidth
            margin="normal"
            autoFocus={!username}
            disabled={loading}
            autoComplete="username"
          />
          <TextField
            label="Password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            fullWidth
            margin="normal"
            autoFocus={Boolean(username)}
            disabled={loading}
            autoComplete="current-password"
          />
          {error && (
            <Alert severity="error" sx={{ mt: 1 }}>{error}</Alert>
          )}
        </Box>
    </AppDialog>
  );
};

export default ReauthModal;
