/**
 * Switched off -- every deleted configuration item, and the way back (2026-10-30).
 *
 * The owner: every config table has an active column; deleting switches an
 * item off instead of erasing it.  This is the ONE place to see them and press
 * Switch on (backend: api/config_active_api.py).  An admin sees everything;
 * anyone else the datasets, reports, queries, dashboards and value lists they
 * own.  A switched-off item is not used anywhere until it is switched on.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, Paper, Stack, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TextField, Typography,
} from '@mui/material';
import { PowerSettingsNew as SwitchOnIcon, Refresh as RefreshIcon } from '@mui/icons-material';
import { safeFetch } from '../services/api/core';
import { appConfirm } from './common/appDialogs';

export interface SwitchedOffItem {
  table: string;
  what: string;
  id: number;
  name: string;
  owner?: string | null;
  switched_off_at?: string | null;
  switched_off_by?: string | null;
}

function when(v?: string | null): string {
  if (!v) return '—';
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? v : d.toLocaleString();
}

export default function SwitchedOffPage() {
  const [items, setItems] = useState<SwitchedOffItem[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoadError(null);
    try {
      const r = await safeFetch('/api/config/switched-off');
      setItems(Array.isArray(r?.items) ? r.items : []);
    } catch (e: any) {
      setLoadError(e?.message || String(e));
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const shown = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? items.filter(i => `${i.what} ${i.name} ${i.owner || ''}`.toLowerCase().includes(q)) : items;
  }, [items, search]);

  const switchOn = async (item: SwitchedOffItem) => {
    if (!await appConfirm(`Switch the ${item.what} "${item.name}" back on? It is used again from now on.`,
      { confirmText: 'Switch on' })) return;
    const key = `${item.table}:${item.id}`;
    setBusy(key);
    setMessage(null);
    try {
      const r = await safeFetch(`/api/config/switched-off/${item.table}/${item.id}/switch-on`, { method: 'POST' });
      setMessage({ ok: true, text: r?.detail || `${item.name} is switched on.` });
      await load();
    } catch (e: any) {
      setMessage({ ok: false, text: e?.message || String(e) });
    } finally {
      setBusy(null);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" sx={{ mb: 1 }} spacing={1}>
        <Typography variant="h5" sx={{ flex: 1 }}>Switched Off</Typography>
        <Button startIcon={<RefreshIcon />} onClick={() => void load()}>Refresh</Button>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        When you delete a dataset, report, feed, calendar, schedule or any other setting, it is switched off,
        not erased. It is not used anywhere until someone switches it back on here.
      </Typography>
      {message && <Alert severity={message.ok ? 'success' : 'error'} sx={{ mb: 2 }}
                         onClose={() => setMessage(null)} data-testid="switched-off-message">{message.text}</Alert>}
      {loadError && <Alert severity="error" sx={{ mb: 2 }}>Could not read what is switched off: {loadError}</Alert>}
      <TextField size="small" placeholder="Search by name, kind or owner" value={search}
                 onChange={e => setSearch(e.target.value)} sx={{ mb: 2, width: 360, maxWidth: '100%' }} />
      <TableContainer component={Paper}>
        <Table size="small" aria-label="Switched-off items">
          <TableHead><TableRow>
            <TableCell>Name</TableCell><TableCell>Kind</TableCell><TableCell>Owner</TableCell>
            <TableCell>Switched off</TableCell><TableCell />
          </TableRow></TableHead>
          <TableBody>
            {shown.map(i => {
              const key = `${i.table}:${i.id}`;
              return (
                <TableRow key={key} data-testid={`switched-off-${i.table}-${i.id}`}>
                  <TableCell>{i.name}</TableCell>
                  <TableCell><Chip size="small" variant="outlined" label={i.what} /></TableCell>
                  <TableCell>{i.owner || '—'}</TableCell>
                  <TableCell>{when(i.switched_off_at)}{i.switched_off_by ? ` by ${i.switched_off_by}` : ''}</TableCell>
                  <TableCell align="right">
                    <Button size="small" variant="outlined" startIcon={<SwitchOnIcon />} disabled={busy === key}
                            onClick={() => void switchOn(i)}>{busy === key ? 'Switching on…' : 'Switch on'}</Button>
                  </TableCell>
                </TableRow>
              );
            })}
            {loaded && !loadError && shown.length === 0 && (
              <TableRow><TableCell colSpan={5}>
                <Typography variant="body2" color="text.secondary">
                  {items.length ? 'Nothing matches the search.' : 'Nothing is switched off.'}
                </Typography>
              </TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}
