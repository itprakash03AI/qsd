/**
 * FederationViewsPage — Admin CRUD for cross-connection saved queries (Phase 93).
 *
 * Users can create named "Oracle-style views" that JOIN or UNION results from
 * two connections of ANY supported type -- S3 / local (pick registered tables)
 * or a SQL connector such as Snowflake, Trino, Oracle (write that side's SQL;
 * 2026-10-04, the backend runs each side on its own engine).  These views can
 * then be published as APIs or used as data sources in business reports.
 */
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableHead, TableRow, TableCell,
  TableBody, IconButton, Dialog,
  Chip, Alert, CircularProgress, Tooltip, TableContainer,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import PreviewIcon from '@mui/icons-material/Visibility';
import PublishIcon from '@mui/icons-material/CloudUpload';
import StorageIcon from '@mui/icons-material/Storage';
import api from '../services/api';
// BF-489 (2026-05-27) — Federation Views can now be published as APIs
// directly from this page.  Backend (source_type="federation") +
// PublishViewDialog already supported this since Phase 93 — only the
// frontend button was missing.  Mounts the same dialog the other 4
// entry points use; the dialog handles federation-specific branches
// internally (preview disabled, payload sends federation_view_id).
import PublishViewDialog from './PublishViewDialog';
import ListPager, { clientPage } from './common/ListPager';
import FederationViewEditorDialog, {
  EMPTY_VIEW, FederationView, FederationConnection as Connection,
} from './federation/FederationViewEditorDialog';

const FederationViewsPage: React.FC = () => {
  const [views, setViews] = useState<FederationView[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editView, setEditView] = useState<Partial<FederationView> | null>(null);
  const [error, setError] = useState('');
  const [previewData, setPreviewData] = useState<any>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);
  const [materializingIds, setMaterializingIds] = useState<Set<number>>(new Set());
  // BF-489 — Publish-as-API dialog state.  Holds the FV we're publishing
  // (null = dialog closed).
  const [publishFv, setPublishFv] = useState<FederationView | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [fvs, conns] = await Promise.all([
        api.listFederationViews(),
        api.listConnections(),
      ]);
      setViews(fvs);
      setConnections(conns);
    } catch (e: any) {
      setError(e.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // Poll while any view is materializing — the backend runs it on a daemon
  // thread and (unlike MV refresh) sends no WebSocket event, so without
  // polling the row showed MATERIALIZING forever until a manual reload.
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => {
    const busy = views.some(v => v.status === 'materializing');
    if (busy && !pollRef.current) {
      pollRef.current = setInterval(() => loadData(), 5000);
    } else if (!busy && pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    return () => { if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; } };
  }, [views, loadData]);

  const handleMaterialize = async (fv: FederationView) => {
    setMaterializingIds(prev => new Set(prev).add(fv.id));
    try {
      await api.materializeFederationView(fv.id);
      loadData();
    } catch (e: any) {
      setError(e.message || 'Materialize failed');
    } finally {
      setMaterializingIds(prev => { const n = new Set(prev); n.delete(fv.id); return n; });
    }
  };

  const handleCreate = () => {
    setEditView({ ...EMPTY_VIEW });
    setError('');
    setDialogOpen(true);
  };

  const handleEdit = (fv: FederationView) => {
    setEditView({ ...fv });
    setError('');
    setDialogOpen(true);
  };

  const handleDelete = async (id: number) => {
    try {
      await api.deleteFederationView(id);
      setDeleteConfirm(null);
      loadData();
    } catch (e: any) {
      setError(e.message || 'Delete failed');
    }
  };

  const handlePreview = async (id: number) => {
    setPreviewLoading(true);
    setPreviewOpen(true);
    setPreviewData(null);
    try {
      const result = await api.previewFederationView(id);
      setPreviewData(result);
    } catch (e: any) {
      setPreviewData({ error: e.message || 'Preview failed' });
    } finally {
      setPreviewLoading(false);
    }
  };

  const getConnName = (id: number) =>
    connections.find(c => c.id === id)?.name || `Connection #${id}`;

  if (loading) {
    return <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}><CircularProgress /></Box>;
  }

  const shown = clientPage(views, page, pageSize);

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5">Federation Views</Typography>
        <Button variant="contained" startIcon={<AddIcon />} onClick={handleCreate}>
          Create View
        </Button>
      </Box>

      {error && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      <TableContainer component={Paper}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Primary</TableCell>
              <TableCell>Secondary</TableCell>
              <TableCell>Mode</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Active</TableCell>
              <TableCell>Created</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {views.length === 0 && (
              <TableRow><TableCell colSpan={9} align="center">No federation views yet</TableCell></TableRow>
            )}
            {shown.rows.map(fv => (
              <TableRow key={fv.id} hover>
                <TableCell><strong>{fv.name}</strong></TableCell>
                <TableCell>{fv.description || '—'}</TableCell>
                <TableCell><Chip label={getConnName(fv.primary_conn_id)} size="small" /></TableCell>
                <TableCell><Chip label={getConnName(fv.secondary_conn_id)} size="small" /></TableCell>
                <TableCell>
                  <Chip
                    label={fv.combine_mode === 'join' ? `${(fv.join_how || 'inner').toUpperCase()} JOIN` : 'UNION'}
                    size="small"
                    color={fv.combine_mode === 'join' ? 'primary' : 'secondary'}
                  />
                </TableCell>
                <TableCell>
                  {(() => {
                    const st = fv.status || 'virtual';
                    const colorMap: Record<string, 'default' | 'warning' | 'success' | 'error'> = {
                      virtual: 'default', materializing: 'warning', ready: 'success', failed: 'error',
                    };
                    return (
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                        <Chip label={st.toUpperCase()} size="small" color={colorMap[st] || 'default'} />
                        {st === 'ready' && fv.row_count != null && (
                          <Typography variant="caption" color="text.secondary">
                            {fv.row_count.toLocaleString()} rows
                          </Typography>
                        )}
                      </Box>
                    );
                  })()}
                </TableCell>
                <TableCell>{fv.is_active ? 'Yes' : 'No'}</TableCell>
                <TableCell>{fv.created_at ? new Date(fv.created_at).toLocaleDateString() : ''}</TableCell>
                <TableCell align="right">
                  <Tooltip title="Materialize to Parquet">
                    <span>
                      <IconButton aria-label="Materialize to Parquet"
                        size="small"
                        color="success"
                        onClick={() => handleMaterialize(fv)}
                        disabled={materializingIds.has(fv.id)}
                      >
                        {materializingIds.has(fv.id) ? <CircularProgress size={18} /> : <StorageIcon />}
                      </IconButton>
                    </span>
                  </Tooltip>
                  <Tooltip title="Preview"><IconButton size="small" onClick={() => handlePreview(fv.id)}><PreviewIcon /></IconButton></Tooltip>
                  {/* BF-489 — Publish as API.  Only offered for active
                      Federation Views since the consumer-facing endpoint
                      will refuse to execute against a deactivated FV. */}
                  {fv.is_active && (
                    <Tooltip title="Publish as API">
                      <IconButton
                        size="small"
                        color="primary"
                        onClick={() => setPublishFv(fv)}
                      >
                        <PublishIcon />
                      </IconButton>
                    </Tooltip>
                  )}
                  <Tooltip title="Edit"><IconButton size="small" onClick={() => handleEdit(fv)}><EditIcon /></IconButton></Tooltip>
                  <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => setDeleteConfirm(fv.id)}><DeleteIcon /></IconButton></Tooltip>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <ListPager paging={shown.paging} onPage={setPage} onPageSize={setPageSize}
                   testid="federation-views-pager" />
      </TableContainer>

      {/* BF-489 — Publish-as-API dialog.  Mounted with sourceType='federation'
          + federationViewId; the dialog sends the right backend payload
          (source_type='federation', federation_view_id=<id>) on submit.
          Columns prop fed from output_columns OR schema_cache so the
          WHERE-clause editor's column dropdown isn't empty (federation
          source has no live preview to populate it from). */}
      {publishFv && (
        <PublishViewDialog
          open={!!publishFv}
          onClose={() => setPublishFv(null)}
          queryName={publishFv.name || ''}
          sourceType="federation"
          federationViewId={publishFv.id}
          columns={
            (publishFv.output_columns && publishFv.output_columns.length > 0)
              ? publishFv.output_columns
              : (publishFv.schema_cache || [])
                  .map((c: any) => (typeof c === 'string' ? c : c?.name))
                  .filter((s: any): s is string => typeof s === 'string' && !!s)
          }
        />
      )}

      {/* ── Create / Edit Dialog: the ONE federation editor, shared with the
          Published API screen's "New cross-source API" (2026-10-23). */}
      <FederationViewEditorDialog
        open={dialogOpen}
        initial={editView}
        connections={connections}
        onClose={() => setDialogOpen(false)}
        onSaved={() => { setDialogOpen(false); setEditView(null); loadData(); }}
      />

      {/* ── Preview Dialog ────────────────────────────────────────────────── */}
      <AppDialog open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        size="lg"
        title="Preview Results"
        actions={<>
          <Button onClick={() => setPreviewOpen(false)}>Close</Button>
        </>}>
          {previewLoading && <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}><CircularProgress /></Box>}
          {previewData?.error && <Alert severity="error">{previewData.error}</Alert>}
          {previewData && !previewData.error && (
            <>
              {/* BF-565 (2026-05-29): consume BF-525 type_mismatches
                  signal.  When the federation engine auto-promoted
                  cross-side type mismatches (e.g. DECIMAL ↔ FLOAT),
                  surface a warning so the user knows downstream
                  aggregations may have lost precision. */}
              {Array.isArray(previewData.type_mismatches) && previewData.type_mismatches.length > 0 && (
                <Alert severity="warning" sx={{ mb: 1 }}>
                  <strong>Type mismatch across sides:</strong> DuckDB auto-promoted these columns and
                  downstream aggregations may have lost precision —
                  <ul style={{ margin: '4px 0 0 0', paddingLeft: 18 }}>
                    {previewData.type_mismatches.map((m: string, i: number) => (
                      <li key={i}><code>{m}</code></li>
                    ))}
                  </ul>
                </Alert>
              )}
              <Typography variant="body2" sx={{ mb: 1 }}>
                Total: {previewData.total_rows} rows | Showing: {previewData.returned_rows}
              </Typography>
              <TableContainer component={Paper} sx={{ maxHeight: 400 }}>
                <Table size="small" stickyHeader>
                  <TableHead>
                    <TableRow>
                      {(previewData.columns || []).map((c: any) => (
                        <TableCell key={c.name}><strong>{c.name}</strong></TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {(previewData.data || []).map((row: any, ri: number) => (
                      <TableRow key={ri}>
                        {(previewData.columns || []).map((c: any) => (
                          <TableCell key={c.name}>
                            {row[c.name] != null ? String(row[c.name]).slice(0, 100) : ''}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </>
          )}
      </AppDialog>

      {/* ── Delete Confirmation ───────────────────────────────────────────── */}
      <AppDialog open={deleteConfirm !== null}
        onClose={() => setDeleteConfirm(null)}
        size="xs"
        dividers={false}
        title="Delete Federation View?"
        actions={<>
          <Button onClick={() => setDeleteConfirm(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={() => deleteConfirm && handleDelete(deleteConfirm)}>
            Delete
          </Button>
        </>}>
          <Typography>Published APIs and reports that use this federation view will stop working. It is switched off, not erased -- an admin or its owner can switch it back on under Admin -&gt; Switched off.</Typography>
      </AppDialog>
    </Box>
  );
};

export default FederationViewsPage;
