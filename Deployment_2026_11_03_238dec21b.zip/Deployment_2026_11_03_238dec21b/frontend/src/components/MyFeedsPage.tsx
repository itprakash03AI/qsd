/**
 * MyFeedsPage (2026-09-28) -- delivery receipts for feed CONSUMERS.
 *
 * docs/FEATURE_STRATEGY_2026_09_28.html #3.  A downstream team (often the
 * viewer role) reads, per feed and business date, the RECEIPT the platform
 * assembled from its own records: the file name, rows, bytes, checksum, the
 * completeness certificate, the delivery chain verdict, delivered-at vs the
 * SLA, and any decision taken (a skipped dependency with its reason).  ONE
 * control per feed: "Notify me" (delivered / late / failed, by bell and
 * e-mail).  No rerun, no skip, no redeliver, no SQL, no config.
 *
 * Reads GET /api/my-feeds and GET /api/my-feeds/receipts
 * (backend/api/feed_consumer_api.py).  Unknown is rendered as UNKNOWN, never
 * as delivered; a refused receipt (404) shows the server's sentence.
 * `?receipt=<run id>` opens that run's receipt (the Support Desk's "Copy
 * receipt link" and the bell's href point here).
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Alert, Box, Button, Checkbox, Chip, CircularProgress, FormControlLabel, FormGroup, MenuItem, Paper,
  Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Tooltip,
  Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Refresh as RefreshIcon, ReceiptLong as ReceiptIcon,
  NotificationsActive as NotifyIcon, Print as PrintIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { resolveApiBaseUrl } from '../services/api/core';
import type {
  ConsumerEvent, MyFeedRow, Receipt, ReceiptOutcome,
} from '../services/api/myFeeds';
import RowActions from './common/RowActions';
import { STICKY_ACTIONS_SX, TABLE_SCROLL_SX } from './common/stickyActions';
import ListPager, { clientPage } from './common/ListPager';

// ── pure rendering helpers (exported for tests) ──────────────────────────

export const OUTCOME_LABEL: Record<ReceiptOutcome, string> = {
  delivered: 'Delivered',
  not_delivered: 'Not delivered (by design)',
  failed: 'Failed — not delivered',
  skipped: 'Skipped — not delivered',
  waiting: 'Waiting on a dependency',
  pending: 'Not started',
  running: 'Running',
  unknown: "Unknown — can't check right now",
};

export const outcomeColor = (o: ReceiptOutcome): 'success' | 'error' | 'warning' | 'default' | 'info' => {
  if (o === 'delivered') return 'success';
  if (o === 'failed') return 'error';
  if (o === 'unknown' || o === 'waiting' || o === 'skipped') return 'warning';
  if (o === 'running') return 'info';
  return 'default';
};

export const fmtBytes = (n: number | null | undefined): string => {
  if (n == null) return 'unknown';
  let v = n;
  for (const unit of ['B', 'KB', 'MB', 'GB', 'TB']) {
    if (v < 1024 || unit === 'TB') return unit === 'B' ? `${v.toLocaleString()} B` : `${v.toFixed(1)} ${unit}`;
    v = v / 1024;
  }
  return String(n);
};

const fmtTs = (v: string | null | undefined): string => {
  if (!v) return '--';
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? v : d.toISOString().replace('T', ' ').slice(0, 16) + ' UTC';
};

/** "on time" / "LATE by N min" / "overdue by N min" / "no SLA declared" / "--". */
export const slaLine = (r: Receipt): string => {
  const s = r.sla;
  if (!s.sla_at) return 'no SLA declared';
  if (s.late === false) return `on time (SLA ${fmtTs(s.sla_at)})`;
  if (s.late === true && r.outcome === 'delivered') return `LATE by ${s.minutes_late ?? '?'} min (SLA ${fmtTs(s.sla_at)})`;
  if (s.late === true) return `overdue by ${s.minutes_late ?? '?'} min — nothing delivered (SLA ${fmtTs(s.sla_at)})`;
  return `SLA ${fmtTs(s.sla_at)}`;
};

const EVENT_HELP: Record<ConsumerEvent, string> = {
  delivered: 'when the file has been delivered (with rows, size, checksum and the certificate)',
  late: 'when the SLA passes and nothing has been delivered for the day',
  failed: 'when the run fails or is cancelled, so no file is coming from it',
};

// ── the page ─────────────────────────────────────────────────────────────

const MyFeedsPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [feeds, setFeeds] = useState<MyFeedRow[]>([]);
  const [events, setEvents] = useState<ConsumerEvent[]>(['delivered', 'late', 'failed']);
  const [days, setDays] = useState<number>(7);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [unavailable, setUnavailable] = useState<Array<{ feed_id: number; reason: string }>>([]);
  const [window, setWindow] = useState<{ from: string; to: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [feedFilter, setFeedFilter] = useState<number | ''>('');
  const [open, setOpen] = useState<Receipt | null>(null);
  const [openError, setOpenError] = useState<string | null>(null);
  const [notify, setNotify] = useState<MyFeedRow | null>(null);
  const [notice, setNotice] = useState<{ tone: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const feedById = useMemo(() => {
    const m = new Map<number, MyFeedRow>();
    feeds.forEach(f => m.set(f.id, f));
    return m;
  }, [feeds]);
  const feedLabel = (id: number, fallback?: string | null) => {
    const f = feedById.get(id);
    return f ? (f.display_name || f.name) : (fallback || `feed #${id}`);
  };

  const load = useCallback(async (d: number) => {
    setLoading(true);
    setError(null);
    try {
      const mine = await api.listMyFeeds();
      setFeeds(mine.feeds || []);
      setEvents(mine.events || ['delivered', 'late', 'failed']);
      const rc = await api.listMyReceipts({ days: d });
      setReceipts(rc.receipts || []);
      setUnavailable(rc.unavailable || []);
      setWindow({ from: rc.business_date_from, to: rc.business_date_to });
    } catch (e: any) {
      setError(e?.message || 'My Feeds could not be loaded');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(days); }, [load, days]);

  // ?receipt=<run id> -- open that run's receipt (from a copied link / the bell)
  const wanted = searchParams.get('receipt');
  useEffect(() => {
    if (!wanted) return;
    let cancelled = false;
    (async () => {
      try {
        const r = await api.getMyReceipt(wanted);
        if (!cancelled) { setOpen(r); setOpenError(null); }
      } catch (e: any) {
        if (!cancelled) setOpenError(e?.message || `receipt ${wanted} could not be read`);
      }
    })();
    return () => { cancelled = true; };
  }, [wanted]);

  const closeReceipt = () => {
    setOpen(null);
    setOpenError(null);
    if (wanted) {
      const next = new URLSearchParams(searchParams);
      next.delete('receipt');
      setSearchParams(next, { replace: true });
    }
  };

  const shown = feedFilter === '' ? receipts : receipts.filter(r => r.feed.id === feedFilter);
  const pg = clientPage(shown, page, pageSize);

  const printable = (r: Receipt) => {
    const href = `${resolveApiBaseUrl()}${api.myReceiptHtmlPath(r.run.id)}`;
    globalThis.open(href, '_blank', 'noopener');
  };

  return (
    <Box sx={{ p: 2 }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
        <ReceiptIcon color="primary" />
        <Typography variant="h5" sx={{ flex: 1 }}>My Feeds</Typography>
        <TextField select size="small" label="Window" value={days}
                   onChange={e => { setDays(Number(e.target.value)); setPage(1); }} sx={{ minWidth: 140 }}>
          {[1, 3, 7, 14, 31].map(d => <MenuItem key={d} value={d}>last {d} day{d > 1 ? 's' : ''}</MenuItem>)}
        </TextField>
        <TextField select size="small" label="Feed" value={feedFilter === '' ? '' : String(feedFilter)}
                   onChange={e => { setFeedFilter(e.target.value === '' ? '' : Number(e.target.value)); setPage(1); }}
                   sx={{ minWidth: 200 }}>
          <MenuItem value=""><em>All my feeds</em></MenuItem>
          {feeds.map(f => <MenuItem key={f.id} value={String(f.id)}>{f.display_name || f.name}</MenuItem>)}
        </TextField>
        <Tooltip title="Reload">
          <span><Button size="small" startIcon={<RefreshIcon />} onClick={() => void load(days)}
                        disabled={loading} aria-label="Reload my feeds">Reload</Button></span>
        </Tooltip>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        The delivery receipts of the feeds delivered to your team, assembled from the platform's own
        records. Read-only: to change a feed, ask its owner.
        {window ? ` Business dates ${window.from} to ${window.to}.` : ''}
      </Typography>

      {notice && (
        <Alert severity={notice.tone} sx={{ mb: 2 }} onClose={() => setNotice(null)}>{notice.text}</Alert>
      )}
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {openError && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={closeReceipt} data-testid="receipt-error">
          The receipt could not be opened: {openError}
        </Alert>
      )}
      {unavailable.length > 0 && (
        <Alert severity="warning" sx={{ mb: 2 }} data-testid="receipts-unavailable">
          Some receipts could not be read (an empty list below is NOT evidence for these):
          {' '}{unavailable.map(u => `${feedLabel(u.feed_id)}: ${u.reason}`).join('; ')}
        </Alert>
      )}

      {/* the feeds and their subscriptions */}
      <Paper variant="outlined" sx={{ p: 1.5, mb: 2 }}>
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Your feeds ({feeds.length})</Typography>
        {loading && feeds.length === 0 ? (
          <CircularProgress size={20} />
        ) : feeds.length === 0 ? (
          <Typography variant="body2" color="text.secondary" data-testid="no-feeds">
            You are not declared as a consumer of any feed. Ask the feed's owner to add your
            entitlement group under "Consumer groups" on the feed.
          </Typography>
        ) : (
          <Stack direction="row" flexWrap="wrap" gap={1}>
            {feeds.map(f => (
              <Paper key={f.id} variant="outlined" sx={{ p: 1, minWidth: 260 }} data-testid={`my-feed-${f.id}`}>
                <Stack direction="row" alignItems="center" spacing={1}>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>{f.display_name || f.name}</Typography>
                    <Typography variant="caption" color="text.secondary">
                      {f.sla_to ? `SLA ${f.sla_to} ${f.sla_timezone}` : 'no SLA declared'}
                      {f.is_active ? '' : ' · inactive'}
                    </Typography>
                    <Box sx={{ mt: 0.5 }}>
                      {f.subscription && f.subscription.events.length > 0
                        ? f.subscription.events.map(ev => <Chip key={ev} size="small" label={`notify: ${ev}`} sx={{ mr: 0.5 }} />)
                        : <Chip size="small" variant="outlined" label="no notifications" />}
                    </Box>
                  </Box>
                  <Tooltip title="Notify me: delivered / late / failed">
                    <Button size="small" startIcon={<NotifyIcon />} onClick={() => setNotify(f)}
                            aria-label={`Notify me — ${f.display_name || f.name}`}>Notify me</Button>
                  </Tooltip>
                </Stack>
              </Paper>
            ))}
          </Stack>
        )}
      </Paper>

      {/* the receipts */}
      <Paper variant="outlined" sx={TABLE_SCROLL_SX}>
        <Table size="small" aria-label="Delivery receipts">
          <TableHead>
            <TableRow>
              <TableCell>Feed</TableCell>
              <TableCell>Business date</TableCell>
              <TableCell>Outcome</TableCell>
              <TableCell>File</TableCell>
              <TableCell align="right">Rows</TableCell>
              <TableCell align="right">Size</TableCell>
              <TableCell>Certified</TableCell>
              <TableCell>Delivered at</TableCell>
              <TableCell>Against SLA</TableCell>
              <TableCell>Decisions</TableCell>
              <TableCell sx={STICKY_ACTIONS_SX}>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading && shown.length === 0 && (
              <TableRow><TableCell colSpan={11}><CircularProgress size={18} /></TableCell></TableRow>
            )}
            {!loading && shown.length === 0 && (
              <TableRow>
                <TableCell colSpan={11}>
                  <Typography variant="body2" color="text.secondary" data-testid="no-receipts">
                    No runs in this window for {feedFilter === '' ? 'your feeds' : feedLabel(feedFilter)}.
                  </Typography>
                </TableCell>
              </TableRow>
            )}
            {pg.rows.map(r => (
              <TableRow key={r.receipt_id} data-testid={`receipt-${r.run.id}`}>
                <TableCell>{feedLabel(r.feed.id, r.feed.display_name || r.feed.name)}</TableCell>
                <TableCell>{r.business_date}{r.run.run_type !== 'scheduled' ? ` (${r.run.run_type})` : ''}</TableCell>
                <TableCell>
                  <Tooltip title={r.outcome_reason || (r.unknown.length ? r.unknown.join('; ') : '')}>
                    <Chip size="small" color={outcomeColor(r.outcome)} label={OUTCOME_LABEL[r.outcome] || r.outcome} />
                  </Tooltip>
                </TableCell>
                <TableCell sx={{ fontFamily: 'monospace', fontSize: 12 }}>{r.file.name || 'unknown'}</TableCell>
                <TableCell align="right">{r.file.rows != null ? r.file.rows.toLocaleString() : 'unknown'}</TableCell>
                <TableCell align="right">{fmtBytes(r.file.size_bytes)}</TableCell>
                <TableCell>{r.completeness.state ? r.completeness.state.toUpperCase() : 'not certified'}</TableCell>
                <TableCell>{fmtTs(r.sla.delivered_at)}</TableCell>
                <TableCell>{slaLine(r)}</TableCell>
                <TableCell>
                  {r.decisions === null ? 'could not be read'
                    : r.decisions.length === 0 ? '--'
                      : r.decisions.map((d, i) => (
                        <Typography key={i} variant="caption" display="block">
                          {d.event_type}{d.dependency ? ` ${d.dependency}` : ''}{d.reason ? ` — ${d.reason}` : ''}
                        </Typography>
                      ))}
                </TableCell>
                <TableCell sx={STICKY_ACTIONS_SX}>
                  <RowActions rowName={`${feedLabel(r.feed.id, r.feed.name)} ${r.business_date}`}
                    primary={[
                      { label: 'View receipt', icon: <ReceiptIcon fontSize="small" />,
                        onClick: () => { setOpen(r); setOpenError(null); } },
                    ]}
                    more={[
                      { label: 'Printable receipt', icon: <PrintIcon fontSize="small" />,
                        description: 'Opens the receipt as a printable page', onClick: () => printable(r) },
                    ]} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {shown.length > 0 && (
          <ListPager paging={pg.paging} onPage={setPage} onPageSize={setPageSize} testid="receipts-pager" />
        )}
      </Paper>

      <ReceiptDialog receipt={open} onClose={closeReceipt} onPrint={printable} feedLabel={feedLabel} />
      <NotifyMeDialog feed={notify} events={events} onClose={() => setNotify(null)}
                      onSaved={(text, tone) => { setNotice({ tone, text }); setNotify(null); void load(days); }} />
    </Box>
  );
};

// ── the receipt dialog ───────────────────────────────────────────────────

const Row: React.FC<{ k: string; children: React.ReactNode }> = ({ k, children }) => (
  <TableRow>
    <TableCell sx={{ fontWeight: 600, width: 180 }}>{k}</TableCell>
    <TableCell>{children}</TableCell>
  </TableRow>
);

const ReceiptDialog: React.FC<{
  receipt: Receipt | null; onClose: () => void; onPrint: (r: Receipt) => void;
  feedLabel: (id: number, fallback?: string | null) => string;
}> = ({ receipt, onClose, onPrint, feedLabel }) => {
  if (!receipt) return null;
  const r = receipt;
  return (
    <AppDialog open
      onClose={onClose}
      size="md"
      aria-labelledby="receipt-title"
      titleId="receipt-title"
      title={<>Delivery receipt — {feedLabel(r.feed.id, r.feed.display_name || r.feed.name)} — {r.business_date}</>}
      actions={<>
        <Button startIcon={<PrintIcon />} onClick={() => onPrint(r)}>Printable</Button>
        <Button onClick={onClose}>Close</Button>
      </>}>
        <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
          <Chip color={outcomeColor(r.outcome)} label={OUTCOME_LABEL[r.outcome] || r.outcome} data-testid="receipt-outcome" />
          {r.outcome_reason && <Typography variant="body2">{r.outcome_reason}</Typography>}
        </Stack>
        <Table size="small">
          <TableBody>
            <Row k="Receipt">{r.receipt_id}</Row>
            <Row k="Run">#{r.run.id} ({r.run.run_type}){r.run.error ? ` — ${r.run.error}` : ''}</Row>
            <Row k="File">{r.file.name || 'unknown'}</Row>
            <Row k="Rows">{r.file.rows != null ? r.file.rows.toLocaleString() : 'unknown'}</Row>
            <Row k="Size">{fmtBytes(r.file.size_bytes)}</Row>
            <Row k="Checksum">{r.file.checksum ? `${r.file.checksum_algorithm || ''} ${r.file.checksum}`.trim() : 'none recorded'}</Row>
            <Row k="Completeness">
              {(r.completeness.state || 'not certified').toUpperCase()}
              {r.completeness.reasons.length ? `: ${r.completeness.reasons.join('; ')}` : ''}
            </Row>
            <Row k="Delivery chain">{r.delivery.verdict || 'no verdict recorded'}{r.delivery.reason ? ` — ${r.delivery.reason}` : ''}</Row>
            <Row k="Delivered at">{fmtTs(r.sla.delivered_at)}</Row>
            <Row k="Against SLA">{slaLine(r)}</Row>
          </TableBody>
        </Table>
        {r.delivery.hops.length > 0 && (
          <>
            <Typography variant="subtitle2" sx={{ mt: 2 }}>Delivery hops</Typography>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Hop</TableCell><TableCell>Type</TableCell><TableCell>Attempt</TableCell>
                  <TableCell>Status</TableCell><TableCell>Verified</TableCell><TableCell>Completed</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {r.delivery.hops.map((h, i) => (
                  <TableRow key={i}>
                    <TableCell>{h.hop || '--'}</TableCell><TableCell>{h.target_type || '--'}</TableCell>
                    <TableCell>{h.attempt ?? '--'}</TableCell><TableCell>{h.status || '--'}</TableCell>
                    <TableCell>{h.verification || '--'}</TableCell><TableCell>{fmtTs(h.completed_at)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </>
        )}
        <Typography variant="subtitle2" sx={{ mt: 2 }}>Decisions</Typography>
        {r.decisions === null ? (
          <Alert severity="warning">The decision ledger could not be read.</Alert>
        ) : r.decisions.length === 0 ? (
          <Typography variant="body2" color="text.secondary">No dependency was skipped or overridden for this run.</Typography>
        ) : (
          <ul>
            {r.decisions.map((d, i) => (
              <li key={i}>
                <b>{d.event_type}</b> {d.dependency || ''} by {d.actor || 'unknown'} at {fmtTs(d.at)}
                {d.reason ? ` — ${d.reason}` : ''}
              </li>
            ))}
          </ul>
        )}
        {r.unknown.length > 0 && (
          <Alert severity="warning" sx={{ mt: 2 }} data-testid="receipt-unknown">
            Could not be read: {r.unknown.join('; ')}
          </Alert>
        )}
    </AppDialog>
  );
};

// ── notify me ────────────────────────────────────────────────────────────

const NotifyMeDialog: React.FC<{
  feed: MyFeedRow | null; events: ConsumerEvent[]; onClose: () => void;
  onSaved: (text: string, tone: 'success' | 'info') => void;
}> = ({ feed, events, onClose, onSaved }) => {
  const [chosen, setChosen] = useState<ConsumerEvent[]>([]);
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (feed) {
      setChosen(feed.subscription?.events || []);
      setEmail(feed.subscription?.email || '');
      setErr(null);
    }
  }, [feed]);

  if (!feed) return null;
  const label = feed.display_name || feed.name;
  const toggle = (ev: ConsumerEvent) =>
    setChosen(c => (c.includes(ev) ? c.filter(x => x !== ev) : [...c, ev]));

  const save = async () => {
    setBusy(true);
    setErr(null);
    try {
      const out = await api.putMySubscription(feed.id, { events: chosen, email: email.trim() || null });
      if (!out.subscription) {
        onSaved(`Notifications for ${label} switched off.`, 'info');
      } else {
        onSaved(`You will be told about ${label}: ${out.subscription.events.join(', ')}`
          + (out.subscription.email ? ` (bell + e-mail to ${out.subscription.email})` : ' (bell only)')
          + (out.email_note ? `. Note: ${out.email_note}` : '.'), 'success');
      }
    } catch (e: any) {
      setErr(e?.message || 'The subscription could not be saved');
    } finally {
      setBusy(false);
    }
  };

  return (
    <AppDialog open
      onClose={onClose}
      size="sm"
      aria-labelledby="notify-title"
      titleId="notify-title"
      title={<>Notify me — {label}</>}
      actions={<>
        <Button onClick={onClose} disabled={busy}>Cancel</Button>
        <Button variant="contained" onClick={() => void save()} disabled={busy}>
          {chosen.length ? 'Save' : 'Switch off'}
        </Button>
      </>}>
        <FormGroup>
          {events.map(ev => (
            <FormControlLabel key={ev}
              control={<Checkbox checked={chosen.includes(ev)} onChange={() => toggle(ev)} />}
              label={<span><b>{ev}</b> — {EVENT_HELP[ev]}</span>} />
          ))}
        </FormGroup>
        <TextField label="E-mail (optional — the bell is always on)" value={email}
                   onChange={e => setEmail(e.target.value)} fullWidth size="small" sx={{ mt: 2 }}
                   helperText="Each notice is sent once per event: a second watcher pass never repeats it." />
        {err && <Alert severity="error" sx={{ mt: 2 }}>{err}</Alert>}
    </AppDialog>
  );
};

export default MyFeedsPage;
