/**
 * FeedGroupsPage — operational feed groups as a managed entity
 * (2026-09-03; backend api/feed_group_api.py).
 *
 * A group ("SAP", holding six feeds) is administered and ACTED ON as
 * one unit: bulk membership, group re-run, group dependency-skip.
 *
 * Rules honoured (each is the backend's contract, mirrored):
 *   * a FAILED group/member load never renders like "no groups";
 *   * both group actions show WHICH feeds they will touch BEFORE
 *     running and render PER-ITEM outcomes after — one aggregate
 *     "done" hides the failures;
 *   * the dependency skip requires a typed reason (it ships feeds
 *     without an input confirmed) and reports feeds OUTSIDE the group
 *     released by the same global tracking rows (`also_released`);
 *   * deleting a non-empty group is refused unless "detach feeds" is
 *     explicitly chosen — the feeds themselves are never deleted.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, Autocomplete, Box, Button, Checkbox, Chip, CircularProgress, Divider,
  FormControlLabel, IconButton, Paper, Stack, Table, TableBody,
  TableCell, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  Add as AddIcon, Delete as DeleteIcon, Edit as EditIcon,
  Groups as GroupIcon, PlayArrow as RerunIcon, Refresh as RefreshIcon,
  RemoveCircleOutline as SkipIcon, PersonRemove as UnassignIcon,
} from '@mui/icons-material';
import api from '../services/api';
import SkipReasonFields, { useSkipReason } from './common/SkipReasonFields';
import type {
  FeedGroupRow, GroupFeedsResponse, GroupRerunResponse, GroupSkipResponse,
} from '../services/api/feedGroups';
import { useAuth } from '../context/AuthContext';
import { clickableRow } from '../utils/clickable';
import ListPager, { clientPage } from './common/ListPager';

type GroupsLoad =
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; groups: FeedGroupRow[] };

type MembersLoad =
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; data: GroupFeedsResponse };

const OUTCOME_COLOR: Record<string, 'success' | 'error' | 'warning' | 'default'> = {
  triggered: 'success', released: 'success',
  failed: 'error',
  blocked_by_deployment_window: 'warning',
  no_run_for_date: 'warning', no_pending_run: 'default',
  skipped_inactive: 'default', not_blocked: 'default',
  no_dependencies: 'default',
};

// ── Group action dialog (rerun / skip-deps) ─────────────────────────────

const GroupActionDialog: React.FC<{
  mode: 'rerun' | 'skip' | null;
  group: FeedGroupRow | null;
  memberNames: string[];
  onClose: () => void;
  onDone: () => void;
}> = ({ mode, group, memberNames, onClose, onDone }) => {
  const [businessDate, setBusinessDate] = useState('');
  const reason = useSkipReason();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [rerunResult, setRerunResult] = useState<GroupRerunResponse | null>(null);
  const [skipResult, setSkipResult] = useState<GroupSkipResponse | null>(null);

  useEffect(() => {
    if (mode != null) {
      setBusinessDate('');
      reason.reset();
      setBusy(false);
      setError(null);
      setRerunResult(null);
      setSkipResult(null);
    }
  }, [mode, group?.id]);  // eslint-disable-line react-hooks/exhaustive-deps

  const needReason = mode === 'skip';
  const blocked = needReason && !reason.valid;

  const run = async () => {
    if (!group || blocked) return;
    setBusy(true);
    setError(null);
    try {
      if (mode === 'rerun') {
        const r = await api.rerunFeedGroup(group.id, {
          ...(businessDate ? { business_date: businessDate } : {}),
        });
        setRerunResult(r);
      } else {
        const r = await api.skipFeedGroupDependencies(group.id, {
          ...reason.body,
          ...(businessDate ? { business_date: businessDate } : {}),
        });
        setSkipResult(r);
      }
      onDone();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const items = rerunResult?.items ?? skipResult?.items ?? null;

  return (
    <AppDialog open={mode != null}
      onClose={busy ? undefined : onClose}
      size="sm"
      title={<>
        {mode === 'rerun' ? 'Re-run group' : 'Skip group dependencies'} —
        {' '}{group?.name}
      </>}
      actions={<>
        <Button onClick={onClose} disabled={busy}>
          {items != null ? 'Close' : 'Cancel'}
        </Button>
        {items == null && (
          <Button
            variant="contained"
            color={mode === 'skip' ? 'warning' : 'primary'}
            disabled={busy || blocked || memberNames.length === 0}
            onClick={() => void run()}
            startIcon={busy
              ? <CircularProgress size={14} />
              : mode === 'skip' ? <SkipIcon /> : <RerunIcon />}
            data-testid="group-action-go"
          >
            {mode === 'rerun'
              ? `Re-run ${memberNames.length} feed(s)`
              : `Skip for ${memberNames.length} feed(s)`}
          </Button>
        )}
      </>}>
        {items == null ? (
          <>
            <Alert severity={mode === 'skip' ? 'warning' : 'info'}
                   sx={{ mb: 2 }}>
              {mode === 'rerun' ? (
                <>Re-runs the group&apos;s existing runs for the business
                  date.  <strong>{memberNames.length} feed(s)</strong> will be
                  touched: {memberNames.join(', ') || '(none)'}</>
              ) : (
                <><strong>{memberNames.length} feed(s)</strong> will proceed
                  WITHOUT their pending inputs confirmed:
                  {' '}{memberNames.join(', ') || '(none)'}.  A dependency
                  shared with feeds OUTSIDE this group releases those too —
                  the result names them.  Recorded with your name and the
                  reason below.</>
              )}
            </Alert>
            <TextField
              label="Business date (empty = today UTC)" type="date"
              value={businessDate} size="small"
              onChange={e => setBusinessDate(e.target.value)}
              InputLabelProps={{ shrink: true }}
              inputProps={{ 'data-testid': 'group-action-date' }}
              sx={{ mb: 1.5, mr: 1.5 }}
            />
            {mode === 'skip' && (
              <SkipReasonFields
                state={reason}
                disabled={busy}
                textTestId="group-skip-reason"
                categoryTestId="group-skip-reason-category"
              />
            )}
            {error && (
              <Alert severity="error" sx={{ mt: 1.5 }}
                     data-testid="group-action-error">
                Refused — nothing was changed. {error}
              </Alert>
            )}
          </>
        ) : (
          <Box data-testid="group-action-outcomes">
            {rerunResult && (
              <Alert
                severity={rerunResult.failed > 0 ? 'warning' : 'success'}
                sx={{ mb: 1.5 }}
              >
                {rerunResult.triggered} triggered, {rerunResult.failed} failed,
                {' '}{rerunResult.skipped_inactive} inactive,
                {' '}{rerunResult.blocked_by_deployment_window} blocked by a
                deployment window ({rerunResult.business_date}).
              </Alert>
            )}
            {skipResult && (
              <Alert
                severity={Object.keys(skipResult.failed_dependencies).length > 0
                  ? 'warning' : 'success'}
                sx={{ mb: 1.5 }}
              >
                {skipResult.released} feed(s) released for
                {' '}{skipResult.business_date} by {skipResult.asserted_by}.
              </Alert>
            )}
            {items.map(it => (
              <Typography key={it.feed_config_id} variant="caption"
                          sx={{ display: 'block' }}>
                <Chip size="small" label={it.outcome}
                      color={OUTCOME_COLOR[it.outcome] ?? 'default'}
                      sx={{ height: 18, fontSize: '0.65rem', mr: 0.5 }} />
                {it.feed_name}
                {it.run_id != null ? ` (run #${it.run_id})` : ''}
                {it.detail ? ` — ${it.detail}` : ''}
              </Typography>
            ))}
            {skipResult && skipResult.also_released.length > 0 && (
              <Alert severity="info" sx={{ mt: 1 }}
                     data-testid="group-skip-also-released">
                Also released (outside this group, same shared dependency):
                {' '}{skipResult.also_released
                  .map(r => `${r.feed_name} (run #${r.feed_run_id})`)
                  .join(', ')}
              </Alert>
            )}
            {skipResult
              && Object.keys(skipResult.failed_dependencies).length > 0 && (
              <Alert severity="error" sx={{ mt: 1 }}>
                NOT skipped:{' '}
                {Object.entries(skipResult.failed_dependencies)
                  .map(([k, v]) => `${k} (${v})`).join('; ')}
              </Alert>
            )}
          </Box>
        )}
    </AppDialog>
  );
};

// ── Page ────────────────────────────────────────────────────────────────

const FeedGroupsPage: React.FC = () => {
  const { user } = useAuth();
  const isAdmin = !!user?.is_admin;

  const [groupsLoad, setGroupsLoad] = useState<GroupsLoad>({ phase: 'loading' });
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [membersLoad, setMembersLoad] =
    useState<MembersLoad>({ phase: 'loading' });

  // create/edit dialog
  const [editorOpen, setEditorOpen] = useState(false);
  // 2026-10-13 -- one group per entity: ~4,000 on the owner's estate.  The
  // list stays one call (the pickers need every group); the page finds and
  // pages it here.
  const [groupFind, setGroupFind] = useState('');
  const [groupPage, setGroupPage] = useState(1);
  const [groupPageSize, setGroupPageSize] = useState(50);
  const [memberPage, setMemberPage] = useState(1);
  const [memberPageSize, setMemberPageSize] = useState(50);
  useEffect(() => { setMemberPage(1); }, [selectedId]);
  const [editing, setEditing] = useState<FeedGroupRow | null>(null);
  const [formName, setFormName] = useState('');
  const [formLabel, setFormLabel] = useState('');
  const [formDescription, setFormDescription] = useState('');
  // 2026-09-27 -- the daily close-out digest's recipients
  const [formEmail, setFormEmail] = useState('');
  const [formActive, setFormActive] = useState(true);
  const [editorBusy, setEditorBusy] = useState(false);
  const [editorError, setEditorError] = useState<string | null>(null);

  // delete flow
  const [deleting, setDeleting] = useState<FeedGroupRow | null>(null);
  const [detachFeeds, setDetachFeeds] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  // membership
  const [allFeeds, setAllFeeds] = useState<any[]>([]);
  const [allFeedsError, setAllFeedsError] = useState<string | null>(null);
  const [toAssign, setToAssign] = useState<any[]>([]);
  const [toUnassign, setToUnassign] = useState<Set<number>>(new Set());
  const [membershipBusy, setMembershipBusy] = useState(false);
  const [membershipError, setMembershipError] = useState<string | null>(null);
  const [membershipResult, setMembershipResult] = useState<string | null>(null);

  // group actions
  const [actionMode, setActionMode] = useState<'rerun' | 'skip' | null>(null);

  const loadGroups = async () => {
    setGroupsLoad({ phase: 'loading' });
    try {
      const groups = await api.listFeedGroups();
      setGroupsLoad({ phase: 'ready', groups: groups || [] });
    } catch (e: any) {
      setGroupsLoad({ phase: 'error', message: e?.message || String(e) });
    }
  };

  const loadMembers = async (groupId: number) => {
    setMembersLoad({ phase: 'loading' });
    try {
      const data = await api.listFeedsInGroup(groupId);
      setMembersLoad({ phase: 'ready', data });
    } catch (e: any) {
      setMembersLoad({ phase: 'error', message: e?.message || String(e) });
    }
  };

  useEffect(() => { void loadGroups(); }, []);

  useEffect(() => {
    if (selectedId != null) {
      setToAssign([]);
      setToUnassign(new Set());
      setMembershipError(null);
      setMembershipResult(null);
      void loadMembers(selectedId);
    }
  }, [selectedId]);

  // The assign picker needs the estate's feeds; a failed load DISABLES
  // assignment with the failure named (it must not look like "no feeds").
  useEffect(() => {
    (async () => {
      try {
        const feeds = await api.listFeeds();
        setAllFeeds(Array.isArray(feeds) ? feeds : []);
        setAllFeedsError(null);
      } catch (e: any) {
        setAllFeedsError(e?.message || String(e));
      }
    })();
  }, []);

  const groups = groupsLoad.phase === 'ready' ? groupsLoad.groups : [];
  const selected = groups.find(g => g.id === selectedId) ?? null;
  const members = membersLoad.phase === 'ready'
    ? membersLoad.data.feeds : [];
  const memberNames = useMemo(
    () => members.map(f => f.display_name || f.name), [members]);

  const openCreate = () => {
    setEditing(null);
    setFormName(''); setFormLabel(''); setFormDescription('');
    setFormActive(true);
    setEditorError(null);
    setEditorOpen(true);
  };

  const openEdit = (g: FeedGroupRow) => {
    setEditing(g);
    setFormName(g.name);
    setFormLabel(g.display_label || '');
    setFormDescription(g.description || '');
    setFormEmail(g.notification_email || '');
    setFormActive(!!g.is_active);
    setEditorError(null);
    setEditorOpen(true);
  };

  const saveEditor = async () => {
    setEditorBusy(true);
    setEditorError(null);
    try {
      const body = {
        name: formName.trim(),
        ...(formLabel.trim() ? { display_label: formLabel.trim() } : {}),
        ...(formDescription.trim()
          ? { description: formDescription.trim() } : {}),
        // sent explicitly (empty = clear) so an address can be removed
        notification_email: formEmail.trim() || null,
        is_active: formActive,
      };
      if (editing) await api.updateFeedGroup(editing.id, body);
      else await api.createFeedGroup(body);
      setEditorOpen(false);
      void loadGroups();
    } catch (e: any) {
      setEditorError(e?.message || String(e));
    } finally {
      setEditorBusy(false);
    }
  };

  const doDelete = async () => {
    if (!deleting) return;
    setDeleteBusy(true);
    setDeleteError(null);
    try {
      await api.deleteFeedGroup(deleting.id, detachFeeds);
      setDeleting(null);
      setDetachFeeds(false);
      if (selectedId === deleting.id) setSelectedId(null);
      void loadGroups();
    } catch (e: any) {
      setDeleteError(e?.message || String(e));
    } finally {
      setDeleteBusy(false);
    }
  };

  const applyMembership = async () => {
    if (selectedId == null) return;
    setMembershipBusy(true);
    setMembershipError(null);
    setMembershipResult(null);
    try {
      const r = await api.setFeedGroupMembership(selectedId, {
        assign: toAssign.map(f => f.id),
        unassign: [...toUnassign],
      });
      const moved = Object.keys(r.moved_from || {}).length;
      const notIn = (r.not_in_group || []).length;
      setMembershipResult(
        `${r.assigned.length} assigned, ${r.unassigned.length} unassigned`
        + (moved ? `, ${moved} moved from another group` : '')
        + (notIn ? `, ${notIn} named feed(s) were not members (unchanged)` : '')
        + ` — group now has ${r.feed_count} feed(s).`);
      setToAssign([]);
      setToUnassign(new Set());
      void loadMembers(selectedId);
      void loadGroups();
    } catch (e: any) {
      setMembershipError(e?.message || String(e));
    } finally {
      setMembershipBusy(false);
    }
  };

  const assignable = useMemo(
    () => allFeeds.filter(f =>
      f.feed_group_id !== selectedId
      && !toAssign.some(t => t.id === f.id)),
    [allFeeds, selectedId, toAssign]);

  const _gq = groupFind.trim().toLowerCase();
  const shownGroups = clientPage(_gq ? groups.filter(g => `${g.name} ${g.display_label || ''}`.toLowerCase().includes(_gq))
                                     : groups, groupPage, groupPageSize);
  const shownMembers = clientPage(members, memberPage, memberPageSize);

  return (
    <Box sx={{ p: 2 }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <GroupIcon color="primary" />
        <Typography variant="h5" sx={{ fontWeight: 700 }}>Feed Groups</Typography>
        <Box sx={{ flex: 1 }} />
        <Button size="small" startIcon={<RefreshIcon />}
                onClick={() => void loadGroups()}>
          Refresh
        </Button>
        {isAdmin && (
          <Button variant="contained" size="small" startIcon={<AddIcon />}
                  onClick={openCreate} data-testid="group-create">
            New group
          </Button>
        )}
      </Stack>

      {groupsLoad.phase === 'loading' && (
        <Stack alignItems="center" sx={{ py: 4 }}>
          <CircularProgress size={24} />
        </Stack>
      )}

      {groupsLoad.phase === 'error' && (
        <Alert
          severity="error" data-testid="groups-load-error"
          action={
            <Button color="inherit" size="small"
                    onClick={() => void loadGroups()}>Retry</Button>
          }
        >
          Could not load feed groups — groups may exist but cannot be shown.
          {' '}{groupsLoad.message}
        </Alert>
      )}

      {groupsLoad.phase === 'ready' && groups.length === 0 && (
        <Alert severity="info" data-testid="groups-empty">
          No feed groups exist yet.
          {isAdmin ? ' Create one to administer related feeds as a unit.'
            : ' An admin can create one.'}
        </Alert>
      )}

      {groupsLoad.phase === 'ready' && groups.length > 0 && (
        <Paper sx={{ mb: 2 }}>
          <TextField size="small" placeholder="Find a group by name or label" value={groupFind}
                     onChange={e => { setGroupFind(e.target.value); setGroupPage(1); }}
                     inputProps={{ 'aria-label': 'Find a group', 'data-testid': 'groups-find' }}
                     sx={{ m: 1, width: 300 }} />
          <Table size="small" data-testid="groups-table">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Label</TableCell>
                <TableCell>Digest e-mail</TableCell>
                <TableCell align="right">Feeds</TableCell>
                <TableCell>Active</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {shownGroups.rows.map(g => (
                <TableRow key={g.id} hover selected={g.id === selectedId}
                          {...clickableRow(() => setSelectedId(g.id), { label: g.name, selected: g.id === selectedId })}
                          sx={{ cursor: 'pointer' }}>
                  <TableCell>{g.name}</TableCell>
                  <TableCell>{g.display_label || '—'}</TableCell>
                  <TableCell sx={{ fontSize: 12 }}>{g.notification_email || '—'}</TableCell>
                  <TableCell align="right">{g.feed_count ?? '—'}</TableCell>
                  <TableCell>
                    <Chip size="small"
                          label={g.is_active ? 'active' : 'inactive'}
                          color={g.is_active ? 'success' : 'default'}
                          variant="outlined"
                          sx={{ height: 20, fontSize: '0.68rem' }} />
                  </TableCell>
                  <TableCell align="right" onClick={e => e.stopPropagation()}>
                    {isAdmin && (
                      <>
                        <Tooltip title="Edit">
                          <IconButton size="small" onClick={() => openEdit(g)}
                                      aria-label={`edit group ${g.name}`}>
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton size="small" color="error"
                                      aria-label={`delete group ${g.name}`}
                                      onClick={() => {
                                        setDeleting(g);
                                        setDetachFeeds(false);
                                        setDeleteError(null);
                                      }}>
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <ListPager paging={shownGroups.paging} onPage={setGroupPage} onPageSize={setGroupPageSize}
                     testid="groups-pager" />
        </Paper>
      )}

      {/* ── Selected group detail ── */}
      {selected && (
        <Paper sx={{ p: 2 }} data-testid="group-detail">
          <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
            <Typography variant="h6">{selected.name}</Typography>
            {!selected.is_active && (
              <Chip size="small" label="inactive" sx={{ height: 20 }} />
            )}
            <Box sx={{ flex: 1 }} />
            <Button size="small" startIcon={<RerunIcon />}
                    disabled={members.length === 0}
                    onClick={() => setActionMode('rerun')}
                    data-testid="group-rerun">
              Re-run group…
            </Button>
            <Button size="small" color="warning" startIcon={<SkipIcon />}
                    disabled={members.length === 0}
                    onClick={() => setActionMode('skip')}
                    data-testid="group-skip">
              Skip dependencies…
            </Button>
          </Stack>

          {membersLoad.phase === 'loading' && <CircularProgress size={18} />}

          {membersLoad.phase === 'error' && (
            <Alert
              severity="error" data-testid="members-load-error"
              action={
                <Button color="inherit" size="small"
                        onClick={() => void loadMembers(selected.id)}>
                  Retry
                </Button>
              }
            >
              Could not load this group&apos;s feeds — members may exist but
              cannot be shown. {membersLoad.message}
            </Alert>
          )}

          {membersLoad.phase === 'ready' && (
            <>
              {members.length === 0 ? (
                <Alert severity="info" data-testid="members-empty">
                  This group has no feeds yet — assign some below.
                </Alert>
              ) : (
                <>
                <Table size="small" data-testid="members-table">
                  <TableHead>
                    <TableRow>
                      <TableCell>Feed</TableCell>
                      <TableCell>Source</TableCell>
                      <TableCell>SLA</TableCell>
                      <TableCell>Active</TableCell>
                      <TableCell align="right">Remove</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {shownMembers.rows.map(f => (
                      <TableRow key={f.id} hover>
                        <TableCell>{f.display_name || f.name}</TableCell>
                        <TableCell>{f.source_type}</TableCell>
                        <TableCell>
                          {f.sla_to ? `to ${f.sla_to}` : '—'}
                        </TableCell>
                        <TableCell>{f.is_active ? 'yes' : 'no'}</TableCell>
                        <TableCell align="right">
                          <Checkbox
                            size="small" checked={toUnassign.has(f.id)}
                            onChange={() => setToUnassign(prev => {
                              const next = new Set(prev);
                              if (next.has(f.id)) next.delete(f.id);
                              else next.add(f.id);
                              return next;
                            })}
                            slotProps={{ input: {
                              'aria-label': `unassign ${f.name}`,
                              } as any }}
                            icon={<UnassignIcon fontSize="small" />}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <ListPager paging={shownMembers.paging} onPage={setMemberPage} onPageSize={setMemberPageSize}
                           testid="members-pager" />
                </>
              )}

              <Divider sx={{ my: 1.5 }} />
              <Typography variant="subtitle2" sx={{ mb: 1 }}>
                Edit membership
              </Typography>
              {allFeedsError ? (
                <Alert severity="error" sx={{ mb: 1 }}>
                  The feed list could not be loaded, so assignment is
                  unavailable (unassignment still works). {allFeedsError}
                </Alert>
              ) : (
                <Autocomplete
                  multiple size="small" options={assignable}
                  getOptionLabel={(f: any) =>
                    `${f.display_name || f.name}${f.feed_group_id != null
                      && f.feed_group_id !== selected.id
                      ? ' (in another group — will be MOVED)' : ''}`}
                  value={toAssign}
                  onChange={(_, v) => setToAssign(v)}
                  renderInput={params => (
                    <TextField {...params} label="Feeds to assign"
                               placeholder="Type to search feeds…" />
                  )}
                  sx={{ mb: 1 }}
                />
              )}
              <Stack direction="row" spacing={1} alignItems="center">
                <Button
                  variant="contained" size="small"
                  disabled={membershipBusy
                    || (toAssign.length === 0 && toUnassign.size === 0)}
                  onClick={() => void applyMembership()}
                  startIcon={membershipBusy
                    ? <CircularProgress size={12} /> : undefined}
                  data-testid="membership-apply"
                >
                  Apply ({toAssign.length} assign, {toUnassign.size} unassign)
                </Button>
                <Typography variant="caption" color="text.secondary">
                  All-or-nothing: an unknown feed, missing permission or an
                  id in both lists refuses the whole change.
                </Typography>
              </Stack>
              {membershipError && (
                <Alert severity="error" sx={{ mt: 1 }}
                       data-testid="membership-error">
                  Nothing was changed. {membershipError}
                </Alert>
              )}
              {membershipResult && (
                <Alert severity="success" sx={{ mt: 1 }}
                       data-testid="membership-result">
                  {membershipResult}
                </Alert>
              )}
            </>
          )}
        </Paper>
      )}

      {/* ── Create/edit dialog ── */}
      <AppDialog open={editorOpen}
        onClose={editorBusy ? undefined : () => setEditorOpen(false)}
        size="xs"
        title={<>{editing ? `Edit group — ${editing.name}` : 'New feed group'}</>}
        actions={<>
          <Button onClick={() => setEditorOpen(false)} disabled={editorBusy}>
            Cancel
          </Button>
          <Button variant="contained"
                  disabled={editorBusy || !formName.trim()}
                  onClick={() => void saveEditor()}
                  data-testid="group-form-save">
            {editing ? 'Save' : 'Create'}
          </Button>
        </>}>
          <TextField label="Name (unique)" value={formName} fullWidth
                     onChange={e => setFormName(e.target.value)}
                     sx={{ mb: 1.5, mt: 0.5 }} size="small"
                     inputProps={{ 'data-testid': 'group-form-name' }} />
          <TextField label="Display label (optional)" value={formLabel}
                     fullWidth size="small" sx={{ mb: 1.5 }}
                     onChange={e => setFormLabel(e.target.value)} />
          <TextField label="Description (optional)" value={formDescription}
                     fullWidth size="small" multiline minRows={2}
                     sx={{ mb: 1.5 }}
                     onChange={e => setFormDescription(e.target.value)} />
          <TextField label="Close-out digest e-mail (optional)" value={formEmail}
                     fullWidth size="small" sx={{ mb: 1 }}
                     inputProps={{ 'data-testid': 'group-form-email' }}
                     helperText="One e-mail per business day for this group's feeds: delivered, not delivered, waiting on what, failed at which step. Comma-separate several addresses; empty = no digest."
                     onChange={e => setFormEmail(e.target.value)} />
          <FormControlLabel
            control={<Checkbox checked={formActive}
                               onChange={e => setFormActive(e.target.checked)} />}
            label="Active (inactive groups refuse new assignments)"
          />
          {editorError && (
            <Alert severity="error" sx={{ mt: 1 }}
                   data-testid="group-form-error">{editorError}</Alert>
          )}
      </AppDialog>

      {/* ── Delete confirm ── */}
      <AppDialog open={deleting != null}
        onClose={deleteBusy ? undefined : () => setDeleting(null)}
        size="xs"
        title={<>Delete group — {deleting?.name}</>}
        actions={<>
          <Button onClick={() => setDeleting(null)} disabled={deleteBusy}>
            Cancel
          </Button>
          <Button variant="contained" color="error" disabled={deleteBusy}
                  onClick={() => void doDelete()}
                  data-testid="group-delete-go">
            Delete group
          </Button>
        </>}>
          <Alert severity="warning" sx={{ mb: 1 }}>
            The group is switched off, not erased — an admin can switch it
            back on under Admin -&gt; Switched off.  The feeds themselves are
            never deleted.  A group that still has feeds is refused unless
            you explicitly choose to leave them ungrouped.
          </Alert>
          <FormControlLabel
            control={
              <Checkbox checked={detachFeeds}
                        onChange={e => setDetachFeeds(e.target.checked)}
                        slotProps={{ input: { 'data-testid': 'group-delete-detach' } as any }} />
            }
            label={`Detach its ${deleting?.feed_count ?? 0} feed(s) (they become ungrouped)`}
          />
          {deleteError && (
            <Alert severity="error" sx={{ mt: 1 }}
                   data-testid="group-delete-error">{deleteError}</Alert>
          )}
      </AppDialog>

      <GroupActionDialog
        mode={actionMode}
        group={selected}
        memberNames={memberNames}
        onClose={() => setActionMode(null)}
        onDone={() => {
          if (selectedId != null) void loadMembers(selectedId);
        }}
      />
    </Box>
  );
};

export default FeedGroupsPage;
