/**
 * "Add to dashboard" from a finance report (2026-09-25).
 *
 * A report is one tile of a dashboard: pick an existing dashboard or name a
 * new one, keep the parameter values on screen (or leave them for the
 * dashboard's filters), and open it.  The tile runs the SAME /execute the
 * report page does, so its access gate, published version and row security
 * are the report's own.
 */
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Alert, Button, Checkbox,
  FormControl, FormControlLabel, InputLabel, MenuItem, Select, TextField, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import api from '../../services/api';
import { toArray } from '../../utils/toArray';

const NEW = '__new__';

export default function AddToDashboardDialog({ open, onClose, reportId, reportName, paramValues, chartType }: {
  open: boolean;
  onClose: () => void;
  reportId: number;
  reportName: string;
  paramValues: Record<string, any>;
  chartType?: string;
}) {
  const navigate = useNavigate();
  const [dashboards, setDashboards] = useState<any[]>([]);
  const [target, setTarget] = useState<string>('');
  const [newName, setNewName] = useState('');
  const [keepValues, setKeepValues] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [added, setAdded] = useState<{ id: number; name: string } | null>(null);

  const filled = Object.fromEntries(Object.entries(paramValues || {})
    .filter(([, v]) => v !== '' && v != null && !(Array.isArray(v) && v.length === 0)));

  useEffect(() => {
    if (!open) return;
    setError(''); setAdded(null); setNewName(''); setKeepValues(true);
    api.listDashboards().then((d: any) => {
      const list: any[] = toArray(d);
      setDashboards(list);
      setTarget(list.length ? String(list[0].id) : NEW);
    }).catch(() => { setDashboards([]); setTarget(NEW); });
  }, [open]);

  const add = async () => {
    setBusy(true); setError('');
    try {
      let dash: any;
      if (target === NEW) {
        if (!newName.trim()) { setError('Name the new dashboard'); setBusy(false); return; }
        dash = await api.createDashboard({ name: newName.trim() });
      } else {
        dash = dashboards.find(d => String(d.id) === target);
      }
      await api.createWidget(dash.id, {
        widget_type: 'business_report',
        source_id: reportId,
        title: reportName,
        chart_type: chartType || 'grid',
        chart_config: {},
        param_values: keepValues ? filled : {},
        layout: { x: 0, y: 0, w: 6, h: 6 },
      });
      setAdded({ id: dash.id, name: dash.name });
    } catch (e: any) {
      setError(e?.message || 'The report could not be added');
    } finally {
      setBusy(false);
    }
  };

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="xs"
      title="Add to a dashboard"
      contentSx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}
      actions={<>
        <Button onClick={onClose}>{added ? 'Close' : 'Cancel'}</Button>
        {added ? (
          <Button variant="contained" onClick={() => navigate(`/dashboards?dashboard=${added.id}`)}>
            Open dashboard
          </Button>
        ) : (
          <Button variant="contained" onClick={add} disabled={busy}>Add</Button>
        )}
      </>}>
        {added ? (
          <Alert severity="success">
            "{reportName}" is on <strong>{added.name}</strong>.
          </Alert>
        ) : (
          <>
            <FormControl size="small" fullWidth>
              <InputLabel id="add-to-dash-target">Dashboard</InputLabel>
              <Select labelId="add-to-dash-target" label="Dashboard" value={target}
                      onChange={e => setTarget(String(e.target.value))}>
                {dashboards.map(d => <MenuItem key={d.id} value={String(d.id)}>{d.name}</MenuItem>)}
                <MenuItem value={NEW}><em>New dashboard…</em></MenuItem>
              </Select>
            </FormControl>
            {target === NEW && (
              <TextField size="small" label="New dashboard name" value={newName} autoFocus
                         onChange={e => setNewName(e.target.value)} />
            )}
            {Object.keys(filled).length > 0 && (
              <FormControlLabel
                control={<Checkbox checked={keepValues} onChange={e => setKeepValues(e.target.checked)} />}
                label={<Typography variant="body2">
                  Keep the parameter values on screen ({Object.entries(filled)
                    .map(([k, v]) => `${k} = ${Array.isArray(v) ? v.join(', ') : v}`).join('; ')})
                </Typography>} />
            )}
            <Typography variant="caption" color="text.secondary">
              A dashboard filter on the same parameter overrides a kept value.
            </Typography>
            {error && <Alert severity="error">{error}</Alert>}
          </>
        )}
    </AppDialog>
  );
}
