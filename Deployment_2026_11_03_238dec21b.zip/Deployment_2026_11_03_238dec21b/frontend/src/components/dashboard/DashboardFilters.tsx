/**
 * Dashboard filters (2026-09-25): the filter bar a viewer uses, the editor an
 * author declares filters with, and the parameter inputs both share.
 *
 * A filter binds by NAME to the parameters the tiles declare
 * (dashboardParams.ts); the editor therefore offers only names some tile
 * uses -- a free-text name that no tile declares would filter nothing.
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip,
  FormControl, IconButton, InputLabel, MenuItem, Select, Stack, TextField, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import { Delete as DeleteIcon, FilterList as FilterIcon } from '@mui/icons-material';
import api from '../../services/api';
import type { DashboardFilter, DeclaredParam } from './dashboardParams';

/** Values for parameters whose options are LOOKED UP (a finance-report
 *  dropdown over a column), fetched once per input set.  A lookup that fails
 *  leaves the input as free text -- it never pretends there are no values. */
function useLookedUpOptions(params: (DeclaredParam | DashboardFilter)[]) {
  const [loaded, setLoaded] = useState<Record<string, string[]>>({});
  const key = params.map(p => `${p.name}:${p.lov?.report_id}:${p.lov?.parameter_id}`).join('|');
  useEffect(() => {
    let live = true;
    for (const p of params) {
      if (!p.lov || (p.options && p.options.length) || loaded[p.name]) continue;
      api.getBusinessReportParamValues(p.lov.report_id, { parameter_id: p.lov.parameter_id })
        .then((r: any) => {
          const vals = Array.isArray(r?.values) ? r.values.map(String) : [];
          if (live && vals.length) setLoaded(prev => ({ ...prev, [p.name]: vals }));
        })
        .catch(() => {});
    }
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  return loaded;
}

const inputTypeFor = (t?: string) =>
  t === 'date' ? 'date' : (t === 'number' || t === 'numeric') ? 'number' : 'text';

/** One input per parameter.  A parameter with options is a select; a date is a
 *  date picker; anything else is text.  Every input is named by its label. */
export function ParamInputs({ params, values, onChange, size = 'small', idPrefix }: {
  params: (DeclaredParam | DashboardFilter)[];
  values: Record<string, any>;
  onChange: (name: string, value: any) => void;
  size?: 'small' | 'medium';
  idPrefix: string;
}) {
  const looked = useLookedUpOptions(params);
  return (
    <>
      {params.map(p => {
        const label = `${p.label || p.name}${(p as DeclaredParam).required ? ' *' : ''}`;
        const v = values[p.name] ?? '';
        const opts = (p.options && p.options.length) ? p.options : (looked[p.name] || []);
        if (opts.length) {
          const id = `${idPrefix}-${p.name}`;
          return (
            <FormControl key={p.name} size={size} sx={{ minWidth: 160 }}>
              <InputLabel id={id}>{label}</InputLabel>
              <Select labelId={id} label={label} value={v}
                      onChange={e => onChange(p.name, e.target.value)}>
                <MenuItem value=""><em>(none)</em></MenuItem>
                {opts.map((o: string) => <MenuItem key={o} value={o}>{o}</MenuItem>)}
              </Select>
            </FormControl>
          );
        }
        return (
          <TextField key={p.name} size={size} label={label} value={v} sx={{ minWidth: 160 }}
                     type={inputTypeFor(p.type)}
                     InputLabelProps={p.type === 'date' ? { shrink: true } : undefined}
                     onChange={e => onChange(p.name, e.target.value)} />
        );
      })}
    </>
  );
}

/** The viewer's bar: edit values, Apply reruns every tile that uses them. */
export function DashboardFilterBar({ filters, values, onApply }: {
  filters: DashboardFilter[];
  values: Record<string, any>;
  onApply: (values: Record<string, any>) => void;
}) {
  const [draft, setDraft] = useState<Record<string, any>>(values);
  useEffect(() => { setDraft(values); }, [values]);
  if (!filters?.length) return null;
  const dirty = JSON.stringify(draft) !== JSON.stringify(values);
  return (
    <Box data-testid="dashboard-filter-bar"
         sx={{ display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap', mb: 1, px: 0.5 }}>
      <FilterIcon sx={{ fontSize: 18, color: 'text.secondary' }} />
      <ParamInputs idPrefix="dash-filter" params={filters} values={draft}
                   onChange={(n, v) => setDraft(d => ({ ...d, [n]: v }))} />
      <Button size="small" variant={dirty ? 'contained' : 'outlined'} onClick={() => onApply(draft)}>
        Apply filters
      </Button>
    </Box>
  );
}

/** The author's editor: which parameters the dashboard filters on. */
export function FiltersEditorDialog({ open, filters, bindable, onClose, onSave }: {
  open: boolean;
  filters: DashboardFilter[];
  bindable: DeclaredParam[];
  onClose: () => void;
  onSave: (filters: DashboardFilter[]) => Promise<void>;
}) {
  const [rows, setRows] = useState<DashboardFilter[]>([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (open) { setRows(filters || []); setError(''); } }, [open, filters]);

  const unused = bindable.filter(p => !rows.some(r => r.name === p.name));
  const add = (p: DeclaredParam) => setRows(r => [...r, {
    name: p.name, label: p.label || p.name,
    type: ((p.options?.length || p.lov) ? 'select' : (p.type === 'date' ? 'date'
      : (p.type === 'number' || p.type === 'numeric') ? 'number' : 'text')) as DashboardFilter['type'],
    options: p.options || [], default: p.default ?? '', lov: p.lov ?? null,
  }]);
  const set = (i: number, patch: Partial<DashboardFilter>) =>
    setRows(r => r.map((x, j) => (j === i ? { ...x, ...patch } : x)));

  const save = async () => {
    setSaving(true); setError('');
    try { await onSave(rows); onClose(); }
    catch (e: any) { setError(e?.message || 'The filters could not be saved'); }
    finally { setSaving(false); }
  };

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="md"
      title="Dashboard filters"
      contentSx={{ display: 'flex', flexDirection: 'column', gap: 2, pt: 1 }}
      actions={<>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={save} disabled={saving}>Save filters</Button>
      </>}>
        <Typography variant="body2" color="text.secondary">
          A filter sets a parameter on every tile that uses it. Only parameters
          your tiles declare can be filtered on.
        </Typography>
        {rows.length === 0 && <Alert severity="info">No filters yet.</Alert>}
        {rows.map((f, i) => (
          <Stack key={f.name} direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
            <Chip label={f.name} size="small" />
            <TextField size="small" label="Label" value={f.label || ''} sx={{ width: 180 }}
                       onChange={e => set(i, { label: e.target.value })} />
            <ParamInputs idPrefix={`dash-filter-default-${i}`}
                         params={[{ ...f, label: 'Default value' }]}
                         values={{ [f.name]: f.default ?? '' }}
                         onChange={(_n, v) => set(i, { default: v })} />
            <IconButton aria-label={`Remove filter ${f.name}`} size="small"
                        onClick={() => setRows(r => r.filter((_x, j) => j !== i))}>
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Stack>
        ))}
        <Box>
          <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Add a filter on</Typography>
          {unused.length === 0 ? (
            <Typography variant="body2" color="text.secondary">
              {bindable.length === 0
                ? 'None of this dashboard’s tiles takes a parameter.'
                : 'Every parameter your tiles use already has a filter.'}
            </Typography>
          ) : (
            <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap>
              {unused.map(p => (
                <Chip key={p.name} label={`${p.label || p.name} (${p.name})`} onClick={() => add(p)}
                      variant="outlined" color="primary" />
              ))}
            </Stack>
          )}
        </Box>
        {error && <Alert severity="error">{error}</Alert>}
    </AppDialog>
  );
}
