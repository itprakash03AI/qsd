/**
 * The ONE editor of a federation view -- the "cross-source query" (two sides,
 * any connection either side, UNION or JOIN).  Used by the Federation Views
 * page and by the Published API screen ("New cross-source API", 2026-10-23),
 * so the union is built the same way wherever it is started.
 *
 * Each side is either the registered tables of a storage connection, or SQL
 * (2026-10-23: an S3 / local side can be SQL too -- it runs on QueryStudio's
 * S3 engine over the connection's registered tables, the custom-SQL-dataset
 * road).  A side's SQL can be typed, copied from the first side ("Same SQL as
 * the primary") or loaded from a saved query; a saved SQL-page query that is
 * itself cross-source fills BOTH sides.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Autocomplete, Box, Button, Chip, CircularProgress, Divider, FormControl, FormControlLabel, Grid, IconButton,
  InputLabel, MenuItem, Select, Switch, TextField, ToggleButton, ToggleButtonGroup, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import DeleteIcon from '@mui/icons-material/Delete';
import api from '../../services/api';

export interface FederationView {
  id: number;
  name: string;
  description: string;
  primary_conn_id: number;
  primary_query: Record<string, any>;
  secondary_conn_id: number;
  secondary_query: Record<string, any>;
  combine_mode: string;
  join_on: Array<{ left: string; right: string }>;
  join_how: string;
  output_columns: string[];
  is_active: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
  status?: string;
  row_count?: number;
  column_count?: number;
  file_size_bytes?: number;
  last_materialized?: string;
  last_error?: string;
  schema_cache?: any[];
}

export interface FederationConnection {
  id: number;
  name: string;
  connection_type: string;
  config?: Record<string, any>;
}

export const EMPTY_VIEW: Partial<FederationView> = {
  name: '',
  description: '',
  primary_conn_id: 0,
  primary_query: { files: [], filters: [], columns: [] },
  secondary_conn_id: 0,
  secondary_query: { files: [], filters: [], columns: [] },
  combine_mode: 'union',
  join_on: [],
  join_how: 'inner',
  output_columns: [],
  is_active: true,
};

type Side = 'primary' | 'secondary';

/** A saved query a side can load its SQL from -- the BQB's (query_config) and
 *  the SQL page's (primary / secondary statements), one list. */
export interface SavedSql {
  key: string;
  label: string;
  connId: number | null;
  sql: string;
  secondaryConnId?: number | null;
  secondarySql?: string;
  combineMode?: string | null;
}

export const savedSqlChoices = (bqb: any[], sqlPage: any[]): SavedSql[] => {
  const out: SavedSql[] = [];
  for (const q of Array.isArray(bqb) ? bqb : []) {
    const qc = q?.query_config || {};
    const sql = String(qc.raw_sql || qc.custom_sql || '').trim();
    if (!sql) continue;
    out.push({ key: `q:${q.id}`, label: `${q.name} (Query Builder)`,
               connId: qc.connection_id ?? null, sql });
  }
  for (const q of Array.isArray(sqlPage) ? sqlPage : []) {
    const sql = String(q?.primary_sql || '').trim();
    if (!sql) continue;
    out.push({ key: `s:${q.id}`, label: `${q.name} (SQL page${q.secondary_connection_id ? ', two connections' : ''})`,
               connId: q.primary_connection_id ?? null, sql,
               secondaryConnId: q.secondary_connection_id ?? null,
               secondarySql: String(q.secondary_sql || '').trim(), combineMode: q.combine_mode ?? null });
  }
  return out;
};

const isStorage = (c?: FederationConnection) =>
  !!c && ['s3', 'local'].includes(String(c.connection_type || '').toLowerCase());

const hasSql = (q?: Record<string, any>) => !!String(q?.raw_sql || '').trim();

interface Props {
  open: boolean;
  initial: Partial<FederationView> | null;
  connections: FederationConnection[];
  onClose: () => void;
  onSaved: (fv: FederationView) => void;
}

const FederationViewEditorDialog: React.FC<Props> = ({ open, initial, connections, onClose, onSaved }) => {
  const [editView, setEditView] = useState<Partial<FederationView> | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [primarySchema, setPrimarySchema] = useState<any[]>([]);
  const [secondarySchema, setSecondarySchema] = useState<any[]>([]);
  // A storage side shows its table picker unless it is (or is switched to) SQL.
  const [sqlMode, setSqlMode] = useState<Record<Side, boolean>>({ primary: false, secondary: false });
  const [saved, setSaved] = useState<SavedSql[] | null>(null);
  const [savedError, setSavedError] = useState('');

  const connOf = useCallback((id?: number) => connections.find(c => c.id === id), [connections]);

  const loadSchemaForSide = useCallback(async (connId: number, files: string[], side: Side) => {
    const set = side === 'primary' ? setPrimarySchema : setSecondarySchema;
    if (!connId || !files?.length) { set([]); return; }
    try {
      const tableName = files[0]?.replace('__registered__:', '') || '';
      if (!tableName) return;
      const schema = await api.getRegisteredTableSchema(String(connId), tableName);
      set((schema?.columns || []).map((c: any) => ({ name: c.name, type: c.type || '' })));
    } catch {
      // the join-column boxes stay free text (freeSolo)
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    const v = initial ? { ...initial } : { ...EMPTY_VIEW };
    setEditView(v);
    setError('');
    setSqlMode({ primary: hasSql(v.primary_query), secondary: hasSql(v.secondary_query) });
    loadSchemaForSide(v.primary_conn_id || 0, v.primary_query?.files || [], 'primary');
    loadSchemaForSide(v.secondary_conn_id || 0, v.secondary_query?.files || [], 'secondary');
  }, [open, initial, loadSchemaForSide]);

  // Saved queries are read once per opening, on first use.
  const loadSaved = useCallback(async () => {
    if (saved !== null) return;
    try {
      const [bqb, sqlPage] = await Promise.all([
        (api as any).listQueries(true), (api as any).listSqlQueries(true)]);
      setSaved(savedSqlChoices(bqb, sqlPage));
      setSavedError('');
    } catch (e: any) {
      setSaved([]);
      setSavedError(`Saved queries could not be read: ${e?.message || e}`);
    }
  }, [saved]);
  useEffect(() => { if (!open) setSaved(null); }, [open]);

  const sideIsSql = (side: Side) => {
    const c = connOf(side === 'primary' ? editView?.primary_conn_id : editView?.secondary_conn_id);
    return !!c && (!isStorage(c) || sqlMode[side]);
  };

  const setSideSql = (side: Side, sql: string) => {
    if (!editView) return;
    const key = side === 'primary' ? 'primary_query' : 'secondary_query';
    setEditView({ ...editView, [key]: { ...(editView[key] || {}), files: [], raw_sql: sql } });
  };

  const switchSideMode = (side: Side, toSql: boolean) => {
    if (!editView) return;
    const key = side === 'primary' ? 'primary_query' : 'secondary_query';
    setSqlMode(m => ({ ...m, [side]: toSql }));
    // a side is ONE thing: its tables or its SQL, never both
    const q = { ...(editView[key] || {}) };
    if (toSql) { q.files = []; q.raw_sql = q.raw_sql || ''; } else { delete q.raw_sql; q.files = q.files || []; }
    setEditView({ ...editView, [key]: q });
  };

  const updateQueryFiles = (side: Side, tableName: string, add: boolean) => {
    if (!editView) return;
    const key = side === 'primary' ? 'primary_query' : 'secondary_query';
    const connKey = side === 'primary' ? 'primary_conn_id' : 'secondary_conn_id';
    const query = { ...(editView[key] || { files: [], filters: [], columns: [] }) };
    const path = `__registered__:${tableName}`;
    query.files = add ? [...(query.files || []), path] : (query.files || []).filter((f: string) => f !== path);
    setEditView({ ...editView, [key]: query });
    const connId = editView[connKey] as number;
    if (connId) loadSchemaForSide(connId, query.files, side);
  };

  const applySaved = (side: Side, choice: SavedSql | null) => {
    if (!editView || !choice) return;
    const both = side === 'primary' && !!choice.secondaryConnId && !!choice.secondarySql;
    const next: Partial<FederationView> = { ...editView };
    const put = (s: Side, connId: number | null | undefined, sql: string) => {
      const ck = s === 'primary' ? 'primary_conn_id' : 'secondary_conn_id';
      const qk = s === 'primary' ? 'primary_query' : 'secondary_query';
      if (connId) (next as any)[ck] = connId;
      (next as any)[qk] = { ...((next as any)[qk] || {}), files: [], raw_sql: sql };
    };
    put(side, choice.connId, choice.sql);
    if (both) {
      put('secondary', choice.secondaryConnId, choice.secondarySql || '');
      if (choice.combineMode === 'union' || choice.combineMode === 'join') next.combine_mode = choice.combineMode;
    }
    setSqlMode(m => ({ ...m, [side]: true, ...(both ? { secondary: true } : {}) }));
    setEditView(next);
  };

  const handleSave = async () => {
    if (!editView?.name?.trim()) { setError('Name is required'); return; }
    if (!editView.primary_conn_id) { setError('Primary connection is required'); return; }
    if (!editView.secondary_conn_id) { setError('Secondary connection is required'); return; }
    for (const side of ['primary', 'secondary'] as Side[]) {
      const q = side === 'primary' ? editView.primary_query : editView.secondary_query;
      if (sideIsSql(side) && !hasSql(q)) { setError(`The ${side} side has no SQL`); return; }
      if (!sideIsSql(side) && !(q?.files || []).length) { setError(`Pick a table for the ${side} side, or switch it to SQL`); return; }
    }
    setSaving(true);
    setError('');
    try {
      const fv = editView.id
        ? await api.updateFederationView(editView.id, editView)
        : await api.createFederationView(editView as any);
      onSaved(fv as FederationView);
    } catch (e: any) {
      setError(e.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const updateJoinColumn = (idx: number, field: 'left' | 'right', value: string) => {
    if (!editView) return;
    const newJoin = [...(editView.join_on || [])];
    newJoin[idx] = { ...newJoin[idx], [field]: value };
    setEditView({ ...editView, join_on: newJoin });
  };

  const savedFor = useMemo(() => (side: Side) => {
    const cid = side === 'primary' ? editView?.primary_conn_id : editView?.secondary_conn_id;
    return (saved || []).filter(s => !cid || !s.connId || s.connId === cid);
  }, [saved, editView?.primary_conn_id, editView?.secondary_conn_id]);

  const popper = {
    popper: {
      sx: {
        maxWidth: '90vw',
        '& .MuiAutocomplete-listbox': { maxHeight: 280 },
        '& .MuiAutocomplete-option': { whiteSpace: 'normal', wordBreak: 'break-word', fontSize: '0.85rem' },
      },
    },
  };

  const renderSide = (side: Side) => {
    const P = side === 'primary';
    const connId = P ? editView?.primary_conn_id : editView?.secondary_conn_id;
    const query = P ? editView?.primary_query : editView?.secondary_query;
    const conn = connOf(connId);
    const tables: any[] = conn?.config?.registered_tables || [];
    const label = P ? 'Primary' : 'Secondary';
    return (
      <Grid container spacing={2}>
        <Grid size={{ xs: 12, md: 6 }}>
          <FormControl fullWidth margin="dense" size="small">
            <InputLabel id={`sel-federationviewspage-${side}-connection`}>{label} Connection</InputLabel>
            <Select labelId={`sel-federationviewspage-${side}-connection`}
              value={connId || 0}
              label={`${label} Connection`}
              onChange={e => {
                const cid = Number(e.target.value);
                const key = P ? 'primary_conn_id' : 'secondary_conn_id';
                setEditView({ ...editView!, [key]: cid });
              }}
            >
              <MenuItem value={0} disabled>Select...</MenuItem>
              {connections.map(c => <MenuItem key={c.id} value={c.id}>{c.name}</MenuItem>)}
            </Select>
          </FormControl>
          {isStorage(conn) && (
            <ToggleButtonGroup size="small" exclusive sx={{ mt: 0.5 }}
              value={sqlMode[side] ? 'sql' : 'tables'}
              onChange={(_e, v) => v && switchSideMode(side, v === 'sql')}
              aria-label={`${label} side source`}>
              <ToggleButton value="tables" data-testid={`fv-${side}-mode-tables`}>Pick tables</ToggleButton>
              <ToggleButton value="sql" data-testid={`fv-${side}-mode-sql`}>Write SQL</ToggleButton>
            </ToggleButtonGroup>
          )}
        </Grid>
        <Grid size={{ xs: 12, md: 6 }}>
          {sideIsSql(side) ? (
            <>
              <TextField
                fullWidth multiline minRows={3} margin="dense" size="small"
                label={`${label} SQL (runs on this connection)`}
                InputLabelProps={{ shrink: true }}
                placeholder={isStorage(conn)
                  ? 'SELECT region, amount FROM <registered table> WHERE ...'
                  : 'SELECT region, amount FROM catalog.schema.trades'}
                value={query?.raw_sql || ''}
                onChange={e => setSideSql(side, e.target.value)}
                inputProps={{ 'aria-label': `${label} side SQL`, 'data-testid': `fv-${side}-sql` }}
              />
              <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap' }}>
                {!P && (
                  <Button size="small" data-testid="fv-secondary-same-sql"
                    disabled={!hasSql(editView?.primary_query)
                      || editView?.primary_query?.raw_sql === editView?.secondary_query?.raw_sql}
                    onClick={() => setSideSql('secondary', editView?.primary_query?.raw_sql || '')}>
                    Same SQL as the primary
                  </Button>
                )}
                <Autocomplete
                  size="small" sx={{ flex: 1, minWidth: 220 }}
                  options={savedFor(side)}
                  loading={saved === null}
                  onOpen={loadSaved}
                  getOptionLabel={(o: SavedSql) => o.label}
                  isOptionEqualToValue={(a, b) => a.key === b.key}
                  value={null}
                  onChange={(_e, v) => applySaved(side, v)}
                  slotProps={popper}
                  renderInput={(params) => (
                    <TextField {...params} margin="dense"
                      placeholder="Load SQL from a saved query..."
                      inputProps={{ ...params.inputProps, 'data-testid': `fv-${side}-saved` }} />
                  )}
                />
              </Box>
              {savedError && <Alert severity="warning" sx={{ mt: 0.5 }}>{savedError}</Alert>}
            </>
          ) : (
            <>
              <Typography variant="caption" color="text.secondary">
                Tables: {(query?.files || []).map((f: string) => f.replace('__registered__:', '')).join(', ')
                  || 'none selected'}
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.5 }}>
                {tables.map((t: any) => {
                  const selected = (query?.files || []).includes(`__registered__:${t.name}`);
                  return (
                    <Chip key={t.name} label={t.name} size="small"
                      color={selected ? (P ? 'primary' : 'secondary') : 'default'}
                      variant={selected ? 'filled' : 'outlined'}
                      onClick={() => updateQueryFiles(side, t.name, !selected)} />
                  );
                })}
              </Box>
            </>
          )}
        </Grid>
      </Grid>
    );
  };

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="md"
      data-testid="fv-editor-dialog"
      title={editView?.id ? 'Edit Federation View' : 'Create Federation View'}
      actions={<>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} disabled={saving} data-testid="fv-editor-save">
          {saving ? <CircularProgress size={20} /> : (editView?.id ? 'Update' : 'Create')}
        </Button>
      </>}>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        <TextField label="View Name" fullWidth margin="dense"
          value={editView?.name || ''}
          onChange={e => setEditView({ ...editView!, name: e.target.value })} />
        <TextField label="Description" fullWidth margin="dense" multiline rows={2}
          value={editView?.description || ''}
          onChange={e => setEditView({ ...editView!, description: e.target.value })} />

        <Divider sx={{ my: 2 }} />
        <Typography variant="subtitle2" gutterBottom>Primary Connection (Left Side)</Typography>
        {renderSide('primary')}

        <Divider sx={{ my: 2 }} />
        <Typography variant="subtitle2" gutterBottom>Secondary Connection (Right Side)</Typography>
        {renderSide('secondary')}

        <Divider sx={{ my: 2 }} />
        <Typography variant="subtitle2" gutterBottom>Combine Mode</Typography>
        <Grid container spacing={2} alignItems="center">
          <Grid size={{ xs: 12, md: 4 }}>
            <FormControl fullWidth margin="dense" size="small">
              <InputLabel id="sel-federationviewspage-mode">Mode</InputLabel>
              <Select labelId="sel-federationviewspage-mode"
                value={editView?.combine_mode || 'union'}
                label="Mode"
                onChange={e => setEditView({ ...editView!, combine_mode: e.target.value })}
              >
                <MenuItem value="union">UNION ALL (stack rows by column name)</MenuItem>
                <MenuItem value="join">JOIN (match columns)</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          {editView?.combine_mode === 'join' && (
            <Grid size={{ xs: 12, md: 4 }}>
              <FormControl fullWidth margin="dense" size="small">
                <InputLabel id="sel-federationviewspage-join-type">Join Type</InputLabel>
                <Select labelId="sel-federationviewspage-join-type"
                  value={editView?.join_how || 'inner'}
                  label="Join Type"
                  onChange={e => setEditView({ ...editView!, join_how: e.target.value })}
                >
                  <MenuItem value="inner">INNER JOIN</MenuItem>
                  <MenuItem value="left">LEFT JOIN</MenuItem>
                  <MenuItem value="right">RIGHT JOIN</MenuItem>
                  <MenuItem value="full">FULL OUTER JOIN</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          )}
        </Grid>

        {editView?.combine_mode === 'join' && (
          <Box sx={{ mt: 2 }}>
            <Typography variant="caption" gutterBottom>Join Column Mapping</Typography>
            {(editView.join_on || []).map((jo, idx) => (
              <Grid container spacing={1} key={idx} sx={{ mb: 1 }} alignItems="center">
                <Grid size={{ xs: 5 }}>
                  <Autocomplete size="small" freeSolo options={primarySchema}
                    getOptionLabel={(opt: any) => typeof opt === 'string' ? opt : `${opt.name} (${opt.type})`}
                    value={jo.left || ''}
                    onInputChange={(_e, val) => updateJoinColumn(idx, 'left', val)}
                    onChange={(_e, val) => updateJoinColumn(idx, 'left', typeof val === 'string' ? val : val?.name || '')}
                    slotProps={popper}
                    renderInput={(params) => <TextField {...params} placeholder="Primary column" />} />
                </Grid>
                <Grid size={{ xs: 1 }}><Typography align="center">=</Typography></Grid>
                <Grid size={{ xs: 5 }}>
                  <Autocomplete size="small" freeSolo options={secondarySchema}
                    getOptionLabel={(opt: any) => typeof opt === 'string' ? opt : `${opt.name} (${opt.type})`}
                    value={jo.right || ''}
                    onInputChange={(_e, val) => updateJoinColumn(idx, 'right', val)}
                    onChange={(_e, val) => updateJoinColumn(idx, 'right', typeof val === 'string' ? val : val?.name || '')}
                    slotProps={popper}
                    renderInput={(params) => <TextField {...params} placeholder="Secondary column" />} />
                </Grid>
                <Grid size={{ xs: 1 }}>
                  <IconButton aria-label="Delete" size="small" color="error"
                    onClick={() => {
                      const j = [...(editView.join_on || [])]; j.splice(idx, 1);
                      setEditView({ ...editView, join_on: j });
                    }}>
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Grid>
              </Grid>
            ))}
            <Button size="small"
              onClick={() => setEditView({ ...editView, join_on: [...(editView.join_on || []), { left: '', right: '' }] })}>
              + Add Column
            </Button>
          </Box>
        )}

        <FormControlLabel
          control={<Switch checked={editView?.is_active !== false}
            onChange={e => setEditView({ ...editView!, is_active: e.target.checked })} />}
          label="Active" sx={{ mt: 1 }} />
    </AppDialog>
  );
};

export default FederationViewEditorDialog;
