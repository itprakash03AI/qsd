/**
 * API — Connections, Uploads, Iceberg, Registered Tables, REST Queries, Profiles
 */
import { safeFetch, uploadFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';

const connections = {
  // ── Connections ───────────────────────────────────────────────────────────
  listConnections: (activeOnly = true) =>
    safeFetch(`/api/connections?active_only=${activeOnly}`).catch(() => []),
  getConnection: (id: string) => safeFetch(`/api/connections/${id}`),
  createConnection: (data: object) =>
    safeFetch('/api/connections', { method: 'POST', body: safeStringify(data) }),
  updateConnection: (id: string, data: object) =>
    safeFetch(`/api/connections/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteConnection: (id: string) =>
    safeFetch(`/api/connections/${id}`, { method: 'DELETE' }),
  // FB-62 (2026-09-23).  The body carries a NAME and nothing else, on
  // purpose: the backend rejects any other field (422), because a request
  // that could both copy a credential and change the host is the
  // exfiltration shape this route was designed against.  Repointing a copy
  // is a second, owner-gated, audited update.
  cloneConnection: (id: string, name?: string) =>
    safeFetch(`/api/connections/${id}/clone`, {
      method: 'POST',
      body: safeStringify(name ? { name } : {}),
    }),
  testConnection: (data: object) =>
    safeFetch('/api/connections/test', { method: 'POST', body: safeStringify(data) }),
  testSavedConnection: (id: string) =>
    safeFetch(`/api/connections/${id}/test`, { method: 'POST' }),
  refreshConnectionCredentials: (id: string) =>
    safeFetch(`/api/connections/${id}/refresh-credentials`, { method: 'POST' }),
  // 2026-11-01 -- Iceberg table VERSIONS (backend core/iceberg_versions.py).
  // One row per Iceberg table the SQL reads, each with its versions newest
  // first; with `set`, the SQL with that table's FOR VERSION AS OF changed.
  // `set.as_of` (an ISO time) writes FOR TIMESTAMP AS OF instead (2026-11-01).
  sqlTableVersions: (body: { connection_id: number; sql: string;
                             set?: { table: string; snapshot_id: string | null; as_of?: string | null } }) =>
    safeFetch('/api/sql/table-versions', { method: 'POST', body: safeStringify(body) }),
  listIcebergTableVersions: (connId: number, table: string) =>
    safeFetch(`/api/connections/${connId}/iceberg/${encodeURIComponent(table)}/snapshots`),
  listConnectionFiles: (connId: string, folder = '') =>
    safeFetch(`/api/connections/${connId}/files?folder=${encodeURIComponent(folder)}`),
  getConnectionFileSchema: (connId: string, filePath: string) =>
    safeFetch(`/api/connections/${connId}/files/${encodeURIComponent(filePath)}/schema`),
  listConnectionExcelSheets: (connId: string, filePath: string) =>
    safeFetch(`/api/connections/${connId}/excel-sheets?file_path=${encodeURIComponent(filePath)}`),

  // ── Upload connection files ─────────────────────────────────────────────
  uploadConnectionFiles: (connId: string, files: File[]): Promise<any> => {
    const form = new FormData();
    files.forEach(f => form.append('files', f));
    return uploadFetch(`/api/connections/${connId}/upload-files`, form);
  },
  listUploadedFiles: (connId: string) =>
    safeFetch(`/api/connections/${connId}/uploaded-files`),
  deleteUploadedFile: (connId: string, filename: string) =>
    safeFetch(`/api/connections/${connId}/uploaded-files/${encodeURIComponent(filename)}`, { method: 'DELETE' }),
  getUploadConnectionsStatus: () =>
    safeFetch('/api/connections/upload-status'),

  // ── Iceberg ─────────────────────────────────────────────────────────────
  listIcebergTables: (connId: string, prefix = '') =>
    safeFetch(`/api/connections/${connId}/iceberg/tables?prefix=${encodeURIComponent(prefix)}`),
  listIcebergFiles: (connId: string, tablePrefix: string) =>
    safeFetch(`/api/connections/${connId}/iceberg/files?table_prefix=${encodeURIComponent(tablePrefix)}`),

  // ── Registered Tables ──────────────────────────────────────────────────
  listRegisteredTables: (connId: string) =>
    safeFetch(`/api/connections/${connId}/tables`),
  registerTable: (connId: string, table: { name: string; s3_prefix: string; format: string; description?: string }) =>
    safeFetch(`/api/connections/${connId}/tables`, { method: 'POST', body: safeStringify(table) }),
  unregisterTable: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}`, { method: 'DELETE' }),
  getRegisteredTableSchema: (connId: string, tableName: string, refresh?: boolean) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/schema${refresh ? '?refresh=true' : ''}`),
  refreshTableSchema: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/schema/refresh`, { method: 'POST' }),
  refreshAllSchemas: (connId: string) =>
    safeFetch(`/api/connections/${connId}/schema/refresh-all`, { method: 'POST' }),
  getRegisteredTablePartitions: (connId: string, tableName: string, fullScan?: boolean) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/partitions${fullScan ? '?full_scan=true' : ''}`),
  refreshPartitionCache: (connId: string, tableName: string) =>
    safeFetch(`/api/connections/${connId}/tables/${encodeURIComponent(tableName)}/partitions/refresh`, { method: 'POST' }),
  refreshAllPartitions: (connId?: string) =>
    safeFetch(`/api/partitions/refresh-all${connId ? `?connection_id=${connId}` : ''}`, { method: 'POST' }),
  discoverTables: (connId: string, prefix?: string) =>
    safeFetch(`/api/connections/${connId}/discover-tables?prefix=${encodeURIComponent(prefix || '')}`),
  browseFolders: (connId: string, prefix?: string) =>
    safeFetch(`/api/connections/${connId}/browse-folders?prefix=${encodeURIComponent(prefix || '')}`),

  // ── REST API Query Definitions ─────────────────────────────────────────
  listRestQueryDefs: (connId: string) =>
    safeFetch(`/api/connections/${connId}/rest-queries`),
  createRestQueryDef: (connId: string, data: object) =>
    safeFetch(`/api/connections/${connId}/rest-queries`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: safeStringify(data) }),
  getRestQueryDef: (connId: string, qid: number) =>
    safeFetch(`/api/connections/${connId}/rest-queries/${qid}`),
  updateRestQueryDef: (connId: string, qid: number, data: object) =>
    safeFetch(`/api/connections/${connId}/rest-queries/${qid}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: safeStringify(data) }),
  deleteRestQueryDef: (connId: string, qid: number) =>
    safeFetch(`/api/connections/${connId}/rest-queries/${qid}`, { method: 'DELETE' }),
  previewRestQuery: (connId: string, qid: number) =>
    safeFetch(`/api/connections/${connId}/rest-queries/${qid}/preview`, { method: 'POST' }),

  // ── Connection Profiles ─────────────────────────────────────────────────
  listConnectionProfiles: () =>
    safeFetch('/api/connection-profiles').catch(() => ({ profiles: [] })),
  getActiveProfile: () =>
    safeFetch('/api/connection-profiles/active').catch(() => null),
  createConnectionProfile: (data: object) =>
    safeFetch('/api/connection-profiles', { method: 'POST', body: safeStringify(data) }),
  updateConnectionProfile: (id: number, data: object) =>
    safeFetch(`/api/connection-profiles/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteConnectionProfile: (id: number) =>
    safeFetch(`/api/connection-profiles/${id}`, { method: 'DELETE' }),
  activateConnectionProfile: (id: number) =>
    safeFetch(`/api/connection-profiles/${id}/activate`, { method: 'POST' }),
  deactivateAllProfiles: () =>
    safeFetch('/api/connection-profiles/deactivate', { method: 'POST' }),
  getProfileMappings: (id: number) =>
    safeFetch(`/api/connection-profiles/${id}/mappings`).catch(() => ({ mappings: [] })),
  setProfileMappings: (id: number, mappings: object[]) =>
    safeFetch(`/api/connection-profiles/${id}/mappings`, { method: 'PUT', body: safeStringify({ mappings }) }),

  // ── Report Connectors Matrix ────────────────────────────────────────────
  // FB-60 / F7 (2026-09-26): finance reports with a SQL source (raw_sql).
  // The legacy /api/reports/... paths answer 308 for one release only.
  getReportConnectorMatrix: () =>
    safeFetch('/api/report-connectors/matrix').catch(() => ({ reports: [] })),
  bulkSetConnectionOverride: (reportIds: number[], connectionOverrideId: number | null) =>
    safeFetch('/api/report-connectors/bulk-set-override', {
      method: 'POST',
      body: safeStringify({ report_ids: reportIds, connection_override_id: connectionOverrideId }),
    }),
};

export default connections;
