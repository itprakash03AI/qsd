/**
 * A page of the report's own table in Arrow (2026-10-30, every report a canvas;
 * the owner: "need faster data ... faster lightweight html").
 *
 * Asks `GET .../results/{execId}` with `Accept: application/vnd.apache.arrow.stream`
 * and reads the answer by its Content-Type: Arrow -> utils/arrowStream.ts (the
 * very JSON envelope, `{...meta, rows}`); JSON -> as always.  The server keeps a
 * page JSON when a column is an exact DECIMAL (Arrow would carry a float) and
 * says so in `X-Page-Format-Reason` -- kept on the answer as `__transport.reason`.
 *
 * Anything but a plain 200 (a refusal, a 409, a network hiccup, bytes this
 * browser cannot read) is asked again on the OLD road, `fallback`, so every
 * error keeps exactly the words and shape the viewer has always handled.
 */
import { rawFetch } from './core';
import { decodeCubeArrow } from '../../utils/arrowStream';
import { ARROW_STREAM } from './cubeArrow';

export interface PageTransport { format: 'arrow' | 'json'; bytes: number; reason: string | null }

export const pageTransportOf = (answer: any): PageTransport | null => answer?.__transport ?? null;

function tag(answer: any, t: PageTransport) {
  if (answer && typeof answer === 'object') Object.defineProperty(answer, '__transport', { value: t, enumerable: false });
  return answer;
}

export function pageQuery(page: number, pageSize: number, sortColumn?: string | null, sortDirection?: string | null,
                          links?: string | null): URLSearchParams {
  const qs = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
  if (sortColumn) qs.set('sort_column', sortColumn);
  if (sortDirection) qs.set('sort_direction', sortDirection);
  if (links) qs.set('links', links);
  return qs;
}

/** GET one page, preferring Arrow; `fallback` is the JSON road (its errors are the viewer's). */
export async function getReportPageArrow(reportId: number, execId: string, page: number, pageSize: number,
                                         sortColumn: string | null | undefined, sortDirection: string | null | undefined,
                                         links: string | null | undefined, fallback: () => Promise<any>): Promise<any> {
  const url = `/api/business-reports/${reportId}/results/${execId}?${pageQuery(page, pageSize, sortColumn, sortDirection, links)}`;
  let resp: Response;
  try {
    resp = await rawFetch(url, { headers: { Accept: ARROW_STREAM } });
  } catch {
    return fallback();
  }
  if (!resp.ok) return fallback();
  const type = resp.headers.get('content-type') || '';
  try {
    if (type.includes(ARROW_STREAM)) {
      const buf = await resp.arrayBuffer();
      return tag(decodeCubeArrow(buf), { format: 'arrow', bytes: buf.byteLength, reason: null });
    }
    const text = await resp.text();
    return tag(JSON.parse(text), { format: 'json', bytes: text.length, reason: resp.headers.get('x-page-format-reason') });
  } catch {
    return fallback();
  }
}
