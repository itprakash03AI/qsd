/**
 * A canvas tile's cube request in Arrow (2026-10-30).
 *
 * Asks the signed-in cube route with `Accept: application/vnd.apache.arrow.stream`
 * and reads whichever answer comes back by its Content-Type: Arrow ->
 * utils/arrowStream.ts, JSON -> as always (the server answers JSON whenever Arrow
 * could not carry the values exactly).  If the Arrow bytes cannot be read
 * here, it asks once more for JSON -- never a wrong value, never no tile.
 * Errors are shaped exactly as `api.queryReportCube`'s (status + structured
 * detail), so a tile's refusal sentence is unchanged.
 *
 * Each answer carries `__transport: {format, bytes}` (non-enumerable) for the
 * render stats.
 */
import { rawFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';
import { decodeCubeArrow } from '../../utils/arrowStream';

export const ARROW_STREAM = 'application/vnd.apache.arrow.stream';

export interface CubeTransport { format: 'arrow' | 'json'; bytes: number; }

export const transportOf = (answer: any): CubeTransport | null => answer?.__transport ?? null;

function tag(answer: any, t: CubeTransport) {
  if (answer && typeof answer === 'object') Object.defineProperty(answer, '__transport', { value: t, enumerable: false });
  return answer;
}

async function failure(resp: Response): Promise<never> {
  let payload: any = null;
  try { payload = await resp.json(); } catch { /* non-JSON error body */ }
  const detail = payload?.detail;
  const message = typeof detail === 'string' ? detail : (detail?.message || `Cube query failed (HTTP ${resp.status})`);
  const err: any = new Error(message);
  err.status = resp.status;
  err.detail = detail;
  throw err;
}

async function ask(url: string, body: any, arrow: boolean): Promise<any> {
  const resp = await rawFetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(arrow ? { Accept: ARROW_STREAM } : {}) },
    body: safeStringify(body),
  });
  if (!resp.ok) return failure(resp);
  const type = resp.headers.get('content-type') || '';
  if (type.includes(ARROW_STREAM)) {
    const buf = await resp.arrayBuffer();
    return tag(decodeCubeArrow(buf), { format: 'arrow', bytes: buf.byteLength });
  }
  const text = await resp.text();
  return tag(JSON.parse(text), { format: 'json', bytes: text.length });
}

/** POST .../results/{execId}/cube, preferring Arrow. */
export async function queryReportCubeArrow(reportId: number, execId: string, body: any): Promise<any> {
  const url = `/api/business-reports/${reportId}/results/${execId}/cube`;
  try {
    return await ask(url, body, true);
  } catch (err: any) {
    if (err?.status) throw err;            // the server refused: its words, unchanged
    return ask(url, body, false);          // the bytes could not be read here: JSON
  }
}
