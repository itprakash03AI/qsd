/**
 * API Core — shared infrastructure for all API domain modules.
 * Provides safeFetch, sharedFetch, openDownload, error parsing, and shared types.
 */

import { getAuthHeader } from '../authState';
import type { PartitionConfig } from '../../types/api';

// Runtime config: index.html loads /config.js synchronously (primary
// path; main.tsx fallback path fetches /config.json if config.js
// failed) BEFORE evaluating this module. So window.APP_CONFIG is
// guaranteed set by the time API_BASE_URL is computed.
//
// Local dev: public/config.js / public/config.json both have apiUrl=""
// → falls through to empty → Vite proxy.
//
// Production: Helm ConfigMap templates both files from values.yaml.
// 2026-06-25 fix: the newer chart (k8s/querystudioapi-helm/ui) used
// to set ``window.__QS_CONFIG__`` -- mismatched the name this module
// reads -> apiUrl silently dropped, every fetch went same-origin.
// Both charts now set ``window.APP_CONFIG``.
//
// Deep-dive #8 (2026-06-30): single source of truth for the
// window.APP_CONFIG type lives in src/types/app-config.d.ts.  No
// import needed -- tsconfig include picks it up.  Was duplicated
// here + in main.tsx pre-fix; TS declaration merging silently
// allowed drift.
// 2026-06-30 fix — lazy resolution.  Pre-fix this module captured
// API_BASE_URL into a const at PARSE TIME.  When config.js shipped
// the empty stub apiUrl="" AND main.tsx had a static `import App`
// (so the App import graph including THIS module evaluated before
// ensureAppConfig() fetched /config.json), API_BASE_URL was frozen
// as '' even when /config.json had a populated apiUrl.  Every fetch
// went same-origin -> SPA catch-all returned index.html -> the
// safeFetch content-type guard surfaced "Backend returned HTML
// instead of JSON" / "Unexpected token '<'".  Reported by operator
// 2026-06-30.
//
// Fix has two layers:
//   1. main.tsx now dynamically imports App AFTER ensureAppConfig
//      resolves -- so on the happy path this module evaluates with
//      the final window.APP_CONFIG already populated.
//   2. THIS module re-reads window.APP_CONFIG inside resolveApiBaseUrl
//      / resolvePublishedApiBaseUrl helpers.  Even if a future
//      regression reintroduces an early import, the URL still tracks
//      the live config because fetch sites call the resolver instead
//      of reading a stale const.
//
// Exported `API_BASE_URL` / `PUBLISHED_API_BASE_URL` are const
// SNAPSHOTS captured at core.ts module-parse time.  This is SAFE
// because main.tsx dynamically imports App AFTER ensureAppConfig()
// finishes (2026-06-30 fix in main.tsx) so window.APP_CONFIG is
// fully populated by the time this module evaluates.  Any consumer
// that needs to survive a future regression to early-import MUST
// use `resolveApiBaseUrl()` at REQUEST time -- see the CI guard in
// __tests__/core.test.ts for the enforced consumer list.  All
// internal fetch helpers below already call the resolver directly.
const _validateAndNormalize = (raw: string, label: string): string => {
  if (!raw) return '';
  if (!raw.startsWith('http')) {
    console.warn(`[api/core] ${label} "${raw}" ignored — must start with http:// or https://. Using same-origin (empty base).`);
    return '';
  }
  return raw.replace(/\/+$/, '');
};

let _lastLoggedApiBase = '__sentinel__';
const resolveApiBaseUrl = (): string => {
  const raw = window.APP_CONFIG?.apiUrl ?? import.meta.env.VITE_API_URL ?? '';
  const out = _validateAndNormalize(raw, 'apiUrl');
  // Log only on first call OR on change so we don't flood the console.
  if (out !== _lastLoggedApiBase) {
    if (out) {
      console.info(`[api/core] API_BASE_URL resolved to: ${out}`);
    } else if (_lastLoggedApiBase && _lastLoggedApiBase !== '__sentinel__') {
      console.info('[api/core] API_BASE_URL now empty (same-origin).');
    }
    _lastLoggedApiBase = out;
  }
  return out;
};

/**
 * Paths served ONLY by the Report API pod.
 *
 * Derived from the routers `main.py` mounts under QUERYSTUDIO_REPORTS_MODE,
 * NOT guessed: that pod also serves /api/datasets, /api/columns and
 * /api/admin, but those are served by the main API too, so routing them here
 * would be a coin-flip between two pods for the same path. Only the
 * unambiguous report-owned prefixes are redirected; everything else stays on
 * apiUrl, where it has always worked.
 */
const REPORT_API_PREFIXES = [
  '/api/business-reports',
  '/api/shared-business-report',
  '/api/embedded-business-report',
  '/api/subscriptions',
  '/api/unsubscribe',
] as const;

/**
 * Download Centre paths (2026-08-30).  These nine routes are owned by
 * api/downloads_api.py and can be served by a dedicated pod, because
 * preview/chart/pivot submit their DuckDB work to the SAME worker pool the
 * API pod uses to execute queries — so browsing old files competed with
 * running new ones.  When downloadApiUrl is unset these fall through to the
 * ordinary API base, which is exactly today's behaviour for every
 * deployment that has not split the pod out.
 */
const DOWNLOAD_API_PREFIXES = [
  '/api/downloads',
  '/api/exports',
] as const;

let _lastLoggedDlBase = '__sentinel__';
const resolveDownloadApiBaseUrl = (): string => {
  const raw = window.APP_CONFIG?.downloadApiUrl ?? '';
  const out = _validateAndNormalize(raw, 'downloadApiUrl');
  if (out !== _lastLoggedDlBase) {
    if (out) {
      console.info(`[api/core] DOWNLOAD_API_BASE_URL resolved to: ${out}`);
    }
    _lastLoggedDlBase = out;
  }
  return out;
};

let _lastLoggedRptBase = '__sentinel__';
const resolveReportApiBaseUrl = (): string => {
  const raw = window.APP_CONFIG?.reportApiUrl ?? '';
  const out = _validateAndNormalize(raw, 'reportApiUrl');
  if (out !== _lastLoggedRptBase) {
    if (out) {
      console.info(`[api/core] REPORT_API_BASE_URL resolved to: ${out}`);
    }
    _lastLoggedRptBase = out;
  }
  return out;
};

/**
 * The base URL a given API path should be called on.
 *
 * Falls back to the main API base whenever reportApiUrl is unset, so a
 * single-pod deployment is byte-identical to before this existed.
 */
const resolveBaseForPath = (path: string): string => {
  if (typeof path === 'string' &&
      DOWNLOAD_API_PREFIXES.some((p) => path.startsWith(p))) {
    const dl = resolveDownloadApiBaseUrl();
    if (dl) return dl;
  }
  if (typeof path === 'string' &&
      REPORT_API_PREFIXES.some((p) => path.startsWith(p))) {
    const rpt = resolveReportApiBaseUrl();
    if (rpt) return rpt;
  }
  return resolveApiBaseUrl();
};

let _lastLoggedPubBase = '__sentinel__';
const resolvePublishedApiBaseUrl = (): string => {
  const raw = window.APP_CONFIG?.publishedApiUrl ?? '';
  const out = _validateAndNormalize(raw, 'publishedApiUrl');
  if (out !== _lastLoggedPubBase) {
    if (out) {
      console.info(`[api/core] PUBLISHED_API_BASE_URL resolved to: ${out}`);
    }
    _lastLoggedPubBase = out;
  }
  return out;
};

// Back-compat: existing consumers may read API_BASE_URL directly as
// a string value.  Snapshotted at module parse time.  This is SAFE
// now that main.tsx dynamically imports App AFTER ensureAppConfig
// finishes -- so by the time THIS module evaluates window.APP_CONFIG
// already reflects the merged config.js + /config.json.  But the
// internal fetch helpers below call resolveApiBaseUrl() at REQUEST
// time anyway, so even a future regression to early-import would
// not strand fetches at the empty same-origin URL.
export const API_BASE_URL: string = resolveApiBaseUrl();
export const PUBLISHED_API_BASE_URL: string = resolvePublishedApiBaseUrl();
export const REPORT_API_BASE_URL: string = resolveReportApiBaseUrl();
export { resolveApiBaseUrl, resolvePublishedApiBaseUrl, resolveReportApiBaseUrl,
         resolveDownloadApiBaseUrl, resolveBaseForPath, REPORT_API_PREFIXES,
         DOWNLOAD_API_PREFIXES };

export class ApiError extends Error {
  errorCode?: string;
  connectionId?: number;
  /**
   * The HTTP status that produced this error.
   *
   * 2026-08-25 — this field did not exist, while `response.status` was in
   * scope at every throw site. Consequently EVERY consumer guard reading
   * `err?.status` compared `undefined` and silently took the else-branch:
   * two execution pollers never stopped on a 404 (they poll a dead execution
   * forever), the report viewer's documented 404 fallback to the client
   * engine never ran and showed "Server drill query failed" instead, and
   * `isEndpointMissing` — the basis of the report lifecycle's graceful
   * degradation — could not detect a 404 at all.
   *
   * Optional because a few failures have no response: a timeout, an abort,
   * or "failed after retries". `undefined` there is honest — the request
   * never received a status — and consumers already treat a missing status
   * as "not a 404".
   */
  status?: number;
  /**
   * The server's STRUCTURED `detail`, when it sent an object (2026-10-07).
   *
   * `message` is the sentence to show; this is what the caller acts on.
   * The query builder's pre-validation refusal is a 400 whose detail is
   * `{type: 'sql_pre_validation_failed', error, error_type,
   * agent_suggestion}` -- the parser kept only `JSON.stringify(detail)`, so
   * the builder showed raw JSON in its banner and its `err.detail.
   * agent_suggestion` branch could never run ("Add GROUP BY clause" never
   * appeared).  Read it through `structuredDetail(err)`.
   *
   * Deliberately NOT named `detail`: some thirty callers render
   * `err?.detail || err?.message` as text, and an object there would crash
   * React instead of showing a sentence.
   */
  payload?: Record<string, any>;
  constructor(message: string, errorCode?: string, connectionId?: number,
              status?: number, payload?: Record<string, any>) {
    super(message);
    this.name = 'ApiError';
    this.errorCode = errorCode;
    this.connectionId = connectionId;
    this.status = status;
    this.payload = payload;
  }
}

/**
 * The structured refusal an error carries, or undefined.
 *
 * ONE reader for both error shapes in this client: an `ApiError` from
 * safeFetch / sharedFetch / uploadFetch (`payload`), and the hand-built
 * errors of the raw fetch helpers in businessReports.ts (`detail`, when it
 * is an object).
 */
export const structuredDetail = (err: unknown): Record<string, any> | undefined => {
  const e = err as any;
  if (e?.payload && typeof e.payload === 'object' && !Array.isArray(e.payload)) return e.payload;
  if (e?.detail && typeof e.detail === 'object' && !Array.isArray(e.detail)) return e.detail;
  return undefined;
};

/** The sentence a structured detail object reads as. */
const sentenceOfDetail = (d: Record<string, any>): string => {
  if (typeof d.message === 'string' && d.message) return d.message;
  // `error` is a sentence on some refusals (the pre-validation 400's
  // `error` is the engine's own message) and a bare code on others
  // (`non_additive_measures`).  A code is not a sentence: show the JSON.
  if (typeof d.error === 'string' && /\s/.test(d.error.trim())) return d.error;
  return JSON.stringify(d);
};

const RETRY_STATUSES = new Set([502, 503, 504]);
const MAX_RETRIES = 2;
const RETRY_DELAYS = [1000, 3000];

// Round 10 deep-dive (2026-06-30): dedupe the qs:auth-expired event
// when N concurrent fetches all get 401 at once.  Pre-fix every 401
// removed localStorage AND dispatched the event -- so 5 in-flight
// fetches caused 5 reauth-modal toggles + 5 localStorage writes in
// rapid succession.  We coalesce: at most one dispatch per
// AUTH_EXPIRED_COOLDOWN_MS window.  The cooldown resets when the
// next successful 2xx arrives so a SECOND session expiry later still
// fires the modal.
const AUTH_EXPIRED_COOLDOWN_MS = 5000;
let _lastAuthExpiredDispatchMs = 0;
const _resetAuthExpiredCooldown = () => { _lastAuthExpiredDispatchMs = 0; };

export const _parseError = async (response: Response): Promise<{
  detail: string; errorCode?: string; connectionId?: number;
  /** The server's detail when it was an object -- see ApiError.payload. */
  payload?: Record<string, any>;
}> => {
  let detail = `HTTP ${response.status}`;
  let errorCode: string | undefined;
  let connectionId: number | undefined;
  let payload: Record<string, any> | undefined;
  try {
    const e = await response.json() as { detail?: any; message?: string };
    if (typeof e.detail === 'string') {
      detail = e.detail;
    } else if (Array.isArray(e.detail)) {
      // BF-428M — safeStringify defends against polluted error payloads
      // (e.g., a Pydantic error whose `input` field carries a complex
      // object) — native JSON.stringify would crash with circular ref.
      const { safeStringify } = await import('../../utils/safeStringify');
      detail = (e.detail as { msg?: string; loc?: any[]; input?: any }[]).map(d => {
        let s = d.msg || safeStringify(d);
        if (d.loc) s += ` [field: ${d.loc.join('.')}]`;
        if (d.input !== undefined) s += ` [got: ${safeStringify(d.input)}]`;
        return s;
      }).join('; ');
    } else if (e.detail && typeof e.detail === 'object') {
      payload = e.detail;
      detail = sentenceOfDetail(e.detail);
      // BRD STEP 1 (2026-09-02) — a structured refusal that carries
      // findings (e.g. the feed output-contract 422: {message,
      // findings: [{field, severity, message, rule}]}) previously
      // collapsed to just its headline, swallowing WHICH term was
      // refused and why.  Surface every finding the backend named.
      if (Array.isArray(e.detail.findings) && e.detail.findings.length > 0) {
        detail += ': ' + (e.detail.findings as any[])
          .map(f => `[${f?.severity ?? 'error'}] ${f?.field}: ${f?.message}`)
          .join('; ');
      }
      errorCode = e.detail.error_code;
      connectionId = e.detail.connection_id;
    } else if (e.message) {
      detail = e.message;
    }
  } catch {}
  return { detail, errorCode, connectionId, payload };
};

/**
 * The request body as fetch needs it.  A PLAIN OBJECT is sent as JSON.
 *
 * 2026-09-24 (click crawl): five SQL-editor features passed an object
 * (`body: {...} as any`); fetch stringifies that as "[object Object]", the
 * server answered 422, and each feature's fail-open catch hid it -- Format
 * did nothing, Explain / Explain-in-English / SQL-to-Visual failed, Run All
 * quietly fell back to splitting on ";".  safeFetch already declares the
 * body JSON (Content-Type), so it serialises one it was handed as an object.
 * Strings, FormData, Blobs, URLSearchParams and buffers pass through.
 */
export const _jsonBody = (body: any): BodyInit | null | undefined => {
  if (body == null || typeof body === 'string') return body;
  if (typeof FormData !== 'undefined' && body instanceof FormData) return body;
  if (typeof Blob !== 'undefined' && body instanceof Blob) return body;
  if (typeof URLSearchParams !== 'undefined' && body instanceof URLSearchParams) return body;
  if (body instanceof ArrayBuffer || ArrayBuffer.isView(body)) return body as BodyInit;
  if (typeof ReadableStream !== 'undefined' && body instanceof ReadableStream) return body;
  if (Object.getPrototypeOf(body) === Object.prototype || Array.isArray(body)) {
    return JSON.stringify(body);
  }
  return body;
};

// 2026-07-03 audit fix: safeFetch is generic so callers can request
// a return type (e.g. `safeFetch<LogicalTable[]>('/api/...')`).  Prior
// signature returned `any` unconditionally, so callers that annotated
// via `<T>` triggered TS2558 ("Expected 0 type arguments, but got 1")
// and lost their type safety silently.  Default `T = any` keeps
// back-compat with all existing untyped callers.
export const safeFetch = async <T = any>(
  url: string,
  // 2026-06-04 audit — added retryOnTimeout (default true).  Polling
  // callers (Operations Dashboard, Query Diagnostic) should pass false
  // so a slow endpoint doesn't generate 3 overlapping requests within
  // the polling interval.  GET retries on network TypeError still fire
  // regardless.
  options: RequestInit & { timeoutMs?: number; retryOnTimeout?: boolean } = {},
): Promise<T> => {
  const fullUrl = url.startsWith('http') ? url : `${resolveBaseForPath(url)}${url}`;
  const headers: Record<string, string> = {
    ...(options.body ? { 'Content-Type': 'application/json' } : {}),
    ...(options.headers as Record<string, string>),
  };
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;
  // Phase 83D: add correlation ID for end-to-end request tracing in logs
  headers['X-Request-ID'] = Math.random().toString(36).slice(2, 10);
  const method = (options.method || 'GET').toUpperCase();
  const canRetry = method === 'GET';

  let lastError: Error | null = null;
  const attempts = canRetry ? MAX_RETRIES + 1 : 1;

  // BF-406: per-request timeout so a single slow request doesn't appear
  // as "backend dead" (which the old reload-on-401 used to wreck UI for).
  // 2026-06-03 — bumped default 60s → 120s after operator hit AbortError
  // on admin listing endpoints (background jobs, metadata sync, column
  // stats status) that legitimately take 60-90s on hot caches.  Callers
  // can override via the new ``timeoutMs`` option.
  const REQUEST_TIMEOUT_MS = options.timeoutMs ?? 120000;
  for (let attempt = 0; attempt < attempts; attempt++) {
    // Declared per-iteration but OUTSIDE the try block so the catch
    // handler can read it.  Reset on every attempt.
    let didTimeout = false;
    try {
      // Honour caller-supplied signal — combine with our timeout
      let signal = options.signal as AbortSignal | undefined;
      let timeoutId: ReturnType<typeof setTimeout> | null = null;
      if (!signal) {
        const ctrl = new AbortController();
        timeoutId = setTimeout(() => {
          didTimeout = true;
          ctrl.abort();
        }, REQUEST_TIMEOUT_MS);
        signal = ctrl.signal;
      }
      const response = await fetch(fullUrl, { ...options, body: _jsonBody(options.body), headers, signal });
      if (timeoutId) clearTimeout(timeoutId);
      if (!response.ok) {
        if (response.status === 401) {
          const { detail, errorCode: ec, connectionId: cid, payload } = await _parseError(response);
          if (ec === 'TOKEN_EXPIRED' && cid) {
            throw new ApiError(detail, ec, cid, response.status, payload);
          }
          // 2026-10-07: a 401 asking for the AWS PORTAL password is about a
          // connection's credential, not this session -- the session is
          // fine.  It used to fall through to the session-expiry path below
          // (token cleared, re-login modal), and the query builder's
          // portal-password branch, which reads the structured detail,
          // could never run.
          if (payload?.type === 'portal_password_required') {
            throw new ApiError(detail, ec, cid, response.status, payload);
          }
          // BF-403: REMOVED window.location.reload() — it destroyed all
          // React state including in-flight queries.  Now we dispatch a
          // custom event that AuthContext listens to + flips isAuth=false.
          // The route guard re-renders LoginPage; BQB and any other
          // mounted components keep their state in memory.  After re-auth
          // the user lands back on their current page with state intact.
          //
          // Architectural principle: HTTP errors NEVER reload the page.
          // Long queries (5+ min) + transient backend slowness must be
          // tolerated without nuking the user's typed query / open tabs.
          try {
            sessionStorage.setItem('qs_post_login_redirect',
              window.location.pathname + window.location.search);
          } catch { /* sessionStorage disabled */ }
          try {
            // Always clear the (now-stale) token even on coalesced
            // dispatches -- the next attempt should NOT re-send it.
            localStorage.removeItem('qs_auth');
            sessionStorage.removeItem('qs_auth');
            // Coalesce: only dispatch one qs:auth-expired per cooldown
            // window so 5 concurrent 401s don't fire 5 modals.
            const now = Date.now();
            if (now - _lastAuthExpiredDispatchMs > AUTH_EXPIRED_COOLDOWN_MS) {
              _lastAuthExpiredDispatchMs = now;
              window.dispatchEvent(new CustomEvent('qs:auth-expired', {
                detail: { reason: detail || 'Session expired' },
              }));
            }
          } catch { /* event API may not exist in older browsers */ }
          throw new ApiError(
            detail || 'Authentication required — please log in again',
            ec || 'AUTH_EXPIRED',
            cid,
            response.status,
          );
        }
        if (canRetry && attempt < MAX_RETRIES && RETRY_STATUSES.has(response.status)) {
          await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
          continue;
        }
        const { detail, errorCode: ec, connectionId: cid, payload } = await _parseError(response);
        throw new ApiError(detail, ec, cid, response.status, payload);
      }
      // Successful response (status<400) -- reset the auth-expired
      // cooldown so a FUTURE session expiry still fires the modal.
      _resetAuthExpiredCooldown();
      if (response.status === 204 || response.headers.get('content-length') === '0') {
        return null;
      }
      // Phase 130 hotfix — defend against the stale-deploy case where
      // the SPA HTML fallback (Vite proxy / k8s ingress) returns
      // index.html with a 200 status code for an unknown /api/* path.
      // Without this guard, ``response.json()`` raises the cryptic
      // "Unexpected token '<', '<!DOCTYPE ..." error that masks the
      // real root cause (backend doesn't know this route yet).
      const _ct = (response.headers.get('content-type') || '').toLowerCase();
      if (_ct && !_ct.includes('json') && !_ct.includes('javascript') && !_ct.includes('text/plain')) {
        const _body = await response.text().catch(() => '');
        const _isHtml = /^\s*<(!DOCTYPE|html)/i.test(_body);
        throw new ApiError(
          _isHtml
            ? `Backend returned HTML instead of JSON for ${url} ` +
              `(likely the API pod hasn't loaded this route — restart or redeploy).`
            : `Backend returned non-JSON response (content-type=${_ct || 'unset'}).`,
          'NON_JSON_RESPONSE',
          undefined,
          response.status,
        );
      }
      return response.json();
    } catch (err) {
      lastError = err as Error;
      // 2026-06-03 — also retry on our own AbortController timeout
      // (didTimeout=true).  Previously the retry loop only caught
      // TypeError (network), so an admin endpoint that legitimately
      // takes 60-90s would abort once and never retry, surfacing
      // as the user-reported "signal is aborted without reason".
      const isOurTimeout = didTimeout
        || (err instanceof DOMException && err.name === 'AbortError' && !options.signal);
      const isNetwork = err instanceof TypeError;
      // 2026-06-04 — polling callers opt out via retryOnTimeout=false.
      const allowTimeoutRetry = options.retryOnTimeout !== false;
      const shouldRetry = isNetwork || (isOurTimeout && allowTimeoutRetry);
      if (canRetry && attempt < MAX_RETRIES && shouldRetry) {
        await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt] || 3000));
        continue;
      }
      // Rewrite the opaque AbortError into something actionable.
      if (isOurTimeout) {
        throw new Error(
          `Request to ${url} timed out after ${REQUEST_TIMEOUT_MS}ms.  ` +
          `If this is an admin listing endpoint, pass timeoutMs: 300000 ` +
          `on safeFetch, OR check the backend logs for a sync-call-in-async stall.`
        );
      }
      throw err;
    }
  }
  // Phase 141 honest-fix: previously a SINGLE TypeError ("Failed to fetch")
  // immediately dispatched qs:api-offline which flipped the entire app to
  // a full-screen "Backend API Unavailable" screen — destroying typed SQL,
  // in-flight queries, and open tabs.  That is exactly what a long-running
  // query through a corporate proxy will look like after a brief network
  // blip.  We now keep the signal (so the periodic health check is forced
  // immediately) but the receiver (AuthContext) requires multiple
  // consecutive failures before flipping apiOnline.  The banner replaces
  // the takeover so user context is preserved either way.
  if (lastError instanceof TypeError) {
    window.dispatchEvent(new CustomEvent('qs:api-offline'));
  }
  throw lastError || new ApiError('Request failed after retries');
};

/**
 * Authenticated file download — fetches as blob with auth headers, then triggers
 * browser download via temporary object URL.  Replaces the old window.open()
 * approach which could not carry the Authorization header.
 */
export const openDownload = async (path: string): Promise<void> => {
  const fullUrl = path.startsWith('http') ? path : `${resolveBaseForPath(path)}${path}`;
  const headers: Record<string, string> = {};
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;

  const response = await fetch(fullUrl, { headers });
  if (!response.ok) {
    const { detail, payload } = await _parseError(response);
    throw new ApiError(detail, undefined, undefined, response.status, payload);
  }

  const blob = await response.blob();
  const blobUrl = URL.createObjectURL(blob);

  // Extract filename from Content-Disposition header, or derive from path
  const cd = response.headers.get('Content-Disposition') || '';
  const fnMatch = cd.match(/filename="?([^";\n]+)"?/);
  const filename = fnMatch?.[1] || path.split(/[?#]/)[0].split('/').pop() || 'download';

  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(blobUrl);
};

export const sharedFetch = async (shareToken: string, url: string, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${resolveBaseForPath(url)}${url}`;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Share-Token': shareToken,
    ...(options.headers as Record<string, string>),
  };
  const response = await fetch(fullUrl, { ...options, headers });
  if (!response.ok) {
    const { detail, payload } = await _parseError(response);
    throw new ApiError(detail, undefined, undefined, response.status, payload);
  }
  if (response.status === 204 || response.headers.get('content-length') === '0') return null;
  return response.json();
};

/**
 * Authenticated FormData upload — injects auth + workspace + request-id headers.
 * Does NOT set Content-Type (browser auto-sets multipart/form-data with boundary).
 * Returns parsed JSON response.
 */
export const uploadFetch = async (url: string, formData: FormData, options: RequestInit = {}): Promise<any> => {
  const fullUrl = url.startsWith('http') ? url : `${resolveBaseForPath(url)}${url}`;
  const headers: Record<string, string> = { ...(options.headers as Record<string, string>) };
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;
  headers['X-Request-ID'] = Math.random().toString(36).slice(2, 10);
  const response = await fetch(fullUrl, { method: 'POST', ...options, headers, body: formData });
  if (!response.ok) {
    const { detail, errorCode, connectionId, payload } = await _parseError(response);
    throw new ApiError(detail, errorCode, connectionId, response.status, payload);
  }
  if (response.status === 204 || response.headers.get('content-length') === '0') return null;
  return response.json();
};

/**
 * Raw authenticated fetch — injects auth + workspace + request-id headers,
 * returns the raw Response object. Use for streaming, blobs, or fire-and-forget.
 */
export const rawFetch = async (url: string, options: RequestInit = {}): Promise<Response> => {
  const fullUrl = url.startsWith('http') ? url : `${resolveBaseForPath(url)}${url}`;
  const headers: Record<string, string> = { ...(options.headers as Record<string, string>) };
  const authHeader = getAuthHeader();
  if (authHeader) headers['Authorization'] = authHeader;
  const wsId = localStorage.getItem('qs_workspace_id');
  if (wsId) headers['X-Workspace-ID'] = wsId;
  headers['X-Request-ID'] = Math.random().toString(36).slice(2, 10);
  return fetch(fullUrl, { ...options, headers });
};

// ── Shared types ──────────────────────────────────────────────────────────────

export interface QueryConfig {
  files?: string[];
  selectedTables?: { path: string }[];
  joins?: {
    left_file?: string; right_file?: string; leftTable?: string; rightTable?: string;
    left_on?: string[]; right_on?: string[]; leftColumn?: string; rightColumn?: string;
    how?: string; joinType?: string;
  }[];
  filters?: { column: string; operator: string; value: string | string[] }[];
  selectedColumns?: ({ columnName: string } | string)[];
  orderBy?: { column: string; direction: string }[];
  limit?: number | null;
  offset?: number;
  columns?: string[] | null;
  order_by?: { column: string; direction: string }[] | null;
  // 2026-09-05 — progressive partition loading.  DECLARED HERE FOR THE SAME
  // REASON THE BACKEND DECLARES IT: ``QueryConfigModel`` did not, pydantic
  // dropped it, the save returned 200 having stored nothing, and the whole
  // partitioned-scan lane was unreachable on every published view that could
  // exist.  This file's ``toBackendQueryConfig`` is the client-side twin of
  // that hazard -- its rebuild branch below constructs a NEW object and
  // therefore drops every key it does not name.
  partition_config?: PartitionConfig | null;
}

export const toBackendQueryConfig = (qc: QueryConfig): QueryConfig => {
  if (qc.files) return qc;
  return {
    files: (qc.selectedTables || []).map(t => t.path),
    joins: (qc.joins || []).length > 0
      ? qc.joins!.map(j => ({
          left_file:  j.left_file  || j.leftTable,
          right_file: j.right_file || j.rightTable,
          left_on:    Array.isArray(j.left_on)  ? j.left_on  : [j.leftColumn!],
          right_on:   Array.isArray(j.right_on) ? j.right_on : [j.rightColumn!],
          how:        j.how || j.joinType || 'inner',
        }))
      : null,
    filters: (qc.filters || []).length > 0
      ? qc.filters!.map(f => ({
          column:   f.column,
          operator: f.operator,
          value:    f.operator === 'in' && !Array.isArray(f.value)
            ? (f.value as string).split(',').map(v => v.trim())
            : f.value,
        }))
      : null,
    columns: (qc.selectedColumns || []).length > 0
      ? qc.selectedColumns!.map(c => (typeof c === 'string' ? c : c.columnName))
      : null,
    order_by: (qc.orderBy || []).length > 0
      ? qc.orderBy!.map(o => ({ column: o.column, direction: o.direction }))
      : null,
    limit:  qc.limit  ?? null,
    offset: qc.offset ?? 0,
    // Carried, not rebuilt: the declaration is the author's document and the
    // server stores it verbatim.  Omitted entirely when absent so the key is
    // never written as an empty object, which the readers treat as "no
    // config" but ``extra="forbid"`` would still have to parse.
    ...(qc.partition_config ? { partition_config: qc.partition_config } : {}),
  };
};

// ── Response interfaces ───────────────────────────────────────────────────────

export interface Connection {
  id: number;
  name: string;
  type: string;
  config: Record<string, any>;
  is_active: boolean;
  test_status?: string;
  test_message?: string;
  last_tested_at?: string;
  created_at?: string;
  updated_at?: string;
}

export interface SavedQuery {
  id: number;
  name: string;
  description?: string;
  query_config: Record<string, any>;
  connection_id?: number;
  created_by?: string;
  is_active: boolean;
  is_favorite?: boolean;
  folder?: string | null;
  tags?: string[] | null;
  created_at?: string;
  updated_at?: string;
}

export interface Execution {
  id: number;
  execution_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  query_config?: Record<string, any>;
  connection_id?: number;
  file_id?: string;
  row_count?: number;
  error_message?: string;
  duration_ms?: number;
  created_at?: string;
}

export interface Dataset {
  id: number;
  name: string;
  subject: string;
  description?: string;
  is_published: boolean;
  owner?: string;
  created_at?: string;
  updated_at?: string;
}

export interface BusinessReport {
  id: number;
  name: string;
  description?: string;
  dataset_id: number;
  owner?: string;
  is_published: boolean;
  is_certified?: boolean;
  template_category?: string;
  config: Record<string, any>;
  created_at?: string;
  updated_at?: string;
}

export interface DashboardItem {
  id: number;
  name: string;
  description?: string;
  owner?: string;
  is_shared: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface Widget {
  id: number;
  dashboard_id: number;
  title: string;
  chart_type: string;
  config: Record<string, any>;
  layout?: Record<string, any>;
}

export interface Schedule {
  id: number;
  name: string;
  cron_expression: string;
  query_id?: number;
  report_id?: number;
  is_active: boolean;
  last_run_at?: string;
  next_run_at?: string;
}

export interface Notification {
  id: number;
  type: string;
  message: string;
  is_read: boolean;
  created_at: string;
  metadata?: Record<string, any>;
}
