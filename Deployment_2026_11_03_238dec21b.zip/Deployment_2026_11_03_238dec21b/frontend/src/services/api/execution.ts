/**
 * API — Query Execution, Streaming, Results, Downloads, SQL Connector, Joins
 */
import { safeFetch, sharedFetch, openDownload, rawFetch, _parseError, ApiError, toBackendQueryConfig, type QueryConfig } from './core';
import { safeStringify } from '../../utils/safeStringify';

// Forward reference to the composed api object — set by index.ts
let _api: any = null;
export const _setApiRef = (ref: any) => { _api = ref; };

/**
 * Client-side cap for a REAL query execution (2026-07-31).
 *
 * 50 minutes.  Must stay comfortably ABOVE the backend's
 * ``query_engine.query_timeout_seconds`` (default 1800s / 30 min) so the
 * SERVER's timeout is the authoritative one and the client always receives a
 * real response instead of aborting a healthy in-flight query.  Bump this if
 * that backend setting is ever raised.
 *
 * NOT the safeFetch default (120s) — that is sized for admin listing calls.
 */
export const QUERY_REQUEST_TIMEOUT_MS = 3_000_000;

const execution = {
  // ── Cost Estimate ──────────────────────────────────────────────────────
  estimateQuery: (queryConfig: QueryConfig, connectionId?: number) =>
    safeFetch('/api/execute/estimate', {
      method: 'POST',
      body: safeStringify({
        query_config: toBackendQueryConfig(queryConfig),
        connection_id: connectionId || null,
      }),
    }).catch(() => null),

  // Phase 142 — SQL-first cost estimate (Business Query Builder).
  // Same response shape as estimateQuery: {estimated_rows, estimated_files,
  // pushdown_warning?}.  Sub-3s timeout — the UI just suppresses the chip
  // when this returns null.
  estimateQuerySql: (rawSql: string, connectionId?: number) =>
    safeFetch('/api/execute/estimate-sql', {
      method: 'POST',
      body: safeStringify({
        raw_sql: rawSql,
        connection_id: connectionId || null,
      }),
    }).catch(() => null),

  // BF-417 — pre-execution result-cache visibility.  Returns
  // { cached: false } or { cached: true, age_seconds, age_human,
  //   row_count, hit_count, ttl_remaining, cache_key } so the BQB can
  // render a "⚡ Cached 2h 34m ago — [Use cached] [Run fresh]" banner
  // BEFORE the user clicks Run.  Result-cache only — file-cache hits
  // happen transparently inside the engine.
  getCacheStatus: (payload: {
    raw_sql: string;
    files: any[];
    params?: Record<string, any>;
    connection_id?: number;
  }) =>
    safeFetch('/api/execute/cache-status', {
      method: 'POST',
      // BF-428M: safeStringify defends against polluted `files` (any[])
      // — if a future caller stuffs a DOM/Event ref in there, native
      // JSON.stringify would crash with "Converting circular structure".
      body: safeStringify({
        raw_sql: payload.raw_sql,
        files: payload.files || [],
        params: payload.params || {},
        connection_id: payload.connection_id ?? null,
      }),
    }).catch(() => null),

  // BF-417 — drop the result-cache entry so the next /api/execute
  // re-populates with a fresh result.  Wired to the BQB "Run fresh"
  // button.  Returns { invalidated: true|false }.
  invalidateCache: (payload: {
    raw_sql: string;
    files: any[];
    params?: Record<string, any>;
    connection_id?: number;
  }) =>
    safeFetch('/api/execute/cache-status/invalidate', {
      method: 'POST',
      // BF-428M — same defensive treatment as getCacheStatus above
      body: safeStringify({
        raw_sql: payload.raw_sql,
        files: payload.files || [],
        params: payload.params || {},
        connection_id: payload.connection_id ?? null,
      }),
    }).catch(() => null),

  // ── Execution ───────────────────────────────────────────────────────────
  //
  // 2026-07-31 -- QUERY_REQUEST_TIMEOUT_MS.  The safeFetch DEFAULT is 120s,
  // chosen for ADMIN LISTING endpoints (see core.ts).  A real query is not a
  // listing: partition detection alone can take 140s+ on a heavily-versioned
  // iceberg table, and the backend's own ceiling is
  // ``query_engine.query_timeout_seconds`` = 1800s (30 min).
  //
  // When the client cap is SHORTER than the backend's, three failures cascade
  // from one cause (operator-reported 2026-07-31):
  //   1. fetch aborts    -> "Request to /api/execute timed out after 120000ms"
  //   2. heartbeats stop -> the backend's stale-query auto-cancel (60s no
  //                         heartbeat) KILLS the still-running execution
  //   3. the cancelled run publishes over WebSocket -> "0 rows", while the
  //      editor never renders because its promise already rejected
  //
  // Fix: make the BACKEND's timeout authoritative by giving the client
  // generous headroom above it, so the server always returns a real answer
  // (result or its own clean timeout error) before the client gives up.
  // Same principle as the ETL proc-timeout work: the inner, authoritative
  // limit must fire first.  /api/execute is POST, so safeFetch never retries
  // it -- raising this cannot cause duplicate executions.
  // BF-418 — added optional ``cache_strategy`` so the BQB "Run fresh"
  // button can pass ``"bypass"`` and bypass the result_cache for that
  // specific call.  This closes the gap where invalidateCache could
  // silently fail (network error) → executeQuery would fall through to
  // ``maybe_serve_from_cache`` → user sees the cached result believing
  // it's fresh.  With ``cache_strategy="bypass"`` the engine
  // unconditionally runs the query against the source.
  executeQuery: (payload: {
    query_config?: QueryConfig;
    query_id?: string;
    raw_sql?: string;
    connection_id?: number;
    default_catalog?: string;
    default_schema?: string;
    cache_strategy?: 'auto' | 'bypass' | 'refresh';
    /** H1 (2026-10-07): the screen's correlation id for this run -- see
     *  hooks/useQueuedWait.ts.  Rides every execution_queued event while
     *  this POST waits for a slot, and cancelQueuedExecution ends the wait by it. */
    client_request_id?: string;
  }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    const idempotencyKey = crypto.randomUUID();
    return safeFetch('/api/execute', {
      method: 'POST',
      body: safeStringify({ ...body, idempotency_key: idempotencyKey }),
      timeoutMs: QUERY_REQUEST_TIMEOUT_MS,
    });
  },
  // NOTE: sharedFetch has NO client-side timeout (plain fetch, no
  // AbortController), so the shared/embedded viewer path was never subject to
  // the 120s abort and needs no timeoutMs here.
  executeSharedQuery: (shareToken: string, payload: { query_config?: any; query_id?: number }) =>
    sharedFetch(shareToken, '/api/execute', { method: 'POST', body: safeStringify(payload) }),
  // 2026-08-23 — the anonymous shared/embedded viewer must read status +
  // results with the SAME X-Share-Token it executed with.  The authenticated
  // getExecutionStatus/getExecutionResults returned 401 under real auth (no
  // session), so a shared dashboard executed every widget and then rendered
  // nothing.  These two carry the token through sharedFetch.
  getSharedExecutionStatus: (shareToken: string, executionId: string) =>
    sharedFetch(shareToken, `/api/executions/${executionId}/status`),
  getSharedExecutionResults: (shareToken: string, executionId: string, page = 1, pageSize = 100) => {
    const params = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
    return sharedFetch(shareToken, `/api/executions/${executionId}/results?${params}`);
  },
  previewSql: (payload: { query_config: any; connection_id?: number }) =>
    safeFetch('/api/execute/preview-sql', { method: 'POST', body: safeStringify(payload) }),
  explainQuery: (payload: { raw_sql?: string; query_config?: any; connection_id?: number; analyze?: boolean }) =>
    safeFetch('/api/execute/explain', { method: 'POST', body: safeStringify(payload) }),
  sqlAutoFix: (payload: { raw_sql: string; connection_id?: number }) =>
    safeFetch('/api/sql/auto-fix', { method: 'POST', body: safeStringify(payload) }),
  streamQuery: (payload: { query_config?: any; raw_sql?: string; connection_id?: number; limit?: number }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream', { method: 'POST', body: safeStringify(body) });
  },
  streamPaginate: (payload: {
    query_config?: any; raw_sql?: string; connection_id?: number;
    page?: number; page_size?: number;
    sort_column?: string | null; sort_direction?: string;
    adv_filters?: string;
  }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream/paginate', { method: 'POST', body: safeStringify(body) });
  },
  streamSchema: (payload: {
    query_config?: any; raw_sql?: string; connection_id?: number;
    sample_rows?: number;
  }) => {
    const body = payload.query_config
      ? { ...payload, query_config: toBackendQueryConfig(payload.query_config) }
      : payload;
    return safeFetch('/api/execute/stream/schema', { method: 'POST', body: safeStringify(body) });
  },
  cancelStream: (streamId: string) =>
    safeFetch('/api/execute/stream/cancel', { method: 'POST', body: safeStringify({ stream_id: streamId }) }),

  // ── Executions ──────────────────────────────────────────────────────────
  /**
   * FB-49 (2026-09-20).  Two things were wrong here, and both were
   * invisible from the screen:
   *
   *   1. `limit` defaulted to 50 and nothing downstream knew, so
   *      /executions showed the 50 most recent rows and row 51 was
   *      unreachable -- execution history that ended at 50.  The call now
   *      always asks for the TOTAL and answers `{items, total}`, so a
   *      caller can page and can SAY how many there are.
   *   2. `.catch(() => [])` turned every failure into an empty list.
   *      "Could not read" and "has none" lead to opposite investigations;
   *      the error now propagates and the caller says which it was.
   */
  listExecutions: (
    params: { limit?: number; offset?: number; status?: string; q?: string } | number = {},
  ): Promise<{ items: any[]; total: number }> => {
    const p = typeof params === 'object' ? params : { limit: params };
    const qs = new URLSearchParams();
    qs.append('limit',  String(p.limit  ?? 50));
    qs.append('offset', String(p.offset ?? 0));
    if (p.status) qs.append('status', p.status);
    if (p.q) qs.append('q', p.q);
    qs.append('include_total', 'true');
    return safeFetch(`/api/executions?${qs}`).then((data: any) => (
      // the route keeps its BARE-LIST default for external consumers; the
      // envelope is opt-in.  Tolerate both so one shape reaches the UI.
      Array.isArray(data)
        ? { items: data, total: data.length }
        : { items: data?.items ?? data?.executions ?? [], total: data?.total ?? 0 }
    ));
  },
  getExecution: (executionId: string) => safeFetch(`/api/executions/${executionId}`).catch(() => null),
  getExecutionFileInfo: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/file-info`).catch(() => ({ available: false })),
  cancelExecution: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/cancel`, { method: 'POST' }),
  /** H1 (2026-10-07): end the caller's OWN slot wait by the client_request_id
   *  its execute POST carried -- the only handle a screen has while that POST
   *  is held in the queue (no execution id yet, and no execution row for
   *  /cancel to find).  Answers {cancelled, status: 'cancelled'|'not_waiting'}. */
  cancelQueuedExecution: (clientRequestId: string) =>
    safeFetch('/api/execute/queued/cancel', {
      method: 'POST',
      body: safeStringify({ client_request_id: clientRequestId }),
    }),
  /** 2026-11-01 (query pods): a run waiting for a query pod -- its job row
   *  (status, position, `waiting` = the sentence, `response.execution_id`
   *  once a pod took it, `error`), and cancelling it while it waits. */
  getQueryJob: (jobId: string) => safeFetch(`/api/jobs/${encodeURIComponent(jobId)}`),
  cancelQueryJob: (jobId: string) =>
    safeFetch(`/api/jobs/${encodeURIComponent(jobId)}/cancel`, { method: 'POST' }),
  getExecutionStatus: async (executionId: string) => {
    try {
      return await safeFetch(`/api/executions/${executionId}/status`);
    } catch {
      try {
        const downloads = await (_api?.listDownloads?.('') ?? safeFetch('/api/downloads')) as { execution_id: string; file_id: string }[];
        const match = downloads.find((d: any) => d.execution_id === executionId);
        if (match) return { execution_id: executionId, status: 'completed', file_id: match.file_id };
      } catch {}
      return { execution_id: executionId, status: 'pending' };
    }
  },

  // ── Downloads ───────────────────────────────────────────────────────────
  listDownloads: (status = 'available') =>
    safeFetch(`/api/downloads${status ? '?status=' + status : ''}`).catch(() => []),
  getDownloads: (status = 'available') =>
    safeFetch(`/api/downloads${status ? '?status=' + status : ''}`).catch(() => []),
  downloadFile: (fileId: string) => openDownload(`/api/downloads/${fileId}/download`),
  deleteDownload: (fileId: string) => safeFetch(`/api/downloads/${fileId}`, { method: 'DELETE' }),
  // 2026-08-30 — the retention a user chooses.  The export routes have
  // accepted ?retain_days= all along and nothing ever sent it, so the
  // choice was reachable only by hand-editing a URL.  Owner or admin;
  // the operator maximum is enforced server-side and its 400 names the
  // limit, so the UI does not restate a number it cannot know.
  setDownloadRetention: (fileId: string, retainDays: number) =>
    safeFetch(`/api/downloads/${fileId}/retention`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ retain_days: retainDays }),
    }),

  // ── Results ─────────────────────────────────────────────────────────────
  getExecutionResults: (
    executionId: string, page = 1, pageSize = 100,
    sortColumn: string | null = null, sortDirection = 'asc', filters: object | null = null,
  ) => {
    const params = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
    if (sortColumn) { params.append('sort_column', sortColumn); params.append('sort_direction', sortDirection); }
    if (filters && Object.keys(filters).length) params.append('filters', safeStringify(filters));
    return safeFetch(`/api/executions/${executionId}/results?${params}`);
  },
  exportResults: (executionId: string, format = 'csv') =>
    openDownload(`/api/executions/${executionId}/export?format=${format}`),
  getExecutionStats: (executionId: string) => safeFetch(`/api/executions/${executionId}/stats`),
  releaseExecutionResults: (executionId: string) =>
    safeFetch(`/api/executions/${executionId}/results`, { method: 'DELETE' }).catch(() => {}),
  getExecutionResultsArrow: async (executionId: string, page = 0, pageSize = 10000): Promise<{
    buffer: ArrayBuffer;
    totalRows: number;
    totalColumns: number;
    page: number;
    pageSize: number;
    rowsInPage: number;
  }> => {
    const response = await rawFetch(
      `/api/executions/${executionId}/results/arrow?page=${page}&page_size=${pageSize}`,
      { headers: { Accept: 'application/vnd.apache.arrow.stream' } },
    );
    if (!response.ok) {
      const { detail } = await _parseError(response);
      throw new ApiError(detail);
    }
    const buffer = await response.arrayBuffer();
    return {
      buffer,
      totalRows: parseInt(response.headers.get('X-Total-Rows') || '0', 10),
      totalColumns: parseInt(response.headers.get('X-Total-Columns') || '0', 10),
      page: parseInt(response.headers.get('X-Page') || '0', 10),
      pageSize: parseInt(response.headers.get('X-Page-Size') || '0', 10),
      rowsInPage: parseInt(response.headers.get('X-Rows-In-Page') || '0', 10),
    };
  },

  // ── SQL Queries ─────────────────────────────────────────────────────────
  getSqlConnectorTypes: () =>
    safeFetch('/api/sql/connector-types').catch(() => ({ types: [], fields: {}, display_names: {} })),
  listSqlQueries: (activeOnly = true) =>
    safeFetch(`/api/sql/queries?active_only=${activeOnly}`).catch(() => []),
  createSqlQuery: (data: object) =>
    safeFetch('/api/sql/queries', { method: 'POST', body: safeStringify(data) }),
  getSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`),
  updateSqlQuery: (id: string, data: object) =>
    safeFetch(`/api/sql/queries/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteSqlQuery: (id: string) => safeFetch(`/api/sql/queries/${id}`, { method: 'DELETE' }),
  // H1 (2026-10-07): the POST is what waits for a slot (up to the server's
  // queue_wait_timeout_seconds), so it gets the query budget, not the 120 s
  // listing default that would abort a healthy wait -- as executeQuery does.
  executeSqlQuery: (payload: object) =>
    safeFetch('/api/sql/execute', {
      method: 'POST', body: safeStringify(payload), timeoutMs: QUERY_REQUEST_TIMEOUT_MS,
    }),
  // 2026-11-01 -- "Run on": which table each name in the SQL reads on the
  // chosen source (backend core/editor_run_on.py), or the refusal sentence.
  sqlRunOnTables: (payload: { sql: string; home_connection_id?: number | null;
                              run_on_connection_id: number; table_map?: Record<string, string> }) =>
    safeFetch('/api/sql/run-on/tables', { method: 'POST', body: safeStringify(payload) }),
  listSqlCatalogs: (connectionId: string) => safeFetch(`/api/sql/connections/${connectionId}/catalogs`),
  listSqlSchemas: (connectionId: string, catalog: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/schemas?catalog=${encodeURIComponent(catalog)}`),
  listSqlTables: (connectionId: string, catalog: string, schema: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/tables?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}`),
  listSqlColumns: (connectionId: string, catalog: string, schema: string, table: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/columns?catalog=${encodeURIComponent(catalog)}&schema=${encodeURIComponent(schema)}&table=${encodeURIComponent(table)}`),
  testSqlConnection: (connectionId: string) =>
    safeFetch(`/api/sql/connections/${connectionId}/test`, { method: 'POST' }),

  // ── Join Preview ────────────────────────────────────────────────────────
  joinPreview: (req: { connection_id?: number; left_file: string; right_file: string;
                        left_on: string[]; right_on: string[]; how?: string }) =>
    safeFetch('/api/joins/preview', { method: 'POST', body: safeStringify(req) }),
};

export default execution;
