"""
FastAPI Application for Parquet Query Engine with S3 Support
Enterprise-grade API with WebSocket support and S3 connectivity
"""

import json
import time as _time
import uuid
import logging
import traceback
from pathlib import Path
import asyncio
import os
import sys
import contextvars as _cv

# ── sys.path self-bootstrap ──────────────────────────────────────────────────
# main.py lives in the backend/ root and imports its sibling packages as
# ``from api.* import ...`` / ``from core.* import ...``.  Those only resolve
# when backend/ is on sys.path.  ``python -m querystudio`` arranges that (via
# querystudio/cli.py), but a direct launch (``uvicorn main:app``, an IDE run,
# or any non-backend cwd) does NOT -- and then the app dies at import with
# "No module named api" / "No module named core".  Make main.py self-sufficient
# so it works regardless of how it's launched.
_BACKEND_DIR = str(Path(__file__).resolve().parent)
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)

# 2026-10-17 -- launched as THE server (`exec python -m main`: the api,
# published-api, reports and downloads charts) = envelope encryption, exactly
# as querystudio/cli.py sets it for its server commands; set BEFORE the
# DatabaseManager below binds the data-key store.  A test importing `main`
# keeps the direct key.  (Missing here, the API -- the key owner -- stayed on
# the direct key and every CLI-started component waited for data keys forever.)
if __name__ == "__main__":
    os.environ.setdefault("QS_DATA_KEYS_IN_DB", "1")

# Phase 83D: Request correlation ID context var (propagated through async context)
_request_id_var: _cv.ContextVar[str] = _cv.ContextVar("request_id", default="-")

# Note: faulthandler intentionally NOT enabled.
# DuckDB uses Structured Exception Handlers (SEH) on Windows; faulthandler's
# Vectored Exception Handler intercepts those and causes fatal crashes.
# Python-level crashes are caught by sys.excepthook / threading.excepthook.
# C-level crashes (segfaults) are isolated via subprocess execution (duckdb_subprocess.py).

# ══════════════════════════════════════════════════════════════════════════════
# FIRST: Set up logging + crash handler BEFORE any app imports.
# This ensures every error — including import failures — is captured.
# ══════════════════════════════════════════════════════════════════════════════
def _configure_logging():
    # BF-574: read each field independently so a single missing /
    # null value in config.json doesn't disable the WHOLE log
    # subsystem (the old single try/except silently fell back to
    # ``log_file=""`` → no file logging, which was confusing to
    # debug).  Per-field fallbacks now produce a working logger
    # even on a partially-broken config.
    def _safe(get_fn, default):
        try:
            v = get_fn()
            return v if v is not None and v != "" else default
        except Exception:
            return default

    try:
        from core.config import server as _srv
    except Exception:
        _srv = None  # type: ignore[assignment]

    use_json       = _safe(lambda: _srv.log_format, "json") == "json" if _srv else True
    _level_name    = _safe(lambda: _srv.log_level, "info") if _srv else "info"
    log_level      = getattr(logging, _level_name.upper(), logging.INFO)
    log_file       = (_safe(lambda: _srv.log_file, "") if _srv else "").strip()
    retention_days = _safe(lambda: _srv.log_retention_days, 14) if _srv else 14
    # BF-574: default 25 MB so the active file stays openable in
    # standard editors.  Was 100 MB which most JSON tools choke on.
    log_max_mb     = _safe(lambda: _srv.log_max_mb, 25) if _srv else 25
    log_compress   = _safe(lambda: _srv.log_compress, True) if _srv else True
    log_async      = bool(_safe(lambda: _srv.log_async, True)) if _srv else True

    # Build the formatter
    if use_json:
        try:
            try:
                # python-json-logger >= 3.x moved the class to
                # pythonjsonlogger.json; the old pythonjsonlogger.jsonlogger
                # alias still imports but emits a DeprecationWarning.
                from pythonjsonlogger.json import JsonFormatter as _JsonFormatter
            except ImportError:  # older python-json-logger (< 3.1)
                from pythonjsonlogger.jsonlogger import JsonFormatter as _JsonFormatter
            formatter = _JsonFormatter(
                fmt="%(asctime)s %(name)s %(levelname)s %(message)s %(pathname)s %(lineno)d %(funcName)s",
                rename_fields={
                    "asctime": "timestamp", "levelname": "level", "name": "logger",
                    "pathname": "file", "lineno": "line", "funcName": "func",
                },
            )
        except ImportError:
            use_json  = False
            formatter = None
    if not use_json or formatter is None:
        _text_fmt = ('%(asctime)s [%(request_id)s] %(name)s %(levelname)s '
                     '%(message)s [%(pathname)s:%(lineno)d]')
        # ColorFormatter tints ERROR red / WARNING yellow for an interactive
        # stdout, and leaves gate lines (already tinted by verdict) alone.
        # It self-disables when stdout is not a TTY, so log FILES and log
        # shippers never receive escape codes.  JSON mode never reaches
        # here — colour inside a JSON string field would corrupt parsers.
        try:
            from core.log_style import ColorFormatter as _CF
            formatter = _CF(_text_fmt)
        except Exception as _cf_exc:               # styling is never critical
            print(f"[logging] colour formatter unavailable ({_cf_exc}); "
                  f"using plain text", flush=True)
            formatter = logging.Formatter(_text_fmt)

    handlers: list = [logging.StreamHandler()]  # always log to stdout

    # BF-406 — Optional combined size+time rotating handler with gzip.
    # Rotates daily at midnight AND when active file exceeds log_max_mb.
    # Rotated files are gzipped (saves ~10× disk on JSON/text logs).
    # Old files (rotated > retention_days ago) are auto-deleted.
    # Set server.log_file in config.json to enable, e.g. "logs/querystudio.log".
    if log_file:
        try:
            from core.log_rotation import SizeAndTimeRotatingFileHandler
            import os as _os
            _log_abs = _os.path.abspath(log_file)
            _os.makedirs(_os.path.dirname(_log_abs), exist_ok=True)
            fh = SizeAndTimeRotatingFileHandler(
                _log_abs,
                when="midnight",
                interval=1,
                backupCount=retention_days,
                encoding="utf-8",
                utc=False,
                max_bytes=int(log_max_mb) * 1024 * 1024 if log_max_mb else 0,
                compress=bool(log_compress),
            )
            fh.setFormatter(formatter)
            handlers.append(fh)
            print(
                f"[logging] File logging enabled: {_log_abs} "
                f"(daily + {log_max_mb} MB cap; "
                f"{retention_days}-day retention; "
                f"gzip={'on' if log_compress else 'off'})",
                flush=True,
            )
        except Exception as _fe:
            # Don't crash startup if file logging fails — stdout is still active
            print(f"[logging] WARNING: could not set up file handler for '{log_file}': {_fe}",
                  flush=True)

    # Phase 83D: Request correlation ID log filter
    class _RequestIdFilter(logging.Filter):
        def filter(self, record):
            # 2026-10-07: stamped where the record is MADE (the request's
            # context); a listener thread re-running this must not replace
            # it with its own context's "-".
            if getattr(record, "request_id", None) is not None:
                return True
            try:
                record.request_id = _request_id_var.get("-")
            except Exception:
                record.request_id = "-"
            return True

    for h in handlers:
        h.setFormatter(formatter)
        h.addFilter(_RequestIdFilter())

    if log_async:
        # 2026-10-07: the handlers above run on ONE listener thread; the
        # root logger only enqueues (see server.log_async).  The queue is
        # bounded: when it is full (the sink cannot keep up) a record is
        # written INLINE by the caller, as before this change -- never
        # dropped, never queued without bound.
        import atexit as _atexit
        import queue as _queue
        import logging.handlers as _lh

        _q: "_queue.Queue" = _queue.Queue(maxsize=100_000)
        _inline_handlers = list(handlers)

        class _LoopSafeQueueHandler(_lh.QueueHandler):
            def prepare(self, record):
                # Resolve %-args NOW (the objects may change before the
                # listener formats); keep exc_info / stack_info for the real
                # formatter, which runs on the listener thread.
                try:
                    record.msg = record.getMessage()
                    record.args = None
                except Exception:
                    pass
                return record

            def enqueue(self, record):
                try:
                    self.queue.put_nowait(record)
                except _queue.Full:
                    for _h in _inline_handlers:
                        if record.levelno >= _h.level:
                            _h.handle(record)

        _qh = _LoopSafeQueueHandler(_q)
        _qh.addFilter(_RequestIdFilter())
        _prev = getattr(logging, "_qs_log_listener", None)
        if _prev is not None:
            try:
                _prev.stop()
            except Exception:
                pass
        _listener = _lh.QueueListener(_q, *handlers, respect_handler_level=True)
        _listener.start()
        logging._qs_log_listener = _listener      # type: ignore[attr-defined]
        _atexit.register(_listener.stop)           # flush what is queued on exit
        logging.root.handlers = [_qh]
    else:
        logging.root.handlers = handlers
    logging.root.setLevel(log_level)

_configure_logging()
logger = logging.getLogger(__name__)

# Process start time — reported in shutdown/restart diagnostics so operators
# can see how long the pod ran before a restart (see [SHUTDOWN-REASON] below).
_PROCESS_START_TS = _time.time()

# Global unhandled exception hook — log with full traceback before exit
def _global_exception_hook(exc_type, exc_value, exc_tb):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return
    logger.critical("Unhandled exception — backend crash", exc_info=(exc_type, exc_value, exc_tb))
    # Also print to stderr as fallback in case logger is broken
    traceback.print_exception(exc_type, exc_value, exc_tb, file=sys.stderr)

sys.excepthook = _global_exception_hook

# Thread exception hook — catches unhandled exceptions in thread-pool threads
def _thread_exception_hook(args):
    logger.critical("Unhandled exception in thread '%s'", args.thread.name if args.thread else "?", exc_info=(args.exc_type, args.exc_value, args.exc_traceback))
    traceback.print_exception(args.exc_type, args.exc_value, args.exc_traceback, file=sys.stderr)

import threading  # noqa: E402
threading.excepthook = _thread_exception_hook

# Unraisable exception hook — catches errors Python can't propagate (GC, __del__, etc.)
def _unraisable_hook(unraisable):
    logger.critical("Unraisable exception in %s: %s", unraisable.object, unraisable.exc_value,
                    exc_info=(type(unraisable.exc_value), unraisable.exc_value, unraisable.exc_value.__traceback__) if unraisable.exc_value else True)

sys.unraisablehook = _unraisable_hook

# ══════════════════════════════════════════════════════════════════════════════
# Now safe to import app modules — any error will be logged with full traceback
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
# Startup with step-by-step tracing — print() always works, even if logging is broken
# ══════════════════════════════════════════════════════════════════════════════
def _deploy_env_name() -> str:
    """Environment name for Netcool Identifiers (§12.2).

    Delegates to ``core.config.deploy_environment`` — THE resolver.  This
    body was a hand-copy of the same precedence chain (one of four), and a
    decision made four times is free to give four answers.  Still returns
    "" when nothing declares one; the daemons refuse loudly on "" rather
    than invent a name that keys every alert under a Node nobody routes.
    """
    try:
        from core.config import deploy_environment as _de
        return _de()
    except Exception:                              # noqa: BLE001
        return ""


def _startup_step(label):
    """Print + log a startup step — print goes to stdout even if logger is broken."""
    print(f"[STARTUP] {label}", flush=True)
    logger.info("[STARTUP] %s", label)

try:
    _startup_step("1/12 Importing FastAPI + stdlib...")
    from fastapi import FastAPI, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect, File, UploadFile, Request, Depends, Header, Body, Query
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.middleware.gzip import GZipMiddleware
    from fastapi.responses import FileResponse
    from pydantic import BaseModel, Field
    from typing import List, Dict, Any, Optional, Tuple, Union
    from datetime import datetime, timedelta, timezone
    from concurrent.futures import ThreadPoolExecutor
    from dotenv import load_dotenv

    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    _startup_step("2/12 Importing API routers...")
    from api.data_grid_api import router as data_grid_router, set_db_manager as set_grid_db, set_ws_manager as set_grid_ws, set_paths as set_grid_paths
    from api.sql_query_api import router as sql_router, set_sql_dependencies
    from api.sql_tools_api import router as sql_tools_router  # Phase 139 honest-fix
    # FB-60 (2026-09-26): api.reports_api holds the raw_sql ENGINES only; the
    # parametric entity routes are gone and there is no router to mount.
    from api.reports_api import set_report_dependencies
    from api.schedules_api import router as schedules_router, set_schedule_dependencies, set_schedules_auth
    from api.dashboards_api import router as dashboards_router, set_dashboard_dependencies
    # Phase 23: Enterprise reporting (additive — no existing code modified)
    from api.catalog_api import router as catalog_router, set_catalog_dependencies
    from api.portal_api import router as portal_router, set_portal_dependencies
    from api.enterprise_reports_api import router as enterprise_router, set_enterprise_dependencies
    from api.pdf_export_api import router as pdf_router, set_pdf_dependencies
    from api.burst_api import router as burst_router, set_burst_dependencies
    from api.connection_profiles_api import router as profiles_router, set_profile_dependencies
    # FB-60 / F7 (2026-09-26): the connector matrix moved off the legacy
    # parametric router onto finance reports; the old paths 308 for one release.
    from api.report_connectors_api import router as report_connectors_router
    from api.workspaces_api import router as workspaces_router, set_workspace_dependencies
    from api.lineage_api import router as lineage_router, set_lineage_dependencies
    # Report readership analytics (2026-08-17).  No set_*_dependencies call:
    # the module resolves the DB through api.deps.require_db and carries its
    # own router-level auth dependency.
    from api.report_usage_api import router as report_usage_router
    # Phase 29: Domain routers extracted from main.py
    from api.auth_api import router as auth_router, set_auth_dependencies
    from api.notifications_api import router as notifications_router, set_notification_dependencies
    from api.system_api import router as system_router, set_system_dependencies
    from api.admin_api import router as admin_router, set_admin_dependencies
    # BF-428G: pluggable S3 readers admin API
    from api.s3_readers_api import router as s3_readers_router
    # Phase 146-B: logical-table admin API
    from api.logical_tables_api import (
        router as logical_tables_router,
        _pv_router as logical_tables_pv_router,  # Phase 146-C
    )
    from api.connections_api import router as connections_router, set_connection_dependencies
    from api.queries_api import router as queries_router, set_query_dependencies
    # The Download Centre surface (2026-08-30).  Its nine routes used to be
    # scattered across queries/data_grid/admin; they are defined once in
    # downloads_api now so the surface can be mounted on its own pod.  This
    # import must follow the three host modules — it binds their handlers.
    from api.downloads_api import router as downloads_router
    from api.materialized_views_api import router as mv_router, set_mv_dependencies
    from api.local_tables_api import router as local_tables_router, set_local_table_dependencies
    import api.materialized_views_api as _mv_api_module
    # Phase 42: Arrow IPC response format
    from api.arrow_api import router as arrow_router, set_arrow_dependencies
    # Phases 46/47/48: Auto-suggest, query analysis, NL-to-SQL
    from api.suggest_api import router as suggest_router, set_suggest_dependencies
    # Phase 53: Semantic Layer — Business Datasets
    from api.datasets_api import router as datasets_router, set_datasets_dependencies
    # Phase 54: Federation Engine
    from api.datasets_api import set_federation_dependencies
    # Phase 56: Business Report Builder
    from api.business_reports_api import router as business_reports_router, set_business_reports_dependencies
    # Phase 60: Subscription/Delivery
    from api.subscription_api import router as subscription_router, set_subscription_dependencies
    # A3: Execute stream router (extracted from main.py)
    from api.execute_stream_api import router as stream_router, set_stream_dependencies
    from api.jobs_api import router as jobs_router
    # A3: Execute API router (extracted from main.py)
    from api.execute_api import router as execute_router, set_execute_dependencies
    # Phase 75: Published Views API (external data access)
    from api.published_views_api import router as published_views_router, set_published_views_dependencies
    from api.feed_api import router as feed_router, set_feed_dependencies
    # Step 8 (BRD §15): change control — export / deploy / drift
    from api.governance_api import router as governance_router, set_governance_dependencies
    # 2026-10-30 (owner): every config row is switched off, never erased -- the one way back
    from api.config_active_api import router as config_active_router
    # BRD §13.1 — the operator run surface (read-only; every control has
    # its own guarded endpoint, and a screen that also acted would be a
    # second place to get them wrong).
    from api.run_surface_api import (
        router as run_surface_router,
        set_run_surface_dependencies,
    )
    # 2026-09-28 -- business-date readiness on a report and its SLO (the
    # feed gate and the feed clocks, read for a report; no state of its own
    # beyond the report-keyed tables).
    from api.report_readiness_api import router as report_readiness_router
    # BRD §7/§13 (2026-09-02) — operator dependency controls: the SKIP
    # assertion producers the gate always knew how to read, the reverse
    # index (dependency -> blocked feeds), and the per-run step view.
    from api.feed_ops_api import (
        router as feed_ops_router,
        set_feed_ops_dependencies,
    )
    # 2026-09-28 -- the date-token vocabulary and preview (business-calendar
    # tokens in report parameters, saved-query and dashboard filters).
    from api.date_tokens_api import (
        router as date_tokens_router,
        set_date_tokens_dependencies,
    )
    # 2026-09-02 — operational feed groups: the managed grouping entity
    # the dashboard groups by and operators act on (group rerun / group
    # dependency skip).  Distinct from owner_group_id (ACL).
    from api.feed_group_api import (
        router as feed_group_router,
        set_feed_group_dependencies,
    )
    # 2026-09-27 -- the feed definition VERSION HISTORY (list / one / diff /
    # restore through the ONE update) and the daily CLOSE-OUT DIGEST's admin
    # preview + status.
    from api.feed_versions_api import router as feed_versions_router
    from api.feed_close_out_api import (
        router as feed_close_out_router,
        set_feed_close_out_dependencies,
    )
    # 2026-10-10 -- feed TEMPLATES: one parameterised definition + a matrix
    # -> N feeds through THE authoring routes, idempotently (the owner's
    # ~4,000 monthly (SYSTEM_ENTITY, EventCode) feeds).
    from api.feed_template_api import (
        router as feed_template_router,
        set_feed_template_dependencies,
    )
    # 2026-09-28 -- My Feeds: delivery receipts + self-subscription for
    # feed CONSUMERS (any role, the viewer included; 404 on a feed the
    # caller is not declared on).
    from api.feed_consumer_api import (
        router as feed_consumer_router,
        set_feed_consumer_dependencies,
    )
    # 2026-10-12 -- variance holds: files the row-count check HELD for the
    # configured release group (core/feed/variance_hold.py).
    from api.feed_variance_hold_api import (
        router as feed_variance_hold_router,
        set_feed_variance_hold_dependencies,
    )
    # 2026-10-12 -- the OTG-style dashboard: tasks grouped by Feed Groups.
    from api.feed_dashboard_api import router as feed_dashboard_router
    # 2026-09-05 — the feed STEP MODEL: the step catalogue and its
    # database plugin path, the flow mapping, the plan a feed WILL
    # run, the per-step timeline of a run, and the per-step re-run.
    from api.feed_steps_api import (
        router as feed_steps_router,
        set_feed_steps_dependencies,
    )
    # 2026-09-24 -- SFTP destination authoring: fetch a host key to pin,
    # test a destination through the delivery code path.
    from api.feed_sftp_api import router as feed_sftp_router
    # BRD §2.1 (2026-09-02) — schedule preview: what an unsaved schedule
    # declaration MEANS in concrete dates.  Computed server-side because
    # business days depend on DB holiday rows + config
    # feed_generation.default_weekend_days; a browser-side preview would
    # diverge from due_on and a wrong preview is worse than none.
    from api.feed_schedule_preview_api import (
        router as feed_schedule_preview_router,
        set_feed_schedule_preview_dependencies,
    )
    # BRD §12/§13.1 — read-only status for the feed daemons (Kafka
    # arrival consumer, SLA watcher, Netcool sender).  A daemon whose
    # state nobody can see is how "registered, reported success and did
    # nothing" survives for months.
    from api.feed_daemons_api import (
        router as feed_daemons_router,
        set_feed_daemons_dependencies,
    )
    # 2026-09-27 -- the effective-posture card: every default-off gate and
    # daemon with configured / effective / where / why on ONE admin screen.
    from api.admin_posture_api import (
        router as admin_posture_router,
        set_posture_dependencies,
    )
    # 2026-10-17 -- component health, one place: every pod, daemon and
    # dependency as ONE state with a reason, controls as audited intents.
    from api.component_health_api import (
        router as component_health_router,
        set_component_health_dependencies,
    )
    # Phase 133: Reconciliation API (source-vs-destination break detection)
    from api.reconciliation_api import (
        router as reconciliation_router,
        set_reconciliation_dependencies,
    )
    # Phase 127: ETL Pipeline API
    from api.etl_pipeline_api import router as etl_pipeline_router, set_etl_pipeline_dependencies
    # Phase 93: Federation Views API
    from api.federation_views_api import router as federation_views_router, set_federation_views_dependencies
    # Phase 88: Metadata Catalog API
    from api.metadata_catalog_api import router as metadata_catalog_router, set_metadata_catalog_dependencies
    # Phase 99: Data Quality Monitoring API
    from api.data_quality_api import router as data_quality_router, set_dq_dependencies
    # Phase 100: User Preferences API (onboarding / guided tours)
    from api.user_preferences_api import router as user_prefs_router, set_user_preferences_dependencies
    # Phase 114-J: Report Comments & Change History API
    from api.report_comments_api import router as report_comments_router
    # 2026-09-28: commentary + sign-off on a report INSTANCE
    from api.report_signoff_api import router as report_signoff_router
    # 2026-10-30: canvas ACTIONS ("Download detail" through a Published API)
    from api.canvas_actions_api import router as canvas_actions_router
    # 2026-10-30: the report Diagnostics panel (how each parameter was applied, per run)
    from api.report_diagnostics_api import router as report_diagnostics_router
    # 2026-11-01: the report run panel's "Data version" listing (its Iceberg tables per side)
    from api.report_data_versions_api import router as report_data_versions_router
    # 2026-11-01: the report band's previous / next business day (the report's calendar)
    from api.report_business_day_api import router as report_business_day_router
    # 2026-11-01: report themes -- the LOOK of a report is configuration (core/reports/themes.py)
    from api.report_themes_api import router as report_themes_router, set_report_themes_dependencies
    # 2026-11-02: report templates -- a report started from a design (core/reports/templates.py)
    from api.report_templates_api import router as report_templates_router, set_report_templates_dependencies
    # 2026-11-01: report parameter templates (core/reports/param_contract.py)
    from api.report_parameter_templates_api import (router as report_parameter_templates_router,
                                                    set_report_parameter_templates_dependencies)
    # Phase 120: Self-Healing Agents API
    from api.agents_api import router as agents_router, set_agents_dependencies
    # Phase 122C: SQL File Management
    from api.sql_files_api import router as sql_files_router, set_sql_files_dependencies
    # Phase 141 — row & column security (Lake Formation equivalent)
    from api.row_security_api import router as row_security_router, set_row_security_dependencies
    # 2026-10-24 -- data entitlement by column (dimensions, values, uploads, /api/me/entitlements)
    from api.entitlement_api import (router as entitlement_router, me_router as entitlement_me_router,
                                     set_entitlement_dependencies)
    # 2026-10-31 -- tool entitlement: GET /api/me/capabilities (core/tool_entitlement)
    from api.tool_entitlement_api import router as tool_entitlement_me_router
    # 2026-10-24 -- named value lists synced into our database (core/value_lists.py)
    from api.value_lists_api import router as value_lists_router, set_value_lists_dependencies
    # Phase 142 — server-side draft persistence (kills localStorage bandages)
    from api.user_drafts_api import router as user_drafts_router, set_user_drafts_dependencies
    # Phase 132 — Generic DataFlow Engine (NEW capability; does NOT touch
    # feed_gen / reports / BQB / CQB / API)
    from api.dataflow_api import router as dataflow_router, set_workflow_dependencies
    # 2026-09-10 — Clockwork authoring plane (jobs, run history, alerts).
    # QueryStudio authors and observes; it never executes a job.
    from api.clockwork_api import router as clockwork_router, set_clockwork_dependencies

    # Phase 22F: GraphQL API (optional — requires strawberry-graphql)
    try:
        from api.graphql_api import get_graphql_router, set_graphql_dependencies, set_pv_execute_callback, set_pv_enterprise_deps
        _graphql_available = True
    except ImportError:
        _graphql_available = False

    load_dotenv()

    _startup_step("3/12 Importing parquet_engine_v2...")
    from core.parquet_engine_v2 import ParquetQueryEngine, QueryConfig, JoinConfig, FileReference, StorageType, AggregationConfig

    _startup_step("4/12 Importing s3_storage...")
    from core.s3_storage import S3Config, build_s3_config, TokenExpiredError

    _startup_step("5/12 Importing database...")
    from core.database import DatabaseManager

    _startup_step("6/12 Importing websocket + connection manager...")
    from core.websocket_manager import WebSocketManager
    from core.connection_manager import ConnectionManager as ConnManager, _normalize_path
    from core.connectors import get_connector, SQL_CONNECTOR_TYPES

    _startup_step("7/12 Loading config...")
    from core.config import paths as _paths, server as _server_cfg, query_engine as _qe_cfg, s3 as _s3_cfg, cors as _cors_cfg, database as _db_cfg, auth as _auth_cfg, limits as _limits_cfg, features as _features_cfg, materialized_views as _mv_cfg, local_tables as _lt_cfg

    _startup_step("8/12 Creating data directories...")
    _paths.data_dir.mkdir(parents=True, exist_ok=True)
    _paths.parquet_dir.mkdir(parents=True, exist_ok=True)
    _paths.downloads_dir.mkdir(parents=True, exist_ok=True)
    _paths.upload_dir.mkdir(parents=True, exist_ok=True)
    _paths.duckdb_temp_dir.mkdir(parents=True, exist_ok=True)
    _paths.download_temp_dir.mkdir(parents=True, exist_ok=True)
    Path(_mv_cfg.storage_dir).mkdir(parents=True, exist_ok=True)
    Path(_lt_cfg.storage_dir).mkdir(parents=True, exist_ok=True)

    # DuckDB temp paths from config → inherited by subprocesses via env vars
    os.environ["DUCKDB_TEMP_DIR"] = str(_paths.duckdb_temp_dir)
    os.environ["DUCKDB_EXTENSION_DIR"] = str(_paths.duckdb_extension_dir)
    os.environ["QS_DOWNLOAD_TEMP_DIR"] = str(_paths.download_temp_dir)
    logger.info("DuckDB temp dirs: spill=%s, extensions=%s, downloads=%s",
                _paths.duckdb_temp_dir, _paths.duckdb_extension_dir, _paths.download_temp_dir)

    # S3 download settings from config → env vars for subprocess inheritance
    os.environ["QS_S3_PARALLEL_WORKERS"] = str(_s3_cfg.parallel_download_workers)
    os.environ["QS_S3_DOWNLOAD_RETRIES"] = str(_s3_cfg.download_retries)
    os.environ["QS_S3_DOWNLOAD_TIMEOUT"] = str(_s3_cfg.download_timeout_seconds)
    os.environ["QS_DOWNLOAD_MIN_FREE_GB"] = str(_s3_cfg.min_free_disk_gb)
    os.environ["QS_PREDOWNLOAD_MAX_GB"] = str(_s3_cfg.predownload_max_disk_gb)

    # BF-416 — emit actionable startup warnings when pre-download config
    # looks misconfigured (low workers + proxy active, /tmp fallback for
    # download_temp_dir, unbounded cache).  Operators see these in pod logs
    # immediately instead of after the first slow / failed query.
    try:
        from core.s3_predownload import warn_if_misconfigured as _pd_warn
        _pd_warn()
    except Exception as _pd_warn_exc:
        logger.debug("[s3-predownload] startup warning check skipped: %s", _pd_warn_exc)

    # BF-424 — cluster-wide orphan temp_dir janitor.  Each pod's
    # ``_global_temp_dirs`` is in-process only.  When a pod is OOMKilled
    # mid-download, atexit doesn't fire on SIGKILL → the temp_dir on
    # shared NFS becomes an orphan that NO other pod's atexit will EVER
    # touch.  Across weeks of cluster activity, NFS fills with thousands
    # of orphan dirs.  Run this at startup so each new pod cleans
    # cluster-wide orphans (>24h old).  Cheap (single os.listdir +
    # mtime check), idempotent across pods (rmtree(..., ignore_errors)
    # is safe under racing janitors).
    try:
        from core.s3_predownload import cleanup_orphan_temp_dirs as _orphan_clean
        _orphan_result = _orphan_clean(max_age_hours=24.0)
        if _orphan_result.get("removed", 0) > 0:
            logger.info(
                "[s3-predownload] startup janitor cleaned %d orphan temp dir(s) "
                "(scanned=%d errors=%d)",
                _orphan_result["removed"],
                _orphan_result.get("scanned", 0),
                _orphan_result.get("errors", 0),
            )
    except Exception as _orphan_exc:
        logger.debug(
            "[s3-predownload] orphan janitor skipped (non-fatal): %s",
            _orphan_exc,
        )

    _startup_step("9/12 Creating FastAPI app...")
    _DATA_DIR = _paths.data_dir
    _DB_URL   = _db_cfg.db_url

    _startup_step("10/12 Importing slowapi (rate limiter)...")
    from slowapi import Limiter, _rate_limit_exceeded_handler
    from slowapi.util import get_remote_address
    from slowapi.errors import RateLimitExceeded

    _startup_step("11/12 Importing prometheus_client...")
    from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST

    _startup_step("12/12 All imports OK")

except Exception:
    print("[STARTUP] FATAL ERROR during startup:", flush=True)
    traceback.print_exc()
    traceback.print_exc(file=sys.stderr)
    logger.critical("FATAL: Startup failed", exc_info=True)
    sys.exit(1)

import re as _re  # noqa: E402
import atexit as _atexit  # noqa: E402

# ── Arrow S3 lifecycle ────────────────────────────────────────────────────────
# PyArrow's C++ layer auto-initializes S3 when DuckDB loads httpfs or any Arrow
# S3 op runs.  If finalize_s3() isn't called (or is called too early / twice),
# the process prints "arrow::fs::FinalizeS3 was not called" on exit.
# Fix: explicitly initialize at startup (take ownership) and finalize exactly
# once via atexit (runs AFTER all other cleanup — DuckDB connections, etc.).
_s3_finalized = False

def _finalize_arrow_s3():
    global _s3_finalized
    if _s3_finalized:
        return
    _s3_finalized = True
    try:
        import pyarrow.fs as _pa_fs
        _pa_fs.finalize_s3()
    except Exception:
        pass

# Register S3 finalize FIRST — atexit runs in LIFO order, so first-registered
# runs LAST, ensuring it's the very last thing before process exit.
_atexit.register(_finalize_arrow_s3)

# Eagerly initialize Arrow S3 so we own the lifecycle
try:
    import pyarrow.fs as _pa_fs
    _pa_fs.initialize_s3()
except Exception:
    pass

# Register atexit handler — catches silent process exits (e.g. DLL load
# failure, C-level crash).
def _atexit_handler():
    # Write the exit marker DIRECTLY to the underlying stderr fd, bypassing
    # stdlib logging.  During pytest teardown the captured-stream wrappers
    # are already closed and stdlib logging's handler-error path produces
    # an "I/O operation on closed file" stack trace even when the
    # logger.warning() call is wrapped in try/except (the logging
    # framework catches handler exceptions itself and reprints them).
    # Skipping the logger here keeps the exit marker visible in normal
    # production exits (os.write hits the real fd 2) without polluting
    # test output.
    try:
        os.write(2, b"[ATEXIT] Backend process exiting\n")
    except (OSError, ValueError):
        pass
    # Ensure thread pools don't block process exit
    try:
        query_executor.shutdown(wait=False, cancel_futures=True)
    except Exception:
        pass
    try:
        _streaming_executor.shutdown(wait=False, cancel_futures=True)
    except Exception:
        pass
_atexit.register(_atexit_handler)

# ── API versioning (22E) ──────────────────────────────────────────────────────
API_VERSION = "2.0.0"         # Semantic version exposed via header + endpoint
API_MAJOR   = "v2"            # URL prefix used in header (X-API-Version: v2)

# Initialize FastAPI app
# 2026-08-20 — startup/shutdown run through an ORDERED HOOK REGISTRY
# instead of the deprecated @app.on_event.
#
# This had to be done in ONE change, not handler by handler: once
# ``lifespan=`` is set, Starlette builds its lifespan from that and
# NEVER reads the on_startup list, so any handler left on
# @app.on_event is SILENTLY SKIPPED — no error, no warning.  Verified
# by execution.  A partial migration here would quietly drop the
# pod-role-gated daemon registration or the loop watchdog and still
# boot looking healthy.
#
# Hook ORDER is registration order, exactly as on_event behaved, and
# is now assertable (see tests/test_lifespan_hooks_*).
from core.lifespan_hooks import LifespanHooks
from core import lifespan_threads as _lifespan_threads
_hooks = LifespanHooks("main")
#: The brain-freshness snapshot listener the CURRENT lifespan registered
#: (replaced, never accumulated, by the next one -- see its registration).
_brain_freshness_snapshot_listener = None

app = FastAPI(
    lifespan=_hooks.lifespan,
    title="QueryStudio API",
    description="Enterprise-grade analytics platform — S3, Iceberg, Snowflake, Trino, Databricks",
    version=API_VERSION,
    # BF-397 (revised) — Swagger moved off /docs so the HTML docs portal
    # (frontend/public/docs/, built into static/docs/) can own the natural URL.
    docs_url="/api-docs",
    redoc_url="/api-redoc",
    openapi_tags=[
        {"name": "auth",           "description": "Authentication — login, logout, session, OIDC/SAML"},
        {"name": "queries",        "description": "Saved queries, SQL editor, file browser, executions"},
        {"name": "connections",    "description": "Data source connections (S3, Snowflake, Trino, Databricks, Oracle, local)"},
        {"name": "reports",        "description": "Report builder — create, schedule, and share reports"},
        {"name": "dashboards",     "description": "Dashboard builder — compose multi-report dashboards"},
        {"name": "schedules",      "description": "Scheduled query / report execution"},
        {"name": "admin",          "description": "Admin — users, storage, audit log, compliance, cache"},
        {"name": "system",         "description": "Health, metrics, version"},
        {"name": "materialized-views", "description": "Materialized views — cached S3 data in local DuckDB"},
        {"name": "local-tables",   "description": "Local upload tables and table operations"},
        {"name": "lineage",        "description": "Data lineage graph"},
        {"name": "workspaces",     "description": "Workspace isolation (multi-tenant namespacing)"},
        {"name": "notifications",  "description": "In-app notification history"},
        {"name": "embed",          "description": "Embedded report tokens and rendering"},
        {"name": "graphql",        "description": "GraphQL API — Strawberry schema (optional)"},
        {"name": "published-views", "description": "Published Views API — external data access via API keys"},
    ],
)

# GZip compression (~70% payload reduction for JSON responses).
# compresslevel=1 (not the default 9): on a single-worker event loop, gzip
# runs ON the loop thread, and level 9 costs 0.2-1.5s of loop CPU per large
# (5000-row) result page — enough to stall health probes under concurrent
# grid load.  Level 1 is ~5-10x cheaper CPU for ~10-15% larger bodies, still
# valid gzip.  See backend/docs/event_loop_blocking_audit.md (P0-B).
app.add_middleware(GZipMiddleware, minimum_size=1024, compresslevel=1)

# 2026-10-17 -- the published-API call record's BACKSTOP
# (core/published_api/calls.py): a 4xx / 5xx on a published-API path that no
# route recorded (a 429 raised before the view is read, a bad key, a retired
# API, a token that expired) becomes a refusal row with the consumer the auth
# dependency stashed and the reason the raise site named in X-QS-Refused.
# Pure ASGI; a recorded request and every other path pass untouched.
from core.published_api.calls import CallRecordMiddleware as _CallRecordMiddleware  # noqa: E402
app.add_middleware(_CallRecordMiddleware)

# Back-compat alias: some run scripts / Dockerfile CMDs / IDE launch
# configs use ``uvicorn main:api`` (historical / typo).  The canonical
# attribute name is ``app`` (set above + referenced throughout this file),
# but exposing ``api`` as a same-object alias means BOTH invocation
# patterns work — operators who copy-paste ``uvicorn main:api`` from
# an older snippet don't hit "attribute api not found in module main".
# This is an additive alias only; nothing reads it inside this file.
api = app

# HTTPS redirect — must be added BEFORE CORS so it runs outermost
if _server_cfg.https_redirect:
    from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware
    app.add_middleware(HTTPSRedirectMiddleware)

# CORS middleware — origins/methods/headers driven by config.json / env vars
# The CORS spec forbids Access-Control-Allow-Origin: * with credentials: true.
# Starlette's allow_origin_regex echoes the actual Origin header back, which
# satisfies the spec while still accepting any origin.
# If "*" appears anywhere in the list, treat as accept-all.
_cors_origins = _cors_cfg.allow_origins

# ── Always allow the frontend's own request headers ──────────────────────────
# 2026-07-12 — the SPA (services/api/core.ts safeFetch + siblings) sends these
# custom headers on its /api requests.  The browser preflights them via
# OPTIONS + Access-Control-Request-Headers.  If the operator's
# cors.allow_headers config omits ANY of them and is not "*", Starlette's
# CORSMiddleware rejects the preflight with a 23-byte
# 400 "Disallowed CORS headers" — the real GET/POST never fires and the whole
# UI looks dead (existing connections don't load, /auth/config fails, etc.).
# allow_headers is NOT a security boundary (the browser only sends headers the
# app's own JS sets; cross-origin abuse is gated by allow_origins +
# credentials, which we do NOT relax here).  So we UNION the app's required
# headers into whatever the operator configured — "*" short-circuits since it
# already permits everything.
_REQUIRED_CORS_HEADERS = [
    "Authorization", "Content-Type", "X-API-Key", "X-Request-ID",
    "X-Workspace-ID", "X-Share-Token", "X-Stream-Id",
    # 2026-09-20 -- the act-as seam (api.deps.ACT_AS_HEADER).  A browser
    # context that sends it is preflighted; omitted here, the preflight was
    # refused, every fetch failed and the SPA showed its "unreachable" page
    # -- a viewer session that was really a dead UI.
    "X-QS-Act-As-Role",
    # 2026-10-24 -- the API Explorer's "try as this consumer"
    # (core/published_api/try_as.py); refused at preflight, the trial call
    # never reached the endpoint.
    "X-QS-Try-As",
]
EXPOSED_CORS_HEADERS = [
    "Content-Disposition", "X-QS-Rows", "X-QS-Row-Limit", "X-QS-Truncated",
    "X-QS-Total-Rows", "X-QS-Continue-With",
]
_cfg_headers = list(_cors_cfg.allow_headers or [])
if "*" in _cfg_headers:
    _effective_headers = ["*"]
else:
    _seen_lower = {str(h).lower() for h in _cfg_headers}
    _effective_headers = _cfg_headers + [
        h for h in _REQUIRED_CORS_HEADERS if h.lower() not in _seen_lower
    ]
    if len(_effective_headers) != len(_cfg_headers):
        logger.info(
            "[cors] augmented allow_headers with app-required headers "
            "(configured=%d effective=%d) so the SPA's preflight isn't rejected",
            len(_cfg_headers), len(_effective_headers),
        )

# Wiz-scan #2 (2026-07-14, CWE-942): credentialed CORS with an accept-all
# origin lets ANY website make credentialed cross-origin calls to this API.
# The CORS spec forbids `Access-Control-Allow-Origin: *` together with
# `Access-Control-Allow-Credentials: true`, so when origins are wildcard/
# echo-all we MUST drop allow_credentials.  The SPA authenticates with a
# Bearer token in the Authorization header (NOT cookies), so credentialed
# mode is not needed for it to work — a manually-set Authorization header
# does not put the request in credentials mode.  In split-host production
# the operator configures an explicit origin allowlist, so this branch is
# NOT taken and allow_credentials stays True for those exact origins.
_allow_all_origins = ("*" in _cors_origins) or bool(_cors_cfg.echo_request_origin)
if _allow_all_origins:
    logger.warning(
        "[cors] accept-all origins configured (wildcard or echo_request_origin)"
        " — dropping allow_credentials per CORS spec (CWE-942).  Bearer-token"
        " auth is unaffected; cookie-based credentialed cross-origin calls are"
        " intentionally not permitted with a wildcard origin."
    )
_cors_kwargs = {
    "allow_credentials": not _allow_all_origins,
    "allow_methods": _cors_cfg.allow_methods,
    "allow_headers": _effective_headers,
    # 2026-11-03 -- the SPA reads a download's file name and the X-QS-* cut
    # disclosure from another origin; unexposed, the browser hid them and a
    # download was named after the request path, query string and all.
    "expose_headers": EXPOSED_CORS_HEADERS,
}
if "*" in _cors_origins:
    _cors_kwargs["allow_origin_regex"] = ".*"
elif _cors_cfg.echo_request_origin:
    # BF-404 — echo-origin escape hatch: accept ANY origin (less strict than
    # explicit allowlist, useful for preview deploys with dynamic URLs).
    _cors_kwargs["allow_origin_regex"] = ".*"
    logger.warning(
        "[cors] echo_request_origin=true — Access-Control-Allow-Origin will "
        "echo every request's Origin header.  Use only when the exact origin "
        "set is genuinely impossible to enumerate (preview deploys, etc.)."
    )
else:
    # BF-404 — combine the explicit allowlist with the suffix list into a
    # single regex so Starlette's CORSMiddleware (which handles the OPTIONS
    # preflight) honours both.  Without this, our custom origin-check would
    # only block POST/PUT/DELETE/PATCH on the FIRST request — but the
    # preflight OPTIONS would already have been rejected by Starlette and
    # the browser would never send the real request.
    _suffixes = list(_cors_cfg.allow_origin_suffixes or [])
    if _suffixes:
        import re as _re
        # Build a regex: ^(https?://)?(<exact_host_1>|<exact_host_2>|...
        # |(?:.*\.)?<suffix_1>|(?:.*\.)?<suffix_2>)(:\d+)?(/.*)?$
        # Escape special chars in each entry before joining.
        # BF-414 — suffix patterns previously used ``.*<suffix>`` which
        # accepted any host that ENDED with the suffix string, including
        # ``evilapps.cluster.example.com`` matching suffix
        # ``apps.cluster.example.com`` (subdomain attack).  Now we require
        # the suffix to either match the entire host OR be preceded by a
        # literal dot — so only true sub-domains pass.
        def _origin_to_pattern(o: str) -> str:
            from urllib.parse import urlparse as _u
            host = (_u(o if "://" in o else f"//{o}").netloc or o).lower()
            return _re.escape(host)

        def _suffix_to_pattern(s: str) -> str:
            # Strip a leading dot if the admin wrote ``.apps.example.com``
            # (both forms are accepted).
            normalised = s.lstrip(".").lower()
            esc = _re.escape(normalised)
            # Either the host == suffix, OR the host ends with .suffix
            return f"(?:.*\\.)?{esc}"

        _exact_patterns = [_origin_to_pattern(o) for o in _cors_origins]
        _suffix_patterns = [_suffix_to_pattern(s) for s in _suffixes if s]
        _combined = "|".join(_exact_patterns + _suffix_patterns)
        _cors_kwargs["allow_origin_regex"] = (
            r"^https?://(" + _combined + r")(:\d+)?$"
        )
        logger.info(
            "[cors] using regex match: exact=%d suffix=%d entries",
            len(_exact_patterns), len(_suffix_patterns),
        )
    else:
        _cors_kwargs["allow_origins"] = _cors_origins
app.add_middleware(CORSMiddleware, **_cors_kwargs)

# Rate limiter setup
limiter = Limiter(key_func=get_remote_address, default_limits=["200/minute"])
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


# ── Global error sanitization — strip credentials/paths from 500 responses ─────
async def _global_unhandled_error_handler(request, exc):
    """Catch unhandled exceptions and return a sanitized 500 response."""
    import logging as _logging
    from core.error_sanitizer import sanitize_error
    _logging.getLogger("main").error("Unhandled error on %s %s: %s",
                                     request.method, request.url.path, exc, exc_info=True)
    from starlette.responses import JSONResponse
    return JSONResponse(
        status_code=500,
        content={"detail": sanitize_error(str(exc))},
    )


app.add_exception_handler(Exception, _global_unhandled_error_handler)


async def _calendar_token_refused_handler(request, exc):
    """A date token that cannot be rendered is the CALLER's problem: 400
    with the reason (which calendars exist, which key to set) -- never the
    sanitized 500 above, and never a silent fallback to plain calendar days
    (core.business_calendar_tokens, 2026-09-28).  Registered for the
    exception class so every route that resolves a date token -- report
    runs, saved-query and dashboard filters, published views -- answers the
    same way without each one catching it."""
    from starlette.responses import JSONResponse
    return JSONResponse(status_code=400, content={"detail": str(exc)})


from core.business_calendar_tokens import (  # noqa: E402
    CalendarTokenRefused as _CalendarTokenRefused,
)
app.add_exception_handler(_CalendarTokenRefused, _calendar_token_refused_handler)


async def _encryption_key_unavailable_handler(request, exc):
    """No encryption key in this component (yet): a credential cannot be
    saved.  503 with the reason and the fix (core/crypto.py, 2026-10-15) --
    never the sanitized 500, and never a password stored under a key that
    would be lost."""
    from starlette.responses import JSONResponse
    return JSONResponse(status_code=503, content={"detail": str(exc)})


from core.crypto import EncryptionKeyUnavailable as _EncryptionKeyUnavailable  # noqa: E402
app.add_exception_handler(_EncryptionKeyUnavailable, _encryption_key_unavailable_handler)



def _encryption_refusal(exc):
    """The ``EncryptionKeyUnavailable`` an exception CARRIES, or None -- through
    ``__cause__`` / ``__context__`` (a route's ``except Exception -> 500``) and
    SQLAlchemy's ``.orig`` (a SecretJSON column that encrypts at FLUSH: the
    refusal arrives as a StatementError).  2026-10-17: a PROD feed save waiting
    for data keys reached the safety net as a bare 500 "contact support"."""
    seen, todo = set(), [exc]
    while todo and len(seen) < 12:
        e = todo.pop()
        if e is None or id(e) in seen:
            continue
        seen.add(id(e))
        if isinstance(e, _EncryptionKeyUnavailable):
            return e
        todo += [getattr(e, "orig", None), getattr(e, "__cause__", None), getattr(e, "__context__", None)]
    return None


# ── BF-402 — Log every 4xx with full diagnostic context ──────────────────────
# FastAPI's default behaviour: validation errors → 422 with field details in
# the response body, but NO log line.  HTTPException(400, "...") → response
# emitted, no log line.  In production (OpenShift, behind a reverse proxy)
# this makes 400/422 errors completely invisible — admins see "save failed"
# in the UI and have no way to debug from `oc logs`.
#
# These two handlers preserve the SAME response shape FastAPI/Starlette would
# have produced (so frontend behaviour is unchanged), but ALSO emit a log
# line at WARNING level with:
#   - HTTP method + path
#   - the validation error list (RequestValidationError) or detail (HTTPException)
#   - the raw request body for POST/PUT/PATCH (truncated to 2 KB; secrets
#     redacted via core.error_sanitizer)
#   - any X-Request-ID header so the log line can be correlated with the
#     consumer's request
async def _validation_exception_handler(request, exc):
    """RequestValidationError → 422 + WARNING log with body + errors.

    BF-402: makes Pydantic validation failures debuggable on OpenShift.
    """
    import logging as _logging
    from starlette.responses import JSONResponse
    from core.error_sanitizer import (REDACTED, _is_sensitive_key, redact_structure,
                                      sanitize_error)
    _logger = _logging.getLogger("main.validation")
    body_preview = ""
    try:
        # request.body() was already consumed by FastAPI's validator;
        # exc.body holds what it tried to parse (Starlette ≥0.27).
        _raw = getattr(exc, "body", None)
        if _raw is not None:
            if isinstance(_raw, (bytes, bytearray)):
                _raw = _raw.decode("utf-8", errors="replace")
            if isinstance(_raw, str):
                # a JSON body that failed validation still has structure
                try:
                    import json as _json
                    _raw = _json.loads(_raw)
                except Exception:
                    pass
            # 2026-10-05 -- STRUCTURAL redaction: the regex scrub alone missed
            # a parsed dict's "'aws_secret_access_key': '...'" form.
            body_preview = sanitize_error(str(redact_structure(_raw)))[:2000]
    except Exception:
        body_preview = "<unreadable>"
    # 2026-08-23: pydantic v2 puts the raising exception OBJECT into each
    # error's ctx ({"error": ValueError(...)}), and 'input' can be bytes.
    # JSONResponse cannot serialize either, so this handler itself raised
    # TypeError and the client saw a 500 for what was a plain 422 — any
    # field_validator that raises ValueError anywhere in the app hit this.
    # Coerce non-primitive values to str before logging/returning.
    def _prim(v):
        return v if isinstance(v, (str, int, float, bool, type(None))) else str(v)

    raw_errors = getattr(exc, "errors", lambda: [])()
    errors = []
    for e in raw_errors:
        try:
            e = dict(e)
            if isinstance(e.get("ctx"), dict):
                e["ctx"] = {k: _prim(v) for k, v in e["ctx"].items()}
            if "input" in e:
                # 2026-10-05 -- redact BEFORE it reaches the response or the
                # log: pydantic puts the whole body here when a top-level
                # field is missing, and a credential field's own value here
                # when that field is malformed.
                _loc = e.get("loc") or ()
                if _loc and _is_sensitive_key(_loc[-1]):
                    e["input"] = REDACTED
                else:
                    e["input"] = _prim(redact_structure(e["input"]))
            errors.append(e)
        except Exception:
            errors.append({"msg": str(e)})
    _logger.warning(
        "[validation-422] %s %s — errors=%s body=%s rid=%s",
        request.method, request.url.path,
        errors,
        body_preview,
        request.headers.get("x-request-id", "-"),
    )
    return JSONResponse(
        status_code=422,
        content={"detail": errors},
    )


def _wrapped_client_error(exc):
    """The 4xx ``HTTPException`` that ``exc`` (a 5xx) was raised while
    handling, or None.  Walks ``__cause__``/``__context__`` (bounded), stops
    at an explicit ``from None``.  See FB-33 in ``_http_exception_logger``."""
    if getattr(exc, "status_code", 500) < 500:
        return None
    seen = 0
    cur = exc
    while cur is not None and seen < 8:
        seen += 1
        _cause = getattr(cur, "__cause__", None)
        if getattr(cur, "__suppress_context__", False) and _cause is None:
            return None          # ``raise ... from None`` -- the author severed it
        nxt = _cause if _cause is not None else getattr(cur, "__context__", None)
        if nxt is None or nxt is cur:
            return None
        if isinstance(nxt, _StarletteHTTPException):
            code = getattr(nxt, "status_code", 500)
            if 400 <= code < 500:
                return nxt
            return None          # a 5xx wrapping a 5xx: nothing to restore
        cur = nxt
    return None


def _is_authored_5xx(exc) -> bool:
    """True when ``exc``'s detail was WRITTEN, not derived from a caught
    exception: raised with no exception being handled, or with
    ``from None``.  See FB-31 in ``_http_exception_logger``."""
    if getattr(exc, "__suppress_context__", False):
        return True
    return (getattr(exc, "__context__", None) is None
            and getattr(exc, "__cause__", None) is None)


def _sanitize_detail(detail):
    """``sanitize_error`` applied through a dict/list detail so a structured
    503 (``{"detail": ..., "retry_after": ...}``) keeps its shape."""
    from core.error_sanitizer import sanitize_error
    if isinstance(detail, dict):
        return {k: _sanitize_detail(v) for k, v in detail.items()}
    if isinstance(detail, list):
        return [_sanitize_detail(v) for v in detail]
    if isinstance(detail, str):
        return sanitize_error(detail)
    return detail


async def _http_exception_logger(request, exc):
    """HTTPException → preserve response, log 4xx at WARNING / 5xx at ERROR.

    BF-402: every 400 / 403 / 404 / 409 / 429 from the API now leaves a
    breadcrumb in the logs.  401 is logged at DEBUG (noisy from unauth
    polling), 5xx escalates to ERROR.  Detail + path + request-id captured.
    """
    import logging as _logging
    from starlette.responses import JSONResponse
    from core.error_sanitizer import sanitize_error
    _logger = _logging.getLogger("main.http")
    # FB-33 (2026-09-19): a handler that catches ``except Exception`` and
    # re-raises as ``HTTPException(500, f"...: {exc}")`` wraps a 4xx it
    # raised itself -- the client saw ``500 "setting update failed: 400:
    # unknown setting key"``: the status code INSIDE the text of a different
    # status code.  A 400 says "you sent something wrong", a 500 says "the
    # server is broken" -- opposite investigations, and the second pages
    # someone.  Python records the exception being handled on the one
    # raised (``__context__``), so the chokepoint can tell -- once, for
    # every route -- that a 5xx was raised WHILE HANDLING a client error,
    # and serve the client error.  ``raise ... from None`` is the author's
    # explicit override (``__suppress_context__``) and is honoured.
    # 2026-10-15 -- a route that wrapped "no encryption key in this
    # component" into a 500 (every ``except Exception -> 500``): the operator's
    # fix is the answer, never "contact support" (core/crypto.py).
    _ctx = _encryption_refusal(exc)
    if _ctx is not None:
        _logger.error("[encryption-key] %s %s refused: %s", request.method,
                      request.url.path, _ctx)
        return JSONResponse(status_code=503, content={"detail": str(_ctx)})
    _client_err = _wrapped_client_error(exc)
    if _client_err is not None:
        _logger.warning(
            "[http-unwrap] %s %s: a %s was raised while handling a %s -- "
            "serving the client error (raise `from None` to override)",
            request.method, request.url.path,
            getattr(exc, "status_code", "?"), _client_err.status_code)
        exc = _client_err
    _code = getattr(exc, "status_code", 500)
    _detail = sanitize_error(str(getattr(exc, "detail", "") or ""))[:500]
    _rid = request.headers.get("x-request-id", "") or ""
    if not _rid or _rid == "-":
        # Wiz-scan #4: always mint a correlation handle so the operator can
        # find the full (logged) detail from the generic 5xx client response.
        import uuid as _uuid
        _rid = _uuid.uuid4().hex[:12]
    if _code >= 500:
        _logger.error("[http-%d] %s %s detail=%s rid=%s",
                       _code, request.method, request.url.path, _detail, _rid)
    elif _code == 401:
        # Unauth polling can be very noisy — drop to DEBUG
        _logger.debug("[http-%d] %s %s detail=%s rid=%s",
                       _code, request.method, request.url.path, _detail, _rid)
    else:
        _logger.warning("[http-%d] %s %s detail=%s rid=%s",
                         _code, request.method, request.url.path, _detail, _rid)
    # Wiz-scan #4 (2026-07-14, CWE-209 info leak): 5xx details across the app
    # frequently embed raw exception text (the ``HTTPException(500,
    # f"...{str(e)}")`` pattern) which can leak internal paths, SQL, table
    # names, or driver messages.  This ONE chokepoint — every HTTPException in
    # the app funnels through it — returns a generic message + correlation id
    # for 5xx; the FULL sanitized detail is in the server log above under the
    # same rid.  4xx details are developer-authored, user-facing, and safe, so
    # they pass through unchanged and the UI keeps its actionable messages.
    if _code == 501:
        # 2026-09-15: 501 Not Implemented is a CAPABILITY statement ("this
        # server cannot render PDFs / has no PyArrow"), and every 501 in the
        # app carries a developer-authored constant, never exception text
        # (business_reports_api maps ONLY PdfRendererUnavailable to it).
        # Erasing it left the caller with "contact support" for a missing
        # apt package.  Sanitised anyway, and the request_id kept.
        _body = {"detail": sanitize_error(str(getattr(exc, "detail", "") or "")),
                 "request_id": _rid}
    elif _code in (503, 504) and _is_authored_5xx(exc):
        # FB-31 (2026-09-19): a 503/504 is an AVAILABILITY statement -- "not
        # enabled on this deployment", "worker not running", "timed out".
        # Four routes were measured raising exactly that sentence and the
        # caller receiving "contact support" (the sentence went to the log).
        # The CWE-209 concern is EXCEPTION TEXT (host:port, driver
        # messages) reaching the client, and the two are distinguishable by
        # provenance: exception text is raised while HANDLING that
        # exception (``__context__`` set); an authored sentence is raised
        # from a plain ``if`` (no context) or with ``from None`` (the
        # author's declaration that the message embeds nothing).  Sanitised
        # anyway, and the request_id kept.  500 is deliberately NOT here: it
        # is "internal error" by definition and stays generic.
        _body = {"detail": _sanitize_detail(getattr(exc, "detail", None)),
                 "request_id": _rid}
    elif _code >= 500 and (getattr(exc, "headers", None) or {}).get("Retry-After"):
        # 2026-09-15: a 5xx that sets ``Retry-After`` is a CAPACITY statement
        # ("queue full", "at capacity", "cache too fresh -- retry in Ns"),
        # not an internal error.  Every such site in the app authors a
        # constant with numbers in it, never exception text (audited: the
        # admission gate, /api/execute's load-shed and queue-full, the
        # Published API's per-key caps).  Erasing it left a caller with
        # "contact support" for a full queue and no way to distinguish
        # back-pressure from a crash -- found live: the Docker load proof
        # showed 503 + Retry-After: 30 + "Internal server error".  Sanitised
        # anyway, and the request_id kept.
        _body = {"detail": sanitize_error(str(getattr(exc, "detail", "") or "")),
                 "request_id": _rid}
    elif _code >= 500:
        _body = {
            "detail": "Internal server error. Please contact support with this reference.",
            "request_id": _rid,
        }
    else:
        _body = {"detail": getattr(exc, "detail", "Error")}
    _resp_headers = dict(getattr(exc, "headers", None) or {})
    _resp_headers.setdefault("X-Request-ID", _rid)
    return JSONResponse(
        status_code=_code,
        content=_body,
        headers=_resp_headers,
    )


# Wire the two handlers.  RequestValidationError comes from FastAPI; we also
# catch the Starlette-level base in case something raises it directly.
try:
    from fastapi.exceptions import RequestValidationError as _RVE
    app.add_exception_handler(_RVE, _validation_exception_handler)
except Exception as _rve_err:
    logger.debug("RequestValidationError handler not wired: %s", _rve_err)

from starlette.exceptions import HTTPException as _StarletteHTTPException  # noqa: E402
app.add_exception_handler(_StarletteHTTPException, _http_exception_logger)
# Also catch FastAPI's own HTTPException class (separate subclass)
try:
    from fastapi import HTTPException as _FastAPIHTTPException
    if _FastAPIHTTPException is not _StarletteHTTPException:
        app.add_exception_handler(_FastAPIHTTPException, _http_exception_logger)
except Exception as _fhe_err:
    logger.debug("FastAPI HTTPException handler not wired separately: %s", _fhe_err)

def _safe_metric(factory, name: str, *args, **kwargs):
    """Register a Prometheus metric idempotently.

    prometheus_client's REGISTRY is PROCESS-global, not module-global, so a
    second import/creation of this module raises
    ``ValueError: Duplicated timeseries in CollectorRegistry``.  That happens
    on uvicorn --reload, on hot-patch, and in any test process where more
    than one module builds the app -- where it is NOT cosmetic: the raise
    propagates out of app construction and every test depending on that
    fixture ERRORS at setup.  A chunked full-suite run on 2026-08-04 lost 51
    tests in one chunk to exactly this.

    api/system_api.py (_safe_counter), core/brain_duckdb_store.py and
    core/brain_latency_breakdown.py all already carry this guard; main.py --
    which registers the HTTP metrics every request path touches -- was the
    one place still calling the raw constructor.

    On duplicate, the EXISTING collector is returned, but only after checking
    it is the same class.  A Gauge would pass a ``hasattr(x, "inc")`` test
    (Gauge is mutable both ways) while meaning something entirely different,
    so the type check is what makes reuse safe rather than merely quiet.
    """
    try:
        return factory(name, *args, **kwargs)
    except ValueError:
        from prometheus_client import REGISTRY as _PROM_REG
        existing = getattr(_PROM_REG, "_names_to_collectors", {}).get(name)
        if existing is None:
            for col in list(getattr(_PROM_REG, "_collector_to_names", {})):
                if name in (_PROM_REG._collector_to_names.get(col) or set()):
                    existing = col
                    break
        if existing is None or not isinstance(existing, factory):
            raise   # no existing collector, or a DIFFERENT metric type
        return existing


_prom_requests_total = _safe_metric(
    Counter,
    "http_requests_total", "Total HTTP requests",
    ["method", "path_template", "status"],
)
_prom_request_duration = _safe_metric(
    Histogram,
    "http_request_duration_seconds", "Request latency",
    ["method", "path_template"],
    buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10, 30],
)
_prom_pool_active = _safe_metric(
    Gauge, "worker_pool_active_tasks", "Active tasks by type", ["work_type"])
_prom_pool_queued = _safe_metric(
    Gauge, "worker_pool_queued_tasks", "Queued tasks by type", ["work_type"])
_prom_websockets = _safe_metric(
    Gauge, "active_websocket_connections", "Active WebSocket connections")

# ── OpenTelemetry Tracing (21C) — optional, auto-disabled if not installed ──
def _setup_otel():
    """Configure OpenTelemetry if the SDK is installed and an endpoint is configured."""
    try:
        from core.config import server as _srv_cfg
        otel_endpoint = getattr(_srv_cfg, "otel_endpoint", "") or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "")
        if not otel_endpoint:
            return  # No endpoint configured — skip silently

        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
        from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

        resource = Resource.create({
            "service.name": os.environ.get("OTEL_SERVICE_NAME", "querystudio"),
            "service.version": "2.0.0",
        })
        provider = TracerProvider(resource=resource)
        exporter = OTLPSpanExporter(endpoint=otel_endpoint, insecure=True)
        provider.add_span_processor(BatchSpanProcessor(exporter))
        trace.set_tracer_provider(provider)
        FastAPIInstrumentor.instrument_app(app, tracer_provider=provider)
        logger.info("OpenTelemetry tracing enabled → %s", otel_endpoint)
    except ImportError:
        logger.debug("OpenTelemetry SDK not installed — tracing disabled")
    except Exception as exc:
        logger.warning("OpenTelemetry setup failed (non-fatal): %s", exc)

_setup_otel()

# Collapse UUIDs / numeric IDs in paths to prevent metric cardinality explosion
_UUID_RE = _re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", _re.I)
_NUMERIC_ID_RE = _re.compile(r"/\d+(?=/|$)")

def _normalize_metric_path(path: str) -> str:
    """Collapse /api/queries/abc-123-... → /api/queries/{id}"""
    path = _UUID_RE.sub("{id}", path)
    path = _NUMERIC_ID_RE.sub("/{id}", path)
    return path


# ── Middleware: security headers + request logging + Prometheus + origin check ─
@app.middleware("http")
async def _enterprise_middleware(request: Request, call_next):
    start = _time.time()
    request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())[:8]
    # Phase 83D: Set correlation ID in context var for log filter
    _request_id_var.set(request_id)
    from core.user_context import begin_request as _begin_request
    _begin_request()   # who is asking, readable by the route (config audit)

    # ── Origin check (CSRF defense-in-depth) ──
    # BF-404 — three fixes vs the original implementation:
    #   1. LOG the rejection at WARNING with origin + allowed list + rid.
    #      Previously silent — admins had no way to see what was blocked.
    #   2. Substring match (`origin_host in allowed_entry`) was a security
    #      hole — "evil-app.example.com" matched "app.example.com" entries.
    #      Now does proper hostname comparison: exact match OR allowed-entry
    #      suffix match via the new cors.allow_origin_suffixes config.
    #   3. New `cors.echo_request_origin` opt-in for environments where the
    #      exact origin set is hard to know up-front (preview deploys, etc.).
    if request.method in ("POST", "PUT", "DELETE", "PATCH"):
        origin = request.headers.get("origin") or request.headers.get("referer", "")
        allowed = list(_cors_cfg.allow_origins or [])
        if "*" not in allowed and origin:
            from urllib.parse import urlparse
            origin_host = (urlparse(origin).netloc or "").lower()
            if origin_host:
                _matched = False
                # Exact-host match against any allowed origin entry
                for ao in allowed:
                    ao_host = (urlparse(ao if "://" in ao else f"//{ao}").netloc or ao).lower()
                    if ao_host == origin_host:
                        _matched = True
                        break
                # Suffix match (e.g. ".apps.cluster.example.com")
                # BF-414 — previous ``endswith(s)`` allowed
                # ``evilapps.cluster.example.com`` to match suffix
                # ``apps.cluster.example.com``.  Require either an exact
                # equality or a true subdomain (dot-boundary) match.
                if not _matched:
                    for suffix in (_cors_cfg.allow_origin_suffixes or []):
                        s = str(suffix or "").lstrip(".").lower()
                        if not s:
                            continue
                        if origin_host == s or origin_host.endswith("." + s):
                            _matched = True
                            break
                # Echo-origin escape hatch (only when explicitly enabled)
                if not _matched and _cors_cfg.echo_request_origin:
                    _matched = True
                    logger.debug("[cors] echo_request_origin=true — allowing %s", origin_host)
                if not _matched:
                    logger.warning(
                        "[cors-reject] %s %s blocked origin=%s host=%s "
                        "allowed=%s suffixes=%s rid=%s — "
                        "fix by adding to cors.allow_origins, cors.allow_origin_suffixes, "
                        "or setting cors.echo_request_origin=true",
                        request.method, request.url.path,
                        origin, origin_host,
                        allowed, list(_cors_cfg.allow_origin_suffixes or []),
                        request_id,
                    )
                    from fastapi.responses import JSONResponse
                    return JSONResponse(
                        status_code=403,
                        content={
                            "detail": "Origin not allowed",
                            "origin": origin_host,
                            "request_id": request_id,
                        },
                    )

    try:
        response = await call_next(request)
    except BaseException as exc:
        # GLOBAL SAFETY NET — no endpoint crash should ever kill the backend.
        # Log the full traceback and return 500 instead of letting it propagate.
        duration_s = _time.time() - start
        _refused = _encryption_refusal(exc)
        if _refused is not None:
            # the operator's fix, never "contact support" (core/crypto.py)
            logger.error("[encryption-key] %s %s refused: %s", request.method, request.url.path, _refused)
            from starlette.responses import JSONResponse as _JSONResp
            return _JSONResp(status_code=503, content={"detail": str(_refused), "request_id": request_id},
                             headers={"X-Request-ID": request_id})
        logger.critical("Unhandled crash in %s %s: %s rid=%s", request.method, request.url.path, exc, request_id, exc_info=True)
        from starlette.responses import JSONResponse as _JSONResp
        # FB-30/FB-34 (2026-09-19): this body carried the exception CLASS
        # (``Internal server error: AttributeError``) -- a CWE-209 leak the
        # HTTPException chokepoint below already closes, reopened here for
        # every crash that reaches the safety net.  Same generic body, same
        # correlation handle; the class and traceback are in the log above.
        return _JSONResp(
            status_code=500,
            content={"detail": "Internal server error. Please contact support with this reference.",
                     "request_id": request_id},
            headers={"X-Request-ID": request_id})
    duration_s = _time.time() - start

    # ── Security headers ──
    _req_path = request.url.path
    response.headers["X-Content-Type-Options"] = "nosniff"
    # Allow iframes for shared/embedded report paths (public, no auth)
    _embeddable = _req_path.startswith(("/api/shared-", "/api/embedded-"))
    if not _embeddable:
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    # Swagger/ReDoc load CSS+JS from cdn.jsdelivr.net — relax CSP for doc paths
    # (BF-397 revised: Swagger moved to /api-docs to free /docs for the HTML portal)
    if _req_path in ("/api-docs", "/api-docs/oauth2-redirect", "/api-redoc", "/openapi.json"):
        response.headers["Content-Security-Policy"] = (
            "default-src 'self' cdn.jsdelivr.net; "
            "script-src 'self' 'unsafe-inline' cdn.jsdelivr.net; "
            "style-src 'self' 'unsafe-inline' cdn.jsdelivr.net; "
            "img-src 'self' data: blob: cdn.jsdelivr.net; "
            "font-src 'self' data: cdn.jsdelivr.net; "
            "object-src 'none'; "
            "frame-ancestors 'self'"
        )
    else:
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; "
            "connect-src 'self' ws: wss:; "
            "font-src 'self' data:; "
            "object-src 'none'; "
            "frame-ancestors 'self'"
        )
    response.headers["X-Request-ID"] = request_id
    response.headers["X-API-Version"] = API_MAJOR

    # ── Request logging (structured JSON or text) ──
    path = request.url.path
    if path not in ("/health", "/metrics"):  # skip noisy health/metric polls
        # BF-WS-NOBLOCK-4: highlight slow requests at WARNING level so they're
        # visible in logs without scanning duration_ms by eye.  Anything over
        # 2 s in an async handler is a candidate for unwrapped sync DB / IO
        # work that's blocking the asyncio loop and starving WS heartbeats.
        # BF-403: also embed method/path/status/duration into the MESSAGE
        # text (not just `extra=`) so plain-text log formatters surface them
        # without JSON parsing.  Earlier code only worked under the JSON
        # formatter — admins on text-format saw "INFO main request" with no
        # detail.  Username is pulled from the session cookie / API key when
        # available (just the username string; never the full user dict).
        _ms = round(duration_s * 1000, 1)
        _user_label = "-"
        try:
            # core.sessions.get_session_user reads the session cookie OR
            # API key header (if present) and returns a dict with "username".
            # Failures are silent — auth issues are logged separately at the
            # endpoint level.
            # 2026-09-01 -- ``core.sessions`` has no ``get_session_user``
            # (it is keyed by token, not request).  The ImportError meant
            # every access-log line recorded the user as "-", which is
            # exactly the field an operator greps when tracing a request.
            # 2026-10-07: READ the principal the request already resolved
            # (the scope middleware / the route's dependency stash it) --
            # never authenticate again here: this ran ON THE EVENT LOOP after
            # every response, a session-store read or a password check
            # (LDAP / pbkdf2) for any request the stash did not cover.
            _u = getattr(request.state, "qs_resolved_user", None)
            if _u:
                _user_label = str(_u.get("username") or _u.get("name") or "-")[:60]
        except Exception as _u_err:
            logger.debug("[access-log] could not resolve user: %s", _u_err)
        # Content-Length on the response (when present) — useful for spotting
        # silent giant responses, totally safe to log.
        _resp_bytes = response.headers.get("content-length", "?")
        _client_host = request.client.host if request.client else "-"
        _query_keys = ",".join(sorted(set(request.query_params.keys())))[:200] or "-"
        # Single-line message with EVERY field needed for triage in plain-text
        # mode.  No request body, no query VALUES (keys only), no auth tokens,
        # no response body — all PII-safe.
        _msg = (
            f"REQ {request.method} {path} "
            f"status={response.status_code} ms={_ms} "
            f"user={_user_label} client={_client_host} "
            f"q=[{_query_keys}] bytes={_resp_bytes} rid={request_id}"
        )
        _log_extra = {
            "request_id": request_id,
            "method": request.method,
            "path": path,
            "status": response.status_code,
            "duration_ms": _ms,
            "client": _client_host,
            "user": _user_label,
            "resp_bytes": _resp_bytes,
            "query_keys": _query_keys,
        }
        if duration_s >= 5.0:
            logger.warning(f"SLOW (>5s) {_msg}", extra=_log_extra)
        elif duration_s >= 2.0:
            logger.warning(f"slow (>2s) {_msg}", extra=_log_extra)
        else:
            logger.info(_msg, extra=_log_extra)

    # ── Prometheus metrics ──
    path_tmpl = _normalize_metric_path(path)
    _prom_requests_total.labels(
        method=request.method, path_template=path_tmpl, status=response.status_code,
    ).inc()
    _prom_request_duration.labels(
        method=request.method, path_template=path_tmpl,
    ).observe(duration_s)

    return response


# Thread pool for CPU-bound query execution (heavy: COPY TO parquet, etc.)
query_executor = ThreadPoolExecutor(
    max_workers=_qe_cfg.max_workers,
    thread_name_prefix="query"
)

# ── Middleware: the scheduler-only scope (2026-09-10) ────────────────────
# "If someone has access for schedule they see scheduler only."  The rule
# lives in core/clockwork/scope.py; this is its API-side enforcer, and it is
# INDEPENDENT of the frontend: RoleGuard is presentation, super_admin
# bypasses it, and curl never saw it.  Only ``/api/*`` and ``/graphql`` are
# enforced; the SPA's files and the websocket upgrade are not narrowed.
#
# The principal is resolved through the SAME ``_resolve_user`` the route
# dependency uses and stashed on ``request.state`` so the route does not
# authenticate twice.  A caller that does not authenticate here is passed
# through untouched — the route's own dependency refuses it with 401; this
# middleware only ever NARROWS an authenticated scheduler-scoped principal.
@app.middleware("http")
async def _scheduler_scope_middleware(request: Request, call_next):
    path = request.url.path
    if path.startswith(("/api/", "/graphql")):
        from core.clockwork.scope import (
            SCOPED_API_PREFIXES, path_allowed_for_scoped, scope_decision,
        )
        if not path_allowed_for_scoped(path):
            user = None
            try:
                # 2026-10-07: resolved OFF the event loop whenever that takes
                # I/O (a session-store read, a password check) -- inline it
                # stalled every request on the pod (api.deps.aresolve_user).
                from api.deps import aresolve_user as _mw_resolve_user
                user = await _mw_resolve_user(request)
            except Exception:                         # noqa: BLE001 — the route decides
                user = None
            if user is not None:
                try:
                    request.state.qs_resolved_user = user
                except Exception:                     # noqa: BLE001
                    pass
                verdict = scope_decision(user, path)
                if not verdict["allowed"]:
                    from fastapi.responses import JSONResponse
                    logger.info("[scheduler-scope] %s %s refused for %s: %s",
                                request.method, path, user.get("username"), verdict["reason"])
                    return JSONResponse(status_code=403, content={
                        "detail": verdict["reason"],
                        "scope": "scheduler_only",
                        "allowed_api_prefixes": list(SCOPED_API_PREFIXES),
                    })
    return await call_next(request)


# Dedicated thread pool for lightweight operations: streaming, schema,
# file listing, metadata.  This is a SEPARATE pool from both query_executor
# and the WorkerPool so heavy background queries can never starve it.
# Sized for I/O-bound work (S3 HTTP calls, parquet footer reads).
_streaming_executor = ThreadPoolExecutor(
    max_workers=min(20, (os.cpu_count() or 4) * 2),
    thread_name_prefix="stream"
)
#: Guards the rebuild in ``_get_light_executor`` -- two requests arriving
#: after a shutdown must not each build a pool and race the global.
_streaming_executor_lock = threading.Lock()

def _get_light_executor():
    """Return the dedicated streaming/metadata executor, REBUILDING it if it
    has been shut down.

    Streaming pagination, schema discovery, file listing, metadata reads
    all go through this pool. It is completely isolated from the heavy
    query_executor and the WorkerPool, so it is never blocked by
    long-running background queries.

    2026-09-15 -- this returned the module global unconditionally, so once
    the lifespan shutdown had killed it (``shutdown(cancel_futures=True)``)
    every later caller got a corpse and its ``run_in_executor`` raised
    "cannot schedule new futures after shutdown" -- surfacing as a 500 from
    whichever route submitted next, several layers from the cause.  It is
    the same defect as ``worker_pool.get_pool`` handing out a shut-down
    pool, but it needs the OPPOSITE fix: that pool is explicitly
    initialised and its callers catch RuntimeError and fall back, so it
    RAISES; this one is infrastructure that callers hand straight to
    ``run_in_executor`` with no fallback, so it REBUILDS -- the same answer
    ``duckdb_worker_pool`` gives for its lazily-constructed singleton.

    Rebuilding is safe: the pool owns no state, and a shut-down pool cannot
    be restarted by any public API.
    """
    global _streaming_executor
    if getattr(_streaming_executor, "_shutdown", False):
        with _streaming_executor_lock:
            if getattr(_streaming_executor, "_shutdown", False):
                logger.info(
                    "[executors] the streaming executor had been shut down; "
                    "rebuilding it rather than handing back a pool that "
                    "rejects every submit")
                _streaming_executor = ThreadPoolExecutor(
                    max_workers=min(20, (os.cpu_count() or 4) * 2),
                    thread_name_prefix="stream",
                )
    return _streaming_executor

# Notification poller asyncio task — set in _startup() when scheduler.mode = "external"
_notification_poller_task = None
# Executor poller asyncio task — set in _startup() when executor.mode = "external"
_executor_poller_task = None
# Phase 120: DQ monitor periodic task — set in _startup() when dq_monitor agent is enabled
_dq_monitor_task = None

# Phase 114-C: Published API dedicated pod mode — only register published views + health
_PUBLISHED_API_MODE = os.environ.get("QUERYSTUDIO_PUBLISHED_API_MODE", "").lower() in ("true", "1", "yes")

# 2026-08-09 (reporting rewire Phase 4) — Reports dedicated pod mode.
# docs/reports_target_architecture_2026_08_08.md §6: microcube drill gestures
# are synchronous DuckDB CPU work; co-located with this event loop at 100+
# concurrent users they re-create the starved-/health incident class, so the
# reports surface gets its own pod.  Sibling of _PUBLISHED_API_MODE above —
# same mechanism (env flag → router subset), different surface.
_REPORTS_MODE = os.environ.get("QUERYSTUDIO_REPORTS_MODE", "").lower() in ("true", "1", "yes")

# 2026-08-30 — Download Centre dedicated pod mode.  Third sibling of the two
# flags above; same mechanism (env flag -> router subset), different surface.
# It exists because /api/downloads/{id}/preview|chart-data|pivot-data submit
# their DuckDB work to worker_pool.get_pool().executor — the SAME pool
# reports_api/schedules_api/sql_query_api use to EXECUTE QUERIES — so on the
# API pod, browsing stored result files competed with running new ones, and
# streaming a large export tied up request capacity on top of that.
_DOWNLOADS_MODE = os.environ.get("QUERYSTUDIO_DOWNLOADS_MODE", "").lower() in ("true", "1", "yes")
if _DOWNLOADS_MODE and (_REPORTS_MODE or _PUBLISHED_API_MODE):
    # Same posture as the pair below: warn loudly, keep the FIRST-established
    # mode, never refuse to boot.  A mode misconfig must not take a pod down,
    # but it must never go unnoticed either.
    logger.warning(
        "QUERYSTUDIO_DOWNLOADS_MODE is set together with REPORTS_MODE/"
        "PUBLISHED_API_MODE — they are mutually exclusive pod roles.  "
        "Ignoring DOWNLOADS_MODE.  Fix the deployment env."
    )
    _DOWNLOADS_MODE = False
if _REPORTS_MODE and _PUBLISHED_API_MODE:
    # Mutually exclusive pod roles.  Follow pod_role.py's posture for an
    # invalid role value: warn loudly and fall back to the FIRST-established
    # mode (published-api) rather than refusing to boot — a mode misconfig
    # must not take the pod down, but it must never go unnoticed either.
    logger.warning(
        "QUERYSTUDIO_REPORTS_MODE and QUERYSTUDIO_PUBLISHED_API_MODE are BOTH "
        "set — they are mutually exclusive pod roles.  Ignoring REPORTS_MODE; "
        "this pod boots as published-api.  Fix the deployment env."
    )
    _REPORTS_MODE = False

# Phase 75: Published Views API — registered in full AND published-api modes
# (it is the entire point of the published-api pod).  NOT in reports mode:
# the consumer-facing /api/v1/* surface has its own dedicated pod, and the
# BR-over-PV execution path calls published_views_api._execute_view as an
# in-process FUNCTION (business_reports_api.py) — its dependencies are wired
# in _startup() regardless of which routers are mounted, so excluding the
# router loses nothing.
if not _REPORTS_MODE and not _DOWNLOADS_MODE:
    app.include_router(published_views_router, tags=["published-views"])

# ── system_router is registered in EVERY mode ────────────────────────────────
# 2026-08-09: it used to live only inside the full-API branch, so in
# published-api mode /health, /health/live, /health/ready and /metrics were
# NEVER REGISTERED — yet Dockerfile.published-api's HEALTHCHECK targets
# /health/live and the chart's liveness, readiness AND startup probes all
# target /health (k8s/querystudioapi-helm/published-api/values.yaml:34-36).
# A startupProbe with failureThreshold 30 at 10s means the published-api pod
# could never become ready: it CrashLoopBackOffs forever.  The ServiceMonitor
# scrapes /metrics, also 404.  Verified by importing main in that mode and
# listing app.routes.
#
# Health is infrastructure, not surface area, so it belongs to every mode
# rather than being repeated per branch — one registration, no branch can
# forget it again.  (/api/admin/diagnostics in this router was
# unauthenticated; it was gated in the same change, so registering the router
# more widely does not widen disclosure.)
app.include_router(system_router)

# ── Download Centre — full API mode, and the dedicated pod ───────────────
# In _DOWNLOADS_MODE this and system_router are the ONLY routers mounted:
# nine paths plus health/metrics.  Query execution, the grid, admin and
# reports all stay off this pod — that is the entire point of the split.
# Not in reports/published-api mode: those pods never served /api/downloads
# (the paths lived in routers they do not mount), so mounting it there
# would WIDEN their surface rather than preserve it.  Registering it here,
# beside system_router, keeps the one-registration-per-surface shape that
# stopped published-api from silently losing /health.
if not _REPORTS_MODE and not _PUBLISHED_API_MODE:
    app.include_router(downloads_router, tags=["downloads"])

if _REPORTS_MODE:
    # ── Reports pod router set (traced from the code, not guessed) ─────────
    # INCLUDED:
    #   system_router            — /health, /health/live, /health/ready
    #                              (kubelet probes), /metrics (Prometheus —
    #                              carries the worker_pool_active_tasks /
    #                              worker_pool_queued_tasks gauges the reports
    #                              HPA scales on), /api/version.
    #   datasets_router          — the semantic layer business reports are
    #                              DEFINED against: dataset/columns/
    #                              hierarchies/conditions/metrics/merged-
    #                              dimensions reads (viewer + builder derive
    #                              drill semantics from these rows) and
    #                              /api/datasets/{id}/column-values (cascading
    #                              parameter/slicer LOVs).
    #   business_reports_router  — the product surface itself: CRUD, execute
    #                              + execute-async, execution status/result,
    #                              paged results, /results/{exec}/cube
    #                              (microcube drill), /instances (serve-from-
    #                              cache opens), PDF/Excel/CSV downloads,
    #                              parameters + parameter-values, share/embed
    #                              tokens + token execute/downloads,
    #                              permissions, admin BR config.
    #   report_comments_router   — mounted because its routes live UNDER
    #                              /api/business-reports/{id}/comments and
    #                              /change-history: any ingress rule that
    #                              routes /api/business-reports/* to this pod
    #                              would 404 the viewer's comment panel if
    #                              this router stayed behind on the API pod.
    #   subscription_router      — subscribe: /api/subscriptions CRUD, pause/
    #                              resume/test-send/history, /api/unsubscribe
    #                              token, admin delivery config.
    # EXCLUDED (and why it is safe):
    #   published_views_router / graphql — consumer surface; own pod (above).
    #   auth_router              — sessions are DB-backed (BF-408,
    #                              core/sessions.set_db_manager below), so
    #                              this pod VALIDATES session cookies via
    #                              api/deps.init_deps without hosting
    #                              /api/auth/*; login/logout/OIDC stay on the
    #                              API pod behind the existing ingress.
    #   pdf/burst/enterprise/catalog/portal — report-keyed enterprise
    #                              surfaces (pdf-config, bursting, bookmarks,
    #                              alerts, catalog) stay on the API pod; the
    #                              BR raw_sql path calls reports_api._run_
    #                              parquet_report/_run_sql_report as in-process
    #                              functions (FB-60: that module has no router).
    #   data_grid/sql/sql_tools/execute/stream/arrow/queries/connections/
    #   mv/local_tables/suggest  — query-builder + ad-hoc execution surfaces.
    #   admin/s3_readers/logical_tables/row_security/agents/notifications/
    #   schedules/dashboards/workspaces/lineage/profiles/jobs/feed/
    #   reconciliation/etl_pipeline/federation_views/metadata_catalog/
    #   data_quality/user_prefs/sql_files/user_drafts/dataflow/sap/worker —
    #                              admin, brain, ETL, dataflow, orchestration:
    #                              none are on the report execute/retrieve/
    #                              drill/export/subscribe path.  (The BR
    #                              federation_view source calls
    #                              federation_views_api.execute_federation_view
    #                              as an in-process function — router not
    #                              needed.)
    # (system_router is registered above, in every mode.)
    app.include_router(datasets_router, tags=["semantic-layer"])
    app.include_router(business_reports_router, tags=["business-reports"])
    app.include_router(report_readiness_router, tags=["report-readiness"])
    app.include_router(report_comments_router, tags=["collaboration"])
    app.include_router(report_signoff_router, tags=["collaboration"])
    app.include_router(canvas_actions_router, tags=["business-reports"])
    app.include_router(report_themes_router, tags=["report-themes"])
    app.include_router(report_templates_router, tags=["report-templates"])
    app.include_router(report_parameter_templates_router, tags=["report-parameter-templates"])
    app.include_router(report_diagnostics_router, tags=["report-diagnostics"])
    app.include_router(report_data_versions_router, tags=["business-reports"])
    app.include_router(report_business_day_router, tags=["business-reports"])
    app.include_router(subscription_router, tags=["delivery"])
elif not _PUBLISHED_API_MODE and not _DOWNLOADS_MODE:
    # Full API mode — register all other routers
    app.include_router(data_grid_router,   tags=["queries"])
    app.include_router(sql_router,          tags=["queries"])
    app.include_router(sql_tools_router,    tags=["queries"])  # Phase 139 honest-fix: format/split/to-visual
    app.include_router(catalog_router,      tags=["reports"])
    app.include_router(portal_router,      tags=["portal"])
    app.include_router(schedules_router,    tags=["schedules"])
    app.include_router(dashboards_router,   tags=["dashboards"])
    app.include_router(enterprise_router,   tags=["reports"])
    app.include_router(pdf_router,          tags=["reports"])
    app.include_router(burst_router,        tags=["reports"])
    app.include_router(profiles_router,     tags=["queries"])
    app.include_router(report_connectors_router, tags=["reports"])
    app.include_router(workspaces_router,   tags=["workspaces"])
    app.include_router(lineage_router,      tags=["lineage"])
    app.include_router(report_usage_router, tags=["report-usage"])
    app.include_router(auth_router)
    app.include_router(notifications_router)
    # (system_router is registered above, in every mode.)
    app.include_router(admin_router)
    app.include_router(s3_readers_router, tags=["admin", "s3-readers"])  # BF-428G
    app.include_router(logical_tables_router, tags=["admin", "logical-tables"])  # Phase 146-B
    app.include_router(logical_tables_pv_router, tags=["admin", "logical-tables"])  # Phase 146-C
    app.include_router(connections_router)
    app.include_router(queries_router)
    app.include_router(mv_router)
    app.include_router(local_tables_router)
    app.include_router(arrow_router)
    app.include_router(suggest_router, tags=["intelligence"])
    app.include_router(datasets_router, tags=["semantic-layer"])
    app.include_router(business_reports_router, tags=["business-reports"])
    app.include_router(report_readiness_router, tags=["report-readiness"])
    app.include_router(subscription_router, tags=["delivery"])
    app.include_router(stream_router, tags=["streaming"])
    app.include_router(execute_router, tags=["execution"])
    app.include_router(jobs_router, tags=["jobs"])         # Industrialization Phase 2 (flag-gated)
    app.include_router(feed_router, tags=["feeds"])
    app.include_router(governance_router, tags=["governance"])
    app.include_router(config_active_router, tags=["governance"])
    app.include_router(run_surface_router, tags=["run-surface"])
    app.include_router(feed_ops_router, tags=["feed-ops"])
    app.include_router(date_tokens_router, tags=["date-tokens"])
    app.include_router(feed_group_router, tags=["feed-groups"])
    app.include_router(feed_versions_router, tags=["feed-versions"])
    app.include_router(feed_close_out_router, tags=["feed-close-out"])
    app.include_router(feed_template_router, tags=["feed-templates"])
    app.include_router(feed_consumer_router, tags=["my-feeds"])
    app.include_router(feed_variance_hold_router, tags=["feed-variance-holds"])
    app.include_router(feed_dashboard_router, tags=["feed-dashboard"])
    # 2026-10-17 -- the published-API INVENTORY (core/published_api/):
    # /api/published-apis, lifecycle, impact, a key's identity
    from api.published_api_api import router as published_api_router
    app.include_router(published_api_router, tags=["published-apis"])
    app.include_router(feed_steps_router, tags=["feed-steps"])
    app.include_router(feed_sftp_router, tags=["feeds"])
    app.include_router(feed_schedule_preview_router, tags=["feeds"])
    app.include_router(feed_daemons_router, tags=["feed-daemons"])
    app.include_router(admin_posture_router, tags=["posture"])
    app.include_router(component_health_router, tags=["component-health"])
    app.include_router(reconciliation_router, tags=["reconciliation"])
    app.include_router(etl_pipeline_router, tags=["etl-pipelines"])
    app.include_router(federation_views_router, tags=["federation-views"])
    app.include_router(metadata_catalog_router, tags=["metadata-catalog"])
    app.include_router(data_quality_router, tags=["data-quality"])
    app.include_router(report_comments_router, tags=["collaboration"])
    app.include_router(report_signoff_router, tags=["collaboration"])
    app.include_router(canvas_actions_router, tags=["business-reports"])
    app.include_router(report_themes_router, tags=["report-themes"])
    app.include_router(report_templates_router, tags=["report-templates"])
    app.include_router(report_parameter_templates_router, tags=["report-parameter-templates"])
    app.include_router(report_diagnostics_router, tags=["report-diagnostics"])
    app.include_router(report_data_versions_router, tags=["business-reports"])
    app.include_router(report_business_day_router, tags=["business-reports"])
    app.include_router(user_prefs_router, tags=["user-preferences"])
    app.include_router(agents_router, tags=["agents"])
    app.include_router(sql_files_router, tags=["sql-files"])
    app.include_router(row_security_router, tags=["row-security"])
    app.include_router(entitlement_router, tags=["row-security"])
    app.include_router(entitlement_me_router, tags=["row-security"])
    app.include_router(tool_entitlement_me_router, tags=["tool-entitlement"])
    app.include_router(value_lists_router, tags=["value-lists"])
    app.include_router(user_drafts_router, tags=["user-drafts"])
    app.include_router(dataflow_router, tags=["dataflows"])
    app.include_router(clockwork_router, tags=["clockwork"])
    # Phase 132.29 — SAP task config CRUD (Airflow standalone runner
    # reads from this table via core.sap_task_loader).
    try:
        from api.sap_tasks_api import router as sap_tasks_router
        app.include_router(sap_tasks_router, tags=["sap-tasks"])
    except Exception as _sap_exc:
        logger.warning("[main] sap_tasks_api not mounted: %s", _sap_exc)
    # Phase 132.33 — live SAP-OData passthrough endpoints.
    try:
        from api.sap_passthrough_api import router as sap_passthrough_router
        app.include_router(sap_passthrough_router, tags=["sap-passthrough"])
    except Exception as _spt_exc:
        logger.warning("[main] sap_passthrough_api not mounted: %s", _spt_exc)
    # BF-384 (Option G) — worker pod endpoints (run-chunk, health, stats).
    # Mounted on every node so a coordinator can dispatch to itself in
    # single-pod dev mode AND so worker pods serve their inbound endpoints.
    try:
        from api.worker_node_api import router as worker_node_router
        app.include_router(worker_node_router, tags=["worker"])
    except Exception as _wn_err:
        logger.debug("Worker node router mount skipped: %s", _wn_err)

# Phase 22F + Phase 133-K: GraphQL endpoint (optional).  Mounted in BOTH
# full and published-api modes because the publishedViewData resolver is the
# consumer-facing entry point that Published API users care about — same
# enterprise hardening as REST (auth, rate limit, cache, audit log).  The
# executeQuery mutation refuses with a structured error in published-api mode
# (see graphql_api.py) since arbitrary SQL execution isn't a consumer concern.
# NOT mounted in reports mode (2026-08-09): /graphql is a Published-Views
# consumer surface — nothing on the report execute/retrieve/drill path uses it.
if _graphql_available and not _REPORTS_MODE:
    try:
        _gql_router = get_graphql_router()
        app.include_router(_gql_router, tags=["graphql"])   # it carries /graphql (and /graphql/)
        logger.info(
            "GraphQL endpoint enabled at /graphql (published_api_mode=%s)",
            _PUBLISHED_API_MODE,
        )
    except Exception as _gql_exc:
        # 2026-10-24 -- LOUD: this was DEBUG, and a schema Strawberry refused
        # left /graphql absent on every pod with nothing in the log (rig).
        logger.error("GraphQL endpoint NOT mounted -- /graphql will answer 404: %s", _gql_exc)

# ── Literal routes must be matched before parametrised ones ────────────────
# 2026-08-25.  Starlette returns on the FIRST match, so a literal path declared
# AFTER a parametrised sibling is unreachable: the request is served by the
# parametrised handler with the literal segment as its "id".  Eight endpoints
# were dead this way — /api/queries/folders and /tags, /api/published-views/
# export-all and /webhooks, /api/dataflows/schedules and /custom-stage-types,
# /api/local-tables/excel-sheets, /api/datasets/federation/execute — plus
# /api/executions/active, whose literal and parametrised halves live in
# DIFFERENT routers nine includes apart, so no per-module ordering could fix it.
#
# The rule was already known here (datasets_api.py: "static path ... MUST appear
# before /{dataset_id}"), but it was enforced by whoever remembered it while
# adding a route.  This enforces it once, for every router, at assembly.
#
# Stable sort on the number of path parameters:
#   * a literal and a parametrised route only compete when both could match the
#     same request, and there the literal is always the intended handler;
#   * stability preserves relative order within each group;
#   * routes with different segment counts never compete at all.
#
# Deliberately placed AFTER every include_router and BEFORE the SPA catch-all
# ``/{full_path:path}`` is registered further down — that one genuinely must be
# last, and it does not exist yet at this point.
def _prioritise_literal_routes(_app) -> int:
    """Reorder the assembled route table so literals win. Returns how many
    routes moved, for the startup log. Fail-open: a sort error must never stop
    the app from booting."""
    try:
        _before = [getattr(r, "path", "") for r in _app.router.routes]
        _app.router.routes.sort(key=lambda r: getattr(r, "path", "").count("{"))
        _after = [getattr(r, "path", "") for r in _app.router.routes]
        return sum(1 for a, b in zip(_before, _after) if a != b)
    except Exception as _exc:      # pragma: no cover - defensive
        logger.warning("route prioritisation skipped (%s); literal routes may "
                       "be shadowed by parametrised ones", _exc)
        return 0


_moved = _prioritise_literal_routes(app)
if _moved:
    logger.info("Route table ordered: %d route(s) repositioned so literal "
                "paths are matched before parametrised ones", _moved)


if _PUBLISHED_API_MODE:
    logger.info("Published API mode — only /api/v1/*, /graphql, and /health endpoints registered")

if _REPORTS_MODE:
    logger.info(
        "Reports pod mode — only /api/business-reports/*, /api/datasets/*, "
        "/api/subscriptions/*, and /health + /metrics endpoints registered"
    )

# Initialize S3 config from environment (legacy global S3 bucket, if set)
s3_config = None
if os.getenv('S3_BUCKET_NAME'):
    s3_config = S3Config(
        bucket_name=os.getenv('S3_BUCKET_NAME'),
        region_name=os.getenv('S3_REGION', _s3_cfg.default_region),
        auth_mode=os.getenv('S3_AUTH_MODE', 'keys'),
        aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
        aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY'),
        aws_profile=os.getenv('AWS_PROFILE'),
        role_arn=os.getenv('AWS_ROLE_ARN'),
        endpoint_url=os.getenv('S3_ENDPOINT_URL'),
        ssl_verify=os.getenv('S3_SSL_VERIFY', 'true').lower() != 'false',
    )

# Initialize components
engine = ParquetQueryEngine(
    base_path=str(_paths.parquet_dir),
    chunk_size=_qe_cfg.chunk_size,
    s3_config=s3_config
)
db_manager = DatabaseManager(db_url=_DB_URL)
# BF-393: publish the singleton so worker pods / background jobs / scheduled
# tasks can resolve a DB handle via core.database.get_db_manager().  Without
# this, each call site instantiates its own DatabaseManager → N connection
# pools to the same DB.
try:
    from core.database import set_db_manager
    set_db_manager(db_manager)
except Exception as _sdm_err:
    logger.warning("set_db_manager() failed: %s", _sdm_err)
ws_manager = WebSocketManager()
conn_manager = ConnManager(db_manager)

# BF-408: wire DB manager into the session store so sessions persist
# across uvicorn worker processes and survive backend restarts.  This
# unblocks ``workers > 1`` in config (single uvicorn worker is the
# root cause of "backend api unavailable" when one request hangs).
try:
    from core.sessions import set_db_manager as _sessions_set_db
    _sessions_set_db(db_manager)
except Exception as _sess_di_err:
    import logging as _li
    _li.getLogger(__name__).warning(
        "BF-408 sessions.set_db_manager wiring failed (sessions will be "
        "in-memory only, multi-worker WILL break): %s", _sess_di_err,
    )
# BF-278 / BF-282: register process-wide singleton so background
# helpers (iceberg_reader, duckdb_views pre-download path) can
# invalidate cached S3 handlers on ExpiredToken without a circular
# import on api.connections_api.
from core.connection_manager import set_connection_manager as _set_global_cm  # noqa: E402
_set_global_cm(conn_manager)

# 2026-06-30 strategic hoist: track_bg_task is used in 6 startup paths.
# Single top-level import + alias instead of 6 inline imports inside
# `try:` blocks (was patched in the first wave; now consolidated to
# match the single-chokepoint pattern other strategic imports follow).
from core.bg_tasks import track_bg_task as _qs_track_bg  # noqa: E402

# Phase 87: Initialize credential manager for auto-credential fetch
from core.credential_manager import CredentialManager as _CredMgrCls, set_credential_manager as _set_cm  # noqa: E402
_cred_manager = _CredMgrCls(db_manager)
_set_cm(_cred_manager)

# ── Notification logging helper ─────────────────────────────────────────────
def _log_ws_notification(event_type: str, recipient: str, title: str,
                         message: str = "", execution_id: str = None,
                         schedule_id: int = None, payload: dict = None):
    """Persist a WebSocket notification to DB for history / bell icon."""
    try:
        db_manager.log_notification(
            event_type=event_type,
            channel="websocket",
            recipient=recipient,
            status="sent",
            title=title,
            message=message,
            payload=payload,
            execution_id=execution_id,
            schedule_id=schedule_id,
        )
    except Exception as exc:
        logger.debug("Failed to log notification: %s", exc)


# Per-execution cancellation registry (used by shutdown handler)
import threading as _threading  # noqa: E402
_running_tasks:      dict = {}   # execution_id → asyncio.Task
_cancellation_flags: dict = {}   # execution_id → threading.Event

# Per-user concurrency + in-flight dedup — moved to api/execute_api.py

# Global concurrency gate — asyncio.Semaphore limits system-wide active queries.
#
# 2026-08-02 FLEET SCOPE: this semaphore (and the load-shed counter behind
# core.executors.concurrency.global_refusal) is PER-POD state — with N
# replicas it admits N x max_concurrent_global.  When
# ``industrialization.fleet_admission`` is armed, the AUTHORITATIVE global
# and per-user caps are enforced fleet-wide in Postgres by
# core.jobqueue.fleet_admission (wired through QueueManager.acquire_slot
# and the worker-pool per-type admission); this per-pod gate then remains
# deliberately in place as the LOCAL BACKSTOP — the bound a single pod
# still enforces on itself when the DB is degraded and the fleet gate
# fails open.  Flag OFF (default): sole enforcement, exactly as before.
import asyncio as _asyncio  # noqa: E402
_global_query_sem: _asyncio.Semaphore | None = None   # initialised at startup

def _init_query_semaphore():
    global _global_query_sem
    # 0 = UNLIMITED product-wide.  Semaphore(0) here would wedge EVERY query
    # in the pod on the first request — the widest blast radius of the five
    # sites this fix has had to reach.
    from core.concurrency_permits import sem_permits as _sem_permits
    _global_query_sem = _asyncio.Semaphore(_sem_permits(
        _qe_cfg.max_concurrent_global, name="query_engine.global"))
    try:
        from core.industrialization import is_enabled as _fleet_adm_on
        if _fleet_adm_on("fleet_admission"):
            logger.info(
                "[fleet-admission] ARMED — query_engine.max_concurrent_global"
                "=%d and max_concurrent_per_user=%d are enforced FLEET-WIDE "
                "via the PG slot gate; this pod's semaphore/load-shed acts "
                "as a local backstop only",
                _qe_cfg.max_concurrent_global, _qe_cfg.max_concurrent_per_user)
    except Exception as _fa_exc:
        logger.debug("[fleet-admission] arming probe failed (flag treated "
                     "as OFF): %s", _fa_exc)

# 2026-08-20 — the deferred lifespan migration, done.  All FIVE startup
# handlers, the shutdown handler, and the two in main_with_s3.py moved in one
# change, in order, to the registry declared above the app.  The reason it had
# to be atomic turned out to be sharper than "piecemeal is risky": a handler
# left on @app.on_event after lifespan= is set does not warn, it just never
# runs.
@_hooks.startup
async def _startup_init_semaphore():
    _init_query_semaphore()


@_hooks.startup
async def _startup_prewarm_boto3():
    """2026-07-22 — pre-warm botocore's service-model load in a BACKGROUND thread.

    The FIRST ``session.client('s3')`` in a process synchronously scans +
    JSON-loads botocore's service data (``list_available_services`` /
    ``_load_service_model``).  On a slow / NFS site-packages mount that first
    build can block for TENS OF SECONDS; when it lands inline on the request
    path it froze the event loop (watchdog: MainThread stuck in
    ``list_available_services``, 46s+).  Warming it ONCE here — off-thread, so it
    never blocks startup or the loop, with DUMMY creds so it can't stall on the
    credential provider chain (IMDS) — loads the s3 model into the OS cache so
    every subsequent client build (on-prem OR AWS) is fast.  Fail-safe.

    R12 (2026-07-22): warm through a PRIVATE ``Session()`` — NOT the module-level
    ``boto3.client`` shortcut, which lazily creates + mutates the shared DEFAULT
    session and could race a concurrent real ``boto3.client()`` during the
    startup window.  The costly work (botocore's service-model load) populates
    the PROCESS-GLOBAL loader cache regardless of which session triggers it, so
    a private session gives the identical warm-up with zero shared state."""
    import threading as _th

    def _warm():
        try:
            import boto3 as _b3
            # Private session — does not touch boto3's shared default session.
            _b3.session.Session().client(
                "s3", region_name="us-east-1",
                aws_access_key_id="prewarm", aws_secret_access_key="prewarm",
            )
        except Exception:
            pass

    try:
        _th.Thread(target=_warm, name="boto3-prewarm", daemon=True).start()
    except Exception:
        pass


@_hooks.startup
async def _startup_install_brain_log_capture():
    """Phase Z.7 (2026-06-09) — attach the brain log capture handler.
    User feedback: 'query diagnose UI still missing such logs ... no
    use of'.  Mirror brain-narrative log lines into a per-execution
    buffer so /diagnose/{id} can show the operator EXACTLY what the
    brain did, in order, without grepping server logs."""
    try:
        from core.brain.log_capture import install as _install_brain_log_capture
        _install_brain_log_capture()
    except Exception as exc:
        # Capture failure must NOT block server startup.
        import logging as _logging
        _logging.getLogger("main").warning(
            "BrainLogCapture install failed (diagnose UI will lack "
            "brain log narrative): %s", exc,
        )


# ── BF-403 — Startup diagnostic banner ───────────────────────────────────────
# Single multi-line INFO block emitted right after the server starts listening.
# Gives ops a one-shot "is this deployment healthy?" snapshot.  Strictly NO
# credentials / secrets logged — only enabled flags and shapes.
@_hooks.startup
async def _startup_banner():
    try:
        from core.config import server as _srv, paths as _paths_cfg
        # Count tables in the DB (sanity check that migrations ran).
        # BF-407: also explicitly verify critical tables exist + log any
        # missing — failing system_accounts/published_views/connections
        # tables are the #1 cause of opaque OperationalErrors in prod.
        _table_count = "?"
        _db_path = "?"
        _db_type = "?"
        _critical_missing = []
        _CRITICAL_TABLES = (
            "connections", "published_views", "system_accounts",
            "user_sessions", "audit_log",
        )
        try:
            # 2026-06-14 — was reading _srv.database_type (which doesn't
            # exist on _ServerCfg) → getattr always returned None → defaulted
            # to "sqlite", checked a stale SQLite path, reported false-
            # positive missing tables on Postgres deploys.  Read from the
            # actual database config (which honours QUERYSTUDIO_DATABASE_TYPE
            # env var as of the env-only-deploy fix).
            from core.config import database as _db_cfg
            _db_type = (_db_cfg.type or "sqlite").lower()

            if _db_type == "sqlite":
                from pathlib import Path as _P
                for _cand in (_paths_cfg.data_dir / "parquet_query_engine.db",
                              _paths_cfg.data_dir / "querystudio.db"):
                    if _cand.exists():
                        _db_path = str(_cand)
                        import sqlite3 as _sq
                        _c = _sq.connect(str(_cand))
                        _table_count = _c.execute(
                            "SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
                        ).fetchone()[0]
                        _existing = {row[0] for row in _c.execute(
                            "SELECT name FROM sqlite_master WHERE type='table'"
                        )}
                        _critical_missing = [t for t in _CRITICAL_TABLES if t not in _existing]
                        _c.close()
                        break
            elif _db_type == "postgresql":
                # Query the live Postgres DB through SQLAlchemy so we hit
                # the same backend the app uses (avoids drift between the
                # banner check and the actual runtime engine).
                try:
                    from sqlalchemy import inspect as _sa_inspect
                    _eng = db_manager.engine  # already initialised by now
                    _insp = _sa_inspect(_eng)
                    _all_tables = _insp.get_table_names()
                    _table_count = len(_all_tables)
                    _db_path = f"{_eng.url.host}:{_eng.url.port or 5432}/{_eng.url.database}"
                    _existing = set(_all_tables)
                    _critical_missing = [t for t in _CRITICAL_TABLES if t not in _existing]
                except Exception as _pg_err:
                    logger.debug("[startup-banner] PG inspect failed: %s", _pg_err)
            elif _db_type == "oracle":
                try:
                    from sqlalchemy import inspect as _sa_inspect
                    _eng = db_manager.engine
                    _insp = _sa_inspect(_eng)
                    _all_tables = _insp.get_table_names()
                    _table_count = len(_all_tables)
                    _db_path = f"oracle://{_eng.url.host or '<dsn>'}"
                    _existing = set(_all_tables)
                    _critical_missing = [t for t in _CRITICAL_TABLES if t not in _existing]
                except Exception as _or_err:
                    logger.debug("[startup-banner] Oracle inspect failed: %s", _or_err)
        except Exception as _db_err:
            logger.debug("[startup-banner] DB sanity check skipped: %s", _db_err)
        if _critical_missing:
            logger.error(
                "[STARTUP] CRITICAL — these expected tables are MISSING from %s: %s. "
                "Migrations did not complete.  Operations on these features "
                "will throw OperationalError.",
                _db_type, _critical_missing,
            )

        # Mounted route count (quick "did all routers register?" smoke)
        _route_count = len(app.routes)

        # Optional features — just enabled flags, no values
        _feat = {}
        for _section, _key in [
            ("result_cache", "enabled"),
            ("multi_worker", "enabled"),
            ("multi_pod", "enabled"),
            ("spark_connect", "enabled"),
            ("row_security", "enabled"),
            ("agents", "enabled"),
            ("iceberg_writer", "enabled"),
            ("backup", "enabled"),
        ]:
            try:
                from core.config import get_section as _gs
                _feat[_section] = bool((_gs(_section) or {}).get(_key, False))
            except Exception:
                _feat[_section] = "?"

        # CORS — origins only, no headers/credentials
        try:
            _cors_origins = list(_cors_cfg.allow_origins or [])
        except Exception:
            _cors_origins = ["?"]

        # Build the banner — multi-line, prefixed for easy grep ([STARTUP])
        _banner = [
            "═════════════════════════════════════════════════════════════════",
            " QueryStudio API ready",
            f"   version    = {API_VERSION}",
            f"   db.type    = {_db_type}",
            f"   db.path    = {_db_path}",
            f"   db.tables  = {_table_count}",
            f"   routes     = {_route_count}",
            f"   log.level  = {logging.getLevelName(logging.root.level)}",
            f"   log.format = {getattr(_srv, 'log_format', '?')}",
            f"   log.file   = {getattr(_srv, 'log_file', '') or '(stdout only)'}",
            f"   cors       = {_cors_origins}",
            "   features   = " + ", ".join(f"{k}={'on' if v is True else 'off' if v is False else v}"
                                            for k, v in _feat.items()),
            "═════════════════════════════════════════════════════════════════",
        ]
        for line in _banner:
            logger.info("[STARTUP] %s", line)
    except Exception as exc:
        logger.warning("[startup-banner] failed to emit banner: %s", exc, exc_info=True)


# ── Active Directory / Auth helpers ───────────────────────────────────────────

from api.models.query_models import LoginRequest as _LoginRequest  # noqa: E402


# ── Server-side session store (in-memory, TTL-based) ─────────────────────────
# Stores opaque tokens → user info so that AD/LDAP passwords are NEVER persisted
# or sent after the initial login.

# ── Session management — delegates to core/sessions.py (single source of truth) ──
from core.sessions import create_session as _core_create_session  # noqa: E402
from core.sessions import get_session as _core_get_session  # noqa: E402
from core.sessions import destroy_session as _core_destroy_session  # noqa: E402


def _create_session(user_info: dict) -> str:
    """Create a session token and store user info server-side."""
    return _core_create_session(user_info)


def _get_session(token: str) -> Optional[dict]:
    """Look up a session token. Returns user info or None if expired/missing."""
    return _core_get_session(token)


def _destroy_session(token: str):
    """Remove a session token (logout)."""
    _core_destroy_session(token)


def _get_current_user(request: Request) -> Optional[dict]:
    """
    Extract and validate the caller's identity.
    - auth.type = "none"  → always returns a guest admin (no login required)
    - "Bearer <session_token>" → look up server-side session (preferred)
    - "Basic <base64>" → authenticate directly (fallback / backward compat)
    Returns the user-info dict or raises 401.
    """
    if _auth_cfg.type == "none":
        return {"username": "guest", "display_name": "Guest", "is_admin": True,
                "groups": [], "role": "admin"}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")

    # Prefer session tokens — no password stored or transmitted after login
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]
        user = _core_get_session(token)
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user

    # Fallback: Basic auth (used by legacy clients / API testing)
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return user


# Note: legacy _require_admin / _require_role / _require_execute_access
# helpers were removed — the canonical implementations live in
# api/deps.py (require_admin, require_role, require_execute_access) and
# every router imports from there. main.py kept dead duplicates that had
# to be patched in lock-step (Phase 107 audit) and were a known source
# of drift. They are now gone.


def _is_owner_or_shared(item: dict, user: dict) -> bool:
    """True if the user owns this item or it's marked as shared."""
    from core.roles import is_admin_like
    if not user or is_admin_like(user):
        return True  # admins see everything
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
        or item.get("is_public", False)
    )


def _is_container_env() -> bool:
    """Detect if running inside Docker/OpenShift/Kubernetes."""
    return (
        os.path.exists("/.dockerenv")
        or os.environ.get("KUBERNETES_SERVICE_HOST") is not None
        or os.environ.get("QUERYSTUDIO_UPLOAD_ENABLED") == "true"
    )


# Pydantic Models — extracted to api/models/query_models.py
from api.models.query_models import (  # noqa: E402
    ALL_CONN_TYPES as _ALL_CONN_TYPES,
    S3ConfigModel, JoinConfigModel, FilterModel, OrderByModel,
    AggregationModel, HavingModel, ComputedColumnModel,
    CaseWhenClauseModel, CaseExpressionModel, WindowFunctionModel,
    QueryConfigModel, SaveQueryRequest, ExecuteQueryRequest,
    ConnectionConfigModel, ConnectionTestRequest,
    StreamQueryRequest, StreamPaginateRequest, StreamSchemaRequest,
    StreamChartRequest, StreamPivotRequest, EstimateRequest,
    PreviewSqlRequest, JoinPreviewRequest,
    BatchQueryItem, BatchSubmitRequest,
    WorkerPoolConfigUpdate, AppConfigUpdateRequest, QueueConfigUpdateRequest,
    CacheInvalidateSourceRequest, RegisteredTableModel,
    MaterializedViewCreateModel, MaterializedViewUpdateModel,
    LocalTableCreateModel, LocalTableUpdateModel, LocalTablePromoteModel,
    UpdateQueryRequest, ShareQueryRequest, ShareDashboardRequest,
    SubjectExportRequest as _SubjectExportRequest,
    UserPayload as _UserPayload,
)

# Helper functions
# build_s3_config is imported from core.s3_storage — single source of truth


# Query conversion — extracted to core/query_converter.py
from core.query_converter import (  # noqa: E402
    convert_query_config_to_engine,
    translate_join_columns as _translate_join_columns,
    rewrite_registered_refs as _rewrite_registered_refs,
)


# ── Iceberg / schema / partition caches — extracted to core/iceberg_cache.py ──
from core.iceberg_cache import (  # noqa: E402
    ICE_FILE_CACHE as _ICE_FILE_CACHE,
    ICE_FILE_CACHE_TTL as _ICE_FILE_CACHE_TTL,
    ice_cache_key as _ice_cache_key,
    ice_cache_get as _ice_cache_get,
    ice_cache_set as _ice_cache_set,
    schema_cache_get as _schema_cache_get,
    schema_cache_set as _schema_cache_set,
    partition_l1_get as _partition_l1_get,
    partition_l1_set as _partition_l1_set,
    partition_l2_get as _partition_l2_get,
    partition_store as _partition_store,
    init_iceberg_cache,
)


# ── DuckDB views — extracted to core/duckdb_views.py ─────────────────────────
from core.duckdb_views import (  # noqa: E402
    SQLCollector as _SQLCollector,
    setup_registered_views as _setup_registered_views,
    execute_registered_table_query as _execute_registered_table_query,
    execute_registered_table_copy_to as _execute_registered_table_copy_to,
    s3_full_copy as _s3_full_copy,
    join_inflight_query as _join_inflight_query,
    run_base_data_local_query as _run_base_data_local_query,
    init_duckdb_views,
)



# ── Old function bodies removed — now in core/duckdb_views.py ─────────────

# ── Execute background workers + endpoints — extracted to api/execute_api.py ──
# _run_query_and_signal, execute_query_background, execute_sql_connector_background,
# execute_cross_query_background, _audit, estimate_query, execute_query
# ── SPA static file serving ───────────────────────────────────────────────────
_STATIC_CANDIDATES = [
    Path(__file__).resolve().parent / "static",          # Docker / production
    Path(__file__).resolve().parent.parent / "frontend" / "build",  # local dev
    Path(__file__).resolve().parent.parent / "frontend" / "dist",   # legacy Vite
]
_STATIC_DIR: Optional[Path] = next((p for p in _STATIC_CANDIDATES if p.is_dir()), None)

if _STATIC_DIR:
    from fastapi.staticfiles import StaticFiles
    # Mount /assets (hashed JS/CSS bundles) — short cache for CDN
    _assets = _STATIC_DIR / "assets"
    if _assets.is_dir():
        app.mount("/assets", StaticFiles(directory=str(_assets)), name="assets")
    # BF-397 (revised) — docs live under the FRONTEND now
    # (frontend/public/docs/ → built into static/docs/).  When the API
    # serves the SPA bundle itself (monolithic Dockerfile), mount /docs
    # so the SPA catch-all below doesn't swallow doc requests.  In the
    # split deploy (Dockerfile.api + Dockerfile.ui), the UI container's
    # `serve` already handles /docs/* — this block is a no-op there since
    # _STATIC_DIR is absent.
    _docs_static = _STATIC_DIR / "docs"
    if _docs_static.is_dir():
        app.mount("/docs", StaticFiles(directory=str(_docs_static), html=True), name="docs")
        logger.info("Serving docs from %s at /docs", _docs_static)
    logger.info("Serving built frontend from %s", _STATIC_DIR)
else:
    logger.info("No built frontend found — API-only mode (no docs)")


def _dir_stats(path: Path) -> dict:
    """Return file count, total bytes, and oldest/newest mtime for a directory."""
    count = total = 0
    oldest = newest = None
    if path.exists():
        for f in path.rglob("*"):
            if f.is_file():
                try:
                    st = f.stat()
                    count += 1
                    total += st.st_size
                    mt = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
                    if oldest is None or mt < oldest:
                        oldest = mt
                    if newest is None or mt > newest:
                        newest = mt
                except OSError as exc:
                    logger.debug("Recoverable error: %s", exc, exc_info=True)
    return {
        "path": str(path),
        "file_count": count,
        "size_bytes": total,
        "size_mb": round(total / (1024 * 1024), 2),
        "oldest_file": oldest.isoformat() if oldest else None,
        "newest_file": newest.isoformat() if newest else None,
    }


def _oldest_age_secs(tasks: list) -> float:
    """Return age in seconds of oldest task by created_at."""
    from datetime import datetime, timezone
    oldest = None
    for t in tasks:
        ca = t.get("created_at")
        if not ca:
            continue
        try:
            dt = datetime.fromisoformat(ca)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            if oldest is None or dt < oldest:
                oldest = dt
        except Exception:
            pass
    if oldest is None:
        return 0.0
    now = datetime.now(timezone.utc)
    return (now - oldest).total_seconds()



# ── Batch Submit API (19H) ────────────────────────────────────────────────────

async def _scheduler_worker_proxy(method: str, path: str, json_body=None, timeout: float = 10.0):
    """Proxy a request to the scheduler worker's internal HTTP API.

    Used when ``scheduler.mode = "external"`` — the scheduler runs in a
    separate process (``scheduler_worker.py``) and exposes a small FastAPI
    control API on ``scheduler.worker_host:scheduler.worker_port``.
    """
    import httpx
    from core.config import scheduler as _sched_cfg
    url = f"{_sched_cfg.worker_url}{path}"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.request(method, url, json=json_body, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
    except httpx.ConnectError:
        raise HTTPException(503, "Scheduler worker is not running or unreachable") from None
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, exc.response.text)
    except Exception as exc:
        raise HTTPException(503, f"Scheduler worker communication failed: {exc}")

_MAX_UPLOAD_SIZE = _limits_cfg.max_upload_size_bytes  # configurable via admin
_ALLOWED_EXTENSIONS = {".parquet", ".csv", ".txt", ".json", ".tsv"}


def _conn_upload_dir(connection_id: int) -> Path:
    """Get the upload directory for a specific connection."""
    d = _paths.upload_dir / str(connection_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


# ── S3 utilities — extracted to core/s3_utilities.py ─────────────────────────
from core.s3_utilities import (  # noqa: E402
    extract_hive_parts as _extract_hive_parts,
    filter_iceberg_files_by_partitions as _filter_iceberg_files_by_partitions,
    extract_partition_filters_from_query as _extract_partition_filters_from_query,
    list_s3_parquet_files as _list_s3_parquet_files,
    s3_urls_to_presigned as _s3_urls_to_presigned,
    make_s3_client_for_conn as _make_s3_client_for_conn,
    get_s3_access_mode as _get_s3_access_mode,
    init_s3_utilities,
)


# ── register_s3_views — extracted to core/duckdb_views.py ─────────────────────
from core.duckdb_views import register_s3_views as _register_s3_views  # noqa: E402


# ─────────────────────────────────────────────────────────────────────────────
# Error detection — extracted to core/error_detection.py
# ─────────────────────────────────────────────────────────────────────────────
from core.error_detection import (  # noqa: E402
    jsonify_value as _jsonify_value,
    jsonify_rows as _jsonify_rows,
    is_s3_auth_error as _is_s3_auth_error,
    raise_if_s3_auth_error as _raise_if_s3_auth_error,
    is_connection_error as _is_connection_error,
    CONN_ERROR_PATTERNS as _CONN_ERROR_PATTERNS,
)

# Streaming endpoints extracted to api/execute_stream_api.py (A3 refactoring)
# _fix_stale_excludes → api/execute_stream_api.py
# _strip_sql_limit → core/query_converter.py as strip_sql_limit




# estimate_query + execute_query endpoints → api/execute_api.py

def _update_config_users(username: str, password: Optional[str], role: Optional[str], action: str):
    """Persist user change to config.json and reload config in-memory.

    Actions:
      add          — add local user (username + hashed password + role)
      update       — update local user (password optional, role required)
      remove       — remove local user entirely
      add_role     — add AD user role mapping (no password)
      update_role  — update AD user role mapping
      remove_role  — remove AD user role mapping
    """
    import json as _json
    config_file = Path(__file__).resolve().parent / "config.json"
    with open(config_file, "r", encoding="utf-8") as f:
        cfg = _json.load(f)

    auth_section = cfg.setdefault("auth", {})

    # Parse current local_users and user_roles
    raw_users = auth_section.get("local_users", "")
    users_dict = {}
    for pair in raw_users.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, p = pair.split(":", 1)
            users_dict[u.strip()] = p.strip()

    raw_roles = auth_section.get("user_roles", "")
    roles_dict = {}
    for pair in raw_roles.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, r = pair.split(":", 1)
            roles_dict[u.strip().lower()] = r.strip().lower()

    from core.ad_auth import hash_password as _hash_pw

    if action == "add":
        users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "update":
        if password:
            users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "remove":
        users_dict.pop(username, None)
        roles_dict.pop(username.lower(), None)
    elif action == "add_role":
        roles_dict[username.lower()] = role
    elif action == "update_role":
        roles_dict[username.lower()] = role
    elif action == "remove_role":
        roles_dict.pop(username.lower(), None)

    auth_section["local_users"] = ",".join(f"{u}:{p}" for u, p in users_dict.items())
    auth_section["user_roles"] = ",".join(f"{u}:{r}" for u, r in roles_dict.items())

    with open(config_file, "w", encoding="utf-8") as f:
        _json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")

    # Reload in-memory config
    from core import config as _config_mod
    _config_mod.reload()
    logger.info("Config reloaded after user %s: %s", action, username)



#: How often the Download Centre pod retires lapsed files.  Matches the
#: scheduler's historical 30-minute cadence, so moving ownership does not
#: silently change how long an expired file lingers on disk.
_DOWNLOADS_RECLAIM_INTERVAL_S = 1800


async def _downloads_reclaim_loop(db_manager):
    """Periodic retention sweep for the Download Centre pod.

    Never raises out of the loop: one bad pass (an unreadable row, an NFS
    blip) must not end reclamation for the life of the pod, which would fill
    the shared volume silently.
    """
    from core.download_retention import reclaim_downloads
    while True:
        try:
            await asyncio.sleep(_DOWNLOADS_RECLAIM_INTERVAL_S)
            await asyncio.to_thread(reclaim_downloads, db_manager)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning("[downloads] retention sweep pass failed "
                           "(retrying next interval): %s", exc, exc_info=True)


@_hooks.startup
async def _startup():
    """Wire shared managers + event loop into sub-router modules."""
    # 2026-10-04 -- a FRESH stop event for this lifespan's periodic threads,
    # before any of them starts (core/lifespan_threads.py).  _shutdown sets
    # it and joins them; a later lifespan in this process (every TestClient
    # enter) must not be born stopped, nor inherit the last one's threads.
    _lifespan_threads.begin()
    # BF-599 (2026-05-30): start the event-loop stall watchdog FIRST so
    # any sync-call-blocking-the-loop bug surfaces with a full thread
    # dump in the log — was the missing diagnostic for "API died with
    # no logs after 1432s" symptom on local Windows multi-worker runs.
    try:
        from core.loop_watchdog import start_loop_watchdog
        # 2026-06-04 — threshold + enable now config-driven so operators
        # can dial down the noise on dev boxes (browser+IDE can briefly
        # stall the loop without it being a real problem).  Defaults
        # preserved (5s threshold, enabled).
        try:
            from core.config import get_section as _gs_lw
            _lw_cfg = _gs_lw("loop_watchdog") or {}
        except Exception:
            _lw_cfg = {}
        _lw_enabled = bool(_lw_cfg.get("enabled", True))
        _lw_threshold = float(_lw_cfg.get("stall_threshold_seconds", 5.0) or 5.0)
        _lw_poll = float(_lw_cfg.get("poll_interval_seconds", 1.0) or 1.0)
        if _lw_enabled:
            start_loop_watchdog(stall_threshold_seconds=_lw_threshold,
                                  poll_interval=_lw_poll)
        else:
            logger.info("loop_watchdog disabled via config.loop_watchdog.enabled=false")
    except Exception as _lw_exc:
        logger.warning("loop watchdog start failed: %s", _lw_exc)

    # 2026-06-03 — memory_guard watchdog: samples available RAM every
    # N seconds; cancels oldest in-flight query when below
    # critical_low_mb.  Defends against BSOD / OOMKiller on both
    # Windows local dev (64GB) and OpenShift (25GB pod cap).  Per-
    # query cancel_event is registered via register_query() in the
    # dispatcher; watchdog calls .set() on it directly — no process
    # callback bridge needed.
    try:
        from core.memory_guard import start_watchdog
        start_watchdog()
    except Exception as _mg_exc:
        logger.warning("memory_guard watchdog start failed: %s", _mg_exc)

    # 2026-09-27 -- the ONE startup line naming the config FILE this pod
    # loaded (path, exists, load ok).  The loader logs at import time, before
    # logging is configured, so nobody sees it; this is the line an operator
    # greps for after a roll, and /health + `config show` expose the same
    # fact for scripts/verify_prod_config.py to assert per pod.
    from core.config import log_config_source
    log_config_source(logger)
    # 2026-10-10 -- this server process registers itself in the pod's worker
    # ledger (core/worker_ledger.py); a process that replaces a worker the
    # supervisor killed logs a WARNING naming the dead pid.  Outside a server
    # process (tests, the CLI) it records nothing.
    try:
        from core.worker_ledger import register_worker_start
        register_worker_start(logger)
    except Exception as _wl_exc:
        logger.warning("worker ledger registration failed (non-fatal): %s", _wl_exc)

    # Phase 69: validate config on startup
    from core.config import validate_config as _validate_cfg
    _cfg_issues = _validate_cfg()
    if _cfg_issues:
        logger.warning("Config validation found %d issue(s)", len(_cfg_issues))

    # Phase 119: set NO_PROXY env var from proxy config (belt-and-suspenders
    # for libcurl in DuckDB and urllib3 in requests)
    from core.proxy_utils import setup_proxy_env
    setup_proxy_env()

    loop = asyncio.get_running_loop()
    # Initialise extracted modules with shared dependencies
    # Phase 130 hotfix-13: wire DB-backed runtime settings before anything
    # that reads them (so the feed engine's first call already honours
    # admin overrides persisted from a prior pod).
    try:
        from core import config as _cfg_mod
        _cfg_mod.init_db_settings(db_manager)
    except Exception as _cfg_db_exc:
        logger.warning("config.init_db_settings failed (non-fatal): %s", _cfg_db_exc)
    init_iceberg_cache(db_manager)
    # BF-296: snapshot-keyed Iceberg metadata cache
    try:
        from core.iceberg_snapshot_cache import init_iceberg_snapshot_cache
        init_iceberg_snapshot_cache(db_manager)
    except Exception as _isc_init_exc:
        logger.warning("BF-296 init failed (non-fatal): %s", _isc_init_exc)
    # BF-320: background_jobs DB-backed pause state
    try:
        from core import background_jobs as _bj_mod
        _bj_mod.init_persistence(db_manager)
    except Exception as _bj_pers_exc:
        logger.warning("BF-320 background_jobs.init_persistence failed: %s", _bj_pers_exc)
    # 2026-10-17 -- the per-pod component-health REPORTER (every server
    # process writes its own rows; declared per-pod in
    # daemon_registry.PER_POD_DAEMONS, so no pod-role gate applies).
    try:
        from core.component_health.reporter import start_reporter as _ch_start_reporter
        _ch_start_reporter(db_manager)
    except Exception as _ch_exc:
        logger.warning("component_health reporter not started (non-fatal): %s", _ch_exc)
    def _daemon_allowed(_name: str) -> bool:
        """Pod-role gate for background daemon starts.

        2026-08-19 — REVERTED TO ALWAYS-TRUE FOR THE RETENTION LOOPS, and the
        reason is worth recording because the first version looked obviously
        right.

        Four DB-retention cleanup loops (etl-cleanup, feed-cleanup, dq-cleanup,
        agent-log-cleanup) started in every pod, so N pods issued the same
        DELETEs.  Gating them behind the pod role removed that duplication —
        and removed the sweeps ENTIRELY.  They are plain daemon threads
        started here in main.py; ``scheduler_worker.py`` runs
        ``init_scheduler`` plus a couple of explicitly added jobs and NEVER
        starts them.  So they only ever ran on the API pod, and gating them
        off it meant they ran on no pod at all: silent unbounded growth of the
        etl / feed / dq / agent-log tables, surfacing weeks later as a full
        disk.

        "This can only ever start FEWER daemons than before" was written as a
        safety property.  For a daemon that nothing else runs, fewer means
        zero.  A duplicated sweep is wasteful; a missing one loses the
        database.

        RESOLVED 2026-08-19: the sweeps were extracted to
        ``core/retention_daemons.py`` and registered by ``scheduler_worker``
        alongside the mirrors and prefetch, so the daemon host now genuinely
        owns them.  With a real owner elsewhere, gating them here MOVES the
        work instead of deleting it — which is the whole point of running
        background jobs in a separate pod.

        Fail-open on an unreadable role: better to sweep twice than never.
        """
        try:
            from core.pod_role import current as _pr_current
            _ok = bool(_pr_current().should_run(_name))
        except Exception as _pr_exc:
            logger.debug("pod-role gate unavailable for %s "
                         "(starting anyway): %s", _name, _pr_exc)
            _ok = True
        if _ok:
            # 2026-09-28 -- every call site starts its daemon right after a
            # True; report it in this pod's heartbeat so the admin posture
            # card can see the sweeps / digest a HYBRID pod runs (before, a
            # hybrid lock holder left 16 rows "could not determine").
            try:
                from core import background_jobs as _bj_allowed
                _bj_allowed.record_boot_registrations(
                    [_name], "started by main.py on this pod (daemon thread)")
            except Exception as _rec_exc:
                logger.debug("heartbeat record for %s failed: %s",
                             _name, _rec_exc)
        return _ok

    # 2026-09-28 -- THE SINGLETON GATE, shared with the scheduler pod.
    #
    # ``should_run`` answers "may this KIND of pod run daemons?".  It never
    # answered "is this the ONE process?", so on a hybrid pod the nine
    # singleton daemons (core.daemon_registry.SINGLETON_DAEMONS) started
    # here AND on the scheduler pod.  Measured on the Docker rig: the Netcool
    # sender posted six heartbeats per minute on a 20 s interval, in pairs,
    # and two drainers polled the same pending_notifications rows -- a real
    # alert could be posted twice.  Every singleton start below now goes
    # through ``daemon_registry.start_when_singleton`` -- the SAME function
    # the scheduler pod's registrations use, with the SAME predicate ("this
    # process holds the APScheduler lock") and the same deferral: a
    # non-holder defers at WARNING and starts the daemon if it wins the lock
    # later (the lock is taken in a background thread further down this
    # startup, so the leader drains its deferrals right after it wins).
    # tests/test_hybrid_singletons_share_the_gate_2026_09_28.py walks these
    # sites by name and fails on a starter called outside the gate.
    from core.daemon_registry import (
        DaemonContext as _HybridDaemonContext,
        start_when_singleton as _registry_start_when_singleton,
    )
    _hybrid_daemon_ctx = _HybridDaemonContext(db_manager, scheduler=None,
                                              loop=loop)

    def _start_singleton(_name: str, _start_fn, *,
                         record_started: bool = True) -> bool:
        """Start a singleton daemon through the registry's one gate."""
        return _registry_start_when_singleton(
            _hybrid_daemon_ctx, _name, _start_fn,
            record_started=record_started)

    # BF-299: background metadata sync (proactive cache warm-up).
    # BF-SCHED-EXTERNAL: when scheduler.mode=external, the iceberg sync
    # job runs on the scheduler pod (scheduler_worker.py) — registering
    # it here would cause it to ALSO run on every API pod, hammering the
    # event loop with sync work that should be isolated.  Skip when
    # external; embedded mode (single-pod dev/minimal) still registers.
    # 2026-09-06 — WIRE THE DB ON EVERY POD, START THE LOOP ON ONE.
    # ``note_query_against`` is the auto-discovery hook the QUERY path calls
    # on every iceberg table read, and it needs only the manager.  Its
    # manager used to be set exclusively inside start_background_sync, which
    # this gate skips on an api pod — so the pod that runs the queries could
    # never register a table, and watched_iceberg_tables stayed empty in
    # every api/worker split.  set_db_manager starts nothing (see its
    # docstring); the loop below is still gated.
    try:
        from core.iceberg_metadata_sync import (
            set_db_manager as _ims_set_db,
        )
        _ims_set_db(db_manager)
    except Exception as _ims_wire_exc:
        logger.warning("iceberg_metadata_sync db wiring failed "
                       "(auto-discovery of watched tables will be "
                       "inert): %s", _ims_wire_exc)
    # 2026-09-28 -- the snapshot-change LISTENERS are per PROCESS, not
    # singleton daemons.  Any process that reconciles an Iceberg table fires
    # them -- including this one, whenever an admin calls
    # POST /api/admin/iceberg-sync/refresh-table.  They used to be armed only
    # by the watcher / metadata-sync starters, so once those were (rightly)
    # gated to the scheduler-lock holder a refresh on this pod inspected no
    # commit and warmed nothing (found live: an Iceberg-commit dependency
    # waited ~6 min for the scheduler's next poll instead of releasing on
    # the refresh).  Arm both here, unconditionally; both are idempotent.
    for _arm_mod in ("core.iceberg_snapshot_indexer",
                     "core.iceberg_snapshot_reactions"):
        try:
            import importlib as _il_arm
            _il_arm.import_module(_arm_mod).arm(db_manager)
        except Exception as _arm_exc:
            logger.warning("%s could not be armed on this process "
                           "(non-fatal -- a refresh here will not inspect "
                           "commits): %s", _arm_mod, _arm_exc)
    try:
        from core.config import scheduler as _ims_sched_cfg
        from core.pod_role import current as _pod_role_current
        if _pod_role_current().should_run(
            "iceberg_metadata_sync",
            scheduler_mode=_ims_sched_cfg.mode,
        ):
            from core.iceberg_metadata_sync import start_background_sync
            _start_singleton("iceberg_metadata_sync",
                             lambda: start_background_sync(db_manager))
    except Exception as _ims_init_exc:
        logger.warning("BF-299 init failed (non-fatal): %s", _ims_init_exc)
    # Phase E (2026-06-08) — Register db_manager with the L2 short-circuit
    # so iceberg_db_first_reader can read its admin-tunable knobs from the
    # SystemSetting table (no env-var hardcodes).  Phase G bootstrap
    # seeds default rows so admin sees them in /api/admin/iceberg-watcher
    # /settings from day 0 (idempotent).
    try:
        from core.iceberg_db_first_reader import (
            _set_db_manager as _dbf_set,
            bootstrap_settings as _dbf_bootstrap,
        )
        _dbf_set(db_manager)
        _dbf_bootstrap(db_manager)
    except Exception as _dbf_init_exc:
        logger.warning("Phase E/G db_first init failed (non-fatal): %s",
                       _dbf_init_exc)

    # Phase C (2026-06-08) — Iceberg manifest watcher.  Cheap fast-tick
    # poll for snapshot-id changes on watched tables; invalidates L1/L2
    # caches between heavy reconciles.  Runs WHERE THE SCHEDULER LIVES:
    # external mode -> scheduler_worker.py owns it; embedded mode (single
    # pod dev) -> API pod owns it.  Never starts on executor pods.  All
    # knobs are admin-controllable via /api/admin/iceberg-watcher/settings.
    try:
        from core.config import scheduler as _icw_sched_cfg
        from core.pod_role import current as _pod_role_current
        if _pod_role_current().should_run(
            "iceberg_manifest_watcher",
            scheduler_mode=_icw_sched_cfg.mode,
        ):
            from core.iceberg_manifest_watcher import (
                start_background as _icw_start,
                bootstrap_settings as _icw_bootstrap,
            )
            _icw_bootstrap(db_manager)
            _start_singleton("iceberg_manifest_watcher",
                             lambda: _icw_start(db_manager))
    except Exception as _icw_init_exc:
        logger.warning("Phase C iceberg watcher init failed (non-fatal): %s",
                       _icw_init_exc)
    # BRD §8/§12 (2026-09-02) — acting time + Netcool.  The two modules
    # compute the clocks and shape the events; NOTHING RAN THEM until this
    # pass existed, which behaves exactly like working code because every
    # unit test agrees and nothing happens.  Runs WHERE THE SCHEDULER LIVES,
    # like the watchers above: one pod evaluates, or 34 blocked feeds get an
    # alert from each pod.
    try:
        from core.config import scheduler as _sla_sched_cfg
        from core.pod_role import current as _pod_role_current
        if _pod_role_current().should_run(
            "feed_sla_watcher",
            scheduler_mode=_sla_sched_cfg.mode,
        ):
            from core.feed.sla_watcher import start_background as _sla_start
            # session_factory is what enqueue_event hands to the durable
            # queue — without it every event the watcher raises dies at
            # enqueue with "THIS ALERT IS LOST" (the log line is loud,
            # but the alert is still lost).
            _start_singleton(
                "feed_sla_watcher",
                lambda: _sla_start(db_manager, env=_deploy_env_name(),
                                   session_factory=db_manager.SessionLocal))
    except Exception as _sla_init_exc:
        logger.warning("feed SLA watcher init failed (non-fatal — alerting "
                       "must never delay a feed): %s", _sla_init_exc)
    # BRD §7.1 (2026-09-02) — the Kafka arrival consumer.  Called
    # UNCONDITIONALLY inside its pod-role gate: it announces its own refusal
    # at INFO with the reason, which is the defect being fixed — "no messages
    # arriving" and "no consumer running" were indistinguishable from outside.
    try:
        from core.config import scheduler as _kaf_sched_cfg
        from core.pod_role import current as _pod_role_current
        if _pod_role_current().should_run(
            "feed_kafka_arrivals",
            scheduler_mode=_kaf_sched_cfg.mode,
        ):
            from core.feed.kafka_arrivals import start_consumer as _kaf_start
            _start_singleton("feed_kafka_arrivals",
                             lambda: _kaf_start(db_manager))
    except Exception as _kaf_init_exc:
        logger.warning("Kafka arrival consumer init failed (non-fatal): %s",
                       _kaf_init_exc)
    # BRD §12.4 (2026-09-02) — the Netcool sender: the queue DRAINER.
    # Store-and-forward without a forwarder is just store.  Called
    # UNCONDITIONALLY inside its pod-role gate: with the shipped
    # transport 'none' it REFUSES AT INFO with the reason (the §18
    # transport inputs are owed by the Netcool team), which is the whole
    # point — a disabled sender that says nothing is the defect.  Runs
    # where the scheduler lives, like the SLA watcher above: one drainer,
    # or every pod posts the same event.
    try:
        from core.config import scheduler as _ncs_sched_cfg
        from core.pod_role import current as _pod_role_current
        if _pod_role_current().should_run(
            "feed_netcool_sender",
            scheduler_mode=_ncs_sched_cfg.mode,
        ):
            from core.feed.netcool_sender import start_sender as _ncs_start
            _start_singleton(
                "feed_netcool_sender",
                lambda: _ncs_start(db_manager.SessionLocal,
                                   env=_deploy_env_name()))
    except Exception as _ncs_init_exc:
        logger.warning("Netcool sender init failed (non-fatal — alerting "
                       "must never delay a feed): %s", _ncs_init_exc)
    # 2026-10-31 -- the Jira channel of the alert road; same rule as Netcool:
    # one sender where the scheduler lives, refuses AT INFO when switched off.
    try:
        from core.config import scheduler as _js_sched_cfg
        from core.pod_role import current as _pod_role_current_js
        if _pod_role_current_js().should_run(
            "feed_jira_sender",
            scheduler_mode=_js_sched_cfg.mode,
        ):
            from core.feed.jira_sender import start_sender as _js_start
            _start_singleton("feed_jira_sender", lambda: _js_start(db_manager))
    except Exception as _js_init_exc:
        logger.warning("Jira sender init failed (non-fatal — alerting "
                       "must never delay a feed): %s", _js_init_exc)
    # Round 14 (2026-06-02) — Prewarm background service.  Registered
    # but disabled by default; admin opts in via
    # ``prewarm_background.enabled=true`` for hot-path tables.  When on,
    # warms S3 footers for watched iceberg tables every 5 min so cold
    # queries skip the 30s-250s HEAD-storm latency.
    try:
        # Phase 161 -- was ungated; now respects PodRole so api-only
        # pods don't warm S3 footers for every watched table.
        from core.pod_role import current as _pod_role_current
        from core.config import scheduler as _pw_sched_cfg
        if _pod_role_current().should_run(
            "prewarm_background",
            scheduler_mode=_pw_sched_cfg.mode,
        ):
            from core.prewarm_background_service import start_background_prewarm
            # record_started=False: the entry is DECLARED INERT (see the
            # module); the registry's own entry says the same.
            _start_singleton("prewarm_background",
                             lambda: start_background_prewarm(db_manager),
                             record_started=False)
    except Exception as _pwbg_init_exc:
        logger.warning("Round 14 prewarm_background init failed (non-fatal): %s",
                       _pwbg_init_exc)
    # Phase 160 (2026-07-01) — brain DuckDB metadata store mirror
    # daemon.  ONE writer per fleet (this pod when scheduler.mode !=
    # external — matches the iceberg_manifest_watcher gating above).
    # Every 5 min pulls col_stats / manifest / hot_tables /
    # hot_columns from the primary DB into the columnar store so hot-
    # path reads (iceberg_manifest_prune + iceberg_reader + 3 other
    # readers) can skip the primary DB.  DEFAULT OFF (opt-in via config or
    # the runtime admin toggle); fail-open on every layer — a broken or
    # disabled mirror does not break queries (readers use the primary DB).
    try:
        from core.config import scheduler as _bds_sched_cfg
        from core.pod_role import current as _pod_role_current
        if _pod_role_current().should_run(
            "brain_duckdb_mirror",
            scheduler_mode=_bds_sched_cfg.mode,
        ):
            # Supervisor (not one-shot start): reconciles the writer to
            # the runtime on/off toggle (config + SystemSetting) so an
            # admin can enable/disable without a redeploy.  DEFAULT OFF --
            # the writer only runs while enabled.
            from core.brain_duckdb_mirror import (
                start_supervisor as _bds_supervisor,
            )
            # Gate the DuckDB WRITER on the scheduler leader lease so at
            # most ONE pod ever writes the mirror store (pod_role.should_run
            # is True on all pods in hybrid/embedded → would be multi-writer
            # without this).  The supervisor loop itself is cheap and may
            # run everywhere; only the writer is leader-gated.
            # 2026-10-18: THE single-runner election is the scheduler LOCK
            # (daemon_registry.holds_single_runner_role, 2026-09-28) -- the
            # lease made a hybrid api pod a SECOND leader beside the scheduler pod
            from core.daemon_registry import holds_single_runner_role as _is_leader
            _bds_supervisor(
                db_manager,
                is_leader_fn=lambda: _is_leader(),
            )
    except Exception as _bds_init_exc:
        logger.warning(
            "Phase 160 brain DuckDB mirror init failed (non-fatal): %s",
            _bds_init_exc,
        )
    # BF-312: custom jobs scheduler (admin-defined cron jobs)
    try:
        # Phase 161 -- api-only pods must not run cron scheduler.
        from core.pod_role import current as _pod_role_current
        from core.config import scheduler as _cj_sched_cfg
        if _pod_role_current().should_run(
            "custom_jobs_scheduler",
            scheduler_mode=_cj_sched_cfg.mode,
        ):
            from core.custom_jobs import start_custom_jobs_scheduler
            _start_singleton("custom_jobs_scheduler",
                             lambda: start_custom_jobs_scheduler(db_manager))
    except Exception as _cj_init_exc:
        logger.warning("BF-312 init failed (non-fatal): %s", _cj_init_exc)
    # 2026-08-22 — spark_k8s reconciler: QueryStudio's own supervisor for
    # SparkApplication feed jobs (submit is per-request; SUPERVISION is a
    # singleton duty).  Owned by the scheduler pod in an api/worker split
    # (core.daemon_registry SCHEDULER_OWNED); in hybrid/embedded mode it
    # starts here.  Triple-gated inside start_reconciler: spark_k8s.enabled
    # → scheduler-lease leadership (per tick) → availability ladder (per
    # tick, declared reasons).
    try:
        from core.pod_role import current as _pod_role_current
        from core.config import scheduler as _sk_sched_cfg
        if _pod_role_current().should_run(
            "spark_k8s_reconciler",
            scheduler_mode=_sk_sched_cfg.mode,
        ):
            # the ONE election (see the DuckDB writer above): two reconcilers
            # would retry / cancel / finalise the same Spark job twice
            from core.daemon_registry import holds_single_runner_role as _sk_leader
            from core.spark_k8s.reconciler import start_reconciler as _sk_start
            _sk_start(
                db_manager,
                is_leader_fn=lambda: _sk_leader(),
            )
    except Exception as _sk_init_exc:
        logger.warning("spark_k8s reconciler init failed (non-fatal): %s",
                       _sk_init_exc)
    init_s3_utilities(conn_manager)
    # 2026-06-16 — ConnectionBrain startup sweep.  Schedules eager
    # partition_columns discovery for every active S3 connection so
    # the first query after pod restart hits the DB cache instead of
    # paying a 30s S3 walk inline.  Each refresh is a daemon thread;
    # the sweep returns immediately.  Connections with partition_columns
    # already populated short-circuit per-step.
    try:
        from core.connection_brain import get_brain
        _scheduled = get_brain().refresh_all()
        if _scheduled:
            logger.info(
                "[startup] ConnectionBrain swept %d connection(s); "
                "discovery runs in background.", _scheduled,
            )
    except Exception as _brain_sweep_exc:
        logger.warning(
            "[startup] ConnectionBrain refresh_all failed (non-fatal): %s",
            _brain_sweep_exc,
        )
    # Phase 29: initialise unified auth dependency (api/deps.py)
    from api.deps import init_deps as _init_deps
    _init_deps(_auth_cfg, db_manager)
    # 2026-10-31 -- tool entitlement: the ONE decision point reads its grants
    # from THIS store, and the role bundles are seeded here (once; a row that
    # exists, on or off, is never touched again) BEFORE the first request, on
    # every pod role that serves routes -- the same main.py runs them all.
    try:
        from core.tool_entitlement import seed_bundles as _te_seed, set_db_manager as _te_set_db
        _te_set_db(db_manager)
        _te_seed(db_manager)
    except Exception as _te_exc:                                     # noqa: BLE001
        # a failed seed leaves NO role grant rows: every non-super_admin is
        # refused until the next start, loudly -- never fail-open
        logger.error("tool entitlement: seeding the role bundles FAILED (%s) -- "
                     "only super_admin can act until this is fixed", _te_exc)
    set_grid_db(db_manager)
    set_grid_ws(ws_manager, loop)
    set_grid_paths(_paths.downloads_dir, _paths.parquet_dir)
    set_sql_dependencies(db_manager, ws_manager, loop, auth_cfg=_auth_cfg)
    set_report_dependencies(db_manager, ws_manager, loop)
    set_schedule_dependencies(db_manager, ws_manager, loop)
    set_clockwork_dependencies(db_manager)
    set_schedules_auth(_auth_cfg)
    set_dashboard_dependencies(db_manager, _get_current_user)

    # Phase 23: Enterprise reporting wiring
    try:
        # 2026-09-01 -- there is no ``EmailService`` class; the module is
        # function-shaped and already exposes exactly the method the
        # consumers call (``send_email_with_attachment``).  The ImportError
        # left ``_esvc = None``, and burst_api guards delivery on
        # ``if ... and _email_svc:`` -- so scheduled report EMAIL DELIVERY
        # never fired, silently, on every burst.  The module IS the service.
        import core.email_service as _esvc
    except Exception:
        _esvc = None

    set_catalog_dependencies(db_manager, _auth_cfg)
    set_portal_dependencies(db_manager, _auth_cfg)
    set_enterprise_dependencies(db_manager, _auth_cfg, email_service=_esvc)

    # FB-60: no legacy execute bridge -- PDF config is keyed to finance
    # reports and bursting runs the business_report family only.
    set_pdf_dependencies(db_manager, _auth_cfg)
    set_burst_dependencies(db_manager, _auth_cfg, email_service=_esvc)
    set_profile_dependencies(db_manager, _auth_cfg)
    set_workspace_dependencies(db_manager, _auth_cfg)
    db_manager.ensure_default_workspace()
    # FB-60: no route reads the legacy parametric `reports` table any more;
    # say at startup how many rows still await the operator's migration.
    from core.reports.legacy_parametric import log_legacy_rows_status
    log_legacy_rows_status(db_manager)
    set_lineage_dependencies(db_manager)
    set_suggest_dependencies(db_manager)
    set_datasets_dependencies(db_manager)
    # Phase 54: Federation Engine
    from core.federation_engine import FederationEngine as _FedEngine
    from core import config as _fed_cfg_ref
    _federation_engine = _FedEngine(db_manager, output_dir=str(_paths.downloads_dir))
    set_federation_dependencies(_federation_engine)

    # Phase 55: Aggregation Cache
    try:
        from core.agg_cache import init_agg_cache, register_scheduled_refreshes
        _agg_cache_dir = str(_paths.data_dir / "agg_cache") if hasattr(_paths, "data_dir") else "/usr/local/querystudioapi/nfs/data/agg_cache"
        init_agg_cache(db_manager, _federation_engine, _agg_cache_dir,
                       enabled=_fed_cfg_ref.agg_cache.enabled)
        from core.scheduler import _scheduler as _agg_sched
        if _agg_sched:
            _n_agg_jobs = register_scheduled_refreshes(_agg_sched)
            if _n_agg_jobs:
                logger.info("Registered %d agg cache refresh jobs", _n_agg_jobs)
    except Exception as _agg_init_err:
        logger.warning("Agg cache init skipped: %s", _agg_init_err)

    # Phase 56: Business Report Builder
    set_business_reports_dependencies(db_manager, _federation_engine, ws_manager)

    # Phase 114-J: Report Comments
    from api.report_comments_api import set_comments_dependencies
    set_comments_dependencies(ws_manager=ws_manager)

    # Phase 60: Subscription/Delivery
    set_subscription_dependencies(db_manager)
    try:
        # 2026-08-20 — the Phase 60/113-E closures (styled PDF render,
        # report_type dispatcher, email fn, lazy webhook) moved VERBATIM to
        # core.delivery_engine.init_default_delivery_engine so the scheduler
        # worker wires the IDENTICAL engine.  Wired only here, the scheduler
        # pod's __subscription_delivery__ tick crashed on None module
        # globals every run.  One constructor, two entry files, no drift.
        from core.delivery_engine import init_default_delivery_engine
        init_default_delivery_engine(db_manager)
        logger.info("Phase 60 delivery engine initialised")
    except Exception as _del_err:
        logger.warning("Delivery engine init skipped: %s", _del_err)

    # A2: Initialise extracted modules
    init_duckdb_views(db_manager, _paths, ws_manager, _mv_cfg, _lt_cfg, _limits_cfg)
    from core.mv_manager import init_mv_manager
    init_mv_manager(db_manager, ws_manager, _mv_cfg, _lt_cfg)

    # A3: Execute stream router
    set_stream_dependencies(db_manager, _paths, _qe_cfg, _limits_cfg,
                            register_s3_views_fn=_register_s3_views,
                            get_light_executor_fn=_get_light_executor,
                            ws_manager=ws_manager)

    # A3: Execute API router (background workers + /api/execute endpoints)
    set_execute_dependencies(db_manager, ws_manager, engine, _paths, _qe_cfg,
                             _limits_cfg, s3_config, query_executor,
                             _get_light_executor)

    # Phase 139 honest-fix #3 — register all 5 engine executor wrappers with
    # EngineRegistry. They satisfy the Executor protocol and delegate to the
    # existing background functions. Future passes will move function bodies
    # INTO the wrapper classes; for now this just establishes the dispatch
    # surface so direct callers can use EngineRegistry.get(kind) /
    # pick_executor(request) instead of importing execute_api functions.
    try:
        from core.executors.engines import register_all_engines
        register_all_engines()
    except Exception as _reg_err:
        logger.warning("Phase 139: engine registration failed (%s) — "
                       "EngineRegistry will be empty; existing dispatch unaffected",
                       _reg_err)

    # ─── Multi-pod prep PR1: cross-pod event bus ────────────────────────────
    # Foundation for the multi-pod architecture (see docs/multi-pod-
    # architecture-plan.html). Single-pod / SQLite mode = in-memory ring
    # buffer + local fan-out (existing WS broadcast works unchanged).
    # PostgreSQL mode = adds pg_notify() so future Worker / WebSocket pods
    # can subscribe.  Wired at this point because db_manager is initialized.
    # ``_eb_ws_wired`` gates the feed broadcast bridge below: only when the
    # in-process ws_manager subscriber is successfully registered do we route
    # feed progress THROUGH the bus (the subscriber then delivers to local WS).
    # If bus init fails, the bridge falls back to the direct ws_manager call so
    # single-pod feed progress is never lost.
    _eb_ws_wired = False
    try:
        from core.event_bus import (init_event_bus, subscribe as _eb_subscribe,
                                     publish as _eb_publish)
        from core.config import database as _db_cfg
        init_event_bus(db_manager=db_manager, db_type=_db_cfg.type)
        # PR1 dual-write: subscribe ws_manager so events published to the
        # bus are ALSO delivered to local WS clients.  When we split the
        # WebSocket pod (PR3), this subscription moves to that pod.
        def _local_ws_dispatch(event):
            # local_only=True (2026-08-02 fleet routing): every event that
            # reaches this subscriber ALREADY traveled the bus — either a
            # local publish() (whose NOTIFY half fanned it to peers) or a
            # remote NOTIFY delivered by the LISTEN consumer.  Re-relaying
            # from the manager would ping-pong events between pods forever.
            import asyncio as _aio
            # 2026-08-20: close the coroutine when scheduling fails (loop
            # not captured yet / already closed) — dropping the event is the
            # intended behaviour, but the un-scheduled coroutine leaked
            # ("coroutine 'WebSocketManager.broadcast…' was never awaited").
            # 2026-10-07: the address is read by ONE function
            # (event_bus.recipients_of, inside deliver_addressed) -- a feed
            # event's audience is a LIST (actor, owner, owner group).
            _coro = None
            try:
                _coro = ws_manager.deliver_addressed(event, local_only=True)
                _aio.run_coroutine_threadsafe(_coro, ws_manager._main_loop)
            except Exception as _ws_exc:
                if _coro is not None:
                    _coro.close()
                logger.debug("event_bus → WS dispatch skipped: %s", _ws_exc)
        _eb_subscribe(_local_ws_dispatch)
        _eb_ws_wired = True
        logger.info("event_bus: ws_manager subscriber registered (PR1 dual-write)")
        # Receiving half of the cross-pod bus: start the PG LISTEN consumer so
        # NOTIFYs from OTHER pods (e.g. a feed running on feed_worker) are
        # decoded and fanned out to THIS pod's ws_manager via the same
        # _local_ws_dispatch subscriber.  NO-OP in sqlite/single-pod mode; the
        # consumer self-dedups our own NOTIFYs (already delivered in-process).
        # Fail-open: a listener start failure must not break startup.
        try:
            from core.event_bus import start_listener as _eb_start_listener
            _eb_start_listener(db_manager, _db_cfg.type)
        except Exception as _eb_listen_err:
            logger.warning("event_bus LISTEN consumer start failed (%s) — "
                           "cross-pod delivery disabled; in-process WS still works",
                           _eb_listen_err)
        # 2026-08-02 fleet routing — completion backstop.  PG NOTIFY is not
        # durable: events emitted while THIS pod's LISTEN connection was
        # down are lost.  On reconnect-after-loss the event bus invokes gap
        # handlers with the outage window; this one re-reads TERMINAL
        # execution rows (the durable source of truth) completed in that
        # window and re-delivers them to local WS clients so a completion
        # for a query that ran on another pod is never silently dropped.
        # local_only=True — replay must never re-relay to peers (each pod
        # replays for its own clients).  Fail-open + bounded (window is
        # clamped by the bus; per-status row scan capped at 200).
        try:
            from core.event_bus import register_gap_handler as _eb_register_gap

            def _ws_terminal_gap_replay(_gap_since: float, _gap_until: float):
                from datetime import datetime as _gr_dt, timezone as _gr_tz
                _terminal_types = {
                    "completed": "execution_completed",
                    "failed":    "execution_failed",
                    "cancelled": "execution_cancelled",
                }
                _replayed = 0
                for _gr_status, _gr_evt in _terminal_types.items():
                    try:
                        _gr_rows = db_manager.list_executions(
                            status=_gr_status, limit=200)
                    except Exception as _gr_list_exc:
                        logger.debug("gap-replay: list_executions(%s) failed: %s",
                                     _gr_status, _gr_list_exc)
                        continue
                    for _gr_row in _gr_rows or []:
                        _gr_comp = _gr_row.get("completed_at")
                        if not _gr_comp:
                            continue
                        try:
                            if isinstance(_gr_comp, str):
                                _gr_cdt = _gr_dt.fromisoformat(_gr_comp)
                            else:
                                _gr_cdt = _gr_comp
                            if _gr_cdt.tzinfo is None:
                                _gr_cdt = _gr_cdt.replace(tzinfo=_gr_tz.utc)
                            _gr_cw = _gr_cdt.timestamp()
                        except Exception as _gr_parse_exc:
                            logger.debug("gap-replay: bad completed_at %r: %s",
                                         _gr_comp, _gr_parse_exc)
                            continue
                        if not (_gap_since <= _gr_cw <= _gap_until):
                            continue
                        _gr_owner = _gr_row.get("executed_by") or ""
                        if not _gr_owner:
                            continue
                        _gr_payload = {
                            "type": _gr_evt,
                            "execution_id": _gr_row.get("execution_id"),
                            "username": _gr_owner,
                            "data": {
                                "status": _gr_status,
                                "total_rows": _gr_row.get("total_rows", 0),
                                "file_size_bytes": _gr_row.get("file_size_bytes", 0),
                                "error": _gr_row.get("error_message"),
                            },
                            "gap_replayed": True,
                            "timestamp": _gr_dt.now(_gr_tz.utc).isoformat(),
                        }
                        # 2026-08-20: close the coroutine when scheduling
                        # fails — same leak class as _local_ws_dispatch.
                        _gr_coro = None
                        try:
                            _gr_coro = ws_manager.broadcast_to_user(
                                _gr_owner, _gr_payload, local_only=True)
                            asyncio.run_coroutine_threadsafe(
                                _gr_coro, ws_manager._main_loop)
                            _replayed += 1
                        except Exception as _gr_sched_exc:
                            if _gr_coro is not None:
                                _gr_coro.close()
                            logger.debug("gap-replay: broadcast schedule "
                                         "failed: %s", _gr_sched_exc)
                if _replayed:
                    logger.info(
                        "gap-replay: re-delivered %d terminal execution "
                        "event(s) missed during a %.0fs LISTEN outage",
                        _replayed, _gap_until - _gap_since)

            _eb_register_gap(_ws_terminal_gap_replay)
        except Exception as _gap_reg_err:
            logger.debug("event_bus gap-replay handler registration failed "
                         "(non-fatal): %s", _gap_reg_err)
    except Exception as _eb_err:
        logger.warning("event_bus init failed (%s) — multi-pod prep disabled, "
                       "existing single-pod WS path still works", _eb_err)

    # 2026-07-16 — Completeness Sentinel: register the decoupled observer hooks
    # on completeness_control so finalize verdicts + shadow-divergence incidents
    # reach the autonomous pruning-trust agent.  Fail-open; a failure here must
    # not break startup (the Sentinel then simply never sees finalize/incident
    # events, and its stamp-point observe in iceberg_reader still works).
    try:
        from core.completeness_sentinel import init_sentinel as _init_sentinel
        _init_sentinel()
    except Exception as _sn_err:
        logger.warning("completeness Sentinel hook registration failed (%s) — "
                       "non-fatal; stamp-point observation still active", _sn_err)

    # 2026-07-17 — Completeness SHADOW RE-EXECUTOR (Tier-3 wrong-prune catcher).
    # Registers the empirical full-scan-off row-count comparison that the shadow
    # sampler runs in the background.  OFF BY DEFAULT: register() is a NO-OP
    # unless an operator opted in via completeness.shadow_sample_rate>0 OR a
    # non-empty completeness.shadow_tables.  In a default install nothing is
    # registered → completeness_control.get_reexecutor() stays None → the
    # reader's Tier-3 enqueue block is skipped entirely (zero cost, zero
    # behaviour change on every query).  Fail-open: a registration failure must
    # not break startup (the sampler then simply stays inert).
    try:
        from core.completeness_reexecutor import register as _register_reexec
        _register_reexec(db_manager=db_manager)
    except Exception as _reexec_err:
        logger.warning("completeness shadow re-executor registration failed (%s) "
                       "— non-fatal; wrong-prune sampling stays inert", _reexec_err)

    # Phase 29: wire domain routers
    from core.execution_state import set_global_sem as _set_sem
    _set_sem(_global_query_sem)
    set_auth_dependencies(limiter, _auth_cfg, db_manager)
    # Eagerly initialise the login-payload RSA keypair so the very first
    # /auth/public-key request doesn't bear the keygen cost (~150ms on a
    # small pod, several seconds on a heavily-loaded one).  Idempotent;
    # safe even if cryptography is missing (logs + continues).
    try:
        from core.login_crypto import generate_keypair_if_missing as _login_keygen
        _login_keygen()
    except Exception as _lck_err:
        logger.warning("Login crypto init skipped (%s) — login plaintext fallback still works", _lck_err)
    set_notification_dependencies(db_manager)
    set_system_dependencies(db_manager, engine, _paths, _qe_cfg,
                             prom_pool_active=_prom_pool_active,
                             prom_pool_queued=_prom_pool_queued)
    set_admin_dependencies(db_manager, engine, _paths, _qe_cfg, _auth_cfg, ws_manager)
    set_connection_dependencies(db_manager, engine, conn_manager, _paths, _auth_cfg, _lt_cfg)
    set_query_dependencies(db_manager, engine, conn_manager, _paths, _auth_cfg,
                           _qe_cfg, _limits_cfg, _features_cfg, ws_manager=ws_manager)
    set_mv_dependencies(db_manager, engine, conn_manager, ws_manager, _mv_cfg)
    set_local_table_dependencies(db_manager, engine, ws_manager, _lt_cfg, _mv_cfg, _paths,
                                  light_executor=_get_light_executor())
    # Provide the _register_s3_views function to mv_router (defined at module level below)
    _mv_api_module._register_s3_views = _register_s3_views

    # Phase 42: Arrow IPC
    set_arrow_dependencies(db_manager, _auth_cfg)

    # Phase 75: Published Views API
    from core.config import published_views as _pv_cfg
    # Phase 91: pass federation engine so BR-based views can execute
    set_published_views_dependencies(db_manager, _pv_cfg, _federation_engine, ws_manager=ws_manager)
    # 2026-10-17 -- the inventory reads the same manager
    from api.published_api_api import set_published_api_dependencies
    set_published_api_dependencies(db_manager)

    # Phase 75: Scheduled cleanup for API access logs + stale cache files
    # Phase 161 -- api-only pods must not run the cleanup thread.
    # 2026-08-20 -- gate through _daemon_allowed (identical decision) so the
    # name matches core/retention_daemons.JOB_IDS: the scheduler pod now
    # owns this sweep as the "pv_cleanup" job, closing the orphan where
    # role=api deleted access-log retention entirely.
    if _pv_cfg.enabled and _daemon_allowed("pv_cleanup"):

        def _pv_cleanup_pass():
            """One cleanup of stale API access logs and cache files."""
            try:
                deleted = db_manager.cleanup_api_access_logs(
                    retention_days=_pv_cfg.access_log_retention_days
                )
                if deleted:
                    logger.info("Published Views: cleaned up %d stale access logs", deleted)
            except Exception as _cl_exc:
                logger.warning("Published Views cleanup failed: %s", _cl_exc)
            # Clean stale cache files (older than max TTL * 2)
            try:
                from pathlib import Path as _P
                cache_dir = _P(_pv_cfg.cache_dir)
                if cache_dir.exists():
                    import time as _t2
                    max_age = max(_pv_cfg.default_cache_ttl_seconds * 2, 3600)
                    now = _t2.time()
                    for f in cache_dir.glob("*.parquet"):
                        if now - f.stat().st_mtime > max_age:
                            f.unlink(missing_ok=True)
            except Exception:
                pass

        # Sleep-then-work every interval, stopped by the lifespan shutdown.
        _lifespan_threads.start_periodic(
            "pv-cleanup", _pv_cleanup_pass,
            every=max(_pv_cfg.cleanup_interval_hours * 3600, 3600))
        logger.info("Published Views: cleanup thread started (interval=%dh, retention=%dd)",
                     _pv_cfg.cleanup_interval_hours, _pv_cfg.access_log_retention_days)

    # Phase 98-I: Kafka-driven cache invalidation
    # Only start in embedded scheduler mode — in split architecture (external),
    # the Kafka consumer runs in the scheduler pod to avoid duplication.
    # Phase 161 -- ALSO gate by PodRole so api-only pods don't attach
    # the Kafka consumer thread + connection pool.
    from core.config import scheduler as _kafka_sched_cfg
    from core.pod_role import should_run as _pr_should_run
    if _pr_should_run("kafka_cache_consumer", scheduler_mode=_kafka_sched_cfg.mode):
        try:
            from core.kafka_cache_consumer import (
                set_kafka_consumer_dependencies, start_kafka_consumer
            )
            from pathlib import Path as _KPath
            _kv_cache_dir = _KPath(_pv_cfg.cache_dir) if _pv_cfg else None
            set_kafka_consumer_dependencies(db_manager, _kv_cache_dir, _pv_cfg)

            def _start_kafka_cache_consumer() -> bool:
                _kafka_started = start_kafka_consumer()
                if _kafka_started:
                    logger.info("Phase 98-I: Kafka cache invalidation consumer started (embedded mode)")
                else:
                    logger.debug("Phase 98-I: Kafka cache invalidation disabled or unavailable")
                return bool(_kafka_started)

            _start_singleton("kafka_cache_consumer", _start_kafka_cache_consumer)
        except Exception as _kafka_exc:
            logger.warning("Phase 98-I: Failed to start Kafka consumer (non-fatal): %s", _kafka_exc)
    else:
        logger.debug("Phase 98-I: Kafka consumer deferred to scheduler worker (external mode)")

    # Phase 93+97: Federation Views
    set_federation_views_dependencies(db_manager=db_manager, connection_manager=conn_manager)
    # Phase 97: Ensure federation views storage dir exists
    from core.config import federation_views_cfg as _fvcfg
    os.makedirs(_fvcfg.storage_dir, exist_ok=True)

    # Phase 127: ETL Pipelines
    from core.config import etl_pipelines as _etl_cfg
    set_etl_pipeline_dependencies(db_manager, _auth_cfg, broadcast_fn=None)

    # BF-582 (2026-05-29): make ETL enabled/disabled state visible at
    # startup regardless of the flag.  Operators couldn't easily tell
    # whether the ETL subsystem was on or off without grepping config.
    logger.info(
        "ETL Pipelines: feature flag etl_pipelines.enabled=%s",
        _etl_cfg.enabled,
    )

    # Phase 161 -- api-only pods must not run ETL scheduler / cleanup.
    from core.pod_role import should_run as _pr_should_run_etl
    if _etl_cfg.enabled and _pr_should_run_etl(
        "etl_pipelines", scheduler_mode=None,
    ):
        from core.etl_engine import (
            init_etl_engine as _init_etl_engine,
            run_etl_scheduler_loop as _run_etl_scheduler_loop,
        )

        def _etl_ws_broadcast(payload):
            username = payload.pop("triggered_by", None)
            if username:
                asyncio.run_coroutine_threadsafe(
                    ws_manager.broadcast_to_user(username, payload), loop)
            else:
                logger.debug("ETL broadcast dropped — no triggered_by in payload")

        _init_etl_engine(db_manager, broadcast_fn=_etl_ws_broadcast)

        # BF-582: run a one-shot cleanup IMMEDIATELY on startup so
        # stale executions from a prior crash are reset before the
        # first request arrives.  Previously the loop slept for the
        # full ``cleanup_interval_hours`` (default 12h) before any
        # cleanup ran.
        _etl_stale_min = _etl_cfg.stale_execution_minutes
        try:
            _bootstrap_stale = db_manager.reset_stale_running_executions(
                stale_minutes=_etl_stale_min,
            )
            if _bootstrap_stale:
                logger.info(
                    "ETL Pipelines: startup reset %d stale execution(s) "
                    "(threshold=%dm)", _bootstrap_stale, _etl_stale_min,
                )
        except Exception as _bs_exc:
            logger.warning("ETL Pipelines startup stale reset failed: %s", _bs_exc)

        # ETL cleanup daemon thread
        def _etl_cleanup_pass():
            # Phase 132 deep-dive: Reset stale running/pending ETL executions.
            # BF-582: threshold now config-driven (was hardcoded 60).
            try:
                stale_count = db_manager.reset_stale_running_executions(
                    stale_minutes=_etl_cfg.stale_execution_minutes,
                )
                if stale_count:
                    logger.info("ETL Pipelines: reset %d stale running executions", stale_count)
            except Exception as _es_exc:
                logger.warning("ETL Pipelines stale reset failed: %s", _es_exc)
            try:
                cleaned = db_manager.cleanup_old_etl_executions(
                    _etl_cfg.execution_history_retention_days
                )
                if cleaned:
                    logger.info("ETL Pipelines: cleaned up %d old execution records", cleaned)
            except Exception as _ec_exc:
                logger.warning("ETL Pipelines cleanup failed: %s", _ec_exc)

        if _daemon_allowed("etl_cleanup"):
            _lifespan_threads.start_periodic(
                "etl-cleanup", _etl_cleanup_pass,
                every=max(_etl_cfg.cleanup_interval_hours * 3600, 3600))

        # BF-582: launch the periodic scheduler that fires
        # trigger_type=schedule pipelines.  Before BF-582 NO loop
        # called trigger_pipeline for cron-scheduled pipelines —
        # they only fired manually or via dependency cascade.
        try:
            # The LOOP is the singleton (the engine wiring and cleanup
            # thread above are per-pod).  Scheduled on the lifespan loop
            # from whichever thread the gate fires on -- at boot, or from
            # the deferral watcher once this process wins the lock.
            _start_singleton(
                "etl_pipelines",
                lambda: loop.call_soon_threadsafe(
                    lambda: _qs_track_bg(_run_etl_scheduler_loop())))
            logger.info(
                "ETL Pipelines: engine initialised, cleanup thread "
                "started (interval=%dh, stale_threshold=%dm), "
                "scheduler loop routed through the singleton gate "
                "(tick=%ds, cluster_cap=%d)",
                _etl_cfg.cleanup_interval_hours,
                _etl_cfg.stale_execution_minutes,
                _etl_cfg.scheduler_tick_seconds,
                _etl_cfg.max_concurrent_pipelines_cluster,
            )
        except Exception as _sched_exc:
            logger.warning(
                "ETL Pipelines: scheduler loop failed to start: %s "
                "(cleanup + manual triggers still work)", _sched_exc,
            )

    # Phase 76: Feed File Generation
    from core.config import feed_generation as _fg_cfg
    set_feed_dependencies(db_manager, _auth_cfg, broadcast_fn=None)
    # Step 8 (BRD §15): change control — db seam only; the pod never
    # talks to git (CI posts file contents + resolved sha to /deploy).
    set_governance_dependencies(db_manager)
    set_run_surface_dependencies(db_manager)
    set_feed_ops_dependencies(db_manager, _auth_cfg)
    set_date_tokens_dependencies(db_manager)
    set_feed_group_dependencies(db_manager)
    set_feed_close_out_dependencies(db_manager)
    set_feed_template_dependencies(db_manager)
    set_feed_consumer_dependencies(db_manager)
    set_feed_variance_hold_dependencies(db_manager)
    set_feed_steps_dependencies(db_manager)
    set_feed_schedule_preview_dependencies(db_manager)
    set_feed_daemons_dependencies(db_manager)
    set_posture_dependencies(db_manager)
    # the scheduler-worker proxy carries run_now / scheduler pause to the
    # owning process in external mode (never run here instead)
    from api.admin_api import _scheduler_worker_proxy as _ch_proxy
    set_component_health_dependencies(db_manager, _ch_proxy)

    # Phase 133: Reconciliation API
    set_reconciliation_dependencies(db_manager, broadcast_fn=None)

    if _fg_cfg.enabled:
        from core.feed_engine import init_feed_engine as _init_feed_engine

        def _feed_ws_broadcast_direct(payload, audience):
            """The legacy direct-to-ws_manager path (pre-event-bus).  Retained
            as the fail-open fallback for when the event bus / its in-process
            subscriber could not be wired, so single-pod feed progress is never
            lost.  2026-10-07: delivers to the resolved AUDIENCE only -- the
            broadcast-all branch is gone (an unaddressed feed event is a
            producer bug and is dropped upstream, never sent to everyone)."""
            msg = dict(payload)
            msg["audience"] = list(audience or [])
            asyncio.run_coroutine_threadsafe(
                ws_manager.deliver_addressed(msg), loop)

        def _feed_ws_broadcast(payload):
            # Cross-pod (2026-07-16) — route feed progress AND the feed
            # log-stream (both flow through this single injected broadcast_fn)
            # through the cross-pod event bus instead of calling ws_manager
            # directly.  The in-process subscriber (_local_ws_dispatch,
            # registered above) delivers to LOCAL WS clients — byte-identical
            # single-pod behaviour — AND in PostgreSQL mode pg_notify fans the
            # SAME event out to other pods, so a feed running on a SEPARATE pod
            # still reaches this pod's WebSocket clients.
            #
            # Routing (2026-10-07): the PRODUCER resolved the audience
            # through core.feed.event_audience.feed_event_audience (the
            # actor if a person, the owner, the owner group) and stamped it
            # on the payload; the bridge reads it and decides nothing.  It
            # used to lift ``triggered_by`` to the username, so a run the
            # queue worker executed was addressed to "queue_worker" -- a
            # name no browser has -- and NOBODY saw it live.  A payload with
            # no audience is a producer bug: WARNING and dropped, never
            # published broadcast-all.  ``triggered_by`` stays the run's
            # recorded actor and is removed from the delivered body (the
            # shape the UI has always received).
            from core.feed.event_audience import bridge_feed_event_to_bus

            def _publish(event_type, body, *, audience):
                if _eb_ws_wired:
                    try:
                        _eb_publish(event_type, body, audience=audience)
                        return
                    except Exception as _eb_pub_exc:
                        # Fail-open: a bus hiccup must never break feed
                        # execution or the local WS.  Direct path below.
                        logger.debug(
                            "event_bus publish failed, direct WS fallback: %s",
                            _eb_pub_exc)
                # Bus not wired (init failed) or publish raised.
                _feed_ws_broadcast_direct(body, audience)

            bridge_feed_event_to_bus(payload, publish=_publish)

        # DECLARED (2026-10-07): this broadcast delivers every per-line
        # ``feed_run_log`` event (bus or direct), so a run on this pod
        # records ``feed_executions.log_stream = "live"`` and the UI tails
        # it; the scheduler relay declares the opposite.
        from core.feed.event_audience import streams_run_log
        _init_feed_engine(db_manager,
                          broadcast_fn=streams_run_log(_feed_ws_broadcast))

        # Phase 130 hotfix-4 — seed predefined CTL format rows.
        # Idempotent (only inserts missing names) so a restart on an
        # existing install is a no-op.  Admin edits via the admin UI
        # take precedence — we never overwrite an existing row.
        try:
            seeded = db_manager.seed_default_feed_control_file_formats()
            if seeded:
                logger.info(
                    "[feed_engine] Seeded %d default control-file format(s)",
                    seeded,
                )
        except Exception as _seed_exc:
            logger.warning(
                "[feed_engine] Default CTL format seeding failed: %s",
                _seed_exc,
            )

        # Phase 131-A — seed the dependency-type catalogue (KAFKA,
        # ORACLE_TABLE, FILE, API).  Same idempotent pattern: only
        # inserts missing rows so admin renames / disables persist
        # across restarts.  Without this, fresh installs would have
        # an empty types dropdown on the Feed config page.
        try:
            seeded_dep = db_manager.seed_default_etl_dependency_types()
            if seeded_dep:
                logger.info(
                    "[feed_engine] Seeded %d default ETL dependency type(s)",
                    seeded_dep,
                )
        except Exception as _seed_exc:
            logger.warning(
                "[feed_engine] Default dep-type seeding failed: %s",
                _seed_exc,
            )

        # Feed cleanup daemon thread
        def _feed_cleanup_pass():
            # Phase 132-C: Reset stale "running" feeds before cleanup
            try:
                stale_count = db_manager.reset_stale_feed_executions(stale_minutes=60)
                if stale_count:
                    logger.info("Feed Generation: reset %d stale running executions", stale_count)
            except Exception as _fs_exc:
                logger.warning("Feed Generation stale reset failed: %s", _fs_exc)
            try:
                from core.feed_engine import cleanup_old_executions
                cleaned = cleanup_old_executions()
                if cleaned:
                    logger.info("Feed Generation: cleaned up %d old execution records", cleaned)
            except Exception as _fc_exc:
                logger.warning("Feed Generation cleanup failed: %s", _fc_exc)

        if _daemon_allowed("feed_cleanup"):
            _lifespan_threads.start_periodic(
                "feed-cleanup", _feed_cleanup_pass,
                every=max(_fg_cfg.cleanup_interval_hours * 3600, 3600))
        logger.info("Feed Generation: engine initialised, cleanup thread started (interval=%dh)",
                     _fg_cfg.cleanup_interval_hours)

    # Phase 88: Metadata Catalog API
    set_metadata_catalog_dependencies(db_manager, conn_manager, _auth_cfg)

    # Phase 99: Data Quality Monitoring
    try:
        from core.config import data_quality as _dq_cfg
        from core.data_quality_engine import set_dq_engine_dependencies

        def _dq_ws_broadcast(payload):
            username = payload.pop("triggered_by", None) or payload.get("username")
            if username:
                asyncio.run_coroutine_threadsafe(
                    ws_manager.broadcast_to_user(username, payload), loop)
            else:
                logger.debug("DQ broadcast dropped — no user in payload")

        set_dq_engine_dependencies(
            db_manager=db_manager,
            connection_manager=conn_manager,
            cfg=_dq_cfg,
        )
        set_dq_dependencies(
            db_manager=db_manager,
            dq_engine=True,
            cfg=_dq_cfg,
            broadcast_fn=_dq_ws_broadcast,
        )

        # Phase 100: User Preferences API
        set_user_preferences_dependencies(db_manager=db_manager)

        # Phase 161 -- api-only pods must not run DQ daemon.
        from core.pod_role import should_run as _pr_should_run_dq
        if _dq_cfg.enabled and _pr_should_run_dq(
            "dq_scheduled_loop", scheduler_mode=None,
        ):
            # DQ scheduled check daemon
            def _dq_scheduled_pass():
                try:
                    from core.data_quality_engine import run_all_enabled
                    results = run_all_enabled()
                    failures = [r for r in results if not r.get("passed")]
                    if failures:
                        logger.warning("DQ check: %d/%d rules failed", len(failures), len(results))
                        _dq_ws_broadcast({
                            "type": "dq_batch_failures",
                            "count": len(failures),
                            "rules": [{"rule_id": r["rule_id"], "severity": r.get("severity")} for r in failures[:10]],
                        })
                    elif results:
                        logger.info("DQ check: all %d rules passed", len(results))
                except Exception as _dq_exc:
                    logger.warning("DQ scheduled check failed: %s", _dq_exc)

            # 30 s initial delay to let the app fully start, then every
            # interval.
            _lifespan_threads.start_periodic(
                "dq-check", _dq_scheduled_pass,
                first=30, every=max(_dq_cfg.schedule_interval_minutes * 60, 60))

            # DQ cleanup daemon
            def _dq_cleanup_pass():
                try:
                    cleaned = db_manager.cleanup_dq_results(_dq_cfg.result_retention_days)
                    if cleaned:
                        logger.info("DQ cleanup: removed %d old results", cleaned)
                except Exception as _dqc_exc:
                    logger.warning("DQ cleanup failed: %s", _dqc_exc)

            if _daemon_allowed("dq_cleanup"):
                _lifespan_threads.start_periodic(
                    "dq-cleanup", _dq_cleanup_pass,
                    every=max(_dq_cfg.cleanup_interval_hours * 3600, 3600))
            logger.info("Phase 99: Data Quality engine started (interval=%dm, retention=%dd)",
                        _dq_cfg.schedule_interval_minutes, _dq_cfg.result_retention_days)
    except Exception as _dq_init_exc:
        logger.warning("Phase 99: Data Quality init failed (non-fatal): %s", _dq_init_exc)

    # Phase 22F: Wire GraphQL dependencies
    if _graphql_available:
        try:
            set_graphql_dependencies(db_manager, _auth_cfg)
            # Phase 133-K — only wire the arbitrary-SQL executeQuery mutation
            # callback in FULL backend mode.  The published-api pod doesn't
            # mount /api/queries/execute so the loopback call would 404; we
            # leave _execute_fn=None there and graphql_api returns a
            # structured "endpoint serves Published Views only — use
            # publishedViewData query" error instead of an opaque failure.
            if not _PUBLISHED_API_MODE:
                from api.graphql_api import set_execute_callback as _set_gql_exec
                from core.config import server as _srv_cfg
                _gql_port = getattr(_srv_cfg, "port", 8000)

                async def _gql_execute_fn(sql: str, connection_id: int,
                                           limit: int = 1000, executed_by: str = "graphql") -> str:
                    """Submit a SQL query via the internal REST execute endpoint."""
                    try:
                        import httpx as _httpx
                    except ImportError:
                        raise RuntimeError("httpx not installed — run: pip install httpx")
                    payload = {
                        "query_type": "sql_query",
                        "connection_id": connection_id,
                        "raw_sql": sql,
                        "limit": limit,
                        "executed_by": executed_by,
                        "cache_strategy": "disabled",
                    }
                    async with _httpx.AsyncClient(timeout=10.0) as _cli:
                        resp = await _cli.post(
                            f"http://localhost:{_gql_port}/api/queries/execute",
                            json=payload,
                        )
                    data = resp.json()
                    eid = data.get("execution_id") or data.get("id")
                    if not eid:
                        raise RuntimeError(f"Execute failed: {data.get('detail', resp.text[:200])}")
                    return eid
                _set_gql_exec(_gql_execute_fn)

            # Phase 133-K — tell graphql_api which mode we're in so the
            # executeQuery mutation can return a friendly error instead of
            # the generic "callback not configured" string.
            try:
                from api.graphql_api import set_published_api_mode as _set_gql_mode
                _set_gql_mode(_PUBLISHED_API_MODE)
            except ImportError:
                pass  # back-compat with older graphql_api builds

            # Inject Published View execute callback for GraphQL data queries
            from api.published_views_api import _execute_view as _pv_exec_view
            from api.published_views_api import _db_manager as _pv_db

            async def _gql_pv_execute_fn(
                slug: str,
                params=None,
                filters=None,
                columns=None,
                sort_column=None,
                sort_dir="asc",
                limit=1000,
                offset=0,
                consumer_user=None,
            ) -> dict:
                """Execute a Published View from GraphQL — wraps _execute_view.

                Phase 131 deep-dive #13: forwards ``consumer_user`` so RLS
                rewrites and api_key_lifecycle registration both see the
                real consumer's identity (was a silent bypass via the
                hardcoded synthetic principal in _execute_view).
                """
                pv = _pv_db.get_published_view_by_slug(slug) if _pv_db else None
                if not pv or not pv.get("is_active"):
                    raise ValueError(f"Published view '{slug}' not found or inactive")
                # 2026-08-17: was `min(limit, pv.get("max_limit", 50000))`.
                # Two defects: the 50000 literal disagreed with the config that
                # graphql_api.py reads (one knob, two answers), and a view
                # published WITHOUT an explicit limit now stores NULL -- so
                # min(int, None) raised TypeError and failed the query outright.
                # Route through the shared resolver: config-authoritative,
                # NULL-safe, and 0 means unlimited rather than folding to a cap.
                # 2026-08-20 -- clamp negatives, same reason as
                # graphql_api.py: this wrapper validates nothing, and
                # downstream max(0, int(v)) turns -7 into 0 == UNLIMITED.
                # A negative limit is not a request for everything.
                if limit is not None and int(limit) < 0:
                    limit = None
                from api.published_views.helpers import effective_page_limit
                effective_limit = effective_page_limit(pv, limit)
                return await _pv_exec_view(
                    pv=pv,
                    filters=filters or [],
                    columns=columns,
                    sort_column=sort_column,
                    sort_dir=sort_dir,
                    limit=effective_limit,
                    offset=offset,
                    params=params,
                    consumer_user=consumer_user,
                )

            set_pv_execute_callback(_gql_pv_execute_fn)

            # Inject enterprise deps for GraphQL PV resolver (auth, rate limit, cache, audit)
            from core.config import published_views as _gql_pv_cfg
            from pathlib import Path as _GqlPath
            _gql_cache_dir = _GqlPath(_gql_pv_cfg.cache_dir) if _gql_pv_cfg else None
            set_pv_enterprise_deps(_gql_pv_cfg, db_manager, _gql_cache_dir)
        except Exception as _gql_exc:
            logger.debug("GraphQL dependency wiring skipped: %s", _gql_exc)

    # Initialise unified worker pool
    from core.config import worker_pool as _wp_cfg
    from core.worker_pool import init_pool
    init_pool(
        total_workers=_wp_cfg.total_workers,
        type_configs=_wp_cfg.build_type_configs(),
        drain_timeout=_wp_cfg.drain_timeout_seconds,
    )

    # 2026-09-15 -- say ONCE, at WARNING, when multi_pod is enabled but no
    # worker can be discovered (the shipped default: enabled=true, no
    # service, no urls, no registry).  Before this the only trace was a
    # DEBUG line per query and an engine-router record saying "0 pods".
    try:
        from core.multi_pod_dispatcher import log_multi_pod_state_once
        await asyncio.to_thread(log_multi_pod_state_once)
    except Exception as _mp_exc:
        logger.warning("[multi-pod] state check at startup failed: %s", _mp_exc)

    # Initialise query result cache
    from core.config import cache as _cache_cfg
    from core.query_cache import init_query_cache
    _cache_dir = _paths.data_dir / "cache"
    _cache_dir.mkdir(parents=True, exist_ok=True)
    init_query_cache(db_manager, _cache_dir,
                     ttl_seconds=_cache_cfg.ttl_seconds,
                     enabled=_cache_cfg.enabled)

    # Phase 104: Snapshot fingerprint service — partition-aware cache invalidation
    try:
        from core.snapshot_fingerprint import init_snapshot_fingerprint
        init_snapshot_fingerprint(db_manager, _cache_cfg)
    except Exception as _sfp_exc:
        logger.warning("[startup] Snapshot fingerprint service init failed (non-fatal): %s", _sfp_exc)

    # ── Circuit breaker initialisation ───────────────────────────────────
    from core.circuit_breaker import (
        init_circuit_breaker, set_broadcast_fn as cb_set_broadcast,
        load_circuit_breaker_states,
    )
    from core.config import circuit_breaker as _cb_cfg
    init_circuit_breaker(
        enabled=_cb_cfg.enabled,
        failure_threshold=_cb_cfg.failure_threshold,
        cooldown_seconds=_cb_cfg.cooldown_seconds,
        max_cooldown_seconds=_cb_cfg.max_cooldown_seconds,
    )
    # Phase 83B: Restore persisted OPEN circuit breaker states from DB
    try:
        load_circuit_breaker_states(db_manager)
    except Exception as _cb_load_exc:
        logger.warning("Circuit breaker state restore failed (non-fatal): %s", _cb_load_exc)

    def _cb_ws_broadcast(payload):
        """Sync broadcast helper for circuit breaker (called from thread-locked code)."""
        username = payload.pop("triggered_by", None) or payload.get("username")
        if username:
            asyncio.run_coroutine_threadsafe(
                ws_manager.broadcast_to_user(username, payload), loop)
        else:
            logger.debug("Circuit breaker broadcast dropped — no user in payload")

    cb_set_broadcast(_cb_ws_broadcast)

    # ── Anomaly detection initialisation (Phase 38) ──────────────────────
    from core.anomaly_detector import init_anomaly_detector
    from core.config import anomaly_detection as _anom_cfg
    init_anomaly_detector(
        enabled=_anom_cfg.enabled,
        z_score_threshold=_anom_cfg.z_score_threshold,
        min_history_runs=_anom_cfg.min_history_runs,
        window_size=_anom_cfg.window_size,
    )

    # ── Phase 134: S3 Performance modules initialisation ────────────────
    try:
        from core.config import s3 as _s3_perf_cfg
        # Footer stats cache
        if _s3_perf_cfg.footer_stats_enabled:
            from core.s3_footer_stats import FooterStatsCache
            _fs_dir = _s3_perf_cfg.footer_stats_dir or str(_paths.data_dir / "footer_stats_cache")
            FooterStatsCache.init_singleton(
                cache_dir=_fs_dir,
                ttl_hours=_s3_perf_cfg.footer_stats_ttl_hours,
            )
            logger.info("Phase 134: Footer stats cache enabled (ttl=%dh)", _s3_perf_cfg.footer_stats_ttl_hours)
        # File download cache -- DELETED 2026-09-07.
        #
        # ``core/s3_file_cache.py`` (Phase 134-D, 470 lines) was
        # constructed here on every boot and read by nobody.  Its last
        # consumer was removed ON PURPOSE when ``duckdb_subprocess``
        # migrated to the unified ``core.s3_predownload`` (the reason is
        # recorded in-code at duckdb_subprocess.py:2703); the parent
        # process never had one.  What remained was a singleton whose
        # only readers were an admin stats block that always reported
        # zero and a clear button for a directory that was always empty
        # -- plus a boot line telling operators a cache was enabled.
        #
        # The disk cache that IS on the S3 pre-download path is
        # ``s3_local_cache`` (BF-257), unaffected.
        #
        # STILL TO REMOVE (they live in files this change does not own):
        # the ``s3.file_cache_*`` properties and ``_DEFAULTS`` entries in
        # core/config.py, the matching keys on
        # ``/api/admin/s3-performance/config``, and the controls in
        # frontend/src/components/admin/S3PerformanceSection.tsx.  Those
        # four must go in one commit or the admin panel renders
        # undefined-valued inputs.  Guarded meanwhile by
        # tests/test_s3_readers_declared_2026_09_07.py::TestS3FileCacheIsGone.
        # S3 circuit breaker
        if _s3_perf_cfg.circuit_breaker_enabled:
            from core.s3_circuit_breaker import get_s3_circuit_breaker
            _s3_cb = get_s3_circuit_breaker()
            logger.info("Phase 134: S3 circuit breaker enabled (threshold=%d, cooldown=%ds)",
                        _s3_perf_cfg.circuit_breaker_threshold, _s3_perf_cfg.circuit_breaker_cooldown_seconds)
        # Scan quotas
        if _s3_perf_cfg.scan_quotas_enabled:
            logger.info("Phase 134: Scan quotas enabled")

        # Phase 139 (Tier 2.2): publish DuckDB tuning gauges so /metrics shows
        # the configured threads/memory at scrape time.
        try:
            from core.config import query_engine as _qe_pub
            from core.metrics import configure_duckdb_metrics
            _mb = int(_qe_pub.duckdb_memory_limit_mb)
            configure_duckdb_metrics(
                threads_per_query=int(_qe_pub.duckdb_threads_per_query),
                memory_limit_bytes=_mb * 1024 * 1024,
            )
            logger.info("Phase 139: DuckDB tuning published — threads=%d, memory=%dMB",
                        int(_qe_pub.duckdb_threads_per_query), _mb)
        except Exception as _qe_pub_err:
            logger.debug("Phase 139: DuckDB tuning publish skipped: %s", _qe_pub_err)
        # Cache encryption
        if _s3_perf_cfg.cache_encryption_enabled:
            from core.cache_crypto import CacheEncryption
            _cache_enc = CacheEncryption(enabled=True, key_source=_s3_perf_cfg.cache_encryption_key_source)
            if _cache_enc.is_available():
                logger.info("Phase 134: Cache encryption enabled (AES-256-GCM)")
        # PV warm-up
        from core.config import published_views as _pv_warmup_cfg
        if _pv_warmup_cfg.warmup_enabled:
            from api.published_views.warmup import set_warmup_dependencies, start_warmup
            set_warmup_dependencies(db_manager, _pv_warmup_cfg)
            start_warmup(loop)
            logger.info("Phase 134: PV warm-up enabled (interval=%dm)", _pv_warmup_cfg.warmup_interval_minutes)
    except Exception as _s3p_exc:
        logger.warning("Phase 134: S3 performance init failed (non-fatal): %s", _s3p_exc)

    # ── Phase 84F: NL Learning Engine initialisation ─────────────────────
    try:
        from core.nl_learning_engine import init_learning_engine
        init_learning_engine(db_manager)
    except Exception as _nle_exc:
        logger.warning("NL learning engine init failed (non-fatal): %s", _nle_exc)

    # ── Phase 95: Local LLM model pre-loading (background, non-blocking) ──
    try:
        from core.config import local_llm as _llm_cfg
        if _llm_cfg.enabled and _llm_cfg.startup_preload:
            import threading

            def _preload_llm_models():
                if _llm_cfg.embedder_enabled:
                    try:
                        from core.nl_learning_engine import init_embedder
                        init_embedder(_llm_cfg.embedder_model)
                    except Exception as _emb_exc:
                        logger.warning("Embedder pre-load failed (non-fatal): %s", _emb_exc)
                if _llm_cfg.sql_generation_enabled and _llm_cfg.model_path:
                    try:
                        from core.local_llm import init_local_llm
                        init_local_llm(
                            model_path=_llm_cfg.model_path,
                            n_ctx=_llm_cfg.n_ctx,
                            n_gpu_layers=_llm_cfg.n_gpu_layers,
                            model_name=_llm_cfg.model_name,
                        )
                    except Exception as _llm_exc:
                        logger.warning("Local LLM pre-load failed (non-fatal): %s", _llm_exc)

            threading.Thread(target=_preload_llm_models, daemon=True,
                             name="llm-preload").start()
            logger.info("Phase 95: LLM model pre-loading started in background")
    except Exception as _llm_init_exc:
        logger.warning("Phase 95 LLM init failed (non-fatal): %s", _llm_init_exc)

    # ── Connection pool initialisation (Phase 40) ─────────────────────────
    from core.connection_pool import init_connection_pool
    from core.config import connection_pool as _pool_cfg
    init_connection_pool(
        enabled=_pool_cfg.enabled,
        max_size=_pool_cfg.max_size,
        idle_timeout_seconds=_pool_cfg.idle_timeout_seconds,
    )

    # ── Auth deps (shared by sql_files + agents) ────────────────────────
    from api.deps import get_current_user as _get_current_user_dep, require_admin as _require_admin_dep

    # ── Phase 122C: SQL Files dependencies ─────────────────────────────
    # BF-107: Must be outside agents try/except — sql_files is independent.
    try:
        set_sql_files_dependencies(db_manager, _get_current_user_dep)
    except Exception as _sf_exc:
        logger.warning("SQL files init failed (non-fatal): %s", _sf_exc)

    # Phase 141 — Row & Column Security wiring.  The CRUD router needs the DB
    # manager; the rewriter module needs it for policy + audit lookups.  Both
    # are independent of agents/sql_files so we wire them outside any
    # surrounding try/except.
    try:
        set_row_security_dependencies(db_manager)
        set_entitlement_dependencies(db_manager)
        set_value_lists_dependencies(db_manager)
        set_report_themes_dependencies(db_manager)
        set_report_templates_dependencies(db_manager)
        set_report_parameter_templates_dependencies(db_manager)
        from core.row_security import set_db_manager as _rs_set_db
        _rs_set_db(db_manager)

        # SECURITY AUDIT 2026-08-03 (S7): wire the schema lookup the column-
        # policy rewriter needs.  set_schema_lookup() existed since Phase 141
        # but was NEVER called, so the rewriter always ran with
        # schema_lookup=None → MASK policies silently emitted SELECT *
        # (cleartext PII) and INCLUDE policies were ignored on every dialect.
        # Columns come from the SchemaCache DB table (populated by the schema
        # browser / execute paths); both the full dotted ref and its last
        # segment are tried so "db.schema.tbl" policies still resolve.
        from core.row_security import set_schema_lookup as _rs_set_schema

        def _rls_schema_lookup(table_ref: str, connection_id):
            if not connection_id or not table_ref:
                return []
            candidates = [table_ref]
            if "." in table_ref:
                candidates.append(table_ref.rsplit(".", 1)[-1])
            for _tname in candidates:
                try:
                    cached = db_manager.get_schema_cache(int(connection_id), _tname)
                except Exception:
                    cached = None
                if not cached:
                    continue
                _sd = cached.get("schema_data") or {}
                _cols = _sd.get("columns") or []
                names = [c.get("name") for c in _cols
                         if isinstance(c, dict) and c.get("name")]
                if names:
                    return names
            return []

        _rs_set_schema(_rls_schema_lookup)
        logger.info("Row & Column Security wired (Phase 141, schema lookup active)")
    except Exception as _rs_exc:
        logger.warning("Row & Column Security init failed (non-fatal): %s", _rs_exc)

    # Industrialization Phase 0 — bind the DB manager to the fleet-mode gate
    # so `industrialization.*` fleet flags probe the ACTUAL metadata backend
    # (PostgreSQL vs SQLite) instead of config intent.  All flags default OFF;
    # this wiring changes no behavior until a flag is armed.  Fail-open.
    try:
        from core.industrialization import bind_db_manager as _ind_bind_db
        _ind_bind_db(db_manager)
    except Exception as _ind_exc:
        logger.warning("Industrialization fleet-gate bind failed (non-fatal): %s", _ind_exc)

    # Industrialization Phase 2 — in-process job-queue executor.  A strict
    # no-op unless `industrialization.queue_mode` is armed (master switch +
    # flag + PostgreSQL fleet gate) AND this process's role runs executors
    # (QS_JOBQUEUE_EXECUTOR env override; else pod role worker/hybrid).
    # Same container image everywhere — the role is an env decision.
    try:
        from core.jobqueue.executor import start_in_process_executor_if_armed
        start_in_process_executor_if_armed(db_manager)
    except Exception as _jq_exc:
        logger.warning("Jobqueue executor bootstrap failed (non-fatal — queue "
                       "mode fails open to inline): %s", _jq_exc)
    # 2026-10-31 (query pods phase 2) -- the queue SWEEP in every process whose
    # queue mode is armed, executor or not: an API pod with every query pod
    # dead must still act on an expired lease (retry a declared read once,
    # else fail with the reason) and fail a sized run no pod can take
    # (core/jobqueue/sweeper.py; idempotent, N sweepers safe).
    try:
        from core.jobqueue.sweeper import start_queue_sweeper_if_armed
        start_queue_sweeper_if_armed(db_manager)
    except Exception as _jqs_exc:
        logger.warning("Jobqueue sweeper not started (non-fatal): %s", _jqs_exc)

    # Industrialization Phase 3 — leader-elected fleet syncer.  A strict
    # no-op unless `industrialization.fleet_syncer_enabled` is armed
    # (master switch + flag + PostgreSQL fleet gate) AND this process's
    # role runs background executors (same role contract as the queue
    # executor).  PG advisory lock guarantees ONE syncing pod fleet-wide.
    try:
        from core.industrialization.fleet_syncer import start_fleet_syncer_if_armed
        start_fleet_syncer_if_armed(db_manager)
    except Exception as _fs_exc:
        logger.warning("Fleet syncer bootstrap failed (non-fatal — readers "
                       "keep the manifest-walk fallback): %s", _fs_exc)

    # Phase 142 — User Drafts wiring + cleanup scheduler.
    try:
        set_user_drafts_dependencies(db_manager)
        from core.config import user_drafts as _ud_cfg
        if _ud_cfg.enabled and _ud_cfg.retention_days > 0:
            from apscheduler.triggers.interval import IntervalTrigger
            async def _user_drafts_cleanup_loop():
                while True:
                    try:
                        await asyncio.sleep(int(_ud_cfg.cleanup_interval_hours * 3600))
                        n = await asyncio.to_thread(
                            db_manager.cleanup_user_drafts,
                            int(_ud_cfg.retention_days),
                        )
                        if n:
                            logger.info("[user_drafts] cleanup removed %d stale drafts", n)
                    except asyncio.CancelledError:
                        raise
                    except Exception as _ud_exc:
                        logger.warning("[user_drafts] cleanup loop error: %s", _ud_exc)
            try:
                from core import background_jobs as _bj
                from core.config import get as _cfg_get_ud
                _ud_autostart = bool(_cfg_get_ud(
                    "background_jobs_autostart", "user_drafts_cleanup", True,
                ))
                _bj.register(
                    name="user_drafts_cleanup",
                    description=(
                        f"Phase 142 — daily cleanup of stale user drafts "
                        f"(retention_days={_ud_cfg.retention_days}, "
                        f"interval={_ud_cfg.cleanup_interval_hours}h)"
                    ),
                    factory=_user_drafts_cleanup_loop,
                    autostart=_ud_autostart,
                    controllable=True,
                )
            except Exception as _bjexc:
                logger.debug("[user_drafts] background_jobs register failed: %s", _bjexc)
        logger.info("User Drafts wired (Phase 142)")
    except Exception as _ud_exc:
        logger.warning("User Drafts init failed (non-fatal): %s", _ud_exc)

    # ── Phase 120: Self-Healing Agents ──────────────────────────────────
    try:
        from core.agents import init_orchestrator as _init_agents
        from core.config import _cfg
        _init_agents(_cfg, db_manager)
        set_agents_dependencies(db_manager, _get_current_user_dep, _require_admin_dep)
        from core.agents import get_orchestrator as _get_orch
        _orch = _get_orch()
        if _orch and _orch.enabled:
            logger.info("Phase 120: Agent orchestrator started (%d agents)", len(_orch.list_agents()))
        elif _orch and getattr(_orch, "refusal_reason", ""):
            # 2026-09-15: a REFUSAL (agents.decision_engine='llm' with no SDK
            # or key) is not "disabled".  The orchestrator already logged the
            # full reason at ERROR; this line must not contradict it.
            logger.error("Phase 120: Agent orchestrator REFUSED to start: %s",
                         _orch.refusal_reason)
        else:
            logger.info("Phase 120: Agent orchestrator disabled (agents.enabled=false)")
    except Exception as _agents_exc:
        logger.warning("Phase 120: Agent init failed (non-fatal): %s", _agents_exc)

    # ── Phase 120: DQ Monitor scheduler (asyncio periodic task) ───────────
    try:
        from core.agents import get_orchestrator as _get_orch_dq
        _orch_dq = _get_orch_dq()
        if _orch_dq and _orch_dq.enabled and _orch_dq.is_agent_enabled("dq_monitor"):
            from core.config import _cfg as _cfg_dq
            _dq_interval_minutes = int(_cfg_dq.get("agents", {}).get("dq_monitor", {}).get("schedule_minutes", 60))

            async def _dq_monitor_loop(_interval_s=_dq_interval_minutes * 60):
                """Periodic DQ monitor scan — runs every schedule_minutes."""
                _first_run = True
                while True:
                    if _first_run:
                        _first_run = False
                        await asyncio.sleep(15)  # brief delay for full startup
                    else:
                        await asyncio.sleep(_interval_s)
                    try:
                        _o = _get_orch_dq()
                        if _o and _o.enabled:
                            _dq_result = _o.run_dq_monitor()
                            # Any non-None result means NOTIFY_USER was triggered
                            if _dq_result:
                                _dq_user = _dq_result.get("triggered_by") or _dq_result.get("username")
                                _dq_msg = {
                                    "type": "agent_suggestion",
                                    "agent": "dq_monitor",
                                    "alerts_sent": _dq_result.get("alerts_sent", 0),
                                    "triggered_rules": _dq_result.get("triggered_rules", 0),
                                    "reason": _dq_result.get("reason", ""),
                                }
                                if _dq_user:
                                    await ws_manager.broadcast_to_user(_dq_user, _dq_msg)
                                else:
                                    logger.debug("DQ monitor result dropped — no user context")
                    except Exception as _dq_exc:
                        logger.warning("DQ monitor periodic scan failed: %s", _dq_exc)

            # BF-MGD-BG-JOBS: register via central background_jobs registry
            # so admin can pause / resume / inspect from /admin/background-jobs.
            try:
                from core import background_jobs as _bj_dq
                # BF-MGD-BG-JOBS-OPT-IN: autostart from config so admin
                # can flip via Helm OR /admin/app-config without code change.
                from core.config import get as _cfg_get
                _dq_autostart = bool(_cfg_get("background_jobs_autostart", "dq_monitor", False))
                _bj_dq.register(
                    name="dq_monitor",
                    description=f"Phase 120 — periodic data-quality scans (every {_dq_interval_minutes} min)",
                    factory=_dq_monitor_loop,
                    autostart=_dq_autostart,
                    controllable=True,
                )
                logger.info("Phase 120: DQ monitor registered (every %d min) — OFF by default, admin opts in via UI",
                             _dq_interval_minutes)
            except Exception as _bj_dq_exc:
                logger.warning("DQ monitor registry registration failed (falling back to direct task): %s",
                                _bj_dq_exc)
                global _dq_monitor_task
                _dq_monitor_task = _qs_track_bg(_dq_monitor_loop())
                logger.info("Phase 120: DQ monitor scheduled (every %d min)", _dq_interval_minutes)
    except Exception as _dq_sched_exc:
        logger.warning("Phase 120: DQ monitor scheduler init failed (non-fatal): %s", _dq_sched_exc)

    # ── Phase 120: Agent decision log cleanup (daily daemon thread) ───────
    try:
        _agent_log_days = int(_cfg.get("agents", {}).get("max_decision_log_days", 30))
        if _agent_log_days > 0:

            def _agent_cleanup_pass():
                try:
                    cleaned = db_manager.cleanup_agent_decisions(max_age_days=_agent_log_days)
                    if cleaned:
                        logger.info("Agent cleanup: removed %d old decision log entries", cleaned)
                except Exception as _acl_exc:
                    logger.warning("Agent cleanup failed: %s", _acl_exc)

            if _daemon_allowed("agent_log_cleanup"):
                # 5 min after startup, then once per day.
                _lifespan_threads.start_periodic(
                    "agent-log-cleanup", _agent_cleanup_pass,
                    first=300, every=86400)
    except Exception as _acl_init_exc:
        logger.warning("Phase 120: Agent cleanup init failed (non-fatal): %s", _acl_init_exc)

    # ── 2026-09-16: the memory watchdog can finally cancel ───────────────
    # core/memory_guard.py::set_cancel_callback documents itself as "Called
    # by execute_api / multi_worker_executor at startup so the watchdog can
    # issue cancels without cyclic imports" -- and nothing called it, so
    # _CANCEL_CALLBACK was permanently None.  Same shape as the
    # set_active_lease gap: a mechanism designed, documented, and missing
    # its one call.
    #
    # It is the watchdog's FALLBACK: the primary path is a per-query
    # cancel_hook, and this covers executions registered without one.  With
    # neither wired the watchdog's only remaining move was to log "COULD NOT
    # cancel ... memory pressure persists", which is an honest message about
    # a capability that was never connected.
    try:
        from core.memory_guard import set_cancel_callback as _mg_set_cancel

        def _cancel_via_pool(execution_id: str, reason: str) -> bool:
            """Signal the pool-registered cancel event for this execution.

            Returns False when there is nothing registered — the watchdog
            reads that as "could not cancel" and says so, which is the
            truth rather than a silent success.
            """
            try:
                from core.duckdb_cancel import lookup_cancel_event
                ev = lookup_cancel_event(str(execution_id or ""))
            except Exception as _lc_exc:
                logger.debug("memory_guard cancel lookup failed for %s: %s",
                             execution_id, _lc_exc)
                return False
            if ev is None:
                return False
            ev.set()
            logger.warning("memory_guard: cancel signalled for %s (%s)",
                           execution_id, reason)
            return True

        _mg_set_cancel(_cancel_via_pool)
    except Exception as _mg_exc:
        logger.warning("memory_guard cancel callback not wired "
                       "(non-fatal): %s", _mg_exc)

    # ── 2026-09-16: connection pooling reads its config (and says if it
    # is inert).  init_connection_pool had NO caller, so
    # connection_pool.enabled / max_size / idle_timeout_seconds were read by
    # nothing and the module defaults were the only values that ever
    # applied.  Calling it does not make pooling happen -- nothing acquires
    # a pooled connector -- but it stops three declared keys being fiction,
    # and it logs the inert state once at startup instead of leaving an
    # operator to infer it from an always-empty admin list.
    try:
        from core.config import connection_pool as _cp_cfg
        from core.connection_pool import init_connection_pool as _cp_init
        _cp_init(enabled=bool(_cp_cfg.enabled),
                 max_size=int(_cp_cfg.max_size),
                 idle_timeout_seconds=int(_cp_cfg.idle_timeout_seconds))
    except Exception as _cp_exc:
        logger.warning("connection pool config not applied (non-fatal): %s",
                       _cp_exc)

    # ── 2026-09-15: two retentions that were declared and never swept ────
    # row_security.audit_retention_days (30) and
    # delivery.delivery_history_retention_days (90) both shipped as promises
    # with no mechanism, so row_security_audit and delivery_history grew
    # without bound.  The RLS sweep's DELETE had even been WRITTEN
    # (DatabaseManager.cleanup_row_security_audit) and never called.
    #
    # Gated by the SAME names the scheduler pod registers
    # (core/retention_daemons.py::JOB_IDS, core/daemon_registry.py::
    # SCHEDULER_OWNED), so a hybrid/embedded pod runs them here and an
    # api/worker split moves them rather than deleting them -- the whole
    # point of the 2026-08-20 relocation, and what three guards in
    # tests/test_pod_role_honours_scheduler_mode_2026_08_19.py enforce.
    #
    # Unlike the five older sweeps these do NOT re-implement their DELETE in
    # an inline loop: they call the same run_* functions the registry calls,
    # so there is one implementation and a fix cannot land on one pod only.
    try:
        from core.retention_daemons import (
            run_delivery_history_cleanup as _run_dhc,
            run_rls_audit_cleanup as _run_rac,
        )

        def _guarded(fn, label, what="sweep"):
            """One pass of ``fn(db_manager)``; a failure is logged, never
            raised (the loop runs again next interval)."""
            def _pass():
                try:
                    fn(db_manager)
                except Exception as _rexc:   # never kill the thread
                    logger.warning("%s %s failed: %s", label, what, _rexc)
            return _pass

        def _daily(name, fn, label):
            # 5 min after startup, then daily; stopped by the lifespan.
            _lifespan_threads.start_periodic(
                name, _guarded(fn, label), first=300, every=86400)

        # Written out rather than looped over a tuple of names ON PURPOSE.
        # test_the_gated_names_match_the_registered_names greps main.py for
        # the literal _daemon_allowed("<job_id>"), because an operator asking
        # "where does this sweep run?" greps one name across three files.
        # Passing the name through a variable satisfies the intent and defeats
        # the check -- and that check caught two real omissions in this very
        # change, so it earns the verbosity.
        if _daemon_allowed("rls_audit_cleanup"):
            _daily("rls-audit-cleanup", _run_rac, "row security audit")
        if _daemon_allowed("delivery_history_cleanup"):
            _daily("delivery-history-cleanup", _run_dhc, "delivery history")
        if _daemon_allowed("query_log_cleanup"):
            from core.retention_daemons import (
                run_query_log_cleanup as _run_qlc,
            )
            _daily("query-log-cleanup", _run_qlc, "query logs")
        # 2026-10-03 -- the shared rate limiter's finished windows, hourly
        # (the scheduler pod registers the same run_* function).
        if _daemon_allowed("rate_limit_window_cleanup"):
            from core.retention_daemons import (
                run_rate_limit_window_cleanup as _run_rlw,
            )

            # 5 min after startup, then hourly.
            _lifespan_threads.start_periodic(
                "rate-limit-window-cleanup",
                _guarded(_run_rlw, "rate limit window"),
                first=300, every=3600)
        # 2026-09-27 -- the daily close-out digest: a due-check TICK every
        # close_out_digest_check_interval_seconds (not daily -- the send
        # time is configured, the tick only asks "is it past that time and
        # not yet sent").  Same relocatable arrangement as the sweeps above.
        if _daemon_allowed("feed_close_out_digest"):
            from core.retention_daemons import (
                close_out_digest_interval_seconds as _cod_every,
                run_feed_close_out_digest as _run_cod,
            )

            # 1 min after startup, then every configured tick.
            _lifespan_threads.start_periodic(
                "feed-close-out-digest",
                _guarded(_run_cod, "feed close-out digest", "tick"),
                first=60, every=_cod_every())
        # 2026-09-28 -- the feed CONSUMER late watcher: a tick every
        # consumer_late_check_interval_seconds that raises ONE "late" notice
        # per (feed, business date) past its SLA with nothing delivered, to
        # the consumers subscribed to it.  Same relocatable arrangement.
        if _daemon_allowed("feed_consumer_late_watch"):
            from core.retention_daemons import (
                consumer_late_watch_interval_seconds as _clw_every,
                run_feed_consumer_late_watch as _run_clw,
            )

            # 1 min after startup, then every configured tick.
            _lifespan_threads.start_periodic(
                "feed-consumer-late-watch",
                _guarded(_run_clw, "feed consumer late watch", "tick"),
                first=60, every=_clw_every())
        # 2026-10-07 -- the FILE arrival watcher: lists each declared
        # file-dependency location for the WAIT runs in the window and
        # records the arrival once the files (and the control file) land;
        # the dependency poller then releases the run.  Same relocatable
        # arrangement; the tick itself acts only in the scheduler-lock
        # holder, so hybrid replicas list once.
        if _daemon_allowed("feed_dependency_file_watch"):
            from core.retention_daemons import (
                dependency_file_watch_interval_seconds as _dfw_every,
                run_feed_dependency_file_watch as _run_dfw,
            )

            # 1 min after startup, then every configured tick.
            _lifespan_threads.start_periodic(
                "feed-dependency-file-watch",
                _guarded(_run_dfw, "feed dependency file watch", "tick"),
                first=60, every=_dfw_every())
        # 2026-10-11 -- the ORACLE-TABLE arrival watcher: reads each configured
        # upstream Oracle table's new rows (the OG QS_KAFKA_MESSAGE landing
        # table), resolves them through the Kafka resolver rules and records
        # the arrivals; the dependency poller then releases the run.  Same
        # relocatable arrangement; the tick acts only in the scheduler-lock
        # holder.
        if _daemon_allowed("feed_dependency_oracle_table_watch"):
            from core.retention_daemons import (
                dependency_oracle_table_watch_interval_seconds as _dotw_every,
                run_feed_dependency_oracle_table_watch as _run_dotw,
            )

            # 30 s after startup, then every configured tick.
            _lifespan_threads.start_periodic(
                "feed-dependency-oracle-table-watch",
                _guarded(_run_dotw, "feed dependency oracle table watch", "tick"),
                first=30, every=_dotw_every())
        # 2026-10-13 -- feed template requests queued FROM SQL
        # (qs_feed_template_apply(), core/feed/template_requests.py); the tick
        # acts only in the scheduler-lock holder.
        if _daemon_allowed("feed_template_requests"):
            from core.retention_daemons import (
                FEED_TEMPLATE_REQUESTS_INTERVAL_SECONDS as _ftr_every,
                run_feed_template_requests as _run_ftr,
            )

            _lifespan_threads.start_periodic(
                "feed-template-requests",
                _guarded(_run_ftr, "feed template requests", "tick"),
                first=30, every=_ftr_every)
        # 2026-10-17 -- the published-API rollup's tick (core/published_api/
        # rollup.py): the dashboard's numbers, folded by the scheduler-lock
        # holder, never on the published-api pod's hot path.  Same relocatable
        # arrangement as the sweeps above.
        if _daemon_allowed("published_api_rollup"):
            from core.retention_daemons import (
                published_api_rollup_interval_seconds as _par_every,
                run_published_api_rollup as _run_par,
            )

            _lifespan_threads.start_periodic(
                "published-api-rollup",
                _guarded(_run_par, "published-api rollup", "tick"),
                first=60, every=_par_every())
        # 2026-10-24 -- the daily value-list sync's tick (core/value_lists.py::
        # tick): a list whose sync_every_hours has passed is re-synced.
        if _daemon_allowed("value_list_sync"):
            from core.retention_daemons import (
                VALUE_LIST_SYNC_INTERVAL_SECONDS as _vls_every,
                run_value_list_sync as _run_vls,
            )

            _lifespan_threads.start_periodic(
                "value-list-sync",
                _guarded(_run_vls, "value-list sync", "tick"),
                first=90, every=_vls_every)
        # 2026-11-02 -- the scheduler dead-man (core/component_health/
        # scheduler_deadman.py): a standalone install's own process holds the
        # lock it watches, so it only says the lock is fresh -- gated like every
        # daemon so a split install runs it on the job-worker alone.
        if _daemon_allowed("scheduler_deadman"):
            from core.retention_daemons import run_scheduler_deadman as _run_sdm
            from core.component_health.scheduler_deadman import INTERVAL_SECONDS as _sdm_every

            _lifespan_threads.start_periodic(
                "scheduler-deadman",
                _guarded(_run_sdm, "scheduler dead-man", "tick"),
                first=120, every=_sdm_every)
        # 2026-10-29 -- the query-pod scaler (core/query_pods/scaler.py): per
        # size, watch KEDA or scale the Deployment; the lock holder acts.
        if _daemon_allowed("query_pod_scaler"):
            from core.retention_daemons import (
                query_pod_scaler_interval_seconds as _qps_every,
                run_query_pod_scaler as _run_qps,
            )

            _lifespan_threads.start_periodic(
                "query-pod-scaler",
                _guarded(_run_qps, "query-pod scaler", "tick"),
                first=60, every=_qps_every())
        # Lake Formation policy refresh — the interval key finally has a
        # reader.  Same relocatable arrangement: here on a hybrid pod, on the
        # scheduler pod in a split.  Inert while
        # row_security.lake_formation_sync_enabled is false.
        if _daemon_allowed("lake_formation_sync"):
            from core.row_security.lake_formation_daemon import (
                run_lake_formation_sync as _run_lfs,
            )
            from core.config import row_security as _lf_cfg_main
            _lf_hours = max(1, int(getattr(
                _lf_cfg_main, "lake_formation_sync_interval_hours", 6)))

            # 5 min after startup, then every interval.
            _lifespan_threads.start_periodic(
                "lake-formation-sync",
                _guarded(_run_lfs, "lake formation"),
                first=300, every=_lf_hours * 3600)
    except Exception as _ret_init_exc:
        logger.warning("retention sweeps init failed (non-fatal): %s",
                       _ret_init_exc)

    # ── Phase 132: Generic DataFlow Engine (NEW capability) ─────────────────
    # Brand-new module under core.dataflow/.  Does NOT touch feed_gen,
    # reports, BQB, CQB, or any other existing feature.  Auto-starts the
    # scheduler when ``dataflows.scheduler_autostart=true`` (default false
    # — admin opts in via /api/dataflows/scheduler/start or POSTing a
    # schedule + tick).
    try:
        from core.dataflow import init_workflow_subsystem

        def _wf_ws_broadcast(payload: dict):
            """Forward dataflow events to WebSocket — same shape as
            the feed broadcast helper."""
            username = (payload.get("triggered_by")
                        or payload.get("username"))
            try:
                if username:
                    asyncio.run_coroutine_threadsafe(
                        ws_manager.broadcast_to_user(username, payload), loop)
                else:
                    asyncio.run_coroutine_threadsafe(
                        ws_manager.broadcast(payload), loop)
            except Exception as _wf_bx_exc:
                logger.debug("[dataflow] broadcast forward failed: %s", _wf_bx_exc)

        _wf_cfg = _cfg.get("dataflows", {}) if isinstance(_cfg, dict) else {}
        _wf_poll = int(_wf_cfg.get("scheduler_poll_seconds", 30))
        _wf_max_conc = int(_wf_cfg.get("max_concurrent_runs", 8))
        _wf_autostart = bool(_wf_cfg.get("scheduler_autostart", False))
        # Phase 161 -- api-only pods don't autostart the DataFlow
        # scheduler even when yaml says so.  Init is still needed so
        # HTTP handlers can trigger manual runs, but the poll loop
        # stays off.
        from core.pod_role import should_run as _pr_should_run_wf
        if _wf_autostart and not _pr_should_run_wf(
            "dataflow_scheduler_autostart", scheduler_mode=None,
        ):
            _wf_autostart = False

        # Leader gate — without an is_leader_fn the DataFlow scheduler
        # defaults to always-leader, so every embedded/hybrid pod would
        # fire the same schedules.  Reuse the SAME scheduler leader lease
        # the cron daemons use so only the leader fires DataFlow schedules.
        # 2026-10-18: the ONE election -- the scheduler LOCK, as on the worker
        from core.daemon_registry import holds_single_runner_role as _wf_is_leader_lock
        _wf_subsys = init_workflow_subsystem(
            db_manager=db_manager,
            broadcast_fn=_wf_ws_broadcast,
            poll_seconds=_wf_poll,
            max_concurrent_runs=_wf_max_conc,
            is_leader_fn=lambda: _wf_is_leader_lock(),
            auto_start_scheduler=_wf_autostart,
        )
        # Reuse the scheduler's executor for ad-hoc API-triggered runs so
        # we don't spawn unbounded threads.
        _wf_dispatch_executor = _wf_subsys["scheduler"]._executor

        set_workflow_dependencies(
            db_manager=db_manager,
            get_current_user_dep=_get_current_user_dep,
            require_admin_dep=_require_admin_dep,
            engine=_wf_subsys["engine"],
            dispatcher=_wf_subsys["dispatcher"],
            scheduler=_wf_subsys["scheduler"],
            dispatch_executor=_wf_dispatch_executor,
        )

        # Phase 132.29 — SAP task config CRUD API.  Same deps as the
        # rest of the DataFlow surface; reused audit helper.
        try:
            from api.sap_tasks_api import set_sap_tasks_dependencies
            # 2026-09-01 -- core.audit exposes ``audit_event``, not
            # ``audit``.  The ImportError was caught by the handler below,
            # so these dependencies were NEVER wired -- the feature was
            # inert while the log line said only "deps not wired".
            from core.audit import audit_event as _shared_audit
            set_sap_tasks_dependencies(
                db_manager=db_manager,
                get_current_user_dep=_get_current_user_dep,
                require_admin_dep=_require_admin_dep,
                audit_fn=_shared_audit,
            )
        except Exception as _sap_dep_exc:
            logger.warning("[main] sap_tasks_api deps not wired: %s",
                            _sap_dep_exc)

        # Phase 132.33 — live SAP-OData passthrough deps + engine init.
        try:
            from api.sap_passthrough_api import set_sap_passthrough_dependencies
            from core.sap_passthrough import init_passthrough
            # 2026-09-01 -- core.audit exposes ``audit_event``, not
            # ``audit``.  The ImportError was caught by the handler below,
            # so these dependencies were NEVER wired -- the feature was
            # inert while the log line said only "deps not wired".
            from core.audit import audit_event as _shared_audit_pt
            set_sap_passthrough_dependencies(
                db_manager=db_manager,
                get_current_user_dep=_get_current_user_dep,
                require_admin_dep=_require_admin_dep,
                audit_fn=_shared_audit_pt,
            )
            init_passthrough(db_manager)
            logger.info("Phase 132.33: SAP-OData passthrough engine ready")
        except Exception as _spt_dep_exc:
            logger.warning("[main] sap_passthrough_api deps not wired: %s",
                            _spt_dep_exc)

        # Phase 132.21 — notification policy engine (event-driven email
        # / webhook / ws on run lifecycle events).  Wire AFTER the
        # dispatcher so its lazy lookup of get_notification_engine() picks
        # this up.  Same broadcast fn → per-user WS routing.
        try:
            from core.dataflow.notification_policy import init_notification_engine
            init_notification_engine(db_manager, broadcast_fn=_wf_ws_broadcast)
            logger.info("Phase 132.21: notification policy engine initialised")
        except Exception as _np_exc:
            logger.warning("Phase 132.21: notification engine init failed: %s",
                            _np_exc)

        # Phase 132.25 — proactive mid-flight SLA scanner (catches SLA
        # breach as soon as the deadline elapses, not only at run end).
        # Phase 161 -- gated so api-only pods don't hold a scanner
        # thread + poll loop.
        try:
            from core.pod_role import should_run as _pr_should_run_sla
            if _pr_should_run_sla("sla_scanner", scheduler_mode=None):
                from core.dataflow.sla_scanner import init_sla_scanner
                _sla_scanner = init_sla_scanner(
                    db_manager,
                    poll_seconds=int(_wf_cfg.get("sla_scan_seconds", 60)),
                )
                asyncio.run_coroutine_threadsafe(_sla_scanner.start(), loop)
                logger.info("Phase 132.25: SLA scanner started")
        except Exception as _sla_exc:
            logger.warning("Phase 132.25: SLA scanner init failed: %s", _sla_exc)

        # Phase 132.25 — GitOps file-watcher (optional, off by default).
        _gitops_enabled = bool(_wf_cfg.get("gitops_enabled", False))
        _gitops_dir = _wf_cfg.get("gitops_directory")
        if _gitops_enabled and _gitops_dir:
            try:
                from core.dataflow.gitops import init_gitops_watcher
                _gitops = init_gitops_watcher(
                    directory=_gitops_dir,
                    engine=_wf_subsys["engine"],
                    db_manager=db_manager,
                    poll_seconds=int(_wf_cfg.get("gitops_poll_seconds", 30)),
                )
                if _gitops is not None:
                    asyncio.run_coroutine_threadsafe(_gitops.start(), loop)
                    logger.info("Phase 132.25: GitOps watcher started (dir=%s)",
                                  _gitops_dir)
            except Exception as _git_exc:
                logger.warning("Phase 132.25: GitOps init failed: %s", _git_exc)
        logger.info(
            "Phase 132: DataFlow engine wired (%d stage types, scheduler %s)",
            _wf_subsys["stage_count"],
            "autostart=on" if _wf_autostart else "autostart=off",
        )
        if _wf_autostart:
            try:
                asyncio.run_coroutine_threadsafe(
                    _wf_subsys["scheduler"].start(), loop)
            except Exception as _wf_sched_start_exc:
                logger.warning(
                    "Phase 132: dataflow scheduler autostart failed: %s",
                    _wf_sched_start_exc,
                )
    except Exception as _wf_init_exc:
        logger.warning("Phase 132: DataFlow engine init failed (non-fatal): %s",
                       _wf_init_exc, exc_info=True)
        # Phase 132.30 — stash so the 503 surface can show operators
        # what went wrong without forcing them into the pod log.
        try:
            import traceback as _tb
            from core.dataflow import set_init_error as _set_wf_init_err
            _set_wf_init_err(
                f"{type(_wf_init_exc).__name__}: {_wf_init_exc}",
                _tb.format_exc(),
            )
        except Exception:
            pass

    # ── Spark Connect session manager (optional, gated by config) ────────
    try:
        from core.config import spark_connect as _sc_cfg
        if _sc_cfg.enabled:
            from core.spark_connect_session_manager import (
                init_spark_connect_manager as _init_sc,
                start_cleanup_task as _start_sc_cleanup,
            )

            async def _sc_broadcast(username: str, payload: dict) -> None:
                await ws_manager.broadcast_to_user(username, payload)

            _init_sc(_sc_cfg, db_manager, _sc_broadcast)
            # BF-MGD-BG-JOBS: register cleanup loop in admin registry
            try:
                from core import background_jobs as _bj_sc
                # BF-MGD-BG-JOBS-OPT-IN: autostart from config
                from core.config import get as _cfg_get_sc
                _sc_cl_autostart = bool(_cfg_get_sc("background_jobs_autostart", "spark_connect_cleanup", False))
                _bj_sc.register(
                    name="spark_connect_cleanup",
                    description="Spark Connect — evict idle gRPC sessions periodically",
                    factory=_start_sc_cleanup,
                    autostart=_sc_cl_autostart,
                    controllable=True,
                )
            except Exception:
                _qs_track_bg(_start_sc_cleanup())
            logger.info("Spark Connect session manager started (server=%s)", _sc_cfg.server_url)
        else:
            logger.debug("Spark Connect disabled (spark_connect.enabled=false)")
    except Exception as _sc_init_exc:
        logger.warning("Spark Connect init failed (non-fatal): %s", _sc_init_exc)

    # ── BF-428: Pluggable S3 reader strategies ────────────────────────────
    # Registers DirectHttpfs + FullPredownload (Phase A) and any
    # additional strategies shipped in later phases (PyArrow+S3FS,
    # SmartPredownload, S3 Select, Athena).  MUST run before any query
    # path so the router has a non-empty registry on first request.
    try:
        from core.s3_readers import register_default_readers, available_readers
        register_default_readers()
        logger.info("S3 readers registered: %s", available_readers())
        # BF-428F: install cost-based auto-router (gated by
        # s3_readers.auto_route_enabled — defaults True).  Replaces
        # Phase A's simple proxy heuristic with a per-query cost model
        # that also considers file count, file size estimate, presence
        # of SQL string, etc.  Falls back silently when kill-switched.
        try:
            from core.s3_readers.router_costmodel import install_cost_router
            install_cost_router()
        except Exception as _cr_exc:
            logger.warning("S3 cost-router install failed (non-fatal — "
                           "Phase A binary heuristic remains): %s", _cr_exc)
    except Exception as _s3r_exc:
        logger.warning("S3 reader registration failed (non-fatal — falls "
                       "back to legacy direct path): %s", _s3r_exc)

    # ── Checkpoint recovery (Phase 41) ────────────────────────────────────
    from core.checkpoint import (init_checkpoint, recover_incomplete,
                                 recover_orphaned_published_view_executions)
    init_checkpoint(db_manager)
    _recovered = recover_incomplete()
    if _recovered:
        logger.info("Checkpoint: recovered %d orphaned executions", _recovered)
    # 2026-10-07 (F11): published-view rows hold no checkpoint; reconcile
    # the ones no live process can own (older than the stale threshold).
    recover_orphaned_published_view_executions()
    # 2026-10-29 -- this process's heartbeat on the runs it holds, and the sweep
    # that fails any run whose process went silent (a restart, a deploy) in
    # ~2.5 min instead of 9,000 s.
    try:
        from core.checkpoint import start_heartbeat as _cp_start_hb
        _cp_start_hb()
    except Exception as _cphb_exc:
        logger.warning("checkpoint heartbeat not started (non-fatal): %s", _cphb_exc)

    # ── Queue backend initialisation ─────────────────────────────────────
    from core.queue_backend import init_queue_backend
    init_queue_backend(db_manager)
    logger.info("Queue backend initialised")

    # ── Scheduler initialisation (mode-dependent) ──────────────────────────
    from core.config import scheduler as _sched_cfg
    import threading as _threading

    # Deep-dive #10 (2026-06-30) -- BLOOM SCANNER VISIBILITY.
    # Operator report: "why i dont see blooming filter scan job?"
    # This is the THIRD report of this bug (Phase 154 in commit e523d2e
    # fixed the external-mode case; deep-dive #10 fixes the embedded +
    # leader-election case).
    #
    # Root cause: the placeholder registration below used to be gated
    # on ``if _sched_cfg.mode == "external":``.  In embedded mode
    # (default) the REAL registration happens inside
    # init_prefetch_scheduler which is only called on the LEADER pod
    # (leader-election in _start_scheduler waits for the lease before
    # touching APScheduler).  Non-leader pods therefore never registered
    # ANYTHING in background_jobs -- admins hitting a non-leader pod
    # saw an empty list and thought bloom was missing.  Additionally,
    # even the leader pod's registration happens inside a daemon thread
    # so admin UI queries during the ~seconds-long lease acquisition
    # window saw an empty list.
    #
    # Fix: register the placeholders UNCONDITIONALLY, right here at
    # startup (main event loop, not the scheduler daemon thread).  The
    # leader pod's init_prefetch_scheduler later idempotently
    # OVERWRITES the "adaptive_prefetch" entry with its richer
    # description (background_jobs.register is a plain dict assign
    # -- last-writer-wins).  Non-leader pods keep the placeholder so
    # admin UI always shows the job.
    try:
        from core import background_jobs as _bj_brain_uni
        _BRAIN_DAEMONS_FOR_UI_UNI = [
            ("adaptive_prefetch",
             "THIS IS THE BLOOM FILTER SCANNER."
             "  Adaptive bloom + supplement scanner: reads"
             " query_pruning_history hourly, ranks top filter columns,"
             " fires bloom + supplement scans for the (table, col)"
             " pairs lacking coverage.  On embedded mode this runs"
             " in-process on the leader pod; on external mode it runs"
             " on the scheduler pod.  Manual trigger via POST"
             " /api/admin/iceberg/bloom/scan."),
            ("iceberg_mirror_daemon",
             "Iceberg metadata mirror -- materialises iceberg "
             "snapshots to a fast-read mirror table."),
            ("plain_parquet_mirror_daemon",
             "Plain parquet metadata mirror -- column-stats + "
             "row-count sidecar so reads skip footer scans."),
            ("pruning_alerts_daemon",
             "Pruning-health alerts -- watches pruning_health "
             "metrics + fires email/webhook on regressions."),
            ("brain_coordinator_daemon",
             "Brain coordinator -- single arbiter that sets the "
             "process-wide pressure flag the other brain daemons "
             "consult before running heavy work."),
            ("portal_cred_prewarmer",
             "Portal credential pre-warmer -- keeps the "
             "aws_portal_auth cred cache populated."),
            ("output_gateway_cleanup",
             "Output gateway cleanup -- drops stale download "
             "files past TTL."),
            ("plain_parquet_sync",
             "Plain parquet supplement sync -- writes column "
             "stats + bloom sidecars for plain-parquet (non-"
             "iceberg) tables."),
        ]
        for _d_name, _d_desc in _BRAIN_DAEMONS_FOR_UI_UNI:
            _bj_brain_uni.register(
                name=_d_name,
                description=_d_desc,
                factory=lambda: None,
                autostart=False,     # placeholder -- real daemon fires elsewhere
                controllable=True,   # admin pause/resume propagates via DB
            )
        logger.info(
            "Registered %d brain-daemon placeholders in background_jobs "
            "for admin UI visibility (mode=%s)",
            len(_BRAIN_DAEMONS_FOR_UI_UNI), _sched_cfg.mode,
        )
    except Exception as _bj_uni_exc:
        logger.warning(
            "Brain-daemon placeholder registration failed "
            "(non-fatal -- daemons still run wherever they own the "
            "heartbeat): %s", _bj_uni_exc,
        )

    # 2026-08-19 -- THE POD ROLE MUST GATE THIS TOO.
    #
    # This branch was keyed on scheduler.mode ALONE, so a pod started with
    # QS_POD_ROLE=api but the default scheduler.mode=embedded fell into the
    # else-branch below and started APScheduler plus EVERY brain daemon --
    # iceberg mirror, output gateway, pruning alerts, brain cleanup, the
    # coordinator, the prewarmer, shadow auto-apply, parquet sync and the
    # plain-parquet mirror.  Setting the role did nothing here, which is the
    # single largest block of background work in the process and exactly what
    # core/pod_role.py was introduced to control ("single-source-of-truth
    # gate for background work").
    #
    # An api-role pod takes the same path as scheduler.mode=external: register
    # the UI placeholders, start no daemons.  A worker/hybrid pod is
    # unaffected, so scheduler_worker.py and single-pod dev keep working.
    try:
        from core.pod_role import current as _pr_sched
        _role_is_api = _pr_sched().is_api()
    except Exception as _pr_sched_exc:      # pragma: no cover - safety net
        logger.debug("pod-role gate unavailable for the scheduler block "
                     "(falling back to scheduler.mode): %s", _pr_sched_exc)
        _role_is_api = False

    if _sched_cfg.mode == "external" or _role_is_api:
        # External mode (or an api-role pod): the scheduler runs elsewhere.
        # Start a notification poller/subscriber to relay WS notifications.
        from core.config import queue as _queue_cfg
        global _notification_poller_task
        # BF-MGD-BG-JOBS: register in admin registry.  controllable=False —
        # external scheduler mode REQUIRES this poller to ferry sched-
        # generated notifications back to the API pod's WS layer.  Pausing
        # would silently break /admin/iceberg-sync/status etc.
        try:
            from core import background_jobs as _bj_np
            from core.config import get as _cfg_get_np
            _np_autostart = bool(_cfg_get_np(
                "background_jobs_autostart", "notification_poller", True,
            ))
            # controllable=True so admin can pause / resume at runtime.
            # WARNING surfaced in the description so the admin UI shows
            # the consequence before they click Pause: cross-pod
            # notifications stop flowing, so live progress / sync-status
            # updates won't reach the WebSocket layer until resumed.
            if _queue_cfg.backend == "redis":
                from core.notification_poller import run_notification_subscriber
                from core.queue_backend import get_notification_queue
                _bj_np.register(
                    name="notification_poller",
                    description=(
                        "Scheduler-pod → API-pod notification bridge (Redis pub/sub). "
                        "⚠ Pausing this stops live sync-status / progress updates from "
                        "reaching the UI until resumed."
                    ),
                    factory=lambda: run_notification_subscriber(get_notification_queue(), ws_manager),
                    autostart=_np_autostart,
                    controllable=True,
                )
                logger.info("Scheduler mode=external — notification subscriber registered (Redis pub/sub)")
            else:
                from core.notification_poller import run_notification_poller
                _bj_np.register(
                    name="notification_poller",
                    description=(
                        f"Scheduler-pod → API-pod notification bridge (DB poll every "
                        f"{_sched_cfg.notification_poll_interval:.1f}s). "
                        "⚠ Pausing this stops live sync-status / progress updates "
                        "from reaching the UI until resumed."
                    ),
                    factory=lambda: run_notification_poller(
                        db_manager.SessionLocal, ws_manager,
                        interval=_sched_cfg.notification_poll_interval,
                    ),
                    autostart=_np_autostart,
                    controllable=True,
                )
                logger.info("Scheduler mode=external — notification poller registered (%.1fs interval)",
                             _sched_cfg.notification_poll_interval)
        except Exception:
            # Fallback to bg_tasks-tracked task if registry fails.  Was
            # unmanaged asyncio.create_task which silently leaked + got
            # GC'd mid-await (Python #88831).
            if _queue_cfg.backend == "redis":
                from core.notification_poller import run_notification_subscriber
                from core.queue_backend import get_notification_queue
                _notification_poller_task = _qs_track_bg(
                    run_notification_subscriber(get_notification_queue(), ws_manager)
                )
            else:
                from core.notification_poller import run_notification_poller
                _notification_poller_task = _qs_track_bg(
                    run_notification_poller(
                        db_manager.SessionLocal, ws_manager,
                        interval=_sched_cfg.notification_poll_interval,
                    )
                )

        # ── Download Centre pod: reclaim what it serves ──────────────────
        # 2026-08-30.  The pod that hands out the files also retires them —
        # one owner for the whole lifecycle, no pod doing half a job.
        # Started by _DOWNLOADS_MODE rather than by the pod-role gate on
        # purpose: role=api means "none of the daemon fleet", and this is not
        # incidental background work, it is this pod's own duty.  The
        # scheduler skips reclamation whenever the declared owner is not
        # itself, so exactly one sweeper runs.
        #
        # Tracked via bg_tasks so a rolling deploy cancels it cleanly — a
        # bare create_task leaks and can be GC'd mid-await.
        if _DOWNLOADS_MODE:
            try:
                from core.download_retention import (
                    downloads_cleanup_owner as _dl_owner)
                if _dl_owner() == "downloads":
                    _qs_track_bg(_downloads_reclaim_loop(db_manager))
                    logger.info("[downloads] retention sweep started "
                                "(every %ds) — this pod owns reclamation",
                                _DOWNLOADS_RECLAIM_INTERVAL_S)
                else:
                    logger.info("[downloads] retention sweep NOT started — "
                                "storage.downloads_cleanup_owner=%r owns it",
                                _dl_owner())
            except Exception as _dl_exc:
                # Fail-open for SERVING: a pod that cannot sweep must still
                # hand out files.  Read-time expiry already refuses lapsed
                # downloads, so nothing stale is served either way.
                logger.warning("[downloads] retention sweep could not start "
                               "(serving unaffected): %s", _dl_exc)

        # Phase 154 (2026-06-25) -- multi-pod admin visibility.
        # Operator 2026-06-25: "still i dont see blooming filter
        # batckground jobs".  Root cause: when scheduler.mode=external,
        # the brain daemons (adaptive_prefetch / bloom scanner /
        # iceberg_mirror / pruning_alerts / etc.) register in the
        # SCHEDULER pod's background_jobs registry.  The API pod's
        # admin UI calls background_jobs.list_jobs() which is per-
        # process -- so the API-pod admin sees an empty list.
        #
        # Fix: register the SAME daemon names in the API pod's
        # registry as PLACEHOLDERS (factory=lambda: None so they
        # don't fire; controllable=True so admin pause/resume actions
        # land in the DB-backed pause state which the scheduler pod
        # checks every tick).  This way:
        #   * Admin UI shows the full list of brain daemons.
        #   * Pause/Resume actions sync to the scheduler pod via DB.
        #   * Descriptions explicitly say "runs on scheduler pod".
        #
        # The list MUST mirror scheduler_worker.py's _daemons tuple.
        # CI test (test_phase_154_admin_bloom_visibility) source-greps
        # both files to lock the parity.
        try:
            from core import background_jobs as _bj_brain
            _BRAIN_DAEMONS_FOR_UI = [
                ("iceberg_mirror_daemon",
                 "Iceberg metadata mirror -- materialises iceberg "
                 "snapshots to a fast-read mirror table.  Runs on "
                 "scheduler pod; this row is a UI placeholder so "
                 "Pause/Resume sync via DB-backed pause state."),
                ("plain_parquet_mirror_daemon",
                 "Plain parquet metadata mirror -- column-stats + "
                 "row-count sidecar so reads skip footer scans.  "
                 "Runs on scheduler pod; placeholder for UI."),
                ("adaptive_prefetch",
                 "Adaptive bloom + supplement scanner.  Reads "
                 "query_pruning_history hourly, ranks top filter "
                 "columns, fires bloom + supplement scans for the "
                 "(table, col) pairs lacking coverage.  This IS the "
                 "bloom filter scanner.  Runs on scheduler pod; "
                 "placeholder for UI.  Manual trigger via POST "
                 "/api/admin/iceberg/bloom/scan."),
                ("pruning_alerts_daemon",
                 "Pruning-health alerts -- watches pruning_health "
                 "metrics + fires email/webhook on regressions.  "
                 "Runs on scheduler pod; placeholder for UI."),
                ("brain_coordinator_daemon",
                 "Brain coordinator -- single arbiter that sets the "
                 "process-wide pressure flag the other brain daemons "
                 "consult before running heavy work.  Runs on "
                 "scheduler pod; placeholder for UI."),
                ("portal_cred_prewarmer",
                 "Portal credential pre-warmer -- defeats the "
                 "cold-portal 30s budget bug by keeping the "
                 "aws_portal_auth cred cache populated.  Runs on "
                 "scheduler pod; placeholder for UI."),
                ("output_gateway_cleanup",
                 "Output gateway cleanup -- drops stale download "
                 "files past TTL.  Runs on scheduler pod; "
                 "placeholder for UI."),
                ("plain_parquet_sync",
                 "Plain parquet supplement sync -- writes column "
                 "stats + bloom sidecars for plain-parquet (non-"
                 "iceberg) tables.  Runs on scheduler pod; "
                 "placeholder for UI."),
            ]
            for _d_name, _d_desc in _BRAIN_DAEMONS_FOR_UI:
                # factory=lambda: None signals "scheduler pod owns
                # the heartbeat; this entry exists for UI + pause
                # state propagation only".  background_jobs._wrap
                # handles None-factory by sleeping forever (already
                # locked by test_iceberg_manifest_watcher_*).
                _bj_brain.register(
                    name=_d_name,
                    description=_d_desc,
                    factory=lambda: None,
                    autostart=False,  # placeholder -- never starts here
                    controllable=True,
                )
            logger.info(
                "Scheduler mode=external -- registered %d brain daemon "
                "placeholders in API-pod background_jobs registry for "
                "admin UI visibility", len(_BRAIN_DAEMONS_FOR_UI),
            )
        except Exception as _bj_brain_exc:
            logger.warning(
                "Brain daemon placeholder registration failed "
                "(non-fatal -- scheduler pod still runs them): %s",
                _bj_brain_exc,
            )

        # ── portal_cred_prewarmer: A PROCESS-LOCAL WARM NEEDS A LOCAL
        #    WARMER (2026-09-07) ────────────────────────────────────────
        #
        # ``aws_portal_auth._cred_cache`` is a module-level dict, so the
        # daemon warms exactly ONE process.  register_prewarmer_daemon is
        # called from the embedded branch below, i.e. on the daemon host —
        # and every deployed query-serving chart is pod.role="api"
        # (querystudioapi-helm: worker x4, reports x2, published-api,
        # downloads), which lands HERE.  Those pods were therefore paying
        # the cold-portal resolution the module exists to remove, while
        # showing a "Runs on scheduler pod" placeholder that read as
        # protection they did not have.  This registration REPLACES that
        # placeholder (background_jobs.register is a dict assign, and this
        # runs after the loop above) with a real, controllable warm task
        # that populates THIS process's cache.
        #
        # It is deliberately the only daemon started on an api-role pod:
        # its whole purpose is this pod's first-query latency, and its cost
        # is a handful of STS resolutions every 8 minutes.
        try:
            from core.portal_cred_prewarmer import (
                start_local_prewarm_task as _start_local_prewarm,
            )
            _start_local_prewarm(db_manager, scheduler_mode=_sched_cfg.mode)
        except Exception as _pcp_local_exc:
            logger.warning(
                "portal_cred_prewarmer local warm task not started on this "
                "query-serving pod (non-fatal -- credentials still resolve "
                "lazily, paying the cold cost on the first query): %s",
                _pcp_local_exc,
            )
    else:
        # Embedded mode (default): start APScheduler in-process, same as before.
        from core.scheduler import init_scheduler, set_broadcast_fn

        def _ws_broadcast(payload):
            # 2026-10-07: an ADDRESSED payload (a feed event's ``audience``
            # list, or a ``username``) is delivered to exactly those names
            # (event_bus.recipients_of, inside deliver_addressed); a
            # scheduler payload that names only ``triggered_by`` keeps its
            # per-user route; one with no address at all is dropped, as
            # before -- never broadcast to every browser.
            from core.event_bus import recipients_of as _recipients_of
            _actor = payload.pop("triggered_by", None)
            if _recipients_of(payload) is None and _actor:
                payload["username"] = _actor
            if _recipients_of(payload):
                _coro = ws_manager.deliver_addressed(payload)
                try:
                    asyncio.run_coroutine_threadsafe(_coro, loop)
                except Exception:
                    # a closed loop: close the coroutine (no 'never awaited'
                    # leak) and raise so emit_ws_event falls through to the queue
                    _coro.close()
                    raise
            else:
                logger.debug("Scheduler broadcast dropped — no user in payload")

        set_broadcast_fn(_ws_broadcast)

        # 2026-09-27 -- the cross-process relay runs on an embedded/hybrid pod
        # too.  Only one process holds the scheduler lock; when that is ANOTHER
        # process (a scheduler pod, a second hybrid) everything it produces --
        # feed_dep_ready / feed_dep_wait_escalated, iceberg sync status, DQ
        # alerts -- arrives only through the notification queue, and until
        # now nothing on this pod read it: found live on the Docker rig, the
        # escalation was queued and no browser ever received it.  No double
        # delivery: this process's own scheduler broadcasts directly (above),
        # never through the queue.
        try:
            from core import background_jobs as _bj_relay
            from core.config import get as _cfg_get_relay
            from core.config import queue as _queue_cfg_relay
            if _queue_cfg_relay.backend == "redis":
                from core.notification_poller import run_notification_subscriber as _relay_sub
                from core.queue_backend import get_notification_queue as _relay_q
                _relay_factory = lambda: _relay_sub(_relay_q(), ws_manager)  # noqa: E731
            else:
                from core.notification_poller import run_notification_poller as _relay_poll
                _relay_factory = lambda: _relay_poll(  # noqa: E731
                    db_manager.SessionLocal, ws_manager,
                    interval=_sched_cfg.notification_poll_interval)
            _bj_relay.register(
                name="notification_poller",
                description=(
                    "Cross-process notification bridge: events raised by the "
                    "scheduler lock holder in ANOTHER process reach this pod's "
                    "WebSocket clients.  ⚠ Pausing this stops them."),
                factory=_relay_factory,
                autostart=bool(_cfg_get_relay(
                    "background_jobs_autostart", "notification_poller", True)),
                controllable=True,
            )
            logger.info("Embedded/hybrid pod -- cross-process notification "
                        "relay registered (%s)", _queue_cfg_relay.backend)
        except Exception as _relay_exc:
            logger.error("Cross-process notification relay NOT registered: %s "
                         "-- events raised by another process's scheduler will "
                         "not reach this pod's browsers", _relay_exc)

        # Autostart gate — when scheduler.autostart=false the scheduler
        # is initialized but starts PAUSED so admin must hit
        # POST /api/admin/scheduler/resume to begin firing jobs.  Default
        # true keeps historical behaviour; flip to false for maintenance
        # windows / blue-green cutovers / debugging stuck schedules.
        try:
            from core.config import scheduler as _sched_autostart_cfg
            _sched_autostart = bool(getattr(_sched_autostart_cfg, "autostart", True))
        except Exception:
            _sched_autostart = True

        # Captured NOW (this lifespan's event), not looked up in the thread.
        _sched_lifespan_stop = _lifespan_threads.stop_event()

        def _start_scheduler():
            # If the interpreter has already started finalising (typical in
            # pytest shutdown: the daemon thread loses its race against the
            # main thread's exit), bail out cleanly.  Importing apscheduler
            # at that point chains through concurrent.futures.process whose
            # module-level threading._register_atexit() raises
            # "can't register atexit after shutdown".  And logging would
            # error too because pytest has closed its captured streams.
            if sys.is_finalizing():
                return
            try:
                # BF-410.4 — leader election gate.  If multiple replicas of
                # this process exist (rolling upgrade overlap, or someone
                # bumped scheduler.replicaCount), only the lease holder
                # runs APScheduler; the others poll for the lease.
                from core.scheduler_lease import SchedulerLease
                _lease_enabled = True
                try:
                    from core.config import scheduler as _sl_cfg
                    _lease_enabled = bool(getattr(_sl_cfg, "leader_election_enabled", True))
                except Exception:
                    pass

                if _lease_enabled:
                    # BF-414 — wire pause/resume callbacks so a lost lease
                    # actually STOPS the scheduler (was: just flipped a
                    # bool, while APScheduler kept firing jobs).  Without
                    # this, both pods continued to run scheduled jobs
                    # during a renew failure — defeating the entire point
                    # of leader election during the highest-risk window.
                    from core.scheduler import (
                        pause_scheduler as _pause_sched,
                        resume_scheduler as _resume_sched,
                    )
                    _lease = SchedulerLease(
                        db_manager,
                        on_lost=_pause_sched,
                        on_acquired=_resume_sched,
                    )
                    while not _lease.try_acquire():
                        logger.info(
                            "[scheduler-lease] another pod is the leader; waiting %ds",
                            _lease.renew_every,
                        )
                        # 2026-10-04 -- wait on THIS lifespan's stop event:
                        # a shutdown while still waiting must not go on to
                        # start a scheduler for an app that has finished.
                        if _sched_lifespan_stop.wait(_lease.renew_every):
                            logger.info(
                                "[scheduler-lease] lifespan stopped while "
                                "waiting for the lease; scheduler not started")
                            return
                    _lease.run_renew_loop()
                    # 2026-09-16 -- REGISTER THE LIVE LEASE.  Its docstring
                    # says "Called by the scheduler bootstrap"; this IS that
                    # bootstrap and never called it, so get_active_lease() was
                    # always None and is_scheduler_leader() fell to a DB read.
                    # Correct only by coincidence.  What was lost: a pod that
                    # LOSES the lease knowing instantly, rather than believing
                    # it is still leader until the row expires.
                    try:
                        from core.scheduler_lease import set_active_lease
                        set_active_lease(_lease)
                    except Exception as _sal_exc:   # pragma: no cover
                        logger.warning(
                            "[scheduler-lease] could not register the live "
                            "lease; leader checks fall back to a DB read: %s",
                            _sal_exc)
                    # Stash on app state so the shutdown handler can release it
                    try:
                        app.state.scheduler_lease = _lease
                    except Exception:
                        pass

                init_scheduler(db_manager, db_url=_DB_URL, start_paused=not _sched_autostart)
                # 2026-09-28 -- the singleton daemons above were gated on
                # holding THIS lock, before it was taken: on the pod that
                # just won it, start them now rather than a lock-retry
                # interval later when the deferral watcher notices.  A pod
                # that did not win keeps its deferrals (the watcher drains
                # them if the holder dies and the retry wins).
                try:
                    from core.daemon_registry import (
                        drain_deferred_singletons as _drain_singletons,
                    )
                    _drained = _drain_singletons()
                    if _drained:
                        logger.info("[singleton-gate] started after winning "
                                    "the scheduler lock: %s",
                                    ", ".join(sorted(_drained)))
                except Exception as _drain_exc:
                    logger.warning("[singleton-gate] drain after lock win "
                                   "failed (the watcher thread retries): %s",
                                   _drain_exc)
                # 2026-09-28 -- THE ROLLING-DEPLOY CASE, hybrid side.  Every
                # registration below needs the APScheduler this process may
                # NOT be running yet: when the previous pod's lock heartbeat
                # is still fresh, init_scheduler returned early above,
                # get_daemon_scheduler() is None, and each block warned
                # "registration failed" once and was never retried -- the
                # lock-retry win minutes later ran none of them.  The block
                # is now a function handed to core.scheduler's started-hook
                # (the ONE place that knows APScheduler started here): it runs
                # right away when the lock was won above, and on the retry
                # thread's start otherwise.  Same seam the scheduler pod's
                # daemon_registry.register_scheduler_owned uses.
                def _hybrid_apscheduler_registrations() -> None:
                    # Phase 133 — wire the 2-hourly reconciliation check job
                    # onto the same scheduler.  Idempotent (safe to re-run on
                    # multi-pod startup).
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.reconciliation_scheduler import (
                            init_reconciliation_scheduler,
                        )
                        init_reconciliation_scheduler(
                            _sched_singleton, db_manager,
                            interval_hours=2,
                        )
                    except Exception as _reco_exc:
                        logger.warning(
                            "[reconciliation-scheduler] registration failed: %s",
                            _reco_exc,
                        )
                    # Phase 149.7 — wire the 24h adaptive-prefetch job onto the
                    # shared scheduler.  Reads query_pruning_history, ranks
                    # top-N filter cols by occurrence, fires supplement +
                    # bloom scans for the (table, col) pairs lacking coverage.
                    # Default ON; disable via iceberg.adaptive_prefetch.enabled=false.
                    # Idempotent (safe to re-run on multi-pod startup).
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.query_history_prefetcher import (
                            init_prefetch_scheduler,
                        )
                        # 149.10 — hourly (was 24h) so brain coverage stays
                        # fresh against hourly iceberg writes; the cadence is
                        # query_history_prefetcher.resolve_interval_hours()
                        # (declared iceberg.adaptive_prefetch.interval_hours),
                        # not a value passed from here (2026-10-07).
                        init_prefetch_scheduler(_sched_singleton, db_manager)
                        # 149.10 — register the BrainFreshness ensure_fresh
                        # listener on the watcher's snapshot-change event so
                        # any roll-forward dispatches a delta scan within
                        # seconds (no 1h wait for the cron).  Best-effort —
                        # listener exceptions never block the watcher.
                        try:
                            from core.database import register_snapshot_change_listener
                            from core.brain_freshness import ensure_fresh as _ef
                            from core.query_history_prefetcher import (
                                make_default_s3_client_factory,
                            )
                            _bf_s3_factory = make_default_s3_client_factory(db_manager)

                            def _on_snapshot_change(connection_id, bucket,
                                                      table_prefix,
                                                      old_snapshot_id,
                                                      new_snapshot_id):
                                try:
                                    _ef(
                                        db_manager, _bf_s3_factory,
                                        bucket, table_prefix,
                                        source="watcher",
                                        blocking=False,
                                    )
                                except Exception as _ef_exc:
                                    logger.debug(
                                        "[149.10] brain_freshness on_change "
                                        "dispatch failed: %s", _ef_exc,
                                    )
                                # Phase 150 — mirror invalidation hook: when
                                # source snapshot rolls forward, mark every
                                # mirror for (bucket, prefix) whose snapshot
                                # != new_snapshot_id as stale.  Best-effort.
                                try:
                                    from core.iceberg_mirror import (
                                        on_snapshot_rollforward as _mirror_roll,
                                    )
                                    _mirror_roll(
                                        db_manager, bucket, table_prefix,
                                        current_snapshot_id=str(new_snapshot_id)
                                                           if new_snapshot_id else None,
                                        previous_snapshot_id=str(old_snapshot_id)
                                                           if old_snapshot_id else None,
                                    )
                                except Exception as _mr_exc:
                                    logger.debug(
                                        "[150] mirror on_snapshot_rollforward "
                                        "dispatch failed: %s", _mr_exc,
                                    )

                            # 2026-10-04 -- REPLACE, not add.  The registry
                            # de-dupes on identity and this closure is new on
                            # every lifespan, so each app start appended one
                            # more listener holding its own db_manager (and
                            # firing against it) for the life of the process.
                            global _brain_freshness_snapshot_listener
                            from core.database import (
                                unregister_snapshot_change_listener as _unreg_scl,
                            )
                            if _brain_freshness_snapshot_listener is not None:
                                _unreg_scl(_brain_freshness_snapshot_listener)
                            register_snapshot_change_listener(_on_snapshot_change)
                            _brain_freshness_snapshot_listener = _on_snapshot_change
                            logger.info(
                                "[149.10] brain_freshness watcher hook registered",
                            )
                        except Exception as _bf_hook_exc:
                            logger.warning(
                                "[149.10] brain_freshness watcher hook "
                                "registration failed (cron daemon still runs "
                                "as primary): %s", _bf_hook_exc,
                            )
                    except Exception as _pref_exc:
                        logger.warning(
                            "[adaptive-prefetch] registration failed: %s",
                            _pref_exc,
                        )

                    # Phase 150 — wire the iceberg_mirror daemon onto the
                    # shared scheduler.  Skips when iceberg.mirror.enabled=false
                    # (Stage 1 ships SHADOW only — operator flips the kill
                    # switch after observing zero divergence per table).
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.iceberg_mirror import register_mirror_daemon
                        register_mirror_daemon(_sched_singleton, db_manager)
                    except Exception as _mir_exc:
                        logger.warning(
                            "[150] mirror daemon registration failed: %s",
                            _mir_exc,
                        )

                    # Phase 150 — wire the output_gateway cleanup daemon
                    # onto the same scheduler.  Skips when output_gateway.
                    # enabled=false (default).
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.output_gateway import (
                            register_output_gateway_daemon,
                        )
                        register_output_gateway_daemon(_sched_singleton, db_manager)
                    except Exception as _gw_exc:
                        logger.warning(
                            "[150] output_gateway daemon registration failed: %s",
                            _gw_exc,
                        )

                    # Phase 148.D — pruning alerts daemon.  Always registers;
                    # tick no-ops when pruning_health.alerts.enabled=false
                    # so flipping the flag at runtime takes effect on the
                    # next tick.
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.pruning_alerts import register_alerts_daemon
                        register_alerts_daemon(_sched_singleton, db_manager)
                    except Exception as _al_exc:
                        logger.warning(
                            "[148.D] pruning alerts daemon registration "
                            "failed: %s", _al_exc,
                        )

                    # 2026-09-10 -- Clockwork alert NOTIFIER.  ``clockwork_alerts``
                    # rows were written by the dispatcher and read by nothing;
                    # this daemon tells the job's owner / owner group (or the
                    # deployment fallback) ONCE per alert identity.  Owned by the
                    # scheduler pod through core.daemon_registry.SCHEDULER_OWNED;
                    # registered here for hybrid mode so it runs on SOME pod in
                    # every topology.
                    try:
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.clockwork.notifier import register_notifier_daemon
                        register_notifier_daemon(_sched_singleton, db_manager)
                    except Exception as _cwn_exc:
                        logger.warning(
                            "[clockwork.notify] daemon registration failed "
                            "(non-fatal): %s", _cwn_exc,
                        )

                    # 2026-10-17 -- component health FLEET WATCHER: probes the
                    # dependencies once for everyone, derives the fleet rows,
                    # confirms transitions, raises alerts through the one
                    # alert road.  Owned by the scheduler pod through
                    # core.daemon_registry.SCHEDULER_OWNED; registered here for
                    # hybrid mode so it runs on SOME pod in every topology.
                    if _daemon_allowed("component_health_fleet_watcher"):
                        try:
                            from core.scheduler import get_daemon_scheduler as _gds
                            _sched_singleton = _gds()
                            from core.component_health.fleet_watcher import register_fleet_watcher_daemon
                            register_fleet_watcher_daemon(_sched_singleton, db_manager)
                        except Exception as _chw_exc:
                            logger.warning(
                                "[component_health] fleet watcher registration failed "
                                "(non-fatal): %s", _chw_exc,
                            )

                    # Phase 156 (2026-06-25) -- brain table cleanup.
                    # Keeps brain_pruning_memo + brain_route_outcome
                    # bounded.  Tick is cheap (two DELETEs per sweep,
                    # default every 6h).
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.brain_cleanup_daemon import register_cleanup_daemon
                        register_cleanup_daemon(_sched_singleton, db_manager)
                    except Exception as _bc_exc:
                        logger.warning(
                            "[Phase 156] brain cleanup daemon registration "
                            "failed: %s", _bc_exc,
                        )

                    # BrainCoordinator — single arbiter that sets the
                    # process-wide pressure flag the other brain daemons
                    # consult before running heavy work.  Always registers;
                    # tick no-ops when brain_coordinator.enabled=false.
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.brain_coordinator import (
                            register_coordinator_daemon,
                        )
                        register_coordinator_daemon(
                            _sched_singleton, db_manager,
                        )
                    except Exception as _bc_exc:
                        logger.warning(
                            "BrainCoordinator daemon registration failed: %s",
                            _bc_exc,
                        )

                    # Portal cred pre-warmer — defeats the cold-portal 30s
                    # budget bug by keeping the aws_portal_auth._cred_cache
                    # populated on a background interval.  User queries
                    # against portal-backed S3 connections hit a warm cache
                    # and skip the 20s cold-portal resolution.
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.portal_cred_prewarmer import (
                            register_prewarmer_daemon,
                        )
                        register_prewarmer_daemon(
                            _sched_singleton, db_manager,
                        )
                    except Exception as _pcp_exc:
                        logger.warning(
                            "portal_cred_prewarmer registration failed: %s",
                            _pcp_exc,
                        )

                    # Writer Advisor SHADOW auto-apply daemon — walks
                    # recommendations on a cron and marks high-leverage
                    # ones status='shadow' in the ledger.  2026-06-10
                    # audit fix — previously SHADOW had only an admin
                    # endpoint, so flipping the flag did nothing autonomously.
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.writer_advisor import (
                            register_shadow_auto_apply_daemon,
                        )
                        register_shadow_auto_apply_daemon(
                            _sched_singleton, db_manager,
                        )
                    except Exception as _wa_exc:
                        logger.warning(
                            "writer_advisor SHADOW daemon registration "
                            "failed: %s", _wa_exc,
                        )

                    # Phase 151.A — plain parquet metadata sync daemon.
                    # Extends the brain to plain-parquet S3 tables that
                    # have no iceberg manifest.  Always-register pattern;
                    # tick reads plain_parquet.sync_enabled and short-
                    # circuits when off so runtime flag flips work without
                    # a pod restart.
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.plain_parquet_metadata_sync import (
                            register_parquet_sync_daemon,
                        )
                        register_parquet_sync_daemon(
                            _sched_singleton, db_manager,
                        )
                    except Exception as _pp_exc:
                        logger.warning(
                            "plain_parquet sync daemon registration "
                            "failed: %s", _pp_exc,
                        )
                    # Phase 151.E — plain parquet mirror daemon.  Builds
                    # logical mirrors for parquet tables (default flag-OFF
                    # = SHADOW posture).  Cleanup runs even with build flag
                    # off so existing rows can be aged out via admin tick.
                    try:
                        # 2026-08-20 -- daemon jobs go through the proxy so their
                        # closure ticks land in the memory 'daemon' jobstore (the
                        # persistent store silently rejected them).
                        from core.scheduler import get_daemon_scheduler as _gds
                        _sched_singleton = _gds()
                        from core.plain_parquet_mirror import (
                            register_mirror_daemon as _reg_pp_mirror,
                        )
                        _reg_pp_mirror(_sched_singleton, db_manager)
                    except Exception as _pp_mirror_exc:
                        logger.warning(
                            "plain_parquet mirror daemon registration "
                            "failed: %s", _pp_mirror_exc,
                        )
                    # 2026-09-28 (found live on Docker) -- the registrations
                    # above create background_jobs entries (brain / mirror
                    # daemons).  When this hook fires on a LATE lock win the
                    # boot-time autostart_all() is long past, so start them
                    # here, on the event loop.  Idempotent.
                    try:
                        from core.daemon_registry import (
                            DaemonContext as _DCtx,
                            _autostart_new_jobs as _autostart_late,
                        )
                        _autostart_late(_DCtx(db_manager, loop=loop))
                    except Exception as _as_exc:
                        logger.error(
                            "late-registered background jobs could not be "
                            "autostarted: %s", _as_exc)
                from core.scheduler import (
                    on_apscheduler_started as _on_aps_started,
                )
                if not _on_aps_started(_hybrid_apscheduler_registrations):
                    logger.warning(
                        "APScheduler is not running in this process (the "
                        "scheduler lock is held elsewhere) -- the daemon "
                        "registrations that need it will register when this "
                        "process wins the scheduler lock")
            except Exception as exc:
                # Same shutdown-race guard as the entry point: if pytest /
                # the interpreter has begun finalising, suppress the log
                # since writing to closed streams just produces noise.
                if sys.is_finalizing():
                    return
                try:
                    logger.error("APScheduler startup failed (non-fatal): %s", exc, exc_info=True)
                except (ValueError, OSError):
                    pass

        # 2026-08-19 -- this branch was gated ONLY by scheduler.mode, never
        # by the pod role.  A pod explicitly stamped QS_POD_ROLE=api whose
        # config still resolved scheduler.mode=embedded (the code default)
        # therefore booted the ENTIRE fleet behind APScheduler: the 20-thread
        # job pool plus reconciliation, the adaptive-prefetch/bloom scanner,
        # the iceberg + plain-parquet mirrors, output-gateway cleanup, the
        # brain coordinator and the portal credential prewarmer.  That is the
        # ~20 GB footprint pod_role.py was written to remove, and role=api
        # did not remove it -- which is exactly "we made separate pods and
        # the API pod is still doing background work".
        #
        # role=api means no background daemons, full stop; the mode check
        # stays for hybrid/worker.  This can only start FEWER daemons.
        _sched_role_ok = True
        try:
            from core.pod_role import current as _pod_role_current
            _sched_role_ok = _pod_role_current().should_run(
                "apscheduler_embedded", scheduler_mode=_sched_cfg.mode)
        except Exception as _role_exc:
            # Fail-open: an unreadable role must not leave a single-pod
            # deployment with no scheduler at all.
            logger.debug("pod-role gate unavailable for APScheduler "
                         "(starting anyway): %s", _role_exc)
        if _sched_role_ok:
            _threading.Thread(target=_start_scheduler, daemon=True).start()
        else:
            logger.info(
                "APScheduler NOT started: pod role forbids background "
                "daemons (scheduler.mode=%s). The scheduler pod owns them.",
                getattr(_sched_cfg, "mode", "?"),
            )

    # ── Executor poller (external mode only) ──────────────────────────────
    from core.config import executor as _exec_cfg
    if _exec_cfg.mode == "external":
        # 2026-11-02 -- DEPRECATED road (docs/COMPONENT_RESPONSIBILITIES_2026_11_02.html
        # §5): a query too heavy for this pod goes to a QUERY POD of the right
        # size (query_pods.classes), the one road.  `external` still works -- the
        # job-worker drains task_queue -- so a switch mid-flight strands nothing,
        # but every API should be `embedded`; said loudly, once, at start.
        logger.warning(
            "executor.mode=external is DEPRECATED: interactive queries belong on this pod or "
            "on a query pod (query_pods.classes); the task_queue road is kept only to drain. "
            "Set executor.mode=embedded on every API pod.")
        from core.config import queue as _queue_cfg2
        global _executor_poller_task
        if _queue_cfg2.backend == "redis":
            from core.executor_poller import run_executor_subscriber
            from core.queue_backend import get_task_queue
            _executor_poller_task = _qs_track_bg(
                run_executor_subscriber(get_task_queue(), ws_manager)
            )
            logger.info("Executor mode=external — subscriber started (Redis pub/sub)")
        else:
            from core.executor_poller import run_executor_poller
            _executor_poller_task = _qs_track_bg(
                run_executor_poller(db_manager, ws_manager, _exec_cfg.notification_poll_interval)
            )
            logger.info("Executor mode=external — poller started (%.1fs interval)",
                         _exec_cfg.notification_poll_interval)

    # ── WebSocket heartbeat (detect dead connections) ─────────────────────
    # BF-WS-NOBLOCK-2: 10s WS server ping (was 30s).  More responsive to
    # transient event-loop slowdowns — corporate WS proxies typically idle-
    # close at 30-60s, so a more frequent ping keeps the connection alive
    # AND surfaces dead clients faster (5s send timeout per send).  Per-
    # ping cost is one tiny JSON write per connection; negligible.
    await ws_manager.start_heartbeat(interval=10)
    logger.info("WebSocket heartbeat started (30s interval)")

    # ── Phase 139 honest-fix #1 — stale-query auto-cancel ────────────────
    # Check every 30s for executions whose frontend hasn't sent a heartbeat
    # in 60+ seconds. Likely browser closed / tab navigated away. Cancel
    # them to free up DuckDB / S3 / connector resources.
    async def _stale_query_cancel_loop():
        from core.execution_state import (
            get_stale_executions, remove_heartbeat, cancellation_flags,
            _gc_orphan_engine_progress,
        )
        from core.config import get as _cfg_get
        # Phase 141 honest-fix: bump CLIENT heartbeat grace to 180s and
        # require ENGINE progress to ALSO be stale before cancelling.
        # Old behaviour (60s, no engine check) killed actively-progressing
        # 16-minute queries when corporate proxies dropped the WebSocket
        # mid-query.  Now the cancel only fires when both the client
        # has gone away AND the engine has stopped progressing — i.e.
        # the genuine "browser closed / pod hung" case.  Both thresholds
        # are config-tunable (smart_cancel section) so admins can widen
        # them if their corporate proxy idle timeout is longer than 3 min.
        while True:
            try:
                await asyncio.sleep(int(_cfg_get("smart_cancel", "check_interval_seconds", 30) or 30))
                _client_stale = float(_cfg_get("smart_cancel", "client_stale_seconds", 180) or 180)
                _engine_stale = float(_cfg_get("smart_cancel", "engine_progress_grace_seconds", 120) or 120)
                stale = get_stale_executions(
                    stale_timeout_seconds=_client_stale,
                    engine_progress_grace_seconds=_engine_stale,
                )
                # Bug-fix: clean orphan engine-progress entries (CLI/scheduled
                # executions stamp progress but never have a client heartbeat
                # → remove_heartbeat is never called for them → memory leak).
                _gc_n = _gc_orphan_engine_progress(max_age_seconds=3600.0)
                if _gc_n > 0:
                    logger.debug("[stale-cancel] gc'd %d orphan engine-progress entries", _gc_n)
                for eid in stale:
                    try:
                        ev = cancellation_flags.get(eid)
                        if ev is None:
                            # Already-completed execution — just clean up the heartbeat record
                            remove_heartbeat(eid)
                            continue
                        # Set the cancel event so the worker thread sees it
                        ev.set()
                        try:
                            db_manager.update_execution(
                                eid, status="cancelled",
                                error_message=(
                                    "Cancelled — both the client heartbeat AND engine progress "
                                    "stopped (browser closed / pod hung).  If you closed the tab "
                                    "by accident, just run the query again."
                                ),
                            )
                        except Exception:
                            pass
                        try:
                            # 2026-08-02 fleet routing: was
                            # ``ws_manager.broadcast_to_all`` — a method that
                            # has never existed on WebSocketManager, so this
                            # AttributeError'd into the except below and the
                            # cancel notice NEVER reached any client.  Now a
                            # real broadcast, which also relays cross-pod.
                            await ws_manager.broadcast({
                                "type":         "execution_cancelled",
                                "execution_id": eid,
                                "reason":       "heartbeat_timeout",
                                "timestamp":    datetime.now(timezone.utc).isoformat(),
                            })
                        except Exception as _cancel_ws_exc:
                            logger.debug("stale-cancel WS notice failed "
                                         "(non-fatal): %s", _cancel_ws_exc)
                        remove_heartbeat(eid)
                        logger.info("[stale-cancel] Auto-cancelled execution %s — no heartbeat for >60s", eid)
                    except Exception as exc:
                        logger.debug("[stale-cancel] failed to cancel %s: %s", eid, exc)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("[stale-cancel] loop error (continuing): %s", exc)
    # BF-MGD-BG-JOBS: register in admin registry.  controllable=False —
    # this is a SAFETY net for stuck queries; pausing it would let
    # stale executions hang indefinitely.  Visible in admin UI as
    # always-running, no pause button.
    try:
        from core import background_jobs as _bj_sc2
        from core.config import get as _cfg_get_sq
        _sq_autostart = bool(_cfg_get_sq(
            "background_jobs_autostart", "stale_query_cancel", True,
        ))
        # controllable=True with warning: admin CAN pause but should
        # know that stuck executions will sit consuming resources until
        # the next pod restart while paused.
        _bj_sc2.register(
            name="stale_query_cancel",
            description=(
                "Phase 141 — smart-cancel: kills executions where BOTH the client "
                "heartbeat AND the engine progress are stale (180s client / 120s "
                "engine, checks every 30s). "
                "⚠ Pausing this lets stuck queries linger until the pod restarts."
            ),
            factory=_stale_query_cancel_loop,
            autostart=_sq_autostart,
            controllable=True,
        )
        logger.info("Phase 139: stale-query auto-cancel registered (60s timeout, 30s check)")
    except Exception:
        _stale_cancel_task = _qs_track_bg(_stale_query_cancel_loop())
        logger.info("Phase 139: stale-query auto-cancel loop started (60s timeout, 30s check) [tracked]")

    # ── 2026-08-02 multi-pod correctness: cross-pod cancel watcher ────────
    # Embedded-executor cancels that land on a pod which does NOT hold the
    # running task are durably recorded on the execution row
    # (cancel_requested flag — see core/cancel_router.py).  This loop makes
    # every pod poll that flag so the OWNING pod signals its local task.
    # At N=1 the cancel API's local fast-path already handles everything,
    # so the sweep finds nothing — one tiny indexed DB read per interval.
    async def _cancel_request_watcher_loop():
        from core.cancel_router import signal_local_cancel
        from core.config import get as _cfg_get_cw
        while True:
            try:
                await asyncio.sleep(float(_cfg_get_cw(
                    "cancel_watcher", "poll_interval_seconds", 5) or 5))
                # DB read off-loop (event-loop starvation lesson, 2026-07-21);
                # signalling ON the loop (running_tasks holds asyncio.Tasks).
                _pending = await asyncio.to_thread(
                    db_manager.get_cancel_requested_executions)
                for _eid in _pending:
                    try:
                        if signal_local_cancel(_eid):
                            logger.info("[cancel-watcher] honoured cross-pod "
                                        "cancel for %s (owning pod)", _eid)
                    except Exception as _cw_sig_exc:
                        logger.debug("[cancel-watcher] signal failed for %s: %s",
                                     _eid, _cw_sig_exc)
            except asyncio.CancelledError:
                raise
            except Exception as _cw_exc:
                logger.warning("[cancel-watcher] loop error (continuing): %s",
                               _cw_exc)
    try:
        from core import background_jobs as _bj_cw
        from core.config import get as _cfg_get_cwr
        _cw_autostart = bool(_cfg_get_cwr(
            "background_jobs_autostart", "cancel_request_watcher", True,
        ))
        _bj_cw.register(
            name="cancel_request_watcher",
            description=(
                "Multi-pod cancel routing — polls the durable "
                "cancel_requested flag every 5s so the pod that OWNS a "
                "running query honours cancels received by other pods. "
                "⚠ Pausing this lets cross-pod-cancelled queries keep "
                "running until completion."
            ),
            factory=_cancel_request_watcher_loop,
            autostart=_cw_autostart,
            controllable=True,
        )
        logger.info("Multi-pod cancel-request watcher registered (5s poll)")
    except Exception:
        _qs_track_bg(_cancel_request_watcher_loop())
        logger.info("Multi-pod cancel-request watcher loop started (5s poll) [tracked]")

    # BF-308: kick off any background jobs that registered themselves
    # earlier in startup AND have autostart=true.  See core/background_jobs.py.
    # 2026-09-01: every daemon this pod does NOT run still gets a visible,
    # controllable placeholder, so the admin UI shows the whole fleet from
    # whichever pod serves it.  Before autostart_all, and placeholders never
    # autostart, so this cannot start anything.
    try:
        from core.daemon_registry import register_remote_placeholders
        register_remote_placeholders()
    except Exception as _ph_exc:
        logger.warning("remote daemon placeholders failed (non-fatal): %s",
                       _ph_exc)

    try:
        from core import background_jobs as _bj
        _bj.autostart_all()
    except Exception as _bj_init_exc:
        logger.warning("BF-308 background_jobs.autostart_all failed (non-fatal): %s", _bj_init_exc)

    # Mark any executions stuck in "running" state as failed.
    # These are orphaned by a previous server crash or forced restart.
    try:
        stuck = db_manager.list_executions(status="running", limit=1000, offset=0)
        for ex in stuck:
            db_manager.update_execution(
                ex["execution_id"],
                status="failed",
                error_message="Server restarted while execution was in progress",
            )
        if stuck:
            logger.warning(
                "Startup: marked %d orphaned 'running' execution(s) as failed", len(stuck)
            )
    except Exception as _e:
        logger.warning("Startup: orphan execution cleanup failed: %s", _e)

    # Auto-migrate plain-text passwords → PBKDF2 hashes
    if _auth_cfg.type == "local":
        _migrate_plaintext_passwords()


def _migrate_plaintext_passwords():
    """One-time migration: hash any plain-text passwords found in config.json."""
    import json as _json
    from core.ad_auth import hash_password as _hash_pw, _PBKDF2_PREFIX

    config_file = Path(__file__).resolve().parent / "config.json"
    try:
        with open(config_file, "r", encoding="utf-8") as f:
            cfg = _json.load(f)
    except Exception:
        return

    raw_users = cfg.get("auth", {}).get("local_users", "")
    if not raw_users:
        return

    users_dict = {}
    migrated_count = 0
    for pair in raw_users.split(","):
        pair = pair.strip()
        if ":" in pair:
            u, p = pair.split(":", 1)
            u, p = u.strip(), p.strip()
            if not p.startswith(_PBKDF2_PREFIX):
                users_dict[u] = _hash_pw(p)
                migrated_count += 1
            else:
                users_dict[u] = p

    if migrated_count > 0:
        cfg["auth"]["local_users"] = ",".join(f"{u}:{p}" for u, p in users_dict.items())
        with open(config_file, "w", encoding="utf-8") as f:
            _json.dump(cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        # Reload in-memory config
        from core import config as _config_mod
        _config_mod._file_cfg = _config_mod._load_file()
        _config_mod._merged = _config_mod._deep_merge(_config_mod._DEFAULTS, _config_mod._file_cfg)
        _config_mod._cfg = _config_mod._apply_env(_config_mod._merged)
        logger.info("Migrated %d plain-text password(s) to PBKDF2 hashes", migrated_count)


@_hooks.shutdown
async def _shutdown():
    # 2026-07-12 — RESTART DIAGNOSTICS.  Emit a clear, greppable reason line at
    # the top of every graceful shutdown so operators can answer "why did the
    # API restart?" from the logs alone.  Under uvicorn this fires when
    # SIGTERM/SIGINT arrives — on OpenShift that means pod termination: rolling
    # deploy, liveness/readiness probe failure (e.g. the event loop was blocked
    # long enough that /health stopped responding), node drain/eviction,
    # scale-down, or `oc delete`.  A hard Python crash instead goes through
    # sys.excepthook ("Unhandled exception — backend crash").  A SIGKILL /
    # OOMKilled leaves NO in-process log (uncatchable) — for that, the only
    # record is `oc describe pod` (Reason: OOMKilled) + the [memory-guard] /
    # [loop-watchdog] WARNING lines this process emits just before it dies.
    try:
        _uptime = _time.time() - _PROCESS_START_TS
        _n_inflight = len([t for t in _running_tasks.values() if not t.done()])
        logger.warning(
            "[SHUTDOWN-REASON] graceful shutdown initiated (SIGTERM/SIGINT) — "
            "pid=%d uptime=%.0fs in_flight_queries=%d. On OpenShift this is pod "
            "termination (rolling deploy / liveness|readiness probe failure / "
            "eviction / scale-down / oc delete). If UNEXPECTED: check `oc "
            "describe pod` for OOMKilled or probe failures, and grep the lines "
            "just above for [loop-watchdog] (event-loop stall) and [memory-guard].",
            os.getpid(), _uptime, _n_inflight,
        )
    except Exception:
        pass
    # 2026-10-29 -- from here on a run that is cancelled was stopped by the
    # SERVER (a deploy, a pod restart), not by its user: it is FAILED with the
    # restart sentence and the UI offers "Run again" (core/checkpoint.py).
    try:
        from core.checkpoint import mark_process_stopping as _cp_stopping
        _cp_stopping()
    except Exception as _cps_exc:
        logger.debug("[shutdown] checkpoint stopping flag failed: %s", _cps_exc)
    # 2026-10-31 (query pods phase 2) -- DRAIN the job-queue executor FIRST:
    # it claims nothing new (its heartbeat says draining; readiness answers 503
    # only while a listener is still open -- under uvicorn's SIGTERM the socket is
    # already closed, so nothing new arrives either way) and its running
    # jobs get jobqueue.drain_seconds / the pod's termination grace to finish;
    # a run still going when time runs out is left to its lease (the queue
    # retries a declared read once on another pod, else fails it with the
    # reason).  No executor here -> nothing happens.  Off the loop: it waits.
    try:
        from core.jobqueue.executor import drain_in_process_executor as _jq_drain
        _drained = await asyncio.to_thread(_jq_drain)
        if _drained is not None:
            logger.warning("[shutdown] job-queue executor drained=%s", _drained)
    except Exception as _jqd_exc:
        logger.warning("[shutdown] executor drain failed (non-fatal): %s", _jqd_exc)
    # 2026-10-04 -- stop THIS lifespan's periodic threads (the cleanup /
    # retention / digest loops _startup started through
    # core/lifespan_threads.py) before anything they use is torn down.  Set
    # their event, join inside a bounded budget off the loop; a thread still
    # mid-pass is named in a WARNING, never waited on past the budget.
    try:
        # the SIGNAL first, on the loop (never blocks); only the joining
        # goes to a pool thread -- a busy pool must not delay the stop.
        _lifespan_threads.request_stop()
        await asyncio.to_thread(_lifespan_threads.stop_all)
    except Exception as _lt_exc:
        logger.warning("[shutdown] stopping lifespan threads failed "
                       "(non-fatal): %s", _lt_exc)
    # ... and withdraw the singleton starts this lifespan DEFERRED: their
    # context holds this event loop, which is about to close.
    try:
        from core.daemon_registry import discard_deferred_for_loop
        discard_deferred_for_loop(asyncio.get_running_loop())
    except Exception as _dd_exc:
        logger.debug("[shutdown] deferred singleton withdrawal failed: %s",
                     _dd_exc)
    # 2026-10-17 -- the component-health reporter thread and its probe pool
    # stop with the lifespan (a thread that outlives the app is the 2026-10-04
    # leak class; the next lifespan starts a fresh one).
    try:
        from core.component_health.reporter import stop_reporter as _ch_stop
        await asyncio.to_thread(_ch_stop, 3.0)
    except Exception as _ch_stop_exc:  # noqa: BLE001
        logger.debug("component_health reporter stop: %s", _ch_stop_exc)
    # Stop the cross-pod event-bus LISTEN consumer (releases its dedicated PG
    # connection).  No-op if it was never started (sqlite / single-pod).
    try:
        from core.event_bus import stop_listener as _eb_stop_listener
        _eb_stop_listener(timeout=3.0)
    except Exception:
        pass
    # BF-410.1 — graceful drain.  OpenShift gives 30 s between SIGTERM and
    # SIGKILL.  Previously we waited 5 s with no actual wait — every rolling
    # deploy interrupted in-flight queries with "connection reset".
    # Now: wait for in-flight tasks to complete up to `server.shutdown_drain_seconds`
    # (default 25 s, leaving 5 s headroom), THEN cancel.
    try:
        from core.config import server as _srv_cfg
        _drain_s = int(getattr(_srv_cfg, "shutdown_drain_seconds", 25))
    except Exception:
        _drain_s = 25
    _drain_s = max(1, min(_drain_s, 120))   # clamp [1, 120]

    _initial = [t for t in _running_tasks.values() if not t.done()]
    if _initial:
        logger.info(
            "[shutdown] %d in-flight queries — draining for up to %ds before cancel",
            len(_initial), _drain_s,
        )
        try:
            # asyncio.wait_for with gather(return_exceptions=True) — captures
            # task exceptions in the result list instead of raising.
            # BF-410-AUDIT-FOLLOWUP: surface those captured exceptions at
            # ERROR level so we don't silently swallow task failures during
            # shutdown (e.g., a query that crashes during drain).
            _results = await asyncio.wait_for(
                asyncio.gather(*_initial, return_exceptions=True),
                timeout=float(_drain_s),
            )
            _exceptions = [r for r in _results if isinstance(r, BaseException)
                           and not isinstance(r, asyncio.CancelledError)]
            if _exceptions:
                logger.error(
                    "[shutdown] %d/%d in-flight queries raised during drain: %s",
                    len(_exceptions), len(_initial),
                    [type(e).__name__ for e in _exceptions[:5]],
                )
            else:
                logger.info("[shutdown] all in-flight queries completed gracefully")
        except asyncio.TimeoutError:
            _still_running = [t for t in _initial if not t.done()]
            logger.warning(
                "[shutdown] %d/%d queries did not finish in %ds — cancelling",
                len(_still_running), len(_initial), _drain_s,
            )
            # Signal cancel events so background threads stop ASAP
            for _ev in list(_cancellation_flags.values()):
                _ev.set()
            for t in _still_running:
                t.cancel()
            # Brief join window for cancellation cleanup
            try:
                await asyncio.wait_for(
                    asyncio.gather(*_still_running, return_exceptions=True),
                    timeout=3.0,
                )
            except asyncio.TimeoutError:
                pass
    else:
        logger.info("[shutdown] no in-flight queries; draining skipped")

    from core.config import scheduler as _sched_cfg
    if _sched_cfg.mode == "embedded":
        from core.scheduler import shutdown_scheduler
        shutdown_scheduler()
        # BF-410.4 — release the scheduler lease so a peer pod can take over
        # faster than waiting for the lease to expire naturally.
        try:
            _l = getattr(app.state, "scheduler_lease", None)
            if _l is not None:
                _l.release()
        except Exception as _le:
            logger.debug("[shutdown] scheduler lease release failed: %s", _le)
    else:
        # External mode — cancel the notification poller task
        if _notification_poller_task and not _notification_poller_task.done():
            _notification_poller_task.cancel()

    # Cancel executor poller if running (external mode)
    if _executor_poller_task and not _executor_poller_task.done():
        _executor_poller_task.cancel()

    # BF-299: stop iceberg metadata sync loop
    try:
        from core.iceberg_metadata_sync import stop_background_sync
        stop_background_sync()
    except Exception:
        pass

    # Phase C: stop iceberg manifest watcher loop
    try:
        from core.iceberg_manifest_watcher import stop_background as _icw_stop
        _icw_stop()
    except Exception:
        pass

    # Phase 160: stop brain DuckDB mirror supervisor + writer (idempotent
    # — no-op when never started).  stop_supervisor also stops the writer.
    try:
        from core.brain_duckdb_mirror import stop_supervisor as _bds_stop
        _bds_stop()
    except Exception as _bds_exc:                                     # pragma: no cover
        # 2026-07-02 -- shutdown-path.  Debug-log so a shutdown
        # regression (mirror stop hanging or raising) is greppable
        # in operator logs without preventing shutdown.
        logger.debug(
            "main.shutdown: brain_duckdb_mirror.stop_supervisor "
            "suppressed %s: %s",
            type(_bds_exc).__name__, _bds_exc,
        )

    # BF-308: stop everything in the background_jobs registry too
    try:
        from core import background_jobs as _bj
        _bj.stop_all(reason="shutdown")
    except Exception:
        pass

    # Phase 120: Cancel DQ monitor periodic task
    if _dq_monitor_task and not _dq_monitor_task.done():
        _dq_monitor_task.cancel()

    # Spark Connect: close all sessions on shutdown
    try:
        from core.config import spark_connect as _sc_shutdown_cfg
        if _sc_shutdown_cfg.enabled:
            from core.spark_connect_session_manager import shutdown_all as _sc_shutdown_all
            await _sc_shutdown_all()
    except Exception:
        pass  # non-fatal on shutdown

    # Phase 98-I: Stop Kafka consumer (only runs in embedded scheduler mode)
    from core.config import scheduler as _shutdown_sched_cfg
    if _shutdown_sched_cfg.mode == "embedded":
        try:
            from core.kafka_cache_consumer import stop_kafka_consumer
            stop_kafka_consumer()
        except Exception:
            pass

    # Stop WebSocket heartbeat
    await ws_manager.stop_heartbeat()

    # Round 11 deep-dive (2026-06-30): cancel every fire-and-forget
    # task tracked by track_bg_task.  Pre-fix the named tasks
    # (_notification_poller_task, _executor_poller_task,
    # _dq_monitor_task) were cancelled individually but the 4+ others
    # registered ONLY via _qs_track_bg (the fallback paths --
    # _run_etl_scheduler_loop, _start_sc_cleanup,
    # _stale_query_cancel_loop, the redis fallback subscribers) were
    # never cancelled -- they hit CancelledError abruptly when the
    # event loop closed, finally blocks may not have run, and
    # connections/locks could leak server-side.
    # Fail-OPEN: if cancel_all itself raises, log and continue
    # shutdown -- never let cleanup wedge the pod past
    # terminationGracePeriodSeconds.
    try:
        from core.bg_tasks import cancel_all as _qs_cancel_all_bg, _bg_tasks
        _cancelled = _qs_cancel_all_bg()
        if _cancelled:
            logger.info(
                "[shutdown] cancelled %d tracked background tasks; "
                "awaiting their completion (3s budget)",
                _cancelled,
            )
            # Brief wait for the cancelled tasks to acknowledge so
            # their finally blocks (DB connection close, semaphore
            # release, etc) get a chance to run.  3s is the same
            # budget the in-flight cancellation path above uses.
            try:
                await asyncio.wait_for(
                    asyncio.gather(*list(_bg_tasks), return_exceptions=True),
                    timeout=3.0,
                )
            except asyncio.TimeoutError:
                logger.warning(
                    "[shutdown] %d tracked bg tasks did not "
                    "acknowledge cancel within 3s -- proceeding",
                    len(_bg_tasks),
                )
    except Exception as _bg_exc:
        logger.warning("[shutdown] cancel_all bg tasks failed (non-fatal): %s", _bg_exc)

    # Don't wait=True — it blocks forever if threads hold locks
    query_executor.shutdown(wait=False, cancel_futures=True)
    _streaming_executor.shutdown(wait=False, cancel_futures=True)

    # Shut down the unified worker pool
    from core.worker_pool import get_pool
    try:
        await get_pool().shutdown()
    except RuntimeError:
        pass  # pool not initialised (tests, etc.)

    # Arrow S3 finalize handled by _finalize_arrow_s3 via atexit (runs last)


# ── Forced exit on Ctrl+C ──────────────────────────────────────────────────
# On Windows, uvicorn sometimes can't cleanly terminate threads (DuckDB
# connections, APScheduler, etc.). After the first SIGINT the graceful
# shutdown runs; a second SIGINT (or 5 s timeout) force-kills the process.
import signal as _signal  # noqa: E402

_SIGINT_COUNT = 0

def _force_exit_handler(signum, frame):
    global _SIGINT_COUNT
    try:
        _signame = _signal.Signals(signum).name   # SIGTERM (oc/k8s) vs SIGINT (Ctrl+C)
    except Exception:
        _signame = f"signal-{signum}"
    _SIGINT_COUNT += 1
    if _SIGINT_COUNT == 1:
        print(f"\n[SHUTDOWN] received {_signame} — stopping server…", flush=True)
        # Give uvicorn 3 seconds to drain, then force-exit cleanly.
        # Don't raise KeyboardInterrupt — it causes noisy asyncio tracebacks.
        def _delayed_exit():
            # 2026-10-31 (query pods phase 2) -- a process that runs the
            # job-queue executor DRAINS first: no new claims (readiness 503),
            # the running jobs finish within jobqueue.drain_seconds / the
            # pod's termination grace; a run still going then is left to its
            # lease (a declared read is retried once, else failed with the
            # reason).  No executor here -> returns at once.
            try:
                from core.jobqueue.executor import drain_in_process_executor as _jq_drain_sig
                _jq_drain_sig()
            except Exception as _jq_sig_exc:  # noqa: BLE001
                print(f"[SHUTDOWN] executor drain failed: {_jq_sig_exc}", flush=True)
            # 2026-10-14 -- a process that hosts the feed queue worker (hybrid
            # mode) hands its unfinished runs back first (drain, publish gate,
            # hand-back: core/feed/run_lifecycle.py); otherwise the old 3 s.
            _finalize_arrow_s3()
            print("[SHUTDOWN] Done.", flush=True)
            from core.feed.run_lifecycle import hand_back_then_exit_from_signal
            hand_back_then_exit_from_signal(globals().get("db_manager"), 0, 3.0)
        _threading.Thread(target=_delayed_exit, daemon=True).start()
    else:
        print("[SHUTDOWN] Force exit!", flush=True)
        _finalize_arrow_s3()
        os._exit(1)

# 2026-09-17 -- ONLY on the main thread.
#
# signal.signal() raises ValueError anywhere else, and this runs at MODULE
# level -- so ``import main`` from a worker thread raised, which is exactly
# what killed every parquet query on the executor pod (executor_worker.py did
# ``from main import ParquetQueryEngine``).  That import is fixed at its own
# site; this guard is the general form, so the next module that imports the
# app from a thread gets a module instead of a ValueError.
#
# Skipping registration off-thread loses nothing: a process has ONE set of
# signal handlers, and the main thread installs them when the app boots
# normally.  A worker thread could not have installed a working handler
# anyway -- Python delivers signals to the main thread only.
if _threading.current_thread() is _threading.main_thread():
    if sys.platform == "win32":
        _signal.signal(_signal.SIGINT, _force_exit_handler)
        try:
            _signal.signal(_signal.SIGBREAK, _force_exit_handler)
        except (AttributeError, OSError):
            pass
    else:
        # Linux/Docker: handle SIGTERM (`docker stop`, k8s pod termination)
        _signal.signal(_signal.SIGINT, _force_exit_handler)
        _signal.signal(_signal.SIGTERM, _force_exit_handler)
else:
    logger.debug(
        "main.py imported off the main thread -- signal handlers not "
        "installed (they belong to the main thread by definition)")


# WebSocket Endpoints
# Two routes: plain /ws and /ws/{client_id} (client appends a timestamp-based ID)
async def _handle_ws(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # BF-WS-LASTSEEN: stamp on every incoming message so the heartbeat
            # loop can prune connections that haven't said anything in too
            # long (catches Windows TCP "writes succeed into dead peer" zombies).
            try:
                if websocket in ws_manager.connection_info:
                    ws_manager.connection_info[websocket]["last_seen_at"] = datetime.now(timezone.utc)
            except Exception as _ls_exc:
                # connection_info dict access shouldn't fail under normal
                # use; debug-log so a future bug here is visible without
                # spamming production logs.
                logger.debug("WS last_seen stamp skipped: %s", _ls_exc)
            # Handle identify message — associate username with this connection
            try:
                msg = json.loads(data)
                if isinstance(msg, dict):
                    msg_type = msg.get("type")
                    # Identify
                    if msg_type == "identify" and msg.get("username"):
                        # ── WS AUTH (2026-07-16) — bind identity to a validated
                        # session token, not a spoofable claimed username.
                        # /ws is unauthenticated; a claim-based identify let a
                        # network-adjacent client subscribe to ANOTHER user's
                        # execution_progress by claiming their name.  When the
                        # identify frame carries a ``token``, validate it and
                        # OVERRIDE the claimed username with the token's user
                        # (authoritative).  Backward-compatible: tokenless
                        # clients keep working unless ``websocket.require_auth``
                        # is enabled, in which case identify without a valid
                        # token is rejected (socket stays open but unbound → it
                        # receives nothing user-scoped).  Default OFF preserves
                        # current behavior for a safe rollout; flip ON once all
                        # clients send the token to close the snoop.
                        _ws_claimed = msg.get("username")
                        _ws_auth_user = None
                        _ws_tok = msg.get("token")
                        if _ws_tok:
                            try:
                                from core.sessions import get_session as _ws_get_session
                                _ws_sess = _ws_get_session(_ws_tok) or {}
                                _ws_auth_user = (_ws_sess.get("username")
                                                 or _ws_sess.get("user") or None)
                            except Exception as _ws_auth_exc:
                                logger.debug("WS token validation failed: %s", _ws_auth_exc)
                                _ws_auth_user = None
                        # ── SECURITY AUDIT 2026-08-03 (S9) ────────────────
                        # The claimed username is NEVER trusted when real
                        # authentication is enabled.  Pre-fix, enforcement
                        # hinged on the websocket.require_auth flag whose
                        # SHIPPED DEFAULT was false — so in every default
                        # deployment a network-adjacent client could
                        # `identify` as any username and receive that
                        # user's execution/feed events.  The default is the
                        # vulnerability, so server-side enforcement is now
                        # unconditional whenever auth.type != 'none':
                        # identity comes ONLY from a validated session
                        # token; tokenless identify leaves the socket
                        # unbound (it still gets broadcast, non-user-scoped
                        # events).  Dev mode (auth.type='none') keeps the
                        # old claim-based behaviour — there are no real
                        # identities to protect.  The UI has sent the token
                        # in its identify frame since 2026-07-16
                        # (wsService.getAuthToken), so logged-in browsers
                        # are unaffected.  websocket.require_auth remains
                        # honoured for no-auth deployments that still want
                        # rejection semantics.
                        try:
                            from core.config import get as _ws_cfg_get
                            _ws_require_auth = bool(_ws_cfg_get("websocket", "require_auth", False))
                        except Exception:
                            _ws_require_auth = False
                        try:
                            from core.config import auth as _ws_auth_cfg
                            _ws_auth_enabled = getattr(_ws_auth_cfg, "type", "none") != "none"
                        except Exception:
                            _ws_auth_enabled = True   # fail CLOSED — assume identities matter
                        if (_ws_auth_enabled or _ws_require_auth) and not _ws_auth_user:
                            logger.warning(
                                "WS identify REJECTED: no valid session token for "
                                "claimed user %r — socket left unbound (no "
                                "user-scoped events).", _ws_claimed)
                            continue
                        if _ws_auth_user:
                            if _ws_auth_user != _ws_claimed:
                                logger.info(
                                    "WS identify: claimed username %r overridden by "
                                    "token-validated user %r (anti-spoof).",
                                    _ws_claimed, _ws_auth_user)
                            msg["username"] = _ws_auth_user
                        if websocket in ws_manager.connection_info:
                            ws_manager.connection_info[websocket]["username"] = msg["username"]
                            # 2026-10-17 -- does this principal see the whole
                            # feed estate?  Decided ONCE here, from the
                            # VALIDATED session (its role), by the rule the
                            # feed routes use; the board watch reads it.  A
                            # claim-based identify (auth off) sees everything,
                            # as every feed route then does.
                            try:
                                from core.feed.permissions import sees_every_feed as _sef
                                _ws_principal = _ws_sess if (_ws_tok and _ws_auth_user) else {"username": msg["username"]}
                                ws_manager.connection_info[websocket]["sees_every_feed"] = bool(_sef(_ws_principal))
                            except Exception as _sef_exc:   # noqa: BLE001 -- unknown = may not watch
                                logger.debug("WS identify: estate grant unreadable (%s)", _sef_exc)
                                ws_manager.connection_info[websocket]["sees_every_feed"] = False
                            # BF-397: capture client_id (stamped on the
                            # WebSocket by the URL-routed endpoint) so we
                            # can evict zombies from the same browser tab.
                            cid = getattr(websocket, "_qs_client_id", None)
                            if cid:
                                ws_manager.connection_info[websocket]["client_id"] = cid
                                # Find any OTHER connection with the same
                                # client_id and disconnect it — that's a
                                # zombie from a previous reconnect attempt
                                # by the same browser tab.
                                zombies = [
                                    other_ws for other_ws, info
                                    in list(ws_manager.connection_info.items())
                                    if other_ws is not websocket
                                    and info.get("client_id") == cid
                                ]
                                for zombie in zombies:
                                    logger.info(
                                        "WS evicting zombie connection for client_id=%s "
                                        "(user=%s) — same browser tab reconnected",
                                        cid, msg["username"],
                                    )
                                    # BF-401: zombie.close() can hang waiting
                                    # for TCP FIN-ACK if the socket is half-
                                    # closed.  Cap at 1s so the event loop
                                    # isn't blocked by a dead browser tab.
                                    try:
                                        await asyncio.wait_for(zombie.close(), timeout=1.0)
                                    except asyncio.TimeoutError:
                                        logger.warning("zombie WS close exceeded 1s — orphaning")
                                    except Exception as _zclose_err:
                                        logger.debug("zombie WS close raised: %s", _zclose_err)
                                    ws_manager.disconnect(zombie)
                        # BF-470 — drain any pending messages queued for
                        # this username while the WS was unidentified
                        # (race window between ws.onopen and identify
                        # being processed).  Replays events in arrival
                        # order so the client doesn't miss feed_progress,
                        # feed_completed, etc.  Stale entries (> 60 s)
                        # are silently dropped inside take_pending_for_user.
                        #
                        # DEEP-DIVE GAP FIX: use _safe_send_json so NaN /
                        # Infinity floats in buffered messages are sanitised
                        # (RFC-invalid JSON literals would otherwise crash
                        # the browser's JSON.parse).  Bypassing this
                        # sanitiser was a real bug — feed_progress
                        # elapsed_seconds is a float that CAN be NaN if
                        # start_time arithmetic produced bad input.
                        try:
                            _pending = ws_manager.take_pending_for_user(msg["username"])
                            if _pending:
                                logger.info(
                                    "BF-470: replaying %d pending message(s) to '%s' on identify",
                                    len(_pending), msg["username"],
                                )
                                from core.websocket_manager import _safe_send_json as _bf470_send
                                for _pmsg in _pending:
                                    try:
                                        await asyncio.wait_for(
                                            _bf470_send(websocket, _pmsg), timeout=5.0,
                                        )
                                    except Exception as _replay_exc:
                                        logger.debug(
                                            "BF-470: replay send failed (non-fatal): %s",
                                            _replay_exc,
                                        )
                                        break
                        except Exception as _drain_exc:
                            logger.debug(
                                "BF-470: drain failed (non-fatal): %s", _drain_exc,
                            )
                        continue
                    # Phase 139 honest-fix #1 — execution_heartbeat keeps stale-cancel
                    # alive. Frontend pings every 10s per running execution_id while the
                    # user is watching. If we don't see a heartbeat for the configured
                    # timeout, the periodic checker cancels the execution.
                    if msg_type == "execution_heartbeat":
                        eid = msg.get("execution_id")
                        if eid:
                            try:
                                from core.execution_state import record_heartbeat
                                record_heartbeat(eid)
                            except Exception:
                                pass
                        continue
                    # BF-WS-PONG: client's pong response to server ping —
                    # last_seen_at was already stamped above, no further work.
                    # This silences the wasteful pong-back-on-pong echo
                    # that was halving the heartbeat budget.
                    if msg_type == "pong":
                        continue
                    # 2026-10-17 -- the board WATCH (core/websocket_manager.py
                    # ``set_watch``): Feed Run Status asks for every feed's
                    # events while it is open; the answer (accepted or why
                    # not) goes back on the socket so the client never
                    # believes it is live when it is not.
                    if msg_type in ("watch", "unwatch"):
                        _ans = ws_manager.set_watch(websocket, str(msg.get("scope") or ""),
                                                    on=(msg_type == "watch"))
                        if not _ans.get("ok"):
                            logger.info("WS %s refused for %r: %s", msg_type,
                                        ws_manager.connection_info.get(websocket, {}).get("username"),
                                        _ans.get("reason"))
                        try:
                            from core.websocket_manager import _safe_send_json as _watch_send
                            await asyncio.wait_for(_watch_send(websocket, _ans), timeout=5.0)
                        except Exception as _watch_exc:     # noqa: BLE001 -- the socket may be gone
                            logger.debug("WS watch answer not sent: %s", _watch_exc)
                        continue
                    # BF-567 (2026-05-29): client reattaches in-flight
                    # execution_ids after WS reconnect.  Without this, a
                    # brief drop mid-query left the heartbeat alive
                    # client-side but the server's pending-message routing
                    # may have lost the binding (no-pending-buffer path,
                    # different socket).  We seed each id into the
                    # heartbeat registry + replay any pending messages
                    # buffered against the user — mirrors the BF-470
                    # drain pattern for identify but scoped to in-flight
                    # work.
                    if msg_type == "reattach_executions":
                        eids = msg.get("execution_ids") or []
                        if isinstance(eids, list):
                            for eid in eids:
                                if not eid:
                                    continue
                                try:
                                    from core.execution_state import record_heartbeat
                                    record_heartbeat(str(eid))
                                except Exception as _hb_exc:
                                    logger.debug(
                                        "BF-567 reattach heartbeat failed for %s: %s",
                                        eid, _hb_exc)
                            logger.info(
                                "BF-567 client reattached %d execution(s) after reconnect",
                                len(eids),
                            )
                        continue
            except (json.JSONDecodeError, TypeError):
                pass
            await websocket.send_json({
                "type": "pong",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
    except WebSocketDisconnect as wsd:
        ws_manager.disconnect(websocket)
        # BF-WS-DIAG: detailed disconnect logging so we can tell WHO closed
        # (client vs server vs proxy) and WHY (browser tab unresponsive,
        # network drop, proxy idle-timeout, server send timeout, etc.).
        # Code reference: https://www.iana.org/assignments/websocket/websocket.xhtml
        _code = getattr(wsd, "code", "?")
        _reason = getattr(wsd, "reason", "") or ""
        _interp = {
            1000: "normal closure",
            1001: "going away (tab closed / nav)",
            1005: "no status received (browser killed it — usually JS event loop blocked or extension)",
            1006: "abnormal closure (no close frame — likely network drop)",
            1011: "server error",
            1012: "service restart",
            1013: "try again later",
        }.get(_code, "see RFC6455")
        _info = ws_manager.connection_info.get(websocket, {})
        _opened = _info.get("connected_at")
        _msgs = _info.get("message_count", 0)
        _username = _info.get("username", "anon")
        _open_for = ""
        if _opened:
            try:
                _open_for = f", open_for={(datetime.now(timezone.utc) - _opened).total_seconds():.1f}s"
            except Exception:
                pass
        logger.info(
            "WebSocket client disconnected: user=%s code=%s (%s) reason='%s' msgs_sent=%d%s",
            _username, _code, _interp, _reason, _msgs, _open_for,
        )
    except Exception as e:
        # Catch connection-reset errors and other network exceptions that
        # are not modelled as WebSocketDisconnect on all platforms/Python versions.
        ws_manager.disconnect(websocket)
        # Same diagnostic detail for the non-WSD exception path.
        _info = ws_manager.connection_info.get(websocket, {})
        _opened = _info.get("connected_at")
        _msgs = _info.get("message_count", 0)
        _username = _info.get("username", "anon")
        _open_for = ""
        if _opened:
            try:
                _open_for = f", open_for={(datetime.now(timezone.utc) - _opened).total_seconds():.1f}s"
            except Exception:
                pass
        logger.warning(
            "WebSocket connection closed unexpectedly: user=%s exc=%s: %s msgs_sent=%d%s",
            _username, type(e).__name__, e, _msgs, _open_for,
        )

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await _handle_ws(websocket)

@app.websocket("/ws/{client_id}")
async def websocket_endpoint_with_id(client_id: str, websocket: WebSocket):
    # BF-397: capture client_id so the identify handler can evict any
    # zombie connection from the same browser tab when the user reconnects
    # mid-query.  Without this, the OLD WS sits in active_connections
    # until the 300s stale-prune fires — broadcasts go to both during
    # that window (old fails silently, new succeeds — wasteful + risks
    # message duplication if both happen to be alive).
    try:
        if not hasattr(websocket, "_qs_client_id"):
            setattr(websocket, "_qs_client_id", client_id)
    except Exception as _stamp_err:
        logger.debug("WS client_id stamp failed: %s", _stamp_err)
    await _handle_ws(websocket)


# ── Materialized Views — extracted to core/mv_manager.py ──────────────────────
from core.mv_manager import (  # noqa: E402
    refresh_materialized_view_sync as _refresh_materialized_view_sync,
    setup_mv_schedule as _setup_mv_schedule,
    remove_mv_schedule as _remove_mv_schedule,
    promote_download_sync as _promote_download_sync,
    upload_file_to_local_table_sync as _upload_file_to_local_table_sync,
    cleanup_expired_local_tables as _cleanup_expired_local_tables,
    resolve_table_duckdb_sql as _resolve_table_duckdb_sql,
)
def _refuse_api_path_as_spa(full_path: str) -> None:
    """An unknown ``/api/...`` GET is a 404, never the SPA shell (2026-09-26)."""
    _p = (full_path or "").lstrip("/").lower()
    if _p == "api" or _p.startswith("api/"):
        raise HTTPException(status_code=404, detail="Not Found")


if _STATIC_DIR:
    @app.get("/", include_in_schema=False)
    async def _spa_root():
        return FileResponse(str(_STATIC_DIR / "index.html"))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def _spa_catch_all(full_path: str):
        # 2026-09-26 -- an unknown API path is a 404, never the SPA shell.
        # Serving index.html here answered a removed or misspelt
        # ``/api/...`` GET with a 200 of HTML, so a client (or a test)
        # asking "is this route gone?" read "yes, it exists" -- found
        # when the parametric-report decommission guard passed on the CI
        # image (no built UI) and failed on a box with one.
        _refuse_api_path_as_spa(full_path)
        return FileResponse(str(_STATIC_DIR / "index.html"))
else:
    @app.get("/")
    async def _api_root():
        return {
            "name": "QueryStudio API",
            "version": API_VERSION,
            "api_version": API_MAJOR,
            "status": "operational",
            "note": "Build the frontend (`npm run build` in frontend/) to enable SPA serving.",
        }


def run_server(host=None, port=None, workers=None, log_level=None):
    """Start the FastAPI webserver.  Called by ``querystudio`` CLI."""
    import uvicorn
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

    # 2026-09-29 -- ONE rule for the listener's TLS, shared with
    # scheduler_worker.main (core/server_tls.py): configured and present ->
    # HTTPS; unconfigured -> plain HTTP; configured but a file missing, or
    # only one of the pair set -> REFUSE to start, naming the path.  Before,
    # this lane handed the paths to uvicorn, which raised a bare
    # FileNotFoundError from ssl.load_cert_chain at startup, while the
    # scheduler quietly served plain HTTP -- two answers to one question.
    from core.server_tls import server_tls_kwargs_or_exit
    ssl_kwargs = server_tls_kwargs_or_exit(_server_cfg, logger, what="webserver")
    if ssl_kwargs:
        logger.info("HTTPS enabled (cert=%s)", ssl_kwargs["ssl_certfile"])
    else:
        # Warn if auth is active but no TLS — passwords travel in plain text
        from core.config import auth as _auth_cfg_run
        if _auth_cfg_run.type != "none":
            logger.warning(
                "Server starting over plain HTTP with authentication enabled. "
                "Set server.ssl_certfile + server.ssl_keyfile in config.json to enable HTTPS "
                "and protect credentials in transit."
            )

    n_workers = int(workers or _server_cfg.workers or 1)

    # 2026-08-11 CRASHLOOP FIX.  This passed the app OBJECT unconditionally.
    # uvicorn REFUSES workers>1 for an app object — "You must pass the
    # application as an import string to enable 'reload' or 'workers'" — and
    # exits 1.  Both Dockerfile.reports and Dockerfile.published-api default
    # their subcommand to ``--workers 2`` (cli.py), so NEITHER IMAGE COULD
    # START: CMD -> exit 1 -> CrashLoopBackOff.  docker-compose.local.yml was
    # only alive because it overrode the command with ``--workers 1``.
    #
    # Fixed by giving uvicorn what it needs to fork: the import string.  Each
    # worker process re-imports ``main``, which is why the mode flags have to
    # be in the ENVIRONMENT before this call and not just in this process's
    # module state — they are: the Dockerfiles bake QUERYSTUDIO_REPORTS_MODE /
    # QUERYSTUDIO_PUBLISHED_API_MODE as ENV, and cmd_reports / cmd_published_api
    # set them via os.environ (inherited by the forked workers) before calling
    # here.  main.py reads them at import time to decide which routers mount.
    #
    # Single-worker keeps passing the OBJECT, unchanged: it avoids a second
    # import of a heavy module, and it is what every in-process caller and
    # test already expects.
    target = app
    # 2026-10-03 -- the pod's PROCESS COUNT is published before uvicorn
    # starts, so every worker reads the same number: each takes
    # core.process_topology.per_process_share() of the pod's CONCURRENCY
    # budgets (PV lane, bulk lane, query caps, DuckDB pool, DB pool), while
    # RATE budgets live in the shared store (core/rate_limiter.py).  The
    # published-api chart runs pod.workers (2) processes through
    # QUERYSTUDIO_SERVER_WORKERS -> server.workers, read just above.
    from core.process_topology import (
        detach_main_module_from_spawn, prepare_prometheus_multiprocess,
        publish_server_processes,
    )
    publish_server_processes(n_workers)
    # 2026-10-10 -- and the boot directory every worker registers itself in
    # at startup (core/worker_ledger.py), so a worker the supervisor killed
    # and replaced is visible in /health ("workers") and in the replacing
    # worker's log, not only in the supervisor's stdout.
    from core.worker_ledger import publish_server_boot_dir
    publish_server_boot_dir(n_workers)
    # 2026-10-10 -- how long uvicorn's multiprocess supervisor waits for a
    # worker's pong before it KILLS and respawns it (every request in flight
    # on that worker dies at the socket).  uvicorn's default is 5 s; found
    # live at 50 concurrent published-API consumers ("Child process [164]
    # died" with RestartCount 0).  The pong is answered by a thread, so this
    # is the bound on a WHOLE process standing still (a long collection, a
    # C call holding the GIL, CPU starvation) -- a backstop, declared as
    # server.worker_healthcheck_timeout_seconds; a blocked event loop is
    # fixed where it blocks (api/published_views/page_io.py), never here.
    _hc_seconds = int(_server_cfg.worker_healthcheck_timeout_seconds)
    if n_workers > 1:
        logger.info(
            "uvicorn worker healthcheck: a worker that does not answer the "
            "supervisor's ping within %ds is killed and respawned "
            "(server.worker_healthcheck_timeout_seconds=%d)", _hc_seconds, _hc_seconds)
    else:
        logger.info(
            "single server process: no uvicorn supervisor, so "
            "server.worker_healthcheck_timeout_seconds=%d has no process to watch",
            _hc_seconds)
    # 2026-10-04 -- cap glibc's malloc arenas for this process and, through
    # MALLOC_ARENA_MAX in the environment, for every worker uvicorn spawns:
    # with glibc's default (8 x cores) each thread that mallocs keeps its own
    # arena and the freed memory of a large request stays resident
    # (core/process_memory.py; server.malloc_arena_max, 0 = glibc default).
    from core.process_memory import configure_allocator
    configure_allocator()
    if n_workers > 1:
        target = "main:app"
        # uvicorn's workers are SPAWNED: without this every worker re-runs
        # this module as __mp_main__ (a second app, a second
        # DatabaseManager) before importing "main:app" -- see the helper.
        detach_main_module_from_spawn()
        # /metrics on an N-process pod: one scrape reaches ONE process, so
        # counters would jump between processes' values.  The workers write
        # to a shared multiprocess directory and /metrics aggregates it.
        prepare_prometheus_multiprocess(n_workers)
        logger.info(
            "Starting %d uvicorn workers via import string %r "
            "(an app object cannot be forked)", n_workers, target)

    uvicorn.run(
        target,
        host=host or _server_cfg.host,
        port=port or _server_cfg.port,
        log_level=log_level or _server_cfg.log_level,
        workers=n_workers,
        # 2026-09-29 -- believe X-Forwarded-For / -Proto only from the
        # DECLARED proxies (server.forwarded_allow_ips; the default is
        # uvicorn's own loopback-only).  Behind an ingress every
        # request.client.host is otherwise the ingress, and the per-address
        # login limit is one bucket for the whole organisation.  Every
        # user-facing entry point (standalone, webserver, reports,
        # published-api) comes through this call.
        proxy_headers=True,
        forwarded_allow_ips=_server_cfg.forwarded_allow_ips,
        # 2026-10-10 -- the supervisor's patience with a silent worker; see
        # the log line above.  uvicorn >= 0.30 (the manifest floor is 0.31).
        timeout_worker_healthcheck=_hc_seconds,
        **ssl_kwargs,
    )


if __name__ == "__main__":
    run_server()
