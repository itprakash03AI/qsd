"""Every configuration row is switched OFF, never erased (owner, 2026-10-30).

The owner: "every config table should have [an active column] ... mostly db
driven".  ONE rule for every table the release vocabulary marks as
configuration (``core/release/vocabulary.TABLE_KINDS`` kind ``release``,
top-level -- a child row belongs to its parent's definition):

  * the table has ``is_active`` (Boolean, default true -- the owner's
    ISACTIVE='Y'); a row from before the column reads active;
  * DELETE switches the row off (``is_active = false``) and leaves its
    children as they are, so "Switch on" brings the whole object back;
  * lists hide switched-off rows unless asked (``include_inactive``);
    runners, schedulers and pickers never use one;
  * a switched-off row keeps its name: creating another with that name is
    refused with ``name_held_message`` -- switch the old one on instead;
  * "Switch on" is ONE route for every table (``api/config_active_api.py``),
    one permission rule (admin, or the row's owner), one name check.

Guard: ``tests/test_config_is_active_everywhere_2026_10_30.py`` fails when a
config table has no ``is_active`` or code erases a config row.
"""
from __future__ import annotations

from typing import Any, Optional

from fastapi import HTTPException

from core.release.vocabulary import KIND_RELEASE, TABLE_KINDS

# owner-like columns, in the order they are trusted
OWNER_COLUMNS = ("owner", "owner_username", "created_by", "username")
# the column that names a row for a person, in order
NAME_COLUMNS = ("name", "display_name", "logical_name", "path", "slug", "key", "table_name",
                "user_group_name", "dependency_type")


def config_tables() -> list[str]:
    """Top-level configuration tables (release kind, not 'child of ...')."""
    return sorted(t for t, (k, note) in TABLE_KINDS.items()
                  if k == KIND_RELEASE and not note.startswith("child")
                  and not note.startswith("legacy_report"))


def model_for(table: str):
    from core.db.models import Base
    for mapper in Base.registry.mappers:
        if mapper.class_.__table__.name == table:
            return mapper.class_
    return None


def active_clause(model):
    """``is_active`` true OR null (a row from before the column)."""
    return model.is_active.isnot(False)


def is_on(row: Any) -> bool:
    v = row.get("is_active") if isinstance(row, dict) else getattr(row, "is_active", True)
    return v is not False


def name_of(row: Any) -> Optional[str]:
    for c in NAME_COLUMNS:
        v = row.get(c) if isinstance(row, dict) else getattr(row, c, None)
        if v:
            return str(v)
    return None


def owner_of(row: Any) -> Optional[str]:
    for c in OWNER_COLUMNS:
        v = row.get(c) if isinstance(row, dict) else getattr(row, c, None)
        if v:
            return str(v)
    return None


def name_held_message(what: str, name: str) -> str:
    """The refusal when a NEW object takes the name of a switched-off one."""
    return (f"A switched-off {what} is already called {name!r}. Open Switched Off in the menu "
            f"and press Switch on to use it again -- or pick another name.")


# --- a switched-off row KEEPS its name: the ONE check a create / rename runs ---
# (three areas each wrote their own on 2026-10-30; merged here -- a decision
# made twice is a bug).  A name unique per owner / connection / parent is
# only held inside that scope.  There is NO name check on Switch on: a unique
# name cannot be taken while its switched-off row holds it (this check + the
# constraint), and a non-unique name (dashboards) may repeat by design.  (A
# report's name is unique PER OWNER: core/db/mixin_datasets._refuse_report_name_taken.)
SCOPE_COLUMNS = ("owner", "connection_id", "connection_name", "scope", "parent_id")


class NameHeld(HTTPException):
    """409: a switched-off row of this table already holds the name.  An
    HTTPException, so raised from the storage layer it reaches the caller
    through every route (they re-raise HTTPException before a catch-all)."""

    def __init__(self, what: str, name: str):
        self.what, self.name = what, name
        super().__init__(status_code=409, detail=name_held_message(what, name))


def holder_of(session, model, column: str, value: Any, *, scope_from: Optional[dict] = None,
              exclude_id: Optional[int] = None, case_insensitive: bool = False) -> Optional[str]:
    """The value held by a SWITCHED-OFF row of ``model`` with ``column == value``
    (within the scope read from ``scope_from``), or None."""
    if value is None or str(value).strip() == "":
        return None
    col = getattr(model, column)
    if case_insensitive:
        from sqlalchemy import func
        cond = func.lower(col) == str(value).strip().lower()
    else:
        cond = col == value
    q = session.query(col).filter(cond, model.is_active.is_(False))
    for c in SCOPE_COLUMNS:
        if hasattr(model, c) and (scope_from or {}).get(c) is not None:
            q = q.filter(getattr(model, c) == (scope_from or {})[c])
    if exclude_id is not None:
        q = q.filter(model.id != int(exclude_id))
    row = q.first()
    return str(row[0]) if row is not None else None


def refuse_if_held(session, model, what: str, column: str, value: Any, *,
                   scope_from: Optional[dict] = None, exclude_id: Optional[int] = None,
                   case_insensitive: bool = False) -> None:
    """Raise ``NameHeld`` (409) when a switched-off row holds ``value``.  An ON
    row with the name is the caller's own "already exists"."""
    held = holder_of(session, model, column, value, scope_from=scope_from,
                     exclude_id=exclude_id, case_insensitive=case_insensitive)
    if held is not None:
        raise NameHeld(what, held)


def switched_off_holder(db, model, name: Any, column: str = "name",
                        exclude_id: Optional[int] = None,
                        ignore_case: bool = False) -> Optional[str]:
    """``holder_of`` for a caller holding the database manager, not a session."""
    with db.get_session(read_only=True) as session:
        return holder_of(session, model, column, name, exclude_id=exclude_id,
                         case_insensitive=ignore_case)


def switched_off_message(what: str) -> str:
    return (f"{what[:1].upper()}{what[1:]} switched off, not erased. An admin (or its owner) can "
            f"switch it back on under Switched Off in the menu.")


def switch_off(row, by_user: Optional[str] = None) -> None:
    """The ONE way a config row is deleted: off, children untouched -- and WHO
    did it is recorded (``config_switch_offs``) in the same transaction, from
    the request's user unless given.  A non-admin may switch a row back on only
    when they switched it off (``switched_off_by``)."""
    from datetime import datetime, timezone
    row.is_active = False
    if hasattr(row, "updated_at"):
        row.updated_at = datetime.now(timezone.utc)
    from sqlalchemy.orm import object_session
    session = object_session(row)
    if session is None:          # a detached row: nobody can prove who -> admins only
        return
    if by_user is None:
        from core.user_context import get_current_username
        by_user = get_current_username() or None
    from core.db.models import ConfigSwitchOff
    if row.id is None:
        session.flush()
    session.add(ConfigSwitchOff(table_name=row.__table__.name, row_id=row.id, by_user=by_user))


def last_switch_off(session, table: str, row_id: int):
    """(who, when) of the latest switch-off of this row, or None when not recorded."""
    from core.db.models import ConfigSwitchOff
    return (session.query(ConfigSwitchOff.by_user, ConfigSwitchOff.at)
            .filter(ConfigSwitchOff.table_name == table, ConfigSwitchOff.row_id == int(row_id))
            .order_by(ConfigSwitchOff.id.desc()).first())


def switched_off_by(session, table: str, row_id: int) -> Optional[str]:
    """Who switched this row off last, or None (not known -> admins only)."""
    last = last_switch_off(session, table, row_id)
    return (last[0] or None) if last else None
