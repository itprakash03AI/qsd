"""Live SAP-OData passthrough engine (Phase 132.33).

Sister module to :mod:`core.sap_task_loader` — instead of writing rows
to CSV (the ETL path), this module fetches OData live, applies the same
``column_mapping.json`` translation, and returns JSON to an API caller.

Use case: consumers need data "as of right now" (SAP MEBAL balances
change every p_timestamp).  The ETL pipeline gives them N-minute-stale
landed files; this gives them no-staleness JSON with a per-task rate
limit and a forced partition filter so one consumer can't drown SAP.

Public surface:

    eng = PassthroughEngine(db_manager)
    schema = eng.describe_schema(task_id)
    result = eng.query(task_id, filters={"company_code": "8129"},
                         top=100, skip=0, period_mode_override=None)

The engine reuses :class:`steps.sap_odata_base.SapOdataBase` for the
HTTP session + retry/backoff (single source of truth — the OG ETL and
this passthrough agree on auth, retries, rate limit, pagination).

Phase 134-K (audit BLOCKER #2) — every outbound URL is validated
against ``core.url_safety.validate_url_safety()`` before the HTTP
session ever sees it.  Blocks cloud-metadata IPs unconditionally and
private/loopback/link-local unless ``rest_api.allow_private_ips`` is
true (on-prem).  An additional ``sap.allowed_hosts`` config-driven
allowlist lets ops restrict SAP traffic to a known set of internal
hostnames even when private IPs are otherwise allowed — defence in
depth against a misconfigured Connection that points at the wrong
internal service.
"""
from __future__ import annotations

import logging
import re
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

# Imported at module level so tests can patch
# ``core.sap_passthrough.validate_url_safety`` cleanly.
from core.url_safety import validate_url_safety

logger = logging.getLogger(__name__)


# Audit BLOCKER #2 — SSRF allowlist guard.  Read at call-time (NOT
# import-time) so config hot-reload works.
def _enforce_sap_url_safety(url: str) -> None:
    """Validate ``url`` is safe to call from the QS pod.

    Two layers:
      1. ``core.url_safety.validate_url_safety`` — blocks cloud-metadata
         (169.254.169.254, metadata.google.internal, …) unconditionally
         and private/loopback/link-local IPs unless on-prem opt-in.
      2. Optional ``sap.allowed_hosts`` config (list of hostnames or
         hostname suffixes).  When set and non-empty, the SAP URL host
         MUST match one of them — even with ``allow_private_ips=true``.
         Defence against a Connection row that points at the wrong
         internal endpoint (e.g. an HR system on the same intranet).
    """
    validate_url_safety(url)   # raises ValueError on private/metadata/etc.

    # Hostname-based allowlist.  Config keys read defensively so the
    # missing-config path doesn't crash the call.
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower().rstrip(".")
    if not host:
        raise ValueError("SAP URL has no hostname")
    try:
        from core.config import sap as _sap_cfg
        allowed = list(getattr(_sap_cfg, "allowed_hosts", None) or [])
    except Exception:
        allowed = []
    if not allowed:
        # No allowlist configured ⇒ rely solely on validate_url_safety.
        return
    # Suffix match so "sap.intranet.example.com" can authorise both
    # "abc.sap.intranet.example.com" and bare "sap.intranet.example.com".
    for entry in allowed:
        e = str(entry).lower().rstrip(".")
        if not e:
            continue
        if host == e or host.endswith("." + e):
            return
    raise ValueError(
        f"SSRF blocked: SAP URL host {host!r} not in sap.allowed_hosts "
        f"(configured allowlist: {allowed}).  Add the host or remove "
        f"sap.allowed_hosts to fall back to validate_url_safety only."
    )


# SAP OData property names are SQL-identifier-shaped.  Reject anything
# else so a malicious / typo'd filter key can't smuggle OData operators
# (`or 1 eq 1`, `tolower(...)`) into the $filter string we paste into
# the URL.
_COL_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")


def _validate_col_name(name: str) -> str:
    """Raise ValueError if ``name`` is not a safe SAP column identifier."""
    if not isinstance(name, str) or not _COL_RE.match(name):
        raise ValueError(
            f"invalid column name {name!r} — must match [A-Za-z_][A-Za-z0-9_]*"
        )
    return name


# Token-bucket-style rate limit per (task_id) — process-local memory.
# {task_id: (last_window_start_ts, request_count_in_window)}
_RATE_LOCK = threading.Lock()
_RATE_STATE: Dict[int, Tuple[float, int]] = {}


def _check_rate_limit(task_id: int, rpm: int) -> bool:
    """Sliding-minute bucket.  Returns True if request is allowed."""
    if not rpm or rpm <= 0:
        return True
    now = time.time()
    window = 60.0
    with _RATE_LOCK:
        start, count = _RATE_STATE.get(task_id, (now, 0))
        if now - start > window:
            # New minute window
            _RATE_STATE[task_id] = (now, 1)
            return True
        if count >= rpm:
            return False
        _RATE_STATE[task_id] = (start, count + 1)
        return True


# ── Engine ─────────────────────────────────────────────────────────────


class PassthroughEngine:
    """Resolves a SapTaskConfig, builds OData URLs, fetches pages, and
    returns mapped JSON.  All SAP-specific logic delegated to
    :class:`SapOdataBase` (auth + pagination + cleaning).  No SAP
    column names hardcoded here — schema comes from column_mapping.json.
    """

    def __init__(self, db_manager: Any) -> None:
        self.db = db_manager

    # ── Schema (filterable / output columns) ────────────────────────────

    def describe_schema(self, task_id: int) -> Dict[str, Any]:
        """Return what columns consumers can filter on + what comes back.
        Backed entirely by the column_mapping JSON (no SAP-specific
        knowledge).  Used by GET /api/sap-passthrough/{id}/schema.

        Returns the schema even when ``passthrough_enabled`` is False so
        admins can preview the contract before flipping the switch on;
        the response includes ``enabled: bool`` so callers know whether
        a /query call would actually succeed.
        """
        from core.sap_task_loader import load_task_config, load_column_mapping
        from core.db.models import SapTaskConfig

        with self.db.get_session(read_only=True) as session:
            from core.config_active import active_clause
            task = session.query(SapTaskConfig).filter(
                SapTaskConfig.id == task_id, active_clause(SapTaskConfig)).first()
            if task is None:
                raise ValueError(f"task id {task_id} not found")
            task_dict = task.to_dict()

        cfg = load_task_config(self.db, task_id)
        mapping_spec = load_column_mapping(cfg.get("column_mapping_path") or "")
        col_map: Dict[str, str] = mapping_spec.get("column_mapping") or {}
        drop_cols = set(mapping_spec.get("drop_columns") or [])
        order = mapping_spec.get("column_order") or []

        # Output columns = target names (post-rename), minus drops.
        # When column_order is set, it's the canonical list.
        # When not, derive from the values of column_mapping.
        if order:
            output_columns = [c for c in order if c not in drop_cols]
        else:
            output_columns = sorted({
                target for src, target in col_map.items()
                if target not in drop_cols
            })

        partition_field = task_dict["passthrough_partition_field"] or "company_code"
        required = list(task_dict["passthrough_required_filters"] or [])
        # Always include the partition field as required
        if partition_field and partition_field not in required:
            required.insert(0, partition_field)

        return {
            "task_id":          task_id,
            "task_name":        task_dict["name"],
            "enabled":          bool(task_dict.get("passthrough_enabled")),
            "partition_field":  partition_field,
            "required_filters": required,
            "filterable_columns": output_columns,
            "output_columns":     output_columns,
            # 2026-08-20 -- see the $top clamp below: 0 = UNLIMITED, and
            # ``or 10000`` turned that into the default cap.  Preserve the
            # configured value verbatim; the consumer of this field decides.
            "max_rows":         (10000 if task_dict.get("passthrough_max_rows") is None
                                 else int(task_dict["passthrough_max_rows"])),
            "rate_limit_rpm":   task_dict["passthrough_rate_limit_rpm"] or 60,
            "entity_set":       cfg["entity_set"],
            "filter_style":     cfg["filter_style"],
            "period_mode":      cfg["period_mode"],
        }

    # ── Query execution ─────────────────────────────────────────────────

    def query(
        self,
        task_id: int,
        filters: Dict[str, Any],
        *,
        top:  int = 1000,
        skip: int = 0,
        period_mode_override: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Fetch one page of live SAP data through column_mapping.

        Returns:
            {
              "results":  [...mapped rows...],
              "top":      N,
              "skip":     M,
              "returned": K,
              "has_more": bool,   # True when len(results)==top (likely more)
              "next_skip": M+top  (only when has_more)
            }
        """
        from core.sap_task_loader import load_task_config, load_column_mapping
        from core.db.models import SapTaskConfig

        # 1. Resolve config + rate-limit check
        with self.db.get_session(read_only=True) as session:
            from core.config_active import active_clause
            task = session.query(SapTaskConfig).filter(
                SapTaskConfig.id == task_id, active_clause(SapTaskConfig)).first()
            if task is None:
                raise ValueError(f"task id {task_id} not found")
            if not task.passthrough_enabled:
                raise ValueError("passthrough not enabled for this task")
            task_dict = task.to_dict()

        rpm = int(task_dict["passthrough_rate_limit_rpm"] or 60)
        if not _check_rate_limit(task_id, rpm):
            raise PermissionError(
                f"task {task_id} rate-limited ({rpm} req/min) — back off")

        # 2. Validate required filters
        partition_field = task_dict["passthrough_partition_field"] or "company_code"
        required = list(task_dict["passthrough_required_filters"] or [])
        if partition_field and partition_field not in required:
            required.insert(0, partition_field)
        missing = [k for k in required if not filters or filters.get(k) in (None, "", [])]
        if missing:
            raise ValueError(
                f"missing required filters: {missing} "
                f"(partition_field={partition_field!r}, required={required})"
            )

        # 3. Resolve creds + column mapping
        cfg = load_task_config(
            self.db, task_id,
            period_mode_override=period_mode_override,
        )
        # 2026-08-20 -- 0 MEANS UNLIMITED, AND THIS CLAMPED IT TO 10,000.
        #
        # ``x or 10000`` folds the product's own "no restriction" spelling
        # into the default cap, so a task configured with
        # passthrough_max_rows=0 served a client asking for $top=50000
        # exactly 10,000 rows -- with a success status.  A short OData page
        # reads as END OF DATA to the consumer, so the caller stops paging
        # and believes it has everything.  Silent FEWER rows: the same shape
        # as the 2026-08-17 ``LIMIT 0`` P0.
        #
        # The fold existed at THREE layers (db/models.py to_dict, the config
        # assembly above, and here), so fixing one would have moved the wrong
        # answer rather than removed it.  All three now resolve 0 explicitly.
        _cfg_max = task_dict.get("passthrough_max_rows")
        max_rows = 0 if _cfg_max is None else int(_cfg_max)
        top = max(1, int(top)) if max_rows <= 0 else max(1, min(int(top), max_rows))
        skip = max(0, int(skip))

        mapping_spec = load_column_mapping(cfg.get("column_mapping_path") or "")
        col_map: Dict[str, str] = mapping_spec.get("column_mapping") or {}
        # Inverse: target → source.  When a column is not in the map,
        # target == source (identity).
        inverse: Dict[str, str] = {target: src for src, target in col_map.items()}

        # 4. Build OData URL: function-import params + entity set
        base_url     = cfg["sap_base_url"].rstrip("/")
        service_path = cfg["odata_service_path"]
        entity_set   = cfg.get("entity_set") or "MEBALParameters"
        if period_mode_override == "explicit" or cfg.get("period_mode") == "explicit":
            p_gjahr = cfg.get("p_gjahr") or ""
            p_poper = cfg.get("p_poper") or ""
        else:
            p_gjahr, p_poper = self._derive_period(cfg["period_mode"])
        if not p_gjahr or not p_poper:
            raise ValueError(
                "could not derive p_gjahr/p_poper — set period_mode + "
                "p_gjahr/p_poper on the SapTaskConfig"
            )
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
        entity_url = (
            f"{base_url}/{service_path}/"
            f"{entity_set}(p_gjahr='{p_gjahr}',p_poper='{p_poper}',"
            f"p_timestamp=datetime'{timestamp}')/Data"
        )
        # Audit BLOCKER #2 — refuse cloud-metadata / private-IP / hosts
        # outside ``sap.allowed_hosts``.  An admin who creates a
        # Connection pointing at 169.254.169.254 or an internal HR system
        # would otherwise have QS forward SAP basic-auth there.
        _enforce_sap_url_safety(entity_url)

        # 5. Build $filter from request filters
        cc_field = cfg.get("company_code_field") or "Companycode"
        filter_str = self._build_filter(filters or {}, inverse,
                                          partition_field, cc_field)

        # 6. Build session + fetch one page
        session, probe = self._build_session(cfg)
        params = {
            "$filter": filter_str,
            "$format": "json",
            "$top":    str(top),
            "$skip":   str(skip),
            "spnego":  "disabled",
        }
        try:
            resp = session.get(
                entity_url, params=params,
                timeout=int(cfg.get("timeout_seconds") or 120),
            )
            resp.raise_for_status()
            data = resp.json()
        finally:
            try:
                session.close()
            except Exception:
                pass

        raw_results = data.get("d", {}).get("results", []) or []

        # 7. Apply column_mapping: rename → drop → reorder
        mapped = self._apply_mapping(raw_results, mapping_spec)

        return {
            "results":     mapped,
            "top":         top,
            "skip":        skip,
            "returned":    len(mapped),
            "has_more":    len(raw_results) == top,
            "next_skip":   skip + top if len(raw_results) == top else None,
            "as_of":       timestamp,
            "task_name":   task_dict["name"],
            "p_gjahr":     p_gjahr,
            "p_poper":     p_poper,
        }

    # ── Helpers ────────────────────────────────────────────────────────

    @staticmethod
    def _derive_period(mode: str) -> Tuple[str, str]:
        """Mirrors SapOdataBase._derive_fiscal_period semantics.
        Module-level copy so we don't need an instantiated step.
        """
        now = datetime.now()
        if mode == "current":
            return str(now.year), f"{now.month:03d}"
        if mode == "current_year_prev_poper":
            poper = now.month - 1
            if poper < 1:
                poper = 12
            return str(now.year), f"{poper:03d}"
        # default + 'prev_eom' + 'previous'
        from datetime import timedelta
        prev = now.replace(day=1) - timedelta(days=1)
        return str(prev.year), f"{prev.month:03d}"

    def _build_session(self, cfg: Dict[str, Any]):
        """Use SapOdataBase to build the HTTP session — single source of
        truth for auth, retry/backoff, connection pool tuning.
        """
        try:
            # Lazy + path-bootstrap (ETL framework may live outside backend/)
            #
            # 2026-08-19 — was ``steps.sap_odata_base``, which does not exist:
            # the module is at ``ETL/steps/sap/sap_odata_base.py`` and the ~15
            # importers inside the ETL tree all spell it
            # ``steps.sap.sap_odata_base``.  So this raised every time and the
            # RuntimeError below fired on every SAP passthrough session —
            # reported as "SAP ETL framework not importable", which sends the
            # reader after a deployment/packaging problem that isn't there.
            try:
                from steps.sap.sap_odata_base import SapOdataBase  # type: ignore
            except ImportError:
                # See core/etl_root.py.  The literal list here
                # (c:/DEV/outputs/ETL, /app/ETL, ./ETL) carried one dev box's
                # absolute path and no candidate derived from this checkout.
                from core.etl_root import ensure_etl_on_path
                ensure_etl_on_path("sap/sap_odata_base.py")
                from steps.sap.sap_odata_base import SapOdataBase  # type: ignore
        except Exception as exc:
            raise RuntimeError(
                "SAP ETL framework not importable; cannot build session: "
                + str(exc)
            )

        class _Probe(SapOdataBase):
            LOG_PREFIX = "passthrough"
            async def _execute_step(self, *args, **kwargs): return 0
        probe = _Probe(starburst_clients={}, oracle_data_manager=None,
                        logger=logger, config={})
        session = probe._build_session(cfg)
        return session, probe

    @staticmethod
    def _build_filter(
        filters: Dict[str, Any], inverse_map: Dict[str, str],
        partition_field: str, cc_field: str,
    ) -> str:
        """Build a SAP OData $filter expression from {target_col: value|[values]}.

        Each filter clause translates target → source column name via
        inverse_map.  Identity passthrough when the target isn't in the
        mapping.

        Value-shape support:
          * scalar (str/int/float)       → ``Col eq 'X'``
          * list ([a, b, c])              → ``(Col eq 'a' or Col eq 'b' or Col eq 'c')``
          * dict {"gt": ..., "le": ...}  → ``Col gt 'X' and Col le 'Y'`` (op_for_each)
        """
        parts: List[str] = []
        for target, val in (filters or {}).items():
            # Reject column names that could smuggle OData syntax
            _validate_col_name(target)
            # partition_field is a target name; if it equals "company_code"
            # but the SAP source column is "Companycode", use cc_field for it.
            if target == partition_field and (
                target not in inverse_map or inverse_map[target] == target
            ):
                src = cc_field
            else:
                src = inverse_map.get(target, target)
            # Validate the SOURCE column too — column_mapping values come
            # from a JSON file written by an admin but defence-in-depth
            # is cheap and the regex is the same.
            _validate_col_name(src)
            parts.append(PassthroughEngine._clause(src, val))
        if not parts:
            raise ValueError("at least one filter required")
        return "(" + " and ".join(parts) + ")"

    @staticmethod
    def _clause(src: str, val: Any) -> str:
        """Build one $filter clause for `src` against `val`."""
        if isinstance(val, list):
            if not val:
                raise ValueError(f"filter {src} got empty list")
            return "(" + " or ".join(
                f"{src} eq {PassthroughEngine._format_literal(v)}" for v in val
            ) + ")"
        if isinstance(val, dict):
            # Range / comparison ops
            ops = {"gt": "gt", "ge": "ge", "lt": "lt", "le": "le", "ne": "ne", "eq": "eq"}
            sub: List[str] = []
            for op, op_str in ops.items():
                if op in val:
                    sub.append(
                        f"{src} {op_str} "
                        f"{PassthroughEngine._format_literal(val[op])}"
                    )
            if not sub:
                raise ValueError(
                    f"filter {src} dict has no recognised ops "
                    f"(supported: {sorted(ops.keys())})"
                )
            return "(" + " and ".join(sub) + ")"
        # scalar
        return f"{src} eq {PassthroughEngine._format_literal(val)}"

    @staticmethod
    def _format_literal(v: Any) -> str:
        """Render a value for an OData ``$filter`` literal slot.

        Phase 132.36 hotfix-1: SAP OData rejects quoted literals for
        typed numeric/boolean properties (``Edm.Int32`` ⇒ ``Year eq 2025``,
        ``Edm.Boolean`` ⇒ ``IsActive eq true``).  Previously every value
        was quoted as a string, producing ``Year eq '2025'`` which SAP
        rejects with a type-mismatch error.

          * bool  → ``true`` / ``false`` (lowercase, no quotes)
          * int   → unquoted integer
          * float → unquoted decimal
          * str / everything else → single-quoted, with `'` doubled
            (OData escape).  Strings that LOOK like numbers (``"2025"``)
            are still quoted — consumers who need numeric semantics
            should pass an int.
        """
        # Order matters — ``bool`` IS-A ``int`` in Python, check bool FIRST.
        if isinstance(v, bool):
            return "true" if v else "false"
        if isinstance(v, int):
            return str(v)
        if isinstance(v, float):
            return repr(v)   # repr handles inf / nan as text; SAP rejects those
        # Strings + everything else → single-quoted, escaped
        return f"'{PassthroughEngine._escape(v)}'"

    @staticmethod
    def _escape(v: Any) -> str:
        """OData single-quote escape: ' → ''.  Anything non-string is str()d."""
        s = str(v)
        return s.replace("'", "''")

    @staticmethod
    def _apply_mapping(
        rows: List[Dict[str, Any]], mapping_spec: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """Apply column_mapping (rename → drop → reorder).  No-mapping ⇒
        verbatim pass-through (minus __metadata / __deferred / __count
        and empty-string keys, same as ETL CSV path).
        """
        excludes = {"__metadata", "__deferred", "__count"}
        rename = (mapping_spec.get("column_mapping") if mapping_spec else None) or {}
        drop = set((mapping_spec.get("drop_columns") if mapping_spec else None) or [])
        order = (mapping_spec.get("column_order") if mapping_spec else None) or None

        out: List[Dict[str, Any]] = []
        for row in rows:
            cleaned: Dict[str, Any] = {}
            for k, v in (row or {}).items():
                if k in excludes or k == "" or k is None:
                    continue
                if isinstance(v, (dict, list)):
                    import json as _json
                    try:
                        v = _json.dumps(v, default=str)
                    except Exception:
                        v = str(v)
                # rename if mapped
                tgt = rename.get(k, k)
                if tgt in drop:
                    continue
                cleaned[tgt] = v
            if order:
                cleaned = {k: cleaned.get(k) for k in order if k in cleaned}
            out.append(cleaned)
        return out


# Module-level singleton ────────────────────────────────────────────────


_engine: Optional[PassthroughEngine] = None


def init_passthrough(db_manager: Any) -> PassthroughEngine:
    global _engine
    _engine = PassthroughEngine(db_manager)
    return _engine


def get_passthrough() -> Optional[PassthroughEngine]:
    return _engine
