"""Listing a SQL source's table VERSIONS, and the refusals its engine words
(2026-11-01, core/connectors/version_capability.py is the DECLARATION; this
is the read).

* Trino / Starburst / Athena: ``SELECT ... FROM "<schema>"."<table>$snapshots"``
  -- the same columns the storage listing shows (snapshot_id, committed_at,
  operation, summary), newest first.
* Databricks: ``DESCRIBE HISTORY <table>`` -- Delta versions (version,
  timestamp, operation).
* Snowflake: no list -- Time Travel reads ANY time inside the table's
  retention window; the window is READ (``SHOW PARAMETERS LIKE
  'DATA_RETENTION_TIME_IN_DAYS' IN TABLE <t>``) and a time before it is
  refused up front with that sentence, not by Snowflake's own error after
  the statement ran.
* Oracle: Flashback -- no list; the engine's ORA-01555 / ORA-08180 /
  ORA-01031 answers are rendered in plain words (``oracle_flashback_refusal``,
  read by ``core/error_sanitizer._refusal_sentence``).

Every identifier is quoted by ONE helper; nothing from the table name
reaches SQL unquoted.
"""
from __future__ import annotations

import datetime as _dt
import re
from typing import Any, Dict, List, Optional

from core.iceberg_versions import IcebergVersionRefusal, qident

#: Days of history a Snowflake table keeps when the parameter cannot be read.
SNOWFLAKE_RETENTION_UNKNOWN = None


def _qualified(table: str) -> str:
    """``db.schema.table`` -> each part quoted by ``qident``."""
    parts = [p for p in re.split(r"\.(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", table.strip()) if p]
    return ".".join(qident(p.strip().strip('"')) for p in parts)


def listing_sql(connection_type: str, table: str) -> Optional[str]:
    """The statement that lists ``table``'s versions on this engine, or None
    when the engine keeps no list (Snowflake, Oracle) or none is declared."""
    t = str(connection_type or "").lower()
    parts = [p for p in re.split(r"\.(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", table.strip()) if p]
    if t in ("trino", "starburst", "starburst_galaxy", "galaxy", "presto", "athena"):
        if not parts:
            return None
        last = parts[-1].strip().strip('"') + "$snapshots"
        q = ".".join(qident(p.strip().strip('"')) for p in parts[:-1] + [last])
        return (f"SELECT snapshot_id, committed_at, parent_id, operation, manifest_list, summary "
                f"FROM {q} ORDER BY committed_at DESC")
    if t == "databricks":
        return f"DESCRIBE HISTORY {_qualified(table)}"
    return None


def retention_sql(connection_type: str, table: str) -> Optional[str]:
    if str(connection_type or "").lower() == "snowflake":
        return f"SHOW PARAMETERS LIKE 'DATA_RETENTION_TIME_IN_DAYS' IN TABLE {_qualified(table)}"
    return None


def _ms(v: Any) -> Optional[int]:
    if v is None:
        return None
    if isinstance(v, _dt.datetime):
        d = v if v.tzinfo else v.replace(tzinfo=_dt.timezone.utc)
        return int(d.timestamp() * 1000)
    try:
        d = _dt.datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        d = d if d.tzinfo else d.replace(tzinfo=_dt.timezone.utc)
        return int(d.timestamp() * 1000)
    except ValueError:
        return None


def rows_to_versions(connection_type: str, columns: List[str], rows: List[Any]) -> List[Dict[str, Any]]:
    """The engine's answer as the ONE listing shape the panel shows
    (snapshot_id, committed_at, operation, summary, is_current)."""
    cols = [str(c).lower() for c in columns or []]
    out: List[Dict[str, Any]] = []
    t = str(connection_type or "").lower()
    for r in rows or []:
        rec = dict(zip(cols, r)) if not isinstance(r, dict) else {str(k).lower(): v for k, v in r.items()}
        if t == "databricks":
            sid, ts, op = rec.get("version"), rec.get("timestamp"), rec.get("operation")
            summ = rec.get("operationparameters") or rec.get("operationmetrics") or {}
        else:
            sid, ts, op = rec.get("snapshot_id"), rec.get("committed_at"), rec.get("operation")
            summ = rec.get("summary") or {}
        if sid is None:
            continue
        ms = _ms(ts)
        out.append({"snapshot_id": str(sid), "committed_at_ms": ms,
                    "committed_at": (_dt.datetime.fromtimestamp(ms / 1000, tz=_dt.timezone.utc)
                                     .isoformat(timespec="milliseconds").replace("+00:00", "Z") if ms else None),
                    "operation": str(op) if op is not None else None,
                    "summary": {str(k): str(v) for k, v in dict(summ).items()} if isinstance(summ, dict) else {},
                    "parent_id": (str(rec["parent_id"]) if rec.get("parent_id") is not None else None),
                    "is_current": False})
    out.sort(key=lambda x: x["committed_at_ms"] or 0, reverse=True)
    if out:
        out[0]["is_current"] = True
    return out


def list_versions(connector, connection_type: str, table: str) -> Dict[str, Any]:
    """Versions of ``table`` through an OPEN connector (``execute_query``
    returning ``{columns, rows}`` or ``(columns, rows)``).  A listing failure
    is the engine's sentence under ``error``, never an empty list."""
    sql = listing_sql(connection_type, table)
    if sql is None:
        return {"versions": None, "sql": None,
                "reason": "this source keeps no list of versions; pick a time instead"}
    try:
        res = connector.execute_query(sql)
        if res is None:
            raise RuntimeError("the source answered nothing")
        cols, rows = _split(res)
        return {"versions": rows_to_versions(connection_type, cols, rows), "sql": sql}
    except Exception as exc:                                   # noqa: BLE001
        # the sanitizer's sentence; the driver's own text goes to the log only
        # (security review of 5f04142e9)
        from core.table_version_access import failure_words
        return {"versions": None, "sql": sql, "error": failure_words(table, exc, verb="listed")}


def _split(res: Any):
    if isinstance(res, dict):
        return list(res.get("columns") or []), list(res.get("rows") or res.get("data") or [])
    if isinstance(res, tuple) and len(res) == 2:
        return list(res[0]), list(res[1])
    return [], list(res or [])


def snowflake_retention_days(connector, table: str) -> Optional[int]:
    """``DATA_RETENTION_TIME_IN_DAYS`` of ``table`` (SHOW PARAMETERS ... IN
    TABLE), or None when it could not be read -- unknown is not a window."""
    try:
        res = connector.execute_query(retention_sql("snowflake", table))
        cols, rows = _split(res)
        lc = [str(c).lower() for c in cols]
        for r in rows:
            rec = dict(zip(lc, r)) if not isinstance(r, dict) else {str(k).lower(): v for k, v in r.items()}
            if str(rec.get("key") or "").upper() == "DATA_RETENTION_TIME_IN_DAYS":
                return int(str(rec.get("value")).strip())
        if rows and len(rows[0]) >= 2 and not isinstance(rows[0], dict):
            return int(str(rows[0][1]).strip())
    except Exception:                                          # noqa: BLE001
        return SNOWFLAKE_RETENTION_UNKNOWN
    return SNOWFLAKE_RETENTION_UNKNOWN


def refuse_outside_snowflake_retention(table: str, as_of_ms: int, retention_days: Optional[int],
                                       now_ms: Optional[int] = None) -> None:
    """A time before the table's retention window is REFUSED here, with the
    window named, before any statement runs.  An unknown window refuses
    nothing (Snowflake answers then, with its own sentence)."""
    if retention_days is None:
        return
    import time as _time
    now = int(now_ms if now_ms is not None else _time.time() * 1000)
    floor = now - int(retention_days) * 86_400_000
    if int(as_of_ms) < floor:
        when = _dt.datetime.fromtimestamp(int(as_of_ms) / 1000, tz=_dt.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        raise IcebergVersionRefusal(
            f"{table} keeps {int(retention_days)} day(s) of history (Snowflake "
            f"DATA_RETENTION_TIME_IN_DAYS), so it cannot be read as of {when}. Pick a time "
            f"inside the last {int(retention_days)} day(s), or remove FOR TIMESTAMP AS OF to read it as it is now.")


_ORA_FLASHBACK = {
    "ORA-01555": "Oracle no longer holds the undo data for that time (ORA-01555: snapshot too old)",
    "ORA-08180": "Oracle has no data for that time (ORA-08180: no snapshot found based on specified time)",
    "ORA-08181": "the time is not inside Oracle's flashback window (ORA-08181)",
    "ORA-01031": "the login lacks the FLASHBACK privilege on the table (ORA-01031: insufficient privileges)",
    "ORA-08189": "the table does not allow flashback (ORA-08189: row movement is not enabled)",
}


def oracle_flashback_refusal(text: str) -> Optional[str]:
    """The plain sentence for an Oracle Flashback (``AS OF TIMESTAMP``)
    refusal in ``text``, or None when it is none of them."""
    s = str(text or "")
    for code, words in _ORA_FLASHBACK.items():
        if code in s.upper():
            return (f"The table could not be read as of that time: {words}. Pick a more recent "
                    f"time (inside the database's undo retention), ask for the FLASHBACK privilege, "
                    f"or remove FOR TIMESTAMP AS OF to read it as it is now.")
    return None
