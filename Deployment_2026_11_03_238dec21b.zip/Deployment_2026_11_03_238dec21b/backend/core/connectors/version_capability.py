"""Which connection types can read a table AT A VERSION, and how -- DECLARED,
one entry per connection type (the plugin pattern; never an if/elif chain).

2026-11-01, the owner: "how will it work in other sources like Starburst,
Snowflake etc."  The user writes Trino's spelling ONCE (``FROM t FOR VERSION
AS OF <id>`` / ``FOR TIMESTAMP AS OF TIMESTAMP '...'``); each connection
type declares:

* ``kinds`` -- which pins it can read: ``{"id", "timestamp"}`` / ``{"timestamp"}``
  / empty (none), with ``reason`` in plain words when it cannot;
* ``render_pin(table, pin)`` -- the clause in its own dialect, or a refusal;
* ``lists_versions`` / ``how_listed`` -- where its versions are listed.

A pin on a type that declares none is REFUSED, never ignored (ignoring it
returns current data under a historical label).  A connection type that
declares nothing is a guard failure
(``tests/test_iceberg_versions_2026_11_01.py::TestConnectorCapability``).

The timestamp is rendered in UTC with the zone written out, so no engine
reads it in its session time zone.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from typing import Callable, Dict, FrozenSet, Optional

KIND_ID = "id"
KIND_TIMESTAMP = "timestamp"


def _utc(ms: int) -> _dt.datetime:
    return _dt.datetime.fromtimestamp(int(ms) / 1000.0, tz=_dt.timezone.utc)


def _refuse(msg: str):
    from core.iceberg_versions import IcebergVersionRefusal
    raise IcebergVersionRefusal(msg)


@dataclass(frozen=True)
class VersionCapability:
    connection_type: str
    kinds: FrozenSet[str]
    reason: Optional[str] = None            # why not (kinds empty / partial)
    how_listed: Optional[str] = None        # where the versions are listed
    native_qs: bool = False                 # QueryStudio reads it itself
    _render_id: Optional[Callable[[str, int], str]] = field(default=None, repr=False)
    _render_ts: Optional[Callable[[str, int], str]] = field(default=None, repr=False)

    @property
    def supported(self) -> str:
        if KIND_ID in self.kinds and KIND_TIMESTAMP in self.kinds:
            return "both"
        if KIND_ID in self.kinds:
            return "id"
        if KIND_TIMESTAMP in self.kinds:
            return "timestamp"
        return "none"

    def render_pin(self, table: str, pin) -> str:
        """The clause that follows the table name in this dialect."""
        if pin.snapshot_id is not None:
            if KIND_ID not in self.kinds or self._render_id is None:
                _refuse(f"{table}: a {self.connection_type} source cannot be read at a "
                        f"version number. {self.reason or ''} ".strip())
            return self._render_id(table, int(pin.snapshot_id))
        if KIND_TIMESTAMP not in self.kinds or self._render_ts is None:
            _refuse(f"{table}: a {self.connection_type} source keeps no versions, so "
                    f"it cannot be read as of a time. {self.reason or ''}".strip())
        return self._render_ts(table, int(pin.as_of_ms))

    def describe(self) -> Dict[str, object]:
        return {"connection_type": self.connection_type, "supported": self.supported,
                "reason": self.reason, "how_listed": self.how_listed,
                "native": self.native_qs}


def _trino_id(t: str, sid: int) -> str:
    return f"FOR VERSION AS OF {sid}"


def _trino_ts(t: str, ms: int) -> str:
    return "FOR TIMESTAMP AS OF TIMESTAMP '" + \
        _utc(ms).strftime("%Y-%m-%d %H:%M:%S.") + f"{_utc(ms).microsecond // 1000:03d} UTC'"


def _snowflake_ts(t: str, ms: int) -> str:
    return "AT(TIMESTAMP => '" + _utc(ms).strftime("%Y-%m-%d %H:%M:%S.") + \
        f"{_utc(ms).microsecond // 1000:03d} +0000'::TIMESTAMP_TZ)"


def _databricks_id(t: str, sid: int) -> str:
    return f"VERSION AS OF {sid}"


def _databricks_ts(t: str, ms: int) -> str:
    return "TIMESTAMP AS OF '" + _utc(ms).strftime("%Y-%m-%dT%H:%M:%S.") + \
        f"{_utc(ms).microsecond // 1000:03d}Z'"


def _oracle_ts(t: str, ms: int) -> str:
    return ("AS OF TIMESTAMP TO_TIMESTAMP_TZ('" + _utc(ms).strftime("%Y-%m-%d %H:%M:%S.") +
            f"{_utc(ms).microsecond // 1000:03d} +00:00', 'YYYY-MM-DD HH24:MI:SS.FF3 TZH:TZM')")


_TRINO_LIST = 'SELECT * FROM "<schema>"."<table>$snapshots" on the connection'

_NONE_PARQUET = ("Plain parquet, Hive-style folders and local files keep no versions; "
                 "only an Iceberg table does.")

#: THE declarations.  Every connection type the product creates is a key.
CAPABILITIES: Dict[str, VersionCapability] = {
    # QueryStudio's own S3 / Iceberg read: resolved from metadata.json.
    "s3": VersionCapability(
        "s3", frozenset({KIND_ID, KIND_TIMESTAMP}), native_qs=True,
        reason="Only the connection's registered ICEBERG tables have versions. " + _NONE_PARQUET,
        how_listed='the "Table version" picker, SELECT * FROM "<table>$snapshots", or '
                   'GET /api/connections/{id}/iceberg/{table}/snapshots'),
    "local": VersionCapability(
        "local", frozenset(), reason=_NONE_PARQUET),
    "upload": VersionCapability(
        "upload", frozenset(), reason="An uploaded file keeps no versions."),
    "trino": VersionCapability(
        "trino", frozenset({KIND_ID, KIND_TIMESTAMP}),
        reason="Trino reads versions of Iceberg tables only; it refuses the clause on a "
               "Hive table.",
        how_listed=_TRINO_LIST,
        _render_id=_trino_id, _render_ts=_trino_ts),
    "starburst": VersionCapability(
        "starburst", frozenset({KIND_ID, KIND_TIMESTAMP}),
        reason="Starburst reads versions of Iceberg tables only; it refuses the clause on "
               "a Hive table.",
        how_listed=_TRINO_LIST,
        _render_id=_trino_id, _render_ts=_trino_ts),
    "athena": VersionCapability(
        "athena", frozenset({KIND_ID, KIND_TIMESTAMP}),
        reason="Athena reads versions of Iceberg tables only.",
        how_listed=_TRINO_LIST,
        _render_id=_trino_id, _render_ts=_trino_ts),
    "snowflake": VersionCapability(
        "snowflake", frozenset({KIND_TIMESTAMP}),
        reason="Snowflake Time Travel reads a table as of a TIME within its retention "
               "window (DATA_RETENTION_TIME_IN_DAYS); it has no version numbers to list.",
        how_listed="no list: pick a time within the table's retention window",
        _render_ts=_snowflake_ts),
    "databricks": VersionCapability(
        "databricks", frozenset({KIND_ID, KIND_TIMESTAMP}),
        reason="Databricks reads Delta table versions.",
        how_listed="DESCRIBE HISTORY <table> on the connection",
        _render_id=_databricks_id, _render_ts=_databricks_ts),
    "oracle": VersionCapability(
        "oracle", frozenset({KIND_TIMESTAMP}),
        reason="Oracle Flashback reads a table as of a TIME, within the database's undo "
               "retention and with the FLASHBACK privilege.",
        how_listed="no list: pick a time within the database's undo retention",
        _render_ts=_oracle_ts),
    "rest_api": VersionCapability(
        "rest_api", frozenset(), reason="A REST source keeps no versions."),
    "postgresql": VersionCapability(
        "postgresql", frozenset(), reason="PostgreSQL keeps no table versions."),
}


for _alias in ("s3_minio", "s3_compatible"):
    CAPABILITIES[_alias] = VersionCapability(
        _alias, CAPABILITIES["s3"].kinds, native_qs=True,
        reason=CAPABILITIES["s3"].reason, how_listed=CAPABILITIES["s3"].how_listed)


def capability_for(connection_type: Optional[str]) -> VersionCapability:
    """The declaration for ``connection_type``; an undeclared type reads as
    NONE with that reason (unknown is never "supported")."""
    t = str(connection_type or "").strip().lower()
    cap = CAPABILITIES.get(t)
    if cap is not None:
        return cap
    return VersionCapability(t or "unknown", frozenset(),
                             reason=f"The {t or 'unknown'} source type declares no versions.")
