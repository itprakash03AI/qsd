"""The runs a query-pod size holds -- ONE number, read two ways.

KEDA's PostgreSQL trigger runs :func:`in_flight_sql` (the query-pods chart
renders the same text; ``tests/test_query_pod_scaling_2026_10_29.py``
compares them); the built-in scaler reads the same predicate through
``JobQueue.demand_by_class`` (the table's chokepoint).  Both turn it into
pods with :func:`desired_replicas` -- the HPA's own rule for an AverageValue
target: ceil(runs / runs per pod), inside the size's min and max.
"""
from __future__ import annotations

import math
from typing import Any, Dict, Iterable, Optional

from core.query_pods.classes import PodClass

#: a run occupies its size's pods while it is waiting, claimed or running
IN_FLIGHT_STATUSES = ("queued", "leased", "running")
#: fleet-admission slot rows live in query_jobs too; they are not runs
NOT_A_RUN_KIND = "fleet_slot"


def in_flight_sql(cls: PodClass) -> str:
    """The text KEDA runs for ``cls`` (one value: the runs the size holds)."""
    statuses = ", ".join(f"'{s}'" for s in IN_FLIGHT_STATUSES)
    return (f"SELECT COUNT(*) FROM query_jobs WHERE status IN ({statuses}) "
            f"AND kind <> '{NOT_A_RUN_KIND}' AND pod_class = '{cls.name}'")


#: the HPA's own tolerance (kube-controller-manager's default, 0.1): a size
#: whose runs per pod are within 10 % of its target keeps its pods
HPA_TOLERANCE = 0.1


def desired_replicas(in_flight: int, cls: PodClass, current: Optional[int] = None) -> int:
    """The HPA's rule for an AverageValue target, so both scalers give one
    answer: ceil(runs / runs_per_pod); a size already within the tolerance of
    its target keeps ``current``; then inside min..max."""
    runs = max(0, int(in_flight))
    want = math.ceil(runs / cls.runs_per_pod)
    if current:
        ratio = runs / (cls.runs_per_pod * current)
        if abs(ratio - 1.0) <= HPA_TOLERANCE:
            want = current
    return max(cls.min, min(cls.max, want))


def read_demand(db: Any, classes: Iterable[PodClass]) -> Dict[str, Dict[str, Optional[int]]]:
    """Per size: in_flight, queued, oldest_wait_s.  Raises when unreadable."""
    from core.jobqueue.queue import JobQueue
    return JobQueue(db).demand_by_class([c.name for c in classes])


__all__ = ["IN_FLIGHT_STATUSES", "NOT_A_RUN_KIND", "desired_replicas", "in_flight_sql", "read_demand"]
