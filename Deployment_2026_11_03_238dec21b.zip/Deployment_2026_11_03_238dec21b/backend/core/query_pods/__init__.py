"""Query pods by SIZE, and who scales them (2026-10-29).

Design: docs/QUERY_PODS_DESIGN_2026_10_29.html, phase 3.  A size (``s`` /
``m`` / ``l`` ...) is one Deployment of job-queue executors, rendered by the
query-pods chart from ``querystudio.query_pods`` -- the SAME block this
process reads as config, so the warm minimum, the maximum, the runs per pod
and the cooldown cannot differ between the two scalers.

* ``classes``  -- the sizes and their limits (THE reader of the config).
* ``demand``   -- the runs a size holds, the number both scalers divide by
  runs-per-pod (KEDA's trigger renders the same predicate).
* ``kube``     -- the four Kubernetes reads/writes the scaler needs.
* ``scaler``   -- the decision per size and the tick on the scheduler pod:
  KEDA scales and QueryStudio watches, or QueryStudio scales; one controller
  per size, never two.
"""
