"""The four Kubernetes calls the query-pod scaler makes.

Read a size's Deployment replicas, set them, list the HPAs that target it,
and read its KEDA ScaledObject's Ready condition.  RBAC: the scheduler
chart's ``rbac-query-pods.yaml`` grants exactly these (deployments get,
deployments/scale get + patch, horizontalpodautoscalers list,
scaledobjects get) when query pods are configured, each scoped BY NAME to
the query-pod Deployments (deployment_prefix + size) except the HPA list.

Unknown is never empty: a failed read RAISES :class:`KubeReadError` with the
reason; only a 404 means "not there".
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

KEDA_GROUP = "keda.sh"
KEDA_VERSION = "v1alpha1"
KEDA_PLURAL = "scaledobjects"
_SA_NAMESPACE_FILE = "/var/run/secrets/kubernetes.io/serviceaccount/namespace"


class KubeReadError(RuntimeError):
    """Kubernetes could not answer; the message says what was asked.
    ``status`` is the HTTP status when Kubernetes answered (403 = the Role
    does not name this Deployment), None for a transport failure."""

    def __init__(self, message: str, status: Optional[int] = None):
        super().__init__(message)
        self.status = status


def keda_hpa_name(scaled_object: str) -> str:
    """The HPA KEDA creates for a ScaledObject (KEDA's own naming)."""
    return f"keda-hpa-{scaled_object}"


class QueryPodKube:
    def __init__(self, namespace: str = ""):
        from kubernetes import client as k8s_client
        from kubernetes import config as k8s_config
        in_cluster = True
        try:
            k8s_config.load_incluster_config()
        except Exception:                                  # noqa: BLE001 -- second source next
            in_cluster = False
            k8s_config.load_kube_config()
        self._exc = k8s_client.exceptions.ApiException
        self._apps = k8s_client.AppsV1Api()
        self._autoscaling = k8s_client.AutoscalingV2Api()
        self._custom = k8s_client.CustomObjectsApi()
        self.namespace = namespace or self._own_namespace(in_cluster, k8s_config)

    @staticmethod
    def _own_namespace(in_cluster: bool, k8s_config) -> str:
        if in_cluster and os.path.isfile(_SA_NAMESPACE_FILE):
            with open(_SA_NAMESPACE_FILE, encoding="utf-8") as fh:
                return fh.read().strip() or "default"
        try:
            _contexts, active = k8s_config.list_kube_config_contexts()
            return ((active or {}).get("context") or {}).get("namespace") or "default"
        except Exception:                                  # noqa: BLE001
            return "default"

    def _call(self, what: str, fn, *args, missing_ok: bool = True, **kwargs):
        try:
            return fn(*args, **kwargs)
        except self._exc as exc:
            if missing_ok and getattr(exc, "status", None) == 404:
                return None
            raise KubeReadError(f"{what}: HTTP {exc.status} {exc.reason}",
                                status=getattr(exc, "status", None)) from exc
        except Exception as exc:                           # noqa: BLE001 -- transport
            raise KubeReadError(f"{what}: {type(exc).__name__}: {exc}") from exc

    def replicas(self, deployment: str) -> Optional[int]:
        """The Deployment's spec replicas; None when it does not exist."""
        scale = self._call(f"read the scale of Deployment {deployment}",
                           self._apps.read_namespaced_deployment_scale, deployment, self.namespace)
        if scale is None:
            return None
        return int(getattr(scale.spec, "replicas", 0) or 0)

    def set_replicas(self, deployment: str, n: int) -> None:
        # a 404 here is a FAILED change (the Deployment went away), never "done"
        self._call(f"set Deployment {deployment} to {n} pods",
                   self._apps.patch_namespaced_deployment_scale, deployment, self.namespace,
                   {"spec": {"replicas": int(n)}}, missing_ok=False)

    def hpas_targeting(self, deployment: str) -> List[str]:
        got = self._call("list the HorizontalPodAutoscalers",
                         self._autoscaling.list_namespaced_horizontal_pod_autoscaler, self.namespace)
        out = []
        for h in getattr(got, "items", None) or []:
            ref = h.spec.scale_target_ref
            if (ref.kind or "") == "Deployment" and (ref.name or "") == deployment:
                out.append(h.metadata.name)
        return sorted(out)

    def scaled_object(self, name: str) -> Optional[Dict[str, Any]]:
        """``{"ready": bool, "message": str}`` or None when there is none
        (or KEDA's CRD is not installed: the API answers 404 for both)."""
        so = self._call(f"read KEDA ScaledObject {name}", self._custom.get_namespaced_custom_object,
                        KEDA_GROUP, KEDA_VERSION, self.namespace, KEDA_PLURAL, name)
        if so is None:
            return None
        ready, message = False, "KEDA has not reported on it yet"
        for c in (so.get("status") or {}).get("conditions") or []:
            if c.get("type") == "Ready":
                ready = str(c.get("status")) == "True"
                message = str(c.get("message") or c.get("reason") or message)
        return {"ready": ready, "message": message}


__all__ = ["KubeReadError", "QueryPodKube", "keda_hpa_name"]
