"""Which query pods are alive, by size (query pods phase 2, 2026-10-31).

A sized run waits for a pod of its size.  If no pod of that size exists -- not
configured, not yet scaled up, all crashed -- the run must SAY so, never wait
in silence (design §5b: "the queue grows without end ... never an unbounded
wait").  So every query pod writes one row, ``query_pod_heartbeats``, every
few seconds: its host, size, budget, runs in flight and whether it is
draining.  The API reads the rows to tell a waiting run how many pods of its
size are alive; the sweeper fails a sized run that has waited
``query_pods.no_pod_fail_seconds`` with none alive.

Nothing here decides admission (the budgeted claim does, from the job rows);
this is presence only.  Every read fails SOFT to "unknown" (None), never to
"zero": an unreadable table must not fail a run for a pod that is there.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from sqlalchemy import text as sa_text

logger = logging.getLogger(__name__)


def seen_within_seconds() -> float:
    try:
        from core.query_pods.budget import cfg_number
        return max(10.0, cfg_number("pod_seen_within_seconds", 90))
    except Exception:
        return 90.0


def no_pod_fail_seconds() -> float:
    try:
        from core.query_pods.budget import cfg_number
        return max(60.0, cfg_number("no_pod_fail_seconds", 600))
    except Exception:
        return 600.0


def beat(db, *, host: str, pod_class: str, budget_bytes: int, in_flight: int,
         draining: bool, now: Optional[float] = None) -> bool:
    """This pod's "I am alive" row (insert or update).  Never raises."""
    if db is None or not host or not pod_class:
        return False
    ts = float(now if now is not None else time.time())
    try:
        with db.get_session() as session:
            n = session.execute(sa_text(
                "UPDATE query_pod_heartbeats SET pod_class = :pc, seen_at = :ts, budget_bytes = :b, "
                "in_flight = :n, draining = :d WHERE host = :host"
            ), {"pc": pod_class, "ts": ts, "b": int(budget_bytes or 0), "n": int(in_flight or 0),
                "d": bool(draining), "host": host}).rowcount
            if n == 0:
                session.execute(sa_text(
                    "INSERT INTO query_pod_heartbeats (host, pod_class, seen_at, budget_bytes, in_flight, draining) "
                    "VALUES (:host, :pc, :ts, :b, :n, :d)"
                ), {"host": host, "pc": pod_class, "ts": ts, "b": int(budget_bytes or 0),
                    "n": int(in_flight or 0), "d": bool(draining)})
        return True
    except Exception as exc:  # noqa: BLE001 -- presence must never fail a run
        logger.debug("[query-pods] heartbeat row not written for %s: %s", host, exc)
        return False


def forget(db, host: str) -> None:
    """A pod that exits cleanly removes its row (a crashed one ages out)."""
    if db is None or not host:
        return
    try:
        with db.get_session() as session:
            session.execute(sa_text("DELETE FROM query_pod_heartbeats WHERE host = :host"), {"host": host})
    except Exception as exc:  # noqa: BLE001
        logger.debug("[query-pods] heartbeat row not removed for %s: %s", host, exc)


def alive(db, pod_class: str, *, now: Optional[float] = None,
          within: Optional[float] = None) -> Optional[List[Dict[str, Any]]]:
    """The pods of ``pod_class`` seen alive within ``within`` seconds (not
    draining), or None when the table cannot be read -- unknown is not zero."""
    if db is None:
        return None
    ts = float(now if now is not None else time.time())
    horizon = ts - float(within if within is not None else seen_within_seconds())
    try:
        with db.get_session(read_only=True) as session:
            rows = session.execute(sa_text(
                "SELECT host, seen_at, budget_bytes, in_flight, draining FROM query_pod_heartbeats "
                "WHERE pod_class = :pc AND seen_at >= :h ORDER BY host"
            ), {"pc": str(pod_class or ""), "h": horizon}).fetchall()
    except Exception as exc:  # noqa: BLE001
        logger.debug("[query-pods] heartbeat rows unreadable: %s", exc)
        return None
    return [{"host": r[0], "seen_at": float(r[1]), "budget_bytes": int(r[2] or 0),
             "in_flight": int(r[3] or 0), "draining": bool(r[4])} for r in rows if not bool(r[4])]


def alive_count(db, pod_class: str, **kw) -> Optional[int]:
    rows = alive(db, pod_class, **kw)
    return None if rows is None else len(rows)


def no_pod_sentence(pod_class: str, waited_s: Optional[float] = None) -> str:
    """Plain words for a run whose size has no pod alive."""
    size = f"size {str(pod_class).upper()}" if pod_class else "this size"
    if waited_s is None:
        return (f"No query pod of {size} is running right now. The run will start as soon as "
                f"one is up; if none comes, it is stopped with this message.")
    mins = max(1, int(round(float(waited_s) / 60.0)))
    return (f"No query pod of {size} came up in {mins} min, so this run was stopped. "
            f"Ask an admin to check the query pods, then press Run again.")


__all__ = ["alive", "alive_count", "beat", "forget", "no_pod_fail_seconds", "no_pod_sentence",
           "seen_within_seconds"]
