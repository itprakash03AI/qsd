"""Who scales each query-pod size, and the scaler QueryStudio carries.

Design: docs/QUERY_PODS_DESIGN_2026_10_29.html §5.5.  ONE controller per size
-- two would fight (KEDA's HPA undoes any other change to replicas):

* ``scaler = keda``: KEDA's ScaledObject scales the size; QueryStudio only
  WATCHES.  A ScaledObject that is not Ready, or runs waiting past
  ``wait_alert_seconds`` while KEDA holds the size at its minimum, is said on
  Component Health (and so alerted) in words -- never fought.  QueryStudio
  scales a size itself ONLY when NOTHING owns it (no ScaledObject, no HPA:
  KEDA not installed, the object deleted).
* ``scaler = builtin``: QueryStudio scales; a size that something else also
  scales is left alone and said.

Both scalers read the same limits (``classes``) and the same number
(``demand``).  Scale-up is immediate; scale-down waits ``cooldown_seconds``
of lower demand (the HPA's stabilization window, the same value KEDA gets).
:func:`decide` is pure; :func:`tick` reads, decides, acts, records.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from core.query_pods.classes import SCALER_BUILTIN, SCALER_KEDA, PodClass, Settings, SettingsError, load_settings
from core.query_pods.demand import desired_replicas

logger = logging.getLogger(__name__)

ACTOR = "query_pod_scaler"

HEALTHY, DEGRADED, DOWN, UNKNOWN = "healthy", "degraded", "down", "unknown"
CONTROLLER_KEDA, CONTROLLER_QS, CONTROLLER_HPA, CONTROLLER_NONE = "keda", "querystudio", "hpa", "none"


@dataclass
class Decision:
    pod_class: str
    scaler: str
    controller: str
    state: str
    reason: str
    deployment: str
    replicas: Optional[int] = None
    desired: Optional[int] = None
    in_flight: Optional[int] = None
    queued: Optional[int] = None
    oldest_wait_s: Optional[int] = None
    #: set when QueryStudio should change the replicas (it is the controller)
    scale_to: Optional[int] = None


def _wait_words(seconds: Optional[int]) -> str:
    s = int(seconds or 0)
    return f"{s} s" if s < 120 else f"{s // 60} min"


def _runs(n: Optional[int]) -> str:
    n = int(n or 0)
    return f"{n} run" if n == 1 else f"{n} runs"


class Stabilizer:
    """Scale-down only after the demand stayed lower for the cooldown -- the
    HPA's rule: the target is the HIGHEST recommendation inside the window.
    Memory of one process (the lock holder); a fresh one waits a full window
    before shrinking anything, so a lock move never shrinks early."""

    def __init__(self):
        self._lock = threading.Lock()
        self._seen: Dict[str, List[Tuple[float, int]]] = {}
        self._since: Dict[str, float] = {}

    def target(self, name: str, recommended: int, current: int, cooldown: float, now: float) -> int:
        with self._lock:
            hist = self._seen.setdefault(name, [])
            self._since.setdefault(name, now)
            hist.append((now, recommended))
            hist[:] = [(t, r) for t, r in hist if t >= now - cooldown]
            if recommended >= current:
                return recommended
            if now - self._since[name] < cooldown:
                return current
            return max(recommended, max(r for _t, r in hist))

    def forget(self, name: str) -> None:
        with self._lock:
            self._seen.pop(name, None)
            self._since.pop(name, None)


_STABILIZER = Stabilizer()


def decide(cls: PodClass, settings: Settings, *, demand: Optional[Dict[str, Optional[int]]],
           demand_error: Optional[str], observed: Optional[Dict[str, Any]], kube_error: Optional[str],
           stabilize=None, now: Optional[float] = None, kube_forbidden: bool = False) -> Decision:
    """One size's verdict.  ``observed`` = {replicas, scaled_object, hpas}.
    ``kube_forbidden``: Kubernetes answered 403 -- the scheduler's Role names
    each size's Deployment, so the size is missing from the chart's list."""
    dep = settings.deployment(cls)
    d = Decision(pod_class=cls.name, scaler=settings.scaler, controller=CONTROLLER_NONE,
                 state=UNKNOWN, reason="", deployment=dep)
    L = cls.label
    if demand is not None:
        d.in_flight, d.queued, d.oldest_wait_s = (demand.get("in_flight"), demand.get("queued"),
                                                   demand.get("oldest_wait_s"))
    if kube_forbidden:
        d.state = DOWN
        d.reason = (f"Size {L}: Kubernetes does not let QueryStudio read the Deployment {dep}. "
                    f"The scheduler chart's query_pods.classes must list every size in the "
                    f"query_pods.classes setting: add {L} there and upgrade the scheduler chart. "
                    f"Nothing was changed.")
        return d
    if kube_error is not None or observed is None:
        d.reason = f"Could not reach Kubernetes to read size {L} ({kube_error}). Nothing was changed."
        return d
    d.replicas = observed.get("replicas")
    so = observed.get("scaled_object")
    from core.query_pods.kube import keda_hpa_name
    others = [h for h in observed.get("hpas") or [] if not (so is not None and h == keda_hpa_name(dep))]
    if so is not None:
        d.controller = CONTROLLER_KEDA
    elif others:
        d.controller = CONTROLLER_HPA
    if d.replicas is None:
        d.state = DOWN
        d.reason = (f"Size {L}: the Deployment {dep} does not exist. Install the query-pods chart "
                    f"with this size, or remove the size from query_pods.classes.")
        return d
    if demand is None:
        d.reason = f"Could not read the runs waiting for size {L} ({demand_error}). Nothing was changed."
        return d
    d.desired = desired_replicas(d.in_flight or 0, cls, d.replicas)
    waiting_long = bool(d.queued) and int(d.oldest_wait_s or 0) >= settings.wait_alert_seconds
    waiting = f"{_runs(d.queued)} waiting {_wait_words(d.oldest_wait_s)}"
    at_max = (f"Size {L} is at its maximum of {cls.max} pods: {waiting}. "
              f"Raise max for size {L} or add capacity.")

    if settings.scaler == SCALER_KEDA:
        if so is not None:
            if others:
                d.state = DEGRADED
                d.reason = (f"Size {L} has KEDA and another autoscaler ({', '.join(others)}). "
                            f"Two controllers fight over the pod count: remove {', '.join(others)}.")
            elif not so.get("ready"):
                d.state = DEGRADED
                d.reason = (f"KEDA is not ready for size {L} ({so.get('message')}), so no pods are added "
                            f"when runs wait. Fix KEDA, or switch query_pods.scaler to builtin.")
            elif waiting_long and d.replicas <= cls.min and d.desired > d.replicas:
                d.state = DEGRADED
                d.reason = (f"KEDA is not adding query pods for size {L}: {waiting}. "
                            f"Switch query_pods.scaler to builtin.")
            elif waiting_long and d.replicas >= cls.max:
                d.state = DEGRADED
                d.reason = at_max
            else:
                d.state = HEALTHY
                d.reason = (f"Size {L} is scaled by KEDA: {d.replicas} pods, {_runs(d.in_flight)} "
                            f"({int(d.queued or 0)} waiting).")
            return d
        if others:
            d.state = DEGRADED
            d.reason = (f"Size {L} is scaled by {', '.join(others)}, not by KEDA. "
                        f"QueryStudio leaves it alone.")
            return d
        # nothing owns the size: take over, said
        d.controller = CONTROLLER_QS
        d.state = DEGRADED
        d.reason = (f"KEDA is not scaling size {L} (there is no ScaledObject {dep}), so QueryStudio "
                    f"is scaling it: ")
    else:
        if so is not None or others:
            owner = "KEDA" if so is not None else ", ".join(others)
            d.state = DEGRADED
            d.reason = (f"Size {L} is also scaled by {owner}. One controller per size: remove it, "
                        f"or set query_pods.scaler to keda.")
            return d
        d.controller = CONTROLLER_QS
        d.state = HEALTHY
        d.reason = f"Size {L} is scaled by QueryStudio: "

    stab = stabilize or _STABILIZER.target
    target = stab(cls.name, d.desired, d.replicas, float(settings.cooldown_seconds),
                  float(now if now is not None else time.time()))
    target = max(cls.min, min(cls.max, int(target)))
    if target != d.replicas:
        d.scale_to = target
    pods = d.replicas if d.scale_to is None else d.scale_to
    d.reason += f"{pods} pods, {_runs(d.in_flight)} ({int(d.queued or 0)} waiting)."
    if waiting_long and pods >= cls.max:
        d.state = DEGRADED
        d.reason += " " + at_max
    return d


# ── the tick ───────────────────────────────────────────────────────────────

def _observe(kube, dep: str) -> Dict[str, Any]:
    return {"replicas": kube.replicas(dep), "scaled_object": kube.scaled_object(dep),
            "hpas": kube.hpas_targeting(dep)}


def _write_state(db, decisions: List[Decision], changes: Dict[str, str], keep: List[str]) -> None:
    from core.db.models import QueryPodScalerState
    now = datetime.now(timezone.utc)
    with db.get_session() as s:
        for d in decisions:
            row = s.get(QueryPodScalerState, d.pod_class) or QueryPodScalerState(pod_class=d.pod_class)
            for k, v in asdict(d).items():
                if k != "scale_to" and hasattr(row, k):
                    setattr(row, k, v)
            row.reason = d.reason
            row.at = now
            if d.pod_class in changes:
                row.last_change, row.last_change_at = changes[d.pod_class], now
            s.merge(row)
        q = s.query(QueryPodScalerState)
        if keep:
            q = q.filter(~QueryPodScalerState.pod_class.in_(keep))
        q.delete(synchronize_session=False)


def _audit(db, d: Decision, before: int, after: int, words: str) -> None:
    try:
        from core.audit import audit_event
        audit_event(db, {"username": ACTOR}, action="query_pods.scaled", resource_type="query_pod_class",
                    resource_id=d.pod_class,
                    details={"deployment": d.deployment, "from": before, "to": after,
                             "in_flight": d.in_flight, "queued": d.queued, "words": words})
    except Exception as exc:                               # noqa: BLE001
        logger.warning("[query_pods] audit of %s %s->%s not written: %s", d.pod_class, before, after, exc)


def tick(db, *, kube_factory=None, settings: Optional[Settings] = None) -> Dict[str, Any]:
    """One pass over every configured size.  Returns the ledger summary."""
    try:
        settings = settings or load_settings()
    except SettingsError as exc:
        return {"status": "error", "reason": str(exc)}
    if not settings.classes:
        try:
            _write_state(db, [], {}, [])
        except Exception:                                  # noqa: BLE001
            pass
        return {"status": "no_input", "reason": "no query pod sizes are configured (query_pods.classes)",
                "sizes": 0}
    demand, demand_error = None, None
    try:
        from core.query_pods.demand import read_demand
        demand = read_demand(db, settings.classes)
    except Exception as exc:                               # noqa: BLE001
        demand_error = f"{type(exc).__name__}: {exc}"
    kube, kube_error = None, None
    try:
        if kube_factory is not None:
            kube = kube_factory(settings.namespace)
        else:
            from core.query_pods.kube import QueryPodKube
            kube = QueryPodKube(settings.namespace)
    except Exception as exc:                               # noqa: BLE001
        kube_error = f"{type(exc).__name__}: {exc}"
    decisions: List[Decision] = []
    changes: Dict[str, str] = {}
    for cls in settings.classes:
        dep = settings.deployment(cls)
        observed, err, forbidden = None, kube_error, False
        if kube is not None:
            try:
                observed = _observe(kube, dep)
            except Exception as exc:                       # noqa: BLE001
                err = str(exc)
                forbidden = getattr(exc, "status", None) == 403
        d = decide(cls, settings, demand=(demand or {}).get(cls.name) if demand is not None else None,
                   demand_error=demand_error, observed=observed, kube_error=err,
                   kube_forbidden=forbidden)
        if d.scale_to is not None and kube is not None:
            before = int(d.replicas or 0)
            words = (f"{cls.label} pods: {before} -> {d.scale_to}, {_runs(d.in_flight)} "
                     f"({int(d.queued or 0)} waiting), by QueryStudio")
            try:
                kube.set_replicas(dep, d.scale_to)
                changes[cls.name] = words
                _audit(db, d, before, d.scale_to, words)
                d.replicas = d.scale_to
                logger.info("[query_pods] %s", words)
            except Exception as exc:                       # noqa: BLE001
                d.state = DOWN
                d.reason = (f"QueryStudio could not change size {cls.label} from {before} to "
                            f"{d.scale_to} pods ({exc}). {_runs(d.queued)} waiting.")
        if d.controller != CONTROLLER_QS:
            _STABILIZER.forget(cls.name)
        decisions.append(d)
    try:
        _write_state(db, decisions, changes, [c.name for c in settings.classes])
    except Exception as exc:                               # noqa: BLE001
        logger.warning("[query_pods] verdicts not written: %s", exc)
    # the TICK ran: "ok".  A size that is not healthy is the size's verdict
    # (Component Health, dependency:query_pods), never a failed tick.
    return {"status": "ok", "sizes": len(decisions), "scaled": len(changes),
            "not_healthy": sum(1 for d in decisions if d.state != HEALTHY),
            "changes": list(changes.values()),
            "classes": {d.pod_class: {"state": d.state, "controller": d.controller, "replicas": d.replicas,
                                      "desired": d.desired, "in_flight": d.in_flight, "queued": d.queued,
                                      "reason": d.reason} for d in decisions}}


def read_state(db) -> List[Dict[str, Any]]:
    from core.db.models import QueryPodScalerState
    with db.get_session(read_only=True) as s:
        return [r.to_dict() for r in s.query(QueryPodScalerState).order_by(QueryPodScalerState.pod_class)]


def status(db) -> Dict[str, Any]:
    try:
        settings = load_settings()
    except SettingsError as exc:
        return {"state": "error", "settings_error": str(exc)}
    return {"scaler": settings.scaler, "sizes": [c.name for c in settings.classes],
            "verdicts": read_state(db)}


__all__ = ["ACTOR", "Decision", "Stabilizer", "decide", "read_state", "status", "tick"]
