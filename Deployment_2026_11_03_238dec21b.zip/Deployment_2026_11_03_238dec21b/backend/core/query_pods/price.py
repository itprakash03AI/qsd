"""The PRICE of a run before it starts: the memory it will need, and the
query-pod size that fits it (design §5.2).

Three sources, tried in this order, each saying which it was:

* ``history``       -- this plan ran before and its DuckDB children's peak
                       memory was MEASURED (``query_jobs.actual_peak_bytes``,
                       the passport's ``actuals.peak_memory_bytes``), times a
                       safety margin (``query_pods.price_safety_margin``).
                       An over-budget run that DuckDB stopped is history too:
                       its recorded peak is at least its reservation, so the
                       next price is higher (calibration, §5b).
* ``estimate``      -- never ran: the files it reads (concrete file URIs in
                       ``query_config.files`` and the bytes the pruner measured
                       for them, else the last passport's island estimate)
                       through the EXISTING cost model
                       (``core.resource_admission.estimate_query_resources``),
                       with the width rule (``min_memory_mb_for_width``) as the
                       engine floor and a sort / group doubling for spill.
* ``class_default`` -- nothing is known: the smallest size's whole budget
                       (``query_pods.unknown_price_mb`` overrides), never zero.

The price is floored at ``query_pods.min_price_mb``.  The size is the
smallest configured one whose budget (``budget.class_budget_bytes``) holds
the price; when none does the caller REFUSES the run with the numbers in
plain words -- it is never started to die, and never queued to wait forever
(no pod of any size could ever claim it).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from core.query_pods import budget as _budget
from core.query_pods.classes import Settings

logger = logging.getLogger(__name__)

SOURCE_HISTORY = "history"
SOURCE_ESTIMATE = "estimate"
SOURCE_CLASS_DEFAULT = "class_default"

_SPILL_WORDS = ("order by", "group by", "distinct", "over (", "over(", "partition by")


@dataclass(frozen=True)
class Price:
    bytes: int
    source: str
    pod_class: Optional[str]
    reason: str = ""                     # plain words when pod_class is None
    detail: Dict[str, Any] = field(default_factory=dict)

    @property
    def too_big(self) -> bool:
        return self.pod_class is None and self.bytes > 0

    def as_dict(self) -> Dict[str, Any]:
        return {"bytes": self.bytes, "source": self.source, "pod_class": self.pod_class,
                "reason": self.reason, "detail": dict(self.detail)}


class TooBigForQueryPods(Exception):
    """No configured size can hold this run.  ``str(exc)`` is the sentence
    the user reads; ``price`` carries the numbers."""

    def __init__(self, price: Price):
        super().__init__(price.reason)
        self.price = price


def too_big_message(price_bytes: int, settings: Settings, *,
                    after_oom_bytes: Optional[int] = None) -> str:
    """The refusal in plain words.  ``after_oom_bytes``: the price came from
    a run of this query that ran out of the memory set aside for it -- said,
    so a refusal born of the ratchet is never a surprise."""
    big = _budget.largest_class(settings)
    if big is None:
        return "No query pod sizes are configured."
    why = ""
    if after_oom_bytes:
        why = (f" The last run of this query ran out of the {_budget.memory_words(int(after_oom_bytes))} "
               f"set aside for it, so it is now priced higher.")
    return (f"This run needs about {_budget.memory_words(price_bytes)}; the largest query pod "
            f"(size {big.label}) has {_budget.memory_words(_budget.class_budget_bytes(big))} for runs.{why} "
            f"Narrow the dates or filters, or ask for a bigger size.")


#: The out-of-memory ratchet's bound: a failed run raises the next price to
#: at most this many times what it was priced at (security review
#: 2026-10-31 -- an unbounded ratchet, fed by a measured RSS the sampler
#: happened to catch high, priced a run straight to a refusal).
RATCHET_MAX_FACTOR = 2.0


# ── the estimate ────────────────────────────────────────────────────────────

def _columns_in_request(payload: Dict[str, Any]) -> int:
    """How many columns the run produces, when that can be read before it
    runs (the SQL's output list; the builder's column list).  0 = unknown."""
    try:
        raw_sql = payload.get("raw_sql")
        if isinstance(raw_sql, str) and raw_sql.strip():
            from core.sql_output_columns import derive_columns_from_sql_text
            cols = derive_columns_from_sql_text(raw_sql)
            if cols and not any(str(c.get("name", "")).strip() == "*" for c in cols):
                return len(cols)
            return 0
        qc = payload.get("query_config") or {}
        cols = qc.get("columns") if isinstance(qc, dict) else None
        return len(cols) if isinstance(cols, list) and cols else 0
    except Exception as exc:
        logger.debug("[query-pods] column count unreadable (unknown): %s", exc)
        return 0


def _sorts_or_groups(payload: Dict[str, Any]) -> bool:
    try:
        raw_sql = payload.get("raw_sql")
        if isinstance(raw_sql, str):
            low = " ".join(raw_sql.lower().split())
            if any(w in low for w in _SPILL_WORDS):
                return True
        qc = payload.get("query_config") or {}
        if isinstance(qc, dict):
            return bool(qc.get("order_by") or qc.get("group_by") or qc.get("distinct")
                        or qc.get("aggregations") or qc.get("window_functions"))
    except Exception:
        pass
    return False


def _measured_files(payload: Dict[str, Any]):
    """(file_count, known_bytes) for CONCRETE file URIs the request names, or
    None when the request names prefixes / nothing (a prefix is many files
    and its size is unknown here -- unknown is not one file of 0 bytes)."""
    qc = payload.get("query_config") or {}
    files = qc.get("files") if isinstance(qc, dict) else None
    if not isinstance(files, list) or not files:
        return None
    uris = [str(f) for f in files if f]
    if not uris or any(u.endswith("/") or not u.rsplit("/", 1)[-1].count(".") for u in uris):
        return None
    from core.measured_file_bytes import bytes_for_uris
    m = bytes_for_uris(uris)
    if m.files <= 0:
        return None
    return m.files, (m.known_bytes if m.known_files else 0), m.known_files


def _passport_island(db: Any, plan_hash: str, scope: Dict[str, Any]):
    """(files, bytes) from the last succeeded run's passport estimate IN THE
    CALLER'S SCOPE (the island depends on the predicates row security added),
    when it knew its island; else None."""
    try:
        from core.jobqueue.queue import JobQueue
        raw = JobQueue(db).latest_passport_for_plan(plan_hash, scoped=True, **scope)
        if not raw:
            return None
        from core.industrialization.passport import PassportConfidence, QueryPassport
        est = QueryPassport.from_json(raw).estimate
        if est is None or est.confidence == PassportConfidence.UNKNOWN or int(est.files or 0) <= 0:
            return None
        return int(est.files), int(est.bytes or 0)
    except Exception as exc:
        logger.debug("[query-pods] passport island unreadable: %s", exc)
        return None


def estimate_bytes(payload: Dict[str, Any], db: Any, plan_hash: str,
                   scope: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """A pre-run estimate, or None when nothing about the files is known.
    Returns ``{"bytes", "files", "known_files", "measured_bytes", "columns",
    "spill"}`` so the price can say what it was built from.  ``scope`` =
    whose history the passport island may come from (``rls_key``,
    ``rls_shareable``, ``username``; none = no passport history)."""
    from core.duckdb_resource_limits import min_memory_mb_for_width
    from core.resource_admission import estimate_query_resources

    n_cols = _columns_in_request(payload)
    width_mb = int(min_memory_mb_for_width(n_cols))
    spill = _sorts_or_groups(payload)
    if spill:
        width_mb *= 2

    island = _measured_files(payload)
    if island is not None:
        files, known_bytes, known_files = island
    else:
        pp = _passport_island(db, plan_hash, dict(scope or {}))
        if pp is None:
            return None
        files, known_bytes = pp
        known_files = files if known_bytes > 0 else 0

    cost = estimate_query_resources(
        file_count=files, n_workers=1, per_worker_mem_mb=width_mb,
        measured_bytes=known_bytes if known_files else None,
        measured_files=known_files or None,
    )
    return {"bytes": int(cost.estimate_total_mem_mb) * _budget.MB, "files": files,
            "known_files": known_files, "measured_bytes": known_bytes,
            "columns": n_cols, "spill": spill, "width_mb": width_mb}


# ── the price ───────────────────────────────────────────────────────────────

def price_for_request(request_payload: Dict[str, Any], db: Any, *,
                      settings: Optional[Settings] = None,
                      rls_key: str = "", rls_shareable: bool = False,
                      username: str = "") -> Price:
    """Price one run and pick its size.  ``Price.pod_class`` is None when no
    size holds it (``too_big``; ``reason`` is the sentence) or when no sizes
    are configured (``bytes`` 0, ``source`` ``""`` -- pricing is off).

    ``rls_key`` / ``rls_shareable`` / ``username`` are the run's calibration
    SCOPE (security review 2026-10-31): history is read from the same user's
    runs of the plan, and from other users' only under the same SHAREABLE
    rls_key (identical enforced SQL).  No scope = no history = an estimate.

    THE RATCHET IS BOUNDED: when the latest run in scope FAILED (DuckDB
    stopped it at its reservation), the next price is at most
    ``RATCHET_MAX_FACTOR`` x what that run was priced at; a later success's
    measured peak is the latest row again and pulls the price back down."""
    s = settings if settings is not None else _budget.settings_or_none()
    if s is None or not s.classes:
        return Price(bytes=0, source="", pod_class=None, reason="no query pod sizes configured")
    payload = dict(request_payload or {})
    from core.jobqueue.queue import JobQueue, compute_plan_hash
    plan_hash = compute_plan_hash(payload)
    scope = {"rls_key": str(rls_key or ""), "rls_shareable": bool(rls_shareable),
             "username": str(username or "")}

    margin = max(1.0, _budget.cfg_number("price_safety_margin", 1.3))
    min_price = int(_budget.cfg_number("min_price_mb", 256) * _budget.MB)
    detail: Dict[str, Any] = {"plan_hash": plan_hash[:12]}

    rec = None
    try:
        rec = JobQueue(db).latest_peak_record_for_plan(plan_hash, **scope)
    except Exception as exc:
        logger.debug("[query-pods] peak history unreadable (estimating): %s", exc)
    after_oom: Optional[int] = None
    if rec:
        peak = int(rec["peak_bytes"])
        priced = int(peak * margin)
        source = SOURCE_HISTORY
        detail.update({"peak_bytes": peak, "margin": margin, "last_status": rec["status"]})
        if rec["status"] == "failed" and int(rec["price_bytes"] or 0) > 0:
            # the out-of-memory ratchet: one failure raises the price by a
            # bounded step, never straight to a refusal on a wild sample
            cap = int(rec["price_bytes"] * RATCHET_MAX_FACTOR)
            after_oom = int(rec["reserved_bytes"] or rec["price_bytes"])
            if priced > cap:
                detail["ratchet_capped_from"] = priced
                priced = cap
            detail["ratchet_from_price"] = int(rec["price_bytes"])
    else:
        est = None
        try:
            est = estimate_bytes(payload, db, plan_hash, scope)
        except Exception as exc:
            logger.debug("[query-pods] estimate failed (class default): %s", exc)
        if est is not None:
            priced = int(est["bytes"])
            source = SOURCE_ESTIMATE
            detail.update(est)
        else:
            smallest = min(s.classes, key=lambda c: (c.memory_gi, c.name))
            configured = int(_budget.cfg_number("unknown_price_mb", 0) * _budget.MB)
            priced = configured if configured > 0 else _budget.class_budget_bytes(smallest)
            # a wide query is never priced below what its width needs
            try:
                from core.duckdb_resource_limits import min_memory_mb_for_width
                width = int(min_memory_mb_for_width(_columns_in_request(payload))) * _budget.MB
                if _sorts_or_groups(payload):
                    width *= 2
                priced = max(priced, width)
            except Exception:
                pass
            source = SOURCE_CLASS_DEFAULT
            detail.update({"default_of": smallest.name})

    priced = max(int(priced), min_price)
    cls = _budget.smallest_class_that_fits(priced, s)
    if cls is None:
        return Price(bytes=priced, source=source, pod_class=None,
                     reason=too_big_message(priced, s, after_oom_bytes=after_oom), detail=detail)
    return Price(bytes=priced, source=source, pod_class=cls.name, detail=detail)


__all__ = ["Price", "RATCHET_MAX_FACTOR", "SOURCE_CLASS_DEFAULT", "SOURCE_ESTIMATE",
           "SOURCE_HISTORY", "TooBigForQueryPods", "estimate_bytes", "price_for_request",
           "too_big_message"]
