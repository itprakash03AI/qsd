"""The query-pod sizes and their limits -- THE reader of ``query_pods``.

The query-pods chart renders its Deployments and KEDA ScaledObjects from the
same ``querystudio.query_pods`` block this module reads, so a size's warm
minimum, maximum and runs per pod are one set of numbers for both scalers.
A setting that cannot be used is refused with the reason (never guessed): a
scaler that guesses a maximum scales the wrong number of pods.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Tuple

SCALER_KEDA = "keda"
SCALER_BUILTIN = "builtin"
SCALERS = (SCALER_KEDA, SCALER_BUILTIN)

#: a size's name is part of a Deployment name: lower-case, short
_NAME_RE = re.compile(r"^[a-z][a-z0-9]{0,7}$")


class SettingsError(ValueError):
    """``query_pods`` cannot be used as written; the message says why."""


@dataclass(frozen=True)
class PodClass:
    name: str
    memory_gi: float
    min: int
    max: int
    runs_per_pod: int

    @property
    def label(self) -> str:
        return self.name.upper()


@dataclass(frozen=True)
class Settings:
    classes: Tuple[PodClass, ...]
    scaler: str
    deployment_prefix: str
    namespace: str
    tick_seconds: int
    cooldown_seconds: int
    wait_alert_seconds: int

    def deployment(self, cls: PodClass) -> str:
        return f"{self.deployment_prefix}{cls.name}"

    def by_name(self) -> Dict[str, PodClass]:
        return {c.name: c for c in self.classes}


def _int(spec: Mapping[str, Any], key: str, where: str, *, low: int) -> int:
    v = spec.get(key)
    if isinstance(v, bool) or not isinstance(v, (int, float)) or int(v) != v or int(v) < low:
        raise SettingsError(f"{where}.{key} must be a whole number of at least {low}, got {v!r}")
    return int(v)


def parse(raw: Mapping[str, Any]) -> Settings:
    raw = dict(raw or {})
    scaler = str(raw.get("scaler") or SCALER_KEDA).strip().lower()
    if scaler not in SCALERS:
        raise SettingsError(f"query_pods.scaler must be one of {', '.join(SCALERS)}, got {scaler!r}")
    specs = raw.get("classes") or {}
    if not isinstance(specs, Mapping):
        raise SettingsError(f"query_pods.classes must be a map of size name -> limits, got {type(specs).__name__}")
    classes = []
    for name in sorted(specs):
        where = f"query_pods.classes.{name}"
        if not _NAME_RE.match(str(name)):
            raise SettingsError(f"{where}: a size name is lower-case letters and digits, at most 8, "
                                f"starting with a letter (it is part of the Deployment name)")
        spec = specs[name] or {}
        if not isinstance(spec, Mapping):
            raise SettingsError(f"{where} must be a map (memory_gi, min, max, runs_per_pod)")
        mem = spec.get("memory_gi")
        if isinstance(mem, bool) or not isinstance(mem, (int, float)) or mem <= 0:
            raise SettingsError(f"{where}.memory_gi must be a number above 0, got {mem!r}")
        lo = _int(spec, "min", where, low=0)
        hi = _int(spec, "max", where, low=1)
        if hi < lo:
            raise SettingsError(f"{where}: max ({hi}) is below min ({lo})")
        per = _int(spec, "runs_per_pod", where, low=1)
        classes.append(PodClass(str(name), float(mem), lo, hi, per))
    prefix = str(raw.get("deployment_prefix") or "querystudio-query-pods-")
    return Settings(
        classes=tuple(classes), scaler=scaler, deployment_prefix=prefix,
        namespace=str(raw.get("namespace") or ""),
        tick_seconds=_int({"t": raw.get("tick_seconds", 60)}, "t", "query_pods.tick_seconds", low=5),
        cooldown_seconds=_int({"c": raw.get("cooldown_seconds", 600)}, "c", "query_pods.cooldown_seconds", low=0),
        wait_alert_seconds=_int({"w": raw.get("wait_alert_seconds", 120)}, "w",
                                "query_pods.wait_alert_seconds", low=1),
    )


def load_settings() -> Settings:
    from core.config import get_section
    return parse(get_section("query_pods") or {})


__all__ = ["PodClass", "SCALERS", "SCALER_BUILTIN", "SCALER_KEDA", "Settings", "SettingsError",
           "load_settings", "parse"]
