"""THE rule for which login a connection uses when it names a System Account
(2026-10-29).

A login is a PAIR: the name and the secret that belongs to it.  Every road
that fills a connection's credentials from a System Account (a SQL connector,
the Spark lane, an Oracle destination, SFTP delivery) asks this one function,
so they cannot disagree.

The rule (2026-10-30: the ACCOUNT comes first):

  1. the ACCOUNT's secret, when it has one, is the login, with the ACCOUNT's
     name -- a name typed beside it is NOT kept (the owner's UAT Trino sent a
     typed username with the Vault password and was refused, HTTP 401), and a
     secret on the connection is NOT used: the owner, 2026-10-30, "its taking
     old password ... my password ... not from vault password" -- a password
     saved on the connection BEFORE a System Account was chosen stays stored
     behind "***" and is indistinguishable from one typed on purpose, so a
     rule that let it win sent the person's own password instead of Vault's;
  2. an account secret with no account name takes the typed name (a Vault
     entry that holds only a key or a password for a named user);
  3. an account with NO secret: the secret typed on the connection, with the
     typed name (or the account's);
  4. no secret anywhere: the name alone (a connection whose auth needs none).

The answer says where each half came from, for a log line or a receipt --
never the secret itself.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Login:
    user: str
    secret: str
    user_from: str      # "typed" | "account" | "none"
    secret_from: str    # "typed" | "account" | "none"

    def describe(self) -> str:
        return f"user from {self.user_from}, secret from {self.secret_from}"


def pair_login(typed_user: Optional[str], typed_secret: Optional[str],
               account_user: Optional[str], account_secret: Optional[str]) -> Login:
    tu = (typed_user or "").strip()
    au = (account_user or "").strip()
    ts = typed_secret or ""
    acs = account_secret or ""
    if acs:
        return Login(au or tu, acs, "account" if au else ("typed" if tu else "none"), "account")
    if ts:
        return Login(tu or au, ts, "typed" if tu else ("account" if au else "none"), "typed")
    return Login(tu or au, "", "typed" if tu else ("account" if au else "none"), "none")


__all__ = ["Login", "pair_login"]
