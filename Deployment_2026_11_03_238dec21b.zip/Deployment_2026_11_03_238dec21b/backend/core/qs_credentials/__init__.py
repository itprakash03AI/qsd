"""qs_credentials -- QS API's single entry point for vault-backed creds.

Public API (call sites only need this import line)::

    from core.qs_credentials import resolve_system_account

Layout:
  resolver.py      -- QS API facade (DB-driven; public functions here)
  cache.py         -- QSCredCache (byte-identical with ETL copy)
  vault/           -- HashiCorp Vault HTTP client (byte-identical)
"""
from __future__ import annotations

from .resolver import (
    # Resolve a SystemAccount row to its runtime credentials.
    resolve_system_account,
    fill_creds_from_system_account,

    # Auth-failure recovery + manual cache invalidation.
    refresh,
    resolve_with_auth_retry,
    invalidate,
    reset_cache,
    disk_cache_clear,

    # Three-layer enable toggle.
    is_vault_enabled,
)

# 2026-10-30 -- credential FRESHNESS across pods and after an auth failure
# (one chokepoint: forget / observe / with_fresh_credentials / is_auth_failure).
from . import freshness

# Re-export shared classes for advanced callers / tests.
from .cache import QSCredCache
from .vault import (
    QSClient,
    QSMachineToken,
    QSVaultToken,
    QSReadSecrets,
    fetch_secret,
    fetch_secret_with_vendor_fallback,  # back-compat alias of fetch_secret
    is_valid_vault_payload,
    resolve_secret,
)

__all__ = [
    "resolve_system_account",
    "fill_creds_from_system_account",
    "refresh",
    "resolve_with_auth_retry",
    "invalidate",
    "reset_cache",
    "disk_cache_clear",
    "is_vault_enabled",
    "freshness",
    "QSCredCache",
    "QSClient",
    "QSMachineToken",
    "QSVaultToken",
    "QSReadSecrets",
    "fetch_secret",
    "fetch_secret_with_vendor_fallback",
    "is_valid_vault_payload",
    "resolve_secret",
]
