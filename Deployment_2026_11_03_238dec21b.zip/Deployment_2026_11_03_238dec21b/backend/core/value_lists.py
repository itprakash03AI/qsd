"""Value lists -- a NAMED list of choices synced into OUR database (2026-10-24).

The owner: "why can't we create a table and get possible parameter values
saved in our db ... a sync-up option rather than calling at run time ...
some list with key value json"; "prod can get from prod queries".

A value list (``value_lists``) is a DEFINITION -- a query on a connection
naming a KEY column (what a choice filters by) and an optional LABEL column
(what a person reads), or a static list -- plus its VALUES
(``value_list_items``), synced into the metadata database.  Any report
parameter can offer it (``values_source = list``); one list serves every
report that names it.

* :func:`sync` runs the query on the list's connection through the engine's
  one execution road (S3 via DuckDB, SQL sources on their connector) and
  replaces the values in ONE transaction: added / changed / removed counted,
  ``values_version`` moved.  A failure changes NOTHING but the status: the
  previous values stay and are served, said stale (``last_status=failed``).
  A release carries the definition, never the values -- each environment
  syncs its own from its own connection.
* :func:`serve` answers "what may THIS viewer choose".  A stored list is a
  snapshot of EVERYTHING, so it is never served wider than the viewer could
  query:
    - an admin (who bypasses row security) gets the stored values;
    - when a source table of the list's query carries a row policy, or an
      entitlement dimension through a column OTHER than the key, the stored
      snapshot cannot be filtered faithfully: the list is served LIVE -- its
      query run under the viewer's row security, cached per viewer
      (core/column_value_cache.py);
    - a source table whose columns are unknown is served live too (live is
      always right, only slower);
    - otherwise the stored values, filtered by the viewer's data entitlement
      on the KEY column by NAME (generic, like every query).
"""
from __future__ import annotations

import logging
import threading
import time
import uuid
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

SOURCE_TYPES = ("query", "static")
SYNC_MODES = ("manual", "daily")
#: a list over the cap is NOT kept (status ``too_big``); the dropdown searches the source as you type
STATUS_TOO_BIG = "too_big"


def max_items() -> int:
    """THE cap on a stored list (2026-11-02; ``value_lists.max_items``, declared
    50,000).  A list is a list of CHOICES; a column with more distinct values
    (a book, a trade id, a counterparty) is a table, and the dropdown searches
    it live.  The cap is pushed INTO the source query (``capped_sql``), so the
    source never ships the excess and the fill never holds millions of rows."""
    from core.config import get
    try:
        v = int(get("value_lists", "max_items", 50000) or 50000)
    except (TypeError, ValueError):
        v = 50000
    return max(100, v)


#: kept for readers of the old name; the cap is :func:`max_items`
MAX_VALUES = 50_000


def too_big_words(cap: int) -> str:
    return (f"This list has more than {cap:,} values, so it is not kept; the dropdown "
            f"searches the source as you type")


def retry_backoff_max_seconds() -> int:
    """A failed list is retried with a DOUBLING wait (5 min, 10, 20, ...), capped
    here (``value_lists.retry_backoff_max_seconds``, declared 6 h) -- not every
    tick for ever."""
    from core.config import get
    try:
        return max(300, int(get("value_lists", "retry_backoff_max_seconds", 21600) or 21600))
    except (TypeError, ValueError):
        return 21600


BACKOFF_BASE_SECONDS = 300


def backoff_seconds(failures: int) -> int:
    """How long after the Nth consecutive failure the next try waits."""
    n = max(1, int(failures or 1))
    return int(min(BACKOFF_BASE_SECONDS * (2 ** (n - 1)), retry_backoff_max_seconds()))


def capped_sql(sql: str, dialect: Optional[str], cap: int) -> str:
    """The list's query wrapped so the source returns at most ``cap + 1`` rows
    (one more than the cap: the fill then KNOWS the list is too big without
    counting the rest).  ``LIMIT`` everywhere the engine runs it (DuckDB, Trino /
    Starburst, Snowflake, PostgreSQL, Databricks, Athena); Oracle takes
    ``FETCH FIRST n ROWS ONLY``."""
    inner = (sql or "").strip().rstrip(";")
    n = int(cap) + 1
    if (dialect or "").lower() == "oracle":
        return f"SELECT * FROM ({inner}) qs_vl FETCH FIRST {n} ROWS ONLY"
    return f"SELECT * FROM ({inner}) AS qs_vl LIMIT {n}"


def live_search_sql(sql: str, dialect: Optional[str], key_column: str, label_column: Optional[str],
                    search: Optional[str], limit: int) -> Tuple[str, Dict[str, Any]]:
    """A TOO-BIG list is searched at the source as the person types: the text
    is matched on the key (and the label) INSIDE the query, and only
    ``limit + 1`` rows come back.  Returns ``(sql, params)``; the pattern is a
    bound parameter, never spliced."""
    inner = (sql or "").strip().rstrip(";")
    q = (search or "").strip().lower()
    where = ""
    params: Dict[str, Any] = {}
    if q:
        cols = [key_column] + ([label_column] if label_column else [])
        preds = " OR ".join(f"LOWER(CAST({_ident(c)} AS VARCHAR)) LIKE :qs_vl_q" for c in cols)
        where = f" WHERE {preds}"
        params["qs_vl_q"] = f"%{q.replace('%', '%%')}%"
    n = int(limit) + 1
    if (dialect or "").lower() == "oracle":
        return f"SELECT * FROM ({inner}) qs_vl{where} FETCH FIRST {n} ROWS ONLY", params
    return f"SELECT * FROM ({inner}) AS qs_vl{where} LIMIT {n}", params


def _ident(name: str) -> str:
    """A column name as the query returned it, quoted when it needs quoting."""
    n = str(name or "").strip().strip('"')
    if n.replace("_", "").isalnum() and not n[:1].isdigit():
        return n
    return '"' + n.replace('"', '""') + '"'


class ValueListError(ValueError):
    """A definition or a sync a person can fix -- the message says how."""


class ValueListTooBig(ValueListError):
    """The source returned more than the cap: the list is not kept."""


# ── definitions ─────────────────────────────────────────────────────────────

def problems(d: Dict[str, Any], *, creating: bool) -> List[str]:
    """Every reason a definition cannot be saved (ONE 422)."""
    out: List[str] = []
    if creating or "name" in d:
        if not str(d.get("name") or "").strip():
            out.append("name is required")
    st = d.get("source_type", "query" if creating else None)
    if st is not None and st not in SOURCE_TYPES:
        out.append(f"source_type must be one of {', '.join(SOURCE_TYPES)}")
    if st == "query":
        if not d.get("connection_id"):
            out.append("a query list needs a connection")
        if not str(d.get("source_sql") or "").strip():
            out.append("a query list needs its query")
        if not str(d.get("key_column") or "").strip():
            out.append("name the KEY column -- the value a choice filters by")
    sm = d.get("sync_mode")
    if sm is not None and sm not in SYNC_MODES:
        out.append(f"sync_mode must be one of {', '.join(SYNC_MODES)}")
    if sm == "daily" and d.get("sync_every_hours") is not None:
        try:
            if int(d["sync_every_hours"]) < 1:
                out.append("sync_every_hours must be at least 1")
        except (TypeError, ValueError):
            out.append("sync_every_hours must be a whole number of hours")
    return out


# ── sync ────────────────────────────────────────────────────────────────────

def _fed(db):
    from core.federation_engine import FederationEngine
    return FederationEngine(db)


def _dialect_of(db, conn: Dict[str, Any]) -> str:
    from core.sql_filter_wrapper import dialect_for_connection_type
    return dialect_for_connection_type(conn.get("connection_type") or conn.get("type")) or "duckdb"


def run_query(db, connection_id: int, sql: str, user_ctx: Optional[Dict[str, Any]] = None,
              fed=None, *, cap: Optional[int] = None) -> Tuple[List[str], List[Dict[str, Any]]]:
    """The list's query on its connection: ``(columns, rows)``.  ``user_ctx``
    given = run under that viewer's row security (the LIVE read); None = the
    SYNC (a snapshot of everything, filtered when served).  ``cap`` (2026-11-02):
    the source returns at most ``cap + 1`` rows (``capped_sql``) -- the fill
    never ships, holds or scans the excess of a high-cardinality column."""
    fed = fed or _fed(db)
    conn = db.get_connection_raw(int(connection_id))
    if not conn:
        raise ValueListError(f"connection {connection_id} does not exist")
    connections = {int(connection_id): conn}
    run_sql = sql
    if user_ctx is not None:
        run_sql = fed._apply_rls_all_connections(sql, connections, user_ctx, label="value list")
    if cap is not None:
        run_sql = capped_sql(run_sql, _dialect_of(db, conn), int(cap))
    views = None
    if fed._get_connection_type(conn) == "s3":
        views = fed._registered_table_views_for_sql(run_sql, connections, [], base_query=run_sql) or None
    df = fed._execute_query(sql=run_sql, connections=connections, source_tables=[],
                            execution_id=str(uuid.uuid4()), table_views=views)
    return [str(c) for c in df.columns], df.to_dict(orient="records")


def run_live_search(db, vl: Dict[str, Any], user_ctx: Optional[Dict[str, Any]], search: Optional[str],
                    limit: int, fed=None) -> Tuple[List[str], List[Dict[str, Any]]]:
    """A TOO-BIG list, searched at the source: the viewer's row security, the
    typed text pushed into the query, ``limit + 1`` rows at most."""
    fed = fed or _fed(db)
    conn = db.get_connection_raw(int(vl["connection_id"]))
    if not conn:
        raise ValueListError(f"connection {vl['connection_id']} does not exist")
    connections = {int(vl["connection_id"]): conn}
    run_sql = vl["source_sql"]
    if user_ctx is not None:
        run_sql = fed._apply_rls_all_connections(run_sql, connections, user_ctx, label="value list")
    run_sql, params = live_search_sql(run_sql, _dialect_of(db, conn), vl["key_column"], vl.get("label_column"),
                                      search, int(limit))
    if params:
        # the engine's road takes SQL text: the ONE pattern is a plain string
        # literal, quotes doubled (it came from the person's search box)
        pat = str(params["qs_vl_q"]).replace("'", "''")
        run_sql = run_sql.replace(":qs_vl_q", f"'{pat}'")
    views = None
    if fed._get_connection_type(conn) == "s3":
        views = fed._registered_table_views_for_sql(run_sql, connections, [], base_query=run_sql) or None
    df = fed._execute_query(sql=run_sql, connections=connections, source_tables=[],
                            execution_id=str(uuid.uuid4()), table_views=views)
    return [str(c) for c in df.columns], df.to_dict(orient="records")


def _find(cols: List[str], name: Optional[str]) -> Optional[str]:
    if not name:
        return None
    want = str(name).strip().strip('"').lower()
    return next((c for c in cols if c.lower() == want), None)


def items_from_rows(cols: List[str], rows: List[Dict[str, Any]], key_column: str,
                    label_column: Optional[str], parent_column: Optional[str] = None) -> List[Dict[str, Any]]:
    """Rows -> items: key / label / sort_order / attrs; first key wins, an
    empty key is skipped.  Names the missing column (never an empty list).
    ``parent_column`` (2026-11-01, a cascade child's list): a key seen under
    several parents keeps EVERY parent in ``attrs.parents`` (sorted), so the
    narrowing is answered from the stored list."""
    kc = _find(cols, key_column)
    if kc is None:
        raise ValueListError(f"the query returns no column {key_column!r} (it returns: {', '.join(cols)})")
    lc = _find(cols, label_column) if label_column else None
    if label_column and lc is None:
        raise ValueListError(f"the query returns no column {label_column!r} (it returns: {', '.join(cols)})")
    pc = _find(cols, parent_column) if parent_column else None
    if parent_column and pc is None:
        raise ValueListError(f"the query returns no column {parent_column!r} (it returns: {', '.join(cols)})")
    seen, out = {}, []
    parents: Dict[str, set] = {}        # 2026-11-02: collected as SETS, sorted ONCE below (linear, not quadratic)
    for r in rows:
        k = r.get(kc)
        if k is None or (isinstance(k, float) and k != k):
            continue
        k = _text(k)
        if k == "":
            continue
        if k in seen:
            if pc is not None and r.get(pc) is not None:
                parents[k].add(_text(r.get(pc)))
            continue
        label = _text(r.get(lc)) if lc else None
        attrs = {c: _jsonable(v) for c, v in r.items() if c not in (kc, lc, pc)} or None
        if pc is not None:
            parents[k] = {_text(r.get(pc))} if r.get(pc) is not None else set()
            attrs = dict(attrs or {})
        item = {"key": k, "label": label, "sort_order": len(out), "attrs": attrs}
        seen[k] = item
        out.append(item)
    if pc is not None:
        for k, item in seen.items():
            item["attrs"]["parents"] = sorted(parents.get(k, ()))
    cap = max_items()
    if len(out) > cap:
        raise ValueListTooBig(too_big_words(cap))
    return out


def _ordered(vl: Dict[str, Any], items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """No ORDER BY in the list's query = no order: a DISTINCT comes back in
    any order, so the list is kept in KEY order (and a re-sync of the same
    rows changes nothing); with an ORDER BY the query's order is the list's."""
    if "order by" not in (vl.get("source_sql") or "").lower():
        items = sorted(items, key=lambda i: i["key"])
        for n, it in enumerate(items):
            it["sort_order"] = n
    return items


def _text(v: Any) -> str:
    # THE engine's rule for a date a filter can use (the S3 road hands a DATE
    # back as a midnight Timestamp): midnight -> YYYY-MM-DD, else
    # YYYY-MM-DD HH:MM:SS -- the same key on every road (rig 2026-10-24).
    if isinstance(v, (datetime, date)):
        from core.federation_engine import _lov_temporal_value
        return _lov_temporal_value(v)
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def _jsonable(v: Any) -> Any:
    if v is None or isinstance(v, (str, int, bool)):
        return v
    if isinstance(v, float):
        return None if v != v else v
    return _text(v)


#: one lock per list in THIS process (rig 2026-11-01): the save's background build and
#: the author's Refresh now ran the same list's sync at once and one died on the unique
#: key.  Across pods the list's row is locked in replace_value_list_items.
_SYNC_LOCKS: Dict[int, threading.Lock] = {}
_SYNC_LOCKS_GUARD = threading.Lock()
REFRESHING_WORDS = "This list is being refreshed right now -- it will be ready in a moment."
RACED_WORDS = ("Another refresh of this list wrote its values at the same moment; those values are kept. "
               "Press Refresh now again if the list looks old.")


def _lock_for(list_id: int) -> threading.Lock:
    with _SYNC_LOCKS_GUARD:
        return _SYNC_LOCKS.setdefault(int(list_id), threading.Lock())


def in_flight(list_id: int) -> bool:
    """Is a sync of this list running in this process right now?"""
    return _lock_for(list_id).locked()


def sync(db, list_id: int, *, by: str = "", fed=None) -> Dict[str, Any]:
    """Sync one query list now.  Returns the stored list's status (with the
    summary).  A failure records the reason and keeps the previous values.

    Syncs of ONE list are SERIALIZED (``_lock_for``): a second caller waits,
    and when the first one finished meanwhile (the version moved) it answers
    with that fresh status instead of running the query again.  A write that
    still collides (another pod, no row lock on the engine) is recorded as
    the list's failure in words, never raised."""
    vl = db.get_value_list(int(list_id))
    if vl is None:
        raise ValueListError(f"value list {list_id} does not exist")
    if vl["source_type"] not in ("partition", "query"):
        raise ValueListError("a static list is edited, not synced")
    with _lock_for(list_id):
        now = db.get_value_list(int(list_id)) or vl
        if now.get("last_status") == "ok" and (now.get("values_version"), str(now.get("last_synced_at"))) != \
                (vl.get("values_version"), str(vl.get("last_synced_at"))):
            logger.info("[value-lists] %r was refreshed while this sync waited; its values are kept", vl["name"])
            return now
        if now["source_type"] == "partition":
            # 2026-11-01 -- a parameter's list over a PARTITION column: the recorded
            # partition values, no data scan (core/reports/param_lists.py)
            from core.reports.param_lists import sync_partition
            return sync_partition(db, now, by=by)
        t0 = time.monotonic()
        cap = max_items()
        try:
            # the cap travels INTO the query: at most cap + 1 rows come back
            cols, rows = run_query(db, now["connection_id"], now["source_sql"], None, fed=fed, cap=cap)
            if len(rows) > cap:
                raise ValueListTooBig(too_big_words(cap))
            items = _ordered(now, items_from_rows(cols, rows, now["key_column"], now.get("label_column"),
                                                  now.get("parent_column")))
        except ValueListTooBig as exc:
            # NOT stored as if complete: the status says so in words and the
            # dropdown searches the source as the person types (serve -> live)
            logger.info("[value-lists] %r is over the cap (%s) -- not kept, searched live", now["name"], cap)
            return db.record_value_list_too_big(int(list_id), str(exc), by=by, cap=cap)
        except Exception as exc:                                  # noqa: BLE001
            msg = str(exc) if isinstance(exc, ValueListError) else f"{type(exc).__name__}: {exc}"
            logger.warning("[value-lists] sync of %r failed: %s", now["name"], msg)
            failures = int(((now.get("last_sync_summary") or {}).get("failures") or 0)) + 1 \
                if now.get("last_status") == "failed" else 1
            wait = backoff_seconds(failures)
            retry_after = datetime.now(timezone.utc) + timedelta(seconds=wait)
            return db.record_value_list_failure(
                int(list_id), msg[:2000], by=by,
                extra={"failures": failures, "retry_after": retry_after.isoformat(),
                       "retry_wait_seconds": wait})
        try:
            summary = db.replace_value_list_items(int(list_id), items, by=by,
                                                  seconds=round(time.monotonic() - t0, 3))
        except Exception as exc:                                  # noqa: BLE001 -- a collision is the list's status, not a 500
            logger.warning("[value-lists] the values of %r were not written: %s", now["name"], exc)
            return db.record_value_list_failure(int(list_id), RACED_WORDS, by=by)
    try:
        from core import column_value_cache
        column_value_cache.clear()      # a list a viewer was served live may have moved too
    except Exception:                   # noqa: BLE001
        pass
    return summary


def _retry_after(vl: Dict[str, Any]) -> Optional[datetime]:
    raw = (vl.get("last_sync_summary") or {}).get("retry_after") if isinstance(vl.get("last_sync_summary"), dict) else None
    if not raw:
        return None
    try:
        ts = datetime.fromisoformat(str(raw))
    except ValueError:
        return None
    return ts if ts.tzinfo else ts.replace(tzinfo=timezone.utc)


def due(lists: List[Dict[str, Any]], now: Optional[datetime] = None) -> List[Dict[str, Any]]:
    """The daily lists whose last sync is older than their interval (24 h by
    default), or that never synced / last FAILED.  A failed list waits its
    BACKOFF (``last_sync_summary.retry_after``, doubling from 5 min, capped at
    ``value_lists.retry_backoff_max_seconds``) -- not every tick for ever.  A
    ``too_big`` list is retried on its own interval like an ok one (the source
    may have shrunk; one capped query a day is cheap)."""
    now = now or datetime.now(timezone.utc)
    out = []
    for vl in lists:
        if vl.get("source_type") not in ("query", "partition") or vl.get("sync_mode") != "daily":
            continue
        every = max(1, int(vl.get("sync_every_hours") or 24))
        last = vl.get("last_synced_at")
        if vl.get("last_status") == "failed":
            ra = _retry_after(vl)
            if ra is None or now >= ra:
                out.append(vl)
            continue
        if vl.get("last_status") == "never" or not last:
            out.append(vl)
            continue
        ts = datetime.fromisoformat(last) if isinstance(last, str) else last
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        if (now - ts).total_seconds() >= every * 3600:
            out.append(vl)
    return out


def tick(db) -> Dict[str, Any]:
    """The job-worker's pass: sync every due daily list (one at a time)."""
    done, failed, too_big = 0, 0, 0
    for vl in due(db.list_value_lists(include_parameter_lists=True)):
        out = sync(db, vl["id"], by="value_list_sync")
        if out.get("last_status") == "ok":
            done += 1
        elif out.get("last_status") == STATUS_TOO_BIG:
            too_big += 1
        else:
            failed += 1
    return {"synced": done, "failed": failed, "too_big": too_big}


# ── serve ───────────────────────────────────────────────────────────────────

def _is_admin(user: Optional[Dict[str, Any]]) -> bool:
    from core.roles import is_admin_like
    return is_admin_like(user)


def source_tables(sql: str, dialect: str) -> Optional[List[str]]:
    """The base tables the list's query reads (the rewriter's own walk);
    None when the query does not parse."""
    try:
        import sqlglot
        from sqlglot import exp
        from core.row_security.rewriter import _resolved_table_ref, is_cte_reference
        tree = sqlglot.parse_one(sql, read=dialect or None)
    except Exception:                                         # noqa: BLE001
        return None
    refs: List[str] = []
    for t in tree.find_all(exp.Table):
        if isinstance(t.parent, exp.CTE) or is_cte_reference(t):
            continue
        r = _resolved_table_ref(t)
        if r and r not in refs:
            refs.append(r)
    return refs


def needs_live(db, vl: Dict[str, Any]) -> Optional[str]:
    """Why the stored snapshot cannot be served filtered (-> serve live), or
    None.  Unknown = live."""
    if vl.get("last_status") == STATUS_TOO_BIG:
        # 2026-11-02: nothing is stored; the dropdown searches the source
        return too_big_words(int(((vl.get("last_sync_summary") or {}).get("cap") or max_items())))
    if vl.get("source_type") == "partition":
        # a partition list names every value of the table: served only when no
        # row policy / dimension can apply (the metadata rule, core/reports/param_values.py)
        try:
            from core.row_security import cache_scope
            if not cache_scope.shared_slot_is_safe(db):
                return "the table's partitions list every value, and row security applies to this data"
        except Exception as exc:                              # noqa: BLE001
            return f"row security could not be checked ({type(exc).__name__})"
        return None
    if vl.get("source_type") != "query":
        return None
    conn = db.get_connection(int(vl["connection_id"])) or {}
    from core.sql_filter_wrapper import dialect_for_connection_type
    dialect = dialect_for_connection_type(conn.get("connection_type")) or "duckdb"
    tables = source_tables(vl.get("source_sql") or "", dialect)
    if tables is None:
        return "the list's query does not parse here"
    try:
        from core.row_security import api as rs_api
        from core.row_security import entitlement as ent
        resolver = rs_api._resolver
        dims = ent.active_dimensions(db) if ent.enabled() else []
        key = str(vl.get("key_column") or "").strip('"').lower()
        for t in tables:
            if resolver is not None and resolver.table_has_any_policy(int(vl["connection_id"]), t):
                return f"{t} carries a row policy"
            if not dims:
                continue
            cols = ent.table_columns(db, int(vl["connection_id"]), t)
            if cols is None:
                return f"the columns of {t} are not known"
            lower = {c.lower() for c in cols}
            for d in dims:
                for c in d["columns"]:
                    cn = str(c["column_name"]).lower()
                    if cn in lower and cn != key and (c.get("connection_id") in (None, vl["connection_id"])):
                        return f"{t} is entitled by {c['column_name']} (not the key)"
    except Exception as exc:                                  # noqa: BLE001
        return f"row security could not be checked ({type(exc).__name__})"
    return None


def entitled_keys(db, vl: Dict[str, Any], user: Dict[str, Any]) -> Optional[set]:
    """The keys THIS viewer may choose under the data entitlement of the KEY
    column (by name); None = no dimension names it (no filter)."""
    from core.row_security import entitlement as ent
    from core.row_security.api import build_user_ctx
    if not ent.enabled():
        return None
    key = str(vl.get("key_column") or "").strip('"').lower()
    dims = [d for d in ent.active_dimensions(db)
            if any(str(c["column_name"]).lower() == key
                   and c.get("connection_id") in (None, vl.get("connection_id")) for c in d["columns"])]
    if not dims:
        return None
    ctx = build_user_ctx(user)
    scope = ent.scope_of(ctx)
    principals = ent.principals_of(ctx, db, scope)
    rows = db.values_for_principals([d["id"] for d in dims], principals)
    today = datetime.now(timezone.utc).date()
    allowed: Optional[set] = None
    for d in dims:
        mine = [r for r in rows if int(r["dimension_id"]) == int(d["id"]) and ent._valid_today(r, today)]
        if any(r.get("is_all") for r in mine):
            continue                                     # every value of this one
        vals = {str(r["value"]) for r in mine if r.get("value") is not None}
        if not vals and d.get("no_value_behaviour") == ent.SEE_EVERYTHING:
            continue
        allowed = vals if allowed is None else (allowed & vals)
    return allowed if allowed is not None else None


def serve(db, list_id: int, user: Optional[Dict[str, Any]], *, search: Optional[str] = None,
          limit: int = 500, with_attrs: bool = False, newest_first: bool = False) -> Dict[str, Any]:
    """What THIS viewer may choose from the list: ``{values: [{key, label}],
    truncated, source: list | list-live, synced_at, status, stale}``."""
    vl = db.get_value_list(int(list_id))
    if vl is None:
        raise ValueListError(f"value list {list_id} does not exist")
    meta = {"list": vl["name"], "synced_at": vl.get("last_synced_at"),
            "status": vl.get("last_status"), "stale": vl.get("last_status") == "failed",
            "values_version": vl.get("values_version")}
    q = (search or "").strip().lower() or None
    if vl.get("last_status") == STATUS_TOO_BIG:
        # 2026-11-02: an admin too -- nothing is stored for a too-big list
        return {**meta, **_live_search(db, vl, user, q, limit),
                "source": "list-live", "live_reason": needs_live(db, vl)}
    if not _is_admin(user):
        why = needs_live(db, vl)
        if why:
            return {**meta, **_live(db, vl, user, q, limit, newest_first=newest_first),
                    "source": "list-live", "live_reason": why}
    allowed = None if _is_admin(user) else entitled_keys(db, vl, user or {})
    items = db.list_value_list_items(int(list_id), search=q, keys=allowed, limit=limit + 1, with_attrs=with_attrs,
                                     newest_first=newest_first)
    return {**meta, "values": items[:limit], "truncated": len(items) > limit, "source": "list"}


def latest_key(db, vl: Dict[str, Any], user: Optional[Dict[str, Any]], *, by_order: bool = False) -> Optional[str]:
    """The newest key THIS viewer may choose (the 'latest with data' default,
    core/reports/param_defaults.py): under exactly ``serve``'s rule -- the live
    road when the snapshot cannot be served filtered, else the stored keys
    under the viewer's entitlement -- as ONE database MAX (``by_order``: the
    last key in list order instead, for a text list).  None = nothing."""
    if vl.get("last_status") == STATUS_TOO_BIG:
        return None                     # nothing stored; no honest "latest" without a full read
    if not _is_admin(user):
        why = needs_live(db, vl)
        if why:
            keys = [i["key"] for i in _live(db, vl, user, None, max_items())["values"] if i.get("key") not in (None, "")]
            if not keys:
                return None
            return keys[-1] if by_order else max(keys)
    allowed = None if _is_admin(user) else entitled_keys(db, vl, user or {})
    if allowed is not None and not allowed:
        return None
    return db.latest_value_list_key(int(vl["id"]), keys=allowed, by_order=by_order)


def latest_keys(db, vl: Dict[str, Any], user: Optional[Dict[str, Any]], n: int) -> List[str]:
    """The ``n`` newest keys THIS viewer may choose, newest first -- ``latest_key``'s
    rule (the live road when the snapshot cannot be served filtered, else the stored
    keys under the viewer's entitlement) for more than one key (2026-11-02)."""
    if vl.get("last_status") == STATUS_TOO_BIG:
        return []
    if not _is_admin(user):
        why = needs_live(db, vl)
        if why:
            keys = {i["key"] for i in _live(db, vl, user, None, max_items())["values"] if i.get("key") not in (None, "")}
            return sorted(keys, reverse=True)[:n]
    allowed = None if _is_admin(user) else entitled_keys(db, vl, user or {})
    if allowed is not None and not allowed:
        return []
    return db.newest_value_list_keys(int(vl["id"]), n, keys=allowed)


def _live_search(db, vl, user, q, limit) -> Dict[str, Any]:
    """A TOO-BIG list: the typed text and the limit go INTO the source query
    under the viewer's row security (an admin: none); ``limit + 1`` rows at
    most come back, so a million-row column costs one bounded query."""
    ctx = None if _is_admin(user) else (user or {})
    cols, rows = run_live_search(db, vl, ctx, q, limit)
    items = items_from_rows(cols, rows[:limit + 1], vl["key_column"], vl.get("label_column"))
    return {"values": [{"key": i["key"], "label": i.get("label")} for i in items[:limit]],
            "truncated": len(items) > limit}


def _live(db, vl, user, q, limit, newest_first: bool = False) -> Dict[str, Any]:
    """The list's query under the viewer's row security, cached per viewer."""
    from core import column_value_cache as cvc
    k = cvc.key(vl["connection_id"], f"value_list:{vl['id']}", vl.get("key_column") or "",
                scope=cvc.scope_for(user or {}), qualifier=f"v{vl.get('values_version')}")
    items = cvc.get(k, 0)
    if items is None:
        cols, rows = run_query(db, vl["connection_id"], vl["source_sql"], user or {})
        items = _ordered(vl, items_from_rows(cols, rows, vl["key_column"], vl.get("label_column")))
        cvc.put(k, items, 0)
    if q:
        items = [i for i in items if q in i["key"].lower() or q in str(i.get("label") or "").lower()]
    if newest_first:
        items = list(reversed(items))
    return {"values": [{"key": i["key"], "label": i.get("label")} for i in items[:limit]],
            "truncated": len(items) > limit}
