"""Insights over a report's ONE stored result (2026-10-30, the owner: "even
Power BI report show insights").

Every function here reads the run's STORED, row-secured result through the
microcube's own building blocks (``core/reports/microcube.py``: the same
DuckDB connection posture, the same artifact reader incl. a finished parts
result, the same identifier gate, the same aggregate expressions and the same
grain rule).  Nothing here ever sends a query to the source.

Primitives (physical column names; the canvas layer in
``core/reports/canvas_insights.py`` maps tile column ids onto them and words
the answer):

* :func:`member_changes` -- the members of a grouping, each with its value
  at A and at B and its change B - A, ranked by the size of the change
  (largest first, ties by the member's own value).  A and B are two values
  of a column of the result (``compare``), or two stored results
  (``path_b``: the current run, ``path_a``: an earlier one).  The top N are
  listed and the rest are ONE row, "Everything else", so the list ALWAYS adds
  up to the total change.  For a DECIMAL / integer measure that is exact
  arithmetic end to end (DuckDB adds DECIMAL as DECIMAL; Python adds the
  parts as ``Decimal``); for a floating-point measure the parts are stated as
  ``Decimal`` of the stored double and the rest is the difference, so the
  list still adds up to the total shown, and the answer says it is not exact.
* :func:`split_total` -- one level of a decomposition: the members of one
  column under a path, biggest first (by size, so a large loss ranks with a
  large gain), each with its share of the level's total, the rest as
  "Everything else".
* :func:`series_points` + :func:`flag_anomalies` -- a measure over an ordered
  column and the robust rule below.

The grain rule (the canvas's): a change can only be split into parts when the
value is ADDED UP -- Sum, or Count over detail rows.  Over grouped rows a
count or an average would already be a wrong number (the microcube refuses
it by name), and a smallest / largest / average / count of different values
does not split into parts that add up to the whole, so those are refused here
by name too (:class:`InsightRefused`).

THE ANOMALY RULE (said in words on the tile, ``anomaly_rule_words``): each
point is judged against the ``window`` points before it.  Their middle value
(the median, m) and their typical spread (s = 1.4826 x the median of each
point's distance from m -- the "MAD", scaled so that for normally spread data
it equals the standard deviation) give the usual range m - k*s .. m + k*s
(k = ``threshold``, 3 unless the tile says).  A point outside that range is
flagged, above or below.  A point with fewer than ``window`` points before it
is not judged; a series with no more than ``window`` points has no flags at
all.  When the earlier points are all equal (s = 0) the usual range is that
one value, so any different value is flagged -- and the words say so.
Everything is ``Decimal``: the same series always gives the same flags.
"""
from __future__ import annotations

import logging
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from core.reports import microcube as mc
from core.reports.pagination import _quote_ident

logger = logging.getLogger(__name__)

__all__ = [
    "ADDITIVE_WORDS",
    "DEFAULT_THRESHOLD",
    "DEFAULT_TOP_N",
    "DEFAULT_WINDOW",
    "InsightRefused",
    "MAD_SCALE",
    "MAX_SERIES_POINTS",
    "anomaly_rule_words",
    "compare_values",
    "flag_anomalies",
    "member_changes",
    "percent",
    "require_additive",
    "series_points",
    "split_total",
]

#: members listed before "Everything else" when a tile does not say
DEFAULT_TOP_N = 10
#: earlier points each point is judged against
DEFAULT_WINDOW = 7
#: how many spreads away from the middle value is unusual
DEFAULT_THRESHOLD = Decimal("3")
#: scales the median absolute deviation to the standard deviation of normal data
MAD_SCALE = Decimal("1.4826")
#: a series longer than this is judged on its latest points (a cap that says so)
MAX_SERIES_POINTS = 5000

ADDITIVE_WORDS = ("only a value that is added up (Sum{count}) splits into parts that add up "
                  "to the whole")


class InsightRefused(ValueError):
    """An insight that would be wrong or has nothing to stand on; ``str(exc)``
    is the plain sentence for the person."""


# ── small exact helpers ──────────────────────────────────────────────────────

def _dec(v: Any) -> Decimal:
    """A number as ``Decimal`` (NULL = 0, the empty side of a comparison).
    A float is taken by its shortest repr, so 0.1 stays 0.1."""
    if v is None:
        return Decimal(0)
    if isinstance(v, Decimal):
        return v
    if isinstance(v, bool):
        return Decimal(int(v))
    if isinstance(v, int):
        return Decimal(v)
    if isinstance(v, float):
        return Decimal(repr(v))
    return Decimal(str(v))


def _dec_or_none(v: Any) -> Optional[Decimal]:
    return None if v is None else _dec(v)


def percent(part: Decimal, whole: Decimal) -> Optional[Decimal]:
    """``part`` as a percentage of ``whole``, rounded to 2 places; None when
    the whole is 0 (a share of nothing is not a number)."""
    if whole == 0:
        return None
    return (part * 100 / whole).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def require_additive(aggregation: str, *, artifact_grain: str, measure_words: str) -> None:
    """The split-into-parts rule: Sum always (the grain rule decides whether a
    Sum is exact), Count only over detail rows."""
    agg = str(aggregation or "sum").strip().lower()
    if agg == "sum":
        return
    if agg == "count" and artifact_grain == mc.GRAIN_DETAIL:
        return
    count = ", or Count over rows that are not already added up"
    raise InsightRefused(f"{measure_words} cannot be split into parts: "
                         + ADDITIVE_WORDS.format(count=count) + ".")


def _exact(coltype: str, aggregation: str) -> bool:
    agg = str(aggregation or "sum").lower()
    return agg == "count" or mc._is_exact_numeric_type(coltype)


def _cast_marker(coltype: str) -> str:
    """``?`` bound against a column of this type: a date / time column takes
    the ISO text the page sends (cast in SQL, the type from DESCRIBE)."""
    if mc._is_temporal_type(coltype):
        return f"CAST(? AS {coltype})"
    return "?"


def _value_clause(column: str, value: Any, schema: Dict[str, str]) -> Tuple[str, List[Any]]:
    qi = _quote_ident(column)
    if value is None:
        return f"{qi} IS NULL", []
    return f"{qi} = {_cast_marker(schema[column])}", [value]


def _and(where: str, clause: str) -> str:
    return f"{where} AND {clause}" if where else f" WHERE {clause}"


def _members_key(row: Sequence[Any]) -> Tuple:
    return tuple(row)


# ── A / B: two values of a column ────────────────────────────────────────────

def compare_values(path: Path, column: str, *, a: Any = None, b: Any = None,
                   path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                   slicers: Optional[Dict[str, Sequence[Any]]] = None,
                   column_words: str = "",
                   threads: int = mc.DEFAULT_THREADS,
                   memory_limit: str = mc.DEFAULT_MEMORY_LIMIT) -> Tuple[Any, Any]:
    """The two values of ``column`` to compare: the ones asked for (each must
    be in the result), else the latest two in the result (B = the latest,
    A = the one before).  Refused in words when the result holds fewer than
    two."""
    words = column_words or column
    con = mc._connect(threads, memory_limit)
    try:
        src = mc._artifact_src(Path(path))
        schema = mc._describe(con, src)
        mc._require_columns([column], schema, "compare")
        where, params = mc._build_where(path_filters, slicers, schema)
        if a is not None and b is not None:
            for v in (a, b):
                clause, extra = _value_clause(column, v, schema)
                n = con.execute(f"SELECT COUNT(*) FROM {src}{_and(where, clause)}",
                                params + extra).fetchone()[0]
                if not n:
                    raise InsightRefused(f"{words} {_plain(v)} is not in this run's result.")
            if str(a) == str(b):
                raise InsightRefused(f"Both sides of the comparison are {words} {_plain(a)}.")
            return a, b
        qi = _quote_ident(column)
        got = [r[0] for r in con.execute(
            f"SELECT DISTINCT {qi} FROM {src}{_and(where, f'{qi} IS NOT NULL')} "
            f"ORDER BY {qi} DESC LIMIT 2", params).fetchall()]
    finally:
        con.close()
    if len(got) < 2:
        only = f" ({_plain(got[0])})" if got else ""
        raise InsightRefused(f"This run's result holds only one {words}{only}, so there is nothing "
                             f"to compare it with.")
    return got[1], got[0]


def _plain(v: Any) -> str:
    if v is None:
        return "(no value)"
    if hasattr(v, "isoformat"):
        s = v.isoformat()
        return s[:10] if s.endswith("T00:00:00") or len(s) == 10 else s
    s = str(v)
    return s[:10] if len(s) >= 19 and s[10:19] == "T00:00:00" else s


# ── 1. member changes (explain a change / top movers) ────────────────────────

def member_changes(path_b: Path, *, dimensions: Sequence[str], measure: str,
                   aggregation: str = "sum",
                   path_a: Optional[Path] = None,
                   compare: Optional[Tuple[str, Any, Any]] = None,
                   path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                   slicers: Optional[Dict[str, Sequence[Any]]] = None,
                   top_n: Optional[int] = DEFAULT_TOP_N,
                   order: str = "size",
                   artifact_grain: str = mc.GRAIN_GROUPED,
                   artifact_group_columns: Optional[Sequence[str]] = None,
                   measure_words: str = "",
                   threads: int = mc.DEFAULT_THREADS,
                   memory_limit: str = mc.DEFAULT_MEMORY_LIMIT) -> Dict[str, Any]:
    """Each member of ``dimensions`` with its value at A and B and the change.

    Exactly one basis: ``compare=(column, a, b)`` (both sides read from
    ``path_b``) or ``path_a`` (A = that earlier stored result).
    ``order``: ``"size"`` ranks by the size of the change (largest first);
    ``"up"`` lists the increases only, largest first; ``"down"`` the
    decreases only, largest fall first.  The members beyond ``top_n`` are
    ``rest`` -- for ``"size"`` every other member, so
    ``sum(member changes) + rest.change == total.change`` exactly.

    Returns ``{"members": [{"values": [...], "a", "b", "change"}...],
    "rest": {"count", "a", "b", "change"}, "total": {"a", "b", "change"},
    "member_count", "exact"}`` with every amount a ``Decimal``.
    """
    dims = list(dimensions)
    if not dims:
        raise ValueError("member changes need at least one field to split by")
    if len(set(dims)) != len(dims):
        raise ValueError(f"duplicate field(s): {dims!r}")
    if (compare is None) == (path_a is None):
        raise ValueError("member changes need exactly one basis: two values of a column, or an earlier run")
    if order not in ("size", "up", "down"):
        raise ValueError(f"unknown order {order!r}")
    gated = mc._gate_measures([{"column": measure, "aggregation": aggregation}],
                              artifact_grain, artifact_group_columns)
    agg = gated[0][1]
    require_additive(agg, artifact_grain=artifact_grain, measure_words=measure_words or measure)
    if compare is not None and compare[0] in dims:
        raise InsightRefused("The field being compared cannot also split the change.")
    n_top = None if top_n is None or int(top_n) <= 0 else int(top_n)

    con = mc._connect(threads, memory_limit)
    try:
        src_b = mc._artifact_src(Path(path_b))
        schema_b = mc._describe(con, src_b)
        if path_a is not None:
            src_a = mc._artifact_src(Path(path_a))
            schema_a = mc._describe(con, src_a)
        else:
            src_a, schema_a = src_b, schema_b
        for schema, which in ((schema_b, "this run"), (schema_a, "the earlier run")):
            missing = [c for c in dims + [measure] if c not in schema]
            if missing:
                raise ValueError(f"{which}'s result has no column(s) {missing!r}")
        where_b, params_b = mc._build_where(path_filters, slicers, schema_b)
        where_a, params_a = mc._build_where(path_filters, slicers, schema_a)
        if compare is not None:
            col, a_val, b_val = compare
            mc._require_columns([col], schema_b, "compare")
            cl_a, ex_a = _value_clause(col, a_val, schema_b)
            cl_b, ex_b = _value_clause(col, b_val, schema_b)
            where_a, params_a = _and(where_a, cl_a), params_a + ex_a
            where_b, params_b = _and(where_b, cl_b), params_b + ex_b
        exact = _exact(schema_b.get(measure, ""), agg) and _exact(schema_a.get(measure, ""), agg)

        g = [f"g{i}" for i in range(len(dims))]
        sel_a = ", ".join(f"{_quote_ident(d)} AS {g[i]}" for i, d in enumerate(dims))
        grp = ", ".join(_quote_ident(d) for d in dims)
        side = lambda src, schema, where: (                        # noqa: E731
            f"SELECT {sel_a}, {mc._agg_expr(measure, agg, schema)} AS v FROM {src}{where} GROUP BY {grp}")
        on = " AND ".join(f"a.{x} IS NOT DISTINCT FROM b.{x}" for x in g)
        coalesced = ", ".join(f"COALESCE(a.{x}, b.{x}) AS {x}" for x in g)
        delta = "(COALESCE(b.v, 0) - COALESCE(a.v, 0))"
        tie = ", ".join(f"{x} ASC NULLS LAST" for x in g)
        if order == "size":
            keep, rank_by = "TRUE", f"ABS(d) DESC, {tie}"
        elif order == "up":
            keep, rank_by = "d > 0", f"d DESC, {tie}"
        else:
            keep, rank_by = "d < 0", f"d ASC, {tie}"
        base = (f"WITH a AS ({side(src_a, schema_a, where_a)}), b AS ({side(src_b, schema_b, where_b)}), "
                f"j AS (SELECT {coalesced}, a.v AS va, b.v AS vb, {delta} AS d "
                f"FROM a FULL OUTER JOIN b ON {on}), "
                f"r AS (SELECT *, ROW_NUMBER() OVER (ORDER BY {rank_by}) AS rk FROM j WHERE {keep}) ")
        params = params_a + params_b
        top_sql = base + f"SELECT {', '.join(g)}, va, vb, d FROM r" + (
            f" WHERE rk <= {n_top}" if n_top else "") + " ORDER BY rk"
        top_rows = con.execute(top_sql, params).fetchall()
        tot = con.execute(
            f"WITH a AS ({side(src_a, schema_a, where_a)}), b AS ({side(src_b, schema_b, where_b)}) "
            f"SELECT (SELECT COUNT(*) FROM (SELECT {', '.join(g)} FROM a UNION SELECT {', '.join(g)} FROM b) u), "
            f"(SELECT SUM(v) FROM a), (SELECT SUM(v) FROM b)", params).fetchone()
        counted = con.execute(base + "SELECT COUNT(*) FROM r", params).fetchone()[0]
    finally:
        con.close()

    members = []
    for row in top_rows:
        values = list(row[:len(dims)])
        va, vb = _dec(row[len(dims)]), _dec(row[len(dims) + 1])
        members.append({"values": values, "a": va, "b": vb, "change": vb - va,
                        "only_in": ("b" if row[len(dims)] is None else "a" if row[len(dims) + 1] is None else None)})
    total_a, total_b = _dec(tot[1]), _dec(tot[2])
    total_change = total_b - total_a
    shown_a = sum((m["a"] for m in members), Decimal(0))
    shown_b = sum((m["b"] for m in members), Decimal(0))
    rest_count = int(counted) - len(members)
    if order == "size":
        # every member not listed: the list + this row IS the whole
        rest = {"count": int(tot[0]) - len(members), "a": total_a - shown_a, "b": total_b - shown_b}
        rest["change"] = rest["b"] - rest["a"]
    else:
        rest = {"count": max(0, rest_count), "a": None, "b": None, "change": None}
    return {"members": members, "rest": rest,
            "total": {"a": total_a, "b": total_b, "change": total_change},
            "member_count": int(tot[0]), "matching": int(counted), "exact": exact,
            "aggregation": agg}


# ── 2. one level of a decomposition ──────────────────────────────────────────

def split_total(path: Path, *, column: str, measure: str, aggregation: str = "sum",
                path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                slicers: Optional[Dict[str, Sequence[Any]]] = None,
                top_n: Optional[int] = DEFAULT_TOP_N,
                artifact_grain: str = mc.GRAIN_GROUPED,
                artifact_group_columns: Optional[Sequence[str]] = None,
                measure_words: str = "",
                threads: int = mc.DEFAULT_THREADS,
                memory_limit: str = mc.DEFAULT_MEMORY_LIMIT) -> Dict[str, Any]:
    """The members of ``column`` under the filters, biggest first by size,
    each with its share of the level's total; the rest as one row.
    ``sum(members) + rest.value == total`` exactly (a DECIMAL measure)."""
    gated = mc._gate_measures([{"column": measure, "aggregation": aggregation}],
                              artifact_grain, artifact_group_columns)
    agg = gated[0][1]
    require_additive(agg, artifact_grain=artifact_grain, measure_words=measure_words or measure)
    n_top = None if top_n is None or int(top_n) <= 0 else int(top_n)
    con = mc._connect(threads, memory_limit)
    try:
        src = mc._artifact_src(Path(path))
        schema = mc._describe(con, src)
        mc._require_columns([column, measure], schema, "decomposition")
        where, params = mc._build_where(path_filters, slicers, schema)
        qc = _quote_ident(column)
        lvl = (f"WITH l AS (SELECT {qc} AS g0, {mc._agg_expr(measure, agg, schema)} AS v "
               f"FROM {src}{where} GROUP BY {qc}), "
               f"r AS (SELECT *, ROW_NUMBER() OVER (ORDER BY ABS(v) DESC, g0 ASC NULLS LAST) AS rk FROM l) ")
        rows = con.execute(lvl + "SELECT g0, v FROM r" + (f" WHERE rk <= {n_top}" if n_top else "")
                           + " ORDER BY rk", params).fetchall()
        tot = con.execute(lvl + "SELECT COUNT(*), SUM(v) FROM l", params).fetchone()
        exact = _exact(schema.get(measure, ""), agg)
    finally:
        con.close()
    total = _dec(tot[1])
    members = [{"value": r[0], "amount": _dec(r[1])} for r in rows]
    for m in members:
        m["share_pct"] = percent(m["amount"], total)
    shown = sum((m["amount"] for m in members), Decimal(0))
    rest = {"count": int(tot[0]) - len(members), "amount": total - shown}
    rest["share_pct"] = percent(rest["amount"], total)
    return {"members": members, "rest": rest, "total": total, "member_count": int(tot[0]),
            "exact": exact, "aggregation": agg}


# ── 3. a series and the anomaly rule ─────────────────────────────────────────

def series_points(path: Path, *, column: str, measure: str, aggregation: str = "sum",
                  path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                  slicers: Optional[Dict[str, Sequence[Any]]] = None,
                  artifact_grain: str = mc.GRAIN_GROUPED,
                  artifact_group_columns: Optional[Sequence[str]] = None,
                  max_points: int = MAX_SERIES_POINTS,
                  threads: int = mc.DEFAULT_THREADS,
                  memory_limit: str = mc.DEFAULT_MEMORY_LIMIT) -> Dict[str, Any]:
    """``measure`` per value of ``column`` in the column's own order (oldest
    first).  NULL values of the column are left out and counted; past
    ``max_points`` the LATEST points are kept and the answer says so."""
    gated = mc._gate_measures([{"column": measure, "aggregation": aggregation}],
                              artifact_grain, artifact_group_columns)
    agg = gated[0][1]
    con = mc._connect(threads, memory_limit)
    try:
        src = mc._artifact_src(Path(path))
        schema = mc._describe(con, src)
        mc._require_columns([column, measure], schema, "series")
        where, params = mc._build_where(path_filters, slicers, schema)
        qc = _quote_ident(column)
        nulls = con.execute(f"SELECT COUNT(*) FROM {src}{_and(where, f'{qc} IS NULL')}", params).fetchone()[0]
        total = con.execute(f"SELECT COUNT(DISTINCT {qc}) FROM {src}{where}", params).fetchone()[0]
        rows = con.execute(
            f"SELECT {qc}, {mc._agg_expr(measure, agg, schema)} AS v FROM {src}"
            f"{_and(where, f'{qc} IS NOT NULL')} GROUP BY {qc} ORDER BY {qc} DESC LIMIT {int(max_points)}",
            params).fetchall()
    finally:
        con.close()
    rows = rows[::-1]
    return {"points": [{"at": r[0], "value": _dec_or_none(r[1])} for r in rows],
            "total_points": int(total), "cut": int(total) > len(rows),
            "rows_without_value": int(nulls), "aggregation": agg}


def _median(values: Sequence[Decimal]) -> Decimal:
    s = sorted(values)
    n = len(s)
    mid = n // 2
    return s[mid] if n % 2 else (s[mid - 1] + s[mid]) / 2


def flag_anomalies(values: Sequence[Optional[Decimal]], *, window: int = DEFAULT_WINDOW,
                   threshold: Decimal = DEFAULT_THRESHOLD) -> List[Dict[str, Any]]:
    """The rule in the module docstring, point by point.  ``values`` in order;
    a point with no value (NULL) is not judged and does not count as an
    earlier point.  Returns one dict per point: ``judged``, ``median``,
    ``low``, ``high``, ``flag`` (``"above"`` / ``"below"`` / None)."""
    window = int(window)
    if window < 1:
        raise ValueError("the window must be at least 1 point")
    k = _dec(threshold)
    out: List[Dict[str, Any]] = []
    seen: List[Decimal] = []
    for v in values:
        entry: Dict[str, Any] = {"judged": False, "median": None, "low": None, "high": None, "flag": None}
        if v is not None and len(seen) >= window:
            prev = seen[-window:]
            m = _median(prev)
            spread = MAD_SCALE * _median([abs(p - m) for p in prev])
            low, high = m - k * spread, m + k * spread
            entry.update(judged=True, median=m, low=low, high=high,
                         flag="above" if v > high else "below" if v < low else None)
        out.append(entry)
        if v is not None:
            seen.append(_dec(v))
    return out


def anomaly_rule_words(window: int, threshold: Decimal, at_words: str) -> str:
    k = _dec(threshold)
    k_words = f"{k.normalize():f}"
    return (f"Each {at_words} is judged against the {int(window)} before it: a value is unusual when it is "
            f"further from their middle value (median) than {k_words} times their typical spread "
            f"(1.4826 x the middle of their distances from that median). The first {int(window)} are not judged.")
