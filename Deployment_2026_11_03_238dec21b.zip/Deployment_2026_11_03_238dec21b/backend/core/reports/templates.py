"""Report templates -- a report started from a design (2026-11-02;
docs/REPORT_DESIGN_UPGRADE_PLAN_2026_11_02.html section 2, step 7).

The owner: "along with some report templates".  A template is a DESIGN with
SLOTS (the date, the categories, the amounts); a person picks a template and a
dataset, QueryStudio proposes which columns fill each slot from the column
types (``suggest_slots``), the person adjusts and names it, and
``build_report`` turns (template, dataset, slots, name, theme) into the SAME
payloads the editor saves by hand -- one report body for ``POST
/api/business-reports`` and the parameter rows for ``PUT .../parameters/batch``.
The browser creates the report through those existing routes (as
``scripts/docker_proof/owner_demo_reports.py`` does), so a template can never
save what the product refuses; a refusal here is ``TemplateRefused`` in words.

Everything a template brings is CONFIGURATION of the canvas: KPI cards
(``canvas_kpi``), chart labels / centre / the overlay (``canvas_chart_options``),
colour by value (``canvas_outline``), pages, band chips, a theme.  Nothing is
named after one team's report; the designs are generic.

2026-11-03 (the owner: "more ... complex type of report scenarios"): five finance
designs -- a P&L explain BRIDGE (a waterfall of values, ``canvas.is_bridge``), a
STATEMENT with subtotals at every level, LIMIT usage and a BREAK report (values
worked out from two others, ``canvas_derived``), AGEING buckets.

PURE: no database, no I/O.  ``TEMPLATES`` is the catalogue (id, name, what it
shows, its slots and their counts, a suggested theme, a wireframe preview);
each template's ``build`` is a function of the resolved slots.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Sequence

from core.reports.canvas import GRID_COLS, MAX_TILES

MAX_NAME = 200
SLOT_KINDS = ("date", "category", "amount")
_DATE_TYPES = ("date", "timestamp", "datetime", "time")
_NUMERIC = ("int", "decimal", "numeric", "double", "float", "real", "number", "money", "bigint", "smallint")
_DATEISH_NAMES = ("date", "_dt", "day", "cob", "asof", "as_of", "period", "month")
#: the business date parameter every dated template asks for
_BUSINESS_DATE = "business_date"
#: the two-dates parameter a comparison template asks for (today vs the previous business day)
_COMPARE = "compare"
_PERIOD = "period"
KPI_FILL_STYLES = ("plain", "filled", "gradient")


class TemplateRefused(ValueError):
    """A template cannot be built from these slots -- said in plain words (422 at the route)."""


class Slot:
    """``prefer``: name words, best first (UAT 2026-11-03) -- an amount slot with them is proposed ONLY a
    column whose name holds one (the best word wins), never "the next amount": the P&L bridge's total
    went into its parts and was counted twice.  Nothing matches = proposed empty (the slot is optional)."""

    def __init__(self, id: str, kind: str, label: str, min: int, max: int, help: str = "",
                 prefer: Sequence[str] = ()):
        self.id, self.kind, self.label, self.min, self.max, self.help = id, kind, label, min, max, help
        self.prefer = tuple(prefer)

    def as_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "kind": self.kind, "label": self.label, "min": self.min, "max": self.max, "help": self.help}


# ── column facts ────────────────────────────────────────────────────────────

def _dtype(c: dict) -> str:
    return str(c.get("data_type") or "").lower()


def is_date_column(c: dict) -> bool:
    if any(t in _dtype(c) for t in _DATE_TYPES):
        return True
    name = str(c.get("physical_name") or "").lower()
    return c.get("column_type") == "dimension" and any(n in name for n in _DATEISH_NAMES) and "amount" not in name


def is_amount_column(c: dict) -> bool:
    if c.get("column_type") in ("measure", "kpi"):
        return True
    return any(t in _dtype(c) for t in _NUMERIC) and not is_date_column(c) and c.get("column_type") != "dimension"


def is_category_column(c: dict) -> bool:
    return c.get("column_type") in ("dimension", "detail", None, "") and not is_date_column(c) and not is_amount_column(c)


def column_kind(c: dict) -> Optional[str]:
    if is_date_column(c):
        return "date"
    if is_amount_column(c):
        return "amount"
    if is_category_column(c):
        return "category"
    return None


def _visible(columns: Sequence[dict]) -> List[dict]:
    return [c for c in columns if isinstance(c, dict) and c.get("id") is not None and not c.get("is_hidden")]


def suggest_slots(template: dict, columns: Sequence[dict]) -> Dict[str, List[int]]:
    """``{slot id: [column ids]}`` from the column TYPES: a date slot takes the first date
    column, a category slot the first categories (the dataset's order), an amount slot
    the first amounts; each slot up to its ``max``; an amount already taken by an earlier
    amount slot (actual / budget) is not offered twice.  The person adjusts."""
    cols = _visible(columns)
    dates = [c for c in cols if is_date_column(c)]
    cats = [c for c in cols if is_category_column(c)]
    amts = [c for c in cols if is_amount_column(c)]
    out: Dict[str, List[int]] = {}
    used_amounts: set = set()
    used_cats: set = set()
    for s in template["slots"]:
        if s.kind == "date":
            out[s.id] = [int(c["id"]) for c in dates[:s.max]]
        elif s.kind == "category":
            pick = [c for c in cats if int(c["id"]) not in used_cats][:s.max]
            out[s.id] = [int(c["id"]) for c in pick]
            used_cats.update(out[s.id])
        elif s.prefer:
            free = [c for c in amts if int(c["id"]) not in used_amounts]
            pick = []
            for word in s.prefer:
                pick = [c for c in free if word in _name_words(c)][:s.max]
                if pick:
                    break
            out[s.id] = [int(c["id"]) for c in pick]
            used_amounts.update(out[s.id])
        else:
            pick = [c for c in amts if int(c["id"]) not in used_amounts][:s.max]
            out[s.id] = [int(c["id"]) for c in pick]
            used_amounts.update(out[s.id])
    return out


def _name_words(c: dict) -> str:
    """The column's physical name and label, lower case, '&' kept (P&L)."""
    return f"{c.get('physical_name') or ''} {c.get('label') or ''}".lower()


def slot_words(template: dict, columns: Sequence[dict]) -> List[str]:
    """Why a suggestion may be short, in plain words (the dataset has no date column ...)."""
    cols = _visible(columns)
    words = []
    for s in template["slots"]:
        have = len([c for c in cols if column_kind(c) == s.kind])
        if have < s.min:
            noun = {"date": "a date column", "category": f"{s.min} category column{'s' if s.min > 1 else ''}",
                    "amount": f"{s.min} number column{'s' if s.min > 1 else ''}"}[s.kind]
            words.append(f"This dataset has {have} {s.kind} column{'s' if have != 1 else ''}; the design needs {noun} for '{s.label}'.")
    return words


# ── the resolved slots a builder works with ─────────────────────────────────

class Ctx:
    """The resolved slots: ``ctx.cols(slot)`` = the column dicts, ``ctx.ids(slot)``, and tile helpers."""

    def __init__(self, columns: Dict[int, dict], slots: Dict[str, List[int]], grouped: bool, calendar: Optional[str] = None):
        self.columns, self.slots, self.grouped, self.calendar = columns, slots, grouped, calendar
        self.notes: List[str] = []
        self._n = 0

    def cols(self, slot: str) -> List[dict]:
        return [self.columns[i] for i in self.slots.get(slot, [])]

    def ids(self, slot: str) -> List[int]:
        return list(self.slots.get(slot, []))

    def label(self, cid: int) -> str:
        c = self.columns[cid]
        return str(c.get("friendly_name") or c.get("physical_name") or f"column #{cid}")

    def measure(self, cid: int, agg: Optional[str] = None, label: Optional[str] = None) -> Dict[str, Any]:
        c = self.columns[cid]
        own = str(c.get("aggregation") or "").lower()
        agg = agg or ("sum" if (own in ("sum", "count", "") or not self.grouped) else own if own in ("min", "max") else "sum")
        m: Dict[str, Any] = {"column_id": cid, "aggregation": agg}
        if label:
            m["label"] = label
        return m

    def tile(self, kind: str, x: int, y: int, w: int, h: int, **kw) -> Dict[str, Any]:
        self._n += 1
        t: Dict[str, Any] = {"id": f"{kind}_{self._n}", "kind": kind, "title": "", "dimensions": [], "measures": [],
                             "series": None, "sort": None, "top_n": None, "layout": {"x": x, "y": y, "w": w, "h": h}}
        t.update(kw)
        return t

    def red(self, *cids: int) -> Dict[str, Dict[str, Any]]:
        return {str(c): {"decimals": 0, "thousands": True, "negative": "red_brackets", "zero": "blank"} for c in cids}

    def kpi_row(self, y: int, amounts: Sequence[int], *, compare: Optional[dict] = None, icons: Sequence[str] = (),
                style: Optional[str] = None, h: int = 2) -> List[Dict[str, Any]]:
        """One KPI card per amount across the width (1..4 cards)."""
        n = max(1, min(4, len(amounts)))
        w = GRID_COLS // n
        out = []
        for i, cid in enumerate(amounts[:4]):
            kw: Dict[str, Any] = {"title": self.label(cid), "measures": [self.measure(cid)], "formats": self.red(cid)}
            if compare:
                kw["compare"] = dict(compare)
                kw["good_when"] = "up"
            if icons:
                kw["icon"] = icons[i % len(icons)]
            if style:
                kw["style"] = style
            out.append(self.tile("number", i * w, y, w, h, **kw))
        return out


def _params(ctx: Ctx, *, date: Optional[int], categories: Sequence[int], compare: bool = False, period: Optional[str] = None,
            chips: bool = False) -> List[Dict[str, Any]]:
    """The parameter rows: the business date (latest with data), the two dates (the two newest
    dates with data -- the rule ``latest_with_data`` on a comparison, 2026-11-02, calendar or
    not) or a period anchored on the date, the categories as multi-selects
    whose lists live in PostgreSQL (value lists, owner_kind = parameter -- the batch route
    schedules them)."""
    rows: List[Dict[str, Any]] = []
    order = 0
    if date is not None:
        rows.append({"name": _BUSINESS_DATE, "label": "Business date", "parameter_type": "date", "lov_column_id": date,
                     "default_rule": "latest_with_data", "is_required": False, "sort_order": order, "values_source": None})
        order += 1
        if compare:
            row = {"name": _COMPARE, "label": "Compare two dates", "parameter_type": "cob_compare", "lov_column_id": date,
                   "is_required": False, "sort_order": order,
                   "description": "A (before) and B (after): every card shows B with its change against A"}
            # 2026-11-02 the two newest dates WITH DATA (B = the business date's own default,
            # A = the date before it) -- "@PREV_BUSINESS_DAY..@TODAY" compared TODAY, which
            # has no data until the day's load, and without a calendar it started empty
            row["default_rule"] = "latest_with_data"
            rows.append(row)
            order += 1
        if period:
            rows.append({"name": _PERIOD, "label": "Period", "parameter_type": "period", "lov_column_id": date,
                         "default_value": period, "is_required": False, "sort_order": order, "depends_on_index": 0,
                         "description": "Daily, month to date, year to date, a month of days, 12 month-ends or 3 year-ends"})
            order += 1
    for cid in categories:
        rows.append({"name": _param_name(ctx, cid, rows), "label": ctx.label(cid), "parameter_type": "multi_select",
                     "lov_column_id": cid, "is_required": False, "sort_order": order, "description": "Pick one or more; none = all"})
        order += 1
    return rows


def _param_name(ctx: Ctx, cid: int, taken: Sequence[dict]) -> str:
    import re
    base = re.sub(r"[^a-z0-9_]+", "_", str(ctx.columns[cid].get("physical_name") or f"c{cid}").lower()).strip("_") or f"c{cid}"
    name = base
    n = 2
    while any(r["name"] == name for r in taken) or name in (_BUSINESS_DATE, _COMPARE, _PERIOD):
        name = f"{base}_{n}"
        n += 1
    return name


def _band(ctx: Ctx, y: int, names: Sequence[str], *, chips: Sequence[str] = (), h: int = 2) -> Dict[str, Any]:
    kw: Dict[str, Any] = {"parameters": list(names)}
    if chips:
        kw["chips"] = list(chips)
    return ctx.tile("band", 0, y, GRID_COLS, h, **kw)


def _cat_params(rows: Sequence[dict]) -> List[str]:
    return [r["name"] for r in rows if r["parameter_type"] == "multi_select"]


# ── the ten designs ─────────────────────────────────────────────────────────

def _financial_summary(ctx: Ctx):
    date, cats, amts = ctx.ids("date")[0], ctx.ids("categories"), ctx.ids("amounts")
    rows = _params(ctx, date=date, categories=cats, compare=True)
    tiles = [_band(ctx, 0, [_BUSINESS_DATE, _COMPARE, *_cat_params(rows)])]
    tiles += ctx.kpi_row(2, amts, compare={"kind": "parameter"}, icons=("money", "bank", "chart", "percent"))
    tiles.append(ctx.tile("bar", 0, 4, 7, 6, title=f"{ctx.label(amts[0])} by {ctx.label(cats[0])}", dimensions=[cats[0]],
                          measures=[ctx.measure(amts[0])], sort={"by": "measure", "dir": "desc"}, top_n=12,
                          labels="values", compare_overlay=True))
    tiles.append(ctx.tile("donut", 7, 4, 5, 6, title=f"{ctx.label(amts[0])} mix", dimensions=[cats[-1]],
                          measures=[ctx.measure(amts[0])], top_n=8, labels="percent", centre="total"))
    tiles.append(ctx.tile("table", 0, 10, GRID_COLS, 8, title="Breakdown: A, B, change and %", dimensions=list(cats),
                          measures=[ctx.measure(a) for a in amts], sort={"by": "measure", "dir": "desc"},
                          formats={**ctx.red(*amts)}))
    return {"tiles": tiles, "compare": {"parameter": _COMPARE}}, rows


def _day_on_day(ctx: Ctx):
    date, cats, amts = ctx.ids("date")[0], ctx.ids("categories"), ctx.ids("amounts")
    rows = _params(ctx, date=date, categories=cats, compare=True)
    tiles = [_band(ctx, 0, [_COMPARE, *_cat_params(rows)])]
    tiles += ctx.kpi_row(2, amts, compare={"kind": "parameter"}, icons=("trend_up", "money", "chart"))
    tiles.append(ctx.tile("bar", 0, 4, GRID_COLS, 6, title=f"Top movers: {ctx.label(amts[0])} by {ctx.label(cats[0])}",
                          dimensions=[cats[0]], measures=[ctx.measure(amts[0])], sort={"by": "measure", "dir": "desc"},
                          top_n=10, labels="values", compare_overlay=True))
    tiles.append(ctx.tile("table", 0, 10, GRID_COLS, 8, title="A, B, change and % by " + " and ".join(ctx.label(c) for c in cats),
                          dimensions=list(cats), measures=[ctx.measure(a) for a in amts], sort={"by": "measure", "dir": "desc"},
                          formats=ctx.red(*amts)))
    return {"tiles": tiles, "compare": {"parameter": _COMPARE}}, rows


def _trend_over_time(ctx: Ctx):
    date, cats, amts = ctx.ids("date")[0], ctx.ids("categories"), ctx.ids("amounts")
    rows = _params(ctx, date=date, categories=cats, period="month_ends_12")
    tiles = [_band(ctx, 0, [_BUSINESS_DATE, _PERIOD, *_cat_params(rows)], chips=[_PERIOD])]
    tiles += ctx.kpi_row(2, amts, icons=("trend_up", "money"), style=None)
    for i, t in enumerate(tiles[1:]):
        t["title"] = f"{ctx.label(amts[i])} over the period"
        t["sparkline"] = {"column_id": date, "points": 12}
    tiles.append(ctx.tile("line", 0, 4, GRID_COLS, 6, title=" and ".join(ctx.label(a) for a in amts) + f" by {ctx.label(date)}",
                          dimensions=[date], measures=[ctx.measure(a) for a in amts], trend_of=_PERIOD, labels="values"))
    tiles.append(ctx.tile("stacked_bar", 0, 10, GRID_COLS, 6, title=f"{ctx.label(amts[0])} by {ctx.label(cats[0])}, each date",
                          dimensions=[date], series=cats[0], measures=[ctx.measure(amts[0])], top_n=24))
    return {"tiles": tiles}, rows


def _operations_dashboard(ctx: Ctx):
    date, cats, amts = ctx.ids("date")[0], ctx.ids("categories"), ctx.ids("amounts")
    rows = _params(ctx, date=date, categories=cats, period="daily_month")
    tiles = [_band(ctx, 0, [_BUSINESS_DATE, _PERIOD, *_cat_params(rows)])]
    tiles += ctx.kpi_row(2, amts, icons=("factory", "truck", "box", "speed"), style="filled")
    tiles.append(ctx.tile("bar", 0, 4, GRID_COLS, 5, title=f"{ctx.label(amts[0])} by {ctx.label(date)}", dimensions=[date],
                          measures=[ctx.measure(amts[0]), ctx.measure(amts[1])], labels="values", top_n=31))
    w = GRID_COLS // min(3, len(cats))
    for i, c in enumerate(cats[:3]):
        tiles.append(ctx.tile("hbar", i * w, 9, w, 5, title=f"{ctx.label(amts[0])} by {ctx.label(c)}", dimensions=[c],
                              measures=[ctx.measure(amts[0])], sort={"by": "measure", "dir": "desc"}, top_n=8, labels="values"))
    tiles.append(ctx.tile("report", 0, 14, GRID_COLS, 8))
    return {"tiles": tiles}, rows


def _budget_vs_actual(ctx: Ctx):
    date, cats, actual, budget = ctx.ids("date")[0], ctx.ids("categories"), ctx.ids("actual")[0], ctx.ids("budget")[0]
    rows = _params(ctx, date=date, categories=cats)
    tiles = [_band(ctx, 0, [_BUSINESS_DATE, *_cat_params(rows)])]
    tiles.append(ctx.tile("number", 0, 2, 4, 2, title=f"{ctx.label(actual)} vs {ctx.label(budget)}", icon="target",
                          measures=[ctx.measure(actual)], formats=ctx.red(actual), good_when="up",
                          compare={"kind": "measure", "column_id": budget, "aggregation": ctx.measure(budget)["aggregation"], "label": ctx.label(budget)}))
    tiles.append(ctx.tile("number", 4, 2, 4, 2, title=ctx.label(actual), icon="money", measures=[ctx.measure(actual)], formats=ctx.red(actual)))
    tiles.append(ctx.tile("number", 8, 2, 4, 2, title=ctx.label(budget), icon="flag", measures=[ctx.measure(budget)], formats=ctx.red(budget)))
    tiles.append(ctx.tile("bar", 0, 4, GRID_COLS, 6, title=f"{ctx.label(actual)} and {ctx.label(budget)} by {ctx.label(cats[0])}",
                          dimensions=[cats[0]], measures=[ctx.measure(actual), ctx.measure(budget)], sort={"by": "measure", "dir": "desc"},
                          top_n=12, labels="values"))
    tiles.append(ctx.tile("waterfall", 0, 10, GRID_COLS, 6, title=f"{ctx.label(actual)} built up by {ctx.label(cats[0])}",
                          dimensions=[cats[0]], measures=[ctx.measure(actual, "sum")], top_n=12))
    tiles.append(ctx.tile("table", 0, 16, GRID_COLS, 8, title=f"{ctx.label(actual)} and {ctx.label(budget)} by " + " and ".join(ctx.label(c) for c in cats),
                          dimensions=list(cats), measures=[ctx.measure(actual), ctx.measure(budget)],
                          sort={"by": "measure", "dir": "desc"},
                          formats={**ctx.red(actual, budget), str(actual): {**ctx.red(actual)[str(actual)], "sign_colour": True,
                                                                             "scale": {"low": "#ffffff", "high": "#d5f0dc"}}}))
    return {"tiles": tiles}, rows


def _top_n_ranking(ctx: Ctx):
    cat, amt = ctx.ids("category")[0], ctx.ids("amount")[0]
    rows = _params(ctx, date=None, categories=[cat])
    tiles = [_band(ctx, 0, _cat_params(rows))]
    tiles.append(ctx.tile("hbar", 0, 2, 7, 8, title=f"Top 10 {ctx.label(cat)} by {ctx.label(amt)}", dimensions=[cat],
                          measures=[ctx.measure(amt)], sort={"by": "measure", "dir": "desc"}, top_n=10, labels="percent"))
    tiles.append(ctx.tile("number", 7, 2, 5, 2, title=f"{ctx.label(amt)} in all", icon="assessment", measures=[ctx.measure(amt)], formats=ctx.red(amt)))
    tiles.append(ctx.tile("donut", 7, 4, 5, 6, title="The top 10 and the rest", dimensions=[cat], measures=[ctx.measure(amt)],
                          sort={"by": "measure", "dir": "desc"}, top_n=10, other_mode="fold", centre="total"))
    tiles.append(ctx.tile("table", 0, 10, GRID_COLS, 8, title=f"Every {ctx.label(cat)}", dimensions=[cat], measures=[ctx.measure(amt)],
                          sort={"by": "measure", "dir": "desc"}, formats={str(amt): {**ctx.red(amt)[str(amt)], "scale": {"low": "#ffffff", "high": "#d6e6fb"}}}))
    return {"tiles": tiles}, rows


def _mix_share(ctx: Ctx):
    cats, amt = ctx.ids("categories"), ctx.ids("amount")[0]
    rows = _params(ctx, date=None, categories=cats)
    tiles = [_band(ctx, 0, _cat_params(rows))]
    tiles.append(ctx.tile("donut", 0, 2, 6, 7, title=f"{ctx.label(amt)} by {ctx.label(cats[0])}", dimensions=[cats[0]],
                          measures=[ctx.measure(amt)], top_n=8, labels="percent", centre="total"))
    tiles.append(ctx.tile("treemap", 6, 2, 6, 7, title=f"{ctx.label(amt)} by {ctx.label(cats[-1])}", dimensions=[cats[-1]],
                          measures=[ctx.measure(amt)], top_n=20, labels="percent"))
    tiles.append(ctx.tile("table", 0, 9, GRID_COLS, 8, title="Every part", dimensions=list(cats), measures=[ctx.measure(amt)],
                          sort={"by": "measure", "dir": "desc"}, formats={str(amt): {**ctx.red(amt)[str(amt)], "scale": {"low": "#ffffff", "high": "#d6e6fb"}}}))
    return {"tiles": tiles}, rows


def _detail_listing(ctx: Ctx):
    date = (ctx.ids("date") or [None])[0]
    cats = ctx.ids("categories")
    rows = _params(ctx, date=date, categories=cats)
    tiles = [_band(ctx, 0, [r["name"] for r in rows]), ctx.tile("report", 0, 2, GRID_COLS, 12)]
    return {"tiles": tiles}, rows


def _matrix_heatmap(ctx: Ctx):
    cats, amt = ctx.ids("categories"), ctx.ids("amount")[0]
    rows = _params(ctx, date=None, categories=[])
    tiles = [ctx.tile("heatmap", 0, 0, GRID_COLS, 10, title=f"{ctx.label(amt)}: {ctx.label(cats[0])} by {ctx.label(cats[1])}",
                      dimensions=[cats[0]], series=cats[1], measures=[ctx.measure(amt)], formats=ctx.red(amt))]
    tiles.append(ctx.tile("table", 0, 10, GRID_COLS, 8, title="The cells as rows", dimensions=list(cats[:2]), measures=[ctx.measure(amt)],
                          sort={"by": "measure", "dir": "desc"}, formats={str(amt): {**ctx.red(amt)[str(amt)], "scale": {"low": "#ffffff", "high": "#d6e6fb"}}}))
    return {"tiles": tiles}, rows


def _multi_page_pack(ctx: Ctx):
    date, cats, amts = ctx.ids("date")[0], ctx.ids("categories"), ctx.ids("amounts")
    rows = _params(ctx, date=date, categories=cats, compare=True)
    band = _band(ctx, 0, [_BUSINESS_DATE, _COMPARE, *_cat_params(rows)])
    kpis = ctx.kpi_row(2, amts, compare={"kind": "parameter"}, icons=("bank", "money", "chart", "percent"))
    bars = ctx.tile("bar", 0, 4, 7, 6, title=f"{ctx.label(amts[0])} by {ctx.label(cats[0])}", dimensions=[cats[0]],
                    measures=[ctx.measure(amts[0])], sort={"by": "measure", "dir": "desc"}, top_n=12, labels="values", compare_overlay=True)
    mix = ctx.tile("donut", 7, 4, 5, 6, title=f"{ctx.label(amts[0])} mix", dimensions=[cats[-1]], measures=[ctx.measure(amts[0])],
                   top_n=8, labels="percent", centre="total")
    grid = ctx.tile("outline", 0, 0, GRID_COLS, 12, title="Breakdown", levels=list(cats), measures=[ctx.measure(a) for a in amts],
                    totals={"levels": [True] + [False] * (len(cats) - 1), "grand": True, "labels": {"grand": "Total"}},
                    open_level=1, formats=ctx.red(*amts))
    report = ctx.tile("report", 0, 0, GRID_COLS, 12)
    tiles = [band, *kpis, bars, mix, grid, report]
    pages = [{"id": "summary", "title": "Summary", "tiles": [band["id"], *[k["id"] for k in kpis], bars["id"], mix["id"]]},
             {"id": "breakdown", "title": "Breakdown", "tiles": [grid["id"]]},
             {"id": "detail", "title": "Detailed", "tiles": [report["id"]]}]
    return {"tiles": tiles, "compare": {"parameter": _COMPARE}, "pages": pages}, rows


# ── the five finance designs (2026-11-03) ───────────────────────────────────

#: limit usage colours: at or over the limit red, from 80 % amber, under it green
_USAGE_RULES = [{"op": "ge", "value": 100, "color": "red"},
                {"op": "ge", "value": 80, "color": "amber"},
                {"op": "lt", "value": 80, "color": "green"}]


def _pnl_bridge(ctx: Ctx):
    date, cats, parts = ctx.ids("date")[0], ctx.ids("categories"), ctx.ids("parts")
    total = ctx.ids("total")
    rows = _params(ctx, date=date, categories=cats)
    tiles = [_band(ctx, 0, [_BUSINESS_DATE, *_cat_params(rows)])]
    # the total (when named) is the first card; the bridge's steps are the parts only
    tiles += ctx.kpi_row(2, (total + parts)[:4], icons=("chart", "money", "exchange", "warning"))
    tiles.append(ctx.tile("waterfall", 0, 4, GRID_COLS, 7, title="How the P&L is made up: each part a step, then the total",
                          measures=[ctx.measure(p, "sum") for p in parts], labels="values"))
    tiles.append(ctx.tile("stacked_bar", 0, 11, GRID_COLS, 6, title=f"The parts by {ctx.label(cats[0])}", dimensions=[cats[0]],
                          measures=[ctx.measure(p) for p in parts], top_n=15))
    tiles.append(ctx.tile("table", 0, 17, GRID_COLS, 8, title="Every part by " + " and ".join(ctx.label(c) for c in cats),
                          dimensions=list(cats), measures=[ctx.measure(p) for p in parts], sort={"by": "measure", "dir": "desc"},
                          formats=ctx.red(*parts)))
    return {"tiles": tiles}, rows


def _statement(ctx: Ctx):
    date, levels, amts = ctx.ids("date")[0], ctx.ids("levels"), ctx.ids("amounts")
    rows = _params(ctx, date=date, categories=levels[:1])
    tiles = [_band(ctx, 0, [_BUSINESS_DATE, *_cat_params(rows)])]
    tiles += ctx.kpi_row(2, amts, icons=("bank", "money", "scale", "receipt"))
    tiles.append(ctx.tile("outline", 0, 4, GRID_COLS, 14, title="Statement", levels=list(levels),
                          measures=[ctx.measure(a) for a in amts],
                          totals={"levels": [True] * len(levels), "grand": True, "labels": {"grand": "Total"}},
                          open_level=min(2, len(levels)), formats=ctx.red(*amts)))
    return {"tiles": tiles}, rows


def _limit_usage(ctx: Ctx):
    date = (ctx.ids("date") or [None])[0]
    cats, usage, limit = ctx.ids("categories"), ctx.ids("usage")[0], ctx.ids("limit")[0]
    rows = _params(ctx, date=date, categories=cats)
    tiles = [_band(ctx, 0, [r["name"] for r in rows])]
    tiles.append(ctx.tile("number", 0, 2, 4, 2, title=f"{ctx.label(usage)} against {ctx.label(limit)}", icon="speed",
                          measures=[ctx.measure(usage)], formats=ctx.red(usage), good_when="down",
                          compare={"kind": "measure", "column_id": limit, "aggregation": ctx.measure(limit)["aggregation"],
                                   "label": ctx.label(limit)}))
    tiles.append(ctx.tile("number", 4, 2, 4, 2, title=ctx.label(usage), icon="bolt", measures=[ctx.measure(usage)], formats=ctx.red(usage)))
    tiles.append(ctx.tile("number", 8, 2, 4, 2, title=ctx.label(limit), icon="shield", measures=[ctx.measure(limit)], formats=ctx.red(limit)))
    tiles.append(ctx.tile("hbar", 0, 4, GRID_COLS, 7, title=f"{ctx.label(usage)} and {ctx.label(limit)} by {ctx.label(cats[0])}",
                          dimensions=[cats[0]], measures=[ctx.measure(usage), ctx.measure(limit)],
                          sort={"by": "measure", "dir": "desc"}, top_n=15, labels="values"))
    tiles.append(ctx.tile("table", 0, 11, GRID_COLS, 9, title="Usage of each limit, the closest to its limit first",
                          dimensions=list(cats), measures=[ctx.measure(usage), ctx.measure(limit)],
                          derived=[{"label": "Headroom", "op": "difference", "a": 1, "b": 0,
                                    "format": {**ctx.red(limit)[str(limit)], "sign_colour": True}},
                                   {"label": "Usage %", "op": "ratio", "a": 0, "b": 1,
                                    "format": {"decimals": 1, "thousands": True, "negative": "minus", "zero": "show",
                                               "rules": _USAGE_RULES}}],
                          sort={"by": "derived", "index": 1, "dir": "desc"}, formats=ctx.red(usage, limit)))
    return {"tiles": tiles}, rows


def _ageing_buckets(ctx: Ctx):
    date = (ctx.ids("date") or [None])[0]
    bucket, owners, amt = ctx.ids("bucket")[0], ctx.ids("owners"), ctx.ids("amount")[0]
    rows = _params(ctx, date=date, categories=owners)
    tiles = [_band(ctx, 0, [r["name"] for r in rows])]
    tiles.append(ctx.tile("number", 0, 2, 4, 2, title=f"{ctx.label(amt)} outstanding", icon="clock",
                          measures=[ctx.measure(amt)], formats=ctx.red(amt)))
    tiles.append(ctx.tile("bar", 4, 2, 8, 6, title=f"{ctx.label(amt)} by {ctx.label(bucket)}", dimensions=[bucket],
                          measures=[ctx.measure(amt)], labels="values"))
    tiles.append(ctx.tile("donut", 0, 4, 4, 4, title=f"Share of each {ctx.label(bucket)}", dimensions=[bucket],
                          measures=[ctx.measure(amt)], labels="percent", centre="total"))
    tiles.append(ctx.tile("stacked_bar", 0, 8, GRID_COLS, 7, title=f"{ctx.label(amt)} by {ctx.label(owners[0])}, split by {ctx.label(bucket)}",
                          dimensions=[owners[0]], series=bucket, measures=[ctx.measure(amt)],
                          sort={"by": "measure", "dir": "desc"}, top_n=15))
    tiles.append(ctx.tile("heatmap", 0, 15, GRID_COLS, 8, title=f"{ctx.label(owners[0])} by {ctx.label(bucket)}",
                          dimensions=[owners[0]], series=bucket, measures=[ctx.measure(amt)], formats=ctx.red(amt)))
    return {"tiles": tiles}, rows


def _break_report(ctx: Ctx):
    date = (ctx.ids("date") or [None])[0]
    keys, side_a, side_b = ctx.ids("keys"), ctx.ids("side_a")[0], ctx.ids("side_b")[0]
    rows = _params(ctx, date=date, categories=keys[:2])
    tiles = [_band(ctx, 0, [r["name"] for r in rows])]
    tiles.append(ctx.tile("number", 0, 2, 4, 2, title=f"{ctx.label(side_a)} against {ctx.label(side_b)}", icon="scale",
                          measures=[ctx.measure(side_a)], formats=ctx.red(side_a),
                          compare={"kind": "measure", "column_id": side_b, "aggregation": ctx.measure(side_b)["aggregation"],
                                   "label": ctx.label(side_b)}))
    tiles.append(ctx.tile("number", 4, 2, 4, 2, title=ctx.label(side_a), icon="table", measures=[ctx.measure(side_a)], formats=ctx.red(side_a)))
    tiles.append(ctx.tile("number", 8, 2, 4, 2, title=ctx.label(side_b), icon="table", measures=[ctx.measure(side_b)], formats=ctx.red(side_b)))
    diff = {"label": "Break", "op": "difference", "a": 0, "b": 1, "format": {**ctx.red(side_a)[str(side_a)], "sign_colour": True}}
    tiles.append(ctx.tile("table", 0, 4, GRID_COLS, 10, title="Breaks: the rows where the two sides do not match, the largest first",
                          dimensions=list(keys), measures=[ctx.measure(side_a), ctx.measure(side_b)],
                          derived=[{**diff, "nonzero": True}], sort={"by": "derived", "index": 0, "dir": "desc", "abs": True},
                          formats=ctx.red(side_a, side_b)))
    tiles.append(ctx.tile("table", 0, 14, GRID_COLS, 8, title="Every row, matched or not",
                          dimensions=list(keys), measures=[ctx.measure(side_a), ctx.measure(side_b)],
                          derived=[diff], sort={"by": "derived", "index": 0, "dir": "desc", "abs": True},
                          formats=ctx.red(side_a, side_b)))
    return {"tiles": tiles}, rows


def _t(id: str, name: str, description: str, slots: List[Slot], build: Callable, theme: str, preview: List[dict],
       pages: Sequence[str] = (), all_columns: bool = False) -> Dict[str, Any]:
    return {"id": id, "name": name, "description": description, "slots": slots, "build": build, "theme": theme,
            "preview": preview, "pages": list(pages), "all_columns": all_columns}


# the wireframe previews: boxes on the 12-column grid, a kind each (the browser draws them)
def _p(kind: str, x: int, y: int, w: int, h: int) -> dict:
    return {"kind": kind, "x": x, "y": y, "w": w, "h": h}


TEMPLATES: List[Dict[str, Any]] = [
    _t("financial_summary", "Financial summary",
       "KPI cards against the previous business day, a trend with the previous day as a dotted line, a breakdown with A, B, change and %, a mix donut.",
       [Slot("date", "date", "Business date", 1, 1, "The date the report is for"),
        Slot("categories", "category", "Categories", 1, 3, "What to break the amounts down by, top level first"),
        Slot("amounts", "amount", "Amounts", 1, 4, "Each becomes a KPI card")],
       _financial_summary, "Finance Blue",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 3, 1), _p("number", 3, 1, 3, 1), _p("number", 6, 1, 3, 1), _p("number", 9, 1, 3, 1),
        _p("bar", 0, 2, 7, 3), _p("donut", 7, 2, 5, 3), _p("table", 0, 5, 12, 3)]),
    _t("day_on_day", "Day on day",
       "Two business dates side by side: every KPI with its change, the top movers, a table of A, B, change and %.",
       [Slot("date", "date", "Business date", 1, 1, "The column the two dates come from"),
        Slot("categories", "category", "Categories", 1, 3, "Who moved: the first is the movers' category"),
        Slot("amounts", "amount", "Amounts", 1, 3, "Each becomes a KPI card")],
       _day_on_day, "Navy Dashboard",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 4, 1), _p("number", 4, 1, 4, 1), _p("number", 8, 1, 4, 1), _p("bar", 0, 2, 12, 3), _p("table", 0, 5, 12, 3)]),
    _t("trend_over_time", "Trend over time",
       "A period picked as chips (12 month-ends, month to date, year to date), KPI cards with sparklines, a trend line, the categories stacked by date.",
       [Slot("date", "date", "Date", 1, 1, "The date the trend runs along"),
        Slot("categories", "category", "Category", 1, 1, "The series of the stacked bars"),
        Slot("amounts", "amount", "Amounts", 1, 2, "The lines of the trend")],
       _trend_over_time, "Soft Cards",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 6, 1), _p("number", 6, 1, 6, 1), _p("line", 0, 2, 12, 3), _p("stacked_bar", 0, 5, 12, 3)]),
    _t("operations_dashboard", "Operations dashboard",
       "A row of filled KPI tiles, the amounts by day, three small bars by category, the detail table.",
       [Slot("date", "date", "Date", 1, 1, "The day"),
        Slot("categories", "category", "Categories", 2, 4, "The small bars, one each"),
        Slot("amounts", "amount", "Amounts", 2, 4, "The KPI tiles; the first two are the bars by day")],
       _operations_dashboard, "Operations Red",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 3, 1), _p("number", 3, 1, 3, 1), _p("number", 6, 1, 3, 1), _p("number", 9, 1, 3, 1),
        _p("bar", 0, 2, 12, 2), _p("hbar", 0, 4, 4, 2), _p("hbar", 4, 4, 4, 2), _p("hbar", 8, 4, 4, 2), _p("report", 0, 6, 12, 3)]),
    _t("budget_vs_actual", "Budget vs actual",
       "Actual against budget as a KPI, both by category, the actual built up as a waterfall, a table with the actual coloured by its sign and size.",
       [Slot("date", "date", "Date", 1, 1, "The date the report is for"),
        Slot("categories", "category", "Categories", 1, 2, "The breakdown"),
        Slot("actual", "amount", "Actual", 1, 1, "The amount that happened"),
        Slot("budget", "amount", "Budget", 1, 1, "The amount planned")],
       _budget_vs_actual, "Ledger",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 4, 1), _p("number", 4, 1, 4, 1), _p("number", 8, 1, 4, 1), _p("bar", 0, 2, 12, 2),
        _p("waterfall", 0, 4, 12, 2), _p("table", 0, 6, 12, 3)]),
    _t("top_n_ranking", "Top N ranking",
       "The top 10 as bars with their share, the total, a donut of the top 10 and the rest, a table of every one.",
       [Slot("category", "category", "Category", 1, 1, "What is ranked"), Slot("amount", "amount", "Amount", 1, 1, "What it is ranked by")],
       _top_n_ranking, "Corporate Blue",
       [_p("band", 0, 0, 12, 1), _p("hbar", 0, 1, 7, 4), _p("number", 7, 1, 5, 1), _p("donut", 7, 2, 5, 3), _p("table", 0, 5, 12, 3)]),
    _t("mix_share", "Mix / share",
       "A donut with the total in its centre and the share on each slice, a treemap, a table of every part.",
       [Slot("categories", "category", "Categories", 1, 2, "The parts; the donut uses the first, the treemap the last"),
        Slot("amount", "amount", "Amount", 1, 1, "What the parts add up to")],
       _mix_share, "Insight",
       [_p("band", 0, 0, 12, 1), _p("donut", 0, 1, 6, 4), _p("treemap", 6, 1, 6, 4), _p("table", 0, 5, 12, 3)]),
    _t("detail_listing", "Detail listing",
       "A filter row and the report's own table, every row; click-through actions can be added on the canvas afterwards.",
       [Slot("date", "date", "Date", 0, 1, "Optional: a business date filter"),
        Slot("categories", "category", "Filters", 0, 4, "Each becomes a multi-select filter in the band")],
       _detail_listing, "QueryStudio",
       [_p("band", 0, 0, 12, 1), _p("report", 0, 1, 12, 6)], all_columns=True),
    _t("matrix_heatmap", "Matrix heatmap",
       "One category down, another across, the cells coloured by the amount; the cells as rows beneath.",
       [Slot("categories", "category", "Rows and columns", 2, 2, "The first down, the second across"), Slot("amount", "amount", "Amount", 1, 1, "What colours the cells")],
       _matrix_heatmap, "Arctic",
       [_p("heatmap", 0, 0, 12, 5), _p("table", 0, 5, 12, 3)]),
    _t("multi_page_pack", "Multi-page pack",
       "Three tabs: Summary (KPI cards, the trend, the mix), Breakdown (the finance grid with totals) and Detailed (every row).",
       [Slot("date", "date", "Business date", 1, 1, "The date the pack is for"),
        Slot("categories", "category", "Levels", 2, 3, "The breakdown's levels, top first"),
        Slot("amounts", "amount", "Amounts", 2, 4, "The KPI cards and the grid's values")],
       _multi_page_pack, "Navy Dashboard",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 3, 1), _p("number", 3, 1, 3, 1), _p("number", 6, 1, 3, 1), _p("number", 9, 1, 3, 1),
        _p("bar", 0, 2, 7, 3), _p("donut", 7, 2, 5, 3)], pages=("Summary", "Breakdown", "Detailed")),
    _t("pnl_bridge", "P&L explain bridge",
       "How the P&L is made up: each part (market moves, carry, new trades, unexplained ...) a step of a waterfall, then the total; the parts by category and as a table.",
       [Slot("date", "date", "Business date", 1, 1, "The date the report is for"),
        Slot("categories", "category", "Categories", 1, 2, "What to break the parts down by"),
        Slot("total", "amount", "The total (optional)", 0, 1,
             "The P&L the parts add up to: shown as a card, never as a step (the bridge draws its own total)",
             prefer=("total", "formal", "net", "p&l", "pnl")),
        Slot("parts", "amount", "Parts of the P&L", 2, 8, "Each becomes a step of the bridge, in this order; not the total")],
       _pnl_bridge, "Ledger",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 3, 1), _p("number", 3, 1, 3, 1), _p("number", 6, 1, 3, 1), _p("number", 9, 1, 3, 1),
        _p("waterfall", 0, 2, 12, 3), _p("stacked_bar", 0, 5, 12, 2), _p("table", 0, 7, 12, 2)]),
    _t("statement", "Statement with subtotals",
       "A balance-sheet style statement: indented rows, level by level, a subtotal under every group and a grand total; KPI cards for the totals.",
       [Slot("date", "date", "Business date", 1, 1, "The date the statement is for"),
        Slot("levels", "category", "Levels", 2, 4, "The statement's rows, top level first"),
        Slot("amounts", "amount", "Amounts", 1, 4, "The statement's columns")],
       _statement, "Statement",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 6, 1), _p("number", 6, 1, 6, 1), _p("outline", 0, 2, 12, 6)]),
    _t("limit_usage", "Limit usage",
       "Usage against each limit: the headroom left and the usage %, red at or over the limit, amber from 80 %, green under it; the closest to its limit first.",
       [Slot("date", "date", "Date", 0, 1, "Optional: a business date filter"),
        Slot("categories", "category", "Limit holders", 1, 3, "Who or what each limit is for (desk, counterparty ...)"),
        Slot("usage", "amount", "Usage", 1, 1, "The amount used"),
        Slot("limit", "amount", "Limit", 1, 1, "The amount allowed")],
       _limit_usage, "Treasury Navy",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 4, 1), _p("number", 4, 1, 4, 1), _p("number", 8, 1, 4, 1),
        _p("hbar", 0, 2, 12, 3), _p("table", 0, 5, 12, 3)]),
    _t("ageing_buckets", "Ageing buckets",
       "How old the amounts are: the total, each age bucket as a bar and a share, each holder split by bucket, and a heat map of holder by bucket.",
       [Slot("date", "date", "Date", 0, 1, "Optional: a business date filter"),
        Slot("bucket", "category", "Age bucket", 1, 1, "The column holding the bucket (0-30, 31-60, 61-90, 90+ ...)"),
        Slot("owners", "category", "Holders", 1, 2, "Who the amounts belong to (counterparty, desk ...)"),
        Slot("amount", "amount", "Amount", 1, 1, "The amount outstanding")],
       _ageing_buckets, "Audit Grey",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 4, 1), _p("donut", 0, 2, 4, 2), _p("bar", 4, 1, 8, 3),
        _p("stacked_bar", 0, 4, 12, 2), _p("heatmap", 0, 6, 12, 3)]),
    _t("break_report", "Break report",
       "Two sides compared row by row: the breaks (the rows that do not match) with the largest first, the totals of each side, and every row with its difference.",
       [Slot("date", "date", "Date", 0, 1, "Optional: a business date filter"),
        Slot("keys", "category", "Match on", 1, 3, "The columns that pair a row of one side with the other"),
        Slot("side_a", "amount", "Side A", 1, 1, "One side's amount (our books)"),
        Slot("side_b", "amount", "Side B", 1, 1, "The other side's amount (theirs)")],
       _break_report, "Audit Grey",
       [_p("band", 0, 0, 12, 1), _p("number", 0, 1, 4, 1), _p("number", 4, 1, 4, 1), _p("number", 8, 1, 4, 1),
        _p("table", 0, 2, 12, 4), _p("table", 0, 6, 12, 3)]),
]
BY_ID: Dict[str, Dict[str, Any]] = {t["id"]: t for t in TEMPLATES}


def catalogue() -> List[Dict[str, Any]]:
    """What the browser lists: everything but the builder."""
    return [{"id": t["id"], "name": t["name"], "description": t["description"], "theme": t["theme"],
             "slots": [s.as_dict() for s in t["slots"]], "preview": t["preview"], "pages": t["pages"]} for t in TEMPLATES]


# ── the build ───────────────────────────────────────────────────────────────

def _check_slots(template: dict, columns: Dict[int, dict], slots: Dict[str, Any]) -> Dict[str, List[int]]:
    out: Dict[str, List[int]] = {}
    for s in template["slots"]:
        raw = slots.get(s.id) if isinstance(slots, dict) else None
        ids: List[int] = []
        for v in (raw if isinstance(raw, list) else ([] if raw is None else [raw])):
            try:
                ids.append(int(v))
            except (TypeError, ValueError):
                raise TemplateRefused(f"'{s.label}' names a column that is not a column id ({v!r}).")
        if len(ids) < s.min:
            raise TemplateRefused(f"'{s.label}' needs at least {s.min} column{'s' if s.min > 1 else ''}; {len(ids)} chosen.")
        if len(ids) > s.max:
            raise TemplateRefused(f"'{s.label}' takes at most {s.max} column{'s' if s.max > 1 else ''}; {len(ids)} chosen.")
        if len(set(ids)) != len(ids):
            raise TemplateRefused(f"'{s.label}' names the same column twice.")
        for cid in ids:
            c = columns.get(cid)
            if c is None:
                raise TemplateRefused(f"'{s.label}' names a column that is not in this dataset (#{cid}).")
            kind = column_kind(c)
            want = s.kind
            if want == "amount" and not is_amount_column(c):
                raise TemplateRefused(f"'{s.label}' needs a number column; {_name(c)} is not one.")
            if want == "date" and not is_date_column(c):
                raise TemplateRefused(f"'{s.label}' needs a date column; {_name(c)} is not one.")
            if want == "category" and kind != "category":
                raise TemplateRefused(f"'{s.label}' needs a category (text) column; {_name(c)} is a {kind or 'column of another kind'}.")
        out[s.id] = ids
    all_ids = [i for ids in out.values() for i in ids]
    if len(set(all_ids)) != len(all_ids):
        raise TemplateRefused("The same column fills two slots; pick a different column for one of them.")
    return out


def _name(c: dict) -> str:
    return str(c.get("friendly_name") or c.get("physical_name") or f"column #{c.get('id')}")


def build_report(template_id: str, dataset: dict, slots: Dict[str, Any], name: str, theme: Optional[str] = None,
                 *, grouped: Optional[bool] = None, calendar: Optional[str] = None) -> Dict[str, Any]:
    """``{"report": <POST /api/business-reports body>, "parameters": <PUT .../parameters/batch rows>, "notes": [words]}``
    -- pure; ``dataset`` = ``get_dataset_full`` (id, columns); ``grouped`` = the dataset's grain
    (None = derive from its columns: any column that adds up); ``calendar`` = the deployment's default
    business calendar name (None = none declared).  Raises ``TemplateRefused``."""
    t = BY_ID.get(str(template_id))
    if t is None:
        raise TemplateRefused(f"There is no design named '{template_id}'. Pick one of: {', '.join(x['id'] for x in TEMPLATES)}.")
    name = str(name or "").strip()
    if not name or len(name) > MAX_NAME:
        raise TemplateRefused(f"Give the report a name of at most {MAX_NAME} characters.")
    cols = {int(c["id"]): c for c in (dataset.get("columns") or []) if isinstance(c, dict) and c.get("id") is not None}
    if not cols:
        raise TemplateRefused("This dataset has no columns yet; detect its columns first.")
    if grouped is None:
        from core.reports.canvas import dataset_rows_are_grouped
        grouped = dataset_rows_are_grouped(list(cols.values()), False)
    resolved = _check_slots(t, cols, slots)
    ctx = Ctx(cols, resolved, bool(grouped), calendar)
    canvas, params = t["build"](ctx)
    canvas = {"version": 1, **canvas}
    tiles = canvas["tiles"]
    if len(tiles) > MAX_TILES:
        raise TemplateRefused(f"The design would make {len(tiles)} tiles; a report holds {MAX_TILES}.")
    # every column a tile, a parameter or a level uses is a column of the report (the ONE query returns it)
    used: List[int] = []
    for tile in tiles:
        for d in tile.get("dimensions") or []:
            used.append(int(d))
        for m in tile.get("measures") or []:
            used.append(int(m["column_id"]))
        if tile.get("series") is not None:
            used.append(int(tile["series"]))
        for lv in tile.get("levels") or []:
            used.append(int(lv))
        cmp = tile.get("compare") if isinstance(tile.get("compare"), dict) else {}
        if cmp.get("kind") == "measure":
            used.append(int(cmp["column_id"]))
        if isinstance(tile.get("sparkline"), dict):
            used.append(int(tile["sparkline"]["column_id"]))
    for p in params:
        if p.get("lov_column_id") is not None:
            used.append(int(p["lov_column_id"]))
    for ids in resolved.values():
        used.extend(ids)
    if t.get("all_columns"):                       # a listing shows EVERY (visible) column of the dataset
        used.extend(int(c["id"]) for c in cols.values() if not c.get("is_hidden"))
    column_ids = sorted(set(used), key=lambda i: (cols[i].get("sort_order") or 0, i))
    theme_name = str(theme or t["theme"])
    report = {"name": name, "description": t["description"], "dataset_id": int(dataset["id"]), "data_source_type": "dataset",
              "column_ids": column_ids,
              "layout_config": {"report_type": "table", "canvas": canvas, "theme": {"name": theme_name}}}
    return {"report": report, "parameters": params, "template": t["id"], "theme": theme_name, "notes": list(ctx.notes)}


__all__ = ["TEMPLATES", "BY_ID", "TemplateRefused", "catalogue", "suggest_slots", "slot_words", "build_report",
           "column_kind", "is_date_column", "is_amount_column", "is_category_column"]
