"""Values DERIVED from two of a table tile's values (2026-11-03).

The owner asked for limit usage (usage against a limit: the headroom and the
usage %) and a break report (two sides compared, only the rows that do not
match).  Both are a value worked out from two values of the SAME row AFTER
they are added up -- never a dataset column -- so a table tile carries::

    derived: [{"label": "Usage %", "op": "difference" | "ratio",
               "a": <index into the tile's measures>, "b": <index>,
               "nonzero"?: true,           # only the rows where it is not zero
               "format"?: {...}}]          # a tile number format (canvas_outline)
    sort:    {"by": "derived", "index": i, "dir": "asc"|"desc", "abs"?: true}

The arithmetic is the microcube's (``microcube.DERIVED_OPS``: a difference
counts a missing side as 0; a ratio is 100 * a / b, no value when b is 0), so
the screen (the cube route) and the documents (``canvas_export``) read the
same numbers.  This module is the save check and the request each reader
sends; the browser's twin is ``frontend/src/components/reports/canvas/canvasDerived.ts``.
"""
from __future__ import annotations

from typing import Any, Callable, List, Optional, Tuple

from core.reports.microcube import DERIVED_OPS, MAX_DERIVED

MAX_DERIVED_LABEL = 60
#: a ratio reads as a percentage with one decimal unless the tile says otherwise
RATIO_FORMAT = {"decimals": 1, "thousands": True, "negative": "minus", "zero": "show"}


def alias(i: int) -> str:
    return f"d{i}__"


def _idx(v: Any) -> Optional[int]:
    return v if isinstance(v, int) and not isinstance(v, bool) else None


def derived_of(t: dict) -> List[dict]:
    """The tile's derived values as stored (a table's only; anything else has none)."""
    d = t.get("derived") if t.get("kind") == "table" else None
    return [x for x in d if isinstance(x, dict)] if isinstance(d, list) else []


def derived_problems(t: dict, say: Callable[[Optional[dict], str], None]) -> None:
    """Every problem in plain words (the browser's ``derivedProblems`` says the same)."""
    raw = t.get("derived")
    if raw is None:
        return
    if t.get("kind") != "table":
        say(t, "only a table can show values worked out from two others.")
        return
    if not isinstance(raw, list) or len(raw) > MAX_DERIVED:
        say(t, f"it can show at most {MAX_DERIVED} values worked out from two others.")
        return
    n = len(t.get("measures") or [])
    for i, d in enumerate(raw, 1):
        if not isinstance(d, dict):
            say(t, f"worked-out value {i} must say how it is worked out.")
            continue
        unknown = sorted(set(d) - {"label", "op", "a", "b", "nonzero", "format"})
        if unknown:
            say(t, f"worked-out value {i} has settings it does not know: {', '.join(map(str, unknown))}.")
        lab = d.get("label")
        if not isinstance(lab, str) or not lab.strip() or len(lab.strip()) > MAX_DERIVED_LABEL:
            say(t, f"worked-out value {i} needs a name of at most {MAX_DERIVED_LABEL} characters.")
        if d.get("op") not in DERIVED_OPS:
            say(t, f"worked-out value {i} is either a difference (first minus second) or a ratio (first as a % of second).")
        a, b = _idx(d.get("a")), _idx(d.get("b"))
        if a is None or b is None or not (0 <= a < n and 0 <= b < n) or a == b:
            say(t, f"worked-out value {i} reads two different values of this table.")
        if d.get("nonzero") is not None and not isinstance(d.get("nonzero"), bool):
            say(t, f"worked-out value {i}: showing only the rows where it is not zero is on or off.")
        if d.get("format") is not None:
            from core.reports.canvas_outline import format_problems
            for msg in format_problems(d["format"]):
                say(t, f"worked-out value {i}: {msg}")
    s = t.get("sort")
    if isinstance(s, dict) and s.get("by") == "derived":
        k = _idx(s.get("index"))
        if k is None or not 0 <= k < len(raw):
            say(t, "it is sorted by a worked-out value it does not have.")
        if s.get("abs") is not None and not isinstance(s.get("abs"), bool):
            say(t, "sorting by size whatever the sign is on or off.")


def drill_request(t: dict) -> Tuple[List[dict], Optional[str], Optional[str], bool]:
    """(the microcube ``derived`` list, the sort column, its direction, sort by size) for this tile.
    The sort is None when the tile does not sort by a derived value."""
    ds = derived_of(t)
    req = [{"alias": alias(i), "op": d.get("op"), "a": f"v{d.get('a')}__", "b": f"v{d.get('b')}__",
            "nonzero": bool(d.get("nonzero"))} for i, d in enumerate(ds)]
    s = t.get("sort")
    if isinstance(s, dict) and s.get("by") == "derived" and _idx(s.get("index")) is not None \
            and 0 <= s["index"] < len(ds):
        return req, alias(s["index"]), ("asc" if s.get("dir") == "asc" else "desc"), bool(s.get("abs"))
    return req, None, None, False


def derived_format(t: dict, d: dict) -> Optional[dict]:
    """The number format a derived value shows with: its own, else a ratio's percentage,
    else (a difference) the tile's format of the value it starts from."""
    if isinstance(d.get("format"), dict):
        return d["format"]
    if d.get("op") == "ratio":
        return dict(RATIO_FORMAT)
    from core.reports.canvas_outline import tile_format_for
    ms = t.get("measures") or []
    a = _idx(d.get("a"))
    if a is not None and 0 <= a < len(ms) and isinstance(ms[a], dict):
        return tile_format_for(t, ms[a].get("column_id"))
    return None


def header_labels(t: dict) -> List[str]:
    return [str(d.get("label") or "").strip() or f"Value {i + 1}" for i, d in enumerate(derived_of(t))]
