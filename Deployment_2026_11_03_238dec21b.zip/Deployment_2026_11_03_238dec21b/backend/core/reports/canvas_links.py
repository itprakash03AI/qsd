"""Linked canvas tiles (2026-10-30, plan docs/REPORT_OUTLINE_AND_DETAIL_LINKS_2026_10_30.html §4).

A click on a tile of a report canvas (a row, a bar, a slice, a point) filters
every OTHER tile to that value -- Power BI's cross-filter.  The state is a
list of ``{column_id, value, tile_id?}`` entries (a clicked path, e.g.
Product Area = Credit > Business Area = FI Credit, is several entries):

* entries naming the SAME field are alternatives (``IN``), different fields
  must all hold (``AND``) -- exactly the microcube's ``slicers``;
* a click of SEVERAL levels at once (an outline row: Product Area = Credit >
  Business Area = FI) stamps its entries with one ``path`` (2026-10-30, the
  integration): on a tile that has a path, every click of THAT tile is one
  alternative -- "this path OR that path", each path all of its steps -- so
  Ctrl-adding Credit > FI and Rates > Govies is ``(PA = Credit AND BA = FI)
  OR (PA = Rates AND BA = Govies)``, never the wider ``PA IN (Credit, Rates)
  AND BA IN (FI, Govies)`` (which also lets Credit > Govies through).  The
  clicks of different tiles must all hold; entries without a path keep the
  rule above.  The microcube receives a path alternative as one
  ``path_filters`` step ``{"any_of": [[{column, value}, ...], ...]}``
  (``microcube._build_where``);
* ``tile_id`` is the tile that was clicked: it is not filtered by its own
  click (it shows what can be clicked);
* a tile with ``linked: false``, or a canvas with ``links: {enabled: false}``
  is not filtered at all.  The report's OWN table follows the links too
  (2026-10-30, every report a canvas): its pages are the matching rows of
  the stored result (``core/reports/report_table_links.py``) -- the same rule,
  never a new query to the source.

Every number is answered from the report's ONE stored, row-secured result
through the microcube -- never a new query to the source.  The viewer
(``frontend/src/components/reports/canvas/canvasLinks.ts``) and the exports
(``canvas_export.canvas_tile_tables(links=)``) apply the SAME rule; this
module is the server's half of it.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Sequence, Tuple

#: more clicked values than this in one export request is refused, not cut
MAX_LINKS = 200

#: a ``path`` id longer than this is refused (it is the clicked steps as text)
MAX_PATH_CHARS = 4000


class LinkFilter(dict):
    """The links of ONE tile: the dict is the microcube ``slicers``
    (``{physical_name: [values]}``); ``any_of`` holds the path alternatives,
    each a list of paths, each path a list of ``{column, value}`` steps that
    must all hold.  A tile is filtered when the dict OR ``any_of`` is
    non-empty -- test :func:`has_filter`, never the dict's truth value."""

    def __init__(self, slicers: Optional[Dict[str, List[Any]]] = None,
                 any_of: Optional[List[List[List[Dict[str, Any]]]]] = None) -> None:
        super().__init__(slicers or {})
        self.any_of: List[List[List[Dict[str, Any]]]] = list(any_of or [])


def has_filter(ls: Any) -> bool:
    return bool(ls) or bool(getattr(ls, "any_of", None))


def path_steps(ls: Any) -> List[Dict[str, Any]]:
    """The ``path_filters`` steps that carry a filter's path alternatives."""
    return [{"any_of": clause} for clause in getattr(ls, "any_of", None) or []]


def plain_slicers(ls: Any) -> Optional[Dict[str, List[Any]]]:
    """The filter's ``slicers`` as a plain dict; None when it has none."""
    return {k: list(v) for k, v in ls.items()} if ls else None


class LinkError(ValueError):
    """A linked filter that cannot be applied (said in plain words)."""


def parse_links(raw: Optional[str]) -> List[Dict[str, Any]]:
    """The export request's ``links`` query value -> entries.  ``None`` / ''
    -> [] (an export with no links is the old export).  A malformed value is
    a LinkError: a filter that cannot be read must never be dropped (the file
    would show MORE than the screen)."""
    if raw is None or str(raw).strip() == "":
        return []
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        raise LinkError("The linked filters sent with the export could not be read.")
    if not isinstance(data, list):
        raise LinkError("The linked filters sent with the export must be a list.")
    if len(data) > MAX_LINKS:
        raise LinkError(f"An export can carry at most {MAX_LINKS} linked values; this one has {len(data)}. "
                        "Clear some of them and export again.")
    out: List[Dict[str, Any]] = []
    for e in data:
        if not isinstance(e, dict) or isinstance(e.get("column_id"), bool):
            raise LinkError("A linked filter sent with the export is not a field and a value.")
        try:
            cid = int(e.get("column_id"))
        except (TypeError, ValueError):
            raise LinkError("A linked filter sent with the export does not name a field.")
        value = e.get("value")
        if isinstance(value, (dict, list)):
            raise LinkError("A linked filter's value must be a single value.")
        tid = e.get("tile_id")
        item = {"column_id": cid, "value": value, "tile_id": str(tid) if tid is not None else None}
        pth = e.get("path")
        if pth is not None:
            if not isinstance(pth, str) or not pth or len(pth) > MAX_PATH_CHARS:
                raise LinkError("A linked filter sent with the export names a clicked path that could not be read.")
            item["path"] = pth
        out.append(item)
    return out


def links_enabled(canvas: Any) -> bool:
    """A canvas links its tiles unless it says ``links: {enabled: false}``."""
    links = canvas.get("links") if isinstance(canvas, dict) else None
    return not (isinstance(links, dict) and links.get("enabled") is False)


def links_for_tile(tile: dict, links: Sequence[Dict[str, Any]], canvas: Any) -> List[Dict[str, Any]]:
    """The entries that filter THIS tile (none for an unlinked tile, a
    canvas with links switched off, or the tile's own clicks).  The report's
    own table is a tile like any other here (2026-10-30)."""
    if not links or not links_enabled(canvas):
        return []
    if not isinstance(tile, dict) or tile.get("linked") is False:
        return []
    tid = tile.get("id")
    return [e for e in links if e.get("tile_id") is None or e.get("tile_id") != tid]


def _phys(cols: Dict[int, dict], cid: Any) -> str:
    name = (cols.get(int(cid)) or {}).get("physical_name")
    if not name:
        raise LinkError(f"A linked filter names a field that is not in this report (column #{cid}).")
    return name


def tile_groups(entries: Sequence[Dict[str, Any]]
                ) -> Tuple[List[Dict[str, Any]], List[List[List[Dict[str, Any]]]]]:
    """``(plain entries, path clauses)``: the clicks of a tile that has a
    path become ONE clause (its paths, OR -- an entry without a path is a
    path of one step); the other tiles' entries stay plain.  A clause is a
    list of paths, a path a list of entries, in click order."""
    order: List[Any] = []
    by_tile: Dict[Any, List[Dict[str, Any]]] = {}
    for e in entries:
        k = e.get("tile_id")
        if k not in by_tile:
            order.append(k)
            by_tile[k] = []
        by_tile[k].append(e)
    plain: List[Dict[str, Any]] = []
    clauses: List[List[List[Dict[str, Any]]]] = []
    for k in order:
        group = by_tile[k]
        if not any(e.get("path") for e in group):
            plain.extend(group)
            continue
        porder: List[Any] = []
        paths: Dict[Any, List[Dict[str, Any]]] = {}
        for i, e in enumerate(group):
            pk = e.get("path") or ("#single", i)
            if pk not in paths:
                porder.append(pk)
                paths[pk] = []
            paths[pk].append(e)
        clauses.append([paths[pk] for pk in porder])
    return plain, clauses


def link_filter(entries: Sequence[Dict[str, Any]], cols: Dict[int, dict]) -> LinkFilter:
    """Entries -> the tile's :class:`LinkFilter` (slicers + path alternatives)."""
    plain, clauses = tile_groups(entries)
    any_of = [[[{"column": _phys(cols, e["column_id"]), "value": e.get("value")} for e in path]
               for path in clause] for clause in clauses]
    return LinkFilter(link_slicers(plain, cols), any_of)


def link_slicers(entries: Sequence[Dict[str, Any]], cols: Dict[int, dict]) -> Dict[str, List[Any]]:
    """Entries -> microcube ``slicers`` ``{physical_name: [values]}``.  A field
    that is not in the report is a LinkError (never silently skipped)."""
    out: Dict[str, List[Any]] = {}
    for e in entries:
        c = cols.get(int(e["column_id"]))
        name = (c or {}).get("physical_name")
        if not name:
            raise LinkError(f"A linked filter names a field that is not in this report (column #{e['column_id']}).")
        vals = out.setdefault(name, [])
        if e.get("value") not in vals:
            vals.append(e.get("value"))
    return out


def merge_slicers(own: Optional[Dict[str, List[Any]]], linked: Optional[Dict[str, List[Any]]]
                  ) -> Optional[Dict[str, List[Any]]]:
    """A tile's own slicers AND the linked ones: a field in both keeps only
    the values in both.  None when neither has any (the old call shape)."""
    if not has_filter(linked):
        return own or None
    out = LinkFilter({k: list(v) for k, v in (linked or {}).items()}, getattr(linked, "any_of", None))
    for k, v in (own or {}).items():
        out[k] = [x for x in v if x in out[k]] if k in out else list(v)
    return out


def _value_words(v: Any) -> str:
    if v is None:
        return "(no value)"
    if v == "":
        return "(blank)"
    s = str(v)
    if len(s) >= 19 and s[10:19] == "T00:00:00":
        s = s[:10]
    return s


def _label_of(cols: Dict[int, dict], cid: int) -> str:
    c = cols.get(cid) or {}
    return c.get("friendly_name") or c.get("label") or c.get("physical_name") or f"column #{cid}"


def link_words(entries: Sequence[Dict[str, Any]], cols: Dict[int, dict]) -> str:
    """"Product Area = Credit or Rates; Business Area = FI Credit" -- in the
    order the fields were first clicked; a tile's clicked paths read
    "(Product Area = Credit and Business Area = FI) or (Product Area = Rates
    and Business Area = Govies)"."""
    plain, clauses = tile_groups(entries)
    parts = [_plain_words(plain, cols)] if plain else []
    for clause in clauses:
        words = []
        for path in clause:
            w = " and ".join(f"{_label_of(cols, int(e['column_id']))} = {_value_words(e.get('value'))}"
                             for e in path)
            words.append(f"({w})" if len(clause) > 1 and len(path) > 1 else w)
        parts.append(" or ".join(words))
    return "; ".join(parts)


def _plain_words(entries: Sequence[Dict[str, Any]], cols: Dict[int, dict]) -> str:
    order: List[int] = []
    vals: Dict[int, List[str]] = {}
    for e in entries:
        cid = int(e["column_id"])
        if cid not in vals:
            order.append(cid)
            vals[cid] = []
        w = _value_words(e.get("value"))
        if w not in vals[cid]:
            vals[cid].append(w)
    return "; ".join(f"{_label_of(cols, cid)} = {' or '.join(vals[cid])}" for cid in order)


def tile_filter(tile: dict, links: Sequence[Dict[str, Any]], canvas: Any, cols: Dict[int, dict]
                ) -> Tuple[Optional[LinkFilter], str]:
    """``(filter, words)`` for one tile of an export; ``(None, '')`` when no
    link applies to it.  The filter is a :class:`LinkFilter`: pass its
    :func:`plain_slicers` as ``slicers`` AND its :func:`path_steps` as
    ``path_filters``."""
    entries = links_for_tile(tile, links, canvas)
    if not entries:
        return None, ""
    return link_filter(entries, cols), link_words(entries, cols)
