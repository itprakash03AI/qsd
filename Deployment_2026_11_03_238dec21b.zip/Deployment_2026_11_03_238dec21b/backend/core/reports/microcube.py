"""Server-side microcube queries over business-report result artifacts.

Design rule (2026-08-08 reporting rewire, Phase 1): a drill, banding,
running-calculation or slicer gesture must NEVER mean "ship every detail row
to the browser so JavaScript can group it".  The client-side engine's
``fetchAllRows`` sweep is the root of the 250-300K-row ceiling: a 5M-row
drill report is a deterministic tab crash and an N²/10⁴ OFFSET scan-storm on
the pod (drill-down audit §2).  Here every gesture is ONE bounded DuckDB
query over the already-materialised ``{execution_id}.parquet`` artifact —
the same engine-pushed posture as ``core.reports.pagination``, which this
module deliberately mirrors in every convention.  Measured on 5M rows × 30
cols at ``threads=4, memory_limit='2GB'``: drill ≈110ms, GROUPING SETS
banding ≈168ms, window-function running calcs ≈40ms, DISTINCT slicer ≈7ms.

All functions are synchronous by design — API endpoints call them via
``asyncio.to_thread`` so the event loop stays free (same contract, and same
starved-``/health`` incident behind it, as ``paginate_result``).  There is
deliberately NO pyarrow fallback for grouped queries: if DuckDB cannot open
the artifact the caller gets the failure loudly and the viewer falls back to
client mode for small results — fail-open on availability, never on numbers.

Correctness GATES (fail loud — these are the defects being fixed, audit §5):

* **Non-additive measures.**  SUM/MIN/MAX re-aggregate correctly from an
  already-grouped artifact; COUNT, AVG and COUNT DISTINCT do NOT — the
  browser engine silently produced avg-of-avgs, count-of-groups and
  distinct-of-distinct-counts (audit D2).  :func:`measure_eligibility` is
  the per-measure predicate; an ineligible measure raises
  :class:`NonAdditiveMeasureError` with a reason the caller can surface
  (the BusinessObjects ``#TOREFRESH`` posture).  One industry-lawful
  exception: COUNT DISTINCT over a grouped artifact IS exact when the
  distinct key is itself one of the artifact's grouping columns (Power BI's
  DISTINCTCOUNT rule — distinctness is preserved by the grain).
* **NULL dimension values** survive grouping and filtering distinctly from
  ``''`` and from the literal text ``'null'`` (audit D5 documents all three
  collisions in the client engine).  A path step whose value is ``None``
  filters with ``IS NULL``; values bind as typed parameters, never
  stringified.
* **Banding rows are tagged by ``GROUPING_ID``**, never inferred from NULLs
  — a genuine NULL dimension value is indistinguishable from a rolled-up
  subtotal cell by looking at the row alone.
* **Identifier safety.**  Every identifier (dimension, measure, filter,
  slicer, partition) is validated against the artifact's actual schema via
  ``DESCRIBE`` before interpolation — exactly as ``pagination.py`` validates
  its sort column.  Unknown identifiers raise ``ValueError`` (an unknown
  *sort* column is ignored, mirroring ``pagination.py``).  Filter/slicer
  VALUES bind as DuckDB prepared-statement parameters.

Resource posture (CAPS — throttle, never refuse): ``threads`` /
``memory_limit`` bound the connection (invalid values fall back to the
measured defaults with a warning, never an error) and a writable
``temp_directory`` is provided so a memory-capped query SPILLS instead of
failing; ``page`` / ``page_size`` chunk large grouped outputs through the
same LIMIT/OFFSET mechanism as ``read_artifact_page``.

Engine-parity shims (the client engine's numeric semantics, matched so a
report does not change its numbers when it crosses the client/server
threshold — ``useReportEngine.ts``):

* numeric aggregation coerces via ``TRY_CAST(col AS DOUBLE)`` so unparseable
  strings are NULL-skipped identically to ``Number(v)``/NaN-skip;
* an aggregate over zero numeric values returns 0, not NULL
  (``aggregateValues`` returns 0 on an empty numeric set);
* ``count_distinct`` excludes NULL **and** empty string for text columns
  (``COUNT(DISTINCT NULLIF(col, ''))``);
* running calcs match ``applyRunningCalculations`` exactly: running sum is
  cumulative over display order (NaN contributes 0), rank is DENSE_RANK
  descending over ``Number(v)||0``, percent-of-total is
  ``ROUND(100*v/total, 2)`` with 0 when the total is not positive, previous
  value is ``LAG`` of ``Number(v)||0`` over display order (NULL on the first
  row of a partition); ``__row_idx`` pins window order to display order.
"""
from __future__ import annotations

import logging
import re
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from core.reports.pagination import _quote_ident, _sql_path

logger = logging.getLogger(__name__)

__all__ = [
    "GRAIN_DETAIL",
    "GRAIN_GROUPED",
    "KNOWN_AGGREGATIONS",
    "NonAdditiveMeasureError",
    "measure_eligibility",
    "read_artifact_drill",
    "read_artifact_bands",
    "read_artifact_running_calcs",
    "read_artifact_slicer_options",
]

# ── Constants ────────────────────────────────────────────────────────────────

GRAIN_DETAIL = "detail"     # artifact rows are source detail rows
GRAIN_GROUPED = "grouped"   # artifact rows are already GROUP BY'd (audit §1.4:
                            # the usual case — measures carried an aggregation)

DEFAULT_THREADS = 4              # the exact settings the reference numbers
DEFAULT_MEMORY_LIMIT = "2GB"     # were measured at (see module docstring)
DEFAULT_DRILL_PAGE_SIZE = 500
DEFAULT_SLICER_LIMIT = 1000      # CAP: page further options via offset

KNOWN_AGGREGATIONS = ("sum", "avg", "count", "min", "max", "count_distinct")
_REAGGREGABLE_FROM_GROUPED = frozenset({"sum", "min", "max"})
_CALC_TYPES = ("running_sum", "rank", "percent_of_total", "previous_value")

_MEMORY_LIMIT_RE = re.compile(r"^\s*\d+(\.\d+)?\s*([KMGT]I?B|B)?\s*$", re.IGNORECASE)
_TEXT_TYPE_MARKERS = ("CHAR", "STRING", "TEXT")


# ── Non-additive measure gate (correctness GATE, fails loud) ─────────────────

class NonAdditiveMeasureError(ValueError):
    """A requested measure cannot be computed correctly from this artifact.

    Raised INSTEAD of silently returning a wrong number (avg-of-avgs,
    count-of-groups, distinct-of-distinct-counts — the exact defects the
    drill audit found in the client engine).  ``refused`` maps each refused
    measure column to a human-readable reason the caller can surface.
    """

    def __init__(self, refused: Dict[str, str]):
        self.refused = dict(refused)
        detail = "; ".join(f"{col}: {reason}" for col, reason in self.refused.items())
        super().__init__(f"non-additive measure(s) refused — {detail}")


def measure_eligibility(aggregation: Optional[str], *, artifact_grain: str,
                        column: Optional[str] = None,
                        artifact_group_columns: Optional[Sequence[str]] = None,
                        ) -> Tuple[bool, Optional[str]]:
    """Per-measure predicate: can ``aggregation`` be computed CORRECTLY here?

    Returns ``(True, None)`` when the measure is exact, or ``(False, reason)``
    when it must be refused.  Rules:

    * detail-grain artifact → every known aggregation is exact (the query
      re-aggregates real detail rows at the requested level);
    * grouped artifact → only SUM/MIN/MAX compose; COUNT would count groups,
      AVG would be an unweighted avg-of-avgs, COUNT DISTINCT does not compose
      across groups — EXCEPT when the distinct key is itself one of the
      artifact's grouping columns (distinctness preserved by the grain);
    * unknown aggregation → refused (UNKNOWN = UNSAFE, and nothing unknown is
      ever interpolated into SQL).

    ``aggregation`` may be ``None``/blank — treated as ``'sum'``, matching
    the client engine's ``getAggType`` default.
    """
    if artifact_grain not in (GRAIN_DETAIL, GRAIN_GROUPED):
        raise ValueError(
            f"unknown artifact_grain {artifact_grain!r} — expected "
            f"{GRAIN_DETAIL!r} or {GRAIN_GROUPED!r} (UNKNOWN = UNSAFE)")
    agg = str(aggregation or "sum").strip().lower()
    if agg not in KNOWN_AGGREGATIONS:
        return False, (f"unknown aggregation {agg!r} — refused rather than "
                       f"guessed (known: {', '.join(KNOWN_AGGREGATIONS)})")
    if artifact_grain == GRAIN_DETAIL:
        return True, None
    if agg in _REAGGREGABLE_FROM_GROUPED:
        return True, None
    if agg == "count":
        return False, ("COUNT over an already-grouped artifact counts groups, "
                       "not underlying rows — recompute from detail (source)")
    if agg == "avg":
        return False, ("AVG cannot be re-aggregated from an already-grouped "
                       "artifact — the result would be an unweighted average "
                       "of group averages (avg-of-avgs); recompute from "
                       "detail, or store SUM+COUNT pairs (Tier 2)")
    # count_distinct
    if column is not None and artifact_group_columns is not None \
            and column in set(artifact_group_columns):
        return True, None   # Power BI DISTINCTCOUNT rule: key is a grain column
    return False, ("COUNT DISTINCT does not compose across groups "
                   "(distinct-of-distinct-counts) — eligible over a grouped "
                   "artifact only when the distinct key is itself one of the "
                   "artifact's grouping columns; otherwise recompute from "
                   "detail (source)")


def _gate_measures(measures: Sequence[Dict[str, Any]], artifact_grain: str,
                   artifact_group_columns: Optional[Sequence[str]],
                   ) -> List[Tuple[str, str]]:
    """Validate every requested measure through :func:`measure_eligibility`.

    Returns ``[(column, aggregation), ...]`` for eligible measures; raises
    :class:`NonAdditiveMeasureError` listing EVERY ineligible one (a partial
    silent result is the defect being fixed).
    """
    refused: Dict[str, str] = {}
    gated: List[Tuple[str, str]] = []
    for m in measures or []:
        col = m.get("column")
        if not col or not isinstance(col, str):
            raise ValueError(f"measure requires a string 'column' key, got {m!r}")
        agg = str(m.get("aggregation") or "sum").strip().lower()
        ok, reason = measure_eligibility(
            agg, artifact_grain=artifact_grain, column=col,
            artifact_group_columns=artifact_group_columns)
        if not ok:
            refused[col] = reason or "ineligible"
        else:
            gated.append((col, agg))
    if refused:
        raise NonAdditiveMeasureError(refused)
    aliases = [measure_alias(m) for m in measures or []]
    if len(set(aliases)) != len(aliases):
        raise ValueError(f"duplicate measure column(s) in request: {aliases!r}")
    return gated


_ALIAS_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")


def measure_alias(m: Dict[str, Any]) -> str:
    """The OUTPUT name of one requested measure (2026-10-26, the report
    canvas): its ``alias`` when given -- so one column can be shown two ways
    in one level, e.g. the sum AND the largest of Amount -- else its column.
    An alias is a plain identifier, validated, never interpolated raw."""
    alias = m.get("alias")
    if alias in (None, ""):
        return str(m.get("column") or "")
    if not isinstance(alias, str) or not _ALIAS_RE.match(alias):
        raise ValueError(f"measure alias {alias!r} must be letters, digits and _ "
                         f"(at most 64, not starting with a digit)")
    return alias


# ── Connection / schema helpers ──────────────────────────────────────────────

def _connect(threads: Any, memory_limit: Any):
    """Fresh DuckDB connection with a bounded resource posture.

    Resource caps THROTTLE, never refuse: invalid settings fall back to the
    measured defaults with a warning, and a writable ``temp_directory`` lets
    a memory-capped query spill instead of erroring (the
    ``bug_duckdb_temp_dir_readonly_cwd`` lesson — cwd may be read-only in a
    non-root container).
    """
    import duckdb

    con = duckdb.connect()
    try:
        con.execute(f"SET threads={max(1, int(threads))}")
    except Exception as exc:
        logger.warning("microcube: SET threads=%r failed (%s) — engine default kept",
                       threads, exc)
    ml = str(memory_limit or DEFAULT_MEMORY_LIMIT).strip()
    if not _MEMORY_LIMIT_RE.match(ml):
        logger.warning("microcube: invalid memory_limit %r — using %s",
                       memory_limit, DEFAULT_MEMORY_LIMIT)
        ml = DEFAULT_MEMORY_LIMIT
    try:
        con.execute(f"SET memory_limit='{ml}'")
    except Exception as exc:
        logger.warning("microcube: SET memory_limit=%r failed (%s) — engine default kept",
                       ml, exc)
    try:
        spill = Path(tempfile.gettempdir()) / "qs_microcube_spill"
        spill.mkdir(parents=True, exist_ok=True)
        con.execute(f"SET temp_directory={_sql_path(spill)}")
    except Exception as exc:   # spill dir is an optimisation — never fatal
        logger.warning("microcube: could not set temp_directory (%s)", exc)
    return con


class ArtifactNotReady(Exception):
    """The result cannot be read as ONE finished dataset (2026-10-26): it is
    still being built, gone, or held where this pod cannot read it.  A plain
    sentence for the person; never a partial answer presented as the whole."""


def _artifact_src(path: Path) -> str:
    """``read_parquet(...)``/``read_csv_auto(...)`` source clause (mirrors
    ``pagination._duckdb_page``).

    2026-10-26: a result still held as PARTS (a partitioned build before its
    parts are merged into one file) is read as the union of its parts -- but
    only from a COMPLETE manifest whose parts are all on this pod; a partial
    build is refused (``ArtifactNotReady``), because a total over the rows
    produced so far would look like the total."""
    path = Path(path)
    if path.exists():
        if path.suffix.lower() in (".parquet", ".pq"):
            return f"read_parquet({_sql_path(path)})"
        return f"read_csv_auto({_sql_path(path)})"
    from core.reports.pagination import parts_dir_for
    from core.feed.parts_manifest import PartsManifestError, is_parts_dir, load_manifest
    parts = parts_dir_for(path)
    if not is_parts_dir(parts):
        raise ArtifactNotReady("This run's result file is no longer available. Run the report again.")
    try:
        manifest, _src = load_manifest(parts)
    except PartsManifestError:
        raise ArtifactNotReady("This run's result is still being built. Wait for it to finish, then try again.")
    files = [parts / p.name for p in manifest.parts if p.location == "local"]
    if len(files) != len(manifest.parts):
        raise ArtifactNotReady("Part of this run's result is stored where this server cannot read it. Run the report again.")
    if not files:
        raise ArtifactNotReady("This run produced no rows.")
    return ("read_parquet([" + ", ".join(_sql_path(f) for f in files)
            + "], union_by_name=true)")


def _describe(con, src: str) -> Dict[str, str]:
    """Artifact schema as ``{column_name: column_type}`` — the ground truth
    every requested identifier is validated against."""
    return {r[0]: r[1] for r in con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()}


def _require_columns(names: Sequence[Optional[str]], schema: Dict[str, str],
                     what: str) -> None:
    """Identifier GATE: every name must exist in the artifact schema exactly.

    Column names come from user-defined semantic models — anything not in the
    schema is rejected before it can reach an interpolated position, so
    identifier injection is structurally impossible (same posture as
    ``pagination.py``'s sort-column validation)."""
    unknown = [n for n in names if n not in schema]
    if unknown:
        raise ValueError(f"{what} column(s) not in artifact schema: {unknown!r}")


def _is_text_type(coltype: str) -> bool:
    t = (coltype or "").upper()
    return any(marker in t for marker in _TEXT_TYPE_MARKERS)


def _is_temporal_type(coltype: str) -> bool:
    t = (coltype or "").upper()
    return any(marker in t for marker in ("DATE", "TIME", "INTERVAL"))


def _is_exact_numeric_type(coltype: str) -> bool:
    t = (coltype or "").upper()
    if _is_temporal_type(t):
        return False
    return t.startswith(("DECIMAL", "NUMERIC")) or t in (
        "TINYINT", "SMALLINT", "INTEGER", "BIGINT", "HUGEINT", "UTINYINT",
        "USMALLINT", "UINTEGER", "UBIGINT", "UHUGEINT", "INT", "INT2", "INT4", "INT8")


# ── SQL fragment builders ────────────────────────────────────────────────────

def _agg_expr(column: str, agg: str, schema: Dict[str, str]) -> str:
    """Aggregate SQL for one measure, with the client-engine parity shims
    (TRY_CAST numeric coercion; empty-set → 0; count_distinct excludes '')."""
    qi = _quote_ident(column)
    if agg == "count_distinct":
        inner = f"NULLIF({qi}, '')" if _is_text_type(schema.get(column, "")) else qi
        return f"COUNT(DISTINCT {inner})"
    num = f"TRY_CAST({qi} AS DOUBLE)"
    if agg == "count":
        return f"COUNT({num})"
    fn = {"sum": "SUM", "avg": "AVG", "min": "MIN", "max": "MAX"}[agg]
    coltype = (schema.get(column, "") or "").upper()
    # 2026-10-26 (the report canvas): a DECIMAL / integer column is added up
    # AS ITSELF -- through DOUBLE a finance total drifts in the cents -- and
    # MIN / MAX of a DATE keep the date (TRY_CAST made the latest business
    # date NULL, then 0); over no rows they are NULL, "no value".  A TEXT
    # column keeps the DOUBLE coercion for every aggregation: a measure stored
    # as text (' 2 ', '') is read as the number the client engine reads
    # (test_report_engine_parity pins it).
    if agg in ("min", "max") and (_is_exact_numeric_type(coltype)
                                  or _is_temporal_type(coltype)):
        return f"{fn}({qi})"
    if agg in ("sum", "avg") and _is_exact_numeric_type(coltype):
        return f"COALESCE({fn}({qi}), 0)"
    return f"COALESCE({fn}({num}), 0)"


def _any_of_clause(paths: Any, schema: Dict[str, str]) -> Tuple[str, List[Any]]:
    """``((a = ? AND b = ?) OR (a = ? AND b IS NULL))`` for a list of paths.
    An empty list, or a path with no steps, is refused: a filter that cannot
    be rendered must never become "no filter" (it would return MORE rows)."""
    if not isinstance(paths, (list, tuple)) or not paths:
        raise ValueError("A linked path filter has no paths.")
    ors: List[str] = []
    params: List[Any] = []
    for path in paths:
        if not isinstance(path, (list, tuple)) or not path:
            raise ValueError("A linked path filter has a path with no steps.")
        ands: List[str] = []
        for st in path:
            col = st.get("column") if isinstance(st, dict) else None
            if not col:
                raise ValueError("A linked path filter has a step that names no column.")
            _require_columns([col], schema, "linked path filter")
            if st.get("value") is None:
                ands.append(f"{_quote_ident(col)} IS NULL")
            else:
                ands.append(f"{_quote_ident(col)} = ?")
                params.append(st["value"])
        ors.append("(" + " AND ".join(ands) + ")")
    return "(" + " OR ".join(ors) + ")", params


def _build_where(path_filters: Optional[Sequence[Dict[str, Any]]],
                 slicers: Optional[Dict[str, Sequence[Any]]],
                 schema: Dict[str, str]) -> Tuple[str, List[Any]]:
    """WHERE clause for a drill path + slicer selections.

    NULL discipline (audit D5): a path/slicer value of ``None`` becomes
    ``IS NULL`` — never ``= 'null'`` — and every non-NULL value binds as a
    typed prepared-statement parameter, so NULL, ``''`` and the literal text
    ``'null'`` stay three distinct things end to end.
    """
    clauses: List[str] = []
    params: List[Any] = []
    for step in path_filters or []:
        if "any_of" in step and step.get("column") is None:
            # 2026-10-30 (linked canvas tiles): "this path OR that path", each
            # path ALL of its steps -- one clause, never widened to per-field
            # INs (that would also let a mixed path through)
            clause, cparams = _any_of_clause(step.get("any_of"), schema)
            clauses.append(clause)
            params.extend(cparams)
            continue
        col = step.get("column")
        _require_columns([col], schema, "drill-path filter")
        if step.get("value") is None:
            clauses.append(f"{_quote_ident(col)} IS NULL")
        else:
            clauses.append(f"{_quote_ident(col)} = ?")
            params.append(step["value"])
    for col, vals in (slicers or {}).items():
        _require_columns([col], schema, "slicer")
        if not vals:
            continue
        non_null = [v for v in vals if v is not None]
        parts: List[str] = []
        if non_null:
            marks = ", ".join("?" for _ in non_null)
            parts.append(f"{_quote_ident(col)} IN ({marks})")
            params.extend(non_null)
        if len(non_null) != len(vals):
            parts.append(f"{_quote_ident(col)} IS NULL")
        clauses.append("(" + " OR ".join(parts) + ")")
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    return where, params


def _order_clause(dimensions: Sequence[str], sort_column: Optional[str],
                  sort_direction: Optional[str], sortable: Sequence[str],
                  sort_abs: bool = False) -> str:
    """``ORDER BY ...`` (no leading space) or ``''``.

    An unknown ``sort_column`` is IGNORED — mirroring ``pagination.py:57``
    (sort is presentation, not correctness) — and the remaining dimensions
    always follow as tiebreakers so pagination is deterministic (audit D10:
    never lean on insertion order for cross-page consistency).
    """
    parts: List[str] = []
    if sort_column and sort_column in set(sortable):
        direction = "DESC" if (sort_direction or "asc").lower() == "desc" else "ASC"
        key = f"ABS({_quote_ident(sort_column)})" if sort_abs else _quote_ident(sort_column)
        parts.append(f"{key} {direction} NULLS LAST")
    for dim in dimensions:
        if dim != sort_column:
            parts.append(f"{_quote_ident(dim)} ASC NULLS LAST")
    return ("ORDER BY " + ", ".join(parts)) if parts else ""


def _limit_clause(page: Any, page_size: Optional[Any]) -> str:
    """LIMIT/OFFSET for grouped output — a CAP that chunks, never refuses.
    ``page_size`` of ``None``/``0`` means the full grouped result."""
    if page_size is None or int(page_size) <= 0:
        return ""
    eff = int(page_size)
    offset = (max(1, int(page)) - 1) * eff
    return f" LIMIT {eff} OFFSET {offset}"


def _check_alias_collisions(dimensions: Sequence[str],
                            aliases: Sequence[str]) -> None:
    dup = set(dimensions) & set(aliases)
    if dup:
        raise ValueError(
            f"measure/output alias collides with dimension column(s): {sorted(dup)!r}")


def _page_contract(records: List[Dict[str, Any]], columns: List[str],
                   total: int, page: Any, page_size: Optional[Any]) -> Dict[str, Any]:
    """The exact page contract of ``pagination.paginate_result`` — callers
    compose additive keys on top (additive only, never fabricate)."""
    from core.json_utils import sanitize_for_json

    eff = int(page_size) if (page_size is not None and int(page_size) > 0) else 0
    total_pages = (max(1, (total + eff - 1) // eff) if eff > 0 else 1)
    return {
        "rows": sanitize_for_json(records),
        "columns": columns,
        "total_rows": total,
        "page": max(1, int(page)) if eff > 0 else 1,
        "page_size": eff if eff > 0 else total,
        "total_pages": total_pages,
    }


def _fetch_records(con, sql: str, params: List[Any],
                   ) -> Tuple[List[Dict[str, Any]], List[str]]:
    cur = con.execute(sql, params)
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, row)) for row in cur.fetchall()], cols


def _grouped_total(con, src: str, where: str, params: List[Any],
                   dimensions: Sequence[str]) -> int:
    """COUNT of groups at this level (cheap — same GROUP BY, no payload)."""
    if not dimensions:
        return 1   # pure-aggregate query: exactly one row
    dims_sql = ", ".join(_quote_ident(d) for d in dimensions)
    sql = (f"SELECT COUNT(*) FROM (SELECT {dims_sql} FROM {src}{where} "
           f"GROUP BY {dims_sql}) _g")
    return int(con.execute(sql, params).fetchone()[0])


def _validate_level_request(dimensions: Sequence[str],
                            gated: Sequence[Tuple[str, str]]) -> None:
    if not dimensions and not gated:
        raise ValueError("nothing to select: at least one dimension or measure required")
    if len(set(dimensions)) != len(dimensions):
        raise ValueError(f"duplicate dimension column(s): {list(dimensions)!r}")
    _check_alias_collisions(dimensions, [c for c, _ in gated])


# ── Public capability 1: drill ───────────────────────────────────────────────

#: values DERIVED from two of a level's measures (2026-11-03): "difference" = a - b (a side
#: with no value counts as 0 -- a break where one side is missing IS a break), "ratio" =
#: 100 * a / b as a percentage (no value when b is 0 or missing -- never a made-up number)
DERIVED_OPS = ("difference", "ratio")
MAX_DERIVED = 4


def _derived_exprs(derived: Optional[Sequence[Dict[str, Any]]], aliases: Sequence[str],
                   taken: Sequence[str]) -> Tuple[List[str], List[str], List[str]]:
    """(select expressions, their names, the names whose rows must not be zero) -- refused in words."""
    exprs: List[str] = []
    names: List[str] = []
    nonzero: List[str] = []
    if len(derived or []) > MAX_DERIVED:
        raise ValueError(f"at most {MAX_DERIVED} derived values")
    for d in derived or []:
        name = str(d.get("alias") or "").strip()
        op, a, b = d.get("op"), d.get("a"), d.get("b")
        if not name or name in taken or name in names:
            raise ValueError(f"a derived value needs its own name (got {name!r})")
        if op not in DERIVED_OPS:
            raise ValueError(f"unknown derived op {op!r} -- expected one of {DERIVED_OPS}")
        if a not in aliases or b not in aliases:
            raise ValueError(f"a derived value reads two measures of this level (have {list(aliases)!r})")
        qa, qb = _quote_ident(a), _quote_ident(b)
        if op == "difference":
            expr = f"(COALESCE({qa}, 0) - COALESCE({qb}, 0))"
        else:
            expr = (f"(CASE WHEN {qb} IS NULL OR {qb} = 0 THEN NULL "
                    f"ELSE ROUND(100.0 * CAST({qa} AS DOUBLE) / CAST({qb} AS DOUBLE), 2) END)")
        exprs.append(f"{expr} AS {_quote_ident(name)}")
        names.append(name)
        if d.get("nonzero"):
            nonzero.append(name)
    return exprs, names, nonzero


def read_artifact_drill(path: Path, *,
                        dimensions: Sequence[str],
                        measures: Sequence[Dict[str, Any]],
                        path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                        slicers: Optional[Dict[str, Sequence[Any]]] = None,
                        sort_column: Optional[str] = None,
                        sort_direction: Optional[str] = None,
                        page: int = 1,
                        page_size: Optional[int] = DEFAULT_DRILL_PAGE_SIZE,
                        artifact_grain: str = GRAIN_GROUPED,
                        artifact_group_columns: Optional[Sequence[str]] = None,
                        threads: int = DEFAULT_THREADS,
                        memory_limit: str = DEFAULT_MEMORY_LIMIT,
                        derived: Optional[Sequence[Dict[str, Any]]] = None,
                        sort_abs: bool = False,
                        ) -> Dict[str, Any]:
    """One drill level: GROUP BY the level's dimensions over the artifact.

    ``SELECT <dims>, <aggs> FROM read_parquet(...) WHERE <path + slicers>
    GROUP BY <dims> ORDER BY ... LIMIT/OFFSET`` — returns the
    ``pagination.paginate_result`` page contract plus additive keys
    ``dimensions`` / ``measures`` / ``grain``.

    ``measures`` is ``[{"column": name, "aggregation": "sum"|...}, ...]``
    (blank aggregation defaults to ``sum``, matching the client engine).
    ``path_filters`` is the clicked drill path as
    ``[{"column": name, "value": v}, ...]`` — ``value=None`` filters
    ``IS NULL``.  ``artifact_grain`` declares whether the artifact holds
    detail rows or already-grouped rows; the fail-closed default is
    ``grouped`` (refuses more), and callers that KNOW the artifact is detail
    pass :data:`GRAIN_DETAIL` to unlock exact AVG/COUNT/COUNT DISTINCT.

    Synchronous by design — call via ``asyncio.to_thread``.

    ``derived`` (2026-11-03): ``[{"alias", "op": "difference"|"ratio", "a", "b",
    "nonzero"?}]`` -- values worked out from two of THIS level's measure aliases
    after they are added up (``DERIVED_OPS``).  A ``nonzero`` one keeps only the
    rows where it is not zero (the breaks of a reconciliation) and the total
    counts those rows.  ``sort_column`` may name one; ``sort_abs`` orders by its
    size whatever its sign (the largest break first).
    """
    path = Path(path)
    dimensions = list(dimensions)
    gated = _gate_measures(measures, artifact_grain, artifact_group_columns)
    _validate_level_request(dimensions, gated)

    con = _connect(threads, memory_limit)
    try:
        src = _artifact_src(path)
        schema = _describe(con, src)
        _require_columns(dimensions, schema, "drill dimension")
        _require_columns([c for c, _ in gated], schema, "measure")
        where, params = _build_where(path_filters, slicers, schema)

        aliases = [measure_alias(m) for m in measures or []]
        _check_alias_collisions(dimensions, aliases)
        d_exprs, d_names, nonzero = _derived_exprs(derived, aliases, list(dimensions) + aliases)
        select_items = [_quote_ident(d) for d in dimensions]
        select_items += [f"{_agg_expr(c, a, schema)} AS {_quote_ident(al)}"
                        for (c, a), al in zip(gated, aliases)]
        group_sql = (" GROUP BY " + ", ".join(_quote_ident(d) for d in dimensions)
                     ) if dimensions else ""
        order_by = _order_clause(dimensions, sort_column, sort_direction,
                                 dimensions + aliases + d_names, sort_abs=sort_abs)
        level_sql = f"SELECT {', '.join(select_items)} FROM {src}{where}{group_sql}"
        if d_names:
            keep = (" WHERE " + " AND ".join(f"{_quote_ident(n)} <> 0" for n in nonzero)) if nonzero else ""
            level_sql = (f"SELECT * FROM (SELECT _lvl.*, {', '.join(d_exprs)} "
                         f"FROM ({level_sql}) _lvl) _dv{keep}")
        if nonzero:
            total = int(con.execute(f"SELECT COUNT(*) FROM ({level_sql}) _n", params).fetchone()[0])
        else:
            total = _grouped_total(con, src, where, params, dimensions)
        sql = (level_sql
               + (f" {order_by}" if order_by else "")
               + _limit_clause(page, page_size))
        records, cols = _fetch_records(con, sql, params)
    finally:
        con.close()

    out = _page_contract(records, cols, total, page, page_size)
    out["dimensions"] = dimensions
    out["measures"] = [{"column": c, "aggregation": a, "alias": al}
                       for (c, a), al in zip(gated, aliases)]
    if d_names:
        out["derived"] = d_names
    out["grain"] = {"artifact_grain": artifact_grain,
                    "filters": list(path_filters or [])}
    return out


# ── Public capability 2: banded (GROUPING SETS, one pass) ────────────────────

def read_artifact_bands(path: Path, *,
                        section_columns: Sequence[str],
                        group_columns: Sequence[str],
                        measures: Sequence[Dict[str, Any]],
                        path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                        slicers: Optional[Dict[str, Sequence[Any]]] = None,
                        page: int = 1,
                        page_size: Optional[int] = None,
                        artifact_grain: str = GRAIN_GROUPED,
                        artifact_group_columns: Optional[Sequence[str]] = None,
                        threads: int = DEFAULT_THREADS,
                        memory_limit: str = DEFAULT_MEMORY_LIMIT,
                        ) -> Dict[str, Any]:
    """Section subtotals AND the grand total in ONE GROUPING SETS pass.

    ``group_columns`` is the data-row grain (what a data row displays);
    ``section_columns`` is the ordered nesting of section breaks and must be
    a subset of ``group_columns``.  Emitted sets: the full data grain, one
    subtotal set per section nesting prefix (deepest first), and the grand
    total ``()``.

    Every returned row is tagged ``_rowType`` (``'data' | 'subtotal' |
    'grand_total'``) decoded from ``GROUPING_ID`` — NEVER inferred from NULL
    cells, because a genuine NULL dimension value is indistinguishable from
    a rolled-up cell that way (correctness point, not style).  Subtotal rows
    also carry ``_sectionLevel`` (0-based nesting depth) and
    ``_sectionValue`` (the section's own value, raw — ``None`` stays
    ``None``), mapping 1:1 onto the client's ``BandedRow`` shape.  Rolled-up
    dimension cells on subtotal/grand rows are NULL in the payload —
    consumers must band by ``_rowType``, never by NULL-ness.

    Rows are ordered header-band style: each section's data rows, then its
    subtotal, sections in section-value order (NULLS LAST), grand total
    last.  ``_count`` carries ``COUNT(*)`` per band (the client's
    ``show_count`` / ``_sectionCount``).  Synchronous — ``asyncio.to_thread``.
    """
    path = Path(path)
    group_columns = list(group_columns)
    section_columns = list(section_columns or [])
    if not group_columns:
        raise ValueError("banded query requires at least one group column")
    missing = [s for s in section_columns if s not in group_columns]
    if missing:
        raise ValueError(f"section column(s) must be among group_columns: {missing!r}")
    if len(set(group_columns)) != len(group_columns):
        raise ValueError(f"duplicate group column(s): {group_columns!r}")
    gated = _gate_measures(measures, artifact_grain, artifact_group_columns)
    _check_alias_collisions(group_columns, [c for c, _ in gated] + ["_count"])

    n = len(group_columns)

    def _mask_of(present: Sequence[str]) -> int:
        present_set = set(present)
        mask = 0
        for i, col in enumerate(group_columns):
            if col not in present_set:
                mask |= 1 << (n - 1 - i)   # first GROUPING_ID arg = MSB
        return mask

    # Grouping sets + the GROUPING_ID→row-tag map (the anti-NULL-inference gate)
    tags: Dict[int, Dict[str, Any]] = {}
    sets_sql: List[str] = []

    def _add_set(cols: Tuple[str, ...], tag: Dict[str, Any]) -> None:
        mask = _mask_of(cols)
        if mask in tags:    # degenerate overlap (e.g. sections == full grain)
            return          # keep the FINEST meaning, added first
        tags[mask] = tag
        sets_sql.append("(" + ", ".join(_quote_ident(c) for c in cols) + ")")

    _add_set(tuple(group_columns), {"_rowType": "data"})
    for k in range(len(section_columns), 0, -1):
        _add_set(tuple(section_columns[:k]),
                 {"_rowType": "subtotal", "_sectionLevel": k - 1})
    _add_set((), {"_rowType": "grand_total"})

    order_cols = section_columns + [c for c in group_columns
                                    if c not in section_columns]

    con = _connect(threads, memory_limit)
    try:
        src = _artifact_src(path)
        schema = _describe(con, src)
        _require_columns(group_columns, schema, "group")
        _require_columns([c for c, _ in gated], schema, "measure")
        where, params = _build_where(path_filters, slicers, schema)

        gid = "GROUPING_ID(" + ", ".join(_quote_ident(c) for c in group_columns) + ")"
        select_items = [_quote_ident(c) for c in group_columns]
        select_items.append(f"{gid} AS __gid")
        for i, c in enumerate(order_cols):
            select_items.append(f"GROUPING({_quote_ident(c)}) AS __o{i}")
        select_items.append('COUNT(*) AS "_count"')
        select_items += [f"{_agg_expr(c, a, schema)} AS {_quote_ident(c)}"
                        for c, a in gated]
        group_sql = " GROUP BY GROUPING SETS (" + ", ".join(sets_sql) + ")"

        count_sql = (f"SELECT COUNT(*) FROM (SELECT "
                     f"{', '.join(_quote_ident(c) for c in group_columns)} "
                     f"FROM {src}{where}{group_sql}) _g")
        total = int(con.execute(count_sql, params).fetchone()[0])

        # Band order: rolled-up flag before value per column, so each
        # section's data rows precede its subtotal and the grand total is
        # last — without ever comparing NULL markers to genuine NULL values.
        order_terms: List[str] = []
        for i, c in enumerate(order_cols):
            order_terms.append(f"__o{i}")
            order_terms.append(f"{_quote_ident(c)} ASC NULLS LAST")
        sql = (f"SELECT {', '.join(select_items)} FROM {src}{where}{group_sql}"
               f" ORDER BY {', '.join(order_terms)}"
               + _limit_clause(page, page_size))
        raw, _cols = _fetch_records(con, sql, params)
    finally:
        con.close()

    internal = {f"__o{i}" for i in range(len(order_cols))}
    records: List[Dict[str, Any]] = []
    for row in raw:
        mask = int(row.pop("__gid"))
        for key in internal:
            row.pop(key, None)
        tag = tags.get(mask)
        if tag is None:   # structurally impossible — fail loud, never mislabel
            raise ValueError(f"unexpected GROUPING_ID {mask} in banded result")
        row.update(tag)
        if tag["_rowType"] == "subtotal":
            row["_sectionValue"] = row.get(section_columns[tag["_sectionLevel"]])
        records.append(row)

    out_columns = group_columns + ["_count"] + [c for c, _ in gated]
    out = _page_contract(records, out_columns, total, page, page_size)
    out["section_columns"] = section_columns
    out["group_columns"] = group_columns
    out["measures"] = [{"column": c, "aggregation": a} for c, a in gated]
    return out


# ── Public capability 3: running calculations (window functions) ─────────────

def read_artifact_running_calcs(path: Path, *,
                                dimensions: Sequence[str],
                                measures: Sequence[Dict[str, Any]],
                                calcs: Sequence[Dict[str, Any]],
                                path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                                slicers: Optional[Dict[str, Sequence[Any]]] = None,
                                sort_column: Optional[str] = None,
                                sort_direction: Optional[str] = None,
                                page: int = 1,
                                page_size: Optional[int] = None,
                                artifact_grain: str = GRAIN_GROUPED,
                                artifact_group_columns: Optional[Sequence[str]] = None,
                                threads: int = DEFAULT_THREADS,
                                memory_limit: str = DEFAULT_MEMORY_LIMIT,
                                ) -> Dict[str, Any]:
    """Window-function running calcs over an aggregated level.

    ``calcs`` entries mirror the client's ``RunningCalcDef``: ``{"name": ...,
    "calc_type": "running_sum"|"rank"|"percent_of_total"|"previous_value",
    "measure": col, "partition": col|None}`` (the client field names
    ``measure_col_name`` / ``partition_col_name`` are accepted too).

    Semantics match ``useReportEngine.ts applyRunningCalculations`` EXACTLY
    (a report must not change its numbers crossing the client/server
    threshold): running sum is cumulative over display order with non-numeric
    values contributing 0; rank is DENSE_RANK over ``Number(v)||0``
    descending; percent-of-total is ``ROUND(100*v/total, 2)`` against the
    partition total (or the whole level when unpartitioned) with 0 when the
    total is not positive; previous value is ``LAG`` of ``Number(v)||0`` and
    NULL on a partition's first row.  ``__row_idx`` (ROW_NUMBER over the
    display ORDER BY) pins window order to the report's display order —
    identical to the client engine's row-sequential semantics.

    Returns the page contract plus ``calculated_columns``.  Synchronous —
    ``asyncio.to_thread``.
    """
    path = Path(path)
    dimensions = list(dimensions)
    gated = _gate_measures(measures, artifact_grain, artifact_group_columns)
    _validate_level_request(dimensions, gated)
    base_columns = dimensions + [c for c, _ in gated]

    norm_calcs: List[Tuple[str, str, str, Optional[str]]] = []
    for c in calcs or []:
        name = str(c.get("name") or "").strip()
        ctype = c.get("calc_type")
        mcol = c.get("measure") or c.get("measure_col_name")
        pcol = c.get("partition") or c.get("partition_col_name")
        if not name:
            raise ValueError("running calc requires a non-empty 'name'")
        if name in base_columns or any(name == n for n, *_ in norm_calcs):
            raise ValueError(f"running calc name {name!r} collides with a result column")
        if ctype not in _CALC_TYPES:
            raise ValueError(f"unknown calc_type {ctype!r} — expected one of {_CALC_TYPES}")
        if mcol not in base_columns:
            raise ValueError(f"running calc measure {mcol!r} is not a column "
                             f"of this level (have {base_columns!r})")
        if pcol is not None and pcol not in base_columns:
            raise ValueError(f"running calc partition {pcol!r} is not a column "
                             f"of this level (have {base_columns!r})")
        norm_calcs.append((name, ctype, mcol, pcol))
    if not norm_calcs:
        raise ValueError("at least one running calc required — use "
                         "read_artifact_drill for a plain level")

    con = _connect(threads, memory_limit)
    try:
        src = _artifact_src(path)
        schema = _describe(con, src)
        _require_columns(dimensions, schema, "drill dimension")
        _require_columns([c for c, _ in gated], schema, "measure")
        where, params = _build_where(path_filters, slicers, schema)

        total = _grouped_total(con, src, where, params, dimensions)

        select_items = [_quote_ident(d) for d in dimensions]
        select_items += [f"{_agg_expr(c, a, schema)} AS {_quote_ident(c)}"
                        for c, a in gated]
        group_sql = (" GROUP BY " + ", ".join(_quote_ident(d) for d in dimensions)
                     ) if dimensions else ""
        base_sql = f"SELECT {', '.join(select_items)} FROM {src}{where}{group_sql}"

        order_by = _order_clause(dimensions, sort_column, sort_direction, base_columns)
        rn = f"ROW_NUMBER() OVER ({order_by})" if order_by else "ROW_NUMBER() OVER ()"
        lvl_sql = f"SELECT base.*, {rn} AS __row_idx FROM ({base_sql}) base"

        calc_exprs: List[str] = []
        # Each percent_of_total's window total is computed ONCE, as a column
        # of an inner layer, and the CASE reads that column.  2026-09-25: the
        # same ``SUM(..) OVER (PARTITION BY ..)`` written twice inside one
        # CASE raises "INTERNAL Error: Failed to bind column reference" on
        # DuckDB 1.5.3 -- the version requirements.txt pins for every image
        # -- and ran on the dev box's 1.5.2, so every partitioned
        # percent-of-total failed in production and passed here.
        total_cols: List[str] = []
        for name, ctype, mcol, pcol in norm_calcs:
            num = f"COALESCE(TRY_CAST({_quote_ident(mcol)} AS DOUBLE), 0)"
            part = f"PARTITION BY {_quote_ident(pcol)} " if pcol else ""
            if ctype == "running_sum":
                expr = (f"SUM({num}) OVER ({part}ORDER BY __row_idx "
                        f"ROWS UNBOUNDED PRECEDING)")
            elif ctype == "rank":
                expr = f"DENSE_RANK() OVER ({part}ORDER BY {num} DESC)"
            elif ctype == "percent_of_total":
                win = f"SUM({num}) OVER ({part.strip()})" if pcol \
                    else f"SUM({num}) OVER ()"
                tot = f"__tot_{len(total_cols)}"
                total_cols.append(f"{win} AS {tot}")
                expr = (f"CASE WHEN {tot} > 0 THEN "
                        f"ROUND(100.0 * {num} / {tot}, 2) ELSE 0 END")
            else:   # previous_value
                expr = f"LAG({num}) OVER ({part}ORDER BY __row_idx)"
            calc_exprs.append(f"{expr} AS {_quote_ident(name)}")

        if total_cols:
            lvl_sql = f"SELECT l0.*, {', '.join(total_cols)} FROM ({lvl_sql}) l0"
            keep = ("lvl.* EXCLUDE ("
                    + ", ".join(f"__tot_{i}" for i in range(len(total_cols))) + ")")
        else:
            keep = "lvl.*"
        sql = (f"SELECT {keep}, {', '.join(calc_exprs)} FROM ({lvl_sql}) lvl "
               f"ORDER BY __row_idx" + _limit_clause(page, page_size))
        records, _cols = _fetch_records(con, sql, params)
    finally:
        con.close()

    for row in records:
        row.pop("__row_idx", None)
    calc_names = [name for name, *_ in norm_calcs]
    out = _page_contract(records, base_columns + calc_names, total, page, page_size)
    out["dimensions"] = dimensions
    out["measures"] = [{"column": c, "aggregation": a} for c, a in gated]
    out["calculated_columns"] = calc_names
    return out


# ── Public capability 4: slicer options ──────────────────────────────────────

def read_artifact_slicer_options(path: Path, column: str, *,
                                 limit: Optional[int] = DEFAULT_SLICER_LIMIT,
                                 offset: int = 0,
                                 path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                                 threads: int = DEFAULT_THREADS,
                                 memory_limit: str = DEFAULT_MEMORY_LIMIT,
                                 ) -> Dict[str, Any]:
    """DISTINCT option list for one slicer column — never scanned in Python.

    ``SELECT DISTINCT col FROM read_parquet(...) WHERE col IS NOT NULL
    ORDER BY col LIMIT n OFFSET k``.  NULL is excluded (matching the client's
    ``extractSlicerOptions``); ``''`` and the literal text ``'null'`` are
    genuine, distinct options.  ``limit`` is a CAP: further options page via
    ``offset``; ``total_options`` discloses the full cardinality so the
    caller knows more exist.  Synchronous — ``asyncio.to_thread``.
    """
    path = Path(path)
    con = _connect(threads, memory_limit)
    try:
        src = _artifact_src(path)
        schema = _describe(con, src)
        _require_columns([column], schema, "slicer")
        where, params = _build_where(path_filters, None, schema)
        qi = _quote_ident(column)
        where = (where + f" AND {qi} IS NOT NULL") if where else f" WHERE {qi} IS NOT NULL"

        total = int(con.execute(
            f"SELECT COUNT(DISTINCT {qi}) FROM {src}{where}", params).fetchone()[0])
        sql = f"SELECT DISTINCT {qi} FROM {src}{where} ORDER BY {qi} ASC"
        if limit is not None and int(limit) > 0:
            sql += f" LIMIT {int(limit)}"
        if offset:
            sql += f" OFFSET {int(offset)}"
        options = [row[0] for row in con.execute(sql, params).fetchall()]
    finally:
        con.close()

    from core.json_utils import sanitize_for_json
    return {
        "column": column,
        "options": sanitize_for_json(options),
        "total_options": total,
        "limit": int(limit) if (limit is not None and int(limit) > 0) else None,
        "offset": int(offset or 0),
    }


# ── Public capability 5: the matching DETAIL rows (2026-10-30) ───────────────
#
# Every report is a canvas, and the report's OWN table follows linked tiles:
# a click on a bar narrows the table to the rows of that bar.  Those rows are
# the stored result's own rows under the SAME WHERE every tile uses
# (``_build_where``: the clicked paths + slicers) -- never a new query to the
# source.  Read the way ``pagination._duckdb_page`` reads a page (DuckDB
# sorts / slices, ``fetch_df`` -> records), so a page of the table has the
# same values whether it is linked or not.

def read_artifact_rows(path: Path, *,
                       path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                       slicers: Optional[Dict[str, Sequence[Any]]] = None,
                       sort_column: Optional[str] = None,
                       sort_direction: Optional[str] = None,
                       offset: int = 0,
                       limit: Optional[int] = None,
                       threads: int = DEFAULT_THREADS,
                       memory_limit: str = DEFAULT_MEMORY_LIMIT,
                       ) -> Tuple[List[Dict[str, Any]], List[str], int]:
    """``(records, columns, matching_rows)`` -- one page of the stored rows that
    match ``path_filters`` + ``slicers``.  An unknown sort column is ignored
    (as the paged route does); an unknown FILTER column is a ValueError (a
    filter that cannot be applied never becomes "every row").  Synchronous."""
    path = Path(path)
    con = _connect(threads, memory_limit)
    try:
        src = _artifact_src(path)
        schema = _describe(con, src)
        where, params = _build_where(path_filters, slicers, schema)
        if not where:
            raise ValueError("read_artifact_rows needs a filter: an unfiltered page is the paged route's")
        cols = list(schema)
        total = int(con.execute(f"SELECT COUNT(*) FROM {src}{where}", params).fetchone()[0])
        order = ""
        if sort_column and sort_column in schema:
            direction = "DESC" if (sort_direction or "asc").lower() == "desc" else "ASC"
            order = f" ORDER BY {_quote_ident(sort_column)} {direction} NULLS LAST"
        sql = f"SELECT * FROM {src}{where}{order}"
        if limit is not None:
            sql += f" LIMIT {int(limit)} OFFSET {int(max(0, offset))}"
        elif offset:
            sql += f" OFFSET {int(offset)}"
        df = con.execute(sql, params).fetch_df()
        return df.to_dict(orient="records"), cols, total
    finally:
        con.close()


def copy_artifact_rows(path: Path, out_path: Path, *,
                       path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                       slicers: Optional[Dict[str, Sequence[Any]]] = None,
                       threads: int = DEFAULT_THREADS,
                       memory_limit: str = DEFAULT_MEMORY_LIMIT) -> int:
    """Write the stored rows that match the filter to ``out_path`` (parquet,
    the stored column types kept) and return how many -- the report table of
    an EXPORT under linked tiles reads this file exactly as it reads the
    whole result (block / "Rows" sheet / PDF), so nothing else changes."""
    path = Path(path)
    out_path = Path(out_path)
    con = _connect(threads, memory_limit)
    try:
        src = _artifact_src(path)
        schema = _describe(con, src)
        where, params = _build_where(path_filters, slicers, schema)
        if not where:
            raise ValueError("copy_artifact_rows needs a filter")
        con.execute(f"COPY (SELECT * FROM {src}{where}) TO {_sql_path(out_path)} (FORMAT PARQUET)", params)
        return int(con.execute(f"SELECT COUNT(*) FROM read_parquet({_sql_path(out_path)})").fetchone()[0])
    finally:
        con.close()
