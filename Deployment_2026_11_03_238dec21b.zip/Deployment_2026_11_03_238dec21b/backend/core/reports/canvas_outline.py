"""The report canvas: the OUTLINE tile, the header BAND tile, number formats
and the report code (2026-10-30).

Plan: docs/REPORT_OUTLINE_AND_DETAIL_LINKS_2026_10_30.html sections 1-3 (the
owner's reference is a Power BI matrix: Product Area > Business Area > Sub
Product > Book ID, a plus / minus on every row, several branches open at once,
"Business Area Total" rows inside the outline, negatives red in brackets, a
blue band with the chosen parameter values and a report code top right).

Additive to the canvas contract (``layout_config.canvas``, version 1)::

    outline tile  {kind: 'outline', levels: [column ids, top first],
                   measures: [{column_id, aggregation, alias?}],
                   totals: {levels: [bool per level], grand: bool,
                            labels: {"<level index>" | "grand": text}},
                   open_level: int (1 = only the top level shows)}
    band tile     {kind: 'band', parameters?: [parameter names, in order]}
    any tile      formats: {"<column id>": {decimals, thousands,
                                            negative: minus|brackets|red_brackets,
                                            zero: show|blank}}
    the canvas    report_code?: text shown top right of the band

THE ONE ANSWER.  Every row of an outline -- each level, each total, the grand
total -- is a microcube drill over the report's ONE stored, row-secured result
(the viewer through ``POST .../results/{exec_id}/cube``, the exports through
``canvas_export._drill_all``).  Nothing is ever asked of the source again.  A
total row is the PARENT's own group (``GROUP BY`` the levels above it), so it
equals the sum of its children exactly: a DECIMAL column is added up as itself
(the microcube's rule) and a re-added grouped measure is re-added, never
averaged (the canvas grain rule applies to outline measures like any other).

Layout (viewer and exports alike): one column per level, then the values.  A
row that is OPEN and whose level has its total switched on shows its values on
its total row under its children (Power BI's "totals at the bottom"); a row
that is open with its total off keeps its values on its own row, so a number
is never lost.

``outline_problems`` is called from ``canvas.canvas_problems`` (one line) and
mirrored by frontend/src/components/reports/canvas/canvasOutline.ts.
"""
from __future__ import annotations

import json
import re
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Callable, Dict, List, Optional, Sequence

from core.reports.canvas import _emits_aggregate, _int, _label, _is_numeric

OUTLINE_KINDS = ("outline", "band")
NEGATIVE_STYLES = ("minus", "brackets", "red_brackets")
ZERO_STYLES = ("show", "blank")
FORMAT_KEYS = ("decimals", "thousands", "negative", "zero", "rules", "scale", "sign_colour")
#: colour by value (2026-11-02, the report design upgrade step 4): ``scale: {low, high}`` colours a
#: cell's background between two colours by where its value sits between the tile's smallest and
#: largest shown value; ``sign_colour: true`` writes a value above zero in the theme's 'up' colour
#: and one below zero in its 'down' colour (the matrix example's green / red delta %)
SIGN_UP, SIGN_DOWN = "1A7F4B", "C62828"
#: colour rules (2026-10-30 integration): "Unexplained <> 0 -> amber".  The
#: browser's canvasOutline.ts has the same names, the same test and the same
#: fills (a cell's BACKGROUND; the first rule that holds wins).
RULE_OPS = ("eq", "ne", "gt", "lt", "ge", "le", "between")
RULE_FILLS = {"amber": "FFE0A3", "red": "F8D0D0", "green": "D5F0DC", "blue": "D6E6FB"}
MAX_RULES = 20
_PLAIN_NUMBER = re.compile(r"^-?\d+(\.\d+)?$")
MAX_DECIMALS = 10
MAX_LABEL = 100
MAX_REPORT_CODE = 40
MAX_BAND_PARAMETERS = 50
#: band CHIPS (2026-11-02, the report design upgrade step 6): a dropdown / period parameter named in a band
#: tile's ``chips`` draws its choices as chips in the band when it has at most this many (else its cell)
MAX_CHIP_CHOICES = 8
#: an export holds at most this many outline rows per tile (the rest are told)
MAX_OUTLINE_EXPORT_ROWS = 50_000
#: the prefix an outline / tile format rides in an export entry's ``formats``
#: list, so the existing Excel / PDF writers carry it to their one formatter
FORMAT_PREFIX = "qsfmt:"
_CODE_RE = re.compile(r"^[^\x00-\x1f\x7f]*$")


# ── save-time checks ─────────────────────────────────────────────────────────

def _bool(v: Any) -> bool:
    return isinstance(v, bool)


def format_problems(fmt: Any) -> List[str]:
    """What is wrong with one column's number format (plain words)."""
    if not isinstance(fmt, dict):
        return ["a number format must say its decimals, thousands, negatives and zero."]
    out = []
    unknown = sorted(set(fmt) - set(FORMAT_KEYS))
    if unknown:
        out.append(f"a number format has settings it does not know: {', '.join(map(str, unknown))}.")
    d = fmt.get("decimals")
    if d is not None and (not isinstance(d, int) or isinstance(d, bool) or not 0 <= d <= MAX_DECIMALS):
        out.append(f"decimals must be a whole number from 0 to {MAX_DECIMALS}.")
    if fmt.get("thousands") is not None and not _bool(fmt.get("thousands")):
        out.append("the thousands separator is either on or off.")
    if fmt.get("negative") is not None and fmt.get("negative") not in NEGATIVE_STYLES:
        out.append("negatives show with a minus, in brackets, or red in brackets.")
    if fmt.get("zero") is not None and fmt.get("zero") not in ZERO_STYLES:
        out.append("a zero is either shown or left blank.")
    out.extend(rule_problems(fmt.get("rules")))
    sc = fmt.get("scale")
    if sc is not None:
        from core.reports.themes import _is_hex
        if not isinstance(sc, dict) or not _is_hex(sc.get("low")) or not _is_hex(sc.get("high")) or set(sc) - {"low", "high"}:
            out.append("a colour scale names its two colours, low and high, like #ffffff and #1e6fd9.")
    if fmt.get("sign_colour") is not None and not _bool(fmt.get("sign_colour")):
        out.append("colouring the sign (green above zero, red below) is on or off.")
    return out


def _rule_number(v: Any) -> Optional[Decimal]:
    """A rule's comparison value as a DECIMAL (a number, or a number written
    as text); None when it is not one."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, str) and not _PLAIN_NUMBER.match(v.strip()):
        return None                     # the browser's decimalString: digits, a minus, one point
    try:
        d = v if isinstance(v, Decimal) else Decimal(str(v).strip())
    except Exception:                                        # noqa: BLE001
        return None
    return d if d.is_finite() else None


def rule_problems(rules: Any) -> List[str]:
    """What is wrong with a column's colour rules (plain words)."""
    if rules is None:
        return []
    if not isinstance(rules, list):
        return ["its colour rules must be a list."]
    if len(rules) > MAX_RULES:
        return [f"a value can have at most {MAX_RULES} colour rules; this one has {len(rules)}."]
    out: List[str] = []
    for i, r in enumerate(rules, 1):
        if not isinstance(r, dict):
            out.append(f"colour rule {i} must say when and which colour.")
            continue
        unknown = sorted(set(r) - {"op", "value", "value2", "color"})
        if unknown:
            out.append(f"colour rule {i} has settings it does not know: {', '.join(map(str, unknown))}.")
        if r.get("op") not in RULE_OPS:
            out.append(f"colour rule {i}: choose when it applies (equal to, not equal to, above, below, "
                       f"at least, at most, or between).")
        if r.get("color") not in RULE_FILLS:
            out.append(f"colour rule {i}: the colour is amber, red, green or blue.")
        a = _rule_number(r.get("value"))
        if a is None:
            out.append(f"colour rule {i}: the value to compare with must be a number.")
        if r.get("op") == "between":
            b = _rule_number(r.get("value2"))
            if b is None:
                out.append(f"colour rule {i}: between needs a second number.")
            elif a is not None and b < a:
                out.append(f"colour rule {i}: between goes from the smaller number to the larger.")
        elif r.get("value2") is not None:
            out.append(f"colour rule {i}: only between takes a second number.")
    return out


def rule_color(v: Any, fmt: Optional[dict]) -> Optional[str]:
    """The colour NAME of the first rule ``v`` meets (None = none / no number).
    The value is compared as it is stored (a DECIMAL as itself), not as it is
    rounded for display -- 0.004 is not 0."""
    rules = (fmt or {}).get("rules") if isinstance(fmt, dict) else None
    if not rules:
        return None
    d = _rule_number(v) if not isinstance(v, str) or v.strip() else None
    if d is None:
        return None
    for r in rules:
        if not isinstance(r, dict):
            continue
        a, op = _rule_number(r.get("value")), r.get("op")
        if a is None:
            continue
        if op == "between":
            b = _rule_number(r.get("value2"))
            hit = b is not None and a <= d <= b
        else:
            hit = {"eq": d == a, "ne": d != a, "gt": d > a, "lt": d < a, "ge": d >= a, "le": d <= a}.get(op, False)
        if hit and r.get("color") in RULE_FILLS:
            return r["color"]
    return None


def rule_fill(v: Any, fmt: Optional[dict]) -> Optional[str]:
    """The background (hex, no #) of the first rule ``v`` meets."""
    c = rule_color(v, fmt)
    return RULE_FILLS[c] if c else None


def mix_hex(low: str, high: str, f: float) -> str:
    """``low`` mixed towards ``high`` by ``f`` (0..1), six hex digits without '#' -- the browser's ``mixHex``."""
    f = max(0.0, min(1.0, f))
    a, b = low.lstrip("#"), high.lstrip("#")
    # half UP (int(x + 0.5)), the browser's Math.round -- Python's round() is half-even and would differ by one
    return "".join(f"{int(int(a[i:i + 2], 16) + (int(b[i:i + 2], 16) - int(a[i:i + 2], 16)) * f + 0.5):02X}" for i in (0, 2, 4))


def scale_fill(v: Any, fmt: Optional[dict], lo: Optional[float], hi: Optional[float]) -> Optional[str]:
    """The background of a scaled cell (hex, no '#'): where ``v`` sits between the
    tile's smallest and largest value; None without a scale / a number / a range."""
    sc = (fmt or {}).get("scale") if isinstance(fmt, dict) else None
    if not isinstance(sc, dict) or lo is None or hi is None:
        return None
    d = _rule_number(v) if not isinstance(v, str) or v.strip() else None
    if d is None:
        return None
    f = 0.0 if hi == lo else (float(d) - lo) / (hi - lo)
    return mix_hex(str(sc.get("low")), str(sc.get("high")), f)


def sign_colour(v: Any, fmt: Optional[dict], colours: Optional[dict] = None) -> Optional[str]:
    """The text colour of a signed value (hex, no '#'): the 'up' colour above zero, the
    'down' colour below; None at zero / no number / the format does not ask."""
    if not isinstance(fmt, dict) or fmt.get("sign_colour") is not True:
        return None
    d = _rule_number(v) if not isinstance(v, str) or v.strip() else None
    if d is None or d == 0:
        return None
    c = colours or {}
    return str(c.get("up") or SIGN_UP) if d > 0 else str(c.get("down") or SIGN_DOWN)


def scale_ranges(entry: dict) -> Dict[str, Dict[str, Any]]:
    """Per export column (by index, as text) whose tile format carries a ``scale``: the
    two colours and the smallest / largest number in the entry's rows -- what the
    Excel ColorScaleRule and the PDF's cell colours are built from."""
    out: Dict[str, Dict[str, Any]] = {}
    for i, pattern in enumerate(entry.get("formats") or []):
        f = decode_format(pattern)
        sc = (f or {}).get("scale")
        if not isinstance(sc, dict):
            continue
        nums = []
        for r in entry.get("rows") or []:
            d = _rule_number(r[i]) if i < len(r) and (not isinstance(r[i], str) or r[i].strip()) else None
            if d is not None:
                nums.append(float(d))
        if nums:
            out[str(i)] = {"low": str(sc["low"]).lstrip("#").upper(), "high": str(sc["high"]).lstrip("#").upper(),
                           "min": min(nums), "max": max(nums)}
    return out


#: 2026-11-01 drill-down (frontend canvasDrill.tsx): a HIERARCHY is a named list of
#: 2..MAX_LEVELS report columns; drill_columns = the fields a viewer may add to the grid
MAX_HIERARCHY_NAME = 60
MAX_LEVELS = 8


def drill_problems(canvas: dict, *, cols: Dict[int, dict], selected: set,
                   say: Callable[[Optional[dict], str], None]) -> None:
    """The drill paths and the approved fields, in the browser's words."""
    def ok(cid: Any) -> bool:
        return isinstance(cid, int) and not isinstance(cid, bool) and cid in cols and (not selected or cid in selected)
    hs = canvas.get("hierarchies")
    if hs is not None:
        if not isinstance(hs, list):
            say(None, "The drill paths must be a list.")
        else:
            for h in hs:
                if not isinstance(h, dict):
                    say(None, "A drill path must name itself and its levels.")
                    continue
                name = h.get("name")
                levels = h.get("levels") if isinstance(h.get("levels"), list) else []
                if not isinstance(name, str) or not name.strip() or len(name) > MAX_HIERARCHY_NAME:
                    say(None, f"A drill path needs a name of at most {MAX_HIERARCHY_NAME} characters.")
                    name = str(name or "")
                if not 2 <= len(levels) <= MAX_LEVELS:
                    say(None, f'The drill path "{name}" needs 2 to {MAX_LEVELS} levels.')
                if len(set(map(str, levels))) != len(levels):
                    say(None, f'The drill path "{name}" names the same field twice.')
                for cid in levels:
                    if not ok(cid):
                        say(None, f'The drill path "{name}" uses a field that is not one of the report\'s columns (#{cid}).')
    dc = canvas.get("drill_columns")
    if dc is not None:
        if not isinstance(dc, list):
            say(None, "The approved drill fields must be a list.")
        else:
            for cid in dc:
                if not ok(cid):
                    say(None, f"An approved drill field is not one of the report's columns (#{cid}).")


def outline_problems(canvas: dict, tiles: Sequence[Any], *, cols: Dict[int, dict], selected: set,
                     grouped: bool, say: Callable[[Optional[dict], str], None]) -> None:
    """Every problem of the outline / band tiles, the number formats of any
    tile and the canvas's report code -- each said on its tile."""
    code = canvas.get("report_code")
    if code is not None and (not isinstance(code, str) or len(code) > MAX_REPORT_CODE or not _CODE_RE.match(code)):
        say(None, f"The report code is text of at most {MAX_REPORT_CODE} characters.")
    drill_problems(canvas, cols=cols, selected=selected, say=say)
    from core.reports.canvas_compare import compare_problems
    compare_problems(canvas, say)
    pages_problems(canvas, tiles, say=say)
    for t in tiles:
        if not isinstance(t, dict):
            continue
        kind = t.get("kind")
        fmts = t.get("formats")
        if fmts is not None:
            if kind == "report":
                say(t, "the report's own table keeps the number formats of its columns (set them on the "
                       "dataset); number formats here apply to the other tiles.")
            elif not isinstance(fmts, dict):
                say(t, "its number formats must be a list by column.")
            else:
                for key, fmt in fmts.items():
                    cid = _int(key)
                    if cid is None or cid not in cols:
                        say(t, f"it has a number format for a field that is not in the data (column #{key}).")
                        continue
                    for p in format_problems(fmt):
                        say(t, f"{_label(cols[cid], cid)}: {p}")
        if kind == "outline":
            _outline_tile_problems(t, cols=cols, selected=selected, grouped=grouped, say=say)
        elif kind == "band":
            _band_tile_problems(t, say=say)
        elif kind == "number":            # the KPI card's fields (2026-11-02, core/reports/canvas_kpi.py)
            from core.reports.canvas_kpi import kpi_problems
            kpi_problems(t, cols=cols, selected=selected, grouped=grouped, say=say, canvas=canvas)
        else:                              # chart options (2026-11-02, core/reports/canvas_chart_options.py)
            from core.reports.canvas import CHART_KINDS
            if kind in CHART_KINDS:
                from core.reports.canvas_chart_options import chart_option_problems
                chart_option_problems(t, say=say, canvas=canvas)


def pages_problems(canvas: dict, tiles: Sequence[Any], *, say: Callable[[Optional[dict], str], None]) -> None:
    """The canvas's pages (2026-11-02): a list of at most MAX_PAGES, each with an id, a
    title of plain text and the ids of its tiles -- a tile on at most one page, every
    page's tiles existing tiles; the browser's ``pagesProblems`` says the same."""
    from core.reports.canvas import MAX_PAGES, MAX_PAGE_TITLE, _ID_RE
    pages = canvas.get("pages")
    if pages is None:
        return
    if not isinstance(pages, list):
        say(None, "The pages must be a list, each with a title and its tiles.")
        return
    if len(pages) > MAX_PAGES:
        say(None, f"A report can have {MAX_PAGES} pages; this one has {len(pages)}.")
    ids = {str(t.get("id")) for t in tiles if isinstance(t, dict)}
    seen_pages: set = set()
    placed: Dict[str, str] = {}
    for k, p in enumerate(pages, 1):
        if not isinstance(p, dict):
            say(None, f"Page {k} must have a title and its tiles.")
            continue
        pid = p.get("id")
        if not isinstance(pid, str) or not _ID_RE.match(pid) or pid in seen_pages:
            say(None, f"Page {k}'s id is missing or used twice.")
        seen_pages.add(str(pid))
        title = p.get("title")
        if not isinstance(title, str) or not title.strip() or len(title) > MAX_PAGE_TITLE or not _CODE_RE.match(title):
            say(None, f"Page {k} needs a title of at most {MAX_PAGE_TITLE} characters.")
        tl = p.get("tiles")
        if not isinstance(tl, list):
            say(None, f"Page {k}'s tiles must be a list of tile ids.")
            continue
        for tid in tl:
            if str(tid) not in ids:
                say(None, f"Page {k} names a tile that is not on the canvas ({tid}).")
            elif str(tid) in placed:
                say(None, f"A tile is on two pages ({tid}); a tile sits on one page.")
            placed[str(tid)] = str(pid)


def _outline_tile_problems(t: dict, *, cols, selected, grouped, say) -> None:
    levels = t.get("levels")
    if not isinstance(levels, list) or not levels:
        say(t, "an outline needs at least one level (the field its rows are grouped by).")
        return
    ids = [_int(x) for x in levels]
    measure_ids = {_int(m.get("column_id")) for m in (t.get("measures") or []) if isinstance(m, dict)}
    for lid, raw in zip(ids, levels):
        if lid is None or lid not in cols:
            say(t, f"a level is a field that is no longer in the data (column #{raw}). Remove it from the outline.")
            continue
        c = cols[lid]
        if lid not in selected:
            say(t, f"{_label(c, lid)} is not one of the report's columns, so the report does not return it. Add it to the report.")
        if lid in measure_ids:
            say(t, f"{_label(c, lid)} is both a level and a value.")
        if grouped and _emits_aggregate(c):
            say(t, f"{_label(c, lid)} is added up in this report's rows, so it cannot be a level.")
    if len(set(ids)) != len(ids):
        say(t, "the same field is a level twice.")
    if t.get("dimensions") or t.get("series") is not None:
        say(t, "an outline takes its fields as levels and values only.")
    if not t.get("measures"):
        say(t, "an outline needs at least one value to show.")
    n = len(levels)
    ol = t.get("open_level")
    if ol is not None and (not isinstance(ol, int) or isinstance(ol, bool) or not 1 <= ol <= n):
        say(t, f"it opens to a level from 1 to {n}.")
    totals = t.get("totals")
    if totals is None:
        return
    if not isinstance(totals, dict):
        say(t, "its totals must say which levels have a total.")
        return
    unknown = sorted(set(totals) - {"levels", "grand", "labels"})
    if unknown:
        say(t, f"its totals have settings it does not know: {', '.join(map(str, unknown))}.")
    tl = totals.get("levels")
    if tl is not None and (not isinstance(tl, list) or len(tl) > n or not all(_bool(x) for x in tl)):
        say(t, f"its totals say on or off for each of its {n} levels.")
    if totals.get("grand") is not None and not _bool(totals.get("grand")):
        say(t, "the grand total is either on or off.")
    labels = totals.get("labels")
    if labels is not None:
        if not isinstance(labels, dict):
            say(t, "the names of its totals must be a list by level.")
        else:
            for k, v in labels.items():
                ki = _int(k)
                if not (k == "grand" or (ki is not None and str(ki) == str(k) and 0 <= ki < n)):
                    say(t, f'a total is named for a level it does not have ("{k}").')
                elif not isinstance(v, str) or len(v) > MAX_LABEL:
                    say(t, f"the name of a total is text of at most {MAX_LABEL} characters.")


def _band_tile_problems(t: dict, *, say) -> None:
    if t.get("dimensions") or t.get("measures") or t.get("series") is not None:
        say(t, "the band shows the report's chosen values; it takes no fields.")
    ps = t.get("parameters")
    if ps is not None:
        if not isinstance(ps, list) or len(ps) > MAX_BAND_PARAMETERS or not all(isinstance(p, str) and 0 < len(p) <= 200 for p in ps):
            say(t, f"the band lists up to {MAX_BAND_PARAMETERS} parameters by name.")
        elif len(set(ps)) != len(ps):
            say(t, "the band lists a parameter twice.")
    chips = t.get("chips")
    if chips is not None:
        if not isinstance(chips, list) or len(chips) > MAX_BAND_PARAMETERS or not all(isinstance(c, str) and 0 < len(c) <= 200 for c in chips):
            say(t, f"the band's chips are up to {MAX_BAND_PARAMETERS} parameter names (a dropdown or a period with at most {MAX_CHIP_CHOICES} choices).")
        elif len(set(chips)) != len(chips):
            say(t, "the band names a parameter twice as chips.")


# ── number formats: ONE reading for the viewer's rules, Excel and the PDF ──

def tile_format_for(t: dict, column_id: Any) -> Optional[dict]:
    fmts = t.get("formats") if isinstance(t.get("formats"), dict) else None
    if not fmts:
        return None
    f = fmts.get(str(column_id))
    if f is None:
        f = fmts.get(column_id) if not isinstance(column_id, str) else None
    return f if isinstance(f, dict) and not format_problems(f) else None


def encode_format(fmt: dict) -> str:
    return FORMAT_PREFIX + json.dumps({k: fmt.get(k) for k in FORMAT_KEYS if fmt.get(k) is not None},
                                      sort_keys=True)


def decode_format(pattern: Any) -> Optional[dict]:
    if not isinstance(pattern, str) or not pattern.startswith(FORMAT_PREFIX):
        return None
    try:
        f = json.loads(pattern[len(FORMAT_PREFIX):])
    except ValueError:
        return None
    return f if isinstance(f, dict) and not format_problems(f) else None


def format_number(v: Any, fmt: dict) -> Optional[str]:
    """The words for a number in a tile format; None when ``v`` is no number.
    A DECIMAL is rounded as a DECIMAL (half up), never through a float."""
    if v is None or isinstance(v, bool):
        return None
    try:
        d = v if isinstance(v, Decimal) else Decimal(str(v))
    except Exception:                                        # noqa: BLE001
        return None
    if not d.is_finite():
        return None
    decimals = fmt.get("decimals")
    decimals = 2 if decimals is None else int(decimals)
    q = d.quantize(Decimal(1).scaleb(-decimals), rounding=ROUND_HALF_UP)
    if q == 0:
        if fmt.get("zero") == "blank":
            return ""
        q = abs(q)                                           # never "-0.00"
    neg = q < 0
    body = f"{abs(q):{',' if fmt.get('thousands', True) else ''}.{decimals}f}"
    if not neg:
        return body
    return f"({body})" if fmt.get("negative") in ("brackets", "red_brackets") else f"-{body}"


def is_red(v: Any, fmt: Optional[dict]) -> bool:
    if not fmt or fmt.get("negative") != "red_brackets" or v is None or isinstance(v, bool):
        return False
    try:
        d = v if isinstance(v, Decimal) else Decimal(str(v))
        decimals = 2 if fmt.get("decimals") is None else int(fmt["decimals"])
        return d.is_finite() and d.quantize(Decimal(1).scaleb(-decimals), rounding=ROUND_HALF_UP) < 0
    except Exception:                                        # noqa: BLE001
        return False


def excel_format(fmt: dict) -> str:
    """The Excel number format of a tile format: positive;negative;zero."""
    decimals = 2 if fmt.get("decimals") is None else int(fmt["decimals"])
    base = ("#,##0" if fmt.get("thousands", True) else "0") + ("." + "0" * decimals if decimals else "")
    neg = fmt.get("negative") or "minus"
    negative = {"minus": f"-{base}", "brackets": f"({base})", "red_brackets": f"[Red]({base})"}[neg]
    zero = '""' if fmt.get("zero") == "blank" else base
    return f"{base};{negative};{zero}"


def wrap_excel_resolver(resolve: Callable[[str], str]) -> Callable[[str], str]:
    """The canvas workbook's format resolver, reading a tile format first."""
    def _resolve(pattern: str) -> str:
        f = decode_format(pattern)
        return excel_format(f) if f is not None else resolve(pattern)
    return _resolve


def wrap_pdf_formatter(fmt_value: Callable[[str, Any, dict], str]) -> Callable[[str, Any, dict], str]:
    """The canvas PDF's cell formatter, reading a tile format first (HTML)."""
    import html as _html

    def _fmt(name: str, v: Any, fmt_map: dict) -> str:
        f = decode_format((fmt_map or {}).get(name))
        if f is None:
            return fmt_value(name, v, fmt_map)
        text = format_number(v, f)
        if text is None:
            return "" if v is None else _html.escape(str(v))
        text = _html.escape(text)
        # the sign's colour (2026-11-02) or a red negative; SECURITY: a colour here is six hex digits of the theme
        sc = sign_colour(v, f, (fmt_map or {}).get("__sign_colours__") if isinstance(fmt_map, dict) else None)
        if sc and re.fullmatch(r"[0-9A-Fa-f]{6}", sc):
            text = f'<span class="cv-sign" style="color:#{sc}">{text}</span>'
        elif is_red(v, f):
            text = f'<span style="color:#d32f2f">{text}</span>'
        bg = rule_fill(v, f)
        return f'<span class="cv-rule" style="background:#{bg};padding:0 2px">{text}</span>' if bg else text
    return _fmt


def _measure_positions(entry: dict, t: dict, n_measures: int) -> List[Optional[int]]:
    """For each header column of an export entry, the index of the tile
    measure it shows (None = a field column).  Mirrors how
    ``canvas_export`` lays each kind out."""
    kind = entry.get("kind")
    header = entry.get("header") or []
    n = len(header)
    dims = len(t.get("dimensions") or [])
    if kind == "outline":
        lead = len(t.get("levels") or [])
        return [None if i < lead else i - lead for i in range(n)]
    if kind in ("number", "table"):
        lead = 0 if kind == "number" else dims
        return [None if i < lead else i - lead for i in range(n)]
    if kind in ("pivot", "heatmap"):
        return [None if i < dims else (i - dims) % max(1, n_measures) for i in range(n)]
    split = bool((entry.get("labels") or {}).get("series"))
    return [None if i == 0 else (0 if split else i - 1) for i in range(n)]


def apply_tile_formats(entry: dict, t: dict) -> None:
    """Put the tile's own number formats on its export entry (in place)."""
    if not isinstance(t.get("formats"), dict) or not t.get("formats") or not entry.get("header"):
        return
    ms = [m for m in t.get("measures") or [] if isinstance(m, dict)]
    formats = list(entry.get("formats") or []) + [""] * len(entry["header"])
    for i, mi in enumerate(_measure_positions(entry, t, len(ms))):
        if mi is None or mi >= len(ms):
            continue
        f = tile_format_for(t, ms[mi].get("column_id"))
        if f is not None:
            formats[i] = encode_format(f)
    entry["formats"] = formats[:len(entry["header"])]
    # colour by value (2026-11-02): the scaled columns' ranges over THIS entry's rows
    ranges = scale_ranges(entry)
    if ranges:
        entry["scales"] = ranges


# ── the outline in an export: open to its starting level, with totals ──────

def total_label(t: dict, level: int, cols: Dict[int, dict]) -> str:
    labels = ((t.get("totals") or {}).get("labels") or {}) if isinstance(t.get("totals"), dict) else {}
    own = labels.get(str(level)) if isinstance(labels, dict) else None
    if isinstance(own, str) and own.strip():
        return own.strip()
    lid = (t.get("levels") or [None])[level]
    return f"{_label(cols.get(_int(lid)), lid)} Total"


def grand_label(t: dict) -> str:
    labels = ((t.get("totals") or {}).get("labels") or {}) if isinstance(t.get("totals"), dict) else {}
    own = labels.get("grand") if isinstance(labels, dict) else None
    return own.strip() if isinstance(own, str) and own.strip() else "Grand Total"


def _totals_on(t: dict, n: int) -> List[bool]:
    tl = (t.get("totals") or {}).get("levels") if isinstance(t.get("totals"), dict) else None
    tl = list(tl) if isinstance(tl, list) else []
    return [bool(tl[i]) if i < len(tl) else False for i in range(n)]


def open_level(t: dict) -> int:
    n = len(t.get("levels") or [])
    ol = t.get("open_level")
    return min(max(int(ol), 1), n) if isinstance(ol, int) and not isinstance(ol, bool) else 1


def outline_entry(entry: dict, t: dict, path, cols: Dict[int, dict], phys, measure_header,
                  fmt_of, drill_all, *, grain: str, group_columns, budget: List[int],
                  slicers: Optional[Dict[str, List[Any]]] = None) -> None:
    """Fill ``entry`` (a canvas_export tile entry) with the outline open to its
    starting level: one column per level then the values, a total row under
    every open row whose level has its total on, the grand total last."""
    level_ids = [_int(x) for x in t.get("levels") or []]
    levels = [phys(i) for i in level_ids]
    ms = [m for m in t.get("measures") or [] if isinstance(m, dict)]
    measures = [{"column": phys(m["column_id"]), "aggregation": m.get("aggregation"), "alias": f"v{i}__"}
                for i, m in enumerate(ms)]
    n = len(levels)
    depth = open_level(t)
    totals_on = _totals_on(t, n)
    grand_on = bool((t.get("totals") or {}).get("grand")) if isinstance(t.get("totals"), dict) else False
    entry["header"] = [_label(cols.get(i), i) for i in level_ids] + [measure_header(m, cols) for m in ms]
    entry["formats"] = [fmt_of(cols.get(i)) for i in level_ids] + [fmt_of(cols.get(int(m["column_id"]))) for m in ms]
    width = max(1, n + len(ms))
    cap = max(1, min(MAX_OUTLINE_EXPORT_ROWS, budget[0] // width))
    # one drill per shown level over the WHOLE stored result -- the children
    # of every open row at once, in the level's own order (as the viewer asks)
    children: Dict[tuple, List[dict]] = {}
    cut = False
    for k in range(1, depth + 1):
        res = drill_all(path, levels[:k], measures, sort_column=levels[k - 1], sort_direction="asc",
                        grain=grain, group_cols=group_columns, limit=cap, slicers=slicers)
        cut = cut or res["total"] > len(res["rows"])
        for r in res["rows"]:
            children.setdefault(tuple(r.get(c) for c in levels[:k - 1]), []).append(r)
    grand = None
    if grand_on:
        g = drill_all(path, [], measures, sort_column=None, sort_direction="asc", grain=grain,
                      group_cols=group_columns, limit=1, slicers=slicers)
        grand = g["rows"][0] if g["rows"] else None
    rows: List[list] = []
    kinds: List[str] = []
    stopped = [False]
    vals = lambda r: [r.get(f"v{i}__") for i in range(len(ms))]   # noqa: E731

    def emit(prefix: tuple, k: int) -> None:
        for r in children.get(prefix, []):
            if len(rows) >= cap:
                stopped[0] = True
                return
            open_ = k + 1 < depth
            total_row = open_ and totals_on[k]
            line = [None] * n + ([None] * len(ms) if total_row else vals(r))
            line[k] = "(no value)" if r.get(levels[k]) is None else r.get(levels[k])
            rows.append(line)
            kinds.append("open" if open_ else "row")
            if open_:
                emit(prefix + (r.get(levels[k]),), k + 1)
                if total_row:
                    tl = [None] * n + vals(r)
                    tl[k] = total_label(t, k, cols)
                    rows.append(tl)
                    kinds.append("total")

    emit((), 0)
    if grand is not None:
        gl = [None] * n + vals(grand)
        gl[0] = grand_label(t)
        rows.append(gl)
        kinds.append("grand")
    entry["rows"] = rows
    entry["row_kinds"] = kinds
    entry["bold_rows"] = [i for i, k in enumerate(kinds) if k in ("total", "grand")]
    budget[0] -= len(rows) * width
    if cut or stopped[0]:
        entry["note"] = (f"{len(rows):,} outline rows are included (an export holds {cap:,} for this tile); "
                         f"open the report on screen to see the rest.")
    elif depth < n:
        names = ", ".join(_label(cols.get(i), i) for i in level_ids[depth:])
        entry["note"] = f"Open to {_label(cols.get(level_ids[depth - 1]), level_ids[depth - 1])}; " \
                        f"{names} {'is' if n - depth == 1 else 'are'} shown on screen when a row is opened."


# ── the band: the run's chosen values ──────────────────────────────────────

def _shown_value(v: Any) -> str:
    if v is None or v == "" or (isinstance(v, (list, tuple)) and not v):
        return "All"
    if isinstance(v, (list, tuple)):
        return ", ".join("" if x is None else str(x) for x in v)
    if isinstance(v, dict):
        return " to ".join(str(x) for x in v.values() if x not in (None, ""))
    return str(v)


def run_parameters(db, report: dict, param_values: Optional[dict]) -> List[Dict[str, Any]]:
    """``[{name, label, value}]`` -- the report's parameters with the values a
    run used: the caller's, else the parameter's default (the run's own rule,
    ``core.parameters.seed_parameter_defaults``)."""
    from core.parameters import seed_parameter_defaults
    try:
        schema = db.list_report_parameters(report.get("id")) or []
    except Exception:                                        # noqa: BLE001
        schema = []
    eff = seed_parameter_defaults(schema, param_values or {})
    return [{"name": p.get("name"), "label": p.get("label") or p.get("name"), "value": eff.get(p.get("name"))}
            for p in schema if isinstance(p, dict) and p.get("name")]


def band_entry(entry: dict, t: dict, report: dict, parameters: Optional[List[dict]]) -> None:
    """Fill ``entry`` with the band: one column per parameter, its chosen
    value, the report code in the title."""
    canvas = (report.get("layout_config") or {}).get("canvas") or {}
    code = canvas.get("report_code") if isinstance(canvas.get("report_code"), str) else ""
    title = str(t.get("title") or "").strip() or str(report.get("name") or "Report")
    entry["title"] = f"{title}  [{code}]" if code else title
    params = list(parameters or [])
    wanted = t.get("parameters") if isinstance(t.get("parameters"), list) else None
    if wanted:
        by = {p["name"]: p for p in params}
        params = [by.get(n) or {"name": n, "label": n, "value": None, "missing": True} for n in wanted]
    if not params:
        entry["note"] = "This report asks for no values."
        entry["header"], entry["rows"], entry["formats"] = [], [], []
        return
    entry["header"] = [str(p.get("label") or p.get("name")) for p in params]
    entry["rows"] = [["(not asked by this report)" if p.get("missing") else _shown_value(p.get("value"))
                      for p in params]]
    entry["formats"] = [""] * len(params)
