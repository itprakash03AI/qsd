"""The report canvas, checked on save (2026-10-26).

Owner-approved design: docs/REPORT_CANVAS_DESIGN_2026_10_25.html.  The
canvas lives in ``layout_config.canvas``; each tile is a view of the report's
ONE result (the stored, row-secured result of a run) computed through the
microcube (``core/reports/microcube.py``) -- never a second query.

``canvas_problems`` is the server's reading of what is wrong with a canvas,
the same rules as the builder's (frontend/src/components/reports/canvas/
canvasModel.ts::canvasProblems), plus what only the server can know:

* every field a tile uses is one of the report's selected columns (the query
  returns nothing else), and a column of its dataset;
* the way a tile adds values up is EXACT for this report's result.  A report
  whose dataset adds its measures up (or has a calculated metric) stores
  GROUPED rows: tiles may then re-add them (sum), take the smallest / largest,
  or count the different values of a column the rows are grouped by -- a
  count or an average over grouped rows would be a wrong number, so it is
  refused here by name (the microcube refuses the same at run time).

An empty list = the canvas may be saved.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional

from core.reports.canvas_actions import actions_problems

TILE_KINDS = ("report", "number", "table", "pivot", "heatmap",
              "bar", "hbar", "stacked_bar", "line", "area", "stacked_area", "combo", "radar",
              "pie", "donut", "treemap", "funnel", "waterfall", "scatter", "bubble",
              "outline", "band",
              "insight")  # insight: core/reports/canvas_insights.py (2026-10-30)
#: one category, 1..8 values (each a series) OR one value split by a series field
SERIES_CHARTS = ("bar", "hbar", "stacked_bar", "line", "area", "stacked_area", "radar")
#: one category, one value
ONE_VALUE_CHARTS = ("pie", "donut", "treemap", "funnel", "waterfall")
#: parts of a whole / a running total: the value must be added up
SUM_ONLY = ("pie", "donut", "treemap", "waterfall")
CHART_KINDS = SERIES_CHARTS + ONE_VALUE_CHARTS + ("combo", "scatter", "bubble")
MAX_SERIES_VALUES = 8
#: a waterfall with NO category is a BRIDGE (2026-11-03): one step per value, then the total
#: (opening -> market -> carry -> new trades -> unexplained); 2..MAX_BRIDGE_STEPS values, each added up
MAX_BRIDGE_STEPS = 8


def is_bridge(t: dict) -> bool:
    """A waterfall whose steps are its VALUES (no category field) -- the one test, export and save check."""
    return t.get("kind") == "waterfall" and not (t.get("dimensions") or []) and len(t.get("measures") or []) >= 2
#: the deepest a canvas goes (grid rows) -- the exports clamp to the same
MAX_GRID_ROWS = 2000
AGGREGATIONS = ("sum", "avg", "count", "min", "max", "count_distinct")
GRID_COLS = 12
MAX_TILES = 40
MAX_CHART_POINTS = 500
#: a tile value's own label ("Trades" instead of "Id (count of different values)")
MAX_MEASURE_LABEL = 60
#: 2026-10-30 (the canvas drawing fast): a line / area over ONE value with no
#: series field is a long series (a day per point for years) -- it may draw up
#: to this many points; the viewer and the exports down-sample it to about a
#: point per pixel with LTTB (core/reports/lttb.py), the peaks and dips kept.
DENSE_KINDS = ("line", "area")
MAX_DENSE_POINTS = 250_000
#: 2026-10-30 (every report a canvas): a scatter may draw as many points too --
#: the viewer paints a big one with WebGL (drawingLadder.ts); the exports draw
#: an even spread of ``canvas_export.EXPORT_MAX_POINTS`` of them and say so
MANY_POINT_KINDS = DENSE_KINDS + ("scatter",)


def max_points_of(kind: str, series: Any) -> int:
    """How many categories a chart tile of this kind may draw."""
    return MAX_DENSE_POINTS if kind in MANY_POINT_KINDS and series is None else MAX_CHART_POINTS


#: PAGES (2026-11-02, the report design upgrade step 5): ``canvas.pages = [{id, title, tiles: [tile ids]}]``
#: -- tabs in the header; one run serves every page (the tiles are views of the same result); a tile
#: on no page sits on the FIRST page; no pages = one page, exactly as before
MAX_PAGES = 12
MAX_PAGE_TITLE = 60


def pages_of(canvas: Any) -> List[Dict[str, Any]]:
    """THE ONE READING of a canvas's pages: ``[{id, title, tile_ids}]`` -- the stored pages
    with every tile on no page added to the first; a canvas without pages is one page
    (title "") of every tile.  The exports and the browser's ``pagesOf`` agree."""
    tiles = [t for t in (canvas.get("tiles") or []) if isinstance(t, dict)] if isinstance(canvas, dict) else []
    ids = [str(t.get("id")) for t in tiles]
    raw = canvas.get("pages") if isinstance(canvas, dict) else None
    pages = [p for p in raw if isinstance(p, dict)] if isinstance(raw, list) else []
    if not pages:
        return [{"id": "page1", "title": "", "tile_ids": list(ids)}]
    out = [{"id": str(p.get("id") or f"page{i + 1}"), "title": str(p.get("title") or ""),
            "tile_ids": [str(x) for x in (p.get("tiles") if isinstance(p.get("tiles"), list) else []) if str(x) in ids]}
           for i, p in enumerate(pages)]
    placed = {x for p in out for x in p["tile_ids"]}
    out[0]["tile_ids"] = out[0]["tile_ids"] + [i for i in ids if i not in placed]
    return out


def export_pages(canvas: Any) -> List[Dict[str, Any]]:
    """``pages_of`` plus ``has_report`` per page (the report's own table sits on one page)."""
    rt = report_tile(canvas)
    rid = str(rt.get("id")) if rt else None
    return [{**p, "has_report": rid in p["tile_ids"]} for p in pages_of(canvas)]


#: the one tile a report with no canvas opens as (2026-10-30, every report a
#: canvas): its own table, full width -- the browser's ``defaultCanvas()``
REPORT_TILE_ID = "report"
REPORT_TILE_LAYOUT = {"x": 0, "y": 0, "w": 12, "h": 7}


def default_canvas() -> Dict[str, Any]:
    """A report's canvas when it has none stored: ONE tile, its own table."""
    return {"version": 1, "tiles": [{"id": REPORT_TILE_ID, "kind": "report", "title": "", "dimensions": [],
                                     "measures": [], "series": None, "sort": None, "top_n": None,
                                     "layout": dict(REPORT_TILE_LAYOUT)}]}


def effective_canvas(layout_config: Any) -> Dict[str, Any]:
    """THE ONE READING of a report's canvas (2026-10-30, the owner: "we should
    mix both rather than categorizing canvas n normal reports"): the stored
    ``layout_config.canvas`` when it has a tile list, otherwise the canvas of
    ONE report tile -- derived at read time, never written (nothing is stored
    until someone saves).  The browser's ``readCanvas(..) ?? defaultCanvas()``
    is the same answer."""
    c = layout_config.get("canvas") if isinstance(layout_config, dict) else None
    if isinstance(c, dict) and isinstance(c.get("tiles"), list):
        return c
    return default_canvas()


def report_tile(canvas: Any) -> Optional[Dict[str, Any]]:
    """The report's own table on a canvas, or None when it is not placed."""
    tiles = canvas.get("tiles") if isinstance(canvas, dict) else None
    for t in tiles if isinstance(tiles, list) else []:
        if isinstance(t, dict) and t.get("kind") == "report":
            return t
    return None


def has_tiles_beside_report(canvas: Any) -> bool:
    """Does the canvas hold a tile beside the report's own table?  A canvas
    of the report table alone exports EXACTLY as a report always did."""
    return isinstance(canvas, dict) and any(isinstance(t, dict) and t.get("kind") != "report"
                                            for t in canvas.get("tiles") or [])
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_VALID_DATASET_AGGS = ("SUM", "AVG", "COUNT", "MIN", "MAX", "COUNT_DISTINCT")
_NUMERIC_RE = re.compile(r"int|decimal|numeric|double|float|real|number|money", re.I)


def _label(col: Optional[dict], cid: Any) -> str:
    if not col:
        return f"column #{cid}"
    return str(col.get("friendly_name") or col.get("display_name") or col.get("physical_name") or f"column #{cid}")


def _emits_aggregate(col: dict) -> bool:
    agg = str(col.get("aggregation") or "").strip().upper()
    return col.get("column_type") in ("measure", "kpi") and agg in _VALID_DATASET_AGGS


def _is_numeric(col: Optional[dict]) -> bool:
    return bool(col) and (bool(_NUMERIC_RE.search(str(col.get("data_type") or "")))
                          or col.get("column_type") in ("measure", "kpi"))


def dataset_rows_are_grouped(columns: Iterable[dict], has_metrics: bool) -> bool:
    """The microcube's fail-closed grain rule (``_derive_artifact_grain``):
    any dataset column that adds up, or any calculated metric, means the
    stored rows are grouped."""
    return has_metrics or any(_emits_aggregate(c) for c in columns)


def _tile_name(t: dict, cols: Dict[int, dict]) -> str:
    title = str(t.get("title") or "").strip()
    if title:
        return title
    if t.get("kind") == "report":
        return "Report"
    if t.get("kind") == "insight":
        from core.reports.canvas_insights import insight_title
        return insight_title(t, cols)
    ms = t.get("measures") if isinstance(t.get("measures"), list) else []
    ds = t.get("dimensions") if isinstance(t.get("dimensions"), list) else []
    m = _label(cols.get(_int(ms[0].get("column_id"))), ms[0].get("column_id")) if ms and isinstance(ms[0], dict) else ""
    d = _label(cols.get(_int(ds[0])), ds[0]) if ds else ""
    if m and d:
        return f"{m} by {d}"
    return m or d or str(t.get("kind") or "tile")


def _int(v: Any) -> Optional[int]:
    try:
        if isinstance(v, bool):
            return None
        return int(v)
    except (TypeError, ValueError):
        return None


def measure_problems(m: dict, cols: Dict[int, dict], grouped: bool) -> List[str]:
    """What is wrong with ONE value of a tile (the aggregation, the grain rule), in
    plain words -- shared with the KPI card's comparison value (canvas_kpi)."""
    out: List[str] = []
    agg = m.get("aggregation")
    col = cols.get(_int(m.get("column_id")))
    if agg not in AGGREGATIONS:
        return [f'"{agg}" is not a way to add up values.']
    name = _label(col, m.get("column_id"))
    if col and agg in ("sum", "avg") and not _is_numeric(col):
        out.append(f"{name} is not a number, so it cannot be {'added up' if agg == 'sum' else 'averaged'}. Use Count of different values instead.")
    if grouped and agg == "count":
        out.append("this report's rows are already added up, so counting them would count groups, not the "
                   "underlying rows. Use a count measure of the data (shown as Sum), or Count of different values.")
    if grouped and agg == "avg":
        out.append(f"this report's rows are already added up, so an average of {name} here would be an average "
                   f"of averages -- a wrong number. Show the Sum, or an average measure at the report's own level.")
    if grouped and agg == "count_distinct" and col and _emits_aggregate(col):
        out.append(f"{name} is added up in this report's rows, so its different values cannot be counted.")
    return out


def canvas_problems(canvas: Any, *, dataset_columns: List[dict], report_column_ids: List[int],
                    has_metrics: bool, has_dataset: bool = True,
                    action_targets: Any = None) -> List[Dict[str, Optional[str]]]:
    out: List[Dict[str, Optional[str]]] = []
    if canvas is None:
        return out
    if not isinstance(canvas, dict) or not isinstance(canvas.get("tiles"), list):
        return [{"tile_id": None, "message": "The canvas must be an object with a list of tiles."}]
    tiles = canvas["tiles"]
    cols = {int(c["id"]): c for c in dataset_columns if _int(c.get("id")) is not None}
    selected = {int(i) for i in report_column_ids if _int(i) is not None}
    grouped = dataset_rows_are_grouped(dataset_columns, has_metrics)

    def say(t: Optional[dict], message: str) -> None:
        if t is None:
            out.append({"tile_id": None, "message": message})
        else:
            out.append({"tile_id": str(t.get("id") or ""), "message": f"{_tile_name(t, cols)}: {message}"})

    if not tiles:
        say(None, "The report has no tiles. Add at least one.")
    if len(tiles) > MAX_TILES:
        say(None, f"A report can hold {MAX_TILES} tiles; this one has {len(tiles)}.")
    if sum(1 for t in tiles if isinstance(t, dict) and t.get("kind") == "report") > 1:
        say(None, "The report's own table can be placed once.")
    # linked tiles (2026-10-30): ``links: {enabled: bool}`` on the canvas,
    # ``linked: bool`` on a tile -- both optional, on when absent
    links = canvas.get("links")
    if links is not None and not (isinstance(links, dict) and isinstance(links.get("enabled", True), bool)):
        say(None, "The canvas's linked-tiles setting must be on or off.")
    seen: set = set()
    boxes = []
    for t in tiles:
        if not isinstance(t, dict):
            say(None, "Every tile must be an object.")
            continue
        tid = t.get("id")
        if not isinstance(tid, str) or not _ID_RE.match(tid) or tid in seen:
            say(t, "its id is missing or used twice.")
        seen.add(tid)
        if "linked" in t and not isinstance(t.get("linked"), bool):
            say(t, "whether it follows clicks on other tiles must be on or off.")
        kind = t.get("kind")
        if kind not in TILE_KINDS:
            say(t, f'"{kind}" is not a kind of tile.')
            continue
        if len(str(t.get("title") or "")) > 200:
            say(t, "its title is longer than 200 characters.")
        lay = t.get("layout") if isinstance(t.get("layout"), dict) else {}
        x, y, w, h = (lay.get(k) for k in ("x", "y", "w", "h"))
        if not all(isinstance(v, int) and not isinstance(v, bool) for v in (x, y, w, h)) \
                or x < 0 or y < 0 or w < 1 or h < 1 or x + w > GRID_COLS or h > 60 or y + h > MAX_GRID_ROWS:
            say(t, "its place on the page is outside the 12-column grid.")
        else:
            boxes.append((t, x, y, w, h))
        if kind not in ("report", "band") and not has_dataset:
            say(t, "charts, pivots and number tiles need a report built on a dataset; "
                   "this report runs its own SQL, so it can show its table and its chart view.")
            continue
        if kind == "insight":       # its own rules: core/reports/canvas_insights.py
            from core.reports.canvas_insights import insight_problems
            for msg in insight_problems(t, cols=cols, selected=selected, grouped=grouped):
                say(t, msg)
            continue
        dims = t.get("dimensions") or []
        measures = t.get("measures") or []
        series = t.get("series")
        if not isinstance(dims, list) or not isinstance(measures, list):
            say(t, "its fields must be lists.")
            continue
        dim_ids = [_int(d) for d in dims]
        fields = list(dim_ids) + [_int(m.get("column_id")) if isinstance(m, dict) else None for m in measures]
        if series is not None:
            fields.append(_int(series))
        for fid in fields:
            if fid is None or fid not in cols:
                say(t, f"it uses a field that is no longer in the data ({'column #' + str(fid) if fid is not None else 'an unreadable field'}). Remove it from the tile.")
            elif fid not in selected:
                say(t, f"{_label(cols[fid], fid)} is not one of the report's columns, so the report does not return it. Add it to the report.")
        if len(set(dim_ids)) != len(dim_ids):
            say(t, "the same field is used twice.")
        for m in measures:
            if not isinstance(m, dict):
                say(t, "every value must name a column and a way to add up.")
                continue
            if m.get("aggregation") not in AGGREGATIONS:
                say(t, f'"{m.get("aggregation")}" is not a way to add up values.')
                continue
            # 2026-11-01 -- a value's own words ("Trades"): text, at most MAX_MEASURE_LABEL
            lab = m.get("label")
            if lab is not None and (not isinstance(lab, str) or len(lab.strip()) > MAX_MEASURE_LABEL):
                say(t, f"a value's name must be text of at most {MAX_MEASURE_LABEL} characters.")
            for msg in measure_problems(m, cols, grouped):
                say(t, msg)
        # values worked out from two others (2026-11-03): core/reports/canvas_derived.py
        from core.reports.canvas_derived import derived_problems
        derived_problems(t, say)
        om = t.get("other_mode")
        if om is not None and om not in ("fold", "none"):
            say(t, 'the rest of a pie / treemap is one part ("fold") or not drawn ("none").')
        oms = t.get("other_max_share")
        if oms is not None and (isinstance(oms, bool) or not isinstance(oms, (int, float)) or not 0.05 <= oms <= 0.9):
            say(t, '"Everything else" may take between 5 % and 90 % of the picture.')
        top_n = t.get("top_n")
        cap = max_points_of(kind, series)
        if top_n is not None and (not isinstance(top_n, int) or isinstance(top_n, bool) or not 1 <= top_n <= cap):
            say(t, f"it can draw between 1 and {cap:,} values.")
        if kind == "table" and not dims and not measures:
            say(t, "add at least one field.")
        elif kind == "pivot":
            if not dims:
                say(t, "needs at least one row field.")
            if series is None:
                say(t, "needs a column field to spread across.")
            elif _int(series) in dim_ids:
                say(t, "the column field is also a row field.")
            if not measures:
                say(t, "needs a value to show.")
        elif kind == "heatmap":
            if len(dims) != 1:
                say(t, "needs one row field.")
            if series is None:
                say(t, "needs a column field to spread across.")
            elif _int(series) in dim_ids:
                say(t, "the column field is also the row field.")
            if len(measures) != 1:
                say(t, "needs exactly one value to colour the cells by.")
        elif kind == "waterfall" and not dims and len(measures) != 1:
            # a bridge: one step per value (no category); every value added up
            if not 2 <= len(measures) <= MAX_BRIDGE_STEPS:
                say(t, f"a waterfall of values (no category) needs 2 to {MAX_BRIDGE_STEPS} values, one per step.")
            if series is not None:
                say(t, "cannot be split into series.")
            if any(isinstance(m, dict) and m.get("aggregation") != "sum" for m in measures):
                say(t, "a waterfall adds its values up as it goes, so each value must be added up (Sum).")
        elif kind in CHART_KINDS:
            if len(dims) != 1:
                say(t, "needs exactly one category field." if kind not in ("scatter", "bubble")
                    else "needs one field that names each point.")
            if kind in SERIES_CHARTS:
                if not 1 <= len(measures) <= MAX_SERIES_VALUES:
                    say(t, f"draws between 1 and {MAX_SERIES_VALUES} values.")
                if series is not None and len(measures) > 1:
                    say(t, "can be split by a series field OR show several values -- not both.")
            elif kind in ONE_VALUE_CHARTS:
                if len(measures) != 1:
                    say(t, "needs exactly one value to draw.")
                if series is not None:
                    say(t, "cannot be split into series.")
                if kind in SUM_ONLY and any(isinstance(m, dict) and m.get("aggregation") != "sum" for m in measures):
                    say(t, ("a waterfall adds its values up as it goes" if kind == "waterfall"
                            else "shows parts of a whole") + ", so its value must be added up (Sum).")
            elif kind == "combo":
                if not 2 <= len(measures) <= MAX_SERIES_VALUES:
                    say(t, f"needs 2 to {MAX_SERIES_VALUES} values: the first as bars, the rest as lines.")
                if series is not None:
                    say(t, "cannot be split into series.")
            elif kind == "scatter" and len(measures) != 2:
                say(t, "needs two values: across (x) and up (y).")
            elif kind == "bubble" and len(measures) != 3:
                say(t, "needs three values: across (x), up (y) and the bubble size.")
            if kind in ("scatter", "bubble") and series is not None:
                say(t, "cannot be split into series.")
            if series is not None and _int(series) in dim_ids:
                say(t, "the series field is also the category.")
        elif kind == "number" and (len(measures) != 1 or dims):
            say(t, "shows exactly one value and no fields.")
    from core.reports.canvas_outline import outline_problems   # the outline / band / formats (2026-10-30)
    outline_problems(canvas, tiles, cols=cols, selected=selected, grouped=grouped, say=say)
    # tiles may overlap across PAGES (2026-11-02), never on the same page
    page_of = {tid: k for k, p in enumerate(pages_of(canvas)) for tid in p["tile_ids"]}
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            _, ax, ay, aw, ah = boxes[i]
            tb, bx, by, bw, bh = boxes[j]
            if page_of.get(str(boxes[i][0].get("id"))) != page_of.get(str(tb.get("id"))):
                continue
            if ax < bx + bw and bx < ax + aw and ay < by + bh and by < ay + ah:
                say(tb, f"it sits on top of {_tile_name(boxes[i][0], cols)}.")
    # canvas actions (canvas_actions.py); ``action_targets`` names what each action's
    # source takes (the save route passes it; None = not checked here)
    out.extend(actions_problems(canvas, cols=cols, selected=selected, targets_for=action_targets))
    return out
