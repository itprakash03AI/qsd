"""Report themes -- the LOOK of a report is configuration (2026-11-01).

The owner: "blue band ... is configurable right so colour can be anything".
Until now the band's blue, the title's serif and the header grey were literals
in the band tile.  A theme is DATA:

    theme = {
      band:    {bg, fg, label_fg, font, show: [parameter names] | null},
      title:   {font, size, color, code_position: right | left | under | hidden},
      grid:    {header_bg, header_fg, subtotal: {bg, fg, bold}, grand: {bg, fg, bold},
                negative: red_brackets | brackets | red | minus, zebra, density: compact | normal | comfortable},
      numbers: {decimals, thousands, scale: none | K | M | B, currency},
      palette: [8 hex colours],
      tiles:   {radius, shadow, other_fill},
      -- theme v2 (2026-11-02, the report design upgrade) --
      page:    {bg, header_bg, header_fg, tabs: bar | chips | plain}      the page behind the cards; the header bar with the page tabs
      card:    {bg, border, fg, title_fg, title_align: left | center}      every tile's card
      kpi:     {style: plain | filled | gradient, fills: [hex...], value_fg, label_fg, up_fg, down_fg}
    }

A page / card colour may be the word "app" -- "as the app draws it" -- so a
theme from before (or a report with no theme) keeps today's look exactly;
a KPI fill is always a colour.  Absent sections = the default's.

* The SHIPPED themes are ``shipped_themes.json`` beside this module
  (``QueryStudio`` the default and 27 more in groups -- Everyday, Finance and
  statements, Executive, Analytics, Colour moods, Accessible, Print; each with a
  ``group`` and a ``description`` for the gallery; ``RENAMED`` keeps an old name
  resolving); the frontend holds the same file
  (``frontend/src/components/reports/canvas/shippedThemes.json``) and a test
  pins the two equal -- the browser must draw what the exports print.
* A library of named themes lives in ``report_themes`` (RELEASE, by name,
  ``is_active``; routes ``api/report_themes_api.py``).
* A report says ``layout_config.theme = {"name": "Finance Blue", ...overrides}``:
  ``name`` picks the base (the library first, then shipped, else the default)
  and every other key overrides a field.  Absent = the default theme, so an
  old report is byte-identical.
* ``theme_of`` is THE resolver (viewer, builder, exports); ``theme_problems``
  refuses a colour that is not ``#rrggbb``, an unknown choice, a contrast
  under 3:1 on the band or the grid header; ``theme_warnings`` says in plain
  words when a contrast is under 4.5:1 ("White on light blue would be hard to
  read").  ``grid_style`` hands the exports the FOUR values they already read
  (header colours, the negative style, zebra) from the theme.
"""
from __future__ import annotations

import copy
import json
import os
import re
from typing import Any, Dict, List, Optional, Tuple

_HERE = os.path.dirname(os.path.abspath(__file__))
_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
#: SECURITY (review 2026-11-01): every theme value reaches the browser's style
#: and the PDF's HTML -- a font is letters, digits, spaces, commas, quotes and
#: hyphens only (no ; { } ( ) : / \ < > or url()); a currency symbol is at most
#: 4 characters with no CSS / HTML metacharacter; a radius is a whole number
#: 0..32; a shadow is on / off.  ONE place: the save check refuses, every READ
#: (``theme_of``) sanitises back to the default, the exports read the resolved
#: (sanitised) theme and still check a colour before writing it.
_FONT = re.compile(r"^[A-Za-z0-9 ,'\-]{1,80}$")
_CURRENCY_BAD = re.compile(r"[<>&\"'`;{}()\\/:=]")
MAX_CURRENCY = 4
MAX_RADIUS = 32
ALLOWED_KEYS = {
    "": {"name", "group", "description", "band", "title", "grid", "numbers", "palette", "tiles", "page", "card", "kpi"},
    "band": {"bg", "fg", "label_fg", "font", "show"},
    "title": {"font", "size", "color", "code_position"},
    "grid": {"header_bg", "header_fg", "subtotal", "grand", "negative", "zebra", "density"},
    "grid.subtotal": {"bg", "fg", "bold"}, "grid.grand": {"bg", "fg", "bold"},
    "numbers": {"decimals", "thousands", "scale", "currency"},
    "tiles": {"radius", "shadow", "other_fill"},
    "page": {"bg", "header_bg", "header_fg", "tabs"},
    "card": {"bg", "border", "fg", "title_fg", "title_align"},
    "kpi": {"style", "fills", "value_fg", "label_fg", "up_fg", "down_fg"},
}
#: theme v2 vocabularies
KPI_STYLES = ("plain", "filled", "gradient")
TAB_STYLES = ("bar", "chips", "plain")
TITLE_ALIGNS = ("left", "center")
MAX_KPI_FILLS = 8
#: "as the app draws it" -- allowed for a page / card colour only
APP = "app"
#: a gradient KPI card runs from its fill to the fill this much darker
GRADIENT_SHADE = 0.22
#: what "app" stands for when a contrast is judged: the app's light surface and its text
APP_BG, APP_FG = "#ffffff", "#1d1d1f"

DEFAULT_THEME_NAME = "QueryStudio"
NEGATIVE_STYLES = ("red_brackets", "brackets", "red", "minus")
CODE_POSITIONS = ("right", "left", "under", "hidden")
DENSITIES = ("compact", "normal", "comfortable")
SCALES = ("none", "K", "M", "B")
PALETTE_SIZE = 8
#: refused below this (WCAG "large text" floor); warned below 4.5
CONTRAST_REFUSE = 3.0
CONTRAST_WARN = 4.5
MAX_THEME_NAME = 60
#: a theme's gallery words (2026-11-02): plain text, no markup characters
MAX_THEME_GROUP = 40
MAX_THEME_DESCRIPTION = 160
_TEXT_BAD = re.compile(r'[<>"`{}\\]')


def _load_shipped() -> Dict[str, Dict[str, Any]]:
    with open(os.path.join(_HERE, "shipped_themes.json"), "r", encoding="utf-8") as fh:
        return json.load(fh)


SHIPPED: Dict[str, Dict[str, Any]] = _load_shipped()


#: a shipped theme's OLD name -> its name now (2026-11-02: "PLEX" was one team's report, not a
#: theme; a report saved with it opens with the same look)
RENAMED: Dict[str, str] = {"PLEX": "Finance Blue"}


def shipped_name(name: str) -> str:
    return RENAMED.get(name, name)


def shipped_names() -> List[str]:
    return list(SHIPPED.keys())


# ── colour maths ────────────────────────────────────────────────────────────

def _lin(c: float) -> float:
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def luminance(hex_color: str) -> float:
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return 0.2126 * _lin(r) + 0.7152 * _lin(g) + 0.0722 * _lin(b)


def contrast_ratio(a: str, b: str) -> float:
    """WCAG contrast between two ``#rrggbb`` colours (1 .. 21)."""
    la, lb = luminance(a), luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return round((hi + 0.05) / (lo + 0.05), 2)


def _is_hex(v: Any) -> bool:
    return isinstance(v, str) and bool(_HEX.match(v))


def _is_hex_or_app(v: Any) -> bool:
    return v == APP or _is_hex(v)


def shade(hex_color: str, amount: float) -> str:
    """``hex_color`` mixed towards black by ``amount`` (0..1) -- the darker end of a gradient."""
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return "#%02x%02x%02x" % tuple(round(c * (1 - amount)) for c in (r, g, b))


def app_colour(v: Any, *, fg: bool = False) -> str:
    """A page / card colour as a hex for a check or a document: "app" = the
    app's light surface (or its text, ``fg``)."""
    return (APP_FG if fg else APP_BG) if v == APP else str(v)


def is_font(v: Any) -> bool:
    return isinstance(v, str) and bool(_FONT.match(v))


def is_currency(v: Any) -> bool:
    return isinstance(v, str) and len(v) <= MAX_CURRENCY and not _CURRENCY_BAD.search(v)


def is_radius(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= MAX_RADIUS


def plain_text(v: Any, limit: int) -> str:
    """A gallery word (group, description): text, no markup characters, bounded; else empty."""
    return v.strip()[:limit] if isinstance(v, str) and not _TEXT_BAD.search(v) else ""


def safe_hex(v: Any, default: str) -> str:
    """A colour for an export / a style: the value when it is ``#rrggbb``, else ``default``."""
    return v if _is_hex(v) else default


def unknown_keys(spec: Dict[str, Any]) -> List[str]:
    """Dotted names of every key a theme does not know (refused on save)."""
    out: List[str] = []

    def walk(d: Any, path: str) -> None:
        if not isinstance(d, dict):
            return
        allowed = ALLOWED_KEYS.get(path)
        for k, v in d.items():
            dotted = f"{path}.{k}" if path else str(k)
            if allowed is not None and k not in allowed:
                out.append(dotted)
                continue
            if isinstance(v, dict) and dotted in ALLOWED_KEYS:
                walk(v, dotted)
    walk(spec, "")
    return out


def sanitize(theme: Dict[str, Any]) -> Dict[str, Any]:
    """A RESOLVED theme made safe for a style sheet and an HTML template: every
    colour ``#rrggbb``, every font a plain family list, the radius / shadow /
    currency / decimals in range -- anything else is the DEFAULT theme's value.
    Applied by ``theme_of`` on every read (a library row written by hand, a
    release package, an old save)."""
    d = SHIPPED[DEFAULT_THEME_NAME]
    t = copy.deepcopy(theme)
    for sec in ("band", "title", "grid", "numbers", "tiles"):
        if not isinstance(t.get(sec), dict):
            t[sec] = {}
    band, title, grid, nums, tiles = t["band"], t["title"], t["grid"], t["numbers"], t["tiles"]
    for sec, key in (("band", "bg"), ("band", "fg"), ("band", "label_fg"), ("title", "color"), ("grid", "header_bg"), ("grid", "header_fg")):
        t[sec][key] = safe_hex(t[sec].get(key), d[sec][key])
    for row in ("subtotal", "grand"):
        r = grid.get(row) if isinstance(grid.get(row), dict) else {}
        grid[row] = {"bg": safe_hex(r.get("bg"), d["grid"][row]["bg"]), "fg": safe_hex(r.get("fg"), d["grid"][row]["fg"]),
                     "bold": r.get("bold") if isinstance(r.get("bold"), bool) else d["grid"][row]["bold"]}
    band["font"] = band.get("font") if is_font(band.get("font")) else d["band"]["font"]
    title["font"] = title.get("font") if is_font(title.get("font")) else d["title"]["font"]
    show = band.get("show")
    band["show"] = [str(x) for x in show if isinstance(x, str) and x] if isinstance(show, list) else None
    size = title.get("size")
    title["size"] = size if isinstance(size, (int, float)) and not isinstance(size, bool) and 10 <= size <= 48 else d["title"]["size"]
    title["code_position"] = title.get("code_position") if title.get("code_position") in CODE_POSITIONS else d["title"]["code_position"]
    grid["negative"] = grid.get("negative") if grid.get("negative") in NEGATIVE_STYLES else d["grid"]["negative"]
    grid["density"] = grid.get("density") if grid.get("density") in DENSITIES else d["grid"]["density"]
    grid["zebra"] = grid.get("zebra") if isinstance(grid.get("zebra"), bool) else d["grid"]["zebra"]
    dec = nums.get("decimals")
    nums["decimals"] = dec if isinstance(dec, int) and not isinstance(dec, bool) and 0 <= dec <= 10 else d["numbers"]["decimals"]
    nums["thousands"] = nums.get("thousands") if isinstance(nums.get("thousands"), bool) else d["numbers"]["thousands"]
    nums["scale"] = nums.get("scale") if nums.get("scale") in SCALES else d["numbers"]["scale"]
    nums["currency"] = nums.get("currency") if is_currency(nums.get("currency")) else ""
    pal = t.get("palette")
    t["palette"] = [c for c in pal if _is_hex(c)][:16] if isinstance(pal, list) and any(_is_hex(c) for c in pal) else list(d["palette"])
    tiles["radius"] = tiles.get("radius") if is_radius(tiles.get("radius")) else d["tiles"]["radius"]
    tiles["shadow"] = tiles.get("shadow") if isinstance(tiles.get("shadow"), bool) else d["tiles"]["shadow"]
    tiles["other_fill"] = safe_hex(tiles.get("other_fill"), d["tiles"]["other_fill"])
    # theme v2: the page, the cards, the KPI cards (an old save has none -> the default's)
    for sec in ("page", "card", "kpi"):
        if not isinstance(t.get(sec), dict):
            t[sec] = {}
    page, card, kpi = t["page"], t["card"], t["kpi"]
    for key in ("bg", "header_bg"):
        page[key] = page.get(key) if _is_hex_or_app(page.get(key)) else d["page"][key]
    page["header_fg"] = safe_hex(page.get("header_fg"), d["page"]["header_fg"])
    page["tabs"] = page.get("tabs") if page.get("tabs") in TAB_STYLES else d["page"]["tabs"]
    for key in ("bg", "border", "fg", "title_fg"):
        card[key] = card.get(key) if _is_hex_or_app(card.get(key)) else d["card"][key]
    card["title_align"] = card.get("title_align") if card.get("title_align") in TITLE_ALIGNS else d["card"]["title_align"]
    kpi["style"] = kpi.get("style") if kpi.get("style") in KPI_STYLES else d["kpi"]["style"]
    fills = kpi.get("fills")
    kpi["fills"] = ([c for c in fills if _is_hex(c)][:MAX_KPI_FILLS]
                    if isinstance(fills, list) and any(_is_hex(c) for c in fills) else list(d["kpi"]["fills"]))
    for key in ("value_fg", "label_fg", "up_fg", "down_fg"):
        kpi[key] = safe_hex(kpi.get(key), d["kpi"][key])
    t["name"] = str(t.get("name") or DEFAULT_THEME_NAME)[:MAX_THEME_NAME]
    t["group"] = plain_text(t.get("group"), MAX_THEME_GROUP)
    t["description"] = plain_text(t.get("description"), MAX_THEME_DESCRIPTION)
    return t


# ── resolution ──────────────────────────────────────────────────────────────

def _deep_merge(base: Dict[str, Any], over: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        elif v is not None:
            out[k] = copy.deepcopy(v)
    return out


def library_theme(db: Any, name: str) -> Optional[Dict[str, Any]]:
    """A named theme of the library (``report_themes``), or None.  Unreadable = None
    (the shipped names still resolve; a report never fails to open over a theme)."""
    if db is None or not name:
        return None
    try:
        row = db.get_report_theme_by_name(name) if hasattr(db, "get_report_theme_by_name") else None
    except Exception:                                        # noqa: BLE001
        return None
    return (row or {}).get("theme") if row else None


def theme_of(layout_config: Optional[Dict[str, Any]], db: Any = None) -> Dict[str, Any]:
    """THE resolved theme of a report: the named base + the report's overrides,
    every field present.  No theme = the default, byte for byte."""
    spec = (layout_config or {}).get("theme") if isinstance(layout_config, dict) else None
    default = copy.deepcopy(SHIPPED[DEFAULT_THEME_NAME])
    if not isinstance(spec, dict):
        out = default
        out["name"] = DEFAULT_THEME_NAME
        return sanitize(out)
    name = str(spec.get("name") or "").strip()
    base = library_theme(db, name) or SHIPPED.get(shipped_name(name))
    resolved = _deep_merge(default, base if isinstance(base, dict) else {})
    overrides = {k: v for k, v in spec.items() if k != "name"}
    resolved = _deep_merge(resolved, overrides)
    resolved["name"] = name or DEFAULT_THEME_NAME
    return sanitize(resolved)


#: a viewer's "View in another theme" pick travels as a theme NAME only, at most this long
MAX_VIEW_THEME_NAME = 100


def known_theme_name(name: Any, db: Any = None) -> Optional[str]:
    """The name when it names a theme the resolver knows -- the library's first,
    then a shipped one (an old name in ``RENAMED`` too) -- else None.  Never a
    set of colours: a viewer names a theme, the resolver supplies its values."""
    if not isinstance(name, str):
        return None
    n = name.strip()
    if not n or len(n) > MAX_VIEW_THEME_NAME:
        return None
    if library_theme(db, n) is not None or shipped_name(n) in SHIPPED:
        return n
    return None


def layout_in_theme(layout_config: Optional[Dict[str, Any]], name: Any, db: Any = None) -> Optional[Dict[str, Any]]:
    """The report's layout as a viewer looks at it in ANOTHER theme (2026-11-03,
    the viewer's "View in another theme"): a deep COPY of ``layout_config`` whose
    ``theme`` is ``{"name": name}`` -- the named theme with none of the report's
    own overrides, exactly what the browser draws.  None when the name is not a
    theme the resolver knows: the caller keeps the report's own theme.  The
    report's stored layout is never touched (the copy is the caller's to use)."""
    known = known_theme_name(name, db)
    if known is None:
        return None
    out = copy.deepcopy(layout_config) if isinstance(layout_config, dict) else {}
    out["theme"] = {"name": known}
    return out


def grid_style(theme: Dict[str, Any]) -> Dict[str, Any]:
    """What the exports read: header colours (no '#'), the negative style in
    the export's own vocabulary, zebra rows."""
    g = theme.get("grid") or {}
    neg = g.get("negative") or "red_brackets"
    return {"header_bg": str(g.get("header_bg") or "#1976d2").lstrip("#").upper(),
            "header_text": str(g.get("header_fg") or "#ffffff").lstrip("#").upper(),
            "negative_format": "brackets" if neg in ("brackets", "red_brackets") else "minus",
            "negative_red": neg in ("red", "red_brackets"),
            "stripe_rows": bool(g.get("zebra", True))}


# ── the save check ──────────────────────────────────────────────────────────

def theme_problems(spec: Any, db: Any = None) -> Tuple[List[str], List[str]]:
    """``(problems, warnings)`` for a report's ``layout_config.theme`` (or a
    library theme's body).  A problem refuses the save; a warning is said."""
    problems: List[str] = []
    warnings: List[str] = []
    if spec is None:
        return problems, warnings
    if not isinstance(spec, dict):
        return ["the look must be a set of named settings (a theme name and colours)."], warnings
    for k in unknown_keys(spec):
        problems.append(f'"{k}" is not a setting of a theme.')
    for sec in ("band", "title"):
        f = (spec.get(sec) or {}).get("font") if isinstance(spec.get(sec), dict) else None
        if f is not None and not is_font(f):
            problems.append(f"the {sec} font must be a font name of letters, digits, spaces, commas, quotes and hyphens "
                            f"(at most 80 characters), like Georgia, serif.")
    tiles = spec.get("tiles") if isinstance(spec.get("tiles"), dict) else {}
    if tiles.get("radius") is not None and not is_radius(tiles["radius"]):
        problems.append(f"the tile corner radius is a whole number from 0 to {MAX_RADIUS}.")
    if tiles.get("shadow") is not None and not isinstance(tiles["shadow"], bool):
        problems.append("the tile shadow is on or off.")
    cur = (spec.get("numbers") or {}).get("currency") if isinstance(spec.get("numbers"), dict) else None
    if cur is not None and not is_currency(cur):
        problems.append(f"the currency symbol is at most {MAX_CURRENCY} characters with no punctuation like < > & ; ( ) / :.")
    name = spec.get("name")
    if name is not None and (not isinstance(name, str) or not name.strip() or len(name) > MAX_THEME_NAME):
        problems.append(f"the theme name must be text of at most {MAX_THEME_NAME} characters.")
    elif isinstance(name, str) and name.strip() and shipped_name(name.strip()) not in SHIPPED and library_theme(db, name) is None:
        problems.append(f'there is no theme named "{name}". Pick one of: {", ".join(shipped_names())}, or a theme of the library.')
    colour_fields = (("band", "bg"), ("band", "fg"), ("band", "label_fg"), ("title", "color"),
                     ("grid", "header_bg"), ("grid", "header_fg"))
    for sec, key in colour_fields:
        v = (spec.get(sec) or {}).get(key) if isinstance(spec.get(sec), dict) else None
        if v is not None and not _is_hex(v):
            problems.append(f"{sec} {key.replace('_', ' ')} must be a colour like #1e6fd9.")
    for sec in ("subtotal", "grand"):
        row = (spec.get("grid") or {}).get(sec) if isinstance(spec.get("grid"), dict) else None
        if row is not None:
            if not isinstance(row, dict):
                problems.append(f"the {sec} row style must name its colours and whether it is bold.")
                continue
            for key in ("bg", "fg"):
                if row.get(key) is not None and not _is_hex(row[key]):
                    problems.append(f"the {sec} row's {key} must be a colour like #1e6fd9.")
            if row.get("bold") is not None and not isinstance(row["bold"], bool):
                problems.append(f"the {sec} row's bold must be on or off.")
    grid = spec.get("grid") if isinstance(spec.get("grid"), dict) else {}
    if grid.get("negative") is not None and grid["negative"] not in NEGATIVE_STYLES:
        problems.append("negatives show red in brackets, in brackets, red, or with a minus sign.")
    if grid.get("density") is not None and grid["density"] not in DENSITIES:
        problems.append("the grid's density is compact, normal or comfortable.")
    if grid.get("zebra") is not None and not isinstance(grid["zebra"], bool):
        problems.append("zebra rows is on or off.")
    title = spec.get("title") if isinstance(spec.get("title"), dict) else {}
    if title.get("code_position") is not None and title["code_position"] not in CODE_POSITIONS:
        problems.append("the report code sits right, left, under the title, or is hidden.")
    if title.get("size") is not None and (not isinstance(title["size"], (int, float)) or isinstance(title["size"], bool)
                                          or not 10 <= title["size"] <= 48):
        problems.append("the title size is between 10 and 48.")
    nums = spec.get("numbers") if isinstance(spec.get("numbers"), dict) else {}
    if nums.get("scale") is not None and nums["scale"] not in SCALES:
        problems.append("numbers are shown as they are, or in thousands (K), millions (M) or billions (B).")
    if nums.get("decimals") is not None and (not isinstance(nums["decimals"], int) or isinstance(nums["decimals"], bool)
                                             or not 0 <= nums["decimals"] <= 10):
        problems.append("decimals is a whole number from 0 to 10.")
    pal = spec.get("palette")
    if pal is not None and (not isinstance(pal, list) or not pal or len(pal) > 16 or not all(_is_hex(c) for c in pal)):
        problems.append("the palette is 1 to 16 colours like #1e6fd9.")
    band = spec.get("band") if isinstance(spec.get("band"), dict) else {}
    show = band.get("show")
    if show is not None and (not isinstance(show, list) or not all(isinstance(s, str) and s for s in show)):
        problems.append("the band's parameters are a list of parameter names.")
    problems.extend(_v2_problems(spec))
    if problems:
        return problems, warnings
    # contrast: on the RESOLVED theme (an override of one colour is judged against its base)
    resolved = theme_of({"theme": spec}, db)
    for words, fg, bg in contrast_pairs(resolved):
        ratio = contrast_ratio(fg, bg)
        if ratio < CONTRAST_REFUSE:
            problems.append(f"{words} ({fg} on {bg}) cannot be read -- contrast {ratio}:1, at least {CONTRAST_REFUSE:g}:1 is needed.")
        elif ratio < CONTRAST_WARN:
            warnings.append(f"{words} ({fg} on {bg}) would be hard to read -- contrast {ratio}:1; {CONTRAST_WARN:g}:1 reads comfortably.")
    return problems, warnings


def contrast_pairs(t: Dict[str, Any]) -> List[Tuple[str, str, str]]:
    """Every (words, fg, bg) a RESOLVED theme must keep readable -- the band, the
    grid header and totals (2026-11-01) and, since theme v2, the page header, the
    card's text and title, a KPI card's text on every fill (and on the darker end
    of a gradient), and the up / down colours on the card.  "app" is judged as the
    app's light surface / text.  The browser's ``contrastChecks`` lists the same."""
    page, card, kpi = t["page"], t["card"], t["kpi"]
    pairs = [("the band's text on its background", t["band"]["fg"], t["band"]["bg"]),
             ("the band's labels on its background", t["band"]["label_fg"], t["band"]["bg"]),
             ("the grid header's text on its background", t["grid"]["header_fg"], t["grid"]["header_bg"]),
             ("the subtotal row's text on its background", t["grid"]["subtotal"]["fg"], t["grid"]["subtotal"]["bg"]),
             ("the grand total's text on its background", t["grid"]["grand"]["fg"], t["grid"]["grand"]["bg"]),
             ("the page header's text on its bar", page["header_fg"], app_colour(page["header_bg"])),
             ("a card's text on the card", app_colour(card["fg"], fg=True), app_colour(card["bg"])),
             ("a card's title on the card", app_colour(card["title_fg"], fg=True), app_colour(card["bg"])),
             ("the 'up' colour on a card", kpi["up_fg"], app_colour(card["bg"])),
             ("the 'down' colour on a card", kpi["down_fg"], app_colour(card["bg"]))]
    for i, f in enumerate(kpi["fills"], 1):
        pairs.append((f"a KPI card's value on fill {i}", kpi["value_fg"], f))
        pairs.append((f"a KPI card's label on fill {i}", kpi["label_fg"], f))
        pairs.append((f"a KPI card's value on the darker end of fill {i}", kpi["value_fg"], shade(f, GRADIENT_SHADE)))
    return pairs


def _v2_problems(spec: Dict[str, Any]) -> List[str]:
    """The page / card / kpi sections, each value in its vocabulary (plain words)."""
    out: List[str] = []
    page = spec.get("page") if isinstance(spec.get("page"), dict) else {}
    card = spec.get("card") if isinstance(spec.get("card"), dict) else {}
    kpi = spec.get("kpi") if isinstance(spec.get("kpi"), dict) else {}
    for sec, key in (("page", "bg"), ("page", "header_bg"), ("card", "bg"), ("card", "border"), ("card", "fg"), ("card", "title_fg")):
        v = (page if sec == "page" else card).get(key)
        if v is not None and not _is_hex_or_app(v):
            out.append(f'{sec} {key.replace("_", " ")} must be a colour like #1e6fd9, or "app" (as the app draws it).')
    if page.get("header_fg") is not None and not _is_hex(page["header_fg"]):
        out.append("page header fg must be a colour like #1e6fd9.")
    if page.get("tabs") is not None and page["tabs"] not in TAB_STYLES:
        out.append("the page tabs are drawn as a bar, as chips, or plain.")
    if card.get("title_align") is not None and card["title_align"] not in TITLE_ALIGNS:
        out.append("a card's title sits left or in the centre.")
    if kpi.get("style") is not None and kpi["style"] not in KPI_STYLES:
        out.append("a KPI card is plain, filled or a gradient.")
    fills = kpi.get("fills")
    if fills is not None and (not isinstance(fills, list) or not fills or len(fills) > MAX_KPI_FILLS or not all(_is_hex(c) for c in fills)):
        out.append(f"the KPI card fills are 1 to {MAX_KPI_FILLS} colours like #1e6fd9.")
    for key in ("value_fg", "label_fg", "up_fg", "down_fg"):
        if kpi.get(key) is not None and not _is_hex(kpi[key]):
            out.append(f"kpi {key.replace('_', ' ')} must be a colour like #1e6fd9.")
    return out


def card_look(theme: Dict[str, Any]) -> Dict[str, Any]:
    """What a DOCUMENT prints of the page and the cards (Excel / PDF): hexes
    without '#', ``None`` where the theme says "app" (= the document's own
    default).  Every value passes ``safe_hex`` on the way."""
    def hx(v: Any) -> Optional[str]:
        return safe_hex(v, "").lstrip("#").upper() or None
    page, card, kpi = theme.get("page") or {}, theme.get("card") or {}, theme.get("kpi") or {}
    return {"page_bg": hx(page.get("bg")), "card_bg": hx(card.get("bg")), "card_border": hx(card.get("border")),
            "card_fg": hx(card.get("fg")), "card_title_fg": hx(card.get("title_fg")),
            "card_title_align": card.get("title_align") if card.get("title_align") in TITLE_ALIGNS else "left",
            "kpi_style": kpi.get("style") if kpi.get("style") in KPI_STYLES else "plain",
            "kpi_fills": [hx(c) for c in (kpi.get("fills") or []) if hx(c)],
            "kpi_value_fg": hx(kpi.get("value_fg")) or "FFFFFF", "kpi_label_fg": hx(kpi.get("label_fg")) or "FFFFFF",
            "kpi_up_fg": hx(kpi.get("up_fg")) or "1A7F4B", "kpi_down_fg": hx(kpi.get("down_fg")) or "C62828"}


# ── the library (report_themes) ─────────────────────────────────────────────

def library_problems(name: Any, theme: Any, db: Any = None) -> Tuple[List[str], List[str]]:
    problems: List[str] = []
    if not isinstance(name, str) or not name.strip():
        problems.append("a theme needs a name.")
    elif len(name) > MAX_THEME_NAME:
        problems.append(f"the theme name is at most {MAX_THEME_NAME} characters.")
    elif name in SHIPPED:
        problems.append(f'"{name}" is a shipped theme -- copy it under another name.')
    body = dict(theme or {}) if isinstance(theme, dict) else theme
    if isinstance(body, dict):
        body.pop("name", None)
    p2, w = theme_problems(body, db)
    return problems + p2, w


__all__ = ["sanitize", "safe_hex", "is_font", "is_currency", "is_radius", "unknown_keys", "SHIPPED", "DEFAULT_THEME_NAME", "NEGATIVE_STYLES", "CODE_POSITIONS", "DENSITIES", "SCALES",
           "shipped_names", "contrast_ratio", "theme_of", "grid_style", "theme_problems", "library_problems",
           "library_theme", "CONTRAST_REFUSE", "CONTRAST_WARN",
           "KPI_STYLES", "TAB_STYLES", "TITLE_ALIGNS", "MAX_KPI_FILLS", "APP", "GRADIENT_SHADE", "shade", "app_colour",
           "contrast_pairs", "card_look"]
