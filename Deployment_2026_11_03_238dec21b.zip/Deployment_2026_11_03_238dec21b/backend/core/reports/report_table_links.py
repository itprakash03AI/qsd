"""The report's OWN table follows linked tiles (2026-10-30, every report a canvas).

The owner: "we should mix both rather than categorizing canvas n normal
reports".  Every report is a canvas (``canvas.effective_canvas``) and its own
table is a tile like the others: when a bar, a slice or a row of another tile
is clicked, the table shows only the matching rows.

THE ONE RULE is ``canvas_links`` (same field = any of the values, different
fields = all, a clicked path exactly; the clicked tile, a ``linked: false``
tile and a canvas with links off are not filtered) and THE ONE READER is the
microcube's WHERE (``microcube._build_where``) over the run's stored,
row-secured result -- never a new query to the source, never a new run:

* the paged route (``GET .../results/{exec_id}?links=``) answers a page of
  the matching rows (:func:`linked_page`);
* the Excel / PDF exports write the matching rows to a file of their own
  (:func:`filtered_artifact`) and read it exactly as they read the whole
  result, so the table in the file is the table on the screen.

A filter that cannot be applied (a field the report does not have, a result
with no stored file) is REFUSED in words -- it never becomes "every row".
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from core.reports.canvas import effective_canvas, report_tile
from core.reports.canvas_links import LinkFilter, has_filter, path_steps, plain_slicers, tile_filter


class TableLinkRefused(ValueError):
    """The report's table cannot follow the clicked values (said in words)."""


def report_table_filter(report: dict, links: Sequence[Dict[str, Any]],
                        dataset_columns: Sequence[dict]) -> Tuple[Optional[LinkFilter], str]:
    """``(filter, words)`` for the report's own table; ``(None, '')`` when no
    link applies to it (no links, links off, the table set to not follow, or
    the canvas does not place the table)."""
    if not links:
        return None, ""
    canvas = effective_canvas((report or {}).get("layout_config") or {})
    tile = report_tile(canvas)
    if tile is None:
        return None, ""
    cols: Dict[int, dict] = {}
    for c in dataset_columns or []:
        try:
            cols[int(c.get("id"))] = c
        except (TypeError, ValueError):
            continue
    from core.reports.canvas_links import LinkError
    try:
        flt, words = tile_filter(tile, links, canvas, cols)
    except LinkError as exc:
        raise TableLinkRefused(f"The report's table cannot follow the clicked values: {exc}") from exc
    return (flt, words) if flt is not None and has_filter(flt) else (None, "")


def why_not_followed(report: dict, links: Sequence[Dict[str, Any]]) -> str:
    """The plain words for a table that does NOT follow the clicks sent."""
    canvas = effective_canvas((report or {}).get("layout_config") or {})
    tile = report_tile(canvas)
    if not links:
        return ""
    if isinstance(canvas.get("links"), dict) and canvas["links"].get("enabled") is False:
        return "Clicking a tile does not filter the others on this report, so the table shows every row."
    if tile is not None and tile.get("linked") is False:
        return "The report's table is set not to follow clicks on other tiles, so it shows every row."
    return ""


def _page_size(page_size: int, cfg) -> int:
    eff = page_size if page_size > 0 else cfg.business_reports.page_size
    return min(eff, cfg.business_reports.max_page_size)


def linked_page(artifact: str, flt: LinkFilter, words: str, page: int, page_size: int,
                sort_column: Optional[str], sort_direction: Optional[str], cfg) -> Dict[str, Any]:
    """One page of the table under the links -- the paged route's contract
    (``rows, columns, total_rows, page, page_size, total_pages``) plus
    ``linked: {applied, words}``.  ``total_rows`` counts the MATCHING rows.
    Synchronous: call it through ``asyncio.to_thread``."""
    from core.json_utils import sanitize_for_json
    from core.reports import microcube as mc
    eff = _page_size(page_size, cfg)
    try:
        records, cols, total = mc.read_artifact_rows(
            Path(artifact), path_filters=path_steps(flt), slicers=plain_slicers(flt),
            sort_column=sort_column, sort_direction=sort_direction,
            offset=(max(1, page) - 1) * eff, limit=eff,
            threads=cfg.business_reports.microcube_threads,
            memory_limit=cfg.business_reports.microcube_memory_limit)
    except mc.ArtifactNotReady as exc:
        raise TableLinkRefused(str(exc)) from exc
    except ValueError as exc:
        raise TableLinkRefused(
            "The report's table cannot follow the clicked values: a clicked field is not one of the "
            "columns this run returned. Run the report again, or clear the clicked values.") from exc
    return {
        "rows": sanitize_for_json(records),
        "columns": cols,
        "total_rows": total,
        "page": page,
        "page_size": eff,
        "total_pages": max(1, (total + eff - 1) // eff) if eff > 0 else 1,
        "linked": {"applied": True, "words": words},
    }


def filtered_artifact(artifact: str, flt: LinkFilter, out_dir: Optional[str] = None) -> Tuple[str, int]:
    """``(path, rows)`` -- the stored rows that match the links, written to a
    parquet file of their own (the caller removes it).  The microcube writes
    it, so the WHERE is the tiles' WHERE."""
    import tempfile
    from core.reports import microcube as mc
    fd, name = tempfile.mkstemp(prefix="qs_linked_table_", suffix=".parquet", dir=out_dir)
    import os
    os.close(fd)
    os.unlink(name)               # DuckDB's COPY creates the file
    try:
        n = mc.copy_artifact_rows(Path(artifact), Path(name), path_filters=path_steps(flt),
                                  slicers=plain_slicers(flt))
    except mc.ArtifactNotReady as exc:
        raise TableLinkRefused(str(exc)) from exc
    except ValueError as exc:
        raise TableLinkRefused(
            "The report's table cannot follow the clicked values: a clicked field is not one of the "
            "columns this run returned.") from exc
    return name, n


def table_note(words: str) -> str:
    """The note the report's table carries in an export when it follows links."""
    return f"Filtered by {words}." if words else ""


def discard(path: Optional[str]) -> None:
    if not path:
        return
    try:
        Path(path).unlink()
    except OSError:
        pass


__all__: List[str] = ["TableLinkRefused", "report_table_filter", "why_not_followed", "linked_page",
                      "filtered_artifact", "table_note", "discard"]
