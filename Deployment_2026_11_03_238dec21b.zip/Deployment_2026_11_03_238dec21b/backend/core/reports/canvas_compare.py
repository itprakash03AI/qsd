"""The COB comparison on the canvas (2026-11-01; FD-04 / 05 / 06).

``canvas.compare = {"parameter": "<a cob_compare parameter's name>"}``.  The
run binds the parameter's column ``IN (a, b)`` (core/reports/period.py), so
the stored result holds both dates; every tile with values reads each side
through the cube with a slicer on that column -- A, B, Variance (B - A),
% Variance -- and a number tile shows B with its change against A.  DECIMAL
end to end (the microcube adds as itself; Python subtracts ``Decimal``).

This module is the EXPORT's half and the save check; the browser's twin is
``frontend/src/components/reports/canvas/canvasCompare.tsx``.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any, Callable, Dict, List, Optional

MAX_PARAM_NAME = 100
COMPARE_HEADERS = ("A", "B", "Variance", "% Variance")


def compare_problems(canvas: dict, say: Callable[[Optional[dict], str], None]) -> None:
    c = canvas.get("compare")
    if c is None:
        return
    if not isinstance(c, dict) or not isinstance(c.get("parameter"), str) or not c["parameter"].strip() \
            or len(c["parameter"]) > MAX_PARAM_NAME:
        say(None, "The comparison must name the parameter that holds the two dates (a 'two dates to compare' parameter).")


def compare_setting(report: dict, parameters: Optional[List[dict]], run_values: Optional[dict]) -> Optional[Dict[str, Any]]:
    """``{column_id, a, b, words}`` when the report compares two dates and the
    run has both; None otherwise.  ``parameters`` = the report's parameter rows."""
    canvas = (report.get("layout_config") or {}).get("canvas") if isinstance(report.get("layout_config"), dict) else None
    c = (canvas or {}).get("compare") if isinstance(canvas, dict) else None
    if not isinstance(c, dict) or not c.get("parameter"):
        return None
    name = str(c["parameter"])
    p = next((x for x in (parameters or []) if isinstance(x, dict) and x.get("name") == name), None)
    if not p or str(p.get("parameter_type") or "") != "cob_compare" or not p.get("lov_column_id"):
        return {"error": f"The comparison names '{name}', which is not a 'two dates to compare' parameter bound to a date column."}
    v = (run_values or {}).get(name)
    if isinstance(v, str) and ".." in v:
        a, b = v.split("..", 1)
        v = {"a": a.strip(), "b": b.strip()}
    if not isinstance(v, dict) or not v.get("a") or not v.get("b"):
        return {"error": f"The comparison '{p.get('label') or name}' has no two dates for this run."}
    return {"column_id": int(p["lov_column_id"]), "a": str(v["a"]), "b": str(v["b"]),
            "words": f"{p.get('label') or name}: {v['a']} (A) vs {v['b']} (B)"}


def _dec(v: Any) -> Optional[Decimal]:
    if v is None or isinstance(v, bool):
        return None
    try:
        return v if isinstance(v, Decimal) else Decimal(str(v))
    except (InvalidOperation, ValueError):
        return None


def variance(a: Any, b: Any) -> Dict[str, Any]:
    """``{variance, pct}`` -- B - A and (B - A) / |A| * 100 (None when A is 0 / missing)."""
    da, db_ = _dec(a), _dec(b)
    if da is None and db_ is None:
        return {"variance": None, "pct": None}
    da = da if da is not None else Decimal(0)
    db_ = db_ if db_ is not None else Decimal(0)
    var = db_ - da
    pct = None if da == 0 else (var / abs(da) * 100).quantize(Decimal("0.01"))
    return {"variance": var, "pct": pct}


def compare_rows(rows_a: List[dict], rows_b: List[dict], dims: List[str], n_measures: int) -> List[list]:
    """Join two drills by their dimension values: per row the dims, then per
    measure A, B, Variance, %.  O(|A| + |B|): each side is indexed ONCE
    (security review 2026-11-01 -- the first cut rebuilt a set per row)."""
    key = lambda r: tuple(r.get(d) for d in dims)             # noqa: E731
    by_a: Dict[tuple, dict] = {}
    for r in rows_a:
        by_a.setdefault(key(r), r)
    by_b: Dict[tuple, dict] = {}
    for r in rows_b:
        by_b.setdefault(key(r), r)
    order = list(by_a) + [k for k in by_b if k not in by_a]
    out: List[list] = []
    for k in order:
        ra, rb = by_a.get(k), by_b.get(k)
        line = list(k)
        for i in range(n_measures):
            va = ra.get(f"v{i}__") if ra else None
            vb = rb.get(f"v{i}__") if rb else None
            vv = variance(va, vb)
            line += [va, vb, vv["variance"], vv["pct"]]
        out.append(line)
    return out


def compare_entry(entry: dict, t: dict, path, cols: Dict[int, dict], phys, dims_ids: List[int], ms: List[dict],
                  measures: List[dict], setting: Dict[str, Any], drill_all, measure_header, fmt,
                  *, grain: str, group_columns, budget, slicers=None) -> None:
    """Fill an export entry of a number / table tile with A, B, Variance, % per value."""
    from core.reports.canvas_links import merge_slicers
    col_name = phys(setting["column_id"])
    if not col_name:
        entry["note"] = "The comparison's date column is not in this run."
        return
    dims = [phys(d) for d in dims_ids] if t.get("kind") != "number" else []
    width = max(1, len(dims) + 4 * len(ms))
    limit = max(1, min(50_000, budget[0] // width))
    sides = []
    for side in ("a", "b"):
        sl = merge_slicers(slicers, {col_name: [setting[side]]}) if slicers else {col_name: [setting[side]]}
        res = drill_all(path, dims, measures, sort_column=dims[0] if dims else None, sort_direction="asc",
                        grain=grain, group_cols=group_columns, limit=limit, slicers=sl)
        sides.append(res["rows"])
    header = [cols.get(d, {}).get("friendly_name") or cols.get(d, {}).get("physical_name") or f"column #{d}" for d in dims_ids] if dims else []
    fmts = [fmt(cols.get(d)) for d in dims_ids] if dims else []
    for m in ms:
        mh = measure_header(m, cols)
        header += [f"{mh} {setting['a']}", f"{mh} {setting['b']}", f"{mh} variance", f"{mh} % variance"]
        mf = fmt(cols.get(int(m["column_id"])))
        fmts += [mf, mf, mf, "0.00"]
    entry["header"] = header
    entry["formats"] = fmts
    entry["rows"] = compare_rows(sides[0], sides[1], dims, len(ms))
    entry["compare"] = {"a": setting["a"], "b": setting["b"]}
    budget[0] -= len(entry["rows"]) * width
    entry["note"] = (f"{setting['words']}. " + (entry.get("note") or "")).strip()


__all__ = ["compare_problems", "compare_setting", "variance", "compare_rows", "compare_entry", "COMPARE_HEADERS"]
