"""Every dropdown's list lives in PostgreSQL (2026-11-01).

The owner: "not in pod memory ... we should have list maintained in postgres
db ... each dropdown should have query etc ... user should be able to define
distinct column's values on source table without where clause ... partition
columns we already store and that should be available by default from
postgres".

ONE model, no second road: a dropdown / multi-select parameter bound to a
column OWNS a ``value_lists`` row (core/value_lists.py -- the same table, the
same sync daemon, the same ``serve`` under the viewer's entitlement).  The
link is BY NAME (``owner_kind = 'parameter'``, ``owner_report_id``,
``owner_param_name``), never by the parameter's id: a batch save REPLACES the
parameter rows (new ids), and a list keyed on the id would be orphaned on
every save.  So nothing was added to ``report_parameters``; an old report
gets its lists on first use.

* ``definition_for`` -- the list's DEFAULT query: the parameter's column TRACED
  through the dataset's SQL to its source table (core/reports/column_lineage)
  -> ``SELECT DISTINCT <col> FROM <table>`` -- NO WHERE from the dataset; a
  cascade child whose parent traces to the SAME table reads
  ``SELECT DISTINCT <col>, <parent col>`` with ``parent_column`` set, so the
  narrowing is answered from PostgreSQL (``attrs.parents``); a PARTITION
  column becomes ``source_type = 'partition'`` -- its values come from the
  partition metadata already recorded, no data is scanned; an untraceable
  column (a computed one, a UNION, two connections) is NOT given a list and
  the reason is said (``trace_note``) -- the live DISTINCT road stays for it.
* ``ensure`` -- find the list by name or create it (and sync it in the
  background); ``after_save`` runs it for every eligible parameter of a
  report after the batch / create / update routes.
* ``choices`` -- the viewer's answer FROM PostgreSQL: ``value_lists.serve``
  (entitled keys by name; the live-under-RLS rule when a row policy makes the
  snapshot unsafe -- said in ``live_reason``), narrowed by the parent's picks
  through ``attrs.parents``; a list never filled says so (never a bare []).
* ``describe`` -- what the EDITOR sees: the query, the status, the count, why
  it is read live, how to refresh.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

OWNER_KIND = "parameter"
#: (2026-11-01) a date / date range bound to a column owns a list too -- the dates
#: that have data, which the band offers as a dropdown and which the default rule
#: "latest with data" reads (param_contract admits that rule for dates; without a
#: list it could never resolve).  values_source "any" keeps a date calendar-only.
LIST_TYPES = ("dropdown", "multi_select", "date", "date_range")
#: the values_source spellings whose list is the parameter's OWN (``auto``
#: included: it is the default); static / any / list / table keep their roads
OWN_LIST_SOURCES = (None, "", "auto", "data", "metadata")
SOURCE_PARTITION = "partition"
#: a sync kicked by a save that takes longer than this is left to the daemon
SYNC_IN_REQUEST_SECONDS = 10.0


def list_name(report_id: int, param_name: str) -> str:
    return f"param:{int(report_id)}:{param_name}"


def eligible(param: Dict[str, Any]) -> bool:
    """A dropdown / multi-select bound to a column whose choices are not static,
    a calendar, a named list or another table."""
    return (str(param.get("parameter_type") or "") in LIST_TYPES
            and bool(param.get("lov_column_id"))
            and not param.get("source_column")
            and (param.get("values_source") in OWN_LIST_SOURCES)
            and not [v for v in (param.get("static_values") or []) if v not in (None, "")])


#: a plain identifier goes into the SQL as written (an unquoted name folds the way
#: the engine folds it -- quoting one would make Oracle / Snowflake case-sensitive)
_PLAIN_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_$#]*$")
MAX_IDENT = 128


def _quote(name: Any) -> str:
    """SECURITY (review 2026-11-01): an identifier is NEVER passed through as it
    came.  A plain name stays plain; anything else -- a quoted name, a space, a
    dot, a quote, SQL -- becomes ONE quoted identifier with its quotes doubled,
    so nothing in it can end the identifier.  Too long / empty is refused."""
    n = str(name if name is not None else "").strip()
    was_quoted = len(n) > 1 and n[0] == '"' and n[-1] == '"'
    if was_quoted:
        n = n[1:-1].replace('""', '"')
    if not n or len(n) > MAX_IDENT:
        raise ValueError("a column name is missing or longer than 128 characters")
    return n if _PLAIN_IDENT.match(n) and not was_quoted else '"' + n.replace('"', '""') + '"'


def _table_parts(table: Any) -> List[str]:
    """``catalog.schema.table`` split on the dots OUTSIDE quotes (1 to 3 parts)."""
    s = str(table if table is not None else "").strip()
    parts, cur, inq = [], "", False
    for ch in s:
        if ch == '"':
            inq = not inq
            cur += ch
        elif ch == "." and not inq:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    parts.append(cur)
    if not 1 <= len(parts) <= 3 or any(not p.strip() for p in parts):
        raise ValueError(f"'{s}' is not a table name (catalog.schema.table)")
    return parts


def quote_table(table: Any) -> str:
    """The table as SQL: each part an identifier (``_quote``)."""
    return ".".join(_quote(p) for p in _table_parts(table))


def _norm_table(table: Any) -> str:
    return ".".join(p.strip().strip('"').lower() for p in _table_parts(table))


def dataset_tables(fed, ds: Dict[str, Any]) -> Optional[set]:
    """The tables the dataset ITSELF reads, normalised: its ``source_tables`` and
    the tables of its SQL (parsed as the engine's dialect).  None = cannot be
    told (the SQL does not parse and no table is declared)."""
    names = set()
    for t in ds.get("source_tables") or []:
        if isinstance(t, dict) and t.get("table"):
            try:
                names.add(_norm_table(t["table"]))
            except ValueError:
                continue
    sql = str(ds.get("base_query") or "").strip()
    if sql:
        from core import value_lists as vlm
        try:
            dialect = fed.dataset_sql_dialect(ds) or ""
        except Exception:                                     # noqa: BLE001
            dialect = ""
        parsed = vlm.source_tables(sql, dialect)
        if parsed is None and not names:
            return None
        for t in parsed or []:
            try:
                names.add(_norm_table(t))
            except ValueError:
                continue
    return names


def table_allowed(fed, ds: Dict[str, Any], table: Any) -> Optional[str]:
    """SECURITY (review 2026-11-01): the list's query runs WITHOUT a user (the
    sync), so its table is only ever one the dataset itself reads.  The plain
    reason when it is not, else None."""
    try:
        wanted = _norm_table(table)
    except ValueError as exc:
        return str(exc)
    allowed = dataset_tables(fed, ds)
    if allowed is None:
        return "the dataset's query could not be read to confirm the table, so no list is made"
    if wanted not in allowed:
        return f"'{table}' is not a table the dataset reads, so no list is made for it"
    return None


def default_sql(table: str, column: str, parent_column: Optional[str] = None) -> str:
    """The owner's rule: DISTINCT on the SOURCE table, no WHERE.  Every
    identifier goes through ``_quote`` / ``quote_table`` (ValueError when one
    is not a name)."""
    cols = _quote(column) + (f", {_quote(parent_column)}" if parent_column else "")
    return f"SELECT DISTINCT {cols} FROM {quote_table(table)}"


def _column_of(ds: Dict[str, Any], column_id: Any) -> Optional[Dict[str, Any]]:
    return next((c for c in (ds.get("columns") or []) if c.get("id") == column_id), None)


async def definition_for(fed, db, report: Dict[str, Any], params: List[Dict[str, Any]],
                         param: Dict[str, Any], user: Dict[str, Any]) -> Dict[str, Any]:
    """The list this parameter should own, or ``{"reason": ...}`` when the
    column cannot be traced to one source table.  Never raises."""
    from core.reports.param_choices import _trace
    from core.reports import param_values as pv
    from api.business_reports_api import _resolve_lov_dataset_id
    ds_id = _resolve_lov_dataset_id(report, db)
    if not ds_id:
        return {"reason": "The report has no dataset to read the choices from."}
    ds = db.get_dataset_full(int(ds_id)) or {}
    col = _column_of(ds, param.get("lov_column_id"))
    if not col:
        return {"reason": f"Column {param.get('lov_column_id')} is not in the report's dataset."}
    src = _trace(fed, ds, col)
    if not src.get("table"):
        return {"reason": src.get("reason") or "The column could not be traced to one source table, so its "
                                               "choices are read from the report's own data."}
    not_allowed = table_allowed(fed, ds, src["table"])
    if not_allowed:
        return {"reason": f"The traced table was refused: {not_allowed}."}
    # a cascade child: its parent must trace to the SAME table to be answered from the list
    parent_column = None
    if param.get("depends_on_param_id") and param.get("cascade_filter_column_id"):
        pcol = _column_of(ds, param.get("cascade_filter_column_id"))
        psrc = _trace(fed, ds, pcol) if pcol else {}
        if psrc.get("table") and str(psrc["table"]).lower() == str(src["table"]).lower():
            parent_column = psrc["column"]
    # a partition column: the recorded partition values, no scan
    is_partition = False
    try:
        look = await pv.partition_values(db, dataset_id=int(ds_id), column_id=param["lov_column_id"], user=user or {},
                                         temporal=False)
        # (rig 2026-11-01) a partition read that was CUT (a SQL source answers at most
        # SQL_PARTITION_VALUES_MAX) is not the whole list: the list runs its query
        is_partition = bool(look.is_partition) and not parent_column and not look.truncated
    except Exception as exc:                                  # noqa: BLE001
        logger.info("[param-lists] partition check skipped: %s", exc)
    try:
        sql = default_sql(src["table"], src["column"], parent_column)
    except ValueError as exc:
        return {"reason": f"The list's query could not be written: {exc}."}
    return {
        "name": list_name(int(report["id"]), str(param["name"])),
        "description": f"The choices of parameter '{param.get('label') or param['name']}' of report "
                       f"'{report.get('name')}' -- made by QueryStudio; edit the query if the list should be different.",
        "source_type": SOURCE_PARTITION if is_partition else "query",
        "connection_id": int(src["connection_id"]),
        "source_sql": sql,
        "key_column": src["column"], "label_column": None, "parent_column": parent_column,
        "sync_mode": "daily", "sync_every_hours": 24,
        "owner_kind": OWNER_KIND, "owner_report_id": int(report["id"]), "owner_param_name": str(param["name"]),
        "_table": src["table"], "_dataset_id": int(ds_id), "_column_id": param["lov_column_id"],
    }


def find(db, report_id: int, param_name: str) -> Optional[Dict[str, Any]]:
    return db.get_parameter_choices_list(int(report_id), str(param_name))


def sync_partition(db, vl: Dict[str, Any], *, by: str = "") -> Dict[str, Any]:
    """Fill a PARTITION list from the recorded partition metadata (no scan).
    Called by ``value_lists.sync`` for ``source_type = 'partition'``."""
    from core.reports import param_values as pv
    t0 = time.monotonic()
    report_id, param_name = vl.get("owner_report_id"), vl.get("owner_param_name")
    try:
        report = db.get_business_report(int(report_id)) if report_id else None
        params = db.list_report_parameters(int(report_id)) if report_id else []
        param = next((p for p in params if p.get("name") == param_name), None)
        if not report or not param:
            raise RuntimeError("the parameter that owns this list is gone")
        from api.business_reports_api import _resolve_lov_dataset_id
        ds_id = _resolve_lov_dataset_id(report, db)
        look = asyncio.run(pv.partition_values(db, dataset_id=int(ds_id), column_id=param["lov_column_id"],
                                               user={"role": "admin", "is_admin": True},
                                               temporal=param.get("parameter_type") in pv.DATE_TYPES))
        if not look.is_partition:
            raise RuntimeError(look.reason or "the column is not a partition column any more")
        if look.truncated:
            # (rig 2026-11-01) the partition read was CUT -- 200 of 740 business dates were
            # stored as the whole list.  A cut list is never stored as complete: read the
            # list's own DISTINCT query instead (every value), and say so.
            # The list BECOMES a query list (security review of 7e2e33140): values read by
            # its query are refreshed and SERVED by the query rules (value_lists.needs_live
            # checks the query's tables for row policies / entitlement dimensions; a live
            # read runs the query under the viewer's own row security), and its words say
            # where they come from -- a partition list's live read is the capped metadata.
            from core import value_lists as vlm
            logger.info("[param-lists] %r: the recorded partitions were cut at %d values; it becomes a "
                        "query list and reads its query", vl.get("name"), len(look.values or []))
            db.update_value_list(int(vl["id"]), {"source_type": "query"}, by=by or "param-lists")
            # read here, not through value_lists.sync: this runs INSIDE sync's per-list lock
            cols, rows = vlm.run_query(db, vl["connection_id"], vl["source_sql"], None)
            items = vlm._ordered(vl, vlm.items_from_rows(cols, rows, vl["key_column"], vl.get("label_column"),
                                                         vl.get("parent_column")))
        else:
            items = [{"key": str(v), "label": None, "sort_order": i, "attrs": None}
                     for i, v in enumerate(look.values or [])]
    except Exception as exc:                                  # noqa: BLE001
        msg = f"{type(exc).__name__}: {exc}" if not isinstance(exc, RuntimeError) else str(exc)
        logger.warning("[param-lists] partition sync of %r failed: %s", vl.get("name"), msg)
        return db.record_value_list_failure(int(vl["id"]), msg[:2000], by=by)
    return db.replace_value_list_items(int(vl["id"]), items, by=by, seconds=round(time.monotonic() - t0, 3))


def _kick_sync(db, list_id: int, by: str) -> None:
    """A sync in the background: the save answers at once; the list says
    "being prepared" until it lands; the daemon retries a failed one."""
    from core import value_lists as vlm

    def _run():
        try:
            vlm.sync(db, int(list_id), by=by)
        except Exception as exc:                              # noqa: BLE001
            # (rig 2026-11-01) the reason is the LIST's status (the editor reads it), not only a log line
            logger.warning("[param-lists] background sync of list %s failed: %s", list_id, exc)
            try:
                db.record_value_list_failure(int(list_id), f"{type(exc).__name__}: {exc}"[:2000], by=by)
            except Exception as exc2:                         # noqa: BLE001
                logger.warning("[param-lists] the failure of list %s could not be recorded: %s", list_id, exc2)
    try:
        loop = asyncio.get_running_loop()
        loop.run_in_executor(None, _run)
    except RuntimeError:
        _run()


async def ensure(fed, db, report: Dict[str, Any], params: List[Dict[str, Any]], param: Dict[str, Any],
                 user: Dict[str, Any], *, sync_now: bool = True) -> Dict[str, Any]:
    """The parameter's list: found by name, else made (and synced in the
    background).  Returns ``{"list": vl}`` or ``{"reason": words}``."""
    if not eligible(param):
        return {"reason": "This parameter's choices do not come from its own list."}
    existing = await asyncio.to_thread(find, db, int(report["id"]), str(param["name"]))
    if existing:
        return {"list": existing}
    d = await definition_for(fed, db, report, params, param, user)
    if not d.get("name"):
        return {"reason": d.get("reason")}
    data = {k: v for k, v in d.items() if not k.startswith("_")}
    try:
        vl = await asyncio.to_thread(db.create_value_list, data, (user or {}).get("username", ""))
    except Exception as exc:                                  # noqa: BLE001
        # (rig 2026-11-02) the save's background build and a Refresh now race to MAKE the same
        # list: the loser met the unique name and answered 422 -- the list it wanted exists
        again = await asyncio.to_thread(find, db, int(report["id"]), str(param["name"]))
        if again:
            return {"list": again}
        logger.warning("[param-lists] could not make the list for %s: %s", d["name"], exc)
        return {"reason": f"The list could not be made: {exc}"}
    if sync_now:
        _kick_sync(db, vl["id"], (user or {}).get("username", ""))
    return {"list": vl, "made": True, "table": d.get("_table")}


async def after_save(fed, db, report: Dict[str, Any], params: List[Dict[str, Any]], user: Dict[str, Any]) -> None:
    """Best effort after a parameter save: every eligible parameter gets its
    list.  Never fails the save."""
    for p in params or []:
        try:
            await ensure(fed, db, report, params, p, user)
        except Exception as exc:                              # noqa: BLE001
            logger.info("[param-lists] after_save skipped %s: %s", p.get("name"), exc)


async def stored_list_for(db, report: Dict[str, Any], param: Dict[str, Any], reader: Optional[Dict[str, Any]],
                          may_see) -> Optional[Dict[str, Any]]:
    """The stored list a VIEWER may be served, or None (SECURITY review 2026-11-01).

    The list is every distinct value of the SOURCE table, so it is served by
    exactly the rule a traced read follows (core/reports/param_choices.py):
    * NO reader (a share / embed token) -> None: a token gets the query's own
      literals / the report's own result road, never a source-table list;
    * an app reader must be allowed to see the list's CONNECTION
      (``may_see(conn, reader)``, THE connections' rule) -> else None;
    * nothing is CREATED here: a list is made by an author's save
      (``after_save``) or the author's Refresh now -- a viewer read with no
      list yet takes the live road and the editor is told it is not built.
    """
    if not reader or not eligible(param):
        return None
    vl = await asyncio.to_thread(find, db, int(report["id"]), str(param["name"]))
    if not vl:
        return None
    try:
        conn = await asyncio.to_thread(db.get_connection, int(vl["connection_id"])) if vl.get("connection_id") else None
    except Exception:                                         # noqa: BLE001
        conn = None
    if not conn or not await may_see(conn, reader):
        return None
    return vl


def may_manage(db, vl: Dict[str, Any], user: Dict[str, Any], can_edit_report) -> bool:
    """ONE rule for every value-list route that CHANGES a list (edit, sync,
    items, delete): a list a report parameter owns is managed by whoever may
    EDIT that report (``can_edit_report(report, user)``), nobody else -- not
    its recorded author, not the viewer who happened to read it.  Any other
    list keeps the route's own rule (``None`` = not decided here)."""
    if vl.get("owner_kind") != OWNER_KIND:
        return None
    rid = vl.get("owner_report_id")
    report = db.get_business_report(int(rid)) if rid else None
    if not report:
        return False
    return bool(can_edit_report(report, user))


def _parents_of(parent_values: Dict[str, Any], params: List[Dict[str, Any]], param: Dict[str, Any]) -> Optional[set]:
    parent = next((x for x in params if x.get("id") == param.get("depends_on_param_id")), None)
    if not parent:
        return None
    val = (parent_values or {}).get(parent["name"])
    if isinstance(val, (list, tuple)):
        vals = {str(v) for v in val if v not in (None, "")}
        return vals or None
    return {str(val)} if val not in (None, "") else None


async def choices(db, vl: Dict[str, Any], param: Dict[str, Any], params: List[Dict[str, Any]], user: Dict[str, Any], *,
                  search: Optional[str], parent_values: Dict[str, Any], limit: int) -> Optional[Dict[str, Any]]:
    """The viewer's choices FROM PostgreSQL, or None when the list cannot
    answer here (a cascade the list does not carry -> the live road)."""
    from core import value_lists as vlm
    parents = _parents_of(parent_values, params, param)
    if parents and not vl.get("parent_column"):
        return None
    if vl.get("last_status") == "never" and not (vl.get("value_count") or 0):
        return {"values": [], "source": "list", "list": vl["name"], "status": "never", "limit": limit,
                "reason": "This list is being prepared (its first fill has not finished). Open the dropdown "
                          "again in a moment, or ask the report's owner to press Refresh now."}
    # a date's list from its NEWEST end (rig 2026-11-01: 740 dates, cap 500, oldest
    # first -> the band's previous date from 30-Oct-2026 was 28-Nov-2025)
    ans = await asyncio.to_thread(vlm.serve, db, int(vl["id"]), user, search=search, limit=limit,
                                  with_attrs=bool(parents),
                                  newest_first=str(param.get("parameter_type") or "") in ("date", "date_range"))
    vals = ans.pop("values")
    if parents:
        vals = [v for v in vals if set(map(str, ((v.get("attrs") or {}).get("parents") or []))) & parents]
    # (rig 2026-11-01) the hint under the dropdown in a person's words -- never the list's internal name
    ans["list_words"] = list_words(param, ans)
    return {**ans, "values": [v["key"] for v in vals],
            "labels": {v["key"]: v.get("label") for v in vals if v.get("label")}, "limit": limit}


def list_words(param: Dict[str, Any], ans: Dict[str, Any]) -> str:
    """'From QueryStudio's stored list for Region (refreshed 07:18)' -- the
    viewer's hint; a list read live says so."""
    label = str(param.get("label") or param.get("name") or "this parameter")
    if ans.get("source") == "list-live":
        return f"From QueryStudio's stored list for {label}, read live for you"
    when = str(ans.get("synced_at") or "")
    clock = when[11:16] if len(when) >= 16 and when[10] in "T " else ""
    return f"From QueryStudio's stored list for {label}" + (f" (refreshed {clock})" if clock else "")


def refresh_now(db, vl: Dict[str, Any], *, by: str) -> Dict[str, Any]:
    """The author's Refresh now (rig 2026-11-01): when a sync of this list is
    already running -- the save's background build -- say so and answer the
    list as it is; else sync (serialized) and answer the result.  Never a 500."""
    from core import value_lists as vlm
    if vlm.in_flight(int(vl["id"])):
        out = describe(vl, None, live_reason=vlm.needs_live(db, vl))
        out["refreshing"] = True
        out["words"] = vlm.REFRESHING_WORDS
        return out
    done = vlm.sync(db, int(vl["id"]), by=by)
    return describe(done, None, live_reason=vlm.needs_live(db, done))


def describe(vl: Optional[Dict[str, Any]], reason: Optional[str], *, live_reason: Optional[str] = None) -> Dict[str, Any]:
    """What the editor is told about a parameter's list, in plain words."""
    if not vl:
        return {"has_list": False, "words": reason or "This parameter has no list of its own yet -- it is made "
                                                       "when the report is saved."}
    n = int(vl.get("value_count") or 0)
    status = vl.get("last_status")
    if status == "ok":
        words = f"{n:,} values, kept in QueryStudio's database; last refreshed {str(vl.get('last_synced_at') or '')[:16].replace('T', ' ')}."
    elif status == "failed":
        words = f"The last refresh failed ({vl.get('last_error')}); the previous {n:,} values are still offered."
    elif status == "too_big":
        # 2026-11-02: over the cap -- not kept; searched at the source as you type
        words = str(vl.get("last_error") or "This list has more values than a list of choices holds, so it is not kept; "
                                             "the dropdown searches the source as you type")
    else:
        words = "Being prepared -- its first fill has not finished."
    if vl.get("source_type") == SOURCE_PARTITION:
        words += " The values come from the table's recorded partitions -- no data is scanned."
    if live_reason:
        words += f" For people under a row policy it is read live and filtered for them ({live_reason})."
    return {"has_list": True, "id": vl["id"], "name": vl["name"], "source_type": vl.get("source_type"),
            "source_sql": vl.get("source_sql"), "key_column": vl.get("key_column"), "label_column": vl.get("label_column"),
            "parent_column": vl.get("parent_column"), "connection_id": vl.get("connection_id"),
            "sync_mode": vl.get("sync_mode"), "sync_every_hours": vl.get("sync_every_hours"),
            "last_status": status, "last_synced_at": vl.get("last_synced_at"), "value_count": n,
            "last_error": vl.get("last_error"), "live_reason": live_reason, "words": words}


__all__ = ["OWNER_KIND", "LIST_TYPES", "SOURCE_PARTITION", "list_name", "eligible", "default_sql", "quote_table",
           "table_allowed", "dataset_tables", "definition_for", "find", "sync_partition", "ensure", "after_save",
           "choices", "list_words", "describe", "refresh_now", "stored_list_for", "may_manage"]
