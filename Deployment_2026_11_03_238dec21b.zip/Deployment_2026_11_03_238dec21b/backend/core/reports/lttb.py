"""Down-sample a long series to about one point per pixel, keeping its shape
(2026-10-30, the report canvas drawing fast).

Largest-Triangle-Three-Buckets (Steinarsson, 2013): the first and the last
point are always kept; every bucket in between keeps the point that makes the
largest triangle with the point kept before it and the average of the next
bucket -- the peaks and dips a reader looks for, not every other point.

Plain LTTB may still pass over the series' single highest or lowest point
when its bucket holds a taller triangle elsewhere, so ``lttb_indices``
reserves two of its points for them: the global maximum and the global
minimum are ALWAYS in the answer (a month-end spike never disappears from a
chart because the picture was made smaller).

The x of a point is its POSITION in the order the rows came in (the tile's
category order: a date, a sequence), so a category of any type works.  A
missing y (NULL) counts as 0 when choosing; the rows themselves are returned
untouched.

The same algorithm runs in the browser
(``frontend/src/components/reports/canvas/canvasRender/lttb.ts``) for the
roads that cannot ask the server (a share link's cube, a split series).
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any, List, Optional, Sequence

#: fewer points than this cannot keep first, last, highest and lowest
MIN_THRESHOLD = 4


def _num(v: Any) -> float:
    if v is None or isinstance(v, bool):
        return 0.0
    if isinstance(v, (int, float, Decimal)):
        f = float(v)
    else:
        try:
            f = float(str(v))
        except (TypeError, ValueError):
            return 0.0
    return f if f == f else 0.0      # NaN -> 0


def lttb_indices(ys: Sequence[Any], threshold: int) -> List[int]:
    """The positions to keep, ascending, at most ``max(threshold, MIN_THRESHOLD)``
    of them; every position when the series is already that short."""
    n = len(ys)
    threshold = max(int(threshold), MIN_THRESHOLD)
    if n <= threshold:
        return list(range(n))
    y = [_num(v) for v in ys]
    hi = max(range(n), key=y.__getitem__)
    lo = min(range(n), key=y.__getitem__)
    extremes = {hi, lo} - {0, n - 1}
    # the buckets choose what is left after first, last and the extremes
    k = threshold - len(extremes)
    if k <= 2:
        return sorted({0, n - 1} | extremes)
    keep = [0]
    every = (n - 2) / (k - 2)
    a = 0
    for i in range(k - 2):
        start = int(i * every) + 1
        end = int((i + 1) * every) + 1
        nxt_start = end
        nxt_end = min(int((i + 2) * every) + 1, n)
        if nxt_start >= nxt_end:          # the last bucket looks at the last point
            avg_x, avg_y = float(n - 1), y[n - 1]
        else:
            span = nxt_end - nxt_start
            avg_x = (nxt_start + nxt_end - 1) / 2.0
            avg_y = sum(y[nxt_start:nxt_end]) / span
        ax, ay = float(a), y[a]
        best, best_area = start, -1.0
        for j in range(start, min(end, n - 1)):
            area = abs((ax - avg_x) * (y[j] - ay) - (ax - j) * (avg_y - ay))
            if area > best_area:
                best_area, best = area, j
        keep.append(best)
        a = best
    keep.append(n - 1)
    return sorted(set(keep) | extremes)


def downsample_rows(rows: List[dict], y_key: str, threshold: int) -> List[dict]:
    """The rows LTTB keeps, in their order (``rows`` itself when short enough)."""
    if len(rows) <= max(int(threshold), MIN_THRESHOLD):
        return rows
    return [rows[i] for i in lttb_indices([r.get(y_key) for r in rows], threshold)]


def drill_y_key(measures: Sequence[dict]) -> Optional[str]:
    """The output name of a drill's first measure (its alias, else its column)."""
    if not measures:
        return None
    m = measures[0]
    return (m.get("alias") or m.get("column")) or None
