"""Insight tiles on the report canvas (2026-10-30, the owner: "even Power BI
report show insights").

A tile of kind ``insight`` carries ``insight``::

    {"kind": "explain_change" | "top_movers" | "decomposition" | "anomalies" | "summary",
     "measure": {"column_id", "aggregation"},
     "dimensions": [column ids],                 # the fields that split it
     "compare": {"basis": "column" | "previous_run" | "auto",
                 "column_id"?, "a"?, "b"?},     # explain_change / top_movers / summary
     "date_column"?: column id,                  # anomalies (and the summary's)
     "window"?: 3..60, "threshold"?: 1..10, "top_n"?: 1..100,
     "path"?: [{"column_id", "value"}]}          # decomposition: the levels opened (request only)

Everything is computed on the run's ONE stored, row-secured result through
``core/reports/insights.py`` (the microcube's reader and rules) -- never a
new query to any source.  The canvas ``version`` stays 1: an insight tile is
one more kind; its ``dimensions`` / ``measures`` stay empty and its columns
are named inside ``insight`` (``insight_column_ids``), so every reader that
does not know insights still reads the canvas.

What A and B are (``compare``), said on the tile every time:

* ``column`` -- two values of a column of the result (a business date, a
  period): the ones the tile names, else the latest two in the result.
* ``previous_run`` -- this run against the newest EARLIER stored run of the
  same report computed under the SAME row access (identical row-security
  signature -- the rule a stored run is served by), whose result file is
  still kept.  A shared link reads only its own run, so it cannot.
* ``auto`` (the default) -- the column when the result holds two of its
  values, else the previous run; when neither is possible the tile says
  both reasons.
"""
from __future__ import annotations

import logging
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

from core.reports import insights as ins
from core.reports import microcube as mc
from core.reports.canvas_links import path_steps, plain_slicers

logger = logging.getLogger(__name__)

__all__ = [
    "COMPARE_BASES",
    "INSIGHT_KINDS",
    "compute_insight",
    "insight_column_ids",
    "insight_export_entry",
    "insight_problems",
    "insight_title",
    "previous_run_of",
]

INSIGHT_KINDS = ("explain_change", "top_movers", "decomposition", "anomalies", "summary")
#: kinds that split a value into parts (the value must be added up)
SPLITTING = ("explain_change", "top_movers", "decomposition", "summary")
COMPARE_BASES = ("column", "previous_run", "auto")
KIND_WORDS = {"explain_change": "Why it changed", "top_movers": "Biggest movers",
              "decomposition": "What it is made of", "anomalies": "Unusual values", "summary": "Summary"}
MAX_FIELDS = 6
MAX_TOP_N = 100
WINDOW_RANGE = (3, 60)
THRESHOLD_RANGE = (1, 10)
AGGREGATIONS = ("sum", "avg", "count", "min", "max", "count_distinct")
#: earlier runs looked at for the previous-run basis
_INSTANCE_LOOKBACK = 200
EVERYTHING_ELSE = "Everything else"


def _int(v: Any) -> Optional[int]:
    try:
        return None if isinstance(v, bool) else int(v)
    except (TypeError, ValueError):
        return None


def _cfg(tile_or_cfg: Any) -> dict:
    if isinstance(tile_or_cfg, dict) and isinstance(tile_or_cfg.get("insight"), dict):
        return tile_or_cfg["insight"]
    return tile_or_cfg if isinstance(tile_or_cfg, dict) else {}


def insight_column_ids(tile: Any) -> List[int]:
    """Every column an insight tile needs the report's query to return."""
    cfg = _cfg(tile)
    ids: List[int] = []
    m = cfg.get("measure")
    if isinstance(m, dict):
        ids.append(_int(m.get("column_id")))
    ids.extend(_int(d) for d in (cfg.get("dimensions") or []))
    cmp_ = cfg.get("compare")
    if isinstance(cmp_, dict) and cmp_.get("column_id") is not None:
        ids.append(_int(cmp_.get("column_id")))
    if cfg.get("date_column") is not None:
        ids.append(_int(cfg.get("date_column")))
    out: List[int] = []
    for i in ids:
        if i is not None and i not in out:
            out.append(i)
    return out


def _label(c: Optional[dict], cid: Any) -> str:
    if not c:
        return f"column #{cid}"
    return str(c.get("friendly_name") or c.get("display_name") or c.get("physical_name") or f"column #{cid}")


def _measure_words(m: dict, cols: Dict[int, dict]) -> str:
    from core.reports.canvas_export import _measure_header
    try:
        return _measure_header({"column_id": int(m.get("column_id")), "aggregation": m.get("aggregation")}, cols)
    except (TypeError, ValueError):
        return "the value"


def insight_title(tile: Any, cols: Dict[int, dict]) -> str:
    """The tile's own title, else "<what it shows>: <the value>"."""
    title = str((tile or {}).get("title") or "").strip() if isinstance(tile, dict) else ""
    if title:
        return title
    cfg = _cfg(tile)
    m = cfg.get("measure") if isinstance(cfg.get("measure"), dict) else None
    head = KIND_WORDS.get(str(cfg.get("kind")), "Insight")
    return f"{head}: {_measure_words(m, cols)}" if m else head


# ── checked on save (canvas_problems) ────────────────────────────────────────

def insight_problems(tile: dict, *, cols: Dict[int, dict], selected: set, grouped: bool) -> List[str]:
    """What is wrong with one insight tile, each in a sentence (the canvas
    prefixes the tile's name).  The same rules as the builder's
    ``canvasInsights.ts::insightProblems``."""
    from core.reports.canvas import _emits_aggregate, _is_numeric
    out: List[str] = []
    cfg = tile.get("insight")
    if not isinstance(cfg, dict):
        return ["choose what the insight shows."]
    kind = cfg.get("kind")
    if kind not in INSIGHT_KINDS:
        return [f'"{kind}" is not a kind of insight.']

    def field(cid: Any, role: str) -> Optional[dict]:
        i = _int(cid)
        if i is None or i not in cols:
            out.append(f"its {role} is a field that is no longer in the data "
                       f"({'column #' + str(cid) if cid is not None else 'none chosen'}).")
            return None
        if i not in selected:
            out.append(f"{_label(cols[i], i)} is not one of the report's columns, so the report does not "
                       f"return it. Add it to the report.")
        return cols[i]

    m = cfg.get("measure")
    measure_col = None
    if not isinstance(m, dict) or m.get("column_id") is None:
        out.append("choose the value it explains.")
    else:
        measure_col = field(m.get("column_id"), "value")
        agg = m.get("aggregation")
        name = _label(measure_col, m.get("column_id"))
        if agg not in AGGREGATIONS:
            out.append(f'"{agg}" is not a way to add up values.')
        elif measure_col is not None:
            if agg in ("sum", "avg") and not _is_numeric(measure_col):
                out.append(f"{name} is not a number, so it cannot be {'added up' if agg == 'sum' else 'averaged'}.")
            elif grouped and agg == "count":
                out.append("this report's rows are already added up, so counting them would count groups, not the "
                           "underlying rows. Use a count measure of the data (shown as Sum).")
            elif grouped and agg == "avg":
                out.append(f"this report's rows are already added up, so an average of {name} here would be an "
                           f"average of averages -- a wrong number. Use the Sum.")
            elif grouped and agg == "count_distinct" and _emits_aggregate(measure_col):
                out.append(f"{name} is added up in this report's rows, so its different values cannot be counted.")
            elif kind in SPLITTING and not (agg == "sum" or (agg == "count" and not grouped)):
                out.append(f"{name} must be added up (Sum) here: only a value that is added up splits into parts "
                           f"that add up to the whole.")

    dims = cfg.get("dimensions") or []
    if not isinstance(dims, list):
        out.append("its fields must be a list.")
        dims = []
    dim_ids = [_int(d) for d in dims]
    for d in dims:
        field(d, "field")
    if len(set(dim_ids)) != len(dim_ids):
        out.append("the same field is used twice.")
    if len(dims) > MAX_FIELDS:
        out.append(f"it can split by at most {MAX_FIELDS} fields.")
    if measure_col is not None and _int(m.get("column_id")) in dim_ids:
        out.append("its value cannot also be one of the fields that split it.")
    if kind in ("explain_change", "top_movers", "decomposition") and not dims:
        out.append("choose at least one field to split it by.")

    cmp_ = cfg.get("compare")
    if kind in ("explain_change", "top_movers") and not isinstance(cmp_, dict):
        out.append("choose what to compare: two values of a date or period field, or the previous run.")
    if isinstance(cmp_, dict):
        basis = cmp_.get("basis") or "auto"
        if basis not in COMPARE_BASES:
            out.append(f'"{basis}" is not a way to compare.')
        if basis == "column" and cmp_.get("column_id") is None:
            out.append("choose the date or period field whose two values are compared.")
        if cmp_.get("column_id") is not None:
            field(cmp_.get("column_id"), "comparison field")
            if _int(cmp_.get("column_id")) in dim_ids:
                out.append("the field being compared cannot also split the change.")
        if (cmp_.get("a") is None) != (cmp_.get("b") is None):
            out.append("name both values to compare, or neither (the latest two are used).")

    if kind == "anomalies" and cfg.get("date_column") is None:
        out.append("choose the date field the values run along.")
    if cfg.get("date_column") is not None:
        field(cfg.get("date_column"), "date field")
    for key, (lo, hi), words in (("window", WINDOW_RANGE, "earlier points each point is judged against"),
                                 ("threshold", THRESHOLD_RANGE, "spreads that count as unusual"),
                                 ("top_n", (1, MAX_TOP_N), "rows it lists")):
        v = cfg.get(key)
        if v is None:
            continue
        ok = isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi
        if key != "threshold":
            ok = ok and isinstance(v, int)
        if not ok:
            out.append(f"the {words} must be between {lo} and {hi}.")
    return out


# ── the previous run (same report, same row access) ──────────────────────────

def _when(v: Any) -> str:
    if not v:
        return "an earlier time"
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        return d.strftime("%Y-%m-%d %H:%M") + (" UTC" if d.tzinfo is not None or "+00:00" in str(v) else "")
    except ValueError:
        return str(v)


def _order_key(r: dict) -> tuple:
    return (str(r.get("created_at") or ""), int(r.get("id") or 0))


def previous_run_of(db, report: dict, *, execution_id: Optional[str] = None,
                    artifact: Optional[str] = None, user_ctx: Optional[dict] = None) -> Dict[str, Any]:
    """The newest EARLIER stored run of ``report`` computed under the CALLER'S
    row access as it is NOW (the current run identified by its execution id,
    or its result file).  Raises :class:`InsightRefused` with the reason.

    SECURITY (2026-10-30): the scope is the caller's LIVE signature
    (``instances.compute_caller_signature`` -- the instance-serve rule), never
    the current run's STORED one: when the caller's row security was narrowed
    since, an earlier run made under their old, wider scope must not be
    opened.  Both the current and the earlier run must carry the live
    signature, and the caller must still be allowed to view the report.  No
    caller (a link, an embed) = no earlier run."""
    from core.reports.contract import require_artifact
    if not user_ctx:
        raise ins.InsightRefused("An earlier run is compared only for a signed-in person who may view this report.")
    from core.reports.authorization import can_view_business_report
    if not can_view_business_report(report, user_ctx, db):
        raise ins.InsightRefused("You may not view this report, so no earlier run of it is opened.")
    try:
        from core.reports.instances import compute_caller_signature
        live = str(compute_caller_signature(db, report, user_ctx))
    except Exception as exc:                                     # noqa: BLE001 -- unknown scope = unsafe
        logger.info("[insights] the caller's row access for report %s could not be signed: %s",
                    report.get("id"), exc)
        raise ins.InsightRefused("Your access to rows could not be checked, so no earlier run is opened.")
    rows = db.list_report_instances(int(report.get("id")), _INSTANCE_LOOKBACK) or []
    stem = Path(str(artifact)).stem if artifact else None
    cur = next((r for r in rows if (execution_id and str(r.get("execution_id")) == str(execution_id))
                or (artifact and (str(r.get("artifact_path") or "") == str(artifact)
                                  or str(r.get("execution_id")) == stem))), None)
    if cur is None:
        raise ins.InsightRefused("This run is not kept as a stored run of the report, so there is no earlier "
                                 "run to compare it with.")
    if str(cur.get("rls_signature")) != live:
        raise ins.InsightRefused("Your access to rows has changed since this run, so it is not compared with an "
                                 "earlier one. Run the report again.")
    earlier = [r for r in rows
               if r.get("id") != cur.get("id") and str(r.get("execution_id")) != str(cur.get("execution_id"))
               and str(r.get("rls_signature")) == live
               and r.get("status") != "expired" and _order_key(r) < _order_key(cur)]
    for r in sorted(earlier, key=_order_key, reverse=True):
        try:
            path = require_artifact(str(r.get("execution_id")), r.get("artifact_path"))
        except Exception:                                    # noqa: BLE001 -- its file is gone: try older
            continue
        return {"artifact": str(path), "execution_id": r.get("execution_id"), "created_at": r.get("created_at"),
                "same_values": str(r.get("params_fingerprint")) == str(cur.get("params_fingerprint")),
                "definition_changed": str(r.get("semantic_version")) != str(cur.get("semantic_version"))}
    raise ins.InsightRefused("There is no earlier run of this report, with the same access to rows, whose "
                             "result is still kept.")


# ── words ────────────────────────────────────────────────────────────────────

def _num(d: Optional[Decimal]) -> str:
    if d is None:
        return "no value"
    d = Decimal(d)
    if d == d.to_integral_value() and d.as_tuple().exponent >= 0:    # a whole number stays whole
        return f"{int(d):,}"
    return f"{d.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP):,.2f}"


def _signed(d: Decimal) -> str:
    return ("+" if d > 0 else "") + _num(d)


def _value_words(v: Any) -> str:
    return ins._plain(v) if v is not None else "(no value)"


def _pct_words(p: Optional[Decimal]) -> str:
    return "" if p is None else f"{p:f}%"


# ── the computation ──────────────────────────────────────────────────────────

class _Ctx:
    def __init__(self, artifact: Path, cfg: dict, cols: Dict[int, dict], path_filters, slicers,
                 grain: str, group_cols, previous, threads, memory_limit):
        self.artifact, self.cfg, self.cols = artifact, cfg, cols
        self.path_filters, self.slicers = list(path_filters or []), (slicers or None)
        self.grain, self.group_cols, self.previous = grain, group_cols, previous
        self.kw = dict(threads=threads, memory_limit=memory_limit)

    def phys(self, cid: Any) -> str:
        c = self.cols.get(_int(cid))
        if not c or not c.get("physical_name"):
            raise ValueError(f"column #{cid} is not a column of this report's dataset")
        return str(c["physical_name"])

    def label(self, cid: Any) -> str:
        return _label(self.cols.get(_int(cid)), cid)

    @property
    def measure(self) -> dict:
        return self.cfg.get("measure") or {}

    @property
    def measure_words(self) -> str:
        return _measure_words(self.measure, self.cols)

    def grain_kw(self) -> dict:
        return dict(artifact_grain=self.grain, artifact_group_columns=self.group_cols)

    def top_n(self, default: int = ins.DEFAULT_TOP_N) -> int:
        v = _int(self.cfg.get("top_n"))
        return v if v and 1 <= v <= MAX_TOP_N else default


def _basis(ctx: _Ctx) -> Dict[str, Any]:
    """Decide A and B once (see the module docstring); InsightRefused with
    every reason when neither basis is possible."""
    cmp_ = ctx.cfg.get("compare") if isinstance(ctx.cfg.get("compare"), dict) else {}
    basis = cmp_.get("basis") or "auto"
    reasons: List[str] = []
    col_id = cmp_.get("column_id")
    if basis in ("column", "auto") and col_id is not None:
        col = ctx.phys(col_id)
        try:
            a, b = ins.compare_values(ctx.artifact, col, a=cmp_.get("a"), b=cmp_.get("b"),
                                      path_filters=ctx.path_filters, slicers=ctx.slicers,
                                      column_words=ctx.label(col_id), **ctx.kw)
            return {"kind": "column", "column": col, "column_id": _int(col_id), "a": a, "b": b,
                    "a_words": f"{ctx.label(col_id)} {_value_words(a)}",
                    "b_words": f"{ctx.label(col_id)} {_value_words(b)}",
                    "words": (f"{ctx.label(col_id)} {_value_words(a)} compared with {_value_words(b)}, "
                              f"both read from this run's result.")}
        except ins.InsightRefused as exc:
            if basis == "column":
                raise
            reasons.append(str(exc))
    if basis in ("previous_run", "auto"):
        if ctx.previous is None:
            reasons.append("A shared link reads only its own run, so it cannot compare with an earlier one.")
        else:
            try:
                prev = ctx.previous()
                same = ("the same values asked for" if prev.get("same_values")
                        else "different values asked for")
                words = (f"This run compared with the earlier run of {_when(prev.get('created_at'))} "
                         f"(the newest earlier run with the same access to rows; {same}).")
                if prev.get("definition_changed"):
                    words += " The report was changed between the two runs."
                return {"kind": "previous_run", "a": None, "b": None, "previous_execution_id": prev.get("execution_id"),
                        "previous_at": prev.get("created_at"), "path_a": prev.get("artifact"),
                        "a_words": f"the run of {_when(prev.get('created_at'))}", "b_words": "this run",
                        "words": words}
            except ins.InsightRefused as exc:
                reasons.append(str(exc))
    if not reasons:
        reasons.append("Choose what to compare: two values of a date or period field, or the previous run.")
    raise ins.InsightRefused(" ".join(reasons))


def _changes(ctx: _Ctx, basis: dict, dims: List[str], *, order: str, top_n: Optional[int]) -> Dict[str, Any]:
    m = ctx.measure
    kw = dict(dimensions=dims, measure=ctx.phys(m.get("column_id")), aggregation=m.get("aggregation") or "sum",
              path_filters=ctx.path_filters, slicers=ctx.slicers, top_n=top_n, order=order,
              measure_words=ctx.measure_words, **ctx.grain_kw(), **ctx.kw)
    if basis["kind"] == "column":
        return ins.member_changes(ctx.artifact, compare=(basis["column"], basis["a"], basis["b"]), **kw)
    return ins.member_changes(ctx.artifact, path_a=Path(basis["path_a"]), **kw)


def _member_label(values: Sequence[Any]) -> str:
    return " › ".join(_value_words(v) for v in values)


def _explain(ctx: _Ctx) -> Dict[str, Any]:
    basis = _basis(ctx)
    dim_ids = list(ctx.cfg.get("dimensions") or [])
    if not dim_ids:
        raise ins.InsightRefused("Choose at least one field to split the change by.")
    sections = []
    total = None
    exact = True
    for cid in dim_ids:
        res = _changes(ctx, basis, [ctx.phys(cid)], order="size", top_n=ctx.top_n())
        total = res["total"]
        exact = exact and res["exact"]
        members = [{"value": mm["values"][0], "label": _value_words(mm["values"][0]), "a": mm["a"], "b": mm["b"],
                    "change": mm["change"], "share_pct": ins.percent(mm["change"], total["change"])}
                   for mm in res["members"]]
        rest = res["rest"]
        sections.append({"field": ctx.label(cid), "column_id": _int(cid), "column": ctx.phys(cid),
                         "members": members, "member_count": res["member_count"],
                         "rest": ({"label": EVERYTHING_ELSE, "count": rest["count"], "a": rest["a"], "b": rest["b"],
                                   "change": rest["change"], "share_pct": ins.percent(rest["change"], total["change"])}
                                  if rest["count"] else None)})
    total = dict(total, change_pct=ins.percent(total["change"], abs(total["a"])) if total else None)
    sent = _change_sentence(ctx, basis, total)
    if sections and sections[0]["members"]:
        top = sections[0]["members"][0]
        if total["change"] != 0:
            sent += (f" The biggest part of that change is {sections[0]['field']} {top['label']}: "
                     f"{_signed(top['change'])}" + (f" ({_pct_words(top['share_pct'])} of the change)."
                                                    if top["share_pct"] is not None else "."))
        elif top["change"] != 0:
            sent += (f" Inside it, {sections[0]['field']} {top['label']} moved most ({_signed(top['change'])}), "
                     f"balanced by the others.")
    return {"basis": basis, "total": total, "sections": sections, "exact": exact, "sentence": sent}


def _change_sentence(ctx: _Ctx, basis: dict, total: dict) -> str:
    pct = total.get("change_pct")
    if total["change"] == 0:
        return (f"{ctx.measure_words} did not change: {_num(total['b'])} for {basis['b_words']}, the same as "
                f"for {basis['a_words']}.")
    return (f"{ctx.measure_words} went from {_num(total['a'])} for {basis['a_words']} to {_num(total['b'])} for "
            f"{basis['b_words']}, a change of {_signed(total['change'])}"
            + (f" ({'+' if pct > 0 else ''}{_pct_words(pct)})." if pct is not None else "."))


def _movers(ctx: _Ctx) -> Dict[str, Any]:
    basis = _basis(ctx)
    dim_ids = list(ctx.cfg.get("dimensions") or [])
    dims = [ctx.phys(c) for c in dim_ids]
    n = ctx.top_n(5)
    out: Dict[str, Any] = {"basis": basis, "fields": [ctx.label(c) for c in dim_ids]}
    exact = True
    for order, key in (("up", "increases"), ("down", "decreases")):
        res = _changes(ctx, basis, dims, order=order, top_n=n)
        exact = exact and res["exact"]
        out[key] = [{"values": mm["values"], "label": _member_label(mm["values"]), "a": mm["a"], "b": mm["b"],
                     "change": mm["change"], "change_pct": ins.percent(mm["change"], abs(mm["a"])),
                     "new": mm["only_in"] == "b", "gone": mm["only_in"] == "a"} for mm in res["members"]]
        out[f"{key}_more"] = res["rest"]["count"]
        out["total"] = dict(res["total"], change_pct=ins.percent(res["total"]["change"], abs(res["total"]["a"])))
    out["exact"] = exact
    sent = _change_sentence(ctx, basis, out["total"])
    if out["increases"]:
        x = out["increases"][0]
        sent += f" The biggest rise is {x['label']} ({_signed(x['change'])})."
    if out["decreases"]:
        x = out["decreases"][0]
        sent += f" The biggest fall is {x['label']} ({_signed(x['change'])})."
    if not out["increases"] and not out["decreases"]:
        sent += " Nothing moved."
    out["sentence"] = sent
    return out


def _decomposition(ctx: _Ctx, path: Sequence[dict]) -> Dict[str, Any]:
    dim_ids = list(ctx.cfg.get("dimensions") or [])
    path = list(path or [])
    if len(path) >= len(dim_ids):
        raise ins.InsightRefused("This is already the last level.")
    filters = list(ctx.path_filters)
    crumbs = []
    for i, step in enumerate(path):
        if not isinstance(step, dict) or _int(step.get("column_id")) != _int(dim_ids[i]):
            raise ValueError("the opened levels must follow the tile's fields in order")
        filters.append({"column": ctx.phys(dim_ids[i]), "value": step.get("value")})
        crumbs.append({"column_id": _int(dim_ids[i]), "field": ctx.label(dim_ids[i]), "value": step.get("value"),
                       "label": _value_words(step.get("value"))})
    level_id = dim_ids[len(path)]
    m = ctx.measure
    res = ins.split_total(ctx.artifact, column=ctx.phys(level_id), measure=ctx.phys(m.get("column_id")),
                          aggregation=m.get("aggregation") or "sum", path_filters=filters, slicers=ctx.slicers,
                          top_n=ctx.top_n(), measure_words=ctx.measure_words, **ctx.grain_kw(), **ctx.kw)
    members = [{"value": x["value"], "label": _value_words(x["value"]), "amount": x["amount"],
                "share_pct": x["share_pct"]} for x in res["members"]]
    rest = res["rest"]
    under = (" under " + " › ".join(f"{c['field']} {c['label']}" for c in crumbs)) if crumbs else ""
    sent = f"{ctx.measure_words}{under} is {_num(res['total'])}."
    if members:
        top = members[0]
        sent += (f" The largest part is {ctx.label(level_id)} {top['label']}: {_num(top['amount'])}"
                 + (f" ({_pct_words(top['share_pct'])} of it)." if top["share_pct"] is not None else "."))
    return {"levels": [{"column_id": _int(c), "field": ctx.label(c)} for c in dim_ids], "path": crumbs,
            "level": len(path), "field": ctx.label(level_id), "column_id": _int(level_id),
            "has_next": len(path) + 1 < len(dim_ids), "total": res["total"], "members": members,
            "member_count": res["member_count"],
            "rest": ({"label": EVERYTHING_ELSE, "count": rest["count"], "amount": rest["amount"],
                      "share_pct": rest["share_pct"]} if rest["count"] else None),
            "exact": res["exact"], "sentence": sent}


def _anomalies(ctx: _Ctx) -> Dict[str, Any]:
    date_id = ctx.cfg.get("date_column")
    window = _int(ctx.cfg.get("window")) or ins.DEFAULT_WINDOW
    thr = ctx.cfg.get("threshold")
    threshold = ins._dec(thr) if thr is not None else ins.DEFAULT_THRESHOLD
    m = ctx.measure
    s = ins.series_points(ctx.artifact, column=ctx.phys(date_id), measure=ctx.phys(m.get("column_id")),
                          aggregation=m.get("aggregation") or "sum", path_filters=ctx.path_filters,
                          slicers=ctx.slicers, **ctx.grain_kw(), **ctx.kw)
    judged = ins.flag_anomalies([p["value"] for p in s["points"]], window=window, threshold=threshold)
    points = []
    for p, j in zip(s["points"], judged):
        points.append({"at": p["at"], "label": _value_words(p["at"]), "value": p["value"], **j})
    flagged = [p for p in points if p["flag"]]
    field = ctx.label(date_id)
    notes = []
    if s["cut"]:
        notes.append(f"The latest {len(points):,} of {s['total_points']:,} {field} values are judged.")
    if s["rows_without_value"]:
        notes.append(f"{s['rows_without_value']:,} rows have no {field} and are left out.")
    n_judged = sum(1 for p in points if p["judged"])
    too_few = n_judged == 0
    if too_few:
        sent = (f"Too few {field} values to judge unusual values of {ctx.measure_words}: there are {len(points)}, "
                f"at least {window + 1} are needed.")
    elif not flagged:
        sent = f"No {field} had an unusual {ctx.measure_words} ({n_judged} judged)."
    else:
        listed = "; ".join(f"{p['label']}: {_num(p['value'])}, {p['flag']} its usual range "
                           f"{_num(p['low'])} to {_num(p['high'])}" for p in flagged[:3])
        more = f" and {len(flagged) - 3} more" if len(flagged) > 3 else ""
        sent = (f"{len(flagged)} {field} value{'s' if len(flagged) != 1 else ''} of {ctx.measure_words} "
                f"{'were' if len(flagged) != 1 else 'was'} unusual ({n_judged} judged): {listed}{more}.")
    return {"field": field, "column_id": _int(date_id), "points": points, "flagged": flagged,
            "judged": n_judged, "too_few": too_few, "window": window, "threshold": threshold,
            "rule": ins.anomaly_rule_words(window, threshold, field), "notes": notes, "sentence": sent}


def _summary(ctx: _Ctx) -> Dict[str, Any]:
    sentences: List[str] = []
    parts: Dict[str, Any] = {}
    dim_ids = list(ctx.cfg.get("dimensions") or [])
    has_compare = isinstance(ctx.cfg.get("compare"), dict)
    explained = False
    if has_compare and dim_ids:
        try:
            ex = _explain(ctx)
            parts["explain_change"] = ex
            sentences.append(ex["sentence"])
            explained = True
        except ins.InsightRefused as exc:
            sentences.append(f"No comparison: {exc}")
    if not explained and dim_ids:
        dec = _decomposition(ctx, [])
        parts["decomposition"] = dec
        sentences.append(dec["sentence"])
    elif not explained:
        m = ctx.measure
        res = mc.read_artifact_drill(ctx.artifact, dimensions=[], measures=[
            {"column": ctx.phys(m.get("column_id")), "aggregation": m.get("aggregation") or "sum", "alias": "v0__"}],
            path_filters=ctx.path_filters, slicers=ctx.slicers, page_size=1, **ctx.grain_kw(), **ctx.kw)
        v = res["rows"][0].get("v0__") if res.get("rows") else None
        sentences.append(f"{ctx.measure_words} is {_num(ins._dec_or_none(v))}.")
    if ctx.cfg.get("date_column") is not None:
        an = _anomalies(ctx)
        parts["anomalies"] = an
        sentences.append(an["sentence"])
    return {"sentences": sentences, "parts": parts, "sentence": " ".join(sentences)}


def compute_insight(artifact: Any, config: dict, *, columns: List[dict],
                    path_filters: Optional[Sequence[Dict[str, Any]]] = None,
                    slicers: Optional[Dict[str, Sequence[Any]]] = None,
                    grain: str = mc.GRAIN_GROUPED, group_columns: Optional[Sequence[str]] = None,
                    previous: Optional[Callable[[], Dict[str, Any]]] = None,
                    threads: int = mc.DEFAULT_THREADS,
                    memory_limit: str = mc.DEFAULT_MEMORY_LIMIT) -> Dict[str, Any]:
    """One insight over the stored result ``artifact`` (amounts as Decimal).
    ``config`` is the tile's ``insight`` (column ids); ``columns`` the
    report's dataset columns; ``previous`` resolves the earlier run (None =
    this caller cannot read other runs -- a shared link)."""
    cols = {int(c["id"]): c for c in columns if _int(c.get("id")) is not None}
    ctx = _Ctx(Path(artifact), config, cols, path_filters, slicers, grain, group_columns, previous,
               threads, memory_limit)
    kind = config.get("kind")
    head = {"kind": kind, "title": insight_title({"insight": config}, cols),
            "measure": {"column_id": _int(ctx.measure.get("column_id")), "words": ctx.measure_words,
                        "aggregation": ctx.measure.get("aggregation") or "sum"}}
    if kind == "explain_change":
        body = _explain(ctx)
    elif kind == "top_movers":
        body = _movers(ctx)
    elif kind == "decomposition":
        body = _decomposition(ctx, config.get("path") or [])
    elif kind == "anomalies":
        body = _anomalies(ctx)
    elif kind == "summary":
        body = _summary(ctx)
    else:
        raise ValueError(f"unknown insight kind {kind!r}")
    if body.get("exact") is False:
        body.setdefault("notes", []).append(
            f"{ctx.measure_words} is stored as a floating-point number, so its last digits can differ from the "
            f"source by rounding; the parts listed still add up to the total shown.")
    return {**head, **body}


# ── the canvas Excel / PDF: the tile's table + its sentence ─────────────────

def insight_export_entry(entry: dict, tile: dict, artifact: Path, dataset_columns: List[dict], *,
                         grain: str, group_columns: Optional[Sequence[str]],
                         previous: Optional[Callable[[], Dict[str, Any]]] = None,
                         slicers: Optional[Dict[str, Sequence[Any]]] = None) -> None:
    """Fill a ``canvas_tile_tables`` entry for an insight tile: ``header`` /
    ``rows`` = the tile's table, ``note`` = its sentence (and what A and B
    are).  A decomposition exports its first level (the tile's opening
    state); anomalies export every point with its usual range."""
    cfg = tile.get("insight") if isinstance(tile.get("insight"), dict) else {}
    cols = {int(c["id"]): c for c in dataset_columns if _int(c.get("id")) is not None}
    entry["title"] = insight_title(tile, cols)
    fmt_m = str((cols.get(_int((cfg.get("measure") or {}).get("column_id"))) or {}).get("format_pattern") or "")
    try:
        res = compute_insight(artifact, dict(cfg, path=[]), columns=dataset_columns, grain=grain,
                              group_columns=group_columns, previous=previous,
                              slicers=plain_slicers(slicers), path_filters=path_steps(slicers) or None)
    except ins.InsightRefused as exc:
        entry["note"] = str(exc)
        return
    kind = res["kind"]
    rows: List[list] = []
    if kind == "explain_change":
        b = res["basis"]
        entry["header"] = ["Field", "Member", b["a_words"], b["b_words"], "Change", "% of the change"]
        entry["formats"] = ["", "", fmt_m, fmt_m, fmt_m, ""]
        for s in res["sections"]:
            for mm in s["members"] + ([s["rest"]] if s["rest"] else []):
                rows.append([s["field"], mm["label"], mm["a"], mm["b"], mm["change"], mm["share_pct"]])
        t = res["total"]
        rows.append(["Total", "", t["a"], t["b"], t["change"], Decimal("100.00") if t["change"] != 0 else None])
    elif kind == "top_movers":
        b = res["basis"]
        entry["header"] = ["", " › ".join(res["fields"]), b["a_words"], b["b_words"], "Change", "% change"]
        entry["formats"] = ["", "", fmt_m, fmt_m, fmt_m, ""]
        for key, words in (("increases", "Rise"), ("decreases", "Fall")):
            for mm in res[key]:
                rows.append([words, mm["label"], mm["a"], mm["b"], mm["change"], mm["change_pct"]])
    elif kind == "decomposition":
        entry["header"] = [res["field"], res["measure"]["words"], "Share of the total %"]
        entry["formats"] = ["", fmt_m, ""]
        for mm in res["members"] + ([res["rest"]] if res["rest"] else []):
            rows.append([mm["label"], mm["amount"], mm["share_pct"]])
        rows.append(["Total", res["total"], Decimal("100.00") if res["total"] != 0 else None])
    elif kind == "anomalies":
        entry["header"] = [res["field"], res["measure"]["words"], "Usual from", "Usual to", "Unusual"]
        entry["formats"] = ["", fmt_m, fmt_m, fmt_m, ""]
        for p in res["points"]:
            rows.append([p["label"], p["value"], p["low"], p["high"], p["flag"] or ""])
    else:
        entry["header"] = ["Summary"]
        entry["formats"] = [""]
        rows = [[s] for s in res["sentences"]]
    entry["rows"] = rows
    words = [res.get("sentence") or ""]
    if res.get("basis"):
        words.append(res["basis"]["words"])
    if kind == "anomalies":
        words.append(res["rule"])
    words.extend(res.get("notes") or [])
    entry["note"] = " ".join(w for w in words if w)
