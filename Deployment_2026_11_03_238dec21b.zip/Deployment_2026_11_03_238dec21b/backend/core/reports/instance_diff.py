""""What changed since I signed?" -- a keyed diff between two report
instances (2026-09-28, the minimal form of strategy item #11).

Both instances are parquet artifacts the platform wrote under a params
fingerprint and a row-security signature, so the comparison is exact and
scoped.  The diff is REFUSED, with the reason, when the two instances are
not comparable: different reports, different parameter values (fingerprint),
different row-security scope (signature), a missing artifact, or more rows
than :data:`DIFF_MAX_ROWS` on either side (a sampled keyed diff would
report added/removed rows that are artefacts of the sample; refusing is
honest, sampling is not).  A different SEMANTIC VERSION is not a refusal:
the diff says so FIRST (``definition_changed``, with the columns added and
removed) and compares the columns the two artifacts share.

KEY COLUMNS are derived, not authored: the report's selected ``dimension``
/ ``detail`` columns (by physical name, then friendly name) that exist in
BOTH artifacts.  That is the grain a finance report is stated at -- its
measures are compared per key.  When the key is not unique on either side,
or the report has no such columns (raw SQL, no dimensions), the result is
a column-level summary only and ``keyed`` says so with the reason.

MEASURES are the numeric non-key columns present on both sides.  Per
measure: sum before, sum after, delta; ``top_movers`` are the changed rows
with the largest absolute delta (``TOP_MOVERS`` per measure).

One DuckDB connection, in-process, over the two files -- the same reader
family ``core/reports/pagination.py`` uses.  No row set leaves DuckDB
except the bounded ``top_movers``.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

#: Rows on either side above which the diff is refused (and says so).
DIFF_MAX_ROWS = 2_000_000
#: Changed rows returned per measure, largest |delta| first.
TOP_MOVERS = 10

_NUMERIC_PREFIXES = ("TINYINT", "SMALLINT", "INTEGER", "BIGINT", "HUGEINT",
                     "UTINYINT", "USMALLINT", "UINTEGER", "UBIGINT",
                     "FLOAT", "DOUBLE", "DECIMAL", "REAL")


class DiffRefused(ValueError):
    """The two instances are not comparable; ``str(exc)`` says why."""


def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _sql_path(path: Path) -> str:
    return "'" + str(path).replace("\\", "/").replace("'", "''") + "'"


def comparable_or_reason(report: Dict[str, Any], base: Dict[str, Any],
                         current: Dict[str, Any]) -> Optional[str]:
    """Why ``base`` and ``current`` must not be diffed, or ``None``."""
    rid = int(report.get("id") or 0)
    if int(base.get("report_id") or 0) != rid or int(current.get("report_id") or 0) != rid:
        return "the two instances belong to different reports"
    if int(base.get("id") or 0) == int(current.get("id") or 0):
        return "the two instances are the same run"
    if str(base.get("params_fingerprint")) != str(current.get("params_fingerprint")):
        return ("the two runs used different parameter values (params "
                "fingerprint differs) -- a diff would report parameter "
                "changes as data changes")
    if str(base.get("rls_signature")) != str(current.get("rls_signature")):
        return ("the two runs were computed under different row-security "
                "scopes (signature differs) -- their rows are not the same "
                "population")
    return None


def candidate_key_columns(db, report: Dict[str, Any]) -> List[Tuple[str, str]]:
    """``(physical_name, friendly_name)`` of the report's selected
    dimension / detail columns, in report order.  Empty for a report with
    no dataset columns (raw SQL, published view)."""
    ds_id = report.get("dataset_id")
    ids = [int(c) for c in (report.get("column_ids") or []) if c is not None]
    if not ds_id or not ids:
        return []
    try:
        cols = db.list_dataset_columns(int(ds_id)) or []
    except Exception as exc:
        logger.info("[instance-diff] dataset columns unreadable: %s", exc)
        return []
    by_id = {int(c["id"]): c for c in cols if c.get("id") is not None}
    out = []
    for cid in ids:
        c = by_id.get(cid)
        if not c:
            continue
        if str(c.get("column_type") or "dimension") in ("dimension", "detail"):
            out.append((str(c.get("physical_name") or ""),
                        str(c.get("friendly_name") or "")))
    return out


def data_versions_changed(base: Dict[str, Any], current: Dict[str, Any]) -> Dict[str, Any]:
    """Which Iceberg table the two runs read at DIFFERENT versions
    (``report_instances.iceberg_versions``, recorded by the run).  ``known``
    is False when either run recorded nothing (an older row) -- unknown is
    said, never read as "same version"."""
    b = {str(r.get("table")): r for r in (base.get("iceberg_versions") or []) if isinstance(r, dict)}
    c = {str(r.get("table")): r for r in (current.get("iceberg_versions") or []) if isinstance(r, dict)}
    if not b or not c:
        return {"known": False, "changed": [], "words": (
            "Which data version each run read was not recorded for both runs.")}
    changed = []
    for t in sorted(set(b) | set(c)):
        bv, cv = b.get(t), c.get(t)
        if (bv or {}).get("snapshot_id") != (cv or {}).get("snapshot_id"):
            changed.append({"table": t,
                            "signed": (bv or {}).get("words"), "current": (cv or {}).get("words")})
    words = ("The data is the same version in both runs." if not changed else
             "The data moved: " + "; ".join(
                 f"{x['table']} was read at {x['signed'] or 'an unrecorded version'} when signed "
                 f"and at {x['current'] or 'an unrecorded version'} now" for x in changed))
    return {"known": True, "changed": changed, "words": words}


def diff_instances(db, report: Dict[str, Any], base: Dict[str, Any],
                   current: Dict[str, Any], *,
                   max_rows: int = DIFF_MAX_ROWS,
                   top_movers: int = TOP_MOVERS) -> Dict[str, Any]:
    """Diff ``current`` against ``base`` (the signed run).  Raises
    :class:`DiffRefused` with the reason when not comparable."""
    reason = comparable_or_reason(report, base, current)
    if reason:
        raise DiffRefused(reason)
    from core.reports.contract import require_artifact
    try:
        base_path = require_artifact(str(base.get("execution_id")), base.get("artifact_path"))
        cur_path = require_artifact(str(current.get("execution_id")), current.get("artifact_path"))
    except Exception as exc:
        raise DiffRefused(f"a result artifact is not retrievable: {exc}")

    import duckdb
    con = duckdb.connect()
    try:
        con.execute(f"CREATE VIEW b AS SELECT * FROM read_parquet({_sql_path(base_path)})")
        con.execute(f"CREATE VIEW c AS SELECT * FROM read_parquet({_sql_path(cur_path)})")
        b_types = {r[0]: str(r[1]).upper() for r in con.execute("DESCRIBE b").fetchall()}
        c_types = {r[0]: str(r[1]).upper() for r in con.execute("DESCRIBE c").fetchall()}
        n_base = int(con.execute("SELECT COUNT(*) FROM b").fetchone()[0])
        n_cur = int(con.execute("SELECT COUNT(*) FROM c").fetchone()[0])
        if max(n_base, n_cur) > int(max_rows):
            raise DiffRefused(
                f"the runs hold {n_base:,} and {n_cur:,} rows; a keyed diff is "
                f"computed only up to {int(max_rows):,} rows per side (a sample "
                "would report sampling as change)")

        shared = [c for c in b_types if c in c_types]
        result: Dict[str, Any] = {
            "base": _ident(base), "current": _ident(current),
            "definition_changed": (str(base.get("semantic_version"))
                                   != str(current.get("semantic_version"))),
            # 2026-11-01 -- the DATA version each run read (core/iceberg_versions.py):
            # a signed run at version A and a current run at version B is said
            # FIRST, in words, never folded into "rows changed"
            "data_versions": data_versions_changed(base, current),
            "columns_added": [c for c in c_types if c not in b_types],
            "columns_removed": [c for c in b_types if c not in c_types],
            "rows": {"base": n_base, "current": n_cur},
            "keyed": False, "key_columns": [], "key_reason": None,
            "measures": [], "top_movers": [],
            "column_summary": _column_summary(con, shared, b_types, c_types),
        }

        keys = _resolve_keys(candidate_key_columns(db, report), shared)
        if not keys:
            result["key_reason"] = (
                "the report declares no dimension or detail column present in "
                "both runs, so rows cannot be matched; column totals only")
            return result
        not_unique = _key_not_unique_reason(con, keys)
        if not_unique:
            result["key_columns"] = keys
            result["key_reason"] = not_unique
            return result
        result.update(_keyed_section(con, keys, shared, b_types, c_types,
                                     n_base, n_cur, top_movers))
        return result
    finally:
        try:
            con.close()
        except Exception:  # pragma: no cover
            pass


def _key_not_unique_reason(con, keys: List[str]) -> Optional[str]:
    group = ", ".join(_quote_ident(k) for k in keys)
    for side, view in (("base", "b"), ("current", "c")):
        dup = int(con.execute(
            f"SELECT COUNT(*) FROM (SELECT 1 FROM {view} GROUP BY {group} "
            f"HAVING COUNT(*) > 1)").fetchone()[0])
        if dup:
            return (f"the key ({', '.join(keys)}) is not unique in the {side} "
                    f"run ({dup:,} duplicate key groups); rows cannot be "
                    "matched one to one; column totals only")
    return None


def _keyed_section(con, keys: List[str], shared: List[str],
                   b_types: Dict[str, str], c_types: Dict[str, str],
                   n_base: int, n_cur: int, top_movers: int) -> Dict[str, Any]:
    """Added / removed / changed rows and per-measure deltas.  Keys are
    unique on both sides (checked by the caller), so the three sets are
    exact: anti-joins for added / removed, an inner join for changed (any
    shared non-key column IS DISTINCT)."""
    measures = [c for c in shared if c not in keys
                and b_types[c].startswith(_NUMERIC_PREFIXES)
                and c_types[c].startswith(_NUMERIC_PREFIXES)]
    compare_cols = [c for c in shared if c not in keys]
    on = " AND ".join(f"b.{_quote_ident(k)} IS NOT DISTINCT FROM c.{_quote_ident(k)}"
                      for k in keys)
    changed_pred = " OR ".join(
        f"b.{_quote_ident(x)} IS DISTINCT FROM c.{_quote_ident(x)}"
        for x in compare_cols) or "FALSE"
    added = int(con.execute(
        f"SELECT COUNT(*) FROM c WHERE NOT EXISTS (SELECT 1 FROM b WHERE {on})"
    ).fetchone()[0])
    removed = int(con.execute(
        f"SELECT COUNT(*) FROM b WHERE NOT EXISTS (SELECT 1 FROM c WHERE {on})"
    ).fetchone()[0])
    changed = int(con.execute(
        f"SELECT COUNT(*) FROM b JOIN c ON {on} WHERE {changed_pred}"
    ).fetchone()[0])
    out: Dict[str, Any] = {
        "keyed": True, "key_columns": keys,
        "rows": {"base": n_base, "current": n_cur, "added": added,
                 "removed": removed, "changed": changed,
                 "unchanged": max(0, n_base - removed - changed)},
        "measures": [], "top_movers": [],
    }
    for m in measures:
        qm = _quote_ident(m)
        bs, cs = con.execute(
            f"SELECT (SELECT SUM({qm}) FROM b), (SELECT SUM({qm}) FROM c)"
        ).fetchone()
        bs = float(bs) if bs is not None else None
        cs = float(cs) if cs is not None else None
        out["measures"].append({
            "column": m, "base_sum": bs, "current_sum": cs,
            "delta": ((cs or 0.0) - (bs or 0.0)) if (bs is not None or cs is not None) else None,
        })
        out["top_movers"].extend(_movers(con, keys, on, m, top_movers))
    return out


def _movers(con, keys: List[str], on: str, measure: str, limit: int) -> List[Dict[str, Any]]:
    """The ``limit`` rows whose ``measure`` moved most, largest |delta| first."""
    qm = _quote_ident(measure)
    key_sel = ", ".join(
        f"COALESCE(b.{_quote_ident(k)}, c.{_quote_ident(k)}) AS {_quote_ident(k)}"
        for k in keys)
    rows = con.execute(
        f"SELECT {key_sel}, b.{qm} AS before_v, c.{qm} AS after_v, "
        f"COALESCE(c.{qm}, 0) - COALESCE(b.{qm}, 0) AS delta "
        f"FROM b FULL OUTER JOIN c ON {on} "
        f"WHERE b.{qm} IS DISTINCT FROM c.{qm} "
        f"ORDER BY ABS(COALESCE(c.{qm}, 0) - COALESCE(b.{qm}, 0)) DESC "
        f"LIMIT {int(limit)}"
    ).fetchall()
    out = []
    for row in rows:
        before_v, after_v, delta = row[len(keys):]
        out.append({
            "column": measure,
            "key": {k: _py(v) for k, v in zip(keys, row[:len(keys)])},
            "before": _py(before_v), "after": _py(after_v),
            "delta": float(delta) if delta is not None else None,
        })
    return out


def _resolve_keys(candidates: List[Tuple[str, str]], shared: List[str]) -> List[str]:
    keys: List[str] = []
    shared_set = set(shared)
    for phys, friendly in candidates:
        if phys and phys in shared_set and phys not in keys:
            keys.append(phys)
        elif friendly and friendly in shared_set and friendly not in keys:
            keys.append(friendly)
    return keys


def _column_summary(con, shared: List[str], b_types: Dict[str, str],
                    c_types: Dict[str, str]) -> List[Dict[str, Any]]:
    out = []
    for col in shared:
        q = _quote_ident(col)
        numeric = (b_types[col].startswith(_NUMERIC_PREFIXES)
                   and c_types[col].startswith(_NUMERIC_PREFIXES))
        sum_expr = f"SUM({q})" if numeric else "NULL"
        entry: Dict[str, Any] = {"column": col, "numeric": numeric}
        for side, view in (("base", "b"), ("current", "c")):
            cnt, nulls, distinct, total = con.execute(
                f"SELECT COUNT(*), COUNT(*) - COUNT({q}), COUNT(DISTINCT {q}), "
                f"{sum_expr} FROM {view}").fetchone()
            entry[side] = {"count": int(cnt), "nulls": int(nulls),
                           "distinct": int(distinct),
                           "sum": (float(total) if total is not None else None)}
        out.append(entry)
    return out


def _ident(inst: Dict[str, Any]) -> Dict[str, Any]:
    return {"instance_id": inst.get("id"), "execution_id": inst.get("execution_id"),
            "created_at": inst.get("created_at"), "created_by": inst.get("created_by"),
            "row_count": inst.get("row_count"),
            "semantic_version": inst.get("semantic_version")}


def _py(v: Any) -> Any:
    """A DuckDB scalar as a JSON-safe Python value."""
    if v is None or isinstance(v, (str, bool, int, float)):
        return v
    try:
        import decimal
        if isinstance(v, decimal.Decimal):
            return float(v)
    except Exception:  # pragma: no cover
        pass
    return str(v)
