"""A cube answer as Arrow (2026-10-30, the report canvas drawing fast).

A canvas tile may ask ``POST .../results/{exec_id}/cube`` with
``Accept: application/vnd.apache.arrow.stream``; everyone else keeps the JSON
they always had, byte for byte.  The Arrow answer carries EXACTLY the values
the JSON would: it is built from the same JSON-ready envelope
(``jsonable_encoder`` of the route's dict), so

* every number is a float64 -- what ``JSON.parse`` makes of it in the browser
  (an integer beyond 2**53 rounds the same way in both);
* text is utf8, true/false is bool, a column that is NULL on every row is the
  null type;
* a column whose values mix kinds (text in one row, a number in the next)
  cannot be one Arrow column without changing a value, so the whole answer is
  NOT encoded (``None``) and the route answers in JSON -- the caller reads the
  Content-Type, never assumes.

Everything else in the envelope (``columns``, ``total_rows``, ``page``,
``page_size``, ``total_pages``, ``downsampled`` ...) rides in the schema's
metadata under ``qs_cube`` as JSON, so ``{...meta, rows}`` is the JSON answer.

The bytes are written by ``core.arrow_ipc.table_to_ipc_stream`` -- the SQL
editor's Arrow road -- and read in the browser by
``frontend/src/components/reports/canvas/canvasRender/arrowStream.ts``.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

META_KEY = b"qs_cube"


def _column_type(values: List[Any]):
    import pyarrow as pa
    present = [v for v in values if v is not None]
    if not present:
        return pa.null()
    if all(isinstance(v, bool) for v in present):
        return pa.bool_()
    if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in present):
        return pa.float64()
    if all(isinstance(v, str) for v in present):
        return pa.string()
    return None


def cube_arrow_bytes(result: Dict[str, Any]) -> Optional[bytes]:
    """The Arrow IPC stream of one cube answer, or ``None`` when it cannot carry
    the JSON's values exactly (then the route answers in JSON)."""
    import pyarrow as pa
    from fastapi.encoders import jsonable_encoder
    from core.arrow_ipc import table_to_ipc_stream

    enc = jsonable_encoder(result)
    if not isinstance(enc, dict):
        return None
    rows = enc.get("rows")
    if not isinstance(rows, list) or any(not isinstance(r, dict) for r in rows):
        return None
    names: List[str] = []
    seen = set()
    for c in (enc.get("columns") or []):
        if isinstance(c, str) and c not in seen:
            seen.add(c)
            names.append(c)
    for r in rows:
        for k in r:
            if k not in seen:
                seen.add(k)
                names.append(k)
    # every row must carry every column: a missing key is not a NULL in JSON
    if any(len(r) != len(names) or any(k not in r for k in names) for r in rows):
        return None
    arrays, fields = [], []
    for name in names:
        values = [r[name] for r in rows]
        typ = _column_type(values)
        if typ is None:
            return None
        if typ == pa.float64():
            values = [None if v is None else float(v) for v in values]
        arrays.append(pa.array(values, type=typ))
        fields.append(pa.field(name, typ, nullable=True))
    meta = {k: v for k, v in enc.items() if k != "rows"}
    schema = pa.schema(fields, metadata={META_KEY: json.dumps(meta).encode("utf-8")})
    table = pa.Table.from_arrays(arrays, schema=schema)
    return table_to_ipc_stream(table)


def decimal_columns(artifact: Optional[str]) -> Optional[List[str]]:
    """The columns the stored result holds as exact DECIMALs, read from the
    file's own schema; ``None`` when the types cannot be read (no file, a
    result still in parts, an unreadable file) -- unknown, never "none"."""
    from pathlib import Path
    if not artifact:
        return None
    p = Path(artifact)
    if not p.is_file() or p.suffix.lower() not in (".parquet", ".pq"):
        return None
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
        schema = pq.read_schema(str(p))
    except Exception:                                         # noqa: BLE001
        return None
    return [f.name for f in schema if pa.types.is_decimal(f.type)]


def page_arrow(answer: Dict[str, Any], artifact: Optional[str]) -> "tuple[Optional[bytes], str]":
    """A page of the report's table as Arrow (2026-10-30, every report a
    canvas): ``(bytes, "")``, or ``(None, why)`` when the page stays JSON.

    EXACT DECIMALS: a DECIMAL column would travel as float64 -- so a page with
    one stays JSON and says which ("exact decimals: amount").  A page whose
    column types cannot be read stays JSON too (unknown is not "no
    decimals").  Otherwise the bytes are :func:`cube_arrow_bytes` of the very
    envelope the JSON answer is, so ``{...meta, rows}`` decodes to the JSON."""
    shown = [c for c in (answer.get("columns") or []) if isinstance(c, str)]
    dec = decimal_columns(artifact)
    if dec is None:
        return None, "the column types of this result could not be read"
    exact = [c for c in shown if c in set(dec)]
    if exact:
        return None, "exact decimals: " + ", ".join(exact)
    data = cube_arrow_bytes(answer)
    if data is None:
        return None, "a column mixes kinds of value"
    return data, ""


def decode_cube_arrow(data: bytes) -> Dict[str, Any]:
    """The JSON envelope back from the Arrow bytes.

    TEST SEAM: the inverse of :func:`cube_arrow_bytes`, used by the tests to
    prove Arrow == JSON by value (the browser decodes with
    ``frontend/src/utils/arrowStream.ts``); no production path needs it."""
    import pyarrow as pa
    reader = pa.ipc.open_stream(pa.py_buffer(data))
    table = reader.read_all()
    meta = json.loads((table.schema.metadata or {}).get(META_KEY, b"{}"))
    return {**meta, "rows": table.to_pylist()}
