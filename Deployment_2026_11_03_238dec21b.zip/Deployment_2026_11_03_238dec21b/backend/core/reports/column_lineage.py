"""Where does a report column REALLY come from? (2026-10-24)

The owner: "if fact_tetb is in the query, use the cached values when the user
selects those columns".  A dataset built on custom SQL exposes OUTPUT
columns; a parameter on one of them used to read its choices by running
``SELECT DISTINCT col FROM (<the whole report query>)``.  That is slow on a
large query and cached nowhere.  When the output column is the SOURCE
table's column passed through unchanged (renamed, through CTEs and joins,
but not computed), its choices are that table's values for that column.  Those
come from the partition metadata, or from THE value cache
(core/column_value_cache.py) the query builder already fills.

:func:`trace` answers that from the SQL text alone (sqlglot lineage): a
``Source`` (table and column AS THE QUERY SPELLS THEM) or a reason it cannot
tell.  Never a guess: a computed column (``UPPER(region)``), a column fed by
two tables (``UNION``), or a ``SELECT *`` it cannot resolve is NOT traced --
the caller keeps the report's own DISTINCT for it and says why.

Note on scope: the table's values may include some the report's own WHERE
excludes (a value that then finds no rows).  That is the trade every BI
tool makes for a list that is instant and the same for every report on the
table.  The answer says where the list came from (``table``).
"""
from __future__ import annotations

import hashlib
import threading
from collections import OrderedDict
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Source:
    table: Optional[str] = None        # as written in the query, without its alias
    column: Optional[str] = None       # the column as written in the query
    reason: Optional[str] = None       # why not traced (table/column None)

    @property
    def traced(self) -> bool:
        return bool(self.table and self.column)


def _name_parts(t) -> list:
    return [p.lower() for p in (t.catalog, t.db, t.name) if p]


def _bare(table, dialect: str) -> str:
    t = table.copy()
    t.set("alias", None)
    return t.sql(dialect or None)


#: The memo of :func:`trace` (2026-10-25): a pure function of (sql, column,
#: dialect) whose cost is a sqlglot lineage over the WHOLE query -- measured
#: 164-597 ms on the owner's 460-column fact_tetb query -- paid on EVERY
#: parameter-values request (a dropdown opened, a keystroke of its search)
#: and, for a computed column, paid for nothing (the trace declines and the
#: report's own DISTINCT runs).  Keyed by the SQL's digest, bounded, LRU.
_MEMO_MAX = 1024
_memo: "OrderedDict[tuple, Source]" = OrderedDict()
_memo_lock = threading.Lock()


def trace(sql: str, output_column: str, dialect: str = "") -> Source:
    """Trace ``output_column`` of ``sql`` to one source table column.

    Memoised (see ``_MEMO_MAX``): the answer depends only on the three
    arguments, and ``Source`` is frozen, so the same object serves every
    caller.  ``memo_stats()`` says how often it hit."""
    key = (hashlib.sha256((sql or "").encode("utf-8", "surrogatepass")).hexdigest(),
           str(output_column or ""), str(dialect or ""))
    with _memo_lock:
        hit = _memo.get(key)
        if hit is not None:
            _memo.move_to_end(key)
            _stats["hits"] += 1
            return hit
    out = _trace_uncached(sql, output_column, dialect)
    with _memo_lock:
        _stats["misses"] += 1
        _memo[key] = out
        _memo.move_to_end(key)
        while len(_memo) > _MEMO_MAX:
            _memo.popitem(last=False)
    return out


_stats = {"hits": 0, "misses": 0}


def memo_stats() -> dict:
    """Hits / misses / size of the trace memo.  TEST SEAM -- read by
    tests/test_lov_lineage_trace_is_memoised_2026_10_25.py to prove the second
    ask is a hit; no production reader (the memo is an optimisation, not a
    surface anything answers from)."""
    with _memo_lock:
        return {"hits": _stats["hits"], "misses": _stats["misses"], "size": len(_memo),
                "max": _MEMO_MAX}


def clear_memo() -> None:
    """Forget every traced answer.  TEST SEAM -- the memo is process-wide, so
    the memoisation test empties it between cases; production never clears it
    (an entry is keyed by the SQL's digest and a pure function's answer does
    not go stale)."""
    with _memo_lock:
        _memo.clear()
        _stats["hits"] = _stats["misses"] = 0


def _single_table_star(sql: str, output_column: str, dialect: str = "") -> Optional[Source]:
    """``SELECT * FROM t [WHERE ...]`` (rig 2026-11-01: the owner's
    ``SELECT * FROM iceberg.qs.pnl_explain`` dataset had NO list traced --
    lineage cannot expand a star without the table's schema).  When the
    statement is ONE plain SELECT whose only projection is ``*`` (or
    ``t.*``) over ONE bare table -- no JOIN, no subquery or CTE, no set
    operation -- every output column IS that table's column, unchanged, so
    the answer is exact without a schema.  Anything else: None (lineage
    decides, as before).  The WHERE does not matter here: a list is the
    table's DISTINCT values (see the module note on scope)."""
    try:
        import sqlglot
        from sqlglot import exp
        tree = sqlglot.parse_one(sql, read=dialect or None)
    except Exception:                                         # noqa: BLE001
        return None
    # An ALLOW-list of clauses (sqlglot renames its arg keys between versions:
    # ``with_`` / ``from_`` / ``except_``) -- any other clause declines.
    allowed = {"expressions", "from", "from_", "where", "distinct", "order", "limit", "offset", "hint"}
    if type(tree) is not exp.Select or any(v for k, v in tree.args.items() if k not in allowed):
        return None
    projections = tree.expressions
    if len(projections) != 1:
        return None
    p = projections[0]
    if not (isinstance(p, exp.Star) or (isinstance(p, exp.Column) and isinstance(p.this, exp.Star))):
        return None
    star_node = p if isinstance(p, exp.Star) else p.this
    if any(star_node.args.values()) or (p is not star_node and any(
            v for k, v in p.args.items() if k not in ("this", "table", "db", "catalog"))):
        return None                       # * EXCLUDE / REPLACE / RENAME change the output
    frm = tree.args.get("from") or tree.args.get("from_")
    src = frm.this if frm is not None else None
    if not isinstance(src, exp.Table) or not src.name or any(
            v for k, v in src.args.items() if k not in ("this", "db", "catalog", "alias")):
        return None                       # a SAMPLE / version / table function is not the table
    if any(True for _ in tree.find_all(exp.Subquery)):
        return None
    return Source(table=_bare(src, dialect),
                  column=exp.to_identifier(str(output_column)).sql(dialect or None))


def _trace_uncached(sql: str, output_column: str, dialect: str = "") -> Source:
    if not (sql or "").strip() or not (output_column or "").strip():
        return Source(reason="There is no query to trace the column through.")
    star = _single_table_star(sql, output_column, dialect)
    if star is not None:
        return star
    try:
        import sqlglot
        from sqlglot import exp
        from sqlglot.lineage import lineage
        # The dataset stores the ENGINE's spelling of the output column; asked
        # for quoted it matches exactly (a quoted "Region" on PostgreSQL),
        # and unquoted as a fallback.
        try:
            root = lineage(exp.column(output_column, quoted=True), sql, dialect=dialect or None)
        except Exception:                                     # noqa: BLE001
            root = lineage(output_column, sql, dialect=dialect or None)
        original = sqlglot.parse_one(sql, read=dialect or None)
    except Exception as exc:                                  # noqa: BLE001
        return Source(reason=f"'{output_column}' could not be traced through the query "
                             f"({type(exc).__name__}) -- a SELECT * or an unusual shape.")
    leaves = []
    for node in root.walk():
        e = node.expression
        inner = e.this if isinstance(e, exp.Alias) else e
        if not isinstance(inner, (exp.Column, exp.Table)):
            return Source(reason=f"'{output_column}' is computed in the query "
                                 f"({inner.sql(dialect or None)[:80]}), not a table's column.")
        if not node.downstream:
            leaves.append(node)
    if len(leaves) != 1:
        return Source(reason=f"'{output_column}' comes from {len(leaves)} places in the query "
                             f"(a UNION or similar), so no single table owns its values.")
    leaf = leaves[0]
    if not isinstance(leaf.source, exp.Table):
        return Source(reason=f"'{output_column}' does not come from a table.")
    # lineage NORMALISES identifiers (a quoted "Fact" comes back "fact"):
    # take the table and the column as the QUERY spells them -- quoting and
    # case are part of the name on PostgreSQL / Snowflake.
    want_t = _name_parts(leaf.source)
    want_c = str(leaf.name).rsplit(".", 1)[-1].strip('"`').lower()
    spellings_t = {_bare(t, dialect) for t in original.find_all(exp.Table)
                   if _name_parts(t) == want_t}
    spellings_c = {c.args["this"].sql(dialect or None) for c in original.find_all(exp.Column)
                   if c.name.lower() == want_c and isinstance(c.args.get("this"), exp.Identifier)}
    if len(spellings_t) != 1:
        return Source(reason=f"The table of '{output_column}' is written "
                             f"{len(spellings_t)} ways in the query, so it is not traced.")
    if len(spellings_c) != 1:
        return Source(reason=f"'{output_column}' is written {len(spellings_c)} ways in the "
                             f"query, so it is not traced.")
    return Source(table=next(iter(spellings_t)), column=next(iter(spellings_c)))
