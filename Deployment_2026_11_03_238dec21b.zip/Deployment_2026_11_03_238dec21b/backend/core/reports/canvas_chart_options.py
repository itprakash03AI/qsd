"""Chart options on a canvas tile (2026-11-02; docs/REPORT_DESIGN_UPGRADE_PLAN_2026_11_02.html step 3).

The owner's examples: values written on the bars, "%" markers on a donut's
slices, the donut's total in its centre, CY bars with a PY dotted line.  Each
is a FIELD of the chart tile (absent = today's drawing)::

    labels:           "none" | "values" | "percent"   values on the marks; percent = the share of the chart's total
    centre:           "none" | "total"                a donut writes its total in the middle
    compare_overlay:  true                            under the canvas's two-dates comparison a bar / line / combo
                                                      tile draws B as its marks and A as a DOTTED line (the same
                                                      categories, both read from the ONE stored result)

This module is the save check (``chart_option_problems``, called from
``canvas_outline.outline_problems`` for every chart tile) and the export's half
(``overlay_entry`` reads the two sides; the SVG and Excel writers read
``entry["labels_mode"]`` / ``entry["centre"]`` / ``entry["overlay"]``); the
browser's twin is ``frontend/src/components/reports/canvas/canvasChartOptions.ts``.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

LABEL_MODES = ("none", "values", "percent")
CENTRE_MODES = ("none", "total")
#: the kinds that may write values on their marks
LABEL_KINDS = ("bar", "hbar", "stacked_bar", "line", "area", "combo", "pie", "donut", "funnel", "treemap", "waterfall")
#: the kinds whose marks can carry "% of the total"
PERCENT_KINDS = ("bar", "hbar", "pie", "donut", "funnel", "treemap")
#: the kinds a two-dates overlay can draw (B as the marks, A as a dotted line)
OVERLAY_KINDS = ("bar", "line", "combo")


def chart_option_problems(t: dict, *, say: Callable[[Optional[dict], str], None], canvas: Optional[dict] = None) -> None:
    """Every problem of a chart tile's options, in plain words (the browser's ``chartOptionProblems`` says the same)."""
    kind = t.get("kind")
    lm = t.get("labels")
    if lm is not None:
        if lm not in LABEL_MODES:
            say(t, "labels on the marks are off, the values, or the share of the total.")
        elif kind not in LABEL_KINDS:
            say(t, "this kind of chart cannot write labels on its marks.")
        elif lm == "percent" and kind not in PERCENT_KINDS:
            say(t, "the share of the total can be written on bars, a pie, a donut, a funnel or a treemap.")
    c = t.get("centre")
    if c is not None:
        if c not in CENTRE_MODES:
            say(t, "the centre of a donut is empty or shows the total.")
        elif kind != "donut":
            say(t, "only a donut has a centre to write the total in.")
    ov = t.get("compare_overlay")
    if ov is not None:
        if not isinstance(ov, bool):
            say(t, "the two-dates overlay is on or off.")
        elif ov and kind not in OVERLAY_KINDS:
            say(t, "the two-dates overlay (B as the marks, A as a dotted line) draws on a bar, a line or a bars-and-lines chart.")
        elif ov and t.get("series") is not None:
            say(t, "the two-dates overlay cannot be drawn on a chart split into series.")
        elif ov and not isinstance((canvas or {}).get("compare"), dict):
            say(t, 'it draws the two-dates overlay, but the canvas has no "two dates to compare" parameter set.')


def labels_mode(t: dict) -> str:
    return t.get("labels") if t.get("labels") in LABEL_MODES else "none"


def overlay_wanted(t: dict, compare_setting: Optional[dict]) -> bool:
    """Does this tile draw B as its marks and A as a dotted line for this run?"""
    return bool(t.get("compare_overlay") is True and t.get("kind") in OVERLAY_KINDS and t.get("series") is None
                and compare_setting and not compare_setting.get("error"))


def overlay_entry(entry: dict, t: dict, path, cols: Dict[int, dict], phys, dims_ids: List[int], ms: List[dict],
                  measures: List[dict], setting: Dict[str, Any], drill_all, measure_header, fmt, *, grain: str,
                  group_columns, budget, slicers=None, top_n: int = 25, largest_first_sort=None) -> None:
    """The export entry of an overlay: the categories of side B (the tile's order and
    ``top_n``), per value ``<label> <b>`` then ``<label> <a>`` -- the writers draw
    the first as the marks and the second as a DOTTED line."""
    from core.reports.canvas_links import merge_slicers
    col_name = phys(setting["column_id"])
    if not col_name:
        entry["note"] = "The comparison's date column is not in this run."
        return
    cat = phys(dims_ids[0])
    cat_label = (cols.get(dims_ids[0]) or {}).get("friendly_name") or cat
    sort_col, sort_dir = largest_first_sort if largest_first_sort else (cat, "asc")
    sides = {}
    b_sl = merge_slicers(slicers, {col_name: [setting["b"]]}) if slicers else {col_name: [setting["b"]]}
    b = drill_all(path, [cat], measures, sort_column=sort_col, sort_direction=sort_dir, grain=grain,
                  group_cols=group_columns, limit=max(1, top_n), slicers=b_sl)
    shown = [r.get(cat) for r in b["rows"]]
    a_sl = merge_slicers(slicers, {col_name: [setting["a"]], cat: [v for v in shown if v is not None]}) if slicers \
        else {col_name: [setting["a"]], cat: [v for v in shown if v is not None]}
    a = drill_all(path, [cat], measures, sort_column=cat, sort_direction="asc", grain=grain,
                  group_cols=group_columns, limit=max(1, top_n), slicers=a_sl)
    sides["a"] = {repr(r.get(cat)): r for r in a["rows"]}
    header = [cat_label]
    fmts = [fmt(cols.get(dims_ids[0]))]
    for m in ms:
        mh = measure_header(m, cols)
        header += [f"{mh} {setting['b']}", f"{mh} {setting['a']}"]
        mf = fmt(cols.get(int(m["column_id"])))
        fmts += [mf, mf]
    entry["header"] = header
    entry["formats"] = fmts
    for r in b["rows"]:
        ra = sides["a"].get(repr(r.get(cat)))
        line = [r.get(cat)]
        for i in range(len(ms)):
            line += [r.get(f"v{i}__"), ra.get(f"v{i}__") if ra else None]
        entry["rows"].append(line)
    entry["overlay"] = {"a": setting["a"], "b": setting["b"], "values": len(ms)}
    budget[0] -= len(entry["rows"]) * len(header)
    note = (f"{setting['words']}: {setting['b']} as the {'bars' if t.get('kind') != 'line' else 'line'}, "
            f"{setting['a']} as the dotted line.")
    if b["total"] > len(shown):
        note += f" Showing {len(shown)} of {b['total']:,} {cat_label}."
        entry["cut"] = {"shown": len(shown), "total": int(b["total"]), "label": cat_label,
                        "largest_first": bool(largest_first_sort and largest_first_sort[1] == "desc")}
    entry["note"] = (note + " " + (entry.get("note") or "")).strip()


__all__ = ["LABEL_MODES", "CENTRE_MODES", "LABEL_KINDS", "PERCENT_KINDS", "OVERLAY_KINDS", "chart_option_problems",
           "labels_mode", "overlay_wanted", "overlay_entry"]
