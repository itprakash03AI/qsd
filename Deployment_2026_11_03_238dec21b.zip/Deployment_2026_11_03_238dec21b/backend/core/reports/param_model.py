"""The report PARAMETER model -- the shape a value has for each kind (2026-10-30).

The kinds a report (and a canvas) asks for, and the value each one takes:

=================  =============================================  ===========================
kind               the value a run receives                       "no value" means
=================  =============================================  ===========================
``date``           ``"2026-07-31"`` (or a token: ``@TODAY``,      the filter is not applied
                   ``@PREV_BUSINESS_DAY:LDN`` ...)
``date_range``     ``{"from": "...", "to": "..."}`` -- either     the filter is not applied;
                   side may be empty (open on that side)          one empty side = open
``dropdown``       one value                                      All
``multi_select``   a LIST of values (one = ``=``, several = IN)   All
``text`` /         one value                                      the filter is not applied
``numeric``
=================  =============================================  ===========================

Cascading (``depends_on_param_id``: a child's choices narrowed by its
parent's value) and business-calendar defaults (``core/
business_calendar_tokens.py``) work on every kind above.

THE GAP THIS CLOSES.  A parameter's DEFAULT is one text column
(``report_parameters.default_value``), and two kinds need more than one text:

* a ``date_range`` default was a single token (the editor offered one
  picker), so a run given only the default received a STRING for a range --
  ``_build_report_filters`` then fell through to ``=`` (one day, silently),
  ``_build_source_bindings`` handed a BETWEEN predicate one bare value, and
  the viewer's From / To boxes showed nothing because a string has no
  ``from``.  A range default is now written ``FROM..TO`` (either side may be
  empty: ``@MONTH_START..`` = from the month start, open-ended); a single
  value with no ``..`` keeps the meaning it ran with before (that one day,
  ``{"from": x, "to": x}``), now as a range;
* a ``multi_select`` default of one picked value was a bare string; it is
  now the one-element list, and a JSON list (``["A", "B"]``) is several.

``normalize_value`` is the ONE place a raw value (a caller's, a URL's, or the
default) becomes the kind's shape -- the filter builder, the source binding,
the Diagnostics record and the canvas band all read values through it.  A
comma is NEVER a separator (a value may contain one).
"""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

#: the separator of a date-range default's two sides
RANGE_SEPARATOR = ".."

LIST_KINDS = ("dropdown", "multi_select")
DATE_KINDS = ("date", "date_range")
#: 2026-11-01 -- a PERIOD (one word: daily / mtd / qtd / ytd / daily_month /
#: month_ends_12 / year_ends_3, anchored on the business date it depends on) and
#: TWO DATES TO COMPARE ({"a", "b"}); the rules: core/reports/period.py
PERIOD_KIND = "period"
COMPARE_KIND = "cob_compare"
ALL_KINDS = LIST_KINDS + DATE_KINDS + ("text", "numeric", PERIOD_KIND, COMPARE_KIND, "number_range", "boolean", "hierarchy")


def _json(text: str) -> Any:
    try:
        return json.loads(text)
    except (TypeError, ValueError):
        return None


def normalize_value(param: Dict[str, Any], raw: Any) -> Any:
    """``raw`` in the shape ``param``'s kind takes (see the module table).

    ``None`` and ``""`` stay as they are (no value); anything already in the
    kind's shape is returned unchanged, so a value the viewer's controls send
    runs exactly as before."""
    if raw is None:
        return None
    kind = str((param or {}).get("parameter_type") or "").strip().lower()
    if kind == "date_range":
        if isinstance(raw, dict):
            return raw
        if isinstance(raw, (list, tuple)) and len(raw) == 2:
            return {"from": raw[0] or "", "to": raw[1] or ""}
        if isinstance(raw, str):
            text = raw.strip()
            if not text:
                return raw
            if text.startswith("{"):
                parsed = _json(text)
                if isinstance(parsed, dict):
                    return {"from": parsed.get("from") or "", "to": parsed.get("to") or ""}
            if RANGE_SEPARATOR in text:
                lo, hi = text.split(RANGE_SEPARATOR, 1)
                return {"from": lo.strip(), "to": hi.strip()}
            return {"from": text, "to": text}
        return raw
    if kind == COMPARE_KIND:
        if isinstance(raw, dict):
            return {"a": raw.get("a") or "", "b": raw.get("b") or ""}
        if isinstance(raw, (list, tuple)) and len(raw) == 2:
            return {"a": raw[0] or "", "b": raw[1] or ""}
        if isinstance(raw, str):
            text = raw.strip()
            if text.startswith("{"):
                parsed = _json(text)
                if isinstance(parsed, dict):
                    return {"a": parsed.get("a") or "", "b": parsed.get("b") or ""}
            if RANGE_SEPARATOR in text:
                a, b = text.split(RANGE_SEPARATOR, 1)
                return {"a": a.strip(), "b": b.strip()}
        return raw
    if kind == PERIOD_KIND:
        return str(raw).strip().lower() if isinstance(raw, str) else raw
    if kind == "number_range":
        if isinstance(raw, dict):
            return {"from": raw.get("from"), "to": raw.get("to")}
        if isinstance(raw, (list, tuple)) and len(raw) == 2:
            return {"from": raw[0], "to": raw[1]}
        if isinstance(raw, str):
            text = raw.strip()
            if text.startswith("{"):
                parsed = _json(text)
                if isinstance(parsed, dict):
                    return {"from": parsed.get("from"), "to": parsed.get("to")}
            if RANGE_SEPARATOR in text:
                lo, hi = text.split(RANGE_SEPARATOR, 1)
                return {"from": lo.strip() or None, "to": hi.strip() or None}
        return raw
    if kind == "boolean":
        if isinstance(raw, bool):
            return raw
        if isinstance(raw, (int, float)):
            return bool(raw)
        return str(raw).strip().lower() in ("true", "1", "yes", "y", "on")
    if kind == "hierarchy":
        if isinstance(raw, dict):
            return {str(k): v for k, v in raw.items()}
        if isinstance(raw, str) and raw.strip().startswith("{"):
            parsed = _json(raw.strip())
            if isinstance(parsed, dict):
                return {str(k): v for k, v in parsed.items()}
        return raw
    if kind == "multi_select":
        if isinstance(raw, list):
            return raw
        if isinstance(raw, tuple):
            return list(raw)
        if isinstance(raw, str):
            text = raw.strip()
            if not text:
                return []
            if text.startswith("["):
                parsed = _json(text)
                if isinstance(parsed, list):
                    return parsed
            return [raw]
        return [raw]
    return raw


def is_empty(value: Any) -> bool:
    """No value: nothing, an empty text, an empty list, a range with no side."""
    if value is None or value == "":
        return True
    if isinstance(value, (list, tuple)):
        return len(value) == 0
    if isinstance(value, dict):
        return not any(v not in (None, "") for v in value.values())
    return False


def value_words(param: Dict[str, Any], value: Any) -> str:
    """The value in plain words, for the band and the Diagnostics panel."""
    kind = str((param or {}).get("parameter_type") or "").strip().lower()
    if is_empty(value):
        if kind == PERIOD_KIND:
            return "Not set (the dates apply as chosen)"
        return "All" if kind in LIST_KINDS or not kind else "No value"
    if kind == PERIOD_KIND and isinstance(value, str):
        from core.reports.period import PERIOD_WORDS
        return PERIOD_WORDS.get(value.lower(), value)
    if kind == "boolean":
        return "Yes" if value is True or str(value).strip().lower() in ("true", "1", "yes", "y", "on") else "No"
    if kind == "hierarchy" and isinstance(value, dict):
        return " › ".join(str(v) for v in value.values() if v not in (None, ""))
    if isinstance(value, dict) and ("a" in value or "b" in value) and "from" not in value:
        return f"{value.get('a') or '?'} (A) vs {value.get('b') or '?'} (B)"
    if isinstance(value, dict):
        lo, hi = value.get("from") or "", value.get("to") or ""
        if lo and hi:
            return lo if lo == hi else f"{lo} to {hi}"
        return f"from {lo}" if lo else f"up to {hi}"
    if isinstance(value, (list, tuple)):
        return ", ".join("(no value)" if v is None else str(v) for v in value)
    return str(value)


def default_text(param: Dict[str, Any]) -> Optional[str]:
    """The stored default as written (a token stays a token)."""
    dv = (param or {}).get("default_value")
    return None if dv in (None, "") else str(dv)


__all__ = ["RANGE_SEPARATOR", "LIST_KINDS", "DATE_KINDS", "PERIOD_KIND", "COMPARE_KIND", "ALL_KINDS", "normalize_value",
           "is_empty", "value_words", "default_text"]
