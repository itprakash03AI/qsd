"""The KPI card -- a number tile with an icon, a comparison and a style (2026-11-02;
docs/REPORT_DESIGN_UPGRADE_PLAN_2026_11_02.html step 2).

The owner's examples: "Assets  £7.63M  ▲  PY: £6.99M  Δ%: 9%", a filled or gradient
card, a card that turns red on a bad variance.  Every bit of it is a FIELD of the
existing ``number`` tile (an old number tile has none and looks as before)::

    icon:      one of KPI_ICONS (a fixed set of business icons; the browser maps the name)
    compare:   {"kind": "parameter"}                          the canvas's two-dates comparison (canvas.compare)
               {"kind": "measure", "column_id", "aggregation", "label"?}   a second value of the SAME result (budget, target, last year)
    good_when: "up" | "down"        which way is good (a cost going up is red); default up
    style:     "theme" | "plain" | "filled" | "gradient"      default "theme" = the theme's kpi.style
    fill:      "#rrggbb"            this card's own fill (else the theme's fills, in turn)
    sparkline: {"column_id", "points": 2..100}   the first value by that column, its last N points

The comparison is COMPUTED from the report's ONE stored result through the
microcube -- the second measure in the same drill, or the two dates as slicers
(``canvas_compare``) -- never a second query to the source.  A comparison that
cannot be computed exactly says so on the card ("No previous value"), never a
made-up number.  Delta and % are ``canvas_compare.variance`` (Decimal).

This module is the save check (``kpi_problems``, called from
``canvas_outline.outline_problems`` for every number tile) and the EXPORT's half
(``kpi_entry`` fills ``entry["kpi"]`` / ``entry["spark"]`` for the Excel and PDF
writers); the browser's twin is ``frontend/src/components/reports/canvas/canvasKpi.ts``.
"""
from __future__ import annotations

from decimal import Decimal
from typing import Any, Callable, Dict, List, Optional

KPI_ICONS = ("money", "bank", "chart", "trend_up", "trend_down", "percent", "people", "person", "building", "globe",
             "calendar", "clock", "warning", "check", "flag", "star", "cart", "box", "truck", "factory", "briefcase",
             "wallet", "card", "receipt", "scale", "shield", "bolt", "target", "pie", "table", "savings", "payments",
             "exchange", "insights", "speed", "assessment")
GOOD_WHEN = ("up", "down")
KPI_TILE_STYLES = ("theme", "plain", "filled", "gradient")
COMPARE_KINDS = ("parameter", "measure")
MIN_SPARK_POINTS, MAX_SPARK_POINTS = 2, 100
MAX_COMPARE_LABEL = 60
NO_PREVIOUS = "No previous value"


def _int(v: Any) -> Optional[int]:
    if isinstance(v, bool):
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _is_hex(v: Any) -> bool:
    from core.reports.themes import _is_hex
    return _is_hex(v)


def kpi_problems(t: dict, *, cols: Dict[int, dict], selected: set, grouped: bool,
                 say: Callable[[Optional[dict], str], None], canvas: Optional[dict] = None) -> None:
    """Every problem of a number tile's KPI fields, in plain words (the browser's ``kpiProblems`` says the same)."""
    from core.reports.canvas import _label, measure_problems
    icon = t.get("icon")
    if icon is not None and icon not in KPI_ICONS:
        say(t, f'"{icon}" is not one of the card icons.')
    gw = t.get("good_when")
    if gw is not None and gw not in GOOD_WHEN:
        say(t, "a good change is up or down.")
    st = t.get("style")
    if st is not None and st not in KPI_TILE_STYLES:
        say(t, "a card is drawn as the theme says, plain, filled or as a gradient.")
    fill = t.get("fill")
    if fill is not None and not _is_hex(fill):
        say(t, "the card's fill must be a colour like #1e6fd9.")
    cmp = t.get("compare")
    if cmp is not None:
        if not isinstance(cmp, dict) or cmp.get("kind") not in COMPARE_KINDS:
            say(t, "the comparison is with the report's two dates, or with another value.")
        elif cmp["kind"] == "parameter":
            if not isinstance((canvas or {}).get("compare"), dict):
                say(t, 'it compares with the report\'s two dates, but the canvas has no "two dates to compare" parameter set.')
        else:
            cid = _int(cmp.get("column_id"))
            if cid is None or cid not in cols:
                say(t, "the value it compares with is no longer in the data. Pick another.")
            else:
                if cid not in selected:
                    say(t, f"{_label(cols[cid], cid)} is not one of the report's columns, so the report does not return it. Add it to the report.")
                for msg in measure_problems({"column_id": cid, "aggregation": cmp.get("aggregation")}, cols, grouped):
                    say(t, msg)
            lab = cmp.get("label")
            if lab is not None and (not isinstance(lab, str) or len(lab.strip()) > MAX_COMPARE_LABEL):
                say(t, f"the comparison's name must be text of at most {MAX_COMPARE_LABEL} characters.")
    sp = t.get("sparkline")
    if sp is not None:
        if not isinstance(sp, dict):
            say(t, "a sparkline names the column its points follow and how many points.")
        else:
            cid = _int(sp.get("column_id"))
            if cid is None or cid not in cols:
                say(t, "the sparkline follows a column that is no longer in the data.")
            elif cid not in selected:
                say(t, f"{_label(cols[cid], cid)} is not one of the report's columns, so the report does not return it. Add it to the report.")
            elif any(_int(m.get("column_id")) == cid for m in (t.get("measures") or []) if isinstance(m, dict)):
                say(t, "the sparkline follows the card's own value; pick a date or an ordered column.")
            n = sp.get("points")
            if not isinstance(n, int) or isinstance(n, bool) or not MIN_SPARK_POINTS <= n <= MAX_SPARK_POINTS:
                say(t, f"a sparkline draws between {MIN_SPARK_POINTS} and {MAX_SPARK_POINTS} points.")


def kpi_column_ids(t: dict) -> List[int]:
    """The columns a number tile's KPI fields need the report's ONE query to return."""
    out: List[int] = []
    cmp = t.get("compare") if isinstance(t.get("compare"), dict) else {}
    if cmp.get("kind") == "measure" and _int(cmp.get("column_id")) is not None:
        out.append(int(cmp["column_id"]))
    sp = t.get("sparkline") if isinstance(t.get("sparkline"), dict) else {}
    if _int(sp.get("column_id")) is not None:
        out.append(int(sp["column_id"]))
    return out


def delta_words(value: Any, previous: Any, good_when: str) -> Dict[str, Any]:
    """``{variance, pct, direction: up|down|flat|none, good: bool|None}`` -- the
    card's change line; ``none`` when there is no previous value."""
    from core.reports.canvas_compare import variance, _dec
    if previous is None or _dec(previous) is None:
        return {"variance": None, "pct": None, "direction": "none", "good": None}
    vv = variance(previous, value)
    var = vv["variance"]
    if var is None:
        return {"variance": None, "pct": None, "direction": "none", "good": None}
    direction = "up" if var > 0 else "down" if var < 0 else "flat"
    good = None if direction == "flat" else (direction == good_when)
    return {"variance": var, "pct": vv["pct"], "direction": direction, "good": good}


def kpi_look(t: dict, index: int, look: Optional[dict]) -> Dict[str, Any]:
    """The card's style and fill for a DOCUMENT: the tile's own style / fill over the
    theme's (``themes.card_look``; hexes without '#').  ``index`` = the card's
    position among the number tiles (the fills are used in turn)."""
    look = look or {}
    style = t.get("style") if t.get("style") in KPI_TILE_STYLES else "theme"
    if style == "theme":
        style = look.get("kpi_style") if look.get("kpi_style") in ("plain", "filled", "gradient") else "plain"
    fills = look.get("kpi_fills") or ["1E6FD9"]
    fill = t["fill"].lstrip("#").upper() if _is_hex(t.get("fill")) else fills[index % len(fills)]
    return {"style": style, "fill": fill, "value_fg": look.get("kpi_value_fg") or "FFFFFF",
            "label_fg": look.get("kpi_label_fg") or "FFFFFF", "up_fg": look.get("kpi_up_fg") or "1A7F4B",
            "down_fg": look.get("kpi_down_fg") or "C62828"}


def kpi_entry(entry: dict, t: dict, path, cols: Dict[int, dict], phys, ms: List[dict], measures: List[dict],
              compare_setting: Optional[dict], drill_all, measure_header, fmt, *, grain: str, group_columns,
              budget, slicers=None, index: int = 0, look: Optional[dict] = None) -> None:
    """Fill a number tile's export entry: ``header`` / ``rows`` as today (the
    value; under the two-dates comparison A, B, Variance, %; with a second value
    the value and that value), plus ``entry["kpi"]`` = what the card shows and
    ``entry["spark"]`` = the sparkline's points."""
    from core.reports import canvas_compare as _cmp
    cmp = t.get("compare") if isinstance(t.get("compare"), dict) else {}
    kind = cmp.get("kind")
    good_when = t.get("good_when") if t.get("good_when") in GOOD_WHEN else "up"
    label = measure_header(ms[0], cols)
    value = previous = None
    previous_words = ""
    if kind != "measure" and compare_setting and not compare_setting.get("error"):
        # the two dates, in ONE drill BY the date column with both as slicers: a date with no
        # rows is simply ABSENT (a SUM over no rows would come back 0 -- a made-up previous);
        # the entry keeps the A, B, Variance, % shape of canvas_compare.compare_entry
        from core.reports.canvas_links import merge_slicers
        col_name = phys(compare_setting["column_id"])
        a_txt, b_txt = str(compare_setting["a"]), str(compare_setting["b"])
        if not col_name:
            entry["note"] = "The comparison's date column is not in this run."
        else:
            sl = merge_slicers(slicers, {col_name: [a_txt, b_txt]}) if slicers else {col_name: [a_txt, b_txt]}
            res = drill_all(path, [col_name], measures[:1], sort_column=col_name, sort_direction="asc", grain=grain,
                            group_cols=group_columns, limit=4, slicers=sl)
            by_date = {str(r.get(col_name))[:10]: r.get("v0__") for r in res["rows"]}
            previous, value = by_date.get(a_txt[:10]), by_date.get(b_txt[:10])
            side_a, side_b = a_txt[:10] in by_date, b_txt[:10] in by_date
        mh = label
        mf = fmt(cols.get(int(ms[0]["column_id"])))
        vv = _cmp.variance(previous, value) if (col_name and side_a and side_b) else {"variance": None, "pct": None}
        entry["header"] = [f"{mh} {a_txt}", f"{mh} {b_txt}", f"{mh} variance", f"{mh} % variance"]
        entry["formats"] = [mf, mf, mf, "0.00"]
        entry["rows"] = [[previous, value, vv["variance"], vv["pct"]]] if col_name else []
        entry["compare"] = {"a": a_txt, "b": b_txt}
        entry["note"] = (f"{compare_setting['words']}. " + (entry.get("note") or "")).strip()
        budget[0] -= 4
        previous_words = f"vs {a_txt}"
    else:
        extra = []
        if kind == "measure" and _int(cmp.get("column_id")) is not None:
            extra = [{"column": phys(cmp["column_id"]), "aggregation": cmp.get("aggregation"), "alias": "v1__"}]
        res = drill_all(path, [], measures[:1] + extra, sort_column=None, sort_direction="asc", grain=grain,
                        group_cols=group_columns, limit=1, slicers=slicers)
        row = res["rows"][0] if res["rows"] else None
        value = row.get("v0__") if row else None
        entry["header"] = [label]
        entry["formats"] = [fmt(cols.get(int(ms[0]["column_id"])))]
        if extra:
            c = cols.get(int(cmp["column_id"]))
            previous_words = str(cmp.get("label") or "").strip() or measure_header({"column_id": cmp["column_id"], "aggregation": cmp.get("aggregation")}, cols)
            previous = row.get("v1__") if row else None
            entry["header"].append(previous_words)
            entry["formats"].append(fmt(c))
            previous_words = f"vs {previous_words}"
            entry["rows"] = [[value, previous]] if row else []
        else:
            entry["rows"] = [[value]] if row else []
        budget[0] -= 2
        if kind != "measure" and compare_setting and compare_setting.get("error"):
            entry["note"] = (str(compare_setting["error"]) + " " + (entry.get("note") or "")).strip()
    has_compare = bool(kind) or bool(compare_setting and not compare_setting.get("error") and kind != "measure")
    change = delta_words(value, previous, good_when) if has_compare else None
    entry["kpi"] = {"value": value, "previous": previous, "previous_words": previous_words, "label": label,
                    "icon": t.get("icon") if t.get("icon") in KPI_ICONS else None, "good_when": good_when,
                    "change": change, "no_previous": bool(has_compare and (change or {}).get("direction") == "none"),
                    **kpi_look(t, index, look)}
    sp = t.get("sparkline") if isinstance(t.get("sparkline"), dict) else None
    if sp and _int(sp.get("column_id")) is not None and isinstance(sp.get("points"), int):
        col = phys(sp["column_id"])
        n = max(MIN_SPARK_POINTS, min(MAX_SPARK_POINTS, int(sp["points"])))
        res = drill_all(path, [col], measures[:1], sort_column=col, sort_direction="desc", grain=grain,
                        group_cols=group_columns, limit=n, slicers=slicers)
        pts = [[r.get(col), r.get("v0__")] for r in res["rows"]][::-1]
        entry["spark"] = {"header": [cols.get(int(sp["column_id"]), {}).get("friendly_name") or col, label], "rows": pts}
        budget[0] -= 2 * len(pts)


def change_text(kpi: dict, fmt_number: Callable[[Any], str]) -> str:
    """The change line as words: "▲ 1,234 (+9.1%) vs 30-Oct-2026" / "No previous value" / ""."""
    ch = kpi.get("change")
    if not ch:
        return ""
    if ch.get("direction") == "none":
        return NO_PREVIOUS
    arrow = {"up": "▲", "down": "▼", "flat": "•"}[ch["direction"]]
    var = ch["variance"]
    pct = ch.get("pct")
    pct_words = "" if pct is None else f" ({'+' if pct > 0 else ''}{pct}%)"
    return f"{arrow} {fmt_number(abs(var) if isinstance(var, Decimal) else var)}{pct_words} {kpi.get('previous_words') or ''}".strip()


def change_colour(kpi: dict) -> Optional[str]:
    """The hex (no '#') of the change line: the up colour for a good change, the
    down colour for a bad one, None when flat / no previous / no comparison."""
    ch = kpi.get("change")
    if not ch or ch.get("good") is None:
        return None
    return kpi["up_fg"] if ch["good"] else kpi["down_fg"]


__all__ = ["KPI_ICONS", "GOOD_WHEN", "KPI_TILE_STYLES", "COMPARE_KINDS", "MAX_SPARK_POINTS", "NO_PREVIOUS",
           "kpi_problems", "kpi_column_ids", "delta_words", "kpi_look", "kpi_entry", "change_text", "change_colour"]
