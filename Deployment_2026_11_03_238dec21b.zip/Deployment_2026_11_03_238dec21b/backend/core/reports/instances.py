"""Report-instance layer — Phase 2 of the reports rewire (2026-08-09).

The product owner's requirement, verbatim in spirit: *"why need so much
cpu... if user already ran report cache should serve from cache also."*
This module is the ONE chokepoint that makes an execution's already-written
``{execution_id}.parquet`` artifact addressable and re-servable — the
BusinessObjects "instance" model (target architecture §5, industry research
§1).  It owns BOTH directions:

* **Write-through** — :func:`record_report_instance`.  Called after every
  successful execution that produced a verified artifact (sync execute,
  async execute, ``core/reports/sources.py execute_headless``).  Cost: one
  INSERT plus a retention prune.  Scheduled/headless runs stamp
  ``is_scheduled=True`` — the 6am schedule producing the instance every 9am
  user opens for free is the entire point.
* **Read-through** — :func:`try_serve_instance`.  Called by the execute
  endpoints BEFORE running anything.  A hit returns the standard wire
  envelope pointing at the stored artifact, with instance metadata
  attached; a miss returns ``None`` and the caller runs live, exactly as
  today.

Cap/gate discipline (docs/reports_target_architecture_2026_08_08.md §5.4)
------------------------------------------------------------------------
GATES — never served wrong, doubt = MISS = run live:

* ``rls_signature`` — recomputed LIVE for the caller on every request via
  ``core/row_security/signature.py scope_signature()`` (never read back
  from a stored row for matching — that recomputation is what makes a
  policy edit invalidate structurally).  :class:`ScopeSignatureError` is a
  MISS, never a wildcard.  Serving another user's artifact is lawful ONLY
  under byte-identical signatures AND a passing
  ``can_view_business_report`` check — both, not either.
* ``params_fingerprint`` — over resolved (macro-expanded) parameter values,
  so ``@TODAY`` keys to the actual date it resolved to.
* ``semantic_version`` — a content hash of the report DEFINITION plus its
  semantic-model rows (dataset + column definitions + view-source
  versions).  Deliberately NOT ``updated_at`` of the report row: that
  column moves on every ``execution_count`` bump, which would invalidate
  every instance on every live run for no semantic reason.  Any edit to
  what the report MEANS changes the hash; execution-stat noise does not.
* artifact existence — ``core/reports/contract.py require_artifact``; an
  instance whose bytes cannot be verified is a MISS.

CAPS — throttle/disclose, never refuse:

* staleness — a stale instance (status ``stale``, ``stale_at`` passed, or
  older than ``business_reports.instance_max_age_seconds``) is served WITH
  ``stale: true`` + ``as_of`` disclosure and a background refresh is
  queued (the exact ``core/agg_cache.py`` stale-serve posture:
  serve-with-banner + daemon-thread refresh — not a second posture).
  Unknown freshness (no ``source_version``) is DISCLOSED as
  ``freshness: "unknown"``, never coerced to "fresh".
* retention — newest ``instance_retention_count`` rows per serve key
  (``prune_report_instances``); an evicted instance simply means the next
  open runs live.

Flag: ``business_reports.instance_serving_enabled`` — **ON** by default since 2026-09-26.  Both
directions are inert while off, so merged behaviour is byte-identical to
today; flipping it is a deliberate one-line act.
"""
from __future__ import annotations

import hashlib
import json
import logging
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.reports.contract import ReportEnvelope, require_artifact
from core.row_security.signature import (
    ScopeSignatureError,
    params_fingerprint,
    scope_signature,
)

logger = logging.getLogger(__name__)

# Domain separation for the semantic-version hash — bump on payload change.
# Version marker AND migration mechanism for compute_semantic_version, the
# third GATE of the report-instance serve key (the other two are
# params_fingerprint and rls_signature).  2026-09-13 security-hotspot
# triage (ruff S324): this was sha1.  A semantic_version collision serves
# an instance built under a DIFFERENT report definition -- the concrete
# defect the 2026-08-10 parameter fold exists to prevent (author drops a
# filter parameter, a saved link still matches the instance built with it
# applied).  Its inputs -- a report's name, SQL, column and parameter
# definitions -- are author-supplied text, so collision material is
# reachable by anyone who can edit a report.  SHA-256.
#
# "sv2:" can never string-equal a stored "sv1:" key, so every sha1-era row
# MISSES and re-executes live rather than colliding.  _SV_HEX keeps
# prefix+digest inside ReportInstance.semantic_version's String(64): a full
# hexdigest is 64 chars and "sv2:" + 64 = 68 would be REJECTED by Postgres
# on insert (SQLite would not complain, so the break would be
# production-only).  224 truncated bits is ~112-bit collision resistance,
# against SHA-1's demonstrated ~2**61.
_SV_PREFIX = "sv2:"
_SV_HEX = 56

_SV_DOMAIN = "qs-report-semver-v1\x00"

#: BusinessReport fields that define WHAT the report means.  ``updated_at``
#: is deliberately excluded (it moves on execution-count bumps — see module
#: docstring); ``is_published`` / whitelists are ACCESS, not meaning, and
#: are enforced by the permission gate instead.
_SEMANTIC_FIELDS = (
    "dataset_id", "merged_dataset_id", "merge_config",
    "merged_dataset_column_ids", "column_ids", "filter_specs",
    "condition_ids", "order_by", "row_limit", "section_definitions",
    "running_calculations", "slicer_column_ids", "drill_hierarchy_id",
    "layout_config", "data_source_type", "federation_view_id",
    "published_view_id", "raw_saved_query_id", "raw_sql_saved_query_id",
    "raw_sql_file_id", "raw_sql_override", "raw_connection_override_id",
)


def instance_serving_enabled() -> bool:
    """The rollout flag.  Unreadable config keeps the feature OFF — this
    flag is an access/behaviour WIDENER, so its fail mode is closed."""
    try:
        from core import config as _cfg
        return bool(_cfg.business_reports.instance_serving_enabled)
    except Exception:
        return False


# ── key derivation ───────────────────────────────────────────────────────────

def canonical_params_fingerprint(param_values: Optional[Dict[str, Any]]) -> str:
    """Fingerprint of RESOLVED parameter values — the one canonicalisation
    both write-through and read-through use, so they can never drift.

    Relative-date macros (``@TODAY`` …) are expanded through the same
    ``_resolve_param_value`` the execution path uses: an instance produced
    under ``@TODAY`` keys to the concrete date, so tomorrow's ``@TODAY``
    open structurally misses instead of serving yesterday's rows as
    today's (params are a GATE).  Raises on non-canonicalisable values
    (callers map that to MISS / skip — fail-closed).
    """
    from api.business_reports_api import _resolve_param_value
    resolved = _resolve_param_value(dict(param_values or {}))
    return params_fingerprint(resolved)


def compute_caller_signature(db, report: Dict[str, Any], user_ctx: Any) -> str:
    """The caller's LIVE row-security scope signature for this report.

    Dataset-backed reports scope to their dataset (finer sharing).  Reports
    spanning a merged secondary dataset use the GLOBAL scope — a
    dataset-scoped signature over only the primary would under-collect the
    secondary's tables, and under-collection is the leak vector; global
    scoping can only over-partition (lose sharing), never collide.
    Raises :class:`ScopeSignatureError` on any uncertainty.
    """
    ds_id = report.get("dataset_id") or None  # 0 = sentinel (raw_sql/PV/FV)
    if report.get("merged_dataset_id"):
        ds_id = None
    sig = scope_signature(user_ctx,
                          dataset_id=(int(ds_id) if ds_id else None),
                          db=db)
    # 2026-08-29 — ``scope_signature`` returns SCOPE_OPEN when row-security is
    # off, on the stated premise that "enforcement rewrites nothing for ANYONE
    # ⇒ every caller's executed SQL — and result bytes — are identical".
    # ``${user.*}`` in a report's own SQL breaks that premise exactly there:
    # the SQL differs per caller with row-security disabled, so an instance
    # stored for one principal would be served to another.  Fold the identity
    # in for those reports only — over-partitioning loses sharing, never
    # collides.
    from core.reports.user_sql_vars import report_references_user_vars
    if report_references_user_vars(report, db):
        from core.row_security.signature import _to_identity
        ident = _to_identity(user_ctx)
        groups = ",".join(sorted(str(g) for g in (ident.groups or ())))
        sig = hashlib.sha256(
            f"{sig}|sv={ident.username}:{ident.role}:{groups}".encode("utf-8")
        ).hexdigest()[:40]
    return sig


def compute_semantic_version(db, report: Dict[str, Any]) -> str:
    """Deterministic content hash of the report definition + semantic model.

    Folds: the report's definition fields (:data:`_SEMANTIC_FIELDS`), each
    referenced dataset's ``updated_at`` / ``base_query`` / column
    definitions, and the backing view's version for PV/FV reports.  Any
    edit to any of these changes the hash → every stored instance
    structurally misses (GATE).  Raises when a referenced object cannot be
    read — an unknowable semantic version must never match anything.
    """
    payload: Dict[str, Any] = {
        "report_id": int(report["id"]),
        "def": {f: report.get(f) for f in _SEMANTIC_FIELDS},
    }

    ds_parts = []
    for key in ("dataset_id", "merged_dataset_id"):
        ds_id = report.get(key)
        if not ds_id:
            continue
        ds = db.get_dataset(int(ds_id))
        if not ds:
            raise ValueError(
                f"semantic_version: dataset {ds_id} (report "
                f"{report.get('id')} {key}) not found — refusing to key "
                "(fail-closed)")
        cols = db.list_dataset_columns(int(ds_id)) or []
        ds_parts.append({
            "key": key,
            "id": int(ds_id),
            "updated_at": str(ds.get("updated_at") or ""),
            "base_query": str(ds.get("base_query") or ""),
            "columns": sorted(
                [[c.get("id"),
                  str(c.get("physical_name") or ""),
                  str(c.get("column_type") or ""),
                  str(c.get("data_type") or ""),
                  str(c.get("aggregation") or "")] for c in cols]),
        })
    payload["datasets"] = ds_parts

    # PARAMETER DEFINITIONS (2026-08-10).  Parameters live in their OWN table
    # (report_parameters), so no ``_SEMANTIC_FIELDS`` entry can reach them,
    # and editing them left the semantic version unchanged.  The params
    # FINGERPRINT does not cover it either: it hashes the caller's resolved
    # VALUES, so a caller replaying the same payload after the author removed
    # or retyped a parameter produced an identical pf AND an identical sv —
    # and got served the instance built under the OLD definition.  Concretely:
    # report filtered by {A, B}; author drops B; a saved link still sends
    # {A:1, B:2}; the pre-2026-08-10 key matched the B-filtered instance.
    #
    # ``lov_column_id`` / ``depends_on_param_id`` / ``cascade_filter_column_id``
    # are folded because they change which rows a value resolves to;
    # ``label`` / ``description`` are NOT (presentation only, and re-running
    # every instance for a typo fix is a pure cost).  ``sort_order`` IS folded
    # — it drives cascade evaluation order, not just display.
    #
    # Fail-closed like the dataset fold above: an unreadable parameter set is
    # an unknowable semantic version, which must never match anything.
    #
    # Publish lifecycle (2026-08-17): a report dict resolved to a PUBLISHED
    # VERSION carries the snapshotted parameter rows in
    # ``_version_parameters`` (core/reports/versions.apply_version).  Fold
    # THOSE, not the live table — the instance an execution of v3 records
    # must be keyed by v3's parameter definitions, or a draft parameter edit
    # would perturb every consumer's serve key while consumers still execute
    # the unchanged published snapshot.  Draft executions (no key present)
    # keep folding the live table exactly as before.
    try:
        if "_version_parameters" in report:
            _params = report.get("_version_parameters") or []
        else:
            _params = db.list_report_parameters(int(report["id"])) or []
    except Exception as exc:
        raise ValueError(
            f"semantic_version: cannot read parameters for report "
            f"{report.get('id')} ({exc}) — refusing to key (fail-closed)"
        ) from exc
    payload["params"] = sorted(
        [[str(p.get("name") or ""),
          str(p.get("parameter_type") or ""),
          str(p.get("default_value") or ""),
          bool(p.get("is_required")),
          p.get("lov_column_id"),
          p.get("depends_on_param_id"),
          p.get("cascade_filter_column_id"),
          p.get("sort_order")] for p in _params if isinstance(p, dict)],
        key=lambda r: (r[0], str(r[7])),
    )
    # The inline schema raw-SQL reports use instead of that table — same
    # reasoning, and it IS a plain column so it rides in the definition fold.
    payload["raw_params"] = report.get("raw_parameters_schema")

    dst = str(report.get("data_source_type") or "saved_query")
    if dst == "published_view":
        pv_id = report.get("published_view_id")
        pv = db.get_published_view(int(pv_id)) if pv_id else None
        if not pv:
            raise ValueError(
                f"semantic_version: published view {pv_id} (report "
                f"{report.get('id')}) not found — refusing to key")
        payload["pv"] = [int(pv_id), pv.get("version"),
                         str(pv.get("query_hash") or ""),
                         str(pv.get("updated_at") or "")]
    elif dst == "federation_view":
        fv_id = report.get("federation_view_id")
        fv = db.get_federation_view(int(fv_id)) if fv_id else None
        if not fv:
            raise ValueError(
                f"semantic_version: federation view {fv_id} (report "
                f"{report.get('id')}) not found — refusing to key")
        payload["fv"] = [int(fv_id), str(fv.get("updated_at") or "")]

    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, default=str)
    return _SV_PREFIX + hashlib.sha256(
        (_SV_DOMAIN + blob).encode("utf-8")).hexdigest()[:_SV_HEX]


# ── write-through ────────────────────────────────────────────────────────────

def truncation_facts(resp: Any, fallback_row_limit: Optional[int]
                     ) -> Dict[str, Any]:
    """Extract the RUN's truncation facts from an execution response —
    the ONE extraction both write-through call sites and tests use.

    D1/D2 (2026-08-09 adversarial cross-feature review): an instance that
    stores only ``row_count`` forces the serve to RECOMPUTE the truncation
    verdict against the BR-configured limit — which resurrects the silent-
    truncation defect 122a8c30 killed (engine clamped at
    ``federation.max_result_rows`` → live run disclosed ``truncated: true``,
    every subsequent serve compared 100000 >= 500000 → ``false``, the
    contract's "definitely complete" value, for a definitely-cut result).

    Mirrors ``business_reports_api._with_contract_keys`` exactly, so what
    gets STORED is what the live response WIRES:

    * ``row_limit`` — the engine-stamped EFFECTIVE limit wins; paths that
      don't stamp one fall back to the caller's limit (same precedence);
    * ``truncated`` — an engine-stamped verdict (key present) wins, even
      ``None``; else computed ``total >= effective limit``; unknowable stays
      ``None`` (tri-state preserved — UNKNOWN is stored as NULL, never
      coerced to False);
    * ``unstable_truncation`` — passed through verbatim (the engine emits
      ``True`` or omits it — "WHICH rows were kept is not stable").

    Returns kwargs for :func:`record_report_instance` (splat with ``**``).
    """
    from core.reports.contract import normalize_row_limit, truncation_verdict
    resp = resp if isinstance(resp, dict) else {}
    eff_limit = resp.get("row_limit")
    if eff_limit is None:
        eff_limit = fallback_row_limit
    if "truncated" in resp:
        truncated = resp.get("truncated")
    else:
        # CORR-2 (2026-08-22): verdict via the ONE chokepoint — an explicit
        # eff_limit of 0 (unlimited) reads COMPLETE (False), not UNKNOWN.
        truncated = truncation_verdict(resp.get("total_rows"), eff_limit)
    return {
        # CORR-2: 0 (unlimited, known) preserved distinct from None (absent).
        "row_limit": normalize_row_limit(eff_limit),
        "truncated": truncated,
        "unstable_truncation": resp.get("unstable_truncation"),
    }


def incomplete_artifact_reason(artifact_path: Any) -> Optional[str]:
    """Why this path is NOT a servable, complete result artifact — or ``None``.

    2026-09-05, progressive serving.  An instance is a promise that the whole
    result is at that path: ``try_serve_instance`` hands the path straight to
    the paged reader, and a served instance is disclosed as complete data,
    only ever STALE.  A partitioned build is a directory of parts plus a
    manifest that is still growing, and the merged file it will become does
    not exist yet.  Recording either as an instance would publish a partial
    result as a finished one — and unlike a partial manifest, a stored
    instance carries no "still building" flag for a reader to notice.

    Two states are refused, and only these two:

      * the path IS a parts directory (a manifest sits in it), or
      * the file does not exist and a parts dataset sits BESIDE it, i.e. the
        build has not been consolidated yet.

    A completed ordinary run has no ``.parts`` sibling (consolidation removes
    it), so this never fires on the artifact of a report that finished — the
    refusal has to be silent on every legitimate input or it is a defect of
    its own.
    """
    if not artifact_path:
        return None
    from core.reports.pagination import parts_dir_for
    try:
        from core.feed.parts_manifest import is_parts_dir
    except Exception as exc:                                  # pragma: no cover
        logger.debug("[report-instance] parts probe unavailable: %s", exc)
        return None
    try:
        p = Path(str(artifact_path))
        if is_parts_dir(p):
            return f"{p} is a parts DIRECTORY, not a single result artifact"
        if not p.is_file() and is_parts_dir(parts_dir_for(p)):
            return (f"{p} does not exist yet and a parts build is still open "
                    f"beside it ({parts_dir_for(p)}) — the result is partial")
    except OSError as exc:
        logger.debug("[report-instance] could not classify artifact %s: %s",
                     artifact_path, exc)
    return None


def record_report_instance(db, report: Dict[str, Any], user_ctx: Any,
                           param_values: Optional[Dict[str, Any]], *,
                           execution_id: str,
                           artifact_path: Optional[str] = None,
                           row_count: Optional[int] = None,
                           is_scheduled: bool = False,
                           created_by: Optional[str] = None,
                           row_limit: Optional[int] = None,
                           truncated: Optional[bool] = None,
                           unstable_truncation: Optional[bool] = None,
                           iceberg_versions: Optional[List[Dict[str, Any]]] = None,
                           ) -> Optional[Dict[str, Any]]:
    """Record a successful execution as a servable :class:`ReportInstance`.

    ``iceberg_versions`` (2026-11-01): the version each Iceberg table of the
    run was read at (``FederationResult.iceberg_versions``), so a sign-off
    names it and "what changed since I signed" can say "the data version
    moved" (core/reports/instance_diff.py).  None = not recorded.

    ``user_ctx`` MUST be the principal the execution ran under (the caller
    for interactive runs, the owner ctx for headless runs) — the stored
    signature is the scope the ARTIFACT was computed at.

    ``row_limit``/``truncated``/``unstable_truncation`` are the RUN's
    truncation facts (see :func:`truncation_facts`) — persisted so serves
    disclose the run's verdict instead of recomputing one.  ``None`` =
    unknown, stored as NULL, served as UNKNOWN.

    FAIL-OPEN by design: the write-through is additive, so any failure —
    including an unsignable scope — logs and returns ``None`` without ever
    affecting the execution's success.  Flag-gated: no-op while
    ``instance_serving_enabled`` is off (flag-off behaviour and cost stay
    byte-identical to today).  Applies the retention CAP
    (``instance_retention_count``) after inserting.
    """
    try:
        if not instance_serving_enabled():
            return None
        if not isinstance(report, dict) or not report.get("id"):
            return None
        if not execution_id:
            return None
        creator = created_by or (
            (user_ctx or {}).get("username", "") if isinstance(user_ctx, dict)
            else "")
        if not creator:
            return None

        # A PARTIAL dataset must never be stored as a complete instance.
        # Fail-open in the usual sense — the execution is unaffected — but
        # NOT silent: a skipped write-through means the next open runs live,
        # which is correct, whereas a recorded partial would be served as the
        # whole answer to somebody else.
        _partial = incomplete_artifact_reason(artifact_path)
        if _partial:
            logger.warning(
                "[report-instance] NOT recording exec=%s report=%s — %s. "
                "The next open of this report runs live instead of serving a "
                "partial result as a complete one.",
                execution_id, report.get("id"), _partial)
            return None

        pf = canonical_params_fingerprint(param_values)
        sig = compute_caller_signature(db, report, user_ctx)
        sv = compute_semantic_version(db, report)

        inst = db.create_report_instance(
            report_id=int(report["id"]),
            execution_id=str(execution_id),
            params_fingerprint=pf,
            rls_signature=sig,
            semantic_version=sv,
            created_by=str(creator),
            artifact_path=(str(artifact_path) if artifact_path else None),
            row_count=(int(row_count) if row_count is not None else None),
            is_scheduled=bool(is_scheduled),
            row_limit=(int(row_limit) if row_limit is not None else None),
            truncated=truncated,
            unstable_truncation=unstable_truncation,
            iceberg_versions=iceberg_versions,
        )
        # Retention CAP — newest N per serve key; an evicted row only means
        # the next open runs live.
        try:
            from core import config as _cfg
            keep = int(_cfg.business_reports.instance_retention_count)
            if keep > 0:
                db.prune_report_instances(report_id=int(report["id"]),
                                          keep_latest=keep)
        except Exception as prune_exc:
            logger.debug("[report-instance] retention prune skipped: %s",
                         prune_exc)
        logger.info("[report-instance] recorded instance=%s report=%s "
                    "exec=%s scheduled=%s by=%s",
                    inst.get("id"), report.get("id"), execution_id,
                    bool(is_scheduled), creator)
        return inst
    except ScopeSignatureError as exc:
        logger.info("[report-instance] write-through skipped — scope "
                    "unsignable (fail-closed, execution unaffected): %s", exc)
        return None
    except Exception as exc:
        logger.warning("[report-instance] write-through failed (fail-open, "
                       "execution unaffected): %s", exc)
        return None


# ── read-through ─────────────────────────────────────────────────────────────

def try_serve_instance(db, report: Dict[str, Any], user_ctx: Any,
                       param_values: Optional[Dict[str, Any]], *,
                       row_limit: Optional[int] = None,
                       surface: str = "interactive",
                       ) -> Optional[Dict[str, Any]]:
    """Serve the latest matching instance to this caller, or ``None`` (= run
    live).  NEVER raises — every uncertainty is a MISS and the caller
    executes exactly as today (where ``SqlRewriter`` enforces RLS at
    source).

    Serve conditions, ALL required (docs §5.2):

    1. flag ON, report does not force ``refresh_on_open``;
    2. caller passes ``can_view_business_report`` (permission gate), AND
    3. the caller's LIVE-recomputed ``rls_signature`` + resolved
       ``params_fingerprint`` + ``semantic_version`` exact-match a stored
       instance (key gates — :class:`ScopeSignatureError` or any
       uncomputable component is a MISS, never a wildcard), AND
    4. the artifact verifies via ``require_artifact``.

    A stale hit is still served (staleness is a CAP) — with ``stale: true``,
    ``as_of`` and ``freshness`` disclosed, and a background refresh queued.

    The serve registers a completed ``br_async_jobs`` row under a fresh
    ``ri_…`` execution id created BY THE CALLER, so the standard paged
    retrieval flow works for them without widening the stricter
    executor/owner/admin gate on foreign federation executions (the
    existing exec-id retrieval path is unchanged, per §5.2).
    """
    try:
        if not instance_serving_enabled():
            return None
        if not isinstance(report, dict) or not report.get("id"):
            return None
        if report.get("refresh_on_open"):
            return None  # per-report "Refresh When Open" — always live
        if not isinstance(user_ctx, dict) or not user_ctx.get("username"):
            return None  # unverifiable principal — never serve

        # GATE — permission (required IN ADDITION to signature equality).
        try:
            from core.reports.authorization import can_view_business_report
            if not can_view_business_report(report, user_ctx, db):
                return None
        except Exception as exc:
            logger.debug("[report-instance] permission check errored — MISS "
                         "(fail-closed): %s", exc)
            return None

        # GATE — the serve key, recomputed live for THIS caller.
        try:
            pf = canonical_params_fingerprint(param_values)
            sig = compute_caller_signature(db, report, user_ctx)
            sv = compute_semantic_version(db, report)
        except ScopeSignatureError as exc:
            logger.info("[report-instance] MISS — caller scope unsignable "
                        "(fail-closed, running live): %s", exc)
            return None
        except Exception as exc:
            logger.info("[report-instance] MISS — serve key uncomputable "
                        "(fail-closed, running live): %s", exc)
            return None

        inst = db.find_latest_report_instance(
            report_id=int(report["id"]),
            params_fingerprint=pf,
            rls_signature=sig,
            semantic_version=sv,
        )
        if not inst:
            return None

        # GATE — the bytes must verifiably exist.
        try:
            path = require_artifact(str(inst["execution_id"]),
                                    inst.get("artifact_path"))
        except Exception as exc:
            logger.info("[report-instance] MISS — instance %s artifact "
                        "unverifiable (running live): %s",
                        inst.get("id"), exc)
            return None

        # CAP — temporal staleness: disclosed + refreshed, never refused.
        now = datetime.now(timezone.utc)
        stale = (inst.get("status") == "stale")
        stale_at = _parse_dt(inst.get("stale_at"))
        if stale_at is not None and now > stale_at:
            stale = True
        created = _parse_dt(inst.get("created_at"))
        try:
            from core import config as _cfg
            max_age = int(_cfg.business_reports.instance_max_age_seconds)
        except Exception:
            max_age = 0
        if (max_age > 0 and created is not None
                and (now - created).total_seconds() > max_age):
            stale = True
        refresh_queued = False
        if stale:
            refresh_queued = _trigger_instance_refresh(
                db, report, user_ctx, param_values,
                key=(int(report["id"]), pf, sig))

        # Register this serve for retrieval by THE CALLER (their own
        # completed job row → the standard paged-results flow).  If the
        # serve cannot be registered the caller could not page it — MISS.
        username = str(user_ctx.get("username"))
        serve_eid = "ri_" + uuid.uuid4().hex[:24]
        row_count = inst.get("row_count")
        try:
            db.create_br_async_job(serve_eid, int(report["id"]),
                                   created_by=username)
            db.update_br_async_job(serve_eid, status="completed",
                                   progress_pct=100,
                                   total_rows=int(row_count or 0),
                                   output_path=str(path))
        except Exception as exc:
            logger.warning("[report-instance] MISS — serve could not be "
                           "registered for retrieval (running live): %s", exc)
            return None
        # the serve carries the producing run's record (its parameters, its
        # filters) under its own id -- core/reports/diagnostics.record_serve
        try:
            from core.reports.diagnostics import record_serve
            if not record_serve(db, serve_execution_id=serve_eid, source_execution_id=str(inst["execution_id"]),
                                report_id=int(report["id"]), served_to=username):
                logger.info("[report-instance] serve %s: run %s has no record to carry", serve_eid, inst["execution_id"])
        except Exception as exc:                             # noqa: BLE001
            logger.warning("[report-instance] serve %s: the run record was not carried: %s", serve_eid, exc)

        # The standard wire envelope, pointing at the stored artifact.
        #
        # D1/D2 (2026-08-09 adversarial cross-feature review): the
        # truncation facts on the wire are the RUN's — read back from the
        # instance row, NEVER recomputed against the report/default limit
        # the CALLER opened with.  Recomputing resurrected the 122a8c30
        # defect: a run clamped at federation.max_result_rows recorded
        # row_count=100000; every serve then compared 100000 >= 500000 and
        # wired ``truncated: false`` — "definitely complete" — for a
        # definitely-cut result.  Truncation is a CORRECTNESS gate: a row
        # predating the stored facts (all three NULL) is served as UNKNOWN
        # (``truncated: null``), never defaulted to False.
        source_type = str(report.get("data_source_type") or "saved_query")
        from core.reports.contract import materialize_limit, normalize_row_limit
        stored_limit = inst.get("row_limit")
        stored_truncated = inst.get("truncated")
        stored_unstable = inst.get("unstable_truncation")
        env = ReportEnvelope(
            execution_id=serve_eid,
            source_type=source_type,
            total_rows=(int(row_count) if row_count is not None else None),
            # CORR-2: preserve a stored 0 (unlimited) rather than folding it to
            # None (unknown) — the two are different disclosures.
            row_limit=normalize_row_limit(stored_limit),
            artifact_path=str(path),
        )
        if source_type in ("published_view", "federation_view"):
            # These sources return inline data on the live path — mirror it.
            # The caller's row_limit stays the MATERIALISATION bound (how
            # many rows to inline) — it is not a truncation verdict.  CORR-2:
            # an explicit 0 (unlimited) resolves to None (read all), not a fold.
            env.materialize(materialize_limit(row_limit))
        else:
            from core.reports.pagination import read_artifact_page
            _recs, cols, total = read_artifact_page(path, offset=0, limit=1)
            env.columns = cols
            if env.total_rows is None:
                env.total_rows = total
        wire = env.to_wire()
        # The stored verdict wins over the envelope's total>=limit
        # recomputation (the engine can stamp verdicts a simple comparison
        # cannot see, e.g. a merged query whose SIDE was cut); None stays
        # None — UNKNOWN disclosed, never coerced.
        wire["truncated"] = stored_truncated
        if stored_unstable is not None:
            wire["unstable_truncation"] = bool(stored_unstable)

        lc = report.get("layout_config") or {}
        if lc.get("report_type") == "pivot":
            wire["pivot_config"] = lc.get("pivot_config")

        wire.update({
            "served_from_instance": True,
            "instance": {
                "id": inst.get("id"),
                "execution_id": inst.get("execution_id"),
                "created_at": inst.get("created_at"),
                "created_by": inst.get("created_by"),
                "is_scheduled": bool(inst.get("is_scheduled")),
                "status": inst.get("status"),
                "row_count": inst.get("row_count"),
            },
            # Freshness DISCLOSURE (§5.4): as_of always; "verified" only
            # when a source snapshot version was derivable at build time —
            # otherwise UNKNOWN is surfaced, never coerced to "fresh".
            "as_of": inst.get("created_at"),
            "freshness": ("verified" if inst.get("source_version")
                          else "unknown"),
            "stale": bool(stale),
            "refresh_queued": bool(refresh_queued),
        })
        # 2026-09-28 -- sign-off disclosure.  THIS instance's sign-offs, and
        # when it is not the signed one under its key, the signed version it
        # supersedes ("signed version is <id> from <time>; this run is
        # newer").  The signed bytes are served only as their own instance:
        # the `instance` block above names the row whose artifact this is.
        # Unreadable state is disclosed as unknown, never as unsigned.
        from core.reports.signoff import serve_disclosure
        wire["signoff"] = serve_disclosure(db, inst)

        from core.reports.serve_log import log_report_serve
        log_report_serve(
            report_id=report.get("id"), execution_id=serve_eid,
            user=username, rls="instance", surface=surface, fmt="json",
            rows=(len(env.records) if env.records is not None else None),
            total_rows=wire.get("total_rows"),
            row_limit=wire.get("row_limit"),
            truncated=wire.get("truncated"),
            detail=(f"instance={inst.get('id')} "
                    f"artifact_exec={inst.get('execution_id')} "
                    f"stale={bool(stale)}"),
        )
        return wire
    except Exception as exc:
        logger.warning("[report-instance] read-through failed — MISS, "
                       "running live (fail-closed): %s", exc)
        return None


# ── stale-serve background refresh (agg_cache posture) ───────────────────────

_REFRESH_INFLIGHT: set = set()
_REFRESH_LOCK = threading.Lock()


def _trigger_instance_refresh(db, report: Dict[str, Any], user_ctx: Any,
                              param_values: Optional[Dict[str, Any]], *,
                              key: Tuple[Any, ...]) -> bool:
    """Queue a non-blocking live re-execution for a stale instance —
    mirrors ``core/agg_cache.py _trigger_background_refresh`` (daemon
    thread, loud logging, never blocks the serve), with per-serve-key
    dedup so a stampede of stale opens queues ONE refresh.

    The refresh runs through ``execute_headless`` at the CALLER's ctx (the
    scope of the instance being refreshed); its internal write-through
    records the fresh instance.  Source types without a headless executor
    (PV/FV) log the refusal and keep serving stale-with-disclosure.
    Returns True when a refresh was queued.
    """
    with _REFRESH_LOCK:
        if key in _REFRESH_INFLIGHT:
            return False
        _REFRESH_INFLIGHT.add(key)

    rpt = dict(report)
    params = dict(param_values or {})
    ctx = dict(user_ctx or {}) if isinstance(user_ctx, dict) else {}

    def _do_refresh():
        try:
            from core.config import paths as _paths
            from core.reports.sources import execute_headless
            execution_id = "ri-refresh-" + uuid.uuid4().hex[:16]
            out_dir = Path(str(_paths.downloads_dir))
            out_dir.mkdir(parents=True, exist_ok=True)
            execute_headless(rpt, params, execution_id, out_dir, ctx, db)
            logger.info("[report-instance] background refresh completed for "
                        "report %s", rpt.get("id"))
        except Exception as exc:
            logger.warning("[report-instance] background refresh failed for "
                           "report %s: %s", rpt.get("id"), exc)
        finally:
            with _REFRESH_LOCK:
                _REFRESH_INFLIGHT.discard(key)

    try:
        t = threading.Thread(
            target=_do_refresh,
            name=f"report_instance_refresh_{rpt.get('id')}",
            daemon=True,
        )
        t.start()
        logger.info("[report-instance] background refresh queued for report "
                    "%s (stale serve)", rpt.get("id"))
        return True
    except Exception as exc:
        with _REFRESH_LOCK:
            _REFRESH_INFLIGHT.discard(key)
        logger.warning("[report-instance] failed to queue background refresh "
                       "for report %s: %s", rpt.get("id"), exc)
        return False


# ── helpers ──────────────────────────────────────────────────────────────────

def _parse_dt(v: Any) -> Optional[datetime]:
    """Parse a stored timestamp (datetime or isoformat str) to aware UTC."""
    if not v:
        return None
    if isinstance(v, datetime):
        dt = v
    else:
        try:
            dt = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        except ValueError:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt
