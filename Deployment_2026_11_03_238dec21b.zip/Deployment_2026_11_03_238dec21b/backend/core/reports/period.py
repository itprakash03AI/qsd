"""Periods and the COB comparison -- two parameter kinds, pure rules (2026-11-01).

FD-04 / 05 / 06 / 07 / 08 and the owner: "business date should be there".

``period``  -- a parameter whose VALUE is one word: ``daily`` (the business
date itself), ``mtd`` (month to date), ``qtd``, ``ytd``, ``daily_month``
(every day of the business date's month), ``month_ends_12`` (the twelve
month-ends up to the business date), ``year_ends_3`` (the three year-ends).
The anchor is the BUSINESS DATE: the value of the parameter the period
DEPENDS ON (``depends_on_param_id`` -- the same field a cascade uses; a
date / date_range parameter, a range anchors on its ``to``), else today.  The
calendar (rig 2026-11-01, the owner's standing rule -- the business date is
DERIVED from the rule + calendar) is the one the anchor parameter names
(``@PREV_BUSINESS_DAY:LDN`` -> LDN), else the report's own
(``layout_config.calendar``), else the deployment's
``feed_generation.default_calendar``; with none resolvable Monday to Friday
counts and the words SAY so.  A month-end / year-end is its last BUSINESS
day, a range starts on the first business day, "a month of days" is the
month's business days.  The run turns the period into the filter(s) the
engine already takes on the period's column (``lov_column_id``): a range ->
``gte`` / ``lte``, a date SET -> ``in`` -- and the period's date set REPLACES
the anchor's own filter (``anchors_replaced``): the anchor only says "as of".
Refused in words when the anchor is not a date.

``cob_compare`` -- a parameter whose VALUE is ``{"a": date, "b": date}`` (each
side a date or a calendar token; ``"A..B"`` text is accepted); the run binds
``column IN (a, b)`` so the report stays ONE query and ONE stored result, and
the canvas tiles read each side through the cube (core/reports/canvas_compare.py:
A, B, Variance, % Variance; a number tile's delta).

Every function here is pure except the calendar lookups, which go through
``core.business_calendar_tokens`` (the ONE resolver).
"""
from __future__ import annotations

import calendar as _cal
from datetime import date, timedelta
from typing import Any, Dict, List, Optional, Sequence

PERIOD_KINDS = ("daily", "mtd", "qtd", "ytd", "daily_month", "month_ends_12", "year_ends_3")
PERIOD_WORDS = {"daily": "Daily", "mtd": "Month to date", "qtd": "Quarter to date", "ytd": "Year to date",
                "daily_month": "Every day of the month", "month_ends_12": "The last 12 month-ends",
                "year_ends_3": "The last 3 year-ends"}
RANGE_KINDS = ("daily", "mtd", "qtd", "ytd", "daily_month")
SET_KINDS = ("month_ends_12", "year_ends_3")
COMPARE_PRESETS = {
    "month_end_vs_previous": {"a": "@PREV_BUSINESS_MONTH_END", "b": "@BUSINESS_MONTH_END",
                              "words": "This month-end vs the previous month-end"},
    "day_vs_previous_day": {"a": "@PREV_BUSINESS_DAY", "b": "@TODAY", "words": "Today vs the previous business day"},
}


class PeriodRefused(ValueError):
    """A period that cannot be rendered -- said in words (400 at a route)."""


class Weekdays:
    """The fallback when no business calendar is resolvable: Monday to Friday
    (said in the words -- the owner's rule is a calendar, this is the honest
    second-best)."""
    name = "Mon-Fri"

    def is_business_day(self, d: date) -> bool:
        return d.isoweekday() < 6


NO_CALENDAR_WORDS = "no business calendar is set, so Monday to Friday counts as business days"


def _last_dom(d: date) -> date:
    return d.replace(day=_cal.monthrange(d.year, d.month)[1])


def _is_bd(cal, d: date) -> Optional[bool]:
    try:
        return bool(cal.is_business_day(d))
    except Exception:                                        # noqa: BLE001  (horizon: unknown)
        return None


def _roll_back(d: date, cal) -> date:
    """``d`` or the last business day before it (unknown = keep ``d``)."""
    if cal is None:
        return d
    x = d
    for _ in range(40):
        bd = _is_bd(cal, x)
        if bd is None:
            return d
        if bd:
            return x
        x -= timedelta(days=1)
    return d


def _roll_forward(d: date, cal) -> date:
    """``d`` or the first business day after it (unknown = keep ``d``)."""
    if cal is None:
        return d
    x = d
    for _ in range(40):
        bd = _is_bd(cal, x)
        if bd is None:
            return d
        if bd:
            return x
        x += timedelta(days=1)
    return d


def _month_end_rolled(d: date, cal) -> date:
    """The month-end of ``d``'s month; on a calendar, its last business day."""
    return _roll_back(_last_dom(d), cal)


def _business_days(start: date, end: date, cal) -> List[date]:
    out, x = [], start
    while x <= end:
        if cal is None or _is_bd(cal, x) is not False:
            out.append(x)
        x += timedelta(days=1)
    return out


def resolve_period(kind: str, anchor: date, cal: Any = None, calendar_words: Optional[str] = None) -> Dict[str, Any]:
    """``{"from", "to"}`` for a range kind, ``{"dates": [...]}`` for a set kind
    (ISO strings), plus ``words``.  ``cal`` = a BusinessCalendar (or ``Weekdays``)
    -- a range starts on the first business day (never after the anchor), a
    month-end / year-end is its last business day, "a month of days" is the
    month's business days; None = calendar days."""
    k = str(kind or "").strip().lower()
    if k not in PERIOD_KINDS:
        raise PeriodRefused(f"{kind!r} is not a period; the periods are {', '.join(PERIOD_KINDS)}.")
    iso = lambda d: d.isoformat()                            # noqa: E731

    def start(d: date) -> date:
        f = _roll_forward(d, cal)
        return f if f <= anchor else d
    if k == "daily":
        out = {"from": iso(anchor), "to": iso(anchor)}
    elif k == "mtd":
        out = {"from": iso(start(anchor.replace(day=1))), "to": iso(anchor)}
    elif k == "qtd":
        qm = 3 * ((anchor.month - 1) // 3) + 1
        out = {"from": iso(start(anchor.replace(month=qm, day=1))), "to": iso(anchor)}
    elif k == "ytd":
        out = {"from": iso(start(anchor.replace(month=1, day=1))), "to": iso(anchor)}
    elif k == "daily_month":
        if cal is None:
            out = {"from": iso(anchor.replace(day=1)), "to": iso(_last_dom(anchor))}
        else:
            out = {"dates": [iso(d) for d in _business_days(anchor.replace(day=1), _last_dom(anchor), cal)]}
    elif k == "month_ends_12":
        dates: List[date] = []
        y, m = anchor.year, anchor.month
        for _ in range(12):
            dates.append(_month_end_rolled(date(y, m, 1), cal))
            m -= 1
            if m == 0:
                y, m = y - 1, 12
        dates = sorted(d for d in dates if d <= anchor or d.month == anchor.month and d.year == anchor.year)
        out = {"dates": [iso(d) for d in dates]}
    else:   # year_ends_3
        dates = [_month_end_rolled(date(anchor.year - i, 12, 1), cal) for i in range(1, 4)]
        out = {"dates": [iso(d) for d in sorted(dates)]}
    out["kind"] = k
    out["words"] = f"{PERIOD_WORDS[k]} to {iso(anchor)}" + (f" ({calendar_words})" if calendar_words else "")
    return out


def anchor_calendar_name(anchor_param: Optional[Dict[str, Any]], report: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """The calendar a period follows: the anchor's default token's calendar
    (``@PREV_BUSINESS_DAY:LDN`` -> LDN), else the report's own
    (``layout_config.calendar``), else the deployment default (None = none)."""
    from core.business_calendar_tokens import default_calendar_name, parse_calendar_token
    tok = parse_calendar_token((anchor_param or {}).get("default_value")) if anchor_param else None
    if tok is not None and tok.calendar:
        return tok.calendar
    lc = (report or {}).get("layout_config") if isinstance((report or {}).get("layout_config"), dict) else {}
    if lc and str(lc.get("calendar") or "").strip():
        return str(lc["calendar"]).strip()
    try:
        return default_calendar_name() or None
    except Exception:                                        # noqa: BLE001
        return None


def calendar_for(anchor_param: Optional[Dict[str, Any]], report: Optional[Dict[str, Any]], db: Any):
    """``(calendar, words)``: the business calendar a period runs on, or the
    Mon-Fri fallback WITH the words that say so (the band / diagnostics)."""
    name = anchor_calendar_name(anchor_param, report)
    cal = load_calendar(name, db)
    if cal is None:
        return Weekdays(), NO_CALENDAR_WORDS
    return cal, f"on the {name} business calendar"


def anchors_replaced(params: Sequence[Dict[str, Any]], values: Dict[str, Any]) -> set:
    """The names of the anchor (business date) parameters whose dependent
    PERIOD has a value: the period's date set replaces the anchor's own
    filter -- ``date = 2026-10-30 AND date IN (month-ends)`` was always empty
    (rig 2026-11-01).  The anchor only says "as of"."""
    from core.reports.param_contract import run_value
    by_id = {p.get("id"): p for p in params if isinstance(p, dict)}
    out = set()
    for p in params:
        if not isinstance(p, dict) or p.get("parameter_type") != "period" or not p.get("lov_column_id"):
            continue
        anchor = by_id.get(p.get("depends_on_param_id"))
        if not anchor:
            continue
        v = run_value(p, values or {}, params)
        if v not in (None, "", [], {}):
            out.add(str(anchor.get("name")))
    out |= set(compare_widens(params, values))
    return out


def compare_widens(params: Sequence[Dict[str, Any]], values: Dict[str, Any]) -> Dict[str, str]:
    """``{single-date parameter name: comparison parameter name}`` (rig 2026-11-02).

    A two-dates comparison with both dates, on the SAME column as a single business
    DATE with a value: ``date = B`` stored B alone, so every A read nothing.  That date
    steps aside and the run binds the column ``IN (A, B)`` (compare_filters).  A date
    RANGE already holds both dates and the comparison must never narrow it (the trend
    keeps its points, 2026-11-01); with no date on the column nothing is narrowed.

    SECURITY (review 2026-11-02): only a date the viewer can SEE steps aside -- a hidden
    date (or one whose 'show when' is not met) is the author's scope and always filters
    (param_contract.run_value); a viewer's two dates never widen past it."""
    from core.reports.param_contract import run_value, shown
    out: Dict[str, str] = {}
    for p in params:
        if not isinstance(p, dict) or p.get("parameter_type") != "cob_compare" or not p.get("lov_column_id"):
            continue
        if compare_sides(run_value(p, values or {}, params)) is None:
            continue
        for a in params:
            if isinstance(a, dict) and a.get("parameter_type") == "date" and a.get("lov_column_id") == p.get("lov_column_id")                     and not a.get("source_column") and shown(a, values or {}, params)                     and run_value(a, values or {}, params) not in (None, "", [], {}):
                out[str(a.get("name"))] = str(p.get("name"))
    return out


def compare_sides(value: Any) -> Optional[Dict[str, str]]:
    """``{a, b}`` out of a two-dates value (``"A..B"`` or ``{a, b}``); None unless both are there."""
    v = value
    if isinstance(v, str) and ".." in v:
        a, b = v.split("..", 1)
        v = {"a": a.strip(), "b": b.strip()}
    if isinstance(v, dict) and v.get("a") not in (None, "") and v.get("b") not in (None, ""):
        return {"a": str(v["a"]), "b": str(v["b"])}
    return None


def load_calendar(name: Optional[str], db: Any = None):
    """A BusinessCalendar for ``name`` or None (no calendar = calendar days)."""
    if not name:
        return None
    try:
        from core.business_calendar_tokens import _load_calendar
        return _load_calendar(name, db) if db is not None else None
    except Exception:                                        # noqa: BLE001
        return None


def anchor_date(value: Any) -> Optional[date]:
    """The business date out of a resolved parameter value: a date text, or a
    range's ``to`` (else ``from``).  None = not a date."""
    v = value
    if isinstance(v, dict):
        v = v.get("to") or v.get("from")
    if isinstance(v, date):
        return v
    if isinstance(v, str):
        try:
            return date.fromisoformat(v.strip()[:10])
        except ValueError:
            return None
    return None


def period_filters(param: Dict[str, Any], kind_value: Any, anchor_value: Any, anchor_param: Optional[Dict[str, Any]],
                   db: Any = None, report: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """The report filters a period parameter becomes (on its ``lov_column_id``),
    on the business calendar (``calendar_for``)."""
    col = param.get("lov_column_id")
    if not col:
        return []
    anchor = anchor_date(anchor_value) if anchor_value not in (None, "") else date.today()
    if anchor is None:
        raise PeriodRefused(f"The period '{param.get('label') or param.get('name')}' needs a business date: "
                            f"{anchor_value!r} is not a date.")
    cal, cal_words = calendar_for(anchor_param, report, db)
    res = resolve_period(kind_value, anchor, cal, cal_words)
    if "dates" in res:
        return [{"column_id": col, "operator": "in", "value": list(res["dates"])}]
    return [{"column_id": col, "operator": "gte", "value": res["from"]},
            {"column_id": col, "operator": "lte", "value": res["to"]}]


def compare_filters(param: Dict[str, Any], value: Any) -> List[Dict[str, Any]]:
    """A cob_compare parameter: ``column IN (a, b)`` (sides already resolved)."""
    col = param.get("lov_column_id")
    value = compare_sides(value) or value
    if not col or not isinstance(value, dict):
        return []
    sides = [s for s in (value.get("a"), value.get("b")) if s not in (None, "")]
    if len(sides) != 2:
        raise PeriodRefused(f"The comparison '{param.get('label') or param.get('name')}' needs two dates (A and B).")
    return [{"column_id": col, "operator": "in", "value": sides}]


__all__ = ["PERIOD_KINDS", "PERIOD_WORDS", "RANGE_KINDS", "SET_KINDS", "COMPARE_PRESETS", "PeriodRefused", "Weekdays",
           "NO_CALENDAR_WORDS", "resolve_period", "anchor_calendar_name", "calendar_for", "anchors_replaced",
           "load_calendar", "anchor_date", "period_filters", "compare_filters", "compare_sides", "compare_widens"]
