"""The general parameter model -- ONE contract, configured, no development (2026-11-01).

The owner: "think on parameters ... how dynamically we can configure any
parameters without developments".  A parameter is DATA on ``report_parameters``
(or a TEMPLATE in ``report_parameter_templates`` attached by ``template_id``);
this module is the rule every road reads:

* ``KINDS`` -- dropdown, multi_select, date, date_range, text, numeric,
  period, cob_compare, **number_range** (``{from, to}`` numbers),
  **boolean** (true / false), **hierarchy** (one value per level of its
  ``applies`` result columns, top first: ``{"<column id>": value, ...}``).
* ``applies`` -- a list of TARGETS a value is given to; one parameter may
  have several.  ``{to: result, column_id}`` filters the stored result on
  that column (several = the same value on each; by column NAME across the
  datasets of a dashboard through ``core/dashboard_params``); ``{to: source,
  source_column}`` fills a condition of the dataset's own WHERE
  (core/source_filters); ``{to: token, token}`` substitutes ``{TOKEN}`` in a
  raw-SQL report (core/parameters.substitute_sql_params reads the value
  under that name); ``{to: api | popup, action_id}`` names a canvas action
  that takes the parameter (applied by the action road, validated here);
  ``{to: compare}`` / ``{to: period}`` say the kind's own role.  Today's
  ``lov_column_id`` / ``source_column`` stay as the FIRST target.
* ``default_rule`` -- ``value`` (the stored text; a calendar token resolves
  there), ``latest_with_data`` (the newest key of the parameter's own list),
  ``entitlement`` (the viewer's single entitled value of a dimension on the
  column), ``last_picked`` (the viewer's last choice, kept per person).
  ``core/reports/param_defaults.py`` resolves them for a viewer.
* ``visible`` (hidden = ALWAYS runs with its default, never shown, a sent
  value ignored -- so a hidden one must have a default), ``group_label``
  (a heading in the viewer's panel), ``show_when`` (``{param, has_value:
  true}`` or ``{param, equals: [..]}``; it hides the CONTROL -- a parameter
  not shown still runs with its default, ``run_value``),
  ``validation`` (``max_days`` on a range, ``max_picks`` / ``min_picks`` on a
  multi-select, ``required_together: [names]``) -- checked before a run
  (400 in words) and told to the viewer.
* ``parameter_problems`` -- every rule the system cannot honour is REFUSED
  on save in plain words, never dropped.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

KINDS = ("dropdown", "multi_select", "date", "date_range", "text", "numeric", "period", "cob_compare",
         "number_range", "boolean", "hierarchy")
TARGETS = ("result", "source", "token", "api", "popup", "compare", "period")
DEFAULT_RULES = ("value", "latest_with_data", "entitlement", "last_picked")
MAX_GROUP_LABEL = 100
MAX_TOKEN = 100
MAX_TARGETS = 12
MAX_LEVELS = 8
#: the fields a template row may be overridden on by the report's own row
TEMPLATE_OVERRIDABLE = ("label", "sort_order", "is_required", "visible", "default_value", "group_label")
#: the fields a template DEFINES (everything else about a parameter)
TEMPLATE_FIELDS = ("parameter_type", "lov_column_id", "static_values", "values_source", "value_list_id",
                   "lov_source_connection_id", "lov_source_table", "lov_source_column", "source_column",
                   "depends_on_param_id", "cascade_filter_column_id", "default_value", "description", "is_required",
                   "applies", "default_rule", "visible", "group_label", "show_when", "validation", "label")


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def targets_of(param: Dict[str, Any]) -> List[Dict[str, Any]]:
    """The parameter's targets: the stored ``applies`` list, with the first
    one derived from ``lov_column_id`` / ``source_column`` when none is stored."""
    applies = param.get("applies")
    out = [dict(t) for t in applies if isinstance(t, dict)] if isinstance(applies, list) else []
    if not out:
        if param.get("source_column"):
            out.append({"to": "source", "source_column": param["source_column"]})
        elif param.get("lov_column_id"):
            out.append({"to": "result", "column_id": param["lov_column_id"]})
    return out


def result_columns(param: Dict[str, Any]) -> List[int]:
    """Every result column a value is applied to (the hierarchy's levels, top first)."""
    cols = [int(t["column_id"]) for t in targets_of(param) if t.get("to") == "result" and _is_int(t.get("column_id"))]
    if not cols and _is_int(param.get("lov_column_id")):
        cols = [int(param["lov_column_id"])]
    return cols


def token_names(param: Dict[str, Any]) -> List[str]:
    return [str(t["token"]) for t in targets_of(param) if t.get("to") == "token" and t.get("token")]


def parameter_problems(params: Sequence[Dict[str, Any]], *, columns: Optional[Dict[int, Dict[str, Any]]] = None,
                       source_keys: Optional[set] = None, action_ids: Optional[set] = None,
                       tokens: Optional[set] = None, templates: Optional[Dict[int, Dict[str, Any]]] = None) -> List[str]:
    """Every problem of a report's parameter set, in plain words (one 422 lists
    them all).  ``columns`` = the dataset's columns by id (None = not checked),
    ``source_keys`` = the keys of the dataset's WHERE conditions, ``action_ids``
    = the canvas actions, ``tokens`` = the ``{TOKEN}`` names a raw-SQL report
    carries, ``templates`` = the library rows by id."""
    out: List[str] = []
    names = {str(p.get("name")): p for p in params if isinstance(p, dict) and p.get("name")}
    for p in params:
        if not isinstance(p, dict):
            continue
        who = str(p.get("label") or p.get("name") or "a parameter")
        kind = str(p.get("parameter_type") or "dropdown")
        if kind not in KINDS:
            out.append(f"{who}: '{kind}' is not a kind of parameter; the kinds are {', '.join(KINDS)}.")
        # templates
        tid = p.get("template_id")
        if tid is not None:
            if not _is_int(tid):
                out.append(f"{who}: the template must be named by its id.")
            elif templates is not None and tid not in templates:
                out.append(f"{who}: template {tid} does not exist or is switched off.")
        # applies
        applies = p.get("applies")
        if applies is not None:
            if not isinstance(applies, list):
                out.append(f"{who}: 'applies' must be a list of targets.")
                applies = []
            if len(applies) > MAX_TARGETS:
                out.append(f"{who}: at most {MAX_TARGETS} targets.")
            for t in applies:
                if not isinstance(t, dict) or t.get("to") not in TARGETS:
                    out.append(f"{who}: a target must say what it applies to ({', '.join(TARGETS)}).")
                    continue
                to = t["to"]
                if to == "result":
                    cid = t.get("column_id")
                    if not _is_int(cid):
                        out.append(f"{who}: a result target names the column it filters.")
                    elif columns is not None and cid not in columns:
                        out.append(f"{who}: result column #{cid} is not one of the report's columns.")
                    elif columns is not None and kind in ("multi_select", "cob_compare") and kind == "cob_compare" \
                            and "date" not in str(columns[cid].get("data_type") or "").lower():
                        out.append(f"{who}: two dates to compare need a date column; '{columns[cid].get('friendly_name') or columns[cid].get('physical_name')}' is not one.")
                elif to == "source":
                    key = str(t.get("source_column") or "").strip().lower()
                    if not key:
                        out.append(f"{who}: a source target names the condition of the dataset's query it fills.")
                    elif source_keys is not None and key not in source_keys:
                        out.append(f"{who}: the dataset's query has no condition on '{key}'" +
                                   (f" (it has: {', '.join(sorted(source_keys))})." if source_keys else " (it has none)."))
                    elif kind not in ("multi_select", "dropdown", "date", "date_range", "text", "numeric", "boolean"):
                        out.append(f"{who}: a {kind} cannot fill a condition of the query.")
                elif to == "token":
                    tok = str(t.get("token") or "").strip()
                    if not tok or len(tok) > MAX_TOKEN:
                        out.append(f"{who}: a token target names the {{TOKEN}} it fills.")
                    elif tokens is not None and tok not in tokens:
                        out.append(f"{who}: the report's SQL has no {{{tok}}} token" + (f" (it has: {', '.join(sorted(tokens))})." if tokens else "."))
                elif to in ("api", "popup"):
                    aid = str(t.get("action_id") or "")
                    if not aid:
                        out.append(f"{who}: an API / popup target names the action it feeds.")
                    elif action_ids is not None and aid not in action_ids:
                        out.append(f"{who}: there is no action '{aid}' on this report.")
                elif to == "compare" and kind != "cob_compare":
                    out.append(f"{who}: only a 'two dates to compare' parameter drives the comparison.")
                elif to == "period" and kind != "period":
                    out.append(f"{who}: only a period parameter drives the period.")
        if kind == "hierarchy":
            lv = result_columns(p)
            if len(lv) < 2 or len(lv) > MAX_LEVELS:
                out.append(f"{who}: a hierarchy applies to 2 to {MAX_LEVELS} result columns, top level first.")
            elif len(set(lv)) != len(lv):
                out.append(f"{who}: a hierarchy names the same column twice.")
        # default rule
        dr = p.get("default_rule")
        if dr is not None and dr not in DEFAULT_RULES:
            out.append(f"{who}: the default rule is one of {', '.join(DEFAULT_RULES)}.")
        if dr == "latest_with_data" and kind not in ("dropdown", "multi_select", "date", "date_range", "cob_compare"):
            out.append(f"{who}: 'latest with data' needs a dropdown, a multi-select, a date or two dates to compare, bound to a column.")
        if dr == "entitlement" and not result_columns(p):
            out.append(f"{who}: the entitlement default needs a result column (a dimension is bound to it).")
        # visible / group
        if p.get("visible") is not None and not isinstance(p.get("visible"), bool):
            out.append(f"{who}: visible is on or off.")
        elif p.get("visible") is False and p.get("default_value") in (None, ""):
            # SECURITY (review 2026-11-01): a hidden parameter is a SCOPE the author set; with no
            # default it would filter nothing and the report would return more rows than meant
            out.append(f"{who}: a hidden parameter always runs with its default value, so give it one.")
        gl = p.get("group_label")
        if gl is not None and (not isinstance(gl, str) or len(gl) > MAX_GROUP_LABEL):
            out.append(f"{who}: the group heading is text of at most {MAX_GROUP_LABEL} characters.")
        # show_when
        sw = p.get("show_when")
        if sw is not None:
            if not isinstance(sw, dict) or not sw.get("param"):
                out.append(f"{who}: 'show when' names another parameter.")
            else:
                other = names.get(str(sw["param"]))
                if other is None or other is p:
                    out.append(f"{who}: 'show when' names '{sw['param']}', which is not another parameter of this report.")
                elif other.get("visible") is False:
                    # SECURITY (commit review 2026-11-01): a hidden parameter is a fixed scope; letting it
                    # show or hide another would let a sent value for it change what runs
                    out.append(f"{who}: 'show when' names '{sw['param']}', which is hidden -- a hidden parameter "
                               "cannot show or hide another.")
                if "equals" in sw and not isinstance(sw["equals"], list):
                    out.append(f"{who}: 'show when ... equals' is a list of values.")
                if "has_value" in sw and not isinstance(sw["has_value"], bool):
                    out.append(f"{who}: 'show when ... has a value' is on or off.")
        # validation
        v = p.get("validation")
        if v is not None:
            if not isinstance(v, dict):
                out.append(f"{who}: the validation rules must be a set of named rules.")
            else:
                for k in v:
                    if k not in ("max_days", "max_picks", "min_picks", "required_together"):
                        out.append(f"{who}: '{k}' is not a validation rule.")
                if v.get("max_days") is not None and (not _is_int(v["max_days"]) or v["max_days"] < 1 or kind != "date_range"):
                    out.append(f"{who}: 'at most N days' is a whole number on a date range.")
                for k in ("max_picks", "min_picks"):
                    if v.get(k) is not None and (not _is_int(v[k]) or v[k] < 1 or kind != "multi_select"):
                        out.append(f"{who}: '{k.replace('_', ' ')}' is a whole number on a multi-select.")
                if v.get("max_picks") is not None and v.get("min_picks") is not None and _is_int(v["max_picks"]) \
                        and _is_int(v["min_picks"]) and v["min_picks"] > v["max_picks"]:
                    out.append(f"{who}: 'at least N picks' is above 'at most N picks'.")
                rt = v.get("required_together")
                if rt is not None:
                    if not isinstance(rt, list) or not all(isinstance(x, str) and x for x in rt):
                        out.append(f"{who}: 'required together' is a list of parameter names.")
                    else:
                        for x in rt:
                            if x not in names:
                                out.append(f"{who}: 'required together' names '{x}', which is not a parameter of this report.")
    # dependency cycles (show_when and cascades)
    for p in params:
        if not isinstance(p, dict):
            continue
        seen, cur = set(), p
        while cur is not None:
            key = str(cur.get("name"))
            if key in seen:
                out.append(f"{p.get('label') or p.get('name')}: 'show when' goes round in a circle.")
                break
            seen.add(key)
            sw = cur.get("show_when") if isinstance(cur.get("show_when"), dict) else None
            cur = names.get(str(sw.get("param"))) if sw else None
    return out


# ── the viewer's rules at run time ─────────────────────────────────────────

def shown(param: Dict[str, Any], values: Dict[str, Any], params: Sequence[Dict[str, Any]],
          _seen: Optional[set] = None) -> bool:
    """A hidden parameter is never shown; a 'show when' parameter is shown only
    when the other parameter's EFFECTIVE value (``run_value`` -- so a hidden or
    itself-unshown controller counts with its default, never with a value a
    viewer sent for it; SECURITY commit review 2026-11-01) has a value (or one of
    the named values).  A circle of 'show when' is not shown."""
    if param.get("visible") is False:
        return False
    sw = param.get("show_when") if isinstance(param.get("show_when"), dict) else None
    if not sw or not sw.get("param"):
        return True
    seen = set(_seen or ())
    me = str(param.get("name"))
    if me in seen:
        return False                                   # a circle: nothing in it is shown (its defaults run)
    seen.add(me)
    other = next((x for x in params if isinstance(x, dict) and str(x.get("name")) == str(sw["param"])), None)
    if other is None or other is param:
        return False
    v = run_value(other, values, params, _seen=seen)
    empty = v is None or v == "" or (isinstance(v, (list, dict)) and not any(
        x not in (None, "") for x in (v.values() if isinstance(v, dict) else v)))
    if "equals" in sw and isinstance(sw["equals"], list):
        vals = v if isinstance(v, list) else [v]
        return any(str(x) in {str(e) for e in sw["equals"]} for x in vals if x not in (None, ""))
    return not empty


def run_value(param: Dict[str, Any], values: Dict[str, Any], params: Sequence[Dict[str, Any]],
              _seen: Optional[set] = None) -> Any:
    """The value a RUN uses for ``param`` -- ONE rule for every road (app, share,
    embed, export, published view; SECURITY review 2026-11-01).

    * a parameter whose control is NOT shown -- hidden (``visible: false``), or
      its 'show when' not met -- ALWAYS runs with its stored default and a sent
      value is IGNORED: a hidden ``region = EU`` is the author's scope, not a
      suggestion (it used to be skipped before the default was read, so it
      filtered nothing and the report returned MORE rows than meant);
    * a shown parameter runs with the sent value, else its default.
    ``None`` = no value (nothing is applied)."""
    d = param.get("default_value")
    d = None if d in (None, "") else d
    if not shown(param, values or {}, params, _seen=_seen):
        return d
    v = (values or {}).get(str(param.get("name")))
    return d if v is None else v


def validation_problems(param: Dict[str, Any], value: Any, values: Dict[str, Any]) -> List[str]:
    """The rules a VALUE breaks, in plain words (400 before a run)."""
    v = param.get("validation") if isinstance(param.get("validation"), dict) else {}
    who = str(param.get("label") or param.get("name"))
    out: List[str] = []
    if not v:
        return out
    if v.get("max_days") and isinstance(value, dict) and value.get("from") and value.get("to"):
        try:
            from datetime import date
            days = (date.fromisoformat(str(value["to"])[:10]) - date.fromisoformat(str(value["from"])[:10])).days + 1
            if days > int(v["max_days"]):
                out.append(f"{who}: at most {int(v['max_days'])} days may be asked for at once ({days} asked).")
        except ValueError:
            pass
    if isinstance(value, list):
        if v.get("max_picks") and len(value) > int(v["max_picks"]):
            out.append(f"{who}: pick at most {int(v['max_picks'])} values ({len(value)} picked).")
        if v.get("min_picks") and 0 < len(value) < int(v["min_picks"]):
            out.append(f"{who}: pick at least {int(v['min_picks'])} values ({len(value)} picked).")
    rt = v.get("required_together")
    if isinstance(rt, list) and value not in (None, "", [], {}):
        missing = [n for n in rt if values.get(n) in (None, "", [], {})]
        if missing:
            out.append(f"{who}: when it has a value, {', '.join(missing)} must have one too.")
    return out


ADMIN_ROLES = ("admin", "super_admin")


def may_change_template(template: Dict[str, Any], user: Optional[Dict[str, Any]]) -> bool:
    """SECURITY (review 2026-11-01): a template's change flows into every report
    attached to it -- so only its OWNER (``created_by``) or an admin may change
    or switch it off.  Decided over versioning: one owner answers for a shared
    definition; a report that wants to differ detaches (its own row)."""
    if not user:
        return False
    if bool(user.get("is_admin")) or str(user.get("role") or "") in ADMIN_ROLES:
        return True
    return bool(template.get("created_by")) and template.get("created_by") == user.get("username")


async def definition_checks(db, definition: Dict[str, Any], user: Dict[str, Any], *, name: str = "") -> None:
    """The SAME save checks the parameter routes run, on a template's definition
    as the CALLER (and again on the merged parameter when a report attaches it):
    the value table / value list the choices come from must be one the caller
    may see (``_refuse_unreadable_value_tables`` -- connection visibility, the
    identifier rules, the list's existence and source).  Raises HTTPException."""
    from api.business_reports_api import _refuse_unreadable_value_tables
    await _refuse_unreadable_value_tables(db, [{**definition, "name": name or definition.get("name") or "template"}], user)


def apply_template(param: Dict[str, Any], template: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The parameter as SERVED: the template's definition under the row's own
    overrides (label / order / required / visible / default / group)."""
    if not template:
        return param
    d = template.get("definition") if isinstance(template.get("definition"), dict) else {}
    merged = dict(param)
    for k in TEMPLATE_FIELDS:
        if k in d and d[k] is not None and not (k in TEMPLATE_OVERRIDABLE and param.get(k) not in (None, "", 0, False)):
            merged[k] = d[k]
    merged["template_name"] = template.get("name")
    return merged


__all__ = ["KINDS", "TARGETS", "DEFAULT_RULES", "TEMPLATE_FIELDS", "TEMPLATE_OVERRIDABLE", "ADMIN_ROLES", "may_change_template",
           "definition_checks", "targets_of", "result_columns",
           "token_names", "parameter_problems", "shown", "run_value", "validation_problems", "apply_template"]
