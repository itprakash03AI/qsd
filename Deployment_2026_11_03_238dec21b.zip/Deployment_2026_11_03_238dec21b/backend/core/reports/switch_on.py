"""What a report / logical table needs when it is SWITCHED back ON (2026-10-30).

Deleting a report switches it off and keeps its children
(core/db/mixin_datasets.delete_business_report).  "Switch on"
(api/config_active_api.py) brings the row back; these follow-ups, registered
in ``ON_SWITCH_ON``, say in plain words what did NOT come back with it, so
the person switching it on is not left with a report that fails later with
no word of why:

  * its dataset (or the second dataset of a merge) is still switched off;
  * a parameter's value list is still switched off;
  * its old share / embed links stay revoked -- a link is an exposure
    decision, so switching a report on never silently re-opens every public
    URL minted for it; the owner shares it again.

A logical table's resolver cache is dropped, so the name resolves again at
once rather than after the cache's lifetime.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def report_switched_on(row: Dict[str, Any], user: dict) -> Optional[str]:
    from core.database import get_db_manager
    db = get_db_manager()
    if db is None or not row.get("id"):
        return None
    rid = int(row["id"])
    notes: List[str] = []
    for key, label in (("dataset_id", "dataset"), ("merged_dataset_id", "second dataset")):
        ds_id = row.get(key)
        if ds_id and db.get_dataset(int(ds_id)) is None:
            notes.append(f"Its {label} (id {int(ds_id)}) is switched off -- switch that on too, "
                         f"or the report cannot run.")
    for p in db.list_report_parameters(rid):
        vl_id = p.get("value_list_id")
        if vl_id and db.get_value_list(int(vl_id)) is None:
            notes.append(f"The value list behind parameter {p.get('name')!r} (id {int(vl_id)}) is "
                         f"switched off -- switch that on too.")
    from core.db.models import BusinessReportShareToken, ReportEmbedToken
    with db.get_session(read_only=True) as session:
        had_links = (session.query(BusinessReportShareToken.id)
                     .filter(BusinessReportShareToken.report_id == rid).first() is not None
                     or session.query(ReportEmbedToken.id)
                     .filter(ReportEmbedToken.report_id == rid,
                             ReportEmbedToken.report_type == "business").first() is not None)
    if had_links:
        notes.append("Its old share and embed links stay turned off -- share it again if people need a link.")
    return " ".join(notes) or None


def logical_table_switched_on(row: Dict[str, Any], user: dict) -> Optional[str]:
    try:
        from core.logical_table_service import get_service
        get_service().invalidate(logical_name=row.get("logical_name"))
    except Exception:  # noqa: BLE001 -- the cache expires on its own
        logger.debug("logical-table cache invalidation after switch-on failed", exc_info=True)
    return None


def register() -> None:
    """Called by the routers that own these tables (one registration each)."""
    from api.config_active_api import ON_SWITCH_ON
    ON_SWITCH_ON["business_reports"] = report_switched_on
    ON_SWITCH_ON["logical_tables"] = logical_table_switched_on


__all__ = ["report_switched_on", "logical_table_switched_on", "register"]
