"""Default RULES for a report parameter (2026-11-01; core/reports/param_contract.py).

``report_parameters.default_rule``:

* ``value`` (or none) -- the stored ``default_value`` as written; a calendar
  token resolves on the run's road as always;
* ``latest_with_data`` -- the newest key of the parameter's OWN list in
  PostgreSQL (core/reports/param_lists.py): a date list's max, a text list's
  last key in order; nothing when the list is not built yet (said);
* ``entitlement`` -- the viewer's single entitled value of a data-entitlement
  dimension bound (by name) to the parameter's result column; several values
  or none = no default (the viewer picks);
* ``last_picked`` -- the value this viewer ran the report with last time,
  kept per person in ``report_bookmarks`` under the reserved name
  ``LAST_PICK_NAME`` (written by ``remember_picks`` at every run).

``effective_defaults(db, report, params, user)`` is called by the report's
detail GET for the viewer; it answers ``{name: {value, words}}`` and the
served parameter rows carry ``effective_default`` / ``default_words``.  The
server's RUN keeps using the stored default (an API caller gets what the
author wrote); the viewer's controls start from the rule's value.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

LAST_PICK_NAME = "__last__"


def _latest_from_list(db, report: Dict[str, Any], param: Dict[str, Any], user: Optional[Dict[str, Any]],
                      lists: Optional[Dict[str, Dict[str, Any]]]) -> Optional[Dict[str, Any]]:
    """SECURITY (review 2026-11-01): the list is read ONLY when the caller resolved
    it for this viewer (``lists[name]`` = ``param_lists.stored_list_for``: a signed-in
    reader who may see the list's connection; never a token), and its newest key
    is taken under the viewer's own entitlement / row policy (``value_lists.latest_key``
    -- the same rule ``serve`` uses, a DB-side MAX, never the whole list)."""
    from core import value_lists as vlm
    from core.reports import param_lists as pl
    if str(param.get("parameter_type") or "") == "cob_compare":
        return _latest_two_from_sibling(db, report, param, user, lists)
    vl = (lists or {}).get(str(param["name"]))
    if not vl:
        if not pl.find(db, int(report["id"]), str(param["name"])):
            return {"value": None, "words": "No value yet: the parameter's list is not built (save the report, or press Refresh now)."}
        return {"value": None, "words": "No default: this list's source is not one you may read."}
    temporal = str(param.get("parameter_type") or "") in ("date", "date_range")
    latest = vlm.latest_key(db, vl, user or {}, by_order=not temporal)
    if latest in (None, ""):
        return {"value": None, "words": "No value yet: the parameter's list has no value you may choose."}
    value = {"from": latest, "to": latest} if param.get("parameter_type") == "date_range" else (
        [latest] if param.get("parameter_type") == "multi_select" else latest)
    return {"value": value, "words": f"The latest value with data: {latest}."}


def _latest_two_from_sibling(db, report, param, user, lists) -> Dict[str, Any]:
    """A two-date comparison (``cob_compare``) defaults to the two newest dates with
    data: B = the newest, A = the one before (2026-11-02).  It has no list of its own;
    it reads the list of the DATE parameter bound to the same column -- the one the
    caller already resolved for this viewer (``lists``, the security rule above)."""
    from core import value_lists as vlm
    col = param.get("lov_column_id")
    sib = next((n for n, vl in (lists or {}).items() if vl and str(n) != str(param.get("name"))
                and any(isinstance(p, dict) and str(p.get("name")) == str(n) and p.get("lov_column_id") == col
                        for p in (report.get("parameters") or []))), None)
    if sib is None:
        return {"value": None, "words": "No default: no date parameter on the same column has a list to read the two newest dates from."}
    keys = vlm.latest_keys(db, lists[sib], user or {}, 2)
    if len(keys) < 2:
        return {"value": None, "words": "No default: fewer than two dates with data you may choose."}
    return {"value": f"{keys[1]}..{keys[0]}", "words": f"The two newest dates with data: {keys[1]} (A) and {keys[0]} (B)."}


def _entitled_single(db, param: Dict[str, Any], user: Dict[str, Any], columns: Dict[int, Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    from core.reports.param_contract import result_columns
    try:
        from core.row_security import entitlement as ent
        from core.row_security.api import build_user_ctx
        if not ent.enabled():
            return {"value": None, "words": "No default: data entitlement is off."}
        cols = [str((columns.get(c) or {}).get("physical_name") or "").lower() for c in result_columns(param)]
        dims = [d for d in ent.active_dimensions(db)
                if any(str(c["column_name"]).lower() in cols for c in d["columns"])]
        if not dims:
            return {"value": None, "words": "No default: no entitlement dimension is bound to this column."}
        ctx = build_user_ctx(user)
        rows = db.values_for_principals([d["id"] for d in dims], ent.principals_of(ctx, db, ent.scope_of(ctx)))
        vals = sorted({str(r["value"]) for r in rows if r.get("value") is not None and not r.get("is_all")})
        if any(r.get("is_all") for r in rows) or len(vals) != 1:
            return {"value": None, "words": "No default: you are entitled to several values (or all) -- pick one."}
        v = vals[0]
        return {"value": [v] if param.get("parameter_type") == "multi_select" else v, "words": f"Your entitled value: {v}."}
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[param-defaults] entitlement default not read: %s", exc)
        return {"value": None, "words": "No default: your entitlement could not be read."}


def _last_picked(db, report: Dict[str, Any], param: Dict[str, Any], user: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    try:
        rows = db.list_bookmarks(int(report["id"]), str(user.get("username") or ""))
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[param-defaults] last pick not read: %s", exc)
        return {"value": None, "words": "No default: your last choice could not be read."}
    last = next((b for b in rows if b.get("name") == LAST_PICK_NAME), None)
    v = (last or {}).get("param_values", {}).get(str(param["name"])) if last else None
    if v in (None, "", [], {}):
        return {"value": None, "words": "No default yet: run the report once and your choice is remembered."}
    return {"value": v, "words": "The value you picked last time."}


class DefaultUnresolved(ValueError):
    """A 'latest with data' default that could not be worked out for a RUN (2026-11-02).
    The run is REFUSED: run with no value, the parameter filtered nothing and a 'latest
    business date' report read every date (the rig: 740 dates for 2 asked).  A
    ValueError, so a scheduled run records it as its failure; the routes answer 409."""


def effective_defaults(db, report: Dict[str, Any], params: List[Dict[str, Any]], user: Optional[Dict[str, Any]],
                       columns: Optional[Dict[int, Dict[str, Any]]] = None,
                       lists: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Dict[str, Any]]:
    """``{name: {value, words}}`` for every parameter with a rule other than ``value``.
    ``lists`` = the stored lists the CALLER resolved for this viewer by parameter
    name (``param_lists.stored_list_for``); a 'latest with data' parameter whose
    list is not in it gets no value (said)."""
    out: Dict[str, Dict[str, Any]] = {}
    for p in params or []:
        if not isinstance(p, dict):
            continue
        rule = str(p.get("default_rule") or "value")
        try:
            if rule == "latest_with_data":
                r = _latest_from_list(db, {**report, "parameters": params}, p, user, lists)
            elif rule == "entitlement":
                r = _entitled_single(db, p, user or {}, columns or {})
            elif rule == "last_picked":
                r = _last_picked(db, report, p, user or {})
            else:
                continue
        except Exception as exc:                             # noqa: BLE001
            r = {"value": None, "words": f"No default: the rule could not be applied ({type(exc).__name__})."}
        if r:
            out[str(p["name"])] = r
    return out


def remember_picks(db, report_id: int, user: Optional[Dict[str, Any]], param_values: Optional[Dict[str, Any]],
                   params: List[Dict[str, Any]]) -> None:
    """Keep this viewer's choices for the parameters whose rule is
    ``last_picked`` (one row per person and report, replaced each run).
    Best effort: never fails a run."""
    names = [str(p["name"]) for p in params or [] if isinstance(p, dict) and p.get("default_rule") == "last_picked"]
    if not names or not user or not user.get("username"):
        return
    picks = {n: (param_values or {}).get(n) for n in names if (param_values or {}).get(n) not in (None, "", [], {})}
    if not picks:
        return
    try:
        rows = db.list_bookmarks(int(report_id), str(user["username"]))
        for b in rows:
            if b.get("name") == LAST_PICK_NAME:
                db.delete_bookmark(int(b["id"]), str(user["username"]))
        db.save_bookmark(int(report_id), str(user["username"]), LAST_PICK_NAME, picks)
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[param-defaults] last pick not kept: %s", exc)


__all__ = ["LAST_PICK_NAME", "effective_defaults", "remember_picks"]
