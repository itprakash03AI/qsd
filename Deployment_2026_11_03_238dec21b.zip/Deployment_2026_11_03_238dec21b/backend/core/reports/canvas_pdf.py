"""A canvas report's PDF: the same layout as the viewer (2026-10-26).

The owner: "even pdf is not getting same format along with charts n all".
The PDF page holds the canvas as the viewer draws it: the 12 grid columns
over the printable width, grid rows scaled to it, every tile at its
``layout`` {x, y, w, h}.  Tiles are absolutely positioned inside BANDS --
runs of grid rows no tile crosses -- and a band never splits across pages
(``page-break-inside: avoid``), so a chart is never cut in two.  Nothing is
ever scaled to fit: a tile that would cross a page edge moves down to start
the next page, and what lies under it in its columns moves with it
(``_paginate``), so every band fits one page at the viewer's proportions.
The first page keeps room for the report's title and notices.  The report's own rows
(the ``report`` tile) flow as the existing table at the report tile's place
in the row order: the bands above it come first, the table, then the bands
below -- so a report without canvas tiles keeps its byte-identical document.

Charts are inline SVG from ``core.reports.svg_charts`` (pure Python);
number / table / pivot / heatmap tiles are styled HTML; every text is
escaped.  ``canvas_pdf_parts`` returns ``{"above", "below", "css"}`` for
``_render_pdf_bytes``.
"""
from __future__ import annotations

import html
import re
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from core.reports.canvas_export import CHART_KINDS
from core.reports.svg_charts import num, render_chart

#: a grid row's height as a share of a grid column's width (the viewer: 56 px
#: rows over ~90 px columns on a 1,200 px page)
ROW_TO_COL = 0.62
_MM = 72 / 25.4
#: the @page margins of ``_render_pdf_bytes`` (15mm 12mm 18mm 12mm)
_MARGIN_TOP, _MARGIN_SIDE, _MARGIN_BOTTOM = 15 * _MM, 12 * _MM, 18 * _MM
_PAGE_SIZES = {"a4": (595.3, 841.9), "a3": (841.9, 1190.6), "a5": (419.5, 595.3),
               "letter": (612.0, 792.0), "legal": (612.0, 1008.0), "tabloid": (792.0, 1224.0)}
_TITLE_PT, _NOTE_PT, _PAD_PT = 13.0, 9.0, 5.0
_HEAD_PT, _ROW_PT = 13.0, 11.0
_HEAT_LOW, _HEAT_HIGH = (255, 255, 255), (42, 120, 214)     # white -> the palette's first blue
#: the first page's title line and the row-limit notice above the canvas
_FIRST_PAGE_HEAD_PT = 80.0


def page_geometry(page_size: str) -> Tuple[float, float]:
    """(printable width, printable height) in pt for a WeasyPrint @page size."""
    words = str(page_size or "A4 landscape").lower().split()
    w, h = _PAGE_SIZES.get(words[0] if words else "a4", _PAGE_SIZES["a4"])
    if "landscape" in words:
        w, h = h, w
    return w - 2 * _MARGIN_SIDE, h - _MARGIN_TOP - _MARGIN_BOTTOM


def _esc(s: Any) -> str:
    return html.escape("" if s is None else str(s), quote=True)


def _bands(boxes: List[dict]) -> List[Tuple[int, int]]:
    """Maximal runs of grid rows that no tile crosses: (y0, y1) half-open."""
    if not boxes:
        return []
    n = max(b["y"] + b["h"] for b in boxes)
    crossed = [False] * (n + 1)        # crossed[k]: some tile spans rows k-1 and k
    for b in boxes:
        for k in range(b["y"] + 1, b["y"] + b["h"]):
            crossed[k] = True
    out, start = [], 0
    for k in range(1, n + 1):
        if k == n or not crossed[k]:
            out.append((start, k))
            start = k
    return out


def _paginate(boxes: List[dict], page_rows: int, first_rows: int) -> None:
    """Move tiles down (never resize, never reorder) so none crosses a page
    edge.  Page edges sit at ``first_rows``, then every ``page_rows``.  A tile
    keeps its columns; it moves down by the most any tile above it in its
    columns was moved, and below whatever already fills them.  A tile taller
    than a page gets one page.  Rewrites ``y`` / ``h`` in place."""
    page_rows = max(1, page_rows)
    first_rows = max(1, min(first_rows, page_rows))

    def edge_after(row: int) -> int:
        if row < first_rows:
            return first_rows
        return first_rows + ((row - first_rows) // page_rows + 1) * page_rows

    push = [0] * 12
    sky = [0] * 12
    for b in sorted(boxes, key=lambda b: (b["y"], b["x"])):
        cols = range(b["x"], min(12, b["x"] + b["w"]))
        b["h"] = min(b["h"], page_rows)
        y = max(b["y"] + max(push[c] for c in cols), max(sky[c] for c in cols))
        edge = edge_after(y)
        if y + b["h"] > edge:                   # would cross a page edge: start the next page
            y = edge                            # (every page after the first holds page_rows >= h)
        for c in cols:
            push[c] = y - b["y"]
            sky[c] = y + b["h"]
        b["y"] = y


def canvas_pdf_parts(tables: Sequence[dict], report_layout: Optional[dict], *, page_size: str,
                     header_bg: str, header_text: str,
                     fmt_value: Callable[[str, Any, dict], str],
                     look: Optional[dict] = None, pages: Optional[Sequence[dict]] = None) -> Dict[str, str]:
    """The HTML above and below the report's own table, and the CSS.
    ``fmt_value(column, value, col_fmt_map)`` renders a table cell the way
    the report's own cells are rendered (format patterns, bracket negatives).
    ``look`` (theme v2, 2026-11-02; ``themes.card_look``): the page tint behind
    the cards, the card colours and its title's colour / alignment -- None =
    the plain document (every value is six hex digits, checked again here)."""
    from core.reports.canvas_outline import wrap_pdf_formatter
    fmt_value = wrap_pdf_formatter(fmt_value)          # a tile's own number formats (2026-10-30)
    look = dict(look or {})
    pages = [p for p in (pages or []) if isinstance(p, dict)]
    if len(pages) > 1:
        # PAGES (2026-11-02; canvas.export_pages): a PDF page per tab, headed by the tab's title; the
        # pages before the report's page come ABOVE its table, the rest below
        by_id = {str(t.get("tile_id")): t for t in tables}
        above: List[str] = []
        below: List[str] = []
        seen_report = False
        for k, p in enumerate(pages):
            subset = [by_id[i] for i in p.get("tile_ids") or [] if i in by_id]
            has_report = bool(p.get("has_report"))
            if not subset and not has_report:
                continue
            # no backslash inside an f-string expression: Python 3.11 (the image, CI) refuses it
            brk = ' style="page-break-before:always"' if (above or below) else ""
            head = (f'<div class="cv-page-head"{brk}>'
                    f'{_esc(p.get("title") or f"Page {k + 1}")}</div>')
            parts = _page_parts(subset, report_layout if has_report else None, page_size, fmt_value, head_pt=_FIRST_PAGE_HEAD_PT if k == 0 else _PAGE_HEAD_PT)
            if has_report:
                above += [head, parts["above"]]
                below += [parts["below"]]
                seen_report = True
            elif not seen_report:
                above += [head, parts["above"], parts["below"]]
            else:
                below += [head, parts["above"], parts["below"]]
        return {"above": "\n".join(x for x in above if x), "below": "\n".join(x for x in below if x),
                "css": _css(header_bg, header_text, look) + "\n.cv-page-head { font-size: 11pt; font-weight: bold; color: #222; margin: 0 0 4pt 0; }"}
    parts = _page_parts(tables, report_layout, page_size, fmt_value, head_pt=_FIRST_PAGE_HEAD_PT)
    return {"above": parts["above"], "below": parts["below"], "css": _css(header_bg, header_text, look)}


#: a page after the first keeps room for its own heading only
_PAGE_HEAD_PT = 24.0


def _page_parts(tables: Sequence[dict], report_layout: Optional[dict], page_size: str, fmt_value, *, head_pt: float) -> Dict[str, str]:
    """The HTML above and below the report's own table for ONE page of tiles."""
    width, height = page_geometry(page_size)
    col_pt = width / 12.0
    row_pt = col_pt * ROW_TO_COL
    boxes = []
    for t in tables:
        lay = t.get("layout") or {}
        boxes.append({"x": int(lay.get("x", 0)), "y": int(lay.get("y", 0)), "w": max(1, int(lay.get("w", 12))),
                      "h": max(1, int(lay.get("h", 4))), "tile": t})
    report_box = None
    if report_layout:
        report_box = {"x": int(report_layout.get("x", 0)), "y": int(report_layout.get("y", 0)),
                      "w": max(1, int(report_layout.get("w", 12))), "h": max(1, int(report_layout.get("h", 6))), "tile": None}
    # the report's own rows flow as a table at the report tile's place: tiles
    # that start above its bottom edge come before the table, the rest after
    cut = (report_box["y"] + report_box["h"]) if report_box else None
    groups = ([b for b in boxes if b["y"] < cut], [b for b in boxes if b["y"] >= cut]) if report_box else (boxes, [])
    page_rows = max(1, int(height // row_pt))
    first_rows = max(1, int((height - head_pt) // row_pt))
    above: List[str] = []
    below: List[str] = []
    for group, target, first in ((groups[0], above, first_rows), (groups[1], below, page_rows)):
        if not group:
            continue
        top = min(b["y"] for b in group)
        for b in group:
            b["y"] -= top
        _paginate(group, page_rows, first)
        for y0, y1 in _bands(group):
            members = [b for b in group if y0 <= b["y"] < y1]
            if not members:
                continue
            band_rows = max(b["y"] + b["h"] for b in members) - y0
            target.append(f'<div class="cv-band" style="height:{band_rows * row_pt:.1f}pt">')
            for b in sorted(members, key=lambda b: (b["y"], b["x"])):
                target.append(_tile_html(b, y0, col_pt, row_pt, fmt_value))
            target.append("</div>")
    return {"above": "\n".join(above), "below": "\n".join(below)}


def _css(header_bg: str, header_text: str, look: dict) -> str:
    page_bg = _hex6(look.get("page_bg"), "")
    css = f"""
.cv-band {{ position: relative; page-break-inside: avoid; break-inside: avoid; margin: 0;{f" background: #{page_bg};" if page_bg else ""} }}
.cv-tile {{ position: absolute; overflow: hidden; border: 0.75pt solid #{_hex6(look.get("card_border"), "d6d5cf")}; border-radius: 3pt;
           padding: {_PAD_PT:g}pt; box-sizing: border-box; background: #{_hex6(look.get("card_bg"), "fff")}; color: #{_hex6(look.get("card_fg"), "222")}; }}
.cv-title {{ font-size: 9pt; font-weight: bold; color: #{_hex6(look.get("card_title_fg"), "222")}; margin: 0 0 2pt 0; white-space: nowrap; overflow: hidden;
            text-align: {"center" if look.get("card_title_align") == "center" else "left"}; }}
.cv-note {{ font-size: 6.5pt; color: #7A3E00; margin: 0 0 2pt 0; white-space: nowrap; overflow: hidden; }}
.cv-number {{ font-weight: bold; line-height: 1.1; }}
.cv-label {{ font-size: 7.5pt; color: #777; }}
.cv-kpi-change {{ font-size: 7.5pt; font-weight: bold; }}
.cv-spark {{ display: block; margin-top: 2pt; }}
.cv-table {{ border-collapse: collapse; font-size: 7.5pt; table-layout: fixed; }}
.cv-table thead tr {{ background: #{header_bg}; color: #{header_text}; }}
.cv-table th {{ padding: 2pt 3pt; text-align: left; font-weight: bold; white-space: nowrap; overflow: hidden; }}
.cv-table td {{ padding: 1.5pt 3pt; border-bottom: 0.5pt solid #e6e6e6; white-space: nowrap; overflow: hidden; }}
.cv-table td.num {{ text-align: right; }}
.cv-table tbody tr:nth-child(even) {{ background: #f7f8fa; }}
.cv-cut {{ font-size: 6.5pt; color: #898781; margin-top: 2pt; }}
.cv-chart svg {{ display: block; }}
.cv-empty {{ font-size: 7.5pt; color: #898781; }}
.cv-table tr.cv-tot td {{ font-weight: bold; border-top: 0.75pt solid #999; }}"""
    return css


def _hex6(v: Any, default: str) -> str:
    """Six hex digits (no '#') or ``default`` -- SECURITY: the only shape that reaches the CSS."""
    return v if isinstance(v, str) and re.fullmatch(r"[0-9a-fA-F]{6}", v) else default


def _tile_html(b: dict, band_y0: int, col_pt: float, row_pt: float, fmt_value) -> str:
    t = b["tile"]
    left, top = b["x"] * col_pt + 1.5, (b["y"] - band_y0) * row_pt + 1.5
    w, h = b["w"] * col_pt - 3.0, b["h"] * row_pt - 3.0
    note = str(t.get("note") or "")
    inner_w = w - 2 * _PAD_PT
    inner_h = h - 2 * _PAD_PT - _TITLE_PT - (_NOTE_PT if note else 0.0)
    kind = str(t.get("kind") or "")
    kpi_style = _kpi_tile_style(t) if kind == "number" else ""
    title_style = ' style="color:inherit"' if kpi_style else ""    # no backslash in an f-string expression (3.11)
    parts = [f'<div class="cv-tile" style="left:{left:.1f}pt;top:{top:.1f}pt;width:{w:.1f}pt;height:{h:.1f}pt{kpi_style}">',
             f'<div class="cv-title"{title_style}>{_esc(t.get("title"))}</div>']
    if note:
        parts.append(f'<div class="cv-note">{_esc(note)}</div>')
    rows = t.get("rows") or []
    header = [str(x) for x in (t.get("header") or [])]
    if kind == "number":
        parts.append(_number_html(t, header, rows, inner_w, inner_h, fmt_value))
    elif kind in CHART_KINDS:
        if rows:
            parts.append(f'<div class="cv-chart">{render_chart(kind, header, rows, width=max(40.0, inner_w), height=max(30.0, inner_h), split=bool((t.get("labels") or {}).get("series")), labels=str(t.get("labels_mode") or "none"), centre_total=(t.get("centre") == "total"), overlay=bool(t.get("overlay")))}</div>')
        else:
            parts.append(f'<div class="cv-empty">{_esc(note) if note else "No rows."}</div>')
    elif header:
        parts.append(_table_html(t, header, rows, inner_w, inner_h, fmt_value, heat=(kind == "heatmap")))
    else:
        parts.append(f'<div class="cv-empty">{_esc(note) if note else "No fields."}</div>')
    parts.append("</div>")
    return "".join(parts)


def _kpi_tile_style(t: dict) -> str:
    """A filled / gradient KPI card colours its whole tile (``canvas_kpi.kpi_look``); SECURITY: six hex digits only."""
    kpi = t.get("kpi") or {}
    if kpi.get("style") not in ("filled", "gradient") or not kpi.get("fill"):
        return ""
    fill = _hex6(kpi.get("fill"), "1E6FD9")
    fg = _hex6(kpi.get("value_fg"), "FFFFFF")
    if kpi["style"] == "gradient":
        from core.reports.themes import GRADIENT_SHADE, shade
        bg = f"linear-gradient(135deg, #{fill} 0%, {shade('#' + fill, GRADIENT_SHADE)} 100%)"
    else:
        bg = f"#{fill}"
    return f";background:{bg};color:#{fg};border-color:#{fill}"


def _number_html(t: dict, header: List[str], rows: list, inner_w: float, inner_h: float, fmt_value) -> str:
    """The number tile -- since 2026-11-02 a KPI card: the value (under the two-dates
    comparison the row is A, B, Variance, %: the value is B, never the %), the label,
    the change line coloured good / bad, a sparkline polyline."""
    from core.reports.canvas_kpi import change_colour, change_text
    kpi = t.get("kpi") or {}
    filled = kpi.get("style") in ("filled", "gradient") and kpi.get("fill")
    muted = "inherit" if filled else "#898781"
    extra_lines = (1 if kpi.get("change") else 0) + (1 if (t.get("spark") or {}).get("rows") else 0)
    size = max(8.0, min(30.0, (inner_h - extra_lines * 11.0) * 0.55))
    if not rows:
        return f'<div class="cv-number" style="font-size:{size:.0f}pt;color:{muted}">No rows</div>'
    v = kpi.get("value") if kpi else (rows[0][-1] if rows[0] else None)
    fmts = t.get("formats") or [""]
    name = header[0] if header else "v"
    if v is None:
        body = f'<span style="color:{muted}">No value</span>'
    else:
        body = fmt_value(name, _plain(v), {name: fmts[0] or ""})
    label = kpi.get("label") or (((t.get("labels") or {}).get("measures") or [""])[0] if isinstance(t.get("labels"), dict) else "")
    # the value fits the tile's WIDTH too (a bold digit is about 0.6 em wide)
    shown = html.unescape(re.sub(r"<[^>]+>", "", str(body)))
    size = max(6.0, min(size, inner_w / (0.62 * max(1, len(shown)))))
    out = [f'<div class="cv-number" style="font-size:{size:.0f}pt">{body}</div>']
    if label:
        label_style = ' style="color:inherit;opacity:.85"' if filled else ""    # no backslash in an f-string expression (3.11)
        out.append(f'<div class="cv-label"{label_style}>{_esc(label)}</div>')
    if kpi.get("change"):
        words = change_text(kpi, lambda x: _strip(fmt_value(name, _plain(x), {name: fmts[0] or ""})))
        colour = change_colour(kpi)
        style = f' style="color:#{_hex6(colour, "555555")}"' if colour and not filled else (' style="color:inherit"' if filled else "")
        out.append(f'<div class="cv-kpi-change"{style}>{_esc(words)}</div>')
    pts = [(r[0], num(r[1])) for r in (t.get("spark") or {}).get("rows") or [] if len(r) > 1]
    pts = [(c, y) for c, y in pts if y is not None]
    if len(pts) >= 2:
        sw, sh = max(20.0, inner_w - 4), 14.0
        lo, hi = min(y for _, y in pts), max(y for _, y in pts)
        span = (hi - lo) or 1.0
        poly = " ".join(f"{i * sw / (len(pts) - 1):.1f},{sh - (y - lo) / span * (sh - 2) - 1:.1f}" for i, (_, y) in enumerate(pts))
        stroke = "currentColor" if filled else f"#{_hex6(kpi.get('fill'), '1E6FD9')}"
        out.append(f'<svg class="cv-spark" width="{sw:.0f}pt" height="{sh:.0f}pt" viewBox="0 0 {sw:.0f} {sh:.0f}">'
                   f'<polyline class="spark" points="{poly}" fill="none" stroke="{stroke}" stroke-width="1.2"/></svg>')
    return "".join(out)


def _plain(v: Any) -> Any:
    """A Decimal as a float for the report's own cell formatter (it formats
    int / float; everything else is shown as text)."""
    from decimal import Decimal
    return float(v) if isinstance(v, Decimal) else v


#: the table font (7.5 pt): an average character's width, a cell's padding
_CELL_CHAR_PT, _CELL_PAD_PT = 4.3, 7.0


def _table_html(t: dict, header: List[str], rows: list, inner_w: float, inner_h: float, fmt_value,
                *, heat: bool) -> str:
    """Each column is as wide as its widest shown value (a number is never cut
    short); as many columns as fit the tile are shown, the rest are named in
    the note; a heading too long for its column ends in an ellipsis."""
    formats = list(t.get("formats") or []) + [""] * len(header)
    n_fit = max(1, int((inner_h - _HEAD_PT) / _ROW_PT))
    cut_words = []
    if len(rows) > n_fit:
        n_fit = max(1, n_fit - 1)
        cut_words.append(f"Showing {n_fit:,} of {len(rows):,} rows.")
    shown = rows[:n_fit]
    fmt_map = {header[i]: (formats[i] or "") for i in range(len(header))}
    # colour by value (2026-11-02): the scaled columns' ranges, the theme's sign colours
    scales = t.get("scales") if isinstance(t.get("scales"), dict) else {}
    if isinstance(t.get("sign_colours"), dict):
        fmt_map["__sign_colours__"] = t["sign_colours"]
    from core.reports.canvas_outline import mix_hex, scale_fill  # noqa: F401
    cells: List[List[Tuple[str, bool]]] = []
    for r in shown:
        line = []
        for i in range(len(header)):
            v = r[i] if i < len(r) else None
            is_num = (isinstance(v, (int, float)) and not isinstance(v, bool)) or _is_decimal(v)
            line.append((fmt_value(header[i], _plain(v), fmt_map) if is_num else ("" if v is None else str(v)), is_num))
        cells.append(line)

    def need(i: int) -> float:
        longest = max([len(_strip(c[i][0])) for c in cells] or [0])
        return max(longest, min(len(header[i]), 8), 3) * _CELL_CHAR_PT + _CELL_PAD_PT

    cols, used = [], 0.0
    for i in range(len(header)):
        w_i = need(i)
        if cols and used + w_i > inner_w:
            break
        cols.append((i, w_i))
        used += w_i
    if len(cols) < len(header):
        cut_words.append(f"{len(cols)} of {len(header)} columns fit this tile.")
    spare = max(0.0, inner_w - used) / max(1, len(cols))
    lo = hi = None
    if heat and shown:
        vals = [num(r[i]) for r in shown for i, _ in cols[1:] if i < len(r)]
        vals = [v for v in vals if v is not None]
        if vals:
            lo, hi = min(vals), max(vals)
    colgroup = "".join(f'<col style="width:{w_i + spare:.1f}pt">' for _, w_i in cols)
    head = "".join(f'<th title="{_esc(header[i])}">{_esc(_fit(header[i], w_i + spare))}</th>' for i, w_i in cols)
    body = []
    bold = set(t.get("bold_rows") or [])                 # an outline's total rows (2026-10-30)
    for ri, (r, line) in enumerate(zip(shown, cells)):
        tds = []
        for i, w_i in cols:
            text, is_num = line[i]
            style = ""
            n = num(r[i]) if i < len(r) else None
            if heat and i > 0 and n is not None and lo is not None:
                style = f' style="background:{_heat_color(n, lo, hi)}"'
            elif str(i) in scales and n is not None:
                sc = scales[str(i)]
                # ONE colour rule with the browser and the tests (canvas_outline.scale_fill)
                fill = scale_fill(n, {"scale": {"low": "#" + _hex6(sc.get("low"), "FFFFFF"), "high": "#" + _hex6(sc.get("high"), "2A78D6")}},
                                  sc["min"], sc["max"]) or "FFFFFF"
                style = f' class="cv-scale" style="background:#{fill}"'
            cls = ' class="num"' if is_num else ""
            if style.startswith(" class="):
                cls, style = "", style.replace(' class="cv-scale"', ' class="cv-scale num"' if is_num else ' class="cv-scale"', 1)
            tds.append(f"<td{cls}{style}>{text if is_num else _esc(_fit(text, w_i + spare))}</td>")
        body.append(('<tr class="cv-tot">' if ri in bold else "<tr>") + "".join(tds) + "</tr>")
    # the band in its theme's colours (2026-11-01); SECURITY: only six hex digits
    # are ever written into the style attribute, and escaped on the way
    # (the module-level ``_hex6`` -- a local one here shadowed it for the scale colours above: UnboundLocalError)
    head_style = (f' style="background:#{_esc(_hex6(t["header_fill"], "1E6FD9"))};'
                  f'color:#{_esc(_hex6(t.get("header_font_color"), "FFFFFF"))}"'
                  if t.get("header_fill") else "")
    out = [f'<table class="cv-table"><colgroup>{colgroup}</colgroup><thead><tr{head_style}>{head}</tr></thead>'
           f'<tbody>{"".join(body)}</tbody></table>']
    if not rows:
        out.append('<div class="cv-empty">No rows.</div>')
    if cut_words:
        out.append(f'<div class="cv-cut">{_esc(" ".join(cut_words))}</div>')
    return "".join(out)


def _strip(s: str) -> str:
    """The visible text of a formatted cell (the formatter may add markup)."""
    return html.unescape(re.sub(r"<[^>]+>", "", str(s)))


def _fit(text: str, width_pt: float) -> str:
    """A heading or a text cell shortened to its column, ending in an ellipsis."""
    room = max(2, int((width_pt - _CELL_PAD_PT) / _CELL_CHAR_PT))
    return text if len(text) <= room else text[: room - 1] + "…"


def _is_decimal(v: Any) -> bool:
    from decimal import Decimal
    return isinstance(v, Decimal)


def _heat_color(v: float, lo: float, hi: float) -> str:
    f = 0.0 if hi == lo else max(0.0, min(1.0, (v - lo) / (hi - lo)))
    r, g, b = (round(a + (b_ - a) * f) for a, b_ in zip(_HEAT_LOW, _HEAT_HIGH))
    return f"#{r:02x}{g:02x}{b:02x}"
