"""A VIEWER's own layout of a report (2026-11-01; FD-03 / FD-10).

The owner's sheet: "drag-and-drop any approved column", "save and export
customised layouts".  When the report's author allows it
(``layout_config.viewers_may_rearrange``), a person who may only VIEW the
report may move / resize its tiles and pick the fields a table, pivot, chart
or finance grid shows -- from the APPROVED columns (``canvas.drill_columns``)
and the tile's own -- and the layout is kept PER PERSON, reset in one click,
and used by that person's Excel / PDF.

Stored per person in ``report_bookmarks`` under the reserved name
``LAYOUT_NAME`` (the one per-person, per-report store the product has; a
bookmark's ``param_values`` JSON holds the layout).  Shape::

    {"tiles":  {"<tile id>": {"x", "y", "w", "h"}},
     "fields": {"<tile id>": {"dimensions": [column ids], "series": id | null, "levels": [column ids]}}}

``layout_problems`` refuses in plain words what the report does not allow
(a tile that is not there, a field that is not approved, a bad size);
``apply`` overlays a saved layout on the stored canvas -- never written back
to the report.  The author's canvas is the one truth; a viewer's layout is a
view of it.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

LAYOUT_NAME = "__layout__"
SETTING = "viewers_may_rearrange"
MAX_W, MAX_H = 12, 60


def allowed(report: Dict[str, Any]) -> bool:
    lc = report.get("layout_config") if isinstance(report.get("layout_config"), dict) else {}
    return bool(lc.get(SETTING))


def _approved(canvas: Dict[str, Any], tile: Dict[str, Any]) -> set:
    own = set(int(d) for d in (tile.get("dimensions") or []) if isinstance(d, int))
    own |= set(int(x) for x in (tile.get("levels") or []) if isinstance(x, int))
    if isinstance(tile.get("series"), int):
        own.add(int(tile["series"]))
    own |= set(int(d) for d in (canvas.get("drill_columns") or []) if isinstance(d, int) and not isinstance(d, bool))
    return own


def layout_problems(layout: Any, canvas: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    if not isinstance(layout, dict):
        return ["the layout must say where each tile goes and which fields it shows."]
    tiles = {str(t.get("id")): t for t in (canvas.get("tiles") or []) if isinstance(t, dict)}
    for k in layout:
        if k not in ("tiles", "fields"):
            out.append(f'"{k}" is not part of a layout.')
    for tid, pos in (layout.get("tiles") or {}).items():
        if tid not in tiles:
            out.append(f"there is no tile '{tid}' on this report.")
            continue
        if not isinstance(pos, dict):
            out.append(f"tile '{tid}' needs x, y, w and h.")
            continue
        for k, hi in (("x", MAX_W - 1), ("y", 10_000), ("w", MAX_W), ("h", MAX_H)):
            v = pos.get(k)
            if not isinstance(v, int) or isinstance(v, bool) or v < 0 or v > hi:
                out.append(f"tile '{tid}': {k} must be a whole number from 0 to {hi}.")
        if isinstance(pos.get("w"), int) and pos["w"] < 1 or isinstance(pos.get("h"), int) and pos["h"] < 1:
            out.append(f"tile '{tid}' needs a width and a height of at least 1.")
    for tid, f in (layout.get("fields") or {}).items():
        t = tiles.get(tid)
        if t is None:
            out.append(f"there is no tile '{tid}' on this report.")
            continue
        if not isinstance(f, dict):
            out.append(f"tile '{tid}': the fields must name dimensions, series and levels.")
            continue
        ok = _approved(canvas, t)
        for key in ("dimensions", "levels"):
            v = f.get(key)
            if v is None:
                continue
            if not isinstance(v, list) or not all(isinstance(x, int) and not isinstance(x, bool) for x in v):
                out.append(f"tile '{tid}': {key} is a list of column ids.")
                continue
            bad = [x for x in v if x not in ok]
            if bad:
                out.append(f"tile '{tid}': column(s) {', '.join('#' + str(b) for b in bad)} are not approved for viewers on this report.")
            if len(set(v)) != len(v):
                out.append(f"tile '{tid}': the same field twice.")
        s = f.get("series")
        if s is not None and (not isinstance(s, int) or isinstance(s, bool) or s not in ok):
            out.append(f"tile '{tid}': the series column is not approved for viewers on this report.")
    return out


def apply(canvas: Dict[str, Any], layout: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The canvas as THIS viewer sees it (a copy; the report is untouched)."""
    if not layout or not isinstance(layout, dict):
        return canvas
    tiles_pos = layout.get("tiles") or {}
    fields = layout.get("fields") or {}
    out = dict(canvas)
    new_tiles = []
    for t in canvas.get("tiles") or []:
        if not isinstance(t, dict):
            continue
        tid = str(t.get("id"))
        nt = dict(t)
        pos = tiles_pos.get(tid)
        if isinstance(pos, dict):
            nt["layout"] = {**(t.get("layout") or {}), **{k: pos[k] for k in ("x", "y", "w", "h") if k in pos}}
        f = fields.get(tid)
        if isinstance(f, dict):
            if isinstance(f.get("dimensions"), list):
                nt["dimensions"] = list(f["dimensions"])
            if isinstance(f.get("levels"), list):
                nt["levels"] = list(f["levels"])
            if "series" in f:
                nt["series"] = f["series"]
        new_tiles.append(nt)
    out["tiles"] = new_tiles
    return out


def get_layout(db, report_id: int, username: str) -> Optional[Dict[str, Any]]:
    try:
        rows = db.list_bookmarks(int(report_id), str(username))
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[viewer-layout] not read: %s", exc)
        return None
    row = next((b for b in rows if b.get("name") == LAYOUT_NAME), None)
    return (row or {}).get("param_values") if row else None


def save_layout(db, report_id: int, username: str, layout: Dict[str, Any]) -> None:
    rows = db.list_bookmarks(int(report_id), str(username))
    for b in rows:
        if b.get("name") == LAYOUT_NAME:
            db.delete_bookmark(int(b["id"]), str(username))
    db.save_bookmark(int(report_id), str(username), LAYOUT_NAME, layout)


def reset_layout(db, report_id: int, username: str) -> bool:
    rows = db.list_bookmarks(int(report_id), str(username))
    gone = False
    for b in rows:
        if b.get("name") == LAYOUT_NAME:
            db.delete_bookmark(int(b["id"]), str(username))
            gone = True
    return gone


def canvas_for_viewer(db, report: Dict[str, Any], username: Optional[str]) -> Dict[str, Any]:
    """The report's canvas with the viewer's saved layout applied when the
    report allows it; the stored canvas otherwise."""
    lc = report.get("layout_config") if isinstance(report.get("layout_config"), dict) else {}
    canvas = lc.get("canvas") if isinstance(lc.get("canvas"), dict) else None
    if not canvas or not username or not allowed(report):
        return canvas or {}
    lay = get_layout(db, int(report.get("id") or 0), username)
    if not lay or layout_problems(lay, canvas):
        return canvas
    return apply(canvas, lay)


__all__ = ["LAYOUT_NAME", "SETTING", "allowed", "layout_problems", "apply", "get_layout", "save_layout",
           "reset_layout", "canvas_for_viewer"]
