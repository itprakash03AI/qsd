"""A canvas report's Excel: the canvas laid out on ONE sheet (2026-10-26).

The owner: "canvas report is not coming with full format in excel ... should
come like report in excel ... not in multi tab".  So the workbook opens on
one visible sheet named after the report, and the tiles sit on it exactly
where the viewer's 12-column grid places them: a grid column is
``COLS_PER_GRID`` Excel columns, a grid row (56 px on screen) is
``ROWS_PER_GRID`` Excel rows, so relative positions and sizes are kept.  A
tile whose rows need more height than its grid rows give STRETCHES its last
grid row (everything below moves down together; nothing overlaps and
nothing is cut).

Each tile is a bordered block with its title row:

* NUMBER -- the value, big and bold, in the measure's number format, with
  its label under it.
* TABLE / PIVOT / HEATMAP (and the report's own rows) -- a formatted table:
  the report's header colours, each column's number format, stripes; a
  heatmap's cells colour-scaled (openpyxl ColorScaleRule).  A table wider
  than its block or longer than ``MAX_BLOCK_ROWS`` says so in its block and
  goes whole onto its own visible sheet named after the tile (the report's
  rows: the sheet "Rows", written by the caller through the streamed writer).
* CHARTS -- NATIVE Excel charts anchored at the tile's cells: bar / hbar /
  stacked bar / line / area / stacked area / combo (bars + lines) / pie /
  donut / scatter / bubble / radar.  Treemap, funnel and waterfall have no
  native openpyxl chart: they are a formatted table plus a bar chart
  (waterfall: stacked bars over an invisible base series), and the tile's
  note says so.  Chart source data lives on ONE hidden sheet "_chart_data".

The workbook is openpyxl's write-only kind, the same the streamed rows use,
so the sheet is built as a grid in memory (bounded by the tile cell budget)
and emitted row by row.  Every text cell goes through the formula guard.
"""
from __future__ import annotations

import re

from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from core.reports.canvas_export import CHART_KINDS, POINT_KINDS, _cell, sheet_names
from core.reports.svg_charts import PALETTE, OTHER_COLOR, waterfall_steps

#: Excel columns per grid column (the viewer's grid has 12)
COLS_PER_GRID = 2
#: Excel rows per grid row (a grid row is 56 px; a default Excel row ~20 px)
ROWS_PER_GRID = 3
#: width of every grid column's Excel columns (characters)
COL_WIDTH = 11
#: the first grid row's Excel row (row 1 = the report name, row 2 blank)
GRID_TOP = 3
#: a table tile's rows written INSIDE its block; past it the tile says so and
#: goes whole onto its own sheet (the report's rows: the sheet "Rows")
MAX_BLOCK_ROWS = 5_000
#: rows a spilled tile still shows in its block, so the page reads at a glance
PREVIEW_ROWS = 20
DATA_SHEET = "_chart_data"
_COL_CM = 2.17          # an 11-character Excel column, in cm
_ROW_CM = 0.53          # a default-height Excel row, in cm
_TITLE_FILL = "F3F4F6"
_STRIPE_FILL = "F9F9F9"
_BORDER = "BFBFBF"
_HEAT_LOW, _HEAT_HIGH = "FFFFFF", "2A78D6"
#: kinds Excel cannot be given as a native chart from here: the tile says what it shows instead
_NO_NATIVE_CHART = {
    "treemap": "Excel cannot be given a treemap from here: shown as a table and a bar chart, largest first.",
    "funnel": "Excel cannot be given a funnel from here: shown as a table and a bar chart, first stage on top.",
    "waterfall": "Shown as a table and a waterfall built from stacked bars (an invisible base, up in green, down in red, the total in grey).",
}


def _hex(c: str) -> str:
    return c.lstrip("#").upper()


def _hex6(v: Any, default: str) -> str:
    """Six hex digits or ``default`` -- SECURITY: the only shape that becomes a fill / font colour."""
    import re as _re
    return v if isinstance(v, str) and _re.fullmatch(r"[0-9a-fA-F]{6}", v) else default


class _Grid:
    """The canvas sheet, built in memory: cells by (row, column), merges,
    row heights, conditional formats and chart anchors; emitted once."""

    def __init__(self, ws, safe: Callable[[Any], Any]):
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        self.ws = ws
        self.safe = safe
        self.cells: Dict[int, Dict[int, Any]] = {}
        self.merges: List[Tuple[int, int, int, int]] = []
        self.heights: Dict[int, float] = {}
        self.conds: List[Tuple[str, Any]] = []
        self.charts: List[Tuple[Any, str]] = []
        self.max_col = 1
        self._fill_cls, self._border_cls = PatternFill, Border
        self._side = Side(style="thin", color=_BORDER)
        self._fills: Dict[str, Any] = {}

    def fill(self, color: str):
        key = _hex(color)
        if key not in self._fills:
            self._fills[key] = self._fill_cls(start_color=key, end_color=key, fill_type="solid")
        return self._fills[key]

    def put(self, r: int, c: int, value: Any = None, *, font=None, fill=None, number_format: str = "",
            align=None, border=None) -> Any:
        from openpyxl.cell import WriteOnlyCell
        cell = WriteOnlyCell(self.ws, value=self.safe(value) if value is not None else None)
        if font is not None:
            cell.font = font
        if fill is not None:
            cell.fill = fill
        if number_format and _is_number(value):
            cell.number_format = number_format
        if align is not None:
            cell.alignment = align
        if border is not None:
            cell.border = border
        self.cells.setdefault(r, {})[c] = cell
        self.max_col = max(self.max_col, c)
        return cell

    def box(self, r0: int, c0: int, r1: int, c1: int) -> None:
        """A thin border around a block, on whatever cells sit on its edge."""
        for r in range(r0, r1 + 1):
            for c in (c0, c1):
                self._edge(r, c, r0, c0, r1, c1)
        for c in range(c0, c1 + 1):
            for r in (r0, r1):
                self._edge(r, c, r0, c0, r1, c1)

    def _edge(self, r: int, c: int, r0: int, c0: int, r1: int, c1: int) -> None:
        cell = self.cells.get(r, {}).get(c)
        if cell is None:
            cell = self.put(r, c)
        cell.border = self._border_cls(left=self._side if c == c0 else None, right=self._side if c == c1 else None,
                                   top=self._side if r == r0 else None, bottom=self._side if r == r1 else None)

    def merge(self, r0: int, c0: int, r1: int, c1: int) -> None:
        if r1 > r0 or c1 > c0:
            self.merges.append((r0, c0, r1, c1))

    def flush(self) -> int:
        from openpyxl.utils import get_column_letter
        max_row = max(self.cells) if self.cells else 1
        for r, h in self.heights.items():
            self.ws.row_dimensions[r].height = h
        for r in range(1, max_row + 1):
            row = self.cells.get(r, {})
            self.ws.append([row.get(c) for c in range(1, self.max_col + 1)])
        for r0, c0, r1, c1 in self.merges:
            self.ws.merged_cells.add(f"{get_column_letter(c0)}{r0}:{get_column_letter(c1)}{r1}")
        for rng, rule in self.conds:
            self.ws.conditional_formatting.add(rng, rule)
        for chart, anchor in self.charts:
            self.ws.add_chart(chart, anchor)
        return max_row


def _is_number(v: Any) -> bool:
    from decimal import Decimal
    return isinstance(v, (int, float, Decimal)) and not isinstance(v, bool)


def _rows_needed(kind: str, n_rows: int, has_note: bool, n_cols_fit: bool) -> Optional[int]:
    """Excel rows a tile's content wants (None = the block's own height is
    enough: a chart fills whatever it is given)."""
    if kind == "number" or (kind in CHART_KINDS and kind not in ("treemap", "funnel", "waterfall")):
        return None
    shown = n_rows if (n_rows <= MAX_BLOCK_ROWS and n_cols_fit) else min(n_rows, PREVIEW_ROWS)
    return 1 + (1 if has_note else 0) + 1 + shown + 1


def write_canvas_workbook(wb, *, sheet_title: str, report_name: str, tiles: Sequence[dict],
                          report_block: Optional[dict], style: dict,
                          resolve_fmt: Callable[[str], str], safe: Callable[[Any], Any] = _cell,
                          footer_lines: Sequence[Tuple[str, str]] = (),
                          look: Optional[dict] = None,
                          pages: Optional[Sequence[dict]] = None) -> Dict[str, Any]:
    """Write the canvas sheet (first), the hidden chart-data sheet and any
    spill sheet into ``wb`` (a write-only workbook).  ``report_block``:
    ``{"layout", "columns", "rows", "formats", "note", "in_block"}`` or None
    when the canvas has no report tile.  ``footer_lines`` are ``(kind, text)``
    pairs written under the grid (kind "disclosure" | "footer" | "note").
    ``look`` (theme v2, 2026-11-02; ``themes.card_look``): the card's title
    colour / fill and the KPI card colours -- None = the plain document.
    ``pages`` (2026-11-02; ``canvas.export_pages``): ``[{title, tile_ids, has_report}]`` --
    ONE SHEET PER PAGE (the first named after the report, the rest after their page;
    the report's own rows on the page that holds the report tile); None / one page =
    the one sheet as before.
    Returns ``{"sheet": name, "sheets": [names], "spilled": [names], "charts": n}``."""
    look = dict(look or {})
    # the FIRST canvas sheet comes first in the workbook (the one a reader opens on), then the hidden chart data
    first_ws = wb.create_sheet(title=sheet_title)
    data_ws = wb.create_sheet(title=DATA_SHEET)
    data_ws.sheet_state = "hidden"
    data = _DataSheet(data_ws, safe)
    pages = [p for p in (pages or []) if isinstance(p, dict)]
    if len(pages) <= 1:
        r = _canvas_sheet(wb, data, first_ws, report_name, tiles, report_block, style, resolve_fmt, safe, footer_lines, look,
                          taken=[sheet_title, DATA_SHEET, "Rows", "Export Info"])
        return {"sheet": sheet_title, "sheets": [sheet_title], **r}
    by_id = {str(t.get("tile_id")): t for t in tiles}
    taken = [sheet_title, DATA_SHEET, "Rows", "Export Info"]
    names = [sheet_title] + sheet_names([p.get("title") or f"Page {k + 2}" for k, p in enumerate(pages[1:])], taken)
    taken += names[1:]
    spilled: List[str] = []
    n_charts = 0
    for k, p in enumerate(pages):
        page_tiles = [by_id[i] for i in p.get("tile_ids") or [] if i in by_id]
        rb = report_block if p.get("has_report") else None
        if not page_tiles and rb is None:
            continue
        title = report_name if k == 0 else f"{report_name} -- {p.get('title') or names[k]}"
        ws = first_ws if k == 0 else wb.create_sheet(title=names[k])
        r = _canvas_sheet(wb, data, ws, title, page_tiles, rb, style, resolve_fmt, safe,
                          footer_lines if k == 0 else (), look, taken=taken)
        spilled += r["spilled"]
        n_charts += r["charts"]
    return {"sheet": sheet_title, "sheets": names, "spilled": spilled, "charts": n_charts}


def _canvas_sheet(wb, data, ws, report_name: str, tiles: Sequence[dict], report_block: Optional[dict],
                  style: dict, resolve_fmt, safe, footer_lines, look: dict, *, taken: List[str]) -> Dict[str, Any]:
    """ONE canvas sheet (a page) on the given ``ws``: the grid of blocks, the charts over the shared data sheet."""
    from openpyxl.styles import Alignment, Font
    from openpyxl.utils import get_column_letter
    from core.reports.canvas_outline import wrap_excel_resolver
    resolve_fmt = wrap_excel_resolver(resolve_fmt)      # a tile's own number formats (2026-10-30)

    ws.sheet_view.showGridLines = False
    ncols = 12 * COLS_PER_GRID
    for c in range(1, ncols + 1):
        ws.column_dimensions[get_column_letter(c)].width = COL_WIDTH
    g = _Grid(ws, safe)
    header_font = Font(bold=True, color=_hex(style.get("header_text") or "FFFFFF"), size=10)
    header_fill = g.fill(style.get("header_bg") or "1976D2")
    stripe = bool(style.get("stripe_rows", True))

    # ── the grid: every block's rows, stretched where a table needs more ──
    blocks: List[dict] = []
    for t in tiles:
        lay = t.get("layout") or {}
        n_fit = len(t.get("header") or []) <= int(lay.get("w", 12)) * COLS_PER_GRID
        blocks.append({"tile": t, "lay": lay, "kind": str(t.get("kind") or ""),
                       "need": _rows_needed(str(t.get("kind") or ""), len(t.get("rows") or []), bool(t.get("note")), n_fit)})
    if report_block is not None:
        lay = report_block["layout"]
        n_rows = len(report_block.get("rows") or []) if report_block.get("in_block") else 0
        blocks.append({"tile": None, "lay": lay, "kind": "report",
                       "need": 1 + (1 if report_block.get("note") else 0) + 1 + n_rows + 1})
    n_grid_rows = max([b["lay"]["y"] + b["lay"]["h"] for b in blocks] + [1])
    rh = [ROWS_PER_GRID] * n_grid_rows
    for b in sorted(blocks, key=lambda b: (b["lay"]["y"], b["lay"]["x"])):
        y, h = b["lay"]["y"], b["lay"]["h"]
        if b["need"] is not None:
            deficit = b["need"] - sum(rh[y:y + h])
            if deficit > 0:
                rh[y + h - 1] += deficit
    top = [GRID_TOP]
    for v in rh:
        top.append(top[-1] + v)

    g.put(1, 1, report_name, font=Font(bold=True, size=14))
    g.heights[1] = 22
    spilled: List[str] = []
    n_charts = 0
    for b in sorted(blocks, key=lambda b: (b["lay"]["y"], b["lay"]["x"])):
        lay = b["lay"]
        c0 = 1 + lay["x"] * COLS_PER_GRID
        c1 = c0 + lay["w"] * COLS_PER_GRID - 1
        r0 = top[lay["y"]]
        r1 = top[lay["y"] + lay["h"]] - 1
        if b["kind"] == "report":
            _report_block(g, report_block, r0, c0, c1, header_font, header_fill, stripe, resolve_fmt)
            continue
        t = b["tile"]
        kind = b["kind"]
        note = str(t.get("note") or "")
        if kind in _NO_NATIVE_CHART and t.get("rows"):
            note = (note + " " if note else "") + _NO_NATIVE_CHART[kind]
        rc = _block_head(g, str(t.get("title") or ""), note, r0, c0, c1, look=look)
        if kind == "number":
            n_charts += _number_block(g, t, rc, c0, c1, resolve_fmt, data=data, r1=r1)
        elif kind in CHART_KINDS and kind not in ("treemap", "funnel", "waterfall"):
            if t.get("rows"):
                chart = _native_chart(kind, t, data, resolve_fmt)
                chart.width = max(4.0, (c1 - c0 + 1) * _COL_CM - 0.25)
                chart.height = max(2.5, (r1 - rc + 1) * _ROW_CM - 0.15)
                g.charts.append((chart, f"{get_column_letter(c0)}{rc}"))
                n_charts += 1
            else:
                g.put(rc, c0, note or "No rows.", font=Font(color="898781", size=9))
        else:
            spill = _table_block(g, t, rc, c0, c1, header_font, header_fill, stripe, resolve_fmt,
                                 heat=(kind == "heatmap"), taken=taken)
            if spill:
                spilled.append(spill)
            if kind in ("treemap", "funnel", "waterfall") and t.get("rows"):
                n_tab = len(t.get("header") or [])
                chart = _native_chart(kind, t, data, resolve_fmt)
                if c1 - (c0 + n_tab) + 1 >= 3:
                    chart.width = max(4.0, (c1 - (c0 + n_tab) + 1) * _COL_CM - 0.25)
                    chart.height = max(2.5, (r1 - rc + 1) * _ROW_CM - 0.15)
                    g.charts.append((chart, f"{get_column_letter(c0 + n_tab)}{rc}"))
                else:
                    chart.width = max(4.0, (c1 - c0 + 1) * _COL_CM - 0.25)
                    chart.height = 6.0
                    g.charts.append((chart, f"{get_column_letter(c0)}{r1 + 1}"))
                n_charts += 1
        g.box(r0, c0, r1, c1)
    # lines under the grid: the disclosure, the certificate footer, notes
    r = top[-1] + 1
    for kind, text in footer_lines:
        if not text:
            continue
        font = (Font(bold=True, color="B45309", size=9) if kind == "disclosure"
                else Font(italic=True, color="777777", size=9) if kind == "footer"
                else Font(color="7A3E00", size=9))
        g.put(r, 1, text, font=font)
        r += 1
    g.flush()
    return {"spilled": spilled, "charts": n_charts}


def _block_head(g: _Grid, title: str, note: str, r0: int, c0: int, c1: int, look: Optional[dict] = None) -> int:
    from openpyxl.styles import Alignment, Font
    look = look or {}
    # theme v2: the card's title colour and fill (a hex without '#', already checked by themes.card_look)
    fill = g.fill(_hex6(look.get("card_bg"), _TITLE_FILL))
    g.put(r0, c0, title or "Tile", font=Font(bold=True, size=11, color=_hex6(look.get("card_title_fg"), "000000")), fill=fill,
          align=Alignment(vertical="center", horizontal="center" if look.get("card_title_align") == "center" else "left"))
    for c in range(c0 + 1, c1 + 1):
        g.put(r0, c, fill=fill)
    g.merge(r0, c0, r0, c1)
    rc = r0 + 1
    if note:
        g.put(rc, c0, note, font=Font(italic=True, color="7A3E00", size=8),
              align=Alignment(wrap_text=False, vertical="top"))
        g.merge(rc, c0, rc, c1)
        rc += 1
    return rc


def _number_block(g: _Grid, t: dict, rc: int, c0: int, c1: int, resolve_fmt, *, data=None, r1: Optional[int] = None) -> int:
    """The number tile -- since 2026-11-02 a KPI CARD (``core.reports.canvas_kpi``):
    the value in the card's colours (a filled / gradient card fills its rows with
    the fill and writes in the value colour), the label, the change line coloured
    good / bad, and a small line chart of the sparkline when the block has room.
    Returns how many charts it added."""
    from openpyxl.styles import Alignment, Font
    from openpyxl.utils import get_column_letter
    from core.reports.canvas_kpi import change_colour, change_text
    rows = t.get("rows") or []
    kpi = t.get("kpi") or {}
    # the value: the card's own (under the two-dates comparison the row is A, B, Variance, % -- the value is B)
    v = kpi.get("value") if kpi else (rows[0][-1] if rows and rows[0] else None)
    fmt = resolve_fmt((t.get("formats") or [""])[0]) if t.get("formats") else ""
    filled = kpi.get("style") in ("filled", "gradient") and kpi.get("fill")
    fill = g.fill(_hex6(kpi.get("fill"), "1E6FD9")) if filled else None
    value_fg = _hex6(kpi.get("value_fg"), "FFFFFF") if filled else None
    label_fg = _hex6(kpi.get("label_fg"), "FFFFFF") if filled else "777777"
    last = rc + 2
    if filled:
        for r in range(rc, last + 1):
            for c in range(c0, c1 + 1):
                g.put(r, c, fill=fill)
    if not rows:
        g.put(rc, c0, "No rows", font=Font(bold=True, size=16, color=value_fg or "898781"), fill=fill)
    elif v is None:
        g.put(rc, c0, "No value", font=Font(bold=True, size=16, color=value_fg or "898781"), fill=fill)
    else:
        g.put(rc, c0, v, font=Font(bold=True, size=20, color=value_fg), number_format=fmt or "#,##0.00",
              align=Alignment(horizontal="left", vertical="center"), fill=fill)
    g.merge(rc, c0, rc, c1)
    g.heights[rc] = 30
    labels = t.get("labels") or {}
    label = kpi.get("label") or ((labels.get("measures") or [""])[0] if isinstance(labels, dict) else "")
    if label:
        g.put(rc + 1, c0, label, font=Font(color=label_fg, size=9), fill=fill)
        g.merge(rc + 1, c0, rc + 1, c1)
    n_charts = 0
    if kpi:
        words = change_text(kpi, lambda x: f"{x:,.2f}" if isinstance(x, (int, float)) or hasattr(x, "quantize") else str(x))
        if words:
            # a filled card writes in its value colour (the fill carries no good / bad meaning); a plain one is coloured by the change
            colour = value_fg if filled else (change_colour(kpi) or "555555")
            g.put(rc + 2, c0, words, font=Font(color=colour, size=10, bold=True), fill=fill)
            g.merge(rc + 2, c0, rc + 2, c1)
        spark = t.get("spark") or {}
        if data is not None and r1 is not None and len(spark.get("rows") or []) >= 2 and r1 - (rc + 3) >= 2:
            chart = _native_chart("line", {"header": spark["header"], "rows": spark["rows"], "formats": ["", (t.get("formats") or [""])[0]]},
                                  data, resolve_fmt)
            chart.legend = None
            chart.width = max(4.0, (c1 - c0 + 1) * _COL_CM - 0.25)
            chart.height = max(2.0, (r1 - (rc + 3) + 1) * _ROW_CM - 0.15)
            g.charts.append((chart, f"{get_column_letter(c0)}{rc + 3}"))
            n_charts = 1
    return n_charts


def _table_block(g: _Grid, t: dict, rc: int, c0: int, c1: int, header_font, header_fill, stripe: bool,
                 resolve_fmt, *, heat: bool, taken: List[str]) -> Optional[str]:
    """A formatted table inside its block; a table too wide or too long for
    the block spills whole onto its own sheet and the block says so.
    Returns the spill sheet's name when one was written."""
    from openpyxl.formatting.rule import ColorScaleRule
    from openpyxl.styles import Alignment, Font
    from openpyxl.utils import get_column_letter
    from core.reports.canvas_outline import decode_format, rule_fill, sign_colour
    header = [str(h) for h in (t.get("header") or [])]
    rows = t.get("rows") or []
    formats = [resolve_fmt(f or "") for f in (t.get("formats") or [])] + [""] * len(header)
    # colour by value (2026-11-02): the scaled columns (a ColorScaleRule each) and the sign colours
    scales = t.get("scales") if isinstance(t.get("scales"), dict) else {}
    signs = t.get("sign_colours") if isinstance(t.get("sign_colours"), dict) else {}
    # a tile format's colour rules (2026-10-30): the cell's background
    tile_fmts = [decode_format(f) for f in (t.get("formats") or [])] + [None] * len(header)
    width = c1 - c0 + 1
    fits = len(header) <= width and len(rows) <= MAX_BLOCK_ROWS
    spill_name = None
    shown = rows
    if not fits:
        spill_name = sheet_names([t.get("title") or "Tile"], taken)[0]
        taken.append(spill_name)
        why = (f"{len(rows):,} rows" if len(rows) > MAX_BLOCK_ROWS else f"{len(header):,} columns")
        g.put(rc, c0, f"{why} -- see the sheet '{spill_name}'. The first {min(PREVIEW_ROWS, len(rows))} rows:",
              font=Font(italic=True, color="7A3E00", size=8))
        g.merge(rc, c0, rc, c1)
        rc += 1
        shown = rows[:PREVIEW_ROWS]
        _spill_sheet(g.ws.parent, spill_name, t, header, rows, formats, header_font, header_fill, g.safe,
                     tile_fmts=tile_fmts, fill=g.fill)
    n_cols = min(len(header), width)
    if t.get("header_fill"):      # the band tile prints in its theme's colours (2026-11-01)
        # SECURITY: openpyxl takes a colour string as given -- only six hex digits pass (the module-level
        # ``_hex6``; a local lambda here shadowed it for the sign / scale colours above: UnboundLocalError)
        header_fill = g.fill(_hex6(t["header_fill"], "1E6FD9"))
        header_font = Font(bold=True, color=_hex6(t.get("header_font_color"), "FFFFFF"))
    for i in range(n_cols):
        g.put(rc, c0 + i, header[i], font=header_font, fill=header_fill, align=Alignment(horizontal="left"))
    if not header:
        g.put(rc, c0, "No fields.", font=Font(color="898781", size=9))
    if not rows:
        g.put(rc + 1, c0, "No rows.", font=Font(color="898781", size=9))
    stripe_fill = g.fill(_STRIPE_FILL)
    bold = set(t.get("bold_rows") or [])                 # an outline's total rows (2026-10-30)
    for ri, row in enumerate(shown):
        r = rc + 1 + ri
        for i in range(n_cols):
            v = row[i] if i < len(row) else None
            ruled = rule_fill(v, tile_fmts[i]) if tile_fmts[i] else None
            sc = sign_colour(v, tile_fmts[i], signs) if tile_fmts[i] else None
            font = Font(bold=ri in bold, color=_hex6(sc, "000000")) if sc else (Font(bold=True) if ri in bold else None)
            g.put(r, c0 + i, v, number_format=formats[i],
                  fill=(g.fill(ruled) if ruled else stripe_fill if (stripe and ri % 2 == 1) else None),
                  **({"font": font} if font else {}))
    for key, sc in scales.items():
        i = int(key) if str(key).isdigit() else -1
        if 0 <= i < n_cols and shown:
            rng = f"{get_column_letter(c0 + i)}{rc + 1}:{get_column_letter(c0 + i)}{rc + len(shown)}"
            g.conds.append((rng, ColorScaleRule(start_type="min", start_color=_hex6(sc.get("low"), "FFFFFF"),
                                                end_type="max", end_color=_hex6(sc.get("high"), "2A78D6"))))
    if heat and shown and n_cols > 1:
        # a heatmap's first column is its row field; every other cell is a value
        rng = (f"{get_column_letter(c0 + 1)}{rc + 1}:"
               f"{get_column_letter(c0 + n_cols - 1)}{rc + len(shown)}")
        g.conds.append((rng, ColorScaleRule(start_type="min", start_color=_HEAT_LOW, end_type="max", end_color=_HEAT_HIGH)))
    return spill_name


def _report_block(g: _Grid, rb: dict, r0: int, c0: int, c1: int, header_font, header_fill, stripe: bool,
                  resolve_fmt) -> None:
    from openpyxl.styles import Alignment, Font
    note = str(rb.get("note") or "")
    rc = _block_head(g, "Report", note, r0, c0, c1)
    columns = [str(c) for c in rb.get("columns") or []]
    if not rb.get("in_block"):
        return
    width = c1 - c0 + 1
    n_cols = min(len(columns), width)
    fmts = {c: resolve_fmt(str((rb.get("formats") or {}).get(c) or "")) for c in columns}
    for i in range(n_cols):
        g.put(rc, c0 + i, columns[i], font=header_font, fill=header_fill, align=Alignment(horizontal="left"))
    rows = rb.get("rows") or []
    if not rows:
        g.put(rc + 1, c0, "No rows.", font=Font(color="898781", size=9))
    stripe_fill = g.fill(_STRIPE_FILL)
    for ri, row in enumerate(rows):
        r = rc + 1 + ri
        for i in range(n_cols):
            col = columns[i]
            v = row.get(col) if isinstance(row, dict) else (row[i] if i < len(row) else None)
            g.put(r, c0 + i, v, number_format=fmts.get(col, ""), fill=(stripe_fill if (stripe and ri % 2 == 1) else None))


def _spill_sheet(wb, name: str, t: dict, header: List[str], rows: List[Any], formats: List[str],
                 header_font, header_fill, safe, *, tile_fmts: Optional[List[Any]] = None, fill=None) -> None:
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.formatting.rule import ColorScaleRule
    from openpyxl.styles import Font
    from openpyxl.utils import get_column_letter
    from core.reports.canvas_outline import rule_fill, sign_colour
    signs = t.get("sign_colours") if isinstance(t.get("sign_colours"), dict) else {}
    ws = wb.create_sheet(title=name)
    ws.column_dimensions["A"].width = 24
    title = WriteOnlyCell(ws, value=safe(t.get("title") or "Tile"))
    title.font = Font(bold=True, size=11)
    ws.append([title])
    if t.get("note"):
        n = WriteOnlyCell(ws, value=safe(t["note"]))
        n.font = Font(italic=True, color="7A3E00", size=8)
        ws.append([n])
    ws.append([])
    hdr = []
    for h in header:
        c = WriteOnlyCell(ws, value=safe(h))
        c.font = header_font
        c.fill = header_fill
        hdr.append(c)
    ws.append(hdr)
    for row in rows:
        out = []
        for i, v in enumerate(row):
            fmt = formats[i] if i < len(formats) else ""
            tf = tile_fmts[i] if tile_fmts and i < len(tile_fmts) else None
            ruled = rule_fill(v, tf) if tf and fill is not None else None
            sc = sign_colour(v, tf, signs) if tf else None
            if (fmt and _is_number(v)) or ruled or sc:
                c = WriteOnlyCell(ws, value=safe(v))
                if fmt and _is_number(v):
                    c.number_format = fmt
                if ruled:
                    c.fill = fill(ruled)
                if sc:
                    c.font = Font(color=_hex6(sc, "000000"))
                out.append(c)
            else:
                out.append(safe(v))
        ws.append(out)
    first = 5 if t.get("note") else 4                       # title, (note), blank, header, then the rows
    for key, sc in (t.get("scales") or {}).items() if isinstance(t.get("scales"), dict) else []:
        i = int(key) if str(key).isdigit() else -1
        if 0 <= i < len(header) and rows:
            ws.conditional_formatting.add(f"{get_column_letter(1 + i)}{first + 1}:{get_column_letter(1 + i)}{first + len(rows)}",
                                          ColorScaleRule(start_type="min", start_color=_hex6(sc.get("low"), "FFFFFF"),
                                                         end_type="max", end_color=_hex6(sc.get("high"), "2A78D6")))


class _DataSheet:
    """The hidden chart-data sheet: one block per chart, appended as built."""

    def __init__(self, ws, safe):
        self.ws = ws
        self.safe = safe
        self.row = 0

    def block(self, header: Sequence[str], rows: Sequence[Sequence[Any]]) -> Tuple[int, int, int]:
        """Append a header + rows; returns (header_row, first_data_row, last_data_row)."""
        if self.row:
            self.ws.append([])
            self.row += 1
        self.ws.append([self.safe(h) for h in header])
        hdr = self.row + 1
        for r in rows:
            self.ws.append([self.safe(v) if isinstance(v, str) else (None if v is None else v) for v in r])
        self.row += 1 + len(rows)
        return hdr, hdr + 1, hdr + len(rows)


def _native_chart(kind: str, t: dict, data: _DataSheet, resolve_fmt):
    """An openpyxl chart of the tile's kind over a block on the data sheet."""
    from openpyxl.chart import (AreaChart, BarChart, BubbleChart, DoughnutChart, LineChart, PieChart,
                                RadarChart, Reference, ScatterChart, Series)
    from openpyxl.chart.series import DataPoint
    header = [str(h) for h in (t.get("header") or [])]
    rows = [list(r) for r in (t.get("rows") or [])]
    formats = list(t.get("formats") or []) + [""] * len(header)
    n_series = max(1, len(header) - 1)
    # chart options (2026-11-02, canvas_chart_options): labels on the marks, the two-dates overlay
    overlay = bool(t.get("overlay"))
    chart = _native_chart_of(kind, t, data, resolve_fmt, header, rows, formats, n_series, overlay)
    _data_labels(chart, str(t.get("labels_mode") or "none"), kind)
    return chart


def _data_labels(chart, mode: str, kind: str) -> None:
    """Values (or, on a pie / donut, the share) written on the marks."""
    if mode not in ("values", "percent"):
        return
    from openpyxl.chart.label import DataLabelList
    labels = DataLabelList()
    if mode == "percent" and kind in ("pie", "donut"):
        labels.showPercent = True
    else:
        labels.showVal = True
    labels.showSerName = False
    labels.showCatName = False
    labels.showLegendKey = False
    for s in getattr(chart, "series", []) or []:
        s.dLbls = labels
    for sub in getattr(chart, "_charts", []) or []:
        for s in getattr(sub, "series", []) or []:
            s.dLbls = labels


def _native_chart_of(kind, t, data, resolve_fmt, header, rows, formats, n_series, overlay):
    from openpyxl.chart import (AreaChart, BarChart, BubbleChart, DoughnutChart, LineChart, PieChart,
                                RadarChart, Reference, ScatterChart, Series)
    from openpyxl.chart.series import DataPoint
    for r in rows:                      # numbers the chart can read; text stays text
        for i in range(1, len(r)):
            r[i] = _as_number(r[i])
    ws = data.ws
    if kind == "waterfall":
        steps = waterfall_steps(rows)
        header = [header[0], "Base", "Up", "Down"]
        rows = [[s["label"], s["base"], s["size"] if (s["value"] >= 0 or s.get("total")) else 0.0,
                 s["size"] if (s["value"] < 0 and not s.get("total")) else 0.0] for s in steps]
        n_series = 3
    if kind in ("treemap", "funnel"):
        # a horizontal bar chart draws its first category at the BOTTOM: the
        # largest tile / the first funnel stage must come last
        rows = sorted(rows, key=lambda r: (r[1] or 0.0)) if kind == "treemap" else rows[::-1]
        rows = [r[:2] for r in rows]
        header = header[:2]
        n_series = 1
    hdr, first, last = data.block(header, rows)
    cats = Reference(ws, min_col=1, min_row=first, max_row=last)
    vals = Reference(ws, min_col=2, min_row=hdr, max_col=1 + n_series, max_row=last)
    fmt = resolve_fmt(formats[1] or "") if len(formats) > 1 else ""

    if kind in POINT_KINDS:
        chart = BubbleChart() if kind == "bubble" else ScatterChart()
        x = Reference(ws, min_col=2, min_row=first, max_row=last)
        y = Reference(ws, min_col=3, min_row=first, max_row=last)
        if kind == "bubble":
            z = Reference(ws, min_col=4, min_row=first, max_row=last)
            s = Series(values=y, xvalues=x, zvalues=z, title=header[0])
            s.graphicalProperties.solidFill = _hex(PALETTE[0])
            chart.bubbleScale = 60
        else:
            s = Series(y, x, title=header[0])
            s.marker.symbol = "circle"
            s.marker.size = 6
            s.marker.graphicalProperties.solidFill = _hex(PALETTE[0])
            s.graphicalProperties.line.noFill = True
            chart.style = 13
        chart.series.append(s)
        chart.x_axis.title = header[1] if len(header) > 1 else None
        chart.y_axis.title = header[2] if len(header) > 2 else None
        chart.legend = None
        _axes_visible(chart, fmt)
        return chart

    if kind in ("pie", "donut"):
        chart = DoughnutChart() if kind == "donut" else PieChart()
        chart.add_data(Reference(ws, min_col=2, min_row=hdr, max_row=last), titles_from_data=True)
        chart.set_categories(cats)
        for i, r in enumerate(rows):
            pt = DataPoint(idx=i)
            pt.graphicalProperties.solidFill = _hex(OTHER_COLOR if r[0] == "Everything else" else PALETTE[i % len(PALETTE)])
            chart.series[0].dPt.append(pt)
        if kind == "donut":
            chart.holeSize = 50
        chart.legend.position = "r"
        return chart

    right_set = set()
    if kind in ("bar", "line", "area", "combo"):
        from core.reports.svg_charts import _on_right, num
        right_set = _on_right(kind, [[num(r[i]) if i < len(r) else None for i in range(1, 1 + n_series)] for r in rows],
                              n_series, bool((t.get("labels") or {}).get("series")))
        if len(right_set) == n_series:
            right_set = set()
    if right_set and kind != "combo":
        return _two_scale_chart(kind, header, right_set, ws, hdr, last, cats, n_series, fmt)

    if overlay and kind in ("bar", "line", "combo"):
        # the two-dates overlay: (B, A) pairs per value -- B as the kind's marks, A as a DASHED line on the same scale
        if kind == "line":
            chart = LineChart()
            chart.add_data(vals, titles_from_data=True)
            chart.set_categories(cats)
            for i, s in enumerate(chart.series):
                s.graphicalProperties.line.solidFill = _hex(PALETTE[(i // 2) % len(PALETTE)])
                s.graphicalProperties.line.width = 22000
                s.smooth = False
                if i % 2 == 1:
                    s.graphicalProperties.line.dashStyle = "dash"
        else:
            chart = BarChart()
            b_cols = [2 + i for i in range(n_series) if i % 2 == 0]
            for c in b_cols[:1] if kind == "combo" else b_cols:
                chart.add_data(Reference(ws, min_col=c, min_row=hdr, max_row=last), titles_from_data=True)
            chart.set_categories(cats)
            for i, s in enumerate(chart.series):
                s.graphicalProperties.solidFill = _hex(PALETTE[i % len(PALETTE)])
            line = LineChart()
            for i in range(n_series):
                if i % 2 == 1 or (kind == "combo" and i >= 2):
                    line.add_data(Reference(ws, min_col=2 + i, min_row=hdr, max_row=last), titles_from_data=True)
            for s, i in zip(line.series, [i for i in range(n_series) if i % 2 == 1 or (kind == "combo" and i >= 2)]):
                s.graphicalProperties.line.solidFill = _hex(PALETTE[(i // 2) % len(PALETTE)])
                s.graphicalProperties.line.width = 22000
                s.smooth = False
                if i % 2 == 1:
                    s.graphicalProperties.line.dashStyle = "dash"
            chart += line
        chart.legend.position = "b"
        _axes_visible(chart, fmt)
        return chart

    if kind == "combo":
        chart = BarChart()
        chart.add_data(Reference(ws, min_col=2, min_row=hdr, max_row=last), titles_from_data=True)
        chart.set_categories(cats)
        chart.series[0].graphicalProperties.solidFill = _hex(PALETTE[0])
        if n_series > 1:
            line = LineChart()
            line.add_data(Reference(ws, min_col=3, min_row=hdr, max_col=1 + n_series, max_row=last), titles_from_data=True)
            for i, s in enumerate(line.series, 1):
                s.graphicalProperties.line.solidFill = _hex(PALETTE[i % len(PALETTE)])
                s.graphicalProperties.line.width = 22000
                s.smooth = False
            line.y_axis.axId = 200                # the lines on their own scale, on the right
            line.y_axis.crosses = "max"
            line.y_axis.majorGridlines = None
            line.y_axis.delete = False
            chart += line
        chart.legend.position = "b"
        _axes_visible(chart, fmt)
        return chart

    if kind in ("bar", "hbar", "stacked_bar", "treemap", "funnel", "waterfall"):
        chart = BarChart()
        chart.type = "bar" if kind in ("hbar", "treemap", "funnel") else "col"
        if kind in ("stacked_bar", "waterfall"):
            chart.grouping = "stacked"
            chart.overlap = 100
        chart.add_data(vals, titles_from_data=True)
        chart.set_categories(cats)
        for i, s in enumerate(chart.series):
            s.graphicalProperties.solidFill = _hex(PALETTE[i % len(PALETTE)])
        if kind == "waterfall":
            chart.series[0].graphicalProperties.noFill = True
            chart.series[0].graphicalProperties.line.noFill = True
            chart.series[1].graphicalProperties.solidFill = _hex(PALETTE[2])
            chart.series[2].graphicalProperties.solidFill = _hex(PALETTE[7])
            chart.gapWidth = 60
        _legend_bottom(chart, n_series == 1 or kind == "waterfall")
        _axes_visible(chart, fmt)
        return chart

    if kind in ("area", "stacked_area"):
        chart = AreaChart()
        chart.grouping = "stacked" if kind == "stacked_area" else "standard"
        chart.add_data(vals, titles_from_data=True)
        chart.set_categories(cats)
        for i, s in enumerate(chart.series):
            s.graphicalProperties.solidFill = _hex(PALETTE[i % len(PALETTE)])
            s.graphicalProperties.line.solidFill = _hex(PALETTE[i % len(PALETTE)])
        _legend_bottom(chart, n_series == 1)
        _axes_visible(chart, fmt)
        return chart

    if kind == "radar":
        chart = RadarChart()
        chart.type = "standard"
        chart.add_data(vals, titles_from_data=True)
        chart.set_categories(cats)
        for i, s in enumerate(chart.series):
            s.graphicalProperties.line.solidFill = _hex(PALETTE[i % len(PALETTE)])
        _legend_bottom(chart, n_series == 1)
        _axes_visible(chart, fmt)
        return chart

    chart = LineChart()                                   # "line"
    chart.add_data(vals, titles_from_data=True)
    chart.set_categories(cats)
    for i, s in enumerate(chart.series):
        s.graphicalProperties.line.solidFill = _hex(PALETTE[i % len(PALETTE)])
        s.graphicalProperties.line.width = 22000
        s.smooth = False
    chart.legend = None if n_series == 1 else chart.legend
    if chart.legend is not None:
        chart.legend.position = "b"
    _axes_visible(chart, fmt)
    return chart


def _two_scale_chart(kind: str, header: List[str], right_set: set, ws, hdr: int, last: int, cats,
                     n_series: int, fmt: str):
    """Bars / lines / areas with values of very different size: the small
    ones on a second axis on the right, named "(right)" -- the viewer's rule
    (``svg_charts._on_right``)."""
    from openpyxl.chart import AreaChart, BarChart, LineChart, Reference
    from openpyxl.chart.series import SeriesLabel
    make = {"bar": BarChart, "line": LineChart, "area": AreaChart}[kind]
    left, right = make(), make()
    if kind == "bar":
        left.type = right.type = "col"
    for i in range(n_series):
        target = right if i in right_set else left
        target.add_data(Reference(ws, min_col=2 + i, min_row=hdr, max_row=last), titles_from_data=True)
        s = target.series[-1]
        color = _hex(PALETTE[i % len(PALETTE)])
        if i in right_set:
            s.tx = SeriesLabel(v=f"{header[1 + i]} (right)")
        if kind == "line":
            s.graphicalProperties.line.solidFill = color
            s.graphicalProperties.line.width = 22000
            s.smooth = False
        else:
            s.graphicalProperties.solidFill = color
            s.graphicalProperties.line.solidFill = color
    left.set_categories(cats)
    right.set_categories(cats)
    right.y_axis.axId = 200
    right.y_axis.crosses = "max"
    right.y_axis.majorGridlines = None
    right.y_axis.delete = False
    _axes_visible(left, fmt)
    left += right
    left.legend.position = "b"
    return left


def _legend_bottom(chart, none: bool) -> None:
    if none:
        chart.legend = None
    else:
        chart.legend.position = "b"


def _axes_visible(chart, fmt: str) -> None:
    """openpyxl 3.1 writes axes Excel hides unless told otherwise."""
    try:
        chart.x_axis.delete = False
        chart.y_axis.delete = False
        if fmt:
            chart.y_axis.number_format = fmt
    except AttributeError:            # a chart kind without these axes
        pass


def _as_number(v: Any) -> Any:
    from decimal import Decimal
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, (int, float)):
        return v
    try:
        return float(str(v).replace(",", ""))
    except (TypeError, ValueError):
        return None
