"""Iceberg table VERSIONS -- which snapshot each table of a run is read at.

2026-11-01, the owner: "if iceberg metadata has multiple versions, when
version is not supplied run query on max version and return data, and user
can also pass version if need specific".

THE RULE -- resolve ONCE, pin, carry.

* At the START of a run, every Iceberg table the statement reads is resolved
  ONCE (:func:`resolve_run_versions`): a table the SQL pins (``FROM t FOR
  VERSION AS OF <id>`` / ``FOR TIMESTAMP AS OF TIMESTAMP '...'``) is read at
  that snapshot; a table it does not pin is read at its CURRENT snapshot --
  ``current-snapshot-id`` of the metadata the bounded pointer resolves, NOT
  the highest id (ids are random longs) and NOT the newest timestamp (after a
  rollback the newest snapshot is not current; a staged / WAP snapshot is in
  ``snapshots`` but was never made current).
* The answer is ONE map ``{view name: ResolvedVersion}`` (snapshot id, the
  metadata file it came from, its commit time, the metadata dict itself).  It
  is activated for the run (:func:`activate`, a ContextVar every thread pool of
  the run copies) and EVERY later step asks it: the reader
  (``iceberg_reader.get_iceberg_data_files`` -> :func:`version_for`), each
  per-table read, the JoinPruner anchor read, the safety-net re-read, the MoR
  delete collection (same reader, same snapshot), the cache keys.  A commit
  landing mid-run cannot mix two snapshots into one answer: the metadata the
  run resolved is the metadata every step reads.
* A version the metadata does not list, a timestamp before the table's first
  snapshot or in the future, a version on a table that is not Iceberg: a
  REFUSAL (:class:`IcebergVersionRefusal`, 422 via ``api/connector_errors``)
  with a plain sentence -- never current data under a historical label.

THE SPELLING.  The editor's SQL is the single truth: the user writes Trino's
clause.  :func:`rewrite_version_clauses` parses it ONCE at the route, with the
SQL tokenizer (strings and comments are single tokens, so a clause inside a
literal is never touched), and replaces each clause with a canonical comment
marker ``/* qs-version view=<v> table=<t> snapshot=<id> */``.  DuckDB ignores
comments, so the statement runs unchanged otherwise -- and every cache key
that hashes the SQL text (dedup, query cache, result cache, brain sql-hash)
differs between a pinned and an unpinned run BY CONSTRUCTION.  Downstream code
reads the pins back from the marker (:func:`pins_in_sql`); it never re-reads
the user's clause.

The same table read at two versions in one statement (``fact FOR VERSION AS
OF 1 a JOIN fact b`` -- "what changed") is TWO views: the pinned occurrence is
renamed to ``"fact@v1"`` and the run binds a copy of the registered table
under that name (:func:`extra_registered_tables`).

A connection whose engine speaks the clause natively (Trino / Starburst) is
left untouched: the clause is pushed down as written and that engine decides
(Trino refuses it on a non-Iceberg table).  A storage connection (S3 /
local) answers it here.

``"t$snapshots"`` / ``"t$history"`` (Trino's metadata tables) are answered
from metadata.json by :func:`snapshot_rows` / :func:`history_rows` -- the SAME
listing the ``GET .../snapshots`` route and the editor's "Table version"
control read.  No data file is touched.
"""
from __future__ import annotations

import contextvars
import copy
import datetime as _dt
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

#: How far into the future a ``FOR TIMESTAMP AS OF`` may point before it is
#: refused (clock skew between this server and the writer).
FUTURE_SKEW_MS = 60_000

#: The marker that carries a pin from the route to every road.
_MARKER_RE = re.compile(r"/\*\s*qs-version\s+([^*]*?)\s*\*/")

#: Connection types whose engine reads ``FOR VERSION AS OF`` natively.
NATIVE_VERSION_ENGINES = frozenset({"trino", "starburst", "starburst_galaxy",
                                    "galaxy", "presto"})


class IcebergVersionRefusal(ValueError):
    """A version the run cannot read as asked.  The message is the sentence
    the user sees; it names the table and what to do."""


@dataclass(frozen=True)
class VersionPin:
    """One pin as the SQL wrote it.  Exactly one of ``snapshot_id`` /
    ``as_of_ms`` is set."""
    view: str                     # the name the statement reads (lower)
    table: str                    # the registered table (lower)
    snapshot_id: Optional[int] = None
    as_of_ms: Optional[int] = None

    def marker(self) -> str:
        val = (f"snapshot={self.snapshot_id}" if self.snapshot_id is not None
               else f"as_of_ms={self.as_of_ms}")
        return f"/* qs-version view={self.view} table={self.table} {val} */"

    def words(self) -> str:
        if self.snapshot_id is not None:
            return f"version {self.snapshot_id}"
        return f"the version current at {_iso(self.as_of_ms)}"


@dataclass
class ResolvedVersion:
    """What ONE table of a run is read at.  ``metadata`` is the metadata as
    of that snapshot (:func:`metadata_at`) -- what the reader is handed."""
    view: str
    table: str
    snapshot_id: Optional[int]
    committed_at_ms: Optional[int]
    pinned: bool
    metadata_key: Optional[str] = None
    table_uuid: Optional[str] = None
    schema_id: Optional[int] = None
    bucket: str = ""
    prefix: str = ""
    asked: str = "latest"
    decided_by: str = "latest"
    decided_words: Optional[str] = None
    metadata: Optional[dict] = field(default=None, repr=False, compare=False)

    def record(self) -> Dict[str, Any]:
        """The run record / result-header entry (no metadata dict)."""
        return {
            "table": self.table, "view": self.view,
            "snapshot_id": str(self.snapshot_id) if self.snapshot_id is not None else None,
            "committed_at": _iso(self.committed_at_ms),
            "pinned": self.pinned, "asked": self.asked,
            "metadata_key": self.metadata_key, "schema_id": self.schema_id,
            "words": self.words(),
            "decided_by": self.decided_by,
            "decided_words": self.decided_words or rule_words(self.decided_by),
        }

    def words(self) -> str:
        if self.snapshot_id is None:
            return f"{self.table}: no data yet (the table has no snapshot)"
        when = _iso_short(self.committed_at_ms)
        if self.pinned:
            return f"{self.table}: version {self.snapshot_id} from {when}"
        return f"{self.table}: latest (version {self.snapshot_id} from {when})"


def qident(name: Any) -> str:
    """ONE quoting of an identifier in the SQL this module writes (a view
    name, a column): a ``"`` inside the name is doubled, never pasted."""
    return '"' + str(name).replace('"', '""') + '"'


def _iso(ms: Optional[int]) -> Optional[str]:
    if ms is None:
        return None
    return _dt.datetime.fromtimestamp(int(ms) / 1000.0, tz=_dt.timezone.utc) \
        .isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _iso_short(ms: Optional[int]) -> str:
    if ms is None:
        return "an unknown time"
    return _dt.datetime.fromtimestamp(int(ms) / 1000.0, tz=_dt.timezone.utc) \
        .strftime("%Y-%m-%d %H:%M UTC")


# ─────────────────────────────────────────────────────────────────────────────
# The route: parse the clause ONCE and leave a marker
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Rewrite:
    sql: str
    pins: List[VersionPin]
    metadata_tables: List[Tuple[str, str]]   # (table, "snapshots" | "history")

    @property
    def changed(self) -> bool:
        return bool(self.pins or self.metadata_tables)


def may_carry_versions(sql: Optional[str]) -> bool:
    """Cheap pre-check: could ``sql`` hold a version clause or a metadata
    table?  False = the route skips the parse entirely (byte-identical)."""
    if not sql:
        return False
    up = sql.upper()
    return (" AS OF" in up and ("VERSION" in up or "TIMESTAMP" in up)) or \
        "$SNAPSHOTS" in up or "$HISTORY" in up


def _parse_timestamp_ms(text: str) -> int:
    """``'2026-10-30 14:02:00'`` (UTC when no zone is written),
    ``'2026-10-30T14:02:00+01:00'``, ``'... UTC'`` -> epoch ms."""
    t = text.strip()
    if t.upper().endswith(" UTC"):
        t = t[:-4].strip()
    if t.endswith("Z"):
        t = t[:-1] + "+00:00"
    try:
        d = _dt.datetime.fromisoformat(t)
    except ValueError:
        raise IcebergVersionRefusal(
            f"'{text}' is not a time QueryStudio can read in FOR TIMESTAMP AS OF. "
            f"Write it like TIMESTAMP '2026-10-30 14:02:00' (UTC) or with an "
            f"offset, TIMESTAMP '2026-10-30 14:02:00+01:00'.")
    if d.tzinfo is None:
        d = d.replace(tzinfo=_dt.timezone.utc)
    return int(d.timestamp() * 1000)


def _tokens(sql: str):
    import sqlglot
    return list(sqlglot.Dialect.get_or_raise("duckdb").tokenize(sql))


@dataclass
class _Clause:
    table: str            # the bare table name (lower)
    name_start: int       # char offsets of the table name (qualifier included)
    name_end: int
    start: int            # char offsets of the clause (FOR ... value)
    end: int
    snapshot_id: Optional[int]
    as_of_ms: Optional[int]


def _find_clauses(sql: str) -> Tuple[List[_Clause], List[Tuple[str, str]]]:
    """Every ``FOR VERSION AS OF`` / ``FOR TIMESTAMP AS OF`` clause in table
    position, and every ``"t$snapshots"`` / ``"t$history"`` name -- THE one
    reading of the Trino spelling, for every connector."""
    from sqlglot.tokens import TokenType as TT
    try:
        toks = _tokens(sql)
    except Exception as exc:                                   # noqa: BLE001
        raise IcebergVersionRefusal(
            f"The SQL could not be read to find its table versions ({exc}).")
    out: List[_Clause] = []
    meta: List[Tuple[str, str]] = []
    name_types = (TT.VAR, TT.IDENTIFIER)

    def word(i: int) -> str:
        return toks[i].text.lower() if 0 <= i < len(toks) else ""

    for i, tk in enumerate(toks):
        if tk.token_type == TT.IDENTIFIER and "$" in tk.text:
            base, _, kind = tk.text.rpartition("$")
            if kind.lower() in ("snapshots", "history"):
                meta.append((base.lower(), kind.lower()))
        if tk.token_type != TT.FOR:
            continue
        kind = word(i + 1)
        if kind not in ("version", "timestamp") or word(i + 2) != "as" or word(i + 3) != "of":
            continue
        j = i - 1
        if j < 0 or toks[j].token_type not in name_types:
            raise IcebergVersionRefusal(
                "FOR VERSION AS OF / FOR TIMESTAMP AS OF must come straight "
                "after a table name, for example: FROM fact_tetb FOR VERSION "
                "AS OF 8123456789 f.")
        name_end = j
        while j - 2 >= 0 and toks[j - 1].token_type == TT.DOT and \
                toks[j - 2].token_type in name_types:
            j -= 2
        name_start = j
        prev = toks[j - 1].token_type if j - 1 >= 0 else None
        if prev not in (TT.FROM, TT.JOIN, TT.COMMA):
            raise IcebergVersionRefusal(
                "FOR VERSION AS OF / FOR TIMESTAMP AS OF can only follow a "
                "table in FROM or JOIN.")
        table = toks[name_end].text.lower()
        k = i + 4
        snap: Optional[int] = None
        as_of: Optional[int] = None
        if kind == "version":
            neg = k < len(toks) and toks[k].token_type == TT.DASH
            if neg:
                k += 1
            if k >= len(toks) or toks[k].token_type != TT.NUMBER or \
                    not re.fullmatch(r"\d+", toks[k].text):
                raise IcebergVersionRefusal(
                    f"The version of {table} must be written as a snapshot "
                    f"number, for example FOR VERSION AS OF 8123456789. "
                    f"Branch and tag names are not supported. List the "
                    f"versions with SELECT * FROM \"{table}$snapshots\".")
            snap = int(toks[k].text) * (-1 if neg else 1)
        else:
            if k < len(toks) and toks[k].token_type != TT.STRING and \
                    word(k) in ("timestamp", "timestamptz"):
                k += 1
                if word(k) == "with" and word(k + 1) == "time" and word(k + 2) == "zone":
                    k += 3
            if k >= len(toks) or toks[k].token_type != TT.STRING:
                raise IcebergVersionRefusal(
                    f"The time for {table} must be written as TIMESTAMP "
                    f"'2026-10-30 14:02:00' (UTC) in FOR TIMESTAMP AS OF.")
            as_of = _parse_timestamp_ms(toks[k].text)
        out.append(_Clause(table=table, name_start=toks[name_start].start,
                           name_end=toks[name_end].end, start=tk.start,
                           end=toks[k].end, snapshot_id=snap, as_of_ms=as_of))
    return out, meta


def has_version_clause(sql: Optional[str]) -> bool:
    if not may_carry_versions(sql):
        return False
    clauses, _ = _find_clauses(sql or "")
    return bool(clauses)


def rewrite_version_clauses(sql: str, *, iceberg_tables: Dict[str, Any],
                            other_tables: Optional[set] = None) -> Rewrite:
    """QueryStudio's OWN read (a storage connection): each clause becomes a
    qs-version marker the run resolves.  ``iceberg_tables`` = the
    connection's registered ICEBERG names; ``other_tables`` = its other
    registered names (a version on one of those is refused: no versions)."""
    other_tables = {str(x).lower() for x in (other_tables or set())}
    clauses, meta_all = _find_clauses(sql)
    meta = [(t, k) for t, k in meta_all if t in iceberg_tables]
    pins: List[Tuple[VersionPin, _Clause]] = []
    for c in clauses:
        if c.table not in iceberg_tables:
            if c.table in other_tables:
                raise IcebergVersionRefusal(
                    f"{c.table} is not an Iceberg table, so it has no versions: "
                    f"FOR VERSION AS OF / FOR TIMESTAMP AS OF works only on "
                    f"Iceberg tables. Remove the clause to read it as it is now.")
            raise IcebergVersionRefusal(
                f"{c.table} is not a registered Iceberg table on this connection, "
                f"so QueryStudio cannot read a version of it. Versions work "
                f"only on the connection's registered Iceberg tables.")
        pins.append((VersionPin(view=c.table, table=c.table,
                                snapshot_id=c.snapshot_id, as_of_ms=c.as_of_ms), c))
    if not pins:
        return Rewrite(sql=sql, pins=[], metadata_tables=sorted(set(meta)))

    # The same table at two versions (or pinned + unpinned): each pinned
    # occurrence becomes its own view, "<table>@v<id>" / "@t<ms>".
    by_table: Dict[str, set] = {}
    count: Dict[str, int] = {}
    for p, _ in pins:
        by_table.setdefault(p.table, set()).add((p.snapshot_id, p.as_of_ms))
        count[p.table] = count.get(p.table, 0) + 1
    occurrences = _table_occurrences(sql)
    edits: List[Tuple[int, int, str]] = []
    final: Dict[str, VersionPin] = {}
    for p, c in pins:
        if len(by_table[p.table]) > 1 or occurrences.get(p.table, 0) > count[p.table]:
            view = (f"{p.table}@v{p.snapshot_id}" if p.snapshot_id is not None
                    else f"{p.table}@t{p.as_of_ms}")
            p = VersionPin(view=view, table=p.table,
                           snapshot_id=p.snapshot_id, as_of_ms=p.as_of_ms)
            edits.append((c.name_start, c.name_end, qident(view)))
        edits.append((c.start, c.end, p.marker()))
        final.setdefault(p.view, p)
    out = sql
    for s_, e_, text in sorted(edits, key=lambda x: x[0], reverse=True):
        out = out[:s_] + text + out[e_ + 1:]
    return Rewrite(sql=out, pins=list(final.values()), metadata_tables=sorted(set(meta)))


def render_for_connector(sql: str, connection_type: str) -> str:
    """A SQL connector's road: the user writes Trino's spelling once and the
    connector's DECLARED capability (``core/connectors/version_capability``)
    renders each clause in its own dialect -- or refuses it."""
    from core.connectors.version_capability import capability_for
    cap = capability_for(connection_type)
    clauses, _ = _find_clauses(sql)
    if not clauses:
        return sql
    out = sql
    for c in sorted(clauses, key=lambda c: c.start, reverse=True):
        pin = VersionPin(view=c.table, table=c.table,
                         snapshot_id=c.snapshot_id, as_of_ms=c.as_of_ms)
        frag = cap.render_pin(c.table, pin)      # raises IcebergVersionRefusal
        out = out[:c.start] + frag + out[c.end + 1:]
    return out


def _table_occurrences(sql: str) -> Dict[str, int]:
    """How many times each table name is read in table position."""
    out: Dict[str, int] = {}
    try:
        import sqlglot
        from sqlglot import exp
        for tree in sqlglot.parse(sql, read="duckdb"):
            if tree is None:
                continue
            ctes = {c.alias_or_name.lower() for c in tree.find_all(exp.CTE) if c.alias_or_name}
            for tb in tree.find_all(exp.Table):
                n = (tb.name or "").lower()
                if n and n not in ctes:
                    out[n] = out.get(n, 0) + 1
    except Exception:                                           # noqa: BLE001
        return {}
    return out


def pins_in_sql(sql: Optional[str]) -> Dict[str, VersionPin]:
    """The pins a rewritten statement carries, by view name (lower)."""
    out: Dict[str, VersionPin] = {}
    for m in _MARKER_RE.finditer(sql or ""):
        fields = dict(kv.split("=", 1) for kv in m.group(1).split() if "=" in kv)
        view = (fields.get("view") or "").lower()
        table = (fields.get("table") or view).lower()
        if not view:
            continue
        snap = fields.get("snapshot")
        asof = fields.get("as_of_ms")
        try:
            pin = VersionPin(view=view, table=table,
                             snapshot_id=int(snap) if snap is not None else None,
                             as_of_ms=int(asof) if asof is not None else None)
        except ValueError:
            raise IcebergVersionRefusal(
                f"The version written for {table} could not be read.")
        if pin.snapshot_id is None and pin.as_of_ms is None:
            continue
        prior = out.get(view)
        if prior is not None and prior != pin:
            raise IcebergVersionRefusal(
                f"{table} is asked for at two different versions under the "
                f"same name; give each its own FOR VERSION AS OF.")
        out[view] = pin
    return out


def extra_registered_tables(registered: List[Dict[str, Any]],
                            pins: Dict[str, VersionPin]) -> List[Dict[str, Any]]:
    """A copy of the registered table for every pinned view whose name is
    not the table's own (``fact@v1``): the run binds it as its own view."""
    by_name = {str(r.get("name") or "").lower(): r for r in registered or []
               if isinstance(r, dict)}
    extra: List[Dict[str, Any]] = []
    for view, pin in pins.items():
        if view == pin.table or view in by_name:
            continue
        base = by_name.get(pin.table)
        if base is None:
            continue
        clone = dict(base)
        clone["name"] = view
        clone["_version_of"] = base.get("name")
        extra.append(clone)
    return extra


# ─────────────────────────────────────────────────────────────────────────────
# THE resolver
# ─────────────────────────────────────────────────────────────────────────────

def _snapshot_index(metadata: dict) -> Dict[int, dict]:
    out: Dict[int, dict] = {}
    for s in (metadata or {}).get("snapshots") or []:
        sid = _int_or_none(s.get("snapshot-id"))     # a non-integer id is not a snapshot
        if sid is not None:
            out[sid] = s
    return out


def snapshot_current_at(metadata: dict, as_of_ms: int) -> Optional[int]:
    """The snapshot that was CURRENT at ``as_of_ms`` per the ``snapshot-log``
    (the table's history) -- not the snapshot with the nearest timestamp: a
    rollback makes an OLDER snapshot current again, and the log says so.
    None = before the first entry.  The log is read in time order whatever
    order the file lists it in."""
    log = sorted(((int(e["timestamp-ms"]), int(e["snapshot-id"]))
                  for e in (metadata or {}).get("snapshot-log") or []
                  if e.get("timestamp-ms") is not None and e.get("snapshot-id") is not None),
                 key=lambda x: x[0])
    chosen = None
    for ts, sid in log:
        if ts <= as_of_ms:
            chosen = sid
        else:
            break
    return chosen


def _kept_words(metadata: dict, table: str) -> str:
    snaps = sorted(_snapshot_index(metadata).values(),
                   key=lambda s: int(s.get("timestamp-ms") or 0), reverse=True)
    if not snaps:
        return f"{table} has no versions at all yet."
    newest = ", ".join(str(s.get("snapshot-id")) for s in snaps[:3])
    return (f"It keeps {len(snaps)} version(s) now; the newest are {newest}. "
            f"See them all with SELECT * FROM \"{table}$snapshots\".")


def resolve_table_version(metadata: dict, *, view: str, table: str,
                          pin: Optional[VersionPin] = None,
                          metadata_key: Optional[str] = None,
                          bucket: str = "", prefix: str = "",
                          now_ms: Optional[int] = None) -> ResolvedVersion:
    """THE decision: which snapshot of ``table`` this run reads.

    * no pin -> ``current-snapshot-id`` (the table's CURRENT snapshot; after a
      rollback that is the rolled-back-to one, a staged snapshot is never it);
    * ``snapshot_id`` -> that snapshot, refused when the metadata does not list
      it (mistyped, expired, or the table was re-created);
    * ``as_of_ms`` -> the snapshot current at that time per the snapshot-log;
      before the first snapshot or in the future -> refused.
    """
    if not isinstance(metadata, dict):
        raise IcebergVersionRefusal(
            f"The versions of {table} could not be read (its metadata is unreadable).")
    snaps = _snapshot_index(metadata)
    uuid = metadata.get("table-uuid")
    cur = metadata.get("current-snapshot-id")
    cur = int(cur) if cur not in (None, -1) else None
    asked = "latest"
    if pin is None:
        sid = cur
        pinned = False
    elif pin.snapshot_id is not None:
        asked = f"version {pin.snapshot_id}"
        if pin.snapshot_id not in snaps:
            raise IcebergVersionRefusal(
                f"{table} has no version {pin.snapshot_id}. The number may be "
                f"mistyped, the version may no longer be kept (old versions are "
                f"removed by snapshot expiry), or the table may have been "
                f"re-created since. {_kept_words(metadata, table)} Nothing was "
                f"read, so no current data was shown in its place.")
        sid = pin.snapshot_id
        pinned = True
    else:
        now = int(now_ms if now_ms is not None else time.time() * 1000)
        asked = f"as of {_iso(pin.as_of_ms)}"
        if pin.as_of_ms > now + FUTURE_SKEW_MS:
            raise IcebergVersionRefusal(
                f"{_iso(pin.as_of_ms)} is in the future, so {table} has no "
                f"version for it yet. Remove FOR TIMESTAMP AS OF to read the "
                f"latest version, or pick a time that has passed.")
        if not metadata.get("snapshot-log"):
            raise IcebergVersionRefusal(
                f"{table} keeps no history of when each version became current, "
                f"so FOR TIMESTAMP AS OF cannot be answered for it. Use FOR "
                f"VERSION AS OF with a number from \"{table}$snapshots\".")
        sid = snapshot_current_at(metadata, int(pin.as_of_ms))
        if sid is None:
            raise IcebergVersionRefusal(
                f"{_iso(pin.as_of_ms)} is before the first version of {table} "
                f"that is still on record, so there is nothing to read at that "
                f"time. {_kept_words(metadata, table)}")
        if sid not in snaps:
            raise IcebergVersionRefusal(
                f"The version of {table} that was current at "
                f"{_iso(pin.as_of_ms)} ({sid}) is no longer kept (old versions "
                f"are removed by snapshot expiry). {_kept_words(metadata, table)}")
        pinned = True
    snap = snaps.get(sid) if sid is not None else None
    if sid is not None and snap is None:
        raise IcebergVersionRefusal(
            f"The current version of {table} ({sid}) is not listed in its "
            f"metadata, so it cannot be read.")
    rv = ResolvedVersion(
        view=view, table=table, snapshot_id=sid,
        committed_at_ms=int(snap["timestamp-ms"]) if snap and snap.get("timestamp-ms") is not None else None,
        pinned=pinned,
        metadata_key=metadata_key, table_uuid=str(uuid) if uuid else None,
        schema_id=(int(snap["schema-id"]) if snap and snap.get("schema-id") is not None
                   else metadata.get("current-schema-id")),
        bucket=bucket, prefix=str(prefix or "").strip("/"), asked=asked,
    )
    rv.metadata = metadata_at(metadata, rv)
    return rv


def schema_columns_at(metadata: dict, snapshot_id: Optional[int]) -> List[Dict[str, Any]]:
    """The columns (``name`` / ``type`` / ``field_id``) of the schema
    ``snapshot_id`` was written with -- the schema a read of that version
    projects.  None / an unknown snapshot = the current schema.  THE one
    reading for the pre-validation stubs and the version panel: a column
    renamed or added AFTER the pinned version is not there, and a column it
    had then is."""
    schemas = (metadata or {}).get("schemas") or (
        [metadata["schema"]] if isinstance(metadata, dict) and "schema" in metadata else [])
    sid_schema = None
    if snapshot_id is not None:
        snap = _snapshot_index(metadata).get(int(snapshot_id)) or {}
        sid_schema = snap.get("schema-id")
    want = sid_schema if sid_schema is not None else (metadata or {}).get("current-schema-id", 0)
    schema_obj = next((s for s in schemas if s.get("schema-id") == want),
                      schemas[0] if schemas else {})
    out: List[Dict[str, Any]] = []
    for fld in schema_obj.get("fields", []) or []:
        ftype = fld.get("type", "string")
        if isinstance(ftype, dict):
            ftype = ftype.get("type", "struct")
        out.append({"name": fld.get("name", ""), "type": str(ftype),
                    "field_id": fld.get("id") or fld.get("field-id")})
    return out


def metadata_at(metadata: dict, rv: ResolvedVersion) -> dict:
    """The metadata AS OF ``rv``'s snapshot: ``current-snapshot-id`` is the
    snapshot and ``current-schema-id`` the schema that snapshot was written
    with (an old version is read with ITS columns; the read plan projects by
    field id from the current schema).  A run on the current snapshot gets the
    metadata unchanged (byte-identical behaviour)."""
    cur = metadata.get("current-snapshot-id")
    if rv.snapshot_id is None or (cur not in (None, -1) and int(cur) == rv.snapshot_id):
        return metadata
    m = copy.copy(metadata)
    m["current-snapshot-id"] = rv.snapshot_id
    snap = _snapshot_index(metadata).get(rv.snapshot_id) or {}
    if snap.get("schema-id") is not None and any(
            s.get("schema-id") == snap.get("schema-id") for s in metadata.get("schemas") or []):
        m["current-schema-id"] = snap.get("schema-id")
    return m


# ─────────────────────────────────────────────────────────────────────────────
# Reading a table's metadata (the bounded pointer) and resolving a run
# ─────────────────────────────────────────────────────────────────────────────

def read_table_metadata(s3_client, bucket: str, prefix: str, *,
                        force_fresh: bool = False) -> Tuple[str, dict]:
    """(metadata key, metadata) through the reader's bounded pointer -- the
    same answer every road of the reader gets for "latest"."""
    from core.iceberg_reader import _latest_metadata_key, _read_s3_json_cached
    meta_prefix = str(prefix).strip("/") + "/metadata/"
    key = _latest_metadata_key(s3_client, bucket, meta_prefix, force_fresh=force_fresh)
    return key, _read_s3_json_cached(s3_client, bucket, key)


def resolve_run_versions(s3_client, bucket: str,
                         tables: List[Dict[str, Any]],
                         pins: Dict[str, VersionPin], *,
                         force_fresh: bool = False,
                         now_ms: Optional[int] = None,
                         decided_by: Optional[Dict[str, str]] = None) -> Dict[str, ResolvedVersion]:
    """Resolve EVERY Iceberg table ``tables`` names (registered-table dicts:
    ``name`` = the view, ``s3_prefix``) ONCE, before any data is read.  A pin
    on a view that is not among them is refused.  Raises
    :class:`IcebergVersionRefusal`; any other failure propagates (the caller
    decides -- unknown is not "latest")."""
    out: Dict[str, ResolvedVersion] = {}
    known = {str(t.get("name") or "").lower() for t in tables}
    for view, pin in pins.items():
        if view not in known:
            raise IcebergVersionRefusal(
                f"{pin.table} is not a registered Iceberg table on this "
                f"connection, so QueryStudio cannot read a version of it.")
    meta_by_prefix: Dict[str, Tuple[str, dict]] = {}
    for t in tables:
        view = str(t.get("name") or "").lower()
        prefix = str(t.get("s3_prefix") or "").strip("/")
        table = str(t.get("_version_of") or t.get("name") or "").lower()
        if not view or not prefix:
            continue
        if prefix not in meta_by_prefix:
            meta_by_prefix[prefix] = read_table_metadata(
                s3_client, bucket, prefix, force_fresh=force_fresh)
        key, meta = meta_by_prefix[prefix]
        out[view] = resolve_table_version(
            meta, view=view, table=table, pin=pins.get(view), metadata_key=key,
            bucket=bucket, prefix=prefix, now_ms=now_ms)
        out[view].decided_by = (decided_by or {}).get(
            view, RULE_IN_SQL if view in pins else RULE_LATEST)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# THE precedence -- one rule for every entry point
# ─────────────────────────────────────────────────────────────────────────────

#: A run-time override (the published API's ?snapshot_id= / ?as_of_timestamp=,
#: a run option) beats the version the statement itself pins (the editor's
#: SQL, a saved query's SQL), which beats the snapshot whose commit released
#: a feed run, which beats latest (the table's own current version).
RULE_OVERRIDE = "override"
RULE_IN_SQL = "pinned_in_sql"
RULE_SAVED = "saved_pin"
RULE_RELEASED = "released_by_commit"
RULE_LATEST = "latest"
PRECEDENCE = (RULE_OVERRIDE, RULE_IN_SQL, RULE_SAVED, RULE_RELEASED, RULE_LATEST)


def decide_pin(*, override: Optional[VersionPin] = None,
               in_sql: Optional[VersionPin] = None,
               saved: Optional[VersionPin] = None,
               released: Optional[VersionPin] = None) -> Tuple[Optional[VersionPin], str]:
    """(the pin a view is read at, the rule that decided it) -- ``None`` =
    latest.  THE precedence; every entry point asks it.  ``in_sql`` is the
    clause written in the statement, ``saved`` a pin saved beside it (a
    feed's ``query_params.iceberg_versions``) -- both "saved on the object",
    the statement's own clause the more specific."""
    for pin, rule in ((override, RULE_OVERRIDE), (in_sql, RULE_IN_SQL),
                      (saved, RULE_SAVED), (released, RULE_RELEASED)):
        if pin is not None:
            return pin, rule
    return None, RULE_LATEST


def rule_words(rule: str, by: Optional[str] = None) -> str:
    """The rule in the words a run record shows a person."""
    return {
        RULE_OVERRIDE: f"override by {by}" if by else "override at run time",
        RULE_IN_SQL: "pinned in the query",
        RULE_SAVED: "saved pin",
        RULE_RELEASED: "released by commit",
        RULE_LATEST: "latest",
    }.get(rule, rule)


# ─────────────────────────────────────────────────────────────────────────────
# The run's map: activated once, asked by every step
# ─────────────────────────────────────────────────────────────────────────────

_RUN_VERSIONS: contextvars.ContextVar[Optional[Dict[str, ResolvedVersion]]] = \
    contextvars.ContextVar("qs_iceberg_run_versions", default=None)


def activate(versions: Optional[Dict[str, ResolvedVersion]]):
    """Make ``versions`` the run's map; returns the token for :func:`deactivate`."""
    return _RUN_VERSIONS.set(dict(versions) if versions else None)


def deactivate(token) -> None:
    try:
        _RUN_VERSIONS.reset(token)
    except Exception:                                           # noqa: BLE001
        _RUN_VERSIONS.set(None)


def run_versions() -> Dict[str, ResolvedVersion]:
    return dict(_RUN_VERSIONS.get() or {})


def version_for(table_name: Optional[str], bucket: Optional[str],
                prefix: Optional[str]) -> Optional[ResolvedVersion]:
    """The run's resolved version for this read, or None (no run map, or the
    table is not in it -- the reader then resolves as it always did).

    By VIEW name first (the reader is told which view it reads); by
    (bucket, prefix) only when every view of that prefix is read at ONE
    snapshot.  Two views of one prefix at two snapshots and no name =
    :class:`IcebergVersionRefusal` (guessing would mix versions)."""
    vm = _RUN_VERSIONS.get()
    if not vm:
        return None
    if table_name:
        rv = vm.get(str(table_name).lower())
        if rv is not None:
            return rv
    p = str(prefix or "").strip("/")
    hits = [rv for rv in vm.values()
            if rv.prefix == p and (not bucket or not rv.bucket or rv.bucket == bucket)]
    if not hits:
        return None
    if len({rv.snapshot_id for rv in hits}) > 1:
        raise IcebergVersionRefusal(
            f"A read of {hits[0].table} did not say which of its versions it "
            f"wants ({', '.join(sorted(str(h.snapshot_id) for h in hits))}); "
            f"refusing rather than guessing.")
    return hits[0]


def l1_cache_snapshot_token(rv: Optional[ResolvedVersion]) -> Optional[str]:
    """The extra L1 file-list key part for a PINNED read (an unpinned read
    keeps today's key and is validated against ``rv.snapshot_id``)."""
    if rv is None or not rv.pinned:
        return None
    return f"@{rv.snapshot_id}:{rv.table_uuid or ''}"


def run_record(versions: Optional[Dict[str, ResolvedVersion]] = None) -> List[Dict[str, Any]]:
    vm = versions if versions is not None else (_RUN_VERSIONS.get() or {})
    return [vm[k].record() for k in sorted(vm)]


# ─────────────────────────────────────────────────────────────────────────────
# Run-time OVERRIDES -- ONE parser for every entry point (2026-11-01)
# ─────────────────────────────────────────────────────────────────────────────

#: The override every table of a run takes when none names it.
EVERY_TABLE = "*"
OVERRIDE_PREFIX = "version."
AS_OF_PARAM = "as_of"
#: The query_config key the serialized overrides travel under.
QC_OVERRIDES_KEY = "_iceberg_version_overrides"


def parse_version_overrides(params: Any, *, legacy_snapshot_id: Any = None,
                            legacy_as_of_ms: Any = None, body: bool = False) -> Dict[str, VersionPin]:
    """``?version.<table>=<snapshot id>`` per table, ``?as_of=<time>`` for
    EVERY table (each side / table resolved on its own), and the published
    API's older ``?snapshot_id=`` / ``?as_of_timestamp=`` (every table) --
    one reading for the published API, a report's "Data version" run option
    and a feed's run-now body.  ``params`` is any mapping (a Starlette
    QueryParams, a dict, a report body ``{table: {snapshot_id | as_of}}``).
    ``body=True`` reads a BODY (``{table: value}``, every key a table);
    ``body=False`` reads a request's query string, where only the
    ``version.`` / ``as_of`` keys are ours (``limit=`` is not a table).
    Refusals are :class:`IcebergVersionRefusal` sentences."""
    out: Dict[str, VersionPin] = {}
    items = []
    if params is not None:
        if hasattr(params, "multi_items"):
            items = list(params.multi_items())
        elif hasattr(params, "items"):
            items = list(params.items())
    for key, val in items:
        k = str(key or "").strip()
        if k.lower().startswith(OVERRIDE_PREFIX):
            table = k[len(OVERRIDE_PREFIX):].strip().strip('"').lower()
            if not table:
                raise IcebergVersionRefusal("version.<table> names no table.")
            _put(out, table, _pin_from_value(table, val))
        elif k.lower() == AS_OF_PARAM:
            if val in (None, ""):
                continue
            _put(out, EVERY_TABLE, VersionPin(view=EVERY_TABLE, table=EVERY_TABLE,
                                              as_of_ms=_parse_timestamp_ms(str(val))))
        elif body or isinstance(val, dict):  # a body: {table: {snapshot_id|as_of} | "latest" | "<id>"}
            table = k.strip('"').lower()
            if not table:
                raise IcebergVersionRefusal("A version names no table.")
            _put(out, table, _pin_from_value(table, val))
    if legacy_snapshot_id not in (None, ""):
        _put(out, EVERY_TABLE, VersionPin(view=EVERY_TABLE, table=EVERY_TABLE,
                                          snapshot_id=_snapshot_int(EVERY_TABLE, legacy_snapshot_id)))
    if legacy_as_of_ms not in (None, ""):
        _put(out, EVERY_TABLE, VersionPin(view=EVERY_TABLE, table=EVERY_TABLE,
                                          as_of_ms=int(legacy_as_of_ms)))
    return out


def _snapshot_int(table: str, value: Any) -> int:
    s = str(value).strip()
    if not re.fullmatch(r"\d{1,20}", s):
        raise IcebergVersionRefusal(
            f"The version of {table} must be a snapshot number (for example "
            f"version.{table}=8123456789); '{s[:40]}' is not one.")
    return int(s)


def _pin_from_value(table: str, val: Any) -> VersionPin:
    """A value is a snapshot number, the word ``latest`` (= no pin), an ISO
    time (``as of``), or a dict ``{snapshot_id} | {as_of} | {as_of_ms}``."""
    if isinstance(val, dict):
        sid = val.get("snapshot_id")
        asof = val.get("as_of") or val.get("as_of_timestamp")
        asof_ms = val.get("as_of_ms")
        given = [x for x in (sid, asof, asof_ms) if x not in (None, "")]
        if len(given) != 1:
            raise IcebergVersionRefusal(
                f"The version of {table} must be ONE of snapshot_id or as_of.")
        if sid not in (None, ""):
            return VersionPin(view=table, table=table, snapshot_id=_snapshot_int(table, sid))
        if asof_ms not in (None, ""):
            return VersionPin(view=table, table=table, as_of_ms=int(asof_ms))
        return VersionPin(view=table, table=table, as_of_ms=_parse_timestamp_ms(str(asof)))
    s = str(val or "").strip()
    if not s or s.lower() == "latest":
        return VersionPin(view=table, table=table)        # neither set = latest
    if re.fullmatch(r"\d{1,20}", s):
        return VersionPin(view=table, table=table, snapshot_id=int(s))
    try:
        return VersionPin(view=table, table=table, as_of_ms=_parse_timestamp_ms(s))
    except IcebergVersionRefusal:
        raise IcebergVersionRefusal(
            f"The version of {table} must be a snapshot number or a time "
            f"(for example version.{table}=8123456789 or "
            f"version.{table}=2026-10-30T14:02:00Z); '{s[:40]}' is neither.")


def _put(out: Dict[str, VersionPin], table: str, pin: VersionPin) -> None:
    prior = out.get(table)
    if prior is not None and prior != pin:
        raise IcebergVersionRefusal(
            f"{table if table != EVERY_TABLE else 'Every table'} is given two different "
            f"versions in one request; give it one.")
    out[table] = pin


def serialize_overrides(overrides: Dict[str, VersionPin]) -> Dict[str, Dict[str, Any]]:
    """The overrides as they travel in a query_config / run record."""
    out: Dict[str, Dict[str, Any]] = {}
    for t, p in (overrides or {}).items():
        if p.snapshot_id is not None:
            out[t] = {"snapshot_id": str(p.snapshot_id)}
        elif p.as_of_ms is not None:
            out[t] = {"as_of_ms": int(p.as_of_ms)}
        else:
            out[t] = {"latest": True}
    return out


def overrides_from_query_config(qcd: Any) -> Dict[str, VersionPin]:
    """The overrides a run's query_config carries: the serialized per-table
    map (``QC_OVERRIDES_KEY``) and the legacy every-table keys."""
    q = qcd if isinstance(qcd, dict) else {}
    out = parse_version_overrides(
        {}, legacy_snapshot_id=q.get("_iceberg_snapshot_id"),
        legacy_as_of_ms=q.get("_iceberg_as_of_ms"))
    for t, v in (q.get(QC_OVERRIDES_KEY) or {}).items():
        if isinstance(v, dict) and v.get("latest"):
            _put(out, str(t).lower(), VersionPin(view=str(t).lower(), table=str(t).lower()))
        else:
            _put(out, str(t).lower(), _pin_from_value(str(t).lower(), v))
    return out


def parse_body_overrides(body: Any) -> Dict[str, VersionPin]:
    """A report / feed BODY ``{table: {snapshot_id} | {as_of} | "latest" | "<id>"}``."""
    return parse_version_overrides(body or {}, body=True)


def overrides_key(overrides: Dict[str, VersionPin]) -> Optional[str]:
    """A canonical text for a cache key (None when nothing is overridden)."""
    if not overrides:
        return None
    parts = []
    for t in sorted(overrides):
        p = overrides[t]
        parts.append(f"{t}@{'v' + str(p.snapshot_id) if p.snapshot_id is not None else 't' + str(p.as_of_ms) if p.as_of_ms is not None else 'latest'}")
    return ";".join(parts)


def override_for(overrides: Dict[str, VersionPin], view: str, table: str) -> Optional[VersionPin]:
    """The override that applies to ``view`` (its own name, its table's, else
    the every-table one); a ``latest`` override (neither set) is a pin to
    NOTHING -- it only beats a saved pin / a released commit."""
    for key in (view.lower(), table.lower(), EVERY_TABLE):
        p = overrides.get(key)
        if p is not None:
            return VersionPin(view=view, table=table, snapshot_id=p.snapshot_id, as_of_ms=p.as_of_ms)
    return None


def _is_latest(pin: Optional[VersionPin]) -> bool:
    return pin is not None and pin.snapshot_id is None and pin.as_of_ms is None


# ─────────────────────────────────────────────────────────────────────────────
# THE resolver every ROAD calls (2026-11-01): execute_api, FederationEngine
# (reports / datasets / the second side of a cross-source run), the feed engine
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RunResolution:
    versions: Dict[str, ResolvedVersion]
    sql: Optional[str]                 # the statement with its clauses as markers (None = unchanged)
    extra_tables: List[Dict[str, Any]]  # the "t@v<id>" views to bind beside the registered ones
    overrides: Dict[str, VersionPin]

    def record(self) -> List[Dict[str, Any]]:
        return run_record(self.versions)


def resolve_for_connection(*, s3_client, bucket: str, registered_tables: List[Dict[str, Any]],
                           sql: Optional[str] = None,
                           referenced_names: Optional[List[str]] = None,
                           overrides: Optional[Dict[str, VersionPin]] = None,
                           saved: Optional[Dict[str, VersionPin]] = None,
                           released: Optional[Dict[str, VersionPin]] = None,
                           force_fresh: bool = False, now_ms: Optional[int] = None,
                           allow_renamed_views: bool = True,
                           override_by: Optional[str] = None) -> Optional[RunResolution]:
    """Resolve ONCE, for one storage connection, every Iceberg table a run
    reads: the statement's own ``FOR VERSION AS OF`` (rewritten to markers
    here when a road hands the user's spelling), the run-time overrides, the
    snapshot whose commit released a feed run, else latest -- THE precedence
    (:func:`decide_pin`) per table.  None = the run reads no Iceberg table of
    this connection and nothing was asked.  Raises
    :class:`IcebergVersionRefusal`; any other failure propagates (unknown is
    not "latest")."""
    regs = [r for r in (registered_tables or []) if isinstance(r, dict) and r.get("name")]
    ice = {str(r.get("name")).lower(): r for r in regs
           if str(r.get("format") or "parquet").lower() == "iceberg"}
    other = {str(r.get("name")).lower() for r in regs} - set(ice)
    overrides = dict(overrides or {})
    saved = dict(saved or {})
    released = dict(released or {})
    rewritten: Optional[str] = None
    if sql and has_version_clause(sql):
        rewritten = rewrite_version_clauses(sql, iceberg_tables=ice, other_tables=other).sql
        sql = rewritten
    pins = pins_in_sql(sql) if sql else {}
    extra = extra_registered_tables(regs, pins) if pins else []
    if extra and not allow_renamed_views:
        raise IcebergVersionRefusal(
            f"{extra[0].get('_version_of')} is read at two versions in one statement; "
            f"this road reads a table at ONE version -- pin it once.")
    for key in list(overrides):
        if key != EVERY_TABLE and key not in ice:
            if key in other:
                raise IcebergVersionRefusal(
                    f"{key} is not an Iceberg table, so it has no versions to pick from.")
            raise IcebergVersionRefusal(
                f"{key} is not a registered Iceberg table on this connection, so "
                f"QueryStudio cannot read a version of it.")
    # which views this run reads
    if referenced_names is not None:
        wanted = {str(n).lower() for n in referenced_names}
    elif sql:
        wanted = {t["table"].lower() for t in iceberg_tables_in_sql(sql, list(ice))}
        wanted |= {v for v in pins}
    else:
        wanted = set(ice)
    tables: List[Dict[str, Any]] = [dict(r) for n, r in ice.items() if n in wanted]
    tables += list(extra)                      # a pinned "t@v" view is always read
    if not tables and not pins and not {k for k in overrides if k != EVERY_TABLE}:
        return None
    decided: Dict[str, str] = {}
    final_pins: Dict[str, VersionPin] = {}
    for t in tables:
        view = str(t.get("name")).lower()
        table = str(t.get("_version_of") or t.get("name")).lower()
        ov = override_for(overrides, view, table)
        if _is_latest(ov):
            decided[view] = RULE_OVERRIDE          # "latest" asked at run time: beats a saved pin
            continue
        sv = saved.get(view) or saved.get(table)
        if _is_latest(sv):
            sv = None
        pin, rule = decide_pin(override=ov, in_sql=pins.get(view), saved=sv,
                               released=released.get(table))
        decided[view] = rule
        if pin is not None:
            final_pins[view] = VersionPin(view=view, table=table, snapshot_id=pin.snapshot_id,
                                          as_of_ms=pin.as_of_ms)
    versions = resolve_run_versions(s3_client, bucket, tables, final_pins,
                                    force_fresh=force_fresh, now_ms=now_ms, decided_by=decided)
    for rv in versions.values():
        rv.decided_words = rule_words(rv.decided_by, override_by)
    return RunResolution(versions=versions, sql=rewritten, extra_tables=extra, overrides=overrides)


def released_pins_for_feed(db, feed_config: Dict[str, Any], business_date,
                           registered_tables: List[Dict[str, Any]], bucket: str) -> Dict[str, VersionPin]:
    """Rule 3 of the precedence: the snapshot whose commit RELEASED this
    feed run -- the ``iceberg_commit`` arrival on the run's business date for
    each of the feed's dependencies, matched to a registered table by
    bucket + prefix (``core/feed/iceberg_commit_source.py`` records
    ``payload.snapshot_id`` / ``bucket`` / ``table_prefix``).  Unreadable =
    nothing released (the run reads latest and says so), never a guess."""
    out: Dict[str, VersionPin] = {}
    if db is None or business_date is None or not feed_config:
        return out
    try:
        from core.feed.etl_dependency import effective_etl_id
        from core.table_prefix import canonical_prefix
        etl_id = effective_etl_id(feed_config)
        rows = db.list_etl_dependency_mappings(etl_id) if hasattr(db, "list_etl_dependency_mappings") else []
        by_prefix = {canonical_prefix(str(r.get("s3_prefix") or "")): str(r.get("name")).lower()
                     for r in registered_tables or []
                     if isinstance(r, dict) and r.get("name")
                     and str(r.get("format") or "").lower() == "iceberg"}
        for m in rows or []:
            name = m.get("dependency_key") or m.get("dependency_name")
            if not name:
                continue
            for ev in db.list_dependency_events(str(name), business_date) or []:
                if str(ev.get("source") or "") != "iceberg_commit":
                    continue
                payload = ev.get("payload") or {}
                if isinstance(payload, str):
                    import json as _json
                    try:
                        payload = _json.loads(payload)
                    except ValueError:
                        payload = {}
                sid = _int_or_none(payload.get("snapshot_id"))
                pfx = canonical_prefix(str(payload.get("table_prefix") or payload.get("prefix") or ""))
                if sid is None or not pfx or (payload.get("bucket") and str(payload.get("bucket")) != str(bucket)):
                    continue
                table = by_prefix.get(pfx)
                if table:
                    out[table] = VersionPin(view=table, table=table, snapshot_id=sid)   # the LATEST arrival wins
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("[iceberg-versions] released-by-commit pins unreadable (%s); "
                       "the run reads latest and says so", exc)
        return {}
    return out


# ─────────────────────────────────────────────────────────────────────────────
# The listing -- ONE function for the route, the editor control, $snapshots
# ─────────────────────────────────────────────────────────────────────────────

def snapshot_rows(metadata: dict, *, limit: int = 0) -> List[Dict[str, Any]]:
    """Every snapshot the metadata lists, newest first: Trino's
    ``$snapshots`` columns (committed_at, snapshot_id, parent_id, operation,
    manifest_list, summary) plus what the editor shows (is_current, rows added
    / total rows / files from the summary, schema_id)."""
    cur = (metadata or {}).get("current-snapshot-id")
    rows: List[Dict[str, Any]] = []
    for s in (metadata or {}).get("snapshots") or []:
        # ids and times are INTEGERS or the row is not listed: the listing is
        # inlined into SQL (``metadata_table_sql``), so nothing from the file
        # travels as text but through ``_q`` (security review 2026-11-01)
        sid = _int_or_none(s.get("snapshot-id"))
        if sid is None:
            continue
        summ = {str(k): str(v) for k, v in (s.get("summary") or {}).items()}
        rows.append({
            "committed_at": _iso(_int_or_none(s.get("timestamp-ms"))),
            "committed_at_ms": _int_or_none(s.get("timestamp-ms")),
            "snapshot_id": str(sid),
            "parent_id": (str(_int_or_none(s.get("parent-snapshot-id")))
                          if _int_or_none(s.get("parent-snapshot-id")) is not None else None),
            "operation": summ.get("operation"),
            "manifest_list": s.get("manifest-list"),
            "summary": summ,
            "is_current": cur is not None and str(cur) == str(s.get("snapshot-id")),
            "schema_id": _int_or_none(s.get("schema-id")),
            "added_rows": _int_or_none(summ.get("added-records")),
            "total_rows": _int_or_none(summ.get("total-records")),
            "total_files": _int_or_none(summ.get("total-data-files")),
        })
    rows.sort(key=lambda r: int(r["committed_at_ms"] or 0), reverse=True)
    return rows[:limit] if limit and limit > 0 else rows


def history_rows(metadata: dict) -> List[Dict[str, Any]]:
    """Trino's ``$history``: one row per entry of the snapshot-log (when a
    snapshot BECAME current), oldest first, with ``is_current_ancestor``."""
    snaps = _snapshot_index(metadata)
    anc: set = set()
    cur = (metadata or {}).get("current-snapshot-id")
    sid = int(cur) if cur not in (None, -1) else None
    while sid is not None and sid not in anc:
        anc.add(sid)
        p = (snaps.get(sid) or {}).get("parent-snapshot-id")
        sid = int(p) if p is not None else None
    out = []
    for e in sorted((metadata or {}).get("snapshot-log") or [],
                    key=lambda e: _int_or_none(e.get("timestamp-ms")) or 0):
        s_id = _int_or_none(e.get("snapshot-id"))
        if s_id is None:
            continue
        parent = _int_or_none((snaps.get(s_id) or {}).get("parent-snapshot-id"))
        out.append({"made_current_at": _iso(_int_or_none(e.get("timestamp-ms"))),
                    "snapshot_id": str(s_id),
                    "parent_id": str(parent) if parent is not None else None,
                    "is_current_ancestor": s_id in anc})
    return out


def _int_or_none(v: Any) -> Optional[int]:
    try:
        return int(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def _q(v: Optional[str]) -> str:
    return "NULL" if v is None else "'" + str(v).replace("'", "''") + "'"


def metadata_table_sql(metadata: dict, kind: str) -> str:
    """``"t$snapshots"`` / ``"t$history"`` as an inline, typed DuckDB
    subquery over the listing (no data file is read)."""
    if kind == "snapshots":
        cols = ("committed_at TIMESTAMPTZ", "snapshot_id BIGINT", "parent_id BIGINT",
                "operation VARCHAR", "manifest_list VARCHAR",
                "summary MAP(VARCHAR, VARCHAR)")
        vals = []
        for r in sorted(snapshot_rows(metadata), key=lambda r: int(r["committed_at_ms"] or 0)):
            m = ", ".join(f"{_q(k)}: {_q(v)}" for k, v in sorted(r["summary"].items()))
            vals.append("(" + ", ".join([
                f"CAST({_q(r['committed_at'])} AS TIMESTAMPTZ)",
                f"CAST({int(r['snapshot_id'])} AS BIGINT)",
                f"CAST({int(r['parent_id']) if r['parent_id'] is not None else 'NULL'} AS BIGINT)",
                f"CAST({_q(r['operation'])} AS VARCHAR)",
                # manifest_list is kept as a column (Trino's shape) but always NULL: a
                # storage path is internal (security review 30c12d091), and an s3:// text in
                # the SQL is refused by the on-prem S3 road's typed-path guard (rig 2026-11-01)
                "CAST(NULL AS VARCHAR)",
                f"CAST(MAP {{{m}}} AS MAP(VARCHAR, VARCHAR))"]) + ")")
    else:
        cols = ("made_current_at TIMESTAMPTZ", "snapshot_id BIGINT", "parent_id BIGINT",
                "is_current_ancestor BOOLEAN")
        vals = []
        for r in history_rows(metadata):
            vals.append("(" + ", ".join([
                f"CAST({_q(r['made_current_at'])} AS TIMESTAMPTZ)",
                f"CAST({int(r['snapshot_id'])} AS BIGINT)",
                f"CAST({int(r['parent_id']) if r['parent_id'] is not None else 'NULL'} AS BIGINT)",
                "TRUE" if r["is_current_ancestor"] else "FALSE"]) + ")")
    names = ", ".join(c.split()[0] for c in cols)
    if not vals:
        nulls = ", ".join(f"CAST(NULL AS {c.split(' ', 1)[1]}) AS {c.split()[0]}" for c in cols)
        return f"(SELECT {nulls} WHERE FALSE)"
    return f"(SELECT * FROM (VALUES {', '.join(vals)}) AS _qs_meta({names}))"


def inline_metadata_tables(sql: str, tables_meta: Dict[str, dict]) -> str:
    """Replace each ``"t$snapshots"`` / ``"t$history"`` identifier token with
    its inline subquery (``tables_meta`` = ``{lower table: metadata}``)."""
    from sqlglot.tokens import TokenType as TT
    toks = _tokens(sql)
    edits = []
    for tk in toks:
        if tk.token_type == TT.IDENTIFIER and "$" in tk.text:
            base, _, kind = tk.text.rpartition("$")
            md = tables_meta.get(base.lower())
            if md is not None and kind.lower() in ("snapshots", "history"):
                # the quotes are outside the token's text span
                s, e = tk.start, tk.end
                if s > 0 and sql[s - 1] == '"':
                    s -= 1
                if e + 1 < len(sql) and sql[e + 1] == '"':
                    e += 1
                edits.append((s, e, metadata_table_sql(md, kind.lower())))
    for s, e, text in sorted(edits, key=lambda x: x[0], reverse=True):
        sql = sql[:s] + text + sql[e + 1:]
    return sql


def set_table_version_in_sql(sql: str, table: str, snapshot_id: Optional[str],
                             as_of: Optional[str] = None) -> str:
    """The editor control's edit: put ``FOR VERSION AS OF <id>`` (or, with
    ``as_of``, ``FOR TIMESTAMP AS OF TIMESTAMP '<utc>'``) after every
    occurrence of ``table`` in table position, replacing a clause already
    there; both None removes it ("Latest").  The SQL text stays the single
    truth.  The time is re-rendered in UTC from THE parser, never pasted."""
    from sqlglot.tokens import TokenType as TT
    if snapshot_id is not None and not re.fullmatch(r"\d{1,20}", str(snapshot_id)):
        raise IcebergVersionRefusal("A version is a snapshot number.")
    if as_of not in (None, ""):
        if snapshot_id is not None:
            raise IcebergVersionRefusal("Pick a version number OR a time, not both.")
        ms = _parse_timestamp_ms(str(as_of))
        clause = " FOR TIMESTAMP AS OF TIMESTAMP '" + \
            _dt.datetime.fromtimestamp(ms / 1000.0, tz=_dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S") + " UTC'"
    else:
        clause = f" FOR VERSION AS OF {int(snapshot_id)}" if snapshot_id else ""
    toks = _tokens(sql)
    t = table.lower()
    edits: List[Tuple[int, int, str]] = []   # (start, end_incl, replacement)
    name_types = (TT.VAR, TT.IDENTIFIER)
    i = 0
    while i < len(toks):
        tk = toks[i]
        if tk.token_type in name_types and tk.text.lower() == t:
            prev = toks[i - 1].token_type if i > 0 else None
            if prev == TT.DOT:
                j = i - 1
                while j - 2 >= 0 and toks[j].token_type == TT.DOT and \
                        toks[j - 1].token_type in name_types:
                    j -= 2
                prev = toks[j].token_type if j >= 0 else None
            nxt_dot = i + 1 < len(toks) and toks[i + 1].token_type == TT.DOT
            if prev in (TT.FROM, TT.JOIN, TT.COMMA) and not nxt_dot:
                end_name = tk.end
                # an existing clause right after
                k = i + 1
                if k < len(toks) and toks[k].token_type == TT.FOR and \
                        k + 3 < len(toks) and toks[k + 2].text.lower() == "as" and \
                        toks[k + 3].text.lower() == "of":
                    v = k + 4
                    if v < len(toks) and toks[v].token_type == TT.DASH:
                        v += 1
                    if v < len(toks) and toks[v].token_type != TT.STRING and \
                            toks[v].text.lower() in ("timestamp", "timestamptz"):
                        v += 1
                    clause_end = toks[min(v, len(toks) - 1)].end
                    edits.append((end_name + 1, clause_end, clause))
                elif clause:
                    edits.append((end_name + 1, end_name, clause))
        i += 1
    for s, e, text in sorted(edits, key=lambda x: x[0], reverse=True):
        sql = sql[:s] + text + sql[e + 1:]
    return sql


def iceberg_tables_in_sql(sql: str, iceberg_names: List[str]) -> List[Dict[str, Any]]:
    """The registered Iceberg tables ``sql`` reads in table position, in
    order of first appearance, each with the version written for it
    (``snapshot_id`` / ``as_of_ms`` or None = latest)."""
    names = {n.lower(): n for n in iceberg_names}
    rw = rewrite_version_clauses(sql, iceberg_tables=names)
    pins = {p.table: p for p in rw.pins}
    seen: List[str] = []
    try:
        import sqlglot
        from sqlglot import exp
        for tree in sqlglot.parse(rw.sql, read="duckdb"):
            if tree is None:
                continue
            for tb in tree.find_all(exp.Table):
                n = (tb.name or "").lower()
                base = n.split("@", 1)[0]
                if base in names and base not in seen:
                    seen.append(base)
    except Exception:                                           # noqa: BLE001
        pass
    return [{"table": names[n],
             "snapshot_id": (str(pins[n].snapshot_id) if n in pins and pins[n].snapshot_id is not None else None),
             "as_of_ms": (pins[n].as_of_ms if n in pins else None)}
            for n in seen]
