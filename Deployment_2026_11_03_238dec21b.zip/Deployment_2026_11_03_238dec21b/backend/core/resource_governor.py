"""Resource Governor — per-query memory on MEASURED truth (2026-08-02).

THE THESIS
----------
Trino's hardest subsystem is per-query memory ACCOUNTING: every query
shares one JVM, so Trino must instrument every operator allocation to
*approximate* what each query uses, then run a low-memory killer on those
estimates.  QueryStudio runs ONE OS PROCESS PER QUERY (legacy Popen, warm
pool worker, forkserver fork — all processes), so per-query memory is
**exactly measurable** with psutil: no instrumentation, no estimation
error.  This module exploits that structural advantage.

Goal: convert "the kernel decides who dies — and on cgroup v2 with
``memory.oom.group=1`` it kills the WHOLE pod tree (every query + the
API)" into "we decide, we act on exactly one query, and we tell the user
why".

WHAT LIVES HERE
---------------
1. **Child registry** — every live DuckDB child process, tolerant of all
   three spawn paths.  Reaped by LIVENESS (``psutil.Process.is_running``
   pins the create-time, so pid reuse can never resurrect a stale entry);
   callers are *invited* to deregister but never trusted to.
2. **Sampler** — one daemon thread, ~1 Hz, records per-execution RSS +
   peak RSS.  One instrument, three consumers: the pressure ladder,
   passport actuals (HBO feedstock), operator telemetry
   (:func:`governor_status`).
3. **Graduated pressure ladder** (the Trino low-memory-killer analogue,
   plus a rung Trino's architecture forbids):

       Tier 0  OBSERVE   log the decision it WOULD take (default mode)
       Tier 1  SUSPEND   SIGSTOP the victim briefly so its siblings can
                         finish and release memory — **no work lost**.
                         Trino cannot do this: its "query" is threads
                         inside a shared JVM.
       Tier 2  KILL      exactly one victim, with a user-facing verdict,
                         via the existing ``_kill_subprocess_tree``
                         (spill files + S3 sockets cleaned, not orphaned).

   SUSPENSION JUDGEMENT (the honest version).  SIGSTOP is memory-safe
   (the process keeps its pages, fds, spill files; SIGCONT resumes with
   zero loss) and psutil's suspend/resume works on Windows too.  The real
   risks are *time-shaped*: a paused child still burns its wall-clock
   ``timeout`` budget; its idle S3 sockets can be reset by the peer; a
   presigned URL can expire mid-pause.  All three are bounded by keeping
   the pause SHORT (default 10 s, hard-capped, one suspendee at a time,
   dead-man's-switch resume timer at 2× the window) — and every one of
   those failure modes is *strictly better than the alternative rung*,
   which is killing the query outright.  What was REJECTED: lowering a
   child's DuckDB ``memory_limit`` mid-flight — there is no control
   channel into a running child (it executes one COPY; stdin is not a
   SQL console), and building one for this would add an IPC surface to
   the hot path for a lever the suspend rung already covers.
4. **Passport write-through** — the sampler's measured peak lands in
   ``PassportActuals.peak_memory_bytes`` (nothing else writes it) and in
   an in-process per-``plan_hash`` corpus, so a later admission layer can
   ask "what did THIS plan actually peak at last time" and get a real
   measured answer — Trino's HBO needs deliberate instrumentation to
   approximate what falls out of our sampler for free.

VICTIM POLICY — reward honesty
------------------------------
Ordered tiers, most-deserving first (one victim per evaluation, always):

  1. **Largest overage above its own declared ceiling** (``rss −
     memory_limit_bytes``).  The query that blew past what it promised is
     the misbehaving one — DuckDB's unspillable allocations (per-column
     vector buffers, parquet writer state) can exceed ``memory_limit``,
     and that excess is exactly what the divisor arithmetic never
     promised the pod.  A query that declared honestly and stayed under
     its ceiling should be SAFER than one that lied.
  2. **Largest RSS among children that declared nothing** — they promised
     nothing, so they enjoy no promise-keeping protection.
  3. **Largest absolute RSS** (everyone declared and is compliant, i.e.
     the pressure is the aggregate of honest queries).  Frees the most
     memory per kill, so one kill is most likely to end the episode.
     This is also Trino's default policy — precedent for the fallback.

  Rejected: *youngest-first* (minimises lost work per kill but frees the
  least memory → serial kills of many small queries while the whale
  survives, and it makes new queries die for an incumbent hog's sins).

SAFETY CONTRACT (non-negotiable)
--------------------------------
* OFF by default (``resource_governor.enabled`` = false).
* ``mode: observe`` (default) logs verdicts, kills/suspends NOTHING.
* Never acts below the threshold; never kills the only running query
  (that just moves the failure); never more than one victim per
  evaluation; never twice within the cooldown; never touches
  ``kind="system"`` children; requires a REAL cgroup limit (no psutil
  fallback for the LIMIT — off-cgroup, "used/total" counts the whole
  box, same rationale as the BF-558c pressure gate).
* The kill threshold (default 0.95) sits ABOVE the BF-558c admission
  pressure gate (0.90), so back-pressure always gets first chance.
* Fail-open EVERYWHERE: every public function never raises; any internal
  error leaves the system exactly as it is today.
* No new infrastructure: psutil is already a dependency.
"""
from __future__ import annotations

import logging
import subprocess  # noqa: F401  (documented spawn-path type; not used directly)
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_MB = 1024 * 1024

KIND_QUERY = "query"
KIND_SYSTEM = "system"          # health / cleanup / non-query work: NEVER a victim

# ── configuration (read per-call, never snapshotted — config.reload works) ──

_CFG_SECTION = "resource_governor"

_CFG_DEFAULTS: Dict[str, Any] = {
    "enabled": False,             # master switch — the whole module is inert OFF
    "mode": "observe",            # "observe" (log only) | "enforce"
    "sample_interval_seconds": 1.0,
    "kill_threshold": 0.95,       # fraction of cgroup limit; > BF-558c gate (0.90)
    "hard_kill_threshold": 0.98,  # skip the suspend rung — kernel OOM is imminent
    "sustained_samples": 3,       # consecutive over-threshold samples before acting
    "kill_cooldown_seconds": 30.0,
    "suspend_enabled": True,      # Tier 1 rung (still gated by enabled+mode)
    "max_suspend_seconds": 10.0,  # bounded pause — see SUSPENSION JUDGEMENT above
    "suspend_cooldown_seconds": 15.0,
    "min_child_age_seconds": 2.0,  # a just-started child has nothing to reclaim
}


def _cfg(key: str) -> Any:
    """One config value, fail-open to the module default.  Never raises."""
    try:
        from core.config import get as _get
        val = _get(_CFG_SECTION, key, _CFG_DEFAULTS[key])
        return _CFG_DEFAULTS[key] if val is None else val
    except Exception as exc:
        logger.debug("[resource-governor] config read %s failed (default): %s",
                     key, exc)
        return _CFG_DEFAULTS[key]


def is_enabled() -> bool:
    """Master switch.  Default False — the repo pattern for anything risky."""
    try:
        return bool(_cfg("enabled"))
    except Exception:                                            # pragma: no cover
        return False


def samples_for_query_pods() -> bool:
    """2026-10-31 -- a QUERY POD measures its runs' peak memory even with the
    governor off: the budget's next price is calibrated from that peak
    (``PassportActuals.peak_memory_bytes``, ``query_jobs.actual_peak_bytes``).
    Sampling ONLY -- the pressure ladder stays behind ``enabled``: here a run
    is held by its own DuckDB memory_limit (its reservation), so nothing
    needs killing.  True when this process serves a configured size."""
    try:
        from core.query_pods import budget as _budget
        return bool(_budget.pod_class_from_env()) and _budget.pricing_enabled()
    except Exception:
        return False


def is_enforcing() -> bool:
    """True only when the operator explicitly opted into ``mode: enforce``.
    Anything else — including typos — is observe-only (fail toward safe)."""
    try:
        return str(_cfg("mode") or "").strip().lower() == "enforce"
    except Exception:                                            # pragma: no cover
        return False


# ── default pod-memory probes (test-injectable) ─────────────────────────────


def _default_pod_usage_bytes() -> Optional[int]:
    """WORKING SET of the pod (reclaimable page cache already subtracted —
    see BF-558f in duckdb_resource_limits).  None = unknown = never act."""
    from core.duckdb_resource_limits import read_pod_memory_usage_bytes
    return read_pod_memory_usage_bytes()


def _default_pod_limit_bytes() -> Optional[int]:
    """cgroup limit ONLY — deliberately no psutil fallback (off-cgroup the
    'limit' would be the whole box and the governor would kill queries
    because a browser is open).  The cgroup limit is also exactly what the
    kernel OOM-killer watches, which is the only thing this exists to
    pre-empt."""
    from core.duckdb_resource_limits import _read_cgroup_memory_limit_bytes
    return _read_cgroup_memory_limit_bytes()


# ── child record ────────────────────────────────────────────────────────────


@dataclass
class ChildRecord:
    """One live DuckDB child process under governance."""
    pid: int
    execution_id: str = ""
    username: str = ""
    kind: str = KIND_QUERY
    memory_limit_bytes: int = 0     # the ceiling this child DECLARED (0 = unknown)
    n_columns: int = 0
    plan_hash: str = ""
    started_at: float = field(default_factory=time.monotonic)
    popen: Any = None               # Popen / _Worker.proc / ForkedChildHandle
    psproc: Any = None              # psutil.Process pinned at register time
    # Whether this child leads its OWN process group / job (legacy Popen
    # spawns with start_new_session / CREATE_NEW_PROCESS_GROUP; forkserver
    # children setsid()).  Warm-pool workers do NOT — they share the API
    # pod's group, so ``_kill_subprocess_tree``'s ``os.killpg`` would
    # signal the WHOLE POD.  Default False = the safe (per-pid) kill path.
    own_process_group: bool = False
    # Passport dict captured (by reference) at REGISTRATION time.  The
    # jobqueue bridge pops the registry entry MID-FLIGHT (first poll after
    # the reader registers it), i.e. usually before the child exits — so
    # an exit-time peek would miss on the queue path.  Registration happens
    # after plan time, so the entry is still there to capture here.
    passport_ref: Any = None
    last_rss: int = 0
    peak_rss: int = 0
    samples: int = 0
    suspended_at: float = 0.0       # monotonic; 0 = not suspended
    # monotonic; 0 = never signalled.  A killed child is DYING, not running:
    # until it is reaped it still has a record (and, on POSIX, a pid), and
    # counting it made "never kill the only running query" see two queries
    # when one was left -- so the next cycle killed the survivor (2026-09-25,
    # found in the CI image; the 30 s default cooldown usually hid it).
    killed_at: float = 0.0

    def age_s(self) -> float:
        return time.monotonic() - self.started_at

    def overage_bytes(self) -> int:
        """How far above its OWN declared ceiling this child is (0 when it
        declared nothing or is compliant)."""
        if self.memory_limit_bytes > 0 and self.last_rss > self.memory_limit_bytes:
            return self.last_rss - self.memory_limit_bytes
        return 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pid": self.pid,
            "execution_id": self.execution_id,
            "username": self.username,
            "kind": self.kind,
            "memory_limit_bytes": self.memory_limit_bytes,
            "n_columns": self.n_columns,
            "plan_hash": self.plan_hash,
            "age_s": round(self.age_s(), 1),
            "last_rss": self.last_rss,
            "peak_rss": self.peak_rss,
            "samples": self.samples,
            "suspended": self.suspended_at > 0,
        }


class _PsProcAdapter:
    """Minimal Popen-shaped shim over a psutil.Process so the existing
    ``_kill_subprocess_tree`` machinery (which expects ``.pid`` /
    ``.poll()`` / ``.send_signal()`` / ``.kill()``) can be reused when the
    registrar only knew a pid."""

    def __init__(self, ps: Any) -> None:
        self._ps = ps
        self.pid = ps.pid

    def poll(self) -> Optional[int]:
        try:
            return None if self._ps.is_running() else 0
        except Exception:                                        # pragma: no cover
            return 0

    def send_signal(self, sig: int) -> None:
        self._ps.send_signal(sig)

    def kill(self) -> None:
        self._ps.kill()


# ── the governor ────────────────────────────────────────────────────────────


class ResourceGovernor:
    """Singleton (via :func:`get_governor`).  All public module functions
    delegate here inside never-raise wrappers."""

    _KILL_GRACE_S = 5.0            # SIGTERM → SIGKILL escalation window
    _MAX_KILL_NOTES = 64           # bounded FIFO of pid/exec → verdict text
    _RESUME_HYSTERESIS = 0.05      # resume when ratio <= kill_threshold − this
    # ── stranded-suspend contract (audit 2026-08-02) ──
    # A SIGSTOPped child holds its memory, spill files, S3 sockets and slot
    # while making no progress — limbo is the one forbidden outcome.  Every
    # resume is VERIFIED; a failed resume preserves the suspension state and
    # re-arms a retry; after _MAX_RESUME_ATTEMPTS the child is deliberately
    # KILLED (with a user-facing verdict) rather than left suspended.
    _MAX_RESUME_ATTEMPTS = 4       # failed resumes before deliberate kill
    _RESUME_RETRY_S = 2.0          # base retry-timer delay after a failure
    _RESUME_MIN_GAP_S = 0.75       # rate-limit concurrent repair callers
    _RESUME_RETRY_MAX_S = 30.0     # retry-delay growth cap

    def __init__(self,
                 usage_fn: Optional[Callable[[], Optional[int]]] = None,
                 limit_fn: Optional[Callable[[], Optional[int]]] = None) -> None:
        self._lock = threading.RLock()
        self._children: Dict[int, ChildRecord] = {}
        self._kill_notes: Dict[Any, str] = {}
        self._usage_fn = usage_fn or _default_pod_usage_bytes
        self._limit_fn = limit_fn or _default_pod_limit_bytes
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._autostart = True          # tests flip off for deterministic cycles
        self._announced = False
        # ladder state
        self._sustained = 0
        self._last_kill_at = 0.0
        self._last_suspend_end = 0.0
        self._suspend_tried_since_relief = False
        self._suspended_pid = 0
        # Durable suspension ledger (audit 2026-08-02): pid → repair state.
        # Written BEFORE the SIGSTOP is sent (write-ahead) and removed only
        # once the child is VERIFIED resumed / dead / gone — so a stranded
        # child is always discoverable by the timers and the loop sweep,
        # even if ChildRecord bookkeeping was lost or corrupted.
        self._suspend_ledger: Dict[int, Dict[str, Any]] = {}
        self._suspend_gen = 0          # per-suspension token for stale timers
        # evidence + HBO corpus
        self._decisions: deque = deque(maxlen=200)     # observe-mode audit trail
        self._finished: deque = deque(maxlen=200)      # per-execution peak history
        self._plan_peaks: Dict[str, deque] = {}        # plan_hash → recent peaks
        self._counters = {"kills": 0, "suspends": 0, "resumes": 0,
                          "would_kill": 0, "would_suspend": 0, "reaped": 0,
                          "resume_failures": 0, "stranded_kills": 0}

    # ── registration ───────────────────────────────────────────────────

    def register(self, pid: int, *, execution_id: str = "", username: str = "",
                 kind: str = KIND_QUERY, memory_limit_bytes: int = 0,
                 n_columns: int = 0, plan_hash: str = "",
                 popen: Any = None, own_process_group: bool = False,
                 spawn_env: Optional[Dict[str, str]] = None) -> Optional[ChildRecord]:
        """Track a live child.  Cheap: one psutil.Process construction
        (pins create_time → pid-reuse-proof liveness).  A duplicate pid
        finalizes the old record first (warm-pool worker serving its next
        request)."""
        try:
            pid = int(pid)
        except (TypeError, ValueError):
            return None
        if pid <= 0:
            return None
        try:
            import psutil
            ps = psutil.Process(pid)
        except Exception as exc:
            logger.debug("[resource-governor] register pid=%s skipped "
                         "(process not observable): %s", pid, exc)
            return None
        if memory_limit_bytes <= 0 and spawn_env is not None:
            memory_limit_bytes = declared_limit_bytes_from_env(spawn_env)
        rec = ChildRecord(
            pid=pid, execution_id=str(execution_id or ""),
            username=str(username or ""), kind=str(kind or KIND_QUERY),
            memory_limit_bytes=max(0, int(memory_limit_bytes or 0)),
            n_columns=max(0, int(n_columns or 0)),
            plan_hash=str(plan_hash or ""), popen=popen, psproc=ps,
            own_process_group=bool(own_process_group),
        )
        if rec.execution_id and rec.kind == KIND_QUERY:
            try:
                from core.industrialization import passport_registry
                p = passport_registry.peek(rec.execution_id)
                if isinstance(p, dict):
                    rec.passport_ref = p
                    if not rec.plan_hash:
                        rec.plan_hash = str(p.get("plan_hash") or "")
            except Exception as exc:
                logger.debug("[resource-governor] passport capture failed "
                             "(fail-open) exec=%s: %s", rec.execution_id, exc)
        with self._lock:
            old = self._children.pop(pid, None)
            if old is not None:
                self._finalize_locked(old, reason="re-register")
            self._children[pid] = rec
        self._announce_once()
        self._ensure_thread()
        return rec

    def deregister(self, pid: int) -> None:
        """Caller-driven removal (normal completion path).  Finalizes the
        record → passport / plan-corpus write-through."""
        try:
            pid = int(pid)
        except (TypeError, ValueError):
            return
        with self._lock:
            rec = self._children.pop(pid, None)
            if rec is not None:
                self._finalize_locked(rec, reason="deregister")

    def _announce_once(self) -> None:
        if self._announced:
            return
        self._announced = True
        if not is_enabled():
            logger.info("[resource-governor] measuring only: this query pod "
                        "records each run's peak memory for the next price "
                        "(the pressure ladder is off -- resource_governor.enabled)")
            return
        logger.info(
            "[resource-governor] active: mode=%s interval=%.1fs "
            "kill_threshold=%.2f hard=%.2f suspend=%s (governor decides who "
            "dies — measured RSS, not estimates)",
            "enforce" if is_enforcing() else "observe",
            float(_cfg("sample_interval_seconds")),
            float(_cfg("kill_threshold")), float(_cfg("hard_kill_threshold")),
            bool(_cfg("suspend_enabled")),
        )

    # ── sampler thread ─────────────────────────────────────────────────

    def _ensure_thread(self) -> None:
        if not self._autostart:
            return
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = threading.Thread(
                target=self._loop, name="resource-governor", daemon=True)
            self._thread.start()

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                interval = max(0.1, float(_cfg("sample_interval_seconds")))
            except Exception:                                    # pragma: no cover
                interval = 1.0
            try:
                if is_enabled():
                    self.run_cycle()
                else:
                    # Disabled mid-flight: the ONE thing that must not
                    # linger is a suspended child.
                    self._resume_suspended("governor disabled")
                    self._sweep_suspend_ledger()
                    # 2026-10-31: a query pod still MEASURES (sample only,
                    # no ladder) -- its budget's next price needs the peak.
                    if samples_for_query_pods():
                        self._sample_all()
            except Exception as exc:
                logger.debug("[resource-governor] cycle failed (fail-open): %s",
                             exc)
            self._stop.wait(interval)

    def run_cycle(self) -> None:
        """One sample + one evaluation.  Called by the thread; callable
        directly by tests for deterministic stepping."""
        self._sample_all()
        self._evaluate()
        self._sweep_suspend_ledger()

    # ── sampling ───────────────────────────────────────────────────────

    @staticmethod
    def _tree_rss(psproc: Any, kids_by_ppid: Dict[int, List[Any]]) -> int:
        """RSS of the registered process AND its descendants.

        2026-08-12 -- the registered pid is not always the process holding
        the memory.  A launcher that re-execs leaves the registered pid at a
        few MB while the engine allocates in a child (observed on a Windows
        venv whose ``Scripts/python.exe`` re-execs the interpreter as a
        grandchild: registered pid 4.0 MB, real allocator 160.6 MB).  The
        governor's entire premise is MEASURED truth, and a governor that
        under-measures never fires.

        Identical to the old single-pid number whenever the child has no
        descendants -- which is every spawn path in the tree today -- so this
        widens correctness without changing behaviour.
        """
        total = int(psproc.memory_info().rss)
        if not kids_by_ppid:
            return total
        stack = [psproc.pid]
        seen = {psproc.pid}
        while stack:
            for kid in kids_by_ppid.get(stack.pop(), ()):
                if kid.pid in seen:
                    continue          # cycle guard: pid reuse mid-walk
                seen.add(kid.pid)
                try:
                    total += int(kid.memory_info().rss)
                except Exception:
                    continue          # died mid-walk -- normal race
                stack.append(kid.pid)
        return total

    def _sample_all(self) -> None:
        """Sample RSS for every registered child; reap the dead.  A pid
        disappearing mid-sample is a NORMAL race, not an error."""
        with self._lock:
            recs = list(self._children.values())

        # ONE pass over the process table per cycle.  psutil's
        # Process.children(recursive=True) re-enumerates every pid on the
        # system, so calling it per registered child would make sampling
        # O(processes x children) on the governor's hot loop.
        kids_by_ppid: Dict[int, List[Any]] = {}
        if recs:
            try:
                import psutil
                for proc in psutil.process_iter(["pid", "ppid"]):
                    try:
                        kids_by_ppid.setdefault(
                            proc.info["ppid"], []).append(proc)
                    except Exception:
                        continue
            except Exception as exc:
                # Fail-open: fall back to single-pid sampling, which is what
                # this did before.  Never let the probe break the governor.
                logger.debug("[resource-governor] process-table scan "
                             "unavailable, sampling single pids: %s", exc)
                kids_by_ppid = {}

        dead: List[ChildRecord] = []
        for rec in recs:
            alive = True
            try:
                if rec.popen is not None and rec.popen.poll() is not None:
                    alive = False
                elif rec.psproc is not None and not rec.psproc.is_running():
                    alive = False        # includes pid-reuse (create_time differs)
            except Exception as exc:
                logger.debug("[resource-governor] liveness probe pid=%s: %s",
                             rec.pid, exc)
                alive = False
            if not alive:
                dead.append(rec)
                continue
            try:
                rss = self._tree_rss(rec.psproc, kids_by_ppid)
            except Exception as exc:
                # NoSuchProcess → died between checks; AccessDenied → skip.
                logger.debug("[resource-governor] sample pid=%s skipped: %s",
                             rec.pid, exc)
                continue
            rec.last_rss = rss
            if rss > rec.peak_rss:
                rec.peak_rss = rss
            rec.samples += 1
        if dead:
            with self._lock:
                for rec in dead:
                    if self._children.pop(rec.pid, None) is not None:
                        self._counters["reaped"] += 1
                        self._finalize_locked(rec, reason="reaped")

    # ── finalization → passport + plan corpus ──────────────────────────

    def _finalize_locked(self, rec: ChildRecord, *, reason: str) -> None:
        """Write-through of the measured peak.  Caller holds the lock (the
        passport-registry lock is a leaf — no inversion)."""
        if rec.pid == self._suspended_pid or rec.pid in self._suspend_ledger:
            # Never let a suspended child vanish while stopped.
            self._resume_record(rec, reason=f"finalize:{reason}")
        if rec.kind != KIND_QUERY or rec.peak_rss <= 0:
            return
        plan_hash = rec.plan_hash
        try:
            p = rec.passport_ref
            if p is None and rec.execution_id:
                # Non-queue path: the registry entry is never popped, so an
                # exit-time peek still finds it.
                from core.industrialization import passport_registry
                p = passport_registry.peek(rec.execution_id)
            if isinstance(p, dict):
                if not plan_hash:
                    plan_hash = str(p.get("plan_hash") or "")
                actuals = p.get("actuals")
                if not isinstance(actuals, dict):
                    actuals = {}
                prev = int(actuals.get("peak_memory_bytes") or 0)
                actuals["peak_memory_bytes"] = max(prev, rec.peak_rss)
                p["actuals"] = actuals
        except Exception as exc:
            logger.debug("[resource-governor] passport stamp failed "
                         "(fail-open) exec=%s: %s", rec.execution_id, exc)
        if plan_hash:
            dq = self._plan_peaks.get(plan_hash)
            if dq is None:
                dq = deque(maxlen=16)
                self._plan_peaks[plan_hash] = dq
                # bound the corpus (FIFO on plans)
                while len(self._plan_peaks) > 512:
                    self._plan_peaks.pop(next(iter(self._plan_peaks)), None)
            dq.append(rec.peak_rss)
        self._finished.append({
            "execution_id": rec.execution_id, "pid": rec.pid,
            "peak_rss": rec.peak_rss, "samples": rec.samples,
            "declared_limit": rec.memory_limit_bytes,
            "plan_hash": plan_hash, "reason": reason,
            "ended_at": time.time(),
        })

    # ── the graduated pressure ladder ──────────────────────────────────

    def _evaluate(self) -> None:
        now = time.monotonic()
        try:
            usage = self._usage_fn()
            limit = self._limit_fn()
        except Exception as exc:
            logger.debug("[resource-governor] pod memory probe failed "
                         "(fail-open): %s", exc)
            self._resume_suspended("memory probe failed")
            return
        if not usage or not limit or limit <= 0:
            # Unknown pressure → never act; and never hold a pause blind.
            self._resume_suspended("pod memory unknown")
            return
        ratio = float(usage) / float(limit)
        try:
            kill_th = float(_cfg("kill_threshold"))
        except Exception:                                        # pragma: no cover
            kill_th = 0.95
        if kill_th <= 0.0 or kill_th >= 1.0:
            self._resume_suspended("killer disabled by config")
            return
        resume_th = max(0.0, kill_th - self._RESUME_HYSTERESIS)

        # 1) manage any in-flight suspension first (resume beats escalate)
        self._maybe_resume(now, ratio, resume_th)

        # 2) below threshold → relief bookkeeping, nothing else
        if ratio < kill_th:
            self._sustained = 0
            if ratio <= resume_th:
                self._suspend_tried_since_relief = False
            return

        # 3) hysteresis: demand sustained pressure, not a spike
        self._sustained += 1
        try:
            need = max(1, int(_cfg("sustained_samples")))
        except Exception:                                        # pragma: no cover
            need = 3
        if self._sustained < need:
            return

        # 4) pick candidates: live, sampled, old-enough QUERY children only
        try:
            min_age = float(_cfg("min_child_age_seconds"))
        except Exception:                                        # pragma: no cover
            min_age = 2.0
        with self._lock:
            candidates = [
                r for r in self._children.values()
                if r.kind == KIND_QUERY and r.samples > 0
                and r.age_s() >= min_age and not r.killed_at
            ]
        if len(candidates) < 2:
            # Killing the only query just moves the failure — it cannot
            # free memory anyone else is waiting for.
            self._record_decision("hold_single_query", None, ratio, usage, limit)
            return

        victim = self._select_victim(candidates)
        if victim is None:                                       # pragma: no cover
            return

        try:
            hard_th = float(_cfg("hard_kill_threshold"))
        except Exception:                                        # pragma: no cover
            hard_th = 0.98

        # 5) the ladder
        if ratio < hard_th and self._can_suspend(now):
            self._do_suspend(victim, ratio, usage, limit, now)
            return
        if self._suspended_pid and ratio < hard_th:
            return          # a pause is in flight — give it its window
        try:
            cooldown = float(_cfg("kill_cooldown_seconds"))
        except Exception:                                        # pragma: no cover
            cooldown = 30.0
        if (now - self._last_kill_at) < cooldown:
            return          # never kill repeatedly within the cooldown
        self._do_kill(victim, ratio, usage, limit, now)

    def _can_suspend(self, now: float) -> bool:
        try:
            if not bool(_cfg("suspend_enabled")):
                return False
            if self._suspended_pid or self._suspend_tried_since_relief:
                return False
            with self._lock:
                if self._suspend_ledger:
                    # An earlier suspension is not yet VERIFIED resolved —
                    # never stack a second stopped child on top of it.
                    return False
            cool = float(_cfg("suspend_cooldown_seconds"))
            return (now - self._last_suspend_end) >= cool
        except Exception as exc:                                 # pragma: no cover
            logger.debug("[resource-governor] suspend gate failed: %s", exc)
            return False

    # ── victim selection (reward honesty) ──────────────────────────────

    @staticmethod
    def _select_victim(candidates: List[ChildRecord]) -> Optional[ChildRecord]:
        if not candidates:
            return None
        # Tier 1: biggest promise-breaker (largest RSS over its OWN ceiling).
        overs = [r for r in candidates if r.overage_bytes() > 0]
        if overs:
            return max(overs, key=lambda r: r.overage_bytes())
        # Tier 2: largest undeclared (promised nothing → no protection).
        undeclared = [r for r in candidates if r.memory_limit_bytes <= 0]
        if undeclared:
            return max(undeclared, key=lambda r: r.last_rss)
        # Tier 3: everyone honest & compliant → largest RSS frees the most
        # per kill (one victim most likely ends the episode; Trino default).
        return max(candidates, key=lambda r: r.last_rss)

    # ── Tier 1: suspend / resume ───────────────────────────────────────

    def _do_suspend(self, rec: ChildRecord, ratio: float, usage: int,
                    limit: int, now: float) -> None:
        if not is_enforcing():
            self._counters["would_suspend"] += 1
            # Progress the ladder in observe mode too, so the audit trail
            # shows the exact sequence enforce mode would have taken.
            self._suspend_tried_since_relief = True
            self._last_suspend_end = now
            self._record_decision("would_suspend", rec, ratio, usage, limit)
            logger.warning(
                "[resource-governor] WOULD SUSPEND pid=%s exec=%s rss=%dMB "
                "(pod %.0f%% of %dMB limit) — observe mode, nothing done",
                rec.pid, rec.execution_id or "?", rec.last_rss // _MB,
                ratio * 100, limit // _MB)
            return
        try:
            max_s = float(_cfg("max_suspend_seconds"))
        except Exception:                                        # pragma: no cover
            max_s = 10.0
        # WRITE-AHEAD bookkeeping (audit 2026-08-02): the durable ledger
        # entry, the suspension markers AND the dead-man timer are all in
        # place BEFORE the SIGSTOP is sent.  Order matters:
        #   * bookkeeping-after-suspend + an exception in between = a
        #     stopped child nobody remembers → stranded forever (the
        #     audit's proven failure).
        #   * bookkeeping-before-suspend + suspend fails = a "suspended"
        #     record for a running child; rolled back below — and even an
        #     un-rolled-back spurious resume (SIGCONT to a running
        #     process) is harmless.
        with self._lock:
            self._suspend_gen += 1
            gen = self._suspend_gen
            self._suspend_ledger[rec.pid] = {
                "psproc": rec.psproc,
                "execution_id": rec.execution_id,
                "suspended_at_mono": now,
                "deadline_mono": now + 2.0 * max_s,
                "attempts": 0,
                "gen": gen,
            }
        rec.suspended_at = now
        self._suspended_pid = rec.pid
        self._suspend_tried_since_relief = True
        # Dead-man's switch: even if the governor thread dies, the child
        # must NEVER stay stopped.
        self._arm_suspend_safety_timer(rec.pid, 2.0 * max_s, gen)
        try:
            rec.psproc.suspend()
        except Exception as exc:
            logger.warning("[resource-governor] suspend pid=%s failed "
                           "(skipping rung): %s", rec.pid, exc)
            # Roll back the write-ahead record — nothing was stopped.
            with self._lock:
                self._suspend_ledger.pop(rec.pid, None)
            rec.suspended_at = 0.0
            if self._suspended_pid == rec.pid:
                self._suspended_pid = 0
            return
        self._counters["suspends"] += 1
        self._record_decision("suspend", rec, ratio, usage, limit)
        logger.warning(
            "[resource-governor] SUSPENDED pid=%s exec=%s rss=%dMB for up to "
            "%.0fs (pod %.0f%% of %dMB) — letting siblings drain; no work lost",
            rec.pid, rec.execution_id or "?", rec.last_rss // _MB,
            max_s, ratio * 100, limit // _MB)

    def _maybe_resume(self, now: float, ratio: Optional[float],
                      resume_th: float) -> None:
        if not self._suspended_pid:
            return
        with self._lock:
            rec = self._children.get(self._suspended_pid)
        if rec is None or rec.suspended_at <= 0:
            # Record vanished or its marker was cleared — resolve through
            # the durable ledger instead of just forgetting the pid (a
            # possibly-stopped child must never be forgotten).
            self._resolve_suspension(self._suspended_pid,
                                     reason="suspension record vanished")
            return
        try:
            max_s = float(_cfg("max_suspend_seconds"))
        except Exception:                                        # pragma: no cover
            max_s = 10.0
        with self._lock:
            live_queries = sum(1 for r in self._children.values()
                               if r.kind == KIND_QUERY)
        reason = None
        if ratio is not None and ratio <= resume_th:
            reason = f"pressure relieved ({ratio:.0%})"
        elif (now - rec.suspended_at) >= max_s:
            reason = f"pause window expired ({max_s:.0f}s)"
        elif live_queries <= 1:
            reason = "only query left — it must make progress"
        if reason:
            self._resume_record(rec, reason=reason)

    def _resume_record(self, rec: ChildRecord, *, reason: str) -> None:
        """Resume ``rec`` via the verified resume-or-kill state machine."""
        self._resolve_suspension(rec.pid, reason=reason, rec=rec)

    def _resolve_suspension(self, pid: int, *, reason: str,
                            rec: Optional[ChildRecord] = None) -> bool:
        """Verified resume-or-kill state machine (audit 2026-08-02).

        Returns True only when the pid is VERIFIED no longer suspended —
        actually running again, dead, or gone.  On failure every piece of
        suspension state is PRESERVED (never cleared on hope: clearing
        state after a failed resume is exactly what disarmed the old
        dead-man switch) and a retry timer is re-armed.  After
        ``_MAX_RESUME_ATTEMPTS`` failures the child is deliberately KILLED
        with a user-facing verdict: a stopped process that cannot be
        resumed holds its memory, spill files and S3 sockets while making
        no progress, which is strictly worse than losing the one query.
        Never raises."""
        try:
            now_m = time.monotonic()
            with self._lock:
                entry = self._suspend_ledger.get(pid)
                if rec is None:
                    rec = self._children.get(pid)
                if entry is not None:
                    # Rate-limit concurrent repair callers (loop + timers):
                    # a retry timer is armed after every failed attempt, so
                    # skipping here never orphans the entry.
                    last = float(entry.get("last_attempt_mono", -1.0e12))
                    if (now_m - last) < self._RESUME_MIN_GAP_S:
                        return False
                    entry["last_attempt_mono"] = now_m
            was_suspended = (entry is not None
                             or (rec is not None and rec.suspended_at > 0))
            if not was_suspended:
                if self._suspended_pid == pid:
                    self._suspended_pid = 0
                return True
            psproc = entry.get("psproc") if entry is not None else None
            if psproc is None and rec is not None:
                psproc = rec.psproc

            outcome = self._attempt_resume_verified(psproc, pid)
            if outcome in ("resumed", "gone"):
                with self._lock:
                    self._suspend_ledger.pop(pid, None)
                if rec is not None:
                    rec.suspended_at = 0.0
                if self._suspended_pid == pid:
                    self._suspended_pid = 0
                self._last_suspend_end = time.monotonic()
                exec_id = (rec.execution_id if rec is not None
                           else str((entry or {}).get("execution_id") or ""))
                if outcome == "resumed":
                    self._counters["resumes"] += 1
                    logger.warning("[resource-governor] RESUMED pid=%s "
                                   "exec=%s (%s)", pid, exec_id or "?", reason)
                else:
                    logger.info("[resource-governor] suspended pid=%s exec=%s "
                                "is gone (%s) — suspension resolved",
                                pid, exec_id or "?", reason)
                return True

            # NOT resumed — the child is still STOPPED.  Preserve the
            # suspension state, record the failure durably, retry, and
            # escalate to a deliberate kill rather than leave it in limbo.
            with self._lock:
                entry = self._suspend_ledger.get(pid)
                if entry is None:
                    # Marker existed only on the record (legacy/degraded
                    # state) — durably re-ledger it so repair can find it.
                    entry = {"psproc": psproc,
                             "execution_id": (rec.execution_id if rec else ""),
                             "suspended_at_mono": now_m,
                             "deadline_mono": now_m,
                             "attempts": 0,
                             "gen": self._suspend_gen,
                             "last_attempt_mono": now_m}
                    self._suspend_ledger[pid] = entry
                entry["attempts"] = int(entry.get("attempts", 0)) + 1
                attempts = entry["attempts"]
                gen = int(entry.get("gen", 0))
            self._counters["resume_failures"] += 1
            if attempts >= self._MAX_RESUME_ATTEMPTS:
                self._kill_stranded(pid, rec, psproc,
                                    exec_id=str((entry or {}).get(
                                        "execution_id") or ""),
                                    attempts=attempts)
            else:
                logger.warning(
                    "[resource-governor] resume pid=%s FAILED "
                    "(attempt %d/%d, %s) — child is still SUSPENDED; "
                    "retrying, will kill rather than strand it",
                    pid, attempts, self._MAX_RESUME_ATTEMPTS, reason)
            delay = min(self._RESUME_RETRY_MAX_S,
                        self._RESUME_RETRY_S * max(1, attempts))
            self._arm_suspend_safety_timer(pid, delay, gen)
            return False
        except Exception as exc:                                 # pragma: no cover
            logger.debug("[resource-governor] resolve-suspension pid=%s "
                         "failed: %s", pid, exc)
            # Even an unexpected error must not strand the child: re-arm.
            self._arm_suspend_safety_timer(pid, self._RESUME_RETRY_S, None)
            return False

    def _attempt_resume_verified(self, psproc: Any, pid: int) -> str:
        """One resume attempt with VERIFICATION.  Returns:
          * ``"resumed"`` — the child verifiably left the stopped state
            (or verification was inconclusive after a successful call);
          * ``"gone"``    — the process no longer exists (nothing stopped);
          * ``"failed"``  — the child is still stopped; the caller must
            retry or escalate.  Fire-and-forget resume was the audit bug:
            a failed SIGCONT treated as success stranded the child."""
        import psutil
        if psproc is None:
            try:
                psproc = psutil.Process(pid)   # last-resort unpinned handle
            except Exception:
                return "gone"
        try:
            psproc.resume()
        except psutil.NoSuchProcess:
            return "gone"
        except Exception as exc:
            try:
                if not psproc.is_running():
                    return "gone"
            except Exception:
                return "gone"
            logger.debug("[resource-governor] resume call pid=%s raised: %s",
                         pid, exc)
            return "failed"
        # The call succeeded — verify the child actually left STOPPED.
        try:
            if psproc.status() == psutil.STATUS_STOPPED:
                return "failed"
        except psutil.NoSuchProcess:
            return "gone"
        except Exception as exc:
            logger.debug("[resource-governor] resume verify pid=%s probe "
                         "failed (call succeeded, assuming resumed): %s",
                         pid, exc)
        return "resumed"

    def _kill_stranded(self, pid: int, rec: Optional[ChildRecord],
                       psproc: Any, *, exec_id: str, attempts: int) -> None:
        """Deliberate last resort: a suspended child that cannot be resumed
        is killed — never left in limbo.  The verdict is stamped FIRST so
        the parent's crash path surfaces it to the user."""
        exec_id = exec_id or (rec.execution_id if rec is not None else "")
        msg = (
            "Query terminated by the QueryStudio resource governor: the "
            "query's engine process was paused under pod memory pressure "
            "and could not be resumed after repeated attempts, so it was "
            "terminated rather than left suspended holding memory, spill "
            "files and S3 connections. Please re-run the query."
        )
        with self._lock:
            self._kill_notes[pid] = msg
            if exec_id:
                self._kill_notes[("exec", exec_id)] = msg
            while len(self._kill_notes) > self._MAX_KILL_NOTES:
                self._kill_notes.pop(next(iter(self._kill_notes)), None)
        self._counters["stranded_kills"] += 1
        logger.error(
            "[resource-governor] KILLING stranded suspended child pid=%s "
            "exec=%s after %d failed resume attempts — a paused child must "
            "be resumed or killed, never left holding memory and sockets",
            pid, exec_id or "?", attempts)
        try:
            if rec is not None:
                # Spawn-shape-aware tree kill (pinned handle → pid-reuse
                # safe).  force=True: SIGTERM is not delivered to a stopped
                # process, SIGKILL is.
                self._terminate_victim(rec, force=True)
            elif psproc is not None:
                psproc.kill()
        except Exception as exc:
            logger.warning("[resource-governor] stranded-kill pid=%s failed "
                           "(will retry via safety timer): %s", pid, exc)

    def _arm_suspend_safety_timer(self, pid: int, delay: float,
                                  gen: Optional[int]) -> None:
        """Arm one dead-man/retry timer for ``pid``.  Best-effort, never
        raises; the loop's ledger sweep is the belt over these braces."""
        try:
            t = threading.Timer(max(0.05, float(delay)),
                                self._safety_resume, args=(pid, gen))
            t.daemon = True
            t.start()
        except Exception as exc:                                 # pragma: no cover
            logger.debug("[resource-governor] safety-resume timer failed: %s",
                         exc)

    def _resume_suspended(self, reason: str) -> None:
        """Resolve EVERY outstanding suspension (marker + ledger)."""
        pids = set()
        if self._suspended_pid:
            pids.add(self._suspended_pid)
        with self._lock:
            pids.update(self._suspend_ledger.keys())
        for pid in pids:
            self._resolve_suspension(pid, reason=reason)

    def _sweep_suspend_ledger(self) -> None:
        """Repair pass, run every loop iteration (enabled or not): resolve
        any ledger entry past its dead-man deadline.  Independent of the
        timers, so timer failure alone can never strand a child; the
        timers are independent of the loop, so governor-thread death alone
        cannot either."""
        try:
            now_m = time.monotonic()
            with self._lock:
                overdue = [pid for pid, e in self._suspend_ledger.items()
                           if now_m >= float(e.get("deadline_mono", 0.0))]
            for pid in overdue:
                self._resolve_suspension(pid,
                                         reason="ledger sweep (deadline)")
        except Exception as exc:                                 # pragma: no cover
            logger.debug("[resource-governor] ledger sweep failed: %s", exc)

    def _safety_resume(self, pid: int, gen: Optional[int] = None) -> None:
        """Timer-driven dead-man's switch: resolve ``pid`` no matter what
        state the governor is in.  ``gen`` guards against a stale timer
        from a PREVIOUS suspension of the same pid acting on a new one.
        Best-effort, never raises."""
        try:
            with self._lock:
                entry = self._suspend_ledger.get(pid)
                rec = self._children.get(pid)
            if entry is not None and gen is not None \
                    and int(entry.get("gen", 0)) != gen:
                return          # stale timer from an earlier suspension
            if entry is None and (rec is None or rec.suspended_at <= 0):
                return          # already resolved
            self._resolve_suspension(pid, reason="safety-net timer")
        except Exception as exc:                                 # pragma: no cover
            logger.debug("[resource-governor] safety resume pid=%s: %s",
                         pid, exc)
            # A failure HERE must still not strand the child.
            self._arm_suspend_safety_timer(pid, self._RESUME_RETRY_S, gen)

    # ── Tier 2: kill ───────────────────────────────────────────────────

    def _kill_message(self, rec: ChildRecord, ratio: float, limit: int) -> str:
        over = rec.overage_bytes()
        over_txt = ""
        if over > 0:
            over_txt = (f", {over // _MB} MB over the {rec.memory_limit_bytes // _MB} MB "
                        f"ceiling it was granted")
        return (
            "Query cancelled by the QueryStudio resource governor: the pod "
            f"reached {ratio:.0%} of its {limit // _MB} MB memory limit and "
            f"this query had the highest measured memory use "
            f"({rec.last_rss // _MB} MB resident{over_txt}). "
            "To reduce memory: select fewer columns, add partition/date "
            "filters to narrow the scan, or re-run when the pod is less busy."
        )

    def _do_kill(self, rec: ChildRecord, ratio: float, usage: int,
                 limit: int, now: float) -> None:
        msg = self._kill_message(rec, ratio, limit)
        if not is_enforcing():
            self._counters["would_kill"] += 1
            self._last_kill_at = now       # observe honours the cooldown too
            self._record_decision("would_kill", rec, ratio, usage, limit)
            logger.warning(
                "[resource-governor] WOULD KILL pid=%s exec=%s rss=%dMB "
                "over_limit=%dMB (pod %.0f%% of %dMB) — observe mode, nothing "
                "killed.  Verdict: %s",
                rec.pid, rec.execution_id or "?", rec.last_rss // _MB,
                rec.overage_bytes() // _MB, ratio * 100, limit // _MB, msg)
            return
        # Kill for real.  Note FIRST (so the parent's crash path finds the
        # verdict no matter how fast the child dies), then terminate via
        # the existing tree-kill (grandchild S3 sockets + spill cleanup —
        # BF-530/BF-542 machinery, not reinvented here).
        with self._lock:
            self._kill_notes[rec.pid] = msg
            if rec.execution_id:
                self._kill_notes[("exec", rec.execution_id)] = msg
            while len(self._kill_notes) > self._MAX_KILL_NOTES:
                self._kill_notes.pop(next(iter(self._kill_notes)), None)
        if rec.pid == self._suspended_pid:
            # SIGTERM is not delivered to a stopped process until it runs
            # again — resume first so the graceful phase can work.
            self._resume_record(rec, reason="selected for kill")
        try:
            self._terminate_victim(rec, force=False)   # graceful phase
            t = threading.Timer(
                self._KILL_GRACE_S,
                lambda: self._terminate_victim(rec, force=True))
            t.daemon = True
            t.start()
        except Exception as exc:
            logger.warning("[resource-governor] kill pid=%s failed "
                           "(kernel OOM remains the backstop): %s", rec.pid, exc)
            return
        self._last_kill_at = now
        rec.killed_at = now
        self._counters["kills"] += 1
        self._record_decision("kill", rec, ratio, usage, limit)
        logger.warning(
            "[resource-governor] KILLED pid=%s exec=%s rss=%dMB over_limit=%dMB "
            "(pod %.0f%% of %dMB limit) — one victim, chosen on measured RSS; "
            "the pod and every other query survive",
            rec.pid, rec.execution_id or "?", rec.last_rss // _MB,
            rec.overage_bytes() // _MB, ratio * 100, limit // _MB)

    def _terminate_victim(self, rec: ChildRecord, *, force: bool) -> None:
        """Terminate the victim by the mechanism its SPAWN SHAPE makes safe.

        * ``own_process_group=True`` (legacy Popen with
          ``start_new_session`` / ``CREATE_NEW_PROCESS_GROUP``; forkserver
          children, which ``setsid()``): reuse the existing BF-530
          ``_kill_subprocess_tree`` — the process-group kill that also
          takes out httpfs/boto3 grandchildren holding S3 sockets.
        * ``own_process_group=False`` (warm-pool workers — their Popen is
          created WITHOUT a new session, so on POSIX ``os.killpg`` on
          their pgid would signal the API POD'S OWN GROUP): per-pid
          psutil tree kill instead (children-recursive, so grandchildren
          are still covered).  The pool's own ``_WorkerDied`` handling
          then drains the worker sidecar → no orphaned spill/predownload
          files.
        """
        if rec.own_process_group and rec.popen is not None:
            from core.duckdb_subprocess import _kill_subprocess_tree
            _kill_subprocess_tree(rec.popen, force=force)
            return
        try:
            import psutil
            procs = [rec.psproc]
            try:
                procs += rec.psproc.children(recursive=True)
            except Exception as exc:
                logger.debug("[resource-governor] children enum pid=%s: %s",
                             rec.pid, exc)
            for p in procs:
                try:
                    if force:
                        p.kill()
                    else:
                        p.terminate()
                except psutil.NoSuchProcess:
                    continue
                except Exception as exc:
                    logger.debug("[resource-governor] terminate pid=%s: %s",
                                 getattr(p, "pid", "?"), exc)
        except Exception as exc:
            logger.debug("[resource-governor] psutil tree kill pid=%s failed: "
                         "%s", rec.pid, exc)

    # ── evidence ───────────────────────────────────────────────────────

    def _record_decision(self, action: str, rec: Optional[ChildRecord],
                         ratio: float, usage: int, limit: int) -> None:
        self._decisions.append({
            "at": time.time(), "action": action,
            "pid": rec.pid if rec else None,
            "execution_id": rec.execution_id if rec else None,
            "victim_rss": rec.last_rss if rec else None,
            "victim_declared_limit": rec.memory_limit_bytes if rec else None,
            "victim_overage": rec.overage_bytes() if rec else None,
            "pod_usage": usage, "pod_limit": limit,
            "ratio": round(ratio, 4),
            "mode": "enforce" if is_enforcing() else "observe",
        })

    def status(self) -> Dict[str, Any]:
        with self._lock:
            children = [r.to_dict() for r in self._children.values()]
            decisions = list(self._decisions)
            finished = list(self._finished)[-20:]
            counters = dict(self._counters)
            now_m = time.monotonic()
            ledger = [
                {"pid": pid,
                 "execution_id": e.get("execution_id") or None,
                 "suspended_for_s": round(
                     now_m - float(e.get("suspended_at_mono", now_m)), 1),
                 "resume_attempts": int(e.get("attempts", 0))}
                for pid, e in self._suspend_ledger.items()
            ]
        return {
            "enabled": is_enabled(),
            "mode": "enforce" if is_enforcing() else "observe",
            "children": children,
            "suspended_pid": self._suspended_pid or None,
            "suspend_ledger": ledger,
            "sustained_over_threshold_samples": self._sustained,
            "counters": counters,
            "recent_decisions": decisions[-50:],
            "recent_finished": finished,
        }

    # ── kill notes / peaks (read side) ─────────────────────────────────

    def take_kill_note(self, pid: int = 0,
                       execution_id: str = "") -> Optional[str]:
        with self._lock:
            note = self._kill_notes.pop(int(pid or 0), None)
            if note is None and execution_id:
                note = self._kill_notes.pop(("exec", str(execution_id)), None)
            return note

    def peak_for_execution(self, execution_id: str) -> Optional[int]:
        if not execution_id:
            return None
        with self._lock:
            for rec in self._children.values():
                if rec.execution_id == execution_id and rec.peak_rss > 0:
                    return rec.peak_rss
            for row in reversed(self._finished):
                if row.get("execution_id") == execution_id:
                    return int(row.get("peak_rss") or 0) or None
        return None

    def peak_for_plan(self, plan_hash: str) -> Optional[int]:
        """Measured HBO answer: the largest peak RSS EVER MEASURED for this
        plan_hash (recent window).  Real bytes, not a model."""
        if not plan_hash:
            return None
        with self._lock:
            dq = self._plan_peaks.get(str(plan_hash))
            if not dq:
                return None
            return max(dq)

    # ── lifecycle ──────────────────────────────────────────────────────

    def shutdown(self) -> None:
        self._stop.set()
        self._resume_suspended("governor shutdown")


# ── declared-ceiling helper (parent-side mirror of the child's resolution) ──


def declared_limit_bytes_from_env(env: Optional[Dict[str, str]]) -> int:
    """What ceiling did this child DECLARE?  Mirrors the child's own
    resolution: an explicit ``DUCKDB_MEMORY_LIMIT`` wins; otherwise the
    cgroup share divided by the concurrency the spawn env stamped
    (BF-558b/d).  0 = unknown (the child auto-resolves).  Never raises."""
    try:
        env = env or {}
        from core.duckdb_resource_limits import (
            parse_memory_limit_to_bytes, resolve_memory_limit_for_duckdb,
        )
        explicit = str(env.get("DUCKDB_MEMORY_LIMIT", "") or "").strip()
        if explicit:
            b = parse_memory_limit_to_bytes(explicit)
            if b > 0:
                return b
        try:
            conc = int(str(env.get("QS_DUCKDB_CONCURRENT_CHILDREN", "1")
                           or "1"))
        except ValueError:
            conc = 1
        return parse_memory_limit_to_bytes(
            resolve_memory_limit_for_duckdb(concurrency=max(1, conc)))
    except Exception as exc:
        logger.debug("[resource-governor] declared-limit resolve failed: %s",
                     exc)
        return 0


# ── module-level singleton + never-raise public API ─────────────────────────

_GOV: Optional[ResourceGovernor] = None
_gov_lock = threading.Lock()


def get_governor() -> ResourceGovernor:
    global _GOV
    if _GOV is not None:
        return _GOV
    with _gov_lock:
        if _GOV is None:
            _GOV = ResourceGovernor()
        return _GOV


def register_child(pid: int, *, execution_id: str = "", username: str = "",
                   kind: str = KIND_QUERY, memory_limit_bytes: int = 0,
                   n_columns: int = 0, plan_hash: str = "", popen: Any = None,
                   own_process_group: bool = False,
                   spawn_env: Optional[Dict[str, str]] = None) -> None:
    """Fail-open registration hook for every spawn path.  When the
    governor is disabled this is one config read and a return.  NEVER
    raises — it must never be the reason a query cannot start.

    ``own_process_group``: pass True ONLY when the child leads its own
    process group/session (legacy Popen spawn, forkserver) — it selects
    the group-kill path.  Default False selects the per-pid kill path,
    which is always safe."""
    try:
        if not is_enabled() and not samples_for_query_pods():
            return
        get_governor().register(
            pid, execution_id=execution_id, username=username, kind=kind,
            memory_limit_bytes=memory_limit_bytes, n_columns=n_columns,
            plan_hash=plan_hash, popen=popen,
            own_process_group=own_process_group, spawn_env=spawn_env)
    except Exception as exc:
        logger.debug("[resource-governor] register_child failed (fail-open): %s",
                     exc)


def deregister_child(pid: int) -> None:
    """Fail-open deregistration.  Runs even when the flag has been turned
    off mid-flight (a record registered while enabled must still finalize).
    NEVER raises."""
    try:
        if _GOV is None:
            return
        _GOV.deregister(pid)
    except Exception as exc:
        logger.debug("[resource-governor] deregister_child failed (fail-open): "
                     "%s", exc)


def consume_kill_note(pid: int = 0, execution_id: str = "") -> Optional[str]:
    """If the governor killed this child, return the user-facing verdict
    (and forget it).  Deliberately ignores the enabled flag: a note can
    only exist if the governor was enforcing when it acted.  NEVER raises."""
    try:
        if _GOV is None:
            return None
        return _GOV.take_kill_note(pid=pid, execution_id=execution_id)
    except Exception as exc:
        logger.debug("[resource-governor] consume_kill_note failed (fail-open): "
                     "%s", exc)
        return None


def peak_rss_for_execution(execution_id: str) -> Optional[int]:
    """Measured peak RSS for an execution (live or recently finished)."""
    try:
        if _GOV is None:
            return None
        return _GOV.peak_for_execution(execution_id)
    except Exception as exc:
        logger.debug("[resource-governor] peak_rss_for_execution failed: %s",
                     exc)
        return None


def measured_peak_for_plan(plan_hash: str) -> Optional[int]:
    """History-based-admission primitive: the measured peak RSS for this
    plan_hash's recent runs, or None when no run was measured.  This is
    the exact-bytes answer Trino's HBO can only approximate."""
    try:
        if _GOV is None:
            return None
        return _GOV.peak_for_plan(plan_hash)
    except Exception as exc:
        logger.debug("[resource-governor] measured_peak_for_plan failed: %s",
                     exc)
        return None


def governor_status() -> Dict[str, Any]:
    """Operator evidence surface (admin dashboards, observe-mode review)."""
    try:
        if _GOV is None:
            return {"enabled": is_enabled(),
                    "mode": "enforce" if is_enforcing() else "observe",
                    "children": [], "counters": {}, "recent_decisions": []}
        return _GOV.status()
    except Exception as exc:
        logger.debug("[resource-governor] governor_status failed: %s", exc)
        return {"enabled": False, "error": "status unavailable"}


# ── test support ────────────────────────────────────────────────────────────


def set_memory_probes_for_tests(
        usage_fn: Optional[Callable[[], Optional[int]]],
        limit_fn: Optional[Callable[[], Optional[int]]]) -> None:
    gov = get_governor()
    gov._usage_fn = usage_fn or _default_pod_usage_bytes
    gov._limit_fn = limit_fn or _default_pod_limit_bytes


def reset_for_tests() -> None:
    global _GOV
    with _gov_lock:
        gov = _GOV
        _GOV = None
    if gov is not None:
        try:
            gov.shutdown()
        except Exception as exc:                                 # pragma: no cover
            logger.debug("[resource-governor] reset shutdown: %s", exc)


__all__ = [
    "KIND_QUERY", "KIND_SYSTEM", "ChildRecord", "ResourceGovernor",
    "is_enabled", "is_enforcing", "samples_for_query_pods", "get_governor",
    "register_child", "deregister_child", "consume_kill_note",
    "peak_rss_for_execution", "measured_peak_for_plan", "governor_status",
    "declared_limit_bytes_from_env",
    "set_memory_probes_for_tests", "reset_for_tests",
]
