"""Value lists -- storage (2026-10-24; the rules are core/value_lists.py)."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from core.config_active import active_clause, switch_off
from core.config_active import refuse_if_held
from core.db.models import ValueList, ValueListItem

_DEF_FIELDS = ("name", "description", "source_type", "connection_id", "source_sql",
               "key_column", "label_column", "sync_mode", "sync_every_hours",
               # 2026-11-01 -- a parameter's own list (core/reports/param_lists.py)
               "owner_kind", "owner_report_id", "owner_param_name", "parent_column")


class ValueListsMixin:

    # 2026-10-30 (owner): a deleted list is SWITCHED OFF, never erased.  Every
    # read below hides it (active_clause), so pickers, report parameters, the
    # sync daemon (it walks list_value_lists) and the values endpoint behave
    # exactly as after a real delete.  Only api/config_active_api.py reads it.

    def list_value_lists(self, *, include_parameter_lists: bool = False) -> List[Dict[str, Any]]:
        """The NAMED lists people make; a list a report parameter owns
        (``owner_kind = 'parameter'``) only when asked -- the sync daemon asks."""
        with self.get_session(read_only=True) as session:
            q = session.query(ValueList).filter(active_clause(ValueList))
            if not include_parameter_lists:
                q = q.filter(ValueList.owner_kind.is_(None))
            return [v.to_dict() for v in q.order_by(ValueList.name).all()]

    def get_parameter_choices_list(self, report_id: int, param_name: str) -> Optional[Dict[str, Any]]:
        """The list a report parameter owns, found BY NAME (2026-11-01)."""
        with self.get_session(read_only=True) as session:
            v = session.query(ValueList).filter(ValueList.owner_kind == "parameter",
                                                ValueList.owner_report_id == int(report_id),
                                                ValueList.owner_param_name == str(param_name),
                                                active_clause(ValueList)).first()
            return v.to_dict() if v else None

    def get_value_list(self, list_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            v = session.query(ValueList).filter(ValueList.id == int(list_id),
                                                active_clause(ValueList)).first()
            return v.to_dict() if v else None

    def get_value_list_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            v = session.query(ValueList).filter(ValueList.name == str(name),
                                                active_clause(ValueList)).first()
            return v.to_dict() if v else None

    def create_value_list(self, data: Dict[str, Any], by: str = "") -> Dict[str, Any]:
        with self.get_session() as session:
            # a switched-off list keeps its (unique) name -> 409, not a 500
            refuse_if_held(session, ValueList, "value list", "name", data.get("name"))
            v = ValueList(**{k: data.get(k) for k in _DEF_FIELDS if k in data},
                          created_by=by, updated_by=by)
            if not v.source_type:
                v.source_type = "query"
            if not v.sync_mode:
                v.sync_mode = "manual"
            session.add(v)
            session.flush()
            return v.to_dict()

    def update_value_list(self, list_id: int, data: Dict[str, Any], by: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            v = session.query(ValueList).filter(ValueList.id == int(list_id),
                                                active_clause(ValueList)).first()
            if v is None:
                return None
            if data.get("name") and data["name"] != v.name:
                refuse_if_held(session, ValueList, "value list", "name", data["name"],
                               exclude_id=v.id)
            for k in _DEF_FIELDS:
                if k in data:
                    setattr(v, k, data[k])
            v.updated_by = by
            session.flush()
            return v.to_dict()

    def delete_value_list(self, list_id: int) -> bool:
        """SWITCH the list OFF (owner, 2026-10-30) -- never erase it.  Its
        synced values (``value_list_items``) stay, so "Switch on" brings the
        list back with the values it had; the next sync refreshes them."""
        with self.get_session() as session:
            v = session.query(ValueList).filter(ValueList.id == int(list_id),
                                                active_clause(ValueList)).first()
            if v is None:
                return False
            switch_off(v)
            return True

    def record_value_list_failure(self, list_id: int, error: str, by: str = "", *,
                                  extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """A sync that failed: the reason, and NOTHING else changes (the
        previous values stay and are served, said stale).  ``extra``
        (2026-11-02): the backoff -- ``failures`` so far and ``retry_after`` --
        kept in the summary so the daemon's ``due()`` waits instead of
        retrying every tick."""
        with self.get_session() as session:
            v = session.get(ValueList, int(list_id))
            v.last_status = "failed"
            v.last_error = error
            summary = {"at": datetime.now(timezone.utc).isoformat(), "by": by,
                       "failed": True, "kept_values": v.value_count or 0}
            if extra:
                summary.update(extra)
            v.last_sync_summary = summary
            session.flush()
            return v.to_dict()

    def record_value_list_too_big(self, list_id: int, words: str, by: str = "", *, cap: int) -> Dict[str, Any]:
        """2026-11-02 -- the source returned more than the cap: the list is NOT
        kept (its stored values, if any, are removed -- a shorter snapshot would
        be served as if complete), its status says so in plain words, and
        ``serve`` searches the source as the person types."""
        with self.get_session() as session:
            v = session.query(ValueList).filter(ValueList.id == int(list_id)).with_for_update().first()
            if v is None:
                raise ValueError(f"value list {list_id} does not exist")
            removed = session.query(ValueListItem).filter(ValueListItem.list_id == int(list_id)).delete()
            v.last_status = "too_big"
            v.last_error = words
            v.value_count = 0
            v.values_version = int(v.values_version or 0) + 1
            v.last_synced_at = datetime.now(timezone.utc)
            v.last_sync_summary = {"at": datetime.now(timezone.utc).isoformat(), "by": by,
                                   "too_big": True, "cap": int(cap), "removed_values": int(removed or 0)}
            session.flush()
            return v.to_dict()

    def replace_value_list_items(self, list_id: int, items: List[Dict[str, Any]], *, by: str = "",
                                 seconds: Optional[float] = None) -> Dict[str, Any]:
        """ONE transaction: the list's values become exactly ``items`` --
        new keys added, changed labels / order / attrs updated, missing keys
        removed -- and the version moves.  Returns the list with the summary."""
        with self.get_session() as session:
            # (rig 2026-11-01) two syncs of one list at once -- the save's background build
            # and the author's Refresh now -- both read "no rows", both inserted the same
            # keys and one died on uq_value_list_item_key.  The list's ROW is locked FIRST
            # (SELECT ... FOR UPDATE on PostgreSQL; SQLite is single-writer and ignores
            # the clause), so the second waits and then replaces what the first wrote.
            v = session.query(ValueList).filter(ValueList.id == int(list_id)).with_for_update().first()
            if v is None:
                raise ValueError(f"value list {list_id} does not exist")
            have = {i.key: i for i in session.query(ValueListItem)
                    .filter(ValueListItem.list_id == int(list_id)).all()}
            want = {i["key"]: i for i in items}
            # the removed keys FIRST, as objects, flushed: a bulk delete left
            # them in the identity map and a new row reusing a freed id then
            # collided with the ghost (SQLite reuses ids)
            gone = [k for k in have if k not in want]
            for k in gone:
                session.delete(have.pop(k))
            session.flush()
            added = changed = 0
            for k, it in want.items():
                row = have.get(k)
                if row is None:
                    session.add(ValueListItem(list_id=int(list_id), key=k, label=it.get("label"),
                                              sort_order=int(it.get("sort_order") or 0), attrs=it.get("attrs")))
                    added += 1
                else:
                    # a CHANGE is a new label or attrs; a new position is not
                    if (row.label, row.attrs) != (it.get("label"), it.get("attrs")):
                        changed += 1
                    row.label, row.sort_order, row.attrs = it.get("label"), int(it.get("sort_order") or 0), it.get("attrs")
            v.value_count = len(want)
            v.values_version = int(v.values_version or 0) + 1
            v.last_synced_at = datetime.now(timezone.utc)
            v.last_status = "ok"
            v.last_error = None
            v.last_sync_summary = {"at": v.last_synced_at.isoformat(), "by": by, "values": len(want),
                                   "added": added, "changed": changed, "removed": len(gone),
                                   "seconds": seconds}
            session.flush()
            return v.to_dict()

    def latest_value_list_key(self, list_id: int, *, keys: Optional[set] = None, by_order: bool = False) -> Optional[str]:
        """ONE key: the MAX key (or the last in list order) among ``keys`` (the
        viewer's entitlement; an EMPTY set = none) -- computed in the database,
        never by reading the list (2026-11-01)."""
        from sqlalchemy import func
        if keys is not None and not keys:
            return None
        with self.get_session(read_only=True) as session:
            q = session.query(ValueListItem).filter(ValueListItem.list_id == int(list_id), ValueListItem.key != "")
            if keys is not None:
                q = q.filter(ValueListItem.key.in_([str(k) for k in keys]))
            if by_order:
                row = q.order_by(ValueListItem.sort_order.desc(), ValueListItem.key.desc()).first()
                return row.key if row else None
            return q.with_entities(func.max(ValueListItem.key)).scalar()

    def newest_value_list_keys(self, list_id: int, n: int, *, keys: Optional[set] = None) -> List[str]:
        """The ``n`` greatest keys among ``keys`` (the viewer's entitlement; an EMPTY
        set = none), newest first -- in the database, never by reading the list
        (2026-11-02: the 'latest with data' default of a two-date comparison)."""
        if keys is not None and not keys:
            return []
        with self.get_session(read_only=True) as session:
            q = session.query(ValueListItem.key).filter(ValueListItem.list_id == int(list_id), ValueListItem.key != "")
            if keys is not None:
                q = q.filter(ValueListItem.key.in_([str(k) for k in keys]))
            return [r[0] for r in q.distinct().order_by(ValueListItem.key.desc()).limit(max(1, int(n))).all()]

    def list_value_list_items(self, list_id: int, *, search: Optional[str] = None,
                              keys: Optional[set] = None, limit: int = 500,
                              offset: int = 0, with_attrs: bool = False,
                              newest_first: bool = False) -> List[Dict[str, Any]]:
        """The stored values, in list order; ``search`` = "contains" on key OR
        label (case-insensitive); ``keys`` = only these (the viewer's
        entitlement; an EMPTY set = none)."""
        from sqlalchemy import func, or_
        if keys is not None and not keys:
            return []
        with self.get_session(read_only=True) as session:
            q = session.query(ValueListItem).filter(ValueListItem.list_id == int(list_id))
            if search:
                like = f"%{search.lower()}%"
                q = q.filter(or_(func.lower(ValueListItem.key).like(like),
                                 func.lower(ValueListItem.label).like(like)))
            if keys is not None:
                q = q.filter(ValueListItem.key.in_([str(k) for k in keys]))
            # newest_first (2026-11-01): a DATE list served from its newest end, so a cap
            # drops the OLDEST dates -- never the newest (the band's prev / next steps)
            order = ((ValueListItem.sort_order.desc(), ValueListItem.key.desc()) if newest_first
                     else (ValueListItem.sort_order, ValueListItem.key))
            rows = q.order_by(*order).offset(int(offset)).limit(int(limit)).all()
            if with_attrs:      # a cascade reads attrs.parents (core/reports/param_lists.py)
                return [{"key": r.key, "label": r.label, "attrs": r.attrs} for r in rows]
            return [{"key": r.key, "label": r.label} for r in rows]
