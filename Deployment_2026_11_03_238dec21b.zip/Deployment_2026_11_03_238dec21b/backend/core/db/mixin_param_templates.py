"""Report parameter templates -- storage (2026-11-01; rules in core/reports/param_contract.py).
RELEASE by name, ``is_active`` (delete = switch off)."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from core.config_active import active_clause, switch_off
from core.db.models import ReportParameterTemplate


class ReportParameterTemplatesMixin:
    def list_report_parameter_templates(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as s:
            return [t.to_dict() for t in s.query(ReportParameterTemplate).filter(active_clause(ReportParameterTemplate))
                    .order_by(ReportParameterTemplate.name).all()]

    def get_report_parameter_template(self, template_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as s:
            t = s.query(ReportParameterTemplate).filter(ReportParameterTemplate.id == int(template_id),
                                                        active_clause(ReportParameterTemplate)).first()
            return t.to_dict() if t else None

    def get_report_parameter_template_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as s:
            t = s.query(ReportParameterTemplate).filter(ReportParameterTemplate.name == str(name),
                                                        active_clause(ReportParameterTemplate)).first()
            return t.to_dict() if t else None

    def templates_by_id(self, ids: List[int]) -> Dict[int, Dict[str, Any]]:
        if not ids:
            return {}
        with self.get_session(read_only=True) as s:
            rows = s.query(ReportParameterTemplate).filter(ReportParameterTemplate.id.in_([int(i) for i in ids]),
                                                           active_clause(ReportParameterTemplate)).all()
            return {int(t.id): t.to_dict() for t in rows}

    def reports_using_template(self, template_id: int) -> List[int]:
        """The ids of the ON reports with a parameter attached to this template
        (a change to the template is checked against each, 2026-11-01)."""
        from core.db.models import BusinessReport, ReportParameter
        with self.get_session(read_only=True) as s:
            rows = (s.query(ReportParameter.report_id).join(BusinessReport, BusinessReport.id == ReportParameter.report_id)
                    .filter(ReportParameter.template_id == int(template_id), active_clause(BusinessReport)).distinct().all())
            return sorted(int(r[0]) for r in rows)

    def create_report_parameter_template(self, data: Dict[str, Any], by: str = "") -> Dict[str, Any]:
        with self.get_session() as s:
            t = ReportParameterTemplate(name=str(data["name"]).strip(), description=data.get("description"),
                                        definition=data.get("definition") or {}, created_by=by, updated_by=by)
            s.add(t)
            s.flush()
            return t.to_dict()

    def update_report_parameter_template(self, template_id: int, data: Dict[str, Any], by: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session() as s:
            t = s.query(ReportParameterTemplate).filter(ReportParameterTemplate.id == int(template_id),
                                                        active_clause(ReportParameterTemplate)).first()
            if not t:
                return None
            for k in ("name", "description", "definition"):
                if k in data and data[k] is not None:
                    setattr(t, k, data[k])
            t.updated_by = by
            t.updated_at = datetime.now(timezone.utc)
            s.flush()
            return t.to_dict()

    def delete_report_parameter_template(self, template_id: int, by: str = "") -> bool:
        with self.get_session() as s:
            t = s.query(ReportParameterTemplate).filter(ReportParameterTemplate.id == int(template_id),
                                                        active_clause(ReportParameterTemplate)).first()
            if not t:
                return False
            switch_off(t, by_user=by)
            return True
