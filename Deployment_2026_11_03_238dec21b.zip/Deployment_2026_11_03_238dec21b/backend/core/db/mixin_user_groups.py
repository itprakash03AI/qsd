"""Mixin — Entitlement Groups CRUD (Phase 130 hotfix-7).

Extracted from DatabaseManager for modularity.  Same pattern as
mixin_feeds.py.
"""
from datetime import datetime, timezone
from typing import List, Optional

from core.config_active import active_clause, switch_off
from core.db.models import UserGroup, UserGroupMember


class UserGroupsMixin:
    """DB methods for user_groups + user_group_members."""

    # ── Group CRUD ─────────────────────────────────────────────────────

    def create_user_group(self, data: dict) -> dict:
        with self.get_session() as session:
            g = UserGroup(**data)
            session.add(g)
            session.flush()
            session.refresh(g)
            return g.to_dict()

    # 2026-10-30 (owner): a deleted group is SWITCHED OFF, never erased
    # (core/config_active.py).  Its members stay (so "Switch on" brings the
    # whole group back) -- which is why every read that GRANTS something
    # through a membership below ignores a switched-off group: it must grant
    # exactly what a deleted group granted, nothing.

    def get_user_group(self, gid: int, include_inactive: bool = False) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(UserGroup).filter(UserGroup.id == gid)
            if not include_inactive:
                q = q.filter(active_clause(UserGroup))
            row = q.first()
            return row.to_dict() if row else None

    def get_user_group_by_name(self, name: str, include_inactive: bool = False) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(UserGroup).filter(UserGroup.name == name)
            if not include_inactive:
                q = q.filter(active_clause(UserGroup))
            row = q.first()
            return row.to_dict() if row else None

    def list_user_groups(self, is_active: Optional[bool] = None) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(UserGroup)
            if is_active is not None:
                q = q.filter(UserGroup.is_active == is_active)
            return [r.to_dict() for r in q.order_by(UserGroup.name).all()]

    def update_user_group(self, gid: int, data: dict) -> Optional[dict]:
        with self.get_session() as session:
            row = session.query(UserGroup).filter(UserGroup.id == gid).first()
            if not row:
                return None
            for k, v in data.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def delete_user_group(self, gid: int) -> bool:
        """Switch the group OFF (2026-10-30): members are KEPT so "Switch
        on" brings the group back whole; meanwhile the membership reads
        below ignore it, so it grants nothing."""
        with self.get_session() as session:
            row = session.query(UserGroup).filter(UserGroup.id == gid).first()
            if not row:
                return False
            switch_off(row)
            return True

    # ── Membership ──────────────────────────────────────────────────────

    def add_user_group_member(self, group_id: int, username: str,
                              role_in_group: str = "member",
                              resource_access_level: str = "read_write",
                              added_by: Optional[str] = None) -> dict:
        """Add a user to a group.  ``resource_access_level`` controls
        what the user can do to GROUP-OWNED RESOURCES (Phase 130
        hotfix-13).  Defaults to ``'read_write'`` for backwards-compat
        with pre-hotfix memberships."""
        with self.get_session() as session:
            row = UserGroupMember(
                group_id=int(group_id),
                username=username,
                role_in_group=role_in_group or "member",
                resource_access_level=resource_access_level or "read_write",
                added_by=added_by,
            )
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def update_user_group_member(self, group_id: int, username: str,
                                   updates: dict) -> Optional[dict]:
        """Update one member's ``role_in_group`` and/or
        ``resource_access_level``.  Phase 130 hotfix-13: supports the
        per-user access flavour toggle.  Returns the post-update row
        as a dict, or None when the member doesn't exist."""
        allowed = {"role_in_group", "resource_access_level"}
        clean = {k: v for k, v in (updates or {}).items() if k in allowed and v is not None}
        if not clean:
            return self._get_member(group_id, username)
        with self.get_session() as session:
            row = session.query(UserGroupMember).filter(
                UserGroupMember.group_id == int(group_id),
                UserGroupMember.username == username,
            ).first()
            if not row:
                return None
            for k, v in clean.items():
                setattr(row, k, v)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def _get_member(self, group_id: int, username: str) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            row = session.query(UserGroupMember).filter(
                UserGroupMember.group_id == int(group_id),
                UserGroupMember.username == username,
            ).first()
            return row.to_dict() if row else None

    def remove_user_group_member(self, group_id: int, username: str) -> bool:
        with self.get_session() as session:
            count = session.query(UserGroupMember).filter(
                UserGroupMember.group_id == group_id,
                UserGroupMember.username == username,
            ).delete()
            return bool(count)

    def list_user_group_members(self, group_id: int,
                                include_inactive: bool = False) -> List[dict]:
        """Members of a group -- none for a switched-off group unless the
        caller asks (the admin screen showing what Switch on brings back):
        access, alerts and notifications read this list."""
        with self.get_session(read_only=True) as session:
            q = session.query(UserGroupMember).filter(
                UserGroupMember.group_id == group_id,
            )
            if not include_inactive:
                q = (q.join(UserGroup, UserGroup.id == UserGroupMember.group_id)
                     .filter(active_clause(UserGroup)))
            rows = q.order_by(UserGroupMember.username).all()
            return [r.to_dict() for r in rows]

    def is_user_in_group(self, username: str, group_id: int) -> bool:
        """Cheap membership lookup used by the permission resolver.

        Returns False on bad input (caller is expected to validate
        rather than throw)."""
        if not username or not group_id:
            return False
        with self.get_session(read_only=True) as session:
            return bool(session.query(UserGroupMember)
                        .join(UserGroup, UserGroup.id == UserGroupMember.group_id)
                        .filter(
                UserGroupMember.group_id == int(group_id),
                UserGroupMember.username == username,
                active_clause(UserGroup),
            ).first())

    def list_groups_for_user(self, username: str) -> List[dict]:
        """Returns the groups the given user belongs to (with full
        group metadata + role_in_group flattened in)."""
        if not username:
            return []
        with self.get_session(read_only=True) as session:
            rows = (session.query(UserGroupMember, UserGroup)
                    .join(UserGroup, UserGroup.id == UserGroupMember.group_id)
                    .filter(UserGroupMember.username == username,
                            active_clause(UserGroup))
                    .order_by(UserGroup.name)
                    .all())
            out: List[dict] = []
            for m, g in rows:
                d = g.to_dict()
                d["role_in_group"]          = m.role_in_group
                d["resource_access_level"]  = m.resource_access_level or "read_write"
                d["added_at"]               = m.added_at.isoformat() if m.added_at else None
                out.append(d)
            return out
