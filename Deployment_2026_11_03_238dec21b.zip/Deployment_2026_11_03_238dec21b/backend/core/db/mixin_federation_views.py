"""
Mixin — Federation Views CRUD (Phase 93).
Extracted from DatabaseManager for modularity.
"""
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any

from core.config_active import active_clause, switch_off
from core.db.models import FederationView


class FederationViewsMixin:
    """Database methods for federation views (cross-connection saved queries)."""

    def create_federation_view(self, **kwargs) -> Dict[str, Any]:
        """A switched-off view keeps its name (unique): reusing it is a 409
        (core/config_active.py).  A new view is always ON -- ``is_active``
        moves only through delete and Switch on."""
        from core.config_active import refuse_if_held
        with self.get_session() as session:
            refuse_if_held(session, FederationView, "federation view", "name", kwargs.get("name"))
            kwargs.pop("is_active", None)
            fv = FederationView(**kwargs)
            session.add(fv)
            session.flush()
            session.refresh(fv)
            return fv.to_dict()

    def get_federation_view(self, view_id: int) -> Optional[Dict[str, Any]]:
        """A switched-off view reads as gone -- no run, no preview, no picker."""
        with self.get_session(read_only=True) as session:
            fv = session.query(FederationView).filter(FederationView.id == view_id,
                                                      active_clause(FederationView)).first()
            return fv.to_dict() if fv else None

    def get_federation_view_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            fv = session.query(FederationView).filter(FederationView.name == name,
                                                      active_clause(FederationView)).first()
            return fv.to_dict() if fv else None

    def list_federation_views(self, active_only: bool = False) -> List[Dict[str, Any]]:
        """Switched-off views are never listed here (``active_only`` kept for
        old callers; api/config_active_api.py lists the switched-off ones)."""
        with self.get_session(read_only=True) as session:
            q = session.query(FederationView).filter(active_clause(FederationView))
            return [fv.to_dict() for fv in q.order_by(FederationView.name).all()]

    def update_federation_view(self, view_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        from core.config_active import refuse_if_held
        with self.get_session() as session:
            fv = session.query(FederationView).filter(FederationView.id == view_id,
                                                      active_clause(FederationView)).first()
            if not fv:
                return None
            kwargs.pop("is_active", None)   # only delete / Switch on move it
            if kwargs.get("name") and kwargs["name"] != fv.name:
                refuse_if_held(session, FederationView, "federation view", "name",
                               kwargs["name"], exclude_id=fv.id)
            for k, v in kwargs.items():
                if hasattr(fv, k):
                    setattr(fv, k, v)
            fv.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(fv)
            return fv.to_dict()

    def delete_federation_view(self, view_id: int) -> bool:
        """Delete = SWITCH OFF (owner, 2026-10-30; core/config_active.py).
        Its materialized files stay, so Switch on brings the view back as it
        was; every read above hides it meanwhile."""
        with self.get_session() as session:
            fv = session.query(FederationView).filter(FederationView.id == view_id,
                                                      active_clause(FederationView)).first()
            if not fv:
                return False
            switch_off(fv)
            session.flush()
            return True

    # ── Phase 97: Materialization helpers ─────────────────────────────────────

    def list_materialized_federation_views(self) -> List[Dict[str, Any]]:
        """Return federation views with status='ready' (materialized, usable in query builder)."""
        with self.get_session(read_only=True) as session:
            q = session.query(FederationView).filter(
                active_clause(FederationView),
                FederationView.status == "ready",
            )
            return [fv.to_dict() for fv in q.order_by(FederationView.name).all()]

    def get_federation_views_by_ids(self, ids: List[int]) -> List[Dict[str, Any]]:
        """Get multiple federation views by ID — used for composability depth check."""
        if not ids:
            return []
        with self.get_session(read_only=True) as session:
            fvs = session.query(FederationView).filter(FederationView.id.in_(ids),
                                                       active_clause(FederationView)).all()
            return [fv.to_dict() for fv in fvs]
