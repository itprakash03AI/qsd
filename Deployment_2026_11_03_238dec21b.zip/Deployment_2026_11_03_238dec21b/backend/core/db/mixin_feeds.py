"""
Mixin — Feed File Generation CRUD (Phase 76).
Extracted from DatabaseManager for modularity.
"""
import logging
import threading
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple

from core.db.models import (
    FeedConfig, FeedExecution, FeedCalendar, FeedHoliday, FeedRun,
    FeedControlFileFormat,
    FeedRowCountBaseline, FeedGroup,
    EtlDependencyType, EtlDependencyMapping, EtlDependencyTracking,
    FeedSequenceAllocation, FeedSodGap,
    FEED_RUN_SOD_CATCHUP_TRIGGER, FEED_RUN_UPSTREAM_TRIGGER,
)

logger = logging.getLogger(__name__)

#: 2026-10-03 -- what an execution row said BEFORE the write in flight on
#: THIS thread (status + stage_timings), captured by _write_feed_execution in
#: the session that writes it and read back by update_feed_execution for the
#: on-completion edge.  A thread-local, so the writer keeps its two-argument
#: seam (tests stub it) and concurrent writes on other threads never mix.
_EXEC_BEFORE = threading.local()

# PostgreSQL ``integer`` bounds.  A counter column left 32-bit rejects anything
# outside these with ``NumericValueOutOfRange`` -- 2,147,483,647 is only 2 GB
# when the column counts bytes.
_INT32_MAX = 2_147_483_647
_INT32_MIN = -2_147_483_648


def _coerce_business_date(value):
    """A business_date may arrive as date, datetime or ISO string
    (delivery_hops passes whatever the execution row carried).  Coerce to
    ``date`` so the SQL comparison matches the column type on every
    engine; an uncoercible value raises — a gate must not guess."""
    from datetime import date as _d, datetime as _dt
    if isinstance(value, _dt):
        return value.date()
    if isinstance(value, _d):
        return value
    return _dt.fromisoformat(str(value)[:10]).date()



def _json_finite(value: Any, path: str = "") -> Tuple[Any, List[str]]:
    """``(value with every NaN / +-Infinity float replaced by None, the paths
    replaced)`` -- recursively through dicts and lists.  JSON (and so every
    JSON column) cannot carry a non-finite number; a value that cannot be
    stored must never cost the row its write."""
    import math
    if isinstance(value, float) and not math.isfinite(value):
        return None, [path or "<value>"]
    if isinstance(value, dict):
        out, hits = {}, []
        for k, v in value.items():
            nv, h = _json_finite(v, f"{path}.{k}" if path else str(k))
            out[k] = nv
            hits += h
        return (out if hits else value), hits
    if isinstance(value, (list, tuple)):
        out_l, hits = [], []
        for i, v in enumerate(value):
            nv, h = _json_finite(v, f"{path}[{i}]")
            out_l.append(nv)
            hits += h
        return ((type(value)(out_l) if isinstance(value, tuple) else out_l) if hits else value), hits
    return value, []

def _oversized_int_fields(data: dict) -> Dict[str, int]:
    """Return the ``{key: value}`` pairs in *data* that cannot fit a 32-bit
    integer column.

    No special case for ``bool`` (an ``int`` subclass in Python): its only two
    values are 0 and 1, so it can never be out of range and excluding it would
    be a branch that cannot be reached.
    """
    out: Dict[str, int] = {}
    for k, v in (data or {}).items():
        if not isinstance(v, int):
            continue
        if v > _INT32_MAX or v < _INT32_MIN:
            out[k] = v
    return out


def _is_numeric_overflow(exc: Exception) -> bool:
    """True when *exc* is PostgreSQL's 22003 (numeric value out of range).

    Matched on the SQLSTATE where psycopg2 exposes one, with a text fallback so
    the guard still works behind a driver that does not.
    """
    orig = getattr(exc, "orig", None)
    code = getattr(getattr(orig, "pgcode", None), "strip", lambda: None)()
    if code == "22003":
        return True
    text = str(exc).lower()
    return "out of range" in text or "numeric field overflow" in text


class FeedsMixin:
    """Database methods for feed configs and executions."""

    # ── FeedConfig CRUD ───────────────────────────────────────────────────

    def create_feed_config(self, data: dict) -> dict:
        with self.get_session() as session:
            fc = FeedConfig(**data)
            session.add(fc)
            session.flush()
            session.refresh(fc)
            return fc.to_dict()

    def get_feed_config(self, feed_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            fc = session.query(FeedConfig).filter(FeedConfig.id == feed_id).first()
            return fc.to_dict() if fc else None

    def list_feed_configs(self, source_type: str = None, is_active: bool = None,
                           frequency_category: str = None) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(FeedConfig)
            if source_type is not None:
                q = q.filter(FeedConfig.source_type == source_type)
            if is_active is not None:
                q = q.filter(FeedConfig.is_active == is_active)
            # BF-473 — optional filter on operator categorization
            if frequency_category is not None:
                q = q.filter(FeedConfig.frequency_category == frequency_category)
            return [fc.to_dict() for fc in q.order_by(FeedConfig.name).all()]

    # ── Feed templates (2026-10-10) ───────────────────────────────────

    def create_feed_template(self, data: dict) -> dict:
        from core.db.models import FeedTemplate
        with self.get_session() as session:
            row = FeedTemplate(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    # 2026-10-30 (owner): a deleted template is SWITCHED OFF
    # (core/config_active.py) -- every read below hides it unless the caller
    # asks (``include_inactive``), so apply / SOD scope / auto-onboarding
    # behave exactly as after a real delete.

    def get_feed_template(self, template_id: int,
                          include_inactive: bool = False) -> Optional[dict]:
        from core.config_active import active_clause
        from core.db.models import FeedTemplate
        with self.get_session(read_only=True) as session:
            q = session.query(FeedTemplate).filter(FeedTemplate.id == int(template_id))
            if not include_inactive:
                q = q.filter(active_clause(FeedTemplate))
            row = q.first()
            return row.to_dict() if row else None

    def get_feed_template_by_name(self, name: str,
                                  include_inactive: bool = False) -> Optional[dict]:
        from sqlalchemy import func
        from core.config_active import active_clause
        from core.db.models import FeedTemplate
        with self.get_session(read_only=True) as session:
            q = session.query(FeedTemplate).filter(
                func.lower(FeedTemplate.name) == str(name).lower())
            if not include_inactive:
                q = q.filter(active_clause(FeedTemplate))
            row = q.first()
            return row.to_dict() if row else None

    def list_feed_templates(self) -> List[dict]:
        from core.config_active import active_clause
        from core.db.models import FeedTemplate
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedTemplate).filter(active_clause(FeedTemplate))
                    .order_by(FeedTemplate.name).all())
            return [r.to_dict() for r in rows]

    def update_feed_template(self, template_id: int, data: dict) -> Optional[dict]:
        from core.db.models import FeedTemplate
        with self.get_session() as session:
            row = session.query(FeedTemplate).filter(
                FeedTemplate.id == int(template_id)).first()
            if row is None:
                return None
            for k, v in data.items():
                if hasattr(row, k) and k != "id":
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    # -- Auto-onboarding requests (2026-10-11, core/feed/auto_onboard.py) --

    def upsert_onboarding_request(self, data: dict) -> tuple:
        """``(row, created)``.  ONE row per (template, member): a second
        message for the same entity + event (its other side, a redelivery)
        finds the first row and changes nothing."""
        from sqlalchemy.exc import IntegrityError
        from core.db.models import FeedOnboardingRequest as R
        with self.get_session() as session:
            row = session.query(R).filter(R.template_id == int(data["template_id"]),
                                          R.member_key == str(data["member_key"])).first()
            if row is not None:
                return row.to_dict(), False
            row = R(**data)
            session.add(row)
            try:
                session.flush()
            except IntegrityError:
                session.rollback()
                row = session.query(R).filter(R.template_id == int(data["template_id"]),
                                              R.member_key == str(data["member_key"])).first()
                return (row.to_dict() if row else None), False
            session.refresh(row)
            return row.to_dict(), True

    def list_onboarding_requests(self, status: Optional[str] = None,
                                 limit: int = 500, offset: int = 0) -> List[dict]:
        from core.db.models import FeedOnboardingRequest as R
        with self.get_session(read_only=True) as session:
            q = session.query(R)
            if status:
                q = q.filter(R.status == status)
            return [r.to_dict() for r in q.order_by(R.id.desc()).offset(int(offset)).limit(int(limit)).all()]

    def onboarding_request_counts(self) -> Dict[str, int]:
        """{status: n} over EVERY request (the tab's counts; never a page's)."""
        from sqlalchemy import func
        from core.db.models import FeedOnboardingRequest as R
        with self.get_session(read_only=True) as session:
            return {str(k): int(n) for k, n in session.query(R.status, func.count(R.id)).group_by(R.status).all()}

    def update_onboarding_request(self, request_id: int, data: dict) -> Optional[dict]:
        from core.db.models import FeedOnboardingRequest as R
        with self.get_session() as session:
            row = session.query(R).filter(R.id == int(request_id)).first()
            if row is None:
                return None
            for k, v in data.items():
                if hasattr(row, k) and k != "id":
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_recent_iceberg_commit_inspections(self, since, limit: int = 2000,
                                               offset: int = 0) -> List[dict]:
        """Every Iceberg-commit inspection since ``since`` (newest first),
        across dependencies -- the Iceberg monitor (core/feed/iceberg_monitor.py)."""
        from core.db.models import IcebergCommitInspection as I
        with self.get_session(read_only=True) as session:
            q = (session.query(I).filter(I.inspected_at >= since)
                 .order_by(I.inspected_at.desc(), I.id.desc()).offset(int(offset)).limit(int(limit)))
            return [r.to_dict() for r in q.all()]

    def iceberg_commit_inspection_counts(self, since) -> Dict[str, int]:
        """{status: n} of every inspection since ``since``."""
        from sqlalchemy import func
        from core.db.models import IcebergCommitInspection as I
        with self.get_session(read_only=True) as session:
            return {str(k): int(n) for k, n in session.query(I.status, func.count(I.id))
                    .filter(I.inspected_at >= since).group_by(I.status).all()}

    def feed_run_step_counts(self, run_ids) -> Dict[int, Dict[str, int]]:
        """``{run_id: {status: n, ..., "total": n}}`` over each run's LATEST
        attempt of every step -- the dashboard's "Failed 1/4" in ONE query
        (2026-10-12, core/feed/dashboard.py)."""
        from sqlalchemy import func
        from core.db.models import FeedRunStep as S
        ids = sorted({int(r) for r in (run_ids or []) if r is not None})
        out: Dict[int, Dict[str, int]] = {}
        if not ids:
            return out
        with self.get_session(read_only=True) as session:
            for start in range(0, len(ids), 900):
                chunk = ids[start:start + 900]
                latest = (session.query(S.feed_run_id.label("rid"), S.alias.label("alias"),
                                        func.max(S.attempt).label("att"))
                          .filter(S.feed_run_id.in_(chunk))
                          .group_by(S.feed_run_id, S.alias).subquery())
                rows = (session.query(S.feed_run_id, S.status, func.count(S.id))
                        .join(latest, (S.feed_run_id == latest.c.rid)
                              & (S.alias == latest.c.alias) & (S.attempt == latest.c.att))
                        .group_by(S.feed_run_id, S.status).all())
                for rid, status, n in rows:
                    d = out.setdefault(int(rid), {"total": 0})
                    d[str(status)] = d.get(str(status), 0) + int(n)
                    d["total"] += int(n)
        return out

    def feed_run_step_sequences(self, run_ids) -> Dict[int, List[dict]]:
        """``{run_id: [{alias, state, started_at, seq}, ...]}`` -- each run's
        LATEST attempt of every step IN THE ORDER IT HAPPENED (started ones
        by start time, then the rest by declared seq): the board row's flow
        is sequential, not grouped by state (2026-10-12).  One query."""
        from sqlalchemy import func
        from core.db.models import FeedRunStep as S
        ids = sorted({int(r) for r in (run_ids or []) if r is not None})
        out: Dict[int, List[dict]] = {}
        if not ids:
            return out
        with self.get_session(read_only=True) as session:
            for start in range(0, len(ids), 900):
                chunk = ids[start:start + 900]
                latest = (session.query(S.feed_run_id.label("rid"), S.alias.label("alias"),
                                        func.max(S.attempt).label("att"))
                          .filter(S.feed_run_id.in_(chunk))
                          .group_by(S.feed_run_id, S.alias).subquery())
                rows = (session.query(S.feed_run_id, S.alias, S.status, S.started_at, S.seq)
                        .join(latest, (S.feed_run_id == latest.c.rid)
                              & (S.alias == latest.c.alias) & (S.attempt == latest.c.att)).all())
                for rid, alias, status, started, seq in rows:
                    out.setdefault(int(rid), []).append({
                        "alias": alias, "state": str(status), "seq": int(seq or 0),
                        "started_at": started.isoformat() if started else None})
        for steps in out.values():
            steps.sort(key=lambda s: (s["started_at"] is None, s["started_at"] or "", s["seq"]))
        return out

    # ── variance holds (2026-10-12, core/feed/variance_hold.py) ──────────

    def previous_delivered_rows(self, feed_config_id: int, business_date) -> Optional[dict]:
        """The rows the latest execution of this feed for an EARLIER
        business date DELIVERED (``destination_path`` set -- it is written
        only when something reached a destination; a released hold writes
        it too).  ``{"rows", "business_date", "execution_db_id"}`` or None
        when no earlier date was ever delivered."""
        from core.db.models import FeedExecution as E
        with self.get_session(read_only=True) as session:
            row = (session.query(E)
                   .filter(E.feed_config_id == int(feed_config_id),
                           E.business_date.isnot(None),
                           E.business_date < business_date,
                           E.status == "completed",
                           E.destination_path.isnot(None),
                           E.destination_path != "")
                   .order_by(E.business_date.desc(), E.id.desc())
                   .first())
            if row is None:
                return None
            return {"rows": int(row.total_rows or 0),
                    "business_date": row.business_date,
                    "execution_db_id": row.id}

    # ── environments + message tokens (2026-10-12): DATA, seeded once ────
    def seed_feed_contract_vocabulary(self) -> int:
        """Insert the seed rows into an EMPTY table (never over an edited
        one).  Idempotent; run at init."""
        from core.db.models import (
            FeedEnvironment, FeedMessageField, FeedMessageToken, SEED_FEED_ENVIRONMENTS,
            SEED_FEED_MESSAGE_FIELDS, SEED_FEED_MESSAGE_TOKENS,
        )
        n = 0
        with self.get_session() as session:
            if session.query(FeedEnvironment.id).first() is None:
                for row in SEED_FEED_ENVIRONMENTS:
                    session.add(FeedEnvironment(**row, is_active=True, updated_by="seed"))
                    n += 1
            if session.query(FeedMessageToken.id).first() is None:
                for row in SEED_FEED_MESSAGE_TOKENS:
                    session.add(FeedMessageToken(**row, is_active=True, updated_by="seed"))
                    n += 1
            if session.query(FeedMessageField.id).first() is None:
                for row in SEED_FEED_MESSAGE_FIELDS:
                    session.add(FeedMessageField(**row, is_active=True, updated_by="seed"))
                    n += 1
            else:
                # 2026-10-12 -- ``identifies`` arrived after the table: a row
                # that has never been answered (NULL) takes the seed's answer
                # once; an admin's True / False is never overwritten
                seeds = {r["field"]: r.get("identifies", False) for r in SEED_FEED_MESSAGE_FIELDS}
                for row in session.query(FeedMessageField).filter(FeedMessageField.identifies.is_(None)).all():
                    row.identifies = bool(seeds.get(row.field, False))
                    n += 1
            session.flush()
        return n

    def list_feed_message_fields(self, active_only: bool = True) -> List[dict]:
        from core.db.models import FeedMessageField as F
        with self.get_session(read_only=True) as session:
            q = session.query(F)
            if active_only:
                q = q.filter(F.is_active == True)  # noqa: E712
            return [f.to_dict() for f in q.order_by(F.sort_order, F.id).all()]

    def upsert_feed_message_field(self, data: dict, user: Optional[str] = None) -> dict:
        from core.db.models import FeedMessageField as F
        with self.get_session() as session:
            name = str(data["field"]).strip()
            row = session.query(F).filter(F.field == name).first()
            if row is None:
                row = F(field=name)
                session.add(row)
            for k in ("label", "sort_order", "on_tile", "on_monitor", "identifies", "is_active"):
                if k in data:
                    setattr(row, k, data[k])
            row.updated_by, row.updated_at = user, datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def list_feed_environments(self, active_only: bool = True) -> List[dict]:
        from core.db.models import FeedEnvironment as E
        with self.get_session(read_only=True) as session:
            q = session.query(E)
            if active_only:
                q = q.filter(E.is_active == True)  # noqa: E712
            return [e.to_dict() for e in q.order_by(E.sort_order, E.id).all()]

    def upsert_feed_environment(self, data: dict, user: Optional[str] = None) -> dict:
        from core.db.models import FeedEnvironment as E
        with self.get_session() as session:
            row = session.query(E).filter(E.side == data["side"]).first()
            if row is None:
                row = E(side=data["side"])
                session.add(row)
            for k in ("label", "dependency_suffixes", "message_field", "message_values", "sort_order", "is_active"):
                if k in data:
                    setattr(row, k, data[k])
            row.updated_by, row.updated_at = user, datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def list_feed_message_tokens(self, active_only: bool = True) -> List[dict]:
        from core.db.models import FeedMessageToken as T
        with self.get_session(read_only=True) as session:
            q = session.query(T)
            if active_only:
                q = q.filter(T.is_active == True)  # noqa: E712
            return [t.to_dict() for t in q.order_by(T.token).all()]

    def upsert_feed_message_token(self, data: dict, user: Optional[str] = None) -> dict:
        from core.db.models import FeedMessageToken as T
        with self.get_session() as session:
            tok = str(data["token"]).strip().lower()
            row = session.query(T).filter(T.token == tok).first()
            if row is None:
                row = T(token=tok)
                session.add(row)
            for k in ("message_field", "description", "is_active"):
                if k in data:
                    setattr(row, k, data[k])
            row.updated_by, row.updated_at = user, datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    # ── hold approvers (2026-10-12): a user group mapped at a scope ─────
    def list_hold_approvers(self) -> List[dict]:
        from core.db.models import FeedHoldApprover as A
        with self.get_session(read_only=True) as session:
            return [a.to_dict() for a in session.query(A).order_by(A.scope, A.scope_id, A.id).all()]

    def create_hold_approver(self, scope: str, scope_id: Optional[int], user_group_id: int,
                             created_by: Optional[str] = None) -> dict:
        """Idempotent: the same (scope, scope_id, group) returns the row that
        exists (NULL scope_id is not unique to the index on every engine)."""
        from core.db.models import FeedHoldApprover as A
        with self.get_session() as session:
            q = session.query(A).filter(A.scope == scope, A.user_group_id == int(user_group_id))
            q = q.filter(A.scope_id.is_(None)) if scope_id is None else q.filter(A.scope_id == int(scope_id))
            row = q.first()
            if row is None:
                row = A(scope=scope, scope_id=None if scope_id is None else int(scope_id),
                        user_group_id=int(user_group_id), created_by=created_by)
                session.add(row)
                session.flush()
            return row.to_dict()

    def delete_hold_approver(self, approver_id: int) -> bool:
        from core.db.models import FeedHoldApprover as A
        with self.get_session() as session:
            return bool(session.query(A).filter(A.id == int(approver_id)).delete())

    # ── restatement policies + feed alerts (2026-10-12): DATA, seeded once ──
    def seed_feed_alerting_vocabulary(self) -> int:
        """Seed the restatement policy and the alert kinds into EMPTY tables
        (never over edited ones).  Idempotent; run at init."""
        from core.db.models import (
            FeedAlertKind, FeedRestatementPolicy, SEED_FEED_ALERT_KINDS,
            SEED_FEED_RESTATEMENT_POLICIES,
        )
        n = 0
        with self.get_session() as session:
            if session.query(FeedRestatementPolicy.id).first() is None:
                for row in SEED_FEED_RESTATEMENT_POLICIES:
                    session.add(FeedRestatementPolicy(**row, is_active=True, updated_by="seed"))
                    n += 1
            if session.query(FeedAlertKind.id).first() is None:
                for row in SEED_FEED_ALERT_KINDS:
                    session.add(FeedAlertKind(**row, is_active=True, updated_by="seed"))
                    n += 1
            session.flush()
        return n

    def seed_missing_feed_alert_kinds(self, rows: Optional[List[dict]] = None) -> int:
        """THE ONE "insert the alert kinds missing BY NAME" seeder (2026-10-17):
        every row of ``rows`` (default ``SEED_FEED_ALERT_KINDS`` -- the feed kinds
        and the component kinds) whose ``kind`` is absent is inserted; a kind
        that exists -- seeded or edited -- is never touched.  The published-API
        kinds ride the same method (``seed_published_api_alerting``).
        Idempotent; run at init after ``seed_feed_alerting_vocabulary``."""
        from core.db.models import SEED_FEED_ALERT_KINDS, FeedAlertKind
        todo = list(rows) if rows is not None else list(SEED_FEED_ALERT_KINDS)
        n = 0
        with self.get_session() as session:
            present = {k for (k,) in session.query(FeedAlertKind.kind).all()}
            for row in todo:
                if row["kind"] in present:
                    continue
                data = dict(row)
                data.setdefault("is_active", True)
                data.setdefault("updated_by", "seed")
                session.add(FeedAlertKind(**data))
                present.add(row["kind"])
                n += 1
            session.flush()
        if n:
            try:
                from core.feed.feed_alerts import invalidate
                invalidate()
            except Exception:                               # noqa: BLE001
                pass
        return n

    def list_restatement_policies(self, active_only: bool = False) -> List[dict]:
        from core.db.models import FeedRestatementPolicy as P
        with self.get_session(read_only=True) as session:
            q = session.query(P)
            if active_only:
                q = q.filter(P.is_active == True)  # noqa: E712
            return [p.to_dict() for p in q.order_by(P.scope, P.scope_id, P.id).all()]

    def upsert_restatement_policy(self, data: dict, user: Optional[str] = None) -> dict:
        """One policy per (scope, scope_id); NULL scope_id compared as NULL."""
        from core.db.models import FeedRestatementPolicy as P
        with self.get_session() as session:
            sid = data.get("scope_id")
            q = session.query(P).filter(P.scope == data["scope"])
            q = q.filter(P.scope_id.is_(None)) if sid is None else q.filter(P.scope_id == int(sid))
            row = q.first()
            if row is None:
                row = P(scope=data["scope"], scope_id=None if sid is None else int(sid))
                session.add(row)
            for k in ("name", "on_new_message", "same_run_date", "window", "window_days",
                      "window_workdays", "is_active"):
                if k in data:
                    setattr(row, k, data[k])
            row.updated_by, row.updated_at = user, datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def delete_restatement_policy(self, policy_id: int) -> bool:
        from core.db.models import FeedRestatementPolicy as P
        with self.get_session() as session:
            return bool(session.query(P).filter(P.id == int(policy_id)).delete())

    def list_feed_alert_kinds(self, active_only: bool = False) -> List[dict]:
        from core.db.models import FeedAlertKind as K
        with self.get_session(read_only=True) as session:
            q = session.query(K)
            if active_only:
                q = q.filter(K.is_active == True)  # noqa: E712
            return [k.to_dict() for k in q.order_by(K.kind).all()]

    def upsert_feed_alert_kind(self, data: dict, user: Optional[str] = None) -> dict:
        from core.db.models import FeedAlertKind as K
        with self.get_session() as session:
            name = str(data["kind"]).strip()
            row = session.query(K).filter(K.kind == name).first()
            if row is None:
                row = K(kind=name)
                session.add(row)
            for k in ("title", "severity", "alert_group", "to_bell", "to_email", "to_netcool",
                      "to_jira", "clears_when", "is_active"):
                if k in data:
                    setattr(row, k, data[k])
            row.updated_by, row.updated_at = user, datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def list_feed_alert_routes(self) -> List[dict]:
        from core.db.models import FeedAlertRoute as R
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in session.query(R).order_by(R.scope, R.scope_id, R.id).all()]

    def create_feed_alert_route(self, data: dict, created_by: Optional[str] = None) -> dict:
        """Idempotent on (scope, scope_id, scope_key, kind, channel, target).
        ``scope_key`` (2026-10-17) keys a route for an alert SUBJECT
        (core/feed/alert_subject.py); NULL = every subject of that kind."""
        from core.db.models import FeedAlertRoute as R
        with self.get_session() as session:
            q = session.query(R).filter(R.scope == data["scope"], R.channel == data["channel"],
                                        R.target == data["target"])
            sid, kind = data.get("scope_id"), data.get("kind")
            skey = data.get("scope_key") or None
            q = q.filter(R.scope_id.is_(None)) if sid is None else q.filter(R.scope_id == int(sid))
            q = q.filter(R.scope_key.is_(None)) if skey is None else q.filter(R.scope_key == str(skey))
            q = q.filter(R.kind.is_(None)) if not kind else q.filter(R.kind == kind)
            row = q.first()
            if row is None:
                row = R(scope=data["scope"], scope_id=None if sid is None else int(sid),
                        scope_key=None if skey is None else str(skey)[:220],
                        kind=kind or None, channel=data["channel"], target=data["target"],
                        created_by=created_by)
                session.add(row)
                session.flush()
            return row.to_dict()

    def delete_feed_alert_route(self, route_id: int) -> bool:
        from core.db.models import FeedAlertRoute as R
        with self.get_session() as session:
            return bool(session.query(R).filter(R.id == int(route_id)).delete())

    def open_feed_alert(self, data: dict) -> Tuple[dict, bool]:
        """(row, created): the OPEN alert with this dedupe key, else a new
        one.  A CLEARED alert of the same key is re-opened as a new raise
        (the problem came back) -- its old deliveries are kept on the row."""
        from core.db.models import FeedAlert as A
        with self.get_session() as session:
            row = session.query(A).filter(A.dedupe_key == data["dedupe_key"]).first()
            if row is not None and row.status == "open":
                return row.to_dict(), False
            if row is None:
                row = A(**data)
                session.add(row)
            else:
                for k, v in data.items():
                    if k != "deliveries":
                        setattr(row, k, v)
                row.deliveries = list(row.deliveries or []) + list(data.get("deliveries") or [])
                row.status, row.cleared_at, row.cleared_by = "open", None, None
                row.raised_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict(), True

    def list_jira_pending_alerts(self, now, limit: int = 50) -> List[dict]:
        """2026-10-31 -- alerts the Jira sender owes a call (create | reopen |
        resolve) whose retry time has come, oldest first (core/feed/jira_sender.py)."""
        from core.db.models import FeedAlert as A
        with self.get_session(read_only=True) as session:
            q = (session.query(A).filter(A.jira_state.in_(("create", "reopen", "resolve")))
                 .filter((A.jira_next_at.is_(None)) | (A.jira_next_at <= now))
                 .order_by(A.id).limit(int(limit)))
            return [r.to_dict() for r in q.all()]

    def count_jira_alerts(self) -> Dict[str, int]:
        """jira_state -> count (the sender's status surface: waiting / failed)."""
        from sqlalchemy import func
        from core.db.models import FeedAlert as A
        with self.get_session(read_only=True) as session:
            rows = (session.query(A.jira_state, func.count(A.id))
                    .filter(A.jira_state.isnot(None)).group_by(A.jira_state).all())
            return {str(s): int(n) for s, n in rows}

    def get_feed_alert(self, alert_id: int) -> Optional[dict]:
        from core.db.models import FeedAlert as A
        with self.get_session(read_only=True) as session:
            row = session.query(A).filter(A.id == int(alert_id)).first()
            return row.to_dict() if row else None

    def update_feed_alert(self, alert_id: int, fields: dict) -> Optional[dict]:
        from core.db.models import FeedAlert as A
        with self.get_session() as session:
            row = session.query(A).filter(A.id == int(alert_id)).first()
            if row is None:
                return None
            for k, v in fields.items():
                setattr(row, k, v)
            session.flush()
            return row.to_dict()

    @staticmethod
    def _subject_filter(q, model, subject_kind: Optional[str], subject_key: Optional[str]):
        """``subject_kind`` (2026-10-17): None = no filter; ``"feed"`` = feed
        alerts only (``subject_kind IS NULL``); else that kind.  ``subject_key``
        narrows to one subject."""
        if subject_kind == "feed":
            q = q.filter(model.subject_kind.is_(None))
        elif subject_kind:
            q = q.filter(model.subject_kind == str(subject_kind))
        if subject_key:
            q = q.filter(model.subject_key == str(subject_key))
        return q

    def clear_feed_alerts(self, *, dedupe_keys: Optional[List[str]] = None,
                          feed_config_id: Optional[int] = None, business_date=None,
                          kinds: Optional[List[str]] = None, subject_kind: Optional[str] = None,
                          subject_key: Optional[str] = None, cleared_by: str = "") -> List[dict]:
        """Clear OPEN alerts by key, by (feed, date, kinds), or by (subject
        kind, subject key, kinds).  Returns the rows cleared (the caller sends
        their Netcool resolutions)."""
        from core.db.models import FeedAlert as A
        with self.get_session() as session:
            q = session.query(A).filter(A.status == "open")
            if dedupe_keys is not None:
                if not dedupe_keys:
                    return []
                q = q.filter(A.dedupe_key.in_(list(dedupe_keys)))
            if feed_config_id is not None:
                q = q.filter(A.feed_config_id == int(feed_config_id))
            if business_date is not None:
                q = q.filter(A.business_date == business_date)
            if kinds:
                q = q.filter(A.kind.in_(list(kinds)))
            q = self._subject_filter(q, A, subject_kind, subject_key)
            now = datetime.now(timezone.utc)
            out = []
            for row in q.all():
                row.status, row.cleared_at, row.cleared_by = "cleared", now, str(cleared_by)[:255]
                out.append(row.to_dict())
            session.flush()
            return out

    def count_feed_alerts(self, *, feed_config_id: Optional[int] = None, business_date=None,
                          status: Optional[str] = None, subject_kind: Optional[str] = None,
                          subject_key: Optional[str] = None) -> int:
        from core.db.models import FeedAlert as A
        with self.get_session(read_only=True) as session:
            q = session.query(A.id)
            if feed_config_id is not None:
                q = q.filter(A.feed_config_id == int(feed_config_id))
            if business_date is not None:
                q = q.filter(A.business_date == business_date)
            if status:
                q = q.filter(A.status == status)
            q = self._subject_filter(q, A, subject_kind, subject_key)
            return int(q.count())

    def list_feed_alerts(self, *, pairs: Optional[List[Tuple[int, Any]]] = None,
                         feed_config_id: Optional[int] = None, business_date=None,
                         status: Optional[str] = None, limit: int = 500,
                         offset: int = 0, subject_kind: Optional[str] = None,
                         subject_key: Optional[str] = None) -> List[dict]:
        """Alerts for (feed, business date) PAIRS (the board's page, one
        query), or by feed / date / status, or by SUBJECT (``subject_kind``:
        None = every alert, ``"feed"`` = feed alerts only, else that kind;
        ``subject_key`` = one subject)."""
        from sqlalchemy import and_, or_
        from core.db.models import FeedAlert as A
        with self.get_session(read_only=True) as session:
            q = session.query(A)
            if pairs is not None:
                if not pairs:
                    return []
                q = q.filter(or_(*[and_(A.feed_config_id == int(f), A.business_date == d)
                                   for f, d in pairs]))
            if feed_config_id is not None:
                q = q.filter(A.feed_config_id == int(feed_config_id))
            if business_date is not None:
                q = q.filter(A.business_date == business_date)
            if status:
                q = q.filter(A.status == status)
            q = self._subject_filter(q, A, subject_kind, subject_key)
            return [a.to_dict() for a in q.order_by(A.raised_at.desc(), A.id.desc())
                    .offset(int(offset)).limit(int(limit)).all()]

    def list_feed_alerts_owing_email(self, limit: int = 50) -> List[dict]:
        """Open alerts whose e-mail delivery is still ``pending`` (the
        retry the alert pass makes)."""
        from core.db.models import FeedAlert as A
        with self.get_session(read_only=True) as session:
            rows = (session.query(A).filter(A.status == "open")
                    .order_by(A.id.desc()).limit(int(limit) * 4).all())
            out = [r.to_dict() for r in rows
                   if any(d.get("channel") == "email" and d.get("status") == "pending"
                          for d in (r.deliveries or []))]
            return out[:int(limit)]

    def create_variance_hold(self, data: dict) -> dict:
        """ONE row per execution; any OPEN hold of the same (feed, business
        date) from an earlier execution is SUPERSEDED in the same
        transaction -- the newer file is the one a person decides on."""
        from core.db.models import FeedVarianceHold as H
        with self.get_session() as session:
            if data.get("business_date") is not None:
                for old in (session.query(H)
                            .filter(H.feed_config_id == int(data["feed_config_id"]),
                                    H.business_date == data["business_date"],
                                    H.status.in_(("held", "release_failed")))
                            .all()):
                    old.status = "superseded"
                    old.decision_reason = (f"superseded by execution "
                                           f"{data.get('execution_id')}")
            row = H(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_variance_hold(self, hold_id: int) -> Optional[dict]:
        from core.db.models import FeedVarianceHold as H
        with self.get_session(read_only=True) as session:
            row = session.query(H).filter(H.id == int(hold_id)).first()
            return row.to_dict() if row else None

    def list_variance_holds(self, *, status: Optional[str] = None,
                            business_date=None, feed_config_id: Optional[int] = None,
                            limit: int = 500) -> List[dict]:
        from core.db.models import FeedVarianceHold as H
        with self.get_session(read_only=True) as session:
            q = session.query(H)
            if status:
                q = q.filter(H.status.in_(tuple(s.strip() for s in status.split(","))))
            if business_date is not None:
                q = q.filter(H.business_date == business_date)
            if feed_config_id is not None:
                q = q.filter(H.feed_config_id == int(feed_config_id))
            return [r.to_dict() for r in q.order_by(H.id.desc()).limit(int(limit)).all()]

    def claim_variance_hold(self, hold_id: int, from_statuses, to_status: str,
                            data: Optional[dict] = None) -> Optional[dict]:
        """Compare-and-swap: move the hold to ``to_status`` only if it is in
        one of ``from_statuses`` NOW.  None = someone else decided first (a
        double click, a second person) -- the caller must not act."""
        from core.db.models import FeedVarianceHold as H
        with self.get_session() as session:
            n = (session.query(H)
                 .filter(H.id == int(hold_id), H.status.in_(tuple(from_statuses)))
                 .update({**(data or {}), "status": to_status,
                          "updated_at": datetime.now(timezone.utc)},
                         synchronize_session=False))
            if not n:
                return None
            row = session.query(H).filter(H.id == int(hold_id)).first()
            return row.to_dict() if row else None

    def update_variance_hold(self, hold_id: int, data: dict) -> Optional[dict]:
        from core.db.models import FeedVarianceHold as H
        with self.get_session() as session:
            row = session.query(H).filter(H.id == int(hold_id)).first()
            if row is None:
                return None
            for k, v in data.items():
                if hasattr(row, k) and k != "id":
                    setattr(row, k, v)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def delete_feed_template(self, template_id: int) -> bool:
        """Switch the template OFF (2026-10-30): its members keep their
        ``template_id`` so "Switch on" brings the whole template back."""
        from core.config_active import active_clause, switch_off
        from core.db.models import FeedTemplate
        with self.get_session() as session:
            row = session.query(FeedTemplate).filter(
                FeedTemplate.id == int(template_id), active_clause(FeedTemplate)).first()
            if row is None:
                return False
            switch_off(row)
            session.flush()
            return True

    def list_template_members(self, template_id: int) -> List[dict]:
        """EVERY feed rendered from the template, active or retired --
        the apply compares against all of them, so a retired member's key
        is never re-created as a duplicate by accident."""
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedConfig)
                    .filter(FeedConfig.template_id == int(template_id))
                    .order_by(FeedConfig.id.asc()).all())
            return [r.to_dict() for r in rows]

    def stamp_template_member(self, feed_id: int, template_id: Optional[int],
                              member_key: Optional[str]) -> bool:
        with self.get_session() as session:
            fc = session.query(FeedConfig).filter(FeedConfig.id == int(feed_id)).first()
            if not fc:
                return False
            fc.template_id = template_id
            fc.template_member_key = member_key
            session.flush()
            return True

    def detach_template_members(self, template_id: int) -> int:
        with self.get_session() as session:
            rows = (session.query(FeedConfig)
                    .filter(FeedConfig.template_id == int(template_id)).all())
            for fc in rows:
                fc.template_id = None
                fc.template_member_key = None
            session.flush()
            return len(rows)

    def list_distinct_frequency_categories(self) -> List[str]:
        """BF-473 — distinct non-null frequency_category values in use.
        Powers the admin-UI dropdown suggestion list so a custom
        category typed by one admin is visible to the next.
        """
        with self.get_session(read_only=True) as session:
            rows = (
                session.query(FeedConfig.frequency_category)
                .filter(FeedConfig.frequency_category.isnot(None))
                .distinct()
                .all()
            )
            return [r[0] for r in rows if r[0]]

    def update_feed_config(self, feed_id: int, data: dict) -> Optional[dict]:
        with self.get_session() as session:
            fc = session.query(FeedConfig).filter(FeedConfig.id == feed_id).first()
            if not fc:
                return None
            for k, v in data.items():
                if hasattr(fc, k):
                    setattr(fc, k, v)
            fc.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(fc)
            return fc.to_dict()

    #: the error a deactivation writes on the tasks it closes
    DEACTIVATED_RUN_REASON = ("Feed deactivated before this task started -- "
                              "it will never run")

    def deactivate_feed_config(self, feed_id: int) -> bool:
        """Deactivate the feed AND close its tasks that never started
        (2026-10-12).  A deleted / retired feed's pending tasks stayed on the
        board as "No group" rows, WAITING forever -- and once an upstream
        message released one, the engine refused the inactive feed and the
        board showed a FAILED run of a feed nobody owns.  Closed in the same
        transaction as ``cancelled`` with ``DEACTIVATED_RUN_REASON``; a task
        a worker has claimed (``status != 'pending'``) is left to finish."""
        with self.get_session() as session:
            fc = session.query(FeedConfig).filter(FeedConfig.id == feed_id).first()
            if not fc:
                return False
            now = datetime.now(timezone.utc)
            fc.is_active = False
            fc.updated_at = now
            closed = self._close_never_started(session, FeedRun.feed_config_id == feed_id, now)
            session.flush()
            if closed:
                logger.info("[feeds] feed %s deactivated: %d never-started task(s) closed",
                            feed_id, closed)
            return True

    def _close_never_started(self, session, which, now) -> int:
        """THE rule both callers apply: a pending task no worker has started."""
        return (session.query(FeedRun)
                .filter(which, FeedRun.status == "pending", FeedRun.started_at.is_(None))
                .update({FeedRun.status: "cancelled",
                         FeedRun.error: self.DEACTIVATED_RUN_REASON,
                         FeedRun.completed_at: now},
                        synchronize_session=False))

    def close_tasks_of_inactive_feeds(self) -> int:
        """The same closing for feeds deactivated BEFORE 2026-10-12 (their
        tasks were left pending).  Idempotent; run at init."""
        with self.get_session() as session:
            inactive = session.query(FeedConfig.id).filter(FeedConfig.is_active == False)  # noqa: E712
            n = self._close_never_started(session, FeedRun.feed_config_id.in_(inactive),
                                          datetime.now(timezone.utc))
            session.flush()
            return int(n or 0)

    # ── FeedExecution CRUD ────────────────────────────────────────────────

    def create_feed_execution(self, data: dict) -> dict:
        with self.get_session() as session:
            fe = FeedExecution(**data)
            session.add(fe)
            session.flush()
            session.refresh(fe)
            return fe.to_dict()

    def get_feed_execution(self, exec_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            fe = session.query(FeedExecution).filter(FeedExecution.id == exec_id).first()
            return fe.to_dict() if fe else None

    def get_feed_execution_by_exec_id(self, execution_id: str) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            fe = session.query(FeedExecution).filter(
                FeedExecution.execution_id == execution_id
            ).first()
            return fe.to_dict() if fe else None

    def get_feed_configs_by_ids(self, ids) -> Dict[int, dict]:
        """The configs of these ids only, {id: config} (2026-10-12: the run
        list loaded EVERY config to name the day's runs)."""
        want = sorted({int(i) for i in (ids or []) if i is not None})
        out: Dict[int, dict] = {}
        if not want:
            return out
        with self.get_session(read_only=True) as session:
            for chunk in range(0, len(want), 900):
                for fc in session.query(FeedConfig).filter(
                        FeedConfig.id.in_(want[chunk:chunk + 900])).all():
                    out[int(fc.id)] = fc.to_dict()
        return out

    def get_feed_executions_by_exec_ids(self, execution_ids) -> Dict[str, dict]:
        """``get_feed_execution_by_exec_id`` for many ids in one session
        (2026-10-12: the run list asked once per row)."""
        ids = sorted({str(i) for i in (execution_ids or []) if i})
        out: Dict[str, dict] = {}
        if not ids:
            return out
        with self.get_session(read_only=True) as session:
            for chunk in range(0, len(ids), 900):
                for fe in session.query(FeedExecution).filter(
                        FeedExecution.execution_id.in_(ids[chunk:chunk + 900])).all():
                    out[str(fe.execution_id)] = fe.to_dict()
        return out

    def get_active_feed_execution(self, feed_config_id: int) -> Optional[dict]:
        """The feed's one pending/running execution, if any (FR-RUN-08).

        The heartbeat caller's lookup: the queue worker knows its
        feed_config_id but the execution row is created inside
        execute_feed, so the worker resolves it here to beat on it.  At
        most one row can be active per feed (partial unique index
        ``ux_feed_executions_one_active_per_feed``); ``.first()`` on
        id-desc is belt-and-braces for DBs deployed before that index."""
        with self.get_session(read_only=True) as session:
            row = (session.query(FeedExecution)
                   .filter(FeedExecution.feed_config_id == int(feed_config_id),
                           FeedExecution.status.in_(["pending", "running"]))
                   .order_by(FeedExecution.id.desc())
                   .first())
            return row.to_dict() if row else None

    def list_feed_executions(self, feed_config_id: int, limit: int = 50, offset: int = 0) -> List[dict]:
        with self.get_session(read_only=True) as session:
            rows = session.query(FeedExecution).filter(
                FeedExecution.feed_config_id == feed_config_id
            ).order_by(FeedExecution.started_at.desc()).offset(offset).limit(limit).all()
            return [fe.to_dict() for fe in rows]

    def list_active_feed_executions_for_backend(self, backend: str,
                                                limit: int = 500) -> List[dict]:
        """2026-08-22 (spark_k8s) — the reconciler's worklist: every
        pending/running execution owned by the given backend.  Oldest
        first so long-runners are always reconciled even if the fleet
        somehow exceeds ``limit`` in-flight rows."""
        with self.get_session(read_only=True) as session:
            rows = (
                session.query(FeedExecution)
                .filter(FeedExecution.execution_backend == backend)
                .filter(FeedExecution.status.in_(["pending", "running"]))
                .order_by(FeedExecution.started_at.asc())
                .limit(limit)
                .all()
            )
            return [fe.to_dict() for fe in rows]

    def list_feed_executions_for_date(self, feed_config_ids: List[int], business_date,
                                      statuses=("completed",)) -> Dict[int, List[dict]]:
        """{feed_config_id: [execution, newest first]} of ONE business date
        -- every delivery of a task (one per run date), one query for a
        board page (2026-10-12)."""
        ids = [int(i) for i in feed_config_ids or []]
        if not ids:
            return {}
        with self.get_session(read_only=True) as session:
            q = session.query(FeedExecution).filter(FeedExecution.feed_config_id.in_(ids),
                                                    FeedExecution.business_date == business_date)
            if statuses:
                q = q.filter(FeedExecution.status.in_(list(statuses)))
            out: Dict[int, List[dict]] = {}
            for fe in q.order_by(FeedExecution.completed_at.desc(), FeedExecution.id.desc()).all():
                out.setdefault(int(fe.feed_config_id), []).append(fe.to_dict())
            return out

    def get_latest_feed_executions_by_feed_ids(self, feed_config_ids: List[int]) -> Dict[int, dict]:
        """Phase 130 hotfix-13: batched lookup of the most-recent
        feed_execution per feed_config_id.  Used by the dashboard
        endpoint to surface stage_timings / failed_stage on each
        feed_runs row in a single query (no N+1).

        Returns ``{feed_config_id: latest_execution_dict_or_None}``.
        Feeds without any execution are absent from the result.
        """
        if not feed_config_ids:
            return {}
        from sqlalchemy import func
        ids = [int(i) for i in feed_config_ids if i is not None]
        with self.get_session(read_only=True) as session:
            # Subquery: latest started_at per feed_config_id
            sub = (
                session.query(
                    FeedExecution.feed_config_id.label("fid"),
                    func.max(FeedExecution.started_at).label("max_started"),
                )
                .filter(FeedExecution.feed_config_id.in_(ids))
                .group_by(FeedExecution.feed_config_id)
                .subquery()
            )
            rows = (
                session.query(FeedExecution)
                .join(sub,
                       (FeedExecution.feed_config_id == sub.c.fid) &
                       (FeedExecution.started_at == sub.c.max_started))
                .all()
            )
            return {int(r.feed_config_id): r.to_dict() for r in rows}

    def _write_feed_execution(self, exec_id: int, data: dict) -> Optional[dict]:
        with self.get_session() as session:
            fe = session.query(FeedExecution).filter(FeedExecution.id == exec_id).first()
            if not fe:
                return None
            # 2026-10-03 -- what the row said BEFORE this write, read in the
            # same session that writes it: the edge the upstream-completion
            # hook fires on (see update_feed_execution).
            _EXEC_BEFORE.value = {"status": fe.status,
                                  "stage_timings": fe.stage_timings}
            for k, v in data.items():
                if hasattr(fe, k):
                    setattr(fe, k, v)
            session.flush()
            session.refresh(fe)
            return fe.to_dict()

    def update_feed_execution(self, exec_id: int, data: dict) -> Optional[dict]:
        """Write *data* onto the execution row, surviving a 32-bit counter.

        2026-09-02.  The columns are BigInteger in the model and
        ``_int32_columns_needing_widening`` widens them on a deployed database
        at boot -- but that ALTER can be refused (lock timeout, insufficient
        privilege), and until it lands a byte count above 2 GB makes the write
        raise ``NumericValueOutOfRange``.  When that write is the TERMINAL one
        the run never reaches a terminal state at all: it stays 'running'
        forever and its real outcome is lost.

        So an overflow drops the offending counters and retries ONCE, which
        gets the verdict recorded.  The dropped values are NOT discarded --
        they are written into ``files_metadata.oversized_columns`` and logged at
        ERROR.  The column itself is left NULL rather than clamped: a clamped
        counter is indistinguishable from a real one, and a wrong number that
        looks right is worse than a missing one that says so.

        2026-10-03 -- ON COMPLETION OF.  This is the ONE write every lane's
        execution passes on its way to a terminal state: the native
        engine's ``_finalize_execution_row``, the detached Spark / Airflow
        lanes' signed webhook, the spark_k8s reconciler, and the late
        delivery verdict a webhook-side delivery records afterwards.  So the
        hook that starts ``on_completion_of`` feeds is called HERE, after
        the write committed, on the EDGE -- when the row's terminal outcome
        (status + delivery-chain verdict) changed -- and never on any other
        write.  It is advisory: it never raises into the write.
        """
        _EXEC_BEFORE.value = None
        # 2026-10-12 -- no number that JSON cannot carry (NaN / +-Infinity)
        # may fail this write: it is the TERMINAL write of every lane, and a
        # completeness claim's ``float("inf")`` once failed a run whose file
        # was already delivered.  Replaced by null, the paths named.
        data, _nonfinite = _json_finite(data)
        if _nonfinite:
            logger.error("[db] feed_execution %s: non-finite number(s) at %s written as null "
                         "(JSON cannot carry NaN / Infinity) -- the producer should say it in words",
                         exec_id, _nonfinite[:10])
        try:
            row = self._write_feed_execution(exec_id, data)
        except Exception as exc:
            oversized = _oversized_int_fields(data)
            if not oversized or not _is_numeric_overflow(exc):
                raise
            logger.error(
                "[db] feed_execution %s: %s exceed(s) this database's 32-bit "
                "counter column(s) -- writing the row WITHOUT them so the run "
                "still reaches its terminal state.  True values preserved in "
                "files_metadata.oversized_columns.  Repair with: %s",
                exec_id, sorted(oversized),
                "; ".join(f"ALTER TABLE feed_executions ALTER COLUMN {k} "
                          f"TYPE bigint" for k in sorted(oversized)),
            )
            retry = {k: v for k, v in data.items() if k not in oversized}
            meta = retry.get("files_metadata")
            meta = dict(meta) if isinstance(meta, dict) else {}
            meta["oversized_columns"] = dict(oversized)
            retry["files_metadata"] = meta
            _EXEC_BEFORE.value = None
            row = self._write_feed_execution(exec_id, retry)
        before = getattr(_EXEC_BEFORE, "value", None)
        _EXEC_BEFORE.value = None
        self._after_execution_write(before, row)
        return row

    def _after_execution_write(self, before: Optional[dict],
                               row: Optional[dict]) -> None:
        """Hand a committed execution write to the ON-COMPLETION hook when
        its terminal outcome changed (core/feed/upstream_completion.py owns
        the rule).  Never raises -- a hook failure is logged, the write
        stands."""
        if not row or not before:
            return
        try:
            from core.feed.upstream_completion import on_execution_written
            on_execution_written(self, before, row)
        except Exception as exc:   # noqa: BLE001 -- advisory, named below
            logger.error(
                "[db] feed_execution %s: the on-completion hook failed (%s: "
                "%s) -- the execution write stands; downstream feeds were "
                "NOT evaluated for this transition", row.get("id"),
                type(exc).__name__, exc)

    def increment_feed_run_count(self, feed_id: int) -> None:
        # 2026-09-15: atomic in SQL (was a Python read-modify-write that
        # lost concurrent increments) -- see
        # mixin_datasets.increment_business_report_execution.
        try:
            from sqlalchemy import func as _sa_func, update as _sa_update
            with self.get_session() as session:
                session.execute(
                    _sa_update(FeedConfig)
                    .where(FeedConfig.id == feed_id)
                    .values(run_count=_sa_func.coalesce(FeedConfig.run_count, 0) + 1))
        except Exception:
            pass  # non-critical

    def create_feed_execution_atomic(self, feed_config_id: int, data: dict):
        """Create feed execution only if no pending/running execution exists for this feed.

        Uses INSERT...SELECT...WHERE NOT EXISTS as a fast-path filter, with
        the partial UNIQUE index ``ux_feed_executions_one_active_per_feed``
        as the actual atomic guard.  Under READ COMMITTED, two concurrent
        triggers can both pass the EXISTS subquery (it only sees committed
        rows); the index then rejects the second insert with IntegrityError
        which we translate to ``None`` (already executing).  Without the
        index, you would get duplicate executions on rare concurrent
        triggers — see BF-415.

        Returns:
            dict: The new execution record, or None if already executing.
        """
        from sqlalchemy import insert, select, literal, exists, and_
        from sqlalchemy.exc import IntegrityError

        try:
            with self.get_session() as session:
                # Build the NOT EXISTS subquery
                conflict_exists = exists(
                    select(FeedExecution.id).where(
                        and_(
                            FeedExecution.feed_config_id == feed_config_id,
                            FeedExecution.status.in_(["pending", "running"]),
                        )
                    )
                )

                # INSERT ... SELECT ... WHERE NOT EXISTS — fast-path filter.
                # The partial UNIQUE index is the actual atomic guard
                # (BF-415).
                col_vals = {}
                for k, v in data.items():
                    if hasattr(FeedExecution, k):
                        col_vals[getattr(FeedExecution, k)] = v

                stmt = (
                    insert(FeedExecution)
                    .from_select(
                        [c.key for c in col_vals.keys()],
                        select(*[literal(v).label(c.key) for c, v in col_vals.items()])
                        .where(~conflict_exists)
                    )
                )
                result = session.execute(stmt)
                session.flush()

                if result.rowcount == 0:
                    return None  # Already executing — race condition prevented

                # Fetch the newly created record
                fe = session.query(FeedExecution).filter(
                    FeedExecution.feed_config_id == feed_config_id,
                ).order_by(FeedExecution.id.desc()).first()
                return fe.to_dict() if fe else None
        except IntegrityError as _ie:
            # BF-415 — partial UNIQUE index on (feed_config_id) WHERE
            # status IN ('pending','running') rejected the row.  This is
            # the EXPECTED outcome of two concurrent triggers racing past
            # the EXISTS subquery: exactly one wins, the other gets
            # IntegrityError and we translate it to "None" so the caller
            # treats it the same as the rowcount==0 path above.
            import logging as _il
            _il.getLogger(__name__).debug(
                "[feed-atomic] concurrent trigger lost the race for feed_config_id=%s (%s)",
                feed_config_id, _ie.__class__.__name__,
            )
            return None

    def reset_stale_feed_executions(self, stale_minutes: int = 60) -> int:
        """Mark feed executions stuck in 'running' or 'pending' for >stale_minutes as failed.

        Mirrors ETL's ``reset_stale_running_executions()`` pattern (Phase 132-C).
        Called from the feed cleanup scheduler to recover from pod crashes.
        Also reaps orphaned 'pending' executions (created but never picked up).

        FR-RUN-08 (2026-09-02) — HEARTBEAT-AWARE.  This was keyed on
        ``started_at`` alone, so a healthy 90-minute execution whose pod
        was beating the whole time was still marked failed at the
        60-minute cutoff.  An execution with a FRESH heartbeat now
        survives regardless of age; a NULL heartbeat (row created before
        this deploy, or the pod died before its first beat) falls back
        to the old age rule — identical behaviour to yesterday for
        legacy rows, so the first sweep after deploy fails nothing that
        the old sweep would not have.
        """
        from sqlalchemy import or_
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=stale_minutes)
        message = f"Execution timed out (stuck >{stale_minutes}min)"
        with self.get_session() as session:
            stale = (FeedExecution.status.in_(["running", "pending"]),
                     FeedExecution.started_at < cutoff,
                     or_(FeedExecution.heartbeat_at.is_(None),
                         FeedExecution.heartbeat_at < cutoff))
            ids = [int(r[0]) for r in
                   session.query(FeedExecution.id).filter(*stale).all()]
            count = session.query(FeedExecution).filter(*stale).update(
                {"status": "failed", "error_message": message},
                synchronize_session="fetch",
            )
        self._after_swept_executions(ids, message)
        return count

    def _after_swept_executions(self, ids: List[int], message: str) -> None:
        """A bulk sweep that FAILED executions in SQL bypassed
        ``update_feed_execution``; hand each row it actually failed (its
        message is the sweep's) to the same on-completion hook, so an
        upstream that timed out records why its downstream did not start
        (2026-10-03).  Never raises."""
        for exec_id in ids or []:
            try:
                row = self.get_feed_execution(int(exec_id))
            except Exception as exc:   # noqa: BLE001 -- named below
                logger.error("[db] swept execution %s unreadable for the "
                             "on-completion hook: %s", exec_id, exc)
                continue
            if row and row.get("status") == "failed" \
                    and row.get("error_message") == message:
                self._after_execution_write(
                    {"status": "running", "stage_timings": None}, row)

    # ── Gapless file sequence ledger (FR-ART-07, 2026-09-03) ─────────
    #
    # The durable half of ``core.feed.sequence``.  That module owns the
    # POLICY (reuse vs revision, what a gap means, when a number may be
    # abandoned); these three methods are the STORE it was written
    # against.  Until they existed, ``SequenceAllocator`` could only be
    # driven by ``InMemorySequenceStore``, which is process-local — the
    # exact property FR-ART-07 forbids, since a restart would restart
    # the numbering.

    def list_feed_sequence_allocations(self, feed_config_id: int,
                                       scope_key: str = "") -> List[Dict[str, Any]]:
        """Every allocation for one (feed, scope) stream, oldest first.

        Returns the whole stream rather than just MAX: the allocator
        needs the taken-but-uncommitted rows to report gaps, and a
        query that returned only the high-water mark would make an
        unexplained hole invisible — which is the one thing this ledger
        exists to prevent.
        """
        with self.get_session(read_only=True) as session:
            rows = session.query(FeedSequenceAllocation).filter(
                FeedSequenceAllocation.feed_config_id == int(feed_config_id),
                FeedSequenceAllocation.scope_key == str(scope_key or ""),
            ).order_by(FeedSequenceAllocation.seq_value.asc()).all()
            return [r.to_dict() for r in rows]

    def insert_feed_sequence_allocation(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Take one number, atomically.

        Translates the UNIQUE(feed, scope, seq_value) violation into
        ``SequenceConflict``, which is the contract the allocator's
        retry loop is built on: a conflict means ANOTHER RUN WON THIS
        NUMBER and the caller should try the next one.  Letting a raw
        IntegrityError escape here would surface a race as a crash, and
        letting it be swallowed would be far worse — two files with one
        identity, delivered, both reported successful.
        """
        from core.feed.sequence import SequenceConflict
        try:
            from sqlalchemy.exc import IntegrityError
        except ImportError:  # pragma: no cover - sqlalchemy is required
            IntegrityError = Exception  # type: ignore[assignment]
        row = FeedSequenceAllocation(
            feed_config_id=int(data["feed_config_id"]),
            scope_key=str(data.get("scope_key") or ""),
            seq_value=int(data["seq_value"]),
            status=str(data.get("status") or "taken"),
            business_date=(str(data["business_date"])
                           if data.get("business_date") is not None else None),
            run_id=(str(data["run_id"])
                    if data.get("run_id") is not None else None),
            taken_at=data.get("taken_at") or datetime.now(timezone.utc),
            note=data.get("note") or "",
        )
        try:
            with self.get_session() as session:
                session.add(row)
                # Flush INSIDE the session so the constraint fires here,
                # where it can be classified, rather than at an outer
                # commit where the caller has already moved on.
                session.flush()
                session.refresh(row)
                return row.to_dict()
        except IntegrityError as exc:
            raise SequenceConflict(
                f"sequence value {data.get('seq_value')} for feed "
                f"{data.get('feed_config_id')} scope "
                f"{data.get('scope_key')!r} was taken by another run "
                f"({exc.__class__.__name__})") from exc

    def update_feed_sequence_allocation(self, alloc_id,
                                        updates: Dict[str, Any]) -> Dict[str, Any]:
        """Move an allocation between states (taken → committed /
        abandoned).  WHICH transitions are legal is the allocator's
        business, not this method's — the store applies what it is
        told and refuses only an id that does not exist."""
        from core.feed.sequence import SequenceError
        with self.get_session() as session:
            row = session.query(FeedSequenceAllocation).filter(
                FeedSequenceAllocation.id == alloc_id).first()
            if row is None:
                raise SequenceError(f"no sequence allocation {alloc_id}")
            for k, v in (updates or {}).items():
                if hasattr(row, k):
                    setattr(row, k, v)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_feed_sequence_allocation(self, alloc_id) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(FeedSequenceAllocation).filter(
                FeedSequenceAllocation.id == alloc_id).first()
            return row.to_dict() if row else None

    def cleanup_old_feed_executions(self, retention_days: int = 90) -> int:
        """Delete feed execution records older than retention period.

        LEGAL HOLD (FR-SEC-11, wired 2026-09-03).  A feed under hold is
        excluded: a hold that records a flag but lets the nightly reaper
        delete the evidence anyway is not a hold.  ``legal_hold_feed_ids``
        fails CLOSED by contract — if the hold store cannot be read it
        RAISES, and this method lets that propagate rather than reaping.
        Skipping one night of cleanup is recoverable; deleting history
        that was under hold is not.

        Returns the count deleted.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        try:
            from core.feed.lifecycle import legal_hold_feed_ids
            held = legal_hold_feed_ids(self)
        except ImportError:
            held = set()          # older build: no hold feature to honour
        with self.get_session() as session:
            q = session.query(FeedExecution).filter(
                FeedExecution.started_at < cutoff,
            )
            if held:
                logger.info(
                    "[feeds] execution cleanup is EXCLUDING %d feed(s) under "
                    "legal hold: %s", len(held), sorted(held))
                q = q.filter(FeedExecution.feed_config_id.notin_(list(held)))
            return q.delete(synchronize_session=False)

    # ── FeedCalendar CRUD (Phase 130) ─────────────────────────────────────

    def create_feed_calendar(self, data: dict) -> dict:
        with self.get_session() as session:
            cal = FeedCalendar(**data)
            session.add(cal)
            session.flush()
            session.refresh(cal)
            return cal.to_dict()

    def get_feed_calendar(self, cal_id: int, include_inactive: bool = False) -> Optional[dict]:
        """A switched-off calendar (core/config_active.py) is hidden unless
        the caller asks -- the admin screen, which lists inactive calendars
        on purpose, and the Clockwork projection, which reports one."""
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            q = session.query(FeedCalendar).filter(FeedCalendar.id == cal_id)
            if not include_inactive:
                q = q.filter(active_clause(FeedCalendar))
            row = q.first()
            return row.to_dict() if row else None

    def get_feed_calendar_by_name(self, name: str) -> Optional[dict]:
        """Resolve a named calendar.  Used by ``BusinessCalendarRepo``."""
        with self.get_session(read_only=True) as session:
            from core.config_active import active_clause
            row = session.query(FeedCalendar).filter(
                FeedCalendar.name == name,
                active_clause(FeedCalendar),
            ).first()
            return row.to_dict() if row else None

    def list_feed_calendars(self, is_active: bool = None) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(FeedCalendar)
            if is_active is not None:
                q = q.filter(FeedCalendar.is_active == is_active)
            return [r.to_dict() for r in q.order_by(FeedCalendar.name).all()]

    def update_feed_calendar(self, cal_id: int, data: dict) -> Optional[dict]:
        with self.get_session() as session:
            row = session.query(FeedCalendar).filter(FeedCalendar.id == cal_id).first()
            if not row:
                return None
            for k, v in data.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            row.version = int(row.version or 1) + 1
            session.flush()
            session.refresh(row)
            out = row.to_dict()
        self._calendar_changed(cal_id, "calendar updated")
        return out

    def delete_feed_calendar(self, cal_id: int) -> bool:
        """Switch the calendar OFF (2026-10-30, core/config_active.py): its
        holidays stay, so "Switch on" brings the whole calendar back."""
        from core.config_active import switch_off
        with self.get_session() as session:
            row = session.query(FeedCalendar).filter(FeedCalendar.id == cal_id).first()
            if not row:
                return False
            switch_off(row)
            return True

    # ── FeedHoliday CRUD (Phase 130) ──────────────────────────────────────

    def add_feed_holiday(self, calendar_id: int, holiday_date, holiday_name: str,
                        recurring: bool = False) -> dict:
        with self.get_session() as session:
            row = FeedHoliday(
                calendar_id=calendar_id,
                holiday_date=holiday_date,
                holiday_name=holiday_name,
                recurring=recurring,
            )
            session.add(row)
            self._bump_calendar_version(session, calendar_id)
            session.flush()
            session.refresh(row)
            out = row.to_dict()
        self._calendar_changed(calendar_id, f"holiday {holiday_date} added")
        return out

    def list_feed_holidays(self, calendar_id: int) -> List[dict]:
        """List holidays for a calendar.  Used by ``BusinessCalendarRepo``."""
        with self.get_session(read_only=True) as session:
            rows = session.query(FeedHoliday).filter(
                FeedHoliday.calendar_id == calendar_id,
            ).order_by(FeedHoliday.holiday_date).all()
            return [r.to_dict() for r in rows]

    def delete_feed_holiday(self, holiday_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(FeedHoliday).filter(FeedHoliday.id == holiday_id).first()
            if not row:
                return False
            calendar_id, holiday_date = row.calendar_id, row.holiday_date
            session.delete(row)
            self._bump_calendar_version(session, calendar_id)
        self._calendar_changed(calendar_id, f"holiday {holiday_date} deleted")
        return True

    # ── The calendar is DATA other subsystems snapshot ─────────────────
    #
    # 2026-09-10 audit: a Clockwork job inlines its bound calendar (holidays
    # included) into ``dispatch_definition`` at SAVE, and nothing re-derived
    # it when the calendar changed afterwards -- so ``/preview`` (the live
    # calendar) said the 5th while the dispatcher fired on the 2nd, a
    # holiday.  Every mutator above therefore (1) bumps ``version`` in ITS
    # transaction -- the model's comment promised "version bumps whenever
    # holidays change" and no code did it -- and (2) after the commit, hands
    # the calendar id to every subsystem that snapshots it, so the snapshot
    # and the live row cannot disagree for longer than this call.

    @staticmethod
    def _bump_calendar_version(session, calendar_id: int) -> None:
        cal = session.query(FeedCalendar).filter(FeedCalendar.id == int(calendar_id)).first()
        if cal is not None:
            cal.version = int(cal.version or 1) + 1
            cal.updated_at = datetime.now(timezone.utc)

    def _calendar_changed(self, calendar_id: int, what: str) -> None:
        """After the commit: re-project everything that snapshots this
        calendar.  Never raises -- a re-projection failure is logged and
        alerted by the re-projector; the holiday edit itself has already
        happened and must not look like it has not."""
        hook = getattr(self, "reproject_clockwork_jobs_for_calendar", None)
        if hook is None:
            return
        try:
            hook(int(calendar_id), reason=what)
        except Exception as exc:                                    # noqa: BLE001
            logger.error("[calendar] %s on calendar %s, but the Clockwork re-projection "
                         "failed (%s): jobs bound to it may still carry the OLD calendar",
                         what, calendar_id, exc)

    # ── FeedGroup CRUD (2026-09-02 — operational feed groups) ─────────────
    # Modelled on the FeedCalendar CRUD above: a managed reference entity
    # attached to feeds.  Membership is feed_configs.feed_group_id (ONE
    # group per feed — see the column comment in models.py).

    def create_feed_group(self, data: dict) -> dict:
        with self.get_session() as session:
            row = FeedGroup(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_feed_group(self, group_id: int, include_inactive: bool = False) -> Optional[dict]:
        """A switched-off group (core/config_active.py) is hidden unless the
        caller asks -- the Feed Groups page lists inactive groups on purpose
        and opens / edits them."""
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            q = session.query(FeedGroup).filter(FeedGroup.id == int(group_id))
            if not include_inactive:
                q = q.filter(active_clause(FeedGroup))
            row = q.first()
            return row.to_dict() if row else None

    def get_feed_group_by_name(self, name: str) -> Optional[dict]:
        """Resolve a group by its identity name (active OR inactive —
        the caller decides what inactivity means for its purpose; the
        duplicate-name refusal must see inactive rows too or a create
        would collide with them at the UNIQUE constraint)."""
        with self.get_session(read_only=True) as session:
            row = session.query(FeedGroup).filter(
                FeedGroup.name == str(name)).first()
            return row.to_dict() if row else None

    def list_feed_groups(self, is_active: bool = None) -> List[dict]:
        """Groups + a live ``feed_count`` each (counted in ONE grouped
        query, not N+1 — the dashboard polls this)."""
        from sqlalchemy import func
        with self.get_session(read_only=True) as session:
            q = session.query(FeedGroup)
            if is_active is not None:
                q = q.filter(FeedGroup.is_active == is_active)
            groups = [r.to_dict() for r in q.order_by(FeedGroup.name).all()]
            counts = dict(
                session.query(FeedConfig.feed_group_id,
                              func.count(FeedConfig.id))
                .filter(FeedConfig.feed_group_id.isnot(None))
                .group_by(FeedConfig.feed_group_id).all())
            for g in groups:
                g["feed_count"] = int(counts.get(g["id"], 0))
            return groups

    def update_feed_group(self, group_id: int, data: dict) -> Optional[dict]:
        with self.get_session() as session:
            row = session.query(FeedGroup).filter(
                FeedGroup.id == int(group_id)).first()
            if not row:
                return None
            for k, v in data.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def delete_feed_group(self, group_id: int, detach_feeds: bool = False) -> bool:
        """Delete a group.  ``detach_feeds=True`` first sets every member
        feed's ``feed_group_id`` to NULL (the feeds themselves are NEVER
        deleted — a group is a grouping, not an owner).  With
        ``detach_feeds=False`` members are left untouched, so the API
        layer MUST refuse the delete while members exist — this method
        deliberately carries no silent-orphan path of its own.

        2026-10-30 (owner): the group is SWITCHED OFF, never erased
        (core/config_active.py) -- its hold approvers, alert routes and
        restatement policies stay, so "Switch on" brings it back whole.
        Detaching the feeds stays an explicit, separate choice."""
        from core.config_active import switch_off
        with self.get_session() as session:
            row = session.query(FeedGroup).filter(
                FeedGroup.id == int(group_id)).first()
            if not row:
                return False
            if detach_feeds:
                session.query(FeedConfig).filter(
                    FeedConfig.feed_group_id == int(group_id),
                ).update({FeedConfig.feed_group_id: None},
                         synchronize_session=False)
            switch_off(row)
            return True

    def count_feeds_in_group(self, group_id: int) -> int:
        from sqlalchemy import func
        with self.get_session(read_only=True) as session:
            return int(session.query(func.count(FeedConfig.id)).filter(
                FeedConfig.feed_group_id == int(group_id)).scalar() or 0)

    def list_feed_configs_in_group(self, group_id: int) -> List[dict]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedConfig)
                    .filter(FeedConfig.feed_group_id == int(group_id))
                    .order_by(FeedConfig.name).all())
            return [r.to_dict() for r in rows]

    def set_feed_group_membership(self, group_id: int,
                                  assign_ids: List[int],
                                  unassign_ids: List[int]) -> Dict[str, List[int]]:
        """Bulk (re)assign / unassign in ONE transaction.

        ``assign_ids`` get ``feed_group_id=group_id`` (a feed already in
        another group is MOVED — one group per feed, so assignment IS
        reassignment).  ``unassign_ids`` are detached only when they are
        currently in THIS group (unassigning a feed from a group it is
        not in must not silently detach it from the group it IS in).
        Returns the ids actually written per action.
        """
        assign = [int(i) for i in (assign_ids or [])]
        unassign = [int(i) for i in (unassign_ids or [])]
        out: Dict[str, List[int]] = {"assigned": [], "unassigned": []}
        with self.get_session() as session:
            if assign:
                rows = session.query(FeedConfig).filter(
                    FeedConfig.id.in_(assign)).all()
                for fc in rows:
                    fc.feed_group_id = int(group_id)
                    fc.updated_at = datetime.now(timezone.utc)
                    out["assigned"].append(int(fc.id))
            if unassign:
                rows = session.query(FeedConfig).filter(
                    FeedConfig.id.in_(unassign),
                    FeedConfig.feed_group_id == int(group_id)).all()
                for fc in rows:
                    fc.feed_group_id = None
                    fc.updated_at = datetime.now(timezone.utc)
                    out["unassigned"].append(int(fc.id))
            session.flush()
        return out

    # ── FeedRun CRUD (Phase 130 — daily SOD task table) ───────────────────

    def create_feed_run(self, data: dict) -> dict:
        with self.get_session() as session:
            row = FeedRun(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_feed_run(self, run_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            row = session.query(FeedRun).filter(FeedRun.id == run_id).first()
            return row.to_dict() if row else None

    def get_feed_run_by_idempotency_key(self, feed_config_id: int,
                                        idempotency_key: str) -> Optional[dict]:
        """The run a caller's ``Idempotency-Key`` already started for this
        feed, or None (2026-09-15).  The key is honoured for as long as the
        run row exists, whatever its status -- a completed run is exactly
        the case the (feed, business_date) pending|running check misses."""
        key = (idempotency_key or "").strip()
        if not key:
            return None
        with self.get_session(read_only=True) as session:
            row = (session.query(FeedRun)
                   .filter(FeedRun.feed_config_id == int(feed_config_id),
                           FeedRun.idempotency_key == key)
                   .order_by(FeedRun.id.asc())
                   .first())
            return row.to_dict() if row else None

    @staticmethod
    def manual_run_excluded():
        """THE filter: a manual "Run Now" run (run_type='manual') is never
        "the day's run".  Every reader that means the SCHEDULED run applies
        this -- the SOD idempotency hook, the queue's lookbacks, the orphan
        reaper, regeneration, re-run pinning, baselines, dependency polling
        -- so a Run Now can own a full step record without changing anything
        the schedule does.  NULL run_type (legacy rows) is not manual."""
        from sqlalchemy import or_
        # 2026-09-27 -- a DRY RUN (run_type='dry_run', core/feed_engine.py
        # ``dry_run=True``) is a manual run that delivers nothing, so it is
        # excluded by the same rule: it must never be "the day's run" for
        # SOD idempotency, the cron, the baselines or the orphan reaper.
        return or_(FeedRun.run_type.is_(None),
                   FeedRun.run_type.notin_(("manual", "dry_run")))

    def get_feed_run_by_feed_date(self, feed_config_id: int, business_date) -> Optional[dict]:
        """THE day's run for (feed, date) -- the SOD generator's idempotency
        hook and 12 other callers.

        Edge-case sweep 2026-09-24: this was ``.first()`` with NO ORDER BY.
        Since Foundation P a backfill writes a SECOND row for a date that
        already has one, so on any backfilled date every caller got whichever
        row the database returned first -- a status could be written onto the
        wrong run.  Deterministic now: the day's PRIMARY row (anything not
        triggered by a backfill) before a backfill row, oldest first.
        """
        from sqlalchemy import case as _case
        with self.get_session(read_only=True) as session:
            row = (session.query(FeedRun).filter(
                FeedRun.feed_config_id == feed_config_id,
                FeedRun.business_date == business_date,
                self.manual_run_excluded(),
            ).order_by(
                _case((FeedRun.triggered_by == "backfill", 1), else_=0),
                FeedRun.id.asc(),
            ).first())
            return row.to_dict() if row else None

    def list_feed_run_keys(self, business_date_from, business_date_to,
                           feed_ids: Optional[List[int]] = None) -> set:
        """The (feed_config_id, business_date) pairs that have a day's run in
        the window -- ONE query for a whole SOD pass (2026-10-11), under the
        SAME filter as ``get_feed_run_by_feed_date`` (``manual_run_excluded``:
        a Run Now / dry run is never the day's run; a backfill row counts).
        Two columns only: at 4,000 daily feeds over a 45-day window that is
        180k tuples, not 180k rows.  ``feed_ids`` narrows it (chunked IN)."""
        out: set = set()
        with self.get_session(read_only=True) as session:
            base = (session.query(FeedRun.feed_config_id, FeedRun.business_date)
                    .filter(FeedRun.business_date >= business_date_from,
                            FeedRun.business_date <= business_date_to,
                            self.manual_run_excluded())
                    .distinct())
            if feed_ids is None:
                chunks = [None]
            else:
                ids = sorted({int(x) for x in feed_ids})
                if not ids:
                    return out
                chunks = [ids[i:i + 500] for i in range(0, len(ids), 500)]
            for chunk in chunks:
                q = base if chunk is None else base.filter(FeedRun.feed_config_id.in_(chunk))
                for fid, bd in q.all():
                    out.add((int(fid), bd))
        return out

    # ── SOD gap records (2026-10-11) ──────────────────────────────────

    def add_feed_run_sql(self, row: dict) -> None:
        """Append one rendered-SQL row (``core/feed/executed_sql.py``)."""
        from core.db.models import FeedRunSql
        with self.get_session() as session:
            session.add(FeedRunSql(**{k: v for k, v in row.items() if hasattr(FeedRunSql, k)}))
            session.flush()

    def list_feed_run_sql(self, feed_run_id: int) -> List[dict]:
        """Every rendered-SQL row of one run, oldest first."""
        from core.db.models import FeedRunSql
        with self.get_session() as session:
            rows = (session.query(FeedRunSql).filter(FeedRunSql.feed_run_id == int(feed_run_id))
                    .order_by(FeedRunSql.rendered_at, FeedRunSql.id).all())
            return [{"id": r.id, "feed_run_id": r.feed_run_id, "feed_config_id": r.feed_config_id,
                     "side": r.side or "", "field": r.field, "lane": r.lane, "sql": r.sql_text,
                     "params": r.params or {},
                     "rendered_at": r.rendered_at.isoformat() if r.rendered_at else None}
                    for r in rows]

    def record_feed_sod_gaps(self, rows: List[dict]) -> int:
        """Insert the gap rows that are NEW -- unique per (feed, business
        date); an existing row (open or resolved) is left as it is.  Returns
        how many landed."""
        if not rows:
            return 0
        from sqlalchemy import tuple_ as _tuple
        n = 0
        with self.get_session() as session:
            keys = [(int(r["feed_config_id"]), r["business_date"]) for r in rows]
            have = set()
            for i in range(0, len(keys), 500):
                chunk = keys[i:i + 500]
                for fid, bd in (session.query(FeedSodGap.feed_config_id,
                                              FeedSodGap.business_date)
                                .filter(_tuple(FeedSodGap.feed_config_id,
                                               FeedSodGap.business_date).in_(chunk))
                                .all()):
                    have.add((int(fid), bd))
            for r in rows:
                key = (int(r["feed_config_id"]), r["business_date"])
                if key in have:
                    continue
                have.add(key)
                session.add(FeedSodGap(**{k: v for k, v in r.items()
                                          if hasattr(FeedSodGap, k)}))
                n += 1
            session.flush()
        return n

    def list_feed_sod_gaps(self, feed_id: Optional[int] = None, *,
                           open_only: bool = True,
                           business_date_from=None, business_date_to=None,
                           feed_ids: Optional[List[int]] = None,
                           limit: Optional[int] = 1000) -> List[dict]:
        """The gap records, newest business date first."""
        with self.get_session(read_only=True) as session:
            q = session.query(FeedSodGap)
            if feed_id is not None:
                q = q.filter(FeedSodGap.feed_config_id == int(feed_id))
            if feed_ids is not None:
                ids = [int(x) for x in feed_ids]
                if not ids:
                    return []
                q = q.filter(FeedSodGap.feed_config_id.in_(ids))
            if open_only:
                q = q.filter(FeedSodGap.resolved_at.is_(None))
            if business_date_from is not None:
                q = q.filter(FeedSodGap.business_date >= business_date_from)
            if business_date_to is not None:
                q = q.filter(FeedSodGap.business_date <= business_date_to)
            q = q.order_by(FeedSodGap.business_date.desc(), FeedSodGap.feed_config_id.asc())
            if limit:
                q = q.limit(int(limit))
            return [r.to_dict() for r in q.all()]

    def resolve_feed_sod_gaps(self, keys, *, how: str = "run_exists",
                              now=None) -> int:
        """Stamp ``resolved_at`` on the OPEN gaps named by ``keys`` =
        [(feed_config_id, business_date)].  Returns how many were stamped."""
        keys = [(int(k[0]), k[1]) for k in (keys or [])]
        if not keys:
            return 0
        from sqlalchemy import tuple_ as _tuple
        now = now or datetime.now(timezone.utc)
        n = 0
        with self.get_session() as session:
            for i in range(0, len(keys), 500):
                chunk = keys[i:i + 500]
                rows = (session.query(FeedSodGap)
                        .filter(FeedSodGap.resolved_at.is_(None),
                                _tuple(FeedSodGap.feed_config_id,
                                       FeedSodGap.business_date).in_(chunk))
                        .all())
                for row in rows:
                    row.resolved_at = now
                    row.resolved_how = str(how)[:40]
                    n += 1
            session.flush()
        return n

    def feed_run_for_execution(self, execution: Optional[dict]) -> Optional[dict]:
        """The feed_run an EXECUTION belongs to -- or None when it belongs to
        none.  THE link for callers that hold only an execution row (the
        spark_k8s reconciler, the timeout sweeper).

        Edge-case sweep 2026-09-24: those callers guessed the run as
        ``(feed, started_at.date())``.  A manual "Run Now" owns NO run -- so
        when one finished on spark_k8s the reconciler wrote completed/failed
        onto the day's SCHEDULED row (no status check at all); a still-pending
        SOD row marked completed is never claimed, and the scheduled delivery
        silently never happens.  The timeout sweeper failed that row the same
        way.  And started_at's date is the wrong day for a run of yesterday's
        business date started after midnight.

        In order: the step rows' link (exact); (feed, business_date,
        build_id) -- the pin stamps the same build on run and execution
        (exact); a MANUAL execution with neither -> None (a Run Now has no
        run); otherwise the day's primary row for the execution's
        business_date (the legacy shape: an old row with no build stamp).
        """
        if not execution:
            return None
        try:
            from core.feed.step_model.store import run_id_for_execution
            rid = run_id_for_execution(self, str(execution.get("execution_id") or ""))
        except Exception:
            rid = None
        if rid is not None:
            return self.get_feed_run(int(rid))
        feed_id = execution.get("feed_config_id")
        bdate = execution.get("business_date")
        build = execution.get("build_id")
        if feed_id and bdate and build:
            with self.get_session(read_only=True) as session:
                row = (session.query(FeedRun).filter(
                    FeedRun.feed_config_id == feed_id,
                    FeedRun.business_date == bdate,
                    FeedRun.build_id == build,
                ).order_by(FeedRun.id.asc()).first())
                if row:
                    return row.to_dict()
        if str(execution.get("trigger_type") or "").lower() == "manual":
            # A Run Now owns the manual run whose build_id is derived from
            # its execution id (feed_executor.run_feed step 3b) -- exact.
            # None when it has none (created before 2026-09-24, or the
            # create failed): never the day's scheduled run.
            with self.get_session(read_only=True) as session:
                row = (session.query(FeedRun).filter(
                    FeedRun.run_type == "manual",
                    FeedRun.build_id == f"manual-{execution.get('execution_id')}"[:40],
                ).first())
                return row.to_dict() if row else None
        if feed_id and bdate:
            return self.get_feed_run_by_feed_date(int(feed_id), bdate)
        return None

    def list_feed_runs_for_feed_date(self, feed_config_id: int,
                                     business_date,
                                     include_manual: bool = False) -> List[dict]:
        """EVERY run row for (feed, business_date) — since Foundation P a
        pair can legitimately hold several rows (the legacy NULL-build_id
        row plus one per backfill/re-run build).  The backfill planner
        (FR-OPS-09) uses this to say, per date, whether a run is already
        pending/running and how many prior attempts exist — a preview
        that cannot see the existing rows would promise runs it will not
        create."""
        bd = _coerce_business_date(business_date)
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedRun)
                    .filter(FeedRun.feed_config_id == int(feed_config_id),
                            FeedRun.business_date == bd,
                            *( () if include_manual else (self.manual_run_excluded(),)))
                    .order_by(FeedRun.created_at.asc(), FeedRun.id.asc())
                    .all())
            return [r.to_dict() for r in rows]

    def feed_run_delivery_suppressed(self, feed_config_id: int,
                                     business_date) -> bool:
        """FR-OPS-08 (2026-09-02) — is the run CURRENTLY EXECUTING for
        (feed, business_date) one that must PRODUCE but NOT deliver?

        Consulted by ``DeliveryHopRunner.execute_chain`` before any
        transport is touched.  Delivery happens while the owning
        feed_runs row is in status 'running', so the resolution is:

        * ANY 'running' row for the pair with ``suppress_delivery`` set
          → suppressed.  When a suppressed backfill and an unsuppressed
          scheduled run of the SAME (feed, date) are somehow running at
          once, the ambiguity resolves toward NOT delivering — a
          suppressed scheduled delivery is recoverable (the hop rows say
          why, and an operator retry of the hop sends it), while a
          delivered backfill is the re-delivery incident FR-OPS-08
          exists to prevent;
        * no 'running' row → False: legacy paths that deliver without a
          bound run row keep delivering exactly as before.

        DB errors PROPAGATE — a gate that cannot be read must not
        silently mean "send".
        """
        if business_date is None:
            # A legacy execution row with no business_date has no run
            # identity to look up — no run knowledge, deliver as before.
            return False
        bd = _coerce_business_date(business_date)
        from sqlalchemy.exc import OperationalError, ProgrammingError
        try:
            with self.get_session(read_only=True) as session:
                rows = (session.query(FeedRun.id,
                                      FeedRun.suppress_delivery)
                        .filter(FeedRun.feed_config_id
                                == int(feed_config_id),
                                FeedRun.business_date == bd,
                                FeedRun.status == "running")
                        .all())
        except (OperationalError, ProgrammingError) as exc:
            # ONLY the missing-table shape fails open: a seam without a
            # feed_runs table (partial-schema test daos, standalone
            # delivery tooling) has no run ledger AT ALL — that is "no
            # run knowledge", the documented pre-backfill behaviour.
            # Any other DB error still propagates: a ledger that EXISTS
            # but cannot be read must not silently mean "send".
            msg = str(exc).lower()
            if "no such table" in msg or "does not exist" in msg                     or "undefinedtable" in msg:
                logger.warning(
                    "[feeds] feed_runs table absent on this seam — "
                    "run-level delivery suppression has no ledger to "
                    "read and stays inactive: %s", exc)
                return False
            raise
        suppressed = [int(r[0]) for r in rows if bool(r[1])]
        if suppressed:
            logger.info(
                "[feeds] delivery for feed %s / %s is SUPPRESSED by "
                "running feed_run(s) %s (suppress_delivery set — "
                "backfill without deliver=true)",
                feed_config_id, bd, suppressed)
            return True
        return False

    def list_feed_runs(self, business_date=None, status=None, limit: int = 200,
                       offset: int = 0, exclude_wait: bool = False,
                       business_date_from=None,
                       business_date_to=None,
                       include_pending_backfills: bool = False,
                       include_manual: bool = False,
                       decided_since=None,
                       include_handed_over_manual: bool = False) -> List[dict]:
        """Phase 4 (2026-08-23) additions:

        ``exclude_wait=True`` — filter dependency-gated
        ``action_decision='WAIT'`` rows in SQL.  The queue worker used to
        filter WAIT in Python AFTER the LIMIT — a page full of WAIT rows
        starved runnable lower-priority rows beyond the fetch window.

        ``business_date_from``/``business_date_to`` — inclusive range for
        the queue worker's lookback window (ONE query, not one per day).
        Ignored when ``business_date`` (exact) is given.

        ``include_pending_backfills`` (FR-OPS-06, 2026-09-02) — widen any
        date filter to ALSO admit pending ``run_type='backfill'`` rows.
        A backfill's business_date is historical BY DEFINITION, so a
        date-window poll that excludes it makes backfill unexecutable —
        the lookback window caps how far back SCHEDULED work is retried,
        never whether declared backfill work runs.  The queue worker
        passes True; date-scoped UI listings keep the default False and
        see backfill rows only under their own business_date.  2026-10-03:
        the same widening admits a pending run started by its UPSTREAM's
        completion (``triggered_by='upstream_completion'``) -- its business
        date is the upstream's, which is historical when an old date was
        delivered (a delivering backfill, a Run Now of last week), and a
        pending row no poll can see is a run that silently never happens.

        Ordering is most-important-first via
        ``core.feed.claims.priority_order_clause`` — the priority
        DIRECTION (1 = highest since 2026-09-02) is declared there and
        nowhere else.
        """
        from sqlalchemy import and_, or_
        from core.feed.claims import priority_order_clause
        with self.get_session(read_only=True) as session:
            q = session.query(FeedRun)
            date_clause = None
            if business_date is not None:
                date_clause = (FeedRun.business_date == business_date)
            else:
                parts = []
                if business_date_from is not None:
                    parts.append(FeedRun.business_date >= business_date_from)
                if business_date_to is not None:
                    parts.append(FeedRun.business_date <= business_date_to)
                if parts:
                    date_clause = and_(*parts)
            if date_clause is not None:
                if include_pending_backfills:
                    # 2026-10-11: a SOD CATCH-UP row (a missed due date created
                    # on a later pass) is historical by construction too --
                    # the queue's lookback (3 days) is shorter than the
                    # catch-up window (7), so without this admission the row
                    # SOD just created would sit pending for ever.
                    q = q.filter(or_(date_clause,
                                     and_(or_(FeedRun.run_type == "backfill",
                                              FeedRun.triggered_by.in_(
                                                  (FEED_RUN_UPSTREAM_TRIGGER,
                                                   FEED_RUN_SOD_CATCHUP_TRIGGER))),
                                          FeedRun.status == "pending"),
                                     # 2026-10-11: the lookback measures the
                                     # DECISION to run, not the business date --
                                     # a pending run CREATED or RELEASED within
                                     # the window is admitted whatever its date
                                     # (a month-end whose data arrives a week
                                     # late; a run-now for a past month-end).
                                     *([and_(FeedRun.status == "pending",
                                             or_(FeedRun.created_at >= decided_since,
                                                 FeedRun.released_at >= decided_since))]
                                       if decided_since is not None else [])))
                else:
                    q = q.filter(date_clause)
            if status is not None:
                q = q.filter(FeedRun.status == status)
            if not include_manual:
                # Manual Run Now runs are listed only where a PERSON is
                # looking at runs (the Today page passes include_manual);
                # the queue worker, SLA tracker, run surface and bulk
                # re-run keep seeing the schedule alone.
                if include_handed_over_manual:
                    # 2026-11-02 -- the queue worker: a manual run an API pod
                    # HANDED OVER (core/feed/handover.py) is its to run; every
                    # other manual row stays excluded.
                    q = q.filter(or_(self.manual_run_excluded(),
                                     FeedRun.handed_over_at.isnot(None)))
                else:
                    q = q.filter(self.manual_run_excluded())
            if exclude_wait:
                q = q.filter(or_(FeedRun.action_decision.is_(None),
                                 FeedRun.action_decision != "WAIT"))
            rows = (q.order_by(priority_order_clause(FeedRun.priority),
                               FeedRun.scheduled_time.asc())
                     .offset(offset).limit(limit).all())
            return [r.to_dict() for r in rows]

    def list_feed_runs_for_pairs(self, pairs) -> List[dict]:
        """Every run row of the given (feed_config_id, business_date) pairs
        -- the board by RUN date reads each feed's derived business date
        (2026-10-13).  Manual Run Now rows left out, as ``list_feed_runs``."""
        from sqlalchemy import tuple_
        todo = sorted({(int(f), d) for f, d in pairs or []})
        out: List[dict] = []
        with self.get_session(read_only=True) as session:
            for i in range(0, len(todo), 500):
                rows = (session.query(FeedRun)
                        .filter(self.manual_run_excluded(),
                                tuple_(FeedRun.feed_config_id, FeedRun.business_date).in_(todo[i:i + 500]))
                        .all())
                out += [r.to_dict() for r in rows]
        return out

    def _write_feed_run(self, run_id: int, data: dict) -> Optional[dict]:
        with self.get_session() as session:
            row = session.query(FeedRun).filter(FeedRun.id == run_id).first()
            if not row:
                return None
            for k, v in data.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def update_feed_run(self, run_id: int, data: dict) -> Optional[dict]:
        """Same 32-bit-counter survival guard as ``update_feed_execution``.

        ``feed_runs`` has no JSON column to park the true values in, but the
        engine writes the same counters to ``feed_executions`` on every run, so
        they are preserved there.  Here the requirement is only that a 2 GB feed
        still reaches a terminal state instead of being stranded 'running'.
        """
        try:
            out = self._write_feed_run(run_id, data)
            self._release_slots_of_a_run_that_left(run_id, data)
            return out
        except Exception as exc:
            oversized = _oversized_int_fields(data)
            if not oversized or not _is_numeric_overflow(exc):
                raise
            logger.error(
                "[db] feed_run %s: %s exceed(s) this database's 32-bit counter "
                "column(s) -- writing the row WITHOUT them so the run still "
                "reaches its terminal state.  Repair with: %s",
                run_id, sorted(oversized),
                "; ".join(f"ALTER TABLE feed_runs ALTER COLUMN {k} TYPE bigint"
                          for k in sorted(oversized)),
            )
            out = self._write_feed_run(
                run_id, {k: v for k, v in data.items() if k not in oversized})
            self._release_slots_of_a_run_that_left(run_id, data)
            return out

    #: a run in one of these holds no connection slot
    _SLOTLESS_RUN_STATES = frozenset({"completed", "failed", "cancelled", "skipped"})

    def _release_slots_of_a_run_that_left(self, run_id: int, data: dict) -> None:
        """A run that ENDED, or was put back on the queue by a re-run / a
        reaper (``pending`` with ``started_at`` cleared), holds no connection
        slot (2026-10-14).  Found live: the pod running a feed was OOM-killed,
        its execution was cancelled and the run re-run -- and the re-run sat
        "waits -- already_held" behind its OWN dead claim for the claim
        reaper's hour.  Slots taken for a pending run by a worker that is
        about to claim it are untouched: that write is ``running``."""
        status = str((data or {}).get("status") or "")
        requeued = status == "pending" and "started_at" in data and data["started_at"] is None
        if status not in self._SLOTLESS_RUN_STATES and not requeued:
            return
        try:
            n = self.release_connection_claims(run_id=int(run_id))
            if n:
                logger.info("[claims] feed_run %s is %s: released %d connection slot(s)",
                            run_id, "back on the queue" if requeued else status, n)
        except Exception as exc:                            # noqa: BLE001
            logger.warning("[claims] feed_run %s: slots NOT released (%s) -- the claim "
                           "reaper frees them later", run_id, exc)

    def reclaim_stale_running_feed_runs(self, stale_after_seconds: int) -> int:
        """Phase 130 hotfix-13 sharding rescue: reset feed_runs rows
        that have been ``status='running'`` for longer than
        ``stale_after_seconds`` back to ``pending``.  Used when a worker
        pod crashes mid-execution and its rows are otherwise orphaned
        (since the dying pod can't transition them to completed/failed).

        Returns the count of reclaimed rows.  Caller is expected to log
        + audit non-zero counts (this is an unusual event).
        """
        if stale_after_seconds <= 0:
            return 0
        from datetime import datetime as _dt, timedelta as _td, timezone as _tz
        cutoff = _dt.now(_tz.utc) - _td(seconds=int(stale_after_seconds))
        with self.get_session() as session:
            count = session.query(FeedRun).filter(
                FeedRun.status == "running",
                FeedRun.started_at < cutoff,
            ).update({
                "status": "pending",
                "started_at": None,
                "error": f"reclaimed: claiming pod did not finish within {stale_after_seconds}s",
            }, synchronize_session=False)
            return int(count or 0)

    def count_pending_feed_runs(self, *, cap: int = 1000) -> dict:
        """How many feed_runs rows are sitting in ``pending``?

        2026-09-15 — the producer/consumer question.  A backfill, a SOD
        sweep and the external trigger route all CREATE pending rows;
        only a queue worker executes one.  Nothing could previously ask
        "is there work that nothing will run", so a backfill of twenty
        days returned 200 {"created": 20} while the health page said the
        native backend was fine and twenty files never appeared.

        BOUNDED on purpose.  The failover agent probes every 30 s and
        this is a COUNT on a table that grows forever; ``status`` is
        indexed but an unbounded count still scans every matching row.
        We count at most ``cap`` and say so — the alarm is "there IS
        stalled work", and "1000+" answers that as well as an exact
        number would.  ``exact`` is False only when the cap was reached.
        """
        cap = max(1, int(cap))
        with self.get_session(read_only=True) as session:
            n = int(session.query(FeedRun.id)
                    .filter(FeedRun.status == "pending")
                    .limit(cap).count() or 0)
        return {"pending": n, "exact": n < cap, "cap": cap}

    def claim_pending_feed_run(self, run_id: int, claimed_by: str = "queue_worker") -> Optional[dict]:
        """Atomic SELECT-FOR-UPDATE style claim — flip status pending
        -> running ONLY if the row is still pending.

        Returns the updated row dict on successful claim, or ``None``
        when the row was already claimed by another worker / pod.
        Safe to call from multiple processes; the conditional UPDATE
        returns rowcount=0 when someone else beat us to it.

        BF-594 (2026-05-30): writes ``claimed_by`` to the dedicated
        column instead of overwriting ``triggered_by``.  Previously
        every claimed row showed up in notifications / SLA scanner /
        notify-stage as ``triggered_by='queue_worker'`` regardless of
        the original source ("external" / "rerun" / "sod" / "manual"
        / username) — silent lineage loss that broke notification
        routing.  The new column preserves the original source.
        """
        with self.get_session() as session:
            count = session.query(FeedRun).filter(
                FeedRun.id == int(run_id),
                FeedRun.status == "pending",
            ).update({
                "status": "running",
                "started_at": datetime.now(timezone.utc),
                "claimed_by": claimed_by,
            }, synchronize_session=False)
            if count == 0:
                return None  # another worker won the race
            session.flush()
            row = session.query(FeedRun).filter(FeedRun.id == int(run_id)).first()
            return row.to_dict() if row else None

    def reset_feed_run_to_pending_if_owned(
        self, run_id: int, owned_by: str = "queue_worker",
    ) -> bool:
        """BF-593 / BF-594 (2026-05-30): conditional reset of a feed_run
        row from status='running' back to 'pending' — but only when the
        row is STILL owned by this worker.

        BF-594: now filters by ``claimed_by`` instead of ``triggered_by``
        so the lineage (original trigger source) is preserved AND the
        reset is correctly gated on this worker's claim.  Existing rows
        whose ``claimed_by`` is NULL (claimed before BF-594) fall
        through to ``triggered_by`` for back-compat — the unconditional-
        reset hazard returns there, but only for that narrow set of
        rows in flight at deploy time.

        The queue worker uses this when an in-process dispatch fails
        AFTER the atomic claim but BEFORE execute_feed gets a chance to
        run.  Without the conditional check, a cross-pod claim that
        arrived between our claim and the dispatch failure would have
        its `running` flip trampled back to `pending`, doubling-up the
        work on that row.

        Returns True if the reset happened (we still owned it), False
        if it didn't (another pod / worker now owns it).
        """
        from sqlalchemy import or_
        with self.get_session() as session:
            count = session.query(FeedRun).filter(
                FeedRun.id == int(run_id),
                FeedRun.status == "running",
                or_(
                    FeedRun.claimed_by == owned_by,
                    # Back-compat: pre-BF-594 rows had no claimed_by but
                    # the legacy claim wrote owned_by to triggered_by.
                    (FeedRun.claimed_by.is_(None))
                    & (FeedRun.triggered_by == owned_by),
                ),
            ).update({
                "status": "pending",
                "started_at": None,
            }, synchronize_session=False)
            session.flush()
            return int(count or 0) > 0

    # ── FeedControlFileFormat CRUD (Phase 130 hotfix-4) ───────────────────

    def create_feed_control_file_format(self, data: dict) -> dict:
        with self.get_session() as session:
            row = FeedControlFileFormat(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_feed_control_file_format(self, fmt_id: int,
                                     include_inactive: bool = False) -> Optional[dict]:
        """A switched-off format (core/config_active.py) is hidden unless the
        caller asks -- the admin screen lists inactive formats on purpose, and
        a run reads the format its feed NAMES (a delete is refused while any
        feed names it, so only an edit can switch a named one off)."""
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            q = session.query(FeedControlFileFormat).filter(
                FeedControlFileFormat.id == fmt_id,
            )
            if not include_inactive:
                q = q.filter(active_clause(FeedControlFileFormat))
            row = q.first()
            return row.to_dict() if row else None

    def get_feed_control_file_format_by_name(self, name: str) -> Optional[dict]:
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            row = session.query(FeedControlFileFormat).filter(
                FeedControlFileFormat.name == name,
                active_clause(FeedControlFileFormat),
            ).first()
            return row.to_dict() if row else None

    def list_feed_control_file_formats(self, is_active: bool = None) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(FeedControlFileFormat)
            if is_active is not None:
                q = q.filter(FeedControlFileFormat.is_active == is_active)
            return [r.to_dict() for r in q.order_by(FeedControlFileFormat.name).all()]

    def update_feed_control_file_format(self, fmt_id: int, data: dict) -> Optional[dict]:
        with self.get_session() as session:
            row = session.query(FeedControlFileFormat).filter(
                FeedControlFileFormat.id == fmt_id,
            ).first()
            if not row:
                return None
            for k, v in data.items():
                if hasattr(row, k):
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def delete_feed_control_file_format(self, fmt_id: int) -> bool:
        """Switch the format OFF (2026-10-30, core/config_active.py)."""
        from core.config_active import switch_off
        with self.get_session() as session:
            row = session.query(FeedControlFileFormat).filter(
                FeedControlFileFormat.id == fmt_id,
            ).first()
            if not row:
                return False
            switch_off(row)
            return True

    # ── Phase 131-B — FeedRowCountBaseline ────────────────────────────────

    def get_feed_row_count_baseline(self, feed_config_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            row = session.query(FeedRowCountBaseline).filter(
                FeedRowCountBaseline.feed_config_id == int(feed_config_id),
            ).first()
            return row.to_dict() if row else None

    def upsert_feed_row_count_baseline(self, feed_config_id: int,
                                        data: dict) -> dict:
        """Insert-or-update a baseline row.  ``data`` carries the
        recomputed stats from ``row_count_check.recompute_baseline_from_history``."""
        with self.get_session() as session:
            row = session.query(FeedRowCountBaseline).filter(
                FeedRowCountBaseline.feed_config_id == int(feed_config_id),
            ).first()
            if row is None:
                row = FeedRowCountBaseline(feed_config_id=int(feed_config_id))
                session.add(row)
            for k, v in (data or {}).items():
                if hasattr(row, k):
                    setattr(row, k, v)
            row.last_updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_recent_completed_feed_runs(self, feed_config_id: int,
                                         since: datetime,
                                         limit: int = 50) -> List[dict]:
        """Used by the baseline-refresh job — recent successful runs for
        one feed.  Ordered newest-first."""
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedRun)
                    .filter(FeedRun.feed_config_id == int(feed_config_id),
                             FeedRun.status == "completed",
                             FeedRun.completed_at >= since,
                             self.manual_run_excluded())
                    .order_by(FeedRun.completed_at.desc())
                    .limit(limit).all())
            return [r.to_dict() for r in rows]

    # ── Phase 131-A — ETL Dependencies ────────────────────────────────────

    def list_etl_dependency_types(self, is_active: Optional[bool] = True) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(EtlDependencyType)
            if is_active is not None:
                q = q.filter(EtlDependencyType.is_active == bool(is_active))
            return [r.to_dict() for r in q.order_by(EtlDependencyType.dependency_type).all()]

    def upsert_etl_dependency_type(self, data: dict) -> dict:
        """Idempotent insert on (dependency_type)."""
        with self.get_session() as session:
            row = session.query(EtlDependencyType).filter(
                EtlDependencyType.dependency_type == data["dependency_type"],
            ).first()
            if row is None:
                row = EtlDependencyType(**data)
                session.add(row)
            else:
                for k, v in data.items():
                    if hasattr(row, k):
                        setattr(row, k, v)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_etl_dependency_mappings(self, etl_id: int) -> List[dict]:
        with self.get_session(read_only=True) as session:
            rows = session.query(EtlDependencyMapping).filter(
                EtlDependencyMapping.etl_id == int(etl_id),
                EtlDependencyMapping.is_active == True,  # noqa: E712
            ).all()
            return [r.to_dict() for r in rows]

    def list_active_etl_dependency_rows_by_etl_id(self) -> Dict[int, List[dict]]:
        """``{etl_id: [{"id", "dependency_key"}, ...]}`` for EVERY active
        mapping, in one three-column query (2026-10-10).  The FR-DEP-22
        cycle check and the FR-OPS-14 downstream finder used to ask
        ``list_etl_dependency_mappings`` once PER FEED -- N queries per
        save, N^2 per template apply (core/feed/authoring_index.py)."""
        with self.get_session(read_only=True) as session:
            rows = session.query(EtlDependencyMapping.etl_id,
                                 EtlDependencyMapping.id,
                                 EtlDependencyMapping.dependency_key).filter(
                EtlDependencyMapping.is_active == True,  # noqa: E712
            ).order_by(EtlDependencyMapping.id.asc()).all()
            out: Dict[int, List[dict]] = {}
            for etl_id, mid, key in rows:
                out.setdefault(int(etl_id), []).append(
                    {"id": mid, "dependency_key": str(key or "")})
            return out

    # ── Feed template apply as a JOB (2026-10-10) ─────────────────────

    def claim_feed_template_apply(self, template_id: int, job_id: str,
                                  previous_job_id: Optional[str]) -> bool:
        """One apply at a time per template: a compare-and-swap on
        ``feed_templates.apply_job_id`` -- the UPDATE lands only while the
        column still holds ``previous_job_id`` (the job the caller read, or
        NULL for never applied).  Two requests reading the same row race
        here and exactly one returns True."""
        from core.db.models import FeedTemplate
        with self.get_session() as session:
            q = session.query(FeedTemplate).filter(FeedTemplate.id == int(template_id))
            if previous_job_id is None:
                q = q.filter(FeedTemplate.apply_job_id.is_(None))
            else:
                q = q.filter(FeedTemplate.apply_job_id == str(previous_job_id))
            n = q.update({FeedTemplate.apply_job_id: str(job_id)},
                         synchronize_session=False)
            session.flush()
            return int(n or 0) == 1

    def set_feed_template_apply_status(self, template_id: int, job_id: str,
                                       status: dict) -> bool:
        """The job's record, written by its owner only: a write from a job
        that no longer holds the claim (superseded after a dead heartbeat)
        is dropped, and says so by returning False."""
        from core.db.models import FeedTemplate
        with self.get_session() as session:
            n = (session.query(FeedTemplate)
                 .filter(FeedTemplate.id == int(template_id),
                         FeedTemplate.apply_job_id == str(job_id))
                 .update({FeedTemplate.apply_status: dict(status)},
                         synchronize_session=False))
            session.flush()
            return int(n or 0) == 1

    def create_etl_dependency_mapping(self, data: dict) -> dict:
        with self.get_session() as session:
            row = EtlDependencyMapping(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def delete_etl_dependency_mapping(self, mapping_id: int) -> bool:
        with self.get_session() as session:
            row = session.query(EtlDependencyMapping).filter(
                EtlDependencyMapping.id == int(mapping_id),
            ).first()
            if not row:
                return False
            session.delete(row)
            return True

    def record_etl_dependency_tracking(self, *, dependency_type_id: int,
                                        dependency_key: str,
                                        business_date,
                                        action: str,
                                        comments: Optional[str] = None) -> dict:
        """Upsert one tracking row on (type_id, key, business_date).
        Called by whatever process owns the dependency arrival
        notification (Kafka consumer, ETL job, /api admin endpoint)."""
        with self.get_session() as session:
            row = session.query(EtlDependencyTracking).filter(
                EtlDependencyTracking.dependency_type_id == int(dependency_type_id),
                EtlDependencyTracking.dependency_key == dependency_key,
                EtlDependencyTracking.business_date == business_date,
            ).first()
            if row is None:
                row = EtlDependencyTracking(
                    dependency_type_id=int(dependency_type_id),
                    dependency_key=dependency_key,
                    business_date=business_date,
                    action=action,
                    comments=comments,
                )
                session.add(row)
            else:
                row.action = action
                if comments is not None:
                    row.comments = comments
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_etl_dependency_mappings_with_tracking(self, etl_id: int,
                                                     business_date) -> List[dict]:
        """Join used by core.feed.etl_dependency.check_dependencies —
        every mapping for the etl_id with its tracking row (if any) for
        the given business_date."""
        return self.list_etl_dependency_mappings_with_tracking_bulk(
            [int(etl_id)], business_date).get(int(etl_id), [])

    def list_etl_dependency_mappings_with_tracking_bulk(self, etl_ids, business_date
                                                        ) -> Dict[int, List[dict]]:
        """The same rows for MANY dependency key sets in one statement per
        500 ids (2026-10-25, the Dependencies & SLA tracker reads a whole
        date): ``{etl_id: [row, ...]}``, every id asked for present (an id
        with no mapping maps to ``[]``).  ONE row builder for both readers."""
        ids = sorted({int(i) for i in etl_ids})
        out: Dict[int, List[dict]] = {i: [] for i in ids}
        with self.get_session(read_only=True) as session:
            for start in range(0, len(ids), 500):
                chunk = ids[start:start + 500]
                # LEFT JOIN — pending mappings have NULL tracking rows.
                rows = (session.query(
                            EtlDependencyMapping, EtlDependencyType, EtlDependencyTracking,
                        )
                        .join(EtlDependencyType,
                               EtlDependencyType.id == EtlDependencyMapping.dependency_type_id)
                        .outerjoin(EtlDependencyTracking,
                                    (EtlDependencyTracking.dependency_type_id ==
                                     EtlDependencyMapping.dependency_type_id) &
                                    (EtlDependencyTracking.dependency_key ==
                                     EtlDependencyMapping.dependency_key) &
                                    (EtlDependencyTracking.business_date == business_date))
                        .filter(EtlDependencyMapping.etl_id.in_(chunk),
                                 EtlDependencyMapping.is_active == True)  # noqa: E712
                        .order_by(EtlDependencyMapping.id.asc())
                        .all())
                for mapping, type_row, tracking in rows:
                    out[int(mapping.etl_id)].append(
                        self._dependency_mapping_row(mapping, type_row, tracking))
        return out

    @staticmethod
    def _dependency_mapping_row(mapping, type_row, tracking) -> dict:
        """One mapping with its tracking row for the date (or none)."""
        return {
            "mapping_id":     int(mapping.id),
            # 2026-10-11 -- the feed's key, so a source whose declaration
            # carries {TOKEN}s (iceberg_commit partition_values) can
            # render them from the feed's parameters at the gate.
            "etl_id":         int(mapping.etl_id),
            "type_id":        int(type_row.id),
            "type_name":      type_row.dependency_type,
            "dependency_key": mapping.dependency_key,
            "action":         (tracking.action if tracking else None),
            "updated_at":     (tracking.updated_at if tracking else None),
            # FR-DEP-08 — whose calendar governs this dependency.
            # The gate needs it to tell NOT-EXPECTED from NOT-MET.
            "calendar_name":  mapping.calendar_name,
            # FR-DEP-24 — the author's expected row count.  The
            # gate's partial-upstream check ("says COMPLETE but
            # loaded 60% of its rows") reads this key; until it
            # was projected here the check had no producer on
            # either side and could not fire on any row ever
            # written.  None means NO CHECK, never zero.
            "expected_rows":  mapping.expected_rows,
            # The join already filters on business_date, so a
            # returned row IS for the date asked about — carried
            # explicitly so the gate's stale-satisfaction guard
            # (FR-DEP-17) can assert it rather than assume it.
            "business_date":  (tracking.business_date
                               if tracking else None),
            # 2026-09-27 — the DECLARED arrival sources and their
            # combination rule (core/feed/arrival_sources.py).  The
            # gate resolves each declared source and combines them;
            # None here means "no declaration" and the legacy
            # any-evidence rule applies to the row unchanged.
            "arrival_sources": mapping.arrival_sources,
            "require_mode":   mapping.require_mode,
            # The row's own comment — the tracking writer's words
            # ("loaded by OTG job 4711"), shown as plain-language
            # evidence for the ``etl`` source.
            "tracking_comments": (tracking.comments if tracking else None),
        }

    def list_etl_dependency_mappings_with_sources(self) -> List[dict]:
        """Every ACTIVE mapping that DECLARES arrival sources (2026-09-27).

        The Iceberg-commit arrival source asks, on every snapshot change,
        "which dependencies declared this table?" — the filter on the JSON
        column's CONTENT is done in Python because the two dialects spell
        JSON containment differently and the set is small (a mapping per
        declared dependency, not per run).
        """
        with self.get_session(read_only=True) as session:
            rows = session.query(EtlDependencyMapping).filter(
                EtlDependencyMapping.is_active == True,  # noqa: E712
                EtlDependencyMapping.arrival_sources.isnot(None),
            ).all()
            out = []
            for r in rows:
                if isinstance(r.arrival_sources, list) and r.arrival_sources:
                    out.append(r.to_dict())
            return out

    # ── 2026-09-27 — Iceberg-commit inspections (evidence for the gate) ──

    def record_iceberg_commit_inspection(self, data: dict) -> Optional[dict]:
        """Insert one inspection row; ``None`` when (dependency, snapshot)
        was already inspected — the replay guard is the unique key, so two
        listeners on two pods cannot both record a snapshot."""
        from sqlalchemy.exc import IntegrityError
        from core.db.models import IcebergCommitInspection
        try:
            with self.get_session() as session:
                row = IcebergCommitInspection(**data)
                session.add(row)
                session.flush()
                session.refresh(row)
                return row.to_dict()
        except IntegrityError:
            return None

    def latest_iceberg_commit_inspection(self, dependency_name: str,
                                         bucket: Optional[str] = None,
                                         table_prefix: Optional[str] = None,
                                         ) -> Optional[dict]:
        """The most recent inspection for one dependency, or None.

        2026-10-08 -- optionally for ONE declared table (``bucket`` +
        ``table_prefix``): a dependency that declares two Iceberg tables
        has an inspection history per table, and "the latest inspection"
        of the dependency as a whole answered the wrong table's question
        (the replay guard and the unreadable verdict both read it).
        """
        from core.db.models import IcebergCommitInspection
        from core.table_prefix import prefix_matches
        with self.get_session(read_only=True) as session:
            q = (session.query(IcebergCommitInspection)
                 .filter(IcebergCommitInspection.dependency_name == dependency_name))
            if bucket is not None:
                q = q.filter(IcebergCommitInspection.bucket == bucket)
            if table_prefix is not None:
                q = q.filter(prefix_matches(IcebergCommitInspection.table_prefix,
                                            table_prefix))
            row = (q.order_by(IcebergCommitInspection.inspected_at.desc(),
                              IcebergCommitInspection.id.desc())
                   .first())
            return row.to_dict() if row else None

    def list_iceberg_commit_inspections(self, dependency_name: str,
                                        limit: int = 20) -> List[dict]:
        from core.db.models import IcebergCommitInspection
        with self.get_session(read_only=True) as session:
            q = (session.query(IcebergCommitInspection)
                 .filter(IcebergCommitInspection.dependency_name == dependency_name)
                 .order_by(IcebergCommitInspection.inspected_at.desc(),
                           IcebergCommitInspection.id.desc())
                 .limit(int(limit)))
            return [r.to_dict() for r in q.all()]

    # ── 2026-10-07 — file-arrival observations (evidence for the gate) ──

    def upsert_file_arrival_observation(self, data: dict) -> dict:
        """Record the watcher's LATEST look at one declared file source.

        One row per (dependency_name, business_date, spec_key), updated in
        place (``looks`` counts the passes).  Two pods racing the first
        insert: the loser's IntegrityError turns into an update of the
        winner's row.
        """
        from sqlalchemy.exc import IntegrityError
        from core.db.models import FileArrivalObservation
        key_cols = ("dependency_name", "business_date", "spec_key")
        mutable = ("connection_id", "location", "status", "data_files",
                   "control_found", "reason", "evidence", "observed_at")

        def _apply(session) -> Optional[dict]:
            row = (session.query(FileArrivalObservation)
                   .filter(*[getattr(FileArrivalObservation, k) == data[k]
                             for k in key_cols])
                   .first())
            if row is None:
                return None
            for k in mutable:
                if k in data:
                    setattr(row, k, data[k])
            row.looks = int(row.looks or 0) + 1
            session.flush()
            return row.to_dict()

        with self.get_session() as session:
            out = _apply(session)
            if out is not None:
                return out
        try:
            with self.get_session() as session:
                row = FileArrivalObservation(
                    **{k: data[k] for k in key_cols},
                    **{k: data[k] for k in mutable if k in data},
                    looks=1,
                    first_observed_at=data.get("observed_at")
                    or datetime.now(timezone.utc))
                session.add(row)
                session.flush()
                session.refresh(row)
                return row.to_dict()
        except IntegrityError:
            with self.get_session() as session:
                out = _apply(session)
                if out is None:
                    raise
                return out

    def get_file_arrival_observation(self, dependency_name: str, business_date,
                                     spec_key: str) -> Optional[dict]:
        """The latest observation of one declared file source, or None."""
        from core.db.models import FileArrivalObservation
        with self.get_session(read_only=True) as session:
            row = (session.query(FileArrivalObservation)
                   .filter(FileArrivalObservation.dependency_name == dependency_name,
                           FileArrivalObservation.business_date == business_date,
                           FileArrivalObservation.spec_key == spec_key)
                   .first())
            return row.to_dict() if row else None

    def list_pending_runs_needing_dep_check(self, limit: int = 500,
                                            after_id: Optional[int] = None,
                                            ) -> List[dict]:
        """Used by the dependency poller, the escalation sweep, the
        blocking index and the admin inspector — the pending feed_runs the
        dependency gate GOVERNS, each carrying ``etl_id`` = the feed's
        EFFECTIVE key (``core.feed.etl_dependency.effective_etl_id``:
        explicit etl_id, else the feed's own id).

        2026-09-27 — this used to select ``feed_configs.etl_id IS NOT
        NULL`` only, while the authoring routes store a feed's mappings
        under COALESCE(etl_id, id): a feed with UI-authored dependencies
        and no explicit etl_id was never scanned, so nothing ever flipped
        its runs to WAIT.  A run is selected when ANY of these hold, in
        SQL on both dialects:

          * its feed has an ACTIVE mapping under its effective key
            (the reason the poller exists);
          * its feed has an explicit etl_id (the legacy set, kept so a
            feed pointed at an ETL id with no mappings yet keeps its
            "deps ready (0 complete)" re-affirmation);
          * it is already held at WAIT -- so a run whose only dependency
            was REMOVED after the hold is released by the next tick
            rather than stuck until the 48 h escalation fails it.

        2026-10-10 -- ``after_id`` (keyset paging, the poller's call): the
        rows with ``id > after_id`` ordered by id, ``limit`` at a time, so a
        caller walks EVERY governed run rather than the first ``limit`` by
        priority.  4,000 feeds released by one month-end message used to
        leave rows 501+ at WAIT until the first 500 were CLAIMED (a RUN-
        decided pending row stays in the set) -- hours, on a 3-slot worker.
        Without ``after_id`` the order and cap are unchanged for the other
        readers (the escalation sweep, the blocking index, the inspector).
        """
        from sqlalchemy import func, or_
        from core.feed.claims import priority_order_clause
        from core.feed.etl_dependency import effective_etl_id
        with self.get_session(read_only=True) as session:
            effective_key = func.coalesce(FeedConfig.etl_id, FeedConfig.id)
            has_mapping = (session.query(EtlDependencyMapping.id)
                           .filter(EtlDependencyMapping.etl_id == effective_key,
                                   EtlDependencyMapping.is_active.is_(True))
                           .exists())
            q = (session.query(FeedRun, FeedConfig)
                 .join(FeedConfig, FeedConfig.id == FeedRun.feed_config_id)
                 .filter(FeedRun.status == "pending",
                         or_(has_mapping,
                             FeedConfig.etl_id.isnot(None),
                             FeedRun.action_decision == "WAIT"),
                         self.manual_run_excluded()))
            if after_id is not None:
                q = (q.filter(FeedRun.id > int(after_id))
                     .order_by(FeedRun.id.asc()))
            else:
                q = q.order_by(priority_order_clause(FeedRun.priority),
                               FeedRun.scheduled_time.asc())
            rows = q.limit(limit).all()
            out: List[dict] = []
            for run, cfg in rows:
                d = run.to_dict()
                d["etl_id"] = effective_etl_id({"id": cfg.id,
                                                "etl_id": cfg.etl_id})
                out.append(d)
            return out

    def seed_default_etl_dependency_types(self) -> int:
        """Idempotent seed of the canonical dependency-type catalogue.

        Mirrors OTG_DEPENDENCY_TYPE's expected values so the QS side has
        a starting catalogue before OTG integration.  Admin can edit
        names / disable rows via the API — values are NOT a business
        rule, just a convenience."""
        defaults = [
            {"dependency_type": "KAFKA",         "description": "Kafka topic arrival"},
            {"dependency_type": "ORACLE_TABLE",  "description": "Oracle table/partition loaded"},
            {"dependency_type": "FILE",          "description": "External file landed"},
            {"dependency_type": "API",           "description": "Upstream API responded"},
            # 2026-09-27 -- the label for the iceberg_commit arrival source
            # (core/feed/arrival_sources.py), so an Iceberg dependency is not
            # filed under FILE or KAFKA on every screen that lists it.
            {"dependency_type": "ICEBERG_TABLE", "description": "Iceberg table loaded for the date"},
        ]
        inserted = 0
        with self.get_session() as session:
            for d in defaults:
                existing = session.query(EtlDependencyType).filter(
                    EtlDependencyType.dependency_type == d["dependency_type"],
                ).first()
                if existing is None:
                    session.add(EtlDependencyType(**d))
                    inserted += 1
            session.flush()
        return inserted

    # ── Phase 131 control persistence (back-compat: original methods) ─────

    def seed_default_feed_control_file_formats(self) -> int:
        """Create the predefined templates if not already present.

        Idempotent — checks by name, only inserts missing rows.  Called
        from startup so a fresh install gets the canonical formats out
        of the box.  Admin can edit / clone / disable them via the UI.
        """
        defaults = _default_control_file_formats()
        inserted = 0
        with self.get_session() as session:
            for d in defaults:
                existing = session.query(FeedControlFileFormat).filter(
                    FeedControlFileFormat.name == d["name"],
                ).first()
                if existing is None:
                    session.add(FeedControlFileFormat(**d))
                    inserted += 1
            session.flush()
        return inserted

    # ── Feed identity (BRD 2026-09-02 §14.3 / D5 / FR-ID-01..03) ─────────
    # Appended 2026-09-02.  feed_configs.name is indexed but NOT unique in
    # the schema (models.py is owned by in-flight work), so uniqueness is
    # enforced at the API boundary via these methods, and pre-existing
    # violations are REPORTED — never refused at startup, never rewritten.

    def get_feed_ids_by_name(self, name: str,
                             exclude_feed_id: Optional[int] = None) -> List[int]:
        """Ids of feed_configs carrying ``name`` — CASE-INSENSITIVE.

        Case-insensitive because every downstream identity artifact
        collapses case: the Spark CR name is lowercased, filenames land
        on case-insensitive mounts, and support conversations do not
        distinguish GL_EXTRACT from gl_extract.  ``exclude_feed_id``
        lets a rename check ignore the feed being renamed.
        """
        from sqlalchemy import func
        with self.get_session(read_only=True) as session:
            q = session.query(FeedConfig.id).filter(
                func.lower(FeedConfig.name) == str(name).lower())
            if exclude_feed_id is not None:
                q = q.filter(FeedConfig.id != int(exclude_feed_id))
            return sorted(int(r[0]) for r in q.all())

    def list_feed_schedule_declarations(self, *, active_only: bool = True) -> List[dict]:
        """``[{"id", "name", "is_active", "schedule_declaration"}]`` for
        every feed (active ones by default) -- three columns, not the whole
        row, because the ON-COMPLETION hook asks "who is downstream of X?"
        on every terminal execution and the answer needs only the
        declarations (core/feed/upstream_completion.py)."""
        with self.get_session(read_only=True) as session:
            q = session.query(FeedConfig.id, FeedConfig.name,
                              FeedConfig.is_active,
                              FeedConfig.schedule_declaration)
            if active_only:
                # the SAME predicate list_feed_configs(is_active=True) uses
                q = q.filter(FeedConfig.is_active == True)  # noqa: E712
            return [{"id": int(r[0]), "name": r[1], "is_active": bool(r[2]),
                     "schedule_declaration": r[3]} for r in q.all()]

    def feed_has_ever_run(self, feed_id: int) -> bool:
        """True when the feed has EVER run — the rename-immutability gate.

        BRD §14.3: a rename after the first run breaks every historical
        reference (archives, alerts, filenames, audit).  Checks every
        run signal, OR-ed, so a partially-recorded run still counts:
        run_count / last_execution_id on the config row, any
        feed_executions row, any feed_runs row.
        """
        with self.get_session(read_only=True) as session:
            fc = session.query(FeedConfig).filter(
                FeedConfig.id == feed_id).first()
            if fc is None:
                return False
            if (fc.run_count or 0) > 0 or fc.last_execution_id is not None:
                return True
            if session.query(FeedExecution.id).filter(
                    FeedExecution.feed_config_id == feed_id).first() is not None:
                return True
            if session.query(FeedRun.id).filter(
                    FeedRun.feed_config_id == feed_id).first() is not None:
                return True
            return False

    def find_duplicate_feed_names(self) -> List[tuple]:
        """[(name_lower, [ids...])] for names carried by MORE THAN ONE feed.

        Case-insensitive grouping (same rationale as get_feed_ids_by_name).
        The live database may already hold duplicates — created before the
        uniqueness gate existed — and the platform's job is to DETECT and
        REPORT them, not to crash on them and not to rewrite them.
        """
        with self.get_session(read_only=True) as session:
            rows = session.query(FeedConfig.id, FeedConfig.name).all()
        by_name: Dict[str, List[int]] = {}
        for fid, fname in rows:
            by_name.setdefault(str(fname or "").lower(), []).append(int(fid))
        return sorted(
            (name, sorted(ids)) for name, ids in by_name.items()
            if len(ids) > 1
        )

    def report_feed_identity_issues(self) -> Dict[str, list]:
        """Startup-safe identity report: duplicates + non-conforming names.

        Logs at WARNING and returns the findings.  NEVER raises — a
        pre-existing bad name must not stop the platform from starting
        (hard requirement: existing feeds keep working; the platform
        reports, it does not refuse to boot and does not rewrite).
        """
        report: Dict[str, list] = {"duplicates": [], "nonconforming": []}
        try:
            report["duplicates"] = self.find_duplicate_feed_names()
            from core.feed.identity import validate_feed_name
            with self.get_session(read_only=True) as session:
                rows = session.query(FeedConfig.id, FeedConfig.name).all()
            for fid, fname in rows:
                try:
                    validate_feed_name(fname)
                except ValueError as exc:
                    report["nonconforming"].append(
                        (int(fid), str(fname), str(exc)))
            for name, ids in report["duplicates"]:
                logger.warning(
                    "Feed identity: name %r is carried by %d feeds (ids %s) "
                    "— alert keys, filenames and archive keys collide. "
                    "Rename all but one via create-new/retire-old.",
                    name, len(ids), ids)
            if report["nonconforming"]:
                logger.warning(
                    "Feed identity: %d existing feed name(s) do not conform "
                    "to the naming rules (kept working, reported only): %s",
                    len(report["nonconforming"]),
                    [(fid, nm) for fid, nm, _ in report["nonconforming"]])
        except Exception:
            logger.warning(
                "Feed identity report failed (non-fatal)", exc_info=True)
        return report

    # ── Foundation L — append-only event ledger (BRD 2026-09-02) ──────────
    # These methods INSERT and READ only.  There is deliberately no update
    # or delete path: state is a projection over the log, and a second
    # arrival is a NEW ROW, never an upsert (replay is otherwise
    # undecidable in principle — BRD §4).  core/feed/ledger.py is the API
    # over this seam and owns vocabulary validation + fail-open behaviour.
    # Models are imported locally so this block stays purely additive.

    def insert_run_event(self, data: dict) -> dict:
        """Append one run/step/decision event row.  Raises on DB failure —
        the fail-open wrapper lives in core/feed/ledger.py so a direct
        caller still sees the truth."""
        from core.db.models import RunEvent
        with self.get_session() as session:
            row = RunEvent(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def insert_dependency_event(self, data: dict) -> dict:
        """Append one dependency-arrival row (every arrival, not just the
        first — BRD §7.2).  Raises on DB failure; see insert_run_event."""
        from core.db.models import DependencyEvent
        with self.get_session() as session:
            row = DependencyEvent(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_run_events(self, feed_config_id: int, business_date=None) -> List[dict]:
        """Ledger rows for a feed, oldest first; optionally one business date."""
        from core.db.models import RunEvent
        with self.get_session(read_only=True) as session:
            q = session.query(RunEvent).filter(
                RunEvent.feed_config_id == feed_config_id)
            if business_date is not None:
                q = q.filter(RunEvent.business_date == business_date)
            return [r.to_dict() for r in q.order_by(RunEvent.id.asc()).all()]

    def list_run_events_for_date(self, business_date, event_types,
                                 limit: int = 500) -> List[dict]:
        """Ledger rows of the given types across EVERY feed for one business
        date, newest first (2026-09-27: the blocking panel's "skipped
        today" list).  ``event_types`` is a sequence of event_type values;
        an empty one returns nothing rather than everything."""
        from core.db.models import RunEvent
        types = [str(t) for t in (event_types or []) if t]
        if not types:
            return []
        with self.get_session(read_only=True) as session:
            q = (session.query(RunEvent)
                 .filter(RunEvent.business_date == business_date,
                         RunEvent.event_type.in_(types))
                 .order_by(RunEvent.id.desc())
                 .limit(int(limit)))
            return [r.to_dict() for r in q.all()]

    def list_dependency_events(self, dependency_name: str, business_date) -> List[dict]:
        """Every arrival for (dependency, business_date), in arrival order.

        Keyed by business date and joined on it — never relaxed, so
        yesterday's arrival cannot satisfy today's gate (FR-DEP-17).
        """
        from core.db.models import DependencyEvent
        with self.get_session(read_only=True) as session:
            q = (session.query(DependencyEvent)
                 .filter(DependencyEvent.dependency_name == dependency_name,
                         DependencyEvent.business_date == business_date)
                 .order_by(DependencyEvent.arrived_at.asc(),
                           DependencyEvent.id.asc()))
            return [r.to_dict() for r in q.all()]

    def list_dependency_events_on(self, business_date) -> Dict[str, List[dict]]:
        """Every arrival on ONE business date, grouped by dependency, each
        group in arrival order -- the rows ``list_dependency_events`` gives
        per name, read in one statement (2026-10-25, the tracker)."""
        from core.db.models import DependencyEvent
        out: Dict[str, List[dict]] = {}
        with self.get_session(read_only=True) as session:
            q = (session.query(DependencyEvent)
                 .filter(DependencyEvent.business_date == business_date)
                 .order_by(DependencyEvent.arrived_at.asc(), DependencyEvent.id.asc()))
            for r in q.all():
                out.setdefault(r.dependency_name, []).append(r.to_dict())
        return out

    def latest_dependency_event(self, dependency_name: str) -> Optional[dict]:
        """The most recent arrival of a dependency on ANY business date (its
        message's identity fields -- CODE, STORE, SOURCE, EVENT -- do not
        change between dates), or None."""
        from core.db.models import DependencyEvent
        with self.get_session(read_only=True) as session:
            row = (session.query(DependencyEvent)
                   .filter(DependencyEvent.dependency_name == dependency_name)
                   .order_by(DependencyEvent.arrived_at.desc(), DependencyEvent.id.desc()).first())
            return row.to_dict() if row else None

    def latest_dependency_events(self, names) -> Dict[str, dict]:
        """The most recent arrival of EACH named dependency on any business
        date -- ``latest_dependency_event`` for many names in one statement
        per 500 names (2026-10-25: a feed may declare 500+ dependencies).
        Same rule: the latest ``arrived_at``, then the highest id."""
        from sqlalchemy import and_, func
        from core.db.models import DependencyEvent
        want = sorted({str(n) for n in names if n})
        out: Dict[str, dict] = {}
        with self.get_session(read_only=True) as session:
            for start in range(0, len(want), 500):
                chunk = want[start:start + 500]
                last = (session.query(DependencyEvent.dependency_name.label("n"),
                                      func.max(DependencyEvent.arrived_at).label("at"))
                        .filter(DependencyEvent.dependency_name.in_(chunk))
                        .group_by(DependencyEvent.dependency_name).subquery())
                rows = (session.query(DependencyEvent)
                        .join(last, and_(DependencyEvent.dependency_name == last.c.n,
                                         DependencyEvent.arrived_at == last.c.at))
                        .order_by(DependencyEvent.id.asc()).all())
                for r in rows:
                    out[r.dependency_name] = r.to_dict()      # the highest id of a tie wins
        return out

    def list_dependency_first_arrivals(self, dependency_name: str,
                                       since_date=None) -> List[dict]:
        """First (earliest) arrival per business_date for one dependency.

        The training data for arrival profiles (BRD §8.2) — the first
        arrival is the observation; redeliveries and replays later the
        same day do not move the day's arrival time.  Returns
        ``[{"business_date": date, "first_arrived_at": datetime}, ...]``
        ordered by business_date ascending (raw values, not isoformat —
        the profile maths consumes them directly).
        """
        from sqlalchemy import func as sa_func

        from core.db.models import DependencyEvent
        with self.get_session(read_only=True) as session:
            q = (session.query(DependencyEvent.business_date,
                               sa_func.min(DependencyEvent.arrived_at))
                 .filter(DependencyEvent.dependency_name == dependency_name))
            if since_date is not None:
                q = q.filter(DependencyEvent.business_date >= since_date)
            rows = (q.group_by(DependencyEvent.business_date)
                     .order_by(DependencyEvent.business_date.asc()).all())
            return [{"business_date": bd, "first_arrived_at": ts}
                    for bd, ts in rows]

    def list_dependency_first_arrivals_bulk(self, dependency_names, since_date=None) -> Dict[str, List[dict]]:
        """``list_dependency_first_arrivals`` for MANY dependencies in ONE
        query (2026-10-25: a board page of 500-dependency feeds asks for every
        waiting one's usual arrival time)."""
        from sqlalchemy import func as sa_func
        from core.db.models import DependencyEvent
        names = [str(n) for n in dependency_names if n]
        if not names:
            return {}
        out: Dict[str, List[dict]] = {}
        with self.get_session(read_only=True) as session:
            for i in range(0, len(names), 900):
                chunk = names[i:i + 900]
                q = (session.query(DependencyEvent.dependency_name, DependencyEvent.business_date,
                                   sa_func.min(DependencyEvent.arrived_at))
                     .filter(DependencyEvent.dependency_name.in_(chunk)))
                if since_date is not None:
                    q = q.filter(DependencyEvent.business_date >= since_date)
                for name, bd, ts in (q.group_by(DependencyEvent.dependency_name, DependencyEvent.business_date)
                                     .order_by(DependencyEvent.business_date.asc()).all()):
                    out.setdefault(str(name), []).append({"business_date": bd, "first_arrived_at": ts})
        return out

    # ── Foundation M — delivery attempts (BRD 2026-09-02 §11, §14.2) ──────
    # One row per hop per attempt, keyed (manifest_version, target, attempt)
    # — the key is enforced by the DATABASE (a uniqueness rule enforced only
    # in Python is enforced only until two pods run).  The runner in
    # core/feed/delivery_hops.py is the API over this seam.  Models are
    # imported locally so this block stays purely additive.

    #: Identity columns of a delivery attempt.  FR-DEL-04: the record NAMES
    #: what it sent; rewriting any of these would let a re-delivery after a
    #: regeneration hide different bytes under the same record.
    _DELIVERY_ATTEMPT_IDENTITY = (
        "id", "manifest_version", "target", "attempt",
        "feed_config_id", "business_date", "build_id",
    )

    def insert_delivery_attempt(self, data: dict) -> dict:
        """Append one delivery attempt row.  Refuses a row that does not
        name the manifest version it sent (FR-DEL-04) — a delivery record
        without that identity is not a record, it is a rumour."""
        from core.db.models import DeliveryAttempt
        if not data.get("manifest_version"):
            raise ValueError(
                "delivery attempt must name the manifest_version it sent "
                "(FR-DEL-04)")
        with self.get_session() as session:
            row = DeliveryAttempt(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def update_delivery_attempt(self, attempt_id: int, data: dict) -> Optional[dict]:
        """Finalise / acknowledge one attempt.  The identity columns are
        immutable — an update that tries to rewrite WHAT was sent, WHERE,
        or WHICH attempt it was is refused loudly, never silently dropped."""
        from core.db.models import DeliveryAttempt
        frozen = [k for k in (data or {}) if k in self._DELIVERY_ATTEMPT_IDENTITY]
        if frozen:
            raise ValueError(
                f"delivery attempt identity is immutable — refusing to "
                f"rewrite {frozen} (FR-DEL-04); a different delivery is a "
                f"NEW row, never an edit")
        with self.get_session() as session:
            row = session.query(DeliveryAttempt).filter(
                DeliveryAttempt.id == attempt_id).first()
            if row is None:
                return None
            for k, v in (data or {}).items():
                if hasattr(row, k):
                    setattr(row, k, v)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_delivery_attempt(self, attempt_id: int) -> Optional[dict]:
        from core.db.models import DeliveryAttempt
        with self.get_session(read_only=True) as session:
            row = session.query(DeliveryAttempt).filter(
                DeliveryAttempt.id == attempt_id).first()
            return row.to_dict() if row else None

    def list_delivery_attempts(self, manifest_version: str,
                               target: Optional[str] = None) -> List[dict]:
        """Attempts for one manifest version (optionally one hop), attempt
        order ascending — the runner derives 'has this hop ever succeeded'
        and the next attempt number from this, never from a cached flag."""
        from core.db.models import DeliveryAttempt
        with self.get_session(read_only=True) as session:
            q = session.query(DeliveryAttempt).filter(
                DeliveryAttempt.manifest_version == manifest_version)
            if target is not None:
                q = q.filter(DeliveryAttempt.target == target)
            return [r.to_dict() for r in
                    q.order_by(DeliveryAttempt.attempt.asc(),
                               DeliveryAttempt.id.asc()).all()]

    def list_delivery_attempts_for_feed(self, feed_config_id: int,
                                        business_date=None,
                                        limit: int = 200) -> List[dict]:
        """Operator view — newest first, optionally one business date
        (every operational question is scoped to one business date, §14.1)."""
        from core.db.models import DeliveryAttempt
        with self.get_session(read_only=True) as session:
            q = session.query(DeliveryAttempt).filter(
                DeliveryAttempt.feed_config_id == feed_config_id)
            if business_date is not None:
                q = q.filter(DeliveryAttempt.business_date == business_date)
            return [r.to_dict() for r in
                    q.order_by(DeliveryAttempt.id.desc()).limit(limit).all()]

    # ── Foundation P — pinning + build_id + orphan reaper (BRD 2026-09-02) ─
    # Appended at the END OF THE CLASS BODY deliberately: a module-level
    # function (_default_control_file_formats) follows this class, so
    # appending to the end of the FILE would silently nest methods inside
    # it.  core/feed/pinning.py is the API over these; the new model is
    # imported locally so the block stays purely additive.

    def get_feed_definition_version(self, version_id: int) -> Optional[dict]:
        """One pinned-definition snapshot row by id (FR-RUN-03)."""
        from core.db.models import FeedDefinitionVersion
        with self.get_session(read_only=True) as session:
            row = session.query(FeedDefinitionVersion).filter(
                FeedDefinitionVersion.id == int(version_id)).first()
            return row.to_dict() if row else None

    def get_latest_feed_definition_version(
            self, feed_config_id: int) -> Optional[dict]:
        """The highest-version snapshot for a feed, or None."""
        from core.db.models import FeedDefinitionVersion
        with self.get_session(read_only=True) as session:
            row = (session.query(FeedDefinitionVersion)
                   .filter(FeedDefinitionVersion.feed_config_id
                           == int(feed_config_id))
                   .order_by(FeedDefinitionVersion.version.desc())
                   .first())
            return row.to_dict() if row else None

    def list_feed_definition_versions(self, feed_config_id: int,
                                      limit: int = 200) -> List[dict]:
        """Every pinned definition of a feed, NEWEST FIRST (2026-09-27).

        The read half of the version history
        (core/feed/definition_history.py, api/feed_versions_api.py).
        Rows are immutable snapshots; the list is the feed's audit trail
        of WHAT ran and WHAT was saved, so nothing here filters."""
        from core.db.models import FeedDefinitionVersion
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedDefinitionVersion)
                    .filter(FeedDefinitionVersion.feed_config_id
                            == int(feed_config_id))
                    .order_by(FeedDefinitionVersion.version.desc())
                    .limit(int(limit)).all())
            return [r.to_dict() for r in rows]

    def pin_feed_definition(self, feed_config_id: int, snapshot: dict,
                            created_by: Optional[str] = None) -> dict:
        """Persist a claim-time snapshot, deduplicated per feed by hash.

        An UNCHANGED definition pinned twice reuses the existing version
        row; a changed one gets version = max+1.  Two pods racing on
        max+1 are arbitrated by ux_feed_definition_versions_feed_version:
        the loser re-reads (the winner may even carry the same hash) and
        retries ONCE before raising.
        """
        from sqlalchemy.exc import IntegrityError

        from core.db.models import FeedDefinitionVersion
        snap_hash = (snapshot or {}).get("definition_hash") or ""
        last_exc = None
        for _attempt in (1, 2):
            latest = self.get_latest_feed_definition_version(feed_config_id)
            if (latest and snap_hash
                    and latest.get("definition_hash") == snap_hash):
                return latest
            next_version = int((latest or {}).get("version") or 0) + 1
            try:
                with self.get_session() as session:
                    row = FeedDefinitionVersion(
                        feed_config_id=int(feed_config_id),
                        version=next_version,
                        definition=(snapshot or {}).get("definition") or {},
                        definition_hash=snap_hash,
                        git_commit=(snapshot or {}).get("git_commit"),
                        image_tag=(snapshot or {}).get("image_tag"),
                        created_by=created_by,
                    )
                    session.add(row)
                    session.flush()
                    session.refresh(row)
                    return row.to_dict()
            except IntegrityError as exc:
                last_exc = exc          # lost the max+1 race — re-read
        raise last_exc

    def pin_feed_run(self, run_id: int, *, build_id: str,
                     version_id: Optional[int] = None,
                     git_commit: Optional[str] = None,
                     image_tag: Optional[str] = None) -> Optional[dict]:
        """Stamp a run row with its build identity + pin — WRITE-ONCE.

        A row that already carries a build_id / pin keeps it: the
        definition a run was admitted with must not drift, and that
        includes drifting via a second pin call.  Also seeds
        heartbeat_at so a claim that dies before its first beat is
        still reclaimable via the started_at fallback.  Returns the
        updated row dict, or None when the run does not exist.
        """
        with self.get_session() as session:
            row = session.query(FeedRun).filter(
                FeedRun.id == int(run_id)).first()
            if row is None:
                return None
            now = datetime.now(timezone.utc)
            if row.build_id is None and build_id:
                row.build_id = str(build_id)
            if row.pinned_version_id is None and version_id is not None:
                row.pinned_version_id = int(version_id)
                row.pinned_git_commit = git_commit
                row.pinned_image_tag = image_tag
                row.pinned_at = now
            row.heartbeat_at = now
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def pin_feed_execution(self, exec_id: int, *,
                           business_date=None,
                           build_id: Optional[str] = None,
                           version_id: Optional[int] = None,
                           git_commit: Optional[str] = None,
                           image_tag: Optional[str] = None) -> Optional[dict]:
        """Execution-row twin of pin_feed_run — WRITE-ONCE, same rules."""
        with self.get_session() as session:
            row = session.query(FeedExecution).filter(
                FeedExecution.id == int(exec_id)).first()
            if row is None:
                return None
            now = datetime.now(timezone.utc)
            if row.business_date is None and business_date is not None:
                row.business_date = business_date
            if row.build_id is None and build_id:
                row.build_id = str(build_id)
            if row.pinned_version_id is None and version_id is not None:
                row.pinned_version_id = int(version_id)
                row.pinned_git_commit = git_commit
                row.pinned_image_tag = image_tag
            row.heartbeat_at = now
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def heartbeat_feed_run(self, run_id: int,
                           owned_by: Optional[str] = None) -> bool:
        """Beat while executing.  True when the beat landed; False means
        the row is no longer running (or no longer ours) — the caller
        lost the claim and must stop, not keep writing output."""
        with self.get_session() as session:
            q = session.query(FeedRun).filter(
                FeedRun.id == int(run_id),
                FeedRun.status == "running",
            )
            if owned_by:
                q = q.filter(FeedRun.claimed_by == owned_by)
            count = q.update({"heartbeat_at": datetime.now(timezone.utc)},
                             synchronize_session=False)
            return int(count or 0) > 0

    def heartbeat_feed_execution(self, exec_id: int) -> bool:
        """Beat on an active execution row.  False = row not active."""
        with self.get_session() as session:
            count = session.query(FeedExecution).filter(
                FeedExecution.id == int(exec_id),
                FeedExecution.status.in_(["pending", "running"]),
            ).update({"heartbeat_at": datetime.now(timezone.utc)},
                     synchronize_session=False)
            return int(count or 0) > 0

    def reap_orphaned_feed_runs(self, heartbeat_timeout_seconds: int) -> int:
        """Reclaim runs whose claiming pod stopped beating (BRD §19 D6).

        Keyed on the HEARTBEAT, not on age alone: a healthy 4-hour run
        that keeps beating is NEVER reaped (an age-only reaper kills it
        at the cutoff).  Rows that never beat at all (claimed
        pre-Foundation-P, or the pod died before its first beat) fall
        back to started_at age.  Reclaimed rows go back to ``pending``
        so the queue re-dispatches them.
        """
        if not heartbeat_timeout_seconds or heartbeat_timeout_seconds <= 0:
            return 0    # a zero/negative timeout must never mean "reap all"
        from sqlalchemy import and_, or_
        from core.feed.run_reclaim import FAILED, apply_reclaim
        cutoff = datetime.now(timezone.utc) - timedelta(
            seconds=int(heartbeat_timeout_seconds))
        why = (f"no heartbeat for >{int(heartbeat_timeout_seconds)}s "
               "(the pod running this is presumed dead); nothing was delivered")
        count = 0
        with self.get_session() as session:
            rows = session.query(FeedRun).filter(
                FeedRun.status == "running",
                # a manual run is never re-queued: only the queue worker
                # heartbeats, so a long Run Now would be "reclaimed" and
                # executed a SECOND time -- a double delivery
                self.manual_run_excluded(),
                or_(
                    FeedRun.heartbeat_at < cutoff,
                    and_(FeedRun.heartbeat_at.is_(None),
                         FeedRun.started_at < cutoff),
                ),
            ).all()
            # 2026-10-26 -- bounded: a run whose worker keeps being stopped
            # is FAILED for good after its retries (core/feed/run_reclaim.py),
            # never re-queued for ever
            for run in rows:
                if apply_reclaim(run, why) == FAILED:
                    logger.error("[db] feed_run %s (feed %s) is not tried again: %s",
                                 run.id, run.feed_config_id, run.error)
                count += 1
        return count

    def reap_orphaned_feed_executions(
            self, heartbeat_timeout_seconds: int) -> int:
        """Execution-row twin of reap_orphaned_feed_runs.

        An active execution row left by a dead pod blocks its feed (or
        feed+date) via the one-active partial indexes until reclaimed —
        BRD §19 D6: "blocks the feed permanently until someone cancels
        it by hand".  Marked ``failed`` (an execution, unlike a run
        row, is ONE attempt — the retry is a NEW attempt with a NEW
        build_id).  Same heartbeat-first, started_at-fallback keying.
        """
        if not heartbeat_timeout_seconds or heartbeat_timeout_seconds <= 0:
            return 0
        from sqlalchemy import and_, or_
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(seconds=int(heartbeat_timeout_seconds))
        message = ("reclaimed by orphan reaper: no heartbeat for >"
                   f"{int(heartbeat_timeout_seconds)}s "
                   "(claiming pod presumed dead)")
        with self.get_session() as session:
            orphaned = (FeedExecution.status.in_(["pending", "running"]),
                        or_(
                            FeedExecution.heartbeat_at < cutoff,
                            and_(FeedExecution.heartbeat_at.is_(None),
                                 FeedExecution.started_at < cutoff),
                        ))
            ids = [int(r[0]) for r in
                   session.query(FeedExecution.id).filter(*orphaned).all()]
            count = session.query(FeedExecution).filter(*orphaned).update({
                "status": "failed",
                "completed_at": now,
                "error_message": message,
            }, synchronize_session=False)
        self._after_swept_executions(ids, message)
        return int(count or 0)

    def add_definition_timeline(self, feed_config_id: int, version_id: int, applies_from=None,
                                saved_by: Optional[str] = None, note: Optional[str] = None) -> dict:
        from core.db.models import FeedDefinitionTimeline as T
        with self.get_session() as session:
            row = T(feed_config_id=int(feed_config_id), version_id=int(version_id),
                    applies_from=applies_from, saved_by=saved_by, note=note)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_definition_timeline(self, feed_config_id: int) -> List[dict]:
        """Newest declaration first."""
        from core.db.models import FeedDefinitionTimeline as T
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in session.query(T).filter(T.feed_config_id == int(feed_config_id))
                    .order_by(T.saved_at.desc(), T.id.desc()).all()]

    def first_delivery_at(self, feed_config_id: int, business_date):
        """When (feed, business date) was FIRST delivered, or None."""
        from sqlalchemy import func
        with self.get_session(read_only=True) as session:
            return (session.query(func.min(FeedExecution.completed_at))
                    .filter(FeedExecution.feed_config_id == int(feed_config_id),
                            FeedExecution.business_date == business_date,
                            FeedExecution.status == "completed").scalar())

    def find_pinned_run_for_date(self, feed_config_id: int,
                                 business_date) -> Optional[dict]:
        """Most recent PINNED run of (feed, business_date) — any status.

        The lookup behind re-run semantics (FR-GOV-01): the definition
        that was live FOR THAT DATE is the one its last pinned run
        carries, never today's.  Returns None when no run of that date
        was ever pinned (the caller falls back to live, saying so).
        """
        with self.get_session(read_only=True) as session:
            row = (session.query(FeedRun)
                   .filter(FeedRun.feed_config_id == int(feed_config_id),
                           FeedRun.business_date == business_date,
                           FeedRun.pinned_version_id.isnot(None),
                           self.manual_run_excluded())
                   .order_by(FeedRun.id.desc())
                   .first())
            return row.to_dict() if row else None

    # ── Foundation C — child file runs (BRD §4.2/§4.3, FR-RUN-02/04/05) ──

    def expand_feed_file_runs(self, *, feed_run_id: int,
                              partition_keys: List[str],
                              feed_config_id: Optional[int] = None,
                              business_date=None,
                              created_by: Optional[str] = None) -> dict:
        """FR-RUN-05 — expand the declared partition list into ``pending``
        child rows BEFORE anything executes.

        Idempotent / restartable: a key that already has a row is SKIPPED
        (its state — running, completed, whatever — is preserved), a
        missing key is inserted.  A crash mid-expansion is repaired by
        calling this again.  Returns ``{"inserted": n, "existing": m}``.
        Raises on DB failure — an expansion that silently half-happened
        would make the §9.3 set comparison lie.
        """
        from core.db.models import FeedFileRun
        with self.get_session() as session:
            existing = {
                row[0] for row in session.query(FeedFileRun.partition_key)
                .filter(FeedFileRun.feed_run_id == int(feed_run_id)).all()
            }
            inserted = 0
            seen: set = set()
            for key in partition_keys:
                skey = str(key)
                if skey in existing or skey in seen:
                    continue
                seen.add(skey)
                session.add(FeedFileRun(
                    feed_run_id=int(feed_run_id),
                    feed_config_id=(int(feed_config_id)
                                    if feed_config_id is not None else None),
                    business_date=business_date,
                    partition_key=skey,
                    status="pending",
                    attempt_count=0,
                    created_by=created_by,
                ))
                inserted += 1
            session.flush()
            return {"inserted": inserted, "existing": len(existing)}

    def get_feed_file_run(self, file_run_id: int) -> Optional[dict]:
        from core.db.models import FeedFileRun
        with self.get_session(read_only=True) as session:
            row = session.query(FeedFileRun).filter(
                FeedFileRun.id == int(file_run_id)).first()
            return row.to_dict() if row else None

    def get_feed_file_run_by_key(self, feed_run_id: int,
                                 partition_key: str) -> Optional[dict]:
        from core.db.models import FeedFileRun
        with self.get_session(read_only=True) as session:
            row = session.query(FeedFileRun).filter(
                FeedFileRun.feed_run_id == int(feed_run_id),
                FeedFileRun.partition_key == str(partition_key),
            ).first()
            return row.to_dict() if row else None

    def list_feed_file_runs(self, feed_run_id: int,
                            status: Optional[str] = None) -> List[dict]:
        from core.db.models import FeedFileRun
        with self.get_session(read_only=True) as session:
            q = session.query(FeedFileRun).filter(
                FeedFileRun.feed_run_id == int(feed_run_id))
            if status is not None:
                q = q.filter(FeedFileRun.status == status)
            return [r.to_dict() for r in q.order_by(FeedFileRun.id).all()]

    def feed_file_run_status_counts(self, feed_run_id: int) -> Dict[str, int]:
        """Counters for DISPLAY (FR-RUN-04: counters may be carried; the
        parent VERDICT is recomputed by fanout.derive_parent_status)."""
        from sqlalchemy import func
        from core.db.models import FeedFileRun
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedFileRun.status,
                                  func.count(FeedFileRun.id))
                    .filter(FeedFileRun.feed_run_id == int(feed_run_id))
                    .group_by(FeedFileRun.status).all())
            return {status: int(count) for status, count in rows}

    def claim_pending_feed_file_run(self, file_run_id: int,
                                    claimed_by: str) -> Optional[dict]:
        """Atomic claim of ONE child: pending → running, attempt counted.
        Returns the row dict, or None when another worker won the race
        (conditional UPDATE, same pattern as claim_pending_feed_run)."""
        from core.db.models import FeedFileRun
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            count = session.query(FeedFileRun).filter(
                FeedFileRun.id == int(file_run_id),
                FeedFileRun.status == "pending",
            ).update({
                "status": "running",
                "started_at": now,
                "heartbeat_at": now,
                "claimed_by": claimed_by,
                "attempt_count": FeedFileRun.attempt_count + 1,
                "updated_at": now,
                "updated_by": claimed_by,
            }, synchronize_session=False)
            if count == 0:
                return None
            session.flush()
            row = session.query(FeedFileRun).filter(
                FeedFileRun.id == int(file_run_id)).first()
            return row.to_dict() if row else None

    def complete_feed_file_run(self, file_run_id: int, *,
                               part_path: Optional[str] = None,
                               row_count: Optional[int] = None,
                               owned_by: Optional[str] = None) -> bool:
        """running → completed, with the part evidence.  False = the row
        was not running (or not ours) — the caller lost the claim and
        must stop, not keep writing output."""
        from core.db.models import FeedFileRun
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            q = session.query(FeedFileRun).filter(
                FeedFileRun.id == int(file_run_id),
                FeedFileRun.status == "running",
            )
            if owned_by:
                q = q.filter(FeedFileRun.claimed_by == owned_by)
            count = q.update({
                "status": "completed",
                "completed_at": now,
                "part_path": part_path,
                "row_count": row_count,
                "error": None,
                "updated_at": now,
                "updated_by": owned_by,
            }, synchronize_session=False)
            return int(count or 0) > 0

    def fail_feed_file_run(self, file_run_id: int, *, error: str,
                           owned_by: Optional[str] = None) -> bool:
        """running → failed.  The child stays failed without touching its
        siblings (§4.2); a retry is a reset back to pending."""
        from core.db.models import FeedFileRun
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            q = session.query(FeedFileRun).filter(
                FeedFileRun.id == int(file_run_id),
                FeedFileRun.status == "running",
            )
            if owned_by:
                q = q.filter(FeedFileRun.claimed_by == owned_by)
            count = q.update({
                "status": "failed",
                "completed_at": now,
                "error": str(error) if error is not None else None,
                "updated_at": now,
                "updated_by": owned_by,
            }, synchronize_session=False)
            return int(count or 0) > 0

    def reset_feed_file_run_to_pending(self, feed_run_id: int,
                                       partition_key: str, *,
                                       requested_by: Optional[str] = None,
                                       ) -> bool:
        """§4.3 "re-run file 738" — flip ONE terminal child back to
        pending, clearing its evidence, WITHOUT touching its siblings.

        Only terminal rows reset (completed/failed/cancelled): a
        pending/running child is already on its way, and resetting it
        would race the worker that owns it.  ``attempt_count`` is
        preserved — the history of how many tries this partition took is
        part of the answer to "which attempt produced this file?".
        """
        from core.db.models import (FEED_FILE_RUN_TERMINAL_STATUSES,
                                    FeedFileRun)
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            count = session.query(FeedFileRun).filter(
                FeedFileRun.feed_run_id == int(feed_run_id),
                FeedFileRun.partition_key == str(partition_key),
                FeedFileRun.status.in_(FEED_FILE_RUN_TERMINAL_STATUSES),
            ).update({
                "status": "pending",
                "claimed_by": None,
                "started_at": None,
                "completed_at": None,
                "heartbeat_at": None,
                "part_path": None,
                "row_count": None,
                "error": None,
                "updated_at": now,
                "updated_by": requested_by,
            }, synchronize_session=False)
            return int(count or 0) > 0

    def heartbeat_feed_file_run(self, file_run_id: int,
                                owned_by: Optional[str] = None) -> bool:
        """Beat on a running child.  False = no longer running/ours —
        the caller lost the claim and must stop."""
        from core.db.models import FeedFileRun
        with self.get_session() as session:
            q = session.query(FeedFileRun).filter(
                FeedFileRun.id == int(file_run_id),
                FeedFileRun.status == "running",
            )
            if owned_by:
                q = q.filter(FeedFileRun.claimed_by == owned_by)
            count = q.update(
                {"heartbeat_at": datetime.now(timezone.utc)},
                synchronize_session=False)
            return int(count or 0) > 0

    def reap_orphaned_feed_file_runs(self,
                                     heartbeat_timeout_seconds: int) -> int:
        """Child twin of reap_orphaned_feed_runs — keyed on the HEARTBEAT,
        never age alone (a healthy 4-hour child that keeps beating is
        never reaped).  Reclaimed children go back to ``pending`` so the
        queue re-dispatches them; ``attempt_count`` is preserved."""
        if not heartbeat_timeout_seconds or heartbeat_timeout_seconds <= 0:
            return 0    # a zero/negative timeout must never mean "reap all"
        from sqlalchemy import and_, or_
        from core.db.models import FeedFileRun
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(seconds=int(heartbeat_timeout_seconds))
        with self.get_session() as session:
            count = session.query(FeedFileRun).filter(
                FeedFileRun.status == "running",
                or_(
                    FeedFileRun.heartbeat_at < cutoff,
                    and_(FeedFileRun.heartbeat_at.is_(None),
                         FeedFileRun.started_at < cutoff),
                ),
            ).update({
                "status": "pending",
                "started_at": None,
                "heartbeat_at": None,
                "claimed_by": None,
                "error": ("reclaimed by orphan reaper: no heartbeat for >"
                          f"{int(heartbeat_timeout_seconds)}s "
                          "(claiming pod presumed dead)"),
                "updated_at": now,
            }, synchronize_session=False)
            return int(count or 0)

    # ── Foundation C — connection claims (BRD §4.2/§13.5, FR-RUN-06..08) ─

    def upsert_connection_concurrency_budget(
            self, connection_id: int, *, max_concurrent_runs: int,
            reserved_critical_slots: int = 0,
            updated_by: Optional[str] = None) -> dict:
        """Declare (or change) a connection's concurrency allowance.

        Refusals mirror the DB CHECK constraints, with better messages:
        negative values, and a reservation larger than the budget, are
        configurations that can never be satisfied.  ``0`` means PAUSED
        (zero slots), NEVER unlimited — delete the row (or never create
        it) to leave a connection unbounded.
        """
        from core.db.models import ConnectionConcurrencyBudget
        maxr = int(max_concurrent_runs)
        reserved = int(reserved_critical_slots or 0)
        if maxr < 0:
            raise ValueError(
                f"max_concurrent_runs={maxr} is refused: negative slots "
                f"name nothing.  0 means PAUSED; no row means unbounded")
        if reserved < 0:
            raise ValueError(
                f"reserved_critical_slots={reserved} is refused: a "
                f"negative reservation names nothing")
        if reserved > maxr:
            raise ValueError(
                f"reserved_critical_slots={reserved} exceeds "
                f"max_concurrent_runs={maxr} — a reservation larger than "
                f"the budget can never be satisfied")
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            row = session.query(ConnectionConcurrencyBudget).filter(
                ConnectionConcurrencyBudget.connection_id
                == int(connection_id)).first()
            if row is None:
                row = ConnectionConcurrencyBudget(
                    connection_id=int(connection_id),
                    max_concurrent_runs=maxr,
                    reserved_critical_slots=reserved,
                    created_by=updated_by,
                )
                session.add(row)
            else:
                row.max_concurrent_runs = maxr
                row.reserved_critical_slots = reserved
                row.updated_at = now
                row.updated_by = updated_by
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_connection_concurrency_budget(
            self, connection_id: int) -> Optional[dict]:
        from core.db.models import ConnectionConcurrencyBudget
        with self.get_session(read_only=True) as session:
            row = session.query(ConnectionConcurrencyBudget).filter(
                ConnectionConcurrencyBudget.connection_id
                == int(connection_id)).first()
            return row.to_dict() if row else None

    def list_connection_claims(
            self, connection_id: Optional[int] = None) -> List[dict]:
        from core.db.models import ConnectionClaim
        with self.get_session(read_only=True) as session:
            q = session.query(ConnectionClaim)
            if connection_id is not None:
                q = q.filter(
                    ConnectionClaim.connection_id == int(connection_id))
            return [r.to_dict() for r in q.order_by(ConnectionClaim.id).all()]

    def try_acquire_connection_claims(
            self, *, run_id: int, connection_ids: List[int], pod_id: str,
            run_kind: str = "feed_run", critical: bool = False,
            priority: Optional[int] = None,
            feed_config_id: Optional[int] = None) -> dict:
        """ALL-OR-NOTHING slot acquisition across a run's whole connection
        set (FR-RUN-07), in ONE transaction.

        The rule: a worker may claim a run only if EVERY connection in
        the set has a free slot — the effective concurrency is the
        MINIMUM free budget across every source the run touches.
        Acquiring 2 of 3 and proceeding is worse than waiting, so on any
        shortfall NOTHING is inserted.

        Mechanics:
        * budgets are read ``FOR UPDATE`` in sorted connection order —
          racing pods serialise on the budget rows (no-op on SQLite,
          which serialises writes at the file level anyway) and the
          sorted order prevents deadlock;
        * no budget row = UNBOUNDED (pre-Foundation-C behaviour);
        * ``critical`` claims may use the reserved slots (FR-OPS-11):
          allowance = max; non-critical allowance = max − reserved;
        * a run that already holds any claim in the set is refused
          (``reason="already_held"``) — release first, never double-count.

        Returns ``{"granted", "reason", "free_slots",
        "blocking_connection_ids"}`` where free_slots maps
        connection_id → remaining slots BEFORE this acquisition (None =
        unbounded).  Raises on DB failure: a claim ledger that cannot be
        read must not silently mean "go" (unbounded) or "stop" (outage).
        """
        from sqlalchemy import func
        from core.db.models import (CONNECTION_CLAIM_RUN_KINDS,
                                    ConnectionClaim,
                                    ConnectionConcurrencyBudget)
        if run_kind not in CONNECTION_CLAIM_RUN_KINDS:
            raise ValueError(
                f"run_kind must be one of {CONNECTION_CLAIM_RUN_KINDS}, "
                f"got {run_kind!r} — a typo must not become a new state")
        ids = sorted({int(c) for c in (connection_ids or [])})
        if not ids:
            # A run that touches no governed connection has nothing to
            # bound — grant with no rows (nothing to release either).
            return {"granted": True, "reason": "no_connections",
                    "free_slots": {}, "blocking_connection_ids": []}
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            already = session.query(ConnectionClaim.id).filter(
                ConnectionClaim.run_kind == run_kind,
                ConnectionClaim.run_id == int(run_id),
                ConnectionClaim.connection_id.in_(ids),
            ).first()
            if already is not None:
                return {"granted": False, "reason": "already_held",
                        "free_slots": {}, "blocking_connection_ids": []}
            free: Dict[int, Optional[int]] = {}
            for cid in ids:     # sorted — deterministic lock order
                budget = (session.query(ConnectionConcurrencyBudget)
                          .filter(ConnectionConcurrencyBudget.connection_id
                                  == cid)
                          .with_for_update().first())
                if budget is None:
                    free[cid] = None    # undeclared budget = unbounded
                    continue
                allowance = int(budget.max_concurrent_runs or 0)
                if not critical:
                    # FR-OPS-11 — the reserved slots are invisible to
                    # non-critical work, so critical always has one.
                    allowance -= int(budget.reserved_critical_slots or 0)
                held = (session.query(func.count(ConnectionClaim.id))
                        .filter(ConnectionClaim.connection_id == cid)
                        .scalar()) or 0
                free[cid] = allowance - int(held)
            blocking = [cid for cid, slots in free.items()
                        if slots is not None and slots <= 0]
            if blocking:
                # Nothing was inserted — the all-or-nothing hold is
                # BY CONSTRUCTION, not by rollback-and-hope.
                return {"granted": False, "reason": "no_free_slot",
                        "free_slots": free,
                        "blocking_connection_ids": blocking}
            for cid in ids:
                session.add(ConnectionClaim(
                    connection_id=cid,
                    run_kind=run_kind,
                    run_id=int(run_id),
                    pod_id=pod_id,
                    priority=priority,
                    feed_config_id=(int(feed_config_id)
                                    if feed_config_id is not None else None),
                    claimed_at=now,
                    heartbeat_at=now,
                    created_by=pod_id,
                ))
            # One flush for the whole set: a unique-constraint race with
            # another pod raises IntegrityError, the session context
            # rolls back EVERY row of this set, and the error propagates
            # — a partial hold cannot survive.
            session.flush()
            return {"granted": True, "reason": "granted",
                    "free_slots": free, "blocking_connection_ids": []}

    def release_connection_claims(self, *, run_id: int,
                                  run_kind: str = "feed_run",
                                  pod_id: Optional[str] = None) -> int:
        """Release every slot a run holds.  ``pod_id`` narrows to one
        pod's claims (defensive release paths); omit it for the normal
        end-of-run release.  Returns rows deleted."""
        from core.db.models import ConnectionClaim
        with self.get_session() as session:
            q = session.query(ConnectionClaim).filter(
                ConnectionClaim.run_kind == run_kind,
                ConnectionClaim.run_id == int(run_id),
            )
            if pod_id:
                q = q.filter(ConnectionClaim.pod_id == pod_id)
            count = q.delete(synchronize_session=False)
            return int(count or 0)

    def heartbeat_connection_claims(self, *, run_id: int, pod_id: str,
                                    run_kind: str = "feed_run") -> int:
        """Beat on every claim this pod holds for a run.  0 = the claims
        are gone (reaped, or released) — the caller no longer holds the
        slots and must stop, not keep executing."""
        from core.db.models import ConnectionClaim
        with self.get_session() as session:
            count = session.query(ConnectionClaim).filter(
                ConnectionClaim.run_kind == run_kind,
                ConnectionClaim.run_id == int(run_id),
                ConnectionClaim.pod_id == pod_id,
            ).update({"heartbeat_at": datetime.now(timezone.utc)},
                     synchronize_session=False)
            return int(count or 0)

    def hand_back_runs(self, run_ids, *, pod_id: Optional[str] = None) -> Dict[str, int]:
        """A shutting-down worker hands its unfinished runs back
        (``core/feed/run_lifecycle.py``; the publish gate is already closed,
        so nothing of these runs can still be delivered by that process).
        Each run's active execution is FAILED with the reason; the run goes
        back to ``pending`` -- a manual Run Now is failed instead (never re-run
        by itself); its connection slots are released."""
        from core.db.models import ConnectionClaim
        from core.feed.run_lifecycle import HANDED_BACK, HANDED_BACK_MANUAL
        ids = sorted({int(r) for r in (run_ids or [])})
        out = {"runs_requeued": 0, "runs_failed": 0, "executions": 0, "claims": 0}
        if not ids:
            return out
        now = datetime.now(timezone.utc)
        ex_ids: List[int] = []
        with self.get_session() as session:
            rows = session.query(FeedRun).filter(FeedRun.id.in_(ids),
                                                 FeedRun.status == "running").all()
            for run in rows:
                manual = str(getattr(run, "run_type", "") or "").lower() == "manual"
                ex = (session.query(FeedExecution)
                      .filter(FeedExecution.feed_config_id == run.feed_config_id,
                              FeedExecution.status.in_(["pending", "running"]))
                      .order_by(FeedExecution.id.desc()).first())
                if ex is not None:
                    ex.status = "failed"
                    ex.completed_at = now
                    ex.error_message = HANDED_BACK_MANUAL if manual else HANDED_BACK
                    ex_ids.append(int(ex.id))
                if manual:
                    run.status = "failed"
                    run.completed_at = now
                    run.error = HANDED_BACK_MANUAL
                    out["runs_failed"] += 1
                else:
                    run.status = "pending"
                    run.started_at = None
                    run.heartbeat_at = None
                    run.claimed_by = None
                    run.error = "handed back: " + HANDED_BACK
                    out["runs_requeued"] += 1
            q = session.query(ConnectionClaim).filter(ConnectionClaim.run_kind == "feed_run",
                                                      ConnectionClaim.run_id.in_(ids))
            if pod_id:
                q = q.filter(ConnectionClaim.pod_id == str(pod_id))
            out["claims"] = int(q.delete(synchronize_session=False) or 0)
        out["executions"] = len(ex_ids)
        if ex_ids:
            self._after_swept_executions(ex_ids, HANDED_BACK)
        return out

    def reap_runs_of_a_dead_process(self, pod_id: str, started_at) -> Dict[str, int]:
        """Free the runs a PREVIOUS process on this pod left behind (2026-10-14).

        Found live: the scheduler was OOM-killed mid-run and restarted under
        the SAME pod name; its run stayed "running", blocking the feed, until
        the heartbeat reaper's 1-hour threshold.  Exact rule, no timing
        guess: a feed_run claim held by ``pod_id``, claimed BEFORE this
        process started (``started_at``, naive UTC like the column), that
        nobody has beaten since -- the caller asks only after a full beat
        interval, so any live process on this pod would have beaten it.
        Same outcome as the heartbeat reaper: the run back to ``pending``
        (never a manual Run Now -- see ``manual_run_excluded``), its active
        execution ``failed`` with the reason, the slots released."""
        from sqlalchemy import or_
        from core.db.models import ConnectionClaim
        from core.feed.run_reclaim import FAILED, apply_reclaim
        message = ("the worker process running this was stopped (restarted, or killed "
                   "for memory) -- reclaimed when it came back; nothing was delivered")
        out = {"runs": 0, "runs_failed": 0, "executions": 0, "claims": 0}
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            dead = session.query(ConnectionClaim.run_id).filter(
                ConnectionClaim.pod_id == str(pod_id),
                ConnectionClaim.run_kind == "feed_run",
                ConnectionClaim.claimed_at < started_at,
                or_(ConnectionClaim.heartbeat_at.is_(None),
                    ConnectionClaim.heartbeat_at < started_at)).distinct().all()
            run_ids = [int(r[0]) for r in dead]
            if not run_ids:
                return out
            runs = session.query(FeedRun).filter(
                FeedRun.id.in_(run_ids), FeedRun.status == "running",
                self.manual_run_excluded(),
                or_(FeedRun.heartbeat_at.is_(None), FeedRun.heartbeat_at < started_at)).all()
            feeds = sorted({int(r.feed_config_id) for r in runs})
            # 2026-10-26 -- bounded: after its retries the run is FAILED for
            # good (core/feed/run_reclaim.py); its last attempt says the same
            final_words = {}
            for run in runs:
                if apply_reclaim(run, message, now=now) == FAILED:
                    out["runs_failed"] += 1
                    final_words[int(run.feed_config_id)] = run.error
                    logger.error("[db] feed_run %s (feed %s) is not tried again: %s",
                                 run.id, run.feed_config_id, run.error)
                else:
                    out["runs"] += 1
            ex_filter = (FeedExecution.feed_config_id.in_(feeds),
                         FeedExecution.status.in_(["pending", "running"]),
                         FeedExecution.started_at < started_at,
                         or_(FeedExecution.heartbeat_at.is_(None),
                             FeedExecution.heartbeat_at < started_at))
            ex_rows = session.query(FeedExecution).filter(*ex_filter).all() if feeds else []
            ex_ids = []
            for ex in ex_rows:
                ex.status = "failed"
                ex.completed_at = now
                ex.error_message = final_words.get(int(ex.feed_config_id)) or message
                ex_ids.append(int(ex.id))
            out["executions"] = len(ex_ids)
            out["claims"] = int(session.query(ConnectionClaim).filter(
                ConnectionClaim.pod_id == str(pod_id),
                ConnectionClaim.run_kind == "feed_run",
                ConnectionClaim.run_id.in_(run_ids)).delete(synchronize_session=False) or 0)
        for words in {message, *final_words.values()}:
            self._after_swept_executions(ex_ids, words)
        return out

    def reap_stale_connection_claims(self,
                                     heartbeat_timeout_seconds: int) -> int:
        """FR-RUN-08 — delete claims whose pod stopped beating, so a dead
        pod holding four slots does not starve the source until someone
        notices.  Heartbeat-keyed, claimed_at fallback for rows that
        never beat.  Returns slots freed."""
        if not heartbeat_timeout_seconds or heartbeat_timeout_seconds <= 0:
            return 0    # a zero/negative timeout must never mean "reap all"
        from sqlalchemy import and_, or_
        from core.db.models import ConnectionClaim
        cutoff = datetime.now(timezone.utc) - timedelta(
            seconds=int(heartbeat_timeout_seconds))
        with self.get_session() as session:
            count = session.query(ConnectionClaim).filter(
                or_(
                    ConnectionClaim.heartbeat_at < cutoff,
                    and_(ConnectionClaim.heartbeat_at.is_(None),
                         ConnectionClaim.claimed_at < cutoff),
                ),
            ).delete(synchronize_session=False)
            return int(count or 0)

    # ── Partition declaration store (BRD §9.2/§9.3, FR-CMP-02) ──────────

    def record_partition_declaration(self, *, feed_run_id: int,
                                     feed_config_id: int, business_date,
                                     identities: List[str],
                                     identity_count: int, on_empty: str,
                                     source: Optional[str],
                                     declared_at,
                                     created_by: Optional[str] = None,
                                     ) -> dict:
        """FR-CMP-02 — record the declared list WITH the run: the
        IDENTITIES, not just the count.

        Errors PROPAGATE — an unrecorded declaration is not evidence.
        One declaration per run: re-recording the IDENTICAL list is
        idempotent (restartable expansion); a DIFFERENT list is refused,
        because the declaration is immutable evidence — a changed list
        means a re-run, which is a new run with a new build_id.
        """
        from core.db.models import (PARTITION_DECLARATION_ON_EMPTY,
                                    FeedPartitionDeclaration)
        if on_empty not in PARTITION_DECLARATION_ON_EMPTY:
            raise ValueError(
                f"on_empty must be one of {PARTITION_DECLARATION_ON_EMPTY}, "
                f"got {on_empty!r} — a typo must not become a new state")
        if identities is None:
            raise ValueError(
                "identities is None — record the LIST (FR-CMP-02); an "
                "empty list under on_empty=skip is [] and says so")
        idents = [str(i) for i in identities]
        if int(identity_count) != len(idents):
            raise ValueError(
                f"identity_count={identity_count} disagrees with the "
                f"list ({len(idents)} identities) — a count that "
                f"contradicts its own list is a bug, not a record")
        if business_date is None:
            raise ValueError("business_date is required — every "
                             "declaration is scoped to one business date")
        if declared_at is None:
            raise ValueError("declared_at is required — evidence without "
                             "a timestamp is not evidence")
        with self.get_session() as session:
            existing = session.query(FeedPartitionDeclaration).filter(
                FeedPartitionDeclaration.feed_run_id == int(feed_run_id)
            ).first()
            if existing is not None:
                if list(existing.identities or []) == idents:
                    return existing.to_dict()   # idempotent re-record
                raise ValueError(
                    f"feed_run {feed_run_id} already has a declaration "
                    f"({existing.identity_count} identities) and the new "
                    f"list differs ({len(idents)}) — a declaration is "
                    f"immutable evidence; a changed list is a NEW run")
            row = FeedPartitionDeclaration(
                feed_run_id=int(feed_run_id),
                feed_config_id=int(feed_config_id),
                business_date=business_date,
                identities=idents,
                identity_count=len(idents),
                on_empty=on_empty,
                source=source,
                declared_at=declared_at,
                created_by=created_by,
            )
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_partition_declaration(self, feed_run_id: int) -> Optional[dict]:
        """This run's declaration — the loop bound AND the completeness
        evidence.  None when the run never declared (fanout's parent
        derivation then refuses to certify — it cannot know the set)."""
        from core.db.models import FeedPartitionDeclaration
        with self.get_session(read_only=True) as session:
            row = session.query(FeedPartitionDeclaration).filter(
                FeedPartitionDeclaration.feed_run_id == int(feed_run_id)
            ).first()
            return row.to_dict() if row else None

    def get_partition_declaration_before(self, *, feed_config_id: int,
                                         business_date) -> Optional[List[str]]:
        """FR-CMP-03 — the identities of the most recent declaration
        STRICTLY BEFORE ``business_date``, or None when none exists.

        Strictly before: today's own declaration must never be its own
        baseline.  Errors PROPAGATE — "couldn't read" must surface as an
        uncompared comparison, never be treated as "nothing there".
        """
        from core.db.models import FeedPartitionDeclaration
        with self.get_session(read_only=True) as session:
            row = (session.query(FeedPartitionDeclaration)
                   .filter(FeedPartitionDeclaration.feed_config_id
                           == int(feed_config_id),
                           FeedPartitionDeclaration.business_date
                           < business_date)
                   .order_by(FeedPartitionDeclaration.business_date.desc(),
                             FeedPartitionDeclaration.id.desc())
                   .first())
            if row is None:
                return None
            return [str(i) for i in (row.identities or [])]

    # ── BRD §7.1 (step 6) — the Kafka landing table (kafka_messages) ──────
    # The consumer INSERTs; the resolver reads 'landed' rows and marks
    # them resolved / unresolvable.  Dedupe lives in the TABLE (unique on
    # (topic, partition, offset) — FR-DEP-03): insert_kafka_message only
    # TRANSLATES the IntegrityError, it never implements the rule.
    # Models are imported locally so this block stays purely additive.
    # NOTE: appended at the END OF THE CLASS BODY — anything added after
    # _default_control_file_formats() below would silently nest there.

    def insert_kafka_message(self, data: dict) -> Optional[dict]:
        """Land one message.  Returns the row, or None when
        (topic, partition, offset) is already landed — the DATABASE's
        unique constraint decides, the only dedupe that still holds when
        two consumer pods race (§14.1).  Raises on any OTHER DB failure:
        the consumer must know the message is not persisted, because it
        must not advance past it."""
        from sqlalchemy.exc import IntegrityError

        from core.db.models import KafkaMessage
        # 2026-10-25 -- the tracker's columns, read from the payload HERE,
        # the one door both roads (the topic, the QS_KAFKA_MESSAGE watcher)
        # land through.  Never raises: an unreadable payload lands untracked.
        from core.feed.message_tracker import track_columns
        data = {**track_columns(data.get("payload"), landed_at=data.get("landed_at")), **data}
        try:
            with self.get_session() as session:
                row = KafkaMessage(**data)
                session.add(row)
                session.flush()
                session.refresh(row)
                return row.to_dict()
        except IntegrityError as _ie:
            # ONLY a unique-key violation is a dedupe.  A CHECK or
            # NOT NULL violation is a real failure and must RAISE —
            # translating it to None would silently drop a message.
            _txt = str(getattr(_ie, "orig", _ie)).lower()
            if "unique" not in _txt and "duplicate" not in _txt:
                raise
            # At-least-once transport noise (a rebalance redelivery, or
            # the other pod won the race) — classified without alarm
            # (FR-DEP-09); the caller logs the dedupe.
            logger.debug(
                "[kafka-landing] duplicate (topic=%r partition=%r offset=%r) "
                "absorbed by uq_kafka_messages_topic_partition_offset (%s)",
                data.get("topic"), data.get("partition"), data.get("offset"),
                _ie.__class__.__name__)
            return None

    def get_kafka_message(self, topic: str, partition: int,
                          offset: int) -> Optional[dict]:
        """The landed row for one (topic, partition, offset), or None."""
        from core.db.models import KafkaMessage
        with self.get_session(read_only=True) as session:
            row = (session.query(KafkaMessage)
                   .filter(KafkaMessage.topic == topic,
                           KafkaMessage.partition == int(partition),
                           KafkaMessage.offset == int(offset))
                   .first())
            return row.to_dict() if row else None

    def list_unresolved_kafka_messages(self, limit: int = 200) -> List[dict]:
        """Rows still awaiting meaning (resolution='landed'), oldest
        first.  'unresolvable' rows are deliberately NOT here — FR-DEP-20:
        a poison message is marked once and never retried."""
        from core.db.models import KafkaMessage
        with self.get_session(read_only=True) as session:
            q = (session.query(KafkaMessage)
                 .filter(KafkaMessage.resolution == "landed")
                 .order_by(KafkaMessage.id.asc())
                 .limit(int(limit)))
            return [r.to_dict() for r in q.all()]

    def mark_kafka_message_resolved(self, message_id: int, *,
                                    dependency_name: str,
                                    business_date) -> Optional[dict]:
        """Flip one 'landed' row to 'resolved', recording WHAT it
        resolved to.  Returns None when the row is missing or already
        decided — a resolved/unresolvable row is never re-flipped, so
        two racing resolver passes cannot double-mark."""
        from core.db.models import KafkaMessage
        with self.get_session() as session:
            row = (session.query(KafkaMessage)
                   .filter(KafkaMessage.id == int(message_id),
                           KafkaMessage.resolution == "landed")
                   .first())
            if row is None:
                return None
            now = datetime.now(timezone.utc)
            row.resolution = "resolved"
            row.dependency_name = dependency_name
            row.business_date = business_date
            row.resolved_at = now
            row.updated_at = now
            row.updated_by = "resolver"
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def mark_kafka_message_unmatched(self, message_id: int, *,
                                     dependency_name: str, business_date,
                                     reason: str) -> Optional[dict]:
        """2026-10-10 -- flip one 'landed' row to 'unmatched': a templated
        rule rendered ``dependency_name`` from the payload and no active
        feed declares it.  The rendered name and date are recorded (the
        operator's question is "which combination arrived with no feed"),
        the reason beside them.  Returns None when the row is missing or
        already decided."""
        from core.db.models import KafkaMessage
        with self.get_session() as session:
            row = (session.query(KafkaMessage)
                   .filter(KafkaMessage.id == int(message_id),
                           KafkaMessage.resolution == "landed")
                   .first())
            if row is None:
                return None
            now = datetime.now(timezone.utc)
            row.resolution = "unmatched"
            row.dependency_name = dependency_name
            row.business_date = business_date
            row.unresolvable_reason = str(reason)[:1000]
            row.resolved_at = now
            row.updated_at = now
            row.updated_by = "resolver"
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_kafka_messages_by_resolution(self, resolution: str, *,
                                          limit: int = 200,
                                          since=None) -> List[dict]:
        """Rows in one resolution state, newest first; ``since`` bounds
        ``landed_at`` (an aware or naive datetime).  The operator surface
        for 'unmatched' (2026-10-10)."""
        from core.db.models import KafkaMessage
        with self.get_session(read_only=True) as session:
            q = (session.query(KafkaMessage)
                 .filter(KafkaMessage.resolution == str(resolution)))
            if since is not None:
                q = q.filter(KafkaMessage.landed_at >= since)
            q = q.order_by(KafkaMessage.id.desc()).limit(int(limit))
            return [r.to_dict() for r in q.all()]

    # -- The dependency-message monitor (2026-10-11) --------------------

    def list_dependency_messages(self, resolution: Optional[str] = None, *,
                                 since=None, limit: int = 500, offset: int = 0) -> List[dict]:
        """Every landed upstream message -- the Kafka topic AND the
        QS_KAFKA_MESSAGE watcher land in the same table -- newest first,
        optionally one resolution only."""
        from core.db.models import KafkaMessage
        with self.get_session(read_only=True) as session:
            q = session.query(KafkaMessage)
            if resolution:
                q = q.filter(KafkaMessage.resolution == str(resolution))
            if since is not None:
                q = q.filter(KafkaMessage.landed_at >= since)
            return [r.to_dict() for r in q.order_by(KafkaMessage.id.desc())
                    .offset(int(offset)).limit(int(limit)).all()]

    def dependency_message_counts(self, *, since=None) -> Dict[str, int]:
        from sqlalchemy import func
        from core.db.models import KafkaMessage
        with self.get_session(read_only=True) as session:
            q = session.query(KafkaMessage.resolution, func.count(KafkaMessage.id))
            if since is not None:
                q = q.filter(KafkaMessage.landed_at >= since)
            return {str(k): int(n) for k, n in q.group_by(KafkaMessage.resolution).all()}

    def list_tracked_messages(self, day, by: str = "business") -> List[dict]:
        """Every landed message whose payload says business date ``day``
        (``by`` = "business"), or that was CREATED on ``day`` (``by`` =
        "run") -- the tracker's columns only (never the payload), oldest
        first.  One indexed read (ix_kafka_messages_track / _track_run)."""
        from core.db.models import KafkaMessage as K
        col = K.trk_run_date if by == "run" else K.trk_business_date
        with self.get_session(read_only=True) as session:
            rows = (session.query(K.id, K.topic, K.landed_at, K.resolution, K.unresolvable_reason,
                                  K.dependency_name, K.trk_code, K.trk_data_source, K.trk_state,
                                  K.trk_key, K.trk_fields)
                    .filter(col == day)
                    .order_by(K.landed_at, K.id).all())
            return [{"id": r[0], "topic": r[1], "landed_at": r[2], "resolution": r[3],
                     "reason": r[4], "dependency_name": r[5], "code": r[6], "data_source": r[7],
                     "state": r[8], "key": r[9], "fields": r[10]} for r in rows]

    def kafka_messages_by_ids(self, ids) -> List[dict]:
        """The FULL landed messages (payload included) for ``ids`` -- the
        tracker opens one message's arrivals on demand (2026-10-25)."""
        from core.db.models import KafkaMessage as K
        ids = [int(i) for i in ids][:500]
        if not ids:
            return []
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in session.query(K).filter(K.id.in_(ids)).order_by(K.landed_at, K.id).all()]

    def tracked_message_dates(self, limit: int = 60, by: str = "business") -> List[dict]:
        """``[{business_date, messages}]`` newest day first -- the tracker's
        date picker, by business date or by run date (``by`` = "run")."""
        from sqlalchemy import func
        from core.db.models import KafkaMessage as K
        col = K.trk_run_date if by == "run" else K.trk_business_date
        with self.get_session(read_only=True) as session:
            rows = (session.query(col, func.count(K.id))
                    .filter(col.isnot(None))
                    .group_by(col)
                    .order_by(col.desc()).limit(int(limit)).all())
            return [{"business_date": d.isoformat(), "messages": int(n)} for d, n in rows]

    def untracked_message_count(self) -> int:
        from sqlalchemy import func
        from core.db.models import KafkaMessage as K
        with self.get_session(read_only=True) as session:
            return int(session.query(func.count(K.id)).filter(_stale_tracking(K)).scalar() or 0)

    def backfill_message_tracking(self, limit: int = 2000) -> int:
        """Read the tracker's columns for up to ``limit`` rows that landed
        before the tracker existed.  Returns the rows filled.  Every row read
        is stamped (an unreadable payload gets ``trk_version`` and NULL
        columns), so the backfill always finishes."""
        from core.db.models import KafkaMessage as K
        from core.feed.message_tracker import track_columns
        with self.get_session() as session:
            rows = (session.query(K.id, K.payload, K.landed_at).filter(_stale_tracking(K))
                    .order_by(K.id).limit(int(limit)).all())
            if not rows:
                return 0
            session.bulk_update_mappings(K, [{"id": rid, **track_columns(p, landed_at=la)}
                                             for rid, p, la in rows])
            return len(rows)

    def feeds_declaring_dependencies(self, names, business_date) -> Dict[str, List[dict]]:
        """``{dependency name: [{feed_id, feed_name, run_status,
        action_decision}]}`` -- every ACTIVE feed declaring each name, with
        its run for ``business_date`` (None when it has none).  One query."""
        names = [str(n) for n in names if n]
        if not names:
            return {}
        with self.get_session(read_only=True) as session:
            rows = (session.query(EtlDependencyMapping.dependency_key, FeedConfig.id, FeedConfig.name,
                                  FeedRun.status, FeedRun.action_decision)
                    .join(FeedConfig, FeedConfig.id == EtlDependencyMapping.etl_id)
                    .outerjoin(FeedRun, (FeedRun.feed_config_id == FeedConfig.id)
                               & (FeedRun.business_date == business_date))
                    .filter(EtlDependencyMapping.dependency_key.in_(names),
                            EtlDependencyMapping.is_active.is_(True),
                            FeedConfig.is_active.is_(True))
                    .all())
            out: Dict[str, List[dict]] = {}
            for key, fid, fname, st, act in rows:
                out.setdefault(str(key), []).append({"feed_id": int(fid), "feed_name": fname,
                                                     "run_status": st, "action_decision": act})
            return out

    def dependency_key_is_declared(self, dependency_key: str) -> bool:
        """Whether ANY active mapping declares ``dependency_key`` (exact
        spelling).  The resolver asks it for a name a templated rule
        rendered; a read failure PROPAGATES (the caller treats it as
        declared -- unreadable is not undeclared)."""
        with self.get_session(read_only=True) as session:
            return session.query(
                session.query(EtlDependencyMapping.id)
                .filter(EtlDependencyMapping.dependency_key == str(dependency_key),
                        EtlDependencyMapping.is_active.is_(True))
                .exists()).scalar() is True

    def mark_kafka_message_filtered(self, message_id: int,
                                    reason: str) -> Optional[dict]:
        """2026-10-11 -- flip one 'landed' row to 'filtered': a rule for its
        topic saw it and its ``match`` filter excluded it (a non-COMPLETE
        state).  The reason is kept beside it; no alert.  Returns None when
        the row is missing or already decided."""
        from core.db.models import KafkaMessage
        with self.get_session() as session:
            row = (session.query(KafkaMessage)
                   .filter(KafkaMessage.id == int(message_id),
                           KafkaMessage.resolution == "landed")
                   .first())
            if row is None:
                return None
            now = datetime.now(timezone.utc)
            row.resolution = "filtered"
            row.unresolvable_reason = str(reason)[:1000]
            row.resolved_at = now
            row.updated_at = now
            row.updated_by = "resolver"
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def mark_kafka_message_unresolvable(self, message_id: int,
                                        reason: str) -> Optional[dict]:
        """FR-DEP-20 — flip one 'landed' row to 'unresolvable' WITH the
        parse error, so it is never retried and never lost.  Returns
        None when the row is missing or already decided."""
        from core.db.models import KafkaMessage
        with self.get_session() as session:
            row = (session.query(KafkaMessage)
                   .filter(KafkaMessage.id == int(message_id),
                           KafkaMessage.resolution == "landed")
                   .first())
            if row is None:
                return None
            now = datetime.now(timezone.utc)
            row.resolution = "unresolvable"
            row.unresolvable_reason = str(reason)[:1000]
            row.resolved_at = now
            row.updated_at = now
            row.updated_by = "resolver"
            session.flush()
            session.refresh(row)
            return row.to_dict()

    # ── Change control (BRD §15) ──────────────────────────────────────

    def apply_config_deploy(self, *, environment: str, commit: str,
                            ticket: Optional[str], deployed_by: Optional[str],
                            items: List[dict]) -> List[dict]:
        """Apply reviewed definitions to an environment, in ONE transaction.

        Either every object lands with its commit stamped, or none does.  A
        half-applied deploy is the worst outcome available here: prod would be
        running a mixture nobody reviewed, and "which commit is running?" would
        have no true answer — the exact question §15 exists to make answerable.

        Each item: ``{object_type, name, definition, definition_hash, path}``.
        Returns what was touched, so the caller can report it.

        2026-10-17: the write goes through THE release engine
        (core/release/engine.apply_items) -- the same contract, registry and
        one-transaction apply a UI/CLI release uses, so a git deploy and an
        upload cannot disagree.  Before this, every type but ``feed`` was
        RECORDED without a runtime row, and a feed the environment lacked was
        recorded and never created: "applied" with nothing applied.
        """
        from core.release import engine as _engine
        return _engine.apply_items(
            self, environment=str(environment), items=items, commit=str(commit),
            ticket=ticket, actor=deployed_by)

    def get_latest_deployments(self, environment: str) -> List[dict]:
        """The newest deployment per governed object — what SHOULD be running.

        The drift report compares this against what IS.
        """
        from core.db.models import ConfigDeployment
        with self.get_session(read_only=True) as session:
            rows = (session.query(ConfigDeployment)
                    .filter(ConfigDeployment.environment == str(environment))
                    .order_by(ConfigDeployment.deployed_at.desc(),
                              ConfigDeployment.id.desc())
                    .all())
        latest: dict = {}
        for row in rows:
            key = (row.object_type, row.object_id, row.name)
            if key not in latest:            # rows are newest-first
                latest[key] = row.to_dict()
        return list(latest.values())

    # get_governed_object / list_governed_objects: core/db/mixin_release.py
    # (2026-10-17 -- every registered release type, not only ``feed``).

    # ── FR-SLA-01/05 (2026-09-03) — measured runtime profiles ────────────
    # The producer side of the SLA decision ladder.  APPEND-ONLY: a row is
    # never updated in place, so "what did we expect on the day we alerted"
    # is always the latest row with computed_at <= that day (FR-SLA-05).

    def insert_feed_runtime_profile(self, data: dict) -> dict:
        """Append one recompute result.  Raises on DB failure — the
        fail-open wrapper lives in core/feed/runtime_profile.py."""
        from core.db.models import FeedRuntimeProfile
        with self.get_session() as session:
            row = FeedRuntimeProfile(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_latest_feed_runtime_profile(self, feed_config_id: int,
                                        as_of=None) -> Optional[dict]:
        """The profile in force for a feed — newest row, or newest row at
        or before ``as_of`` (the audit read: what did we expect THEN)."""
        from core.db.models import FeedRuntimeProfile
        with self.get_session(read_only=True) as session:
            q = (session.query(FeedRuntimeProfile)
                 .filter(FeedRuntimeProfile.feed_config_id
                         == int(feed_config_id)))
            if as_of is not None:
                q = q.filter(FeedRuntimeProfile.computed_at <= as_of)
            row = (q.order_by(FeedRuntimeProfile.computed_at.desc(),
                              FeedRuntimeProfile.id.desc())
                    .first())
            return row.to_dict() if row else None

    def list_feed_runtime_profiles(self, feed_config_id: int,
                                   limit: int = 50) -> List[dict]:
        """Profile history newest-first — the audit trail itself."""
        from core.db.models import FeedRuntimeProfile
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedRuntimeProfile)
                    .filter(FeedRuntimeProfile.feed_config_id
                            == int(feed_config_id))
                    .order_by(FeedRuntimeProfile.computed_at.desc(),
                              FeedRuntimeProfile.id.desc())
                    .limit(int(limit)).all())
            return [r.to_dict() for r in rows]

    # ── FR-DEP-10/18/20 (2026-09-03) — regeneration decisions ────────────

    def insert_regeneration_decision(self, data: dict) -> dict:
        from core.db.models import FeedRegenerationDecision
        payload = dict(data)
        if "business_date" in payload:
            payload["business_date"] = _coerce_business_date(
                payload["business_date"])
        with self.get_session() as session:
            row = FeedRegenerationDecision(**payload)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_regeneration_decision(self, decision_id: int) -> Optional[dict]:
        from core.db.models import FeedRegenerationDecision
        with self.get_session(read_only=True) as session:
            row = (session.query(FeedRegenerationDecision)
                   .filter(FeedRegenerationDecision.id == int(decision_id))
                   .first())
            return row.to_dict() if row else None

    def list_regeneration_decisions(self, *, feed_config_id: int = None,
                                    business_date=None, status: str = None,
                                    dependency_name: str = None,
                                    limit: int = 200) -> List[dict]:
        """Decisions, newest-raised first.  Every filter optional — the
        operator screen asks by feed+date, the raiser's idempotency check
        asks by (feed, date, dependency, status='open')."""
        from core.db.models import FeedRegenerationDecision
        with self.get_session(read_only=True) as session:
            q = session.query(FeedRegenerationDecision)
            if feed_config_id is not None:
                q = q.filter(FeedRegenerationDecision.feed_config_id
                             == int(feed_config_id))
            if business_date is not None:
                q = q.filter(FeedRegenerationDecision.business_date
                             == _coerce_business_date(business_date))
            if status is not None:
                q = q.filter(FeedRegenerationDecision.status == str(status))
            if dependency_name is not None:
                q = q.filter(FeedRegenerationDecision.dependency_name
                             == str(dependency_name))
            rows = (q.order_by(FeedRegenerationDecision.raised_at.desc(),
                               FeedRegenerationDecision.id.desc())
                     .limit(int(limit)).all())
            return [r.to_dict() for r in rows]

    def resolve_regeneration_decision(self, decision_id: int, *,
                                      resolution: str, resolved_by: str,
                                      reason: str) -> Optional[dict]:
        """Flip ONE open decision to resolved.  Returns None when the row
        is missing or ALREADY resolved — a decision is decided once; a
        second resolver must see the first answer, never overwrite it."""
        from core.db.models import FeedRegenerationDecision
        with self.get_session() as session:
            row = (session.query(FeedRegenerationDecision)
                   .filter(FeedRegenerationDecision.id == int(decision_id),
                           FeedRegenerationDecision.status == "open")
                   .first())
            if row is None:
                return None
            row.status = "resolved"
            row.resolution = str(resolution)
            row.resolved_by = str(resolved_by)
            row.resolved_at = datetime.now(timezone.utc)
            row.resolution_reason = str(reason)[:1000]
            session.flush()
            session.refresh(row)
            return row.to_dict()

    # ── FR-DEP-14 (2026-09-03) — maker/checker skip approvals ────────────

    def insert_feed_skip_approval(self, data: dict) -> dict:
        """One actor's approval of one skip.  The unique key makes the
        same actor approving twice idempotent (returns the existing row)
        — one person clicking twice is still ONE approver."""
        from sqlalchemy.exc import IntegrityError

        from core.db.models import FeedSkipApproval
        payload = dict(data)
        if "business_date" in payload:
            payload["business_date"] = _coerce_business_date(
                payload["business_date"])
        try:
            with self.get_session() as session:
                row = FeedSkipApproval(**payload)
                session.add(row)
                session.flush()
                session.refresh(row)
                return row.to_dict()
        except IntegrityError:
            existing = [a for a in self.list_feed_skip_approvals(
                            dependency_type_id=payload["dependency_type_id"],
                            dependency_key=payload["dependency_key"],
                            business_date=payload["business_date"])
                        if a.get("actor") == payload.get("actor")]
            if existing:
                return existing[0]
            raise

    def list_feed_skip_approvals(self, *, dependency_type_id: int,
                                 dependency_key: str,
                                 business_date) -> List[dict]:
        from core.db.models import FeedSkipApproval
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedSkipApproval)
                    .filter(FeedSkipApproval.dependency_type_id
                            == int(dependency_type_id),
                            FeedSkipApproval.dependency_key
                            == str(dependency_key),
                            FeedSkipApproval.business_date
                            == _coerce_business_date(business_date))
                    .order_by(FeedSkipApproval.created_at.asc(),
                              FeedSkipApproval.id.asc())
                    .all())
            return [r.to_dict() for r in rows]

    # ── FR-DEP-10/18 reverse lookups (2026-09-03) ────────────────────────

    def list_etl_ids_for_dependency_key(self, dependency_key: str) -> List[int]:
        """Every etl_id whose mapping names this dependency — the reverse
        edge the replay decision walks: which feeds consumed the thing
        that just replayed."""
        from core.db.models import EtlDependencyMapping
        with self.get_session(read_only=True) as session:
            rows = (session.query(EtlDependencyMapping.etl_id)
                    .filter(EtlDependencyMapping.dependency_key
                            == str(dependency_key),
                            EtlDependencyMapping.is_active.is_(True))
                    .distinct().all())
            return sorted(int(r[0]) for r in rows)

    def list_feed_configs_by_etl_id(self, etl_id: int) -> List[dict]:
        """The active feeds whose EFFECTIVE etl_id (explicit etl_id, else
        the feed's own id -- ``core.feed.etl_dependency.effective_etl_id``)
        is ``etl_id``.  Until 2026-09-27 this matched the explicit column
        only, so a replay could not find the feed consuming a dependency
        authored under the feed's own id."""
        from sqlalchemy import func
        with self.get_session(read_only=True) as session:
            rows = (session.query(FeedConfig)
                    .filter(func.coalesce(FeedConfig.etl_id, FeedConfig.id)
                            == int(etl_id),
                            FeedConfig.is_active.is_(True))
                    .order_by(FeedConfig.id.asc())
                    .all())
            return [r.to_dict() for r in rows]



def _default_control_file_formats() -> List[dict]:
    """Seed rows — predefined CTL templates.  Stored as Python dicts here
    so the seeder can insert them; admins edit via the admin UI after
    install (NOT a hardcoded business rule — just a starting point)."""
    return [
        {
            "name": "enterprise_kv_md5",
            "description": "Key-value format with MD5 checksum (most common enterprise)",
            "style": "key_value",
            "delimiter": "|",
            "fields": [
                "filename", "row_count", "byte_size",
                "checksum_md5", "business_date", "generated_at",
            ],
            "field_specs": {
                "filename": {"label": "FILE_NAME"},
                "row_count": {"label": "TOTAL_ROWS"},
                "byte_size": {"label": "FILE_SIZE_BYTES"},
                "checksum_md5": {"label": "MD5_CHECKSUM"},
                "business_date": {"label": "BUSINESS_DATE", "format": "%Y%m%d"},
                "generated_at": {"label": "CREATED_AT"},
            },
            "checksum_algorithm": "md5",
            "is_active": True,
            "is_default": True,
        },
        {
            "name": "enterprise_kv_md5_sha256",
            "description": "Key-value with both MD5 and SHA-256 (defence in depth)",
            "style": "key_value",
            "delimiter": "|",
            "fields": [
                "filename", "row_count", "byte_size",
                "checksum_md5", "checksum_sha256",
                "business_date", "generated_at",
            ],
            "checksum_algorithms": ["md5", "sha256"],
            "is_active": True,
        },
        {
            "name": "enterprise_pipe_delimited",
            "description": "Single-line pipe-delimited (FLX-style)",
            "style": "delimited",
            "delimiter": "|",
            "fields": [
                "filename", "row_count", "byte_size",
                "checksum_md5", "business_date",
            ],
            "checksum_algorithm": "md5",
            "is_active": True,
        },
        {
            "name": "csv_with_sha256",
            "description": "Comma-delimited control with SHA-256 only",
            "style": "delimited",
            "delimiter": ",",
            "fields": [
                "filename", "row_count", "byte_size", "checksum_sha256",
            ],
            "checksum_algorithm": "sha256",
            "is_active": True,
        },
        {
            "name": "mainframe_kv_full",
            "description": "Key-value with all checksums + extended metadata (mainframe-friendly)",
            "style": "key_value",
            "delimiter": "|",
            "fields": [
                "filename", "row_count", "byte_size",
                "checksum_md5", "checksum_sha1", "checksum_sha256",
                "checksum_crc32",
                "business_date", "feed_name", "feed_id", "run_id",
                "generated_at",
            ],
            "checksum_algorithms": ["md5", "sha1", "sha256", "crc32"],
            "is_active": True,
        },
    ]


def _stale_tracking(K):
    """Rows whose tracker columns are missing or were read by an older
    ``message_tracker.TRACK_VERSION`` -- the backfill re-reads them."""
    from sqlalchemy import or_
    from core.feed.message_tracker import TRACK_VERSION
    return or_(K.trk_version.is_(None), K.trk_version < TRACK_VERSION)
