"""Report themes -- the library of named looks (2026-11-01; rules in
core/reports/themes.py).  RELEASE by name, ``is_active`` (delete = switch off)."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from core.config_active import active_clause, switch_off
from core.db.models import ReportTheme


class ReportThemesMixin:
    def list_report_themes(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [t.to_dict() for t in session.query(ReportTheme).filter(active_clause(ReportTheme))
                    .order_by(ReportTheme.name).all()]

    def get_report_theme(self, theme_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            t = session.query(ReportTheme).filter(ReportTheme.id == int(theme_id), active_clause(ReportTheme)).first()
            return t.to_dict() if t else None

    def get_report_theme_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            t = session.query(ReportTheme).filter(ReportTheme.name == str(name), active_clause(ReportTheme)).first()
            return t.to_dict() if t else None

    def create_report_theme(self, data: Dict[str, Any], by: str = "") -> Dict[str, Any]:
        with self.get_session() as session:
            t = ReportTheme(name=str(data["name"]).strip(), description=data.get("description"),
                            theme=data.get("theme") or {}, created_by=by, updated_by=by)
            session.add(t)
            session.flush()
            return t.to_dict()

    def update_report_theme(self, theme_id: int, data: Dict[str, Any], by: str = "") -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            t = session.query(ReportTheme).filter(ReportTheme.id == int(theme_id), active_clause(ReportTheme)).first()
            if not t:
                return None
            for k in ("name", "description", "theme"):
                if k in data and data[k] is not None:
                    setattr(t, k, data[k])
            t.updated_by = by
            t.updated_at = datetime.now(timezone.utc)
            session.flush()
            return t.to_dict()

    def delete_report_theme(self, theme_id: int, by: str = "") -> bool:
        """Switches the theme OFF (config is_active); reports naming it fall back to the default look."""
        with self.get_session() as session:
            t = session.query(ReportTheme).filter(ReportTheme.id == int(theme_id), active_clause(ReportTheme)).first()
            if not t:
                return False
            switch_off(t, by_user=by)
            return True
