"""
Mixin — Data Quality Monitoring CRUD (Phase 99).
Extracted from DatabaseManager for modularity.
"""
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict

from core.db.models import DataQualityRule, DataQualityResult, DataQualityAlert


class DataQualityMixin:
    """Database methods for DQ rules and results."""

    # ── DQ Rules CRUD ────────────────────────────────────────────────────

    def create_dq_rule(self, **kwargs) -> dict:
        with self.get_session() as session:
            rule = DataQualityRule(**kwargs)
            session.add(rule)
            session.flush()
            session.refresh(rule)
            return rule.to_dict()

    # 2026-10-30 (owner): a deleted rule is SWITCHED OFF (is_active=false);
    # every read below hides it -- the scheduled DQ run, the screens, the
    # summary -- and its results stay as history.  ``enabled`` is PAUSED.

    def get_dq_rule(self, rule_id: int) -> Optional[dict]:
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            r = session.query(DataQualityRule).filter(
                DataQualityRule.id == rule_id, active_clause(DataQualityRule)).first()
            return r.to_dict() if r else None

    def list_dq_rules(self, target_type: str = None, target_id: int = None,
                      enabled_only: bool = False) -> List[dict]:
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            q = session.query(DataQualityRule).filter(active_clause(DataQualityRule))
            if target_type:
                q = q.filter(DataQualityRule.target_type == target_type)
            if target_id is not None:
                q = q.filter(DataQualityRule.target_id == target_id)
            if enabled_only:
                q = q.filter(DataQualityRule.enabled)
            return [r.to_dict() for r in q.order_by(DataQualityRule.id).all()]

    def update_dq_rule(self, rule_id: int, **updates) -> Optional[dict]:
        from core.config_active import active_clause
        with self.get_session() as session:
            r = session.query(DataQualityRule).filter(
                DataQualityRule.id == rule_id, active_clause(DataQualityRule)).first()
            if not r:
                return None
            for k, v in updates.items():
                if hasattr(r, k):
                    setattr(r, k, v)
            session.flush()
            session.refresh(r)
            return r.to_dict()

    def delete_dq_rule(self, rule_id: int) -> bool:
        """Switch the rule OFF (2026-10-30: config rows are never erased).
        Its results are history and stay (they used to be cascade-deleted
        with the rule); the scheduled run no longer lists it."""
        from core.config_active import active_clause, switch_off
        with self.get_session() as session:
            r = session.query(DataQualityRule).filter(
                DataQualityRule.id == rule_id, active_clause(DataQualityRule)).first()
            if not r:
                return False
            switch_off(r)
            return True

    # ── DQ Results CRUD ──────────────────────────────────────────────────

    def create_dq_result(self, **kwargs) -> dict:
        with self.get_session() as session:
            res = DataQualityResult(**kwargs)
            session.add(res)
            session.flush()
            session.refresh(res)
            return res.to_dict()

    def list_dq_results(self, rule_id: int = None, passed: bool = None,
                        limit: int = 100) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(DataQualityResult)
            if rule_id is not None:
                q = q.filter(DataQualityResult.rule_id == rule_id)
            if passed is not None:
                q = q.filter(DataQualityResult.passed == passed)
            return [r.to_dict() for r in q.order_by(DataQualityResult.checked_at.desc()).limit(limit).all()]

    def get_latest_dq_result(self, rule_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            r = (session.query(DataQualityResult)
                 .filter(DataQualityResult.rule_id == rule_id)
                 .order_by(DataQualityResult.checked_at.desc())
                 .first())
            return r.to_dict() if r else None

    def acknowledge_dq_result(self, result_id: int, username: str) -> Optional[dict]:
        with self.get_session() as session:
            r = session.query(DataQualityResult).filter(DataQualityResult.id == result_id).first()
            if not r:
                return None
            r.acknowledged = True
            r.acknowledged_by = username
            r.acknowledged_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(r)
            return r.to_dict()

    def cleanup_dq_results(self, retention_days: int = 90) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        with self.get_session() as session:
            count = session.query(DataQualityResult).filter(
                DataQualityResult.checked_at < cutoff
            ).delete()
            return count

    def get_dq_summary(self, target_type: str = None, target_id: int = None) -> dict:
        """Aggregated pass/fail stats for recent DQ results."""
        rules = self.list_dq_rules(target_type=target_type, target_id=target_id)
        total = len(rules)
        passing = 0
        failing = 0
        errored = 0
        no_data = 0
        for rule in rules:
            latest = self.get_latest_dq_result(rule["id"])
            if not latest:
                no_data += 1
            elif latest.get("outcome") == "errored":
                # 2026-09-17 (FB-8b) -- a check that COULD NOT RUN is not a
                # data failure.  Counting it as one told the data owner their
                # data was bad when the rule was misconfigured; the two lead
                # to opposite investigations.  Rows written before the column
                # existed have outcome=None and keep the old passed/failed
                # reading -- unknown, not silently reclassified.
                errored += 1
            elif latest["passed"]:
                passing += 1
            else:
                failing += 1
        return {
            "total_rules": total,
            "passing": passing,
            "failing": failing,
            "errored": errored,
            "no_data": no_data,
            "health": "healthy" if failing == 0 else ("degraded" if failing <= total * 0.3 else "unhealthy"),
            # Separate axis on purpose: data health and CHECK health are
            # different questions and one must not mask the other.
            "checks_healthy": errored == 0,
        }

    # ── DQ Alerts (Phase 114-E) ────────────────────────────────────────────

    def create_dq_alert(self, **kwargs) -> dict:
        with self.get_session() as session:
            alert = DataQualityAlert(**kwargs)
            session.add(alert)
            session.flush()
            result = alert.to_dict()
            session.commit()
            return result

    def list_dq_alerts(self, rule_id: int = None, status: str = None,
                       limit: int = 100) -> List[dict]:
        with self.get_session() as session:
            q = session.query(DataQualityAlert)
            if rule_id is not None:
                q = q.filter(DataQualityAlert.rule_id == rule_id)
            if status:
                q = q.filter(DataQualityAlert.status == status)
            return [a.to_dict() for a in q.order_by(DataQualityAlert.id.desc()).limit(limit).all()]

    def get_dq_alert_summary(self) -> dict:
        """Counts of alerts by channel and status."""
        with self.get_session() as session:
            all_alerts = session.query(DataQualityAlert).all()
            by_channel: Dict[str, int] = {}
            by_status: Dict[str, int] = {}
            for a in all_alerts:
                by_channel[a.channel] = by_channel.get(a.channel, 0) + 1
                by_status[a.status] = by_status.get(a.status, 0) + 1
            return {"total": len(all_alerts), "by_channel": by_channel, "by_status": by_status}

    # ── DQ Trend (Phase 114-F) ─────────────────────────────────────────────

    def list_dq_results_for_trend(self, rule_id: int, limit: int = 30) -> List[dict]:
        """Last N results for a rule, ordered by checked_at ASC (time-series)."""
        with self.get_session() as session:
            q = (session.query(DataQualityResult)
                 .filter(DataQualityResult.rule_id == rule_id)
                 .order_by(DataQualityResult.checked_at.desc())
                 .limit(limit))
            results = [r.to_dict() for r in q.all()]
            results.reverse()  # ASC order for charting
            return results
