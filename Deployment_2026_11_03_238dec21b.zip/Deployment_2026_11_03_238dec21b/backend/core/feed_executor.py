"""FeedExecutor seam — the single, orchestrator-agnostic entrypoint for feed runs.

Phase (feed-seam, 2026-07-16).  ONE function — :func:`run_feed` — that ANY
orchestrator calls to run "feed X for business_date Y, triggered by <who>":

    * QS scheduler / queue worker (in-process, today)
    * A UI "Run now" click (via ``POST /api/feeds/{id}/execute``)
    * Airflow / OTG later (via the same execute API + a status poll)

It exists so feed logic is single-sourced: Airflow never re-implements source
read / transform / delivery — it triggers this seam, which REUSES the tested,
live :func:`core.feed_engine.execute_feed` pipeline (native DuckDB /
Spark-Connect / Airflow-DAG dispatch, RLS, creds, SFTP/S3/control-file/
named-file delivery — all inherited, none reimplemented here).

This mirrors the F2 ``ReportExecutor`` / ``_dispatch_business_report_execution``
chokepoint (commit 7e460dcf): one factored body that every caller routes
through so schedulers and external triggers can never diverge.

What this module ADDS on top of ``execute_feed`` (and ONLY this):
    1. A stable ``run_feed(...) -> status_dict`` contract any caller can poll.
    2. Idempotency per (feed_id, business_date, trigger_type) — a second
       trigger for the same key while one is running/complete returns the
       EXISTING execution's status instead of starting a duplicate.
    3. A fail-safe net — if the underlying pipeline raises before it can
       record its own failure, we record a FAILED execution and return the
       error (never a partial delivery).

It deliberately does NOT change native / Spark-Connect / Airflow execution
behaviour — it wraps them.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import date, datetime, timezone
from typing import Any, Dict, Optional

from core.feed import pinning as _pinning

logger = logging.getLogger(__name__)

# ── Trigger taxonomy ──────────────────────────────────────────────────────
# Triggers that come from an EXTERNAL orchestrator (Airflow / OTG).  For
# these, ``run_feed`` is the single execution authority: the caller must
# route through the seam exactly once and MUST NOT also fire a second
# background ``execute_feed`` (audit gap #7 — the double-execution guard).
EXTERNAL_ORCHESTRATOR_TRIGGERS = frozenset({"airflow", "otg"})

# Triggers whose intent is to re-run even when a terminal run already exists
# for the (feed, business_date) key.  Everything else is short-circuited by
# the idempotency guard when a completed run is present.
RERUN_TRIGGERS = frozenset({"retry", "rerun"})

# feed_runs.status values that mean "a run for this (feed, date) is already
# owned" — a fresh trigger must not start a duplicate.
_ACTIVE_RUN_STATES = frozenset({"pending", "running", "in_progress", "queued"})
# Phase 4 (2026-08-23): "skipped" is a VERDICT (SOD action condition said
# don't run today), and it belongs in the done set — it was in neither set,
# so an airflow/otg trigger fell straight through and EXECUTED a run the
# SOD generator had auditable-y skipped, overwriting the verdict.  An
# explicit rerun/retry (RERUN_TRIGGERS) still overrides it — that is a
# human decision, same as re-running a completed day.
_DONE_RUN_STATES = frozenset({"completed", "success", "skipped"})

# feed_executions.status values considered terminal.
_TERMINAL_EXEC_STATES = frozenset({"completed", "failed", "cancelled"})


def _get_db():
    """Resolve the shared DB manager the feed engine already uses.

    Single source of truth — we read ``feed_engine._db_manager`` rather than
    holding our own handle so the seam and the pipeline can never point at
    different databases.
    """
    from core import feed_engine
    if feed_engine._db_manager is None:  # pragma: no cover - defensive
        raise RuntimeError("feed_engine._db_manager not initialised")
    return feed_engine._db_manager


def _default_triggered_by(trigger_type: str) -> str:
    return {
        "scheduled": "scheduler",
        "queue": "queue_worker",
        "airflow": "airflow",
        "otg": "otg",
    }.get(trigger_type, "orchestrator")


#: The run_type of a manual "Run Now" run (see run_feed step 3b).
MANUAL_RUN_TYPE = "manual"
#: The run_type AND trigger_type of a DRY RUN (2026-09-27): a manual run
#: that delivers nothing.  One spelling, read by the engine, the Today
#: page and ``manual_run_excluded``.
DRY_RUN_TYPE = "dry_run"


def manual_build_id(execution_id: str) -> str:
    """The build_id of the manual run an execution owns -- derived, so the
    execution -> run link is exact with no extra column."""
    return f"manual-{execution_id}"[:40]


#: The marker a manual run's action_reason carries when it went although
#: the gate said NOT MET (2026-09-27).  One spelling; the Today page and
#: the timeline read it.
DEPENDENCIES_OVERRIDDEN_MARKER = "dependencies_overridden"


def manual_override_reason(actor: Any, override: Dict[str, Any]) -> str:
    not_met = ", ".join(str(n) for n in (override.get("not_met") or [])) or "unknown"
    return (f"{DEPENDENCIES_OVERRIDDEN_MARKER} by {actor or 'unknown'}: "
            f"{override.get('reason') or ''} (not met: {not_met})")


def _record_dependencies_overridden(db: Any, *, feed_id: int, run: Dict[str, Any],
                                    actor: str, override: Dict[str, Any]) -> None:
    """The audit row for a Run Now that went on operator intent.  Fail-soft
    (the run row already carries the reason) but never silent."""
    try:
        bd = _coerce_business_date(run.get("business_date")) or datetime.now(timezone.utc).date()
        db.insert_run_event({
            "feed_config_id": int(feed_id),
            "business_date": bd,
            "build_id": run.get("build_id"),
            "event_type": "dependencies_overridden",
            "subject": ", ".join(str(n) for n in (override.get("not_met") or []))[:500],
            "actor": actor,
            "payload": {
                "reason": override.get("reason"),
                "reason_category": override.get("reason_category"),
                "not_met": list(override.get("not_met") or []),
                "verdicts": override.get("verdicts"),
                "feed_run_id": run.get("id"),
                "source": "run_now_override",
                "asserted_at": datetime.now(timezone.utc).isoformat(),
            },
        })
    except Exception as exc:
        logger.error("[feed_executor] feed %s: the dependencies_overridden audit "
                     "row could not be written (%s) -- the run row still carries "
                     "the reason", feed_id, exc)


def _coerce_business_date(business_date: Any) -> Optional[date]:
    """Normalise a business_date (date / datetime / ISO string) to a ``date``.

    Returns None when no business_date was supplied (the legacy per-feed
    manual/scheduled path that keys idempotency on the feed alone)."""
    if business_date is None:
        return None
    if isinstance(business_date, datetime):
        return business_date.date()
    if isinstance(business_date, date):
        return business_date
    # ISO string ("2026-07-16" or full timestamp)
    s = str(business_date).strip()
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        return datetime.fromisoformat(s).date()


def _status_dict(
    *,
    feed_id: int,
    status: str,
    trigger_type: str,
    execution_id: Optional[str] = None,
    execution_db_id: Optional[int] = None,
    feed_run_id: Optional[int] = None,
    reason: Optional[str] = None,
    error: Optional[str] = None,
    total_rows: Optional[int] = None,
    destination_path: Optional[str] = None,
) -> Dict[str, Any]:
    """The stable seam contract — what every caller (incl. Airflow) polls."""
    out: Dict[str, Any] = {
        "feed_id": feed_id,
        "status": status,
        "trigger_type": trigger_type,
        "execution_id": execution_id,
        "execution_db_id": execution_db_id,
        "feed_run_id": feed_run_id,
    }
    if reason is not None:
        out["reason"] = reason
    if error is not None:
        out["error"] = error
    if total_rows is not None:
        out["total_rows"] = total_rows
    if destination_path is not None:
        out["destination_path"] = destination_path
    return out


def _publish_feed_status(sd: Dict[str, Any], triggered_by: Optional[str]) -> Dict[str, Any]:
    """Publish a SEAM-authored status to the cross-pod event bus, username-routed,
    so a UI on ANOTHER pod updates live without polling — then return ``sd``.

    Reconciliation (audit gap — no double-emit): this is called ONLY for the
    seam-only outcomes that the underlying pipeline never broadcasts itself —
    idempotent short-circuits, config/validation errors, the atomic-slot loss,
    and the fail-safe net.  The normal EXECUTED path returns via
    :func:`_normalize_execution` and is intentionally NOT published here, because
    ``execute_feed`` already emits ``feed_progress`` (stage=status_running) at
    start and ``feed_completed`` / ``feed_failed`` / ``feed_cancelled`` at
    terminal — and those flow through the SAME bus (main._feed_ws_broadcast).
    Emitting here too would double-fire.

    Fire-and-forget / fail-open: a bus failure NEVER affects the returned status
    or feed execution.  ``event_bus.publish`` is itself non-blocking + never
    raises; the try/except is belt-and-suspenders for the import.
    """
    try:
        from core.event_bus import publish as _eb_publish
        from core.feed.event_audience import feed_event_audience
        try:
            _db = _get_db()
        except Exception:  # noqa: BLE001 -- the actor alone, never everybody
            _db = None
        # 2026-10-07: addressed to the feed's AUDIENCE (THE function), not
        # to ``triggered_by`` alone -- a queue-worker seam outcome was
        # addressed to "queue_worker", a name no browser has.
        # ``feed_run_id`` names the run (None for a run-less Run Now), so
        # the person who ASKED for it -- a backfill's requester -- hears.
        _audience = feed_event_audience(_db, sd.get("feed_id"), triggered_by,
                                        run_id=sd.get("feed_run_id"))
        if not _audience:
            return sd
        _eb_publish("feed_status", {
            # payload "type" wins in the delivered event so a cross-pod UI keys
            # on it exactly like the in-process feed events.
            "type": "feed_status",
            "feed_id": sd.get("feed_id"),
            "status": sd.get("status"),
            "execution_id": sd.get("execution_id"),
            "execution_db_id": sd.get("execution_db_id"),
            "feed_run_id": sd.get("feed_run_id"),
            "trigger_type": sd.get("trigger_type"),
            "reason": sd.get("reason"),
            "error": sd.get("error"),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }, audience=_audience)
    except Exception:  # pragma: no cover - defensive; publish never raises
        pass
    return sd


def _normalize_execution(feed_id: int, trigger_type: str, feed_run_id: Optional[int],
                         exec_result: Any) -> Dict[str, Any]:
    """Turn an ``execute_feed`` return value (a feed_execution dict or a
    ``{"status": "skipped", ...}`` short-circuit) into the seam contract."""
    if not isinstance(exec_result, dict):
        # Defensive — execute_feed always returns a dict, but never trust.
        return _status_dict(feed_id=feed_id, status="unknown",
                             trigger_type=trigger_type, feed_run_id=feed_run_id)
    status = (exec_result.get("status") or "unknown")
    return _status_dict(
        feed_id=feed_id,
        status=status,
        trigger_type=trigger_type,
        execution_id=exec_result.get("execution_id"),
        execution_db_id=exec_result.get("id"),
        feed_run_id=feed_run_id,
        reason=exec_result.get("reason"),
        error=exec_result.get("error_message") or exec_result.get("error"),
        total_rows=exec_result.get("total_rows"),
        destination_path=exec_result.get("destination_path"),
    )


async def run_feed(
    feed_id: int,
    *,
    business_date: Any = None,
    trigger_type: str,
    param_values: Optional[Dict[str, Any]] = None,
    execution_id: Optional[str] = None,
    triggered_by: Optional[str] = None,
    backend_override: Optional[str] = None,
    dependencies_overridden: Optional[Dict[str, Any]] = None,
    dry_run: bool = False,
    version_overrides: Optional[Dict[str, Any]] = None,
    feed_run_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Run feed ``feed_id`` for ``business_date``, triggered by ``trigger_type``.

    ``feed_run_id`` (2026-11-02): the run row the caller already owns -- the
    feed-worker's queue worker claimed a manual row an API pod HANDED OVER
    (core/feed/handover.py) and runs the request it carries.  Given, the
    ledger lookup and the manual row creation below are skipped: the row IS
    the run.

    ``version_overrides`` (2026-11-01): the Iceberg version each table is read
    at for THIS run (core/iceberg_versions.py), handed to the engine as is.

    ``dependencies_overridden`` (2026-09-27, manual only): the Run Now
    preflight found the gate NOT MET and the operator chose to run anyway
    -- ``{"reason": <validated text>, "reason_category": ..., "not_met":
    [names], "business_date": ...}``.  It is stamped on the manual run's
    ``action_reason`` and recorded as a ``dependencies_overridden`` run
    event, so the timeline says the run went on intent, not on evidence.
    Run Now stays NON-blocking: nothing here refuses on the gate.

    ``dry_run`` (2026-09-27): the engine runs the whole chain and delivers
    NOTHING (see ``execute_feed``).  A dry run never touches the
    (feed, business_date) idempotency ledger -- it is not the day's run
    and must neither be short-circuited by it nor claim it -- and its own
    run row is ``run_type='dry_run'`` (excluded by
    ``manual_run_excluded`` like a manual run).  A dry run carries no
    ``dependencies_overridden``: nothing is delivered, so there is
    nothing to override (the route never asks it for a reason).

    The single, orchestrator-agnostic entrypoint.  Reuses the existing
    :func:`core.feed_engine.execute_feed` pipeline for ALL heavy work
    (backend routing, RLS, credentials, delivery) — this function only adds
    the idempotency guard, the fail-safe net, and the stable status contract.

    Idempotent per ``(feed_id, business_date, trigger_type)``:
        * When a run for the same (feed, date) is already active or already
          completed (and the trigger is not a retry/rerun), the existing
          execution's status is returned and NO duplicate is started.
        * The per-feed atomic execution guard
          (``create_feed_execution_atomic``) is the concurrency backstop for
          two triggers racing at the exact same instant.

    Fail-safe: on any unexpected error the seam records a FAILED execution
    and returns the error — it never partial-delivers.

    Returns a status dict (see :func:`_status_dict`) — never raises for
    normal operational outcomes.
    """
    db = _get_db()
    if dry_run:
        # The flag IS the trigger: a direct caller of the seam gets the
        # same stamped execution the route gives the UI.
        trigger_type = DRY_RUN_TYPE
    triggered_by = triggered_by or _default_triggered_by(trigger_type)

    # 1. Load the feed config (existing accessor).  Fail-safe: return an
    #    error status rather than raising, so every caller polls uniformly.
    try:
        feed = await asyncio.to_thread(db.get_feed_config, feed_id)
    except Exception as exc:  # pragma: no cover - DB down
        logger.error("[feed_executor] feed %s config load failed: %s", feed_id, exc)
        return _publish_feed_status(_status_dict(
            feed_id=feed_id, status="error", trigger_type=trigger_type,
            error=f"Config load failed: {exc}"), triggered_by)
    if not feed:
        return _publish_feed_status(_status_dict(
            feed_id=feed_id, status="error", trigger_type=trigger_type,
            error=f"Feed {feed_id} not found"), triggered_by)
    if not feed.get("is_active"):
        return _publish_feed_status(_status_dict(
            feed_id=feed_id, status="error", trigger_type=trigger_type,
            error=f"Feed {feed_id} is inactive"), triggered_by)

    # 2. Resolve business_date -> feed_run row.  feed_runs is the existing
    #    idempotency ledger (one row per feed+date, see
    #    get_feed_run_by_feed_date — "one row per (feed, date)").  We reuse
    #    it, we don't invent a new key store.
    bdate = _coerce_business_date(business_date)
    is_manual = str(trigger_type or "").lower() == "manual"
    # 2026-09-27 -- neither a manual Run Now nor a dry run consults the
    # ledger.  Since 2026-09-24 a manual run OWNS a run of its own (step
    # 3b), and every reader that means "the day's scheduled run" excludes
    # it (a dry run the same way, run_type='dry_run'); adopting the SOD
    # row here is the reverse edge of that rule (a Run Now that finished
    # the day's scheduled run, or was short-circuited by it, was the
    # 2026-09-24 defect).  The Run Now dialog now sends the business date
    # it preflighted, so this branch is reached for the first time by the UI.
    if feed_run_id is None and bdate is not None and not is_manual and not dry_run:
        existing_run = await asyncio.to_thread(
            db.get_feed_run_by_feed_date, feed_id, bdate)
        if existing_run:
            run_status = (existing_run.get("status") or "").lower()
            is_rerun = trigger_type in RERUN_TRIGGERS
            if run_status in _ACTIVE_RUN_STATES or (
                run_status in _DONE_RUN_STATES and not is_rerun
            ):
                # Idempotent short-circuit — do NOT start a duplicate.
                logger.info(
                    "[feed_executor] feed %s date %s already %s (trigger=%s) — "
                    "returning existing status, no duplicate run",
                    feed_id, bdate, run_status, trigger_type,
                )
                # If a caller pre-created an execution row (the API endpoint,
                # for its sync 409/exec_id return) but this run is idempotently
                # short-circuited, release that row so it doesn't linger as
                # 'pending' until the stale reaper.
                await asyncio.to_thread(
                    _release_precreated_exec, db, execution_id,
                    f"idempotent: feed already {run_status} for {bdate}")
                latest = await asyncio.to_thread(_latest_execution, db, feed_id)
                return _publish_feed_status(_status_dict(
                    feed_id=feed_id,
                    status=run_status if run_status in _DONE_RUN_STATES else "running",
                    trigger_type=trigger_type,
                    execution_id=(latest or {}).get("execution_id"),
                    execution_db_id=(latest or {}).get("id"),
                    feed_run_id=int(existing_run["id"]),
                    reason=f"already_{run_status}",
                ), triggered_by)
            feed_run_id = int(existing_run["id"])
        else:
            try:
                # Phase 4 (2026-08-23): this create has NEVER succeeded on
                # the real schema — it omitted run_date (NOT NULL) and
                # passed trigger_type, which is not a FeedRun column at all
                # (the model's field is triggered_by).  Both errors were
                # swallowed by the "lost race" handler below, so the seam's
                # (feed, business_date) idempotency ledger was silently
                # never written for airflow/otg triggers.  Found by running
                # the create against the real schema instead of a mock.
                new_run = await asyncio.to_thread(db.create_feed_run, {
                    "feed_config_id": feed_id,
                    "business_date": bdate,
                    "run_date": datetime.now(timezone.utc).date(),
                    "status": "pending",
                    "triggered_by": trigger_type,
                })
                feed_run_id = int(new_run["id"])
            except Exception as exc:
                # A racing creator won the (feed, date) unique row — re-read
                # and short-circuit as "already owned" rather than duplicate.
                logger.info(
                    "[feed_executor] feed %s date %s feed_run create lost race "
                    "(%s) — treating as already owned", feed_id, bdate, exc)
                existing_run = await asyncio.to_thread(
                    db.get_feed_run_by_feed_date, feed_id, bdate)
                if existing_run:
                    return _publish_feed_status(_status_dict(
                        feed_id=feed_id, status="running", trigger_type=trigger_type,
                        feed_run_id=int(existing_run["id"]), reason="already_running"),
                        triggered_by)
                # No row found and we couldn't create — fall through without a
                # feed_run (legacy per-feed behaviour); do not block the run.
                feed_run_id = None

    # 3. Admit exactly one execution.  When the caller pre-created the
    #    execution row (the API endpoint, so it can return exec_id + 409
    #    synchronously), REUSE it — mirrors execute_feed's own reuse at
    #    feed_engine.py:688 and prevents a double create.  Otherwise create
    #    it atomically here (the concurrency backstop — one active execution
    #    per feed via ux_feed_executions_one_active_per_feed / BF-415).
    exec_id = execution_id or f"feed-{uuid.uuid4().hex[:16]}"
    exec_record = None
    if execution_id:
        exec_record = await asyncio.to_thread(
            db.get_feed_execution_by_exec_id, execution_id)
    if exec_record is None:
        # Foundation P wiring (2026-09-02) — stamp the run's IDENTITY.
        #
        # Until these two keys were written, every execution fell under the
        # LEGACY guard (one active execution per feed, regardless of date), so
        # a backfill of another date and a re-run of a completed date were both
        # impossible at the schema level.  With them, the partial index keyed
        # on (feed_config_id, business_date, build_id) takes over: two dates
        # run concurrently, a completed date can be re-run, and two concurrent
        # triggers for the SAME feed and date still collide into the
        # IntegrityError -> None idempotency contract below.
        #
        # ``bdate`` is None for a caller that supplied no business date; the
        # legacy per-feed guard then still applies, which is exactly today's
        # behaviour and is why this is safe to ship on its own.
        _exec_payload = {
            "feed_config_id": feed_id,
            "execution_id": exec_id,
            "status": "pending",
            "execution_backend": backend_override or "auto",
            "trigger_type": trigger_type,
            "triggered_by": triggered_by,
            "started_at": datetime.now(timezone.utc),
            "business_date": bdate,
            "build_id": _pinning.new_build_id(),
        }
        exec_record = await asyncio.to_thread(
            db.create_feed_execution_atomic, feed_id, _exec_payload)
        if exec_record is None:
            # Another trigger already holds the single active slot for this
            # feed — idempotent: return that execution's status, start nothing.
            logger.info(
                "[feed_executor] feed %s already has an active execution "
                "(trigger=%s) — returning existing status, no duplicate run",
                feed_id, trigger_type)
            latest = await asyncio.to_thread(_latest_execution, db, feed_id)
            return _publish_feed_status(_status_dict(
                feed_id=feed_id, status=(latest or {}).get("status") or "running",
                trigger_type=trigger_type,
                execution_id=(latest or {}).get("execution_id"),
                execution_db_id=(latest or {}).get("id"),
                feed_run_id=feed_run_id, reason="already_executing"), triggered_by)

    exec_db_id = exec_record.get("id")
    exec_id = exec_record.get("execution_id") or exec_id

    # 3b. A manual Run Now gets its OWN feed_run (2026-09-24).  Every run --
    #     scheduled or manual -- must produce the SAME record: step rows with
    #     wall-clock boundaries, row counts, the pod, errors, per-step re-run.
    #     The step model records against a feed_run, and a Run Now used to have
    #     none, so its timeline was a stage-duration projection with no start
    #     times.  The row is marked run_type="manual" and every reader that
    #     asks "what is the day's SCHEDULED run" excludes it
    #     (core.db.mixin_feeds.manual_run_excluded), so the SOD row, cron,
    #     the queue, the orphan reaper, regeneration and the baselines behave
    #     exactly as before.  Its build_id is derived from the execution id,
    #     which is the exact link back from the execution (feed_run_for_execution).
    if feed_run_id is None and (is_manual or dry_run):
        try:
            _today = datetime.now(timezone.utc).date()
            _manual_row: Dict[str, Any] = {
                "feed_config_id": feed_id,
                "business_date": bdate or _today,
                "run_date": _today,
                "status": "running",
                "started_at": datetime.now(timezone.utc),
                "triggered_by": DRY_RUN_TYPE if dry_run else "manual",
                "triggered_by_user": (str(triggered_by)[:100] if triggered_by else None),
                # A dry run is marked on the ROW (run_type), so the Today
                # page and every scheduled-run reader see it for what it is.
                "run_type": DRY_RUN_TYPE if dry_run else MANUAL_RUN_TYPE,
                "build_id": manual_build_id(exec_id),
            }
            if dependencies_overridden:
                _manual_row["action_decision"] = "RUN"
                _manual_row["action_reason"] = manual_override_reason(
                    triggered_by, dependencies_overridden)[:2000]
            manual_run = await asyncio.to_thread(db.create_feed_run, _manual_row)
            feed_run_id = int(manual_run["id"])
            if dependencies_overridden:
                _record_dependencies_overridden(
                    db, feed_id=feed_id, run=manual_run,
                    actor=str(triggered_by or "unknown"),
                    override=dependencies_overridden)
        except Exception as exc:
            # The run still runs -- only its step record is missing, and the
            # timeline says so (source=derived).  Never block a Run Now on
            # bookkeeping.
            logger.error(
                "[feed_executor] feed %s: could not create the manual run record "
                "(%s) -- this Run Now will show a derived step timeline",
                feed_id, exc)

    # 4. Dispatch to the EXISTING pipeline.  execute_feed internally picks the
    #    backend (native DuckDB / spark_connect / airflow) and runs delivery.
    #    We reuse it verbatim — no feed logic is copied here.
    try:
        result = await execute_feed_dispatch(
            feed_id,
            trigger_type=trigger_type,
            triggered_by=triggered_by,
            execution_id=exec_id,
            feed_run_id=feed_run_id,
            backend_override=backend_override,
            query_param_overrides=param_values,
            dry_run=dry_run,
            version_overrides=version_overrides,
        )
    except Exception as exc:
        # 5. Fail-safe net.  execute_feed records its OWN failures for errors
        #    raised inside its pipeline; this catches the rare raise before it
        #    could (e.g. config vanished between our load and its load).  We
        #    mark FAILED so no caller ever sees a stuck "pending" — and no
        #    delivery has happened, so nothing is partial.
        err = str(exc)[:2000]
        logger.error("[feed_executor] feed %s exec %s crashed pre-pipeline: %s",
                     feed_id, exec_id, err, exc_info=True)
        if exec_db_id is not None:
            try:
                await asyncio.to_thread(db.update_feed_execution, exec_db_id, {
                    "status": "failed",
                    "completed_at": datetime.now(timezone.utc),
                    "error_message": f"FeedExecutor: {err}",
                })
            except Exception:
                pass
        if feed_run_id is not None:
            try:
                await asyncio.to_thread(db.update_feed_run, feed_run_id, {
                    "status": "failed",
                    "completed_at": datetime.now(timezone.utc),
                    "error": f"FeedExecutor: {err}",
                })
            except Exception:
                pass
        return _publish_feed_status(_status_dict(
            feed_id=feed_id, status="failed", trigger_type=trigger_type,
            execution_id=exec_id, execution_db_id=exec_db_id,
            feed_run_id=feed_run_id, error=err), triggered_by)

    # NORMAL executed path — execute_feed already broadcast feed_progress +
    # feed_completed/feed_failed through the SAME bus, so we do NOT re-publish
    # here (reconciled: no double-emit).
    return _normalize_execution(feed_id, trigger_type, feed_run_id, result)


async def execute_feed_dispatch(*args, **kwargs):
    """Indirection to the live pipeline so tests can patch a single seam.

    Kept as a thin wrapper (not an alias) so the import happens lazily —
    ``feed_engine`` imports a lot and we don't want to pull it in at module
    import time — and so a test can monkeypatch
    ``core.feed_executor.execute_feed_dispatch`` to assert dispatch/idempotency
    without running real Spark/DuckDB.
    """
    from core.feed_engine import execute_feed
    return await execute_feed(*args, **kwargs)


def _release_precreated_exec(db, execution_id: Optional[str], reason: str) -> None:
    """Mark a caller-pre-created (still pending) execution row as skipped when
    the run is idempotently short-circuited, so it doesn't linger as
    'pending'.  No-op when no execution_id was supplied or the row already
    left the pending state."""
    if not execution_id:
        return
    try:
        row = db.get_feed_execution_by_exec_id(execution_id)
        if row and (row.get("status") == "pending"):
            db.update_feed_execution(row["id"], {
                "status": "skipped",
                "completed_at": datetime.now(timezone.utc),
                "error_message": reason,
            })
    except Exception:
        pass


def _latest_execution(db, feed_id: int) -> Optional[Dict[str, Any]]:
    """Best-effort lookup of the most-recent execution for a feed, so an
    idempotent short-circuit can echo back a real execution_id to poll."""
    try:
        by_id = db.get_latest_feed_executions_by_feed_ids([feed_id])
        row = by_id.get(int(feed_id)) if isinstance(by_id, dict) else None
        if row:
            return row
    except Exception:
        pass
    try:
        rows = db.list_feed_executions(feed_id, limit=1, offset=0)
        if rows:
            return rows[0]
    except Exception:
        pass
    return None
