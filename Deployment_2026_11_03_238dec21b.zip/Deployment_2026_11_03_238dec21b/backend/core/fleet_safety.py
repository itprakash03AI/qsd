"""Fleet safety — is this build actually safe to run on more than one pod?

WHY THIS MODULE EXISTS
======================
QueryStudio has repeatedly grown state that is correct *by accident*: it
lives in a module-level dict, and it is correct only because there has
only ever been ONE pod holding it.  Three such defects were found in a
single 2026-08-02 audit, and all three were SILENT — they produce wrong
state, not crashes:

  * a revoked session stayed valid on every pod that had cached it;
  * a cancel routed to the wrong pod marked the query "cancelled" while
    it kept running on another;
  * every pod BOOT marked every in-flight query in the fleet "failed".

None of these were live, because the deployment runs one replica.  But
``k8s/querystudioapi-helm/api/values.yaml`` declares ``replicas: 3`` and
``hpa.enabled: true`` — so a single ``helm upgrade`` with chart defaults
would have armed all three at once, silently.

The lesson is NOT "fix those three".  It is that a product intended to
scale must be able to STATE whether it is safe to scale, and must refuse
to pretend.  That is what this module is: one place that knows the
fleet-safety preconditions, checks the ones that are machine-checkable,
and makes the answer visible at startup instead of at 3am.

DESIGN RULES
============
* **Advisory by default, never a new outage.**  This module reports and
  warns.  It does not kill the process: a false positive that refuses to
  boot would be worse than the risk it guards.  Operators opt into
  strictness with ``fleet.enforce_preconditions``.
* **Preconditions are DATA, not prose.**  Adding per-pod state means
  adding an entry here, which makes the cost visible in review.
* **Never claim safety you cannot verify.**  Unknown => not satisfied.
"""
from __future__ import annotations

import logging
import os
import socket
from dataclasses import dataclass, field
from typing import Callable, List, Optional

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Precondition:
    """One thing that must be true before this build may run >1 replica.

    ``check`` returns True when satisfied, False when not, and None when
    it cannot be determined.  None is treated as NOT satisfied — a
    precondition we cannot verify is not a precondition we can rely on.
    """
    key: str
    summary: str
    why: str                       # what breaks, concretely, if ignored
    check: Optional[Callable[[], Optional[bool]]] = field(
        default=None, repr=False)
    # "code"   -> engineering work is still required;
    # "deploy" -> the code has landed; an operator must apply config
    #             (helm upgrade / flag flip) for it to take effect.
    # The distinction matters: "unmet" otherwise reads as "unbuilt" and
    # hides the fact that the remaining action is a five-second flag.
    gate: str = "code"

    def satisfied(self) -> Optional[bool]:
        if self.check is None:
            return None
        try:
            return self.check()
        except Exception as exc:
            logger.debug("fleet precondition %r check raised: %s",
                         self.key, exc)
            return None


# ── machine-checkable probes ────────────────────────────────────────────
#
# Each probe answers "has the fix landed?" by inspecting the code, not by
# trusting a flag.  A probe that cannot tell returns None (= unsafe).


def _code_only(src: str) -> str:
    """Source with comments AND string literals removed.

    The first version of these probes matched raw text and reported two
    preconditions SATISFIED because the fix names appeared in a COMMENT
    ("# External executor: set cancel_requested flag...") and in a module
    DOCSTRING ("Idle eviction via _prune_locked()").  A safety check that
    reads prose and calls it a guarantee is worse than no check at all —
    so match executable code only.
    """
    import ast
    import textwrap
    try:
        tree = ast.parse(textwrap.dedent(src))
    except Exception:
        # Unparseable — do NOT fall back to raw text, or we reintroduce
        # the prose-matching bug.  "" means "cannot determine" => unsafe.
        return ""
    # Drop docstrings only.  Stripping EVERY string literal (the first
    # attempt) was too aggressive in the other direction: it also removed
    # ``_upd_kwargs["cancel_requested"] = True``, where the string is a
    # dict key and therefore real behaviour, so a landed fix still read as
    # "unknown".  Comments vanish for free — ast never retains them.
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                             ast.AsyncFunctionDef)):
            body = getattr(node, "body", None)
            if (body and isinstance(body[0], ast.Expr)
                    and isinstance(body[0].value, ast.Constant)
                    and isinstance(body[0].value.value, str)):
                body.pop(0)
    try:
        return ast.unparse(tree)
    except Exception:
        return ""

def _checkpoint_recovery_is_scoped() -> Optional[bool]:
    """`recover_incomplete()` must only reap ITS OWN pod's checkpoints.

    Unscoped, a booting pod fails every in-flight execution in the fleet
    — and under HPA that happens at peak load, so users retry, load
    doubles, another pod boots, and it happens again.
    """
    try:
        import inspect
        from core import checkpoint as _cp
        src = _code_only(inspect.getsource(_cp.recover_incomplete))
    except Exception:
        return None
    if not src:
        return None
    # Unscoped implementations reap everything the store returns.
    if "get_all_checkpoints" in src and not any(
            tok in src for tok in ("owner", "executor_host", "pod_id",
                                   "boot_id", "hostname")):
        return False
    return True


def _cancel_is_not_unconditional() -> Optional[bool]:
    """Cancel must not write status='cancelled' it did not effect.

    Routed to the wrong pod, an unconditional write tells the user the
    query stopped while it keeps consuming an engine elsewhere — then the
    real completion races over the cancelled status.
    """
    try:
        import inspect
        from api import queries_api as _q
        src = _code_only(inspect.getsource(_q))
    except Exception:
        return None
    if not src:
        return None
    if "cancel_requested" in src or "owner_pod" in src:
        return True
    return None


def _session_revocation_converges() -> Optional[bool]:
    """A revoked session must not survive in another pod's L1 cache.

    The sliding-TTL extend refreshed L1 without re-checking the DB row,
    and the flush silently no-opped when the row was gone — so a
    logged-out or role-downgraded user kept working, indefinitely, on any
    pod that had them cached.
    """
    try:
        import inspect
        from core import sessions as _s
        src = _code_only(inspect.getsource(_s))
    except Exception:
        return None
    if not src:
        return None
    # Safe if the extend path can evict on a missing row, or L1 lifetime
    # is bounded short enough for revocation to converge.
    if any(t in src for t in ("_L1_REVALIDATE_SECS", "_L1_MAX_AGE",
                              "_evict_revoked", "revalidate")):
        return True
    return None


def _caches_are_coherent() -> Optional[bool]:
    """Correctness-bearing caches must converge across pods.

    The Iceberg snapshot POINTER was a per-process dict with a ~3h TTL, so
    two pods could answer the SAME query from different snapshots —
    nondeterministic row counts that read as data loss.  Connection-config
    edits had the same shape: invalidated only on the pod that received
    the edit.
    """
    try:
        import inspect
        from core import cache_coherence as _cc
        src = _code_only(inspect.getsource(_cc))
    except Exception:
        return None
    if not src:
        return None
    return "CoherenceBus" in src and "get_bus" in src


def _spill_is_pod_local() -> Optional[bool]:
    """Spill must not be on shared RWX storage.

    Every pod computes its spill quota from the SAME free-space reading,
    so on a shared PVC they all admit simultaneously and collectively hit
    ENOSPC — precisely when memory pressure (hence spilling) peaks.
    """
    d = (os.environ.get("DUCKDB_TEMP_DIR") or "").replace("\\", "/").lower()
    if not d:
        return None
    # Heuristic: the deployment's shared RWX mount is under /nfs.
    if "/nfs/" in d or d.endswith("/nfs"):
        return False
    return True


def _ws_progress_is_fleet_routed() -> Optional[bool]:
    """Progress/completion/cancel WS events must reach the user's pod.

    The WS registry is per-process; with TLS passthrough (no cookie
    affinity) a user's socket lands on a random pod while their query runs
    on another.  The fix is a relay chokepoint in WebSocketManager: every
    non-local broadcast also goes to peer pods through the event bus's
    NOTIFY-only half, and each pod's LISTEN consumer delivers to its own
    clients.  This probe verifies all three halves exist in EXECUTABLE
    code: the manager relay, the bus's notify-only publisher, and the
    LISTEN/deliver receive path.
    """
    try:
        import inspect
        from core import websocket_manager as _wsm
        from core import event_bus as _eb
        from core import checkpoint as _cp
        from api import execute_api as _xa
        ws_src = _code_only(inspect.getsource(_wsm))
        eb_src = _code_only(inspect.getsource(_eb))
        cp_src = _code_only(inspect.getsource(_cp))
        st_src = _code_only(inspect.getsource(_xa.get_execution_status))
    except Exception:
        return None
    if not ws_src or not eb_src or not cp_src or not st_src:
        return None
    # Send half: the manager relays through the bus, and has the
    # local_only receive-path guard that prevents relay ping-pong.
    if not ("publish_notify_only" in ws_src and "local_only" in ws_src):
        return False
    # Bus halves: NOTIFY-only publisher + LISTEN consumer + remote fan-out.
    if not ("def publish_notify_only" in eb_src
            and "def start_listener" in eb_src
            and "deliver_remote_event" in eb_src):
        return False
    # 2026-10-31 (query pods phase 2, design §5.4): the STAGE/PROGRESS a
    # polling page reads (/api/executions/{id}/status) came from a
    # process-local registry, so a run on a query pod -- or one whose API pod
    # restarted -- showed no stage anywhere.  The run's process now writes
    # stage + progress on the checkpoint row with its heartbeat
    # (progress_snapshot -> touch_checkpoints) and the status route falls
    # back to it (stage_from_checkpoint).  Both halves must exist in CODE.
    if not ("def progress_snapshot" in cp_src and "def stage_from_checkpoint" in cp_src
            and "touch_checkpoints" in cp_src):
        return False
    if "stage_from_checkpoint" not in st_src:
        return False
    return True


def _per_user_limits_are_fleet_wide() -> Optional[bool]:
    """`max_concurrent_per_user` is per-pod in-memory state.

    With N pods it silently becomes N x the configured limit, so the
    per-user fairness guarantee quietly stops being one.
    """
    try:
        from core.industrialization.flags import is_enabled
        return bool(is_enabled("fleet_admission"))
    except Exception:
        return None


PRECONDITIONS: List[Precondition] = [
    Precondition(
        "checkpoint_recovery_scoped",
        "Startup recovery only reaps this pod's own checkpoints",
        "A booting pod fails EVERY in-flight query in the fleet; under "
        "HPA this fires at peak load and causes a retry storm.",
        _checkpoint_recovery_is_scoped,
    ),
    Precondition(
        "cancel_routed_to_owner",
        "Cancel reaches the pod actually running the query",
        "Cancel lands on the wrong pod, reports success, and the query "
        "keeps consuming an engine; completion then races over the "
        "cancelled status.",
        _cancel_is_not_unconditional,
    ),
    Precondition(
        "session_revocation_converges",
        "Revoking a session takes effect on every pod",
        "SECURITY: a logged-out or role-downgraded user keeps working on "
        "any pod holding them in its L1 cache.",
        _session_revocation_converges,
    ),
    Precondition(
        "spill_is_pod_local",
        "DuckDB spill is on pod-local disk, not a shared RWX volume",
        "Pods size their spill quota from the same shared free-space "
        "reading and collectively exhaust it (ENOSPC mid-query).",
        _spill_is_pod_local,
        gate="deploy",
    ),
    Precondition(
        "fleet_admission_enabled",
        "Per-user / global concurrency limits are enforced fleet-wide",
        "Per-pod counters silently become N x the configured limit.",
        _per_user_limits_are_fleet_wide,
        gate="deploy",
    ),
    Precondition(
        "websocket_and_progress_fleet_routed",
        "Progress/WebSocket delivery reaches the user's connected pod, and "
        "a run's stage/progress can be read from any pod",
        "The WS registry is per-process, so a user connected to pod A "
        "sees no progress for a query running on pod B; the stage registry "
        "the status route polls is per-process too, so a run on a query pod "
        "(or after an API restart) shows no stage anywhere.",
        _ws_progress_is_fleet_routed,
        gate="code",
    ),
    Precondition(
        "caches_are_coherent_or_harmless",
        "Cross-pod caches are coherent (esp. the Iceberg snapshot pointer)",
        "The snapshot POINTER is per-process, so two pods can answer the "
        "same query from different snapshots — nondeterministic row "
        "counts that look like data loss.",
        _caches_are_coherent,
    ),
    Precondition(
        "loadtest_run_against_staging",
        "The 100-user runbook has been run on real infrastructure",
        "Every capacity number is extrapolated from unit measurement "
        "until this runs; the first real breaker (shared-executor "
        "starvation) was invisible to static analysis.",
        None,
        gate="deploy",
    ),
]


def unmet_preconditions() -> List[Precondition]:
    """Preconditions not provably satisfied.  Unknown counts as unmet."""
    return [p for p in PRECONDITIONS if p.satisfied() is not True]


def is_fleet_safe() -> bool:
    """True only when EVERY precondition is provably satisfied."""
    return not unmet_preconditions()


def detect_peer_pods() -> Optional[int]:
    """Best-effort count of API pods currently resolvable, or None.

    Uses the same headless-Service DNS the multi-pod dispatcher already
    relies on, so it needs no new configuration.  None = unknown; callers
    must not treat unknown as "single pod".
    """
    svc = ""
    try:
        from core.config import get_section
        svc = str((get_section("multi_pod") or {}).get("k8s_service") or "")
    except Exception:
        svc = ""
    svc = svc or os.environ.get("QS_API_SERVICE", "")
    if not svc:
        return None
    try:
        infos = socket.getaddrinfo(svc, None, proto=socket.IPPROTO_TCP)
        return len({i[4][0] for i in infos}) or None
    except Exception as exc:
        logger.debug("fleet peer discovery failed for %r: %s", svc, exc)
        return None


def check_at_startup() -> bool:
    """Log a fleet-safety verdict at boot.  Returns True when safe.

    Deliberately ADVISORY: it never kills the process, because a false
    positive refusing to boot would be a worse outage than the risk it
    guards.  Operators who want hard enforcement set
    ``fleet.enforce_preconditions`` and get a raised RuntimeError instead.
    """
    unmet = unmet_preconditions()
    peers = detect_peer_pods()
    multi = bool(peers and peers > 1)

    if not unmet:
        logger.info("[fleet-safety] all %d preconditions satisfied — safe "
                    "to scale beyond one replica.", len(PRECONDITIONS))
        return True

    lines = "; ".join(f"{p.key}: {p.summary}" for p in unmet)
    if multi:
        logger.error(
            "[fleet-safety] RUNNING %d PODS with %d UNMET precondition(s). "
            "These defects are SILENT (wrong state, not crashes): %s",
            peers, len(unmet), lines,
        )
        try:
            from core.config import get_section
            if bool((get_section("fleet") or {}).get(
                    "enforce_preconditions", False)):
                raise RuntimeError(
                    f"fleet.enforce_preconditions is on and {len(unmet)} "
                    f"fleet-safety precondition(s) are unmet: {lines}")
        except RuntimeError:
            raise
        except Exception as exc:
            logger.debug("[fleet-safety] enforcement config read failed: %s",
                         exc)
    else:
        logger.warning(
            "[fleet-safety] single replica (peers=%s) — OK today, but %d "
            "precondition(s) must be met BEFORE scaling out: %s",
            peers if peers is not None else "unknown", len(unmet), lines,
        )
    return False
