"""``SqlQueryStage`` — execute a SQL statement and emit row-count + sample rows.

Defers to ``core.duckdb_factory`` so we honour the same connection
factory the rest of the codebase uses (extension dir, S3 secrets, NFS
guards, etc.).  This is the first "real work" stage and serves as a
template for ``ConvertFormat``, ``RowCountCheck``, ``DeliverS3`` etc.
that follow in later phases.

NOT used by existing feed_gen / BQB / CQB / Reports code paths — those
keep their own engines.  This stage exists for *new* dataflow-engine
runs that want a simple "run a query and read its row count" step.
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_SOURCE, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class SqlQueryStage(BaseStage):
    """Run a SQL statement using DuckDB.

    Config:
        ``sql``           : str (required) — supports ``{key}`` interpolation
                              against run_context.
        ``return_rows``   : int (default 10) — number of result rows to capture
                              into outputs.sample.  Set 0 to skip sampling.
        ``return_columns`` : bool (default true) — include column names.
    """

    NAME = "sql_query"
    DISPLAY_NAME = "Run SQL Query (DuckDB)"
    CATEGORY = CATEGORY_SOURCE
    DESCRIPTION = ("Execute a SQL statement via DuckDB.  Supply raw SQL "
                     "directly OR reference a saved_query_id from "
                     "QueryStudio's saved-queries catalogue.  Optionally "
                     "writes the FULL result set to a file (CSV / Parquet / "
                     "JSON) so downstream sink stages can upload it.")
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "sql_file_id":     {"type": "integer", "lookup": "sql_files",
                              "description": "QueryStudio .sql file (created via BQB / CQB "
                                              "or hand-saved).  Loaded fresh at run time so "
                                              "edits flow through automatically."},
        "saved_query_id":  {"type": "integer", "lookup": "saved_queries",
                              "description": "QueryStudio saved query (alternative to sql_file_id)."},
        "sql":             {"type": "string",
                              "description": "Raw inline SQL (fallback when no sql_file_id / "
                                              "saved_query_id).  Supports {key} interpolation."},
        # BF-506 (2026-05-28) — when set, the stage registers any
        # iceberg / parquet S3 tables on this connection BEFORE
        # executing the SQL.  Without this, raw DuckDB has no view
        # for the user's table reference and fails with
        # ``CatalogException: Table does not exist``.  Iceberg tables
        # also get manifest-driven pruning (BF-498..505) instead of
        # brute-force glob reads.  Leave 0/empty for inline SQL that
        # doesn't reference QueryStudio-managed S3 tables.
        "connection_id":   {"type": "integer", "lookup": "connections",
                              "description": "QueryStudio connection id.  When set, the stage "
                                              "auto-registers S3 / iceberg views from that "
                                              "connection so the user's SQL can reference table "
                                              "names directly.  Iceberg tables get manifest-driven "
                                              "pruning via the same path BQB / CQB / Feed Gen use "
                                              "(BF-498..505 hardening)."},
        "return_rows":     {"type": "integer", "minimum": 0,
                              "description": "Sample rows to capture into outputs.sample (default 10)."},
        "return_columns":  {"type": "boolean"},
        "output_file_path": {"type": "string",
                               "description": "Write the FULL result set to this file path."},
        "output_format":   {"type": "string", "enum": ["csv", "parquet", "json"]},
        # Phase 132.38 — per-stage Static / Dynamic WHERE-clause mapping
        # (same primitive Published Views + Feed Gen use).  Static rows
        # are locked at config time; Dynamic rows let the run starter
        # supply values via ``run_context._consumer_overrides``.  When
        # set, the wrap is applied AFTER ``{key}`` templating but BEFORE
        # execution.
        "where_clauses":   {"type": "where_clauses",
                              "description": "Per-stage Static / Dynamic WHERE-clause mapping.  "
                                              "Static rows lock at config time; Dynamic rows let "
                                              "the run starter override at trigger time."},
        # Phase 154 (2026-06-25) -- explicit cross-source config.
        # Inherits silently from sql_file_id / saved_query_id when
        # those references carry cross-conn fields (no explicit config
        # needed in the common case).  Explicit config wins when both
        # the reference AND the stage-level fields are set.
        "secondary_connection_id": {"type": "integer", "lookup": "connections",
                                       "description": "Cross-source secondary connection.  When "
                                                       "set, the stage pulls primary + secondary "
                                                       "into temp parquets and combines via "
                                                       "DuckDB union/join."},
        "secondary_sql":   {"type": "string",
                              "description": "Cross-source secondary SQL.  Required when "
                                              "secondary_connection_id is set but no "
                                              "secondary_sql_file_id is provided."},
        "secondary_sql_file_id": {"type": "integer", "lookup": "sql_files",
                                     "description": "Load secondary SQL from a .sql file (parity "
                                                     "with sql_file_id on the primary side)."},
        "combine_mode":    {"type": "string", "enum": ["union", "join"],
                               "description": "Cross-source combine mode (default 'union')."},
        "join_config":     {"type": "object",
                               "description": "JOIN config when combine_mode='join'.  Shape: "
                                               "{ how, left_on, right_on, suffixes }."},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        sql = (config.get("sql") or "").strip()
        sqid = config.get("saved_query_id")
        if not sql and not sqid:
            errs.append("either sql or saved_query_id is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        # SQL source priority:
        #   1. sql_file_id   (QueryStudio .sql files — BQB / CQB)
        #   2. saved_query_id (legacy saved-queries catalogue)
        #   3. raw `sql` config (inline)
        # Each source loads fresh on every run so edits to the source
        # flow through automatically.
        sql_template = ""
        sql_file_id = ctx.get_config("sql_file_id")
        saved_query_id = ctx.get_config("saved_query_id")

        # Phase 154 cross-source state -- collected during reference
        # resolution below, consumed at execution dispatch time.
        cross_secondary_sql: str = ""
        cross_secondary_conn_id: Any = None
        cross_combine_mode: str = (ctx.get_config("combine_mode") or "union").lower().strip()
        cross_join_config: Any = ctx.get_config("join_config")

        if sql_file_id and ctx.db_manager is not None:
            sql_template = self._load_sql_file(ctx.db_manager, int(sql_file_id))
            if sql_template:
                ctx.log(f"sql loaded from sql_file_id={sql_file_id} "
                        f"({len(sql_template)} chars)")
            # Phase 154 cross-source: .sql files store primary +
            # _CROSS_SEPARATOR + secondary.  Split + inherit metadata
            # from the SqlFile row.  The fail-loud guard (commit
            # 3d99c02) is replaced here by actual execution support.
            if sql_template:
                from api.sql_files_api import _split_cross_sql
                _pri, _sec = _split_cross_sql(sql_template)
                if _sec:
                    sql_template = _pri  # primary half only
                    cross_secondary_sql = _sec
                    # Inherit secondary connection + combine semantics
                    # from the SqlFile row (operator already set them
                    # when saving the .sql file).
                    try:
                        sf_row = ctx.db_manager.get_sql_file(int(sql_file_id))
                        if sf_row and sf_row.get("secondary_connection_id"):
                            cross_secondary_conn_id = sf_row["secondary_connection_id"]
                            if sf_row.get("combine_mode"):
                                cross_combine_mode = sf_row["combine_mode"]
                            if sf_row.get("join_config"):
                                cross_join_config = sf_row["join_config"]
                    except Exception as _sf_exc:
                        ctx.log(f"sql_file row lookup failed for "
                                f"cross-source inheritance: {_sf_exc}")
        if not sql_template and saved_query_id and ctx.db_manager is not None:
            # Phase 154 -- BQB cross-conn saved queries carry
            # secondary_connection_id inside query_config (post 163ccd2).
            sq = ctx.db_manager.get_query(int(saved_query_id))
            if sq and isinstance(sq.get("query_config"), dict):
                qcfg = sq["query_config"]
                if qcfg.get("secondary_connection_id"):
                    cross_secondary_conn_id = qcfg["secondary_connection_id"]
                    cross_secondary_sql = (qcfg.get("secondary_raw_sql")
                                           or qcfg.get("secondary_sql")
                                           or "")
                    if qcfg.get("combine_mode"):
                        cross_combine_mode = qcfg["combine_mode"]
                    if qcfg.get("join_config"):
                        cross_join_config = qcfg["join_config"]
            sql_template = self._load_saved_query_sql(
                ctx.db_manager, int(saved_query_id),
            )
            if sql_template:
                ctx.log(f"sql loaded from saved_query_id={saved_query_id} "
                        f"({len(sql_template)} chars)")

        # Phase 154 -- explicit stage-level cross-source config OVERRIDES
        # inheritance (operator override wins, mirrors Feed Gen rule).
        _explicit_sec_conn = ctx.get_config("secondary_connection_id")
        if _explicit_sec_conn:
            cross_secondary_conn_id = int(_explicit_sec_conn)
        _explicit_sec_sql = (ctx.get_config("secondary_sql") or "").strip()
        if _explicit_sec_sql:
            cross_secondary_sql = _explicit_sec_sql
        _explicit_sec_sql_file_id = ctx.get_config("secondary_sql_file_id")
        if _explicit_sec_sql_file_id and ctx.db_manager is not None and not _explicit_sec_sql:
            cross_secondary_sql = self._load_sql_file(
                ctx.db_manager, int(_explicit_sec_sql_file_id),
            )
        if not sql_template:
            sql_template = ctx.get_config("sql", "")

        return_rows = int(ctx.get_config("return_rows", 10))
        return_columns = bool(ctx.get_config("return_columns", True))
        output_file_path = ctx.get_config("output_file_path")
        output_format = (ctx.get_config("output_format") or "csv").lower().strip()

        try:
            sql = sql_template.format(**ctx.run_context)
        except Exception as exc:
            return StageResult.failed(error=f"SQL templating failed: {exc}")

        # Phase 132.38 — apply the per-stage WHERE-clause mapping after
        # templating but before execution.  Static rows lock at config
        # time; Dynamic rows that have a matching consumer override in
        # run_context._consumer_overrides are appended via REPLACE
        # semantics.  No-op when the stage has no mapping.
        try:
            sql = self.apply_where_mapping_to_sql(sql, ctx) or sql
        except Exception as exc:
            ctx.log(f"WHERE-mapping wrap failed (running unwrapped): {exc}")

        # BF-571/572 audit fix: apply cross-dialect strftime /
        # DATE_FORMAT / format_datetime / to_iso8601 normaliser so
        # pipelines written for Starburst/Trino/MySQL run unchanged
        # on DuckDB.  Without this, Trino-style `%i` minute
        # specifiers crashed at execute.
        try:
            from core.duckdb_format_normaliser import normalise_strftime_formats as _norm
            sql, _ff = _norm(sql)
            if _ff:
                ctx.log(
                    f"BF-571/572 auto-fixed {len(_ff)} format "
                    f"specifier(s) in stage SQL"
                )
        except Exception:
            pass  # fail-open

        # Phase 154 cross-source dispatch.  When both halves resolved
        # to non-empty SQL + a secondary connection is known, the
        # stage runs PRIMARY on its connection -> temp parquet,
        # SECONDARY on its connection -> temp parquet, then UNION /
        # JOIN-combines via DuckDB.  Reuses the connector_to_parquet
        # chokepoint (Phase 154 bounded-memory primitive) for the SQL
        # connector sides; DuckDB COPY (sql) TO for file-based sides.
        if cross_secondary_sql and cross_secondary_conn_id:
            try:
                sec_sql = cross_secondary_sql.format(**ctx.run_context)
            except Exception as exc:
                return StageResult.failed(
                    error=f"secondary SQL templating failed: {exc}",
                )
            return self._execute_cross_source(
                ctx=ctx,
                primary_sql=sql,
                primary_conn_id=ctx.get_config("connection_id"),
                secondary_sql=sec_sql,
                secondary_conn_id=int(cross_secondary_conn_id),
                combine_mode=cross_combine_mode,
                join_config=cross_join_config,
                output_file_path=output_file_path,
                output_format=output_format,
                return_rows=return_rows,
                return_columns=return_columns,
            )

        # Interpolate output_file_path with run_context too
        resolved_out_path = None
        if output_file_path:
            try:
                resolved_out_path = output_file_path.format(**ctx.run_context)
            except Exception:
                resolved_out_path = output_file_path

        try:
            con = self._open_connection(ctx, sql=sql)
        except Exception as exc:
            return StageResult.failed(error=f"open DuckDB connection failed: {exc}")

        try:
            outputs: Dict[str, Any] = {}
            full_row_count: int | None = None

            # ── Optional: write FULL result to a file via DuckDB COPY TO ──
            #
            # DuckDB's COPY (sql) TO 'path' (FORMAT ...) streams the whole
            # result set straight to disk without buffering all rows in
            # Python memory.  Much faster than fetchall() for big results.
            if resolved_out_path:
                import os
                parent = os.path.dirname(resolved_out_path)
                if parent:
                    os.makedirs(parent, exist_ok=True)
                fmt_clause = {"csv": "(FORMAT 'csv', HEADER)",
                              "parquet": "(FORMAT 'parquet')",
                              "json": "(FORMAT 'json')"}.get(output_format, "(FORMAT 'csv', HEADER)")
                escaped_path = resolved_out_path.replace("'", "''")
                copy_sql = f"COPY ({sql}) TO '{escaped_path}' {fmt_clause}"
                con.execute(copy_sql)
                full_row_count = self._count_rows_in_file(
                    resolved_out_path, output_format)
                outputs["output_file_path"] = resolved_out_path
                outputs["output_format"]   = output_format
                outputs["row_count"]       = full_row_count
                ctx.log(f"wrote full result set to {resolved_out_path} "
                        f"(format={output_format}, rows={full_row_count})")

            # ── Always: capture a small sample + columns for the dashboard ──
            cur = con.execute(sql)
            columns: List[str] = [d[0] for d in (cur.description or [])]
            if return_rows > 0:
                rows = cur.fetchmany(return_rows)
                sample = [list(r) for r in rows]
            else:
                sample = []
            outputs["sample_rows"]  = sample
            outputs["sample_count"] = len(sample)
            if return_columns:
                outputs["columns"] = columns
            if full_row_count is None:
                ctx.log(f"executed SQL — captured {len(sample)} sample rows, "
                        f"{len(columns)} columns")
            return StageResult.succeeded(outputs=outputs)
        except Exception as exc:
            return StageResult.failed(error=f"SQL execution failed: {exc}")
        finally:
            try:
                con.close()
            except Exception as _close_exc:
                # Connection close failure is non-fatal — the query has
                # already returned its result or its error.
                ctx.log(f"duckdb close error: {_close_exc}")

    # ── helpers ─────────────────────────────────────────────────────────

    def _execute_cross_source(
        self,
        *,
        ctx: StageContext,
        primary_sql: str,
        primary_conn_id: Any,
        secondary_sql: str,
        secondary_conn_id: int,
        combine_mode: str,
        join_config: Any,
        output_file_path: Any,
        output_format: str,
        return_rows: int,
        return_columns: bool,
    ) -> StageResult:
        """Phase 154 cross-source executor.

        Pulls primary + secondary into temp parquets via the right
        executor per connection type, then UNION/JOIN-combines via
        DuckDB.  Reuses ``connector_to_parquet.execute_sql_to_parquet``
        (bounded memory) for SQL connector sides and DuckDB COPY for
        file-based sides.  Single output file path returned to the
        caller -- the cross-source path is opaque to downstream stages.
        """
        import os
        import uuid
        import tempfile
        from core.executors.cross_source_combine import (
            combine_sides, combine_spec,
        )

        ctx.log(f"cross-source dispatch: primary_conn={primary_conn_id} "
                f"secondary_conn={secondary_conn_id} combine={combine_mode}")

        # Resolve connection records.  Both must exist.
        try:
            pri_conn = ctx.db_manager.get_connection_raw(int(primary_conn_id)) \
                if primary_conn_id else None
            sec_conn = ctx.db_manager.get_connection_raw(int(secondary_conn_id))
        except Exception as exc:
            return StageResult.failed(
                error=f"cross-source connection lookup failed: {exc}",
            )
        if not pri_conn:
            return StageResult.failed(
                error=f"primary connection_id={primary_conn_id} not found",
            )
        if not sec_conn:
            return StageResult.failed(
                error=f"secondary connection_id={secondary_conn_id} not found",
            )

        tmp_dir = tempfile.mkdtemp(prefix="qs_cross_")
        primary_path = os.path.join(tmp_dir, f"primary_{uuid.uuid4().hex[:8]}.parquet")
        secondary_path = os.path.join(tmp_dir, f"secondary_{uuid.uuid4().hex[:8]}.parquet")
        cleanup_paths = [primary_path, secondary_path]

        try:
            self._execute_one_side(
                ctx=ctx, sql=primary_sql, conn_record=pri_conn,
                output_parquet=primary_path, side="primary",
            )
            self._execute_one_side(
                ctx=ctx, sql=secondary_sql, conn_record=sec_conn,
                output_parquet=secondary_path, side="secondary",
            )

            # Combine via DuckDB.  Output to user-specified path when
            # set, else to a temp parquet that we read for the sample.
            #
            # BUG-I fix (2026-06-25 deep dive): when output_file_path
            # was None, combined_path landed INSIDE tmp_dir but was
            # NOT added to cleanup_paths.  The finally block's
            # ``os.rmdir(tmp_dir)`` then failed silently (dir not
            # empty) and the combined parquet leaked on disk -- once
            # per cross-source DataFlow run.  Track the in-tmp combined
            # file explicitly so cleanup drops it.
            _combined_in_tmp = not output_file_path
            combined_path = output_file_path or os.path.join(
                tmp_dir, f"combined_{uuid.uuid4().hex[:8]}.parquet",
            )
            try:
                resolved_combined = combined_path.format(**ctx.run_context) \
                    if isinstance(combined_path, str) else combined_path
            except Exception:
                resolved_combined = combined_path
            if _combined_in_tmp:
                cleanup_paths.append(resolved_combined)

            # THE cross-source combine (2026-10-04): the one every surface
            # uses -- one join vocabulary ("outer" == "full"), key types
            # harmonised and disclosed, never a one-sided result.
            from core.duckdb_factory import duckdb_connection
            _df_outcome = combine_sides(
                primary_path, secondary_path, resolved_combined,
                combine_spec(combine_mode, join_config or {},
                             default_mode="union"))

            # If the user asked for a non-parquet output_format, convert
            # the combined parquet via DuckDB COPY.  Otherwise the
            # combine output IS the deliverable.
            outputs: Dict[str, Any] = {}
            final_out_path = resolved_combined
            if output_file_path and output_format != "parquet":
                with duckdb_connection() as con2:
                    fmt_clause = {
                        "csv":  "(FORMAT 'csv', HEADER)",
                        "json": "(FORMAT 'json')",
                    }.get(output_format, "(FORMAT 'csv', HEADER)")
                    final_out_path = resolved_combined.rsplit(".", 1)[0] + f".{output_format}"
                    esc = final_out_path.replace("'", "''")
                    con2.execute(
                        f"COPY (SELECT * FROM read_parquet('{resolved_combined}')) "
                        f"TO '{esc}' {fmt_clause}"
                    )
                cleanup_paths.append(resolved_combined)

            # Sample + columns capture from the combined parquet.
            from core.duckdb_factory import duckdb_connection as _df_conn
            with _df_conn() as con3:
                cur = con3.execute(
                    f"SELECT * FROM read_parquet('{resolved_combined}') "
                    f"LIMIT {max(return_rows, 0)}"
                )
                columns: List[str] = [d[0] for d in (cur.description or [])]
                if return_rows > 0:
                    sample = [list(r) for r in cur.fetchall()]
                else:
                    sample = []
                # Total combined row count via metadata read (no full load).
                row_count = self._count_rows_in_file(
                    resolved_combined, "parquet")

            if output_file_path:
                outputs["output_file_path"] = final_out_path
                outputs["output_format"]   = output_format
                outputs["row_count"]       = row_count
            outputs["sample_rows"]  = sample
            outputs["sample_count"] = len(sample)
            if return_columns:
                outputs["columns"] = columns
            # Cross-source telemetry.
            outputs["cross_source"] = True
            outputs["primary_connection_id"]   = int(primary_conn_id) if primary_conn_id else None
            outputs["secondary_connection_id"] = int(secondary_conn_id)
            outputs["combine_mode"]            = combine_mode
            outputs["cross_source_disclosure"] = _df_outcome.disclosure()
            ctx.log(f"cross-source executed: combine={combine_mode}, "
                    f"row_count={row_count}, columns={len(columns)}")
            return StageResult.succeeded(outputs=outputs)
        except Exception as exc:
            return StageResult.failed(
                error=f"cross-source execution failed: {exc}",
            )
        finally:
            # Best-effort cleanup of temp side-files.  We keep the
            # combined file when it lives at the user-specified
            # output_file_path; the temp ones get dropped.
            for p in cleanup_paths:
                try:
                    if os.path.isfile(p):
                        os.unlink(p)
                except Exception:
                    pass
            try:
                if os.path.isdir(tmp_dir):
                    os.rmdir(tmp_dir)
            except Exception:
                pass

    def _execute_one_side(
        self, *, ctx: StageContext, sql: str, conn_record: Dict[str, Any],
        output_parquet: str, side: str,
    ) -> None:
        """Execute one side of a cross-source query and write the
        result to ``output_parquet``.  Routes SQL connectors through
        the bounded-memory chokepoint (Phase 154's
        ``connector_to_parquet.execute_sql_to_parquet``); routes
        S3 / local file connections through DuckDB COPY (sql) TO
        with the appropriate views registered first.

        Raises on failure -- caller wraps with friendlier error.
        """
        conn_type = (conn_record.get("connection_type") or "").lower()
        # 2026-06-25 zero-risk audit: align with the actual registry in
        # core.connectors._REGISTRY -- postgresql + mysql were listed
        # aspirationally in federation_engine.SQL_CONNECTION_TYPES but
        # aren't registered as connectors yet.  Hitting get_connector
        # with those raises "Unsupported connection type".  Source the
        # canonical list from the registry so this set can't drift.
        from core.connectors import SQL_CONNECTOR_TYPES as _REG_SQL_TYPES
        SQL_CONN_TYPES = set(_REG_SQL_TYPES) - {"rest_api"}

        if conn_type in SQL_CONN_TYPES:
            # SQL connector side -- THE cross-source side runner (2026-10-04):
            # pooled connector -> connector_to_parquet, bounded memory.
            from core.executors.cross_source_combine import (
                SideSpec, run_side_to_parquet)
            run_side_to_parquet(
                SideSpec(side, connection=conn_record, sql=sql),
                output_parquet, db_manager=ctx.db_manager)
            ctx.log(f"{side} side ({conn_type}) -> {output_parquet} via chokepoint")
        else:
            # File-based (s3 / local) -- DuckDB COPY direct to parquet.
            from core.duckdb_factory import duckdb_connection
            with duckdb_connection() as con:
                # Best-effort register the connection's S3 / iceberg
                # views so the SQL can reference QueryStudio-managed
                # table names (mirrors single-side _open_connection
                # behaviour).
                #
                # 2026-09-01 — this call was WRONG and had never run.  It
                # passed ``con`` and the connection id positionally into
                # ``(engine, query_config, ...)`` and then two keywords that
                # do not exist on ``setup_registered_views`` --
                # ``sql=`` and ``registered_tables_override=``.  Every call
                # raised TypeError, and the fail-open handler below reported
                # it as "view registration skipped", which reads like a
                # deliberate no-op rather than a broken call.
                #
                # So on the cross-source path the S3 side never had its
                # views registered: the user's SQL could not reference any
                # QueryStudio-managed table name, and iceberg tables got no
                # manifest-driven pruning.  Its twin ``_open_connection``
                # (the single-source path) has always called this correctly
                # -- the same sibling divergence this codebase keeps
                # producing, and the BF-506 tests only ever inspected the
                # twin that worked.
                #
                # Mirrors _open_connection exactly, minus the lookup: the
                # connection record is already in hand here.
                try:
                    _side_cfg = conn_record.get("config") or {}
                    _side_tables = _side_cfg.get("registered_tables") or []
                    _side_bucket = (_side_cfg.get("bucket_name")
                                    or _side_cfg.get("bucket") or "")
                    if (conn_type == "s3" and _side_tables and _side_bucket
                            and conn_record.get("id")):
                        from types import SimpleNamespace
                        from core.duckdb_views import setup_registered_views
                        from core.query_hints import extract_referenced_tables

                        class _SideEngine:
                            pass

                        _side_eng = _SideEngine()
                        _side_eng._s3_conn_config = _side_cfg
                        _side_eng._registered_tables = _side_tables
                        _side_eng._s3_bucket = _side_bucket
                        _side_eng._s3_conn_id = int(conn_record["id"])
                        # raw_sql on the shim so JoinPruner's semi-join
                        # extractor can fire on IN (SELECT ...) here too
                        # (Phase 134-O gave the single-source path this and
                        # the cross-source path never got it).
                        _side_qc = SimpleNamespace(
                            raw_sql=sql or "", files=[], joins=[], filters=[])
                        setup_registered_views(
                            _side_eng, _side_qc, _side_cfg, _side_tables,
                            _side_bucket, int(conn_record["id"]),
                            referenced_tables=(
                                extract_referenced_tables(_side_tables, sql)
                                if sql else None),
                            db_manager=ctx.db_manager,
                            con=con,
                        )
                except Exception as _reg_exc:
                    # Still fail-open -- the user's SQL may reference S3
                    # paths directly -- but say what actually happened
                    # rather than implying a no-op was intended.
                    ctx.log(f"{side} view registration FAILED, falling back "
                            f"to bare DuckDB (SQL must reference S3 paths "
                            f"directly): {_reg_exc}")
                esc = output_parquet.replace("'", "''")
                con.execute(
                    f"COPY ({sql}) TO '{esc}' (FORMAT 'parquet')"
                )
            ctx.log(f"{side} side ({conn_type}) -> {output_parquet} via DuckDB COPY")

    @staticmethod
    def _load_sql_file(db_manager: Any, sql_file_id: int) -> str:
        """Look up a SqlFile row by id, read its file_path on disk, return
        the SQL contents.  Empty string on lookup / read failure (caller
        falls back to saved_query_id or inline SQL).

        Phase 132.36 hotfix-1: log every failure path at WARNING so
        operators can distinguish missing row / file / read error /
        empty file.  Returning empty-string is preserved for the
        SqlQueryStage caller which falls through to alternative SQL
        sources; ``_load_sql_file_strict`` raises instead, used by
        stages where SQL is required.
        """
        import logging as _logging
        _log = _logging.getLogger("dataflow.sql_file")
        try:
            from core.db.models import SqlFile
            with db_manager.get_session(read_only=True) as session:
                row = session.query(SqlFile).filter(
                    SqlFile.id == sql_file_id,
                    SqlFile.is_active == True,  # noqa: E712
                ).first()
                if row is None:
                    _log.warning("sql_file_id=%s not found (or inactive)",
                                   sql_file_id)
                    return ""
                if not row.file_path:
                    _log.warning("sql_file_id=%s has no file_path", sql_file_id)
                    return ""
                file_path = row.file_path
            # Read OUTSIDE the session so NFS slowness doesn't hold a row lock.
            import os
            if not os.path.exists(file_path):
                _log.warning("sql_file_id=%s file_path %s does not exist on disk",
                               sql_file_id, file_path)
                return ""
            with open(file_path, "r", encoding="utf-8") as fh:
                content = fh.read()
            if not content.strip():
                _log.warning("sql_file_id=%s file %s is empty",
                               sql_file_id, file_path)
            return content
        except Exception as exc:
            _log.warning("sql_file_id=%s read failed: %s",
                          sql_file_id, exc, exc_info=True)
            return ""

    @staticmethod
    def _load_sql_file_strict(db_manager: Any, sql_file_id: int) -> str:
        """Phase 132.36 hotfix-1: strict variant for callers that REQUIRE
        SQL content.  Raises with a precise message naming the exact
        failure mode so admins can act.
        """
        from core.db.models import SqlFile
        with db_manager.get_session(read_only=True) as session:
            row = session.query(SqlFile).filter(
                SqlFile.id == sql_file_id,
            ).first()
            if row is None:
                raise RuntimeError(
                    f"sql_file_id {sql_file_id} not found"
                )
            if not row.is_active:
                raise RuntimeError(
                    f"sql_file_id {sql_file_id} ({row.name!r}) is inactive"
                )
            if not row.file_path:
                raise RuntimeError(
                    f"sql_file_id {sql_file_id} ({row.name!r}) has no file_path"
                )
            file_path = row.file_path
            name_for_msg = row.name
        import os
        if not os.path.exists(file_path):
            raise RuntimeError(
                f"sql_file_id {sql_file_id} ({name_for_msg!r}) file "
                f"{file_path} does not exist on disk"
            )
        with open(file_path, "r", encoding="utf-8") as fh:
            content = fh.read()
        if not content.strip():
            raise RuntimeError(
                f"sql_file_id {sql_file_id} ({name_for_msg!r}) file "
                f"{file_path} is empty"
            )
        return content

    @staticmethod
    def _count_rows_in_file(path: str, fmt: str) -> int | None:
        """Best-effort row count after writing the file.  Used to surface
        row_count in outputs without re-running the full query.  Returns
        None on any failure — non-fatal.
        """
        try:
            import duckdb  # type: ignore
            con = duckdb.connect(database=":memory:")
            try:
                if fmt == "parquet":
                    n = con.execute(
                        f"SELECT COUNT(*) FROM read_parquet('{path}')").fetchone()
                elif fmt == "json":
                    n = con.execute(
                        f"SELECT COUNT(*) FROM read_json_auto('{path}')").fetchone()
                else:
                    n = con.execute(
                        f"SELECT COUNT(*) FROM read_csv_auto('{path}', HEADER=true)").fetchone()
                return int(n[0]) if n else None
            finally:
                con.close()
        except Exception:
            return None

    @staticmethod
    def _load_saved_query_sql(db_manager: Any, saved_query_id: int) -> str:
        """Look up a saved query by id and return its SQL.  Empty string
        on lookup failure (caller falls back to raw 'sql' config).
        """
        try:
            from core.config_active import active_clause
            from core.db.models import SavedQuery
            with db_manager.get_session(read_only=True) as session:
                # a switched-off (deleted) saved query is not run (2026-10-30)
                row = session.query(SavedQuery).filter(
                    SavedQuery.id == saved_query_id,
                    active_clause(SavedQuery),
                ).first()
                if row is None:
                    return ""
                # SavedQuery.query_config is a structured BQB / CQB JSON,
                # not raw SQL.  Two possibilities:
                #   1. Row has a `sql` text column (raw SQL persisted) — preferred
                #   2. We render the QueryConfig to SQL ourselves
                # We only handle (1) here — (2) requires the full engine
                # which is overkill for the DataFlow stage's purpose.
                raw_sql = getattr(row, "sql", None) or ""
                if isinstance(raw_sql, str) and raw_sql.strip():
                    return raw_sql
                # Fallback — JSON stringify so admins can at least debug.
                return ""
        except Exception:
            return ""

    def _open_connection(self, ctx: StageContext, sql: str = "") -> Any:
        """Open a short-lived DuckDB connection.

        Uses ``core.duckdb_factory`` when available (so extensions /
        httpfs config / NFS guards all line up with the rest of the
        codebase).  Falls back to plain duckdb.connect() for unit tests
        running in environments without the factory installed.

        BF-506 — when ``connection_id`` is set in the stage config,
        register the connection's S3 / iceberg views via
        ``setup_registered_views`` so the user's SQL can reference
        QueryStudio-managed table names directly AND iceberg tables
        get manifest-driven pruning (BF-498..505).  Without this
        the stage was a plain DuckDB that crashed on any reference
        to an S3 table name.

        Phase 134-O (2026-06-02) — ``sql`` is now threaded so the
        registration path can (a) restrict ``referenced_tables`` to
        only the tables the SQL actually mentions and (b) expose the
        raw SQL to JoinPruner's semi-join extractor via a minimal
        query_config shim.  Without (b), ETL workloads that wrote
        ``IN (SELECT ...)`` patterns silently full-scanned the outer
        side even though JoinPruner already supports that pattern on
        the BQB / CQB / Published API paths.
        """
        try:
            # 2026-09-01 -- ``open_duckdb_connection`` does not exist; the
            # factory exposes ``get_connection`` (and the ``duckdb_connection``
            # context manager).  So this ALWAYS fell through to the bare
            # in-memory DuckDB below, and the stage ran without any of the
            # factory's configuration -- httpfs/S3 settings, extensions,
            # memory and thread limits.  It worked, quietly, on defaults.
            from core.duckdb_factory import get_connection as _ddb_get  # type: ignore
            con = _ddb_get()
        except Exception:
            import duckdb  # type: ignore
            con = duckdb.connect(database=":memory:")

        # BF-506 — optional view registration when the stage is bound
        # to a QueryStudio connection.  No-op when connection_id is
        # missing / zero / the connection lookup fails (fail-OPEN:
        # better to let the user's SQL run against a bare DuckDB
        # than to block the stage on a config typo).
        try:
            _conn_id = ctx.get_config("connection_id")
            if _conn_id and ctx.db_manager is not None:
                _conn_record = ctx.db_manager.get_connection_raw(int(_conn_id))
                if _conn_record and (_conn_record.get("connection_type") or "").lower() == "s3":
                    _cfg = _conn_record.get("config", {}) or {}
                    _registered_tables = _cfg.get("registered_tables") or []
                    _bucket = _cfg.get("bucket_name") or _cfg.get("bucket") or ""
                    if _registered_tables and _bucket:
                        from core.duckdb_views import setup_registered_views
                        # Provide a minimal ParquetQueryEngine-like
                        # holder so setup_registered_views' attribute
                        # accesses work.  This mirrors what
                        # execute_api.py does at its setup call site.
                        class _MinEngine:
                            pass
                        _eng = _MinEngine()
                        _eng._s3_conn_config = _cfg
                        _eng._registered_tables = _registered_tables
                        _eng._s3_bucket = _bucket
                        _eng._s3_conn_id = int(_conn_id)
                        # setup_registered_views attaches the views to
                        # ``con`` and returns the (possibly-rewritten)
                        # SQL.  We don't need the rewritten SQL here
                        # (we run raw SQL via DuckDB directly), only
                        # the side-effect of CREATE VIEW statements.
                        #
                        # Phase 134-O: build a minimal query_config
                        # shim that exposes ``raw_sql`` so JoinPruner's
                        # semi-join extractor can fire on IN (SELECT)
                        # patterns; also pass ``referenced_tables``
                        # extracted from the SQL so we skip every other
                        # table on the connection.
                        try:
                            from types import SimpleNamespace
                            from core.query_hints import extract_referenced_tables
                            _qc_shim = SimpleNamespace(
                                raw_sql=sql or "",
                                files=[],
                                joins=[],
                                filters=[],
                            )
                            _ref_tables = (
                                extract_referenced_tables(_registered_tables, sql)
                                if sql else None
                            )
                            setup_registered_views(
                                _eng, _qc_shim, _cfg, _registered_tables,
                                _bucket, int(_conn_id),
                                referenced_tables=_ref_tables,
                                db_manager=ctx.db_manager,
                                con=con,
                            )
                        except Exception as _setup_exc:
                            ctx.log(
                                f"BF-506: view registration failed for "
                                f"connection {_conn_id} — falling back to bare "
                                f"DuckDB (user SQL must reference S3 paths "
                                f"directly): {_setup_exc}"
                            )
        except Exception as _bf506_exc:
            # Fail-open — any error in the registration path falls back
            # to bare DuckDB.  The user's SQL might still work if it
            # uses inline ``read_parquet('s3://...')`` references.
            ctx.log(f"BF-506: connection_id resolution failed (non-fatal): {_bf506_exc}")

        return con
