"""The report/dataset path's result-cache gate.

2026-09-07.  WHY THE REPORT PATH WAS NEVER CACHED
-------------------------------------------------
It was not a decision and it was not a missing config knob.  ``core.
result_cache`` has exactly one consult in the product -- ``core.
query_cache_integration.maybe_serve_from_cache``, called from ``api.
execute_api.execute_query_background`` -- and that call site is guarded:

    if raw_sql and _rc_files and cache_strategy != "bypass":

``_rc_files`` is ``query_config.files``.  A business report does not go
through ``execute_query_background`` at ALL: it goes
``POST /api/business-reports/{id}/execute`` -> ``_run_report_query`` ->
``FederationEngine.execute_dataset_query``, which builds its own SQL and
runs it directly.  There is no ``query_config`` on that road, so there
was nothing for that gate to be reached FROM -- and even had the call
been copied over, the ``_rc_files`` half of the guard would have refused
a table-sourced dataset (which carries source_tables, not a file list)
and a raw-SQL dataset alike.  Two independent reasons, one outcome: the
identical report re-executed from S3 every single time.

THE SECOND ROAD (2026-09-07, later the same day)
------------------------------------------------
The paragraph above says a business report goes through
``execute_dataset_query``.  That is true of a DATASET-backed report and
false of a ``raw_sql`` one, which goes ``POST /{id}/execute`` ->
``business_reports_api._execute_raw_sql_report`` ->
``reports_api._run_sql_report`` -> ``core.cross_source_engine`` and never
enters the federation engine at all.  So the gate below covered one of two
roads, and the other -- the one that runs Starburst / Snowflake / Oracle /
cross-source SQL -- stayed uncached.

``build_identity_for_sql_report`` is that road's identity, and it is fed
to the SAME ``lookup`` / ``store`` as the dataset road: one gate
implementation, one key function, one freshness posture, two builders for
the two different things that need identifying.  Its gate sits in
``_run_sql_report`` at the single point where every side's SQL is final
and post-RLS and before any engine is chosen, for the same reason this
one sits where it does.  See that function's docstring for what is in
its key.

THE THIRD ROAD (2026-09-07, later the same day AGAIN)
------------------------------------------------------
Two of those paragraphs read as a finished job, and an auditor -- not
either author -- found the third.  A business report whose
``data_source_type`` is ``federation_view`` goes ``POST /{id}/execute`` ->
``api.federation_views_api.execute_federation_view``, entering NEITHER of
the two gates above.  It had a SCHEMA cache on the view row
(``schema_cache``/``schema_cached_at``) and nothing else, so both sides
re-executed against S3 and the DuckDB combine re-ran every single time.

``build_identity_for_federation_view`` is that road's identity.  Read its
docstring for what is in the key; the two things that differ from the
other roads are that a STRUCTURED side has no SQL at consult time (so the
row-security POLICY FINGERPRINT carries the policy for it) and that this
road's artifact is a PAGE rather than a whole answer (so ``limit``,
``offset`` and ``materialize`` are in the key, and ``total_rows`` rides
alongside the entry in ``store(extra=)``).

THE FOURTH ROAD IS REAL AND IS NOT COVERED HERE.  A ``raw_sql`` business
report backed by a STRUCTURED saved query (``saved_query_id``, not
``sql_saved_query_id``) goes ``business_reports_api._execute_raw_sql_report``
-> ``reports_api._run_parquet_report``, which runs ``OptimizedParquetEngine``
/ direct DuckDB / ``connector_to_parquet.execute_sql_to_parquet`` and
reaches NO result-cache consult at all -- from eight surfaces, scheduler and
subscription delivery included.  It is named here rather than quietly
covered because its identity is a different shape (a structured saved
query's config, the resolved file set, WHICH of its three engine branches
ran, and an RLS rewrite that happens in only one of them) and that shape has
not been agreed.  A gap that is written down is a scoping item; a gap that
is not is how "two of three" happened.

AN RLS PREDICATE THAT READS ANOTHER TABLE (2026-09-07)
------------------------------------------------------
Keying on the post-RLS SQL captures the policy -- for a SCALAR predicate.
It does NOT for a subquery one, and the product accepts those.  See
:func:`policies_are_cacheable` for the measurement and the refusal.

WHERE THIS GATE LIVES, AND WHY THERE
------------------------------------
Inside ``_execute_dataset_query_inner``, between "the SQL is final" and
"execute it".  That point is reached by EVERY road to a dataset query --
interactive execute, execute-async, pivot, drill-down, export, share
token, embed token, merged/union sides, the dataset preview -- because
they all funnel through ``execute_dataset_query``.  A gate at the call
sites would have had eleven copies and a twelfth added next month.

WHAT IS IN THE KEY, AND WHY EACH IS NOT OPTIONAL
------------------------------------------------
The key is built from what the engine holds at that point, NOT from
anything a caller passes -- a correctness property that depends on every
future caller remembering an argument is the wrong shape.

  * **the final, post-RLS SQL.**  Columns, calculated metrics, filters
    (parameters render into them), pre-defined conditions, ORDER BY, the
    aggregation overrides, the LIMIT, and the row-security rewrite are
    all already IN it.  "Same report, different parameters" and "same
    query, different row limit" are different SQL and therefore
    different keys, with no separate bookkeeping to drift.
  * **the principal.**  ``core.cache_identity.principal_scope_token`` --
    username + group set.  UNCONDITIONALLY, not "when row security is
    enabled": a scope that a config flag can switch off is how
    ``_resolve_user_namespace`` came to share one slot between two
    principals, and the cost of over-scoping is a cache miss while the
    cost of under-scoping is one user reading another's rows.  A
    ``user_ctx`` of None (agg-cache materialisation and other deliberate
    UNRESTRICTED callers) gets its own sentinel so an unfiltered body can
    never land in a scoped consumer's slot.
  * **the role.**  Column visibility is resolved per role.  It is already
    reflected in the SQL; it is in the key too, because the cheap
    belt-and-braces is worth more than the argument about whether the
    braces suffice.
  * **the dataset's lifecycle.**  ``updated_at`` -- so an edit that does
    not change the generated SQL (a type change, a rename that maps back)
    still invalidates.
  * **the connections.**  Same SQL against a re-pointed connection is a
    different answer.

REPORT LIFECYCLE.  An archived or republished business report never
reaches this gate with the wrong definition: ``_resolve_execution_report``
runs at the ROUTE, before dispatch, and 410s an archived report / swaps in
the current published version.  A republished version with different
columns or filters produces different SQL; a republished version with
identical columns and filters produces the same rows, which is the same
answer.  (The published-views lane, whose cache branch RETURNS before its
lifecycle check, needed ``_report_version_scope`` in its key for exactly
this reason -- that hazard does not exist here, and this docstring is
where the difference is recorded so nobody has to re-derive it.)

FRESHNESS -- THE GATE FAILS, IT DOES NOT THROTTLE
--------------------------------------------------
The key is deliberately S3-FREE: a cache must not tax the first run, and
a miss here makes ZERO remote calls.  Freshness is checked on the HIT,
with the machinery that already exists rather than a second copy of it:

  * **S3 / Iceberg sources** -- ``core.snapshot_fingerprint.
    check_cache_entry_staleness_multi``, with ``bypass_l1=True`` so the
    "current" side is FETCHED.  Its L1 memo has a 300s TTL, and a
    comparison against a five-minute-old memory is a bounded-staleness
    claim, not the verification this road discloses.  Cost: one LIST per
    table per hit, against the ~100 round trips it replaces.
  * **Local file sources** -- ``(path, size, mtime_ns)`` over the globs
    the FINAL SQL reads.  Exact, and a stat per file.  Added 2026-09-07
    after a TTL-only first cut served a rewritten local parquet's old
    rows and broke ``test_report_portal_end_to_end_2026_08_10``.

and then, on the verdict:

  * verifiably stale, or a probe that could not finish  -> EVICT and
    re-execute.  An interactive re-run after new data landed must never
    hand back the old rows.
  * verified current                                    -> serve,
    ``cache_freshness="verified"``.
  * **freshness could not be established at all** (a SQL connector has
    nothing cheap to fingerprint)                       -> **REFUSE the
    hit and re-execute.**  This road ALWAYS re-executed before the cache
    existed; quietly turning that into "up to an hour stale" would change
    a contract nobody asked to change, and a 200 carrying yesterday's
    rows is indistinguishable from a correct one.  An operator who wants
    TTL-bounded caching for such sources sets
    ``result_cache.serve_unverifiable_seconds`` to the window they accept
    being wrong for; that serve is still disclosed as
    ``cache_freshness="unknown"`` and is never upgraded.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

__all__ = [
    "CacheDecision",
    "is_enabled",
    "build_identity",
    "build_identity_for_sql_report",
    "build_identity_for_federation_view",
    "lookup",
    "store",
    "ROAD_DATASET",
    "ROAD_SQL_REPORT",
    "ROAD_FEDERATION_VIEW",
]

#: Freshness verdicts, mirroring core/reports/instances.py's posture.
FRESH_VERIFIED = "verified"
FRESH_UNKNOWN = "unknown"

#: Bound on the staleness probe.  A probe that cannot finish CANNOT prove
#: the body current, so a timeout evicts (see execute_api, which took the
#: same decision for the same reason).
_STALENESS_TIMEOUT_S = 15.0


class CacheDecision:
    """What the gate decided, and everything the caller must disclose."""

    __slots__ = ("key", "served", "freshness", "age_seconds", "row_count",
                 "column_count", "reason", "identity", "extra")

    def __init__(self, key: str = "", served: bool = False,
                 freshness: str = FRESH_UNKNOWN, age_seconds: float = 0.0,
                 row_count: int = 0, column_count: int = 0,
                 reason: str = "", identity: Optional[dict] = None,
                 extra: Optional[dict] = None):
        self.key = key
        self.served = served
        self.freshness = freshness
        self.age_seconds = age_seconds
        self.row_count = row_count
        self.column_count = column_count
        self.reason = reason
        self.identity = identity or {}
        #: Road-specific facts the caller stored ALONGSIDE the parquet and
        #: cannot recompute from it -- the federation road's ``total_rows``
        #: (a COUNT over the whole combine, while the artifact holds only
        #: the requested page) and its cross-side type-mismatch warning.
        #: Empty on a miss and on every road that stores none.
        self.extra = extra or {}


# ── configuration ────────────────────────────────────────────────────────────


def is_enabled() -> bool:
    """``result_cache.enabled`` AND ``result_cache.dataset_path_enabled``.

    Two knobs because they answer different questions: the first is "is
    the result cache running at all" (shared with /api/execute), the
    second is "may the dataset/report road use it" -- an operator who
    hits trouble here must be able to switch off THIS road without
    darkening the SQL editor's cache too.  Both default TRUE; both are
    declared in ``core.config._DEFAULTS`` (an undeclared knob is a knob
    no guard can see).
    """
    try:
        from core.config import get_section
        cfg = get_section("result_cache") or {}
        return (bool(cfg.get("enabled", True))
                and bool(cfg.get("dataset_path_enabled", True)))
    except Exception as exc:                      # pragma: no cover
        logger.debug("[dataset-cache] config unreadable (%s) — disabled", exc)
        return False


def _ttl_seconds() -> Optional[int]:
    try:
        from core.config import get_section
        cfg = get_section("result_cache") or {}
        v = cfg.get("dataset_path_ttl_seconds")
        if v is None:
            return None                # ResultCache's own default_ttl
        return max(0, int(v))
    except Exception:                             # pragma: no cover
        return None


# ── identity ─────────────────────────────────────────────────────────────────


def _principal_scope(user_ctx: Optional[Dict[str, Any]]) -> str:
    """The principal half of the key.  ALWAYS a value, never None.

    ``user_ctx is None`` and ``user_ctx == {}`` are DIFFERENT principals:
    the first is a deliberate internal unrestricted caller, the second is
    an anonymous request.  Folding them together would let an
    unrestricted agg-cache materialisation populate the slot an anonymous
    share-token consumer then reads.
    """
    from core.cache_identity import (
        UNSCOPED_INTERNAL, principal_scope_token,
    )
    if user_ctx is None:
        return UNSCOPED_INTERNAL
    token = principal_scope_token(user_ctx)
    # An unresolved principal (group lookup failed) is NOT the same
    # consumer as one whose groups resolved to the same list -- the
    # rewriter treats them differently, so the cache must too.
    if user_ctx.get("rls_unresolved"):
        token = f"{token}:rls_unresolved"
    return token


def _source_table_ids(source_tables: List[Dict[str, Any]]) -> List[str]:
    """``["<conn_id>:<table>", ...]`` sorted -- the table IDENTIFIERS.

    These become the KEYS of the fingerprint dict handed to
    ``build_cache_key``, which is also what ``ResultCache.
    invalidate_for_table`` substring-matches against, so an admin
    invalidation reaches these entries too.
    """
    out = []
    for st in (source_tables or []):
        if not isinstance(st, dict):
            continue
        cid = st.get("connection_id") or st.get("conn_id")
        tbl = st.get("table") or st.get("table_name") or st.get("name")
        if tbl:
            out.append(f"{cid}:{tbl}")
    return sorted(set(out))


def build_identity(
    *,
    sql: str,
    dataset_id: int,
    dataset: Optional[Dict[str, Any]],
    source_tables: List[Dict[str, Any]],
    connections: Any,
    row_limit: Any,
    user_role: str,
    user_ctx: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Everything that identifies this result.  No S3, no DB, no clock."""
    ds = dataset or {}
    try:
        conn_ids = sorted(int(c) for c in (connections or {}))
    except Exception:
        conn_ids = sorted(str(c) for c in (connections or {}))
    return {
        "sql": sql or "",
        "params": {
            # Which road produced this entry.  Two roads reach this module
            # and their ``params`` differ in shape; the marker makes a
            # cross-road collision impossible to argue about rather than
            # merely unlikely.
            "road": ROAD_DATASET,
            "dataset_id": int(dataset_id),
            "row_limit": row_limit,
            "user_role": str(user_role or ""),
            "connection_ids": conn_ids,
            # The dataset's lifecycle: an edit that does not reach the
            # SQL still has to invalidate.
            "dataset_updated_at": str(ds.get("updated_at") or ""),
            "dataset_version": str(ds.get("version") or ""),
        },
        "tables": _source_table_ids(source_tables),
        "scope": _principal_scope(user_ctx),
    }


#: The road a cache entry was produced on.  Two roads reach this module
#: (``dataset`` = FederationEngine, ``sql_report`` = the raw-SQL report
#: engines) and they carry different ``params`` shapes; the marker means
#: their keys can never be argued about rather than merely being unlikely
#: to collide.
ROAD_DATASET = "dataset"
ROAD_SQL_REPORT = "sql_report"


def build_identity_for_sql_report(
    *,
    report_id: Any,
    primary_sql: str,
    primary_connection_id: Any,
    secondary_sql: str = "",
    secondary_connection_id: Any = None,
    combine_mode: str = "",
    join_config: Optional[Dict[str, Any]] = None,
    row_limit: Any = None,
    user_ctx: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """The identity of a **raw-SQL business report** result.

    2026-09-07.  WHY THIS ROAD NEEDED ITS OWN BUILDER
    -------------------------------------------------
    ``8379f4ff`` put the result cache inside ``_execute_dataset_query_inner``
    because everything that runs a DATASET query funnels through there.  A
    ``raw_sql`` business report does not: ``POST /{id}/execute`` ->
    ``_execute_raw_sql_report`` -> ``reports_api._run_sql_report`` ->
    ``core.cross_source_engine``, and it never touches the federation
    engine at all.  Same product-visible thing ("run this report"), a
    completely different road, and the consult on the first road cannot be
    reached from the second -- so the identical report re-executed on
    Starburst / S3 every single time.

    WHAT IS IN THE KEY, AND WHY
    ---------------------------
      * **the FINAL, POST-RLS SQL of every side.**  Built after Step 0
        (``${user.*}``), Step 1 (``{param}`` substitution), Step 2
        (auto-appended partition WHERE) and Step 2b (``row_security.
        secure_sql``) have all run, so parameters, user variables and the
        row-security predicates are already inside it.  A cached body
        therefore cannot outlive the policy that shaped it: change the
        policy, the rewrite changes, the SQL changes, the key changes.
        Both sides of a cross-source report are in the key -- caching on
        the primary alone would serve one report's rows for another whose
        secondary differs.
      * **the principal, UNCONDITIONALLY.**  Not gated on
        ``row_security.enabled``: a scope a config flag can switch off is
        how one slot comes to be shared by two principals, and flipping row
        security on would then serve a body cached for somebody else
        moments earlier.  Over-scoping costs a miss; under-scoping is one
        user reading another's rows.
      * **the role**, for the same belt-and-braces reason the dataset road
        keeps it.
      * **the connections.**  Same SQL against a re-pointed connection is a
        different answer.
      * **the combine mode and join config**, which decide what the two
        sides become.
      * **the row limit**, which is not part of the SQL on this road (the
        engines apply it themselves), so it must be part of the key.

    FRESHNESS.  Handed to the SAME ``lookup`` / ``store`` as the dataset
    road, so it inherits that gate unchanged: ``source_tables`` is empty
    here (a raw-SQL report names no registered tables), which means a
    report against a SQL connector has nothing cheap to fingerprint and is
    therefore **neither stored nor served** while
    ``result_cache.serve_unverifiable_seconds`` is 0 (the default).  That
    is the correct posture, not a limitation: this road always
    re-executed, and quietly converting that into "up to an hour stale"
    would change a contract nobody asked to change.  Raw SQL that names
    files (``read_parquet('...')``) IS fingerprinted exactly, cached, and
    verified on every hit.
    """
    mode = (combine_mode or "").strip().lower()
    # ONE text carrying every side, because ``is_cacheable_sql`` and
    # ``local_paths_in_sql`` both read ``identity["sql"]``: a NOW() or a
    # local file literal on the SECONDARY side must be seen too.
    #
    # Concatenated rather than JSON-encoded on purpose: a JSON encoding
    # doubles the backslashes in a Windows ``read_parquet('C:\...')``
    # literal, and ``local_paths_in_sql`` would then extract a path that
    # does not exist -- silently turning an exactly-verifiable local
    # source into an unverifiable one, on one platform only.  The literals
    # must survive VERBATIM.
    #
    # And the separator is a plain ``;``, NOT a SQL comment: the key
    # function runs ``result_cache.normalize_sql``, which STRIPS comments
    # outside literals.  A first cut used ``/* ... */`` markers to carry
    # the combine mode and the join config -- and they were erased before
    # hashing, so two reports differing only in their join config shared a
    # key.  Anything that must be IN the key goes in ``params`` below,
    # where it is hashed verbatim; the composite carries only the SQL text
    # the scanners need to see.
    composite = "\n;\n".join([primary_sql or "", secondary_sql or ""])
    # The join spec, canonicalised, as a HASH so a large config does not
    # bloat the key.  In ``params`` because a comment would not survive
    # normalisation.
    import hashlib as _hl
    join_fp = _hl.sha256(json.dumps(
        join_config or {}, sort_keys=True, default=str).encode()
    ).hexdigest()[:16]
    try:
        conn_ids = sorted(
            int(c) for c in (primary_connection_id, secondary_connection_id)
            if c is not None)
    except Exception:
        conn_ids = sorted(
            str(c) for c in (primary_connection_id, secondary_connection_id)
            if c is not None)
    return {
        "sql": composite,
        "params": {
            "road": ROAD_SQL_REPORT,
            "report_id": str(report_id),
            "row_limit": row_limit,
            "user_role": str((user_ctx or {}).get("role") or ""),
            "connection_ids": conn_ids,
            "combine_mode": mode,
            "join_fingerprint": join_fp,
            # Whether there IS a secondary side, so "A;<empty>" and
            # "<empty>;A" can never be argued to be the same composite.
            "has_secondary": bool((secondary_sql or "").strip()),
        },
        # No registered source tables on this road -- see FRESHNESS above.
        "tables": [],
        "scope": _principal_scope(user_ctx),
    }


#: The THIRD road (2026-09-07, later the same day again).  See
#: :func:`build_identity_for_federation_view`.
ROAD_FEDERATION_VIEW = "federation_view"


def _canonical_fingerprint(obj: Any) -> str:
    """A short, stable digest of any JSON-able structure.

    In ``params`` rather than in ``sql`` because ``params`` is hashed
    VERBATIM, while ``sql`` goes through ``result_cache.normalize_sql``,
    which strips comments outside literals -- the trap the sql-report
    builder's docstring records (a ``/* ... */`` marker carrying the join
    config was erased before hashing, so two reports differing only in
    their join config shared a key).
    """
    import hashlib as _hl
    return _hl.sha256(json.dumps(obj, sort_keys=True, default=str)
                      .encode()).hexdigest()[:16]


def build_identity_for_federation_view(
    *,
    view_id: Any,
    sides: List[Dict[str, Any]],
    combine_mode: str,
    join_on: Any = None,
    join_how: str = "",
    output_columns: Any = None,
    extra_filters: Any = None,
    dynamic_columns: Any = None,
    limit: Any = None,
    offset: Any = 0,
    materialize: bool = False,
    rls_policy_fingerprint: str = "",
    credential_username: str = "",
    user_ctx: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """The identity of a **federation-view** result.

    2026-09-07.  THE THIRD ROAD, AND THE ONE NOBODY MENTIONED
    ---------------------------------------------------------
    ``8379f4ff`` cached the dataset road and ``916d820b`` cached the
    raw-SQL road, and between them their commit messages read as a
    complete job.  They were not: a business report whose
    ``data_source_type`` is ``federation_view`` goes ``POST /{id}/execute``
    -> ``api.federation_views_api.execute_federation_view``, which enters
    neither ``_execute_dataset_query_inner`` nor ``_run_sql_report``.  It
    had a SCHEMA cache (``schema_cache``/``schema_cached_at`` on the view
    row) and nothing else, so it re-executed BOTH sides against S3 and
    re-ran the DuckDB combine on every single run -- the exact symptom the
    first commit was written for, on a road neither commit looked at.

    WHAT IS IN THE KEY, AND WHY EACH IS NOT OPTIONAL
    ------------------------------------------------
      * **each side's FINAL, POST-RLS SQL** -- for a side that carries
        ``raw_sql``.  Resolved by ``federation_views_api._resolve_side_sql``,
        which is the SAME function ``_execute_side`` uses to produce the
        SQL it executes, hoisted so the consult can see it: one rewrite,
        computed once, keyed and then executed.  A cached body therefore
        cannot outlive the policy that shaped it -- change the policy, the
        rewrite changes, the SQL changes, the key changes.  Both sides are
        in the key: keying on the primary alone would serve one view's
        rows for another whose secondary differs.
      * **the ROW-SECURITY POLICY FINGERPRINT**
        (``core.identity.rls_predicates.compute_policy_fingerprint``) --
        the DB-derived digest of the entire row-security configuration.
        Needed because a STRUCTURED side (no ``raw_sql``) has no SQL at
        this point at all: its rewrite happens inside
        ``execute_api.execute_query_background``, which synthesises SQL
        from the query config and secures it there.  Recomputing that here
        purely to hash it would be a second answer to "what does this side
        run", and this repo's rule is that a decision made twice is a bug.
        The fingerprint closes the same hole from the other end and closes
        it for BOTH side shapes: any policy add / edit / delete /
        rebinding changes the digest, so no entry can survive the policy
        that produced it.  It OVER-invalidates (an edit to a policy that
        binds nobody here still changes the digest) -- that is a cap, not
        a gate: the next run simply executes.
      * **the principal, UNCONDITIONALLY.**  Never gated on
        ``row_security.enabled``: a scope a config flag can switch off is
        how one slot comes to be shared by two principals.  Over-scoping
        costs a miss; under-scoping is one user reading another's rows.
      * **the CREDENTIAL username**, which on this road is a SECOND
        identity and not a duplicate of the principal.
        ``published_views_api`` passes ``username=pv["created_by"]``
        (whose S3 credentials the sides read with) alongside
        ``user_ctx=<the consumer>`` (whose row policies apply), and its own
        comments label them "CREDENTIAL identity" and "RLS identity".
        ``_fv_principal`` uses ``user_ctx`` as-is whenever it names a user,
        so the principal token does NOT carry the credential half: two
        published views over one federation view, published by different
        people, read through different credentials and can therefore see
        different bytes for one consumer.  Keying on the principal alone
        would share those.
      * **each side's query config** (fingerprinted, ``raw_sql`` removed
        because it is already in ``sql`` verbatim) -- the structured side's
        files, filters, columns, aggregations and per-side limit.
      * **the combine**: mode, join columns, join type, output projection.
        These decide what the two sides BECOME.
      * **``extra_filters`` and ``dynamic_columns``** -- the consumer
        override.  ``dynamic_columns`` is not decoration: it decides which
        of the publisher's hardcoded predicates are REMOVED before the
        override is AND-ed, so the same filters with and without it are
        different row sets.
      * **``limit``, ``offset`` and ``materialize``.**  Unlike the other
        two roads, this artifact is the PAGE, not the whole answer: the
        engine applies ``LIMIT/OFFSET`` in the combine.  ``materialize``
        is the third state -- ``materialize_to`` ignores limit/offset and
        writes the WHOLE combined set -- and a boolean in the key is what
        stops a 1,000-row page ever being served to a caller that asked
        for the lot.

    FRESHNESS.  Handed to the SAME ``lookup``/``store`` as the other two
    roads.  ``tables`` carries each side's file/prefix list as
    ``"<conn_id>:<name>"``, which is both what ``_capture_source_fingerprints``
    fingerprints (S3 sides, via the registered-table resolver with
    ``table_name_is_prefix=True``) and what ``ResultCache.invalidate_for_table``
    substring-matches, so an admin invalidation reaches these entries too.
    Local sides are fingerprinted exactly through ``store(local_patterns=)``.
    A side this cannot fingerprint at all leaves the entry unservable, and
    ``store`` then refuses to write it while ``serve_unverifiable_seconds``
    is 0 (the default) -- the same posture, for the same reason, as the
    raw-SQL road's SQL-connector case.
    """
    _sides = list(sides or [])
    # ONE text carrying every side, because ``is_cacheable_sql`` and
    # ``local_paths_in_sql`` both read ``identity["sql"]``.
    #
    # A raw_sql side contributes its POST-RLS text VERBATIM -- not JSON
    # encoded -- because ``local_paths_in_sql`` must be able to extract a
    # Windows ``read_parquet('C:\\...')`` literal, and a JSON encoding
    # doubles the backslashes so the extracted path would not exist,
    # silently turning an exactly-verifiable local source into an
    # unverifiable one on one platform only (the trap the sql-report
    # builder records).
    #
    # A STRUCTURED side contributes its canonical config JSON, for two
    # reasons that are both about ``is_cacheable_sql``: an all-structured
    # view would otherwise contribute NO text at all and be refused as
    # "empty SQL" -- i.e. the common case would never cache -- and the
    # non-determinism scan must still be able to SEE a ``NOW()`` hiding
    # in a computed column or a case expression, which a config
    # fingerprint alone would hide from it.  Its files are handed to
    # ``store(local_patterns=)`` explicitly rather than parsed back out
    # of this text, so the JSON escaping cannot mislead anything.
    def _side_text(s: Dict[str, Any]) -> str:
        final = str(s.get("final_sql") or "").strip()
        if final:
            return final
        return json.dumps(s.get("query_config") or {}, sort_keys=True,
                          default=str)
    composite = "\n;\n".join(_side_text(s) for s in _sides)
    try:
        conn_ids = [int(s.get("connection_id")) for s in _sides
                    if s.get("connection_id") is not None]
    except Exception:
        conn_ids = [str(s.get("connection_id")) for s in _sides
                    if s.get("connection_id") is not None]
    tables: List[str] = []
    for s in _sides:
        cid = s.get("connection_id")
        for t in (s.get("source_tables") or []):
            name = (t or {}).get("table")
            if name:
                tables.append(f"{cid}:{name}")
    return {
        "sql": composite,
        "params": {
            "road": ROAD_FEDERATION_VIEW,
            "view_id": str(view_id),
            # ORDERED, not a set: primary and secondary are not
            # interchangeable in a JOIN or in the output projection.
            "connection_ids": conn_ids,
            "side_configs": [_canonical_fingerprint(s.get("query_config") or {})
                             for s in _sides],
            "has_raw_sql": [bool(str(s.get("final_sql") or "").strip())
                            for s in _sides],
            "combine_mode": (combine_mode or "").strip().lower(),
            "join_how": (join_how or "").strip().lower(),
            "join_fingerprint": _canonical_fingerprint(join_on or []),
            "output_columns": list(output_columns or []),
            "extra_filters_fingerprint": _canonical_fingerprint(
                extra_filters or []),
            "dynamic_columns": sorted(str(c) for c in (dynamic_columns or [])),
            # The artifact on this road is the PAGE, not the whole answer.
            "materialize": bool(materialize),
            "limit": None if materialize else limit,
            "offset": None if materialize else offset,
            "user_role": str((user_ctx or {}).get("role") or ""),
            # The CREDENTIAL identity, which is not the principal on this
            # road -- see the docstring.
            "credential_username": str(credential_username or ""),
            # See the docstring: this is what makes a STRUCTURED side's
            # policy change invalidate, and it belt-and-braces the
            # raw-SQL side whose rewrite is already inside ``sql``.
            "rls_policy_fingerprint": str(rls_policy_fingerprint or ""),
        },
        "tables": sorted(set(tables)),
        "scope": _principal_scope(user_ctx),
    }


def _key_for(identity: Dict[str, Any]) -> str:
    """``core.result_cache.build_cache_key`` -- reused, not re-invented."""
    from core.result_cache import build_cache_key
    fingerprint = dict.fromkeys(identity.get("tables") or [], "")
    return build_cache_key(
        identity.get("sql") or "",
        identity.get("params") or {},
        fingerprint,
        user_namespace=identity.get("scope") or "",
    )


# ── freshness ────────────────────────────────────────────────────────────────


# A quoted literal inside read_parquet/read_csv/read_json that is NOT a
# remote URL: a LOCAL dataset's files.  These are fingerprintable EXACTLY
# and for free (a stat per file), which matters because a local-source
# report is the one case where "we cannot tell if it changed" would be a
# plain lie -- and where serving a TTL-stale body silently broke a
# standing end-to-end test on 2026-09-07.
_LOCAL_LIT_RE = re.compile(
    r"read_(?:parquet|csv|csv_auto|json|json_auto)\s*\(\s*\[?\s*"
    r"((?:'[^']*'\s*,?\s*)+)", re.IGNORECASE)
_QUOTED_RE = re.compile(r"'([^']*)'")
_REMOTE_PREFIXES = ("s3://", "s3a://", "gs://", "az://", "azure://",
                    "http://", "https://", "r2://", "gcs://")


def local_paths_in_sql(sql: str) -> List[str]:
    """Every LOCAL file/glob literal the SQL reads.  Sorted, de-duplicated.

    Derived from the FINAL SQL rather than from the dataset definition on
    purpose: a custom-SQL (``base_query``) dataset names its files in the
    SQL and nowhere else, and the SQL is what actually ran.
    """
    out = set()
    for m in _LOCAL_LIT_RE.finditer(sql or ""):
        for lit in _QUOTED_RE.findall(m.group(1)):
            low = lit.lower()
            if lit and not low.startswith(_REMOTE_PREFIXES):
                out.add(lit)
    return sorted(out)


def _local_fingerprint(patterns: List[str]) -> str:
    """``sha256`` over (path, size, mtime_ns) for every matching file.

    Empty string when there is nothing to fingerprint OR when any pattern
    cannot be expanded -- an unreadable directory is NOT "no files", and
    conflating them is how "could not read" becomes "has none".
    """
    if not patterns:
        return ""
    import glob as _glob
    import hashlib as _hl
    h = _hl.sha256()
    seen = 0
    for pat in patterns:
        try:
            matches = sorted(_glob.glob(pat, recursive=True))
            if not matches and os.path.exists(pat):
                matches = [pat]
        except Exception:
            return ""
        for f in matches:
            try:
                st = os.stat(f)
            except OSError:
                return ""
            h.update(("%s|%s|%s" % (f, st.st_size, st.st_mtime_ns))
                     .encode("utf-8", "replace"))
            seen += 1
    return h.hexdigest() if seen else ""


def _capture_source_fingerprints(
    db_manager, source_tables: List[Dict[str, Any]],
) -> Tuple[str, List[Dict[str, Any]]]:
    """``(source_fingerprint, source_tables_json)`` for the stored entry.

    ALL OR NOTHING.  Returns ``("", [])`` unless EVERY table named was
    fingerprinted.

    2026-09-07 -- this used to be "best effort", and the docstring said a
    table it could not fingerprint "is simply absent from the list, which
    the staleness check reads as 'no opinion' -- and the serve then
    discloses freshness='unknown' rather than claiming fresh."  READ THE
    CODE, NOT THE DOCSTRING: ``check_cache_entry_staleness_multi`` is
    handed the SUBSET, finds every member of it current, and returns
    ``reason="fresh"`` -- so ``_verify_freshness`` returns
    ``FRESH_VERIFIED`` and the response CLAIMS verification over a table
    nobody looked at.  A dataset joining an S3 table to a Trino one
    (nothing cheap to fingerprint) is exactly that shape.

    A PARTIAL fingerprint is worse than none: none refuses the hit, a
    partial one asserts freshness it did not establish.  "Could not read"
    is not "unchanged", and a value computed for a correctness gate and
    then quietly narrowed will disagree with what the system claims.
    """
    try:
        from core import snapshot_fingerprint as sfp
    except Exception:                             # pragma: no cover
        return "", []
    resolver = sfp.make_registered_table_s3_resolver(
        db_manager, table_name_is_prefix=True)
    rows: List[Dict[str, Any]] = []
    wanted = 0
    for st in (source_tables or []):
        if not isinstance(st, dict):
            continue
        cid = st.get("connection_id") or st.get("conn_id")
        tbl = st.get("table") or st.get("table_name") or st.get("name")
        if cid is None or not tbl:
            continue
        wanted += 1
        resolved = resolver(cid, tbl)
        if resolved is None:
            logger.debug("[dataset-cache] %s/%s does not resolve to a "
                         "fingerprintable source — this result cannot be "
                         "verified as a whole", cid, tbl)
            return "", []
        client, bucket, prefix = resolved
        fmt = sfp.registered_table_format(db_manager, cid, tbl)
        try:
            fp = sfp.get_table_fingerprint(
                conn_id=cid, table_name=tbl, table_format=fmt,
                s3_client=client, bucket=bucket, prefix=prefix)
        except Exception as exc:
            logger.debug("[dataset-cache] fingerprint failed %s/%s: %s",
                         cid, tbl, exc)
            return "", []
        if not fp:
            return "", []
        rows.append({
            "conn_id": cid, "table_name": tbl, "format": fmt,
            "snapshot_id": fp.get("snapshot_id"),
            "file_list_hash": fp.get("file_list_hash"),
            "file_count": fp.get("file_count"),
        })
    # A REDUNDANT BACKSTOP, kept knowingly.  Every incomplete path above
    # already returned ``("", [])``, so no input can distinguish this line
    # from ``if not rows`` -- a mutation of it survives, and that is
    # reported rather than papered over.  It is kept because the thing it
    # asserts (fingerprinted == asked) is the property the whole function
    # exists for, and the cheapest way for a future edit to reintroduce
    # the defect is to turn one of those returns back into a ``continue``.
    if not rows or len(rows) != wanted:
        return "", []
    return sfp.compute_source_fingerprint(rows), rows


def _verify_freshness(db_manager, stored: Dict[str, Any]) -> Tuple[bool, str]:
    """``(is_stale, freshness)`` for a hit.

    ``is_stale`` True means EVICT.  ``freshness`` is what the response
    discloses when it is False.  A probe that raises, times out, or
    cannot be run at all is never reported as fresh.
    """
    # ── LOCAL files first: exact, and it costs a stat per file ──────
    #
    # 2026-09-07.  Without this, a dataset over a local parquet directory
    # was served its cached body after the file underneath was rewritten
    # -- caught by tests/test_report_portal_end_to_end_2026_08_10.py,
    # which has asserted "a re-run picks up new data" since August.  A
    # local file is the one source where "we cannot tell whether it
    # changed" would be a plain untruth, so it is checked exactly.
    local_pats = stored.get("local_patterns") or []
    if local_pats:
        now_fp = _local_fingerprint(local_pats)
        was_fp = stored.get("local_fingerprint") or ""
        if not now_fp or not was_fp:
            # A pattern that no longer expands, or a stat that failed.
            # "Could not read" is not "unchanged".
            return True, FRESH_UNKNOWN
        if now_fp != was_fp:
            logger.info("[dataset-cache] STALE (local files changed) — "
                        "evicting")
            return True, FRESH_UNKNOWN

    tables = stored.get("source_tables_json") or []
    fingerprint = stored.get("source_fingerprint") or ""
    if not tables or not fingerprint:
        # Verified iff the LOCAL side proved it; otherwise nothing here
        # has an opinion.
        return False, (FRESH_VERIFIED if local_pats else FRESH_UNKNOWN)
    try:
        from core.snapshot_fingerprint import (
            check_cache_entry_staleness_multi,
            make_registered_table_s3_resolver,
        )
    except Exception:                             # pragma: no cover
        return False, FRESH_UNKNOWN
    entry = {"source_fingerprint": fingerprint, "source_tables_json": tables}
    resolver = make_registered_table_s3_resolver(
        db_manager, table_name_is_prefix=True)
    try:
        # bypass_l1: this road DISCLOSES "verified", so the comparison has
        # to look at the source rather than at a <=300s-old remembered
        # fingerprint.  See check_cache_entry_staleness_multi's docstring
        # for the measurement that made that trade worth one LIST.
        is_stale, reason = _bounded(
            lambda *_a: check_cache_entry_staleness_multi(
                entry, resolver, bypass_l1=True))
    except TimeoutError:
        logger.info("[dataset-cache] staleness probe exceeded %.0fs — "
                    "evicting (cannot prove the body current)",
                    _STALENESS_TIMEOUT_S)
        return True, FRESH_UNKNOWN
    except Exception as exc:
        # Could not run the probe at all.  NOT stale (we have no evidence
        # of a change) but definitely not verified either.
        logger.debug("[dataset-cache] staleness probe error: %s", exc)
        return False, FRESH_UNKNOWN
    if is_stale:
        logger.info("[dataset-cache] STALE (%s) — evicting", reason)
        return True, FRESH_UNKNOWN
    if reason == "fresh":
        return False, FRESH_VERIFIED
    # "no-fingerprint" / "disabled" / "table-not-found" / "check-failed":
    # the probe ran and declined to have an opinion.
    return False, FRESH_UNKNOWN


def _bounded(fn, *args):
    """Run ``fn`` on a worker thread, bounded by ``_STALENESS_TIMEOUT_S``.

    This gate is entered from a WORKER thread (the report route hands the
    engine to ``asyncio.to_thread``), so there is no event loop here to
    ``wait_for`` against -- a plain thread + join is the right shape, and
    it keeps the timeout honest on the sync callers (feeds, exports) too.
    """
    from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FTO
    with ThreadPoolExecutor(max_workers=1) as ex:
        fut = ex.submit(fn, *args)
        try:
            return fut.result(timeout=_STALENESS_TIMEOUT_S)
        except _FTO:
            # Do NOT block the caller waiting for the abandoned probe:
            # let the pool shut down without joining it.
            ex.shutdown(wait=False, cancel_futures=True)
            raise TimeoutError("staleness probe timed out")


# ── the gate ─────────────────────────────────────────────────────────────────


def _read_stored_fingerprint(entry) -> Dict[str, Any]:
    """The freshness payload this gate wrote at store time.

    Lives in the entry's ``snapshot_fingerprint`` dict under a reserved
    key, so ``ResultCache`` needs no schema change and the table
    identifiers stay where ``invalidate_for_table`` looks for them.
    Read off the CacheEntry rather than the sidecar so an L1 hit is not
    forced back to the filesystem.
    """
    try:
        fp = getattr(entry, "snapshot_fingerprint", None)
        if isinstance(fp, str):
            fp = json.loads(fp or "{}")
        return (fp or {}).get("__freshness__") or {}
    except Exception:
        return {}


def _read_stored_extra(entry) -> Dict[str, Any]:
    """The road-specific payload ``store(extra=...)`` wrote, or ``{}``.

    Same slot mechanism as ``__freshness__``: a reserved key inside the
    entry's ``snapshot_fingerprint`` dict, so ``ResultCache`` needs no
    schema change and the table identifiers stay where
    ``invalidate_for_table`` looks for them.
    """
    try:
        fp = getattr(entry, "snapshot_fingerprint", None)
        if isinstance(fp, str):
            fp = json.loads(fp or "{}")
        return (fp or {}).get("__extra__") or {}
    except Exception:
        return {}


def lookup(
    *,
    identity: Dict[str, Any],
    output_path: str,
    db_manager=None,
) -> CacheDecision:
    """Try to serve ``identity``'s result into ``output_path``.

    Fail-open in every direction: any error is a MISS, and a miss costs
    the caller nothing but the key computation (no S3, no DB).
    """
    key = ""
    try:
        if not is_enabled():
            return CacheDecision(reason="disabled", identity=identity)
        from core.result_cache import get_result_cache, is_cacheable_sql
        rc = get_result_cache()
        if rc is None:
            return CacheDecision(reason="no-cache", identity=identity)
        ok, why = is_cacheable_sql(identity.get("sql") or "",
                                   _skip_patterns())
        if not ok:
            return CacheDecision(reason=f"not-cacheable:{why}",
                                 identity=identity)
        pol_ok, pol_why = policies_are_cacheable(db_manager)
        if not pol_ok:
            # See the block comment on ``policies_are_cacheable``: a
            # predicate that reads a table this gate cannot fingerprint
            # would let a REVOKED entitlement keep serving rows until the
            # TTL.  A correctness gate FAILS; it does not throttle.
            logger.info("[dataset-cache] declining to serve — %s", pol_why)
            return CacheDecision(reason=f"policy-not-fingerprintable:{pol_why}",
                                 identity=identity)
        key = _key_for(identity)
        entry = rc.get(key)
        if entry is None:
            return CacheDecision(key=key, reason="miss", identity=identity)

        stale, freshness = _verify_freshness(
            db_manager, _read_stored_fingerprint(entry))
        if not stale and freshness != FRESH_VERIFIED:
            # ── A CORRECTNESS GATE FAILS; IT DOES NOT THROTTLE ──────
            #
            # Freshness could not be established for this source (a SQL
            # connector has nothing cheap to fingerprint; a table that
            # resolves to no prefix has nothing to list).  This road
            # ALWAYS re-executed before today, so quietly converting
            # that into "up to an hour stale" would be a change of
            # contract the operator never asked for -- and a 200 with
            # yesterday's rows is indistinguishable from a correct one.
            #
            # Default: refuse the hit and re-execute.  An operator who
            # WANTS TTL-bounded caching for such sources sets
            # ``result_cache.serve_unverifiable_seconds`` to the window
            # they are willing to be wrong for; the serve is then still
            # disclosed as ``cache_freshness: "unknown"``, never
            # upgraded.
            _window = _unverifiable_window()
            if _window <= 0 or age_of(entry) > _window:
                logger.debug(
                    "[dataset-cache] declining an unverifiable hit "
                    "(key=%s window=%ss) — re-executing", key[:16],
                    _window)
                return CacheDecision(key=key, reason="unverifiable",
                                     identity=identity)
        if stale:
            try:
                rc.invalidate(key)
            except Exception as exc:              # pragma: no cover
                logger.debug("[dataset-cache] evict failed: %s", exc)
            return CacheDecision(key=key, reason="stale-evicted",
                                 identity=identity)

        import shutil
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        shutil.copyfile(entry.file_path, output_path)
        age = max(0.0, time.time() - float(entry.created_at or 0.0))
        logger.info(
            "[dataset-cache] HIT key=%s rows=%d freshness=%s age=%.1fs "
            "scope=%s — S3 and DuckDB not touched",
            key[:16], entry.row_count, freshness, age,
            str(identity.get("scope"))[:24])
        return CacheDecision(key=key, served=True, freshness=freshness,
                             age_seconds=round(age, 3),
                             row_count=int(entry.row_count or 0),
                             column_count=int(entry.column_count or 0),
                             reason="hit", identity=identity,
                             extra=_read_stored_extra(entry))
    except Exception as exc:
        logger.debug("[dataset-cache] lookup failed (fail-open miss): %s", exc)
        return CacheDecision(key=key, reason="error", identity=identity)


def store(
    *,
    identity: Dict[str, Any],
    output_path: str,
    row_count: int,
    column_count: int,
    source_tables: Optional[List[Dict[str, Any]]] = None,
    db_manager=None,
    key: str = "",
    local_patterns: Optional[List[str]] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> bool:
    """Best-effort write-through.  Never raises, never blocks the answer.

    ``local_patterns`` (2026-09-07) -- local file globs the SQL text does
    NOT name.  The dataset and raw-SQL roads carry their local sources as
    ``read_parquet('...')`` literals, so parsing the final SQL finds them
    all; a federation view's STRUCTURED side names its files in a query
    config instead, and its ``base_path`` lives on the connection.  Those
    resolved paths are passed in and UNIONed with the parsed ones, so a
    local federation view is fingerprinted exactly (a stat per file)
    rather than being unverifiable and therefore uncacheable.

    ``extra`` -- road-specific facts the caller cannot recompute from the
    stored parquet, returned on a hit as ``CacheDecision.extra``.  It is
    NOT part of the key: it is an OUTPUT of the run, not an identity.
    """
    try:
        if not is_enabled():
            return False
        from core.result_cache import get_result_cache, is_cacheable_sql
        rc = get_result_cache()
        if rc is None:
            return False
        ok, _why = is_cacheable_sql(identity.get("sql") or "",
                                    _skip_patterns())
        if not ok:
            return False
        pol_ok, pol_why = policies_are_cacheable(db_manager)
        if not pol_ok:
            # Refused at the WRITE as well as the read.  An entry that can
            # never be served is disk spent to push servable entries out of
            # the bounded L2 by LRU -- and an entry written now would still
            # be sitting there if the offending policy were later deleted,
            # carrying rows computed under a policy set nobody can now
            # reconstruct.
            logger.debug("[dataset-cache] not storing — %s", pol_why)
            return False
        cache_key = key or _key_for(identity)
        src_fp, src_tables = _capture_source_fingerprints(
            db_manager, source_tables or [])
        local_pats = sorted(set(local_paths_in_sql(identity.get("sql") or ""))
                            | {str(p) for p in (local_patterns or []) if p})
        local_fp = _local_fingerprint(local_pats)
        if not src_fp and not local_fp and _unverifiable_window() <= 0:
            # Nothing about this source can be verified, and the operator
            # has not opted into serving what cannot be verified -- so
            # this entry could never be SERVED.  Writing it anyway would
            # spend disk and push genuinely servable entries out of the
            # bounded L2 by LRU.  Refuse at the write, not just the read.
            logger.debug(
                "[dataset-cache] not storing an unverifiable result "
                "(nothing to fingerprint, serve_unverifiable_seconds=0)")
            return False
        fingerprint: Dict[str, Any] = dict.fromkeys(
            identity.get("tables") or [], "")
        fingerprint["__freshness__"] = {
            "source_fingerprint": src_fp,
            "source_tables_json": src_tables,
            "local_patterns": local_pats,
            "local_fingerprint": local_fp,
        }
        if extra:
            fingerprint["__extra__"] = dict(extra)
        stored = rc.put(cache_key, identity.get("sql") or "", fingerprint,
                        output_path, int(row_count or 0),
                        int(column_count or 0),
                        ttl_seconds=_ttl_seconds())
        if stored:
            logger.info(
                "[dataset-cache] STORED key=%s rows=%d tables=%d "
                "fingerprinted=%d", cache_key[:16], row_count,
                len(identity.get("tables") or []), len(src_tables))
        return bool(stored)
    except Exception as exc:
        logger.debug("[dataset-cache] store failed (ignored): %s", exc)
        return False


def age_of(entry) -> float:
    """Seconds since the entry was stored."""
    try:
        return max(0.0, time.time() - float(getattr(entry, "created_at", 0.0)))
    except Exception:                             # pragma: no cover
        return 0.0


def _unverifiable_window() -> int:
    """``result_cache.serve_unverifiable_seconds`` -- 0 (default) = never.

    The knob is DECLARED in ``core.config._DEFAULTS``; a guard on an
    undeclared key is vacuous.
    """
    try:
        from core.config import get_section
        v = (get_section("result_cache") or {}).get(
            "serve_unverifiable_seconds", 0)
        return max(0, int(v or 0))
    except Exception:                             # pragma: no cover
        return 0


# ── An RLS predicate that reads ANOTHER TABLE ───────────────────────────────
#
# 2026-09-07.  MEASURED, NOT HYPOTHESISED.  The rewriter inlines a row
# policy's ``filter_sql`` VERBATIM (``rewriter.py``: ``rendered =
# substitute_vars(tpl, user_ctx)`` -> ``WHERE ({rendered})``), and
# ``substitute_vars`` renders ``${user.*}`` as a quoted LITERAL.  So for a
# scalar predicate the post-RLS SQL captures the whole policy, and a policy
# edit moves the key.  For a SUBQUERY predicate it does not:
#
#     filter_sql = "region IN (SELECT r FROM allowed WHERE u = ${user.username})"
#
# rewrites to
#
#     SELECT id, region FROM (SELECT * FROM trades WHERE (region IN
#       (SELECT r FROM allowed WHERE u = 'alice'))) AS trades
#
# and the entitlement table ``allowed`` appears in NEITHER of the two
# things this gate verifies: ``identity["tables"]`` (the report's own
# source tables, which is what ``check_cache_entry_staleness_multi``
# fingerprints) nor ``local_paths_in_sql`` (which finds file literals, and
# ``allowed`` is a name).  DELETE alice's row from ``allowed`` and the
# rewrite is byte-identical -- measured: the same key, to the character --
# so the gate serves her the rows she was just un-entitled to, for as long
# as the TTL allows (``dataset_path_ttl_seconds``, else ResultCache's
# 3600s default).  Revocation would not take effect until then.
#
# THE FIX IS A REFUSAL, and it is the SAME refusal the aggregate cache
# already makes for the same shape: ``agg_cache._predicate_serve_form``
# raises ``_RlsCubeIneligible`` on ``region IN (SELECT ...)`` and
# ``_compute_security_dimensions`` forces the cube open.  A cache whose
# freshness claim cannot cover a predicate must not serve that predicate's
# results -- a cap that costs an execution, never a gate that ships stale
# entitlements.
#
# It OVER-refuses: one subquery policy anywhere in the deployment disables
# result caching for every report, because "which policies apply to THIS
# query" is knowledge the rewriter has and this gate does not, and buying
# it would mean resolving policies a second time (a decision made twice).
# Over-refusing costs an execution the product was making yesterday; under-
# refusing serves an unentitled row.  The asymmetry decides it.

_POLICY_SUBQUERY_RE = re.compile(r"\(\s*SELECT\b", re.IGNORECASE)

#: Memo for :func:`policies_are_cacheable`.  Keyed on the STORE it scanned
#: and the in-process policy version, AND bounded by a TTL, because that
#: counter is per-pod: a sibling pod's policy edit is invisible to it.  The
#: TTL is the resolver's own ``row_security.cache_resolver_seconds``
#: (default 30s), so this inherits exactly the propagation bound the
#: row-security layer already declares rather than inventing a second one.
#:
#: 2026-09-26 -- the store is part of the key.  Keyed on the version alone,
#: a verdict read from one handle was served for the next handle asked
#: (measured in the suite: a test whose fake could not answer passed
#: whenever a neighbour had warmed this memo in the previous 30 s, and
#: failed cold).  ``tests/conftest.py`` empties it before every test.
_policy_scan_memo: Dict[str, Any] = {"key": None, "at": 0.0,
                                     "verdict": (True, "")}


def _policy_scan_ttl() -> float:
    try:
        from core.config import get_section
        return float((get_section("row_security") or {}).get(
            "cache_resolver_seconds", 30) or 30)
    except Exception:                             # pragma: no cover
        return 30.0


def policies_are_cacheable(db_manager) -> Tuple[bool, str]:
    """``(ok, reason)`` -- may a result under the current policy set be cached?

    ``False`` when ANY enabled row policy's ``filter_sql`` or column
    policy's ``mask_expr`` contains a subquery, i.e. reads a table this
    gate does not fingerprint.  See the block comment above for the
    measurement and for why the refusal is deliberately coarse.

    STRICT: an unreadable policy store returns ``False``.  "Could not read
    the policies" is not "there are no policies" -- that conflation is the
    one this codebase keeps paying for.
    """
    try:
        from core.row_security.api import _is_enabled as _rs_is_enabled
        if not _rs_is_enabled():
            # No rewrite happens, so there is no predicate to be unable to
            # verify.  Costs no DB read in the common deployment.
            return True, ""
    except Exception as exc:
        return False, f"row-security state unreadable: {exc}"
    # 2026-09-26 (F0: row security ON by default) -- ONE reading of the
    # policy set.  ``core.row_security.cache_scope`` already answers "is
    # there any enabled policy at all?" for every cache, memoised per store.
    # An EMPTY set holds no subquery, so the scan below would read two
    # tables to learn what that state already says -- the same decision
    # made twice, and with the flag on for every deployment it was a DB
    # round trip per cache consult in the commonest one.  An UNREADABLE
    # set is refused here on the scan's own rule: unknown is unsafe.  This
    # is also the seam a test declares with ``rls_on_no_policies`` /
    # ``rls_on_with_policies`` (tests/conftest.py).
    try:
        from core.row_security.cache_scope import policy_set_state
        state = policy_set_state(db_manager)
    except Exception as exc:
        return False, f"policy set unreadable: {exc}"
    if not state.enabled:
        return True, ""
    if not state.readable:
        return False, ("policy set unreadable: the row-security store could "
                       "not be read")
    if state.empty:
        return True, ""
    try:
        from core.row_security.api import current_policy_version
        version = current_policy_version()
    except Exception:
        version = None
    now = time.time()
    memo = _policy_scan_memo
    memo_key = (id(db_manager), version)
    if (memo["key"] == memo_key
            and (now - float(memo["at"] or 0.0)) < _policy_scan_ttl()):
        return memo["verdict"]
    verdict = _scan_policies_for_subqueries(db_manager)
    _policy_scan_memo.update({"key": memo_key, "at": now, "verdict": verdict})
    return verdict


def _scan_policies_for_subqueries(db_manager) -> Tuple[bool, str]:
    """The uncached scan.  One query over two small policy tables."""
    if db_manager is None:
        return False, "no database handle to read the policy set"
    try:
        from core.config_active import active_clause
        from core.db.models import ColumnPolicy, RowLevelPolicy
        with db_manager.get_session(read_only=True) as session:
            # a switched-off (deleted, 2026-10-30) policy applies to nobody
            for pol in session.query(RowLevelPolicy).filter(
                    RowLevelPolicy.enabled.is_(True), active_clause(RowLevelPolicy)).all():
                if _POLICY_SUBQUERY_RE.search(pol.filter_sql or ""):
                    return False, (
                        f"row policy {pol.id} ({pol.name!r}) filters on a "
                        f"SUBQUERY, which reads a table this cache does not "
                        f"fingerprint")
            for pol in session.query(ColumnPolicy).filter(
                    ColumnPolicy.enabled.is_(True), active_clause(ColumnPolicy)).all():
                if _POLICY_SUBQUERY_RE.search(pol.mask_expr or ""):
                    return False, (
                        f"column policy {pol.id} ({pol.name!r}) masks with a "
                        f"SUBQUERY, which reads a table this cache does not "
                        f"fingerprint")
    except Exception as exc:
        # UNKNOWN = UNSAFE.
        return False, f"policy set unreadable: {exc}"
    return True, ""


def _skip_patterns() -> List[str]:
    try:
        from core.config import get_section
        return list((get_section("result_cache") or {}).get(
            "skip_patterns") or [])
    except Exception:                             # pragma: no cover
        return []
