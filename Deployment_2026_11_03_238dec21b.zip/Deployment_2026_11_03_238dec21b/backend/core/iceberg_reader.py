"""
Iceberg table reader for S3.

Reads Apache Iceberg v1/v2 table metadata stored on S3 to discover the
active set of Parquet data files for a given table snapshot.

Flow:
  1. Scan S3 prefix for directories that contain a metadata/ subfolder
     with *.metadata.json files → those are Iceberg tables.
  2. Read the latest metadata.json to get current-snapshot-id.
  3. Follow the manifest-list (Avro) → manifest files (Avro) → data file paths.
  4. Return S3 keys for all ADDED/EXISTING Parquet data files.

Partition pruning (enterprise feature):
  Pass partition_filters=[{"col":"business_date","op":"equals","val":"2024-01-15"}]
  to get_iceberg_data_files().  The reader decodes per-manifest partition bounds
  from the Avro manifest-list and skips manifests (and their data files) that
  cannot possibly match the filter — dramatically reducing S3 API calls and
  latency for large tables.

Supported partition bound types:  string, date, int, long, float, double,
  timestamp (µs since epoch).

Requires: fastavro (for Avro manifest reading)
"""

from __future__ import annotations

import io
from core.table_prefix import prefix_matches
import json
import logging
import os
import struct
import threading
import time as _time
from datetime import date, datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ── SCAN-STRATEGY (2026-06-01) ───────────────────────────────────────────────
# Centralised file-ordering helper.  Replaces the BF-535 hard-coded
# smallest-first sort with a strategy-driven order.  Implementation lives in
# core.scan_strategy; this thin wrapper keeps iceberg_reader free of an
# import-time dependency on the strategy module (lazy import + safe degrade
# to manifest order on any error).

# 2026-06-04 user request — per-WHERE-clause pruning breakdown.
# Operator → file-level pruning support.  Used by the diagnostic to
# explain WHY a query scanned N files: each filter is tagged with
# whether the iceberg pruner can act on it at all.
#
#   supported   — pruner uses manifest bounds / column-stats supplement
#                 to drop files; the filter actively reduces the scan.
#   weak        — only fires in narrow cases (e.g. NOT IN where
#                 file.lo == file.hi); usually passes files through.
#   unsupported — no file-level prune logic; runs in DuckDB row-level
#                 ONLY.  Example: ``<>`` and ``NOT LIKE``.
_FILTER_SUPPORT = {
    "equals":      ("supported",   "manifest min/max bounds"),
    "in":          ("supported",   "manifest bounds + IN-list intersect"),
    "ne":          ("weak",        "fires when file.lo == file.hi AND that single value == the filter literal"),
    "not_equals":  ("weak",        "fires when file.lo == file.hi AND that single value == the filter literal"),
    "lt":          ("supported",   "manifest upper-bound check"),
    "le":          ("supported",   "manifest upper-bound check"),
    "gt":          ("supported",   "manifest lower-bound check"),
    "ge":          ("supported",   "manifest lower-bound check"),
    "between":     ("supported",   "manifest [lo,hi] intersect"),
    "not_between": ("supported",   "fires when file's bounds entirely INSIDE [lo,hi]"),
    "not_in":      ("weak",        "fires ONLY when file.lo == file.hi and that value is in the exclude list; most files have lo!=hi"),
    "nin":         ("weak",        "fires ONLY when file.lo == file.hi and that value is in the exclude list; most files have lo!=hi"),
    "like_prefix": ("supported",   "prefix-range decomposition into >= / <"),
    "starts_with": ("supported",   "prefix-range decomposition into >= / <"),
    "is_null":     ("supported",   "manifest null_count check"),
    "is_not_null": ("supported",   "manifest null_count vs record_count"),
    "not_like":    ("supported",   "prefix-range prune when file's [lo,hi] is fully inside [PREFIX, PREFIX+1)"),
    "nlike":       ("supported",   "prefix-range prune when file's [lo,hi] is fully inside [PREFIX, PREFIX+1)"),
}


def _record_query_observations() -> bool:
    """Does a query record what its scan decided?  Default TRUE.

    `query_pruning_history` is the ONLY input `brain_cost_model` and
    `brain_skew_detector` have.  Until 2026-09-06 the write site sat
    behind a short-circuit no query could pass, so the table held zero
    rows and both modules were permanently cold.

    ON by default because the measured cost is ~0.6 ms of CPU on the
    request thread and NO S3 and NO synchronous DB work: the DB insert
    is a `queue.put_nowait` drained by the `pruning_history_writer`
    daemon (core/query_diagnostic_store.py), and the queue is bounded
    at 1000 so a stalled writer drops rows rather than blocking a query.
    Set false to silence the telemetry entirely -- the cost of doing so
    is that routing stays threshold-based forever.
    """
    try:
        from core.config import get as _g
        return bool(_g("iceberg", "record_query_observations", True))
    except Exception:
        return True


def _persist_scan_plan_on_query() -> bool:
    """Does a query durably persist its unified scan plan?  Default FALSE.

    A SELECT + INSERT/UPDATE + COMMIT per iceberg table per query.
    Measured at query cadence on local sqlite: p50 3.1 ms, max 30 ms --
    against 14 us for everything else the observation does.  It feeds
    the /api/admin/queries/scan-plan screen, NOT the routing brain, and
    that screen reads the in-memory context first, so with this off an
    operator still gets the plan for a query that just ran.  What is
    lost is the plan surviving a pod restart.

    Flip it true when the deployment wants durable scan plans and can
    pay a synchronous DB write inside the query path.
    """
    try:
        from core.config import get as _g
        return bool(_g("iceberg", "persist_scan_plan_on_query", False))
    except Exception:
        return False


def _lazy_freshness_on_query() -> bool:
    """Does a query trigger the lazy brain-freshness delta scan?

    Default FALSE, and this one is NOT a taste preference.  Unlike the
    observation above, `brain_freshness.ensure_fresh` does real work ON
    THE REQUEST THREAD before it decides whether to dispatch anything:
    it builds an S3 client and calls `get_iceberg_snapshot_id_only`,
    then runs 3 DB queries.  Measured on the wire rig that is +1 S3 GET
    on EVERY iceberg query (the two iceberg journeys go 6 -> 7 and
    7 -> 8 round trips) -- spent re-learning a snapshot id this very
    function already resolved into `current_snapshot_id` above.
    Paying for an answer we are holding is not a cost worth defaulting
    on.  The watcher (`iceberg_manifest_watcher`) and the cron daemon
    already keep coverage fresh and are unaffected by this key.

    Flip it true when the deployment has no watcher and wants queries
    to be the refresh trigger; the in-flight set in brain_freshness
    dedupes a thundering herd to one scan.
    """
    try:
        from core.config import get as _g
        return bool(_g("iceberg", "lazy_freshness_on_query", False))
    except Exception:
        return False


def _classify_filter_support(operator: str) -> Tuple[str, str]:
    """Return (level, reason) for a filter operator string.
    level in {'supported','weak','unsupported','unknown'}.

    Phase 147 — operator-only legacy wrapper.  Kept for the per-WHERE-
    clause breakdown payload that record_pruning writes (downstream
    diagnose UI reads these strings directly).  The richer column-aware
    classifier is at ``core.pruning_support.PruneSupportClassifier`` —
    callers that hold the table spec should prefer it.
    """
    return _FILTER_SUPPORT.get(operator.lower() if operator else "",
                                ("unknown", f"operator {operator!r} not in classifier table"))


def _classify_filter_with_spec(
    filter_dict: Dict[str, Any],
    metadata: Optional[Dict[str, Any]] = None,
    *,
    supplement_columns: Optional[Set[str]] = None,
) -> Tuple[str, str]:
    """Phase 147 — column-aware classification when metadata is in scope.

    Falls back to the operator-only legacy table on any error so the
    record_pruning payload always carries (support, reason) — never
    raises.
    """
    try:
        from core.pruning_support import (
            PruneSupportClassifier,
            build_table_spec_from_iceberg_metadata,
        )
        spec = (
            build_table_spec_from_iceberg_metadata(
                metadata or {}, supplement_columns=supplement_columns,
            )
            if metadata is not None
            else None
        )
        r = PruneSupportClassifier.get_default().classify(filter_dict, spec)
        return r.support, r.reason
    except Exception:
        op_raw = str(filter_dict.get("op") or filter_dict.get("operator") or "")
        return _classify_filter_support(op_raw)


def _apply_scan_order(files: List[Dict[str, Any]],
                       file_order: Optional[str]) -> List[Dict[str, Any]]:
    """Order *files* per *file_order*.

    Resolution priority (2026-06-03 audit closeout — full ScanStrategist
    end-to-end wiring):
      1. Explicit ``file_order`` kwarg
      2. Thread-local set by the dispatcher via
         ``scan_strategy.set_current_file_order(scan_plan.file_order)``
         — this is how per-workload routing (feed_gen=largest_first,
         BQB=smallest_first) actually reaches the deep modules without
         threading a new kwarg through 4 layers.
      3. ``scan_strategy.default_file_order`` config (admin default)
      4. ``smallest_first`` (BF-535 — restored 2026-06-03)
    Any failure degrades to the input order silently.
    """
    if not files:
        return files
    try:
        from core.scan_strategy import (
            order_files as _order_files,
            FileOrder as _FO,
            get_current_file_order as _get_tl_order,
        )
        if file_order is None:
            # Step 2 — thread-local from dispatcher's scan_plan.
            tl_order = _get_tl_order()
            if tl_order is not None:
                file_order = tl_order.value
        if file_order is None:
            # Step 3 — admin-controlled config.
            try:
                from core.config import get_section as _gs
                file_order = ((_gs("scan_strategy") or {}).get(
                    "default_file_order") or "smallest_first")
            except Exception:
                file_order = "smallest_first"
        try:
            fo = _FO(str(file_order).lower())
        except ValueError:
            fo = _FO.SMALLEST_FIRST
        return _order_files(files, fo)
    except Exception:
        return files


# ── Metadata key cache ───────────────────────────────────────────────────────
# Avoids re-scanning thousands of metadata files on every query.
# Key: "bucket/meta_prefix" → Value: {"key": str, "ts": float}
# Stale-while-revalidate: when TTL expires, return stale result instantly
# and trigger async background refresh.  User NEVER waits for a full scan.
from collections import OrderedDict as _OrderedDict  # noqa: E402

_metadata_key_cache: "_OrderedDict[str, Dict[str, Any]]" = _OrderedDict()
_metadata_key_cache_lock = threading.Lock()
# Phase 161 (2026-07-02) prod audit fix -- was unbounded.  Grows one
# entry per distinct table forever; fleets with 5000+ iceberg tables
# would accrue ~250 KB per entry with no eviction ever.  LRU with
# cap so an idle table drops when we hit the ceiling.  Env var
# ``QS_METADATA_KEY_CACHE_MAX`` overrides (default 5000, negative or
# zero clamped to default).
def _resolve_metadata_key_cache_darn() -> int:
    try:
        v = int(os.environ.get("QS_METADATA_KEY_CACHE_MAX", "") or 0)
    except (TypeError, ValueError):
        v = 0
    return v if v > 0 else 5000


_METADATA_KEY_CACHE_MAX_ENTRIES = _resolve_metadata_key_cache_darn()


def _bounded_metadata_key_cache_put(cache_id: str, value: Dict[str, Any]) -> None:
    """Insert into ``_metadata_key_cache`` with LRU eviction when full.
    Assumes caller already holds ``_metadata_key_cache_lock``.

    Phase 161 -- LRU touch on rewrite so the eviction order tracks
    recency of access, not order of first insertion.
    """
    if len(_metadata_key_cache) >= _METADATA_KEY_CACHE_MAX_ENTRIES \
            and cache_id not in _metadata_key_cache:
        try:
            _metadata_key_cache.popitem(last=False)  # oldest first
        except KeyError:                                             # pragma: no cover
            pass
    _metadata_key_cache[cache_id] = value
    _metadata_key_cache.move_to_end(cache_id)
_METADATA_CACHE_TTL = 60  # seconds, overridden by config iceberg.metadata_cache_ttl_seconds
_METADATA_STALE_TTL = 3600  # serve stale for up to 1 hour while background refresh runs
# BF-511 (2026-05-28): Hard ceiling on how long a row in IcebergMetadataKeyCache
# may serve without S3 corroboration.  Below this age + verify success → safe to
# return.  Above this age OR verify failure → refuse, fall through to a fresh
# resolution that reads version-hint.text directly.  Caps blast radius of the
# previously-unbounded DB cache when version-hint.text is unavailable (V1
# tables) or temporarily broken.  Configurable via
# ``iceberg.metadata_key_db_cache_max_age_seconds`` — set 0 to disable the
# DB cache layer entirely (forces version-hint / scan on every miss).
_METADATA_DB_CACHE_MAX_AGE_SECONDS_DEFAULT = 3600  # 1 hour
_METADATA_COUNT_WARN_THRESHOLD = 5000  # warn ops when metadata file count exceeds this
# Phase 139 audit-fix Gap 9: raised from 100 → 500 (covers ~500K objects). Now
# configurable via iceberg.metadata_scan_max_pages so admins can raise it for
# very actively-written tables. Cap prevents pathological scans of buckets
# with millions of metadata files.
_METADATA_SCAN_MAX_PAGES_DEFAULT = 500
def _metadata_scan_max_pages() -> int:
    try:
        from core.config import get as _cfg_get
        return int(_cfg_get("iceberg", "metadata_scan_max_pages",
                            _METADATA_SCAN_MAX_PAGES_DEFAULT))
    except Exception:
        return _METADATA_SCAN_MAX_PAGES_DEFAULT
_METADATA_SCAN_MAX_PAGES = _METADATA_SCAN_MAX_PAGES_DEFAULT  # back-compat


def _should_cross_check_newest_metadata() -> bool:
    """Opt-in: when True, the version-hint.text resolve ALSO scans the metadata
    prefix for a NEWER ``*.metadata.json`` and prefers it if the hint is stale.

    2026-07-15 STALE-SNAPSHOT GUARD (adversarial audit): ``version-hint.text``
    is a HadoopCatalog optimisation.  For catalog-managed tables (Glue / Hive /
    Nessie / REST — the typical Starburst setup) a writer can advance the
    snapshot WITHOUT atomically bumping ``version-hint.text``, pinning QS to a
    STALE pre-compaction metadata.json (MORE small files, FEWER rows) while the
    catalog engine follows the newer snapshot — the classic "QS 1640 files /
    77.8M rows vs Starburst 1088 / 210M" split.  Default OFF (the fast path is
    correct for HadoopCatalog tables that maintain the hint); enable for
    catalog-managed tables whose writer doesn't keep version-hint.text current.
    """
    try:
        from core.config import get as _cfg_get
        return bool(_cfg_get("iceberg", "cross_check_newest_metadata", False))
    except Exception:
        return False


def _newest_metadata_json_by_scan(s3_client, bucket: str, meta_prefix: str):
    """Return the newest ``*.metadata.json`` object (by LastModified) under
    ``meta_prefix`` via a capped LIST, or None.  Used by the version-hint
    stale-check; raises are the caller's to swallow."""
    _max_pages = _metadata_scan_max_pages()
    best = None
    page_count = 0
    capped = False
    paginator = s3_client.get_paginator("list_objects_v2")
    for page in _counted_pages(paginator.paginate(Bucket=bucket, Prefix=meta_prefix)):
        page_count += 1
        for obj in page.get("Contents", []):
            if obj["Key"].endswith(".metadata.json"):
                if best is None or obj["LastModified"] > best["LastModified"]:
                    best = obj
        if page_count >= _max_pages:
            capped = True
            break
    if capped:
        # 2026-08-20 DATA-LOSS FIX (disclosure): this cap used to fire with
        # NO log (the Layer-4 sibling scan warns) — and because S3 LISTs
        # lexicographically, the cut tail is exactly the NEWEST
        # ``NNNNN-*.metadata.json`` keys, so "newest by scan" can silently
        # be an OLDER metadata.json and newly written files stay excluded.
        # ``scan_capped`` on the result lets the adaptive-freshness caller
        # avoid stamping ``confirmed_fresh`` (which would 10x-throttle
        # future re-scans) off a scan that provably did not see the tail.
        logger.warning(
            "ICEBERG NEWEST-METADATA SCAN CAPPED: s3://%s/%s stopped at "
            "cap=%d pages — the un-scanned tail holds the NEWEST metadata "
            "keys, so this 'newest' result may be an OLDER metadata.json "
            "(newly committed files would be excluded).  Run "
            "'expire_snapshots' to shrink metadata/ OR raise "
            "iceberg.metadata_scan_max_pages in config.json.",
            bucket, meta_prefix, _max_pages,
        )
        if best is not None:
            best = dict(best)
            best["scan_capped"] = True
    return best


# ── 2026-07-15 ADAPTIVE FRESHNESS (audit Finding #2) ─────────────────────────
# The version-hint cross-check above used to be a default-OFF config flag that
# ONLY ran inside the Layer-3 version-hint resolve — never on cache hits.  A
# writer that advances the snapshot WITHOUT bumping version-hint.text pins QS
# to a stale pre-compaction metadata.json ("QS ~4000 files across two tables
# whose CURRENT snapshots have 1605 + 1200"), and every upper cache layer
# (metadata-key L1/L2/L2.5, Phase-156 memo, BF-296 snapshot-content cache)
# agrees because they are all keyed on the stale resolved snapshot-id.
#
# Adaptive Freshness makes the cross-check a DECISION, not a flag: the capped
# newest-by-scan LIST fires only when a trigger says the resolved pointer is
# suspect —
#   1. ANOMALY      — the Scan Ledger recently returned over_count/under_count
#                     for this table (per-table flag, DB-backed).
#   2. STALE CADENCE— the resolved snapshot's timestamp-ms is much older than
#                     the table's observed write cadence (median delta of the
#                     snapshot-log already in the SAME metadata.json — free).
#   3. HINT LIED    — the resolved pointer has EVER disagreed with newest-by-
#                     scan for this table (per-table count, DB-backed) →
#                     permanent cross-check for that table.
#   4. CONFIG FORCE — iceberg.cross_check_newest_metadata=true (unchanged
#                     global force-on).
# SAFETY CONTRACT: a newer snapshot only ever ADDS or compacts committed data,
# so preferring the newest metadata.json is ALWAYS correctness-safe; the only
# cost is bounded S3 LIST latency (capped pages + per-table TTL throttle).
# Healthy tables with no trigger pay ZERO extra I/O — the fast path is
# byte-identical to before.  Every branch is fail-safe: any error keeps the
# already-resolved (fast-path) result; we NEVER adopt an OLDER snapshot.

_ADAPTIVE_FRESHNESS_SCAN_TTL_DEFAULT = 60            # s between LISTs per table
_ADAPTIVE_FRESHNESS_CADENCE_MULTIPLIER_DEFAULT = 4.0  # stale when age > 4x median
_ADAPTIVE_FRESHNESS_CADENCE_FLOOR_SECONDS_DEFAULT = 600.0  # never "stale" under 10 min
_ADAPTIVE_FRESHNESS_ANOMALY_WINDOW_SECONDS_DEFAULT = 86400.0  # anomaly arms 24h
_ADAPTIVE_FRESHNESS_RELIABILITY_DB_TTL = 300         # s between DB re-reads per table

_freshness_lock = threading.Lock()
# Per-(bucket,table_prefix) reliability cache:
#   {"hint_lied_count": int, "last_anomaly_ts": epoch_float, "_db_checked_ts": epoch}
# Backed by the iceberg_freshness_reliability DB table when a db_manager is
# reachable (cross-pod, restart-survival); degrades to per-pod in-process
# state when the DB layer is unavailable.
_freshness_reliability: Dict[str, Dict[str, Any]] = {}
# Per-table newest-by-scan throttle so a permanently cross-checked table does
# NOT pay a LIST on every query:
#   {"ts": epoch, "newest_key": str|None, "confirmed_fresh": bool}
_freshness_scan_cache: Dict[str, Dict[str, Any]] = {}


def _adaptive_freshness_cfg(key: str, default):
    """Config accessor for iceberg.adaptive_freshness_* knobs (fail-safe)."""
    try:
        from core.config import get as _cfg_get
        return _cfg_get("iceberg", key, default)
    except Exception:
        return default


def _adaptive_freshness_enabled() -> bool:
    """Adaptive Freshness is ON by default — it costs nothing for healthy
    tables (pure in-memory decision) and only LISTs on a trigger."""
    try:
        return bool(_adaptive_freshness_cfg("adaptive_freshness_enabled", True))
    except Exception:
        return True


def _freshness_table_id(bucket: str, table_prefix: str) -> str:
    return f"{bucket}/{(table_prefix or '').rstrip('/')}"


def _table_prefix_from_meta_prefix(meta_prefix: str) -> str:
    """``bucket-relative`` table prefix from a metadata prefix
    (``analytics/fact/metadata/`` → ``analytics/fact``)."""
    p = (meta_prefix or "").rstrip("/")
    if p.endswith("/metadata"):
        p = p[: -len("/metadata")]
    return p


def _metadata_last_updated_ms(md) -> Optional[int]:
    """Commit-time ordering key for a metadata.json body.  Prefers
    ``last-updated-ms``; falls back to the max snapshot timestamp-ms.
    None when neither is derivable (caller treats as 'cannot compare')."""
    try:
        v = (md or {}).get("last-updated-ms")
        if v is not None:
            return int(v)
    except (TypeError, ValueError):
        pass
    try:
        ts = [int(s.get("timestamp-ms") or 0)
              for s in ((md or {}).get("snapshots") or [])
              if isinstance(s, dict)]
        ts = [t for t in ts if t > 0]
        return max(ts) if ts else None
    except Exception:
        return None


def _freshness_get_record(bucket: str, table_prefix: str,
                          db_manager=None) -> Dict[str, Any]:
    """Return the per-table freshness-reliability record
    ``{"hint_lied_count": int, "last_anomaly_ts": epoch_float}``.

    In-process cache first; DB re-read at most every
    ``_ADAPTIVE_FRESHNESS_RELIABILITY_DB_TTL`` seconds per table so the
    hot query path never pays more than a dict lookup.  Fail-safe: any
    DB error degrades to the in-process record (zeros on first sight)."""
    tid = _freshness_table_id(bucket, table_prefix)
    now = _time.time()
    with _freshness_lock:
        rec = _freshness_reliability.get(tid)
        if rec is not None and (now - float(rec.get("_db_checked_ts") or 0)
                                ) < _ADAPTIVE_FRESHNESS_RELIABILITY_DB_TTL:
            return dict(rec)
    db_rec = None
    try:
        dbm = db_manager
        if dbm is None:
            from core.database import get_db_manager
            dbm = get_db_manager()
        if dbm is not None:
            db_rec = dbm.iceberg_freshness_get(
                bucket, (table_prefix or "").rstrip("/"))
    except Exception as exc:
        logger.debug("[adaptive-freshness] reliability DB read failed "
                     "(fail-safe, using in-process record): %s", exc)
    with _freshness_lock:
        rec = _freshness_reliability.get(tid) or {
            "hint_lied_count": 0, "last_anomaly_ts": 0.0,
        }
        if db_rec:
            try:
                rec["hint_lied_count"] = max(
                    int(rec.get("hint_lied_count") or 0),
                    int(db_rec.get("hint_lied_count") or 0))
                rec["last_anomaly_ts"] = max(
                    float(rec.get("last_anomaly_ts") or 0.0),
                    float(db_rec.get("last_anomaly_ts") or 0.0))
            except (TypeError, ValueError):
                pass
        rec["_db_checked_ts"] = now
        _freshness_reliability[tid] = rec
        return dict(rec)


def _freshness_record_hint_lied(bucket: str, table_prefix: str,
                                db_manager=None) -> None:
    """The resolved pointer disagreed with newest-by-scan: bump the
    per-table lie counter (in-process + DB).  Once >0 the table is
    cross-checked PERMANENTLY.  Never raises."""
    try:
        tid = _freshness_table_id(bucket, table_prefix)
        with _freshness_lock:
            rec = _freshness_reliability.setdefault(tid, {
                "hint_lied_count": 0, "last_anomaly_ts": 0.0,
            })
            rec["hint_lied_count"] = int(rec.get("hint_lied_count") or 0) + 1
        try:
            dbm = db_manager
            if dbm is None:
                from core.database import get_db_manager
                dbm = get_db_manager()
            if dbm is not None:
                dbm.iceberg_freshness_record(
                    bucket, (table_prefix or "").rstrip("/"), hint_lied=True)
        except Exception as exc:
            logger.debug("[adaptive-freshness] hint-lied DB persist failed "
                         "(in-process record still set): %s", exc)
    except Exception as exc:                                 # pragma: no cover
        logger.debug("[adaptive-freshness] hint-lied record failed: %s", exc)


def _freshness_record_anomaly(bucket: str, table_prefix: str,
                              db_manager=None) -> None:
    """Scan Ledger flagged over_count/under_count for this table: arm the
    per-table anomaly flag so the NEXT queries cross-check freshness.
    Never raises."""
    try:
        tid = _freshness_table_id(bucket, table_prefix)
        with _freshness_lock:
            rec = _freshness_reliability.setdefault(tid, {
                "hint_lied_count": 0, "last_anomaly_ts": 0.0,
            })
            rec["last_anomaly_ts"] = _time.time()
        try:
            dbm = db_manager
            if dbm is None:
                from core.database import get_db_manager
                dbm = get_db_manager()
            if dbm is not None:
                dbm.iceberg_freshness_record(
                    bucket, (table_prefix or "").rstrip("/"), anomaly=True)
        except Exception as exc:
            logger.debug("[adaptive-freshness] anomaly DB persist failed "
                         "(in-process record still set): %s", exc)
    except Exception as exc:                                 # pragma: no cover
        logger.debug("[adaptive-freshness] anomaly record failed: %s", exc)


def _reset_freshness_state_for_tests() -> None:
    """Test hook — clears the in-process reliability + scan-throttle dicts.

    Includes the watcher-certificate cache: a certificate leaking between
    tests would let one test's healthy watcher silence another test's
    expected LIST, which is exactly the kind of order-dependent green that
    hides a real defect.
    """
    with _freshness_lock:
        _freshness_reliability.clear()
        _freshness_scan_cache.clear()
        _WATCHER_CERT_CACHE.clear()


def _should_refresh_snapshot(
    *,
    resolved_snapshot_ts_ms: Optional[int],
    snapshot_log: Optional[List[Dict[str, Any]]],
    now_ms: Optional[int] = None,
    anomaly_seen: bool = False,
    hint_lied_count: int = 0,
    force_cross_check: bool = False,
    cadence_multiplier: float = _ADAPTIVE_FRESHNESS_CADENCE_MULTIPLIER_DEFAULT,
    cadence_floor_seconds: float = _ADAPTIVE_FRESHNESS_CADENCE_FLOOR_SECONDS_DEFAULT,
    min_cadence_samples: int = 3,
) -> Tuple[bool, str]:
    """PURE trigger decision for Adaptive Freshness — no I/O, no side
    effects, unit-testable without S3 mocking.

    Returns ``(refresh, reason)``; reason ∈ {"config_force",
    "hint_lied_before(...)", "scan_ledger_anomaly", "stale_by_cadence(...)",
    "healthy"}.  ``healthy`` means the caller must pay ZERO extra I/O.

    Stale-by-cadence: the median delta between the last ~10 snapshot-log
    timestamps is the table's observed write cadence.  When
    ``now - resolved_ts`` exceeds ``max(multiplier x median, floor)`` the
    resolved pointer is probably pinned behind a newer commit.  Needs at
    least ``min_cadence_samples`` deltas — single-snapshot / young tables
    never trigger.  All arithmetic is defensive; garbage input → no trigger.
    """
    if force_cross_check:
        return True, "config_force"
    try:
        if int(hint_lied_count or 0) > 0:
            return True, f"hint_lied_before(count={int(hint_lied_count)})"
    except (TypeError, ValueError):
        pass
    if anomaly_seen:
        return True, "scan_ledger_anomaly"
    try:
        if resolved_snapshot_ts_ms and snapshot_log:
            ts_list = []
            for entry in snapshot_log:
                try:
                    t = int((entry or {}).get("timestamp-ms") or 0)
                except (TypeError, ValueError, AttributeError):
                    continue
                if t > 0:
                    ts_list.append(t)
            ts_list.sort()
            recent = ts_list[-10:]
            deltas = sorted(b - a for a, b in zip(recent, recent[1:]) if b > a)
            if len(deltas) >= max(1, int(min_cadence_samples)):
                mid = len(deltas) // 2
                median_ms = (float(deltas[mid]) if len(deltas) % 2 == 1
                             else (deltas[mid - 1] + deltas[mid]) / 2.0)
                _now = int(now_ms if now_ms is not None
                           else _time.time() * 1000)
                age_ms = _now - int(resolved_snapshot_ts_ms)
                threshold_ms = max(float(cadence_multiplier) * median_ms,
                                   float(cadence_floor_seconds) * 1000.0)
                if median_ms > 0 and age_ms > threshold_ms:
                    return True, (
                        f"stale_by_cadence(age_s={age_ms / 1000.0:.0f}, "
                        f"median_cadence_s={median_ms / 1000.0:.0f}, "
                        f"threshold_s={threshold_ms / 1000.0:.0f})")
    except Exception as _be_exc:
        # Cadence math must never break the fast path.
        note_best_effort("(True, f'stale_by_cadence(age_s={age_ms / 1000.0:.0f}, median_cad...", _be_exc,
                         logger=logger)
    return False, "healthy"


_WATCHER_CERT_CACHE: Dict[str, Any] = {}
_WATCHER_CERT_CACHE_TTL = 30.0


def _watcher_interval_seconds(default: float = 1800.0) -> float:
    """The watcher's own poll cadence, from the settings it declares.

    Read through the watcher module so there is ONE declaration of the
    default -- a second copy here would drift the moment an admin retunes
    the watcher, and the certificate's whole validity window is derived
    from this number.
    """
    try:
        from core.iceberg_manifest_watcher import get_setting as _ws
        v = float(_ws("iceberg_watcher.interval_seconds") or default)
        return v if v > 0 else default
    except Exception:
        return default


def _watcher_certificate_verdict(bucket: str, table_prefix: str,
                                 resolved_snapshot_id: Any,
                                 db_manager=None) -> Tuple[bool, str]:
    """Does the watcher PROVE this table's resolved pointer is newest?

    Returns ``(trusted, why)``.  ``why`` is always populated -- a refusal
    that cannot say why it refused is indistinguishable from a feature
    that was never wired up.

    Trusted only when ALL of these hold:
      * the trust knob is on (kill switch),
      * a certificate row exists for this (bucket, table_prefix),
      * its status is exactly ``ok`` -- an errored poll is not evidence,
      * it is younger than ``interval x grace`` -- so a stopped, crashed,
        disabled or simply-not-covering-this-table watcher ages out on its
        own within about one missed tick, with no flag to remember,
      * and the snapshot it observed EQUALS the pointer this query already
        resolved.  This is the load-bearing check: it is what makes the
        certificate a proof about THIS read rather than a general claim
        about the table.  If the watcher saw something newer, we disagree
        with it and must go look.

    Any exception -> (False, reason).  Failure costs a LIST, never an
    answer.
    """
    try:
        from core.config import get as _cfg
        if not bool(_cfg("iceberg", "watcher_certificate_trust", True)):
            return False, "trust_disabled_by_config"
    except Exception:
        pass                          # unreadable config -> knob default ON
    if resolved_snapshot_id is None:
        return False, "query_has_no_resolved_snapshot"
    tid = _freshness_table_id(bucket, table_prefix)
    now = _time.time()
    cert = None
    cached = None
    with _freshness_lock:
        cached = _WATCHER_CERT_CACHE.get(tid)
    if cached is not None and (now - float(cached[0] or 0)) < _WATCHER_CERT_CACHE_TTL:
        cert = cached[1]
    else:
        try:
            dbm = db_manager
            if dbm is None:
                from core.database import get_db_manager
                dbm = get_db_manager()
            cert = (dbm.iceberg_watcher_cert_get(
                bucket, (table_prefix or "").rstrip("/"))
                if dbm is not None else None)
        except Exception as exc:
            return False, f"cert_read_failed:{type(exc).__name__}"
        with _freshness_lock:
            _WATCHER_CERT_CACHE[tid] = (now, cert)
    if not cert:
        return False, "no_certificate(table_not_watched_or_never_polled)"
    if str(cert.get("status") or "") != "ok":
        return False, f"watcher_unhealthy(status={cert.get('status')})"
    ts = float(cert.get("checked_at_epoch") or 0.0)
    if ts <= 0:
        return False, "certificate_has_no_timestamp"
    try:
        from core.config import get as _cfg2
        grace = float(_cfg2("iceberg",
                            "watcher_certificate_grace_multiplier", 2.0) or 2.0)
    except Exception:
        grace = 2.0
    max_age = _watcher_interval_seconds() * max(1.0, grace)
    age = now - ts
    if age > max_age:
        return False, (f"certificate_stale(age={age:.0f}s > "
                       f"{max_age:.0f}s — watcher stopped or behind)")
    # 2026-10-07 -- a certificate is a confirmation made ``age`` seconds
    # ago; skipping the LIST on it answers from that confirmation.  Bounded
    # like every other unconfirmed serve (interval x grace was 3,600 s).
    if not _may_serve_unconfirmed_age(age):
        return False, (f"certificate_older_than_staleness_bound(age="
                       f"{age:.0f}s >= {_staleness_bound_now():.0f}s)")
    observed = cert.get("observed_snapshot_id")
    if observed is None:
        return False, "certificate_has_no_snapshot"
    if str(observed) != str(resolved_snapshot_id):
        return False, (f"snapshot_mismatch(watcher_saw={observed}, "
                       f"query_resolved={resolved_snapshot_id}) — something "
                       f"moved, must LIST")
    return True, f"watcher_confirmed_newest(age={age:.0f}s)"


def _adaptive_freshness_refresh(
    s3_client,
    bucket: str,
    table_prefix: str,
    meta_prefix: str,
    meta_key: str,
    metadata: dict,
    *,
    db_manager=None,
    _out_meta: Optional[dict] = None,
) -> Tuple[str, dict]:
    """Adaptive-Freshness runtime hook.  Called once per query right after
    the metadata pointer has been resolved and its body read — i.e. it sees
    the FINAL result of every cache layer (L1/L2/L2.5/L3/L4), which is
    exactly where the old flag-gated cross-check had a blind spot.

    Returns ``(meta_key, metadata)`` — either the caller's pair unchanged
    (fast path / no trigger / throttled / scan error) or a strictly NEWER
    pair.  NEVER raises; NEVER returns an older pair.  On adoption it also
    repoints the metadata-key caches and invalidates the poisoned
    snapshot-keyed upper caches (Phase-156 memo + BF-296 snapshot-content
    + BF-550 result cache) for the OLD snapshot so the stale pointer stops
    being served."""
    try:
        force_cc = _should_cross_check_newest_metadata()
        if not (_adaptive_freshness_enabled() or force_cc):
            return meta_key, metadata
        if not isinstance(metadata, dict) or not meta_key \
                or not isinstance(meta_key, str):
            return meta_key, metadata

        # ── Gather trigger signals (no S3 I/O) ───────────────────────────
        try:
            rec = _freshness_get_record(bucket, table_prefix,
                                        db_manager=db_manager)
        except Exception:
            rec = {}
        try:
            anomaly_window = float(_adaptive_freshness_cfg(
                "adaptive_freshness_anomaly_window_seconds",
                _ADAPTIVE_FRESHNESS_ANOMALY_WINDOW_SECONDS_DEFAULT))
        except (TypeError, ValueError):
            anomaly_window = _ADAPTIVE_FRESHNESS_ANOMALY_WINDOW_SECONDS_DEFAULT
        last_anom = float(rec.get("last_anomaly_ts") or 0.0)
        anomaly_seen = last_anom > 0 and (_time.time() - last_anom) < anomaly_window

        resolved_ts = None
        try:
            cur_sid = metadata.get("current-snapshot-id")
            for _s in metadata.get("snapshots") or []:
                if isinstance(_s, dict) and _s.get("snapshot-id") == cur_sid:
                    resolved_ts = _s.get("timestamp-ms")
                    break
            if resolved_ts is None:
                slog = metadata.get("snapshot-log") or []
                if slog and isinstance(slog[-1], dict):
                    resolved_ts = slog[-1].get("timestamp-ms")
        except Exception:
            resolved_ts = None

        decision, reason = _should_refresh_snapshot(
            resolved_snapshot_ts_ms=resolved_ts,
            snapshot_log=metadata.get("snapshot-log"),
            anomaly_seen=anomaly_seen,
            hint_lied_count=int(rec.get("hint_lied_count") or 0),
            force_cross_check=force_cc,
            cadence_multiplier=float(_adaptive_freshness_cfg(
                "adaptive_freshness_cadence_multiplier",
                _ADAPTIVE_FRESHNESS_CADENCE_MULTIPLIER_DEFAULT)),
            cadence_floor_seconds=float(_adaptive_freshness_cfg(
                "adaptive_freshness_cadence_floor_seconds",
                _ADAPTIVE_FRESHNESS_CADENCE_FLOOR_SECONDS_DEFAULT)),
        )

        # ── 2026-08-24: the watcher already answered this ────────────────
        # A SUSPICION can be satisfied by the watcher's published
        # certificate; EVIDENCE cannot.  ``config_force`` and
        # ``stale_by_cadence`` both mean "we have no reason to believe the
        # pointer is fresh" — and a recent certificate naming this exact
        # snapshot IS that reason.  ``hint_lied_before`` and
        # ``scan_ledger_anomaly`` are records of this table actually
        # misbehaving; no amount of healthy background polling refutes an
        # observed lie, so those always pay for the LIST.
        # Gate on the SIGNALS, never on ``reason``.  ``_should_refresh_snapshot``
        # returns the FIRST trigger that fires and ``force_cross_check`` is its
        # first line, so with ``cross_check_newest_metadata: true`` a table that
        # has actually lied reports ``reason == "config_force"`` and its
        # hint_lied evidence is invisible in the string.  Reading the summary
        # instead of the evidence let a certificate silence a known-lying table
        # (caught by test_evidence_of_lying_is_never_satisfied_by_a_certificate).
        _has_evidence = anomaly_seen or int(rec.get("hint_lied_count") or 0) > 0
        # An ALLOW-LIST of the triggers a certificate is known to answer, so a
        # trigger added later must be classified deliberately instead of
        # inheriting trust.  Both conditions are load-bearing: the allow-list
        # alone would admit a known-lying table (config_force masks the
        # evidence in the reason), and the evidence check alone would grant
        # trust to any future trigger by default — failing open on an
        # unrecognised spelling is the 2026-08-21 island bug.
        _suspicion_only = (reason == "config_force"
                           or reason.startswith("stale_by_cadence"))
        _cert_why = None
        if decision and _suspicion_only and not _has_evidence:
            _trusted, _cert_why = _watcher_certificate_verdict(
                bucket, table_prefix,
                (metadata or {}).get("current-snapshot-id"),
                db_manager=db_manager)
            if _trusted:
                decision = False
                reason = f"watcher_certificate({_cert_why})"
                logger.info(
                    "[adaptive-freshness] %s/%s: capped LIST SKIPPED — %s. "
                    "The watcher polls metadata/ on its own cadence and "
                    "published this observation; re-deriving it in the "
                    "query's foreground is the same LIST twice.",
                    bucket, table_prefix, _cert_why)
            else:
                # Say why we are about to pay for a LIST.  A silent refusal
                # is indistinguishable from a feature that was never wired.
                logger.info(
                    "[adaptive-freshness] %s/%s: LIST required (trigger=%s) "
                    "— watcher certificate not usable: %s",
                    bucket, table_prefix, reason, _cert_why)
        if _out_meta is not None:
            try:
                _out_meta["adaptive_freshness"] = {
                    "trigger": reason, "refreshed": False,
                    # Why the LIST was or wasn't skipped — readable in the
                    # scan meta without turning on debug logging.
                    "watcher_certificate": _cert_why,
                    # 2026-07: genuine-staleness flag.  A TRIGGER (incl.
                    # config_force / stale_by_cadence) only means "we CHECKED",
                    # NOT that the pointer was behind.  Default False; set True
                    # ONLY when a strictly-newer metadata is actually adopted
                    # (line ~825).  The completeness Sentinel reads THIS, not
                    # ``trigger and not refreshed`` — which false-fired
                    # full_scan on every healthy query whose check merely
                    # confirmed the pointer was already newest.
                    "stale": False,
                }
            except Exception as _be_exc:
                note_best_effort("_out_meta['adaptive_freshness'] = {'trigger': reason, 'refreshed'...", _be_exc,
                                 logger=logger)
        if not decision:
            return meta_key, metadata      # healthy → ZERO extra S3 I/O

        # ── Throttled newest-by-scan (capped LIST) ───────────────────────
        tid = _freshness_table_id(bucket, table_prefix)
        try:
            scan_ttl = float(_adaptive_freshness_cfg(
                "adaptive_freshness_scan_ttl_seconds",
                _ADAPTIVE_FRESHNESS_SCAN_TTL_DEFAULT))
        except (TypeError, ValueError):
            scan_ttl = float(_ADAPTIVE_FRESHNESS_SCAN_TTL_DEFAULT)
        now = _time.time()
        newest_key = None
        have_cached_scan = False
        with _freshness_lock:
            cached_scan = _freshness_scan_cache.get(tid)
            cached_scan = dict(cached_scan) if cached_scan else None
        if cached_scan is not None:
            _eff_ttl = scan_ttl
            # A quiet/archived table permanently trips stale-by-cadence;
            # once a scan CONFIRMED the pointer is freshest, re-LIST 10x
            # less often for that trigger (bounded background cost).
            if cached_scan.get("confirmed_fresh") \
                    and reason.startswith("stale_by_cadence"):
                _eff_ttl = scan_ttl * 10
            if (now - float(cached_scan.get("ts") or 0)) < _eff_ttl:
                newest_key = cached_scan.get("newest_key")
                have_cached_scan = True
                if not newest_key or newest_key == meta_key:
                    return meta_key, metadata   # throttled; nothing newer known
        if not have_cached_scan:
            try:
                best = _newest_metadata_json_by_scan(
                    s3_client, bucket, meta_prefix)
            except Exception as scan_exc:
                logger.warning(
                    "[adaptive-freshness] newest-metadata scan failed for %s "
                    "(trigger=%s) — keeping fast-path result (fail-safe): %s",
                    tid, reason, scan_exc)
                return meta_key, metadata
            newest_key = best["Key"] if best else None
            # 2026-08-20: a CAPPED scan did not see the lexicographic tail —
            # exactly where the newest metadata keys live — so it must never
            # stamp confirmed_fresh (that 10x-throttles future re-scans off
            # a "confirmation" the scan provably could not make).
            _scan_capped = bool(best.get("scan_capped")) if isinstance(best, dict) else False
            with _freshness_lock:
                _freshness_scan_cache[tid] = {
                    "ts": now,
                    "newest_key": newest_key,
                    "scan_capped": _scan_capped,
                    "confirmed_fresh": bool((newest_key is None
                                             or newest_key == meta_key)
                                            and not _scan_capped),
                }
        if not newest_key or newest_key == meta_key:
            logger.info(
                "[adaptive-freshness] %s: trigger=%s → scan confirmed the "
                "resolved pointer %s IS the newest metadata (no refresh "
                "needed)", tid, reason, meta_key)
            return meta_key, metadata

        # ── Candidate differs — adopt ONLY if strictly newer ─────────────
        try:
            cand = _read_s3_json_cached(s3_client, bucket, newest_key)
        except Exception as cand_exc:
            logger.warning(
                "[adaptive-freshness] could not read candidate metadata %s — "
                "keeping fast-path result (fail-safe): %s",
                newest_key, cand_exc)
            return meta_key, metadata
        cur_ts = _metadata_last_updated_ms(metadata)
        cand_ts = _metadata_last_updated_ms(cand)
        if (not isinstance(cand, dict) or cand_ts is None
                or (cur_ts is not None and cand_ts <= cur_ts)):
            # NEVER adopt an older (or same-age / uncomparable) snapshot.
            with _freshness_lock:
                _e = _freshness_scan_cache.get(tid)
                # 2026-08-20: a capped scan cannot confirm freshness — the
                # true newest may sit beyond the cap.
                if _e is not None and not _e.get("scan_capped"):
                    _e["confirmed_fresh"] = True
            logger.info(
                "[adaptive-freshness] %s: newest-by-scan %s is NOT newer than "
                "resolved %s (cand_ts=%s cur_ts=%s) — keeping fast-path result",
                tid, newest_key, meta_key, cand_ts, cur_ts)
            return meta_key, metadata

        # ── DEEP-DIVE FIX v2 (2026-07-16) — STRICTLY-AHEAD-IN-COMMIT-ORDER GUARD
        # "newest by LastModified" is not proof of "newer on the same commit
        # lineage": a racing / orphaned / rolled-back writer can leave a
        # metadata.json with a LATER timestamp that is NOT ahead of the resolved
        # snapshot; adopting it would serve a SIBLING snapshot missing committed
        # rows.  The FIRST attempt (2026-07-15) required the resolved snapshot-id
        # in the candidate's snapshots/snapshot-log lists — but ``expireSnapshots``
        # (which nearly every production table runs) TRIMS those lists, so a
        # legitimate newer snapshot no longer names the old one → that guard
        # REFUSED valid refreshes and re-opened the stale-pointer data-loss this
        # mechanism exists to repair.
        #
        # Use ``last-sequence-number`` instead: a top-level, MONOTONIC-per-commit
        # counter that expiry NEVER trims.  We only reach here when the candidate
        # is already newer by timestamp (checked above), so:
        #   * candidate strictly AHEAD in sequence (cand_seq > res_seq)  → ADOPT
        #     (expiry-proof; a failed/uncommitted orphan never advances the
        #     sequence, so it can't be "ahead").
        #   * candidate NOT ahead (cand_seq <= res_seq) despite a newer timestamp
        #     → the orphan/rollback signature → REFUSE (keep resolved, fail-safe).
        # This is strictly MORE conservative than the original timestamp-only
        # adoption (adds a refuse condition) yet never refuses a genuinely-ahead
        # snapshot.  When sequence numbers are absent (v1 / malformed metadata)
        # we fall back to the original newer-by-timestamp adoption — no worse
        # than pre-guard behavior.  Residual (documented): a SUCCESSFUL concurrent
        # sibling commit with a genuinely higher sequence is an inherent
        # split-brain that only a catalog can arbitrate.
        old_sid = metadata.get("current-snapshot-id")
        if cur_ts is None:
            logger.info("[adaptive-freshness] %s: resolved last-updated-ms is "
                        "uncomparable — refusing adoption (fail-safe).", tid)
            return meta_key, metadata

        def _as_int(_v):
            try:
                return int(_v)
            except (TypeError, ValueError):
                return None
        _res_seq = _as_int(metadata.get("last-sequence-number"))
        _cand_seq = _as_int(cand.get("last-sequence-number"))
        if (_res_seq is not None and _cand_seq is not None
                and _cand_seq <= _res_seq):
            logger.warning(
                "[adaptive-freshness] %s: newest-by-scan %s (snapshot=%s) has a "
                "later timestamp but is NOT ahead in commit order "
                "(last-sequence-number %s <= resolved %s) — orphaned / "
                "rolled-back / sibling metadata.  REFUSING adoption (would risk "
                "dropping committed rows); keeping the resolved pointer.",
                tid, newest_key, cand.get("current-snapshot-id"),
                _cand_seq, _res_seq)
            with _freshness_lock:
                _e = _freshness_scan_cache.get(tid)
                # 2026-08-20: never "confirm" off a capped scan.
                if _e is not None and not _e.get("scan_capped"):
                    _e["confirmed_fresh"] = True
            return meta_key, metadata

        new_sid = cand.get("current-snapshot-id")
        logger.warning(
            "[adaptive-freshness] STALE POINTER detected for %s: resolved %s "
            "(snapshot=%s, last-updated-ms=%s) but newest-by-scan is %s "
            "(snapshot=%s, last-updated-ms=%s) — trigger=%s.  Adopting the "
            "newer metadata and invalidating the poisoned snapshot-keyed "
            "caches (Phase-156 memo + BF-296 snapshot-content + result "
            "cache).  A newer snapshot only ADDS/compacts committed data, so "
            "this is always correctness-safe.",
            tid, meta_key, old_sid, cur_ts, newest_key, new_sid, cand_ts,
            reason,
        )
        # Hint reliability: the resolved pointer disagreed with reality →
        # this table is cross-checked permanently from now on.
        _freshness_record_hint_lied(bucket, table_prefix,
                                    db_manager=db_manager)

        # Repoint / invalidate every poisoned cache layer — each step is
        # individually fail-safe; a failure only delays convergence.
        cache_id = f"{bucket}/{meta_prefix}"
        try:
            _cache_metadata_key(cache_id, newest_key,
                                connection_id=_connection_id_from_s3_client(
                                    s3_client))
        except Exception as exc:
            logger.debug("[adaptive-freshness] metadata-key cache repoint "
                         "failed: %s", exc)
        try:
            _invalidate_result_cache_for_cache_id(cache_id)   # BF-550
        except Exception as exc:
            logger.debug("[adaptive-freshness] result-cache invalidate "
                         "failed: %s", exc)
        if old_sid is not None and str(old_sid) != str(new_sid):
            try:
                from core.brain_pruning_memo import (
                    invalidate_for_snapshot as _bm_inv,
                )
                _n = _bm_inv(str(old_sid), db_manager)
                logger.info("[adaptive-freshness] invalidated %s Phase-156 "
                            "memo entr%s pinned to stale snapshot %s",
                            _n, "y" if _n == 1 else "ies", old_sid)
            except Exception as exc:
                logger.debug("[adaptive-freshness] memo invalidate failed: %s",
                             exc)
            try:
                from core import iceberg_snapshot_cache as _isc
                _isc.invalidate_contents(bucket, table_prefix,
                                         snapshot_id=str(old_sid))
                _isc.invalidate_pointer(bucket, table_prefix)
            except Exception as exc:
                logger.debug("[adaptive-freshness] BF-296 snapshot-content "
                             "invalidate failed: %s", exc)
        if _out_meta is not None:
            try:
                _out_meta["adaptive_freshness"] = {
                    "trigger": reason, "refreshed": True,
                    "stale": True,   # genuinely was behind → newer adopted
                    "old_meta_key": meta_key, "new_meta_key": newest_key,
                    "old_snapshot_id": str(old_sid),
                    "new_snapshot_id": str(new_sid),
                }
            except Exception as _be_exc:
                note_best_effort("_out_meta['adaptive_freshness'] = {'trigger': reason, 'refreshed'...", _be_exc,
                                 logger=logger)
        return newest_key, cand
    except Exception as exc:
        logger.warning(
            "[adaptive-freshness] hook failed — keeping fast-path result "
            "(fail-safe): %s", exc)
        return meta_key, metadata


_background_refresh_in_progress: Dict[str, bool] = {}  # tracks which cache_ids are being refreshed

# ── Metadata content cache ────────────────────────────────────────────────────
# Caches the parsed metadata.json content to avoid redundant S3 GetObject calls
# within the same query execution (e.g. BQB path reads metadata twice: once to
# extract partition spec, once inside get_iceberg_data_files).
# Key: "bucket/key" → Value: {"content": dict, "ts": float}
# TTL matches _METADATA_CACHE_TTL so cache stays coherent with key cache.
_metadata_content_cache: Dict[str, Dict[str, Any]] = {}
_metadata_content_cache_lock = threading.Lock()


# ── S3 URI helpers ────────────────────────────────────────────────────────────

def _s3_uri_to_key(uri: str) -> str:
    """Convert s3://bucket/key  or  s3a://bucket/key  →  key only."""
    for scheme in ("s3a://", "s3n://", "s3://"):
        if uri.startswith(scheme):
            path = uri[len(scheme):]
            slash = path.find("/")
            return path[slash + 1:] if slash >= 0 else ""
    return uri  # already a bare key


def _s3_uri_bucket(uri: str) -> str:
    """Return the bucket named by an ``s3://``/``s3a://``/``s3n://`` URI, or
    ``""`` for a bare key (no scheme ⇒ the caller's table bucket is implied).

    2026-08-20 DATA-LOSS FIX companion to ``_s3_uri_to_key``: the dedup
    guards in ``get_iceberg_data_files`` keyed on the KEY ONLY, so a
    multi-bucket table with colliding key paths silently dropped the second
    file/manifest as a "duplicate reference" — and reported the drop as a
    fix.  Dedup identity must be (bucket, key).
    """
    for scheme in ("s3a://", "s3n://", "s3://"):
        if uri.startswith(scheme):
            path = uri[len(scheme):]
            slash = path.find("/")
            return path[:slash] if slash >= 0 else path
    return ""


def _classify_ref_for_dedup(seen: Dict[str, str], key: str,
                            effective_bucket: str) -> str:
    """Dedup decision for one manifest/data-file reference (2026-08-20).

    ``seen`` maps key → effective bucket of the FIRST reference (bare URI ⇒
    the table's bucket).  Returns:

      * ``"new"``     — first sight of this key: caller records + keeps it;
      * ``"dup"``     — same (bucket, key) seen before: a true duplicate
        reference, safe to drop (the 2026-07-13 phantom-count fix);
      * ``"foreign"`` — the KEY collides but the bucket DIFFERS: a DISTINCT
        physical file/manifest in another bucket that this single-bucket
        reader cannot scan.  The caller must skip it (appending the bare
        key would double-read the colliding same-bucket twin) but surface
        it as missing data — NEVER count it as a dedup "fix".

    Mutates ``seen`` on ``"new"``.
    """
    prev = seen.get(key)
    if prev is None:
        seen[key] = effective_bucket
        return "new"
    if prev == effective_bucket:
        return "dup"
    return "foreign"


def _is_expired_token_error(exc: Exception) -> bool:
    """BF-278: classify a boto3 exception as a credential-expiry signal.

    Returns True for STS/IAM token-expired errors regardless of how the
    error is surfaced (ClientError code, ExpiredTokenException class, or
    plain message text — different boto3 versions raise different
    permutations).
    """
    # 2026-10-30 -- the declared vocabulary of a REJECTED credential lives in
    # one place (core/qs_credentials/freshness.py::is_auth_failure): expiry
    # AND a key Vault has since rotated (InvalidAccessKeyId /
    # SignatureDoesNotMatch) are the same remedy -- drop the handler, forget
    # the account, re-resolve.  AccessDenied (a right the key lacks) is not.
    try:
        from core.qs_credentials.freshness import is_auth_failure
        return is_auth_failure(exc) is not None
    except Exception as _be_exc:                               # pragma: no cover
        note_best_effort("is_auth_failure", _be_exc, logger=logger)
    msg = str(exc).lower()
    return ("expired token" in msg or "token has expired" in msg
            or "expiredtoken" in msg)


def _connection_id_from_s3_client(s3_client) -> Optional[int]:
    """BF-278: best-effort lookup of the QueryStudio connection_id that
    owns this boto3 client.  We tag clients with ``_qs_connection_id``
    when they pass through ``make_s3_client_for_conn``; if the attribute
    is missing (legacy / direct-build paths) we return None and the
    caller skips the auto-invalidation path."""
    try:
        return getattr(s3_client, "_qs_connection_id", None)
    except Exception:
        return None


# BF-590 (2026-05-29): hard timeout cap on every iceberg S3 call, via a
# *SHARED* module-level ThreadPoolExecutor.
#
# BF-589 introduced this cap but used `with ThreadPoolExecutor(max_workers=1):`
# per call — audit Agent A flagged that pattern would spawn ~8000 threads on
# a 1000-manifest fanout (8 parallel manifest workers × 1000 files).
# The right shape is one shared pool sized to the worker count, reused across
# every invocation.  Per-call we still wrap with `_fut.result(timeout=...)`
# so a stuck proxy / unreachable bucket can never wedge an iceberg worker.
import concurrent.futures as _cf_iceberg  # noqa: E402
_S3_CALL_TIMEOUT_S = 60.0  # generous: cold metadata fetch can take 30s
# BF-590 sized this at 32 — BF-591 raises to 64 to match the worst-case
# fanout of 8 parallel manifest workers × 8 inner S3 calls each.  Below
# this the per-call _fut.result(timeout=) starts firing on tail tasks
# that haven't even left the queue yet (timer is wall-clock-from-submit,
# not from-execution-start).
_S3_POOL_MAX_WORKERS = 64
_S3_CALL_POOL: Optional["_cf_iceberg.ThreadPoolExecutor"] = None
_S3_CALL_POOL_LOCK = threading.Lock()

# ── F2 (2026-08-22, design_s3_speed §6) — pool-depth telemetry ──────────
# A TimeoutError here used to call _fut.cancel(), which CANNOT cancel an
# already-running boto3 call: the stuck call kept its pool worker until
# the socket died, and a proxy brown-out could exhaust all 64 slots and
# serialize every metadata read behind stuck calls with no signal at all.
# The GET itself cannot be aborted from outside (boto3 read timeouts
# belong on the client config, owned by the client factory) — but the
# condition can be SEEN: an in-flight gauge, an "abandoned" count for
# calls whose caller gave up, a completion hook that releases the slot
# accounting and CLOSES the orphaned response body (else the urllib3
# connection leaks too), and a rate-limited ERROR when the pool is close
# to saturated.
_S3_POOL_GAUGE_LOCK = threading.Lock()
_S3_POOL_GAUGE = {
    "inflight": 0,          # calls currently executing on pool threads
    "abandoned": 0,         # running calls whose caller timed out
    "abandoned_total": 0,   # lifetime count of abandonments
    "abandoned_returned": 0,  # abandoned calls that eventually finished
    "saturation_alarms": 0,
}
_S3_POOL_SATURATION_HEADROOM = 8   # alarm when free slots drop below this
_S3_POOL_ALARM_MIN_INTERVAL_S = 60.0
_S3_POOL_LAST_ALARM = [0.0]


def s3_pool_stats() -> dict:
    """Live pool-depth telemetry (F2).  Cheap; safe from any thread."""
    with _S3_POOL_GAUGE_LOCK:
        out = dict(_S3_POOL_GAUGE)
    out["max_workers"] = _S3_POOL_MAX_WORKERS
    return out


def _s3_pool_check_saturation() -> None:
    """Rate-limited ERROR when stuck+running calls approach pool size —
    the wedge that used to be invisible."""
    with _S3_POOL_GAUGE_LOCK:
        busy = _S3_POOL_GAUGE["inflight"] + _S3_POOL_GAUGE["abandoned"]
    if busy < _S3_POOL_MAX_WORKERS - _S3_POOL_SATURATION_HEADROOM:
        return
    now = _time.monotonic()
    if now - _S3_POOL_LAST_ALARM[0] < _S3_POOL_ALARM_MIN_INTERVAL_S:
        return
    _S3_POOL_LAST_ALARM[0] = now
    with _S3_POOL_GAUGE_LOCK:
        _S3_POOL_GAUGE["saturation_alarms"] += 1
        snap = dict(_S3_POOL_GAUGE)
    logger.error(
        "S3-POOL SATURATION: %d/%d slots busy (%d in-flight + %d ABANDONED "
        "stuck calls).  Metadata reads are about to serialize behind stuck "
        "sockets — check the proxy / S3 endpoint.  (abandoned_total=%d, "
        "eventually_returned=%d)",
        busy, _S3_POOL_MAX_WORKERS, snap["inflight"], snap["abandoned"],
        snap["abandoned_total"], snap["abandoned_returned"])


def _s3_pool_note_abandoned(fut, bucket: str, key: str,
                            started_at: float) -> None:
    """Caller timed out.  If the call never started, cancel() freed the
    slot and there is nothing to track.  If it IS running, count it as
    abandoned and attach a completion hook that (a) releases the
    accounting, (b) CLOSES the response body a successful late return
    would otherwise leak, (c) logs how long the slot was held."""
    if fut.cancelled():
        return
    with _S3_POOL_GAUGE_LOCK:
        _S3_POOL_GAUGE["abandoned"] += 1
        _S3_POOL_GAUGE["abandoned_total"] += 1

    def _on_done(f):
        held = _time.monotonic() - started_at
        with _S3_POOL_GAUGE_LOCK:
            _S3_POOL_GAUGE["abandoned"] = max(
                0, _S3_POOL_GAUGE["abandoned"] - 1)
            _S3_POOL_GAUGE["abandoned_returned"] += 1
        try:
            _exc = f.exception()
        except Exception:
            _exc = None
        if _exc is None:
            try:
                f.result()["Body"].close()
            except Exception as _be_exc:
                note_best_effort("f.result()['Body'].close()", _be_exc,
                                 logger=logger)
            logger.warning(
                "F2: abandoned S3 GET for s3://%s/%s finally RETURNED "
                "after %.1fs — slot released, orphaned body closed.",
                bucket, key, held)
        else:
            logger.warning(
                "F2: abandoned S3 GET for s3://%s/%s finally FAILED "
                "after %.1fs (%s) — slot released.",
                bucket, key, held, type(_exc).__name__)

    fut.add_done_callback(_on_done)
    _s3_pool_check_saturation()


def _get_s3_call_pool() -> "_cf_iceberg.ThreadPoolExecutor":
    """Lazy-init the shared executor.  Thread-safe via double-checked lock."""
    global _S3_CALL_POOL
    if _S3_CALL_POOL is not None:
        return _S3_CALL_POOL
    with _S3_CALL_POOL_LOCK:
        if _S3_CALL_POOL is None:
            _S3_CALL_POOL = _cf_iceberg.ThreadPoolExecutor(
                max_workers=_S3_POOL_MAX_WORKERS,
                thread_name_prefix="ice-s3",
            )
    return _S3_CALL_POOL


# ── Phase 0 (2026-08-22, design_s3_speed §4) — per-query ACTUAL S3 GET
# counter, at the ONE chokepoint every iceberg metadata GET goes through.
#
# The 08-21 lesson, generalised: "s3_manifests=5/5" counted manifests
# PROCESSED (including ones served entirely from L1/L2), so a fully-cached
# walk looked identical to five real network GETs.  This counter increments
# ONLY where a GetObject call is actually submitted to boto3 — a cache hit
# never touches it.  The reader installs a counter in a ContextVar at query
# entry and reports the DELTA on its scan line; pool-thread callers (the
# parallel manifest fetch) receive the counter EXPLICITLY via the
# ``_get_counter`` kwarg because executor threads do not inherit the
# caller's context.  Background warmers deliberately do NOT count — they
# are off the query's critical path, and charging them to the query would
# make the line lie in the other direction.
from contextvars import ContextVar as _CtxVar  # noqa: E402


class _S3GetCounter:
    """Thread-safe count of REAL S3 GetObject calls issued for one query."""

    __slots__ = ("_n", "_lk")

    def __init__(self) -> None:
        self._n = 0
        self._lk = threading.Lock()

    def bump(self) -> None:
        with self._lk:
            self._n += 1

    @property
    def value(self) -> int:
        with self._lk:
            return self._n


_S3_GET_COUNTER_CTX: "_CtxVar[Optional[_S3GetCounter]]" = _CtxVar(
    "qs_iceberg_s3_get_counter", default=None)

# 2026-08-24 — LIST calls were never counted.  ``s3_gets`` bumps only inside
# ``_read_s3_bytes`` (a GET), so a scan that paginated an entire ``metadata/``
# prefix still printed ``s3_gets=0``.  That zero was read as evidence the
# pruning path was healthy — twice — while the LIST storm it could not see was
# the dominant cost.  A counter that measures one verb, displayed as if it
# measured I/O, turns "I did not look" into "I checked and it was fine".
_S3_LIST_COUNTER_CTX: "_CtxVar[Optional[_S3GetCounter]]" = _CtxVar(
    "qs_iceberg_s3_list_counter", default=None)


# ── 2026-10-08 ONE recording point for query_pruning_history ───────────────
#
# ``query_pruning_history`` is THE input of the brain (adaptive prefetch's
# bloom ranking, brain_cost_model >= 10 rows, brain_skew_detector >= 5, the
# writer advisor, pruning alerts) and of the per-execution admin route an
# operator reads to learn how many files a query read.  Until 2026-10-08
# only the two WALK returns of ``get_iceberg_data_files`` recorded it; the
# db-first served set, the brain-memo hit, the pyiceberg route, the
# empty-island verdict, the OR-group union and a snapshot-less table all
# returned BEFORE the recorder, so on the rig a 2,688-file table held 14
# rows after hundreds of queries and ten cold bypass queries left none.
#
# The body keeps its nine returns; the recording moved to ONE place every
# return passes through: ``_one_observation_per_call`` wraps the body and
# records in a ``finally`` from the observation the roads stamped
# (``_observe_road``) plus the returned list.  Nested reader calls (the
# OR-group branches, the empty-island re-prove / widening passes) share the
# outermost call's observation and never record on their own -- exactly
# one row per top-level reader call.  Guard:
# tests/test_pruning_history_one_recording_point_2026_10_08.py.
class _ReaderObservation:
    """What one top-level reader call decided, as the roads stamped it."""

    __slots__ = ("source", "files_before_prune", "files_after_prune",
                 "payload", "snapshot_id", "detail")

    def __init__(self) -> None:
        self.source: Optional[str] = None
        self.files_before_prune: Optional[int] = None
        self.files_after_prune: Optional[int] = None
        self.payload: Optional[Dict[str, Any]] = None
        self.snapshot_id: Optional[str] = None
        self.detail: Dict[str, Any] = {}


_READER_OBS_CTX: "_CtxVar[Optional[_ReaderObservation]]" = _CtxVar(
    "qs_iceberg_reader_observation", default=None)


def _observe_road(source: Optional[str], *, files_after: Optional[int] = None,
                  files_before: Optional[int] = None,
                  snapshot_id: Any = None,
                  payload: Optional[Dict[str, Any]] = None,
                  unless: Tuple[str, ...] = (), **detail: Any) -> None:
    """Stamp the road a reader call took and the counts it KNOWS.

    ``files_after`` is the pruned SOURCE count before any mirror / island
    substitution; ``files_before`` the files the snapshot lists.  A road
    that does not know a count passes nothing -- the row then carries
    NULL, never 0.  ``source=None`` keeps the current source; ``unless``
    names sources this stamp must not overwrite (the walk after a proven
    empty island stays ``empty_island``).  A no-op outside a reader call.
    """
    obs = _READER_OBS_CTX.get()
    if obs is None:
        return
    if source is not None and obs.source not in unless:
        obs.source = source
    if files_after is not None:
        obs.files_after_prune = int(files_after)
    if files_before is not None:
        obs.files_before_prune = int(files_before)
    if snapshot_id is not None and str(snapshot_id):
        obs.snapshot_id = str(snapshot_id)
    if payload is not None:
        obs.payload = payload
    if detail:
        obs.detail.update(detail)


def _cheap_filter_breakdown(partition_filters: Any) -> List[Dict[str, Any]]:
    """The ``[{column, operator}]`` shape the bloom ranker reads, from the
    raw filters -- for the roads that never classified them."""
    out: List[Dict[str, Any]] = []
    for f in partition_filters or []:
        if not isinstance(f, dict):
            continue
        col = str(f.get("col") or f.get("column") or "")
        op = str(f.get("op") or f.get("operator") or "")
        if col and op:
            out.append({"column": col, "operator": op})
    return out


def _reader_call_identity(args: tuple, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """The arguments the recorder needs, however the caller spelled them."""
    def _pos(i: int, name: str, default: Any = None) -> Any:
        return args[i] if len(args) > i else kwargs.get(name, default)
    return {
        "bucket": _pos(1, "bucket"),
        "table_prefix": _pos(2, "table_prefix"),
        "partition_filters": _pos(3, "partition_filters"),
        "keys_only": bool(_pos(4, "keys_only", False)),
        "snapshot_id": kwargs.get("snapshot_id"),
        "_out_meta": kwargs.get("_out_meta"),
    }


def _record_reader_observation(obs: _ReaderObservation, *, result: Any,
                               error: Optional[BaseException], bucket: Any,
                               table_prefix: Any, partition_filters: Any,
                               keys_only: bool, snapshot_id: Any,
                               _out_meta: Any) -> None:
    """THE one write of a reader call's ``query_pruning_history`` row.

    Counts come from the road's stamp first, the walk's rich payload
    second, the snapshot's declared ``total-data-files`` third, and are
    NULL when none of those knew.  A raising body records too
    (``source='error:<road>'``) -- a failed read is still a query.  Every
    "did not record" is counted by the store, never silent.
    """
    from core.query_diagnostic_store import (
        get_current_execution_id, note_pruning_history_skipped,
        record_pruning_history)
    if not _record_query_observations():
        note_pruning_history_skipped("disabled")
        return
    exec_id = None
    if isinstance(_out_meta, dict):
        exec_id = _out_meta.get("execution_id") or _out_meta.get("correlation_id")
    if not exec_id:
        exec_id = get_current_execution_id()
    if not exec_id:
        note_pruning_history_skipped("no_execution_id")
        return
    payload: Dict[str, Any] = dict(obs.payload) if isinstance(obs.payload, dict) else {}
    source = obs.source or payload.get("source") or "unknown"
    if error is not None:
        source = f"error:{source}"
    files_after = obs.files_after_prune
    if files_after is None:
        files_after = payload.get("files_after_prune")
    if files_after is None and error is None and isinstance(result, list):
        files_after = len(result)
    files_before = obs.files_before_prune
    if files_before is None:
        files_before = payload.get("files_before_prune")
    if files_before is None and isinstance(_out_meta, dict):
        try:
            declared = _out_meta.get("snapshot_total_data_files")
            files_before = int(declared) if declared not in (None, "") else None
        except (TypeError, ValueError):
            files_before = None
    snap = (payload.get("snapshot_id") or obs.snapshot_id
            or ((_out_meta or {}).get("snapshot_id") if isinstance(_out_meta, dict) else None)
            or (str(snapshot_id) if snapshot_id is not None else ""))
    # 2026-10-08 -- what this call HANDED BACK (the list after a mirror /
    # island swap), beside the pruner's count above.  A raising call
    # handed back nothing: unknown, NULL.  The LIMIT-only early stop
    # trims AFTER the reader returns and patches the row itself
    # (query_diagnostic_store.record_files_read).
    files_read: Optional[int] = None
    read_reason: Optional[str] = None
    if error is None and isinstance(result, list):
        files_read = len(result)
    if isinstance(_out_meta, dict) and _out_meta.get("read_substitution") in ("mirror", "island"):
        read_reason = str(_out_meta["read_substitution"])
    payload.update({
        "bucket": bucket,
        "table_prefix": table_prefix,
        "snapshot_id": str(snap or ""),
        "files_before_prune": files_before,
        "files_after_prune": files_after,
        "files_read": files_read,
        "read_reason": read_reason,
        "stage_drops": payload.get("stage_drops") or {},
        "filter_breakdown": (payload.get("filter_breakdown")
                             or _cheap_filter_breakdown(partition_filters)),
        "source": str(source)[:32],
        "format": "iceberg",
        "keys_only": bool(keys_only),
        "road_detail": dict(obs.detail),
    })
    if error is not None:
        payload["error"] = f"{type(error).__name__}: {error}"[:300]
    if isinstance(_out_meta, dict):
        # The L1 file-list cache stores these with the entry so a HIT can
        # record the counts the cache carried (duckdb_views).
        _out_meta["files_before_prune"] = files_before
        _out_meta["files_after_prune"] = files_after
        _out_meta["pruning_history_source"] = payload["source"]
    record_pruning_history(str(exec_id), payload)
    # the in-memory entry (the walk's emitter wrote it with the pruner's
    # count) carries the read set too, for the consumer's disclosure
    try:
        from core.query_diagnostic_store import get_pruning, record_pruning
        if get_pruning(str(exec_id)) is not None:
            record_pruning(str(exec_id), {"files_read": files_read, "read_reason": read_reason})
    except Exception as _mem_exc:                              # noqa: BLE001
        note_best_effort("record_pruning(files_read)", _mem_exc, logger=logger)


def _one_observation_per_call(fn):
    """Wrap the reader body so EVERY return (and every raise) passes
    through ``_record_reader_observation`` exactly once per top-level
    call.  ``functools.wraps`` keeps ``inspect.signature`` /
    ``inspect.getsource`` on the public name answering for the body."""
    import functools as _ft

    @_ft.wraps(fn)
    def _recorded(*args, **kwargs):
        obs = _READER_OBS_CTX.get()
        outermost = obs is None
        tok = None
        if outermost:
            obs = _ReaderObservation()
            tok = _READER_OBS_CTX.set(obs)
        result = None
        error: Optional[BaseException] = None
        try:
            try:
                result = fn(*args, **kwargs)
            except BaseException as exc:
                error = exc
                raise
        finally:
            if outermost:
                _READER_OBS_CTX.reset(tok)
                try:
                    _record_reader_observation(
                        obs, result=result, error=error,
                        **_reader_call_identity(args, kwargs))
                except Exception as _rec_exc:                 # noqa: BLE001
                    note_best_effort("_record_reader_observation(obs, ...)",
                                     _rec_exc, logger=logger)
        return result
    return _recorded



def _counted_pages(pages):
    """Yield ``pages`` unchanged, counting one LIST round-trip per page.

    Wraps an existing ``paginator.paginate(...)`` rather than replacing it, so
    every call site keeps its own kwargs, its own early ``break``, and its own
    page semantics.  The counting is here and nowhere else.
    """
    _ctr = _S3_LIST_COUNTER_CTX.get()
    for _page in pages:
        if _ctr is not None:
            _ctr.bump()
        yield _page


def _read_s3_bytes(s3_client, bucket: str, key: str, *,
                   _get_counter: Optional[_S3GetCounter] = None) -> bytes:
    logger.debug("_read_s3_bytes: s3://%s/%s", bucket, key)
    try:
        # BF-590: submit to the SHARED pool, enforce per-call timeout via
        # _fut.result(timeout=_S3_CALL_TIMEOUT_S).  This bounds every S3
        # call even when the underlying client lacks read_timeout, without
        # spawning a fresh thread per call.
        _pool = _get_s3_call_pool()
        # Phase 0 — count the ATTEMPT: a GET that times out or fails is
        # still a real network round-trip.  No exception guard: the counter
        # is 6 lines above and a typo here must fail tests, not hide.
        _ctr = (_get_counter if _get_counter is not None
                else _S3_GET_COUNTER_CTX.get())
        if _ctr is not None:
            _ctr.bump()

        def _do_get():
            with _S3_POOL_GAUGE_LOCK:
                _S3_POOL_GAUGE["inflight"] += 1
            try:
                return s3_client.get_object(Bucket=bucket, Key=key)
            finally:
                with _S3_POOL_GAUGE_LOCK:
                    _S3_POOL_GAUGE["inflight"] -= 1

        _submitted_at = _time.monotonic()
        _fut = _pool.submit(_do_get)
        try:
            obj = _fut.result(timeout=_S3_CALL_TIMEOUT_S)
        except _cf_iceberg.TimeoutError:
            # F2: cancel() only helps a NOT-YET-STARTED call.  A running
            # boto3 GET cannot be aborted from here — account for the
            # stuck slot loudly instead of pretending it was freed.
            _fut.cancel()
            _s3_pool_note_abandoned(_fut, bucket, key, _submitted_at)
            raise TimeoutError(
                f"BF-590: S3 GetObject timeout ({_S3_CALL_TIMEOUT_S}s) "
                f"for s3://{bucket}/{key}.  Likely cold metadata fetch "
                f"via slow proxy or unreachable bucket."
            )
    except Exception as exc:
        # BF-278: detect ExpiredToken → invalidate the cached S3 handler
        # so the NEXT call re-resolves fresh credentials.  We don't retry
        # in-place (would need the new client passed in); the caller's
        # outer retry path handles the actual re-fetch.
        if _is_expired_token_error(exc):
            conn_id = _connection_id_from_s3_client(s3_client)
            if conn_id is not None:
                try:
                    from core.connection_manager import get_connection_manager
                    cm = get_connection_manager()
                    if cm:
                        cm.invalidate_s3_handler(int(conn_id),
                                                  reason="ExpiredToken on GetObject")
                except Exception as _inv_exc:
                    logger.debug("S3 handler invalidation failed: %s", _inv_exc)
            logger.error("S3 GetObject failed for s3://%s/%s — credentials EXPIRED "
                         "(handler invalidated; retry will fetch fresh STS token)",
                         bucket, key)
        else:
            logger.error("S3 GetObject failed for s3://%s/%s", bucket, key, exc_info=True)
        raise
    body = obj["Body"]
    try:
        data = body.read()
        logger.debug("_read_s3_bytes: got %d bytes from s3://%s/%s", len(data), bucket, key)
        return data
    except Exception:
        logger.error("S3 body read failed for s3://%s/%s", bucket, key, exc_info=True)
        raise
    finally:
        body.close()


#: F1 fallback — the pre-2026-08-22 hard cap.  Used when the config read
#: fails or the configured value is invalid.  NEVER derived via ``a or b``:
#: 0 must mean "invalid, use the fallback", not "unlimited" (that fold has
#: shipped three times in this codebase).
_MANIFEST_FETCH_PARALLELISM_FALLBACK = 8


def _manifest_fetch_parallelism(n_manifests: int) -> int:
    """F1 (2026-08-22, design_s3_speed §6) — cold manifest fetch width.

    The fetch was hard-capped at 8-way against a 64-slot shared S3 pool,
    costing ⌈M/8⌉ RTT waves on the one path a corporate proxy makes slow.
    Width now comes from ``iceberg.manifest_fetch_parallelism`` (declared in
    config._DEFAULTS, default 32 — footer capture already runs 32 against
    the same pool), clamped to ``_S3_POOL_MAX_WORKERS`` and to the number of
    manifests.  This is a THROTTLE, never a gate: every manifest is still
    fetched at any width.
    """
    width = _MANIFEST_FETCH_PARALLELISM_FALLBACK
    raw: Any = None
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("iceberg", "manifest_fetch_parallelism", 32)
        width = int(raw)
    except Exception as _exc:
        logger.warning(
            "iceberg.manifest_fetch_parallelism unreadable (%r → %s) — "
            "using documented fallback %d",
            raw, _exc, _MANIFEST_FETCH_PARALLELISM_FALLBACK)
        width = _MANIFEST_FETCH_PARALLELISM_FALLBACK
    if width <= 0:
        logger.warning(
            "iceberg.manifest_fetch_parallelism=%r is invalid (must be "
            ">= 1; 0 does NOT mean unlimited) — using documented fallback %d",
            raw, _MANIFEST_FETCH_PARALLELISM_FALLBACK)
        width = _MANIFEST_FETCH_PARALLELISM_FALLBACK
    width = min(width, _S3_POOL_MAX_WORKERS)
    # Clamp to the task count (never more workers than manifests); 0 or a
    # negative count clamps to 1 EXPLICITLY — not via the ``or 1`` fold the
    # old ``min(8, len) or 1`` used.
    width = min(width, max(1, n_manifests))
    return max(1, width)


def _read_s3_json(s3_client, bucket: str, key: str) -> dict:
    raw = _read_s3_bytes(s3_client, bucket, key)
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        logger.error("Invalid JSON from s3://%s/%s (first 200 bytes: %r)", bucket, key, raw[:200], exc_info=True)
        raise


def _metadata_content_cache_max_entries() -> int:
    """Per-connection LRU cap for the persistent metadata-content cache.

    Read from config; default 5000 entries.  Tables typically generate a
    new metadata.json + manifest-list per snapshot, so 5000 covers ~years
    of history for a busy table — more than enough for query-time hits
    while keeping the table small.
    """
    try:
        from core.config import get as _cfg_get
        return int(_cfg_get("iceberg", "metadata_content_cache_max_entries", 5000))
    except Exception:
        return 5000


def _read_s3_json_cached(s3_client, bucket: str, key: str) -> dict:
    """Like _read_s3_json but caches parsed content via two layers:

    1. **In-memory** (``_metadata_content_cache``, 60s TTL, 100-entry LRU)
       — same-process dedupe.  Prevents duplicate S3 GetObject calls within
       the same query execution (BQB path reads metadata.json twice: once
       for partition spec extraction, once inside get_iceberg_data_files).

    2. **DB** (``IcebergMetadataContentCache``, persistent, LRU bounded)
       — cross-process / restart-survival.  metadata.json files are
       immutable (UUID in filename), so caching by full S3 key is safe
       forever.  Cold process / first-query-per-snapshot serves from DB
       in ~1ms instead of paying the S3 round-trip.

    Both caches are best-effort: any DB hiccup degrades to current S3-fetch
    behaviour.  The in-memory cache always succeeds.
    """
    cache_id = f"{bucket}/{key}"
    try:
        ttl = _get_metadata_cache_ttl()
    except Exception:
        ttl = _METADATA_CACHE_TTL

    # ── L1: in-memory ────────────────────────────────────────────────────
    with _metadata_content_cache_lock:
        entry = _metadata_content_cache.get(cache_id)
        if entry and (ttl <= 0 or _time.time() - entry["ts"] < ttl):
            logger.debug("Iceberg metadata content cache hit (L1): %s", cache_id)
            return entry["content"]

    # ── L2: DB (cross-process, restart-survival) ─────────────────────────
    # BF-ICEBERG-CACHE-ANY-CONN: the DB cache is now consulted on EVERY
    # call, including when the boto3 client isn't tagged with
    # ``_qs_connection_id``.  Iceberg metadata bodies are content-addressed
    # (UUID in filename / snapshot-id in path) so the cached answer is
    # identical regardless of which connection asks — the DB helper falls
    # back to an object_key-only lookup when conn_id is None.
    conn_id = _connection_id_from_s3_client(s3_client)
    try:
        from core.connection_manager import get_connection_manager
        cm = get_connection_manager()
        if cm and getattr(cm, "db", None):
            row = cm.db.get_iceberg_metadata_content(conn_id, key)
            if row:
                content = row.get("content")
                if content is not None:
                    logger.info("Iceberg metadata content cache hit (L2/DB): %s", cache_id)
                    # Hydrate L1 so subsequent same-process reads use the fast path.
                    with _metadata_content_cache_lock:
                        _metadata_content_cache[cache_id] = {
                            "content": content, "ts": _time.time(),
                        }
                    return content
    except Exception as _l2_exc:
        logger.debug("L2 metadata content cache read failed (cache_id=%s): %s",
                     cache_id, _l2_exc)

    # ── Cache miss → fetch from S3 + populate both layers ────────────────
    content = _read_s3_json(s3_client, bucket, key)

    # L1 write (always)
    with _metadata_content_cache_lock:
        if len(_metadata_content_cache) > 100:
            # Evict oldest entry to bound memory use
            oldest = min(_metadata_content_cache, key=lambda k: _metadata_content_cache[k]["ts"])
            del _metadata_content_cache[oldest]
        _metadata_content_cache[cache_id] = {"content": content, "ts": _time.time()}

    # L2 write (best-effort; works for tagged AND untagged clients —
    # untagged writes use sentinel conn_id=0 so any reader can find them).
    try:
        from core.connection_manager import get_connection_manager
        cm = get_connection_manager()
        if cm and getattr(cm, "db", None):
            # Approximate size for telemetry — JSON string length, not exact bytes.
            _approx_size = len(json.dumps(content, default=str)) if isinstance(content, (dict, list)) else 0
            cm.db.set_iceberg_metadata_content(
                conn_id, key, content,
                content_kind="json", content_size=_approx_size,
                max_entries=_metadata_content_cache_max_entries(),
            )
    except Exception as _l2_w_exc:
        logger.debug("L2 metadata content cache write failed (cache_id=%s): %s",
                     cache_id, _l2_w_exc)

    return content


# F3 (2026-08-22, design_s3_speed §6) — in-process L1 for manifest-list
# BYTES.  Without it every query — including a full BF-296 cache HIT — paid
# a DB row fetch + bytes.fromhex + fastavro parse of the manifest list,
# because the read at the top of the walk runs BEFORE the contents-cache
# branch.  The content is immutable (the path carries the snapshot id), so
# the TTL is a memory bound, not a correctness bound; past the entry cap the
# oldest entry is evicted, same policy as the metadata-content L1.
_manifest_list_l1: Dict[str, Dict[str, Any]] = {}
_manifest_list_l1_lock = threading.Lock()
_MANIFEST_LIST_L1_MAX_ENTRIES = 32


def _manifest_list_l1_put(cache_id: str, data: bytes) -> None:
    """Insert into the manifest-list L1, evicting the oldest entry past the
    cap.  bytes are immutable so handing the same object to every caller is
    safe."""
    with _manifest_list_l1_lock:
        if (cache_id not in _manifest_list_l1
                and len(_manifest_list_l1) >= _MANIFEST_LIST_L1_MAX_ENTRIES):
            oldest = min(_manifest_list_l1,
                         key=lambda k: _manifest_list_l1[k]["ts"])
            del _manifest_list_l1[oldest]
        _manifest_list_l1[cache_id] = {"data": data, "ts": _time.time()}


def pruning_alarm_is_benign(*, case_a: bool, enforced: bool,
                           unengaged, identity_failed: bool,
                           pruned_before_partition_stage) -> bool:
    """Is this PARTITION-PRUNING ALARM the expected shape of a HEALTHY query?

    2026-08-22.  Sub-case "a partition predicate engaged but eliminated 0
    files" is what a correct read looks like when an upstream stage already
    delivered exactly the island: nothing is left for the partition stage to
    eliminate.  It was logged at ERROR regardless, and now that range
    predicates form islands too it fires on far more queries.

    ``pruned_before_partition_stage`` is the field that settles it — added
    precisely because operators were reading 31-of-31-in-a-4000-file-table
    (pruning WORKED upstream) as 31-of-31-in-a-31-file-table (a genuine full
    scan).  Positive means upstream pruning demonstrably worked.

    Benign ⇒ INFO.  Everything else — the predicate never engaged, identity
    resolution failed, case B, or anything being FAILED CLOSED — stays ERROR.
    Unknown (``None``) is never benign: we do not claim a proof we lack.

    An ERROR that fires on healthy queries teaches operators to ignore
    ERRORs, which is the opposite of what this alarm is for.
    """
    return bool(
        case_a
        and not enforced
        and not unengaged
        and not identity_failed
        # a bool is an int in Python; a bool here means the producer changed
        # shape, which is not evidence of anything
        and not isinstance(pruned_before_partition_stage, bool)
        and isinstance(pruned_before_partition_stage, int)
        and pruned_before_partition_stage > 0)


def _read_manifest_list_avro_cached(s3_client, bucket: str, key: str) -> bytes:
    """Like ``_read_s3_bytes`` but caches the BYTES of immutable Iceberg
    manifest-list Avro files (named ``snap-{snapshot-id}-...``).

    F3 (2026-08-22): an in-process L1 (shared metadata-cache TTL, small
    entry cap) now fronts the DB L2, so a warm query pays a dict lookup
    instead of a DB row fetch + hex decode on every single execution.

    Pairs with ``_read_s3_json_cached`` to give a fully-local metadata
    chain on cold start: once a snapshot has been queried even once on
    this cluster, every subsequent process / pod can rebuild the manifest
    walk without an S3 round-trip for the manifest-list body.

    The Avro bytes are stored hex-encoded in the JSON column to keep the
    schema portable across SQLite / Postgres without a separate BLOB
    column type.  Decode round-trip is cheap (microseconds) compared to
    the S3 GetObject it replaces (10s-100ms over VPC, longer through
    proxy).
    """
    # BF-ICEBERG-CACHE-ANY-CONN: cache lookup runs even when the s3_client
    # is untagged.  Manifest-list paths contain the snapshot id and are
    # immutable, so the cached bytes are correct regardless of which
    # connection writes / reads.
    # ── F3: L1 first (in-process, immutable content) ─────────────────────
    cache_id = f"{bucket}/{key}"
    try:
        _ml_ttl = _get_metadata_cache_ttl()
    except Exception:
        _ml_ttl = _METADATA_CACHE_TTL
    with _manifest_list_l1_lock:
        _ml_entry = _manifest_list_l1.get(cache_id)
        if _ml_entry and (_ml_ttl <= 0
                          or _time.time() - _ml_entry["ts"] < _ml_ttl):
            logger.debug("Iceberg manifest-list cache hit (L1): %s", cache_id)
            return _ml_entry["data"]

    conn_id = _connection_id_from_s3_client(s3_client)
    try:
        from core.connection_manager import get_connection_manager
        cm = get_connection_manager()
        if cm and getattr(cm, "db", None):
            row = cm.db.get_iceberg_metadata_content(conn_id, key)
            if row and row.get("content_kind") == "avro":
                hex_str = row.get("content")
                if isinstance(hex_str, str) and hex_str:
                    logger.info("Iceberg manifest-list cache hit (L2/DB): %s/%s",
                                bucket, key)
                    try:
                        _ml_data = bytes.fromhex(hex_str)
                    except ValueError:
                        logger.debug("manifest-list cache hex decode failed; refetching")
                    else:
                        # F3 — hydrate L1 so subsequent same-process reads
                        # skip the DB fetch + hex decode entirely.
                        _manifest_list_l1_put(cache_id, _ml_data)
                        return _ml_data
    except Exception as _exc:
        logger.debug("manifest-list cache read failed: %s", _exc)

    # Cache miss → fetch from S3 and populate.
    data = _read_s3_bytes(s3_client, bucket, key)

    if data:
        _manifest_list_l1_put(cache_id, data)   # F3 — L1 write (always)
        try:
            from core.connection_manager import get_connection_manager
            cm = get_connection_manager()
            if cm and getattr(cm, "db", None):
                cm.db.set_iceberg_metadata_content(
                    conn_id, key, data.hex(),
                    content_kind="avro", content_size=len(data),
                    max_entries=_metadata_content_cache_max_entries(),
                )
        except Exception as _w_exc:
            logger.debug("manifest-list cache write failed: %s", _w_exc)

    return data


#: Per-file metrics kept for a WIDE table's manifest entry: the identity
#: partition source columns plus the first N field ids.  Iceberg's own
#: writer default (``write.metadata.metrics.max-inferred-column-defaults``)
#: is 100 for the same reason.  A table with <= N metric columns is decoded
#: exactly as before.
MANIFEST_METRIC_COLUMNS = 100

#: The six per-column metric maps of an Iceberg ``data_file``.
_METRIC_MAPS = ("column_sizes", "value_counts", "null_value_counts",
                "nan_value_counts", "lower_bounds", "upper_bounds")

#: Key under which a bounded entry carries the field ids its file STORES
#: (the full key set of ``column_sizes``) -- the read plan's column
#: presence must see every stored column, or it would project the ones
#: whose metrics were dropped as NULL.
METRIC_IDS_KEY = "_qs_metric_ids"


def _manifest_keep_ids(header: Any) -> set:
    """Identity / any partition source field ids from a manifest's Avro
    header (``partition-spec`` is written by every Iceberg writer)."""
    keep: set = set()
    try:
        raw = (header or {}).get("partition-spec")
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "replace")
        spec = json.loads(raw) if isinstance(raw, str) and raw else None
        fields = spec.get("fields") if isinstance(spec, dict) else spec
        for f in fields or []:
            sid = f.get("source-id") if isinstance(f, dict) else None
            if sid is not None:
                keep.add(int(sid))
    except Exception:
        pass
    return keep


def _bound_entry_metrics(rec: Any, partition_ids: set,
                         limit: int = MANIFEST_METRIC_COLUMNS) -> bool:
    """Bound ONE decoded manifest entry's per-column metric maps in place.

    2026-10-06, measured live: a 1,000-column table (2,016 data files)
    decodes to ~6,000 metric items per entry -- ~1.5 MB of Python objects
    per FILE, ~3 GB for the snapshot -- held in the manifest L1, encoded
    again for the L2 and the per-file store, on the API process.  The
    watcher's first look at the table after every boot enumerates the WHOLE
    snapshot, so the 2 GiB API container was OOM-killed, restarted, and
    killed again.

    For an entry with more than ``limit`` metric columns: every map keeps
    only the partition source ids and the ``limit`` smallest field ids (in
    its own wire shape), and the full set of stored field ids is
    kept as id RUNS under ``METRIC_IDS_KEY`` (``metric_ids_of`` expands).  A dropped bound is
    UNKNOWN to the pruners, which keep the file -- never a lost row.
    Returns True when the entry was bounded.
    """
    df = rec.get("data_file") if isinstance(rec, dict) else None
    if not isinstance(df, dict):
        return False
    sizes = _avro_kv_map(df.get("column_sizes")) or \
        _avro_kv_map(df.get("value_counts")) or \
        _avro_kv_map(df.get("null_value_counts"))
    if not sizes or len(sizes) <= limit:
        return False
    ids = []
    for k in sizes.keys():
        try:
            ids.append(int(k))
        except (TypeError, ValueError):
            continue
    ids_t = sorted(set(ids))
    keep = set(ids_t[:limit]) | set(partition_ids or ())
    def _kept(k) -> bool:
        try:
            return int(k) in keep
        except (TypeError, ValueError):
            return False

    for name in _METRIC_MAPS:
        m = df.get(name)
        if m is None:
            continue
        # As an int-keyed dict: every consumer reads both Avro map shapes
        # through _avro_kv_map, the L2 / per-file store encoder round-trips
        # int keys (_INT_KEYS_TAG), and it is ~3x smaller than the
        # array-of-{key, value}-records shape fastavro hands back.
        out = {}
        for k, v in _avro_kv_map(m).items():
            if _kept(k):
                out[int(k)] = v
        df[name] = out
    df[METRIC_IDS_KEY] = _id_runs(ids_t)
    return True


def _id_runs(sorted_ids: List[int]) -> List[List[int]]:
    """``[1,2,3,7,8]`` -> ``[[1,3],[7,8]]`` -- a 1,000-column file's stored
    ids are one or two runs, not 1,000 objects per file (and JSON-safe for
    the L2 / per-file stores)."""
    runs: List[List[int]] = []
    for i in sorted_ids:
        if runs and i == runs[-1][1] + 1:
            runs[-1][1] = i
        else:
            runs.append([i, i])
    return runs


def metric_ids_of(data_file: Any) -> Optional[List[int]]:
    """The field ids a bounded entry's file STORES (``METRIC_IDS_KEY``
    expanded), or None for an entry that was never bounded."""
    runs = data_file.get(METRIC_IDS_KEY) if isinstance(data_file, dict) else None
    if not runs:
        return None
    out: List[int] = []
    for r in runs:
        try:
            lo, hi = int(r[0]), int(r[1])
        except (TypeError, ValueError, IndexError):
            return None
        out.extend(range(lo, hi + 1))
    return out


def bound_entries(entries: Any) -> int:
    """Bound every entry of an already-decoded manifest (a cache read of an
    entry list stored before 2026-10-06).  No partition-spec header there,
    so the first ``MANIFEST_METRIC_COLUMNS`` ids are kept; presence keeps
    every id regardless.  Returns how many were bounded."""
    n = 0
    for e in entries or ():
        try:
            if _bound_entry_metrics(e, set()):
                n += 1
        except Exception:
            continue
    return n


def _read_avro(data: bytes) -> List[dict]:
    """Deserialise an Avro byte stream using fastavro.

    2026-10-06 -- a MANIFEST entry of a wide table has its per-column metric
    maps bounded AS IT IS DECODED (``_bound_entry_metrics``), so the full
    1,000-column form never exists for more than one entry at a time.
    Manifest LISTS and narrow tables decode exactly as before.
    """
    try:
        import fastavro
    except ImportError:
        raise RuntimeError(
            "fastavro is required for Iceberg manifest reading. "
            "Install it with: pip install fastavro>=1.9.0"
        )
    try:
        logger.debug("_read_avro: parsing %d bytes of Avro data", len(data))
        reader = fastavro.reader(io.BytesIO(data))
        _pids = None
        records = []
        _bounded = 0
        for rec in reader:
            if isinstance(rec, dict) and "data_file" in rec:
                if _pids is None:
                    _pids = _manifest_keep_ids(getattr(reader, "metadata", None))
                if _bound_entry_metrics(rec, _pids):
                    _bounded += 1
            records.append(rec)
        if _bounded:
            logger.info(
                "_read_avro: bounded per-column metrics on %d of %d manifest "
                "entries (wide table: kept partition sources + the first %d "
                "field ids; stored-column ids kept whole)",
                _bounded, len(records), MANIFEST_METRIC_COLUMNS)
        logger.debug("_read_avro: decoded %d records", len(records))
        return records
    except Exception:
        logger.error("fastavro failed to decode Avro data (%d bytes, header: %r)",
                     len(data), data[:16], exc_info=True)
        raise


# ── Table detection ───────────────────────────────────────────────────────────

def is_iceberg_table(s3_client, bucket: str, prefix: str,
                      raise_on_access_error: bool = False) -> bool:
    """Return True if the S3 prefix looks like an Iceberg table directory.

    Checks for a metadata/ subfolder containing Iceberg metadata files:
      - v1.metadata.json, 00000-xxx.metadata.json  (standard naming)
      - metadata.json  (simplified naming)
      - *.avro  (Avro manifest files used by some Iceberg writers)

    DEFAULT BEHAVIOUR (raise_on_access_error=False):
      Swallows ALL exceptions and returns False.  This is what every
      DISCOVER-style caller wants — they iterate over many folders and
      a single 403 on one folder must not abort the sweep.

    OPT-IN (raise_on_access_error=True):
      Set this from REGISTER-style callers that hand-pick a single
      folder and want to surface IAM / network failures as actionable
      errors instead of mislabeling them "not a valid Iceberg table".
      On AccessDenied / Forbidden / EndpointConnectionError /
      DNS-resolution failure, the exception is re-raised so the caller
      can classify it.
    """
    meta_prefix = prefix.rstrip("/") + "/metadata/"
    try:
        _lc = _S3_LIST_COUNTER_CTX.get()
        if _lc is not None:
            _lc.bump()          # a direct LIST is still a round trip
        resp = s3_client.list_objects_v2(
            Bucket=bucket, Prefix=meta_prefix, MaxKeys=30
        )
        for obj in resp.get("Contents", []):
            key = obj["Key"]
            basename = key.rsplit("/", 1)[-1].lower()
            if basename.endswith(".metadata.json"):
                return True
            if basename == "metadata.json":
                return True
            if basename.endswith(".avro"):
                return True
    except Exception as exc:
        if raise_on_access_error:
            _msg = str(exc).lower()
            _code = ""
            try:
                _code = exc.response.get("Error", {}).get("Code", "")
            except Exception as _be_exc:
                note_best_effort("exc.response.get('Error', {}).get('Code', '')", _be_exc,
                                 logger=logger)
            if (_code in {"AccessDenied", "Forbidden", "403"}
                    or "accessdenied" in _msg
                    or "could not connect to the endpoint" in _msg
                    or "name or service not known" in _msg
                    or "name resolution" in _msg):
                logging.getLogger(__name__).error(
                    "is_iceberg_table: underlying S3 access failed for "
                    "s3://%s/%s — %s",
                    bucket, meta_prefix, exc,
                )
                raise
        logging.getLogger(__name__).warning(
            "%s failed: %s", "iceberg_reader", exc, exc_info=True)
    return False


def list_iceberg_tables(
    s3_client, bucket: str, prefix: str = ""
) -> List[Dict[str, Any]]:
    """
    Scan one level of S3 prefix for Iceberg table directories.

    Args:
        s3_client: boto3 S3 client
        bucket:    S3 bucket name
        prefix:    S3 prefix to scan (warehouse path, e.g. "warehouse/db/")

    Returns:
        List of dicts: {name, prefix, type='iceberg_table', path}
    """
    paginator = s3_client.get_paginator("list_objects_v2")
    tables: List[Dict[str, Any]] = []

    try:
        for page in _counted_pages(paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/")):
            for cp in page.get("CommonPrefixes", []):
                folder = cp["Prefix"]
                name = folder.rstrip("/").split("/")[-1]
                if is_iceberg_table(s3_client, bucket, folder):
                    tables.append({
                        "name":   name,
                        "prefix": folder,
                        "type":   "iceberg_table",
                        # virtual path consumed by the query builder
                        "path":   f"__iceberg__:{folder}",
                        "folder": prefix,
                    })
    except Exception as e:
        logger.error("Error scanning for Iceberg tables at %s: %s", prefix, e)
        raise

    logger.info("Found %d Iceberg tables under prefix '%s'", len(tables), prefix)
    return tables


# ── Partition spec + bound decoding ──────────────────────────────────────────

_EPOCH = date(1970, 1, 1)


def _decode_partition_value(raw: Any, iceberg_type: str) -> Any:
    """Decode a partition value that fastavro returns as a Python primitive.

    Unlike _decode_bound (which decodes raw bytes), fastavro already unpacks
    Avro data into Python ints/strings/etc.  But date columns come back as
    int (days since epoch) and timestamps as int (microseconds since epoch).
    This function converts them to human-readable strings.
    """
    if raw is None:
        return None
    if isinstance(raw, bytes):
        return _decode_bound(raw, iceberg_type)
    t = iceberg_type.lower()
    # Normalize transform types to their underlying semantics
    if t == "_transform_day":
        t = "date"
    elif t == "_transform_month":
        t = "_month"
    elif t == "_transform_year":
        t = "_year"
    elif t == "_transform_hour":
        t = "_hour"
    if isinstance(raw, int):
        if t == "date":
            try:
                return str(_EPOCH + timedelta(days=raw))
            except Exception:
                return str(raw)
        if t == "_month":
            try:
                year = 1970 + raw // 12
                month = 1 + raw % 12
                return f"{year:04d}-{month:02d}"
            except Exception:
                return str(raw)
        if t == "_year":
            return str(1970 + raw)
        if t == "_hour":
            try:
                dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(hours=raw)
                return dt.strftime("%Y-%m-%d %H:00")
            except Exception:
                return str(raw)
        if t in ("timestamp", "timestamptz", "timestamp_tz",
                 "timestamp with local time zone"):
            try:
                dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=raw)
                return dt.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                return str(raw)
        if t == "time":
            try:
                total_secs = raw // 1_000_000
                h, rem = divmod(total_secs, 3600)
                m, s = divmod(rem, 60)
                return f"{h:02d}:{m:02d}:{s:02d}"
            except Exception:
                return str(raw)
    # String / already decoded — return as-is
    return raw


_PARTITION_CAST_RE = None


def _strip_partition_cast(v):
    """Strip a ``DATE '…'`` / ``TIMESTAMP '…'`` / ``TIME '…'`` SQL cast wrapper
    to the inner literal.  Non-string / unwrapped values pass through unchanged.
    Used before applying bucket/truncate partition transforms to IN-list values
    (a cast wrapper makes the transform raise → None → empty set → over-prune)."""
    global _PARTITION_CAST_RE
    if not isinstance(v, str):
        return v
    if _PARTITION_CAST_RE is None:
        import re as _re_pc
        _PARTITION_CAST_RE = _re_pc.compile(
            r"^(?:DATE|TIMESTAMP|TIME)\s+'(.+)'$", _re_pc.IGNORECASE)
    _m = _PARTITION_CAST_RE.match(v)
    return _m.group(1) if _m else v


def _is_bloom_parity_safe_type(iceberg_type: Optional[str]) -> bool:
    """True only for iceberg types whose anchor-key string form (_decode_bound)
    is BYTE-IDENTICAL to the bloom sidecar's build-side encoding
    (_value_to_bytes on pyarrow values).  Gates bloom JOIN target-file pruning
    so a value-form mismatch can never silently drop joining rows.

    SAFE (round-trip proven, byte-canonical ACROSS tables): integers, boolean,
    date (fixed-width struct / date-int — no representation freedom).

    UNSAFE -> skip:
      * 2026-07-14 (round 5): STRING/str — the bloom hashes RAW UTF-8 on BOTH
        build and probe (iceberg_bloom_sidecar._value_to_bytes) with NO
        canonicalization, so two tables that spell the same logical key with
        byte drift (CASE / whitespace / Unicode NFC-vs-NFD) mis-match: the
        anchor's probe bytes miss the target's build bytes -> a file that DOES
        contain the joining row is wrongly pruned -> silent PARTIAL row loss,
        invisible to the 0-file safety net.  _partition_value_string_match
        cannot help here (bloom is hashed-bytes membership, not a value compare)
        and normalizing the encoder would mis-prune every not-yet-rebuilt bloom
        (no bloom-format version field exists).  So EXCLUDE string from bloom
        pruning: it falls back to no bloom prune = over-scan = SAFE, and string
        keys are still pruned by partition / column-stats / SQL IN-list paths.
      * decimal (anchor strips trailing zeros: "100.5" vs bloom "100.50"),
        timestamp/timestamptz (isoformat 'T'+offset vs str() space),
        float/double (numeric-string ambiguity), and anything not positively
        classified.

    The SQL IN-list path (join_key_distinct_values) is unaffected -- it prunes
    via column stats + the numeric/string reconciliation, not bloom bytes -- so
    string join keys keep that pruning.
    """
    t = (iceberg_type or "").lower().strip()
    return t in (
        "int", "integer", "long", "bigint", "smallint", "tinyint",
        "boolean", "bool", "date",
    )


#: (table_prefix, filter columns) already warned about having no bloom rows
#: in this process.  Bounded by the number of distinct filtered shapes a pod
#: sees; the first sighting is a WARNING, later ones INFO.
_BLOOM_NO_ROWS_WARNED: set = set()


def _bloom_probe_encoding_safe(iceberg_type: Optional[str], val: Any) -> bool:
    """True only when ``_value_to_bytes(val)`` (the CONSUME-side probe) is
    byte-identical to the sidecar's BUILD-side ``_value_to_bytes`` on the
    column's native pyarrow value — so ``bloom_can_contain`` hashes the SAME
    bytes and an "absent" verdict is trustworthy.

    2026-07-15 DATA-LOSS GUARD.  Single-table WHERE / IN values reach the
    pruner as STRINGS (SQL literal '2025-09-30', '5'), while the sidecar bloom
    was built from the column's NATIVE typed value.  A string probe only
    byte-matches a genuine STRING column; for a DATE/INT/etc. column the build
    hashed date/int bytes, so the string probe silently misses and drops files
    that DO contain the row (the 210M->78M vector).  Fail-CLOSED: return False
    unless the probe's Python type provably matches the column's encoding, so
    the caller SKIPS bloom pruning for that column (fail-open scan).
    """
    t = (iceberg_type or "").lower().strip()
    if not t:
        return False  # unknown column type → never trust an absence
    if isinstance(val, bool):
        return t in ("boolean", "bool")
    if isinstance(val, str):
        # string probe ↔ string build only (utf-8 bytes on both sides)
        return t in ("string", "str", "varchar", "char", "text", "uuid")
    if isinstance(val, int):
        return t in ("int", "integer", "long", "bigint", "smallint", "tinyint")
    if isinstance(val, float):
        return t in ("float", "double")
    # bytes / Decimal / date objects / etc. — can't guarantee build encoding.
    return False


def _iceberg_current_schema_col_types(metadata: Dict[str, Any]) -> Dict[str, str]:
    """``{column_name_lower: iceberg_type_str}`` from the CURRENT schema.

    Only top-level primitive (string-typed) fields are captured — nested /
    struct types come back as dicts and are skipped (bloom never targets
    them).  Returns {} on any shape error (callers treat missing as unknown
    → fail-open)."""
    out: Dict[str, str] = {}
    try:
        _sid = metadata.get("current-schema-id")
        _schemas = metadata.get("schemas") or []
        _cur = next(
            (s for s in _schemas if s.get("schema-id") == _sid),
            _schemas[0] if _schemas else None,
        )
        if _cur:
            for _f in _cur.get("fields") or []:
                _n, _ty = _f.get("name"), _f.get("type")
                if _n and isinstance(_ty, str):
                    out[str(_n).lower()] = _ty
    except Exception:
        return {}
    return out


def _decode_bound(raw: Optional[bytes], iceberg_type: str) -> Any:
    """Decode an Iceberg partition bound byte array to a Python value.

    Returns None if raw is None / empty.
    """
    if not raw:
        return None
    try:
        t = iceberg_type.lower()
        # Normalize transform types to their underlying storage format
        if t == "_transform_day":
            t = "date"       # int32 days since epoch
        elif t == "_transform_month":
            t = "_month"     # int32 months since epoch
        elif t == "_transform_year":
            t = "_year"      # int32 years since 1970
        elif t == "_transform_hour":
            t = "_hour"      # int64 hours since epoch
        # BF-502 (2026-05-28) — bucket/truncate bounds are stored in
        # the TRANSFORM-RESULT type, not the source type.  Iceberg spec:
        #   bucket(N, anytype)   → bucket-id as int32
        #   truncate(W, string)  → utf-8 string (truncated)
        #   truncate(W, int)     → int32
        #   truncate(W, decimal) → decimal in source scale
        # Without this branch we hit the bottom utf-8 fallback and
        # decode the int32 bucket-id BYTES as garbage characters.
        # User-visible symptom: sample-values UI on a bucket-partitioned
        # column shows control chars instead of bucket numbers.
        elif t.startswith("_transform_bucket["):
            # Bucket result is always int32 — return the integer.
            try:
                return struct.unpack_from("<i", raw)[0]
            except Exception as _be_exc:
                note_best_effort("struct.unpack_from('<i', raw)[0]", _be_exc,
                                 logger=logger)
        elif t.startswith("_transform_truncate["):
            # Truncate result type = source type.  Extract the source
            # type from the ``_transform_truncate[W]:source_type``
            # encoding and recursively decode.
            try:
                colon = t.index(":")
                _src_type = t[colon + 1:]
                return _decode_bound(raw, _src_type)
            except Exception as _be_exc:
                note_best_effort("_decode_bound(raw, _src_type)", _be_exc,
                                 logger=logger)
        if t in ("string", "varchar", "char", "uuid"):
            return raw.decode("utf-8")
        if t == "boolean":
            return raw[0] != 0
        if t in ("int", "integer", "date", "_month", "_year"):
            val = struct.unpack_from("<i", raw)[0]
            if t == "date":
                return str(_EPOCH + timedelta(days=val))
            if t == "_month":
                year = 1970 + val // 12
                month = 1 + val % 12
                return f"{year:04d}-{month:02d}"
            if t == "_year":
                return str(1970 + val)
            return val
        if t in ("long", "bigint", "time", "timestamp", "timestamptz",
                 "timestamp_tz", "timestamp with local time zone", "_hour"):
            val = struct.unpack_from("<q", raw)[0]
            if t in ("timestamp", "timestamptz", "timestamp_tz",
                     "timestamp with local time zone"):
                # microseconds since epoch → ISO datetime
                try:
                    dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=val)
                    return dt.isoformat()
                except Exception:
                    return str(val)
            if t == "_hour":
                try:
                    dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(hours=val)
                    return dt.strftime("%Y-%m-%d %H:00")
                except Exception:
                    return str(val)
            return val
        if t in ("float", "double"):
            # BF-600-L3 (2026-05-31): NaN/±Infinity in bounds is a
            # writer bug (no row should compare to NaN), but if it
            # appears we must NOT use it as a min/max — any compare
            # against NaN returns False, which silently skews pruning.
            # Returning None signals "no usable bound" → caller keeps
            # the file (correct fail-open).
            import math as _math_nan
            _val = (struct.unpack_from("<f", raw)[0] if t == "float"
                     else struct.unpack_from("<d", raw)[0])
            if _math_nan.isnan(_val) or _math_nan.isinf(_val):
                return None
            return _val
        if t.startswith("decimal"):
            # Iceberg spec §4.1.6: decimal bounds are big-endian two's-complement
            # unscaled integers. Decode using the scale parsed from the type string
            # (e.g. "decimal(10,2)" → scale=2 → divide by 100).
            # Phase 139 audit-fix Gap 10.
            #
            # BF-161 safety: bare "decimal" (no precision/scale) is unsafe — we
            # don't know the scale to apply, so we refuse to decode and let the
            # caller skip pruning (file stays in the result).
            if "(" not in t or ")" not in t:
                return None
            from decimal import Decimal as _Decimal
            try:
                inside = t[t.index("(") + 1: t.index(")")]
                parts = [p.strip() for p in inside.split(",")]
                scale = int(parts[1]) if len(parts) == 2 else 0
                unscaled = int.from_bytes(raw, byteorder="big", signed=True)
                if scale == 0:
                    return _Decimal(unscaled)
                return _Decimal(unscaled) / (_Decimal(10) ** scale)
            except Exception as _dec_exc:
                logger.debug("decimal decode failed (type=%s, raw=%r): %s",
                             iceberg_type, raw, _dec_exc)
                return None
        # Fallback: try utf-8
        return raw.decode("utf-8", errors="replace")
    except Exception as exc:
        logger.debug("_decode_bound failed for type=%s raw=%r: %s", iceberg_type, raw, exc)
        return None


def detect_iceberg_schema_evolution(metadata: dict) -> bool:
    """Return True when metadata.json carries multiple schema entries with
    differing field-id sets — i.e. columns were added/dropped over time.

    DuckDB CREATE VIEW over data files spanning evolved schemas needs
    `union_by_name=true` so it can read files written under older schemas.
    Without evolution, plain read_parquet is enough.

    Cheap structural check — no S3 I/O.  Reused by both setup_registered_views
    and the raw-SQL S3 path so they make the same union_by_name decision.
    """
    try:
        schemas = metadata.get("schemas") or []
        if len(schemas) <= 1:
            return False
        cur_id = metadata.get("current-schema-id")
        cur_schema = next(
            (s for s in schemas if s.get("schema-id") == cur_id),
            schemas[0],
        )
        cur_fids = {f.get("id") for f in (cur_schema.get("fields") or [])
                     if f.get("id") is not None}
        for s in schemas:
            if s is cur_schema:
                continue
            other_fids = {f.get("id") for f in (s.get("fields") or [])
                           if f.get("id") is not None}
            if cur_fids != other_fids:
                return True
        return False
    except Exception:
        # Fail-safe: assume evolution → union_by_name=true (slow but correct)
        return True


def detect_iceberg_type_conflicts(metadata: dict) -> bool:
    """Return True when the SAME field-id carries DIFFERENT types across schema
    versions (e.g. a column that was int, then bigint, then string).

    This is the SPECIFIC evolution shape that SEGFAULTS DuckDB 1.5.3 under
    ``union_by_name=true`` — name-based reconciliation of incompatible types
    crashes the engine.  Pure ADD/DROP-column evolution (the field-id SET
    changes but no field-id changes TYPE) is SAFE for union_by_name (it fills
    NULLs).  So this is the guard that decides whether union_by_name can be
    turned on at all.  Cheap structural check — no S3 I/O; walks nested
    struct/list/map so a nested type change is caught too."""
    try:
        schemas = metadata.get("schemas") or []
        if len(schemas) <= 1:
            return False
        fid_types: Dict[Any, set] = {}

        def _walk(fields):
            for f in (fields or []):
                if not isinstance(f, dict):
                    continue
                fid = f.get("id") if f.get("id") is not None else f.get("field-id")
                t = f.get("type", "string")
                if isinstance(t, dict):
                    _k = t.get("type", "string")
                    if fid is not None:
                        fid_types.setdefault(fid, set()).add(str(_k))
                    if _k == "struct":
                        _walk(t.get("fields"))
                    elif _k == "list" and isinstance(t.get("element"), dict):
                        _walk([{"id": t.get("element-id"), "type": t["element"]}])
                    elif _k == "map" and isinstance(t.get("value"), dict):
                        _walk([{"id": t.get("value-id"), "type": t["value"]}])
                elif fid is not None:
                    fid_types.setdefault(fid, set()).add(str(t))

        for s in schemas:
            _walk(s.get("fields"))
        return any(len(v) > 1 for v in fid_types.values())
    except Exception:
        # Fail-safe: a conflict we couldn't evaluate → assume YES so
        # union_by_name stays OFF (avoid the crash) rather than risk a segfault.
        return True


def _partition_pruning_columns(metadata: Optional[dict]) -> Optional[set]:
    """The lower-cased column names a partition predicate on THIS table may
    name (2026-10-08, for ``filter_ops.disjunction_decision``): every
    partition FIELD name of the default spec plus each field's SOURCE column
    (a ``month(dt)`` field is ``dt_month`` in the spec while the predicate
    says ``dt``).  None when the metadata cannot say, AND for an
    UNPARTITIONED table (an empty default spec): no branch can carry a
    partition predicate there, the per-file column-stats / bloom arms decide
    each branch, and their union is sound -- the decision then applies its
    structural rules only."""
    if not isinstance(metadata, dict):
        return None
    try:
        cols: set = set()
        spec = _extract_partition_spec(metadata) or {}
        cols.update(str(k).lower() for k in spec.keys())
        field_names: Dict[int, str] = {}
        for sch in (metadata.get("schemas") or
                    ([metadata["schema"]] if "schema" in metadata else [])):
            for f in (sch or {}).get("fields") or []:
                if isinstance(f, dict) and f.get("id") is not None and f.get("name"):
                    field_names[int(f["id"])] = str(f["name"]).lower()
        specs = metadata.get("partition-specs") or (
            [{"spec-id": 0, "fields": metadata.get("partition-spec") or []}]
            if metadata.get("partition-spec") else [])
        want = metadata.get("default-spec-id")
        for sp in specs:
            if want is not None and sp.get("spec-id") != want:
                continue
            for f in sp.get("fields") or []:
                if isinstance(f, dict):
                    if f.get("name"):
                        cols.add(str(f["name"]).lower())
                    src = f.get("source-id")
                    if src is not None and int(src) in field_names:
                        cols.add(field_names[int(src)])
        return cols or None
    except Exception as exc:  # noqa: BLE001 -- unknown is not a guess
        logger.debug("[island] partition columns unreadable from metadata: %s", exc)
        return None


def _extract_partition_spec(metadata: dict,
                            spec_id: Optional[int] = None) -> Dict[str, str]:
    """Return {partition_field_name: iceberg_type} from Iceberg metadata JSON.

    Handles both v1 (top-level "schema"/"partition-spec") and
    v2 (lists "schemas"/"partition-specs" with current IDs).

    2026-08-03 (spec-evolution DATA-LOSS FIX): ``spec_id`` selects a SPECIFIC
    partition spec instead of the default.  Manifest-list entries carry the
    spec their positional ``partitions`` summaries were written under
    (``partition_spec_id``); after spec evolution, indexing those summaries
    by the DEFAULT spec's field order compares the WRONG column's bounds.
    When an explicit ``spec_id`` cannot be resolved, {} is returned (the
    caller must fail-open and NOT prune with a guessed field order); the
    default path (``spec_id=None``) keeps its historical first-spec fallback.

    Phase 139 audit-fix Gap 4: detect partition-column type changes across
    schema versions (field-id appears with different types in different
    schemas). Old data files have bounds in the old type but we'd decode
    them with the current type — silently wrong. Log a WARNING so ops can
    spot it; pruning still uses the current type but at least the warning
    surfaces the risk.
    """
    # Build field_id → type map from schema(s) — track conflicts for Gap 4 audit
    field_type: Dict[int, str] = {}
    field_type_history: Dict[int, set] = {}  # fid -> set of types seen
    schemas = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
    # Pick the current schema (highest current-schema-id) so its type wins.
    current_schema_id = metadata.get("current-schema-id")
    # Iterate non-current schemas first, then current → current overwrites.
    if current_schema_id is not None:
        ordered_schemas = (
            [s for s in schemas if s.get("schema-id") != current_schema_id]
            + [s for s in schemas if s.get("schema-id") == current_schema_id]
        )
    else:
        ordered_schemas = schemas
    def _walk_fields(fields):
        # 2026-07 robustness: recurse into nested struct/list/map field
        # definitions so EVERY field-id (not just top-level) resolves to a type.
        # A partition whose source-id lives inside a struct was previously
        # invisible → its identity column got DROPPED from detection (F1 guard
        # below) → "no partition columns" → full ocean scan.
        for field in (fields or []):
            if not isinstance(field, dict):
                continue
            fid = field.get("id") or field.get("field-id")
            ftype = field.get("type", "string")
            if isinstance(ftype, dict):
                _kind = ftype.get("type", "string")
                if fid is not None:
                    field_type[fid] = str(_kind)
                    field_type_history.setdefault(fid, set()).add(str(_kind))
                # recurse into nested structures
                if _kind == "struct":
                    _walk_fields(ftype.get("fields"))
                elif _kind == "list":
                    _el = ftype.get("element")
                    _eid = ftype.get("element-id")
                    if isinstance(_el, dict):
                        _walk_fields([{"id": _eid, "type": _el}])
                    elif _eid is not None and _el is not None:
                        field_type[_eid] = str(_el)
                elif _kind == "map":
                    _vt = ftype.get("value")
                    _vid = ftype.get("value-id")
                    if isinstance(_vt, dict):
                        _walk_fields([{"id": _vid, "type": _vt}])
                    elif _vid is not None and _vt is not None:
                        field_type[_vid] = str(_vt)
            elif fid is not None:
                field_type[fid] = str(ftype)
                field_type_history.setdefault(fid, set()).add(str(ftype))

    for schema in ordered_schemas:
        _walk_fields(schema.get("fields", []))
    # Warn on type evolution
    for fid, types_seen in field_type_history.items():
        if len(types_seen) > 1:
            logger.warning(
                "Iceberg schema evolution: partition column field-id=%d had types %s "
                "across snapshots. Old data file bounds may decode incorrectly with the "
                "current type=%r. Pruning may produce wrong results for queries that span "
                "the schema-change boundary. Consider re-writing old data files with the "
                "current schema (compaction).",
                fid, sorted(types_seen), field_type.get(fid),
            )

    # Resolve active partition spec
    specs = metadata.get("partition-specs") or (
        [metadata["partition-spec"]] if "partition-spec" in metadata else []
    )
    if spec_id is not None:
        # Explicit spec requested (per-manifest resolution) — NO fallback:
        # returning a different spec's field order would re-create the
        # wrong-column-bounds bug this parameter exists to fix.
        active_spec = next(
            (s for s in specs
             if isinstance(s, dict) and s.get("spec-id") == spec_id), {})
    else:
        default_spec_id = metadata.get("default-spec-id", 0)
        active_spec = next(
            (s for s in specs if s.get("spec-id") == default_spec_id), specs[0] if specs else {}
        )

    result: Dict[str, str] = {}
    for pf in active_spec.get("fields", []):
        name      = pf.get("name", "")
        source_id = pf.get("source-id") or pf.get("source_id")
        transform = pf.get("transform", "identity")
        if not name:
            continue
        # Only identity-transformed fields have meaningful bounds we can compare.
        # bucket/truncate transforms store bucket-numbers (not source values) in bounds —
        # comparing user filter values against bucket-number bounds causes data loss.
        # void partitions have no data — skip entirely.
        if transform in ("void",):
            continue
        # Phase 139 audit-fix Gap 2: bucket/truncate now supported for
        # equality (and limited range for truncate) predicates. Encode them
        # in the type string as ``_transform_bucket[N]:source_type`` so the
        # entry-level pruner can apply the transform to user filter values
        # before comparing.
        from core.iceberg_transforms import parse_transform as _pt
        kind, param = _pt(transform)
        if kind == "identity":
            _src_ty = field_type.get(source_id)
            if _src_ty is None:
                # 2026-07-15 DATA-LOSS FIX (audit Finding F1): the source
                # column's type couldn't be resolved (schema evolution
                # dropped/renamed the source column, or a source-id key
                # mismatch).  Defaulting to "string" would decode a DATE
                # partition's int-days bound as a raw int ('20361') and then
                # skip EVERY file for a 'YYYY-MM-DD' equality filter (full data
                # loss).  Leave the column UNregistered for partition pruning →
                # its WHERE filter falls to the (fail-open) column-stats path
                # instead of being wrongly pruned here.
                logger.warning(
                    "Iceberg identity partition '%s' (source-id=%s) has no "
                    "resolvable type in the current schema — NOT registering it "
                    "for partition pruning (fail-open; avoids mis-decoding a "
                    "typed bound as a raw int).",
                    name, source_id,
                )
                continue
            result[name] = _src_ty
            continue
        if kind in ("year", "month", "day", "hour"):
            # date-based transforms: bounds are ints (year/month/day/hour counts)
            result[name] = f"_transform_{kind}"
            continue
        if kind in ("bucket", "truncate") and param is not None:
            src_type = field_type.get(source_id, "string")
            result[name] = f"_transform_{kind}[{param}]:{src_type}"
            logger.info(
                "Iceberg partition transform '%s(%d)' on column '%s' (source type=%s) "
                "registered for pruning — equality predicates will be transformed.",
                kind, param, name, src_type,
            )
            continue
        # Unknown / unsupported
        logger.warning(
            "Iceberg partition transform '%s' on column '%s' is not supported for "
            "pruning — full scan will be performed for this column. "
            "Supported: identity, year, month, day, hour, bucket(N), truncate(W).",
            transform, name,
        )

    return result


def _active_spec_field_count(metadata: dict) -> int:
    """Non-void field count on the ACTIVE partition spec — the raw
    'is this table partitioned?' truth, INDEPENDENT of whether
    _extract_partition_spec could resolve source names/types (its F1 guard
    deliberately DROPS identity fields with an unresolvable source type; that
    guard must never be able to silently declare a partitioned table
    unpartitioned).  Used by the partition-resolver's is_partitioned signal and
    the reader's partition-pruning control."""
    try:
        specs = metadata.get("partition-specs") or (
            [metadata["partition-spec"]] if "partition-spec" in metadata else [])
        if not specs:
            return 0
        _dsid = metadata.get("default-spec-id", 0)
        _active = next((s for s in specs if s.get("spec-id") == _dsid), specs[0])
        return sum(1 for f in (_active.get("fields") or [])
                   if isinstance(f, dict)
                   and (f.get("transform") or "identity") != "void")
    except Exception:
        return 0


def _positional_partition_zip_safe(metadata: dict) -> bool:
    """2026-08-03 (spec-evolution DATA-LOSS FIX) — is it PROVABLY safe to
    attribute a POSITIONAL partition tuple via the DEFAULT spec's key order?

    Some writers/decoders yield an entry's partition record as a positional
    list; the reader coerces it with ``dict(zip(default_spec_keys, values))``.
    That attribution is only correct when the tuple was written under a spec
    whose field order is a PREFIX of (or equal to) the default spec's —
    otherwise value[i] belongs to a DIFFERENT column and the partition
    pruner compares the wrong value.  This deployment has had spec
    evolution, so the condition must be PROVEN, not assumed.

    Returns True when metadata has at most one spec, or when EVERY spec's
    field-name sequence is a prefix of the default spec's.  Any doubt
    (shape errors included) returns False → the caller treats positional
    tuples as no-partition-info (KEEP; never prunes on a guess).
    """
    try:
        specs = metadata.get("partition-specs") or []
        if len(specs) <= 1:
            return True
        _dsid = metadata.get("default-spec-id", 0)
        _default = next(
            (s for s in specs
             if isinstance(s, dict) and s.get("spec-id") == _dsid), None)
        if not isinstance(_default, dict):
            return False
        _def_names = [str((f or {}).get("name", "")).lower()
                      for f in (_default.get("fields") or [])]
        for s in specs:
            if not isinstance(s, dict):
                return False
            _names = [str((f or {}).get("name", "")).lower()
                      for f in (s.get("fields") or [])]
            if _names != _def_names[:len(_names)]:
                return False
        return True
    except Exception:
        return False


class IcebergPartitionPruningError(ValueError):
    """iceberg.require_partition_pruning=true and a partition predicate could
    not be engaged for pruning on a partitioned table — the query fails CLOSED
    instead of silently full-scanning the ocean.  ValueError subclass so it
    rides the same user-facing surfacing path as the max-files-per-query cap."""


def build_source_to_partition_field_map(metadata: dict) -> Dict[str, str]:
    """Return {source_column_name_lower: partition_field_name} from Iceberg
    metadata.

    Iceberg writers commonly rename partition fields when applying transforms
    (e.g. day(business_close_date) → partition field 'business_close_date_day').
    Manifest bounds are keyed by the partition FIELD name, but admins typically
    type the SOURCE column name in filter UIs.  Use this map to rewrite
    user-supplied filter column names so manifest pruning kicks in.

    Resolution: uses default-spec-id and current-schema-id (matches what the
    bounds were actually written with).  Falls back to first spec / schema.
    """
    result: Dict[str, str] = {}
    schemas = metadata.get("schemas") or (
        [metadata["schema"]] if "schema" in metadata else []
    )
    csid = metadata.get("current-schema-id")
    cur_schema = next(
        (s for s in schemas if s.get("schema-id") == csid),
        schemas[0] if schemas else {},
    )
    fid_to_name: Dict[int, str] = {}
    for f in cur_schema.get("fields", []):
        fid = f.get("id") or f.get("field-id")
        nm = f.get("name", "")
        if fid is not None and nm:
            fid_to_name[fid] = nm

    specs = metadata.get("partition-specs") or []
    # v1 metadata has a flat list of field dicts under "partition-spec"
    # (no spec-id / fields wrapper).
    if not specs and "partition-spec" in metadata:
        ps = metadata["partition-spec"]
        if isinstance(ps, list):
            specs = [{"spec-id": 0, "fields": ps}]
        elif isinstance(ps, dict):
            specs = [ps]
    dsid = metadata.get("default-spec-id", 0)
    active = next(
        (s for s in specs if s.get("spec-id") == dsid),
        specs[0] if specs else {},
    )
    for pf in active.get("fields", []):
        src_id = pf.get("source-id") or pf.get("source_id")
        pname = pf.get("name", "")
        if src_id is None or not pname:
            continue
        sname = fid_to_name.get(src_id)
        if sname and sname.lower() != pname.lower():
            # Only register when names differ — identity case doesn't need rewrite.
            result[sname.lower()] = pname
    return result


def extract_partition_identity_names(metadata: dict) -> Set[str]:
    """2026-08-02 — partition-column IDENTITY resolution (names only, no I/O).

    Defect-free identity companion to :func:`_extract_partition_spec` /
    :func:`build_source_to_partition_field_map`, per
    ``docs/iceberg_partition_identity_design.md`` (defect 4).  Those two are
    DECODE maps: they key by derived partition-field name, resolve source
    names against the current schema's TOP-LEVEL fields only, and (correctly,
    for bound decoding — the F1 guard) DROP identity fields whose source type
    is unresolvable.  All three properties are wrong for *identifying* whether
    a WHERE column IS a partition column — which is what the partition-pruning
    control/alarm needs.  On a schema-evolved table (the 97-schema prod
    incident) the decode maps came back empty, the query's own partition
    predicate was classified "not a partition column", and the alarm reported
    case B ("no partition filter") for the exact case-A engine failure it was
    built to catch.

    Returns the LOWER-CASED union of, for every non-void partition field in
    EVERY spec (v1 + v2 metadata forms, ALL spec-ids — a ``default-spec-id``
    pointing at an unpartitioned spec must not hide older partitioned specs
    that wrote the existing data files):

      * the partition FIELD name (e.g. ``business_close_date_day``) — kept
        even when the source id / type is unresolvable (identity ≠ decode);
      * the SOURCE column name, resolved via a nested (struct/list/map) walk
        across ALL schemas, current-schema-id winning on conflicts.

    Matching stays EXACT (by field-id / literal name) — no fuzzy matching, no
    suffix stripping, so two different columns can never alias.  This function
    NEVER prunes by itself: consumers use it only to CLASSIFY predicates
    (alarm / telemetry), so more names can only ever let pruning *consider*
    more columns through the existing fail-open paths — never exclude a file.
    Pure + total: any parse error returns whatever was gathered (fail-open).
    """
    names: Set[str] = set()
    try:
        # field-id → name across ALL schemas, nested; current schema wins.
        fid_to_name: Dict[Any, str] = {}
        schemas = metadata.get("schemas") or (
            [metadata["schema"]] if "schema" in metadata else [])
        csid = metadata.get("current-schema-id")
        if csid is not None:
            ordered_schemas = (
                [s for s in schemas if isinstance(s, dict)
                 and s.get("schema-id") != csid]
                + [s for s in schemas if isinstance(s, dict)
                   and s.get("schema-id") == csid])
        else:
            ordered_schemas = [s for s in schemas if isinstance(s, dict)]

        def _walk_names(fields):
            for f in (fields or []):
                if not isinstance(f, dict):
                    continue
                fid = f.get("id") if f.get("id") is not None else f.get("field-id")
                nm = f.get("name")
                if fid is not None and nm:
                    fid_to_name[fid] = str(nm)
                ftype = f.get("type")
                if isinstance(ftype, dict):
                    _kind = ftype.get("type")
                    if _kind == "struct":
                        _walk_names(ftype.get("fields"))
                    elif _kind == "list" and isinstance(ftype.get("element"), dict):
                        _walk_names([{"id": ftype.get("element-id"),
                                      "type": ftype["element"]}])
                    elif _kind == "map":
                        if isinstance(ftype.get("key"), dict):
                            _walk_names([{"id": ftype.get("key-id"),
                                          "type": ftype["key"]}])
                        if isinstance(ftype.get("value"), dict):
                            _walk_names([{"id": ftype.get("value-id"),
                                          "type": ftype["value"]}])

        for _sch in ordered_schemas:
            _walk_names(_sch.get("fields"))

        # Union of partition fields across ALL specs (v1 + v2 shapes).
        specs = [s for s in (metadata.get("partition-specs") or [])
                 if isinstance(s, dict)]
        if not specs and "partition-spec" in metadata:
            _ps = metadata["partition-spec"]
            if isinstance(_ps, list):          # v1 flat field list
                specs = [{"fields": _ps}]
            elif isinstance(_ps, dict):
                specs = [_ps]
        for _spec in specs:
            for pf in (_spec.get("fields") or []):
                if not isinstance(pf, dict):
                    continue
                if (pf.get("transform") or "identity") == "void":
                    continue
                _pf_name = pf.get("name")
                if _pf_name:
                    names.add(str(_pf_name).strip().lower())
                _src_id = (pf.get("source-id") if pf.get("source-id") is not None
                           else pf.get("source_id"))
                _src_name = fid_to_name.get(_src_id) if _src_id is not None else None
                if _src_name:
                    names.add(str(_src_name).strip().lower())
        names.discard("")
    except Exception as _pid_exc:
        logger.debug(
            "extract_partition_identity_names failed (fail-open, returning "
            "%d name(s) gathered so far): %s", len(names), _pid_exc)
    return names


# ── Schema index for column statistics pushdown ───────────────────────────────

def _build_schema_index(metadata: dict) -> Tuple[Dict[int, str], Dict[str, int]]:
    """Return (fid_to_type, name_lower_to_fid) from Iceberg metadata schema.

    fid_to_type  : {field_id: iceberg_type_str}
    name_lower_to_fid: {column_name.lower(): field_id}

    Used for column statistics pushdown — matching filter column names to the
    field IDs that appear as keys in data_file.lower_bounds / upper_bounds.

    Only considers the current (highest-id) schema.
    """
    fid_to_type: Dict[int, str] = {}
    name_lower_to_fid: Dict[str, int] = {}

    schemas = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
    # Use the schema with the highest schema-id (most up-to-date)
    current_schema_id = metadata.get("current-schema-id")
    if current_schema_id is not None:
        active = next((s for s in schemas if s.get("schema-id") == current_schema_id), None)
    else:
        active = schemas[-1] if schemas else None
    if active is None and schemas:
        active = schemas[0]
    if active is None:
        return fid_to_type, name_lower_to_fid

    def _normalise_type(raw_type) -> str:
        """Collapse Iceberg type to the string expected by _decode_bound.

        Phase 139 audit-fix Gap 10: preserve decimal(precision,scale) so
        _decode_bound can use the scale to decode unscaled big-endian bounds.
        """
        if isinstance(raw_type, dict):
            # nested struct / list / map — not useful for stats comparison
            return "struct"
        s = str(raw_type).lower().strip()
        if s.startswith("decimal"):
            # Keep "decimal(10,2)" form so the scale is available for decoding.
            return s
        if s.startswith("fixed") or s.startswith("binary"):
            return "binary"
        if s in ("int", "integer"):
            return "int"
        if s in ("long", "bigint"):
            return "long"
        if "timestamp" in s:
            return "timestamptz" if "tz" in s or "zone" in s else "timestamp"
        return s  # string, date, float, double, boolean, time, uuid …

    for field in active.get("fields", []):
        fid = field.get("id") or field.get("field-id")
        name = field.get("name", "")
        raw_type = field.get("type", "string")
        if fid is None or not name:
            continue
        fid_to_type[int(fid)] = _normalise_type(raw_type)
        name_lower_to_fid[name.lower()] = int(fid)

    return fid_to_type, name_lower_to_fid


# ── 2026-07-31 — Phase-2 temporal-spelling guards (families E / F / G) ────────
# Siblings of the Phase-1 ``_partition_value_string_match`` 4th arm (c3a4e029)
# and the family-C/D fixes (b6215de6).  VERIFIED DEFECT at HEAD: for a NON-ISO
# temporal literal ('30 sep 2025') against ISO-decoded bounds ('2025-09-30'),
# the per-file column-stats matcher, the manifest-LIST matcher and the
# supplement-bounds matcher each compare LEXICOGRAPHICALLY ('3…' > '2…') and
# PRUNE every file — including the one holding matching rows.  The BF-509
# bare-date bridges only fire for a 10-char ISO literal, so they cannot help.
#
# The fix is a FAIL-OPEN GUARD, not a rewrite (the rewrite approach was
# reverted in 7284185b for causing data loss): when the DECLARED type is
# temporal AND the literal is a non-ISO spelling that predicate_coerce can
# parse, the matcher SKIPS that filter (= keeps the file/manifest).  Genuine
# VARCHAR columns are untouched BY CONSTRUCTION — the guard is gated on the
# declared type, so byte-wise stats keep their lexicographic semantics.
# Exclusion predicates (!=, NOT IN, NOT BETWEEN, NOT LIKE) are deliberately
# NOT guarded: there "these are equal" would justify DROPPING a file, and
# their existing exact-equality compares cannot mis-prune on spelling.
import re as _re_t31  # noqa: E402
from core.best_effort import note_best_effort

_ISO_DATE_PREFIX_RE_T31 = _re_t31.compile(r"^\d{4}-\d{2}-\d{2}")

# Declared types on which the guard may fire.  ``date`` + the timestamp
# spellings _normalise_type emits, plus the temporal partition-transform
# pseudo-types (both the bare "_day"-style names used by the column-stats
# coercion branches and the "_transform_day"-style names used by the
# manifest partition specs).  NEVER "string"/"varchar".
_TEMPORAL_DECLARED_TYPES_T31 = frozenset({
    "date", "timestamp", "timestamptz", "timestamp_tz",
    "timestamp with local time zone",
    "_day", "_hour", "_month", "_year",
})
_TEMPORAL_TRANSFORM_PREFIXES_T31 = (
    "_transform_day", "_transform_hour", "_transform_month", "_transform_year",
)

# Ops the guard covers: INCLUSION comparisons only (a skipped filter = keep,
# which is fail-open for these).  ``in`` is handled separately because its
# value is a list.
_TEMPORAL_GUARD_OPS_T31 = frozenset({
    "equals", "eq", "=", "==",
    "gt", ">", "greater_than", "gte", ">=", "greater_equals",
    "lt", "<", "less_than", "lte", "<=", "less_equals",
})


def _is_temporal_declared_type(t: Any) -> bool:
    """True when ``t`` is a DECLARED temporal type (schema field type or
    partition-spec type).  False for anything string-like — that is the
    entire VARCHAR safety argument, so keep this list conservative."""
    if not isinstance(t, str):
        return False
    return (t in _TEMPORAL_DECLARED_TYPES_T31
            or t.startswith(_TEMPORAL_TRANSFORM_PREFIXES_T31))


def _noniso_parseable_temporal_literal(v: Any) -> bool:
    """True when ``v`` is a STRING temporal literal in a NON-ISO spelling
    that ``predicate_coerce._to_datetime`` can parse — '30 sep 2025',
    '2025-Sep-30', 'September 30, 2025 13:00'.

    False (guard does not fire, behaviour stays exactly today's) for:
      * non-strings and empty strings;
      * anything starting YYYY-MM-DD — the BF-509 bridges and the plain
        lexicographic compare already handle ISO shapes correctly, and
        firing there would needlessly weaken pruning;
    2026-07-31 AUDIT FIX — also True for AMBIGUOUS date-ish spellings
    ('01/02/2025', '02-01-2025', '30 sep 25').  Previously those fell through
    to a lexicographic compare against ISO bounds and PRUNED EVERY FILE.
    Executed proof: DATE column, bounds [2025-01-01, 2025-03-01], filter
    ``= '01/02/2025'`` -> keep=False at E, F and G — the file containing BOTH
    candidate readings (Jan-2 and Feb-1) was dropped.

    DuckDB itself REFUSES those literals with a Conversion Error, so pruning
    every file turns a LOUD engine error into a SILENT 0-row success — strictly
    worse than a full scan that lets the engine raise.  "Cannot read it" is a
    reason to KEEP, never to prune.

    Never raises.
    """
    if not isinstance(v, str):
        return False
    s = v.strip()
    if not s or _ISO_DATE_PREFIX_RE_T31.match(s):
        return False
    try:
        from core.predicate_coerce import (
            _to_datetime as _tdt,
            is_ambiguous_temporal_literal as _amb,
        )
        # Parseable non-ISO (e.g. '30 sep 2025', '2025/01/02') OR date-shaped
        # but unreadable — both mean "a lexicographic compare against ISO
        # bounds is meaningless here", which is exactly when we must keep.
        return _tdt(s) is not None or _amb(s)
    except Exception:                                        # pragma: no cover
        return False


def _coerce_listed_value(v, lo):
    """Coerce one IN/NOT-IN list member to the bound's type, SAFELY.

    2026-08-19 — the two list branches used a bare ``type(lo)(v)``.  For a
    BOOLEAN column that is ``bool(v)``, and ``bool('false')`` is **True** —
    Python's truthiness of a non-empty string, not a parse.  Consequences,
    both silent file drops:

      * bounds lo=hi=False, ``IN ('false')``  -> coerced True, outside
        [False, False] -> "all out" -> file dropped, though every row matches.
      * bounds lo=hi=True, ``NOT IN ('false')`` -> coerced True == lo ->
        file dropped, though every row satisfies the predicate.

    String-valued booleans are the normal shape from a UI/JSON filter, so this
    is reachable from an ordinary query.  The ``equals`` branch already had a
    careful case-insensitive parser (BF-600a); these branches bypassed it.

    Returns the coerced value, or ``None`` to mean "cannot coerce" — callers
    treat that as fail-open (keep the file) rather than guessing.
    """
    if isinstance(lo, bool):
        if isinstance(v, bool):
            return v
        if isinstance(v, (int, float)):
            return bool(int(v))
        _bs = str(v).strip().lower()
        if _bs in ("true", "t", "1", "yes"):
            return True
        if _bs in ("false", "f", "0", "no"):
            return False
        return None                      # unrecognised -> keep the file
    try:
        return type(lo)(v)
    except (ValueError, TypeError):
        return None


def _avro_kv_map(raw) -> dict:
    """Normalise an Iceberg Avro map field to a plain dict.

    2026-08-21 — FOUND IN PRODUCTION by the fail-open diagnostic added the
    same day, which printed the stack on the first failure:

        column-stats pruning FAILED OPEN on its first candidate ...
        AttributeError: 'list' object has no attribute 'get'
          iceberg_reader.py:2452  lo_bytes = _get_bound(lb_raw, fid)
          iceberg_reader.py:2388  v = bounds.get(fid)

    ``lower_bounds`` / ``upper_bounds`` / ``null_value_counts`` /
    ``value_counts`` are declared ``map<int, X>`` in the Iceberg spec, but Avro
    has two on-the-wire encodings for a map and writers pick either:

        {123: b'...'}                                   -- decoded as a dict
        [{'key': 123, 'value': b'...'}, ...]            -- array-of-KV structs

    Every consumer in this file assumed the dict form, so on a table written
    with the array form EVERY per-file bounds lookup raised AttributeError
    straight into a fail-open handler: column-stats pruning silently pruned
    NOTHING and every candidate was kept "on no evidence" (the operator's
    `column_stats: 3001`, then `column_stats: 11`).

    Accepts either shape, plus the string-keyed variant Avro produces for map
    keys, and returns {} for anything unrecognised (fail-open, unchanged).
    """
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, (list, tuple)):
        out = {}
        for item in raw:
            if isinstance(item, dict):
                # canonical KV struct
                if "key" in item:
                    out[item.get("key")] = item.get("value")
                    continue
                # some decoders emit a single-entry dict per element
                if len(item) == 1:
                    _k, _v = next(iter(item.items()))
                    out[_k] = _v
                    continue
            elif isinstance(item, (list, tuple)) and len(item) == 2:
                out[item[0]] = item[1]
        return out
    return {}


# ── 2026-08-21 — CLOSING THE BOOTSTRAP LOOP ─────────────────────────────
# The file index (per-file rows keyed by snapshot) is what makes enumeration
# O(island) instead of O(table).  Its PRODUCER is the background metadata
# sync, which reads UNFILTERED and therefore enumerates completely.
#
# When that producer is not running, the store can never populate, because the
# CONSUMER cannot fill it:
#     storing requires a COMPLETE enumeration
#     complete requires all N manifests
#     a filtered query reads only the ones bounds-pruning kept  (the point!)
#     completing from cache needs the pruned ones already cached
#     nothing ever reads them, so they never are
# A closed loop with no entry point.  The operator sees it as
# "bounds-pruned walk cannot be completed - 18 pruned manifest(s), at least
# one not in the manifest cache" on every single execution, forever.
#
# The missing manifests are IMMUTABLE and small (~1 MB).  Fetching them once
# per snapshot permanently populates the index; after that enumeration is a
# database seek.  We do it OFF the query's critical path so the query that
# discovers the gap pays nothing, and single-flight so N concurrent queries
# do not fetch the same manifests N times.
_BOOTSTRAP_INFLIGHT: Set[str] = set()
_BOOTSTRAP_LOCK = threading.Lock()


def _bootstrap_manifest_cache_async(bucket: str, table_prefix: str,
                                    snapshot_id: str, missing_keys: List[str],
                                    s3_client, db_manager=None,
                                    probe_missing: bool = False) -> bool:
    """Warm the per-manifest cache for `missing_keys` in the background.

    Returns True when a worker was started.  Never raises, never blocks, and
    never touches the caller's result — the only effect is that the NEXT read
    of this snapshot can complete its enumeration and store it.

    ``probe_missing=True`` (2026-08-22): ``missing_keys`` is a CANDIDATE set
    (e.g. every bounds-pruned manifest) and the worker thread first probes the
    L1/L2 cache to find which are genuinely absent — moving that probe pass
    off the caller's critical path.  The cap then applies to the PROBED
    missing count, not the candidate count.
    """
    try:
        _cap = 200
        try:
            from core.config import get as _bs_cfg
            _cap = int(_bs_cfg("iceberg", "bootstrap_max_manifests", 200) or 200)
        except Exception as _cap_exc:
            # Not silent: falling back to the built-in cap changes how much
            # work this does, so a config failure must leave a trace.
            logger.debug("[bootstrap] cap lookup failed, using %d: %s",
                         _cap, _cap_exc)
        if not missing_keys or not snapshot_id or s3_client is None:
            return False
        if not probe_missing and _cap > 0 and len(missing_keys) > _cap:
            logger.warning(
                "[bootstrap] %s: %d manifest(s) missing from the cache, above "
                "the %d cap — NOT warming.  This table's file index cannot be "
                "built from the query path; run the background metadata sync "
                "(or raise iceberg.bootstrap_max_manifests).",
                table_prefix, len(missing_keys), _cap)
            return False

        _tag = f"{bucket}/{table_prefix}@{snapshot_id}"
        with _BOOTSTRAP_LOCK:
            if _tag in _BOOTSTRAP_INFLIGHT:
                return False          # single-flight: one warm per snapshot
            _BOOTSTRAP_INFLIGHT.add(_tag)

        def _run() -> None:
            _ok = 0
            try:
                from core import iceberg_snapshot_cache as _bs_isc
                _work_keys = missing_keys
                if probe_missing:
                    # Off-path now: L1/L2-only peeks, then the cap applies
                    # to what is genuinely absent.
                    _probed = []
                    for _pk2 in missing_keys:
                        try:
                            if _bs_isc.peek_manifest_entries(
                                    bucket, _pk2) is None:
                                _probed.append(_pk2)
                        except Exception:
                            _probed.append(_pk2)
                    _work_keys = _probed
                    if not _work_keys:
                        logger.info(
                            "[bootstrap] %s snapshot=%s: probe found no "
                            "missing manifests (raced a concurrent warm) — "
                            "nothing to fetch.", table_prefix, snapshot_id)
                        return
                    if _cap > 0 and len(_work_keys) > _cap:
                        logger.warning(
                            "[bootstrap] %s: %d manifest(s) missing from the "
                            "cache, above the %d cap — NOT warming.  Run the "
                            "background metadata sync (or raise "
                            "iceberg.bootstrap_max_manifests).",
                            table_prefix, len(_work_keys), _cap)
                        return
                for _mk in _work_keys:
                    try:
                        _bs_isc.get_or_fetch_manifest_entries(
                            bucket=bucket, manifest_path=_mk,
                            fetch_fn=lambda _b, _k: _read_avro(
                                _read_s3_bytes(s3_client, _b, _k)),
                        )
                        _ok += 1
                    except Exception as _one:
                        logger.debug("[bootstrap] %s: manifest %s failed: %s",
                                     table_prefix, _mk, _one)
                logger.info(
                    "[bootstrap] %s snapshot=%s: warmed %d/%d pruned "
                    "manifest(s).  The next read of this snapshot can store a "
                    "COMPLETE enumeration, after which file lookup is a "
                    "database seek instead of an S3 walk.",
                    table_prefix, snapshot_id, _ok, len(_work_keys))
            except Exception as _exc:
                logger.warning("[bootstrap] %s: warm failed (%s: %s)",
                               table_prefix, type(_exc).__name__, str(_exc)[:200])
            finally:
                with _BOOTSTRAP_LOCK:
                    _BOOTSTRAP_INFLIGHT.discard(_tag)

        threading.Thread(target=_run, daemon=True,
                         name=f"iceberg-bootstrap-{table_prefix[-24:]}").start()
        return True
    except Exception as _outer:
        logger.debug("[bootstrap] not started (fail-open): %s", _outer)
        return False


def _file_matches_column_stats(
    data_file: dict,
    non_partition_filters: List[Dict[str, Any]],
    fid_to_type: Dict[int, str],
    name_lower_to_fid: Dict[str, int],
    *,
    string_partition_cols: Optional[set] = None,
) -> bool:
    """Return False if we can *prove* this Parquet file contains no rows satisfying
    all non-partition filters using Iceberg column min/max statistics.

    ``string_partition_cols`` (2026-10-06): lower-cased names of the STRING
    identity-partition columns the filters name.  A range on one of them is
    decided by ``core.filter_ops.string_partition_range_decision`` -- THE one
    decision for "may a range prune a string partition?" -- and by nothing
    else: its ``drop`` drops the file, a refusal KEEPS it.  Column
    stats are applied to partition columns too (BF-252), so this stage was a
    fourth pruner answering that question lexically on its own.

    This is the Iceberg equivalent of Parquet row-group pruning but at FILE level:
    the Iceberg manifest stores per-data-file lower_bound/upper_bound for every
    column that the writer chose to track.

    Returns True (keep file) when:
      - column stats are absent for this file / field
      - the comparison type cannot be safely decoded
      - the filter column is not in the schema
      - the bounds don't prove the file is empty for this filter (safe over-approximation)

    Also handles ``is_null`` / ``is_not_null`` predicates via the data_file's
    ``null_value_counts`` map (also recorded in the manifest by the writer):
      - ``IS NULL``: file is provably empty when null_count == 0
      - ``IS NOT NULL``: file is provably empty when null_count == record_count

    Maps from data_file may have string-encoded field IDs (Avro map keys are strings).
    """
    lb_raw = _avro_kv_map(data_file.get("lower_bounds"))
    ub_raw = _avro_kv_map(data_file.get("upper_bounds"))
    null_counts_raw = _avro_kv_map(data_file.get("null_value_counts"))
    record_count = data_file.get("record_count") or 0

    # No bounds AND no null counts → can't prune anything → keep file.
    if not lb_raw and not ub_raw and not null_counts_raw:
        return True

    # Normalise map keys: Avro stores map keys as strings; field IDs are ints
    def _get_bound(bounds: dict, fid: int) -> Optional[bytes]:
        """Look up a field in an Avro map that may have int or string keys.

        Uses explicit None-check rather than 'or' to handle b"" (empty bytes is
        valid in Iceberg for e.g. empty-string min bounds and is falsy).
        """
        v = bounds.get(fid)
        if v is None:
            v = bounds.get(str(fid))
        if isinstance(v, (bytes, bytearray)):
            return bytes(v)
        return None

    import re as _re_cs
    _cast_re = _re_cs.compile(r"^(?:DATE|TIMESTAMP|TIME)\s+'(.+)'$", _re_cs.IGNORECASE)

    def _get_null_count(fid: int) -> Optional[int]:
        """Read null_value_counts[fid] handling int/string Avro map keys."""
        v = null_counts_raw.get(fid)
        if v is None:
            v = null_counts_raw.get(str(fid))
        if isinstance(v, (int,)) or (isinstance(v, str) and v.isdigit()):
            return int(v)
        return None

    for filt in non_partition_filters:
        col_raw = filt.get("col") if filt.get("col") is not None else filt.get("column", "")
        op      = filt.get("op")  if filt.get("op")  is not None else filt.get("operator", "")
        val     = filt.get("val") if filt.get("val") is not None else filt.get("value", "")

        # Strip table-qualified prefix  "schema.table.col" → "col"
        col_lower = col_raw.split(".")[-1].lower()
        fid = name_lower_to_fid.get(col_lower)
        if fid is None:
            # BF-600-L4 (2026-05-31): newly-added columns intentionally fall
            # through to "keep file".  When a column is added in a snapshot
            # AFTER some files were written, those older files have NO
            # field-id entry in name_lower_to_fid (built from current
            # schema only).  Pruning would be unsafe — we don't know what
            # the old files contained for that column.  Fail-open: keep
            # the file, let DuckDB's read-time filter handle the row-level
            # exclusion (returns NULL for the missing column by Iceberg
            # spec, then DuckDB applies the WHERE).
            continue

        # ── IS NULL / IS NOT NULL via null_value_counts ──────────────────
        # These don't need lower/upper bounds — only the null count.
        if op in ("is_null", "isnull"):
            nc = _get_null_count(fid)
            if nc is not None and nc == 0:
                return False  # file has zero nulls in this col → can't satisfy IS NULL
            continue
        if op in ("is_not_null", "isnotnull"):
            nc = _get_null_count(fid)
            if nc is not None and record_count and nc >= record_count:
                return False  # every row in this col is null → can't satisfy IS NOT NULL
            continue

        ftype = fid_to_type.get(fid, "string")
        # Phase 139 audit-fix Gap 10: decimal IS now decodable using the scale
        # from the type string ("decimal(10,2)"). Removed from the skip list.
        # BF-600a (2026-05-31): boolean IS now safely comparable.  Was in
        # skip list pre-fix → every WHERE bool_col = true on an iceberg
        # table scanned every file, even when bounds metadata clearly
        # showed the file held only the opposite value.  _decode_bound
        # already supports boolean (returns Python bool); the only
        # missing piece was the comparison.
        if ftype in ("struct", "list", "map", "binary", "uuid"):
            continue  # not safely comparable

        lo_bytes = _get_bound(lb_raw, fid)
        hi_bytes = _get_bound(ub_raw, fid)
        if lo_bytes is None and hi_bytes is None:
            continue  # column stats not tracked for this field → keep

        lo = _decode_bound(lo_bytes, ftype) if lo_bytes else None
        hi = _decode_bound(hi_bytes, ftype) if hi_bytes else None

        # Normalise filter value — strip DuckDB cast syntax e.g. "DATE '2024-01-01'"
        val_str = str(val)
        _m = _cast_re.match(val_str)
        val_norm = _m.group(1) if _m else val_str
        # Astral-safe LIKE ceiling: a bound ending in the legacy U+FFFF
        # like-prefix sentinel (from the extractor's ``col <= prefix+ceiling``
        # decomposition) is upgraded to U+10FFFF so a supplementary-plane
        # (emoji / CJK-ext-B) file value isn't wrongly pruned by less_equals.
        from core.predicate_coerce import normalize_like_ceiling as _nlc
        val_norm = _nlc(val_norm)

        # 2026-10-06 -- a range on a STRING PARTITION column: the one decision.
        if (string_partition_cols and col_lower in string_partition_cols
                and op in _STRING_RANGE_STAGE_OPS):
            from core.filter_ops import (
                string_partition_range_decision as _spd_cs)
            _d_cs = _spd_cs(ftype, op, _range_literal(val, val_norm), lo, hi,
                            literal_kind=filt.get("literal_kind"))
            if _d_cs.applies:
                if _d_cs.drop:
                    return False
                continue   # kept by the one decision (refused or matching)

        # Convert filter value to comparable Python type
        try:
            cval: Any = val_norm
            if ftype in ("int", "integer", "date", "_month", "_year"):
                cval = int(val_norm) if val_norm.lstrip("-").isdigit() else val_norm
                # If lo/hi are ISO date strings but val_norm is a date string → keep as string
                if lo and isinstance(lo, str) and "-" in lo:
                    cval = val_norm
            elif ftype in ("long", "bigint", "_hour"):
                cval = int(val_norm) if val_norm.lstrip("-").isdigit() else val_norm
                if lo and isinstance(lo, str):
                    cval = val_norm
            elif ftype in ("float", "double"):
                cval = float(val_norm)
                if lo is not None:
                    lo = float(lo)
                if hi is not None:
                    hi = float(hi)
            elif ftype.startswith("decimal"):
                # BF-600e (2026-05-31): parse decimal strings via Decimal,
                # not float, to preserve precision when comparing against
                # decimal-typed bounds.  Filter `decimal_col = '1.0001'`
                # against bounds [Decimal('1.0001'), Decimal('1.0001')]
                # would silently fail through float() coercion because
                # float(1.0001) != Decimal('1.0001') under strict eq.
                # Decimal compares correctly with both Decimal and int.
                from decimal import Decimal, InvalidOperation
                try:
                    cval = Decimal(val_norm)
                    if lo is not None and not isinstance(lo, Decimal):
                        lo = Decimal(str(lo))
                    if hi is not None and not isinstance(hi, Decimal):
                        hi = Decimal(str(hi))
                except (InvalidOperation, ValueError, TypeError):
                    continue   # fail-open: keep file when coercion fails
            elif ftype == "boolean":
                # BF-600a: coerce filter literal to Python bool so the
                # eq/ne branches below can compare against bound (also
                # a Python bool from _decode_bound).  Accepts:
                #   True / False / 1 / 0 / "true" / "false" / "1" / "0"
                # case-insensitive.  Anything else → fail-open (keep).
                if isinstance(val, bool):
                    cval = val
                elif isinstance(val, (int, float)):
                    cval = bool(int(val))
                else:
                    _bs = val_norm.strip().lower()
                    if _bs in ("true", "t", "1", "yes"):
                        cval = True
                    elif _bs in ("false", "f", "0", "no"):
                        cval = False
                    else:
                        continue  # unrecognised bool literal → keep
        except (ValueError, TypeError):
            continue  # type conversion failed → keep file

        # BF-509 (2026-05-28) — bare-date filter value against ISO-timestamp
        # bounds must NOT do a plain string compare.  Lexically
        # "2026-02-28" < "2026-02-28T00:00:00+00:00" so the EQ branch
        # below would exclude every file whose bounds bracket exactly
        # that day — silently zeroing out the result.  When ftype is
        # timestamp-like AND val_norm is a 10-char YYYY-MM-DD, truncate
        # both bounds to their date prefix for the comparison.  Sibling
        # of BF-498 at the column-stats layer; same root cause, different
        # pruning stage.  User-visible symptom was "works for some dates
        # but not others" — dates whose writer happened to store DATE-typed
        # bounds worked; dates whose writer used TIMESTAMP-typed bounds
        # silently dropped every file.
        _is_ts_ftype = ftype in (
            "timestamp", "timestamptz", "timestamp_tz",
            "timestamp with local time zone",
        )
        _bare_date_re = None
        if _is_ts_ftype and isinstance(val_norm, str) and len(val_norm) == 10:
            import re as _re_bd509
            _bare_date_re = _re_bd509.compile(r"^\d{4}-\d{2}-\d{2}$")
        _bare_date_filter = bool(_bare_date_re and _bare_date_re.match(val_norm))
        if _bare_date_filter:
            _lo_prefix = lo[:10] if isinstance(lo, str) and len(lo) >= 10 else lo
            _hi_prefix = hi[:10] if isinstance(hi, str) and len(hi) >= 10 else hi
        else:
            _lo_prefix = lo
            _hi_prefix = hi

        # 2026-07-31 — Phase-2 FAMILY E fail-open guard (see the block comment
        # above this function).  A non-ISO temporal literal on a DECLARED-
        # temporal column cannot be compared to the ISO-decoded bounds below
        # (lexicographic '3…' vs '2…' prunes the MATCHING file), so skip this
        # filter for this file = KEEP.  Keep-only by CALL-SITE SHAPE: every
        # production caller is ``if not _file_matches_column_stats(...): skip``
        # (get_iceberg_data_files ~:8601, prunability profile ~:8574), so
        # `continue` can only PREVENT a prune, never cause one.  VARCHAR
        # columns never enter (declared-type gate); ambiguous all-numeric
        # literals never enter (_to_datetime refuses); exclusion ops are not
        # listed, so !=/NOT IN/NOT BETWEEN/NOT LIKE behave exactly as before.
        if _is_temporal_declared_type(ftype):
            if (op in _TEMPORAL_GUARD_OPS_T31
                    and _noniso_parseable_temporal_literal(val_norm)):
                continue
            if (op == "in" and isinstance(val, list)
                    and any(_noniso_parseable_temporal_literal(_v)
                            for _v in val)):
                continue

        try:
            if op in ("equals", "eq", "=", "=="):
                if _bare_date_filter:
                    if _lo_prefix is not None and cval < _lo_prefix:
                        return False
                    if _hi_prefix is not None and cval > _hi_prefix:
                        return False
                else:
                    # BF-600d (2026-05-31) wanted case-insensitive eq
                    # pruning.  2026-08-03 DATA-LOSS FIX: casefold is NOT
                    # order-preserving — 'Zebra'(Z=0x5A) < 'apple'(a=0x61)
                    # byte-wise but 'zebra' > 'apple' folded — so folding
                    # the bounds could INVERT the interval and prune the
                    # file holding the EXACT match (bounds {'Zebra',
                    # 'apple'}: lo='Zebra', hi='apple'; filter 'apple'
                    # folds to 'apple' < 'zebra' → excluded).  The old
                    # comment claimed DuckDB row-level filtering preserves
                    # correctness — wrong: this branch excludes FILES.
                    # An EXCLUSION may fire only when out-of-range under
                    # BOTH readings:
                    #   1. raw byte order (sound for DuckDB's case-
                    #      sensitive '=' against byte-ordered bounds), AND
                    #   2. casefolded with the folded interval RE-ORDERED
                    #      (retains BF-600d's case-drift pruning where it
                    #      is provable under both).
                    # Plus a temporal ISO 'T'-vs-space spelling veto — the
                    # same drift the supplement layer bridges with
                    # _maybe_normalize_pair (see _temporal_str_prune_recheck).
                    if isinstance(lo, str) and isinstance(cval, str):
                        _byte_out = ((cval < lo) or
                                     (isinstance(hi, str) and cval > hi))
                        _prune_eq = False
                        if _byte_out:
                            _f_lo = lo.casefold()
                            _f_hi = hi.casefold() if isinstance(hi, str) else None
                            if _f_hi is not None and _f_lo > _f_hi:
                                _f_lo, _f_hi = _f_hi, _f_lo
                            _cv_f = cval.casefold()
                            _prune_eq = ((_cv_f < _f_lo) or
                                         (_f_hi is not None and _cv_f > _f_hi))
                        if (_prune_eq
                                and _temporal_str_prune_recheck(
                                    "eq", cval, lo, hi) is False):
                            _prune_eq = False   # spelling-drift veto → keep
                        if _prune_eq:
                            return False
                    else:
                        if lo is not None and cval < lo:
                            return False
                        if hi is not None and cval > hi:
                            return False
            elif op in ("not_equals", "ne", "!="):
                # 2026-06-04 — single-value file prune (mirror of not_in):
                # if the file's bounds collapse to lo == hi AND that value
                # equals the filter literal, the file's sole value is the
                # excluded one → file empty for this filter.  Was a silent
                # fall-open before (line said: pass # can't safely prune).
                if lo is not None and hi is not None and lo == hi:
                    try:
                        if isinstance(lo, str):
                            _cv_ne = str(val)
                        else:
                            try:
                                _cv_ne = type(lo)(val)
                            except (ValueError, TypeError):
                                _cv_ne = val
                        if _cv_ne == lo:
                            return False
                    except (TypeError, ValueError):
                        pass
            elif op in ("not_like", "nlike") and isinstance(val, str):
                # 2026-06-04 — NOT LIKE prefix prune.
                # For pattern 'PREFIX%' (prefix-only LIKE), NOT LIKE is
                # satisfied iff the row is OUTSIDE the range [PREFIX, PREFIX⁺).
                # Provable file-empty when the file's entire [lo, hi] is
                # INSIDE [PREFIX, PREFIX⁺) — every row in the file matches
                # the LIKE so none can satisfy NOT LIKE.
                # Patterns containing _ or interior % are not safely
                # prunable here (would need full pattern semantics).
                if isinstance(lo, str) and isinstance(hi, str):
                    pat = val
                    if pat.endswith("%") and "%" not in pat[:-1] and "_" not in pat[:-1]:
                        prefix = pat[:-1]
                        # Compute upper bound of the prefix range (exclusive):
                        # last code-point of prefix +1.  Fallback to a wide
                        # sentinel if exhausted.
                        try:
                            if prefix:
                                _upper = prefix[:-1] + chr(ord(prefix[-1]) + 1)
                            else:
                                _upper = None   # empty prefix matches everything
                        except Exception:
                            _upper = None
                        if _upper is not None:
                            # File fully inside [prefix, _upper)?  BYTE-EXACT (no
                            # case-fold): NOT LIKE is an EXCLUSION op, so folding
                            # OVER-PRUNES.  DuckDB matches LIKE case-SENSITIVELY,
                            # so a file with min==max=='APP' satisfies
                            # ``NOT LIKE 'app%'`` (rows kept) -- folding
                            # 'APP'->'app' inside [app,apq) would wrongly prune it
                            # -> data loss (2026-07-06 fix, mirrors _cmp_neq).
                            try:
                                if lo >= prefix and hi < _upper:
                                    return False
                            except TypeError:
                                pass
            elif op == "not_between" and isinstance(val, list) and len(val) == 2:
                # NOT BETWEEN low AND high  →  file empty if file's bounds
                # are entirely INSIDE [low, high] (every row satisfies the
                # original BETWEEN, so none satisfy NOT BETWEEN).
                # 2026-08-19 — was a bare ``type(lo)(val[0])``.  On a BOOLEAN
                # bound that is ``bool(...)``, and a non-empty string is
                # truthy, so ``active NOT BETWEEN 'false' AND 'false'``
                # coerced to [True, True], "proved" the file inside, and
                # DROPPED it — though True is not in [False, False] and every
                # row satisfies the predicate.  This is an EXCLUSION branch,
                # so an undecidable coercion must KEEP the file, never guess.
                _nb_ok = True
                if lo is not None and not isinstance(lo, str):
                    nb_low = _coerce_listed_value(val[0], lo)
                    if nb_low is None:
                        _nb_ok = False
                else:
                    nb_low = val[0]
                if hi is not None and not isinstance(hi, str):
                    nb_high = _coerce_listed_value(val[1], hi)
                    if nb_high is None:
                        _nb_ok = False
                else:
                    nb_high = val[1]
                if _nb_ok and lo is not None and hi is not None:
                    try:
                        if nb_low <= lo and hi <= nb_high:
                            return False
                    except TypeError:
                        pass          # incomparable -> keep the file
            elif op in ("not_in", "nin") and isinstance(val, list):
                # BF-600b (2026-05-31) — NOT IN file-level pruning.
                # Was a silent miss: WHERE x NOT IN (a,b,c) scanned every
                # file even when the file's bounds said the file only
                # contained values in {a,b,c}.
                # Safe prune ONLY when the file's bounds collapse to a
                # SINGLE value AND that value is in the NOT IN set.
                # (For bounds spanning [lo,hi] with lo<hi, we can't prove
                # every row is in the excluded set without enumerating the
                # full interval against val.  Single-value case is the
                # common "partition by region with one region per file"
                # pattern that motivated the audit finding.)
                if lo is not None and hi is not None and lo == hi:
                    try:
                        for v in val:
                            _vs = str(v)
                            if not isinstance(lo, str):
                                _cv = _coerce_listed_value(v, lo)
                                if _cv is None:
                                    continue   # uncoercible -> keep file
                            else:
                                _cv = _vs
                            if _cv == lo:
                                return False  # file's sole value is in the excluded set
                    except TypeError:
                        pass
            elif op == "in" and isinstance(val, list):
                # Prune only if ALL in-list values are outside [lo, hi]
                # BF-509: same bare-date-vs-timestamp normalisation for IN
                # — per-item, since the list can mix bare dates and full
                # timestamps.  When the item being compared is a bare date
                # AND bounds are timestamp-typed, truncate the bounds to
                # their date prefix for THAT comparison.
                if lo is not None and hi is not None:
                    all_out = True
                    import re as _re_in509
                    _bd_re_in = _re_in509.compile(r"^\d{4}-\d{2}-\d{2}$")
                    _lo_str_pfx = lo[:10] if isinstance(lo, str) and len(lo) >= 10 else lo
                    _hi_str_pfx = hi[:10] if isinstance(hi, str) and len(hi) >= 10 else hi
                    for v in val:
                        try:
                            _vs = str(v)
                            _item_is_bare_date = _is_ts_ftype and bool(_bd_re_in.match(_vs))
                            if _item_is_bare_date:
                                _cv = _vs
                                _lo_cmp_in, _hi_cmp_in = _lo_str_pfx, _hi_str_pfx
                            else:
                                if lo is not None and not isinstance(lo, str):
                                    _cv = _coerce_listed_value(v, lo)
                                    if _cv is None:
                                        all_out = False   # uncoercible -> keep
                                        break
                                else:
                                    _cv = _vs
                                _lo_cmp_in, _hi_cmp_in = lo, hi
                            if not (_cv < _lo_cmp_in or _cv > _hi_cmp_in):
                                all_out = False
                                break
                        except (ValueError, TypeError):
                            all_out = False
                            break
                    if all_out:
                        return False
            elif op in ("gt", ">", "greater_than"):
                # file has no rows where col > val  if hi <= val
                # 2026-08-03 DATA-LOSS FIX (BF-509 sibling): with a BARE-DATE
                # literal the day-prefix normalisation erases the intra-day
                # time.  ``col > DATE 'd'`` compares against MIDNIGHT of d, so
                # a file whose timestamp max is 18:00 ON day d DOES hold
                # matching rows — equal prefixes prove nothing.  Only a
                # STRICTLY-EARLIER day is provable for gt.
                _hi_cmp = _hi_prefix if _bare_date_filter else hi
                if _hi_cmp is not None and (
                        (_hi_cmp < cval) if _bare_date_filter
                        else (_hi_cmp <= cval)):
                    return False
            elif op in ("gte", ">=", "greater_equals"):
                _hi_cmp = _hi_prefix if _bare_date_filter else hi
                if _hi_cmp is not None and _hi_cmp < cval:
                    return False
            elif op in ("lt", "<", "less_than"):
                _lo_cmp = _lo_prefix if _bare_date_filter else lo
                if _lo_cmp is not None and _lo_cmp >= cval:
                    # 2026-08-03 DATA-LOSS FIX (spelling drift): bounds
                    # decode with a 'T' separator, literals use a space,
                    # and 'T'(0x54) > ' '(0x20) — so lo='…-30T08:00' >=
                    # cval='…-30 13:00' is lexicographically TRUE though
                    # 08:00 < 13:00, pruning a file that DOES hold
                    # matching rows.  Only bare 10-char dates got the
                    # BF-509 bridge.  Temporal-instant veto: keep unless
                    # the prune is ALSO provable on parsed instants.
                    if (not _bare_date_filter
                            and isinstance(lo, str) and isinstance(cval, str)
                            and _temporal_str_prune_recheck(
                                "lt", cval, lo, hi) is False):
                        continue
                    return False
            elif op in ("lte", "<=", "less_equals"):
                _lo_cmp = _lo_prefix if _bare_date_filter else lo
                if _lo_cmp is not None and _lo_cmp > cval:
                    # 2026-08-03 — same spelling-drift veto as lt.
                    if (not _bare_date_filter
                            and isinstance(lo, str) and isinstance(cval, str)
                            and _temporal_str_prune_recheck(
                                "lte", cval, lo, hi) is False):
                        continue
                    return False
            elif op in ("like_prefix", "starts_with"):
                # BF-600-L1 (2026-05-31) — prefix-match prune.
                # `WHERE name LIKE 'Apple%'` against bounds ['Banana',
                # 'Zebra']: every string starting with 'Apple' is < 'B'
                # so the file is empty.  Safe when val is a literal
                # prefix (no % / _ inside the prefix portion).
                # Equivalent to gte+lte decomposition the extractor
                # already does at partition_filters_to_pruning_format —
                # this branch handles callers that bypass the extractor.
                if isinstance(cval, str) and cval and cval != "%":
                    # Strip a trailing '%' if the caller passed the raw
                    # LIKE pattern.  starts_with takes a bare prefix.
                    _prefix = cval[:-1] if cval.endswith("%") else cval
                    # BF-600-L1 round-6: empty prefix (val="" or val="%")
                    # means "match anything" — pruning must fail-open.
                    # The `cval and cval != "%"` guard above covers this;
                    # also skip if the stripped prefix is empty.
                    if not _prefix:
                        continue
                    # Refuse non-trivial wildcard patterns: any '%' or '_'
                    # inside the prefix means it's not a simple prefix.
                    if "%" not in _prefix and "_" not in _prefix:
                        # File empty if every value in [lo, hi] is < prefix
                        # OR every value is > prefix + "￿" (highest BMP char)
                        if isinstance(hi, str) and hi < _prefix:
                            return False
                        # Upper-bound check: file's lo must be < prefix + "￿"
                        # otherwise every value starts with chars > prefix.
                        # Construct a conservative upper bound: prefix
                        # followed by 0x10FFFF (max Unicode code point).
                        # If lo > that, every value is lexically AFTER the
                        # prefix family → prune.
                        try:
                            from core.predicate_coerce import (
                                like_prefix_upper_bound as _lpub,
                            )
                            _upper = _lpub(_prefix)
                            if isinstance(lo, str) and lo > _upper:
                                return False
                        except Exception as _lp_upper_exc:
                            logger.debug(
                                "BF-600-L1 like_prefix upper-bound check skipped "
                                "(fail-open keep): %s", _lp_upper_exc,
                            )
        except TypeError:
            continue  # incomparable types → keep

    return True  # file may contain matching rows


# ── Partition filter evaluation ───────────────────────────────────────────────

#: Every operator spelling the manifest-list matcher has a branch for.  A
#: filter whose op is outside this set is DECLINED (kept) -- tallied as
#: ``op_unsupported`` so a "skipped 0/N" line can say why.  Widening this set
#: without a per-op proof is how the 2026-08-19 NOT LIKE inversion happened.
_MANIFEST_MATCHER_OPS = frozenset({
    "equals", "eq", "=", "==", "in",
    "not_equals", "ne", "!=", "not_like", "nlike",
    "gt", ">", "greater_than", "gte", ">=", "greater_equals",
    "lt", "<", "less_than", "lte", "<=", "less_equals",
})

#: Keep-reason keys the matcher tallies.  ``pruned`` and ``overlap`` are the
#: two outcomes of an EVALUATED (manifest, filter) pair; everything else is a
#: pair that was never evaluated -- absent input or a declared decline.
#: ``string_range_declined`` (2026-10-06): a range on a STRING partition the
#: one decision (core.filter_ops.string_partition_range_decision) refused --
#: a summary spanning several partitions is never decidable by it.
MANIFEST_KEEP_REASONS = (
    "pruned", "overlap",
    "no_summary", "bounds_undecodable", "col_not_partitioned",
    "op_unsupported", "transform_declined", "temporal_literal_declined",
    "incomparable", "string_range_declined",
)

#: The range spellings every stage below routes through the one
#: string-partition decision (core.filter_ops.string_partition_range_decision).
_STRING_RANGE_STAGE_OPS = frozenset({
    "gt", ">", "greater_than", "gte", ">=", "greater_equals",
    "lt", "<", "less_than", "lte", "<=", "less_equals",
})


def _range_literal(raw: Any, normalised: Any) -> Any:
    """The literal a stage hands the one string-partition decision: a NATIVE
    number stays a number (a structured filter's ``int`` renders as an
    unquoted SQL number -- ``core.query_compiler.sql_literal`` -- so only the
    numeric reading exists), anything else its cast-stripped spelling."""
    from decimal import Decimal
    if isinstance(raw, bool):
        return normalised
    if isinstance(raw, (int, float, Decimal)):
        return raw
    return normalised


def _manifest_matches_filters(
    manifest_entry: dict,
    partition_spec: Dict[str, str],
    filters: List[Dict[str, Any]],
    *,
    src_to_part: Optional[Dict[str, str]] = None,
    reasons: Optional[Dict[str, int]] = None,
    decision_out: Optional[Dict[str, Any]] = None,
) -> bool:
    """Return False only if we can *prove* no data file in this manifest satisfies
    all filters.  Returns True when uncertain (safe over-approximation).

    ``decision_out`` (2026-09-28): when the manifest IS pruned, the caller's
    dict receives the deciding filter and the DECODED summary bounds --
    ``{"field", "col_type", "op", "val", "lo", "hi"}`` -- the record the
    pruning gate's ``manifest_summary`` stage re-derives the verdict from.
    A drop nobody can verify is a drop nobody can prove.

    ``reasons`` (2026-09-26, F4a): an optional tally the caller owns.  Every
    (manifest, filter) pair is counted under exactly one key of
    ``MANIFEST_KEEP_REASONS`` -- so a "skipped 0/N manifests" line can say
    whether the predicate was EVALUATED against every summary and simply
    overlapped (healthy, non-selective) or was never evaluated at all (the
    writer omits summaries, the column is not partitioned, the op has no
    branch).  Before this, both printed the identical aggregate line; the
    system logged what it did and never what it declined to do.  A manifest
    with no ``partitions`` field is counted ONCE as ``no_summary`` (there is
    nothing per-filter to evaluate) and is always kept: absent = must read.

    manifest_entry fields (from Avro manifest-list):
      partitions: list<{lower_bound: bytes, upper_bound: bytes, contains_null: bool}>

    149.3 (2026-06-09) — transform-aware projection.  Pre-fix this
    function only matched filter columns against the partition FIELD
    name (the renamed-after-transform name like ``event_time_day``).
    Filters written against the SOURCE column (``event_time``) silently
    skipped manifest-level pruning, even though the file-level loop
    (``get_iceberg_data_files`` step 6) already translated them via
    ``build_source_to_partition_field_map``.  Result: every manifest
    was loaded from S3 (10s-minutes on cold cache) just to prune at the
    file level.  Post-fix the same translation runs at the manifest
    level too — skips manifests whose summary already says "no overlap"
    on a transform-renamed partition column.

    ``src_to_part`` is the precomputed
    ``build_source_to_partition_field_map(metadata)`` lookup, hoisted
    outside the per-manifest loop so we build it ONCE per query, not
    N times per N manifests.  When None, the lookup is skipped (back-
    compat) and the function behaves identically to pre-149.3.
    """
    def _tally(reason: str) -> None:
        if reasons is not None:
            reasons[reason] = reasons.get(reason, 0) + 1

    def _prune(_field, _ptype, _op, _val, _lo, _hi) -> bool:
        """The ONE exit for a pruned manifest: tally + decision record."""
        _tally("pruned")
        if decision_out is not None:
            decision_out.update({"field": _field, "col_type": _ptype,
                                 "op": _op, "val": _val,
                                 "lo": _lo, "hi": _hi})
        return False

    parts = manifest_entry.get("partitions")
    if not parts:
        _tally("no_summary")
        return True   # no partition metadata → can't prune → keep manifest

    spec_fields = list(partition_spec.items())   # ordered: name, type
    spec_name_to_idx_lower = {n.lower(): i for i, (n, _) in enumerate(spec_fields)}

    for filt in filters:
        col = filt.get("col") or filt.get("column", "")
        op  = filt.get("op")  or filt.get("operator", "")
        val = filt.get("val") or filt.get("value", "")

        # 149.3: column resolution — direct + lowercased + source→partition map.
        # The source→partition map covers writer renames after transforms
        # (e.g. ``day(event_time)`` → ``event_time_day``).  Without this,
        # filters written against the user-visible source column name
        # never matched any partition spec entry → manifest-pruning was
        # silently skipped for the most common transform case.
        col_lower = col.lower() if col else ""
        spec_idx = spec_name_to_idx_lower.get(col_lower)
        if spec_idx is None and "." in col_lower:
            # 2026-09-26 (F4a): strip a ``table.`` / ``schema.table.``
            # qualifier, exactly as the per-file loop does (BF-PART-FIRST,
            # Step 6) and the col-stats path does (BF-377).  This matcher
            # was the one layer that did not, so ``WHERE t.dt = ...``
            # kept EVERY manifest here -- bodies fetched, then Step 6
            # dropped the same files from the same tuples -- while the
            # bare spelling skipped them.  The full name is tried FIRST
            # so a partition field that is literally dotted still resolves.
            col_lower = col_lower.split(".")[-1]
            spec_idx = spec_name_to_idx_lower.get(col_lower)
        if spec_idx is None and src_to_part:
            _mapped = src_to_part.get(col_lower)
            if _mapped:
                spec_idx = spec_name_to_idx_lower.get(_mapped.lower())
        if spec_idx is None or spec_idx >= len(parts):
            _tally("col_not_partitioned")
            continue  # column not partitioned → can't prune on it

        ptype = spec_fields[spec_idx][1]
        pbounds = parts[spec_idx]
        lo_raw = pbounds.get("lower_bound")
        hi_raw = pbounds.get("upper_bound")
        has_null = pbounds.get("contains_null", False)

        lo = _decode_bound(lo_raw, ptype) if lo_raw else None
        hi = _decode_bound(hi_raw, ptype) if hi_raw else None

        if lo is None and hi is None:
            _tally("bounds_undecodable")
            continue   # no bounds info → keep

        _op_l = str(op).lower().strip() if op else ""
        if _op_l not in _MANIFEST_MATCHER_OPS or (
                _op_l == "in" and not isinstance(val, list)):
            # No branch below can evaluate this pair.  Declined, not
            # absent -- the summary is there, the op has no proof.
            _tally("op_unsupported")
            continue

        # Convert filter value to comparable type.
        # For _transform_* types, lo/hi are already ISO strings from _decode_bound,
        # so we keep cval as a string for correct lexicographic (== chronological) comparison.
        # 149-fix-2 (2026-06-09): bucket / truncate are EXCEPTIONS — bounds
        # are decoded to the TRANSFORM RESULT (bucket → int, truncate →
        # truncated source type), so comparing the raw source-col filter
        # value would silently fail with TypeError and the manifest got
        # kept by the fail-open catch.  We now apply the transform here
        # so the comparison is type-correct AND semantically right.
        # Matches the file-level loop's behaviour (BF-501 / BF-502).
        try:
            cval: Any = val
            if ptype.startswith("_transform_bucket["):
                # 149-fix-2: project source-col filter through bucket() so
                # we can compare to the bucket-index bounds.  Without
                # this, every bucket-partitioned table silently skipped
                # manifest pruning on its bucket-partition column.
                try:
                    from core.iceberg_transforms import bucket_transform as _bxf
                    _bracket_open = ptype.index("[") + 1
                    _bracket_close = ptype.index("]")
                    _N = int(ptype[_bracket_open:_bracket_close])
                    _colon = ptype.index(":")
                    _src_type = ptype[_colon + 1:]
                    _bucketed = _bxf(val, _N, _src_type)
                    if _bucketed is None:
                        # Transform returned None (incomparable) — skip
                        # this filter, keep the manifest (fail-open).
                        _tally("transform_declined")
                        continue
                    cval = _bucketed
                    # 2026-07-04 DATA-LOSS FIX: bucket() is NON-MONOTONIC.
                    # Only eq / in can prune a bucket partition.  A range or
                    # != compares the bucket INDEX of the filter value to the
                    # manifest's bucket-index bounds -- unsound: a value that
                    # satisfies e.g. ``col > 5000`` can hash into [lo,hi] and
                    # live in this manifest, so the range branch would wrongly
                    # prune it.  Fail open for all non-equality ops, matching
                    # the file-level loop's ``continue # range/!=: can't prune``.
                    if op not in ("equals", "eq", "=", "==", "in"):
                        _tally("transform_declined")
                        continue
                except Exception:
                    _tally("transform_declined")
                    continue
            elif ptype.startswith("_transform_truncate["):
                # 149-fix-2: same fix for truncate.  Bounds are decoded
                # back to the SOURCE TYPE via the recursive _decode_bound
                # path (line 678-681), so we apply truncate to the filter
                # value for a same-type comparison.
                try:
                    from core.iceberg_transforms import truncate_transform as _txf
                    _bracket_open = ptype.index("[") + 1
                    _bracket_close = ptype.index("]")
                    _W = int(ptype[_bracket_open:_bracket_close])
                    _colon = ptype.index(":")
                    _src_type = ptype[_colon + 1:]
                    _truncated = _txf(val, _W, _src_type)
                    if _truncated is not None:
                        cval = _truncated
                    else:
                        _tally("transform_declined")
                        continue
                except Exception:
                    _tally("transform_declined")
                    continue
            elif ptype.startswith("_transform_"):
                # day/month/year/hour: bounds are ISO strings from
                # _decode_bound — keep val as string too.
                # Also strip DuckDB cast syntax (e.g. "DATE '2024-01-15'" → "2024-01-15")
                import re as _re_mf
                _cm = _re_mf.match(r"^(?:DATE|TIMESTAMP|TIME)\s+'(.+)'$", str(val), _re_mf.IGNORECASE)
                cval = _cm.group(1) if _cm else str(val)
            elif ptype in ("int", "integer", "long", "bigint"):
                cval = int(val)
            elif ptype in ("float",):
                cval = float(val)
            elif ptype in ("double", "decimal") or ptype.startswith("decimal("):
                # 2026-08-03: parametrized "decimal(p,s)" (the verbatim spec
                # spelling) never matched the exact test, leaving cval a
                # STRING against Decimal bounds → TypeError → keep (manifest
                # decimal pruning silently inert).  float compares correctly
                # against Decimal bounds in Python 3.
                cval = float(val)
        except (ValueError, TypeError):
            cval = str(val)

        # BF-509 (2026-05-28) — same bare-date-vs-timestamp normalisation
        # the file-level column-stats path uses.  Without this, the
        # MANIFEST-LIST level pruning silently drops every manifest whose
        # partition column is timestamp-typed and whose user filter is a
        # bare date string.  Manifests pruned here never make it to the
        # file-level pruning, so the file-level fix alone wouldn't have
        # been enough — this is the layer that REALLY hits first.
        _is_ts_ptype = (
            ptype in ("timestamp", "timestamptz", "timestamp_tz",
                       "timestamp with local time zone")
            or ptype.startswith("_transform_hour")
        )
        _cval_str = str(cval) if cval is not None else ""
        import re as _re_mf509
        _mf_bare_date = (
            _is_ts_ptype and len(_cval_str) == 10
            and bool(_re_mf509.match(r"^\d{4}-\d{2}-\d{2}$", _cval_str))
        )
        if _mf_bare_date:
            _lo_pf = lo[:10] if isinstance(lo, str) and len(lo) >= 10 else lo
            _hi_pf = hi[:10] if isinstance(hi, str) and len(hi) >= 10 else hi
        else:
            _lo_pf, _hi_pf = lo, hi

        # 2026-07-31 — Phase-2 FAMILY F fail-open guard (worst family: a
        # manifest pruned here removes ALL its files before ANY file-level
        # check can run).  Same shape as family E: non-ISO temporal literal +
        # DECLARED-temporal partition type → skip this filter for this
        # manifest = KEEP.  Keep-only by CALL-SITE SHAPE: the sole production
        # caller filters ``[m for m in manifests if
        # _manifest_matches_filters(...)]`` (~:6875), so `continue` can only
        # RETAIN more manifests.  String-typed partition specs never enter
        # (declared-type gate keeps identity-VARCHAR partitions byte-wise);
        # bucket/truncate transforms never enter (not in the temporal-type
        # list — their cval is already transform-projected above); exclusion
        # ops (!=, NOT LIKE) are not listed and behave exactly as before.
        if _is_temporal_declared_type(ptype):
            if (op in _TEMPORAL_GUARD_OPS_T31
                    and _noniso_parseable_temporal_literal(_cval_str)):
                _tally("temporal_literal_declined")
                continue
            if (op == "in" and isinstance(val, list)
                    and any(_noniso_parseable_temporal_literal(_v)
                            for _v in val)):
                _tally("temporal_literal_declined")
                continue

        # 2026-10-06 -- a range on a STRING identity partition: the ONE
        # decision (the island's).  A summary spans every partition value in
        # the manifest, and a span is decided by no reading but one -- so
        # this is refused unless the manifest holds a single value.
        if (_op_l in _STRING_RANGE_STAGE_OPS
                and not ptype.startswith("_transform_")):
            from core.filter_ops import (
                string_partition_range_decision as _spd_mf)
            _d_mf = _spd_mf(ptype, op, cval, lo, hi,
                            literal_kind=filt.get("literal_kind"))
            if _d_mf.applies:
                if _d_mf.drop:
                    return _prune(spec_fields[spec_idx][0], ptype, op, val,
                                  lo, hi)
                if _d_mf.reason:
                    _tally("string_range_declined")
                else:
                    _tally("overlap")   # evaluated: every reading matches
                continue

        # Apply operator check — if we can PROVE the manifest doesn't match, prune
        # Note: has_null doesn't affect comparison pruning — NULL never satisfies >, <, = etc.
        try:
            if op in ("equals", "eq", "=", "=="):
                _mf_prune = ((_lo_pf is not None and cval < _lo_pf) or
                             (_hi_pf is not None and cval > _hi_pf))
                if _mf_prune and ptype in _TEMPORAL_IDENTITY_RANGE_TYPES:
                    # 2026-08-03 — temporal veto (interval + ISO-spelling
                    # drift; see _manifest_temporal_prune_ok).  Can only
                    # PREVENT a drop, never cause one.
                    _mf_prune = _manifest_temporal_prune_ok(
                        lo, hi, cval, ptype, "eq")
                if _mf_prune:
                    return _prune(spec_fields[spec_idx][0], ptype, op, val, lo, hi)
            elif op == "in" and isinstance(val, list):
                # For IN: prune if ALL values are outside the manifest bounds.
                # BF-509: per-item bare-date normalisation against ts bounds.
                _bd_re_mf_in = _re_mf509.compile(r"^\d{4}-\d{2}-\d{2}$")
                _lo_str_pfx = lo[:10] if isinstance(lo, str) and len(lo) >= 10 else lo
                _hi_str_pfx = hi[:10] if isinstance(hi, str) and len(hi) >= 10 else hi
                converted_vals = []
                bare_date_flags = []
                for v in val:
                    try:
                        if ptype.startswith("_transform_"):
                            import re as _re_mf2
                            _cm2 = _re_mf2.match(r"^(?:DATE|TIMESTAMP|TIME)\s+'(.+)'$", str(v), _re_mf2.IGNORECASE)
                            _vc = _cm2.group(1) if _cm2 else str(v)
                            converted_vals.append(_vc)
                            bare_date_flags.append(False)
                        elif ptype in ("int", "integer", "long", "bigint"):
                            converted_vals.append(int(v))
                            bare_date_flags.append(False)
                        elif (ptype in ("float", "double", "decimal")
                              or ptype.startswith("decimal(")):
                            # 2026-08-03: same parametrized-decimal miss as
                            # the scalar branch above.
                            converted_vals.append(float(v))
                            bare_date_flags.append(False)
                        else:
                            _vs = str(v)
                            converted_vals.append(_vs)
                            bare_date_flags.append(
                                _is_ts_ptype and bool(_bd_re_mf_in.match(_vs))
                            )
                    except (ValueError, TypeError):
                        converted_vals.append(str(v))
                        bare_date_flags.append(False)
                if lo is not None and hi is not None:
                    all_out = True
                    for cv, _bd in zip(converted_vals, bare_date_flags):
                        _lo_c = _lo_str_pfx if _bd else lo
                        _hi_c = _hi_str_pfx if _bd else hi
                        if not (cv < _lo_c or cv > _hi_c):
                            all_out = False
                            break
                    if all_out and ptype in _TEMPORAL_IDENTITY_RANGE_TYPES:
                        # 2026-08-03 — temporal veto: EVERY item must be
                        # provably outside the manifest's covered instant
                        # interval, else keep (spelling drift / period
                        # coverage can make the lexicographic test lie).
                        all_out = all(
                            _manifest_temporal_prune_ok(lo, hi, _cv, ptype, "in")
                            for _cv in converted_vals)
                    if all_out:
                        return _prune(spec_fields[spec_idx][0], ptype, op, val, lo, hi)
            elif op in ("not_equals", "ne", "!="):
                # 2026-06-04 supplement-bounds single-value prune.
                if lo is not None and hi is not None and lo == hi:
                    try:
                        if isinstance(lo, str):
                            _cv_ne_s = str(cval)
                        else:
                            # 2026-08-19 — third copy of the bare
                            # ``type(lo)(...)`` bool trap; see the manifest
                            # not_equals branch.  Undecidable -> keep.
                            _cv_ne_s = _coerce_listed_value(cval, lo)
                            if _cv_ne_s is None:
                                _cv_ne_s = cval
                        if _cv_ne_s == lo:
                            return _prune(spec_fields[spec_idx][0], ptype, op, val, lo, hi)
                    except (TypeError, ValueError):
                        pass
            elif op in ("not_like", "nlike") and isinstance(cval, str):
                # 2026-06-04 supplement-bounds NOT LIKE prefix prune.
                if isinstance(lo, str) and isinstance(hi, str) and \
                   cval.endswith("%") and "%" not in cval[:-1] and "_" not in cval[:-1]:
                    _prefix_s = cval[:-1]
                    try:
                        if _prefix_s:
                            _upper_s = _prefix_s[:-1] + chr(ord(_prefix_s[-1]) + 1)
                        else:
                            _upper_s = None
                    except Exception:
                        _upper_s = None
                    if _upper_s is not None:
                        # 2026-08-03 DATA-LOSS FIX: BYTE-EXACT compare (no
                        # case-fold).  NOT LIKE is an EXCLUSION op — DuckDB
                        # matches LIKE case-SENSITIVELY, so a manifest whose
                        # bounds collapse to 'APP' satisfies ``NOT LIKE
                        # 'app%'`` (rows kept); folding 'APP'→'app' inside
                        # [app,apq) wrongly pruned it.  Same fix the FILE-
                        # level twin received 2026-07-06 (mirrors _cmp_neq).
                        if lo >= _prefix_s and hi < _upper_s:
                            return _prune(spec_fields[spec_idx][0], ptype, op, val, lo, hi)
            elif op in ("gt", ">", "greater_than"):
                _hi_c = _hi_pf if _mf_bare_date else hi
                if _hi_c is not None and cval >= _hi_c:
                    # 2026-08-03 — temporal veto (see eq branch).  The
                    # point-compare treats a day/month/year upper bound as
                    # an instant; the manifest actually COVERS the whole
                    # period, so only a period provably ending at/before
                    # the literal may be dropped.
                    if (ptype in _TEMPORAL_IDENTITY_RANGE_TYPES
                            and not _manifest_temporal_prune_ok(
                                lo, hi, cval, ptype, "gt")):
                        _tally("overlap")   # veto: evaluated, KEEP
                        continue
                    return _prune(spec_fields[spec_idx][0], ptype, op, val, lo, hi)
            elif op in ("gte", ">=", "greater_equals"):
                _hi_c = _hi_pf if _mf_bare_date else hi
                if _hi_c is not None and cval > _hi_c:
                    if (ptype in _TEMPORAL_IDENTITY_RANGE_TYPES
                            and not _manifest_temporal_prune_ok(
                                lo, hi, cval, ptype, "gte")):
                        _tally("overlap")   # veto: evaluated, KEEP
                        continue
                    return _prune(spec_fields[spec_idx][0], ptype, op, val, lo, hi)
            elif op in ("lt", "<", "less_than"):
                _lo_c = _lo_pf if _mf_bare_date else lo
                if _lo_c is not None and cval <= _lo_c:
                    # 'T'(0x54) > ' '(0x20): a space-separated literal
                    # sorts BELOW the same-day 'T'-separated decode, so
                    # this branch pruned manifests that DO match.
                    if (ptype in _TEMPORAL_IDENTITY_RANGE_TYPES
                            and not _manifest_temporal_prune_ok(
                                lo, hi, cval, ptype, "lt")):
                        _tally("overlap")   # veto: evaluated, KEEP
                        continue
                    return _prune(spec_fields[spec_idx][0], ptype, op, val, lo, hi)
            elif op in ("lte", "<=", "less_equals"):
                _lo_c = _lo_pf if _mf_bare_date else lo
                if _lo_c is not None and cval < _lo_c:
                    if (ptype in _TEMPORAL_IDENTITY_RANGE_TYPES
                            and not _manifest_temporal_prune_ok(
                                lo, hi, cval, ptype, "lte")):
                        _tally("overlap")   # veto: evaluated, KEEP
                        continue
                    return _prune(spec_fields[spec_idx][0], ptype, op, val, lo, hi)
            else:
                # The pre-check above admitted this op by its LOWERCASED
                # spelling; the chain matched none of its branches (a
                # case-variant such as ``EQ``).  Declined, not evaluated.
                _tally("op_unsupported")
                continue
        except TypeError:
            _tally("incomparable")
            continue  # incomparable types → keep
        # Evaluated against this manifest's summary and could not prove
        # exclusion: the bounds genuinely overlap the predicate.  (The four
        # temporal-veto ``continue``s inside the range branches tally their
        # own ``overlap`` -- a ``continue`` never reaches this line.)
        _tally("overlap")

    return True   # manifest may contain matching rows


def _temporal_str_prune_recheck(op, val, lo, hi):
    """2026-08-03 DATA-LOSS FIX — ISO spelling-drift bridge for
    ``_file_matches_column_stats`` (the manifest-bounds file-level layer).

    Identity-timestamp bounds decode via ``dt.isoformat()`` ('T' separator,
    '+00:00' suffix) while SQL literals are space-separated, and
    ``' '(0x20) < 'T'(0x54)`` — so the plain string compares pruned same-day
    files that DO match (only bare 10-char dates got the BF-509 bridge).
    This is the same disease the SUPPLEMENT layer already solved with
    ``_maybe_normalize_pair`` + union-of-interpretations; here the temporal
    reading is applied as a VETO on an already-decided prune, so it can only
    PREVENT a drop, never cause one.

    Returns:
      ``False`` — the temporal-instant reading PROVES the file can hold a
                  match → caller must KEEP.
      ``True``  — the temporal reading agrees the prune is safe.
      ``None``  — no temporal opinion (a needed operand does not parse) →
                  caller keeps its existing lexicographic verdict.
    """
    try:
        dv = _parse_iso_instant(str(val)) if val is not None else None
        if dv is None:
            return None
        d_lo = _parse_iso_instant(str(lo)) if isinstance(lo, str) else None
        d_hi = _parse_iso_instant(str(hi)) if isinstance(hi, str) else None
        if op == "eq":
            # BOTH available bounds must parse — a one-sided opinion could
            # mis-prove an out-of-range verdict.
            if lo is not None and d_lo is None:
                return None
            if hi is not None and d_hi is None:
                return None
            import re as _re_tsr
            if _re_tsr.match(r"^\d{4}-\d{2}-\d{2}$",
                             _strip_partition_cast(str(val)).strip()):
                # Bare-date literal widens to its whole day (keep-safe).
                v_lo = dv
                v_hi = dv + timedelta(days=1) - timedelta(microseconds=1)
            else:
                v_lo = v_hi = dv
            if d_lo is not None and v_hi < d_lo:
                return True
            if d_hi is not None and v_lo > d_hi:
                return True
            return False
        if op == "lt":                  # prune iff NO value below dv exists
            return None if d_lo is None else (d_lo >= dv)
        if op == "lte":
            return None if d_lo is None else (d_lo > dv)
        if op == "gt":                  # prune iff NO value above dv exists
            return None if d_hi is None else (d_hi <= dv)
        if op == "gte":
            return None if d_hi is None else (d_hi < dv)
        return None
    except Exception:                                       # pragma: no cover
        return None


# BF-COL-STATS — file-level pruning using the column-stats supplement table.
# Same pattern as _file_matches_column_stats but operates on string-valued
# bounds extracted from parquet footers (NOT from Iceberg manifest avros) so
# we can prune on columns the writer didn't track in manifest bounds.
def _supp_gt_same_day_bare_date(upper, val) -> bool:
    """2026-08-03 (BF-509 sibling) — True when a ``gt`` prune is UNPROVABLE:
    the literal is a BARE DATE and the upper bound is a TIMED instant on the
    SAME day.  ``col > DATE 'd'`` compares against midnight of d, so rows
    after midnight on d satisfy the predicate even though the day-prefix
    normalisation makes the bounds look equal.  Fail-open: any parse doubt
    returns False (the caller's existing verdict stands)."""
    try:
        from core.predicate_coerce import (
            _is_date_only_spelling as _idos,
            _to_datetime as _tdt,
        )
        if not _idos(val):
            return False
        if _idos(upper):
            return False          # date-vs-date: the prefix compare is exact
        ud, vd = _tdt(upper), _tdt(val)
        if ud is None or vd is None:
            return False
        return ud.date() == vd.date()
    except Exception:                                       # pragma: no cover
        return False


def _file_matches_supplement_bounds(
    file_path: str,
    supplement_bounds: Dict[str, Dict[str, tuple]],
    non_partition_filters: List[Dict[str, Any]],
    *,
    drop_reason: Optional[List[Dict[str, Any]]] = None,
    string_partition_cols: Optional[set] = None,
) -> bool:
    """Returns False when supplement bounds prove this file empty for filters.
    True (keep) when bounds missing or comparison can't prune.

    ``string_partition_cols`` (2026-10-06): as for
    ``_file_matches_column_stats`` -- a range on a STRING partition column is
    decided by ``core.filter_ops.string_partition_range_decision`` alone.

    supplement_bounds: {file_path: {col_name_lower: (lower_str, upper_str, null_count)}}

    ``drop_reason`` (opt-in, pruning-audit only): when a list is passed, the
    filter + bounds that caused a prune are appended to it right before the
    function returns False.  Default None → zero behaviour change (the append
    is the ONLY thing gated on this param; the prune verdict is untouched).
    Consumed by pruning_audit.verify_supplement_drops to explain / footer-verify
    each drop.
    """
    def _drop(_col=None, _op=None, _val=None, _lo=None, _hi=None) -> bool:
        if drop_reason is not None:
            drop_reason.append({
                "col": _col, "op": _op, "val": _val, "lower": _lo, "upper": _hi,
            })
        return False

    file_bounds = supplement_bounds.get(file_path)
    if not file_bounds:
        return True

    # BF-509c (2026-05-28) — supplement bounds is the THIRD pruning layer
    # with the same date-vs-timestamp string-compare blind spot.  If the
    # column-stats scan stored ISO timestamp strings for a timestamp
    # column ("2026-02-28T00:00:00+00:00") and the user filters with a
    # bare date "2026-02-28", a plain lex compare lies in both directions:
    #   "2026-02-28T..." <= "2026-02-28"   → False  (so EQ "in range" → False → excluded)
    #   "2026-02-28T..." <  "2026-02-28"   → False  (so GT/LT pruning misfires)
    # Normalise inputs to 10-char date prefix when both look ISO-timestamp-ish.
    import re as _re_supp509
    _bd_supp = _re_supp509.compile(r"^\d{4}-\d{2}-\d{2}$")
    _iso_ts_supp = _re_supp509.compile(r"^\d{4}-\d{2}-\d{2}[T ]")

    def _date_norm(v):
        if isinstance(v, str) and (_bd_supp.match(v) or _iso_ts_supp.match(v)):
            return v[:10]
        return v

    def _maybe_normalize_pair(a, b):
        """If either side is date-ish, normalise BOTH to their 10-char
        date prefix so comparisons are semantically right.  No-op otherwise."""
        if isinstance(a, str) and isinstance(b, str):
            a_date = bool(_bd_supp.match(a) or _iso_ts_supp.match(a))
            b_date = bool(_bd_supp.match(b) or _iso_ts_supp.match(b))
            if a_date or b_date:
                return _date_norm(a), _date_norm(b)
        return a, b

    # 2026-07-15 DATA-LOSS FIX (audit Finding A): supplement bounds are stored
    # as STRINGS (type-erased in the DB), so these comparators cannot know
    # whether a column is genuinely numeric (compare numerically) or a VARCHAR
    # holding numeric-looking values (compare lexicographically, matching
    # pyarrow's file min/max AND DuckDB's row filter).  The old code compared
    # numerically whenever float() parsed, which WRONGLY skips a VARCHAR file:
    # e.g. file value '5' with lexicographic bounds lo='100', hi='999' —
    # numeric says 5∉[100,999] → skip → the row for '5' is LOST, even though
    # '100' <= '5' <= '999' lexicographically keeps it.
    #
    # Fix: evaluate BOTH orderings and keep the file if EITHER says the
    # predicate can be satisfied.  A file is only pruned when it is out of
    # range under numeric AND lexicographic — which means it genuinely cannot
    # match regardless of the column's true type.  Purely fail-OPEN: can only
    # KEEP more files, never drop a matching one.
    def _num_pair(a, b):
        try:
            return float(a), float(b)
        except (ValueError, TypeError):
            return None

    # 2026-07-31 — Phase-2 FAMILY G: a THIRD (temporal) reading joins the
    # numeric+lexicographic union above.  Supplement bounds are TYPE-ERASED
    # strings, so unlike families E/F there is no declared type to gate on —
    # instead the union-of-interpretations contract itself is the safety
    # argument (same as the 2026-07-15 numeric/lex fix): KEEP-position
    # helpers may only gain a disjunct (more keeps), PRUNE-position helpers
    # may only gain a conjunct (fewer prunes).  A genuine VARCHAR column
    # keeps its lexicographic reading in the union, so the attempt-1
    # kill-case (bounds min='05 Jan 2020' max='10 Dec 2019', filter
    # '05 Jan 2020') stays KEEP.
    def _t_pair(a, b):
        """Both-sides temporal reading: ``(a_dt, b_dt, a_is_day, b_is_day)``
        when BOTH sides parse with the same tz-awareness, else None (= no
        temporal opinion, today's verdict stands).  Never raises."""
        try:
            from core.predicate_coerce import (
                _is_date_only_spelling as _idos,
                _to_datetime as _tdt,
            )
            _da, _db = _tdt(a), _tdt(b)
            if _da is None or _db is None:
                return None
            if (_da.tzinfo is None) != (_db.tzinfo is None):
                return None              # incomparable — refuse, do not guess
            return _da, _db, bool(_idos(a)), bool(_idos(b))
        except Exception:                                    # pragma: no cover
            return None

    def _any_noniso_temporal(*vals) -> bool:
        """Gate for the KEEP-position temporal arms: consult the temporal
        reading only when a NON-ISO spelling is involved, so every all-ISO
        verdict stays bit-identical to today's (no pruning-power change)."""
        return any(_noniso_parseable_temporal_literal(v) for v in vals)

    def _cmp_lt(a, b) -> bool:
        _np = _num_pair(a, b)
        _a, _b = _maybe_normalize_pair(a, b)
        try:
            _lex = str(_a) < str(_b)
        except Exception:
            _lex = True
        _base = _lex if _np is None else (_np[0] < _np[1] or _lex)
        if _base:
            return True
        # Family G temporal arm — KEEP position only (`lt` branch calls
        # ``not _cmp_lt(lower, val)`` to drop): an extra True can only
        # PREVENT a drop.  Mixed day-ness widens to day overlap (keep-safe).
        if _any_noniso_temporal(a, b):
            _t = _t_pair(a, b)
            if _t is not None:
                try:
                    if _t[2] != _t[3]:
                        return _t[0].date() <= _t[1].date()
                    return _t[0] < _t[1]
                except Exception as _be_exc:
                    note_best_effort("_t[0] < _t[1]", _be_exc,
                                     logger=logger)
        return _base

    def _cmp_gt(a, b) -> bool:
        _np = _num_pair(a, b)
        _a, _b = _maybe_normalize_pair(a, b)
        try:
            _lex = str(_a) > str(_b)
        except Exception:
            _lex = True
        _base = _lex if _np is None else (_np[0] > _np[1] or _lex)
        if _base:
            return True
        # Family G temporal arm — KEEP position only (`gt` branch calls
        # ``not _cmp_gt(upper, val)`` to drop).  See _cmp_lt.
        if _any_noniso_temporal(a, b):
            _t = _t_pair(a, b)
            if _t is not None:
                try:
                    if _t[2] != _t[3]:
                        return _t[0].date() >= _t[1].date()
                    return _t[0] > _t[1]
                except Exception as _be_exc:
                    note_best_effort("_t[0] > _t[1]", _be_exc,
                                     logger=logger)
        return _base

    # 2026-07-15 DATA-LOSS FIX (audit residual): the gte/lte prune branches
    # need "out of range under BOTH orderings" — the OR-helpers above are
    # correct only in KEEP position (gt/lt use `not _cmp_*`).  In a PRUNE
    # position an OR-helper drops a file when it is out of range under EITHER
    # ordering, which silently loses VARCHAR-numeric matches: bounds
    # lower='1' upper='9', query `acct >= '10'` — numerically 9<10 so upper<val,
    # but lexically '9' >= '10' so the file DOES hold matches.  These AND-both
    # variants prune only when the file genuinely cannot match under either
    # interpretation; they fail-OPEN (don't prune) when the lexical compare
    # itself raises.
    def _cmp_lt_both(a, b) -> bool:
        """True only when a < b under BOTH numeric AND lexicographic orderings
        — and, since 2026-07-31, the TEMPORAL reading must also agree when
        both sides parse temporally.  PRUNE-support helper (a True lets the
        gte branch drop the file), so the extra requirement is a CONJUNCT: it
        can only turn a prune into a keep, never the reverse.  All-ISO pairs
        cannot lose pruning power: the date-normalised lex compare only says
        True when the day prefixes strictly differ, and then the temporal
        day/instant compare agrees."""
        _np = _num_pair(a, b)
        _a, _b = _maybe_normalize_pair(a, b)
        try:
            _lex = str(_a) < str(_b)
        except Exception:
            _lex = False  # can't prove lexically below → don't prune
        _base = _lex if _np is None else (_np[0] < _np[1] and _lex)
        if not _base:
            return False
        _t = _t_pair(a, b)
        if _t is not None:
            try:
                if _t[2] != _t[3]:
                    # Mixed day-ness: require the DAYS to strictly differ —
                    # a timed bound inside the literal's day must not prune.
                    return _t[0].date() < _t[1].date()
                return _t[0] < _t[1]
            except Exception:                                # pragma: no cover
                return _base
        return _base

    def _cmp_gt_both(a, b) -> bool:
        """True only when a > b under BOTH numeric AND lexicographic orderings
        — and, since 2026-07-31, the TEMPORAL reading must also agree when
        both sides parse temporally.  PRUNE-support helper (a True lets the
        lte branch drop the file).  See _cmp_lt_both."""
        _np = _num_pair(a, b)
        _a, _b = _maybe_normalize_pair(a, b)
        try:
            _lex = str(_a) > str(_b)
        except Exception:
            _lex = False  # can't prove lexically above → don't prune
        _base = _lex if _np is None else (_np[0] > _np[1] and _lex)
        if not _base:
            return False
        _t = _t_pair(a, b)
        if _t is not None:
            try:
                if _t[2] != _t[3]:
                    return _t[0].date() > _t[1].date()
                return _t[0] > _t[1]
            except Exception:                                # pragma: no cover
                return _base
        return _base

    def _cmp_eq_in_range(target, lo, hi) -> bool:
        """Is target ∈ [lo, hi]?  Fail-OPEN across numeric + lexicographic:
        keep unless BOTH orderings prove out-of-range."""
        if lo is None or hi is None:
            return True  # can't prove out-of-range → keep
        # Numeric interpretation (None when any operand isn't numeric).
        _num_in = None
        try:
            _t, _l, _h = float(target), float(lo), float(hi)
            _num_in = (_l <= _t <= _h)
        except (ValueError, TypeError):
            _num_in = None
        # Lexicographic interpretation (with the date-prefix normalisation).
        _tn, _lon = _maybe_normalize_pair(target, lo)
        _tn2, _hin = _maybe_normalize_pair(target, hi)
        try:
            _lex_in = (str(_lon) <= str(_tn) <= str(_hin))
        except Exception:
            _lex_in = True
        _base = _lex_in if _num_in is None else (_num_in or _lex_in)
        if _base:
            return True
        # 2026-07-31 Family G temporal arm — KEEP position only (the eq and
        # in branches call ``not _cmp_eq_in_range(...)`` to drop): a new True
        # can only PREVENT a drop.  Consulted only when a NON-ISO spelling is
        # involved so all-ISO verdicts stay bit-identical.  A date-only
        # literal against timed bounds widens to whole-day containment
        # (mirrors temporal_eq_keep's day-widening rule).
        if _any_noniso_temporal(target, lo, hi):
            try:
                from core.predicate_coerce import (
                    _is_date_only_spelling as _idos,
                    _to_datetime as _tdt,
                )
                _td, _ld, _hd = _tdt(target), _tdt(lo), _tdt(hi)
                if (_td is not None and _ld is not None and _hd is not None
                        and (_td.tzinfo is None) == (_ld.tzinfo is None)
                        and (_ld.tzinfo is None) == (_hd.tzinfo is None)):
                    if _idos(target) and not (_idos(lo) and _idos(hi)):
                        if _ld.date() <= _td.date() <= _hd.date():
                            return True
                    elif _ld <= _td <= _hd:
                        return True
            except Exception as _be_exc:
                note_best_effort("True", _be_exc,
                                 logger=logger)
        return _base

    for filt in non_partition_filters:
        col = (filt.get("col") if filt.get("col") is not None
               else filt.get("column", ""))
        col_lower = (col or "").split(".")[-1].lower()
        op = filt.get("op") if filt.get("op") is not None else filt.get("operator", "")
        val = filt.get("val") if filt.get("val") is not None else filt.get("value", "")
        if col_lower not in file_bounds:
            continue
        # BF-600g (2026-05-31): unpack 4-tuple (lower, upper, null_count,
        # row_count).  Pre-BF-600g, the tuple was 3-element and IS NOT NULL
        # could not prune at this layer.  Defensive: accept 3-tuple for
        # legacy callers / tests that haven't been updated yet.
        _entry = file_bounds[col_lower]
        if len(_entry) >= 4:
            lower, upper, null_count, row_count = _entry[0], _entry[1], _entry[2], _entry[3]
        else:
            lower, upper, null_count = _entry[0], _entry[1], _entry[2]
            row_count = 0   # signals "unknown" — IS NOT NULL won't prune

        # IS NULL / IS NOT NULL — only need null_count + row_count
        if op in ("is_null", "isnull"):
            # DATA-LOSS FIX: null_count is None => UNTRACKED (not "zero"); we
            # cannot prove the file has no nulls, so KEEP.  Only a KNOWN 0
            # (integer) proves no nulls and may be pruned for IS NULL.
            if null_count is None:
                continue
            if int(null_count) == 0:
                return _drop(col_lower, op, val, lower, upper)  # no nulls → IS NULL empty
            continue
        if op in ("is_not_null", "isnotnull"):
            # BF-600g: prune when every row is null.  row_count comes
            # from the supplement schema (`row_count` column has been
            # in the table since creation — only the loader didn't
            # surface it pre-BF-600g).  When row_count == 0 (legacy
            # 3-tuple or genuinely unknown), bail to fail-open.
            if row_count and int(null_count or 0) >= int(row_count):
                return _drop(col_lower, op, val, lower, upper)  # all null → IS NOT NULL empty
            continue

        if lower is None and upper is None:
            continue

        # 2026-10-06 -- a range on a STRING PARTITION column: the one decision.
        if (string_partition_cols and col_lower in string_partition_cols
                and op in _STRING_RANGE_STAGE_OPS):
            from core.filter_ops import (
                string_partition_range_decision as _spd_sp)
            _d_sp = _spd_sp("string", op, val, lower, upper,
                            literal_kind=filt.get("literal_kind"))
            if _d_sp.drop:
                return _drop(col_lower, op, val, lower, upper)
            continue   # kept by the one decision (refused or matching)

        if op in ("equals", "eq", "=", "=="):
            if not _cmp_eq_in_range(val, lower, upper):
                return _drop(col_lower, op, val, lower, upper)
        elif op in ("in",) and isinstance(val, list):
            if not any(_cmp_eq_in_range(v, lower, upper) for v in val):
                return _drop(col_lower, op, val, lower, upper)
        elif op in ("gt", ">", "greater_than"):
            if upper is not None and not _cmp_gt(upper, val):
                # 2026-08-03 DATA-LOSS FIX (BF-509 sibling, supplement layer):
                # a BARE-DATE literal vs a TIMED upper bound on the SAME day —
                # _maybe_normalize_pair truncates both to the day prefix, but
                # ``col > DATE 'd'`` means "> midnight of d", which rows after
                # midnight on d DO satisfy.  Equal-day ⇒ unprovable ⇒ keep.
                if not _supp_gt_same_day_bare_date(upper, val):
                    return _drop(col_lower, op, val, lower, upper)
        elif op in ("gte", ">=", "greater_equals"):
            if upper is not None:
                # upper < val under BOTH orderings → all values in [lower,upper]
                # are < val → file empty.  Must require both (see _cmp_lt_both).
                if _cmp_lt_both(upper, val):
                    return _drop(col_lower, op, val, lower, upper)
        elif op in ("lt", "<", "less_than"):
            if lower is not None and not _cmp_lt(lower, val):
                return _drop(col_lower, op, val, lower, upper)
        elif op in ("lte", "<=", "less_equals"):
            if lower is not None and _cmp_gt_both(lower, val):
                return _drop(col_lower, op, val, lower, upper)
        elif op in ("like_prefix", "starts_with"):
            # BF-600-L1: supplement-layer prefix prune (mirror of
            # _file_matches_column_stats branch).  Safe when val is a
            # literal prefix.  Round-6 guard: empty val / "%"-only means
            # "match anything" — pruning must fail-open.
            if isinstance(val, str) and val and val != "%":
                _prefix = val[:-1] if val.endswith("%") else val
                if not _prefix:
                    continue
                if "%" not in _prefix and "_" not in _prefix:
                    if isinstance(upper, str) and upper < _prefix:
                        return _drop(col_lower, op, val, lower, upper)
                    try:
                        from core.predicate_coerce import (
                            like_prefix_upper_bound as _lpub,
                        )
                        _upper_bound = _lpub(_prefix)
                        if isinstance(lower, str) and lower > _upper_bound:
                            return _drop(col_lower, op, val, lower, upper)
                    except Exception as _supp_lp_exc:
                        logger.debug(
                            "BF-600-L1 supplement like_prefix upper-bound "
                            "skipped (fail-open keep): %s", _supp_lp_exc,
                        )
        # !=, like (interior %), contains — supplement bounds can't safely prune
    return True


# ── Metadata + manifest traversal ────────────────────────────────────────────

def _get_metadata_cache_ttl() -> int:
    """Read TTL from config, fall back to module default."""
    try:
        from core.config import get
        return int(get("iceberg", "metadata_cache_ttl_seconds", _METADATA_CACHE_TTL))
    except Exception:
        return _METADATA_CACHE_TTL


def invalidate_metadata_cache(bucket: str = "", prefix: str = "") -> int:
    """Invalidate cached metadata keys and content.  Called by admin cache-clear endpoints.

    If bucket+prefix given, invalidate that one entry.  Otherwise clear all.
    Returns number of key-cache entries removed.
    """
    with _metadata_key_cache_lock:
        if bucket and prefix:
            cache_id = f"{bucket}/{prefix}"
            if cache_id in _metadata_key_cache:
                del _metadata_key_cache[cache_id]
                removed = 1
            else:
                removed = 0
        else:
            removed = len(_metadata_key_cache)
            _metadata_key_cache.clear()

    # Also clear content cache entries for this bucket/prefix
    with _metadata_content_cache_lock:
        if bucket and prefix:
            stale = [k for k in _metadata_content_cache if k.startswith(f"{bucket}/")]
            for k in stale:
                del _metadata_content_cache[k]
        else:
            _metadata_content_cache.clear()

    return removed


# ── BF-511 (2026-05-28): single pointer-verify helper ────────────────────────
# Three layers (fresh in-memory hit, stale in-memory hit, DB hit) all need the
# same cheap version-hint.text check.  Before BF-511, the fresh-hit and
# stale-hit paths each open-coded the check (two near-identical 30-line
# blocks); the DB hit had no check at all.  This helper is the single source
# of truth so adding a new cache layer in the future cannot re-introduce the
# "stale forever" failure mode by accident.
_POINTER_VERIFIED_MATCH = "verified_match"
_POINTER_ADVANCED = "pointer_advanced"
_POINTER_VERIFY_FAILED = "verify_failed"


def _verify_or_trust_pointer(
    s3_client, bucket: str, meta_prefix: str, cached_key: str,
    cache_id: str,
) -> str:
    """Smart-brain wrapper around ``_verify_pointer_against_version_hint``.

    Short-circuits the per-query S3 GET when the BF-299 watcher has
    reconciled THIS cache_id within the configured trust window
    (``iceberg.cache_trust_window_seconds``, default 300s).  The watcher
    has just authoritatively refreshed the pointer + manifest cache, so
    paying for a `version-hint.text` round-trip on the next query is
    pure overhead.

    Returns the same three verdicts as the underlying verifier
    (``VERIFIED_MATCH`` / ``ADVANCED`` / ``VERIFY_FAILED``), letting
    callers keep their existing decision logic unchanged.  When the
    trust window short-circuits, returns ``VERIFIED_MATCH`` (the
    watcher's contract IS verification).

    Degrades gracefully: window=0 disables, no tick recorded yet
    behaves like no trust, stale tick falls through to live verify.
    """
    try:
        from core.iceberg_metadata_sync import (
            is_cache_trusted, watcher_tick_age_seconds,
        )
        if is_cache_trusted(cache_id):
            try:
                from core.brain_trace import trace as _btrace
                _btrace("cache_check", "trusted",
                        cache_id=cache_id,
                        tick_age_s=watcher_tick_age_seconds(cache_id))
            except Exception as _be_exc:
                note_best_effort("_btrace(...)", _be_exc,
                                 logger=logger)
            return _POINTER_VERIFIED_MATCH
    except Exception as _be_exc:
        # Import-time failure (circular dep / sync module absent) —
        # silently fall through to live verify.  Never crash a query
        # because the trust shortcut couldn't load.
        note_best_effort("_POINTER_VERIFIED_MATCH", _be_exc,
                         logger=logger)
    _result = _verify_pointer_against_version_hint(
        s3_client, bucket, meta_prefix, cached_key)
    try:
        from core.brain_trace import trace as _btrace
        _btrace("cache_check", _result, cache_id=cache_id)
    except Exception as _be_exc:
        note_best_effort("_btrace('cache_check', _result, cache_id=cache_id)", _be_exc,
                         logger=logger)
    return _result


def _verify_pointer_against_version_hint(
    s3_client, bucket: str, meta_prefix: str, cached_key: str,
) -> str:
    """Cheap version-hint.text GET to decide whether ``cached_key`` is still
    the current Iceberg metadata pointer.

    Returns one of ``_POINTER_VERIFIED_MATCH`` / ``_POINTER_ADVANCED`` /
    ``_POINTER_VERIFY_FAILED``.  Caller decides what to do with each
    outcome — fresh/stale in-memory hits typically fail-open
    (``VERIFY_FAILED`` → serve cache), DB hits typically fail-safe
    (``VERIFY_FAILED`` → defer to hard-max-age check).

    Cost: 1 S3 GET (~5-10ms).  Returns ``VERIFY_FAILED`` for V1 tables
    that don't write version-hint.text — caller must handle that case
    without panicking, since serving cached data is the only option.
    """
    if not cached_key:
        return _POINTER_VERIFY_FAILED
    try:
        from core.config import get as _cfg_get
        if not bool(_cfg_get("iceberg", "cache_pointer_verification", True)):
            # Operator opted out — treat as "couldn't verify" so caller's
            # hard-max-age check still kicks in for DB hits.
            return _POINTER_VERIFY_FAILED
    except Exception as _be_exc:
        note_best_effort("_POINTER_VERIFY_FAILED", _be_exc,
                         logger=logger)
    try:
        hint_key = meta_prefix.rstrip("/") + "/version-hint.text"
        resp = s3_client.get_object(Bucket=bucket, Key=hint_key)
        live_ver = resp["Body"].read().decode("utf-8").strip().lstrip("0")
        cached_basename = cached_key.rsplit("/", 1)[-1]
        cached_ver = cached_basename.split("-", 1)[0].lstrip("0")
        if not live_ver or not cached_ver:
            return _POINTER_VERIFY_FAILED
        return (_POINTER_VERIFIED_MATCH if live_ver == cached_ver
                else _POINTER_ADVANCED)
    except Exception as exc:
        if _is_no_such_key_error(exc):
            # 2026-10-07 -- NO version-hint.text is the NORMAL case for
            # every metastore catalog (Trino / Glue / JDBC / REST write
            # ``NNNNN-<uuid>.metadata.json`` and no hint).  "Could not
            # verify" was therefore the verdict on every hit for those
            # tables, and the callers served the cached pointer anyway --
            # a committed row stayed invisible for up to an hour.  Those
            # catalogs number versions consecutively, so the question
            # "has anything committed after this pointer?" is ONE LIST of
            # the next version's prefix.
            return _probe_successor_metadata(s3_client, bucket, cached_key)
        logger.debug(
            "_verify_pointer_against_version_hint: skipped (non-fatal): %s",
            exc,
        )
        return _POINTER_VERIFY_FAILED


# ``NNNNN-<uuid>.metadata.json`` / ``NNNNN-<uuid>.gz.metadata.json`` -- the
# file-name convention of every metastore catalog writer (Iceberg's
# BaseMetastoreTableOperations: ``String.format("%05d-%s%s", version, uuid,
# ext)``, version = current + 1).  Hadoop tables (``vN.metadata.json``)
# carry a version-hint and never reach the successor probe.
_SEQUENTIAL_METADATA_NAME = _re_t31.compile(r"^(\d+)-[^/]+\.metadata\.json$")


def _is_no_such_key_error(exc: BaseException) -> bool:
    """True only when S3 said the object does not exist -- an outage, a
    denied request or a timeout is NOT absence and must stay 'unknown'."""
    try:
        if type(exc).__name__ in ("NoSuchKey", "NotFound"):
            return True
        resp = getattr(exc, "response", None)
        if isinstance(resp, dict):
            code = str(((resp.get("Error") or {}).get("Code")) or "")
            return code in ("NoSuchKey", "404", "NotFound")
    except Exception:                                   # pragma: no cover
        return False
    return False


def _probe_successor_metadata(s3_client, bucket: str, cached_key: str) -> str:
    """Has a commit landed after ``cached_key``?  One capped LIST.

    For a sequentially-numbered pointer ``.../00020-<uuid>.metadata.json``
    the next commit can only be ``.../00021-*.metadata.json``, so a LIST of
    that prefix answers it: empty -> nothing committed since
    (``VERIFIED_MATCH``), a metadata file -> ``ADVANCED``.  A pointer not in
    that convention, or a LIST that errors or answers something that is not
    a listing, is ``VERIFY_FAILED`` -- never a confirmation.
    """
    try:
        if not cached_key or "/" not in cached_key:
            return _POINTER_VERIFY_FAILED
        directory, name = cached_key.rsplit("/", 1)
        m = _SEQUENTIAL_METADATA_NAME.match(name)
        if not m:
            return _POINTER_VERIFY_FAILED
        nxt = f"{directory}/{int(m.group(1)) + 1:05d}-"
        resp = s3_client.list_objects_v2(Bucket=bucket, Prefix=nxt, MaxKeys=10)
        if not isinstance(resp, dict):
            return _POINTER_VERIFY_FAILED
        contents = resp.get("Contents") or []
        if not isinstance(contents, list):
            return _POINTER_VERIFY_FAILED
        for obj in contents:
            if isinstance(obj, dict) and str(obj.get("Key") or "").endswith(
                    ".metadata.json"):
                logger.info(
                    "_latest_metadata_key: successor probe found %s after "
                    "cached pointer %s -- a commit has landed",
                    obj.get("Key"), cached_key)
                return _POINTER_ADVANCED
        if resp.get("IsTruncated"):
            return _POINTER_VERIFY_FAILED
        return _POINTER_VERIFIED_MATCH
    except Exception as exc:
        logger.debug("_probe_successor_metadata: failed (unknown, not "
                     "fresh): %s", exc)
        return _POINTER_VERIFY_FAILED


def _staleness_bound_now() -> float:
    """The staleness bound in force for this call (diagnostics only -- the
    DECISION is :func:`_may_serve_unconfirmed_age`)."""
    from core.iceberg_freshness_bound import max_snapshot_staleness_seconds
    return max_snapshot_staleness_seconds()


def _may_serve_unconfirmed_age(confirmed_age_seconds) -> bool:
    """May a pointer last confirmed ``confirmed_age_seconds`` ago answer
    without a live probe?  Delegates to the ONE decision
    (``core.iceberg_freshness_bound.may_serve_unconfirmed``)."""
    from core.iceberg_freshness_bound import may_serve_unconfirmed
    return may_serve_unconfirmed(confirmed_age_seconds)


def _entry_confirmed_age(entry) -> Optional[float]:
    """Seconds since an in-memory pointer entry was last CONFIRMED newest.

    ``confirmed`` is stamped by every writer (a fresh resolve = now, a DB
    row = its updated_at).  An entry from before the field existed falls
    back to ``ts`` -- the moment it was cached, which for those writers was
    the moment it was resolved.
    """
    try:
        stamp = entry.get("confirmed", entry.get("ts"))
        return None if stamp is None else _time.time() - float(stamp)
    except Exception:
        return None


def _may_serve_unconfirmed_entry(entry) -> bool:
    return _may_serve_unconfirmed_age(_entry_confirmed_age(entry))


def _metadata_key_db_cache_max_age_seconds() -> int:
    """Config-driven ceiling for serving DB-cached metadata keys.

    ``0`` disables the DB cache layer entirely (every in-memory miss
    resolves from version-hint.text or capped scan).
    """
    try:
        from core.config import get as _cfg_get
        return int(_cfg_get(
            "iceberg", "metadata_key_db_cache_max_age_seconds",
            _METADATA_DB_CACHE_MAX_AGE_SECONDS_DEFAULT))
    except Exception:
        return _METADATA_DB_CACHE_MAX_AGE_SECONDS_DEFAULT


_AUTO_SUPP_LAUNCHED: Dict[str, float] = {}
_AUTO_SUPP_LOCK = threading.Lock()
_AUTO_SUPP_COOLDOWN_SECONDS = 600  # 10 minutes between auto-triggers per table

# 2026-07-15 — bloom-sidecar self-heal (mirrors BF-547 supplement auto-heal).
# When a query filters `col IN (...)` / `col = x` and the bloom sidecar has NO
# rows for that column (never built -> can't prune -> user sees "4000 files
# scanned for a 2-value IN"), fire a background scan so the NEXT query prunes.
# Keyed per (bucket, table_prefix, sorted-cols) so distinct filter-column sets
# each get one build; 10-minute cooldown throttles a query storm.
_AUTO_BLOOM_LAUNCHED: Dict[str, float] = {}
_AUTO_BLOOM_LOCK = threading.Lock()
_AUTO_BLOOM_COOLDOWN_SECONDS = 600  # 10 minutes between auto bloom-builds per (table,cols)

# 2026-08-20 — (table, cols, SNAPSHOT) sets whose bloom build is pointless
# because min/max bounds already decide equality for every requested column.
#
# BLOOM ANSWERS SET MEMBERSHIP; BOUNDS ANSWER RANGES.  When a column holds ONE
# value per file (min == max — a partition column, or anything the writer
# clusters on), the bound is already an exact equality test, and a bloom filter
# cannot narrow further.  The sidecar detects this and correctly declines to
# scan.  Without this set the trigger re-fires every 10 minutes, re-probes the
# supplement, and logs a fresh scare each time.
#
# Keyed by SNAPSHOT: a later snapshot can land multiple values per file for the
# same column, at which point bloom becomes worth building again.
_AUTO_BLOOM_BOUNDS_DECIDED: Dict[str, float] = {}


def _maybe_trigger_async_bloom_scan(
    bucket: str, table_prefix: str,
    metadata: Dict[str, Any], data_files: List[Dict[str, Any]],
    bloom_columns: List[str],
    connection_id: Optional[int] = None,
) -> None:
    """Fire-and-forget background bloom-sidecar build for eq/in filter columns.

    Bloom pruning can only skip a file once a bloom row EXISTS for the queried
    column.  The adaptive-prefetch daemon builds those eventually (≥3 query-
    history hits, hourly), but a fresh column a user is actively filtering on
    scans every file until then.  This trigger closes that gap: on a bloom
    coverage-miss it scans the current snapshot's files for exactly the queried
    columns and populates ``iceberg_bloom_sidecar_v1`` — so the next identical
    query prunes.  Bloom is FAIL-OPEN (a missing/older row only over-keeps,
    never drops), so a background build can never cause data loss.

    Opt-out via ``iceberg.auto_bloom_on_query_miss=false``.  Throttled per
    ``(bucket, table_prefix, sorted-cols)`` on a 10-minute cooldown.
    """
    if not (bucket and table_prefix and bloom_columns and data_files):
        return
    if connection_id is None:
        return  # need a tagged connection to rebuild an S3 client off-thread
    try:
        from core.config import get as _cfg_get
        if not bool(_cfg_get("iceberg", "auto_bloom_on_query_miss", False)):
            return
    except Exception as _be_exc:
        note_best_effort("return", _be_exc,
                         logger=logger)
    _cols_sorted = sorted({(c or "").split(".")[-1].lower() for c in bloom_columns if c})
    if not _cols_sorted:
        return
    key = f"{bucket}/{table_prefix}::{','.join(_cols_sorted)}"
    now = _time.time()
    with _AUTO_BLOOM_LOCK:
        _last = _AUTO_BLOOM_LAUNCHED.get(key, 0)
        if (now - _last) < _AUTO_BLOOM_COOLDOWN_SECONDS:
            logger.debug("auto-bloom skipped (cooldown): %s", key)
            return
        # Evict entries whose cooldown has fully elapsed so this dict
        # can't grow without bound across many distinct (table, cols)
        # keys — an expired entry no longer suppresses anything, so it
        # is safe to drop.  O(n) sweep, n bounded by active tables.
        _expiry = now - _AUTO_BLOOM_COOLDOWN_SECONDS
        _stale = [k for k, ts in _AUTO_BLOOM_LAUNCHED.items() if ts < _expiry]
        for k in _stale:
            _AUTO_BLOOM_LAUNCHED.pop(k, None)
        _AUTO_BLOOM_LAUNCHED[key] = now
    snapshot_id = metadata.get("current-snapshot-id") if isinstance(metadata, dict) else None
    if snapshot_id is None:
        return
    _decided_key = f"{key}::{snapshot_id}"
    with _AUTO_BLOOM_LOCK:
        if _decided_key in _AUTO_BLOOM_BOUNDS_DECIDED:
            logger.debug(
                "auto-bloom skipped: min/max bounds already decide %s for "
                "snapshot %s — a bloom filter cannot narrow further",
                _cols_sorted, snapshot_id)
            return
    file_keys = [
        df.get("key") or df.get("path") or ""
        for df in data_files if (df.get("key") or df.get("path"))
    ]
    if not file_keys:
        return
    # PROBE-SAFETY (2026-07-15): the bloom scan reads the ENTIRE column chunk
    # per file — heavy CPU+S3 IO.  Doing that for thousands of files on the
    # live query pod can starve the liveness probe and restart the pod.  So we
    # do NOT auto-heal large tables inline: above the cap we log a one-line
    # instruction to run the OFFLINE admin scan (which runs isolated) and bail.
    # Bloom is fail-open, so declining to build just means "no pruning yet" —
    # never wrong data.  Small/medium tables self-heal safely.
    try:
        from core.config import get as _cfg_get2
        # 2026-07-22: default 10000 (was 1500).  A single COB partition is
        # commonly ~2k files — with the old 1500 cap the auto-build SILENTLY
        # SKIPPED, so the bloom sidecar never populated for exactly the tables
        # that need it and "system_id IN (...) still scans every file" persisted
        # forever.  The build is a bounded low-concurrency background job; 10k
        # gives real partitions room while still deferring a pathological
        # whole-table build to the offline admin scan.
        _auto_bloom_max = int(_cfg_get2("iceberg", "auto_bloom_max_files", 10000))
    except Exception:
        _auto_bloom_max = 10000
    if _auto_bloom_max > 0 and len(file_keys) > _auto_bloom_max:
        logger.warning(
            "auto-bloom SKIPPED for %s/%s cols=%s — %d files exceeds the inline "
            "cap (iceberg.auto_bloom_max_files=%d).  A scan this large on the "
            "query pod could starve the liveness probe; run it OFFLINE instead: "
            "POST /api/admin/iceberg/bloom/scan (isolated worker).  Until then "
            "these queries scan all files (correct, just not pruned).",
            bucket, table_prefix, _cols_sorted, len(file_keys), _auto_bloom_max,
        )
        return
    logger.info(
        "auto-bloom: building bloom sidecar for %s/%s cols=%s over %d files "
        "(bloom coverage-miss on an eq/in filter — next query will prune)",
        bucket, table_prefix, _cols_sorted, len(file_keys),
    )

    def _run() -> None:
        try:
            from core.connection_manager import get_connection_manager
            cm = get_connection_manager()
            if not (cm and getattr(cm, "db", None)):
                return
            conn = cm.db.get_connection_raw(int(connection_id))
            if not conn:
                return
            from core.s3_utilities import make_s3_client_for_conn
            sub_s3 = make_s3_client_for_conn(conn)
            if sub_s3 is None:
                return
            from core.iceberg_bloom_sidecar import scan_files_for_bloom
            # PROBE-SAFETY: low concurrency (2, not the daemon's 8) so a
            # piggy-backed build can't saturate the query pod's CPU/IO and
            # starve the health probe.  Configurable via iceberg.auto_bloom_workers.
            try:
                from core.config import get as _cfg_get3
                _ab_workers = max(1, int(_cfg_get3("iceberg", "auto_bloom_workers", 2)))
            except Exception:
                _ab_workers = 2
            _res = scan_files_for_bloom(
                cm.db, sub_s3, bucket, table_prefix,
                str(snapshot_id), file_keys,
                target_columns=_cols_sorted,
                max_workers=_ab_workers,
                skip_already_scanned=True,
                connection_id=int(connection_id),
            )
            _ins = (_res or {}).get("rows_inserted", 0)
            _scn = (_res or {}).get("scanned", 0)
            _fld = (_res or {}).get("failed", 0)
            if _ins > 0:
                logger.info(
                    "auto-bloom scan COMPLETE for %s (cols=%s, %d files scanned, "
                    "%d rows inserted) — subsequent eq/in queries on these cols "
                    "will now prune",
                    key, _cols_sorted, _scn, _ins,
                )
            else:
                # 2026-08-20 — this branch used to blame "the per-file distinct
                # cap or unreadable files" for EVERY zero-row outcome, including
                # the one where the sidecar did exactly the right thing.
                #
                # The sidecar reports which columns it skipped because their
                # bounds are SINGLETON (min == max per file, so the bound is
                # already an exact equality test and bloom adds nothing).  That
                # field was ignored, so a healthy, correct decision was logged
                # as a suspected S3 read failure — sending an operator to look
                # at bucket permissions when the honest answer is "nothing to
                # build here".  scanned=0 with failed=0 cannot mean "files were
                # unreadable": nothing was opened.
                _singleton = [c for c in ((_res or {}).get(
                    "skipped_singleton_cols") or [])]
                if _singleton and not set(_cols_sorted) - set(_singleton):
                    with _AUTO_BLOOM_LOCK:
                        _AUTO_BLOOM_BOUNDS_DECIDED[_decided_key] = _time.time()
                    logger.info(
                        "auto-bloom NOT NEEDED for %s (cols=%s) — min/max bounds "
                        "already decide equality for every requested column "
                        "(one value per file), so a bloom filter cannot narrow "
                        "further.  Pruning for these columns is already working "
                        "via bounds; no build scheduled.",
                        key, _singleton,
                    )
                elif _scn == 0:
                    logger.info(
                        "auto-bloom scanned no files for %s (cols=%s) — every "
                        "(file, column) pair was already present or skipped; "
                        "nothing new to build",
                        key, _cols_sorted,
                    )
                else:
                    logger.warning(
                        "auto-bloom scan produced 0 bloom rows for %s (cols=%s, "
                        "scanned=%d, failed=%d) — column may exceed the per-file "
                        "distinct cap or files were unreadable; pruning stays off "
                        "for these cols",
                        key, _cols_sorted, _scn, _fld,
                    )
        except Exception as exc:
            logger.warning("auto-bloom scan errored for %s: %s", key, exc)

    try:
        _t = threading.Thread(target=_run, name="auto-bloom-scan", daemon=True)
        _t.start()
    except Exception as exc:
        logger.debug("auto-bloom thread launch failed: %s", exc)


# ── 2026-07-15 PRUNABILITY PROFILES (audit Finding #3/#4) ────────────────
# The brain never reasoned about WHETHER a column is prunable — it waited
# for the background daemon to build a bloom after 3 lucky query-history
# hits.  Result: ``system_id IN (...)`` scanned thousands of files because
# min/max can't prune a high-cardinality unsorted id column and no bloom
# existed yet.  ``_bloom_worthiness`` is the pure DECISION: given the
# accumulated profile + this query's scan size, does this column NEED a
# bloom sidecar?  Profiles may only INFORM which artifacts to BUILD and
# which diagnostics to emit — they NEVER change keep/drop correctness.

_PRUNABILITY_OVERLAP_THRESHOLD_DEFAULT = 0.5   # min/max failed to prune >= 50% of files
_PRUNABILITY_MIN_FILES_DEFAULT = 64            # don't bother below this scan size


def _prunability_thresholds() -> Dict[str, float]:
    """Config-backed thresholds for the bloom-worthiness decision.
    Tuning these can only change which artifacts get BUILT / which
    diagnostics get logged — never which files a query keeps."""
    overlap_min = _PRUNABILITY_OVERLAP_THRESHOLD_DEFAULT
    min_survivors = _PRUNABILITY_MIN_FILES_DEFAULT
    try:
        from core.config import get as _cfg_get
        overlap_min = float(_cfg_get(
            "iceberg", "prunability_overlap_threshold",
            _PRUNABILITY_OVERLAP_THRESHOLD_DEFAULT))
        min_survivors = int(_cfg_get(
            "iceberg", "prunability_min_files",
            _PRUNABILITY_MIN_FILES_DEFAULT))
    except Exception as _be_exc:
        note_best_effort("int(...)", _be_exc,
                         logger=logger)
    return {"overlap_min": overlap_min, "min_survivors": min_survivors}


def _bloom_worthiness(
    profile: Optional[Dict[str, Any]],
    survivors: int,
    has_bloom: bool,
    thresholds: Optional[Dict[str, float]] = None,
) -> Tuple[bool, str]:
    """Decide from EVIDENCE whether an eq/in filter column NEEDS a bloom
    sidecar — on the FIRST query, not after 3 lucky history hits.

    Args:
        profile:    merged prunability profile dict (needs
                    ``bounds_overlap_ratio``; other keys optional) — either
                    the DB running-average row or this query's observation.
        survivors:  number of files this query actually had to scan for
                    the column (post-pruning file count).
        has_bloom:  True when a bloom sidecar row already exists for the
                    column (nothing to build).
        thresholds: {"overlap_min": float, "min_survivors": int} — falls
                    back to defaults when absent.

    Returns:
        (needs_bloom, human-readable reason).  PURE — no I/O, no side
        effects; never raises on missing/odd profile shapes (returns
        (False, reason) instead).  The verdict only routes artifact
        BUILDS + diagnostics; it never gates a keep/drop decision.
    """
    th = thresholds or {}
    try:
        overlap_min = float(th.get("overlap_min",
                                   _PRUNABILITY_OVERLAP_THRESHOLD_DEFAULT))
    except (TypeError, ValueError):
        overlap_min = _PRUNABILITY_OVERLAP_THRESHOLD_DEFAULT
    try:
        min_survivors = int(th.get("min_survivors",
                                   _PRUNABILITY_MIN_FILES_DEFAULT))
    except (TypeError, ValueError):
        min_survivors = _PRUNABILITY_MIN_FILES_DEFAULT
    if has_bloom:
        return False, "bloom sidecar already exists for this column"
    if not isinstance(profile, dict) or not profile:
        return False, "no prunability profile (no evidence yet)"
    try:
        overlap = float(profile.get("bounds_overlap_ratio") or 0.0)
    except (TypeError, ValueError):
        return False, "profile unreadable (bounds_overlap_ratio not numeric)"
    try:
        survivors_i = int(survivors)
    except (TypeError, ValueError):
        survivors_i = 0
    if survivors_i < min_survivors:
        return False, (
            f"only {survivors_i} file(s) scanned "
            f"(< prunability_min_files={min_survivors}) — bloom gain too small")
    if overlap >= overlap_min:
        return True, (
            f"bounds overlap {overlap:.0%} >= {overlap_min:.0%} over "
            f"{survivors_i} scanned file(s) — min/max cannot prune this "
            f"column; a bloom sidecar would")
    return False, (
        f"bounds overlap {overlap:.0%} < {overlap_min:.0%} — min/max "
        f"pruning is effective for this column")


# 2026-06-09 — per-(bucket, prefix, col) self-heal failure memory.
# User feedback: "brain needs more learning".  When BF-547 auto-scan
# fails with access_denied / file_not_found, retrying every 10 minutes
# wastes resources AND spams the operator with "scan failed" warnings
# that won't resolve until IAM / snapshot is fixed.  Brain now
# remembers: for a (bucket, prefix, col) tuple that has FAILED-HARD
# with a non-transient failure category, skip the auto-retry until
# the brain sees a successful supplement load for that col (signal
# that operator fixed the underlying cause).
_AUTO_HEAL_BLOCKED: Dict[str, Dict[str, Any]] = {}
_AUTO_HEAL_BLOCKED_LOCK = threading.Lock()


def _is_auto_heal_blocked(bucket: str, table_prefix: str, col: str) -> bool:
    """Check if (bucket, prefix, col) is on the no-retry list."""
    key = f"{bucket}|{table_prefix.rstrip('/')}|{col.lower()}"
    with _AUTO_HEAL_BLOCKED_LOCK:
        entry = _AUTO_HEAL_BLOCKED.get(key)
        if entry is None:
            return False
        # The block lifts when operator clears it (via admin) OR when
        # the supplement table later DOES have data for this col (the
        # signal that the underlying cause has been resolved).
        return True


def _mark_auto_heal_blocked(
    bucket: str, table_prefix: str, col: str,
    reason: str, category: str,
) -> None:
    key = f"{bucket}|{table_prefix.rstrip('/')}|{col.lower()}"
    with _AUTO_HEAL_BLOCKED_LOCK:
        _AUTO_HEAL_BLOCKED[key] = {
            "bucket":     bucket,
            "prefix":     table_prefix.rstrip("/"),
            "col":        col.lower(),
            "blocked_at": _time.time(),
            "reason":     reason,
            "category":   category,
        }


def _unblock_auto_heal_if_supplement_arrived(
    bucket: str, table_prefix: str, supp_cols_lower: Set[str],
) -> None:
    """Called from the supplement-load path.  If a col previously
    failed-hard but the supplement table NOW has rows for it (operator
    fixed IAM and ran a manual scan), drop the block so BF-547 will
    re-try future cols too."""
    pfx = table_prefix.rstrip("/")
    with _AUTO_HEAL_BLOCKED_LOCK:
        to_drop = []
        for key, entry in _AUTO_HEAL_BLOCKED.items():
            if entry["bucket"] == bucket and entry["prefix"] == pfx:
                if entry["col"] in supp_cols_lower:
                    to_drop.append(key)
        for k in to_drop:
            _AUTO_HEAL_BLOCKED.pop(k, None)
        if to_drop:
            logger.info(
                "BF-547 auto-heal: unblocking %d previously-failed "
                "(col) entries for %s/%s (supplement now has data — "
                "operator must have resolved underlying cause)",
                len(to_drop), bucket, pfx,
            )


def _suggest_fix_from_categories(categories: Dict[str, int]) -> str:
    """Turn failure-category counts into one actionable operator
    instruction.  2026-06-09 — added so the brain stops shrugging
    when an auto-heal scan fails; it now tells the user EXACTLY
    what to fix."""
    if not categories:
        return ("unknown failure mode — check the column-stats scan "
                "log for the actual exception")
    if categories.get("access_denied"):
        return ("s3:GetObject denied — connection's IAM role / bucket "
                "policy is missing GetObject for the data files.  "
                "Fix the IAM policy and re-run the query (BF-547 will "
                "auto-retry after the 10-min cooldown).")
    if categories.get("file_not_found"):
        return ("data files missing — Iceberg snapshot points at files "
                "S3 no longer has.  Either run an iceberg compaction "
                "to drop dead files OR force-refresh the snapshot "
                "cache (Admin → Iceberg Cache → Refresh).")
    if categories.get("decode_error"):
        return ("parquet footer decode failed — file format may be "
                "corrupted or use unsupported codec.  Check writer "
                "version compatibility.")
    return f"see categories detail: {categories}"


def _maybe_trigger_async_supplement_scan(
    s3_client, bucket: str, table_prefix: str,
    metadata: Dict[str, Any], data_files: List[Dict[str, Any]],
    missing_columns: List[str],
    connection_id: Optional[int] = None,
) -> None:
    """BF-547 (2026-05-28): fire-and-forget background column-stats scan.

    When a query needs file-level pruning on columns whose bounds are
    absent from manifests AND not in the supplement, spawn a daemon
    thread that scans the data-file footers and populates the
    supplement.  Subsequent queries on those columns get full file-
    level pruning.

    Throttled per ``(bucket, table_prefix)`` to a 10-minute cooldown so
    a stream of queries doesn't kick off N concurrent scans.  Operator
    opt-out via ``iceberg.auto_supplement_on_query_miss=false``.
    """
    if not (bucket and table_prefix and missing_columns and data_files):
        return
    if connection_id is None:
        # Can't easily reconstruct an S3 client in a daemon thread
        # without a tagged connection — skip the auto-trigger.
        return
    # 2026-06-09 brain LEARNING — filter out cols this brain has
    # previously failed-hard on for THIS (bucket, prefix).  Retrying
    # every 10 minutes on an access_denied / file_not_found col
    # wastes resources and spams the logs.  When operator fixes the
    # underlying cause and supplement data appears for the col, the
    # block clears automatically (see
    # _unblock_auto_heal_if_supplement_arrived call site).
    _filtered_cols = [
        c for c in missing_columns
        if not _is_auto_heal_blocked(bucket, table_prefix, c)
    ]
    if not _filtered_cols:
        logger.info(
            "BF-547 auto-supplement skipped — all requested cols=%s "
            "are on the no-retry blocklist for %s (previously failed-"
            "hard with non-transient cause; brain waits for operator "
            "to fix IAM / snapshot)",
            missing_columns, f"{bucket}/{table_prefix}",
        )
        return
    if len(_filtered_cols) < len(missing_columns):
        _skipped = [c for c in missing_columns if c not in _filtered_cols]
        logger.info(
            "BF-547 auto-supplement: scanning %s (skipping %s — "
            "previously failed-hard, awaiting operator fix)",
            _filtered_cols, _skipped,
        )
    missing_columns = _filtered_cols
    key = f"{bucket}/{table_prefix}"
    now = _time.time()
    with _AUTO_SUPP_LOCK:
        _last = _AUTO_SUPP_LAUNCHED.get(key, 0)
        if (now - _last) < _AUTO_SUPP_COOLDOWN_SECONDS:
            logger.debug(
                "BF-547 auto-supplement skipped (cooldown): %s", key)
            return
        _AUTO_SUPP_LAUNCHED[key] = now
    # Capture the values we'll need inside the daemon thread.
    snapshot_id = metadata.get("current-snapshot-id") if isinstance(metadata, dict) else None
    if snapshot_id is None:
        return
    file_keys = [
        df.get("key") or df.get("path") or ""
        for df in data_files if (df.get("key") or df.get("path"))
    ]
    if not file_keys:
        return

    def _run() -> None:
        try:
            from core.connection_manager import get_connection_manager
            cm = get_connection_manager()
            if not (cm and getattr(cm, "db", None)):
                return
            conn = cm.db.get_connection_raw(int(connection_id))
            if not conn:
                return
            from core.s3_utilities import make_s3_client_for_conn
            sub_s3 = make_s3_client_for_conn(conn)
            if sub_s3 is None:
                return
            from core.iceberg_column_stats import scan_files_to_supplement
            # 2026-06-09 — capture the scan result so we can REPORT
            # honestly.  Pre-fix the log said "COMPLETE" even when the
            # scan failed 100% (user saw "failed=6830, rows_inserted=0
            # ... BF-547 ... COMPLETE" in the same breath).  That's
            # the brain lying — exactly what user pushed back on with
            # "brain needs more learning".
            _scan_result = scan_files_to_supplement(
                cm.db, sub_s3, bucket, table_prefix,
                str(snapshot_id), file_keys,
                target_columns=missing_columns,
                max_workers=8,  # gentle — we're piggy-backing on a
                                # user query
                skip_already_scanned=True,
                connection_id=int(connection_id),
            )
            _rows_inserted = (_scan_result or {}).get("rows_inserted", 0)
            _scanned = (_scan_result or {}).get("scanned", 0)
            _failed = (_scan_result or {}).get("failed", 0)
            _failure_cats = (_scan_result or {}).get("failure_categories") or {}
            if _rows_inserted > 0:
                logger.info(
                    "BF-547 auto-supplement scan COMPLETE for %s "
                    "(cols=%s, %d files scanned, %d rows inserted)",
                    key, missing_columns, _scanned, _rows_inserted,
                )
            elif _failed and not _scanned:
                # Honest failure report.  All files failed; the brain
                # cannot self-heal until the underlying cause (most
                # commonly access_denied or file_not_found) is fixed.
                logger.warning(
                    "BF-547 auto-supplement scan FAILED-HARD for %s "
                    "(cols=%s, attempted=%d, succeeded=0, failed=%d, "
                    "categories=%s).  Brain CANNOT self-heal this "
                    "column.  Operator action required: %s",
                    key, missing_columns, len(file_keys), _failed,
                    _failure_cats,
                    _suggest_fix_from_categories(_failure_cats),
                )
                # Brain LEARNING: remember the failure so we stop
                # retrying every 10 minutes on a hard-blocked
                # (bucket, prefix, col) tuple.  Operator's fix to
                # IAM / snapshot will clear the block automatically
                # when supplement data later appears for the col.
                _dominant_cat = max(
                    (_failure_cats.items() if _failure_cats else
                     [("unknown", 0)]),
                    key=lambda kv: kv[1],
                    default=("unknown", 0),
                )[0]
                for _col in (missing_columns or []):
                    _mark_auto_heal_blocked(
                        bucket, table_prefix, _col,
                        reason=_suggest_fix_from_categories(_failure_cats),
                        category=_dominant_cat,
                    )
            else:
                logger.info(
                    "BF-547 auto-supplement scan PARTIAL for %s "
                    "(cols=%s, scanned=%d, inserted=%d, failed=%d)",
                    key, missing_columns,
                    _scanned, _rows_inserted, _failed,
                )
        except Exception as exc:
            logger.warning(
                "BF-547 auto-supplement scan RAISED for %s: %s",
                key, exc, exc_info=True,
            )

    t = threading.Thread(target=_run, daemon=True,
                          name=f"qs-bf547-supplement-{bucket[:20]}")
    t.start()
    logger.info(
        "BF-547 auto-supplement scan QUEUED for %s "
        "(cols=%s, %d files) — next query will benefit",
        key, missing_columns, len(file_keys),
    )


def _parse_cache_id(cache_id: str) -> Optional[tuple]:
    """Split ``cache_id`` = ``f"{bucket}/{meta_prefix}"`` back into
    ``(bucket, meta_prefix)``.  The first ``/`` is the separator; the
    meta_prefix may contain further ``/`` characters and typically ends
    with ``metadata/``.  Returns None on malformed input."""
    if not cache_id or "/" not in cache_id:
        return None
    bucket, _, meta_prefix = cache_id.partition("/")
    if not bucket or not meta_prefix:
        return None
    return bucket, meta_prefix


# BF-526 (2026-05-28): per-resolution freshness telemetry.  When
# ``_latest_metadata_key`` serves a cached pointer, it stamps the s3
# client (if supplied) with a freshness verdict the caller can read at
# response-build time and surface to the user as a badge or extra
# field.  Possible values:
#   * "verified"            — cache hit confirmed against version-hint
#   * "cached_unverified"   — cache hit served because verify failed
#                             (V1 table / transient outage / config opt-out)
#                             AND row was within hard max-age
#   * "fresh"               — Layer 3 / Layer 4 fresh resolve
# Empty string ("") = freshness unknown (e.g. pre-loaded metadata path
# never went through this function).
_FRESHNESS_VERIFIED = "verified"
_FRESHNESS_CACHED_UNVERIFIED = "cached_unverified"
_FRESHNESS_FRESH = "fresh"


def _stamp_freshness(s3_client, label: str) -> None:
    """Best-effort: attach ``_qs_iceberg_freshness`` to the s3 client
    so the response-builder can read it.  Never raises — diagnostic
    only."""
    if s3_client is None or not label:
        return
    try:
        setattr(s3_client, "_qs_iceberg_freshness", label)
    except Exception as _stamp_exc:
        # Some boto3 client wrappers use __slots__ — a setattr failure
        # just means freshness signal isn't available for this client;
        # query result is unaffected.
        logger.debug("BF-526 freshness stamp skipped: %s", _stamp_exc)


def refresh_metadata_key_db_row(connection_id: Optional[int],
                                  cache_id: str) -> Dict[str, Any]:
    """BF-512 (2026-05-28): re-resolve ONE DB-cached metadata key from S3.

    Builds an S3 client for ``connection_id`` and calls
    ``_latest_metadata_key(..., force_fresh=True)`` — the resolver does
    Layer 3 (version-hint.text) → Layer 4 (capped scan) and updates
    BOTH the in-memory cache and the DB row via ``_cache_metadata_key``.

    Returns ``{ok, cache_id, old_key, new_key, advanced, error}`` for
    the background-job telemetry.  Never raises — failures are
    captured in the result so a bad row doesn't kill the sweep.

    Sentinel rows (``connection_id`` in {None, 0}) are refused because
    we cannot build an S3 client without a real connection.  Caller
    should pre-filter those out.
    """
    result: Dict[str, Any] = {
        "ok": False, "cache_id": cache_id,
        "old_key": None, "new_key": None,
        "advanced": False, "error": None,
    }
    if connection_id is None or int(connection_id) == 0:
        result["error"] = "sentinel_connection"
        return result
    parsed = _parse_cache_id(cache_id)
    if parsed is None:
        result["error"] = "malformed_cache_id"
        return result
    bucket, meta_prefix = parsed

    # Capture the current cached key (if any) so the caller can tell
    # whether this refresh actually moved the pointer.
    try:
        with _metadata_key_cache_lock:
            mem_row = _metadata_key_cache.get(cache_id)
        if mem_row:
            result["old_key"] = mem_row.get("key")
        else:
            db_row = _load_metadata_key_row_from_db(connection_id, cache_id)
            if db_row:
                result["old_key"] = db_row.get("metadata_key")
    except Exception as _be_exc:
        note_best_effort("mem_row.get('key')", _be_exc,
                         logger=logger)

    # Build the S3 client via the shared helper used elsewhere.
    try:
        from core.connection_manager import get_connection_manager
        cm = get_connection_manager()
        if not (cm and getattr(cm, "db", None)):
            result["error"] = "no_connection_manager"
            return result
        conn = cm.db.get_connection_raw(int(connection_id))
        if not conn:
            result["error"] = "connection_not_found"
            return result
        from core.s3_utilities import make_s3_client_for_conn
        s3 = make_s3_client_for_conn(conn)
        if s3 is None:
            result["error"] = "s3_client_build_failed"
            return result
    except Exception as exc:
        result["error"] = f"s3_client_setup: {exc}"
        return result

    # Force-fresh resolution: skips Layers 1/2/2.5 → straight to
    # version-hint.text or capped scan, then writes the result to
    # both caches.
    try:
        new_key = _latest_metadata_key(s3, bucket, meta_prefix,
                                        force_fresh=True)
        result["new_key"] = new_key
        result["ok"] = True
        if result["old_key"] and new_key and result["old_key"] != new_key:
            result["advanced"] = True
    except Exception as exc:
        result["error"] = f"resolve_failed: {exc}"
        return result
    return result


def _invalidate_result_cache_for_cache_id(cache_id: str) -> None:
    """BF-550 (2026-05-29): when an iceberg metadata pointer advances,
    drop stale result-cache entries that reference this table.

    Never raises — best-effort cleanup so the on-demand resolver stays
    fast even if the cache module is broken or absent.
    """
    if not cache_id:
        return
    try:
        from core.result_cache import get_result_cache
        rc = get_result_cache()
        if rc is None:
            return
        rc.invalidate_for_table(cache_id)
    except Exception as exc:
        logger.debug(
            "BF-550 result-cache invalidate_for_table failed: %s", exc)


def _evict_metadata_key_from_db(connection_id: Optional[int],
                                  cache_id: str) -> None:
    """Drop the persisted metadata key for this cache_id, both per-connection
    and the sentinel(0) row.  Failures are swallowed — eviction is a hint
    to the next call, not a guarantee."""
    try:
        from core.connection_manager import get_connection_manager
        cm = get_connection_manager()
        if not (cm and getattr(cm, "db", None)):
            return
        cm.db.evict_iceberg_metadata_key(connection_id, cache_id)
    except Exception as exc:
        logger.debug("DB evict of metadata_key failed (cache_id=%s): %s",
                     cache_id, exc)


def _latest_metadata_key(s3_client, bucket: str, meta_prefix: str,
                         force_fresh: bool = False) -> str:
    """Return the S3 key of the most-recently-modified ``*.metadata.json`` file.

    Resolution order (designed to NEVER make users wait for large scans):

    1. **Fresh cache** — within TTL (default 60s) → instant return.
       Skipped when ``force_fresh=True`` (Published API / scheduled reports).
    2. **Stale-while-revalidate** — cache expired but within stale window
       (1 hour) → return stale instantly, trigger background refresh.
       User NEVER waits for a full scan after the first cold start.
       Skipped when ``force_fresh=True``.
    3. **version-hint.text** (Iceberg v2) → 1 GET + 1 narrow LIST.
    4. **Capped scan** — paginate up to ``_METADATA_SCAN_MAX_PAGES`` pages
       (100 pages = 100K files).  Stops and uses best found so far.
       At 1M files this means scanning 100K instead of all 1M.
    """
    cache_id = f"{bucket}/{meta_prefix}"
    ttl = _get_metadata_cache_ttl()
    # Phase 141: connection_id needed to read/write the persistent DB cache.
    # Best-effort lookup — None means "no DB persistence for this call"
    # (admin tools, one-off scripts) and the function still works correctly,
    # just without the cross-process cache layer.
    connection_id = _connection_id_from_s3_client(s3_client)

    # ── Layer 1: fresh cache ─────────────────────────────────────────────
    # Skipped for force_fresh (Published API needs latest data)
    if not force_fresh:
        with _metadata_key_cache_lock:
            cached = _metadata_key_cache.get(cache_id)
            # Phase 161 -- LRU touch on hit so eviction tracks
            # recency of access, not first-insert order.
            if cached is not None:
                _metadata_key_cache.move_to_end(cache_id)
        if cached and ttl > 0:
            age = _time.time() - cached["ts"]
            # BF-503 (2026-05-28), refactored BF-511 (2026-05-28): cheap
            # version-hint.text GET to verify the live Iceberg pointer
            # hasn't advanced.  Costs ~5-10ms per call but eliminates
            # "Starburst writes new data → QueryStudio serves stale for
            # 60s" windows.  Helper centralises the check so all three
            # cache layers (fresh / stale / DB) use identical logic.
            if age < ttl:
                # Smart brain: when the BF-299 watcher just reconciled
                # this cache_id, skip the version-hint S3 GET.  Watcher
                # is the authoritative refresh path; verifying its work
                # on every query is wasted I/O.  Stale tick falls through
                # to live verify automatically.
                _verdict = _verify_or_trust_pointer(
                    s3_client, bucket, meta_prefix, cached["key"], cache_id)
                if _verdict == _POINTER_ADVANCED:
                    logger.info(
                        "_latest_metadata_key: pointer advanced on FRESH hit — "
                        "invalidating cache and re-resolving",
                    )
                    with _metadata_key_cache_lock:
                        _metadata_key_cache.pop(cache_id, None)
                    _invalidate_result_cache_for_cache_id(cache_id)  # BF-550
                elif (_verdict != _POINTER_VERIFIED_MATCH
                        and not _may_serve_unconfirmed_entry(cached)):
                    # 2026-10-07 -- FAILED is not "verified".  Served only
                    # while the pointer's last confirmation is inside the
                    # declared staleness bound; past it, re-resolve.
                    logger.info(
                        "_latest_metadata_key: FRESH hit NOT served (verify="
                        "%s, last confirmed %.0fs ago >= staleness bound "
                        "%.0fs) -- re-resolving from S3",
                        _verdict, _entry_confirmed_age(cached),
                        _staleness_bound_now())
                else:
                    # MATCH, or FAILED inside the staleness bound.
                    logger.info(
                        "_latest_metadata_key: CACHE HIT (age=%.0fs, "
                        "verify=%s) → %s",
                        age, _verdict, cached["key"],
                    )
                    _stamp_freshness(s3_client,
                        _FRESHNESS_VERIFIED if _verdict == _POINTER_VERIFIED_MATCH
                        else _FRESHNESS_CACHED_UNVERIFIED)  # BF-526
                    return cached["key"]

            # ── Layer 2: stale-while-revalidate ──────────────────────────
            # BF-507 (2026-05-28), refactored BF-511: same verify on stale
            # hits — without this we'd serve a metadata key up to 1 hour
            # old, far longer than the background refresh might take to
            # complete.  Symptom observed pre-BF-507: STALE HIT returned
            # an old snapshot missing the user's new data → 0 files →
            # CatalogException downstream.
            elif age < _METADATA_STALE_TTL:
                _verdict_stale = _verify_or_trust_pointer(
                    s3_client, bucket, meta_prefix, cached["key"], cache_id)
                if _verdict_stale == _POINTER_ADVANCED:
                    logger.info(
                        "_latest_metadata_key: STALE hit + pointer advanced "
                        "— invalidating and re-resolving (BF-507)",
                    )
                    with _metadata_key_cache_lock:
                        _metadata_key_cache.pop(cache_id, None)
                    _invalidate_result_cache_for_cache_id(cache_id)  # BF-550
                elif (_verdict_stale != _POINTER_VERIFIED_MATCH
                        and not _may_serve_unconfirmed_entry(cached)):
                    # 2026-10-07 -- this branch served an UNVERIFIED pointer
                    # up to _METADATA_STALE_TTL (1 h) old.  Re-resolve.
                    logger.info(
                        "_latest_metadata_key: STALE hit NOT served (verify="
                        "%s, last confirmed %.0fs ago >= staleness bound "
                        "%.0fs) -- re-resolving from S3",
                        _verdict_stale, _entry_confirmed_age(cached),
                        _staleness_bound_now())
                else:
                    logger.info(
                        "_latest_metadata_key: STALE HIT (age=%.0fs, "
                        "ttl=%ds, verify=%s) → %s "
                        "(background refresh triggered)",
                        age, ttl, _verdict_stale, cached["key"],
                    )
                    _stamp_freshness(s3_client,
                        _FRESHNESS_VERIFIED if _verdict_stale == _POINTER_VERIFIED_MATCH
                        else _FRESHNESS_CACHED_UNVERIFIED)  # BF-526
                    _trigger_background_refresh(s3_client, bucket, meta_prefix, cache_id)
                    return cached["key"]

        # ── Layer 2.5: DB-persisted cache (Phase 141, hardened BF-511) ───
        # In-memory miss → check the DB cache before paying for cold S3 scan.
        # Common case: process just restarted, or this table was queried
        # previously by another worker / pod.
        #
        # BF-511 (2026-05-28): the original Phase-141 implementation
        # returned the DB row INSTANTLY with no version-hint verification
        # and kicked a background refresh.  In practice that meant:
        # pod restart + DB row hours-old → first query after restart
        # served a stale snapshot (e.g. April pointer when newer data
        # had landed in May) until the background refresh completed.
        # User-visible bug: "WHERE businessdate = '2026-02-28'" returned
        # empty even though the data was on S3 — the cached April
        # snapshot didn't reference the later-arrived files.
        #
        # Fix: apply the same version-hint verify as fresh/stale hits.
        # Additionally enforce a HARD MAX AGE so a DB row that cannot
        # be corroborated (V1 table, transient S3 outage) cannot serve
        # indefinitely — we cap blast radius to
        # ``iceberg.metadata_key_db_cache_max_age_seconds`` (default 1h).
        db_row = _load_metadata_key_row_from_db(connection_id, cache_id)
        if db_row and db_row.get("metadata_key"):
            db_key = db_row["metadata_key"]
            db_age = _db_row_age_seconds(db_row)
            max_age = _metadata_key_db_cache_max_age_seconds()
            # Smart-brain cross-pod trust (2026-06-23): the DB row's
            # ``updated_at`` is bumped by EVERY pod's successful
            # ``reconcile_table`` (via ``_cache_metadata_key`` ->
            # ``set_iceberg_metadata_key``).  So when any pod's
            # watcher recently reconciled this cache_id, the DB
            # row's age is small — even though THIS pod's in-memory
            # trust dict doesn't have the tick.  Treat that as
            # cross-pod trusted: warm the local cache + record a
            # local tick + short-circuit the verifier.  Multi-pod
            # fleets now share a hot brain via the existing DB
            # cache infrastructure -- no extra round-trips.
            try:
                from core.iceberg_metadata_sync import (
                    _cache_trust_window_seconds as _ctw,
                    record_watcher_tick as _rwt,
                )
                _trust_window = _ctw()
                # 2026-06-28 BUG-FIX: cross-pod trust used to bypass the
                # ``max_age <= 0`` operator escape hatch.  Setting
                # ``iceberg.metadata_key_db_cache_max_age_seconds=0`` is
                # the documented "I suspect DB-cache corruption -- skip
                # it" knob.  Cross-pod trust READS from the DB cache,
                # so it MUST honour the same gate.  Without this guard
                # operators couldn't force-fall-through to S3 because
                # cross-pod trust kept serving the DB row.
                # 2026-10-07 -- and the row must be inside the staleness
                # bound: its updated_at IS the moment some pod confirmed
                # it newest.  The local tick is back-dated to that moment
                # (it used to be stamped NOW, re-arming a fresh trust
                # window off a 299 s old observation).
                if (max_age > 0
                        and _trust_window > 0
                        and 0 <= db_age < _trust_window
                        and _may_serve_unconfirmed_age(db_age)):
                    with _metadata_key_cache_lock:
                        _bounded_metadata_key_cache_put(cache_id, {
                            "key": db_key, "ts": _time.time(),
                            "confirmed": _time.time() - db_age,
                        })
                    _rwt(cache_id, age_seconds=db_age)
                    _stamp_freshness(s3_client, _FRESHNESS_VERIFIED)
                    try:
                        from core.brain_trace import trace as _btrace
                        _btrace("cache_check", "trusted_cross_pod",
                                cache_id=cache_id, db_age_s=db_age)
                    except Exception as _be_exc:
                        note_best_effort("_btrace(...)", _be_exc,
                                         logger=logger)
                    logger.info(
                        "_latest_metadata_key: CROSS-POD TRUST hit "
                        "(db_age=%.0fs < trust_window=%ds) → %s "
                        "(another pod's watcher recently reconciled)",
                        db_age, _trust_window, db_key,
                    )
                    return db_key
            except Exception as _cpt_exc:
                # Trust shortcut unavailable; fall through to verify.
                logger.debug("Cross-pod trust check non-fatal: %s",
                             _cpt_exc)
            _verdict_db = _verify_or_trust_pointer(
                s3_client, bucket, meta_prefix, db_key, cache_id)

            if _verdict_db == _POINTER_ADVANCED:
                logger.info(
                    "_latest_metadata_key: DB HIT + pointer advanced "
                    "(db_age=%.0fs) — evicting DB row, re-resolving (BF-511)",
                    db_age,
                )
                _evict_metadata_key_from_db(connection_id, cache_id)
                _invalidate_result_cache_for_cache_id(cache_id)  # BF-550
                # Fall through to Layer 3.
            elif _verdict_db == _POINTER_VERIFIED_MATCH:
                logger.info(
                    "_latest_metadata_key: DB CACHE HIT (db_age=%.0fs, "
                    "verified) → %s (in-memory miss, background refresh "
                    "triggered)", db_age, db_key,
                )
                with _metadata_key_cache_lock:
                    _bounded_metadata_key_cache_put(
                        cache_id, {"key": db_key, "ts": _time.time(),
                                   "confirmed": _time.time()},
                    )
                _stamp_freshness(s3_client, _FRESHNESS_VERIFIED)  # BF-526
                _trigger_background_refresh(s3_client, bucket, meta_prefix, cache_id)
                return db_key
            else:
                # VERIFY_FAILED: V1 table OR transient outage OR operator
                # disabled verification.  Only safe to serve if the row
                # is younger than the hard max-age — beyond that we
                # cannot bound staleness, so fall through to Layer 3
                # which talks to S3 directly.
                # 2026-10-07 -- AND inside the staleness bound.  max_age
                # alone (3,600 s) let an unverified row answer for an hour
                # after a commit; "verify failed" is not "verified".
                if (max_age <= 0 or db_age > max_age
                        or not _may_serve_unconfirmed_age(db_age)):
                    logger.info(
                        "_latest_metadata_key: DB HIT REFUSED (db_age=%.0fs, "
                        "max_age=%ds, staleness bound=%.0fs, verify=failed) "
                        "— falling through to fresh resolve (BF-511)",
                        db_age, max_age, _staleness_bound_now(),
                    )
                    # Don't evict — Layer 3 will overwrite if it succeeds.
                else:
                    logger.info(
                        "_latest_metadata_key: DB CACHE HIT (db_age=%.0fs, "
                        "verify=failed, within max_age=%ds and the "
                        "staleness bound) → %s "
                        "(in-memory miss, background refresh triggered)",
                        db_age, max_age, db_key,
                    )
                    with _metadata_key_cache_lock:
                        _bounded_metadata_key_cache_put(
                            cache_id, {"key": db_key, "ts": _time.time(),
                                       "confirmed": _time.time() - db_age},
                        )
                    _stamp_freshness(s3_client, _FRESHNESS_CACHED_UNVERIFIED)  # BF-526
                    _trigger_background_refresh(s3_client, bucket, meta_prefix, cache_id)
                    return db_key

    # ── Layer 3: version-hint.text (Iceberg v2) ─────────────────────────
    hint_key = meta_prefix.rstrip("/") + "/version-hint.text"
    try:
        resp = s3_client.get_object(Bucket=bucket, Key=hint_key)
        hint_text = resp["Body"].read().decode("utf-8").strip()
        if hint_text:
            narrow_prefix = meta_prefix.rstrip("/") + f"/{hint_text}-"
            narrow_candidates = []
            paginator = s3_client.get_paginator("list_objects_v2")
            for page in _counted_pages(paginator.paginate(Bucket=bucket, Prefix=narrow_prefix)):
                for obj in page.get("Contents", []):
                    if obj["Key"].endswith(".metadata.json"):
                        narrow_candidates.append(obj)
            if narrow_candidates:
                best = max(narrow_candidates, key=lambda x: x["LastModified"])
                # 2026-07-15 STALE-SNAPSHOT GUARD (opt-in): a present-but-stale
                # version-hint.text pins us to an old snapshot.  Cross-check the
                # newest metadata.json by LastModified and prefer it if newer.
                # Fail-safe: any error keeps the hint result (never worse).
                if _should_cross_check_newest_metadata():
                    try:
                        _scan_best = _newest_metadata_json_by_scan(
                            s3_client, bucket, meta_prefix)
                        if (_scan_best is not None
                                and _scan_best["Key"] != best["Key"]
                                and _scan_best["LastModified"] > best["LastModified"]):
                            logger.warning(
                                "_latest_metadata_key: version-hint.text=%s → %s, "
                                "but a NEWER metadata file exists: %s (LastModified "
                                "%s > %s) — version-hint is STALE (catalog advanced "
                                "without bumping it). Using the newer file to avoid "
                                "serving a stale snapshot (audit stale-snapshot guard).",
                                hint_text, best["Key"], _scan_best["Key"],
                                _scan_best["LastModified"], best["LastModified"],
                            )
                            # Adaptive Freshness: hint lied → permanent cross-check.
                            _freshness_record_hint_lied(bucket, _table_prefix_from_meta_prefix(meta_prefix))
                            best = _scan_best
                    except Exception as _xchk:
                        logger.debug("newest-metadata cross-check failed "
                                     "(keeping version-hint result): %s", _xchk)
                logger.info("_latest_metadata_key: version-hint.text=%s → %s "
                            "(1 narrow LIST, no full scan)", hint_text, best["Key"])
                _cache_metadata_key(cache_id, best["Key"], connection_id=connection_id)
                _stamp_freshness(s3_client, _FRESHNESS_FRESH)  # BF-526
                # Smart-brain: Layer 3 is the SAME authoritative resolve
                # the watcher does (version-hint.text -> narrow LIST ->
                # latest .metadata.json).  Treat this success as a
                # watcher-equivalent tick so subsequent queries on cold-
                # pod-first-resolve don't pay for re-verification of
                # the work we just did.  Layer 4 (capped scan) is NOT
                # stamped — it may miss recent files if scan was capped,
                # so trusting it would risk serving stale pointers.
                try:
                    from core.iceberg_metadata_sync import record_watcher_tick
                    record_watcher_tick(cache_id)
                except Exception as _be_exc:
                    note_best_effort("record_watcher_tick(cache_id)", _be_exc,
                                     logger=logger)
                try:
                    from core.brain_trace import trace as _btrace
                    _btrace("cache_check", "fresh_resolve",
                            cache_id=cache_id,
                            via="version_hint", layer=3)
                except Exception as _be_exc:
                    note_best_effort("_btrace(...)", _be_exc,
                                     logger=logger)
                return best["Key"]
            logger.warning("_latest_metadata_key: version-hint.text=%s but no matching "
                           "file under %s — falling back to capped scan",
                           hint_text, narrow_prefix)
    except Exception as hint_exc:
        # 2026-10-07 -- one ``except Exception`` + a classifier instead of
        # ``except s3_client.exceptions.NoSuchKey``: that clause EVALUATES
        # the client attribute when anything is raised, and a client whose
        # ``exceptions`` is not a class registry (a wrapped / proxied
        # client) turned "no hint" into a TypeError that failed the query.
        if _is_no_such_key_error(hint_exc):
            logger.debug("_latest_metadata_key: no version-hint.text")
        else:
            logger.debug("_latest_metadata_key: version-hint.text read "
                         "failed: %s", hint_exc)

    # ── Layer 4: capped scan ─────────────────────────────────────────────
    # Phase 139 audit-fix Gap 9: read cap from config so admins can raise it.
    _max_pages = _metadata_scan_max_pages()
    logger.info("_latest_metadata_key: capped scan s3://%s/%s (max_pages=%d)",
                bucket, meta_prefix, _max_pages)
    best = None
    page_count = 0
    total_candidates = 0
    capped = False
    try:
        paginator = s3_client.get_paginator("list_objects_v2")
        for page in _counted_pages(paginator.paginate(Bucket=bucket, Prefix=meta_prefix)):
            page_count += 1
            for obj in page.get("Contents", []):
                if obj["Key"].endswith(".metadata.json"):
                    total_candidates += 1
                    if best is None or obj["LastModified"] > best["LastModified"]:
                        best = obj
            if page_count >= _max_pages:
                capped = True
                break
    except Exception as exc:
        # BF-282: same ExpiredToken propagation pattern as the background
        # refresher (BF-278) — invalidate the cached S3 handler + drop the
        # cached metadata key so the NEXT call re-resolves fresh STS creds
        # instead of looping forever on stale data.
        if _is_expired_token_error(exc):
            conn_id = _connection_id_from_s3_client(s3_client)
            if conn_id is not None:
                try:
                    from core.connection_manager import get_connection_manager
                    cm = get_connection_manager()
                    if cm:
                        cm.invalidate_s3_handler(int(conn_id),
                                                  reason="ExpiredToken in foreground capped scan")
                except Exception as _inv_exc:
                    logger.debug("S3 handler invalidation failed: %s", _inv_exc)
            try:
                with _metadata_key_cache_lock:
                    _metadata_key_cache.pop(cache_id, None)
            except Exception as _be_exc:
                note_best_effort("_metadata_key_cache.pop(cache_id, None)", _be_exc,
                                 logger=logger)
            logger.error(
                "Failed to list S3 metadata objects under s3://%s/%s — "
                "credentials EXPIRED (handler + cache invalidated)",
                bucket, meta_prefix,
            )
        else:
            logger.error("Failed to list S3 metadata objects under s3://%s/%s: %s",
                         bucket, meta_prefix, exc, exc_info=True)
        raise ValueError(
            f"Failed to list S3 objects under {meta_prefix}: {exc}"
        ) from exc

    if not best:
        logger.error("No Iceberg metadata JSON found under s3://%s/%s", bucket, meta_prefix)
        raise ValueError(f"No Iceberg metadata JSON found under {meta_prefix}")

    if capped:
        logger.warning(
            "ICEBERG SCAN CAPPED: s3://%s/%s scanned %d pages (%d candidates found so far). "
            "Scan stopped at cap=%d pages. Result may be stale if latest metadata is beyond "
            "this range. Either run 'expire_snapshots' to reduce metadata file count OR raise "
            "iceberg.metadata_scan_max_pages in config.json.",
            bucket, meta_prefix.rsplit("/metadata", 1)[0],
            page_count, total_candidates, _max_pages,
        )

    # ── High-count warning ───────────────────────────────────────────────
    try:
        from core.config import get as _cfg_get
        _warn_threshold = int(_cfg_get("iceberg", "metadata_count_warn_threshold",
                                       _METADATA_COUNT_WARN_THRESHOLD))
    except Exception:
        _warn_threshold = _METADATA_COUNT_WARN_THRESHOLD
    if total_candidates > _warn_threshold:
        logger.warning(
            "ICEBERG MAINTENANCE NEEDED: table s3://%s/%s has %d+ metadata files "
            "(threshold=%d). Run 'expire_snapshots' and 'remove_orphan_files' in "
            "Spark/Trino to prevent scan degradation.",
            bucket, meta_prefix.rsplit("/metadata", 1)[0],
            total_candidates, _warn_threshold,
        )

    logger.info("_latest_metadata_key: scanned %d pages, %d candidates%s → %s (modified %s)",
                page_count, total_candidates, " (CAPPED)" if capped else "",
                best["Key"], best.get("LastModified", "?"))
    _cache_metadata_key(cache_id, best["Key"], connection_id=connection_id)
    _stamp_freshness(s3_client, _FRESHNESS_FRESH)  # BF-526
    return best["Key"]


def _cache_metadata_key(cache_id: str, key: str,
                        connection_id: Optional[int] = None) -> None:
    """Store resolved metadata key in both the in-memory and DB caches.

    Phase 141 — DB persistence so a fresh process / first-query-per-table
    doesn't pay the cold capped-LIST scan cost.  DB write is best-effort:
    the in-memory cache always succeeds; a DB hiccup just means the next
    process restart will fall through to the slower path for this cache_id.

    BF-ICEBERG-CACHE-ANY-CONN: ``connection_id=None`` now writes a row
    under the sentinel value ``0``.  Previous behaviour: silently
    skipped the DB write entirely, which meant any code path that
    produced an untagged s3_client (admin tools, fallback builds)
    never populated the warm cache — even though that population
    would have helped EVERY subsequent reader.
    """
    _now = _time.time()
    with _metadata_key_cache_lock:
        _bounded_metadata_key_cache_put(
            cache_id, {"key": key, "ts": _now, "confirmed": _now},
        )

    try:
        from core.connection_manager import get_connection_manager
        cm = get_connection_manager()
        if cm and getattr(cm, "db", None):
            cm.db.set_iceberg_metadata_key(connection_id, cache_id, key)
    except Exception as exc:
        logger.debug("DB persistence of metadata_key failed (cache_id=%s): %s",
                     cache_id, exc)


def _signal_stage(stage: str, message: str = "", files_total: Optional[int] = None) -> None:
    """Helper: tell the per-execution stage tracker we entered ``stage``.

    Reads the execution_id from the BF-289 ContextVar set by the orchestrator
    (api/execute_api.py before calling get_iceberg_data_files via
    setup_registered_views).  No-op when no execution is in scope (admin
    tools, sync helpers).
    """
    try:
        from core.duckdb_views import _DL_EXEC_ID_CTX as _ctx
        execution_id = _ctx.get(None)
    except Exception:
        execution_id = None
    if not execution_id:
        return
    try:
        from core import execution_stage as _stg
        _stg.set_stage(execution_id, stage, files_total=files_total, message=message)
    except Exception as _be_exc:
        note_best_effort("_stg.set_stage(...)", _be_exc,
                         logger=logger)


def _load_metadata_key_row_from_db(connection_id: Optional[int],
                                     cache_id: str) -> Optional[Dict[str, Any]]:
    """Look up the persisted metadata-key row (key + updated_at) in DB cache.

    Returns the full row dict (``{metadata_key, updated_at, ...}``) or None.
    BF-511 (2026-05-28) — replaces the older ``_load_metadata_key_from_db``
    which returned the bare string.  Callers need ``updated_at`` to enforce
    the hard max-age check that bounds stale-DB-row blast radius.

    BF-ICEBERG-CACHE-ANY-CONN: ``connection_id=None`` falls back to a
    content-only ``cache_id`` lookup, returning the freshest row from any
    connection.
    """
    try:
        from core.connection_manager import get_connection_manager
        cm = get_connection_manager()
        if not (cm and getattr(cm, "db", None)):
            return None
        return cm.db.get_iceberg_metadata_key(connection_id, cache_id)
    except Exception as exc:
        logger.debug("DB read of metadata_key row failed (cache_id=%s): %s",
                     cache_id, exc)
        return None


def _load_metadata_key_from_db(connection_id: Optional[int],
                                cache_id: str) -> Optional[str]:
    """Bare-string variant of ``_load_metadata_key_row_from_db`` — kept for
    tests + any future caller that only needs the key.  Production hot
    path uses the row-returning variant so it can enforce max-age."""
    row = _load_metadata_key_row_from_db(connection_id, cache_id)
    return row.get("metadata_key") if row else None


def _db_row_age_seconds(row: Dict[str, Any]) -> float:
    """Compute age of a DB cache row in seconds, robust to missing /
    naive datetimes (treats them as UTC).  Returns ``float('inf')`` if
    ``updated_at`` is absent or unparseable — pushes the row past any
    finite max-age threshold so the caller refuses to serve it."""
    ts = row.get("updated_at") if row else None
    if ts is None:
        return float("inf")
    try:
        from datetime import datetime as _dt, timezone as _tz
        if isinstance(ts, str):
            try:
                ts = _dt.fromisoformat(ts.replace("Z", "+00:00"))
            except Exception:
                return float("inf")
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=_tz.utc)
        return (_dt.now(_tz.utc) - ts).total_seconds()
    except Exception:
        return float("inf")


def _trigger_background_refresh(s3_client, bucket: str, meta_prefix: str, cache_id: str) -> None:
    """Fire-and-forget background thread to refresh the metadata key cache.

    Only one refresh per cache_id runs at a time.  If a refresh is already
    running, this is a no-op.  Uses atomic check-and-set under lock to
    prevent duplicate concurrent refreshes.
    """
    # Atomic check-and-set — prevents two threads from both passing the check
    with _metadata_key_cache_lock:
        if _background_refresh_in_progress.get(cache_id):
            return  # already refreshing
        _background_refresh_in_progress[cache_id] = True

    # Phase 141: pull connection_id ONCE for the refresh thread so DB
    # persistence calls in _cache_metadata_key get the right key.
    _bg_conn_id = _connection_id_from_s3_client(s3_client)

    def _do_refresh():
        try:
            # Try version-hint first (cheapest)
            hint_key = meta_prefix.rstrip("/") + "/version-hint.text"
            try:
                resp = s3_client.get_object(Bucket=bucket, Key=hint_key)
                hint_text = resp["Body"].read().decode("utf-8").strip()
                if hint_text:
                    narrow_prefix = meta_prefix.rstrip("/") + f"/{hint_text}-"
                    narrow_candidates = []
                    paginator = s3_client.get_paginator("list_objects_v2")
                    for page in _counted_pages(paginator.paginate(Bucket=bucket, Prefix=narrow_prefix)):
                        for obj in page.get("Contents", []):
                            if obj["Key"].endswith(".metadata.json"):
                                narrow_candidates.append(obj)
                    if narrow_candidates:
                        best_hint = max(narrow_candidates, key=lambda x: x["LastModified"])
                        _cache_metadata_key(cache_id, best_hint["Key"], connection_id=_bg_conn_id)
                        logger.info("_latest_metadata_key: background refresh "
                                    "via version-hint → %s", best_hint["Key"])
                        return
            except Exception as _bg_hint_exc:
                logger.debug("_latest_metadata_key: background refresh "
                             "version-hint failed: %s", _bg_hint_exc)

            # Fallback: capped scan
            best = None
            page_count = 0
            paginator = s3_client.get_paginator("list_objects_v2")
            _bg_max_pages = _metadata_scan_max_pages()
            for page in _counted_pages(paginator.paginate(Bucket=bucket, Prefix=meta_prefix)):
                page_count += 1
                for obj in page.get("Contents", []):
                    if obj["Key"].endswith(".metadata.json"):
                        if best is None or obj["LastModified"] > best["LastModified"]:
                            best = obj
                if page_count >= _bg_max_pages:
                    break
            if best:
                _cache_metadata_key(cache_id, best["Key"], connection_id=_bg_conn_id)
                logger.info("_latest_metadata_key: background refresh "
                            "via capped scan (%d pages) → %s", page_count, best["Key"])
        except Exception as exc:
            # BF-278: when refresh fails with ExpiredToken, the cached
            # metadata key entry will be served stale forever (we keep
            # bumping age past TTL because every refresh keeps failing
            # on the SAME expired creds).  Two fixes:
            #   1. Invalidate the cached S3 client (next caller gets
            #      fresh STS creds).
            #   2. Drop the cached metadata key so the next foreground
            #      call falls through to the capped scan path with
            #      fresh creds, instead of returning stale data.
            if _is_expired_token_error(exc):
                logger.warning(
                    "_latest_metadata_key: background refresh failed with "
                    "EXPIRED CREDENTIALS — invalidating S3 handler + cached "
                    "metadata key (next call will re-resolve STS token): %s", exc,
                )
                conn_id = _connection_id_from_s3_client(s3_client)
                if conn_id is not None:
                    try:
                        from core.connection_manager import get_connection_manager
                        cm = get_connection_manager()
                        if cm:
                            cm.invalidate_s3_handler(int(conn_id),
                                                      reason="ExpiredToken in background refresh")
                    except Exception as _inv_exc:
                        logger.debug("S3 handler invalidation failed: %s", _inv_exc)
                # Drop the stale cached metadata key so the next read
                # doesn't serve 8x-past-TTL data.
                try:
                    with _metadata_key_cache_lock:
                        _metadata_key_cache.pop(cache_id, None)
                except Exception as _be_exc:
                    note_best_effort("_metadata_key_cache.pop(cache_id, None)", _be_exc,
                                     logger=logger)
            else:
                logger.warning("_latest_metadata_key: background refresh failed: %s", exc)
        finally:
            with _metadata_key_cache_lock:
                _background_refresh_in_progress.pop(cache_id, None)

    t = threading.Thread(target=_do_refresh, daemon=True, name=f"iceberg-meta-refresh-{cache_id[-30:]}")
    t.start()


def _batch_s3_metadata(
    s3_client, bucket: str, keys: List[str]
) -> Dict[str, Dict[str, Any]]:
    """Return {key: {size_bytes, last_modified}} for a list of S3 keys.

    Uses list_objects_v2 grouped by common prefix to minimise API calls instead
    of one head_object per file (which is O(N) round trips).
    """
    if not keys:
        return {}

    result: Dict[str, Dict[str, Any]] = {}

    # Group keys by their directory prefix (everything up to the last /)
    from collections import defaultdict
    prefix_map: Dict[str, List[str]] = defaultdict(list)
    for key in keys:
        slash = key.rfind("/")
        prefix = key[: slash + 1] if slash >= 0 else ""
        prefix_map[prefix].append(key)

    for prefix, prefix_keys in prefix_map.items():
        key_set = set(prefix_keys)
        try:
            paginator = s3_client.get_paginator("list_objects_v2")
            for page in _counted_pages(paginator.paginate(Bucket=bucket, Prefix=prefix)):
                for obj in page.get("Contents", []):
                    k = obj["Key"]
                    if k in key_set:
                        result[k] = {
                            "size_bytes":    obj["Size"],
                            "last_modified": obj["LastModified"].isoformat(),
                        }
        except Exception as exc:
            logger.warning("list_objects_v2 failed for prefix %s: %s", prefix, exc)
            # Fall back to individual HEAD for this batch
            for k in prefix_keys:
                try:
                    head = s3_client.head_object(Bucket=bucket, Key=k)
                    result[k] = {
                        "size_bytes":    head["ContentLength"],
                        "last_modified": head["LastModified"].isoformat(),
                    }
                except Exception:
                    result[k] = {"size_bytes": 0, "last_modified": ""}

    return result


def get_latest_partition_value(
    s3_client,
    bucket: str,
    table_prefix: str,
    *,
    metadata: Optional[dict] = None,
) -> Dict[str, str]:
    """Find the latest (max) partition value for date/timestamp partition columns.

    Efficiently reads only the manifest list (not individual manifests) to
    determine the max partition value from upper_bounds.

    Args:
        metadata: Pre-loaded Iceberg metadata dict.  When provided, skips
                  the S3 read for metadata.json (avoids duplicate fetches).

    Returns:
        {partition_column_name: latest_value_string}  e.g. {"business_date": "2024-03-15"}
    """
    if metadata is None:
        meta_prefix = table_prefix.rstrip("/") + "/metadata/"
        meta_key = _latest_metadata_key(s3_client, bucket, meta_prefix)
        metadata = _read_s3_json_cached(s3_client, bucket, meta_key)

    current_snapshot_id = metadata.get("current-snapshot-id", -1)
    if current_snapshot_id in (-1, None):
        return {}

    snapshots = {
        s.get("snapshot-id"): s
        for s in metadata.get("snapshots", [])
        if s.get("snapshot-id") is not None
    }
    snapshot = snapshots.get(current_snapshot_id)
    if not snapshot:
        return {}

    # Get partition spec
    partition_spec = _extract_partition_spec(metadata)
    if not partition_spec:
        return {}

    # Get ordered partition field names from active spec
    spec_fields = list(partition_spec.items())  # [(name, type), ...]

    # Build partition_field_name → source_column_name mapping so that returned keys
    # use source column names (needed for correct DuckDB SQL filter construction).
    _field_to_src: Dict[str, str] = {}
    _schemas = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
    _fid_to_name: Dict[int, str] = {}
    for _sch in _schemas:
        for _sf in _sch.get("fields", []):
            _fid = _sf.get("id") or _sf.get("field-id")
            if _fid is not None:
                _fid_to_name[_fid] = _sf.get("name", "")
    _specs = metadata.get("partition-specs") or (
        [metadata["partition-spec"]] if "partition-spec" in metadata else []
    )
    _def_spec_id = metadata.get("default-spec-id", 0)
    _active_spec = next(
        (s for s in _specs if s.get("spec-id") == _def_spec_id), _specs[0] if _specs else {}
    )
    for _pf in _active_spec.get("fields", []):
        _fname = _pf.get("name", "")
        _src_id = _pf.get("source-id") or _pf.get("source_id")
        _src_name = _fid_to_name.get(_src_id, "")
        if _fname and _src_name:
            _field_to_src[_fname] = _src_name

    # Auto-filter date/timestamp columns (identity or day/month/year/hour transforms)
    _DATE_TYPES = {"date", "timestamp", "timestamptz", "timestamp_tz",
                   "timestamp with local time zone",
                   "_transform_day", "_transform_month", "_transform_year", "_transform_hour"}
    date_indices: List[Tuple[int, str, str]] = []  # (index, name, type)
    for i, (name, ptype) in enumerate(spec_fields):
        if ptype.lower() in _DATE_TYPES:
            date_indices.append((i, name, ptype))

    if not date_indices:
        return {}

    # Read manifest list
    manifest_list_uri = snapshot.get("manifest-list")
    if not manifest_list_uri:
        return {}

    ml_key = _s3_uri_to_key(manifest_list_uri)
    try:
        manifest_list_data = _read_manifest_list_avro_cached(s3_client, bucket, ml_key)
        manifests = _read_avro(manifest_list_data)
    except Exception:
        return {}

    # Scan manifest entries for max partition upper bounds
    max_values: Dict[str, str] = {}
    for manifest in manifests:
        # Only look at data manifests, not delete manifests
        content = manifest.get("content", 0)
        if content != 0:
            continue
        partitions = manifest.get("partitions") or []
        for idx, name, ptype in date_indices:
            if idx >= len(partitions):
                continue
            p_summary = partitions[idx]
            upper = p_summary.get("upper_bound")
            if upper is None:
                continue
            decoded = _decode_bound(upper, ptype)
            if decoded is None:
                continue
            decoded_str = str(decoded)
            # For timestamps, take only the date portion for partition comparison
            if ptype.lower() != "date" and "T" in decoded_str:
                decoded_str = decoded_str[:10]
            if name not in max_values or decoded_str > max_values[name]:
                max_values[name] = decoded_str

    if max_values:
        logger.info("Latest partition values for %s: %s", table_prefix, max_values)

    # Return keyed by SOURCE column name so callers can use values directly in SQL filters.
    # For identity transforms field_name == source_name; for day/month transforms they may differ.
    return {_field_to_src.get(k, k): v for k, v in max_values.items()}


def get_iceberg_snapshot_id_only(s3_client, bucket: str, table_prefix: str) -> Optional[int]:
    """Read ONLY current-snapshot-id from metadata.json (~1-5KB, 2 S3 calls).

    Used by the snapshot fingerprint service to check if a table has changed
    without loading the full manifest chain. Returns None if the table has no
    current snapshot or metadata cannot be read.
    """
    try:
        meta_prefix = table_prefix.rstrip("/") + "/metadata/"
        meta_key = _latest_metadata_key(s3_client, bucket, meta_prefix)
        metadata = _read_s3_json_cached(s3_client, bucket, meta_key)
        snap_id = metadata.get("current-snapshot-id", None)
        if snap_id in (-1, None):
            return None
        return int(snap_id)
    except Exception as exc:
        logger.debug("get_iceberg_snapshot_id_only failed for %s: %s", table_prefix, exc)
        return None


def find_snapshot_at_timestamp(metadata: dict, timestamp_ms: int) -> Optional[int]:
    """Phase 139 audit-fix Gap 6 — pick the latest snapshot at or before a timestamp.

    Iceberg metadata.json has a ``snapshot-log`` list of ``{timestamp-ms, snapshot-id}``
    entries describing the order snapshots became current. Returns the snapshot-id
    that was current at ``timestamp_ms``. Returns None when the list is empty or
    the requested time predates the table's first snapshot.
    """
    log = metadata.get("snapshot-log") or []
    chosen = None
    for entry in log:
        ts = entry.get("timestamp-ms")
        sid = entry.get("snapshot-id")
        if ts is None or sid is None:
            continue
        if int(ts) <= int(timestamp_ms):
            chosen = sid
        else:
            break  # log is chronological — no later entries can match
    return chosen


def _try_materialized_island_route(
    *,
    db_manager,
    bucket: str,
    table_prefix: str,
    snapshot_id,
    source_files: List[Dict[str, Any]],
    _out_meta: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """Phase 8 — materialized-island routing swap.

    Called from every ``get_iceberg_data_files`` return path, immediately
    before the Phase-150 whole-table ``_try_mirror_route`` (see
    ``_apply_read_substitutions`` below) -- this is MORE specific (keyed
    to the EXACT post-prune file set via a SHA-256 fingerprint, not just
    the table+snapshot), so it is tried first and, on a hit, skips the
    broader Phase-150 check entirely.

    FILE-LIST SWAP ONLY.  Every downstream step (WHERE, RLS enforcement,
    MoR, joins) runs unchanged over whichever list comes back -- RLS is
    neutral by construction (same logical rows, different physical
    files).  Fail-CLOSED at every edge (see
    ``core.materialized_islands`` module docstring for the full branch
    list): any doubt returns ``source_files`` UNCHANGED (same object —
    callers may rely on ``is`` identity to detect a swap).
    """
    if not source_files or db_manager is None:
        return source_files
    try:
        from core.materialized_islands import route_files_for_island
        files, decision = route_files_for_island(
            db_manager, bucket=bucket, table_prefix=table_prefix,
            snapshot_id=snapshot_id, source_files=source_files,
        )
        if _out_meta is not None:
            _out_meta["materialized_island_decision"] = decision
        return files
    except Exception as exc:
        logger.debug("[materialized_islands] _try_materialized_island_route "
                     "fail-open: %s", exc)
        return source_files


def _apply_read_substitutions(
    *,
    db_manager,
    metadata,
    bucket: str,
    table_prefix: str,
    snapshot_id,
    source_files: List[Dict[str, Any]],
    _out_meta: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """THE reader file-list substitution chokepoint (Phase 8 + Phase 150).

    Tries the Phase 8 materialized-island route FIRST (exact fingerprint
    match against the post-prune island — the correctness-critical,
    fail-closed swap) and, ONLY when it did not route, falls back to the
    broader Phase 150 whole-table mirror route.  Skipping Phase 150 after
    a Phase 8 hit avoids re-evaluating (and potentially overriding) an
    already-optimal, already-proven file list with a coarser one.

    Both legs are individually flag-gated and fail-open to the incoming
    list; this wrapper adds no new failure mode of its own.
    """
    routed_files = _try_materialized_island_route(
        db_manager=db_manager, bucket=bucket, table_prefix=table_prefix,
        snapshot_id=snapshot_id, source_files=source_files, _out_meta=_out_meta,
    )
    if routed_files is not source_files:
        _mark_read_plan_substituted(_out_meta, "island")
        return routed_files
    out = _try_mirror_route(
        db_manager=db_manager, metadata=metadata, bucket=bucket,
        table_prefix=table_prefix, snapshot_id=snapshot_id,
        source_files=source_files, _out_meta=_out_meta,
    )
    if out is not source_files:
        _mark_read_plan_substituted(_out_meta, "mirror")
    return out


def _mark_read_plan_substituted(_out_meta, reason: str = "") -> None:
    """2026-09-25 -- a substituted list (mirror / materialized island) is not
    the manifest's data files: the per-file presence the read plan carries
    no longer describes what DuckDB reads, so the planner must keep the
    hive-path read.  Fail-open: unmarkable ⇒ the plan is absent ⇒ hive path.

    2026-10-08 -- ``reason`` (``island`` / ``mirror``) is stamped as
    ``_out_meta["read_substitution"]`` so the one recording point writes
    the row's ``read_reason`` beside ``files_read`` (the substituted
    list's length) while ``files_after_prune`` keeps the pruner's count."""
    try:
        if isinstance(_out_meta, dict):
            if reason:
                _out_meta["read_substitution"] = str(reason)
            if isinstance(_out_meta.get("iceberg_read_plan"), dict):
                _out_meta["iceberg_read_plan"]["files_substituted"] = True
    except Exception:
        pass


def _try_mirror_route(
    *,
    db_manager,
    metadata,
    bucket: str,
    table_prefix: str,
    snapshot_id,
    source_files: List[Dict[str, Any]],
    _out_meta: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """Phase 150 — mirror-routing swap.

    Called from every ``get_iceberg_data_files`` return path.  Asks the
    IcebergMirrorEngine whether the post-prune source file list should
    be replaced with the consolidated mirror files for the same snapshot.

    Fail-OPEN at every edge: any exception / kill-switch / row-mismatch
    keeps the caller on source files.  Decision payload is stashed in
    ``_out_meta["mirror_decision"]`` so the diagnose UI can render
    'mirror routed' vs 'source used because <reason>'.
    """
    if not source_files or db_manager is None:
        return source_files
    try:
        from core.iceberg_mirror import (
            route_files_for_query, IcebergMirrorEngine,
        )
        try:
            schema_hash = IcebergMirrorEngine._schema_hash(metadata or {})
        except Exception:
            schema_hash = ""
        decision = route_files_for_query(
            db_manager,
            bucket=bucket,
            prefix=table_prefix,
            snapshot_id=snapshot_id,
            source_schema_hash=schema_hash,
            source_file_count=len(source_files),
            source_files=source_files,
        )
        if _out_meta is not None:
            try:
                _out_meta["mirror_decision"] = decision.to_dict()
            except Exception as _be_exc:
                note_best_effort("decision.to_dict()", _be_exc,
                                 logger=logger)
        if decision.routed and decision.mirror_files:
            logger.info(
                "[mirror] routed %d source files -> %d mirror files "
                "for %s/%s snap=%s",
                len(source_files), len(decision.mirror_files),
                bucket, table_prefix, snapshot_id,
            )
            return decision.mirror_files
        return source_files
    except Exception as exc:
        logger.debug("[mirror] _try_mirror_route fail-open: %s", exc)
        return source_files


def _phase156_memo_populate(
    *,
    sql_hash: Optional[str],
    snapshot_id: Any,
    bucket: str,
    table_prefix: str,
    surviving_files: List[Dict[str, Any]],
    db_manager: Any,
    join_key_columns: Optional[List[str]] = None,
    force_fresh: bool = False,
    gate: Any = None,
    scan_meta: Optional[Dict[str, Any]] = None,
) -> None:
    """Phase 156 (2026-06-25) -- module-level memo populate.

    Single chokepoint: every return path in get_iceberg_data_files
    calls this after computing the surviving file list.  Refusing
    rules (single source of truth):
      * sql_hash missing  -> caller didn't opt in
      * force_fresh       -> caller wanted a re-prune
      * db_manager missing-> nowhere to persist
      * join_key_columns WITHOUT a scan_meta carrying join_key_bounds
        -> JoinPruner needs bounds a bare record cannot replay.  Since
        2026-08-22 (F4) the walk path passes scan_meta with the computed
        bounds, so join queries ARE memoised when the bounds were
        actually computed; the refusal now only fires for producers that
        did not compute them (pyiceberg path, hit_limit-less callers).
      * snapshot_id falsy -> can't key the entry
      * bucket / prefix missing
      * surviving_files empty (2026-08-03) -> a 0-file verdict is the
        single most dangerous thing to replay from cache: if it was
        WRONG (any pruning bug), every later identical query silently
        returns zero rows for the memo TTL.  Recomputing an empty
        prune is cheap; do not memoise it.
      * gate counted UNJUSTIFIED drops (2026-08-03) -> the pruning
        gate could not justify at least one drop in this very scan;
        memoising its output would launder an unverified file list
        past the gate on every replay.
    Fail-OPEN: any error logs at debug and never raises.

    Module-level (NOT nested in get_iceberg_data_files) so:
      * No closure-scope hazards on early-return paths (pyiceberg
        + L2 DB-first paths were returning BEFORE the nested helper
        was even defined).
      * Independently unit-testable.
    """
    if not sql_hash or force_fresh or db_manager is None:
        return
    if join_key_columns and not (
            isinstance(scan_meta, dict) and "join_key_bounds" in scan_meta):
        # A replay for a join query MUST reproduce the bounds the
        # JoinPruner would have received — a record without them would
        # silently un-prune (safe) or, worse, be trusted as if bounds had
        # been computed.  No proof of computation => no memo.
        return
    if not snapshot_id or not bucket or not table_prefix:
        return
    if not surviving_files:
        logger.debug(
            "[brain-memo] refusing to memoise an EMPTY surviving-file list "
            "for %s/%s snap=%s (0-file verdicts are recomputed, never "
            "replayed).", bucket, table_prefix, snapshot_id)
        return
    try:
        if gate is not None and int(getattr(gate, "unjustified_count", 0)) > 0:
            logger.warning(
                "[brain-memo] refusing to memoise for %s/%s snap=%s: the "
                "pruning gate counted %d UNJUSTIFIED drop(s) in this scan — "
                "replaying this file list would bypass the gate.",
                bucket, table_prefix, snapshot_id,
                int(gate.unjustified_count))
            return
    except Exception as _gate_exc:
        logger.debug("[brain-memo] gate consult failed (refusing to "
                     "memoise, fail-safe): %s", _gate_exc)
        return
    try:
        from core.brain_pruning_memo import put_memo as _bm_put
        _bm_put(
            sql_hash=sql_hash,
            snapshot_id=str(snapshot_id),
            bucket=bucket, table_prefix=table_prefix,
            surviving_files=surviving_files,
            surviving_count=len(surviving_files),
            pruning_breakdown=None,
            scan_meta=scan_meta,
            db_manager=db_manager,
        )
    except Exception as exc:
        logger.debug(
            "[brain-memo] populate failed (fail-open): %s", exc,
        )


def _memo_scan_meta_from_out(_out_meta: Any) -> Optional[Dict[str, Any]]:
    """F4 (2026-08-22) — collect from ``_out_meta`` exactly what a memo
    REPLAY must reproduce beyond the survivor list:

      * ``join_key_bounds`` / ``join_key_distinct_values`` — what the
        JoinPruner consumes.  Presence (even ``{}``) means "the
        aggregation RAN"; absence means it did not, and the populate
        refusal keeps such scans un-memoised for join queries.
      * ``file_enumeration_complete`` — the completeness attestation the
        runtime IN-list push requires; replaying without it is
        safe-but-degraded, replaying a WRONG one would be row loss, so
        it is copied exactly and only when present.
      * ``pos_delete_files`` / ``eq_delete_files`` — the MoR delete view
        inputs; the consult side refuses delete-bearing snapshots unless
        both are present.  (``data_seq_by_path`` is deliberately NOT
        carried: cache-served walks lack it too, and its absence degrades
        eq-delete sequence scoping to global apply — the over-delete-
        direction historical baseline, never an overcount.)
    """
    if not isinstance(_out_meta, dict):
        return None
    sm: Dict[str, Any] = {}
    for k in ("join_key_bounds", "join_key_distinct_values",
              "pos_delete_files", "eq_delete_files"):
        if k in _out_meta:
            sm[k] = _out_meta[k]
    if "file_enumeration_complete" in _out_meta:
        sm["file_enumeration_complete"] = bool(
            _out_meta["file_enumeration_complete"])
    return sm or None


def _num_or_none(x):
    """Parse ``x`` as int (exact for int64) then float; None if non-numeric."""
    try:
        return int(x)
    except (ValueError, TypeError):
        try:
            return float(x)
        except (ValueError, TypeError):
            return None


def _partition_date_eq(_d: str, _f: str, _ct: str) -> bool:
    """BF-498 date-vs-timestamp EQUALITY widening — the funnel's identity-eq
    arm (hoisted 2026-08-23 from the per-file loop, body unchanged).

    True when the two spellings are equal outright, or when the column is
    date/timestamp-flavoured and both sides share the same YYYY-MM-DD
    prefix (a bare-date filter deliberately matches every sub-day
    timestamp partition value on that date).  INCLUSION-ONLY: callers use
    it to PREVENT a skip, never to cause one."""
    if _d is None or _f is None:
        return False
    if _d == _f:
        return True
    _ctl = (_ct or "").lower()
    _is_ts = (_ctl in ("timestamp", "timestamptz",
                        "timestamp_tz",
                        "timestamp with local time zone")
              or _ctl.startswith("_transform_hour"))
    _is_date = (_ctl in ("date",)
                or _ctl.startswith("_transform_day"))
    # 2026-09-28 (P0, found live) -- INTERVAL bridge for EVERY declared
    # temporal partition type.  The prefix compare below knows day / hour /
    # timestamp / date; a ``month(dt)`` partition decodes to ``1995-06`` and
    # the literal is ``1995-06-15``: no prefix match, no numeric match, no
    # string match -> skip_file for EVERY file -> 0 rows, status completed
    # (Trino: 616).  ``year(dt)`` identically.  A partition value COVERS its
    # period and a bare-date literal denotes its whole day (BF-498/509), so
    # the question is interval OVERLAP; undecidable on a temporal column
    # (an unparseable literal) is KEEP, never a drop -- "cannot read it" is
    # not "no rows".  Widening-only, like every other arm of this helper.
    if _is_temporal_declared_type(_ctl):
        _ov = _temporal_point_overlap(_d, _f, _ctl)
        if _ov is not False:
            return True
    # Only normalise when at least one side is date/ts
    if not (_is_ts or _is_date):
        return False
    # Compare date prefix (10 chars: YYYY-MM-DD)
    import re as _re_de
    _date_re = _re_de.compile(r"^\d{4}-\d{2}-\d{2}")
    _dm = _date_re.match(_d)
    _fm = _date_re.match(_f)
    if _dm and _fm:
        return _dm.group(0) == _fm.group(0)
    return False


def _partition_value_numeric_match(decoded_str, candidates) -> bool:
    """2026-07-14 DATA-LOSS FIX — fail-OPEN numeric reconciliation for
    partition-value INCLUSION matching (identity transform).

    The identity partition matcher compares partition values as exact strings.
    Two tables in a JOIN can spell the SAME numeric partition value differently
    — "5" vs "05", "100" vs "100.0", decimal scale drift — so a synthetic
    join-key IN/= filter built from ONE table's spelling would byte-mismatch
    the OTHER table's partition value and drop every matching file → 0 rows
    (the residual variant of the join-prune data-loss found in the 2026-07-14
    deep-dive).

    Returns True iff ``decoded_str`` equals ANY candidate under Decimal
    canonicalization.  PURELY ADDITIVE: callers use it ONLY to PREVENT a skip
    on an INCLUSION filter (IN / =), never to cause one, so it can only reduce
    over-pruning — it can NEVER drop a matching file.  Non-numeric values don't
    match here, so the caller's exact-string result stands for string keys
    (where "5" and "05" are genuinely different codes).
    """
    from decimal import Decimal, InvalidOperation
    try:
        _d = Decimal(str(decoded_str))
    except (InvalidOperation, ValueError, TypeError):
        return False
    for _c in candidates:
        try:
            if Decimal(str(_c)) == _d:
                return True
        except (InvalidOperation, ValueError, TypeError):
            continue
    return False


def _partition_value_string_match(decoded_str, candidates) -> bool:
    """2026-07-14 DATA-LOSS FIX (deep-dive round 2) — fail-OPEN STRING
    reconciliation for partition-value INCLUSION matching.

    A synthetic join-key ``IN`` list is built from the ANCHOR table's spelling
    of a key and applied to the TARGET table's partition value.  For a
    NON-numeric string key the two tables can spell the same logical value with
    trivial drift — CASE (``TRADE`` vs ``Trade``) or surrounding WHITESPACE
    (`` TRADE `` vs ``TRADE``) — which the numeric reconciliation can't bridge,
    so exact-string membership drops EVERY target file → 0 rows.

    Returns True iff ``decoded_str`` equals ANY candidate after normalization.
    INCLUSION-only (IN / =): callers use it ONLY to PREVENT a skip, so it can
    only reduce over-pruning — never drop a matching file.  Over-keeping is
    safe: DuckDB re-applies the real join equality at read time.

    2026-07-14 deep-dive round 5 — broadened beyond casefold to close the
    silent PARTIAL-loss vectors the 0-file safety net can't catch:
      * UNICODE FORM: NFKC-normalize before folding, so NFC "Zürich" (U+00FC)
        matches NFD "Zürich", and full-width "ＡＢＣ" matches "ABC".
      * INTERNAL WHITESPACE: collapse ALL whitespace runs, so "NEW  YORK"
        (two spaces / tab / NBSP) matches "NEW YORK".
      * DATE-FORM (ungated): if both sides start with a YYYY-MM-DD prefix,
        match on that prefix — bridges a string-typed date target vs a
        timestamp anchor ("2025-09-30" vs "2025-09-30 00:00:00") regardless of
        the target column's declared type (the type-gated date-prefix in the
        matcher above doesn't fire for string-typed columns).
    All still inclusion-only → over-keep-safe.
    """
    if not isinstance(decoded_str, str):
        return False
    import unicodedata as _ud
    import re as _re_pvs

    def _norm(s: str) -> str:
        # NFKC + casefold + '+'-as-space (some hive writers URL-encode a
        # space as '+' in path segments; unquote() leaves '+' untouched, so
        # 'US+East' must still match 'US East' — 2026-08-03, inclusion-only)
        # + collapse every whitespace run to one space.
        return " ".join(
            _ud.normalize("NFKC", s).casefold().replace("+", " ").split())

    _d = _norm(decoded_str)
    if not _d:
        return False
    _date_re = _re_pvs.compile(r"^\d{4}-\d{2}-\d{2}")
    _d_date = _date_re.match(decoded_str.strip())
    for _c in candidates:
        if not isinstance(_c, str):
            continue
        if _norm(_c) == _d:
            return True
        if _d_date:
            _c_date = _date_re.match(_c.strip())
            if _c_date and _c_date.group(0) == _d_date.group(0):
                return True
    # 2026-07-31 -- TEMPORAL SPELLING bridge (4th arm).
    #
    # The date-prefix arm above requires BOTH sides to be ^YYYY-MM-DD, so it
    # cannot bridge an ISO-decoded partition value against a month-name literal
    # ('2025-09-30' vs '30 sep 2025').  Without this, the identity-partition
    # and hive-island matchers conclude "provably a different partition value"
    # and prune EVERY file INCLUDING THE MATCHING ONE -- the `0 rows vs 42M`
    # class.  (Executed: decoded '2025-09-30' vs '30 sep 2025' -> skip_file.)
    #
    # This is the BOTH-SIDES reconciliation, deliberately replacing the
    # literal-rewrite approach that was reverted in 7284185b: rewriting the
    # user's value REPLACED the lexicographic reading and broke genuine-VARCHAR
    # date-like columns; reconciling here only ADDS a keep path.
    #
    # Safe by call-site shape, not by argument: all three callers have the form
    # ``if not _partition_value_string_match(...): skip_file = True`` (see
    # :4985, :8083, :8162), so a new True can only PREVENT a skip.  The
    # exclusion ops NOT-IN (:8106) and != (:8174) use exact equality and never
    # reach this function -- untouched by construction.
    try:
        from core.predicate_coerce import (
            temporal_eq_keep as _teq,
            temporal_keep_undecidable as _tku,
        )
    except Exception:                                        # pragma: no cover
        return False
    for _c in candidates:
        if isinstance(_c, str) and _teq(decoded_str, _c):
            return True
    # 2026-07-31 -- UNDECIDABLE => KEEP (5th arm).
    #
    # An AMBIGUOUS literal ('01/02/2025' = Jan-2 or Feb-1 by locale) is
    # deliberately never parsed, because guessing would prune the WRONG files.
    # But an unreadable literal matches no spelling, so it pruned EVERY file --
    # silent data loss whenever a file really does hold that date.  Keep
    # instead, and only when the DECODED partition value is itself temporal so
    # genuine string columns keep their prunable semantics.
    for _c in candidates:
        if isinstance(_c, str) and _tku(decoded_str, _c):
            return True
    return False


def _hive_island_constraints(
    partition_filters: Optional[List[Dict[str, Any]]],
    engaged_cols: Optional[set],
    table_name: Optional[str],
) -> Optional[List[tuple]]:
    """2026-07-23 ISLAND HEAL — build hive-path island constraints for the
    partition-filter columns that SPEC-BASED partition pruning could NOT
    engage (ocean ⋈ island == ocean fix).

    ROOT CAUSE this heals: a partitioned table whose ``metadata.json`` partition
    spec can't be resolved (heavy schema evolution / field-id→name drift — the
    F1 guard in :func:`_extract_partition_spec` deliberately drops unresolvable
    identity fields, or the spec parse fails outright) keeps EVERY manifest and
    EVERY data file for a WHERE predicate on its partition column — the
    per-table leg of a raw-SQL JOIN then pays full-ocean cost (~2000 files)
    even though the filter was correctly extracted AND routed to this table.
    The partition value is ALSO in each data file's hive path (``col=value/``)
    — the same spec-evolution-proof source the 5-tier resolver's HIVE-PATH tier
    and the PARTITION-PRUNING CONTROL already trust — so the per-file walk can
    prune on that, at the PARTITION stage of the funnel (before col-stats /
    supplement / bloom, which then only see ISLAND survivors).

    Returns ``[(col_lower, [allowed str values])]`` or ``None`` when nothing
    can engage (no filters / all filter cols already spec-engaged / only
    non-inclusion ops / only foreign-qualified filters).

    SCOPE SAFETY (mirrors the B3 guard / _compute_table_filters): a filter
    qualified to a table (``table`` key or ``tbl.col`` prefix) is used ONLY
    when it matches ``table_name`` (full or bare last segment).  When
    ``table_name`` is unknown, qualified filters are SKIPPED entirely — an
    unscoped foreign predicate must never prune this table.

    OP SAFETY: only inclusion ops (``equals`` / ``in``) participate — the
    island is a set of allowed partition values; range/negation ops fall open.
    Columns already engaged by ``_resolved_pf`` are excluded (never
    double-handle a col the spec path is already pruning).
    """
    if not partition_filters:
        return None
    _engaged = {str(c).lower() for c in (engaged_cols or set())}

    _tn_ok = None
    if table_name:
        _tn_full = str(table_name).lower()
        _tn_ok = {_tn_full, _tn_full.rsplit(".", 1)[-1]}

    constraints: List[tuple] = []          # [(col_lower, [allowed str values])]
    for _f in partition_filters:
        if not isinstance(_f, dict):
            continue
        col = (_f.get("col") or _f.get("column") or "")
        op = (_f.get("op") or _f.get("operator") or "").strip().lower()
        val = _f.get("val") if "val" in _f else _f.get("value")
        col_bare = str(col).split(".")[-1].strip().lower()
        if not col_bare or col_bare in _engaged:
            continue
        # scope guard — qualified filters must match THIS table
        _qual = _f.get("table")
        if _qual:
            if _tn_ok is None or str(_qual).lower() not in _tn_ok:
                continue
        elif "." in str(col):
            if _tn_ok is None or str(col).rsplit(".", 1)[0].lower() not in _tn_ok:
                continue
        if op in ("equals", "eq", "=", "=="):
            if val is None or isinstance(val, (list, tuple, set, dict)):
                continue
            constraints.append((col_bare, [_strip_partition_cast(str(val))]))
        elif op == "in" and isinstance(val, (list, tuple)) and val:
            _vals = [_strip_partition_cast(str(v)) for v in val if v is not None]
            if _vals:
                constraints.append((col_bare, _vals))
    return constraints or None


def _hive_island_file_parts(file_path: str) -> Dict[str, str]:
    """Lower-cased ``{hive_col: value}`` from a data-file path.  Empty dict on
    any error (fail-open — caller keeps the file)."""
    try:
        from core.s3_utilities import extract_hive_parts as _ehp
        return {str(pk).lower(): pv for pk, pv in _ehp(str(file_path)).items()}
    except Exception:
        return {}


def _hive_island_file_prunes(
    parts_lower: Dict[str, str],
    constraints: List[tuple],
) -> bool:
    """True iff a file's hive path segments PROVE it lies outside the island.

    PRUNE SAFETY (fail-open at every grain — can never drop a JOIN match):
      * A file whose path lacks the segment for a column is KEPT.
      * Value match is exact-string OR numeric-reconciled
        (:func:`_partition_value_numeric_match`) OR string-normalised
        (:func:`_partition_value_string_match`) — both reconciliations are
        inclusion-only (keep-side), so spelling drift ("05" vs "5",
        "2025-09-30" vs "2025-09-30 00:00:00") can only REDUCE pruning.
      * A file is pruned ONLY when its hive segment PROVES a different
        partition value — the hive invariant (segment value == column value
        for every row in the file) that the parquet path, the island pushdown
        and the partition control already rely on.
      * Filters mirrored across a JOIN arrive here only via the extractor's
        equi-join propagation (``_propagate_join_filters`` gates on proven
        ``a.col = b.col`` equalities over partition columns), so a pruned file
        provably contains no joinable row for the anchored partition value.
      * Any internal error → False (keep).
    """
    try:
        if not parts_lower or not constraints:
            return False
        for _col, _vals in constraints:
            _fv = parts_lower.get(_col)
            if _fv is None:
                continue                  # segment absent → can't prove → keep
            _sfv = str(_fv)
            # 2026-08-02 — Hive's NULL / unrepresentable-value sentinel is
            # NOT a literal partition value: it means the writer could not
            # (or did not) encode the value in the path.  That is "no
            # information", not "provably different" — treating it as a
            # mismatch pruned the file (silent data loss when such a file
            # holds rows the predicate matches).  Empty segment values are
            # the same class.  KEEP (fail-open).
            if not _sfv or _sfv.upper() == "__HIVE_DEFAULT_PARTITION__":
                continue
            if _sfv in _vals:
                continue
            if _partition_value_numeric_match(_sfv, _vals):
                continue
            if _partition_value_string_match(_sfv, _vals):
                continue
            return True                   # provably a different partition value
        return False
    except Exception:
        return False


def _island_scope_file_keys(
    all_entries: Optional[List[List[dict]]],
    partition_filters: Optional[List[Dict[str, Any]]],
    table_name: Optional[str],
    *,
    max_paths: int = 2000,
) -> Optional[List[str]]:
    """2026-08-03 — ISLAND-SCOPED METADATA LOADS (perf-only, evidence-only).

    The supplement / bloom DB loads previously fetched rows for EVERY file
    of the snapshot (14k+ rows of per-file JSONB on the operator's table)
    even though only the handful of partition-island survivors ever consult
    them.  This helper derives, from the manifest entries ALREADY in memory
    (zero extra S3 I/O), the hive-path island's file keys so those DB
    fetches scale with the ISLAND.

    STRICTLY CANNOT CAUSE DATA LOSS: the scoped set only controls which
    files get supplement/bloom EVIDENCE.  A file excluded here simply has
    no bounds/bloom rows loaded → every downstream layer fails open → the
    file is KEPT.  Exclusion uses the SAME keep-side-reconciled matcher as
    the funnel's hive island stage (``_hive_island_file_prunes`` — exact
    string OR numeric-drift OR normalised-string match keeps a file in
    scope), and only inclusion ops (equals / IN) participate.

    Returns None (= load everything, today's behaviour) when: no usable
    eq/in partition constraints, OR-groups present, nothing actually
    narrowed (non-hive layout ⇒ every file stays in scope), or the island
    exceeds ``max_paths`` (an IN-list of that size is a worse DB shape
    than the unscoped fetch — this changes FETCH STRATEGY only, never
    which files can be pruned)."""
    try:
        if not all_entries or not partition_filters:
            return None
        if any(isinstance(pf, dict) and (pf.get("op") == "or" or "or" in pf)
               for pf in partition_filters):
            return None
        constraints = _hive_island_constraints(
            partition_filters, set(), table_name)
        if not constraints:
            return None
        # Cheap layout probe — if none of the first files carry a hive
        # segment for ANY constraint column, the table isn't hive-pathed
        # for these columns and the full pass can never narrow: return
        # None immediately (= full fetch, exactly today's behaviour) so a
        # 14k-entry non-hive table doesn't pay the whole derivation walk.
        _probe_seen = 0
        _probe_hit = False
        _c_cols = {c for c, _ in constraints}
        for entries in all_entries:
            for entry in entries or []:
                if _probe_seen >= 32 or _probe_hit:
                    break
                if not isinstance(entry, dict):
                    continue
                _p_df = entry.get("data_file") or {}
                _p_fp = (_p_df.get("file_path") or _p_df.get("path", "")
                         if isinstance(_p_df, dict) else "")
                if not _p_fp:
                    continue
                _probe_seen += 1
                if _c_cols & set(_hive_island_file_parts(str(_p_fp))):
                    _probe_hit = True
            if _probe_seen >= 32 or _probe_hit:
                break
        if _probe_seen and not _probe_hit:
            return None
        keys: List[str] = []
        seen: set = set()
        narrowed = False
        for entries in all_entries:
            for entry in entries or []:
                if not isinstance(entry, dict) or entry.get("status") == 2:
                    continue
                data_file = entry.get("data_file") or {}
                if not isinstance(data_file, dict):
                    continue
                fp = data_file.get("file_path") or data_file.get("path", "")
                if not fp or not str(fp).endswith(".parquet"):
                    continue
                key = _s3_uri_to_key(str(fp))
                if key in seen:
                    continue
                seen.add(key)
                parts = _hive_island_file_parts(str(fp))
                if parts and _hive_island_file_prunes(parts, constraints):
                    narrowed = True     # provably outside the island
                    continue
                keys.append(key)
                if len(keys) > max_paths:
                    return None         # fetch-strategy bound, not a prune cap
        if not narrowed:
            return None                 # no gain — keep the unscoped fetch
        return keys
    except Exception as _iss_exc:
        logger.debug("[island-scope] derivation failed (fail-open → full "
                     "metadata load): %s", _iss_exc)
        return None


def _enumeration_scope_file_keys(
    all_entries: Optional[List[List[dict]]],
    *,
    max_paths: int = 20000,
) -> Optional[List[str]]:
    """2026-08-23 — ENUMERATION-BOUNDED METADATA LOADS (perf-only).

    Bound the supplement / bloom DB fetches by the file keys THIS snapshot
    enumerated, instead of pulling every row the store holds for the
    (bucket, prefix).  The store is snapshot-AGNOSTIC (BF-370: immutable
    data files are valid across snapshots), so after churn / an indexer
    backfill it holds rows for files no current snapshot references —
    the operator's table: 13,787 store rows vs 7,024 enumerated files,
    125s of a 154s scan spent fetching rows that could never be consulted.

    PROOF this cannot change any result: the funnel iterates
    ``_all_entries`` and nothing else.  A file absent from the enumeration
    can never survive the funnel, can never be observed by the JOIN-PRUNER
    bound aggregator (``observe`` runs on funnel survivors), and can never
    consult supplement/bloom evidence (every per-file lookup keys on an
    enumerated entry's path).  Fetching its rows is therefore pure waste;
    not fetching them is invisible.  Unlike ``_island_scope_file_keys``
    this bound is valid UNCONDITIONALLY — including when
    ``join_key_columns`` is set, because enumeration is a strict superset
    of partition-stage survivorship (the island, by contrast, can be
    narrower than survivorship when tuples are undecodable, which is why
    island-scoping a join load is a data-loss vector and stays disabled).

    Keys are derived through ``_s3_uri_to_key`` — THE helper the store is
    written and consulted with.  Deriving the key any other way is the
    2026-08-23 failed-fix defect: a scope that matches nothing "succeeds"
    and silently returns no bounds.

    Returns None (= unscoped fetch, today's behaviour) when nothing is
    enumerated, when the enumeration exceeds ``max_paths`` (an IN-list of
    that size is a worse DB shape than the unscoped fetch — this bound
    changes FETCH STRATEGY only, never which files can be pruned; it must
    NEVER truncate, a truncated scope would silently starve evidence), or
    on any error (fail-open)."""
    try:
        if not all_entries:
            return None
        keys: List[str] = []
        seen: set = set()
        for entries in all_entries:
            for entry in entries or []:
                if not isinstance(entry, dict) or entry.get("status") == 2:
                    continue
                data_file = entry.get("data_file") or {}
                if not isinstance(data_file, dict):
                    continue
                fp = data_file.get("file_path") or data_file.get("path", "")
                if not fp or not str(fp).endswith(".parquet"):
                    continue
                key = _s3_uri_to_key(str(fp))
                if key in seen:
                    continue
                seen.add(key)
                keys.append(key)
                if len(keys) > max_paths:
                    return None     # fetch-strategy bound — NEVER truncate
        # NOTE: an EMPTY enumeration also returns None — ``file_paths=[]``
        # is falsy at every DB read site and would mean UNSCOPED, the exact
        # opposite of "no files".  (With zero enumerated files nothing
        # downstream consults evidence anyway.)
        return keys or None
    except Exception as _ens_exc:
        logger.debug("[enum-scope] derivation failed (fail-open -> full "
                     "metadata load): %s", _ens_exc)
        return None


_EXACT_EQ_SPELLINGS = ("equals", "eq", "=", "==")


def _identity_eq_in_decision(decoded_str, f_op, f_val, f_val_str, col_type):
    """Classify what the funnel's IDENTITY partition stage will do with this
    (decoded partition value, filter) pair — through the funnel's OWN arms.

        "exact_keep"  — kept via exact spelling equality / set membership;
                        correct min/max-bounds (= this single value) or a
                        correct bloom (contains this value) can NEVER
                        contradict it, so evidence for this column is
                        provably redundant for this file.
        "exact_drop"  — dropped decisively; the file never reaches the
                        evidence stages at all.
        "drift"       — kept, but only via a RECONCILIATION arm (BF-498
                        date-prefix widening / numeric "05"=="5" /
                        case-whitespace-NFKC string match).  The evidence
                        stages compare by ORDER, not by reconciliation, and
                        can legitimately out-prune the partition stage here
                        (e.g. supplement lo=hi='trade' vs filter 'TRADE') —
                        so exactness must be REFUSED, not assumed.
        "refuse"      — an op these arms do not model (ranges, exclusions,
                        unknown spellings — note the funnel dispatches on
                        LITERAL spellings, so even an upper-case "IN" lands
                        here exactly as it falls through the funnel).

    The eq comparand is ``f_val_str`` (the pre-stripped value from
    ``_resolved_pf``) and the drift arms are the module-level helpers the
    funnel itself calls (``_partition_date_eq``,
    ``_partition_value_numeric_match``, ``_partition_value_string_match``)
    — the one deliberate mirror is the IN set/date-prefix construction,
    which is covered by the drift corpus in
    tests/test_island_exact_2026_08_23.py."""
    try:
        if decoded_str is None:
            return "refuse"
        if f_op in _EXACT_EQ_SPELLINGS:
            if f_val_str is None:
                return "refuse"
            if decoded_str == f_val_str:
                return "exact_keep"
            if (_partition_date_eq(decoded_str, f_val_str, col_type)
                    or _partition_value_numeric_match(
                        decoded_str, (f_val_str,))
                    or _partition_value_string_match(
                        decoded_str, (f_val_str,))):
                return "drift"
            return "exact_drop"
        if f_op == "in" and isinstance(f_val, list):
            # Mirror of the funnel's IN set: DATE/TIMESTAMP/TIME cast
            # wrappers stripped from string members via the SAME regex
            # (_strip_partition_cast), everything else str()-ed.
            _set = {
                (str(_strip_partition_cast(v)) if isinstance(v, str)
                 else str(v))
                for v in f_val
            }
            if decoded_str in _set:
                return "exact_keep"
            # Funnel's reconciliation arms for IN, in its order: the ONE
            # temporal arm (_partition_date_eq per member -- 2026-09-28; the
            # inline date-prefix loop it replaces knew day/hour only), then
            # numeric, then string.
            if any(_partition_date_eq(decoded_str, _s, col_type) for _s in _set):
                return "drift"
            if (_partition_value_numeric_match(decoded_str, _set)
                    or _partition_value_string_match(decoded_str, _set)):
                return "drift"
            return "exact_drop"
        return "refuse"
    except Exception:
        return "refuse"          # an arm that errors proves nothing


def _compute_island_exactness(
    all_entries: Optional[List[List[dict]]],
    resolved_pf: Optional[list],
    island_filters: Optional[List[tuple]],
    island_coverage: Optional[Dict[str, Any]],
    table_prefix: str,
) -> Dict[str, Any]:
    """2026-08-23 — the "ISLAND IS EXACT" proof.

    The operator incident this exists for: a query whose every filter
    column is an identity partition column seeks a perfect 11-file island
    (0 S3 GETs) — and the pipeline then spends 125s loading 13,787
    supplement rows, checks bloom, and profiles prunability, to eliminate
    ZERO additional files.  The pipeline gathered evidence for a decision
    the partition values had already made.

    This function decides — POSITIVELY, on proof, never on the absence of
    a reason to continue — that the evidence stages have nothing left to
    narrow.  Two halves:

    STATIC (the consumption ledger, produced by the island builder — the
    one site that decides consumption):
      * an island exists and EVERY offered predicate was consumed into it
        (``all_consumed``): no exclusion, no range refusal, no
        non-partition predicate, no uncoercible value survives this check;
      * eq/IN entries only (``eq_in_only``): v1 deliberately refuses range
        islands — their funnel arm carries temporal-interval semantics
        this proof does not model; a refused range keeps today's full
        evidence path (a DECLARED refusal, logged with its reason);
      * every island column engaged the spec-resolved identity path of the
        funnel (``_resolved_pf``), with a literal eq/IN spelling the
        funnel's identity arms dispatch on.

    DYNAMIC (over the entries the funnel will actually walk):
      * every enumerated live parquet entry carries a dict-shaped
        partition tuple with a present, decodable value for every island
        column (decoded via the funnel's own ``_decode_partition_value``),
        and the funnel's own arms classify each (value, filter) pair as
        exact-keep or exact-drop — NEVER reconciliation-drift (see
        ``_identity_eq_in_decision``: a drift-kept file is exactly the
        file the order-comparing evidence stages could out-prune).

    When both halves hold: for every file the funnel keeps, correct
    supplement bounds are lo = hi = the matching partition value and a
    correct bloom contains it — neither can prune; files the funnel drops
    never consult evidence.  Skipping the evidence stages is therefore
    IDENTICAL, not merely safe.  Any refusal returns exact=False with its
    reason and today's behaviour continues byte-for-byte.

    Fail-safe throughout: any error → not exact.  Kill switch:
    ``iceberg.island_exact_shortcircuit`` (default True)."""
    import time as _t_ie
    _t0 = _t_ie.monotonic()

    def _no(reason: str, checked: int = 0) -> Dict[str, Any]:
        return {"exact": False, "decided_cols": set(), "reason": reason,
                "checked_entries": checked,
                "elapsed_ms": round((_t_ie.monotonic() - _t0) * 1000.0, 3)}

    try:
        try:
            from core.config import get as _cfg_ie
            if not bool(_cfg_ie("iceberg", "island_exact_shortcircuit",
                                True)):
                return _no("disabled_by_config")
        except Exception:
            pass                        # unreadable config -> knob default ON
        if not island_filters:
            return _no("no_island")
        if not island_coverage or island_coverage.get(
                "all_consumed") is not True:
            _unc = (island_coverage or {}).get("unconsumed") or []
            return _no("predicates_not_fully_consumed:"
                       + (";".join(f"{c}/{o}/{r}" for c, o, r in _unc[:5])
                          or "no_coverage_ledger"))
        if island_coverage.get("eq_in_only") is not True or any(
                len(t) != 2 for t in island_filters):
            return _no("range_island_not_exactable_v1")
        island_cols = {str(t[0]).lower() for t in island_filters}
        if not island_cols:
            return _no("no_island_columns")

        # Which funnel rows evaluate each island column?
        rows_by_col: Dict[str, list] = {}
        for _row in (resolved_pf or []):
            try:
                rows_by_col.setdefault(str(_row[9]).lower(), []).append(_row)
            except Exception:
                return _no("resolved_pf_row_malformed")
        island_rows: list = []
        for _c in sorted(island_cols):
            _rows = rows_by_col.get(_c)
            if not _rows:
                # The island consumed the filter but the funnel's spec
                # resolution did not engage it (schema-evolution drift ->
                # the hive-path FALLBACK decides per file, which this
                # proof does not model).
                return _no(f"spec_unresolved:{_c}")
            for _r in _rows:
                if _r[6] is not None:              # transform_kind
                    return _no(f"transform_engaged:{_c}")
                _op = _r[3]
                if not (_op in _EXACT_EQ_SPELLINGS
                        or (_op == "in" and isinstance(_r[4], list))):
                    return _no(f"op_not_exactable:{_c}:{_op}")
            island_rows.extend(_rows)

        # Dynamic pass over exactly the entries the funnel will walk.
        _decode_memo: Dict[tuple, Optional[str]] = {}
        # Partition values repeat massively (dates x events x codes), so
        # memoise the per-(row, decoded value) verdict too: measured on the
        # 7,024-entry walk shape this cuts the prover from ~36ms (21k
        # classifier calls) to the ~40 distinct (value, filter) pairs.
        _verdict_memos: List[Dict[str, str]] = [{} for _ in island_rows]
        checked = 0
        for entries in (all_entries or []):
            for entry in (entries or []):
                if not isinstance(entry, dict) or entry.get("status") == 2:
                    continue
                data_file = entry.get("data_file") or {}
                if not isinstance(data_file, dict):
                    continue
                fp = (data_file.get("file_path")
                      or data_file.get("path", ""))
                if not fp or not str(fp).endswith(".parquet"):
                    continue
                partition = data_file.get("partition")
                if not isinstance(partition, dict):
                    # positional tuple / absent — the funnel has coercion
                    # + refusal paths this proof does not model.
                    return _no("partition_tuple_not_dict", checked)
                checked += 1
                _entry_dropped = False
                _entry_bad: Optional[str] = None
                for _ri, _row in enumerate(island_rows):
                    part_field, col_type = _row[0], _row[1]
                    raw_val = partition.get(part_field)
                    if raw_val is None:
                        _entry_bad = _entry_bad or (
                            f"partition_value_missing:{part_field}")
                        continue
                    try:
                        _mk = (part_field, raw_val)
                        decoded_str = _decode_memo[_mk]
                    except TypeError:
                        _d = _decode_partition_value(raw_val, col_type)
                        decoded_str = (str(_d) if _d is not None else None)
                        _mk = None
                    except KeyError:
                        _d = _decode_partition_value(raw_val, col_type)
                        decoded_str = (str(_d) if _d is not None else None)
                        _decode_memo[_mk] = decoded_str
                    if decoded_str is None:
                        _entry_bad = _entry_bad or (
                            f"partition_value_undecodable:{part_field}")
                        continue
                    _vm = _verdict_memos[_ri]
                    _verdict = _vm.get(decoded_str)
                    if _verdict is None:
                        _verdict = _identity_eq_in_decision(
                            decoded_str, _row[3], _row[4], _row[5],
                            col_type)
                        _vm[decoded_str] = _verdict
                    if _verdict == "exact_drop":
                        # Drops are decisive: the funnel breaks on the
                        # first skip, so this file never reaches the
                        # evidence stages — the other columns' values
                        # cannot matter.
                        _entry_dropped = True
                        break
                    if _verdict == "drift":
                        return _no(f"reconciliation_drift:{part_field}",
                                   checked)
                    if _verdict != "exact_keep":
                        return _no(f"undecidable:{part_field}", checked)
                if _entry_dropped:
                    continue
                if _entry_bad:
                    return _no(_entry_bad, checked)
        if checked == 0:
            # An empty enumeration decides nothing — and nothing
            # downstream consults evidence for zero files anyway.
            return _no("no_entries", 0)
        return {"exact": True, "decided_cols": set(island_cols),
                "reason": "proven", "checked_entries": checked,
                "elapsed_ms": round((_t_ie.monotonic() - _t0) * 1000.0, 3)}
    except Exception as _ie_exc:
        logger.debug("[island-exact] proof errored (fail-safe -> NOT "
                     "exact): %s", _ie_exc)
        return _no(f"error:{type(_ie_exc).__name__}")


def _truncate_lower_prunes(decoded_str, trunc_threshold, source_type) -> bool:
    """For a ``truncate(col, W)``-partitioned file with truncated partition
    value ``decoded_str`` and a ``>=`` / ``>`` predicate whose threshold
    truncates to ``trunc_threshold``, return True IFF the file provably has NO
    matching rows (its whole bucket is below the threshold bucket) and may be
    skipped.

    DATA-LOSS-CRITICAL: compare in the SOURCE COLUMN's ordering, and return
    False (KEEP) whenever the ordering can't be proven -- a wrong True here is
    silent data loss.
      * numeric source  -> numeric compare.  Lexicographic would wrongly skip
        ("100" < "90" lexicographically but 100 >= 90).
      * string / binary -> lexicographic (SQL VARCHAR default collation).  A
        numeric compare would wrongly skip ("50" < "100" numerically but
        '50' >= '100' in SQL).
      * unknown source  -> KEEP (never false-skip on an unprovable ordering).
    """
    if decoded_str is None or trunc_threshold is None:
        return False
    src = str(source_type or "").lower()
    is_num = any(t in src for t in ("int", "long", "decimal", "double", "float", "num"))
    is_str = any(t in src for t in ("string", "char", "varchar", "text", "binary"))
    try:
        if is_num:
            dv, tv = _num_or_none(decoded_str), _num_or_none(trunc_threshold)
            return dv is not None and tv is not None and dv < tv
        if is_str:
            return str(decoded_str) < str(trunc_threshold)
    except Exception:
        return False
    return False   # unknown source type -> keep (conservative)


# ── 2026-08-03 DATA-LOSS FIX — temporal partitions are INTERVALS, not points ─
_TEMPORAL_IDENTITY_RANGE_TYPES = (
    "date", "timestamp", "timestamptz", "timestamp_tz",
    "timestamp with local time zone",
    "_transform_day", "_transform_hour", "_transform_month", "_transform_year",
)

_ISO_TEMPORAL_RE = None


def _parse_iso_instant(v) -> Optional["datetime"]:
    """Parse an ISO-ish temporal string ('T' OR space separator, optional
    fractional seconds, optional UTC suffix) to a naive UTC datetime.
    Month-only ('2025-09') and year-only ('2025') parse to the period start.
    Non-UTC offsets / non-ISO spellings → None (undecidable)."""
    global _ISO_TEMPORAL_RE
    if not isinstance(v, str):
        return None
    if _ISO_TEMPORAL_RE is None:
        import re as _re_ti
        _ISO_TEMPORAL_RE = _re_ti.compile(
            r"^(\d{4})(?:-(\d{2}))?(?:-(\d{2}))?"
            r"(?:[T ](\d{1,2})(?::(\d{2}))?(?::(\d{2}))?(?:\.(\d{1,6}))?)?"
            r"(Z|[+-]00:?00)?$"
        )
    m = _ISO_TEMPORAL_RE.match(_strip_partition_cast(v).strip())
    if not m:
        return None
    try:
        frac = m.group(7) or ""
        return datetime(
            int(m.group(1)), int(m.group(2) or 1), int(m.group(3) or 1),
            int(m.group(4) or 0), int(m.group(5) or 0), int(m.group(6) or 0),
            int(frac.ljust(6, "0")) if frac else 0,
        )
    except (ValueError, TypeError):
        return None


def _temporal_partition_interval(decoded_str, col_type_lower):
    """The [lo, hi_inclusive] instant interval a temporal partition value can
    COVER.  A day/hour/month/year transform covers its whole period; an
    identity timestamp carries up to 1s of decode-truncation slack
    (_decode_partition_value renders '%Y-%m-%d %H:%M:%S', dropping micros);
    an identity DATE is a point (SQL coerces DATE to midnight).
    None → unparseable (caller must KEEP)."""
    lo = _parse_iso_instant(str(decoded_str)) if decoded_str is not None else None
    if lo is None:
        return None
    t = col_type_lower
    try:
        if t == "_transform_day":
            hi = lo + timedelta(days=1) - timedelta(microseconds=1)
        elif t == "_transform_hour":
            hi = lo + timedelta(hours=1) - timedelta(microseconds=1)
        elif t == "_transform_month":
            hi = (datetime(lo.year + 1, 1, 1) if lo.month == 12
                  else datetime(lo.year, lo.month + 1, 1)) - timedelta(microseconds=1)
        elif t == "_transform_year":
            hi = datetime(lo.year + 1, 1, 1) - timedelta(microseconds=1)
        elif t == "date":
            hi = lo                     # point value (midnight)
        else:                           # identity timestamp family
            hi = lo + timedelta(seconds=1) - timedelta(microseconds=1)
    except (ValueError, OverflowError):
        return None
    return lo, hi


def _temporal_literal_interval(v) -> Optional[tuple]:
    """The [lo, hi] instant interval a temporal LITERAL denotes (2026-09-28):
    ``YYYY`` its year, ``YYYY-MM`` its month, ``YYYY-MM-DD`` its whole day
    (the BF-498/BF-509 fail-open reading), a timed literal an instant.  A
    ``date`` / ``datetime`` OBJECT is its ISO spelling.  None = unparseable
    (the caller must KEEP).  Twin of ``pruning_gate._literal_interval``,
    kept separate on purpose so the gate cannot vouch for the reader."""
    if isinstance(v, datetime):
        v = v.isoformat(sep=" ")
    elif isinstance(v, date):
        v = v.isoformat()
    if not isinstance(v, str):
        return None
    s = _strip_partition_cast(v).strip()
    lo = _parse_iso_instant(s)
    if lo is None:
        return None
    try:
        m = _ISO_TEMPORAL_RE.match(s)
        if m.group(4) is not None:          # timed -> instant
            return lo, lo
        if m.group(3) is not None:          # YYYY-MM-DD -> its day
            return lo, lo + timedelta(days=1) - timedelta(microseconds=1)
        if m.group(2) is not None:          # YYYY-MM -> its month
            hi = (datetime(lo.year + 1, 1, 1) if lo.month == 12
                  else datetime(lo.year, lo.month + 1, 1)) - timedelta(microseconds=1)
            return lo, hi
        return lo, datetime(lo.year + 1, 1, 1) - timedelta(microseconds=1)
    except (ValueError, OverflowError, AttributeError):
        return None


def _temporal_point_overlap(decoded_str, f_val, col_type_lower) -> Optional[bool]:
    """Can a partition value ``decoded_str`` (a PERIOD for day/hour/month/
    year transforms, a point for identity date, a 1s-slack interval for an
    identity timestamp) hold a row equal to literal ``f_val``?  True =
    overlap (KEEP), False = provably disjoint, None = undecidable (the
    caller must KEEP).  The eq / IN arm's ONE temporal decision."""
    piv = _temporal_partition_interval(decoded_str, col_type_lower)
    if piv is None:
        return None
    liv = _temporal_literal_interval(f_val)
    if liv is None:
        return None
    return not (liv[1] < piv[0] or liv[0] > piv[1])


def _temporal_identity_range_prune_ok(decoded_str, f_val_str,
                                      col_type_lower, f_op) -> bool:
    """DATA-LOSS-CRITICAL guard for the identity-path RANGE pruner.

    The lexicographic/typed compare in the range branch treats every
    partition value as a POINT.  For temporal partitions that is wrong in
    three ways, each of which DROPPED files holding matching rows:

      1. day/hour/month/year transforms — the file COVERS a period.  A
         day-partition file '2025-09-30' was dropped for
         ``ts > '2025-09-30 08:00:00'`` ('2025-09-30' < '2025-09-30 08…'
         lexicographically) even though its 09:00-23:59 rows match.
      2. identity timestamps — the decode truncates to whole seconds, so a
         strict ``>`` at the boundary dropped sub-second matches.
      3. spelling drift — 'T'-separator ISO literals ('2025-09-30T13:00:00')
         sort ABOVE space-separated decodes ('2025-09-30 13:00:00'), so a
         ``>`` filter dropped every same-day file.

    Called ONLY after the existing compare has decided to SKIP a file whose
    partition column type is temporal.  Returns True IFF interval semantics
    ALSO prove the skip safe; False = KEEP.  It can only PREVENT a drop,
    never cause one.  Non-temporal types never reach here.
    """
    iv = _temporal_partition_interval(decoded_str, col_type_lower)
    if iv is None:
        return False                    # unparseable — cannot prove, keep
    liv = _temporal_literal_interval(f_val_str) if f_val_str is not None else None
    if liv is None:
        return False                    # unparseable literal — keep
    lo, hi = iv
    # A RANGE literal is its START instant -- SQL's own reading (``v <
    # '2024-01-01'`` excludes the whole of Jan 1; ``v <= '1995-06'`` is the
    # 1st at midnight).  Only = / IN read a bare date as its whole day.
    lit = liv[0]
    if f_op in ("gt", ">", "greater_than"):
        return hi <= lit                # no instant in [lo,hi] exceeds lit
    if f_op in ("gte", ">=", "greater_equals"):
        return hi < lit
    if f_op in ("lt", "<", "less_than"):
        return lo >= lit
    if f_op in ("lte", "<=", "less_equals"):
        return lo > lit
    return False                        # unknown op — keep


def _manifest_temporal_prune_ok(lo, hi, cval, ptype, op) -> bool:
    """2026-08-03 DATA-LOSS FIX — MANIFEST-level twin of
    ``_temporal_identity_range_prune_ok``.  Files inside a pruned manifest
    never reach the per-file loop OR the pruning gate, so a wrong manifest
    drop is UNGATED data loss.  The 2026-08-03 interval fix was applied only
    at file level; at manifest level the same two diseases persisted:

      * POINT-vs-INTERVAL: day/month/year bounds decode to period strings
        ('2025-09-30', '2025-09', '2025'), so ``ts > '2025-09-30 08:00:00'``
        lexicographically pruned the manifest whose LAST day is 2025-09-30 —
        dropping that day's 08:00–24:00 rows.
      * ISO SPELLING DRIFT: identity timestamps decode via ``dt.isoformat()``
        ('T' separator) while SQL literals are space-separated, and
        ``' '(0x20) < 'T'(0x54)`` — so ``lt/lte/eq`` pruned same-day
        manifests that DO match.

    Called ONLY after the existing lexicographic/typed compare has decided
    to PRUNE a manifest whose partition type is temporal.  Returns True IFF
    interval-instant semantics ALSO prove the prune safe; False = KEEP.  It
    can only PREVENT a drop, never cause one.  ``lo``/``hi`` are the DECODED
    manifest partition-summary bounds; the manifest covers the instant
    interval [interval(lo).start, interval(hi).end].
    """
    try:
        m_lo = None
        m_hi = None
        if lo is not None:
            _ivl = _temporal_partition_interval(str(lo), ptype)
            if _ivl is None:
                return False            # undecidable bound — cannot prove, keep
            m_lo = _ivl[0]
        if hi is not None:
            _ivh = _temporal_partition_interval(str(hi), ptype)
            if _ivh is None:
                return False
            m_hi = _ivh[1]
        # 2026-09-28: ONE literal-interval rule (_temporal_literal_interval)
        # -- a bare date is its whole day, YYYY-MM its month, YYYY its year
        # -- for = / IN (widening can only KEEP more).  A RANGE literal is
        # its START instant, SQL's own reading (``v < '2024-01-01'``
        # excludes the whole of Jan 1) -- exactly the 2026-08-03 semantics.
        _liv = _temporal_literal_interval(str(cval).strip())
        if _liv is None:
            return False                # unparseable literal — keep
        v_lo, v_hi = _liv
        if op in ("equals", "eq", "=", "==", "in"):
            if m_lo is not None and v_hi < m_lo:
                return True
            if m_hi is not None and v_lo > m_hi:
                return True
            return False
        lit = v_lo
        if op in ("gt", ">", "greater_than"):
            return m_hi is not None and m_hi <= lit
        if op in ("gte", ">=", "greater_equals"):
            return m_hi is not None and m_hi < lit
        if op in ("lt", "<", "less_than"):
            return m_lo is not None and m_lo >= lit
        if op in ("lte", "<=", "less_equals"):
            return m_lo is not None and m_lo > lit
        return False                    # unknown op — keep
    except Exception as _mtp_exc:                           # pragma: no cover
        logger.debug("manifest temporal prune veto errored (KEEP): %s",
                     _mtp_exc)
        return False


def _snapshot_has_row_deletes(metadata: Optional[dict], snapshot_id: Any,
                              s3_client=None, bucket: str = "") -> bool:
    """True when the snapshot has any row-level (position/equality) delete files.

    Detection is AUTHORITATIVE and writer-independent, the way Starburst does it:
      1. If the snapshot ``summary`` reports the delete counters (``total-delete-
         files`` / ``total-position-deletes`` / ``total-equality-deletes``), trust
         them — no S3 round-trip.  Most writers emit these.
      2. If the counters are ABSENT (some writers omit them — and we can't change
         the writer), do NOT assume zero.  Read the snapshot's manifest-list Avro
         (one cheap, cached GET) and look for any manifest with ``content == 1``
         (a delete manifest).  This is the same metadata Starburst reads; it never
         depends on the summary being populated.
      3. If we can't check (no s3_client, or a read error), return True — fail
         SAFE: force the delete-aware path rather than risk a delete-blind result.

    This closes the "COUNT is 726 high because the writer didn't record delete
    counters, so the fast paths skipped delete collection" gap.
    """
    try:
        _sid = str(snapshot_id)
        _snap = None
        for _s in (metadata or {}).get("snapshots") or []:
            if str(_s.get("snapshot-id")) == _sid:
                _snap = _s
                break
        if _snap is None:
            # F7 fail-safe (2026-07-15): the requested snapshot id is not in the
            # metadata we hold (stale/divergent metadata).  We CANNOT prove it is
            # delete-free, so assume deletes and force the delete-aware path
            # rather than risk a delete-blind overcount.  Both callers merely
            # fall back to the full read on True -- no hard failure.
            return True
        _sum = _snap.get("summary") or {}
        _counters = [_sum.get(k) for k in
                     ("total-delete-files", "total-position-deletes", "total-equality-deletes")]
        _present = [c for c in _counters if c is not None]
        if _present:
            return any(int(c) > 0 for c in _present)   # writer reported them → trust
        # Counters absent → authoritative manifest-list check (content==1).
        if s3_client is not None and bucket:
            try:
                _ml = _snap.get("manifest-list")
                if _ml:
                    _mans = _read_avro(_read_manifest_list_avro_cached(
                        s3_client, bucket, _s3_uri_to_key(_ml)))
                    for _m in _mans:
                        if int(_m.get("content", 0) or 0) == 1:
                            return True
                    return False
            except Exception as _ml_exc:
                logger.debug("delete-manifest detection via manifest-list failed "
                             "(assuming deletes, fail-safe): %s", _ml_exc)
                return True
        return True   # no way to confirm → assume deletes → delete-aware path
    except Exception:
        return True    # unknown → assume deletes → force the MoR-aware path


def _scan_ledger_verdict(
    considered: int,
    final: int,
    declared_total: Optional[Any],
    has_filters: bool,
    hit_limit: bool,
    max_files: int,
    manifest_read_failures: int = 0,
) -> Tuple[str, str]:
    """Scan Ledger (2026-07-15, Finding #1) — pure reconciliation arithmetic.

    The pruning brain checks ITS OWN arithmetic against the snapshot
    summary's DECLARED ``total-data-files``.  A query once scanned ~4000
    files across two tables whose snapshots declared 1605 + 1200 files —
    the brain enumerated more files than exist and never noticed.  This
    helper is the detector.  It is PURE (no I/O, no side effects) so it
    can be unit-tested without S3 mocking, and it is DIAGNOSTIC only —
    callers must never alter the returned file list based on the verdict.

    Invariants:
      A (always valid): ``considered <= declared_total``.  You can never
        consider more files than the snapshot declares.  Violation =
        phantom / double-counted-manifest / cross-snapshot-cache-
        contamination fingerprint → verdict ``over_count``.
      B (only when NO filters, NOT capped, no manifest read failures):
        ``final == declared_total``.  Under → ``under_count`` (possible
        partial enumeration); over → ``over_count`` (phantom).

    Returns ``(verdict, note)`` where verdict is one of:
      ``ok`` · ``over_count`` · ``under_count`` · ``partial_manifest_read`` ·
      ``skipped_capped`` · ``no_declared_total``.

    ``partial_manifest_read`` (2026-08-20): one or more manifests could not
    be read and contributed ZERO data files — the enumeration is provably
    partial regardless of caps/filters, so this verdict wins over the
    cap/filter relaxations and is a certificate HARD NEGATIVE.
    """
    try:
        declared = int(declared_total) if declared_total is not None else None
    except (TypeError, ValueError):
        declared = None
    # 2026-08-20 DATA-LOSS FIX: a manifest read failure means every data
    # file that manifest referenced is ABSENT from the enumeration (the
    # non-strict path returns [] for it) — a PROVABLY PARTIAL scan set.
    # This used to return verdict "ok" ("invariant B relaxed"), an
    # AFFIRMATIVE completeness signal the Completeness Certificate turned
    # into COMPLETE.  It is checked FIRST — before the no-declared-total
    # skip and the cap/filter relaxations — because those merely make
    # final<declared unprovable, while a failed manifest makes
    # incompleteness PROVEN.  The certificate treats this verdict as a
    # HARD NEGATIVE (INCOMPLETE) — see
    # completeness_certificate._eval_scan_ledger.
    if manifest_read_failures:
        return ("partial_manifest_read",
                f"{int(manifest_read_failures)} manifest read failure(s) — "
                "every data file referenced by a failed manifest is MISSING "
                "from this scan set (partial enumeration, delivered with a "
                "success status unless the certificate blocks it); fix the "
                "manifest reads (S3 access / proxy / credentials) or enable "
                "iceberg.manifest_read_strict_mode to fail the query instead")
    if declared is None:
        return ("no_declared_total",
                "snapshot summary has no total-data-files "
                "(writer omitted it) — ledger skipped")
    considered = int(considered or 0)
    final = int(final or 0)
    # Invariant A — ALWAYS checked (valid even under caps / filters:
    # neither can make considered EXCEED the snapshot's declared total).
    if considered > declared:
        return ("over_count",
                f"INVARIANT A VIOLATED: considered {considered} > declared "
                f"total-data-files {declared} (delta +{considered - declared})"
                " — phantom files / double-counted manifest / cross-snapshot "
                "cache contamination fingerprint")
    # Invariant B is only meaningful on an UNCAPPED, UNFILTERED, fully-read
    # enumeration — otherwise final < declared is expected and benign.
    if hit_limit or (max_files or 0) > 0:
        return ("skipped_capped",
                f"invariant B skipped: enumeration capped "
                f"(hit_limit={bool(hit_limit)}, max_files={int(max_files or 0)})"
                " — final < declared is expected")
    if has_filters:
        return ("ok",
                "filters present — final <= declared is expected (pruning); "
                "invariant B not applicable")
    if final == declared:
        return ("ok", f"reconciled: final {final} == declared {declared}")
    if final < declared:
        return ("under_count",
                f"INVARIANT B VIOLATED: final {final} < declared "
                f"total-data-files {declared} with NO filters, NO cap and NO "
                "manifest read failures — possible partial enumeration or "
                "over-aggressive dedup")
    return ("over_count",
            f"INVARIANT B VIOLATED: final {final} > declared "
            f"total-data-files {declared} — phantom files survived dedup")


# ── Phase 3 (industrialization, 2026-07-23) — Query Passport + DB-only
# enumeration helpers.  ALL fail-open: any error → None → today's path. ──


def _island_spec_display(island_filters) -> str:
    """One-line human summary of an island spec — legacy eq/IN entries and
    2026-08-22 range entries alike.  Display only; never raises (the log
    line that uses it must not be able to kill the scan)."""
    try:
        from core.filter_ops import normalize_island_spec as _nis
        parts = []
        for col, op, payload in _nis(island_filters or []):
            if op == "range":
                lo, hi = payload.get("lo"), payload.get("hi")
                lo_b = ">=" if payload.get("lo_inc", True) else ">"
                hi_b = "<=" if payload.get("hi_inc", True) else "<"
                seg = []
                if lo is not None:
                    seg.append(f"{lo_b} {lo}")
                if hi is not None:
                    seg.append(f"{hi_b} {hi}")
                parts.append(f"{col} RANGE ({' AND '.join(seg) or '?'})")
            else:
                parts.append(f"{col} IN ({len(payload)})")
        return " AND ".join(parts) or "<empty>"
    except Exception as _disp_exc:
        return f"<island spec unprintable: {_disp_exc}>"


def _phase3_island_filters_for_snapshot(
    metadata: Optional[dict],
    partition_filters: Optional[List[Dict[str, Any]]],
    coverage_out: Optional[Dict[str, Any]] = None,
) -> Optional[List[tuple]]:
    """SAFE hive-island pushdown filters for this table's partition spec.

    Reuses the db-first brain's ``_hive_island_pushdown_filters`` contract
    (identity string/date partition eq/IN, plus — 2026-08-22 — date-identity
    RANGES as ``(col, "range", payload)`` entries; anything else → None →
    whole-table behavior) so the SQL island carved here is provably a
    superset-safe narrowing — the downstream per-entry funnel prunes the
    exact set either way."""
    try:
        if not metadata or not partition_filters:
            return None
        from core.iceberg_db_first_reader import (
            _hive_island_pushdown_filters as _hipf,
        )
        pspec = _extract_partition_spec(metadata)
        if not pspec:
            return None
        part_cols_lower = {str(c).lower() for c in pspec.keys()}
        types_lower: Dict[str, str] = {}
        _cur_sid = metadata.get("current-schema-id")
        _schemas = metadata.get("schemas") or []
        _cur = next((s for s in _schemas if s.get("schema-id") == _cur_sid),
                    _schemas[0] if _schemas else None)
        if _cur:
            for _f in _cur.get("fields") or []:
                _nm, _tp = _f.get("name"), _f.get("type")
                if _nm and isinstance(_tp, str):
                    types_lower[_nm.lower()] = _tp
                elif _nm and isinstance(_tp, dict):
                    types_lower[_nm.lower()] = _tp.get("type", "string")
        # Partition transform markers WIN over same-named schema columns
        # (2026-07-22 lesson): a bucket/truncate/day field must be seen as
        # its transform so _hipf falls open on it.
        for _pc, _pt in pspec.items():
            _pk = str(_pc).lower()
            if str(_pt).startswith("_transform_"):
                types_lower[_pk] = _pt
            else:
                types_lower.setdefault(_pk, _pt)
        return _hipf(partition_filters, part_cols_lower, types_lower,
                     coverage_out=coverage_out)
    except Exception as _exc:
        logger.debug("[phase3] island filter derivation failed "
                     "(fail-open, no pushdown): %s", _exc)
        # A failed derivation proves nothing: any half-filled coverage
        # ledger must not survive to claim consumption it cannot back.
        if coverage_out is not None:
            coverage_out.clear()
        return None


def _phase3_expected_total_files(metadata: Optional[dict],
                                 snapshot_id: Any) -> Optional[int]:
    """The snapshot's authoritative total-data-files from its summary
    (already in memory — no S3).  None when the writer omitted it."""
    try:
        _snap = next(
            (s for s in (metadata or {}).get("snapshots", [])
             if str(s.get("snapshot-id")) == str(snapshot_id)), None)
        if _snap:
            _tdf = (_snap.get("summary") or {}).get("total-data-files")
            if _tdf is not None:
                return int(_tdf)
    except Exception as _be_exc:
        note_best_effort("int(_tdf)", _be_exc,
                         logger=logger)
    return None


def _phase3_issue_passport(
    db_manager,
    metadata: Optional[dict],
    bucket: str,
    table_prefix: str,
    snapshot_id: Any,
    partition_filters: Optional[List[Dict[str, Any]]],
    sql_hash: Optional[str],
    _out_meta: Optional[dict],
) -> None:
    """Issue the Query Passport at PLAN time (snapshot just pinned) from the
    db-first store — PURE DB, no S3.  Stamps ``_out_meta['query_passport']``
    and the process-local passport registry (execution_id → passport) so the
    Phase-2 job row can carry it.  Flag-gated + fail-open: one flag read and
    out when ``industrialization.passport_enabled`` is OFF."""
    try:
        from core.industrialization import is_enabled as _ind_enabled
        if not _ind_enabled("passport_enabled"):
            return
        # plan_hash (sql_hash) is the passport's plan identity — without it
        # the passport can never be addressable, and its absence also marks
        # the BF-549 OR-branch recursion (sql_hash is not propagated), whose
        # per-branch island estimate must not masquerade as the union
        # query's.  Skip in both cases.
        if db_manager is None or not snapshot_id or not sql_hash:
            return
        from core.industrialization.passport_issuer import (
            issue_passport_for_scan,
        )
        _isl = _phase3_island_filters_for_snapshot(metadata, partition_filters)
        # 2026-08-22 — passport_issuer speaks the LEGACY (col, [values])
        # shape only (it is outside this change's ownership).  Range entries
        # are dropped for the ESTIMATE: an estimate that ignores a narrowing
        # conjunct stays an upper bound — wider, never narrower.
        _isl_legacy = [t for t in (_isl or []) if len(t) == 2] or None
        _pp = issue_passport_for_scan(
            db_manager, bucket=bucket, table_prefix=table_prefix,
            snapshot_id=str(snapshot_id), plan_hash=str(sql_hash or ""),
            island_filters=_isl_legacy)
        if _pp is None:
            return
        _d = _pp.to_dict()
        if isinstance(_out_meta, dict):
            _out_meta["query_passport"] = _d
        _eid = None
        if isinstance(_out_meta, dict):
            _eid = (_out_meta.get("execution_id")
                    or _out_meta.get("correlation_id"))
        if not _eid:
            try:
                from core.query_diagnostic_store import (
                    get_current_execution_id as _gceid,
                )
                _eid = _gceid()
            except Exception:
                _eid = None
        if _eid:
            from core.industrialization import passport_registry as _preg
            _preg.register(str(_eid), _d)
        _est = _pp.estimate
        logger.info(
            "[passport] issued plan_hash=%s snapshot=%s files=%s bytes=%s "
            "rows=%s partitions=%s confidence=%s island=%s",
            str(sql_hash or "")[:12], snapshot_id,
            getattr(_est, "files", None), getattr(_est, "bytes", None),
            getattr(_est, "rows_post_prune", None),
            getattr(_est, "partitions", None),
            getattr(getattr(_est, "confidence", None), "value", "unknown"),
            bool(_isl),
        )
    except Exception as _exc:
        logger.debug("[passport] issuance failed (fail-open): %s", _exc)


@_one_observation_per_call
def get_iceberg_data_files(
    s3_client,
    bucket: str,
    table_prefix: str,
    partition_filters: Optional[List[Dict[str, Any]]] = None,
    keys_only: bool = False,
    max_files: int = 0,
    *,
    metadata: Optional[dict] = None,
    _out_meta: Optional[dict] = None,
    force_fresh: bool = False,
    snapshot_id: Optional[int] = None,
    as_of_timestamp_ms: Optional[int] = None,
    max_rows: int = 0,
    enforce_max_files_cap: bool = True,
    # BF-COL-STATS-V2: when db_manager is provided, look up the column-stats
    # supplement table for filter columns lacking manifest bounds and
    # apply additional file-level pruning using those supplement bounds.
    # The supplement is keyed on (bucket, table_prefix) — already required
    # positional arguments — so identity is shared across QueryStudio
    # connections that point at the same S3 location.
    # connection_id / table_name remain accepted for backward compat but
    # are NOT used for the supplement lookup; they're ignored here.
    connection_id: Optional[int] = None,
    table_name: Optional[str] = None,
    db_manager=None,
    # BF-549 (2026-05-29): OR-condition partition pruning.
    # When the user's WHERE has ``cond1 OR cond2`` across DIFFERENT
    # columns (e.g. ``WHERE region='US' OR year=2025``), the
    # extractor cannot collapse it into a single AND-list without
    # over-pruning.  Instead it can pass each OR-branch as a
    # separate AND-group via this parameter.  The reader runs the
    # iceberg scan once per group and UNIONs the resulting file
    # sets.  When None (the default), behaviour is unchanged.
    or_groups: Optional[List[List[Dict[str, Any]]]] = None,
    # SCAN-STRATEGY (2026-06-01): file ordering is now owned by
    # core.scan_strategy.  Caller passes ``file_order`` (a string matching
    # FileOrder enum: "largest_first" | "smallest_first" | "size_balanced"
    # | "manifest_order").  When None, falls back to the admin-controlled
    # ``scan_strategy.default_file_order`` config key (which itself
    # defaults to "manifest_order" — i.e. no implicit sort).  This
    # REPLACES the hard-coded BF-535 smallest-first sort; the user's
    # 3000-file feed-gen workload was hurt by that default because the
    # biggest file became a tail-end straggler.  See
    # backend/core/scan_strategy.py for the full design rationale.
    file_order: Optional[str] = None,
    # JOIN-PRUNER (2026-06-01): when caller supplies a list of column
    # names, the reader aggregates lower_bound / upper_bound across every
    # SURVIVING data file for those columns and writes the result to
    # ``_out_meta["join_key_bounds"] = {col_lower: (lo, hi), ...}``.
    # This is the input core.join_pruner needs to synthesise BETWEEN
    # filters for joined tables that share a key column with this
    # (already-filtered) anchor table.  Zero extra S3 reads — we walk
    # data_file.lower_bounds / upper_bounds maps already iterated for the
    # existing column-stats pruning.  Empty list / None → no aggregation.
    join_key_columns: Optional[List[str]] = None,
    # Phase 156 (2026-06-25) -- brain pruning memo.  When caller supplies
    # a sql_hash + db_manager, the reader consults brain_pruning_memo
    # BEFORE the manifest walk and returns the cached file list on hit
    # (skips manifest + supplement + bloom prune entirely).  On miss,
    # the reader runs normally AND populates the memo on exit so the
    # next identical query hits.  Optional; missing sql_hash falls
    # through to today's behaviour.
    sql_hash: Optional[str] = None,
    # 2026-09-28 -- THE EMPTY ISLAND.  0 = the caller's read; 1 = the
    # re-prove pass (gate FORCED to enforce, 100% sampling) this function
    # runs on itself when a 0-file answer could not be proven; 2 = the
    # widening pass (no partition filters at all) when even enforce could
    # not prove it.  Never passed by a caller.
    _empty_island_pass: int = 0,
) -> List[Dict[str, Any]]:
    """
    Read Iceberg table metadata and return the active Parquet data files.

    Args:
        s3_client:         boto3 S3 client
        bucket:            S3 bucket name
        table_prefix:      S3 prefix of the Iceberg table root (ends with /)
        partition_filters: Optional list of filter dicts in adv_filters format
                           e.g. [{"col":"business_date","op":"equals","val":"2024-01-15"}]
                           Used to prune manifests via Iceberg partition bounds.
        keys_only:         If True, skip the expensive _batch_s3_metadata() call
                           and return entries with key/path only (for query execution).
        max_files:         If > 0, stop collecting files once this many are found.
                           Useful with LIMIT queries to avoid scanning all manifests.
        metadata:          Pre-loaded Iceberg metadata dict.  When provided, skips
                           the S3 read for metadata.json (avoids duplicate fetches).
        snapshot_id:       Phase 139 audit-fix Gap 6 — when provided, read this
                           snapshot instead of current-snapshot-id (time travel /
                           AS OF VERSION). Raises if the snapshot doesn't exist
                           in the table metadata.
        as_of_timestamp_ms: Phase 139 audit-fix Gap 6 — when provided, find the
                           snapshot that was current at this timestamp via the
                           snapshot-log. Mutually exclusive with snapshot_id.

    Returns:
        List of dicts: {key, name, path, size_bytes, last_modified, folder, type}
    """
    # 2026-11-01 -- THE RUN'S VERSION MAP (core/iceberg_versions.py).  A run
    # resolves every Iceberg table it reads ONCE, before any data is read
    # (pinned -> that snapshot; else the CURRENT snapshot), and every read of
    # the run is handed that resolution: the snapshot AND the metadata it was
    # resolved from (as of that snapshot: its schema).  A caller's own
    # pre-read metadata is a SECOND resolution of "latest" and is replaced --
    # a commit landing mid-run must never put two snapshots in one answer.
    # A caller that names a snapshot itself must name the SAME one.
    if _empty_island_pass == 0:
        from core.iceberg_versions import (
            version_for as _iv_for, IcebergVersionRefusal as _IVR)
        _run_rv = _iv_for(table_name, bucket, table_prefix)
        if _run_rv is not None:
            if as_of_timestamp_ms is not None or (
                    snapshot_id is not None and _run_rv.snapshot_id is not None
                    and int(snapshot_id) != int(_run_rv.snapshot_id)):
                raise _IVR(
                    f"{_run_rv.table} was resolved to version "
                    f"{_run_rv.snapshot_id} for this run, and a step asked "
                    f"for another version; refusing rather than mixing two "
                    f"versions in one answer.")
            if _run_rv.snapshot_id is None:
                logger.info("get_iceberg_data_files: %s has no snapshot in "
                            "this run's resolution -- empty", table_prefix)
            snapshot_id = _run_rv.snapshot_id
            if _run_rv.metadata is not None:
                metadata = _run_rv.metadata
                if _out_meta is not None and _run_rv.metadata_key:
                    _out_meta["metadata_key"] = str(_run_rv.metadata_key)
            if _out_meta is not None:
                _out_meta["run_version"] = _run_rv.record()
    logger.info(
        "get_iceberg_data_files: table=%s bucket=%s keys_only=%s max_files=%d "
        "filters=%s snapshot_id=%s as_of_ts=%s",
        table_prefix, bucket, keys_only, max_files, bool(partition_filters),
        snapshot_id, as_of_timestamp_ms,
    )

    # ── Phase 0 (2026-08-22) — per-query ACTUAL S3 GET counter ───────────
    # Installed FIRST so the pointer-verify / metadata.json / manifest-list
    # GETs below are all counted.  On an or_groups recursion the parent's
    # counter is reused (never replaced) and every invocation reports its
    # own DELTA from the entry snapshot, so nested scan lines stay honest.
    # The token is deliberately not reset: the counter is one int, and the
    # delta arithmetic makes a leaked counter harmless.
    _s3_ctr = _S3_GET_COUNTER_CTX.get()
    if _s3_ctr is None:
        _s3_ctr = _S3GetCounter()
        _S3_GET_COUNTER_CTX.set(_s3_ctr)
    _s3_gets_at_entry = _s3_ctr.value
    # Same lifecycle as the GET counter: reuse a parent's on or_groups
    # recursion, report a DELTA from entry, never reset the token.
    _s3_list_ctr = _S3_LIST_COUNTER_CTX.get()
    if _s3_list_ctr is None:
        _s3_list_ctr = _S3GetCounter()
        _S3_LIST_COUNTER_CTX.set(_s3_list_ctr)
    _s3_lists_at_entry = _s3_list_ctr.value
    _seek_route = "walk"        # Phase 0: route that served enumeration

    # ── B3 SCOPE GUARD (2026-07-14 deep-dive, consumer-side complement) ────────
    # A filter dict may carry a ``table`` key (the alias-resolved REAL table name
    # it was qualified to in the SQL).  Unlike the DuckDB consumer
    # (_compute_table_filters), this iceberg reader otherwise splits filters
    # purely on (col, op, val) and IGNORES ``table`` — so a foreign predicate
    # like ``FACT.system_id`` in a combined multi-table filter list would prune
    # the EXT target (silent dropped join rows) if EXT has a same-named column.
    # Drop any filter qualified to a DIFFERENT table than this call's
    # ``table_name`` (case-insensitive exact match, mirroring
    # _compute_table_filters).  SAFE-BY-CONSTRUCTION: dropping a filter only ever
    # REDUCES pruning (over-scan) — it can never cause a wrong prune / data loss.
    # NO-OP when table_name is None (DuckDB/feed callers pre-scope and pass
    # nothing) or a filter is unqualified (no ``table`` key) or matches.
    if partition_filters and table_name:
        # Match against BOTH the full registered name and its bare last segment,
        # because the filter's ``table`` value is the bare SQL token (sqlglot
        # strips the schema, e.g. "analytics.fact" -> "fact") while table_name
        # may be registered schema-qualified.  Comparing only the full name
        # would drop the table's OWN filters on a schema/name-spelling mismatch
        # (over-scan).  A genuinely different table still fails both → dropped.
        _b3_tn_full = str(table_name).lower()
        _b3_tn_base = _b3_tn_full.rsplit(".", 1)[-1]
        _b3_ok = {_b3_tn_full, _b3_tn_base}

        def _b3_keep(_f):
            if not isinstance(_f, dict):
                return True                      # non-dict filter — leave as-is
            _ft = _f.get("table")
            if not _ft:
                return True                      # unqualified — applies to all
            return str(_ft).lower() in _b3_ok    # qualified to THIS table

        _b3_scoped = [_f for _f in partition_filters if _b3_keep(_f)]
        if len(_b3_scoped) != len(partition_filters):
            logger.info(
                "B3 scope guard: dropped %d foreign-table filter(s) for "
                "table_name=%s (a predicate qualified to another table must not "
                "prune this one).",
                len(partition_filters) - len(_b3_scoped), table_name)
        partition_filters = _b3_scoped

    # ── 2026-10-08 DISJUNCTIONS: one carrier from here on ─────────────────
    # Both spellings of an OR -- the ``or_groups`` keyword and ONE inline
    # ``{"op": "or", "or": [...]}`` group inside ``partition_filters`` (the
    # structured filter_logic="OR" road, which every arm below treated as an
    # unknown operator = no pruning at all) -- become the local ``or_groups``
    # (a list of AND-lists) and ``partition_filters`` keeps the AND conjuncts
    # only.  The decision whether the union may prune is taken ONCE, below,
    # after the partition spec is known.
    from core.filter_ops import split_or_groups as _split_or_groups
    partition_filters, _or_groups_in = _split_or_groups(partition_filters, or_groups)
    or_groups = _or_groups_in or None

    # Phase 156 R6 (2026-07-22) — the memo key now folds the operative
    # pruning-config fingerprint (bloom-sidecar / s3-bloom / db-first) so a knob
    # flip busts stale survivor lists for an UNCHANGED snapshot.  That transform
    # lives INSIDE brain_pruning_memo.get_memo/put_memo (single chokepoint), so
    # this reader passes its RAW sql_hash unchanged and still keys identically to
    # brain_router — no per-caller drift possible.
    #
    # Phase 156 -- the brain pruning memo consult was previously here
    # but moved DOWN to right after current_snapshot_id is resolved
    # (~line 3830).  Reason: the consult key is (sql_hash, snapshot_id);
    # at function entry the snapshot isn't resolved yet for the common
    # BQB / Feed / Reports paths.  See the consult+populate block at
    # the post-snapshot-resolution site.

    # BF-296: stage timing — start with metadata read.  Records into the
    # per-execution stage tracker so the heartbeat + execution detail
    # surface "step X took Ys" breakdowns.
    _bf296_t_metadata = _time.monotonic()
    # ── Step 1: Read latest table metadata JSON ───────────────────────────────
    if metadata is None:
        meta_prefix = table_prefix.rstrip("/") + "/metadata/"
        meta_key = _latest_metadata_key(s3_client, bucket, meta_prefix,
                                         force_fresh=force_fresh)
        # BF-556 (2026-05-29): writer-expired-snapshot retry.
        # When a writer runs ``expire_snapshots`` while QS holds a
        # cached metadata-key pointing at the now-deleted manifest,
        # the GET against that key returns 404 / NoSuchKey.  Old
        # behaviour: surface a confusing error.  Fix: catch the
        # not-found, evict the cache layers, and retry ONCE with
        # ``force_fresh=True``.  Single retry only — if S3 is
        # genuinely broken we surface the second failure.
        try:
            metadata = _read_s3_json_cached(s3_client, bucket, meta_key)
        except Exception as _mr_exc:
            _msg = str(_mr_exc).lower()
            if ("nosuchkey" in _msg or "not found" in _msg
                    or "404" in _msg):
                logger.warning(
                    "BF-556 metadata key %s vanished (likely "
                    "writer expire_snapshots) — evicting cache + "
                    "retrying with force_fresh", meta_key,
                )
                cache_id = f"{bucket}/{meta_prefix}"
                with _metadata_key_cache_lock:
                    _metadata_key_cache.pop(cache_id, None)
                _evict_metadata_key_from_db(
                    _connection_id_from_s3_client(s3_client), cache_id)
                _invalidate_result_cache_for_cache_id(cache_id)
                meta_key = _latest_metadata_key(
                    s3_client, bucket, meta_prefix, force_fresh=True)
                metadata = _read_s3_json_cached(s3_client, bucket, meta_key)
            else:
                raise
        # ── 2026-07-15 ADAPTIVE FRESHNESS (audit Finding #2) ──────────────
        # Runs AFTER every cache layer has spoken (this is the resolved
        # pointer the query will actually use — including L1/L2/L2.5 cache
        # hits the old flag-gated cross-check never saw).  Zero extra I/O
        # for healthy tables; on a trigger (scan-ledger anomaly / stale-by-
        # cadence / hint-lied-before / config force) it runs a capped,
        # throttled newest-by-scan LIST and prefers a strictly NEWER
        # metadata.json, invalidating the poisoned snapshot-keyed caches.
        # Skipped for explicit time-travel (snapshot_id / as_of_timestamp_ms)
        # — the user pinned a snapshot; a newer metadata could have expired
        # it and changed behaviour.  FAIL-SAFE: any error keeps (meta_key,
        # metadata) exactly as resolved above.
        if snapshot_id is None and as_of_timestamp_ms is None:
            try:
                meta_key, metadata = _adaptive_freshness_refresh(
                    s3_client, bucket, table_prefix, meta_prefix,
                    meta_key, metadata,
                    db_manager=db_manager, _out_meta=_out_meta)
            except Exception as _af_exc:                     # pragma: no cover
                logger.debug("[adaptive-freshness] call-site guard tripped "
                             "(fail-safe): %s", _af_exc)
        meta_key_display = meta_key
        # 2026-10-14 -- THE metadata file this read is planned from (after
        # every cache layer and the freshness check): the read plan hands
        # Spark this file + the pinned snapshot (core/feed/read_plan.py).
        # Recorded HERE, before any early return (the memo path returns
        # long before the snapshot export below).
        if _out_meta is not None:
            _out_meta["metadata_key"] = str(meta_key)
    else:
        meta_key_display = "(pre-loaded)"
    logger.info("Iceberg metadata: %s (format-version %s)",
                meta_key_display, metadata.get("format-version", "?"))
    _bf296_metadata_seconds = _time.monotonic() - _bf296_t_metadata

    # ── BF-549 (2026-05-29): OR-condition partition pruning ──────────────────
    # When the caller supplied ``or_groups`` (per-branch AND-filter lists
    # extracted from a top-level OR), run the scan ONCE PER GROUP and
    # union the resulting file sets.  Each group's AND-list is combined
    # with the global ``partition_filters`` so a query like
    # ``WHERE country='US' AND (region='East' OR year=2025)`` is
    # pruned correctly: each branch carries the country='US' AND.
    #
    # 2026-10-08 -- THE decision (``core.filter_ops.disjunction_decision``),
    # asked with the partition columns of THIS table (spec field names and
    # their source columns): every branch must carry a decidable predicate
    # on one of them, or the union is the whole table and the disjunction
    # is DECLINED with its reason -- the AND conjuncts alone prune below.
    # Per branch, the recursive call reuses every per-predicate decision
    # (manifest-summary Step 4b, the per-file identity arm, db-first v3,
    # the temporal overlap rule, the string-range decision).
    _dd = None
    if or_groups:
        from core.filter_ops import disjunction_decision as _disjunction_decision
        _dd = _disjunction_decision(
            or_groups, partition_columns=_partition_pruning_columns(metadata))
        if _out_meta is not None:
            _out_meta["disjunction"] = {
                "applies": bool(_dd.applies), "reason": _dd.reason,
                "branches": _dd.n_branches if _dd.applies else sum(len(g) for g in or_groups)}
        if not _dd.applies:
            logger.info(
                "[island] %s: disjunction DECLINED (%s: %s) -- %d OR branch(es) "
                "stay in the WHERE for DuckDB; the %d AND conjunct(s) alone "
                "prune.", table_prefix, _dd.reason, _dd.reason_text,
                sum(len(g) for g in or_groups), len(partition_filters or []))
            or_groups = None
    if or_groups and _dd is not None and _dd.applies:
        logger.info(
            "[island] %s: disjunction ENGAGED -- %d branch(es), each pruned "
            "on its own predicates (+ %d AND conjunct(s)); the file set is "
            "the UNION of the branch islands.", table_prefix, _dd.n_branches,
            len(partition_filters or []))
        _union_keys: set = set()
        _union_files: List[Dict[str, Any]] = []
        _global_anchor = list(partition_filters or [])
        _branch_counts: List[int] = []
        for _idx, _branch in enumerate(_dd.branches):
            _combined = _global_anchor + list(_branch or [])
            try:
                _branch_files = get_iceberg_data_files(
                    s3_client, bucket, table_prefix,
                    partition_filters=_combined,
                    keys_only=keys_only, max_files=0,
                    metadata=metadata, _out_meta=_out_meta,
                    force_fresh=force_fresh, snapshot_id=snapshot_id,
                    as_of_timestamp_ms=as_of_timestamp_ms,
                    max_rows=0,
                    enforce_max_files_cap=False,
                    connection_id=connection_id,
                    table_name=table_name,
                    db_manager=db_manager,
                    or_groups=None,           # collapse recursion
                    # 2026-06-04 audit fix — must propagate file_order
                    # AND join_key_columns through the OR-branch
                    # recursive calls; were dropped before so OR queries
                    # silently lost scan-strategy ordering + JoinPruner.
                    file_order=file_order,
                    join_key_columns=join_key_columns,
                )
            except Exception as _br_exc:
                # Fail-OPEN: any branch failure degrades to "include
                # all files" so we never lose correctness.  Log loudly
                # so ops can see the regression.
                logger.warning(
                    "BF-549 OR-branch %d scan failed (%s) — falling back "
                    "to global scan",
                    _idx, _br_exc,
                )
                # Fall back to non-OR scan.
                return get_iceberg_data_files(
                    s3_client, bucket, table_prefix,
                    partition_filters=partition_filters,
                    keys_only=keys_only, max_files=max_files,
                    metadata=metadata, _out_meta=_out_meta,
                    force_fresh=force_fresh, snapshot_id=snapshot_id,
                    as_of_timestamp_ms=as_of_timestamp_ms,
                    max_rows=max_rows,
                    enforce_max_files_cap=enforce_max_files_cap,
                    connection_id=connection_id,
                    table_name=table_name,
                    db_manager=db_manager,
                    or_groups=None,
                    # 2026-06-04 audit fix — propagate ordering + JoinPruner.
                    file_order=file_order,
                    join_key_columns=join_key_columns,
                )
            _branch_counts.append(len(_branch_files or []))
            for _f in _branch_files:
                _k = _f.get("key") or _f.get("path") or ""
                if _k and _k not in _union_keys:
                    _union_keys.add(_k)
                    _union_files.append(_f)
        logger.info(
            "[island] %s: disjunction UNION -- %d branch(es) %s -> %d unique "
            "file(s)", table_prefix, _dd.n_branches, _branch_counts,
            len(_union_files))
        if _out_meta is not None and isinstance(_out_meta.get("disjunction"), dict):
            _out_meta["disjunction"]["branch_files"] = list(_branch_counts)
            _out_meta["disjunction"]["union_files"] = len(_union_files)
        # SCAN-STRATEGY (2026-06-01): post-union ordering is now driven by
        # the caller-supplied ``file_order`` (or the admin-default).  The
        # legacy BF-535 hard-coded smallest-first sort was removed because
        # full-scan callers (feed gen, reports) got stuck with the largest
        # file as a tail-end straggler.
        try:
            _union_files = _apply_scan_order(_union_files, file_order)
        except Exception as _post_sort_exc:
            logger.debug(
                "BF-549 post-union ordering failed: %s", _post_sort_exc)
        # 2026-10-08 -- the branch calls above are NESTED reader calls
        # (they share this call's observation and record nothing on their
        # own); the union is what this query read.
        _observe_road("or_groups_union", files_after=len(_union_files),
                      or_branches=len(or_groups))
        if max_files > 0 and len(_union_files) > max_files:
            _union_files = _union_files[:max_files]
        return _union_files

    # ── BF-510 (2026-05-28): optional pyiceberg-based pruning ─────────────────
    # Strategic exit from the BF-498..509 hand-rolled bug chain.  When the
    # ``iceberg.use_pyiceberg`` config flag is on (default false during
    # rollout), delegate the manifest walk + pruning + type/transform
    # handling to the official Apache pyiceberg library.  pyiceberg's
    # native ``BoundPredicate.eval`` + ``Transform.project`` handle
    # date-vs-timestamp, bucket(N), truncate(W), partition-spec evolution,
    # and field-id-based schema evolution natively — every bug class we
    # patched manually in BF-498..509 is eliminated at the source.
    #
    # Caching/freshness contract preserved: the caller's ICE_FILE_CACHE
    # still wraps this function; we still resolved meta_key via the BF-503/
    # 507-verified ``_latest_metadata_key`` path; pre-loaded metadata
    # (``metadata is not None``) still falls through to the hand-rolled
    # path because pyiceberg needs a metadata.json URI it can re-fetch.
    #
    # On equality-delete tables (apache/iceberg-python#1210 unsupported in
    # 0.11.1), fall back to hand-rolled — never silently fail.
    _use_pyice = False
    if metadata is not None and 'meta_key' in dir():
        try:
            from core.config import get as _cfg_get
            _use_pyice = bool(_cfg_get("iceberg", "use_pyiceberg", False))
        except Exception:
            _use_pyice = False
    # Only the standard call path qualifies — pre-loaded metadata case
    # is the one branch (above) that doesn't carry a meta_key we could
    # hand to StaticTable.from_metadata.
    _ran_pyice = False
    if _use_pyice and meta_key_display != "(pre-loaded)":
        try:
            from core.iceberg_pyiceberg_reader import (
                get_iceberg_data_files_via_pyiceberg as _pyice_run,
                PyIcebergEqualityDeleteUnsupportedError as _PyiceDelErr,
            )
            try:
                _pyice_result = _pyice_run(
                    s3_client,
                    bucket,
                    table_prefix,
                    meta_key,
                    partition_filters=partition_filters,
                    keys_only=keys_only,
                    max_files=max_files,
                    snapshot_id=snapshot_id,
                    # BF-600f (2026-05-31): supplement-bounds bridge —
                    # pyiceberg's BoundPredicate.eval handles manifest
                    # bounds but not QS's supplement table, so the
                    # supplement column-stats pruning was silently
                    # skipped on the pyiceberg path.  Pass db_manager
                    # so the path can do the same supplement filter
                    # the hand-rolled path does at iceberg_reader.py:3898.
                    db_manager=db_manager,
                    # JOIN-PRUNER (2026-06-01) — thread through so
                    # ``iceberg.use_pyiceberg=true`` deployments get
                    # the same dynamic semi-join pruning the hand-rolled
                    # path does.  Without these two kwargs, the pyiceberg
                    # path silently no-ops JoinPruner.
                    join_key_columns=join_key_columns,
                    _out_meta=_out_meta,
                )
                _ran_pyice = True
                logger.info(
                    "BF-510 pyiceberg path returned %d files for %s (filters=%d)",
                    len(_pyice_result), table_prefix,
                    len(partition_filters or []),
                )
                # Phase 156 -- memo POPULATE via module-level helper.
                # pyiceberg path runs BEFORE the main snapshot-resolve
                # block so we read the snapshot from _out_meta (the
                # pyiceberg call stamps it there).
                _pyice_snap = (_out_meta or {}).get("snapshot_id") if isinstance(_out_meta, dict) else None
                _phase156_memo_populate(
                    sql_hash=sql_hash,
                    snapshot_id=_pyice_snap,
                    bucket=bucket, table_prefix=table_prefix,
                    surviving_files=_pyice_result,
                    db_manager=db_manager,
                    join_key_columns=join_key_columns,
                    force_fresh=force_fresh,
                )
                if _pyice_result or not partition_filters:
                    # 2026-10-08 -- pyiceberg does not count what it
                    # considered: files_before stays unknown (NULL).
                    _observe_road("pyiceberg", files_after=len(_pyice_result),
                                  snapshot_id=_pyice_snap)
                    return _pyice_result
                # 2026-09-28 -- a 0-file answer this route cannot prove
                # (no gate saw its drops) falls through to the hand-rolled
                # reader, whose funnel is gated and re-proves itself.
                logger.warning(
                    "BF-510: pyiceberg pruned %s to 0 files -- UNPROVEN "
                    "(its drops are not gated); falling through to the "
                    "hand-rolled reader", table_prefix)
            except _PyiceDelErr as _del_exc:
                # Fall through to hand-rolled path — does the same thing
                # the hand-rolled path would have done (returns data files,
                # ignores deletes — pre-v2-delete behaviour).
                logger.warning(
                    "BF-510: pyiceberg refused v2 equality deletes for %s — "
                    "falling back to hand-rolled reader: %s",
                    table_prefix, _del_exc,
                )
            except Exception as _pyice_exc:
                # Any other pyiceberg failure: log + fall through.
                # Better to serve possibly-stale-pruned data than to
                # break a user query that the old path can still handle.
                logger.warning(
                    "BF-510: pyiceberg path failed for %s (fail-open to "
                    "hand-rolled path): %s", table_prefix, _pyice_exc,
                )
        except ImportError as _imp_exc:
            logger.warning(
                "BF-510: pyiceberg not installed but use_pyiceberg=true; "
                "falling back to hand-rolled. Install with `pip install "
                "pyiceberg`. (%s)", _imp_exc,
            )

    # Phase 139 audit-fix Gap 6: resolve effective snapshot
    if snapshot_id is not None and as_of_timestamp_ms is not None:
        raise ValueError(
            "Cannot specify both snapshot_id and as_of_timestamp_ms. Pick one."
        )
    effective_snapshot_id = metadata.get("current-snapshot-id", -1)
    if as_of_timestamp_ms is not None:
        resolved = find_snapshot_at_timestamp(metadata, as_of_timestamp_ms)
        if resolved is None:
            raise ValueError(
                f"No snapshot found at or before timestamp_ms={as_of_timestamp_ms} "
                f"for table {table_prefix}"
            )
        effective_snapshot_id = resolved
        logger.info("Time-travel: as_of_ts=%d → snapshot_id=%s",
                    as_of_timestamp_ms, effective_snapshot_id)
    elif snapshot_id is not None:
        effective_snapshot_id = snapshot_id
        logger.info("Time-travel: explicit snapshot_id=%s", effective_snapshot_id)

    if effective_snapshot_id in (-1, None):
        logger.warning("Table %s has no current snapshot — returning empty", table_prefix)
        # 2026-10-08 -- a table with no snapshot has NO data files: 0 is
        # the true count here, not an unknown.
        _observe_road("no_snapshot", files_before=0, files_after=0)
        return []

    # 2026-07-15 DIAGNOSTIC: log the resolved snapshot + its DECLARED file /
    # record counts (from the snapshot summary in metadata.json) so operators
    # can compare directly against another engine.  "QS 1640 files vs Starburst
    # 1088" almost always means the two engines are on DIFFERENT snapshots —
    # e.g. QS served a cached metadata pointer from BEFORE a compaction that
    # merged many small files into fewer large ones.  total-data-files here is
    # the ground truth for "how many files does the snapshot QS is reading
    # actually contain" — independent of WHERE-clause pruning.
    try:
        _snap_obj = None
        for _s in (metadata.get("snapshots") or []):
            if _s.get("snapshot-id") == effective_snapshot_id:
                _snap_obj = _s
                break
        _snap_sum = (_snap_obj or {}).get("summary") or {}
        logger.info(
            "Iceberg table %s: reading snapshot=%s — declared total-data-files=%s, "
            "total-delete-files=%s, total-records=%s, snapshot-ts-ms=%s. Compare "
            "total-data-files with the engine you're diffing against; a mismatch "
            "means different snapshots (stale metadata pointer / recent compaction), "
            "NOT a pruning bug.",
            table_prefix, effective_snapshot_id,
            _snap_sum.get("total-data-files"), _snap_sum.get("total-delete-files"),
            _snap_sum.get("total-records"), (_snap_obj or {}).get("timestamp-ms"),
        )
        if _out_meta is not None:
            _out_meta["snapshot_total_data_files"] = _snap_sum.get("total-data-files")
            _out_meta["snapshot_total_delete_files"] = _snap_sum.get("total-delete-files")
    except Exception as _snap_log_exc:
        logger.debug("snapshot summary diagnostic log failed: %s", _snap_log_exc)

    # Phase 104: export snapshot_id to caller for cache fingerprinting
    if _out_meta is not None:
        _out_meta["snapshot_id"] = str(effective_snapshot_id)
        # BF-PRUNE-PERF / Option 2: export the current Iceberg schema
        # (column names + types) so the caller can pass an explicit
        # column projection to read_parquet, eliminating DuckDB's need
        # to read a footer for schema discovery.
        try:
            _cur_schema_id = metadata.get("current-schema-id")
            _schemas = metadata.get("schemas") or []
            _cur_schema = next(
                (s for s in _schemas if s.get("schema-id") == _cur_schema_id),
                _schemas[0] if _schemas else None,
            )
            if _cur_schema:
                _fields_out = []
                for _f in _cur_schema.get("fields") or []:
                    _name = _f.get("name")
                    _type = _f.get("type")
                    if _name:
                        # Iceberg type may be a dict (struct/list/map) or
                        # a simple string ("int", "string", "decimal(p,s)").
                        # Pass through as-is; duckdb_views will map to a
                        # DuckDB type when emitting the SELECT projection.
                        _fields_out.append({"name": _name, "type": _type})
                if _fields_out:
                    _out_meta["iceberg_schema"] = _fields_out

            # ── Schema-evolution auto-detection ─────────────────────
            # When a table's metadata.json carries multiple schema
            # entries with differing field-id sets, columns have been
            # added or dropped over time.  Old data files still on S3
            # were written under an older schema, so DuckDB's CREATE
            # VIEW needs union_by_name=true to read across them.
            # We export this as a hint; duckdb_views ORs it with the
            # config flag so:
            #   * uniform-schema tables (default) → fast path
            #   * schema-evolved tables           → safe path (auto)
            #   * config flag forced true         → safe path (manual)
            # Iceberg metadata is cached + reconciled by BF-296/298/299
            # background sync, so this check is essentially free.
            _evolution = False
            if len(_schemas) > 1 and _cur_schema:
                _cur_fids = {f.get("id") for f in (_cur_schema.get("fields") or [])
                              if f.get("id") is not None}
                for _s in _schemas:
                    if _s is _cur_schema:
                        continue
                    _other_fids = {f.get("id") for f in (_s.get("fields") or [])
                                    if f.get("id") is not None}
                    if _cur_fids != _other_fids:
                        _evolution = True
                        break
            _out_meta["iceberg_schema_evolution"] = _evolution
            # TYPE-conflict signal (a field-id whose TYPE changed across schemas)
            # — the specific shape that segfaults DuckDB 1.5.3 under
            # union_by_name=true.  Consumed by setup_registered_views to decide
            # whether union_by_name can be enabled at all.
            try:
                # Compute UNCONDITIONALLY (cheap, no I/O) so the union_by_name
                # gate protects even a type-only conflict an admin force-enabled
                # union_by_name on.
                _out_meta["iceberg_schema_type_conflict"] = bool(
                    detect_iceberg_type_conflicts(metadata))
            except Exception:
                _out_meta["iceberg_schema_type_conflict"] = _evolution
            # 2026-09-25 -- the READ PLAN inputs (current schema with
            # field-ids, identity partition source field-ids, type-conflict
            # flag).  Per-file column presence is filled in after the
            # survivor loop below; `core.iceberg_read_plan.plan_iceberg_read`
            # decides from these whether partition values may be taken from
            # the data files (hive_partitioning=false) instead of the path.
            # Absent/None keeps today's hive-path read.
            try:
                from core.iceberg_read_plan import (
                    read_plan_inputs_from_metadata as _rp_inputs,
                    META_KEY as _RP_META_KEY,
                )
                _rp_in = _rp_inputs(metadata)
                if _rp_in is not None:
                    _out_meta[_RP_META_KEY] = _rp_in
            except Exception as _rp_exc:
                logger.debug("iceberg_read_plan inputs export failed (hive-path "
                             "read keeps today's behaviour): %s", _rp_exc)
            if _evolution:
                logger.info(
                    "Iceberg %s: schema evolution detected (%d schemas in "
                    "metadata.json) — DuckDB CREATE VIEW will use "
                    "union_by_name=true for this table to read files "
                    "written under older schemas.",
                    table_prefix, len(_schemas),
                )
        except Exception as _sch_exc:
            logger.debug("BF-PRUNE-PERF: iceberg_schema export failed: %s", _sch_exc)

    snapshots = {s.get("snapshot-id"): s for s in metadata.get("snapshots", []) if s.get("snapshot-id") is not None}
    snapshot = snapshots.get(effective_snapshot_id)
    if snapshot is None and snapshot_id is not None:
        # Explicit user-requested snapshot not found
        raise ValueError(
            f"Snapshot {snapshot_id} not found in table {table_prefix}. "
            f"Available: {sorted(snapshots.keys())[:10]}{'...' if len(snapshots)>10 else ''}"
        )
    # Re-bind the variable name used below
    current_snapshot_id = effective_snapshot_id
    if not snapshot:
        raise ValueError(
            f"Snapshot {current_snapshot_id} not found in {meta_key_display}"
        )

    # ── Phase 3 (industrialization) — Query Passport at PLAN time ───────
    # The snapshot is PINNED right above (read exactly once; every later
    # step uses this id), so this is the plan-time chokepoint: estimate
    # the island from the db-first per-file store (PURE DB, no S3) and
    # stamp it on _out_meta + the passport registry for the job row.
    # Flag-gated (industrialization.passport_enabled, default OFF) and
    # fail-open — one flag read and out when OFF.  or_groups recursion is
    # skipped (same rule as memo/db-first): a per-branch island estimate
    # must not masquerade as the whole (union) query's passport.
    if not or_groups:
        _phase3_issue_passport(
            db_manager, metadata, bucket, table_prefix, current_snapshot_id,
            partition_filters, sql_hash, _out_meta)

    # ── Phase 156 (2026-06-25) brain pruning memo CONSULT ───────────────
    # Memo is consulted ONCE here (post-snapshot-resolution, pre-
    # manifest-walk).  On hit we still run the CHEAP post-prune
    # operations -- file_order, max_files cap, mirror routing,
    # _out_meta stamps -- so the cached path behaves identically
    # to the first click except for the saved manifest walk.
    # Populate is done by the module-level _phase156_memo_populate
    # helper from EVERY return path so a query reaching any branch
    # still leaves a memo for the next identical request.
    # 2026-07-15 — skip the memo shortcut ONLY for a snapshot that actually has
    # row-level deletes while MoR is enabled: the memo returns a bare
    # surviving-files list WITHOUT the pos/eq delete files, so a memo HIT would
    # build a delete-blind view → silent COUNT overcount on V2 tables.  Running
    # the full resolve then guarantees Step-4a delete collection populates
    # _out_meta.  Snapshots with NO deletes (the common case) keep the memo, so
    # this is correctness-only, not a blanket perf regression.  Absence of the
    # summary delete counters means zero deletes (same assumption the db-first
    # delete guard makes below); any error → assume deletes → skip (fail-safe).
    _mor_skip_memo = False
    try:
        from core.iceberg_mor import is_mor_enabled as _ime_memo
        if _ime_memo() and _snapshot_has_row_deletes(metadata, current_snapshot_id, s3_client, bucket):
            _mor_skip_memo = True
    except Exception:
        _mor_skip_memo = False
    if (sql_hash and not force_fresh and db_manager is not None
            and bucket and table_prefix and current_snapshot_id):
        try:
            from core.brain_pruning_memo import get_memo as _bm_get
            _row = _bm_get(
                sql_hash, str(current_snapshot_id),
                bucket=bucket, table_prefix=table_prefix,
                db_manager=db_manager,
            )
            # F4 (2026-08-22): join queries and MoR snapshots are no
            # longer memo-BLIND — the gate moved from the QUERY SHAPE to
            # the RECORD.  A record is replayable for this query iff it
            # carries what the query needs: join_key_bounds when the
            # caller wants join pruning; the pos/eq delete-file lists
            # when the snapshot has row-level deletes.  A record that
            # cannot prove it (pre-F4 rows included) is a MISS for that
            # shape — recompute, exactly as before.
            _row_sm = (_row or {}).get("scan_meta") or {}
            _replay_refused = None
            if _row and join_key_columns and "join_key_bounds" not in _row_sm:
                _replay_refused = "join_query_record_lacks_bounds"
            if _row and _mor_skip_memo and not (
                    "pos_delete_files" in _row_sm
                    and "eq_delete_files" in _row_sm):
                _replay_refused = "mor_record_lacks_delete_files"
            if _replay_refused:
                logger.info(
                    "[brain-memo] record for %s/%s snap=%s cannot serve "
                    "this query shape (%s) — recomputing.",
                    bucket, table_prefix, current_snapshot_id,
                    _replay_refused)
                _row = None
            if _row and _row.get("surviving_files"):
                _files = list(_row.get("surviving_files") or [])
                _norm_files: List[Dict[str, Any]] = []
                for _f in _files:
                    if isinstance(_f, dict):
                        _norm_files.append(_f)
                    elif isinstance(_f, str):
                        _norm_files.append({
                            "key":          _f,
                            "path":         _f,
                            "size_bytes":   0,
                            # 2026-10-08 -- no count stored = UNKNOWN; a 0
                            # here reads as "holds nothing" to the LIMIT
                            # early stop and would skip a file that has rows.
                        })
                if _norm_files:
                    # 2026-10-08 -- the memo's surviving list IS the pruned
                    # source count (before the max_files cap and the
                    # mirror swap below); files_before = the snapshot's
                    # declared total, resolved by the recorder.
                    _observe_road("memo", files_after=len(_norm_files),
                                  snapshot_id=current_snapshot_id)
                    # Apply the CHEAP post-prune operations so the
                    # cached path doesn't silently degrade caller
                    # expectations.
                    try:
                        _norm_files = _apply_scan_order(_norm_files, file_order)
                    except Exception as _so_exc:
                        logger.debug(
                            "[brain-memo] file_order on cached path "
                            "failed (fail-open): %s", _so_exc,
                        )
                    if max_files and max_files > 0 and len(_norm_files) > max_files:
                        _norm_files = _norm_files[:max_files]
                    # Mirror routing on the cached list.  Same swap
                    # semantics as fresh path -- routing engine reads
                    # mirror_metadata + flips files when engaged.
                    try:
                        _norm_files = _apply_read_substitutions(
                            db_manager=db_manager,
                            metadata=metadata,
                            bucket=bucket,
                            table_prefix=table_prefix,
                            snapshot_id=current_snapshot_id,
                            source_files=_norm_files,
                            _out_meta=_out_meta,
                        )
                    except Exception as _mr_exc:
                        logger.debug(
                            "[brain-memo] mirror_route on cached path "
                            "failed (fail-open): %s", _mr_exc,
                        )
                    _seek_route = "memo"
                    if isinstance(_out_meta, dict):
                        _out_meta["snapshot_id"] = str(current_snapshot_id)
                        _out_meta["brain_memo_hit"] = True
                        _out_meta["brain_memo_files"] = len(_norm_files)
                        _out_meta["seek_route"] = _seek_route
                        # F4 — restore what the walk would have stamped:
                        # the JoinPruner bounds, the MoR delete lists and
                        # the completeness attestation, exactly as stored.
                        for _sm_k in ("join_key_bounds",
                                      "join_key_distinct_values",
                                      "file_enumeration_complete",
                                      "pos_delete_files",
                                      "eq_delete_files"):
                            if _sm_k in _row_sm:
                                _out_meta[_sm_k] = _row_sm[_sm_k]
                    logger.info(
                        "[brain-memo] HIT for table=%s/%s sql_hash=%s "
                        "snapshot=%s -- returning %d cached files "
                        "(skipped manifest+supplement+bloom prune; "
                        "scan_order + max_files + mirror_route applied)",
                        bucket, table_prefix, sql_hash[:8],
                        current_snapshot_id, len(_norm_files),
                    )
                    # Phase 0 — this return path never reaches the QS-SCAN
                    # block, so its verdict line is emitted HERE.  The
                    # instrument must exist on every route, not just the walk.
                    logger.info(
                        "[seek] %s seek_route=memo entries_decoded=0 "
                        "s3_gets=%d files=%d",
                        table_prefix, _s3_ctr.value - _s3_gets_at_entry,
                        len(_norm_files),
                    )
                    return _norm_files
        except Exception as _bm_exc:
            logger.debug(
                "[brain-memo] consult failed (fail-open, run prune): %s",
                _bm_exc,
            )

    # ── Phase B+D (2026-06-08) DB-FIRST PRUNING BRAIN ─────────────────────────
    # The brain has 3 cache layers -- L1 in-process / L2 DB supplement / L3 S3.
    # When L2 is fresh for THIS snapshot, ``prune_files_with_brain`` applies
    # the WHERE-clause filters using supplement bounds with PARTITION-AWARE
    # semantics + type coercion + JOIN-key bounds aggregation, skipping the
    # manifest_list + manifest avro reads entirely (the slowest stage on
    # cold-cache scans behind a corporate proxy).
    #
    # Engages when:
    #   * db_manager available (otherwise no L2)
    #   * QS_USE_DB_FIRST_PRUNING=true (env opt-in until production-proven)
    #   * not an or_groups recursion (parent caller handles unions)
    #   * is_fresh() returns True (MAX(scanned_at) within window)
    #
    # Fails OPEN at every step: any coercion failure / unsupported op /
    # DB error -> ``surviving_files=None`` -> fall back to manifest walk.
    if db_manager is not None and not or_groups:
        try:
            from core.iceberg_db_first_reader import (
                is_db_first_enabled as _dbf_enabled,
                is_fresh as _dbf_fresh,
                is_complete as _dbf_is_complete,
                columns_fully_covered as _dbf_cols_covered,
                get_all_file_paths as _dbf_all_paths,
                prune_files_with_brain as _dbf_brain,
                record_outcome as _dbf_record,
                _outcome_category as _dbf_cat,
            )
            if _dbf_enabled():
                _dbf_snap = str(current_snapshot_id)
                _dbf_session = lambda: db_manager.get_session(read_only=True)
                # ── Completeness guard input (2026-07-12) ─────────────────
                # The snapshot's authoritative data-file count (from the
                # metadata.json snapshot summary — already in memory, no S3).
                # Used by _dbf_is_complete to prove the supplement covers
                # EVERY file before we trust it; None => unverifiable => S3.
                _dbf_expected_total: Optional[int] = None
                try:
                    _dbf_snap_obj = next(
                        (s for s in metadata.get("snapshots", [])
                         if s.get("snapshot-id") == current_snapshot_id),
                        None,
                    )
                    if _dbf_snap_obj:
                        _tdf = (_dbf_snap_obj.get("summary") or {}).get(
                            "total-data-files")
                        if _tdf is not None:
                            _dbf_expected_total = int(_tdf)
                except Exception as _tdf_exc:
                    logger.debug(
                        "[db_first] total-data-files extract failed: %s",
                        _tdf_exc)
                # AUDIT FIX (Finding 3, 2026-07-13): DELETE-file guard.  The
                # db-first path returns ONLY the data-file list and returns
                # BEFORE Step 4a (which collects V2 merge-on-read position/
                # equality delete files into _out_meta for a delete-aware
                # view).  If this snapshot has row-level deletes, serving the
                # data files alone would surface DELETED rows → wrong results.
                # Skip db-first (fall through to the MoR-aware S3 manifest walk)
                # whenever the snapshot has delete files.  Detection is
                # AUTHORITATIVE — summary counters when the writer records them,
                # else the manifest-list content==1 check — so a writer that omits
                # the counters can't slip a delete-blind result past db-first.
                _dbf_has_deletes = _snapshot_has_row_deletes(
                    metadata, _dbf_snap, s3_client, bucket)
                if _dbf_has_deletes:
                    logger.info(
                        "[db_first] snapshot %s has row-level DELETE files -- "
                        "skipping db-first, using S3 manifest walk (MoR-aware) "
                        "for %s/%s", _dbf_snap, bucket, table_prefix)
                # Engage ONLY when the supplement is fresh AND provably
                # complete for this snapshot AND the snapshot has no row-level
                # deletes.  Any check False → fall through to the S3 manifest
                # walk below (never drops files, never surfaces deleted rows).
                _dbf_fresh_ok = (not _dbf_has_deletes) and _dbf_fresh(
                    _dbf_session, bucket, table_prefix, _dbf_snap)
                _dbf_complete_ok = _dbf_fresh_ok and _dbf_is_complete(
                    _dbf_session, bucket, table_prefix, _dbf_snap,
                    _dbf_expected_total)
                if not _dbf_complete_ok:
                    # CONTROL (2026-07-13): record WHY db-first didn't engage
                    # so operators can monitor cache health.  A rising
                    # ``incomplete`` count means the column-stats scanner is
                    # behind for these snapshots — queries stay CORRECT (served
                    # from S3), just not accelerated until the supplement fills.
                    _dbf_gate_reason = (
                        "has_deletes" if _dbf_has_deletes
                        else "not_fresh" if not _dbf_fresh_ok
                        else "incomplete")
                    _dbf_record("fallthrough:" + _dbf_gate_reason)
                    # 2026-09-01, reported as "db first is alwsz skipped":
                    # the reason was computed here, counted, stashed in
                    # _out_meta -- and never logged.  Only ``has_deletes``
                    # had a line of its own, so the two ordinary reasons
                    # (stale supplement, incomplete supplement) left no trace
                    # at all and the operator could only observe the SYMPTOM:
                    # a slow query walking S3.
                    #
                    # This is the same shape as the [island] line added on
                    # 2026-08-21 -- the system logged what it DID and never
                    # what it DECLINED to do.  Unconditional and at INFO,
                    # because a diagnostic that needs DEBUG turned on is not
                    # available at the moment it is needed, and one line per
                    # query is nothing next to the S3 walk it is explaining.
                    logger.info(
                        "[db_first] SKIPPED for %s/%s snapshot=%s reason=%s "
                        "-- falling back to the S3 manifest walk (correct, "
                        "just not accelerated)",
                        bucket, table_prefix, _dbf_snap, _dbf_gate_reason)
                    if _out_meta is not None:
                        _out_meta.setdefault(
                            "db_first_decision",
                            "fallthrough:" + _dbf_gate_reason)
                if _dbf_complete_ok:
                    # ── Build the inputs the brain needs ──────────────
                    # Partition columns from the iceberg partition_spec
                    # (the SAME source the manifest path uses below, so
                    # the brain stays in lockstep with downstream).
                    _dbf_pspec: Dict[str, str] = {}
                    try:
                        _dbf_pspec = _extract_partition_spec(metadata)
                    except Exception as _ps_exc:
                        logger.debug(
                            "[db_first] _extract_partition_spec failed: %s",
                            _ps_exc)
                    _dbf_part_cols = list(_dbf_pspec.keys())

                    # Iceberg field types -> drives type coercion of filter
                    # values to match what the supplement scanner stored.
                    _dbf_types: Dict[str, str] = {}
                    try:
                        _cur_sid = metadata.get("current-schema-id")
                        _schemas = metadata.get("schemas") or []
                        _cur = next(
                            (s for s in _schemas
                             if s.get("schema-id") == _cur_sid),
                            _schemas[0] if _schemas else None,
                        )
                        if _cur:
                            for _f in _cur.get("fields") or []:
                                _nm = _f.get("name")
                                _tp = _f.get("type")
                                if _nm and isinstance(_tp, str):
                                    _dbf_types[_nm.lower()] = _tp
                                elif _nm and isinstance(_tp, dict):
                                    # struct/list/map -- can't coerce easily;
                                    # brain will skip filters on these.
                                    _dbf_types[_nm.lower()] = _tp.get(
                                        "type", "string")
                        # Inject partition transform types so date/_month/_year
                        # transforms get their physical semantic.
                        # 2026-07-22: a partition field carrying a _transform_
                        # marker (bucket/truncate/day/…) MUST WIN over a same-named
                        # schema column.  With setdefault, a bucket/truncate field
                        # named identically to a real column let the PLAIN schema
                        # type mask the marker, so the db-first guard
                        # (_unsafe_transform_part_cols / join-key _jk_unsafe) never
                        # fired and the pruner did exact partition_eq (lo==hi==v)
                        # on a MULTI-VALUED bucket/truncate file → dropped rows.
                        # Identity partition types equal the schema type, so
                        # overwriting them is a harmless no-op.
                        for _pc, _pt in _dbf_pspec.items():
                            _pk = _pc.lower()
                            if str(_pt).startswith("_transform_"):
                                _dbf_types[_pk] = _pt          # transform wins
                            else:
                                _dbf_types.setdefault(_pk, _pt)  # identity: no-op
                    except Exception as _ft_exc:
                        logger.debug(
                            "[db_first] field types extract failed: %s",
                            _ft_exc)

                    if partition_filters:
                        # PER-COLUMN completeness guard (2026-07-12): the brain
                        # prunes each filter by selecting files that have a
                        # supplement row for that column; a file with NO row for
                        # a filtered column would be silently dropped.  Require
                        # every filtered column to cover all data files, else
                        # fall back to the S3 walk (no silent row loss).
                        #
                        # 2026-07-22: join-key columns are NO LONGER folded into
                        # this ENGAGEMENT gate.  The 2026-07-13 concern (a
                        # join-key file missing from the supplement narrows the
                        # aggregated BETWEEN → over-prunes the joined table) is
                        # handled INDEPENDENTLY, per-key, by _safe_join_key_emit
                        # (iceberg_db_first_reader.py:511-514): the instant ANY
                        # surviving file lacks that join key's stat it returns
                        # (None, None) — emitting NO bound rather than a narrowed
                        # one — so the joined table is simply not pruned on that
                        # key (correct, less selective).  Requiring WHOLE-TABLE
                        # join-key coverage just to ENGAGE db-first needlessly
                        # dropped the accelerated path for the most common
                        # enterprise join (join on the partitioned COB date) →
                        # slow S3 walk on every such query.  Anchor enumeration
                        # depends only on the FILTER columns, which stay fully
                        # guarded here.
                        _dbf_filter_cols = sorted({
                            (f.get("col") or f.get("column") or "")
                            for f in partition_filters
                            if (f.get("col") or f.get("column"))
                        })
                        # Phase 4 (2026-08-22, design_s3_speed §4): under the
                        # v3 (per-FILE) grain the per-COLUMN coverage check is
                        # no longer an ENGAGEMENT gate.  v3's own guards make
                        # it redundant for correctness: the post-load EXACT
                        # count check proves every snapshot file has a stats
                        # row (else it falls through), and a file whose row
                        # lacks THIS column's entry is KEPT per-file
                        # (fail-open) — so an uncovered column simply prunes
                        # nothing, instead of sending the WHOLE query (all
                        # filters, including fully-covered ones) back to the
                        # manifest walk.  Correct as a DROP gate; wrong as an
                        # engagement gate — the same lesson applied to join
                        # keys on 2026-07-22, now applied to filter columns.
                        # v2 keeps the gate: its set-INTERSECTION drops a file
                        # with no supplement row for a filtered column, so
                        # there the gate IS the correctness proof.
                        _dbf_per_file_grain = False
                        try:
                            from core.config import iceberg_file_stats_grain                                 as _dbf_grain_fn
                            _dbf_per_file_grain = (
                                _dbf_grain_fn() == "v3")
                        except Exception as _dbf_grain_exc:
                            logger.debug(
                                "[db_first] grain resolve failed (keeping "
                                "the v2 engagement gate): %s",
                                _dbf_grain_exc)
                        if not _dbf_per_file_grain and not _dbf_cols_covered(
                            _dbf_session, bucket, table_prefix, _dbf_snap,
                            _dbf_filter_cols, _dbf_expected_total,
                        ):
                            _dbf_survivors = None
                            _dbf_cascade = []
                            _dbf_jkbounds = {}
                            _dbf_fell = True
                            _dbf_reason = "per_column_coverage_incomplete"
                        else:
                            _brain = _dbf_brain(
                                _dbf_session, bucket, table_prefix, _dbf_snap,
                                partition_filters=partition_filters,
                                partition_columns=_dbf_part_cols,
                                iceberg_field_types=_dbf_types,
                                join_key_columns=join_key_columns,
                                expected_total_files=_dbf_expected_total,
                            )
                            _dbf_survivors = _brain.surviving_files
                            _dbf_cascade = _brain.cascade
                            _dbf_jkbounds = _brain.join_key_bounds
                            _dbf_jkdistinct = getattr(
                                _brain, "join_key_distinct_values", {}) or {}
                            _dbf_fell = _brain.fell_through
                            _dbf_reason = _brain.fell_through_reason
                    else:
                        _dbf_survivors = _dbf_all_paths(
                            _dbf_session, bucket, table_prefix, _dbf_snap,
                        )
                        _dbf_cascade = []
                        _dbf_jkbounds = {}
                        _dbf_jkdistinct = {}
                        # Phase G: get_all_file_paths returns None on DB
                        # error.  Mark as fell_through so the next
                        # branch logs WHY and falls back to S3.
                        if _dbf_survivors is None:
                            _dbf_fell = True
                            _dbf_reason = "all_paths_db_error"
                        elif _dbf_expected_total is not None and \
                                len(_dbf_survivors) < _dbf_expected_total:
                            # CONTROL (2026-07-13): belt-and-suspenders re-check
                            # on the ACTUAL fetched set (not just the earlier
                            # is_complete COUNT).  Guards a race between the
                            # count and this fetch, or a supplement that lost
                            # rows in between.  If the served set is short of
                            # the snapshot's authoritative file count, do NOT
                            # serve it — fall through to S3.  This is the last
                            # line that guarantees a partially-cached snapshot
                            # can never return an incomplete file list.
                            _dbf_fell = True
                            _dbf_reason = (
                                f"post_fetch_incomplete("
                                f"{len(_dbf_survivors)}/{_dbf_expected_total})")
                        else:
                            _dbf_fell = False
                            _dbf_reason = ""

                    if (_dbf_survivors is not None and not _dbf_fell
                            and not _dbf_survivors and partition_filters):
                        # 2026-09-28 -- an EMPTY survivor set is the one
                        # answer db-first may not serve: this route bypasses
                        # the funnel AND the pruning gate, so nothing can
                        # prove it.  Walk instead (gated, self-proving).
                        _dbf_fell = True
                        _dbf_reason = "empty_survivors_unproven"
                    if _dbf_survivors is not None and not _dbf_fell:
                        logger.info(
                            "[db_first] HIT bucket=%s prefix=%s snap=%s -> "
                            "%d files (skipped manifest walk) cascade=%s",
                            bucket, table_prefix, _dbf_snap,
                            len(_dbf_survivors),
                            [
                                f"{c.column}{c.op}{c.raw_value!r}"
                                f"[{c.semantic}]->{c.files_after}"
                                for c in _dbf_cascade
                            ],
                        )
                        _dbf_files: List[Dict[str, Any]] = []
                        for _fp in sorted(_dbf_survivors):
                            _dbf_files.append({
                                "key":           _fp,
                                "name":          _fp.split("/")[-1],
                                "path":          _fp,
                                "size_bytes":    0,
                                "last_modified": "",
                                "folder":        ("/".join(_fp.split("/")[:-1]) + "/")
                                                 if "/" in _fp else "",
                                "type":          "parquet",
                            })
                        # 2026-10-08 (pruning proof P20) -- export the per-file
                        # record counts the store KNOWS.  Without them the
                        # LIMIT-only early stop declined on this, the
                        # commonest road ("a file's record count is unknown")
                        # and `select * from fact_tetb limit 100` read all
                        # 2,688 files.  A count the store lacks stays ABSENT
                        # (unknown; the early stop declines), never 0.
                        _dbf_counts = None
                        try:
                            from core.iceberg_db_first_reader import (
                                get_file_row_counts as _dbf_row_counts)
                            _dbf_counts = _dbf_row_counts(
                                _dbf_session, bucket, table_prefix, _dbf_snap,
                                [_f["key"] for _f in _dbf_files])
                        except Exception as _dbf_rc_exc:              # noqa: BLE001
                            logger.warning(
                                "[db_first] per-file record counts not served "
                                "for %s/%s: %s", bucket, table_prefix, _dbf_rc_exc)
                        _dbf_counts_known = 0
                        if _dbf_counts:
                            for _f in _dbf_files:
                                _rc_known = _dbf_counts.get(_f["key"])
                                if _rc_known is not None:
                                    _f["record_count"] = int(_rc_known)
                                    _dbf_counts_known += 1
                        logger.info(
                            "[db_first] record counts known for %d of %d served "
                            "file(s)%s", _dbf_counts_known, len(_dbf_files),
                            "" if _dbf_counts_known == len(_dbf_files) else
                            " -- a LIMIT-only early stop will decline")
                        if not keys_only and _dbf_files:
                            try:
                                _dbf_meta = _batch_s3_metadata(
                                    s3_client, bucket,
                                    [f["key"] for f in _dbf_files],
                                )
                                for _f in _dbf_files:
                                    _m = _dbf_meta.get(_f["key"], {})
                                    _f["size_bytes"] = _m.get("size_bytes", 0)
                                    _f["last_modified"] = _m.get(
                                        "last_modified", "")
                            except Exception as _meta_exc:
                                logger.warning(
                                    "[db_first] _batch_s3_metadata enrich "
                                    "failed (serving size-less): %s",
                                    _meta_exc,
                                )
                        try:
                            _dbf_files = _apply_scan_order(_dbf_files, file_order)
                        except Exception as _so_exc:
                            logger.debug(
                                "[db_first] _apply_scan_order failed: %s",
                                _so_exc)
                        # 2026-07-15 (audit finding #6) — completeness
                        # attestation, computed BEFORE any max_files slice.
                        # The db-first served set is complete by its own
                        # guards (is_complete + per-column coverage +
                        # post-fetch count re-check); the ONLY way it can
                        # be a prefix is the max_files truncation below.
                        # 2026-10-08 -- the served set is the pruned source
                        # count (before the max_files slice and the mirror
                        # swap); files_before = the snapshot's declared total.
                        _observe_road("db_first", files_after=len(_dbf_files),
                                      snapshot_id=_dbf_snap)
                        _dbf_enum_complete = not (
                            max_files > 0 and len(_dbf_files) > max_files)
                        if max_files > 0 and len(_dbf_files) > max_files:
                            _dbf_files = _dbf_files[:max_files]
                        _dbf_record("hit")
                        # Logged as deliberately as the skip.  With only one
                        # of the two lines, "no [db_first] line" would mean
                        # both "it worked" and "this build predates the
                        # logging" -- and an operator cannot tell those apart.
                        logger.info(
                            "[db_first] ENGAGED for %s/%s snapshot=%s -- "
                            "%d file(s) served from the supplement, no S3 "
                            "manifest walk",
                            bucket, table_prefix, _dbf_snap, len(_dbf_files))
                        if _out_meta is not None:
                            _out_meta["file_enumeration_complete"] = _dbf_enum_complete
                            _out_meta["db_first_hit"] = True
                            _out_meta["db_first_decision"] = "hit"
                            _out_meta["files_after_prune"] = len(_dbf_files)
                            _out_meta["pruning_source"] = "db_first"
                            _out_meta["db_first_cascade"] = [
                                {
                                    "column":         c.column,
                                    "op":             c.op,
                                    "raw_value":      c.raw_value,
                                    "coerced_value":  c.coerced_value,
                                    "semantic":       c.semantic,
                                    "files_after":    c.files_after,
                                    "status":         c.status,
                                }
                                for c in _dbf_cascade
                            ]
                            # JOIN-PRUNER bridge: feed the brain's bounds
                            # aggregation into the same _out_meta key the
                            # manifest path uses.  Joined tables sharing
                            # the partition key (e.g. business_close_date)
                            # get a BETWEEN-pushdown without us walking
                            # manifests.
                            # F4 (2026-08-22): stamped UNCONDITIONALLY when
                            # the caller asked for join keys (may be {}) —
                            # presence == "the aggregation ran", which is
                            # the memo populate's proof-of-computation.
                            if join_key_columns or _dbf_jkbounds:
                                _out_meta["join_key_bounds"] = {
                                    k: v for k, v in _dbf_jkbounds.items()
                                }
                            # 2026-07-14 — also surface the complete-by-
                            # construction IN-list (equality set) so the
                            # JoinPruner prefers it over an ambiguous BETWEEN.
                            # This is what lets a numeric-string partition key
                            # prune the joined table SAFELY (IN = equality,
                            # collation-independent) instead of collapsing it
                            # to one file via a lexicographic BETWEEN.
                            if _dbf_jkdistinct:
                                _out_meta["join_key_distinct_values"] = {
                                    k: list(v) for k, v in _dbf_jkdistinct.items()
                                }
                        # Phase 8 + Phase 150 — reader substitution at
                        # DB-first return point.  Fail-OPEN: source list
                        # preserved on any error.
                        _dbf_files = _apply_read_substitutions(
                            db_manager=db_manager,
                            metadata=metadata,
                            bucket=bucket,
                            table_prefix=table_prefix,
                            snapshot_id=_dbf_snap,
                            source_files=_dbf_files,
                            _out_meta=_out_meta,
                        )
                        # Phase 156 -- memo POPULATE via module-level
                        # helper.  _dbf_snap is the snapshot the L2
                        # path matched against.
                        _phase156_memo_populate(
                            sql_hash=sql_hash,
                            snapshot_id=_dbf_snap,
                            bucket=bucket, table_prefix=table_prefix,
                            surviving_files=_dbf_files,
                            db_manager=db_manager,
                            join_key_columns=join_key_columns,
                            force_fresh=force_fresh,
                            scan_meta=_memo_scan_meta_from_out(_out_meta),
                        )
                        # Phase 0 — early return path: emit the verdict line
                        # here too.  "db_first" is deliberately OUTSIDE the
                        # memo|seek:*|rows:full|walk enum: this route serves
                        # from the per-file supplement store, and labelling it
                        # as any of the others would misreport which store
                        # answered.
                        _seek_route = "db_first"
                        if _out_meta is not None:
                            _out_meta["seek_route"] = _seek_route
                        logger.info(
                            "[seek] %s seek_route=db_first entries_decoded=0 "
                            "s3_gets=%d files=%d",
                            table_prefix, _s3_ctr.value - _s3_gets_at_entry,
                            len(_dbf_files),
                        )
                        return _dbf_files
                    else:
                        _dbf_record("fallthrough:" + _dbf_cat(_dbf_reason))
                        if _out_meta is not None:
                            _out_meta["db_first_decision"] = (
                                "fallthrough:" + (_dbf_reason or "unknown"))
                        logger.info(
                            "[db_first] FELL THROUGH on %s/%s reason=%s -- "
                            "falling back to S3 manifest walk",
                            bucket, table_prefix, _dbf_reason or "unknown",
                        )
                # is_fresh()=False -> fall through; log was emitted by is_fresh.
        except Exception as _dbf_exc:
            try:
                _dbf_record("fallthrough:exception")
            except Exception as _be_exc:
                note_best_effort("_dbf_record('fallthrough:exception')", _be_exc,
                                 logger=logger)
            logger.warning(
                "[db_first] short-circuit failed for %s/%s (falling back to "
                "S3): %s: %s",
                bucket, table_prefix, type(_dbf_exc).__name__, _dbf_exc,
            )

    # ── Step 2: Parse partition spec (needed for pruning) ─────────────────────
    partition_spec: Dict[str, str] = {}
    # ── 2026-07-16 COMPLETENESS CONTROL · Tier 2 — per-table TRUST LEVEL ──
    # Resolve the table's trust mode HERE, where the prune decision is made.
    # ``full_scan`` (opt-in per table, or forced by a Tier-3 quarantine)
    # DISABLES pruning: we drop the filters + join keys so EVERY data file is
    # kept and the query does a provably-correct full scan.  This is the ONLY
    # path that forces a full scan.  Fail-open: any error → default ``fast``
    # and the normal pruning path is untouched.
    _completeness_mode = "fast"
    try:
        from core.completeness_control import resolve_table_mode as _cc_mode
        _completeness_mode = _cc_mode(table_prefix)
        if _completeness_mode == "full_scan":
            # 2026-07-22: the completeness control is OBSERVATIONAL — it records
            # a verdict, it must NEVER alter the result or disable pruning.  The
            # old behaviour here DROPPED the WHERE partition filter (and join
            # keys) and read the whole ocean "to prove completeness" — which is
            # exactly backwards: partition elimination uses the AUTHORITATIVE
            # Iceberg manifest tuples and can never drop a matching row, so there
            # is never a reason to scan beyond the partition(s) the query asks
            # for.  full_scan mode is now purely a LABEL surfaced in the verdict;
            # normal partition-first pruning runs unchanged.
            logger.info(
                "[completeness] table %s flagged full_scan — recorded as a "
                "verdict label only; pruning runs normally (partition-first, "
                "then per-file stats).", table_prefix)
            if _out_meta is not None:
                _out_meta["completeness_mode"] = "full_scan"
    except Exception as _cc_mode_exc:
        logger.debug("[completeness] mode resolve failed (fail-open, fast): %s",
                     _cc_mode_exc)
    use_pruning = bool(partition_filters)
    # Column statistics pushdown — schema index for non-partition column pruning
    _col_stats_fid_to_type: Dict[int, str] = {}
    _col_stats_name_to_fid: Dict[str, int] = {}
    _non_partition_filters: List[Dict[str, Any]] = []
    # JOIN-PRUNER (2026-06-01): build the schema index even when there are
    # no partition_filters, as long as the caller asked for join-key bounds.
    # Without this, anchor tables that don't themselves carry filters
    # (rare but possible — e.g. a primary table that gets filtered solely
    # via JOIN equivalence from a CTE) couldn't surface their column
    # min/max to the join pruner.
    _needs_schema_index = use_pruning or bool(join_key_columns)
    if _needs_schema_index and not use_pruning:
        try:
            _col_stats_fid_to_type, _col_stats_name_to_fid = _build_schema_index(metadata)
        except Exception as _si_exc:
            logger.debug("schema index build (join-pruner path) failed: %s", _si_exc)
    # 2026-06-08 — partition_spec is also needed when caller supplied
    # join_key_columns (even without partition_filters) so JOIN-PRUNER's
    # partition-bounds aggregation can identify which join keys are
    # partition cols.  Without this, anchor reads with no filter +
    # join_key_columns silently emitted no bounds.
    if use_pruning or join_key_columns:
        try:
            partition_spec = _extract_partition_spec(metadata)
            if use_pruning:
                logger.info(
                    "Iceberg partition spec for %s: %s", table_prefix,
                    {k: v for k, v in partition_spec.items()}
                )
        except Exception as exc:
            logger.warning("Could not parse partition spec — pruning disabled: %s", exc)
            use_pruning = False
    if use_pruning:
        try:
            # Build schema field index for column statistics pushdown
            _col_stats_fid_to_type, _col_stats_name_to_fid = _build_schema_index(metadata)
            # BF-252: Apply column-stats pruning to ALL filters, not just
            # non-partition ones.  See git blame for rationale.
            # BF-261: dedupe filters before applying.  BQB's pruning chain
            # injects the same WHERE predicate from multiple sources
            # (caller list + query_config + raw-SQL extractor), so we'd see
            # filters=['business_close_date','code','business_close_date',
            # 'code','code'].  Each duplicate causes a redundant bound check
            # per data file; on 1000+ files this is real cost.  Dedupe by
            # the (col, op, val) tuple — first occurrence wins.
            _seen_filter_keys: set = set()
            _non_partition_filters: List[Dict[str, Any]] = []
            for _f in (partition_filters or []):
                _col_name = (_f.get("col") or _f.get("column") or "").strip().lower()
                _op_name  = (_f.get("op") or _f.get("operator") or "").strip().lower()
                _val      = _f.get("val") if "val" in _f else _f.get("value")
                # Lists/tuples (IN clauses) — convert to a tuple of sorted values
                if isinstance(_val, (list, tuple)):
                    try:
                        _val_key = tuple(sorted(str(v) for v in _val))
                    except Exception:
                        _val_key = tuple(str(v) for v in _val)
                else:
                    _val_key = str(_val)
                _key = (_col_name, _op_name, _val_key)
                if _key in _seen_filter_keys:
                    continue
                _seen_filter_keys.add(_key)
                _non_partition_filters.append(_f)
            _dropped = len((partition_filters or [])) - len(_non_partition_filters)
            # BF-371: defer the with_stats / without_stats log to AFTER the
            # supplement load below — otherwise it reports "no min/max" for
            # columns that ARE actually covered by the supplement table,
            # which has been the user-reported source of confusion.
            # BF-377: strip table prefix when comparing.  Qualified filters
            # like ``a.system_id`` need to match bare ``system_id`` in
            # both manifest stats AND supplement bounds.  Without the
            # split, qualified filters always look like "no min/max"
            # even when stats are present.
            _pruning_summary_dropped = _dropped
            _pruning_summary_manifest_capable: list = []
            _pruning_summary_manifest_missing: list = []
            if _non_partition_filters:
                _manifest_cols_lower = {k.lower() for k in _col_stats_name_to_fid.keys()}
                for _f in _non_partition_filters:
                    _fc = (_f.get("col") or _f.get("column") or "").strip()
                    _fc_bare_lower = _fc.split(".")[-1].lower()  # strip 'a.' prefix
                    if _fc_bare_lower in _manifest_cols_lower:
                        _pruning_summary_manifest_capable.append(_fc)
                    else:
                        _pruning_summary_manifest_missing.append(_fc)
        except Exception as _csi_exc:
            logger.debug("Column stats index build failed (non-fatal): %s", _csi_exc)

    # ── Step 3: Read manifest list ────────────────────────────────────────────
    manifest_list_uri = snapshot.get("manifest-list")
    if manifest_list_uri:
        ml_key = _s3_uri_to_key(manifest_list_uri)
        try:
            manifest_list_data = _read_manifest_list_avro_cached(s3_client, bucket, ml_key)
            manifests = _read_avro(manifest_list_data)
        except Exception as exc:
            raise ValueError(
                f"Failed to read manifest list {ml_key}: {exc}"
            ) from exc
    else:
        manifests = snapshot.get("manifests", [])

    # BF-289 / per-step timing: from here on we're pruning manifest entries
    # against partition spec + column stats.  This is typically the longest
    # step on cold-cache scans (each manifest = one S3 GetObject + Avro
    # decode), so giving it its own stage label makes the execution-history
    # timeline meaningful.
    _signal_stage("manifest_prune",
                   message=f"Pruning {len(manifests)} manifest(s)",
                   files_total=len(manifests) if manifests else None)

    # ── Step 4a: Handle DELETE manifests (Iceberg V2 merge-on-read) ──────────
    # content=0 → DATA manifests; content=1 → DELETE manifests
    # (within DELETE: data_file.content=1 is position-delete, =2 is equality-delete)
    # Phase 139 audit-fix Gap 1: when iceberg_mor.enabled=true, collect delete
    # file metadata into _out_meta so the caller can build a MoR-aware view.
    # Default false preserves the historical "skip deletes" behaviour suitable
    # for append-only ETL pipelines.
    # content may arrive as int (fastavro) or str (some metadata paths) -> coerce
    # so a "1"/"0" string can't misclassify a delete manifest as data (F7).
    def _mc(m):
        try:
            return int(m.get("content", 0) or 0)
        except (TypeError, ValueError):
            return 0
    delete_manifests = [m for m in manifests if _mc(m) == 1]
    data_manifests = [m for m in manifests if _mc(m) == 0]
    if delete_manifests:
        try:
            from core.iceberg_mor import (
                is_mor_enabled,
                collect_delete_files,
                MorDeleteCollectionError,
            )
            if is_mor_enabled() and _out_meta is not None:
                pos_files, eq_files = collect_delete_files(s3_client, bucket, delete_manifests)
                _out_meta["pos_delete_files"] = pos_files
                _out_meta["eq_delete_files"] = eq_files
                # 2026-10-06 -- delete files are read by every worker too;
                # their manifest sizes feed the same per-file keeper.
                try:
                    from core.measured_file_bytes import record_many as _mfb_rd
                    _mfb_rd(bucket, (
                        (f.get("file_path"), f.get("file_size_in_bytes"))
                        for f in list(pos_files) + list(eq_files)))
                except Exception as _mfb_exc:
                    logger.debug("[measured-bytes] delete sizes skipped: %s",
                                 _mfb_exc)
                logger.info(
                    "[iceberg_mor] table %s has %d position-delete + %d equality-delete files (mor.enabled=true)",
                    table_prefix, len(pos_files), len(eq_files),
                )
            elif not is_mor_enabled():
                # DATA-CORRECTNESS (2026-07-06): this table has DELETE files
                # (merge-on-read).  Reading it without applying them silently
                # returns deleted / updated-away rows -- WRONG data with no
                # signal.  FAIL LOUD instead, unless an admin has explicitly
                # opted into data-only reads.
                from core.iceberg_mor import allow_stale_reads
                if allow_stale_reads():
                    logger.warning(
                        "Iceberg V2 table %s has %d DELETE manifests and "
                        "iceberg_mor.enabled=false; iceberg_mor.allow_stale_reads"
                        "=true -> returning DATA-ONLY (deleted rows INCLUDED).",
                        table_prefix, len(delete_manifests),
                    )
                else:
                    # 2026-10-25 -- a ValueError SUBCLASS: a road that lists
                    # inside a fail-open handler re-raises exactly this.
                    from core.iceberg_mor import MorDisabledWithDeletesError
                    raise MorDisabledWithDeletesError(
                        f"Iceberg V2 table '{table_prefix}' has "
                        f"{len(delete_manifests)} DELETE manifest(s) "
                        f"(merge-on-read).  Reading it without applying the "
                        f"deletes would silently return deleted/updated-away "
                        f"rows.  Set iceberg_mor.enabled=true to apply deletes, "
                        f"or iceberg_mor.allow_stale_reads=true to explicitly "
                        f"accept data-only (deleted rows included) reads."
                    )
        except (ValueError, MorDeleteCollectionError):
            # our own fail-loud (MoR-disabled guard, or an INCOMPLETE delete
            # set that would overcount) -> propagate, never swallow
            raise
        except Exception as _mor_exc:
            logger.warning("[iceberg_mor] delete-file collection failed: %s", _mor_exc)
    if len(data_manifests) < len(manifests):
        logger.info(
            "Iceberg V2: %d data manifests, %d delete manifests for table %s",
            len(data_manifests), len(delete_manifests), table_prefix,
        )
    manifests = data_manifests
    # 2026-08-03 SCAN-ECONOMICS — hoisted counters so the end-of-scan summary
    # can report what the work actually SCALED with (manifest-list bounds
    # pruning happens BEFORE any manifest body is fetched/decoded).
    _manifests_total_pre_prune = len(manifests)
    _manifests_pruned_by_bounds = 0

    # 2026-08-21 — PHASE TIMING, because the field log had a 68-SECOND HOLE.
    #
    # A query reported `[metadata_read] elapsed=100.25s files_after_prune=11`
    # and between the stage starting and the first pruning line the log emitted
    # NOTHING but heartbeats.  Pruning itself was correct (11 of 14,673), the
    # DB store answers the same question in ~60ms at that scale, and the
    # manifest cache reported a HIT — so the time went somewhere no existing
    # line covered, and "why is it slow" was unanswerable from the log.
    # An unmeasured stretch of the critical path is its own defect.
    #
    # Pure logging: no behaviour change, no new failure mode.  Emits only when
    # a phase actually costs something, so a healthy query stays quiet.
    _phase_t0 = _time.monotonic()
    _phase_last = [_phase_t0]

    def _phase(label, threshold=2.0):
        _now = _time.monotonic()
        _delta = _now - _phase_last[0]
        _phase_last[0] = _now
        if _delta >= threshold:
            logger.info(
                "[iceberg-phase] %s: %s took %.1fs (%.1fs into the read)",
                table_prefix, label, _delta, _now - _phase_t0)

    # F-A (2026-07): when manifest-level partition pruning drops manifests, the
    # entry list below is a PARTIAL enumeration of the snapshot — it must NOT be
    # stored under the filter-independent snapshot cache key (a later broader
    # query would hit the poisoned partial and silently miss files).  Track it.
    _manifests_were_pruned = False
    # 2026-08-21 — the manifests bounds-pruning DROPS, kept so the snapshot
    # store can be completed from cache without re-reading S3.  See
    # ``_complete_pruned_enumeration`` at the store site below.
    _pruned_manifest_refs: List[Any] = []
    # ── 2026-08-03 PRUNING CORRECTNESS GATE (armed here since 2026-09-28,
    # ABOVE Step 4b, so a manifest-summary drop is gated too) ──────────────────────────────
    # Independent per-drop justification verifier (core/pruning_gate.py).
    # off (default) → zero overhead; observe → verify + log, never changes
    # the file set; enforce → an UNJUSTIFIED drop is vetoed and the file is
    # RESTORED to the scan set (fail-closed against data loss).  The gate
    # itself is fail-open: any error means the reader's decision stands.
    _gate = None
    try:
        from core.pruning_gate import gate_for_query as _pg_for_query
        _gate = _pg_for_query(table_prefix=table_prefix)
    except Exception as _pg_init_exc:
        logger.debug("pruning-gate init skipped (fail-open): %s", _pg_init_exc)
        _gate = None

    def _gate_allow(stage: str, file_key: str, **record) -> bool:
        """True → the drop may proceed.  False (enforce mode, unjustified
        drop) → the caller must KEEP the file.  Never raises."""
        if _gate is None:
            return True
        try:
            return _gate.allow_drop(stage, file_key, **record)
        except Exception as _ga_exc:
            logger.debug("pruning-gate check failed open (drop allowed): %s",
                         _ga_exc)
            return True

    # ── Step 4b: Prune manifests using partition bounds ────────────────────────
    if use_pruning and partition_spec and partition_filters:
        total = len(manifests)
        logger.debug(
            "Partition pruning for %s: spec=%s filters=%s",
            table_prefix, partition_spec, partition_filters,
        )
        # 149.3 (2026-06-09): hoist source→partition-field map ONCE per
        # query, pass into the per-manifest loop.  This makes the
        # manifest-level pruner symmetric with the file-level pruner
        # (BF-501) — both now translate source-col filters to partition-
        # field names for transform-renamed partitions (day/month/year/
        # hour/bucket/truncate).  Win is proportional to manifest count;
        # tables with hundreds of manifests + a date filter on a
        # day-partitioned column see most manifests skipped without
        # opening their Avro bodies.
        _step4b_src_to_part: Dict[str, str] = {}
        try:
            _step4b_src_to_part = build_source_to_partition_field_map(metadata)
        except Exception as _s2p_exc:
            logger.debug(
                "149.3: source→partition-field map failed at manifest "
                "prune step (non-fatal, falls back to direct-name "
                "matching): %s", _s2p_exc,
            )
        # 2026-08-03 (spec-evolution DATA-LOSS FIX): a manifest's positional
        # ``partitions`` summaries are ordered by the spec the manifest was
        # WRITTEN under (``partition_spec_id``), not the table's default
        # spec.  Pruning every manifest with the default spec's field order
        # compares the WRONG column's bounds after spec evolution — an
        # UNGATED drop (files inside a pruned manifest never reach the
        # per-file loop or the pruning gate).  Resolve per-manifest; a spec
        # id we cannot resolve ⇒ KEEP the manifest (fail-open).
        _default_sid = metadata.get("default-spec-id", 0)
        _spec_by_id_cache: Dict[Any, Optional[Dict[str, str]]] = {}

        def _spec_for_manifest(_m) -> Optional[Dict[str, str]]:
            try:
                _sid = _m.get("partition_spec_id", _m.get("partition-spec-id"))
            except AttributeError:
                _sid = None
            if (_sid is None or _sid == _default_sid
                    or not metadata.get("partition-specs")):
                return partition_spec
            if _sid not in _spec_by_id_cache:
                try:
                    _spec_by_id_cache[_sid] = (
                        _extract_partition_spec(metadata, spec_id=_sid)
                        or None)
                except Exception as _sfm_exc:
                    logger.warning(
                        "Iceberg %s: could not resolve partition spec-id %s "
                        "for manifest-level pruning (%s) — manifests written "
                        "under it are KEPT unpruned (fail-open).",
                        table_prefix, _sid, _sfm_exc)
                    _spec_by_id_cache[_sid] = None
            return _spec_by_id_cache[_sid]

        _kept_manifests = []
        # 2026-09-26 (F4a): WHY each manifest was kept, per (manifest,
        # filter) pair -- see MANIFEST_KEEP_REASONS.  "skipped 0/N" used to
        # be printed both by a healthy non-selective predicate and by a
        # writer that omits partition summaries; the receipt is the
        # difference between "correct" and "the ocean, silently".
        _keep_reasons: Dict[str, int] = {}
        # 2026-09-28 -- the matcher said prune, the pruning gate (enforce)
        # could not justify it from its own interval model: KEPT.  Counted
        # beside the keep-reasons (that vocabulary is the matcher's own).
        _mf_gate_restored = 0
        for m in manifests:
            _m_spec = _spec_for_manifest(m)
            if not _m_spec:
                _keep_reasons["spec_unresolved"] = (
                    _keep_reasons.get("spec_unresolved", 0) + 1)
                _kept_manifests.append(m)     # unresolvable spec → KEEP
                continue
            _mf_dec: Dict[str, Any] = {}
            if _manifest_matches_filters(
                    m, _m_spec, partition_filters,
                    src_to_part=_step4b_src_to_part,
                    reasons=_keep_reasons, decision_out=_mf_dec):
                _kept_manifests.append(m)
            elif not _gate_allow("manifest_summary",
                                 str((m.get("manifest_path") if isinstance(m, dict)
                                      else None) or ""), **_mf_dec):
                # 2026-09-28 -- THROUGH THE GATE, like every per-file stage.
                # Enforce: an unjustified summary drop KEEPS the manifest
                # (its files then meet the gated per-file funnel).  Observe:
                # counted, so an all-manifests-pruned "0 files" can be
                # PROVEN -- or shown not to be.
                _mf_gate_restored += 1
                _kept_manifests.append(m)
            else:
                # Bounds say this manifest holds nothing this query wants.
                # That is a statement about THIS query's filters, not about
                # the snapshot -- so remember it, or the enumeration below
                # can never be completed and the snapshot store stays empty
                # for every filtered query forever.
                _pruned_manifest_refs.append(m)
        manifests = _kept_manifests
        pruned = total - len(manifests)
        _manifests_pruned_by_bounds = pruned
        _manifests_were_pruned = pruned > 0
        logger.info(
            "Iceberg partition pruning: skipped %d/%d manifests for table %s "
            "(manifest-summary verdicts: %s%s)",
            pruned, total, table_prefix,
            ", ".join(f"{k}={v}" for k, v in sorted(_keep_reasons.items()))
            or "none",
            f"; gate_restored={_mf_gate_restored}" if _mf_gate_restored else "",
        )
        _evaluated_pairs = (_keep_reasons.get("pruned", 0)
                            + _keep_reasons.get("overlap", 0))
        if total and pruned == 0 and _evaluated_pairs == 0:
            # Every manifest kept and NOT ONE (manifest, filter) pair was
            # evaluated against a summary.  That is the silent-ocean
            # signature the 2026-09-22 record described: the predicate
            # never touched the manifest list, and Step 5 will open every
            # body.  Correct, and worth a WARNING, because the operator's
            # only other signal was an INFO line identical to a healthy one.
            logger.warning(
                "Iceberg partition pruning for %s: %d manifest(s) kept and "
                "the predicate on %s was never evaluated against a single "
                "manifest-list summary (%s).  Every manifest body will be "
                "opened; the per-file loop still prunes.",
                table_prefix, total,
                [(f.get("col") or f.get("column") or "")
                 for f in partition_filters],
                ", ".join(f"{k}={v}" for k, v in sorted(_keep_reasons.items()))
                or "no reason recorded",
            )
        # 149.3 — emit manifest-pruning record into _out_meta so the
        # scan-plan diagnose UI can render "manifest-list pruning
        # dropped 850/1000 manifests via day(event_time) projection"
        # instead of just the file-level counts.  Best-effort.
        if _out_meta is not None:
            try:
                _out_meta.setdefault("manifest_pruning", {})
                _out_meta["manifest_pruning"] = {
                    "manifests_before":          total,
                    "manifests_after":           len(manifests),
                    "manifests_dropped":         pruned,
                    # F4a: per-(manifest, filter) verdict tally; see
                    # MANIFEST_KEEP_REASONS.  ``evaluated_pairs == 0`` with
                    # manifests kept means the summaries were never consulted.
                    "keep_reasons":              dict(_keep_reasons),
                    "evaluated_pairs":           _evaluated_pairs,
                    # 2026-09-28: summary drops the enforce gate refused.
                    "gate_restored":             _mf_gate_restored,
                    "src_to_part_translations":  dict(_step4b_src_to_part),
                    "filter_columns":            [
                        (f.get("col") or f.get("column") or "")
                        for f in partition_filters
                    ],
                }
            except Exception as _be_exc:
                note_best_effort("_out_meta['manifest_pruning'] = {'manifests_before': total, 'mani...", _be_exc,
                                 logger=logger)

    # ── Step 5: Read manifests in parallel and collect data file paths ────────
    # Resolve manifest paths first
    _manifest_paths: List[str] = []
    # 2026-08-20: dedup identity is (effective bucket, key) — key-only dedup
    # dropped a colliding-path manifest from ANOTHER bucket as a "duplicate".
    # Maps key → effective bucket of the first reference (bare URI ⇒ the
    # table's bucket).
    _seen_manifest_paths: Dict[str, str] = {}  # 2026-07-13: dedup guard
    _dup_manifest_refs = 0
    _foreign_manifest_refs: List[str] = []     # 2026-08-20: NOT duplicates
    # 2026-08-04 (f39cf53a caller wiring) — manifest-list entry sequence
    # numbers, keyed by resolved manifest key.  The V2 inheritance source for
    # ADDED (status=1) data-file entries whose own ``sequence_number`` is
    # null.  Consumed below when building ``_out_meta["data_seq_by_path"]``
    # for equality-delete sequence scoping.
    _manifest_seq_by_key: Dict[str, int] = {}
    for manifest in manifests:
        manifest_path = (
            manifest.get("manifest_path")
            or manifest.get("manifest-path")
            or (manifest if isinstance(manifest, str) else None)
        )
        if manifest_path:
            _mk = _s3_uri_to_key(manifest_path)
            try:
                _mseq_raw = (manifest.get("sequence_number")
                             if isinstance(manifest, dict) else None)
                if _mseq_raw is not None:
                    _manifest_seq_by_key.setdefault(_mk, int(_mseq_raw))
            except (TypeError, ValueError):
                pass
            # 2026-07-13 (phantom-file-count fix): a manifest-list that
            # references the SAME manifest more than once would otherwise
            # have ALL of that manifest's data files read (and counted)
            # twice -> the "N files that never existed" over-count the user
            # reported.  Each manifest file is immutable and self-contained,
            # so reading it once is complete; a second reference adds only
            # duplicates.  Skip repeats.
            # 2026-08-20 DATA-LOSS FIX: "repeat" now means same (bucket,
            # key), not same key.  A colliding key path in a DIFFERENT
            # bucket is NOT a duplicate — it is a manifest this
            # single-bucket reader cannot read at all (its data files are
            # provably missing from the enumeration), so it is surfaced as
            # a foreign-bucket ref (file_cap/certificate hard negative
            # below) instead of being silently "fixed" away.
            _m_bucket = (_s3_uri_bucket(str(manifest_path
                                            if isinstance(manifest_path, str)
                                            else _mk)) or bucket)
            # NOTE deliberately NOT changed: a non-colliding manifest whose
            # URI names another bucket is still read (key-only) from the
            # table's bucket — deployments where the connection bucket is an
            # alias/mirror of the recorded one depend on that, and a truly
            # foreign one 404s into ``manifest_read_failures`` → the ledger's
            # ``partial_manifest_read`` hard negative (2026-08-20).  Only the
            # COLLISION case is reclassified here, because for a collision
            # the two references provably name DIFFERENT objects.
            _m_verdict = _classify_ref_for_dedup(
                _seen_manifest_paths, _mk, _m_bucket)
            if _m_verdict == "dup":
                _dup_manifest_refs += 1
                continue
            if _m_verdict == "foreign":
                _foreign_manifest_refs.append(f"{_m_bucket}/{_mk}")
                continue
            _manifest_paths.append(_mk)
    if _dup_manifest_refs:
        logger.warning(
            "Iceberg %s: manifest-list referenced %d manifest(s) more than "
            "once — deduped to %d unique manifest(s) (prevents phantom "
            "double-counted data files).",
            table_prefix, _dup_manifest_refs, len(_manifest_paths),
        )
    if _foreign_manifest_refs:
        # 2026-08-20: these were counted as "duplicates" and the drop was
        # reported as a FIX.  They are unreadable-by-construction for a
        # single-bucket reader: every data file they reference is MISSING.
        # Surfaced via file_cap/record_scan_truncation after enumeration.
        logger.error(
            "Iceberg %s: manifest-list references %d manifest(s) in a "
            "FOREIGN bucket colliding with same-key manifests in s3://%s — "
            "NOT duplicates; their data files are MISSING from this scan "
            "(single-bucket reader).  First few: %s",
            table_prefix, len(_foreign_manifest_refs), bucket,
            _foreign_manifest_refs[:5],
        )

    # BF-296: snapshot-keyed contents cache.  When the manifest list for
    # this exact snapshot has been walked before, skip the parallel S3
    # fetches entirely — Iceberg snapshots are immutable so we can safely
    # serve the cached avro entries.  Saves 10+ minutes on big tables
    # through a corporate proxy.
    _bf296_t_manifests = _time.monotonic()
    _bf296_cache_hit = False
    _bf296_snap_key = str(current_snapshot_id) if current_snapshot_id else ""
    _all_entries = None
    # Function scope on purpose: the walk branch below fills this, but a
    # cache HIT skips that branch entirely and the end-of-scan summary
    # still reads it.  Declared inside the branch, it raised NameError
    # into a fail-open `except` on the FAST path — the summary vanished
    # exactly where the system was working correctly.
    _manifests_fetched_from_s3: List[str] = []
    # BF-500 (2026-05-28) — when ``force_fresh=True`` skip the BF-296
    # snapshot-content cache entirely.  Reasons:
    #   1. A previous sync run that was interrupted (network blip,
    #      scheduler shutdown, OOM) could have stored a PARTIAL
    #      manifest-entries list under this snapshot_id.  Without
    #      this skip, future ``force_fresh`` calls KEEP returning the
    #      partial cache — the watched-tables registry stays stuck
    #      at "half the files".  User reproduced this exactly:
    #      "table has half of the files on watched tables...tried
    #      to force everything for that table its not caching
    #      everything".
    #   2. Iceberg metadata sync's entire job is to be the
    #      authoritative refresh path.  Trusting our own cache
    #      defeats the purpose.
    # The expensive part of force-fresh isn't this cache skip — it's
    # the manifest-list re-walk that already happens.  The skip just
    # ensures the entries we ASSEMBLE come from S3, not from a
    # potentially-partial in-process store.
    # Strict mode for manifest reads.  Read once here so the inner
    # _read_manifest_from_s3 closure can consult it without re-loading
    # config on every parallel S3 fetch.  Off by default for
    # back-compat with existing fail-open-on-S3-error behaviour;
    # operators flip it to True in production once S3 connectivity
    # is reliable, so a transient S3 failure becomes a loud query
    # error instead of a silent partial scan.
    try:
        from core.config import get as _cfg_get
        _manifest_strict_mode = bool(_cfg_get(
            "iceberg", "manifest_read_strict_mode", False))
    except Exception:
        _manifest_strict_mode = False

    # Diagnostic — caller surfaces this in logs + admin UI so operators
    # can tell whether the cache served the query, S3 served it, or it
    # was a partial result.  Always emitted; the caller is free to
    # ignore.  Use a stable dict shape so it's safe to consume.
    _cache_diag = {
        "cache_hit":            False,    # set True below on cache HIT
        "cache_state":          "empty",  # "hit" | "miss" | "force_fresh" | "disabled"
        "manifests_attempted":  0,
        "manifests_succeeded":  0,
        "manifests_failed":     0,
        "s3_read_path":         False,    # True when manifest data came from S3
        "strict_mode":          _manifest_strict_mode,
    }

    # ── Phase 3 (industrialization) — DB-only enumeration ──────────────
    # When ``industrialization.db_only_enumeration`` is armed, the rows
    # store (iceberg_snapshot_files) is the query-path source of truth:
    # the SAFE partition-island predicates are pushed into the SQL load so
    # enumeration is O(island), and a store that is NOT provably complete
    # for this snapshot triggers an ALARMED fallback to the manifest walk
    # (files a "syncer behind" signal — loud, never silent).  Flag OFF
    # (default): island filters stay None → get_cached_contents behaves
    # byte-for-byte as today.
    _p3_db_only = False
    _p3_island_filters = None
    _p3_island_coverage: Optional[Dict[str, Any]] = None
    _p3_expected_total = None
    _p3_serve_info: Dict[str, Any] = {}   # Phase 0: which cache route served
    try:
        from core.industrialization import is_enabled as _p3_enabled
        _p3_db_only = bool(_p3_enabled("db_only_enumeration"))
    except Exception:
        _p3_db_only = False
    # 2026-08-21 — THE ISLAND PUSHDOWN IS NO LONGER GATED ON db_only_enumeration.
    #
    # That flag bundles two things under one switch:
    #   (a) push the partition predicate INTO the rows store, so the DB returns
    #       the island instead of the whole snapshot;
    #   (b) "Query path never walks manifests; DB-first store only" — no
    #       fallback.
    # (b) is a real behaviour change and stays behind the flag.  (a) carries NO
    # such risk, because the receiving side refuses to serve a narrowed list it
    # cannot prove complete: get_cached_contents only applies island_filters
    # under storage_mode='rows' AND _rows_store_proven_complete(); anything else
    # ignores them and serves exactly what it serves today.
    #
    # Bundling them meant the safe half was hostage to the risky half, and the
    # field result was a query that fetched every row it needed FROM THE
    # DATABASE and then filtered in Python:
    #     BF-296 cache HIT — 7028 entries — skipping S3 fetches
    #     entries_decoded=7028 -> survivors=9
    # "All the metadata is in the DB" and "it is diving in the ocean" were both
    # true at once.  Measured at this scale the seek answers in ~60ms against
    # ~15s of entry decode.
    # Phase 4 (2026-08-22): island derivation + narration + the store serve
    # + route classification moved into core.iceberg_snapshot_seek — the
    # ONE entry point answering "which files of snapshot S can match
    # predicate P".  Behaviour is byte-for-byte the former inline block;
    # only the address changed.

    # 2026-08-21 — force_fresh NO LONGER MEANS "walk the ocean".
    #
    # "Bypass the cache" was implemented as "skip the snapshot-content store
    # entirely", which threw away the PARTITION ISLAND along with the memo and
    # sent every such query back to decoding the full manifest set.  Operator,
    # on seeing it: "really how come cache bypass will dive in ocean....so
    # crazy" — and they are right.  The island is a QUERY PLAN derived from the
    # WHERE clause and the partition spec.  It is not a cached answer, and
    # refusing stale answers is no reason to abandon the plan.
    #
    # An Iceberg snapshot is IMMUTABLE: the file list of snapshot N is the same
    # forever.  So force_fresh only ever needs to re-resolve WHICH snapshot is
    # current — which it still does, upstream, with a real metadata.json read.
    # For the CONTENTS of that snapshot it may use the per-file rows store,
    # but ONLY when that store PROVES completeness (marker written last,
    # COUNT(rows) == declared, declared <= the snapshot's own total).
    #
    # BF-500's incident — a partial enumeration cached under a good snapshot id
    # and served forever — is fully preserved: an unproven store, a memoised L1
    # entry and the proof-less JSON blob are ALL refused in this mode, and the
    # walk happens exactly as before.  What changed is that a PROVEN island is
    # no longer thrown away for no reason.
    _proof_only = bool(force_fresh)
    if _bf296_snap_key:
        from core.iceberg_snapshot_seek import snapshot_seek as _snapshot_seek
        _seek_res = _snapshot_seek(
            bucket=bucket, table_prefix=table_prefix,
            snapshot_id=_bf296_snap_key, metadata=metadata,
            partition_filters=partition_filters,
            require_proven_complete=_proof_only,
            out_meta=_out_meta, db_only=_p3_db_only)
        _all_entries = _seek_res.entries
        _p3_island_filters = _seek_res.island_filters
        _p3_island_coverage = _seek_res.island_coverage
        _p3_expected_total = _seek_res.expected_total
        _p3_serve_info = _seek_res.serve_info
        if _all_entries is not None:
            _bf296_cache_hit = True
            _cache_diag["cache_hit"] = True
            _cache_diag["cache_state"] = (
                "hit:proven" if _proof_only else "hit")
            if _seek_res.seek_route:
                _seek_route = _seek_res.seek_route
    if _all_entries is None and _bf296_snap_key and force_fresh:
        _cache_diag["cache_state"] = "force_fresh"
        logger.info(
            "BF-500: force_fresh=True and no PROVABLY COMPLETE rows store for "
            "%s/%s snapshot=%s — re-reading manifests from S3.  (A proven "
            "store would have been used: a snapshot is immutable, so "
            "force_fresh re-resolves WHICH snapshot is current, not what is "
            "in it.)",
            bucket, table_prefix, _bf296_snap_key,
        )

    if _all_entries is None:
        # ── Phase 4 (2026-08-22) — the walk is a FILED event, always ──
        # The seek could not serve this snapshot (store absent / incomplete
        # / header missing): the query stays CORRECT via the manifest walk
        # below, and record_syncer_behind files it — unconditionally, no
        # longer only under db_only_enumeration.  Its VERDICT (2026-09-26)
        # depends on whether a fleet syncer is armed: armed → ERROR (the
        # syncer did not get here first); not armed (the shipped default)
        # → the store_contents call AFTER this walk is the only writer of
        # the rows store, so the first walk of a snapshot is the designed
        # completion (INFO) and only a REPEAT walk of the same snapshot is
        # a WARNING.  force_fresh is a deliberate operator re-walk — not
        # filed at all.
        if _bf296_snap_key and not force_fresh:
            try:
                from core.industrialization.fleet_syncer import (
                    record_syncer_behind as _p4_alarm,
                )
                _p4_alarm(bucket, table_prefix, _bf296_snap_key)
            except Exception as _p4_alarm_exc:
                logger.warning(
                    "[seek] rows store could not serve %s/%s snapshot=%s "
                    "— falling back to the S3 manifest walk (alarm "
                    "plumbing failed: %s)",
                    bucket, table_prefix, _bf296_snap_key, _p4_alarm_exc)
            if _p3_db_only and _out_meta is not None:
                _out_meta["db_only_enum"] = "fallback:manifest_walk"
        # BF-500 (2026-05-28) — track manifest-read failures.  When one
        # or more manifests fail, the resulting ``_all_entries`` list
        # has empty slots — looks like a "valid" partial result.
        # Previously we'd then call ``store_contents`` with that partial
        # list, caching the "half the files" state under the snapshot
        # id.  Every subsequent force-refresh re-served the partial
        # cache.  Track failures here, refuse to store on any failure,
        # and surface the count so the caller can decide what to do.
        _manifest_read_failures: list = []  # list of (manifest_path, error_str)
        # 2026-08-21 — count ACTUAL S3 object reads.  The ICEBERG-CACHE line
        # used to print manifests_succeeded/attempted under the label
        # "s3_manifests", which counts every manifest we PROCESSED including
        # the ones served entirely from L1/L2.  A fully-cached walk therefore
        # read "s3_manifests=5/5" and looked identical to five real GETs —
        # so the one line an operator reads to answer "is it still diving in
        # the ocean?" could not answer it.  This counter can.
        # (declared at FUNCTION scope above — a cache HIT never enters this branch,
        #  and the end-of-scan summary reads it either way.)

        def _read_manifest_from_s3(_bucket: str, mk: str) -> list:
            """Read a single manifest file and return its Avro entries.

            BF-298: this is the COLD path — only called on cache miss.
            The hot path goes through ``iceberg_snapshot_cache.get_or_fetch_manifest_entries``
            which checks the manifest-keyed cache first.  Iceberg manifest
            files are immutable so a cache hit can never be wrong.

            BF-500: failures are tracked so the caller can refuse to
            cache a partial result.

            Failure policy (2026-06-03, user request "we should not fail
            silently — read from S3 when cache is empty, but loudly
            if S3 itself fails"):
              * Default (back-compat): log error, track failure, return ``[]``
                for THIS manifest.  Other manifests still attempted;
                aggregate result may be PARTIAL.  Caller sees the failure
                count via ``_out_meta["manifest_read_failures"]`` and
                via the loud WARNING line emitted below.
              * Strict mode (``iceberg.manifest_read_strict_mode=true``):
                RAISE the underlying exception immediately so the caller
                fails the query with a clear, actionable error instead of
                silently returning a partial file list.  Recommended for
                production where over-scan / under-scan from a partial
                manifest read is a correctness incident, not a perf hint.
            """
            _manifests_fetched_from_s3.append(mk)
            try:
                logger.debug("Reading manifest: s3://%s/%s", _bucket, mk)
                # Phase 0 — the counter is passed EXPLICITLY: this closure
                # runs on executor threads, which do not inherit the query
                # thread's ContextVar context.
                data = _read_s3_bytes(s3_client, _bucket, mk,
                                      _get_counter=_s3_ctr)
                entries = _read_avro(data)
                logger.debug("Manifest %s: %d entries", mk.rsplit("/", 1)[-1], len(entries))
                return entries
            except Exception as e:
                logger.error("Could not read manifest %s: %s", mk, e, exc_info=True)
                _manifest_read_failures.append((mk, str(e)[:200]))
                if _manifest_strict_mode:
                    raise RuntimeError(
                        f"Iceberg manifest read failed (strict mode on): "
                        f"s3://{_bucket}/{mk} -> {type(e).__name__}: {e}. "
                        f"Iceberg cache is empty AND S3 manifest read failed "
                        f"for this table; query is aborted to prevent silent "
                        f"under-scan / over-scan.  Either fix S3 access "
                        f"(proxy / VPC endpoint / credentials) OR set "
                        f"iceberg.manifest_read_strict_mode=false to fall "
                        f"back to partial-result mode (NOT recommended in "
                        f"production)."
                    ) from e
                # Marked, not bare: a bare [] here is indistinguishable from a
                # genuinely empty manifest, and the per-manifest cache stored
                # it permanently — turning one transient S3 error into a
                # permanent under-enumeration of this table.
                try:
                    from core.iceberg_snapshot_cache import FailedManifestRead
                    return FailedManifestRead()
                except Exception:
                    return []

        # BF-298: per-manifest cache (incremental reconciliation).  Most
        # manifests in a new snapshot are reused verbatim from the
        # previous snapshot, so the cache hit ratio approaches 99 % for
        # append-only tables.  Only true misses go to S3 (in parallel).
        try:
            from core import iceberg_snapshot_cache as _isc_mf
            def _read_one(mk: str) -> list:
                return _isc_mf.get_or_fetch_manifest_entries(
                    bucket=bucket, manifest_path=mk,
                    fetch_fn=_read_manifest_from_s3,
                )
        except Exception:
            _read_one = lambda mk: _read_manifest_from_s3(bucket, mk)  # noqa: E731

        # Parallel read.  F1 (2026-08-22): the width was hard-capped at 8
        # against a 64-slot shared pool — ⌈M/8⌉ RTT waves on exactly the
        # path a proxy makes slow (63 waves for a 500-manifest table).  Now
        # a knob (iceberg.manifest_fetch_parallelism, default 32), clamped
        # to the shared pool size; 8 stays as the documented fallback when
        # the config read fails or the value is invalid.  Cache-hit branches
        # inside ``_read_one`` are nearly free, so the parallel pool is only
        # used when the cache really misses.
        from concurrent.futures import ThreadPoolExecutor
        _PARALLEL = _manifest_fetch_parallelism(len(_manifest_paths))
        if _cache_diag["cache_state"] == "empty":
            _cache_diag["cache_state"] = "miss"
        _cache_diag["s3_read_path"] = True
        _cache_diag["manifests_attempted"] = len(_manifest_paths)
        if len(_manifest_paths) > 1:
            with ThreadPoolExecutor(max_workers=_PARALLEL) as pool:
                _all_entries = list(pool.map(_read_one, _manifest_paths))
        else:
            _all_entries = [_read_one(mk) for mk in _manifest_paths]
        # Populate post-read counts.  manifest_read_failures is closed
        # over by _read_manifest_from_s3 and grew during the parallel
        # fetch above; in strict mode the first failure already raised.
        _cache_diag["manifests_failed"]    = len(_manifest_read_failures)
        _cache_diag["manifests_succeeded"] = (
            len(_manifest_paths) - len(_manifest_read_failures)
        )

        # BF-296: store the snapshot-level cache (full _all_entries
        # under one key) so the very next query against the same
        # snapshot can skip even the per-manifest lookups.
        # BF-500 — refuse to cache when manifest reads failed.  A
        # partial list would otherwise haunt future force-refresh
        # calls (cache layer always returned the "half" entries).
        # ── 2026-08-21: COMPLETE A PRUNED WALK, DON'T ABANDON IT ──────────
        # A bounds-pruned walk enumerates only the manifests THIS query's
        # filters could match, so ``_all_entries`` is a PARTIAL view of the
        # snapshot and must never be stored under the filter-independent
        # snapshot key (a later, broader query would hit the poisoned partial
        # and silently miss files).  That much was always right.
        #
        # What was wrong was the conclusion: "partial ⇒ store nothing".
        # Manifest pruning fires on essentially every real query, and this is
        # the ONLY writer of the contents store — so the store stayed empty in
        # production, the per-file rows store behind it stayed empty, the
        # island seek had nothing to seek, and every query fell back to
        # walking the whole snapshot.  The pruning that was supposed to make
        # us fast was disabling the cache that makes us fast.
        #
        # Manifests are immutable and are reused verbatim across snapshots, so
        # the ones we skipped are almost always already in the BF-298
        # per-manifest cache.  Ask for them there — L1/L2 only, NEVER S3 — and
        # if every one is available we hold a provably COMPLETE enumeration
        # and may store it, having paid nothing extra to get it.  If even one
        # is absent we store nothing, exactly as before: no regression, and
        # never a partial written as if it were whole.
        #
        # The completion feeds the STORE only.  ``_all_entries`` keeps its
        # positional alignment with ``_manifest_paths`` (the V2 sequence-number
        # inheritance below depends on it) and the query's answer is byte-for-
        # byte what it was — pruning still prunes.
        _store_entries = _all_entries
        if _manifests_were_pruned:
            _store_entries = None
            try:
                from core import iceberg_snapshot_cache as _isc_fill
                _fill_keys: List[str] = []
                _fill_seen = set(_manifest_paths)
                # A ref we cannot even name is NOT the same as "nothing left
                # to fetch" — both leave _fill_keys empty, so say which.
                _fill_readable = True
                # A colliding-key manifest in ANOTHER bucket was dropped from
                # the kept path as unreadable, so _all_entries is ALREADY
                # short of that manifest's files.  Completing on top of a
                # known-incomplete base would stamp it "whole".  Refuse.
                if _foreign_manifest_refs:
                    _fill_readable = False
                for _pm in _pruned_manifest_refs if _fill_readable else ():
                    _pmp = (_pm if isinstance(_pm, str)
                            else (_pm.get("manifest_path")
                                  or _pm.get("manifest-path"))
                            if isinstance(_pm, dict) else None)
                    if not _pmp:
                        _fill_readable = False   # unreadable ref → cannot prove
                        break
                    _pk = _s3_uri_to_key(_pmp)
                    if _pk in _fill_seen:
                        # Same key on both sides of the prune: either a
                        # duplicated manifest-list ref, or a collision naming
                        # a DIFFERENT object in another bucket.  We cannot
                        # tell which from here, and one of them means the
                        # enumeration is not what it claims — so refuse
                        # rather than assume the kept read covered it.
                        _fill_readable = False
                        break
                    _fill_seen.add(_pk)
                    _fill_keys.append(_pk)
                if _fill_readable:
                    _filled = []
                    for _pk in _fill_keys:
                        _ents = _isc_fill.peek_manifest_entries(bucket, _pk)
                        if _ents is None:
                            _filled = None       # not cached → cannot complete
                            break
                        _filled.append(_ents)
                    if _filled is not None:
                        _store_entries = list(_all_entries) + _filled
                        logger.info(
                            "Iceberg %s: completed a bounds-pruned walk from "
                            "the manifest cache — %d pruned manifest(s) "
                            "recovered with 0 S3 reads; storing the FULL "
                            "snapshot enumeration (%d manifests).",
                            table_prefix, len(_fill_keys), len(_store_entries),
                        )
                    else:
                        # 2026-08-22 (audit-open P2): the missing-set
                        # recompute used to probe EVERY pruned manifest here
                        # via peek_manifest_entries — L1 misses become L2 DB
                        # reads behind a 2-permit semaphore, i.e. hundreds of
                        # serialized DB round-trips ON THE CRITICAL PATH for
                        # a big pruned table.  "Cache-only probe: costs
                        # nothing" was false.  The probe now runs inside the
                        # background warmer (probe_missing=True); this query
                        # only knows "at least one is missing", which is all
                        # it needs.
                        logger.info(
                            "Iceberg %s: bounds-pruned walk cannot be completed "
                            "— at least 1 of %d pruned manifest(s) is not in "
                            "the manifest cache, so this snapshot's file index "
                            "cannot be stored yet.  Probing + warming in the "
                            "BACKGROUND; this query is unaffected.",
                            table_prefix, len(_fill_keys),
                        )
                        _bootstrap_manifest_cache_async(
                            bucket, table_prefix, str(_bf296_snap_key),
                            _fill_keys, s3_client, db_manager=db_manager,
                            probe_missing=True,
                        )
            except Exception as _fill_exc:
                _store_entries = None
                logger.warning(
                    "Iceberg %s: pruned-walk completion failed (%s: %s) — "
                    "storing nothing, which is the safe outcome.",
                    table_prefix, type(_fill_exc).__name__, str(_fill_exc)[:200],
                )

        if (_bf296_snap_key and not _manifest_read_failures
                and _store_entries is not None):
            try:
                from core import iceberg_snapshot_cache as _isc
                logger.info(
                    "BF-296 cache store START: bucket=%r table_prefix=%r "
                    "snapshot=%r entries_count=%d",
                    bucket, table_prefix, _bf296_snap_key, len(_store_entries),
                )
                _isc.store_contents(
                    bucket=bucket, table_prefix=table_prefix,
                    snapshot_id=_bf296_snap_key, files=_store_entries,
                )
                _isc.store_pointer(bucket, table_prefix, _bf296_snap_key)
                logger.info(
                    "BF-296 cache store DONE: bucket=%r snapshot=%r "
                    "entries=%d", bucket, _bf296_snap_key, len(_store_entries),
                )
            except Exception as _bf296_store_exc:
                # 2026-06-04 — was DEBUG and silently swallowed.  On
                # Postgres cutovers the encoder can fail here and you
                # get a 0-row iceberg_snapshot_cache with no log signal.
                # WARNING + exc_info=True surfaces the chain.
                logger.warning(
                    "BF-296 cache store failed: bucket=%r table_prefix=%r "
                    "snapshot=%r entries=%d type=%s msg=%s",
                    bucket, table_prefix, _bf296_snap_key, len(_all_entries),
                    type(_bf296_store_exc).__name__,
                    str(_bf296_store_exc)[:300],
                    exc_info=True,
                )
        elif _bf296_snap_key and _manifest_read_failures:
            logger.warning(
                "BF-500: %d manifest read(s) failed for %s/%s snapshot=%s — "
                "NOT caching partial result.  Next call will re-read from "
                "S3.  Failures: %s",
                len(_manifest_read_failures), bucket, table_prefix,
                _bf296_snap_key,
                "; ".join(f"{p}: {e}" for p, e in _manifest_read_failures[:3])
                + (f" (+{len(_manifest_read_failures) - 3} more)"
                   if len(_manifest_read_failures) > 3 else ""),
            )
            # Surface to caller via _out_meta so admins can see the
            # partial-read warning at the call site (e.g. preview-files
            # UI can flag "snapshot was only partially read").
            if _out_meta is not None:
                _out_meta["manifest_read_failures"] = len(_manifest_read_failures)
                _out_meta["manifest_read_failure_paths"] = [
                    p for p, _ in _manifest_read_failures[:10]
                ]
    _bf296_manifests_seconds = _time.monotonic() - _bf296_t_manifests

    # ── 2026-08-04 — equality-delete SEQUENCE-scoping caller wiring ──────────
    # f39cf53a taught collect_delete_files to extract eq-delete sequence
    # numbers, but no caller supplied the DATA side (read path → data seq), so
    # build_mor_view_sql's seq arm stayed inert: every eq delete applied to
    # every data file, wrongly suppressing a CDC key deleted at seq N and
    # re-inserted at seq N+1.  Build the map here — the ONE place that has the
    # manifest entries — and hand it to callers via _out_meta, the same channel
    # as pos/eq_delete_files.
    #
    # SAFETY (direction of error matters): a MISSING map entry falls back to
    # global apply — today's baseline, can only over-delete (the pre-fix
    # behaviour).  A WRONG (too-high) seq would EXEMPT a data file from
    # deletes → silent overcount, which is worse.  So:
    #   * an entry's EXPLICIT sequence_number is always trusted;
    #   * V2 inheritance (null seq on an ADDED status=1 entry inherits the
    #     manifest-list entry's seq) is applied ONLY when _all_entries is
    #     provably parallel to _manifest_paths — the S3 walk built it via
    #     pool.map over exactly that list.  Cache-served entry lists
    #     (BF-296 blob / per-file rows store) may be re-wrapped as one
    #     pseudo-manifest, so inherited attribution there is skipped, never
    #     guessed;
    #   * anything unresolvable stays OUT of the map → baseline.
    if (_out_meta is not None and _out_meta.get("eq_delete_files")
            and _all_entries):
        try:
            _seq_aligned = (not _bf296_cache_hit
                            and len(_all_entries) == len(_manifest_paths))
            _data_seq_map: Dict[str, int] = {}
            for _seq_mi, _seq_entries in enumerate(_all_entries):
                _seq_inherit = (_manifest_seq_by_key.get(_manifest_paths[_seq_mi])
                                if _seq_aligned else None)
                for _seq_ent in (_seq_entries or []):
                    if not isinstance(_seq_ent, dict) or _seq_ent.get("status") == 2:
                        continue
                    _seq_df = _seq_ent.get("data_file") or {}
                    if not isinstance(_seq_df, dict):
                        continue
                    _seq_fp = _seq_df.get("file_path") or _seq_df.get("path", "")
                    if not _seq_fp:
                        continue
                    _seq_val = _seq_ent.get("sequence_number")
                    if _seq_val is None and _seq_ent.get("status") == 1:
                        _seq_val = _seq_inherit          # V2 inheritance (ADDED only)
                    if _seq_val is None:
                        continue                          # unknown → global-apply baseline
                    try:
                        _data_seq_map[str(_seq_fp)] = int(_seq_val)
                    except (TypeError, ValueError):
                        continue
            if _data_seq_map:
                _out_meta["data_seq_by_path"] = _data_seq_map
                logger.info(
                    "[iceberg_mor] eq-delete seq scoping armed: data seq known "
                    "for %d file(s) (aligned=%s)", len(_data_seq_map), _seq_aligned)
        except Exception as _seq_map_exc:
            logger.debug("[iceberg_mor] data seq map build failed (fail-open "
                         "→ global apply): %s", _seq_map_exc)

    # BF-296/297: emit stage timings into the per-execution stage tracker
    # so the user can see "metadata=0.2s manifests=14.8s" in execution
    # details.  _out_meta is the channel back to the API layer, so we
    # also stash the breakdown there for cache-fingerprint callers.
    if _out_meta is not None:
        _out_meta.setdefault("iceberg_timing", {})
        _out_meta["iceberg_timing"]["metadata_seconds"] = round(_bf296_metadata_seconds, 3)
        _out_meta["iceberg_timing"]["manifests_seconds"] = round(_bf296_manifests_seconds, 3)
        _out_meta["iceberg_timing"]["cache_hit"] = _bf296_cache_hit
        _out_meta["iceberg_timing"]["manifests_read"] = len(_manifest_paths)
    # Phase 160 (2026-07-01) — attribute iceberg metadata walk +
    # manifest scan to the ``metadata`` stage of the per-query
    # latency breakdown.  No-op when no breakdown is active.  Runs
    # BEFORE the DuckDB subprocess so the ``compute`` stage stays
    # clean.
    try:
        from core.brain_latency_breakdown import record_stage as _lb_rec
        _lb_rec("metadata",
                float(_bf296_metadata_seconds) + float(_bf296_manifests_seconds))
    except Exception as _lb_exc:                                      # pragma: no cover
        # 2026-07-02 -- debug-log so a systematic latency-breakdown
        # attach failure surfaces in ops greps.  Never breaks read.
        logger.debug(
            "iceberg_reader: record_stage('metadata') "
            "suppressed %s: %s",
            type(_lb_exc).__name__, _lb_exc,
        )

    # 2026-06-03 — explicit cache-vs-S3 diagnostic for the "we should
    # not silently fail when iceberg cache is empty" follow-up.
    # Operators can read this from /api/admin/executions/{id}/stage to
    # confirm a query went cache → S3 → pruned correctly, OR to see
    # that it fell open due to partial manifest reads.
    #
    # 2026-07-02 hotfix -- this block + the record_pruning() call
    # below were previously INDENTED INSIDE the except-lb_exc handler
    # (pre-existing structural bug caught by the silent-except refactor
    # audit).  That meant the healthy path (99.9% of queries where the
    # latency stage record succeeds) NEVER emitted the pruning
    # diagnostic -- exactly the opposite of the fix's intent.
    # De-indented to function scope so the diagnostic fires on every
    # query regardless of latency-record outcome.
    # 2026-08-22 — the de-indent dropped the None guard: any caller that
    # passes no _out_meta crashed HERE with a TypeError on the walk path
    # (latent; production callers all pass a dict).  Guarded.
    if _out_meta is not None:
        _out_meta["iceberg_cache_diagnostic"] = dict(_cache_diag)

    # 2026-06-03 — also push to the per-execution diagnostic store
    # so the admin Query Diagnostic UI can surface "got column stats
    # from S3" / "pruned X of Y files" without round-tripping
    # _out_meta through the query result.  Best-effort: failure
    # must NEVER break the query path.
    _exec_id = ((_out_meta.get("execution_id")
                 or _out_meta.get("correlation_id"))
                if isinstance(_out_meta, dict) else None)
    if not _exec_id:
        # Fall back to thread-local set at the top of the query path
        # (execute_api / multi_worker_dispatcher).  Avoids threading
        # a new kwarg through 4 modules.
        try:
            from core.query_diagnostic_store import get_current_execution_id
            _exec_id = get_current_execution_id()
        except Exception as _gid_exc:                                 # pragma: no cover
            # 2026-07-02 -- was silent pass; debug-log for greppability.
            logger.debug(
                "iceberg_reader: get_current_execution_id "
                "suppressed %s: %s",
                type(_gid_exc).__name__, _gid_exc,
            )
            _exec_id = None
    if _exec_id:
        # 2026-06-03 — initial diagnostic capture: source label +
        # manifest counts.  `files_after_prune` (actual data-file
        # count) is patched in by a second record_pruning() call at
        # the end of this function, once `result` is built.  Was a
        # bug: previously reported len(_manifest_paths) (1-30) as
        # "files after prune", confusing operators reading the
        # admin diagnostic UI.
        try:
            from core.query_diagnostic_store import record_pruning
            # Decide the source label based on what actually happened.
            # 2026-06-03 — fixed: was checking cache_state == "fresh"
            # but that string is NEVER assigned anywhere (actual
            # values are: empty | hit | miss | force_fresh | disabled).
            if _cache_diag.get("s3_read_path"):
                _source = "s3_fallback"
            elif _cache_diag.get("cache_state") == "hit":
                _source = "cache"
            else:
                _source = _cache_diag.get("cache_state") or "unknown"
            record_pruning(str(_exec_id), {
                "source":               _source,
                "cache_state":          _cache_diag.get("cache_state"),
                "manifests_attempted":  _cache_diag.get("manifests_attempted"),
                "manifests_succeeded":  _cache_diag.get("manifests_succeeded"),
                "manifests_failed":     _cache_diag.get("manifests_failed"),
                "strict_mode":          _cache_diag.get("strict_mode"),
                "metadata_seconds":     round(_bf296_metadata_seconds, 3),
                "manifests_seconds":    round(_bf296_manifests_seconds, 3),
                "cache_hit":            _bf296_cache_hit,
                "manifests_count":      len(_manifest_paths),
                "snapshot_id":          (_out_meta.get("snapshot_id")
                                         if isinstance(_out_meta, dict)
                                         else None),
                "schema_evolution":     bool(
                    isinstance(_out_meta, dict)
                    and _out_meta.get("iceberg_schema_evolution")),
            })
        except Exception as _rp_exc:                                  # pragma: no cover
            # 2026-07-02 -- was silent pass; debug-log for greppability.
            # Strictly best-effort — admin diagnostic must not break
            # the user's query path.
            logger.debug(
                "iceberg_reader: record_pruning suppressed %s: %s",
                type(_rp_exc).__name__, _rp_exc,
            )
    # One-line INFO so pod logs show the cache/S3 decision per query
    # without an admin UI lookup.  Quiet on cache HIT (the common case);
    # loud on miss + partial.
    if _cache_diag["s3_read_path"]:
        logger.info(
            "ICEBERG-CACHE: %s/%s snapshot=%s state=%s manifests=%d/%d "
            "s3_fetched=%d cached=%d failed=%d strict=%s",
            bucket, table_prefix, _bf296_snap_key or "?",
            _cache_diag["cache_state"],
            _cache_diag["manifests_succeeded"], _cache_diag["manifests_attempted"],
            len(_manifests_fetched_from_s3),
            max(0, _cache_diag["manifests_attempted"]
                   - len(_manifests_fetched_from_s3)),
            _cache_diag["manifests_failed"], _cache_diag["strict_mode"],
        )
    # BF-297/BF-310-fix: also forward to the per-execution stage tracker
    # via the download ContextVar so the execution detail UI gets the
    # same data without each caller having to thread _out_meta through.
    # Use the FULL table_prefix as the qualifier (not just the leaf
    # name) so two tables with the same name in different schemas
    # don't collide and overwrite each other's metrics.
    try:
        from core.duckdb_views import _DL_EXEC_ID_CTX as _exec_ctx
        _exec_id_for_track = _exec_ctx.get(None)
    except Exception:
        _exec_id_for_track = None
    if _exec_id_for_track:
        try:
            from core.execution_stage import add_extras as _stg_extras
            # Sanitise the prefix so it's a valid extras key — replace
            # path separators with dots, strip trailing slash.
            _table_qual = table_prefix.rstrip("/").replace("/", ".") or "_unknown"
            _stg_extras(
                _exec_id_for_track,
                **{
                    f"iceberg_meta_seconds__{_table_qual}":
                        round(_bf296_metadata_seconds, 3),
                    f"iceberg_manifests_seconds__{_table_qual}":
                        round(_bf296_manifests_seconds, 3),
                    f"iceberg_cache_hit__{_table_qual}":
                        bool(_bf296_cache_hit),
                    f"iceberg_manifests_read__{_table_qual}":
                        len(_manifest_paths),
                },
            )
        except Exception as _be_exc:
            note_best_effort("_stg_extras(...)", _be_exc,
                             logger=logger)

    data_file_keys: List[str] = []
    # 2026-08-20: dedup identity is (effective bucket, key) — see the
    # manifest dedup above.  Maps key → effective bucket of first reference.
    _seen_data_file_keys: Dict[str, str] = {}  # 2026-07-13: dedup guard (phantom count)
    _dup_data_file_refs = 0
    _foreign_data_file_refs: List[str] = []    # 2026-08-20: NOT duplicates
    _record_counts: List[int] = []  # per-file record_count from Iceberg manifests
    # 2026-06-04 — capture per-file size from the manifest so the
    # keys_only=True short-circuit can still produce a sortable list
    # for ScanStrategist file_order ordering.  Iceberg manifests carry
    # file_size_in_bytes as a standard field (spec v1+).  Pre-fix the
    # keys_only path returned size-less dicts and order_files would no-op.
    _file_sizes:    List[int] = []
    _hit_limit = False
    # Phase 139 (Tier 1.1): track files considered/pruned for Prometheus telemetry
    _ice_files_considered = 0
    _ice_skipped_partition = 0
    _ice_skipped_col_stats = 0
    # ── 2026-07-16 COMPLETENESS CONTROL · Tier 1 PRUNE RECEIPT ───────────
    # Capped, per-file audit of WHY each file was pruned, so every prune is
    # auditable offline at ZERO scan cost.  Bounded by prune_receipt_max so
    # a huge scan can't blow up memory; predicate strings are precomputed
    # ONCE (not per file).  Pure diagnostic — never affects survival.
    _prune_receipt_entries: List[Dict[str, Any]] = []
    try:
        from core.completeness_control import prune_receipt_max as _cc_prcap
        _prune_receipt_cap = _cc_prcap()
    except Exception:
        _prune_receipt_cap = 200
    try:
        _prcpt_pred_part = str(partition_filters)[:180] if partition_filters else None
    except Exception:
        _prcpt_pred_part = None
    def _prcpt(reason: str, file_key: str, predicate=None, bounds=None) -> None:
        try:
            if len(_prune_receipt_entries) < _prune_receipt_cap:
                _prune_receipt_entries.append({
                    "file": file_key, "reason": reason,
                    "predicate": predicate, "bounds": bounds})
        except Exception as _be_exc:
            note_best_effort("_prune_receipt_entries.append(...)", _be_exc,
                             logger=logger)

    # (The pruning gate -- ``_gate`` / ``_gate_allow`` -- is armed above
    #  Step 4b since 2026-09-28, so manifest-summary drops are gated too.)

    def _gate_partition_record() -> dict:
        """Decision inputs for a partition-stage drop (built ONLY on drop)."""
        _eng = []
        for (_gp_field, _gp_ct, _gp_ctl, _gp_op, _gp_val, _gp_val_str,
             _gp_tk, _gp_tp, _gp_tst, _gp_fcl) in _resolved_pf:
            _gp_raw = partition.get(_gp_field)
            try:
                _gp_dec = (_decode_partition_value(_gp_raw, _gp_ct)
                           if _gp_raw is not None else None)
            except Exception:
                _gp_dec = None
            _eng.append({
                "field": _gp_field, "col_type": _gp_ct, "op": _gp_op,
                "val": (_gp_val if isinstance(_gp_val, (list, tuple))
                        else (_gp_val_str if _gp_val_str is not None else _gp_val)),
                "decoded": (str(_gp_dec) if _gp_dec is not None else None),
            })
        return {"partition": partition, "engaged": _eng}

    def _gate_stats_record(_gs_df: dict) -> dict:
        """Decision inputs for a column_stats (manifest bounds) drop."""
        _gs_b: Dict[str, tuple] = {}
        _gs_nc: Dict[str, int] = {}
        _gs_lb = _avro_kv_map(_gs_df.get("lower_bounds"))
        _gs_ub = _avro_kv_map(_gs_df.get("upper_bounds"))
        _gs_nvc = _avro_kv_map(_gs_df.get("null_value_counts"))
        for _gs_f in (_non_partition_filters or []):
            _gs_c = (_gs_f.get("col") or _gs_f.get("column")
                     or "").split(".")[-1].lower()
            _gs_fid = (_col_stats_name_to_fid or {}).get(_gs_c)
            if _gs_fid is None:
                continue
            _gs_ft = (_col_stats_fid_to_type or {}).get(_gs_fid, "string")
            _gs_lo_raw = _gs_lb.get(_gs_fid, _gs_lb.get(str(_gs_fid)))
            _gs_hi_raw = _gs_ub.get(_gs_fid, _gs_ub.get(str(_gs_fid)))
            try:
                _gs_lo = (_decode_bound(bytes(_gs_lo_raw), _gs_ft)
                          if isinstance(_gs_lo_raw, (bytes, bytearray)) else None)
                _gs_hi = (_decode_bound(bytes(_gs_hi_raw), _gs_ft)
                          if isinstance(_gs_hi_raw, (bytes, bytearray)) else None)
            except Exception:
                _gs_lo = _gs_hi = None
            _gs_b[_gs_c] = (_gs_lo, _gs_hi)
            _gs_n = _gs_nvc.get(_gs_fid, _gs_nvc.get(str(_gs_fid)))
            if isinstance(_gs_n, int):
                _gs_nc[_gs_c] = _gs_n
        return {"filters": _non_partition_filters, "bounds": _gs_b,
                "null_counts": _gs_nc,
                "record_count": _gs_df.get("record_count") or 0}

    def _gate_supp_record(_gsp_key: str, _gsp_rc) -> dict:
        """Decision inputs for a supplement-bounds drop."""
        _gsp_b: Dict[str, tuple] = {}
        _gsp_nc: Dict[str, int] = {}
        for _gsp_c, _gsp_t in ((_supplement_bounds.get(_gsp_key) or {}).items()
                               if _supplement_bounds else ()):
            if isinstance(_gsp_t, (tuple, list)) and len(_gsp_t) >= 2:
                _gsp_b[_gsp_c] = (_gsp_t[0], _gsp_t[1])
                if len(_gsp_t) > 2 and isinstance(_gsp_t[2], int):
                    _gsp_nc[_gsp_c] = _gsp_t[2]
        return {"filters": _non_partition_filters, "bounds": _gsp_b,
                "null_counts": _gsp_nc, "record_count": _gsp_rc or 0}

    # ── 2026-08-03 PER-STAGE DECIDABILITY — count where pruning FELL OPEN ─
    # "pruned 0" must be distinguishable from "could not decide".  Each
    # fail-open event (unresolved filter, stage exception) is counted here
    # and surfaced via _out_meta["pruning_decidability"].  Diagnostic only.
    _stage_fail_open: Dict[str, int] = {}

    def _fail_open(stage: str) -> None:
        _stage_fail_open[stage] = _stage_fail_open.get(stage, 0) + 1

    # Filter columns that are not partition fields.  Collected so the reader
    # says it ONCE with the full list, instead of one paragraph per column.
    _unresolved_pf_cols: List[str] = []

    # ── 2026-08-03 NULL-partition prune (prune MORE, safely) ─────────────
    # An EXPLICIT null partition value (field present in the manifest tuple,
    # value null — identity/bucket/truncate all null out together) means
    # every row in the file has NULL in that column, and SQL three-valued
    # logic excludes NULL from every comparison predicate (=, IN, ranges).
    # Distinct from an ABSENT field (spec evolution → no information → keep)
    # and from the hive-path __HIVE_DEFAULT_PARTITION__ sentinel (ambiguous
    # writer encoding → keep; manifest metadata is authoritative, the path
    # is not).  Kill switch: iceberg.prune_null_partition_values.
    try:
        from core.config import get as _cfg_np
        _null_prune_enabled = bool(_cfg_np(
            "iceberg", "prune_null_partition_values", True))
    except Exception:
        _null_prune_enabled = True
    _NULL_EXCLUDING_OPS = ("equals", "eq", "=", "==", "in",
                           "gt", ">", "greater_than",
                           "gte", ">=", "greater_equals",
                           "lt", "<", "less_than",
                           "lte", "<=", "less_equals")

    # ── BF-PRUNE-PERF: hoist filter preprocessing OUT of the per-file
    # loop ───────────────────────────────────────────────────────────
    # The previous code did .get()×3, .lower(), and a generator-walk
    # over partition_spec PER FILE PER FILTER.  On a 14k-entry × 3-filter
    # table that was 42k iterations of the same dict lookups → 100s+ on
    # Python.  Build a static list of resolved filters ONCE, then loop.
    _spec_lower = {k.lower(): k for k in (partition_spec or {})} if partition_spec else {}
    # BF-501 (2026-05-28) — when the table's partition spec has a
    # RENAMED field (e.g., ``bucket(16, flex_sap_company_code)`` →
    # partition field name ``flex_sap_company_code_bucket_16``), the
    # user writes their WHERE clause against the SOURCE column name
    # but ``partition_spec`` is keyed by partition FIELD name.  The
    # direct + lowercased lookups both fail, the filter is silently
    # SKIPPED, no pruning fires, every file gets scanned.
    # User report: "I have created bucket on columns and that column
    # is in where clause but still its scanning all files".
    # Fix: build the source→field map from the same metadata we just
    # read and try it as a third resolution tier.  Mirrors what
    # ``build_source_to_partition_field_map`` does for admin_api's
    # preview endpoint — now extends the same logic to every query
    # path (BQB / streaming / feed engine / reports) so pruning
    # ALWAYS engages when the user filters on a transform-renamed
    # source column.
    _src_to_part_lookup: dict = {}
    if use_pruning and partition_filters and partition_spec and metadata:
        try:
            _src_to_part_lookup = build_source_to_partition_field_map(metadata)
        except Exception as _s2p_exc:
            logger.debug("source→partition-field map failed (non-fatal): %s",
                         _s2p_exc)
    _resolved_pf: list = []   # [(part_field, col_type, col_type_lower, f_op, f_val, f_val_str, transform_kind, transform_param, transform_source_type)]
    # 2026-10-06: (part_field, op, f_val_str) -> the extractor's
    # ``literal_kind`` ("number" for an unquoted SQL number), read by the one
    # string-partition range decision.  A side map, so the 10-tuple every
    # unpacker above relies on keeps its shape.
    _resolved_pf_literal_kind: Dict[tuple, Optional[str]] = {}
    if use_pruning and partition_filters and partition_spec:
        import re as _re_pf_setup
        try:
            from core.iceberg_transforms import bucket_transform as _bucket_xf, truncate_transform as _trunc_xf
        except Exception:
            _bucket_xf = _trunc_xf = None
        for filt in partition_filters:
            f_col = filt.get("col") or filt.get("column", "")
            # BF-PART-FIRST (2026-07-22): strip a ``table.`` / ``schema.table.``
            # qualifier so ``fact_table.business_close_date`` resolves to the
            # partition field ``business_close_date`` — parity with the col-stats
            # path (line ~1919/7593), which already strips.  Without this, a
            # qualified filter matched NO partition field, silently downgraded to
            # weak min/max pruning, and never did partition-tuple elimination →
            # the whole ocean survived.
            f_col_bare = f_col.split(".")[-1] if f_col else ""
            f_op  = filt.get("op")  or filt.get("operator", "")
            f_val = filt.get("val") or filt.get("value", "")
            f_col_lower = f_col_bare.lower()
            part_field = partition_spec.get(f_col_bare) and f_col_bare
            if not part_field:
                part_field = _spec_lower.get(f_col_lower)
            # BF-501 — fall back to source→partition-field translation
            # when direct + lowercased lookups failed.  Common for
            # bucket/truncate/day transforms where the writer renamed
            # the partition field but the user filters by source name.
            if not part_field and _src_to_part_lookup:
                _mapped = _src_to_part_lookup.get(f_col_lower)
                if _mapped:
                    # The mapped name might itself need case-insensitive
                    # lookup against partition_spec (older specs sometimes
                    # mix case).  Try direct, then lowercased.
                    part_field = (partition_spec.get(_mapped) and _mapped) \
                        or _spec_lower.get(_mapped.lower())
                    if part_field:
                        logger.info(
                            "BF-501: translated filter column %r → partition "
                            "field %r via source-to-field map (pruning enabled)",
                            f_col, part_field,
                        )
            if not part_field:
                _fail_open("partition_filter_unresolved")
                # 2026-08-21 — was one INFO line PER COLUMN.  A 5-filter query
                # emitted five near-identical paragraphs restating the same
                # partition-field list, which is most of what an operator has
                # to scroll past to reach the numbers.  Collect them and say it
                # once, after the loop.
                _unresolved_pf_cols.append(str(f_col))
                logger.debug(
                    "Filter column %r does not match any partition field "
                    "(direct, lowercased, or source-to-field translation) — "
                    "skipping pruning for this filter.  Known partition "
                    "fields: %s.  Known source columns: %s.",
                    f_col, list(partition_spec.keys()),
                    list(_src_to_part_lookup.keys()),
                )
                continue
            col_type = partition_spec[part_field]
            col_type_lower = col_type.lower()
            # 2026-08-22 (design_s3_speed §4 Phase 1) — lower BETWEEN into
            # its two range conjuncts (>= lo AND <= hi) so the per-file
            # partition stage evaluates it with the EXISTING gte/lte arms,
            # including the temporal-interval guard that protects the
            # boundary day (the 2026-08-19 trap).  Before this, "between"
            # was simply not in the partition stage's op vocabulary: the
            # file was kept fail-open, so a range island's funnel re-check
            # could not tighten an over-wide serve.  Identity partitions
            # AND (2026-09-28) the day/hour/month/year transforms: the range
            # arms' temporal-interval veto (_temporal_identity_range_prune_
            # ok) decides those by PERIOD, which is why ``dt >= x`` pruned a
            # month(dt) table correctly while ``dt BETWEEN x AND x`` kept
            # everything (found live).  bucket/truncate stay out: their
            # token is not ordered by the value.
            _pf_expanded = [(f_op, f_val)]
            if (not col_type_lower.startswith(("_transform_bucket[",
                                               "_transform_truncate["))
                    and isinstance(f_val, (list, tuple)) and len(f_val) == 2):
                # Spelling comes from the ONE vocabulary — a local literal
                # set here is exactly the drift that killed the island.
                from core.filter_ops import classify as _fo_classify
                if _fo_classify(f_op) == "between":
                    _pf_expanded = [("greater_equals", f_val[0]),
                                    ("less_equals", f_val[1])]
            for f_op, f_val in _pf_expanded:
                # Strip DuckDB cast syntax once
                if isinstance(f_val, str):
                    _cm = _re_pf_setup.match(
                        r"^(?:DATE|TIMESTAMP|TIME)\s+'(.+)'$",
                        f_val, _re_pf_setup.IGNORECASE)
                    f_val_str = _cm.group(1) if _cm else str(f_val)
                else:
                    f_val_str = str(f_val) if f_val is not None else None
                # Detect transform once (parse the bracket params here, not per file)
                transform_kind = None
                transform_param = None
                transform_source_type = None
                if col_type.startswith("_transform_bucket["):
                    transform_kind = "bucket"
                elif col_type.startswith("_transform_truncate["):
                    transform_kind = "truncate"
                if transform_kind:
                    try:
                        bracket_open = col_type.index("[") + 1
                        bracket_close = col_type.index("]")
                        transform_param = int(col_type[bracket_open:bracket_close])
                        colon = col_type.index(":")
                        transform_source_type = col_type[colon + 1:]
                    except Exception:
                        transform_kind = None  # malformed → skip transform path
                _resolved_pf.append((
                    part_field, col_type, col_type_lower, f_op, f_val, f_val_str,
                    transform_kind, transform_param, transform_source_type, f_col_lower,
                ))
                if filt.get("literal_kind"):
                    _resolved_pf_literal_kind[(part_field, f_op, f_val_str)] = (
                        filt.get("literal_kind"))
    # 2026-10-06 -- the ONE decision for "may a range prune a STRING
    # partition?" (core.filter_ops.string_partition_range_decision), bound once
    # for the per-file stages below: the identity arm, column stats and the
    # supplement.  ``_string_partition_filter_cols`` names the filter columns
    # (as the filters spell them) that resolved to a STRING identity field.
    from core.filter_ops import (
        is_string_partition_type as _is_str_part_pf,
        string_partition_range_decision as _spd_pf,
    )
    _string_partition_filter_cols = {
        _t[9] for _t in _resolved_pf
        if _t[6] is None and not _t[2].startswith("_transform_")
        and _is_str_part_pf(_t[2])
    }
    # ── 2026-07-23 HIVE-PATH ISLAND fallback (funnel stage 1b) ────────────
    # When a partition predicate could NOT be matched to a spec field
    # (_resolved_pf missed it — spec unresolved under schema evolution /
    # field-id drift, or parse failure), fall back to pruning on the data
    # file's hive path segments (col=value/) at the SAME partition stage of
    # the per-file funnel — BEFORE col-stats / supplement / bloom — so every
    # downstream pruner and the join-key bound aggregation only ever see
    # ISLAND survivors, never the ocean.  This is what guarantees BOTH legs
    # of a JOIN carve to their island even when a leg's metadata spec is
    # unresolvable (island ⋈ island, never ocean ⋈ island).  Fail-open:
    # any error disables the fallback and keeps today's behaviour.
    _hive_island_constraints_list: Optional[List[tuple]] = None
    _hive_island_obs_cols: set = set()
    _hive_island_pruned = 0
    try:
        _hive_island_constraints_list = _hive_island_constraints(
            partition_filters,
            {t[9] for t in _resolved_pf},
            table_name,
        )
    except Exception as _hic_exc:
        _hive_island_constraints_list = None
        logger.debug("[hive-island] constraint build skipped (fail-open): %s",
                     _hic_exc)
    if _hive_island_constraints_list:
        logger.info(
            "[hive-island] fallback ARMED for %s (table_name=%s): spec-based "
            "partition pruning did not engage col(s) %s — files outside the "
            "hive-path island will be pruned at the partition stage.",
            table_prefix, table_name,
            [c for c, _ in _hive_island_constraints_list],
        )
    # ── 2026-08-23 ISLAND-EXACT — decide, then gather the undecided ──────
    # The one positive, provable signal that the evidence stages
    # (supplement / bloom / prunability profiling / footer capture) have
    # NOTHING left to narrow: every offered predicate was consumed by the
    # island as eq/IN on identity partition columns (static ledger from the
    # island builder), and every enumerated entry carries a partition value
    # the funnel's own exact arms decide — no reconciliation drift (dynamic
    # pass, see _compute_island_exactness).  Gated on PROOF: any refusal
    # keeps today's behaviour byte-for-byte, and says why.
    _island_exact_info = _compute_island_exactness(
        _all_entries, _resolved_pf, _p3_island_filters,
        _p3_island_coverage, table_prefix)
    _island_exact = bool(_island_exact_info.get("exact"))
    _island_decided_cols: set = set(
        _island_exact_info.get("decided_cols") or ())
    if _island_exact:
        logger.info(
            "[island-exact] %s: EXACT — every predicate is decided by "
            "partition values on col(s) %s (%d entr%s checked, %.1fms). "
            "Supplement / bloom / prunability / footer-capture evidence "
            "stages are SKIPPED: min/max of a single-valued identity "
            "partition can never contradict the value itself.",
            table_prefix, sorted(_island_decided_cols),
            _island_exact_info.get("checked_entries", 0),
            "y" if _island_exact_info.get("checked_entries") == 1 else "ies",
            _island_exact_info.get("elapsed_ms", 0.0))
    elif partition_filters:
        # The system must narrate the refusal, not only the action — an
        # unrecognised shape and a deliberate refusal must never be
        # indistinguishable (2026-08-21 lesson).
        logger.info(
            "[island-exact] %s: NOT exact (%s) — evidence stages run as "
            "before.", table_prefix,
            _island_exact_info.get("reason", "unknown"))
    if _out_meta is not None:
        _out_meta["island_exact"] = {
            "exact": _island_exact,
            "decided_cols": sorted(_island_decided_cols),
            "reason": _island_exact_info.get("reason"),
            "checked_entries": _island_exact_info.get("checked_entries", 0),
            "elapsed_ms": _island_exact_info.get("elapsed_ms", 0.0),
        }
    # Cache `_decode_partition_value` per (part_field, raw_val) within ONE
    # file iteration.  Two filters on the same partition column → one decode.
    # (Reset inside the loop per-entry below.)
    # BF-316 — track per-filter bound coverage so we can tell admin
    # WHICH filter columns lack writer-side stats.  filter_col → count of
    # files that actually had a non-empty lower_bound/upper_bound for it.
    _ice_bound_coverage: Dict[str, int] = {}
    if _non_partition_filters:
        for _f in _non_partition_filters:
            _fc = (_f.get("col") or _f.get("column") or "").split(".")[-1].lower()
            _ice_bound_coverage[_fc] = 0
    # 2026-07-15 (Finding #7) — SEPARATE, value-independent TABLE-LEVEL
    # stats-coverage counter.  ``_ice_bound_coverage`` above is incremented
    # only AFTER the partition-skip ``continue`` (survivor-based, value-
    # dependent — deliberately so, see the 2026-07-15 warning fix).  This
    # counter is measured over ALL enumerated (deduped) files BEFORE any
    # prune ``continue``, counting files that have manifest OR supplement
    # bounds per filter column — the true, filter-value-independent picture
    # of "can this table prune on column X at all".  Diagnostic only.
    _ice_stats_coverage_all: Dict[str, int] = {}
    _ice_stats_total_enumerated = 0
    _stats_cov_seen: set = set()
    if _non_partition_filters:
        for _f in _non_partition_filters:
            _fc = (_f.get("col") or _f.get("column") or "").split(".")[-1].lower()
            if _fc:
                _ice_stats_coverage_all[_fc] = 0
    # ── 2026-07-15 PRUNABILITY PROFILES (audit Finding #3/#4) ──────────
    # Per-(eq/in filter column) evidence accumulators, filled during the
    # per-file walk below from data ALREADY in hand (manifest bounds +
    # supplement rows — ZERO extra S3 I/O):
    #   evaluated              — files that reached the bound-evaluation
    #                            stage (survived partition pruning)
    #   with_bounds            — of those, files with manifest OR
    #                            supplement bounds for the column
    #   bounds_could_not_prune — files whose bounds CONTAINED the queried
    #                            eq/in value (or had no bounds at all) —
    #                            i.e. min/max could NOT prune the file
    #   singleton              — bounded files where min == max
    # PURE DIAGNOSTIC + build-routing input: never mutates any skip
    # decision; every consumer is wrapped fail-open.
    _prof_eq_in: List[Tuple[str, Dict[str, Any]]] = []
    _prof_counters: Dict[str, Dict[str, int]] = {}
    _prof_disabled_midscan = False
    if _non_partition_filters:
        try:
            from core.config import get as _cfg_prof_en
            _prof_enabled = bool(_cfg_prof_en(
                "iceberg", "prunability_profile_enabled", True))
        except Exception:
            _prof_enabled = True
        if _prof_enabled:
            try:
                for _f in _non_partition_filters:
                    _p_op = (_f.get("op") or _f.get("operator") or "").lower()
                    if _p_op not in ("=", "==", "eq", "equals", "in"):
                        continue
                    _p_val = _f.get("val") if "val" in _f else _f.get("value")
                    if _p_val is None:
                        continue
                    if _p_op == "in" and not (
                            isinstance(_p_val, (list, tuple)) and _p_val):
                        continue
                    _p_col = (_f.get("col") or _f.get("column")
                              or "").split(".")[-1].lower()
                    # 2026-08-23 island-exact: a partition-decided column
                    # would profile as 100% overlap (every SURVIVOR's
                    # bounds contain the matched value BY CONSTRUCTION) —
                    # a distorted profile that mis-routes bloom builds,
                    # plus a per-column DB upsert, for a question already
                    # answered.  Skip it.
                    if _island_exact and _p_col in _island_decided_cols:
                        continue
                    if _p_col and _p_col not in _prof_counters:
                        _prof_eq_in.append((_p_col, _f))
                        _prof_counters[_p_col] = {
                            "evaluated": 0,
                            "with_bounds": 0,
                            "bounds_could_not_prune": 0,
                            "singleton": 0,
                        }
            except Exception as _prof_init_exc:
                logger.debug("[prunability] init skipped (fail-open): %s",
                             _prof_init_exc)
                _prof_eq_in = []
                _prof_counters = {}

    # Phase Z (2026-06-09) — JOIN-PRUNER bounds aggregation is now
    # delegated to a unified BoundProviderRegistry.  Pre-Phase-Z, the
    # three sources (partition / manifest-stats / supplement) were
    # aggregated via three independent inline blocks; this caused the
    # supplement-only-join-key bug (the 1313-file regression) and made
    # adding a 4th source impossible.  See core/brain/bound_providers.py
    # for the abstraction.  ``_bound_aggregator`` is None when caller
    # doesn't request bounds; the per-file blocks below short-circuit
    # cheaply on that case.
    _bound_aggregator = None
    if join_key_columns:
        try:
            from core.brain.bound_providers import (
                BoundAggregator as _BA,
                BoundProviderRegistry as _BPR,
                ManifestStatsProvider as _MSP,
                PartitionValueProvider as _PVP,
                SupplementProvider as _SUP,
            )
            _providers = [
                _PVP(partition_spec=partition_spec,
                     decode_partition_value=_decode_partition_value),
                _MSP(col_to_fid=_col_stats_name_to_fid,
                     fid_to_type=_col_stats_fid_to_type,
                     decode_bound=_decode_bound),
                _SUP(),
            ]
            _bound_registry = _BPR(_providers)
            _bound_aggregator = _BA(_bound_registry, list(join_key_columns))
            # NOTE: the SupplementProvider is preloaded BELOW (after the
            # existing _supplement_bounds load runs), since we share the
            # data and don't want two DB round-trips.  Captured here so
            # we can drive the populate step from the same data source.
            _bound_supp_provider = _providers[2]
        except Exception as _bp_setup_exc:
            logger.warning(
                "BoundProviderRegistry setup failed (fail-open, no "
                "JOIN-PRUNER): %s", _bp_setup_exc,
            )
            _bound_aggregator = None
            _bound_supp_provider = None

    # BF-PRUNE-PERF: signal that we're entering the file-pruning phase
    # so heartbeats display "stage=file_prune" instead of generic init.
    _file_prune_t0 = _time.monotonic()
    _entry_total_for_log = sum(len(_e) for _e in _all_entries) if _all_entries else 0
    _signal_stage("file_prune",
                   message=f"Pruning {_entry_total_for_log} manifest entries against "
                           f"{len(_resolved_pf)} partition filter(s)",
                   files_total=_entry_total_for_log)

    # BF-COL-STATS: load supplement bounds for filter columns the writer
    # didn't track in manifest bounds.  One DB query, returns
    # {file_path: {col_lower: (lower, upper, null_count)}}.
    # BF-COL-STATS-V2: keyed on (bucket, table_prefix) — content identity
    # shared across QueryStudio connections.  Two connections (e.g. one
    # VPC, one non-VPC) for the same S3 bucket+prefix read from the same
    # supplement rows.  Skipped silently when db_manager not provided.
    _supplement_bounds: Dict[str, Dict[str, tuple]] = {}
    _ice_skipped_supplement = 0
    # 2026-07-15 pruning self-audit (opt-in, default OFF).  When enabled we record
    # WHICH files the supplement layer drops + the bound/filter that caused each,
    # and (if pruning_audit_verify_footers) footer-verify a sample against real
    # min/max to catch stale/wrong cached bounds.  None here = audit off = the
    # drop_reason arg passed to the pruner stays None = zero overhead.
    try:
        from core import pruning_audit as _pruning_audit
        _supp_audit_on = _pruning_audit.is_enabled()
    except Exception:
        _pruning_audit = None
        _supp_audit_on = False
    _supp_drop_trace: List[Dict[str, Any]] = [] if _supp_audit_on else []
    # BF-548 (2026-05-29): S3-side bloom filter pre-skip.  Off by
    # default because it adds a 256 KB suffix-range GET per file —
    # for non-selective workloads that's net-negative.  Operators
    # enable per-table or globally when they know their tables have
    # bloom-bearing equality predicates (high-cardinality cols like
    # account_id, customer_id, sap_company_code).
    _ice_skipped_bloom = 0
    _ice_skipped_bloom_sidecar = 0
    # 2026-09-27 -- (file, col) bloom decisions taken on a row that carries
    # no build-side type (pre-07-15 row or a 3-tuple double).  Reported in
    # scan_economics so an operator can see how much rests on the
    # encoder-unchanged proof rather than on a recorded stamp.
    _ice_bloom_untyped_decisions = 0
    try:
        from core.config import get as _cfg_get_bloom
        _bloom_check_enabled = bool(_cfg_get_bloom(
            "iceberg", "s3_bloom_check_enabled", False))
        # 149.4 (2026-06-09) — DB-backed bloom sidecar.  Separate config
        # flag from BF-548 native S3 bloom: sidecar bloom is cheap (1 DB
        # lookup at load time, no per-file S3 round trip).
        # 2026-09-27: default ON (read side joins the write side, which has
        # been building sidecars by default through warm-on-commit and
        # adaptive_prefetch).  History: 2026-07-15 the 210M->78M loss (a
        # STRING probe pruning a DATE-built bloom) added the probe-encoding
        # parity gate and turned the default OFF; 2026-07-22 (42f5a1c6 R5) a
        # brief default-ON was reverted because that gate proves the PROBE's
        # type only and could not see a row whose BITS were built by another
        # encoder.  Both objections are now closed at ONE chokepoint,
        # ``iceberg_bloom_sidecar.probe_parity_proven``: the row's recorded
        # BUILD-side type (column_type, written by every scan since
        # 0f026d97) is loaded with the bits and must agree with the probe
        # too; an untyped pre-07-15 row is trusted on the schema gate alone
        # because the encoder and hash are byte-identical to inception
        # (diffed 2026-09-27).  Proof, by the pruning-brain discipline (row
        # MULTISET, aggregates, files handed to read_parquet, adversarial
        # probes, per-file FP rate, gate mutation):
        # tests/test_bloom_read_on_proof_2026_09_27.py.  Operators can still
        # switch the reader off with iceberg.bloom_sidecar_enabled=false.
        _bloom_sidecar_enabled = bool(_cfg_get_bloom(
            "iceberg", "bloom_sidecar_enabled", True))
    except Exception:
        _bloom_check_enabled = False
        _bloom_sidecar_enabled = False
    # 149.4 — per-query bloom lookup map populated below, mirrors
    # _supplement_bounds shape: {file_path: {col_lower: (bits, num_bits, k)}}.
    _bloom_sidecar_bounds: Dict[str, Dict[str, Tuple[bytes, int, int]]] = {}
    _bloom_eq_in_cols: List[str] = []   # hoisted for the end-of-fn coverage diag + self-heal
    # 2026-07-15 DATA-LOSS GUARD: column iceberg types so the sidecar CONSUME
    # loop can verify the probe's byte-encoding matches the bloom's build side
    # before trusting an "absent" verdict (see _bloom_probe_encoding_safe).
    _bloom_col_types: Dict[str, str] = {}
    # BF-370: snapshot_id no longer required — supplement is keyed on
    # (bucket, prefix, file_path) since data files are immutable across
    # snapshots.  When the table rolls forward to a new snapshot, files
    # from the prior snapshot still match.
    # 2026-06-09 — include join_key_columns in the supplement load too.
    # Pre-fix the supplement was loaded ONLY for non-partition WHERE
    # filter columns, so JOIN-PRUNER never got bounds for join keys
    # that weren't in the WHERE clause.  User's 1313-file case: actual
    # join key existed in column_stats_supplement_v2 with narrow per-
    # file bounds, but iceberg_reader never asked the DB for those
    # rows — so the supplement aggregator silently saw zero coverage.
    _should_load_supp = (
        db_manager is not None and bucket and table_prefix
        and (_non_partition_filters or join_key_columns)
    )
    # ── 2026-08-03 ISLAND-SCOPED METADATA LOADS ─────────────────────────
    # Don't pay for metadata that partition pruning will never consult:
    # scope the supplement + bloom DB fetches to the hive-path island
    # derived from the manifest entries already in memory.  None → full
    # fetch (today's behaviour).  Evidence-only: cannot change which files
    # can be pruned, only which files carry prune-evidence (fail-open).
    # NOTE: deliberately DISABLED when join_key_columns is set — the
    # JOIN-PRUNER aggregates supplement bounds across surviving files and
    # partition-stage survivorship can be broader than the hive island
    # (undecodable tuples are kept), so scoping there could narrow the
    # aggregated join-key bounds → tighter synth filters on the OTHER
    # table → potential data loss.  Filter-evidence use is safe; bound
    # AGGREGATION for another table is not.
    _island_scope_paths: Optional[List[str]] = None
    if _should_load_supp and not join_key_columns:
        try:
            from core.config import get as _cfg_iss
            _iss_enabled = bool(_cfg_iss(
                "iceberg", "metadata_load_island_scope", True))
            _iss_max = int(_cfg_iss(
                "iceberg", "metadata_load_island_scope_max_paths", 2000))
        except Exception:
            _iss_enabled, _iss_max = True, 2000
        if _iss_enabled:
            _island_scope_paths = _island_scope_file_keys(
                _all_entries, partition_filters, table_name,
                max_paths=_iss_max)
            if _island_scope_paths is not None:
                logger.info(
                    "[island-scope] %s: supplement/bloom DB loads scoped to "
                    "%d island file(s) (of %d enumerated) — metadata fetch "
                    "scales with the ISLAND.",
                    table_prefix, len(_island_scope_paths),
                    sum(len(_e or []) for _e in (_all_entries or [])))
    # ── 2026-08-23 ENUMERATION-BOUNDED evidence fetch ────────────────────
    # When the hive-island scope stood down (join_key_columns present, non-
    # hive layout, OR-groups, over-cap island), the supplement/bloom loads
    # used to be bounded by NOTHING — O(store rows), and the store is
    # snapshot-agnostic so it only ever grows.  Bound them by the
    # ENUMERATION instead (see _enumeration_scope_file_keys for the proof
    # that this is a pure fetch-strategy change).  The island scope, when
    # present, is strictly narrower and keeps priority.
    _evidence_scope_paths: Optional[List[str]] = _island_scope_paths
    _evidence_scope_kind: str = (
        "island" if _island_scope_paths is not None else "full")
    if _evidence_scope_paths is None and _should_load_supp:
        try:
            from core.config import get as _cfg_ens
            _ens_enabled = bool(_cfg_ens(
                "iceberg", "metadata_load_enum_scope", True))
            _ens_max = int(_cfg_ens(
                "iceberg", "metadata_load_enum_scope_max_paths", 20000))
        except Exception:
            _ens_enabled, _ens_max = True, 20000
        if _ens_enabled:
            _evidence_scope_paths = _enumeration_scope_file_keys(
                _all_entries, max_paths=_ens_max)
            if _evidence_scope_paths is not None:
                _evidence_scope_kind = "enum"
                logger.info(
                    "[enum-scope] %s: supplement/bloom DB loads bounded by "
                    "the ENUMERATION — %d file key(s).  A file absent from "
                    "the enumeration cannot survive, cannot be aggregated "
                    "and cannot carry evidence; the store's other rows are "
                    "other snapshots' files.",
                    table_prefix, len(_evidence_scope_paths))
    # 2026-06-09 — hoisted out of the try block so Phase Z's
    # SupplementProvider populate can read it unconditionally
    # below.  Default empty when the supplement load doesn't run.
    _filter_cols_lower: List[str] = []
    if _should_load_supp:
        try:
            _filter_cols_lower = list({
                (f.get("col") or f.get("column") or "").split(".")[-1].lower()
                for f in (_non_partition_filters or [])
                if (f.get("col") or f.get("column"))
            })
            # Also load supplement for join key columns the caller wants
            # bounds on (so the JOIN-PRUNER supplement-source aggregator
            # has data to work with).  Dedupe against filter cols.
            for _jkc in (join_key_columns or []):
                if not _jkc:
                    continue
                _jkc_lower = str(_jkc).split(".")[-1].lower()
                if _jkc_lower not in _filter_cols_lower:
                    _filter_cols_lower.append(_jkc_lower)
            # 2026-08-23 island-exact: partition values decide these
            # columns for every enumerated file — their supplement rows
            # can only agree (correct bounds of a single-valued identity
            # partition are lo = hi = the value).  A JOIN KEY is never
            # dropped: the aggregator needs its bounds regardless of what
            # the filters decided.
            if _island_exact and _filter_cols_lower:
                _jk_keep = {str(_j).split(".")[-1].lower()
                            for _j in (join_key_columns or []) if _j}
                _ie_dropped = [c for c in _filter_cols_lower
                               if c in _island_decided_cols
                               and c not in _jk_keep]
                if _ie_dropped:
                    _filter_cols_lower = [
                        c for c in _filter_cols_lower
                        if c not in _ie_dropped]
                    logger.info(
                        "[island-exact] %s: supplement fetch skipped for "
                        "island-decided col(s) %s%s.",
                        table_prefix, sorted(_ie_dropped),
                        (" — nothing left to load"
                         if not _filter_cols_lower else
                         f"; still loading {sorted(_filter_cols_lower)} "
                         f"for the JOIN-PRUNER"))
            if _filter_cols_lower:
                # 2026-07-13 — load supplement bounds through the SINGLE grain-
                # routing chokepoint: it reads the per-file v3 table under
                # grain=v3 (every file carries ALL columns), else the Phase 160
                # brain store (store-first, DB-fallback).  Same
                # {file_path:{col:(lo,hi,nulls,rc)}} shape either way.
                # ``_fs_grain`` is still resolved for the empty-load diagnostic
                # probe below (it must query the right table).
                try:
                    from core import config as _qs_cfg_grain
                    _fs_grain = _qs_cfg_grain.iceberg_file_stats_grain()
                except Exception:
                    _fs_grain = "v3"
                _snap_for_supp = (
                    str(effective_snapshot_id) if effective_snapshot_id else "")
                from core.brain_duckdb_store import (
                    get_col_stats_for_snapshot_via_store,
                )
                _raw_supp = get_col_stats_for_snapshot_via_store(
                    db_manager,
                    bucket=bucket,
                    table_prefix=table_prefix.rstrip("/"),
                    snapshot_id=_snap_for_supp,
                    column_names=_filter_cols_lower,
                    # 2026-08-03 — island-scoped fetch; 2026-08-23 —
                    # enumeration-bounded when the island stands down
                    # (None = full).  See _island_scope_file_keys /
                    # _enumeration_scope_file_keys: evidence-only, fail-open.
                    file_paths=_evidence_scope_paths,
                )
                # Lowercase keys for case-insensitive match against filter cols
                for _fp, _cols in (_raw_supp or {}).items():
                    _supplement_bounds[_fp] = {
                        (k or "").lower(): v for k, v in (_cols or {}).items()
                    }
                if _supplement_bounds:
                    logger.info(
                        "BF-COL-STATS: loaded supplement bounds for %s — "
                        "%d files have supplement entries for cols=%s "
                        "(snapshot-agnostic lookup)",
                        table_prefix,
                        len(_supplement_bounds), _filter_cols_lower,
                    )
                    # 2026-06-09 brain LEARNING — if a col previously
                    # failed-hard but now has supplement data, the
                    # operator must have fixed the underlying cause
                    # (IAM / snapshot).  Clear the auto-heal block
                    # for that col so BF-547 can scan it again.
                    try:
                        _supp_cols_now = set()
                        for _file_cols in _supplement_bounds.values():
                            _supp_cols_now.update(_file_cols.keys())
                        _unblock_auto_heal_if_supplement_arrived(
                            bucket, table_prefix, _supp_cols_now,
                        )
                    except Exception as _be_exc:
                        note_best_effort("_unblock_auto_heal_if_supplement_arrived(...)", _be_exc,
                                         logger=logger)
                else:
                    # Deep-dive diagnostic: when supplement load returns empty,
                    # tell the user EXACTLY why.  Two common causes:
                    #   (a) scan ran for DIFFERENT columns than the filter uses
                    #   (b) scan stored under DIFFERENT bucket+prefix
                    # Issue a probe query with NO column filter to see what
                    # IS in supplement for this bucket+prefix.
                    _probe_cols: list = []
                    _probe_files = 0
                    try:
                        _norm_prefix = table_prefix.rstrip("/")
                        _probe_cols_set: set = set()
                        _probe_files_set: set = set()
                        with db_manager.get_session(read_only=True) as _sess:
                            if _fs_grain == "v3":
                                from core.db.models import IcebergFileStats as _IMF
                                for _row in _sess.query(_IMF).filter(
                                    _IMF.bucket == bucket,
                                    prefix_matches(_IMF.table_prefix, _norm_prefix),
                                ).limit(2000).all():
                                    if _row.file_path:
                                        _probe_files_set.add(_row.file_path)
                                    _cs = _row.column_stats or {}
                                    if isinstance(_cs, dict):
                                        _probe_cols_set.update(
                                            (k or "").lower() for k in _cs)
                            else:
                                from core.db.models import (
                                    IcebergColumnStatsSupplement as _IMCC2)
                                for _cn, _fp in _sess.query(
                                    _IMCC2.column_name, _IMCC2.file_path,
                                ).filter(
                                    _IMCC2.bucket == bucket,
                                    prefix_matches(_IMCC2.table_prefix, _norm_prefix),
                                ).limit(2000).all():
                                    if _cn:
                                        _probe_cols_set.add((_cn or "").lower())
                                    if _fp:
                                        _probe_files_set.add(_fp)
                        _probe_cols = sorted(_probe_cols_set)
                        _probe_files = len(_probe_files_set)
                    except Exception as _probe_err:
                        logger.debug(
                            "[col-stats] supplement diagnostic probe failed: %s",
                            _probe_err,
                        )

                    if _probe_files == 0:
                        logger.warning(
                            "BF-COL-STATS: NO supplement rows AT ALL for "
                            "bucket=%s prefix=%s. Scan never ran for this "
                            "bucket/prefix, OR scan ran under a different "
                            "(bucket, table_prefix) tuple. Check the admin "
                            "Column Stats page — what bucket+prefix did you "
                            "scan? Must match exactly (incl. trailing slashes).",
                            bucket, table_prefix.rstrip("/"),
                        )
                    else:
                        logger.warning(
                            "BF-COL-STATS: supplement HAS %d files for "
                            "bucket=%s prefix=%s but NONE cover your filter "
                            "cols=%s.  Scanned cols in DB: %s.  Likely cause: "
                            "you scanned different columns than the filter "
                            "needs.  Re-run scan with the right columns "
                            "selected (or scan ALL columns).",
                            _probe_files, bucket, table_prefix.rstrip("/"),
                            _filter_cols_lower, _probe_cols[:20],
                        )
        except Exception as _supp_load_exc:
            logger.debug(
                "BF-COL-STATS: supplement load failed (fail-open): %s",
                _supp_load_exc,
            )

    # 149.4 (2026-06-09) — bloom sidecar load.  Mirrors the supplement-
    # bound load above but pulls bloom bytes for the equality-filter
    # columns.  Restricted to EQ + IN filters since bloom only supports
    # those operators.  When no eq/in filters exist, the load is a no-op
    # (zero DB roundtrip).  When the sidecar table is empty (scanner
    # hasn't populated it yet), the load returns {} and per-file checks
    # below all fall through fail-open.
    # 2026-08-23 island-exact: every eq/in filter column is decided by
    # its partition value; a correct bloom (built over a single-valued
    # identity partition column) contains that value for every kept file
    # and can never prune one — skip the fetch.  _bloom_eq_in_cols stays
    # empty, which also parks the coverage-miss auto-bloom trigger below.
    if (db_manager is not None and bucket and table_prefix
            and _bloom_sidecar_enabled and _non_partition_filters
            and not _island_exact):
        try:
            _eq_in_cols_lower: List[str] = []
            for _f in _non_partition_filters:
                _op = (_f.get("op") or _f.get("operator") or "").lower()
                if _op in ("=", "==", "eq", "equals", "in"):
                    _bc = (_f.get("col") or _f.get("column") or "").split(".")[-1].lower()
                    if _bc and _bc not in _eq_in_cols_lower:
                        _eq_in_cols_lower.append(_bc)
            _bloom_eq_in_cols = list(_eq_in_cols_lower)  # hoist for end-of-fn diag
            if _eq_in_cols_lower:
                _bloom_sidecar_bounds = db_manager.iceberg_bloom_get_for_snapshot(
                    bucket=bucket,
                    table_prefix=table_prefix.rstrip("/"),
                    snapshot_id=str(effective_snapshot_id) if effective_snapshot_id else "",
                    column_names=_eq_in_cols_lower,
                    # 2026-08-03 — island-scoped fetch; 2026-08-23 —
                    # enumeration-bounded (None = full).  Evidence-only: an
                    # excluded file just loses its bloom row → kept
                    # (fail-open), never wrongly pruned.
                    file_paths=_evidence_scope_paths,
                    # 2026-09-27 — the row's BUILD-side type rides with the
                    # bits (4th element) so the consume loop can veto a
                    # probe the bitset was not built for.  A double that
                    # ignores the flag hands back 3-tuples; the loop reads
                    # either shape (built type None = untyped row).
                    include_types=True,
                )
                if _bloom_sidecar_bounds:
                    # Capture column types once so the per-file consume loop can
                    # apply the probe-encoding parity gate (a string probe must
                    # not prune a DATE/INT column — that was the 210M->78M bug).
                    _bloom_col_types = _iceberg_current_schema_col_types(metadata)
                    logger.info(
                        "149.4: loaded bloom sidecar for %s — %d files have "
                        "bloom rows for cols=%s (snapshot=%s)",
                        table_prefix, len(_bloom_sidecar_bounds),
                        _eq_in_cols_lower, effective_snapshot_id,
                    )
                else:
                    # ENABLED but the sidecar has ZERO rows for these columns ->
                    # it was never built -> NO file can be bloom-pruned (the
                    # "system_id IN (...) still scanned 4000 files" symptom).
                    # Say so loudly + actionably; the end-of-fn self-heal will
                    # kick off a background build so the next query prunes.
                    # 2026-09-27: with the reader ON by default this fires
                    # on every filtered query against an un-bloomed column,
                    # so it is a WARNING once per (table, columns) per
                    # process and INFO after that -- the line is always
                    # emitted (the system says what it declined to do), the
                    # channel is not flooded.  The owners are named: bloom
                    # is built by warm-on-commit for a table's DECLARED
                    # bloom_columns and by adaptive_prefetch for columns the
                    # query history ranks; auto_bloom_on_query_miss is off.
                    _nb_key = (table_prefix, tuple(_eq_in_cols_lower))
                    _nb_first = _nb_key not in _BLOOM_NO_ROWS_WARNED
                    if _nb_first:
                        _BLOOM_NO_ROWS_WARNED.add(_nb_key)
                    (logger.warning if _nb_first else logger.info)(
                        "bloom sidecar ENABLED for %s but has NO rows for filter "
                        "col(s)=%s (snapshot=%s) — nothing can be bloom-pruned for "
                        "them.  Declare the column in the table's bloom_columns "
                        "(Connections page; warm-on-commit builds it at the next "
                        "snapshot), let adaptive_prefetch rank it (>=3 filtered "
                        "queries), or build now: POST /api/admin/iceberg/bloom/scan.",
                        table_prefix, _eq_in_cols_lower, effective_snapshot_id,
                    )
        except Exception as _bloom_load_exc:
            logger.debug(
                "149.4: bloom sidecar load failed (fail-open): %s",
                _bloom_load_exc,
            )

    # Phase Z (2026-06-09) — feed the just-loaded _supplement_bounds
    # into the BoundProviderRegistry's SupplementProvider so the
    # JOIN-PRUNER per-file walk can consult it WITHOUT a duplicate DB
    # query.  When _bound_aggregator is None (caller didn't request
    # bounds), this is a no-op.
    if _bound_aggregator is not None and _bound_supp_provider is not None:
        try:
            _bound_supp_provider._bounds = dict(_supplement_bounds or {})
            _bound_supp_provider._loaded_cols = set(_filter_cols_lower)
            # join_key_columns are already included in _filter_cols_lower
            # via the Phase X follow-up dedupe above; no need to re-add.
        except Exception as _sup_feed_exc:
            logger.debug("SupplementProvider populate failed: %s", _sup_feed_exc)

    # BF-371: unified pruning summary — manifest AND supplement together.
    # Replaces the misleading early log that reported "no min/max" for
    # columns the supplement actually covers.
    # BF-377: strip table prefix when comparing — qualified filters
    # like ``a.system_id`` must match bare ``system_id`` keys.
    if _non_partition_filters:
        # Build the set of columns covered by ANY file's supplement entry.
        _supp_cols_lower: set = set()
        for _file_cols in _supplement_bounds.values():
            _supp_cols_lower.update(_file_cols.keys())
        # 2026-06-09 — report cols truthfully across BOTH sources.  Pre-
        # fix the log only put a col in with_supplement_stats if it
        # had NO manifest stats — but a col can have BOTH (manifest
        # was sparse / supplement filled gaps) and the user-facing
        # log called supplement empty even when 2956 files got
        # pruned by supplement bounds.  Now show full coverage:
        #   with_manifest_stats: cols whose manifest carried bounds
        #   with_supplement_stats: cols supplement covers (overlap OK)
        #   without_any_stats: cols with neither (brain CAN'T prune)
        _final_with_manifest = list(_pruning_summary_manifest_capable)
        _final_with_supplement = []
        _final_without_any = []
        # ALL filter cols — include both manifest-capable and missing
        # in the supplement check, since a col can have BOTH sources.
        _all_filter_cols = (
            list(_pruning_summary_manifest_capable)
            + list(_pruning_summary_manifest_missing)
        )
        for _fc in _all_filter_cols:
            _fc_bare_lower = _fc.split(".")[-1].lower()
            if _fc_bare_lower in _supp_cols_lower:
                _final_with_supplement.append(_fc)
        for _missing in _pruning_summary_manifest_missing:
            _missing_bare_lower = _missing.split(".")[-1].lower()
            if _missing_bare_lower not in _supp_cols_lower:
                _final_without_any.append(_missing)
        # 2026-08-23 island-exact: an island-decided column without
        # min/max stats is NOT "file pruning impossible" — partition
        # values prune it exactly; warning + auto-scan would be noise and
        # S3 cost for a question already answered.
        if _island_exact and _final_without_any:
            _ie_no_stats = [
                c for c in _final_without_any
                if c.split(".")[-1].lower() in _island_decided_cols]
            if _ie_no_stats:
                logger.info(
                    "[island-exact] %s: no-stats warning + auto-supplement "
                    "suppressed for island-decided col(s) %s — partition "
                    "values already prune them exactly.",
                    table_prefix, sorted(_ie_no_stats))
                _final_without_any = [
                    c for c in _final_without_any
                    if c not in _ie_no_stats]
        logger.info(
            "Iceberg pruning enabled for %s: filters_total=%d · "
            "with_manifest_stats=%s · with_supplement_stats=%s · "
            "without_any_stats=%s%s",
            table_prefix, len(_non_partition_filters),
            _final_with_manifest, _final_with_supplement, _final_without_any,
            f" · deduped {_pruning_summary_dropped} duplicate(s)"
            if _pruning_summary_dropped else "",
        )
        if _final_without_any:
            logger.warning(
                "Iceberg pruning: columns %s have NO min/max in manifest AND "
                "no supplement bounds — file pruning impossible for these. "
                "Action: run column-stats scan from admin UI for these columns.",
                _final_without_any,
            )
            # BF-547 (2026-05-28): auto-trigger an async column-stats sync
            # so the NEXT query benefits, even if the admin hasn't enabled
            # the background sync globally.
            #
            # 2026-06-09 DEEP-DIVE FIX — the original code at this site
            # referenced ``data_files`` which is UNDEFINED in scope here
            # (it's a parameter name in the helper function, not a local
            # in get_iceberg_data_files).  A NameError was raised on
            # every call but silently swallowed by the broad except
            # below (logged at DEBUG, invisible at the user's log
            # level).  Net effect: the auto-trigger has been DEAD CODE
            # for at least a month.  User's "still 1239 files" with
            # system_id having no bounds was the symptom — no scan
            # ever ran because no scan ever queued.
            #
            # Fix: build the file-key dicts from _all_entries (the
            # manifest entry list ALREADY parsed by this point) and
            # also bubble up the actual failure as a WARNING so the
            # next opaque skip is visible immediately.
            try:
                from core.config import get as _cfg_get_auto
                if bool(_cfg_get_auto(
                        "iceberg",
                        "auto_supplement_on_query_miss",
                        False)):
                    # Build a flat list of {key: ...} dicts from the
                    # manifest entries we already have in memory.  The
                    # helper only uses ``key`` / ``path`` so this is
                    # cheap (no S3 round-trips).
                    _bf547_data_files: List[Dict[str, Any]] = []
                    for _ents in (_all_entries or []):
                        for _ent in _ents:
                            if not isinstance(_ent, dict):
                                continue
                            _df_for_547 = _ent.get("data_file") or {}
                            if not isinstance(_df_for_547, dict):
                                continue
                            _fp_547 = (_df_for_547.get("file_path")
                                        or _df_for_547.get("path") or "")
                            if _fp_547.endswith(".parquet"):
                                _bf547_data_files.append({"key": _fp_547})
                    if _bf547_data_files:
                        _maybe_trigger_async_supplement_scan(
                            s3_client, bucket, table_prefix,
                            metadata, _bf547_data_files,
                            _final_without_any,
                            connection_id=_connection_id_from_s3_client(s3_client),
                        )
            except Exception as _auto_exc:
                # 2026-06-09 — surfaced from DEBUG → WARNING because
                # the previous DEBUG hid the NameError for weeks.  An
                # exception here means the brain WANTS to self-heal
                # but something stopped it; the operator needs to
                # see why.
                logger.warning(
                    "BF-547 auto-supplement trigger FAILED for %s "
                    "(type=%s): %s",
                    table_prefix, type(_auto_exc).__name__, _auto_exc,
                    exc_info=True,
                )

    # BF-508 (2026-05-28) — diagnostic sample of distinct partition values
    # actually seen during the scan, so when zero files survive pruning we
    # can log "filter wanted X but manifest only contained [Y, Z]".  User
    # has been reporting "still 0 rows" with no signal on whether the
    # partition values truly didn't match, or whether we mis-decoded them.
    _diag_partition_samples: Dict[str, set] = {}
    _DIAG_PARTITION_SAMPLE_CAP = 20
    # 2026-06-08 — log-once gates so a malformed entry shape (e.g. fastavro
    # returning a list instead of a dict for some schema-evolved manifests)
    # surfaces ONCE per table instead of aborting the WHOLE pruning pass and
    # losing join-key bounds for the anchor.  Previously a single bad entry
    # raised "'list' object has no attribute 'get'" which the Phase S
    # caller caught — but it caught for the WHOLE table, so anchor bounds
    # were silently dropped and the joined target over-scanned every file.
    _logged_bad_entry_shape = False
    _logged_bad_data_file_shape = False
    # 2026-08-03 (spec-evolution DATA-LOSS FIX): a POSITIONAL partition
    # tuple can only be attributed to field names when every spec's field
    # order is a prefix of the default spec's — otherwise dict(zip(
    # default_spec_keys, values)) can pair the wrong value with the wrong
    # column and prune on garbage.  Computed ONCE per query; entries in
    # _all_entries carry no per-manifest spec id, so when the layouts are
    # not provably consistent the positional shape is treated as "no
    # partition info" (KEEP — dict-shaped tuples are unaffected).
    _positional_zip_safe = _positional_partition_zip_safe(metadata)
    _logged_positional_zip_refusal = False
    # 2026-09-25 -- per-file column presence for the read plan: which
    # field-ids each SURVIVING data file physically stores, from the
    # manifest's column_sizes (value_counts / null_value_counts as fallbacks).
    # Observed exactly where a file joins data_file_keys, so the counts
    # describe the list DuckDB will read -- max_files truncation breaks the
    # loop after the append, so the two can never disagree.
    try:
        from core.iceberg_read_plan import ColumnPresenceAccumulator as _RPAcc
        _rp_presence = _RPAcc()
    except Exception:
        _rp_presence = None
    for entries in _all_entries:
        if _hit_limit:
            break
        for entry in entries:
            # Defensive: tolerate unexpected entry shapes so one malformed
            # entry doesn't abort the entire table's pruning pass.
            if not isinstance(entry, dict):
                if not _logged_bad_entry_shape:
                    logger.warning(
                        "Iceberg manifest entry has unexpected shape "
                        "(type=%s) for %s — skipping entry; pruning continues "
                        "on remaining entries.  Repr sample: %r",
                        type(entry).__name__, table_prefix, str(entry)[:200],
                    )
                    _logged_bad_entry_shape = True
                continue
            # status: 0=EXISTING  1=ADDED  2=DELETED
            if entry.get("status") == 2:
                continue
            data_file = entry.get("data_file") or {}
            if not isinstance(data_file, dict):
                if not _logged_bad_data_file_shape:
                    logger.warning(
                        "Iceberg data_file has unexpected shape (type=%s) "
                        "for %s — skipping entry; pruning continues.  "
                        "Repr sample: %r",
                        type(data_file).__name__, table_prefix,
                        str(data_file)[:200],
                    )
                    _logged_bad_data_file_shape = True
                continue
            file_path  = data_file.get("file_path") or data_file.get("path", "")
            if not file_path.endswith(".parquet"):
                continue
            _ice_files_considered += 1

            # 2026-07-15 (Finding #7) — table-level, value-independent stats
            # coverage.  Counted HERE, before ANY prune `continue` (empty-file
            # / partition / col-stats / supplement / bloom), deduped on
            # file_path so duplicate manifest refs don't inflate it.
            # Diagnostic only — never affects which files survive.
            if _ice_stats_coverage_all and file_path not in _stats_cov_seen:
                try:
                    _stats_cov_seen.add(file_path)
                    _ice_stats_total_enumerated += 1
                    _cov_lb = _avro_kv_map(data_file.get("lower_bounds"))
                    _cov_ub = _avro_kv_map(data_file.get("upper_bounds"))
                    _cov_supp = (_supplement_bounds.get(_s3_uri_to_key(file_path))
                                 if _supplement_bounds else None)
                    for _cov_col in _ice_stats_coverage_all:
                        _cov_fid = (_col_stats_name_to_fid.get(_cov_col)
                                    if _col_stats_name_to_fid else None)
                        _cov_has_manifest = _cov_fid is not None and (
                            _cov_fid in _cov_lb or str(_cov_fid) in _cov_lb
                            or _cov_fid in _cov_ub or str(_cov_fid) in _cov_ub)
                        _cov_has_supp = bool(_cov_supp) and _cov_col in _cov_supp
                        if _cov_has_manifest or _cov_has_supp:
                            _ice_stats_coverage_all[_cov_col] += 1
                except Exception as _be_exc:
                    note_best_effort("_ice_stats_coverage_all[_cov_col] += 1", _be_exc,
                                     logger=logger)

            # 2026-06-04 — empty-file fast skip.  Iceberg V2 delete files
            # can leave data files where record_count is 0 (every row
            # was tombstoned by a position delete).  Skipping these
            # avoids the open + footer read entirely.  No filter needed.
            _rc_val = data_file.get("record_count")
            if _rc_val is not None and _rc_val == 0:
                if _gate_allow("empty_file", file_path, record_count=_rc_val):
                    _ice_skipped_partition += 1   # roll into partition bucket for diagnostics
                    _prcpt("empty_file", file_path, predicate="record_count==0")
                    continue

            # 2026-06-08 — extract + coerce partition ONCE per entry so
            # both the filter-pruning block AND the JOIN-PRUNER partition-
            # bounds aggregator below see the same dict.  Some Iceberg
            # writers (and fastavro under spec-evolution scenarios) encode
            # the partition record as a list of positional values; coerce
            # using the FULL partition_spec key order so .get(field)
            # lookups succeed.
            partition = data_file.get("partition") or {}
            if isinstance(partition, (list, tuple)):
                if not _positional_zip_safe:
                    # Spec evolution with inconsistent field orders: the
                    # positional values CANNOT be attributed to columns.
                    # Treat as no-partition-info → file is KEPT by the
                    # partition stage (fail-open; wrong attribution here
                    # pruned on the WRONG column's value).
                    if not _logged_positional_zip_refusal:
                        logger.warning(
                            "Iceberg %s: positional partition tuples with "
                            "EVOLVED specs whose field orders diverge — "
                            "partition values cannot be attributed to "
                            "columns; partition pruning is skipped for "
                            "these entries (fail-open, dict-shaped entries "
                            "unaffected).", table_prefix)
                        _logged_positional_zip_refusal = True
                    partition = {}
                else:
                    try:
                        _spec_keys = list(partition_spec.keys()) if partition_spec else []
                        partition = dict(zip(_spec_keys, partition))
                    except Exception:
                        partition = {}
            elif not isinstance(partition, dict):
                partition = {}
            # Phase Z (2026-06-09) — write back the coerced partition so
            # downstream BoundProviderRegistry's PartitionValueProvider
            # sees the dict shape (its bounds_for does data_file.get
            # ("partition") to read the value).  Cheap dict mutation;
            # avoids threading a second parameter through the provider.
            if data_file.get("partition") is not partition:
                data_file["partition"] = partition

            # ── Entry-level partition pruning ─────────────────────────
            if _resolved_pf:
                # BF-508 diagnostic — capture distinct partition values per
                # filtered field so we can replay the mismatch on zero-files.
                if partition:
                    for (_dpf_field, _dpf_ctype, *_rest) in _resolved_pf:
                        _dpf_seen = _diag_partition_samples.setdefault(_dpf_field, set())
                        if len(_dpf_seen) < _DIAG_PARTITION_SAMPLE_CAP:
                            _dpf_raw = partition.get(_dpf_field)
                            if _dpf_raw is not None:
                                try:
                                    _dpf_dec = _decode_partition_value(_dpf_raw, _dpf_ctype)
                                    _dpf_seen.add(str(_dpf_dec)[:64])
                                except Exception:
                                    _dpf_seen.add(str(_dpf_raw)[:64])
                skip_file = False
                _skip_null = False
                # Per-file decode cache: same partition column queried by
                # multiple filters → decoded once.
                _decode_cache: dict = {}
                for (part_field, col_type, col_type_lower, f_op, f_val, f_val_str,
                     transform_kind, transform_param, transform_source_type, _f_col_lower) in _resolved_pf:
                    raw_val = partition.get(part_field)
                    if raw_val is None:
                        # 2026-08-03 — EXPLICIT null partition value (field
                        # PRESENT in the tuple, value null): every row in the
                        # file is NULL in this column, and NULL fails every
                        # comparison predicate (SQL 3VL) → provable drop.
                        # ABSENT field (spec evolution) = no information → keep.
                        # IS NULL / negation ops never prune here.
                        if (_null_prune_enabled
                                and part_field in partition
                                and f_op in _NULL_EXCLUDING_OPS
                                and f_val is not None):
                            skip_file = True
                            _skip_null = True
                            break
                        continue
                    _ck = part_field
                    if _ck in _decode_cache:
                        decoded, decoded_str = _decode_cache[_ck]
                    else:
                        decoded = _decode_partition_value(raw_val, col_type)
                        decoded_str = str(decoded) if decoded is not None else None
                        _decode_cache[_ck] = (decoded, decoded_str)

                    # ── Transform path (bucket / truncate) — params pre-parsed ──
                    if transform_kind == "bucket":
                        if _bucket_xf is None:
                            continue
                        if f_op == "in" and isinstance(f_val, list):
                            # 2026-07-15 DATA-LOSS FIX (audit Finding F3): strip
                            # DATE/TIMESTAMP cast wrappers before the transform
                            # (else bucket_transform("DATE '2025-09-30'") raises
                            # → None), AND fail-OPEN when NO value transforms
                            # (empty set): `decoded not in {}` is always True and
                            # would skip EVERY file.
                            _bvals = [_strip_partition_cast(_v) for _v in f_val]
                            _bucket_set = {str(_b) for _b in
                                           (_bucket_xf(_v, transform_param, transform_source_type) for _v in _bvals)
                                           if _b is not None}
                            if _bucket_set and decoded_str is not None and decoded_str not in _bucket_set:
                                skip_file = True
                                break
                            continue
                        if f_op in ("equals", "eq", "=", "=="):
                            _b = _bucket_xf(f_val, transform_param, transform_source_type)
                            if _b is not None and decoded_str is not None and str(_b) != decoded_str:
                                skip_file = True
                                break
                            continue
                        continue   # range/!= on bucket: can't prune
                    if transform_kind == "truncate":
                        if _trunc_xf is None:
                            continue
                        if f_op == "in" and isinstance(f_val, list):
                            # 2026-07-15 DATA-LOSS FIX (audit Finding F3): see
                            # bucket IN above — strip casts + fail-open on empty.
                            _tvals = [_strip_partition_cast(_v) for _v in f_val]
                            _truncs = {str(_t) for _t in
                                       (_trunc_xf(_v, transform_param, transform_source_type) for _v in _tvals)
                                       if _t is not None}
                            if _truncs and decoded_str is not None and decoded_str not in _truncs:
                                skip_file = True
                                break
                            continue
                        if f_op in ("equals", "eq", "=", "=="):
                            _t = _trunc_xf(f_val, transform_param, transform_source_type)
                            if _t is not None and decoded_str is not None and str(_t) != decoded_str:
                                skip_file = True
                                break
                            continue
                        if f_op in ("gte", ">=", "greater_equals", "gt", ">", "greater_than"):
                            _t = _trunc_xf(f_val, transform_param, transform_source_type)
                            if _t is None or decoded_str is None:
                                continue
                            # Type-aware, fail-safe (see _truncate_lower_prunes):
                            # numeric compare for numeric source, lexicographic
                            # for string, KEEP for unknown -- never false-skip.
                            if _truncate_lower_prunes(decoded_str, _t, transform_source_type):
                                skip_file = True
                                break
                            continue
                        continue   # < / <= / != on truncate: can't prune

                    # ── Identity-transform path ────────────────────────────────
                    # BF-PRUNE-PERF fix: original used regex-based DuckDB
                    # cast strip; the split("'") shortcut I tried first
                    # was wrong for values containing apostrophes.  Use
                    # the regex (compiled once at setup, pattern below).
                    # IN
                    if f_op == "in" and isinstance(f_val, list):
                        _set = {
                            (_re_pf_setup.match(r"^(?:DATE|TIMESTAMP|TIME)\s+'(.+)'$",
                                                str(v), _re_pf_setup.IGNORECASE).group(1)
                             if isinstance(v, str) and _re_pf_setup.match(
                                 r"^(?:DATE|TIMESTAMP|TIME)\s+'.+'$", v, _re_pf_setup.IGNORECASE)
                             else str(v))
                            for v in f_val
                        }
                        # BF-498 — same date-vs-timestamp normalisation for IN.
                        if decoded_str is not None and decoded_str not in _set:
                            # 2026-09-28 -- ONE temporal arm for = and IN:
                            # _partition_date_eq per member (date-prefix
                            # widening for date/timestamp/day/hour, INTERVAL
                            # overlap for every declared temporal type incl.
                            # month/year).  The inline date-prefix loop it
                            # replaces knew day/hour only, so ``dt IN
                            # ('1995-06-15')`` on month(dt) dropped every file.
                            _matched = any(
                                _partition_date_eq(decoded_str, _s, col_type)
                                for _s in _set)
                            # 2026-07-14 — fail-OPEN reconciliation: a synth
                            # join-key IN built from the OTHER table's
                            # partition-value spelling must still match this
                            # table's — numeric drift ("5"/"05"/"5.0") AND
                            # string drift (case / whitespace).  Only PREVENTS a
                            # skip → never drops a matching file.
                            if (not _matched
                                    and not _partition_value_numeric_match(decoded_str, _set)
                                    and not _partition_value_string_match(decoded_str, _set)):
                                skip_file = True
                                break
                        continue
                    # NOT IN
                    if f_op in ("not_in", "notin") and isinstance(f_val, list):
                        _set = {
                            (_re_pf_setup.match(r"^(?:DATE|TIMESTAMP|TIME)\s+'(.+)'$",
                                                str(v), _re_pf_setup.IGNORECASE).group(1)
                             if isinstance(v, str) and _re_pf_setup.match(
                                 r"^(?:DATE|TIMESTAMP|TIME)\s+'.+'$", v, _re_pf_setup.IGNORECASE)
                             else str(v))
                            for v in f_val
                        }
                        # 2026-07-22 (audit C5) DATA-LOSS FIX: EXACT-match
                        # exclusion ONLY.  BF-498 added date-prefix WIDENING so a
                        # bare-date filter matches a sub-day timestamp partition
                        # — but that widening is only fail-OPEN-safe for the
                        # positive IN/= path (it KEEPS files).  Reusing it to
                        # EXCLUDE on NOT IN drops a timestamp/day-partition file
                        # (value 2025-09-30 13:00:00) for NOT IN ('2025-09-30')
                        # even though its 13:00 rows satisfy the predicate →
                        # silent row loss.  Only skip a file whose partition
                        # value EXACTLY equals an excluded value; keep otherwise.
                        if decoded_str is not None and decoded_str in _set:
                            skip_file = True
                            break
                        continue
                    # EQ / NEQ — string compare against pre-stripped f_val_str
                    # BF-498 (2026-05-28) — when col_type is TIMESTAMP-like
                    # and the user typed a bare date (``YYYY-MM-DD``),
                    # ``_decode_partition_value`` returns a full
                    # ``"YYYY-MM-DD HH:MM:SS"`` string and the plain ``!=``
                    # excludes every file even though the user clearly
                    # meant "any timestamp on this date".  Normalise both
                    # sides to their date prefix when the filter value is
                    # exactly 10 chars in YYYY-MM-DD form.  Symmetric
                    # for the reverse case (user typed a timestamp,
                    # decoded is a date).
                    # (2026-08-23) _date_eq hoisted to module level as
                    # _partition_date_eq — pure function; the island-exact
                    # pre-pass must call the funnel's OWN arm, and a closure
                    # re-defined per filter iteration has no address.
                    _date_eq = _partition_date_eq
                    if f_op in ("equals", "eq", "=", "=="):
                        # 2026-07-15 DATA-LOSS FIX (audit Finding, EQ path): the
                        # IN and range branches guard `decoded_str is not None`
                        # / `cmp_decoded is None: continue`, but EQ did NOT.
                        # When _decode_partition_value returns None for a
                        # NON-None raw_val (bare decimal w/o scale, NaN/Inf
                        # float bound, struct-unpack failure), all three matchers
                        # below return False → skip_file=True → EVERY file
                        # dropped.  Fail-OPEN: an undecodable partition value
                        # can't prove the file is out of range.
                        if decoded_str is None:
                            continue
                        # 2026-07-14 — fail-OPEN reconciliation (see IN branch):
                        # a synth join-key '=' from the other table's
                        # partition-value spelling must still match this one —
                        # numeric AND string (case/whitespace) drift.
                        if (not _date_eq(decoded_str, f_val_str, col_type)
                                and not _partition_value_numeric_match(
                                    decoded_str, (f_val_str,))
                                and not _partition_value_string_match(
                                    decoded_str, (f_val_str,))):
                            skip_file = True
                            break
                        continue
                    if f_op in ("not_equals", "ne", "!="):
                        # 2026-07-22 (audit C5) DATA-LOSS FIX: EXACT match only.
                        # _date_eq WIDENS a bare date to match any sub-day
                        # timestamp on that date — fail-OPEN-safe for `=` (keeps
                        # files) but here it would EXCLUDE a file whose value is
                        # 2025-09-30 13:00:00 for `!= '2025-09-30'`, dropping its
                        # 13:00 rows that satisfy the predicate.  Only skip on an
                        # exact partition-value match; keep otherwise.
                        if decoded_str is not None and decoded_str == f_val_str:
                            skip_file = True
                            break
                        continue
                    # Range — type-aware compare; coerce based on
                    # PRE-COMPUTED col_type_lower
                    if f_op in ("gt", ">", "greater_than", "gte", ">=", "greater_equals",
                                  "lt", "<", "less_than", "lte", "<=", "less_equals"):
                        # 2026-10-06 -- a STRING identity partition: the ONE
                        # decision (the island's, db-first's, the manifest
                        # matcher's).  Every reading of this file's single
                        # value must agree, or the file is kept.
                        if _is_str_part_pf(col_type_lower):
                            _d_pf = _spd_pf(
                                col_type_lower, f_op,
                                _range_literal(f_val, f_val_str),
                                decoded_str, decoded_str,
                                literal_kind=_resolved_pf_literal_kind.get(
                                    (part_field, f_op, f_val_str)))
                            if _d_pf.drop:
                                skip_file = True
                                break
                            continue   # kept by the one decision
                        try:
                            if col_type_lower in ("int", "integer", "long", "bigint"):
                                cmp_decoded = int(decoded_str) if decoded_str else None
                                cmp_fval = int(f_val_str)
                            elif (col_type_lower in ("float", "double", "decimal")
                                  or col_type_lower.startswith("decimal(")):
                                # 2026-08-03 DATA-LOSS FIX: _extract_partition_spec
                                # stores the VERBATIM type — "decimal(10,2)" — so
                                # the exact-match test above never fired and range
                                # predicates on decimal identity partitions fell
                                # to the STRING branch: "9.50" >= "10" is False
                                # lexicographically → matching file skipped, rows
                                # lost.  eq/IN were rescued by
                                # _partition_value_numeric_match; ranges were not.
                                cmp_decoded = float(decoded_str) if decoded_str else None
                                cmp_fval = float(f_val_str)
                            else:
                                cmp_decoded = decoded_str
                                cmp_fval = f_val_str
                            if cmp_decoded is None:
                                continue
                            _range_skip = False
                            if f_op in ("gt", ">", "greater_than") and cmp_decoded <= cmp_fval:
                                _range_skip = True
                            elif f_op in ("gte", ">=", "greater_equals") and cmp_decoded < cmp_fval:
                                _range_skip = True
                            elif f_op in ("lt", "<", "less_than") and cmp_decoded >= cmp_fval:
                                _range_skip = True
                            elif f_op in ("lte", "<=", "less_equals") and cmp_decoded > cmp_fval:
                                _range_skip = True
                            if _range_skip:
                                # 2026-08-03 DATA-LOSS FIX: temporal partition
                                # values are INTERVALS (day/hour/month/year
                                # transforms cover their period; timestamp
                                # decode truncates seconds; 'T'-vs-space ISO
                                # spellings mis-sort lexicographically).  A
                                # range skip on a temporal column must ALSO be
                                # proven under interval semantics; otherwise
                                # KEEP.  Non-temporal columns are unaffected.
                                if (col_type_lower in _TEMPORAL_IDENTITY_RANGE_TYPES
                                        and not _temporal_identity_range_prune_ok(
                                            decoded_str, f_val_str,
                                            col_type_lower, f_op)):
                                    continue    # interval overlaps → keep
                                skip_file = True
                                break
                        except (ValueError, TypeError):
                            pass
                if skip_file:
                    if _gate_allow(("partition_null" if _skip_null else "partition"),
                                   file_path, **_gate_partition_record()):
                        _ice_skipped_partition += 1
                        _prcpt("partition_null" if _skip_null else "partition",
                               file_path, predicate=_prcpt_pred_part)
                        continue
                    skip_file = False   # gate veto (enforce): keep the file

            # ── 2026-07-23 HIVE-PATH ISLAND fallback — partition stage ─────
            # Covers ONLY filter columns _resolved_pf could NOT engage (spec
            # unresolved).  Runs BEFORE col-stats / supplement / bloom so the
            # downstream funnel operates on ISLAND survivors, not the ocean.
            # Fail-open per file: unparseable path or absent segment → keep.
            if _hive_island_constraints_list:
                try:
                    _hi_parts = _hive_island_file_parts(file_path)
                    if _hi_parts:
                        for _hi_col, _hi_vals in _hive_island_constraints_list:
                            if _hi_col in _hi_parts:
                                _hive_island_obs_cols.add(_hi_col)
                    if _hive_island_file_prunes(
                            _hi_parts, _hive_island_constraints_list):
                        if _gate_allow("partition_hive", file_path,
                                       parts=_hi_parts,
                                       constraints=_hive_island_constraints_list):
                            _hive_island_pruned += 1
                            _ice_skipped_partition += 1
                            _prcpt("partition", file_path,
                                   predicate=("hive_island:" + ",".join(
                                       f"{c}={v}" for c, v in
                                       _hive_island_constraints_list))[:180])
                            continue
                except Exception as _hi_exc:
                    _fail_open("partition_hive")
                    logger.debug("[hive-island] per-file check failed open "
                                 "for %s: %s", file_path, _hi_exc)

            # ── BF-316 — record bound coverage BEFORE pruning ──────────
            # For each filter column, count how many files actually have a
            # non-empty lower/upper bound for it.  If the count is 0 at
            # the end, the writer didn't save stats for that column and
            # nothing we do here will prune it.
            if _non_partition_filters and _col_stats_name_to_fid:
                _df_lb = _avro_kv_map(data_file.get("lower_bounds"))
                _df_ub = _avro_kv_map(data_file.get("upper_bounds"))
                for _f in _non_partition_filters:
                    _fc = (_f.get("col") or _f.get("column") or "").split(".")[-1].lower()
                    _fid = _col_stats_name_to_fid.get(_fc)
                    if _fid is None:
                        continue
                    # Bounds dict can have int OR string keys depending on cache decode path
                    _has_lb = (_fid in _df_lb) or (str(_fid) in _df_lb)
                    _has_ub = (_fid in _df_ub) or (str(_fid) in _df_ub)
                    if _has_lb or _has_ub:
                        _ice_bound_coverage[_fc] = _ice_bound_coverage.get(_fc, 0) + 1

            # ── 2026-07-15 PRUNABILITY PROFILES — per-file evidence ─────────
            # For each eq/in filter column, record whether THIS file's bounds
            # (manifest OR supplement — both already in hand, ZERO extra S3
            # I/O) could have excluded the queried value.  Runs BEFORE the
            # prune `continue`s below so pruned files are counted too.
            # PURE OBSERVATION: never mutates any skip decision; disabled
            # for the rest of the scan on first error (fail-open).
            if _prof_eq_in and not _prof_disabled_midscan:
                try:
                    _p_lb = _avro_kv_map(data_file.get("lower_bounds"))
                    _p_ub = _avro_kv_map(data_file.get("upper_bounds"))
                    _p_supp = (_supplement_bounds.get(_s3_uri_to_key(file_path))
                               if _supplement_bounds else None)
                    for _p_col, _p_filt in _prof_eq_in:
                        _p_st = _prof_counters.get(_p_col)
                        if _p_st is None:
                            continue
                        _p_fid = (_col_stats_name_to_fid.get(_p_col)
                                  if _col_stats_name_to_fid else None)
                        _p_lo = _p_hi = None
                        if _p_fid is not None:
                            _p_lo = _p_lb.get(_p_fid)
                            if _p_lo is None:
                                _p_lo = _p_lb.get(str(_p_fid))
                            _p_hi = _p_ub.get(_p_fid)
                            if _p_hi is None:
                                _p_hi = _p_ub.get(str(_p_fid))
                        _p_has_manifest = (_p_lo is not None
                                           or _p_hi is not None)
                        _p_supp_entry = (_p_supp.get(_p_col)
                                         if _p_supp else None)
                        _p_st["evaluated"] += 1
                        if not (_p_has_manifest or _p_supp_entry):
                            # No bounds anywhere → min/max could not prune.
                            _p_st["bounds_could_not_prune"] += 1
                            continue
                        _p_st["with_bounds"] += 1
                        # Singleton: min == max (raw-value equality — bytes
                        # for manifest bounds, strings for supplement).
                        if ((_p_lo is not None and _p_lo == _p_hi)
                                or (_p_supp_entry
                                    and len(_p_supp_entry) >= 2
                                    and _p_supp_entry[0] is not None
                                    and _p_supp_entry[0] == _p_supp_entry[1])):
                            _p_st["singleton"] += 1
                        # Could the bounds EXCLUDE the queried value?
                        # Re-uses the EXACT prune predicates with a single-
                        # filter list — same verdict the real prune layers
                        # produce for this one column, so the profile can
                        # never disagree with actual pruning behaviour.
                        _p_excluded = False
                        if _p_has_manifest and _col_stats_name_to_fid:
                            _p_excluded = not _file_matches_column_stats(
                                data_file, [_p_filt],
                                _col_stats_fid_to_type,
                                _col_stats_name_to_fid,
                            )
                        if (not _p_excluded and _p_supp_entry
                                and _supplement_bounds):
                            _p_excluded = not _file_matches_supplement_bounds(
                                _s3_uri_to_key(file_path),
                                _supplement_bounds, [_p_filt],
                            )
                        if not _p_excluded:
                            _p_st["bounds_could_not_prune"] += 1
                except Exception as _prof_file_exc:
                    _prof_disabled_midscan = True
                    logger.debug(
                        "[prunability] per-file accumulation disabled "
                        "mid-scan (fail-open): %s", _prof_file_exc,
                    )

            # ── Column statistics pushdown (non-partition columns) ─────────
            # Use Iceberg data_file.lower_bounds / upper_bounds to skip files
            # whose column min/max stats prove no rows can satisfy the filter.
            # This works for ANY column tracked by the Iceberg writer — even
            # non-partition columns like CUSTOMER_ID, AMOUNT, STATUS etc.
            if _non_partition_filters and _col_stats_name_to_fid:
                try:
                    if not _file_matches_column_stats(
                        data_file, _non_partition_filters,
                        _col_stats_fid_to_type, _col_stats_name_to_fid,
                        string_partition_cols=_string_partition_filter_cols,
                    ):
                        if _gate_allow("column_stats", file_path,
                                       **_gate_stats_record(data_file)):
                            _ice_skipped_col_stats += 1
                            _prcpt("column_stats", file_path,
                                   predicate=str(_non_partition_filters)[:180])
                            continue  # file provably empty for this filter
                except Exception as _cs_exc:
                    _fail_open("column_stats")
                    # 2026-08-21 — a fail-open that fires on EVERY candidate is
                    # not a fail-open, it is a silent OUTAGE: column-stats
                    # pruning does nothing and every file is kept on no
                    # evidence.  The operator's run logged column_stats=3001
                    # fail-opens over 3001 candidates and pruned 0 files by
                    # stats, and the ONLY trace was this DEBUG line — invisible
                    # at the INFO level everyone actually runs.  Name the first
                    # one loudly, with the stack and the inputs, so a single
                    # run identifies the cause instead of a guessing round.
                    if _stage_fail_open.get("column_stats") == 1:
                        logger.warning(
                            "column-stats pruning FAILED OPEN on its first "
                            "candidate (%s) — every file it fails on is KEPT "
                            "on no evidence.  filters=%s fid_to_type=%d "
                            "name_to_fid=%d",
                            file_path, str(_non_partition_filters)[:300],
                            len(_col_stats_fid_to_type or {}),
                            len(_col_stats_name_to_fid or {}),
                            exc_info=True,
                        )
                    else:
                        logger.debug(
                            "column-stats check failed open for %s: %s",
                            file_path, _cs_exc)

            # ── BF-COL-STATS supplement pruning ────────────────────────────
            # When the manifest has no bounds for a filter column (writer
            # didn't track it), check the supplement table populated by
            # extract_parquet_column_stats.  Same prune effect, different
            # bounds source.
            if _supplement_bounds and _non_partition_filters:
                _key_for_supp = _s3_uri_to_key(file_path)
                try:
                    _dr = [] if _supp_audit_on else None
                    if not _file_matches_supplement_bounds(
                        _key_for_supp, _supplement_bounds, _non_partition_filters,
                        drop_reason=_dr,
                        string_partition_cols=_string_partition_filter_cols,
                    ):
                        if _gate_allow("supplement", _key_for_supp,
                                       **_gate_supp_record(
                                           _key_for_supp,
                                           data_file.get("record_count"))):
                            _ice_skipped_supplement += 1
                            _prcpt("supplement", _key_for_supp,
                                   predicate=str(_non_partition_filters)[:180],
                                   bounds=(_dr[0] if _dr else None))
                            if _supp_audit_on:
                                _supp_drop_trace.append({
                                    "file": _key_for_supp,
                                    "reason": (_dr[0] if _dr else None),
                                })
                            continue  # supplement bounds prove file empty
                except Exception as _sp_exc:
                    _fail_open("supplement")
                    logger.debug("supplement-bounds check failed open for %s: %s",
                                 file_path, _sp_exc)

            # ── 149.4 bloom sidecar (DB-backed) ────────────────────────────
            # Cheap pre-skip via the iceberg_bloom_sidecar_v1 table.
            # Bounds prune ranges; bloom prunes sparse-equality
            # (e.g. WHERE customer_id = 12345 on a [1, 1M] bounds col).
            # Cost: zero S3 round-trips per file (DB rows were loaded once
            # at query start) — strictly cheaper than the BF-548 native
            # S3 bloom check below, so we run sidecar first.  Fail-OPEN
            # at every step — bloom can never produce false negatives.
            if _bloom_sidecar_bounds and _non_partition_filters:
                _key_for_bloom_sc = _s3_uri_to_key(file_path)
                _file_bloom = _bloom_sidecar_bounds.get(_key_for_bloom_sc)
                if _file_bloom:
                    try:
                        from core.iceberg_bloom_sidecar import (
                            bloom_can_contain as _bcc,
                            bloom_can_contain_any as _bcca,
                            probe_parity_proven as _bloom_parity_proven,
                        )
                        _bloom_pruned = False
                        for _f in _non_partition_filters:
                            _op  = (_f.get("op") or _f.get("operator") or "").lower()
                            _col = (_f.get("col") or _f.get("column") or "").split(".")[-1].lower()
                            _val = _f.get("val") if "val" in _f else _f.get("value")
                            if not _col or _val is None:
                                continue
                            _bloom_entry = _file_bloom.get(_col)
                            if not _bloom_entry:
                                continue
                            # DATA-LOSS GUARD (2026-07-15): only trust a bloom
                            # "absent" verdict when the probe's byte-encoding
                            # matches the column's build-side encoding.  A
                            # STRING '2025-09-30' probe against a DATE column
                            # (built from date32 bytes) silently misses and
                            # would drop the file.  Mismatch → skip bloom for
                            # this column (fail-open scan).
                            # 2026-09-27: and the row's recorded BUILD-side
                            # type must agree too (probe_parity_proven --
                            # the one chokepoint; None = untyped row, see
                            # its docstring for why that is still safe).
                            _bcol_ty = _bloom_col_types.get(_col)
                            _built_ty = (_bloom_entry[3]
                                         if len(_bloom_entry) > 3 else None)
                            if _built_ty is None:
                                _ice_bloom_untyped_decisions += 1
                            if _op in ("=", "==", "eq", "equals"):
                                if not _bloom_parity_proven(_bcol_ty, _built_ty, _val):
                                    continue
                            elif _op == "in" and isinstance(_val, (list, tuple)) and _val:
                                if not all(
                                    _bloom_parity_proven(_bcol_ty, _built_ty, _v)
                                    for _v in _val
                                ):
                                    continue
                            _bbits, _bn, _bk = _bloom_entry[0], _bloom_entry[1], _bloom_entry[2]
                            if _op in ("=", "==", "eq", "equals"):
                                if not _bcc(_bbits, _bn, _bk, _val):
                                    _bloom_pruned = True
                                    break
                            elif _op == "in" and isinstance(_val, (list, tuple)) and _val:
                                if not _bcca(_bbits, _bn, _bk, _val):
                                    _bloom_pruned = True
                                    break
                        if _bloom_pruned:
                            if _gate_allow("bloom_sidecar", file_path,
                                           filters=_non_partition_filters,
                                           bloom=_file_bloom,
                                           col_types=_bloom_col_types):
                                _ice_skipped_bloom_sidecar += 1
                                _prcpt("bloom_sidecar", file_path,
                                       predicate=str(_non_partition_filters)[:180])
                                continue
                    except Exception as _bsc_exc:
                        _fail_open("bloom_sidecar")
                        logger.debug(
                            "149.4: bloom sidecar check error for %s (fail-open): %s",
                            file_path, _bsc_exc,
                        )

            # BF-548 (2026-05-29): S3-side bloom filter pre-skip.  For
            # highly-selective equality predicates (especially on
            # high-cardinality columns the writer DID bloom), this
            # skips the file ENTIRELY before DuckDB ever opens it.
            # Cost: 1 suffix-range GET (~256 KB) per file vs the cost
            # of opening + scanning the file.  Opt-in via config so
            # non-selective workloads aren't penalised with extra
            # round trips.  Fail-OPEN at every step — bloom can never
            # produce false negatives.
            if _bloom_check_enabled and _non_partition_filters:
                try:
                    # JOIN-PRUNER (2026-06-01 deep-audit round 5) — bloom
                    # for IN: a file is provably absent for ``col IN
                    # (v1, v2, ...)`` only if EVERY value's bloom check
                    # proves absence.  Decompose by checking each value
                    # individually; keep file as soon as ONE value passes.
                    _eq_filters_for_bloom = []
                    _in_filters_for_bloom = []
                    for f in _non_partition_filters:
                        _op = (f.get("op") or "").lower()
                        _val = f.get("val") if "val" in f else f.get("value")
                        if _op in ("=", "==", "eq", "equals") and _val is not None:
                            _eq_filters_for_bloom.append((f["col"], _val))
                        elif _op in ("in",) and isinstance(_val, (list, tuple)) and _val:
                            # Cap IN-list bloom checks at a sane size to
                            # avoid one massive synth-IN dominating the
                            # per-file cost (one suffix-GET per value).
                            if len(_val) <= 20:
                                _in_filters_for_bloom.append((f["col"], list(_val)))
                    if _eq_filters_for_bloom or _in_filters_for_bloom:
                        from core.parquet_pruning import file_matches_bloom_s3
                        _key_for_bloom = _s3_uri_to_key(file_path)
                        _gate_reprobe = (lambda _rp_c, _rp_v, _rp_k=_key_for_bloom:
                                         bool(file_matches_bloom_s3(
                                             s3_client, bucket, _rp_k,
                                             [(_rp_c, _rp_v)])))
                        # EQ first — cheaper.
                        if _eq_filters_for_bloom and not file_matches_bloom_s3(
                            s3_client, bucket, _key_for_bloom, _eq_filters_for_bloom,
                        ):
                            if _gate_allow("bloom", file_path,
                                           eq_filters=_eq_filters_for_bloom,
                                           in_filters=[],
                                           reprobe=_gate_reprobe):
                                _ice_skipped_bloom += 1
                                _prcpt("bloom", file_path,
                                       predicate=str(_eq_filters_for_bloom)[:180])
                                continue
                        # IN: file passes if ANY value passes.
                        _in_pruned = False
                        for _in_col, _in_vals in _in_filters_for_bloom:
                            _any_pass = False
                            for _vv in _in_vals:
                                if file_matches_bloom_s3(
                                    s3_client, bucket, _key_for_bloom,
                                    [(_in_col, _vv)],
                                ):
                                    _any_pass = True
                                    break
                            if not _any_pass:
                                _in_pruned = True
                                break
                        if _in_pruned:
                            if _gate_allow("bloom", file_path,
                                           eq_filters=[],
                                           in_filters=_in_filters_for_bloom,
                                           reprobe=_gate_reprobe):
                                _ice_skipped_bloom += 1
                                _prcpt("bloom", file_path,
                                       predicate=str(_in_filters_for_bloom)[:180])
                                continue
                except Exception as _bl_exc:
                    _fail_open("bloom")
                    logger.debug("BF-548 bloom check skipped: %s", _bl_exc)

            _dedup_key = _s3_uri_to_key(file_path)
            # 2026-07-13 (phantom-file-count fix): within a single snapshot
            # every live data file is referenced by EXACTLY ONE manifest
            # entry, so a repeat file_path means the same physical file was
            # referenced twice (duplicate manifest, or a rewrite/compaction
            # bookkeeping artifact).  Counting it again inflates the file
            # count with files that "never existed" as separate objects and
            # would make DuckDB read the same parquet twice.  Keep the first
            # occurrence only — keeps data_file_keys / _record_counts /
            # _file_sizes / bound observations mutually consistent.
            # 2026-08-20 DATA-LOSS FIX: "repeat" = same (effective bucket,
            # key).  A colliding key path in a DIFFERENT bucket is a
            # DISTINCT physical file this single-bucket reader cannot scan
            # (appending its bare key would read the colliding twin twice —
            # duplicate rows); it is skipped but surfaced as a foreign-
            # bucket ref → file_cap/certificate HARD NEGATIVE below, never
            # counted as a dedup "fix".  Non-colliding foreign URIs keep
            # today's key-only read (alias-bucket deployments rely on it).
            _df_bucket = _s3_uri_bucket(str(file_path)) or bucket
            _df_verdict = _classify_ref_for_dedup(
                _seen_data_file_keys, _dedup_key, _df_bucket)
            if _df_verdict == "dup":
                _dup_data_file_refs += 1
                continue
            if _df_verdict == "foreign":
                _foreign_data_file_refs.append(f"{_df_bucket}/{_dedup_key}")
                continue
            data_file_keys.append(_dedup_key)
            _record_counts.append(data_file.get("record_count", 0) or 0)
            # 2026-06-04 — size from manifest enables file_order sorting
            # in the keys_only path without an extra S3 HEAD storm.
            _file_sizes.append(int(data_file.get("file_size_in_bytes") or 0))
            if _rp_presence is not None:
                try:
                    # 2026-10-06 -- a wide entry's metric maps are bounded
                    # at decode (_bound_entry_metrics); the FULL set of
                    # stored field ids rides METRIC_IDS_KEY.  Presence must
                    # read that, or every column past the bound would be
                    # projected as NULL.
                    _rp_ids = metric_ids_of(data_file)
                    if _rp_ids:
                        _rp_presence.observe(_rp_ids)
                    else:
                        _rp_keys = _avro_kv_map(data_file.get("column_sizes")) or \
                            _avro_kv_map(data_file.get("value_counts")) or \
                            _avro_kv_map(data_file.get("null_value_counts")) or {}
                        _rp_presence.observe(_rp_keys.keys())
                except Exception:
                    _rp_presence.observe(None)   # no metrics for this file
            # Phase Z (2026-06-09) — unified JOIN-PRUNER aggregation
            # via BoundProviderRegistry.  Replaces three independent
            # inline blocks (partition / manifest_stats / supplement)
            # with one observe() call.  The aggregator dispatches
            # to each provider in priority order; first-hit-wins per
            # col, with full source attribution preserved for the
            # diagnose UI.  See core/brain/bound_providers.py.
            if _bound_aggregator is not None:
                # Use the S3 key (matches supplement table's file_path
                # column) for consistency across providers.
                _bound_aggregator.observe(_s3_uri_to_key(file_path), data_file)
            if max_files > 0 and len(data_file_keys) >= max_files:
                _hit_limit = True
                break
            # Phase 139 audit-fix LIMIT/top-k: stop accumulating files once
            # cumulative row count is >= max_rows. Only safe when the query
            # has NO ORDER BY (caller passes max_rows only in that case).
            if max_rows > 0 and sum(_record_counts) >= max_rows:
                _hit_limit = True
                break

    # -- 2026-08-21 - MISSING EVIDENCE IS NOT A REASON TO READ THE OCEAN --
    #
    # Operator: "even if columns stats not in db then still cant dive in ocen".
    #
    # Their run: 3,001 files survived partition pruning, the column-stats stage
    # could decide almost none of them (coverage 16%), everything undecided
    # fail-opened to KEEP, and 2,880 files / 32.2 GB / 204M rows went to DuckDB
    # -- the vast majority kept not because they might match but because we
    # knew nothing about them.
    #
    # Fail-open on missing evidence is the right CORRECTNESS choice and is
    # unchanged.  It is the wrong PLAN.  When the undecidable set is bounded,
    # the cheap move is to go and get the evidence: a parquet footer is
    # 1 HEAD + 1-2 ranged GETs, ~16-256 KB REGARDLESS of file size.  3,001
    # footers is ~300 MB and parallel; the data those files hold is 32.2 GB.
    # Two orders of magnitude, to turn a guess into a fact.
    #
    # Nothing here is new machinery.  ``scan_files_to_supplement`` has read
    # footers in parallel and upserted them for months -- it was only ever
    # wired to the admin scanner and the watcher, never to the query that is
    # about to pay for their absence.  This connects the two, scoped to THIS
    # query surviving island and THIS query filter columns.
    #
    # Bounded and fail-open throughout: a file cap, a wall-clock deadline, and
    # any error at all leaves the survivor list exactly as the funnel built it.
    # Captured bounds are persisted, so the next query on this island is free.
    _footer_capture_meta = None
    try:
        from core.config import get as _cfg_get_ice
        # C8 fix (2026-08-22): capture ONLY columns an actual filter
        # constrains.  _filter_cols_lower also carries join-key columns
        # (they are loaded for the JoinPruner's aggregation), but that
        # aggregation ran during the entry loop ABOVE — bounds captured
        # here for a join key can decide nothing in THIS query's re-prune,
        # so each such footer parse was pure waste.  The snapshot-arrival
        # indexer captures demand-ranked join keys off the query path.
        _fc_filter_only = {
            (f.get("col") or f.get("column") or "").split(".")[-1].lower()
            for f in (_non_partition_filters or [])
            if (f.get("col") or f.get("column"))
        }
        _fc_cols = [
            c for c in (_filter_cols_lower or [])
            if c in _fc_filter_only
            and _ice_bound_coverage.get(c, 0) < len(data_file_keys)
            # 2026-08-23 island-exact: a footer can only restate what the
            # partition value already said — never pay S3 GETs for it.
            and not (_island_exact and c in _island_decided_cols)
        ] if _non_partition_filters else []
        _fc_on = bool(_cfg_get_ice("iceberg", "footer_capture_on_query", True))
        _fc_max = int(_cfg_get_ice("iceberg", "footer_capture_max_files", 5000)
                      or 5000)
        _fc_min = int(_cfg_get_ice("iceberg", "footer_capture_min_files", 25)
                      or 25)
        _fc_deadline = float(_cfg_get_ice(
            "iceberg", "footer_capture_deadline_seconds", 25) or 25)
        _fc_workers = int(_cfg_get_ice("iceberg", "footer_capture_workers", 32)
                          or 32)
        _fc_n = len(data_file_keys)
        # 2026-08-21 - NO HARD CAP.  This used to SKIP the capture entirely
        # above _fc_max files: 5,001 undecidable files got zero evidence and
        # were all read in full, which fails in the WRONG DIRECTION - the
        # bigger the island, the more the evidence was worth, and that is
        # exactly when it refused.  A file count is a GATE; the wall clock
        # is a THROTTLE.  We now always start, bounded by the deadline, and
        # keep whatever evidence came back.  _fc_max now only bounds how
        # many files ONE call scans, so a huge island makes partial progress
        # per query and drains across queries instead of never starting.
        if (_fc_on and _fc_cols and db_manager is not None
                and s3_client is not None and _fc_n >= _fc_min
                and effective_snapshot_id):
            logger.info(
                "[footer-capture] %s: %d surviving file(s) have no usable "
                "bounds for %s - reading their PARQUET FOOTERS (~16-256KB "
                "each) rather than keeping them unjudged.",
                table_prefix, _fc_n, _fc_cols,
            )
            _fc_t0 = _time.monotonic()
            _fc_cancel = threading.Event()
            _fc_stop = threading.Event()

            def _fc_watchdog():
                if not _fc_stop.wait(_fc_deadline):
                    _fc_cancel.set()

            _fc_timer = threading.Thread(target=_fc_watchdog, daemon=True,
                                          name="footer-capture-deadline")
            _fc_timer.start()
            try:
                from core.iceberg_column_stats import scan_files_to_supplement
                _fc_res = scan_files_to_supplement(
                    db_manager, s3_client, bucket,
                    table_prefix.rstrip("/"), str(effective_snapshot_id),
                    file_keys=list(data_file_keys),
                    target_columns=list(_fc_cols),
                    max_workers=_fc_workers,
                    skip_already_scanned=True,
                    connection_id=_connection_id_from_s3_client(s3_client),
                    table_name=table_name,
                    cancel_event=_fc_cancel,
                    max_to_scan=_fc_max,
                )
            finally:
                _fc_stop.set()
            _fc_elapsed = _time.monotonic() - _fc_t0
            # 2026-08-22 — this synchronous capture (deadline-capped at
            # ``footer_capture_deadline_seconds``, default 25 s) runs AFTER
            # the manifests stopwatch stopped, so up to 25 s of wall-clock
            # was landing in the breakdown's ``other`` residual — exactly
            # where "where is the startup 100s going" hides.  It is parquet-
            # footer acquisition, which is the ``metadata`` stage by its own
            # definition.  Fail-open: a broken stopwatch never breaks a read.
            try:
                from core.brain_latency_breakdown import record_stage as _fc_rec
                _fc_rec("metadata", _fc_elapsed)
            except Exception as _fc_rec_exc:                # pragma: no cover
                logger.debug("[footer-capture] record_stage('metadata') "
                             "suppressed %s: %s",
                             type(_fc_rec_exc).__name__, _fc_rec_exc)

            # Re-read what we just captured and run the SAME supplement matcher
            # the funnel uses -- one predicate implementation, so a captured
            # bound can never be judged differently from a stored one.
            from core.brain_duckdb_store import (
                get_col_stats_for_snapshot_via_store as _fc_load,
            )
            _fc_raw = _fc_load(
                db_manager, bucket=bucket,
                table_prefix=table_prefix.rstrip("/"),
                snapshot_id=str(effective_snapshot_id),
                column_names=list(_fc_cols),
                file_paths=list(data_file_keys),
            ) or {}
            _fc_bounds = {
                _fp: {(k or "").lower(): v for k, v in (_cols or {}).items()}
                for _fp, _cols in _fc_raw.items()
            }
            _fc_orig = list(data_file_keys)
            _fc_keep = []
            for _i, _k in enumerate(data_file_keys):
                try:
                    if (_fc_bounds.get(_k)
                            and not _file_matches_supplement_bounds(
                                _k, _fc_bounds, _non_partition_filters,
                                string_partition_cols=(
                                    _string_partition_filter_cols))):
                        # 2026-08-22 — THROUGH THE GATE, like every other
                        # stage.  This was the only prune in the funnel the
                        # correctness gate could not veto, and it emitted no
                        # prune receipt: in enforce mode every other stage
                        # must justify a drop to `_gate_allow` or keep the
                        # file, and a stage that quietly exempts itself makes
                        # the gate's verdict a partial one while still
                        # reporting a clean run.  Footer bounds are the
                        # strongest evidence we have, so this will almost
                        # always be allowed — which is exactly why it costs
                        # nothing to ask.
                        # The record shape is the one _justify_stats
                        # reads: {filters, bounds{col:(lo,hi)}, null_counts,
                        # record_count}.  Handing it a different shape would
                        # make the verifier throw into its own except and
                        # count every drop unproven — a gate that cannot read
                        # its input is not a gate.
                        _fc_b, _fc_nc = {}, {}
                        for _fc_c, _fc_t in (_fc_bounds.get(_k) or {}).items():
                            if isinstance(_fc_t, (tuple, list)) and len(_fc_t) >= 2:
                                _fc_b[_fc_c] = (_fc_t[0], _fc_t[1])
                                if len(_fc_t) > 2 and isinstance(_fc_t[2], int):
                                    _fc_nc[_fc_c] = _fc_t[2]
                        if _gate_allow(
                                "footer_capture", _k,
                                filters=_non_partition_filters,
                                bounds=_fc_b, null_counts=_fc_nc,
                                record_count=(_record_counts[_i]
                                              if _i < len(_record_counts)
                                              else 0)):
                            # Prune receipt, like every other stage — a drop
                            # nobody can see is a drop nobody can audit.
                            try:
                                _prcpt("footer_capture", _k,
                                       predicate=str(_non_partition_filters)[:180],
                                       bounds=(_fc_b or None))
                            except Exception as _rcpt_exc:
                                # Not a silent pass: a receipt that fails to
                                # record is the difference between an audited
                                # drop and an invisible one, and this module
                                # has already shipped one feature whose only
                                # symptom was a message nobody wrote.
                                logger.debug(
                                    "[footer-capture] prune receipt failed for "
                                    "%s: %s", _k, _rcpt_exc)
                            continue      # PROVED empty by its own footer
                except Exception as _be_exc:
                    note_best_effort("continue", _be_exc,
                                     logger=logger)
                _fc_keep.append(_i)

            _fc_dropped = len(data_file_keys) - len(_fc_keep)
            if _fc_dropped > 0:
                # Rebuild every parallel array from ONE keep-mask so they
                # cannot drift out of alignment.
                data_file_keys[:] = [data_file_keys[i] for i in _fc_keep]
                _record_counts[:] = [_record_counts[i] for i in _fc_keep]
                _file_sizes[:] = [_file_sizes[i] for i in _fc_keep]
            # Survivors that STILL have no bounds — the honest "blind" count
            # after the capture.  The stage's fail-open tally counts what was
            # undecidable BEFORE we went and got the evidence; reporting that
            # afterwards would overstate the problem by everything we just
            # resolved.
            _fc_still_blind = sum(
                1 for _i in _fc_keep if not _fc_bounds.get(_fc_orig[_i]))
            _footer_capture_meta = {
                "columns": list(_fc_cols),
                "candidates": _fc_n,
                "still_blind": _fc_still_blind,
                "scanned": (_fc_res or {}).get("scanned"),
                "failed": (_fc_res or {}).get("failed"),
                "dropped": _fc_dropped,
                "seconds": round(_fc_elapsed, 2),
                "deadline_hit": bool(_fc_cancel.is_set()),
            }
            logger.info(
                "[footer-capture] %s: %d candidate(s) -> %d PROVED empty and "
                "dropped, %d remain (scanned=%s failed=%s %.1fs%s).  Those "
                "bounds are now stored: the next query on this island is "
                "cheaper%s.",
                table_prefix, _fc_n, _fc_dropped, len(data_file_keys),
                (_fc_res or {}).get("scanned"), (_fc_res or {}).get("failed"),
                _fc_elapsed, ", DEADLINE HIT" if _fc_cancel.is_set() else "",
                (f" (PARTIAL: {_fc_still_blind} file(s) still unjudged - the"
                 f" next run continues from here)") if _fc_still_blind else "",
            )
        elif _fc_on and _fc_cols and 0 < _fc_n < _fc_min:
            logger.debug(
                "[footer-capture] %s: only %d undecidable file(s) - below "
                "the %d floor, not worth the round-trip.",
                table_prefix, _fc_n, _fc_min,
            )
    except Exception as _fc_exc:
        # NEVER breaks the read: the funnel survivor list stands as-is.
        logger.warning(
            "[footer-capture] %s: skipped (fail-open) - %s: %s",
            table_prefix, type(_fc_exc).__name__, str(_fc_exc)[:200],
        )
    if _out_meta is not None and _footer_capture_meta:
        _out_meta["footer_capture"] = _footer_capture_meta

    # 2026-09-25 -- read plan: attach the per-file column presence of the
    # surviving list.  A count mismatch (should be impossible) exports
    # nothing, and the planner keeps today's hive-path read.
    try:
        if (_out_meta is not None and _rp_presence is not None
                and isinstance(_out_meta.get("iceberg_read_plan"), dict)):
            if _rp_presence.files == len(data_file_keys):
                _out_meta["iceberg_read_plan"]["presence"] = _rp_presence.to_dict()
            else:
                logger.warning(
                    "iceberg_read_plan: presence observed %d file(s) but %d "
                    "survived for %s -- exporting no presence (hive-path read).",
                    _rp_presence.files, len(data_file_keys), table_prefix)
    except Exception as _rp_exp_exc:
        logger.debug("iceberg_read_plan presence export failed: %s", _rp_exp_exc)

    # BF-316: clear breakdown so admin can see WHY the surviving file
    # count is what it is.  Helps diagnose "why 1235 files for my query?"
    _final = len(data_file_keys)
    # ── 2026-07-23 HIVE-PATH ISLAND fallback — outcome surfacing ──────────
    if _hive_island_constraints_list:
        _hive_island_meta = {
            "engaged_cols": sorted(_hive_island_obs_cols),
            "armed_cols": sorted({c for c, _ in _hive_island_constraints_list}),
            "files_pruned": int(_hive_island_pruned),
            "files_kept": int(_final),
            "table_name": table_name,
        }
        if _out_meta is not None:
            _out_meta["hive_island_heal"] = _hive_island_meta
        if _hive_island_pruned:
            logger.info(
                "[hive-island] %s: pruned %d file(s) to the hive-path island "
                "(%d kept) on col(s) %s — spec-based partition pruning could "
                "not engage (schema-evolution/field-id drift); island carved "
                "from path segments instead.",
                table_prefix, _hive_island_pruned, _final,
                sorted(_hive_island_obs_cols))
        elif _hive_island_obs_cols:
            logger.info(
                "[hive-island] %s: island check engaged on col(s) %s but "
                "pruned 0 file(s) — every enumerated file is inside the "
                "island (or values matched after reconciliation).",
                table_prefix, sorted(_hive_island_obs_cols))
    if _dup_data_file_refs:
        logger.warning(
            "Iceberg table %s: dropped %d DUPLICATE data-file reference(s) "
            "during enumeration → %d distinct files (was over-counting "
            "files that don't exist as separate objects).  Duplicate refs "
            "usually mean the snapshot's manifest-list points at the same "
            "manifest twice or a rewrite left a stale reference.",
            table_prefix, _dup_data_file_refs, _final,
        )
        if _out_meta is not None:
            _out_meta["duplicate_data_file_refs"] = _dup_data_file_refs

    # ── 2026-08-20 FOREIGN-BUCKET REFS — surfaced, never called a "fix" ───
    # Colliding key paths whose URIs name ANOTHER bucket: distinct physical
    # files this single-bucket reader provably did not scan.  They used to
    # be folded into duplicate_data_file_refs (the drop reported as a fix).
    # Routed through the file_cap chokepoint → diagnostic store + the
    # Completeness Certificate goes INCOMPLETE (hard negative).  Fail-open:
    # surfacing failure never breaks the query; the skip itself already
    # happened (including the keys would double-read the colliding twins).
    if _foreign_data_file_refs or _foreign_manifest_refs:
        logger.error(
            "Iceberg table %s: %d foreign-bucket data-file ref(s) and %d "
            "foreign-bucket manifest ref(s) are MISSING from this scan — "
            "the table spans buckets but the reader is bound to s3://%s.  "
            "Result is a PARTIAL enumeration (certificate → INCOMPLETE).",
            table_prefix, len(_foreign_data_file_refs),
            len(_foreign_manifest_refs), bucket,
        )
        if _out_meta is not None:
            _out_meta["foreign_bucket_refs"] = {
                "data_files": list(_foreign_data_file_refs[:50]),
                "data_file_count": len(_foreign_data_file_refs),
                "manifests": list(_foreign_manifest_refs[:50]),
                "manifest_count": len(_foreign_manifest_refs),
            }
        try:
            from core.scan_truncation import record_scan_truncation
            record_scan_truncation(
                table=str(table_name or table_prefix),
                kind="foreign_bucket_refs",
                reason=(f"{len(_foreign_data_file_refs)} data file(s) and "
                        f"{len(_foreign_manifest_refs)} manifest(s) live in a "
                        f"bucket other than s3://{bucket} (colliding key "
                        f"paths) — unreadable by this single-bucket reader; "
                        f"their rows are absent from the result"),
                cap=None,
                files_before=None,
                files_registered=int(_final),
                # A skipped foreign MANIFEST hides an unknown number of data
                # files — only claim an exact dropped count when every
                # foreign ref is a data file.
                dropped=(len(_foreign_data_file_refs)
                         if not _foreign_manifest_refs else None),
                out_meta=_out_meta,
            )
        except Exception as _fb_exc:
            logger.warning(
                "Iceberg table %s: could not surface foreign-bucket refs "
                "through the truncation chokepoint (%s) — logged + stamped "
                "in out_meta only", table_prefix, _fb_exc)

    # ── 2026-07-15 SCAN LEDGER (Finding #1) — self-reconciliation ─────────
    # The brain checks ITS OWN arithmetic against the snapshot summary's
    # declared total-data-files (extracted near the snapshot-resolution
    # diagnostic above and stamped into _out_meta["snapshot_total_data_files"]).
    # Root incident: a query scanned ~4000 files across two tables whose
    # current snapshots declare 1605 + 1200 — the brain enumerated MORE
    # files than exist and never noticed.  PURE DIAGNOSTIC + FAIL-OPEN:
    # this block NEVER modifies data_file_keys and NEVER raises.
    _scan_ledger: Optional[Dict[str, Any]] = None
    try:
        _ledger_declared = None
        if _out_meta is not None:
            _ledger_declared = _out_meta.get("snapshot_total_data_files")
        if _ledger_declared is None:
            # _out_meta absent or writer path didn't stamp it — re-read the
            # followed snapshot's summary directly from metadata.json.
            for _lsnap in ((metadata or {}).get("snapshots") or []):
                if _lsnap.get("snapshot-id") == effective_snapshot_id:
                    _ledger_declared = ((_lsnap.get("summary") or {})
                                        .get("total-data-files"))
                    break
        try:
            # BF-500 partial-read signal: local only exists on the cache-miss
            # (S3 manifest read) path — NameError on cache hits means 0.
            _ledger_mrf = len(_manifest_read_failures)
        except (NameError, TypeError):
            _ledger_mrf = 0
        _ledger_has_filters = bool(partition_filters) or bool(_non_partition_filters)
        _ledger_verdict, _ledger_note = _scan_ledger_verdict(
            considered=_ice_files_considered,
            final=_final,
            declared_total=_ledger_declared,
            has_filters=_ledger_has_filters,
            hit_limit=_hit_limit,
            max_files=max_files,
            manifest_read_failures=_ledger_mrf,
        )
        try:
            _ledger_declared_int = (int(_ledger_declared)
                                    if _ledger_declared is not None else None)
        except (TypeError, ValueError):
            _ledger_declared_int = None
        _scan_ledger = {
            "considered":       int(_ice_files_considered),
            "final":            int(_final),
            "declared_total":   _ledger_declared_int,
            "delta_considered": ((int(_ice_files_considered) - _ledger_declared_int)
                                 if _ledger_declared_int is not None else None),
            "verdict":          _ledger_verdict,
        }
        if _out_meta is not None:
            _out_meta["scan_ledger"] = _scan_ledger
        if _ledger_verdict == "over_count":
            logger.critical(
                "[scan-ledger] Iceberg table %s OVER-COUNT: considered=%d "
                "final=%d declared total-data-files=%s snapshot=%s — %s.  "
                "The file list is returned UNCHANGED (detect-and-report only); "
                "investigate manifest-list duplication / snapshot-content cache "
                "contamination / stale metadata pointer.",
                table_prefix, _ice_files_considered, _final, _ledger_declared,
                effective_snapshot_id, _ledger_note,
            )
        elif _ledger_verdict == "under_count":
            logger.warning(
                "[scan-ledger] Iceberg table %s UNDER-COUNT: considered=%d "
                "final=%d declared total-data-files=%s snapshot=%s — %s.",
                table_prefix, _ice_files_considered, _final, _ledger_declared,
                effective_snapshot_id, _ledger_note,
            )
        elif _ledger_verdict == "partial_manifest_read":
            # 2026-08-20: was verdict "ok" ("invariant B relaxed") — an
            # affirmative completeness signal over a provably partial
            # enumeration.  The verdict travels via _out_meta["scan_ledger"]
            # into the Completeness Certificate as a HARD NEGATIVE.
            logger.error(
                "[scan-ledger] Iceberg table %s PARTIAL ENUMERATION: "
                "considered=%d final=%d declared total-data-files=%s "
                "snapshot=%s — %s",
                table_prefix, _ice_files_considered, _final, _ledger_declared,
                effective_snapshot_id, _ledger_note,
            )
        elif _ledger_verdict == "no_declared_total":
            logger.debug(
                "[scan-ledger] Iceberg table %s: no declared total-data-files, "
                "ledger skipped (snapshot=%s).",
                table_prefix, effective_snapshot_id,
            )
        # ── 2026-07-15 ADAPTIVE FRESHNESS coupling ────────────────────────
        # over_count / under_count are the fingerprints of a stale metadata
        # pointer (the incident: ~4000 files vs 1605 + 1200 declared).  Arm
        # the per-table anomaly flag so the NEXT queries on this table run
        # the freshness cross-check (see _adaptive_freshness_refresh).
        # Diagnostic-side effect only — never alters this query's result.
        if _ledger_verdict in ("over_count", "under_count"):
            _freshness_record_anomaly(bucket, table_prefix,
                                      db_manager=db_manager)
        else:
            logger.debug(
                "[scan-ledger] Iceberg table %s: verdict=%s (considered=%d "
                "final=%d declared=%s snapshot=%s) — %s",
                table_prefix, _ledger_verdict, _ice_files_considered, _final,
                _ledger_declared, effective_snapshot_id, _ledger_note,
            )
    except Exception as _ledger_exc:
        # FAIL-OPEN: the ledger is a control layer — it must never break
        # or alter the query path.
        logger.debug("[scan-ledger] reconciliation skipped (fail-open): %s",
                     _ledger_exc)

    # ── 2026-08-03 PRUNING CORRECTNESS GATE — per-query verdict ──────────
    # Per-stage justified/unjustified drop counts + capped detail of every
    # unjustified drop (full decision inputs).  In enforce mode unjustified
    # drops were already vetoed inline (files restored); here we only report.
    if _gate is not None:
        try:
            _gate_sum = _gate.summary()
            if _out_meta is not None:
                _out_meta["pruning_gate"] = _gate_sum
            if _gate_sum.get("unjustified"):
                logger.error(
                    "[pruning-gate] %s: %d of %d verified drop(s) were "
                    "UNJUSTIFIED (%s mode%s).  by_stage=%s detail=%s",
                    table_prefix, _gate_sum["unjustified"],
                    _gate_sum.get("checked", 0), _gate_sum.get("mode"),
                    "; files were RESTORED" if _gate_sum.get("restored")
                    else " — results may be missing rows",
                    _gate_sum.get("by_stage"),
                    _gate_sum.get("unjustified_detail"),
                )
            else:
                logger.info(
                    "[pruning-gate] %s: every verified drop justified "
                    "(checked=%d, delegated=%d, sampled_out=%d).",
                    table_prefix, _gate_sum.get("checked", 0),
                    _gate_sum.get("delegated", 0),
                    _gate_sum.get("skipped_by_sampling", 0),
                )
        except Exception as _gate_sum_exc:
            logger.debug("pruning-gate summary skipped (fail-open): %s",
                         _gate_sum_exc)
    # Per-stage decidability: where pruning FELL OPEN (could not decide) —
    # distinguishes "pruned 0" from "could not decide".
    try:
        if _stage_fail_open and _out_meta is not None:
            _out_meta["pruning_decidability"] = {
                "fail_open_events": dict(_stage_fail_open)}
            # 2026-08-21 — INFO was the wrong level for "we could not decide
            # most of the island".  A handful of unresolved filters is normal
            # (a non-partition column at the partition stage always is); a
            # stage that fell open on a large share of the SURVIVING files
            # means that stage contributed nothing and the survivors are kept
            # blind.  That is the difference between "pruned 0 because nothing
            # matched" and "pruned 0 because it crashed 3,001 times".
            _blind = max(_stage_fail_open.values())
            _kept = int(_final)          # survivors, set at the funnel's end
            if _kept and _blind >= max(50, _kept // 2):
                logger.warning(
                    "[pruning-decidability] %s: a pruning stage could NOT "
                    "DECIDE %d file(s) while keeping %d — those files are "
                    "kept on NO evidence, not because they match.  "
                    "fail-open events by stage: %s",
                    table_prefix, _blind, _kept, _stage_fail_open)
            else:
                logger.info("[pruning-decidability] %s: fail-open events by "
                            "stage: %s", table_prefix, _stage_fail_open)
    except Exception as _be_exc:
        note_best_effort("logger.warning(...)", _be_exc,
                         logger=logger)

    # ── 2026-08-03 ISLAND SIZE — measurement only, no behaviour change ───
    # Pruning already decoded, per SURVIVING file, ``record_count`` and
    # ``file_size_in_bytes`` from the Iceberg manifests.  So the exact size
    # of the island is known HERE, before a single byte of data is read,
    # for free.
    #
    # Until now that number survived only inside ``_out_meta["completeness"]``
    # and only when the completeness flag was armed, so every downstream
    # consumer was blind to it: ``multi_worker_dispatcher`` passes a
    # hardcoded ``row_estimate=0`` into the engine router, whose
    # ``row_estimate_min: 10_000_000`` rule therefore CANNOT fire — on a
    # query whose island was 17M rows and ~60 GB.
    #
    # Stamp it unconditionally so size-aware decisions become possible.
    # Deliberately NOT wired into routing here: making the router suddenly
    # see 17M where it saw 0 would change engine selection, and that needs
    # its own change with its own evidence.  This commit only stops the
    # system from discarding what it already knows.
    try:
        if _out_meta is not None:
            _out_meta["island_rows"] = int(sum(_record_counts or []))
            _out_meta["island_bytes"] = int(sum(_file_sizes or []))
            _out_meta["island_files"] = int(_final or 0)
    except Exception as _isz_exc:                  # never break the read
        logger.debug("[island-size] stamp skipped (non-fatal): %s", _isz_exc)

    # 2026-10-06 -- the same sizes, PER FILE, where a sizing decision can
    # read them.  The island totals above are one slot (a join's second
    # table overwrites the first) and a log line; resource admission sized
    # a 96 MB one-COB join at 15,481 MB from a per-file constant one second
    # after this stamp.  core/measured_file_bytes is the one keeper.
    try:
        from core.measured_file_bytes import record_many as _mfb_record
        _mfb_record(bucket, zip(data_file_keys, _file_sizes))
    except Exception as _mfb_exc:                  # never break the read
        logger.debug("[measured-bytes] record skipped (non-fatal): %s",
                     _mfb_exc)

    # 2026-08-03 — ALSO publish the island size to the read-strategy shadow
    # observer.  ``_out_meta`` is parent-process-only and never crosses the
    # DuckDB process boundary, so the stamp above cannot be read by the one
    # site (``duckdb_s3_plan.plan_s3_setup``) that both processes share.
    # This makes the value actually reachable instead of write-only.
    # Note the deliberate ``or 0`` in the sum above: a manifest entry with no
    # ``file_size_in_bytes`` contributes 0 silently, so a 0 total means
    # UNMEASURED, not empty — ``IslandSize.known`` encodes that distinction.
    try:
        from core.s3_read_strategy import set_island_size as _set_island
        # 2026-08-04 — also record the table's schema WIDTH (top-level
        # column count of the current schema).  The subprocess spawn reads
        # it as a ROW_GROUP_SIZE hint for the child when the child's own
        # LIMIT-0 width probe fails (the 40 GB incident), and the split
        # gate uses bytes+width to stop 31x900-column scans being refused
        # as "too few files".
        _isz_cols = -1
        try:
            if metadata:
                _isz_sid = metadata.get("current-schema-id")
                _isz_schemas = metadata.get("schemas") or (
                    [metadata["schema"]] if "schema" in metadata else [])
                _isz_cur = next(
                    (s for s in _isz_schemas
                     if s.get("schema-id") == _isz_sid),
                    _isz_schemas[0] if _isz_schemas else None,
                )
                if _isz_cur:
                    _isz_cols = len(_isz_cur.get("fields") or []) or -1
        except Exception:
            _isz_cols = -1
        _set_island(island_bytes=int(sum(_file_sizes or [])),
                    island_files=int(_final or 0),
                    detail=f"table_prefix={table_prefix}",
                    island_columns=_isz_cols)
        # One greppable [GATE] line for the pruning outcome — the single
        # most consequential decision in a query's life (P5, 2026-08-04).
        try:
            from core.log_style import gate as _isz_gate, human_bytes as _hb
            _isz_gate(
                logger, "prune.island", "PASS",
                f"island carved for {table_prefix}",
                files=int(_final or 0),
                bytes=_hb(sum(_file_sizes or [])) or "unknown",
                rows=int(sum(_record_counts or [])),
                columns=(_isz_cols if _isz_cols > 0 else "unknown"),
            )
        except Exception as _be_exc:
            note_best_effort("_isz_gate(...)", _be_exc,
                             logger=logger)
    except Exception as _isz_pub_exc:              # never break the read
        logger.debug("[island-size] publish skipped (non-fatal): %s",
                     _isz_pub_exc)

    # ── 2026-07-16 COMPLETENESS CONTROL · Tier 1 — metadata RECEIPT ──────
    # Build ``_out_meta["completeness"]`` from METADATA ONLY (no data scan):
    # expected_rows = Σ record_count(kept) − Σ position-delete records.
    # rows_read stays None (verdict "unverified") until the READ PATH calls
    # completeness_control.finalize_completeness with the engine's scan count.
    # Also stamps the capped prune_receipt.  Then (Tier 3) enqueues an async
    # shadow sample IFF eligible + a re-executor is registered — OFF and inert
    # by default.  Wrapped fail-open: NEVER alters data_file_keys, NEVER raises.
    try:
        import core.completeness_control as _cc
        if _out_meta is not None and _cc.metadata_check_enabled():
            try:
                from core.duckdb_views import _DL_EXEC_ID_CTX as _cc_ctx
                _cc_exec_id = _cc_ctx.get(None)
            except Exception:
                _cc_exec_id = None
            _cc_pos = sum(int((f or {}).get("record_count", 0) or 0)
                          for f in (_out_meta.get("pos_delete_files") or []))
            _cc_eq = sum(int((f or {}).get("record_count", 0) or 0)
                         for f in (_out_meta.get("eq_delete_files") or []))
            _cc_receipt = _cc.build_completeness_receipt(
                table_prefix=table_prefix,
                kept_files_count=_final,
                kept_record_counts=list(_record_counts),
                pos_delete_records=_cc_pos,
                eq_delete_records=_cc_eq,
                mode=_completeness_mode,
                execution_id=_cc_exec_id,
                prune_entries=_prune_receipt_entries,
            )
            _out_meta["completeness"] = _cc_receipt
            _out_meta["prune_receipt"] = _cc_receipt.get("prune_receipt")
            # ── Phase 2b · AUDITED FILE-INTEGRITY COUNT (opt-in modes only) ──
            # In audited/full_scan mode ONLY, run a CHEAP, UNFILTERED COUNT(*)
            # over the KEPT data files and compare to the PRE-delete declared
            # record_count.  WHERE-agnostic + delete-agnostic → CANNOT
            # false-INCOMPLETE on a filtered / MoR query.  Mutates _cc_receipt in
            # place (== _out_meta["completeness"]) so the certificate block below
            # sees the finalized verdict.  Fully fail-open: NEVER raises, NEVER
            # alters data_file_keys, ZERO added cost in fast mode.
            try:
                if (_completeness_mode in (_cc.MODE_AUDITED, _cc.MODE_FULL_SCAN)
                        and _cc.audited_file_integrity_count_enabled()):
                    _conn_id = _connection_id_from_s3_client(s3_client)
                    _phys = _cc.audited_file_integrity_count(
                        bucket, list(data_file_keys), _conn_id, db_manager)
                    if _phys is not None:
                        _cc.finalize_file_integrity(_cc_receipt, _phys)
            except Exception as _fi_exc:
                logger.debug("[completeness] audited file-integrity skipped "
                             "(fail-open): %s", _fi_exc)
            # ── Tier 3 enqueue (async, off the hot path, inert by default) ──
            _cc_reexec = _cc.get_reexecutor()
            if _cc_reexec is not None:
                _cc_sample_ctx = {
                    "bucket": bucket,
                    "table_prefix": table_prefix,
                    "partition_filters": partition_filters,
                    "kept_file_keys": list(data_file_keys),
                    "snapshot_id": effective_snapshot_id,
                    "connection_id": connection_id,
                    "table_name": table_name,
                }
                _cc.maybe_enqueue_shadow_sample(
                    execution_id=_cc_exec_id,
                    table_prefix=table_prefix,
                    mode=_completeness_mode,
                    rerun_fn=(lambda _ctx=_cc_sample_ctx, _fn=_cc_reexec: _fn(_ctx)),
                    out_meta=_out_meta,
                )
    except Exception as _cc_exc:
        # FAIL-OPEN: completeness control must never break or alter the query.
        logger.debug("[completeness] receipt/sample skipped (fail-open): %s",
                     _cc_exc)

    # ── 2026-07-18 COMPLETENESS CERTIFICATE (core.completeness_certificate) ──
    # Fuse the signals just stamped on _out_meta (completeness receipt,
    # scan_ledger, snapshot id/total-data-files, adaptive_freshness) + the
    # Sentinel quarantine state into ONE fail-CLOSED provable-completeness
    # verdict for THIS table scan (query scope), and stamp it onto
    # _out_meta["completeness_certificate"].  It rides the exact rails as
    # _out_meta["completeness"] AND is pushed to the per-execution diagnostic
    # store so the report / API envelope can surface it by execution_id
    # without threading it through FederationResult.
    #   • In the default (fast) mode the completeness verdict is still
    #     "unverified" (rows_read is only finalized in audited/full-scan mode)
    #     so the certificate reads UNVERIFIED — HONEST, never a false COMPLETE.
    #   • A HARD-negative present at reader time — scan_ledger over_count
    #     (the "44M→143k"-class manifest fault) or a Sentinel quarantine —
    #     is flagged INCOMPLETE immediately, with NO scan needed.
    # OBSERVATIONAL + fail-open: builds a dict, never touches data_file_keys,
    # never raises.  Multi-table (join) queries stamp per-table; a worst-wins
    # cross-table fusion at the delivery layer is a documented follow-up.
    try:
        if _out_meta is not None:
            import core.completeness_certificate as _cert_mod
            if _cert_mod.enabled():
                try:
                    import core.completeness_control as _cc_q
                    _cert_sentinel: Any = _cc_q.is_quarantined(table_prefix)
                except Exception:
                    _cert_sentinel = None
                import time as _cert_time
                # 2026-08-20 — re-absorb any scan-set truncation ALREADY
                # recorded for this execution (BF-579 cap / listing cap on
                # an earlier table).  Without this, a multi-table query's
                # later per-table certificate build would CLOBBER the
                # store's INCOMPLETE verdict with a clean one.
                try:
                    from core.scan_truncation import fuse_stored_file_cap
                    fuse_stored_file_cap(_out_meta)
                except Exception as _fcap_exc:
                    logger.debug("[cert] file_cap fusion skipped: %s",
                                 _fcap_exc)
                _cert = _cert_mod.build_certificate(
                    _cert_mod.SCOPE_QUERY,
                    table_prefix,
                    out_meta=_out_meta,
                    sentinel_state=_cert_sentinel,
                    issued_at=_cert_time.time(),
                )
                _out_meta["completeness_certificate"] = _cert.to_dict()
                # Best-effort push to the per-execution diagnostic store so the
                # report / API envelope can retrieve it by execution_id (the
                # id is stamped on _out_meta by duckdb_views; ContextVar is the
                # fallback).  Never breaks the query path.
                _cert_eid = (_out_meta.get("execution_id")
                             or _out_meta.get("correlation_id"))
                if not _cert_eid:
                    try:
                        from core.query_diagnostic_store import (
                            get_current_execution_id as _cert_gid)
                        _cert_eid = _cert_gid()
                    except Exception:
                        _cert_eid = None
                if _cert_eid:
                    try:
                        from core.query_diagnostic_store import (
                            record_pruning as _cert_rp)
                        _cert_rp(str(_cert_eid), {
                            "completeness_certificate":
                                _out_meta["completeness_certificate"],
                        })
                    except Exception as _be_exc:
                        note_best_effort("_cert_rp(...)", _be_exc,
                                         logger=logger)
    except Exception as _cert_exc:
        # FAIL-OPEN: the certificate is observational — never break/alter the query.
        logger.debug("[cert] certificate build skipped (fail-open): %s", _cert_exc)

    _filtered_total = _ice_skipped_partition + _ice_skipped_col_stats + _ice_skipped_supplement
    # 2026-07-15: bloom skips added to the breakdown (were tracked but never
    # surfaced) + snapshot id, so the ONE summary line answers "why N files":
    # partition vs column-min/max vs supplement vs bloom (native S3 + sidecar),
    # against which snapshot.  A high bloom skip count on a DATE/INT equality
    # is the fingerprint of the type-mismatch data-loss class — the type-parity
    # gate should keep it at 0 for non-string columns.
    _bloom_skips = int(_ice_skipped_bloom) + int(_ice_skipped_bloom_sidecar)
    # 2026-08-21 — "from %d total" printed _ice_files_considered, which is the
    # entries DECODED after manifest-level bounds pruning, not the table's file
    # count.  With 18 of 23 manifests bounds-pruned it read
    #     "11 data files after pruning (from 10956 total"
    # for a table whose snapshot declares 14,673 — so anyone comparing against
    # the real table size saw a number that matched nothing, and the manifest
    # pruning that skipped 3,717 files was invisible.  Say all three.
    _declared_total = None
    try:
        _declared_total = int((metadata or {}).get("_qs_declared_total_data_files")
                              or 0) or None
    except Exception:
        _declared_total = None
    _total_note = (f"{_ice_files_considered} entries considered"
                   + (f" of {_declared_total} declared in the snapshot"
                      if _declared_total and _declared_total != _ice_files_considered
                      else "")
                   + (f"; {_manifests_pruned_by_bounds} of "
                      f"{_manifests_total_pre_prune} manifests skipped by bounds "
                      f"before any entry was decoded"
                      if _manifests_pruned_by_bounds else ""))
    logger.info(
        "Iceberg table %s → %d data files after pruning (%s · "
        "skipped %d by partition filter · %d by column min/max · "
        "%d by col-stats supplement · %d by bloom [native=%d sidecar=%d] · "
        "%d manifests read in parallel · snapshot=%s)%s",
        table_prefix, _final, _total_note,
        _ice_skipped_partition, _ice_skipped_col_stats, _ice_skipped_supplement,
        _bloom_skips, _ice_skipped_bloom, _ice_skipped_bloom_sidecar,
        len(_manifest_paths), effective_snapshot_id,
        f" (capped at {max_files})" if _hit_limit else "",
    )
    _phase("manifest fetch + entry decode + pruning")
    # Phase 0 — stamp the route on _out_meta OUTSIDE the diagnostics try
    # below: the verdict must survive even a broken emission block.
    if _out_meta is not None:
        _out_meta["seek_route"] = _seek_route
    # ── 2026-08-03 SCAN-ECONOMICS — what did the work SCALE with? ────────
    # One machine-readable record + one INFO line so "pruned 0" is never
    # again indistinguishable from "could not decide", and so operators can
    # see whether metadata cost tracked the ISLAND (survivors) or the OCEAN
    # (table size).  Diagnostic only — never affects the file set.
    try:
        _scan_econ = {
            # manifest level (BEFORE any manifest body fetch/decode)
            "manifests_total":             int(_manifests_total_pre_prune),
            "manifests_pruned_by_bounds":  int(_manifests_pruned_by_bounds),
            "manifests_fetched":           int(_cache_diag.get("manifests_attempted") or 0),
            "snapshot_cache_hit":          bool(_bf296_cache_hit),
            # Phase 0 (2026-08-22) — the verdict fields: WHICH route served
            # enumeration, and how many REAL S3 GETs this scan issued
            # (counted at the _read_s3_bytes chokepoint, never inferred).
            "seek_route":                  _seek_route,
            "s3_gets":                     int(_s3_ctr.value
                                               - _s3_gets_at_entry),
            # LIST round-trips.  Reported SEPARATELY from s3_gets rather than
            # folded in: they have very different costs and conflating them
            # would trade one blind spot for another.
            "s3_lists":                    int(_s3_list_ctr.value
                                               - _s3_lists_at_entry),
            # entry level
            "entries_decoded":             int(_ice_files_considered),
            "files_survived":              int(_final),
            "pruned_by_stage": {
                "partition":       int(_ice_skipped_partition),
                "hive_island":     int(_hive_island_pruned),
                "col_stats":       int(_ice_skipped_col_stats),
                "supplement":      int(_ice_skipped_supplement),
                "bloom_native":    int(_ice_skipped_bloom),
                "bloom_sidecar":   int(_ice_skipped_bloom_sidecar),
            },
            # decidability — fail-open events per stage ("could not decide")
            "fail_open_events":            dict(_stage_fail_open),
            # metadata-fetch economics (DB rows pulled for prune evidence)
            "supplement_rows_fetched":     len(_supplement_bounds or {}),
            "bloom_rows_fetched":          len(_bloom_sidecar_bounds or {}),
            "bloom_untyped_decisions":     int(_ice_bloom_untyped_decisions),
            "island_exact": bool(_island_exact),
            "metadata_load_scope": _evidence_scope_kind,
            "island_scope_paths": (
                len(_island_scope_paths)
                if _island_scope_paths is not None else None),
            "evidence_scope_paths": (
                len(_evidence_scope_paths)
                if _evidence_scope_paths is not None else None),
        }
        if _out_meta is not None:
            _out_meta["scan_economics"] = _scan_econ
        logger.info(
            "SCAN-ECONOMICS %s: seek_route=%s s3_gets=%d · manifests %d "
            "total → %d bounds-pruned → %d "
            "fetched (cache_hit=%s) · entries_decoded=%d → survivors=%d · "
            "pruned{partition=%d hive=%d col_stats=%d supplement=%d "
            "bloom=%d+%d} · fail_open=%s · evidence_rows{supp=%d bloom=%d "
            "scope=%s%s}",
            table_prefix,
            _scan_econ["seek_route"], _scan_econ["s3_gets"],
            _scan_econ["manifests_total"],
            _scan_econ["manifests_pruned_by_bounds"],
            _scan_econ["manifests_fetched"],
            _scan_econ["snapshot_cache_hit"],
            _scan_econ["entries_decoded"], _scan_econ["files_survived"],
            _ice_skipped_partition, _hive_island_pruned,
            _ice_skipped_col_stats, _ice_skipped_supplement,
            _ice_skipped_bloom, _ice_skipped_bloom_sidecar,
            _scan_econ["fail_open_events"] or "{}",
            _scan_econ["supplement_rows_fetched"],
            _scan_econ["bloom_rows_fetched"],
            _scan_econ["metadata_load_scope"],
            (f":{_scan_econ['evidence_scope_paths']}"
             if _scan_econ["evidence_scope_paths"] is not None else ""),
        )
    except Exception as _se_exc:
        logger.debug("scan-economics emission skipped (diagnostic only): %s",
                     _se_exc)

    # ONE line for every filter column that is not a partition field, instead
    # of one paragraph each restating the same spec.  This is normal and not a
    # fault: a non-partition column is pruned later, by column stats.
    if _unresolved_pf_cols:
        logger.info(
            "[partition-match] %s: %d filter column(s) are NOT partition "
            "fields and were passed to the column-stats stage instead: %s.  "
            "Partition fields on this table: %s.",
            table_prefix, len(_unresolved_pf_cols), _unresolved_pf_cols,
            list((partition_spec or {}).keys()),
        )

    # ── 2026-08-21 — ONE BLOCK AN OPERATOR CAN SHARE ─────────────────────
    # Operator: "can logs nicely...should defind stage with some icons...
    # something so i can share line rather trying to copy everything...some
    # unneccessary logs there".
    #
    # Fair.  Answering "why was that slow" meant copying twenty interleaved
    # lines out of a file that also carries heartbeats and HTTP access logs,
    # and the numbers that matter were spread across SCAN-ECONOMICS, the phase
    # timer, the decidability summary and the footer-capture lines.
    #
    # This is ONE log record, greppable by the single token ``QS-SCAN``, with
    # a status marker per stage so the failing one is visible without reading
    # any numbers.  It adds no work: every value is already computed above.
    #
    # Diagnostics only — wrapped so it can never affect a query, including on
    # a console whose encoding cannot render the markers.
    try:
        def _n(v):
            try:
                return f"{int(v):,}"
            except Exception:
                return str(v)

        _qs_elapsed = _time.monotonic() - _phase_t0
        # Undecidable AT THE PRUNE STAGE.  STEP 4 may then have gone and
        # fetched the evidence, so the two figures are deliberately distinct:
        # _qs_undecided is what step 3 could not judge, _qs_blind is what is
        # STILL unjudged once step 4 has run.  Reporting the first as the
        # final answer overstates the problem by everything step 4 resolved.
        _qs_undecided = max((_stage_fail_open or {}).values(), default=0)
        _qs_blind = _qs_undecided
        if _footer_capture_meta is not None:
            _qs_blind = int(_footer_capture_meta.get("still_blind") or 0)
        _qs_decoded = int(_scan_econ.get("entries_decoded") or 0)
        _qs_surv = int(_scan_econ.get("files_survived") or 0)
        _qs_s3 = len(_manifests_fetched_from_s3)
        _qs_s3_gets = int(_scan_econ.get("s3_gets") or 0)
        _qs_s3_lists = int(_scan_econ.get("s3_lists") or 0)
        _qs_mf_att = int(_scan_econ.get("manifests_fetched") or 0)

        # 1 — ISLAND.  No island means the read had to enumerate everything.
        if _p3_island_filters:
            _qs_isl = ("OK", _island_spec_display(_p3_island_filters))
        else:
            _qs_isl = ("WARN", "none - enumerating the WHOLE snapshot "
                               "(no eq/IN/date-range predicate on an "
                               "identity partition)")

        # 2 — MANIFESTS.  s3= is REAL object reads; cached= came from L1/L2.
        _qs_mf = ("OK" if _qs_s3 == 0 else "..",
                  f"{_n(_scan_econ.get('manifests_total'))} total -> "
                  f"{_n(_scan_econ.get('manifests_pruned_by_bounds'))} pruned "
                  f"by bounds | s3={_qs_s3} cached={max(0, _qs_mf_att - _qs_s3)}")

        # 3 — PRUNE.  "blind" is the number we could not DECIDE, kept anyway.
        _qs_pr = ("WARN" if _qs_blind >= max(50, _qs_surv // 2) else "OK",
                  f"{_n(_qs_decoded)} -> {_n(_qs_surv)} files"
                  f" | partition {_n(_ice_skipped_partition)}"
                  f" | supplement {_n(_ice_skipped_supplement)}"
                  f" | col-stats {_n(_ice_skipped_col_stats)}"
                  + (f" | undecided {_n(_qs_undecided)}"
                     + (" -> see STEP 4" if _footer_capture_meta else "")
                     if _qs_undecided else ""))

        # Descriptive STEP names, not numbers: an operator reading this once
        # should not have to know the pipeline to know which stage misbehaved.
        # Status is the first thing on each row so the bad one is findable
        # without reading any figures.
        _qs_lines = [
            "",
            "  +-- QS-SCAN " + str(table_prefix) + " " + "-" * max(
                4, 58 - len(str(table_prefix))),
            f"  |  TOTAL {_qs_elapsed:>7.1f}s   ->  {_n(_qs_surv)} file(s) to read",
            f"  |  SEEK   seek_route={_seek_route} · "
            f"entries_decoded={_n(_qs_decoded)} · s3_gets={_n(_qs_s3_gets)}"
            f" · s3_lists={_n(_qs_s3_lists)}",
            "  |",
            f"  |  [{_qs_isl[0]:^4}] STEP 1  FIND ISLAND       {_qs_isl[1]}",
            f"  |  [{_qs_mf[0]:^4}] STEP 2  READ MANIFESTS    {_qs_mf[1]}",
            f"  |  [{_qs_pr[0]:^4}] STEP 3  PRUNE FILES       {_qs_pr[1]}",
        ]
        if _footer_capture_meta:
            _fcm = _footer_capture_meta
            _qs_lines.append(
                f"  |  [{('WARN' if _fcm.get('deadline_hit') else 'OK'):^4}] "
                f"STEP 4  CAPTURE FOOTERS   "
                f"{_n(_fcm.get('candidates'))} undecidable -> "
                f"{_n(_fcm.get('dropped'))} dropped in {_fcm.get('seconds')}s"
                + (" (DEADLINE HIT)" if _fcm.get("deadline_hit") else ""))
        else:
            _qs_lines.append(
                "  |  [ -- ] STEP 4  CAPTURE FOOTERS   not needed "
                "(every survivor had usable bounds)")
        if _qs_blind or not _p3_island_filters:
            _qs_lines.append("  |")
        if _qs_blind:
            _qs_lines.append(
                f"  |  !! {_n(_qs_blind)} file(s) are being read with NO "
                f"EVIDENCE - not because they")
            _qs_lines.append(
                "  |     match, but because nothing could judge them.")
        if not _p3_island_filters:
            _qs_lines.append(
                "  |  !! NO PARTITION ISLAND - this read enumerated the whole "
                "snapshot.")
            _qs_lines.append(
                "  |     See the [island] line above for which predicates were "
                "offered.")
        _qs_lines.append("  +" + "-" * 70)
        logger.info("\n".join(_qs_lines))
    except Exception as _qs_exc:
        logger.debug("QS-SCAN summary skipped (diagnostic only): %s", _qs_exc)
    # ── PARTITION-PRUNING CONTROL (2026-07) — a partitioned table + a partition
    # predicate must NEVER silently full-scan the ocean.  Zero extra S3 I/O:
    # reuses the metadata dict + the data-file keys already in hand.  Two
    # independent is_partitioned signals (raw spec field count — immune to the
    # F1 name/type-drop guard — AND observed hive col=value/ path segments) so a
    # detection regression anywhere upstream cannot make this blind.  Default
    # observe-only; iceberg.require_partition_pruning=true makes it FAIL CLOSED
    # instead of scanning the ocean.  Fully fail-open on its OWN errors.
    try:
        _pp_spec_fields = _active_spec_field_count(metadata) if metadata else 0
        _pp_hive_cols: Set[str] = set()
        for _pp_k in list(data_file_keys or [])[:3]:
            for _pp_seg in str(_pp_k).replace("\\", "/").split("/")[:-1]:
                if "=" in _pp_seg and not _pp_seg.startswith("="):
                    _pp_c = _pp_seg.split("=", 1)[0].strip().lower()
                    if _pp_c and not _pp_c.startswith(("_", ".")):
                        _pp_hive_cols.add(_pp_c)
        _pp_is_partitioned = _pp_spec_fields > 0 or bool(_pp_hive_cols)
        if _out_meta is not None:
            _out_meta["is_partitioned"] = _pp_is_partitioned
        # partition-column identity (source names + field names + hive segments)
        _pp_part_names: Set[str] = set(_pp_hive_cols)
        try:
            _pp_part_names.update(
                str(k).lower() for k in (_extract_partition_spec(metadata) or {}))
            _pp_part_names.update(
                str(k).lower() for k in (build_source_to_partition_field_map(metadata) or {}))
        except Exception as _be_exc:
            note_best_effort("_pp_part_names.update(...)", _be_exc,
                             logger=logger)
        # 2026-08-02 IDENTITY FIX (iceberg_partition_identity_design defect 4):
        # the two DECODE maps above key by derived partition-field name,
        # resolve source names from the current schema's top level only, and
        # F1-drop identity fields with an unresolvable source type — so on a
        # schema-evolved table the query's own partition predicate classified
        # as "not a partition column" and this alarm reported case B ("no
        # partition filter") for the exact prod full-ocean scan it exists to
        # catch.  The identity resolver keeps ALL names (source + field name,
        # union across all specs/schemas, nested walk) and never drops a
        # column merely because its type won't decode.  CLASSIFICATION ONLY —
        # pruning still uses the guarded decode maps above, so extra names can
        # never cause a file to be excluded.
        try:
            _pp_part_names.update(extract_partition_identity_names(metadata)
                                  if metadata else set())
        except Exception as _pp_ident_exc:
            # Not silent: losing identity resolution is exactly how a
            # partitioned table full-ocean-scans while the alarm misreports
            # it as "no partition predicate" (case B).  If this ever fires,
            # that misdiagnosis is the symptom and this is the cause.
            logger.debug(
                "partition identity resolution failed for %s (falling back "
                "to the decode maps, pruning may be reduced): %s",
                table_prefix, _pp_ident_exc)
        # Which WHERE columns ARE partition columns?
        _pp_pred_cols: Set[str] = set()
        for _pp_f in (partition_filters or []):
            _pp_fc = ((_pp_f.get("col") or _pp_f.get("column") or "")
                      .split(".")[-1] or "").strip().lower()
            if _pp_fc and _pp_fc in _pp_part_names:
                _pp_pred_cols.add(_pp_fc)
        # bool(_resolved_pf) == a partition predicate was matched to a spec field
        # and drove the manifest prune.  Empty while _pp_pred_cols is non-empty =
        # the exact prod failure: a partition predicate that never engaged.
        # 2026-07-23: the HIVE-PATH ISLAND fallback also counts as engagement —
        # when it observed its col(s) in the file paths, the partition predicate
        # DID police the scan (island carved from path segments), so the alarm
        # must not report it unengaged / fail closed.
        _pp_engaged = bool(_resolved_pf) or bool(_hive_island_obs_cols)
        _pp_unengaged = _pp_pred_cols if not _pp_engaged else set()
        # Effectively a FULL SCAN of a partitioned table? (nothing skipped by
        # partition AND every considered file kept).
        _pp_full_scan = (_ice_skipped_partition == 0
                         and _final >= _ice_files_considered
                         and _ice_files_considered > 0)
        # CASE A — a partition predicate IS present but never engaged
        #          (detection / spec-matching failure; the classic silent
        #          ocean-dive despite a WHERE on a partition column).
        # CASE B — NO partition predicate at all on a partitioned table and it
        #          full-scans (the query simply didn't filter by partition).
        # 2026-08-02: when filters WERE forwarded but identity resolution came
        # up completely empty (0 partition-column names from spec + schema +
        # hive — a DETECTION failure), we cannot know whether those filters
        # are partition predicates, so "no partition filter" (case B) would be
        # a guess that sends the operator to debug their SQL instead of the
        # engine.  That shape is case A.  Case B now means exactly what it
        # says: identity is known and the query genuinely carries no filter on
        # any partition column.
        _pp_identity_failed = (bool(partition_filters)
                               and not _pp_pred_cols
                               and not _pp_part_names)
        _pp_caseA = (bool(_pp_pred_cols)
                     and (_pp_unengaged or _ice_skipped_partition == 0)) \
            or (_pp_identity_failed and _pp_full_scan)
        _pp_caseB = ((not _pp_pred_cols) and _pp_full_scan
                     and not _pp_identity_failed)
        if _pp_is_partitioned and (_pp_caseA or _pp_caseB):
            try:
                from core.config import get as _cfg_get_pp
                _require_pp = str(_cfg_get_pp(
                    "iceberg", "require_partition_pruning", "false") or "false"
                ).strip().lower() in ("1", "true", "yes", "on")
            except Exception:
                _require_pp = False
            # Fail closed when required on EITHER genuine ocean-dive shape: a
            # partition predicate that couldn't be matched (A — including the
            # identity-resolution-failed sub-shape, which pre-2026-08 raised
            # under the case-B label; the enforcement envelope is preserved,
            # only the diagnosis is corrected), or a partitioned table scanned
            # with no partition filter at all (B).  An engaged predicate that
            # legitimately kept every file (single partition / all-match)
            # alarms but NEVER raises → no false positives.
            # 2026-08-03 — SPLIT the control, because one flag conflated two
            # very different events and that is why it could never be turned on:
            #
            #   ENGINE FAILURE (case A / identity-failed): a partition predicate
            #     WAS supplied and the engine could not use it.  An accidental
            #     ocean dive.  This is the one an operator wants blocked.
            #   USER CHOICE (case B): the query genuinely has no partition
            #     filter.  A full table scan is the CORRECT answer, and failing
            #     it closed breaks legitimate queries — which is exactly why
            #     require_partition_pruning had to stay off.
            #
            # `iceberg.block_accidental_ocean_dive` (default TRUE) refuses only
            # the engine-failure shapes.  `require_partition_pruning` keeps its
            # original meaning — refuse ANY full scan, user choice included —
            # and stays default false.
            try:
                from core.config import get as _cfg_get_ocean
                _block_accidental = str(_cfg_get_ocean(
                    "iceberg", "block_accidental_ocean_dive", "true")
                    or "true").strip().lower() in ("1", "true", "yes", "on")
            except Exception as _ocean_exc:
                logger.debug(
                    "block_accidental_ocean_dive read failed (default on): %s",
                    _ocean_exc)
                _block_accidental = True
            # Only refuse a dive that actually HURTS.  An engine-detection
            # failure on a 6-file table costs nothing and hard-failing it
            # would be a large blast radius for no benefit; the same failure
            # on 14552 files is what OOM-killed a 30 GiB pod.  This is a
            # threshold on when to REFUSE, not a cap on pruning — pruning is
            # never disabled by it.
            try:
                from core.config import get as _cfg_get_min
                _ocean_min = int(_cfg_get_min(
                    "iceberg", "accidental_ocean_dive_min_files", 1000) or 1000)
            except Exception as _min_exc:
                logger.debug("accidental_ocean_dive_min_files read failed "
                             "(default 1000): %s", _min_exc)
                _ocean_min = 1000
            _pp_engine_failure = bool(
                (_pp_unengaged or (_pp_identity_failed and _pp_full_scan))
                and int(_ice_files_considered or 0) >= _ocean_min)
            _pp_enforced = bool(
                (_require_pp and (_pp_unengaged or _pp_caseB
                                  or (_pp_identity_failed and _pp_full_scan)))
                or (_block_accidental and _pp_engine_failure))
            _pp_alarm = {
                "case": "A" if _pp_caseA else "B",
                "is_partitioned": True,
                "has_partition_predicate": bool(_pp_pred_cols),
                "expected_partition_filter_cols": sorted(_pp_pred_cols),
                "engaged": _pp_engaged,
                "unengaged_cols": sorted(_pp_unengaged),
                "identity_resolution_failed": bool(_pp_identity_failed),
                "identity_cols_resolved": len(_pp_part_names),
                "filters_forwarded": len(partition_filters or []),
                "skipped_by_partition": int(_ice_skipped_partition),
                "files_considered": int(_ice_files_considered),
                "files_kept": int(_final),
                # THE field that distinguishes a real ocean dive from an
                # alarm false-positive.  "considered" counts files that
                # reached the PARTITION stage — manifest-level pruning has
                # already run by then.  So considered==kept only means
                # "nothing was skipped HERE", not "nothing was pruned at
                # all".  Without the snapshot's declared total there is no
                # way to tell 31-of-31-in-a-4000-file-table (pruning WORKED
                # upstream) from 31-of-31-in-a-31-file-table (genuine full
                # scan) — and operators were reading the first as the second.
                "declared_total_data_files": _ledger_declared_int,
                "pruned_before_partition_stage": (
                    (int(_ledger_declared_int) - int(_ice_files_considered))
                    if _ledger_declared_int is not None else None),
                "spec_field_count": int(_pp_spec_fields),
                "hive_cols_observed": sorted(_pp_hive_cols),
                "enforced": _pp_enforced,
            }
            if _out_meta is not None:
                _out_meta["partition_pruning_alarm"] = _pp_alarm

            # 2026-08-22 — SEVERITY, not content.  The sub-case "engaged but
            # eliminated 0 files" is the EXPECTED shape when an upstream
            # stage already handed this stage exactly the island: there is
            # nothing left here to eliminate.  ``pruned_before_partition_
            # stage`` exists to tell that apart from a genuine full scan —
            # this is the decision it was added for.  Positive ⇒ pruning
            # worked upstream ⇒ INFO.  Everything else, and anything
            # enforcing, stays ERROR.  An ERROR that fires on healthy
            # queries teaches operators to ignore ERRORs.
            _pp_benign = pruning_alarm_is_benign(
                case_a=_pp_caseA,
                enforced=_pp_enforced,
                unengaged=_pp_unengaged,
                identity_failed=_pp_identity_failed,
                pruned_before_partition_stage=_pp_alarm.get(
                    "pruned_before_partition_stage"))
            _pp_alarm["severity"] = "info" if _pp_benign else "error"
            logger.log(
                logging.INFO if _pp_benign else logging.ERROR,
                "PARTITION-PRUNING ALARM (case %s) for %s: table IS partitioned "
                "(spec_fields=%d, hive=%s) but %s — %d/%d files kept, "
                "skipped-by-partition=%d, declared-total-data-files=%s "
                "(pruned-before-partition-stage=%s).  %s",
                _pp_alarm["case"], table_prefix, _pp_spec_fields,
                sorted(_pp_hive_cols),
                ("the partition predicate(s) on %s NEVER ENGAGED (not matched to "
                 "any partition field)" % sorted(_pp_pred_cols)) if _pp_unengaged
                else ("%d WHERE filter(s) were forwarded but partition-column "
                      "IDENTITY RESOLUTION FAILED (0 names from spec + schema "
                      "+ hive path) — engine detection failure, NOT a missing "
                      "filter" % len(partition_filters or [])
                      if _pp_identity_failed else
                      ("the query has NO partition filter → full table scan"
                       if _pp_caseB else
                       "a partition predicate engaged but eliminated 0 files")),
                _final, _ice_files_considered, _ice_skipped_partition,
                _ledger_declared_int if _ledger_declared_int is not None else "?",
                ((int(_ledger_declared_int) - int(_ice_files_considered))
                 if _ledger_declared_int is not None else "?"),
                "FAILING CLOSED (iceberg.require_partition_pruning=true)."
                if _pp_enforced else
                "Set iceberg.require_partition_pruning=true to fail closed.")
            if _pp_enforced:
                if _pp_caseB:
                    raise IcebergPartitionPruningError(
                        f"Query on partitioned table {table_prefix} has NO "
                        f"partition filter — refusing to full-scan "
                        f"{_ice_files_considered} data files "
                        f"(iceberg.require_partition_pruning=true).  Add a WHERE "
                        f"predicate on a partition column "
                        f"({sorted(_pp_hive_cols) or 'the table partition key'}).")
                if _pp_identity_failed:
                    raise IcebergPartitionPruningError(
                        f"Partition-column IDENTITY RESOLUTION FAILED for "
                        f"partitioned table {table_prefix} (spec_fields="
                        f"{_pp_spec_fields}): {len(partition_filters or [])} "
                        f"WHERE filter(s) were forwarded but could not be "
                        f"classified against any partition column name (spec + "
                        f"schema + hive path all came up empty).  Refusing to "
                        f"full-scan {_ice_files_considered} data files "
                        f"(iceberg.require_partition_pruning=true).  This is an "
                        f"ENGINE detection failure, not a missing filter.  Fix: "
                        f"set registered_tables[].partition_columns in "
                        f"Connection admin, or investigate metadata "
                        f"schema/field-id drift.")
                raise IcebergPartitionPruningError(
                    f"Partition pruning did not engage for table {table_prefix}: "
                    f"partition predicate(s) on {sorted(_pp_unengaged)} could not "
                    f"be matched to the partition spec (spec_fields="
                    f"{_pp_spec_fields}, hive_layout={sorted(_pp_hive_cols)}).  "
                    f"Refusing to full-scan {_ice_files_considered} data files "
                    f"(iceberg.require_partition_pruning=true).  Fix: set "
                    f"registered_tables[].partition_columns in Connection admin, "
                    f"or investigate metadata schema/field-id drift.")
    except IcebergPartitionPruningError:
        raise
    except Exception as _pp_ctrl_exc:
        logger.debug("[partition-control] skipped (fail-open): %s", _pp_ctrl_exc)
    # 2026-07-15 bloom-sidecar self-heal: an eq/in filter was set on column(s)
    # that have NO bloom rows (sidecar enabled but not built) -> nothing could be
    # bloom-pruned.  Fire a background build so the NEXT identical query prunes.
    # Bloom is fail-open, so a background build can never lose data.  Guarded by
    # coverage==0 for the queried cols; throttled + opt-out inside the helper.
    if (_bloom_sidecar_enabled and _bloom_eq_in_cols
            and not _bloom_sidecar_bounds and data_file_keys):
        try:
            _maybe_trigger_async_bloom_scan(
                bucket, table_prefix, metadata,
                [{"key": k} for k in data_file_keys],
                _bloom_eq_in_cols,
                connection_id=_connection_id_from_s3_client(s3_client),
            )
        except Exception as _auto_bloom_exc:
            logger.warning(
                "auto-bloom trigger FAILED for %s (cols=%s): %s",
                table_prefix, _bloom_eq_in_cols, _auto_bloom_exc,
            )
    # ── 2026-07-15 PRUNABILITY PROFILES (audit Finding #3/#4) — decide ─────
    # Merge this scan's per-column evidence into the persistent profile
    # (running average), then DECIDE per eq/in column whether it NEEDS a
    # bloom sidecar — from evidence, on the FIRST query, instead of waiting
    # for 3 lucky query-history hits.  Routes a build (inline self-heal for
    # small tables; loud offline-scan instruction above the probe-safety
    # cap) and exports verdicts to _out_meta["prunability"].
    # ABSOLUTE SAFETY: this block only BUILDS artifacts + emits diagnostics.
    # It never touches data_file_keys and is wrapped fail-open — the
    # returned file list is byte-identical with or without it.
    try:
        if _prof_counters:
            _prof_thresholds = _prunability_thresholds()
            # Columns that already have bloom sidecar rows loaded for THIS
            # query (sidecar disabled / never built → empty → has_bloom
            # False, which is exactly the "no bloom exists yet" evidence).
            _prof_bloom_cols: set = set()
            for _pb_file_cols in (_bloom_sidecar_bounds or {}).values():
                try:
                    _prof_bloom_cols.update(_pb_file_cols.keys())
                except Exception as _be_exc:
                    note_best_effort("_prof_bloom_cols.update(_pb_file_cols.keys())", _be_exc,
                                     logger=logger)
            _prunability_meta: Dict[str, Any] = {}
            _bloom_needed_cols: List[str] = []
            _bloom_needed_reasons: Dict[str, str] = {}
            for _p_col, _p_st in _prof_counters.items():
                _p_eval = int(_p_st.get("evaluated") or 0)
                if _p_eval <= 0:
                    continue
                _p_overlap = (_p_st.get("bounds_could_not_prune") or 0) / _p_eval
                _p_wb = int(_p_st.get("with_bounds") or 0)
                _p_singleton = ((_p_st.get("singleton") or 0) / _p_wb
                                if _p_wb else 0.0)
                # Coverage: prefer the value-independent TABLE-LEVEL counter
                # (Finding #7 — manifest OR supplement over ALL enumerated
                # files); fall back to this query's bound-evaluated set.
                if (_ice_stats_total_enumerated > 0
                        and _p_col in _ice_stats_coverage_all):
                    _p_coverage = (_ice_stats_coverage_all[_p_col]
                                   / _ice_stats_total_enumerated)
                else:
                    _p_coverage = _p_wb / _p_eval
                _p_profile = None
                if db_manager is not None:
                    try:
                        _p_profile = db_manager.iceberg_prunability_upsert(
                            bucket, table_prefix.rstrip("/"), _p_col,
                            stats_coverage_pct=_p_coverage,
                            bounds_overlap_ratio=_p_overlap,
                            singleton_ratio=_p_singleton,
                        )
                    except Exception as _prof_up_exc:
                        logger.debug(
                            "[prunability] profile upsert failed for %s.%s "
                            "(fail-open): %s",
                            table_prefix, _p_col, _prof_up_exc,
                        )
                if not _p_profile:
                    # DB unavailable / no db_manager — decide from THIS
                    # query's evidence alone (the first-query decision
                    # must not depend on a persistence round-trip).
                    _p_profile = {
                        "stats_coverage_pct":   _p_coverage,
                        "bounds_overlap_ratio": _p_overlap,
                        "singleton_ratio":      _p_singleton,
                        "sample_count":         1,
                    }
                _p_has_bloom = _p_col in _prof_bloom_cols
                _p_needed, _p_reason = _bloom_worthiness(
                    _p_profile, survivors=_final, has_bloom=_p_has_bloom,
                    thresholds=_prof_thresholds,
                )
                _prunability_meta[_p_col] = {
                    "stats_coverage_pct":   round(_p_coverage, 4),
                    "bounds_overlap_ratio": round(_p_overlap, 4),
                    "singleton_ratio":      round(_p_singleton, 4),
                    "evaluated_files":      _p_eval,
                    "sample_count":         int(_p_profile.get("sample_count")
                                                or 1),
                    "has_bloom":            _p_has_bloom,
                    "bloom_needed":         _p_needed,
                    "reason":               _p_reason,
                }
                if _p_needed:
                    _bloom_needed_cols.append(_p_col)
                    _bloom_needed_reasons[_p_col] = _p_reason
            if _prunability_meta:
                if _out_meta is not None:
                    _out_meta["prunability"] = _prunability_meta
                logger.info(
                    "[prunability] %s profile verdicts (evidence-based, "
                    "diagnostics/build-routing only): %s",
                    table_prefix,
                    "; ".join(
                        f"{_pm_c}: overlap={_pm_v['bounds_overlap_ratio']:.0%}"
                        f" coverage={_pm_v['stats_coverage_pct']:.0%}"
                        f" singleton={_pm_v['singleton_ratio']:.0%}"
                        f" files={_pm_v['evaluated_files']}"
                        f" bloom_needed={_pm_v['bloom_needed']}"
                        for _pm_c, _pm_v in sorted(_prunability_meta.items())
                    ),
                )
            if _bloom_needed_cols:
                try:
                    from core.config import get as _cfg_prof_cap
                    _prof_auto_max = int(_cfg_prof_cap(
                        "iceberg", "auto_bloom_max_files", 10000))
                except Exception:
                    _prof_auto_max = 1500
                _prof_routed = (
                    "inline_auto_bloom"
                    if (_prof_auto_max <= 0 or _final <= _prof_auto_max)
                    else "offline_scan_required")
                if _out_meta is not None:
                    _out_meta["bloom_needed"] = {
                        "columns": sorted(_bloom_needed_cols),
                        "reasons": dict(_bloom_needed_reasons),
                        "routed":  _prof_routed,
                    }
                if _prof_routed == "inline_auto_bloom":
                    # Small table → reuse the existing self-heal (throttled,
                    # opt-out, probe-safe low concurrency, and re-checks the
                    # cap itself).  Idempotent with the coverage-miss trigger
                    # above thanks to the per-(table, cols) cooldown.
                    _maybe_trigger_async_bloom_scan(
                        bucket, table_prefix, metadata,
                        [{"key": _bn_k} for _bn_k in data_file_keys],
                        sorted(_bloom_needed_cols),
                        connection_id=_connection_id_from_s3_client(s3_client),
                    )
                else:
                    # Above the probe-safety cap: do NOT run a heavy scan on
                    # the query pod — tell the operator exactly what to do.
                    for _bn_col in sorted(_bloom_needed_cols):
                        logger.warning(
                            "[prunability] %s: column %r NEEDS a bloom (%s) "
                            "but the table has %d surviving file(s) — above "
                            "the inline auto-build cap "
                            "(iceberg.auto_bloom_max_files=%d).  Queue the "
                            "OFFLINE scan: POST /api/admin/iceberg/bloom/scan "
                            "(isolated worker).  Until built, eq/in queries "
                            "on this column scan every file (correct, just "
                            "not pruned).",
                            table_prefix, _bn_col,
                            _bloom_needed_reasons.get(_bn_col, ""),
                            _final, _prof_auto_max,
                        )
    except Exception as _prof_exc:
        logger.debug("[prunability] profile block skipped (fail-open): %s",
                     _prof_exc)
    # 2026-07-15 pruning self-audit: trace WHICH files the supplement layer dropped
    # and (opt-in) footer-verify a sample against real min/max to catch stale/wrong
    # cached bounds.  Fail-open + opt-in — a verify error never touches the result.
    if _supp_audit_on and _pruning_audit is not None and _supp_drop_trace:
        try:
            _verify = None
            if _pruning_audit.verify_footers_enabled():
                _verify = _pruning_audit.verify_supplement_drops(
                    s3_client, bucket, _supp_drop_trace, _non_partition_filters,
                )
            _pruning_audit.log_audit(table_prefix, _supp_drop_trace, _verify)
            if _out_meta is not None:
                _out_meta["supplement_drop_audit"] = {
                    "dropped": len(_supp_drop_trace),
                    "verify": _verify,
                }
        except Exception as _audit_exc:
            logger.debug("pruning-audit skipped (fail-open): %s", _audit_exc)
    # If a WHERE filter was set but pruned nothing, flag it loudly —
    # that's the most common admin confusion ("I filtered but still see
    # all files").  Usually means: type mismatch in the filter, or the
    # filter column lacks min/max stats.
    if partition_filters and _filtered_total == 0 and _ice_files_considered > 0:
        if _island_exact:
            # 2026-08-23: with an EXACT island, zero funnel skips means the
            # enumeration already WAS the island (seek-served) or every
            # enumerated file genuinely matches — success, not confusion.
            # The old warning ("filter column isn't a partition column...")
            # would be wrong on every count here.
            logger.info(
                "[island-exact] %s: 0 additional funnel skips — the island "
                "already carved the enumeration to exactly the %d matching "
                "file(s).",
                table_prefix, _final,
            )
        else:
            logger.warning(
                "Iceberg pruning produced ZERO skips for table %s despite "
                "%d filter(s) being set: %s.  Common causes: "
                "(a) filter column isn't a partition column AND writer didn't "
                "save column min/max stats; (b) date/timestamp filter value "
                "format mismatch; (c) bucket/truncate partition without "
                "exact-match filter.  All %d files will be downloaded.",
                table_prefix, len(partition_filters),
                [f.get("col") or f.get("column") for f in partition_filters],
                _final,
            )
    # BF-508 (2026-05-28) — opposite extreme: filter fired AND wiped out
    # every file.  User has been hitting "0 rows for date that should
    # exist" — this is the diagnostic that tells them WHY: their filter
    # value vs the actual partition values present in the manifest.
    if partition_filters and _final == 0 and _ice_files_considered > 0 and _diag_partition_samples:
        _filter_summary = [
            f"{f.get('col') or f.get('column')} {f.get('op') or f.get('operator')} {f.get('val') or f.get('value')!r}"
            for f in partition_filters
        ]
        _sample_summary = {
            _pf: sorted(_vals)[:_DIAG_PARTITION_SAMPLE_CAP]
            for _pf, _vals in _diag_partition_samples.items()
            if _vals
        }
        logger.warning(
            "Iceberg pruning result for table %s: 0 files survived from %d considered. "
            "Filter(s): %s.  Distinct partition values actually seen in manifest "
            "(sample up to %d per field): %s.  If the value you're looking for IS "
            "in the sample, this is a format-mismatch bug (e.g., bare-date vs "
            "timestamp string).  If NOT in the sample, the snapshot genuinely "
            "doesn't contain rows for that partition — check the writer side "
            "(Spark/Trino COMMIT may not have landed yet, or the snapshot pointer "
            "is stale).  Snapshot id used: %s.",
            table_prefix, _ice_files_considered, _filter_summary,
            _DIAG_PARTITION_SAMPLE_CAP, _sample_summary,
            (metadata or {}).get("current-snapshot-id"),
        )

    # BF-PRUNE-PERF — push the pruning summary into execution_stage extras
    # so the live UI timeline (ExecutionLiveTimeline + heartbeat WS event)
    # can show "3032 / 14025 files (skipped 10930 by partition + 0 by
    # column stats)" instead of just a spinner.
    try:
        from core.duckdb_views import _DL_EXEC_ID_CTX as _exec_ctx2
        _exec_id_for_prune = _exec_ctx2.get(None)
    except Exception:
        _exec_id_for_prune = None
    if _exec_id_for_prune:
        try:
            from core.execution_stage import (
                update_progress as _upd_prog,
                add_extras as _stg_extras2,
            )
            _table_qual2 = table_prefix.rstrip("/").replace("/", ".") or "_unknown"
            # 2026-09-01 — this call passed ``files_total=``, which
            # ``update_progress`` does not accept (it is keyword-only:
            # files_done / files_delta / bytes_* / rows_done / message / log;
            # ``set_stage`` is the one that takes a total).  So it raised
            # TypeError every time.
            #
            # The damage was not the progress line.  Both calls sat in ONE
            # try, so the TypeError also skipped ``_stg_extras2`` — and the
            # four iceberg_* pruning extras below were never recorded on any
            # query.  That is exactly the telemetry an operator reaches for
            # when asking why pruning is slow.  The handler then blamed
            # "_stg_extras2(...)", which is the call that never got to run.
            #
            # The considered-count is not lost: it is in the message and in
            # ``iceberg_files_considered__*`` below.
            _upd_prog(_exec_id_for_prune,
                       files_done=_final,
                       message=(f"{table_prefix}: {_final} files after pruning "
                                f"of {_ice_files_considered} considered "
                                f"({_ice_skipped_partition} skipped by partition, "
                                f"{_ice_skipped_col_stats} by column stats)"))
        except Exception as _be_exc:
            note_best_effort("_upd_prog(...)", _be_exc, logger=logger)
        # Separate try: the extras are the durable record, and a failure in
        # the progress line above must not take them with it.  Sharing one
        # handler is what hid this for as long as it lasted.
        try:
            _stg_extras2(_exec_id_for_prune, **{
                f"iceberg_files_after_pruning__{_table_qual2}":   int(_final),
                f"iceberg_files_considered__{_table_qual2}":      int(_ice_files_considered),
                f"iceberg_skipped_by_partition__{_table_qual2}":  int(_ice_skipped_partition),
                f"iceberg_skipped_by_col_stats__{_table_qual2}":  int(_ice_skipped_col_stats),
            })
        except Exception as _be_exc:
            note_best_effort("_stg_extras2(...)", _be_exc,
                             logger=logger)

    # BF-316 — bound-coverage report.  Tells admin EXACTLY which filter
    # columns lack writer-side min/max stats.
    # BF-PRUNE-PERF: SUPPRESS the warning for columns that are ALSO
    # partition columns — Iceberg writers deliberately don't store
    # column min/max for partition columns (the partition path IS the
    # stat).  Pruning still works at PARTITION level for them, so the
    # "no min/max" warning is misleading.  Only warn for genuinely-
    # unprunable non-partition filter columns.
    _partition_col_names_lower = {str(k).lower() for k in (partition_spec or {})}
    # BF-377: also suppress the "no min/max" warning for columns the
    # supplement covers — admin already scanned them, pruning DOES work
    # via the supplement bounds.  Otherwise the warning misleadingly
    # implies the scan was wasted.
    _supp_cols_lower_for_warn: set = set()
    for _file_cols in _supplement_bounds.values():
        _supp_cols_lower_for_warn.update(_file_cols.keys())
    # 2026-07-15: coverage is measured ONLY over files that survived partition
    # pruning (the counter sits after the partition-skip `continue`), and column
    # stats are now PER-FILE (v3 supplement) — so a given filter VALUE that
    # leaves a different surviving-file set legitimately sees different coverage.
    # Report against the surviving set (not the grand total), and name the
    # value/per-file dependency so "cries for 'ABC' but not 'SAP'" isn't a
    # mystery.  Correctness is identical either way; this only affects pruning.
    _bound_eval_files = max(0, int(_ice_files_considered) - int(_ice_skipped_partition))
    if _ice_bound_coverage and _bound_eval_files > 0:
        for _fc, _count in _ice_bound_coverage.items():
            _pct = (100.0 * _count / _bound_eval_files) if _bound_eval_files else 0.0
            _fc_bare_lower = (_fc or "").split(".")[-1].lower()
            if _count == 0:
                if _fc_bare_lower in _partition_col_names_lower:
                    logger.debug(
                        "Iceberg %s: filter column %r has no column-stats "
                        "(but it's a PARTITION column — pruned via partition "
                        "path, not column min/max; this is normal).",
                        table_prefix, _fc,
                    )
                    continue
                if _fc_bare_lower in _supp_cols_lower_for_warn:
                    logger.info(
                        "Iceberg %s: filter column %r has no manifest "
                        "min/max — pruning via per-file column-stats "
                        "supplement (admin scanned it).",
                        table_prefix, _fc,
                    )
                    continue
                logger.warning(
                    "Iceberg %s: filter column %r has NO min/max bounds in the "
                    "%d file(s) that survived partition pruning AND no per-file "
                    "supplement bounds for them — column-stats pruning "
                    "unavailable FOR THIS query.  Note: coverage is per-file, so "
                    "a different filter value that leaves a different file set "
                    "can look different.  To prune anyway: run the per-file "
                    "column-stats scan (or bloom scan) from admin for this "
                    "column.",
                    table_prefix, _fc, _bound_eval_files,
                )
            elif _count < _bound_eval_files:
                logger.info(
                    "Iceberg %s: filter column %r has bounds on %d/%d surviving "
                    "file(s) (%.0f%%) — partial pruning available (per-file "
                    "coverage; varies by which files a filter value leaves).",
                    table_prefix, _fc, _count, _bound_eval_files, _pct,
                )

    # ── Phase 4 (industrialization, 2026-07-23) — within-island supplement ──
    # Coverage-0 filter columns used to ONLY warn (the block above) and then
    # fail OPEN forever: every island file kept, nothing ever fixed it.  When
    # ``industrialization.supplement_on_zero_coverage`` is ON, the detection
    # is surfaced LOUDLY (structured log + _out_meta) and a BACKGROUND
    # per-file min/max build is scheduled for exactly (table, snapshot,
    # column) via the EXISTING scan_files_to_supplement machinery —
    # single-flighted per (table, snapshot, column) through the
    # iceberg_supplement_build_v1 marker so query storms can't stampede.
    # INVARIANT: building stats NEVER changes results — the supplement holds
    # TRUE footer bounds, and the consume path (the supplement prune stage
    # above, which runs on ISLAND survivors AFTER the partition stage) keeps
    # any file without bounds.  Flag OFF (default) → this block is a single
    # flag read → today's behavior byte-for-byte.  FAIL-OPEN: any error →
    # debug log, query untouched.
    try:
        from core.industrialization import is_enabled as _wis_enabled
        if (_wis_enabled("supplement_on_zero_coverage")
                and _ice_bound_coverage and _bound_eval_files > 0):
            from core.within_island_supplement import (
                get_controller as _wis_get_controller,
            )
            _wis_entries_ref = _all_entries   # captured for the lazy closure

            def _wis_file_keys() -> List[str]:
                """Full pinned-snapshot file list (BF-547 pattern) — built
                from manifest entries ALREADY in memory, zero S3 I/O.
                Bucket-relative keys, matching the supplement store."""
                _keys: List[str] = []
                _seen: set = set()
                for _w_ents in (_wis_entries_ref or []):
                    for _w_ent in _w_ents:
                        if not isinstance(_w_ent, dict):
                            continue
                        _w_df = _w_ent.get("data_file") or {}
                        if not isinstance(_w_df, dict):
                            continue
                        _w_fp = (_w_df.get("file_path")
                                 or _w_df.get("path") or "")
                        if not _w_fp.endswith(".parquet"):
                            continue
                        _w_key = _s3_uri_to_key(_w_fp)
                        if _w_key and _w_key not in _seen:
                            _seen.add(_w_key)
                            _keys.append(_w_key)
                return _keys

            # Per-column supplement file counts (flag-ON only; one walk of
            # the already-loaded supplement dict).
            _wis_supp_counts: Dict[str, int] = {}
            for _w_file_cols in _supplement_bounds.values():
                for _w_sc in _w_file_cols.keys():
                    _wis_supp_counts[_w_sc] = _wis_supp_counts.get(_w_sc, 0) + 1
            _wis_meta = _wis_get_controller().observe_and_schedule(
                db_manager=db_manager,
                bucket=bucket,
                table_prefix=table_prefix,
                table_name=table_name,
                snapshot_id=(str(effective_snapshot_id)
                             if effective_snapshot_id else ""),
                connection_id=_connection_id_from_s3_client(s3_client),
                manifest_coverage=dict(_ice_bound_coverage),
                island_files=int(_bound_eval_files),
                partition_cols_lower=set(_partition_col_names_lower),
                supplement_file_counts=_wis_supp_counts,
                non_partition_filters=list(_non_partition_filters or []),
                file_keys_fn=_wis_file_keys,
            )
            if _wis_meta and _out_meta is not None:
                _out_meta["within_island_supplement"] = _wis_meta
    except Exception as _wis_exc:
        logger.debug(
            "[within-island] observe/schedule skipped (fail-open): %s",
            _wis_exc,
        )

    # 2026-07-15 (Finding #7) — TABLE-LEVEL, value-independent stats coverage.
    # The survivor-based report above is per-QUERY (measured only over files
    # that survived partition pruning, so it varies with the filter VALUE).
    # This one is measured over ALL enumerated (deduped) files BEFORE any
    # prune, so the operator sees the true table-level picture: "column X has
    # bounds (manifest OR supplement) on N of M files, period".  Fail-open.
    try:
        if _ice_stats_coverage_all and _ice_stats_total_enumerated > 0:
            if _out_meta is not None:
                _out_meta["stats_coverage"] = {
                    _cov_c: {
                        "files_with_bounds": int(_cov_n),
                        "total_enumerated":  int(_ice_stats_total_enumerated),
                    }
                    for _cov_c, _cov_n in _ice_stats_coverage_all.items()
                }
            logger.info(
                "Iceberg %s TABLE-LEVEL stats coverage (value-independent, "
                "manifest OR supplement bounds, over ALL %d enumerated "
                "file(s)): %s",
                table_prefix, _ice_stats_total_enumerated,
                "; ".join(
                    f"{_cov_c}={_cov_n}/{_ice_stats_total_enumerated} "
                    f"({100.0 * _cov_n / _ice_stats_total_enumerated:.0f}%)"
                    for _cov_c, _cov_n in sorted(_ice_stats_coverage_all.items())
                ),
            )
    except Exception as _cov_all_exc:
        logger.debug("table-level stats coverage export skipped (fail-open): %s",
                     _cov_all_exc)

    # ── 2026-07-15 BRAIN DIAGNOSTICS EXPORT — user-facing "Why N files?" ──
    # Every diagnostic below is ALREADY stamped into _out_meta by the blocks
    # above (scan_ledger, prunability, bloom_needed, stats_coverage,
    # adaptive_freshness, duplicate_data_file_refs, snapshot_total_data_files)
    # but until now only reached logs.  Summarise them into ONE compact blob
    # and push it through the SAME execution_stage extras pipeline the
    # file-count summary already uses, so:
    #   - the live heartbeat WS event can narrate pruning while running;
    #   - /status + persisted stage_history.extras serve the completed panel.
    # PURE READ + FAIL-OPEN: never touches data_file_keys, never raises.
    try:
        from core.duckdb_views import _DL_EXEC_ID_CTX as _bd_exec_ctx
        _bd_exec_id = _bd_exec_ctx.get(None)
    except Exception:
        _bd_exec_id = None
    if _bd_exec_id and _out_meta is not None:
        try:
            from core.brain_diagnostics import build_brain_diagnostics
            from core.execution_stage import add_extras as _bd_extras
            _bd_blob = build_brain_diagnostics(
                _out_meta,
                table_prefix=table_prefix,
                files_scanned=_final,
                files_considered=_ice_files_considered,
                skipped_partition=_ice_skipped_partition,
                skipped_col_stats=_ice_skipped_col_stats,
                connection_id=_connection_id_from_s3_client(s3_client),
                table_name=table_name,
            )
            if _bd_blob:
                _bd_qual = (table_prefix.rstrip("/").replace("/", ".")
                            or "_unknown")
                _bd_extras(_bd_exec_id,
                           **{f"brain_diagnostics__{_bd_qual}": _bd_blob})
        except Exception as _bd_exc:
            logger.debug("brain diagnostics export skipped (fail-open): %s",
                         _bd_exc)

    # ── 2026-07-16 COMPLETENESS SENTINEL — autonomous pruning-trust agent ──
    # FUSE the signals the brain just stamped into _out_meta (completeness
    # verdict, scan_ledger verdict, per-column stats_coverage, prunability
    # overlap, adaptive_freshness, shadow incident) and let the Sentinel DECIDE
    # whether pruning is untrustworthy for THIS table.  It only ever decides
    # MODES (fast↔audited↔full_scan via resolve_table_mode on the NEXT query)
    # and can trigger the watcher to re-capture stored stats — it NEVER alters
    # this query's data_file_keys / rows.  PURE OBSERVATION + fully fail-open.
    if _out_meta is not None:
        try:
            import core.completeness_sentinel as _sentinel
            if _sentinel.enabled():
                try:
                    from core.duckdb_views import _DL_EXEC_ID_CTX as _sn_ctx
                    _sn_exec_id = _sn_ctx.get(None)
                except Exception:
                    _sn_exec_id = None
                _sn_signals = _sentinel.extract_signals(
                    _out_meta,
                    resync_ctx={
                        "connection_id": _connection_id_from_s3_client(s3_client),
                        "bucket": bucket,
                        "table_prefix": table_prefix,
                    },
                    execution_id=_sn_exec_id,
                )
                _sentinel.get_sentinel().observe(table_prefix, _sn_signals)
        except Exception as _sn_exc:
            # FAIL-OPEN: the Sentinel must never break or alter a query.
            logger.debug("[sentinel] observe skipped (fail-open): %s", _sn_exc)

    # BF-316 — hard cap on file count.  Prevents accidentally massive
    # downloads: if the surviving file list exceeds the cap, raise an
    # actionable error with diagnostics.  Configurable.
    try:
        from core.config import get as _cfg_get
        _max_files_query = int(_cfg_get("iceberg", "max_files_per_query", 0) or 0)
    except Exception:
        _max_files_query = 0
    # BF-319: skip the cap when caller is metadata-only (sync reconcile,
    # partition picker, etc.).  Cap exists to stop user QUERIES from
    # silently scanning thousands of files; metadata enumeration that
    # never reads data should not be blocked.
    if (enforce_max_files_cap
            and _max_files_query > 0
            and _final > _max_files_query
            and not _hit_limit):
        _zero_bound_cols = [c for c, v in _ice_bound_coverage.items() if v == 0]
        raise ValueError(
            f"Iceberg query would scan {_final} data files for table "
            f"{table_prefix} (cap: {_max_files_query}).  "
            f"Pruning result: from {_ice_files_considered} total · "
            f"skipped {_ice_skipped_partition} by partition · "
            f"skipped {_ice_skipped_col_stats} by column min/max."
            + (
                f"  Filter columns with NO min/max stats: {_zero_bound_cols} — "
                f"add them as partitions OR re-write the table with column "
                f"statistics enabled OR raise iceberg.max_files_per_query."
                if _zero_bound_cols else
                "  Add a more selective WHERE clause OR raise "
                "iceberg.max_files_per_query."
            )
        )

    # Phase 139 (Tier 1.1): emit Iceberg pruning telemetry — fail-open
    try:
        from core.metrics import record_files_skipped
        if _ice_files_considered > 0:
            record_files_skipped("iceberg", considered=_ice_files_considered,
                                 skipped=_ice_skipped_partition, reason="partition")
            if _ice_skipped_col_stats:
                record_files_skipped("iceberg", considered=0,
                                     skipped=_ice_skipped_col_stats, reason="column_stats")
    except Exception as _be_exc:
        note_best_effort("record_files_skipped(...)", _be_exc,
                         logger=logger)

    if len(data_file_keys) == 0 and partition_filters:
        # Diagnostic: log exactly why every file was pruned
        logger.warning(
            "0 data files found after entry-level pruning for %s — "
            "partition_spec=%s  partition_filters=%s  manifests_scanned=%d",
            table_prefix, partition_spec, partition_filters, len(_manifest_paths),
        )
        # Sample the first manifest to show what partition values actually exist
        if _manifest_paths:
            try:
                _sample_data = _read_s3_bytes(s3_client, bucket, _manifest_paths[0])
                _sample_entries = _read_avro(_sample_data)[:3]
                for _se in _sample_entries:
                    _df = _se.get("data_file") or {}
                    logger.warning(
                        "  Sample entry: status=%s partition=%s file=%s",
                        _se.get("status"), _df.get("partition"), _df.get("file_path", "")[-60:],
                    )
            except Exception as _diag_err:
                logger.warning("  Could not sample manifest for diagnostics: %s", _diag_err)

    # Phase Z (2026-06-09) — unified JOIN-PRUNER emit via the
    # BoundAggregator.  The aggregator already tracked per-col source
    # attribution (partition / manifest_stats / supplement) so the
    # report() method returns it without recomputation.  Emit shape
    # preserved for backward-compat: _out_meta["join_key_bounds"] +
    # _out_meta["join_key_distinct_values"].  New key
    # ``join_key_bound_report`` surfaces source attribution + per-col
    # files_covered/files_missing into the diagnose UI.
    # 2026-07-14 DATA-LOSS GUARD: if the file walk stopped early on a
    # max_files / max_rows cap (_hit_limit), the aggregator observed only a
    # PREFIX of the surviving files, so its IN-list / bounds are an INCOMPLETE
    # build-side domain.  Pushing a partial equality set to the joined table
    # would drop matching rows.  Currently every join_key_columns caller passes
    # max_files=0 so this can't trigger, but emit NOTHING under a cap so a
    # future max_files>0 + join_key_columns caller can't silently lose rows.
    #
    # 2026-07-15 (audit finding #6) — COMPLETENESS ATTESTATION for runtime
    # join dynamic filtering.  duckdb_views' runtime SELECT-DISTINCT IN-list
    # push requires PROOF that the anchor's file enumeration was complete;
    # this stamp is that proof (True only when no max_files/max_rows cap
    # truncated the walk).  Consumers treat a MISSING key as "not proven"
    # (no push), so early-return paths that don't stamp it are fail-safe.
    if _out_meta is not None:
        _out_meta["file_enumeration_complete"] = (not _hit_limit)
    if _out_meta is not None and _bound_aggregator is not None and not _hit_limit:
        _emit_bounds = _bound_aggregator.emit_bounds()
        _emit_distinct = _bound_aggregator.emit_distinct(max_distinct=200)
        _report = _bound_aggregator.report()
        # Bloom join-prune (2026-07-13): also emit a HIGHER-cap complete
        # distinct set for bloom-membership file pruning.  emit_distinct only
        # returns a set when EVERY anchor file is single-valued (complete BY
        # CONSTRUCTION — singletons is nulled the instant any file is
        # multi-valued or missing a bound), so a bigger cap stays correct: it
        # just captures more COMPLETE key sets.  Bloom tests thousands of keys
        # per file cheaply (unlike the SQL IN-list, which we keep capped at
        # 200 to avoid huge WHERE fragments).
        try:
            from core.config import get as _cfg_get_jb
            _bloom_cap = int(_cfg_get_jb("iceberg", "join_bloom_max_distinct", 50000) or 50000)
        except Exception:
            _bloom_cap = 50000
        _emit_distinct_bloom = (
            _bound_aggregator.emit_distinct(max_distinct=_bloom_cap)
            if _bloom_cap > 200 else dict(_emit_distinct)
        )
        # AUDIT FIX (2026-07-13, HIGH): bloom join-prune is SAFE only for column
        # types whose anchor-key encoding (_decode_bound here) is BYTE-IDENTICAL
        # to the bloom build-side encoding (_value_to_bytes on pyarrow values in
        # the sidecar scanner).  DECIMAL diverges (anchor strips trailing zeros:
        # "100.5" vs bloom "100.50") and TIMESTAMP diverges ("2026-01-01T..+00:00"
        # vs "2026-01-01 ..+00:00") -> bloom_can_contain_any would return False
        # for a target file that DOES contain the key -> silently drop joining
        # rows.  Restrict the bloom key set to parity-proven types
        # (integers / string / boolean / date); skip decimal, timestamp,
        # float/double and anything we can't type-verify.  The SQL IN-list path
        # (join_key_distinct_values) is untouched — it prunes via column stats,
        # not bloom bytes, so it stays available for all types.
        if _emit_distinct_bloom:
            try:
                _bloom_types: Dict[str, str] = {}
                _b_sid = metadata.get("current-schema-id")
                _b_schemas = metadata.get("schemas") or []
                _b_cur = next(
                    (s for s in _b_schemas if s.get("schema-id") == _b_sid),
                    _b_schemas[0] if _b_schemas else None,
                )
                if _b_cur:
                    for _bf in _b_cur.get("fields") or []:
                        _bn, _bt = _bf.get("name"), _bf.get("type")
                        if _bn and isinstance(_bt, str):
                            _bloom_types[_bn.lower()] = _bt
                _emit_distinct_bloom = {
                    _c: _v for _c, _v in _emit_distinct_bloom.items()
                    if _is_bloom_parity_safe_type(_bloom_types.get(_c))
                }
            except Exception as _bt_exc:
                logger.debug(
                    "[bloom-join-prune] type-gate failed, emitting nothing "
                    "(safe): %s", _bt_exc)
                _emit_distinct_bloom = {}
        # F4 (2026-08-22): stamp UNCONDITIONALLY (may be {}).  Presence
        # means "the aggregation RAN" — the memo populate uses that as its
        # proof-of-computation; every consumer reads the dict's CONTENT,
        # and an empty dict is falsy exactly like the absent key was.
        _out_meta["join_key_bounds"] = _emit_bounds
        if _emit_distinct:
            _out_meta["join_key_distinct_values"] = _emit_distinct
        if _emit_distinct_bloom:
            _out_meta["join_key_distinct_values_bloom"] = _emit_distinct_bloom
        if _report:
            _out_meta["join_key_bound_report"] = _report
        # Phase Z.4 self-heal — when JOIN-PRUNER finds ZERO bounds for
        # a join key (no provider has data), queue an async column-
        # stats scan for that col.  Next query gets bounds for free.
        # Reuses BF-547 throttling so a query storm doesn't queue
        # duplicate scans.  Operator opt-out via the same config flag.
        if _report:
            _heal_cols = sorted(
                col for col, rep in _report.items()
                if not rep.get("has_bounds") and not rep.get("sources")
            )
            if _heal_cols:
                try:
                    from core.config import get as _cfg_get_heal
                    _heal_enabled = bool(_cfg_get_heal(
                        "iceberg", "auto_supplement_on_query_miss", False))
                except Exception:
                    _heal_enabled = False
                if _heal_enabled:
                    try:
                        _maybe_trigger_async_supplement_scan(
                            s3_client, bucket, table_prefix,
                            metadata,
                            [{"key": k} for k in data_file_keys],
                            _heal_cols,
                            connection_id=_connection_id_from_s3_client(s3_client),
                        )
                        logger.info(
                            "Phase Z self-heal: queued column-stats "
                            "scan for join keys %s on %s — next "
                            "query benefits.",
                            _heal_cols, table_prefix,
                        )
                    except Exception as _heal_exc:
                        logger.debug(
                            "Phase Z self-heal trigger failed: %s",
                            _heal_exc,
                        )
            # Phase Z (2026-06-09) — also push the report to the
            # per-execution registry so the diagnose UI can render
            # per-col source attribution without re-reading manifests.
            try:
                _exec_id_for_report = (
                    _out_meta.get("execution_id")
                    or _out_meta.get("correlation_id")
                )
                if not _exec_id_for_report:
                    try:
                        from core.query_diagnostic_store import get_current_execution_id
                        _exec_id_for_report = get_current_execution_id()
                    except Exception:
                        _exec_id_for_report = None
                if _exec_id_for_report:
                    from core.brain.scan_plan import record_bound_report
                    record_bound_report(
                        _exec_id_for_report,
                        table_name=(table_name or table_prefix or "")
                                    .rstrip("/").split("/")[-1] or table_prefix,
                        report=_report,
                    )
            except Exception as _reg_exc:
                logger.debug("record_bound_report failed: %s", _reg_exc)
        if _emit_bounds:
            logger.info(
                "JOIN-PRUNER: aggregated bounds for %s on %d column(s) over "
                "%d surviving files: %s · sources=%s",
                table_prefix, len(_emit_bounds), len(data_file_keys),
                {k: (str(v[0])[:40], str(v[1])[:40])
                 for k, v in _emit_bounds.items()},
                {k: _report.get(k, {}).get("sources", []) for k in _emit_bounds},
            )
        else:
            # Loud signal: caller requested bounds but aggregator found
            # NOTHING.  Report tells operator WHICH sources had data and
            # which didn't — actionable next step.
            logger.warning(
                "JOIN-PRUNER: requested cols=%s on %s — NO bounds "
                "aggregated.  Per-col report: %s",
                list(join_key_columns or []), table_prefix, _report,
            )
        if _emit_distinct:
            logger.info(
                "JOIN-PRUNER: distinct values for %s on %d column(s): %s "
                "(every surviving file had single-value bounds)",
                table_prefix, len(_emit_distinct),
                {k: len(v) for k, v in _emit_distinct.items()},
            )

    # 2026-09-06 -- THE BRAIN'S ONLY INPUT, made reachable.
    #
    # This block used to live INLINE below, after the `if keys_only:
    # ... return` short-circuit, guarded by `if _out_meta is not None`.
    # An AST sweep of all 34 call sites found the two preconditions are
    # never satisfied together: every caller that passes `_out_meta`
    # also passes `keys_only=True` (that is what query execution wants
    # -- paths, not per-object HEADs), and the only callers that take
    # the `keys_only=False` default are the connection-browse endpoints,
    # which pass no `_out_meta`.  So `record_pruning_history` -- the
    # ONLY writer of `query_pruning_history` on the iceberg road, and
    # the table `brain_cost_model` (>=10 rows) and `brain_skew_detector`
    # (>=5 rows) read before they predict anything -- had never been
    # reached by a query.  Measured: 0 rows after 14 journeys over every
    # S3 shape.  A brain with no input is not a brain.
    #
    # Defining it HERE, above the short-circuit, is deliberate: a nested
    # closure captures the ~17 locals the payload needs (`_ice_skipped_*`,
    # `_scan_ledger`, `_bf296_snap_key`, ...) without an 18-parameter
    # signature that a future edit could silently forget to thread.
    # `_pre_mirror_source_file_count` is the ONE value that differs
    # between the two call sites, so it is the one parameter.
    def _emit_brain_observation(_pre_mirror_source_file_count: int) -> None:
        """Record what this scan decided: diagnostic store, pruning-IQ
        verdict, lazy freshness trigger, pruning history row, scan plan.

        Caller gates on `_out_meta is not None` and on the config key,
        so this body is the SAME work on both paths.
        """
        _exec_id_final = _out_meta.get("execution_id") or _out_meta.get("correlation_id")
        if not _exec_id_final:
            try:
                from core.query_diagnostic_store import get_current_execution_id
                _exec_id_final = get_current_execution_id()
            except Exception:
                _exec_id_final = None
        # Per-WHERE-clause breakdown classification.  Phase 147 upgrade —
        # column-aware verdict when metadata is in scope so the diagnose
        # UI sees the same classification the pre-flight endpoint emits.
        # Bug F fix: build the spec ONCE outside the loop (was per-filter,
        # so N filters meant N redundant partition-spec walks).
        _bug_f_spec = None
        try:
            from core.pruning_support import (
                PruneSupportClassifier as _PSC_cls,
                build_table_spec_from_iceberg_metadata as _PSC_build,
            )
            _bug_f_spec = _PSC_build(metadata or {})
            _bug_f_classifier = _PSC_cls.get_default()
        except Exception:
            _bug_f_spec = None
            _bug_f_classifier = None

        _filter_breakdown: List[Dict[str, Any]] = []
        try:
            for _pf in (partition_filters or []):
                _col = str(_pf.get("col") or _pf.get("column") or "")
                _op  = str(_pf.get("op")  or _pf.get("operator") or "")
                # Bug B fix: read singular ``value`` as the fallback (was
                # plural ``values`` which mismatched the classifier's own
                # dual-key read at pruning_support.py:320).  Plural form
                # not observed in any prod call path; this restores
                # symmetry with the classifier + every other reader.
                _val = (
                    _pf.get("val") if "val" in _pf
                    else _pf.get("value") if "value" in _pf
                    else _pf.get("values")
                )
                _col_kind = ""
                if _bug_f_classifier is not None:
                    _r = _bug_f_classifier.classify(
                        {"col": _col, "op": _op, "val": _val},
                        _bug_f_spec,
                    )
                    _lvl, _why = _r.support, _r.reason
                    # Persist column_kind so brain_skew_detector +
                    # writer_advisor can reason about partition / bucket
                    # / truncate / time-proj cols from history without
                    # re-deriving from metadata.  Without this the skew
                    # detector silently returns [].
                    _col_kind = (getattr(_r, "column_kind", "") or "")
                else:
                    _lvl, _why = _classify_filter_with_spec(
                        {"col": _col, "op": _op, "val": _val},
                        metadata=metadata,
                    )
                _filter_breakdown.append({
                    "column":           _col,
                    "operator":         _op,
                    "value":            _val if not isinstance(_val, (list, tuple))
                                              else list(_val)[:10],
                    "support":          _lvl,
                    "support_reason":   _why,
                    "column_kind":      _col_kind,
                })
        except Exception:
            _filter_breakdown = []
        # files_after_prune carries the SOURCE post-prune count even when
        # Phase 150 swapped the file list to a mirror — the metric is
        # about pruning effectiveness, not routing outcome.  The mirror
        # routing decision lives in its own payload field.
        _files_after = int(_pre_mirror_source_file_count)
        _mirror_decision_payload = None
        try:
            _mirror_decision_payload = _out_meta.get("mirror_decision")
        except Exception:
            _mirror_decision_payload = None
        _payload = {
            "files_before_prune":   int(_ice_files_considered or 0),
            "files_after_prune":    _files_after,
            "stage_drops": {
                "partition":      int(_ice_skipped_partition),
                "column_stats":   int(_ice_skipped_col_stats),
                "supplement":     int(_ice_skipped_supplement),
                # 149.4: DB-backed bloom sidecar (separate from BF-548 S3 bloom)
                "bloom_sidecar":  int(_ice_skipped_bloom_sidecar),
                "bloom":          int(_ice_skipped_bloom),
            },
            "filter_breakdown":     _filter_breakdown,
            # 2026-07-15 Scan Ledger (Finding #1) — self-reconciliation verdict
            # against the snapshot's declared total-data-files.  None when the
            # ledger block failed open.  Surfaces alongside pruning_iq in the
            # diagnose UI / pruning history.
            "scan_ledger":          _scan_ledger,
            "bucket":               bucket,
            "table_prefix":         table_prefix,
            "snapshot_id":          _bf296_snap_key or str(snapshot_id or ""),
            # Phase 150 — surfaces in the diagnose UI as a "served from
            # mirror" chip when routed.  None when not eligible.
            "mirror_decision":      _mirror_decision_payload,
        }
        # 2026-09-27 -- the MANIFEST side of the same scan, for the
        # report-scoped disclosure (core/reports/scan_disclosure.py): how
        # many manifests the snapshot lists and how many bodies this scan
        # opened.  None -- never 0 -- when a counter was not reached, so
        # "not recorded" stays distinguishable from "nothing to read".
        try:
            _payload["manifests_total"] = int(_manifests_total_pre_prune)
        except Exception:                                    # noqa: BLE001
            _payload["manifests_total"] = None
        try:
            _payload["manifests_read"] = len(_manifest_paths)
        except Exception:                                    # noqa: BLE001
            _payload["manifests_read"] = None
        # 2026-10-08 -- the query_pruning_history row is written by the ONE
        # recording point every return of this function passes through
        # (_record_reader_observation); the walk hands it this rich
        # payload (classified filters, stage drops, ledger, IQ verdict --
        # the keys added below land too, it is the same dict).  Writing
        # the row here as well would double the walk road and leave the
        # other seven roads silent, which is the 2026-10-08 defect.
        _observe_road(None, payload=_payload)

        # 2026-06-24 -- Pruning IQ verdict.  Single per-query
        # classification that tells the operator at-a-glance whether
        # this scan is LEGITIMATE (full_scan_intended /
        # partition_pruned_well) or BROKEN (partition_filter_
        # ineffective, cold_brain, pruning_hostile_filter,
        # no_filter_hot_table).  Closes the "is 4000 valid or
        # broken?" visibility gap.  Surfaces via brain_trace +
        # files_metadata.brain_pruning_iq.  Fail-safe: classify()
        # never raises on partial inputs.
        try:
            from core.brain_pruning_iq import (
                classify as _classify_iq, trace as _trace_iq,
            )
            # filter_columns from filter_breakdown (list of
            # {"col": ..., "operator": ..., ...} dicts).
            _filter_cols = []
            for _fb in (_filter_breakdown or []):
                _col = _fb.get("col") or _fb.get("column")
                if _col:
                    _filter_cols.append(str(_col))
            # partition_columns from iceberg metadata.
            _part_cols: list = []
            try:
                _part_spec = (_out_meta or {}).get("partition_spec_columns")
                if isinstance(_part_spec, list):
                    _part_cols = [str(c) for c in _part_spec]
            except Exception as _be_exc:
                note_best_effort("_part_cols = [str(c) for c in _part_spec]", _be_exc,
                                 logger=logger)
            # supplement_coverage: per-filter-column boolean.  2026-06-25
            # bug fix (brain deep dive): the original wire-in set the
            # SAME value (_had_supp_drops) for EVERY filter column ->
            # cold_brain verdict either never fired (when ANY supplement
            # drops happened, all cols got marked covered) OR fired for
            # every filter col uniformly (when no drops).  Mixed-coverage
            # queries (col_a covered, col_b not) had col_b's cold_brain
            # condition silently masked.
            #
            # Fix: only mark a column as KNOWN-MISSING (False) when we
            # KNOW supplement scans didn't help on this query AND that
            # column has no historical coverage.  Otherwise leave the
            # key absent -- the classifier treats absence as "covered"
            # which is the safe default (cold_brain only fires on
            # explicit False).  The cost is that we under-report
            # cold_brain rather than over-report it -- the operator
            # asks the explicit /scan-now endpoint when they want a
            # certain answer.
            _supp_coverage: dict = {}
            _had_supp_drops = int(_ice_skipped_supplement or 0) > 0
            if not _had_supp_drops:
                # No supplement help on this query.  Best signal we
                # have that the brain hasn't scanned the touched cols
                # -- but only mark filter cols, not partition cols
                # (partition pruning works without supplement).
                for _c in _filter_cols:
                    if _c not in _part_cols:
                        _supp_coverage[_c] = False
            # else: leave coverage dict empty (= "covered" via the
            # classifier's default).  Operator can pull the explicit
            # per-column coverage from the bloom_sidecar / supplement
            # tables if they need precise answers.
            _verdict = _classify_iq(
                files_total=int(_ice_files_considered or 0)
                            or _files_after,
                files_after_prune=_files_after,
                filter_columns=_filter_cols,
                partition_columns=_part_cols,
                stage_drops=_payload["stage_drops"],
                supplement_coverage=_supp_coverage,
                pruning_hostile_columns=[],   # SQL classifier feeds
                                              # this later
                auto_rewrite_applied=False,   # same
            )
            _trace_iq(_verdict)
            _payload["pruning_iq"] = _verdict.to_dict()
            # Operator-visible WARNING line when verdict is broken.
            if _verdict.severity == "broken":
                logger.warning(
                    "[pruning-iq] BROKEN for %s/%s -- %s | %s",
                    bucket, table_prefix,
                    _verdict.summary, _verdict.diagnosis,
                )
        except Exception as _iq_exc:
            logger.debug(
                "[pruning-iq] classify failed (non-fatal): %s",
                _iq_exc,
            )
        # 149.10 -- lazy brain-freshness trigger.  When a newer snapshot
        # exists than the one the brain last scanned, queue a delta scan
        # so the NEXT query gets full coverage.
        #
        # 2026-09-06 -- DEFAULT OFF, and the comment this replaces was
        # wrong: it said "fire-and-forget -- never blocks the current
        # query".  Only the SCAN is on a thread.  Before ensure_fresh can
        # decide whether to dispatch one it builds an S3 client, calls
        # get_iceberg_snapshot_id_only (measured +1 S3 GET) and 3 DB
        # queries -- all on the request thread, on EVERY iceberg query.
        # Measured on the wire rig with this key on: the two iceberg
        # journeys go 6 -> 7 and 7 -> 8 S3 round trips, +1 GET each.
        # Worse, those round trips re-read a snapshot id we are already
        # holding in current_snapshot_id.  See _lazy_freshness_on_query.
        if _lazy_freshness_on_query():
            try:
                from core.brain_freshness import ensure_fresh as _ef
                from core.query_history_prefetcher import (
                    make_default_s3_client_factory as _mksf,
                )
                _ef_factory = (_mksf(db_manager)
                               if db_manager is not None else None)
                if _ef_factory is not None and bucket and table_prefix:
                    _ef(db_manager, _ef_factory, bucket, table_prefix,
                        source="lazy", blocking=False)
            except Exception as _ef_lazy_exc:
                logger.debug(
                    "[149.10] lazy brain_freshness trigger failed for "
                    "%s/%s: %s", bucket, table_prefix, _ef_lazy_exc,
                )
        if _exec_id_final:
            try:
                from core.query_diagnostic_store import record_pruning
                record_pruning(str(_exec_id_final), _payload)
            except Exception as _be_exc:
                note_best_effort("record_pruning(str(_exec_id_final), _payload)", _be_exc,
                                 logger=logger)
            # (The DB row -- /api/admin/queries/pruning-history -- is
            # written by _record_reader_observation, see above.)

            # Phase N (2026-06-08) -- shadow-write to the unified
            # PruneContext / ScanPlan so /api/admin/queries/scan-plan
            # serves the full decision flow.  Best-effort; never blocks.
            # Once Phase R deletes the legacy paths, this becomes the
            # primary write site.
            try:
                from core.brain.scan_plan import (
                    PruneContext, TableScanPlan, Decision,
                    DecisionGate, DecisionAction, PruningSource,
                    get_recent, remember,
                )
                from core.brain.filter import (
                    BrainFilter, FilterSource,
                )
                _ctx = get_recent(str(_exec_id_final))
                if _ctx is None:
                    _ctx = PruneContext(execution_id=str(_exec_id_final))
                    remember(_ctx)
                _tn = (table_name
                       or (table_prefix.rstrip("/").rsplit("/", 1)[-1]
                           if table_prefix else "iceberg_table"))
                _plan = _ctx.find_table(_tn)
                if _plan is None:
                    _plan = TableScanPlan(
                        table_name=_tn,
                        connection_id=connection_id,
                        bucket=bucket or "",
                        table_prefix=(table_prefix or "").rstrip("/"),
                        snapshot_id=_bf296_snap_key or str(snapshot_id or ""),
                    )
                    _ctx.add_table(_plan)
                _plan.filters_received = [
                    BrainFilter.from_legacy_dict(
                        f, source=FilterSource.WHERE_CLAUSE)
                    for f in (partition_filters or [])
                ]
                _plan.files_before = int(_ice_files_considered or 0)
                _plan.files_final = int(_files_after)
                # Per-stage drops as Decisions
                if _ice_skipped_partition:
                    _plan.record(Decision(
                        gate=DecisionGate.PARTITION_PRUNE,
                        action=DecisionAction.ENGAGED,
                        reason="manifest partition bounds pruned files",
                        files_before=int(_ice_files_considered or 0),
                        files_after=int(_ice_files_considered or 0) - int(_ice_skipped_partition),
                    ))
                if _ice_skipped_col_stats:
                    _plan.record(Decision(
                        gate=DecisionGate.COLUMN_STATS_PRUNE,
                        action=DecisionAction.ENGAGED,
                        reason="iceberg manifest stats pruned files",
                        files_before=int(_ice_files_considered or 0) - int(_ice_skipped_partition),
                        files_after=int(_ice_files_considered or 0) - int(_ice_skipped_partition) - int(_ice_skipped_col_stats),
                    ))
                if _ice_skipped_supplement:
                    _plan.record(Decision(
                        gate=DecisionGate.SUPPLEMENT_PRUNE,
                        action=DecisionAction.ENGAGED,
                        reason="supplement-v2 column bounds pruned files",
                        files_before=int(_ice_files_considered or 0) - int(_ice_skipped_partition) - int(_ice_skipped_col_stats),
                        files_after=_files_after,
                    ))
                _plan.pruning_source = (
                    PruningSource.L2_DB_FIRST
                    if (_out_meta and _out_meta.get("db_first_hit"))
                    else PruningSource.L3_MANIFEST
                )
                # Phase 150 — surface the mirror-routing decision on the
                # plan so the diagnose UI can render "served from mirror".
                _plan.mirror_decision = _mirror_decision_payload
                _ctx.finalize()
                # DB persist of the full plan.
                #
                # 2026-09-06 -- gated, DEFAULT OFF.  Measured on the
                # wire rig at query cadence this is a SYNCHRONOUS
                # SELECT + INSERT/UPDATE + COMMIT costing p50 3.1 ms /
                # max 30 ms per iceberg table per query on local
                # sqlite -- ~200x everything else in this function
                # combined (the classify + pruning-IQ + history-queue
                # put total 14 us).  It is also not what the brain
                # reads: query_pruning_history is, and that write is
                # a queue.put_nowait.  The scan-plan endpoint reads
                # the IN-MEMORY context first and only falls back to
                # this table, so off it still answers for recent
                # queries; what is lost is durability across a
                # restart.  See config iceberg.persist_scan_plan_on_query.
                if db_manager is not None and _persist_scan_plan_on_query():
                    try:
                        _ctx.persist(db_manager)
                    except Exception as _be_exc:
                        note_best_effort("_ctx.persist(db_manager)", _be_exc,
                                         logger=logger)
            except Exception as _sp_exc:
                logger.debug(
                    "[scan_plan] shadow-write failed (legacy paths unaffected): %s",
                    _sp_exc,
                )

    # ── 2026-09-28 THE EMPTY ISLAND — proven, re-proven, or widened ──────
    # "0 files" after pruning becomes 0 rows with status completed: the one
    # answer this reader may never give on a guess.  It is PROVEN only when
    # the gate independently justified EVERY drop that produced it (file
    # drops and manifest-summary drops, none sampled out, none delegated).
    # Unproven on the caller's pass -> this function re-runs itself with
    # the gate FORCED to enforce (every unjustified drop is restored) ->
    # still unproven -> it runs once more with NO partition filters at all
    # (the full enumeration; DuckDB applies the WHERE).  Slower, never
    # wrong.  The verdict travels in ``_out_meta["empty_island"]`` and the
    # consumers (BF-504 empty-view paths) refuse an unproven empty.
    if (_final == 0 and int(_empty_island_pass) < 2
            and (partition_filters or _non_partition_filters)
            and max_files == 0 and not _hit_limit):
        try:
            from core.pruning_gate import (
                FORCED_MODE as _ei_forced, MODE_ENFORCE as _ei_enforce,
                empty_island_verdict as _ei_verdict)
            _ei_gate_sum = _gate.summary() if _gate is not None else None
            _ei_fc_dropped = int((_footer_capture_meta or {}).get("dropped") or 0)
            _ei_file_drops = (int(_ice_skipped_partition)
                              + int(_ice_skipped_col_stats)
                              + int(_ice_skipped_supplement)
                              + int(_ice_skipped_bloom)
                              + int(_ice_skipped_bloom_sidecar)
                              + _ei_fc_dropped)
            _ei_proven, _ei_reason = _ei_verdict(
                _ei_gate_sum, gate_armed=_gate is not None,
                files_dropped=_ei_file_drops,
                manifests_dropped=int(_manifests_pruned_by_bounds or 0),
                hit_limit=bool(_hit_limit))
            _ei_stamp: Dict[str, Any] = {
                "proven": bool(_ei_proven), "reason": _ei_reason,
                "pass": int(_empty_island_pass),
                "files_dropped": _ei_file_drops,
                "manifests_dropped": int(_manifests_pruned_by_bounds or 0),
            }
            if _out_meta is not None:
                _out_meta["empty_island"] = _ei_stamp
            if _ei_proven:
                logger.info("[empty-island] %s: 0 files PROVEN on pass %d (%s)",
                            table_prefix, _empty_island_pass, _ei_reason)
                _observe_road("empty_island", files_after=0,
                              empty_island=dict(_ei_stamp))
            else:
                _fail_open("empty_island_unproven")
                _ei_common = dict(
                    keys_only=keys_only, max_files=max_files,
                    metadata=metadata, force_fresh=force_fresh,
                    snapshot_id=snapshot_id,
                    as_of_timestamp_ms=as_of_timestamp_ms, max_rows=max_rows,
                    enforce_max_files_cap=enforce_max_files_cap,
                    connection_id=connection_id, table_name=table_name,
                    db_manager=db_manager, or_groups=None,
                    file_order=file_order, join_key_columns=join_key_columns,
                    sql_hash=sql_hash)
                _ei_child_meta: Dict[str, Any] = {}
                if int(_empty_island_pass) == 0:
                    logger.warning(
                        "[empty-island] %s: 0 files after pruning is UNPROVEN "
                        "(%s) -- re-proving with the pruning gate FORCED to "
                        "enforce mode (unjustified drops are restored).",
                        table_prefix, _ei_reason)
                    _ei_tok = _ei_forced.set(_ei_enforce)
                    try:
                        _ei_res = get_iceberg_data_files(
                            s3_client, bucket, table_prefix,
                            partition_filters=partition_filters,
                            _out_meta=_ei_child_meta, _empty_island_pass=1,
                            **_ei_common)
                    finally:
                        _ei_forced.reset(_ei_tok)
                else:
                    logger.error(
                        "[empty-island] %s: 0 files after pruning is UNPROVEN "
                        "even under enforce (%s) -- WIDENING to the full "
                        "enumeration; DuckDB applies the WHERE.  Slower, "
                        "never wrong.", table_prefix, _ei_reason)
                    _ei_res = get_iceberg_data_files(
                        s3_client, bucket, table_prefix,
                        partition_filters=None,
                        _out_meta=_ei_child_meta, _empty_island_pass=2,
                        **_ei_common)
                    if not _ei_res:
                        # The UNFILTERED enumeration is empty: the snapshot
                        # holds no data file at all.  That IS the proof.
                        _ei_child_meta["empty_island"] = {
                            "proven": True, "pass": 2,
                            "reason": "full enumeration (no partition filters) is empty",
                            "files_dropped": 0, "manifests_dropped": 0}
                if _out_meta is not None:
                    _ei_child_stamp = dict(_ei_child_meta.get("empty_island") or {
                        "proven": False, "pass": int(_empty_island_pass) + 1,
                        "reason": "widened"})
                    _ei_child_stamp["widened_from"] = _ei_stamp
                    _ei_child_stamp["widened_to"] = len(_ei_res or [])
                    _ei_child_meta["empty_island"] = _ei_child_stamp
                    _out_meta.update(_ei_child_meta)
                logger.warning(
                    "[empty-island] %s: pass %d served %d file(s) (proven=%s).",
                    table_prefix, int(_empty_island_pass) + 1,
                    len(_ei_res or []),
                    (_out_meta or {}).get("empty_island", {}).get("proven")
                    if _out_meta is not None else "?")
                # 2026-10-08 -- the child pass is a nested reader call: its
                # walk stamped files_before and the drops; this is the list
                # the query reads.
                _observe_road("empty_island", files_after=len(_ei_res or []),
                              empty_island=dict(
                                  (_out_meta or {}).get("empty_island") or {}))
                return _ei_res
        except Exception as _ei_exc:
            logger.error(
                "[empty-island] %s: proof / widening FAILED (%s) -- the "
                "0-file answer is UNPROVEN and stamped so.", table_prefix,
                _ei_exc, exc_info=True)
            if _out_meta is not None:
                _out_meta["empty_island"] = {
                    "proven": False, "pass": int(_empty_island_pass),
                    "reason": f"proof failed: {_ei_exc}"}

    # ── Step 6: Batch-fetch S3 metadata (replaces N×head_object) ─────────────
    # Skip this expensive step when caller only needs file paths (e.g. query execution)
    if keys_only:
        # 2026-06-04 audit fix — the keys_only short-circuit USED to return
        # size-less dicts AND skip _apply_scan_order entirely, making
        # ScanStrategist file_order wiring a silent no-op for every BQB
        # iceberg query (duckdb_views.setup_registered_views passes
        # keys_only=True).  Now: populate size_bytes from the manifest
        # (already in _file_sizes) AND run _apply_scan_order so smallest_first
        # / largest_first / size_balanced actually take effect.
        _ko_result = [
            {"key": key, "path": key, "type": "parquet",
             "record_count": rc, "size_bytes": sz}
            for key, rc, sz in zip(data_file_keys, _record_counts, _file_sizes)
        ]
        try:
            _ko_result = _apply_scan_order(_ko_result, file_order)
        except Exception as _ko_sort_exc:
            logger.debug(
                "scan-strategy ordering on keys_only path failed "
                "(degrading to manifest order): %s", _ko_sort_exc,
            )
        # Pre-mirror source count -- see _emit_brain_observation.
        _ko_pre_mirror_count = len(_ko_result)
        # Phase 8 + Phase 150 — reader substitution at keys_only return.
        _ko_result = _apply_read_substitutions(
            db_manager=db_manager,
            metadata=metadata,
            bucket=bucket,
            table_prefix=table_prefix,
            snapshot_id=current_snapshot_id,
            source_files=_ko_result,
            _out_meta=_out_meta,
        )
        # 2026-09-06 -- the observation the brain was never given.  Same
        # work the full path does; `_ko_pre_mirror_count` is captured
        # BEFORE the Phase 150 substitution so `files_after_prune` keeps
        # its meaning (pruning effectiveness, not routing outcome).
        _observe_road("walk", files_after=_ko_pre_mirror_count,
                      files_before=int(_ice_files_considered or 0),
                      snapshot_id=current_snapshot_id,
                      unless=("empty_island",))
        if _out_meta is not None and _record_query_observations():
            _emit_brain_observation(_ko_pre_mirror_count)
        # Phase 156 -- memo POPULATE via module-level helper.
        # 2026-08-03: gate-aware (see _phase156_memo_populate docstring).
        _phase156_memo_populate(
            sql_hash=sql_hash,
            snapshot_id=current_snapshot_id,
            bucket=bucket, table_prefix=table_prefix,
            surviving_files=_ko_result,
            db_manager=db_manager,
            join_key_columns=join_key_columns,
            force_fresh=force_fresh,
            gate=_gate,
            scan_meta=_memo_scan_meta_from_out(_out_meta),
        )
        return _ko_result

    s3_meta = _batch_s3_metadata(s3_client, bucket, data_file_keys)

    result: List[Dict[str, Any]] = []
    for _i, key in enumerate(data_file_keys):
        meta = s3_meta.get(key, {})
        result.append({
            "key":           key,
            # 2026-10-08 -- the manifest's record_count (parallel list), as
            # the keys_only road has exported since 2026-06-04; the LIMIT
            # early stop reads it from every road.
            "record_count":  (_record_counts[_i]
                              if _i < len(_record_counts) else None),
            "name":          key.split("/")[-1],
            "path":          key,
            "size_bytes":    meta.get("size_bytes", 0),
            "last_modified": meta.get("last_modified", ""),
            "folder":        "/".join(key.split("/")[:-1]) + "/" if "/" in key else "",
            "type":          "parquet",
        })

    # SCAN-STRATEGY (2026-06-01): ordering is now caller-driven via
    # ``file_order``.  Old BF-535 default of smallest-first was *good* for
    # LIMIT-100 queries but *bad* for full feed scans (3000 files where the
    # biggest file became a tail-end straggler).  The new design moves the
    # decision to core.scan_strategy.ScanStrategist where it can be picked
    # per-workload: LIMIT queries → INTERACTIVE profile → smallest-first;
    # feed gen → BULK_SCAN profile → largest-first; admin can override per
    # profile.  When the caller doesn't supply file_order, we honour the
    # admin-controlled ``scan_strategy.default_file_order`` config key —
    # default ``manifest_order`` (no implicit sort), so old call sites that
    # weren't updated retain DuckDB's parallel-scanner-friendly behaviour
    # without imposing the smallest-first ordering by stealth.
    try:
        result = _apply_scan_order(result, file_order)
    except Exception as _sort_exc:
        logger.debug("scan-strategy ordering failed (degrading to manifest order): %s",
                     _sort_exc)

    # Phase 8 + Phase 150 — reader substitution.  Run BEFORE the
    # diagnostic-store block so the routing decision flows into
    # ``_payload`` (pruning history) and the brain ``scan_plan`` (diagnose
    # UI chip).  ``files_after_prune`` is computed BELOW from the swapped
    # list, so we capture the pre-swap source count up-front to preserve
    # that metric's semantics — pruning effectiveness, not routing outcome.
    _pre_mirror_source_file_count = len(result) if isinstance(result, list) else 0
    result = _apply_read_substitutions(
        db_manager=db_manager,
        metadata=metadata,
        bucket=bucket,
        table_prefix=table_prefix,
        snapshot_id=current_snapshot_id,
        source_files=result,
        _out_meta=_out_meta,
    )

    # 2026-06-04 — patch the diagnostic store with files_after_prune
    # AND the per-WHERE-clause breakdown (operator-level prune support
    # classification + stage-level drop counts) so admins can see which
    # predicates pruned files and which fell open.  Plus persistence
    # to the DB pruning history table for trend analysis across runs.
    _observe_road("walk", files_after=_pre_mirror_source_file_count,
                  files_before=int(_ice_files_considered or 0),
                  snapshot_id=current_snapshot_id,
                  unless=("empty_island",))
    if _out_meta is not None and _record_query_observations():
        _emit_brain_observation(_pre_mirror_source_file_count)

    # Phase 150 swap already ran above (pre-payload) so result already
    # carries the mirror file list when routing engaged.
    # Phase 156 -- memo POPULATE via module-level helper.
    # 2026-08-03: pass the pruning gate so a scan with UNJUSTIFIED drops
    # (or an empty survivors list) is never laundered into the memo.
    _phase156_memo_populate(
        sql_hash=sql_hash,
        snapshot_id=current_snapshot_id,
        bucket=bucket, table_prefix=table_prefix,
        surviving_files=result,
        db_manager=db_manager,
        join_key_columns=join_key_columns,
        force_fresh=force_fresh,
        gate=_gate,
        scan_meta=_memo_scan_meta_from_out(_out_meta),
    )
    return result


def get_iceberg_partition_values(
    s3_client,
    bucket: str,
    table_prefix: str,
    full_scan: bool = False,
) -> Dict[str, Any]:
    """Extract distinct partition values from Iceberg manifest entries.

    Args:
        full_scan: If True, always read individual manifest files (slow path)
                   to get exact partition values and complete combos.
                   If False, use the fast path from manifest-list summaries.

    Returns:
        {
            "partition_columns": [...],
            "values": {...}, "file_counts": {...}, "record_counts": {...},
            "combos": [...],
            "fast_path": True/False,
        }
    """
    logger.info("get_iceberg_partition_values: table=%s bucket=%s full_scan=%s",
                table_prefix, bucket, full_scan)
    meta_prefix = table_prefix.rstrip("/") + "/metadata/"
    meta_key = _latest_metadata_key(s3_client, bucket, meta_prefix)
    metadata = _read_s3_json_cached(s3_client, bucket, meta_key)

    # ── Get partition spec ────────────────────────────────────────────────────
    partition_spec = _extract_partition_spec(metadata)
    if not partition_spec:
        return {"partition_columns": [], "values": {}, "file_counts": {}}

    # Build partition field index → (name, type) mapping
    spec_fields = list(partition_spec.items())  # ordered: [(name, type), ...]

    # Also get the field names for the schema (for source column resolution)
    specs = metadata.get("partition-specs") or (
        [metadata["partition-spec"]] if "partition-spec" in metadata else []
    )
    default_spec_id = metadata.get("default-spec-id", 0)
    active_spec = next(
        (s for s in specs if s.get("spec-id") == default_spec_id), specs[0] if specs else {}
    )

    partition_columns = []
    field_id_to_name = {}
    schemas = metadata.get("schemas") or ([metadata["schema"]] if "schema" in metadata else [])
    for schema in schemas:
        for field in schema.get("fields", []):
            fid = field.get("id") or field.get("field-id")
            if fid is not None:
                field_id_to_name[fid] = field.get("name", "")

    for pf in active_spec.get("fields", []):
        src_id = pf.get("source-id") or pf.get("source_id")
        partition_columns.append({
            "name": pf.get("name", ""),
            "source_column": field_id_to_name.get(src_id, str(src_id)),
            "type": partition_spec.get(pf.get("name", ""), "string"),
            "transform": pf.get("transform", "identity"),
        })

    # ── Read manifests to collect partition values ────────────────────────────
    current_snapshot_id = metadata.get("current-snapshot-id", -1)
    if current_snapshot_id in (-1, None):
        return {"partition_columns": partition_columns, "values": {}, "file_counts": {}}

    snapshots = {s.get("snapshot-id"): s for s in metadata.get("snapshots", []) if s.get("snapshot-id") is not None}
    snapshot = snapshots.get(current_snapshot_id)
    if not snapshot:
        return {"partition_columns": partition_columns, "values": {}, "file_counts": {}}

    manifest_list_uri = snapshot.get("manifest-list")
    if manifest_list_uri:
        ml_key = _s3_uri_to_key(manifest_list_uri)
        try:
            manifest_list_data = _read_manifest_list_avro_cached(s3_client, bucket, ml_key)
            manifests = _read_avro(manifest_list_data)
        except Exception as exc:
            logger.error("Failed to read manifest list %s: %s", ml_key, exc)
            return {"partition_columns": partition_columns, "values": {}, "file_counts": {}}
    else:
        manifests = snapshot.get("manifests", [])

    # ── FAST PATH: extract partition values from manifest-list summary ────────
    # Each manifest-list entry has a `partitions` field with per-column
    # {lower_bound, upper_bound} as BYTES.  For identity-transform partitions,
    # lower == upper means all files in that manifest share the same partition
    # value.  This avoids reading individual manifest files entirely —
    # only 2 S3 calls (metadata.json + manifest-list.avro) instead of 10+.

    values: Dict[str, set] = {name: set() for name, _ in spec_fields}
    file_counts: Dict[str, Dict[str, int]] = {name: {} for name, _ in spec_fields}
    record_counts: Dict[str, Dict[str, int]] = {name: {} for name, _ in spec_fields}
    # Partition combos — exact tuples for cascading selection in the UI.
    # Each combo is {col1: val1, col2: val2, ...} with file/record counts.
    _combo_map: Dict[tuple, Dict] = {}  # frozen-tuple → {cols + _files + _records}

    for manifest in manifests:
        parts_summary = manifest.get("partitions")
        n_added = manifest.get("added_data_files_count") or manifest.get("added_files_count") or 0
        n_existing = manifest.get("existing_data_files_count") or manifest.get("existing_files_count") or 0
        manifest_file_count = n_added + n_existing
        # Record counts available at manifest-list level
        n_added_rows = manifest.get("added_rows_count", 0) or 0
        n_existing_rows = manifest.get("existing_rows_count", 0) or 0
        manifest_record_count = n_added_rows + n_existing_rows

        combo: Dict[str, str] = {}
        if parts_summary:
            for idx, (col_name, col_type) in enumerate(spec_fields):
                if idx >= len(parts_summary):
                    continue
                pbound = parts_summary[idx]
                lo_raw = pbound.get("lower_bound")
                hi_raw = pbound.get("upper_bound")
                lo = _decode_bound(lo_raw, col_type) if lo_raw else None
                hi = _decode_bound(hi_raw, col_type) if hi_raw else None

                if lo is not None and hi is not None and lo == hi:
                    # Exact value — all files in this manifest share this partition value
                    str_val = str(lo)
                    values[col_name].add(str_val)
                    file_counts[col_name][str_val] = file_counts[col_name].get(str_val, 0) + max(manifest_file_count, 1)
                    record_counts[col_name][str_val] = record_counts[col_name].get(str_val, 0) + manifest_record_count
                    combo[col_name] = str_val
                elif lo is not None:
                    # Range — add both bounds as values (approximate but fast)
                    # Don't add to combo for this column (unknown exact value)
                    str_lo = str(lo)
                    values[col_name].add(str_lo)
                    file_counts[col_name][str_lo] = file_counts[col_name].get(str_lo, 0) + max(manifest_file_count // 2, 1)
                    record_counts[col_name][str_lo] = record_counts[col_name].get(str_lo, 0) + manifest_record_count // 2
                    if hi is not None and hi != lo:
                        str_hi = str(hi)
                        values[col_name].add(str_hi)
                        file_counts[col_name][str_hi] = file_counts[col_name].get(str_hi, 0) + max(manifest_file_count // 2, 1)
                        record_counts[col_name][str_hi] = record_counts[col_name].get(str_hi, 0) + manifest_record_count // 2

        # Record partial or complete combo — any manifest with at least one exact
        # partition column helps narrow cascading selection in the UI.
        # Columns absent from combo are treated as wildcards on the frontend.
        if len(combo) > 0:
            key = tuple(sorted(combo.items()))
            if key in _combo_map:
                _combo_map[key]["_files"] += max(manifest_file_count, 1)
                _combo_map[key]["_records"] += manifest_record_count
            else:
                _combo_map[key] = {**combo, "_files": max(manifest_file_count, 1), "_records": manifest_record_count}

    # Fall back to reading manifest files directly if:
    #   - fast path found no values (older Iceberg format), OR
    #   - caller explicitly requested a full scan for complete combos
    has_any_values = any(len(v) > 0 for v in values.values())
    _used_fast_path = has_any_values and not full_scan
    if not has_any_values or full_scan:
        if full_scan and has_any_values:
            # Reset fast-path values/combos before building exact ones
            logger.info("Full scan requested — reading individual manifests for exact combos")
            values = {name: set() for name, _ in spec_fields}
            file_counts = {name: {} for name, _ in spec_fields}
            record_counts = {name: {} for name, _ in spec_fields}
            _combo_map = {}
        else:
            logger.info("No partition summaries in manifest-list — falling back to manifest scan")
        from concurrent.futures import ThreadPoolExecutor, as_completed
        manifest_keys = []
        for manifest in manifests:
            mp = manifest.get("manifest_path") or manifest.get("manifest-path") or (manifest if isinstance(manifest, str) else None)
            if mp:
                manifest_keys.append(_s3_uri_to_key(mp))

        def _read_manifest(mk):
            data = _read_s3_bytes(s3_client, bucket, mk)
            return _read_avro(data)

        all_entries = []
        if manifest_keys:
            with ThreadPoolExecutor(max_workers=min(len(manifest_keys), 8)) as pool:
                future_to_key = {pool.submit(_read_manifest, mk): mk for mk in manifest_keys}
                for future in as_completed(future_to_key):
                    try:
                        all_entries.extend(future.result())
                    except Exception as e:
                        logger.warning("Could not read manifest for partition values: %s", e)

        for entry in all_entries:
            if entry.get("status") == 2:  # DELETED
                continue
            data_file = entry.get("data_file") or {}
            partition = data_file.get("partition") or {}
            entry_record_count = data_file.get("record_count", 0) or 0
            combo: Dict[str, str] = {}
            for idx, (col_name, col_type) in enumerate(spec_fields):
                raw_val = partition.get(col_name)
                if raw_val is None:
                    continue
                decoded = _decode_partition_value(raw_val, col_type)
                if decoded is not None:
                    str_val = str(decoded)
                    values[col_name].add(str_val)
                    file_counts[col_name][str_val] = file_counts[col_name].get(str_val, 0) + 1
                    record_counts[col_name][str_val] = record_counts[col_name].get(str_val, 0) + entry_record_count
                    combo[col_name] = str_val
            # Record combo from individual data file entry
            # Accept partial combos (same as fast path) — missing columns are
            # treated as wildcards on the frontend for cascading selection.
            if len(combo) > 0:
                key = tuple(sorted(combo.items()))
                if key in _combo_map:
                    _combo_map[key]["_files"] += 1
                    _combo_map[key]["_records"] += entry_record_count
                else:
                    _combo_map[key] = {**combo, "_files": 1, "_records": entry_record_count}

    # Sort values
    sorted_values = {}
    for name, vals in values.items():
        sorted_values[name] = sorted(vals)

    # Build combos list for cascading partition selection
    combos = list(_combo_map.values())

    return {
        "partition_columns": partition_columns,
        "values": sorted_values,
        "file_counts": {name: dict(sorted(counts.items())) for name, counts in file_counts.items()},
        "record_counts": {name: dict(sorted(counts.items())) for name, counts in record_counts.items()},
        "combos": combos,
        "fast_path": _used_fast_path,
    }
