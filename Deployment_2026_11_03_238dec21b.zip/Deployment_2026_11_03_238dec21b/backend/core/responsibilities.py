"""WHICH component is this process, and WHAT work may it do -- ONE declaration (2026-11-02).

The owner: "each component should have their own responsibilities, not mix n
match"; "scheduler pod only watch iceberg metadata, dependency resolution n
other background tasks ... no feed gen will be here"; "one worker tier i m ok
... but feed worker should do feed work".

Before this module the same question ("does this process run feeds / daemons /
queries?") was answered by a different flag at every site: ``QS_POD_ROLE``,
``scheduler.mode``, ``feed_generation.queue_worker_enabled``,
``feed_generation.worker_pod_only``, ``executor.mode``, ``QS_JOBQUEUE_EXECUTOR``
-- and the per-feed cron fire read none of them, so a 10 GiB scheduler pod
still ran every scheduled feed in-process whatever the operator set.

Now every ENTRY POINT declares its component once, before anything starts::

    scheduler_worker.py   -> declare(SCHEDULER)
    feed_worker.py        -> declare(FEED_WORKER)
    executor_worker.py    -> declare(JOB_WORKER)   (python -m querystudio job-worker)
    main.py (serving)     -> API, derived from QS_POD_ROLE=api when nothing declared
    main.py (standalone)  -> STANDALONE, the default: one process owns everything

and every EXECUTION SITE asks :func:`owns` for the KIND of work it is about
to do.  A process that does not own a kind never does it -- there is no
setting that turns it back on -- and says so (:func:`why_not`).

The kinds of work:

``SCHEDULING``            deciding WHEN: APScheduler, SOD, dependency release,
                          the watchers (Iceberg metadata, Kafka / file / Oracle
                          arrivals, SLA), alerts, component health, the
                          query-pod scaler, retention sweeps.  Metadata only.
``FEED_RUNS``             claiming and executing ``feed_runs`` rows.
``BACKGROUND_EXECUTION``  every OTHER background execution: scheduled reports
                          and subscription deliveries, data-quality rules, ETL
                          pipelines, DataFlow runs, reconciliation, custom
                          SQL / webhook jobs, value-list fills, data mirrors
                          and bloom builds -- anything that READS or WRITES
                          DATA on a schedule.
``SERVING``               HTTP requests and the interactive queries they start.

The component table (:data:`COMPONENTS`) is the whole model; the design and
as-built record is ``docs/COMPONENT_RESPONSIBILITIES_2026_11_02.html``.
"""
from __future__ import annotations

import logging
import threading
from typing import Dict, FrozenSet, Optional

logger = logging.getLogger(__name__)

# ── kinds of work ─────────────────────────────────────────────────────────────
SCHEDULING = "scheduling"
FEED_RUNS = "feed_runs"
BACKGROUND_EXECUTION = "background_execution"
SERVING = "serving"

WORK_KINDS: FrozenSet[str] = frozenset({SCHEDULING, FEED_RUNS, BACKGROUND_EXECUTION, SERVING})

# ── components ────────────────────────────────────────────────────────────────
SCHEDULER = "scheduler"
FEED_WORKER = "feed-worker"
JOB_WORKER = "job-worker"
API = "api"
STANDALONE = "standalone"

#: component -> the kinds of work it owns.  THE table.
COMPONENTS: Dict[str, FrozenSet[str]] = {
    SCHEDULER:   frozenset({SCHEDULING}),
    FEED_WORKER: frozenset({FEED_RUNS}),
    JOB_WORKER:  frozenset({BACKGROUND_EXECUTION}),
    API:         frozenset({SERVING}),
    # a single-pod install (``python -m querystudio standalone``, or any
    # ``main.py`` process whose pod role is not ``api``): one process owns
    # everything, exactly as before this module.
    STANDALONE:  frozenset(WORK_KINDS),
}

#: What each component NEVER does, in plain words -- the reason a refusal
#: carries (``why_not``), and what the as-built record says.
NEVER_DOES: Dict[str, str] = {
    SCHEDULER:   "this is the scheduler pod: it creates runs, releases them and watches; "
                 "the feed-worker pods run feeds and the job-worker pods run every other "
                 "background job",
    FEED_WORKER: "this is a feed-worker pod: it runs feeds and nothing else",
    JOB_WORKER:  "this is a job-worker pod: it runs scheduled reports, deliveries, data "
                 "checks, pipelines and the other background jobs -- never feeds, never "
                 "the schedule itself",
    API:         "this pod serves requests: a feed run or a background job is queued for "
                 "the worker pods, never run here",
    STANDALONE:  "",
}

_lock = threading.Lock()
_declared: Optional[str] = None
_declared_by: str = ""


def declare(component: str, *, by: str = "") -> str:
    """The entry point says which component this process is.  Once per
    process; declaring a DIFFERENT component later is a programming error
    (two entry points in one process) and raises."""
    global _declared, _declared_by
    if component not in COMPONENTS:
        raise ValueError(f"unknown component {component!r}; one of {sorted(COMPONENTS)}")
    with _lock:
        if _declared is not None and _declared != component:
            raise RuntimeError(
                f"this process already declared itself {_declared!r} (by {_declared_by or '?'}); "
                f"it cannot also be {component!r}")
        _declared = component
        _declared_by = by or component
    logger.info("[responsibilities] this process is the %s: owns %s%s",
                component, ", ".join(sorted(COMPONENTS[component])),
                f" -- {NEVER_DOES[component]}" if NEVER_DOES.get(component) else "")
    return component


def _derived_from_pod_role() -> str:
    """When no entry point declared anything (``python -m main``, a test):
    a ``QS_POD_ROLE=api`` process SERVES, anything else is a STANDALONE that
    owns everything -- today's behaviour for a hybrid pod."""
    try:
        from core.pod_role import current as _pod_role
        if _pod_role().is_api():
            return API
    except Exception as exc:                              # noqa: BLE001 -- the role is a hint
        logger.debug("[responsibilities] pod role unreadable (%s): standalone", exc)
    return STANDALONE


def current() -> str:
    """This process's component: what was declared, else derived."""
    return _declared if _declared is not None else _derived_from_pod_role()


def declared() -> Optional[str]:
    """What an entry point declared, or None when nothing did."""
    return _declared


def owns(kind: str) -> bool:
    """May THIS process do work of ``kind``?"""
    if kind not in WORK_KINDS:
        raise ValueError(f"unknown kind of work {kind!r}; one of {sorted(WORK_KINDS)}")
    return kind in COMPONENTS[current()]


def why_not(kind: str) -> Optional[str]:
    """The reason this process does not do ``kind``, or None when it does."""
    if owns(kind):
        return None
    comp = current()
    return NEVER_DOES.get(comp) or f"this process is the {comp} and does not own {kind}"


def describe() -> Dict[str, object]:
    """For /health and the component-health reporter: who this process is
    and what it owns."""
    comp = current()
    return {"component": comp, "declared": _declared is not None,
            "owns": sorted(COMPONENTS[comp]),
            "never": {k: NEVER_DOES[comp] for k in sorted(WORK_KINDS - COMPONENTS[comp])}}


def _reset_for_tests() -> None:
    global _declared, _declared_by
    with _lock:
        _declared = None
        _declared_by = ""


__all__ = ["SCHEDULING", "FEED_RUNS", "BACKGROUND_EXECUTION", "SERVING", "WORK_KINDS",
           "SCHEDULER", "FEED_WORKER", "JOB_WORKER", "API", "STANDALONE",
           "COMPONENTS", "NEVER_DOES", "declare", "declared", "current", "owns",
           "why_not", "describe"]
