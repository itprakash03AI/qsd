"""BF-384 — Option G: Multi-pod query dispatcher (coordinator side).

Wraps the same ``SplitPlan`` interface that ``multi_worker_executor`` uses,
but instead of running chunks in local threads, ships each chunk to a
DIFFERENT pod over HTTP and reads Arrow IPC back.

Pod discovery options (config-driven):
  * ``worker_urls``     — explicit list of base URLs from config
  * ``k8s_service``     — DNS-round-robin via a headless K8s Service
  * ``worker_registry`` — Phase 45 Redis registry (preferred for elastic scaling)

Falls back to in-pod execution (Option F) when:
  * ``multi_pod.enabled = false``
  * No worker pods discoverable
  * Cluster auth (HMAC secret) not configured

Public API:
  ``dispatch_chunks_to_pods(plan, setup_sql_builder, ...) -> MultiWorkerOutcome``

Returns the same ``MultiWorkerOutcome`` dataclass as the in-pod executor
so all downstream code (admin UI, history, merger, parquet write) is
unchanged.
"""
from __future__ import annotations

import base64
import json
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Optional

import pyarrow as pa
import pyarrow.ipc as pa_ipc
import requests  # module-level so tests can patch it

from core.multi_worker_executor import (
    MultiWorkerOutcome,
    WorkerResult,
    _record_outcome,
)
from core.query_splitter import FileChunk, SplitPlan
from core.query_worker_node import sign_payload
from core.result_merger import merge_partial_results

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Pod discovery
# ─────────────────────────────────────────────────────────────────────────────


MULTI_POD_DISABLED = "disabled"   # multi_pod.enabled is false
MULTI_POD_INERT    = "inert"      # enabled, but no worker can be discovered
MULTI_POD_ACTIVE   = "active"     # enabled and at least one worker discovered

MULTI_POD_REMEDY = (
    "Set multi_pod.k8s_service to the worker pods' headless Service DNS name "
    "(e.g. qs-worker-headless.<ns>.svc.cluster.local) or multi_pod.worker_urls "
    "to a static list of worker base URLs, and QS_WORKER_SECRET (or "
    "multi_pod.shared_secret) on every pod; or set multi_pod.enabled=false "
    "to stop advertising a fan-out that cannot happen."
)


def _discover(mp: Dict[str, Any]) -> tuple:
    """Run the three discovery strategies in order.

    Returns ``(urls, strategy, attempts)`` where ``strategy`` names the one
    that produced ``urls`` (None when none did) and ``attempts`` says, per
    strategy, WHY it yielded nothing -- the state a bare ``[]`` hid.
    """
    attempts: List[str] = []

    # 1. Static URL list
    urls = list(mp.get("worker_urls") or [])
    urls = [str(u).rstrip("/") for u in urls if u]
    if urls:
        return urls, "worker_urls", attempts
    attempts.append("multi_pod.worker_urls is empty")

    # 2. Kubernetes headless service
    svc = str(mp.get("k8s_service", "") or "").strip()
    if svc:
        try:
            import socket
            # Headless service returns ALL pod IPs as A records
            results = socket.gethostbyname_ex(svc)
            host_list = results[2] if results and len(results) >= 3 else []
            port = int(mp.get("k8s_service_port", 8000) or 8000)
            if host_list:
                return [f"http://{h}:{port}" for h in host_list], "k8s_service", attempts
            attempts.append(f"multi_pod.k8s_service={svc!r} resolved to no addresses")
        except Exception as dns_err:
            logger.warning("[multi-pod] DNS lookup for %s failed: %s", svc, dns_err)
            attempts.append(f"multi_pod.k8s_service={svc!r} DNS lookup failed: {dns_err}")
    else:
        attempts.append("multi_pod.k8s_service is unset")

    # 3. Worker registry -- only pods advertising worker role
    try:
        from core.worker_registry import get_worker_registry
        registry = get_worker_registry()
        workers = registry.list_workers(worker_type="query_worker")
        port = int(mp.get("worker_port", 8000) or 8000)
        out: List[str] = []
        for w in workers:
            if not getattr(w, "hostname", ""):
                continue
            if getattr(w, "status", "") != "active":
                continue
            out.append(f"http://{w.hostname}:{port}")
        if out:
            return out, "worker_registry", attempts
        attempts.append(
            f"the worker registry lists no active query_worker "
            f"({len(list(workers or []))} registered)")
    except Exception as reg_err:
        logger.debug("[multi-pod] registry lookup skipped: %s", reg_err)
        attempts.append(f"the worker registry is unavailable ({reg_err})")

    return [], None, attempts


def discover_worker_pods() -> List[str]:
    """Return a list of base URLs (e.g. ``http://qs-worker-1:8000``) for
    worker pods we can dispatch to.

    Strategy order (first non-empty wins):
      1. Static ``multi_pod.worker_urls`` config (good for testing)
      2. Kubernetes DNS via ``multi_pod.k8s_service`` (resolves to all pods)
      3. Phase 45 worker_registry (Redis-backed, dynamic membership)

    An empty list is the DISPATCH answer only; ``multi_pod_state()`` says
    why it is empty.
    """
    try:
        from core.config import get_section as _cfg_section
        mp = _cfg_section("multi_pod") or {}
    except Exception:
        mp = {}
    urls, _strategy, _attempts = _discover(mp)
    return urls


def _secret_configured(mp: Dict[str, Any]) -> bool:
    import os
    return bool(os.environ.get("QS_WORKER_SECRET") or mp.get("shared_secret"))


def multi_pod_state() -> Dict[str, Any]:
    """The HONEST multi-pod state: configured-and-working vs configured-and-inert.

    2026-09-15: ``multi_pod.enabled`` ships ``True`` (2026-06-24, "whatever
    required should be on") while ``worker_urls`` is empty, ``k8s_service``
    unset and the registry never initialised on most deployments -- so
    ``discover_worker_pods()`` returned ``[]`` and the engine router fell
    back to single-pod with nothing but a DEBUG line.  Built-but-not-wired
    presenting as enabled.  This does not add a distributed feature; it
    makes the state legible:

      state      configured_enabled  pods   meaning
      disabled   False               --     the operator turned it off
      inert      True                []     enabled, NO worker discoverable
                                            -> ``reason`` says why per
                                            strategy, ``remedy`` what to set
      active     True                [..]   enabled and dispatchable

    ``secret_configured`` is reported separately: a worker REJECTS an
    unsigned chunk (query_worker_node), so pods without a secret are
    discoverable and still undispatchable -- ``state`` is ``active``
    only when both hold.
    """
    try:
        from core.config import get_section as _cfg_section
        mp = _cfg_section("multi_pod") or {}
    except Exception:
        mp = {}
    # 2026-11-02: the pool is RETIRED; the declared default is False (core/config.py
    # multi_pod.enabled) and this fallback must equal it (the declared-config guard).
    enabled = bool(mp.get("enabled", False))
    secret_ok = _secret_configured(mp)
    if not enabled:
        return {
            "state": MULTI_POD_DISABLED, "configured_enabled": False,
            "pods": [], "strategy": None, "secret_configured": secret_ok,
            "reason": "multi_pod.enabled is false", "remedy": "",
        }
    urls, strategy, attempts = _discover(mp)
    if urls and secret_ok:
        return {
            "state": MULTI_POD_ACTIVE, "configured_enabled": True,
            "pods": urls, "strategy": strategy, "secret_configured": True,
            "reason": f"{len(urls)} worker pod(s) discovered via {strategy}",
            "remedy": "",
        }
    if urls and not secret_ok:
        reason = (f"{len(urls)} worker pod(s) discovered via {strategy} but no "
                  f"HMAC secret is configured -- every worker would reject the "
                  f"dispatch (QS_WORKER_SECRET / multi_pod.shared_secret unset)")
    else:
        reason = ("multi_pod.enabled is true but no worker pod can be "
                  "discovered: " + "; ".join(attempts))
    return {
        "state": MULTI_POD_INERT, "configured_enabled": True,
        "pods": urls, "strategy": strategy, "secret_configured": secret_ok,
        "reason": reason, "remedy": MULTI_POD_REMEDY,
    }


def fleet_safety_verdict() -> Dict[str, Any]:
    """Is this BUILD safe to run on more than one pod?

    2026-09-16 — ``core/fleet_safety.py`` was written after a 2026-08-02
    audit found three defects that are correct only because there has ever
    been ONE pod (a revoked session staying valid on every pod that cached
    it; a cancel routed to the wrong pod marking a still-running query
    "cancelled"; every pod BOOT marking every in-flight query failed).  It
    declares eight preconditions and computes which are unmet.

    NOTHING IN THE PRODUCT CALLED IT.  Not one reference outside two
    comments -- so the module that exists to answer "is multi-pod safe
    here?" was never asked, while ``k8s/querystudioapi-helm/api/values.yaml``
    declares ``replicas: 3`` and ``hpa.enabled: true``.  One ``helm upgrade``
    with chart defaults scales past the assumption and nothing says a word.

    Reported beside the multi-pod state rather than as a separate surface,
    because "multi-pod is ACTIVE" and "this build is safe on multiple pods"
    are two halves of one answer and an operator reading the first without
    the second is the exact failure this module was written about.

    Never raises: a safety check that breaks startup is a safety check
    someone deletes.
    """
    try:
        from core.fleet_safety import is_fleet_safe, unmet_preconditions
        # The module's OWN predicate decides the boolean.  Recomputing it here
        # as ``not unmet_preconditions()`` would be the same decision spelled
        # twice, and the two spellings would be free to drift the moment
        # fleet_safety grows a precondition that is unmet but tolerated.
        safe = is_fleet_safe()
        unmet = unmet_preconditions()
    except Exception as exc:                             # pragma: no cover
        return {"safe": None, "unmet": [],
                "reason": f"fleet-safety check unavailable: {exc}"[:200]}
    return {
        "safe": safe,
        "unmet": [{"key": p.key, "summary": p.summary, "why": p.why,
                   "gate": p.gate} for p in unmet],
        "reason": ("every multi-pod precondition is provably satisfied"
                   if not unmet else
                   f"{len(unmet)} multi-pod precondition(s) NOT provably "
                   f"satisfied: " + ", ".join(p.key for p in unmet)),
    }


_state_logged_once = False


def log_multi_pod_state_once() -> Dict[str, Any]:
    """Log the multi-pod state ONCE per process (startup): WARNING when the
    feature is enabled and inert (with the reason and the remedy), INFO when
    active, DEBUG when disabled.  Returns the state it logged.
    """
    global _state_logged_once
    state = multi_pod_state()
    # Fleet safety travels WITH the state, so no caller can report
    # "multi_pod active" without also carrying whether the build is safe on
    # more than one pod.
    state["fleet_safety"] = fleet_safety_verdict()
    if _state_logged_once:
        return state
    _state_logged_once = True
    _fs = state["fleet_safety"]
    if _fs.get("safe") is False:
        # WARNING even when multi_pod is disabled: the Helm chart defaults to
        # replicas: 3, so "not enabled here" is one `helm upgrade` away from
        # being wrong, and this is the only place that says so.
        logger.warning(
            "[fleet-safety] this build is NOT provably safe on more than one "
            "pod — %s. Each unmet precondition: %s",
            _fs.get("reason"),
            "; ".join(f"{u['key']} ({u['why']})" for u in _fs.get("unmet", [])))
    if state["state"] == MULTI_POD_INERT:
        logger.warning(
            "[multi-pod] ENABLED BUT INERT -- every query will run single-pod. "
            "%s. %s", state["reason"], state["remedy"])
    elif state["state"] == MULTI_POD_ACTIVE:
        logger.info("[multi-pod] active: %s", state["reason"])
    else:
        logger.debug("[multi-pod] %s", state["reason"])
    return state


# ─────────────────────────────────────────────────────────────────────────────
# Single-chunk dispatch over HTTP
# ─────────────────────────────────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────────
# Shared helpers — used by BOTH parquet chunk dispatch (DuckDB workers) and
# SQL-connector shard dispatch (Snowflake/Trino/Starburst/etc workers).
# Keeping HMAC + HTTP + Arrow IPC + meta-header decoding in one place so the
# two callers stay in sync (auth changes, header changes, etc. need to land
# in only one function).
# ─────────────────────────────────────────────────────────────────────────────


def _post_worker_payload(
    pod_url: str,
    payload_dict: Dict[str, Any],
    *,
    timeout_s: int,
    correlation_id: str,
    chunk_index: int,
    files_for_result: List[Any],
    cancel_event: Optional[threading.Event] = None,
) -> WorkerResult:
    """HTTP POST ``payload_dict`` to a worker's ``/api/worker/run-chunk`` and
    decode the Arrow IPC reply into a ``WorkerResult``.

    Common to BOTH dispatch flavours.  ``payload_dict`` is the body that gets
    JSON-serialized + HMAC-signed; the function adds nothing to it.

    ``files_for_result`` is whatever the caller wants stamped on the returned
    WorkerResult for downstream history / merging — the file-list for
    parquet chunks, ``[]`` for SQL-connector shards.
    """
    t0 = time.monotonic()
    if cancel_event is not None and cancel_event.is_set():
        return WorkerResult(
            chunk_index=chunk_index,
            files=files_for_result,
            error="cancelled before dispatch",
            elapsed_s=0.0,
        )

    payload = json.dumps(payload_dict).encode("utf-8")
    sig = sign_payload(payload)
    headers = {
        "Content-Type":            "application/json",
        "X-QS-Worker-Signature":   sig,
        "X-QS-Worker-Correlation": correlation_id or "",
    }
    try:
        resp = requests.post(
            f"{pod_url.rstrip('/')}/api/worker/run-chunk",
            data=payload,
            headers=headers,
            timeout=timeout_s,
            stream=False,
        )
    except Exception as exc:
        return WorkerResult(
            chunk_index=chunk_index,
            files=files_for_result,
            error=f"transport: {type(exc).__name__}: {exc}"[:500],
            elapsed_s=time.monotonic() - t0,
        )

    elapsed = time.monotonic() - t0
    meta_header = resp.headers.get("X-QS-Worker-Meta", "")
    meta: Dict[str, Any] = {}
    if meta_header:
        try:
            meta = json.loads(base64.urlsafe_b64decode(meta_header).decode("utf-8"))
        except Exception as meta_err:
            logger.debug("[multi-pod] meta header parse failed: %s", meta_err)

    if resp.status_code != 200:
        err = meta.get("error") or f"HTTP {resp.status_code}: {resp.text[:300]}"
        return WorkerResult(
            chunk_index=chunk_index,
            files=files_for_result,
            error=err,
            elapsed_s=elapsed,
        )

    try:
        reader = pa_ipc.open_stream(resp.content)
        arrow = reader.read_all()
        return WorkerResult(
            chunk_index=chunk_index,
            files=files_for_result,
            table=arrow,
            row_count=arrow.num_rows,
            elapsed_s=elapsed,
        )
    except Exception as ipc_err:
        return WorkerResult(
            chunk_index=chunk_index,
            files=files_for_result,
            error=f"arrow IPC decode: {ipc_err}"[:500],
            elapsed_s=elapsed,
        )


def _record_router_decision(engine: str, reason: str, rule: str,
                            execution_id: str) -> None:
    """Stamp an Engine Router decision row.  Failures are swallowed —
    the router is a diagnostic feed, not a critical path."""
    try:
        from core.engine_router import EngineDecision, record_decision
        record_decision(
            EngineDecision(engine=engine, reason=reason, rule=rule),
            execution_id=execution_id,
        )
    except Exception as exc:
        logger.debug("[engine-router] %s record failed: %s", rule, exc)


def _merge_or_fallback(
    plan_like,
    partials: List[Any],
    final_sql: str,
    results: List[WorkerResult],
    *,
    pods_count: int,
    t_start: float,
    flavour: str,             # 'parquet' or 'sql' — for log only
) -> MultiWorkerOutcome:
    """Merge a list of partial Arrow tables using ``plan_like.merge_strategy``.

    On merge exception:
      * ``union`` retries (concat is idempotent)
      * everything else (sum_count_avg, group_by_rollup) signals fallback
        via ``MultiWorkerOutcome(fell_back=True)``.

    Common to the parquet chunk and SQL shard paths so the failure semantics
    are identical.
    """
    n_shards = len(results)
    try:
        merged = merge_partial_results(
            partials,
            plan_like.merge_strategy,
            plan_like.merge_metadata,
            final_sql,
        ) if partials else pa.table({})
    except Exception as merge_exc:
        if plan_like.merge_strategy == "union":
            logger.warning(
                "[multi-pod/%s] union merge raised (%s) — retrying",
                flavour, merge_exc,
            )
            merged = merge_partial_results(
                partials, "union", {}, final_sql,
            ) if partials else pa.table({})
        else:
            logger.error(
                "[multi-pod/%s] %s merge failed (%s) — signalling fallback",
                flavour, plan_like.merge_strategy, merge_exc,
            )
            return MultiWorkerOutcome(
                table=pa.table({}),
                worker_count=pods_count,
                succeeded=0,
                failed=n_shards,
                total_elapsed_s=time.monotonic() - t_start,
                fell_back=True,
                fallback_reason=f"merge ({plan_like.merge_strategy}) raised: {merge_exc}"[:300],
                per_worker=results,
                merge_strategy=plan_like.merge_strategy,
            )

    succeeded = sum(1 for r in results if r.ok)
    failed = sum(1 for r in results if not r.ok)
    return MultiWorkerOutcome(
        table=merged,
        worker_count=pods_count,
        succeeded=succeeded,
        failed=failed,
        total_elapsed_s=time.monotonic() - t_start,
        fell_back=False,
        per_worker=results,
        merge_strategy=plan_like.merge_strategy,
    )


def _dispatch_one_chunk(
    pod_url: str,
    chunk: FileChunk,
    partial_sql: str,
    setup_sql: str,
    duckdb_settings: Dict[str, Any],
    timeout_s: int,
    correlation_id: str,
    cancel_event: Optional[threading.Event] = None,
) -> WorkerResult:
    """HTTP POST a parquet chunk to one pod (DuckDB worker path)."""
    return _post_worker_payload(
        pod_url,
        {
            "chunk_index":     chunk.chunk_index,
            "partial_sql":     partial_sql,
            "setup_sql":       setup_sql,
            "duckdb_settings": duckdb_settings,
            "timeout_seconds": timeout_s,
            "correlation_id":  correlation_id,
        },
        timeout_s=timeout_s,
        correlation_id=correlation_id,
        chunk_index=chunk.chunk_index,
        files_for_result=chunk.files,
        cancel_event=cancel_event,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Public dispatcher
# ─────────────────────────────────────────────────────────────────────────────


def dispatch_chunks_to_pods(
    split_plan: SplitPlan,
    setup_sql_builder: Callable[[FileChunk], str],
    *,
    final_sql: str = "",
    duckdb_settings: Optional[Dict[str, Any]] = None,
    cancel_event: Optional[threading.Event] = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    correlation_id: str = "",
    per_worker_timeout_s: int = 1800,
    fallback_on_error: bool = True,
    execution_id: str = "",
    max_retries_per_chunk: int = 1,
) -> Optional[MultiWorkerOutcome]:
    """Dispatch every chunk to a different pod.  Returns:
      * ``MultiWorkerOutcome`` with merged Arrow table on success
      * ``MultiWorkerOutcome(fell_back=True)`` when partial failure + ``fallback_on_error``
      * ``None`` when multi-pod isn't usable (no pods discovered, etc.) —
        caller falls back to in-pod F

    Deep-dive round 1 fixes:
      * execution_id tagged on all engine-router decisions (no cross-query pollution)
      * retry transient transport failures on a DIFFERENT pod (one flaky pod
        no longer kills the whole query)
      * record dispatch start in Engine Router so admin UI shows mid-flight
        activity, not only post-completion
    """
    if not split_plan.splittable or not split_plan.chunks:
        return None

    pods = discover_worker_pods()
    if not pods:
        logger.info("[multi-pod] no worker pods discoverable — falling back to in-pod F")
        _record_router_decision(
            engine="single",
            reason="multi-pod: no worker pods discoverable",
            rule="multi_pod_skip",
            execution_id=execution_id,
        )
        return None

    # Record dispatch START so Engine Router shows mid-flight activity.
    _record_router_decision(
        engine="multi_pod",
        reason=f"multi-pod dispatch: {len(split_plan.chunks)} chunks across {len(pods)} pods",
        rule="multi_pod_dispatch_started",
        execution_id=execution_id,
    )

    n_chunks = len(split_plan.chunks)
    # Round-robin pods → chunks; if more chunks than pods, pods get multiple.
    chunk_pod_map: List[tuple] = [
        (split_plan.chunks[i], pods[i % len(pods)])
        for i in range(n_chunks)
    ]

    logger.info(
        "[multi-pod] dispatching %d chunks across %d pods (round-robin), "
        "merge=%s",
        n_chunks, len(pods), split_plan.merge_strategy,
    )

    t_start = time.monotonic()
    results: List[WorkerResult] = []
    done_count = 0

    def _emit(msg: str):
        if progress_cb:
            try:
                progress_cb(done_count, n_chunks, msg)
            except Exception as cb_err:
                logger.debug("[multi-pod] progress_cb raised: %s", cb_err)

    def _dispatch_chunk_with_retry(chunk, primary_pod_url):
        """Dispatch one chunk with retry on a different pod for transient
        transport failures (connection refused, timeout, 5xx).  Application
        errors (HTTP 4xx, SQL errors) are NOT retried — those are
        deterministic and would just waste compute.
        """
        attempt_pods = [primary_pod_url]
        # Pick fallback pods from the available set (excluding primary)
        for p in pods:
            if p != primary_pod_url and len(attempt_pods) < (max_retries_per_chunk + 1):
                attempt_pods.append(p)

        last_wr = None
        for attempt_idx, pod in enumerate(attempt_pods):
            setup = setup_sql_builder(chunk)
            wr = _dispatch_one_chunk(
                pod, chunk,
                split_plan.partial_sql, setup,
                duckdb_settings or {},
                per_worker_timeout_s,
                correlation_id,
                cancel_event,
            )
            if wr.ok:
                return wr
            last_wr = wr
            err_lower = (wr.error or "").lower()
            is_transient = any(k in err_lower for k in (
                "transport:", "connection", "timeout", "timed out",
                "503", "504", "502", "reset by peer", "brokenpipe",
            ))
            if not is_transient or attempt_idx >= len(attempt_pods) - 1:
                return wr
            logger.info(
                "[multi-pod] chunk %d transient failure on %s (attempt %d/%d): %s — retrying on different pod",
                chunk.chunk_index, pod, attempt_idx + 1, len(attempt_pods), wr.error[:200] if wr.error else "?",
            )
        return last_wr

    # Parallel HTTP dispatch — N concurrent requests
    with ThreadPoolExecutor(
        max_workers=min(n_chunks, len(pods) * 2),
        thread_name_prefix="mp-dispatch",
    ) as pool:
        futures = {}
        for chunk, pod_url in chunk_pod_map:
            fut = pool.submit(_dispatch_chunk_with_retry, chunk, pod_url)
            futures[fut] = (chunk, pod_url)

        for fut in as_completed(futures):
            chunk, pod_url = futures[fut]
            try:
                wr = fut.result()
            except Exception as exc:
                wr = WorkerResult(
                    chunk_index=chunk.chunk_index,
                    files=chunk.files,
                    error=f"future raised: {exc}"[:500],
                    elapsed_s=0.0,
                )
            results.append(wr)
            done_count += 1
            _emit(
                f"pod {pod_url.rsplit('/', 1)[-1]} chunk={wr.chunk_index} "
                f"({'ok' if wr.ok else 'FAIL'}; rows={wr.row_count:,}; "
                f"{wr.elapsed_s:.1f}s)"
            )

            if cancel_event is not None and cancel_event.is_set():
                logger.warning("[multi-pod] cancel set — cancelling pending futures")
                for f in futures:
                    if not f.done():
                        f.cancel()
                break

    results.sort(key=lambda r: r.chunk_index)
    succeeded = sum(1 for r in results if r.ok)
    failed = sum(1 for r in results if not r.ok)
    total_elapsed = time.monotonic() - t_start

    if failed > 0 and fallback_on_error:
        logger.warning(
            "[multi-pod] %d/%d chunks failed — caller will fall back to in-pod F. "
            "First error: %s",
            failed, n_chunks,
            next((r.error for r in results if not r.ok), "unknown"),
        )
        outcome = MultiWorkerOutcome(
            table=pa.table({}),
            worker_count=len(pods),
            succeeded=succeeded,
            failed=failed,
            total_elapsed_s=total_elapsed,
            fell_back=True,
            fallback_reason=(
                f"{failed}/{n_chunks} pod chunks failed: "
                + (next((r.error for r in results if not r.ok), "unknown"))[:200]
            ),
            per_worker=results,
            merge_strategy=split_plan.merge_strategy,
        )
        _record_outcome(outcome, raised=False)
        return outcome

    if failed > 0:
        outcome = MultiWorkerOutcome(
            table=pa.table({}),
            worker_count=len(pods),
            succeeded=succeeded,
            failed=failed,
            total_elapsed_s=total_elapsed,
            per_worker=results,
            merge_strategy=split_plan.merge_strategy,
        )
        _record_outcome(outcome, raised=True)
        raise RuntimeError(
            f"multi-pod execution failed: {failed}/{n_chunks} chunks errored"
        )

    # Merge Arrow tables (shared helper — handles UNION retry + aggregate
    # fallback identically to the SQL-connector path)
    partials = [r.table for r in results if r.ok and r.table is not None]
    final = _merge_or_fallback(
        split_plan, partials, final_sql, results,
        pods_count=len(pods),
        t_start=t_start,
        flavour="parquet",
    )

    if final.fell_back:
        _record_outcome(final, raised=False)
        return final

    logger.info(
        "[multi-pod] complete: %d/%d chunks ok across %d pods, %d rows, %.1fs total",
        succeeded, n_chunks, len(pods), final.table.num_rows, final.total_elapsed_s,
    )

    # Record success in Engine Router so admin UI shows the final outcome.
    _record_router_decision(
        engine="multi_pod",
        reason=f"multi-pod JOIN complete: {final.table.num_rows} rows, "
                f"{succeeded}/{n_chunks} chunks ok across {len(pods)} pods, "
                f"{final.total_elapsed_s:.1f}s",
        rule="multi_pod_dispatch",
        execution_id=execution_id,
    )

    _record_outcome(final, raised=False)
    return final


# ─────────────────────────────────────────────────────────────────────────────
# BF-393 — SQL-connector dispatcher
# ─────────────────────────────────────────────────────────────────────────────


def _dispatch_one_sql_shard(
    pod_url: str,
    shard_index: int,
    partial_sql: str,
    connector_type: str,
    connection_id: int,
    timeout_s: int,
    correlation_id: str,
    cancel_event: Optional[threading.Event] = None,
) -> WorkerResult:
    """HTTP POST a SQL-connector shard to one pod (Snowflake/Trino/etc.).

    Thin wrapper over ``_post_worker_payload`` — supplies ``connector_type``
    + ``connection_id`` so the worker routes through ``get_connector()``
    instead of DuckDB.  Files list is empty because connector shards have
    no per-chunk parquet file partition.
    """
    return _post_worker_payload(
        pod_url,
        {
            "chunk_index":     shard_index,
            "partial_sql":     partial_sql,
            "setup_sql":       "",        # connectors don't need DuckDB setup SQL
            "duckdb_settings": {},
            "timeout_seconds": timeout_s,
            "correlation_id":  correlation_id,
            "connector_type":  connector_type,
            "connection_id":   int(connection_id),
        },
        timeout_s=timeout_s,
        correlation_id=correlation_id,
        chunk_index=shard_index,
        files_for_result=[],
        cancel_event=cancel_event,
    )


def dispatch_sql_connector_query(
    sql: str,
    connector_type: str,
    connection_id: int,
    *,
    shard_count: int,
    shard_column: str,
    shard_strategy: str = "bucket",
    shard_bounds: Optional[List[tuple]] = None,
    cancel_event: Optional[threading.Event] = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    correlation_id: str = "",
    per_shard_timeout_s: int = 1800,
    fallback_on_error: bool = True,
    execution_id: str = "",
) -> Optional[MultiWorkerOutcome]:
    """Multi-pod dispatch for a SQL-connector query (Snowflake / Trino /
    Starburst / Databricks / Oracle / Athena).

    Splits ``sql`` into ``shard_count`` predicate-restricted shards using
    ``core.sql_connector_splitter.decide_sql_connector_split``, then ships
    each shard to a different worker pod over HTTP.  Workers look up the
    connection by ``connection_id`` and execute via ``get_connector()``.

    Returns ``MultiWorkerOutcome`` on success / fallback, ``None`` when the
    query is not shardable or no worker pods are available.
    """
    # 1. Decide shards
    from core.sql_connector_splitter import decide_sql_connector_split
    plan = decide_sql_connector_split(
        sql,
        shard_count=shard_count,
        shard_strategy=shard_strategy,
        shard_column=shard_column,
        connector_type=connector_type,
        shard_bounds=shard_bounds,
    )
    if not plan.splittable:
        logger.info(
            "[multi-pod/sql] not splittable (%s) — falling back to single-shard",
            plan.skip_reason,
        )
        return None

    # 2. Discover pods (re-uses the same path as parquet dispatch)
    pods = discover_worker_pods()
    if not pods:
        logger.info("[multi-pod/sql] no worker pods discoverable — falling back")
        return None

    # 3. Record dispatch start
    _record_router_decision(
        engine="multi_pod",
        reason=(
            f"multi-pod SQL connector dispatch: {connector_type} "
            f"{len(plan.shards)} shards across {len(pods)} pods "
            f"(strategy={plan.shard_strategy})"
        ),
        rule="multi_pod_sql_connector_started",
        execution_id=execution_id,
    )

    n_shards = len(plan.shards)
    shard_pod_map = [(s, pods[i % len(pods)]) for i, s in enumerate(plan.shards)]
    t_start = time.monotonic()
    results: List[WorkerResult] = []
    done_count = 0

    def _emit(msg: str):
        if progress_cb:
            try:
                progress_cb(done_count, n_shards, msg)
            except Exception as cb_err:
                logger.debug("[multi-pod/sql] progress_cb raised: %s", cb_err)

    with ThreadPoolExecutor(
        max_workers=min(n_shards, len(pods) * 2),
        thread_name_prefix="mp-sql-dispatch",
    ) as pool:
        futures = {}
        for shard, pod_url in shard_pod_map:
            fut = pool.submit(
                _dispatch_one_sql_shard,
                pod_url,
                shard.shard_index,
                shard.partial_sql,
                connector_type,
                int(connection_id),
                per_shard_timeout_s,
                correlation_id,
                cancel_event,
            )
            futures[fut] = (shard, pod_url)
        for fut in as_completed(futures):
            shard, pod_url = futures[fut]
            try:
                wr = fut.result()
            except Exception as exc:
                wr = WorkerResult(
                    chunk_index=shard.shard_index,
                    files=[],
                    error=f"future raised: {exc}"[:500],
                    elapsed_s=0.0,
                )
            results.append(wr)
            done_count += 1
            _emit(
                f"pod {pod_url.rsplit('/', 1)[-1]} shard={wr.chunk_index} "
                f"({'ok' if wr.ok else 'FAIL'}; rows={wr.row_count:,}; "
                f"{wr.elapsed_s:.1f}s)"
            )
            if cancel_event is not None and cancel_event.is_set():
                logger.warning("[multi-pod/sql] cancel set — cancelling pending futures")
                for f in futures:
                    if not f.done():
                        f.cancel()
                break

    results.sort(key=lambda r: r.chunk_index)
    succeeded = sum(1 for r in results if r.ok)
    failed = sum(1 for r in results if not r.ok)

    if failed > 0 and fallback_on_error:
        logger.warning(
            "[multi-pod/sql] %d/%d shards failed — caller falls back to single. "
            "First error: %s",
            failed, n_shards,
            next((r.error for r in results if not r.ok), "unknown"),
        )
        outcome = MultiWorkerOutcome(
            table=pa.table({}),
            worker_count=len(pods),
            succeeded=succeeded,
            failed=failed,
            total_elapsed_s=time.monotonic() - t_start,
            fell_back=True,
            fallback_reason=(
                f"{failed}/{n_shards} sql shards failed: "
                + (next((r.error for r in results if not r.ok), "unknown"))[:200]
            ),
            per_worker=results,
            merge_strategy=plan.merge_strategy,
        )
        _record_outcome(outcome, raised=False)
        return outcome

    if failed > 0:
        outcome = MultiWorkerOutcome(
            table=pa.table({}),
            worker_count=len(pods),
            succeeded=succeeded,
            failed=failed,
            total_elapsed_s=time.monotonic() - t_start,
            per_worker=results,
            merge_strategy=plan.merge_strategy,
        )
        _record_outcome(outcome, raised=True)
        raise RuntimeError(
            f"multi-pod sql connector execution failed: {failed}/{n_shards} shards errored"
        )

    partials = [r.table for r in results if r.ok and r.table is not None]
    final = _merge_or_fallback(
        plan, partials, sql, results,
        pods_count=len(pods),
        t_start=t_start,
        flavour="sql",
    )

    if final.fell_back:
        _record_outcome(final, raised=False)
        return final

    logger.info(
        "[multi-pod/sql] complete: %d/%d shards ok across %d pods, %d rows, %.1fs total",
        succeeded, n_shards, len(pods), final.table.num_rows, final.total_elapsed_s,
    )

    _record_router_decision(
        engine="multi_pod",
        reason=(
            f"multi-pod SQL connector complete: {connector_type} {final.table.num_rows} rows, "
            f"{succeeded}/{n_shards} shards ok across {len(pods)} pods, "
            f"{final.total_elapsed_s:.1f}s"
        ),
        rule="multi_pod_sql_connector_complete",
        execution_id=execution_id,
    )

    _record_outcome(final, raised=False)
    return final
