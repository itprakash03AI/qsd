"""``dependency:query_pods`` -- the query-pod sizes and who scales them.

Read from ``query_pod_scaler_state``, the verdict the scaler writes for each
size every tick (core/query_pods/scaler.py), so any pod's watcher reads the
same answer.  The worst size decides the state; the reason names every size
that is not healthy, in the scaler's own words ("KEDA is not adding query
pods for size M: 6 runs waiting 3 min. Switch query_pods.scaler to builtin.").
A transition alerts like every other component (component_down /
component_degraded, Netcool through the kind's route).
"""
from __future__ import annotations

from datetime import datetime, timezone

from core.component_health.contract import HealthCheck, Observation, ProbeContext
from core.component_health.registry import REGISTRY
from core.component_health.vocabulary import (
    CONTROL_PROBE_NOW, DISPOSITION_DISABLED, DOWN, HEALTHY, KIND_DEPENDENCY,
    OWNER_FLEET_WATCHER, SCOPE_FLEET, UNKNOWN, WORST_FIRST,
)

#: verdicts older than this many scaler ticks are not an answer
STALE_TICKS = 3


def probe_query_pods(ctx: ProbeContext) -> Observation:
    from core.query_pods.classes import SettingsError, load_settings
    from core.query_pods.scaler import read_state
    try:
        settings = load_settings()
    except SettingsError as exc:
        return Observation(DOWN, f"query_pods cannot be used as written: {exc}", evidence="config")
    if not settings.classes:
        return Observation(HEALTHY, "no query pod sizes are configured (query_pods.classes is empty)",
                           evidence="config", disposition=DISPOSITION_DISABLED)
    rows = {r["pod_class"]: r for r in read_state(ctx.db)}
    now = datetime.now(timezone.utc)
    stale_after = STALE_TICKS * settings.tick_seconds
    states, words, metrics = [], [], {"scaler": settings.scaler}
    for cls in settings.classes:
        r = rows.get(cls.name)
        if r is None:
            states.append(UNKNOWN)
            words.append(f"Size {cls.label}: the scaler has not reported on it yet.")
            continue
        at = datetime.fromisoformat(r["at"]) if r.get("at") else None
        if at is not None and at.tzinfo is None:
            at = at.replace(tzinfo=timezone.utc)
        age = None if at is None else (now - at).total_seconds()
        if age is None or age > stale_after:
            states.append(UNKNOWN)
            words.append(f"Size {cls.label}: the scaler's last word is {int(age or 0)} s old "
                         f"(it ticks every {settings.tick_seconds} s). Is the scheduler pod running?")
            continue
        states.append(r["state"])
        metrics[f"{cls.name}_pods"] = r.get("replicas")
        metrics[f"{cls.name}_runs"] = r.get("in_flight")
        metrics[f"{cls.name}_waiting"] = r.get("queued")
        if r["state"] != HEALTHY:
            words.append(r["reason"])
    worst = next(s for s in WORST_FIRST if s in states)
    if worst == HEALTHY:
        reason = " ".join(rows[c.name]["reason"] for c in settings.classes)
    else:
        reason = " ".join(words)
    return Observation(worst, reason, evidence="query_pod_scaler_state", metrics=metrics)


REGISTRY.register(HealthCheck(
    component_id="dependency:query_pods", kind=KIND_DEPENDENCY, label="query pods (sizes and their scaling)",
    scope=SCOPE_FLEET, owner=OWNER_FLEET_WATCHER, probe=probe_query_pods, timeout_seconds=3.0,
    interval_seconds=30, controls=(CONTROL_PROBE_NOW,), group="platform",
    legacy_routes=("/api/admin/background-jobs/query_pod_scaler/status",),
    docs="healthy: every size is scaled by its one controller and nothing waits too long; degraded: KEDA "
         "not ready or not adding pods, a size at its maximum with runs waiting, two controllers on one "
         "size, or QueryStudio scaling a size KEDA should; down: a size's Deployment is missing or could "
         "not be scaled; unknown: Kubernetes or the job table could not be read, or the scaler is silent."))
