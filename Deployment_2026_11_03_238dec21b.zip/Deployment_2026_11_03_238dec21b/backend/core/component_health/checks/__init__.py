"""The declared checks.  Importing a module here registers its checks; the
registry's ``load()`` imports every module once.  A new component is a new
``REGISTRY.register(HealthCheck(...))`` in one of these files (or a new
file imported by ``registry.load``), never an edit to the page."""
