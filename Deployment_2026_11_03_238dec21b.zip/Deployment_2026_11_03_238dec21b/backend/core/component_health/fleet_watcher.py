"""The FLEET WATCHER: an APScheduler job on the scheduler-lock holder.

Every tick (``report_interval_seconds``):

0. RETIRE the pods that are gone (``retire.py``: superseded by a newer pod of
   their role, or silent past ``pod_retire_after_seconds``): one ``retired``
   event each, their alerts cleared, their rows deleted -- a rollout never
   pages for pods that were simply replaced; the ROLE row ``pod:role:<role>``
   is what is DOWN when none is left;
1. derive the dependency checks from the tables (connections, SFTP hosts,
   external pods, the roles the fleet knows) and register them;
2. probe the dependencies that are DUE (their own interval, round-robin,
   at most ``max_probes_per_cycle``; a ``probe_now`` intent makes one due)
   and write the ``@fleet`` rows;
3. compute the scheduler election row and every singleton daemon's fleet
   verdict from all pods' rows (silence applied);
4. confirm transitions (``transition_confirmations`` consecutive reads) into
   ``component_health_events``, raise / clear alerts through THE alert road,
   muted while an intent stands;
5. expire intents, GC the rows of pods silent past ``dead_pod_retention_hours``
   and events past ``events_retention_days``.

It is declared like every other daemon: ``SCHEDULER_OWNED`` (brain-daemon
shape), a ``JobContract`` with ``job_id``, main.py's hybrid literal.
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from core.component_health.contract import HealthCheck, Observation, ProbeContext
from core.component_health.vocabulary import (
    ALERT_DEDUPE_PREFIX, CONTROL_PROBE_NOW, DEGRADED, DISPOSITION_DRAINING, DISPOSITION_PAUSED,
    DOWN, FLEET_POD_ID, HEALTHY, INTENT_PENDING, KIND_DAEMON, KIND_DEPENDENCY, KIND_POD,
    OWNER_FLEET_WATCHER, RETIRED, ROLE_ROW_PREFIX, SCOPE_FLEET, SCOPE_PER_POD, SCOPE_SINGLETON, UNKNOWN,
    unknown_reason,
)

logger = logging.getLogger(__name__)

NAME = "component_health_fleet_watcher"
JOB_ID = NAME

_last_probe: Dict[str, float] = {}
_derived_ids: Set[str] = set()
#: (pod_id, component_id) -> {"state", "count"} -- the confirmation memory,
#: reseeded from the events table on the first tick after a (re)start
_confirm: Dict[Tuple[str, str], Dict[str, Any]] = {}
_seeded = False
_ticks = 0
_last_tick: Dict[str, Any] = {}


def _cfg():
    from core.config import component_health as c
    return c


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ── 1. derived checks ────────────────────────────────────────────────────────

def _role_probe(role: str):
    def _probe(ctx: ProbeContext) -> Observation:
        from core.component_health.retire import role_verdict
        from core.component_health.rules import Thresholds
        th = Thresholds.from_config()
        state, reason, metrics = role_verdict(role, ctx.db.list_component_health(component_id="pod:self"),
                                              down_after_s=th.pod_down_after_seconds,
                                              stale_after_s=th.stale_after_seconds)
        return Observation(state, reason, evidence="pod_rows", metrics=metrics)
    _probe.__name__ = f"probe_role_{role}"
    return _probe


def _role_checks(db, extra_roles: Iterable[str] = ()) -> List[HealthCheck]:
    """One ``pod:role:<role>`` fleet row per role the fleet knows -- the thing
    that is DOWN when every pod of a role is gone (retire.py)."""
    from core.component_health.retire import roles_present
    try:
        rows = db.list_component_health()
    except Exception as exc:                               # noqa: BLE001
        logger.warning("[component_health] pod rows unreadable for the role rows: %s", exc)
        return []
    out: List[HealthCheck] = []
    for role in sorted(set(roles_present(rows)) | {str(r) for r in extra_roles if r}):
        out.append(HealthCheck(
            component_id=f"{ROLE_ROW_PREFIX}{role}", kind=KIND_POD, label=f"pods of role {role}",
            scope=SCOPE_FLEET, owner=OWNER_FLEET_WATCHER, probe=_role_probe(role), timeout_seconds=3.0,
            interval_seconds=15, controls=(), legacy_routes=("/api/admin/multi-pod/pods",), group="pods",
            docs=("The ROLE, not a pod name: healthy with N live pods, unknown while every pod of the role "
                  "is merely stale, DOWN when none is live.  A pod that stopped reporting is retired once a "
                  "newer pod of its role reports or after pod_retire_after_seconds; this row is what alerts.")))
    return out


def _refresh_derived(db, reg, retired_roles: Iterable[str] = ()) -> Tuple[int, List[str]]:
    global _derived_ids
    from core.component_health.checks.dependencies import derived_checks
    from core.component_health.checks.platform import register_external_pods
    register_external_pods(reg)
    from core.component_health.planted import planted_checks
    checks = derived_checks(db) + _role_checks(db, retired_roles) + planted_checks(db)
    ids = {c.component_id for c in checks}
    for c in checks:
        reg.register(c, replace=True)
    gone = sorted(_derived_ids - ids)
    for cid in gone:
        reg.unregister(cid)
        _last_probe.pop(cid, None)
    _derived_ids = ids
    return len(checks), gone


# ── 2. dependency probes ─────────────────────────────────────────────────────

def _probe_now_targets(db) -> Set[str]:
    try:
        return {i["component_id"] for i in db.list_component_intents(status=[INTENT_PENDING])
                if i["control"] == CONTROL_PROBE_NOW}
    except Exception:                                      # noqa: BLE001
        return set()


def _due_slack_seconds(tick_seconds: float, interval_seconds: float) -> float:
    """How early a check may be probed so its interval never SLIPS a tick.

    2026-10-18, measured on the rig: a 30 s interval judged by a 15 s tick
    was probed every 45 s (``now - last >= 30`` was 29.98 at the tick it
    should have fired on), so every dependency row aged past
    ``stale_after_seconds`` (45) between probes and read UNKNOWN, and a
    stopped SFTP took > 45 s to show DOWN.  A check is due within half a
    tick of its interval (never more than half its own interval early)."""
    return max(0.0, min(float(tick_seconds) / 2.0, float(interval_seconds) / 2.0))


def _due(reg, forced: Set[str], limit: int) -> List[HealthCheck]:
    now = time.monotonic()
    try:
        tick = float(_cfg().report_interval_seconds)
    except Exception:                                      # noqa: BLE001
        tick = 15.0
    due: List[Tuple[float, HealthCheck]] = []
    for c in reg.fleet_checks():
        if c.kind == KIND_DAEMON or c.component_id == "dependency:scheduler" \
                or str(c.component_id).startswith(ROLE_ROW_PREFIX):
            continue                                   # derived from rows every tick, not probed
        last = _last_probe.get(c.component_id)
        slack = _due_slack_seconds(tick, c.interval_seconds)
        if c.component_id in forced or last is None or now - last >= c.interval_seconds - slack:
            due.append((last or 0.0, c))
    # oldest first; on a tie (the first tick: nothing probed yet) the DECLARED
    # platform dependencies before the derived per-connection ones -- with many
    # connections the cycle limit cut postgres / scheduler out of the first tick
    due.sort(key=lambda t: (t[0], t[1].component_id in _derived_ids))
    return [c for _l, c in due[:max(1, limit)]]


def _fleet_row(check: HealthCheck, obs: Observation) -> Dict[str, Any]:
    r = obs.to_row()
    r.update({"component_id": check.component_id, "kind": check.kind, "scope": check.scope,
              "label": check.label, "group": check.group, "pod_role": "fleet",
              "interval_seconds": int(check.interval_seconds), "timeout_seconds": float(check.timeout_seconds)})
    return r


def _redact(obs: Observation) -> Observation:
    try:
        from core.error_sanitizer import redact_structure
        obs.metrics = redact_structure(dict(obs.metrics or {}))
        obs.reason = str(redact_structure(obs.reason))
    except Exception:                                      # noqa: BLE001
        pass
    return obs


def _probe_dependencies(db, reg) -> Tuple[List[Dict[str, Any]], int]:
    from core.component_health.probe_pool import pool
    from core.component_health.reporter import pod_id
    forced = _probe_now_targets(db)
    due = _due(reg, forced, _cfg().max_probes_per_cycle)
    ctx = ProbeContext(db=db, pod_id=pod_id(), pod_role="fleet_watcher")
    rows: List[Dict[str, Any]] = []
    for c in due:
        obs = _redact(pool().run(c, ctx))
        _last_probe[c.component_id] = time.monotonic()
        rows.append(_fleet_row(c, obs))
    if forced:
        for i in db.list_component_intents(status=[INTENT_PENDING]):
            if i["control"] == CONTROL_PROBE_NOW and i["component_id"] in {c.component_id for c in due}:
                db.record_component_intent_application(i["id"], FLEET_POD_ID, "ok", "probed", complete=True)
    return rows, len(due)


# ── 3. rows derived from the pods' rows ──────────────────────────────────────

def _read_rows(db) -> List[Dict[str, Any]]:
    from core.component_health.rules import Thresholds, apply_silence, inherit_from_pod, pod_states
    th = Thresholds.from_config()
    now = _now()
    rows = [apply_silence(r, th, now) for r in db.list_component_health()]
    pods = pod_states(rows)
    return [inherit_from_pod(r, pods) for r in rows]


def _singleton_rows(reg, read_rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    from core.component_health.rules import daemon_fleet_verdict
    by_component: Dict[str, List[Dict[str, Any]]] = {}
    for r in read_rows:
        if r.get("pod_id") != FLEET_POD_ID and r.get("kind") == KIND_DAEMON:
            by_component.setdefault(str(r["component_id"]), []).append(r)
    out: List[Dict[str, Any]] = []
    for c in reg.all():
        if c.kind != KIND_DAEMON or c.scope != SCOPE_SINGLETON:
            continue
        pod_rows = by_component.get(c.component_id, [])
        state, reason, disp, metrics = daemon_fleet_verdict(c.component_id, pod_rows, singleton=True)
        obs = Observation(state, reason, evidence="pod_rows", metrics=metrics, disposition=disp)
        out.append(_fleet_row(c, obs))
    return out


def _role_rows(db, reg) -> List[Dict[str, Any]]:
    """``pod:role:<role>`` every tick from the pod:self rows (retire.py)."""
    from core.component_health.retire import role_verdict
    from core.component_health.rules import Thresholds
    checks = [c for c in reg.all() if str(c.component_id).startswith(ROLE_ROW_PREFIX)]
    if not checks:
        return []
    th = Thresholds.from_config()
    pod_rows = db.list_component_health(component_id="pod:self")
    out: List[Dict[str, Any]] = []
    for c in checks:
        role = str(c.component_id)[len(ROLE_ROW_PREFIX):]
        state, reason, metrics = role_verdict(role, pod_rows, down_after_s=th.pod_down_after_seconds,
                                              stale_after_s=th.stale_after_seconds)
        out.append(_fleet_row(c, Observation(state, reason, evidence="pod_rows", metrics=metrics)))
        _last_probe[c.component_id] = time.monotonic()
    return out


def _scheduler_row(db, reg) -> Optional[Dict[str, Any]]:
    c = reg.get("dependency:scheduler")
    if c is None:
        return None
    from core.component_health.checks.platform import scheduler_verdict
    try:
        obs = scheduler_verdict(db)
    except Exception as exc:                               # noqa: BLE001
        obs = Observation(UNKNOWN, f"scheduler verdict raised {type(exc).__name__}: {str(exc)[:160]}",
                          evidence="scheduler_lock")
    _last_probe[c.component_id] = time.monotonic()
    return _fleet_row(c, obs)


# ── 4. transitions and alerts ────────────────────────────────────────────────

def _seed_confirmations(db) -> None:
    global _seeded
    if _seeded:
        return
    try:
        for ev in reversed(db.list_component_health_events(limit=1000)):
            if ev.get("to_state") == RETIRED:
                continue                                   # a retired pod has no live row to confirm against
            key = (str(ev.get("pod_id") or FLEET_POD_ID), str(ev["component_id"]))
            _confirm[key] = {"state": ev["to_state"], "count": 0, "confirmed": ev["to_state"]}
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] events unreadable at seed: %s", exc)
    _seeded = True


def _alert_key(row: Dict[str, Any]) -> str:
    cid = str(row["component_id"])
    if row.get("pod_id") == FLEET_POD_ID or row.get("scope") == SCOPE_SINGLETON:
        return ALERT_DEDUPE_PREFIX + cid
    return f"{ALERT_DEDUPE_PREFIX}{cid}@{row.get('pod_id')}"


def _muted(row: Dict[str, Any], draining_pods: Set[str]) -> bool:
    if row.get("disposition") in (DISPOSITION_PAUSED, DISPOSITION_DRAINING):
        return True
    if row.get("pod_id") in draining_pods:
        return True
    return bool(row.get("muted_by_intent"))


def _alerts_belong_to_the_role_row(row: Dict[str, Any]) -> bool:
    """A pod that went SILENT, and every row inherited from it, never alerts
    by itself: the pod is retired once superseded or past the retire window,
    and what is down meanwhile is the ROLE (``pod:role:<role>``) or a singleton
    with no live holder -- those fleet rows alert (retire.py, 2026-10-18).
    A pod's OWN verdict (memory pressure, a stale key) still alerts."""
    if row.get("pod_id") == FLEET_POD_ID:
        return False
    if row.get("inherited"):
        return True
    if row.get("kind") == KIND_POD and row.get("component_id") == "pod:self":
        observed = row.get("observed_state")
        return observed is not None and observed != row.get("state")   # silence rewrote the state
    return False


def _draining_pods(db) -> Set[str]:
    from core.component_health import intents as _in
    out: Set[str] = set()
    try:
        for r in db.list_component_health(component_id="pod:self"):
            if _in.open_drain_for(db, str(r["pod_id"])) is not None:
                out.add(str(r["pod_id"]))
    except Exception:                                      # noqa: BLE001
        pass
    return out


def _raise(db, row: Dict[str, Any], kind: str) -> Optional[int]:
    try:
        from core.feed.feed_alerts import raise_component_alert as fn
        label = str(row.get("label") or row["component_id"])
        if row.get("pod_id") not in (None, FLEET_POD_ID):
            label = f"{label} on {row['pod_id']}"
        a = fn(db, kind, component_id=str(row["component_id"]), label=label,
               message=str(row.get("reason") or "")[:900], dedupe_key=_alert_key(row),
               href=f"/admin?section=componentHealth&component={row['component_id']}")
        return (a or {}).get("id")
    except Exception as exc:                               # noqa: BLE001
        logger.warning("[component_health] alert %s for %s not raised: %s", kind, row.get("component_id"), exc)
        return None


def _clear(db, row: Dict[str, Any]) -> int:
    try:
        from core.feed import feed_alerts
        rows = feed_alerts.clear(db, by=NAME, dedupe_keys=[_alert_key(row)])
        return len(rows or [])
    except Exception as exc:                               # noqa: BLE001
        logger.warning("[component_health] alert for %s not cleared: %s", row.get("component_id"), exc)
        return 0


def _transitions(db, read_rows: List[Dict[str, Any]], fleet_rows: List[Dict[str, Any]]) -> Dict[str, int]:
    """Confirm transitions on EVERY row the page shows (pods' rows as read,
    plus this tick's fleet rows) and act on them."""
    from core.component_health.rules import Thresholds, alert_kind_for, clear_due
    th = Thresholds.from_config()
    _seed_confirmations(db)
    counts = {"transitions": 0, "alerts_raised": 0, "alerts_cleared": 0, "muted": 0}
    draining = _draining_pods(db)
    alerts_on = bool(_cfg().alerts_enabled)
    now = _now()
    for row in [r for r in read_rows if r.get("pod_id") != FLEET_POD_ID] + fleet_rows:
        key = (str(row.get("pod_id") or FLEET_POD_ID), str(row["component_id"]))
        state = str(row.get("state") or UNKNOWN)
        mem = _confirm.setdefault(key, {"state": None, "count": 0, "confirmed": None})
        if mem["state"] == state:
            mem["count"] += 1
        else:
            mem["state"], mem["count"] = state, 1
        confirmed_before = mem.get("confirmed")
        if mem["count"] >= th.transition_confirmations and confirmed_before != state:
            mem["confirmed"] = state
            if confirmed_before is not None or state != HEALTHY:
                try:
                    db.add_component_health_event({"component_id": row["component_id"], "pod_id": key[0],
                                                   "from_state": confirmed_before, "to_state": state,
                                                   "reason": row.get("reason"), "at": now,
                                                   "intent_id": row.get("muted_by_intent")})
                    counts["transitions"] += 1
                except Exception as exc:                   # noqa: BLE001
                    logger.debug("[component_health] event not written: %s", exc)
        if not alerts_on:
            continue
        if _alerts_belong_to_the_role_row(row):
            continue
        muted = _muted(row, draining)
        if muted:
            counts["muted"] += 1
        confirmed = mem.get("confirmed")
        unknown_for = None
        if confirmed == UNKNOWN:
            from core.component_health.rules import parse_ts
            since = parse_ts(row.get("state_since")) if row.get("pod_id") == FLEET_POD_ID else None
            unknown_for = (now - since).total_seconds() if since else mem["count"] * _cfg().report_interval_seconds
        kind = alert_kind_for(confirmed, unknown_for_seconds=unknown_for, th=th) if confirmed else None
        if kind and not muted and not mem.get("alert_kind") == kind:
            aid = _raise(db, row, kind)
            if aid:
                mem["alert_kind"] = kind
                mem["alert_id"] = aid
                counts["alerts_raised"] += 1
                try:
                    db.set_component_health_alert(key[0], row["component_id"], aid)
                except Exception:                          # noqa: BLE001
                    pass
        elif confirmed == HEALTHY and mem.get("alert_kind") and mem["count"] >= th.clear_after_cycles:
            if _clear(db, row):
                counts["alerts_cleared"] += 1
            mem.pop("alert_kind", None)
            mem.pop("alert_id", None)
            try:
                db.set_component_health_alert(key[0], row["component_id"], None)
            except Exception:                              # noqa: BLE001
                pass
    return counts


# ── 5. expiry and GC ─────────────────────────────────────────────────────────

def _housekeeping(db, gone_components: List[str], reg=None) -> Dict[str, int]:
    from core.component_health import intents as _in
    c = _cfg()
    out = {"intents_expired": 0, "rows_gc": 0, "events_pruned": 0}
    try:
        out["intents_expired"] = _in.expire(db)
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] expiry failed: %s", exc)
    try:
        hours = int(c.dead_pod_retention_hours)
        if hours > 0:
            out["rows_gc"] = db.delete_component_health(reported_before=_now() - timedelta(hours=hours))
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] dead-pod GC failed: %s", exc)
    if gone_components:
        try:
            out["rows_gc"] += db.delete_component_health(pod_id=FLEET_POD_ID, component_ids=gone_components)
        except Exception as exc:                           # noqa: BLE001
            logger.debug("[component_health] gone-component GC failed: %s", exc)
    # a ROLE row DOWN for the whole retention window is a role the deployment
    # no longer has: forget it (until then it says "no live pod of role X")
    try:
        from core.component_health.rules import parse_ts
        from core.component_health.vocabulary import ROLE_ROW_PREFIX
        hours = int(c.dead_pod_retention_hours)
        if hours > 0:
            cutoff = _now() - timedelta(hours=hours)
            forgotten = [str(r["component_id"]) for r in db.list_component_health(pod_id=FLEET_POD_ID)
                         if str(r.get("component_id") or "").startswith(ROLE_ROW_PREFIX) and r.get("state") == DOWN
                         and parse_ts(r.get("state_since")) is not None and parse_ts(r.get("state_since")) < cutoff]
            if forgotten:
                out["rows_gc"] += db.delete_component_health(pod_id=FLEET_POD_ID, component_ids=forgotten)
                for cid in forgotten:
                    _last_probe.pop(cid, None)
                    if reg is not None:
                        reg.unregister(cid)
                    _derived_ids.discard(cid)
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] role-row GC failed: %s", exc)
    try:
        out["events_pruned"] = db.prune_component_health_events(int(c.events_retention_days))
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] event prune failed: %s", exc)
    return out


# ── the tick ─────────────────────────────────────────────────────────────────

#: one tick at a time per process -- the module's memory (derived ids, probe
#: times, confirmations) is shared, and two interleaved ticks (the APScheduler
#: job and a run-now / the JobContract tick) unregistered each other's checks
_tick_lock = threading.Lock()


def watcher_tick(db) -> Dict[str, Any]:
    """ONE tick.  The JobContract tick and the APScheduler job's function;
    returns the counts the ledger classifies (``fleet_rows`` > 0 = ok)."""
    with _tick_lock:
        return _watcher_tick(db)


def _watcher_tick(db) -> Dict[str, Any]:
    global _ticks, _last_tick
    if db is None:
        return {"status": "skipped", "reason": "no database manager"}
    t0 = time.monotonic()
    from core.component_health.registry import load
    reg = load()
    counts: Dict[str, Any] = {}
    # 0. retire the pods that are GONE (superseded by a newer pod of their
    #    role, or silent past the retire window) before anything reads them
    try:
        from core.component_health.retire import retire_pods
        from core.component_health.rules import Thresholds
        th0 = Thresholds.from_config()
        ret = retire_pods(db, down_after_s=th0.pod_down_after_seconds, retire_after_s=th0.pod_retire_after_seconds)
        for r in ret["retired"]:
            for key in [k for k in _confirm if k[0] == r["pod_id"]]:
                _confirm.pop(key, None)
        counts["pods_retired"] = len(ret["retired"])
        retired_roles = [r["role"] for r in ret["retired"]]
        counts["rows_retired"] = int(ret["rows_deleted"])
        counts["retired_alerts_cleared"] = int(ret["alerts_cleared"])
    except Exception as exc:                               # noqa: BLE001
        logger.warning("[component_health] retire pass failed: %s", exc)
        counts["pods_retired"] = 0
        retired_roles = []
    n_derived, gone = _refresh_derived(db, reg, retired_roles)
    counts["derived_checks"] = n_derived
    dep_rows, probed = _probe_dependencies(db, reg)
    counts["probes_run"] = probed
    sched = _scheduler_row(db, reg)
    read_rows = _read_rows(db)
    fleet_rows = dep_rows + ([sched] if sched else []) + _role_rows(db, reg) + _singleton_rows(reg, read_rows)
    written = db.upsert_component_health(FLEET_POD_ID, fleet_rows)
    counts["fleet_rows"] = written
    # re-read the fleet rows as written (state_since / confirmations) for the transition pass
    fleet_now = [r for r in db.list_component_health(pod_id=FLEET_POD_ID)
                 if r["component_id"] in {f["component_id"] for f in fleet_rows}]
    counts.update(_transitions(db, read_rows, fleet_now))
    counts.update(_housekeeping(db, gone, reg))
    _ticks += 1
    counts["ms"] = int((time.monotonic() - t0) * 1000)
    counts["at"] = _now().isoformat()
    _last_tick = dict(counts)
    return counts


def watcher_verdict(raw: Any) -> Tuple[str, Optional[str], Dict[str, Any]]:
    """The ledger's verdict: fleet rows written = ok; none = no_input."""
    from core.background_job_contract import OUTCOME_ERROR, OUTCOME_NO_INPUT, OUTCOME_OK, OUTCOME_SKIPPED
    if not isinstance(raw, dict):
        return OUTCOME_ERROR, "the tick returned nothing", {}
    if raw.get("status") == "skipped":
        return OUTCOME_SKIPPED, str(raw.get("reason")), {}
    counts = {k: v for k, v in raw.items() if isinstance(v, (int, float)) and k not in ("ms",)}
    if int(raw.get("fleet_rows") or 0) > 0:
        return OUTCOME_OK, None, counts
    return OUTCOME_NO_INPUT, "no fleet row written", counts


def status(db=None) -> Dict[str, Any]:
    from core.daemon_snapshots import daemon_runs_here
    return {"runs_here": daemon_runs_here(NAME), "ticks": _ticks, "last_tick": dict(_last_tick),
            "derived_checks": sorted(_derived_ids), "probed": sorted(_last_probe)}


# ── registration (the brain-daemon shape) ────────────────────────────────────

def register_fleet_watcher_daemon(scheduler: Any, db_manager: Any) -> Optional[str]:
    """``register_*_daemon(scheduler, db_manager)`` -- what daemon_registry's
    ``_reg_brain_daemon`` and main.py's hybrid block both call."""
    if scheduler is None:
        return None
    try:
        from core.config import component_health as _cfg
        if not _cfg.enabled:
            logger.info("[component_health] fleet watcher not registered: component_health.enabled=false")
            return None
        every = int(_cfg.report_interval_seconds)
    except Exception:                                      # noqa: BLE001
        every = 15

    def _tick():
        try:
            from core.background_jobs import is_paused
            if is_paused(NAME):
                return {"status": "skipped", "reason": "paused by admin"}
        except Exception:                                  # noqa: BLE001
            pass
        try:
            from core.daemon_snapshots import daemon_runs_here
            if not daemon_runs_here(NAME):
                return {"status": "skipped", "reason": "this process does not hold the scheduler lock"}
        except Exception:                                  # noqa: BLE001
            pass
        try:
            return watcher_tick(db_manager)
        except Exception as exc:                           # noqa: BLE001
            logger.warning("[component_health] watcher tick error: %s", exc, exc_info=True)
            return {"error": str(exc)[:300]}

    scheduler.add_job(_tick, "interval", seconds=max(5, every), id=JOB_ID, replace_existing=True,
                      max_instances=1, coalesce=True)
    logger.info("[component_health] fleet watcher scheduled every %d s (job_id=%s)", every, JOB_ID)
    try:
        from core import background_jobs as _bj
        _bj.record_boot_registrations([NAME], "APScheduler interval job on the scheduler-lock holder",
                                      running=True, status="registered")
    except Exception:                                      # noqa: BLE001
        pass
    return JOB_ID


def reset_for_tests() -> None:
    global _seeded, _ticks, _last_tick, _derived_ids
    # a derived check (a role row, a connection) stays in the process-wide
    # registry unless it is unregistered: forgetting only its id left a
    # previous test's pod:role:hybrid there, DOWN and alerting, in the next one
    from core.component_health.registry import REGISTRY
    for cid in _derived_ids:
        REGISTRY.unregister(cid)
    _last_probe.clear()
    _confirm.clear()
    _derived_ids = set()
    _seeded = False
    _ticks = 0
    _last_tick = {}


__all__ = ["JOB_ID", "NAME", "register_fleet_watcher_daemon", "reset_for_tests", "status",
           "watcher_tick", "watcher_verdict"]
