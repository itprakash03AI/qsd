"""The planted slow probe (Docker proof C11's TEST SEAM), carried through the DATABASE
(2026-11-02).

The route used to register the probe in the API process's in-memory registry.  That
worked while the API pod could hold the scheduler lock and run the fleet watcher in
the same process; with one responsibility per component the watcher runs on the
scheduler pod and never saw it.  The plant is now a ``system_settings`` row
(``component_health.planted_probe.<tag>`` = seconds) that the fleet watcher DERIVES
into a check on its next tick, like a connection; removing the row removes the check.
Inert unless ``component_health.planted_probe_enabled``.
"""
from __future__ import annotations

import logging
import time
from typing import Any, List

from core.component_health.contract import HealthCheck, Observation
from core.component_health.vocabulary import (
    CONTROL_PROBE_NOW, HEALTHY, KIND_DEPENDENCY, OWNER_FLEET_WATCHER, SCOPE_FLEET,
)

logger = logging.getLogger(__name__)

PREFIX = "component_health.planted_probe."


def component_id_of(tag: str) -> str:
    return f"dependency:planted_{tag}"


def enabled() -> bool:
    try:
        from core.config import component_health as _cfg
        return bool(_cfg.planted_probe_enabled)
    except Exception:                                      # noqa: BLE001
        return False


def plant(db, tag: str, seconds: int) -> str:
    db.set_system_setting(PREFIX + tag, int(seconds))
    return component_id_of(tag)


def unplant(db, tag: str) -> bool:
    return bool(db.delete_system_setting(PREFIX + tag))


def _check(tag: str, seconds: int) -> HealthCheck:
    def _sleepy(_ctx):
        time.sleep(seconds)
        return Observation(HEALTHY, "slept through its budget")
    return HealthCheck(component_id=component_id_of(tag), kind=KIND_DEPENDENCY, label=f"planted probe {tag}",
                       scope=SCOPE_FLEET, owner=OWNER_FLEET_WATCHER, probe=_sleepy, timeout_seconds=3.0,
                       interval_seconds=15, controls=(CONTROL_PROBE_NOW,), group="test",
                       docs="a planted probe that sleeps past its budget (Docker proof C11)")


def planted_checks(db: Any) -> List[HealthCheck]:
    if not enabled():
        return []
    out: List[HealthCheck] = []
    try:
        for row in db.list_system_settings(prefix=PREFIX) or []:
            key = str(row.get("key", ""))
            tag = key[len(PREFIX):]
            if tag:
                out.append(_check(tag, int(db.get_system_setting(key, 60) or 60)))
    except Exception as exc:                               # noqa: BLE001
        logger.warning("[component_health] planted probes unreadable: %s", exc)
    return out
