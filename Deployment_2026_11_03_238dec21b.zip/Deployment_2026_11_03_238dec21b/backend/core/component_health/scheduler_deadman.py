"""Who watches the watcher: the job-worker raises ONE alert when the scheduler is
not running (2026-11-02).

The fleet watcher -- every fleet row, every component alert -- is an APScheduler job
on the scheduler-lock holder (lock row 1), and the scheduler is a single pod by design
(two would race on the cron rows).  So when the scheduler pod dies or crash-loops, the
one process that raises component alerts is the one that is gone: the page goes stale
(its rows age into "no report for N s", reader.py), and nobody is TOLD.  Found on the
rig by component_health_proof C5 the day the API stopped taking the scheduler lock over;
the owner's CrashLoopBackOff scheduler was exactly this case.

The job-worker holds its OWN election (lock row 2) and is always on, so it asks the
same question the page asks on read -- ``platform.scheduler_verdict`` -- and, when the
answer is DOWN on two ticks running (a rolling deploy hands the lock over in seconds;
one stale read is not an outage), raises the alert the fleet watcher would have raised
for ``dependency:scheduler``: the SAME dedupe key, so it is one alert whoever raises or
clears it.  It clears that alert when the verdict is HEALTHY again.  A PAUSED or
otherwise degraded scheduler is the fleet watcher's to judge (it is running then);
this check never touches it.  It watches; it runs nothing of the scheduler's.
"""
from __future__ import annotations

import logging
from typing import Any, Dict

from core.component_health.vocabulary import DOWN, HEALTHY

logger = logging.getLogger(__name__)

NAME = "scheduler_deadman"
COMPONENT_ID = "dependency:scheduler"
LABEL = "the scheduler"
#: consecutive DOWN verdicts before the alert is raised
CONFIRM_TICKS = 2
INTERVAL_SECONDS = 30

_down_ticks = 0


def tick(db) -> Dict[str, Any]:
    """One look at lock row 1.  Returns what it saw and did."""
    global _down_ticks
    from core.component_health import fleet_watcher as fw
    from core.component_health.checks.platform import scheduler_verdict
    obs = scheduler_verdict(db)
    row = {"component_id": COMPONENT_ID, "pod_id": fw.FLEET_POD_ID, "label": LABEL, "reason": obs.reason}
    out: Dict[str, Any] = {"status": "ran", "state": obs.state, "reason": obs.reason, "raised": None, "cleared": 0}
    if obs.state == DOWN:
        _down_ticks += 1
        out["down_ticks"] = _down_ticks
        if _down_ticks >= CONFIRM_TICKS:
            out["raised"] = fw._raise(db, row, "component_down")
    else:
        _down_ticks = 0
        if obs.state == HEALTHY:
            out["cleared"] = fw._clear(db, row)
    return out


def reset_for_tests() -> None:
    global _down_ticks
    _down_ticks = 0
