"""A control is an INTENT ROW the owning pod applies -- never a call the
requesting pod makes on another pod's behalf (docs §3.8).

* ``request``  -- validates (component, control) against the registry, the
                  reason (mandatory), computes the consequence, writes the
                  row, nudges the owner over the event bus.
* ``apply_for_pod`` -- run by every pod's reporter each cycle: applies the
                  pending intents addressed to this pod (or ``*``), records
                  the outcome per pod.
* ``expire``   -- the fleet watcher: pending intents past ``expires_at``.
* the DRAINING flag -- process-local, read by ``/health/ready`` and by the
                  claim loops; set by applying a ``drain`` intent.

Pause / resume of a daemon are NOT intents: ``background_job_state`` + the
per-pod reconciler are their one home.  ``run_now`` is the contract path.
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

from core.component_health.vocabulary import (
    CONTROL_DRAIN, CONTROL_PROBE_NOW, CONTROL_RERUN_SELF_TEST, CONTROL_RESET_BREAKER,
    CONTROL_UNDRAIN, EVERY_POD_TARGET, INTENT_APPLIED, INTENT_CONTROLS, INTENT_EXPIRED,
    INTENT_PENDING, INTENT_WITHDRAWN,
)

logger = logging.getLogger(__name__)

INTENT_EVENT = "component_intent"


class IntentRefused(ValueError):
    def __init__(self, status_code: int, reason: str) -> None:
        super().__init__(reason)
        self.status_code = status_code
        self.reason = reason


# ── the draining flag (process-local; one per server process) ───────────────

_drain_lock = threading.Lock()
_draining: Dict[str, Any] = {"active": False, "since": None, "by": None, "intent_id": None}


def set_draining(active: bool, *, by: Optional[str] = None, intent_id: Optional[int] = None) -> None:
    with _drain_lock:
        _draining["active"] = bool(active)
        _draining["since"] = datetime.now(timezone.utc).isoformat() if active else None
        _draining["by"] = by if active else None
        _draining["intent_id"] = intent_id if active else None
        _drain_row_cache.update({"at": 0.0, "pod_id": None, "value": None})   # the row view follows at once


def is_draining() -> bool:
    with _drain_lock:
        return bool(_draining["active"])


def draining_info() -> Dict[str, Any]:
    with _drain_lock:
        return dict(_draining)


#: the DB-backed answer, cached briefly so a readiness probe stays cheap
_drain_row_cache: Dict[str, Any] = {"at": 0.0, "pod_id": None, "value": None}
DRAIN_ROW_CACHE_SECONDS = 2.0


def effective_draining(db: Any = None, pod_id: Optional[str] = None) -> Dict[str, Any]:
    """What a readiness probe must answer: the process-local flag when it is
    up, else the DRAIN ROW -- an applied, unexpired drain addressed to this
    pod (``open_drain_for``), read from the table and cached 2 s.

    2026-10-18, the rebuilt rig's C6: the drain intent was recorded as applied
    by the api pod and ``/health/ready`` still answered 200 ``ready``.  A flag
    that lives in one process's memory is only as good as the process that
    happens to serve the probe (a second server process, a probe before the
    reporter's first cycle after a restart, a reporter whose cycle has not
    run yet).  The ROW is the truth; the flag is the hurry.  Unreadable table
    = the local flag alone (never "draining" by accident)."""
    local = draining_info()
    if local.get("active"):
        return dict(local, source="local_flag")
    try:
        me = pod_id or _this_pod_id()
    except Exception:                                      # noqa: BLE001
        return dict(local, source="local_flag")
    now = time.monotonic()
    with _drain_lock:
        hit = (_drain_row_cache["value"] is not None and _drain_row_cache["pod_id"] == me
               and now - _drain_row_cache["at"] < DRAIN_ROW_CACHE_SECONDS)
        if hit:
            return dict(_drain_row_cache["value"])
    if db is None:
        try:
            from core.database import get_db_manager
            db = get_db_manager()
        except Exception:                                  # noqa: BLE001
            db = None
    value: Dict[str, Any] = dict(local, source="local_flag")
    if db is not None:
        try:
            drain = open_drain_for(db, me)
            if drain is not None and me in (drain.get("applied_by_pods") or {}):
                value = {"active": True, "since": drain.get("created_at") or drain.get("requested_at"),
                         "by": drain.get("requested_by"), "intent_id": drain.get("id"), "source": "drain_row"}
        except Exception as exc:                           # noqa: BLE001
            logger.debug("[component_health] drain row unreadable for readiness: %s", exc)
    with _drain_lock:
        _drain_row_cache.update({"at": now, "pod_id": me, "value": dict(value)})
    return value


def _this_pod_id() -> str:
    from core.component_health.reporter import pod_id
    return pod_id()


def reset_drain_cache_for_tests() -> None:
    with _drain_lock:
        _drain_row_cache.update({"at": 0.0, "pod_id": None, "value": None})


# ── request ──────────────────────────────────────────────────────────────────

def _nudge(intent: Dict[str, Any]) -> None:
    """Tell the owner now rather than at its next cycle.  Advisory: the row
    is the truth, the event is the hurry."""
    try:
        from core import event_bus
        event_bus.publish(INTENT_EVENT, {"type": INTENT_EVENT, "intent_id": intent["id"],
                                         "control": intent["control"],
                                         "target_pod_id": intent["target_pod_id"]}, audience=[])
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] intent nudge not sent: %s", exc)


def consequence_of(db, control: str, component_id: str, target_pod_id: str) -> str:
    """What the system computes at request time, for the audit row and the
    confirm dialog.  Cheap facts only."""
    try:
        if control == CONTROL_DRAIN:
            rows = db.list_component_health(component_id="pod:self")
            live = [r for r in rows if r.get("pod_id") != target_pod_id]
            same_role = None
            me = next((r for r in rows if r.get("pod_id") == target_pod_id), None)
            if me is not None:
                same_role = [r for r in live if r.get("pod_role") == me.get("pod_role")]
            parts = [f"{target_pod_id} stops accepting new work and leaves the Service once its "
                     f"readiness answers 503; in-flight work finishes"]
            if me is not None and (me.get("metrics") or {}).get("scheduler_lock_held"):
                parts.append("it holds the scheduler lock: feeds and every singleton daemon pause "
                             "until the lock moves (~20 s after it stops heartbeating)")
            if same_role is not None and not same_role:
                parts.append(f"it is the ONLY reporting pod of role {me.get('pod_role')}")
            return "; ".join(parts)
        if control == CONTROL_RESET_BREAKER:
            return (f"every pod closes its breaker for {component_id}; the next call tries the "
                    f"dependency and the breaker re-opens on failure")
        if control == CONTROL_RERUN_SELF_TEST:
            return "the read-only self-test suites run once on the pod (< 1 s)"
        if control == CONTROL_PROBE_NOW:
            return "one bounded probe on the fleet watcher's next tick"
        if control == CONTROL_UNDRAIN:
            return f"{target_pod_id} answers ready again and resumes claiming work"
    except Exception as exc:                               # noqa: BLE001
        return f"consequence could not be computed: {type(exc).__name__}: {exc}"
    return ""


def find_check(db, component_id: str, registry=None):
    """THE lookup of a component's declaration for a control (2026-11-02): this
    process's registry, else a DERIVED check (a connection, an SFTP host) built from
    the same tables -- no probe runs.  Derived checks are registered only in the fleet
    watcher's process (the scheduler), so on the api pod every breaker reset was a 404."""
    from core.component_health.registry import load
    reg = registry or load()
    check = reg.get(component_id)
    if check is None:
        try:
            from core.component_health.checks.dependencies import derived_checks
            check = next((c for c in derived_checks(db) if c.component_id == component_id), None)
        except Exception as exc:                           # noqa: BLE001
            logger.warning("[component_health] derived checks unreadable: %s", exc)
    return check


def request(db, *, control: str, component_id: str, requested_by: str, reason: str,
            target_pod_id: Optional[str] = None, expires_in_minutes: Optional[int] = None,
            registry=None) -> Dict[str, Any]:
    """Validate and write one intent.  Raises IntentRefused(400/404/409)."""
    check = find_check(db, component_id, registry)
    if check is None:
        raise IntentRefused(404, f"unknown component {component_id!r}")
    if control not in INTENT_CONTROLS:
        raise IntentRefused(409, f"{control!r} is not an intent control; the intent controls are "
                                 f"{list(INTENT_CONTROLS)}")
    if control not in check.controls:
        raise IntentRefused(409, f"{control!r} is not a control of {component_id}; it declares "
                                 f"{list(check.controls) or 'none'}")
    if not (reason or "").strip():
        raise IntentRefused(400, "a reason is required")
    target = (target_pod_id or "").strip()
    if control == CONTROL_RESET_BREAKER:
        target = target or EVERY_POD_TARGET
    elif control == CONTROL_PROBE_NOW:
        from core.component_health.vocabulary import FLEET_POD_ID
        target = FLEET_POD_ID
    elif not target:
        raise IntentRefused(400, f"{control} needs target_pod_id (the pod to apply it on)")
    pending = db.list_component_intents(status=[INTENT_PENDING], component_id=component_id)
    dup = [p for p in pending if p["control"] == control and p["target_pod_id"] == target]
    if dup:
        raise IntentRefused(409, f"an identical {control} intent (#{dup[0]['id']}) is already pending")
    from core.config import component_health as cfg
    minutes = expires_in_minutes if expires_in_minutes is not None else cfg.intent_default_expiry_minutes
    expires = (datetime.now(timezone.utc) + timedelta(minutes=int(minutes))) if int(minutes) > 0 else None
    row = db.create_component_intent({
        "control": control, "component_id": component_id, "target_pod_id": target,
        "requested_by": requested_by, "reason": reason.strip(), "expires_at": expires,
        "consequence": consequence_of(db, control, component_id, target),
        "audit_action": f"component_health.{control}"})
    _nudge(row)
    return row


def withdraw(db, intent_id: int, *, by: str) -> Optional[Dict[str, Any]]:
    row = db.get_component_intent(intent_id)
    if row is None:
        return None
    if row["status"] != INTENT_PENDING:
        raise IntentRefused(409, f"intent #{intent_id} is {row['status']}, not pending")
    return db.update_component_intent(intent_id, {"status": INTENT_WITHDRAWN, "withdrawn_by": by,
                                                   "withdrawn_at": datetime.now(timezone.utc)})


# ── apply (the reporter, every pod, every cycle) ─────────────────────────────

Applier = Callable[[Dict[str, Any]], Dict[str, Any]]   # intent -> {"outcome": "ok"|"failed"|"not_applicable", "detail"}


def _pods_reporting(db, now: datetime, stale_after: int) -> List[str]:
    out = []
    for r in db.list_component_health(component_id="pod:self"):
        from core.component_health.rules import age_seconds
        age = age_seconds(r.get("reported_at"), now)
        if age is not None and age <= stale_after:
            out.append(str(r["pod_id"]))
    return sorted(out)


def apply_for_pod(db, pod_id: str, applier: Applier, *, now: Optional[datetime] = None) -> List[Dict[str, Any]]:
    """Apply every pending intent addressed to ``pod_id`` or ``*`` that this
    pod has not yet applied.  A ``*`` intent completes when every pod that
    reports has applied it (decided here from the pod rows)."""
    now = now or datetime.now(timezone.utc)
    done: List[Dict[str, Any]] = []
    try:
        pending = db.list_component_intents(status=[INTENT_PENDING])
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] intents unreadable: %s", exc)
        return done
    for it in pending:
        target = it.get("target_pod_id")
        if target not in (pod_id, EVERY_POD_TARGET):
            continue
        if pod_id in (it.get("applied_by_pods") or {}):
            continue
        exp = it.get("expires_at")
        if exp:
            from core.component_health.rules import parse_ts
            e = parse_ts(exp)
            if e is not None and e < now:
                continue                               # the watcher expires it
        try:
            result = applier(it) or {}
            outcome = str(result.get("outcome") or "ok")
            detail = str(result.get("detail") or "")
        except Exception as exc:                           # noqa: BLE001
            outcome, detail = "failed", f"{type(exc).__name__}: {str(exc)[:300]}"
        if target == EVERY_POD_TARGET:
            try:
                from core.config import component_health as cfg
                pods = _pods_reporting(db, now, cfg.stale_after_seconds)
            except Exception:                              # noqa: BLE001
                pods = [pod_id]
            applied = set((it.get("applied_by_pods") or {}).keys()) | {pod_id}
            complete = set(pods) <= applied
        else:
            complete = True
        row = db.record_component_intent_application(it["id"], pod_id, outcome, detail, complete=complete)
        if row is not None:
            done.append(row)
            logger.info("[component_health] intent #%s %s applied on %s: %s %s", it["id"],
                        it["control"], pod_id, outcome, detail[:120])
    return done


def expire(db, *, now: Optional[datetime] = None) -> int:
    """Pending intents past expires_at -> expired.  A drain that expires
    is lifted by the pod on its next cycle (it re-reads the open drains)."""
    now = now or datetime.now(timezone.utc)
    n = 0
    from core.component_health.rules import parse_ts
    for it in db.list_component_intents(status=[INTENT_PENDING, INTENT_APPLIED]):
        e = parse_ts(it.get("expires_at"))
        if e is not None and e < now and it["control"] in (CONTROL_DRAIN,) or \
                (it["status"] == INTENT_PENDING and e is not None and e < now):
            db.update_component_intent(it["id"], {"status": INTENT_EXPIRED})
            n += 1
    return n


def open_drain_for(db, pod_id: str, *, now: Optional[datetime] = None) -> Optional[Dict[str, Any]]:
    """The applied, unexpired drain of this pod, if any -- what keeps the
    draining flag up across cycles and lifts it on expiry / undrain."""
    now = now or datetime.now(timezone.utc)
    from core.component_health.rules import parse_ts
    drains = [i for i in db.list_component_intents(status=[INTENT_PENDING, INTENT_APPLIED])
              if i["control"] in (CONTROL_DRAIN, CONTROL_UNDRAIN) and i["target_pod_id"] == pod_id]
    drains.sort(key=lambda i: i["id"])
    latest = drains[-1] if drains else None
    if latest is None or latest["control"] == CONTROL_UNDRAIN:
        return None
    e = parse_ts(latest.get("expires_at"))
    if e is not None and e < now:
        return None
    return latest


__all__ = ["Applier", "DRAIN_ROW_CACHE_SECONDS", "INTENT_EVENT", "IntentRefused", "apply_for_pod",
           "consequence_of", "draining_info", "effective_draining", "expire", "is_draining", "open_drain_for",
           "request", "reset_drain_cache_for_tests", "set_draining", "withdraw"]
