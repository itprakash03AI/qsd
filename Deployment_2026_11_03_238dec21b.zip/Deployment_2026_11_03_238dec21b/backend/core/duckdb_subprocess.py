"""
DuckDB Subprocess Worker — crash-isolated DuckDB execution.

DuckDB's C++ code can crash (access violation / segfault) during httpfs
extension loading or S3 operations, especially on Windows in thread-pool
threads.  A C-level crash kills the entire Python process — no try/except
can catch it.

This module runs DuckDB operations in a **child process**.  If DuckDB
crashes, only the child dies; the main backend survives and returns an
error to the client.

Usage from main.py / worker_pool:

    from core.duckdb_subprocess import run_duckdb_copy_to
    result = run_duckdb_copy_to(conn_config, tables, bucket, sql,
                                 output_path, connection_id, timeout=600)
"""

import json
import logging
import os
import subprocess
import sys
import tempfile
import time as _time

from core.s3_utilities import get_s3_access_mode

logger = logging.getLogger(__name__)

_BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class DuckDBEngineError(RuntimeError):
    """DuckDB subprocess crashed or produced no result file (not a query/SQL error or timeout).

    Only raised for process-level failures — non-zero exit code or silent crash.
    This distinct type lets callers (circuit breaker, retry logic) distinguish
    engine failures from query errors (bad SQL) or timeouts.
    """


class DuckDBQueryError(DuckDBEngineError):
    """The child exited 1 with ITS OWN verdict, and that verdict is
    request-shaped: the REQUEST failed, the engine did not.

    2026-09-26 (F2 of the brief).  ``s3_full_copy`` documents its breaker
    as "trips after N crashes, not SQL errors", but every child exit 1 was
    raised as ``DuckDBEngineError`` and recorded -- so three queries that
    each got an HTTP 403 from a MIS-TARGETED host opened the connection's
    ``duckdb_engine`` breaker for every other user, and each was retried
    once first.  A 403, a binder error or a missing key says nothing about
    the engine's health and cannot succeed on a retry.

    The classification is DECLARED, by the exception TYPE the child
    recorded (``QUERY_SHAPED_VERDICTS``), and a verdict matching one of
    ``core.s3_scan_retry.TRANSIENT_SIGNATURES`` stays an engine error so the
    subprocess route keeps the retry that class was measured to need.
    Unknown = engine error (today's behaviour): a type nobody has classified
    must not silently lose its retry.

    A SUBCLASS on purpose: every ``except DuckDBEngineError`` and every
    ``pytest.raises(DuckDBEngineError)`` still holds; only the callers that
    ASK (the breaker/retry loop in ``s3_full_copy``) treat it differently.
    """


class PresignedDownloadRefusal(RuntimeError):
    """The presigned pre-download REFUSED: more files than its declared cap.

    2026-10-02, measured live: a published API over a saved raw-SQL query
    answered ``500 "Internal server error ... contact support"`` while the
    pod's log said ``Presigned pre-download would fetch 7308 files; cap is
    200.  Narrow the query (add a partition filter or LIMIT) OR raise
    QS_PRESIGNED_MAX_FILES.``  That sentence is a CAPACITY REFUSAL with a
    remedy, written for the person who sent the query -- and it was a bare
    ``RuntimeError``, so nothing could tell it from a crash: the DuckDB
    engine breaker recorded it as an engine failure and retried it, the
    executor filed it as a failed run, and the route said "contact support".

    A distinct type, raised at the cap (``_pre_download_presigned``).  It
    crosses the process boundary by NAME -- the child records
    ``"PresignedDownloadRefusal: <sentence>"`` as its verdict and the parent
    re-raises THIS class from it (``refusal_from_child_verdict``), on both
    transports (the per-query child and the warm pool).  It is NOT a
    ``DuckDBEngineError``: it says nothing about the engine's health, so the
    breaker learns nothing from it and nothing retries it.  The HTTP answer
    is decided once, in ``api/connector_errors.py::scan_refusal_http_error``
    (422 with the sentence).  The cap itself is unchanged: it refuses, it
    never truncates.
    """


#: Child verdict TYPE -> the parent-side refusal class it is re-raised as.
#: Declared, by name: an unlisted type stays whatever it was before.
CHILD_REFUSAL_TYPES = {
    "PresignedDownloadRefusal": PresignedDownloadRefusal,
}


def refusal_from_child_verdict(verdict):
    """The typed refusal a child verdict (``"<Type>: <message>"``) carries.

    None for an empty verdict and for every type outside
    ``CHILD_REFUSAL_TYPES`` -- the caller then raises exactly what it raised
    before.  The message is the child's own sentence, unchanged.
    """
    verdict = (verdict or "").strip()
    if not verdict:
        return None
    type_name, _sep, message = verdict.partition(":")
    cls = CHILD_REFUSAL_TYPES.get(type_name.strip())
    if cls is None:
        return None
    return cls(message.strip())


#: Child exception types whose verdict is the request's, not the engine's.
#: ``type(exc).__name__`` as the child records it -- the DuckDB Python
#: package raises these as ``duckdb.<Name>``.
QUERY_SHAPED_VERDICTS = frozenset({
    "HTTPException",            # HTTP 403 / 404 / 400 from the object store
    "IOException",              # "No files found", "Could not open file"
    "BinderException",          # unknown column / function
    "ParserException",          # malformed SQL
    "CatalogException",         # unknown table / view
    "InvalidInputException",    # bad parquet / bad argument
    "ConversionException",      # a value that does not cast
    "PermissionException",
    "SyntaxException",
    "NotImplementedException",
    "OutOfRangeException",
})


def verdict_is_query_shaped(verdict: str) -> bool:
    """Is a child verdict (``"<Type>: <message>"``) the request's fault?

    False for an empty verdict, for a type outside ``QUERY_SHAPED_VERDICTS``
    and for a message matching a DECLARED transient signature (those are
    engine-layer failures a retry on a fresh process was measured to cure).
    """
    verdict = (verdict or "").strip()
    if not verdict:
        return False
    type_name = verdict.split(":", 1)[0].strip()
    if type_name not in QUERY_SHAPED_VERDICTS:
        return False
    try:
        from core.s3_scan_retry import TRANSIENT_SIGNATURES
    except Exception:                                    # pragma: no cover
        TRANSIENT_SIGNATURES = []
    low = verdict.lower()
    for sig_type, fragments, _why in TRANSIENT_SIGNATURES:
        if sig_type == type_name and all(f.lower() in low for f in fragments):
            return False
    return True
    pass


_VERDICT_TYPE_RE = None

#: Tokens that, in a child verdict of type IOException / HTTPException,
#: mean the object store could not be REACHED (as opposed to a 403/404 or a
#: missing file, which are the request's).
_TRANSPORT_VERDICT_TOKENS = (
    "could not connect", "connection refused", "connection reset",
    "timed out", "timeout was reached", "couldn't resolve host",
    "name or service not known", "temporary failure in name resolution",
    "no route to host", "ssl connect error", "http 5", "service unavailable",
    "slow down", "503", "502", "504",
)


def engine_failure_is_transport(exc: BaseException) -> bool:
    """Does this DuckDB engine failure say the SOURCE could not be reached?

    2026-10-06, measured on AWS: the owner's heavy GROUP BY failed with
    ``OutOfMemoryException`` (an engine-sized-too-small fault), the engine
    retried it once, and the two failures OPENED the connection's
    ``duckdb_engine`` breaker -- the next three queries on the S3
    connection were refused with "'duckdb_engine:conn=323' is temporarily
    unavailable ... repeated failures".  An out-of-memory, a binder error,
    an internal error or a crashed worker says nothing about the SOURCE;
    a breaker keyed on the connection may only learn from failures that do.

    True only for the transport class: what
    ``core.connectors.base.is_transient_source_failure`` calls transient
    (connect / DNS / timeout / declared transient scan signatures), or a
    child verdict of type IOException / HTTPException whose message names a
    connect-level failure or a 5xx.  Everything else -- unknown included --
    is False: it is still retried where the engine retries, it just does
    not pause the connection for every other user.
    """
    global _VERDICT_TYPE_RE
    try:
        from core.connectors.base import is_transient_source_failure
        if is_transient_source_failure(exc):
            return True
    except Exception:
        pass
    import re as _re
    if _VERDICT_TYPE_RE is None:
        _VERDICT_TYPE_RE = _re.compile(r"\b([A-Za-z]+(?:Exception|Error))\s*:\s*(.*)",
                                       _re.S)
    m = _VERDICT_TYPE_RE.search(str(exc) or "")
    if not m:
        return False
    vtype, msg = m.group(1), m.group(2).lower()
    if vtype in ("IOException", "HTTPException"):
        return any(tok in msg for tok in _TRANSPORT_VERDICT_TOKENS)
    try:
        from core.s3_scan_retry import TRANSIENT_SIGNATURES
        for sig_type, fragments, _why in TRANSIENT_SIGNATURES:
            if sig_type == vtype and all(f.lower() in msg for f in fragments):
                return True
    except Exception:
        pass
    return False


def _decode_subprocess_exit(returncode: int) -> str:
    """BF-531 (2026-05-28): translate the subprocess exit code into an
    actionable diagnostic string.  Without this, operators reading the
    log see "exit code -9" with no idea what killed the process — and
    the user-facing error is a generic 500.

    On POSIX, negative return codes mean the process was killed by a
    signal: ``-9`` = SIGKILL (OOM-killer is the canonical cause when
    DuckDB doesn't honour its own memory_limit), ``-15`` = SIGTERM.
    On Windows, exit codes follow NTSTATUS conventions.
    """
    if returncode == 0:
        return "exit 0 but no result file (silent crash mid-write)"
    if os.name == "posix" and returncode < 0:
        sig = -returncode
        if sig == 9:
            return ("SIGKILL (-9) — most likely OOM-killed by the cgroup. "
                    "Check pod memory limit vs DuckDB memory_limit setting.")
        if sig == 11:
            return "SIGSEGV (-11) — DuckDB segfault.  Possible cause: bad parquet file or DuckDB bug."
        if sig == 15:
            return "SIGTERM (-15) — process group terminated (cancel/timeout)."
        if sig == 6:
            return "SIGABRT (-6) — DuckDB aborted internally (assertion failure)."
        return f"signal {sig}"
    if returncode == 1:
        # 2026-08-19 — exit 1 was the ONLY common code with no diagnosis, so
        # it rendered as the tautology "crashed (exit code 1, exit code 1)".
        # It is not a crash at all: it is the child's top-level handler
        # reporting a query error it already wrote to the result file.
        return ("exit 1 — query error reported by the subprocess driver "
                "(the cause is the message above, from the child itself)")
    if returncode == 3:
        return "exit 3 — Python uncaught exception in subprocess driver"
    # Windows-specific common codes (NTSTATUS).
    if returncode == -1073741819:  # 0xC0000005
        return "STATUS_ACCESS_VIOLATION (Windows) — segfault analog"
    if returncode == -1073741676:  # 0xC0000094
        return "STATUS_INTEGER_DIVIDE_BY_ZERO (Windows)"
    return f"exit code {returncode}"


def _record_crash_to_db(execution_id, connection_id, returncode,
                          cause, stderr_tail, wall_seconds) -> None:
    """BF-541 (2026-05-28): persist a subprocess crash event.

    Pure telemetry — must NEVER raise.  Failures degrade to a debug
    log so the recovery / fallback path is never blocked on a DB
    hiccup.
    """
    try:
        from core.connection_manager import get_connection_manager
        cm = get_connection_manager()
        if not (cm and getattr(cm, "db", None)):
            return
        import socket as _sock
        pod_id = os.environ.get("HOSTNAME") or _sock.gethostname()
        cm.db.record_duckdb_subprocess_crash(
            execution_id=execution_id,
            pod_id=pod_id,
            connection_id=connection_id,
            returncode=returncode,
            cause=cause,
            stderr_tail=stderr_tail,
            wall_seconds=wall_seconds,
        )
    except Exception as _rec_exc:
        import logging as _l
        _l.getLogger(__name__).debug(
            "BF-541 record_crash_to_db failed (non-fatal): %s", _rec_exc)


def _kill_subprocess_tree(proc, force: bool = False) -> None:
    """BF-530 (2026-05-28): kill the whole process group (POSIX) or job
    object (Windows) instead of just the immediate child.  Without this,
    DuckDB's httpfs/boto3 grandchildren outlive the parent — holding
    file descriptors and S3 connections until the kernel TCP timeout
    finally GCs them.  Under load this saturates the connection pool
    and stalls every subsequent query.

    Two-phase:
      1. SIGTERM (Unix) / CTRL_BREAK (Windows) — graceful, lets
         DuckDB flush spill files + close S3 sessions.
      2. SIGKILL after a short grace — force-terminate if step 1 didn't
         take.  ``force=True`` skips straight to step 2.

    Never raises — failures degrade to "best effort" so the caller
    isn't blocked on an undead process.
    """
    if proc is None or proc.poll() is not None:
        return
    try:
        import logging as _kl
        _klog = _kl.getLogger(__name__)
        if os.name == "posix":
            import signal
            try:
                pgid = os.getpgid(proc.pid)
            except ProcessLookupError:
                return
            if not force:
                try:
                    os.killpg(pgid, signal.SIGTERM)
                    return
                except ProcessLookupError:
                    return
                except Exception as _term_exc:
                    # SIGTERM failed (rare — permission / race).  Falls
                    # through to SIGKILL below.
                    _klog.debug(
                        "BF-530 SIGTERM to pgid=%s failed: %s — escalating to SIGKILL",
                        pgid, _term_exc)
            try:
                os.killpg(pgid, signal.SIGKILL)
            except (ProcessLookupError, OSError) as _kill_exc:
                # Process already gone or kernel refused — nothing more
                # we can do, but log so ops can see the pattern.
                _klog.debug("BF-530 SIGKILL to pgid=%s no-op: %s",
                            pgid, _kill_exc)
        else:
            # Windows.  CTRL_BREAK to the group, then TerminateProcess.
            import signal
            if not force:
                try:
                    proc.send_signal(getattr(signal, "CTRL_BREAK_EVENT", 0))
                    return
                except Exception as _ctrl_exc:
                    _klog.debug(
                        "BF-530 CTRL_BREAK_EVENT failed: %s — escalating to TerminateProcess",
                        _ctrl_exc)
            try:
                proc.kill()
            except OSError as _wkill_exc:
                _klog.debug("BF-530 Windows kill no-op: %s", _wkill_exc)
    except Exception as exc:
        # Never block on undead processes.
        import logging as _l
        _l.getLogger(__name__).debug(
            "BF-530 kill_subprocess_tree failed (pid=%s): %s",
            getattr(proc, "pid", "?"), exc)


def _attribute_child_latency(timing: dict, wall_elapsed: float) -> None:
    """Phase 164 — split the DuckDB child's coarse timings into the
    per-query latency-breakdown stages so the operator can tell S3-byte
    time, per-query cold start, and real compute apart (instead of the
    whole subprocess wall landing in ``compute``).

    Mapping (child timing dict -> stage):
      * ``spawn_s`` + ``init_s`` + ``creds_s`` -> ``coldstart`` —
        interpreter spawn + child module imports (spawn_s, 2026-08-22),
        ``import duckdb``, connect, ``LOAD httpfs``, S3 endpoint/cred/SSL
        setup: the fixed per-query tax a warm subprocess pool eliminates.
      * ``setup_s``              -> ``s3`` — predownload of parquet bytes
        (+ CREATE VIEW).  The dominant cost on the LOCAL_FILES path.
      * ``query_s``              -> ``compute`` — the real COPY-TO scan.

    Residual (IPC + result-file read; before 2026-08-22 also the whole
    spawn+boot span) auto-folds into
    ``other`` via emit_breakdown's finalize.  Fail-open — a broken
    stopwatch must never break the query.  No-op when no breakdown is
    active (background jobs / smoke scripts / admin sync).
    """
    try:
        from core.brain_latency_breakdown import record_stage as _rec
    except Exception:                                                 # pragma: no cover
        return
    try:
        init_s = float(timing.get("init_s", 0) or 0)
        creds_s = float(timing.get("creds_s", 0) or 0)
        setup_s = float(timing.get("setup_s", 0) or 0)
        query_s = float(timing.get("query_s", 0) or 0)
        spawn_s = float(timing.get("spawn_s", 0) or 0)
    except Exception:                                                 # pragma: no cover
        # Malformed timing dict from an older/other child — fall back to
        # whole-wall compute so time isn't lost.
        _rec("compute", wall_elapsed)
        return
    # 2026-08-22 — spawn_s is a CROSS-CLOCK measurement (parent time.time()
    # vs child time.time()).  Same host, so normally exact — but an NTP step
    # between the two reads could fabricate a huge value.  It can never
    # legitimately exceed the parent-observed wall for the whole call, so
    # clamp there; the child already clamped negatives to 0.
    spawn_s = min(max(0.0, spawn_s), max(0.0, wall_elapsed))
    _rec("coldstart", init_s + creds_s + spawn_s)
    _rec("s3", setup_s)
    _rec("compute", query_s)


def _prefetch_presigned_from_sql(setup_sql: str, copy_sql: str,
                                  conn_config: dict) -> None:
    """Phase 10 — PARENT-side prefetch trigger for the on-prem presigned
    path.  Extracts every presigned URL already embedded in ``setup_sql``/
    ``copy_sql`` (same regex ``_pre_download_presigned`` uses further down
    to find them once it's actually running inside the subprocess) and
    fires a cache-aware background fan-out for them, overlapped with pool
    submission / ``subprocess.Popen`` spawn.  No-op unless
    ``industrialization.local_file_cache`` is armed; never raises.
    """
    from core.onprem_file_cache import is_enabled, prefetch
    if not is_enabled():
        return
    import re as _re
    import shutil
    from urllib.parse import urlparse, urlunparse, quote
    from urllib.request import urlopen, Request

    url_re = _re.compile(r"'(https?://[^']+)'")
    urls = list(dict.fromkeys(
        url_re.findall(setup_sql or "") + url_re.findall(copy_sql or "")))
    if not urls:
        return

    from core.ssl_config import resolve_ssl, as_ssl_context
    ssl_res = resolve_ssl(conn_config.get("ssl_verify", True))
    ssl_ctx = as_ssl_context(ssl_res)

    def _fetch_fn_for(url: str):
        parsed = urlparse(url)
        canonical_path = quote(parsed.path, safe='/-._~')
        download_url = (
            urlunparse((parsed.scheme, parsed.netloc, canonical_path,
                        parsed.params, parsed.query, parsed.fragment))
            if canonical_path != parsed.path else url)

        def _do(tmp_path: str):
            from core.onprem_file_cache import FetchMeta
            req = Request(download_url, headers={"User-Agent": "QueryStudio/1.0"})
            with urlopen(req, context=ssl_ctx, timeout=120) as resp:
                etag = resp.headers.get("ETag")
                with open(tmp_path, "wb") as out:
                    shutil.copyfileobj(resp, out)
            return FetchMeta(size=os.path.getsize(tmp_path),
                              etag=(etag.strip('"') if etag else None))
        return _do

    prefetch(urls, _fetch_fn_for)


def _inner_query_from_copy(copy_sql: str) -> str:
    """Extract the inner SELECT from ``COPY (<inner>) TO '<path>' (...)``.

    Balanced-paren scan from the first ``(`` after ``COPY`` — so nested
    parentheses and subqueries inside the SELECT are handled.  Quote-aware so
    a literal ``')'`` inside a string does not terminate the scan early.

    Returns ``""`` when the statement is not a COPY of that shape (e.g. a
    ``COPY table TO ...`` form) — the caller then leaves the SQL untouched.
    """
    if not copy_sql:
        return ""
    s = copy_sql.lstrip()
    if not s[:4].upper().startswith("COPY"):
        return ""
    start = copy_sql.find("(")
    if start == -1:
        return ""
    # The paren must be the COPY *source*, i.e. everything between the COPY
    # keyword and it is whitespace.  Otherwise this is the `COPY table TO ...`
    # form and the first paren is the OPTION list -- returning that would hand
    # the caller "FORMAT PARQUET" as if it were a query.
    _kw = copy_sql.index(s[:4])
    if copy_sql[_kw + 4:start].strip():
        return ""
    depth = 0
    in_str = False
    i = start
    while i < len(copy_sql):
        ch = copy_sql[i]
        if in_str:
            if ch == "'":
                # '' is an escaped quote inside a SQL string literal
                if i + 1 < len(copy_sql) and copy_sql[i + 1] == "'":
                    i += 2
                    continue
                in_str = False
        elif ch == "'":
            in_str = True
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return copy_sql[start + 1:i].strip()
        i += 1
    return ""


def _probe_column_count(con, inner_sql: str):
    """Return the column count of ``inner_sql``, or None.

    ``LIMIT 0`` so this is planning only — DuckDB resolves the schema without
    reading row data.  Never raises.
    """
    if not inner_sql:
        return None
    try:
        cur = con.execute(f"SELECT * FROM ({inner_sql}) LIMIT 0")
        desc = getattr(cur, "description", None)
        if desc:
            return len(desc)
    except Exception:
        return None
    return None


def _inject_copy_option(copy_sql: str, clause: str) -> str:
    """Insert ``clause`` (e.g. ``", ROW_GROUP_SIZE 17000"``) into the COPY
    option list — immediately before the FINAL closing paren.

    Returns ``""`` when the shape is unexpected, so the caller keeps the
    original SQL rather than emitting something malformed.
    """
    if not copy_sql or not clause:
        return ""
    # 2026-07-31 audit fix (F1): tolerate a TRAILING SEMICOLON (and trailing
    # whitespace).  multi_worker_executor.py:1536 builds
    # ``COPY (...) TO '...' (FORMAT 'parquet', COMPRESSION 'zstd');`` -- with
    # the semicolon this returned "" and the width-aware row-group fix
    # SILENTLY did not apply to the per-worker partial writes, which is very
    # likely the path that actually OOM'd (the 900-column aggregate
    # decomposition).  The original tests all used unterminated statements, so
    # nothing caught it.
    stripped = copy_sql.rstrip()
    trailer = copy_sql[len(stripped):]          # whitespace we must re-append
    while stripped.endswith(";"):
        trailer = ";" + trailer
        stripped = stripped[:-1].rstrip()
    if not stripped.endswith(")"):
        return ""
    idx = stripped.rfind(")")
    if idx == -1:
        return ""
    return stripped[:idx] + clause + stripped[idx:] + trailer


class _PipePump:
    """P5 (2026-08-04) — LIVE child-pipe drain.

    Before this, the child's stderr reached the parent only after
    ``proc.communicate()`` returned — i.e. after the query ENDED — so
    mid-query questions ("is it spilling? did the width clause apply?")
    were unanswerable from the parent log.  A pump thread reads the pipe
    line-by-line as the child writes it, logs each line immediately
    (``live=True``), and keeps the bytes so post-exit error reporting sees
    exactly what ``communicate()`` would have returned.  Draining also
    prevents the classic full-pipe deadlock without ``communicate``.
    """

    # Retention bounds for the in-memory copy of the child's output.
    #
    # 2026-08-04: `_chunks` was an UNBOUNDED list, so the parent's memory grew
    # with however much the child chose to print -- and this child is chatty
    # (per-stage SUBPROCESS: lines, spill attribution, and loop_watchdog's
    # all-thread stack dump).  Measured: test_duckdb_subprocess.py went from
    # 139 MB to >12 GB and was still climbing when killed.
    #
    # Dropping the OLDEST lines is the right direction: post-mortem error
    # reporting wants the output nearest the failure.  Nothing is lost from
    # the LOG either way -- live=True already emitted every line as it
    # arrived; this bounds only what is replayed to the caller.
    _MAX_RETAINED_LINES = 20_000
    _MAX_RETAINED_BYTES = 8 * 1024 * 1024

    def __init__(self, pipe, tag: str, live: bool = True) -> None:
        import threading as _thr
        from collections import deque as _deque
        self._pipe = pipe
        self._chunks = _deque()
        self._retained_bytes = 0
        self._dropped_lines = 0
        self._tag = tag
        self._live = live
        self._thread = _thr.Thread(
            target=self._run, name=f"qs-duckdb-{tag}-pump", daemon=True)
        self._thread.start()

    def _run(self) -> None:
        try:
            for raw in iter(self._pipe.readline, b""):
                if not isinstance(raw, (bytes, bytearray)):
                    # `iter(f.readline, b"")` stops only on an EXACT b""
                    # match, so anything non-bytes (a text-mode pipe, or a
                    # test double whose readline returns the same object
                    # forever) makes this loop non-terminating -- in a daemon
                    # thread, which keeps spinning and allocating for the rest
                    # of the process's life.  Stop instead.
                    logger.debug(
                        "pipe pump (%s) stopping: readline returned %s, "
                        "not bytes", self._tag, type(raw).__name__)
                    break
                self._chunks.append(raw)
                self._retained_bytes += len(raw)
                while (len(self._chunks) > self._MAX_RETAINED_LINES
                       or self._retained_bytes > self._MAX_RETAINED_BYTES):
                    dropped = self._chunks.popleft()
                    self._retained_bytes -= len(dropped)
                    self._dropped_lines += 1
                if self._live:
                    try:
                        line = raw.decode("utf-8", "replace").rstrip()
                        if line:
                            logger.info("[duckdb-child] %s", line)
                    except Exception:
                        logger.debug("child line decode failed",
                                     exc_info=True)
        except Exception as exc:
            logger.debug("pipe pump (%s) stopped: %s", self._tag, exc)
        finally:
            try:
                self._pipe.close()
            except OSError:
                pass

    def data(self, join_timeout: float = 5.0) -> bytes:
        try:
            self._thread.join(timeout=join_timeout)
        except Exception:
            logger.debug("pipe pump (%s) join failed", self._tag,
                         exc_info=True)
        body = b"".join(self._chunks)
        if self._dropped_lines:
            # NEVER truncate silently: a caller reading this to explain a
            # failure must know it is not the complete stream.
            body = (
                b"[qs] NOTE: " + str(self._dropped_lines).encode()
                + b" earlier line(s) of child output were dropped -- retention"
                b" bound reached; the full stream was logged live.\n"
            ) + body
        return body


def _dir_bytes(path: str) -> int:
    """Best-effort recursive byte count of ``path``.  0 on any error."""
    total = 0
    try:
        for root, _dirs, files in os.walk(path):
            for name in files:
                try:
                    total += os.path.getsize(os.path.join(root, name))
                except OSError:
                    continue
    except OSError:
        return 0
    return total


def _start_spill_attribution(spill_dir: str, quota_bytes: int,
                             output_path: str, phase_ref: dict):
    """P1c (2026-08-04) — SPILL ATTRIBUTION.  Background sampler that
    watches THIS query's private spill dir and says out loud — while the
    query is still running — which phase is spilling and how much, next to
    how many output bytes exist.  This is the line whose absence turned the
    40 GB incident into a 6-hour misdiagnosis: the temp volume filled and
    nothing distinguished "DuckDB out-of-core scratch" (expected for a
    17M x 900 result) from "downloader copying files" (never ran).

    Emits a ``[GATE] WARN spill.growth`` line to stderr at 1 GiB, then at
    every further 4 GiB step — stderr is streamed live to the parent log,
    so the operator sees it mid-query, not post-mortem.  Returns
    ``(stop_event, hiwater_ref)``; the thread is a daemon and never blocks
    exit.  Any internal error stops the sampler silently — telemetry must
    never fail a query.
    """
    import threading as _thr
    stop_evt = _thr.Event()
    hiwater = {"bytes": 0}

    _FIRST_STEP = 1 * 1024 ** 3
    _STEP = 4 * 1024 ** 3

    def _fmt(n: int) -> str:
        try:
            from core.log_style import human_bytes as _hb
            return _hb(n) or "0B"
        except Exception:
            return f"{n}B"

    def _run() -> None:
        next_report = _FIRST_STEP
        try:
            from core.log_style import gate_line as _gl
        except Exception:
            _gl = None
        while not stop_evt.wait(5.0):
            try:
                cur = _dir_bytes(spill_dir)
                if cur > hiwater["bytes"]:
                    hiwater["bytes"] = cur
                if cur < next_report:
                    continue
                next_report = cur + _STEP
                try:
                    out_b = (os.path.getsize(output_path)
                             if os.path.exists(output_path) else 0)
                except OSError:
                    out_b = 0
                detail = ("DuckDB out-of-core scratch for THIS query "
                          "(NOT a download)")
                if out_b <= 0:
                    detail += ("; output still 0B -- an operator is "
                               "buffering the result before emitting "
                               "(hash build side / blocking plan)")
                fields = {
                    "phase": phase_ref.get("phase", "?"),
                    "spill": _fmt(cur),
                    "quota": _fmt(quota_bytes) if quota_bytes > 0 else "?",
                    "output": _fmt(out_b) if out_b > 0 else "0B",
                    "dir": spill_dir,
                }
                if _gl is not None:
                    line = _gl("spill.growth", "WARN", detail, **fields)
                else:
                    kv = " ".join(f"{k}={v}" for k, v in fields.items())
                    line = f"[GATE] WARN  spill.growth {kv} -- {detail}"
                print(f"SUBPROCESS: {line}", file=sys.stderr, flush=True)
            except Exception:
                return  # sampler must never hurt the query
    t = _thr.Thread(target=_run, name="qs-spill-attribution", daemon=True)
    t.start()
    return stop_evt, hiwater


def _spill_preflight_mode() -> str:
    """BF-543 reconciliation (2026-08-02) — ``"degrade"`` or ``"block"``.

    The original pre-flight REFUSED every new spawn while the spill dir
    sat under the free-space floor.  On a pod whose children spill hard
    (the memory-composition work deliberately shrinks per-child memory
    under concurrency, so spilling INCREASES), one long-running spiller
    could hold the dir low for minutes and wedge the whole pod — every
    new query failed at spawn, including ones that never spill.

    Default is now ``degrade``: the caller logs a warning and spawns
    anyway.  The child sizes ``max_temp_directory_size`` from the same
    (low) free-space reading, so THIS query gets a small spill budget and
    fails alone if it genuinely needs more — and its temp_directory
    fallback chain still guarantees a writable dir (a memory limit with
    nowhere to spill turns "uses more RAM" into "query fails").

    ``DUCKDB_SPILL_PREFLIGHT_HARD=1`` restores the old hard refusal for
    operators who prefer fail-fast admission over degraded execution.
    Never raises.
    """
    try:
        raw = os.environ.get("DUCKDB_SPILL_PREFLIGHT_HARD", "").strip()
        if raw.lower() in ("1", "true", "yes", "on"):
            return "block"
    except Exception as exc:                                 # pragma: no cover
        logger.debug("BF-543 pre-flight mode read failed: %s", exc)
    return "degrade"


def _progressive_list_parts(parts_dir: str) -> list:
    """Return the DuckDB COPY part files in ``parts_dir`` as absolute
    paths in NUMERIC index order (``data_0.parquet``, ``data_1.parquet``,
    …).  Raises when no parts exist or the index sequence has a gap —
    a gap would silently drop rows from the middle of the result."""
    import re as _re
    pairs = []
    for name in os.listdir(parts_dir):
        m = _re.match(r"^data_(\d+)\.parquet$", name)
        if m:
            pairs.append((int(m.group(1)), name))
    if not pairs:
        raise RuntimeError(f"no COPY part files found in {parts_dir}")
    pairs.sort()
    idxs = [i for i, _ in pairs]
    if idxs != list(range(len(idxs))):
        raise RuntimeError(
            f"non-contiguous COPY part indexes in {parts_dir}: {idxs}")
    return [os.path.join(parts_dir, name) for _, name in pairs]


def _progressive_concat_parts(parts_dir: str, dest_path: str) -> int:
    """Streaming concat of the COPY parts into ONE parquet file.

    ParquetFile.iter_batches → a single ParquetWriter: peak memory is
    O(one batch), NEVER O(result) — no pq.read_table of everything.
    Row order = part-index order, then each part's own order.  That is
    the order the parts HOLD, which is NOT a query's ORDER BY order:
    DuckDB writes a FILE_SIZE_BYTES COPY through its parallel sink and
    interleaves rows across threads even inside one part (measured,
    1.5.3, 2026-10-06).  ``progressive_results.plan_copy_rewrite``
    therefore never arms the spool for a statement carrying ORDER BY /
    LIMIT / OFFSET / FETCH (``copy_order_refusal``); for the unordered
    statements it does arm, any order is the statement's answer.
    Column order + types come from part 0's arrow schema (all parts were
    written by the same COPY, so they are identical; a mismatch raises
    rather than silently casting).  Row-group size reuses the
    width-aware formula (core.parquet_write_opts.row_group_rows_for_width)
    with DuckDB's COPY default as the clamp, matching what the canonical
    single-file COPY would have produced.

    Returns total rows written.  ``dest_path`` should be a TEMP path the
    caller atomically ``os.replace``s into place — this function does
    not make the write atomic itself."""
    import pyarrow.parquet as _pq
    part_paths = _progressive_list_parts(parts_dir)
    pf0 = _pq.ParquetFile(part_paths[0])
    try:
        schema = pf0.schema_arrow
    finally:
        pf0.close()
    from core.parquet_write_opts import (
        DUCKDB_DEFAULT_ROW_GROUP_ROWS,
        row_group_rows_for_width,
    )
    rg_rows = row_group_rows_for_width(
        len(schema.names), max_rows=DUCKDB_DEFAULT_ROW_GROUP_ROWS)
    total = 0
    writer = _pq.ParquetWriter(dest_path, schema, compression="zstd")
    try:
        for path in part_paths:
            pf = _pq.ParquetFile(path)
            try:
                if pf.schema_arrow != schema:
                    raise RuntimeError(
                        f"COPY part {os.path.basename(path)} schema differs "
                        f"from part 0 — refusing to concat")
                for batch in pf.iter_batches(batch_size=rg_rows):
                    if batch.num_rows == 0:
                        continue
                    writer.write_batch(batch)
                    total += batch.num_rows
            finally:
                pf.close()
    finally:
        writer.close()
    return total


class _StreamingMachineryError(Exception):
    """P3 — an error in OUR streaming writer/tee machinery (not the query).
    The caller falls back to the canonical COPY; a genuine query error
    propagates as-is because the canonical COPY would fail identically."""


def _try_streaming_arrow_copy(con, inner_sql: str, output_path: str,
                              parts_dir: str, execution_id: str,
                              width_hint: int, sidecar_register,
                              temp_files: list, phase_ref: dict):
    """P3 (2026-08-04) — TRUE incremental delivery for the COPY subprocess
    path: rows reach the grid as DuckDB produces them, not after the full
    result is on disk.

    ``fetch_record_batch`` (the same mechanism the local-file raw-SQL path
    has used since ``api/execute_api.py:5287``) pulls Arrow batches out of
    the running query; each batch is (a) appended to the canonical single
    parquet file via a width-aware ParquetWriter and (b) teed into the
    progressive spool as SEALED segments + atomic manifest — segment #1
    seals after ``first_segment_rows`` (~4 MB), so page 1 lights up in
    seconds instead of after the last of tens of GB.

    Contract preservation:
      * crash isolation — still entirely inside the DuckDB child process;
      * exports — the canonical ``<execution_id>.parquet`` is still written,
        atomically (`os.replace`), with width-aware row groups;
      * cancel — parent SIGTERM/SIGKILL still stops the child; the tmp file,
        spool dir and spill dir are sidecar-registered so the parent's
        BF-542 drain reclaims them;
      * a partial stream can NEVER present as complete — segments serve only
        while the DB row is in a running state and the manifest has no
        "complete" state at all (see progressive_results docstring); the
        canonical file appears only via the final atomic replace;
      * completeness certificate / scan ledger — unchanged: same single
        output file, same result JSON, same row count read from its footer.

    Returns total rows written on success, ``None`` on refusal (caller runs
    the canonical COPY, byte-for-byte today's path).  Machinery errors
    (pyarrow writer, spool I/O) clean up and return ``None``; QUERY errors
    propagate unchanged.
    """
    _t0 = _time.monotonic()
    try:
        from core import progressive_results as _prog
        if not (inner_sql and parts_dir and output_path):
            return None
        if not _prog.is_enabled() or not _prog.arrow_stream_enabled():
            return None
        if not _prog.should_stream_plan(inner_sql):
            print("SUBPROCESS: [GATE] SKIP  stream.arrow -- blocking plan "
                  "(ORDER BY/GROUP BY/DISTINCT/window): nothing can be "
                  "emitted before the query finishes; native COPY parts "
                  "still tail", file=sys.stderr, flush=True)
            return None
        if not execution_id:
            # Older parent payload — the spool dir is keyed on the id.
            _base = os.path.basename(parts_dir.rstrip("/\\"))
            execution_id = _base[:-len("__segments")] \
                if _base.endswith("__segments") else ""
            if not execution_id:
                return None
        import pyarrow as _pa
        import pyarrow.parquet as _pq
        from pathlib import Path as _Path
        from core.parquet_write_opts import (
            DUCKDB_DEFAULT_ROW_GROUP_ROWS as _rg_max,
            row_group_rows_for_width as _rg_rows_for,
        )
    except Exception as _st_setup_exc:
        print(f"SUBPROCESS: streaming lane unavailable (fail-open -> "
              f"canonical COPY): {_st_setup_exc}", file=sys.stderr,
              flush=True)
        return None

    tee = None
    writer = None
    tmp_out = output_path + ".streaming_tmp.parquet"
    try:
        # ── query side (errors PROPAGATE from here) ──────────────────────
        res = con.execute(inner_sql)
        ncols = len(res.description or []) or int(width_hint or 0)
        batch_rows = max(1024, _prog.first_segment_rows(ncols or None))
        # 2026-08-04 — fetch_record_batch(rows_per_batch=) is deprecated in
        # duckdb 1.5; to_arrow_reader(batch_size=) returns the SAME
        # pyarrow.RecordBatchReader (batch sizing and INTERRUPT-on-abort
        # semantics verified identical, see
        # tests/test_progressive_copy_path_2026_07_31.py's interrupt case).
        reader = res.to_arrow_reader(batch_size=batch_rows)

        # ── machinery side (errors -> fallback) ──────────────────────────
        try:
            schema = reader.schema
            ncols = len(schema.names) or ncols
            rg_rows = _rg_rows_for(ncols, max_rows=_rg_max)
            sidecar_register(tmp_out)
            temp_files.append(tmp_out)
            tee = _prog.SegmentedResultTee(
                execution_id, _Path(parts_dir),
                first_seg_rows=_prog.first_segment_rows(ncols))
            sidecar_register(parts_dir)
            writer = _pq.ParquetWriter(tmp_out, schema, compression="zstd")
        except Exception as _mach_exc:
            raise _StreamingMachineryError(str(_mach_exc)) from _mach_exc

        print(f"SUBPROCESS: [GATE] PASS  stream.arrow columns={ncols} "
              f"batch_rows={batch_rows} row_group={rg_rows} -- rows flow "
              f"to the grid AS PRODUCED (canonical file still written)",
              file=sys.stderr, flush=True)

        total = 0
        pending = []          # accumulated batches, flushed per row group
        pending_rows = 0
        last_note = _t0

        def _flush():
            nonlocal pending, pending_rows
            if not pending:
                return
            tbl = _pa.Table.from_batches(pending, schema=schema)
            try:
                writer.write_table(tbl, row_group_size=rg_rows)
            except Exception as _w_exc:
                raise _StreamingMachineryError(str(_w_exc)) from _w_exc
            tee.write(tbl)     # never raises (self-disarming)
            pending = []
            pending_rows = 0

        # 2026-08-04 — the comment here used to read "query errors
        # propagate".  They do not, usefully: DuckDB aborts a streaming
        # result by INTERRUPTING the Arrow reader, so pyarrow raises
        # `OSError: INTERRUPT Error: Interrupted!` and the REAL cause --
        # e.g. `Conversion Error: could not convert 'boom' to INT` -- never
        # reaches the operator.  "Interrupted" reads as "somebody cancelled
        # me", which sends the user looking in exactly the wrong place for a
        # data defect in their own query.
        #
        # Treat it as a machinery failure so the canonical COPY re-executes
        # and raises DuckDB's genuine message.  This cannot mask a real
        # cancellation: cancel is enforced by the PARENT killing this
        # process group (BF-530), so a cancelled child never reaches here.
        _it = iter(reader)
        while True:
            try:
                batch = next(_it)
            except StopIteration:
                break
            except Exception as _rd_exc:
                if "INTERRUPT" in str(_rd_exc).upper():
                    raise _StreamingMachineryError(
                        f"streaming reader interrupted ({_rd_exc}) -- "
                        f"re-running canonically to surface the real error"
                    ) from _rd_exc
                raise
            if batch.num_rows == 0:
                continue
            pending.append(batch)
            pending_rows += batch.num_rows
            total += batch.num_rows
            if pending_rows >= rg_rows:
                _flush()
            now = _time.monotonic()
            if now - last_note >= 5.0:
                last_note = now
                print(f"SUBPROCESS: streaming {total:,} rows "
                      f"(sealed for grid: {tee.total_sealed_rows:,}) "
                      f"[{now - _t0:.0f}s]", file=sys.stderr, flush=True)
        _flush()
        try:
            writer.close()
            writer = None
            os.replace(tmp_out, output_path)
        except Exception as _fin_exc:
            raise _StreamingMachineryError(str(_fin_exc)) from _fin_exc
        print(f"SUBPROCESS: [GATE] PASS  stream.finish rows={total:,} "
              f"[{_time.monotonic() - _t0:.0f}s] -- canonical file "
              f"atomically in place", file=sys.stderr, flush=True)
        return total
    except _StreamingMachineryError as _sm_exc:
        print(f"SUBPROCESS: streaming machinery failed ({_sm_exc}) -- "
              f"falling back to canonical COPY (query re-executes; reads "
              f"are idempotent)", file=sys.stderr, flush=True)
        return None
    finally:
        if writer is not None:
            try:
                writer.close()
            except Exception:
                logger.debug("streaming writer close failed (tmp is "
                             "sidecar-registered)", exc_info=True)
        if tee is not None:
            tee.close_and_cleanup()
        try:
            if os.path.exists(tmp_out) and not os.path.exists(output_path):
                os.unlink(tmp_out)
        except OSError:
            pass


def _remote_io_hint_for(setup_sql: str, copy_sql: str,
                        concurrent_children) -> "dict | None":
    """2026-10-06 -- what the CHILD needs for the remote-I/O decision and
    cannot know itself: this dispatch's fan-out (its share of the per-query
    budget) and the sizes the pruner measured for the files it will read
    (``core.measured_file_bytes`` lives in the parent).  ``None`` when the
    child is alone and nothing is measured.  Never raises."""
    try:
        share = max(1, int(concurrent_children or 0))
    except (TypeError, ValueError):
        share = 1
    hint: dict = {}
    if share > 1:
        hint["share"] = share
    try:
        from core.measured_file_bytes import bytes_for_uris
        from core.s3_http_transport import remote_file_uris
        mb = bytes_for_uris(remote_file_uris(setup_sql, copy_sql))
        if mb.known_files > 0:
            hint.update(files=mb.files, known_files=mb.known_files,
                        known_bytes=mb.known_bytes, max_bytes=mb.max_bytes)
    except Exception as exc:                          # noqa: BLE001
        logger.debug("[remote-io] hint skipped (non-fatal): %s", exc)
    return hint or None


def _pool_for_run(execution_id):
    """``(pool, PoolUnavailable)`` for THIS run: the warm pool when it is
    enabled and the run carries no query-pod reservation, else ``(None,
    Exception)``.

    2026-10-31: a run with a RESERVATION (core/query_pods/budget.py) never
    rides the warm pool -- a pooled worker's memory_limit was fixed when it
    was spawned (the pod share), and the run's limit must be ITS
    reservation.  The per-run spawn (forkserver or cold) is told the
    reservation; the pool stays the fast path for unreserved runs.  Any
    error reads as "no pool" (the legacy path can never be lost)."""
    try:
        from core.duckdb_worker_pool import (
            is_enabled as _pool_enabled,
            get_pool as _get_pool,
            PoolUnavailable as _PoolUnavailable,
        )
        if not _pool_enabled():
            return None, _PoolUnavailable
        from core.query_pods.budget import reservation_for as _qp_reservation
        if _qp_reservation(execution_id) > 0:
            logger.info("[query-pods] execution %s carries a reservation: the warm "
                        "pool is skipped so DuckDB gets exactly that limit",
                        execution_id or "-")
            return None, _PoolUnavailable
        return _get_pool(), _PoolUnavailable
    except Exception:
        return None, Exception


def run_duckdb_copy_to(
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    setup_sql: str,
    copy_sql: str,
    output_path: str,
    connection_id: int = None,
    timeout: int = 600,
    execution_id: str = None,
    cancel_event=None,
    concurrent_children: int = 0,
) -> dict:
    """Run a DuckDB COPY TO query in a child process.

    BF-558d: ``concurrent_children`` is how many DuckDB children this
    dispatch runs at once.  Passed EXPLICITLY rather than read from the
    process-global ``QS_DUCKDB_CONCURRENT_CHILDREN``, because that global
    races: two concurrent multi-worker dispatches overwrite each other's
    stamp, and whichever finishes first restores its own previous value
    while the other is still spawning.  0 = fall back to the global
    (unchanged behaviour for callers that do not pass it).

    Returns dict with keys: total_rows, file_size_bytes, timing
    Raises RuntimeError on crash or timeout.

    BF-PRUNE-PERF-LOG: when execution_id is given, emits periodic stage
    signals + log lines so the heartbeat heard by the user reflects
    "still in DuckDB subprocess, Ns elapsed" instead of a silent gap
    that looks like the entire query is dead.
    """
    wall_start = _time.monotonic()
    # 2026-10-06 -- the child's inputs to the remote-I/O decision (see its
    # "Remote I/O concurrency" block): how many children THIS dispatch runs
    # (its share of the per-query budget) and what the parent MEASURED
    # about the files (the per-file sizes live in this process only).
    # ``None`` when there is nothing to say, so the common payload stays
    # byte-identical.
    _remote_io_hint = _remote_io_hint_for(setup_sql, copy_sql,
                                          concurrent_children)
    # Phase 164 — exactly-once latency-stage attribution.  Set True once
    # the success path splits the child's timings into coldstart/s3/
    # compute; the finally records a whole-wall fallback if we exited
    # before that (crash / timeout).
    _latency_attributed = False

    # Phase 10 — prefetch pipelining (industrialization.local_file_cache,
    # default OFF).  setup_sql/copy_sql already carry every presigned URL
    # this query needs; kick a cache-aware background fan-out for them NOW
    # so the downloads overlap pool submission / subprocess spawn +
    # interpreter startup + extension load, instead of serialising
    # entirely after it.  Fail-open + fire-and-forget: never raises, never
    # blocks this call — the subprocess's own _pre_download_presigned (or
    # the pooled worker's) always runs afterward regardless and is itself
    # cache-aware, so a prefetch miss just means "no speedup this time".
    try:
        if get_s3_access_mode(conn_config) == "presigned":
            _prefetch_presigned_from_sql(setup_sql, copy_sql, conn_config)
    except Exception as _pf_exc:
        logger.debug("[onprem-cache] prefetch trigger skipped: %s", _pf_exc)

    # ── Progressive COPY delivery (2026-07-31; default ON since 2026-08-02) ──
    # progressive_results.plan_copy_rewrite retargets the COPY from the
    # single output file to `<spool>/<execution_id>__segments/` with
    # FILE_SIZE_BYTES, so DuckDB emits sequentially-finalised parts; the
    # parent tails them into the progressive manifest on every wait slice
    # (``_progress_tick`` below) and the CHILD concats them back into the
    # canonical single file at the end.
    #
    # 2026-09-25 -- armed BEFORE the warm-pool attempt.  This block used to
    # sit after it, on the reasoning that "the pool is default OFF anyway";
    # the pool has been ON by default since 2026-08-22, so every query went
    # to the pool with the canonical single-file COPY and progressive
    # delivery never ran in production.  BOTH transports now carry the same
    # armed SQL + parts dir (the child side is path-agnostic: the pool
    # worker loop runs the same _child_main), and a PoolUnavailable
    # fall-through reuses THIS arming -- one plan, one spool, one execution.
    # Flag OFF → plan_copy_rewrite returns None after one config read and
    # everything below is byte-for-byte the canonical behaviour.
    _prog_parts_dir = None
    _prog_fallback_sql = None
    _prog_tailer = None
    try:
        from core import progressive_results as _prog_mod
        _prog_plan = _prog_mod.plan_copy_rewrite(
            copy_sql, output_path, execution_id)
        if _prog_plan:
            _prog_fallback_sql = copy_sql
            copy_sql, _prog_parts_dir = _prog_plan
            _prog_tailer = _prog_mod.CopyPartTailer(
                execution_id, _prog_parts_dir)
            logger.info(
                "[progressive] COPY armed for %s: parts dir %s "
                "(FILE_SIZE_BYTES rewrite; child concats back to the "
                "canonical single file)", execution_id, _prog_parts_dir)
            # P5 — greppable decision line (spool is RESULT SEGMENTS in the
            # progressive spool dir, NOT a download).
            try:
                from core.log_style import gate as _pg_gate
                _pg_gate(logger, "progressive.arm", "PASS",
                         "result segments spool armed (not a download)",
                         exec=execution_id, dir=_prog_parts_dir)
            except Exception as _be_exc:
                note_best_effort("_pg_gate(...)", _be_exc,
                                 logger=logger)
    except Exception as _prog_exc:
        logger.warning("[progressive] arm failed (fail-open → canonical "
                       "COPY): %s", _prog_exc)
        if _prog_fallback_sql:
            copy_sql = _prog_fallback_sql
        _prog_parts_dir = None
        _prog_fallback_sql = None
        _prog_tailer = None

    def _prog_spool_cleanup():
        """Progressive COPY spool — belt-and-braces removal on EVERY exit
        path of EITHER transport.  Success: the child already concatenated
        + removed it (rmtree of a missing dir is a no-op).  Crash / timeout
        / cancel: the sidecar drain (legacy finally, or the pool worker's
        kill()) usually got it, but a pre-registration kill or an
        unwritable sidecar would otherwise leak the spool until the TTL
        sweep.  A stale manifest can never serve past this point either
        way: the DB row leaves the running state, which closes the
        serving gate."""
        if _prog_parts_dir:
            try:
                import shutil as _prog_sh
                _prog_sh.rmtree(_prog_parts_dir, ignore_errors=True)
            except Exception as _be_exc:
                note_best_effort(
                    "_prog_sh.rmtree(_prog_parts_dir, ignore_errors=True)",
                    _be_exc, logger=logger)

    # Optional stage tracker — fail-open if unavailable.  Resolved HERE,
    # ahead of the pool attempt, because the heartbeat below serves both
    # transports.
    _stg_update = None
    _stg_set = None
    if execution_id:
        try:
            from core.execution_stage import (
                update_progress as _stg_update,
                set_stage as _stg_set,
            )
        except Exception:
            _stg_update = None
            _stg_set = None

    # ── ONE progress tick for BOTH transports ──────────────────────────
    # Called on every wait slice: by the pool's wait_ack (0.5 s) and by
    # the legacy Popen poll loop (1 s).  Tails newly-sealed parts into
    # the progressive manifest (when armed) so the paginator can serve
    # page 1 while the COPY is still running, and emits the bytes-written
    # heartbeat on the coarser cadence the poll loop always used (every
    # 5 s, not every slice, so the stage tracker is not spammed).  NEVER
    # raises: progress reporting must not fail a query.
    _heartbeat_interval = 5.0
    _hb_state = {"last": 0.0}

    def _progress_tick(waited, pid=None):
        try:
            if _prog_tailer is not None:
                _prog_tailer.poll()       # never raises (self-disarming)
            if (waited - _hb_state["last"]) < _heartbeat_interval:
                return
            _hb_state["last"] = waited
            # Real progress signal: bytes already written to the output
            # parquet.  Progressive mode: DuckDB writes parts, not
            # output_path — sealed-part bytes are the real signal.
            _bytes_so_far = 0
            try:
                if os.path.exists(output_path):
                    _bytes_so_far = os.path.getsize(output_path)
                elif _prog_tailer is not None:
                    _bytes_so_far = _prog_tailer.total_sealed_bytes
            except OSError:
                _bytes_so_far = 0
            _bytes_mb = (_bytes_so_far / (1024 * 1024)
                         if _bytes_so_far else 0)
            if execution_id and _stg_update:
                try:
                    _stg_update(execution_id,
                                bytes_done=_bytes_so_far,
                                message=f"DuckDB subprocess running "
                                        f"({int(waited)}s elapsed, "
                                        f"output_bytes={_bytes_mb:.1f}MB, "
                                        f"timeout {int(timeout)}s)")
                except Exception as _be_exc:
                    note_best_effort("_stg_update(...)", _be_exc,
                                     logger=logger)
            logger.info(
                "DuckDB subprocess (pid=%s) still running after %.0fs "
                "(output=%.1fMB, timeout=%ds)",
                pid if pid is not None else "pool", waited, _bytes_mb,
                timeout,
            )
        except Exception as _tick_exc:
            note_best_effort("_progress_tick(...)", _tick_exc,
                             logger=logger)

    # Phase 168 — warm subprocess pool fast path (DEFAULT ON since
    # 2026-08-22; env kill-switch QS_DUCKDB_POOL=off).  When enabled, hand
    # the whole request to a pooled long-lived worker to skip the
    # per-query cold start.  The pool is a FAST PATH, never a hard
    # dependency: any problem (disabled, not-implemented, no healthy
    # worker, checkout timeout, import hiccup, unexpected error) falls
    # through to the legacy per-query Popen path below, so the pool can
    # never fail a query the legacy path would have run.
    _pool, _PoolUnavailable = _pool_for_run(execution_id)
    if _pool is not None:
        # Phase 3 — immutability proof for the pooled child's metadata-
        # cache policy ("auto" trusts caches only under this stamp).
        # True ONLY when every registered table on this request is
        # Iceberg — Iceberg data files are immutable by format, so a
        # cached footer/HTTP-metadata entry for their paths can never go
        # stale.  Any doubt (empty list, non-dict entry, other format)
        # proves nothing => False => the child revalidates.
        _plan_all_iceberg = False
        try:
            _plan_all_iceberg = bool(registered_tables) and all(
                isinstance(_rt, dict)
                and str(_rt.get("format", "parquet")).strip().lower()
                == "iceberg"
                for _rt in registered_tables)
        except Exception:
            _plan_all_iceberg = False
        _pool_ran = True
        try:
            # The ARMED copy_sql + parts dir ride the pool transport too
            # (2026-09-25); the pool worker runs the same _child_main, so
            # it reads the same keys the legacy payload carries below.
            return _pool.submit(
                conn_config=conn_config, registered_tables=registered_tables,
                bucket=bucket, setup_sql=setup_sql, copy_sql=copy_sql,
                output_path=output_path, connection_id=connection_id,
                timeout=timeout, execution_id=execution_id,
                cancel_event=cancel_event,
                plan_all_iceberg=_plan_all_iceberg,
                progressive_parts_dir=_prog_parts_dir,
                progressive_fallback_copy_sql=_prog_fallback_sql,
                on_tick=_progress_tick,
                **({"remote_io": _remote_io_hint} if _remote_io_hint else {}),
            )
        except _PoolUnavailable:
            # The query did NOT run on a worker (no worker free, or the
            # request frame never got sent).  Safe to fall through to the
            # legacy per-query Popen path below -- which REUSES the
            # progressive arming above (same rewritten SQL, same parts
            # dir, same tailer): no second plan, no second spool.
            _pool_ran = False
        finally:
            # Pool-served (returned, or raised AFTER the frame was sent):
            # the spool was this request's, remove it.  On the
            # PoolUnavailable fall-through it is left for the legacy path.
            if _pool_ran:
                _prog_spool_cleanup()
        # NB: ANY other exception (crash / timeout / cancel / query error
        # AFTER the frame was sent) MUST propagate -- the query may have
        # executed, so re-running it on the legacy path would be a DOUBLE
        # EXECUTION.  submit() raises PoolUnavailable ONLY pre-send, so a
        # non-PoolUnavailable error here is a real query failure, exactly
        # like a legacy subprocess crash (which also raises out of here).

    args_payload = {
        "conn_config": conn_config,
        "registered_tables": registered_tables,
        "bucket": bucket,
        "setup_sql": setup_sql,
        "copy_sql": copy_sql,
        "output_path": output_path,
        "connection_id": connection_id,
    }
    if execution_id:
        args_payload["execution_id"] = str(execution_id)
    # 2026-10-06 -- the child's remote-I/O inputs; omitted when empty.
    if _remote_io_hint:
        args_payload["remote_io"] = _remote_io_hint
    # 2026-08-04 (P1a) — width HINT for the child's ROW_GROUP_SIZE sizing.
    # The pruner stamped the island's schema column count into
    # core.s3_read_strategy one step earlier in this same call chain; hand
    # it to the child so a failed LIMIT-0 probe no longer silently reverts
    # to DuckDB's 122,880-row default (the 40 GB incident).  A hint, never
    # an authority — the child's live probe wins when it works, and a
    # wrong hint can only change row-group granularity, never correctness.
    try:
        from core.s3_read_strategy import current_island_size as _cis_hint
        _isl_hint, _ = _cis_hint()
        if int(getattr(_isl_hint, "columns", -1) or -1) > 0:
            args_payload["column_count_hint"] = int(_isl_hint.columns)
        # 2026-08-04 stage-2 admission: the island's measured size has no
        # other transport across the process boundary (contextvars do not
        # cross fork/spawn), and the CHILD is the only place the plan
        # shape and the parquet decode ratio are measurable.  Same
        # authority rule as the parent-side check: contextvar slot only,
        # and only when the size is actually known — an absent key is the
        # child's signal to render no verdict, never a zero.
        if bool(getattr(_isl_hint, "known", False)):
            args_payload["island_hint"] = {
                "bytes": int(_isl_hint.bytes_),
                "files": int(_isl_hint.files),
                "columns": int(getattr(_isl_hint, "columns", -1) or -1),
            }
    except Exception as _hint_exc:
        logger.debug("width-hint stamp skipped (non-fatal): %s", _hint_exc)
    # Progressive COPY keys — present ONLY when armed, so the flag-off
    # payload stays byte-identical to today's.
    if _prog_parts_dir:
        args_payload["progressive_parts_dir"] = _prog_parts_dir
        args_payload["progressive_fallback_copy_sql"] = _prog_fallback_sql
    # F2 (2026-07-25) — hand the parent's authoritative size/etag hints to
    # the subprocess so its on-prem cache wire site refuses stale bytes for
    # overwritten-in-place objects.  Empty (key omitted) when the cache
    # flag is off — payload byte-parity preserved.
    try:
        from core.onprem_file_cache import export_expected_meta_for_sql
        _exp_meta = export_expected_meta_for_sql(setup_sql)
        if _exp_meta:
            args_payload["onprem_expected_meta"] = _exp_meta
    except Exception as _exp_exc:
        logger.debug("onprem expected-meta export skipped (non-fatal): %s",
                     _exp_exc)

    # (The optional stage tracker -- _stg_update / _stg_set -- is resolved
    # above, ahead of the pool attempt, so one heartbeat serves both
    # transports.)

    # Write args to temp file (avoids command-line length limits)
    #
    # 2026-09-17 -- THE TEMP DIR, NOT THE SOURCE DIR.  This wrote into
    # ``_BACKEND_DIR`` (the backend package root, ``/app`` in the image), and
    # the runtime user does not own it:
    #
    #     uid 1001, /app root-owned      -> os.access(_BACKEND_DIR, W_OK) False
    #     PermissionError: [Errno 13] '/app/tmpXXXXXXXX.json'
    #
    # which failed EVERY query that goes through the DuckDB subprocess COPY
    # path -- including the whole published-API data surface
    # (/api/v1/views/{slug}/data 500s on every call).  Nothing needs the file
    # to live beside the code: the child receives an ABSOLUTE path as
    # ``sys.argv[1]``, and the result/sidecar/cleanup paths are all derived
    # from ``args_file.name``, so they follow it.
    #
    # Omitting ``dir`` uses ``tempfile.gettempdir()``, which this image
    # already points at a writable location (TMPDIR=/tmp/querystudio) and
    # which a test that redirects tempdir will also pick up.  A read-only code
    # directory is ordinary hardening, so the old placement was going to fail
    # on any such deployment, not only this one.
    args_file = tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False)
    try:
        # 2026-08-22 — spawn+boot attribution.  The child's own stopwatch
        # (_t0 at the top of _child_main) starts AFTER interpreter spawn and
        # after `python -m core.duckdb_subprocess` finishes importing, so
        # that span (measured 100-160 ms warm on a dev box, more on a
        # throttled pod) was invisible to the latency breakdown and landed
        # in `other`.  Stamp the parent wall-clock here (same host, so
        # time.time() is comparable); the child reports the delta as
        # timing.spawn_s and _attribute_child_latency folds it into
        # `coldstart` — where a warm worker pool would actually save it.
        args_payload["parent_spawn_wall_t"] = _time.time()
        json.dump(args_payload, args_file)
        args_file.close()

        result_path = args_file.name + ".result.json"

        # NOTE: don't re-emit set_stage(STAGE_DUCKDB_EXECUTE) here — the
        # parent (api/execute_api.py) already set this stage right before
        # calling s3_full_copy.  Re-emitting would produce a duplicate
        # KIND=stage line in the per-query log with PREV=duckdb_execute:0s.
        # Use update_progress instead so the message updates without a
        # spurious stage transition.
        if execution_id and _stg_update:
            try:
                _stg_update(execution_id,
                            message="Spawning DuckDB subprocess (httpfs S3 read + COPY TO)")
            except Exception as _be_exc:
                note_best_effort("_stg_update(...)", _be_exc,
                                 logger=logger)

        # BF-543 disk pre-flight on the spill dir.  Reconciled
        # 2026-08-02: low space DEGRADES by default (warn + spawn with a
        # reduced spill budget) instead of a pod-wide DuckDBEngineError
        # refusal — see _spill_preflight_mode for the full rationale.
        try:
            _spill_dir = os.environ.get("DUCKDB_TEMP_DIR", "").strip()
            if _spill_dir and os.path.exists(_spill_dir):
                import shutil as _sh
                _usage = _sh.disk_usage(_spill_dir)
                _MIN_FREE_BYTES = 256 * 1024 * 1024  # 256 MiB
                _override = os.environ.get(
                    "DUCKDB_SPILL_MIN_FREE_BYTES", "").strip()
                if _override:
                    try:
                        _MIN_FREE_BYTES = int(_override)
                    except ValueError:
                        pass
                if _usage.free < _MIN_FREE_BYTES:
                    _pf_msg = (
                        f"spill directory {_spill_dir} has only "
                        f"{_usage.free // (1024 ** 2)} MiB free "
                        f"(minimum {_MIN_FREE_BYTES // (1024 ** 2)} MiB).  "
                        f"Either expand the PVC, narrow the WHERE clause, "
                        f"or split the query into smaller pieces.  "
                        f"BF-543 disk pre-flight."
                    )
                    if _spill_preflight_mode() == "block":
                        raise DuckDBEngineError(
                            f"Refusing to spawn DuckDB subprocess: "
                            f"{_pf_msg}")
                    logger.warning(
                        "BF-543 disk pre-flight (degraded): %s  Spawning "
                        "anyway with a spill budget bounded by the "
                        "remaining free space — this query fails alone "
                        "if it genuinely needs more.  Set "
                        "DUCKDB_SPILL_PREFLIGHT_HARD=1 to refuse spawns "
                        "instead.", _pf_msg)
        except DuckDBEngineError:
            raise
        except Exception as _disk_exc:
            # Pre-flight probe failure shouldn't block the query — log
            # and proceed.  If the disk really is full, DuckDB's own
            # spill error will surface later.
            logger.debug("BF-543 disk pre-flight skipped: %s", _disk_exc)

        # BF-530 (2026-05-28): spawn DuckDB in its own process group / job
        # so timeout-kill propagates to grandchildren (httpfs / boto3 worker
        # threads).  Without this, killing only the parent leaves S3
        # downloads running, holding boto3 pool slots until the kernel
        # tcp-timeout finally garbage-collects them (minutes).  Under load
        # this exhausts the pool and every subsequent query stalls with
        # "Connection pool is full".
        _popen_extra: dict = {}
        if os.name == "posix":
            # Unix: new session = new process group.  os.killpg(0, SIGKILL)
            # then kills DuckDB AND every thread it spawned.
            _popen_extra["start_new_session"] = True
        elif os.name == "nt":
            # Windows: CREATE_NEW_PROCESS_GROUP so TerminateProcess + the
            # subsequent OS cleanup walks the group instead of orphaning.
            _popen_extra["creationflags"] = getattr(
                subprocess, "CREATE_NEW_PROCESS_GROUP", 0)

        # BF-542 (2026-05-28): orphan-tracking sidecar.  Subprocess writes
        # its per-query temp paths (pre-downloaded files, spill subdir)
        # into this sidecar file as it creates them.  If the subprocess
        # SIGKILLs before its own finally-block runs, the parent reads
        # the sidecar and cleans up — preventing GBs of orphan files
        # accumulating in the spill PVC after every crash.
        _sidecar_path = args_file.name + ".sidecar.tmp"
        try:
            open(_sidecar_path, "w").close()  # touch + truncate
        except Exception as _sc_exc:
            logger.debug("BF-542 sidecar create skipped: %s", _sc_exc)
            _sidecar_path = ""
        # Pass the sidecar path to the subprocess via env var (cheaper
        # than another CLI arg + keeps subprocess startup compatible
        # with the existing 3-arg signature).
        _spawn_env = os.environ.copy()
        if _sidecar_path:
            _spawn_env["DUCKDB_SUBPROCESS_SIDECAR"] = _sidecar_path

        # ── Spill admission (2026-08-04) ─────────────────────────────────
        # The LAST point at which refusing is still cheap: nothing has been
        # spawned, nothing downloaded, no .tmp written.  Past here the only
        # remaining failure report is DuckDB's "failed to offload data block",
        # which arrives tens of GB and twenty minutes later and tells the
        # operator nothing they can act on.
        #
        # This runs in the PARENT deliberately: the pruner's island size lives
        # in a parent contextvar and has no transport across the process
        # boundary (see s3_read_strategy's note), while the budget inputs are
        # resolvable on both sides.  In `observe` (the default) this only
        # logs -- execution is untouched.
        _adm = None
        _adm_args = None
        try:
            from core import spill_admission as _adm_mod
            if _adm_mod.mode() != _adm_mod.MODE_OFF:
                from core.s3_read_strategy import current_island_size as _cis
                # current_island_size() returns (authoritative, recent).  Take
                # ONLY the authoritative contextvar slot: the module marks the
                # _RECENT fallback diagnostic-grade and says it must never
                # become an authoritative input, and deciding whether to
                # REFUSE a query is as authoritative as it gets.  A stale
                # stamp from another query would refuse the wrong one.
                _adm_island = _cis()[0]
                if _adm_island is not None and _adm_island.known:
                    from core.duckdb_resource_limits import (
                        parse_memory_limit_to_bytes as _adm_m2b,
                        resolve_spill_quota_bytes as _adm_spill,
                    )
                    # _mem_limit is a CHILD-side local; in the parent the
                    # resolved limit is what we are about to hand the child.
                    _adm_mem = _adm_m2b(
                        _spawn_env.get("DUCKDB_MEMORY_LIMIT", "").strip()
                        or os.environ.get("DUCKDB_MEMORY_LIMIT", "").strip())
                    _adm_dir = (os.environ.get("DUCKDB_TEMP_DIR", "").strip()
                                or tempfile.gettempdir())
                    _adm_args = (
                        _adm_island, _adm_mem,
                        _adm_spill(_adm_dir, memory_limit_bytes=_adm_mem))
                    _adm = _adm_mod
        except Exception as _adm_exc:
            # Gathering the inputs must never break a query; only the verdict
            # below is allowed to stop one.
            logger.debug("spill admission inputs unavailable (fail-open): %s",
                         _adm_exc)
            _adm = None
        if _adm is not None and _adm_args is not None:
            # SpillRefused propagates on purpose in `enforce` mode — that IS
            # the feature.  check() raises nothing else.
            #
            # 2026-08-04 completion route: when the operator has ALSO enabled
            # ``spill_admission.completion_route``, a parent-side REFUSE no
            # longer kills the query — the child is spawned anyway, its
            # stage-2 check re-renders the verdict with MEASURED inputs
            # (plan shape + footer decode ratio), and a refusal there is
            # routed through the completion lane (chunked sorted runs +
            # k-way streaming merge) instead of raised.  Refusal remains
            # the fallback when no route applies.
            try:
                _adm.check(
                    _adm_args[0],
                    memory_limit_bytes=_adm_args[1],
                    spill_quota_bytes=_adm_args[2],
                    context=f"execution_id={execution_id or '-'}",
                )
            except _adm.SpillRefused:
                _cr_parent_route = False
                try:
                    from core.blocking_completion_route import (
                        completion_route_enabled as _cr_enabled_fn,
                    )
                    _cr_parent_route = _cr_enabled_fn()
                except Exception as _cr_imp_exc:
                    logger.debug("completion-route availability check "
                                 "failed (refusal stands): %s", _cr_imp_exc)
                    _cr_parent_route = False
                if not _cr_parent_route:
                    raise
                logger.warning(
                    "[spill-admission] enforce-mode REFUSE at the parent, "
                    "but spill_admission.completion_route is enabled — "
                    "spawning the child so its measured stage-2 check can "
                    "ROUTE the plan through the completion lane instead of "
                    "refusing (execution_id=%s)", execution_id or "-")
        # BF-558d: stamp the concurrency into THIS child's env.  The
        # process-global stamp races between concurrent dispatches (see
        # the docstring); a per-spawn dict cannot, because each child gets
        # its own copy at spawn time.  Governs both the memory divisor and
        # the F3 spill-disk share.
        # BF-558f: when the caller does not know its own fan-out (the
        # SINGLE-WORKER path — core/duckdb_views.s3_full_copy, which is the
        # dominant shape for interactive queries under
        # multi_worker.min_files_to_split), fall back to the LIVE
        # cross-query count.  Without this the child resolved
        # concurrency=1 and took 75% of the pod, so N concurrent
        # single-worker queries each claimed the whole budget — the
        # cross-query divisor added for multi-worker dispatches never
        # applied to the majority of queries.
        #
        # This governs the F3 spill-disk share too (the child divides the
        # "50% of free disk" ceiling by the same key), so it also stops N
        # concurrent queries each being promised the whole PVC share.
        _cc = int(concurrent_children or 0)
        if _cc <= 0:
            try:
                from core.worker_pool import live_query_concurrency
                _cc = int(live_query_concurrency())
            except Exception:                                # pragma: no cover
                _cc = 0
        if _cc > 0:
            _spawn_env["QS_DUCKDB_CONCURRENT_CHILDREN"] = str(_cc)

        # ── Phase 7 Parts 1/2/4 — adaptive DuckDB (industrialization.
        # adaptive_duckdb, default OFF) ─────────────────────────────────
        # Per-query overrides for THIS spawn, computed fresh right here
        # (no thread-local plumbing needed — a pure function call using
        # the live fleet signal at spawn time):
        #   * DUCKDB_THREADS      <- Part 1 adaptive degree (fleet load)
        #   * DUCKDB_MEMORY_LIMIT <- Part 2 passport-priced memory_limit
        #   * DUCKDB_SPILL_QUOTA_GB <- Part 4 passport-priced spill quota
        #     (the child's existing resolve_spill_quota_bytes() already
        #     honours this env override — see core.duckdb_resource_limits)
        # Fail-open: ANY error here leaves _spawn_env untouched, so the
        # child falls back to its normal env/cgroup resolution chain —
        # today's behaviour, unchanged.
        _dd_cap = 0
        _dd_slot_acquired = False
        try:
            from core.industrialization.flags import is_enabled as _dd_enabled
            if _dd_enabled("adaptive_duckdb"):
                from core.industrialization import adaptive_duckdb as _dd
                _degree = _dd.compute_degree()
                _spawn_env["DUCKDB_THREADS"] = str(_degree.duckdb_threads)

                _dd_passport = None
                if execution_id:
                    try:
                        from core.industrialization import passport_registry as _dd_preg
                        _dd_passport = _dd_preg.peek(execution_id)
                    except Exception:
                        _dd_passport = None

                _dd_mem_mb = _dd.memory_limit_mb_from_passport(_dd_passport)
                if _dd_mem_mb:
                    _spawn_env["DUCKDB_MEMORY_LIMIT"] = f"{_dd_mem_mb}MB"

                # The pricer fractions a POD-WIDE ceiling, so it must resolve
                # that ceiling from the same three inputs the non-adaptive
                # child path uses at the `resolve_spill_quota_bytes` call
                # below.  Passing only the passport left it with
                # memory_limit_bytes=0 (flat 10 GB instead of 4x memory),
                # temp_dir=gettempdir() (the wrong filesystem — the spill
                # dir is DUCKDB_TEMP_DIR) and concurrent_children=1 (every
                # child promised the whole free-disk share).  Turning the
                # adaptive_duckdb flag ON would have SHRUNK the spill budget.
                _dd_spill_dir = os.environ.get("DUCKDB_TEMP_DIR", "").strip()
                _dd_mem_bytes = int(_dd_mem_mb) * 1024 * 1024 if _dd_mem_mb else 0
                if not _dd_mem_bytes:
                    # No passport-priced limit — fall back to the pod's own
                    # resolved memory limit so the 4x ratio still applies.
                    try:
                        from core.duckdb_resource_limits import (
                            parse_memory_limit_to_bytes as _dd_mem2b,
                        )
                        _dd_mem_bytes = _dd_mem2b(
                            os.environ.get("DUCKDB_MEMORY_LIMIT", "").strip())
                    except Exception:
                        _dd_mem_bytes = 0
                try:
                    _dd_kids = int(os.environ.get(
                        "QS_DUCKDB_CONCURRENT_CHILDREN", "1") or "1")
                except ValueError:
                    _dd_kids = 1
                _dd_spill_bytes = _dd.spill_quota_bytes_from_passport(
                    _dd_passport,
                    temp_dir=_dd_spill_dir or None,
                    memory_limit_bytes=_dd_mem_bytes,
                    concurrent_children=_dd_kids,
                )
                if _dd_spill_bytes:
                    _spawn_env["DUCKDB_SPILL_QUOTA_GB"] = (
                        f"{_dd_spill_bytes / (1024 ** 3):.4f}")

                logger.info(
                    "[adaptive-duckdb] subprocess overrides: threads=%s "
                    "memory_limit=%s spill_quota_gb=%s (%s)",
                    _degree.duckdb_threads,
                    _spawn_env.get("DUCKDB_MEMORY_LIMIT", "<unset>"),
                    _spawn_env.get("DUCKDB_SPILL_QUOTA_GB", "<unset>"),
                    _degree.rationale,
                )

                # Part 2 hard cap — per-pod bounded wait for a free
                # subprocess slot.  cap<=0 (default) = unlimited = a
                # no-op acquire that always "succeeds" without touching
                # any counter (today's behaviour).  Never deadlocks: on
                # timeout the query proceeds WITHOUT a slot (throughput
                # backpressure, not a hard admission wall).
                from core.config import get as _dd_cfg_get
                _dd_cap = int(_dd_cfg_get(
                    "industrialization_duckdb",
                    "max_concurrent_subprocesses", 0) or 0)
                _dd_wait_s = float(_dd_cfg_get(
                    "industrialization_duckdb",
                    "subprocess_slot_wait_seconds", 30) or 30)
                _dd_slot_acquired = _dd.acquire_subprocess_slot(
                    _dd_cap, timeout_s=_dd_wait_s)
        except Exception as _dd_exc:
            logger.debug(
                "[adaptive-duckdb] subprocess override skipped (fail-open, "
                "today's env/cgroup resolution stays in effect): %s",
                _dd_exc,
            )

        # ── Query pods (2026-10-31): the run's RESERVATION is DuckDB's limit ──
        # A run claimed by a budgeted query pod carries reserved_bytes
        # (core/query_pods/budget.py, set around the run by the job-queue
        # bridge).  Its DuckDB memory_limit is exactly that reservation,
        # split among the children THIS dispatch fans out to -- never a
        # share of whatever is free when it starts (the 2026-10-28 cause).
        # Wins over the adaptive pricing above: the reservation is what the
        # pod set aside.  No reservation (0) -> nothing changes here.
        try:
            from core.query_pods.budget import duckdb_memory_limit_for_spawn as _qp_limit
            _qp_mb = _qp_limit(execution_id, int(concurrent_children or 0))
            if _qp_mb > 0:
                _spawn_env["DUCKDB_MEMORY_LIMIT"] = f"{_qp_mb}MB"
                logger.info("[query-pods] execution %s: DuckDB memory_limit=%dMB "
                            "= its reservation / %d child(ren)",
                            execution_id or "-", _qp_mb, max(1, int(concurrent_children or 1)))
        except Exception as _qp_exc:
            logger.debug("[query-pods] reservation not applied to the spawn "
                         "(fail-open): %s", _qp_exc)

        # ── Phase 7 Part 3 — forkserver fast path (industrialization.
        # forkserver, default OFF; structurally inert on non-POSIX) ─────
        # Tries a forked one-shot child of the pre-warmed template first;
        # falls back to the legacy cold subprocess.Popen below on ANY
        # unavailability (flag off, Windows/dev, boot failure, fork
        # failure) — see core.industrialization.duckdb_forkserver for the
        # full design + the no-state-bleed argument.
        proc = None
        try:
            from core.industrialization import duckdb_forkserver as _dd_fs
            # The forked child inherits this process's os.environ via
            # fork's copy-on-write already; only the per-query deltas
            # captured in _spawn_env (sidecar path + the Phase 7
            # adaptive overrides, if any) need to be re-applied
            # explicitly inside the child.
            _fs_overrides = {}
            # BF-558b: QS_DUCKDB_CONCURRENT_CHILDREN MUST be in this
            # allow-list.  The forkserver child inherits the TEMPLATE
            # process's env, which was captured at forkserver startup —
            # long before any query stamped its worker count.  Omitting it
            # silently disables BOTH the memory divisor (BF-558b) and the
            # spill-share divisor (F3, 2026-07-31) on the forkserver path,
            # so every forked child would claim the WHOLE pod budget.
            for _fk in ("DUCKDB_SUBPROCESS_SIDECAR", "DUCKDB_THREADS",
                        "DUCKDB_MEMORY_LIMIT", "DUCKDB_SPILL_QUOTA_GB",
                        "QS_DUCKDB_CONCURRENT_CHILDREN"):
                if _fk in _spawn_env:
                    _fs_overrides[_fk] = _spawn_env[_fk]
            proc = _dd_fs.try_spawn_via_forkserver(
                args_file.name, result_path, env_overrides=_fs_overrides,
            )
        except Exception as _fs_exc:
            logger.debug(
                "[forkserver] spawn attempt raised (fail-open to cold "
                "spawn): %s", _fs_exc,
            )
            proc = None

        if proc is None:
            proc = subprocess.Popen(
                [sys.executable, "-m", "core.duckdb_subprocess", args_file.name, result_path],
                cwd=_BACKEND_DIR,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=_spawn_env,
                **_popen_extra,
            )

        # ── Resource Governor (2026-08-02, default OFF) ── register this
        # child so the governor's sampler can measure its RSS exactly (the
        # one-process-per-query structural advantage).  Covers BOTH spawn
        # shapes reaching here (forkserver handle or cold Popen).
        # Fail-open: any error leaves the query exactly as it is today.
        try:
            from core import resource_governor as _rg
            _rg.register_child(
                proc.pid, execution_id=execution_id or "", popen=proc,
                # Both spawn shapes reaching here lead their OWN process
                # group (Popen: start_new_session / CREATE_NEW_PROCESS_GROUP
                # above; forkserver children setsid()) — so the governor may
                # reuse the BF-530 group kill.
                own_process_group=True,
                spawn_env=_spawn_env,
            )
        except Exception as _rg_exc:
            logger.debug("[resource-governor] register skipped (fail-open): %s",
                         _rg_exc)

        # BF-PRUNE-PERF-LOG: wait in poll-loop (10s slices) so we can emit
        # heartbeat stage updates instead of one silent communicate(timeout)
        # that blocks forever with no visibility for the user.
        # Also stat the output file so the user sees "X bytes written"
        # — DuckDB streams result rows into the COPY TO target as it scans
        # files, so growth here = actual progress.
        # BF-CANCEL: when cancel_event is provided AND set, KILL the
        # subprocess immediately so the user's "Cancel" button actually
        # stops work.  Was: cancel_event was inert here — the subprocess
        # ran to completion (or timeout) regardless.
        stdout = b""
        stderr = b""
        _cancelled = False
        # P5 (2026-08-04) — live child-output pumps.  When the spawn shape
        # exposes pipes, drain them on threads so (a) the child's stderr is
        # in the parent log AS IT HAPPENS (spill attribution, width-clause
        # lines, streaming progress) and (b) a chatty child can't fill the
        # pipe and deadlock.  ``proc.wait`` replaces ``proc.communicate``
        # only when pumps are attached; pipe-less spawn shapes keep the
        # communicate path byte-for-byte.
        _pump_err = None
        _pump_out = None
        try:
            if getattr(proc, "stderr", None) is not None:
                _pump_err = _PipePump(proc.stderr, "stderr", live=True)
            if getattr(proc, "stdout", None) is not None:
                _pump_out = _PipePump(proc.stdout, "stdout", live=False)
        except Exception as _pump_exc:
            logger.debug("pipe pumps unavailable (communicate path stays): "
                         "%s", _pump_exc)
            _pump_err = _pump_out = None
        _pumped = _pump_err is not None or _pump_out is not None

        def _collect(wait_timeout):
            """wait-or-communicate + gather output.  Raises
            subprocess.TimeoutExpired exactly like communicate."""
            nonlocal stdout, stderr
            if _pumped:
                proc.wait(timeout=wait_timeout)
                stdout = _pump_out.data() if _pump_out else b""
                stderr = _pump_err.data() if _pump_err else b""
                return stdout, stderr
            return proc.communicate(timeout=wait_timeout)

        if execution_id or cancel_event is not None:
            # BF-540 (2026-05-28): cancel poll was 5s — a click on Cancel
            # took up to 5s to fire SIGKILL, making the UI feel broken.
            # 1s slice trades 5× more wakeups (cheap) for snappy UX.
            # Heartbeat / bytes-written progress event is emitted on a
            # coarser cadence so we don't spam the stage tracker.
            _slice = 1.0
            _waited = 0.0
            while True:
                try:
                    stdout, stderr = _collect(_slice)
                    break  # subprocess finished
                except subprocess.TimeoutExpired:
                    _waited += _slice
                    # ── Cancel check ───────────────────────────────────────
                    if cancel_event is not None and cancel_event.is_set():
                        _cancelled = True
                        logger.warning(
                            "DuckDB subprocess (pid=%s) cancel_event set after %.0fs — "
                            "SIGTERM-then-SIGKILL on process group (BF-530)",
                            proc.pid, _waited,
                        )
                        # P4/P5 — one [GATE] line for the cancel decision;
                        # the child's per-query spill dir + spool + tmp are
                        # sidecar-registered, so the BF-542 drain in the
                        # finally below reclaims them the moment the child
                        # is reaped (SIGKILL leaves DuckDB no chance to).
                        try:
                            from core.log_style import gate as _cx_gate
                            _cx_gate(
                                logger, "cancel.subprocess", "BLOCK",
                                "SIGTERM then SIGKILL on the process group; "
                                "per-query spill/spool reclaimed via "
                                "sidecar drain",
                                pid=proc.pid,
                                waited_s=int(_waited),
                                exec=execution_id or "n/a",
                            )
                        except Exception as _be_exc:
                            note_best_effort("_cx_gate(...)", _be_exc,
                                             logger=logger)
                        _kill_subprocess_tree(proc)
                        try:
                            stdout, stderr = _collect(10)
                        except subprocess.TimeoutExpired:
                            _kill_subprocess_tree(proc, force=True)
                            stdout, stderr = b"", b""
                        # 2026-10-26 -- what the cancel reached is RECORDED
                        # on the run (core/cancel_scope.py::note_cancel)
                        try:
                            from core.cancel_scope import note_cancel as _note_cancel
                            _rc = proc.poll()
                            _note_cancel(cancel_event, "duckdb_child",
                                         reached=_rc is not None,
                                         statement=f"pid {proc.pid}",
                                         detail=(f"the child process was stopped (exit {_rc})"
                                                 if _rc is not None else
                                                 "the child process did not stop"))
                        except Exception as _be_exc:
                            note_best_effort("_note_cancel(...)", _be_exc, logger=logger)
                        if execution_id and _stg_update:
                            try:
                                _stg_update(execution_id,
                                            message=f"DuckDB subprocess cancelled by user after {int(_waited)}s")
                            except Exception as _be_exc:
                                note_best_effort("_stg_update(...)", _be_exc,
                                                 logger=logger)
                        break
                    if _waited >= timeout:
                        # exhausted total timeout — fall through to outer except
                        raise
                    # ── Progressive tail + heartbeat (shared tick) ─────────
                    # Tails newly-sealed data_N.parquet parts into the
                    # progressive manifest on EVERY slice and emits the
                    # bytes-written heartbeat every 5 s (BF-540: the 1 s
                    # cadence is for fast cancel, not heartbeat spam).  The
                    # same closure serves the pool transport's wait_ack.
                    _progress_tick(_waited, pid=proc.pid)
        else:
            stdout, stderr = _collect(timeout)
        wall_elapsed = round(_time.monotonic() - wall_start, 2)
        # Phase 164 (2026-07-04) — latency attribution moved to the
        # success path below (split by the child's timings into
        # coldstart / s3 / compute) with a whole-wall fallback in the
        # finally.  The old code attributed the ENTIRE subprocess wall
        # to ``compute``, which hid S3-byte time and per-query cold
        # start behind one bucket and defeated the pool-vs-mirror
        # decision the breakdown exists to inform.
        if _cancelled:
            raise RuntimeError(
                f"DuckDB subprocess cancelled by user after {wall_elapsed}s"
            )

        if proc.returncode != 0:
            # 2026-06-24 -- previously this truncated to the LAST 2000
            # bytes of stderr, which scrolled the early diagnostics
            # (S3 setup plan line, SSL config, extension load) out of
            # sight when the subprocess crashed late in setup.  Result:
            # the operator saw only the failing CREATE VIEW / HTTP 0
            # but lost the upstream "which strategy did the planner
            # pick" context that's CRITICAL for triage.  Capture
            # head + tail so both the planner decision AND the crash
            # site survive.
            _full_stderr = stderr.decode("utf-8", errors="replace")
            if len(_full_stderr) > 6500:
                stderr_text = (
                    _full_stderr[:2500]
                    + "\n... [stderr truncated mid-stream, "
                    + str(len(_full_stderr) - 6500)
                    + " bytes hidden] ...\n"
                    + _full_stderr[-4000:]
                )
            else:
                stderr_text = _full_stderr
            stdout_text = stdout.decode("utf-8", errors="replace")[-2000:]
            # 2026-08-19 -- THE CHILD ALREADY TOLD US WHY, AND WE THREW IT
            # AWAY.  ``_child_main``'s top-level handler sanitizes the
            # exception, writes ``{"error": "<Type>: <msg>"}`` to the SAME
            # result file this function reads on success, and only THEN
            # exits 1.  But this branch raised on the exit code alone and
            # never opened that file, so every ordinary query failure --
            # OOM, spill exhaustion, an httpfs 403/404, a bad parquet --
            # reached the user as:
            #     DuckDB query execution crashed (exit code 1, exit code 1).
            #     SUBPROCESS: duckdb version=... <2.5KB of setup banner>
            # The real exception WAS in stderr, but behind the whole S3
            # setup plan, and the head/tail truncation above then cut the
            # middle out.  Operators saw the engine's boot log and no cause.
            # Read the child's own verdict and lead the message with it.
            # Pure diagnostics + fail-open: anything unreadable here falls
            # through to the exit-code-only message below.
            # Hoisted ABOVE the exit-diagnosis marker for the same reason
            # the governor block below is -- see its comment.
            _child_error = None
            try:
                if os.path.exists(result_path):
                    with open(result_path, "r") as _err_f:
                        _payload = json.load(_err_f)
                    if isinstance(_payload, dict):
                        _child_error = (_payload.get("error") or "").strip() or None
            except Exception as _err_exc:
                logger.debug(
                    "child error-result unreadable (fail-open, falling back "
                    "to the exit code): %s", _err_exc,
                )
            # Resource Governor: if WE killed this child, surface the
            # governor's verdict instead of a bare exit code.  Deliberately
            # hoisted ABOVE the exit-diagnosis marker below: its regression
            # test scans a fixed source window from that marker to the
            # raise, so inserting between them pushes the raise out of the
            # window.  (This comment must not contain that marker string
            # either, or find() matches HERE and shifts the window.)
            # Fail-open: any error falls through to today's crash message.
            _rg_note = None
            try:
                from core import resource_governor as _rg
                _rg_note = _rg.consume_kill_note(proc.pid, execution_id or "")
            except Exception as _rg_exc:
                logger.debug("[resource-governor] kill-note lookup failed "
                             "(fail-open): %s", _rg_exc)
            # BF-531: structured exit-code diagnosis so operators see the
            # likely cause instantly (OOM-kill / segfault / cancel) rather
            # than puzzling over a bare "-9".
            cause = _decode_subprocess_exit(proc.returncode)
            # 2026-06-24 -- sanitize stderr/stdout BEFORE logging so AWS
            # SigV4 secrets (X-Amz-Credential / Security-Token /
            # Signature) embedded in presigned-URL error messages don't
            # leak to pod logs.  Anyone reading the logs would otherwise
            # get a working presigned URL until expiry.
            from core.proxy_utils import sanitize_proxy_error as _redact
            stderr_text = _redact(stderr_text)
            stdout_text = _redact(stdout_text)
            logger.error(
                "DuckDB subprocess crashed (exit %d = %s, %.1fs):\n"
                "STDOUT: %s\nSTDERR: %s",
                proc.returncode, cause, wall_elapsed, stdout_text, stderr_text,
            )
            # BF-541 (2026-05-28): persist the crash to DB so the
            # admin dashboard can render "N crashes in last 24h" and
            # operators see the failure pattern across pods.  Pure
            # telemetry — must NEVER raise.
            _record_crash_to_db(execution_id, connection_id,
                                 proc.returncode, cause,
                                 stderr_text, wall_elapsed)
            if _rg_note:
                raise DuckDBEngineError(_rg_note)
            # 2026-10-02 -- a child that REFUSED (a declared cap, with its
            # remedy) is neither a crash nor a query error: re-raise the
            # typed refusal so the breaker, the retry and the route can each
            # tell it apart.  Only exit 1 carries a verdict of the child's
            # own (its top-level handler); anything else is unchanged.
            _refusal = (refusal_from_child_verdict(_child_error)
                        if proc.returncode == 1 else None)
            if _refusal is not None:
                raise _refusal
            # BF-48: Include stderr in the error message so downstream
            # is_connection_error() can detect ExpiredToken, AccessDenied,
            # etc. and trigger stale-result fallback instead of a hard failure.
            # Raise DuckDBEngineError so circuit breaker only trips on engine
            # failures, not query/SQL errors.
            from core.proxy_utils import sanitize_proxy_error
            # The child's own verdict goes FIRST when we have it: it is the
            # actual exception, already sanitized, and it is what the reader
            # needs in the first line.  The exit code and the stderr tail
            # stay behind it as supporting context -- they carry the S3
            # setup plan and the spill high-water mark, which matter for
            # triage but are not the answer to "why did it fail".
            _lead = f"{_child_error}  " if _child_error else ""
            # 2026-09-26 -- exit 1 WITH a request-shaped verdict is the
            # request's failure (see DuckDBQueryError): same message, a
            # subclass, so the breaker learns nothing and nothing retries it.
            _exc_type = (DuckDBQueryError
                         if proc.returncode == 1 and verdict_is_query_shaped(_child_error)
                         else DuckDBEngineError)
            raise _exc_type(
                sanitize_proxy_error(
                    f"{_lead}DuckDB query execution crashed ({cause}, exit "
                    f"code {proc.returncode}). {stderr_text.strip()}"
                )
            )

        if not os.path.exists(result_path):
            # BF-531: differentiate exit-0-no-result (silent OOM mid-write)
            # from a genuine engine crash so ops see the actionable cause.
            cause = _decode_subprocess_exit(0)
            logger.error(
                "DuckDB subprocess (pid=%s) %s (%.1fs).  Likely cause: "
                "the result-file write was interrupted by an OOM-kill or "
                "spill-dir-full event right as the query finished.",
                proc.pid, cause, wall_elapsed,
            )
            # BF-541: persist silent-crash event too — they're the
            # hardest to diagnose blind.
            _record_crash_to_db(execution_id, connection_id, 0, cause,
                                 stderr.decode("utf-8", errors="replace")[-2000:],
                                 wall_elapsed)
            raise DuckDBEngineError(
                f"DuckDB subprocess completed but no result file ({cause}).  "
                f"Check pod memory limit + spill-dir free space."
            )

        with open(result_path, "r") as f:
            result = json.load(f)

        if result.get("error"):
            from core.proxy_utils import sanitize_proxy_error
            _safe_err = sanitize_proxy_error(result["error"])
            logger.error(
                "DuckDB query error (%.1fs): %s", wall_elapsed, _safe_err[:500]
            )
            _refusal = refusal_from_child_verdict(_safe_err)
            if _refusal is not None:
                raise _refusal
            raise RuntimeError(f"DuckDB query error: {_safe_err}")

        # Log subprocess stderr on success (contains proxy/extension/cred diagnostics)
        _ok_stderr = stderr.decode("utf-8", errors="replace").strip()
        if _ok_stderr:
            for _line in _ok_stderr.splitlines():
                _line = _line.strip()
                if not _line:
                    continue
                # 2026-08-21 — s3_region and the TLS verdict join proxy/download
                # at INFO.  These decide whether EVERY object read succeeds
                # (a wrong region is AuthorizationHeaderMalformed on all of
                # them), so hiding them at DEBUG meant the one line that
                # answers "what did we sign with?" was absent from production
                # logs — and their absence then reads as "the fix is not
                # deployed", which is a different and wrong conclusion.
                _lc = _line.lower()
                if ("proxy" in _lc or "pre-download" in _lc
                        or "s3_region" in _lc
                        or "region configured" in _lc
                        or "certificate verification" in _lc):
                    logger.info("SUBPROCESS: %s", _line)
                else:
                    logger.debug("SUBPROCESS: %s", _line)

        # Log timing breakdown from the child process
        timing = result.get("timing", {})
        logger.info(
            "DuckDB subprocess OK: %s rows, %.1f MB, wall=%.1fs "
            "(init=%.1fs creds=%.1fs setup=%.1fs query=%.1fs)",
            f"{result.get('total_rows', 0):,}",
            result.get("file_size_bytes", 0) / 1024 / 1024,
            wall_elapsed,
            timing.get("init_s", 0),
            timing.get("creds_s", 0),
            timing.get("setup_s", 0),
            timing.get("query_s", 0),
        )

        result["timing"]["wall_s"] = wall_elapsed
        # Phase 164 — split the child's coarse timings into real latency
        # stages so the operator dashboard distinguishes S3-byte time,
        # per-query cold start, and genuine compute.
        _attribute_child_latency(timing, wall_elapsed)
        _latency_attributed = True
        return result

    except subprocess.TimeoutExpired:
        logger.error(
            "DuckDB subprocess (pid=%s) timed out after %ds — SIGTERM-then-SIGKILL "
            "on process group (BF-530)",
            proc.pid, timeout,
        )
        _kill_subprocess_tree(proc)
        try:
            if locals().get("_pumped"):
                proc.wait(timeout=10)  # pumps own the pipes
            else:
                proc.communicate(timeout=10)  # wait for OS to release file handles
        except subprocess.TimeoutExpired:
            _kill_subprocess_tree(proc, force=True)
            logger.warning(
                "DuckDB subprocess (pid=%s) did not die within 10s after SIGKILL",
                proc.pid,
            )
        # BF-531: surface timeout as DuckDBEngineError so the circuit
        # breaker counts it.  A pod that times out 3× in a row needs to
        # back off before letting the 4th query crash everything; the
        # old RuntimeError path silently bypassed the breaker.
        raise DuckDBEngineError(
            f"DuckDB query timed out after {timeout}s (subprocess killed via "
            f"process-group, BF-530+BF-531).  Likely cause: memory exhausted "
            f"the in-process query plan and DuckDB began thrashing the spill "
            f"dir.  Either narrow the WHERE clause, add more partition "
            f"columns to the source table, or set the scan budget for this "
            f"table's layout — s3.max_files_per_query for plain/hive "
            f"parquet, iceberg.max_files_per_query for Iceberg — so an "
            f"over-large scan is REFUSED with a count instead of timing out."
            # 2026-09-21 (FB-55): this advised raising
            # iceberg.max_files_per_query for EVERY DuckDB timeout,
            # including plain-parquet ones, where that key governs nothing.
            # Naming a knob the failing path does not read is the same
            # defect the sibling refusal message shipped once already.
        )
    finally:
        # Phase 7 Part 2 — release the per-pod subprocess slot (no-op
        # when cap<=0 / never acquired).  Must run on EVERY exit path
        # (success, crash, timeout, cancel) so a saturated cap always
        # drains — never a leaked permanent slot.
        try:
            from core.industrialization import adaptive_duckdb as _dd_release
            _dd_release.release_subprocess_slot(
                locals().get("_dd_cap", 0) or 0,
                acquired=bool(locals().get("_dd_slot_acquired", False)),
            )
        except Exception as _be_exc:
            note_best_effort("_dd_release.release_subprocess_slot(...)", _be_exc,
                             logger=logger)
        # Resource Governor (2026-08-02): stop tracking this child on
        # EVERY exit path.  The governor also reaps by liveness, so a
        # missed deregister only delays finalization by one sample tick.
        try:
            from core import resource_governor as _rg_dereg
            _rg_proc = locals().get("proc")
            if _rg_proc is not None:
                _rg_dereg.deregister_child(getattr(_rg_proc, "pid", 0) or 0)
        except Exception as _rg_dereg_exc:
            logger.debug("[resource-governor] deregister skipped (fail-open): "
                         "%s", _rg_dereg_exc)
        # Phase 164 — if the success path never attributed latency (the
        # subprocess crashed / timed out before we parsed its timings),
        # record the whole wall as ``compute`` so a failed query still
        # shows up in the breakdown rather than vanishing.  Best-effort.
        if not _latency_attributed:
            try:
                from core.brain_latency_breakdown import record_stage as _lb_rec
                _lb_rec("compute", _time.monotonic() - wall_start)
            except Exception as _be_exc:
                note_best_effort("_lb_rec('compute', _time.monotonic() - wall_start)", _be_exc,
                                 logger=logger)
        # BF-542 (2026-05-28): drain the orphan-tracking sidecar before
        # we unlink it.  When the subprocess SIGKILLs before its own
        # finally-block runs (OOM, SIGKILL, segfault), this is the only
        # way the parent learns about temp files the subprocess created.
        # Each line in the sidecar is a path the subprocess promised to
        # clean.  We do best-effort unlink/rmtree here so the spill PVC
        # doesn't accumulate orphans after every crash.
        _sc_path = locals().get("_sidecar_path", "") or ""
        if _sc_path and os.path.exists(_sc_path):
            try:
                with open(_sc_path, "r") as _sc_fh:
                    _orphan_paths = [
                        line.strip() for line in _sc_fh if line.strip()
                    ]
                for _op in _orphan_paths:
                    try:
                        if os.path.isdir(_op):
                            import shutil as _sh
                            _sh.rmtree(_op, ignore_errors=True)
                        elif os.path.exists(_op):
                            os.unlink(_op)
                    except OSError as _op_exc:
                        logger.debug(
                            "BF-542 orphan cleanup skipped %s: %s",
                            _op, _op_exc)
                if _orphan_paths:
                    logger.info(
                        "BF-542 sidecar cleanup: removed %d temp paths "
                        "from subprocess args=%s",
                        len(_orphan_paths), args_file.name,
                    )
            except OSError as _sc_read_exc:
                logger.debug("BF-542 sidecar read failed: %s",
                             _sc_read_exc)
        # Cleanup temp files (sidecar + args + result)
        for p in (args_file.name, args_file.name + ".result.json",
                   _sc_path):
            if not p:
                continue
            try:
                os.unlink(p)
            except OSError:
                pass
        # Progressive COPY spool — belt-and-braces removal on EVERY exit
        # path (the sidecar drain above usually got it; see the helper).
        _prog_spool_cleanup()


# ═══════════════════════════════════════════════════════════════════════════════
# Pre-download: fetch HTTPS URLs via Python's SSL stack so DuckDB reads local
# ═══════════════════════════════════════════════════════════════════════════════

# Shared helper for converting a downloaded local path to a form DuckDB
# can open on the current OS — handles the Windows MAX_PATH (260-char)
# limit by applying the ``\\?\`` long-path prefix when needed.  Single
# source of truth in core.s3_predownload so subprocess + parent paths
# behave identically.
from core.s3_predownload import to_duckdb_path as _to_duckdb_path  # noqa: E402
# 2026-08-03 (defect fix) — mid-flight disk-headroom guard, shared with the
# sibling downloaders (predownload_s3_files / _presigned_to_local).  Imported
# at module level so the CHILD process (which imports this module before
# calling _pre_download_presigned) fails fast at import time if the helper
# ever moves, instead of silently downloading without the guard.
from core.s3_predownload import _assert_disk_headroom  # noqa: E402
from core.best_effort import note_best_effort


def read_strategy_for_setup(plan, conn_config: dict, setup_sql: str, proxy_active: bool):
    """The child's read verdict: ``(strategy, vpc_needed, vpc_reason)``.

    2026-09-26 (F3 round 5) -- ONE decision, ``core.duckdb_s3_plan
    .read_strategy``, fed the two gates this process evaluates: the proxy
    (``proxy_active`` is what ``set_subprocess_proxy_env`` returned, i.e.
    ``core.proxy_utils.duckdb_proxy_applies`` for this endpoint) and the VPC
    workaround.  The three pre-download blocks below dispatch on the answer
    instead of restating it; the scheduled S3 road
    (core.local_parquet_road) calls the same function with the same inputs.
    """
    from core.duckdb_s3_plan import read_strategy
    from core.ssl_config import vpc_httpfs_workaround_needed
    ep = conn_config.get("endpoint_url") or conn_config.get("endpoint")
    try:
        vpc_needed, vpc_reason = vpc_httpfs_workaround_needed(ep, setup_sql)
    except Exception as exc:                      # the check is best-effort
        vpc_needed, vpc_reason = False, f"check unavailable: {exc}"
    return (read_strategy(plan, proxy_applies=bool(proxy_active), vpc_needed=bool(vpc_needed)),
            vpc_needed, vpc_reason)


def _pre_download_presigned(setup_sql: str, conn_config: dict):
    """Download pre-signed HTTPS parquet URLs to local temp dir.

    DuckDB's bundled libcurl in subprocesses cannot always establish HTTPS
    connections to on-prem S3 servers (HTTP 0 errors).  Python's SSL stack
    works fine (same as boto3).  This function:

    1. Finds all https:// URLs in the setup SQL
    2. Downloads each to a temp dir, **preserving hive partition directory
       structure** so DuckDB's hive_partitioning=true can still extract
       partition column values (e.g. /code=ABC/date=2025-01-01/file.parquet)
    3. Replaces URLs in the SQL with local file paths

    Returns (modified_sql, list_of_temp_paths).
    Caller must delete temp files when done.  The first entry in the list
    is the temp directory root (for shutil.rmtree cleanup).
    """
    import re
    import shutil
    from urllib.parse import urlparse, urlunparse, quote, unquote
    from urllib.request import urlopen, Request

    # Match 'https://...' URLs inside SQL strings
    url_re = re.compile(r"'(https?://[^']+)'")
    urls_raw = url_re.findall(setup_sql)
    if not urls_raw:
        return setup_sql, []

    # Deduplicate while preserving order (BUG #3 fix)
    urls = list(dict.fromkeys(urls_raw))

    # 2026-06-18 -- ALL SSL config now routes through core.ssl_config.
    # This replaces the prior inline parsing which had a DEAD BRANCH
    # (ssl_verify=True -> CERT_NONE) AND silently ignored the helm-
    # deployed backend/certs/tls_bundle.pem.  Both bugs fixed by
    # delegating to the central resolver.
    from core.ssl_config import resolve_ssl, as_ssl_context, describe
    _ssl_res = resolve_ssl(conn_config.get("ssl_verify", True))
    print(f"SUBPROCESS: presigned download -- {describe(_ssl_res)}",
          file=sys.stderr, flush=True)
    ssl_ctx = as_ssl_context(_ssl_res)

    # Create a temp directory to preserve hive partition dir structure.
    # QS_DOWNLOAD_TEMP_DIR should point to a PVC-backed path (e.g. /app/data/tmp/downloads)
    # to prevent pod eviction on large S3 downloads.
    _dl_base = os.environ.get("QS_DOWNLOAD_TEMP_DIR", "").strip() or None
    if _dl_base:
        os.makedirs(_dl_base, exist_ok=True)
    temp_dir = tempfile.mkdtemp(prefix="qs_subprocess_dl_", dir=_dl_base)
    temp_files = [temp_dir]  # first entry = root dir (for cleanup)
    modified_sql = setup_sql
    _http_pool = None  # urllib3 PoolManager; set in try block if available

    # Disk space guard — same check as _pre_download_s3_via_boto3()
    _min_free_gb = float(os.environ.get("QS_DOWNLOAD_MIN_FREE_GB", "1.0"))
    try:
        _disk = shutil.disk_usage(temp_dir)
        _free_gb = _disk.free / (1024 ** 3)
        if _free_gb < _min_free_gb:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise RuntimeError(
                f"Insufficient disk space for presigned pre-download: "
                f"{_free_gb:.1f} GB free, need at least {_min_free_gb:.0f} GB"
            )
    except RuntimeError:
        raise
    except Exception as _disk_err:
        print(f"SUBPROCESS: disk_usage check skipped (presigned): {_disk_err}",
              file=sys.stderr, flush=True)

    # BF-578 (2026-05-29): cap on total presigned download volume.
    # Audit found this path bypassed the cap that the boto3 sibling
    # honored — so a 1000-file 50 GB query on the presigned path
    # would fill the PVC even after we set predownload_max_disk_gb.
    # File count is a cheap proxy when we don't have per-file size
    # ahead of time; refuse early if the URL count exceeds N (default
    # 200) AND no env override is set.  Admin can disable via
    # QS_PRESIGNED_MAX_FILES=0.
    try:
        _presigned_max_files = int(
            os.environ.get("QS_PRESIGNED_MAX_FILES", "200")
        )
        if _presigned_max_files > 0 and len(urls) > _presigned_max_files:
            shutil.rmtree(temp_dir, ignore_errors=True)
            # 2026-10-02 -- a TYPED refusal (a RuntimeError subclass, so the
            # re-raise just below still holds): see PresignedDownloadRefusal.
            raise PresignedDownloadRefusal(
                f"Presigned pre-download would fetch {len(urls)} files; cap "
                f"is {_presigned_max_files}.  Narrow the query (add a "
                f"partition filter or LIMIT) OR raise QS_PRESIGNED_MAX_FILES."
            )
    except (RuntimeError, ValueError) as _cap_err:
        if isinstance(_cap_err, RuntimeError):
            raise
        # ValueError on bad env value — log and proceed with default behaviour.
        print(f"SUBPROCESS: BF-578 cap parse failed: {_cap_err}",
              file=sys.stderr, flush=True)

    # ── MID-FLIGHT disk-headroom guard (2026-08-03 defect fix) ──────────────
    # The one-shot pre-flight above proves there was room to START, never
    # room to FINISH; the BF-578 file-count cap is a proxy a 31-file /
    # ~60 GB island sails straight through (31 << 200).  Re-check free
    # space as files land, at the SAME cadence the sibling downloader
    # (core.s3_predownload.predownload_s3_files → _track) uses: once per
    # progress interval, not per file.  _assert_disk_headroom raises
    # RuntimeError → the outer except below rmtrees temp_dir, so the
    # abort is clean.  Fail-open when the volume can't be stat'd (helper
    # behaviour) — an unreadable disk must not block a working deployment.
    #
    # Floor resolution: env QS_DOWNLOAD_MIN_FREE_GB (same knob the
    # pre-flight honours) wins when set; otherwise s3.min_free_disk_gb
    # config (same source the sibling paths use); otherwise the 1 GB
    # default already in _min_free_gb.
    _hd_floor = _min_free_gb
    if not os.environ.get("QS_DOWNLOAD_MIN_FREE_GB", "").strip():
        try:
            from core.config import s3 as _s3_cfg_hd
            _hd_floor = float(_s3_cfg_hd.min_free_disk_gb)
        except Exception as _hd_cfg_err:
            print(f"SUBPROCESS: headroom floor config unavailable "
                  f"({_hd_cfg_err}) — using {_min_free_gb:.1f} GB",
                  file=sys.stderr, flush=True)
            _hd_floor = _min_free_gb
    _hd_interval = max(1, min(10, len(urls) // 10)) if len(urls) > 1 else 1
    _hd_state = {"done": 0, "bytes": 0}

    def _headroom_after_file(local_file: str) -> None:
        """Called once per completed download (both the sequential and the
        parallel collection loop).  Every ``_hd_interval`` files, re-checks
        free space on the download volume and raises RuntimeError (via the
        shared ``_assert_disk_headroom``) when it falls below the floor."""
        _hd_state["done"] += 1
        try:
            _hd_state["bytes"] += os.path.getsize(local_file)
        except OSError:
            pass  # size is diagnostic only — never block on a stat failure
        if _hd_state["done"] % _hd_interval == 0:
            _assert_disk_headroom(temp_dir, _hd_floor, _hd_state["done"],
                                  len(urls), _hd_state["bytes"])

    def _cache_fetch_fn(download_url: str, orig_url: str):
        """Phase 10 — fetch_fn(tmp_path)->FetchMeta closure for the on-prem
        cache.  Mirrors the two GET strategies below (urllib3 pool vs
        stdlib urlopen fallback) exactly, just targeting an arbitrary tmp
        path (inside the cache) instead of ``temp_dir/rel_path``.
        """
        def _do(tmp_path: str):
            from core.onprem_file_cache import FetchMeta
            if _http_pool is not None:
                resp = _http_pool.request("GET", download_url, preload_content=False)
                try:
                    if resp.status >= 400:
                        raise RuntimeError(
                            f"HTTP {resp.status} downloading {orig_url[:80]}")
                    etag = None
                    try:
                        etag = resp.headers.get("ETag")
                    except Exception as _be_exc:
                        note_best_effort("resp.headers.get('ETag')", _be_exc,
                                         logger=logger)
                    with open(tmp_path, "wb") as out:
                        shutil.copyfileobj(resp, out)
                    resp.release_conn()
                except Exception:
                    resp.close()
                    raise
            else:
                req = Request(download_url, headers={"User-Agent": "QueryStudio/1.0"})
                with urlopen(req, context=ssl_ctx, timeout=120) as resp2:
                    etag = resp2.headers.get("ETag")
                    with open(tmp_path, "wb") as out:
                        shutil.copyfileobj(resp2, out)
            return FetchMeta(size=os.path.getsize(tmp_path),
                              etag=(etag.strip('"') if etag else None))
        return _do

    def _dl_one(idx: int, url: str) -> tuple:
        """Download a single presigned URL. Returns (idx, url, local_file)."""
        parsed = urlparse(url)
        canonical_path = quote(parsed.path, safe='/-._~')
        if canonical_path != parsed.path:
            download_url = urlunparse((
                parsed.scheme, parsed.netloc, canonical_path,
                parsed.params, parsed.query, parsed.fragment
            ))
        else:
            download_url = url

        # Phase 10 (industrialization.local_file_cache, default OFF) — an
        # on-prem immutable local-disk cache keyed on (host, object path).
        # ``cached_download`` returns None when the flag is off or on ANY
        # internal error, in which case this falls straight through to the
        # unmodified download below — byte-for-byte parity with today.
        try:
            from core.onprem_file_cache import cached_download
            _cached = cached_download(url, _cache_fetch_fn(download_url, url))
        except Exception:
            _cached = None
        if _cached is not None:
            return (idx, url, _cached[0])

        url_path = unquote(parsed.path)
        path_segs = url_path.lstrip("/").split("/", 1)
        rel_path = path_segs[1] if len(path_segs) > 1 else f"file_{idx}.parquet"

        local_file = os.path.normpath(os.path.join(temp_dir, rel_path))
        local_dir = os.path.dirname(local_file)
        if local_dir:
            os.makedirs(local_dir, exist_ok=True)

        if _http_pool is not None:
            # urllib3: reuses TCP+TLS connections across threads
            resp = _http_pool.request("GET", download_url, preload_content=False)
            try:
                if resp.status >= 400:
                    raise RuntimeError(f"HTTP {resp.status} downloading {url[:80]}")
                with open(local_file, "wb") as out:
                    shutil.copyfileobj(resp, out)
                resp.release_conn()
            except Exception:
                resp.close()
                raise
        else:
            # Fallback: stdlib urlopen (new TCP+TLS per request)
            req = Request(download_url, headers={"User-Agent": "QueryStudio/1.0"})
            with urlopen(req, context=ssl_ctx, timeout=120) as resp:
                with open(local_file, "wb") as out:
                    shutil.copyfileobj(resp, out)

        return (idx, url, local_file)

    try:
        # Phase 103-D: Parallel download via ThreadPoolExecutor
        import time as _dl_time
        from concurrent.futures import ThreadPoolExecutor, as_completed
        _dl_t0 = _dl_time.monotonic()

        _default_workers = 8
        try:
            from core.s3_utilities import _parallel_workers
            _default_workers = _parallel_workers()
        except Exception as _be_exc:
            note_best_effort("_parallel_workers()", _be_exc,
                             logger=logger)
        workers = min(len(urls), int(os.environ.get("QS_S3_PARALLEL_WORKERS", str(_default_workers))))

        # Create urllib3 connection pool — reuses TCP+TLS across threads.
        # 2026-06-18 -- SSL kwargs come from the central resolver.  Prior
        # code's "else: CERT_NONE" branch silently disabled verification
        # whenever ssl_verify=True (the default!) -- and ignored the
        # helm-deployed CA bundle.  Now via as_urllib3_kwargs:
        #   verify=ON + bundle  -> CERT_REQUIRED + ca_certs=<path>
        #   verify=ON + no path -> CERT_REQUIRED + system CA store
        #   verify=OFF          -> CERT_NONE  (explicit opt-out only)
        try:
            import urllib3
            from core.ssl_config import as_urllib3_kwargs
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            _pool_kw = {
                "num_pools": 4,
                "maxsize": max(workers, 1),
                "retries": urllib3.util.Retry(total=0),
                "timeout": urllib3.util.Timeout(connect=30, read=120),
                "headers": {"User-Agent": "QueryStudio/1.0"},
            }
            _pool_kw.update(as_urllib3_kwargs(_ssl_res))
            _http_pool = urllib3.PoolManager(**_pool_kw)
        except Exception as _be_exc:
            note_best_effort("urllib3.PoolManager(**_pool_kw)", _be_exc,
                             logger=logger)

        if workers <= 1:
            # Sequential fallback for single file
            for idx, url in enumerate(urls):
                try:
                    _, orig_url, local_file = _dl_one(idx, url)
                    temp_files.append(local_file)
                    # MAX_PATH-safe path conversion — see _to_duckdb_path docs
                    local_path = _to_duckdb_path(local_file)
                    modified_sql = modified_sql.replace(f"'{orig_url}'", f"'{local_path}'")
                except Exception as dl_err:
                    print(f"SUBPROCESS: pre-download FAILED for {url[:120]}: {dl_err}",
                          file=sys.stderr, flush=True)
                    raise RuntimeError(
                        f"Failed to download parquet from on-prem S3: {dl_err}"
                    ) from dl_err
                # Mid-flight headroom check — OUTSIDE the try above so its
                # RuntimeError keeps its own actionable message instead of
                # being re-wrapped as a generic download failure.  Raising
                # propagates to the outer except → temp_dir rmtree'd.
                _headroom_after_file(local_file)
        else:
            # Parallel download.  BF-591: explicit pool lifetime + cancel
            # propagation on error so a single failed download doesn't
            # block the parent's SIGTERM/SIGKILL wait on shutdown(wait=True).
            pool = ThreadPoolExecutor(max_workers=workers)
            _failed = False
            try:
                futures = {
                    pool.submit(_dl_one, idx, url): idx
                    for idx, url in enumerate(urls)
                }
                # Collect results (order doesn't matter — SQL replacement is string-based)
                for future in as_completed(futures):
                    fidx = futures[future]
                    try:
                        _, orig_url, local_file = future.result()
                        temp_files.append(local_file)
                        local_path = _to_duckdb_path(local_file)
                        modified_sql = modified_sql.replace(f"'{orig_url}'", f"'{local_path}'")
                    except Exception as dl_err:
                        _failed = True
                        print(f"SUBPROCESS: pre-download FAILED for {urls[fidx][:120]}: {dl_err}",
                              file=sys.stderr, flush=True)
                        raise RuntimeError(
                            f"Failed to download parquet from on-prem S3: {dl_err}"
                        ) from dl_err
                    # Mid-flight headroom check — mark _failed FIRST so the
                    # finally below cancels the still-queued futures instead
                    # of shutdown(wait=True)-ing them onto an already-full
                    # volume.  Raising propagates to the outer except →
                    # temp_dir rmtree'd.
                    try:
                        _headroom_after_file(local_file)
                    except RuntimeError:
                        _failed = True
                        raise
            finally:
                try:
                    if _failed:
                        # cancel_futures drops everything still QUEUED, so we
                        # never start new downloads onto a volume that just
                        # ran out.  But wait=True is required for the ones
                        # already RUNNING: the caller's except arm rmtree's
                        # temp_dir, and a worker still writing into it would
                        # re-create the directory a moment later (it makedirs
                        # its parent), leaving an orphan staging dir on the
                        # very volume the guard just fired to protect.
                        #
                        # 2026-08-04: this was wait=False, and that race is
                        # exactly what it produced -- reproducible as
                        # test_parallel_aborts_and_cleans_temp_dir, which
                        # failed while its sequential twin passed because
                        # sequential has no concurrent writer.
                        #
                        # The wait is BOUNDED by the in-flight count (at most
                        # `workers`), not by the queue, so the BF-591 concern
                        # this originally addressed -- shutdown(wait=True)
                        # blocking the parent's SIGTERM/SIGKILL on the whole
                        # remaining batch -- does not come back.  Each of
                        # those downloads carries its own 120s socket timeout.
                        pool.shutdown(wait=True, cancel_futures=True)
                    else:
                        pool.shutdown(wait=True)
                except Exception as _be_exc:
                    note_best_effort("pool.shutdown(wait=True, cancel_futures=True)", _be_exc,
                                     logger=logger)

        _dl_elapsed = _dl_time.monotonic() - _dl_t0
        # Phase 160 — S3 predownload time is s3 stage in the query's
        # latency breakdown.  This runs in the subprocess (separate
        # process from the query's ContextVar), so it's a no-op here
        # in-child; the parent process only sees the wall-clock via
        # ``timing`` in the return payload.  We attribute in the
        # parent below via the timing dict.
        _dl_total_mb = sum(
            os.path.getsize(f) for f in temp_files[1:]  # skip temp_dir entry
            if os.path.isfile(f)
        ) / 1024 / 1024
        print(f"SUBPROCESS: pre-download complete — {len(temp_files) - 1}/{len(urls)} files, "
              f"{_dl_total_mb:.1f} MB, {_dl_elapsed:.1f}s, {workers} workers"
              f"{', pooled' if _http_pool else ''}",
              file=sys.stderr, flush=True)
        if _http_pool is not None:
            try:
                _http_pool.clear()
            except Exception as _be_exc:
                note_best_effort("_http_pool.clear()", _be_exc,
                                 logger=logger)
    except Exception:
        if _http_pool is not None:
            try:
                _http_pool.clear()
            except Exception as _be_exc:
                note_best_effort("_http_pool.clear()", _be_exc,
                                 logger=logger)
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception as _be_exc:
            note_best_effort("shutil.rmtree(temp_dir, ignore_errors=True)", _be_exc,
                             logger=logger)
        raise

    return modified_sql, temp_files


def _derive_boto3_pool_size() -> int:
    """Pool size for any boto3 client we build in this subprocess.

    Matches the in-process ``s3_storage`` derivation: max(64, workers*2),
    floor 10 / cap 256.  Closes the "Connection pool size: 10" warning
    when N workers exceed the urllib3 default.  Returns 64 on any
    lookup failure (safe default for typical 15-30 file fan-outs)."""
    try:
        from core import config as _cfgm
        _pool_cfg = _cfgm.get("s3", "max_pool_connections", 0)
        if _pool_cfg:
            return max(10, min(int(_pool_cfg), 256))
    except Exception as _be_exc:
        note_best_effort("max(10, min(int(_pool_cfg), 256))", _be_exc,
                         logger=logger)
    try:
        from core.worker_pool import DEFAULT_TYPE_CONFIGS
        _tw = sum(int(getattr(c, "max_workers", 0) or 0)
                  for c in DEFAULT_TYPE_CONFIGS.values())
    except Exception:
        _tw = 30
    return max(10, min(max(64, _tw * 2), 256))


def _child_s3_credentials(conn_config: dict) -> tuple:
    """``(key, secret, token)`` the child signs with -- through THE
    credential chain (``core.credential_resolver.resolve_s3_keys``), the
    same one the parent and the query builder run.

    2026-10-26 -- the child carried its OWN STS / profile copy (one of
    four), dispatching on ``auth_mode`` alone: no system account, no
    portal, its own on-prem rule.  The parent resolves portal / vault
    keys before the child starts (they arrive as ``keys``); a profile or
    role is resolved HERE because STS must run in the process that
    signs.  A failure prints and yields empty keys: the read then fails
    at the wire naming its cause, never with someone else's identity.
    """
    try:
        from core.credential_resolver import resolve_s3_keys
        return resolve_s3_keys(conn_config)
    except Exception as exc:
        print(f"WARNING: credential resolution failed: {exc}", file=sys.stderr, flush=True)
        return "", "", ""


def _rewrite_s3_urls_to_presigned_for_vpc(
    setup_sql: str, conn_config: dict,
    key: str, secret: str, token: str, region: str, ep: str,
):
    """Strategic VPC primary path: rewrite ``s3://...`` URLs in
    ``setup_sql`` to presigned ``https://...`` URLs so DuckDB httpfs
    reads directly via the VPC interface endpoint.

    Why this exists (replaces VPC pre-download):
      * User has a VPC interface endpoint to AWS S3 ("if we got VPC
        link why we will download file locally?").
      * Native DuckDB httpfs against path_style URLs URL-encodes ``=``
        in hive-partition segments — breaks SigV4 canonical request →
        SignatureDoesNotMatch 403.  This is the libcurl URL-encoding
        bug.
      * boto3 signs the URL ONCE on this side (no libcurl in the
        signing path → no encoding bug).  The resulting presigned URL
        is a flat HTTPS GET.  DuckDB httpfs makes plain HTTP requests
        against it — no signing, no encoding bug, traffic flows over
        VPC.
      * NO files are downloaded.  NO temp files.  NO disk pressure.
        Lazy read: DuckDB only fetches the parquet bytes it actually
        scans (footer + row groups it needs).

    On-prem note: this helper is ONLY called when the endpoint matches
    AWS's VPC interface pattern (``.vpce.amazonaws.com``).  On-prem +
    Hive metastore paths never reach here — they use native httpfs
    against the on-prem S3 hostname directly.

    Returns the rewritten ``setup_sql``.  Empty list returned alongside
    keeps the call-site signature parallel with ``_pre_download_*``.
    """
    import re as _re
    import boto3 as _boto3
    from botocore.config import Config as BotoConfig

    s3_re = _re.compile(r"'(s3://[^']+)'")
    urls = list(dict.fromkeys(s3_re.findall(setup_sql)))
    if not urls:
        return setup_sql, []

    # Use the central SSL resolver (same one the download path uses) —
    # bundle auto-detection / explicit insecure / system CA all routed
    # through one decision point.
    from core.ssl_config import resolve_ssl, as_boto3_verify, describe
    _ssl_res = resolve_ssl(conn_config.get("ssl_verify", True))
    verify = as_boto3_verify(_ssl_res)
    print(
        f"SUBPROCESS: VPC presigned-URL rewrite — {describe(_ssl_res)}",
        file=sys.stderr, flush=True,
    )

    # Pool size derived from worker count (NOT urllib3 default of 10).
    # The presigned generation is local-only (no S3 round-trip per
    # generate_presigned_url) so 64 is more than enough, but keeping
    # the derivation aligned with download paths means a single config
    # knob (s3.max_pool_connections) controls every boto3 client we
    # build in this subprocess.
    _pool = _derive_boto3_pool_size()
    # 2026-06-23 — force SigV4 explicitly.  We're in the VPC code
    # path; VPC endpoints REQUIRE SigV4 and boto3's default with
    # ``endpoint_url=vpce-*`` can fall back to SigV2 (the legacy
    # AWSAccessKeyId/Signature/Expires form), which VPC will 403.
    # 2026-06-24 -- single chokepoint for boto3 S3 config kwargs.
    # build_boto3_s3_config_kwargs honours operator's addressing_style
    # override AND forces SigV4 -- both required for VPC.  Every
    # boto3.client('s3', ...) site in the codebase goes through here
    # so no client can silently diverge.
    # 2026-06-24 strategic fix -- operator-confirmed on the pod that
    # AWS S3 VPCE for bucket data requires the ``bucket.``-prefixed
    # sub-domain (cert SANs only cover ``bucket.vpce-XXX...``, NOT
    # the generic ``vpce-XXX...`` form most operators enter).  We
    # normalise transparently AND force path-style addressing per
    # the operator's verified working ``boto3 list_objects_v2`` call.
    try:
        from core.ssl_config import normalize_vpce_endpoint_for_s3_data
        _ep_normalised = normalize_vpce_endpoint_for_s3_data(ep)
    except Exception:
        _ep_normalised = ep
    _ep_is_vpce_for_cfg = (
        bool(ep) and ".vpce.amazonaws.com" in (ep or "").lower())
    if _ep_is_vpce_for_cfg:
        # Force path-style addressing -- AWS S3 VPCE rejects virtual-
        # hosted requests against ``bucket.vpce-XXX...`` (the bucket
        # name lives in the URL PATH, not the host).
        _shared_cfg = {
            "signature_version": "s3v4",
            "s3": {"addressing_style": "path"},
        }
    else:
        try:
            from core.s3_storage import build_boto3_s3_config_kwargs as _bccfg
            _shared_cfg = _bccfg({
                "addressing_style": conn_config.get("addressing_style"),
                "path_style": conn_config.get("path_style", False),
                "endpoint_url": ep,
            })
        except Exception:
            _shared_cfg = {"signature_version": "s3v4"}
    _boto_cfg = BotoConfig(
        connect_timeout=30, read_timeout=60,
        retries={"max_attempts": 3, "mode": "adaptive"},
        max_pool_connections=_pool,
        **_shared_cfg,
    )

    client_kw: dict = {
        "service_name": "s3", "region_name": region,
        "verify": verify, "config": _boto_cfg,
    }
    if key:
        client_kw["aws_access_key_id"] = key
    if secret:
        client_kw["aws_secret_access_key"] = secret
    if token:
        client_kw["aws_session_token"] = token
    # 2026-06-24 -- single chokepoint: use the normalized VPCE
    # endpoint (``bucket.vpce-XXX...``) when the operator entered the
    # generic form.  ``normalize_vpce_endpoint_for_s3_data`` is the
    # ONLY place that knows about the bucket-prefix rule -- no other
    # site in the codebase reinvents it.
    if _ep_normalised:
        client_kw["endpoint_url"] = _ep_normalised
        if _ep_normalised != ep:
            print(
                f"SUBPROCESS: VPCE endpoint normalised "
                f"({(ep or '').lower()} -> {_ep_normalised.lower()}) "
                f"-- bucket-data sub-domain whose TLS cert AWS designed "
                f"for S3 bucket access.  Set QS_VPCE_AUTO_BUCKET_PREFIX=0 "
                f"to disable.",
                file=sys.stderr, flush=True,
            )

    s3 = _boto3.client(**client_kw)
    try:
        modified_sql = setup_sql
        # 2026-06-23 — bumped default 3600 -> 21600 (6 hours).  DuckDB
        # reads parquet files LAZILY as it scans, so the URL must stay
        # valid for the entire scan duration.  Large iceberg scans
        # (10K+ files, multi-GB) can exceed 1h.  6h covers the slow-
        # query case with margin; AWS allows up to 7 days.  Operators
        # set ``QS_VPC_PRESIGNED_TTL_SECONDS`` to a smaller value to
        # tighten the leaked-URL blast radius.
        _expiry_seconds = int(
            os.environ.get("QS_VPC_PRESIGNED_TTL_SECONDS", "21600"))
        # 2026-06-24 -- decode `%3D` -> `=` in PATH portion only.
        # boto3 URL-encodes `=` in hive-partition path segments
        # (e.g. business_close_date=2025-09-30 -> business_close_date
        # %3D2025-09-30).  DuckDB httpfs's libcurl then double-encodes
        # `%3D` -> `%253D` when sending the request, which makes the
        # canonical request AWS reconstructs differ from what boto3
        # signed -> 403 SignatureDoesNotMatch (or HTTP 0 when
        # libcurl chokes earlier).  The parent-process helper
        # ``core.s3_utilities._sign_one_url`` does this same decode
        # already; the subprocess copy was missing it.  Leave the
        # query string UNTOUCHED -- it carries the signature and must
        # remain exactly as boto3 emitted it.
        from urllib.parse import urlparse, urlunparse, unquote as _unq
        for url in urls:
            stripped = url[len("s3://"):]
            parts = stripped.split("/", 1)
            bucket = parts[0]
            object_key = parts[1] if len(parts) > 1 else ""
            ps = s3.generate_presigned_url(
                "get_object",
                Params={"Bucket": bucket, "Key": object_key},
                ExpiresIn=_expiry_seconds,
            )
            try:
                _parsed = urlparse(ps)
                _decoded_path = _unq(_parsed.path)
                if _decoded_path != _parsed.path:
                    ps = urlunparse((
                        _parsed.scheme, _parsed.netloc, _decoded_path,
                        _parsed.params, _parsed.query, _parsed.fragment,
                    ))
            except Exception as _be_exc:
                # If the decode somehow fails, fall back to the raw
                # boto3 URL.  Worst case: libcurl re-encode bug; not
                # worse than the prior behaviour.
                note_best_effort("urlunparse(...)", _be_exc,
                                 logger=logger)
            modified_sql = modified_sql.replace(f"'{url}'", f"'{ps}'")
    finally:
        try:
            s3.close()
        except Exception as _be_exc:
            note_best_effort("s3.close()", _be_exc,
                             logger=logger)

    print(
        f"SUBPROCESS: VPC presigned-URL rewrite complete — "
        f"{len(urls)} URL(s) rewritten (DuckDB httpfs reads via VPC, "
        f"no local download)",
        file=sys.stderr, flush=True,
    )
    return modified_sql, []


def _pre_download_s3_via_boto3(setup_sql: str, conn_config: dict,
                                key: str, secret: str, token: str,
                                region: str, ep: str):
    """Download s3:// parquet files via boto3 when DuckDB httpfs cannot reach
    S3 through a corporate proxy (HTTP 503).

    boto3 uses Python's urllib3 which handles proxy auth correctly.
    DuckDB's libcurl-based httpfs gets rejected by some corporate proxies.

    Preserves hive partition directory structure so DuckDB's
    ``hive_partitioning=true`` can still extract partition column values.

    Returns ``(modified_sql, list_of_temp_paths)`` — first entry in the list
    is the temp directory root (for ``shutil.rmtree`` cleanup).
    """
    import re as _re

    # Find 's3://bucket/key' URLs in the SQL
    s3_re = _re.compile(r"'(s3://[^']+)'")
    urls = list(dict.fromkeys(s3_re.findall(setup_sql)))
    if not urls:
        return setup_sql, []

    # Create boto3 S3 client with proxy config (same path that works for
    # schema refresh / iceberg metadata listing)
    import boto3
    from botocore.config import Config as BotoConfig
    from core.proxy_utils import get_boto_proxies

    # Suppress urllib3 InsecureRequestWarning spam when proxy uses verify=False
    import urllib3 as _ul3
    _ul3.disable_warnings(_ul3.exceptions.InsecureRequestWarning)

    # 2026-06-18 -- boto3 SSL config now routes through the central
    # resolver too (same fix as the presigned path).  The prior inline
    # parsing didn't auto-detect the helm-deployed backend/certs/
    # tls_bundle.pem -- when ssl_verify=True (default) it passed
    # verify=True to boto3 which uses the system CA store and IGNORES
    # any cluster CA the helm chart drops in.  Now via as_boto3_verify:
    #   ssl_verify=True + bundle exists -> verify=<bundle path>
    #   ssl_verify=True + no bundle     -> verify=True (system CA)
    #   ssl_verify=<path>               -> verify=<that path>
    #   ssl_verify=False                -> verify=False (explicit insecure)
    from core.ssl_config import resolve_ssl, as_boto3_verify, describe
    _ssl_res = resolve_ssl(conn_config.get("ssl_verify", True))
    verify = as_boto3_verify(_ssl_res)
    print(f"SUBPROCESS: boto3 pre-download -- {describe(_ssl_res)}",
          file=sys.stderr, flush=True)

    _px = get_boto_proxies(endpoint_url=ep)
    # Production timeout + adaptive retries for transient S3 errors
    # (503 SlowDown, RequestLimitExceeded, network blips)
    _dl_timeout = int(os.environ.get("QS_S3_DOWNLOAD_TIMEOUT", "120"))
    _max_attempts = int(os.environ.get("QS_S3_DOWNLOAD_RETRIES", "3"))
    _boto_kw = {
        "connect_timeout": 30,
        "read_timeout": _dl_timeout,
        "retries": {"max_attempts": _max_attempts, "mode": "adaptive"},
        # Without an explicit pool size, urllib3 defaults to 10 ->
        # "Connection pool is full, discarding connection" spam +
        # serialised fetches when N workers exceed 10.  Same derivation
        # as the in-process s3_storage client + the VPC presigned helper
        # so one config knob covers every boto3 client we build.
        "max_pool_connections": _derive_boto3_pool_size(),
    }
    if _px:
        _boto_kw["proxies"] = _px
    # 2026-06-24 -- same shared chokepoint as the VPC presign helper.
    try:
        from core.s3_storage import build_boto3_s3_config_kwargs as _bccfg2
        _boto_kw.update(_bccfg2({
            "addressing_style": conn_config.get("addressing_style"),
            "path_style": conn_config.get("path_style", False),
            "endpoint_url": ep,
        }))
    except Exception as _be_exc:
        note_best_effort("_boto_kw.update(...)", _be_exc,
                         logger=logger)
    _boto_cfg = BotoConfig(**_boto_kw)

    client_kw = {"service_name": "s3", "region_name": region, "verify": verify,
                  "config": _boto_cfg}
    if key:
        client_kw["aws_access_key_id"] = key
    if secret:
        client_kw["aws_secret_access_key"] = secret
    if token:
        client_kw["aws_session_token"] = token
    if ep:
        client_kw["endpoint_url"] = ep

    s3_client = boto3.client(**client_kw)
    modified_sql = setup_sql

    # BF-416 — delegate the actual parallel download to the unified
    # ``core.s3_predownload`` utility.  Preserves behaviour parity with
    # the parent-process path (duckdb_views._s3_to_local_via_boto3) — same
    # workers, same retry, same atomic-rename, same cache hookup, same
    # disk guard.  This subprocess copy used to drift from the parent
    # (each fix had to be applied twice, sometimes only one site got it);
    # now there's one implementation.
    #
    # Note: this migration drops the Phase 134-D ``S3FileCache`` lookup
    # that previously fired only on the subprocess path.  The BF-257
    # ``s3_local_cache`` used by the unified utility is the primary
    # disk-backed cache; the Phase 134-D layer was an orthogonal
    # ETag-validated cache that was never wired into the parent path.
    # If your deployment relies on Phase 134-D, set
    # ``s3_local_cache.enabled=true`` to use the unified cache; both
    # provide path-keyed disk caching, the unified one with simpler
    # eviction (LRU-by-mtime, see scheduler).
    try:
        from core.s3_predownload import (
            predownload_s3_files as _predownload,
            resolve_predownload_config as _resolve_pd_cfg,
        )
        _pd_cfg = _resolve_pd_cfg()

        def _on_progress(done: int, total: int, _bytes: int):
            if done % max(1, total // 10) == 0 or done == total:
                print(f"SUBPROCESS: boto3 download progress {done}/{total}",
                      file=sys.stderr, flush=True)

        # BF-418 — ExpiredToken hook.  In the subprocess we can't reach
        # the parent's connection_manager (separate process, separate
        # handler cache), so the callback just logs to stderr.  The parent
        # process's _on_expired_token (in duckdb_views.py) handles the
        # actual handler invalidation when the parent path is taken.  The
        # subprocess error message bubbles up via _write_result anyway and
        # the caller can recheck creds at that point.
        def _on_expired_token(_exc):
            print(
                f"SUBPROCESS: boto3 ExpiredToken — parent must refresh STS "
                f"creds before next query: {type(_exc).__name__}",
                file=sys.stderr, flush=True,
            )

        result = _predownload(
            s3_client, list(urls), cfg=_pd_cfg,
            progress_callback=_on_progress,
            is_cancelled=None,  # subprocess gets killed on cancel; no event lookup
            on_expired_token=_on_expired_token,
        )

        # Rewrite SQL: replace each s3:// URL with its local path.
        # The utility returns local_paths in the same order as input urls.
        #
        # WINDOWS MAX_PATH FIX: Iceberg hive partition layouts (e.g.
        # ``business_close_date=YYYY-MM-DD/code=ABC/businessevent=XYZ/``)
        # routinely produce 260+ char local paths once joined with the
        # temp_dir + bucket + parquet UUID filename.  ``_download_one_with_retry``
        # already creates such files via the ``\\?\`` long-path prefix so
        # they EXIST on disk — but DuckDB's Windows file-IO applies the
        # plain MAX_PATH limit when given a non-prefixed path and fails
        # with "No files found that match the pattern".  Give it the
        # prefixed path on Windows when length warrants it.  Forward-
        # slash conversion is still applied so DuckDB's SQL parser
        # doesn't trip on backslash escaping.
        for url, local_file in zip(urls, result.local_paths):
            local_path = _to_duckdb_path(local_file)
            modified_sql = modified_sql.replace(f"'{url}'", f"'{local_path}'")

        # ``temp_files`` historical contract: [temp_dir, local_path_1, ...]
        # (legacy callers use the first entry for shutil.rmtree on cleanup;
        # cache mode returns temp_dir=None and the cleanup is skipped).
        temp_files = [result.temp_dir] if result.temp_dir else []
        temp_files.extend(result.local_paths)

        print(f"SUBPROCESS: boto3 pre-download complete — "
              f"{result.files_succeeded} file(s), "
              f"{result.workers_used} workers, "
              f"{result.duration_seconds:.1f}s "
              f"({result.cached_hits} cache hit{'s' if result.cached_hits != 1 else ''}, "
              f"{result.bytes_downloaded / 1024 / 1024:.1f} MB)",
              file=sys.stderr, flush=True)
    finally:
        try:
            s3_client.close()
        except Exception as _close_exc:
            print(f"SUBPROCESS: boto3 client close warning: {_close_exc}",
                  file=sys.stderr, flush=True)

    return modified_sql, temp_files



# ═══════════════════════════════════════════════════════════════════════════════
# Phase 3 (2026-08-22, design_s3_speed §4) — pool-worker persistent DuckDB
# DatabaseInstance.
#
# WHY.  DuckDB's remote-file caches (external file cache, HTTP metadata
# cache, parsed parquet-footer cache) live on the DatabaseInstance.  With a
# fresh ``:memory:`` instance per request — even inside a warm pool worker —
# every query re-reads every surviving parquet footer: measured at the
# operator's incident scale, ~108 s per warm repeat through a proxy.  Keeping
# ONE instance alive across requests is the only way those caches can
# survive, so that is what this block does — under proofs, never on trust:
#
#   * The instance is keyed by a CONNECTION FINGERPRINT (canonical
#     conn_config + resource env + duckdb version).  A request for any other
#     connection DROPS the instance — two connections may hold different S3
#     credentials for overlapping paths, and a shared byte cache would let
#     connection B read blocks connection A was authorised to fetch.
#   * Each request runs on a FRESH CURSOR (DuckDB session).  Measured on
#     duckdb 1.5.2: legacy ``SET s3_*`` credentials are session-scoped (a
#     sibling cursor observes NULL and ``duckdb_secrets()`` stays empty),
#     TEMP tables die with the session.  Catalog objects (views/tables/
#     macros/types/sequences/secrets/attached DBs) DO outlive the cursor —
#     so between requests the catalog is WIPED and then VERIFIED empty by
#     COUNT; if the count is not zero, or the wipe errors, the instance is
#     closed instead of stashed.  Not-proven-clean ⇒ not reused.  A wipe
#     bug can therefore only cost performance, never isolation.
#   * Reuse applies ONLY to the native-S3 plan.  Presigned/LOCAL_FILES
#     plans read per-request local temp files — nothing to cache, and the
#     unique temp paths would only pollute the instance.
#   * Any request ERROR drops the instance (self-heal: rotated credentials,
#     an in-place-overwritten file poisoning a cached footer, or any state
#     doubt at all — the next request builds fresh, exactly like today).
#   * A hard age bound (QS_DUCKDB_POOL_DB_MAX_AGE_S) drops the instance
#     regardless of health — a throttle on staleness exposure.
#
# Cache-trust policy (QS_DUCKDB_POOL_CACHE_MODE, stamped by the pool from
# ``duckdb_pool.metadata_cache_mode``):
#   revalidate — enable_http_metadata_cache=false, parquet_metadata_cache=
#                false.  The external file cache (default ON, VALIDATE_ALL)
#                still serves cached bytes AFTER one HEAD proves the ETag
#                unchanged.  Measured: 1 HEAD + 2 GETs per file per query →
#                1 HEAD on repeats; an overwritten file serves FRESH data.
#   full       — both caches ON: repeats issue ZERO requests per file.
#                An overwritten file fails LOUDLY ("no magic bytes"), never
#                serves stale — and the error drops the instance, so the
#                retry succeeds.
#   auto       — "full" only when the parent stamped plan_all_iceberg=True
#                (every registered table on the request is Iceberg; Iceberg
#                data files are immutable by format), else "revalidate".
# ═══════════════════════════════════════════════════════════════════════════════

_POOL_DB = {"root": None, "fingerprint": None, "created_ts": 0.0,
            "poisoned": False}


def _pool_db_reuse_enabled() -> bool:
    return (os.environ.get("DUCKDB_SUBPROCESS_POOL") == "1"
            and (os.environ.get("QS_DUCKDB_POOL_DB_REUSE", "") or "").strip()
            == "1")


def _pool_db_cache_mode() -> str:
    m = (os.environ.get("QS_DUCKDB_POOL_CACHE_MODE", "") or "").strip().lower()
    # Unknown/absent degrades toward SAFETY (revalidate), never trust.
    return m if m in ("auto", "revalidate", "full") else "revalidate"


def _pool_db_max_age_s() -> float:
    try:
        v = float(os.environ.get("QS_DUCKDB_POOL_DB_MAX_AGE_S", "") or 3600.0)
    except (TypeError, ValueError):
        return 3600.0
    # <=0 is INVALID (never "unlimited") -> default.
    return v if v > 0 else 3600.0


def _pool_db_fingerprint(conn_config: dict) -> str:
    """Identity of the S3 world this instance's caches were filled under.
    Empty string means "cannot fingerprint" -> no reuse (fail-safe)."""
    import hashlib
    try:
        cc = json.dumps(conn_config or {}, sort_keys=True, default=str)
    except Exception:
        return ""
    env_bits = "|".join(
        f"{k}={os.environ.get(k, '')}"
        for k in ("DUCKDB_MEMORY_LIMIT", "DUCKDB_THREADS",
                  "QS_DUCKDB_CONCURRENT_CHILDREN"))
    try:
        import duckdb as _dd_fp          # lazy: parent imports this module
        ver = _dd_fp.__version__
    except Exception:
        ver = "?"
    return hashlib.sha256(
        f"{cc}\x00{env_bits}\x00{ver}".encode("utf-8", "replace")
    ).hexdigest()


def _pool_db_drop(reason: str = "") -> None:
    _pending = _POOL_DB.pop("pending_release", None)
    if _pending:
        for _h in _pending:
            try:
                _h.close()
            except Exception as _be_exc:
                note_best_effort("_h.close()", _be_exc,
                                 logger=logger)
    root = _POOL_DB.get("root")
    _POOL_DB["root"] = None
    _POOL_DB["fingerprint"] = None
    _POOL_DB["created_ts"] = 0.0
    _POOL_DB["poisoned"] = False
    if root is not None:
        if reason:
            print(f"SUBPROCESS: pool DB instance DROPPED ({reason})",
                  file=sys.stderr, flush=True)
        try:
            root.close()
        except Exception as _be_exc:
            note_best_effort("root.close()", _be_exc,
                             logger=logger)


def _pool_db_finish_request() -> None:
    """Run the deferred end-of-request release: close the request's
    session, wipe + VERIFY the shared catalog, stash only when proven
    clean.  Called by the pool worker loop AFTER the ack — the parent
    already has its result, so the ~36 ms wipe (measured; dominated by
    duckdb_functions() scanning every built-in) costs the query nothing.
    Also drained self-healingly at the next acquire, so a caller that
    never runs the loop (in-process tests) cannot leak an unreleased
    instance — and by the checkout invariant the STASH stays empty until
    this ran, so a skipped release can only cost a rebuild, never hand
    over a dirty catalog."""
    _pending = _POOL_DB.pop("pending_release", None)
    if _pending:
        _pool_db_release(_pending[0], _pending[1])


def _pool_db_acquire(conn_config: dict):
    """Return ``(cursor, root, reused)`` when persistent-instance reuse
    applies to this request, else ``(None, None, False)`` (caller falls
    back to the legacy fresh ``:memory:`` connect — today's behaviour)."""
    if not _pool_db_reuse_enabled():
        return None, None, False
    try:
        # Settle any deferred release FIRST (normally the worker loop
        # already did, right after the previous ack).
        _pool_db_finish_request()
        try:
            mode = get_s3_access_mode(conn_config or {})
        except Exception:
            mode = "presigned"          # unknowable -> treat as no-reuse
        if mode != "native":
            _pool_db_drop("non-native plan")
            return None, None, False
        fp = _pool_db_fingerprint(conn_config)
        if not fp:
            _pool_db_drop("unfingerprintable conn_config")
            return None, None, False
        import time as _pt
        root = _POOL_DB.get("root")
        if root is not None:
            age = _pt.monotonic() - float(_POOL_DB.get("created_ts") or 0.0)
            if _POOL_DB.get("fingerprint") != fp:
                _pool_db_drop("connection fingerprint changed")
                root = None
            elif age > _pool_db_max_age_s():
                _pool_db_drop(f"max age exceeded ({age:.0f}s)")
                root = None
        if root is not None:
            # CHECKOUT: take the instance OUT of the stash for the
            # duration of the request.  The stash-empty state is what
            # makes a crashed / interrupted request unable to hand a
            # dirty catalog to its successor — only _pool_db_release can
            # put an instance back, and only after the wipe PROVED the
            # catalog empty.
            _POOL_DB["root"] = None
            try:
                cur = root.cursor()
                print("SUBPROCESS: pool DB instance REUSED "
                      "(fingerprint match) -- remote-file caches are warm",
                      file=sys.stderr, flush=True)
                return cur, root, True
            except Exception as exc:
                print(f"SUBPROCESS: pool DB cursor open failed ({exc}) -- "
                      f"building fresh", file=sys.stderr, flush=True)
                try:
                    root.close()
                except Exception as _be_exc:
                    note_best_effort("root.close()", _be_exc,
                                     logger=logger)
        import duckdb                    # lazy: never at parent import time
        root = duckdb.connect(database=":memory:")
        cur = root.cursor()
        # NOT stashed here — see the checkout invariant above.  The
        # fingerprint/birth stamps ride the module dict so release can
        # re-stash without re-deriving them.
        _POOL_DB["fingerprint"] = fp
        _POOL_DB["created_ts"] = _pt.monotonic()
        _POOL_DB["poisoned"] = False
        return cur, root, False
    except Exception as exc:
        print(f"SUBPROCESS: pool DB reuse unavailable "
              f"(fail-safe fresh instance): {exc}",
              file=sys.stderr, flush=True)
        _pool_db_drop()
        return None, None, False


def _pool_db_apply_cache_policy(con, args: dict) -> None:
    """State THIS request's metadata-cache trust explicitly (the settings
    are instance-global on a shared DatabaseInstance, so silence would
    inherit the PREVIOUS request's policy).  If the safety-critical
    downgrade (revalidate) cannot be applied, the instance is POISONED:
    it will not be stashed after this request."""
    full = False
    mode = _pool_db_cache_mode()
    if mode == "full":
        full = True
    elif mode == "auto":
        full = bool(args.get("plan_all_iceberg") is True)
    try:
        con.execute(f"SET enable_http_metadata_cache="
                    f"{'true' if full else 'false'};")
        con.execute(f"SET parquet_metadata_cache="
                    f"{'true' if full else 'false'};")
        print(f"SUBPROCESS: pool cache policy: "
              f"{'full' if full else 'revalidate'} (mode={mode}, "
              f"plan_all_iceberg={args.get('plan_all_iceberg')!r})",
              file=sys.stderr, flush=True)
    except Exception as exc:
        # Could not PROVE the policy applied.  In 'revalidate' intent this
        # could leave a previous 'true' live — so refuse to keep the
        # instance past this request.  Never silent.
        _POOL_DB["poisoned"] = True
        print(f"SUBPROCESS: pool cache policy FAILED to apply ({exc}) -- "
              f"instance poisoned, will be dropped after this request",
              file=sys.stderr, flush=True)


def _pool_db_wipe_and_verify(root) -> bool:
    """Drop every user-visible object from the persistent instance, then
    PROVE the catalog is empty by COUNT.  True == provably clean (stash
    allowed); False == anything unexpected at all (caller must drop).

    The proof direction is the contract: a bug here can only cause a
    False (instance dropped, performance lost), never a stale/foreign
    object surviving into the next request."""
    try:
        cur = root.cursor()
        try:
            # ONE enumeration query instead of eight (measured: the wipe
            # cost 36 ms/request, almost all of it per-query overhead on
            # the catalog functions).  Drops are then targeted per object.
            # Order matters: foreign DATABASEs detach first, secrets next,
            # whole non-internal SCHEMAs go with CASCADE (taking their
            # contents), then per-object drops in what remains.
            _objs = cur.execute(
                "SELECT 'database' AS kind, '' AS sch, database_name AS nm"
                " FROM duckdb_databases() WHERE NOT internal"
                "  AND database_name NOT IN ('memory','temp','system') "
                "UNION ALL SELECT 'secret', '', name FROM duckdb_secrets() "
                "UNION ALL SELECT 'schema', '', schema_name"
                " FROM duckdb_schemas() WHERE NOT internal"
                "  AND database_name = 'memory' AND schema_name <> 'main' "
                "UNION ALL SELECT 'view', schema_name, view_name"
                " FROM duckdb_views() WHERE NOT internal "
                "UNION ALL SELECT 'table', schema_name, table_name"
                " FROM duckdb_tables() WHERE NOT internal "
                "UNION ALL SELECT 'sequence', schema_name, sequence_name"
                " FROM duckdb_sequences() "
                "UNION ALL SELECT CASE WHEN function_type = 'table_macro'"
                "  THEN 'macro_table' ELSE 'macro' END,"
                "  schema_name, function_name"
                " FROM duckdb_functions() WHERE NOT internal"
                "  AND function_type IN ('macro','table_macro') "
                "UNION ALL SELECT 'type', schema_name, type_name"
                " FROM duckdb_types() WHERE NOT internal"
            ).fetchall()
            _order = {"database": 0, "secret": 1, "schema": 2, "view": 3,
                      "table": 4, "sequence": 5, "macro": 6,
                      "macro_table": 7, "type": 8}
            _dropped_schemas = set()
            for kind, sch, name in sorted(
                    _objs, key=lambda r: _order.get(r[0], 9)):
                if kind == "database":
                    cur.execute(f'DETACH DATABASE "{name}"')
                elif kind == "secret":
                    cur.execute(f'DROP SECRET IF EXISTS "{name}"')
                elif kind == "schema":
                    cur.execute(f'DROP SCHEMA "{name}" CASCADE')
                    _dropped_schemas.add(name)
                elif sch in _dropped_schemas:
                    continue           # went with its schema CASCADE
                elif kind == "view":
                    cur.execute(
                        f'DROP VIEW IF EXISTS "{sch}"."{name}" CASCADE')
                elif kind == "table":
                    cur.execute(
                        f'DROP TABLE IF EXISTS "{sch}"."{name}" CASCADE')
                elif kind == "sequence":
                    cur.execute(
                        f'DROP SEQUENCE IF EXISTS "{sch}"."{name}"')
                elif kind == "macro":
                    cur.execute(f'DROP MACRO IF EXISTS "{sch}"."{name}"')
                elif kind == "macro_table":
                    cur.execute(
                        f'DROP MACRO TABLE IF EXISTS "{sch}"."{name}"')
                elif kind == "type":
                    cur.execute(f'DROP TYPE IF EXISTS "{sch}"."{name}"')
            # Restore instance-global spill dir to default; each request
            # sets its own before running.
            try:
                cur.execute("RESET temp_directory")
            except Exception as _be_exc:
                note_best_effort("cur.execute('RESET temp_directory')", _be_exc,
                                 logger=logger)
            # ── THE PROOF ─────────────────────────────────────────────
            leftovers = cur.execute(
                "SELECT"
                " (SELECT count(*) FROM duckdb_views() WHERE NOT internal)"
                "+(SELECT count(*) FROM duckdb_tables() WHERE NOT internal)"
                "+(SELECT count(*) FROM duckdb_sequences())"
                "+(SELECT count(*) FROM duckdb_functions()"
                "  WHERE NOT internal"
                "  AND function_type IN ('macro','table_macro'))"
                "+(SELECT count(*) FROM duckdb_types() WHERE NOT internal)"
                "+(SELECT count(*) FROM duckdb_secrets())"
                "+(SELECT count(*) FROM duckdb_schemas()"
                "  WHERE NOT internal AND database_name = 'memory'"
                "  AND schema_name <> 'main')"
                "+(SELECT count(*) FROM duckdb_databases()"
                "  WHERE NOT internal AND database_name NOT IN"
                "  ('memory','temp','system'))").fetchone()[0]
            return int(leftovers) == 0
        finally:
            try:
                cur.close()
            except Exception as _be_exc:
                note_best_effort("cur.close()", _be_exc,
                                 logger=logger)
    except Exception as exc:
        print(f"SUBPROCESS: pool DB wipe/verify errored ({exc}) -- "
              f"instance will be dropped (fail-safe)",
              file=sys.stderr, flush=True)
        return False


def _pool_db_release(request_cursor, root) -> None:
    """End-of-request (SUCCESS path only): close the request's session,
    then wipe + verify the shared catalog.  Proven clean -> the instance
    stays stashed for the next request; anything else -> dropped."""
    try:
        request_cursor.close()
    except Exception as _be_exc:
        note_best_effort("request_cursor.close()", _be_exc,
                         logger=logger)
    if _POOL_DB.get("poisoned"):
        _POOL_DB["poisoned"] = False
        print("SUBPROCESS: pool DB instance DROPPED (cache policy could "
              "not be proven this request)", file=sys.stderr, flush=True)
        try:
            root.close()
        except Exception as _be_exc:
            note_best_effort("root.close()", _be_exc,
                             logger=logger)
        return
    if not _pool_db_wipe_and_verify(root):
        print("SUBPROCESS: pool DB instance DROPPED (post-request wipe "
              "could not prove a clean catalog)", file=sys.stderr, flush=True)
        try:
            root.close()
        except Exception as _be_exc:
            note_best_effort("root.close()", _be_exc,
                             logger=logger)
        return
    # THE ONLY STASH SITE: the catalog was just PROVEN empty.
    _POOL_DB["root"] = root
    print("SUBPROCESS: pool DB instance stashed (catalog proven clean)",
          file=sys.stderr, flush=True)


# ═══════════════════════════════════════════════════════════════════════════════
# CLI entry point — runs in the CHILD process
# ═══════════════════════════════════════════════════════════════════════════════

def _child_main(args_path=None, result_path=None):
    """Execute ONE DuckDB COPY-TO request in this process.

    Two entry modes:
      * Legacy (one process per query): invoked as
        ``python -m core.duckdb_subprocess <args.json> <result.json>``;
        ``args_path``/``result_path`` default to ``sys.argv[1:3]``.
      * Pool (Phase 168c): the warm worker calls this with explicit paths
        once per request.  Each call opens its OWN fresh ``:memory:``
        connection (isolation by construction -- no cross-request state).

    On query error it writes an error result and ``sys.exit(1)`` (legacy
    contract); the pool worker loop catches that ``SystemExit`` and keeps
    serving, since the error result is already on disk.
    """
    import time as _t

    _t0 = _t.monotonic()
    # 2026-08-22 — wall-clock twin of _t0, taken at the same instant, so the
    # spawn+boot span (parent's stamp -> here) can be computed after the args
    # file is read.  Same host as the parent, so time.time() is comparable.
    _t0_wall = _t.time()

    import duckdb

    # Pre-flight visibility: log the version <-> bundled-extension dir
    # status BEFORE anything else.  When extensions are missing or version-
    # mismatched, the existing LOAD-failure path emits a clear message;
    # this pre-flight makes the mismatch visible IMMEDIATELY so operators
    # spot the drift in pod boot logs instead of in query-failure traces.
    try:
        _dd_ver = getattr(duckdb, "__version__", "?")
        _pf_primary = os.environ.get("DUCKDB_EXTENSION_DIR", "").strip()
        _pf_fallback = os.environ.get("DUCKDB_EXTENSION_FALLBACK_DIR", "").strip()
        _pf_checked = []
        _pf_found_dir = None
        for _pf_dir in (_pf_primary, _pf_fallback,
                        "/opt/duckdb_extensions",
                        "/usr/local/querystudioapi/duckdb_extensions",
                        "/usr/local/querystudioapi/backend/duckdb_extensions"):
            if not _pf_dir:
                continue
            _pf_check = os.path.join(_pf_dir, f"v{_dd_ver}",
                                     "linux_amd64", "httpfs.duckdb_extension")
            _pf_checked.append(_pf_check)
            if os.path.isfile(_pf_check):
                _pf_found_dir = _pf_dir
                break
        if _pf_found_dir is not None:
            print(
                f"SUBPROCESS: duckdb version={_dd_ver}, "
                f"httpfs extension PRESENT at {_pf_found_dir}/v{_dd_ver}/"
                f"linux_amd64/httpfs.duckdb_extension",
                file=sys.stderr, flush=True,
            )
        else:
            print(
                f"SUBPROCESS: WARN duckdb version={_dd_ver}, httpfs "
                f"extension MISSING from all known dirs ({_pf_checked}). "
                f"LOAD will FAIL FAST (Phase 164 -- no ~120s network "
                f"INSTALL hang) unless DUCKDB_ALLOW_EXTENSION_INSTALL=1 is "
                f"set.  Action: run "
                f"`python duckdb_extensions/download_extensions.py "
                f"--version {_dd_ver}` and rebuild, OR pin duckdb in "
                f"requirements.txt to a version that matches the bundled "
                f"extension tree.",
                file=sys.stderr, flush=True,
            )
    except Exception as _pf_exc:
        # Pre-flight is diagnostic-only; never crash a query because the
        # visibility log couldn't run.
        print(
            f"SUBPROCESS: extension pre-flight skipped (non-fatal): "
            f"{_pf_exc}",
            file=sys.stderr, flush=True,
        )

    # Legacy entry reads argv; pool worker passes explicit paths.
    if args_path is None:
        args_path = sys.argv[1]
    if result_path is None:
        result_path = sys.argv[2]

    def _write_result(data):
        with open(result_path, "w") as f:
            json.dump(data, f)

    _temp_files = []  # pre-downloaded parquet temp paths — must be before try for finally cleanup
    # P1c (2026-08-04) — phase marker + sampler handles for spill attribution.
    _qs_phase = {"phase": "init"}
    _spill_stop = None
    _spill_hiwater = {"bytes": 0}

    # BF-542 (2026-05-28): orphan-tracking sidecar.  If we SIGKILL
    # before reaching our own finally-block, the parent uses this
    # sidecar to clean up.  Each line in the file is one path the
    # subprocess promises to free in normal exit.
    _sidecar_path_child = os.environ.get("DUCKDB_SUBPROCESS_SIDECAR", "").strip()
    def _sidecar_register(path: str) -> None:
        """Best-effort append to the orphan-tracking sidecar so the
        parent can free this path on SIGKILL."""
        if not _sidecar_path_child or not path:
            return
        try:
            with open(_sidecar_path_child, "a") as _scf:
                _scf.write(path + "\n")
                _scf.flush()
                try:
                    os.fsync(_scf.fileno())
                except OSError:
                    pass
        except OSError:
            pass

    try:
        with open(args_path, "r") as f:
            args = json.load(f)

        # F2 (2026-07-25) — seed this process's on-prem cache hint
        # registry with the parent's listing-derived size/etag facts so a
        # same-path overwrite is a MISS -> refetch here too.  Best-effort.
        try:
            from core.onprem_file_cache import load_expected_meta
            load_expected_meta(args.get("onprem_expected_meta") or {})
        except Exception as _lem_exc:
            print(f"SUBPROCESS: expected-meta load skipped (non-fatal): "
                  f"{_lem_exc}", file=sys.stderr, flush=True)

        # 2026-08-22 — spawn+boot span: parent stamp -> _t0.  Absent on the
        # warm-pool path (its frame never carries the stamp — a pooled worker
        # has no per-request spawn) and on frames from an older parent; both
        # yield 0.0.  Clamped at 0 so clock adjustment between the two
        # time.time() reads can never produce a negative stage.
        _spawn_s = 0.0
        try:
            _parent_stamp = float(args.get("parent_spawn_wall_t") or 0.0)
            if _parent_stamp > 0.0:
                _spawn_s = max(0.0, _t0_wall - _parent_stamp)
        except (TypeError, ValueError):
            _spawn_s = 0.0

        conn_config = args["conn_config"]
        setup_sql = args["setup_sql"]
        copy_sql = args["copy_sql"]
        output_path = args["output_path"]
        # Progressive COPY (2026-07-31; default ON since 2026-08-02): when
        # the parent armed the rewrite, copy_sql targets this parts
        # DIRECTORY (FILE_SIZE_BYTES multi-file) and the fallback key
        # carries the ORIGINAL canonical single-file COPY for fail-open
        # recovery.  Both transports carry the keys (the warm pool since
        # 2026-09-25).  Keys absent (flag off) → both empty → every
        # progressive branch below is skipped entirely.
        _prog_parts_dir = str(args.get("progressive_parts_dir") or "")
        _prog_fallback_sql = str(
            args.get("progressive_fallback_copy_sql") or "")
        if _prog_parts_dir and not _prog_fallback_sql:
            # Never run the dir-target COPY without a canonical fallback.
            _prog_parts_dir = ""
        # 2026-08-04 (P1a) — the parent's WIDTH HINT (Iceberg schema column
        # count from the pruner stamp).  Used ONLY when the live LIMIT-0
        # probe below fails: the 40 GB incident showed the probe fails on
        # exactly the wide/evolved shapes that need ROW_GROUP_SIZE most.
        try:
            _width_hint = int(args.get("column_count_hint") or 0)
        except (TypeError, ValueError):
            _width_hint = 0
        _exec_id_child = str(args.get("execution_id") or "")
        _proxy_active = False  # set to True if proxy env was applied

        # Create DuckDB connection.  Phase 3 (2026-08-22): in pool
        # db-instance-reuse mode the worker keeps ONE DatabaseInstance per
        # connection fingerprint so DuckDB's remote-file caches outlive a
        # single request; the request itself always runs on a FRESH cursor
        # (session).  Outside that mode this is byte-for-byte the legacy
        # fresh :memory: connect.
        _pool_con, _pool_root, _pool_db_reused = _pool_db_acquire(conn_config)
        if _pool_con is not None:
            con = _pool_con
        else:
            _pool_root = None
            con = duckdb.connect(database=":memory:")

        # Disable auto-install to prevent DuckDB from trying to download
        # extensions from extensions.duckdb.org when encountering extension-
        # specific settings (e.g. httpfs SET commands).  In air-gapped
        # containers, each auto-install attempt times out (~120s) causing
        # multi-minute delays.  Docker pre-installs required extensions;
        # explicit INSTALL/LOAD still works with this disabled.
        try:
            con.execute("SET autoinstall_known_extensions=false;")
        except Exception as _be_exc:
            note_best_effort("con.execute('SET autoinstall_known_extensions=false;')", _be_exc,
                             logger=logger)

        # ── BF-528..531 (2026-05-28) — Enterprise-level resource bounding.
        # Without these, the subprocess crashes under production load:
        #   - cgroup-aware memory: DuckDB auto-detect reads HOST RAM (64 GB),
        #     not the pod's cgroup limit (4 GB) → DuckDB happily allocates
        #     40 GB → OOM-killed by the cgroup with no warning.
        #   - bounded threads: default = all host CPUs (16) → one query
        #     starves every other query in the pod.
        #   - spill quota: default is unbounded → one bad join fills the
        #     PVC → "no space on device" crash for every other query.
        # All three honoured if env var supplied; otherwise derived from
        # cgroup so the subprocess works correctly in containerised deploys
        # without extra config.
        from core.duckdb_resource_limits import (
            resolve_memory_limit_for_duckdb,
            resolve_thread_count_for_duckdb,
            resolve_spill_quota_bytes,
        )

        # BF-558b: the pod's memory budget is SHARED by every concurrent
        # DuckDB child.  QS_DUCKDB_CONCURRENT_CHILDREN is stamped by the
        # multi-worker fan-out (see multi_worker_executor) so each child
        # claims only its share instead of all of them claiming 75% of
        # the whole pod — which is how an N-way fan-out gets the pod
        # OOM-killed while no individual DuckDB thinks it is over budget.
        try:
            _conc_children = int(
                os.environ.get("QS_DUCKDB_CONCURRENT_CHILDREN", "1") or "1")
        except (TypeError, ValueError):
            _conc_children = 1
        _conc_children = max(1, _conc_children)

        # 2026-08-02 (defect 2): the SAME divisor now applies to threads.
        # Memory composed across children (BF-558b) but threads did not:
        # every child claimed cpus-1, so 30 concurrent engines on 8 vCPU
        # ran 210 threads (26x oversubscription).  Env override still wins.
        # Remember which knobs the OPERATOR pinned via env — the width-
        # aware adjustment further down must never override an explicit
        # operator choice.
        _mem_from_env = bool(os.environ.get("DUCKDB_MEMORY_LIMIT", "").strip())
        _thr_from_env = bool(os.environ.get("DUCKDB_THREADS", "").strip())
        _mem_limit = (os.environ.get("DUCKDB_MEMORY_LIMIT", "").strip()
                      or resolve_memory_limit_for_duckdb(
                          concurrency=_conc_children))
        _threads   = (os.environ.get("DUCKDB_THREADS", "").strip()
                      or str(resolve_thread_count_for_duckdb(
                          concurrency=_conc_children)))
        if _mem_limit:
            try:
                con.execute(f"SET memory_limit='{_mem_limit}';")
                print(f"SUBPROCESS: DuckDB memory_limit={_mem_limit}",
                      file=sys.stderr, flush=True)
            except Exception as _e:
                print(f"WARNING: could not set memory_limit={_mem_limit!r}: {_e}", file=sys.stderr)
        if _threads:
            try:
                con.execute(f"SET threads={int(_threads)};")
                print(f"SUBPROCESS: DuckDB threads={_threads}",
                      file=sys.stderr, flush=True)
            except Exception as _e:
                print(f"WARNING: could not set threads={_threads!r}: {_e}", file=sys.stderr)

        # Phase 168c — spill correctness (applies to BOTH the legacy
        # per-query child and the warm-pool worker, since both funnel
        # through _child_main).  Two independent settings:
        #
        #   1. preserve_insertion_order=false — DuckDB's default (true)
        #      forces it to buffer whole result sets to keep row order,
        #      which DEFEATS out-of-core spilling: a big GROUP BY / hash
        #      join OOMs instead of spilling.  We never rely on implicit
        #      row order (COPY TO + ORDER BY is explicit), so turn it off
        #      unconditionally.  Fail-open: a SET error just logs.
        #
        #   2. temp_directory — spill to a real (PVC-backed) dir so large
        #      ops spill to disk instead of blowing the memory_limit.  We
        #      derive the dir from DUCKDB_TEMP_DIR when present, else from
        #      config paths.duckdb_temp_dir / duckdb_spill_dir, so the
        #      pool path spills identically to the legacy path even when
        #      the env var isn't exported into the worker.
        try:
            con.execute("SET preserve_insertion_order=false;")
            print("SUBPROCESS: DuckDB preserve_insertion_order=false",
                  file=sys.stderr, flush=True)
        except Exception as _e:
            # Older DuckDB may not know the setting — degrade to default.
            print(f"WARNING: could not set preserve_insertion_order "
                  f"(non-fatal): {_e}", file=sys.stderr)

        # DuckDB temp directory — spill to PVC, not ephemeral pod storage.
        # DUCKDB_TEMP_DIR should point to a PVC-backed path (e.g. /app/data/tmp/duckdb)
        # to prevent pod eviction on large queries that exceed memory_limit.
        _temp_dir = os.environ.get("DUCKDB_TEMP_DIR", "").strip()
        if not _temp_dir:
            # Env var absent (common on the pooled worker): fall back to
            # the configured spill dir so behaviour matches the legacy
            # path.  Best-effort — any failure leaves _temp_dir empty and
            # DuckDB uses its own default temp dir (never crashes).
            try:
                from core import config as _cfg_mod
                _cfg_temp = None
                for _attr in ("duckdb_spill_dir", "duckdb_temp_dir"):
                    _getter = getattr(_cfg_mod.paths, _attr, None)
                    if _getter is not None:
                        try:
                            _cfg_temp = str(_getter)
                        except Exception:
                            _cfg_temp = None
                        if _cfg_temp:
                            break
                if _cfg_temp and _cfg_temp.strip():
                    _temp_dir = _cfg_temp.strip()
                    print(f"SUBPROCESS: DuckDB temp_directory derived from "
                          f"config ({_temp_dir}) — DUCKDB_TEMP_DIR unset",
                          file=sys.stderr, flush=True)
            except Exception as _e:
                print(f"WARNING: could not derive temp_directory from config "
                      f"(non-fatal): {_e}", file=sys.stderr)
        # 2026-07-16: temp_directory MUST resolve to a WRITABLE dir.  An empty
        # or unwritable _temp_dir (env unset + config not deployed, or an NFS
        # path with wrong perms) previously left temp_directory UNSET — and
        # DuckDB then creates ``.tmp`` in the process CWD, which is the
        # read-only code dir in the container, so the first spill / COPY TO
        # crashes with "failed to create directory .tmp: Permission denied"
        # (the query_native feed failure).  Try the configured dir, then a
        # guaranteed-writable local OS-temp dir.  _temp_dir (the *configured*
        # value) is left untouched so the extension_directory derivation below
        # keeps its original behaviour.
        _local_spill = os.path.join(tempfile.gettempdir(), "qs_duckdb_spill")
        _effective_temp = ""
        _spill_query_dir = ""
        for _cand in ([_temp_dir] if _temp_dir else []) + [_local_spill]:
            try:
                os.makedirs(_cand, exist_ok=True)
                # ── 2026-08-04 (P4) — PER-QUERY spill subdir ──────────────
                # DuckDB's .tmp scratch used to land directly in the SHARED
                # spill root, so when cancel SIGKILLed the child (SIGKILL
                # leaves DuckDB no chance to unlink), tens of GB sat
                # stranded until the scheduler's TTL sweep — unattributable
                # to any query.  A per-query subdir is (a) registered in
                # the BF-542 sidecar, so the parent's finally-drain reclaims
                # it the moment the cancelled/killed child is reaped, and
                # (b) measurable, so spill growth can be attributed to THIS
                # query while it runs.  Free-space / quota maths still use
                # the ROOT (same filesystem).
                import uuid as _sp_uuid
                _q_sub = f"q_{os.getpid()}_{_sp_uuid.uuid4().hex[:8]}"
                _qdir = os.path.join(_cand, _q_sub)
                os.makedirs(_qdir, exist_ok=True)
                con.execute(f"SET temp_directory='{_qdir}';")
                _effective_temp = _cand
                _spill_query_dir = _qdir
                _sidecar_register(_qdir)
                _temp_files.append(_qdir)
                print(f"SUBPROCESS: per-query spill dir {_qdir} "
                      f"(sidecar-registered; reclaimed on cancel/kill)",
                      file=sys.stderr, flush=True)
                if _cand != _temp_dir:
                    print(f"SUBPROCESS: DuckDB temp_directory falling back to "
                          f"local {_cand} (configured={_temp_dir!r} "
                          f"unset/unwritable)", file=sys.stderr, flush=True)
                break
            except Exception as _e:
                print(f"WARNING: temp_directory={_cand!r} unusable ({_e}); "
                      f"trying local fallback", file=sys.stderr, flush=True)
        if _effective_temp:
            # BF-529: bound spill so one pathological query can't fill the
            # PVC and crash every other query.  Env var overrides; otherwise
            # derived from the memory limit (see resolver) and ceilinged at
            # 50% of free disk.
            #
            # 2026-07-31: pass the memory limit through so spill is sized as a
            # MULTIPLE of it.  Previously the flat 10 GB default sat next to a
            # 22.5 GB memory_limit -- an out-of-core budget smaller than the
            # in-core one, which defeats the point of spilling and is exactly
            # how a 900-column scan died at 10.0/10.0 GiB.
            _mem_bytes_for_spill = 0
            try:
                from core.duckdb_resource_limits import (
                    parse_memory_limit_to_bytes as _mem2b,
                )
                _mem_bytes_for_spill = _mem2b(_mem_limit)
            except Exception:
                _mem_bytes_for_spill = 0
            # 2026-07-31 audit fix (F3): every concurrent child samples the
            # SAME free-disk reading, so the "50% of free" ceiling must be
            # divided between them or N children are each promised the whole
            # share.  The parent stamps QS_DUCKDB_CONCURRENT_CHILDREN when it
            # fans out; absent (single-worker COPY) it is 1 = today's value.
            try:
                _kids = int(os.environ.get(
                    "QS_DUCKDB_CONCURRENT_CHILDREN", "1") or "1")
            except ValueError:
                _kids = 1
            _spill_bytes = resolve_spill_quota_bytes(
                _effective_temp, memory_limit_bytes=_mem_bytes_for_spill,
                concurrent_children=_kids)
            if _spill_bytes > 0:
                try:
                    con.execute(
                        f"SET max_temp_directory_size='{_spill_bytes}b';"
                    )
                    print(f"SUBPROCESS: DuckDB max_temp_directory_size="
                          f"{_spill_bytes // (1024 * 1024)} MiB",
                          file=sys.stderr, flush=True)
                except Exception as _e:
                    # PRAGMA may not exist on older DuckDB; degrade gracefully.
                    print(f"WARNING: could not bound spill quota "
                          f"(DuckDB version may not support it): {_e}",
                          file=sys.stderr)
            print(f"SUBPROCESS: DuckDB temp_directory={_effective_temp}", file=sys.stderr, flush=True)
            # P1c (2026-08-04) — spill attribution sampler on the per-query
            # dir.  Stopped (and summarised) in the finally below.
            try:
                if _spill_query_dir:
                    _spill_stop, _spill_hiwater = _start_spill_attribution(
                        _spill_query_dir, int(_spill_bytes or 0),
                        output_path, _qs_phase)
            except Exception as _spw_exc:
                print(f"SUBPROCESS: spill attribution sampler skipped "
                      f"(non-fatal): {_spw_exc}", file=sys.stderr, flush=True)
        else:
            print("WARNING: no writable temp_directory (config/env/OS-temp all "
                  "failed); DuckDB may crash on spill with '.tmp' errors",
                  file=sys.stderr, flush=True)

        # ── Extension directory — must be writable for INSTALL/LOAD ────────
        # In containers running as non-root, HOME may be "/" (read-only).
        # DuckDB defaults to ~/.duckdb/extensions/ which would fail.
        _ext_dir = os.environ.get("DUCKDB_EXTENSION_DIR", "").strip()
        if not _ext_dir and _temp_dir:
            # temp_dir is typically .../data/tmp/duckdb — need 2 levels up to reach .../data/
            _ext_dir = os.path.join(os.path.dirname(os.path.dirname(_temp_dir.rstrip("/\\"))), "duckdb_extensions")
        if not _ext_dir and os.name != "nt":
            _ext_dir = "/usr/local/querystudioapi/nfs/data/duckdb_extensions"
        try:
            os.makedirs(_ext_dir, exist_ok=True)
            con.execute(f"SET extension_directory='{_ext_dir}';")
            print(f"SUBPROCESS: DuckDB extension_directory={_ext_dir}", file=sys.stderr, flush=True)
        except Exception as _e:
            print(f"WARNING: could not set extension_directory={_ext_dir!r}: {_e}", file=sys.stderr)

        # ── Compute the S3 setup plan ──────────────────────────────────────
        # Strategic decision point introduced 2026-06-23 -- one planner,
        # three orthogonal strategies (local files / native s3 / presigned
        # URLs already in SQL).  Every SET / LOAD / pre-download gate
        # below reads ``_plan`` fields directly; nothing here second-
        # guesses ``access_mode`` on its own.  See core.duckdb_s3_plan.
        #
        # Crash-safety: wrapped so a future bug in the planner module
        # (import error, attribute error on the dataclass, etc.) NEVER
        # takes down the subprocess.  Fallback synthesises a plan
        # equivalent to the pre-planner legacy behaviour from
        # access_mode alone -- the PRESIGNED_URLS_IN_SQL guard is
        # forfeited under the fallback but every existing query path
        # still works.  User-stated invariant 2026-06-23: "duckdb or
        # subprocess should never be crashed".
        _access_mode = get_s3_access_mode(conn_config)
        _plan = None
        try:
            from core.duckdb_s3_plan import (
                plan_s3_setup,
                LOCAL_FILES as _PLAN_LOCAL_FILES,
                PRESIGNED_URLS_IN_SQL as _PLAN_PRESIGNED_IN_SQL,
            )
            _plan = plan_s3_setup(conn_config, setup_sql, copy_sql)
        except Exception as _plan_exc:
            print(
                f"SUBPROCESS: S3 setup planner unavailable "
                f"({type(_plan_exc).__name__}: {_plan_exc}) -- "
                f"falling back to legacy access-mode-only semantics.  "
                f"PRESIGNED_URLS_IN_SQL double-sign guard is FORFEITED "
                f"under this fallback.  This is a defensive last-mile -- "
                f"file an issue if you see it in steady-state.",
                file=sys.stderr, flush=True,
            )
            # Minimal duck-typed plan that reproduces legacy behaviour:
            # access_mode=presigned -> LOCAL_FILES; else -> NATIVE_S3.
            class _LegacyPlan:
                pass
            _plan = _LegacyPlan()
            _is_presigned_mode = (_access_mode == "presigned")
            _plan.kind = "legacy_fallback_presigned" if _is_presigned_mode \
                else "legacy_fallback_native"
            _plan.reason = "planner failed; legacy fallback in effect"
            _plan.load_httpfs = not _is_presigned_mode
            _plan.set_endpoint_and_credentials = not _is_presigned_mode
            _plan.apply_ssl_bundle = not _is_presigned_mode
            _plan.predownload_presigned_to_local = _is_presigned_mode
            _plan.allow_boto3_predownload_fallback = not _is_presigned_mode
            _PLAN_LOCAL_FILES = "legacy_fallback_presigned"
            _PLAN_PRESIGNED_IN_SQL = "_unreachable_legacy_fallback_"
        # Legacy variable preserved for the pre-download blocks below
        # that still gate on "did we take the presigned-mode local-files
        # path?" -- they remain semantically correct under the planner
        # because LOCAL_FILES is the only kind that runs predownload.
        _skip_s3_creds = (_plan.kind == _PLAN_LOCAL_FILES)
        print(
            f"SUBPROCESS: S3 setup plan: kind={_plan.kind} "
            f"(access_mode={_access_mode}, load_httpfs={_plan.load_httpfs}, "
            f"set_endpoint_and_credentials={_plan.set_endpoint_and_credentials}, "
            f"predownload_to_local={_plan.predownload_presigned_to_local}, "
            f"allow_boto3_predownload_fallback={_plan.allow_boto3_predownload_fallback}) "
            f"-- {_plan.reason}",
            file=sys.stderr, flush=True,
        )

        # Load httpfs only when the plan calls for it.  LOCAL_FILES never
        # loads httpfs (URLs become local paths after pre-download).
        # NATIVE_S3_SIGNED_BY_DUCKDB and PRESIGNED_URLS_IN_SQL both need
        # httpfs but differ on whether DuckDB signs the requests itself.
        if _plan.load_httpfs:
            try:
                con.execute("LOAD 'httpfs';")
            except Exception as _load_err:
                # 2026-06-15 — when the bundled extension tree under
                # duckdb_extensions/v<X.Y.Z>/ doesn't match the duckdb
                # wheel version (typical cause: pip resolved a newer
                # duckdb than the image was built for), LOAD falls
                # through to INSTALL, which tries to fetch from
                # extensions.duckdb.org — blocked in air-gapped /
                # corporate-egress environments.  Print a clear
                # diagnostic BEFORE attempting INSTALL so the operator
                # sees what to fix instead of a 200-line "Connection
                # timed out" trace.
                try:
                    import duckdb as _dd
                    _dd_ver = getattr(_dd, "__version__", "?")
                except Exception:
                    _dd_ver = "?"

                # 2026-06-18 -- NFS volume mount over the
                # ${DUCKDB_EXTENSION_DIR} path hides the image-baked
                # duckdb_extensions/ tree at runtime.  Before falling
                # through to INSTALL (which times out in air-gapped
                # envs), try alternate locations that do NOT live under
                # the mount point: image-baked copy at /opt/, repo
                # checkout when running outside container, and an
                # operator-overridable env var.  Each candidate is
                # tried by re-pointing extension_directory then
                # retrying LOAD; the first that succeeds wins.
                _alt_dirs = []
                _env_alt = os.environ.get(
                    "DUCKDB_EXTENSION_FALLBACK_DIR", ""
                ).strip()
                if _env_alt:
                    _alt_dirs.append(_env_alt)
                _alt_dirs.extend([
                    "/opt/duckdb_extensions",
                    "/usr/local/querystudioapi/duckdb_extensions",
                    "/usr/local/querystudioapi/backend/duckdb_extensions",
                ])
                _loaded_via_alt = False
                for _alt in _alt_dirs:
                    _alt_ext = os.path.join(
                        _alt, f"v{_dd_ver}", "linux_amd64",
                        "httpfs.duckdb_extension",
                    )
                    if not os.path.isfile(_alt_ext):
                        continue
                    try:
                        con.execute(f"SET extension_directory='{_alt}';")
                        con.execute("LOAD 'httpfs';")
                        print(
                            f"SUBPROCESS: LOAD httpfs SUCCEEDED via "
                            f"fallback extension_directory={_alt} "
                            f"(primary {_ext_dir!r} was missing the "
                            f"file -- likely NFS mount overlay hiding "
                            f"the image-baked copy)",
                            file=sys.stderr, flush=True,
                        )
                        _loaded_via_alt = True
                        break
                    except Exception as _alt_err:
                        print(
                            f"SUBPROCESS: fallback {_alt} present but "
                            f"LOAD still failed: {_alt_err}",
                            file=sys.stderr, flush=True,
                        )
                        continue
                if not _loaded_via_alt:
                    _expected_path = os.path.join(
                        _ext_dir or "?", f"v{_dd_ver}", "linux_amd64",
                        "httpfs.duckdb_extension",
                    )
                    # Phase 164 — the network INSTALL fallback is now
                    # OPT-IN.  A correctly-bundled pod never reaches here
                    # (LOAD succeeded from the bundled tree), so the only
                    # callers are version-drift / unbundled pods -- and in
                    # an egress-restricted env `INSTALL 'httpfs'` reaches
                    # extensions.duckdb.org and hangs ~120s PER QUERY before
                    # timing out.  Default to FAIL-FAST with the actionable
                    # fix; set DUCKDB_ALLOW_EXTENSION_INSTALL=1 (internet-
                    # connected dev/build only) to restore the network fetch.
                    _allow_install = os.environ.get(
                        "DUCKDB_ALLOW_EXTENSION_INSTALL", "",
                    ).strip().lower() in ("1", "true", "yes", "on")
                    _fix_hint = (
                        f"httpfs extension unavailable for duckdb=={_dd_ver} "
                        f"(expected at {_expected_path}, checked "
                        f"{_alt_dirs}). Fix: (a) pin duckdb in requirements.txt "
                        f"to a version whose extensions are already in the "
                        f"image, OR (b) run `python duckdb_extensions/"
                        f"download_extensions.py --version {_dd_ver}` on a "
                        f"machine with internet and rebuild."
                    )
                    if not _allow_install:
                        print(
                            f"SUBPROCESS: LOAD httpfs failed and network "
                            f"INSTALL is disabled (DUCKDB_ALLOW_EXTENSION_"
                            f"INSTALL unset) -- failing fast instead of a "
                            f"~120s per-query hang. {_fix_hint} "
                            f"(err={_load_err})",
                            file=sys.stderr, flush=True,
                        )
                        raise RuntimeError(
                            f"httpfs extension unavailable and network INSTALL "
                            f"disabled. {_fix_hint}"
                        )
                    print(
                        f"SUBPROCESS: DUCKDB_ALLOW_EXTENSION_INSTALL set -- "
                        f"attempting network INSTALL httpfs (slow; times out "
                        f"in air-gapped envs). {_fix_hint} (err={_load_err})",
                        file=sys.stderr, flush=True,
                    )
                    con.execute("INSTALL 'httpfs';")
                    con.execute("LOAD 'httpfs';")

        # Apply proxy for DuckDB httpfs (Phase 119)
        # Relevant whenever httpfs makes network calls -- BOTH the
        # NATIVE_S3_SIGNED_BY_DUCKDB strategy (s3:// signed locally) and
        # the PRESIGNED_URLS_IN_SQL strategy (https:// URLs already
        # signed by the parent process).  LOCAL_FILES doesn't load
        # httpfs so proxy settings have no effect.
        #
        # Two-layer strategy:
        # 1. Set HTTP_PROXY/HTTPS_PROXY env vars (libcurl fallback)
        # 2. DuckDB SET http_proxy + http_proxy_username + http_proxy_password
        #    (DuckDB passes these to CURLOPT_PROXY* and may override env vars)
        # Both layers are needed because DuckDB httpfs may set CURLOPT_PROXY
        # from its internal setting even when empty, disabling env var fallback.
        if _plan.load_httpfs:
            try:
                from core.proxy_utils import (
                    set_subprocess_proxy_env, get_duckdb_proxy_stmts,
                    sanitize_proxy_error as _sp,
                )
                _ep_url = conn_config.get("endpoint_url") or conn_config.get("endpoint", "")

                # Layer 1: env vars (libcurl native fallback)
                _proxy_set = set_subprocess_proxy_env(endpoint_url=_ep_url)
                if _proxy_set:
                    _proxy_active = True
                    _redacted = os.environ.get("HTTP_PROXY", "")
                    if "@" in _redacted:
                        import re as _re_proxy
                        _redacted = _re_proxy.sub(r"(https?://)([^@]+)@", r"\1***:***@", _redacted)
                    print(f"SUBPROCESS: proxy env={_redacted}", file=sys.stderr, flush=True)
                else:
                    print("SUBPROCESS: proxy not configured or bypassed", file=sys.stderr, flush=True)

                # Layer 2: DuckDB SET statements
                _stmts = get_duckdb_proxy_stmts(endpoint_url=_ep_url)
                for _ps in _stmts:
                    try:
                        con.execute(_ps)
                        print(f"SUBPROCESS: proxy SET OK: {_sp(_ps)}", file=sys.stderr, flush=True)
                    except Exception as _se:
                        print(f"SUBPROCESS: proxy SET FAILED: {_sp(_ps)} -> {_sp(str(_se))}", file=sys.stderr, flush=True)
            except Exception as _proxy_e:
                from core.proxy_utils import sanitize_proxy_error as _sp2
                print(f"SUBPROCESS: proxy setup error: {_sp2(str(_proxy_e))}", file=sys.stderr, flush=True)

        _t_init = _t.monotonic()

        # ── S3 credentials ────────────────────────────────────────────────
        # "presigned" mode: all reads use pre-signed HTTPS URLs (boto3 handles
        # auth).  DuckDB must NOT set s3_endpoint or credentials — that causes
        # httpfs to add S3 auth headers on top of pre-signed URLs, corrupting
        # the SigV4 signature.
        if _skip_s3_creds:
            # Presigned mode: DuckDB reads pre-downloaded local files — no
            # httpfs, no S3 credentials, no HTTP tuning needed.  All SSL/HTTP
            # settings here are httpfs-specific and would trigger auto-install
            # in air-gapped containers without the autoinstall guard above.
            pass
        else:
            # AWS S3 — set credentials as before
            pass  # fall through to credential setup below

        ep = conn_config.get("endpoint_url") or conn_config.get("endpoint", "")
        # 2026-08-21 — ONE resolver, shared with the parent.  This block used to
        # take an explicit region verbatim and only fall back to the endpoint
        # when the field was EMPTY.  It is almost never empty: the connection
        # form ships `region_name: 'us-east-1'` as its DEFAULT and saves it, so
        # a VPCE connection arrives pre-stamped us-east-1 that nobody typed —
        # and DuckDB httpfs, which signs every object GET with this value, then
        # 400s on all of them.  resolve_s3_region applies the contradiction rule:
        # when the endpoint hostname names a region and the config disagrees,
        # the endpoint wins, because AWS validates the signature against the
        # endpoint it served.
        # 2026-08-22 — LATENCY: on the LOCAL_FILES plan (_skip_s3_creds) this
        # child never signs an S3 request: httpfs is not loaded, credentials
        # are skipped, and every `region` consumer below is gated off
        # (set_endpoint_and_credentials=False; allow_boto3_predownload_
        # fallback=False kills the VPC/proxy rewrite branches).  Yet the
        # resolver import pulls core.s3_storage -> boto3, measured at
        # 250-350 ms PER QUERY on the on-prem presigned path — half the
        # child's fixed tax, spent computing a value nothing reads.  Skip it.
        if _skip_s3_creds:
            region = ""
            print("SUBPROCESS: s3_region resolution SKIPPED "
                  "(local-files plan signs nothing; saves a per-query "
                  "boto3 import)", file=sys.stderr, flush=True)
        else:
            try:
                from core.s3_storage import resolve_s3_region as _qs_region
                region = _qs_region(conn_config)
            except Exception as _region_exc:
                # The child must never fail to start over this; fall back to
                # the old behaviour and say so.
                print(f"SUBPROCESS: region resolution unavailable "
                      f"({_region_exc}); falling back to the configured value",
                      file=sys.stderr, flush=True)
                region = (conn_config.get("region_name")
                          or conn_config.get("region") or "us-east-1")
            print(f"SUBPROCESS: s3_region={region!r}", file=sys.stderr,
                  flush=True)
        key = ""
        secret = ""
        token = ""

        if _skip_s3_creds:
            pass  # already handled above — skip to setup SQL
        else:
            key, secret, token = _child_s3_credentials(conn_config)

        def _esc(v: str) -> str:
            return v.replace("'", "''")

        if _plan.set_endpoint_and_credentials:
            # NATIVE_S3_SIGNED_BY_DUCKDB strategy: DuckDB httpfs signs every
            # request itself, so we hand it the endpoint + credentials.
            # Intentionally skipped under PRESIGNED_URLS_IN_SQL -- the URLs
            # in setup_sql are already SigV4-signed, and a second signing
            # pass corrupts them (libcurl returns HTTP 0 or S3 returns 403
            # SignatureDoesNotMatch).
            # 2026-09-26 -- the endpoint host, ssl flag and url style are
            # decided ONCE in core.s3_access (F2); the credentials this
            # child resolved (STS runs in-process) and the region it already
            # printed are handed in so nothing is re-derived.  Proxy was
            # applied above under the plan's own gate.
            from core.s3_access import resolve_s3_access as _resolve_s3_access
            _access = _resolve_s3_access(
                conn_config, credentials=(key, secret, token), region=region,
                proxy=False)
            for _stmt in _access.apply_to_duckdb(con):
                if not _stmt.startswith(("SET s3_access_key_id", "SET s3_secret",
                                         "SET s3_session_token")):
                    print(f"SUBPROCESS: {_stmt}", file=sys.stderr, flush=True)

        if _plan.apply_ssl_bundle:
            # SSL verification for DuckDB httpfs.  Applies to BOTH
            # NATIVE_S3_SIGNED_BY_DUCKDB and PRESIGNED_URLS_IN_SQL --
            # libcurl needs to validate the TLS chain on the S3 / VPCE
            # host regardless of who signed the request.
            # 2026-06-18 -- routes through core.ssl_config.  Prior code's
            # else-branch ("disable verification when no explicit path")
            # was the SAME dead-branch pattern as the urllib3 PoolManager
            # site -- it silently DISABLED cert verification on the
            # native httpfs path AND ignored the helm-deployed CA
            # bundle.  Now: when ssl_verify resolves to a bundle path
            # (helm auto-detected OR operator-supplied), DuckDB
            # httpfs+libcurl is pointed at it via SET ca_cert_file.
            # When ssl_verify resolves to system CA (no custom bundle
            # found), DuckDB libcurl's own default trust store handles
            # it -- only when explicitly OFF do we set
            # enable_server_cert_verification=false.
            from core.ssl_config import resolve_ssl, describe
            _ssl_res = resolve_ssl(conn_config.get("ssl_verify", True))
            print(f"SUBPROCESS: native httpfs SSL -- {describe(_ssl_res)}",
                  file=sys.stderr, flush=True)
            if _ssl_res.enabled and _ssl_res.ca_bundle_path:
                try:
                    con.execute(
                        f"SET ca_cert_file='{_esc(_ssl_res.ca_bundle_path)}';"
                    )
                except Exception as _be_exc:
                    note_best_effort("con.execute(f'SET ca_cert_file='{_esc(_ssl_res.ca_bundle_path)}';')", _be_exc,
                                     logger=logger)
            elif not _ssl_res.enabled:
                for _ssl_setting in (
                    "SET enable_server_cert_verification=false;",
                    "SET enable_curl_server_cert_verification=false;",
                ):
                    try:
                        con.execute(_ssl_setting)
                    except Exception as _be_exc:
                        note_best_effort("con.execute(_ssl_setting)", _be_exc,
                                         logger=logger)
            # else: enabled + no custom bundle -> rely on libcurl's
            # default trust store (system CA).  Leave DuckDB defaults.

            # S3 tuning
            try:
                con.execute("SET http_keep_alive=true;")
                con.execute("SET http_retries=3;")
                con.execute("SET http_timeout=30;")
                con.execute("SET enable_http_metadata_cache=true;")
                con.execute("SET enable_object_cache=true;")
            except Exception as _be_exc:
                note_best_effort("con.execute('SET enable_object_cache=true;')", _be_exc,
                                 logger=logger)
            # ── S3 HTTP transport (2026-09-20) ───────────────────────────
            # ``http_keep_alive`` above is necessary and NOT sufficient: with
            # it on, DuckDB still opened TWO TCP connections per file, and at
            # several thousand files that churn is what makes the endpoint
            # refuse.  ``httpfs_connection_caching`` only exists after
            # ``LOAD httpfs`` (done at ~3698, well before this line).
            try:
                from core.s3_http_transport import apply_s3_http_transport
                _tr = apply_s3_http_transport(con, label="subprocess")
                print(f"SUBPROCESS: s3 http transport {_tr}",
                      file=sys.stderr, flush=True)
            except Exception as _be_exc:
                note_best_effort("apply_s3_http_transport(con)", _be_exc,
                                 logger=logger)
            # ── Remote I/O concurrency (2026-10-06) ──────────────────────
            # threads above is CPU-sized (cgroup cpus-1 / children): 2 on a
            # 2-vCPU pod, i.e. two files in flight.  At ~150 ms a request
            # (AWS) that, not the bytes, is the scan's wall time.  Raise to
            # this query's remote-I/O share -- only here, where the plan
            # reads REMOTE files through httpfs (a LOCAL_FILES plan never
            # reaches this block).  DUCKDB_THREADS sizes the CPU value it
            # starts from; ``s3.remote_io_concurrency = 0`` turns it off.
            try:
                from core.s3_http_transport import (
                    apply_remote_io_concurrency, count_remote_files,
                )
                # The budget is per QUERY: share = how many children THIS
                # dispatch runs (``remote_io.share``, stamped by the
                # parent).  NOT QS_DUCKDB_CONCURRENT_CHILDREN -- that is the
                # pod's CPU/memory divisor (a warm-pool worker carries the
                # pool size there for life), and dividing a lone query's
                # reads by it left it 8 in flight (measured).
                _rio_hint = args.get("remote_io") or {}
                try:
                    _io_share = max(1, int(_rio_hint.get("share") or 1))
                except (TypeError, ValueError, AttributeError):
                    _io_share = 1
                _rio_measured = None
                try:
                    from core.measured_file_bytes import MeasuredBytes
                    if int(_rio_hint.get("known_files") or 0) > 0:
                        _rio_measured = MeasuredBytes(
                            files=int(_rio_hint.get("files") or 0),
                            known_files=int(_rio_hint.get("known_files") or 0),
                            known_bytes=int(_rio_hint.get("known_bytes") or 0),
                            max_bytes=int(_rio_hint.get("max_bytes") or 0))
                except Exception:
                    _rio_measured = None
                _rio = apply_remote_io_concurrency(
                    con,
                    remote_files=count_remote_files(setup_sql, copy_sql),
                    share=_io_share, label="subprocess",
                    measured=_rio_measured)
                print(f"SUBPROCESS: remote I/O concurrency {_rio}",
                      file=sys.stderr, flush=True)
            except Exception as _be_exc:
                note_best_effort("apply_remote_io_concurrency(con)", _be_exc,
                                 logger=logger)

        # Phase 3 — on a REUSED DatabaseInstance the metadata-cache
        # settings are shared state: the block above just set
        # enable_http_metadata_cache=true unconditionally (harmless on a
        # per-query instance, a trust decision on a persistent one).
        # State THIS request's policy explicitly, before any remote read.
        if _pool_root is not None:
            _pool_db_apply_cache_policy(con, args)

        _t_creds = _t.monotonic()

        # ── Pre-download for presigned mode ────────────────────────────────
        # DuckDB's bundled libcurl in subprocesses cannot always connect to
        # on-prem HTTPS endpoints (HTTP 0).  Python's urllib uses a different
        # SSL stack that works.  Download parquet files to temp paths, rewrite
        # the setup SQL to reference local files.  DuckDB never touches the
        # network — crash isolation is preserved with zero network risk.
        # ── ONE verdict (F3 round 5): what DuckDB reads, decided once ─────
        # core.duckdb_s3_plan.read_strategy, fed this process's two gates.
        # The three blocks below dispatch on it; the scheduled S3 road asks
        # the same function.
        from core.duckdb_s3_plan import (
            READ_LOCAL_PRESIGNED as _READ_LOCAL_PRESIGNED,
            READ_LOCAL_BOTO3 as _READ_LOCAL_BOTO3,
            READ_HTTPFS_PRESIGN_FOR_VPC as _READ_HTTPFS_PRESIGN_FOR_VPC,
        )
        _strategy, _vpc_needed, _vpc_reason = read_strategy_for_setup(
            _plan, conn_config, setup_sql, _proxy_active)
        print(f"SUBPROCESS: read strategy: {_strategy}", file=sys.stderr, flush=True)
        if _strategy == _READ_LOCAL_PRESIGNED and setup_sql:
            print("SUBPROCESS: pre-downloading presigned parquet files via Python SSL…",
                  file=sys.stderr, flush=True)
            setup_sql, _temp_files = _pre_download_presigned(setup_sql, conn_config)
            # BF-542: register each predownload temp file with the sidecar
            # so the parent can free them on SIGKILL.
            # Loop var is _tf (not _t) — _t is the `time` module imported at
            # top of _child_main; shadowing it broke _t.monotonic() below.
            for _tf in _temp_files:
                _sidecar_register(_tf)
            print(f"SUBPROCESS: pre-download complete — {len(_temp_files)} file(s), "
                  f"DuckDB will read local files only",
                  file=sys.stderr, flush=True)

        # ── Pre-download for native mode behind corporate proxy ───────────
        # DuckDB httpfs (libcurl) gets HTTP 503 from corporate proxies that
        # reject its auth negotiation.  boto3 (urllib3) uses the same proxy
        # and works.  Download s3:// files via boto3, rewrite SQL to local
        # paths.  DuckDB reads local parquet — no httpfs network traffic.
        # ── Pre-download decision log — always emit ───────────────────
        # User-visible diagnostic so "why is BQB downloading files?" has
        # a definitive answer in the log instead of being inferred from
        # query duration.
        if _plan.allow_boto3_predownload_fallback and setup_sql:
            print(
                f"SUBPROCESS: pre-download decision: "
                f"proxy_active={_proxy_active} "
                f"(if True, boto3 will pre-download all s3:// URLs in setup_sql "
                f"because DuckDB httpfs+libcurl gets HTTP 503 from corporate proxies; "
                f"to disable downloads, set proxy.enabled=false OR proxy.apply_to_duckdb=false "
                f"in config.json)",
                file=sys.stderr, flush=True,
            )
        # 2026-06-18 -- VPC ENDPOINT FORCE boto3 pre-download even without
        # proxy.  DuckDB httpfs native mode against path_style=True URLs
        # URL-encodes '=' to '%3D' in hive partition paths -- breaks the
        # SigV4 canonical request -> SignatureDoesNotMatch.  The
        # presigned path is already ruled out for VPC (signature host
        # mismatch -> 403).  boto3 is the only path that correctly signs
        # against the VPC endpoint hostname AND emits the hive-partition
        # URLs without the encoding glitch.  Force this path even when
        # proxy isn't active so VPC + no-proxy setups work.
        # 2026-06-18 -- VPC forcing decision delegated to the single
        # source of truth in ssl_config.  Same helper is used by
        # in-process callers (BQB streaming / Feed Gen / DataFlow)
        # so the decision is consistent across every code path.
        # (F3 round 5) _vpc_needed / _vpc_reason came from the ONE verdict
        # above (read_strategy_for_setup); the VPC branch fires exactly when
        # the verdict names it -- LOCAL_FILES has already pre-downloaded,
        # PRESIGNED_URLS_IN_SQL must NOT re-sign, the proxy wins over VPC.
        _vpc_ep = conn_config.get("endpoint_url") or conn_config.get("endpoint")
        _force_boto3_for_vpc = (_strategy == _READ_HTTPFS_PRESIGN_FOR_VPC)
        if _vpc_needed and not _plan.allow_boto3_predownload_fallback:
            # LOCAL_FILES already pre-downloaded OR PRESIGNED_URLS_IN_SQL
            # already carries signed URLs; either way, do nothing.
            _force_boto3_for_vpc = False

        # One-line diagnostic so the operator can see why boto3 fired
        # (or didn't) without grepping for multiple branches.
        print(
            f"SUBPROCESS: VPC workaround decision: "
            f"needed={_vpc_needed} ({_vpc_reason})",
            file=sys.stderr, flush=True,
        )
        if _strategy == _READ_HTTPFS_PRESIGN_FOR_VPC:
            # Strategic VPC path: rewrite s3:// to presigned HTTPS URLs.
            # DuckDB httpfs then reads the parquet files DIRECTLY over
            # the VPC interface endpoint — no local download, no temp
            # files, no disk pressure.  boto3 signs once on our side so
            # the libcurl '=' URL-encoding bug never enters the picture.
            #
            # Falls back to pre-download ONLY if presigned generation
            # itself fails (e.g. STS expired between auth and rewrite).
            # Pre-download remains the correct strategy for proxy-only
            # paths (handled below) — that's a different failure mode.
            print(
                "SUBPROCESS: VPC + hive paths -- using PRESIGNED URL "
                "strategy (DuckDB reads via VPC, no local download).  "
                "Set QS_FORCE_BOTO3_FOR_VPC=0 to disable VPC workaround.",
                file=sys.stderr, flush=True,
            )
            try:
                setup_sql, _ = _rewrite_s3_urls_to_presigned_for_vpc(
                    setup_sql, conn_config,
                    key, secret, token, region, ep,
                )
                # Mark as "handled" so the proxy-active branch doesn't
                # also try to download the same URLs.  No temp files
                # registered because nothing was downloaded.
                _skip_s3_creds = True
                # 2026-06-24 CRITICAL -- clear s3_endpoint + creds that
                # were SET earlier in this function (~line 1727-1737)
                # under the NATIVE_S3 plan computed against the
                # PRE-rewrite setup_sql.  Without this RESET, DuckDB
                # httpfs sees s3_endpoint matching the URL host of the
                # just-presigned URLs and applies its OWN SigV4 on top
                # -> libcurl drops the malformed request -> HTTP 0 /
                # 403 SignatureDoesNotMatch.  Mirrors the in-process
                # register_s3_views fix in duckdb_views.py.  Single
                # decision point: the SAME planner module that the
                # subprocess consults at the top of _child_main.
                try:
                    from core.duckdb_s3_plan import reset_s3_signing_on_connection
                    reset_s3_signing_on_connection(con, sql_context=setup_sql)
                    print(
                        "SUBPROCESS: RESET s3_endpoint + credentials "
                        "after VPC presigned-URL rewrite -- prevents "
                        "httpfs double-signing the presigned URLs.",
                        file=sys.stderr, flush=True,
                    )
                except Exception as _reset_exc:
                    print(
                        f"SUBPROCESS: post-rewrite signing RESET "
                        f"FAILED ({_reset_exc}) -- query may 403 with "
                        f"SignatureDoesNotMatch.",
                        file=sys.stderr, flush=True,
                    )
            except Exception as _ps_exc:
                from core.proxy_utils import sanitize_proxy_error as _sp_vpc
                print(
                    f"SUBPROCESS: VPC presigned-URL rewrite FAILED: "
                    f"{_sp_vpc(str(_ps_exc))} -- falling back to boto3 "
                    f"pre-download (slower, uses disk)",
                    file=sys.stderr, flush=True,
                )
                try:
                    setup_sql, _temp_files = _pre_download_s3_via_boto3(
                        setup_sql, conn_config,
                        key, secret, token, region, ep,
                    )
                    for _tf in _temp_files:
                        _sidecar_register(_tf)
                    _skip_s3_creds = True
                except Exception as _dl_exc:
                    print(
                        f"SUBPROCESS: VPC pre-download fallback ALSO "
                        f"FAILED: {_sp_vpc(str(_dl_exc))} -- letting "
                        f"native httpfs try (will likely 403)",
                        file=sys.stderr, flush=True,
                    )

        if _strategy == _READ_LOCAL_BOTO3 and setup_sql:
            print("SUBPROCESS: proxy active — pre-downloading S3 files via boto3…",
                  file=sys.stderr, flush=True)
            try:
                setup_sql, _temp_files = _pre_download_s3_via_boto3(
                    setup_sql, conn_config, key, secret, token, region, ep,
                )
                # BF-542: register boto3-predownload temp files too.
                for _tf in _temp_files:
                    _sidecar_register(_tf)
            except Exception as _dl_exc:
                from core.proxy_utils import sanitize_proxy_error as _sp3
                _dl_msg = _sp3(str(_dl_exc))
                print(f"SUBPROCESS: boto3 pre-download FAILED: {_dl_msg} "
                      f"— trying presigned URL fallback",
                      file=sys.stderr, flush=True)
                # Fallback: rewrite s3:// to presigned HTTPS via the
                # shared helper (single source of truth for SSL +
                # pool sizing), then download those presigned URLs via
                # Python SSL — same proxy that broke libcurl httpfs
                # works fine through urllib.  Do NOT fall back to
                # DuckDB httpfs here — it will hit the same 503.
                try:
                    setup_sql, _ = _rewrite_s3_urls_to_presigned_for_vpc(
                        setup_sql, conn_config,
                        key, secret, token, region, ep,
                    )
                    setup_sql, _temp_files = _pre_download_presigned(
                        setup_sql, conn_config
                    )
                    for _tf in _temp_files:
                        _sidecar_register(_tf)
                    print(f"SUBPROCESS: presigned fallback complete — "
                          f"{len(_temp_files)} file(s)",
                          file=sys.stderr, flush=True)
                except Exception as _fb_exc:
                    _fb2_msg = _sp3(str(_fb_exc))
                    print(f"SUBPROCESS: presigned fallback also FAILED: "
                          f"{_fb2_msg} — falling back to DuckDB httpfs",
                          file=sys.stderr, flush=True)

        # ── BF-571: format-string safety net ──────────────────────────────
        # Last-mile defence against cross-dialect strftime specifiers
        # (``%i``, ``%c``, ``%e``, ``%k``, ``%l``, ``%s``, ``%T``, ``%r``)
        # and stray DATE_FORMAT calls that DuckDB rejects.  The dialect
        # translator handles the >99% case but some execute paths
        # bypass it; this guarantees the SQL DuckDB sees is always
        # valid even when upstream wasn't.
        try:
            from core.duckdb_format_normaliser import (
                normalise_strftime_formats as _norm_fmt,
            )
            if setup_sql:
                _new_setup, _setup_fixes = _norm_fmt(setup_sql)
                if _setup_fixes:
                    print(
                        f"SUBPROCESS: BF-571 auto-fixed "
                        f"{len(_setup_fixes)} format specifier(s) "
                        f"in setup SQL",
                        file=sys.stderr, flush=True,
                    )
                    setup_sql = _new_setup
            _new_copy, _copy_fixes = _norm_fmt(copy_sql)
            if _copy_fixes:
                print(
                    f"SUBPROCESS: BF-571 auto-fixed "
                    f"{len(_copy_fixes)} format specifier(s) "
                    f"in COPY SQL: "
                    f"{', '.join(f.describe() for f in _copy_fixes)}",
                    file=sys.stderr, flush=True,
                )
                copy_sql = _new_copy
        except Exception as _norm_exc:
            print(
                f"SUBPROCESS: format normaliser skipped (fail-open): "
                f"{_norm_exc}",
                file=sys.stderr, flush=True,
            )

        # ── Setup SQL (CREATE VIEW statements) ────────────────────────────
        _qs_phase["phase"] = "setup_sql"
        if setup_sql:
            for stmt in setup_sql.split(";\n"):
                stmt = stmt.strip()
                if stmt:
                    con.execute(stmt)

        _t_setup = _t.monotonic()

        # ── Width-aware ROW_GROUP_SIZE (2026-07-31) ───────────────────────
        #
        # A row group is buffered IN FULL before it can be written, so its
        # cost is rows x COLUMNS.  With no ROW_GROUP_SIZE, DuckDB uses 122,880
        # rows; at ~900 columns that is ~110M cells (0.9-3.3 GB) held per
        # writer thread, which is what exhausted max_temp_directory_size and
        # killed the query with "failed to offload data block".
        #
        # We can only size this correctly if we know the width, and the child
        # is the only place with a live connection — so probe it here with a
        # zero-row execution (planning only, no data read).
        #
        # FAIL-OPEN: any problem leaves copy_sql byte-for-byte unchanged, i.e.
        # exactly today's behaviour.  And the clause is omitted entirely for
        # tables narrow enough to clamp at DuckDB's own default, so narrow
        # results keep producing identical files (same row groups, same footer
        # stats, same pruning granularity).
        _rg_clause_val = ""   # stashed for the progressive fallback COPYs
        _probed_ncols = None  # stashed for the width-aware limit adjustment
        try:
            # 2026-07-31 audit fix (T4): ROW_GROUP_SIZE is a PARQUET-only
            # option.  Without this format check the injector would append it
            # to a CSV/JSON COPY and DuckDB raises
            #   Unrecognized option "ROW_GROUP_SIZE" for csv
            # turning a working statement into a hard failure — so the
            # "fail-open at every step" contract was false for non-parquet.
            # Latent today (every _child_main COPY is parquet), fixed before
            # it stops being latent.
            _cs_upper = copy_sql.upper()
            if ("ROW_GROUP_SIZE" not in _cs_upper
                    and "PARQUET" in _cs_upper):
                _inner = _inner_query_from_copy(copy_sql)
                if _inner:
                    _ncols = _probe_column_count(con, _inner)
                    _probed_ncols = _ncols
                    # 2026-08-04 (P1a) — FAIL-CLOSED width resolution.  The
                    # 40 GB incident: the probe failed silently here, the
                    # clause vanished, and DuckDB buffered 122,880 rows x
                    # 900 cols per writer thread.  Resolution order is now
                    # probe -> parent hint -> assume-wide; an unknown width
                    # can no longer fall back to DuckDB's default.
                    if not _ncols:
                        if _width_hint > 0:
                            print(
                                f"SUBPROCESS: width probe FAILED — using "
                                f"parent hint ({_width_hint} columns) for "
                                f"ROW_GROUP_SIZE",
                                file=sys.stderr, flush=True)
                        else:
                            print(
                                "SUBPROCESS: width probe FAILED and no "
                                "parent hint — FAIL-CLOSED row groups "
                                "(assume wide; DuckDB's 122,880-row "
                                "default is never used on unknown width)",
                                file=sys.stderr, flush=True)
                    from core.parquet_write_opts import (
                        duckdb_copy_row_group_clause as _rg_clause,
                        ASSUMED_UNKNOWN_WIDTH_COLS as _rg_assumed,
                    )
                    _ncols_eff = int(_ncols or _width_hint or 0)
                    _ncols_lbl = (str(_ncols_eff) if _ncols_eff
                                  else f"unknown(assumed {_rg_assumed})")
                    _clause = _rg_clause(
                        _ncols,
                        fallback_columns=_width_hint or None,
                        assume_wide_when_unknown=True,
                    )
                    _rg_clause_val = _clause or ""
                    if _clause:
                        _new = _inject_copy_option(copy_sql, _clause)
                        if not _new:
                            # 2026-07-31 audit fix (F1): this used to fail
                            # SILENTLY -- the code logged on success and on
                            # "keeping default" but said nothing when
                            # injection was refused, so an unrecognised
                            # COPY shape looked identical to a narrow
                            # table.  Say it out loud.
                            print(
                                f"SUBPROCESS: WARNING — {_ncols_lbl} columns "
                                f"needs{_clause.strip(', ')} but the COPY "
                                f"statement shape was not recognised; "
                                f"proceeding with DuckDB's default row "
                                f"group size (OOM risk on wide tables). "
                                f"COPY tail: ...{copy_sql[-60:]!r}",
                                file=sys.stderr, flush=True,
                            )
                        if _new:
                            copy_sql = _new
                            print(
                                f"SUBPROCESS: width-aware row groups — "
                                f"{_ncols_lbl} columns ->{_clause.strip(', ')}"
                                f" (DuckDB default 122880 would buffer "
                                f"~{(_ncols_eff or _rg_assumed) * 122880 // 1_000_000}M cells "
                                f"per row group)",
                                file=sys.stderr, flush=True,
                            )
                    else:
                        print(
                            f"SUBPROCESS: {_ncols_lbl} columns — keeping "
                            f"DuckDB default row group size",
                            file=sys.stderr, flush=True,
                        )
        except Exception as _rg_exc:                          # pragma: no cover
            print(f"SUBPROCESS: row-group sizing skipped (fail-open): "
                  f"{_rg_exc}", file=sys.stderr, flush=True)

        # ── Width-aware memory/threads (2026-08-02, defect 1) ─────────────
        #
        # MEASURED: at memory_limit=256MB (the high-concurrency floor) a
        # 900-column operation raises OutOfMemoryException instead of
        # spilling — per-thread column buffers are not spillable, so below
        # a width-dependent floor the query CANNOT complete at any spill
        # budget (see the measured matrix in core.duckdb_resource_limits).
        # A wide query must either get fewer threads (free — no extra
        # memory claimed) or, when even one thread cannot fit, a bounded
        # memory escalation to the single-thread width floor.
        #
        # This is the ONLY place the width is knowable (live connection,
        # views created).  Reuses the row-group probe above when it ran;
        # probes here otherwise (LIMIT-0 planning only).  current_setting
        # is read back from the connection so the values are GROUND TRUTH
        # (env override, caller SET via setup_sql, resolver — whatever
        # won).  Operator env pins (DUCKDB_MEMORY_LIMIT / DUCKDB_THREADS)
        # are never overridden.  FAIL-OPEN: any error leaves settings
        # exactly as they are today.
        try:
            _wa_ncols = _probed_ncols
            if not _wa_ncols:
                _wa_inner = _inner_query_from_copy(copy_sql)
                if _wa_inner:
                    _wa_ncols = _probe_column_count(con, _wa_inner)
            # 2026-08-04 (P1a) — probe failed twice: fall back to the
            # parent's schema-width hint so the width-aware memory/thread
            # floors still engage on exactly the queries that break the
            # probe (wide, spec-evolved, presigned).
            if not _wa_ncols and _width_hint > 0:
                _wa_ncols = _width_hint
                print(f"SUBPROCESS: width-aware limits using parent hint "
                      f"({_width_hint} columns) — live probe failed",
                      file=sys.stderr, flush=True)
            if _wa_ncols:
                from core.duckdb_resource_limits import (
                    width_aware_limits,
                    parse_memory_limit_to_bytes as _wa_parse,
                )
                _wa_cur_mem = _wa_parse(str(con.execute(
                    "SELECT current_setting('memory_limit')").fetchone()[0]))
                _wa_cur_thr = int(con.execute(
                    "SELECT current_setting('threads')").fetchone()[0])
                _wa_mem_mb, _wa_thr = width_aware_limits(
                    _wa_ncols, _wa_cur_mem, _wa_cur_thr,
                    sql_text=copy_sql)
                # Threads first: shrink parallelism before granting memory.
                if _wa_thr is not None and not _thr_from_env:
                    con.execute(f"SET threads={int(_wa_thr)};")
                    print(f"SUBPROCESS: width-aware threads — {_wa_ncols} "
                          f"columns at {_wa_cur_mem // (1024*1024)}MB: "
                          f"threads {_wa_cur_thr} -> {int(_wa_thr)}",
                          file=sys.stderr, flush=True)
                if _wa_mem_mb is not None and not _mem_from_env:
                    con.execute(f"SET memory_limit='{int(_wa_mem_mb)}MB';")
                    print(f"SUBPROCESS: width-aware memory floor — "
                          f"{_wa_ncols} columns cannot complete at "
                          f"{_wa_cur_mem // (1024*1024)}MB on any thread "
                          f"count (unspillable per-column buffers); "
                          f"memory_limit -> {int(_wa_mem_mb)}MB",
                          file=sys.stderr, flush=True)
        except Exception as _wa_exc:                          # pragma: no cover
            print(f"SUBPROCESS: width-aware limits skipped (fail-open): "
                  f"{_wa_exc}", file=sys.stderr, flush=True)

        # ── Stage-2 spill admission (2026-08-04) — plan shape MEASURED ────
        # The parent's pre-spawn check (stage 1) guesses two inputs this
        # process can measure: whether the plan has a blocking operator
        # (EXPLAIN, planning only — measured 2026-08-04: our RLS /
        # _auto_filtered / union_by_name wraps add NO operator; the MoR
        # anti-join was the one wrap that ever did), and the parquet decode
        # ratio (footer metadata on one island file, replacing the 8.0
        # guess — measured 2.55x on 900-col data).  A STREAMING-shaped plan
        # is O(1) in memory regardless of result size (measured: 900 cols x
        # 120k rows COPY at memory_limit=1260MB completed with spill
        # high-water 0.0 MB) and is therefore NEVER refused.  Everything
        # here is fail-open except SpillRefused itself, which IS the
        # feature in enforce mode.  Runs BEFORE the streaming/progressive/
        # COPY lanes: past this point the query starts reading data.
        #
        # 2026-08-04 completion route: an enforce-mode refusal is first
        # offered to core.blocking_completion_route (chunked sorted runs +
        # k-way streaming merge — the export that ALWAYS finishes).  When
        # the route completes it writes the canonical output file itself
        # and every execution lane below is skipped; when no route applies
        # or the route fails, the ORIGINAL refusal propagates — the child
        # never falls through to the lane the verdict said would die.
        _route_result = None
        try:
            from core import spill_admission as _s2_adm
            if _s2_adm.mode() != _s2_adm.MODE_OFF:
                from core.duckdb_plan_shape import (
                    probe_plan_shape as _s2_probe,
                    sample_parquet_ref as _s2_sample,
                    measured_expansion_factor as _s2_ratio,
                )
                _s2_shape = _s2_probe(con, copy_sql)
                print(f"SUBPROCESS: {_s2_shape.describe()}",
                      file=sys.stderr, flush=True)
                _s2_isl_raw = args.get("island_hint") or None
                if _s2_isl_raw and _s2_shape.known:
                    from core.s3_read_strategy import IslandSize as _S2Island
                    _s2_island = _S2Island(
                        bytes_=int(_s2_isl_raw.get("bytes", -1)),
                        files=int(_s2_isl_raw.get("files", -1)),
                        source="parent_hint",
                        columns=int(_s2_isl_raw.get("columns", -1)),
                    )
                    _s2_exp = None
                    if not _s2_shape.streaming and _s2_island.known:
                        # The ratio only matters when a blocking operator
                        # will materialise the island — skip the footer
                        # read entirely on the streaming path.
                        _s2_pair = _s2_ratio(
                            con, _s2_sample(setup_sql, copy_sql))
                        if _s2_pair:
                            _s2_exp = _s2_pair[0]
                            print(f"SUBPROCESS: measured decode ratio "
                                  f"{_s2_pair[1]:.2f}x (footer) -> "
                                  f"admission factor {_s2_pair[0]:.2f}x "
                                  f"(with headroom; configured guess "
                                  f"{_s2_adm.expansion_factor():.1f}x)",
                                  file=sys.stderr, flush=True)
                    try:
                        # Fresh import: _wa_parse above is only bound when
                        # the width-aware block ran.  current_setting is
                        # ground truth (env pin / width floor / resolver —
                        # whichever won).
                        from core.duckdb_resource_limits import (
                            parse_memory_limit_to_bytes as _s2_m2b,
                        )
                        _s2_mem = int(_s2_m2b(str(con.execute(
                            "SELECT current_setting('memory_limit')"
                        ).fetchone()[0])))
                    except Exception:
                        _s2_mem = 0
                    try:
                        _s2_spill = int(_spill_bytes or 0)
                    except NameError:
                        _s2_spill = 0
                    _s2_adm.check(
                        _s2_island,
                        memory_limit_bytes=_s2_mem,
                        spill_quota_bytes=_s2_spill,
                        has_blocking_operator=not _s2_shape.streaming,
                        expansion_override=_s2_exp,
                        context=f"stage2 execution_id={_exec_id_child or '-'}",
                    )
        except Exception as _s2_exc:
            try:
                from core.spill_admission import SpillRefused as _S2Refused
            except Exception:                                # pragma: no cover
                _S2Refused = ()  # isinstance(x, ()) is always False
            if isinstance(_s2_exc, _S2Refused):
                # ── Completion route: ROUTE before refusing ──────────────
                _cr_enabled = False
                try:
                    from core.blocking_completion_route import (
                        completion_route_enabled as _cr_flag,
                        execute_completion_route as _cr_exec,
                        CompletionRouteError as _CrError,
                    )
                    _cr_enabled = _cr_flag()
                except Exception as _cr_imp_exc:
                    print(f"SUBPROCESS: completion route unavailable "
                          f"(refusal stands): {_cr_imp_exc}",
                          file=sys.stderr, flush=True)
                if not _cr_enabled:
                    raise    # enforce-mode refusal — operator-legible error
                print("SUBPROCESS: admission REFUSED the blocking plan — "
                      "attempting the completion route (chunked runs + "
                      "streaming merge)", file=sys.stderr, flush=True)
                # _s2_exp was bound before check() could raise; guard
                # anyway so a future reshuffle cannot NameError here.
                _cr_exp = None
                try:
                    _cr_exp = _s2_exp
                except NameError:                            # pragma: no cover
                    _cr_exp = None
                _cr_isl = args.get("island_hint") or {}
                try:
                    _route_result = _cr_exec(
                        con=con,
                        setup_sql=setup_sql,
                        inner_sql=_inner_query_from_copy(copy_sql),
                        output_path=output_path,
                        island_bytes=int(_cr_isl.get("bytes", -1) or -1),
                        island_files=int(_cr_isl.get("files", -1) or -1),
                        expansion_factor=_cr_exp,
                        row_group_clause=_rg_clause_val,
                        execution_id=str(_exec_id_child or ""),
                        sidecar_register=_sidecar_register,
                        temp_files=_temp_files,
                        log=lambda _m: print(_m, file=sys.stderr,
                                             flush=True),
                    )
                except _CrError as _cr_exc:
                    print(f"SUBPROCESS: completion route FAILED — "
                          f"surfacing the original refusal.  {_cr_exc}",
                          file=sys.stderr, flush=True)
                    raise _s2_exc from _cr_exc
                if _route_result is None:
                    raise    # no route for this shape — the refusal stands
            else:
                print(f"SUBPROCESS: stage-2 admission skipped (fail-open): "
                      f"{_s2_exc}", file=sys.stderr, flush=True)

        # ── P3 (2026-08-04): TRUE incremental delivery ────────────────────
        # When progressive is armed and the plan can emit before it
        # finishes, stream Arrow record batches out of the running query:
        # rows reach the grid as produced (sealed ~4 MB segments) while the
        # canonical single file is written alongside.  Refusal or machinery
        # failure returns None -> the COPY lanes below run byte-for-byte as
        # today.  Query errors propagate (the COPY would fail identically).
        _streamed_rows = None
        if _route_result is not None:
            # Completion route already wrote the canonical output file —
            # every execution lane below (arrow-stream / progressive /
            # COPY / concat) must be skipped, not merely optional.
            _streamed_rows = int(_route_result.get("rows") or 0)
            _prog_parts_dir = ""
            _qs_phase["phase"] = "completion_route_done"
        if _prog_parts_dir:
            _stream_inner = ""
            try:
                _stream_inner = _inner_query_from_copy(
                    _prog_fallback_sql or copy_sql)
            except Exception as _si_exc:
                print(f"SUBPROCESS: streaming inner-SQL extraction failed "
                      f"(fail-open -> COPY): {_si_exc}",
                      file=sys.stderr, flush=True)
            if _stream_inner:
                _qs_phase["phase"] = "arrow_stream"
                _streamed_rows = _try_streaming_arrow_copy(
                    con, _stream_inner, output_path, _prog_parts_dir,
                    _exec_id_child, _width_hint, _sidecar_register,
                    _temp_files, _qs_phase)
                if _streamed_rows is not None:
                    _prog_parts_dir = ""   # COPY + concat lanes skip below

        # ── Progressive COPY: spool-dir prep (fail-open → canonical) ──────
        # DuckDB refuses a NON-EMPTY target dir, so a stale spool from a
        # crashed prior attempt must go first.  Any prep problem disarms
        # progressive and runs the ORIGINAL single-file COPY instead —
        # today's behaviour, exactly.
        if _streamed_rows is None and _prog_parts_dir:
            try:
                import shutil as _prog_sh
                if os.path.isdir(_prog_parts_dir):
                    _prog_sh.rmtree(_prog_parts_dir, ignore_errors=True)
                if os.path.exists(_prog_parts_dir):
                    raise OSError(
                        f"stale parts dir not removable: {_prog_parts_dir}")
                # Register BEFORE the COPY starts writing: on SIGKILL the
                # parent drains the sidecar and removes the spool.
                _sidecar_register(_prog_parts_dir)
                _temp_files.append(_prog_parts_dir)
            except Exception as _prog_prep_exc:
                print(f"SUBPROCESS: progressive spool prep failed "
                      f"(fail-open -> canonical single-file COPY): "
                      f"{_prog_prep_exc}", file=sys.stderr, flush=True)
                copy_sql = (_inject_copy_option(_prog_fallback_sql,
                                                _rg_clause_val)
                            or _prog_fallback_sql)
                _prog_parts_dir = ""

        # ── Execute COPY TO (skipped when the streaming lane delivered) ───
        _qs_phase["phase"] = "copy"
        try:
            if _streamed_rows is None:
                con.execute(copy_sql)
        except Exception as _copy_exc:
            # Progressive fail-open: a failure WRITING THE PARTS DIR (the
            # error names the spool path) is progressive machinery, not
            # the query — retry the canonical single-file COPY once.  Any
            # other error (binder, S3 read, OOM…) would fail the
            # canonical COPY identically, so it propagates AS-IS — no
            # double execution on genuine query errors.
            _prog_err_txt = str(_copy_exc).replace("\\", "/")
            if (_prog_parts_dir
                    and _prog_parts_dir.replace("\\", "/") in _prog_err_txt):
                print(f"SUBPROCESS: progressive COPY failed on the parts "
                      f"dir ({type(_copy_exc).__name__}) -- retrying "
                      f"CANONICAL single-file COPY",
                      file=sys.stderr, flush=True)
                import shutil as _prog_sh
                _prog_sh.rmtree(_prog_parts_dir, ignore_errors=True)
                _prog_parts_dir = ""
                copy_sql = (_inject_copy_option(_prog_fallback_sql,
                                                _rg_clause_val)
                            or _prog_fallback_sql)
                con.execute(copy_sql)
            else:
                raise

        # ── Progressive COPY: concat parts → canonical single file ───────
        # Streaming (ParquetFile.iter_batches into ONE ParquetWriter, O(one
        # batch) memory) into a temp path, then atomic os.replace — a
        # partial file can NEVER appear at output_path.  Concat failure
        # falls back to a local DuckDB re-copy of the parts (order
        # preserved: explicit index-ordered file list +
        # preserve_insertion_order default); if even that fails, the last
        # resort is re-running the original canonical COPY.
        if _prog_parts_dir:
            _qs_phase["phase"] = "concat_parts"
            _prog_tmp_out = output_path + ".progressive_tmp.parquet"
            _sidecar_register(_prog_tmp_out)
            _temp_files.append(_prog_tmp_out)
            try:
                _prog_n = _progressive_concat_parts(_prog_parts_dir,
                                                    _prog_tmp_out)
                os.replace(_prog_tmp_out, output_path)
                print(f"SUBPROCESS: progressive concat OK -- {_prog_n:,} "
                      f"rows from parts into {os.path.basename(output_path)}",
                      file=sys.stderr, flush=True)
            except Exception as _prog_cc_exc:
                print(f"SUBPROCESS: progressive concat FAILED "
                      f"({type(_prog_cc_exc).__name__}: {_prog_cc_exc}) -- "
                      f"falling back to local DuckDB re-copy of the parts",
                      file=sys.stderr, flush=True)
                try:
                    os.unlink(_prog_tmp_out)
                except OSError:
                    pass
                try:
                    _prog_list = ", ".join(
                        "'" + p.replace("\\", "/").replace("'", "''") + "'"
                        for p in _progressive_list_parts(_prog_parts_dir))
                    _prog_safe_out = (
                        _prog_tmp_out.replace("\\", "/").replace("'", "''"))
                    con.execute(
                        f"COPY (SELECT * FROM read_parquet([{_prog_list}], "
                        f"union_by_name=false)) TO '{_prog_safe_out}' "
                        f"(FORMAT PARQUET, COMPRESSION ZSTD{_rg_clause_val})")
                    os.replace(_prog_tmp_out, output_path)
                except Exception as _prog_rc_exc:
                    print(f"SUBPROCESS: local re-copy ALSO failed "
                          f"({_prog_rc_exc}) -- last resort: re-running the "
                          f"canonical single-file COPY",
                          file=sys.stderr, flush=True)
                    try:
                        os.unlink(_prog_tmp_out)
                    except OSError:
                        pass
                    con.execute(_inject_copy_option(_prog_fallback_sql,
                                                    _rg_clause_val)
                                or _prog_fallback_sql)
            finally:
                import shutil as _prog_sh
                _prog_sh.rmtree(_prog_parts_dir, ignore_errors=True)

        _t_query = _t.monotonic()

        # ── Read result metadata ──────────────────────────────────────────
        import pyarrow.parquet as pq
        meta = pq.read_metadata(output_path)
        total_rows = meta.num_rows
        file_size = os.path.getsize(output_path)

        _write_result({
            "total_rows": total_rows,
            "file_size_bytes": file_size,
            "timing": {
                # 2026-08-22 — spawn_s: parent stamp -> child _t0 (interpreter
                # spawn + module imports).  3 decimals: the value is tens of
                # ms and round(,2) would quantise a 34 ms spawn to 30/40.
                "spawn_s": round(_spawn_s, 3),
                "init_s":  round(_t_init - _t0, 2),
                "creds_s": round(_t_creds - _t_init, 2),
                "setup_s": round(_t_setup - _t_creds, 2),
                "query_s": round(_t_query - _t_setup, 2),
                "total_child_s": round(_t_query - _t0, 2),
            },
        })
        if _pool_root is not None:
            # Persistent instance: the release (close session, wipe +
            # VERIFY, stash-if-proven) is DEFERRED to after the worker's
            # ack — the parent has its result; the wipe costs it nothing.
            # The checkout invariant holds throughout: the stash stays
            # EMPTY until _pool_db_finish_request proves the catalog
            # clean, so no path can observe a dirty instance.
            _POOL_DB["pending_release"] = (con, _pool_root)
        else:
            con.close()

    except Exception as exc:
        import traceback
        traceback.print_exc(file=sys.stderr)
        # Phase 3 — ANY request error drops the persistent instance:
        # rotated credentials, a poisoned cached footer (file overwritten
        # in place), or state we simply cannot reason about.  The next
        # request builds fresh — self-healing, at worst today's cost.
        # The instance is CHECKED OUT into the local during the request
        # (the stash is empty by invariant) — close the local; the
        # module-level drop is belt-and-braces for the stashed state.
        try:
            if _pool_root is not None:
                _pool_root.close()
        except (NameError, UnboundLocalError):
            pass                     # failed before the connection existed
        except Exception as _be_exc:
            note_best_effort("_pool_root.close()", _be_exc,
                             logger=logger)
        _pool_db_drop("request errored")
        from core.proxy_utils import sanitize_proxy_error
        _write_result({"error": sanitize_proxy_error(f"{type(exc).__name__}: {exc}"), "timing": {}})
        sys.exit(1)
    finally:
        # P1c — stop the spill sampler and say how high the water got, so
        # even a query that FAILS leaves one line attributing its scratch.
        try:
            if _spill_stop is not None:
                _spill_stop.set()
            if int(_spill_hiwater.get("bytes", 0) or 0) > 0:
                _hw = int(_spill_hiwater["bytes"])
                print(f"SUBPROCESS: spill high-water "
                      f"{_hw / (1024 ** 3):.2f}GB (phase at exit: "
                      f"{_qs_phase.get('phase', '?')})",
                      file=sys.stderr, flush=True)
        except Exception:
            logger.debug("spill sampler stop failed (non-fatal)",
                         exc_info=True)
        # Clean up pre-downloaded temp files/dirs
        import shutil as _shutil
        for _tf in _temp_files:
            try:
                if os.path.isdir(_tf):
                    _shutil.rmtree(_tf, ignore_errors=True)
                else:
                    os.unlink(_tf)
            except OSError:
                pass


def _pool_worker_main():
    """Phase 168c — warm-worker request loop.

    Reads newline-delimited JSON request frames from stdin and runs each
    via :func:`_child_main` (which opens its OWN fresh ``:memory:``
    connection per request -> cross-request isolation by construction),
    then writes a one-line JSON ack to stdout.  The heavy interpreter +
    imports are paid ONCE at process start, not per request -- that's the
    saving over the legacy one-process-per-query path.

    Protocol:
      request  (parent->worker, stdin):  {"args":"<path>","result":"<path>"}\\n
      ack      (worker->parent, stdout): {"ok":true}\\n
                                         {"ok":false}\\n                (query error)
                                         {"ok":false,"recycle":true}\\n (fatal -> respawn)
      shutdown: an empty line or EOF ends the loop.

    A per-request QUERY error (``_child_main`` writes the error result +
    ``sys.exit(1)``) is caught as ``SystemExit`` and reported ok=false
    WITHOUT killing the worker -- the error result is already on disk.
    An unexpected framework error asks the parent to recycle this worker.
    """
    import sys as _sys
    import json as _json

    # Warm the heavy import once so the FIRST request doesn't pay it.
    try:
        import duckdb  # noqa: F401
    except Exception as _be_exc:
        note_best_effort("import duckdb", _be_exc,
                         logger=logger)

    # Give acks a PRIVATE OS fd so any NATIVE write to fd 1 (a DuckDB /
    # pyarrow progress print) can never corrupt the ack stream.  We dup
    # the real stdout pipe, then point OS fd 1 (and Python-level stdout)
    # at stderr for the rest of the process life.
    try:
        _ack_fd = os.dup(1)
        os.dup2(2, 1)
        try:
            _sys.stdout = _sys.stderr
        except Exception as _be_exc:
            note_best_effort("_sys.stdout = _sys.stderr", _be_exc,
                             logger=logger)
    except Exception:                                              # pragma: no cover
        _ack_fd = 1   # fallback: acks on fd 1 (best-effort)

    def _ack(**kw):
        try:
            os.write(_ack_fd, (_json.dumps(kw) + "\n").encode("utf-8"))
        except Exception as _be_exc:
            note_best_effort("os.write(_ack_fd, (_json.dumps(kw) + '\n').encode('utf-8'))", _be_exc,
                             logger=logger)

    # Pristine env snapshot -- restored before EACH request so a previous
    # request's proxy env (set_subprocess_proxy_env mutates os.environ)
    # can't leak into the next request on this long-lived worker.
    _env_snapshot = dict(os.environ)
    _sidecar = os.environ.get("DUCKDB_SUBPROCESS_SIDECAR", "").strip()

    _ack(ready=True)

    for _raw in _sys.stdin:
        _line = _raw.strip()
        if not _line:
            break                      # shutdown sentinel / EOF
        try:
            _frame = _json.loads(_line)
            _args = _frame["args"]
            _result = _frame["result"]
        except Exception as _fe:
            _ack(ok=False, error=f"bad request frame: {_fe}", recycle=True)
            return

        # Isolation: restore pristine env (drops A's proxy vars before B).
        try:
            for _k in list(os.environ.keys()):
                if _k not in _env_snapshot:
                    del os.environ[_k]
            for _k, _v in _env_snapshot.items():
                if os.environ.get(_k) != _v:
                    os.environ[_k] = _v
        except Exception as _be_exc:
            note_best_effort("os.environ[_k] = _v", _be_exc,
                             logger=logger)
        # Reset the per-worker sidecar so it tracks only THIS request's
        # predownload temp files (the parent drains it on a hard kill).
        if _sidecar:
            try:
                open(_sidecar, "w").close()
            except Exception as _be_exc:
                note_best_effort("open(_sidecar, 'w').close()", _be_exc,
                                 logger=logger)

        try:
            _child_main(_args, _result)
            _ack(ok=True)
            # Deferred instance release — AFTER the ack, so the parent
            # never waits on the wipe.  Single-threaded loop: this always
            # completes before the next frame is read.
            try:
                _pool_db_finish_request()
            except Exception:
                _pool_db_drop("deferred release failed")
        except SystemExit as _se:
            # Query-error path: error result already written to _result.
            _ack(ok=bool(_se.code in (0, None)))
            try:
                _pool_db_finish_request()
            except Exception:
                _pool_db_drop("deferred release failed")
        except BaseException as _be:   # noqa: BLE001 -- worker may be dirty
            try:
                import traceback as _tb
                _tb.print_exc(file=_sys.stderr)
            except Exception as _be_exc:
                note_best_effort("_tb.print_exc(file=_sys.stderr)", _be_exc,
                                 logger=logger)
            _ack(ok=False, error=str(_be)[:300], recycle=True)
            return


if __name__ == "__main__":
    if os.environ.get("DUCKDB_SUBPROCESS_POOL") == "1" or "--pool" in sys.argv:
        _pool_worker_main()
    else:
        _child_main()
