"""THE Jira connection (2026-10-31) -- one REST client for the change check
(core/feed/jira_link.py ``get_ticket``) and for alerts (core/feed/jira_sender.py).

REST API v2 on both flavours: Jira Server / Data Center and Jira Cloud both
accept ``/rest/api/2`` with a plain-text description and comment (v3 would
need Atlassian Document Format on Cloud only -- two shapes for one call).

The login is a System Account (``feed_generation.governance.jira.system_account``),
resolved through ``core.qs_credentials`` -- the one chokepoint every source
uses, Vault included.  ``auth``: ``bearer`` = a Server / Data Center personal
access token (the account's password); ``basic`` = Cloud (username = the
account's e-mail, password = an API token).  A 401 re-reads the account from
Vault ONCE (a rotated token heals on the next call, not after the cache TTL).

Every failure raises :class:`JiraError` with the words a support person can
act on; callers decide what a failure means (the change check: an OUTAGE
value; the sender: a retry).  Nothing here retries in a loop.
"""
from __future__ import annotations

import base64
from collections.abc import Callable, Mapping
from typing import Any

AUTH_BEARER = "bearer"
AUTH_BASIC = "basic"


class JiraError(RuntimeError):
    """Jira could not do what was asked; ``status`` is the HTTP code (None = no answer)."""

    def __init__(self, message: str, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status


def load_config() -> dict:
    """The declared ``feed_generation.governance.jira`` block (every key read
    here is declared in core/config.py)."""
    from core import config as _config
    gov = _config.get("feed_generation", "governance", {}) or {}
    raw = gov.get("jira", {}) or {}
    alerts = raw.get("alerts", {}) or {}
    return {
        "enabled": bool(raw.get("enabled", False)),
        "base_url": str(raw.get("base_url") or "").rstrip("/"),
        "auth": str(raw.get("auth") or AUTH_BEARER).strip().lower(),
        "system_account": str(raw.get("system_account") or "").strip(),
        "timeout_seconds": float(raw.get("timeout_seconds", 10)),
        "alerts": {
            "enabled": bool(alerts.get("enabled", False)),
            "project": str(alerts.get("project") or "").strip(),
            "issue_type": str(alerts.get("issue_type") or "Task"),
            "priority_by_severity": {str(k): str(v) for k, v in
                                     (alerts.get("priority_by_severity") or {}).items()},
            "labels": [str(x) for x in (alerts.get("labels") or [])],
            "resolve_transition": str(alerts.get("resolve_transition") or ""),
            "reopen_transition": str(alerts.get("reopen_transition") or ""),
            "poll_interval_seconds": float(alerts.get("poll_interval_seconds", 15)),
            "batch_size": max(1, int(alerts.get("batch_size", 50))),
            "max_attempts": max(1, int(alerts.get("max_attempts", 6))),
            "retry_backoff_seconds": float(alerts.get("retry_backoff_seconds", 60)),
        },
    }


def connection_refusal(cfg: Mapping[str, Any]) -> str | None:
    """Why no client can be built from this config, in plain words; None = it can."""
    if not cfg.get("base_url"):
        return "Jira is not set up: no address (feed_generation.governance.jira.base_url)."
    if cfg.get("auth") not in (AUTH_BEARER, AUTH_BASIC):
        return (f"Jira login type {cfg.get('auth')!r} is not known: use 'bearer' (Jira Server / "
                f"Data Center token) or 'basic' (Jira Cloud e-mail + API token).")
    if not cfg.get("system_account"):
        return ("Jira has no login: choose the System Account that holds it "
                "(feed_generation.governance.jira.system_account).")
    return None


def _account_creds(name: str, *, fresh: bool = False) -> dict:
    from core import qs_credentials as qc
    return qc.refresh(name) if fresh else qc.resolve_system_account(name)


class JiraRestClient:
    """``get_ticket`` / ``create_issue`` / ``add_comment`` / ``transition``.

    ``creds_fn(fresh: bool) -> {"username", "password"}`` and
    ``client_factory() -> httpx.Client`` are seams (tests inject fakes; the
    rig points ``base_url`` at its Jira stand-in)."""

    def __init__(self, base_url: str, *, auth: str, creds_fn: Callable[[bool], Mapping[str, Any]],
                 timeout: float = 10.0, client_factory: Callable | None = None) -> None:
        self._base = base_url.rstrip("/")
        self._auth = auth
        self._creds_fn = creds_fn
        self._timeout = timeout
        self._client_factory = client_factory

    # ── HTTP ──────────────────────────────────────────────────────────────
    def _headers(self, creds: Mapping[str, Any]) -> dict:
        h = {"Accept": "application/json", "Content-Type": "application/json"}
        if self._auth == AUTH_BASIC:
            raw = f"{creds.get('username') or ''}:{creds.get('password') or ''}".encode()
            h["Authorization"] = "Basic " + base64.b64encode(raw).decode()
        else:
            h["Authorization"] = f"Bearer {creds.get('password') or ''}"
        return h

    def _call(self, method: str, path: str, body: Mapping[str, Any] | None = None):
        import httpx
        factory = self._client_factory or (lambda: httpx.Client(timeout=self._timeout))
        url = f"{self._base}{path}"
        for fresh in (False, True):
            try:
                creds = self._creds_fn(fresh)
            except Exception as exc:                    # noqa: BLE001 -- a missing account is words
                raise JiraError(f"the Jira login could not be read: {exc}") from exc
            if not (creds or {}).get("password"):
                # an unreadable secret comes back EMPTY (core.crypto.decrypt_value
                # returns "" on a key mismatch); sending "Bearer " is a call that
                # cannot log in -- read it again once, then refuse in words
                if not fresh:
                    continue
                raise JiraError("the Jira login could not be read: the System Account holds no readable "
                                "token or password (empty, or it could not be decrypted with this pod's key) "
                                "-- nothing was sent to Jira")
            try:
                with factory() as client:
                    resp = client.request(method, url, headers=self._headers(creds),
                                          json=dict(body) if body is not None else None)
            except Exception as exc:                    # noqa: BLE001 -- network: no answer
                raise JiraError(f"Jira did not answer ({type(exc).__name__}: {exc})") from exc
            if resp.status_code != 401:
                return resp
            # a 401: the token may have been rotated -- read it from Vault again, once
        raise JiraError("Jira refused the login (401) twice -- the token in the System Account "
                        "is wrong or expired", 401)

    @staticmethod
    def _detail(resp) -> str:
        try:
            j = resp.json()
            msgs = list(j.get("errorMessages") or []) + [f"{k}: {v}" for k, v in
                                                         (j.get("errors") or {}).items()]
            return "; ".join(msgs)[:300] or resp.text[:300]
        except Exception:                               # noqa: BLE001
            return (resp.text or "")[:300]

    def _ok(self, resp, what: str):
        if 200 <= resp.status_code < 300:
            return resp
        raise JiraError(f"Jira answered {resp.status_code} to {what}: {self._detail(resp)}",
                        resp.status_code)

    # ── the four calls ────────────────────────────────────────────────────
    def get_ticket(self, key: str) -> dict | None:
        """{"key", "status"} or None when Jira says it does not exist (the
        change check's contract); any other failure raises (= an outage)."""
        resp = self._call("GET", f"/rest/api/2/issue/{key}?fields=status")
        if resp.status_code == 404:
            return None
        j = self._ok(resp, f"reading {key}").json()
        return {"key": j.get("key") or key,
                "status": ((j.get("fields") or {}).get("status") or {}).get("name")}

    def create_issue(self, *, project: str, issue_type: str, summary: str, description: str,
                     priority: str | None = None, labels: list[str] | None = None) -> str:
        fields: dict[str, Any] = {"project": {"key": project}, "issuetype": {"name": issue_type},
                                  "summary": summary[:250], "description": description}
        if priority:
            fields["priority"] = {"name": priority}
        if labels:
            fields["labels"] = [str(x).replace(" ", "_") for x in labels]
        resp = self._ok(self._call("POST", "/rest/api/2/issue", {"fields": fields}),
                        f"opening an issue in {project}")
        key = (resp.json() or {}).get("key")
        if not key:
            raise JiraError("Jira opened an issue but did not say its key")
        return str(key)

    def find_by_label(self, label: str) -> str | None:
        """The key of the issue carrying ``label`` (the alert's own label), or
        None.  What makes a retried "open the issue" safe: an issue Jira opened
        whose key we failed to store is FOUND, never opened twice."""
        from urllib.parse import quote
        jql = quote(f'labels = "{label}" ORDER BY created ASC')
        resp = self._ok(self._call("GET", f"/rest/api/2/search?jql={jql}&maxResults=1&fields=key"),
                        f"searching for the issue labelled {label}")
        issues = (resp.json() or {}).get("issues") or []
        return str(issues[0]["key"]) if issues else None

    def add_comment(self, key: str, text: str) -> None:
        self._ok(self._call("POST", f"/rest/api/2/issue/{key}/comment", {"body": text}),
                 f"commenting on {key}")

    def transition(self, key: str, name: str) -> bool:
        """Move ``key`` through the transition called ``name`` (case-insensitive).
        False = the issue's workflow offers no such transition now (already
        done, or another workflow) -- a fact, not an error."""
        resp = self._ok(self._call("GET", f"/rest/api/2/issue/{key}/transitions"),
                        f"reading the transitions of {key}")
        want = name.strip().lower()
        tid = next((t.get("id") for t in (resp.json() or {}).get("transitions") or []
                    if str(t.get("name", "")).strip().lower() == want), None)
        if tid is None:
            return False
        self._ok(self._call("POST", f"/rest/api/2/issue/{key}/transitions",
                            {"transition": {"id": str(tid)}}), f"moving {key} to {name!r}")
        return True


def client_from_config(cfg: Mapping[str, Any] | None = None) -> JiraRestClient:
    """The deployment's client, or :class:`JiraError` with the refusal."""
    cfg = cfg if cfg is not None else load_config()
    reason = connection_refusal(cfg)
    if reason:
        raise JiraError(reason)
    account = cfg["system_account"]
    return JiraRestClient(cfg["base_url"], auth=cfg["auth"],
                          creds_fn=lambda fresh: _account_creds(account, fresh=fresh),
                          timeout=cfg["timeout_seconds"])
