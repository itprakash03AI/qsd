"""The Jira channel of the alert road (2026-10-31) -- the sender.

``core.feed.feed_alerts`` marks an alert for Jira (``jira_state``) when its
kind has ``to_jira``; this module, on the scheduler pod (one sender, or every
pod opens the same issue), makes the calls.  Nothing here runs on a raiser's
path: a Jira outage DELAYS an issue, it never fails a feed or a run.

The state lives on the alert row, not in memory and not in the hour-reaped
notification queue: ``create`` / ``reopen`` / ``resolve`` = a call is owed;
``open`` / ``done`` = nothing owed; ``failed`` = given up after
``max_attempts`` (kept, counted on the status surface, logged CRITICAL).  A
restart loses nothing -- the next pass reads the same rows.

ONE issue per alert row.  A cleared alert that comes back re-opens the SAME
row (core/db/mixin_feeds.open_feed_alert), so its issue is commented on and
re-opened; a clear comments and moves it through ``resolve_transition``.

Retry safety is DECLARED, not assumed: opening an issue is not idempotent, so
every issue carries its alert's own label (``qs-alert-<id>``) and a retried
"open" first SEARCHES for it -- an issue Jira opened whose key we failed to
store is adopted, never opened twice.  A comment repeated after a lost answer
is the accepted cost (a duplicate comment, never a duplicate issue).
"""
from __future__ import annotations

import logging
import threading
from collections.abc import Callable, Mapping
from datetime import datetime, timedelta, timezone
from typing import Any

from core.feed.jira_client import JiraError, client_from_config, connection_refusal, load_config

logger = logging.getLogger(__name__)

DAEMON_NAME = "feed_jira_sender"
MAX_BACKOFF_SECONDS = 3600.0

_lock = threading.Lock()
_thread: threading.Thread | None = None
_stop = threading.Event()
_last_pass: dict[str, Any] = {}
_refusal: str | None = None


def alert_label(alert_id: int) -> str:
    return f"qs-alert-{int(alert_id)}"


def sender_refusal(cfg: Mapping[str, Any] | None = None) -> str | None:
    """Why the sender does not run, in plain words; None = it runs."""
    cfg = cfg if cfg is not None else load_config()
    if not cfg["alerts"]["enabled"]:
        return "Jira alerts are switched off (feed_generation.governance.jira.alerts.enabled)."
    if not cfg["alerts"]["project"]:
        return "Jira alerts have no project (feed_generation.governance.jira.alerts.project)."
    return connection_refusal(cfg)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _description(row: Mapping[str, Any]) -> str:
    lines = [str(row.get("message") or row.get("title") or "")]
    facts = [("Alert", row.get("kind")), ("Severity", row.get("severity")),
             ("Feed", row.get("feed_name")), ("About", row.get("subject_key")),
             ("Business date", row.get("business_date")), ("Run", row.get("execution_id")),
             ("Raised", row.get("raised_at"))]
    lines += [f"{k}: {v}" for k, v in facts if v not in (None, "")]
    lines.append(f"QueryStudio alert #{row.get('id')} -- this issue is updated by QueryStudio "
                 f"when the alert comes back or clears.")
    return "\n".join(lines)


def _mark_delivery(row: Mapping[str, Any], status: str, issue: str | None, at: str) -> list:
    """The row's deliveries with its LAST jira entry updated (the one this raise queued)."""
    ds = [dict(d) for d in (row.get("deliveries") or [])]
    for d in reversed(ds):
        if d.get("channel") == "jira":
            d.update({"status": status, "issue": issue, "sent_at": at})
            break
    return ds


def _create(client, row, acfg) -> str:
    label = alert_label(row["id"])
    if int(row.get("jira_attempts") or 0) > 0:          # a retry: did Jira open it last time?
        found = client.find_by_label(label)
        if found:
            return found
    sev = str(row.get("severity"))
    return client.create_issue(
        project=acfg["project"], issue_type=acfg["issue_type"], summary=str(row.get("title") or ""),
        description=_description(row), priority=acfg["priority_by_severity"].get(sev),
        labels=list(acfg["labels"]) + [label, str(row.get("kind") or "alert")])


def _step(db, client, row, acfg) -> str:
    """Make the one call this row owes; returns the new jira_state."""
    state, key, at = row.get("jira_state"), row.get("jira_issue_key"), _now().isoformat()
    if state == "create":
        key = _create(client, row, acfg)
        db.update_feed_alert(row["id"], {"jira_issue_key": key, "jira_state": "open",
                                         "jira_attempts": 0, "jira_next_at": None, "jira_error": None,
                                         "deliveries": _mark_delivery(row, "sent", key, at)})
        return "open"
    if state == "reopen":
        client.add_comment(key, f"The alert came back at {row.get('raised_at')}: {row.get('message')}")
        moved = bool(acfg["reopen_transition"]) and client.transition(key, acfg["reopen_transition"])
        db.update_feed_alert(row["id"], {
            "jira_state": "open", "jira_attempts": 0, "jira_next_at": None,
            "jira_error": None if moved or not acfg["reopen_transition"] else
            f"commented; the issue offers no {acfg['reopen_transition']!r} transition now",
            "deliveries": _mark_delivery(row, "sent", key, at)})
        return "open"
    if state == "resolve":
        client.add_comment(key, f"Cleared by {row.get('cleared_by') or 'QueryStudio'} at "
                                f"{row.get('cleared_at')}.")
        moved = bool(acfg["resolve_transition"]) and client.transition(key, acfg["resolve_transition"])
        db.update_feed_alert(row["id"], {
            "jira_state": "done", "jira_attempts": 0, "jira_next_at": None,
            "jira_error": None if moved or not acfg["resolve_transition"] else
            f"commented; the issue offers no {acfg['resolve_transition']!r} transition now"})
        return "done"
    return str(state)


def _failed(db, row, acfg, exc: Exception, counters) -> None:
    attempts = int(row.get("jira_attempts") or 0) + 1
    msg = str(exc)[:1000]
    if attempts >= acfg["max_attempts"]:
        db.update_feed_alert(row["id"], {"jira_state": "failed", "jira_attempts": attempts,
                                         "jira_error": f"gave up after {attempts} tries: {msg}"})
        counters["failed"] += 1
        logger.critical("[jira_sender] alert #%s (%s) NOT sent to Jira after %d tries -- %s",
                        row.get("id"), row.get("jira_state"), attempts, msg)
        return
    wait = min(MAX_BACKOFF_SECONDS, acfg["retry_backoff_seconds"] * (2 ** (attempts - 1)))
    db.update_feed_alert(row["id"], {"jira_attempts": attempts, "jira_error": msg,
                                     "jira_next_at": _now() + timedelta(seconds=wait)})
    counters["retrying"] += 1
    logger.warning("[jira_sender] alert #%s (%s) try %d failed, next in %.0f s: %s",
                   row.get("id"), row.get("jira_state"), attempts, wait, msg)


def run_pass(db, client, cfg: Mapping[str, Any] | None = None) -> dict:
    """One pass over the owed calls.  Never raises: one bad row never stops the rest."""
    cfg = cfg if cfg is not None else load_config()
    acfg = cfg["alerts"]
    counters = {"rows": 0, "sent": 0, "retrying": 0, "failed": 0}
    try:
        rows = db.list_jira_pending_alerts(_now(), limit=acfg["batch_size"])
    except Exception as exc:                            # noqa: BLE001 -- unknown is not "nothing owed"
        logger.error("[jira_sender] could not read the alerts owed to Jira: %s", exc)
        return {**counters, "error": f"could not read the alerts owed to Jira: {exc}"}
    for row in rows:
        counters["rows"] += 1
        try:
            _step(db, client, row, acfg)
            counters["sent"] += 1
        except Exception as exc:                        # noqa: BLE001 -- a retry, never a crash
            try:
                _failed(db, row, acfg, exc, counters)
            except Exception as exc2:                   # noqa: BLE001
                logger.error("[jira_sender] alert #%s: the failure could not be recorded: %s",
                             row.get("id"), exc2)
    return counters


def _loop(db, client_fn: Callable[[], Any], cfg) -> None:
    client = None
    while not _stop.is_set():
        try:
            client = client or client_fn()
            out = run_pass(db, client, cfg)
            _last_pass.update({**out, "at": _now().isoformat()})
        except Exception as exc:                        # noqa: BLE001
            _last_pass.update({"error": str(exc)[:500], "at": _now().isoformat()})
            logger.error("[jira_sender] pass failed: %s", exc)
            client = None
        _stop.wait(cfg["alerts"]["poll_interval_seconds"])


def start_sender(db, *, cfg: Mapping[str, Any] | None = None,
                 client_fn: Callable[[], Any] | None = None) -> bool:
    """Start the one sender thread; False (and the reason said at INFO) when it does not run."""
    global _thread, _refusal
    cfg = cfg if cfg is not None else load_config()
    with _lock:
        if _thread is not None and _thread.is_alive():
            return True
        _refusal = sender_refusal(cfg)
        if _refusal:
            logger.info("[jira_sender] not started: %s", _refusal)
            return False
        _stop.clear()
        _thread = threading.Thread(target=_loop, name=DAEMON_NAME, daemon=True,
                                   args=(db, client_fn or (lambda: client_from_config(cfg)), cfg))
        _thread.start()
        logger.info("[jira_sender] started: project %s, every %.0f s",
                    cfg["alerts"]["project"], cfg["alerts"]["poll_interval_seconds"])
        return True


def stop_sender(timeout: float = 10.0) -> None:
    global _thread
    _stop.set()
    t = _thread
    if t is not None:
        t.join(timeout)
    _thread = None


def get_status(db=None) -> dict:
    """Running or why not, the last pass, and the alerts by Jira state (failed = given up)."""
    out: dict[str, Any] = {"running": bool(_thread is not None and _thread.is_alive()),
                           "refusal": _refusal if _refusal is not None else sender_refusal(),
                           "last_pass": dict(_last_pass)}
    if db is not None:
        try:
            out["by_state"] = db.count_jira_alerts()
        except Exception as exc:                        # noqa: BLE001
            out["by_state_error"] = str(exc)[:300]
    return out
