"""Where a System Account's login may be SENT, and who may send it there
(2026-10-29).

A feed's SFTP destination is written inline: a host, a port and the System
Account whose username and password (from Vault) log in there.  Feed authors
may NAME an account an admin set up (``/api/feed-destinations/sftp/accounts``
lists them for that purpose) -- but until now nothing tied the account to a
HOST, so any author could save a feed (or press the SFTP form's Test, which
saves nothing) that sends the account's login to a host they control.

Two rules, one module:

  1. **The account says where it may log in.**  ``allowed_hosts`` in the
     account's ``config`` (Admin -> System Accounts): ``"sftp.bank.com"``
     (any port) or ``"sftp.bank.com:2222"``.  When it is set, a login to any
     other host is REFUSED on every road -- delivery on either lane, the
     Test buttons -- whoever asks (``login_refusal``).
  2. **Only an admin may send an account somewhere new.**  A feed author who
     is not an admin may save or test an SFTP destination that uses a System
     Account only when that host is on the account's ``allowed_hosts``, or the
     destination is unchanged from what is already saved (an admin-made feed
     keeps working when someone else edits its schedule).  Turning off the
     server's host-key check (``allow_unknown_host_key``) with an account is
     an admin's decision too: without it, a machine in the middle collects
     the password (``authoring_refusal``).

An account with no ``allowed_hosts`` keeps working for every feed already
saved -- nothing that delivers today stops -- and only an admin may point it
at a new host.

**The host's KEY is part of the approval** (the security review: an author
on an allowed host could pin their own key, and a machine answering for that
host would collect the password).  When an admin saves the account, the key
each allowed host presents is read by the server and stored beside the list
(``config.host_keys``, ``record_host_keys``); a login to that host must pin
exactly that key, whoever asks.  An admin whose server cannot reach a host
stores its key by hand.

**The destinations are read the way DELIVERY reads them**
(``sftp_destinations`` asks ``core/feed/delivery_hops.py::build_hop_plan``):
a hop typed ``target`` or ``target_type`` in any case is the same hop to the
gate and to delivery; a chain delivery cannot read is checked entry by entry
(fail closed), never skipped.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Tuple

DEFAULT_SFTP_PORT = 22


def account_ref(dest: Dict[str, Any]) -> Any:
    return (dest or {}).get("system_account_id") or (dest or {}).get("system_account_name")


def uses_account(dest: Dict[str, Any]) -> bool:
    """Does the ACCOUNT's login go out?  Whenever the destination names an
    account (2026-10-30).  The login rule puts the ACCOUNT first
    (core/qs_credentials/login.py::pair_login; core/feed/sftp_auth.py): a
    username + password typed on the destination no longer replaces the
    account's -- so this gate may not assume it does.  It used to answer
    "no" for a typed login, and with the new rule that let a destination
    send the ACCOUNT's credential to a host the account does not list.
    Naming an account is enough to be held to its rules; the safe
    direction for a credential gate."""
    return bool(account_ref(dest or {}))


def account_row(db, ref) -> Optional[Dict[str, Any]]:
    """The System Account row a destination names (by id or by name), or None."""
    if not ref or db is None:
        return None
    if isinstance(ref, int) or (isinstance(ref, str) and ref.strip().isdigit()):
        return db.get_system_account_raw(int(ref))
    return db.get_system_account_by_name_raw(str(ref))


def allowed_hosts(row: Optional[Dict[str, Any]]) -> List[str]:
    cfg = (row or {}).get("config") or {}
    raw = cfg.get("allowed_hosts") or []
    if isinstance(raw, str):
        raw = [p for p in raw.replace(",", " ").split()]
    return [str(h).strip().lower() for h in raw if str(h).strip()]


_HOST_ENTRY = None


def allowed_hosts_problem(config: Optional[Dict[str, Any]]) -> Optional[str]:
    """Why an account's ``allowed_hosts`` cannot be saved, or None.  Each
    entry is a host name or address, optionally ``:port`` -- never a URL."""
    import re
    global _HOST_ENTRY
    if _HOST_ENTRY is None:
        _HOST_ENTRY = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9.\-]*[A-Za-z0-9])?(?::\d{1,5})?$")
    raw = (config or {}).get("allowed_hosts")
    if raw in (None, "", []):
        return None
    if not isinstance(raw, list):
        return "allowed_hosts must be a list of host names, e.g. [\"sftp.bank.com\", \"10.1.2.3:2222\"]"
    bad = [str(h) for h in raw if not isinstance(h, str) or not _HOST_ENTRY.match(h.strip())]
    if bad:
        return (f"Allowed hosts must be host names or addresses, optionally with :port "
                f"(no https:// or sftp://, no paths): {bad[:5]}")
    return None


def _entry_key(entry: str) -> str:
    """``"host"`` -> ``"host:22"``: an allowed entry's key is recorded at its
    port (the SFTP default when none is written)."""
    h, _, p = entry.strip().lower().partition(":")
    return f"{h}:{p or DEFAULT_SFTP_PORT}"


def host_keys(row: Optional[Dict[str, Any]]) -> Dict[str, str]:
    """The approved key per ``host:port`` (base64 of the key blob) on an
    account row."""
    cfg = (row or {}).get("config") or {}
    out = {}
    for k, v in (cfg.get("host_keys") or {}).items():
        b64 = v.get("host_key_b64") if isinstance(v, dict) else v
        if b64:
            out[str(k).strip().lower()] = str(b64).strip()
    return out


def record_host_keys(config: Optional[Dict[str, Any]], fetch) -> Dict[str, Any]:
    """The account config with the key of every allowed host recorded.  An
    entry that already has a key keeps it (an admin may store one by hand);
    a removed entry loses its key.  ``fetch(host, port)`` reads the key the
    host presents (``api/feed_sftp_api.py::_read_host_key``); a host that
    cannot be read REFUSES the save -- an approval without its key would let
    the next author pin any key."""
    cfg = dict(config or {})
    wanted = {_entry_key(e) for e in allowed_hosts({"config": cfg})}
    have = {str(k).strip().lower(): v for k, v in (cfg.get("host_keys") or {}).items()
            if str(k).strip().lower() in wanted}
    for key in sorted(wanted - set(have)):
        host, _, port = key.partition(":")
        try:
            got = fetch(host, int(port))
        except Exception as exc:                          # noqa: BLE001
            raise ValueError(
                f"Could not read the host key of {host}:{port} to approve it "
                f"({type(exc).__name__}: {exc}).  Check that this server can reach it, "
                f"or store its key in host_keys yourself.") from exc
        have[key] = {"host_key_b64": got["host_key_b64"], "key_type": got.get("key_type"),
                     "fingerprint_sha256": got.get("fingerprint_sha256")}
    if have:
        cfg["host_keys"] = have
    else:
        cfg.pop("host_keys", None)
    return cfg


def _approved_key(row, host: str, port: int) -> Optional[str]:
    return host_keys(row).get(f"{host.lower()}:{port}")


def _pinned(dest: Dict[str, Any]) -> str:
    return (dest.get("host_key_b64") or "").strip()


def _host_port(dest: Dict[str, Any]) -> Tuple[str, int]:
    try:
        port = int(dest.get("port") or DEFAULT_SFTP_PORT)
    except (TypeError, ValueError):
        port = DEFAULT_SFTP_PORT
    return str(dest.get("host") or "").strip().lower(), port


def host_allowed(row: Optional[Dict[str, Any]], host: str, port: int) -> bool:
    for entry in allowed_hosts(row):
        h, _, p = entry.partition(":")
        if h == host.lower() and (not p or p == str(port)):
            return True
    return False


def _name(row: Optional[Dict[str, Any]], ref) -> str:
    return str((row or {}).get("name") or ref)


def login_refusal(db, dest: Dict[str, Any]) -> Optional[str]:
    """Rule 1, at the moment of logging in: the reason this destination may
    not use its System Account, or None.  Read by every road that turns an
    SFTP destination into a login."""
    ref = account_ref(dest)
    if not ref or not uses_account(dest):
        return None
    if db is None:                      # a lane wired without the module's db
        from core.database import get_db_manager
        db = get_db_manager()
    row = account_row(db, ref)
    if row is None or not allowed_hosts(row):
        return None
    host, port = _host_port(dest)
    if host_allowed(row, host, port):
        approved = _approved_key(row, host, port)
        if approved and _pinned(dest) != approved:
            return (f"System Account {_name(row, ref)!r} may log in to {host}:{port} only "
                    f"to the server whose key was approved with it, and this destination "
                    f"does not pin that key.  Fetch the host key again; if the server's key "
                    f"really changed, an admin saves the account again to approve the new one.")
        return None
    return (f"System Account {_name(row, ref)!r} may log in only to "
            f"{', '.join(allowed_hosts(row))}; this destination is {host}:{port}.  "
            f"An admin can add the host to the account's Allowed hosts "
            f"(Admin -> System Accounts).")


def _same_destination(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    """Unchanged = the same account, host and port AND the same way of
    checking the server (pinned key, known_hosts file, or none)."""
    return (str(account_ref(a)) == str(account_ref(b))
            and _host_port(a) == _host_port(b)
            and bool(a.get("allow_unknown_host_key")) == bool(b.get("allow_unknown_host_key"))
            and _pinned(a) == _pinned(b)
            and (a.get("known_hosts_path") or "").strip() == (b.get("known_hosts_path") or "").strip())


def authoring_refusal(db, user: Dict[str, Any], dest: Dict[str, Any],
                      stored: Iterable[Dict[str, Any]] = ()) -> Optional[str]:
    """Rule 2, when a destination is saved or tested: the reason this user may
    not send its System Account there, or None.  ``stored`` = the SFTP
    destinations already saved on this feed (an unchanged one stays allowed)."""
    from core.roles import is_admin_like
    ref = account_ref(dest)
    if not ref or not uses_account(dest) or is_admin_like(user):
        return None
    # an unchanged SAVED destination stays allowed -- but only one that itself
    # sent the account's login: a saved destination with its own login only
    # NAMED the account, and clearing its password must not turn that into an
    # approval nobody gave (the security review, 2026-10-29)
    if any(uses_account(s or {}) and _same_destination(dest, s or {}) for s in stored):
        return None
    row = account_row(db, ref)
    name = _name(row, ref)
    if dest.get("allow_unknown_host_key"):
        return (f"Only an admin can use System Account {name!r} without checking "
                f"the server's host key: without it, a machine in the middle can "
                f"collect the login.  Fetch the host key in the form instead.")
    if (dest.get("known_hosts_path") or "").strip():
        return (f"Only an admin can check the server of System Account {name!r} against a "
                f"known_hosts file; pin the host key fetched in the form instead.")
    host, port = _host_port(dest)
    if row is not None and host_allowed(row, host, port):
        approved = _approved_key(row, host, port)
        if approved and _pinned(dest) == approved:
            return None
        if not approved:
            return (f"System Account {name!r} has no approved host key for {host}:{port}.  "
                    f"Ask an admin to save the account (Admin -> System Accounts) so the "
                    f"server's key is recorded with it.")
        return (f"The host key on this destination is not the one approved for System "
                f"Account {name!r} on {host}:{port}.  Fetch the host key again; if the "
                f"server's key really changed, an admin saves the account again.")
    return (f"Only an admin can send System Account {name!r} to {host}:{port}.  "
            f"Ask an admin to add this host to the account's Allowed hosts "
            f"(Admin -> System Accounts), or to set up this destination.")


def sftp_destinations(feed_like: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Every SFTP destination a feed body carries: the main one and each SFTP
    hop of its delivery chain."""
    out: List[Dict[str, Any]] = []
    if str(feed_like.get("destination_type") or "").strip().lower() == "sftp":
        out.append(dict(feed_like.get("destination_config") or {}))
    chain = feed_like.get("delivery_chain")
    if not chain:
        return out
    try:
        from core.feed.delivery_hops import build_hop_plan
        plan = build_hop_plan({"delivery_chain": chain})
        out += [dict(h.config or {}) for h in plan if str(h.target_type).lower() == "sftp"]
    except Exception:                                     # noqa: BLE001 -- fail CLOSED
        # a chain delivery cannot read: every entry naming an account is
        # checked as if it were an SFTP hop, never skipped
        for hop in chain if isinstance(chain, list) else []:
            if not isinstance(hop, dict):
                continue
            cfg = hop.get("config") if isinstance(hop.get("config"), dict) else hop
            if account_ref(cfg) or account_ref(hop):
                out.append(dict(cfg if account_ref(cfg) else hop))
    return out


__all__ = ["allowed_hosts_problem", "authoring_refusal", "login_refusal", "record_host_keys",
           "sftp_destinations"]
