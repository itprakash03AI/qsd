"""Who hears about a feed -- ONE answer for every feed-scoped WS event
(2026-10-07).

Found live on the Docker rig (``scripts/docker_proof/feed_triggers_proof.py``
with a browser socket open as the feed's owner): a run the queue worker
executed -- released from a dependency WAIT, a backfill, an upstream-
completion trigger -- produced NO feed events in the owner's browser, only
one ``feed_dep_ready``.  Two rules answered the same question:

* ``dependency_skip.release_admitted_run`` addressed ``feed_dep_ready`` to the
  feed's OWNER (``created_by``);
* the engine addressed ``feed_progress`` / ``feed_completed`` / ``feed_failed``
  / ``feed_cancelled`` / ``feed_run_log`` to ``triggered_by`` -- the ACTOR --
  and the queue worker passes ``triggered_by="queue_worker"``, a name no
  user has.  Every scheduled / released / backfilled / chained run was
  invisible live to everybody; only a user's own Run Now was seen.

A decision made twice is a bug.  :func:`feed_event_audience` is the decision;
every producer of a feed-scoped event calls it (a guard,
``tests/test_feed_event_audience_guard_2026_10_07.py``, sweeps the backend
for every emit of a :data:`FEED_EVENT_TYPES` member and fails on one that
does not).

THE RULE -- the product's existing feed SHARING rule, nothing invented:

1. the ACTOR, when the actor is a real user (a manual Run Now, a rerun, a
   retry -- the person who pressed the button keeps hearing about it);
2. the feed's OWNER (``feed_configs.created_by``);
3. every member of the feed's OWNER GROUP (``owner_group_id``) -- the same
   membership ``permissions.can_view_feed`` grants VIEW on.

Deliberately NOT in it:

* admin / support.  Their view is ROLE-WIDE -- a read grant to the estate,
  not membership in one feed's audience.  Addressing them would send every
  feed's every event to every admin browser: the broadcast-all class in
  another spelling (Netcool rows reaching every browser was that leak).
* ``consumer_group_ids``.  A declaration, NOT a view grant (qs-feedgen,
  2026-09-28); a consumer is told through its own subscription
  (``consumer_notices``), which addresses the subscriber.
* anyone, when nothing resolves.  An unknown feed and a system actor is an
  EMPTY audience and the event goes nowhere -- never to every browser.

4. the person who ASKED for the run (2026-10-07 follow-up) -- the run row's
   ``triggered_by_user``: a backfill's requester (``run_backfill(
   requested_by=)``), a whole-run rerun's, an external trigger's caller.
   The run's actor is ``queue_worker`` when the queue executes it, so the
   requester is only known when the producer NAMES THE RUN (``run=`` the
   row, or ``run_id=``); the guard requires every call to.

A PLATFORM event -- about the deployment, not one feed
(:data:`PLATFORM_EVENT_TYPES`: the failover agent's backend override) -- has
no feed audience; :func:`platform_event_audience` answers it: every user
holding the admin role, from the users/roles store.  Nobody resolvable is
nobody, never everybody.

``triggered_by`` stays the run's RECORDED actor everywhere; only the
ADDRESSING reads this module.  A system actor is never a username:
:data:`SYSTEM_ACTORS` is the declared vocabulary, and a name with a ``:``
(``pipeline:x``, ``backfill:alice``, ``pv:slug``) is synthetic by the
WebSocket layer's own convention (BF-110).

The addressed payload carries :data:`AUDIENCE_KEY` (a list) and, for a
consumer from before this change, ``username`` = its first name.  The bus
(``core.event_bus``) carries the list across pods and through the
notification outbox; ``core.event_bus.recipients_of`` is the ONE reader on
the delivering side, and ``WebSocketManager.deliver_addressed`` delivers to
exactly those names.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional

logger = logging.getLogger(__name__)

#: The routing key a feed event's audience travels under.  The bus, the
#: outbox drain and the WebSocket manager read it through
#: ``core.event_bus.recipients_of``; it is stripped before a browser sees
#: the message.
AUDIENCE_KEY = "audience"

#: Actor names that are the SYSTEM, never a person.  Every name the feed
#: platform records as ``triggered_by`` for a run nobody pressed a button
#: for.  ``tests/test_feed_event_audience_guard_2026_10_07.py`` sweeps the
#: feed modules for every literal ``triggered_by`` and fails on one that is
#: not here -- a new system name would otherwise be addressed as a user.
SYSTEM_ACTORS = frozenset({
    "queue_worker",          # core/feed/queue_worker.py (every claimed run)
    "queue",
    "scheduler",             # APScheduler cron fire, SLA tracker
    "cron",
    "sod",                   # start-of-day generation
    "sod_catchup",           # models.FEED_RUN_SOD_CATCHUP_TRIGGER (a missed due date)
    "backfill",              # SodTaskGenerator.run_backfill
    "retry",                 # a retry re-queued as a new attempt (core/feed/handover.py, 2026-11-02)
    "upstream_completion",   # models.FEED_RUN_UPSTREAM_TRIGGER
    "rerun",                 # the run ROW of a rerun (the execution names the user)
    "restatement",           # core/feed/restatement.py (a re-sent upstream re-runs a date)
    "external",              # POST /api/feeds/trigger/external
    "airflow",
    "otg",
    "orchestrator",          # feed_executor._default_triggered_by fallback
    "etl_scheduler",
    "reconciler",
    "feed_engine",
    "system",
    "unknown",               # execute_feed's default
})

#: The feed-scoped WebSocket event vocabulary.  Every one of these is
#: addressed through :func:`feed_event_audience`; the guard finds every emit
#: of one in the backend and refuses an emit of a ``feed_*`` type that is not
#: declared here (or declared exempt in the guard, with its reason).
FEED_EVENT_TYPES = frozenset({
    "feed_progress",
    "feed_completed",
    "feed_failed",
    "feed_cancelled",
    "feed_run_log",
    "feed_status",
    "feed_dep_ready",
    "feed_dep_sla_breach",
    "feed_dep_wait_escalated",
    "feed_sla_breach",
})

#: Events that start ``feed_`` but are about the DEPLOYMENT, not one feed.
#: Addressed through :func:`platform_event_audience` (the guard holds them
#: to it exactly as it holds :data:`FEED_EVENT_TYPES` to
#: :func:`feed_event_audience`).
PLATFORM_EVENT_TYPES = frozenset({
    "feed_backend_override_changed",   # core/feed/failover_agent.py::_apply
})


def is_system_actor(name: Any) -> bool:
    """True when ``name`` is not a person: empty, a declared system name, or
    a synthetic ``kind:value`` name."""
    if not isinstance(name, str) or not name.strip():
        return True
    n = name.strip()
    return n.lower() in SYSTEM_ACTORS or ":" in n


def _dedupe(names: Iterable[Any]) -> List[str]:
    out: List[str] = []
    seen: set = set()
    for n in names:
        if not isinstance(n, str):
            continue
        n = n.strip()
        if not n or ":" in n or n.lower() in seen:
            continue
        seen.add(n.lower())
        out.append(n)
    return out


def _group_members(db: Any, group_id: Any) -> List[str]:
    try:
        gid = int(group_id)
    except (TypeError, ValueError):
        return []
    lister = getattr(db, "list_user_group_members", None)
    if lister is None:
        return []
    try:
        rows = lister(gid)
    except Exception as exc:  # noqa: BLE001 -- advisory, never raises
        logger.warning("[feed_event_audience] owner group %s members could "
                       "not be read (%s) -- its members will not hear this "
                       "event", gid, exc)
        return []
    if not isinstance(rows, list):
        return []
    return [r.get("username") for r in rows if isinstance(r, Mapping)]


def _run_requester(db: Any, run: Optional[Mapping], run_id: Any) -> Any:
    """The person who asked for the run (``feed_runs.triggered_by_user``),
    from the row the caller holds, else read by id.  ``None`` when there is
    no run or it cannot be read (logged) -- the rest of the audience stands."""
    if isinstance(run, Mapping):
        return run.get("triggered_by_user")
    if run_id is None or db is None:
        return None
    getter = getattr(db, "get_feed_run", None)
    if getter is None:
        return None
    try:
        row = getter(int(run_id))
    except Exception as exc:  # noqa: BLE001 -- advisory, never raises
        logger.warning("[feed_event_audience] run %s could not be read (%s) "
                       "-- the person who asked for it will not hear this "
                       "event", run_id, exc)
        return None
    return row.get("triggered_by_user") if isinstance(row, Mapping) else None


def feed_event_audience(db: Any, feed_id: Any, actor: Optional[str] = None,
                        *, feed: Optional[Mapping] = None,
                        run: Optional[Mapping] = None,
                        run_id: Any = None) -> List[str]:
    """THE answer to "who hears about this feed" -- see the module docstring.

    ``feed`` (the config dict) skips the read when the caller holds it.
    ``run`` (the feed_runs row) or ``run_id`` names the run the event is
    about, so the person who ASKED for it (``triggered_by_user``) hears it;
    ``None`` when the event has no run.  Returns an ordered, de-duplicated
    list: the actor (if a person), the requester (if a person), the owner,
    then the owner group's members.  Never raises: a feed that cannot be
    read yields the actor and requester alone, logged -- never "everybody".
    """
    names: List[Any] = []
    if not is_system_actor(actor):
        names.append(actor)
    requester = _run_requester(db, run, run_id)
    if not is_system_actor(requester):
        names.append(requester)
    cfg: Optional[Mapping] = feed if isinstance(feed, Mapping) else None
    if cfg is None and feed_id is not None and db is not None:
        try:
            got = db.get_feed_config(int(feed_id))
            cfg = got if isinstance(got, Mapping) else None
        except Exception as exc:  # noqa: BLE001
            logger.warning("[feed_event_audience] feed %s could not be read "
                           "(%s) -- only the actor (if a person) will hear "
                           "this event", feed_id, exc)
    if cfg:
        owner = cfg.get("created_by")
        if not is_system_actor(owner):
            names.append(owner)
        if cfg.get("owner_group_id"):
            names.extend(_group_members(db, cfg.get("owner_group_id")))
    return _dedupe(names)


def _holds_role(user: Mapping, role: str) -> bool:
    from core.roles import ROLE_ADMIN, is_admin_like
    if role == ROLE_ADMIN:
        return is_admin_like(dict(user))
    return str(user.get("role") or "").strip().lower() == role


def platform_event_audience(db: Any, *, role: str = "admin") -> List[str]:
    """THE answer to "who hears about a PLATFORM event" -- every user
    holding ``role`` (``"admin"`` = the admin tier, ``core.roles``).

    Read from the users/roles store the auth layer itself uses:

    * ``auth.type == "none"`` -- every browser is the guest admin
      (``_get_current_user``'s principal), so the guest is the audience;
    * the explicit per-user mapping ``auth.user_roles`` -- what
      ``GET /api/admin/users`` lists and ``ad_auth._resolve_role`` reads
      FIRST;
    * the live sessions (``user_sessions``, unexpired) -- the role the auth
      layer resolved at login, which is the only record of an AD admin by
      GROUP (in no mapping).  A browser socket is identified only through a
      session when auth is on, so nobody who could receive the event is
      missed.

    A source that cannot be read is logged and skipped.  Nobody resolvable
    is an EMPTY audience: the event goes to nobody, never to everybody.
    """
    role = str(role or "").strip().lower()
    if not role:
        return []
    names: List[Any] = []
    try:
        from core.config import auth as _auth
        auth_type = str(getattr(_auth, "type", "") or "").strip().lower()
        if auth_type == "none":
            guest = {"username": "guest", "role": "admin", "is_admin": True}
            return ["guest"] if _holds_role(guest, role) else []
        for user, r in (_auth.user_roles or {}).items():
            if _holds_role({"username": user, "role": r}, role):
                names.append(user)
    except Exception as exc:  # noqa: BLE001 -- advisory, never raises
        logger.warning("[platform_event_audience] the role mapping could not "
                       "be read (%s) -- mapped %s users will not hear this "
                       "event", exc, role)
    session_scope = getattr(db, "get_session", None)
    if session_scope is not None:
        try:
            from datetime import datetime, timezone
            from core.db.models import UserSession
            now = datetime.now(timezone.utc).replace(tzinfo=None)
            with session_scope() as s:
                rows = (s.query(UserSession.user_data)
                        .filter(UserSession.expires_at > now).all())
            for (data,) in rows:
                if isinstance(data, Mapping) and _holds_role(data, role):
                    names.append(data.get("username"))
        except Exception as exc:  # noqa: BLE001
            logger.warning("[platform_event_audience] live sessions could "
                           "not be read (%s) -- a %s known only by AD group "
                           "will not hear this event", exc, role)
    return _dedupe(names)


def address(payload: Dict[str, Any], audience: List[str]) -> Dict[str, Any]:
    """Stamp a resolved audience onto ``payload`` (in place; returned).

    ``username`` is the first name -- the single-recipient key a consumer
    from before this change routes on -- and is REMOVED when the audience
    is empty, so nothing downstream reads an empty address as "everybody".
    """
    aud = _dedupe(audience or [])
    payload[AUDIENCE_KEY] = aud
    if aud:
        payload["username"] = aud[0]
    else:
        payload.pop("username", None)
    return payload


def bridge_feed_event_to_bus(payload: Dict[str, Any], *,
                             publish: Callable[..., None]) -> bool:
    """The engine-to-bus bridge every pod installs as ``feed_engine.
    _broadcast_fn`` (main.py's ``_feed_ws_broadcast``, feed_worker.py's
    ``_feed_bus_broadcast``, the scheduler pod's queue relay).

    Reads the audience the PRODUCER resolved -- the bridge decides nothing.
    ``triggered_by`` is the recorded actor, not an address: it is removed
    from the delivered body (the shape the UI has always received).  A
    payload with NO audience is a producer bug: WARNING and dropped --
    never published unaddressed (broadcast-all).  Returns whether it was
    published.
    """
    payload.pop("triggered_by", None)
    event_type = (payload.get("type") or payload.get("event")
                  or "execution_progress")
    if AUDIENCE_KEY not in payload:
        logger.warning(
            "[feed_event_audience] feed event %s (feed_id=%s) carries no "
            "audience -- a producer bypassed feed_event_audience; DROPPED "
            "rather than sent to every browser", event_type,
            payload.get("feed_id"))
        return False
    audience = list(payload.pop(AUDIENCE_KEY) or [])
    payload.pop("username", None)
    if not audience:
        logger.debug("[feed_event_audience] %s for feed %s has an empty "
                     "audience (system actor, unowned feed) -- not sent",
                     event_type, payload.get("feed_id"))
        return False
    publish(event_type, payload, audience=audience)
    return True


#: Event kinds the scheduler-pod relay does NOT send: one durable outbox
#: row per log line would turn the notification outbox into a log sink.
_NOT_RELAYED_VIA_OUTBOX = frozenset({"feed_run_log"})

# ── Does this pod stream a run's log lines live? (2026-10-07) ─────────────
#
# A run executed where the engine's broadcast is the scheduler relay (or
# nothing) streams NO ``feed_run_log`` lines, and the UI's log view sat on
# "Waiting for log lines..." forever.  The executing engine records which
# case it is on the execution (``feed_executions.log_stream``) and the
# payload tells the UI (``core.feed.run_log_view``).  It is a DECLARATION
# by whoever installs the broadcast -- unknown = "none", never a guess
# that lines will come.

#: The broadcast delivers every ``feed_run_log`` line to the audience.
RUN_LOG_LIVE = "live"
#: It does not (the scheduler pod's relay, or no broadcast at all).
RUN_LOG_NONE = "none"


def streams_run_log(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Declare that ``fn`` -- an engine broadcast built on
    :func:`bridge_feed_event_to_bus` (main.py, feed_worker.py) -- delivers
    the per-line log stream.  Returns ``fn``."""
    fn.streams_run_log = True
    return fn


def run_log_stream_of(broadcast_fn: Any) -> str:
    """:data:`RUN_LOG_LIVE` when ``broadcast_fn`` DECLARED it streams the
    log (:func:`streams_run_log`), else :data:`RUN_LOG_NONE`."""
    if broadcast_fn is not None and getattr(broadcast_fn, "streams_run_log",
                                            False) is True:
        return RUN_LOG_LIVE
    return RUN_LOG_NONE


def relay_feed_event_via_scheduler(payload: Dict[str, Any]) -> bool:
    """``feed_engine._broadcast_fn`` on the SCHEDULER pod (2026-10-07).

    That pod's queue worker executes feeds and its engine was wired with
    ``broadcast_fn=None``: every run it executed was silent in every
    browser.  The addressed event rides the scheduler's own broadcast
    (``core.scheduler._broadcast`` -- on that pod the notification queue,
    which every API pod's relay drains and delivers to the event's
    audience).  Same contract as :func:`bridge_feed_event_to_bus`: the
    producer's audience is honoured, an unaddressed payload is dropped
    loudly, an empty audience is not sent.  Returns whether it was sent.
    """
    kind = payload.get("type") or payload.get("event")
    if kind in _NOT_RELAYED_VIA_OUTBOX:
        return False
    if AUDIENCE_KEY not in payload:
        logger.warning(
            "[feed_event_audience] feed event %s (feed_id=%s) carries no "
            "audience -- DROPPED rather than queued unaddressed", kind,
            payload.get("feed_id"))
        return False
    if not payload.get(AUDIENCE_KEY):
        return False
    payload.pop("triggered_by", None)
    from core import scheduler as _sch
    _sch._broadcast(payload)
    return True


# The relay never sends a log line (above): declared, so a run on the
# scheduler pod says "live tail unavailable" instead of an empty tail.
relay_feed_event_via_scheduler.streams_run_log = False
