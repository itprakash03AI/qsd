"""HANDING a feed run to the feed-worker pods -- the ONE road (2026-11-02).

The owner: "no feed gen will be here [the scheduler pod]"; "feed worker should
do feed work".  ``core/responsibilities.py`` says which process may RUN a
feed (``owns(FEED_RUNS)``).  Every other process -- the scheduler pod firing a
feed's cron, an API pod answering Run Now / a dry run / a retry / the external
trigger -- puts the run ON THE QUEUE through this module and nothing else:

* the ``feed_runs`` row is left ``pending`` (never claimed here) with
  ``handed_over_at`` stamped, which the queue worker reads as "claim me now":
  no cron grace (``_filter_cron_owned``), and a manual row is admitted
  although ``run_type='manual'`` normally keeps the queue's hands off it;
* a Run Now carries its whole request in ``run_request`` -- the execution id
  the caller was given, the business date, parameter values, the lane, the
  dependency override, dry run, Iceberg version overrides -- so the worker
  runs exactly what the person asked, through the same ``run_feed`` seam the
  API process used to call in-process.

A process that DOES own feed runs (a standalone install) still goes through
here: the row is queued the same way and :func:`nudge_local_worker` asks its
own queue worker to poll at once, so a Run Now starts within a second there
too.  One road, one row shape, whatever the topology.

Kept from ``run_scheduled_feed``'s in-process branches, by meaning:
  WAIT / SKIP / running  -> nothing is queued (the dependency poller releases a
                            WAIT; a SKIP is the day's verdict; a run in flight
                            is not doubled);
  pending (RUN)          -> handed over as is;
  failed                 -> re-queued (the retry on the next fire), a new attempt;
  completed / cancelled  -> re-queued as a NEW ATTEMPT of the (feed, date) task
                            (an intra-day cron, e.g. hourly) -- the same model as
                            an operator's re-run (core/feed/rerun.py): the run row
                            is the task, every attempt its own execution;
  no row                 -> created pending RUN (a WAIT when the creation-time
                            dependency check says so) and handed over.
"""
from __future__ import annotations

import logging
import threading
from datetime import datetime, timezone
from typing import Any, Dict, Mapping, Optional

logger = logging.getLogger(__name__)

#: ``feed_runs.triggered_by`` of a row the scheduler's cron fire handed over.
CRON_HANDOVER_TRIGGER = "scheduler"
#: ``action_reason`` written on a row re-queued by a later cron fire.
INTRADAY_REFIRE_REASON = "the feed's schedule fired again today; a new attempt was queued"
RETRY_REASON = "retried after a failed attempt"
HANDED_OVER_WORDS = "queued for a feed-worker pod"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def is_handed_over(row: Optional[Mapping[str, Any]]) -> bool:
    return bool(row and row.get("handed_over_at"))


def hand_over_row(db, run_id: int, *, extra: Optional[Dict[str, Any]] = None) -> Optional[dict]:
    """Stamp ``handed_over_at`` (and ``extra``) on a PENDING row; the queue
    worker may claim it at once."""
    data = {"handed_over_at": _now()}
    if extra:
        data.update(extra)
    out = db.update_feed_run(int(run_id), data)
    nudge_local_worker()
    return out


def requeue_as_new_attempt(db, row: Mapping[str, Any], *, reason: str,
                           triggered_by: str = CRON_HANDOVER_TRIGGER,
                           triggered_by_user: Optional[str] = None) -> Optional[dict]:
    """A finished / failed row goes back on the queue as a new attempt (the
    re-run model, core/feed/rerun.py::requeue), handed over."""
    data = {
        "status": "pending",
        "started_at": None,
        "completed_at": None,
        "error": None,
        "claimed_by": None,
        "action_decision": "RUN",
        "action_reason": reason,
        "triggered_by": triggered_by,
        "retry_count": int(row.get("retry_count") or 0) + 1,
        "released_at": _now(),
        "handed_over_at": _now(),
    }
    if triggered_by_user:
        data["triggered_by_user"] = str(triggered_by_user)[:100]
    out = db.update_feed_run(int(row["id"]), data)
    nudge_local_worker()
    return out


def hand_over_cron_fire(db, feed_config_id: int, fc: Mapping[str, Any],
                        bdate, today, row: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    """The per-feed cron fired in a process that runs no feeds: make sure
    the day's row exists and is claimable, run nothing.  Returns what was
    done, in words, for the log and the tests."""
    if row is None:
        from core.feed.etl_dependency import hold_reason_at_creation
        hold = None
        try:
            hold = hold_reason_at_creation(db, fc, bdate)
        except Exception as exc:                          # noqa: BLE001 -- fail-open like the in-process fire
            logger.warning("[handover] feed %s: dependency check at creation failed (%s) -- "
                           "the run is queued RUN", feed_config_id, exc)
        data = {
            "feed_config_id": int(feed_config_id),
            "business_date": bdate,
            "run_date": today,
            "scheduled_time": _now(),
            "status": "pending",
            "triggered_by": CRON_HANDOVER_TRIGGER,
            "run_type": "scheduled",
            "action_decision": "WAIT" if hold else "RUN",
            "action_reason": hold or None,
        }
        if not hold:
            data["handed_over_at"] = _now()
        try:
            created = db.create_feed_run(data)
        except Exception as exc:                          # noqa: BLE001 -- lost the create race
            logger.info("[handover] feed %s: create lost a race (%s) -- re-reading", feed_config_id, exc)
            row = db.get_feed_run_by_feed_date(int(feed_config_id), bdate)
            if row is None:
                return {"action": "error", "detail": str(exc)[:300]}
            return hand_over_cron_fire(db, feed_config_id, fc, bdate, today, row)
        if hold:
            return {"action": "created_wait", "run_id": created.get("id"), "detail": hold}
        nudge_local_worker()
        return {"action": "created", "run_id": created.get("id"), "detail": HANDED_OVER_WORDS}

    status = str(row.get("status") or "").lower()
    decision = str(row.get("action_decision") or "RUN").upper()
    if status == "skipped" or decision == "SKIP":
        return {"action": "left_skip", "run_id": row.get("id"),
                "detail": row.get("action_reason") or "SOD verdict SKIP"}
    if decision == "WAIT" and status == "pending":
        return {"action": "left_wait", "run_id": row.get("id"),
                "detail": "the dependency poller releases it"}
    if status == "running":
        return {"action": "left_running", "run_id": row.get("id"),
                "detail": f"in flight (claimed_by={row.get('claimed_by')})"}
    if status == "pending":
        if is_handed_over(row):
            return {"action": "already_handed_over", "run_id": row.get("id")}
        hand_over_row(db, int(row["id"]))
        return {"action": "handed_over", "run_id": row.get("id"), "detail": HANDED_OVER_WORDS}
    if status == "failed":
        requeue_as_new_attempt(db, row, reason=RETRY_REASON)
        return {"action": "requeued_failed", "run_id": row.get("id")}
    # completed / cancelled: the intra-day refire -- a new attempt of the task
    requeue_as_new_attempt(db, row, reason=INTRADAY_REFIRE_REASON)
    return {"action": "requeued_refire", "run_id": row.get("id"), "previous_status": status}


def enqueue_manual_run(db, *, feed_id: int, execution_id: str, trigger_type: str,
                       triggered_by: str, business_date=None,
                       param_values: Optional[Dict[str, Any]] = None,
                       backend_override: Optional[str] = None,
                       dependencies_overridden: Optional[Dict[str, Any]] = None,
                       dry_run: bool = False,
                       version_overrides: Optional[Dict[str, Any]] = None) -> dict:
    """A Run Now / dry run / orchestrator trigger from an API pod: ONE pending
    manual row carrying the whole request, handed over.  The execution row
    (``feed_executions``, ``execution_id``) was created by the caller and is
    REUSED by the worker's ``run_feed`` -- the id the caller got back is the
    id of the run that happens."""
    from core.feed_executor import (DRY_RUN_TYPE, MANUAL_RUN_TYPE, manual_build_id,
                                    manual_override_reason)
    today = _now().date()
    bdate = business_date
    if isinstance(bdate, str) and bdate:
        try:
            bdate = datetime.fromisoformat(bdate[:10]).date()
        except ValueError:
            bdate = None
    if isinstance(bdate, datetime):
        bdate = bdate.date()
    request = {
        "execution_id": execution_id,
        "trigger_type": DRY_RUN_TYPE if dry_run else trigger_type,
        "triggered_by": triggered_by,
        "business_date": bdate.isoformat() if bdate else None,
        "param_values": param_values or None,
        "backend_override": backend_override,
        "dependencies_overridden": dependencies_overridden or None,
        "dry_run": bool(dry_run),
        "version_overrides": version_overrides or None,
    }
    row: Dict[str, Any] = {
        "feed_config_id": int(feed_id),
        "business_date": bdate or today,
        "run_date": today,
        "scheduled_time": _now(),
        "status": "pending",
        "action_decision": "RUN",
        "triggered_by": DRY_RUN_TYPE if dry_run else (trigger_type or MANUAL_RUN_TYPE),
        "triggered_by_user": str(triggered_by)[:100] if triggered_by else None,
        "run_type": DRY_RUN_TYPE if dry_run else MANUAL_RUN_TYPE,
        "build_id": manual_build_id(execution_id),
        "handed_over_at": _now(),
        "run_request": request,
    }
    if dependencies_overridden:
        row["action_reason"] = manual_override_reason(triggered_by, dependencies_overridden)[:2000]
    created = db.create_feed_run(row)
    if dependencies_overridden:
        try:
            from core.feed_executor import _record_dependencies_overridden
            _record_dependencies_overridden(db, feed_id=int(feed_id), run=created,
                                            actor=str(triggered_by or "unknown"),
                                            override=dependencies_overridden)
        except Exception as exc:                          # noqa: BLE001 -- the record, not the run
            logger.warning("[handover] feed %s: dependency override not recorded (%s)", feed_id, exc)
    nudge_local_worker()
    return created


def run_request_kwargs(row: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
    """The ``run_feed`` keyword arguments a handed-over manual row carries,
    or None when the row carries no request (a scheduled row)."""
    req = row.get("run_request")
    if not isinstance(req, dict) or not req.get("execution_id"):
        return None
    return {
        "business_date": req.get("business_date"),
        "trigger_type": req.get("trigger_type") or "manual",
        "param_values": req.get("param_values") or None,
        "execution_id": req.get("execution_id"),
        "triggered_by": req.get("triggered_by"),
        "backend_override": req.get("backend_override"),
        "dependencies_overridden": req.get("dependencies_overridden") or None,
        "dry_run": bool(req.get("dry_run")),
        "version_overrides": req.get("version_overrides") or None,
    }


def nudge_local_worker() -> bool:
    """A process that runs feeds itself (a standalone install) polls its own
    queue at once instead of waiting a tick.  Any other process: nothing to
    nudge, the feed-worker pods poll.  Never raises."""
    try:
        from core import responsibilities as _r
        if not _r.owns(_r.FEED_RUNS):
            return False
        from core.feed.queue_worker import peek_shared_queue_worker
        worker = peek_shared_queue_worker()
        if worker is None:
            return False

        def _poll():
            try:
                worker.poll_once(trigger="handover")
            except Exception as exc:                      # noqa: BLE001
                logger.debug("[handover] local poll failed (%s); the tick picks it up", exc)

        threading.Thread(target=_poll, name="feed-handover-poll", daemon=True).start()
        return True
    except Exception as exc:                              # noqa: BLE001
        logger.debug("[handover] no local worker to nudge (%s)", exc)
        return False


__all__ = ["CRON_HANDOVER_TRIGGER", "HANDED_OVER_WORDS", "is_handed_over", "hand_over_row",
           "requeue_as_new_attempt", "hand_over_cron_fire", "enqueue_manual_run",
           "run_request_kwargs", "nudge_local_worker"]
