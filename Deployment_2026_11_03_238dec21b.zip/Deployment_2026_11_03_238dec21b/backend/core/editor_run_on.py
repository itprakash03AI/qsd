"""The SQL editor's "Run on": ONE query, run on any source (2026-11-01).

The owner: "on query editor need option to use same query across source".
Decided with the owner: *pick the source, same SQL*.  The person writes the
SQL ONCE with table names; "Run on" picks a connection (AWS S3 direct,
Trino, Starburst, on-prem Hive ...) and every table name the SQL reads is
mapped to THAT source's table -- exactly a feed side's table map
(``core/feed/table_map.py``), whose rename this module calls rather than
re-implementing (a decision made twice is a bug).

For each table the SQL reads, the table it reads on the chosen source is
decided here, in this order (``how``):

* ``mapped``     -- the person said so (the saved query's map for this source,
  or the panel's edit).  On an S3 source the target must be a table
  REGISTERED on that connection.
* ``as_written`` -- the chosen source IS the query's own connection (the one
  it was written against): the name as written, as the page always ran it.
* (2026-11-01, rig) NOT a rule any more: an S3 source's registered table
  with the same SHORT name (``iceberg.qs.trades`` -> ``trades``) is only a
  SUGGESTION (``suggested``) the panel offers -- on the rig the MinIO
  connection's ``trades`` was an unrelated parquet table and the "Run on"
  answered from it, 200, wrong rows.  A name match does not prove the same
  data; the person confirms it (the panel's "Use ..." / the saved map).
* ``on_source``  -- a SQL source whose catalog lists the table exactly as
  written (one ``list_tables`` per catalog.schema, asked once).

Anything else is a REFUSAL in a sentence naming the table and the source --
never a run against the name as written on a source it was not written for
(that is how a query "runs" on the cloud catalog while the person chose
on-prem).  A source whose tables cannot be listed is "could not check", not
"has no such table" (unknown is not empty), and it refuses too.

A map entry for a table the SQL no longer reads is REPORTED
(``unused_entries``), not refused: unlike a feed, every table the editor runs
is resolved above, so a left-over entry cannot make a table read unmapped.

The dialect: a SQL source (Trino / Starburst / Hive) receives the text as
written; an S3 source is read by QueryStudio's engine, which translates from
the dialect the S3 CONNECTION declares (``config.sql_dialect``) -- the
translation feeds and datasets use (``sql_dialect_translator.
translate_for_qs_engine``), applied in ``api/sql_query_api.py``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from core.feed.table_map import TableMapRefused, check_name_map, rename_tables

#: what the panel and the disclosure say for each ``how``
HOW_WORDS = {
    "mapped": "you chose it",
    "as_written": "the query's own connection",
    "registered": "registered on this connection",
    "on_source": "found on this source",
}

_S3_TYPES = {"s3"}


class RunOnRefused(ValueError):
    """The query cannot run on the chosen source as it stands.  The text is
    the sentence the person reads."""


@dataclass
class TableOnSource:
    name: str                       # as written in the SQL
    reads: Optional[str] = None     # the table it reads on the chosen source
    how: Optional[str] = None       # HOW_WORDS key; None = unresolved
    problem: Optional[str] = None   # the sentence when unresolved
    suggested: Optional[str] = None # a same-short-name table the person may confirm

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "reads": self.reads, "how": self.how,
                "how_words": HOW_WORDS.get(self.how or ""), "problem": self.problem,
                "suggested": self.suggested}


@dataclass
class RunOnPlan:
    source: Dict[str, Any]
    tables: List[TableOnSource] = field(default_factory=list)
    unused_entries: List[str] = field(default_factory=list)
    dialect: str = "trino"

    @property
    def problems(self) -> List[str]:
        return [t.problem for t in self.tables if t.problem]

    def refusal(self) -> Optional[str]:
        p = self.problems
        if not p:
            return None
        return p[0] if len(p) == 1 else " ".join(p)

    def renames(self) -> Dict[str, str]:
        """``{written (normalised): reads}`` for every table whose name changes."""
        out: Dict[str, str] = {}
        for t in self.tables:
            if t.reads and _norm(t.reads) != _norm(t.name):
                out[_norm(t.name)] = t.reads
        return out

    def to_dict(self) -> Dict[str, Any]:
        return {"source": self.source, "tables": [t.to_dict() for t in self.tables],
                "unused_entries": self.unused_entries, "ok": not self.problems,
                "refusal": self.refusal()}


def _norm(name: str) -> str:
    return ".".join(p.strip().strip('"').strip("`").strip("[]").lower()
                    for p in str(name).split("."))


def parse_dialect(home_conn: Optional[dict], target_conn: dict) -> str:
    """The grammar the names are read in: the S3 connection's declared
    ``sql_dialect`` when either side declares one, else the query's own
    connection's dialect (THE vocabulary, ``dialect_for_connection_type``)."""
    from core.sql_filter_wrapper import dialect_for_connection_type
    for c in (home_conn or {}, target_conn or {}):
        d = str(((c.get("config") or {}).get("sql_dialect")) or "").strip().lower()
        if d and d != "auto":
            return d
    home_type = (home_conn or target_conn or {}).get("connection_type")
    return dialect_for_connection_type(home_type)


def tables_written(sql: str, dialect: str) -> List[str]:
    """Every table the statement reads, spelled as written, in order, once
    each.  A CTE's own name is not a table on any source."""
    import sqlglot
    from sqlglot import exp
    try:
        tree = sqlglot.parse_one(sql, dialect=dialect)
    except Exception as exc:                                # noqa: BLE001
        raise RunOnRefused(
            f"The query could not be read to find its tables ({type(exc).__name__}: "
            f"{str(exc).splitlines()[0] if str(exc) else ''}).  Fix the SQL, then choose "
            f"where to run it.") from exc
    ctes = {c.alias_or_name.lower() for c in tree.find_all(exp.CTE) if c.alias_or_name}
    first: Dict[str, tuple] = {}
    for n, t in enumerate(tree.find_all(exp.Table)):
        parts = [p for p in (t.catalog, t.db, t.name) if p]
        if not parts:
            continue
        written = ".".join(parts)
        key = _norm(written)
        if len(parts) == 1 and key in ctes:
            continue
        starts = [(i.meta or {}).get("start") for i in t.find_all(exp.Identifier)]
        pos = min((s for s in starts if s is not None), default=len(sql) + n)
        if key not in first or pos < first[key][0]:
            first[key] = (pos, written)
    # in the order the text names them -- the order the panel lists them
    return [w for _p, w in sorted(first.values())]


def _source_of(conn: dict) -> Dict[str, Any]:
    from core.engine_attribution import engine_for_connection_type, engine_label
    ctype = str(conn.get("connection_type") or "").lower()
    engine = engine_for_connection_type(ctype)
    return {"id": conn.get("id"), "name": conn.get("name") or f"connection {conn.get('id')}",
            "type": ctype, "engine": engine, "engine_label": engine_label(engine)}


def resolve_run_on(sql: str, *, home_conn: Optional[dict], target_conn: dict,
                   table_map: Any = None,
                   list_tables: Optional[Callable[[str, str], List[Any]]] = None) -> RunOnPlan:
    """Which table each name in ``sql`` reads on ``target_conn`` (module
    docstring).  ``list_tables(catalog, schema)`` lists a SQL source's tables
    (the caller's connector); it is asked once per catalog.schema."""
    mapping = check_name_map(table_map, "the Run on table map")
    dialect = parse_dialect(home_conn, target_conn)
    src = _source_of(target_conn)
    plan = RunOnPlan(source=src, dialect=dialect)
    names = tables_written(sql, dialect)
    if not names:
        raise RunOnRefused("The query reads no table, so there is nothing to map to "
                           f"'{src['name']}'.")
    same = home_conn is not None and home_conn.get("id") == target_conn.get("id")
    is_s3 = src["type"] in _S3_TYPES
    registered = {}
    if is_s3:
        for r in (target_conn.get("config") or {}).get("registered_tables") or []:
            if isinstance(r, dict) and r.get("name"):
                registered[str(r["name"]).lower()] = str(r["name"])
    listed: Dict[tuple, Any] = {}

    def _listing(catalog: str, schema: str):
        key = (catalog.lower(), schema.lower())
        if key not in listed:
            try:
                rows = list_tables(catalog, schema) if list_tables else None
                if rows is None:
                    raise RuntimeError("this source's tables cannot be listed here")
                listed[key] = {str((r.get("name") if isinstance(r, dict) else r) or "").lower()
                               for r in rows}
            except Exception as exc:                        # noqa: BLE001
                listed[key] = exc
        return listed[key]

    for written in names:
        t = TableOnSource(name=written)
        key = _norm(written)
        target = mapping.get(key)
        if target:
            if is_s3 and _norm(target) not in registered:
                t.problem = (f"The table '{written}' is set to read '{target}' on "
                             f"'{src['name']}', but no table of that name is registered on "
                             f"that connection.  Pick one of its registered tables, or "
                             f"register it first.")
            else:
                t.reads, t.how = (registered.get(_norm(target), target) if is_s3 else target), "mapped"
        elif same:
            t.reads, t.how = written, "as_written"
        elif is_s3:
            last = key.split(".")[-1]
            if last in registered:
                t.suggested = registered[last]
                t.problem = (f"The table '{written}' has no confirmed table on '{src['name']}'.  "
                             f"'{registered[last]}' is registered there under the same name, but "
                             f"that does not prove it holds the same data.  If it does, choose it "
                             f"under 'Tables on this source'.")
            else:
                t.problem = (f"The table '{written}' has no table to read on '{src['name']}'.  "
                             f"Choose the table it should read under 'Tables on this source', "
                             f"or register it on that connection.")
        else:
            parts = written.split(".")
            if len(parts) < 3:
                t.problem = (f"The table '{written}' is not named in full "
                             f"(catalog.schema.table), so it cannot be found on "
                             f"'{src['name']}'.  Choose the table it should read under "
                             f"'Tables on this source'.")
            else:
                cat, sch, tab = (p.strip().strip('"') for p in parts[-3:])
                got = _listing(cat, sch)
                if isinstance(got, Exception):
                    t.problem = (f"Could not check whether '{written}' exists on "
                                 f"'{src['name']}' ({str(got).splitlines()[0] if str(got) else type(got).__name__}).  "
                                 f"Choose the table it should read under 'Tables on this "
                                 f"source', or try again.")
                elif tab.lower() in got:
                    t.reads, t.how = written, "on_source"
                else:
                    t.problem = (f"The table '{written}' was not found on '{src['name']}'.  "
                                 f"Choose the table it should read under 'Tables on this "
                                 f"source'.")
        plan.tables.append(t)
    in_sql = {_norm(n) for n in names}
    plan.unused_entries = sorted(k for k in mapping if k not in in_sql)
    return plan


def apply_run_on(sql: str, plan: RunOnPlan) -> str:
    """``sql`` with every table renamed to the one it reads on the chosen
    source -- through THE feed rename (``core/feed/table_map.rename_tables``).
    Refuses an unresolved plan; never runs a partial rename."""
    refusal = plan.refusal()
    if refusal:
        raise RunOnRefused(refusal)
    renames = plan.renames()
    if not renames:
        return sql
    try:
        out, unused = rename_tables(sql, renames, dialect=plan.dialect)
    except TableMapRefused as exc:
        raise RunOnRefused(str(exc)) from exc
    if unused:   # resolved from this very SQL: a name the rename could not place
        raise RunOnRefused(
            f"The table(s) {unused} could not be renamed for '{plan.source['name']}' -- "
            f"refusing rather than run them as written.")
    return out


__all__ = ["HOW_WORDS", "RunOnPlan", "RunOnRefused", "TableOnSource", "apply_run_on",
           "parse_dialect", "resolve_run_on", "tables_written"]
