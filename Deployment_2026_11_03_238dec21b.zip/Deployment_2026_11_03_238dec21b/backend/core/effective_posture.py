"""The EFFECTIVE POSTURE: every default-off gate and daemon, three-valued.

WHY (2026-09-27)
----------------
The product ships with most of its machinery OFF, and each piece answers
"am I on?" on its own screen in its own words: the feed gates in the
scheduler log, the daemon fleet under Background Jobs, the bloom reader in
a config key, RLS on its own page, a Spark lane in an availability probe.
Every one of the 2026-09 incidents that read "the capability exists and ran
nowhere" -- SOD-generated runs nothing consumed, a poller that returned
silently on every tick, a bloom index built for a reader that was off --
was invisible because no single screen put CONFIGURED next to EFFECTIVE
next to WHERE.

One collector, one vocabulary.  For each item:

  * ``configured``  -- the key(s) and the value(s) actually read;
  * ``effective``   -- ``on`` / ``off`` / ``COULD_NOT_DETERMINE``.  The third
                       state is the point: unknown is NOT off.  A daemon
                       jobstore this pod cannot see yields the third state
                       and NAMES the pod that can;
  * ``runs_on``     -- the pod role / scheduler-lock holder / lease that
                       runs it when it runs;
  * ``reason``      -- how the verdict was reached;
  * ``consequence`` -- a cheap fact that says what the posture costs
                       ("pending runs: 3 but no queue consumer").

Conventions reused, not re-invented: the three-valued verdict prefix from
``core/verdict_vocabulary.py`` (the same one ``/api/admin/agents/health``,
``core/feed/health.py::probe_queue_consumer``, DataFlow runnability and
Clockwork use), the daemon inventory from ``core/daemon_registry.py``, and
the per-pod first-hand ``daemon_heartbeat`` rows.

Fail-open per item: one builder that raises costs one row that SAYS it
could not be determined, never the whole card.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

from core.verdict_vocabulary import COULD_NOT_DETERMINE

logger = logging.getLogger(__name__)

ON = "on"
OFF = "off"
UNKNOWN = COULD_NOT_DETERMINE
VERDICTS = (ON, OFF, UNKNOWN)

GROUP_FEEDS = "feeds"
GROUP_BRAIN = "pruning brain"
GROUP_SECURITY = "security"
GROUP_SPARK = "spark lanes"
GROUP_AGENTS = "agents"
GROUP_FLEET = "daemon fleet"

#: the APScheduler job ids of the four feed gates, as ``core/scheduler.py``
#: registers them (all in the in-memory ``daemon`` jobstore).
FEED_JOB_IDS = {
    "sod_generator": "__feed_sod_generator__",
    "queue_worker": "__feed_queue_worker__",
    "sla_tracker": "__feed_sla_tracker__",
    "etl_dependency_poller": "__feed_etl_dep_poller__",
}

#: a heartbeat older than this is stale (three reconciler ticks; the same
#: figure the Background Jobs fleet listing uses).
DAEMON_STALE_AFTER_S = 30

#: a scheduler-lock heartbeat older than this says the holder may be gone -- the
#: SAME age at which another process may take the lock over (one answer, 2026-11-02).
from core.database import SCHEDULER_LOCK_STALE_AFTER_SECONDS as LOCK_STALE_AFTER_S  # noqa: E402

#: how many sidecar rows / policies / mappings we bother counting exactly.
COUNT_CAP = 100_000

Verdict = Tuple[str, str, str, str]   # (effective, runs_on, reason, source)


@dataclass
class PostureItem:
    id: str
    label: str
    group: str
    configured: Dict[str, Any]
    effective: str
    runs_on: str
    reason: str
    consequence: Optional[str] = None
    source: str = ""
    warning: Optional[str] = None
    extras: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.effective not in VERDICTS:
            raise ValueError(f"effective must be one of {VERDICTS}, got {self.effective!r}")
        if self.effective == UNKNOWN and not self.reason.startswith(COULD_NOT_DETERMINE):
            self.reason = f"{COULD_NOT_DETERMINE}: {self.reason}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "label": self.label, "group": self.group,
            "configured": dict(self.configured), "effective": self.effective,
            "runs_on": self.runs_on, "reason": self.reason,
            "consequence": self.consequence, "source": self.source,
            "warning": self.warning, "extras": dict(self.extras),
        }


# ── context: who am I, who holds what ───────────────────────────────────────

def _scheduler_lock_row(db, lock_id: int = 1) -> Optional[Dict[str, Any]]:
    """The Phase 83C ``scheduler_lock`` row (worker_id + heartbeat age), or
    None when no row exists.  Raises on a read failure -- the caller turns
    that into the third state.  ``lock_id`` 2 (2026-11-02) is the job-worker
    tier's election (core.scheduler.JOB_WORKER_LOCK_ID)."""
    from core.db.models import SchedulerLock
    with db.get_session(read_only=True) as s:
        row = s.query(SchedulerLock).filter(SchedulerLock.id == int(lock_id)).first()
        if row is None:
            return None
        hb = row.heartbeat_at
        age = None
        if hb is not None:
            if hb.tzinfo is None:
                hb = hb.replace(tzinfo=timezone.utc)
            age = max(0.0, (datetime.now(timezone.utc) - hb).total_seconds())
        return {"worker_id": row.worker_id,
                "heartbeat_at": hb.isoformat() if hb else None,
                "heartbeat_age_seconds": age}


def _ctx_field(ctx: Dict[str, Any], key: str, read: Callable[[], Any]) -> None:
    try:
        ctx[key] = read()
    except Exception as exc:
        ctx[key] = None
        ctx[f"{key}_error"] = f"{type(exc).__name__}: {exc}"


def _context(db) -> Dict[str, Any]:
    ctx: Dict[str, Any] = {}

    def _role():
        from core.pod_role import current
        return current().role

    def _mode():
        from core.config import scheduler
        return str(scheduler.mode)

    def _pod():
        from core.background_jobs import _this_pod_id
        return _this_pod_id()

    def _runs_aps():
        from core import scheduler
        ctx["apscheduler_worker_id"] = scheduler._scheduler_worker_id
        return bool(scheduler._this_process_runs_apscheduler())

    def _lease():
        from core.scheduler_lease import current_holder, _leader_election_enabled
        ctx["leader_election_enabled"] = bool(_leader_election_enabled())
        return current_holder(db)

    _ctx_field(ctx, "pod_role", _role)
    _ctx_field(ctx, "scheduler_mode", _mode)
    _ctx_field(ctx, "pod_id", _pod)
    _ctx_field(ctx, "this_process_runs_apscheduler", _runs_aps)
    _ctx_field(ctx, "scheduler_lock", lambda: _scheduler_lock_row(db))
    _ctx_field(ctx, "lease_holder", _lease)
    return ctx


def _local_apscheduler_verdict(job_id: str, runs_on: str) -> Verdict:
    try:
        from core.scheduler import get_scheduler
        sch = get_scheduler()
        job = sch.get_job(job_id) if sch is not None else None
    except Exception as exc:
        return UNKNOWN, runs_on, f"APScheduler could not be asked for {job_id}: {exc}", "apscheduler"
    if job is not None:
        return ON, runs_on, f"job {job_id} is registered in this process's APScheduler", "apscheduler"
    return (OFF, runs_on,
            f"job {job_id} is not registered in this process's APScheduler (this process holds the lock)",
            "apscheduler")


def _apscheduler_job_verdict(job_id: str, ctx: Dict[str, Any]) -> Verdict:
    """A job in the in-memory ``daemon`` jobstore is observable only from
    the process that runs APScheduler -- the scheduler lock holder.  From
    any other pod the honest answer is the third state, naming the holder;
    with NO holder at all nothing runs APScheduler anywhere, and that is
    ``off``."""
    lock = ctx.get("scheduler_lock")
    holder = (lock or {}).get("worker_id")
    runs_on = "scheduler lock holder" + (f" {holder}" if holder else " (none recorded)")
    if ctx.get("this_process_runs_apscheduler"):
        return _local_apscheduler_verdict(job_id, runs_on)
    if ctx.get("scheduler_lock_error"):
        return (UNKNOWN, runs_on,
                f"the scheduler lock could not be read ({ctx['scheduler_lock_error']})",
                "scheduler_lock")
    if lock is None:
        return (OFF, runs_on,
                "no scheduler lock holder is recorded, so no process runs APScheduler "
                "and this job cannot be ticking", "scheduler_lock")
    me = ctx.get("pod_id") or "this pod"
    age = lock.get("heartbeat_age_seconds")
    if age is not None and age > LOCK_STALE_AFTER_S:
        return (UNKNOWN, runs_on,
                f"the lock holder {holder} last heartbeat {age:.0f}s ago; its in-memory "
                f"daemon jobstore is not visible from {me}", "scheduler_lock")
    return (UNKNOWN, runs_on,
            f"the daemon jobstore is in-memory on the lock holder {holder}; {me} (role "
            f"{ctx.get('pod_role')}) does not run APScheduler -- ask that pod",
            "scheduler_lock")


def _gated_job_item(item_id: str, label: str, job_key: str, enabled: bool,
                    configured: Dict[str, Any], ctx: Dict[str, Any], off_reason: str,
                    consequence_when_not_on: Optional[str] = None,
                    db: Any = None) -> PostureItem:
    """A feed gate that is an APScheduler job: the config flag decides OFF
    when this pod cannot see the jobstore; presence decides on the holder."""
    eff, runs_on, reason, src = _apscheduler_job_verdict(FEED_JOB_IDS[job_key], ctx)
    if eff == UNKNOWN:
        # 2026-09-27 -- the lock holder reports its feed-gate jobs in its
        # heartbeat (background_jobs.FEED_GATE_JOB_IDS); a live report decides.
        reports, _err = _heartbeat_reports(db) if db is not None else ({}, None)
        decided = _heartbeat_verdict(FEED_JOB_IDS[job_key], runs_on, reports)
        if decided is not None and decided[0][0] != UNKNOWN:
            eff, runs_on, reason, src = decided[0]
    if not enabled and eff == UNKNOWN:
        eff, reason, src = OFF, off_reason, "config"
    consequence = None if eff == ON else consequence_when_not_on
    return PostureItem(item_id, label, GROUP_FEEDS, configured, eff, runs_on, reason,
                       consequence=consequence, source=src)


# ── item builders ───────────────────────────────────────────────────────────

def _cfg(section: str, key: str, fallback: Any = None) -> Any:
    from core.config import get
    return get(section, key, fallback)


def _queue_worker_item(db, fg) -> PostureItem:
    """The probe that already owns this question decides."""
    from core.feed.health import probe_queue_consumer
    presence = probe_queue_consumer(fg, db=db)
    # 2026-11-02: which process runs feeds is its declared responsibility
    # (core/responsibilities.py); the two old flags decide nothing.
    from core import responsibilities as _resp
    configured = {"this_process": _resp.current(),
                  "runs_feeds_here": _resp.owns(_resp.FEED_RUNS)}
    if not presence.determined:
        eff, reason = UNKNOWN, presence.reason
    elif presence.present:
        eff, reason = ON, f"a consumer is present (source: {presence.source})"
    else:
        eff, reason = OFF, presence.reason
    try:
        pending = db.count_pending_feed_runs()
    except Exception as exc:
        logger.debug("[posture] pending feed runs unreadable: %s", exc)
        pending = None
    if pending is None:
        consequence = f"{COULD_NOT_DETERMINE}: pending feed runs could not be counted"
    else:
        n = f"{pending['pending']}{'' if pending.get('exact', True) else '+'}"
        consequence = f"pending runs: {n}" + (" but no queue consumer" if eff == OFF else "")
    runs_on = ("this process (a single-pod install)" if _resp.owns(_resp.FEED_RUNS)
               else "the feed-worker pods")
    return PostureItem("queue_worker", "Feed run queue worker", GROUP_FEEDS, configured, eff,
                       runs_on, reason, consequence=consequence,
                       source=f"probe_queue_consumer:{presence.source}")


def _etl_dependency_item(db, ctx) -> PostureItem:
    """Configured as the poller reads it (App Config setting over config)."""
    from core.feed.etl_dependency import load_config as _dep_cfg
    dep = _dep_cfg()
    configured = {"feed_generation.etl_dep_check_enabled": bool(dep.get("enabled")),
                  "feed_generation.etl_dep_check_interval_seconds": dep.get("interval_seconds"),
                  "feed_generation.etl_dep_check_leader_only": dep.get("leader_only")}
    item = _gated_job_item(
        "etl_dependency_poller", "ETL-dependency poller (WAIT -> RUN)", "etl_dependency_poller",
        bool(dep.get("enabled")), configured, ctx,
        "feed_generation.etl_dep_check_enabled=false (config / App Config setting)",
        db=db)
    try:
        mappings = len(db.list_etl_dependency_mappings_with_sources() or [])
    except Exception as exc:
        logger.debug("[posture] dependency mappings unreadable: %s", exc)
        mappings = None
    if mappings is None:
        item.consequence = f"{COULD_NOT_DETERMINE}: dependency mappings could not be counted"
    elif item.effective == ON:
        item.consequence = f"dependency mappings declared: {mappings}"
    else:
        item.consequence = f"dependency mappings declared: {mappings}, poller off = not enforced"
    return item


def _feed_gates(db, ctx) -> List[PostureItem]:
    from core.config import feed_generation as fg
    return [
        _gated_job_item("sod_generator", "SOD task generator", "sod_generator",
                        bool(fg.sod_enabled),
                        {"feed_generation.sod_enabled": bool(fg.sod_enabled),
                         "feed_generation.sod_cron": getattr(fg, "sod_cron", None)},
                        ctx, "feed_generation.sod_enabled=false on this pod; the scheduler "
                             "bootstrap registers the job only when true",
                        "no feed_runs rows are generated for the business day", db=db),
        _queue_worker_item(db, fg),
        _gated_job_item("sla_tracker", "Feed SLA tracker", "sla_tracker",
                        bool(fg.sla_tracker_enabled),
                        {"feed_generation.sla_tracker_enabled": bool(fg.sla_tracker_enabled)},
                        ctx, "feed_generation.sla_tracker_enabled=false on this pod",
                        "SLA breaches are not swept", db=db),
        _etl_dependency_item(db, ctx),
    ]


def _count_rows(db, model, cap: int = COUNT_CAP) -> Optional[int]:
    try:
        with db.get_session(read_only=True) as s:
            return int(s.query(model.id).limit(cap).count() or 0)
    except Exception as exc:
        logger.debug("[posture] count of %s failed: %s", getattr(model, "__tablename__", model), exc)
        return None


def _bloom(db, ctx) -> List[PostureItem]:
    from core.db.models import IcebergBloomSidecar
    reader_on = bool(_cfg("iceberg", "bloom_sidecar_enabled", True))
    rows = _count_rows(db, IcebergBloomSidecar)
    if rows is None:
        consequence = f"{COULD_NOT_DETERMINE}: sidecar rows could not be counted"
    elif reader_on:
        consequence = f"sidecar rows available to the reader: {rows}"
    else:
        consequence = f"sidecar rows built: {rows}, reader off = never consulted"
    warm = bool(_cfg("iceberg", "warm_on_commit_enabled", True))
    watch = bool(_cfg("iceberg", "watch_registered_tables", True))
    return [
        PostureItem(
            "bloom_reader", "Bloom sidecar reader (Iceberg equality/IN pruning)", GROUP_BRAIN,
            {"iceberg.bloom_sidecar_enabled": reader_on,
             "iceberg.s3_bloom_check_enabled": bool(_cfg("iceberg", "s3_bloom_check_enabled", False))},
            ON if reader_on else OFF,
            "every query-serving pod (api / hybrid), read per query",
            "in-process config on this pod; each query pod reads its own copy",
            consequence=consequence, source="config"),
        PostureItem(
            "bloom_warm_on_commit", "Bloom warm-on-commit (declared bloom_columns)", GROUP_BRAIN,
            {"iceberg.warm_on_commit_enabled": warm, "iceberg.watch_registered_tables": watch,
             "iceberg.auto_bloom_on_query_miss": bool(_cfg("iceberg", "auto_bloom_on_query_miss", False))},
            ON if (warm and watch) else OFF,
            "scheduler pod (snapshot-change listener, register_snapshot_change_reactions)",
            ("both gates on; a registered table's new snapshot builds its declared columns"
             if (warm and watch) else
             "warm needs BOTH watch_registered_tables and warm_on_commit_enabled"),
            source="config"),
    ]


def _rls(db, ctx) -> List[PostureItem]:
    from core.config import row_security as rs
    enabled = bool(rs.enabled)
    mode = rs.default_mode
    try:
        policies = len(db.list_row_policies(enabled_only=True) or [])
    except Exception as exc:
        logger.debug("[posture] RLS policies unreadable: %s", exc)
        policies = None
    if policies is None:
        consequence = f"{COULD_NOT_DETERMINE}: enabled policies could not be counted"
    elif enabled:
        consequence = f"enabled policies: {policies}" + (
            " (0 = every table unrestricted)" if policies == 0 else "")
    else:
        consequence = f"enabled policies: {policies}, RLS off = none applied"
    return [PostureItem(
        "row_security", "Row-level security", GROUP_SECURITY,
        {"row_security.enabled": enabled, "row_security.default_mode": mode,
         "row_security.fail_open": bool(rs.fail_open)},
        ON if enabled else OFF,
        "every query-serving pod, at SQL rewrite",
        f"in-process config; enforcement mode {mode}",
        consequence=consequence, source="config")]


def _fleet_syncer(db, ctx) -> List[PostureItem]:
    configured = {"industrialization.enabled": bool(_cfg("industrialization", "enabled", False)),
                  "industrialization.fleet_syncer_enabled":
                      bool(_cfg("industrialization", "fleet_syncer_enabled", False))}
    try:
        from core.industrialization.fleet_syncer import _syncer_armed
        armed = bool(_syncer_armed())
    except Exception as exc:
        logger.debug("[posture] syncer armed check failed: %s", exc)
        armed = False
    if armed:
        eff, reason = UNKNOWN, ("armed by config; whether the executor pod's loop is ticking "
                                "is not observable from here")
    else:
        eff, reason = OFF, ("not armed: needs industrialization.enabled AND fleet_syncer_enabled "
                            "AND a PostgreSQL metadata database; the query path completes the "
                            "per-file store itself on the first walk of a snapshot")
    return [PostureItem("fleet_syncer", "Iceberg fleet syncer", GROUP_BRAIN, configured,
                        eff, "executor-role pod", reason, source="industrialization.is_enabled")]


def _spark_lanes(db, ctx) -> List[PostureItem]:
    from core.config import spark_k8s as sk, spark_connect as sc
    try:
        # THE lane decision the router uses (2026-10-07), not a second probe.
        from core.feed.backend_router import lane_availability
        av = lane_availability("spark_k8s")
        k8s: Verdict = (ON if av.available else OFF, "", av.describe(),
                        "backend_router.lane_availability (cached probe)")
    except Exception as exc:
        k8s = (UNKNOWN, "", f"availability probe raised {type(exc).__name__}: {exc}",
               "backend_router.lane_availability")
    connect_on = bool(sc.enabled)
    return [
        PostureItem("spark_k8s", "Spark-on-K8s lane", GROUP_SPARK,
                    {"spark_k8s.enabled": bool(sk.enabled),
                     "spark_k8s.submit_mode": sk.submit_mode,
                     "spark_k8s.namespace": sk.namespace},
                    k8s[0], "a SparkApplication / driver pod the reconciler supervises",
                    k8s[2], source=k8s[3]),
        PostureItem("spark_connect", "Spark Connect lane", GROUP_SPARK,
                    {"spark_connect.enabled": connect_on,
                     "spark_connect.server_url": sc.server_url},
                    UNKNOWN if connect_on else OFF,
                    "one long-lived Spark Connect session pod",
                    ("enabled by config; session reachability is not probed here "
                     "(a probe opens a Spark session)") if connect_on
                    else "spark_connect.enabled=false",
                    source="config"),
    ]


def _agents(db, ctx) -> List[PostureItem]:
    from core.agents import get_orchestrator
    orch = get_orchestrator()
    configured = {"agents.enabled": bool(_cfg("agents", "enabled", True)),
                  "agents.decision_engine": _cfg("agents", "decision_engine", "rules")}
    status: Dict[str, Any] = {}
    if orch is not None:
        try:
            status = orch.decision_engine_status() or {}
        except Exception as exc:
            status = {"error": str(exc)}
    if orch is not None and bool(orch.enabled):
        eff, reason = ON, (f"orchestrator enabled; decision engine "
                           f"{status.get('effective') or status.get('configured')}")
    elif configured["agents.enabled"] and orch is None:
        eff, reason = UNKNOWN, "agents.enabled=true but no orchestrator is wired in this process"
    else:
        eff, reason = OFF, (status.get("reason") or "agents.enabled=false")
    return [PostureItem("agents", "Self-healing agents", GROUP_AGENTS, configured, eff,
                        "the pod that wires the orchestrator (api)", reason,
                        source="orchestrator.decision_engine_status",
                        extras={"decision_engine_status": status})]


# ── the daemon fleet ────────────────────────────────────────────────────────

def _heartbeat_reports(db) -> Tuple[Dict[str, list], Optional[str]]:
    reports: Dict[str, list] = {}
    try:
        for hb in (db.list_daemon_heartbeats(max_age_seconds=DAEMON_STALE_AFTER_S) or []):
            reports.setdefault(hb.get("name"), []).append(hb)
    except Exception as exc:
        return reports, f"{type(exc).__name__}: {exc}"
    return reports, None


def _runs_per_pod(name: str) -> bool:
    """True for a daemon DECLARED to run on every pod
    (``daemon_registry.PER_POD_DAEMONS``).  Anything else on two pods is a
    double run and warns.  Unreadable registry = False (warn)."""
    try:
        from core.daemon_registry import PER_POD_DAEMONS
        return name in PER_POD_DAEMONS
    except Exception:
        return False


def _heartbeat_verdict(name: str, owner: str, reports: Dict[str, list]
                       ) -> Optional[Tuple[Verdict, Optional[str]]]:
    """A first-hand report decides: live+running -> on (naming the pods,
    warning on a duplicated singleton), live+not running -> off, stale ->
    the third state.  None when nobody has reported it at all."""
    mine = reports.get(name) or []
    live = [h for h in mine if not h.get("stale")]
    running_on = sorted({h["pod_id"] for h in live if h.get("running")})
    if running_on:
        # 2026-09-28 -- "more than one pod" is NOT a fault for a daemon
        # declared per-pod (portal_cred_prewarmer warms each API
        # pod's own cache) runs on every pod by design and was a permanent
        # false alarm on any deployment with more than one API pod.
        warning = ("running on more than one pod: " + ", ".join(running_on)
                   if len(running_on) > 1 and not _runs_per_pod(name) else None)
        return ((ON, ", ".join(running_on),
                 f"reported running by {len(running_on)} pod(s) within {DAEMON_STALE_AFTER_S}s",
                 "daemon_heartbeat"), warning)
    if live:
        best = max(live, key=lambda h: h.get("updated_at") or "")
        return ((OFF, str(best.get("pod_id")),
                 f"reported by {best.get('pod_id')} as {best.get('status') or 'not running'}",
                 "daemon_heartbeat"), None)
    if mine:
        stale = max(mine, key=lambda h: h.get("updated_at") or "")
        return ((UNKNOWN, owner,
                 f"last reported by {stale.get('pod_id')} at {stale.get('updated_at')} "
                 f"(> {DAEMON_STALE_AFTER_S}s ago) -- the owning pod may be down",
                 "daemon_heartbeat(stale)"), None)
    return None


def _local_registry_verdict(name: str, me: str) -> Optional[Verdict]:
    """This process's own ``background_jobs`` entry, if it is not a placeholder."""
    try:
        from core import background_jobs as _bj
        local = _bj.get_job(name)
    except Exception:
        return None
    if local is None or getattr(local, "remote", False):
        return None
    d = local.to_dict()
    return (ON if d.get("running") else OFF, me,
            f"registered in this process: {d.get('status')}", "background_jobs(local)")


def _silent_verdict(name: str, owner: str, configured: Dict[str, Any],
                    hb_error: Optional[str], me: str, orphans: Dict[str, str]) -> Verdict:
    """Nobody reported it and it is not here: an orphan, an admin stop, an
    unreadable heartbeat table, or genuine silence -- four facts, four words."""
    if name in orphans:
        return OFF, owner, f"declared orphan: {orphans[name]}", "daemon_registry"
    if configured.get("admin_toggle") is False:
        return OFF, owner, "switched off by an admin (job_control toggle)", "job_control"
    if hb_error:
        return UNKNOWN, owner, f"heartbeats unreadable ({hb_error})", "daemon_heartbeat"
    return (UNKNOWN, owner,
            f"no pod has reported this daemon within {DAEMON_STALE_AFTER_S}s and it does "
            f"not run in this process ({me})", "daemon_heartbeat")


def _daemon_fleet(db, ctx) -> List[PostureItem]:
    """One row per DECLARED daemon (the registry is the inventory)."""
    from core.daemon_registry import (SCHEDULER_OWNED, API_OWNED, KNOWN_ORPHANS,
                                      ADMIN_TOGGLES, admin_disabled)
    reports, hb_error = _heartbeat_reports(db)
    me = ctx.get("pod_id") or "this pod"
    declared: List[Tuple[str, str]] = (
        [(n, "scheduler/worker pod") for n in SCHEDULER_OWNED]
        + [(n, "api pod") for n in API_OWNED]
        + [(n, "NO POD -- declared orphan") for n in KNOWN_ORPHANS])
    items: List[PostureItem] = []
    for name, owner in declared:
        configured: Dict[str, Any] = {}
        if name in ADMIN_TOGGLES:
            configured["admin_toggle"] = not admin_disabled(name)
        warning = None
        decided = _heartbeat_verdict(name, owner, reports)
        if decided is not None:
            verdict, warning = decided
        else:
            verdict = (_local_registry_verdict(name, me)
                       or _silent_verdict(name, owner, configured, hb_error, me, KNOWN_ORPHANS))
        eff, runs_on, reason, src = verdict
        items.append(PostureItem(name, name.replace("_", " "), GROUP_FLEET, configured,
                                 eff, runs_on, reason, source=src, warning=warning))
    return items


BUILDERS: List[Callable[[Any, Dict[str, Any]], List[PostureItem]]] = [
    _feed_gates, _bloom, _rls, _fleet_syncer, _spark_lanes, _agents, _daemon_fleet,
]


def collect_posture(db_manager: Any) -> Dict[str, Any]:
    """The whole card.  Each builder is guarded on its own: a failing one
    contributes a single row that names itself and the third state."""
    ctx = _context(db_manager)
    items: List[PostureItem] = []
    for builder in BUILDERS:
        try:
            items.extend(builder(db_manager, ctx))
        except Exception as exc:
            logger.warning("[posture] %s failed: %s", builder.__name__, exc)
            name = builder.__name__.strip("_")
            items.append(PostureItem(name, name.replace("_", " "), "collector", {}, UNKNOWN,
                                     "?", f"collector raised {type(exc).__name__}: {exc}",
                                     source="collector"))
    return {
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "context": ctx,
        "summary": {v: sum(1 for i in items if i.effective == v) for v in VERDICTS},
        "items": [i.to_dict() for i in items],
    }


__all__ = ["ON", "OFF", "UNKNOWN", "VERDICTS", "FEED_JOB_IDS", "PostureItem",
           "collect_posture"]
