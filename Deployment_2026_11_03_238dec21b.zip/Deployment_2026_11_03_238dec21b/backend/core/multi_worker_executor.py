"""BF-383 — Multi-worker query executor (Option F).

Dispatches a ``SplitPlan`` across N parallel workers, collects per-chunk
partial results, and hands them to ``result_merger``.

Two execution modes:
  * **thread** (default):  N threads, each with its own DuckDB connection.
                           Lightweight, lowest overhead.  Best when DuckDB
                           is stable on the platform.
  * **subprocess**:        N child processes via the existing
                           ``duckdb_subprocess`` framework.  Heavier but
                           crash-isolated — a DuckDB segfault in one
                           worker doesn't take the whole backend down.

The choice is config-driven (``multi_worker.executor_mode``).  Falls back
to single-worker (caller-driven) when:
  * ``multi_worker.enabled = false``
  * ``decide_split()`` returns ``splittable=False``
  * Any worker raises and ``fallback_on_error = true``

Public API:
  ``execute_multi_worker(split_plan, sql, setup_sql_for_chunk, ...) -> pa.Table``

The caller supplies ``setup_sql_for_chunk(chunk)`` — a callable that
builds the per-worker registered-table DDL given that chunk's file list.
This keeps the dispatcher decoupled from the connection-type details
(parquet view setup differs per engine / connection).
"""
from __future__ import annotations

import logging
import os
import re
import sys
import tempfile
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
# BF-586: TimeoutError for outer-timeout fallback in as_completed.
from concurrent.futures import TimeoutError as FuturesTimeoutError
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import pyarrow as pa
import pyarrow.parquet as pq

from core.query_splitter import FileChunk, SplitPlan
from core.result_merger import merge_partial_results

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Per-process dispatch counters (best-effort, lock-protected)
# ─────────────────────────────────────────────────────────────────────────────

_STATS_LOCK = threading.Lock()
_STATS: Dict[str, Any] = {
    "submitted":         0,   # number of times execute_multi_worker() was called
    "succeeded":         0,   # all workers ok + merge ok
    "failed":            0,   # raised
    "fell_back":         0,   # any worker failure → caller falls back
    "total_worker_runs": 0,
    "total_worker_ok":   0,
    "total_worker_fail": 0,
    "last_invocation_at": 0.0,
}

# Bounded history of recent dispatches — ring buffer, newest first.
# Caps at 100 entries to keep memory bounded under burst workloads.
_HISTORY_MAX = 100
from collections import deque as _deque  # noqa: E402
_HISTORY: _deque = _deque(maxlen=_HISTORY_MAX)


def get_dispatch_stats() -> Dict[str, Any]:
    """Return a snapshot of the per-process dispatch counters."""
    with _STATS_LOCK:
        return dict(_STATS)


def get_dispatch_history(limit: int = 50) -> List[Dict[str, Any]]:
    """Return the most-recent dispatch records (newest first)."""
    with _STATS_LOCK:
        items = list(_HISTORY)
    items.reverse()  # newest first
    return items[: max(0, int(limit))]


# BF-405: live worker progress — what every in-flight chunk is doing RIGHT NOW.
# Keyed by (correlation_id, chunk_index) → dict with state + timings.
# Admin UI polls this to show "worker 0: running 1.2s, worker 1: completed 240 rows"
_ACTIVE_WORKERS: Dict[str, Dict[str, Any]] = {}
# ── QS_DUCKDB_CONCURRENT_CHILDREN, shared by concurrent dispatches ─────────
#
# 2026-09-25.  Each dispatch used to save the variable, set its own N and
# put the SAVED value back when done.  Two dispatches overlapping in one API
# process restored each other: A saves "unset" and sets 4, B saves A's "4",
# A finishes and unsets, B finishes and puts "4" BACK -- the process stays at
# 4 for good, and every later query in that pod gets a quarter of its memory
# and threads until restart.  Found in the CI image: a concurrency test left
# the variable at '4' and a later test's DuckDB limit fell to 267 MB.
#
# Now one registry, under one lock: while any dispatch is active the variable
# holds the LARGEST active N; when the last one leaves it returns to what it
# was before the first arrived.
_KIDS_LOCK = threading.Lock()
_KIDS_ACTIVE: Dict[int, int] = {}          # token -> n_workers
_KIDS_BASELINE: List[Optional[str]] = []   # [value before the first dispatch]
_KIDS_NEXT = [0]
_KIDS_VAR = "QS_DUCKDB_CONCURRENT_CHILDREN"


def _kids_apply_locked() -> None:
    if _KIDS_ACTIVE:
        os.environ[_KIDS_VAR] = str(max(_KIDS_ACTIVE.values()))
        return
    base = _KIDS_BASELINE.pop() if _KIDS_BASELINE else None
    if base is None:
        os.environ.pop(_KIDS_VAR, None)
    else:
        os.environ[_KIDS_VAR] = base


def _kids_stamp_enter(n_workers: int) -> int:
    with _KIDS_LOCK:
        if not _KIDS_ACTIVE:
            _KIDS_BASELINE[:] = [os.environ.get(_KIDS_VAR)]
        _KIDS_NEXT[0] += 1
        token = _KIDS_NEXT[0]
        _KIDS_ACTIVE[token] = max(1, int(n_workers))
        _kids_apply_locked()
        return token


def _kids_stamp_exit(token: int) -> None:
    with _KIDS_LOCK:
        if _KIDS_ACTIVE.pop(token, None) is None:
            return                          # already released: idempotent
        _kids_apply_locked()


_ACTIVE_LOCK = threading.Lock()


def _set_worker_state(correlation_id: str, chunk_index: int,
                       state: Optional[str], **fields):
    """Update live worker state.  ``state`` ∈ {starting, setup, running, completed, failed, cancelled}

    BF-599 (2026-05-30): also invokes the optional broadcast callback so
    the UI gets live per-worker progress without polling — eliminates
    the "0/3032 files for 900s" mystery the user hit when admin-endpoint
    polling required auth.

    BF-599d (2026-05-30): ``state=None`` is treated as a side-channel
    fields-only update — used by the heartbeat sampler to push
    ``running_detail`` / ``stuck_s`` without clobbering the canonical
    state set by the main worker loop.  Without this, a heartbeat
    racing with a setup→running transition could overwrite the new
    state back to the old one.
    """
    key = f"{correlation_id or 'unknown'}:{chunk_index}"
    # BF-599e (2026-05-30): coalesce — when state=None (heartbeat) AND
    # the running_detail field is unchanged AND no other field is new,
    # skip the broadcast.  Local _ACTIVE_WORKERS is still updated so
    # admin polling sees the latest updated_at, but the WS push (which
    # routes to N concurrent users' broadcast queues) is suppressed —
    # cuts heartbeat noise from 0.2/s per worker to ~0 when a worker
    # is genuinely stuck on the same frame.
    _suppress_broadcast = False
    with _ACTIVE_LOCK:
        entry = _ACTIVE_WORKERS.get(key, {
            "correlation_id": correlation_id or "",
            "chunk_index":    chunk_index,
            "started_at":     time.time(),
        })
        if state is None and fields:
            # Coalesce: only the elapsed_s + stuck_s tick.  Suppress if
            # running_detail is set and unchanged from the prior entry.
            _new_detail = fields.get("running_detail")
            if _new_detail is not None and _new_detail == entry.get("running_detail"):
                _suppress_broadcast = True
        if state is not None:
            entry["state"] = state
        entry["updated_at"] = time.time()
        for k, v in fields.items():
            entry[k] = v
        _ACTIVE_WORKERS[key] = entry
        _snapshot = dict(entry)
    # BF-599: push to broadcast callback OUTSIDE the lock.  Callback is
    # registered by execute_api at startup; it routes to
    # ws_manager.broadcast_to_user_sync so the user owning this execution
    # sees live progress in the BQB / CQB chip.  Errors are swallowed —
    # broadcast is best-effort observability, never blocks the worker.
    if _suppress_broadcast:
        return
    _cb = _STATE_CHANGE_CALLBACK
    if _cb is not None:
        try:
            _cb(_snapshot)
        except Exception as _cb_exc:
            logger.debug("[multi-worker] state-change callback raised: %s", _cb_exc)


# BF-599: optional broadcast callback.  Signature: fn(state_snapshot_dict).
# Registered by execute_api.set_execute_dependencies() at startup so the
# multi-worker subsystem stays decoupled from the WS manager.
_STATE_CHANGE_CALLBACK: Optional[Callable[[Dict[str, Any]], None]] = None


def set_state_change_callback(
    fn: Optional[Callable[[Dict[str, Any]], None]],
) -> None:
    """BF-599: register a callback invoked whenever a worker's live state
    changes.  Called from worker threads — implementation MUST be thread-
    safe.  Use ``ws_manager.broadcast_to_user_sync`` (BF-589 capped) for
    the wire push so events from N workers don't flood the loop."""
    global _STATE_CHANGE_CALLBACK
    _STATE_CHANGE_CALLBACK = fn


def _operator_pod_cap_mb(pod_cap_mb: Optional[int]) -> int:
    """The operator's pod memory cap in MB (0 = none).  ``pod_cap_mb=None``
    reads ``query_admission.pod_memory_cap_mb``; an explicit value (tests pass
    0 to isolate themselves from ambient config) is used as given."""
    if pod_cap_mb is None:
        from core.config import get_section as _sect
        pod_cap_mb = (_sect("query_admission") or {}).get("pod_memory_cap_mb")
    return int(pod_cap_mb or 0)


def _compute_per_worker_memory_mb(n_workers: int,
                                    reserve_pct: float = 0.30,
                                    pod_cap_mb: Optional[int] = None,
                                    ) -> Optional[int]:
    """BF-599d (2026-05-30) — return per-worker DuckDB memory budget in MB.

    The classic multi-worker OOM trap: each of N DuckDB connections
    auto-detects host RAM and sets ``memory_limit`` to ~75% of TOTAL —
    so 4 workers × 75% pod = 300% pod budget, OOM-killed with no log.

    This helper computes a safe per-worker share:

      pod_mem * (1 - reserve_pct) / n_workers

    reserve_pct (default 30%) leaves room for:
      * the Python coordinator process
      * pyarrow merge buffers (each partial Arrow table is held in RAM
        until merge completes)
      * S3 client buffers (boto3 / httpfs sockets)
      * the FastAPI / uvicorn worker pool

    Returns None when:
      * the resolver cannot infer a pod-bound budget (e.g. Windows dev
        machine with no cgroup) — caller leaves memory_limit unset and
        DuckDB falls back to its own auto-detect.  On a single-user
        local dev box the auto-detect (75% of host) is usually fine.
      * n_workers <= 0 (caller bug — returning None is safer than div0).
      * n_workers == 1 — a single-chunk multi-worker dispatch should
        get the same memory budget as native single-worker execution
        (DuckDB auto-detect, ~75% pod).  Without this carve-out we'd
        return 70% which is asymmetric vs single-worker mode and could
        confuse operators tuning memory_limit globally.
    """
    if n_workers <= 0:
        return None
    if n_workers == 1:
        # BF-599g: single-chunk multi-worker dispatch matches native
        # single-worker memory budget.  On Linux cgroup-bounded pods
        # we can safely leave memory_limit unset and let DuckDB pick
        # 75% of pod RAM.  On Windows there is no cgroup; DuckDB's
        # 75%-of-host + mmap page-cache (Standby) regularly pushes
        # past total RAM under multi-file Iceberg scans → BSOD.  So
        # on Windows we always compute an explicit cap.
        #
        # 2026-09-25: "leave it unset" is right ONLY when the operator set
        # no pod cap.  This early return ran BEFORE the cap below was read,
        # so on Linux -- every deployed pod -- a single worker ignored
        # query_admission.pod_memory_cap_mb and DuckDB took 75% of the
        # cgroup.  Invisible on the Windows dev box, which skips this branch;
        # found by running the suite in the CI image (python:3.11-slim).
        try:
            import sys
            if sys.platform != "win32" and _operator_pod_cap_mb(pod_cap_mb) <= 0:
                return None
        except Exception:
            return None
    try:
        from core.duckdb_resource_limits import (
            _read_cgroup_memory_limit_bytes,
            _read_proc_meminfo_total_bytes,
        )
        budget_b = _read_cgroup_memory_limit_bytes()
        _from_cgroup = budget_b is not None and budget_b > 0
        if not _from_cgroup:
            budget_b = _read_proc_meminfo_total_bytes()
        # 2026-06-10 Windows-BSOD fix: cgroup + /proc/meminfo are both
        # absent on Windows.  Without a budget we used to return None,
        # letting each of N workers self-detect 75% of host RAM via
        # DuckDB's auto-detect → N × 75% = up to 300% committed → BSOD.
        # Fall back to psutil.virtual_memory().total which works on
        # every OS — that gives a real ceiling we can divide by N.
        if budget_b is None or budget_b <= 0:
            try:
                import psutil
                budget_b = int(psutil.virtual_memory().total)
            except Exception:
                budget_b = None
        if budget_b is None or budget_b <= 0:
            return None
        # ── 2026-08-21 — HONOUR THE OPERATOR'S POD CAP ────────────────────
        # This budget was resolved from cgroup -> /proc/meminfo -> psutil host
        # total, and NEVER consulted query_admission.pod_memory_cap_mb.  So an
        # operator who caps the pod at 28,000 MB had that cap honoured by the
        # ADMISSION controller and ignored by the EXECUTOR that actually sets
        # the DuckDB limit: admission decided n_workers=2 @ 512 MB, and the
        # executor computed 4 x 11,394 MB from a 64 GB host total.  Two
        # components disagreeing about "how much memory may this pod use".
        #
        # An explicitly configured cap is a statement of operator intent and
        # must never be exceeded, so take the MIN.  Default is 0 (= unset), so
        # this is a NO-OP for any deployment that has not set it — the clamp
        # can only ever LOWER a ceiling, which makes DuckDB spill rather than
        # letting the kernel OOM-kill the pod.
        # ``pod_cap_mb`` defaults to None = read the operator's setting, so no
        # caller can forget it.  Tests of the HOST/cgroup budget resolution
        # pass 0 to isolate themselves from ambient config — without that the
        # assertion depends on whatever config.json the developer happens to
        # have, which is testing the machine, not the code.
        _cap_applied = False
        _pod_cap_mb = 0
        try:
            _pod_cap_mb = _operator_pod_cap_mb(pod_cap_mb)
            if _pod_cap_mb > 0:
                _cap_b = _pod_cap_mb * 1024 * 1024
                if _cap_b < budget_b:
                    logger.info(
                        "[multi-worker] pod_memory_cap_mb=%d is below the "
                        "detected budget (%d MB) - using the operator's cap.",
                        _pod_cap_mb, budget_b // (1024 * 1024))
                    budget_b = _cap_b
                    _cap_applied = True
        except Exception as _cap_exc:
            logger.debug(
                "[multi-worker] pod cap lookup skipped (fail-open): %s",
                _cap_exc)
        # 2026-08-02 role-aware reserve (see duckdb_resource_limits):
        # on a HYBRID/worker pod the daemon fleet is co-resident, so the
        # 30% reserve sized for "coordinator + merge buffers" is not
        # enough — the pod-level invariant (sum of worker ceilings +
        # co-residents < cgroup limit) must hold at every worker count.
        # Only applies when the budget came from a CGROUP: the psutil /
        # host-total paths (Windows dev, BSOD gates) keep the historical
        # 30%.  Fail-open to the caller's reserve.
        try:
            from core.duckdb_resource_limits import (
                effective_reserve_pct as _eff_reserve,
            )
            reserve_pct = _eff_reserve(
                reserve_pct, budget_from_cgroup=_from_cgroup)
        except Exception as _rr_exc:
            logger.debug(
                "[multi-worker] role-aware reserve skipped (fail-open): %s",
                _rr_exc)
        per_worker_b = int(budget_b * (1.0 - reserve_pct)) // n_workers
        per_worker_mb = per_worker_b // (1024 * 1024)
        # Floor at 256 MB — below this DuckDB struggles to plan any query.
        #
        # BF-558b (2026-08-01): CLAMP, do not return None.  Returning None
        # leaves the PRAGMA unset, which makes DuckDB auto-detect 75% of
        # the HOST — the single worst outcome under high concurrency, and
        # precisely the case that now reaches this branch: once the divisor
        # composes across queries (concurrent_queries x workers) it can hit
        # 200, so a 30 GB pod computes ~105 MB and would previously have
        # unset the limit for all 200 children.  A small explicit ceiling
        # makes them spill; an unset one makes the kernel kill the pod.
        if per_worker_mb < 256:
            # Discriminate the two ways this branch is reached:
            #   * GENUINELY TINY BOX (usable < 1 GB) — there is no budget to
            #     hand out.  Keep the original contract and return None so
            #     DuckDB errors with a clear message (BF-599d / the Windows
            #     BSOD gates pin this: 1 GB box / 8 workers -> None).
            #   * ADEQUATE POD, LARGE DIVISOR — new with the cross-query
            #     divisor.  Here None would be actively harmful, so clamp.
            # 2026-08-22 — AND the cap must not INVERT here.  The clamp
            # above was added yesterday; below it, an operator cap small
            # enough to push `usable` under 1 GB fell into the "genuinely
            # tiny box" arm and returned None — which unsets the PRAGMA and
            # lets DuckDB auto-detect 75% of the HOST.  Measured: cap=1000 MB
            # on a 64 GB host went from a bounded 11,468 MB per worker to
            # NO CEILING AT ALL.  Setting a cap made the pod less bounded
            # than not setting one, the exact opposite of the invariant three
            # lines up ("the clamp can only ever LOWER a ceiling").
            #
            # The two arms are told apart by CAUSE, not by size: a small
            # budget because the BOX is small is a real "no budget to hand
            # out" (keep returning None so DuckDB errors clearly — BF-599d
            # and the Windows BSOD gates pin this).  A small budget because
            # the OPERATOR ASKED FOR LESS is an instruction to use less
            # memory, and can only ever mean a lower explicit ceiling.
            #
            # 2026-09-26 -- and the cap is in play even when it was NOT the
            # smaller number.  On a 6 GB pod under an 8,000 MB cap the cap
            # is "not applied" (the cgroup is the smaller budget), so this
            # arm handed 32 workers the 256 MB floor each: 8,192 MB of
            # ceilings, over the operator's 8,000 MB cap by the floor
            # alone.  Measured in the CI replica (6 GB cgroup); invisible
            # on a 64 GB dev box, where every cap is the smaller number.
            # The floor may stand in for a small CGROUP share (BF-558b,
            # above: a small explicit ceiling beats an unset one), but never
            # over an operator's stated ceiling -- a cap throttles, it is
            # not exceeded.  Admission bounds n_workers against the cap
            # before dispatch (resource_admission: n <= remaining // 768);
            # this is the executor's own half of the invariant, and it must
            # hold on the paths admission does not see (the cross-query
            # divisor, a disabled admission, a dispatcher that bypasses it).
            _floor_breaks_cap = (_pod_cap_mb > 0
                                 and 256 * n_workers > _pod_cap_mb)
            if _cap_applied or _floor_breaks_cap:
                _usable_mb = max(
                    1, int(budget_b * (1.0 - reserve_pct)) // (1024 * 1024))
                # No floor above the operator's own share: flooring at 64 MB
                # made 8 workers under a 500 MB cap total 512 MB, i.e. the
                # clamp would exceed the very cap it enforces.  The cap wins;
                # if the resulting share is too small for DuckDB to plan, say
                # so rather than quietly spending memory the operator forbade.
                _clamped = max(1, min(256, _usable_mb // max(1, n_workers)))
                logger.warning(
                    "[multi-worker] pod_memory_cap_mb=%d: %s leaves only %d "
                    "MB usable across %d workers; setting an explicit %d MB "
                    "ceiling each%s. The 256 MB floor would total %d MB, "
                    "over the cap; unsetting the limit would let DuckDB "
                    "auto-detect 75%% of the HOST, i.e. a cap would REMOVE "
                    "the ceiling it was set to impose.",
                    _pod_cap_mb,
                    "the cap" if _cap_applied else "the pod's own budget",
                    _usable_mb, n_workers, _clamped,
                    " (below the ~64 MB DuckDB needs to plan comfortably — "
                    "raise the cap or lower the worker count)"
                    if _clamped < 64 else "",
                    256 * n_workers)
                return _clamped
            if int(budget_b * (1.0 - reserve_pct)) < (1024 * 1024 * 1024):
                return None
            return 256
        return int(per_worker_mb)
    except Exception as exc:
        logger.debug("[multi-worker] per-worker memory resolver failed: %s", exc)
        return None


def _resolve_temp_dir_for_spill() -> Optional[str]:
    """BF-599d — return a writable temp directory for DuckDB spill-to-disk.

    DuckDB's ``temp_directory`` defaults to an in-process buffer that grows
    until OOM under memory pressure.  Pointing it at a real disk path
    means heavy aggregations spill instead of crashing.

    Resolution order (no hardcoded filesystem paths — BF-600-cfg
    2026-05-31):
      1. ``DUCKDB_TEMP_DIR`` env var (operator override, highest priority)
      2. config.json ``paths.duckdb_spill_dir`` (explicit spill dir)
      3. config.json ``paths.duckdb_temp_dir`` (existing DuckDB temp dir) +
         ``/spill`` subdir
      4. ``tempfile.gettempdir()`` (OS-standard temp dir; resolves via the
         Python stdlib's well-defined search order — NOT a hardcoded
         literal: honours $TMPDIR/$TMP/$TEMP on POSIX, %TMP%/%TEMP%/
         %USERPROFILE% on Windows)

    Returns None on failure — caller leaves the PRAGMA unset.
    """
    try:
        env_dir = (os.environ.get("DUCKDB_TEMP_DIR") or "").strip()
        if env_dir:
            os.makedirs(env_dir, exist_ok=True)
            return env_dir
        # config.json — explicit spill_dir first, then derive from temp_dir.
        try:
            from core.config import get as _cfg_get
            cfg_spill = (_cfg_get("paths", "duckdb_spill_dir", "") or "").strip()
            if cfg_spill:
                os.makedirs(cfg_spill, exist_ok=True)
                return cfg_spill
            cfg_temp = (_cfg_get("paths", "duckdb_temp_dir", "") or "").strip()
            if cfg_temp:
                spill_dir = os.path.join(cfg_temp, "spill")
                os.makedirs(spill_dir, exist_ok=True)
                return spill_dir
        except Exception as _cfg_exc:
            logger.debug(
                "[multi-worker] config.json paths read failed (falling "
                "back to tempfile.gettempdir): %s", _cfg_exc,
            )
        # Last resort: stdlib's OS-standard temp dir.  tempfile.gettempdir()
        # is the canonical "where does this OS keep temp files" resolver —
        # NOT a hardcoded literal.  See Python docs for the search order.
        spill_dir = os.path.join(tempfile.gettempdir(), "duckdb_spill")
        os.makedirs(spill_dir, exist_ok=True)
        return spill_dir
    except Exception as exc:
        logger.debug("[multi-worker] temp-dir resolver failed: %s", exc)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Streaming UNION merge plumbing (2026-07-31)
# ─────────────────────────────────────────────────────────────────────────────
#
# Defect: the union merge held the ENTIRE result in coordinator RAM —
# each subprocess worker did ``pq.read_table(partial.parquet)`` (full
# partial in memory), the dispatcher held ALL partials at once, and
# ``pa.concat_tables`` pinned them until the caller was done.  For a plain
# SELECT split across workers that is the full result (10-20M rows × ~900
# cols = 72-290 GB uncompressed) — OOM regardless of row-group tuning.
#
# Fix: for merge_strategy == "union", workers keep their partial ON DISK
# (WorkerResult.table_path); the coordinator streams the partials
# batch-by-batch into ONE uncompressed Arrow IPC spool file and returns
# it as a zero-copy memory-mapped table.  Peak coordinator pool memory =
# O(one width-aware batch), and the mapped pages are OS-evictable.
#
#   * subprocess workers (original 2026-07-31 fix): the COPY-to-parquet
#     output stays on disk; row_count comes from the parquet footer.
#   * thread workers (risk-1 close, same day): the DuckDB cursor is
#     STREAMED via its Arrow record-batch reader into an Arrow IPC spool
#     (``_spool_thread_partial_ipc``).  Arrow IPC — NOT COPY-to-parquet —
#     because IPC round-trips the in-process Arrow types EXACTLY
#     (HUGEINT→decimal128(38,0), decimal128, timestamp-tz, enum
#     dictionaries, nested list/struct/map), whereas DuckDB's parquet
#     writer is lossy (HUGEINT → DOUBLE — see query_splitter's
#     hugeint_restore machinery).  Type parity with the legacy
#     ``.to_arrow_table()`` path is proven exhaustively in
#     tests/test_merge_streaming_2026_07_31.py.  Thread mode matters:
#     it is the DEFAULT executor_mode, so pre-fix the O(result)
#     coordinator memory defect was still LIVE in default deployments.
#
# Aggregate strategies are untouched everywhere — their partials are small
# by construction.  The multi_worker.streaming_union_merge kill switch
# restores the full legacy behaviour for BOTH modes.

_SPOOL_CHUNK_PREFIX = "qs-mw-chunk-"       # per-worker partial temp dirs
_MERGE_SPOOL_PREFIX = "qs-mw-merge-"       # coordinator IPC spool files
_MERGE_SPOOL_SUBDIR = "qs_mw_merge"
_SPOOL_GC_AGE_S = 24 * 3600                # sweep leftovers older than 24h
                                           # (outer dispatch cap is 4h)


def _streaming_union_enabled() -> bool:
    """Config gate ``multi_worker.streaming_union_merge`` — default ON.

    Emergency rollback knob only: set to false to restore the legacy
    load-everything-then-concat behaviour."""
    try:
        from core.config import get as _cfg_get
        v = _cfg_get("multi_worker", "streaming_union_merge", True)
        if v is None:
            return True
        if isinstance(v, str):
            return v.strip().lower() not in ("0", "false", "no", "off")
        return bool(v)
    except Exception:
        return True


def _resolve_merge_spool_dir() -> str:
    """Directory for the coordinator's IPC merge spool.  Prefers the
    operator-configured DuckDB spill dir (already pointed at a disk sized
    for query spill), falls back to the OS temp dir."""
    base = _resolve_temp_dir_for_spill() or tempfile.gettempdir()
    d = os.path.join(base, _MERGE_SPOOL_SUBDIR)
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        d = tempfile.gettempdir()
    return d


def _remove_path_quiet(path: str) -> None:
    """Best-effort file delete.  On Windows a still-memory-mapped spool
    file cannot be deleted — the age-based sweep catches it later."""
    try:
        os.remove(path)
    except OSError:
        pass


def _gc_stale_merge_artifacts() -> None:
    """Age-based sweep of orphaned spool artifacts (best-effort, cheap).

    Two orphan classes exist by design:
      * ``qs-mw-chunk-*`` partial dirs from workers abandoned by the
        BF-586 outer timeout that later completed successfully (their
        results are discarded, so the coordinator never cleans them);
      * ``qs-mw-merge-*.arrow`` spool files whose delete-on-collect
        finalizer failed on Windows (file still memory-mapped at GC time).

    Anything older than _SPOOL_GC_AGE_S (24h — 6× the outer dispatch cap)
    is provably dead."""
    import shutil
    now = time.time()
    try:
        candidates: List[str] = []
        tmp = tempfile.gettempdir()
        for name in os.listdir(tmp):
            if name.startswith(_SPOOL_CHUNK_PREFIX):
                candidates.append(os.path.join(tmp, name))
        spool_dir = os.path.join(
            _resolve_temp_dir_for_spill() or tmp, _MERGE_SPOOL_SUBDIR)
        if os.path.isdir(spool_dir):
            for name in os.listdir(spool_dir):
                if name.startswith(_MERGE_SPOOL_PREFIX):
                    candidates.append(os.path.join(spool_dir, name))
        removed = 0
        for path in candidates:
            try:
                if now - os.path.getmtime(path) < _SPOOL_GC_AGE_S:
                    continue
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    os.remove(path)
                removed += 1
            except OSError:
                continue
        if removed:
            logger.info("[multi-worker] spool GC removed %d stale artifacts",
                        removed)
    except Exception as _gc_exc:
        logger.debug("[multi-worker] spool GC failed: %s", _gc_exc)


def _cleanup_spooled_partials(results: List["WorkerResult"]) -> None:
    """Delete the temp dirs of path-backed partials.  Called on EVERY exit
    from the post-dispatch section (merge done, fell-back, raised) so
    spooled partials never outlive the dispatch that created them."""
    import shutil
    for r in results:
        p = getattr(r, "table_path", None)
        if not p:
            continue
        try:
            shutil.rmtree(os.path.dirname(p), ignore_errors=True)
        except Exception as _rm_exc:
            logger.debug("[multi-worker] partial cleanup failed for %s: %s",
                         p, _rm_exc)


def _spool_thread_partial_ipc(
    cur,
    chunk: "FileChunk",
    t0: float,
    correlation_id: str,
    wtag: str,
) -> Optional["WorkerResult"]:
    """2026-07-31 (risk-1 close) — stream a thread worker's executed DuckDB
    cursor into an Arrow IPC spool file, one record batch at a time.

    Replaces the legacy ``.to_arrow_table()`` materialisation for UNION
    partials: the partial never exists whole in process memory — batches
    flow cursor → IPC file, and the coordinator later stream-merges the
    files.  Batch size is width-aware via the SAME formula the merge uses
    (``result_merger._stream_batch_rows``); width comes from
    ``cursor.description`` (available after execute(), no row fetched).

    Failure classification — probe-verified on DuckDB 1.5.2: the Arrow
    record-batch reader surfaces BOTH query errors and cancel interrupts
    as plain ``OSError``, so exception TYPE cannot separate them from
    disk failures.  Classification is therefore by CALL SITE:

      * reader-side exceptions (``read_next_batch`` — query error, cancel
        interrupt) PROPAGATE: they are exactly what the legacy
        ``.to_arrow_table()`` would have raised, and the caller's existing
        except/cancel handling applies unchanged;
      * writer/spool-side exceptions (mkdtemp / open / write_batch /
        footer close — disk full, spill dir vanished) return ``None``:
        the caller LOUDLY falls back to the legacy in-memory
        materialisation, so a sick spill disk can never fail a query that
        used to succeed.

    On success the returned WorkerResult hands ownership of the spool dir
    to the coordinator (``_cleanup_spooled_partials`` reclaims it after
    the merge); on every failure path this function deletes the dir
    itself."""
    import shutil

    # Width probe with NO row fetched — description is populated by
    # execute() alone.
    try:
        _desc = getattr(cur, "description", None)
        n_cols = len(_desc) if _desc else 0
    except Exception:
        n_cols = 0
    from core.result_merger import _stream_batch_rows
    batch_rows = _stream_batch_rows(n_cols)

    # Streaming reader — prefer the non-deprecated to_arrow_reader
    # (DuckDB >= 1.5); fetch_record_batch for older builds.  No streaming
    # API at all → keep the legacy in-memory path (cursor untouched, so
    # the caller's re-execute is a no-op cost).
    if hasattr(cur, "to_arrow_reader"):
        reader = cur.to_arrow_reader(batch_rows)
    elif hasattr(cur, "fetch_record_batch"):
        reader = cur.fetch_record_batch(batch_rows)
    else:                       # pragma: no cover — pre-0.6 DuckDB only
        logger.warning("%s no Arrow streaming API on this DuckDB build — "
                       "keeping legacy in-memory partial", wtag)
        return None

    out_dir: Optional[str] = None
    try:
        out_dir = tempfile.mkdtemp(
            prefix=f"{_SPOOL_CHUNK_PREFIX}{chunk.chunk_index}-")
        out_path = os.path.join(out_dir, "partial.arrow")
        sink = pa.OSFile(out_path, "wb")
    except (OSError, pa.ArrowException) as _mk_exc:
        if out_dir:
            shutil.rmtree(out_dir, ignore_errors=True)
        logger.warning("%s IPC spool setup failed (%s: %s) — falling back "
                       "to legacy in-memory materialisation", wtag,
                       type(_mk_exc).__name__, _mk_exc)
        return None

    n_rows = 0
    _spool_ok = False
    try:
        _close_exc: Optional[Exception] = None
        writer = None
        try:
            # Header write — spool-side: a failure here means the sink is
            # unusable, not that the query failed.
            try:
                writer = pa.ipc.new_file(sink, reader.schema)
            except (OSError, pa.ArrowException) as _hdr_exc:
                logger.warning(
                    "%s IPC spool header write failed (%s: %s) — falling "
                    "back to legacy in-memory materialisation", wtag,
                    type(_hdr_exc).__name__, _hdr_exc)
                return None
            while True:
                # Reader side: query errors / cancel interrupts raise HERE
                # and must PROPAGATE — never swallowed into a spool
                # fallback (re-executing a genuinely failing query would
                # double the work just to fail again).
                try:
                    batch = reader.read_next_batch()
                except StopIteration:
                    break
                # Writer side: only genuine spool I/O failures raise here.
                try:
                    writer.write_batch(batch)
                except (OSError, pa.ArrowException) as _sp_exc:
                    logger.warning(
                        "%s IPC spool write failed after %d rows (%s: %s) "
                        "— falling back to legacy in-memory "
                        "materialisation", wtag, n_rows,
                        type(_sp_exc).__name__, _sp_exc)
                    return None
                n_rows += batch.num_rows
        finally:
            if writer is not None:
                try:
                    writer.close()   # finalises the IPC footer
                except (OSError, pa.ArrowException) as _we:
                    # Spool-side failure; recorded instead of raised so a
                    # propagating reader exception is never masked.
                    _close_exc = _we
            try:
                sink.close()
            except Exception:        # pragma: no cover — best-effort
                pass
        if _close_exc is not None:
            logger.warning("%s IPC spool footer close failed (%s: %s) — "
                           "falling back to legacy in-memory "
                           "materialisation", wtag,
                           type(_close_exc).__name__, _close_exc)
            return None

        elapsed = time.monotonic() - t0
        logger.info(
            "%s COMPLETED (IPC-spooled) — rows=%d, cols=%d, "
            "batch_rows=%d, total=%.2fs, spool=%s",
            wtag, n_rows, n_cols, batch_rows, elapsed, out_path,
        )
        _set_worker_state(correlation_id, chunk.chunk_index,
                           "completed", rows=n_rows,
                           elapsed_s=round(elapsed, 2))
        _spool_ok = True
        return WorkerResult(
            chunk_index=chunk.chunk_index,
            files=chunk.files,
            table=None,
            table_path=out_path,
            elapsed_s=elapsed,
            row_count=n_rows,
        )
    finally:
        if not _spool_ok and out_dir:
            shutil.rmtree(out_dir, ignore_errors=True)


def _stream_union_merge(ok_results: List["WorkerResult"],
                        correlation_id: str) -> pa.Table:
    """Stream path-backed union partials into one memory-mapped table.

    Row-conservation audit: the merged row count MUST equal the sum of the
    per-worker footer counts — a mismatch raises loudly and the caller
    falls back to the legacy concat path (never silently short).

    The IPC spool file is deleted when the returned table is garbage-
    collected (weakref.finalize; POSIX allows unlink-while-mapped).  On
    Windows a mapped file can't be deleted — _gc_stale_merge_artifacts
    sweeps it later."""
    import uuid
    import weakref

    from core.result_merger import merge_union_streaming

    _gc_stale_merge_artifacts()
    spool_path = os.path.join(
        _resolve_merge_spool_dir(),
        f"{_MERGE_SPOOL_PREFIX}{correlation_id or 'x'}-"
        f"{uuid.uuid4().hex[:8]}.arrow",
    )
    sources = [r.table_path for r in ok_results]
    expected_rows = sum(int(r.row_count or 0) for r in ok_results)
    try:
        merged = merge_union_streaming(sources, spool_path)
    except Exception:
        _remove_path_quiet(spool_path)
        raise
    if merged.num_rows != expected_rows:
        _got_rows = merged.num_rows
        del merged  # release the mapping before attempting delete
        _remove_path_quiet(spool_path)
        raise RuntimeError(
            f"[multi-worker] streaming union row-conservation FAILED: "
            f"merged {_got_rows} rows but workers reported {expected_rows}"
        )
    weakref.finalize(merged, _remove_path_quiet, spool_path)
    return merged


def _summarise_stack_frame(worker_tid: int) -> str:
    """BF-599d — sample the worker thread's current Python frame and
    return a single grep-able string.

    Walks from the deepest user-relevant frame outward, skipping noise
    frames (threading internals, the heartbeat itself).  Falls back to
    the literal bottom-of-stack frame when no user frame is identifiable.

    Returns ``"<no frame>"`` when the worker thread can't be sampled
    (already exited, or the GIL is held by C code that doesn't yield
    Python frames — both reasonable signals on their own).
    """
    try:
        frames = sys._current_frames()
        frame = frames.get(worker_tid)
        if frame is None:
            return "<no frame>"
        stack = traceback.extract_stack(frame)
        if not stack:
            return "<empty stack>"
        # Walk outermost → innermost, prefer frames from our own code
        # (multi_worker_executor, iceberg_reader, parquet_engine_v2,
        # duckdb_views, s3_*).  Skip threading.py, queue.py, and the
        # heartbeat helper itself.
        _SKIP_FILES = {"threading.py", "queue.py", "_weakrefset.py"}
        _PREFER_HINTS = (
            "multi_worker", "iceberg", "duckdb", "parquet",
            "s3_", "execute_api", "register_s3", "boto", "urllib3",
            "httpfs", "ssl.py", "socket.py",
        )
        candidate = None
        for entry in reversed(stack):  # deepest first
            fname = os.path.basename(entry.filename or "")
            if fname in _SKIP_FILES:
                continue
            if entry.name in ("_running_heartbeat", "_heartbeat_loop",
                              "_summarise_stack_frame"):
                continue
            if candidate is None:
                candidate = entry
            if any(hint in fname for hint in _PREFER_HINTS):
                return f"{fname}:{entry.lineno} {entry.name}"
        if candidate is not None:
            return f"{os.path.basename(candidate.filename or '?')}:" \
                   f"{candidate.lineno} {candidate.name}"
        entry = stack[-1]
        return f"{os.path.basename(entry.filename or '?')}:{entry.lineno} {entry.name}"
    except Exception:
        return "<sample failed>"


def _flush_handlers(_logger: logging.Logger) -> None:
    """BF-599: force every handler in the logger chain to flush.

    DuckDB's httpfs extension is C code — a segfault during cold-S3
    fetch on Windows kills the Python process WITHOUT raising any
    Python exception or calling atexit hooks.  StreamHandler /
    FileHandler buffers can lose the last few log lines, hiding the
    exact wedge point.

    Walking the parent chain catches the root logger's handlers too
    (where the per-query FileHandler usually lives).  Errors are
    swallowed — flush is best-effort.
    """
    _walker = _logger
    while _walker is not None:
        for _h in list(_walker.handlers):
            try:
                _h.flush()
            except Exception as _flush_exc:
                # Best-effort: flush during a C-level crash may fail
                # on closed handlers / racing rotation.  Log to
                # stderr-of-last-resort via debug; this loop must
                # survive any single-handler failure to flush the
                # rest.
                logger.debug(
                    "[loop-watchdog] handler %r flush failed: %s",
                    _h, _flush_exc,
                )
        if not _walker.propagate:
            break
        _walker = _walker.parent


def _clear_worker_state(correlation_id: str, chunk_index: int,
                         keep_terminal: bool = True):
    """Drop or mark terminal."""
    key = f"{correlation_id or 'unknown'}:{chunk_index}"
    with _ACTIVE_LOCK:
        if not keep_terminal:
            _ACTIVE_WORKERS.pop(key, None)


def get_active_workers() -> List[Dict[str, Any]]:
    """Return all currently-tracked worker entries (terminal included for last 60s).

    Admin UI calls this every 1-2s to render a live grid of workers.
    """
    now = time.time()
    with _ACTIVE_LOCK:
        # Garbage-collect entries terminal for >60s
        stale_keys = [
            k for k, v in _ACTIVE_WORKERS.items()
            if v.get("state") in ("completed", "failed", "cancelled")
            and now - v.get("updated_at", 0) > 60
        ]
        # BF-599e (2026-05-30): also evict stuck NON-terminal entries —
        # a worker that hangs for >2 hours with no state-change update
        # is either a process that died without writing terminal state
        # (C-level crash bypassing _set_worker_state) or a zombie from
        # a prior dispatch that was abandoned by the outer-timeout
        # fallback (BF-586).  Without this, the live grid pollutes
        # forever with state=running entries that will never complete.
        # Threshold is per_worker_timeout_s (1800s default) + 50% grace
        # = 2700s, but we use a flat 7200s (2h) because we don't have
        # the per-dispatch timeout in scope here.
        _NON_TERMINAL_TTL = 7200
        stale_non_terminal = [
            k for k, v in _ACTIVE_WORKERS.items()
            if v.get("state") not in ("completed", "failed", "cancelled")
            and now - v.get("updated_at", 0) > _NON_TERMINAL_TTL
        ]
        stale_keys.extend(stale_non_terminal)
        if stale_non_terminal:
            logger.warning(
                "[multi-worker] evicting %d stuck NON-terminal entries "
                "(>%ds since last update — orphaned by C-crash or "
                "BF-586 outer-timeout)",
                len(stale_non_terminal), _NON_TERMINAL_TTL,
            )
        for k in stale_keys:
            _ACTIVE_WORKERS.pop(k, None)
        # BF-599e (2026-05-30): snapshot AFTER eviction so the returned
        # list reflects the post-GC state.  Previous code took items
        # BEFORE eviction — admin UI showed evicted entries for one
        # poll tick before they disappeared.
        items = list(_ACTIVE_WORKERS.values())
    # Add live elapsed
    for it in items:
        it["elapsed_s"] = round(now - it.get("started_at", now), 2)
    items.sort(key=lambda i: (i.get("correlation_id", ""), i.get("chunk_index", 0)))
    return items


def _record_outcome(outcome: "MultiWorkerOutcome", raised: bool,
                     correlation_id: str = "",
                     per_worker_summary: Optional[List[Dict[str, Any]]] = None):
    with _STATS_LOCK:
        _STATS["submitted"] += 1
        _STATS["last_invocation_at"] = time.time()
        _STATS["total_worker_runs"] += outcome.worker_count
        _STATS["total_worker_ok"]   += outcome.succeeded
        _STATS["total_worker_fail"] += outcome.failed
        if raised:
            status = "failed"
            _STATS["failed"] += 1
        elif outcome.fell_back:
            status = "fell_back"
            _STATS["fell_back"] += 1
        else:
            status = "succeeded"
            _STATS["succeeded"] += 1
        try:
            _HISTORY.append({
                "timestamp":       time.time(),
                "status":          status,
                # 2026-06-03 — correlation_id (= execution_id on the main
                # path, hard-coded for broadcast/partition-aligned joins).
                # Stashing here lets the per-query diagnostic correlate
                # this dispatch with the engine_router decision via
                # execution_id WITHOUT requiring live worker state to
                # still be alive.
                "correlation_id":  correlation_id or "",
                "worker_count":    outcome.worker_count,
                "succeeded":       outcome.succeeded,
                "failed":          outcome.failed,
                "rows":            outcome.table.num_rows if outcome.table is not None else 0,
                "elapsed_s":       round(outcome.total_elapsed_s, 3),
                "merge_strategy":  outcome.merge_strategy,
                "fallback_reason": outcome.fallback_reason or "",
                # 2026-06-03 — per-worker summary for offline diagnostic.
                # Slim shape (chunk_index, files-count, elapsed_s, ok)
                # so 50 history rows × 32 workers = 1600 small dicts is
                # still cheap.  Full Arrow tables stay off-history.
                "per_worker":      list(per_worker_summary or []),
            })
        except Exception as _hist_err:
            logger.debug("[multi-worker] history append failed: %s", _hist_err)


# ─────────────────────────────────────────────────────────────────────────────
# Result types
# ─────────────────────────────────────────────────────────────────────────────


#: The failures after which a chunk may be re-run ONCE (2026-10-23).  A
#: chunk only READS its files, so a re-run cannot duplicate anything; the
#: list is still a declaration, never "any error": DuckDB's own INTERNAL
#: error (an engine fault -- httpfs 1.5.3 was seen raising one on a
#: negative length under concurrent reads) is the only member.  A binder /
#: parser / conversion error would fail again; a timeout or a cancel is an
#: answer, not a fault.
_CHUNK_RERUN_SAFE_FAILURES = ("InternalException",)


def _chunk_rerun_is_safe(r: "WorkerResult") -> bool:
    """True when ``r`` failed with a declared re-run-safe engine fault (and
    was not stopped by a timeout or a cancel)."""
    if r.ok or r.cancel_source:
        return False
    names = (r.original_exc_type or "", (r.error or "").split(":", 1)[0].strip())
    return any(n in _CHUNK_RERUN_SAFE_FAILURES for n in names)


@dataclass
class WorkerResult:
    """One worker's outcome — partial Arrow table or failure."""
    chunk_index: int
    files: List[Any]
    table: Optional[pa.Table] = None
    error: Optional[str] = None
    elapsed_s: float = 0.0
    row_count: int = 0
    # 149.0 (2026-06-09): preserve the underlying exception type+message
    # when the worker is killed by an external cancel.  Pre-fix we
    # silently relabelled every race-exception to "cancelled mid-query",
    # which discarded the real cause (ConnectionClosed / InterruptException
    # / S3 timeout / TaskTimeout from the worker_pool watchdog).  The
    # dispatcher now surfaces this in EngineDecision.reason so admins
    # can see WHY partition-aligned fell back instead of guessing.
    cancel_source: str = ""        # "" | "task_timeout" | "outer_timeout" | "external_cancel" | "before_start"
    original_exc_type: str = ""    # e.g. "ConnectionException", "InterruptException"
    original_exc_msg: str = ""     # truncated original exception message
    # 2026-07-31 streaming-union merge: workers on the UNION strategy
    # leave their partial ON DISK and hand back the path instead of
    # holding it in coordinator RAM (the old paths held N × full-partial
    # simultaneously — O(result) for a plain SELECT).  Subprocess workers
    # point at their COPY parquet (row_count from the footer, O(KB));
    # thread workers point at a lossless Arrow IPC spool (row_count
    # counted while streaming).  The coordinator sniffs the format by
    # magic bytes, streams these paths into the final result batch-by-
    # batch, and deletes the temp dirs afterwards.
    table_path: Optional[str] = None

    @property
    def ok(self) -> bool:
        return self.error is None and (
            self.table is not None or self.table_path is not None
        )


@dataclass
class MultiWorkerOutcome:
    """Final outcome returned to the caller."""
    table: pa.Table
    worker_count: int
    succeeded: int
    failed: int
    total_elapsed_s: float
    fell_back: bool = False
    fallback_reason: str = ""
    per_worker: List[WorkerResult] = field(default_factory=list)
    merge_strategy: str = ""

    def to_dict(self) -> Dict[str, Any]:
        # 2026-07-16: surface the TOTAL files scanned across all workers so the
        # UI can show "scanned N files across K workers" — the number that
        # tells the user whether pruning did its job.  Derived from per_worker
        # (each WorkerResult carries its chunk's file list), so it is correct
        # on the success, fallback, and error paths alike with no extra state.
        _files_total = sum(len(w.files or []) for w in self.per_worker)
        return {
            "row_count":         self.table.num_rows if self.table is not None else 0,
            "column_count":      self.table.num_columns if self.table is not None else 0,
            "worker_count":      self.worker_count,
            "files_total":       _files_total,
            "succeeded":         self.succeeded,
            "failed":            self.failed,
            "total_elapsed_s":   round(self.total_elapsed_s, 3),
            "fell_back":         self.fell_back,
            "fallback_reason":   self.fallback_reason,
            "merge_strategy":    self.merge_strategy,
            "per_worker":        [
                {"chunk_index": w.chunk_index, "files": len(w.files),
                 "rows": w.row_count, "elapsed_s": round(w.elapsed_s, 3),
                 "ok": w.ok, "error": w.error}
                for w in self.per_worker
            ],
        }


# ─────────────────────────────────────────────────────────────────────────────
# Public dispatcher
# ─────────────────────────────────────────────────────────────────────────────


def execute_multi_worker(
    split_plan: SplitPlan,
    setup_sql_builder: Callable[[FileChunk], str],
    *,
    final_sql: str = "",
    executor_mode: str = "thread",
    max_workers: int = 4,
    per_worker_timeout_s: int = 1800,
    fallback_on_error: bool = True,
    cancel_event: Optional[threading.Event] = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    duckdb_settings: Optional[Dict[str, str]] = None,
    correlation_id: str = "",
    # 2026-06-03 — when False, the BF-586 outer timeout is suppressed
    # (set to sys.maxsize) so feed-gen / published-API / scheduled-
    # report queries run to completion no matter how slow.  Interactive
    # callers (BQB/CQB) keep the cap so a runaway query can be
    # recovered.
    cancellable: bool = True,
) -> MultiWorkerOutcome:
    """Run each chunk in parallel, collect partials, merge.

    Args:
      split_plan:        result of ``query_splitter.decide_split()``
      setup_sql_builder: callable invoked per chunk; returns the setup
                          SQL (CREATE VIEW / table-registration DDL) that
                          binds the partial SQL to that chunk's files.
      final_sql:         the original (un-rewritten) SQL — passed to the
                          merger for diagnostics + GROUP BY extraction.
      executor_mode:     'thread' or 'subprocess'.
      max_workers:       upper bound on parallelism.
      per_worker_timeout_s: kill a worker after this many seconds.
      fallback_on_error: when any worker fails, do we attempt fallback to
                          single-worker execution? (Caller actually runs
                          the fallback — we signal via ``fell_back=True``.)
      cancel_event:      sets → all workers stop ASAP.
      progress_cb:       ``(done_count, total_count, message)`` called as
                          each worker finishes.  Best-effort.
      duckdb_settings:   dict of ``SET key=value`` to apply per worker
                          (memory_limit, threads, etc.).

    Returns ``MultiWorkerOutcome``.  Raises ``RuntimeError`` only on
    catastrophic failure (e.g. merger crashes) — partial worker failures
    are reported via the outcome with ``fell_back=True`` to let the
    caller decide.
    """
    if not split_plan.splittable:
        raise ValueError(f"split_plan not splittable: {split_plan.skip_reason}")
    if not split_plan.chunks:
        raise ValueError("split_plan has no chunks")

    t_start = time.monotonic()
    n_workers = min(max_workers, len(split_plan.chunks))
    if n_workers < 1:
        n_workers = 1

    # ── Query pods (2026-10-31, security review): a run with a RESERVATION
    # fans out to no more children than the reservation holds at the
    # engine's floor, and the children SHARE the reservation -- so the total
    # the run's processes may use never exceeds what the pod admitted it on
    # (core/query_pods/budget.py).  THIS is the one place the fan-out is
    # decided, so the bound lives here; the spawn divides, never lifts.
    # correlation_id == the execution id on the main path; the reservation
    # reaches this thread through the run's context (the worker pool copies
    # it) or the bridge's note by execution id.  No reservation -> unchanged.
    _qp_reserved = 0
    try:
        from core.query_pods.budget import (
            MB as _qp_mb, max_children_for_reservation as _qp_max_children,
            reservation_for as _qp_reservation,
        )
        _qp_reserved = int(_qp_reservation(correlation_id) or 0)
        if _qp_reserved > 0:
            _qp_cap = _qp_max_children(_qp_reserved)
            if n_workers > _qp_cap:
                logger.info(
                    "[multi-worker] query pod reservation %.0f MB holds %d child(ren) at the "
                    "engine's floor: fan-out %d -> %d", _qp_reserved / _qp_mb, _qp_cap,
                    n_workers, _qp_cap)
                n_workers = _qp_cap
    except Exception as _qp_exc:  # noqa: BLE001 -- unchanged behaviour on any failure
        logger.debug("[multi-worker] reservation bound skipped: %s", _qp_exc)
        _qp_reserved = 0

    # 2026-07-31 audit fix (T2): STAMP the concurrency so each child can size
    # its spill share.
    #
    # core/duckdb_resource_limits.resolve_spill_quota_bytes divides the
    # "50% of free disk" ceiling by QS_DUCKDB_CONCURRENT_CHILDREN, because
    # every child samples the SAME free-space reading -- without the divisor,
    # N workers are each promised the whole share (4 workers => 200% of free
    # disk).  That divisor shipped in c3a4e029 reading this variable, but
    # NOTHING EVER WROTE IT: a repo-wide grep found only the read site and its
    # own comment, so every child computed N=1 and the fix was inert.  Same
    # "wired to an input nobody provides" mistake as the one-caller
    # "chokepoint" earlier in the session.
    #
    # Set in the PARENT's environment before any worker spawns, so both the
    # legacy Popen path (_spawn_env = os.environ.copy()) and thread workers
    # inherit it.  Restored in the finally below so a dispatch cannot leak
    # concurrency state into unrelated later queries.
    _kids_token = _kids_stamp_enter(int(n_workers))

    def _restore_kids_env():
        """Undo the stamp on EVERY exit path, so a dispatch cannot leak its
        concurrency into a later, unrelated query (which would under-size
        that query's spill share).  Idempotent: several exit paths call it."""
        _kids_stamp_exit(_kids_token)

    logger.info(
        "[multi-worker] dispatching %d chunks across %d workers (mode=%s, "
        "merge=%s, files_total=%d)",
        len(split_plan.chunks), n_workers, executor_mode,
        split_plan.merge_strategy,
        sum(len(c.files) for c in split_plan.chunks),
    )
    # BF-586 (2026-05-29): log per-worker file count so admins can
    # verify distribution at a glance (no more "are files spread or
    # all in chunk 0?" mystery).
    for _c in split_plan.chunks:
        logger.info(
            "[multi-worker] chunk %d: %d files (total_bytes=%s)",
            _c.chunk_index, len(_c.files),
            getattr(_c, "total_size_bytes", "n/a"),
        )
    # BF-599d (2026-05-30): operator-facing sanity warning when chunks
    # are very large.  Cold S3 + Windows can hit ~50-100ms per footer
    # fetch — at 500+ files per worker the wall time goes >1 hour
    # before partial_sql even starts.  Surfaces a clear "bump
    # max_workers" hint in the per-query log instead of leaving the
    # user staring at a wedged-looking worker for 30 min.
    _max_files_per_chunk = max((len(c.files) for c in split_plan.chunks), default=0)
    if _max_files_per_chunk >= 500:
        logger.warning(
            "[multi-worker] LARGE CHUNKS: max chunk has %d files across %d "
            "workers (cold S3 footer fetch is serial inside each worker). "
            "If this query is slow, raise admin → Multi-Worker → "
            "'Max workers' to %d so each chunk gets ~200 files.",
            _max_files_per_chunk, n_workers,
            max(n_workers, _max_files_per_chunk // 200),
        )

    # BF-599d (2026-05-30): per-worker memory + spill defaults.
    # Without these, N DuckDB connections each auto-detect host RAM and
    # set memory_limit to ~75% — 4 workers × 75% pod = 300% pod budget,
    # OOM-killed silently.  Caller-supplied duckdb_settings always win.
    _ms = dict(duckdb_settings or {})
    if _qp_reserved > 0:
        # 2026-10-31: the run's reservation, split among ITS children -- not
        # the pod's share.  Each child's SET memory_limit lands in its setup
        # SQL (the channel below), so the sum over the fan-out is exactly
        # the reservation the pod set aside for this run.
        _ms["memory_limit"] = f"{max(1, _qp_reserved // n_workers // _qp_mb)}MB"
        logger.info("[multi-worker] query pod reservation %.0f MB / %d worker(s) = "
                    "memory_limit %s per child", _qp_reserved / _qp_mb, n_workers,
                    _ms["memory_limit"])
    elif "memory_limit" not in _ms:
        # BF-558b (2026-08-01): divide ACROSS concurrent queries too, not
        # just across this query's workers.  BF-599d composed within one
        # dispatch (4 workers x 75% -> 4 x 18.75%), but every CONCURRENT
        # QUERY still computed its share from the same global reading, so
        # 50 single-worker queries each claimed 75% of the pod = a 37x
        # over-promise.  memory_limit is a CEILING, not a reservation, so
        # nothing spilled early -- they grew until the KERNEL OOM-killed
        # the pod, taking every in-flight query with it.
        #
        # Deliberately NOT signalled via QS_DUCKDB_CONCURRENT_CHILDREN:
        # os.environ is process-global, so concurrent dispatches overwrite
        # each other's stamp under exactly the conditions this is meant to
        # fix.  This value rides the per-spawn duckdb_settings channel
        # (BF-599e prepends it to setup_sql), which is race-free because
        # it is baked into THAT child's SQL.
        #
        # Fail-open: live_query_concurrency() returns 1 on any error or
        # before pool init, making this byte-identical to BF-599d.
        try:
            from core.worker_pool import live_query_concurrency
            _live_q = max(1, live_query_concurrency())
        except Exception:
            _live_q = 1
        _per_worker_mb = _compute_per_worker_memory_mb(n_workers * _live_q)
        if _live_q > 1:
            logger.info(
                "[multi-worker] BF-558b: cross-query divisor active — "
                "%d concurrent queries x %d workers = %d-way split",
                _live_q, n_workers, n_workers * _live_q,
            )
        if _per_worker_mb:
            _ms["memory_limit"] = f"{_per_worker_mb}MB"
            logger.info(
                "[multi-worker] BF-599d: per-worker memory_limit=%dMB "
                "(n_workers=%d, reserve=30%% for python/arrow)",
                _per_worker_mb, n_workers,
            )
    if "temp_directory" not in _ms:
        _spill_dir = _resolve_temp_dir_for_spill()
        if _spill_dir:
            _ms["temp_directory"] = _spill_dir
            logger.info(
                "[multi-worker] BF-599d: spill-to-disk temp_directory=%s",
                _spill_dir,
            )
    # 2026-08-02 (defect 2): divide THREADS by the same divisor as memory.
    # Memory composed (n_workers x live queries) but threads never did:
    #   * subprocess mode: each child resolved cpus-1 independently;
    #   * thread mode (the DEFAULT): these in-process connections got
    #     memory_limit + temp_directory from duckdb_settings but never a
    #     threads value at all, so each defaulted to the HOST core count.
    # 30 engines x 7 threads on 8 vCPU = 210 runnable threads — every
    # query thrashes and holds its pool slot longer.  Caller-supplied
    # settings always win; divisor==1 (single worker, no concurrent
    # queries) adds nothing, keeping the common case byte-identical.
    # Fail-open: any error leaves threads unset — today's behaviour.
    if "threads" not in _ms:
        try:
            # Own live count — NOT shared with the memory branch, which is
            # skipped entirely when the caller supplies a memory_limit (a
            # shared variable would then silently disable this divisor).
            try:
                from core.worker_pool import (
                    live_query_concurrency as _lqc_threads,
                )
                _thr_live = max(1, _lqc_threads())
            except Exception:
                _thr_live = 1
            _thr_div = max(1, n_workers) * _thr_live
            if _thr_div > 1:
                from core.duckdb_resource_limits import (
                    resolve_thread_count_for_duckdb,
                )
                _per_worker_threads = resolve_thread_count_for_duckdb(
                    concurrency=_thr_div)
                if _per_worker_threads >= 1:
                    _ms["threads"] = str(int(_per_worker_threads))
                    logger.info(
                        "[multi-worker] per-worker threads=%d "
                        "(divisor=%d: %d workers x %d live queries)",
                        _per_worker_threads, _thr_div, n_workers, _thr_live,
                    )
        except Exception as _thr_exc:
            logger.debug(
                "[multi-worker] thread divisor skipped (fail-open): %s",
                _thr_exc,
            )
    duckdb_settings = _ms

    if executor_mode == "subprocess":
        runner = _run_chunk_subprocess
    else:
        runner = _run_chunk_thread

    # 2026-07-31 streaming-union merge: UNION partials stay on disk and
    # are streamed into the final result with O(one batch) of coordinator
    # memory instead of being loaded whole.  Subprocess workers spool
    # their COPY parquet; thread workers (risk-1 close — thread is the
    # DEFAULT mode) stream their cursor into a LOSSLESS Arrow IPC spool —
    # see the streaming-plumbing comment block above.  Aggregate
    # strategies keep the legacy in-memory path (small partials, concat is
    # correct there).
    _spool_union = (
        split_plan.merge_strategy == "union"
        and executor_mode in ("subprocess", "thread")
        and _streaming_union_enabled()
    )
    if _spool_union:
        logger.info("[multi-worker] union partials will be spooled to disk "
                    "and stream-merged (O(batch) coordinator memory)")

    # ── Dispatch ─────────────────────────────────────────────────────────────
    results: List[WorkerResult] = []
    done_count = 0
    total_count = len(split_plan.chunks)

    def _emit(msg: str):
        if progress_cb:
            try:
                progress_cb(done_count, total_count, msg)
            except Exception as _cb_err:
                logger.debug("[multi-worker] progress_cb raised: %s", _cb_err)

    # BF-405: generate a correlation_id so live progress can be grouped
    # per-dispatch in the admin UI.  If caller didn't pass one (e.g.
    # execution_id), make one up.
    _corr_id = correlation_id or f"mw-{int(time.time() * 1000)}"

    # BF-588 (2026-05-29): explicit pool lifecycle — NEVER use a
    # `with ThreadPoolExecutor` context here.  Audit found the
    # context manager's `__exit__` calls
    # ``shutdown(wait=True, cancel_futures=False)`` which BLOCKS
    # FOREVER waiting for hung worker threads to finish.  BF-586's
    # outer ``as_completed`` timeout was meaningless because the
    # `with` block still hung on shutdown.
    #
    # New pattern: explicit try/finally with
    # ``shutdown(wait=False, cancel_futures=True)``.  Returns
    # immediately even if workers are stuck in non-interruptible
    # syscalls (libcurl recv, boto3 socket).  Pool threads are
    # daemon so they die with the process.
    pool = ThreadPoolExecutor(max_workers=n_workers, thread_name_prefix="mw")
    futures: Dict[Any, Any] = {}
    try:
        futures = {
            pool.submit(
                runner,
                chunk,
                split_plan.partial_sql,
                setup_sql_builder(chunk),
                per_worker_timeout_s,
                cancel_event,
                duckdb_settings or {},
                _corr_id,
                _spool_union,
                n_workers,
            ): chunk
            for chunk in split_plan.chunks
        }

        # BF-586 outer timeout = per_worker × 1.25 + 30s grace.  Used to
        # be necessary alongside the `with` block to recover; with the
        # BF-588 explicit shutdown, this is now a sanity ceiling.
        # 2026-06-03 — when cancellable=False (api/feed/report), the
        # outer timeout is raised to a GENEROUS 4h ceiling instead of
        # sys.maxsize.  Rationale (audit catch): with no upper bound, a
        # genuinely stuck `as_completed` (boto3 socket hang, no progress
        # callbacks) would block forever, accumulating dead futures
        # until the ThreadPoolExecutor is exhausted and only a pod
        # restart recovers.  4h is well past any legitimate feed-gen
        # / published-API run yet still recoverable.
        if not cancellable:
            _outer_timeout = 4 * 3600.0   # 4 hours
        else:
            _outer_timeout = (per_worker_timeout_s or 1800) * 1.25 + 30
        _dispatch_t0 = time.monotonic()
        try:
            for fut in as_completed(futures, timeout=_outer_timeout):
                chunk = futures[fut]
                try:
                    wr: WorkerResult = fut.result()
                except Exception as exc:
                    logger.error("[multi-worker] chunk %d crashed: %s",
                                 chunk.chunk_index, exc)
                    wr = WorkerResult(
                        chunk_index=chunk.chunk_index,
                        files=chunk.files,
                        error=str(exc),
                    )
                results.append(wr)
                done_count += 1
                _emit(f"worker {wr.chunk_index} done "
                      f"({'ok' if wr.ok else 'FAILED'}; "
                      f"{wr.row_count:,} rows; {wr.elapsed_s:.1f}s)")

                # 2026-06-03 — push per-worker progress to the diagnostic
                # store so the admin Query Diagnostic UI's Live Worker
                # Progress table actually populates (was empty before;
                # only `record_worker_progress` was wired, never called).
                # Critical-path defence: failure must never propagate.
                try:
                    from core.query_diagnostic_store import record_worker_progress
                    record_worker_progress(_corr_id, int(wr.chunk_index), {
                        "rows_scanned":  int(wr.row_count or 0),
                        "files_count":   len(wr.files) if hasattr(wr, "files") else 0,
                        "elapsed_s":     float(wr.elapsed_s or 0),
                        "ok":            bool(wr.ok),
                        "error":         (wr.error or "")[:200] if not wr.ok else "",
                    })
                except Exception:
                    pass

                # Honour cancel — drain remaining futures
                if cancel_event is not None and cancel_event.is_set():
                    _unfinished = sum(1 for f in futures if not f.done())
                    logger.warning(
                        "[multi-worker] cancel_event set — cancelling %d "
                        "unfinished workers", _unfinished,
                    )
                    for f in futures:
                        if not f.done():
                            f.cancel()
                    # 2026-08-03 (C4) — append failure stubs for every chunk
                    # whose result was NOT collected before the break, exactly
                    # like the BF-588 outer-timeout path below.  Pre-fix the
                    # break left ``results`` as a SUBSET with failed == 0, so
                    # the merge ran on partial chunks and returned
                    # fell_back=False → the caller reported "completed" with
                    # silently missing rows (wrong SUM/COUNT under
                    # aggregation).  With the stubs, failed > 0 and the
                    # dispatch resolves as fell_back / raise — never a
                    # partial merge presented as complete.
                    _elapsed_c = time.monotonic() - _dispatch_t0
                    _collected_idx = {r.chunk_index for r in results}
                    for _f, _chunk in futures.items():
                        if _chunk.chunk_index in _collected_idx:
                            continue
                        results.append(WorkerResult(
                            chunk_index=_chunk.chunk_index,
                            files=_chunk.files,
                            error=(f"cancelled by cancel_event after "
                                   f"{_elapsed_c:.1f}s (result not collected)"),
                            cancel_source="external_cancel",
                            original_exc_type="Cancelled",
                            original_exc_msg=("cancel_event set before this "
                                              "worker's result was collected"),
                        ))
                        _set_worker_state(
                            _corr_id, _chunk.chunk_index,
                            "failed",
                            error="cancelled by cancel_event",
                            elapsed_s=round(_elapsed_c, 2),
                        )
                    break
        except FuturesTimeoutError:
            _elapsed = time.monotonic() - _dispatch_t0
            _unfinished = sum(1 for f in futures if not f.done())
            logger.error(
                "[multi-worker] BF-586: outer timeout exceeded after "
                "%.1fs (cap=%.1fs).  %d worker(s) abandoned — falling "
                "back to single-worker.  Common cause: httpfs / boto3 "
                "stuck on cold S3 fetch.",
                _elapsed, _outer_timeout, _unfinished,
            )
            if cancel_event is not None:
                cancel_event.set()
            for f in futures:
                if not f.done():
                    f.cancel()
            # BF-588 (2026-05-29): append failure stubs for abandoned
            # chunks so the downstream aggregation correctly sees this
            # as a FAILED multi-worker dispatch (not a "partial
            # success" with N=succeeded workers).  The caller's
            # ``maybe_dispatch_multi_worker`` checks ``failed_chunks``
            # to decide whether to fall back; without these stubs the
            # results list looked successful.
            for f, chunk in futures.items():
                if not f.done():
                    # 149.0 (2026-06-09): tag the cancel source so the
                    # dispatcher can render an actionable EngineDecision
                    # ("outer timeout fired at 2280s") instead of the
                    # opaque "cancelled mid-query" of pre-fix.
                    results.append(WorkerResult(
                        chunk_index=chunk.chunk_index,
                        files=chunk.files,
                        error=f"outer-timeout after {_elapsed:.1f}s (cap={_outer_timeout:.0f}s)",
                        cancel_source="outer_timeout",
                        original_exc_type="OuterTimeout",
                        original_exc_msg=f"as_completed exceeded {_outer_timeout:.0f}s",
                    ))
                    # BF-599g (2026-05-31): mark abandoned chunks as
                    # 'failed' in _ACTIVE_WORKERS so admin / BQB grid
                    # doesn't show them as "running" forever.  Without
                    # this, the worker thread (still alive in the
                    # abandoned future, daemon thread) might NEVER
                    # reach its finally block to write terminal state,
                    # leaving the entry stuck at state='running' until
                    # the 7200s non-terminal GC fires.
                    _set_worker_state(
                        _corr_id, chunk.chunk_index,
                        "failed",
                        error=f"outer-timeout after {_elapsed:.1f}s",
                        elapsed_s=round(_elapsed, 2),
                    )
    finally:
        # BF-588: NON-blocking shutdown.  Unfinished futures get
        # cancel-flagged (Python 3.9+); running futures are abandoned
        # but their threads are daemons so they die with the process.
        try:
            pool.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            # Python <3.9 fallback (no cancel_futures kwarg).  Best
            # we can do — at least don't wait.
            pool.shutdown(wait=False)

    # ── One re-run of a chunk that DuckDB itself broke (2026-10-23) ──────────
    # Found live on the rig: a 7,300-file MinIO scan through a published API
    # answered 200 at 03:40 and 422 at 03:46 for the SAME request -- 2 of 4
    # workers died inside httpfs ("INTERNAL Error: Information loss on integer
    # cast: value -670 ...", DuckDB 1.5.3), the fallback single-process road
    # then refused its presigned cap.  A chunk is a READ of its own files
    # (no write, no side effect): re-running it is safe BY DECLARATION
    # (`_CHUNK_RERUN_SAFE_FAILURES`), once, on a fresh connection, one at a
    # time.  Anything else -- a binder error, a timeout, a cancel -- still
    # falls back as before.
    _rerun = [r for r in results if not r.ok and _chunk_rerun_is_safe(r)
              and not (cancel_event is not None and cancel_event.is_set())]
    if _rerun:
        _by_index = {c.chunk_index: c for c in split_plan.chunks}
        for _bad in _rerun:
            _chunk = _by_index.get(_bad.chunk_index)
            if _chunk is None:
                continue
            logger.warning(
                "[multi-worker] chunk %d failed inside the engine (%s) -- "
                "re-running it once (a read; declared safe)",
                _bad.chunk_index, (_bad.error or "")[:160])
            try:
                _again: WorkerResult = runner(
                    _chunk, split_plan.partial_sql, setup_sql_builder(_chunk),
                    per_worker_timeout_s, cancel_event, duckdb_settings or {},
                    _corr_id, _spool_union, n_workers)
            except Exception as exc:     # the re-run's own failure is the answer
                _again = WorkerResult(chunk_index=_chunk.chunk_index,
                                      files=_chunk.files, error=str(exc))
            logger.info("[multi-worker] chunk %d re-run: %s", _chunk.chunk_index,
                        "ok" if _again.ok else f"FAILED again: {(_again.error or '')[:160]}")
            results[results.index(_bad)] = _again

    # ── Aggregate ────────────────────────────────────────────────────────────
    results.sort(key=lambda r: r.chunk_index)
    succeeded = sum(1 for r in results if r.ok)
    failed = sum(1 for r in results if not r.ok)
    total_elapsed = time.monotonic() - t_start

    # ── Failure handling ─────────────────────────────────────────────────────
    if failed > 0 and fallback_on_error:
        # Signal caller to retry single-worker.  Caller still gets the
        # outcome for telemetry, but with table=empty + fell_back=True.
        logger.warning(
            "[multi-worker] %d/%d workers failed — caller should fall back to "
            "single-worker execution.  Failures: %s",
            failed, total_count,
            [r.error for r in results if not r.ok][:3],
        )
        # 149.0 (2026-06-09): build an actionable fallback_reason.  Pre-fix
        # admins saw "3/4 workers failed: cancelled mid-query" with no clue
        # what KIND of cancel.  Now we group failures by cancel_source so
        # the operator sees "3/4 workers cancelled by outer_timeout (cap=2280s)
        # — first underlying exc: ConnectionException: HTTP 408".  Tells them
        # WHETHER to raise the timeout, scale workers, or investigate S3.
        _fail_by_src: Dict[str, int] = {}
        _first_underlying: Optional[WorkerResult] = None
        for r in results:
            if r.ok:
                continue
            _src = r.cancel_source or "exception"
            _fail_by_src[_src] = _fail_by_src.get(_src, 0) + 1
            if _first_underlying is None and r.original_exc_type:
                _first_underlying = r
        _src_summary = ", ".join(f"{c}×{src}" for src, c in sorted(_fail_by_src.items()))
        if _first_underlying:
            _fb_reason = (
                f"{failed}/{total_count} workers failed ({_src_summary}) — "
                f"first underlying: {_first_underlying.original_exc_type}: "
                f"{_first_underlying.original_exc_msg[:160]}"
            )[:400]
        else:
            _fb_reason = (
                f"{failed}/{total_count} workers failed ({_src_summary}): "
                + (next((r.error for r in results if not r.ok), "unknown"))[:200]
            )[:400]
        _fb_outcome = MultiWorkerOutcome(
            table=pa.table({}),
            worker_count=n_workers,
            succeeded=succeeded,
            failed=failed,
            total_elapsed_s=total_elapsed,
            fell_back=True,
            fallback_reason=_fb_reason,
            per_worker=results,
            merge_strategy=split_plan.merge_strategy,
        )
        _fb_pw_summary = [{
            "chunk_index": w.chunk_index,
            "files_count": len(w.files or []),
            "elapsed_s":   round(w.elapsed_s, 3),
            "ok":          w.ok,
            "row_count":   w.row_count,
            "error":       (w.error or "")[:200],
        } for w in results]
        _record_outcome(_fb_outcome, raised=False,
                        correlation_id=_corr_id,
                        per_worker_summary=_fb_pw_summary)
        # 2026-07-31: workers that DID succeed may have spooled partials
        # on disk — reclaim them before handing control back.
        _cleanup_spooled_partials(results)
        _restore_kids_env()   # early exit — must not leak the stamp
        return _fb_outcome

    if failed > 0:
        # No fallback — raise so caller surfaces error to the user.
        first_err = next((r.error for r in results if not r.ok), "unknown")
        _err_outcome = MultiWorkerOutcome(
            table=pa.table({}),
            worker_count=n_workers,
            succeeded=succeeded,
            failed=failed,
            total_elapsed_s=total_elapsed,
            per_worker=results,
            merge_strategy=split_plan.merge_strategy,
        )
        _err_pw_summary = [{
            "chunk_index": w.chunk_index,
            "files_count": len(w.files or []),
            "elapsed_s":   round(w.elapsed_s, 3),
            "ok":          w.ok,
            "row_count":   w.row_count,
            "error":       (w.error or "")[:200],
        } for w in results]
        _record_outcome(_err_outcome, raised=True,
                        correlation_id=_corr_id,
                        per_worker_summary=_err_pw_summary)
        _cleanup_spooled_partials(results)
        # 2026-08-02 audit fix: this raise path skipped _restore_kids_env(),
        # leaking QS_DUCKDB_CONCURRENT_CHILDREN=<n_workers> into os.environ
        # for the life of the process (verified by execution) — later
        # children spawned without an explicit per-spawn stamp would divide
        # their memory/spill share by a stale worker count.
        _restore_kids_env()
        raise RuntimeError(
            f"multi-worker execution failed: {failed}/{total_count} chunks "
            f"errored (fallback_on_error=False).  First error: {first_err}"
        )

    # ── Merge ────────────────────────────────────────────────────────────────
    def _merge_fell_back_outcome(reason: str) -> MultiWorkerOutcome:
        """Build + record a fell_back outcome for a merge-stage failure —
        caller falls back to single-worker execution (correct results,
        never a silently-corrupt merge)."""
        fail_outcome = MultiWorkerOutcome(
            table=pa.table({}),
            worker_count=n_workers,
            succeeded=0,
            failed=total_count,
            total_elapsed_s=time.monotonic() - t_start,
            fell_back=True,
            fallback_reason=reason[:300],
            per_worker=results,
            merge_strategy=split_plan.merge_strategy,
        )
        _mf_pw_summary = [{
            "chunk_index": w.chunk_index,
            "files_count": len(w.files or []),
            "elapsed_s":   round(w.elapsed_s, 3),
            "ok":          w.ok,
            "row_count":   w.row_count,
            "error":       (w.error or "")[:200],
        } for w in results]
        _record_outcome(fail_outcome, raised=False,
                        correlation_id=_corr_id,
                        per_worker_summary=_mf_pw_summary)
        _restore_kids_env()   # early exit — must not leak the stamp
        return fail_outcome

    # 2026-08-03 (C4 guard) — refuse to merge an INCOMPLETE chunk set.  Every
    # early exit from the collection loop is required to leave one result (ok
    # or failure stub) per chunk; if any path ever misses that contract again,
    # merging the subset would silently drop that chunk's rows.  Belt-and-
    # braces: signal fallback instead of presenting a partial merge as
    # complete.
    if len(results) != total_count:
        logger.error(
            "[multi-worker] refusing merge: %d/%d chunk results present "
            "(incomplete set — merging would silently drop rows)",
            len(results), total_count,
        )
        # This return is BEFORE the merge try/finally, so reclaim any
        # spooled partials here (collected ok-workers may have spooled).
        _cleanup_spooled_partials(results)
        return _merge_fell_back_outcome(
            f"refusing merge: only {len(results)}/{total_count} chunk results "
            f"present (incomplete set)")

    _ok_results = [r for r in results if r.ok]
    merged: Optional[pa.Table] = None
    try:
        # 2026-07-31 — streaming UNION merge: when every successful worker
        # spooled its partial to disk (subprocess+union), stream the
        # partials batch-by-batch into ONE memory-mapped table.  Peak
        # coordinator pool memory = O(one width-aware batch) instead of
        # O(full result).  Any failure falls back LOUDLY to the legacy
        # load-then-concat path below (same output, old memory profile).
        if (_ok_results
                and split_plan.merge_strategy == "union"
                and all(r.table_path for r in _ok_results)):
            try:
                merged = _stream_union_merge(_ok_results, _corr_id)
            except Exception as _stream_exc:
                logger.error(
                    "[multi-worker] streaming union merge failed (%s) — "
                    "falling back to legacy in-memory concat", _stream_exc,
                )
                merged = None

        if merged is None:
            # Legacy path: materialise every partial in RAM, then merge.
            # Spool-backed partials (only reachable here when the
            # streaming merge failed) are reloaded from disk — identical
            # to the pre-streaming behaviour.
            partials: List[pa.Table] = []
            _reload_error: Optional[Exception] = None
            try:
                # load_partial_table sniffs the spool format by magic
                # bytes: parquet (subprocess COPY) or Arrow IPC (thread
                # streaming, 2026-07-31) — both fully materialised, which
                # IS the legacy memory profile.
                from core.result_merger import load_partial_table
                for r in _ok_results:
                    if r.table is not None:
                        partials.append(r.table)
                    elif r.table_path:
                        partials.append(load_partial_table(r.table_path))
            except Exception as _re:
                _reload_error = _re
            if _reload_error is not None:
                # A spooled partial could not be reloaded — retrying the
                # merge with a PARTIAL list would silently drop rows, so
                # signal fallback to single-worker instead.
                logger.error(
                    "[multi-worker] partial reload failed (%s) — signalling "
                    "fallback to caller", _reload_error,
                )
                return _merge_fell_back_outcome(
                    f"partial reload failed: {_reload_error}")
            if not partials:
                merged = pa.table({})
            else:
                try:
                    merged = merge_partial_results(
                        partials,
                        split_plan.merge_strategy,
                        split_plan.merge_metadata,
                        final_sql,
                    )
                except Exception as merge_exc:
                    # For UNION, concat is the same operation — safe to retry.
                    # For sum_count_avg / group_by_rollup, concat would PRODUCE
                    # WRONG RESULTS (N rows instead of 1 aggregated row, or
                    # duplicate groups).  Convert merge failure into a worker
                    # failure so the caller falls back to single-worker rather
                    # than silently returning corrupt aggregates.
                    if split_plan.merge_strategy == "union":
                        logger.warning("[multi-worker] union merge raised (%s) — retrying",
                                        merge_exc)
                        merged = merge_partial_results(partials, "union", {}, final_sql)
                    else:
                        logger.error("[multi-worker] %s merge failed (%s) — signalling "
                                      "fallback to caller (concat would corrupt aggregates)",
                                      split_plan.merge_strategy, merge_exc)
                        return _merge_fell_back_outcome(
                            f"merge ({split_plan.merge_strategy}) raised: {merge_exc}")
    finally:
        # Reclaim spooled partial temp dirs on EVERY exit — merge done,
        # merge fell back, or raised.  The merged mmap table (if any) has
        # its OWN spool file with its own lifecycle; partials are no
        # longer needed once this section exits.
        _cleanup_spooled_partials(results)
        # Undo the QS_DUCKDB_CONCURRENT_CHILDREN stamp (see the fan-out site).
        # All workers have finished by here, so no child can still need it.
        _restore_kids_env()

    total_elapsed = time.monotonic() - t_start
    logger.info(
        "[multi-worker] complete: %d/%d workers ok, %d rows, %.1fs total "
        "(merge_strategy=%s)",
        succeeded, total_count, merged.num_rows, total_elapsed,
        split_plan.merge_strategy,
    )

    final = MultiWorkerOutcome(
        table=merged,
        worker_count=n_workers,
        succeeded=succeeded,
        failed=failed,
        total_elapsed_s=total_elapsed,
        fell_back=False,
        per_worker=results,
        merge_strategy=split_plan.merge_strategy,
    )
    # 2026-06-03 — pass correlation_id + slim per-worker summary into the
    # history so the per-query diagnostic can correlate this dispatch
    # with the engine_router decision by execution_id (= _corr_id on the
    # standard single-table multi-worker path).  Slim shape only — no
    # Arrow tables in history.
    _pw_summary = [{
        "chunk_index": w.chunk_index,
        "files_count": len(w.files or []),
        "elapsed_s":   round(w.elapsed_s, 3),
        "ok":          w.ok,
        "row_count":   w.row_count,
        "error":       (w.error or "")[:200],
    } for w in results]
    _record_outcome(final, raised=False,
                    correlation_id=_corr_id,
                    per_worker_summary=_pw_summary)
    return final


# ─────────────────────────────────────────────────────────────────────────────
# Thread-mode worker (in-process DuckDB)
# ─────────────────────────────────────────────────────────────────────────────


_LOAD_HTTPFS_RE = re.compile(r"\bLOAD\s+'?httpfs'?", re.IGNORECASE)


def _apply_worker_transport(con, wtag: str, setup_sql: str, partial_sql: str,
                            *, share: int = 1) -> None:
    """2026-10-06 -- the S3 transport policy and the remote-I/O concurrency
    for a THREAD-mode worker, applied right after its setup SQL's
    ``LOAD httpfs`` (the settings do not exist before it) and BEFORE its
    CREATE VIEWs bind (binding a ``union_by_name`` view opens every file's
    footer -- measured live: 50 s for one 682-file MoR view).

    Both were missing here.  ``apply_s3_http_transport`` ran in the
    subprocess child and federation only, so a worker opened ~2 TCP+TLS
    connections per file (2-3 round trips each against AWS) -- and its
    ``threads`` was CPU-sized (2 on the rig), i.e. two files in flight.
    Fail-open: a worker that cannot apply either still runs, as before.
    """
    try:
        from core.s3_http_transport import (
            apply_remote_io_concurrency, apply_s3_http_transport,
            remote_file_uris,
        )
        _label = (wtag or "").strip("[]")
        apply_s3_http_transport(con, label=_label)
        _uris = remote_file_uris(setup_sql, partial_sql)
        try:
            from core.measured_file_bytes import bytes_for_uris
            _mb = bytes_for_uris(_uris)
        except Exception:
            _mb = None
        apply_remote_io_concurrency(
            con, remote_files=len(_uris),
            share=max(1, int(share or 1)), label=_label, measured=_mb)
    except Exception as exc:                          # noqa: BLE001
        logger.warning("%s s3 transport / I/O concurrency not applied "
                       "(fail-open): %s", wtag, exc)


def _subprocess_worker_threads(cpu_value, duckdb_settings, setup_sql: str,
                               partial_sql: str, *, share: int = 1):
    """2026-10-06 -- the ``SET threads`` a SUBPROCESS-mode worker's setup
    SQL carries.  That SET runs inside the child's setup, AFTER the child's
    own remote-I/O raise, so a CPU-sized value here would undo it; the same
    decision (``core.s3_http_transport.remote_io_threads``) is made here,
    over this chunk's remote files, its share of the query budget and its
    memory_limit.  Fail-open: any error returns the CPU value."""
    try:
        from core.s3_http_transport import remote_file_uris, remote_io_threads
        from core.duckdb_resource_limits import parse_memory_limit_to_bytes
        _uris = remote_file_uris(setup_sql, partial_sql)
        _mem = 0
        try:
            _mem = int(parse_memory_limit_to_bytes(
                str((duckdb_settings or {}).get("memory_limit") or "")) or 0)
        except Exception:
            _mem = 0
        _avg = None
        try:
            from core.measured_file_bytes import bytes_for_uris
            _mb = bytes_for_uris(_uris)
            _avg = (_mb.known_bytes // _mb.known_files) if _mb.known_files else None
        except Exception:
            _avg = None
        return str(remote_io_threads(
            cpu_threads=int(cpu_value), remote_files=len(_uris),
            share=max(1, int(share or 1)), memory_limit_bytes=_mem,
            avg_file_bytes=_avg))
    except Exception:
        return cpu_value


def _run_chunk_thread(
    chunk: FileChunk,
    partial_sql: str,
    setup_sql: str,
    timeout_s: int,
    cancel_event: Optional[threading.Event],
    duckdb_settings: Dict[str, str],
    correlation_id: str = "",
    spool_partial: bool = False,
    concurrent_children: int = 0,   # BF-558d: accepted for signature parity
                                    # with _run_chunk_subprocess; thread mode
                                    # spawns no child, so it is unused here.
) -> WorkerResult:
    """Run a single chunk in a fresh in-process DuckDB connection.

    2026-07-31 (risk-1 close) — ``spool_partial=True`` (UNION strategy):
    the partial is STREAMED from the DuckDB cursor into a lossless Arrow
    IPC spool file (``_spool_thread_partial_ipc``) instead of being
    materialised whole via ``.to_arrow_table()``.  Thread mode is the
    DEFAULT executor_mode, so pre-fix the coordinator still held the
    ENTIRE result in RAM (N × full partial + concat) on the default
    path.  Arrow IPC — never COPY-to-parquet — because IPC round-trips
    the in-process Arrow types EXACTLY (DuckDB's parquet writer is lossy,
    e.g. HUGEINT → DOUBLE — see query_splitter's hugeint_restore
    machinery); type parity is proven in
    tests/test_merge_streaming_2026_07_31.py.  Spool-side I/O failures
    fall back LOUDLY (in-worker) to the legacy materialisation."""
    t0 = time.monotonic()

    # Phase K (2026-06-08) -- explicitly propagate execution_id into
    # this worker thread so iceberg_reader's record_pruning can fire.
    # Pre-Phase-K, threading.local in query_diagnostic_store didn't
    # inherit across ThreadPoolExecutor.submit, so deep modules called
    # from this worker saw execution_id=None and the recorder silently
    # no-op'd.  Phase K replaced threading.local with ContextVar, but
    # ThreadPoolExecutor still doesn't auto-propagate ContextVar across
    # OS threads -- we set it explicitly here.
    if correlation_id:
        try:
            from core.query_diagnostic_store import set_current_execution_id
            set_current_execution_id(correlation_id)
        except Exception:
            pass

    # BF-405: live progress tracking for admin UI
    _set_worker_state(correlation_id, chunk.chunk_index,
                       "starting", files_count=len(chunk.files))

    if cancel_event is not None and cancel_event.is_set():
        _set_worker_state(correlation_id, chunk.chunk_index,
                           "cancelled", error="cancelled before start")
        return WorkerResult(
            chunk_index=chunk.chunk_index,
            files=chunk.files,
            error="cancelled before start",
            elapsed_s=0.0,
            cancel_source="before_start",
        )

    try:
        import duckdb
        from core.duckdb_factory import get_connection
    except Exception:
        # Fallback if factory unavailable for some reason
        import duckdb
        get_connection = None

    con = None
    # BF-599d (2026-05-30): heartbeat thread for live worker visibility.
    # Samples THIS worker's Python frame every 5s and writes the top
    # user-relevant frame into the worker's state as ``running_detail``.
    # That ends the "state=running, no detail for 30 min" black box the
    # user hit on 758-file chunks — admins now see "iceberg_reader.py:412
    # _S3_CALL_POOL.submit" continuously updating, so a wedge is obvious.
    # Daemon thread — dies with the process; stopped + joined in finally.
    _hb_stop = threading.Event()
    _hb_thread: Optional[threading.Thread] = None
    # Watcher thread: when cancel_event fires mid-query, call con.interrupt()
    # so the blocking ``con.execute()`` aborts immediately instead of running
    # to completion.  Without this, cancel only takes effect between chunks.
    _watcher_stop = threading.Event()
    _watcher_thread: Optional[threading.Thread] = None

    def _cancel_watcher():
        """Poll cancel_event every 250ms.  When set:
          1. Call ``con.interrupt()`` — best-effort, only fires at
             DuckDB scheduler checkpoints (no help mid-libcurl-recv).
          2. **BF-588 (2026-05-29)**: ALSO call ``con.close()`` — closes
             the underlying connection, which kills the libcurl socket
             via OS-level fd close.  This is the ONLY thing that
             actually unblocks a worker stuck in a non-interruptible
             ``recv()`` on a cold S3 footer fetch.

        The order matters: interrupt() first (clean abort if DuckDB is
        between operations), then close() (forceful) if interrupt
        didn't return control within ~100ms (we approximate by NOT
        waiting and trusting the next poll iteration).
        """
        while not _watcher_stop.wait(0.25):
            if cancel_event is not None and cancel_event.is_set():
                _local_con = con  # snapshot under closure
                if _local_con is not None:
                    try:
                        _local_con.interrupt()
                        logger.info(
                            "[multi-worker] worker %d interrupted by cancel_event",
                            chunk.chunk_index,
                        )
                    except Exception as _intr_err:
                        logger.debug(
                            "[multi-worker] worker %d interrupt() failed: %s",
                            chunk.chunk_index, _intr_err,
                        )
                    # BF-588: forceful close kills the libcurl socket
                    # that interrupt() can't reach.  Worker thread
                    # then sees a closed-connection error and exits
                    # the try/except.
                    try:
                        _local_con.close()
                        logger.info(
                            "[multi-worker] worker %d connection closed "
                            "(BF-588 forceful kill)",
                            chunk.chunk_index,
                        )
                    except Exception as _close_err:
                        logger.debug(
                            "[multi-worker] worker %d close() failed: %s",
                            chunk.chunk_index, _close_err,
                        )
                return

    try:
        # BF-599 (2026-05-30): per-stage timing so admins can see EXACTLY
        # where a worker is wedged.  All log lines tagged
        # [mw-w{N}] for easy grep + filter in the per-query log file.
        _wtag = f"[mw-w{chunk.chunk_index}]"
        _t_conn0 = time.monotonic()
        if get_connection is not None:
            con = get_connection(database=":memory:")
        else:
            con = duckdb.connect(database=":memory:")
        _t_conn = time.monotonic() - _t_conn0
        logger.info("%s connection acquired in %.2fs (files=%d)",
                    _wtag, _t_conn, len(chunk.files))

        _t_pragma0 = time.monotonic()
        _pragma_count = 0
        for k, v in (duckdb_settings or {}).items():
            try:
                con.execute(f"SET {k}={_quote_setting_value(v)};")
                _pragma_count += 1
            except Exception as set_exc:
                logger.debug("[multi-worker] worker %d ignored SET %s: %s",
                             chunk.chunk_index, k, set_exc)
        logger.info("%s pragmas applied (%d) in %.2fs",
                    _wtag, _pragma_count, time.monotonic() - _t_pragma0)

        # BF-599d (2026-05-30): start heartbeat sampler BEFORE setup.
        # The heartbeat reads our OWN thread id (the worker thread —
        # this code runs IN that thread), then samples it from a
        # daemon side thread every 5s.  Pushes top user-relevant
        # frame as ``running_detail``.  Always-on — overhead is one
        # GIL-protected dict read every 5s.
        _worker_tid = threading.get_ident()
        _hb_started_at = t0  # for elapsed bumps in setup phase

        def _heartbeat_loop():
            """Sample the worker thread every 5s; update running_detail.

            BF-599g (2026-05-31): self-bail when the canonical state
            becomes terminal.  Without this, a heartbeat tick scheduled
            5s in the future could fire AFTER the main thread writes
            "completed", re-broadcasting a stale running_detail and
            confusing the UI ("worker shows running 5s after done").
            Reads the live state dict under lock; if state is in
            terminal set, exit the loop immediately.
            """
            _last_detail = ""
            _last_change_at = time.monotonic()
            _key = f"{correlation_id or 'unknown'}:{chunk.chunk_index}"
            _TERMINAL = ("completed", "failed", "cancelled")
            while not _hb_stop.wait(5.0):
                # BF-599g: self-bail on terminal state — covers the gap
                # between "main thread writes completed" and "finally
                # block sets _hb_stop".  Snapshot read of _ACTIVE_WORKERS
                # under lock is GIL-cheap.
                with _ACTIVE_LOCK:
                    _live_state = (_ACTIVE_WORKERS.get(_key) or {}).get("state")
                if _live_state in _TERMINAL:
                    return
                try:
                    detail = _summarise_stack_frame(_worker_tid)
                    now = time.monotonic()
                    elapsed = now - _hb_started_at
                    # Track how long the same frame has been on top —
                    # surfacing a "stuck_for=N.Ns" signal helps the UI
                    # highlight workers that are genuinely wedged vs
                    # actively progressing through stack frames.
                    if detail != _last_detail:
                        _last_detail = detail
                        _last_change_at = now
                    stuck_s = now - _last_change_at
                    _set_worker_state(
                        correlation_id, chunk.chunk_index, None,
                        running_detail=detail,
                        elapsed_s=round(elapsed, 1),
                        stuck_s=round(stuck_s, 1),
                    )
                    # If the frame hasn't changed in >60s, log a WARN so
                    # the per-query log captures the suspected wedge.
                    # BF-599g: throttled to "first time crosses 60s" +
                    # "every 60s after that" instead of buggy modulo —
                    # round-1 audit caught off-by-rounding bug.
                    if stuck_s >= 60.0:
                        _bucket = int(stuck_s) // 60
                        if _bucket != getattr(_heartbeat_loop, "_warned_bucket", -1):
                            logger.warning(
                                "[mw-w%d] heartbeat: SAME frame for %.1fs — %s",
                                chunk.chunk_index, stuck_s, detail,
                            )
                            _flush_handlers(logger)
                            _heartbeat_loop._warned_bucket = _bucket  # type: ignore[attr-defined]
                except BaseException as _hb_err:
                    # BF-599g: catch BaseException so KeyboardInterrupt /
                    # SystemExit inside _summarise_stack_frame don't kill
                    # the daemon thread silently mid-query.
                    logger.debug(
                        "[mw-w%d] heartbeat sample failed: %s",
                        chunk.chunk_index, _hb_err,
                    )

        _hb_thread = threading.Thread(
            target=_heartbeat_loop,
            name=f"mw-hb-{chunk.chunk_index}",
            daemon=True,
        )
        _hb_thread.start()

        # BF-588 (2026-05-29): start the cancel watcher BEFORE the
        # setup_sql loop.  Audit found setup-phase was uncancellable
        # — if all N workers had cold-S3 footers to fetch during
        # setup, NONE of them could be interrupted, and the user's
        # 30-min hang resulted.  Watcher must be live from the
        # moment we have a connection so any cancel during setup
        # propagates immediately.
        if cancel_event is not None:
            _watcher_thread = threading.Thread(
                target=_cancel_watcher,
                name=f"mw-cancel-watch-{chunk.chunk_index}",
                daemon=True,
            )
            _watcher_thread.start()

        # Execute the setup SQL — registers tables / creates views for this
        # chunk's slice of the file list.  (Watcher already running.)
        # BF-599: per-statement timing + state.  setup_sql for a 758-file
        # chunk has ~3-5 statements; the CREATE VIEW with hive_partitioning=true
        # triggers a footer fetch per file (= ~758 S3 HEAD/GET range calls)
        # which on Windows + cold cache can take 15-50 minutes.
        # Live state ``setup_step`` / ``setup_total`` lets the admin UI
        # (and the new /api/executions/{id}/workers endpoint) show
        # "registering view 3/5" instead of opaque "setup".
        _set_worker_state(correlation_id, chunk.chunk_index, "setup")
        if setup_sql:
            _setup_stmts = [s.strip() for s in setup_sql.split(";\n") if s.strip()]
            _setup_total = len(_setup_stmts)
            _set_worker_state(correlation_id, chunk.chunk_index,
                              "setup", setup_step=0, setup_total=_setup_total)
            _t_setup0 = time.monotonic()
            for _idx, stmt in enumerate(_setup_stmts, 1):
                # First 80 chars of statement so the log is grep-able.
                _stmt_preview = stmt.replace("\n", " ")[:80]
                _t_stmt0 = time.monotonic()
                logger.info(
                    "%s setup_sql stmt %d/%d STARTING: %s%s",
                    _wtag, _idx, _setup_total, _stmt_preview,
                    "..." if len(stmt) > 80 else "",
                )
                # BF-599 (2026-05-30): FLUSH EVERY HANDLER before the
                # con.execute() call.  DuckDB's httpfs extension can
                # segfault on cold-S3 Windows cold-cache → Python
                # process exits with no traceback → the last "STARTING"
                # log line would be lost in buffered stdout/file handles.
                # Flushing here guarantees the wedge point survives even
                # a C-level crash.
                _flush_handlers(logger)
                _set_worker_state(
                    correlation_id, chunk.chunk_index, "setup",
                    setup_step=_idx, setup_total=_setup_total,
                    setup_current=_stmt_preview,
                )
                con.execute(stmt)
                _stmt_elapsed = time.monotonic() - _t_stmt0
                logger.info(
                    "%s setup_sql stmt %d/%d done in %.2fs",
                    _wtag, _idx, _setup_total, _stmt_elapsed,
                )
                _flush_handlers(logger)
                if _LOAD_HTTPFS_RE.search(stmt):
                    _apply_worker_transport(
                        con, _wtag, setup_sql, partial_sql,
                        share=concurrent_children)
            logger.info(
                "%s setup_sql complete (%d stmts, %.2fs total)",
                _wtag, _setup_total, time.monotonic() - _t_setup0,
            )

        # NOTE 2026-06-23: protection against httpfs double-signing
        # presigned URLs in setup_sql is enforced UPSTREAM at the
        # dispatcher (multi_worker_dispatcher._duckdb_settings_from_
        # conn_config consults the planner and omits s3_endpoint +
        # credentials when presigned URLs are detected).  No worker-
        # side reset is required.  See core.duckdb_s3_plan.

        # ── Width-aware memory/threads (2026-08-02, defect 1) ────────────
        # Thread-mode twin of the subprocess child's adjustment (see
        # duckdb_subprocess._child_main).  MEASURED: at the 256MB
        # high-concurrency floor a 900-column partial raises
        # OutOfMemoryException instead of spilling — per-thread column
        # buffers are unspillable, so a wide query needs fewer threads
        # or (when even 1 thread can't fit) a bounded memory escalation
        # to the width floor.  This is doubly important in thread mode:
        # pre-fix these in-process connections got NO threads value at
        # all and defaulted to the HOST core count.  LIMIT-0 probe =
        # planning only.  current_setting = ground truth after the
        # settings loop.  FAIL-OPEN: any error changes nothing, and
        # narrow (<=130 col) partials return (None, None) so the common
        # case is byte-identical.
        from core.duckdb_resource_limits import apply_width_aware_limits
        apply_width_aware_limits(con, partial_sql, tag=_wtag)

        # Final partial SQL → Arrow
        _t_exec0 = time.monotonic()
        logger.info("%s partial_sql STARTING (%d files)",
                    _wtag, len(chunk.files))
        _flush_handlers(logger)  # BF-599: preserve wedge point on C-level crash
        _set_worker_state(correlation_id, chunk.chunk_index, "running")
        _cur = con.execute(partial_sql)
        _exec_elapsed = time.monotonic() - _t_exec0
        logger.info("%s partial_sql executed in %.2fs (fetching Arrow now)",
                    _wtag, _exec_elapsed)

        if spool_partial:
            # 2026-07-31 risk-1 close: stream the partial into a lossless
            # Arrow IPC spool so the coordinator can stream-merge with
            # O(one batch) memory instead of holding every thread partial
            # in-process at once.  Query errors / cancel interrupts raise
            # out of the helper into the existing except handling below —
            # identical to what .to_arrow_table() raised.
            _spooled = _spool_thread_partial_ipc(
                _cur, chunk, t0, correlation_id, _wtag)
            if _spooled is not None:
                return _spooled
            # Spool-side I/O failure only (helper already logged it).
            # LOUD fallback: the cursor was partially consumed by the
            # failed spool attempt and DuckDB cursors cannot rewind, so
            # re-execute and materialise in memory — legacy behaviour,
            # legacy memory profile.
            logger.warning("%s re-executing partial_sql for legacy "
                           "in-memory materialisation", _wtag)
            _t_exec0 = time.monotonic()
            _cur = con.execute(partial_sql)
            _exec_elapsed = time.monotonic() - _t_exec0

        # Prefer the non-deprecated to_arrow_table() (DuckDB >= 1.x); fall
        # back to fetch_arrow_table() for older versions.
        _t_fetch0 = time.monotonic()
        if hasattr(_cur, "to_arrow_table"):
            arrow = _cur.to_arrow_table()
        else:
            arrow = _cur.fetch_arrow_table()
        elapsed = time.monotonic() - t0
        logger.info(
            "%s COMPLETED — rows=%d, exec=%.2fs, fetch=%.2fs, total=%.2fs",
            _wtag, arrow.num_rows, _exec_elapsed,
            time.monotonic() - _t_fetch0, elapsed,
        )
        _set_worker_state(correlation_id, chunk.chunk_index,
                           "completed", rows=arrow.num_rows, elapsed_s=round(elapsed, 2))
        return WorkerResult(
            chunk_index=chunk.chunk_index,
            files=chunk.files,
            table=arrow,
            elapsed_s=elapsed,
            row_count=arrow.num_rows,
        )
    except Exception as exc:
        elapsed = time.monotonic() - t0
        # 149.0 (2026-06-09): ALWAYS preserve the underlying exception.
        # Pre-fix we relabelled every race-exception to "cancelled
        # mid-query" which discarded the real cause — admins saw N
        # workers all reporting "cancelled" with no hint that the
        # actual trigger was a TaskTimeout / ConnectionException /
        # InterruptException etc.
        _orig_type = type(exc).__name__
        _orig_msg = str(exc)[:400]
        if cancel_event is not None and cancel_event.is_set():
            # cancelled — preserve the underlying exception in the
            # message so the dispatcher can surface it.  We still log
            # at warning so the per-query log file has the cause.
            err_msg = f"cancelled mid-query (underlying: {_orig_type}: {_orig_msg})"[:500]
            logger.warning(
                "[mw-w%d] cancelled mid-query — underlying exception: %s: %s",
                chunk.chunk_index, _orig_type, _orig_msg,
            )
            _set_worker_state(correlation_id, chunk.chunk_index,
                               "cancelled", error=err_msg, elapsed_s=round(elapsed, 2))
            _cs = "external_cancel"
        else:
            # 2026-09-26: an INTERRUPT with no cancel requested is a QUERY
            # error DuckDB raised on one of its own worker threads and
            # relabelled (core.duckdb_cancel.is_masked_worker_error has the
            # mechanism).  Left as-is it reads "somebody cancelled me" in
            # the fallback_reason and sends the operator to the cancel
            # path instead of their data.  Name the class; the real message
            # surfaces on the single-engine run the dispatcher falls back to.
            from core.duckdb_cancel import (
                MASKED_WORKER_ERROR_NOTE,
                is_masked_worker_error,
            )
            if is_masked_worker_error(exc, cancel_requested=False):
                _orig_msg = f"{_orig_msg} ({MASKED_WORKER_ERROR_NOTE})"[:400]
                logger.warning(
                    "[mw-w%d] %s: %s", chunk.chunk_index, _orig_type, _orig_msg)
            err_msg = f"{_orig_type}: {_orig_msg}"[:500]
            _set_worker_state(correlation_id, chunk.chunk_index,
                               "failed", error=err_msg, elapsed_s=round(elapsed, 2))
            _cs = ""
        return WorkerResult(
            chunk_index=chunk.chunk_index,
            files=chunk.files,
            error=err_msg,
            elapsed_s=elapsed,
            cancel_source=_cs,
            original_exc_type=_orig_type,
            original_exc_msg=_orig_msg,
        )
    finally:
        # BF-599g (2026-05-31): cleanup ordering matters.  Set BOTH
        # stop-flags FIRST (atomic signal — no thread can be in the
        # middle of a new iteration after this point), THEN join both
        # threads (Event.wait() returns immediately when set), THEN
        # close the connection (so neither thread can race con.close()
        # against an in-flight con.interrupt() or stack sample).
        # Pre-fix: heartbeat could push a stale state AFTER main thread
        # wrote terminal state; watcher could call con.interrupt() on
        # an already-closed handle.
        _hb_stop.set()
        _watcher_stop.set()
        if _hb_thread is not None:
            try:
                _hb_thread.join(timeout=1.0)
            except Exception as _hb_join_err:
                logger.debug(
                    "[multi-worker] heartbeat join failed for worker %d: %s",
                    chunk.chunk_index, _hb_join_err,
                )
        if _watcher_thread is not None:
            try:
                _watcher_thread.join(timeout=1.0)
            except Exception as _join_err:
                logger.debug(
                    "[multi-worker] watcher join failed for worker %d: %s",
                    chunk.chunk_index, _join_err,
                )
        if con is not None:
            try:
                con.close()
            except Exception as _close_err:
                logger.debug("[multi-worker] DuckDB con.close() raised: %s", _close_err)


# ─────────────────────────────────────────────────────────────────────────────
# Subprocess-mode worker (crash-isolated DuckDB)
# ─────────────────────────────────────────────────────────────────────────────


def _run_chunk_subprocess(
    chunk: FileChunk,
    partial_sql: str,
    setup_sql: str,
    timeout_s: int,
    cancel_event: Optional[threading.Event],
    duckdb_settings: Dict[str, str],
    correlation_id: str = "",
    spool_partial: bool = False,
    concurrent_children: int = 0,
) -> WorkerResult:
    """Run a chunk in a child DuckDB process — survives C-level crashes.

    Uses the existing ``duckdb_subprocess`` framework: writes a partial
    parquet to a temp path, then reads it back as Arrow.

    BF-599e (2026-05-30): publishes the same _set_worker_state lifecycle
    as the thread-mode runner so subprocess-mode workers are visible in
    BQB / CQB / admin UI.  Coordinator-side heartbeat samples its OWN
    thread (which is blocked waiting on the subprocess) and surfaces
    ``in subprocess — elapsed Ns`` so the UI doesn't look frozen.  Per-
    worker memory_limit + temp_directory are prepended to setup_sql so
    the subprocess honours them WITHOUT changing duckdb_subprocess's
    signature.

    2026-07-31 — ``spool_partial=True`` (UNION strategy only): the partial
    parquet is NOT loaded into coordinator RAM.  The row count is read
    from the parquet footer (O(KB)) and ``WorkerResult.table_path`` hands
    the on-disk file to the coordinator's streaming merge, which deletes
    the temp dir when done.  Pre-fix, ``pq.read_table(out_path)`` here
    materialised every worker's full partial simultaneously — O(result)
    coordinator memory for plain SELECTs.
    """
    t0 = time.monotonic()
    # When True, the finally block must NOT delete out_dir — ownership of
    # the spooled partial transfers to the coordinator's merge/cleanup.
    _keep_out_dir = False
    # BF-599e: lifecycle event — visible in admin grid + BQB/CQB per-
    # execution panel as soon as the worker is picked up by the pool.
    _set_worker_state(correlation_id, chunk.chunk_index,
                       "starting", files_count=len(chunk.files),
                       executor_mode="subprocess")
    if cancel_event is not None and cancel_event.is_set():
        _set_worker_state(correlation_id, chunk.chunk_index,
                           "cancelled", error="cancelled before start")
        return WorkerResult(
            chunk_index=chunk.chunk_index,
            files=chunk.files,
            error="cancelled before start",
            elapsed_s=0.0,
            cancel_source="before_start",
        )

    # Build a COPY TO statement — subprocess writes to a temp parquet
    # then coordinator reads it back as Arrow.
    out_dir = tempfile.mkdtemp(prefix=f"qs-mw-chunk-{chunk.chunk_index}-")
    out_path = os.path.join(out_dir, "partial.parquet")
    # BF-599e (2026-05-30): coordinator-side heartbeat for subprocess
    # mode.  Can't sample the subprocess's Python stack across the
    # process boundary, but bumping elapsed_s + a generic
    # ``in subprocess`` running_detail every 5s keeps the UI alive
    # and lets the user tell "wedged" from "completed-already" at a
    # glance.  Daemon thread, stopped + joined in finally.
    _hb_stop = threading.Event()

    def _subprocess_heartbeat():
        """BF-599g (round-3 audit): mirror thread-mode self-bail on
        terminal state so a delayed tick doesn't push a stale
        "in subprocess" message AFTER terminal state was written."""
        _key = f"{correlation_id or 'unknown'}:{chunk.chunk_index}"
        _TERMINAL = ("completed", "failed", "cancelled")
        while not _hb_stop.wait(5.0):
            with _ACTIVE_LOCK:
                _live_state = (_ACTIVE_WORKERS.get(_key) or {}).get("state")
            if _live_state in _TERMINAL:
                return
            try:
                elapsed_now = time.monotonic() - t0
                _set_worker_state(
                    correlation_id, chunk.chunk_index, None,
                    running_detail="in subprocess (executor_mode=subprocess) — "
                                   "awaiting partial.parquet write",
                    elapsed_s=round(elapsed_now, 1),
                )
            except Exception as _sp_hb_err:
                logger.debug(
                    "[mw-w%d] subprocess heartbeat tick failed: %s",
                    chunk.chunk_index, _sp_hb_err,
                )

    _hb_thread = threading.Thread(
        target=_subprocess_heartbeat,
        name=f"mw-sp-hb-{chunk.chunk_index}",
        daemon=True,
    )
    _hb_thread.start()
    try:
        from core.path_utils import to_duckdb_path as _to_ddb_path
        # NOTE (2026-07-31 risk-2 audit): the ABSENCE of ROW_GROUP_SIZE
        # here is deliberate, not an oversight.  The width cannot be known
        # until the chunk's views exist, and only the child has that live
        # connection — duckdb_subprocess._child_main (reached by BOTH the
        # legacy Popen path and the warm-pool path of run_duckdb_copy_to)
        # probes the width AFTER setup_sql runs and injects a width-aware
        # ROW_GROUP_SIZE via _inner_query_from_copy / _probe_column_count /
        # _inject_copy_option (trailing-';'-tolerant since the F1 audit
        # fix).  Wide partials therefore do NOT buffer DuckDB's default
        # 122,880-row row groups (~1-3 GB per worker at 900 cols); narrow
        # (<=130 col) partials get NO clause and keep byte-identical
        # default output.  Do not add a ROW_GROUP_SIZE here — a parent-
        # side probe would have to re-run setup_sql (repeating every S3
        # footer fetch) just to learn the width the child already knows.
        copy_sql = (
            f"COPY ({partial_sql}) TO '{_to_ddb_path(out_path)}' "
            f"(FORMAT 'parquet', COMPRESSION 'zstd');"
        )

        # BF-599e (2026-05-30): thread the per-worker memory budget
        # through to the subprocess.  duckdb_subprocess's signature
        # is fixed (conn_config + setup_sql + copy_sql), so prepend
        # SET statements to setup_sql instead of modifying the call
        # contract.  Filters to settings the subprocess will accept
        # via raw SET (memory_limit, temp_directory, threads).
        _ds_prefix_parts = []
        for _k in ("memory_limit", "temp_directory", "threads"):
            _v = (duckdb_settings or {}).get(_k)
            if _v is None or _v == "":
                continue
            if _k == "threads":
                _v = _subprocess_worker_threads(
                    _v, duckdb_settings, setup_sql, partial_sql,
                    share=concurrent_children)
            _ds_prefix_parts.append(f"SET {_k}={_quote_setting_value(_v)};")
        if _ds_prefix_parts:
            setup_sql = "\n".join(_ds_prefix_parts) + "\n" + (setup_sql or "")
            logger.debug(
                "[mw-w%d] subprocess: prepended %d duckdb_settings to setup_sql",
                chunk.chunk_index, len(_ds_prefix_parts),
            )

        # BF-599e: transition to "running" once setup is finalised —
        # next state change comes from the heartbeat (elapsed bump)
        # or from completed/failed below.
        _set_worker_state(correlation_id, chunk.chunk_index, "running")

        from core.duckdb_subprocess import run_duckdb_copy_to
        # Caller-provided setup SQL is opaque to the subprocess wrapper —
        # we pass empty conn_config + registered_tables and rely on the
        # setup_sql to carry all view-creation DDL.  The wrapper still
        # applies proxy / S3 creds from env if needed.
        run_duckdb_copy_to(
            conn_config={},
            registered_tables=[],
            bucket="",
            setup_sql=setup_sql,
            copy_sql=copy_sql,
            output_path=out_path,
            connection_id=None,
            timeout=timeout_s,
            execution_id=None,
            cancel_event=cancel_event,
            concurrent_children=concurrent_children,
        )

        if spool_partial:
            # Streaming-union path: leave the partial ON DISK.  Row count
            # comes from the parquet footer — O(KB) read, not O(partial).
            _pf = pq.ParquetFile(out_path)
            try:
                _n_rows = int(_pf.metadata.num_rows)
            finally:
                _pf.close()
            elapsed = time.monotonic() - t0
            _set_worker_state(correlation_id, chunk.chunk_index,
                               "completed", rows=_n_rows,
                               elapsed_s=round(elapsed, 2))
            _keep_out_dir = True
            return WorkerResult(
                chunk_index=chunk.chunk_index,
                files=chunk.files,
                table=None,
                table_path=out_path,
                elapsed_s=elapsed,
                row_count=_n_rows,
            )

        table = pq.read_table(out_path)
        elapsed = time.monotonic() - t0
        _set_worker_state(correlation_id, chunk.chunk_index,
                           "completed", rows=table.num_rows,
                           elapsed_s=round(elapsed, 2))
        return WorkerResult(
            chunk_index=chunk.chunk_index,
            files=chunk.files,
            table=table,
            elapsed_s=elapsed,
            row_count=table.num_rows,
        )
    except Exception as exc:
        elapsed = time.monotonic() - t0
        # 149.0 (2026-06-09): preserve original exception (same fix as
        # _run_chunk_thread).  Subprocess mode lost the cause too —
        # admins saw "cancelled mid-query" with no hint that the actual
        # trigger was a SubprocessTimeoutError / DuckDBSegfault / etc.
        _orig_type = type(exc).__name__
        _orig_msg = str(exc)[:400]
        if cancel_event is not None and cancel_event.is_set():
            err_msg = f"cancelled mid-query (underlying: {_orig_type}: {_orig_msg})"[:500]
            logger.warning(
                "[mw-w%d subprocess] cancelled mid-query — underlying exception: %s: %s",
                chunk.chunk_index, _orig_type, _orig_msg,
            )
            _set_worker_state(correlation_id, chunk.chunk_index,
                               "cancelled", error=err_msg,
                               elapsed_s=round(elapsed, 2))
            _cs = "external_cancel"
        else:
            err_msg = f"{_orig_type}: {_orig_msg}"[:500]
            _set_worker_state(correlation_id, chunk.chunk_index,
                               "failed", error=err_msg,
                               elapsed_s=round(elapsed, 2))
            _cs = ""
        return WorkerResult(
            chunk_index=chunk.chunk_index,
            files=chunk.files,
            error=err_msg,
            elapsed_s=elapsed,
            cancel_source=_cs,
            original_exc_type=_orig_type,
            original_exc_msg=_orig_msg,
        )
    finally:
        # BF-599e: stop the coordinator heartbeat first so it doesn't
        # push a stale "in subprocess — elapsed Ns" AFTER terminal
        # state was written.  1s join is generous (wait(5s) returns
        # immediately on set()).
        _hb_stop.set()
        try:
            _hb_thread.join(timeout=1.0)
        except Exception as _hb_join_err:
            logger.debug(
                "[multi-worker] subprocess heartbeat join failed for worker %d: %s",
                chunk.chunk_index, _hb_join_err,
            )
        import shutil
        try:
            # 2026-07-31: on the spooled-success path the coordinator owns
            # the partial file now — _cleanup_spooled_partials reclaims it
            # after the streaming merge.  Every other exit (aggregate
            # strategies, errors, cancels) cleans up here as before.
            if not _keep_out_dir:
                shutil.rmtree(out_dir, ignore_errors=True)
        except Exception as _rm_err:
            logger.debug("[multi-worker] temp-dir cleanup failed: %s", _rm_err)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _quote_setting_value(v: Any) -> str:
    """Format value for DuckDB SET key=value.

    Numeric / bool → bare token.  Everything else → single-quoted with
    embedded quotes escaped.
    """
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    s = str(v).replace("'", "''")
    return f"'{s}'"
