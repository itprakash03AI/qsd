"""
Iceberg file cache, schema cache, and partition cache.

All three caches use L1 in-memory (short TTL) + optional L2 SQLite (long TTL).
Extracted from main.py for maintainability.

Usage:
    from core.iceberg_cache import init_iceberg_cache, ice_cache_get, ...
    init_iceberg_cache(db_manager)   # call once at startup
"""
from __future__ import annotations

import json as _json
import logging
import threading
import time
from datetime import datetime, timezone
from typing import Dict, Optional, Tuple

from core.config import partition_cache as _pcache_cfg

logger = logging.getLogger(__name__)

# ── Module-level db_manager (set via init_iceberg_cache) ─────────────────────
_db_manager = None


def init_iceberg_cache(db_manager):
    """Inject the database manager for L2 cache operations."""
    global _db_manager
    _db_manager = db_manager


def _l2_enabled() -> bool:
    """The L2 (DB) iceberg_file_cache is keyed per-CONNECTION
    (connection_id, table_name) — so the SAME physical (bucket, table_prefix)
    registered under two connections would NOT share it, and a bucket-only
    re-key would risk MIXING different tables in one bucket.  It is also
    REDUNDANT: the db-first per-file stats and the snapshot cache are already
    keyed by (bucket, table_prefix) — table-specific AND shared across
    connections — so the pruned survivor list is re-derived correctly and
    cheaply from those.  2026-07-22: default OFF to remove the per-connection
    fragmentation (and the mix-and-match risk) entirely.  L1 (per-pod, in-mem)
    is unaffected.  Operator can re-enable via iceberg.l2_file_cache_enabled."""
    try:
        from core.config import get as _cfg_get
        return bool(_cfg_get("iceberg", "l2_file_cache_enabled", False))
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════════════════════
# Iceberg data-file cache: L1 in-memory (5 min) + L2 SQLite (5 hours)
# Avoids re-scanning S3 manifests.  L2 survives server restarts.
# Key: (connection_id, table_name, filters_hash)  →  (active_files, metadata, ts)
# ══════════════════════════════════════════════════════════════════════════════

ICE_FILE_CACHE: Dict[tuple, dict] = {}
# 2026-08-20 — this L1 is written from worker-pool threads
# (core/duckdb_views.py `_exec_to_parquet`) yet, unlike its siblings
# `_schema_cache` / `_partition_cache`, it had NO lock: the two-phase
# eviction in ice_cache_set iterated `.items()` lazily while other threads
# inserted, raising "RuntimeError: dictionary changed size during iteration"
# and killing the storing query.  (invalidate_for_table's comment even noted
# "ICE_FILE_CACHE_LOCK never existed" — now it does.)  Every read/mutate of
# ICE_FILE_CACHE must hold this lock; L2 (SQLite) calls stay OUTSIDE it.
ICE_FILE_CACHE_LOCK = threading.Lock()
ICE_FILE_CACHE_TTL = 300       # L1: 5 minutes (in-memory hot cache)
ICE_FILE_CACHE_L2_TTL = 18000  # L2: 5 hours (persistent SQLite cache)


def ice_cache_key(connection_id, tname, partition_filters, or_groups=None,
                  snapshot=None):
    """The L1/L2 file-list key: (connection, table, AND filters, OR groups).

    2026-10-08: ``or_groups`` is PART of the key.  Keyed on the AND filters
    alone, an OR-of-AND-groups query (P13: no AND conjunct, two branches)
    keyed as the UNFILTERED table -- a cached whole-table list answered it
    (no pruning), and its UNION list was written under the unfiltered key,
    so the next unfiltered query would have read the union (row loss behind
    a 200).  ``filter_ops.or_groups_fingerprint`` spells the groups.
    """
    pf_str = _json.dumps(partition_filters, sort_keys=True, default=str) if partition_filters else ""
    if or_groups:
        from core.filter_ops import or_groups_fingerprint
        pf_str = pf_str + "|or=" + or_groups_fingerprint([list(b) for b in or_groups])
    # 2026-11-01 -- a PINNED read (``FOR VERSION AS OF``) is keyed by its
    # snapshot (``iceberg_versions.l1_cache_snapshot_token``): a pinned run
    # never reads nor writes the unpinned entry, so v1 / latest / v1 cannot
    # cross.  None = an unpinned read, today's key byte for byte.
    if snapshot:
        pf_str = pf_str + "|snap=" + str(snapshot)
    return (connection_id, tname, pf_str)


def _verify_snapshot_unchanged(
    cached_snapshot_id: str,
    connection_id,
    table_name: str,
) -> bool:
    """BF-505 (2026-05-28) — verify the cached snapshot_id still matches
    the current snapshot on S3.

    Returns True when the stored snapshot is still current (cache fresh)
    OR when verification was skipped / failed (fail-OPEN — better to
    serve a possibly-stale cache than to block every query on an S3
    round-trip when ``version-hint.text`` is unavailable).

    Returns False ONLY when we have strong evidence the snapshot has
    advanced (different current-snapshot-id detected via the
    iceberg_snapshot_cache pointer mirror).

    The verification uses ``iceberg_snapshot_cache`` pointer mirror
    which is populated whenever metadata.json is read.  It's a pure
    in-memory check (no S3 call) so it's cheap enough to run on every
    ice_cache_get.  When the pointer mirror has NO entry for this
    table (cold start, never queried), we trust the ice_cache —
    invalidation will happen on the NEXT metadata.json read.
    """
    if not cached_snapshot_id:
        return True  # legacy entries without stored snapshot — can't verify
    # Pointer mirror is keyed by (bucket, table_prefix), and we do not have
    # those here from the ice_cache key, so the tighter check cannot be made
    # at this seam.  Trust ice_cache and rely on BF-503's pointer check at
    # the upstream ``_latest_metadata_key`` call to evict the metadata-key
    # cache; when that evicts, the next ``ice_cache_set`` overwrites under
    # the SAME key with the new snapshot's file list.  Returning True is
    # correct given that invalidation chain.
    #
    # 2026-09-01 -- this reasoning used to sit inside a try/except whose
    # first statement imported ``get_cached_pointer``, a name
    # core.iceberg_snapshot_cache does not define.  The block raised
    # ImportError immediately, every time, and the handler swallowed it: a
    # deliberate decision wearing the costume of a failed check.  Removing
    # the scaffolding changes nothing except what the code says it is doing.
    return True


def _serve_unverified(entry: dict, key, tier: str) -> dict:
    """2026-08-20 DATA-LOSS FIX (disclosure): the caller ASKED for a
    snapshot-freshness check (``current_snapshot_id`` was passed) but its
    snapshot probe FAILED (empty string).  Previously the empty live
    snapshot made the mismatch check a no-op and the entry was served
    exactly like a verified hit — files committed since the cache write
    were silently missing from the scan set, with nothing in the envelope.

    The entry is still served (fail-open: the probe failing does not prove
    the cache is stale, and refusing would turn every transient S3 blip
    into a full manifest walk) — but the serve is now VISIBLE:

      * WARNING log,
      * ``freshness_unverified: True`` on a shallow COPY of the entry
        (never mutate the cached dict), and
      * a per-execution ``iceberg_cache_freshness_unverified`` record in
        the diagnostic store (execution id resolved from the ContextVar),
        where the response envelope already looks.
    """
    logger.warning(
        "Iceberg file cache (%s): snapshot probe FAILED upstream — serving "
        "cached file list for %s WITHOUT freshness verification (stored "
        "snapshot=%s).  Files committed since the cache write would be "
        "missing; flagged freshness_unverified in the entry + diagnostic "
        "store.", tier, key[1], str(entry.get("snapshot_id") or "?"),
    )
    out = dict(entry)
    out["freshness_unverified"] = True
    try:
        from core.query_diagnostic_store import (
            get_current_execution_id, get_pruning, record_pruning,
        )
        eid = get_current_execution_id()
        if eid:
            prev = dict((get_pruning(eid) or {}).get(
                "iceberg_cache_freshness_unverified") or {})
            prev[str(key[1])] = {
                "tier": tier,
                "stored_snapshot_id": str(entry.get("snapshot_id") or ""),
                "reason": "snapshot probe failed — cache entry served "
                          "without freshness verification",
            }
            record_pruning(eid, {"iceberg_cache_freshness_unverified": prev})
    except Exception as _exc:
        logger.debug("freshness_unverified diagnostic record skipped: %s", _exc)
    return out


def ice_cache_get(key, *, current_snapshot_id: Optional[str] = None):
    """L1 + L2 lookup.  Returns dict or None.

    BF-505 — when ``current_snapshot_id`` is provided by the caller
    (it has just resolved the current snapshot of the underlying
    table), the cache compares it to the snapshot_id stored at
    insert time.  Mismatch → cache MISS (the cached file list was
    produced under a different snapshot and is stale).  This is the
    cheapest possible freshness check because the caller already has
    ``current_snapshot_id`` in scope; no extra S3 calls.
    """
    # L1 check — fast in-memory (2026-08-20: under ICE_FILE_CACHE_LOCK —
    # pure dict ops + comparisons, no I/O held under the lock).
    with ICE_FILE_CACHE_LOCK:
        entry = ICE_FILE_CACHE.get(key)
        if entry and (time.monotonic() - entry["ts"]) < ICE_FILE_CACHE_TTL:
            # BF-505 — verify snapshot match (caller-supplied).  Mismatched
            # snapshots mean the cached file list was produced before a
            # new write committed — return MISS so caller re-reads
            # manifests for the current snapshot.
            if current_snapshot_id is not None:
                _stored_snap = str(entry.get("snapshot_id") or "")
                _live_snap = str(current_snapshot_id or "")
                if _stored_snap and _live_snap and _stored_snap != _live_snap:
                    logger.info(
                        "Iceberg file cache: snapshot mismatch — cached=%s "
                        "live=%s, invalidating L1 entry for %s",
                        _stored_snap, _live_snap, key[1],
                    )
                    ICE_FILE_CACHE.pop(key, None)
                    # Don't return — fall through to L2 + freshness check.
                elif not _live_snap:
                    # 2026-08-20 — check REQUESTED but the caller's snapshot
                    # probe failed ("" is the probe-failure spelling, see
                    # duckdb_views).  Serve, but flagged — never silently.
                    # 2026-10-07 — and only while the entry (written right
                    # after its snapshot was resolved) is inside the
                    # declared staleness bound: an unverified entry used to
                    # serve for the whole file-cache TTL.
                    from core.iceberg_freshness_bound import (
                        may_serve_unconfirmed as _may_serve)
                    if _may_serve(time.monotonic() - entry["ts"]):
                        return _serve_unverified(entry, key, "L1")
                    logger.info(
                        "Iceberg file cache: snapshot probe failed and the "
                        "entry for %s is older than the staleness bound -- "
                        "MISS (re-read under a resolved snapshot)", key[1])
                    ICE_FILE_CACHE.pop(key, None)
                else:
                    return entry
            else:
                return entry
        if entry:
            # BF-505 — use pop (idempotent) instead of del; the snapshot-
            # mismatch branch above may have already popped this key, so
            # ``del`` would raise KeyError and crash the whole lookup.
            ICE_FILE_CACHE.pop(key, None)

    # L2 check — persistent DB (per-connection; OFF by default — bucket-scoped
    # db-first stats + snapshot cache supersede it).
    if not _l2_enabled():
        return None
    connection_id, table_name, filters_hash = key
    try:
        db_entry = _db_manager.get_iceberg_file_cache(connection_id, table_name, filters_hash)
        if db_entry:
            updated = datetime.fromisoformat(db_entry["updated_at"]).replace(tzinfo=timezone.utc) \
                      if isinstance(db_entry["updated_at"], str) else db_entry["updated_at"]
            if updated and (datetime.now(timezone.utc) - updated).total_seconds() < ICE_FILE_CACHE_L2_TTL:
                # BF-505 — same snapshot check for L2 hits.  L2 has
                # a ``snapshot_id`` column (added by set_iceberg_file_cache).
                _l2_snap = str(db_entry.get("snapshot_id") or "")
                if (current_snapshot_id is not None
                        and _l2_snap
                        and str(current_snapshot_id) != _l2_snap):
                    logger.info(
                        "Iceberg file cache L2: snapshot mismatch — cached=%s "
                        "live=%s, treating as MISS for %s/%s",
                        _l2_snap, current_snapshot_id, table_name,
                        filters_hash[:30],
                    )
                    return None
                # Promote to L1
                result = {
                    "files": db_entry["file_list"],
                    "metadata": None,
                    "ts": time.monotonic(),
                    "snapshot_id": _l2_snap,
                }
                with ICE_FILE_CACHE_LOCK:
                    ICE_FILE_CACHE[key] = result
                logger.debug("Iceberg file cache L2 hit: %s/%s (%d files)",
                             table_name, filters_hash[:30], len(db_entry["file_list"]))
                return result
    except Exception as exc:
        logger.warning("Iceberg file cache L2 read error: %s", exc)

    return None


def ice_cache_set(key, active_files, metadata, record_count=0, snapshot_id="",
                  join_key_bounds=None, join_key_distinct_values=None,
                  join_key_distinct_values_bloom=None,
                  pos_delete_files=None, eq_delete_files=None,
                  file_enumeration_complete=None,
                  iceberg_read_plan=None, empty_island=None,
                  file_record_counts=None, files_before_prune=None):
    """Store in L1 + L2.

    2026-10-08 -- ``files_before_prune`` (the reader's pre-prune total for
    the snapshot, ``_out_meta["files_before_prune"]``) travels with the
    entry so a cache HIT records a ``query_pruning_history`` row with the
    counts the cache carried.  L1-only; absent / None = the reader did not
    count, and the hit's row says NULL, never 0.

    2026-10-07 -- ``file_record_counts`` (the manifests' ``record_count``
    per file, parallel to ``active_files``) lets a cache HIT still decide
    the LIMIT-only early stop (``core.limit_early_stop``).  L1-only; absent
    (L2-promoted / pre-fix entry) = unknown, and the early stop declines.

    2026-09-28 -- ``empty_island`` (the reader's ``_out_meta["empty_island"]``
    verdict) travels with an EMPTY file list so a cache HIT on a 0-file
    island still knows whether that emptiness was PROVEN.  A hit whose list
    is empty and whose verdict is absent or unproven is treated as a MISS by
    the consumers (a pre-fix / L2-promoted entry must never serve 0 rows on
    the strength of a guess).  L1-only.

    2026-09-25 -- ``iceberg_read_plan`` (the reader's
    ``_out_meta["iceberg_read_plan"]``: current schema, identity partition
    field-ids, per-file column presence) travels with the file list so a
    cache HIT builds the same view as a miss -- values from the data files
    and the current schema projected.  L1-only; absent (pre-fix / L2-promoted
    entry) ⇒ the planner keeps the hive-path read.

    JOIN-PRUNER (2026-06-01) — optional ``join_key_bounds`` and
    ``join_key_distinct_values`` are stored alongside the file list so
    that subsequent queries with the same partition filter and matching
    join-key column set can serve bounds from L1 without re-walking
    manifests.  The cache key already includes the partition_filters
    (different filter → different surviving files → different bounds),
    so caching is automatically correct.  L2 stores files-only (bounds
    are L1-only).

    BLOOM JOIN-PRUNE (2026-07-13) — ``join_key_distinct_values_bloom`` is
    the anchor's COMPLETE distinct join-key set (emitted only when every
    anchor file was single-valued).  Like the bounds above it is a pure
    function of (table, partition_filters, snapshot) — all captured by
    the cache key + snapshot check — so caching it is correct and lets a
    repeat join's bloom target-prune engage even when the anchor side is
    served from cache.  L1-only, same as bounds.
    """
    # L1 store
    # 2026-07-15 — pos/eq delete files travel with the file list so a cache HIT
    # on a merge-on-read (V2) table still builds a delete-aware view instead of
    # silently counting deleted rows.  These keys are ALWAYS present on entries
    # written here (empty list = genuinely no deletes); their ABSENCE marks an
    # untrusted L2-promoted / pre-fix entry, which the reader force-refreshes
    # when MoR is enabled.  L1-only, same as the join bounds above (L2 stores
    # files-only), and correct-by-construction: delete files are a pure function
    # of (table, partition_filters, snapshot), all captured by the cache key +
    # snapshot check.
    # 2026-07-15 (audit finding #6) — file_enumeration_complete is the
    # reader's completeness attestation for runtime join dynamic filtering.
    # Tri-state on purpose: True = provably complete; False = provably
    # truncated; None = unknown (legacy caller / L2-promoted entry).
    # Consumers require ``is True`` before pushing a runtime IN-list, so
    # None/absent is fail-safe (no push).  L1-only, like the join bounds.
    # 2026-08-20 — store + two-phase eviction run atomically under
    # ICE_FILE_CACHE_LOCK: the stale sweep and the LRU sort both iterated
    # the live dict while worker threads inserted, which is exactly the
    # "dictionary changed size during iteration" crash this lock removes.
    with ICE_FILE_CACHE_LOCK:
        ICE_FILE_CACHE[key] = {
            "files": active_files, "metadata": metadata, "ts": time.monotonic(),
            "record_count": record_count, "snapshot_id": snapshot_id,
            "join_key_bounds": join_key_bounds or {},
            "join_key_distinct_values": join_key_distinct_values or {},
            "join_key_distinct_values_bloom": join_key_distinct_values_bloom or {},
            "pos_delete_files": pos_delete_files or [],
            "eq_delete_files": eq_delete_files or [],
            "file_enumeration_complete": file_enumeration_complete,
            "iceberg_read_plan": iceberg_read_plan,
            "empty_island": empty_island,
            "file_record_counts": (list(file_record_counts)
                                   if file_record_counts is not None
                                   and len(file_record_counts) == len(active_files or [])
                                   else None),
            "files_before_prune": (int(files_before_prune)
                                   if isinstance(files_before_prune, int)
                                   and not isinstance(files_before_prune, bool)
                                   else None),
        }
        # BF-580 (2026-05-29): two-phase eviction.  Old code only
        # removed STALE entries when count > 200 — under churn where
        # all 200 entries were still within TTL, the dict grew
        # unbounded (multi-GB on multi-tenant pods).  Now: stale
        # sweep first, then LRU evict by oldest ``ts`` until the
        # cache is back under the hard cap.
        _HARD_CAP = 500     # max entries — gives us 2.5× headroom over the old soft trigger
        if len(ICE_FILE_CACHE) > _HARD_CAP:
            now = time.monotonic()
            # Phase 1: drop expired entries.
            stale = [k for k, v in ICE_FILE_CACHE.items() if now - v["ts"] > ICE_FILE_CACHE_TTL]
            for k in stale:
                ICE_FILE_CACHE.pop(k, None)
            # Phase 2: if still over cap, evict OLDEST first until under.
            if len(ICE_FILE_CACHE) > _HARD_CAP:
                sorted_by_age = sorted(
                    ICE_FILE_CACHE.items(), key=lambda kv: kv[1]["ts"],
                )
                target_evictions = len(ICE_FILE_CACHE) - _HARD_CAP
                for k, _v in sorted_by_age[:target_evictions]:
                    ICE_FILE_CACHE.pop(k, None)
                logger.info(
                    "BF-580: ice_file_cache LRU-evicted %d oldest entries "
                    "(cap=%d). Cache pressure suggests high distinct-query "
                    "churn — consider raising ICE_FILE_CACHE hard cap if "
                    "this is sustained.",
                    target_evictions, _HARD_CAP,
                )

    # L2 store — persistent DB (per-connection; OFF by default, see _l2_enabled).
    if not _l2_enabled():
        return
    connection_id, table_name, filters_hash = key
    try:
        _db_manager.set_iceberg_file_cache(connection_id, table_name, filters_hash, active_files)
    except Exception as exc:
        logger.warning("Iceberg file cache L2 write error: %s", exc)


def invalidate_for_table(bucket, table_prefix, snapshot_id=None,
                         table_name=None, connection_id=None) -> dict:
    """Invalidate the ICE_FILE_CACHE survivor-file-list entries for a table —
    BOTH the L1 in-memory layer AND the L2 SQLite (5h) layer.

    Called when new per-file column stats land so a cached PRE-stats survivor
    list stops short-circuiting pruning.  The key is
    ``(connection_id, registered_view_name, filters_hash)`` — which does NOT
    contain the bucket/prefix — so L1 is matched on the entry's stored FILE
    VALUES (files are ``s3://{bucket}/{prefix}/...`` — duckdb_views.py:3125),
    which is exact regardless of view naming, plus the key's table_name when
    supplied.  L2 is deleted by ``table_name`` (the persistent layer the old
    hasattr-guarded clear never touched — ``ICE_FILE_CACHE_LOCK`` never existed).
    Fail-open; returns per-layer counts."""
    pfx = f"s3://{bucket}/{(table_prefix or '').rstrip('/')}/"
    l1 = 0
    # 2026-08-20 — under ICE_FILE_CACHE_LOCK (cheap value probes only);
    # the list() snapshot alone protected THIS iteration but not the
    # eviction pass in ice_cache_set running concurrently.
    with ICE_FILE_CACHE_LOCK:
        for k, v in list(ICE_FILE_CACHE.items()):
            try:
                files = v.get("files") or []
                probe = files[:3] + files[-1:]
                if (table_name and isinstance(k, tuple) and len(k) > 1 and k[1] == table_name) \
                        or any(isinstance(f, str) and f.startswith(pfx) for f in probe):
                    ICE_FILE_CACHE.pop(k, None)
                    l1 += 1
            except Exception:
                continue
    l2 = 0
    try:
        if _l2_enabled() and _db_manager is not None and table_name:
            l2 = int(_db_manager.delete_iceberg_file_cache(
                connection_id=connection_id, table_name=table_name) or 0)
    except Exception as exc:
        logger.debug("invalidate_for_table L2 delete skipped: %s", exc)
    if l1 or l2:
        logger.info("ice_file_cache invalidate_for_table prefix=%s -> L1=%d L2=%d",
                    pfx, l1, l2)
    return {"l1": l1, "l2": l2}


# ══════════════════════════════════════════════════════════════════════════════
# Schema cache: L1 in-memory only (10 min TTL)
# ══════════════════════════════════════════════════════════════════════════════

_schema_cache: Dict[str, Tuple[float, dict]] = {}
_schema_cache_lock = threading.Lock()
SCHEMA_L1_TTL = 600   # 10 minutes


def schema_cache_get(key: str) -> Optional[dict]:
    with _schema_cache_lock:
        if key in _schema_cache:
            ts, result = _schema_cache[key]
            if time.time() - ts < SCHEMA_L1_TTL:
                return result
    return None


def schema_cache_set(key: str, result: dict):
    with _schema_cache_lock:
        if len(_schema_cache) > 200:
            oldest = min(_schema_cache, key=lambda k: _schema_cache[k][0])
            del _schema_cache[oldest]
        _schema_cache[key] = (time.time(), result)


# ══════════════════════════════════════════════════════════════════════════════
# Partition cache: L1 in-memory (configurable) + L2 SQLite (configurable)
# ══════════════════════════════════════════════════════════════════════════════

_partition_cache: Dict[str, Tuple[float, dict]] = {}
_partition_cache_lock = threading.Lock()


def _partition_l1_ttl() -> int:
    return _pcache_cfg.l1_ttl_seconds


def _partition_l2_ttl() -> int:
    return _pcache_cfg.l2_ttl_seconds


def _partition_cache_max() -> int:
    # Pre-existing bug: this function read ``_pcache_cfg.max_entries`` but
    # ``_PartitionCacheCfg`` only exposes ``l1_max_entries`` (and
    # ``l1_ttl_seconds`` / ``l2_ttl_seconds``).  Every call site that
    # reached this function crashed with
    # ``AttributeError: '_PartitionCacheCfg' object has no attribute 'max_entries'``.
    # Surface only happened when an iceberg metadata cache path was
    # exercised — the rest of the code reads the same value via the
    # local ``_pcache_l1_max`` helper in api/connections_api.py which
    # gets it right.
    return _pcache_cfg.l1_max_entries


def partition_l1_get(cache_key: str):
    """Check L1 in-memory cache. Returns (hit, result)."""
    with _partition_cache_lock:
        if cache_key in _partition_cache:
            ts, result = _partition_cache[cache_key]
            if time.time() - ts < _partition_l1_ttl():
                return True, result
    return False, None


def partition_l1_set(cache_key: str, result: dict):
    """Store in L1 in-memory cache."""
    with _partition_cache_lock:
        if len(_partition_cache) >= _partition_cache_max():
            oldest = min(_partition_cache, key=lambda k: _partition_cache[k][0])
            del _partition_cache[oldest]
        _partition_cache[cache_key] = (time.time(), result)


def partition_l2_get(connection_id: int, table_name: str, scan_type: str, s3_prefix: str = ""):
    """Check L2 SQLite cache. Returns (hit, result, cached_at_iso)."""
    entry = _db_manager.get_partition_cache(connection_id, table_name, scan_type, s3_prefix=s3_prefix)
    if entry:
        updated = datetime.fromisoformat(entry["updated_at"]).replace(tzinfo=timezone.utc) \
                  if isinstance(entry["updated_at"], str) else entry["updated_at"]
        if updated and (datetime.now(timezone.utc) - updated).total_seconds() < _partition_l2_ttl():
            data = dict(entry["partition_data"])  # copy — don't mutate DB cache
            data["cached_at"] = entry["updated_at"]
            return True, data, entry["updated_at"]
    return False, None, None


def partition_store(connection_id: int, table_name: str, scan_type: str,
                    cache_key: str, result: dict, s3_prefix: str = ""):
    """Store in both L1 + L2.  Does NOT mutate the input dict."""
    now_iso = datetime.now(timezone.utc).isoformat()
    stamped = {**result, "cached_at": now_iso}   # shallow copy with timestamp
    partition_l1_set(cache_key, stamped)
    _db_manager.set_partition_cache(connection_id, table_name, scan_type, stamped, s3_prefix=s3_prefix)
