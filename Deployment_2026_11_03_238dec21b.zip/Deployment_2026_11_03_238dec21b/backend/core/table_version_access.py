"""Who may LIST a table's versions, and what a listing may carry (2026-11-01).

Security review of 5f04142e9: the version-listing routes (``POST
/api/sql/table-versions``, ``GET /api/connections/{id}/iceberg/{table}/
snapshots``, the published ``GET /api/v1/views/{slug}/versions`` and the
report run panel's own listing) ran statements on the source (Trino
``"t$snapshots"``, Databricks ``DESCRIBE HISTORY``) or read the table's
metadata with the connection's stored credentials, under a read-only
capability and with no look at the person's rights on the TABLE -- and they
returned the snapshot's whole summary (manifest list, operation parameters,
total row counts).

ONE decision, the one the run takes: the row-security engine
(``core.row_security.secure_sql_report``) is asked about ``SELECT * FROM
<table>`` for this person, exactly as ``POST /api/sql/execute`` asks about
the statement it runs.

* the engine REFUSES (an unresolved principal, a broken policy, an
  entitlement it cannot decide) -> ``refused``: no listing;
* the person holds NO grant on a table that has grants (the composition's
  ``no_grant``: they would read zero rows) -> ``refused``: a person who may
  not read a table may not list its versions;
* a policy narrows the rows -> ``limited``: the versions are listed (ids,
  times, operations -- what the picker needs) but the row and file COUNTS are
  withheld: they are the WHOLE table's, which this person may not count;
* nothing applies (no policy, row security off, an admin) -> ``full``.

A listing carries only ``LISTED_FIELDS``; never ``manifest_list`` (a storage
path), ``summary`` / ``operationParameters`` (the engine's whole blob).

A listing failure is told through ``failure_words`` -- the sanitizer's
sentence (``core.error_sanitizer.describe_exception``) -- and the raw driver
text is logged server-side only.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional

logger = logging.getLogger(__name__)

#: the fields of one version a listing answers -- what the pickers show
LISTED_FIELDS = ("snapshot_id", "parent_id", "committed_at", "committed_at_ms",
                 "operation", "is_current", "added_rows", "total_rows", "total_files")
#: the whole-table numbers a ``limited`` reader is not shown
COUNT_FIELDS = ("added_rows", "total_rows", "total_files")

FULL, LIMITED, REFUSED = "full", "limited", "refused"

LIMITED_WORDS = ("Row and file counts are not shown: your access to this table's "
                 "rows is limited.")
NO_GRANT_WORDS = ("You may not read {table}, so its versions are not listed.")
REFUSED_WORDS = ("The versions of {table} are not listed: your access to it could "
                 "not be decided ({why}).")


@dataclass(frozen=True)
class TableAccess:
    state: str                     # full | limited | refused
    words: Optional[str] = None    # what the person reads when not full

    @property
    def counts(self) -> bool:
        return self.state == FULL


def _probe_sql(table: str, dialect: Optional[str]) -> str:
    import sqlglot
    from sqlglot import exp
    tbl = exp.to_table(str(table), dialect=dialect or None)
    return sqlglot.select("*").from_(tbl).sql(dialect=dialect or None)


def access_for(user: Optional[dict], table: str, *, connection_id: Optional[int],
               dialect: Optional[str]) -> TableAccess:
    """THE decision for one table (see the module docstring)."""
    from core.row_security.api import secure_sql_report
    try:
        probe = _probe_sql(table, dialect)
    except Exception as exc:                                   # noqa: BLE001
        logger.warning("table_version_access: %r does not parse as a table: %s", table, exc)
        return TableAccess(REFUSED, REFUSED_WORDS.format(
            table=table, why="the table name could not be read"))
    try:
        _sql, result = secure_sql_report(
            probe, dialect=dialect or "duckdb", user_ctx=user or {},
            connection_id=connection_id)
    except Exception as exc:                                   # noqa: BLE001  -- refusal = refused
        logger.info("table_version_access: listing of %s refused for %s: %r",
                    table, (user or {}).get("username"), exc)
        # fixed words: a policy's own refusal can name the policy and its SQL
        return TableAccess(REFUSED, REFUSED_WORDS.format(
            table=table, why="the access rules on it could not be applied"))
    if result is None:
        return TableAccess(FULL)
    for row in result.applied or []:
        comp = row.get("composition") or {}
        if comp.get("outcome") == "no_grant":
            return TableAccess(REFUSED, NO_GRANT_WORDS.format(table=table))
    if result.changed:
        return TableAccess(LIMITED, LIMITED_WORDS)
    return TableAccess(FULL)


def public_rows(rows: Optional[Iterable[Dict[str, Any]]], access: TableAccess
                ) -> Optional[List[Dict[str, Any]]]:
    """``rows`` cut to ``LISTED_FIELDS``; the counts withheld (None) unless
    ``access`` is full.  ``None`` stays ``None`` (could not be read)."""
    if rows is None:
        return None
    out = []
    for r in rows:
        row = {k: r.get(k) for k in LISTED_FIELDS}
        if not access.counts:
            for k in COUNT_FIELDS:
                row[k] = None
        out.append(row)
    return out


def failure_words(table: str, exc: BaseException, *, verb: str = "read") -> str:
    """The sentence for a listing that failed: the sanitizer's words; the
    exception itself goes to the server log only."""
    from core.error_sanitizer import describe_exception
    logger.warning("table versions of %s could not be %s", table, verb, exc_info=exc)
    try:
        why = describe_exception(exc)
    except Exception:                                          # noqa: BLE001
        why = type(exc).__name__
    return f"The versions of {table} could not be {verb}: {why}"
