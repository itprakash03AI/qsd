"""
DuckDB view/table management — registered S3 tables, MV views, local tables.

Extracted from main.py for maintainability.

Functions:
- SQLCollector           — fake DuckDB connection that records SQL
- setup_registered_views — resolve __registered__: → DuckDB views + build SQL
- execute_registered_table_query  — stream Arrow tables from registered views
- execute_registered_table_copy_to — COPY TO parquet via subprocess
- s3_full_copy           — COPY a statement's result from S3 (its own LIMIT kept;
                           a GENERATED query-builder cap stripped)
- join_inflight_query    — shadow execution dedup (waits for primary)
- run_base_data_local_query — re-query local parquet without S3 round-trip
- register_s3_views      — register S3/MV/local views in a DuckDB connection
"""
from __future__ import annotations

import asyncio
import contextvars
import json
import logging
from core.s3_http_errors import failure_text as _s3_failure_text
import os
import time as _time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set


# BF-289: thread/task-local execution_id used by _track() to update the
# per-execution stage tracker.  Set by callers that know the execution_id
# (api/execute_api passes it via `with set_dl_execution_id(eid):`); cleared
# automatically when the context exits.  ContextVar so async tasks +
# threadpool workers both see the right value.
_DL_EXEC_ID_CTX: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "_DL_EXEC_ID_CTX", default=None,
)


# ── BF-494 (2026-05-27) — Iceberg partition-spec evolution handling ─────────
#
# When an Iceberg table evolves its partition spec (e.g. a new bucket /
# truncate column is added later), files written before the evolution
# have a SHORTER hive-key path than files written after.  Example:
#
#   pre-evolution:   .../businessdate=null/receiveddate=null/race_su=V6324/level2_name=Total_Assets/*.parquet
#   post-evolution:  .../businessdate=2026-04-30/receiveddate=2026-05-18/race_su=V8360/level2_name=Total_Assets/flex_sap_company_code_bucket_16=0/*.parquet
#
# DuckDB's ``read_parquet([files], hive_partitioning=true)`` requires
# EVERY file in the list to share the same hive-key set.  Mismatched
# keys raise ``BinderException: Hive partition mismatch ... key X not
# found``.  ``union_by_name=true`` doesn't help — that reconciles
# DATA columns, not hive partition keys.
#
# Fix: group the file list by hive-key signature.  Emit one
# ``read_parquet`` per group, combined with ``UNION ALL BY NAME``
# which auto-fills missing columns as NULL.  Behavioural parity with
# ``iceberg_scan()`` (which handles spec evolution natively) but with
# zero dependency on the iceberg DuckDB extension — works in every
# subprocess + on-prem environment regardless of extension availability.

import re as _re_hp_evo  # noqa: E402

# Match a hive ``key=value`` segment anchored at any path separator —
# forward slash (S3 / posix) OR backslash (Windows local files).  Both
# matter because pre-download fallback paths rewrite s3:// → local
# C:\…\key=value\file.parquet, and the same view-construction code path
# sees both.  Without the ``\\`` alternative the helper silently
# returned ``()`` for every Windows path, defeated partition-spec
# detection, and the original BinderException re-surfaced.
_HIVE_KV_PAT = _re_hp_evo.compile(r"[/\\]([a-zA-Z_][a-zA-Z0-9_]*)=")


def _hive_keys_of(path: str) -> tuple:
    """Return the sorted tuple of hive partition KEY NAMES present in
    a single S3 / file path.  Values are intentionally ignored — only
    the KEY SHAPE matters for grouping.
    """
    return tuple(sorted(set(_HIVE_KV_PAT.findall(path or ""))))


def _group_files_by_hive_signature(paths) -> list:
    """Group files by their hive partition KEY signature.

    Returns a list of ``(signature_tuple, [paths])`` items.  A single
    item means every file has the same hive-key set (no spec evolution).
    Two-or-more items means we hit partition-spec evolution and the
    caller must emit one ``read_parquet`` per group + UNION ALL BY NAME.
    """
    groups: "dict[tuple, list]" = {}
    for p in paths or []:
        sig = _hive_keys_of(p)
        groups.setdefault(sig, []).append(p)
    return list(groups.items())


def _suspend_signing_if_views_contain_presigned_urls(
    con, registered_tables,
) -> bool:
    """Scan the view DDLs we just created on ``con``; if any embedded
    presigned URLs (``X-Amz-Signature=`` marker), RESET ``s3_endpoint``
    + S3 credentials on the connection and stamp it so the pool drops
    it on release.

    Why this matters -- when an in-process caller (BQB streaming,
    materialized view refresh, the materialized_views_api download
    endpoint, federation_engine, etc.) hands a DuckDB connection to
    ``register_s3_views``, the connection already has ``SET s3_endpoint
    ='vpce-...'`` + ``SET s3_access_key_id='...'`` applied by the
    factory ``_duckdb_con_with_s3``.  When the smart-VPC fast path
    embeds presigned ``https://vpce-.../...?X-Amz-Signature=…`` URLs
    into a ``CREATE VIEW`` DDL, the URL host matches the connection's
    s3_endpoint -- so when the view is QUERIED, httpfs adds its own
    SigV4 ``Authorization`` header on top of the already-signed URL.
    libcurl drops the malformed request and surfaces it as
    ``HTTP 0 Internal Server Error``.  This is the in-process twin of
    the subprocess bug closed by ``core.duckdb_s3_plan``.

    Strategy: scan the connection's view DDLs for the SigV4 marker
    after registration.  If any view embeds a presigned URL, RESET the
    connection's S3 settings so the imminent query reads the presigned
    URLs cleanly, and stamp the connection with
    ``_qs_s3_signing_reset_for_presigned_views`` so the pool drops it
    on release (the S3 settings are now in an indeterminate state --
    safer to recycle than to risk a future query getting a partially-
    configured connection).

    Returns True if the suspend fired (caller uses for telemetry /
    brain_trace), False otherwise.
    """
    try:
        from core.duckdb_s3_plan import sql_has_presigned_marker
    except Exception:
        return False

    # Short-circuit when ``con`` is the SQLCollector used by the
    # subprocess batch path -- it has no real DuckDB session to query,
    # and naively probing it would append a ``SELECT … FROM
    # duckdb_views()`` statement to the collector that the subprocess
    # then has to skip.  The subprocess path is already protected by
    # the planner (PRESIGNED_URLS_IN_SQL strategy); no in-process
    # signing context exists on the collector to suspend.
    if hasattr(con, "statements") and not hasattr(con, "fetchall"):
        return False

    # Limit the scan to views named after tables we just registered.
    # ``duckdb_views()`` returns ALL views on the connection -- if the
    # pooled connection had stale views from a prior query, we'd false-
    # positive into a needless reset.  Filtering by table name keeps
    # the scan precise.
    _watched = set()
    for tbl in registered_tables or []:
        if isinstance(tbl, dict):
            _name = tbl.get("name") or tbl.get("table_name") or ""
            if _name:
                _watched.add(_name.lower())
        elif isinstance(tbl, str) and tbl:
            _watched.add(tbl.lower())
    if not _watched:
        return False

    try:
        rows = con.execute(
            "SELECT view_name, sql FROM duckdb_views()"
        ).fetchall()
    except Exception:
        return False

    _embedded = False
    for view_name, view_sql in rows:
        if not view_sql or not view_name:
            continue
        if str(view_name).lower() not in _watched:
            continue
        if sql_has_presigned_marker(str(view_sql)):
            _embedded = True
            break
    if not _embedded:
        return False

    # Delegate the actual RESET + stamp to the shared helper in
    # core.duckdb_s3_plan so every caller (this in-process view path,
    # federation_engine's inline SQL path, future modules) goes through
    # the same code -- one place to add a future RESET key if AWS
    # introduces a new s3_* setting that affects signing.
    from core.duckdb_s3_plan import reset_s3_signing_on_connection
    reset_s3_signing_on_connection(con)

    logger.info(
        "register_s3_views: detected presigned URLs in %d view DDL(s) -- "
        "RESET s3_endpoint + credentials so the imminent query reads "
        "them cleanly; pool will drop this connection on release.",
        len(_watched),
    )

    # Brain trace so post-mortem can see this branch fired.
    try:
        from core.brain_trace import trace as _bt_suspend
        _bt_suspend(
            "s3_signing_reset", "in_process_presigned_urls",
            tables_watched=len(_watched),
        )
    except Exception:
        pass

    return True


def _iceberg_file_read_url(file_path: str, bucket: str) -> str:
    """An Iceberg file reference (a manifest's ``file_path``) as the
    ``s3://bucket/key`` URL this engine reads (2026-10-14).  A writer records
    ``s3://``, ``s3a://`` (Spark / Hadoop / EMR) or ``s3n://`` -- or a bare
    key.  Found live: a Spark-written v2 table's delete files (``s3a://``)
    were read as ``s3://<bucket>/s3a://<bucket>/...`` -> 404, and the table
    could not be read at all."""
    from core.iceberg_reader import _s3_uri_bucket, _s3_uri_to_key
    fp = str(file_path or "")
    b = _s3_uri_bucket(fp)
    if b:
        return f"s3://{b}/{_s3_uri_to_key(fp)}"
    return f"s3://{bucket}/{fp.lstrip('/')}"


def _build_iceberg_read_expr(paths, union_clause: str = "",
                             hive_types: "Optional[dict]" = None) -> str:
    """Return the FROM-clause expression for a list of Iceberg data files.

    Single hive-key signature → returns the regular
    ``read_parquet([f1, f2, ...], hive_partitioning=true, …)`` form.

    Multiple signatures (partition-spec evolution) → returns a
    parenthesised UNION-ALL-BY-NAME of per-signature ``read_parquet``s.
    Files from earlier specs (with fewer hive keys) get NULL for the
    newly-added partition columns, matching ``iceberg_scan()``'s
    behaviour.

    ``union_clause`` lets the caller forward the existing
    ``", union_by_name=true"`` toggle (BF-PRUNE-PERF / Phase 122) so
    DATA-column evolution still works inside each group.

    2026-10-06 -- every group's read DECLARES its partition keys' types
    (``hive_types`` = the caller's declared types, see
    ``core.hive_partition_types``) and turns DuckDB's per-read guess off: a
    STRING partition ``code=51`` read as BIGINT, '007' would read as 7.
    """
    from core.hive_partition_types import hive_types_clause
    _esc = lambda v: v.replace("'", "''")
    groups = _group_files_by_hive_signature(paths)
    if len(groups) <= 1:
        # Fast path — no evolution, single read_parquet expression.
        paths_str = ", ".join(f"'{_esc(p)}'" for p in paths)
        _ht = hive_types_clause(groups[0][0] if groups else (), hive_types)
        return f"read_parquet([{paths_str}], hive_partitioning=true{union_clause}{_ht})"
    # Spec evolution — one SELECT per signature, UNION ALL BY NAME.
    selects = []
    for _sig, group_paths in groups:
        paths_str = ", ".join(f"'{_esc(p)}'" for p in group_paths)
        _ht = hive_types_clause(_sig, hive_types)
        selects.append(
            f"SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true{union_clause}{_ht})"
        )
    return "(" + " UNION ALL BY NAME ".join(selects) + ")"


# 2026-09-25 -- THE Iceberg read/projection decision.  Every Iceberg view
# builder in this module (batch, streaming, MoR via _apply_mor_view) and the
# raw-SQL builder in execute_api go through plan_iceberg_read; in hive-path
# mode its from_expr is _build_iceberg_read_expr's output, unchanged.
from core.hive_partition_types import (  # noqa: E402
    declared_partition_types as _declared_partition_types,
)
from core.iceberg_read_plan import (  # noqa: E402
    plan_iceberg_read as _plan_iceberg_read,
    iceberg_view_select_sql as _iceberg_view_select_sql,
    iceberg_view_source as _iceberg_view_source,
)


def build_query_sql(query_config, connection_type=None) -> str:
    """Build a complete SQL string from a saved ``query_config``, FOR THE
    ENGINE THAT WILL RUN IT.

    Module-level convenience for callers that don't have a
    ``ParquetQueryEngine`` instance in scope (feed_engine, scheduled
    tasks, the agent runner).  For code paths that already hold an
    engine (setup_registered_views, /api/execute), keep calling
    ``engine.build_query_sql`` directly — this helper is for the
    "give me one SQL string for this config" use case.

    Handles four input shapes:
      - dict with ``raw_sql`` field → returned as-is (SQL-mode saved
        queries)
      - dict with structured fields (selected_columns / filters /
        joins…) → coerced through ``QueryConfigModel`` then the
        engine's converter
      - ``QueryConfigModel`` instance → converted via
        ``convert_query_config_to_engine``
      - engine-native ``QueryConfig`` → passed straight to the engine

    ``connection_type`` (2026-09-05) is the connection the SQL will be
    EXECUTED on -- ``"trino"``, ``"snowflake"``, ``"oracle"``, ``"s3"``,
    ... .  It was not a parameter at all, so every caller here got DuckDB
    grammar (``FROM read_parquet('...') AS t0``) regardless of target,
    and ``feed_engine._execute_duckdb_query`` shipped it verbatim to
    Trino / Snowflake / Oracle.  Omitting it still means "DuckDB", which
    is what a caller with no connection in hand means and what every
    pre-existing caller got: cannot-tell is not a refusal.  Passing a
    remote SQL engine's type either renders for that engine or raises
    ``core.parquet_engine_v2.QueryNotExpressible`` naming it.

    Returns the executable SQL string.  Raises ``ValueError`` when the
    config is so malformed even the raw_sql shortcut doesn't apply, or
    ``QueryNotExpressible`` (a ValueError) when the builder cannot
    express this config on ``connection_type``.
    """
    # 1. raw_sql shortcut — covers SQL-mode saved queries + sql_file
    #    sources, the most common feed-source shape in production.
    if isinstance(query_config, dict):
        raw = query_config.get("raw_sql")
        if raw and isinstance(raw, str) and raw.strip():
            return raw

    # 2. Pydantic / dict → engine QueryConfig via the converter.
    if hasattr(query_config, "model_dump"):
        from core.query_converter import convert_query_config_to_engine
        query_config = convert_query_config_to_engine(query_config)
    elif isinstance(query_config, dict):
        # 2026-09-26 (F3 / M1, D9) -- a model REFUSAL used to fall through
        # here as ``except Exception: pass`` and the raw dict reached the
        # builder, which reads ``aggregations`` / ``joins`` as objects
        # (``agg.function``): the refusal surfaced, if at all, as an
        # AttributeError three frames down.  ``engine_config_from_stored``
        # raises a ValueError naming the field and the door instead.
        from core.query_converter import engine_config_from_stored
        query_config = engine_config_from_stored(
            query_config, where="build_query_sql (stored query_config)")

    # 3. Build SQL via the engine's structural builder, TOLD WHERE IT IS
    #    GOING.  ``build_query_sql_for_connection`` is byte-identical to
    #    ``get_duckdb_sql`` when connection_type is absent or is not a
    #    remote SQL engine, so every existing caller is unaffected; when
    #    it names one, the FROM clause and the dialect are that engine's,
    #    or the build refuses (QueryNotExpressible) rather than emitting
    #    DuckDB grammar the engine never agreed to speak.
    from core.parquet_engine_v2 import ParquetQueryEngine
    eng = ParquetQueryEngine()  # base_path / chunk_size from config defaults
    return eng.build_query_sql_for_connection(query_config, connection_type)


def set_dl_execution_id(execution_id: Optional[str]):
    """Context-manager-style helper: thread the execution_id through to
    the boto3 download _track() callback so progress lands on the right
    execution's stage tracker."""
    class _Ctx:
        def __enter__(self_inner):
            self_inner._tok = _DL_EXEC_ID_CTX.set(execution_id)
            return self_inner
        def __exit__(self_inner, *exc):
            _DL_EXEC_ID_CTX.reset(self_inner._tok)
            return False
    return _Ctx()

logger = logging.getLogger(__name__)

# ── Module-level singletons — populated by init_duckdb_views() ─────────────
_db_manager = None
_paths = None
_ws_manager = None
_mv_cfg = None
_lt_cfg = None
_limits_cfg = None


def init_duckdb_views(db_manager, paths, ws_manager, mv_cfg, lt_cfg, limits_cfg):
    """Call once from main.py _startup() after all components are initialised."""
    global _db_manager, _paths, _ws_manager, _mv_cfg, _lt_cfg, _limits_cfg
    _db_manager = db_manager
    _paths = paths
    _ws_manager = ws_manager
    _mv_cfg = mv_cfg
    _lt_cfg = lt_cfg
    _limits_cfg = limits_cfg


# ── Imports from extracted modules ──────────────────────────────────────────
from core.iceberg_cache import (  # noqa: E402
    ice_cache_key as _ice_cache_key,
    ice_cache_get as _ice_cache_get,
    ice_cache_set as _ice_cache_set,
)
from core.s3_utilities import (  # noqa: E402
    list_s3_parquet_files as _list_s3_parquet_files,
    list_s3_parquet_files_cached as _list_s3_parquet_files_cached,
    s3_urls_to_presigned as _s3_urls_to_presigned,
    make_s3_client_for_conn as _make_s3_client_for_conn,
    filter_iceberg_files_by_partitions as _filter_iceberg_files_by_partitions,
    get_s3_access_mode as _get_s3_access_mode,
)
from core.query_converter import translate_join_columns as _translate_join_columns  # noqa: E402
from core.path_utils import to_duckdb_path as _to_ddb_path  # noqa: E402


# ═══════════════════════════════════════════════════════════════════════════
# Pre-download presigned URLs for in-process DuckDB reads (on-prem S3)
# ═══════════════════════════════════════════════════════════════════════════

import shutil  # noqa: E402
import tempfile  # noqa: E402
import threading  # noqa: E402
from urllib.parse import urlparse, urlunparse, quote, unquote  # noqa: E402
from urllib.request import urlopen, Request  # noqa: E402

_thread_local = threading.local()

# 78I — Global registry for atexit cleanup (catches subprocess crashes)
import atexit as _atexit  # noqa: E402
from core.download_retention import (
    download_expires_at as _download_expires_at)
_global_temp_dirs: list = []
_global_temp_dirs_lock = threading.Lock()


def _atexit_cleanup():
    """Remove all tracked temp dirs on process exit (safety net for crashes)."""
    with _global_temp_dirs_lock:
        dirs = list(_global_temp_dirs)
    if not dirs:
        return
    removed, failed = 0, 0
    for d in dirs:
        try:
            shutil.rmtree(d, ignore_errors=True)
            removed += 1
        except Exception as _e:
            failed += 1
            # Use print — logger stream may already be closed during atexit
            print(f"[atexit_cleanup] Failed to remove {d}: {_e}", flush=True)
    print(f"[atexit_cleanup] Cleaned {removed} temp dir(s), {failed} failed", flush=True)


_atexit.register(_atexit_cleanup)


def _build_ssl_ctx(conn_config: dict):
    """Build SSL context matching connection config.

    2026-06-18 -- routes through core.ssl_config.  Prior code had the
    SAME dead-branch bug as duckdb_subprocess.py:765 -- when
    ssl_verify=True (the default), it set CERT_NONE here too,
    bypassing verification AND ignoring the helm-deployed CA bundle.
    Strategic fix: central resolver, single source of truth.
    """
    from core.ssl_config import resolve_ssl, as_ssl_context
    return as_ssl_context(resolve_ssl(conn_config.get("ssl_verify", True)))


def _is_proxy_active_for_duckdb() -> bool:
    """Return True if the corporate proxy is enabled for DuckDB httpfs traffic.

    When True, streaming views should pre-download S3 files via boto3 instead
    of relying on DuckDB httpfs (which gets HTTP 503 from some corporate proxies).
    """
    # 2026-09-26 (F3 round 4) -- ONE decision, core.proxy_utils
    # .duckdb_proxy_applies: the DuckDB child, the streaming views and the
    # scheduled S3 road ask the same predicate (this site used to restate
    # ``enabled and apply_to_duckdb`` and skip the child's endpoint-bypass
    # and proxy-URL checks -- two answers to one question).
    try:
        from core.proxy_utils import duckdb_proxy_applies
        return duckdb_proxy_applies("")
    except Exception:
        return False


def _is_s3_cache_active() -> bool:
    """BF-259: Return True when the persistent S3 file cache is opted-in.

    When True, ``setup_registered_views`` routes file reads through
    ``_s3_to_local_via_boto3`` regardless of proxy / on-prem state — so the
    cache benefits ALL S3 setups (direct-AWS, corporate-proxy, on-prem).
    Without this, a direct-AWS user who enables the cache sees no effect
    because the existing pre-download branches gate on proxy or presigned
    mode only.
    """
    try:
        from core.config import s3_local_cache as _sclc
        return bool(_sclc.enabled)
    except Exception:
        return False


def _is_parallel_predownload_active() -> bool:
    """BF-380: Return True when admin has opted in to parallel boto3
    pre-download for query execution on direct-AWS (no proxy, no
    persistent cache).

    When True, ``setup_registered_views`` routes file reads through
    ``_s3_to_local_via_boto3`` to a per-query temp dir (deleted at end).
    32-worker parallel boto3 saturates VPC bandwidth (~1 GB/s),
    typically 3-10× faster than DuckDB serial httpfs for many-file
    queries.

    Files are NOT cached across queries — temp dir cleaned up at
    query end.  Different from s3_local_cache which persists files.
    Use when:
      - direct-AWS-VPC environment (no corporate proxy)
      - many-file queries (1000+ files post-pruning)
      - want speedup without disk-space commitment of persistent cache
    """
    try:
        from core.config import get as _cfg_get
        return bool(_cfg_get("s3", "parallel_predownload_for_query", False))
    except Exception:
        return False


def _extract_reader_override(query_config) -> Optional[str]:
    """BF-428I — pull ``reader_override`` off the query_config (Pydantic
    model OR dict).  Used to honour the per-query reader chip in BQB/CQB.
    Returns None when the field is absent / empty / not a string.

    Whitelist validation happens downstream in
    ``S3ReaderRouter._extract_forced_reader_safe`` so a malicious value
    can't smuggle a reader choice; this helper just extracts."""
    if query_config is None:
        return None
    val = None
    if hasattr(query_config, "reader_override"):
        val = getattr(query_config, "reader_override", None)
    elif isinstance(query_config, dict):
        val = query_config.get("reader_override")
    if not val or not isinstance(val, str):
        return None
    val = val.strip()
    return val or None


def _onprem_pyarrow_tls_from_conn(conn_config: dict):
    """Lift the SAME TLS settings the working on-prem boto3 client used
    (``ssl_verify`` = True | False | CA-bundle path, and the effective
    ``addressing_style``) so the s3fs handshake in the projected reader
    matches boto3 exactly.  Returns ``(tls_verify, addressing_style)``;
    either may be None when it cannot be determined (reader then leaves
    s3fs on botocore defaults and fails open on any TLS error)."""
    tls_verify = None
    addressing_style = None
    try:
        from core.s3_storage import _parse_ssl_verify as _psv
        tls_verify = _psv(conn_config.get("ssl_verify", True))
    except Exception:
        try:
            _sv = conn_config.get("ssl_verify", True)
            tls_verify = not (_sv is False or str(_sv).lower() == "false")
        except Exception:
            tls_verify = None
    try:
        from core.s3_storage import effective_addressing_style as _eas
        addressing_style = _eas(conn_config)
    except Exception:
        addressing_style = None
    return tls_verify, addressing_style


def _compute_projection_for_table(*, raw_sql, query_config, table_name):
    """FAIL-SAFE wrapper around the on-prem column-projection extractor.

    Returns a conservative SUPERSET of the columns ``table_name`` is read
    with in the query, or ``None`` (read ALL columns == today's exact
    behaviour) on ANY doubt.  NEVER raises.

    Only the RAW-SQL on-prem path is projected: the view emitted for
    raw-SQL tables is a plain ``SELECT * FROM read_parquet(...)`` with NO
    JOIN-PRUNER view-WHERE injection (that is gated to STRUCTURED queries
    only — see the ``_raw_sql_present`` guard in setup_registered_views /
    register_s3_views), so the outer raw SQL is the SOLE source of column
    references for the projected file.  In STRUCTURED (BQB) mode we have
    no raw SQL here and deliberately do NOT reconstruct columns from
    query_config — the synthesized view-WHERE could reference columns the
    structured extractor wouldn't see — so we read ALL columns (safe)."""
    try:
        sql = raw_sql or (
            getattr(query_config, "raw_sql", None) if query_config else None)
        if not sql:
            return None
        from core.s3_readers.projection_extractor import columns_for_table
        proj = columns_for_table(sql, table_name, dialect="duckdb")
        if proj:
            logger.info(
                "[s3-readers] on-prem projection for '%s': %d column(s) %s",
                table_name, len(proj), proj[:20])
        return proj
    except Exception as _proj_exc:
        logger.debug("[s3-readers] projection compute failed for '%s' (%s) — "
                     "reading ALL columns (fail-safe)", table_name, _proj_exc)
        return None


def _apply_registered_files_cap(files: list, *, table: str, fmt: str,
                                cap, execution_id: Optional[str] = None):
    """BF-579 ``max_registered_files`` cap — 2026-08-20: the truncation now
    SURFACES instead of masquerading as pruning.

    Returns ``(files, cap_info | None)``.  When the cap fires the list is
    sliced to the LAST ``cap`` entries (most-recent data for typical
    time-partitioned tables — unchanged behaviour) and ``cap_info`` is the
    per-table truncation record from
    ``core.scan_truncation.record_scan_truncation``, which also:

      * merges a ``file_cap`` record into the per-execution diagnostic
        store (visible in the response envelope, DISTINCT from pruning);
      * DOWNGRADES the execution's stored Completeness Certificate to
        INCOMPLETE — the reader-time certificate and the iceberg scan
        ledger both computed their counts BEFORE this slice, so a capped
        scan could previously be certified COMPLETE.

    Callers stash ``cap_info`` into ``_file_stats[table]["file_cap"]`` so
    the envelope's ``after_pruning`` (recorded AFTER the slice) is no
    longer the only trace.  ``cap <= 0`` disables the cap (documented
    knob).  Fail-open on the surfacing, never on the cap itself.

    2026-09-21 (FB-55) — THE ONLY CALLER IS NOW THE ICEBERG BRANCH.  The
    plain-parquet branch used to call this too, and while
    ``scan_budget_hard=1000`` refused first it never fired.  Unifying the
    two file-count gates onto one key that ships OFF let it fire, and it
    dropped 2,300 of 7,300 files behind an HTTP 200 (four region groups
    instead of five).  Removing one ceiling exposed another that answers a
    DIFFERENT question and calls it the same answer.

    It stays here for Iceberg, where 5,000 was actually chosen (raised back
    from BF-579's lowering "for legitimate 3000-file Iceberg BQB scans") and
    where the count comes from a manifest rather than an S3 listing.  Plain
    parquet's single ceiling is ``core/scan_budget.py``, and it REFUSES.
    """
    try:
        cap = int(cap)
    except (TypeError, ValueError):
        cap = 5000
    if cap <= 0 or len(files) <= cap:
        return files, None
    dropped = len(files) - cap
    logger.warning(
        "BF-579: '%s' has %d %s files after pruning, capping to %d (most "
        "recent) — DROPPING %d file(s); the result is a TRUNCATED SUBSET, "
        "not pruning.  Add a partition filter (e.g. date BETWEEN ...) or "
        "raise limits.max_registered_files to scan more.",
        table, len(files), fmt, cap, dropped,
    )
    cap_info = None
    try:
        from core.scan_truncation import record_scan_truncation
        cap_info = record_scan_truncation(
            table=table, kind="max_registered_files",
            reason=(f"max_registered_files cap sliced '{table}' ({fmt}) "
                    f"from {len(files)} to {cap} files after pruning — "
                    f"{dropped} file(s) DROPPED"),
            cap=cap, files_before=len(files), files_registered=cap,
            dropped=dropped, execution_id=execution_id,
        )
    except Exception as _cap_exc:
        logger.warning(
            "BF-579: could not surface the file-cap truncation for '%s' "
            "(%s) — cap still applied", table, _cap_exc)
        cap_info = {"capped": True, "kind": "max_registered_files",
                    "cap": cap, "files_before_cap": len(files),
                    "files_registered": cap, "dropped": dropped}
    return files[-cap:], cap_info


def _try_router_for_presigned(*, s3_client, conn_config: dict,
                               bucket: str, s3_keys: list,
                               table_name: str, progress_fn=None,
                               forced_reader: Optional[str] = None,
                               partition_filters=None,
                               raw_sql: Optional[str] = None,
                               query_config=None):
    """BF-429 — Bridge between setup_registered_views' presigned (on-
    prem) branches and the pluggable S3 reader system.

    Returns IntegrationResult IFF:
      - s3_readers.presigned_router_enabled = True (independent
        master switch from integration_enabled)
      - router picked a reader without error
      - reader returned local_paths OR s3_paths
      - read had zero failed files

    Returns None in any other case so the caller falls through to the
    legacy ``_presigned_to_local`` path with no behaviour change.

    Eligible readers in this mode (auto-declined by AWS-only readers
    via their ``can_handle``):
      - DirectHttpfsReader      → returns presigned HTTPS URLs for DuckDB
      - FullPredownloadReader   → urllib download via shared helper
      - SmartPredownloadReader  → urllib download + cache write
    """
    try:
        from core.s3_readers.integration import (
            read_via_router, presigned_router_enabled,
        )
    except Exception as exc:
        logger.debug("[s3-readers] integration unavailable for presigned "
                     "(%s) — falling through to legacy", exc)
        return None
    if not presigned_router_enabled():
        return None

    # Build the two callbacks the readers consume.  Both wrap the
    # existing _presigned_to_local helper (TLS, retries, hive partition
    # preservation hardened by BF-413..425).
    def _signer(s3_urls: list) -> list:
        return _s3_urls_to_presigned(s3_client, list(s3_urls), conn_config)

    def _downloader(s3_urls: list):
        presigned = _s3_urls_to_presigned(
            s3_client, list(s3_urls), conn_config)
        return _presigned_to_local(
            presigned, conn_config, s3_client=s3_client,
            original_s3_urls=list(s3_urls),
        )

    try:
        from core.s3_readers import S3ReaderRouter
        safe_forced = S3ReaderRouter._extract_forced_reader_safe(
            forced_reader)
    except Exception:
        safe_forced = None

    # ON-PREM PROJECTED READ opt-in.  Only when the master flag is on do
    # we (a) mark the request so pyarrow_s3fs may serve presigned mode and
    # (b) thread the connection's TLS so the s3fs handshake matches boto3.
    # When off (default) these stay False/None and the reader keeps
    # declining presigned mode → legacy predownload runs unchanged.
    _onprem_pyarrow = False
    _tls_verify = None
    _addr_style = None
    _projected_filters = None
    _projection = None
    try:
        from core.config import s3_readers as _srcfg
        if bool(getattr(_srcfg, "onprem_pyarrow_enabled", False)):
            _onprem_pyarrow = True
            _tls_verify, _addr_style = _onprem_pyarrow_tls_from_conn(conn_config)
            # Row-group pruning uses the SAME partition filters already
            # trusted for file-level pruning upstream; pyarrow drops any
            # it can't translate (no wrong pruning) and DuckDB re-applies
            # the full WHERE.  None when caller had no filters.
            _projected_filters = partition_filters or None
            # COLUMN PROJECTION (the other half of the byte win): read only
            # the columns this table's query references.  The extractor is
            # FAIL-SAFE — it returns a conservative SUPERSET or None (read
            # ALL columns).  The reader adds a final schema-parity gate on
            # top.  On ANY doubt (no SQL, parse fail, star, multi-table
            # ambiguity) this stays None → today's behaviour (all columns).
            _projection = _compute_projection_for_table(
                raw_sql=raw_sql, query_config=query_config,
                table_name=table_name)
    except Exception as _flag_exc:
        logger.debug("[s3-readers] onprem_pyarrow flag check failed (%s) — "
                     "staying on legacy presigned path", _flag_exc)
        _onprem_pyarrow = False
        _projection = None

    # The router's auto-select picks predownload/direct — never pyarrow —
    # so unless the operator forced a reader via the per-query chip, we
    # PREFER pyarrow_s3fs when the on-prem projected path is opted in.  If
    # pyarrow can't handle (non-onprem, deps missing) the router falls
    # through to the legacy readers; if it reads but fails, files_failed>0
    # → we return None → caller runs _presigned_to_local.  Fail-open both.
    _effective_forced = safe_forced
    if _onprem_pyarrow and not _effective_forced:
        _effective_forced = "pyarrow_s3fs"
    base_tag = f"presigned;table={table_name}"
    tag = (base_tag + f";forced_reader={_effective_forced}"
           if _effective_forced else base_tag)

    try:
        result = read_via_router(
            s3_client=s3_client,
            bucket=bucket,
            s3_keys=s3_keys,
            projection=_projection,
            filters=_projected_filters,
            progress_callback=(
                (lambda done, total, _t=table_name: progress_fn({
                    "status": "processing",
                    "log": f"{_t}: {done}/{total} files via router (on-prem)",
                })) if progress_fn else None
            ),
            tag=tag,
            presigner=_signer,
            presigned_downloader=_downloader,
            onprem_pyarrow=_onprem_pyarrow,
            s3fs_tls_verify=_tls_verify,
            s3fs_addressing_style=_addr_style,
        )
    except Exception as exc:
        logger.warning("REG-VIEW '%s': presigned router call failed (%s) "
                       "— falling back to legacy _presigned_to_local",
                       table_name, exc)
        return None

    if result is None:
        return None
    if result.output_kind == "error":
        logger.warning("REG-VIEW '%s': presigned router returned error "
                       "(%s) — falling back to legacy", table_name,
                       result.extra.get("error"))
        return None
    if result.files_failed > 0:
        return None
    # SILENT-TRUNCATION GUARD (on-prem projected read): pyarrow_s3fs treats
    # a ``pyarrow_max_rows`` overflow (or a mid-read cancellation) as a
    # SUCCESS with files_failed=0 but a TRUNCATED table.  A truncated view
    # would drop rows the whole-file predownload path returns — silent data
    # loss.  Fail OPEN to predownload so the result stays byte-identical.
    if result.extra.get("row_cap_hit") or result.extra.get("cancelled"):
        logger.warning("REG-VIEW '%s': projected reader returned a "
                       "truncated/cancelled result (row_cap_hit=%s "
                       "cancelled=%s) — falling back to legacy predownload "
                       "for a complete result", table_name,
                       result.extra.get("row_cap_hit"),
                       result.extra.get("cancelled"))
        # Clean up the partial temp parquet the arrow reclassification wrote
        # so the fallback's fresh download doesn't leak it.
        _partial_td = result.extra.get("temp_dir")
        if _partial_td:
            try:
                import shutil as _sh
                _sh.rmtree(_partial_td, ignore_errors=True)
            except Exception:
                pass
        return None
    if result.output_kind in ("local_paths", "s3_paths"):
        # BF-429 audit HIGH-1: when FullPredownloadReader serves on-prem
        # via _presigned_to_local, the helper returns a temp_dir which
        # the legacy fallback path registered via register_temp_dir().
        # The reader carries it forward in extra["temp_dir"]; bridge
        # MUST register it here so the atexit cleanup fires (otherwise
        # PVC accumulates qs_predl_* dirs over time).
        _td_to_register = result.extra.get("temp_dir")
        if _td_to_register:
            try:
                register_temp_dir(_td_to_register)
            except Exception as _reg_exc:
                logger.warning("REG-VIEW '%s': temp_dir register failed "
                               "(%s) — atexit cleanup may not fire for %s",
                               table_name, _reg_exc, _td_to_register)
        return result
    logger.info("REG-VIEW '%s': presigned router returned unexpected kind "
                "%r — using legacy", table_name, result.output_kind)
    return None


def _try_router_for_predownload(*, s3_client, bucket: str, s3_keys: list,
                                 table_name: str, progress_fn=None,
                                 forced_reader: Optional[str] = None,
                                 partition_filters=None,
                                 raw_sql: Optional[str] = None,
                                 query_config=None):
    """BF-428H — Bridge between setup_registered_views and the pluggable
    S3 reader system.

    Returns the IntegrationResult IFF:
      - s3_readers.integration_enabled = True (master switch)
      - router picked a reader without error
      - reader returned local_paths (the only output kind setup_registered_views'
        downstream wiring directly handles today; arrow_table is materialised
        to temp parquet inside integration.py and reclassified to local_paths)
      - read had zero failed files

    Returns None in any other case so the caller can fall through to the
    legacy boto3 pre-download path with no behaviour change.

    Used by both Iceberg (line ~1290) and parquet (line ~1700) branches
    so the integration is consistent across the two branches (BF-428H
    cross-cutting audit C2).

    2026-08-03 (defect fix) — ``partition_filters`` / ``raw_sql`` /
    ``query_config`` mirror the sibling ``_try_router_for_presigned``.
    Without them this bridge passed NO sql, NO projection and NO filters,
    so a routed ``pyarrow_s3fs`` read transferred EVERY column of EVERY
    row group while the cost model scored the reader at ~10%% of bytes —
    arming ``integration_enabled`` would have been strictly SLOWER than
    the legacy path it replaces.  Callers that genuinely lack the context
    (the streaming ``register_s3_views`` path has no raw SQL text) pass
    what they have; projection stays None there (read ALL columns — the
    fail-safe today's behaviour).  Filters must only be passed for tables
    they were TRUSTED against upstream (primary tables — the same scope
    file-level pruning uses); the reader's coercion parity gate drops
    what it can't prove, and DuckDB re-applies the full WHERE either way.
    """
    try:
        from core.s3_readers.integration import read_via_router
    except Exception as exc:
        logger.debug("[s3-readers] integration unavailable (%s) — "
                     "falling through to legacy", exc)
        return None
    # BF-428I — per-query reader override (from BQB/CQB chip): if the
    # caller passed forced_reader=NAME, append it to the tag so the
    # router's forced-reader path picks it (whitelist-validated by
    # S3ReaderRouter._extract_forced_reader_safe).
    from core.s3_readers import S3ReaderRouter
    safe_forced = S3ReaderRouter._extract_forced_reader_safe(forced_reader)
    base_tag = f"setup_registered_views;table={table_name}"
    tag = (base_tag + f";forced_reader={safe_forced}"
           if safe_forced else base_tag)
    # COLUMN PROJECTION — same fail-safe extractor the presigned bridge
    # uses: a conservative SUPERSET of the columns this table is read
    # with, or None (read ALL columns) on ANY doubt.  NEVER raises.
    _projection = _compute_projection_for_table(
        raw_sql=raw_sql, query_config=query_config, table_name=table_name)
    try:
        result = read_via_router(
            s3_client=s3_client,
            bucket=bucket,
            s3_keys=s3_keys,
            sql=raw_sql,
            projection=_projection,
            filters=partition_filters or None,
            progress_callback=(
                (lambda done, total, _t=table_name: progress_fn({
                    "status": "processing",
                    "log": f"{_t}: {done}/{total} files via router",
                })) if progress_fn else None
            ),
            tag=tag,
        )
    except Exception as exc:
        logger.warning("REG-VIEW '%s': router call failed (%s) — "
                       "falling back to legacy predownload",
                       table_name, exc)
        return None
    if result is None:
        return None  # master switch off
    # SILENT-TRUNCATION GUARD (2026-08-03) — mirrors the identical guard in
    # _try_router_for_presigned above.  A ``pyarrow_max_rows`` overflow (or a
    # mid-read cancellation) comes back as a SUCCESS: files_failed=0, kind=
    # local_paths, but a TRUNCATED result.  Accepting it drops rows the
    # legacy predownload would have returned — silent data loss, the worst
    # failure this codebase has.  This bridge was missing the check its
    # sibling has had all along; latent only because
    # s3_readers.integration_enabled defaults False, which makes it a
    # landmine for whoever arms that flag rather than a bug that shows up
    # today.  Fail OPEN to the legacy path so the result stays complete.
    if result.extra.get("row_cap_hit") or result.extra.get("cancelled"):
        logger.warning("REG-VIEW '%s': routed reader returned a "
                       "truncated/cancelled result (row_cap_hit=%s "
                       "cancelled=%s) — falling back to legacy predownload "
                       "for a complete result", table_name,
                       result.extra.get("row_cap_hit"),
                       result.extra.get("cancelled"))
        _partial_td = result.extra.get("temp_dir")
        if _partial_td:
            try:
                import shutil as _sh
                _sh.rmtree(_partial_td, ignore_errors=True)
            except Exception as _rm_exc:
                logger.debug("partial temp cleanup skipped: %s", _rm_exc)
        return None
    if (result.output_kind == "local_paths"
            and result.read_targets
            and result.files_failed == 0):
        # Mirror of the presigned bridge's BF-429 HIGH-1 fix: a reader
        # that materialised into its own temp dir carries it in
        # extra["temp_dir"]; register it so atexit/per-request cleanup
        # fires (otherwise the PVC accumulates qs_arrow_* dirs).
        _td_to_register = result.extra.get("temp_dir")
        if _td_to_register:
            try:
                register_temp_dir(_td_to_register)
            except Exception as _reg_exc:
                logger.warning("REG-VIEW '%s': temp_dir register failed "
                               "(%s) — atexit cleanup may not fire for %s",
                               table_name, _reg_exc, _td_to_register)
        return result
    if result.output_kind == "error":
        logger.warning("REG-VIEW '%s': router returned error (%s) — "
                       "falling back to legacy predownload", table_name,
                       result.extra.get("error"))
    else:
        logger.info("REG-VIEW '%s': router result not directly usable "
                    "(kind=%s failed=%d) — using legacy predownload",
                    table_name, result.output_kind, result.files_failed)
    return None


def _signal_predownload_stage(s3_urls: list) -> None:
    """BF-289: tell the per-execution stage tracker that we're starting
    a boto3 pre-download phase, so heartbeats show "Downloading files
    from S3 (1234 / 4273)" instead of generic "Query still running…"."""
    try:
        execution_id = _DL_EXEC_ID_CTX.get(None)
    except Exception:
        execution_id = None
    if not execution_id:
        return
    try:
        from core import execution_stage as _stg
        _stg.set_stage(execution_id, "boto3_predownload",
                        files_total=len(s3_urls or []),
                        message="Downloading files from S3")
    except Exception:
        pass


def _s3_to_local_via_boto3(s3_client, s3_urls: list,
                            progress_callback=None) -> tuple:
    """Download ``s3://`` URLs to local temp files via boto3 when DuckDB httpfs
    cannot reach S3 through the corporate proxy (HTTP 503).

    BF-416 — body migrated to ``core.s3_predownload.predownload_s3_files``
    (single source of truth shared with duckdb_subprocess).  This wrapper
    preserves the historical signature ``(local_paths, temp_dir)`` and the
    cancel-event resolution via the orchestrator's ``_DL_EXEC_ID_CTX``
    ContextVar.  The atomic-rename semantics, retry policy, ExpiredToken
    handling, persistent cache, Windows MAX_PATH workaround, and progress
    callback are all preserved by the new utility — see that module for
    the consolidated implementation.

    Args:
        progress_callback: Optional ``fn(current, total)`` called periodically.

    Returns ``(local_paths, temp_dir)``.  When cache mode is on, ``temp_dir``
    is None — caller MUST NOT clean up cache files.  When off (default),
    ``temp_dir`` is a per-query temp dir the caller registers for cleanup.
    """
    if not s3_urls:
        return s3_urls, None

    # BF-289: signal "we're starting download" with the file count so
    # heartbeats can render an accurate progress bar.
    _signal_predownload_stage(s3_urls)

    # BF-CANCEL-S3: resolve the cancel event for THIS execution once.  The
    # orchestrator sets ``_DL_EXEC_ID_CTX`` via the ContextVar pattern
    # (BF-289).  When no execution_id is in scope (admin tools, tests) the
    # event is None and every check is a cheap no-op.
    _cancel_event: Optional[threading.Event] = None
    try:
        from core.execution_state import cancellation_flags as _cf
        _exec_id_for_cancel = _DL_EXEC_ID_CTX.get(None)
        if _exec_id_for_cancel:
            _cancel_event = _cf.get(_exec_id_for_cancel)
    except Exception as _ce_err:
        logger.debug("cancel_event lookup failed (non-fatal): %s", _ce_err)

    def _is_cancelled() -> bool:
        return _cancel_event is not None and _cancel_event.is_set()

    # BF-416 — delegate the actual download to the unified utility.
    # Behaviour parity: same workers, same retry, same atomic-rename, same
    # cache hookup, same Windows MAX_PATH handling, same disk guard.
    from core.s3_predownload import (
        predownload_s3_files as _predownload,
        resolve_predownload_config as _resolve_pd_cfg,
    )

    _pd_cfg = _resolve_pd_cfg()

    # Preserve the legacy 2-arg progress signature when caller passed one
    # (utility's callback gets a third ``bytes_delta`` arg).
    _legacy_cb = None
    if progress_callback is not None:
        def _legacy_cb(done: int, total: int, _bytes: int):
            try:
                progress_callback(done, total)
            except Exception:
                pass

    # Update per-execution stage tracker on EVERY completion (BF-289).
    # BF-418 — the import was wrong (core.execution_state has no
    # update_progress; it's in core.execution_stage).  The bare except
    # masked the ImportError, so heartbeats showed a frozen "0 / 4273
    # files" for the entire pre-download.  Also broadcast the WS
    # ``download_progress`` message that the legacy code emitted and
    # the BF-416 migration accidentally dropped — frontend needs it
    # to render the live progress bar in the BQB Alert.
    def _on_progress(done: int, total: int, bytes_delta: int):
        try:
            from core.execution_stage import update_progress
            execution_id = _DL_EXEC_ID_CTX.get(None)
            if execution_id:
                update_progress(execution_id, files_done=done,
                                 bytes_delta=bytes_delta)
        except Exception:
            pass
        # WS broadcast for the BQB live progress bar (BF-418 restore).
        # BF-420 — switched from broadcast_sync to broadcast_to_user_sync
        # so user A's 3000-file scan doesn't flash progress messages in
        # user B's BQB (per-user WS filter pattern, MEMORY a92b692).
        # Falls back to legacy broadcast when execution_id can't be
        # resolved (admin tools, tests).
        if _ws_manager is not None:
            _msg = {
                "type":    "download_progress",
                "current": done,
                "total":   total,
                "phase":   "s3_proxy_predownload",
            }
            try:
                _user_for_ws = None
                _exec_id_for_ws = _DL_EXEC_ID_CTX.get(None)
                if _exec_id_for_ws and _db_manager is not None:
                    try:
                        _row = _db_manager.get_execution(_exec_id_for_ws)
                        _user_for_ws = (_row or {}).get("executed_by")
                    except Exception:
                        pass
                if _user_for_ws:
                    _msg["execution_id"] = _exec_id_for_ws
                    _ws_manager.broadcast_to_user_sync(_user_for_ws, _msg)
                else:
                    _ws_manager.broadcast_sync(_msg)
            except Exception:
                pass
        if _legacy_cb is not None:
            _legacy_cb(done, total, bytes_delta)

    # BF-418 — on ExpiredToken, resolve the conn_id from the s3_client and
    # invalidate the cached handler so the next query rebuilds it with
    # fresh STS creds.  Mirrors the legacy behaviour at the (now-removed)
    # in-place try/except around _is_expt(exc).  Without this, every
    # subsequent query on the same connection would hit the same expired
    # handler until the connection_manager TTL flushed it (~45 min).
    def _on_expired_token(_exc):
        try:
            from core.iceberg_reader import _connection_id_from_s3_client
            from core.connection_manager import get_connection_manager
            _conn_id = _connection_id_from_s3_client(s3_client)
            if _conn_id is not None:
                _cm = get_connection_manager()
                if _cm is not None:
                    _cm.invalidate_s3_handler(
                        int(_conn_id),
                        reason="ExpiredToken in boto3 pre-download",
                    )
        except Exception as _et_exc:
            logger.debug(
                "[s3-predownload] handler invalidate skipped: %s", _et_exc,
            )

    result = _predownload(
        s3_client, list(s3_urls), cfg=_pd_cfg,
        progress_callback=_on_progress,
        is_cancelled=_is_cancelled,
        on_expired_token=_on_expired_token,
    )

    # BF-418 — atexit registration moved INTO the utility so a hard
    # crash mid-download (SIGKILL, OOMKilled, segfault) doesn't orphan
    # the temp dir.  Nothing to do here.

    return result.local_paths, result.temp_dir


# BF-416 — original implementation moved to ``core.s3_predownload``.
# The body above is now a thin wrapper that delegates to the unified
# utility.  See git history for the legacy 470-line in-place
# implementation if you need to compare behaviour.


def _onprem_cache_fetch_fn(download_url: str, ssl_ctx, timeout: float):
    """Phase 10 — build a ``fetch_fn(tmp_path) -> FetchMeta`` closure for
    ``core.onprem_file_cache.cached_download``.  Same urlopen/copy the
    direct-download branch in ``_download_one`` uses, just targeting an
    arbitrary tmp path (inside the cache) instead of the per-query
    ``temp_dir``.  ETag is captured from the response header for free (no
    extra round trip) and stored for future guard checks.
    """
    def _do(tmp_path: str):
        from core.onprem_file_cache import FetchMeta
        req = Request(download_url, headers={"User-Agent": "QueryStudio/1.0"})
        with urlopen(req, context=ssl_ctx, timeout=timeout) as resp:
            etag = resp.headers.get("ETag")
            with open(tmp_path, "wb") as out:
                shutil.copyfileobj(resp, out)
        return FetchMeta(size=os.path.getsize(tmp_path),
                          etag=(etag.strip('"') if etag else None))
    return _do


def _presigned_to_local(presigned_urls: list, conn_config: dict,
                        s3_client=None, original_s3_urls: list | None = None) -> tuple:
    """Download presigned HTTPS URLs to local temp files for on-prem S3.

    DuckDB's bundled httpfs/libcurl cannot reliably connect to on-prem S3
    servers (HTTP 0 or 403 errors due to self-signed certs and SigV4 path
    encoding issues).  Python's urllib/SSL stack works (same as boto3).

    Preserves hive partition directory structure so DuckDB's
    hive_partitioning=true can still extract partition column values.

    Phase 74: Supports retry with URL re-generation on 403 (expired signature).
    Pass s3_client and original_s3_urls to enable retry-on-403.

    Returns (local_paths, temp_dir).  Caller must clean up temp_dir.
    """
    if not presigned_urls:
        return presigned_urls, None

    from core import config as _retry_cfg
    retry_enabled = _retry_cfg.presigned_url.retry_enabled
    max_retries = _retry_cfg.presigned_url.max_retries
    retry_on_403 = _retry_cfg.presigned_url.retry_on_403
    retry_delay = _retry_cfg.presigned_url.retry_delay_seconds

    temp_dir = tempfile.mkdtemp(prefix="qs_stream_dl_")
    ssl_ctx = _build_ssl_ctx(conn_config)

    def _download_one(url: str, idx: int) -> str:
        """Download a single URL. Returns local file path."""
        parsed = urlparse(url)
        url_path = unquote(parsed.path)
        path_segs = url_path.lstrip("/").split("/", 1)
        rel_path = path_segs[1] if len(path_segs) > 1 else f"file_{idx}.parquet"

        canonical_path = quote(parsed.path, safe="/-._~")
        if canonical_path != parsed.path:
            download_url = urlunparse((
                parsed.scheme, parsed.netloc, canonical_path,
                parsed.params, parsed.query, parsed.fragment
            ))
        else:
            download_url = url

        from core.config import presigned_url as _pu_cfg
        _timeout = _pu_cfg.download_timeout_seconds

        # Phase 10 (industrialization.local_file_cache, default OFF) — an
        # on-prem immutable local-disk cache keyed on (host, object path).
        # ``cached_download`` returns None when the flag is off or on ANY
        # internal error, in which case this falls straight through to the
        # unmodified download below — byte-for-byte parity with today.
        try:
            from core.onprem_file_cache import cached_download
            _cached = cached_download(
                url, _onprem_cache_fetch_fn(download_url, ssl_ctx, _timeout))
        except Exception:
            _cached = None
        if _cached is not None:
            _register_cache_pinned_url(url)
            return _cached[0].replace("\\", "/")

        local_file = os.path.join(temp_dir, rel_path)
        os.makedirs(os.path.dirname(local_file), exist_ok=True)

        req = Request(download_url, headers={"User-Agent": "QueryStudio/1.0"})
        with urlopen(req, context=ssl_ctx, timeout=_timeout) as resp:
            with open(local_file, "wb") as out:
                shutil.copyfileobj(resp, out)

        return local_file.replace("\\", "/")

    def _download_with_retry(i: int, url: str) -> tuple:
        """Download one file with retry logic. Returns (index, local_path)."""
        current_url = url
        last_err = None
        for attempt in range(1 + (max_retries if retry_enabled else 0)):
            try:
                return (i, _download_one(current_url, i))
            except Exception as dl_err:
                last_err = dl_err
                is_403 = "403" in str(dl_err) or "Forbidden" in str(dl_err)
                if attempt < max_retries and retry_enabled:
                    if is_403 and retry_on_403 and s3_client and original_s3_urls:
                        logger.warning("Pre-download %d/%d: 403 on attempt %d, re-signing URL",
                                       i + 1, len(presigned_urls), attempt + 1)
                        try:
                            fresh = _s3_urls_to_presigned(s3_client, [original_s3_urls[i]], conn_config)
                            current_url = fresh[0]
                        except Exception:
                            pass
                    else:
                        logger.warning("Pre-download %d/%d: attempt %d failed: %s",
                                       i + 1, len(presigned_urls), attempt + 1, dl_err)
                    import time as _t
                    _t.sleep(retry_delay)
                else:
                    raise last_err
        raise last_err  # unreachable, but satisfies type checker

    try:
        # Phase 103-C: Parallel file download via ThreadPoolExecutor
        from concurrent.futures import ThreadPoolExecutor, as_completed
        from core.s3_utilities import _parallel_workers

        http_tasks = []
        local_paths = [None] * len(presigned_urls)
        for i, url in enumerate(presigned_urls):
            if not url.startswith("http"):
                local_paths[i] = url
            else:
                http_tasks.append((i, url))

        # 2026-08-03 — running volume guard.  This downloader has its OWN
        # urlopen loop; it does NOT go through
        # ``s3_predownload.predownload_s3_files``, so the headroom check
        # added there does not cover it.  Without this, a large island
        # fills the temp volume and the failure surfaces later as an
        # unrelated "I/O file not available" from DuckDB.  Checked every
        # 10 files, not per file.  Fail-open inside the helper.
        def _headroom_check(done: int) -> None:
            if done % 10:
                return
            try:
                from core.s3_predownload import _assert_disk_headroom
                from core.config import s3 as _s3_hr_cfg
                _assert_disk_headroom(
                    temp_dir, float(getattr(_s3_hr_cfg, "min_free_disk_gb", 1.0)),
                    done, len(http_tasks), 0)
            except RuntimeError:
                raise                      # volume exhausted — abort the download
            except Exception as _hr_exc:   # never break a working download
                logger.debug("presigned headroom check skipped: %s", _hr_exc)

        if http_tasks:
            workers = min(len(http_tasks), _parallel_workers())
            _t0 = _time.monotonic()
            if workers <= 1:
                _done_ct = 0
                for i, url in http_tasks:
                    _, path = _download_with_retry(i, url)
                    local_paths[i] = path
                    _done_ct += 1
                    _headroom_check(_done_ct)
            else:
                with ThreadPoolExecutor(max_workers=workers) as pool:
                    futures = {
                        pool.submit(_download_with_retry, i, url): i
                        for i, url in http_tasks
                    }
                    _done_ct = 0
                    for future in as_completed(futures):
                        idx, path = future.result()
                        local_paths[idx] = path
                        _done_ct += 1
                        _headroom_check(_done_ct)

            _elapsed = _time.monotonic() - _t0
            _total_mb = sum(
                os.path.getsize(p.replace("/", os.sep))
                for p in local_paths if p and os.path.exists(p.replace("/", os.sep))
            ) / 1024 / 1024
            logger.info("Pre-downloaded %d presigned files to %s (%.1f MB, %.1fs, %d workers)",
                         len(http_tasks), temp_dir, _total_mb, _elapsed, workers)
        else:
            logger.info("Pre-download: no HTTP URLs to download (%d files passed through)",
                         len(local_paths))
    except Exception:
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception:
            pass
        raise

    return local_paths, temp_dir


def _prefetch_presigned(presigned_urls: list, conn_config: dict) -> None:
    """Phase 10 — prefetch pipelining.  Fire a cache-aware background
    fan-out for ``presigned_urls`` the MOMENT the pruned island file list
    resolves, so the actual downloads overlap the rest of query planning
    (router selection, subprocess hand-off, etc.) instead of serialising
    entirely after it.

    No-op unless ``industrialization.local_file_cache`` is armed.  Never
    raises, never blocks the caller beyond starting a few daemon threads —
    every per-file error is swallowed because the REAL download
    (``_presigned_to_local`` / the subprocess's ``_pre_download_presigned``)
    always runs afterward regardless and is itself cache-aware, so a
    prefetch miss just means "no speedup this time", never a correctness
    or availability issue.
    """
    if not presigned_urls:
        return
    try:
        from core.onprem_file_cache import is_enabled, prefetch
        if not is_enabled():
            return
        ssl_ctx = _build_ssl_ctx(conn_config)
        from core.config import presigned_url as _pu_cfg
        timeout = _pu_cfg.download_timeout_seconds

        def _fetch_fn_for(url: str):
            parsed = urlparse(url)
            canonical_path = quote(parsed.path, safe="/-._~")
            download_url = (
                urlunparse((parsed.scheme, parsed.netloc, canonical_path,
                            parsed.params, parsed.query, parsed.fragment))
                if canonical_path != parsed.path else url)
            return _onprem_cache_fetch_fn(download_url, ssl_ctx, timeout)

        prefetch(list(presigned_urls), _fetch_fn_for)
    except Exception as exc:
        logger.debug("[onprem-cache] prefetch trigger skipped (non-fatal): %s", exc)


def _register_cache_pinned_url(url: str) -> None:
    """Phase 10 — track a URL whose on-prem cache entry was pinned by
    ``cached_download`` (see ``core.onprem_file_cache.OnPremFileCache.
    pin``), so ``cleanup_temp_downloads`` can release the pin once this
    request is done reading it.  Thread-local, mirrors ``register_temp_dir``.
    The pin also self-expires (``pin_ttl_seconds``) so a request path that
    never reaches ``cleanup_temp_downloads`` (an exception before the
    finally block runs) can never permanently block eviction.
    """
    if not hasattr(_thread_local, "cache_pinned_urls"):
        _thread_local.cache_pinned_urls = []
    _thread_local.cache_pinned_urls.append(url)


def register_temp_dir(temp_dir: str):
    """Track a temp download directory for cleanup (thread-local + global atexit)."""
    if temp_dir is None:
        return
    if not hasattr(_thread_local, "temp_dirs"):
        _thread_local.temp_dirs = []
    _thread_local.temp_dirs.append(temp_dir)
    # 78I: Also register globally so atexit can purge on subprocess crash
    with _global_temp_dirs_lock:
        _global_temp_dirs.append(temp_dir)


def unregister_temp_dir(temp_dir: str):
    """BF-420 — opposite of ``register_temp_dir``.  Remove the dir from
    BOTH the thread-local list (so ``cleanup_temp_downloads`` doesn't
    rmtree an already-deleted path) AND the global list (so atexit
    doesn't either).  Safe to call when the dir was never registered
    (no-op) — idempotent.

    Used by ``s3_predownload`` error paths where the downloader created
    the dir, registered it for safety, then rmtree'd it on disk-cap
    failure / path traversal / cancellation.  Without unregistering,
    the registries grow unbounded across the pod's lifetime.
    """
    if temp_dir is None:
        return
    # Thread-local — best-effort; no error if the dir wasn't there.
    tl = getattr(_thread_local, "temp_dirs", None)
    if tl is not None:
        try:
            tl.remove(temp_dir)
        except ValueError:
            pass
    with _global_temp_dirs_lock:
        try:
            _global_temp_dirs.remove(temp_dir)
        except ValueError:
            pass


def evict_s3_cache_lru() -> dict:
    """BF-257: LRU eviction for the persistent S3 file cache.

    Walks the cache directory, sums file sizes, and deletes oldest-by-mtime
    files until total size is below ``s3_local_cache.max_size_gb``.  Safe to
    call concurrently with downloads — a file currently being written has its
    mtime updated continuously, so it won't be the oldest.

    Returns a stats dict ``{total_bytes, evicted, kept}``.  Logged at INFO.
    """
    try:
        from core.config import s3_local_cache as _sclc
    except Exception:
        return {"status": "config_unavailable"}
    if not _sclc.enabled:
        return {"status": "disabled"}
    cache_dir = _sclc.cache_dir
    if not os.path.isdir(cache_dir):
        return {"status": "no_cache_dir", "cache_dir": cache_dir}

    max_bytes = int(_sclc.max_size_gb) * 1024 ** 3

    # Collect (path, size, mtime) for every file in the cache.
    # BF-414 — exclude in-flight ``.t<pid><rand>.<attempt>`` tmp files
    # written by parallel boto3 downloaders (pattern at duckdb_views.py:418
    # / 427).  A multi-GB download has an old mtime relative to its
    # eventual rename target, so without this filter eviction would pick
    # the tmp as "oldest", delete it mid-write, and the writer's
    # subsequent ``os.replace`` would raise ``FileNotFoundError``.  Their
    # bytes also shouldn't count toward the budget because they may
    # disappear in the very next ``os.replace`` (which removes the tmp
    # file by overwriting the destination).
    import re as _re_evict
    _TMP_RE = _re_evict.compile(r"\.t[0-9a-f]+\.\d+$")
    # BF-424 — NFS silly-rename: when a file is unlinked while held open
    # by another NFS client, the server renames it to ``.nfs<hex>`` and
    # keeps it visible until the holder closes.  These show up under
    # os.walk and would otherwise be ranked + deleted by the LRU loop,
    # only to fail with EBUSY (NFSv4) or be silently re-created on next
    # access (NFSv3).  Skip them.
    _NFS_SILLY_RE = _re_evict.compile(r"^\.nfs[0-9a-f]+$")

    entries: list = []
    total_bytes = 0
    skipped_tmp = 0
    skipped_silly = 0
    for root, _dirs, files in os.walk(cache_dir):
        for name in files:
            if _TMP_RE.search(name):
                skipped_tmp += 1
                continue
            if _NFS_SILLY_RE.match(name):
                skipped_silly += 1
                continue
            fp = os.path.join(root, name)
            try:
                st = os.stat(fp)
                entries.append((fp, st.st_size, st.st_mtime))
                total_bytes += st.st_size
            except OSError:
                pass  # file disappeared mid-walk (concurrent eviction) — skip

    if total_bytes <= max_bytes:
        logger.info("[s3_cache] within budget: %.1f GB / %d GB max — no eviction "
                    "(skipped %d in-flight tmp files)",
                    total_bytes / 1024 ** 3, _sclc.max_size_gb, skipped_tmp)
        return {"status": "within_budget", "total_bytes": total_bytes, "max_bytes": max_bytes,
                "evicted": 0, "kept": len(entries)}

    # Sort by mtime ASC — oldest first
    entries.sort(key=lambda e: e[2])

    # BF-424 — re-stat at decision time on NFS deployments.  The os.walk
    # above takes seconds on a 10k-file cache; each file's mtime is then
    # cached in this pod's NFS attribute cache (``actimeo=60`` default)
    # for ~60s.  Other pods may ``os.utime`` files (mark as hot) DURING
    # the walk; the lease-holder still sees the pre-touch mtime and
    # would evict files that are now hot.  Re-stat at the moment of
    # the delete decision forces a fresh server round-trip and skips
    # files that have been touched in the cooldown window.
    _RECENTLY_TOUCHED_S = 300  # don't evict if touched in the last 5 min
    _now = _time.time()

    def _evict_pass(respect_recent_touch: bool):
        """One pass through the sorted entries.  ``respect_recent_touch``
        when True skips files touched in the recency window; when False
        forces eviction regardless (escape hatch for sustained-load
        stall — see comment after pass 1).  Returns
        (bytes_freed_pass, evicted_pass, skipped_recent_pass)."""
        _bf = 0
        _ev = 0
        _sr = 0
        for fp, size, _mt in entries:
            if total_bytes - (bytes_freed + _bf) <= max_bytes:
                break
            try:
                _st_now = os.stat(fp)
                if respect_recent_touch and (_now - _st_now.st_mtime) < _RECENTLY_TOUCHED_S:
                    _sr += 1
                    continue  # touched recently by another pod — keep
                os.remove(fp)
                _bf += size
                _ev += 1
            except FileNotFoundError:
                # Already evicted by another process / stale NFS attr cache
                # showed it as present.  Treat as already evicted.
                pass
            except OSError as exc:
                logger.debug("[s3_cache] eviction failed for %s: %s", fp, exc)
        return _bf, _ev, _sr

    evicted = 0
    bytes_freed = 0
    skipped_recent = 0

    # Pass 1: respect the recency window.
    _bf1, _ev1, _sr1 = _evict_pass(respect_recent_touch=True)
    bytes_freed += _bf1
    evicted += _ev1
    skipped_recent += _sr1

    # BF-424 follow-up — under sustained load every cached file may have
    # been touched in the last 5 min, leaving Pass 1 with bytes_freed=0
    # while disk continues to fill.  When that happens, do a SECOND pass
    # ignoring the recency window (sorted-by-mtime order still gives us
    # least-recently-touched first).  Logged loudly so operators see it
    # as a load signal — usually means the cache is undersized for the
    # working set.
    if (total_bytes - bytes_freed) > max_bytes and _sr1 > 0:
        logger.warning(
            "[s3_cache] LRU pass-1 stalled (skipped %d recently-touched, "
            "freed 0 bytes) — running pass-2 ignoring recency window. "
            "Consider raising s3_local_cache.max_size_gb (currently %.1f GB) "
            "or shortening the recency window.",
            _sr1, _sclc.max_size_gb,
        )
        _bf2, _ev2, _sr2 = _evict_pass(respect_recent_touch=False)
        bytes_freed += _bf2
        evicted += _ev2

    # Best-effort: prune empty parent dirs to keep cache clean
    for root, dirs, files in os.walk(cache_dir, topdown=False):
        if root == cache_dir:
            continue
        if not dirs and not files:
            try:
                os.rmdir(root)
            except OSError:
                pass

    logger.info("[s3_cache] LRU eviction: freed %.1f GB across %d files (%.1f GB → %.1f GB)",
                bytes_freed / 1024 ** 3, evicted,
                total_bytes / 1024 ** 3, (total_bytes - bytes_freed) / 1024 ** 3)
    return {
        "status":           "evicted",
        "total_bytes_before": total_bytes,
        "total_bytes_after":  total_bytes - bytes_freed,
        "max_bytes":          max_bytes,
        "evicted":            evicted,
        "bytes_freed":        bytes_freed,
        "kept":               len(entries) - evicted,
    }


def s3_cache_stats() -> dict:
    """BF-257: read-only stats for the S3 cache (admin / monitoring)."""
    try:
        from core.config import s3_local_cache as _sclc
    except Exception:
        return {"status": "config_unavailable"}
    cache_dir = _sclc.cache_dir
    if not _sclc.enabled:
        return {"status": "disabled", "enabled": False}
    if not os.path.isdir(cache_dir):
        return {"status": "ok", "enabled": True, "cache_dir": cache_dir,
                "file_count": 0, "total_bytes": 0, "max_bytes": int(_sclc.max_size_gb) * 1024 ** 3}
    total_bytes = 0
    file_count = 0
    for root, _d, files in os.walk(cache_dir):
        for name in files:
            try:
                total_bytes += os.path.getsize(os.path.join(root, name))
                file_count += 1
            except OSError:
                pass
    return {
        "status":      "ok",
        "enabled":     True,
        "cache_dir":   cache_dir,
        "file_count":  file_count,
        "total_bytes": total_bytes,
        "max_bytes":   int(_sclc.max_size_gb) * 1024 ** 3,
        "utilisation_pct": round(total_bytes / (int(_sclc.max_size_gb) * 1024 ** 3) * 100, 1) if _sclc.max_size_gb else 0,
    }


def cleanup_temp_downloads():
    """Clean up all temp download directories for the current thread.

    Must be called in the finally block of every streaming endpoint.
    """
    dirs = getattr(_thread_local, "temp_dirs", [])
    if dirs:
        removed, failed = 0, 0
        for d in dirs:
            try:
                shutil.rmtree(d, ignore_errors=True)
                removed += 1
            except Exception as _e:
                failed += 1
                logger.warning("Failed to remove temp dir %s: %s", d, _e)
        if failed:
            logger.warning("cleanup_temp_downloads: %d removed, %d failed", removed, failed)
        else:
            logger.debug("cleanup_temp_downloads: removed %d temp dir(s)", removed)
    _thread_local.temp_dirs = []
    # 78I: Remove cleaned dirs from global registry
    if dirs:
        with _global_temp_dirs_lock:
            for d in dirs:
                try:
                    _global_temp_dirs.remove(d)
                except ValueError:
                    pass

    # Phase 10 — release any on-prem cache read-window pins taken out by
    # this request (see ``_register_cache_pinned_url``).  Best-effort: the
    # cache module no-ops if the flag is off, and the pin self-expires
    # regardless, so a failure here is never a correctness issue.
    pinned = getattr(_thread_local, "cache_pinned_urls", None)
    if pinned:
        try:
            from core.onprem_file_cache import release_all
            release_all(pinned)
        except Exception:
            pass
    _thread_local.cache_pinned_urls = []


# ═══════════════════════════════════════════════════════════════════════════
# SQLCollector
# ═══════════════════════════════════════════════════════════════════════════

class SQLCollector:
    """Fake DuckDB connection that records SQL instead of executing it.

    Used by setup_registered_views(con=collector) to capture CREATE VIEW
    statements so they can be replayed in a crash-isolated subprocess.
    """
    def __init__(self):
        self.statements: list[str] = []

    def execute(self, sql: str):
        self.statements.append(sql)

    def close(self):
        pass


# ═══════════════════════════════════════════════════════════════════════════
# "What SQL is this query?" — ONE answer
# ═══════════════════════════════════════════════════════════════════════════

def effective_raw_sql(raw_sql, query_config) -> Optional[str]:
    """The query's raw SQL, from whichever source carries it.

    2026-08-22 (audit round 4, P0).  ``setup_registered_views`` resolved this
    same fact FIVE different ways in one function, and they disagreed.  The
    chokepoint fallback that extracts unqualified filters read the SQL off
    ``query_config`` (its comment names the callers it exists for: "feed +
    dataflow batch callers"), while the guard deciding whether those filters
    may BIND received only the explicit parameter — so on every path that
    supplies the SQL through the config object, filters were extracted from
    SQL the guard could not see, and the guard was skipped as though there
    were no SQL at all.  The 2026-08-21 row-loss bug stayed live there:
    `core/dataflow/stages/sql_query_stage.py` builds a config shim carrying
    ``raw_sql`` and passes no ``raw_sql=`` parameter.

    A guard wired to one of two sources of the same fact is the dominant
    defect class in this file's history.  There is now one source.
    """
    if raw_sql:
        return raw_sql
    if query_config is None:
        return None
    try:
        found = getattr(query_config, "raw_sql", None)
        if not found and isinstance(query_config, dict):
            found = query_config.get("raw_sql")
        return found or None
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════════════════
# Per-table partition filter helper (JOIN pruning fix)
# ═══════════════════════════════════════════════════════════════════════════

def _compute_table_or_groups(or_groups, tname: str, is_primary: bool,
                             all_table_names=None, raw_sql: str = None):
    """The disjunction's branches SCOPED to one table (2026-10-08), by the
    same rules ``_compute_table_filters`` applies to the AND conjuncts --
    one attribution decision, applied per branch.

    A branch that keeps no predicate for this table is that table's WHOLE
    table, so the union would be everything: the disjunction is dropped for
    this table (None; the reader's ``[island]`` line names the reason at its
    own gate too), never a partial union.  ``or_groups`` may be the keyword
    list of branches or carry inline groups; the answer is a list of
    branches for ``get_iceberg_data_files(or_groups=)``.
    """
    if not or_groups:
        return None
    from core.filter_ops import split_or_groups as _split_or
    _and, groups = _split_or(None, or_groups)
    if len(groups) != 1:
        logger.info(
            "[island] %s: disjunction dropped for this table (%d OR groups "
            "AND-ed together; one is the most a union may carry)", tname, len(groups))
        return None
    scoped = []
    for i, branch in enumerate(groups[0]):
        b = _compute_table_filters(list(branch or []), tname, is_primary,
                                   all_table_names=all_table_names, raw_sql=raw_sql)
        if not b:
            logger.info(
                "[island] %s: disjunction dropped for this table -- branch %d "
                "keeps no predicate here (branch_without_predicate); that "
                "branch would be the whole table", tname, i)
            return None
        scoped.append(b)
    return scoped


def _compute_table_filters(partition_filters, tname: str, is_primary: bool,
                           all_table_names=None, raw_sql: str = None):
    """Compute partition filters applicable to a specific table in a (possibly JOIN) query.

    In single-table queries the frontend sends unqualified column names:
        {col: "business_date", op: "equals", val: "2024-01-01"}

    In JOIN queries the frontend qualifies with the table name:
        {col: "sales_data.business_date", op: "equals", val: "2024-01-01"}

    Rules:
    - Qualified filter (col has '.' or a "table" key):
        → Include if the qualifier matches *tname* exactly, OR — when
          ``all_table_names`` (the connection's registered table names) is
          supplied — when the bare last dot-segment matches UNAMBIGUOUSLY.
          2026-08-02: exact-only matching silently dropped a table's OWN
          predicates whenever the SQL-side name shape differed from the
          registered name (sqlglot resolves aliases to the BARE table name,
          e.g. "fact_table", while registrations may be schema-qualified,
          e.g. "claudestore.fins.fact_table" — and vice-versa).  Dropping
          them zeroed ``partition_filters`` at the reader → full ocean scan
          (PARTITION-PRUNING ALARM case B) even though the WHERE covered
          every partition column.  The bare match mirrors the raw-SQL loop's
          reference matching (execute_api BF-190 fix) and the reader's own
          ``_hive_island_constraints`` scope guard.
          SAFETY: the bare fallback needs ``all_table_names`` because two
          registered tables can share a bare segment ("a.fact" / "b.fact");
          when the qualifier could mean more than one registered table, or
          exactly names a DIFFERENT one, the filter is skipped (fail-open —
          over-scan, never cross-table pruning).  Callers that don't pass
          the registry keep the previous exact-only behaviour.
    - Unqualified filter (no '.'):
        → Include for ALL tables (primary + joined).  The downstream
          filter_iceberg_files_by_partitions() gracefully ignores filters
          whose column doesn't match any hive partition segment, so this
          is safe even when joined tables have different partition schemas.
          This prevents full S3 scans on joined tables that share the same
          partition structure as the primary table.

    Returns a list of normalized (prefix-stripped) filter dicts for this table,
    or None if no applicable filters exist (caller skips pruning entirely).
    """
    if not partition_filters:
        return None

    _tl = tname.lower()

    def _bare(s: str) -> str:
        return str(s).lower().rsplit(".", 1)[-1]

    _names = {str(n).lower() for n in (all_table_names or []) if n}

    def _qual_matches_this_table(qual: str) -> bool:
        ql = str(qual).lower()
        if ql == _tl:
            return True
        if not _names:
            return False       # no registry → exact-only (previous behaviour)
        if _bare(ql) != _bare(_tl):
            return False
        # The qualifier exactly names a DIFFERENT registered table → it
        # belongs there, never here.
        if ql in _names and ql != _tl:
            return False
        # Bare-segment relationship — allow only when THIS table is the
        # single registered candidate for that bare segment.
        _cands = {n for n in _names if _bare(n) == _bare(ql)}
        _cands.add(_tl)   # bare equality with tname proven above
        return len(_cands) == 1

    applicable = []
    for pf in partition_filters:
        col = pf["col"]
        # 2026-07-04 SCOPE FIX: the raw-SQL extractor now carries the table
        # qualifier in a separate "table" key (not embedded in col).  A
        # filter QUALIFIED to a table must ONLY prune that table -- a
        # predicate on a JOINED table (events.date) must never prune the
        # PRIMARY table (fact) just because both have a `date` column.
        qual_table = pf.get("table")
        if qual_table:
            if _qual_matches_this_table(qual_table):
                _pf = {k: v for k, v in pf.items() if k != "table"}
                applicable.append(_pf)
            # else: belongs to a different table — skip (no cross-table prune)
            continue
        if "." in col:
            table_prefix, bare_col = col.rsplit(".", 1)
            if _qual_matches_this_table(table_prefix):
                applicable.append({**pf, "col": bare_col})
            # else: this filter belongs to a different table — skip
        else:
            # ── 2026-08-21 — UNQUALIFIED NO LONGER MEANS "EVERY TABLE" ────
            # The original rule applied an unqualified filter to every table,
            # justified by "filter_iceberg_files_by_partitions() silently
            # ignores filters on non-existing partition columns".  That was
            # TRUE when the hive-path filter was the only consumer.  It is no
            # longer: the same filter now also reaches
            # _file_matches_column_stats and _file_matches_supplement_bounds,
            # which DROP a file whenever the OTHER table happens to have a
            # same-named column.
            #
            # Measured: `WHERE business_close_date >= '2024-01-01'` binds
            # legally to fact_tetb (the CTE projects only k, amt), is emitted
            # UNQUALIFIED, is handed to fact_a as well, and every fact_a file
            # whose date bounds end before 2024 is dropped.  Those rows join
            # on k, not on date — they belong in the answer and vanish
            # silently, HTTP 200, no warning.
            #
            # `is_primary` exists for exactly this and was declared and never
            # read.  The convention it encodes: an unqualified predicate means
            # the ANCHOR table.  So:
            #   * single-table query      -> unambiguous, apply (unchanged)
            #   * multi-table, primary    -> apply (the stated convention)
            #   * multi-table, NON-primary-> DO NOT apply; we cannot prove the
            #     column means the same thing here, and guessing deletes rows.
            # Pruning on the anchor (the big table) is preserved; the join
            # side merely loses a prune it was never entitled to.
            _multi = bool(all_table_names) and len(
                {str(t).lower() for t in all_table_names if t}) > 1
            if _multi and not is_primary:
                logger.debug(
                    "[table-filters] %s: unqualified filter on %r NOT applied "
                    "— multi-table query and this is not the anchor; applying "
                    "it here could drop files whose rows join on another key.",
                    tname, col)
                continue
            # 2026-08-22 — ASK THE SQL.
            #
            # The `is_primary` rule above is correct where the flag carries
            # information, and vacuous where it does not: every raw-SQL caller
            # marks EVERY table primary, because that same set also drives
            # "did all primary tables come back empty" detection.  One set,
            # two jobs, different right answers — so the measured bug
            # (`WITH a AS (SELECT k, amt FROM fact_a) ... WHERE
            # business_close_date >= '2024-01-01'` pruning fact_a on a column
            # its relation does not even expose) walked straight past it.
            #
            # This asks whether any relation over `tname` can expose the
            # column, and skips ONLY on proof that none can.  Every
            # uncertainty — SELECT *, a direct reference, a parse failure —
            # keeps today's behaviour, so it can remove a prune that is
            # provably wrong and can never remove one that is right.
            if _multi and raw_sql:
                try:
                    from core.unqualified_binding import (
                        unqualified_filter_can_bind as _can_bind,
                    )
                    if not _can_bind(raw_sql, tname, col):
                        logger.info(
                            "[table-filters] %s: unqualified filter on %r NOT "
                            "applied — no relation over this table exposes "
                            "that column, so the predicate binds elsewhere "
                            "and pruning here would drop joined rows.",
                            tname, col)
                        continue
                except Exception as _bind_exc:
                    logger.debug(
                        "[table-filters] binding check unavailable for %s.%s "
                        "(keeping current behaviour): %s",
                        tname, col, _bind_exc)
            applicable.append(pf)
    return applicable or None


# ═══════════════════════════════════════════════════════════════════════════
# BF-369: Join-filter propagation across partition columns
# ═══════════════════════════════════════════════════════════════════════════

def _ensure_join_key_bounds_sync(
    bucket: str,
    table_prefix: str,
    join_key_cols: List[str],
    connection_id: Optional[int],
    db_manager,
    s3_conn_config: Optional[Dict[str, Any]] = None,
    max_files: int = 200,
    timeout_s: float = 10.0,
    table_name: Optional[str] = None,
) -> bool:
    """Phase L (2026-06-08) -- self-healing brain.

    When JoinPruner injects a synthesised filter on a target table's
    join-key column, ensure THAT column has bounds available so the
    pruner can actually evaluate the filter on FIRST run (not waiting
    for the next query like BF-547's async path).

    Algorithm:
      1. Check supplement table: does (bucket, prefix) have bounds for
         the join key column(s)?
      2. If yes, no-op -- return True
      3. If no, kick a SYNCHRONOUS scan capped at ``max_files`` parquet
         footers (bound the latency); only scan the join key columns.
      4. On timeout/error, fall through gracefully (BF-547 async path
         still fires later if configured).

    Returns True when bounds are now available (either pre-existing or
    just scanned).  False on any error / timeout.

    Best-effort: never raises.  Logs every decision.
    """
    if not (bucket and table_prefix and join_key_cols and db_manager):
        return False
    cols_lower = [c.split(".")[-1].lower() for c in join_key_cols if c]
    if not cols_lower:
        return False

    # Step 1: do we already have bounds in the supplement?
    try:
        # Phase 160 wire-in: route through brain DuckDB store
        # chokepoint (store-first, DB-fallback, brain_trace).
        from core.brain_duckdb_store import (
            get_col_stats_for_snapshot_via_store,
        )
        existing = get_col_stats_for_snapshot_via_store(
            db_manager,
            bucket=bucket,
            table_prefix=table_prefix,
            snapshot_id="",   # snapshot_id is now advisory per BF-370
            column_names=cols_lower,
        )
        if existing:
            _covered_cols: Set[str] = set()
            for _file_cols in existing.values():
                _covered_cols.update((c or "").lower() for c in _file_cols)
            _missing = [c for c in cols_lower if c not in _covered_cols]
            if not _missing:
                logger.info(
                    "[brain-self-heal] %s/%s already has supplement "
                    "bounds for join keys %s -- no scan needed",
                    bucket, table_prefix, cols_lower,
                )
                return True
            logger.info(
                "[brain-self-heal] %s/%s has bounds for %s but MISSING %s "
                "-- triggering sync scan",
                bucket, table_prefix, sorted(_covered_cols), _missing,
            )
            cols_to_scan = _missing
        else:
            logger.info(
                "[brain-self-heal] %s/%s has NO supplement bounds for "
                "join keys %s -- triggering sync scan (max_files=%d, "
                "timeout=%ds)",
                bucket, table_prefix, cols_lower, max_files, timeout_s,
            )
            cols_to_scan = cols_lower
    except Exception as _ck_exc:
        logger.debug(
            "[brain-self-heal] bounds existence check failed for %s/%s: "
            "%s -- proceeding to scan", bucket, table_prefix, _ck_exc,
        )
        cols_to_scan = cols_lower

    # Step 2: resolve an S3 client + iceberg metadata to know which
    # files to scan.  Bounded by max_files so latency is predictable.
    try:
        from core.iceberg_reader import (
            _latest_metadata_key, _read_s3_json, get_iceberg_data_files,
        )
        from core.s3_utilities import make_s3_client_for_conn
        # Build an S3 client from the connection config OR connection_id
        s3_client = None
        if connection_id is not None and hasattr(db_manager, "get_connection_raw"):
            try:
                _conn = db_manager.get_connection_raw(int(connection_id))
                if _conn:
                    s3_client = make_s3_client_for_conn(_conn)
            except Exception as _conn_exc:
                logger.debug(
                    "[brain-self-heal] connection_raw lookup failed: %s",
                    _conn_exc,
                )
        if s3_client is None and s3_conn_config:
            s3_client = make_s3_client_for_conn(
                {"id": connection_id, "config": s3_conn_config}
            )
        if s3_client is None:
            logger.warning(
                "[brain-self-heal] couldn't build S3 client for %s/%s "
                "(skipped sync scan)", bucket, table_prefix,
            )
            return False

        # Get the data file list, capped at max_files
        files_meta = get_iceberg_data_files(
            s3_client, bucket, table_prefix,
            keys_only=True, max_files=max_files,
            db_manager=db_manager,
        )
        file_keys = [
            m.get("key") or m.get("path") for m in files_meta
            if (m.get("key") or m.get("path"))
        ]
        if not file_keys:
            logger.info(
                "[brain-self-heal] no data files to scan for %s/%s",
                bucket, table_prefix,
            )
            return False

        # Resolve snapshot_id
        try:
            meta_key = _latest_metadata_key(s3_client, bucket,
                                              table_prefix.rstrip("/") + "/metadata/")
            metadata = _read_s3_json(s3_client, bucket, meta_key)
            snapshot_id = str(metadata.get("current-snapshot-id") or "")
        except Exception:
            snapshot_id = ""

        # Step 3: run the scan with a thread + timeout.
        import threading
        from core.iceberg_column_stats import scan_files_to_supplement

        _scan_done = threading.Event()
        _scan_result: Dict[str, Any] = {"ok": False, "err": None}

        def _do_scan():
            try:
                scan_files_to_supplement(
                    db_manager, s3_client, bucket, table_prefix,
                    snapshot_id, file_keys,
                    target_columns=cols_to_scan,
                    max_workers=8,
                    skip_already_scanned=True,
                    connection_id=connection_id,
                    table_name=table_name,
                )
                _scan_result["ok"] = True
            except Exception as exc:
                _scan_result["err"] = str(exc)
            finally:
                _scan_done.set()

        _t = threading.Thread(
            target=_do_scan, daemon=True,
            name=f"qs-brain-self-heal-{table_prefix[:20]}",
        )
        _t.start()
        completed = _scan_done.wait(timeout=timeout_s)
        if not completed:
            logger.warning(
                "[brain-self-heal] sync scan for %s/%s join keys %s "
                "TIMED OUT after %ds -- continuing scan in background, "
                "this query falls back to no-bounds (BF-547 async also "
                "fires later)",
                bucket, table_prefix, cols_to_scan, timeout_s,
            )
            return False
        if _scan_result["err"]:
            logger.warning(
                "[brain-self-heal] sync scan for %s/%s failed: %s",
                bucket, table_prefix, _scan_result["err"],
            )
            return False
        logger.info(
            "[brain-self-heal] sync scan COMPLETE for %s/%s join keys "
            "%s (%d files) -- current query will now prune on join key",
            bucket, table_prefix, cols_to_scan, len(file_keys),
        )
        return True
    except Exception as _scan_exc:
        logger.warning(
            "[brain-self-heal] sync scan errored for %s/%s: %s",
            bucket, table_prefix, _scan_exc,
        )
        return False


def _rescoped_join_mirror(src_filter, target_col, target_table):
    """Copy `src_filter` onto `target_col`, RE-SCOPED to `target_table`.

    Returns None when the target table is unknown — an unscoped mirror is
    applied to every table downstream, which is the row-loss bug this guards.
    """
    _tt = (target_table or "").strip()
    if not _tt:
        return None
    _nf = {k: v for k, v in src_filter.items() if k != "table"}
    _nf["col"] = str(target_col or "").split(".")[-1]
    if not _nf["col"]:
        return None
    _nf["table"] = _tt
    return _nf


def _propagate_join_partition_filters(partition_filters, query_config):
    """When the user JOINs two tables on a partition column AND has a WHERE
    filter on that column for ONE side, mirror the filter to the OTHER
    side so its partition pruning fires too.

    Without this, filtering ``a.date='2025-09-30'`` while joining
    ``a.date = b.date`` leaves table B fully scanned — DuckDB's planner
    doesn't push predicate transitivity down to file listing.

    Conservative — only mirrors filters that match the join keys exactly
    (case-insensitive).  Doesn't infer filters from non-join column
    relationships.

    Returns the new (possibly extended) list of partition filters.
    """
    if not partition_filters or not query_config:
        return partition_filters
    joins = getattr(query_config, "joins", None) or []
    if not joins:
        return partition_filters

    # Build {col_lower: filter_dict} from existing filters for fast lookup.
    # We only mirror filters whose ``col`` matches a join key.  Existing
    # filters take priority — we never overwrite, only append.
    existing_cols = {
        (f.get("col") or f.get("column") or "").split(".")[-1].lower()
        for f in partition_filters
    }

    mirrored: list = list(partition_filters)

    # Track existing QUALIFIED filters too — a qualified filter
    # ``a.date=val`` doesn't reach table b in _compute_table_filters even
    # when the join key has the same column name on both sides.  We need
    # to ADD an unqualified version of such filters (or a qualified
    # version for the other table) so both sides get pruned.
    existing_qualified: set = set()  # {(table_lower, col_lower)}
    existing_unqualified_cols: set = set()  # {col_lower without table prefix}
    for f in partition_filters:
        col = f.get("col") or f.get("column") or ""
        if "." in col:
            tprefix, bcol = col.rsplit(".", 1)
            existing_qualified.add((tprefix.lower(), bcol.lower()))
        else:
            existing_unqualified_cols.add(col.lower())

    # Fixed-point iteration so chained joins propagate transitively:
    # filter on A → mirror to B (via join A↔B) → mirror to C (via join B↔C).
    # Hard cap at len(joins) iterations — a single chained join can only
    # extend by one new column per pass, so this terminates.
    for _ in range(max(1, len(joins))):
        added_this_pass = False
        for jc in joins:
            # JoinConfig has left_on / right_on as lists; handle both
            left_keys = getattr(jc, "left_on", None) or []
            right_keys = getattr(jc, "right_on", None) or []
            if isinstance(left_keys, str):
                left_keys = [left_keys]
            if isinstance(right_keys, str):
                right_keys = [right_keys]
            if len(left_keys) != len(right_keys):
                continue   # malformed join

            # Resolve table aliases from the join's left_file/right_file
            # (e.g. "__registered__:a" → "a") so we can recognise qualified
            # filters that target one specific side of the join.
            left_tab = (getattr(jc, "left_file", None) or "")
            right_tab = (getattr(jc, "right_file", None) or "")
            # 2026-09-05 round 2 -- this copy happened to be COMPLETE,
            # which is exactly why it is retired rather than left alone:
            # four copies in this module, three of them missing an entry,
            # and no way to tell which from the call site.  One owner.
            from core.query_compiler import _strip_virtual as _strip_vp_jk
            left_tab = _strip_vp_jk(left_tab)
            right_tab = _strip_vp_jk(right_tab)
            left_tab_l = left_tab.lower() if left_tab else ""
            right_tab_l = right_tab.lower() if right_tab else ""

            for lk, rk in zip(left_keys, right_keys):
                lk_l = (lk or "").split(".")[-1].lower()
                rk_l = (rk or "").split(".")[-1].lower()
                if not lk_l or not rk_l:
                    continue

                if lk_l == rk_l:
                    # Same column name on both sides of the join.
                    # If the existing filter is QUALIFIED to one table
                    # only (e.g. ``a.date=val``), it doesn't reach the
                    # OTHER side via _compute_table_filters — we need to
                    # add a qualified version for the other side OR an
                    # unqualified copy that applies to both.
                    if lk_l in existing_unqualified_cols:
                        continue   # unqualified covers both sides already
                    # Walk filters; for any qualified filter on this column,
                    # add an unqualified copy (applies to ALL tables).
                    for f in list(mirrored):
                        fcol = f.get("col") or f.get("column") or ""
                        if "." not in fcol:
                            continue
                        _ftab, _fbase = fcol.rsplit(".", 1)
                        if _fbase.lower() != lk_l:
                            continue
                        # 2026-08-21 — was an UNQUALIFIED copy, i.e. "apply
                        # to every table".  Downstream that now reaches the
                        # file-level column-stats / supplement prunes, which
                        # DROP files on a same-named column of an unrelated
                        # table.  The join equality only licenses copying to
                        # the OTHER SIDE of this join, so scope it there.
                        _src_tab = (_ftab or "").split(".")[-1].lower()
                        _other = (right_tab if _src_tab == left_tab_l
                                  else left_tab if _src_tab == right_tab_l
                                  else "")
                        nf = _rescoped_join_mirror(f, _fbase, _other)
                        if nf is None:
                            continue      # cannot name the target — do not guess
                        mirrored.append(nf)
                        existing_cols.add(lk_l)
                        added_this_pass = True
                        break   # one mirrored copy is enough
                    continue

                # Different-name join keys — mirror filter from one column
                # to the other (works whether qualified or not because the
                # propagated copy uses the bare column name).

            # ── 2026-08-21 — A MIRROR MUST BE RE-SCOPED TO ITS TARGET ──────
            # `nf = dict(f)` copies the SOURCE filter wholesale — including
            # its `table` key — and then renames the column to the OTHER
            # side's.  The result carries table A's KEY DOMAIN under table B's
            # COLUMN NAME while still scoped to A:
            #
            #   {'col':'cust_id','val':['C1','C2'],'table':'orders'}
            #     -> {'col':'id','val':['C1','C2'],'table':'orders'}
            #
            # orders' own surrogate `id` is then pruned by CUSTOMER keys and
            # every orders file is dropped — zero/partial rows, HTTP 200, no
            # warning.  Meanwhile `customers`, the intended beneficiary, gets
            # nothing: the propagation is also a no-op in the direction it
            # exists for.
            #
            # The join equality is what licenses the mirror (a.k = b.k means a
            # predicate on a.k holds for b.k), so the copy is valid ONLY when
            # scoped to the table that owns the TARGET column.  left_tab /
            # right_tab are resolved above and were unused here.
            #
            # If the owning table cannot be named we do not mirror at all:
            # an unscoped copy means "every table" downstream, which is the
            # same row-loss bug by another route.
                for f in list(mirrored):
                    fcol = (f.get("col") or f.get("column") or "").split(".")[-1].lower()
                    if fcol == lk_l and rk_l not in existing_cols:
                        nf = _rescoped_join_mirror(f, rk, right_tab)
                        if nf is None:
                            continue
                        mirrored.append(nf)
                        existing_cols.add(rk_l)
                        added_this_pass = True
                    elif fcol == rk_l and lk_l not in existing_cols:
                        nf = _rescoped_join_mirror(f, lk, left_tab)
                        if nf is None:
                            continue
                        mirrored.append(nf)
                        existing_cols.add(lk_l)
                        added_this_pass = True
        if not added_this_pass:
            break   # fixed point reached
    return mirrored


def _iceberg_type_to_duckdb(itype) -> str:
    """Map an iceberg (or already-DuckDB) field type string to a DuckDB type
    for an empty view.  IDEMPOTENT: an already-valid DuckDB type passes
    through, so it is safe to apply to columns from either the iceberg
    metadata (raw iceberg types like ``long``) or the schema cache.  Unknown /
    nested types → VARCHAR (an empty relation's types only need to BIND, and
    VARCHAR casts against anything in a 0-row JOIN)."""
    if not isinstance(itype, str):
        return "VARCHAR"          # struct / list / map (dict types)
    t = itype.strip().lower()
    if not t:
        return "VARCHAR"
    # Already a DuckDB type (idempotent — cols may be pre-mapped, or the cache
    # stored DuckDB types for non-iceberg tables) → pass through.
    _duckdb_ok = {
        "varchar", "bigint", "integer", "int", "double", "float", "real",
        "boolean", "bool", "date", "timestamp", "timestamptz", "time", "blob",
        "uuid", "hugeint", "smallint", "tinyint", "ubigint", "uinteger",
        "usmallint", "utinyint", "interval",
    }
    if t in _duckdb_ok:
        return t.upper()
    if t.startswith("decimal") or t.startswith("numeric"):
        return itype.upper()      # decimal(P,S) is DuckDB-valid
    # Iceberg-specific spellings → DuckDB.
    _m = {"long": "BIGINT", "string": "VARCHAR", "binary": "BLOB"}
    if t in _m:
        return _m[t]
    if t.startswith("timestamptz") or t.startswith("timestamp"):
        return "TIMESTAMP"
    if t.startswith("fixed"):
        return "BLOB"
    # nested (struct / list<...> / map<...> / array) and anything unrecognised
    # → VARCHAR (bind-safe for a 0-row view).
    return "VARCHAR"


def _iceberg_cols_from_metadata(metadata) -> list:
    """Extract ``[{"name","type"}]`` (DuckDB types) from an iceberg metadata
    dict's CURRENT schema.  Partition SOURCE columns are regular schema fields
    in iceberg (the spec requires each partition field's source-id to point at a
    schema field), so this ALWAYS includes them — unlike a parquet-file sample,
    which can physically omit projected-away / non-identity-transform partition
    columns.  Needs no S3 read (metadata is already in hand)."""
    if not isinstance(metadata, dict):
        return []
    schemas = metadata.get("schemas") or []
    cur_id = metadata.get("current-schema-id")
    cur = None
    for s in schemas:
        if isinstance(s, dict) and s.get("schema-id") == cur_id:
            cur = s
            break
    if cur is None:
        cur = (schemas[0] if schemas else metadata.get("schema"))   # v1 fallback
    fields = (cur or {}).get("fields") or [] if isinstance(cur, dict) else []
    out = []
    for f in fields:
        if not isinstance(f, dict):
            continue
        nm = f.get("name")
        if not nm:
            continue
        out.append({"name": nm, "type": _iceberg_type_to_duckdb(f.get("type"))})
    return out


def typed_empty_view_ddl(tname: str, connection_id, db_manager, *,
                          view_name: str = None,
                          force_varchar: bool = False,
                          iceberg_metadata=None) -> "Optional[str]":
    """The ``CREATE OR REPLACE VIEW`` DDL around :func:`typed_empty_select_sql`
    (the SELECT alone is what the federation report road embeds, 2026-10-29)."""
    select = typed_empty_select_sql(tname, connection_id, db_manager,
                                    force_varchar=force_varchar,
                                    iceberg_metadata=iceberg_metadata)
    if select is None:
        return None
    vesc = (view_name or tname).replace('"', '""')
    return f'CREATE OR REPLACE VIEW "{vesc}" AS {select}'


def typed_empty_select_sql(tname: str, connection_id, db_manager, *,
                           force_varchar: bool = False,
                           iceberg_metadata=None) -> "Optional[str]":
    """2026-07-14 — build a ``CREATE OR REPLACE VIEW`` DDL for a 0-row view that
    carries the table's REAL column schema (typed NULLs) from the connection's
    schema cache.  Returns the DDL string, or ``None`` when no cached schema is
    available.

    Shared by both empty-iceberg-table paths (streaming ``setup_registered_
    views`` and the raw-SQL subprocess builder) so an iceberg table that
    resolved to 0 files never becomes a ``SELECT 1 AS dummy`` view — that dummy
    view lacks the real columns and makes a JOIN
    (``ON ext.business_close_date = fact.business_close_date``) crash with a
    Binder error instead of returning 0 rows.

    Emits ``SELECT CAST(NULL AS <type>) AS "<col>" ... WHERE FALSE``.  An empty
    relation's column TYPES are immaterial to a 0-row JOIN, so ``force_varchar``
    yields a bind-safe view even if a declared iceberg type isn't a valid DuckDB
    CAST target.
    """
    cols = []
    # 1) 2026-10-06 -- the iceberg metadata already loaded for THIS query is
    #    the CURRENT schema; the schema cache is a copy taken whenever the
    #    table was last opened, and an ``ALTER TABLE ... ADD COLUMN`` since
    #    then made the empty view lack the new column (a query naming it
    #    failed to bind on an empty island).  Metadata first, cache second.
    if iceberg_metadata is not None:
        cols = _iceberg_cols_from_metadata(iceberg_metadata)
    # 2) No metadata in hand → the schema cache (all columns incl partition
    #    source columns) when the table has been opened before.
    if not cols and connection_id and db_manager is not None:
        try:
            cached = db_manager.get_schema_cache(int(connection_id), tname)
            sd = (cached or {}).get("schema_data") or {}
            cols = sd.get("columns") or []
        except Exception:
            cols = []
    parts = []
    for c in cols:
        cname = c.get("name") or c.get("column_name") or ""
        if not cname:
            continue
        if force_varchar:
            ctype = "VARCHAR"
        else:
            # Always route through the mapper so the DDL is DuckDB-valid
            # regardless of source (schema cache stores RAW iceberg types like
            # "long"/"fixed[16]"/"list"; metadata stores iceberg types too).
            ctype = _iceberg_type_to_duckdb(c.get("type") or c.get("data_type"))
        cesc = cname.replace('"', '""')
        parts.append(f'CAST(NULL AS {ctype}) AS "{cesc}"')
    if not parts:
        return None
    return f'SELECT {", ".join(parts)} WHERE FALSE'


def _create_empty_iceberg_view(con, tname_esc: str, tname: str,
                                connection_id, db_manager,
                                iceberg_metadata=None) -> None:
    """Create (execute) a 0-row view for an iceberg table that resolved to NO
    files, carrying its REAL schema so a JOIN/WHERE binds and returns 0 rows.
    Typed → VARCHAR-coerced → bare-dummy escalation.  See typed_empty_view_ddl.

    2026-07-14 — ``iceberg_metadata`` is threaded through so the COLD-CACHE case
    (table never opened → schema cache empty) still yields a real-schema view
    from the metadata already in hand, instead of the JOIN-breaking bare dummy.
    """
    for _force_varchar in (False, True):
        _ddl = typed_empty_view_ddl(
            tname, connection_id, db_manager, force_varchar=_force_varchar,
            iceberg_metadata=iceberg_metadata)
        if not _ddl:
            break
        try:
            con.execute(_ddl)
            logger.warning(
                "REG-VIEW '%s': iceberg table resolved to 0 files — created a "
                "0-row view with the REAL schema%s so a JOIN/WHERE binds and "
                "returns 0 rows (not a crash).",
                tname, " (types coerced to VARCHAR)" if _force_varchar else "")
            return
        except Exception as _typed_exc:
            logger.debug(
                "REG-VIEW '%s': typed empty view (force_varchar=%s) failed: %s",
                tname, _force_varchar, _typed_exc)
            continue

    # Last resort: no cached schema anywhere → bare dummy view.  Strictly better
    # than a missing view (CatalogException); only happens when never cached.
    con.execute(
        f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT 1 AS dummy WHERE FALSE')
    logger.warning(
        "REG-VIEW '%s': iceberg table resolved to 0 files AND no cached schema "
        "is available — created a bare dummy view. A JOIN referencing this "
        "table's columns may still fail to bind; open the table once (CQB/BQB) "
        "to populate its schema cache.", tname)


# ═══════════════════════════════════════════════════════════════════════════
# _apply_mor_view — single chokepoint for Iceberg V2 merge-on-read views
# ═══════════════════════════════════════════════════════════════════════════

# Iceberg MoR fail-loud refusal -- delete files EXIST for the table but
# provably cannot be applied.  Serving the plain view would silently
# OVERCOUNT.  Declared in ``core.iceberg_mor`` since 2026-10-25 (the
# federation engine and the cross-source road raise the same type without
# importing this module); re-exported here so ``setup_registered_views``'s
# per-table handler, ``api.execute_api`` and every test keep their name.  The
# dedicated type exists so that handler can re-raise THIS error (correctness
# refusal -> query must fail loud) while continuing to record every other
# registration failure in ``_registration_failures`` exactly as before
# (BF-474 semantics unchanged).
from core.iceberg_mor import MorDeletesUnresolvableError  # noqa: E402,F401


def registration_failures_in_scope(failures, scope):
    """Which registration failures affect a query whose tables are ``scope``.

    An EMPTY or MISSING scope means UNKNOWN, and unknown fails CLOSED: every
    failure is treated as in scope.  Returns the in-scope subset (possibly
    empty).  Never raises.  (Moved from ``core.feed_engine`` 2026-09-26 so
    the batch view setup and the feed engine read ONE predicate.)
    """
    try:
        failures = failures or {}
        if not failures:
            return {}
        scope = {str(x).lower() for x in (scope or set()) if x}
        if not scope:
            return dict(failures)
        return {k: v for k, v in failures.items() if str(k).lower() in scope}
    except Exception:
        return dict(failures or {})


def _record_cache_hit_observation(execution_id, bucket, table_prefix,
                                  snapshot_id, n_files, partition_filters,
                                  files_before_prune=None) -> None:
    """One ``query_pruning_history`` row for an Iceberg read served from the
    file-list cache (2026-09-26).  The reader writes this row on a miss; a
    hit never reached it, so the bloom owner (``query_history_prefetcher``)
    ranked an empty history on a rig where the same filtered query ran all
    day.  Same key (execution id), same shape the ranker reads (bucket,
    table_prefix, filter_breakdown[{column, operator}]); ``source`` says it
    came from the cache.

    2026-10-08 -- EVERY hit records (it used to need a partition filter,
    so an unfiltered repeat query left no row and the operator's "how many
    files did this read?" had no answer).  ``files_after_prune`` is the
    cached list's length (what the query reads); ``files_before_prune`` is
    the pre-prune total the cache entry carried (``ice_cache_set(...,
    files_before_prune=)``) and NULL when the entry predates it -- unknown,
    never 0.  A missing execution id falls back to the request's
    ContextVar (the streaming path has no parameter for it); none at all
    is COUNTED by the store, not silently skipped.
    """
    try:
        from core.iceberg_reader import _record_query_observations
        from core.query_diagnostic_store import (
            get_current_execution_id, note_pruning_history_skipped,
            record_pruning_history)
        if not _record_query_observations():
            note_pruning_history_skipped("disabled")
            return
        eid = execution_id or get_current_execution_id()
        if not eid:
            note_pruning_history_skipped("no_execution_id")
            return
        breakdown = []
        for f in partition_filters or []:
            if not isinstance(f, dict):
                continue
            col = str(f.get("col") or f.get("column") or "")
            op = str(f.get("op") or f.get("operator") or "")
            if col and op:
                breakdown.append({"column": col, "operator": op})
        before = None
        if files_before_prune is not None:
            try:
                before = int(files_before_prune)
            except (TypeError, ValueError):
                before = None
        record_pruning_history(str(eid), {
            "bucket": bucket, "table_prefix": table_prefix,
            "snapshot_id": snapshot_id or "",
            "files_before_prune": before, "files_after_prune": int(n_files),
            "stage_drops": {}, "filter_breakdown": breakdown,
            "source": "l1_file_list_cache", "format": "iceberg",
        })
    except Exception as exc:
        logger.warning("cache-hit pruning observation FAILED for %s/%s: %s",
                       bucket, table_prefix, exc)


class ViewRegistrationFailed(RuntimeError):
    """A table this query READS could not be registered (S3 403, network,
    expired credentials...).  Raised by ``setup_registered_views`` so the
    batch callers -- reports, the query builder, published views -- fail
    with the reason instead of reading the missing view as "0 files
    matched" and serving an EMPTY result as success (2026-09-26).  The
    streaming routes had this gate since BF-484 (``_raise_if_registration_
    failed``); the batch path recorded the failure and nobody read it."""


def _apply_mor_view(con, tname, tname_esc, data_files, orig_s3_paths,
                    ice_meta_out, bucket, conn_config, s3_client, s3_prefix,
                    *, log_prefix: str = "REG-VIEW", fail_loud: bool = False,
                    select_only: bool = False):
    # Returns: bool when con is provided (True=MoR view created, False=no deletes
    # -> caller builds plain view); when con is None (deferred/raw-SQL) returns the
    # MoR CREATE VIEW SQL string, or None when there are no applicable deletes.
    # select_only=True (con=None only; 2026-10-25, the federation engine's
    # ``_table_to_expression``): the SELECT body instead of the DDL, so the
    # caller can embed ``(<body>)`` as a FROM expression -- the same statement.
    """Phase 139 Gap 1 — SINGLE chokepoint for the Iceberg V2 merge-on-read
    (MoR) delete-aware view.  Extracted 2026-07-15 from setup_registered_views
    (behaviour there unchanged) so the streaming path (register_s3_views)
    shares ONE implementation instead of a drifting copy.

    Resolves position/equality delete files carried in ``ice_meta_out``
    (filled by iceberg_reader Step 4a when iceberg_mor.enabled=true, or
    restored from the iceberg L1 cache), presigns / pre-downloads them exactly
    like data files, then builds the anti-join view via
    core.iceberg_mor.build_mor_view_sql with ``data_orig_paths`` = the
    ORIGINAL writer s3:// uris (parallel to the rewritten read paths) so
    position deletes match the paths the delete files actually reference.

    Returns True when a MoR view was created (caller must NOT build the plain
    view), False when there are no applicable deletes (caller builds the plain
    view exactly as before).

    fail_loud=False (historical batch behaviour, kept as the parameter
    default for API compatibility): any resolution failure logs a warning and
    falls back to the plain view — deletes will NOT apply (documented
    fail-open overcount).
    fail_loud=True (BOTH production call sites since 2026-07-15 — streaming
    register_s3_views AND batch setup_registered_views): when deletes EXIST
    but provably cannot be applied, raise MorDeletesUnresolvableError
    (a RuntimeError) instead of silently serving an overcounted result —
    unless the admin opted into ``iceberg_mor.allow_stale_reads`` (then warn
    + fall back like the historical batch path).  Tables without delete
    files never reach the loud paths (immediate False), so plain append-only
    queries are unaffected.
    """
    # con=None (F1, 2026-07-15): the raw-SQL direct-S3 builder in execute_api
    # has no live DuckDB connection at resolution time — it assembles a deferred
    # CREATE VIEW string.  When con is None we RESOLVE + BUILD exactly as for the
    # batch/streaming paths but RETURN the SQL string (or None when there are no
    # applicable deletes) instead of executing it, so all THREE Iceberg view
    # builders share this one MoR chokepoint (no drifting copy).
    _defer = con is None
    _mor_pos_raw = (ice_meta_out or {}).get("pos_delete_files") or []
    _mor_eq_raw = (ice_meta_out or {}).get("eq_delete_files") or []
    try:
        from core.iceberg_mor import allow_stale_reads as _mor_allow_stale
        _stale_ok = _mor_allow_stale()
    except Exception:
        _stale_ok = False
    _loud = bool(fail_loud) and not _stale_ok
    if not (_mor_pos_raw or _mor_eq_raw) and data_files:
        # 2026-10-25 -- THE rule for a road handed data files WITHOUT their
        # deletes (core.iceberg_mor.uncollected_deletes_reason): the snapshot
        # summary declares delete files and NO list was collected (the
        # pyiceberg route drops delete entries; a caller with no _out_meta).
        # "No list" used to read as "no deletes" here -> the plain view ->
        # the deleted rows served.  An append-only snapshot (no counter, or
        # 0) is untouched: no extra read, no change.
        from core.iceberg_mor import uncollected_deletes_reason as _uncollected
        _missing = _uncollected(ice_meta_out)
        if _missing:
            if _loud:
                raise MorDeletesUnresolvableError(
                    f"Iceberg MoR: table '{tname}' -- {_missing}; refusing to "
                    f"serve a delete-blind (overcounted) result.  Set "
                    f"iceberg_mor.allow_stale_reads=true to accept data-only reads.")
            logger.warning(
                "%s '%s': %s -- serving the plain view (deletes will NOT apply; "
                "%s)", log_prefix, tname, _missing,
                "allow_stale_reads=true" if _stale_ok else "fail_loud=False")
    if not (_mor_pos_raw or _mor_eq_raw) or not data_files:
        return None if _defer else False

    _mor_pos_paths: list = []
    _mor_eq_files: list = []
    try:
        # Convert delete-file paths to s3:// URLs that the s3 helper can presign
        _mor_pos_s3 = []
        for _df in _mor_pos_raw:
            _fp = _df.get("file_path", "") if isinstance(_df, dict) else ""
            if _fp:
                _mor_pos_s3.append(_iceberg_file_read_url(_fp, bucket))
        # Same s3:// → presigned → pre-download flow as data files
        if _mor_pos_s3:
            _mor_pos_presigned = _s3_urls_to_presigned(s3_client, _mor_pos_s3, conn_config)
            if _get_s3_access_mode(conn_config) == "presigned":
                try:
                    _mor_pos_paths, _mor_pos_tmp = _presigned_to_local(
                        _mor_pos_presigned, conn_config,
                        s3_client=s3_client,
                        original_s3_urls=_mor_pos_s3,
                    )
                    if _mor_pos_tmp:
                        with _global_temp_dirs_lock:
                            _global_temp_dirs.append(_mor_pos_tmp)
                except Exception as _mor_dl_err:
                    # Not a silent-overcount path: the presigned URLs still
                    # carry the deletes into the view; if DuckDB can't read
                    # them the view errors LOUDLY at query time.
                    logger.warning("MoR pos-delete pre-download failed: %s", _mor_dl_err)
                    _mor_pos_paths = _mor_pos_presigned
            else:
                _mor_pos_paths = _mor_pos_presigned
        # Same for equality-delete files
        _mor_eq_s3 = []
        for _df in _mor_eq_raw:
            _fp = _df.get("file_path", "") if isinstance(_df, dict) else ""
            if _fp:
                _mor_eq_s3.append((_iceberg_file_read_url(_fp, bucket), _df))
        if _mor_eq_s3:
            _mor_eq_urls_only = [u for u, _ in _mor_eq_s3]
            _mor_eq_presigned = _s3_urls_to_presigned(s3_client, _mor_eq_urls_only, conn_config)
            if _get_s3_access_mode(conn_config) == "presigned":
                try:
                    _mor_eq_local, _mor_eq_tmp = _presigned_to_local(
                        _mor_eq_presigned, conn_config,
                        s3_client=s3_client,
                        original_s3_urls=_mor_eq_urls_only,
                    )
                    if _mor_eq_tmp:
                        with _global_temp_dirs_lock:
                            _global_temp_dirs.append(_mor_eq_tmp)
                except Exception as _mor_eq_err:
                    logger.warning("MoR eq-delete pre-download failed: %s", _mor_eq_err)
                    _mor_eq_local = _mor_eq_presigned
            else:
                _mor_eq_local = _mor_eq_presigned
            # Rebuild eq_files with local paths
            for (_orig_url, _df), _local_path in zip(_mor_eq_s3, _mor_eq_local):
                _df_copy = dict(_df) if isinstance(_df, dict) else {}
                _df_copy["file_path"] = _local_path
                _mor_eq_files.append(_df_copy)
    except Exception as _mor_err:
        if _loud:
            raise MorDeletesUnresolvableError(
                f"Iceberg MoR: table '{tname}' has {len(_mor_pos_raw)} position "
                f"+ {len(_mor_eq_raw)} equality delete file(s) but they could "
                f"not be resolved ({_mor_err}) — refusing to serve a "
                f"delete-blind (overcounted) result.  Set "
                f"iceberg_mor.allow_stale_reads=true to accept data-only reads."
            ) from _mor_err
        logger.warning("MoR delete-file resolution failed for '%s': %s — falling back to non-MoR view (deletes will NOT apply)", tname, _mor_err)
        _mor_pos_paths = []
        _mor_eq_files = []

    if not (_mor_pos_paths or _mor_eq_files):
        if _loud and (_mor_pos_raw or _mor_eq_raw):
            raise MorDeletesUnresolvableError(
                f"Iceberg MoR: table '{tname}' carries delete-file metadata "
                f"({len(_mor_pos_raw)} pos / {len(_mor_eq_raw)} eq) but none "
                f"resolved to a readable path — refusing to serve a "
                f"delete-blind (overcounted) result.  Set "
                f"iceberg_mor.allow_stale_reads=true to accept data-only reads."
            )
        return None if _defer else False

    # MoR view path: build SQL with anti-join NOT EXISTS clauses
    from core.iceberg_mor import build_mor_select_sql, mor_view_ddl
    # Build fid → name map for equality-delete column resolution.
    # Load schema from S3 (one small read per Iceberg table per query).
    _fid_to_name: dict = {}
    if _mor_eq_files:
        try:
            from core.iceberg_reader import (
                _latest_metadata_key as _lmk,
                _read_s3_json_cached as _rsj,
                _build_schema_index as _bsi,
            )
            _meta_key = _lmk(s3_client, bucket,
                              s3_prefix.rstrip("/") + "/metadata/")
            _meta_dict = _rsj(s3_client, bucket, _meta_key)
            _fid_to_type, _name_to_fid = _bsi(_meta_dict)
            # Invert name_to_fid so we have fid → name
            _fid_to_name = {v: k for k, v in _name_to_fid.items()}
        except Exception as _meta_err:
            logger.warning("MoR fid→name lookup failed (%s) — equality deletes may be skipped",
                           _meta_err)
        if _loud and not _fid_to_name:
            raise MorDeletesUnresolvableError(
                f"Iceberg MoR: table '{tname}' has equality delete file(s) but "
                f"the field-id → column map could not be built — equality "
                f"deletes would be silently skipped (overcount).  Set "
                f"iceberg_mor.allow_stale_reads=true to accept data-only reads."
            )
    # 2026-07-15 — pass the ORIGINAL writer uris (parallel to the rewritten
    # read paths) so the position-delete anti-join matches the delete files'
    # recorded s3:// paths, not the presigned/local read paths.  Without this
    # the overlay is a silent no-op (overcount).
    _mor_orig_paths = None
    if orig_s3_paths and len(orig_s3_paths) == len(data_files):
        _mor_orig_paths = list(orig_s3_paths)
    if (_loud and _mor_pos_paths and _mor_orig_paths is None
            and not all(str(_p).startswith(("s3://", "s3a://", "s3n://"))
                        for _p in data_files)):
        raise MorDeletesUnresolvableError(
            f"Iceberg MoR: table '{tname}' has position delete file(s) but the "
            f"read→original path map is unavailable and the read paths are "
            f"rewritten (presigned/local) — position deletes could not match "
            f"any row (silent overcount).  Set "
            f"iceberg_mor.allow_stale_reads=true to accept data-only reads."
        )
    # 2026-08-04 (f39cf53a caller wiring) — data-file sequence numbers, stamped
    # by iceberg_reader alongside pos/eq_delete_files.  Keys are the ORIGINAL
    # writer uris (manifest-recorded); build_mor_view_sql resolves them via
    # data_orig_paths (and their scheme-normalised forms).  None/missing keeps
    # the global-apply baseline — a re-inserted CDC key is then still
    # suppressed (pre-fix behaviour), never the reverse.
    _mor_seq_map = (ice_meta_out or {}).get("data_seq_by_path") or None
    # 2026-09-25 -- THE read decision (partition values from the files vs the
    # hive path; current-schema projection) is made by core.iceberg_read_plan
    # from the same reader metadata the plain view uses, so the MoR view and
    # the plain view of one table can never answer differently.
    from core.iceberg_read_plan import plan_iceberg_read as _plan_ice_read
    _mor_plan = _plan_ice_read(
        list(data_files), meta=ice_meta_out, union_by_name=True,
        table_name=tname, log_prefix=f"{log_prefix} (MoR)",
    )
    # ONE statement: the SELECT body (what a FROM expression embeds) and the
    # view DDL over it are the same text -- build_mor_view_sql is this pair.
    _mor_body = build_mor_select_sql(
        data_paths=list(data_files),
        pos_delete_paths=_mor_pos_paths,
        eq_delete_files=_mor_eq_files,
        fid_to_name=_fid_to_name,
        data_orig_paths=_mor_orig_paths,
        data_seq_by_path=_mor_seq_map,
        read_plan=_mor_plan,
    )
    _mor_sql = mor_view_ddl(tname_esc, _mor_body)
    if _defer:
        # Raw-SQL path: hand back the SQL string; the caller stamps it as the
        # deferred CREATE VIEW.  Same resolution/fail-loud semantics as above.
        # select_only (federation): the body, embedded as ``(<body>)``.
        logger.info(
            "%s '%s': MoR %s built (deferred) with %d data + %d pos-delete "
            "+ %d eq-delete files (orig-path-map=%s)",
            log_prefix, tname, "SELECT" if select_only else "view SQL",
            len(data_files), len(_mor_pos_paths),
            len(_mor_eq_files), "yes" if _mor_orig_paths else "no",
        )
        return _mor_body if select_only else _mor_sql
    con.execute(_mor_sql)
    logger.info(
        "%s '%s': MoR view with %d data + %d pos-delete + %d eq-delete files (orig-path-map=%s)",
        log_prefix, tname, len(data_files), len(_mor_pos_paths), len(_mor_eq_files),
        "yes" if _mor_orig_paths else "no",
    )
    return True


# ═══════════════════════════════════════════════════════════════════════════
# Runtime join dynamic filtering (2026-07-15, audit finding #6)
# ═══════════════════════════════════════════════════════════════════════════
#
# Trino-style dynamic filtering: after the ANCHOR (build side) table's view
# is registered, collect its ACTUAL distinct join-key values with a bounded
# ``SELECT DISTINCT <key> FROM <anchor_view> WHERE <key> IS NOT NULL
# LIMIT cap+1`` and — ONLY when provably complete — push them as an exact
# IN-list to prune the probe side's files.  This works on multi-valued
# anchor files by construction (it reads real values, not per-file min/max
# singletons, which is where the static ``emit_distinct`` path degrades).
#
# COMPLETENESS PROOF (why the pushed set can never be incomplete):
#   1. The DISTINCT runs against the very DuckDB view the query's JOIN will
#      read (same registered view name, same connection, same resolved file
#      list incl. any MoR delete handling) — so the collected key domain is
#      by construction a SUPERSET of the join keys of every anchor row that
#      can participate in the join (row-level WHERE only shrinks it further).
#   2. It fires only when the reader attested ``file_enumeration_complete``
#      is True (no max_files/max_rows cap truncated the anchor's file walk).
#   3. The LIMIT cap+1 probe proves non-truncation: cap+1 rows back ⇒ the
#      set is a prefix ⇒ push NOTHING (the 7be0324 partial-set class).
#   4. NULL keys are excluded (NULL never satisfies an equi-join) and probes
#      only ever target the UNPRESERVED side of a join (plan_probes matrix).
# Any failure / doubt / unsupported value type ⇒ (None, …) ⇒ nothing pushed
# ⇒ the probe side is merely scanned wider (always safe).

_RUNTIME_DF_FAILED = object()   # memo sentinel: attempted and refused


def _runtime_collect_anchor_distinct(con, anchor_view_name, col_name, cap):
    """Bounded runtime DISTINCT collection.  Returns ``(values, truncated)``.

    ``values`` is None on ANY doubt: query error (view missing / column
    missing), truncation, cap<=0, or a value type outside the proven-safe
    set (int / str / date / datetime — types whose SQL literal rendering
    and cross-type comparison semantics match the join's own).  float /
    Decimal / bytes / anything exotic → refuse (push nothing) rather than
    risk a literal that doesn't round-trip.
    """
    if con is None or not anchor_view_name or not col_name:
        return None, False
    try:
        cap_i = int(cap)
    except (TypeError, ValueError):
        return None, False
    if cap_i <= 0:
        return None, False
    _v = str(anchor_view_name).replace('"', '""')
    _c = str(col_name).replace('"', '""')
    try:
        _res = con.execute(
            f'SELECT DISTINCT "{_c}" FROM "{_v}" '
            f'WHERE "{_c}" IS NOT NULL LIMIT {cap_i + 1}'
        )
        if _res is None:
            # Fake/recording connection (returns None) — cannot prove
            # anything about the data → nothing pushed.
            return None, False
        rows = _res.fetchall()
    except Exception as _exc:
        logger.debug(
            "runtime-DF: DISTINCT probe on %s.%s failed (nothing pushed, "
            "fail-safe): %s", anchor_view_name, col_name, _exc)
        return None, False
    if len(rows) > cap_i:
        logger.info(
            "runtime-DF: anchor %s.%s has >%d distinct join keys (LIMIT "
            "hit ⇒ set would be INCOMPLETE) — nothing pushed.",
            anchor_view_name, col_name, cap_i)
        return None, True
    vals = []
    for _r in rows:
        _val = _r[0]
        if _val is None:
            continue    # NULL never satisfies an equi-join
        # 2026-07-15 DATA-LOSS FIX (adversarial deep-dive): the pushed IN-list
        # flows into the STRING-based manifest-stats pruning stack
        # (_file_matches_column_stats / _manifest_matches_filters), which
        # str()-compares the value against the reader's ISO bounds.  A Python
        # datetime str()s to space-form '2024-01-01 12:00:00' while the reader
        # decodes timestamp bounds to ISO 'T'-form '2024-01-01T…' — ' ' < 'T'
        # lexicographically, so a probe file whose min-bound DATE equals the
        # anchor value is judged "out" and DROPPED (day-partitioned probes are
        # hit dead-center).  The same class bites an int value vs a zero-padded
        # string-typed probe column ('5' vs '05').  Only ``str`` join keys
        # round-trip safely (str(str)==str, and a string key joins a string
        # column).  Non-string keys keep their existing NATIVE static pruning
        # (safe numeric/date BETWEEN) — we simply don't push a runtime IN for
        # them.  Typed keys can return later behind a probe-column-type parity
        # gate (like the bloom parity gate).  Fail-open: push nothing = over-scan.
        if not isinstance(_val, str):
            logger.info(
                "runtime-DF: anchor %s.%s join-key type %s is not string — "
                "nothing pushed (non-string keys need probe-column-type parity; "
                "this avoids the datetime/int-vs-string lexicographic-mismatch "
                "data-loss class).",
                anchor_view_name, col_name, type(_val).__name__)
            return None, False
        vals.append(_val)
    return vals, False


def _maybe_runtime_dynamic_filter(
    jp, con, probe, anchor_view_name,
    anchor_scan_complete, anchor_file_count, memo,
):
    """Attempt a runtime dynamic filter for one probe.  Returns a
    ``SyntheticFilter`` (op ``in``/``equals``, never ``between``) or None.

    Gates, in order (all are refuse-to-push, never refuse-to-scan-wide):
      * runtime flag + JoinPruner master gate on
      * ``anchor_scan_complete is True`` — the reader's completeness
        attestation (missing/None/False all mean NOT proven → no push)
      * anchor file count known, > 0, and within the runtime scan cost cap
      * the pure completeness decision in join_pruner._runtime_join_filter
        (via synthesize_runtime_filter) on the collected set.
    ``memo`` de-duplicates the DISTINCT scan per (anchor, col) within one
    registration pass.
    """
    try:
        if jp is None or con is None:
            return None
        if isinstance(con, SQLCollector):
            # SQL-recording shim (subprocess replay path): it can't fetch
            # results AND the probe SQL must not pollute the replay script.
            return None
        if not jp.runtime_dynamic_filter_enabled():
            return None
        if anchor_scan_complete is not True:
            logger.debug(
                "runtime-DF: anchor '%s' enumeration completeness not "
                "proven — nothing pushed.", probe.anchor_table)
            return None
        try:
            _afc = int(anchor_file_count)
        except (TypeError, ValueError):
            return None
        _scan_cap = jp.runtime_scan_max_anchor_files()
        if _afc <= 0 or (_scan_cap > 0 and _afc > _scan_cap):
            return None
        _memo_key = (probe.anchor_table, probe.anchor_col)
        _hit = memo.get(_memo_key)
        if _hit is _RUNTIME_DF_FAILED:
            return None
        if _hit is None:
            _vals, _truncated = _runtime_collect_anchor_distinct(
                con, anchor_view_name, probe.anchor_col,
                jp.runtime_in_list_max())
            if _vals is None:
                memo[_memo_key] = _RUNTIME_DF_FAILED
                return None
            memo[_memo_key] = (_vals, _truncated)
            _hit = (_vals, _truncated)
        _vals, _truncated = _hit
        return jp.synthesize_runtime_filter(
            probe, _vals, _truncated,
            anchor_fully_scanned=(anchor_scan_complete is True))
    except Exception as _exc:
        logger.debug("runtime-DF: attempt failed (nothing pushed, "
                     "fail-safe): %s", _exc)
        return None


# ═══════════════════════════════════════════════════════════════════════════
# setup_registered_views
# ═══════════════════════════════════════════════════════════════════════════

def setup_registered_views(
    engine,
    query_config,
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    connection_id: int = None,
    progress_fn=None,
    con=None,
    force_fresh_iceberg: bool = False,
    partition_filters=None,  # Caller-provided partition filters (e.g. from raw SQL extraction).
                             # Merged with query_config-extracted filters — use this when
                             # query_config.filters is empty (BQB raw SQL mode).
    or_groups=None,  # BF-568 (2026-05-29): per-branch AND-filter lists
                     # extracted from a top-level OR in the WHERE clause.
                     # The reader runs the iceberg scan once per branch
                     # and UNIONs the resulting file sets — far better
                     # than the previous fail-open full scan when OR
                     # appears across different partition columns.
                     # ``None`` (default) preserves existing behaviour.
    snapshot_id: int = None,             # Phase 139 honest-fix: time-travel — read this Iceberg snapshot
    as_of_timestamp_ms: int = None,      # Phase 139 honest-fix: time-travel — read snapshot at this ts
    referenced_tables=None,              # BF-PRUNE-PERF: when caller has parsed
                                         # the raw SQL and knows which tables are
                                         # actually referenced, pass them here so
                                         # we skip every other registered table.
                                         # Set or list of lowercase table names.
                                         # Was the actual cause of the user-reported
                                         # 4-minute "stage=init" gap — code was
                                         # calling get_iceberg_data_files for
                                         # every table in the connection, not
                                         # just the 2 in the FROM clause.
    db_manager=None,                     # BF-368: when supplied, get_iceberg_data_files
                                         # queries the column-stats supplement table
                                         # for additional file-level pruning on
                                         # filter columns lacking manifest bounds.
                                         # Without this, the supplement is silently
                                         # ignored even when admin has scanned it.
    raw_sql: Optional[str] = None,       # Phase J (2026-06-08): explicit raw SQL
                                         # so JoinPruner.plan_probes_from_raw_joins
                                         # can extract JOIN ON column equalities.
    execution_id: Optional[str] = None,  # Phase V (2026-06-08): pass the
                                         # execution_id EXPLICITLY all the way
                                         # to iceberg_reader so record_pruning
                                         # fires reliably regardless of
                                         # ContextVar propagation (which fails
                                         # in some threading contexts).  Pre-
                                         # Phase-V the recorder depended on
                                         # ContextVar set in
                                         # execute_query_background; when the
                                         # iceberg read ran in a thread that
                                         # didn't inherit it (some worker pool
                                         # threads), execution_id was None and
                                         # record_pruning silently no-op'd.
):
    """Set up DuckDB views for registered S3 tables and build query SQL.

    If *con* is provided (e.g. a SQLCollector), it is used instead of
    creating a real DuckDB connection — this lets callers capture the
    generated SQL without touching DuckDB.

    Resolves __registered__:table_name → DuckDB views backed by:
      - Iceberg: read Iceberg manifests → read_parquet([active files])
      - Parquet: read_parquet('s3://bucket/prefix/**/*.parquet')
      - CSV: read_csv_auto('s3://bucket/prefix/**/*.csv')

    Returns (con, sql, auto_partition_info, all_primary_empty).
    all_primary_empty is True when every primary table was pruned to 0 files.
    Caller MUST close con in a finally block.
    """
    from api.data_grid_api import _duckdb_con_with_s3

    _esc = lambda v: v.replace("'", "''")
    if not execution_id:
        try:
            from core.query_diagnostic_store import get_current_execution_id as _gcei
            execution_id = _gcei()
        except Exception:
            execution_id = None
    own_con = con is None
    if own_con:
        con = _duckdb_con_with_s3(conn_config, connection_id=connection_id)

    # ── Extract hive partition filter from query ──────────────────────────
    from core.s3_utilities import extract_partition_filters_from_query as _extract_pf
    _qc_partition_filters, _pf_warnings = _extract_pf(query_config)
    if _pf_warnings:
        for _w in _pf_warnings:
            logger.warning("Partition filter warning: %s", _w.get("message", _w))
    # Merge caller-provided filters (raw SQL extraction) with query_config filters.
    # Caller filters take priority (prepended); duplicates are harmless — a file
    # must satisfy ALL filters to be included.
    if partition_filters or _qc_partition_filters:
        partition_filters = list(partition_filters or []) + list(_qc_partition_filters or [])
        # BF-369: when the query has JOINs and the JOIN keys are partition
        # columns, propagate WHERE filters across the join so the joined
        # tables also get partition pruning.  Without this, a filter on
        # table A's date doesn't help table B even when joining on date.
        try:
            _propagated = _propagate_join_partition_filters(
                partition_filters, query_config)
            if _propagated and len(_propagated) > len(partition_filters):
                added = len(_propagated) - len(partition_filters)
                logger.info(
                    "setup_registered_views: propagated %d partition filter(s) "
                    "across JOIN keys", added)
                partition_filters = _propagated
        except Exception as _propagate_err:
            logger.debug(
                "Join filter propagation failed (fail-open): %s", _propagate_err)
        logger.info(
            "setup_registered_views: partition_filters=%d "
            "(caller=%d, query_config=%d)",
            len(partition_filters),
            len(partition_filters) - len(_qc_partition_filters or []),
            len(_qc_partition_filters or []),
        )
    else:
        partition_filters = None

    # ── 2026-08-22 — resolve "what SQL is this query" ONCE, here, so the
    # extraction below and the binding guard further down can never disagree
    # about it.  See effective_raw_sql() for the P0 this closes.
    _eff_raw_sql = effective_raw_sql(raw_sql, query_config)

    # ── 2026-08-02 CHOKEPOINT FALLBACK — never enter the reader filterless
    # when the query carries SQL.  Some entry paths (execute_registered_
    # table_copy_to / _query, feed + dataflow batch callers) reach here with
    # NEITHER caller-extracted filters NOR query_config.filters, while the
    # WHERE clause lives in raw SQL.  partition_filters=None means the
    # reader can engage NOTHING — spec-based pruning and the hive-island
    # heal both require a forwarded predicate — so a partitioned table
    # full-ocean-scans at ANY file count (PARTITION-PRUNING ALARM case B).
    # Extract here, at the one place every path converges, with the same
    # extractor (and the same fail-open safety gates) the BQB path uses.
    # Fail-open: any error leaves today's behaviour (no filters, full scan).
    if not partition_filters:
        _fb_raw_sql = _eff_raw_sql
        if _fb_raw_sql:
            try:
                from core.sql_partition_extractor import (
                    extract_combined_filters_and_or_groups_for_iceberg
                    as _fb_extract,
                )
                _fb_pc: dict = {}
                for _fbt in (registered_tables or []):
                    if isinstance(_fbt, dict) and _fbt.get("name"):
                        _fb_pc[_fbt["name"]] = list(
                            _fbt.get("partition_columns") or [])
                _fb_filters, _fb_og = _fb_extract(
                    _fb_raw_sql, _fb_pc, dialect="duckdb")
                # 2026-10-08 -- an OR of AND-groups with NO AND conjunct
                # (the P13 shape) extracts as ([], branches); gating the
                # or_groups on a non-empty AND list dropped them here.
                if _fb_filters or (_fb_og and not or_groups):
                    if _fb_filters:
                        partition_filters = _fb_filters
                    if _fb_og and not or_groups:
                        or_groups = _fb_og
                    logger.info(
                        "setup_registered_views: caller passed no partition_"
                        "filters and query_config.filters is empty — "
                        "extracted %d filter(s) and %d OR branch(es) from raw "
                        "SQL at the chokepoint (prevents a filterless "
                        "full-ocean scan).",
                        len(_fb_filters or []), len(_fb_og or []))
            except Exception as _fb_exc:
                logger.debug(
                    "setup_registered_views: chokepoint raw-SQL filter "
                    "extraction failed (fail-open, no pruning): %s", _fb_exc)

    # ── Determine which tables the query actually references ─────────────
    # Primary tables (FROM clause) → apply partition pruning
    # Joined tables → register but do NOT prune (filters may not apply)
    # Non-referenced tables → skip entirely (avoids S3 errors for unneeded tables)
    _primary_tables = set()   # tables in query_config.files (lowered for case-insensitive match)
    _all_query_tables = set()  # primary + joined (lowered)
    _query_table_originals = {}  # lower→original mapping for view name resolution
    # 2026-09-05 round 2 -- RETIRED ONTO THE OWNER.  This was a FOURTH
    # copy of the prefix vocabulary and it was missing ``__iceberg__:``,
    # so an ``__iceberg__:orders`` ref was classified NON-virtual, never
    # entered ``_primary_tables`` / ``_all_query_tables``, and therefore
    # got NO PARTITION PRUNING -- a full-ocean scan for exactly the table
    # shape pruning exists to serve, with nothing in the logs saying a
    # decision had been declined.  ``core.query_compiler._VIRTUAL_PREFIXES``
    # is the declared owner (``core.join_pruner`` and
    # ``core.parquet_engine_v2`` both ask it), so a sixth prefix added
    # there now reaches this scope with no edit.
    #
    # The LOCAL CONTRACT is preserved exactly: this ``_strip_virtual``
    # answers "" for "not a virtual reference" and the callers below use
    # that falsiness as the test, whereas the owner's returns its argument
    # UNCHANGED.  Translating here rather than at four call sites keeps
    # the one difference in one place.
    from core.query_compiler import _strip_virtual as _qc_strip_virtual
    def _strip_virtual(s: str) -> str:
        _bare = _qc_strip_virtual(s)
        return "" if _bare == s else _bare
    if query_config:
        for _qf in (getattr(query_config, 'files', None) or []):
            _f = _qf if isinstance(_qf, str) else getattr(_qf, 'path', str(_qf))
            _tname = _strip_virtual(_f)
            if _tname:
                _tname_lower = _tname.lower()
                _primary_tables.add(_tname_lower)
                _all_query_tables.add(_tname_lower)
                _query_table_originals[_tname_lower] = _tname
        for _jn in (getattr(query_config, 'joins', None) or []):
            for _jf_attr in ('left_file', 'right_file'):
                _jf = (getattr(_jn, _jf_attr, None) if hasattr(_jn, _jf_attr)
                        else (_jn.get(_jf_attr) if isinstance(_jn, dict) else None))
                if _jf and isinstance(_jf, str):
                    _jtname = _strip_virtual(_jf)
                    if _jtname:
                        _jtname_lower = _jtname.lower()
                        _all_query_tables.add(_jtname_lower)
                        _query_table_originals[_jtname_lower] = _jtname
    # BF-PRUNE-PERF: when caller passed referenced_tables (raw SQL path),
    # use it to populate _all_query_tables so the per-table loop below
    # skips unreferenced tables.  This fixes the "all 5 registered tables
    # processed even though SQL only references 2" bottleneck.
    if referenced_tables:
        _ref_lower = {str(t).lower() for t in referenced_tables if t}
        if _ref_lower:
            _all_query_tables = (_all_query_tables or set()) | _ref_lower
            # If primary_tables is empty (no query_config.files), treat
            # the referenced tables as primary so partition pruning still
            # applies to them.
            if not _primary_tables:
                _primary_tables = set(_ref_lower)
    if _all_query_tables:
        logger.info("PRUNE-SCOPE: primary_tables=%s, all_query_tables=%s", _primary_tables, _all_query_tables)

    _auto_partition_applied = None
    # Track whether ALL primary tables ended up empty (0 files after pruning)
    _all_primary_empty = bool(_primary_tables)  # True if there are primary tables (assume empty until proven otherwise)
    _any_primary_registered_with_data = False
    _registered_ok: set = set()  # track successfully created views
    _file_stats: dict = {}  # Per-table file scan metadata: {tname: {total, after_pruning, format}}
    # 2026-08-20 — per-table scan-set TRUNCATION records (BF-579 cap slice /
    # listing cap), keyed by table so a cache-hit iteration for table B can
    # never inherit table A's record.  Merged into _file_stats[tname]
    # ["file_cap"] at the stats sites so the envelope shows the truncation
    # DISTINCT from pruning ("after_pruning" is recorded AFTER the slice).
    _file_cap_by_table: dict = {}
    # BF-474 (2026-05-19) — registration FAILURES distinct from
    # genuine 0-file pruning.  Populated when a CREATE VIEW raises
    # (S3 403/401, network timeout, etc.).  feed_engine must check
    # this and FAIL the run instead of emitting empty output for
    # tables that exist but couldn't be read.
    _registration_failures: dict = {}

    # ── Create shared S3 client (reused for all tables in this connection) ──
    _shared_s3 = _make_s3_client_for_conn({"id": connection_id, "config": conn_config})

    # ── JOIN-PRUNER (2026-06-01): plan cross-table semi-join probes ──────
    # When the WHERE filters one side of a JOIN but not the other, the
    # OTHER side is normally full-scanned because predicate transitivity
    # isn't pushed down to file listing.  JoinPruner asks the iceberg
    # reader to surface MIN/MAX of the join key over the FILTERED side's
    # surviving files (zero extra S3 reads — bounds are already in the
    # manifest), then synthesises a BETWEEN filter for the OTHER side so
    # its existing column-stats pruning fires.  Probes that don't fire
    # leave behaviour unchanged.  See backend/core/join_pruner.py.
    # Smart brain (2026-06-23): per-query accumulator for iceberg
    # co-access learning.  Appended to as the table loop processes
    # each iceberg table; emitted at function exit to the co-access
    # learner.  The learner records (table_a, table_b) pairs so the
    # watcher can predictively invalidate the neighbour's tick when
    # one advances (data co-evolves on joined tables more often than
    # on unrelated ones).
    _co_access_query_tables: list = []

    _join_probes: list = []
    try:
        from core.join_pruner import JoinPruner as _JP
        # Round 8 — removed dead applicable_callers config gate.
        # JoinPruner now has a single global `enabled` flag; no caller
        # hint plumbing needed.
        _jp = _JP()
        _join_probes = _jp.plan_probes(query_config, partition_filters)
        # JOIN-PRUNER (2026-06-01 deep-audit round 5) — raw-SQL semi-joins.
        # When the query is raw SQL with ``IN (SELECT ...)`` shapes that
        # JoinConfig can't represent, extract them as synthetic probes +
        # anchor partition filters.  Treats inner SELECT col as the
        # anchor's join key column; inner WHERE filters become anchor's
        # partition filters.  Per Trino's rule: "semi-joins with IN
        # conditions are supported."
        # Phase J: prefer the explicit ``raw_sql`` parameter (added 2026-06-08);
        # fall back to query_config attribute for back-compat with callers that
        # may have monkey-patched it.  Pre-Phase-J was ONLY the attribute --
        # which is None because engine QueryConfig dataclass has no raw_sql
        # field, so plan_probes_from_raw_joins NEVER engaged.
        # DELIBERATELY NOT effective_raw_sql(): that would additionally
        # resolve a dict-shaped query_config, which would start JoinPruner
        # synthesizing filters on paths where it never has.  Synthesized
        # filters NARROW, and narrowing is the direction that loses rows —
        # so it needs its own evidence, not a drive-by unification.  Every
        # other reader of "what SQL is this" is the chokepoint above.
        _raw_sql_for_jp = (raw_sql or getattr(query_config, "raw_sql", None) or "")
        if _raw_sql_for_jp:
            try:
                _sj_probes, _sj_filters = _jp.plan_probes_from_semi_joins(
                    _raw_sql_for_jp, partition_filters,
                )
            except Exception as _sj_exc:
                logger.debug("JoinPruner semi-join planning failed: %s", _sj_exc)
                _sj_probes, _sj_filters = [], []
            if _sj_filters:
                # Merge into partition_filters so anchor's iceberg scan
                # is pruned by the inner-WHERE filters.
                partition_filters = list(partition_filters or []) + _sj_filters
            if _sj_probes:
                # Dedupe against existing probes (same key tuple).
                _existing_probe_keys = {
                    (p.anchor_table, p.anchor_col, p.target_table, p.target_col)
                    for p in _join_probes
                }
                for _sp in _sj_probes:
                    _k = (_sp.anchor_table, _sp.anchor_col,
                          _sp.target_table, _sp.target_col)
                    if _k not in _existing_probe_keys:
                        _join_probes.append(_sp)
                        _existing_probe_keys.add(_k)
            # Phase I (2026-06-08) -- raw-SQL JOIN ON probes.  Closes the
            # over-scan bug: when raw SQL has ``JOIN ON a.id = b.id
            # WHERE a.date = 'X'``, the date filter prunes ``a`` but
            # ``b`` was full-scanned because plan_probes() returned []
            # (no JoinConfig from BQB UI for raw SQL).  Now we extract
            # JOIN ON column equivalences from the raw SQL and build
            # probes for each filtered-anchor / unfiltered-target pair.
            try:
                _rj_probes = _jp.plan_probes_from_raw_joins(
                    _raw_sql_for_jp, partition_filters,
                )
            except Exception as _rj_exc:
                logger.debug("JoinPruner raw-JOIN planning failed: %s", _rj_exc)
                _rj_probes = []
            if _rj_probes:
                _existing_probe_keys = {
                    (p.anchor_table, p.anchor_col, p.target_table, p.target_col)
                    for p in _join_probes
                }
                for _rp in _rj_probes:
                    _k = (_rp.anchor_table, _rp.anchor_col,
                          _rp.target_table, _rp.target_col)
                    if _k not in _existing_probe_keys:
                        _join_probes.append(_rp)
                        _existing_probe_keys.add(_k)
                logger.info(
                    "JoinPruner: added %d raw-SQL JOIN ON probe(s); "
                    "total probes=%d",
                    len(_rj_probes), len(_join_probes),
                )
    except Exception as _jp_plan_exc:
        # Fail-OPEN: planning failure must NEVER block normal registration.
        logger.debug("JoinPruner plan_probes failed (fail-open): %s", _jp_plan_exc)
        _jp = None
        _join_probes = []
    _anchor_tables_lower: set = {p.anchor_table for p in _join_probes}
    _target_tables_lower: set = {p.target_table for p in _join_probes}
    # bounds populated AFTER each anchor's manifest read; consumed by
    # targets that follow in the loop.  Empty unless probes fire.
    _join_anchor_bounds: dict = {}      # anchor_table_lower → {col_lower: (lo, hi)}
    _join_anchor_file_count: dict = {}  # anchor_table_lower → int
    _join_anchor_distinct: dict = {}    # anchor_table_lower → {col_lower: [v1,...]}  (SQL IN, cap 200)
    _join_anchor_distinct_bloom: dict = {}  # anchor → {col_lower: [v1,...]}  (COMPLETE set for bloom prune)
    # Runtime dynamic filtering (2026-07-15, audit finding #6):
    #   scan_complete — reader's file_enumeration_complete attestation per
    #   anchor (True == provably no cap truncated the walk; anything else
    #   == not proven ⇒ runtime IN-list must NOT be pushed).
    #   runtime memo — one bounded SELECT DISTINCT per (anchor, col) per
    #   registration pass; _RUNTIME_DF_FAILED marks attempted-and-refused.
    _join_anchor_scan_complete: dict = {}   # anchor_table_lower → bool
    _join_anchor_runtime_memo: dict = {}    # (anchor, col) → (vals, truncated) | _RUNTIME_DF_FAILED

    # Reorder ``registered_tables`` so each table is processed AFTER
    # every table whose probe targets it.  For simple cases (A anchor → B
    # target) phase 0/2 is enough; for chained probes (A → B → C) we need
    # a topological-by-depth sort because B is BOTH a target (of A) and
    # an anchor (for C).  Depth = longest probe-chain distance from any
    # initial-anchor (no incoming probes); ties keep natural order.
    _ordered_registered_tables = list(registered_tables or [])
    if _anchor_tables_lower or _target_tables_lower:
        # depth[t] = max(depth[anchor] + 1) over all probes targeting t.
        # Tables with NO incoming probe stay at depth 0.
        _depth: dict = {(_tb.get("name") or "").lower(): 0
                        for _tb in _ordered_registered_tables}
        for _iter in range(max(2, len(_join_probes) + 1)):
            _changed = False
            for _p in _join_probes:
                _at = _p.anchor_table
                _tt = _p.target_table
                if _at in _depth and _tt in _depth:
                    _new = _depth[_at] + 1
                    if _new > _depth[_tt]:
                        _depth[_tt] = _new
                        _changed = True
            if not _changed:
                break
        def _table_order_key(_tb, _i=[0]):
            _i[0] += 1
            _nm = (_tb.get("name") or "").lower()
            return (_depth.get(_nm, 0), _i[0])
        _ordered_registered_tables.sort(key=_table_order_key)
        logger.debug(
            "JoinPruner: reordered tables — anchors=%s targets=%s depths=%s",
            _anchor_tables_lower, _target_tables_lower,
            {k: v for k, v in _depth.items() if v > 0 or k in _anchor_tables_lower},
        )

    # Runtime dynamic filtering: lower-cased probe table names → the
    # ORIGINAL registered view name (view identifiers are created with the
    # caller's casing; DuckDB matches case-insensitively but we pass the
    # exact name anyway).
    _tbl_name_by_lower: dict = {
        (_tb.get("name") or "").lower(): _tb.get("name")
        for _tb in _ordered_registered_tables
    }

    # 2026-10-08 -- the caller's disjunction, scoped PER TABLE inside the
    # loop (``or_groups`` is rebound per table below, exactly like
    # ``_tbl_filters``); this keeps the caller's value.
    _or_groups_caller = or_groups
    # ── Register each table ──────────────────────────────────────────────
    for tbl in _ordered_registered_tables:
        tname = tbl["name"]
        _tname_lower = tname.lower()
        # Skip tables not referenced by the query (case-insensitive match)
        if _all_query_tables and _tname_lower not in _all_query_tables:
            logger.debug("PRUNE-SCOPE: skipping '%s' — not referenced by query (query_tables=%s)", tname, _all_query_tables)
            continue
        # JOIN-PRUNER: if this table is a target of any probe, build and
        # merge synthesized filter(s) from the anchor's bounds BEFORE
        # computing per-table filters.  Anchors run first (the depth-
        # topological reorder above guarantees this — also handles
        # chained A→B→C cases where B is both target-of-A and anchor-
        # for-C).  Selection considers both BETWEEN bounds AND IN-list
        # distinct values; JoinPruner picks the more selective
        # representation per probe.
        _join_synthesized_local: list = []
        _join_synth_objs_local: list = []  # SyntheticFilter objects (for SQL WHERE injection)
        if _jp and _tname_lower in _target_tables_lower:
            for _probe in _join_probes:
                if _probe.target_table != _tname_lower:
                    continue
                _anchor_bounds = _join_anchor_bounds.get(_probe.anchor_table) or {}
                _anchor_distinct = _join_anchor_distinct.get(_probe.anchor_table) or {}
                _anchor_files = int(_join_anchor_file_count.get(_probe.anchor_table) or 0)
                _sf = None
                if _anchor_bounds or _anchor_distinct:
                    try:
                        _sf = _jp.synthesize_filter(
                            _probe, _anchor_bounds, _anchor_files,
                            anchor_distinct_values=_anchor_distinct or None,
                        )
                    except Exception as _jp_syn_exc:
                        logger.debug("JoinPruner synthesize failed (fail-open): %s", _jp_syn_exc)
                        _sf = None
                # ── RUNTIME DYNAMIC FILTER (2026-07-15, audit finding #6) ─
                # When the static path produced nothing (multi-valued
                # anchor files kill the singleton IN; string ranges are
                # refused) or only a coarse BETWEEN, collect the anchor's
                # ACTUAL distinct join keys from its already-registered
                # view and push a COMPLETE IN-list instead.  Fires only
                # under the completeness proof (anchor enumeration
                # attested complete + DISTINCT not truncated); every
                # other outcome pushes nothing.  The anchor's view exists
                # by now — the depth-topological reorder above registers
                # anchors before their targets.
                if _sf is None or _sf.op == "between":
                    _rt_sf = _maybe_runtime_dynamic_filter(
                        _jp, con, _probe,
                        _tbl_name_by_lower.get(_probe.anchor_table)
                        or _probe.anchor_table,
                        _join_anchor_scan_complete.get(_probe.anchor_table),
                        _join_anchor_file_count.get(_probe.anchor_table),
                        _join_anchor_runtime_memo,
                    )
                    if _rt_sf is not None:
                        _sf = _rt_sf
                if _sf is not None:
                    _join_synthesized_local.append(_sf.as_filter_dict())
                    _join_synth_objs_local.append(_sf)
        # JOIN-PRUNER (2026-06-01 deep-audit round 5) — build a SQL
        # WHERE fragment from the synth filters so DuckDB's row-group
        # pruner can ALSO apply them (manifest-level pruning fires
        # earlier; this gets the cherry on top within surviving files).
        # Empty when no synth filters OR when none can be safely
        # rendered as SQL — fail-open, just miss the row-group cherry.
        #
        # CRITICAL SAFETY (deep-audit round 6, 2026-06-01) — only emit
        # view WHERE for STRUCTURED queries (raw_sql empty).  The view
        # WHERE applies to EVERY reference of the table in the query,
        # which is correct for structured queries (each table appears
        # exactly once in JoinConfig-generated SQL) but UNSAFE for raw
        # SQL where the user might reference the same table standalone:
        #
        #   SELECT b.* FROM a JOIN b ON a.id=b.id WHERE a.day='x'
        #   UNION ALL
        #   SELECT b.* FROM b WHERE b.id > 1000  -- view WHERE would
        #                                        -- incorrectly narrow this
        #
        # Manifest-level pruning is ALWAYS safe (just removes files;
        # DuckDB still filters at row level via the actual JOIN
        # predicate).  Only the row-group cherry is gated.  This trades
        # a small perf optimisation for correctness on the raw-SQL path.
        _raw_sql_present = bool(_eff_raw_sql)
        _join_view_where: str = ""
        if _join_synth_objs_local and not _raw_sql_present:
            _frags = [s.to_sql_where_fragment() for s in _join_synth_objs_local]
            _frags = [f for f in _frags if f]
            if _frags:
                _join_view_where = " AND ".join(_frags)
        elif _join_synth_objs_local and _raw_sql_present:
            logger.debug(
                "JoinPruner: skipping view-WHERE injection for '%s' (raw_sql "
                "path; manifest pruning still fires)", tname,
            )
        # Compute per-table filters: primary tables get unqualified + own qualified filters;
        # joined tables get only their own qualified filters (enables pruning on both sides).
        _tbl_filters = _compute_table_filters(
            partition_filters, tname, _tname_lower in _primary_tables,
            all_table_names=[t.get("name") for t in (registered_tables or [])
                             if isinstance(t, dict) and t.get("name")],
            raw_sql=_eff_raw_sql)
        if _join_synthesized_local:
            # Append the synthesized filters AFTER the existing per-table
            # ones so the iceberg reader processes them in deterministic
            # order (dedup happens inside _file_matches_column_stats via
            # BF-261 key set).
            _tbl_filters = list(_tbl_filters or []) + _join_synthesized_local
            logger.info(
                "JoinPruner: injected %d synthesised filter(s) on '%s' "
                "(now %d filter(s) on this table) — keys: %s",
                len(_join_synthesized_local), tname, len(_tbl_filters),
                [(f.get("col"), f.get("op")) for f in _join_synthesized_local],
            )
            # Phase L (2026-06-08) — self-healing brain.  User asked:
            # "brain should think in all ways - high level of iq".
            # When JoinPruner injects a synth filter (e.g. BETWEEN on the
            # join key for the target table) but the target has NO
            # bounds for that column, the synth filter reaches the
            # iceberg reader but per-file pruning has nothing to compare
            # against -- file kept conservatively -- target still full-
            # scans.  Pre-Phase-L the BF-547 auto-scan fired ASYNC
            # AFTER the read, so the CURRENT query missed out and only
            # the NEXT query benefited.
            #
            # Phase L: detect this case and trigger a SYNCHRONOUS
            # column-stats scan (capped at max_files for latency
            # bound) so the synth filter actually prunes on FIRST run.
            # Best-effort with timeout; on any failure, fall through to
            # the old async behavior.
            # 2026-08-09: this read `fmt`, which is only assigned ~20 lines
            # BELOW inside this same per-table loop body.  First iteration →
            # UnboundLocalError; later iterations → the PREVIOUS table's
            # format.  Read the format off `tbl` directly (identical to the
            # assignment below).
            if (tbl.get("format", "parquet") == "iceberg" and db_manager is not None
                    and tbl.get("s3_prefix")):
                try:
                    _ensure_join_key_bounds_sync(
                        bucket=bucket,
                        table_prefix=tbl["s3_prefix"].rstrip("/"),
                        join_key_cols=[f["col"] for f in _join_synthesized_local
                                        if f.get("col")],
                        connection_id=connection_id,
                        db_manager=db_manager,
                        s3_conn_config=conn_config,
                        max_files=200,
                        timeout_s=10,
                        table_name=tname,
                    )
                except Exception as _ej_exc:
                    logger.debug(
                        "Phase L sync join-key bounds scan failed "
                        "(falling back to async via BF-547): %s",
                        _ej_exc,
                    )
        # 2026-10-08 -- the disjunction's branches scoped to THIS table by the
        # same attribution rules as the AND conjuncts (None = dropped here).
        or_groups = _compute_table_or_groups(
            _or_groups_caller, tname, _tname_lower in _primary_tables,
            all_table_names=[t.get("name") for t in (registered_tables or [])
                             if isinstance(t, dict) and t.get("name")],
            raw_sql=_eff_raw_sql)
        _apply_pruning = bool(_tbl_filters) or bool(or_groups)
        tname_esc = tname.replace('"', '""')
        fmt = tbl.get("format", "parquet")
        prefix = tbl["s3_prefix"].rstrip("/")

        if fmt == "iceberg":
            try:
                # BF-181: Pass partition filters to cache key + get_iceberg_data_files() so
                # Avro manifest-level pruning runs (correct for Iceberg -- data files have no
                # hive-path segments; _filter_iceberg_files_by_partitions was always a no-op).
                _ice_pf = (_tbl_filters or None) if _apply_pruning else None
                # 2026-06-08 -- ScanPlan-style diagnostic.  If the
                # CALLER passed referenced_tables AND partition_filters
                # (signal that the upstream extraction tried), but THIS
                # specific iceberg table ends up with no filters to
                # apply, log a WARNING so the operator can correlate
                # "scan all files" symptoms with "filters didn't reach
                # this table".  Common causes: partition_resolver Tier
                # lookup failed for this table; SQL WHERE references
                # a non-partition column; JOIN propagation didn't fire.
                if (partition_filters and referenced_tables
                        and not _ice_pf and not or_groups):
                    logger.warning(
                        "[duckdb_views] ScanPlan: iceberg table %r will "
                        "FULL-SCAN -- caller passed partition_filters=%d "
                        "(from upstream extraction) but NONE matched this "
                        "table's columns.  Check partition_resolver for "
                        "this table OR the SQL WHERE clause.  "
                        "_tbl_filters=%r",
                        tname, len(partition_filters), _tbl_filters,
                    )
                else:
                    logger.info(
                        "[duckdb_views] ScanPlan: iceberg table %r -- "
                        "pruning=%s, filters_for_this_table=%d",
                        tname, _apply_pruning, len(_tbl_filters or []),
                    )
                # 2026-11-01 -- the run's resolved version of THIS view
                # (core/iceberg_versions.py): a pinned read keys its own
                # entry; any read is validated against the snapshot the run
                # resolved ONCE, never a second probe.
                from core.iceberg_versions import (
                    version_for as _ivf, l1_cache_snapshot_token as _il1)
                _run_ver = _ivf(tname, bucket, tbl.get("s3_prefix"))
                cache_key = _ice_cache_key(connection_id, tname, _ice_pf,
                                           or_groups=or_groups,
                                           snapshot=_il1(_run_ver))
                # BF-505 (2026-05-28) — resolve the CURRENT snapshot
                # before the cache lookup so ice_cache_get can compare
                # against the snapshot stamped at insert time.  Cheap
                # — ``get_iceberg_snapshot_id_only`` reads metadata.json
                # which is BF-503-pointer-verified.  When the snapshot
                # has advanced (e.g., Starburst just wrote new files),
                # the cached entry for an old snapshot is treated as
                # MISS and we re-read manifests for the current
                # snapshot's file list.  Without this, the L2 SQLite
                # cache could serve stale data for up to 5 hours
                # — exactly the "we are following only cached detail"
                # scenario the user reported.
                _current_snap_for_cache = None
                if _run_ver is not None and not force_fresh_iceberg:
                    _current_snap_for_cache = _run_ver.snapshot_id
                elif not force_fresh_iceberg:
                    try:
                        from core.iceberg_reader import get_iceberg_snapshot_id_only as _gsi
                        _current_snap_for_cache = _gsi(_shared_s3, bucket, tbl["s3_prefix"])
                    except Exception as _snap_probe_exc:
                        _current_snap_for_cache = None
                        logger.debug("snapshot probe raised for '%s': %s",
                                     tname, _snap_probe_exc)
                    if _current_snap_for_cache is None:
                        # 2026-08-20 DATA-LOSS FIX (disclosure): this used to
                        # be SILENT — the "" passed below made ice_cache_get's
                        # BF-505 mismatch check a no-op, so a stale cached
                        # file list (missing files committed since the cache
                        # write) was served with nothing in the log OR the
                        # envelope.  The serve still happens (fail-open) but
                        # ice_cache_get now flags it freshness_unverified.
                        logger.warning(
                            "[iceberg-cache] snapshot freshness probe FAILED "
                            "(or table has no current snapshot) for '%s' — a "
                            "cache hit will be served WITHOUT freshness "
                            "verification and flagged freshness_unverified",
                            tname)
                # JOIN-PRUNER (2026-06-01): when this table is an anchor,
                # collect the join-key columns we need MIN/MAX bounds for so
                # subsequent target tables can be pruned.  Anchor MUST bypass
                # the file cache — bounds aren't stored alongside the cached
                # file list, and the manifest re-read needed to compute them
                # is what would be skipped on a cache hit.  Cost: one extra
                # metadata.json + manifest-list.avro read (BF-296 makes
                # manifest CONTENTS cheap), worth it because the surfaced
                # bounds unlock downstream file-count savings on every
                # target table.
                _is_join_anchor = bool(_jp) and _tname_lower in _anchor_tables_lower
                _join_key_cols_for_call = (
                    _jp.anchor_join_columns(tname, _join_probes)
                    if _is_join_anchor else []
                )
                # JOIN-PRUNER cache integration (deep-audit round 4):
                # Only bypass the file cache when this is an anchor AND
                # the cache entry doesn't carry the bounds we need.  This
                # restores the L1/L2 hit rate for repeat queries — the
                # initial implementation bypassed unconditionally, paying
                # an extra metadata read per anchor query.
                cached = None if force_fresh_iceberg else _ice_cache_get(
                    cache_key,
                    current_snapshot_id=str(_current_snap_for_cache or ""),
                )
                # If we're an anchor and the cached entry lacks bounds
                # for any of the join key columns we need, force a fresh
                # read so the new manifest walk surfaces them.
                if cached and _is_join_anchor and _join_key_cols_for_call:
                    _cached_bounds = (cached.get("join_key_bounds") or {})
                    _missing = [c for c in _join_key_cols_for_call
                                if c not in _cached_bounds]
                    if _missing:
                        logger.debug(
                            "JoinPruner: cache hit for '%s' but bounds missing "
                            "for %s — forcing fresh read", tname, _missing,
                        )
                        cached = None
                # 2026-07-15 MoR correctness: an entry that predates delete-file
                # caching (or was promoted from L2, which stores files-only) has
                # no delete-file info.  When iceberg_mor is enabled, serving it
                # would build a delete-BLIND view → silent overcount on V2 tables.
                # Force a fresh resolve so deletes apply; the fresh write then
                # re-populates L1 WITH the delete lists for subsequent hits.
                if (cached is not None
                        and "pos_delete_files" not in cached
                        and "eq_delete_files" not in cached):
                    try:
                        from core.iceberg_mor import is_mor_enabled as _is_mor_on
                        if _is_mor_on():
                            logger.info(
                                "REG-VIEW '%s': MoR enabled but cache entry lacks "
                                "delete-file info (L2/legacy) — forcing fresh "
                                "resolve so deletes apply", tname,
                            )
                            cached = None
                    except Exception:
                        pass
                _ice_snapshot_id = None  # Phase 104: capture for cache fingerprinting
                total_all = 0  # guard: defined even if data_files stays empty
                # 2026-09-28 -- a cached EMPTY list serves only under its
                # PROVEN verdict (see iceberg_cache.ice_cache_set).
                if (cached and not cached.get("files")
                        and (cached.get("empty_island") or {}).get("proven") is not True):
                    logger.info(
                        "REG-VIEW '%s': cached 0-file entry carries no proven "
                        "empty-island verdict -- forcing a fresh resolve", tname)
                    cached = None
                _les_counts = None
                if cached:
                    data_files = cached["files"]
                    _les_counts = cached.get("file_record_counts")  # 2026-10-07 limit early stop
                    # 2026-07-15 — restore delete files from the cache so the MoR
                    # block builds a delete-aware view on cache hits too.  Also
                    # RESETS _ice_meta_out per table, closing the cross-table leak
                    # where a cache-hit table would consume the previous (miss)
                    # table's delete files.  (Force-fresh above guarantees these
                    # keys are present whenever MoR is enabled.)
                    _ice_meta_out = {
                        "pos_delete_files": cached.get("pos_delete_files") or [],
                        "eq_delete_files": cached.get("eq_delete_files") or [],
                        # 2026-09-25 -- read-plan inputs travel with the
                        # entry so a cache hit builds the same view as a miss.
                        "iceberg_read_plan": cached.get("iceberg_read_plan"),
                        # 2026-09-28 -- the empty-island verdict (see above).
                        "empty_island": cached.get("empty_island"),
                    }
                    # Phase 104: snapshot_id for fingerprinting — use cached
                    # value if available.  Do NOT call _latest_metadata_key() here
                    # as it scans thousands of metadata files on every cache hit.
                    # The query-result cache staleness check fetches fresh snapshot
                    # when needed (execute_api cache path).
                    _ice_snapshot_id = cached.get("snapshot_id", "")
                    # 2026-09-26 -- a cache hit is still a QUERY.  The reader
                    # records query_pruning_history, but a hit never reaches
                    # the reader, so a hot table's repeated filtered queries
                    # -- exactly what the bloom owner ranks -- left no row.
                    _record_cache_hit_observation(
                        execution_id, bucket, tbl.get("s3_prefix"),
                        _ice_snapshot_id, len(data_files or []), _ice_pf,
                        files_before_prune=cached.get("files_before_prune"))
                    # JOIN-PRUNER: cached bounds → populate downstream
                    # consumer maps WITHOUT re-running iceberg manifests.
                    if _is_join_anchor:
                        _cached_bounds = cached.get("join_key_bounds") or {}
                        _cached_distinct = cached.get("join_key_distinct_values") or {}
                        _cached_distinct_bloom = cached.get("join_key_distinct_values_bloom") or {}
                        if _cached_bounds:
                            _join_anchor_bounds[_tname_lower] = _cached_bounds
                        if _cached_distinct:
                            _join_anchor_distinct[_tname_lower] = _cached_distinct
                        # BLOOM JOIN-PRUNE (2026-07-13): restore the anchor's
                        # complete distinct set so a repeat join's target
                        # bloom-prune engages even on an anchor cache hit.
                        if _cached_distinct_bloom:
                            _join_anchor_distinct_bloom[_tname_lower] = _cached_distinct_bloom
                        _join_anchor_file_count[_tname_lower] = len(data_files or [])
                        # Runtime-DF completeness attestation (2026-07-15):
                        # only an explicit True stored at cache-write time
                        # counts; legacy/L2-promoted entries lack the key
                        # (None) ⇒ not proven ⇒ no runtime IN-list push.
                        _join_anchor_scan_complete[_tname_lower] = (
                            cached.get("file_enumeration_complete") is True)
                else:
                    from core.iceberg_reader import get_iceberg_data_files
                    _ice_meta_out = {}
                    # Phase V (2026-06-08) -- stamp execution_id explicitly
                    # so iceberg_reader.get_iceberg_data_files's
                    # record_pruning at the end never silently no-ops on
                    # ContextVar miss.  Belt-and-suspenders with Phase K.
                    if execution_id:
                        _ice_meta_out["execution_id"] = execution_id
                    # Phase 156 (2026-06-25) -- compute sql_hash so the
                    # reader's memo can short-circuit on the next
                    # identical query.  Only meaningful when the raw
                    # SQL is available (BQB raw mode, PV, feed-gen all
                    # carry it).  Falls through to None when missing
                    # which keeps today's behaviour.
                    _phase156_sql_hash: Optional[str] = None
                    try:
                        _phase156_raw_sql = _eff_raw_sql or ""
                        if _phase156_raw_sql:
                            from core.agg_cache import make_sql_hash as _mk_sh156
                            _phase156_sql_hash = _mk_sh156(_phase156_raw_sql) or None
                    except Exception:
                        _phase156_sql_hash = None
                    raw_files = get_iceberg_data_files(_shared_s3, bucket, tbl["s3_prefix"],
                                                       partition_filters=_ice_pf,
                                                       keys_only=True, _out_meta=_ice_meta_out,
                                                       force_fresh=force_fresh_iceberg,
                                                       snapshot_id=snapshot_id,
                                                       as_of_timestamp_ms=as_of_timestamp_ms,
                                                       db_manager=db_manager,
                                                       or_groups=or_groups,  # BF-568
                                                       join_key_columns=_join_key_cols_for_call or None,
                                                       # 2026-07-23 island heal: the reader
                                                       # needs to know WHICH table this leg
                                                       # is (B3 filter scoping + hive-path
                                                       # island fallback attribution).
                                                       table_name=tname,
                                                       sql_hash=_phase156_sql_hash)
                    # 2026-07-14 DATA-LOSS SAFETY NET (streaming parity with the
                    # subprocess path): the synth join-key filters are a
                    # semi-join OPTIMIZATION; they must never be the reason the
                    # target is empty.  If they pruned this table to 0 files,
                    # re-read using ONLY its own WHERE filters (WITHOUT synth) and
                    # adopt those files if any — else a cross-table value-encoding
                    # mismatch the reconciliation didn't bridge silently drops
                    # every join row.  Fully fault-tolerant: cap-bypass only when
                    # bounded, and swallow any error.
                    if not raw_files and _join_synthesized_local:
                        try:
                            _presynth_pf = _compute_table_filters(
                                partition_filters, tname,
                                _tname_lower in _primary_tables,
                                all_table_names=[
                                    t.get("name")
                                    for t in (registered_tables or [])
                                    if isinstance(t, dict) and t.get("name")],
                                raw_sql=_eff_raw_sql)
                            _sn_cap_off = bool(_presynth_pf)
                            _sn_reread = get_iceberg_data_files(
                                _shared_s3, bucket, tbl["s3_prefix"],
                                partition_filters=_presynth_pf or None,
                                keys_only=True, _out_meta={},
                                force_fresh=force_fresh_iceberg,
                                snapshot_id=snapshot_id,
                                as_of_timestamp_ms=as_of_timestamp_ms,
                                db_manager=db_manager, or_groups=or_groups,
                                table_name=tname,   # 2026-07-23 island heal
                                enforce_max_files_cap=(not _sn_cap_off),
                            ) or []
                            if _sn_reread:
                                logger.warning(
                                    "STREAM SAFETY NET: synth join filter(s) pruned "
                                    "'%s' to 0 files — re-read WITHOUT synth has %d "
                                    "files; using those (correctness over "
                                    "selectivity).", tname, len(_sn_reread))
                                raw_files = _sn_reread
                        except Exception as _sn_exc:
                            logger.warning(
                                "STREAM SAFETY NET: re-read for '%s' failed (%s) — "
                                "leaving empty (0-row view).", tname, _sn_exc)
                    _ice_snapshot_id = _ice_meta_out.get("snapshot_id") or ""
                    # Phase 156 (2026-06-25) -- surface the resolved
                    # snapshot id back to the caller's query_config so
                    # execute_api Hook 6 (brain pruning memo write) +
                    # the dispatcher path's brain_router consultation
                    # can both key on the actual snapshot.  Pre-fix
                    # only the PV path set _iceberg_snapshot_id, so
                    # BQB/CQB/Feed/Reports queries silently couldn't
                    # populate or consult the brain memo.
                    try:
                        if isinstance(query_config, dict) and _ice_snapshot_id:
                            # First-table-wins: the brain memo is keyed
                            # on (sql_hash, snapshot) -- when a query
                            # joins two iceberg tables the snapshot of
                            # the FIRST iceberg table is the authoritative
                            # one (matches Hook 6 logic).  Don't
                            # overwrite if already set (PV path wins).
                            if not query_config.get("_iceberg_snapshot_id"):
                                query_config["_iceberg_snapshot_id"] = str(_ice_snapshot_id)
                    except Exception:
                        pass
                    # BLOOM JOIN-PRUNE moved DOWNSTREAM (2026-07-13 fix):
                    # it must run AFTER _ice_cache_set so the shared
                    # (conn, table, partition_filter) cache stores the FULL
                    # file list, never a query-specific pruned one.  See the
                    # post-cache, view-local prune below the cache write.
                    # JOIN-PRUNER: surface bounds + distinct values +
                    # file count so the target-table iteration below can
                    # consume them.  Distinct values (IN-list singletons)
                    # are populated only when every surviving file had
                    # single-value bounds for the column.
                    if _is_join_anchor:
                        _jkb = _ice_meta_out.get("join_key_bounds") or {}
                        if _jkb:
                            _join_anchor_bounds[_tname_lower] = _jkb
                        _jkd = _ice_meta_out.get("join_key_distinct_values") or {}
                        if _jkd:
                            _join_anchor_distinct[_tname_lower] = _jkd
                        _jkd_bloom = _ice_meta_out.get("join_key_distinct_values_bloom") or {}
                        if _jkd_bloom:
                            _join_anchor_distinct_bloom[_tname_lower] = _jkd_bloom
                        _join_anchor_file_count[_tname_lower] = len(raw_files or [])
                        # Runtime-DF completeness attestation (2026-07-15):
                        # explicit True from the reader ONLY (missing key
                        # ⇒ not proven ⇒ no runtime IN-list push).
                        _join_anchor_scan_complete[_tname_lower] = (
                            _ice_meta_out.get("file_enumeration_complete") is True)
                    # BF-299: auto-add this table to the watched registry so
                    # the background sync job keeps its metadata fresh.
                    try:
                        from core.iceberg_metadata_sync import note_query_against
                        note_query_against(connection_id, bucket, tbl["s3_prefix"])
                    except Exception:
                        pass
                    # Smart brain (2026-06-23): record this iceberg table
                    # in the per-query accumulator so we can learn
                    # co-access patterns at function exit (used by the
                    # watcher to predictively invalidate frequent-pair
                    # neighbours when one advances).  Accumulator is
                    # initialised at the top of setup_registered_views.
                    try:
                        _co_access_query_tables.append(
                            (bucket, tbl["s3_prefix"]))
                    except (NameError, AttributeError):
                        pass
                    _rc = sum(f.get("record_count", 0) for f in raw_files if isinstance(f, dict))
                    data_files = [
                        f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                        for f in raw_files
                    ]
                    _les_counts = [f.get("record_count") if isinstance(f, dict) else None
                                   for f in raw_files]
                    # JOIN-PRUNER: cache bounds + distinct values
                    # alongside file list so subsequent queries with
                    # the same partition filters serve them from L1
                    # without re-walking manifests.
                    _ice_cache_set(
                        cache_key, data_files, None,
                        record_count=_rc, snapshot_id=str(_ice_snapshot_id),
                        join_key_bounds=_ice_meta_out.get("join_key_bounds") or {},
                        join_key_distinct_values=_ice_meta_out.get("join_key_distinct_values") or {},
                        join_key_distinct_values_bloom=_ice_meta_out.get("join_key_distinct_values_bloom") or {},
                        # 2026-07-15 — cache the resolved delete files so repeat
                        # queries on this MoR table rebuild the delete-aware view.
                        pos_delete_files=_ice_meta_out.get("pos_delete_files") or [],
                        eq_delete_files=_ice_meta_out.get("eq_delete_files") or [],
                        # Runtime-DF completeness attestation travels with the
                        # entry so an anchor cache hit can still prove itself.
                        file_enumeration_complete=_ice_meta_out.get("file_enumeration_complete"),
                        iceberg_read_plan=_ice_meta_out.get("iceberg_read_plan"),
                        empty_island=_ice_meta_out.get("empty_island"),
                        file_record_counts=_les_counts,
                        # 2026-10-08 -- so a HIT records the counts the
                        # cache carried (NULL when the reader did not count).
                        files_before_prune=_ice_meta_out.get("files_before_prune"),
                    )

                # ── 2026-10-07 LIMIT-ONLY EARLY STOP (core/limit_early_stop.py) ──
                # A statement answered by ANY n rows of this table reads only
                # the first files whose manifest record counts reach n -- the
                # cache above keeps the FULL list; only this query's view is
                # narrowed.  Declines (and logs why) on anything else.
                if data_files and _eff_raw_sql:
                    try:
                        from core.limit_early_stop import plan_limit_early_stop as _les_plan
                        _les_kept = _les_plan(
                            _eff_raw_sql, tname, data_files,
                            _les_counts or [None] * len(data_files),
                            _ice_meta_out, road="setup_registered_views",
                            bucket=bucket, table_prefix=tbl.get("s3_prefix"),
                            execution_id=execution_id)
                    except Exception as _les_exc:  # noqa: BLE001 -- never break the read
                        logger.debug("[limit-early-stop] skipped for %r: %s", tname, _les_exc)
                        _les_kept = None
                    if _les_kept is not None:
                        data_files = _les_kept
                # ── 2026-09-28 THE EMPTY ISLAND (consumer side) ──────────
                # An empty file list may become an empty view (the BF-504
                # path below) ONLY when the reader PROVED it: every drop
                # independently justified by the pruning gate.  The reader
                # re-proves and widens itself before answering, so an
                # unproven empty here means the reader was bypassed (a
                # pre-fix cache entry, an error path).  Unknown is not
                # empty: widen to the full enumeration; if even that cannot
                # be read, REFUSE rather than serve 0 rows as success.
                if not data_files and _apply_pruning:
                    from core.pruning_gate import (
                        EmptyIslandUnproven as _EIUnproven,
                        empty_island_proven as _ei_proven_fn)
                    if not _ei_proven_fn(_ice_meta_out):
                        logger.error(
                            "REG-VIEW '%s': iceberg pruned to 0 files and the "
                            "emptiness is NOT PROVEN (verdict=%s) -- widening "
                            "to the full enumeration (DuckDB applies the WHERE)",
                            tname, (_ice_meta_out or {}).get("empty_island"))
                        try:
                            from core.iceberg_reader import (
                                get_iceberg_data_files as _ei_reader)
                            _ei_widened = _ei_reader(
                                _shared_s3, bucket, tbl["s3_prefix"],
                                partition_filters=None, keys_only=True,
                                _out_meta={}, force_fresh=force_fresh_iceberg,
                                db_manager=db_manager, table_name=tname) or []
                        except Exception as _ei_exc:
                            raise _EIUnproven(
                                f"Iceberg table '{tname}' pruned to 0 files; the "
                                f"pruning could not be proven and the unfiltered "
                                f"enumeration failed ({_ei_exc}). Refusing to "
                                f"answer 0 rows on a guess.") from _ei_exc
                        data_files = [
                            f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                            for f in _ei_widened]
                        if isinstance(_ice_meta_out, dict):
                            _ice_meta_out["empty_island"] = {
                                "proven": not data_files,
                                "reason": ("full enumeration is empty"
                                           if not data_files else
                                           "widened by the view builder"),
                                "widened_to": len(data_files)}
                # BF-504 (2026-05-28) — empty data_files path.  When
                # partition pruning excludes every file (e.g., user
                # filters on a partition value that exists in S3 but
                # was excluded by spec/snapshot evolution OR by the
                # filter's match logic), the previous code took the
                # ``if data_files:`` branch as False and SKIPPED THE
                # ENTIRE TABLE — no CREATE VIEW emitted.  Downstream
                # COPY ``SELECT … FROM <table>`` then crashed with
                # ``CatalogException: Table does not exist`` because
                # the view was never registered.  User report:
                #   "same query is running for 2026-04-30 and not
                #    running for 2026-02-28" → 2026-02-28 pruned to
                #    0 files → no view → CatalogException.
                # Same behaviour the streaming variant
                # (register_s3_views) gets via its own ``if not
                # data_files`` empty-schema branch.  Mirror it here.
                if not data_files:
                    if _apply_pruning:
                        logger.info(
                            "PRUNE-SCOPE: iceberg '%s' pruned to 0 files — "
                            "creating empty schema view so the query returns "
                            "0 rows instead of crashing on missing-view error "
                            "(BF-504, filters: %s)",
                            tname, _tbl_filters,
                        )
                    else:
                        logger.info(
                            "REG-VIEW '%s': iceberg table has 0 files even "
                            "without pruning — creating empty schema view",
                            tname,
                        )
                    try:
                        # 2026-07-14 (deep-dive round 5): PREFER the real iceberg
                        # SCHEMA view (schema cache — always includes partition
                        # source columns, no S3) so a partition-key JOIN binds.
                        # The read_parquet sample can PHYSICALLY omit partition
                        # columns (projection / non-identity transform) → a JOIN
                        # on that column still crashes.  Sample is now only a
                        # cold-cache fallback.
                        _typed_ddl = typed_empty_view_ddl(
                            tname, connection_id, db_manager)
                        if _typed_ddl:
                            con.execute(_typed_ddl)
                            _registered_ok.add(tname)
                            logger.info(
                                "REG-VIEW '%s': 0 files — empty view from iceberg "
                                "schema (JOIN-safe, partition cols included)", tname)
                        else:
                            from core.iceberg_reader import get_iceberg_data_files as _gdf
                            _schema_files = _gdf(_shared_s3, bucket, tbl["s3_prefix"], keys_only=True, max_files=1)
                            if _schema_files:
                                _sf_raw = f"s3://{bucket}/{_schema_files[0]['key']}"
                                _sf_presigned = _s3_urls_to_presigned(_shared_s3, [_sf_raw], conn_config)[0]
                                _ice_is_presigned = _get_s3_access_mode(conn_config) == "presigned"
                                _sf_view_path = _sf_presigned
                                if _ice_is_presigned:
                                    # BF-200: DuckDB httpfs cannot open presigned URLs on
                                    # on-prem S3 (HTTP 0 / self-signed cert). Pre-download.
                                    try:
                                        _sf_locals, _sf_tmp = _presigned_to_local(
                                            [_sf_presigned], conn_config,
                                            s3_client=_shared_s3,
                                            original_s3_urls=[_sf_raw],
                                        )
                                        if _sf_tmp:
                                            with _global_temp_dirs_lock:
                                                _global_temp_dirs.append(_sf_tmp)
                                        _sf_view_path = _sf_locals[0] if _sf_locals else None
                                    except Exception as _sf_dl_err:
                                        logger.warning(
                                            "REG-VIEW '%s': Iceberg schema-sample pre-download failed (%s) — "
                                            "creating bare empty view (BF-504 fallback)",
                                            tname, _sf_dl_err,
                                        )
                                        _sf_view_path = None
                                if _sf_view_path:
                                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'{_esc(_sf_view_path)}\', hive_partitioning=true) WHERE FALSE')
                                    _registered_ok.add(tname)
                                else:
                                    _create_empty_iceberg_view(
                                        con, tname_esc, tname, connection_id, db_manager)
                                    _registered_ok.add(tname)
                            else:
                                # BF-504 — no schema anywhere.  _create_empty_iceberg_view
                                # guarantees a view (real schema → VARCHAR → dummy).
                                _create_empty_iceberg_view(
                                    con, tname_esc, tname, connection_id, db_manager)
                                _registered_ok.add(tname)
                    except Exception as _empty_exc:
                        logger.error("Failed to create empty Iceberg schema view for '%s': %s — "
                                     "creating real-schema fallback view", tname, _empty_exc, exc_info=True)
                        try:
                            _create_empty_iceberg_view(
                                con, tname_esc, tname, connection_id, db_manager)
                            _registered_ok.add(tname)
                        except Exception:
                            pass

                if data_files:
                    # Normalize cached entries
                    data_files = [
                        f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                        for f in data_files
                    ]
                    total_all = len(data_files)
                    # ── BLOOM JOIN-PRUNE (2026-07-13) ─────────────────────────
                    # Applied HERE — AFTER the file list is resolved (cache OR
                    # fresh manifests) AND AFTER _ice_cache_set stored the FULL
                    # list — so the shared (conn, table, partition_filter) cache
                    # is NEVER contaminated with a query-specific pruned list
                    # (a standalone SELECT on this table, or the same join after
                    # the anchor advances, must still see every file).  This
                    # prune touches ONLY the local ``data_files`` that builds
                    # THIS query's view.
                    #
                    # If this iceberg table is a JOIN TARGET and an already-
                    # processed anchor supplied a COMPLETE join-key set, drop
                    # target files whose bloom PROVES none of those keys can be
                    # present, so a big-file JOIN's view reads only the relevant
                    # files.
                    #
                    # SAFE BY CONSTRUCTION:
                    #   * join_key_distinct_values_bloom is emitted ONLY when
                    #     every anchor file was single-valued (BoundAggregator
                    #     nulls the set the instant any file is multi-valued or
                    #     missing a bound) -> the key set is COMPLETE, so
                    #     anchor_keys_complete=True is correct.
                    #   * bloom_prune_target_files is FAIL-OPEN everywhere: no
                    #     bloom row / bloom "maybe" / file-path form mismatch /
                    #     any error -> the file is KEPT.  A file is dropped ONLY
                    #     when its bloom proves NONE of the keys can be present
                    #     (bloom has no false negatives).  Never drops a joining
                    #     row; worst case a no-op.
                    #   * If a prune would empty ``data_files`` we KEEP the full
                    #     list instead (the JOIN itself yields 0 rows, and this
                    #     dodges any empty read_parquet view edge case).
                    if (_jp and _tname_lower in _target_tables_lower
                            and data_files and db_manager is not None
                            and _ice_snapshot_id and fmt == "iceberg"):
                        try:
                            from core.iceberg_bloom_sidecar import (
                                bloom_prune_target_files as _bloom_prune,
                            )
                            _pfx = f"s3://{bucket}/"
                            _key_of = (lambda u: u[len(_pfx):]
                                       if isinstance(u, str) and u.startswith(_pfx)
                                       else u)
                            for _bp in _join_probes:
                                if _bp.target_table != _tname_lower:
                                    continue
                                _bk = (_join_anchor_distinct_bloom.get(
                                    _bp.anchor_table) or {}).get(_bp.anchor_col)
                                if not _bk:
                                    continue    # anchor set absent/incomplete
                                _fp_list = [_key_of(u) for u in data_files]
                                _kept, _bstats = _bloom_prune(
                                    db_manager, bucket=bucket,
                                    table_prefix=prefix,
                                    snapshot_id=str(_ice_snapshot_id),
                                    target_files=_fp_list,
                                    join_column=_bp.target_col,
                                    anchor_keys=_bk,
                                    anchor_keys_complete=True,
                                )
                                if _bstats.get("pruned") and _kept:
                                    _kept_set = set(_kept)
                                    data_files = [u for u in data_files
                                                  if _key_of(u) in _kept_set]
                                    logger.info(
                                        "[bloom-join-prune] table=%s target_col=%s "
                                        "anchor=%s keys=%d -> pruned %d, %d files "
                                        "remain (post-cache, view-local)",
                                        tname, _bp.target_col, _bp.anchor_table,
                                        len(_bk), _bstats["pruned"], len(data_files),
                                    )
                        except Exception as _bloom_exc:
                            logger.debug(
                                "bloom join-prune failed (fail-open, no prune): %s",
                                _bloom_exc)
                    # Manifest-level pruning already applied inside get_iceberg_data_files()
                    # (Avro bounds, correct for Iceberg). Log result for diagnostics.
                    if _apply_pruning:
                        _auto_partition_applied = {
                            "table": tname,
                            "total_files": total_all,
                            "filtered_files": len(data_files),
                            "filters": _tbl_filters,
                        }
                        logger.info("PRUNE-SCOPE: iceberg '%s' pruned via manifests %d files (%s)", tname, len(data_files), "primary" if _tname_lower in _primary_tables else "joined")
                    if True:  # BF-504 — kept structure for diff readability
                        # Safety cap on file count.  BF-579 (2026-05-29):
                        # 2026-06-04 — default raised back to 5000 after
                        # the BF-579 lowering proved too aggressive for
                        # legitimate 3000-file Iceberg BQB scans.  The
                        # truncation is still LOGGED as a warning so
                        # admins can spot full-table scans in prod logs
                        # without trawling.  Keeping the LAST N files
                        # preserves the most-recent data for typical
                        # time-partitioned tables.  Set
                        # max_registered_files=0 to disable the cap.
                        _MAX_FILES = getattr(_limits_cfg, 'max_registered_files', 5000) if _limits_cfg else 5000
                        # 2026-08-20 — the slice now SURFACES (file_stats +
                        # diagnostic store + certificate downgrade) instead
                        # of masquerading as pruning.  See the helper.
                        data_files, _ice_cap_info = _apply_registered_files_cap(
                            data_files, table=tname, fmt="iceberg",
                            cap=_MAX_FILES, execution_id=execution_id)
                        if _ice_cap_info:
                            _file_cap_by_table[tname] = _ice_cap_info
                        _ice_s3_originals = list(data_files)  # save s3:// URLs before presigning
                        # Smart-VPC fast path (2026-06-23): when the endpoint is
                        # an AWS VPC interface endpoint AND the URLs contain
                        # hive-partition segments, REWRITE to boto3-signed
                        # HTTPS but DO NOT pre-download.  DuckDB httpfs then
                        # reads each file LAZILY directly over the VPC link —
                        # no disk pressure, no temp files, no serialised fetch.
                        # On-prem (Hive) endpoints don't match the VPC pattern
                        # so this branch is a no-op for them.
                        #
                        # Failure semantics: ``s3_urls_to_presigned_vpc`` is
                        # fail-CLOSED — if any signing fails it raises, so
                        # we don't accidentally pass raw ``s3://`` URLs to
                        # DuckDB (libcurl URL-encodes ``=`` -> 403).  When
                        # raised, ``_vpc_needed_predownload`` flags the
                        # downstream pre-download branch to fire UNCONDITION-
                        # ALLY (even without proxy) so the query still
                        # completes via the local-files safety net.
                        _vpc_handled = False
                        _vpc_needed_predownload = False
                        try:
                            from core.s3_utilities import (
                                vpc_presigned_rewrite_needed as _vpc_need,
                                s3_urls_to_presigned_vpc as _vpc_presign,
                            )
                            if _vpc_need(conn_config, _ice_s3_originals):
                                try:
                                    data_files = _vpc_presign(
                                        _shared_s3, data_files, conn_config)
                                    _vpc_handled = True
                                    logger.info(
                                        "REG-VIEW '%s': VPC + hive paths -> "
                                        "rewrote %d s3:// URL(s) to presigned "
                                        "HTTPS (DuckDB reads via VPC, no download)",
                                        tname, len(_ice_s3_originals))
                                    try:
                                        from core.brain_trace import trace as _bt
                                        _bt("vpc_route", "presigned",
                                            table=tname,
                                            url_count=len(_ice_s3_originals))
                                    except Exception:
                                        pass
                                except Exception as _vpc_sign_exc:
                                    _vpc_needed_predownload = True
                                    logger.warning(
                                        "REG-VIEW '%s': VPC presigned-rewrite "
                                        "FAILED (%s) — forcing pre-download "
                                        "safety net so query doesn't 403 on "
                                        "raw s3:// URLs",
                                        tname, _vpc_sign_exc)
                        except Exception as _vpc_exc:
                            logger.warning(
                                "REG-VIEW '%s': VPC presigned-rewrite skipped "
                                "(non-fatal): %s", tname, _vpc_exc)
                        if not _vpc_handled:
                            data_files = _s3_urls_to_presigned(_shared_s3, data_files, conn_config)
                        # BF-200: On-prem S3 — DuckDB httpfs cannot open presigned URLs (HTTP 0 /
                        # self-signed cert).  Pre-download via Python urllib, same guard as parquet path.
                        # VPC fast-path skipped this branch entirely (VPC works lazily over httpfs).
                        if not _vpc_handled and _get_s3_access_mode(conn_config) == "presigned" and data_files:
                            # Phase 10 — the pruned island file list just
                            # resolved into presigned URLs; kick the cache
                            # prefetch fan-out NOW so it overlaps the
                            # router lookup + the blocking download below
                            # instead of the two running serially.
                            _prefetch_presigned(data_files, conn_config)
                            # BF-429 — router-first (gated by presigned_router_enabled).
                            _ppr_ice = _try_router_for_presigned(
                                s3_client=_shared_s3, conn_config=conn_config,
                                bucket=bucket, s3_keys=_ice_s3_originals,
                                table_name=tname, progress_fn=progress_fn,
                                forced_reader=_extract_reader_override(query_config),
                                partition_filters=partition_filters,
                                raw_sql=raw_sql, query_config=query_config,
                            )
                            if (_ppr_ice is not None
                                    and _ppr_ice.output_kind in ("local_paths", "s3_paths")
                                    and _ppr_ice.read_targets):
                                data_files = _ppr_ice.read_targets
                                logger.info("REG-VIEW '%s': presigned router=%s "
                                            "served %d file(s) (%s) in %.1fs",
                                            tname, _ppr_ice.reader_name,
                                            _ppr_ice.files_succeeded,
                                            _ppr_ice.output_kind,
                                            _ppr_ice.duration_seconds)
                            else:
                                try:
                                    data_files, _vw_tmp = _presigned_to_local(
                                        data_files, conn_config,
                                        s3_client=_shared_s3,
                                        original_s3_urls=_ice_s3_originals,
                                    )
                                    if _vw_tmp:
                                        with _global_temp_dirs_lock:
                                            _global_temp_dirs.append(_vw_tmp)
                                except Exception as _ice_dl_err:
                                    logger.warning(
                                        "REG-VIEW '%s': Iceberg pre-download failed (%s) — "
                                        "passing presigned URLs to DuckDB directly "
                                        "(may fail with HTTP 0 on on-prem S3)",
                                        tname, _ice_dl_err,
                                    )
                        # BF-251 / BF-259: pre-download via parallel boto3 when
                        # one of these gates fires:
                        #   * corporate proxy enabled (httpfs-libcurl is serial
                        #     through proxies — 60+ min on 3000 files)
                        #   * s3_local_cache enabled (the cache is path-keyed
                        #     and only populates via _s3_to_local_via_boto3,
                        #     so direct-AWS users get no benefit unless we
                        #     route through it)
                        # Falls back to DuckDB httpfs on download failure.
                        # BF-416: skip pre-download when post-pruning file count
                        # is small — the local-file detour overhead exceeds the
                        # serial-httpfs cost on tiny scans.  Threshold is
                        # ``s3.predownload_skip_threshold`` (0 = always
                        # pre-download = legacy).  Cache mode always pre-downloads
                        # (cache hits are O(0)).
                        elif (not _vpc_handled) and (_vpc_needed_predownload or _is_proxy_active_for_duckdb() or _is_s3_cache_active() or _is_parallel_predownload_active()) and _ice_s3_originals:
                            from core.s3_predownload import should_predownload as _should_pd
                            if not _should_pd(len(_ice_s3_originals)):
                                logger.info(
                                    "REG-VIEW '%s': %d files <= predownload_skip_threshold — "
                                    "letting DuckDB httpfs read directly (proxy + serial)",
                                    tname, len(_ice_s3_originals),
                                )
                            else:
                                _trigger = ("proxy" if _is_proxy_active_for_duckdb()
                                            else "cache" if _is_s3_cache_active()
                                            else "parallel_predownload")
                                # BF-428H: Try the pluggable router first.  When master
                                # switch s3_readers.integration_enabled=False (default)
                                # this returns None and we fall through to the legacy
                                # _s3_to_local_via_boto3 path unchanged.
                                _router_result = _try_router_for_predownload(
                                    s3_client=_shared_s3,
                                    bucket=bucket,
                                    s3_keys=_ice_s3_originals,
                                    table_name=tname,
                                    progress_fn=progress_fn,
                                    forced_reader=_extract_reader_override(query_config),
                                    # 2026-08-03 defect fix — thread the same
                                    # context the presigned sibling passes so a
                                    # routed pyarrow read projects columns +
                                    # prunes row groups instead of transferring
                                    # EVERY column.  Filters only for PRIMARY
                                    # tables — the same trust scope file-level
                                    # pruning uses (joined tables' columns may
                                    # not match the query's WHERE filters).
                                    partition_filters=(
                                        partition_filters
                                        if _tname_lower in _primary_tables
                                        else None),
                                    raw_sql=raw_sql,
                                    query_config=query_config,
                                )
                                _t_dl0 = _time.monotonic()
                                if _router_result is not None:
                                    # Router served the request — use its paths,
                                    # skip the legacy predownload entirely.
                                    _local_paths = _router_result.read_targets
                                    data_files = _local_paths
                                    logger.info(
                                        "REG-VIEW '%s': router=%s served %d "
                                        "file(s) (bytes_read=%d cache_hits=%d) "
                                        "in %.1fs", tname,
                                        _router_result.reader_name,
                                        _router_result.files_succeeded,
                                        _router_result.bytes_read,
                                        _router_result.cache_hits,
                                        _router_result.duration_seconds,
                                    )
                                else:
                                    # Master switch off OR router unable to serve
                                    # — legacy boto3 pre-download.
                                    try:
                                        _local_paths, _vw_tmp = _s3_to_local_via_boto3(
                                            _shared_s3, _ice_s3_originals,
                                            progress_callback=(
                                                (lambda done, total, _t=tname: progress_fn({
                                                    "status": "processing",
                                                    "log": f"Downloading {tname}: {done}/{total} files",
                                                })) if progress_fn else None
                                            ),
                                        )
                                        # BF-418 follow-up — _s3_to_local_via_boto3
                                        # now self-registers temp_dir for atexit
                                        # cleanup inside core.s3_predownload (so
                                        # a hard crash mid-download doesn't
                                        # orphan the dir).  An additional append
                                        # here would create a duplicate entry
                                        # in _global_temp_dirs that the cleanup
                                        # job would try to rmtree twice.
                                        data_files = _local_paths
                                        logger.info(
                                            "REG-VIEW '%s': boto3 pre-download (%s) → %d local file(s) in %.1fs",
                                            tname, _trigger, len(_local_paths), _time.monotonic() - _t_dl0,
                                        )
                                    except Exception as _proxy_dl_err:
                                        logger.warning(
                                            "REG-VIEW '%s': boto3 pre-download (%s) failed (%s) — "
                                            "falling back to DuckDB httpfs (may be slow)",
                                            tname, _trigger, _proxy_dl_err,
                                        )
                        # Phase 139 honest-fix Gap 1 wiring: when iceberg_mor.enabled=true
                        # AND _out_meta carries delete files, build a MoR-aware view that
                        # anti-joins data files against position+equality delete files.
                        # Works on both AWS S3 (httpfs read) and on-prem S3 (pre-downloaded
                        # local paths — same as data files).
                        # 2026-07-15 STRATEGIC: the resolve → presign/pre-download →
                        # build_mor_view_sql sequence now lives in the single
                        # module-level chokepoint ``_apply_mor_view`` (shared with the
                        # streaming path register_s3_views).
                        # 2026-07-15 fail-mode symmetry: fail_loud=True — same
                        # posture as the streaming path.  When deletes EXIST but
                        # provably cannot be applied, MorDeletesUnresolvableError
                        # is raised (re-raised past the per-table handler below)
                        # instead of silently serving a delete-blind OVERCOUNTED
                        # result to BQB full runs / feed gen / Published API.
                        # Single operator opt-out: iceberg_mor.allow_stale_reads
                        # =true downgrades to the historical warn + plain view.
                        # Tables without delete files return False immediately —
                        # non-MoR and append-only tables are unaffected.
                        try:
                            _ice_out_for_mor = _ice_meta_out if isinstance(_ice_meta_out, dict) else {}
                        except NameError:
                            _ice_out_for_mor = {}  # _ice_meta_out not in scope on cached path — no MoR data
                        try:
                            _mor_orig_in = _ice_s3_originals
                        except NameError:
                            _mor_orig_in = None  # AWS-direct: read path == s3 uri
                        _mor_view_built = _apply_mor_view(
                            con, tname, tname_esc, data_files,
                            orig_s3_paths=_mor_orig_in,
                            ice_meta_out=_ice_out_for_mor,
                            bucket=bucket, conn_config=conn_config,
                            s3_client=_shared_s3, s3_prefix=tbl["s3_prefix"],
                            fail_loud=True,
                        )
                        if not _mor_view_built:
                            # BF-PRUNE-PERF (Option 1 + Option 2):
                            #   Opt-1: union_by_name controlled by config
                            #          (default FALSE for Iceberg — Iceberg
                            #          guarantees schema uniformity).
                            #   Opt-2: when the Iceberg schema is available
                            #          via _out_meta["iceberg_schema"],
                            #          project columns explicitly so DuckDB
                            #          doesn't need to discover the schema
                            #          from a parquet footer at all.
                            try:
                                from core.execution_stage import (
                                    set_stage as _set_stg,
                                    STAGE_DUCKDB_SETUP as _S_SETUP,
                                )
                                _exec_id_setup = _DL_EXEC_ID_CTX.get(None)
                                if _exec_id_setup:
                                    _set_stg(_exec_id_setup, _S_SETUP,
                                              files_total=len(data_files),
                                              message=f"Registering '{tname}' ({len(data_files)} parquet files)")
                            except Exception:
                                pass
                            try:
                                from core.config import s3 as _s3_cfg_view
                                _ubn_ice = _s3_cfg_view.duckdb_union_by_name_iceberg
                            except Exception:
                                _ubn_ice = False  # safe default: no per-file footer reads
                            # Auto-enable for schema-evolved tables — overrides
                            # the config default.  iceberg_reader sets
                            # `iceberg_schema_evolution`=true when metadata.json
                            # carries differing field-id sets across schemas.
                            _ice_schema_fields = None
                            _ice_schema_evolved = False
                            _ice_type_conflict = False
                            try:
                                if isinstance(_ice_meta_out, dict):
                                    _ice_schema_fields = _ice_meta_out.get("iceberg_schema") or None
                                    _ice_schema_evolved = bool(_ice_meta_out.get("iceberg_schema_evolution"))
                                    # A field-id whose TYPE changed across schemas
                                    # SEGFAULTS DuckDB 1.5.3 under union_by_name=true.
                                    _ice_type_conflict = bool(_ice_meta_out.get("iceberg_schema_type_conflict"))
                            except NameError:
                                pass
                            # Deep-dive fix: previously this auto-enabled
                            # union_by_name=true when evolution was detected,
                            # OVERRIDING the admin's explicit
                            # ``s3.duckdb_union_by_name_iceberg=false`` setting.
                            # The flag was useless on schema-evolved tables
                            # because the override always won.
                            #
                            # New semantics: admin's flag is authoritative.
                            # If admin set it to false but evolution is detected,
                            # we log a WARNING (so they know the risk) but use
                            # fast path as requested.  This matches the same
                            # fix applied to execute_api.py's Iceberg branch.
                            # 2026-06-24 strategic fix -- when Iceberg
                            # metadata reports schema evolution, AUTO
                            # ENABLE union_by_name=true IF the file
                            # count is small enough that footer scanning
                            # is cheap.  Reason: operator hit "Column
                            # 'tetb_account_title' not found in the
                            # query result" when one partition's older
                            # parquet file lacked a column that appears
                            # in newer files.  Correctness on partition-
                            # pruned queries (where the file count is
                            # already small) wins over speed.
                            #
                            # For LARGE file sets (e.g. full-table scan,
                            # no WHERE filter), the union_by_name=true
                            # setup penalty can exceed 200-350s because
                            # DuckDB libcurl reads every parquet footer
                            # over S3.  In those cases we keep the
                            # admin's config preference -- if columns
                            # go missing the operator can either add
                            # partition filters OR flip the admin flag.
                            #
                            # Threshold: ``s3.union_by_name_max_files``
                            # (default 200) -- partition-pruned queries
                            # typically land under this; full scans go
                            # over.  Tune per deployment.  Opt out
                            # entirely via QS_FORCE_FAST_ICEBERG=1 for
                            # post-compaction tables that don't need
                            # the safety net.
                            _force_fast = os.environ.get(
                                "QS_FORCE_FAST_ICEBERG", "").strip() in (
                                "1", "true", "TRUE", "yes")
                            try:
                                from core.config import s3 as _s3_cfg_thr
                                _ubn_max_files = int(getattr(
                                    _s3_cfg_thr, "union_by_name_max_files",
                                    200))
                            except Exception:
                                _ubn_max_files = 200
                            _file_count = len(data_files) if data_files else 0
                            _evolution_within_threshold = (
                                _ice_schema_evolved
                                and not _force_fast
                                and _file_count <= _ubn_max_files
                            )
                            _ubn_effective = (
                                True if _evolution_within_threshold
                                else _ubn_ice
                            )
                            # PERMANENT SEGFAULT AVOIDANCE (2026-07): union_by_name
                            # reconciles files BY NAME; DuckDB 1.5.3 SEGFAULTS when
                            # a field-id's TYPE changed across schema versions
                            # (int→bigint→string).  Pure ADD/DROP-column evolution
                            # is safe; a TYPE conflict is not.  So when a type
                            # conflict is present we force union_by_name OFF up
                            # front — never enable the crashing path (the s3_full_copy
                            # SIGSEGV retry that strips it is now only a last-resort
                            # net).  A single-partition island is usually
                            # schema-consistent, so the plain read then succeeds; if
                            # it genuinely spans a type-changed column the query gets
                            # a clean error, never a crash.
                            if _ubn_effective and _ice_type_conflict:
                                _ubn_effective = False
                                logger.warning(
                                    "REG-VIEW '%s': iceberg schema has a cross-version "
                                    "TYPE conflict — union_by_name FORCED OFF to avoid "
                                    "the DuckDB 1.5.3 segfault (name-based union of "
                                    "incompatible types crashes the engine). Reading "
                                    "%d file(s) without union_by_name.",
                                    tname, _file_count)
                            if _evolution_within_threshold and not _ubn_ice:
                                logger.info(
                                    "REG-VIEW '%s': Iceberg schema evolution "
                                    "detected + file count %d <= threshold %d "
                                    "-- auto-enabling union_by_name=true "
                                    "(correctness path).  Set "
                                    "QS_FORCE_FAST_ICEBERG=1 to skip.",
                                    tname, _file_count, _ubn_max_files,
                                )
                            elif _ice_schema_evolved and not _ubn_ice and _file_count > _ubn_max_files:
                                logger.warning(
                                    "REG-VIEW '%s': Iceberg schema evolution "
                                    "detected BUT file count %d > threshold %d "
                                    "-- using fast path to avoid ~200-350s "
                                    "footer-scan penalty.  If query returns "
                                    "wrong/missing columns, either (1) add "
                                    "partition filters to reduce file count, "
                                    "(2) raise s3.union_by_name_max_files, or "
                                    "(3) set s3.duckdb_union_by_name_iceberg=true.",
                                    tname, _file_count, _ubn_max_files,
                                )
                            # 2026-09-25 -- THE read decision (partition
                            # values from the data files vs the hive path;
                            # current-schema projection) comes from
                            # core.iceberg_read_plan, shared with the
                            # streaming, raw-SQL and MoR builders.
                            # In hive-path mode (today's behaviour) the
                            # plan's from_expr is the BF-494 helper's
                            # output: a single ``read_parquet`` when all
                            # files share one hive-key set, else a
                            # UNION ALL BY NAME of per-signature reads
                            # (older files lack the newly-added partition
                            # column in their path -- without it DuckDB
                            # raises BinderException: Hive partition
                            # mismatch).  In files mode there are no hive
                            # keys to mismatch.
                            _ice_plan = _plan_iceberg_read(
                                data_files, meta=_ice_out_for_mor,
                                union_by_name=_ubn_effective,
                                table_name=tname, log_prefix="REG-VIEW",
                            )
                            _from_expr = _ice_plan.from_expr
                            _evolved_partition_spec = "UNION ALL BY NAME" in _from_expr
                            # 2026-10-06 -- every SELECT below reads through
                            # the plan's SOURCE: the read itself, or the read
                            # UNION ALL BY NAME the typed current-schema pad
                            # (a column no file carries binds as NULL).
                            _src_expr = _iceberg_view_source(_ice_plan)
                            if _evolved_partition_spec:
                                logger.info(
                                    "REG-VIEW '%s': Iceberg partition-spec "
                                    "evolution detected (%d hive-signature "
                                    "group(s)) — emitting UNION ALL BY NAME view",
                                    tname,
                                    _from_expr.count("read_parquet"),
                                )
                            # Round 18: when the iceberg manifest declares
                            # columns that aren't physically present in
                            # the parquet data files (schema evolution,
                            # column drop, etc.), the explicit-projection
                            # SELECT raises ``BinderException: referenced
                            # column not found in FROM clause``.  Catch
                            # and retry with SELECT * — slightly slower
                            # scan but lets the view get created so the
                            # query / feed can run.  Logged at INFO so
                            # admins can see the fallback fired.
                            # JOIN-PRUNER row-group injection: when synth
                            # filters were built for this target table,
                            # append them as a WHERE clause to the view
                            # DDL so DuckDB's row-group pruner ALSO
                            # applies them (manifest pruning already
                            # fired; this is the per-file row-group cherry).
                            _view_where_clause = (
                                f' WHERE {_join_view_where}' if _join_view_where else ''
                            )
                            if _ice_plan.projected:
                                # Files mode: the plan's projection IS the
                                # current Iceberg schema (absent columns
                                # NULL, no hive-path or helper columns).  A
                                # binder error here means the manifest's
                                # metrics named a column the file lacks --
                                # fall back to ``SELECT *`` over the SAME
                                # files-mode read (never back to the path).
                                _plan_sql = (
                                    f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                    f'{_iceberg_view_select_sql(_ice_plan, _join_view_where or "")}'
                                )
                                try:
                                    con.execute(_plan_sql)
                                except Exception as _plan_exc:
                                    _pmsg = str(_plan_exc)
                                    if ("Binder" in _pmsg or
                                        "referenced column" in _pmsg or
                                        "not found in" in _pmsg.lower()):
                                        logger.warning(
                                            "REG-VIEW '%s': iceberg current-schema "
                                            "projection rejected by DuckDB (manifest "
                                            "metrics vs file drift); retrying with "
                                            "SELECT * over the same files-mode read.  "
                                            "Original: %s", tname, _pmsg[:200])
                                        con.execute(
                                            f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                            f'SELECT * FROM {_src_expr}{_view_where_clause}'
                                        )
                                    else:
                                        raise
                            elif _ice_plan.pad_select:
                                # 2026-10-06 -- hive-path read with the typed
                                # current-schema pad: the plan's own SELECT
                                # (``SELECT * [REPLACE (COALESCE(new, old))]``
                                # over the padded source) -- an added column
                                # binds as NULL in any slice, a renamed one is
                                # answered by every file.
                                _pad_sql = (
                                    f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                    f'{_iceberg_view_select_sql(_ice_plan, _join_view_where or "")}'
                                )
                                try:
                                    con.execute(_pad_sql)
                                except Exception as _pad_exc:
                                    _pmsg = str(_pad_exc)
                                    if ("Binder" in _pmsg or
                                        "referenced column" in _pmsg or
                                        "not found in" in _pmsg.lower()):
                                        logger.warning(
                                            "REG-VIEW '%s': padded hive-path view "
                                            "rejected by DuckDB; retrying with "
                                            "SELECT * over the bare read.  "
                                            "Original: %s", tname, _pmsg[:200])
                                        con.execute(
                                            f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                            f'SELECT * FROM {_from_expr}{_view_where_clause}'
                                        )
                                    else:
                                        raise
                            elif _ice_schema_fields:
                                _cols_proj = ", ".join(
                                    f'"{_esc(_f["name"])}"' for _f in _ice_schema_fields
                                    if _f.get("name")
                                )
                                _star_sql = (
                                    f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                    f'SELECT * FROM {_src_expr}{_view_where_clause}'
                                )
                                # When partition-spec evolved, skip the
                                # explicit-projection optimisation — the
                                # UNION-ALL-BY-NAME subquery's column set
                                # is whatever each group exposes; trying
                                # to project explicit columns is fragile.
                                if _cols_proj and not _evolved_partition_spec:
                                    _proj_sql = (
                                        f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                        f'SELECT {_cols_proj} FROM {_src_expr}{_view_where_clause}'
                                    )
                                    try:
                                        con.execute(_proj_sql)
                                    except Exception as _proj_exc:
                                        _msg = str(_proj_exc)
                                        # Binder / parser errors from column-set drift
                                        # between manifest and parquet files → fall
                                        # back to SELECT *.  Other errors (S3 read,
                                        # auth) are NOT caught here — they should
                                        # surface up.
                                        if ("Binder" in _msg or
                                            "referenced column" in _msg or
                                            "not found in" in _msg.lower()):
                                            logger.info(
                                                "REG-VIEW '%s': iceberg explicit-projection "
                                                "rejected (column drift between manifest and "
                                                "data files); retrying with SELECT *.  "
                                                "Original: %s",
                                                tname, _msg[:200],
                                            )
                                            con.execute(_star_sql)
                                        else:
                                            raise
                                else:
                                    con.execute(_star_sql)
                            else:
                                con.execute(
                                    f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                    f'SELECT * FROM {_src_expr}{_view_where_clause}'
                                )
                            if _join_view_where:
                                logger.info(
                                    "JOIN-PRUNER: appended view WHERE for '%s': %s",
                                    tname, _join_view_where[:200],
                                )

                        if _tname_lower in _primary_tables:
                            _any_primary_registered_with_data = True
                        _registered_ok.add(tname)
                        if progress_fn:
                            progress_fn({"status": "processing",
                                         "log": f"Registered '{tname}' ({len(data_files)}/{total_all} Iceberg files)"})
                # BF-546 (2026-05-29): freshness verdict from s3 client.
                _ice_freshness_setup = ""
                try:
                    _ice_freshness_setup = getattr(
                        locals().get("_shared_s3") or locals().get("s3_client"),
                        "_qs_iceberg_freshness", "") or ""
                except Exception as _fr_exc:
                    logger.debug("BF-546 freshness probe skipped: %s", _fr_exc)
                _file_stats[tname] = {
                    "total": total_all, "after_pruning": len(data_files), "format": "iceberg",
                    "snapshot_id": _ice_snapshot_id or "",  # Phase 104
                    "file_count": total_all,                # Phase 104 — total files before pruning
                    # KNOWN-DEAD (2026-08-09 lint audit): `_mor_pos_paths` /
                    # `_mor_eq_files` are locals of _resolve_mor_deletes, not
                    # of this function, so `in dir()` is ALWAYS False and both
                    # counters ALWAYS report 0.  Runtime-safe (the guard means
                    # no NameError is ever raised) but the telemetry is inert.
                    # Left as-is deliberately: wiring the real counts requires
                    # threading them back out of the MoR resolver, which is a
                    # behaviour change, not a lint fix.
                    "mor_pos_deletes":   len(_mor_pos_paths) if '_mor_pos_paths' in dir() else 0,  # noqa: F821
                    "mor_eq_deletes":    len(_mor_eq_files) if '_mor_eq_files' in dir() else 0,  # noqa: F821
                    "iceberg_freshness": _ice_freshness_setup,  # BF-546
                }
                # 2026-08-20 — "after_pruning" above is recorded AFTER the
                # BF-579 slice, so a capped scan looked exactly like
                # pruning.  The truncation record makes it distinct.
                if tname in _file_cap_by_table:
                    _file_stats[tname]["file_cap"] = _file_cap_by_table[tname]
            except MorDeletesUnresolvableError:
                # 2026-07-15 fail-mode symmetry — a MoR correctness refusal
                # must NOT be downgraded to a _registration_failures entry:
                # execute_api's batch callers only consult ``all_empty`` (not
                # the failures dict), so recording it here would turn "deletes
                # can't be applied" into a silent 0-row result when the failed
                # table is the sole primary (silent undercount replacing the
                # old silent overcount).  Propagate instead — every batch
                # caller already surfaces raised exceptions actionably:
                #   - execute_api (BQB/CQB/Published API/scheduled reports):
                #     top-level handler marks the execution failed with str(e)
                #   - execute_registered_table_copy_to caller re-raises as
                #     "S3 query failed: …" into the same handler
                #   - feed_engine catches, stamps _setup_views_warning and the
                #     feed FAILS with the message prepended (no empty output)
                # Same established contract as check_mmap_admission_or_raise,
                # which already raises out of this function.  Close the con we
                # created ourselves (caller-provided cons stay untouched —
                # their owners close them in their own cleanup paths).
                if own_con:
                    try:
                        con.close()
                    except Exception as _mor_close_exc:
                        logger.debug(
                            "MoR fail-loud: closing own con failed: %s",
                            _mor_close_exc)
                raise
            except Exception as e:
                logger.warning("Could not register Iceberg view '%s': %s", tname, e, exc_info=True)
                if progress_fn:
                    progress_fn({"status": "processing", "log": f"Warning: {tname} — {str(e)[:200]}"})
                # BF-474 (2026-05-19) — track REGISTRATION FAILURES
                # distinctly from genuine 0-file pruning.  When an
                # iceberg/parquet view fails to register because S3
                # returned 403/401/timeout/etc., the table-of-interest
                # is unreadable.  The caller (feed_engine) must NOT
                # treat this as "no matching data" — emitting an
                # empty parquet on an auth failure is silent data
                # loss masquerading as a successful run.
                _registration_failures[tname] = {
                    "error_type": type(e).__name__,
                    # what S3 answered, before the URL (s3_http_errors)
                    "error_message": _s3_failure_text(e),
                    "table_format": "iceberg",
                    "files_pre_failure": len(data_files) if 'data_files' in dir() else None,
                }

        elif fmt == "parquet":
            try:
                # 78C: Wrap listing with S3 circuit breaker
                from core.s3_utilities import call_with_s3_circuit_breaker as _s3_cb
                _s3_cb_id = connection_id or 0
                _s3_cb_name = str(conn_config.get("name", f"conn-{_s3_cb_id}"))
                # 2026-08-03 ISLAND-FIRST LIST — when the WHERE pins hive
                # partition columns, LIST only the island's derived prefix(es)
                # instead of enumerating the whole table and filtering.  The
                # planner returns None on ANY doubt (mixed layout, OR groups,
                # unpinned leading column, S3 error) → full listing below runs
                # exactly as before.  The result is always a SUPERSET of the
                # post-filter survivors (shared hive_parts_could_match
                # chokepoint), and _filter_iceberg_files_by_partitions still
                # runs on it below — the final file set is byte-identical to
                # today's; only enumeration cost changes.
                pq_files = None
                if _apply_pruning and (_tbl_filters or or_groups):
                    try:
                        from core.island_prefix_planner import (
                            list_island_parquet_files_cached as _island_list)
                        pq_files = _s3_cb(_island_list, _s3_cb_id, _s3_cb_name,
                                          connection_id, _shared_s3, bucket,
                                          prefix, _tbl_filters,
                                          or_groups=or_groups)
                        if pq_files is not None and len(pq_files) == 0:
                            # Proven-empty island.  The downstream
                            # empty-listing branch deep-lists / raw-globs the
                            # WHOLE table (it was designed for "prefix has no
                            # files at all"), so keep behaviour byte-identical
                            # by running today's full-listing path for this
                            # rare case — the post-filter will produce the
                            # same [] with today's exact empty-handling.
                            logger.info(
                                "REG-VIEW '%s': island proven empty — "
                                "re-running full listing to preserve legacy "
                                "empty-result handling", tname)
                            pq_files = None
                        elif pq_files is not None:
                            logger.info(
                                "REG-VIEW '%s': island-targeted LIST served "
                                "%d key(s) (ocean enumeration skipped)",
                                tname, len(pq_files))
                    except Exception as _island_exc:
                        logger.debug(
                            "REG-VIEW '%s': island listing unavailable "
                            "(fallback to full listing): %s",
                            tname, _island_exc)
                        pq_files = None
                if pq_files is None:
                    pq_files = _s3_cb(_list_s3_parquet_files_cached, _s3_cb_id, _s3_cb_name, connection_id, _shared_s3, bucket, prefix)
                    # 2026-08-20 — list_s3_parquet_files has stamped
                    # ``truncated=True`` at its file cap since 2026-08-03
                    # and NOTHING read it here: a >cap plain-parquet table
                    # silently queried a subset.  Check the verdict NOW —
                    # the partition filter below returns a plain list and
                    # the flag is gone.
                    try:
                        from core.scan_truncation import surface_truncated_listing
                        _pq_trunc_info = surface_truncated_listing(
                            pq_files, table=tname, bucket=bucket,
                            prefix=prefix, execution_id=execution_id)
                        if _pq_trunc_info:
                            _file_cap_by_table[tname] = _pq_trunc_info
                    except Exception as _pq_trunc_exc:
                        logger.warning(
                            "REG-VIEW '%s': could not surface listing "
                            "truncation (%s)", tname, _pq_trunc_exc)
                # Phase 104: compute fingerprint from already-fetched list (no 2nd S3 walk)
                _pq_file_hash, _pq_file_count = "", 0
                try:
                    from core.s3_utilities import get_parquet_file_list_fingerprint
                    # 2026-08-09: was `s3_client` — a name that does not
                    # exist in setup_registered_views (the shared client is
                    # `_shared_s3`, used by every other call in this
                    # function).  NameError was swallowed by the `except`
                    # below, so the Phase-104 fingerprint was ALWAYS ""/0.
                    _pq_file_hash, _pq_file_count = get_parquet_file_list_fingerprint(
                        _shared_s3, bucket, prefix, existing_file_list=pq_files,
                    )
                except Exception:
                    pass
                _s3_mode = _get_s3_access_mode(conn_config)  # "native" or "presigned"
                _is_presigned = _s3_mode == "presigned"
                total_pq = 0  # guard: defined even when pq_files is initially empty
                if pq_files:
                    total_pq = len(pq_files)
                    logger.info("REG-VIEW '%s': %d parquet files listed (s3_mode=%s, prune=%s)", tname, total_pq, _s3_mode, _apply_pruning)
                    # 2026-08-19 -- the line above is the ONLY trace a plain-
                    # parquet ocean scan used to leave, and the decisive word
                    # is "prune=False" buried mid-line.  The iceberg reader
                    # has shouted about this since 2026-08-02; parquet never
                    # grew the equivalent, so a lost region predicate showed
                    # up only as an OOM in the engine.  Observe-only, never
                    # raises, changes no file list.
                    try:
                        from core.ocean_dive_alarm import check_parquet_ocean_dive
                        check_parquet_ocean_dive(
                            tname, pq_files,
                            pruning_applied=bool(_apply_pruning),
                            table_filters=_tbl_filters,
                            caller_filters=partition_filters,
                        )
                    except Exception as _od_exc:
                        logger.debug("ocean-dive check unavailable: %s", _od_exc)
                    # ── 2026-08-21 — A TRUNCATED LISTING CANNOT BE PARTITION-FILTERED ──
                    # The listing above is capped (default 5,000 keys) in S3
                    # LEXICOGRAPHIC order, and the partition filter runs on
                    # whatever that cap happened to include.  If the wanted
                    # partition sorts after the cap — a recent-date window on
                    # a table with older dates — the filter matches NOTHING and
                    # the feed reports "completed" having delivered ZERO rows.
                    #
                    # The truncation verdict has been computed since 2026-08-03
                    # and recorded into _file_cap_by_table, but it only ever
                    # reached _file_stats as a diagnostic.  A cap must THROTTLE;
                    # this is a correctness GATE and must FAIL.  We cannot know
                    # what the cap excluded, so we cannot honestly return a
                    # filtered subset of it.
                    if _apply_pruning:
                        try:
                            from core.scan_truncation import (
                                refuse_truncated_partition_scan as _refuse_tps,
                            )
                            _tps_msg = _refuse_tps(
                                _file_cap_by_table.get(tname), True, tname)
                        except Exception as _tps_exc:
                            _tps_msg = None
                            logger.debug("truncation gate unavailable: %s",
                                         _tps_exc)
                        if _tps_msg:
                            try:
                                from core.config import get as _tc_cfg
                                _tc_strict = bool(_tc_cfg(
                                    "plain_parquet",
                                    "fail_on_truncated_partition_scan", True))
                            except Exception:
                                _tc_strict = True
                            if _tc_strict:
                                logger.error("REG-VIEW %s", _tps_msg)
                                from core.scan_truncation import (
                                    TruncatedScanRefusal as _TSRefuse,
                                )
                                raise _TSRefuse(_tps_msg)
                            logger.error(
                                "REG-VIEW %s  (plain_parquet."
                                "fail_on_truncated_partition_scan=false - "
                                "proceeding with a KNOWN-INCOMPLETE list)",
                                _tps_msg)
                    if _apply_pruning:
                        pq_files = _filter_iceberg_files_by_partitions(
                            pq_files, _tbl_filters, or_groups=or_groups)
                        if pq_files and len(pq_files) < total_pq:
                            _auto_partition_applied = {
                                "table": tname,
                                "total_files": total_pq,
                                "filtered_files": len(pq_files),
                                "filters": _tbl_filters,
                            }
                            logger.info("REG-VIEW '%s': partition pruning %d→%d files (%s)", tname, total_pq, len(pq_files), "primary" if _tname_lower in _primary_tables else "joined")
                    # ── Phase 134-A: Footer stats pruning ────────────────
                    _after_footer = len(pq_files) if pq_files else 0
                    if pq_files and len(pq_files) > 1:
                        try:
                            from core.config import s3 as _s3p_cfg
                            if _s3p_cfg.footer_stats_enabled and len(pq_files) >= _s3p_cfg.footer_stats_min_files_threshold:
                                from core.s3_footer_stats import FooterStatsCache
                                _fsc = FooterStatsCache.instance()
                                if _fsc and _tbl_filters:
                                    from core.s3_footer_stats import prune_files_by_footer_stats
                                    _fs_keys = []
                                    for _pf in pq_files:
                                        if isinstance(_pf, str) and _pf.startswith("s3://"):
                                            _parts = _pf[5:].split("/", 1)
                                            _fs_keys.append(_parts[1] if len(_parts) > 1 else _pf)
                                        else:
                                            _fs_keys.append(_pf)
                                    _kept_keys, _pruned_n, _fs_stats = prune_files_by_footer_stats(
                                        _fs_keys, _tbl_filters, connection_id or 0, _shared_s3, bucket, _fsc,
                                    )
                                    if _pruned_n > 0:
                                        # Reconstruct full s3:// paths from kept
                                        # keys.  2026-07-04: EXACT match via the
                                        # index-aligned _fs_keys (built 1:1 with
                                        # pq_files above), not a substring `k in f`
                                        # -- a kept key that is a substring of a
                                        # DIFFERENT pruned file's path would have
                                        # wrongly retained that pruned file
                                        # (over-scan).
                                        _kept_set = set(_kept_keys)
                                        pq_files = [
                                            f for f, _k in zip(pq_files, _fs_keys)
                                            if _k in _kept_set
                                        ]
                                        _after_footer = len(pq_files)
                                        logger.info("REG-VIEW '%s': footer stats pruning %d→%d files",
                                                    tname, _after_footer + _pruned_n, _after_footer)
                        except Exception as _fs_exc:
                            logger.debug("Footer stats pruning skipped for '%s': %s", tname, _fs_exc)

                    # ── Phase 151.B: plain-parquet supplement drops ──────
                    # Gated behind plain_parquet.brain.enabled (default
                    # false).  Drops files whose column-stats supplement
                    # bounds prove them empty for the WHERE — same
                    # _file_matches_supplement_bounds helper the iceberg
                    # branch uses, fed by the format='parquet' rows the
                    # parquet sync daemon populates.
                    _supplement_drops_pq = 0
                    _bloom_drops_pq = 0
                    _supp_before = len(pq_files) if pq_files else 0
                    if pq_files and _apply_pruning:
                        try:
                            from core.plain_parquet_brain_hooks import (
                                apply_supplement_drops as _apply_supp_pq,
                                apply_bloom_drops      as _apply_bloom_pq,
                            )
                            pq_files, _supplement_drops_pq = _apply_supp_pq(
                                db_manager=db_manager or _db_manager,
                                bucket=bucket, table_prefix=prefix,
                                files=pq_files, table_filters=_tbl_filters,
                                table_name=tname,
                            )
                            # Phase 151.C — bloom drops on equality / IN
                            # filters.  Runs AFTER supplement so we only
                            # bloom-test files that survived bounds.
                            pq_files, _bloom_drops_pq = _apply_bloom_pq(
                                db_manager=db_manager or _db_manager,
                                bucket=bucket, table_prefix=prefix,
                                files=pq_files, table_filters=_tbl_filters,
                                table_name=tname,
                            )
                        except Exception as _pp_exc:
                            logger.debug(
                                "plain_parquet supplement/bloom drops skipped "
                                "for '%s': %s", tname, _pp_exc,
                            )

                    # 2026-10-07 LIMIT-ONLY EARLY STOP, plain parquet (core/limit_early_stop.py):
                    # a statement any n rows of this table answer reads only the LEADING
                    # files whose footers' row counts reach n (probed in batches).  Declines
                    # (and logs why) on every other shape.  BEFORE the scan budget: a bare
                    # LIMIT trimmed to a handful of files is not a whole-table scan.
                    # 2026-10-08 -- the row this road records BELOW carries
                    # the PRUNER's count; the trim records files_read itself.
                    _pq_pruner_kept = len(pq_files) if pq_files else 0
                    if pq_files and _eff_raw_sql:
                        try:
                            from core.limit_early_stop import plan_hive_limit_early_stop as _les_hive
                            _les_hive_kept = _les_hive(_eff_raw_sql, tname, pq_files, _shared_s3, bucket,
                                                       road="setup_registered_views", table_prefix=prefix,
                                                       execution_id=execution_id)
                        except Exception as _les_hive_exc:  # noqa: BLE001 -- never break the read
                            logger.debug("[limit-early-stop] skipped for %r: %s", tname, _les_hive_exc)
                            _les_hive_kept = None
                        if _les_hive_kept is not None:
                            pq_files = _les_hive_kept
                    # ── THE ONE SCAN BUDGET (Phase 134-B; FB-55) ──────────
                    # 2026-09-21 — this used to read ``s3.scan_budget_hard``
                    # (shipped 1000) while ``core/federation_engine.py`` read
                    # ``s3.max_files_per_query`` (shipped 0) for the SAME
                    # decision about the SAME table.  Measured side by side
                    # on a 7,300-file table with no filters: federation 200
                    # in 12.2 s, this road refused.  A DECISION MADE TWICE IS
                    # A BUG.  ``core/scan_budget.resolve_scan_budget`` now
                    # owns the number, and ``scan_budget_hard`` survives only
                    # as a deprecated alias so a deliberate operator ceiling
                    # is not deleted underneath them.
                    #
                    # DATA-COMPLETENESS FIX (2026-07-06), unchanged: do NOT
                    # silently truncate to the first N files -- that returns
                    # an INCOMPLETE result with only a log warning.  The
                    # refusal is a ``ScanBudgetRefusal`` rather than a bare
                    # RuntimeError because the fallback handler below cannot
                    # otherwise tell a deliberate refusal from a registration
                    # FAILURE: on native access it treated this as "native
                    # mode failed", re-listed the whole prefix WITHOUT the
                    # partition filters and served it.  Refusing a scan and
                    # then serving a BIGGER one is the worst outcome on offer.
                    if pq_files:
                        try:
                            from core.config import s3 as _sb_cfg
                            _soft = _sb_cfg.scan_budget_soft
                            _suggest = _sb_cfg.suggest_partitions
                            _allow_trunc = bool(getattr(
                                _sb_cfg, "scan_budget_allow_truncation", False))
                        except Exception:
                            # Can't read config -> fail OPEN (no truncation, no
                            # raise) so a config hiccup never blocks a query.
                            _soft = 0
                            _suggest = False
                            _allow_trunc = False
                        from core.scan_budget import (
                            enforce_scan_budget as _enforce_budget,
                            resolve_scan_budget as _resolve_budget,
                        )
                        _hard = _resolve_budget().files
                        if _allow_trunc and _hard > 0 and len(pq_files) > _hard:
                            # The documented escape hatch for operators who
                            # accept partial results.  A CAP MAY THROTTLE —
                            # but it must not masquerade as pruning, so the
                            # slice is SURFACED the same way the BF-579 cap
                            # is: diagnostic store + a Completeness
                            # Certificate downgraded to INCOMPLETE.  Before
                            # 2026-09-21 this path had a logger.warning and
                            # nothing else, so an opted-in truncation could
                            # still be certified COMPLETE.
                            logger.warning(
                                "SCAN-BUDGET: '%s' %d > %d files -- TRUNCATING "
                                "to first %d (scan_budget_allow_truncation="
                                "true; result is INCOMPLETE)",
                                tname, len(pq_files), _hard, _hard)
                            _budget_dropped = len(pq_files) - _hard
                            try:
                                from core.scan_truncation import (
                                    record_scan_truncation as _rec_trunc,
                                )
                                _bt_info = _rec_trunc(
                                    table=tname, kind="scan_budget_truncation",
                                    reason=(
                                        f"s3.scan_budget_allow_truncation=true "
                                        f"sliced '{tname}' from {len(pq_files)} "
                                        f"to {_hard} files after pruning — "
                                        f"{_budget_dropped} file(s) DROPPED"),
                                    cap=_hard, files_before=len(pq_files),
                                    files_registered=_hard,
                                    dropped=_budget_dropped,
                                    execution_id=execution_id,
                                )
                                if _bt_info:
                                    _file_cap_by_table[tname] = _bt_info
                            except Exception as _bt_exc:
                                logger.warning(
                                    "SCAN-BUDGET: could not surface the "
                                    "opted-in truncation for '%s' (%s) — the "
                                    "slice still applied", tname, _bt_exc)
                            pq_files = pq_files[:_hard]
                        else:
                            _enforce_budget(
                                len(pq_files), table=tname, bucket=bucket,
                                prefix=prefix, listed=total_pq,
                                filters=len(_tbl_filters or []),
                                road="reg-view")
                        if _soft > 0 and len(pq_files) > _soft and _suggest:
                            logger.warning(
                                "SCAN-BUDGET: '%s' exceeds soft limit (%d > %d "
                                "files) — consider partition filters",
                                tname, len(pq_files), _soft)

                    # ── Phase 151.E: plain parquet mirror routing swap ──
                    # When a healthy mirror exists for this (bucket, prefix)
                    # AND BOTH the global routing flag + per-row toggle
                    # are on, swap pq_files for the mirror's read targets.
                    # SHADOW posture is the default — flags ship OFF.
                    _mirror_id_pq = None
                    if pq_files:
                        try:
                            from core.plain_parquet_mirror import (
                                PlainParquetMirrorEngine,
                            )
                            _eng_pq = PlainParquetMirrorEngine.get_default(
                                db_manager or _db_manager,
                            )
                            pq_files, _mirror_id_pq = _eng_pq.route_files(
                                bucket=bucket, prefix=prefix,
                                source_files=pq_files,
                            )
                            if _mirror_id_pq is not None:
                                logger.info(
                                    "PLAIN-PARQUET-MIRROR: '%s' routed via "
                                    "mirror_id=%s", tname, _mirror_id_pq,
                                )
                        except Exception as _mr_exc:
                            logger.debug(
                                "plain_parquet mirror routing skipped "
                                "for '%s': %s", tname, _mr_exc,
                            )

                    # ── Phase 151.B: pruning_history write (parquet) ─────
                    # Single row per registered parquet table per query,
                    # stamped format='parquet' so brain components see it.
                    try:
                        from core.plain_parquet_brain_hooks import (
                            record_pruning_history_for_parquet as _rec_pp,
                            brain_enabled as _pp_brain_on,
                        )
                        if _pp_brain_on() and total_pq > 0:
                            _stage_drops_pq = {
                                "partition":  max(0, total_pq - _supp_before),
                                "supplement": int(_supplement_drops_pq),
                                "bloom":      int(_bloom_drops_pq),
                            }
                            # Phase 151 audit — pass `file_keys` so the
                            # helper derives the SAME synthetic token as
                            # the supplement-sync daemon + PlainParquetCatalog.
                            # Without this, supplement rows and pruning_history
                            # rows carry different snapshot_ids for the same
                            # (bucket, prefix), confusing operators.
                            _rec_pp(
                                bucket=bucket, table_prefix=prefix,
                                files_before_prune=total_pq,
                                files_after_prune=_pq_pruner_kept,
                                stage_drops=_stage_drops_pq,
                                filter_breakdown=_tbl_filters,
                                file_keys=pq_files,
                            )
                    except Exception as _ph_exc:
                        logger.debug(
                            "plain_parquet pruning_history skipped for '%s': %s",
                            tname, _ph_exc,
                        )

                    if not pq_files:
                        logger.info("REG-VIEW '%s': 0 files after pruning — creating empty view", tname)
                        _schema_pq = _list_s3_parquet_files(_shared_s3, bucket, prefix, max_files=1)
                        if _schema_pq:
                            _schema_urls = _s3_urls_to_presigned(_shared_s3, _schema_pq[:1], conn_config)
                            # BF-200: On on-prem S3 (presigned mode), DuckDB httpfs cannot open
                            # presigned URLs (HTTP 0 / SSL errors with self-signed certs).
                            # Pre-download the single schema sample file via _presigned_to_local()
                            # before passing to DuckDB — same approach as the non-empty path.
                            _schema_view_paths = _schema_urls
                            _schema_tmp = None
                            if _is_presigned:
                                try:
                                    _schema_view_paths, _schema_tmp = _presigned_to_local(
                                        _schema_urls, conn_config,
                                        s3_client=_shared_s3,
                                        original_s3_urls=None,
                                    )
                                    if _schema_tmp:
                                        with _global_temp_dirs_lock:
                                            _global_temp_dirs.append(_schema_tmp)
                                except Exception as _schema_dl_err:
                                    logger.warning(
                                        "REG-VIEW '%s': schema-sample pre-download failed (%s) — "
                                        "skipping empty view (table absent from this query; "
                                        "0 files matched the partition filter anyway)",
                                        tname, _schema_dl_err,
                                    )
                                    _schema_view_paths = []  # BF-200: don't pass presigned URL to DuckDB (HTTP 0)
                            if _schema_view_paths:
                                con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'{_esc(_schema_view_paths[0])}\', hive_partitioning=true) WHERE FALSE')
                    else:
                        # ── THE THIRD CEILING, REMOVED (FB-55, 2026-09-21) ──
                        # ``limits.max_registered_files`` (5,000) used to
                        # slice the plain-parquet list here, keeping the LAST
                        # N.  It never fired while ``scan_budget_hard=1000``
                        # refused first — and the moment the two gates were
                        # unified onto one key, it did.  MEASURED, on the
                        # same 7,300-file table this whole item is about:
                        #
                        #   BF-579: 'trades' has 7300 parquet files after
                        #   pruning, capping to 5000 (most recent) —
                        #   DROPPING 2300 file(s)
                        #
                        # HTTP 200, four region groups instead of five, and
                        # the AMER rows simply absent.  Unifying the gates
                        # without removing this would have turned an honest
                        # refusal into a silently incomplete answer, which is
                        # the worse of the two by a long way.
                        #
                        # It is REMOVED rather than converted into a refusal
                        # because a refusal at 5,000 would just re-create
                        # FB-55 at a different number: federation applies no
                        # such cap, so the two roads would disagree again.
                        # Plain parquet now has exactly ONE file-count
                        # ceiling — ``core/scan_budget.py`` — and it is a
                        # GATE.  The backstops that remain are real and all
                        # of them REFUSE or disclose rather than drop rows:
                        # ``s3.listing_max_files`` (50,000) refuses at
                        # enumeration, ``s3.max_files_per_query`` bounds the
                        # read wherever an operator wants it, and the
                        # pre-download path keeps its own disk cap.
                        #
                        # The number was arbitrary in the same way the 5,000
                        # listing cap was: measured 2026-09-06, DuckDB takes
                        # a 200,000-element path list and every cost is
                        # linear.  ``_apply_registered_files_cap`` stays, and
                        # the ICEBERG branch above still uses it — that is
                        # where 5,000 was chosen (raised back from BF-579's
                        # lowering "for legitimate 3000-file Iceberg BQB
                        # scans") and its count comes from a manifest rather
                        # than a listing.
                        _pq_s3_originals = list(pq_files)  # save s3:// URLs before presigning
                        # Smart-VPC fast path (2026-06-23) — mirror of the
                        # iceberg branch above (see that branch's comments
                        # for full rationale + failure semantics).
                        _pq_vpc_handled = False
                        _pq_vpc_needed_predownload = False
                        try:
                            from core.s3_utilities import (
                                vpc_presigned_rewrite_needed as _vpc_need_pq,
                                s3_urls_to_presigned_vpc as _vpc_presign_pq,
                            )
                            if _vpc_need_pq(conn_config, _pq_s3_originals):
                                try:
                                    pq_files = _vpc_presign_pq(
                                        _shared_s3, pq_files, conn_config)
                                    _pq_vpc_handled = True
                                    logger.info(
                                        "REG-VIEW '%s' (parquet): VPC + hive -> "
                                        "rewrote %d s3:// URL(s) to presigned "
                                        "HTTPS (DuckDB reads via VPC, no download)",
                                        tname, len(_pq_s3_originals))
                                except Exception as _vpc_pq_sign_exc:
                                    _pq_vpc_needed_predownload = True
                                    logger.warning(
                                        "REG-VIEW '%s' (parquet): VPC "
                                        "presigned-rewrite FAILED (%s) -- "
                                        "forcing pre-download safety net",
                                        tname, _vpc_pq_sign_exc)
                        except Exception as _vpc_pq_exc:
                            logger.warning(
                                "REG-VIEW '%s' (parquet): VPC presigned-"
                                "rewrite skipped (non-fatal): %s",
                                tname, _vpc_pq_exc)
                        if not _pq_vpc_handled:
                            pq_files = _s3_urls_to_presigned(_shared_s3, pq_files, conn_config)
                        if not _pq_vpc_handled and _is_presigned and pq_files:
                            # 2026-06-24 -- redact SigV4 secrets before logging.
                            # First 200 chars of a presigned URL include
                            # X-Amz-Credential + X-Amz-Date.  Anyone
                            # reading logs gets exploitable data.
                            try:
                                from core.proxy_utils import sanitize_proxy_error as _redact_url
                                _safe_sample = _redact_url(pq_files[0])[:200]
                            except Exception:
                                _safe_sample = pq_files[0].split("?")[0][:200]
                            logger.info("REG-VIEW '%s': sample pre-signed URL (first 200 chars, secrets redacted): %s",
                                        tname, _safe_sample)
                            # BF-429 — router-first (gated by presigned_router_enabled).
                            _ppr_pq = _try_router_for_presigned(
                                s3_client=_shared_s3, conn_config=conn_config,
                                bucket=bucket, s3_keys=_pq_s3_originals,
                                table_name=tname, progress_fn=progress_fn,
                                forced_reader=_extract_reader_override(query_config),
                                partition_filters=partition_filters,
                                raw_sql=raw_sql, query_config=query_config,
                            )
                            if (_ppr_pq is not None
                                    and _ppr_pq.output_kind in ("local_paths", "s3_paths")
                                    and _ppr_pq.read_targets):
                                pq_files = _ppr_pq.read_targets
                                logger.info("REG-VIEW '%s': presigned router=%s "
                                            "served %d file(s) (%s) in %.1fs",
                                            tname, _ppr_pq.reader_name,
                                            _ppr_pq.files_succeeded,
                                            _ppr_pq.output_kind,
                                            _ppr_pq.duration_seconds)
                            else:
                                # DuckDB's bundled httpfs/libcurl cannot reliably open on-prem S3
                                # presigned URLs (HTTP 0 / SSL handshake failure against self-signed
                                # certs). Pre-download via Python urllib (OS SSL stack, same as boto3)
                                # then create the view with local paths — DuckDB reads from disk.
                                # Hive partition directory structure is preserved by _presigned_to_local()
                                # so hive_partitioning=true still extracts column values from paths.
                                try:
                                    pq_files, _vw_tmp = _presigned_to_local(
                                        pq_files, conn_config,
                                        s3_client=_shared_s3,
                                        # 2026-07-04: pass the index-aligned
                                        # s3:// originals (saved pre-presign at
                                        # _pq_s3_originals) so _presigned_to_local
                                        # can RE-SIGN and retry on a 403 when a
                                        # presigned URL expires mid-download --
                                        # matching the iceberg branch.  None here
                                        # left large on-prem parquet scans failing
                                        # instead of re-signing.
                                        original_s3_urls=_pq_s3_originals,
                                    )
                                    if _vw_tmp:
                                        with _global_temp_dirs_lock:
                                            _global_temp_dirs.append(_vw_tmp)
                                        logger.info(
                                            "REG-VIEW '%s': boto3 pre-download → %d local file(s) in %s",
                                            tname, len(pq_files), _vw_tmp,
                                        )
                                except Exception as _vw_dl_err:
                                    logger.warning(
                                        "REG-VIEW '%s': boto3 pre-download failed (%s) — "
                                        "passing presigned URLs to DuckDB directly (may fail with HTTP 0)",
                                        tname, _vw_dl_err,
                                    )
                        # BF-251 / BF-259: pre-download via parallel boto3 when
                        # corporate proxy active OR persistent S3 cache opted in.
                        # BF-416: skip-when-tiny — same logic as the iceberg branch.
                        elif (not _pq_vpc_handled) and (_pq_vpc_needed_predownload or _is_proxy_active_for_duckdb() or _is_s3_cache_active() or _is_parallel_predownload_active()) and _pq_s3_originals:
                            from core.s3_predownload import should_predownload as _should_pd_pq
                            if not _should_pd_pq(len(_pq_s3_originals)):
                                logger.info(
                                    "REG-VIEW '%s': %d files <= predownload_skip_threshold — "
                                    "letting DuckDB httpfs read directly (proxy + serial)",
                                    tname, len(_pq_s3_originals),
                                )
                            else:
                                _trigger = ("proxy" if _is_proxy_active_for_duckdb()
                                            else "cache" if _is_s3_cache_active()
                                            else "parallel_predownload")
                                # BF-428H — same router-first bridge as the
                                # Iceberg branch (cross-cutting audit C2).
                                _router_result = _try_router_for_predownload(
                                    s3_client=_shared_s3,
                                    bucket=bucket,
                                    s3_keys=_pq_s3_originals,
                                    table_name=tname,
                                    progress_fn=progress_fn,
                                    forced_reader=_extract_reader_override(query_config),
                                    # 2026-08-03 defect fix — same context the
                                    # presigned sibling passes (projection +
                                    # trusted row-group filters); filters only
                                    # for PRIMARY tables, same trust scope as
                                    # file-level pruning.
                                    partition_filters=(
                                        partition_filters
                                        if _tname_lower in _primary_tables
                                        else None),
                                    raw_sql=raw_sql,
                                    query_config=query_config,
                                )
                                _t_dl0 = _time.monotonic()
                                if _router_result is not None:
                                    _local_paths = _router_result.read_targets
                                    pq_files = _local_paths
                                    logger.info(
                                        "REG-VIEW '%s': router=%s served %d "
                                        "file(s) (bytes_read=%d cache_hits=%d) "
                                        "in %.1fs", tname,
                                        _router_result.reader_name,
                                        _router_result.files_succeeded,
                                        _router_result.bytes_read,
                                        _router_result.cache_hits,
                                        _router_result.duration_seconds,
                                    )
                                else:
                                    try:
                                        _local_paths, _vw_tmp = _s3_to_local_via_boto3(
                                            _shared_s3, _pq_s3_originals,
                                            progress_callback=(
                                                (lambda done, total, _t=tname: progress_fn({
                                                    "status": "processing",
                                                    "log": f"Downloading {tname}: {done}/{total} files",
                                                })) if progress_fn else None
                                            ),
                                        )
                                        # BF-418 follow-up — utility self-registers
                                        # temp_dir; explicit append removed to
                                        # avoid duplicate _global_temp_dirs entry.
                                        pq_files = _local_paths
                                        logger.info(
                                            "REG-VIEW '%s': boto3 pre-download (%s) → %d local file(s) in %.1fs",
                                            tname, _trigger, len(_local_paths), _time.monotonic() - _t_dl0,
                                        )
                                    except Exception as _proxy_dl_err:
                                        logger.warning(
                                            "REG-VIEW '%s': boto3 pre-download (%s) failed (%s) — "
                                            "falling back to DuckDB httpfs (may be slow)",
                                            tname, _trigger, _proxy_dl_err,
                                        )
                        # BF-PRUNE-PERF: same flag for parquet branch.
                        try:
                            from core.config import s3 as _s3_cfg_pq
                            _ubn_pq = _s3_cfg_pq.duckdb_union_by_name_parquet
                        except Exception:
                            _ubn_pq = False
                        _union_clause_pq = ", union_by_name=true" if _ubn_pq else ""
                        try:
                            from core.execution_stage import (
                                set_stage as _set_stg_pq,
                                STAGE_DUCKDB_SETUP as _S_SETUP_PQ,
                            )
                            _exec_id_pq_setup = _DL_EXEC_ID_CTX.get(None)
                            if _exec_id_pq_setup:
                                _set_stg_pq(_exec_id_pq_setup, _S_SETUP_PQ,
                                             files_total=len(pq_files),
                                             message=f"Registering '{tname}' ({len(pq_files)} parquet files)")
                        except Exception:
                            pass
                        # BF-494 — parquet hive-partitioned tables can ALSO
                        # have mismatched hive-key sets across files
                        # (manual file moves, user wrote files under
                        # inconsistent paths, or Iceberg-style spec
                        # evolution for a table tracked as "parquet"
                        # here).  Helper falls back to UNION ALL BY NAME
                        # when it detects multiple hive signatures;
                        # otherwise emits the original single
                        # read_parquet form (no behaviour change).
                        _from_expr_pq = _build_iceberg_read_expr(
                            pq_files, union_clause=_union_clause_pq,
                            hive_types=_declared_partition_types(
                                connection_id, tname, db_manager, paths=pq_files),
                        )
                        if "UNION ALL BY NAME" in _from_expr_pq:
                            logger.info(
                                "REG-VIEW '%s': parquet hive-key mismatch "
                                "across %d signature group(s) — emitting "
                                "UNION ALL BY NAME view",
                                tname, _from_expr_pq.count("read_parquet"),
                            )
                        # JOIN-PRUNER row-group injection (parquet path) —
                        # mirror the iceberg branch.  When synth filters
                        # were built for this target, append as WHERE so
                        # DuckDB row-group pruning applies them.
                        _view_where_pq = (
                            f' WHERE {_join_view_where}' if _join_view_where else ''
                        )
                        con.execute(
                            f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                            f'SELECT * FROM {_from_expr_pq}{_view_where_pq}'
                        )
                        if _join_view_where:
                            logger.info(
                                "JOIN-PRUNER: appended view WHERE for parquet '%s': %s",
                                tname, _join_view_where[:200],
                            )
                        if _tname_lower in _primary_tables:
                            _any_primary_registered_with_data = True
                        _registered_ok.add(tname)
                        if progress_fn:
                            progress_fn({"status": "processing",
                                         "log": f"Registered '{tname}' ({len(pq_files)} parquet files)"})
                    _file_stats[tname] = {
                        "total": total_pq, "after_pruning": len(pq_files), "format": "parquet",
                        "after_footer_pruning": _after_footer,  # Phase 134
                        "file_list_hash": _pq_file_hash,  # Phase 104
                        "file_count": _pq_file_count,     # Phase 104
                    }
                    # 2026-08-20 — truncation distinct from pruning (see
                    # the iceberg stats site above for rationale).
                    if tname in _file_cap_by_table:
                        _file_stats[tname]["file_cap"] = _file_cap_by_table[tname]
                else:
                    if total_pq == 0:
                        # 2026-10-14 -- NO data files under the table's folder
                        # (listed by Hive's rule, s3_utilities.is_parquet_data_key):
                        # refused, never an empty view (scan_truncation.
                        # NoDataFilesRefusal).  Pruning everything away is the
                        # other branch -- that table HAS data.
                        from core.scan_truncation import NoDataFilesRefusal
                        raise NoDataFilesRefusal(
                            f"Table '{tname}' has no data files under s3://{bucket}/{prefix} "
                            f"(only hidden files such as _SUCCESS, or nothing at all). The "
                            f"query is refused rather than answered as empty: check the "
                            f"table's location, or that its data has landed.")
                    if _is_presigned:
                        # Presigned mode: glob not possible — create empty view instead
                        logger.warning("REG-VIEW '%s': no parquet files found under %s/%s (presigned mode) — creating empty schema view (glob not safe)", tname, bucket, prefix)
                    else:
                        # BF-494 audit follow-up — instead of letting
                        # DuckDB resolve the glob internally (which
                        # crashes on hive-key mismatch), do a deep
                        # boto3 listing first and pass the file list
                        # through the helper so partition-spec
                        # evolution is handled correctly here too.
                        # Falls back to the original glob form only when
                        # boto3 listing itself fails.
                        logger.warning("REG-VIEW '%s': no parquet files found under %s/%s — boto3 deep-list fallback", tname, bucket, prefix)
                        _glob_files: list = []
                        try:
                            _glob_files = _list_s3_parquet_files(
                                _shared_s3, bucket, prefix,
                            ) or []
                        except Exception as _gl_exc:
                            logger.warning(
                                "REG-VIEW '%s': boto3 deep-list failed (%s) — "
                                "falling through to raw read_parquet glob "
                                "(may hit Hive Partition Mismatch if files "
                                "have mismatched hive keys)",
                                tname, _gl_exc,
                            )
                        if _glob_files:
                            _from_expr_gl = _build_iceberg_read_expr(
                                _glob_files, hive_types=_declared_partition_types(
                                    connection_id, tname, db_manager, paths=_glob_files))
                            if "UNION ALL BY NAME" in _from_expr_gl:
                                logger.info(
                                    "REG-VIEW '%s': glob-fallback hive-key "
                                    "mismatch across %d signature group(s) — "
                                    "emitting UNION ALL BY NAME view",
                                    tname, _from_expr_gl.count("read_parquet"),
                                )
                            con.execute(
                                f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                f'SELECT * FROM {_from_expr_gl}'
                            )
                        else:
                            # Last-resort raw glob — preserves legacy
                            # behaviour when boto3 listing itself failed.
                            con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.parquet\', hive_partitioning=true)')
                        if _tname_lower in _primary_tables:
                            _any_primary_registered_with_data = True  # glob may have data
                        _registered_ok.add(tname)
                    # Phase 104: record fingerprint even when no files found via listing
                    _file_stats[tname] = {
                        "total": 0, "after_pruning": 0, "format": "parquet",
                        "file_list_hash": _pq_file_hash,
                        "file_count": _pq_file_count,
                    }
            except Exception as e:
                # A truncation REFUSAL is not a registration failure.  Falling
                # back here would re-list the same truncated key set and
                # register it with the partition filter dropped, turning a
                # deliberate refusal into a silent partial answer.
                #
                # 2026-09-21 (FB-55) — ``ScanBudgetRefusal`` joins it, and it
                # is not hypothetical: the scan budget raised a bare
                # RuntimeError into this handler, so on NATIVE access mode a
                # refused 7,300-file scan fell through to the branch below,
                # which calls ``_list_s3_parquet_files(bucket, prefix)`` —
                # the WHOLE prefix, with every partition filter computed
                # above discarded — presigns it and serves HTTP 200.  The
                # gate refused a scan and the fallback then ran a BIGGER one.
                # Presigned mode hid this because its branch re-raises.
                from core.scan_truncation import (
                    TruncatedScanRefusal as _TSRefuse,
                    ScanBudgetRefusal as _SBRefuse,
                    NoDataFilesRefusal as _NDRefuse,
                )
                if isinstance(e, (_TSRefuse, _SBRefuse, _NDRefuse)):
                    raise
                _access_mode = _get_s3_access_mode(conn_config)
                if _access_mode == "presigned":
                    # Presigned mode: glob fallback not possible — propagate error
                    logger.error("REG-VIEW '%s': parquet registration failed (presigned mode, no glob fallback): %s", tname, e, exc_info=True)
                    raise RuntimeError(
                        f"Failed to register S3 table '{tname}': {e}. "
                        f"Check S3 credentials, endpoint URL, and path_style setting."
                    ) from e
                else:
                    # Native mode failed — try presigned URLs as intermediate fallback
                    # (DuckDB httpfs may URL-encode '=' to '%3D' in hive partition paths)
                    logger.warning("REG-VIEW '%s': DuckDB view creation failed in native mode: %s — trying presigned URLs", tname, e, exc_info=True)
                    _ps_ok = False
                    try:
                        _ps_files = _list_s3_parquet_files(_shared_s3, bucket, prefix)
                        if _ps_files:
                            # Force presigned conversion regardless of access mode
                            _ps_presigned = []
                            for _ps_url in _ps_files:
                                if _ps_url.startswith("s3://"):
                                    _ps_parts = _ps_url[5:].split("/", 1)
                                    _ps_key = _ps_parts[1] if len(_ps_parts) > 1 else ""
                                    try:
                                        from urllib.parse import urlparse, urlunparse, unquote
                                        # 2026-06-24 -- read VPC presigned TTL
                                        # from config (was hardcoded 3600s/1h).
                                        # Large Iceberg scans exceed 1h; expired
                                        # URLs mid-query -> HTTP 403.
                                        try:
                                            from core.config import get as _cfg_get
                                            _ps_ttl = int(_cfg_get(
                                                "presigned_url",
                                                "vpc_expiry_seconds", 21600))
                                        except Exception:
                                            _ps_ttl = 21600
                                        _ps_signed = _shared_s3.generate_presigned_url(
                                            "get_object",
                                            Params={"Bucket": _ps_parts[0], "Key": _ps_key},
                                            ExpiresIn=_ps_ttl,
                                        )
                                        _parsed = urlparse(_ps_signed)
                                        _decoded = unquote(_parsed.path)
                                        if _decoded != _parsed.path:
                                            _ps_signed = urlunparse((_parsed.scheme, _parsed.netloc, _decoded,
                                                                     _parsed.params, _parsed.query, _parsed.fragment))
                                        _ps_presigned.append(_ps_signed)
                                    except Exception:
                                        _ps_presigned.append(_ps_url)
                                else:
                                    _ps_presigned.append(_ps_url)
                            # BF-494 — presigned-fallback parquet path
                            # also needs hive-signature grouping.
                            _from_expr_ps = _build_iceberg_read_expr(
                                _ps_presigned, union_clause=", union_by_name=true",
                                hive_types=_declared_partition_types(
                                    connection_id, tname, db_manager, paths=_ps_presigned),
                            )
                            if "UNION ALL BY NAME" in _from_expr_ps:
                                logger.info(
                                    "REG-VIEW '%s': presigned-parquet hive-key "
                                    "mismatch — emitting UNION ALL BY NAME view",
                                    tname,
                                )
                            con.execute(
                                f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                f'SELECT * FROM {_from_expr_ps}'
                            )
                            if _tname_lower in _primary_tables:
                                _any_primary_registered_with_data = True
                            _ps_ok = True
                            _registered_ok.add(tname)
                            logger.info("REG-VIEW '%s': presigned fallback succeeded (%d files)", tname, len(_ps_presigned))
                    except Exception as _ps_err:
                        logger.warning("REG-VIEW '%s': presigned fallback also failed: %s", tname, _ps_err)
                    if not _ps_ok:
                        logger.error("REG-VIEW '%s': all registration attempts failed — table will be unavailable", tname)
                        # BF-474 — parquet path also tracks registration failures.
                        _registration_failures[tname] = {
                            "error_type": "RegistrationFailed",
                            "error_message": "all registration attempts failed (presigned + native)",
                            "table_format": "parquet",
                            "files_pre_failure": None,
                        }

        elif fmt == "csv":
            if _get_s3_access_mode(conn_config) == "presigned":
                # Presigned mode: glob not possible — pre-list + pre-sign CSV files
                try:
                    from core.s3_utilities import list_s3_csv_files as _csv_list, s3_urls_to_presigned as _csv_presign
                    # 2026-08-20 — A TRUNCATED CSV LISTING IS NOT A COMPLETE ONE.
                    # ``list_s3_csv_files`` has stamped ``truncated=True`` at its
                    # 5000-file cap since 2026-08-03; every parquet listing site
                    # surfaces that verdict and this one did not, so a >cap CSV
                    # table served a SUBSET and certified COMPLETE.  Read the
                    # verdict HERE: presigning returns a plain list and the flag
                    # is gone by the next line.
                    _csv_files = _csv_list(_shared_s3, bucket, prefix)
                    try:
                        from core.scan_truncation import surface_truncated_listing
                        _csv_trunc = surface_truncated_listing(
                            _csv_files, table=tname, bucket=bucket,
                            prefix=prefix, execution_id=execution_id)
                        if _csv_trunc:
                            _file_cap_by_table[tname] = _csv_trunc
                    except Exception as _csv_trunc_exc:
                        logger.warning(
                            "REG-VIEW '%s': could not surface CSV listing "
                            "truncation (%s)", tname, _csv_trunc_exc)
                    if not _csv_files:
                        logger.warning("REG-VIEW '%s': no CSV files found (presigned mode) under s3://%s/%s/", tname, bucket, prefix)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT 1 WHERE FALSE')
                        # 2026-08-20 — unlike the parquet branch this used to
                        # register the never-match view WITHOUT recording a
                        # registration failure, so the BF-484/BF-514 gate
                        # (_raise_if_registration_failed / feed _all_empty
                        # check) could not fire: a transient/permission-
                        # filtered LIST yielding [] served 0 rows as HTTP 200.
                        # An empty listing and a failed listing are
                        # indistinguishable here — fail CLOSED and say so.
                        _registration_failures[tname] = {
                            "error_type": "EmptyCsvListing",
                            "error_message": (
                                f"boto3 LIST returned 0 CSV files under "
                                f"s3://{bucket}/{prefix}/ — cannot distinguish "
                                f"an empty dataset from a failed or "
                                f"permission-filtered listing; refusing to "
                                f"serve 0 rows as a silent success. Verify "
                                f"the prefix and S3 list permissions."
                            ),
                            "table_format": "csv",
                            "files_pre_failure": 0,
                        }
                    else:
                        _csv_files = _csv_presign(_shared_s3, _csv_files, conn_config)
                        _csv_esc = lambda v: v.replace("'", "''")
                        _csv_paths = ", ".join(f"'{_csv_esc(f)}'" for f in _csv_files)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_csv_auto([{_csv_paths}])')
                        if _tname_lower in _primary_tables:
                            _any_primary_registered_with_data = True
                        _registered_ok.add(tname)
                        _file_stats[tname] = {"total": len(_csv_files), "after_pruning": len(_csv_files), "format": "csv"}
                        # Truncation is DISTINCT from pruning: after_pruning ==
                        # total here, which is exactly what a capped listing
                        # looks like from the envelope unless it is said.
                        if tname in _file_cap_by_table:
                            _file_stats[tname]["file_cap"] = _file_cap_by_table[tname]
                except Exception as _csv_err:
                    logger.error("REG-VIEW '%s': CSV registration failed (presigned mode): %s", tname, _csv_err, exc_info=True)
                    raise RuntimeError(
                        f"Failed to register S3 CSV table '{tname}': {_csv_err}. "
                        f"Check S3 credentials, endpoint URL, and path_style setting."
                    ) from _csv_err
            else:
                con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_csv_auto(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.csv\')')
                if _tname_lower in _primary_tables:
                    _any_primary_registered_with_data = True
                _registered_ok.add(tname)

    # ── Register materialized views as local VIEWs ─────────────────────
    _mv_storage = getattr(_mv_cfg, 'storage_dir', None) if _mv_cfg else None
    if _mv_storage and _db_manager:
        try:
            mv_list = _db_manager.list_materialized_views(connection_id=connection_id)
            for mv in mv_list:
                if mv["status"] != "ready" or not mv.get("is_active", True):
                    continue
                mv_name = mv["name"]
                tname_esc_mv = f"__mv__{mv_name}".replace('"', '""')
                mv_dir = os.path.join(_mv_storage, str(mv["id"]))
                import glob as _glob_mod
                pq_files = _glob_mod.glob(os.path.join(mv_dir, "*.parquet"))
                if pq_files:
                    paths_str = ", ".join(f"'{_to_ddb_path(p)}'" for p in pq_files)
                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc_mv}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
        except Exception as e:
            logger.warning("Could not register MV views: %s", e, exc_info=True)

    # ── Register local tables as local VIEWs ───────────────────────────
    _lt_storage = getattr(_lt_cfg, 'storage_dir', None) if _lt_cfg else None
    if _lt_storage and _db_manager:
        try:
            import glob as _glob_mod2
            lt_list = _db_manager.list_local_tables()
            for lt in lt_list:
                if lt["status"] != "ready" or not lt.get("is_active", True):
                    continue
                lt_name = lt["name"]
                tname_esc_lt = f"__lt__{lt_name}".replace('"', '""')
                lt_dir = os.path.join(_lt_storage, str(lt["id"]))
                pq_files = _glob_mod2.glob(os.path.join(lt_dir, "*.parquet"))
                if pq_files:
                    paths_str = ", ".join(f"'{_to_ddb_path(p)}'" for p in pq_files)
                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc_lt}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                    try:
                        _db_manager.touch_local_table(lt["id"])
                    except Exception as _touch_exc:
                        logger.error("Failed to touch local table '%s' (id=%s): %s", lt_name, lt["id"], _touch_exc, exc_info=True)
                else:
                    logger.warning("Local table '%s' (id=%s) has no parquet files at %s — view __lt__%s will NOT be created",
                                   lt_name, lt["id"], lt_dir, lt_name)
        except Exception as e:
            logger.warning("Could not register local table views: %s", e, exc_info=True)

    # ── Phase 97: Register materialized federation views as local VIEWs ─
    if _db_manager:
        try:
            import glob as _glob_fv
            fv_list = _db_manager.list_materialized_federation_views()
            for fv in fv_list:
                fv_name = fv["name"]
                fv_dir = fv.get("storage_path")
                if not fv_dir or not os.path.isdir(fv_dir):
                    continue
                pq_files = list(_glob_fv.glob(os.path.join(fv_dir, "*.parquet")))
                if pq_files:
                    tname_esc_fv = f"__fv__{fv_name}".replace('"', '""')
                    paths_str = ", ".join(f"'{_to_ddb_path(p)}'" for p in pq_files)
                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc_fv}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                    logger.info("Registered federation view '%s' with %d local files", fv_name, len(pq_files))
        except Exception as e:
            logger.warning("Could not register federation views: %s", e, exc_info=True)

    # ── Build SQL ──────────────────────────────────────────────────────
    # ── Guard: warn if join references a view that wasn't created ──────
    if query_config and query_config.joins and _registered_ok:
        # 2026-09-05 round 2 -- a FIFTH copy, also missing
        # ``__iceberg__:``, found by the guard written for the fourth.
        # ``core.query_compiler._strip_virtual`` returns its argument
        # unchanged when nothing matched, which is exactly what this
        # chain did.
        from core.query_compiler import _strip_virtual as _strip_reg
        for _jc in (query_config.joins or []):
            _rf = _jc.right_file
            if isinstance(_rf, list):
                _rf = _rf[0] if _rf else ""
            elif not isinstance(_rf, str):
                _rf = getattr(_rf, 'path', str(_rf))
            _rf_name = _strip_reg(_rf)
            if _rf_name and _all_query_tables and _rf_name in _all_query_tables and _rf_name not in _registered_ok:
                logger.error("JOIN references '%s' but its view was NOT created — query will fail with Catalog Error. "
                             "Check backend logs for registration warnings above.", _rf_name)

    # Translate tableName.col → tN.col AFTER partition pruning so that
    # _compute_table_filters above could use original table names to scope
    # filters correctly.  This mutates query_config in-place.
    _translate_join_columns(query_config)

    # ── BF-61b: Validate right_column_aliases against actual view columns ──
    # The frontend may include aliases for columns that don't exist in the
    # right table (e.g. hive partition cols only in the left table).  DuckDB's
    # EXCLUDE is strict and throws BinderError if the column is missing.
    # Probe each right-table view's columns and drop any non-existent aliases.
    if query_config.joins:
        # 2026-09-05 round 2 -- a SIXTH copy, same shape, same omission.
        from core.query_compiler import _strip_virtual as _strip_vp
        _view_col_cache: dict = {}
        def _get_view_cols(view_name: str) -> Optional[set]:
            if view_name in _view_col_cache:
                return _view_col_cache[view_name]
            # Try real DuckDB probe (works when con is a real connection, not SQLCollector)
            try:
                _r = con.execute(f'SELECT * FROM "{view_name.replace(chr(34), chr(34)+chr(34))}" LIMIT 0')
                if hasattr(_r, 'fetchdf'):
                    cols = set(_r.fetchdf().columns)
                    _view_col_cache[view_name] = cols
                    return cols
            except Exception as e:
                logger.debug("Failed to fetch view columns via DuckDB for %s: %s", view_name, e)
            # Fallback: registered_tables schema metadata
            for _rt in (registered_tables or []):
                if _rt["name"] == view_name and _rt.get("columns"):
                    cols = set(c["name"] if isinstance(c, dict) else c for c in _rt["columns"])
                    _view_col_cache[view_name] = cols
                    return cols
            _view_col_cache[view_name] = None
            return None

        for _jc in query_config.joins:
            if not _jc.right_column_aliases:
                continue
            _rt = _jc.right_file if isinstance(_jc.right_file, str) else getattr(_jc.right_file, 'path', str(_jc.right_file))
            _rt_name = _strip_vp(_rt)
            _view_cols = _get_view_cols(_rt_name)
            if _view_cols is not None:
                _bad = [c for c in _jc.right_column_aliases if c not in _view_cols]
                if _bad:
                    logger.warning("BF-61b: dropping %d non-existent columns from right_column_aliases "
                                   "for '%s': %s (available: %s)", len(_bad), _rt_name, _bad, sorted(_view_cols)[:20])
                    for _bc in _bad:
                        del _jc.right_column_aliases[_bc]
            else:
                # Cannot determine columns (SQLCollector path / COPY TO) — clear aliases
                # to avoid EXCLUDE on possibly non-existent columns.  DuckDB handles
                # duplicate column names natively via t0.col / t1.col qualification.
                logger.warning("BF-61b: cannot verify columns for '%s' — clearing right_column_aliases "
                               "to avoid EXCLUDE BinderError (COPY TO path)", _rt_name)
                _jc.right_column_aliases = {}

    from core.query_converter import rewrite_registered_refs
    # BF-99: Convert Pydantic QueryConfigModel → engine QueryConfig before
    # build_query_sql — Pydantic FilterModel/CaseExpressionModel etc. are not
    # subscriptable (f["column"] fails).  Attribute access (.files, .joins) is fine
    # for _build_duckdb_from_clause, but build_query_sql uses dict subscript on
    # nested objects (filters, computed_columns, case_expressions, window_functions).
    if hasattr(query_config, 'model_dump'):
        from core.query_converter import convert_query_config_to_engine
        query_config = convert_query_config_to_engine(query_config)
    # Phase 145 hotfix (2026-05-18, BF-455) — raw-SQL feed / published-view path.
    #
    # Feed Gen + raw-SQL Published Views call setup_registered_views with a
    # query_config that has files=[] (no structured FROM clause) because the
    # caller will run its OWN SQL against the views we just registered.  The
    # returned `sql` is only used for diagnostic logging — feed_engine ignores
    # it (it executes feed_config["raw_sql"] instead).
    #
    # Before this guard, _build_duckdb_from_clause would crash on
    # ``files[0]`` (IndexError) the moment a raw-SQL feed hit setup_registered_views,
    # because the structured-SQL path is unreachable without files.  The
    # IndexError bubbled up, feed_engine swapped to a plain DuckDB connection
    # (which has no views registered) and the user saw a misleading
    # "Catalog Error: table fact_table does not exist" downstream.
    #
    # Symptom in user logs: "REG-VIEW 'fact_table_ext' failed (list index
    # out of range)" → fallback → CatalogException on fact_table.
    if not query_config.files:
        # Raw-SQL caller will substitute its own SQL.  joins-only without
        # files is structurally invalid (joins.left_file must match files[0]);
        # treat it the same — return empty sql and let the caller execute its
        # own raw SQL against the views we just registered.
        sql = ""
        from_clause = ""
        logger.info(
            "setup_registered_views: raw-SQL path (no structured files/joins) — "
            "skipping build_query_sql; %d view(s) registered: %s",
            len(_registered_ok), sorted(_registered_ok),
        )
    else:
        from_clause = engine._build_duckdb_from_clause(query_config)
        sql = engine.build_query_sql(query_config, from_clause)
        sql = rewrite_registered_refs(sql, registered_tables)
        logger.info("Registered table SQL:\n%s", sql)

    _all_primary_empty = _all_primary_empty and not _any_primary_registered_with_data
    if _all_primary_empty:
        logger.warning("All primary tables pruned to 0 files — queries will return empty results")

    # ── Remote-I/O concurrency for THIS query's files (2026-10-06) ────
    # The views are built, so the file list is known.  Decided by the one
    # function every in-process view road shares; BEFORE the count(*) pass
    # below, which opens every file's footer too.  Measured on AWS: the
    # cross-source S3 side read a 672-file island two files at a time for
    # 20 minutes.  A SQLCollector is skipped (the child decides); a pooled
    # connection is put back to its CPU value on release.
    try:
        from core.s3_http_transport import apply_remote_io_for_views
        apply_remote_io_for_views(con, view_names=_registered_ok,
                                  label="setup_registered_views")
    except Exception as _rio_exc:                     # noqa: BLE001
        logger.debug("setup_registered_views: remote I/O concurrency "
                     "skipped (fail-open): %s", _rio_exc)

    # ── Collect total_possible_rows per table via count(*) ────────────
    # DuckDB optimises count(*) on parquet to a metadata-only scan (O(1) per file).
    # Silently skip for SQLCollector path or any errors — this is best-effort metadata.
    for _fs_tname, _fs_stat in _file_stats.items():
        try:
            _fs_esc = _fs_tname.replace('"', '""')
            _fs_result = con.execute(f'SELECT count(*) FROM "{_fs_esc}"')
            _fs_stat["total_possible_rows"] = _fs_result.fetchone()[0]
        except Exception:
            pass  # SQLCollector or empty view — skip gracefully

    # ── Phase 107-B: post-execution full-scan detection (log only, non-fatal) ──
    try:
        from core.query_guardrails import check_post_exec_file_stats
        check_post_exec_file_stats(
            file_stats=_file_stats,
            connection_id=connection_id,
            source="setup_registered_views",
        )
    except Exception as e:
        logger.warning("Post-execution guardrail check failed: %s", e)

    # BF-474 — surface registration failures on the engine attr so
    # feed_engine can check them without changing the (4 or 5)-tuple
    # contract relied on by every other caller (BQB, CQB, PV, etc.).
    # The set of failed table NAMES intersected with _primary_tables
    # tells the caller "these tables you needed couldn't be read"
    # vs "these tables had 0 matching files".  The two cases must
    # NOT be conflated.
    try:
        engine._setup_registration_failures = dict(_registration_failures)
        # 2026-08-20 — publish the QUERY SCOPE alongside the failures.
        #
        # A consumer that wants to fail on a registration failure has to know
        # whether the failed table was one this query actually needed.
        # ``registered_tables`` can legitimately carry tables the query never
        # references, and failing on those would break working feeds; failing
        # on NONE of them loses data silently.  Only this function knows which
        # tables were in scope, so it says so rather than making every caller
        # guess.  Empty set == scope unknown ⇒ the caller must treat ANY
        # failure as in scope (fail closed).
        engine._setup_query_table_scope = {
            str(t).lower() for t in (_all_query_tables or set()) if t}
    except Exception:
        pass

    # 2026-09-26 -- a table the query READS that failed to register is
    # UNKNOWN, not empty.  Before this, the zero-file shortcut below read
    # the missing view as "all primary tables pruned to 0 files", wrote an
    # empty parquet and the execution COMPLETED with 0 rows: an expired or
    # wrong S3 credential looked like "no matching data".  Only a KNOWN
    # scope raises here -- with no scope (raw SQL) a failure on a table the
    # SQL may never touch is the caller's call (the feed engine fails
    # closed on it itself, via the same predicate).
    _known_scope = {str(t).lower() for t in (_all_query_tables or set()) if t}
    if _known_scope and _registration_failures:
        _hit = {k: v for k, v in registration_failures_in_scope(
                    _registration_failures, _known_scope).items()
                if k not in _registered_ok}
        if _hit:
            _names = sorted(_hit)
            _first = _hit[_names[0]]
            _msg = (
                f"cannot read {len(_hit)} table(s) this query needs: {_names} "
                f"on connection {connection_id} -- "
                f"{_first.get('error_type', '?')}: "
                f"{str(_first.get('error_message', ''))[:700]}.  Refusing to "
                f"serve an empty result as success; check the connection's "
                f"S3 credentials, endpoint and permissions.")
            logger.error("setup_registered_views: %s", _msg)
            if own_con:
                try:
                    con.close()
                except Exception as _rf_close_exc:
                    logger.debug("registration-failure close: %s", _rf_close_exc)
            raise ViewRegistrationFailed(_msg)

    # ── Phase 150.B (2026-06-04) — BSOD guard for the feed/batch path ──
    # Same rationale as the register_s3_views chokepoint below.  The
    # dispatcher already runs admission for queries that fan out via
    # multi-worker; this catches the single-worker fallback and the
    # batch/feed-gen direct calls that bypass the dispatcher entirely.
    try:
        from core.resource_admission import check_mmap_admission_or_raise
        _total_post_prune = sum(
            int((v or {}).get("after_pruning") or 0)
            for v in (_file_stats or {}).values()
        )
        if _total_post_prune > 0:
            check_mmap_admission_or_raise(
                file_count=_total_post_prune,
                n_workers=1,
                caller="setup_registered_views",
            )
    except RuntimeError:
        raise
    except Exception as _adm_exc:
        logger.debug("Phase 150.B admission check skipped: %s", _adm_exc)

    # Smart brain co-access learning (2026-06-23): emit the per-query
    # table set so the learner can update the (a, b) frequency map.
    # ≥2 tables = a real co-access signal; <2 = single-table query
    # (no pair to learn).  Non-blocking; failures are silent.
    if len(_co_access_query_tables) >= 2:
        try:
            from core.iceberg_co_access import (
                record_query_tables_from_buckets_and_prefixes,
            )
            record_query_tables_from_buckets_and_prefixes(_co_access_query_tables)
        except Exception as _co_exc:
            logger.debug("Co-access learning emit skipped: %s", _co_exc)

    # 2026-06-23 deep-dive: same double-signing guard as register_s3_views,
    # for the batch path used by feed_engine + dataflow sql_query_stage.
    # When ``con`` is a SQLCollector (subprocess path), the helper short-
    # circuits and returns False -- no-op, no harm.
    # When ``con`` is a real DuckDB connection (sql_query_stage), the
    # helper scans the views, and if any embed presigned URLs, RESETs
    # s3_endpoint + credentials + DROPs S3 SECRETs before the user SQL
    # runs against the views.  Single chokepoint guarantees that no
    # future setup_registered_views caller can accidentally reintroduce
    # the bug by handing it a credentialed connection.
    #
    # Crash-safety: wrapped so feed_engine and dataflow callers receive
    # the full return tuple even if the suspend helper misbehaves.
    try:
        _suspend_signing_if_views_contain_presigned_urls(
            con, registered_tables)
    except Exception as _suspend_exc:
        logger.warning(
            "setup_registered_views: suspend-signing helper raised "
            "unexpectedly (%s) -- continuing.  PRESIGNED_URLS_IN_SQL "
            "guard is forfeited for this query but the query path is "
            "otherwise unaffected.",
            _suspend_exc,
        )

    return con, sql, _auto_partition_applied, _all_primary_empty, _file_stats


# ═══════════════════════════════════════════════════════════════════════════
# execute_registered_table_query
# ═══════════════════════════════════════════════════════════════════════════

def execute_registered_table_query(
    engine,
    query_config,
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    connection_id: int = None,
    progress_fn=None,
    force_fresh_iceberg: bool = False,
    db_manager=None,                                 # BF-368
    execution_id: Optional[str] = None,              # 2026-09-26: the pruning record's key
):
    """Execute a query against registered S3 tables, streaming results as Arrow tables."""
    import pyarrow as _pa

    con, sql, auto_part, all_empty, file_stats = setup_registered_views(
        engine, query_config, conn_config, registered_tables, bucket,
        connection_id, progress_fn, force_fresh_iceberg=force_fresh_iceberg,
        db_manager=db_manager, execution_id=execution_id)

    if auto_part:
        query_config._auto_partition = auto_part
    if file_stats:
        query_config._file_stats = file_stats

    if all_empty:
        logger.info("All primary tables empty — returning 0 rows without executing query")
        con.close()
        return

    try:
        if progress_fn:
            progress_fn({"status": "processing", "log": "Executing SQL query on S3 data..."})

        _t0 = _time.monotonic()
        result = con.execute(sql)
        reader = result.to_arrow_reader(batch_size=engine.chunk_size)
        total = 0
        for batch in reader:
            if len(batch) == 0:
                continue
            total += len(batch)
            elapsed = _time.monotonic() - _t0
            if progress_fn:
                progress_fn({"status": "processing",
                             "log": f"Streaming: {total:,} rows [{elapsed:.1f}s]"})
            yield _pa.Table.from_batches([batch])

        elapsed = _time.monotonic() - _t0
        if progress_fn:
            progress_fn({"status": "processing",
                         "log": f"Query returned {total:,} rows [{elapsed:.1f}s]"})
    finally:
        con.close()


# ═══════════════════════════════════════════════════════════════════════════
# execute_registered_table_copy_to
# ═══════════════════════════════════════════════════════════════════════════

def execute_registered_table_copy_to(
    engine,
    query_config,
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    output_path: str,
    connection_id: int = None,
    progress_fn=None,
    cancel_event=None,
    force_fresh_iceberg: bool = False,
    db_manager=None,                                 # BF-368
    execution_id: Optional[str] = None,              # progressive delivery key
    row_bound: Optional[int] = None,                 # 2026-09-15: declared page bound
):
    """Execute registered table query using DuckDB COPY TO (fast path).

    Runs DuckDB in a **subprocess** for crash isolation — a C-level crash
    (access violation / segfault) in DuckDB only kills the child process,
    not the main backend.
    """
    import pyarrow.parquet as _pq

    # Phase 1: Resolve files + build SQL (no DuckDB, safe)
    collector = SQLCollector()
    # 2026-09-26 -- pass the execution id on.  It was received here (for
    # progressive delivery) and dropped at this call, so the Iceberg reader,
    # running on a worker thread with no execution ContextVar, recorded NO
    # query_pruning_history row for any report / query-builder run -- the
    # bloom owner's only input stayed empty ("no_input") however many
    # filtered queries ran.  Found on the Docker rig.
    _, sql, auto_part, all_empty, file_stats = setup_registered_views(
        engine, query_config, conn_config, registered_tables, bucket,
        connection_id, progress_fn, con=collector,
        force_fresh_iceberg=force_fresh_iceberg,
        db_manager=db_manager, execution_id=execution_id)

    # Zero-file guard: all primary tables pruned to 0 files — write empty parquet directly
    if all_empty:
        logger.warning("All primary tables pruned to 0 files — writing empty parquet directly (skipping subprocess)")
        import pyarrow as _pa
        empty_table = _pa.table({"_empty": _pa.array([], type=_pa.int32())})
        _pq.write_table(empty_table, output_path, compression="ZSTD")
        if progress_fn:
            progress_fn({"status": "processing", "log": "All tables pruned to 0 files — empty result"})
        return {
            "total_rows": 0,
            "file_size_bytes": os.path.getsize(output_path),
            "status": "completed",
            "chunks_processed": 0,
            "all_primary_empty": True,
            "file_stats": file_stats or None,
        }

    # Build KV metadata clause for auto_partition
    kv_meta = {}
    if auto_part:
        kv_meta["auto_partition"] = json.dumps(auto_part)
    kv_clause = ""
    if kv_meta:
        kv_pairs = ", ".join(f"'{k}': '{v}'" for k, v in kv_meta.items())
        kv_clause = f", KV_METADATA {{{kv_pairs}}}"

    setup_sql_str = ";\n".join(collector.statements)
    logger.info("COPY TO setup SQL (%d statements):\n%s", len(collector.statements), setup_sql_str[:2000])
    logger.info("COPY TO inner SQL:\n%s", sql)

    # Two-phase execution: preview + full download
    result = s3_full_copy(
        inner_sql=sql,
        output_path=output_path,
        row_bound=row_bound,
        # 2026-10-06 -- ``sql`` is build_query_sql's output (a structured
        # config), so its trailing LIMIT is the query builder's generated
        # cap: stripped by the owner's decision, its OFFSET kept.
        generated_sql=True,
        conn_config=conn_config,
        registered_tables=registered_tables,
        bucket=bucket,
        setup_sql=setup_sql_str,
        connection_id=connection_id,
        progress_fn=progress_fn,
        timeout=600,
        kv_clause=kv_clause,
        # Progressive COPY delivery (2026-08-03): without the execution_id
        # plan_copy_rewrite hard-refuses (it keys the segment spool on
        # `<execution_id>__segments`), so the registered-table grid path —
        # the operator's 17M-row case — never streamed early pages even
        # with the flag ON.  Fail-open: None keeps today's canonical COPY.
        execution_id=execution_id,
        # 2026-08-03 (defect fix) — cancel_event was accepted by THIS
        # function's signature but silently dropped here, so Cancel could
        # never kill the DuckDB subprocess on the structured COPY path
        # (same missing-argument shape as the execution_id gap above).
        # s3_full_copy forwards it to run_duckdb_copy_to, whose poll loop
        # SIGTERM/SIGKILLs the child process group when the event is set.
        cancel_event=cancel_event,
    )

    total_rows = result["total_rows"]
    file_size = result["file_size_bytes"]

    # Write auto_partition to Parquet KV metadata
    if auto_part and os.path.exists(output_path):
        try:
            meta = _pq.read_metadata(output_path)
            if not meta.metadata or b"auto_partition" not in (meta.metadata or {}):
                tbl = _pq.read_table(output_path)
                existing = tbl.schema.metadata or {}
                existing[b"auto_partition"] = json.dumps(auto_part).encode()
                tbl = tbl.replace_schema_metadata(existing)
                # BF-274: re-write through the micro-partition writer so row
                # groups stay finely tuned even after metadata embedding.
                from core.parquet_write_opts import write_table as _pw_write
                _pw_write(tbl, output_path, compression="ZSTD")
                total_rows = len(tbl)
                file_size = os.path.getsize(output_path)
        except Exception as _meta_exc:
            logger.warning("Could not embed auto_partition metadata: %s", _meta_exc, exc_info=True)

    if progress_fn:
        progress_fn({"status": "processing",
                     "log": f"COPY TO complete: {total_rows:,} rows, "
                            f"{file_size / 1024 / 1024:.1f} MB"})
    return {
        "total_rows": total_rows,
        "file_size_bytes": file_size,
        "status": "completed",
        "chunks_processed": 1,
        "file_stats": file_stats or None,
    }


# ═══════════════════════════════════════════════════════════════════════════
# s3_full_copy
# ═══════════════════════════════════════════════════════════════════════════

# Fixed key for the DuckDB engine circuit breaker — fallback when no
# connection_id is available (e.g. very early failures).  When connection_id
# IS known we key by it so a credential blip on connection A doesn't open
# the breaker for unrelated connection B.
# Layout below avoids collision with:
#   - SQL connector IDs (positive integers)
#   - S3 connection CB keys  (-(conn_id + 100_000), max ~-101_000 for realistic IDs)
_DUCKDB_ENGINE_CB_ID = -999_999
_DUCKDB_ENGINE_CB_NAME = "duckdb_engine"


def _duckdb_engine_cb_key(connection_id) -> tuple:
    """BF-281: return a per-connection circuit-breaker (id, name) pair.

    A single global ``duckdb_engine`` breaker means one connection's
    transient failure (e.g. ExpiredToken on STS) opens the breaker for
    52s and halts ALL DuckDB engine traffic, including unrelated
    connections.  Keying by connection_id isolates the fault.

    Falls back to the global key when ``connection_id`` is None
    (preserves existing behaviour for callers that haven't been
    threaded with conn_id yet).

    Returns ``(cb_id, cb_name)``:
      - cb_id: ``-(conn_id + 200_000)`` for connections (won't collide
        with the S3 connection CB at ``-(conn_id + 100_000)``).
      - cb_name: e.g. ``"duckdb_engine:conn=42"`` so logs show which
        connection's CB tripped.
    """
    try:
        cid = int(connection_id) if connection_id is not None else None
    except (TypeError, ValueError):
        cid = None
    if cid is None:
        return (_DUCKDB_ENGINE_CB_ID, _DUCKDB_ENGINE_CB_NAME)
    return (-(cid + 200_000), f"{_DUCKDB_ENGINE_CB_NAME}:conn={cid}")


def s3_full_copy(
    inner_sql: str,
    output_path: str,
    conn_config: dict,
    registered_tables: list,
    bucket: str,
    setup_sql: str = "",
    connection_id=None,
    progress_fn=None,
    timeout: int = 600,
    kv_clause: str = "",
    execution_id: Optional[str] = None,
    cancel_event=None,
    row_bound: Optional[int] = None,
    generated_sql: bool = False,
) -> dict:
    """COPY the result of ``inner_sql`` from S3 into ``output_path``.

    ``generated_sql`` (2026-10-06) — DECLARES where the statement came from,
    because that decides what its trailing LIMIT means:

    * ``False`` (the default) — a statement a person or a saved query WROTE
      (the raw-SQL road).  It is copied EXACTLY as written: its ORDER BY,
      LIMIT, OFFSET and FETCH are its answer.  This function used to strip
      the trailing LIMIT of every statement ("so the cache always contains
      the complete result set"), so ``... order by amt desc limit 3 offset
      150000`` over a 201,600-row island returned all 201,600 rows (found
      live on AWS, 2026-10-06) -- while the same statement on the query
      builder's in-process road returned three.
    * ``True`` — SQL the PRODUCT generated from a structured query config
      (``build_query_sql`` / ``get_duckdb_sql``).  The compiler's trailing
      row cap is removed (the owner's decision of 2026-09-26: "Query Builder
      limit: show all rows"); its OFFSET is kept.  See
      ``core.statement_bounds``.

    ``row_bound`` (2026-09-15) — a bound the CALLER declared (a published-view
    page scan): it WRAPS the statement (``core.statement_bounds.
    bound_statement``), so the statement's own window is applied first.  It
    is a declaration, never a default: with ``None`` nothing is added.  The
    bound travels with the SQL text, so a SQL-keyed cache downstream cannot
    confuse a bounded copy with the whole.

    Wraps run_duckdb_copy_to() with:
    - DuckDB engine circuit breaker (trips after N crashes, not SQL errors)
    - 1-retry for transient engine crashes (not timeouts, not bad SQL)
    """
    import time as _time
    from core.duckdb_subprocess import (
        run_duckdb_copy_to, DuckDBEngineError, DuckDBQueryError,
    )
    from core.circuit_breaker import (
        check_circuit, record_success, record_failure, CircuitOpenError,
    )
    from core.config import duckdb_cfg as _dc

    from core.statement_bounds import (
        bound_statement as _bound_statement,
        statement_body as _statement_body,
        strip_generated_limit as _strip_generated_limit,
    )
    full_sql = (_strip_generated_limit(inner_sql) if generated_sql
                else _statement_body(inner_sql))
    full_sql = _bound_statement(full_sql, row_bound)
    safe_out = output_path.replace("\\", "/").replace("'", "''")

    if progress_fn:
        progress_fn({"status": "processing", "log": "Processing query from S3…"})

    copy_sql = (
        f"COPY ({full_sql}) TO '{safe_out}' "
        f"(FORMAT PARQUET, COMPRESSION ZSTD{kv_clause})"
    )

    # Brain trace: record which S3 setup strategy the subprocess will
    # follow before we spawn it.  Both processes derive the plan from
    # the same (conn_config, setup_sql, copy_sql) so the trace here is
    # what the subprocess will see -- valuable for post-mortem when a
    # smart-VPC fast-path query fails with HTTP 0.
    #
    # 2026-06-24 -- ALSO log to the standard logger so the plan kind
    # appears in pod stderr WITHOUT being subject to the subprocess
    # stderr 2000-byte tail truncation.  Operators need to see the
    # planner's decision in EVERY query, not just when brain_trace is
    # surfaced via execution metadata.
    try:
        from core.duckdb_s3_plan import plan_s3_setup as _plan_s3_setup
        from core.brain_trace import trace as _bt_plan
        _plan_pre = _plan_s3_setup(conn_config, setup_sql, copy_sql)
        logger.info(
            "[s3_full_copy] S3 setup plan: kind=%s "
            "(load_httpfs=%s, set_endpoint_and_credentials=%s, "
            "apply_ssl_bundle=%s, "
            "predownload_presigned_to_local=%s, "
            "allow_boto3_predownload_fallback=%s) -- %s",
            _plan_pre.kind,
            _plan_pre.load_httpfs,
            _plan_pre.set_endpoint_and_credentials,
            _plan_pre.apply_ssl_bundle,
            _plan_pre.predownload_presigned_to_local,
            _plan_pre.allow_boto3_predownload_fallback,
            _plan_pre.reason,
        )
        _bt_plan(
            "s3_setup_plan", _plan_pre.kind,
            load_httpfs=_plan_pre.load_httpfs,
            set_endpoint_and_credentials=(
                _plan_pre.set_endpoint_and_credentials),
            apply_ssl_bundle=_plan_pre.apply_ssl_bundle,
            predownload_presigned_to_local=(
                _plan_pre.predownload_presigned_to_local),
            allow_boto3_predownload_fallback=(
                _plan_pre.allow_boto3_predownload_fallback),
            reason=_plan_pre.reason,
        )
    except Exception as _bt_exc:
        # Trace is diagnostic-only; never block a query because the
        # brain couldn't record its own plan.
        logger.debug("s3_setup_plan brain trace skipped: %s", _bt_exc)

    def _run_once():
        return run_duckdb_copy_to(
            conn_config=conn_config,
            registered_tables=registered_tables,
            bucket=bucket,
            setup_sql=setup_sql,
            copy_sql=copy_sql,
            output_path=output_path,
            connection_id=connection_id,
            timeout=timeout,
            execution_id=execution_id,
            cancel_event=cancel_event,
        )

    # ── DuckDB engine circuit breaker ──────────────────────────────────────
    # BF-281: per-connection key so a credential blip on conn A doesn't
    # open the breaker for unrelated conn B.
    _cb_id, _cb_name = _duckdb_engine_cb_key(connection_id)
    if _dc.circuit_breaker_enabled:
        try:
            check_circuit(_cb_id, _cb_name)
        except CircuitOpenError as _coe:
            logger.warning(
                "[duckdb_cb] %s circuit OPEN — fast-failing query "
                "(retry_after=%.0fs)", _cb_name, _coe.retry_after
            )
            raise

    # ── Execute with retry on engine crash + a dedicated SEGFAULT mitigation ─
    # A DuckDB SIGSEGV reading a schema-evolved table is almost always
    # ``union_by_name=true`` reconciling CROSS-SCHEMA TYPE CONFLICTS (a
    # DuckDB 1.5.3 crash).  That path became reachable once partition pruning
    # shrank the file set below the union_by_name auto-enable threshold
    # (s3.union_by_name_max_files, default 200) — a full-table scan stayed
    # over the threshold so union_by_name was OFF and never crashed.  Retrying
    # the IDENTICAL config just re-crashes, so on a segfault we retry ONCE with
    # union_by_name stripped from the setup SQL (independent of the general
    # engine-retry config).  Worst case the retry hits a plain "column not
    # found" — a clean, actionable error instead of a hard crash.
    _cb_ok = _dc.circuit_breaker_enabled
    _max_attempts = 1 + (_dc.retry_max_attempts if _dc.retry_on_engine_error else 0)
    _last_exc: Exception = None
    _segfault_union_retry_used = False
    _attempt = 0
    while True:
        try:
            result = _run_once()
            if _cb_ok:
                record_success(_cb_id)
            if _attempt > 0 or _segfault_union_retry_used:
                logger.info(
                    "[duckdb_cb] %s retry succeeded on attempt %d",
                    _cb_name, _attempt + 1,
                )
            break  # success
        except DuckDBEngineError as exc:
            if isinstance(exc, DuckDBQueryError):
                # 2026-09-26 -- the REQUEST failed (an HTTP 403 from the
                # host it was pointed at, a binder error, a missing key);
                # the engine is fine.  The breaker learns nothing from it
                # and a retry cannot change the answer.  Before this, three
                # such failures opened the connection's breaker for every
                # other user -- measured live on 2026-09-25 (F2).
                raise
            _last_exc = exc
            # 2026-10-06 -- only a TRANSPORT failure teaches the connection's
            # breaker anything (core.duckdb_subprocess.engine_failure_is_
            # transport).  An OutOfMemory on AWS was retried, recorded twice,
            # and paused the S3 connection for every other query.
            if _cb_ok:
                from core.duckdb_subprocess import engine_failure_is_transport
                if engine_failure_is_transport(exc):
                    record_failure(_cb_id, str(exc)[:300], _cb_name)
                else:
                    logger.info(
                        "[duckdb_cb] %s: engine failure is not a transport "
                        "failure -- the breaker is not charged (%s)",
                        _cb_name, str(exc)[:160])
            _is_segfault = ("-11" in str(exc)) or ("SIGSEGV" in str(exc).upper())
            # One-shot union_by_name segfault mitigation — does NOT consume a
            # general retry attempt.
            if (_is_segfault and not _segfault_union_retry_used
                    and "union_by_name=true" in (setup_sql or "")):
                _segfault_union_retry_used = True
                setup_sql = setup_sql.replace(
                    "union_by_name=true", "union_by_name=false")
                logger.warning(
                    "[duckdb_cb] DuckDB SEGFAULT reading a schema-evolved table "
                    "— retrying with union_by_name DISABLED (cross-schema "
                    "type-conflict segfault mitigation; the correctness path "
                    "union_by_name=true crashes DuckDB 1.5.3 here).")
                continue
            _attempt += 1
            if _attempt < _max_attempts:
                _delay = _dc.retry_delay_seconds
                logger.warning(
                    "[duckdb_cb] DuckDB engine crash on attempt %d/%d — retrying in %.1fs: %s",
                    _attempt, _max_attempts, _delay, str(exc)[:200],
                )
                _time.sleep(_delay)
                continue
            logger.error(
                "[duckdb_cb] DuckDB engine failed all attempt(s) — giving up: %s",
                str(exc)[:300],
            )
            raise
        except Exception:
            # Non-engine errors (bad SQL, timeouts, S3 auth) — do not trip DuckDB
            # CB, do not retry, just propagate immediately.
            raise
    else:
        # All attempts exhausted
        raise _last_exc  # type: ignore[misc]

    total_rows = result["total_rows"]
    file_size = result["file_size_bytes"]
    if progress_fn:
        progress_fn({"status": "processing",
                     "log": f"Processing complete: {total_rows:,} rows, "
                            f"{file_size / 1024 / 1024:.1f} MB"})
    return {"total_rows": total_rows, "file_size_bytes": file_size,
            "status": "completed", "chunks_processed": 1}


# ═══════════════════════════════════════════════════════════════════════════
# join_inflight_query
# ═══════════════════════════════════════════════════════════════════════════

async def join_inflight_query(shadow_id: str, cache_key: str,
                              event: "asyncio.Event", primary_id: str) -> None:
    """Wait for a primary execution to finish then serve its result to a shadow execution."""
    _shadow_rec = _db_manager.get_execution(shadow_id) or {}
    _shadow_user = _shadow_rec.get("executed_by", "")
    try:
        await asyncio.wait_for(event.wait(), timeout=660)
    except asyncio.TimeoutError:
        logger.warning("[dedup] Shadow %s timed out waiting for primary %s", shadow_id[:8], primary_id[:8])
        _db_manager.update_execution(shadow_id, status="failed",
                                     error_message="Timed out waiting for shared execution")
        await _ws_manager.broadcast_to_user(_shadow_user, {
            "type": "execution_failed", "execution_id": shadow_id,
            "error": "Timed out waiting for shared execution",
            "username": _shadow_user,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        return

    # Primary finished — check if its output file exists
    output_file = _paths.downloads_dir / f"{primary_id}.parquet"
    if output_file.exists():
        try:
            file_size = output_file.stat().st_size
        except FileNotFoundError:
            file_size = 0
            output_file = None

    if output_file and output_file.exists():
        file_id = str(uuid.uuid4())
        _primary_rec = _db_manager.get_execution(primary_id) or {}
        _db_manager.update_execution(shadow_id, status="completed",
                                     output_file=str(output_file),
                                     total_rows=_primary_rec.get("total_rows", 0),
                                     file_size_bytes=file_size)
        _db_manager.create_download_file(
            file_id=file_id, execution_id=shadow_id,
            filename=f"result_{shadow_id}.parquet",
            file_path=str(output_file),
            file_size_bytes=file_size,
            expires_at=_download_expires_at(),
        )
        await _ws_manager.broadcast_to_user(_shadow_user, {
            "type": "execution_completed",
            "execution_id": shadow_id,
            "file_id": file_id,
            "shared_from": primary_id,
            "username": _shadow_user,
            "stats": {
                "total_rows": _primary_rec.get("total_rows", 0),
                "total_columns": _primary_rec.get("total_columns"),
                "duration_seconds": _primary_rec.get("duration_seconds"),
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        logger.info("[dedup] Shadow %s completed via primary %s (shared file)", shadow_id[:8], primary_id[:8])
    else:
        _db_manager.update_execution(shadow_id, status="failed",
                                     error_message=f"Shared execution {primary_id[:8]} failed")
        await _ws_manager.broadcast_to_user(_shadow_user, {
            "type": "execution_failed", "execution_id": shadow_id,
            "error": "Shared execution failed — please retry",
            "username": _shadow_user,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        logger.warning("[dedup] Shadow %s failed because primary %s failed", shadow_id[:8], primary_id[:8])


# ═══════════════════════════════════════════════════════════════════════════
# run_base_data_local_query
# ═══════════════════════════════════════════════════════════════════════════

def run_base_data_local_query(
    base_parquet: Path, query_config: dict, output_path: Path,
) -> Optional[dict]:
    """Run a presentation-only SQL against an already-downloaded local parquet.

    The base_parquet contains rows matching the original FROM/WHERE/JOIN from
    a previous S3 download.  We only need SELECT / aggregation / GROUP BY /
    ORDER BY / LIMIT on top — no network round-trip.

    Returns {"total_rows": int, "file_size_bytes": int} on success, None on
    failure (e.g. missing columns in the cached file).
    """
    try:
        import duckdb as _ddb
    except ImportError:
        return None
    con = None
    try:
        con = _ddb.connect(database=":memory:")
        pq_path = str(base_parquet).replace("\\", "/")

        # ── Build presentation SQL ────────────────────────────────────
        _q = lambda c: '"' + str(c).replace('"', '""') + '"' if c != "*" else c
        select_parts: list[str] = []
        group_cols: list[str] = []

        aggs = query_config.get("aggregations") or []
        columns = query_config.get("columns") or []
        group_by = query_config.get("group_by") or []
        order_by = query_config.get("order_by") or []
        limit = query_config.get("limit")
        offset = query_config.get("offset", 0)
        distinct = query_config.get("distinct", False)
        computed = query_config.get("computed_columns") or []
        case_exprs = query_config.get("case_expressions") or []
        window_fns = query_config.get("window_functions") or []
        col_aliases = query_config.get("column_aliases") or {}

        if aggs:
            for col in group_by:
                group_cols.append(_q(col))
                select_parts.append(_q(col))
            for agg in aggs:
                fn = agg["function"].upper()
                acol = _q(agg["column"])
                alias = agg.get("alias", f"{fn}_{agg['column']}")
                select_parts.append(f'{fn}({acol}) AS "{alias}"')
        elif columns:
            for col in columns:
                alias = col_aliases.get(col)
                if alias:
                    select_parts.append(f'{_q(col)} AS "{alias}"')
                else:
                    select_parts.append(_q(col))
        else:
            select_parts.append("*")

        for cc in computed:
            expr = cc.get("expression", "")
            alias = cc.get("alias", "computed")
            _expr_upper = expr.upper().replace(" ", "")
            _blocked = ("DROP", "TRUNCATE", "ALTER", "DELETE", "INSERT",
                        "UPDATE", "CREATE", "COPY", "ATTACH", "DETACH",
                        "EXECUTE", "CALL", "PRAGMA", "EXPORT", "IMPORT",
                        "LOAD", "INSTALL")
            _safe = True
            for _bk in _blocked:
                if _bk in _expr_upper:
                    logger.warning("Blocked dangerous computed expression: %s", expr[:100])
                    _safe = False
                    break
            if _safe and expr.strip():
                select_parts.append(f'({expr}) AS {_q(alias)}')

        for ce in case_exprs:
            alias = ce.get("alias", "case_result")
            whens = ce.get("when_clauses") or []
            parts = ["CASE"]
            for w in whens:
                parts.append(f"WHEN {w.get('condition','')} THEN {w.get('result','NULL')}")
            else_val = ce.get("else_result")
            if else_val is not None:
                parts.append(f"ELSE {else_val}")
            parts.append("END")
            select_parts.append(f'{" ".join(parts)} AS "{alias}"')

        for wf in window_fns:
            fn = wf.get("function", "ROW_NUMBER")
            wcol = wf.get("column", "")
            partition = wf.get("partition_by") or []
            worder = wf.get("order_by") or []
            alias = wf.get("alias", f"win_{fn}")
            fn_arg = f"({_q(wcol)})" if wcol else "()"
            over_parts = []
            if partition:
                over_parts.append("PARTITION BY " + ", ".join(_q(c) for c in partition))
            if worder:
                over_parts.append("ORDER BY " + ", ".join(
                    f'{_q(o["column"])} {o.get("direction","ASC").upper()}'
                    if isinstance(o, dict) else _q(o)
                    for o in worder
                ))
            select_parts.append(f'{fn}{fn_arg} OVER ({" ".join(over_parts)}) AS "{alias}"')

        distinct_kw = "DISTINCT " if distinct else ""
        sql = f"SELECT {distinct_kw}{', '.join(select_parts)}\nFROM read_parquet('{pq_path}')"

        if group_cols:
            sql += f"\nGROUP BY {', '.join(group_cols)}"

        # HAVING — sanitize operator and quote column
        _HAVING_OPS = {">", "<", ">=", "<=", "=", "!=", "<>"}
        having = query_config.get("having") or []
        if having:
            hparts = []
            for h in having:
                hcol = h.get("column", "")
                hop = h.get("operator", ">")
                hval = h.get("value", 0)
                if hop not in _HAVING_OPS:
                    hop = ">"
                try:
                    hval = float(hval)
                except (TypeError, ValueError):
                    hval = 0
                hparts.append(f"{_q(hcol)} {hop} {hval}")
            sql += f"\nHAVING {' AND '.join(hparts)}"

        if order_by:
            oparts = []
            for o in order_by:
                ocol = o["column"] if isinstance(o, dict) else o
                odir = o.get("direction", "ASC").upper() if isinstance(o, dict) else "ASC"
                oparts.append(f'{_q(ocol)} {odir}')
            sql += f"\nORDER BY {', '.join(oparts)}"

        if limit:
            sql += f"\nLIMIT {limit}"
            if offset:
                sql += f" OFFSET {offset}"

        # ── Execute and write result ─────────────────────────────────
        out_str = str(output_path).replace("\\", "/")
        copy_sql = f"COPY ({sql}) TO '{out_str}' (FORMAT PARQUET, COMPRESSION ZSTD)"
        con.execute(copy_sql)

        if not output_path.exists():
            return None
        file_size = output_path.stat().st_size
        total_rows = con.execute(
            f"SELECT COUNT(*) FROM read_parquet('{out_str}')"
        ).fetchone()[0]

        logger.info("[base_data_reuse] Local query OK: %d rows, %.1f MB from %s",
                     total_rows, file_size / 1024 / 1024, base_parquet.name)
        return {"total_rows": total_rows, "file_size_bytes": file_size}
    except Exception as exc:
        logger.debug("[base_data_reuse] Local query failed (will fall through to S3): %s", exc)
        try:
            output_path.unlink(missing_ok=True)
        except OSError:
            pass
        return None
    finally:
        if con:
            try:
                con.close()
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════════════════════
# register_s3_views  (used by streaming endpoints + MV refresh)
# ═══════════════════════════════════════════════════════════════════════════

def register_s3_views(con, registered_tables, bucket, connection_id, cfg,
                      referenced_tables=None, partition_filters=None,
                      primary_tables=None, force_fresh_iceberg: bool = False,
                      raw_sql: str = None,
                      db_manager=None, reader_override: Optional[str] = None,
                      progress_fn=None,
                      or_groups=None,  # BF-568 — see setup_registered_views docstring
                      # JOIN-PRUNER (2026-06-01): optional list of duck-typed
                      # JoinConfig-shaped objects with left_file/right_file/
                      # left_on/right_on attributes.  When supplied, the
                      # streaming path (BQB) gets the same cross-table
                      # semi-join pruning the batch path (feed_engine) gets
                      # via setup_registered_views.  Callers can pass
                      # ``query_config.joins`` directly.  Default None ⇒
                      # behaviour unchanged.
                      joins=None,
                      # JOIN-PRUNER deep-audit round 6 — when caller is
                      # running raw SQL (not a structured query), suppress
                      # view-WHERE injection so the synth filter doesn't
                      # narrow standalone references to the same table
                      # (e.g. ``SELECT * FROM b`` in a UNION).  Manifest
                      # pruning still fires.  Default False = back-compat,
                      # structured-query behaviour.
                      raw_sql_present: bool = False):
    """Register S3 views in a DuckDB connection for registered tables.

    When `referenced_tables` is provided (set of table names), only those tables
    are registered — avoids scanning manifests for unreferenced Iceberg tables.
    Uses the L1/L2 Iceberg manifest cache to avoid redundant S3 reads.

    partition_filters: list of {col, op, val} dicts to prune hive-partitioned files.
    primary_tables: set of table names from the query's FROM clause — only these
                    tables get partition-pruned.  Joined dimension tables are
                    registered but NOT pruned (their partition columns may not
                    match the query's WHERE clause filters).

    Returns: (total_records, all_primary_empty, file_stats) tuple.
    total_records: record count from Iceberg manifests (0 if unavailable).
    all_primary_empty: True when every primary table was pruned to 0 files.
    file_stats: dict with per-table file counts {table: {total, after_pruning, format}}.
    """
    import time as _rv_t
    _esc = lambda v: v.replace("'", "''")
    _total_records = 0
    _primary_set = primary_tables or set()
    _all_primary_empty = bool(_primary_set)
    _any_primary_with_data = False
    _file_stats = {}  # {table_name: {"total": N, "after_pruning": N, "format": str}}
    # 2026-08-20 — per-table scan-set TRUNCATION records (listing cap), see
    # the twin declaration in setup_registered_views for rationale.
    _file_cap_by_table: dict = {}
    # BF-484 (2026-05-27) — track CREATE VIEW failures (auth/network) so the
    # caller can distinguish "0 files matched the filter" (legitimately empty)
    # from "CREATE VIEW failed and we lost data" (silent data loss).  Stamped
    # on the connection at end so execute_stream_api can surface an actionable
    # error instead of returning empty rows.  Mirrors BF-474 for the streaming
    # path (BF-474 only patched setup_registered_views, used by feed_engine).
    _registration_failures: dict = {}

    # ── JOIN-PRUNER (2026-06-01) — streaming-path parity ──────────────────
    # Mirrors the wiring in ``setup_registered_views``: plan probes,
    # reorder anchors before targets, surface bounds via ``join_key_columns``
    # on the iceberg read, inject synthesised BETWEEN filters into target
    # tables' filter lists.  No-op when ``joins`` not supplied or when
    # JoinPruner is disabled / has no probes.
    _join_probes_stream: list = []
    try:
        from core.join_pruner import JoinPruner as _JPStream
        from types import SimpleNamespace as _NS
        _jp_stream = _JPStream()
        if joins:
            _qc_shim = _NS(joins=joins, files=[])
            _join_probes_stream = _jp_stream.plan_probes(_qc_shim, partition_filters)
    except Exception as _jp_stream_exc:
        logger.debug("register_s3_views JoinPruner plan_probes failed (fail-open): %s",
                     _jp_stream_exc)
        _jp_stream = None
        _join_probes_stream = []
    _anchor_tables_lower_s: set = {p.anchor_table for p in _join_probes_stream}
    _target_tables_lower_s: set = {p.target_table for p in _join_probes_stream}
    _join_anchor_bounds_s: dict = {}
    _join_anchor_file_count_s: dict = {}
    _join_anchor_distinct_s: dict = {}
    _join_anchor_distinct_bloom_s: dict = {}   # COMPLETE set for bloom prune
    # Runtime dynamic filtering (2026-07-15, audit finding #6) — streaming
    # parity.  Same semantics as setup_registered_views.
    _join_anchor_scan_complete_s: dict = {}    # anchor_table_lower → bool
    _join_anchor_runtime_memo_s: dict = {}     # (anchor, col) → (vals, truncated) | _RUNTIME_DF_FAILED

    _ordered_registered_tables_s = list(registered_tables or [])
    if _anchor_tables_lower_s or _target_tables_lower_s:
        def _phase_s(_tb):
            _nm = (_tb.get("name") or "").lower()
            if _nm in _anchor_tables_lower_s:
                return 0
            if _nm in _target_tables_lower_s:
                return 2
            return 1
        _ordered_registered_tables_s.sort(key=_phase_s)

    # Runtime dynamic filtering: lower-cased name → original view name.
    _tbl_name_by_lower_s: dict = {
        (_tb.get("name") or "").lower(): _tb.get("name")
        for _tb in _ordered_registered_tables_s
    }

    _or_groups_caller_s = or_groups   # 2026-10-08: scoped per table below
    for tbl in _ordered_registered_tables_s:
        tname = tbl["name"]
        _tname_lower = tname.lower()
        if referenced_tables and _tname_lower not in {r.lower() for r in referenced_tables}:
            continue
        # JOIN-PRUNER: synthesise + inject before _compute_table_filters.
        # Considers both BETWEEN bounds AND IN-list distinct values.
        _join_synth_s: list = []
        _join_synth_objs_s: list = []
        if _jp_stream and _tname_lower in _target_tables_lower_s:
            for _probe in _join_probes_stream:
                if _probe.target_table != _tname_lower:
                    continue
                _ab = _join_anchor_bounds_s.get(_probe.anchor_table) or {}
                _ad = _join_anchor_distinct_s.get(_probe.anchor_table) or {}
                _afc = int(_join_anchor_file_count_s.get(_probe.anchor_table) or 0)
                _sf = None
                if _ab or _ad:
                    try:
                        _sf = _jp_stream.synthesize_filter(
                            _probe, _ab, _afc,
                            anchor_distinct_values=_ad or None,
                        )
                    except Exception as _jp_syn_s_exc:
                        logger.debug("register_s3_views JoinPruner synthesise failed (fail-open): %s",
                                     _jp_syn_s_exc)
                        _sf = None
                # ── RUNTIME DYNAMIC FILTER (2026-07-15) — streaming parity.
                # Complete-by-construction IN-list from the anchor's
                # already-registered view; pushes NOTHING unless the
                # completeness proof holds (see setup_registered_views).
                if _sf is None or _sf.op == "between":
                    _rt_sf_s = _maybe_runtime_dynamic_filter(
                        _jp_stream, con, _probe,
                        _tbl_name_by_lower_s.get(_probe.anchor_table)
                        or _probe.anchor_table,
                        _join_anchor_scan_complete_s.get(_probe.anchor_table),
                        _join_anchor_file_count_s.get(_probe.anchor_table),
                        _join_anchor_runtime_memo_s,
                    )
                    if _rt_sf_s is not None:
                        _sf = _rt_sf_s
                if _sf is not None:
                    _join_synth_s.append(_sf.as_filter_dict())
                    _join_synth_objs_s.append(_sf)
        # View WHERE clause for row-group pruning (streaming path).
        # Same safety gate as setup_registered_views: only inject when
        # caller signals structured-query mode (raw_sql_present=False).
        _join_view_where_s: str = ""
        if _join_synth_objs_s and not raw_sql_present:
            _frags_s = [s.to_sql_where_fragment() for s in _join_synth_objs_s]
            _frags_s = [f for f in _frags_s if f]
            if _frags_s:
                _join_view_where_s = " AND ".join(_frags_s)
        elif _join_synth_objs_s and raw_sql_present:
            logger.debug(
                "JoinPruner (stream): skipping view-WHERE injection for '%s' "
                "(raw_sql; manifest pruning still fires)", tname,
            )
        # Per-table filters: joined tables get pruned by their own qualified filters too.
        _tbl_filters = _compute_table_filters(
            partition_filters, tname,
            bool(primary_tables and _tname_lower in {p.lower() for p in primary_tables}),
            all_table_names=[t.get("name") for t in (registered_tables or [])
                             if isinstance(t, dict) and t.get("name")],
            raw_sql=raw_sql)
        if _join_synth_s:
            _tbl_filters = list(_tbl_filters or []) + _join_synth_s
            logger.info(
                "JoinPruner (stream): injected %d synthesised filter(s) on '%s'",
                len(_join_synth_s), tname,
            )
        or_groups = _compute_table_or_groups(
            _or_groups_caller_s, tname,
            bool(primary_tables and _tname_lower in {p.lower() for p in primary_tables}),
            all_table_names=[t.get("name") for t in (registered_tables or [])
                             if isinstance(t, dict) and t.get("name")],
            raw_sql=raw_sql)
        _apply_pruning = bool(_tbl_filters) or bool(or_groups)
        tname_esc = tname.replace('"', '""')
        fmt = tbl.get("format", "parquet")
        prefix = tbl["s3_prefix"].rstrip("/")
        _rv0 = _rv_t.monotonic()
        if fmt == "iceberg":
            try:
                # JOIN-PRUNER cache integration (deep-audit round 4) —
                # serve cached bounds when present, force fresh only when
                # cache lacks the bounds we need.
                _is_join_anchor_s = bool(_jp_stream) and _tname_lower in _anchor_tables_lower_s
                _join_key_cols_for_call_s = (
                    _jp_stream.anchor_join_columns(tname, _join_probes_stream)
                    if _is_join_anchor_s else []
                )
                # BF-181: Pass partition filters to cache key + get_iceberg_data_files()
                # for Avro manifest-level pruning (correct for Iceberg flat data layout).
                _ice_pf_stream = (_tbl_filters or None) if _apply_pruning else None
                from core.iceberg_versions import (
                    version_for as _ivf_s, l1_cache_snapshot_token as _il1_s)
                _run_ver_s = _ivf_s(tname, bucket, tbl.get("s3_prefix"))
                cache_key = _ice_cache_key(connection_id, tname, _ice_pf_stream,
                                           or_groups=or_groups,
                                           snapshot=_il1_s(_run_ver_s))
                # BF-505 — same snapshot-id verification as the
                # non-streaming variant.  Streaming path was hitting
                # the same stale-cache trap.
                _current_snap_for_cache_si = None
                if _run_ver_s is not None and not force_fresh_iceberg:
                    _current_snap_for_cache_si = _run_ver_s.snapshot_id
                elif not force_fresh_iceberg:
                    try:
                        from core.iceberg_reader import get_iceberg_snapshot_id_only as _gsi_si
                        _si_s3 = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                        _current_snap_for_cache_si = _gsi_si(_si_s3, bucket, tbl["s3_prefix"])
                    except Exception as _snap_probe_exc_si:
                        _current_snap_for_cache_si = None
                        logger.debug("snapshot probe raised for '%s': %s",
                                     tname, _snap_probe_exc_si)
                    if _current_snap_for_cache_si is None:
                        # 2026-08-20 DATA-LOSS FIX (disclosure) — streaming
                        # parity with setup_registered_views: a failed probe
                        # silently disabled the BF-505 freshness check and a
                        # stale cached file list was served with no trace.
                        # ice_cache_get now flags the serve.
                        logger.warning(
                            "[iceberg-cache] snapshot freshness probe FAILED "
                            "(or table has no current snapshot) for '%s' — a "
                            "cache hit will be served WITHOUT freshness "
                            "verification and flagged freshness_unverified",
                            tname)
                cached = None if force_fresh_iceberg else _ice_cache_get(
                    cache_key,
                    current_snapshot_id=str(_current_snap_for_cache_si or ""),
                )
                # Force fresh when anchor needs bounds not in cache.
                if cached and _is_join_anchor_s and _join_key_cols_for_call_s:
                    _cached_bounds_s = (cached.get("join_key_bounds") or {})
                    _missing_s = [c for c in _join_key_cols_for_call_s
                                  if c not in _cached_bounds_s]
                    if _missing_s:
                        cached = None
                # 2026-07-15 MoR correctness (streaming parity with
                # setup_registered_views): an entry that predates delete-file
                # caching (or was promoted from L2, which stores files-only)
                # has no delete-file info.  When iceberg_mor is enabled,
                # serving it would build a delete-BLIND view → silent
                # overcount on V2 tables.  Force a fresh resolve so deletes
                # apply; the fresh write re-populates L1 WITH the delete lists.
                if (cached is not None
                        and "pos_delete_files" not in cached
                        and "eq_delete_files" not in cached):
                    try:
                        from core.iceberg_mor import is_mor_enabled as _is_mor_on_s
                        if _is_mor_on_s():
                            logger.info(
                                "STREAM-DIAG: '%s' MoR enabled but cache entry "
                                "lacks delete-file info (L2/legacy) — forcing "
                                "fresh resolve so deletes apply", tname,
                            )
                            cached = None
                    except Exception:
                        pass
                # 2026-09-28 -- a cached EMPTY list serves only under its
                # PROVEN verdict (see iceberg_cache.ice_cache_set).
                if (cached and not cached.get("files")
                        and (cached.get("empty_island") or {}).get("proven") is not True):
                    logger.info(
                        "STREAM-DIAG: '%s' cached 0-file entry carries no proven "
                        "empty-island verdict -- forcing a fresh resolve", tname)
                    cached = None
                _les_counts = None
                if cached:
                    data_files = cached["files"]
                    _les_counts = cached.get("file_record_counts")  # 2026-10-07 limit early stop
                    _total_records += cached.get("record_count", 0)
                    # 2026-07-15 — restore delete files from the cache so the
                    # MoR chokepoint (_apply_mor_view) builds a delete-aware
                    # view on cache hits too.  Also resets _out_meta per table,
                    # so a cache-hit table can never consume a previous (miss)
                    # table's delete files.
                    _out_meta = {
                        "pos_delete_files": cached.get("pos_delete_files") or [],
                        "eq_delete_files": cached.get("eq_delete_files") or [],
                        # 2026-09-25 -- read-plan inputs (see batch path).
                        "iceberg_read_plan": cached.get("iceberg_read_plan"),
                        "empty_island": cached.get("empty_island"),
                    }
                    # 2026-10-08 -- a streaming cache hit is still a query
                    # (the batch path has recorded its hits since
                    # 2026-09-26; this path never did).  The execution id is
                    # the request's ContextVar -- this function has no
                    # parameter for it.
                    _record_cache_hit_observation(
                        None, bucket, tbl.get("s3_prefix"),
                        cached.get("snapshot_id", ""), len(data_files or []),
                        _ice_pf_stream,
                        files_before_prune=cached.get("files_before_prune"))
                    # JOIN-PRUNER: serve cached bounds + distinct values.
                    if _is_join_anchor_s:
                        _cb_s = cached.get("join_key_bounds") or {}
                        _cd_s = cached.get("join_key_distinct_values") or {}
                        _cd_bloom_s = cached.get("join_key_distinct_values_bloom") or {}
                        if _cb_s:
                            _join_anchor_bounds_s[_tname_lower] = _cb_s
                        if _cd_s:
                            _join_anchor_distinct_s[_tname_lower] = _cd_s
                        # BLOOM JOIN-PRUNE (2026-07-13): restore anchor's
                        # complete distinct set so a repeat join's target
                        # bloom-prune engages on an anchor cache hit.
                        if _cd_bloom_s:
                            _join_anchor_distinct_bloom_s[_tname_lower] = _cd_bloom_s
                        _join_anchor_file_count_s[_tname_lower] = len(data_files or [])
                        # Runtime-DF completeness attestation (2026-07-15):
                        # only an explicit stored True counts (legacy /
                        # L2-promoted entries ⇒ not proven ⇒ no push).
                        _join_anchor_scan_complete_s[_tname_lower] = (
                            cached.get("file_enumeration_complete") is True)
                else:
                    from core.iceberg_reader import get_iceberg_data_files
                    s3_client = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                    _out_meta = {}
                    raw_files = get_iceberg_data_files(s3_client, bucket, tbl["s3_prefix"],
                                                       partition_filters=_ice_pf_stream,
                                                       keys_only=True,
                                                       force_fresh=force_fresh_iceberg,
                                                       _out_meta=_out_meta,
                                                       db_manager=db_manager,
                                                       or_groups=or_groups,  # BF-568
                                                       # 2026-07-23 island heal: per-table
                                                       # identity for B3 scoping + hive-path
                                                       # island fallback attribution.
                                                       table_name=tname,
                                                       join_key_columns=_join_key_cols_for_call_s or None)
                    # 2026-07-14 DATA-LOSS SAFETY NET (streaming parity) — if the
                    # synth join-key filters pruned this table to 0 files, re-read
                    # WITHOUT them (its own WHERE filters only) and adopt those
                    # files if any, so a cross-table value-encoding mismatch can't
                    # silently drop every join row.  Cap-bypass only when bounded;
                    # any error leaves it empty.
                    if not raw_files and _join_synth_s:
                        try:
                            _presynth_pf_s = _compute_table_filters(
                                partition_filters, tname,
                                bool(primary_tables and _tname_lower in {p.lower() for p in primary_tables}),
                                all_table_names=[
                                    t.get("name")
                                    for t in (registered_tables or [])
                                    if isinstance(t, dict) and t.get("name")],
                                raw_sql=raw_sql)
                            _sn_cap_off_s = bool(_presynth_pf_s)
                            _sn_reread_s = get_iceberg_data_files(
                                s3_client, bucket, tbl["s3_prefix"],
                                partition_filters=_presynth_pf_s or None,
                                keys_only=True, _out_meta={},
                                force_fresh=force_fresh_iceberg,
                                db_manager=db_manager, or_groups=or_groups,
                                table_name=tname,   # 2026-07-23 island heal
                                enforce_max_files_cap=(not _sn_cap_off_s),
                            ) or []
                            if _sn_reread_s:
                                logger.warning(
                                    "STREAM SAFETY NET: synth join filter(s) pruned "
                                    "'%s' to 0 files — re-read WITHOUT synth has %d "
                                    "files; using those.", tname, len(_sn_reread_s))
                                raw_files = _sn_reread_s
                        except Exception as _sn_exc_s:
                            logger.warning(
                                "STREAM SAFETY NET: re-read for '%s' failed (%s) — "
                                "leaving empty.", tname, _sn_exc_s)
                    # BF-299: auto-add to watched registry
                    try:
                        from core.iceberg_metadata_sync import note_query_against
                        note_query_against(connection_id, bucket, tbl["s3_prefix"])
                    except Exception:
                        pass
                    # BLOOM JOIN-PRUNE moved DOWNSTREAM (2026-07-13 fix):
                    # must run AFTER _ice_cache_set so the shared
                    # (conn, table, partition_filter) cache stores the FULL
                    # file list, never a query-specific pruned one.  See the
                    # post-cache, view-local prune below the cache write.
                    _rc = sum(f.get("record_count", 0) for f in raw_files if isinstance(f, dict))
                    data_files = [
                        f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                        for f in raw_files
                    ]
                    _les_counts = [f.get("record_count") if isinstance(f, dict) else None
                                   for f in raw_files]
                    _ice_snapshot = _out_meta.get("snapshot_id", "")
                    # JOIN-PRUNER: store bounds + distinct values alongside files.
                    _ice_cache_set(
                        cache_key, data_files, None,
                        record_count=_rc, snapshot_id=str(_ice_snapshot),
                        join_key_bounds=_out_meta.get("join_key_bounds") or {},
                        join_key_distinct_values=_out_meta.get("join_key_distinct_values") or {},
                        join_key_distinct_values_bloom=_out_meta.get("join_key_distinct_values_bloom") or {},
                        # 2026-07-15 — cache the resolved delete files so repeat
                        # queries on this MoR table rebuild the delete-aware view.
                        pos_delete_files=_out_meta.get("pos_delete_files") or [],
                        eq_delete_files=_out_meta.get("eq_delete_files") or [],
                        # Runtime-DF completeness attestation.
                        file_enumeration_complete=_out_meta.get("file_enumeration_complete"),
                        iceberg_read_plan=_out_meta.get("iceberg_read_plan"),
                        empty_island=_out_meta.get("empty_island"),
                        file_record_counts=_les_counts,
                        # 2026-10-08 -- see the batch store above.
                        files_before_prune=_out_meta.get("files_before_prune"),
                    )
                    _total_records += _rc
                    # JOIN-PRUNER: capture bounds + distinct values +
                    # file count for any target tables we'll process
                    # later in this loop.
                    if _is_join_anchor_s:
                        _jkb_s = _out_meta.get("join_key_bounds") or {}
                        if _jkb_s:
                            _join_anchor_bounds_s[_tname_lower] = _jkb_s
                        _jkd_s = _out_meta.get("join_key_distinct_values") or {}
                        if _jkd_s:
                            _join_anchor_distinct_s[_tname_lower] = _jkd_s
                        _jkd_bloom_s = _out_meta.get("join_key_distinct_values_bloom") or {}
                        if _jkd_bloom_s:
                            _join_anchor_distinct_bloom_s[_tname_lower] = _jkd_bloom_s
                        _join_anchor_file_count_s[_tname_lower] = len(raw_files or [])
                        # Runtime-DF completeness attestation (2026-07-15).
                        _join_anchor_scan_complete_s[_tname_lower] = (
                            _out_meta.get("file_enumeration_complete") is True)
                # ── 2026-10-07 LIMIT-ONLY EARLY STOP (core/limit_early_stop.py) ──
                # A statement answered by ANY n rows of this table reads only
                # the first files whose manifest record counts reach n -- the
                # cache above keeps the FULL list; only this query's view is
                # narrowed.  Declines (and logs why) on anything else.
                if data_files and raw_sql:
                    try:
                        from core.limit_early_stop import plan_limit_early_stop as _les_plan
                        _les_kept = _les_plan(
                            raw_sql, tname, data_files,
                            _les_counts or [None] * len(data_files),
                            _out_meta, road="register_s3_views",
                            bucket=bucket, table_prefix=tbl.get("s3_prefix"))
                    except Exception as _les_exc:  # noqa: BLE001 -- never break the read
                        logger.debug("[limit-early-stop] skipped for %r: %s", tname, _les_exc)
                        _les_kept = None
                    if _les_kept is not None:
                        data_files = _les_kept
                # ── 2026-09-28 THE EMPTY ISLAND (consumer side) ──────────
                # An empty file list may become an empty view (the BF-504
                # path below) ONLY when the reader PROVED it: every drop
                # independently justified by the pruning gate.  The reader
                # re-proves and widens itself before answering, so an
                # unproven empty here means the reader was bypassed (a
                # pre-fix cache entry, an error path).  Unknown is not
                # empty: widen to the full enumeration; if even that cannot
                # be read, REFUSE rather than serve 0 rows as success.
                if not data_files and _ice_pf_stream:
                    from core.pruning_gate import (
                        EmptyIslandUnproven as _EIUnproven,
                        empty_island_proven as _ei_proven_fn)
                    if not _ei_proven_fn(_out_meta):
                        logger.error(
                            "STREAM-DIAG '%s': iceberg pruned to 0 files and the "
                            "emptiness is NOT PROVEN (verdict=%s) -- widening "
                            "to the full enumeration (DuckDB applies the WHERE)",
                            tname, (_out_meta or {}).get("empty_island"))
                        try:
                            from core.iceberg_reader import (
                                get_iceberg_data_files as _ei_reader)
                            _ei_widened = _ei_reader(
                                s3_client, bucket, tbl["s3_prefix"],
                                partition_filters=None, keys_only=True,
                                _out_meta={}, force_fresh=force_fresh_iceberg,
                                db_manager=db_manager, table_name=tname) or []
                        except Exception as _ei_exc:
                            raise _EIUnproven(
                                f"Iceberg table '{tname}' pruned to 0 files; the "
                                f"pruning could not be proven and the unfiltered "
                                f"enumeration failed ({_ei_exc}). Refusing to "
                                f"answer 0 rows on a guess.") from _ei_exc
                        data_files = [
                            f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                            for f in _ei_widened]
                        if isinstance(_out_meta, dict):
                            _out_meta["empty_island"] = {
                                "proven": not data_files,
                                "reason": ("full enumeration is empty"
                                           if not data_files else
                                           "widened by the view builder"),
                                "widened_to": len(data_files)}
                # 2026-07-14 (round 5 self-audit) — GENUINE-0-files guarantee.
                # The `if data_files:` block below (which holds the bloom-emptied
                # empty-view handler) is SKIPPED ENTIRELY when the read returned 0
                # files, leaving the table with NO view → the COPY crashes with
                # CatalogException.  Create the real-schema 0-row view here so a
                # JOIN binds and returns 0 rows.  (The in-block handler still
                # covers the case where a non-empty read is later emptied by the
                # bloom prune.)
                if not data_files:
                    logger.info(
                        "STREAM-DIAG: Iceberg '%s': read returned 0 files — "
                        "creating empty schema view (genuine-empty guarantee)",
                        tname)
                    try:
                        _typed0_s = typed_empty_view_ddl(tname, connection_id, db_manager)
                        if _typed0_s:
                            con.execute(_typed0_s)
                        else:
                            _create_empty_iceberg_view(
                                con, tname_esc, tname, connection_id, db_manager)
                    except Exception as _e0_s:
                        logger.error(
                            "Failed to create genuine-empty iceberg view for '%s': "
                            "%s — bare dummy fallback", tname, _e0_s)
                        try:
                            con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT 1 AS dummy WHERE FALSE')
                        except Exception as _dummy_exc:
                            logger.error(
                                "REG-VIEW '%s': even the bare dummy view failed "
                                "(%s) — downstream COPY will error for this table.",
                                tname, _dummy_exc)
                    _file_stats.setdefault(tname, {
                        "total": len(raw_files or []), "after_pruning": 0,
                        "format": "iceberg"})
                if data_files:
                    data_files = [
                        f"s3://{bucket}/{f['key']}" if isinstance(f, dict) else f
                        for f in data_files
                    ]
                    total_all = len(data_files)
                    # ── BLOOM JOIN-PRUNE (raw-SQL path, 2026-07-13) ───────────
                    # Applied HERE — AFTER the file list is resolved (cache OR
                    # fresh) AND AFTER _ice_cache_set stored the FULL list — so
                    # the shared (conn, table, partition_filter) cache is NEVER
                    # contaminated with a query-specific pruned list.  Touches
                    # only the local ``data_files`` for THIS query's view.
                    # Fail-open + complete-by-construction (see structured path).
                    # KEEP the full list if a prune would empty it.
                    if (_jp_stream and _tname_lower in _target_tables_lower_s
                            and data_files and db_manager is not None):
                        try:
                            _snap_for_prune_s = str(
                                (cached.get("snapshot_id") if cached
                                 else _out_meta.get("snapshot_id"))
                                or _current_snap_for_cache_si or "")
                            if _snap_for_prune_s:
                                from core.iceberg_bloom_sidecar import (
                                    bloom_prune_target_files as _bloom_prune_s,
                                )
                                _pfx_s = f"s3://{bucket}/"
                                _key_of_s = (lambda u: u[len(_pfx_s):]
                                             if isinstance(u, str)
                                             and u.startswith(_pfx_s) else u)
                                for _bp_s in _join_probes_stream:
                                    if _bp_s.target_table != _tname_lower:
                                        continue
                                    _bk_s = (_join_anchor_distinct_bloom_s.get(
                                        _bp_s.anchor_table) or {}).get(_bp_s.anchor_col)
                                    if not _bk_s:
                                        continue
                                    _kept_s2, _bstats_s = _bloom_prune_s(
                                        db_manager, bucket=bucket,
                                        table_prefix=prefix,
                                        snapshot_id=_snap_for_prune_s,
                                        target_files=[_key_of_s(u) for u in data_files],
                                        join_column=_bp_s.target_col,
                                        anchor_keys=_bk_s, anchor_keys_complete=True,
                                    )
                                    if _bstats_s.get("pruned") and _kept_s2:
                                        _keep_set_s = set(_kept_s2)
                                        data_files = [u for u in data_files
                                                      if _key_of_s(u) in _keep_set_s]
                                        logger.info(
                                            "[bloom-join-prune][raw-sql] table=%s "
                                            "target_col=%s anchor=%s keys=%d -> "
                                            "pruned %d, %d remain (post-cache)", tname,
                                            _bp_s.target_col, _bp_s.anchor_table,
                                            len(_bk_s), _bstats_s["pruned"],
                                            len(data_files))
                        except Exception as _bloom_exc_s:
                            logger.debug(
                                "bloom join-prune (raw-sql) failed (fail-open): %s",
                                _bloom_exc_s)
                    # Manifest pruning already applied; log result
                    if _apply_pruning:
                        logger.info("STREAM-DIAG: Iceberg '%s': %d files after manifest pruning (%s)", tname, len(data_files), "primary" if (primary_tables and tname in primary_tables) else "joined")
                    # BF-546 (2026-05-29): capture iceberg metadata-key
                    # freshness verdict so the response can render a
                    # "Data: verified / cached / fresh" badge.  Stamp
                    # lives on the s3_client as `_qs_iceberg_freshness`
                    # (set by `_latest_metadata_key` per BF-526).
                    _ice_freshness = getattr(s3_client,
                                              "_qs_iceberg_freshness", "")
                    _file_stats[tname] = {
                        "total":         total_all,
                        "after_pruning": len(data_files),
                        "format":        "iceberg",
                        "iceberg_freshness": _ice_freshness,
                    }
                    if not data_files:
                        logger.info("STREAM-DIAG: Iceberg '%s': 0/%d files after partition filter — empty view",
                                    tname, total_all)
                        _ice_s3 = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                        _empty_view_made = False
                        try:
                            # 2026-07-14 (deep-dive round 5): PREFER the real
                            # iceberg SCHEMA view (schema cache — always has
                            # partition source columns, no S3) so a partition-key
                            # JOIN binds.  The read_parquet sample can OMIT
                            # partition columns; it's only a cold-cache fallback.
                            _typed_ddl = typed_empty_view_ddl(
                                tname, connection_id, db_manager)
                            if _typed_ddl:
                                con.execute(_typed_ddl)
                                _empty_view_made = True
                            else:
                                from core.iceberg_reader import get_iceberg_data_files as _gdf
                                _schema_files = _gdf(_ice_s3, bucket, tbl["s3_prefix"], keys_only=True, max_files=1)
                                if _schema_files:
                                    _sf = f"s3://{bucket}/{_schema_files[0]['key']}"
                                    _sf_list = _s3_urls_to_presigned(_ice_s3, [_sf], cfg)
                                    if _get_s3_access_mode(cfg) == "presigned":
                                        _sf_list, _td = _presigned_to_local(_sf_list, cfg)
                                        register_temp_dir(_td)
                                    elif _is_proxy_active_for_duckdb():
                                        # BF-428K — router-first; fall to legacy predl
                                        _rr = _try_router_for_predownload(
                                            s3_client=_ice_s3, bucket=bucket,
                                            s3_keys=[_sf], table_name=tname,
                                            progress_fn=progress_fn,
                                            forced_reader=reader_override,
                                        )
                                        if (_rr is not None
                                                and _rr.output_kind == "local_paths"
                                                and _rr.read_targets):
                                            _sf_list = _rr.read_targets
                                        else:
                                            _sf_list, _td = _s3_to_local_via_boto3(_ice_s3, [_sf])
                                    _sf = _sf_list[0]
                                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'{_esc(_sf)}\', hive_partitioning=true) WHERE FALSE')
                                    _empty_view_made = True
                        except Exception as _empty_ice_exc:
                            logger.error("Failed to create empty Iceberg schema view for '%s': %s", tname, _empty_ice_exc, exc_info=True)
                        # GUARANTEE a view exists (BF-504/507): a missing view →
                        # downstream COPY crashes with CatalogException.  Real
                        # schema → VARCHAR → bare dummy, always creates something.
                        if not _empty_view_made:
                            try:
                                _create_empty_iceberg_view(
                                    con, tname_esc, tname, connection_id, db_manager)
                            except Exception as _cev_exc:
                                logger.error(
                                    "REG-VIEW '%s': real-schema empty view failed "
                                    "(%s) — bare dummy fallback", tname, _cev_exc)
                                try:
                                    con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT 1 AS dummy WHERE FALSE')
                                except Exception as _dummy_exc2:
                                    logger.error(
                                        "REG-VIEW '%s': even the bare dummy view "
                                        "failed (%s) — COPY will error for this "
                                        "table.", tname, _dummy_exc2)
                    else:
                        _MAX_STREAM_FILES = _limits_cfg.max_stream_files if _limits_cfg else 500
                        if len(data_files) > _MAX_STREAM_FILES:
                            logger.info("STREAM-DIAG: '%s' still has %d files after filter, capping to %d",
                                        tname, len(data_files), _MAX_STREAM_FILES)
                            data_files = data_files[-_MAX_STREAM_FILES:]
                        _ice_s3 = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                        _orig_ice_urls = list(data_files)
                        # Smart-VPC fast path (2026-06-23) — STREAMING iceberg
                        # path (register_s3_views).  Same rationale as the
                        # batch path in setup_registered_views: VPC + hive ->
                        # rewrite to presigned HTTPS, DuckDB reads via VPC
                        # lazily, no local download.  On-prem (Hive)
                        # endpoints don't match the VPC pattern so this is
                        # a no-op for them.
                        _stream_vpc_handled = False
                        _stream_vpc_needed_predownload = False
                        try:
                            from core.s3_utilities import (
                                vpc_presigned_rewrite_needed as _vpc_need_si,
                                s3_urls_to_presigned_vpc as _vpc_presign_si,
                            )
                            if _vpc_need_si(cfg, _orig_ice_urls):
                                try:
                                    data_files = _vpc_presign_si(
                                        _ice_s3, data_files, cfg)
                                    _stream_vpc_handled = True
                                    logger.info(
                                        "STREAM-DIAG: '%s' VPC + hive paths -> "
                                        "rewrote %d s3:// URL(s) to presigned "
                                        "HTTPS (DuckDB reads via VPC, no download)",
                                        tname, len(_orig_ice_urls))
                                except Exception as _vpc_si_sign_exc:
                                    _stream_vpc_needed_predownload = True
                                    logger.warning(
                                        "STREAM-DIAG: '%s' VPC presigned-"
                                        "rewrite FAILED (%s) -- forcing "
                                        "pre-download safety net",
                                        tname, _vpc_si_sign_exc)
                        except Exception as _vpc_si_exc:
                            logger.warning(
                                "STREAM-DIAG: '%s' VPC presigned-rewrite "
                                "skipped (non-fatal): %s",
                                tname, _vpc_si_exc)
                        if not _stream_vpc_handled:
                            data_files = _s3_urls_to_presigned(_ice_s3, data_files, cfg)
                        # On-prem presigned: pre-download so DuckDB reads local files
                        if not _stream_vpc_handled and _get_s3_access_mode(cfg) == "presigned":
                            # Phase 10 — kick the cache prefetch fan-out the
                            # moment this island's presigned URLs resolve,
                            # overlapping it with router selection + the
                            # blocking download below.
                            _prefetch_presigned(data_files, cfg)
                            # BF-429 — router-first for on-prem streaming Iceberg
                            _ppr_si = _try_router_for_presigned(
                                s3_client=_ice_s3, conn_config=cfg,
                                bucket=bucket, s3_keys=_orig_ice_urls,
                                table_name=tname, progress_fn=progress_fn,
                                forced_reader=reader_override,
                            )
                            if (_ppr_si is not None
                                    and _ppr_si.output_kind in ("local_paths", "s3_paths")
                                    and _ppr_si.read_targets):
                                data_files = _ppr_si.read_targets
                            else:
                                data_files, _td = _presigned_to_local(
                                    data_files, cfg, s3_client=_ice_s3,
                                    original_s3_urls=_orig_ice_urls)
                                register_temp_dir(_td)
                        elif (not _stream_vpc_handled) and (_stream_vpc_needed_predownload or _is_proxy_active_for_duckdb()):
                            # BF-428K — router-first for streaming Iceberg
                            _rr = _try_router_for_predownload(
                                s3_client=_ice_s3, bucket=bucket,
                                s3_keys=_orig_ice_urls, table_name=tname,
                                progress_fn=progress_fn,
                                forced_reader=reader_override,
                                # 2026-08-03 defect fix — trusted row-group
                                # filters for PRIMARY tables only (same scope
                                # as file-level pruning).  No raw SQL text in
                                # this streaming path → projection stays None
                                # (read ALL columns — fail-safe).
                                partition_filters=(
                                    partition_filters
                                    if tname in _primary_set else None),
                            )
                            if (_rr is not None
                                    and _rr.output_kind == "local_paths"
                                    and _rr.read_targets
                                    and _rr.files_failed == 0):
                                data_files = _rr.read_targets
                            else:
                                data_files, _td = _s3_to_local_via_boto3(_ice_s3, _orig_ice_urls)
                        # 2026-07-15 MoR wiring (streaming parity with
                        # setup_registered_views): when iceberg_mor.enabled=true
                        # AND _out_meta carries pos/eq delete files, build the
                        # delete-aware anti-join view via the SAME single
                        # chokepoint the batch path uses (_apply_mor_view).
                        # fail_loud=True: if deletes exist but provably cannot
                        # be applied, the chokepoint RAISES (unless
                        # iceberg_mor.allow_stale_reads=true) → caught by the
                        # per-table handler below → BF-484 surfaces an
                        # actionable error instead of a silent overcount.
                        # Tables without delete files return False immediately
                        # (plain-view path unchanged).
                        try:
                            _out_for_mor_si = _out_meta if isinstance(_out_meta, dict) else {}
                        except NameError:
                            _out_for_mor_si = {}
                        _n_mor_del_si = (
                            len(_out_for_mor_si.get("pos_delete_files") or [])
                            + len(_out_for_mor_si.get("eq_delete_files") or []))
                        if _n_mor_del_si and tname in _file_stats:
                            # Signal to execute_stream_api that the manifest
                            # record_count sum is delete-blind for this table.
                            _file_stats[tname]["mor_delete_files"] = _n_mor_del_si
                        _mor_built_si = _apply_mor_view(
                            con, tname, tname_esc, data_files,
                            orig_s3_paths=_orig_ice_urls,
                            ice_meta_out=_out_for_mor_si,
                            bucket=bucket, conn_config=cfg,
                            s3_client=_ice_s3, s3_prefix=tbl["s3_prefix"],
                            log_prefix="REG-VIEW (stream)", fail_loud=True,
                        )
                        if _mor_built_si and _join_view_where_s:
                            logger.debug(
                                "JOIN-PRUNER (stream): view WHERE skipped for "
                                "'%s' — MoR view (same as batch path)", tname)
                        if not _mor_built_si:
                            # BF-PRUNE-PERF: streaming Iceberg branch -- same
                            # threshold-gated auto-enable as the REG-VIEW
                            # chokepoint above.  See that block for the full
                            # rationale.
                            try:
                                from core.config import s3 as _s3_cfg_si
                                _ubn_si = _s3_cfg_si.duckdb_union_by_name_iceberg
                                _ubn_max_si = int(getattr(
                                    _s3_cfg_si, "union_by_name_max_files", 200))
                            except Exception:
                                _ubn_si = False
                                _ubn_max_si = 200
                            _ice_evo_si = False
                            _ice_type_conflict_si = False
                            try:
                                # 2026-09-25 -- was `_ice_meta_out`, a name that
                                # exists only in setup_registered_views: the
                                # NameError was swallowed and schema evolution
                                # NEVER auto-enabled union_by_name on the
                                # streaming path.  The streaming meta dict is
                                # `_out_meta`.  The type-conflict guard the
                                # batch path applies is honoured here too.
                                if isinstance(_out_meta, dict):
                                    _ice_evo_si = bool(_out_meta.get(
                                        "iceberg_schema_evolution"))
                                    _ice_type_conflict_si = bool(_out_meta.get(
                                        "iceberg_schema_type_conflict"))
                            except (NameError, Exception):
                                pass
                            _force_fast_si = os.environ.get(
                                "QS_FORCE_FAST_ICEBERG", "").strip() in (
                                "1", "true", "TRUE", "yes")
                            _fc_si = len(data_files) if data_files else 0
                            _evo_si_in_threshold = (
                                _ice_evo_si
                                and not _force_fast_si
                                and _fc_si <= _ubn_max_si
                            )
                            _ubn_si_effective = (
                                True if _evo_si_in_threshold else _ubn_si
                            )
                            if _evo_si_in_threshold and not _ubn_si:
                                logger.info(
                                    "STREAM-DIAG: Iceberg '%s' schema evolution "
                                    "+ file count %d <= threshold %d -- auto "
                                    "enabling union_by_name=true (correctness).",
                                    tname, _fc_si, _ubn_max_si,
                                )
                            elif _ice_evo_si and not _ubn_si and _fc_si > _ubn_max_si:
                                logger.warning(
                                    "STREAM-DIAG: Iceberg '%s' schema evolution "
                                    "BUT file count %d > threshold %d -- using "
                                    "fast path.  Add partition filters or raise "
                                    "s3.union_by_name_max_files if columns go "
                                    "missing.",
                                    tname, _fc_si, _ubn_max_si,
                                )
                            if _ubn_si_effective and _ice_type_conflict_si:
                                _ubn_si_effective = False
                                logger.warning(
                                    "STREAM-DIAG: Iceberg '%s' schema has a "
                                    "cross-version TYPE conflict — union_by_name "
                                    "FORCED OFF (DuckDB 1.5.3 segfault).", tname)
                            # 2026-09-25 -- THE read decision (values from the
                            # data files vs the hive path; current-schema
                            # projection) comes from core.iceberg_read_plan,
                            # shared with the batch, raw-SQL and MoR builders.
                            # In hive-path mode the plan's from_expr IS the
                            # BF-494 partition-spec-evolution helper's output
                            # (UNION ALL BY NAME across hive-key signatures).
                            _plan_si = _plan_iceberg_read(
                                data_files, meta=_out_meta,
                                union_by_name=_ubn_si_effective,
                                table_name=tname, log_prefix="REG-VIEW (stream)",
                            )
                            _from_expr_si = _plan_si.from_expr
                            if "UNION ALL BY NAME" in _from_expr_si:
                                logger.info(
                                    "STREAM-DIAG: Iceberg '%s' partition-spec "
                                    "evolution — emitting UNION ALL BY NAME view "
                                    "(%d signature groups)",
                                    tname, _from_expr_si.count("read_parquet"),
                                )
                            # JOIN-PRUNER row-group injection (streaming
                            # iceberg path).  Same contract as the batch path
                            # in setup_registered_views — append WHERE so
                            # DuckDB row-group pruning fires on synth filters.
                            con.execute(
                                f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                f'{_iceberg_view_select_sql(_plan_si, _join_view_where_s or "")}'
                            )
                            if _join_view_where_s:
                                logger.info(
                                    "JOIN-PRUNER (stream): appended view WHERE "
                                    "for '%s': %s", tname, _join_view_where_s[:200],
                                )
                        if tname in _primary_set:
                            _any_primary_with_data = True
                        logger.info("STREAM-DIAG: Iceberg view '%s': %d/%d files after partition filter (%.2fs)",
                                    tname, len(data_files), total_all, _rv_t.monotonic() - _rv0)
            except Exception as e:
                logger.warning("Stream: could not register Iceberg view '%s': %s", tname, e, exc_info=True)
                # BF-484 — track failure so caller can refuse to emit empty rows.
                _registration_failures[tname] = {
                    "format": "iceberg",
                    "error_type": type(e).__name__,
                    "error_message": _s3_failure_text(e),
                }
        elif fmt == "parquet":
            try:
                _pq_s3 = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                # 2026-08-03 ISLAND-FIRST LIST (streaming parity with the
                # batch path): targeted LIST of the pinned partition island;
                # None → today's full listing.  Post-filter below still runs,
                # so the final file set is identical — see
                # core/island_prefix_planner.py for the coverage proof.
                _pq_files = None
                if _apply_pruning and (_tbl_filters or or_groups):
                    try:
                        from core.island_prefix_planner import (
                            list_island_parquet_files_cached as _island_list_s)
                        _pq_files = _island_list_s(
                            connection_id, _pq_s3, bucket, prefix, _tbl_filters,
                            or_groups=or_groups)
                        if _pq_files is not None and len(_pq_files) == 0:
                            # Proven-empty island → preserve legacy
                            # empty-result handling (see batch path).
                            logger.info(
                                "STREAM-DIAG: Parquet '%s': island proven "
                                "empty — re-running full listing for legacy "
                                "empty handling", tname)
                            _pq_files = None
                        elif _pq_files is not None:
                            logger.info(
                                "STREAM-DIAG: Parquet '%s': island-targeted "
                                "LIST served %d key(s) (ocean skipped)",
                                tname, len(_pq_files))
                    except Exception as _island_exc_s:
                        logger.debug(
                            "STREAM-DIAG: Parquet '%s': island listing "
                            "unavailable (fallback): %s", tname, _island_exc_s)
                        _pq_files = None
                if _pq_files is None:
                    _pq_files = _list_s3_parquet_files_cached(connection_id, _pq_s3, bucket, prefix)
                    # 2026-08-20 — streaming twin of the batch-path check:
                    # the listing's truncated=True verdict had no consumers
                    # here either.  Check before the partition filter below
                    # returns a plain list and drops the flag.
                    try:
                        from core.scan_truncation import surface_truncated_listing
                        _pq_trunc_info_s = surface_truncated_listing(
                            _pq_files, table=tname, bucket=bucket,
                            prefix=prefix)
                        if _pq_trunc_info_s:
                            _file_cap_by_table[tname] = _pq_trunc_info_s
                    except Exception as _pq_trunc_exc_s:
                        logger.warning(
                            "STREAM-DIAG: Parquet '%s': could not surface "
                            "listing truncation (%s)", tname, _pq_trunc_exc_s)
                if _pq_files:
                    total_pq = len(_pq_files)
                    if _apply_pruning:
                        # 2026-08-22 — the GATE, not just the verdict.  This
                        # path recorded the truncation above and then
                        # partition-filtered it anyway, so the identical query
                        # that raises on the batch path returned 0 rows and
                        # HTTP 200 here, reported as a legitimate empty
                        # result.  Recording a hazard is not the same as
                        # refusing to act on it.
                        try:
                            from core.scan_truncation import (
                                refuse_truncated_partition_scan as _refuse_tps_s,
                            )
                            _tps_msg_s = _refuse_tps_s(
                                _file_cap_by_table.get(tname), True, tname)
                        except Exception as _tps_exc_s:
                            _tps_msg_s = None
                            logger.debug(
                                "STREAM-DIAG: truncation gate unavailable: %s",
                                _tps_exc_s)
                        if _tps_msg_s:
                            try:
                                from core.config import get as _tc_cfg_s
                                _tc_strict_s = bool(_tc_cfg_s(
                                    "plain_parquet",
                                    "fail_on_truncated_partition_scan", True))
                            except Exception:
                                _tc_strict_s = True
                            if _tc_strict_s:
                                logger.error("STREAM-DIAG %s", _tps_msg_s)
                                from core.scan_truncation import (
                                    TruncatedScanRefusal as _TSRefuse_s,
                                )
                                raise _TSRefuse_s(_tps_msg_s)
                            logger.error(
                                "STREAM-DIAG %s  (plain_parquet."
                                "fail_on_truncated_partition_scan=false — "
                                "continuing with a knowingly partial scan)",
                                _tps_msg_s)
                        _pq_files = _filter_iceberg_files_by_partitions(
                            _pq_files, _tbl_filters, or_groups=or_groups)
                        logger.info("STREAM-DIAG: Parquet '%s': pruned %d→%d files (%s)", tname, total_pq, len(_pq_files), "primary" if (primary_tables and tname in primary_tables) else "joined")
                    # ── Phase 134-A: Footer stats pruning (2026-07-04 STREAMING
                    # PARITY with setup_registered_views).  The streaming grid
                    # was missing this stage, so an interactive query scanned
                    # more files than the identical batch/feed query.  Same
                    # guards + EXACT index-aligned reconstruction as the batch
                    # path.  Fail-OPEN (any error -> keep all files).
                    if _pq_files and len(_pq_files) > 1:
                        try:
                            from core.config import s3 as _s3p_cfg_s
                            if _s3p_cfg_s.footer_stats_enabled and len(_pq_files) >= _s3p_cfg_s.footer_stats_min_files_threshold:
                                from core.s3_footer_stats import FooterStatsCache
                                _fsc_s = FooterStatsCache.instance()
                                if _fsc_s and _tbl_filters:
                                    from core.s3_footer_stats import prune_files_by_footer_stats
                                    _fs_keys_s = []
                                    for _pf_s in _pq_files:
                                        if isinstance(_pf_s, str) and _pf_s.startswith("s3://"):
                                            _parts_s = _pf_s[5:].split("/", 1)
                                            _fs_keys_s.append(_parts_s[1] if len(_parts_s) > 1 else _pf_s)
                                        else:
                                            _fs_keys_s.append(_pf_s)
                                    _kept_keys_s, _pruned_n_s, _fs_stats_s = prune_files_by_footer_stats(
                                        _fs_keys_s, _tbl_filters, connection_id or 0, _pq_s3, bucket, _fsc_s,
                                    )
                                    if _pruned_n_s > 0:
                                        _kept_set_s = set(_kept_keys_s)
                                        _before_fs_s = len(_pq_files)
                                        _pq_files = [
                                            f for f, _k in zip(_pq_files, _fs_keys_s)
                                            if _k in _kept_set_s
                                        ]
                                        logger.info("STREAM-DIAG: Parquet '%s': footer stats pruning %d→%d files",
                                                    tname, _before_fs_s, len(_pq_files))
                        except Exception as _fs_exc_s:
                            logger.debug("Footer stats pruning skipped (stream) for '%s': %s", tname, _fs_exc_s)
                    # Phase 151.B + 151.C — plain-parquet supplement +
                    # bloom drops in the streaming branch.  Same hooks
                    # as setup_registered_views.  Fail-OPEN inside.
                    _supp_before_s = len(_pq_files) if _pq_files else 0
                    _supp_drops_s = 0
                    _bloom_drops_s = 0
                    if _pq_files and _apply_pruning:
                        try:
                            from core.plain_parquet_brain_hooks import (
                                apply_supplement_drops as _apply_supp_s,
                                apply_bloom_drops      as _apply_bloom_s,
                                record_pruning_history_for_parquet as _rec_pp_s,
                                brain_enabled as _pp_brain_on_s,
                            )
                            _pq_files, _supp_drops_s = _apply_supp_s(
                                db_manager=_db_manager,
                                bucket=bucket, table_prefix=prefix,
                                files=_pq_files, table_filters=_tbl_filters,
                                table_name=tname,
                            )
                            _pq_files, _bloom_drops_s = _apply_bloom_s(
                                db_manager=_db_manager,
                                bucket=bucket, table_prefix=prefix,
                                files=_pq_files, table_filters=_tbl_filters,
                                table_name=tname,
                            )
                            if _pp_brain_on_s() and total_pq > 0:
                                _rec_pp_s(
                                    bucket=bucket, table_prefix=prefix,
                                    files_before_prune=total_pq,
                                    files_after_prune=len(_pq_files) if _pq_files else 0,
                                    stage_drops={
                                        "partition":  max(0, total_pq - _supp_before_s),
                                        "supplement": int(_supp_drops_s),
                                        "bloom":      int(_bloom_drops_s),
                                    },
                                    filter_breakdown=_tbl_filters,
                                    source="duckdb_views.parquet.stream",
                                    file_keys=_pq_files,
                                )
                        except Exception as _pp_exc_s:
                            logger.debug(
                                "plain_parquet stream hooks skipped for '%s': %s",
                                tname, _pp_exc_s,
                            )
                    # 2026-10-07 LIMIT-ONLY EARLY STOP, plain parquet (core/limit_early_stop.py):
                    # a statement any n rows of this table answer reads only the LEADING
                    # files whose footers' row counts reach n (probed in batches).  Declines
                    # (and logs why) on every other shape.  BEFORE the scan budget: a bare
                    # LIMIT trimmed to a handful of files is not a whole-table scan.
                    if _pq_files and raw_sql:
                        try:
                            from core.limit_early_stop import plan_hive_limit_early_stop as _les_hive
                            _les_hive_kept = _les_hive(raw_sql, tname, _pq_files, _pq_s3, bucket,
                                                       road="register_s3_views", table_prefix=prefix)
                        except Exception as _les_hive_exc:  # noqa: BLE001 -- never break the read
                            logger.debug("[limit-early-stop] skipped for %r: %s", tname, _les_hive_exc)
                            _les_hive_kept = None
                        if _les_hive_kept is not None:
                            _pq_files = _les_hive_kept
                    _file_stats[tname] = {"total": total_pq, "after_pruning": len(_pq_files), "format": "parquet"}
                    # 2026-08-20 — truncation distinct from pruning.
                    if tname in _file_cap_by_table:
                        _file_stats[tname]["file_cap"] = _file_cap_by_table[tname]
                    if not _pq_files:
                        _schema_pq = _list_s3_parquet_files(_pq_s3, bucket, prefix, max_files=1)
                        if _schema_pq:
                            _schema_urls = _s3_urls_to_presigned(_pq_s3, _schema_pq[:1], cfg)
                            if _get_s3_access_mode(cfg) == "presigned":
                                _schema_urls, _td = _presigned_to_local(_schema_urls, cfg)
                                register_temp_dir(_td)
                            elif _is_proxy_active_for_duckdb():
                                # BF-428K — router-first for empty parquet
                                _rr = _try_router_for_predownload(
                                    s3_client=_pq_s3, bucket=bucket,
                                    s3_keys=_schema_pq[:1], table_name=tname,
                                    progress_fn=progress_fn,
                                    forced_reader=reader_override,
                                )
                                if (_rr is not None
                                        and _rr.output_kind == "local_paths"
                                        and _rr.read_targets):
                                    _schema_urls = _rr.read_targets
                                else:
                                    _schema_urls, _td = _s3_to_local_via_boto3(_pq_s3, _schema_pq[:1])
                            con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_parquet(\'{_esc(_schema_urls[0])}\', hive_partitioning=true) WHERE FALSE')
                        logger.info("STREAM-DIAG: Parquet view '%s': 0/%d files after partition filter — empty view", tname, total_pq)
                    else:
                        # ── THE ONE SCAN BUDGET (FB-55, 2026-09-21) ───────
                        # The streaming road reads plain parquet too, and it
                        # consulted NEITHER file-count ceiling — only the
                        # 200-file ``max_stream_files`` slice below, which is
                        # a cap and not a gate.  A budget an operator sets to
                        # protect a pod has to hold on every road into the
                        # data or it protects nothing; with the shipped
                        # default (0 = off) this is inert.
                        from core.scan_budget import (
                            enforce_scan_budget as _enforce_budget_s,
                        )
                        _enforce_budget_s(
                            len(_pq_files), table=tname, bucket=bucket,
                            prefix=prefix, listed=total_pq,
                            filters=len(_tbl_filters or []), road="stream")
                        # ── THE FOURTH CEILING, REMOVED (FB-55, 2026-09-21) ─
                        # ``limits.max_stream_files`` (200) sliced this list
                        # to the LAST 200 keys, with a ``logger.warning`` as
                        # its only trace — so a streaming result missing rows
                        # answered 200 and could still be certified COMPLETE,
                        # and ``mv_manager`` (the other caller of this
                        # function) MATERIALISED the truncated set, making
                        # the loss durable.
                        #
                        # Removed for the same reason as the BF-579 slice on
                        # the batch road above: a CAP MAY THROTTLE, but this
                        # one throttles by dropping rows, and a latency
                        # concern is not a licence to answer a different
                        # question.  Plain parquet now has exactly ONE
                        # file-count ceiling — ``core/scan_budget.py``,
                        # enforced a few lines above — and it REFUSES with a
                        # count, a knob and a remedy instead.
                        #
                        # Its remedy string also named
                        # ``multi_worker.max_stream_files`` while the
                        # accessor reads ``limits.max_stream_files``, so an
                        # operator who followed the advice would have set a
                        # key nothing consults.  ``max_stream_files`` remains
                        # live and unchanged on the ICEBERG streaming branch
                        # above, whose count comes from a manifest.
                        _orig_pq_urls = list(_pq_files)
                        # Smart-VPC fast path (2026-06-23) — STREAMING parquet
                        # path (register_s3_views).  Mirror of the iceberg
                        # branch above.
                        _stream_pq_vpc_handled = False
                        _stream_pq_vpc_needed_predownload = False
                        try:
                            from core.s3_utilities import (
                                vpc_presigned_rewrite_needed as _vpc_need_sp,
                                s3_urls_to_presigned_vpc as _vpc_presign_sp,
                            )
                            if _vpc_need_sp(cfg, _orig_pq_urls):
                                try:
                                    _pq_files = _vpc_presign_sp(
                                        _pq_s3, _pq_files, cfg)
                                    _stream_pq_vpc_handled = True
                                    logger.info(
                                        "STREAM-DIAG: '%s' (parquet) VPC + hive "
                                        "-> rewrote %d s3:// URL(s) to presigned "
                                        "HTTPS (DuckDB reads via VPC, no download)",
                                        tname, len(_orig_pq_urls))
                                except Exception as _vpc_sp_sign_exc:
                                    _stream_pq_vpc_needed_predownload = True
                                    logger.warning(
                                        "STREAM-DIAG: '%s' (parquet) VPC "
                                        "presigned-rewrite FAILED (%s) -- "
                                        "forcing pre-download safety net",
                                        tname, _vpc_sp_sign_exc)
                        except Exception as _vpc_sp_exc:
                            logger.warning(
                                "STREAM-DIAG: '%s' (parquet) VPC presigned-"
                                "rewrite skipped (non-fatal): %s",
                                tname, _vpc_sp_exc)
                        if not _stream_pq_vpc_handled:
                            _pq_files = _s3_urls_to_presigned(_pq_s3, _pq_files, cfg)
                        if not _stream_pq_vpc_handled and _get_s3_access_mode(cfg) == "presigned":
                            # BF-429 — router-first for on-prem streaming parquet
                            _ppr_sp = _try_router_for_presigned(
                                s3_client=_pq_s3, conn_config=cfg,
                                bucket=bucket, s3_keys=_orig_pq_urls,
                                table_name=tname, progress_fn=progress_fn,
                                forced_reader=reader_override,
                            )
                            if (_ppr_sp is not None
                                    and _ppr_sp.output_kind in ("local_paths", "s3_paths")
                                    and _ppr_sp.read_targets):
                                _pq_files = _ppr_sp.read_targets
                            else:
                                _pq_files, _td = _presigned_to_local(
                                    _pq_files, cfg, s3_client=_pq_s3,
                                    original_s3_urls=_orig_pq_urls)
                                register_temp_dir(_td)
                        elif (not _stream_pq_vpc_handled) and (_stream_pq_vpc_needed_predownload or _is_proxy_active_for_duckdb()):
                            # BF-428K — router-first for streaming parquet
                            _rr = _try_router_for_predownload(
                                s3_client=_pq_s3, bucket=bucket,
                                s3_keys=_orig_pq_urls, table_name=tname,
                                progress_fn=progress_fn,
                                forced_reader=reader_override,
                                # 2026-08-03 defect fix — trusted row-group
                                # filters for PRIMARY tables only; no raw SQL
                                # here → projection None (read ALL, fail-safe).
                                partition_filters=(
                                    partition_filters
                                    if tname in _primary_set else None),
                            )
                            if (_rr is not None
                                    and _rr.output_kind == "local_paths"
                                    and _rr.read_targets
                                    and _rr.files_failed == 0):
                                _pq_files = _rr.read_targets
                            else:
                                _pq_files, _td = _s3_to_local_via_boto3(_pq_s3, _orig_pq_urls)
                        # BF-PRUNE-PERF: streaming parquet branch — same flag.
                        try:
                            from core.config import s3 as _s3_cfg_sp
                            _ubn_sp = _s3_cfg_sp.duckdb_union_by_name_parquet
                        except Exception:
                            _ubn_sp = False
                        _union_sp = ", union_by_name=true" if _ubn_sp else ""
                        # BF-494 — streaming parquet hive-key mismatch
                        # (same as setup_registered_views parquet branch).
                        _from_expr_sp = _build_iceberg_read_expr(
                            _pq_files, union_clause=_union_sp,
                            hive_types=_declared_partition_types(
                                connection_id, tname, db_manager, paths=_pq_files),
                        )
                        if "UNION ALL BY NAME" in _from_expr_sp:
                            logger.info(
                                "STREAM-DIAG: parquet '%s' hive-key mismatch — "
                                "emitting UNION ALL BY NAME view (%d signature groups)",
                                tname, _from_expr_sp.count("read_parquet"),
                            )
                        # JOIN-PRUNER row-group injection (streaming parquet).
                        _view_where_sp = (
                            f' WHERE {_join_view_where_s}' if _join_view_where_s else ''
                        )
                        con.execute(
                            f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                            f'SELECT * FROM {_from_expr_sp}{_view_where_sp}'
                        )
                        if _join_view_where_s:
                            logger.info(
                                "JOIN-PRUNER (stream): appended view WHERE for "
                                "parquet '%s': %s", tname, _join_view_where_s[:200],
                            )
                        if tname in _primary_set:
                            _any_primary_with_data = True
                        logger.info("STREAM-DIAG: Parquet view '%s': %d/%d files after partition filter (%.2fs)",
                                    tname, len(_pq_files), total_pq, _rv_t.monotonic() - _rv0)
                else:
                    logger.warning("Stream: no parquet files found for '%s' under %s/%s", tname, bucket, prefix)
            except Exception as _pq_err:
                # Same rule as the batch path: a truncation REFUSAL must not
                # be retried through the presigned fallback, which re-lists
                # the same truncated keys and registers them with the
                # partition filter dropped.  2026-09-21 (FB-55) —
                # ``ScanBudgetRefusal`` for the same reason; see the batch
                # path's handler for the mechanism.
                from core.scan_truncation import (
                    TruncatedScanRefusal as _TSRefuse_h,
                    ScanBudgetRefusal as _SBRefuse_h,
                )
                if isinstance(_pq_err, (_TSRefuse_h, _SBRefuse_h)):
                    raise
                _pq_access = _get_s3_access_mode(cfg)
                if _pq_access == "presigned":
                    # Presigned mode: glob fallback not possible — propagate error
                    logger.error("Stream: parquet view creation failed for '%s' (presigned mode): %s", tname, _pq_err, exc_info=True)
                    raise RuntimeError(
                        f"Failed to register S3 table '{tname}': {_pq_err}. "
                        f"Check S3 credentials, endpoint URL, and path_style setting."
                    ) from _pq_err
                else:
                    # Native mode failed — try presigned URLs as intermediate fallback
                    logger.warning("Stream: DuckDB view creation failed for '%s' in native mode: %s — trying presigned URLs", tname, _pq_err, exc_info=True)
                    _sps_ok = False
                    try:
                        _sps_s3 = _make_s3_client_for_conn({"id": connection_id, "config": cfg})
                        _sps_files = _list_s3_parquet_files(_sps_s3, bucket, prefix)
                        if _sps_files:
                            _sps_presigned = []
                            for _sps_url in _sps_files:
                                if _sps_url.startswith("s3://"):
                                    _sps_parts = _sps_url[5:].split("/", 1)
                                    _sps_key = _sps_parts[1] if len(_sps_parts) > 1 else ""
                                    try:
                                        from urllib.parse import urlparse, urlunparse, unquote
                                        # 2026-06-24 -- read VPC presigned TTL
                                        # from config (was hardcoded 3600s/1h).
                                        try:
                                            from core.config import get as _sps_cfg_get
                                            _sps_ttl = int(_sps_cfg_get(
                                                "presigned_url",
                                                "vpc_expiry_seconds", 21600))
                                        except Exception:
                                            _sps_ttl = 21600
                                        _sps_signed = _sps_s3.generate_presigned_url(
                                            "get_object",
                                            Params={"Bucket": _sps_parts[0], "Key": _sps_key},
                                            ExpiresIn=_sps_ttl,
                                        )
                                        _sps_parsed = urlparse(_sps_signed)
                                        _sps_decoded = unquote(_sps_parsed.path)
                                        if _sps_decoded != _sps_parsed.path:
                                            _sps_signed = urlunparse((_sps_parsed.scheme, _sps_parsed.netloc, _sps_decoded,
                                                                       _sps_parsed.params, _sps_parsed.query, _sps_parsed.fragment))
                                        _sps_presigned.append(_sps_signed)
                                    except Exception:
                                        _sps_presigned.append(_sps_url)
                                else:
                                    _sps_presigned.append(_sps_url)
                            # Pre-download presigned URLs for DuckDB local reads
                            if _get_s3_access_mode(cfg) == "presigned" or cfg.get("path_style", False):
                                _sps_presigned, _td = _presigned_to_local(_sps_presigned, cfg)
                                register_temp_dir(_td)
                            # BF-494 — streaming presigned-fallback also
                            # needs hive-signature grouping.
                            _from_expr_sps = _build_iceberg_read_expr(
                                _sps_presigned, union_clause=", union_by_name=true",
                                hive_types=_declared_partition_types(
                                    connection_id, tname, db_manager, paths=_sps_presigned),
                            )
                            if "UNION ALL BY NAME" in _from_expr_sps:
                                logger.info(
                                    "Stream: presigned-fallback '%s' hive-key "
                                    "mismatch — emitting UNION ALL BY NAME view",
                                    tname,
                                )
                            con.execute(
                                f'CREATE OR REPLACE VIEW "{tname_esc}" AS '
                                f'SELECT * FROM {_from_expr_sps}'
                            )
                            if tname in _primary_set:
                                _any_primary_with_data = True
                            _sps_ok = True
                            logger.info("Stream: presigned fallback succeeded for '%s' (%d files)", tname, len(_sps_presigned))
                    except Exception as _sps_err:
                        logger.warning("Stream: presigned fallback also failed for '%s': %s", tname, _sps_err)
                    if not _sps_ok:
                        logger.error("Stream: all registration attempts failed for '%s' — table unavailable", tname)
                        # BF-484 — all parquet fallback paths exhausted.
                        _registration_failures[tname] = {
                            "format": "parquet",
                            "error_type": type(_pq_err).__name__,
                            "error_message": _s3_failure_text(_pq_err),
                        }
        elif fmt == "csv":
            if _get_s3_access_mode(cfg) == "presigned":
                # Presigned mode: glob not possible — pre-list + pre-sign CSV files
                try:
                    from core.s3_utilities import list_s3_csv_files as _csv_list_s, s3_urls_to_presigned as _csv_presign_s, make_s3_client_for_conn as _csv_make_s3_s
                    _csv_s3_s = _csv_make_s3_s({"id": connection_id, "config": cfg})
                    # 2026-08-20 — A TRUNCATED CSV LISTING IS NOT A COMPLETE ONE.
                    # ``list_s3_csv_files`` has stamped ``truncated=True`` at its
                    # 5000-file cap since 2026-08-03; every parquet listing site
                    # surfaces that verdict and this one did not, so a >cap CSV
                    # table served a SUBSET and certified COMPLETE.  Read the
                    # verdict HERE: presigning returns a plain list and the flag
                    # is gone by the next line.
                    _csv_files_s = _csv_list_s(_csv_s3_s, bucket, prefix)
                    try:
                        from core.scan_truncation import surface_truncated_listing
                        # NO execution_id here: register_s3_views does not
                        # take one.  record_scan_truncation resolves it from the
                        # ambient execution context instead — passing a name that
                        # does not exist would raise NameError straight into the
                        # except below, which logs and moves on, leaving a fix
                        # that looks applied and never fires.
                        _csv_trunc_s = surface_truncated_listing(
                            _csv_files_s, table=tname, bucket=bucket,
                            prefix=prefix)
                        if _csv_trunc_s:
                            _file_cap_by_table[tname] = _csv_trunc_s
                            _file_stats.setdefault(tname, {
                                "total": len(_csv_files_s),
                                "after_pruning": len(_csv_files_s),
                                "format": "csv"})["file_cap"] = _csv_trunc_s
                    except Exception as _csv_trunc_s_exc:
                        logger.warning(
                            "Stream '%s': could not surface CSV listing "
                            "truncation (%s)", tname, _csv_trunc_s_exc)
                    if not _csv_files_s:
                        logger.warning("Stream: no CSV files found for '%s' (presigned mode) under %s/%s", tname, bucket, prefix)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT 1 WHERE FALSE')
                        # 2026-08-20 — same fail-closed disclosure as the
                        # batch presigned-CSV branch: an empty LIST must
                        # reach the BF-484/BF-514 gate, not serve 0 rows
                        # as a silent HTTP 200.
                        _registration_failures[tname] = {
                            "format": "csv",
                            "error_type": "EmptyCsvListing",
                            "error_message": (
                                f"boto3 LIST returned 0 CSV files under "
                                f"s3://{bucket}/{prefix}/ — cannot distinguish "
                                f"an empty dataset from a failed or "
                                f"permission-filtered listing; refusing to "
                                f"serve 0 rows as a silent success. Verify "
                                f"the prefix and S3 list permissions."
                            ),
                        }
                    else:
                        _csv_files_s = _csv_presign_s(_csv_s3_s, _csv_files_s, cfg)
                        # Pre-download for on-prem presigned mode
                        _csv_files_s, _td = _presigned_to_local(_csv_files_s, cfg)
                        register_temp_dir(_td)
                        _csv_paths_s = ", ".join(f"'{_esc(f)}'" for f in _csv_files_s)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_csv_auto([{_csv_paths_s}])')
                        if tname in _primary_set:
                            _any_primary_with_data = True
                except Exception as _csv_err_s:
                    logger.error("Stream: CSV registration failed for '%s' (presigned mode): %s", tname, _csv_err_s, exc_info=True)
                    raise RuntimeError(
                        f"Failed to register S3 CSV table '{tname}': {_csv_err_s}. "
                        f"Check S3 credentials, endpoint URL, and path_style setting."
                    ) from _csv_err_s
            elif _is_proxy_active_for_duckdb():
                # Proxy active: list CSV files via boto3, pre-download, read local
                try:
                    from core.s3_utilities import list_s3_csv_files as _csv_list_px, make_s3_client_for_conn as _csv_make_s3_px
                    _csv_s3_px = _csv_make_s3_px({"id": connection_id, "config": cfg})
                    # 2026-08-20 — A TRUNCATED CSV LISTING IS NOT A COMPLETE ONE.
                    # ``list_s3_csv_files`` has stamped ``truncated=True`` at its
                    # 5000-file cap since 2026-08-03; every parquet listing site
                    # surfaces that verdict and this one did not, so a >cap CSV
                    # table served a SUBSET and certified COMPLETE.  Read the
                    # verdict HERE: presigning returns a plain list and the flag
                    # is gone by the next line.
                    _csv_files_px = _csv_list_px(_csv_s3_px, bucket, prefix)
                    try:
                        from core.scan_truncation import surface_truncated_listing
                        # NO execution_id here: register_s3_views does not
                        # take one.  record_scan_truncation resolves it from the
                        # ambient execution context instead — passing a name that
                        # does not exist would raise NameError straight into the
                        # except below, which logs and moves on, leaving a fix
                        # that looks applied and never fires.
                        _csv_trunc_px = surface_truncated_listing(
                            _csv_files_px, table=tname, bucket=bucket,
                            prefix=prefix)
                        if _csv_trunc_px:
                            _file_cap_by_table[tname] = _csv_trunc_px
                            _file_stats.setdefault(tname, {
                                "total": len(_csv_files_px),
                                "after_pruning": len(_csv_files_px),
                                "format": "csv"})["file_cap"] = _csv_trunc_px
                    except Exception as _csv_trunc_px_exc:
                        logger.warning(
                            "Stream '%s': could not surface CSV listing "
                            "truncation (%s)", tname, _csv_trunc_px_exc)
                    if not _csv_files_px:
                        logger.warning("Stream: no CSV files found for '%s' (proxy mode) under %s/%s", tname, bucket, prefix)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT 1 WHERE FALSE')
                        # 2026-08-20 — same fail-closed disclosure as the
                        # presigned branches (see EmptyCsvListing above).
                        _registration_failures[tname] = {
                            "format": "csv",
                            "error_type": "EmptyCsvListing",
                            "error_message": (
                                f"boto3 LIST returned 0 CSV files under "
                                f"s3://{bucket}/{prefix}/ — cannot distinguish "
                                f"an empty dataset from a failed or "
                                f"permission-filtered listing; refusing to "
                                f"serve 0 rows as a silent success. Verify "
                                f"the prefix and S3 list permissions."
                            ),
                        }
                    else:
                        # BF-419 — utility self-registers temp_dir
                        _csv_local, _td = _s3_to_local_via_boto3(_csv_s3_px, _csv_files_px)
                        _csv_paths_px = ", ".join(f"'{_esc(f)}'" for f in _csv_local)
                        con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_csv_auto([{_csv_paths_px}])')
                        if tname in _primary_set:
                            _any_primary_with_data = True
                except Exception as _csv_px_err:
                    logger.error("Stream: CSV proxy pre-download failed for '%s': %s", tname, _csv_px_err, exc_info=True)
                    raise RuntimeError(
                        f"Failed to register S3 CSV table '{tname}' via proxy: {_csv_px_err}. "
                        f"Check S3 credentials, proxy settings, and endpoint URL."
                    ) from _csv_px_err
            else:
                con.execute(f'CREATE OR REPLACE VIEW "{tname_esc}" AS SELECT * FROM read_csv_auto(\'s3://{_esc(bucket)}/{_esc(prefix)}/**/*.csv\')')
                if tname in _primary_set:
                    _any_primary_with_data = True

    # Register materialized views as local parquet VIEWs
    _mv_storage = getattr(_mv_cfg, 'storage_dir', None) if _mv_cfg else None
    if _mv_storage and _db_manager:
        try:
            mv_list = _db_manager.list_materialized_views(connection_id=connection_id)
            for mv in mv_list:
                if mv["status"] != "ready" or not mv.get("is_active", True):
                    continue
                mv_name = mv["name"]
                if referenced_tables and mv_name not in referenced_tables:
                    continue
                mv_dir = os.path.join(_mv_storage, str(mv["id"]))
                import glob as _glob_mod
                pq_files = _glob_mod.glob(os.path.join(mv_dir, "*.parquet"))
                # Phase 139 — local MV parquet footer-stats + bloom pruning
                if pq_files and len(pq_files) > 1:
                    try:
                        # 2026-08-09: was `_primary_tables`, a local of
                        # setup_registered_views — undefined here.  The
                        # NameError was swallowed by the fail-open except
                        # below, so Phase-139 local-MV pruning never ran.
                        # `primary_tables` is this function's own parameter;
                        # use the same normalisation as the S3 path above.
                        # all_table_names is REQUIRED for either guard to
                        # fire: `_multi` is False without it, so both the
                        # is_primary rule and the binding check were
                        # structurally dead here, and the filter flowed
                        # into prune_local_parquet_files(use_bloom=True) —
                        # the same file-level drop the guards exist to stop.
                        _filt_for_mv = _compute_table_filters(
                            partition_filters, mv_name,
                            bool(primary_tables and mv_name.lower() in {p.lower() for p in primary_tables}),
                            all_table_names=[t.get("name") for t in (registered_tables or [])
                                             if isinstance(t, dict) and t.get("name")],
                            raw_sql=raw_sql,
                        )
                        if _filt_for_mv:
                            from core.parquet_pruning import prune_local_parquet_files
                            _before_mv = len(pq_files)
                            pq_files = prune_local_parquet_files(
                                pq_files, _filt_for_mv, use_bloom=True,
                            )
                            if len(pq_files) < _before_mv:
                                logger.info("MV '%s': pruned %d→%d files via footer/bloom",
                                            mv_name, _before_mv, len(pq_files))
                    except Exception as _mv_lp_exc:
                        logger.debug("MV footer pruning skipped (%s): %s", mv_name, _mv_lp_exc)
                if pq_files:
                    paths_str = ", ".join(f"'{_to_ddb_path(p)}'" for p in pq_files)
                    vname = "__mv__" + mv_name.replace('"', '""')
                    con.execute(f'CREATE OR REPLACE VIEW "{vname}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                    logger.info("Registered materialized view '%s' with %d local files", mv_name, len(pq_files))
        except Exception as e:
            logger.warning("Could not register materialized views: %s", e, exc_info=True)

    # Register local tables as local parquet VIEWs
    _lt_storage = getattr(_lt_cfg, 'storage_dir', None) if _lt_cfg else None
    if _lt_storage and _db_manager:
        try:
            import glob as _glob_mod2
            lt_list = _db_manager.list_local_tables()
            for lt in lt_list:
                if lt["status"] != "ready" or not lt.get("is_active", True):
                    continue
                lt_name = lt["name"]
                if referenced_tables and lt_name not in referenced_tables and f"__lt__{lt_name}" not in referenced_tables:
                    continue
                lt_dir = os.path.join(_lt_storage, str(lt["id"]))
                pq_files = _glob_mod2.glob(os.path.join(lt_dir, "*.parquet"))
                if pq_files:
                    # Phase 139 — local parquet footer-stats + bloom pruning.
                    # Closes the gap that pruning was S3-only. Fail-OPEN.
                    if pq_files and len(pq_files) > 1:
                        try:
                            # 2026-08-09: same fix as the MV branch above —
                            # `_primary_tables` belongs to
                            # setup_registered_views, not to this function.
                            _filt_for_lt = _compute_table_filters(
                                partition_filters, lt_name,
                                bool(primary_tables and lt_name.lower() in {p.lower() for p in primary_tables}),
                                all_table_names=[t.get("name") for t in (registered_tables or [])
                                                 if isinstance(t, dict) and t.get("name")],
                                raw_sql=raw_sql,
                            )
                            if _filt_for_lt:
                                from core.parquet_pruning import prune_local_parquet_files
                                _before_n = len(pq_files)
                                pq_files = prune_local_parquet_files(
                                    pq_files, _filt_for_lt, use_bloom=True,
                                )
                                if len(pq_files) < _before_n:
                                    logger.info("Local table '%s': pruned %d→%d files via footer/bloom",
                                                lt_name, _before_n, len(pq_files))
                        except Exception as _lp_exc:
                            logger.debug("Local table footer pruning skipped (%s): %s", lt_name, _lp_exc)
                if pq_files:
                    paths_str = ", ".join(f"'{_to_ddb_path(p)}'" for p in pq_files)
                    vname = "__lt__" + lt_name.replace('"', '""')
                    con.execute(f'CREATE OR REPLACE VIEW "{vname}" AS SELECT * FROM read_parquet([{paths_str}], hive_partitioning=true)')
                    logger.info("Registered local table '%s' with %d local files", lt_name, len(pq_files))
                    try:
                        _db_manager.touch_local_table(lt["id"])
                    except Exception as _touch_exc:
                        logger.error("Failed to touch local table '%s' (id=%s): %s", lt_name, lt["id"], _touch_exc, exc_info=True)
                else:
                    logger.warning("Local table '%s' (id=%s) has no parquet files at %s — view __lt__%s will NOT be created",
                                   lt_name, lt["id"], lt_dir, lt_name)
        except Exception as e:
            logger.warning("Could not register local tables: %s", e, exc_info=True)

    _all_primary_empty = _all_primary_empty and not _any_primary_with_data
    if _all_primary_empty:
        logger.warning("Stream: all primary tables pruned to 0 files — queries will return empty results")

    # BF-484 — stamp the failure dict on the connection so the caller (e.g.
    # execute_stream_api) can refuse to return empty rows when CREATE VIEW
    # failed due to auth/network rather than legitimately-empty pruning.
    try:
        setattr(con, "_qs_register_failures", dict(_registration_failures))
    except Exception:
        pass

    # 2026-10-06 -- remote-I/O concurrency for the views this call built:
    # the same decision as setup_registered_views (one function), so the
    # streaming grid, PV and MV roads stop reading two files at a time.
    try:
        from core.s3_http_transport import apply_remote_io_for_views
        _rio_names = {
            str(t.get("name") or "").lower()
            for t in (registered_tables or []) if isinstance(t, dict)}
        if referenced_tables:
            _rio_ref = {str(r).lower() for r in referenced_tables}
            _rio_names = {n for n in _rio_names if n in _rio_ref} or _rio_names
        apply_remote_io_for_views(con, view_names=_rio_names,
                                  label="register_s3_views")
    except Exception as _rio_exc:                     # noqa: BLE001
        logger.debug("register_s3_views: remote I/O concurrency skipped "
                     "(fail-open): %s", _rio_exc)

    # 2026-06-23 -- Strategic guard against in-process httpfs double-signing.
    # When the smart-VPC fast path (or any future caller) embeds presigned
    # URLs into a view DDL on this connection, the connection still has
    # ``s3_endpoint`` + S3 credentials set (the in-process factory
    # _duckdb_con_with_s3 applied them at creation time).  httpfs will
    # then re-sign the already-signed URL when the view is queried ->
    # libcurl drops the malformed request -> HTTP 0 / 403.  Same root
    # cause as the subprocess bug closed by core.duckdb_s3_plan.
    #
    # Fix: scan the just-created view DDLs for the SigV4 marker.  If any
    # view embeds presigned URLs, RESET s3_endpoint + credentials on the
    # connection (so the imminent query reads the presigned URLs cleanly)
    # AND stamp the connection so the pool drops it on release -- the
    # connection's S3 settings are now in an indeterminate state, safer
    # to recycle than to risk a future query getting an unconfigured
    # one.  The stamp is consumed by data_grid_api._return_to_s3_pool
    # which closes (instead of pooling) stamped connections.
    #
    # Crash-safety: the suspend helper has its own internal try/except
    # for the probe + reset, but a future refactor could introduce a
    # path that raises before reaching them.  Wrap defensively -- the
    # caller (BQB streaming / mv_manager / materialized_views_api /
    # execute_stream_api) MUST always get the registered-views return
    # tuple, even if the suspend helper itself misbehaves.  User-
    # stated invariant 2026-06-23: "duckdb or subprocess should never
    # be crashed".
    try:
        _suspend_signing_if_views_contain_presigned_urls(
            con, registered_tables)
    except Exception as _suspend_exc:
        logger.warning(
            "register_s3_views: suspend-signing helper raised "
            "unexpectedly (%s) -- continuing with original connection "
            "state.  PRESIGNED_URLS_IN_SQL guard is forfeited for this "
            "query but the query path is otherwise unaffected.",
            _suspend_exc,
        )

    # ── Phase 107-B: post-execution full-scan detection (log only, non-fatal) ──
    try:
        from core.query_guardrails import check_post_exec_file_stats
        check_post_exec_file_stats(
            file_stats=_file_stats,
            connection_id=connection_id,
            source="register_s3_views",
        )
    except Exception as e:
        logger.warning("Post-execution guardrail check failed: %s", e)

    # ── Phase 150.B (2026-06-04) — BSOD guard for bypass paths ──
    # register_s3_views is the chokepoint for paths that don't go
    # through maybe_dispatch_multi_worker: federation_engine,
    # dataflow.sql_query_stage, published_views_api, execute_stream
    # _api.  Phase 150 in the dispatcher only protected BQB / CQB /
    # feed_gen.  This call closes the gap: every read path that
    # actually opens DuckDB views runs through the same Windows
    # mmap admission gate.  Fail-open: helper swallows config
    # errors, so we can't introduce a new failure mode.  When
    # admission rejects, RuntimeError propagates up to the caller
    # which surfaces it as a 4xx to the user — query never runs,
    # mmap never happens, machine never BSODs.
    try:
        from core.resource_admission import check_mmap_admission_or_raise
        _total_post_prune = sum(
            int((v or {}).get("after_pruning") or 0)
            for v in (_file_stats or {}).values()
        )
        if _total_post_prune > 0:
            check_mmap_admission_or_raise(
                file_count=_total_post_prune,
                n_workers=1,
                caller="register_s3_views",
            )
    except RuntimeError:
        # Admission rejected — propagate; do NOT log under this except
        # because the helper already logged with the full reason.
        raise
    except Exception as _adm_exc:
        logger.debug("Phase 150.B admission check skipped: %s", _adm_exc)

    return _total_records, _all_primary_empty, _file_stats
