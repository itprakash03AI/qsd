"""JobQueue — THE single chokepoint for the ``query_jobs`` substrate.

Every read/write of the table lives here (single-chokepoint rule).  The
design encodes the Phase 2 edge-case contract:

* **Clock skew** — leases and heartbeats are set AND compared against DB
  server time in UTC, evaluated in SQL (``now() at time zone 'utc'`` on
  PostgreSQL, ``datetime('now')`` on SQLite).  Pod wall-clocks never
  participate in expiry math.
* **Split-brain / double execution** — the claim is a single ``UPDATE …
  WHERE id = (SELECT … FOR UPDATE SKIP LOCKED)`` on PostgreSQL, so two
  executors cannot claim one job; post-claim, every write-back carries the
  **fencing token** (incremented on every claim) and is applied
  ``WHERE fencing_token = :mine`` — a zombie executor whose lease was
  reaped writes nothing (:class:`FencingError`).
* **Executor crash mid-lease** — the lease expires (no heartbeat) and
  :meth:`JobQueue.reap_orphans` returns the job to ``queued`` with
  ``attempts`` already counted (attempts increment at claim).
* **Poison job** — once ``attempts >= max_attempts`` the reaper
  quarantines to terminal ``failed`` instead of requeueing; never an
  infinite loop.
* **Duplicate delivery** — completion is idempotent under the fencing
  token: only the CURRENT lease holder's terminal write lands.
* **Rolling-deploy schema skew** — jobs carry ``payload_version``;
  ``claim_next`` only picks jobs with ``payload_version <=``
  :data:`SUPPORTED_PAYLOAD_VERSION`, leaving newer jobs for newer
  executors instead of misinterpreting them.
* **Cancellation** — cooperative: :meth:`cancel` flips a flag on the row
  (or cancels outright while still queued); executors poll it between
  stages.

Portability: the model round-trips on SQLite (dev/tests) with a
transactional claim fallback; production queue mode only ARMS on
PostgreSQL (fleet gate), where SKIP LOCKED provides contention-free
multi-executor pulls.

Fail-open posture: the queue RAISES on errors (loudly) — callers on the
API path catch and fall back to today's inline execution.  A user's
query is never silently dropped.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import socket
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from sqlalchemy import bindparam, text as sa_text

from core.db.models import QueryJob

logger = logging.getLogger(__name__)

#: Highest job payload_version this build understands.  Bump ONLY on a
#: breaking payload change; additive fields never require a bump
#: (deserializers ignore unknown fields).
SUPPORTED_PAYLOAD_VERSION = 1

#: 2026-10-31 (query pods phase 2): what a job says when the pod running it
#: died and the reaper could not hand it to another pod.
POD_DIED_NOT_RETRIED_MESSAGE = (
    "The query pod running this query stopped (a restart, a deployment or the pod "
    "running out of memory). This query is not run again by itself because it may "
    "change data or could not be checked as read-only. Press Run again.")
POD_DIED_TWICE_MESSAGE = (
    "The query pod running this query stopped, and the second try on another query "
    "pod stopped too. Ask an admin to check the query pods, then press Run again.")
#: what the retry writes on the run the dead pod left behind
CONTINUED_ELSEWHERE_MESSAGE = (
    "The query pod running this query stopped, so it was started again on another "
    "query pod as run {new}. Follow that run for the result; nothing is wrong with the query.")

_PLAN_HASH_DOMAIN = "qsjob-plan-v1|"

#: Process-local serialization of single-flight attach-or-create on SQLite
#: (dev/tests only — production single_flight arms exclusively on
#: PostgreSQL, where pg_advisory_xact_lock provides fleet-wide exclusion).
_sqlite_single_flight_lock = threading.Lock()

#: Process-local serialization of a BUDGETED claim on SQLite (2026-10-31).
#: The claim reads "what this pod already holds" and admits the candidate in
#: one statement; two claimers on one pod must not both read the same held
#: sum.  PostgreSQL serializes them per pod with ``pg_advisory_xact_lock``
#: (released at commit, so the second claimer reads the first one's row);
#: SQLite is one writer per database and dev/tests are one process, so a
#: process lock gives the same exclusion there.
_sqlite_pod_budget_lock = threading.Lock()


class QueueError(RuntimeError):
    """Base error for job-queue operations."""


class FencingError(QueueError):
    """A fenced write-back found a different fencing token / lease state —
    the caller is a zombie (its lease was reaped and possibly re-issued).
    The zombie must STOP: it owns nothing."""


class JobNotFoundError(QueueError):
    """The referenced job id does not exist."""


class JobStatus(str, Enum):
    QUEUED = "queued"
    LEASED = "leased"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"
    # Phase 5 — single-flight follower: rides another job's execution.
    # Never claimable; resolved by leader-terminal propagation (or by a
    # detach back to 'queued' when the leader cannot serve it).
    ATTACHED = "attached"

    @classmethod
    def terminal(cls) -> tuple:
        return (cls.SUCCEEDED.value, cls.FAILED.value, cls.CANCELLED.value)

    @classmethod
    def live_lease(cls) -> tuple:
        return (cls.LEASED.value, cls.RUNNING.value)

    @classmethod
    def live(cls) -> tuple:
        """States in which a job is an eligible single-flight leader."""
        return (cls.QUEUED.value, cls.LEASED.value, cls.RUNNING.value)


@dataclass(frozen=True)
class ClaimedJob:
    """A claimed job — everything an executor needs, AS DATA (no ambient
    request state, no contextvars)."""
    id: str
    kind: str
    payload_version: int
    fencing_token: int
    attempts: int
    max_attempts: int
    plan_hash: str
    snapshot_id: str
    rls_key: str
    identity_payload: Dict[str, Any]
    request: Dict[str, Any]
    rls_payload: Optional[Dict[str, Any]] = None
    passport_json: Optional[str] = None
    cancel_requested: bool = False
    enqueued_by: Optional[str] = None
    # Phase 5 — single-flight / fairness (additive, defaulted for
    # rolling-deploy compatibility with older rows).
    lane: str = "interactive"
    rls_key_shareable: bool = False
    rls_fingerprint: str = ""
    extras: Dict[str, Any] = field(default_factory=dict)
    # 2026-10-31 — the price before the run and the reservation THIS claim
    # holds (0 when the claimer is not a budgeted query pod).  The run's
    # DuckDB memory_limit is ``reserved_bytes`` (core/query_pods/budget.py).
    pod_class: str = ""
    price_bytes: int = 0
    price_source: str = ""
    reserved_bytes: int = 0
    # 2026-10-31 (phase 2) -- the execution the previous attempt left behind
    # on a pod that died (None on a first attempt)
    previous_result_handle: Optional[str] = None


@dataclass(frozen=True)
class EnqueueOutcome:
    """Result of :meth:`JobQueue.enqueue_or_attach`.

    ``attached_to`` is set when this request became a single-flight
    FOLLOWER of an existing live leader (no new execution was created);
    ``created`` is False in that case."""
    job_id: str
    attached_to: Optional[str] = None
    created: bool = True


def failclosed_rls_key(job_id: str) -> str:
    """The per-job FAIL-CLOSED rls_key (HARD gate 1).

    Used whenever the effective predicates cannot be computed with
    certainty (RlsComputationError, non-SQL request shape, policy-set
    drift detected mid-execution).  Unique per job by construction — it
    can never equal another job's key, so nothing keyed on it is ever
    shared.  ``rls_key_shareable`` additionally stays False as a second,
    independent barrier."""
    return f"failclosed:{job_id}"[:64]


def compute_plan_hash(request_payload: Dict[str, Any]) -> str:
    """Phase-2 plan hash: SHA-256 over domain-separated canonical JSON of
    the request payload.  (Phase 3 replaces this with the passport's real
    plan hash; the column contract is identical.)"""
    canonical = json.dumps(request_payload or {}, sort_keys=True,
                           separators=(",", ":"), default=str)
    return hashlib.sha256((_PLAN_HASH_DOMAIN + canonical).encode("utf-8")).hexdigest()


def make_owner_id(role: str = "executor") -> str:
    """Lease-owner identity: ``host:pid:role:uuid8`` — unique per claimer
    incarnation (a restarted process gets a fresh id)."""
    return f"{socket.gethostname()}:{os.getpid()}:{role}:{uuid.uuid4().hex[:8]}"


class JobQueue:
    """The chokepoint.  Construct with a live DatabaseManager (uses its
    ``get_session`` context manager; commits on scope exit)."""

    def __init__(self, db_manager):
        if db_manager is None:
            raise QueueError("JobQueue requires a DatabaseManager")
        self._db = db_manager

    # ── dialect helpers (DB-time ONLY — the clock-skew rule) ────────────

    @property
    def _is_pg(self) -> bool:
        return bool(getattr(self._db, "is_postgresql", False))

    @property
    def _now_sql(self) -> str:
        """SQL expression: DB server time, UTC wall-clock, both dialects."""
        return "(now() at time zone 'utc')" if self._is_pg else "datetime('now')"

    def _lease_expiry_sql(self) -> str:
        """SQL expression: DB-UTC now + :lease_s seconds."""
        if self._is_pg:
            return "((now() at time zone 'utc') + make_interval(secs => :lease_s))"
        # SQLite: modifier string is a bound param ("+120 seconds").
        return "datetime('now', :lease_mod)"

    def _lease_params(self, lease_seconds: int) -> Dict[str, Any]:
        if self._is_pg:
            return {"lease_s": int(lease_seconds)}
        return {"lease_mod": f"+{int(lease_seconds)} seconds"}

    @property
    def _created_at_value(self):
        """``created_at`` stamp (H3, 2026-07-23): the single-flight
        staleness bound and the fairness aging predicates compare
        ``created_at`` against DB ``now()`` — an API-pod wall-clock value
        lets clock skew make stale leaders look fresh / invert fairness
        aging.  On PostgreSQL (the only backend the fleet arms on, and
        the only multi-host deployment) the DB server stamps its OWN
        clock via a SQL expression, so both sides of every age predicate
        read the same clock.  On SQLite (dev/tests, single process+host)
        the Python clock IS the DB clock — skew is structurally
        impossible — and its microsecond resolution keeps FIFO ties
        ordered (SQLite SQL time functions only offer milliseconds)."""
        if self._is_pg:
            return sa_text("(now() at time zone 'utc')")
        return datetime.now(timezone.utc)

    # ── enqueue (API side — identity captured AS DATA) ──────────────────

    def _build_row(
        self,
        *,
        kind: str,
        request_payload: Dict[str, Any],
        identity,                      # EffectiveIdentity (fail-closed type check)
        rls_predicates=None,           # Optional[EffectiveRlsPredicates]
        rls_failure: Optional[str] = None,
        rls_fingerprint: str = "",
        passport=None,                 # Optional[QueryPassport]
        priority: int = 100,
        max_attempts: Optional[int] = None,
        lane: str = "interactive",
        admission_cost_mb: int = 0,
        status: str = JobStatus.QUEUED.value,
        attached_to: Optional[str] = None,
        pod_class: str = "",
        price_bytes: int = 0,
        price_source: str = "",
    ) -> QueryJob:
        """Validate + construct (NOT persist) one ``query_jobs`` row.

        SECURITY: ``identity`` MUST be an :class:`EffectiveIdentity` from
        the Phase 1 boundary — raw user dicts / usernames are refused here
        exactly like at the RLS-key chokepoint (a forged dict must not be
        laundered into a job row the executor will trust).

        The rls_key leg of the content address (HARD gate 1):
          * ``rls_predicates`` given → the Phase-1 key, ``shareable=True``
            (this includes the shared UNFILTERED key for admin-bypass /
            RLS-off / no-matching-policies — identical enforced SQL for
            everyone by the rendering theorem);
          * ``rls_failure`` given (computation failed / not computable) →
            a UNIQUE per-job fail-closed key, ``shareable=False`` — the
            job runs but NOTHING derived from it is ever shared;
          * neither → ``""`` (Phase-2 legacy posture: address-incomplete,
            never shareable — byte-for-byte pre-Phase-5 rows).
        """
        from core.identity import EffectiveIdentity
        if not isinstance(identity, EffectiveIdentity):
            raise QueueError(
                "enqueue requires a verified EffectiveIdentity (got "
                f"{type(identity).__name__}) — raw user payloads are forgeable "
                "and refused at this boundary"
            )
        if not kind or not str(kind).strip():
            raise QueueError("enqueue requires a job kind")
        if not isinstance(request_payload, dict):
            raise QueueError("request_payload must be a dict")

        if max_attempts is None:
            # 2026-10-31 (query pods phase 2): RETRY SAFETY IS A DECLARATION.
            # A job may be claimed again after its pod died only when its
            # request is PROVEN a read (core/jobqueue/retry_safety.py); any
            # other request, and any other kind, gets one attempt -- the
            # reaper then fails it with the reason instead of re-running it.
            if str(kind) == "execute_query":
                from core.jobqueue.retry_safety import max_attempts_for
                max_attempts, _why = max_attempts_for(
                    request_payload, read_attempts=self._cfg_int("max_attempts", 2))
            else:
                max_attempts = 1
        job_id = str(uuid.uuid4())
        rls_key = ""
        rls_shareable = False
        rls_json: Optional[str] = None
        if rls_predicates is not None:
            rls_key = rls_predicates.rls_key()
            rls_json = rls_predicates.canonical_json()
            rls_shareable = True
        elif rls_failure:
            rls_key = failclosed_rls_key(job_id)
            rls_shareable = False
        passport_json: Optional[str] = None
        snapshot_id = ""
        if passport is not None:
            passport_json = passport.to_json()
            snapshot_id = passport.snapshot_id or ""

        plan_hash = compute_plan_hash(request_payload)
        return QueryJob(
            id=job_id,
            kind=str(kind),
            payload_version=SUPPORTED_PAYLOAD_VERSION,
            plan_hash=plan_hash,
            snapshot_id=snapshot_id,
            rls_key=rls_key,
            identity_payload=json.dumps(identity.to_payload(),
                                        sort_keys=True, separators=(",", ":")),
            rls_payload=rls_json,
            passport_json=passport_json,
            request_payload=json.dumps(request_payload, sort_keys=True,
                                       separators=(",", ":"), default=str),
            status=status,
            priority=int(priority),
            attempts=0,
            max_attempts=max(1, int(max_attempts)),
            fencing_token=0,
            cancel_requested=False,
            lane=str(lane or "interactive"),
            attached_to=attached_to,
            rls_fingerprint=str(rls_fingerprint or ""),
            rls_key_shareable=bool(rls_shareable),
            share_verified=False,
            initiator_detached=False,
            admission_cost_mb=max(0, int(admission_cost_mb or 0)),
            # 2026-10-31 — priced at enqueue (core/query_pods/price.py);
            # '' / 0 when no query-pod sizes are configured.
            pod_class=str(pod_class or ""),
            price_bytes=max(0, int(price_bytes or 0)),
            price_source=str(price_source or ""),
            reserved_bytes=0,
            enqueued_by=identity.username,
            # H3: DB-server time on PostgreSQL (SQLAlchemy renders the
            # expression into the INSERT so the DB stamps its own clock);
            # see ``_created_at_value``.
            created_at=self._created_at_value,
        )

    def enqueue(
        self,
        *,
        kind: str,
        request_payload: Dict[str, Any],
        identity,                      # EffectiveIdentity (fail-closed type check)
        rls_predicates=None,           # Optional[EffectiveRlsPredicates]
        rls_failure: Optional[str] = None,
        passport=None,                 # Optional[QueryPassport]
        priority: int = 100,
        max_attempts: Optional[int] = None,
        lane: str = "interactive",
        admission_cost_mb: int = 0,
        pod_class: str = "",
        price_bytes: int = 0,
        price_source: str = "",
    ) -> str:
        """Insert a queued job.  Returns the job id.  (See
        :meth:`_build_row` for the security + rls_key contract; see
        :meth:`enqueue_or_attach` for the single-flight entry point.)"""
        row = self._build_row(
            kind=kind, request_payload=request_payload, identity=identity,
            rls_predicates=rls_predicates, rls_failure=rls_failure,
            passport=passport, priority=priority, max_attempts=max_attempts,
            lane=lane, admission_cost_mb=admission_cost_mb,
            pod_class=pod_class, price_bytes=price_bytes, price_source=price_source,
        )
        job_id, plan_hash = row.id, row.plan_hash   # before commit expires the instance
        with self._db.get_session() as session:
            session.add(row)
        logger.info("[jobqueue] enqueued job=%s kind=%s user=%s plan_hash=%s",
                    job_id, kind, identity.username, plan_hash[:12])
        return job_id

    # ── Phase 5 — single-flight attach-or-create (ONE guarded tx) ───────

    def enqueue_or_attach(
        self,
        *,
        kind: str,
        request_payload: Dict[str, Any],
        identity,
        rls_predicates=None,
        rls_failure: Optional[str] = None,
        rls_fingerprint: str = "",
        passport=None,
        priority: int = 100,
        max_attempts: Optional[int] = None,
        lane: str = "interactive",
        admission_cost_mb: int = 0,
        pod_class: str = "",
        price_bytes: int = 0,
        price_source: str = "",
    ) -> EnqueueOutcome:
        """Single-flight entry point: if a LIVE job (queued/leased/running)
        with the SAME ``(plan_hash, rls_key)`` enqueue-time address exists,
        ATTACH this request to it as a follower instead of creating a
        second execution; otherwise create a normal queued job.

        Correct by construction (HARD gate 1): attach requires
        ``rls_key_shareable`` on BOTH sides — identical shareable key ⇒
        identical rendered RLS predicates ⇒ identical enforced SQL ⇒
        identical result bytes.  A fail-closed per-job key never attaches
        and is never attached to.

        Snapshot leg: at enqueue neither side has pinned a snapshot yet
        (``snapshot_id=''`` — Phase 3 stamps it mid-execution), so the
        enqueue-time address is ``(plan_hash, '', rls_key)`` on both
        sides.  A live leader may already carry its stamped pin; attach
        tolerates that within ``single_flight_max_leader_age_seconds`` —
        the follower receives data as-of the leader's plan-time pin,
        which is inside the follower's own planning-latency window
        (identical to having clicked a few seconds earlier).  Older
        leaders are not attachable (staleness bound, fail-closed).

        THE RACE GUARD: attach-vs-create for one address is serialized by
        ``pg_advisory_xact_lock`` over a 64-bit digest of the address
        (PostgreSQL — the only backend the flag can arm on), so two
        concurrent enqueues can never both become leaders.  On SQLite
        (dev/tests) a process-local lock provides the same exclusion.

        Flag OFF (or key not shareable) → plain :meth:`enqueue`, one flag
        read — byte-for-byte today's behavior.
        """
        single_flight_armed = False
        try:
            from core.industrialization import is_enabled
            single_flight_armed = is_enabled("single_flight")
        except Exception:
            single_flight_armed = False

        row = self._build_row(
            kind=kind, request_payload=request_payload, identity=identity,
            rls_predicates=rls_predicates, rls_failure=rls_failure,
            rls_fingerprint=rls_fingerprint,
            passport=passport, priority=priority, max_attempts=max_attempts,
            lane=lane, admission_cost_mb=admission_cost_mb,
            pod_class=pod_class, price_bytes=price_bytes, price_source=price_source,
        )

        # Capture BEFORE any commit expires the ORM instance.
        job_id, plan_hash, job_rls_key = row.id, row.plan_hash, row.rls_key
        job_rls_fp, job_kind = row.rls_fingerprint, row.kind
        shareable = bool(row.rls_key_shareable)

        # Sharing requires BOTH a shareable key AND the policy-set
        # fingerprint captured at key time (the TOCTOU chain anchor) —
        # anything less enqueues as a plain, unshared job.
        if not (single_flight_armed and shareable and job_rls_fp):
            with self._db.get_session() as session:
                session.add(row)
            logger.info("[jobqueue] enqueued job=%s kind=%s user=%s plan_hash=%s",
                        job_id, kind, identity.username, plan_hash[:12])
            return EnqueueOutcome(job_id=job_id, attached_to=None, created=True)

        max_age = self._cfg_fairness_int(
            "single_flight_max_leader_age_seconds", 300)
        lock_key = self._address_lock_key(plan_hash, job_rls_key)

        def _attach_or_create(session) -> EnqueueOutcome:
            if self._is_pg:
                # Transaction-scoped advisory lock — released at commit/
                # abort; serializes attach-vs-create per address fleet-wide.
                session.execute(
                    sa_text("SELECT pg_advisory_xact_lock(CAST(:k AS BIGINT))"),
                    {"k": lock_key})
            if self._is_pg:
                age_pred = ("created_at > ((now() at time zone 'utc') "
                            "- make_interval(secs => :max_age))")
                age_params: Dict[str, Any] = {"max_age": int(max_age)}
            else:
                age_pred = "created_at > datetime('now', :age_mod)"
                age_params = {"age_mod": f"-{int(max_age)} seconds"}
            leader = session.execute(sa_text(f"""
                SELECT id FROM query_jobs
                WHERE plan_hash = :plan_hash AND rls_key = :rls_key
                  AND rls_fingerprint = :rls_fp
                  AND kind = :kind
                  AND status IN ('queued', 'leased', 'running')
                  AND attached_to IS NULL
                  AND rls_key_shareable = :yes
                  AND cancel_requested = :no
                  AND {age_pred}
                ORDER BY created_at ASC, id ASC
                LIMIT 1
            """), {"plan_hash": plan_hash, "rls_key": job_rls_key,
                   "rls_fp": job_rls_fp,
                   "kind": job_kind, "yes": True, "no": False, **age_params},
            ).first()
            if leader is not None:
                leader_id = leader[0]
                row.status = JobStatus.ATTACHED.value
                row.attached_to = leader_id
                session.add(row)
                return EnqueueOutcome(job_id=job_id, attached_to=leader_id,
                                      created=False)
            session.add(row)
            return EnqueueOutcome(job_id=job_id, attached_to=None, created=True)

        if self._is_pg:
            with self._db.get_session() as session:
                outcome = _attach_or_create(session)
        else:
            # SQLite dev/tests: process-local exclusion (single-writer DB).
            with _sqlite_single_flight_lock:
                with self._db.get_session() as session:
                    outcome = _attach_or_create(session)
        if outcome.attached_to:
            logger.info(
                "[jobqueue] single-flight ATTACH: job=%s user=%s rides "
                "leader=%s (plan_hash=%s)", outcome.job_id, identity.username,
                outcome.attached_to, plan_hash[:12])
        else:
            logger.info("[jobqueue] enqueued job=%s kind=%s user=%s plan_hash=%s",
                        outcome.job_id, kind, identity.username,
                        plan_hash[:12])
        return outcome

    @staticmethod
    def _address_lock_key(plan_hash: str, rls_key: str) -> int:
        """64-bit signed advisory-lock key from the enqueue-time address."""
        digest = hashlib.sha256(
            f"qsjob-sf-lock|{plan_hash}|{rls_key}".encode("utf-8")).digest()
        return int.from_bytes(digest[:8], "big", signed=True)

    def _cfg_fairness_int(self, key: str, fallback: int) -> int:
        try:
            from core.config import get as _cfg_get
            return int(_cfg_get("industrialization_fairness", key, fallback)
                       or fallback)
        except Exception:
            return fallback

    # ── claim (executor side) ───────────────────────────────────────────

    _CLAIM_COLS = ("id, kind, payload_version, plan_hash, snapshot_id, rls_key, "
                   "identity_payload, rls_payload, passport_json, request_payload, "
                   "attempts, max_attempts, fencing_token, cancel_requested, "
                   "enqueued_by, lane, rls_key_shareable, rls_fingerprint, "
                   "pod_class, price_bytes, price_source, reserved_bytes, "
                   "previous_result_handle")

    def claim_next(
        self,
        owner: str,
        *,
        lease_seconds: Optional[int] = None,
        kind: Optional[str] = None,
        pid: Optional[int] = None,
        host: Optional[str] = None,
        pod_class: Optional[str] = None,
        budget_bytes: Optional[int] = None,
        idle_budget_bytes: Optional[int] = None,
        only_unsized: bool = False,
    ) -> Optional[ClaimedJob]:
        """Claim the oldest eligible queued job (FIFO + age within priority
        — cannot starve).  PostgreSQL: single-statement
        ``FOR UPDATE SKIP LOCKED`` claim.  SQLite (dev/tests): transactional
        select-then-guarded-update.  Returns None when the queue is empty.

        2026-10-31 — a BUDGETED claim (``pod_class`` + ``budget_bytes``, the
        query pod's contract, ``core/query_pods/budget.py``): the claim also
        requires ``pod_class = :pc`` and that the job's ``price_bytes`` fit
        what the pod ``host`` still has -- ``budget_bytes`` minus the
        ``reserved_bytes`` of every job the host holds a LIVE lease on,
        derived in the SAME statement that claims (no counter anywhere).
        A pod holding nothing admits a job priced up to
        ``idle_budget_bytes`` (its size's budget; defaults to
        ``budget_bytes``), so a job that fit when priced cannot wait forever
        on a pod whose own process grew.  The claim sets ``reserved_bytes =
        price_bytes``; nothing ever "releases" it -- it is counted only
        while the lease is live, so complete / fail / cancel / expiry /
        reaper all return the bytes by ending the lease.  Two claimers on
        one host are serialized (PostgreSQL: ``pg_advisory_xact_lock`` on
        the host, released at commit; SQLite: a process lock), so two
        claims cannot both fit into the same free bytes.  A job priced
        above the budget is never claimed here -- it is refused at enqueue
        (``core/query_pods/price.py``), never left to wait.

        Both None (every caller before this date) → the legacy claim; the
        only difference in the statement is ``reserved_bytes = 0`` in the
        SET (a requeued job must not carry a dead pod's reservation).

        ``only_unsized`` (phase 2): a PLAIN executor on a fleet with query-pod
        sizes configured claims only jobs with no size -- a sized job belongs
        to a pod of its size (design §5.1); claiming it here would put the
        heavy run back in the API pod, the thing the sizes exist to stop."""
        if not owner:
            raise QueueError("claim_next requires an owner id")
        if (pod_class is None) != (budget_bytes is None):
            raise QueueError("a budgeted claim needs BOTH pod_class and budget_bytes "
                             "(a budget belongs to a pod of a size)")
        if only_unsized and pod_class is not None:
            raise QueueError("only_unsized is the plain executor's rule; a sized pod names its size")
        lease_seconds = lease_seconds or self._cfg_int("lease_seconds", 120)
        pid = pid if pid is not None else os.getpid()
        host = host or socket.gethostname()
        budget: Optional[Dict[str, Any]] = None
        if pod_class is not None:
            pc = str(pod_class).strip().lower()
            if not pc:
                raise QueueError("a budgeted claim needs a pod_class")
            budget = {"pc": pc, "budget": max(0, int(budget_bytes)),
                      "idle_budget": max(0, int(idle_budget_bytes
                                                if idle_budget_bytes is not None
                                                else budget_bytes))}
        elif only_unsized:
            budget = {"unsized_only": True}

        # Phase 5 — fleet admission + weighted-fair pull.  Flag OFF (the
        # default) → the legacy FIFO+age claim, byte-for-byte.  Any error
        # in the fairness machinery → fail OPEN to the legacy claim
        # (admission is backpressure, never a correctness dependency).
        try:
            fair = self._fairness_claim_parts()
        except Exception as exc:
            logger.warning("[jobqueue] fairness claim-parts failed — "
                           "FAIL-OPEN to plain FIFO claim: %s", exc)
            fair = None
        if fair is not None:
            try:
                if self._is_pg:
                    return self._claim_next_pg(owner, lease_seconds, kind,
                                               pid, host, fair=fair, budget=budget)
                return self._claim_next_sqlite(owner, lease_seconds, kind,
                                               pid, host, fair=fair, budget=budget)
            except Exception as exc:
                logger.warning(
                    "[jobqueue] fleet-admission claim failed — FAIL-OPEN to "
                    "plain FIFO claim: %s", exc)
        if self._is_pg:
            return self._claim_next_pg(owner, lease_seconds, kind, pid, host,
                                       budget=budget)
        return self._claim_next_sqlite(owner, lease_seconds, kind, pid, host,
                                       budget=budget)

    def _claim_predicate(self, budget: Optional[Dict[str, Any]] = None) -> str:
        # CAST on the kind filter: psycopg2 cannot type a bare
        # ``:param IS NULL`` — an uncast NULL parameter raises
        # "could not determine data type of parameter" on PostgreSQL.
        #
        # kind <> 'fleet_slot': fleet-admission WAITER rows (see
        # core.jobqueue.fleet_admission) are 'queued' by design but are
        # concurrency bookkeeping, NOT executable jobs — an executor
        # claiming one would try to run an empty payload.  No such rows
        # exist with the fleet_admission flag OFF, so the legacy claim
        # result set is unchanged.
        base = ("status = 'queued' AND kind <> 'fleet_slot' "
                "AND payload_version <= :maxver "
                "AND cancel_requested = :no "
                "AND (CAST(:kind_filter AS VARCHAR) IS NULL "
                "     OR kind = CAST(:kind_filter AS VARCHAR))")
        if budget is None:
            return base
        if budget.get("unsized_only"):
            return base + " AND pod_class = ''"
        return base + " AND " + self._budget_predicate()

    def _held_on_host_sql(self) -> str:
        """SQL: the bytes the pod ``:host`` holds in LIVE leases, 0 when none.
        The reservation ledger IS these rows; an ended lease is not counted."""
        live = (self._LIVE_LEASE_PRED
                .replace("status", "r.status")
                .replace("lease_expires_at", "r.lease_expires_at")
                .replace("kind <>", "r.kind <>")
                .format(now=self._now_sql))
        return ("COALESCE((SELECT SUM(r.reserved_bytes) FROM query_jobs r "
                f"WHERE r.executor_host = :host AND {live}), 0)")

    def _budget_predicate(self) -> str:
        """The budgeted claim's extra clause (2026-10-31): the candidate is
        for this size, and its price fits what the host still has -- or the
        host holds nothing and the price fits the size's idle budget."""
        held = self._held_on_host_sql()
        return (f"pod_class = :pc AND price_bytes <= "
                f"(CASE WHEN {held} = 0 THEN :idle_budget ELSE :budget - {held} END)")

    @staticmethod
    def _host_lock_key(host: str) -> int:
        digest = hashlib.sha256(f"qsjob-pod-budget|{host}".encode("utf-8")).digest()
        return int.from_bytes(digest[:8], "big", signed=True)

    @staticmethod
    def _claim_set_reserved_sql(budget: Optional[Dict[str, Any]]) -> str:
        """The SET clause for the reservation: a budgeted claim holds the
        job's price; any other claim holds nothing (a requeued job must not
        carry a dead pod's reservation into its next lease)."""
        if budget and not budget.get("unsized_only"):
            return "reserved_bytes = price_bytes"
        return "reserved_bytes = 0"

    # ── Phase 5 — fleet admission + weighted-fair claim (Trino resource
    #    groups analogue) ─────────────────────────────────────────────────

    # kind <> 'fleet_slot': fleet-admission slot rows are the FLEET
    # concurrency ledger (core.jobqueue.fleet_admission), not jobs — a
    # query running via the queue AND holding fleet slots must count ONCE
    # here, not three times.  The gate counts its own kind exclusively;
    # this predicate counts everything else exclusively.  (Unqualified
    # ``kind`` binds to the innermost FROM alias in the correlated
    # subqueries, same as the other columns.)
    _LIVE_LEASE_PRED = ("status IN ('leased', 'running') "
                        "AND kind <> 'fleet_slot' "
                        "AND lease_expires_at IS NOT NULL "
                        "AND lease_expires_at > {now}")

    def _fairness_claim_parts(self) -> Optional[Dict[str, Any]]:
        """Predicate/order/params for the fleet-admission claim, or None
        when the flag is off (→ legacy claim untouched).  Never raises.

        Design (all counters are COUNT/SUM over live-lease job rows — no
        independent counters, so drift is structurally impossible; the
        reaper releasing a lease IS the slot release):

          * per-user cap — a user with >= N live-lease jobs cannot have
            another claimed; their jobs stay queued (humans burst, the
            queue absorbs).
          * fleet budget — the candidate's passport-priced cost must fit
            ``fleet_memory_budget_mb`` minus inflight cost.  An EMPTY
            fleet always admits one job (a monster query alone gets the
            whole fleet — bounded waiting, never a permanent starve, and
            no deadlock when one job exceeds the whole budget).
          * lanes — interactive(0) > feed(1) > background(2), with an
            age-based promotion of one rank per ``lane_promote_seconds``
            queued: starvation is bounded by rank × promote_seconds
            (the Phase-2 "FIFO+age cannot starve" rule, extended).
          * then: per-user fairness (users with fewer running jobs
            first), priority, FIFO age, id.

        Known bounded race (documented, accepted): two executors claiming
        concurrently both read the same committed counters and can
        over-admit by one job each per tick — the same tick granularity
        Trino's dispatcher has; the per-pod resource_admission gate still
        guards actual memory at execution time.
        """
        try:
            from core.industrialization import is_enabled
            if not is_enabled("fleet_admission"):
                return None
        except Exception:
            return None
        try:
            now = self._now_sql
            live = self._LIVE_LEASE_PRED.format(now=now)
            user_cap = self._cfg_fairness_int("user_max_running", 2)
            budget = self._cfg_fairness_int("fleet_memory_budget_mb", 0)
            promote = max(1, self._cfg_fairness_int("lane_promote_seconds", 120))
            if self._is_pg:
                age_seconds = ("EXTRACT(EPOCH FROM ((now() at time zone 'utc') "
                               "- q.created_at))")
            else:
                age_seconds = ("(julianday('now') - julianday(q.created_at)) "
                               "* 86400.0")
            user_running = ("(SELECT COUNT(*) FROM query_jobs r "
                            "WHERE r.enqueued_by = q.enqueued_by AND "
                            + self._LIVE_LEASE_PRED
                            .replace("status", "r.status")
                            .replace("lease_expires_at", "r.lease_expires_at")
                            .format(now=now) + ")")
            predicate = f"({user_running} < :user_cap)"
            if budget > 0:
                inflight_cost = ("COALESCE((SELECT SUM(r2.admission_cost_mb) "
                                 "FROM query_jobs r2 WHERE "
                                 + self._LIVE_LEASE_PRED
                                 .replace("status", "r2.status")
                                 .replace("lease_expires_at", "r2.lease_expires_at")
                                 .format(now=now) + "), 0)")
                fleet_empty = ("NOT EXISTS (SELECT 1 FROM query_jobs r3 WHERE "
                               + self._LIVE_LEASE_PRED
                               .replace("status", "r3.status")
                               .replace("lease_expires_at", "r3.lease_expires_at")
                               .format(now=now) + ")")
                predicate += (f" AND ({fleet_empty} OR "
                              f"q.admission_cost_mb + {inflight_cost} <= :budget)")
            lane_rank = ("(CASE q.lane WHEN 'interactive' THEN 0 "
                         "WHEN 'feed' THEN 1 ELSE 2 END)")
            order = (f"({lane_rank} - CAST(({age_seconds}) / :promote AS INTEGER)) ASC, "
                     f"{user_running} ASC, "
                     "q.priority ASC, q.created_at ASC, q.id ASC")
            params: Dict[str, Any] = {"user_cap": int(user_cap),
                                      "promote": int(promote)}
            if budget > 0:
                params["budget"] = int(budget)
            return {"predicate": predicate, "order": order, "params": params}
        except Exception as exc:
            logger.warning("[jobqueue] fairness claim-parts build failed — "
                           "FAIL-OPEN to plain claim: %s", exc)
            return None

    def _claim_select_sql(self, fair: Optional[Dict[str, Any]],
                          *, for_update: bool,
                          budget: Optional[Dict[str, Any]] = None) -> str:
        """The candidate-picking SELECT.  Legacy shape when ``fair`` is
        None (byte-for-byte the Phase-2 statement); aliased + fairness-
        filtered + weighted-fair-ordered when armed.  ``budget`` adds the
        budgeted claim's clause to either shape."""
        suffix = "\n                FOR UPDATE SKIP LOCKED" if for_update else ""
        if fair is None:
            return (f"""
                SELECT id FROM query_jobs
                WHERE {self._claim_predicate(budget)}
                ORDER BY priority ASC, created_at ASC, id ASC
                LIMIT 1{suffix}
            """)
        # Aliased (q) so the correlated fairness subqueries can reference
        # the candidate row unambiguously; the unqualified legacy predicate
        # columns bind to q (innermost FROM wins in SQL scoping).
        return (f"""
                SELECT q.id FROM query_jobs q
                WHERE {self._claim_predicate(budget)}
                  AND {fair['predicate']}
                ORDER BY {fair['order']}
                LIMIT 1{suffix}
            """)

    def _claim_params(self, kind, host, fair, budget) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "maxver": SUPPORTED_PAYLOAD_VERSION, "no": False, "kind_filter": kind,
            **(fair["params"] if fair else {}),
        }
        if budget and not budget.get("unsized_only"):
            params.update({"pc": budget["pc"], "budget": int(budget["budget"]),
                           "idle_budget": int(budget["idle_budget"]), "host": host})
        return params

    def _claim_next_pg(self, owner, lease_seconds, kind, pid, host,
                       fair: Optional[Dict[str, Any]] = None,
                       budget: Optional[Dict[str, Any]] = None) -> Optional[ClaimedJob]:
        sql = sa_text(f"""
            UPDATE query_jobs SET
                status = 'leased',
                lease_owner = :owner,
                fencing_token = fencing_token + 1,
                attempts = attempts + 1,
                lease_expires_at = {self._lease_expiry_sql()},
                heartbeat_at = {self._now_sql},
                started_at = COALESCE(started_at, {self._now_sql}),
                executor_pid = :pid,
                executor_host = :host,
                {self._claim_set_reserved_sql(budget)}
            WHERE id = ({self._claim_select_sql(fair, for_update=True, budget=budget)})
            RETURNING {self._CLAIM_COLS}
        """)
        params = {
            "owner": owner, "pid": pid, "host": host,
            **self._claim_params(kind, host, fair, budget),
            **self._lease_params(lease_seconds),
        }
        with self._db.get_session() as session:
            if budget and not budget.get("unsized_only"):
                # One claimer per pod at a time: the held sum the predicate
                # reads is then always AFTER the previous claim on this host
                # committed (the lock is released at commit).  Pods lock
                # different keys, so they never wait on each other.
                session.execute(
                    sa_text("SELECT pg_advisory_xact_lock(CAST(:k AS BIGINT))"),
                    {"k": self._host_lock_key(host)})
            row = session.execute(sql, params).mappings().first()
        return self._row_to_claimed(row) if row else None

    def _claim_next_sqlite(self, owner, lease_seconds, kind, pid, host,
                           fair: Optional[Dict[str, Any]] = None,
                           budget: Optional[Dict[str, Any]] = None) -> Optional[ClaimedJob]:
        """SQLite fallback (dev/tests): select-then-guarded-update inside
        one session/transaction.  The ``status='queued'`` guard on the
        UPDATE (rowcount check) makes a lost race a clean miss, never a
        double claim.  A budgeted claim additionally holds the process
        lock (see ``_sqlite_pod_budget_lock``)."""
        if budget and not budget.get("unsized_only"):
            with _sqlite_pod_budget_lock:
                return self._claim_next_sqlite_tx(owner, lease_seconds, kind, pid,
                                                  host, fair, budget)
        return self._claim_next_sqlite_tx(owner, lease_seconds, kind, pid, host,
                                          fair, budget)

    def _claim_next_sqlite_tx(self, owner, lease_seconds, kind, pid, host,
                              fair, budget) -> Optional[ClaimedJob]:
        with self._db.get_session() as session:
            pick = session.execute(
                sa_text(self._claim_select_sql(fair, for_update=False, budget=budget)),
                self._claim_params(kind, host, fair, budget)).first()
            if not pick:
                return None
            job_id = pick[0]
            res = session.execute(sa_text(f"""
                UPDATE query_jobs SET
                    status = 'leased',
                    lease_owner = :owner,
                    fencing_token = fencing_token + 1,
                    attempts = attempts + 1,
                    lease_expires_at = {self._lease_expiry_sql()},
                    heartbeat_at = {self._now_sql},
                    started_at = COALESCE(started_at, {self._now_sql}),
                    executor_pid = :pid,
                    executor_host = :host,
                    {self._claim_set_reserved_sql(budget)}
                WHERE id = :id AND status = 'queued'
            """), {"owner": owner, "pid": pid, "host": host, "id": job_id,
                   **self._lease_params(lease_seconds)})
            if res.rowcount != 1:
                return None  # lost the race — clean miss
            row = session.execute(sa_text(
                f"SELECT {self._CLAIM_COLS} FROM query_jobs WHERE id = :id"
            ), {"id": job_id}).mappings().first()
        return self._row_to_claimed(row) if row else None

    @staticmethod
    def _row_to_claimed(row) -> ClaimedJob:
        m = dict(row)

        def _load(key):
            raw = m.get(key)
            if not raw:
                return None
            try:
                return json.loads(raw)
            except Exception:
                return None

        return ClaimedJob(
            id=m["id"],
            kind=m["kind"],
            payload_version=int(m.get("payload_version") or 1),
            fencing_token=int(m["fencing_token"]),
            attempts=int(m.get("attempts") or 0),
            max_attempts=int(m.get("max_attempts") or 1),
            plan_hash=m.get("plan_hash") or "",
            snapshot_id=m.get("snapshot_id") or "",
            rls_key=m.get("rls_key") or "",
            identity_payload=_load("identity_payload") or {},
            request=_load("request_payload") or {},
            rls_payload=_load("rls_payload"),
            passport_json=m.get("passport_json"),
            cancel_requested=bool(m.get("cancel_requested")),
            enqueued_by=m.get("enqueued_by"),
            lane=m.get("lane") or "interactive",
            rls_key_shareable=bool(m.get("rls_key_shareable")),
            rls_fingerprint=m.get("rls_fingerprint") or "",
            pod_class=m.get("pod_class") or "",
            price_bytes=int(m.get("price_bytes") or 0),
            price_source=m.get("price_source") or "",
            reserved_bytes=int(m.get("reserved_bytes") or 0),
            previous_result_handle=m.get("previous_result_handle") or None,
        )

    # ── fenced write-backs (zombie-proof) ───────────────────────────────

    def _fenced(self, job_id: str, token: int, set_sql: str,
                params: Dict[str, Any], statuses: tuple) -> int:
        placeholders = ", ".join(f"'{s}'" for s in statuses)
        sql = sa_text(f"""
            UPDATE query_jobs SET {set_sql}
            WHERE id = :job_id AND fencing_token = :token
              AND status IN ({placeholders})
        """)
        with self._db.get_session() as session:
            res = session.execute(sql, {"job_id": job_id, "token": int(token), **params})
            return res.rowcount

    def mark_running(self, job_id: str, token: int) -> None:
        """leased → running (fenced)."""
        n = self._fenced(job_id, token, "status = 'running'", {},
                         (JobStatus.LEASED.value,))
        if n != 1:
            raise FencingError(
                f"mark_running fenced out for job {job_id} (token {token}) — "
                "lease was reaped or job is not in 'leased' state")

    def heartbeat(self, job_id: str, token: int,
                  lease_seconds: Optional[int] = None) -> bool:
        """Renew the lease (fenced).  Returns False when fenced out — the
        caller has become a zombie and MUST stop working the job."""
        lease_seconds = lease_seconds or self._cfg_int("lease_seconds", 120)
        n = self._fenced(
            job_id, token,
            f"heartbeat_at = {self._now_sql}, "
            f"lease_expires_at = {self._lease_expiry_sql()}",
            self._lease_params(lease_seconds),
            JobStatus.live_lease(),
        )
        return n == 1

    def stamp_passport(self, job_id: str, token: int, *,
                       passport_json: str,
                       snapshot_id: str = "") -> bool:
        """Phase 3 — stamp the plan-time Query Passport onto the job row
        (fenced; live-lease only).  Also fills the ``snapshot_id`` leg of
        the content address ``(plan_hash, snapshot_id, rls_key)`` — the
        passport pins the snapshot the query actually read, which enqueue
        could not know.  Returns False when fenced out (zombie); never a
        correctness dependency (fail-open at every caller)."""
        set_sql = "passport_json = :pp"
        params: Dict[str, Any] = {"pp": passport_json}
        if snapshot_id:
            set_sql += ", snapshot_id = :snap"
            params["snap"] = str(snapshot_id)
        n = self._fenced(job_id, token, set_sql, params,
                         JobStatus.live_lease())
        return n == 1

    # ── Phase 5 — single-flight share verification (fenced) ─────────────

    def set_share_verified(self, job_id: str, token: int) -> bool:
        """Mark the leader's rls_key as PROVEN to match what enforcement
        applied (the executor's pre/post-execution verification sandwich
        passed).  Follower results are served ONLY from verified leaders —
        a leader that went terminal without this stamp (crash, absorb,
        skipped verification) can never fan its result out.  Fenced;
        returns False when fenced out (zombie)."""
        n = self._fenced(job_id, token, "share_verified = :yes", {"yes": True},
                         JobStatus.live_lease())
        return n == 1

    def unshare_leader(self, job_id: str, token: int, *, reason: str) -> int:
        """FAIL-CLOSED un-share: the executor detected that the rls_key can
        no longer be trusted for sharing (policy set changed between key
        computation and enforcement, or re-verification errored).

        Two idempotent steps in one session:
          1. re-key the leader to its per-job fail-closed key
             (``shareable=False``, ``share_verified=False``) — fenced, so a
             zombie cannot un-share a job a newer lease owns;
          2. DETACH every live follower back to an independent ``queued``
             job (its own fail-closed per-job key) — each re-executes under
             its OWN captured identity; nobody is silently dropped and
             nobody receives a result the key no longer proves safe.

        The leader's own execution continues — enforcement is always
        self-consistent for the leader's identity; only SHARING is lost.
        Returns the number of detached followers."""
        with self._db.get_session() as session:
            fenced = session.execute(sa_text("""
                UPDATE query_jobs SET
                    rls_key = 'failclosed:' || id,
                    rls_key_shareable = :no,
                    share_verified = :no
                WHERE id = :job_id AND fencing_token = :token
                  AND status IN ('leased', 'running')
            """), {"job_id": job_id, "token": int(token), "no": False})
            if fenced.rowcount != 1:
                raise FencingError(
                    f"unshare_leader fenced out for job {job_id} (token {token})")
            detached = session.execute(sa_text("""
                UPDATE query_jobs SET
                    status = 'queued',
                    attached_to = NULL,
                    rls_key = 'failclosed:' || id,
                    rls_key_shareable = :no,
                    error = :note
                WHERE attached_to = :job_id AND status = 'attached'
            """), {"job_id": job_id, "no": False,
                   "note": f"detached from leader {job_id}: {reason}"[:2000]},
            ).rowcount
        if detached:
            logger.warning(
                "[jobqueue] single-flight UNSHARE of job %s (%s) — %d "
                "follower(s) detached to independent execution",
                job_id, reason, detached)
        return detached

    def stamp_actual_peak(self, job_id: str, token: int, *,
                          peak_bytes: int) -> bool:
        """2026-10-31 — record the MEASURED peak memory of the run's DuckDB
        children on the job row (``actual_peak_bytes``) and inside the
        passport's ``actuals.peak_memory_bytes`` (the one place that number
        was ever written -- the resource governor's sampler).  The next
        price of this plan reads it (``latest_peak_for_plan``): calibration.
        Fenced, live-lease only; returns False when fenced out or when the
        peak is not a positive number (unknown is never recorded as 0)."""
        try:
            peak = int(peak_bytes or 0)
        except (TypeError, ValueError):
            return False
        if peak <= 0:
            return False
        with self._db.get_session(read_only=True) as session:
            row = session.execute(sa_text(
                "SELECT passport_json, plan_hash FROM query_jobs WHERE id = :id"
            ), {"id": job_id}).first()
        if row is None:
            return False
        passport: Dict[str, Any] = {}
        if row[0]:
            try:
                passport = json.loads(row[0])
                if not isinstance(passport, dict):
                    passport = {}
            except Exception:
                passport = {}
        if not passport:
            from core.industrialization.passport import QueryPassport
            passport = QueryPassport(plan_hash=str(row[1] or "")).to_dict()
        actuals = passport.get("actuals")
        if not isinstance(actuals, dict):
            actuals = {}
        actuals["peak_memory_bytes"] = max(int(actuals.get("peak_memory_bytes") or 0), peak)
        passport["actuals"] = actuals
        n = self._fenced(job_id, token,
                         "actual_peak_bytes = :peak, passport_json = :pp",
                         {"peak": peak, "pp": json.dumps(passport, sort_keys=True,
                                                         separators=(",", ":"), default=str)},
                         JobStatus.live_lease())
        return n == 1

    def set_submit_response(self, job_id: str, token: int, *,
                            response: Dict[str, Any],
                            result_handle: Optional[str]) -> bool:
        """Stamp the executor's submit-response (parity relay for the API
        waiter) + the result handle, while the job keeps running.  Fenced;
        returns False when fenced out."""
        n = self._fenced(
            job_id, token,
            "response_json = :resp, result_handle = :rh",
            {"resp": json.dumps(response, default=str), "rh": result_handle},
            JobStatus.live_lease(),
        )
        return n == 1

    def complete(self, job_id: str, token: int, *,
                 result_handle: Optional[str] = None) -> None:
        """Terminal success (fenced).  A zombie's complete raises
        :class:`FencingError` and writes NOTHING (duplicate-delivery /
        split-brain guard)."""
        set_sql = (f"status = 'succeeded', finished_at = {self._now_sql}, "
                   "lease_owner = NULL, lease_expires_at = NULL")
        params: Dict[str, Any] = {}
        if result_handle is not None:
            set_sql += ", result_handle = :rh"
            params["rh"] = result_handle
        n = self._fenced(job_id, token, set_sql, params, JobStatus.live_lease())
        if n != 1:
            raise FencingError(
                f"complete fenced out for job {job_id} (token {token}) — "
                "a newer lease owns this job; zombie write refused")

    def fail(self, job_id: str, token: int, *, error: str,
             requeue: bool = False) -> str:
        """Terminal failure OR fenced requeue-for-retry.

        ``requeue=True`` re-queues only while ``attempts < max_attempts``;
        at the bound the job is quarantined as terminal ``failed``
        (poison-job stop).  Returns the resulting status.  Zombie writes
        raise :class:`FencingError`."""
        err = (error or "")[:8000]
        if requeue:
            # H1 (2026-07-23): a requeued attempt must RE-EARN the
            # share_verified stamp — and the stale submit response /
            # result handle must not survive into the next attempt (a
            # later absorb/propagation would otherwise fan them out).
            set_sql = (
                "status = CASE WHEN attempts >= max_attempts "
                "THEN 'failed' ELSE 'queued' END, "
                "finished_at = CASE WHEN attempts >= max_attempts "
                f"THEN {self._now_sql} ELSE NULL END, "
                "error = :err, lease_owner = NULL, lease_expires_at = NULL, "
                "share_verified = :sv_no, response_json = NULL, "
                "previous_result_handle = COALESCE(result_handle, previous_result_handle), "
                "result_handle = NULL, reserved_bytes = 0"
            )
        else:
            set_sql = (f"status = 'failed', finished_at = {self._now_sql}, "
                       "error = :err, lease_owner = NULL, lease_expires_at = NULL")
        params: Dict[str, Any] = {"err": err}
        if requeue:
            params["sv_no"] = False
        n = self._fenced(job_id, token, set_sql, params, JobStatus.live_lease())
        if n != 1:
            raise FencingError(
                f"fail fenced out for job {job_id} (token {token}) — "
                "a newer lease owns this job; zombie write refused")
        job = self.get(job_id) or {}
        return job.get("status", JobStatus.FAILED.value)

    # ── cancellation (cooperative) ──────────────────────────────────────

    def cancel(self, job_id: str) -> str:
        """Cancel a job.  Returns the effective mode.

        Plain jobs (no single-flight involvement — the only shape that
        exists with the flag OFF): still queued → immediate terminal
        ``cancelled``; leased/running → ``cancel_requested`` (executors
        poll it between stages); terminal → no-op.  Byte-for-byte Phase-2
        behavior.

        Single-flight participant semantics (refcount — a cancel must
        never silently drop the OTHER participants):

          * follower cancel → detaches THAT follower only (terminal
            ``cancelled`` for its row); the shared execution continues for
            everyone else → ``"detached"``.  If it was the LAST live
            participant (initiator already detached), the now-abandoned
            leader execution is cancelled too.
          * leader cancel while live followers exist → the INITIATOR
            detaches (flag on the row; their waiter/stream sees it) but
            the execution CONTINUES for the followers →
            ``"initiator_detached"``.  Safe because attach requires an
            identical shareable rls_key: the result bytes are identical
            for every participant, so who "owns" the run is irrelevant to
            what anyone receives.  When the last follower later detaches,
            the abandoned execution is cancelled for real.

        NOTE: cancelling the underlying EXECUTION directly (the existing
        /api/executions cancel path) bypasses this refcount by design;
        the leader job then terminates ``cancelled`` and the propagation
        sweep detaches its followers back to independent execution — a
        degraded (re-run) but never-lost outcome."""
        with self._db.get_session() as session:
            row = session.execute(sa_text(
                "SELECT status, attached_to, initiator_detached "
                "FROM query_jobs WHERE id = :id"), {"id": job_id}).first()
            if row is None:
                raise JobNotFoundError(f"job {job_id} not found")
            status, attached_to = row[0], row[1]

            # ── follower detach ────────────────────────────────────────
            if status == JobStatus.ATTACHED.value and attached_to:
                n = session.execute(sa_text(f"""
                    UPDATE query_jobs
                    SET status = 'cancelled', finished_at = {self._now_sql},
                        error = 'follower detached (cancelled by its user)'
                    WHERE id = :id AND status = 'attached'
                """), {"id": job_id}).rowcount
                if n == 1:
                    self._cancel_leader_if_abandoned(session, attached_to)
                    return "detached"
                # raced into another state — fall through to plain handling

            # ── leader with live followers → initiator detaches only ───
            live_followers = session.execute(sa_text(
                "SELECT COUNT(*) FROM query_jobs "
                "WHERE attached_to = :id AND status = 'attached'"),
                {"id": job_id}).scalar() or 0
            if live_followers > 0:
                n = session.execute(sa_text("""
                    UPDATE query_jobs SET initiator_detached = :yes
                    WHERE id = :id AND status IN ('queued', 'leased', 'running')
                """), {"id": job_id, "yes": True}).rowcount
                if n == 1:
                    logger.info(
                        "[jobqueue] leader %s cancel → initiator detached; "
                        "execution continues for %d follower(s)",
                        job_id, live_followers)
                    return "initiator_detached"

            # ── plain job (Phase-2 semantics, unchanged) ───────────────
            res = session.execute(sa_text(f"""
                UPDATE query_jobs
                SET status = 'cancelled', finished_at = {self._now_sql},
                    error = COALESCE(error, 'cancelled before execution')
                WHERE id = :id AND status = 'queued'
            """), {"id": job_id})
            if res.rowcount == 1:
                return "cancelled"
            res = session.execute(sa_text("""
                UPDATE query_jobs SET cancel_requested = :yes
                WHERE id = :id AND status IN ('leased', 'running')
            """), {"id": job_id, "yes": True})
            if res.rowcount == 1:
                return "cancel_requested"
        job = self.get(job_id)
        if job is None:
            raise JobNotFoundError(f"job {job_id} not found")
        return f"noop:{job['status']}"

    def _cancel_leader_if_abandoned(self, session, leader_id: str) -> None:
        """Cancel a leader whose initiator detached AND whose last live
        follower just detached (refcount hit zero — nobody wants the
        result).  Runs inside the caller's session.  Conservative under
        races: two concurrent follower-detach transactions may each still
        see the other attached and skip — the execution then completes
        unwatched (wasted work, never a wrong result)."""
        row = session.execute(sa_text(
            "SELECT status, initiator_detached FROM query_jobs WHERE id = :id"),
            {"id": leader_id}).first()
        if row is None or not bool(row[1]):
            return
        remaining = session.execute(sa_text(
            "SELECT COUNT(*) FROM query_jobs "
            "WHERE attached_to = :id AND status = 'attached'"),
            {"id": leader_id}).scalar() or 0
        if remaining:
            return
        n = session.execute(sa_text(f"""
            UPDATE query_jobs
            SET status = 'cancelled', finished_at = {self._now_sql},
                error = 'cancelled: all single-flight participants detached'
            WHERE id = :id AND status = 'queued'
        """), {"id": leader_id}).rowcount
        if n != 1:
            session.execute(sa_text("""
                UPDATE query_jobs SET cancel_requested = :yes
                WHERE id = :id AND status IN ('leased', 'running')
            """), {"id": leader_id, "yes": True})
        logger.info("[jobqueue] leader %s abandoned by all participants — "
                    "cancelled", leader_id)

    def is_cancel_requested(self, job_id: str) -> bool:
        with self._db.get_session(read_only=True) as session:
            row = session.execute(sa_text(
                "SELECT cancel_requested, status FROM query_jobs WHERE id = :id"
            ), {"id": job_id}).first()
        if row is None:
            return False
        return bool(row[0]) or row[1] == JobStatus.CANCELLED.value

    def mark_cancelled(self, job_id: str, token: int, *, note: str = "") -> None:
        """Fenced terminal cancel from the lease holder (executor observed
        the cooperative flag and stopped)."""
        n = self._fenced(
            job_id, token,
            f"status = 'cancelled', finished_at = {self._now_sql}, "
            "error = :note, lease_owner = NULL, lease_expires_at = NULL",
            {"note": (note or "cancelled by request")[:2000]},
            JobStatus.live_lease(),
        )
        if n != 1:
            raise FencingError(
                f"mark_cancelled fenced out for job {job_id} (token {token})")

    # ── orphan reaper (idempotent; N concurrent reapers safe) ───────────

    def reap_orphans(self) -> Dict[str, int]:
        """Expired-lease sweep, DB-time only.

        * ``attempts < max_attempts`` → back to ``queued`` (lease cleared;
          the next claim bumps the fencing token past the zombie's).
        * ``attempts >= max_attempts`` → quarantined terminal ``failed``
          (poison-job stop) with a diagnostic note.

        Both statements are conditional UPDATEs keyed on
        ``lease_expires_at < DB-now`` — idempotent by construction, so
        concurrent reapers on N pods are safe."""
        now = self._now_sql
        with self._db.get_session() as session:
            # 2026-10-31 (phase 2): in plain words.  max_attempts = 1 is the
            # DECLARATION "not safe to run again by itself" (a write, or a
            # request the retry rule could not prove a read); above it the
            # job was already retried once on another pod and died again.
            quarantined = session.execute(sa_text(f"""
                UPDATE query_jobs SET
                    status = 'failed',
                    finished_at = {now},
                    error = CASE WHEN max_attempts <= 1 THEN :msg_once ELSE :msg_twice END,
                    lease_owner = NULL, lease_expires_at = NULL
                WHERE status IN ('leased', 'running')
                  AND kind <> 'fleet_slot'
                  AND lease_expires_at IS NOT NULL
                  AND lease_expires_at < {now}
                  AND attempts >= max_attempts
            """), {"msg_once": POD_DIED_NOT_RETRIED_MESSAGE,
                   "msg_twice": POD_DIED_TWICE_MESSAGE}).rowcount
            # H1 (2026-07-23): share_verified / response_json /
            # result_handle are cleared on requeue — the verified stamp is
            # re-earned per ATTEMPT, never inherited by the next claim (a
            # crashed-after-stamp leader must not fan an unverified
            # retry's, or an absorb's, result to followers).
            requeued = session.execute(sa_text(f"""
                UPDATE query_jobs SET
                    status = 'queued',
                    error = 'requeued by orphan reaper (lease expired, no heartbeat)',
                    lease_owner = NULL, lease_expires_at = NULL,
                    share_verified = :sv_no,
                    response_json = NULL,
                    previous_result_handle = COALESCE(result_handle, previous_result_handle),
                    result_handle = NULL,
                    reserved_bytes = 0
                WHERE status IN ('leased', 'running')
                  AND kind <> 'fleet_slot'
                  AND lease_expires_at IS NOT NULL
                  AND lease_expires_at < {now}
                  AND attempts < max_attempts
            """), {"sv_no": False}).rowcount
        if quarantined or requeued:
            logger.warning(
                "[jobqueue] orphan reaper: requeued=%d quarantined=%d",
                requeued, quarantined)
        # Phase 5 — resolve followers of terminal leaders (idempotent
        # conditional UPDATEs; N concurrent reapers safe).  Fail-open:
        # the reaper's core duty above must never die on this.
        try:
            self.propagate_single_flight()
        except Exception as exc:
            logger.warning("[jobqueue] single-flight propagation failed "
                           "(non-fatal, retried next sweep): %s", exc)
        return {"requeued": requeued, "quarantined": quarantined}

    # ── Phase 5 — single-flight follower propagation ────────────────────

    def propagate_single_flight(self) -> Dict[str, int]:
        """Resolve ``attached`` followers whose leader reached a terminal
        state.  Three idempotent, conditional UPDATEs (any number of
        concurrent sweepers is safe):

          1. leader ``succeeded`` AND ``share_verified`` → follower
             succeeds with the leader's result handle + relayed response
             (the ONLY path that fans a result out — hard gate 1's
             runtime enforcement);
          2. leader ``failed`` → follower fails with the leader's error
             ("on terminal failure all followers get the failure — never
             hang"; a requeued-for-retry leader is NOT terminal, so
             followers simply keep riding the retry);
          3. leader ``succeeded`` WITHOUT verification (executor crashed
             before the sandwich stamped it, or the API absorbed the job
             inline) or ``cancelled`` (cancel raced the attach) →
             follower is DETACHED back to an independent queued job under
             its own fail-closed key — it re-executes under its OWN
             captured identity; degraded, never lost, never served an
             unproven result.
        """
        with self._db.get_session(read_only=True) as session:
            any_attached = session.execute(sa_text(
                "SELECT 1 FROM query_jobs WHERE status = 'attached' LIMIT 1"
            )).first()
        if not any_attached:
            return {"succeeded": 0, "failed": 0, "detached": 0}
        now = self._now_sql
        with self._db.get_session() as session:
            succeeded = session.execute(sa_text(f"""
                UPDATE query_jobs SET
                    status = 'succeeded',
                    finished_at = {now},
                    result_handle = (SELECT l.result_handle FROM query_jobs l
                                     WHERE l.id = query_jobs.attached_to),
                    response_json = (SELECT l.response_json FROM query_jobs l
                                     WHERE l.id = query_jobs.attached_to)
                WHERE status = 'attached' AND EXISTS (
                    SELECT 1 FROM query_jobs l
                    WHERE l.id = query_jobs.attached_to
                      AND l.status = 'succeeded' AND l.share_verified = :yes)
            """), {"yes": True}).rowcount
            failed = session.execute(sa_text(f"""
                UPDATE query_jobs SET
                    status = 'failed',
                    finished_at = {now},
                    error = (SELECT l.error FROM query_jobs l
                             WHERE l.id = query_jobs.attached_to)
                WHERE status = 'attached' AND EXISTS (
                    SELECT 1 FROM query_jobs l
                    WHERE l.id = query_jobs.attached_to
                      AND l.status = 'failed')
            """)).rowcount
            detached = session.execute(sa_text("""
                UPDATE query_jobs SET
                    status = 'queued',
                    attached_to = NULL,
                    rls_key = 'failclosed:' || id,
                    rls_key_shareable = :no,
                    error = 'detached: leader finished unverified or was cancelled'
                WHERE status = 'attached' AND EXISTS (
                    SELECT 1 FROM query_jobs l
                    WHERE l.id = query_jobs.attached_to
                      AND (l.status = 'cancelled'
                           OR (l.status = 'succeeded'
                               AND l.share_verified = :no)))
            """), {"no": False}).rowcount
        if succeeded or failed or detached:
            logger.info("[jobqueue] single-flight propagation: succeeded=%d "
                        "failed=%d detached=%d", succeeded, failed, detached)
        return {"succeeded": succeeded, "failed": failed, "detached": detached}

    # ── Phase 5 — fleet admission view + shared-result grant ────────────

    def fleet_inflight(self) -> Dict[str, Any]:
        """Fleet-wide inflight accounting — COUNT/SUM over live-lease job
        rows (no independent counters: the reaper releasing a lease IS the
        slot release; drift is structurally impossible)."""
        now = self._now_sql
        live = self._LIVE_LEASE_PRED.format(now=now)
        with self._db.get_session(read_only=True) as session:
            total = session.execute(sa_text(
                f"SELECT COUNT(*), COALESCE(SUM(admission_cost_mb), 0) "
                f"FROM query_jobs WHERE {live}")).first()
            lanes = session.execute(sa_text(
                f"SELECT lane, COUNT(*), COALESCE(SUM(admission_cost_mb), 0) "
                f"FROM query_jobs WHERE {live} GROUP BY lane")).fetchall()
            users = session.execute(sa_text(
                f"SELECT enqueued_by, COUNT(*) "
                f"FROM query_jobs WHERE {live} GROUP BY enqueued_by")).fetchall()
            queued = session.execute(sa_text(
                "SELECT COUNT(*) FROM query_jobs WHERE status = 'queued' "
                "AND kind <> 'fleet_slot'"
            )).scalar() or 0
            attached = session.execute(sa_text(
                "SELECT COUNT(*) FROM query_jobs WHERE status = 'attached'"
            )).scalar() or 0
            # Fleet-admission slot ledger (core.jobqueue.fleet_admission):
            # live running slots + fresh waiters per scope.  Additive
            # observability — empty dict whenever the flag is off.
            slot_rows = session.execute(sa_text(
                f"SELECT plan_hash, status, COUNT(*) FROM query_jobs "
                f"WHERE kind = 'fleet_slot' AND lease_expires_at > {now} "
                f"GROUP BY plan_hash, status")).fetchall()
        fleet_slots: Dict[str, Any] = {}
        for scope, sstatus, n in slot_rows:
            d = fleet_slots.setdefault(scope, {"running": 0, "waiting": 0})
            d["running" if sstatus == "running" else "waiting"] += int(n)
        return {
            "running": int(total[0] or 0),
            "inflight_cost_mb": int(total[1] or 0),
            "queued": int(queued),
            "attached_followers": int(attached),
            "by_lane": {r[0]: {"running": int(r[1]), "cost_mb": int(r[2] or 0)}
                        for r in lanes},
            "by_user": {r[0]: int(r[1]) for r in users},
            "fleet_slots": fleet_slots,
        }

    def has_shared_result_grant(self, execution_id: str, username: str) -> bool:
        """Phase 5 — may ``username`` read the results of ``execution_id``
        because they are (or were) a single-flight follower of the job
        that produced it?

        True ONLY when a follower row for this user rides a leader that
        (a) produced this exact result handle, (b) reached ``succeeded``,
        and (c) is ``share_verified`` — the executor PROVED the rls_key
        matched enforcement.  Anything less (unverified, failed, detached,
        different user) → False.  Never raises (callers treat errors as
        deny — fail closed)."""
        if not execution_id or not username:
            return False
        try:
            with self._db.get_session(read_only=True) as session:
                row = session.execute(sa_text("""
                    SELECT 1 FROM query_jobs f
                    JOIN query_jobs l ON l.id = f.attached_to
                    WHERE f.enqueued_by = :username
                      AND f.status IN ('attached', 'succeeded')
                      AND l.status = 'succeeded'
                      AND l.share_verified = :yes
                      AND l.result_handle = :execution_id
                    LIMIT 1
                """), {"username": username, "execution_id": execution_id,
                       "yes": True}).first()
            return row is not None
        except Exception as exc:
            logger.warning("[jobqueue] shared-result grant check failed "
                           "(deny): %s", exc)
            return False

    def latest_passport_for_plan(self, plan_hash: str, *, rls_key: str = "",
                                 rls_shareable: bool = False,
                                 username: str = "", scoped: bool = False) -> Optional[str]:
        """Phase 5 admission pricing — the most recent SUCCEEDED job's
        passport for this plan_hash (history-based estimate, Trino HBO
        style).  Returns the raw passport JSON or None.

        ``scoped=True`` (the query-pod pricer, 2026-10-31) reads only the
        caller's calibration scope (see ``_history_scope_sql``): the island a
        passport recorded depends on the predicates row security added, so a
        wide-scope user's passport must not size a narrow-scope user's run.
        The admission pricer keeps the plan-wide read it always had."""
        if not plan_hash:
            return None
        pred, params = "1 = 1", {}
        if scoped:
            scope = self._history_scope_sql(rls_key, rls_shareable, username)
            if scope is None:
                return None
            pred, params = scope
        with self._db.get_session(read_only=True) as session:
            row = session.execute(sa_text(f"""
                SELECT passport_json FROM query_jobs
                WHERE plan_hash = :plan_hash
                  AND passport_json IS NOT NULL
                  AND status = 'succeeded'
                  AND {pred}
                ORDER BY created_at DESC
                LIMIT 1
            """), {"plan_hash": plan_hash, **params}).first()
        return row[0] if row else None

    # ── calibration history, scoped to who ran it (2026-10-31) ──────────
    #
    # Security review of phase 1: history keyed on plan_hash ALONE let one
    # user's run price another's.  Under row security the same plan reads
    # very different data per identity -- a wide-scope user's peak (or an
    # out-of-memory ratchet) priced a narrow-scope user's run up, even to a
    # refusal.  The history a run may read is therefore ITS OWN scope:
    #
    #   * the same user's earlier runs of the plan (``enqueued_by``) --
    #     identity decides the row-security scope, so one user's history
    #     is always that user's data;
    #   * other users' runs ONLY under the SAME SHAREABLE rls_key -- an
    #     identical shareable key means identical enforced SQL (the
    #     single-flight theorem), so the data read was the same.
    #
    # No user and no shareable key = no history (unknown is not shared).
    # A fail-closed per-job key never matches anyone (unique by
    # construction), so such a run reads only its own user's history.

    @staticmethod
    def _history_scope_sql(rls_key: str, rls_shareable: bool,
                           username: str) -> Optional[tuple]:
        """``(predicate, params)`` for the calibration scope, or None when
        nothing may be read (no identity, no shareable key)."""
        parts, params = [], {}
        if username:
            parts.append("enqueued_by = :hist_user")
            params["hist_user"] = str(username)
        if rls_shareable and rls_key:
            parts.append("(rls_key = :hist_rk AND rls_key_shareable = :hist_yes)")
            params["hist_rk"] = str(rls_key)
            params["hist_yes"] = True
        if not parts:
            return None
        return "(" + " OR ".join(parts) + ")", params

    def latest_peak_record_for_plan(self, plan_hash: str, *, rls_key: str = "",
                                    rls_shareable: bool = False,
                                    username: str = "") -> Optional[Dict[str, Any]]:
        """The latest finished run of this plan IN THIS SCOPE that recorded a
        measured peak: ``{"peak_bytes", "status", "price_bytes",
        "reserved_bytes"}``.  ``failed`` rows count too -- an over-budget run
        DuckDB stopped records at least its reservation, so the next price
        goes UP (and the pricer bounds that step by ``price_bytes``).  None =
        nothing measured in this scope, or no scope at all."""
        if not plan_hash:
            return None
        scope = self._history_scope_sql(rls_key, rls_shareable, username)
        if scope is None:
            return None
        pred, params = scope
        with self._db.get_session(read_only=True) as session:
            row = session.execute(sa_text(f"""
                SELECT actual_peak_bytes, status, price_bytes, reserved_bytes FROM query_jobs
                WHERE plan_hash = :plan_hash
                  AND actual_peak_bytes IS NOT NULL AND actual_peak_bytes > 0
                  AND status IN ('succeeded', 'failed')
                  AND {pred}
                ORDER BY created_at DESC, id DESC
                LIMIT 1
            """), {"plan_hash": plan_hash, **params}).first()
        if not row or not row[0]:
            return None
        return {"peak_bytes": int(row[0]), "status": str(row[1] or ""),
                "price_bytes": int(row[2] or 0), "reserved_bytes": int(row[3] or 0)}

    def latest_peak_for_plan(self, plan_hash: str, *, rls_key: str = "",
                             rls_shareable: bool = False, username: str = "") -> Optional[int]:
        """2026-10-31 — the most recently recorded MEASURED peak of this
        plan in the caller's scope (see ``latest_peak_record_for_plan``).
        None = never measured in that scope."""
        rec = self.latest_peak_record_for_plan(plan_hash, rls_key=rls_key,
                                               rls_shareable=rls_shareable, username=username)
        return rec["peak_bytes"] if rec else None

    def reserved_bytes_on_host(self, host: str) -> int:
        """2026-10-31 — the bytes the pod ``host`` holds in LIVE leases:
        ``SUM(reserved_bytes)`` over its leased / running jobs whose lease
        has not expired.  THE reservation ledger -- derived from rows every
        time, never a counter, so a dead pod's bytes return with its leases.
        Raises when the table cannot be read (unknown is not zero)."""
        if not host:
            return 0
        with self._db.get_session(read_only=True) as session:
            v = session.execute(sa_text(
                f"SELECT {self._held_on_host_sql()}"), {"host": host}).scalar()
        return int(v or 0)

    def queue_position(self, job_id: str) -> Optional[int]:
        """2026-10-31 — "2nd in line": 1 + the queued jobs of the same size
        (or, for an unsized job, of the whole queue) ahead of this one in
        claim order (priority, then age).  None when the job is not queued."""
        with self._db.get_session(read_only=True) as session:
            me = session.execute(sa_text(
                "SELECT status, pod_class, priority, created_at FROM query_jobs "
                "WHERE id = :id"), {"id": job_id}).first()
            if me is None or me[0] != JobStatus.QUEUED.value:
                return None
            ahead = session.execute(sa_text("""
                SELECT COUNT(*) FROM query_jobs
                WHERE status = 'queued' AND kind <> 'fleet_slot'
                  AND pod_class = :pc AND id <> :id
                  AND (priority < :prio
                       OR (priority = :prio AND created_at < :created))
            """), {"pc": me[1] or "", "id": job_id, "prio": me[2],
                   "created": me[3]}).scalar() or 0
        return int(ahead) + 1

    def fail_sized_jobs_without_a_pod(self, *, alive_by_class: Dict[str, Optional[int]],
                                      max_wait_seconds: float) -> List[str]:
        """2026-10-31 (phase 2): a SIZED run queued longer than
        ``max_wait_seconds`` while NO pod of its size is alive is FAILED with
        the reason -- never left to wait silently (design §5b).  A size whose
        presence is UNKNOWN (None) is left alone: unknown is not zero.
        Idempotent conditional UPDATE; N sweepers are safe."""
        dead_sizes = sorted(pc for pc, n in (alive_by_class or {}).items() if n == 0)
        if not dead_sizes:
            return []
        from core.query_pods.presence import no_pod_sentence
        wait = max(1, int(max_wait_seconds))
        if self._is_pg:
            age_pred = ("created_at < ((now() at time zone 'utc') "
                        "- make_interval(secs => :wait))")
            params: Dict[str, Any] = {"wait": wait}
        else:
            age_pred = "created_at < datetime('now', :wait_mod)"
            params = {"wait_mod": f"-{wait} seconds"}
        failed: List[str] = []
        with self._db.get_session() as session:
            for pc in dead_sizes:
                rows = session.execute(sa_text(f"""
                    SELECT id FROM query_jobs
                    WHERE status = 'queued' AND kind <> 'fleet_slot'
                      AND pod_class = :pc AND {age_pred}
                """), {"pc": pc, **params}).fetchall()
                for (jid,) in rows:
                    n = session.execute(sa_text(f"""
                        UPDATE query_jobs SET status = 'failed', finished_at = {self._now_sql},
                            error = :msg
                        WHERE id = :id AND status = 'queued'
                    """), {"id": jid, "msg": no_pod_sentence(pc, wait)}).rowcount
                    if n == 1:
                        failed.append(jid)
        if failed:
            logger.warning("[jobqueue] %d sized run(s) failed: no query pod of their size came up "
                           "within %ss (sizes %s)", len(failed), wait, ", ".join(dead_sizes))
        return failed

    def expire_dead_local_leases(self, host: str, alive_pids) -> int:
        """Startup hygiene for a restarted executor pod: force-expire
        leases recorded for THIS host whose executor pid no longer exists,
        then let :meth:`reap_orphans` handle requeue/quarantine uniformly.
        ``alive_pids`` is a set of live pids on this host."""
        with self._db.get_session() as session:
            rows = session.execute(sa_text("""
                SELECT id, executor_pid FROM query_jobs
                WHERE executor_host = :host AND status IN ('leased', 'running')
            """), {"host": host}).fetchall()
            dead = [r[0] for r in rows
                    if r[1] is not None and int(r[1]) not in alive_pids]
            expired = 0
            if dead:
                past = ("((now() at time zone 'utc') - make_interval(secs => 1))"
                        if self._is_pg else "datetime('now', '-1 seconds')")
                for jid in dead:
                    expired += session.execute(sa_text(f"""
                        UPDATE query_jobs SET lease_expires_at = {past}
                        WHERE id = :id AND status IN ('leased', 'running')
                    """), {"id": jid}).rowcount
        if expired:
            logger.warning(
                "[jobqueue] expired %d dead lease(s) on host %s (restarted "
                "executor cleanup)", expired, host)
        return expired

    # ── status surface (API side) ───────────────────────────────────────

    def get(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Full job view (status + response relay).  Never includes the
        identity/rls payloads — those are executor-side data, not API
        response material."""
        with self._db.get_session(read_only=True) as session:
            row = session.query(QueryJob).filter(QueryJob.id == job_id).first()
            if row is None:
                return None
            d = row.to_dict()
            d["response_json"] = row.response_json
        # 2026-10-31: a sized run still in line says where it stands -- and
        # (phase 2) whether any pod of its size is alive to take it.
        if d.get("status") == JobStatus.QUEUED.value and d.get("pod_class"):
            try:
                from core.query_pods.budget import waiting_sentence
                from core.query_pods.presence import alive_count, no_pod_sentence
                d["position"] = self.queue_position(job_id)
                d["waiting"] = waiting_sentence(d["position"], d["pod_class"])
                n_alive = alive_count(self._db, d["pod_class"])
                d["pods_alive"] = n_alive
                if n_alive == 0:
                    d["waiting"] = no_pod_sentence(d["pod_class"])
            except Exception as exc:
                logger.debug("[jobqueue] position unreadable for %s: %s", job_id, exc)
        return d

    def list_for_user(self, username: str, limit: int = 50) -> List[Dict[str, Any]]:
        with self._db.get_session(read_only=True) as session:
            rows = (session.query(QueryJob)
                    .filter(QueryJob.enqueued_by == username)
                    .order_by(QueryJob.created_at.desc())
                    .limit(max(1, min(int(limit), 200))).all())
            return [r.to_dict() for r in rows]

    def is_stranded(self, job_id: str) -> bool:
        """M3 (2026-07-23) — age-based "no executor progress" check: the
        job is still ``queued`` past ``jobqueue.stranded_after_seconds``
        (default 300) — i.e. queue_mode is armed but no executor has
        picked it up (no executor role deployed / all executors down).
        DB-time on BOTH sides (clock-skew rule).  Never raises — callers
        surface it as an alarm, not a correctness dependency."""
        try:
            threshold = max(1, self._cfg_int("stranded_after_seconds", 300))
            if self._is_pg:
                age_pred = ("created_at < ((now() at time zone 'utc') "
                            "- make_interval(secs => :thr))")
                params: Dict[str, Any] = {"id": job_id, "thr": threshold}
            else:
                age_pred = "created_at < datetime('now', :thr_mod)"
                params = {"id": job_id, "thr_mod": f"-{threshold} seconds"}
            with self._db.get_session(read_only=True) as session:
                row = session.execute(sa_text(f"""
                    SELECT 1 FROM query_jobs
                    WHERE id = :id AND status = 'queued' AND {age_pred}
                """), params).first()
            return row is not None
        except Exception as exc:
            logger.warning("[jobqueue] stranded check failed for %s: %s",
                           job_id, exc)
            return False

    def counts_by_status(self) -> Dict[str, int]:
        with self._db.get_session(read_only=True) as session:
            rows = session.execute(sa_text(
                "SELECT status, COUNT(*) FROM query_jobs GROUP BY status"
            )).fetchall()
        return {r[0]: int(r[1]) for r in rows}

    def demand_by_class(self, classes) -> Dict[str, Dict[str, Optional[int]]]:
        """2026-10-29 -- per query-pod size: the runs it holds (queued +
        leased + running; THE number both scalers divide by runs-per-pod --
        ``core.query_pods.demand.in_flight_sql`` is the same predicate KEDA's
        trigger renders), how many are still queued, and how long the oldest
        queued one has waited (DB time).  Raises when the table cannot be
        read: unknown demand must never read as no demand."""
        from core.query_pods.demand import IN_FLIGHT_STATUSES, NOT_A_RUN_KIND
        names = [str(c) for c in classes]
        if not names:
            return {}
        if self._is_pg:
            age = "EXTRACT(EPOCH FROM ((now() at time zone 'utc') - MIN(created_at)))"
        else:
            age = "(julianday('now') - julianday(MIN(created_at))) * 86400"
        statuses = ", ".join(f"'{s}'" for s in IN_FLIGHT_STATUSES)
        out: Dict[str, Dict[str, Optional[int]]] = {
            n: {"in_flight": 0, "queued": 0, "oldest_wait_s": None} for n in names}
        with self._db.get_session(read_only=True) as session:
            rows = session.execute(sa_text(
                f"SELECT pod_class, COUNT(*) FROM query_jobs WHERE status IN ({statuses}) "
                f"AND kind <> '{NOT_A_RUN_KIND}' AND pod_class IN :names GROUP BY pod_class"
            ).bindparams(bindparam("names", expanding=True)), {"names": names}).fetchall()
            for cls, n in rows:
                out[str(cls)]["in_flight"] = int(n)
            rows = session.execute(sa_text(
                f"SELECT pod_class, COUNT(*), {age} FROM query_jobs WHERE status = 'queued' "
                f"AND kind <> '{NOT_A_RUN_KIND}' AND pod_class IN :names GROUP BY pod_class"
            ).bindparams(bindparam("names", expanding=True)), {"names": names}).fetchall()
            for cls, n, wait in rows:
                out[str(cls)]["queued"] = int(n)
                out[str(cls)]["oldest_wait_s"] = None if wait is None else max(0, int(float(wait)))
        return out

    # ── API-side fail-open absorb (inline fallback) ─────────────────────

    def absorb_for_inline(self, job_id: str, owner: str) -> Optional[ClaimedJob]:
        """Claim a SPECIFIC still-queued job so the API pod can run it
        inline (fail-open when no executor picked it up in time).  Uses the
        same fencing discipline as a normal claim.  Returns None when the
        job is no longer queued (an executor got it — do NOT run inline)."""
        lease_seconds = self._cfg_int("lease_seconds", 120)
        with self._db.get_session() as session:
            # H1 (2026-07-23): the absorb clears any STALE verified stamp /
            # response / handle a previous attempt left behind — the
            # absorbed row's inline marker must never fan out to followers.
            res = session.execute(sa_text(f"""
                UPDATE query_jobs SET
                    status = 'running',
                    lease_owner = :owner,
                    fencing_token = fencing_token + 1,
                    attempts = attempts + 1,
                    lease_expires_at = {self._lease_expiry_sql()},
                    heartbeat_at = {self._now_sql},
                    started_at = COALESCE(started_at, {self._now_sql}),
                    executor_pid = :pid,
                    executor_host = :host,
                    share_verified = :sv_no,
                    response_json = NULL, result_handle = NULL,
                    reserved_bytes = 0
                WHERE id = :id AND status = 'queued'
            """), {"owner": owner, "id": job_id, "pid": os.getpid(),
                   "host": socket.gethostname(), "sv_no": False,
                   **self._lease_params(lease_seconds)})
            if res.rowcount != 1:
                return None
            row = session.execute(sa_text(
                f"SELECT {self._CLAIM_COLS} FROM query_jobs WHERE id = :id"
            ), {"id": job_id}).mappings().first()
        return self._row_to_claimed(row) if row else None

    # ── internals ───────────────────────────────────────────────────────

    @staticmethod
    def _cfg_int(key: str, fallback: int) -> int:
        try:
            from core.config import get as _cfg_get
            return int(_cfg_get("jobqueue", key, fallback) or fallback)
        except Exception:
            return fallback


# ── Module singleton ────────────────────────────────────────────────────

_queue: Optional[JobQueue] = None
_queue_lock = threading.Lock()


def get_job_queue(db_manager=None) -> JobQueue:
    """Process-wide JobQueue.  First call must (directly or via
    ``core.database.get_db_manager``-style wiring) provide a
    DatabaseManager; later calls reuse the singleton.

    L2-C3 (2026-07-25 red-team): passing a DIFFERENT DatabaseManager once
    the singleton exists used to be SILENTLY IGNORED — the caller believed
    it had rebound the queue to its manager but every operation still hit
    the old DB (the root of cross-module test pollution and a prod footgun
    on any future re-init path).  Now an explicit different manager
    REBINDS the singleton (with a warning); passing None or the same
    manager reuses it unchanged."""
    global _queue
    if _queue is None:
        with _queue_lock:
            if _queue is None:
                if db_manager is None:
                    db_manager = _default_db_manager()
                _queue = JobQueue(db_manager)
                return _queue
    if db_manager is not None and db_manager is not _queue._db:
        with _queue_lock:
            if db_manager is not _queue._db:
                logger.warning(
                    "get_job_queue: rebinding singleton to a DIFFERENT "
                    "DatabaseManager (old=%r new=%r)",
                    _queue._db, db_manager)
                _queue = JobQueue(db_manager)
    return _queue


def reset_job_queue_for_tests() -> None:
    global _queue
    with _queue_lock:
        _queue = None


def _default_db_manager():
    """Resolve the app-wide DatabaseManager without importing main
    eagerly.  Raises QueueError when unavailable (callers fail open)."""
    try:
        import main as _main
        dbm = getattr(_main, "db_manager", None)
        if dbm is not None:
            return dbm
    except Exception:
        pass
    raise QueueError(
        "no DatabaseManager available for JobQueue — pass one explicitly "
        "(get_job_queue(db_manager=...)) or initialize the app first")
