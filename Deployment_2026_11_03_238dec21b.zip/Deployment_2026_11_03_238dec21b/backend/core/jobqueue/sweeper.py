"""The queue sweep every server process runs (query pods phase 2, 2026-10-31).

Before this, only an EXECUTOR reaped expired leases.  An API pod (role api,
no executor) with every query pod dead therefore never acted on a lease that
had expired: the run sat "running" until a pod came back.  Worse than today
-- so the sweep now rides a lifespan periodic thread in EVERY process whose
queue mode is armed, exactly like the checkpoint heartbeat:

  * ``JobQueue.reap_orphans`` -- an expired lease is re-queued (a declared
    read with an attempt left) or failed with the reason; idempotent
    conditional UPDATEs, N sweepers safe;
  * ``JobQueue.fail_sized_jobs_without_a_pod`` -- a SIZED run queued past
    ``query_pods.no_pod_fail_seconds`` while no pod of its size is alive
    (``core/query_pods/presence.py``) is failed with the reason, never left
    to wait silently.  Presence UNKNOWN leaves it alone.

Declared in ``core/background_job_contract.py`` (``jobqueue_sweeper``,
per process) so run-now and the ledger see it.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

_thread: Optional[threading.Thread] = None
_state: Dict[str, Any] = {"last_run_at": None, "runs": 0, "requeued_total": 0,
                          "quarantined_total": 0, "no_pod_failed_total": 0, "last_error": None}


def sweep_once(db_manager) -> Dict[str, Any]:
    """One sweep: reap, then fail the sized runs no pod can ever take."""
    out: Dict[str, Any] = {"status": "ok", "requeued": 0, "quarantined": 0, "no_pod_failed": []}
    if db_manager is None:
        return {"status": "skipped", "reason": "no database manager"}
    from core.jobqueue.queue import JobQueue
    queue = JobQueue(db_manager)
    try:
        reaped = queue.reap_orphans()
        out["requeued"] = int(reaped.get("requeued", 0))
        out["quarantined"] = int(reaped.get("quarantined", 0))
        from core.query_pods import budget as _budget, presence
        settings = _budget.settings_or_none()
        if settings is not None and settings.classes:
            alive = {c.name: presence.alive_count(db_manager, c.name) for c in settings.classes}
            out["pods_alive"] = alive
            out["no_pod_failed"] = queue.fail_sized_jobs_without_a_pod(
                alive_by_class=alive, max_wait_seconds=presence.no_pod_fail_seconds())
        _state["last_run_at"] = time.time()
        _state["runs"] += 1
        _state["requeued_total"] += out["requeued"]
        _state["quarantined_total"] += out["quarantined"]
        _state["no_pod_failed_total"] += len(out["no_pod_failed"])
        _state["last_error"] = None
    except Exception as exc:  # noqa: BLE001 -- one bad pass never ends the sweep
        _state["last_error"] = f"{type(exc).__name__}: {exc}"[:300]
        out = {"status": "error", "reason": _state["last_error"], "requeued": 0,
               "quarantined": 0, "no_pod_failed": []}
        logger.warning("[jobqueue] sweep failed: %s", exc)
    return out


def sweep_tick(db_manager) -> Dict[str, Any]:
    """The thread's body and the run-now: one sweep, recorded in the ledger."""
    t0 = time.monotonic()
    out = sweep_once(db_manager)
    try:
        from core.background_job_contract import record_event_tick
        record_event_tick("jobqueue_sweeper", out, duration_s=time.monotonic() - t0)
    except Exception as exc:  # noqa: BLE001
        logger.debug("jobqueue sweeper ledger write skipped: %s", exc)
    return out


def interval_seconds() -> float:
    try:
        from core.config import get as _cfg_get
        return max(5.0, float(_cfg_get("jobqueue", "reap_interval_seconds", 30) or 30))
    except Exception:
        return 30.0


def start_queue_sweeper_if_armed(db_manager) -> bool:
    """Start this process's sweep thread when ``industrialization.queue_mode``
    is armed (idempotent; through core/lifespan_threads.py so it stops with
    the lifespan).  Never raises."""
    global _thread
    try:
        from core.industrialization import is_enabled
        if not is_enabled("queue_mode"):
            return False
        if _thread is not None and _thread.is_alive():
            return True
        from core import lifespan_threads as _lt
        _thread = _lt.start_periodic("jobqueue-sweeper", lambda: sweep_tick(db_manager),
                                     every=interval_seconds())
        logger.info("[jobqueue] sweeper started (every %.0fs: expired leases, sized runs with no pod)",
                    interval_seconds())
        return True
    except Exception as exc:  # noqa: BLE001
        logger.warning("[jobqueue] sweeper not started (non-fatal): %s", exc)
        return False


def sweeper_status() -> Dict[str, Any]:
    return {"running": bool(_thread is not None and _thread.is_alive()),
            "interval_seconds": interval_seconds(), **_state}


__all__ = ["interval_seconds", "start_queue_sweeper_if_armed", "sweep_once", "sweep_tick",
           "sweeper_status"]
