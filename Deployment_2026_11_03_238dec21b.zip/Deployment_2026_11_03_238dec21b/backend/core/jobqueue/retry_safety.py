"""Retry safety is a DECLARATION, not a default (CLAUDE.md §4; query pods
phase 2, 2026-10-31).

When a query pod dies its leases expire and the reaper re-queues the job
while ``attempts < max_attempts``.  That is right for a READ -- running the
same SELECT again on another pod gives the same answer and the fencing token
keeps the dead pod's late writes out -- and wrong for anything else: OG's
``RETRY_SAFE`` once defaulted true and a non-idempotent step was retried into
50M duplicate rows.  So the declaration is made ONCE, at enqueue, as the
job's ``max_attempts``:

  * a request this module can PROVE is a read -> ``jobqueue.max_attempts``
    (2: one retry on another pod);
  * anything else -- a statement that writes, a statement this module cannot
    classify, a shape it does not know -> 1: the reaper fails it at lease
    expiry with the reason and the user presses Run again.

Unknown = unsafe.  A builder request (``query_config``) is a read by
construction (the builder only renders SELECTs).
"""
from __future__ import annotations

import re
from typing import Any, Dict, Optional, Tuple

#: statements that only read
_READ_HEADS = ("select", "with", "show", "describe", "desc", "explain", "values", "table")
#: a word that, at the top level, makes the statement a write (or unknown)
_WRITE_WORDS = frozenset((
    "insert", "update", "delete", "merge", "create", "drop", "alter", "truncate", "copy",
    "call", "exec", "execute", "grant", "revoke", "replace", "upsert", "load", "attach",
    "detach", "install", "set", "reset", "pragma", "begin", "commit", "rollback", "vacuum",
    "analyze", "import", "export", "into",
))
_COMMENT_RE = re.compile(r"--[^\n]*|/\*.*?\*/", re.S)
_STRING_RE = re.compile(r"'(?:[^']|'')*'|\"(?:[^\"]|\"\")*\"")
_WORD_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def _bare(sql: str) -> str:
    """The SQL without comments and with string literals blanked, so a word
    inside a literal ('delete me') cannot classify the statement."""
    s = _COMMENT_RE.sub(" ", sql)
    return _STRING_RE.sub("''", s)


def classify_sql(sql: Optional[str]) -> Tuple[bool, str]:
    """``(is_read, reason)`` for one SQL text.  Fail-closed: anything not
    proven a read is not a read."""
    if not isinstance(sql, str) or not sql.strip():
        return False, "no SQL"
    bare = _bare(sql)
    statements = [p for p in bare.split(";") if p.strip()]
    if not statements:
        return False, "no statement"
    if len(statements) > 1:
        return False, "more than one statement"
    words = [w.lower() for w in _WORD_RE.findall(statements[0])]
    if not words:
        return False, "no words"
    if words[0] not in _READ_HEADS:
        return False, f"starts with {words[0].upper()}"
    hit = next((w for w in words if w in _WRITE_WORDS), None)
    if hit is not None:
        return False, f"contains {hit.upper()}"
    return True, "a read"


def is_read_only_request(payload: Dict[str, Any]) -> Tuple[bool, str]:
    """``(is_read, reason)`` for one execute request payload (as enqueued)."""
    if not isinstance(payload, dict):
        return False, "not a request"
    sqls = [payload.get("raw_sql"), payload.get("secondary_raw_sql")]
    sqls = [s for s in sqls if isinstance(s, str) and s.strip()]
    if sqls:
        for s in sqls:
            ok, why = classify_sql(s)
            if not ok:
                return False, why
        return True, "a read"
    qc = payload.get("query_config")
    if isinstance(qc, dict) and qc:
        return True, "a builder query (reads by construction)"
    return False, "unknown request shape"


def max_attempts_for(payload: Dict[str, Any], *, read_attempts: int) -> Tuple[int, str]:
    """THE declaration: how many times this job may be claimed.  A proven
    read gets ``read_attempts`` (the configured bound); anything else 1."""
    ok, why = is_read_only_request(payload)
    if ok:
        return max(1, int(read_attempts)), why
    return 1, why


__all__ = ["classify_sql", "is_read_only_request", "max_attempts_for"]
