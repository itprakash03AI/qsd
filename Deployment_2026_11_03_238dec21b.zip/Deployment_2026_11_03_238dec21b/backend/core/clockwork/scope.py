"""The scheduler-only scope — ONE predicate, read by every enforcer.

Requirement (2026-09-10): "if someone has access for schedule they see
scheduler only."  A principal holding the ``scheduler`` role and nothing
wider may reach the Clockwork surface and the handful of bootstrap routes a
signed-in browser needs, and nothing else.

WHY ONE MODULE.  The frontend's ``RoleGuard`` is presentation only and
``super_admin`` bypasses it; the admin-controlled ``component_visibility``
map is per-role data an admin may edit; and an API route is reachable with
``curl`` whatever the nav shows.  Three places could each hold a copy of
"what may a scheduler-scoped user see", and three copies drift.  So the
rule is decided HERE and consumed three ways:

  * ``main.py``'s scope middleware refuses a scoped principal on any
    ``/api/*`` path outside :data:`SCOPED_API_PREFIXES` — the backend
    enforces this independently of the frontend;
  * ``GET /api/app-settings`` passes its resolved ``component_visibility``
    through :func:`apply_scope_to_visibility`, so the nav the browser draws
    is the same verdict the API applies;
  * ``GET /api/clockwork/access`` publishes :func:`access_payload` so the
    frontend can READ the verdict instead of re-deriving it.

Nothing here reads ``auth.type``.  Auth MODE must never gate scope — the
``api/schedules_api.py`` pattern this repo already paid for.  Under a
genuine ``auth.type=none`` the guest is an admin and is simply not scoped.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Optional

from core.roles import (
    ROLE_ADMIN, ROLE_ANALYST, ROLE_SCHEDULER, ROLE_SUPER_ADMIN,
    is_admin_like, is_scheduler_scoped, is_support,
)

#: The visibility key the nav and the admin matrix use for the scheduler.
#: Sub-features use dot-notation under it (``clockwork.jobs`` ...) and the
#: existing parent cascade in ``get_ui_visibility_resolved`` applies.
SCHEDULER_COMPONENT_KEY = "clockwork"

#: API path prefixes a scheduler-scoped principal may reach.  Everything a
#: signed-in browser needs to BE signed in, plus the scheduler itself.
#: Prefix-matched on the path only (never the query string).
SCOPED_API_PREFIXES: tuple = (
    "/api/clockwork",          # the scheduler
    "/auth",                   # login / logout / me / config
    "/api/auth",
    "/api/app-settings",       # the visibility map the nav reads
    "/api/user-preferences",   # theme, layout — per-user, harmless
    "/api/notifications",      # the bell in the header
    "/health",                 # probes
    "/api/health",
    "/metrics",
)

#: Only these path roots are ENFORCED.  The SPA's static files and the
#: websocket upgrade are not API surface and are not narrowed here.
_ENFORCED_ROOTS: tuple = ("/api/", "/graphql")

#: Roles that may CREATE and EDIT jobs (subject to per-job entitlement).
#: viewer and support are read-only everywhere else in the product and
#: stay read-only here.
AUTHOR_ROLES: frozenset = frozenset({
    ROLE_SUPER_ADMIN, ROLE_ADMIN, ROLE_ANALYST, ROLE_SCHEDULER,
})

SCOPE_FULL = "full"
SCOPE_SCHEDULER_ONLY = "scheduler_only"
SCOPE_NONE = "none"


def _role(user: Optional[Mapping[str, Any]]) -> str:
    return str((user or {}).get("role", "") or "").lower()


def path_allowed_for_scoped(path: str) -> bool:
    """May a scheduler-scoped principal reach ``path``?

    True for anything outside the enforced roots (static files) and for
    every prefix in :data:`SCOPED_API_PREFIXES`.  A prefix match is on a
    segment boundary — ``/api/clockworkx`` is not ``/api/clockwork``.
    """
    p = (path or "").split("?", 1)[0]
    if not p.startswith(_ENFORCED_ROOTS):
        return True
    for prefix in SCOPED_API_PREFIXES:
        if p == prefix or p.startswith(prefix + "/"):
            return True
    return False


def scope_decision(user: Optional[Mapping[str, Any]], path: str) -> Dict[str, Any]:
    """The middleware's answer: ``{"allowed": bool, "reason": str}``.

    Pure over ``user`` and ``path`` so the middleware can be tested as a
    function AND the HTTP path can be tested end-to-end.
    """
    if not is_scheduler_scoped(user):
        return {"allowed": True, "reason": "not_scheduler_scoped"}
    if path_allowed_for_scoped(path):
        return {"allowed": True, "reason": "scheduler_surface"}
    return {
        "allowed": False,
        "reason": (
            f"role '{ROLE_SCHEDULER}' is scoped to the scheduler: "
            f"{path} is outside it"
        ),
    }


def can_author(user: Optional[Mapping[str, Any]]) -> bool:
    """May this principal create / edit job definitions at all?
    (Per-job entitlement narrows further; this is the floor.)

    2026-10-31 -- tool entitlement: the floor is the capability
    ``clockwork.author`` (``core.tool_entitlement.can``), whose day-one
    bundles are exactly :data:`AUTHOR_ROLES`; a grant to a group now opens
    authoring.  A store that cannot be read answers False (nobody authors on
    a guess); a harness with no store answers from the code bundles."""
    if not user:
        return False
    from core.tool_entitlement.engine import PermissionCheckUnavailable, can
    try:
        return can(user, "clockwork.author")
    except PermissionCheckUnavailable:
        return False


def scope_for(user: Optional[Mapping[str, Any]],
              component_visible: Optional[bool] = None) -> str:
    """``full`` | ``scheduler_only`` | ``none``.

    ``component_visible`` is the admin visibility map's verdict for
    :data:`SCHEDULER_COMPONENT_KEY` (None = not consulted / default show).
    An admin hiding the component for a role hides the scheduler from that
    role's API too — the nav and the API must agree in BOTH directions.
    """
    if not user:
        return SCOPE_NONE
    if component_visible is False:
        return SCOPE_NONE
    if is_scheduler_scoped(user):
        return SCOPE_SCHEDULER_ONLY
    return SCOPE_FULL


def apply_scope_to_visibility(user: Optional[Mapping[str, Any]],
                              resolved: Optional[Mapping[str, bool]],
                              known_keys: Iterable[str]) -> Dict[str, bool]:
    """Narrow an admin-resolved visibility map for a scoped principal.

    For anyone else the map is returned unchanged (a ``{}`` for super_admin
    stays ``{}``, which the frontend reads as "show everything").  For a
    scheduler-scoped principal EVERY known key is stated explicitly — the
    frontend defaults an ABSENT key to visible, so an explicit False per
    key is the only shape that actually hides the rest of the product.
    The scheduler key itself keeps whatever the admin map said (an admin
    may still hide it for the role; that yields scope ``none``).
    """
    base: Dict[str, bool] = dict(resolved or {})
    if not is_scheduler_scoped(user):
        return base
    out: Dict[str, bool] = {}
    for key in set(known_keys) | set(base.keys()):
        if key == SCHEDULER_COMPONENT_KEY or key.startswith(SCHEDULER_COMPONENT_KEY + "."):
            out[key] = bool(base.get(key, True))
        else:
            out[key] = False
    return out


def access_payload(user: Optional[Mapping[str, Any]],
                   component_visible: Optional[bool] = None) -> Dict[str, Any]:
    """The published verdict for ``GET /api/clockwork/access``."""
    scope = scope_for(user, component_visible)
    role = _role(user)
    username = str((user or {}).get("username", "") or "")
    if scope == SCOPE_NONE:
        reason = (
            f"component '{SCHEDULER_COMPONENT_KEY}' is disabled for role "
            f"'{role or 'anonymous'}' by the admin visibility map"
            if user else "anonymous"
        )
    elif scope == SCOPE_SCHEDULER_ONLY:
        reason = f"role '{ROLE_SCHEDULER}' is scoped to the scheduler and nothing else"
    else:
        reason = f"role '{role}' has the full product; the scheduler is one part of it"
    return {
        "scope": scope,
        "principal": username,
        "role": role,
        "reason": reason,
        "can_author": bool(scope != SCOPE_NONE and can_author(user)),
        "can_admin": bool(scope != SCOPE_NONE and is_admin_like(user)),
        "read_only": bool(scope != SCOPE_NONE and (is_support(user) or not can_author(user))),
        "component_key": SCHEDULER_COMPONENT_KEY,
        "allowed_api_prefixes": list(SCOPED_API_PREFIXES) if scope == SCOPE_SCHEDULER_ONLY else None,
    }


def visible_component_keys(known_keys: Iterable[str]) -> List[str]:
    """The keys a scoped principal is left with — for tests and the report."""
    return sorted(k for k in known_keys
                  if k == SCHEDULER_COMPONENT_KEY or k.startswith(SCHEDULER_COMPONENT_KEY + "."))
