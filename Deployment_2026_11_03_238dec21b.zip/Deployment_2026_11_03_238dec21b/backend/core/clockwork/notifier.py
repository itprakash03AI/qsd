"""The alert NOTIFIER: the one consumer of ``clockwork_alerts`` (2026-09-10).

THE GAP.  The dispatcher's publisher writes every refusal and anomaly as a
row (``_pg_publisher.alert``: once per (job, deployment, kind), a count and
first/last-seen), and the authoring plane writes its own
(``calendar_unprojectable``).  The rows were faithful and NOTHING READ THEM
except the alerts page -- a job failing at 02:00 was a row nobody saw until
a person opened it.  An alert with no consumer is the pattern this repo has
already named (a Netcool queue with no drainer, a watcher computing
freshness and throwing it away).

THE RULES, each stated because each has been broken somewhere in this repo:

* **An alert is a FACT, a notification is a DELIVERY.**  This module never
  writes ``clockwork_alerts``.  What it did lands in
  ``clockwork_alert_notifications`` (one ledger row per alert id) and in the
  product's ``notification_log`` (the same history the reports and feeds
  write, read by the in-app bell).  A delivery failure is a ledger row with
  ``status=failed`` and the error; the fact is untouched.

* **Once per alert IDENTITY, never once per tick.**  The alert row bumps
  ``count`` on every repetition; the ledger remembers the count and the
  acknowledged state it last saw, and delivers only on a TRANSITION: the
  first sighting, or a re-raise after a person acknowledged it (the
  publisher clears ``acknowledged_at`` when the fact recurs).  A permanently
  bad job pages once.  A retry after a failed delivery is bounded by
  ``clockwork.notify_max_attempts``; after that the ledger says
  ``exhausted`` and the log says so once.

* **Who is told is derived from the job**: the owner group's
  ``notification_email`` and its members (in-app), then the job's ``owner``
  (an address if it contains ``@``, else a username for the in-app bell),
  with a DEPLOYMENT-LEVEL fallback (``clockwork.notify_fallback_emails`` /
  ``_usernames``) for a job nobody owns and for a global alert (``job_id``
  NULL).  A CRITICAL alert goes to the fallback as well as the owner.
  "No recipient" is a ledger row that says ``unrouted``, an ERROR line
  once, and a count on ``/api/clockwork/health`` -- never a silent return.

* **Severity**: an UNKNOWN outcome, a stuck CLAIMED row, an unreconciled
  tick and an unreadable job source are CRITICAL -- a human must look
  before anyone re-drives, and nothing else will fire until someone does.
  A refused row / credential / calendar is a WARNING: nothing went out, the
  job did not run, the fix is in the configuration.  A failed task, a
  missed window and a refused claim are ERRORs.  An UNKNOWN KIND (the
  dispatcher may grow new ones) is treated as an ERROR and delivered --
  never dropped, never a crash -- and the message says the kind is new.

* **Advisory code fails OPEN, audibly.**  ``run_once`` never raises; a
  failure on one alert is logged at ERROR with the ``[clockwork.notify]``
  prefix and recorded on that alert's ledger row, and the next alert is
  still processed.  A tick, the API and the alert row are never affected.

WHERE IT RUNS.  ``register_notifier_daemon`` puts an interval job on the
daemon scheduler; ``core.daemon_registry.SCHEDULER_OWNED`` owns it on the
scheduler pod and ``main.py`` registers it in hybrid mode -- both, because
a daemon registered in one place and gated in the other runs on NO pod
(2026-08-20, 2026-09-01).
"""
from __future__ import annotations

import html
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence

logger = logging.getLogger(__name__)

#: The grep prefix for every line this module writes above DEBUG.
LOG_PREFIX = "[clockwork.notify]"
DAEMON_NAME = "clockwork_alert_notifier"
EVENT_TYPE = "clockwork_alert"

SEVERITY_CRITICAL = "critical"
SEVERITY_ERROR = "error"
SEVERITY_WARNING = "warning"

#: alert kind -> severity.  The kinds are the dispatcher's trigger names
#: (``clockwork.alerts.ALL_TRIGGERS``, written as ``kind`` by its publisher)
#: plus the authoring plane's own.  A kind absent here is DEFAULT_SEVERITY.
KIND_SEVERITY: Dict[str, str] = {
    # a lost answer: the task may have run; re-driving it is the one failure
    # this platform exists to prevent, so a person must look
    "clockwork_unknown_outcome": SEVERITY_CRITICAL,
    # a claim nobody finished: same question, asked by the clock
    "clockwork_stale_claim": SEVERITY_CRITICAL,
    # rows vanished from a tick's arithmetic; the counters look normal
    "clockwork_tick_unreconciled": SEVERITY_CRITICAL,
    # the deployment cannot read its jobs: NOTHING fires until fixed
    "clockwork_source_unreadable": SEVERITY_CRITICAL,
    # a deployment that stopped ticking: every job it has authority for
    # is silently not running (added by the core 2026-09-10)
    "clockwork_deployment_stalled": SEVERITY_CRITICAL,
    # the OTHER half of that: a pod that DIED or never started raises
    # nothing at all -- a dead process cannot alarm about itself -- so
    # core/clockwork/silence.py raises this one from OUTSIDE, by reading
    # clockwork_deployments.last_tick_at.  A scheduler nobody is driving is
    # not a warning.
    "clockwork_deployment_silent": SEVERITY_CRITICAL,
    # something went out and did not succeed, or an occurrence was lost
    "clockwork_task_failed": SEVERITY_ERROR,
    "clockwork_missed_window": SEVERITY_ERROR,
    "clockwork_claim_refused": SEVERITY_ERROR,
    # NOTE (2026-09-11 security review): this ARGUABLY belongs with the
    # criticals.  The job read is ordered, so a truncated read drops the SAME
    # rows on every tick -- those jobs are not late, they are not running at
    # all -- which is the shape of ``clockwork_source_unreadable`` above.  It
    # is left at ERROR because ``tests/test_clockwork_alert_notifier_2026_09_10.py``
    # pins the map and that file was owned by another change in flight.  It
    # is not left silent: the trigger's MESSAGE now says the overflow is the
    # same rows every tick and names the two ways out, and a truncation alert
    # is global (no job), so ``resolve_recipients`` routes it to the
    # deployment fallback anyway -- which is what CRITICAL would have added.
    "clockwork_source_truncated": SEVERITY_ERROR,
    # nothing went out; the job did not run; the fix is configuration
    "clockwork_row_refused": SEVERITY_WARNING,
    "clockwork_credential_refused": SEVERITY_WARNING,
    "clockwork_task_unroutable": SEVERITY_WARNING,
    "calendar_unprojectable": SEVERITY_WARNING,
    # a query template a job snapshots was edited into something the
    # projection refuses (inactive, or the statement rules): the job is
    # out of the dispatch view until the template or the job is fixed
    "template_unprojectable": SEVERITY_WARNING,
}
DEFAULT_SEVERITY = SEVERITY_ERROR

STATUS_SENT = "sent"
STATUS_PARTIAL = "partial"
STATUS_FAILED = "failed"
STATUS_UNROUTED = "unrouted"
STATUS_EXHAUSTED = "exhausted"
#: the alert was already acknowledged the first time the notifier saw it
#: (a system acknowledgement, or a person on the page): nothing to tell.
STATUS_ACKNOWLEDGED = "acknowledged"
#: CLAIMED by one pass, delivery in flight (2026-10-10).  Written by the
#: insert-first claim BEFORE anything is sent, so a second pass in the same
#: window (another pod's tick, a run-now beside the tick) finds the row and
#: does not page again.  Replaced by the outcome when the pass finishes; a
#: pass that died mid-send leaves it, and :data:`SENDING_TAKEOVER_SECONDS`
#: later the next pass claims it as a retry.
STATUS_SENDING = "sending"
SENDING_TAKEOVER_SECONDS = 600


def severity_of(kind: Any) -> str:
    return KIND_SEVERITY.get(str(kind or ""), DEFAULT_SEVERITY)


@dataclass
class Recipients:
    emails: List[str] = field(default_factory=list)
    usernames: List[str] = field(default_factory=list)
    #: how each was derived, for the ledger ("owner_group:3 notification_email", "owner", "fallback")
    derived_from: List[str] = field(default_factory=list)

    def __bool__(self) -> bool:
        return bool(self.emails or self.usernames)

    def to_dict(self) -> Dict[str, Any]:
        return {"emails": list(self.emails), "usernames": list(self.usernames),
                "derived_from": list(self.derived_from)}


def _channels(value: Any) -> Dict[str, List[str]]:
    """``{"emails": [...], "usernames": [...]}`` from a ledger sub-dict that
    may be absent or malformed (a row written before 2026-09-11 has no
    ``delivered`` / ``pending``): missing means empty."""
    if not isinstance(value, Mapping):
        return {"emails": [], "usernames": []}
    return {"emails": [str(e) for e in (value.get("emails") or []) if isinstance(e, str)],
            "usernames": [str(u) for u in (value.get("usernames") or []) if isinstance(u, str)]}


def _pending_of(row: Mapping[str, Any]) -> str:
    p = _channels((row.get("recipients") or {}).get("pending") if isinstance(row.get("recipients"), Mapping) else None)
    parts = ([f"email {', '.join(p['emails'])}"] if p["emails"] else []) + \
            ([f"in-app {', '.join(p['usernames'])}"] if p["usernames"] else [])
    return "; ".join(parts) or "(not recorded)"


#: The most recipients ONE alert is delivered to.
#:
#: 2026-09-11.  There was no cap of any kind: a job's ``owner`` went verbatim
#: into the recipient list, an owner group's ``notification_email`` is a
#: comma-separated column, and a member list is a table.  A non-admin who can
#: author a job could therefore choose who the organisation's SMTP server
#: writes to, how often (fail the job), and how many at a time.
MAX_RECIPIENTS_PER_ALERT = 25

#: The most emails ONE pass of the notifier sends.  The daemon runs every
#: ``poll_seconds``; without this, N alerts x M recipients is one burst with
#: no ceiling, and the organisation's mail server is the thing that finds out.
MAX_EMAILS_PER_PASS = 100


def _domain_of(address: str) -> str:
    return str(address or "").rsplit("@", 1)[-1].strip().lower()


@dataclass
class Settings:
    enabled: bool = True
    poll_seconds: int = 60
    fallback_emails: List[str] = field(default_factory=list)
    fallback_usernames: List[str] = field(default_factory=list)
    max_attempts: int = 5
    #: Domains an alert may be EMAILED to.  An address derived from a JOB ROW
    #: -- the ``owner`` column, an owner group's ``notification_email`` --
    #: must be on this list.  See :meth:`allows_email`.
    allowed_email_domains: List[str] = field(default_factory=list)

    @classmethod
    def from_config(cls) -> "Settings":
        from core.config import get as _get
        return cls(
            enabled=bool(_get("clockwork", "notify_enabled", True)),
            poll_seconds=max(5, int(_get("clockwork", "notify_poll_seconds", 60) or 60)),
            fallback_emails=_split(_get("clockwork", "notify_fallback_emails", "")),
            fallback_usernames=_split(_get("clockwork", "notify_fallback_usernames", "")),
            max_attempts=max(1, int(_get("clockwork", "notify_max_attempts", 5) or 5)),
            allowed_email_domains=[d.lower().lstrip("@") for d in
                                   _split(_get("clockwork", "notify_allowed_email_domains", ""))],
        )

    def email_domains(self) -> List[str]:
        """The domains an AUTHORED address may use.  Empty = not configured.

        Declared by the operator; and when they have declared none, DERIVED
        from the addresses the operator already configured as fallbacks --
        which is the operator saying, in the only other place they say it,
        which domain this deployment writes to.
        """
        if self.allowed_email_domains:
            return list(self.allowed_email_domains)
        return sorted({_domain_of(a) for a in self.fallback_emails if "@" in a})

    def allows_email(self, address: str) -> bool:
        """May an address DERIVED FROM A JOB ROW be written to?

        ═══════════════════════════════════════════════════════════════
        THE TRADE, STATED, BECAUSE THE DEFAULT IS NOT FAIL-CLOSED
        ═══════════════════════════════════════════════════════════════

        With :attr:`allowed_email_domains` (or a fallback address to derive
        one from) configured, this is an ALLOW-LIST and an authored address
        outside it is dropped and logged by name.  With NOTHING configured
        it permits, and says so in the log.

        That asymmetry is deliberate.  This module is ADVISORY code -- its
        whole reason to exist is that an alert with no consumer is a fact
        nobody reads -- and this repo has already paid for advisory code
        that failed closed on an absent configuration (2026-08-29: a
        placeholder's empty scope rendered as fact, an EMPTY FILE delivered
        with status SUCCESS).  Turning "the operator has not set a key yet"
        into "nobody is told the job failed" would replace a disclosure risk
        with a silence risk, on every existing deployment, at upgrade time.

        What is NOT left to the configuration: the SHAPE of ``owner`` is
        refused at save (``validation._owner_problems`` -- one address, no
        display name, no comma list, no newline, so one value cannot become
        several recipients or an injected header), the recipient count is
        capped per alert, and the email count is capped per pass.  Those
        are always on.  The domain gate is the part an operator turns on
        with ``clockwork.notify_allowed_email_domains``, and the log says
        so every time an authored address is routed without one.
        """
        domain = _domain_of(address)
        if "@" not in str(address or "") or not domain:
            return False
        allowed = self.email_domains()
        if not allowed:
            logger.warning(
                "%s %s is an AUTHORED alert recipient and this deployment "
                "declares no allowed domains, so it is being written to.  "
                "Set clockwork.notify_allowed_email_domains to restrict "
                "which domains a job's owner may direct alerts to.",
                LOG_PREFIX, address)
            return True
        return any(domain == d or domain.endswith("." + d) for d in allowed)


def _split(raw: Any) -> List[str]:
    if isinstance(raw, (list, tuple)):
        items = [str(x) for x in raw]
    else:
        items = str(raw or "").split(",")
    out: List[str] = []
    for x in items:
        x = x.strip()
        if x and x.lower() not in {o.lower() for o in out}:
            out.append(x)
    return out


def _add(into: List[str], values: Sequence[str]) -> None:
    seen = {v.lower() for v in into}
    for v in values:
        v = str(v or "").strip()
        if v and v.lower() not in seen:
            into.append(v)
            seen.add(v.lower())


def resolve_recipients(db: Any, job: Optional[Mapping[str, Any]], severity: str,
                       settings: Settings) -> Recipients:
    """Who is told about an alert on ``job`` (None = a global alert or a
    job that no longer exists).  See the module docstring."""
    r = Recipients()
    if job is not None:
        gid = job.get("owner_group_id")
        if gid:
            try:
                group = db.get_user_group(int(gid)) or {}
            except Exception as exc:  # noqa: BLE001 - a lookup failure must not lose the alert
                logger.warning("%s owner group %s could not be read: %s", LOG_PREFIX, gid, exc)
                group = {}
            emails = _authored_emails(_split(group.get("notification_email")), settings,
                                      f"owner_group:{gid} notification_email")
            if emails:
                _add(r.emails, emails)
                r.derived_from.append(f"owner_group:{gid} notification_email")
            try:
                members = [m.get("username") for m in (db.list_user_group_members(int(gid)) or [])]
            except Exception as exc:  # noqa: BLE001
                logger.warning("%s owner group %s members could not be read: %s", LOG_PREFIX, gid, exc)
                members = []
            members = [m for m in members if m]
            if members:
                _add(r.usernames, members)
                r.derived_from.append(f"owner_group:{gid} members")
        owner = str(job.get("owner") or "").strip()
        if owner:
            if "@" in owner:
                allowed = _authored_emails([owner], settings, "owner")
                if allowed:
                    _add(r.emails, allowed)
                    r.derived_from.append("owner")
            else:
                _add(r.usernames, [owner])
                r.derived_from.append("owner")
    if (severity == SEVERITY_CRITICAL or not r) and (
            settings.fallback_emails or settings.fallback_usernames):
        # The operator's own addresses.  NOT passed through the domain
        # gate: they are configuration, not something an author typed.
        _add(r.emails, settings.fallback_emails)
        _add(r.usernames, settings.fallback_usernames)
        r.derived_from.append("fallback")
    # CAPPED, and the cap is stated on the ledger rather than applied
    # silently -- "delivered to 25" must not read as "told everyone".
    if len(r.emails) + len(r.usernames) > MAX_RECIPIENTS_PER_ALERT:
        room = max(0, MAX_RECIPIENTS_PER_ALERT - len(r.usernames))
        dropped = len(r.emails) - room
        r.emails = r.emails[:room]
        r.usernames = r.usernames[:MAX_RECIPIENTS_PER_ALERT]
        r.derived_from.append(
            f"capped at {MAX_RECIPIENTS_PER_ALERT} recipients ({max(0, dropped)} "
            f"email address(es) not written to)")
    return r


def _authored_emails(addresses: Sequence[str], settings: Settings,
                     where: str) -> List[str]:
    """Filter addresses that came out of a JOB ROW through the domain gate.

    ``owner`` is validated as "must be a string" and nothing else, so a
    non-admin who can author a job could set it to an address outside the
    organisation, fail the job, and have the organisation's own SMTP server
    write to that address -- with no rate limit and no cap.  An address the
    gate refuses is DROPPED and LOGGED by name; the alert still goes to
    whoever else is routed, and to the fallback if nobody is.
    """
    out: List[str] = []
    for address in addresses:
        if settings.allows_email(address):
            out.append(address)
        else:
            logger.warning(
                "%s %s names %r, which is not on this deployment's alert "
                "email domains %s -- NOT written to.  Set "
                "clockwork.notify_allowed_email_domains, or use a username.",
                LOG_PREFIX, where, address, settings.email_domains() or "(none)")
    return out


def _default_email_send(to_addresses: List[str], subject: str, text: str) -> bool:
    """The product's SMTP path (``core.email_service``), the one the
    DataFlow notification engine and the DQ alerter use.  Returns False
    when SMTP is not configured -- the caller records that as a failure
    with the reason, not as a silent success."""
    from core.email_service import is_email_enabled, send_email
    if not is_email_enabled():
        raise RuntimeError("SMTP not configured (config email.host / SMTP_HOST); email not sent")
    # ESCAPED.  ``text`` is built from a job's name, its owner, the alert
    # kind and the alert's detail -- and the detail is what a TARGET said.
    # Interpolating that into an HTML body unescaped put attacker-chosen
    # markup in a mail the organisation sent from its own domain.
    return bool(send_email(to_addresses=to_addresses, subject=subject,
                           html_body=f"<pre>{html.escape(text)}</pre>",
                           text_body=text))


def _default_broadcast(payload: Dict[str, Any]) -> None:
    """The scheduler's pluggable broadcast (a websocket in embedded mode,
    the ``pending_notifications`` queue on the scheduler pod), so a person
    with the UI open sees the bell move before the next poll."""
    from core import scheduler as _sched
    fn = getattr(_sched, "_broadcast_fn", None)
    if fn is not None:
        fn(payload)


class AlertNotifier:
    """Reads the alert rows, decides what is a transition, delivers, records.

    ``email_send(to, subject, text) -> bool`` and ``broadcast(payload)`` are
    injectable so a test asserts the VALUES delivered; the defaults are the
    product's own paths.
    """

    def __init__(self, db: Any, *, settings: Optional[Settings] = None,
                 email_send: Optional[Callable[[List[str], str, str], bool]] = None,
                 broadcast: Optional[Callable[[Dict[str, Any]], None]] = None,
                 clock: Optional[Callable[[], datetime]] = None) -> None:
        self.db = db
        self._settings = settings
        self._email_send = email_send or _default_email_send
        self._broadcast = broadcast or _default_broadcast
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        #: Emails sent SO FAR IN THIS PASS.  Reset by ``run_once``; read by
        #: ``_deliver`` so a burst of alerts cannot become a burst of mail
        #: (see :data:`MAX_EMAILS_PER_PASS`).
        self._emails_this_pass = 0

    @property
    def settings(self) -> Settings:
        return self._settings if self._settings is not None else Settings.from_config()

    # ── the pass ────────────────────────────────────────────────────────

    def run_once(self) -> Dict[str, int]:
        """One pass over every alert row.  Never raises.  Returns counters
        so a caller (or a test) can see what happened: ``seen``,
        ``notified``, ``repeated`` (no transition), ``unrouted``,
        ``failed``, ``exhausted``, ``errors`` (the notifier's own)."""
        counters = {k: 0 for k in ("seen", "notified", "repeated", "unrouted", "failed",
                                   "exhausted", "acknowledged", "errors",
                                   # 2026-10-10: another pass holds the delivery
                                   "claimed_elsewhere", "in_flight")}
        self._emails_this_pass = 0
        try:
            alerts = self.db.list_clockwork_alerts()
            ledger = {int(r["alert_id"]): r
                      for r in self.db.list_clockwork_alert_notifications()}
        except Exception as exc:  # noqa: BLE001 - fail open: a tick is not the notifier's to break
            logger.error("%s could not read the alert rows: %s: %s -- nothing notified this pass",
                         LOG_PREFIX, type(exc).__name__, exc)
            counters["errors"] += 1
            return counters
        jobs: Dict[int, Optional[Dict[str, Any]]] = {}
        for a in alerts:
            counters["seen"] += 1
            try:
                outcome = self._consider(a, ledger.get(int(a["id"])), jobs)
                counters[outcome] += 1
            except Exception as exc:  # noqa: BLE001 - one alert's failure must not mute the rest
                counters["errors"] += 1
                logger.error("%s alert %s (%s) could not be processed: %s: %s -- the alert row is "
                             "untouched and will be reconsidered next pass",
                             LOG_PREFIX, a.get("id"), a.get("kind"), type(exc).__name__, exc)
                try:
                    self.db.upsert_clockwork_alert_notification(
                        int(a["id"]), job_id=a.get("job_id"), kind=str(a.get("kind") or ""),
                        severity=severity_of(a.get("kind")), status=STATUS_FAILED,
                        error=f"notifier error: {type(exc).__name__}: {exc}"[:4000])
                except Exception as exc2:  # noqa: BLE001
                    logger.error("%s ... and the ledger could not record it either: %s", LOG_PREFIX, exc2)
        return counters

    def _consider(self, a: Mapping[str, Any], row: Optional[Mapping[str, Any]],
                  jobs: Dict[int, Optional[Dict[str, Any]]]) -> str:
        """The transition rule.  Returns the counter it landed in."""
        alert_id = int(a["id"])
        acked = a.get("acknowledged_at") is not None
        count = int(a.get("count") or 0)
        if self._job_switched_off(a, jobs):
            # 2026-10-30: a DELETED job is switched off, not erased.  Its
            # alerts page nobody -- not its owner, not the fallback -- even
            # when one recurs; the ledger records the count it covered, so a
            # recurrence after it is switched back on pages as usual.
            if row is None or not row.get("alert_acknowledged") \
                    or int(row.get("alert_count") or 0) < count:
                self.db.upsert_clockwork_alert_notification(
                    alert_id, job_id=a.get("job_id"), kind=str(a.get("kind") or ""),
                    severity=severity_of(a.get("kind")), alert_count=count,
                    alert_acknowledged=True, status=STATUS_ACKNOWLEDGED,
                    error="the job is switched off; nobody is paged for it")
            return "acknowledged"
        if row is None:
            if acked:
                self.db.upsert_clockwork_alert_notification(
                    alert_id, job_id=a.get("job_id"), kind=str(a.get("kind") or ""),
                    severity=severity_of(a.get("kind")), alert_count=count,
                    alert_acknowledged=True, status=STATUS_ACKNOWLEDGED)
                return "acknowledged"
            return self._deliver(a, attempts=0, row=None)  # first sighting
        if acked:
            if not row.get("alert_acknowledged"):
                self.db.upsert_clockwork_alert_notification(
                    alert_id, alert_acknowledged=True, alert_count=count)
            return "acknowledged"
        attempts = int(row.get("attempts") or 0)
        status = row.get("status")
        if status == STATUS_SENDING:
            # Another pass claimed this delivery.  In flight: nothing to do.
            # Abandoned (the pass died before writing its outcome): the
            # claim ages out and this pass takes it over AS A RETRY -- the
            # conditional claim inside _deliver makes exactly one taker.
            if self._sending_age_seconds(row) < SENDING_TAKEOVER_SECONDS:
                return "in_flight"
            logger.warning("%s alert %s (%s) has been 'sending' for over %ds -- the pass that "
                           "claimed it never recorded an outcome; taking it over",
                           LOG_PREFIX, alert_id, a.get("kind"), SENDING_TAKEOVER_SECONDS)
            return self._deliver(a, attempts=attempts, row=row)
        if row.get("alert_acknowledged") and count > int(row.get("alert_count") or 0):
            # acknowledged by a person, then the fact recurred: a transition
            return self._deliver(a, attempts=0, row=row)
        if status in (STATUS_FAILED, STATUS_PARTIAL):
            # 2026-09-11 audit (item 4): ``partial`` had no branch and fell
            # through to "repeated", so a failed email beside a delivered
            # in-app bell was never retried.  Both are retried within
            # ``notify_max_attempts``; a partial retries ONLY what failed
            # (the ledger's ``recipients.pending``), so nobody is told
            # twice.  Exhausted says what was never delivered.
            if attempts >= self.settings.max_attempts:
                self.db.upsert_clockwork_alert_notification(alert_id, status=STATUS_EXHAUSTED)
                logger.error("%s alert %s (%s, job %s) %s after %d attempt(s): %s -- giving up; the "
                             "alert row stays and is visible on the alerts page%s",
                             LOG_PREFIX, alert_id, a.get("kind"), a.get("job_id"),
                             ("could not be delivered" if status == STATUS_FAILED
                              else "was only PARTLY delivered"),
                             attempts, row.get("error"),
                             ("" if status == STATUS_FAILED else
                              f"; never told: {_pending_of(row)}"))
                return "exhausted"
            return self._deliver(a, attempts=attempts, row=row,    # bounded retry
                                 prior=(row.get("recipients") if status == STATUS_PARTIAL else None))
        if status == STATUS_UNROUTED:
            # an owner may have been assigned or a fallback configured since
            job = self._job(a, jobs)
            if resolve_recipients(self.db, job, severity_of(a.get("kind")), self.settings):
                return self._deliver(a, attempts=attempts, row=row)
            return "unrouted"
        if status == STATUS_EXHAUSTED:
            return "exhausted"
        return "repeated"

    def _sending_age_seconds(self, row: Mapping[str, Any]) -> float:
        """How long a ``sending`` row has been held; unreadable = forever
        (an unparseable timestamp must not keep a delivery hostage)."""
        raw = row.get("updated_at")
        try:
            ts = datetime.fromisoformat(str(raw)) if isinstance(raw, str) else raw
            if not isinstance(ts, datetime):
                return float("inf")
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            now = self._clock()
            if now.tzinfo is None:
                now = now.replace(tzinfo=timezone.utc)
            return max(0.0, (now - ts).total_seconds())
        except (TypeError, ValueError):
            return float("inf")

    def _job_switched_off(self, a: Mapping[str, Any], jobs: Dict[Any, Any]) -> bool:
        """True when the alert's job exists and is SWITCHED OFF (deleted,
        2026-10-30).  Cached per pass beside ``jobs``; a DB without the
        question (an older stub) or an unreadable answer is "not switched
        off" -- the alert is then handled exactly as before."""
        jid = a.get("job_id")
        ask = getattr(self.db, "clockwork_job_switched_off", None)
        if jid is None or ask is None:
            return False
        key = ("switched_off", int(jid))
        if key not in jobs:
            try:
                jobs[key] = bool(ask(int(jid)) is True)
            except Exception as exc:  # noqa: BLE001
                logger.warning("%s could not ask whether job %s is switched off: %s",
                               LOG_PREFIX, jid, exc)
                jobs[key] = False
        return bool(jobs[key])

    def _job(self, a: Mapping[str, Any], jobs: Dict[int, Optional[Dict[str, Any]]]) -> Optional[Dict[str, Any]]:
        jid = a.get("job_id")
        if jid is None:
            return None
        jid = int(jid)
        if jid not in jobs:
            try:
                jobs[jid] = self.db.get_clockwork_job(jid)
            except Exception as exc:  # noqa: BLE001
                logger.warning("%s job %s could not be read: %s", LOG_PREFIX, jid, exc)
                jobs[jid] = None
        return jobs[jid]

    # ── one delivery ────────────────────────────────────────────────────

    def _deliver(self, a: Mapping[str, Any], *, attempts: int,
                 prior: Optional[Mapping[str, Any]] = None,
                 row: Optional[Mapping[str, Any]] = None) -> str:
        """One delivery attempt.  ``prior`` is the ledger's ``recipients``
        from a PARTIAL attempt: only its ``pending`` are sent to now, and
        its ``delivered`` are carried forward, so the ledger states what
        actually happened across attempts -- who was told, who never was.

        ``row`` is the ledger row this pass READ (None on first sighting).
        Before anything is sent the delivery is CLAIMED against it
        (2026-10-10): an insert of the row, or a conditional update gated on
        the status/attempts that were read.  A pass that loses the claim
        sends nothing -- the other pass is paging these people."""
        alert_id = int(a["id"])
        kind = str(a.get("kind") or "")
        severity = severity_of(kind)
        claim = dict(job_id=a.get("job_id"), kind=kind, severity=severity,
                     alert_count=int(a.get("count") or 0), alert_acknowledged=False,
                     status=STATUS_SENDING)
        if row is None:
            won = self.db.claim_clockwork_alert_notification(alert_id, attempts=attempts, **claim)
        else:
            won = self.db.claim_clockwork_alert_notification(
                alert_id, expect_status=row.get("status"),
                expect_attempts=int(row.get("attempts") or 0), **claim)
        if not won:
            logger.info("%s alert %s (%s, job %s): another pass holds this delivery -- not "
                        "paging again", LOG_PREFIX, alert_id, kind, a.get("job_id"))
            return "claimed_elsewhere"
        job = self._job(a, {})
        recipients = resolve_recipients(self.db, job, severity, self.settings)
        done_before = _channels(prior.get("delivered") if prior else None)
        if prior and isinstance(prior.get("pending"), Mapping):
            # a retry of a partial: only what is still pending AND still a
            # recipient (an owner replaced since is not paged for the old
            # one).  A row with NO recorded pending (written before
            # 2026-09-11) re-sends to everyone: a second bell for someone
            # already told beats a page that never reaches someone owed it.
            pending = _channels(prior.get("pending"))
            recipients = Recipients(
                emails=[e for e in recipients.emails if e in pending["emails"]],
                usernames=[u for u in recipients.usernames if u in pending["usernames"]],
                derived_from=list(recipients.derived_from))
        base = dict(job_id=a.get("job_id"), kind=kind, severity=severity,
                    alert_count=int(a.get("count") or 0), alert_acknowledged=False,
                    recipients=recipients.to_dict())
        if prior and isinstance(prior.get("pending"), Mapping) and not recipients:
            # nothing pending is a recipient any more: what was delivered is
            # all there is to deliver
            self.db.upsert_clockwork_alert_notification(
                alert_id, status=STATUS_SENT, attempts=attempts + 1, error=None,
                **{**base, "recipients": {**base["recipients"], "delivered": done_before,
                                          "pending": _channels(None)}})
            return "notified"
        if not recipients:
            why = ("no recipient: " + ("the alert is global (no job)" if job is None and a.get("job_id") is None
                                       else f"job {a.get('job_id')} does not exist" if job is None
                                       else "the job has no owner and no owner group")
                   + " and clockwork.notify_fallback_emails / notify_fallback_usernames are empty")
            self.db.upsert_clockwork_alert_notification(alert_id, status=STATUS_UNROUTED, error=why, **base)
            logger.error("%s alert %s (%s, %s, job %s) reached NOBODY -- %s.  It stays on the alerts "
                         "page; configure a fallback or assign an owner", LOG_PREFIX, alert_id, kind,
                         severity, a.get("job_id"), why)
            return "unrouted"

        title, text = self._render(a, job, severity, kind)
        now = self._clock()
        failures: List[str] = []
        delivered = 0
        told = {"emails": list(done_before["emails"]), "usernames": list(done_before["usernames"])}
        pending_now = {"emails": [], "usernames": []}
        for username in recipients.usernames:
            try:
                self.db.log_notification(
                    event_type=EVENT_TYPE, channel="websocket", recipient=username, status="sent",
                    title=title, message=text,
                    payload={"alert_id": alert_id, "job_id": a.get("job_id"), "kind": kind,
                             "severity": severity, "count": a.get("count"),
                             "first_seen_at": a.get("first_seen_at"), "last_seen_at": a.get("last_seen_at")})
                delivered += 1
                told["usernames"].append(username)
            except Exception as exc:  # noqa: BLE001
                failures.append(f"in-app {username}: {type(exc).__name__}: {exc}")
                pending_now["usernames"].append(username)
            try:
                self._broadcast({"type": "notification", "event_type": EVENT_TYPE, "username": username,
                                 "title": title, "message": text, "severity": severity,
                                 "alert_id": alert_id, "job_id": a.get("job_id"), "kind": kind})
            except Exception as exc:  # noqa: BLE001 - the bell is a courtesy; the row is the record
                logger.debug("%s broadcast to %s failed: %s", LOG_PREFIX, username, exc)
        if recipients.emails and self._emails_this_pass >= MAX_EMAILS_PER_PASS:
            # THE PASS BUDGET.  Not silence: the addresses go on the ledger's
            # ``pending``, so the next pass's PARTIAL retry sends to exactly
            # them and the row says who is still owed the page.  A cap that
            # dropped the recipients instead would page nobody and look
            # delivered.
            failures.append(
                f"email {', '.join(recipients.emails)}: this pass has already "
                f"sent {MAX_EMAILS_PER_PASS} emails (clockwork.notifier "
                f"MAX_EMAILS_PER_PASS); deferred to the next pass")
            pending_now["emails"].extend(recipients.emails)
            logger.warning("%s email budget of %d reached this pass; alert %s "
                           "deferred to the next pass",
                           LOG_PREFIX, MAX_EMAILS_PER_PASS, alert_id)
        elif recipients.emails:
            self._emails_this_pass += len(recipients.emails)
            try:
                ok = self._email_send(list(recipients.emails), title, text)
                if ok:
                    delivered += len(recipients.emails)
                    told["emails"].extend(recipients.emails)
                    self._log_email(recipients.emails, title, text, "sent", None, a)
                else:
                    failures.append(f"email {', '.join(recipients.emails)}: send_email returned False")
                    pending_now["emails"].extend(recipients.emails)
                    self._log_email(recipients.emails, title, text, "failed", "send_email returned False", a)
            except Exception as exc:  # noqa: BLE001
                failures.append(f"email {', '.join(recipients.emails)}: {type(exc).__name__}: {exc}")
                pending_now["emails"].extend(recipients.emails)
                self._log_email(recipients.emails, title, text, "failed", f"{type(exc).__name__}: {exc}", a)

        ever_delivered = delivered + len(done_before["emails"]) + len(done_before["usernames"])
        if failures and not ever_delivered:
            status = STATUS_FAILED
        elif failures:
            status = STATUS_PARTIAL
        else:
            status = STATUS_SENT
        # the ledger says what actually happened: who was told (across
        # attempts) and who is still owed the page
        base["recipients"] = {**base["recipients"], "delivered": told, "pending": pending_now}
        self.db.upsert_clockwork_alert_notification(
            alert_id, status=status, attempts=attempts + 1,
            error=("; ".join(failures)[:4000] or None),
            notified_at=(now.replace(tzinfo=None) if delivered else None), **base)
        if status == STATUS_SENT:
            logger.info("%s alert %s (%s, %s, job %s) delivered to %d recipient(s): %s",
                        LOG_PREFIX, alert_id, kind, severity, a.get("job_id"), delivered,
                        ", ".join(recipients.derived_from))
            return "notified"
        logger.error("%s alert %s (%s, %s, job %s) delivery %s (attempt %d/%d): %s",
                     LOG_PREFIX, alert_id, kind, severity, a.get("job_id"), status,
                     attempts + 1, self.settings.max_attempts, "; ".join(failures))
        return "notified" if status == STATUS_PARTIAL else "failed"

    def _log_email(self, addresses: Sequence[str], title: str, text: str, status: str,
                   error: Optional[str], a: Mapping[str, Any]) -> None:
        for addr in addresses:
            try:
                self.db.log_notification(
                    event_type=EVENT_TYPE, channel="email", recipient=addr, status=status,
                    title=title, message=text, error_message=error,
                    payload={"alert_id": a.get("id"), "job_id": a.get("job_id"), "kind": a.get("kind")})
            except Exception as exc:  # noqa: BLE001 - history is a courtesy; the ledger is the record
                logger.debug("%s notification_log write for %s failed: %s", LOG_PREFIX, addr, exc)

    @staticmethod
    def _render(a: Mapping[str, Any], job: Optional[Mapping[str, Any]], severity: str, kind: str):
        job_label = (f"job '{job.get('name')}' (#{job.get('id')})" if job
                     else (f"job #{a.get('job_id')} (no longer exists)" if a.get("job_id") is not None
                           else "the Clockwork deployment"))
        known = kind in KIND_SEVERITY
        title = f"[Clockwork {severity.upper()}] {kind} on {job_label}"
        lines = [
            f"Severity: {severity}" + ("" if known else f"  (kind {kind!r} is not one this notifier "
                                                       f"classifies; treated as {DEFAULT_SEVERITY})"),
            f"Alert: {kind}",
            f"Where: {job_label}",
            f"Deployment: {a.get('deployment_id') or '(authoring plane)'}",
            f"Message: {a.get('message') or ''}",
            f"First seen: {a.get('first_seen_at')}   Last seen: {a.get('last_seen_at')}   "
            f"Occurrences: {a.get('count')}",
        ]
        if severity == SEVERITY_CRITICAL:
            lines.append("Action: a person must confirm what happened BEFORE anyone re-drives it; "
                         "a re-driven lost answer is a duplicate side effect.")
        elif severity == SEVERITY_WARNING:
            lines.append("Action: nothing was run.  Fix the job's configuration; the alert clears when "
                         "it is acknowledged on the Clockwork alerts page.")
        else:
            lines.append("Action: see the fire log and the alerts page; acknowledge the alert once handled.")
        lines.append("You are told ONCE per alert; a repeat of the same alert does not re-notify until "
                     "it has been acknowledged and recurs.")
        return title, "\n".join(lines)


# ── the daemon ───────────────────────────────────────────────────────────

_notifier: Optional[AlertNotifier] = None
#: built lazily beside the notifier; the type is imported inside
#: run_notifier_once so this module stays importable on its own.
_silence: Optional[Any] = None


def run_notifier_once(db_manager: Any) -> Dict[str, int]:
    """One pass with the module's notifier (built on first use).

    The SILENCE WATCH runs FIRST, in the same pass, because the fact it
    raises is one this pass should then deliver -- a dead pod raises
    nothing itself (see ``core/clockwork/silence.py``), so without this
    call the only witness to a scheduler nobody is driving would be a
    human opening a screen.  It is advisory and fails open: its own
    counters are returned under ``silence_*`` so a caller can see it ran
    rather than infer it from nothing happening.
    """
    from core.config import get as _get
    from core.clockwork.silence import SilenceWatch

    global _notifier, _silence
    if _notifier is None or _notifier.db is not db_manager:
        _notifier = AlertNotifier(db_manager)
        _silence = None
    if _silence is None or _silence.db is not db_manager:
        _silence = SilenceWatch(
            db_manager,
            silent_seconds=int(_get("clockwork", "deployment_silent_seconds", 600) or 0))
    counters = dict(_notifier.run_once())
    for key, value in _silence.run_once().items():
        counters[f"silence_{key}"] = value
    return counters


def register_notifier_daemon(scheduler: Any, db_manager: Any) -> Optional[str]:
    """Put the notifier on the daemon scheduler as an interval job.

    Always registers; the tick itself checks ``clockwork.notify_enabled``
    and the admin pause on every pass, so a flag flip takes effect on the
    next tick without a restart (the pruning-alerts daemon's shape).
    Returns the job id, or None when there is no scheduler to register on.
    """
    if scheduler is None:
        return None
    settings = Settings.from_config()

    def _tick() -> Any:
        # Returns the pass's counters (2026-10-07) for the background-job
        # ledger; a pause / disabled flag says so instead of returning None.
        try:
            from core.background_jobs import is_paused
            if is_paused(DAEMON_NAME):
                return {"status": "skipped", "reason": "paused by admin"}
        except Exception as exc:  # noqa: BLE001 - an unreadable pause flag means "running"
            logger.debug("%s pause check unavailable (running): %s", LOG_PREFIX, exc)
        try:
            if not Settings.from_config().enabled:
                logger.debug("%s disabled by clockwork.notify_enabled", LOG_PREFIX)
                return {"status": "skipped", "reason": "clockwork.notify_enabled is false"}
            counters = run_notifier_once(db_manager)
            if counters["notified"] or counters["unrouted"] or counters["failed"] or counters["errors"]:
                logger.info("%s pass: %s", LOG_PREFIX, counters)
            return counters
        except Exception as exc:  # noqa: BLE001 - never take the scheduler thread down
            logger.error("%s pass failed: %s: %s", LOG_PREFIX, type(exc).__name__, exc)
            return {"error": f"{type(exc).__name__}: {exc}"[:300]}

    scheduler.add_job(_tick, "interval", seconds=settings.poll_seconds, id=DAEMON_NAME,
                      replace_existing=True, max_instances=1, coalesce=True)
    logger.info("%s daemon scheduled every %ds (job_id=%s, enabled=%s, fallback_emails=%d, "
                "fallback_usernames=%d)", LOG_PREFIX, settings.poll_seconds, DAEMON_NAME,
                settings.enabled, len(settings.fallback_emails), len(settings.fallback_usernames))
    return DAEMON_NAME


__all__ = ["AlertNotifier", "Recipients", "Settings", "KIND_SEVERITY", "DEFAULT_SEVERITY",
           "SEVERITY_CRITICAL", "SEVERITY_ERROR", "SEVERITY_WARNING", "severity_of",
           "resolve_recipients", "run_notifier_once", "register_notifier_daemon",
           "DAEMON_NAME", "EVENT_TYPE", "LOG_PREFIX"]
