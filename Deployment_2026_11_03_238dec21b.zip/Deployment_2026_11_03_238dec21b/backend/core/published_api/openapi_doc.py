"""ONE published API as an OpenAPI 3.0 document (2026-10-23).

The owner: "someone wants to plug in [an] api test ui".  A consumer team's
tool -- Postman, Swagger UI, Hoppscotch, their own -- imports an OpenAPI
document.  The app's global spec (``/openapi.json``) describes every route of
the product; a consumer needs THEIR view: its columns, its filters, its
parameters, its limits, its errors.

Built ONLY from the view's own meta answer (``GET /api/v1/views/{slug}``, the
SAME access check, lifecycle and limits a call meets), so the document can
never promise what the API does not serve.  Pure: no database, no request.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

OPENAPI_VERSION = "3.0.3"

#: QueryStudio column type words -> JSON Schema.
_JSON_TYPES = {
    "integer": {"type": "integer"}, "int": {"type": "integer"}, "bigint": {"type": "integer"},
    "smallint": {"type": "integer"}, "tinyint": {"type": "integer"},
    "number": {"type": "number"}, "float": {"type": "number"}, "double": {"type": "number"},
    "decimal": {"type": "number"}, "numeric": {"type": "number"}, "real": {"type": "number"},
    "boolean": {"type": "boolean"}, "bool": {"type": "boolean"},
    "date": {"type": "string", "format": "date"},
    "timestamp": {"type": "string", "format": "date-time"},
    "datetime": {"type": "string", "format": "date-time"},
}

FILTER_OPERATORS = ("eq", "ne", "gt", "gte", "lt", "lte", "in", "not_in", "contains", "between")


def _schema_for(type_word: Any) -> Dict[str, Any]:
    t = str(type_word or "string").strip().lower()
    base = t.split("(", 1)[0].strip()
    for key in (t, base):
        if key in _JSON_TYPES:
            return dict(_JSON_TYPES[key], nullable=True)
    if base.startswith("timestamp"):
        return {"type": "string", "format": "date-time", "nullable": True}
    return {"type": "string", "nullable": True}


def _filter_names(allowed: Any) -> List[str]:
    out: List[str] = []
    for f in (allowed or []):
        name = f.get("column") or f.get("name") if isinstance(f, dict) else f
        if name and str(name) not in out:
            out.append(str(name))
    return out


def _param(name: str, schema: Dict[str, Any], description: str, *, example: Any = None) -> Dict[str, Any]:
    p = {"name": name, "in": "query", "required": False, "schema": schema, "description": description}
    if example is not None:
        p["example"] = example
    return p


def build_view_openapi(meta: Dict[str, Any], *, server_url: str) -> Dict[str, Any]:
    """The OpenAPI document of ONE published view, from its meta answer."""
    slug = str(meta.get("slug") or "")
    cols = [c for c in (meta.get("columns") or []) if isinstance(c, dict) and c.get("name")]
    row_schema = {"type": "object",
                  "properties": {str(c["name"]): _schema_for(c.get("type")) for c in cols}}
    if not cols:
        row_schema["description"] = ("The column list was not recorded yet: call the API once "
                                     "(or GET the view's meta) and fetch this document again.")
    by_name = {str(c["name"]).lower(): c for c in cols}

    filters = []
    for name in _filter_names(meta.get("allowed_filters")):
        col = by_name.get(name.lower())
        filters.append(_param(
            f"filter.{name}", {"type": "string"},
            f"Filter on {name}"
            + (f" ({col.get('type')})" if col else "")
            + f". Form: operator:value, operators {', '.join(FILTER_OPERATORS)} -- "
              f"e.g. eq:VALUE, in:A,B, between:LOW,HIGH.",
            example="eq:VALUE"))
    params = []
    for pd in (meta.get("param_definitions") or []):
        if not isinstance(pd, dict) or not pd.get("name"):
            continue
        params.append(dict(_param(
            str(pd["name"]), _schema_for(pd.get("type")),
            str(pd.get("description") or pd.get("label") or f"Parameter {pd['name']}")
            + (" (required)" if pd.get("required") else "")),
            required=bool(pd.get("required"))))

    default_limit, max_limit = meta.get("default_limit"), meta.get("max_limit")
    paging = [
        _param("limit", {"type": "integer", "minimum": 0,
                         **({"maximum": max_limit} if isinstance(max_limit, int) and max_limit > 0 else {}),
                         **({"default": default_limit} if isinstance(default_limit, int) else {})},
               "Rows per page."),
        _param("offset", {"type": "integer", "minimum": 0, "default": 0},
               "Rows to skip. Follow pagination.next_offset; past the ceiling the answer is 416."),
        _param("sort", {"type": "string"}, "Column to order by; prefix '-' for descending."),
        _param("columns", {"type": "string"}, "Comma-separated columns to return."),
        _param("dataset_version", {"type": "string"},
               "The X-QS-Dataset-Version of page 1: every later page must come from the same "
               "data, or the answer is 409 (start again from offset 0)."),
    ]
    if meta.get("time_travel_supported"):
        _tables = [str(t.get("table")) for t in (meta.get("table_versions") or []) if t.get("table")]
        paging += [_param("snapshot_id", {"type": "integer"},
                          "Read this Iceberg snapshot (every Iceberg table of the view). "
                          "Prefer version.<table> to name the table."),
                   _param("as_of_timestamp", {"type": "string", "format": "date-time"},
                          "Read the snapshot current at this time (every table)."),
                   _param("as_of", {"type": "string", "format": "date-time"},
                          "Read every Iceberg table at the version current at this time; "
                          "each table (each side of a two-source view) is resolved on its own.")]
        for _t in _tables:
            paging.append(_param(f"version.{_t}", {"type": "string"},
                                 f"Read {_t} at this snapshot id, or 'latest', or at the version "
                                 f"current at this time (ISO 8601). List its versions at "
                                 f"GET /api/v1/views/{{slug}}/versions?table={_t}. A version the "
                                 f"table does not have is refused (422), never today's data."))

    def _err(desc: str) -> Dict[str, Any]:
        return {"description": desc, "content": {"application/json": {"schema": {
            "type": "object", "properties": {"detail": {}}}}}}

    errors = {
        "401": _err("No or invalid credentials (send the X-API-Key header)."),
        "403": _err("This key may not call this API."),
        "404": _err("No such API (or not offered yet)."),
        "409": _err("dataset_version no longer matches: start again from offset 0."),
        "410": _err("This API is retired."),
        "416": _err("offset is at or past the paged ceiling: continue with the bulk endpoint."),
        "429": _err("Rate limit: retry after the Retry-After seconds."),
        "503": _err("Busy or the source is unreachable: retry after the Retry-After seconds."),
    }
    envelope = {"type": "object", "properties": {
        "data": {"type": "array", "items": row_schema},
        "total_rows": {"type": "integer"},
        "pagination": {"type": "object", "properties": {
            "offset": {"type": "integer"}, "limit": {"type": "integer"},
            "has_more": {"type": "boolean"}, "next_offset": {"type": "integer", "nullable": True},
            "dataset_version": {"type": "string"},
            "truncated_at": {"type": "integer", "nullable": True},
            "continue_with": {"type": "string", "nullable": True}}},
        "meta": {"type": "object"}}}
    lifecycle = meta.get("lifecycle") or {}
    desc_bits = [str(meta.get("description") or "").strip(),
                 f"{len(cols)} column(s). Authenticate with the X-API-Key header."]
    if isinstance(lifecycle, dict) and lifecycle.get("status") == "deprecated":
        desc_bits.append(f"DEPRECATED{(' -- sunset ' + str(lifecycle.get('sunset_at'))) if lifecycle.get('sunset_at') else ''}.")
    return {
        "openapi": OPENAPI_VERSION,
        "info": {"title": str(meta.get("name") or slug), "version": str(meta.get("version") or 1),
                 "description": " ".join(b for b in desc_bits if b)},
        "servers": [{"url": server_url.rstrip("/")}],
        "components": {"securitySchemes": {
            "ApiKey": {"type": "apiKey", "in": "header", "name": "X-API-Key"}}},
        "security": [{"ApiKey": []}],
        "paths": {
            f"/api/v1/views/{slug}": {"get": {
                "summary": "What this API serves: columns, filters, limits, lifecycle",
                "operationId": "meta", "responses": {"200": {"description": "The API's description"},
                                                     **{k: errors[k] for k in ("401", "403", "404", "410")}}}},
            f"/api/v1/views/{slug}/data": {"get": {
                "summary": "Rows, one page at a time",
                "operationId": "data",
                "parameters": paging + filters + params + [
                    _param("format", {"type": "string", "enum": ["json", "csv", "parquet", "excel"],
                                      "default": "json"}, "Answer format.")],
                "responses": {"200": {"description": "One page of rows",
                                      "content": {"application/json": {"schema": envelope}}},
                              **errors}}},
            f"/api/v1/views/{slug}/bulk": {"get": {
                "summary": "Every row, streamed (past the paged ceiling)",
                "operationId": "bulk",
                "parameters": filters + params + [
                    _param("format", {"type": "string", "enum": ["csv", "jsonl", "json", "arrow", "parquet"]},
                           "Stream format.")],
                "responses": {"200": {"description": "The whole result, streamed"},
                              **{k: errors[k] for k in ("401", "403", "404", "410", "429", "503")}}}},
        },
    }


def server_url_of(request: Optional[Any]) -> str:
    """The base URL the caller reached this API on (behind a proxy, the
    forwarded host/proto)."""
    if request is None:
        return ""
    h = request.headers
    proto = h.get("x-forwarded-proto") or request.url.scheme
    host = h.get("x-forwarded-host") or h.get("host") or request.url.netloc
    return f"{proto}://{host}"
