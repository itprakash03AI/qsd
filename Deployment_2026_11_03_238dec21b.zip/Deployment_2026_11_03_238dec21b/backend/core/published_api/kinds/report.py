"""The ``published_report`` kind: a published finance report reached from
OUTSIDE by an embed token (``/api/embedded-business-report/{token}/*``) or a
share token (``/api/business-reports/shared/{token}/download-*``); the tokens
are its consumers.  A report is listed when it is published OR a token was
ever minted for it (an unpublished report whose tokens still exist answers
410 -- that is exactly what the inventory should show).
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.published_api.contract import (
    ApiKind, BuildContext, Consumer, DEP_OK, DEP_UNPUBLISHED, Dependency, Endpoint, PublishedApi,
    health_from,
)
from core.published_api.impact import DependencyResolver, connection_ids_of_dataset
from core.published_api.lifecycle import lifecycle_of

REPORT_ENDPOINTS = (
    ("GET", "/api/embedded-business-report/{token}", ["json"]),
    ("POST", "/api/embedded-business-report/{token}/execute", ["json"]),
    ("POST", "/api/embedded-business-report/{token}/parameter-values", ["json"]),
    ("GET", "/api/business-reports/embedded/{token}/download-{pdf|excel|csv}", ["pdf", "excel", "csv"]),
    ("GET", "/api/business-reports/shared/{token}/download-{pdf|excel|csv}", ["pdf", "excel", "csv"]),
)
REPORT_AUTH = ["embed token", "share token"]


class PublishedReportKind(ApiKind):
    kind = "published_report"

    def __init__(self):
        from core.db.models import BusinessReport
        self.model = BusinessReport

    def rows(self, session) -> list:
        from core.db.models import BusinessReportShareToken, ReportEmbedToken
        from sqlalchemy import or_
        tok_ids = {int(r[0]) for r in session.query(ReportEmbedToken.report_id).distinct().all()}
        tok_ids |= {int(r[0]) for r in session.query(BusinessReportShareToken.report_id).distinct().all()}
        # published, OR a token was ever minted for it, OR its API lifecycle was
        # ever set (a retired report API stays listed as retired)
        conds = [self.model.is_published == True, self.model.api_lifecycle_status.isnot(None)]  # noqa: E712
        if tok_ids:
            conds.append(self.model.id.in_(list(tok_ids)))
        # a SWITCHED-OFF report (deleted, 2026-10-30) is no API any more
        from core.config_active import active_clause
        return (session.query(self.model).filter(or_(*conds), active_clause(self.model))
                .order_by(self.model.id).all())

    def is_offered(self, row) -> bool:
        return bool(getattr(row, "is_published", False)) and getattr(row, "lifecycle_status", None) != "archived"

    def set_offered(self, row, offered: bool) -> None:
        # the report's INTERNAL publish lifecycle is its own (draft / published /
        # archived, core/reports/versions.py); the API lifecycle rides is_published
        row.is_published = bool(offered)
        if offered and getattr(row, "lifecycle_status", None) in (None, "draft"):
            row.lifecycle_status = "published"
        if not offered and getattr(row, "lifecycle_status", None) == "published":
            row.lifecycle_status = "draft"

    def owner_of(self, row):
        return getattr(row, "owner", None)

    def endpoints(self, row) -> List[Endpoint]:
        return [Endpoint(method=m, path=p, formats=list(f), auth=list(REPORT_AUTH)) for m, p, f in REPORT_ENDPOINTS]

    def build(self, session, rows: list, ctx: BuildContext) -> List[PublishedApi]:
        if not rows:
            return []
        from core.db.models import (
            BusinessReportShareToken, BusinessReportVersion, RLSPolicy, ReportEmbedToken, ReportParameter,
            UserGroup,
        )
        ids = [int(r.id) for r in rows]
        res = DependencyResolver(session)
        ds_ids, conn_ids, pv_ids, fv_ids, sq_ids, sf_ids, grp_ids = set(), set(), set(), set(), set(), set(), set()
        for r in rows:
            for d in (r.dataset_id, r.merged_dataset_id):
                if d:
                    ds_ids.add(d)
            for c in (r.raw_connection_override_id, r.secondary_connection_id):
                if c:
                    conn_ids.add(c)
            if r.published_view_id:
                pv_ids.add(r.published_view_id)
            if r.federation_view_id:
                fv_ids.add(r.federation_view_id)
            if r.raw_saved_query_id:
                sq_ids.add(r.raw_saved_query_id)
            if r.raw_sql_file_id:
                sf_ids.add(r.raw_sql_file_id)
            if r.owner_group_id:
                grp_ids.add(r.owner_group_id)
        res.load("dataset", ds_ids)
        for did in ds_ids:
            ds = res.get("dataset", did)
            if ds is not None:
                conn_ids.update(connection_ids_of_dataset(ds))
        res.load("federation_view", fv_ids)
        res.load("saved_query", sq_ids)
        res.load("sql_file", sf_ids)
        res.load("connection", conn_ids)
        # a view that a report reads is a dependency of the report; the view kind
        # is this inventory's own, read directly
        views: Dict[int, Any] = {}
        if pv_ids:
            try:
                from core.db.models import PublishedView
                views = {int(v.id): v for v in session.query(PublishedView).filter(PublishedView.id.in_(list(pv_ids))).all()}
            except Exception as exc:                        # noqa: BLE001
                ctx.problems.append(f"published views unreadable: {exc}")
        groups: Dict[int, str] = {}
        if grp_ids:
            try:
                groups = {int(g.id): str(g.name) for g in session.query(UserGroup).filter(UserGroup.id.in_(list(grp_ids))).all()}
            except Exception as exc:                        # noqa: BLE001
                ctx.problems.append(f"user groups unreadable: {exc}")

        # tokens, parameters, policies, versions: one query each
        tokens: Dict[int, List[Consumer]] = {}
        try:
            for t in session.query(ReportEmbedToken).filter(ReportEmbedToken.report_id.in_(ids)).all():
                tokens.setdefault(int(t.report_id), []).append(Consumer(
                    kind="token", id=f"token:{str(t.token)[:8]}", name=f"embed token {str(t.token)[:8]}",
                    owner=t.created_by, is_active=bool(t.is_active),
                    expires_at=t.expires_at.isoformat() if t.expires_at else None,
                    identity=f"token:{str(t.token)[:8]}"))
            for t in session.query(BusinessReportShareToken).filter(BusinessReportShareToken.report_id.in_(ids)).all():
                tokens.setdefault(int(t.report_id), []).append(Consumer(
                    kind="token", id=f"token:{str(t.token)[:8]}", name=f"share token {str(t.token)[:8]}",
                    owner=t.created_by, is_active=bool(t.is_active),
                    expires_at=t.expires_at.isoformat() if t.expires_at else None,
                    identity=f"token:{str(t.token)[:8]}"))
        except Exception as exc:                            # noqa: BLE001
            ctx.problems.append(f"report tokens unreadable: {exc}")
        params: Dict[int, List[dict]] = {}
        try:
            for p in session.query(ReportParameter).filter(ReportParameter.report_id.in_(ids)).order_by(
                    ReportParameter.sort_order, ReportParameter.id).all():
                params.setdefault(int(p.report_id), []).append({
                    "name": p.name, "type": p.parameter_type, "required": bool(p.is_required),
                    "default": p.default_value})
        except Exception as exc:                            # noqa: BLE001
            ctx.problems.append(f"report parameters unreadable: {exc}")
        rls: Dict[int, List[str]] = {}
        rls_error = None
        try:
            for p in session.query(RLSPolicy).filter(RLSPolicy.report_id.in_(ids)).all():
                if getattr(p, "is_enabled", True):
                    rls.setdefault(int(p.report_id), []).append(f"report: {p.column_name} {p.operator}")
        except Exception as exc:                            # noqa: BLE001
            rls_error = str(exc)
            ctx.problems.append(f"report RLS policies unreadable: {exc}")
        versions: Dict[int, int] = {}
        versions_error = None
        try:
            from sqlalchemy import func
            for rid, vmax in session.query(BusinessReportVersion.report_id, func.max(BusinessReportVersion.version_no)) \
                    .filter(BusinessReportVersion.report_id.in_(ids)).group_by(BusinessReportVersion.report_id).all():
                versions[int(rid)] = int(vmax)
        except Exception as exc:                            # noqa: BLE001
            versions_error = str(exc)
            ctx.problems.append(f"report versions unreadable: {exc}")

        out: List[PublishedApi] = []
        for r in rows:
            deps, connections = self._dependencies(r, res, views, versions, versions_error)
            offered = self.is_offered(r)
            ds = res.get("dataset", r.dataset_id) if r.dataset_id else None
            api = PublishedApi(
                api_kind=self.kind, api_id=int(r.id), key=str(r.slug or r.id), name=str(r.name),
                description=r.description, owner=r.owner,
                owner_group=groups.get(int(r.owner_group_id)) if r.owner_group_id else None,
                source={"kind": "dataset", "id": r.dataset_id, "name": getattr(ds, "name", None) if ds is not None else None,
                        "word": "dataset", "data_source_type": r.data_source_type},
                connections=connections, endpoints=self.endpoints(r),
                parameters=params.get(int(r.id), []), filters=[],
                definition_version=versions.get(int(r.id)), schema_version=None, schema_changed_at=None,
                rls=({"mode": "unknown", "policies": [], "reason": f"the row-security policies could not be read: {rls_error}"}
                     if rls_error else
                     {"mode": "per_caller" if rls.get(int(r.id)) else "none_declared", "policies": rls.get(int(r.id), []),
                      "reason": None if rls.get(int(r.id)) else "no RLS policy names this report",
                      "posture": "a token principal is low-privilege by construction; an embed token may carry a group scope"}),
                consumers=tokens.get(int(r.id), []), lifecycle=lifecycle_of(r, offered),
                health=health_from(deps), dependencies=deps,
                created_by=r.owner,
                created_at=r.created_at.isoformat() if r.created_at else None,
                updated_at=r.updated_at.isoformat() if r.updated_at else None,
            )
            aud = ctx.audit.get(("business_report", str(r.id))) or {}
            api.last_changed_by, api.last_changed_at = aud.get("username"), aud.get("timestamp")
            num = ctx.numbers.get((self.kind, int(r.id)))
            if ctx.numbers_error:
                api.last_call = {"state": "unknown", "reason": ctx.numbers_error}
            elif num:
                api.last_call = {"at": num.get("last_call_at"), "state": "known"}
                api.calls_7d = num.get("calls_7d")
            else:
                api.last_call = {"at": None, "state": "none_recorded"}
                api.calls_7d = 0
            out.append(api)
        return out

    @staticmethod
    def _dependencies(r, res: DependencyResolver, views: Dict[int, Any], versions: Dict[int, int],
                      versions_error):
        deps: List[Dependency] = []
        connections: List[Dict[str, Any]] = []

        def _conn(cid, role, via=None):
            d = res.dependency("connection", cid, role=role, via=via)
            deps.append(d)
            connections.append({"id": d.id, "name": d.name, "role": role, "state": d.state})

        dst = r.data_source_type or "saved_query"
        if dst in ("saved_query", "dataset"):
            d = res.dependency("dataset", r.dataset_id, role="dataset")
            deps.append(d)
            ds = res.get("dataset", r.dataset_id) if r.dataset_id else None
            if ds is not None:
                for cid in connection_ids_of_dataset(ds):
                    _conn(cid, "primary", via=f"dataset #{ds.id}")
            if r.merged_dataset_id:
                deps.append(res.dependency("dataset", r.merged_dataset_id, role="merged_dataset"))
        elif dst == "published_view":
            if r.published_view_id and int(r.published_view_id) in views:
                v = views[int(r.published_view_id)]
                deps.append(Dependency(kind="published_view", id=int(v.id), name=str(v.slug), role="source",
                                       state=DEP_OK if v.is_active else DEP_UNPUBLISHED,
                                       reason=None if v.is_active else "the view is not active"))
            else:
                deps.append(Dependency(kind="published_view", id=r.published_view_id, role="source",
                                       state="missing" if r.published_view_id else "missing",
                                       reason=f"published view #{r.published_view_id} does not exist"
                                       if r.published_view_id else "no reference stored"))
        elif dst == "federation_view":
            deps.append(res.dependency("federation_view", r.federation_view_id, role="source"))
            fv = res.get("federation_view", r.federation_view_id) if r.federation_view_id else None
            if fv is not None:
                for cid, role in ((getattr(fv, "primary_conn_id", None), "primary"),
                                  (getattr(fv, "secondary_conn_id", None), "secondary")):
                    if cid:
                        _conn(cid, role, via=f"federation_view #{fv.id}")
        elif dst == "raw_sql":
            if r.raw_sql_file_id:
                deps.append(res.dependency("sql_file", r.raw_sql_file_id, role="source"))
                sf = res.get("sql_file", r.raw_sql_file_id)
                if sf is not None and getattr(sf, "connection_id", None) and not r.raw_connection_override_id:
                    _conn(sf.connection_id, "primary", via=f"sql_file #{sf.id}")
            elif r.raw_saved_query_id:
                deps.append(res.dependency("saved_query", r.raw_saved_query_id, role="source"))
            if r.raw_connection_override_id:
                _conn(r.raw_connection_override_id, "primary")
        if r.secondary_connection_id:
            _conn(r.secondary_connection_id, "secondary")
        # the published VERSION is what a token runs
        if versions_error:
            deps.append(Dependency(kind="report_version", id=None, role="published_version", state="unknown",
                                   reason=f"could not read the versions: {versions_error}"))
        elif getattr(r, "is_published", False):
            v = versions.get(int(r.id))
            deps.append(Dependency(kind="report_version", id=v, name=f"v{v}" if v else None, role="published_version",
                                   state=DEP_OK if v else DEP_UNPUBLISHED,
                                   reason=None if v else "published with no version row (consumers get 410)"))
        return deps, connections


def register(registry) -> None:
    registry.register(PublishedReportKind())
