"""The ``published_view`` kind: a published view is the REST API
``/api/v1/views/{slug}/*`` (+ GraphQL ``publishedViewData``, + bulk);
its consumers are the API keys that may call it and the AD groups it allows.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.published_api.contract import (
    ApiKind, BuildContext, Consumer, Dependency, Endpoint, PublishedApi, health_from,
)
from core.published_api.impact import DependencyResolver, connection_ids_of_dataset
from core.published_api.lifecycle import lifecycle_of

VIEW_ENDPOINTS = (
    ("GET", "/api/v1/views/{slug}", ["json"]),
    ("GET", "/api/v1/views/{slug}/data", ["json", "csv", "parquet", "excel"]),
    ("GET", "/api/v1/views/{slug}/data.csv", ["csv"]),
    ("GET", "/api/v1/views/{slug}/data.parquet", ["parquet"]),
    ("GET", "/api/v1/views/{slug}/bulk", ["parquet", "jsonl", "arrow", "csv"]),
    ("GET", "/api/v1/views/{slug}/bulk/manifest", ["json"]),
    ("POST", "/api/v1/views/{slug}/bulk/prepare", ["json"]),
    ("GET", "/api/v1/views/{slug}/bulk/download", ["parquet"]),
    ("POST", "/graphql  publishedViewData(slug)", ["json"]),
)
VIEW_AUTH = ["X-API-Key", "Basic (AD)", "Bearer (session)"]

SOURCE_WORDS = {"saved_query": "saved query", "business_report": "finance report",
                "federation": "federation view", "sql_file": "SQL file"}


class PublishedViewKind(ApiKind):
    kind = "published_view"

    def __init__(self):
        from core.db.models import PublishedView
        self.model = PublishedView

    def rows(self, session) -> list:
        return session.query(self.model).order_by(self.model.id).all()

    def is_offered(self, row) -> bool:
        return bool(getattr(row, "is_active", False))

    def set_offered(self, row, offered: bool) -> None:
        row.is_active = bool(offered)

    def endpoints(self, row) -> List[Endpoint]:
        slug = str(row.slug)
        return [Endpoint(method=m, path=p.replace("{slug}", slug), formats=list(f), auth=list(VIEW_AUTH))
                for m, p, f in VIEW_ENDPOINTS]

    # -- the build ------------------------------------------------------------------
    def build(self, session, rows: list, ctx: BuildContext) -> List[PublishedApi]:
        if not rows:
            return []
        res = DependencyResolver(session)
        # first hop: every id the views name, one query per kind
        conn_ids, q_ids, br_ids, fv_ids, sf_ids = set(), set(), set(), set(), set()
        for r in rows:
            for c in (r.connection_id, r.execution_connection_id):
                if c:
                    conn_ids.add(c)
            for c in (r.allowed_engine_connections or []):
                if isinstance(c, (int, str)) and str(c).strip().isdigit():
                    conn_ids.add(int(c))
            if r.query_id:
                q_ids.add(r.query_id)
            if r.business_report_id:
                br_ids.add(r.business_report_id)
            if r.federation_view_id:
                fv_ids.add(r.federation_view_id)
            if r.sql_file_id:
                sf_ids.add(r.sql_file_id)
        res.load("saved_query", q_ids)
        res.load("business_report", br_ids)
        res.load("federation_view", fv_ids)
        res.load("sql_file", sf_ids)
        # second hop: a report's dataset, a file's / view's connections
        ds_ids = set()
        for rid in br_ids:
            br = res.get("business_report", rid)
            if br is not None and getattr(br, "dataset_id", None):
                ds_ids.add(br.dataset_id)
        res.load("dataset", ds_ids)
        for did in ds_ids:
            ds = res.get("dataset", did)
            if ds is not None:
                conn_ids.update(connection_ids_of_dataset(ds))
        for fid in sf_ids:
            sf = res.get("sql_file", fid)
            if sf is not None:
                for c in (getattr(sf, "connection_id", None), getattr(sf, "secondary_connection_id", None)):
                    if c:
                        conn_ids.add(c)
        for vid in fv_ids:
            fv = res.get("federation_view", vid)
            if fv is not None:
                for c in (getattr(fv, "primary_conn_id", None), getattr(fv, "secondary_conn_id", None)):
                    if c:
                        conn_ids.add(c)
        res.load("connection", conn_ids)

        schema = self._schema_versions(ctx, [r.id for r in rows])
        report_rls = self._report_rls(session, br_ids, ctx)
        conn_policies = self._connection_policies(session, conn_ids, ctx)
        from core.published_api.consumers import keys_for_view

        out: List[PublishedApi] = []
        for r in rows:
            deps, connections = self._dependencies(r, res)
            consumers = self._consumers(r, keys_for_view(ctx.keys, r.id))
            sv = schema.get(r.id) or {}
            api = PublishedApi(
                api_kind=self.kind, api_id=int(r.id), key=str(r.slug), name=str(r.name),
                description=r.description, owner=r.created_by, owner_group=None,
                source=self._source(r, res), connections=connections, endpoints=self.endpoints(r),
                parameters=list(r.param_definitions or []), filters=list(r.allowed_filters or []),
                definition_version=int(r.version) if r.version is not None else 1,
                schema_version=sv.get("version_no") if isinstance(sv.get("version_no"), int) else None,
                schema_changed_at=sv.get("created_at"),
                rls=self._rls(r, res, report_rls, conn_policies, connections),
                consumers=consumers, lifecycle=lifecycle_of(r, self.is_offered(r)),
                health=health_from(deps), dependencies=deps,
                created_by=r.created_by,
                created_at=r.created_at.isoformat() if r.created_at else None,
                updated_at=r.updated_at.isoformat() if r.updated_at else None,
            )
            aud = ctx.audit.get(("published_view", str(r.id))) or {}
            api.last_changed_by, api.last_changed_at = aud.get("username"), aud.get("timestamp")
            num = ctx.numbers.get((self.kind, int(r.id)))
            if ctx.numbers_error:
                api.last_call = {"state": "unknown", "reason": ctx.numbers_error}
                api.calls_7d = None
            elif num:
                api.last_call = {"at": num.get("last_call_at"), "state": "known"}
                api.calls_7d = num.get("calls_7d")
            else:
                api.last_call = {"at": None, "state": "none_recorded"}
                api.calls_7d = 0
            out.append(api)
        return out

    # -- helpers --------------------------------------------------------------------
    @staticmethod
    def _schema_versions(ctx: BuildContext, ids: list) -> Dict[int, dict]:
        try:
            got = ctx.db.latest_pv_schema_versions(ids)
            return got if isinstance(got, dict) else {}
        except Exception as exc:                            # noqa: BLE001
            ctx.problems.append(f"schema versions unreadable: {exc}")
            return {}

    @staticmethod
    def _report_rls(session, br_ids, ctx: BuildContext) -> Dict[int, List[str]]:
        """report id -> the enabled RLS policy columns of that report."""
        if not br_ids:
            return {}
        try:
            from core.db.models import RLSPolicy
            out: Dict[int, List[str]] = {}
            for p in session.query(RLSPolicy).filter(RLSPolicy.report_id.in_(list(br_ids))).all():
                if getattr(p, "is_enabled", True):
                    out.setdefault(int(p.report_id), []).append(f"{p.column_name} {p.operator}")
            return out
        except Exception as exc:                            # noqa: BLE001
            ctx.problems.append(f"report RLS policies unreadable: {exc}")
            return {"__error__": [str(exc)]}

    @staticmethod
    def _connection_policies(session, conn_ids, ctx: BuildContext) -> Dict[Any, List[str]]:
        """connection id (or None = every connection) -> enabled row-level policy names."""
        try:
            from core.config_active import active_clause
            from core.db.models import RowLevelPolicy
            out: Dict[Any, List[str]] = {}
            q = session.query(RowLevelPolicy).filter(RowLevelPolicy.enabled == True,  # noqa: E712
                                                     active_clause(RowLevelPolicy))
            for p in q.all():
                cid = p.connection_id
                if cid is None or (conn_ids and int(cid) in {int(c) for c in conn_ids}):
                    out.setdefault(None if cid is None else int(cid), []).append(f"{p.name} ({p.table_pattern})")
            return out
        except Exception as exc:                            # noqa: BLE001
            ctx.problems.append(f"row-level policies unreadable: {exc}")
            return {"__error__": [str(exc)]}

    def _dependencies(self, r, res: DependencyResolver):
        deps: List[Dependency] = []
        connections: List[Dict[str, Any]] = []

        def _conn(cid, role, via=None):
            d = res.dependency("connection", cid, role=role, via=via)
            deps.append(d)
            connections.append({"id": d.id, "name": d.name, "role": role, "state": d.state})

        if r.connection_id:
            _conn(r.connection_id, "primary")
        if r.execution_connection_id:
            _conn(r.execution_connection_id, "execution")
        for c in (r.allowed_engine_connections or []):
            if isinstance(c, (int, str)) and str(c).strip().isdigit():
                _conn(int(c), "engine")
        st = r.source_type or "saved_query"
        if st == "saved_query":
            deps.append(res.dependency("saved_query", r.query_id, role="source"))
        elif st == "business_report":
            d = res.dependency("business_report", r.business_report_id, role="source")
            deps.append(d)
            br = res.get("business_report", r.business_report_id) if r.business_report_id else None
            # a DATASET-backed report rests on its dataset (and the dataset's
            # connections); a raw-SQL / view / federation report does not
            if br is not None and (getattr(br, "data_source_type", None) or "saved_query") in ("saved_query", "dataset"):
                via = f"business_report #{br.id}"
                dd = res.dependency("dataset", getattr(br, "dataset_id", None), role="dataset", via=via)
                deps.append(dd)
                ds = res.get("dataset", br.dataset_id) if getattr(br, "dataset_id", None) else None
                if ds is not None:
                    for cid in connection_ids_of_dataset(ds):
                        _conn(cid, "primary", via=f"{via} -> dataset #{ds.id}")
            elif br is not None and getattr(br, "raw_connection_override_id", None):
                _conn(br.raw_connection_override_id, "primary", via=f"business_report #{br.id}")
        elif st == "federation":
            d = res.dependency("federation_view", r.federation_view_id, role="source")
            deps.append(d)
            fv = res.get("federation_view", r.federation_view_id) if r.federation_view_id else None
            if fv is not None:
                via = f"federation_view #{fv.id}"
                if getattr(fv, "primary_conn_id", None):
                    _conn(fv.primary_conn_id, "primary", via=via)
                if getattr(fv, "secondary_conn_id", None):
                    _conn(fv.secondary_conn_id, "secondary", via=via)
        elif st == "sql_file":
            d = res.dependency("sql_file", r.sql_file_id, role="source")
            deps.append(d)
            sf = res.get("sql_file", r.sql_file_id) if r.sql_file_id else None
            if sf is not None:
                via = f"sql_file #{sf.id}"
                if getattr(sf, "connection_id", None) and sf.connection_id != r.connection_id:
                    _conn(sf.connection_id, "primary", via=via)
                if getattr(sf, "secondary_connection_id", None):
                    _conn(sf.secondary_connection_id, "secondary", via=via)
        return deps, connections

    @staticmethod
    def _source(r, res: DependencyResolver) -> Dict[str, Any]:
        st = r.source_type or "saved_query"
        sid = {"saved_query": r.query_id, "business_report": r.business_report_id,
               "federation": r.federation_view_id, "sql_file": r.sql_file_id}.get(st)
        kind = {"saved_query": "saved_query", "business_report": "business_report",
                "federation": "federation_view", "sql_file": "sql_file"}.get(st, st)
        row = res.get(kind, sid) if sid else None
        name = None
        if row is not None:
            name = getattr(row, "name", None) or getattr(row, "file_path", None)
        return {"kind": kind, "id": sid, "name": name, "word": SOURCE_WORDS.get(st, st)}

    @staticmethod
    def _consumers(r, keys: list) -> List[Consumer]:
        from core.published_api.rate_limits import effective_rate_limit
        out: List[Consumer] = []
        for k in keys:
            eff = effective_rate_limit(k.get("rate_limit"))
            out.append(Consumer(
                kind="api_key", id=f"apikey:{k.get('id')}", name=str(k.get("name") or ""),
                owner=k.get("owner_username") or k.get("created_by"), consumer=k.get("consumer"),
                contact=k.get("contact_email"), scope=k.get("scope", "this_api"),
                is_active=bool(k.get("is_active", True)), expires_at=k.get("expires_at"),
                last_used_at=k.get("last_used_at"), identity=f"apikey:{k.get('id')}",
                rate_limit=k.get("rate_limit"), effective_rate_limit=eff["effective"],
                rate_limit_capped=eff["capped"], rate_limit_cap_reason=eff["reason"]))
        groups = [str(g) for g in (r.allowed_ad_groups or []) if str(g).strip()]
        if groups:
            for g in groups:
                out.append(Consumer(kind="ad_group", id=f"group:{g}", name=g, identity=f"group:{g}"))
        else:
            out.append(Consumer(kind="every_ad_user", id="*", name="every authenticated AD / session user",
                                identity="*"))
        return out

    @staticmethod
    def _rls(r, res, report_rls: Dict, conn_policies: Dict, connections: list) -> Dict[str, Any]:
        if "__error__" in report_rls or "__error__" in conn_policies:
            return {"mode": "unknown", "policies": [],
                    "reason": "the row-security policies could not be read"}
        policies: List[str] = []
        if (r.source_type or "") == "business_report" and r.business_report_id:
            policies += [f"report: {p}" for p in report_rls.get(int(r.business_report_id), [])]
        conn_ids = {c["id"] for c in connections if c.get("id") is not None}
        for cid, names in conn_policies.items():
            if cid is None or cid in conn_ids:
                policies += [f"connection{'' if cid is None else ' #' + str(cid)}: {n}" for n in names]
        posture = ("API-key callers are refused on a governed table (no directory identity); "
                   "AD / session callers are filtered by their groups")
        if not policies:
            return {"mode": "none_declared", "policies": [], "reason": "no row-level policy names this API's "
                    "report or connections", "posture": posture,
                    "credential_mode": r.credential_mode or "consumer"}
        return {"mode": "per_caller", "policies": policies, "reason": None, "posture": posture,
                "credential_mode": r.credential_mode or "consumer"}


def register(registry) -> None:
    registry.register(PublishedViewKind())
