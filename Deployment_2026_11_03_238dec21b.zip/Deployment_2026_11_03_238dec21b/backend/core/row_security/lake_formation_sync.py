"""Option C — sync row & column policies from AWS Lake Formation.

Reads LF data-cells filters via boto3 and upserts them into our
``row_level_policies`` / ``column_policies`` tables with
``source='lake_formation'``.  Once imported, enforcement is exactly the
same as a hand-authored policy (sqlglot rewrite) — LF is just a feed.

Bindings are derived from LF ``Permissions`` grants: principals on the
LF side (IAM users, IAM roles, AD groups via IdP integration) are
mapped to QueryStudio bindings according to a configurable
``principal_mapping``.

This module is import-safe even when boto3 isn't available — callers get
an explicit error from ``sync_connection`` rather than at import time.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class LakeFormationSyncError(RuntimeError):
    """Raised when an LF sync run cannot proceed (no boto3, no creds, etc.)."""


def _boto3_session(aws_creds: Dict[str, Any]):
    try:
        import boto3
    except ImportError as exc:
        raise LakeFormationSyncError(
            "boto3 not installed — cannot sync Lake Formation policies"
        ) from exc
    kwargs: Dict[str, Any] = {}
    if "region" in aws_creds:
        kwargs["region_name"] = aws_creds["region"]
    if "access_key" in aws_creds:
        kwargs["aws_access_key_id"] = aws_creds["access_key"]
    if "secret_key" in aws_creds:
        kwargs["aws_secret_access_key"] = aws_creds["secret_key"]
    if "session_token" in aws_creds:
        kwargs["aws_session_token"] = aws_creds["session_token"]
    return boto3.Session(**kwargs)


def _principal_for_lf(
    lf_principal: Dict[str, Any],
    principal_mapping: Optional[Callable[[Dict[str, Any]], Optional[Dict[str, str]]]] = None,
) -> Optional[Dict[str, str]]:
    """Translate an LF DataLakePrincipal into a QueryStudio binding.

    LF principals look like ``{"DataLakePrincipalIdentifier": "arn:aws:iam::..."}``.
    Default mapping rules:
      * ``arn:aws:iam::*:role/<RoleName>`` → ``role:<RoleName>``
      * ``arn:aws:iam::*:user/<UserName>`` → ``user:<UserName>``
      * Other identifiers (SAML, IdP groups) → ``group:<rest>``
    """
    if principal_mapping is not None:
        try:
            out = principal_mapping(lf_principal)
            if out:
                return out
        except Exception as exc:
            logger.debug("custom principal_mapping raised: %s", exc)

    ident = (lf_principal or {}).get("DataLakePrincipalIdentifier", "")
    if not ident:
        return None
    if ":role/" in ident:
        return {"principal_type": "role",
                "principal_id":   ident.rsplit(":role/", 1)[-1].split("/")[-1]}
    if ":user/" in ident:
        return {"principal_type": "user",
                "principal_id":   ident.rsplit(":user/", 1)[-1].split("/")[-1]}
    # Federated principals — best-effort group binding
    return {"principal_type": "group", "principal_id": ident.split("/")[-1]}


def _upsert_row_policy(
    db, *, connection_id: int, filter_name: str,
    table_pattern: str, filter_expr: str,
    external_id: str, updated_by: str,
) -> int:
    """Insert or update a row policy keyed by ``external_id``.  Returns policy id."""
    existing = db.get_row_policy_by_external("lake_formation", external_id)
    if existing and existing.get("is_active") is False:
        # 2026-10-30: deleting a policy now SWITCHES IT OFF.  A deleted
        # Lake Formation policy used to be re-imported by the next sync (the
        # filter still exists in Lake Formation -- it is the source of
        # truth, and an access-control import errs toward restricting).
        # Keep exactly that: the import switches it back on, then updates it.
        db.switch_on_imported_row_policy(existing["id"])
    if existing:
        updated = db.update_row_policy(
            existing["id"],
            table_pattern=table_pattern,
            filter_sql=filter_expr,
            description=f"Imported from Lake Formation: {filter_name}",
            updated_by=updated_by,
            connection_id=connection_id,
            enabled=True,
        )
        return updated["id"]
    created = db.create_row_policy(
        name=f"lf:{filter_name}",
        description=f"Imported from Lake Formation: {filter_name}",
        source="lake_formation",
        table_pattern=table_pattern,
        connection_id=connection_id,
        filter_sql=filter_expr,
        enforcement="rewrite",
        enabled=True,
        priority=100,
        created_by=updated_by,
        updated_by=updated_by,
        external_id=external_id,
        # FB-45 -- authored without a class, so it takes the configured
        # default; under per_policy a Lake Formation data filter is a GRANT
        # (LF filters union), and that is what it declares.
        policy_class=_lf_policy_class(),
    )
    return created["id"]


def _lf_policy_class() -> str:
    from core.row_security.composition import (
        PERMISSIVE, default_class_for_new_policy,
    )
    return default_class_for_new_policy() or PERMISSIVE


def _ensure_binding(
    db, policy_kind: str, policy_id: int,
    principal_type: str, principal_id: str,
    created_by: str,
) -> None:
    existing = db.list_policy_bindings(
        policy_kind=policy_kind,
        policy_id=policy_id,
        principal_type=principal_type,
        principal_id=principal_id,
    )
    if existing:
        return
    try:
        db.create_policy_binding(
            policy_kind=policy_kind,
            policy_id=policy_id,
            principal_type=principal_type,
            principal_id=principal_id,
            priority=100,
            created_by=created_by,
        )
    except Exception as exc:
        # Unique-constraint race is harmless
        logger.debug("create_policy_binding race for policy %s: %s", policy_id, exc)


def sync_connection(
    db,
    connection_id: int,
    aws_creds: Dict[str, Any],
    *,
    databases: Optional[List[str]] = None,
    principal_mapping: Optional[Callable[[Dict[str, Any]], Optional[Dict[str, str]]]] = None,
    updated_by: str = "system",
) -> Dict[str, Any]:
    """Sync LF data-cells filters for a single connection.

    Returns ``{"imported": N, "skipped": N, "errors": [...]}``.
    """
    session = _boto3_session(aws_creds)
    try:
        lf = session.client("lakeformation")
        glue = session.client("glue")
    except Exception as exc:
        raise LakeFormationSyncError(f"client init failed: {exc}") from exc

    imported = 0
    skipped = 0
    errors: List[str] = []

    if databases is None:
        try:
            paginator = glue.get_paginator("get_databases")
            databases = []
            for page in paginator.paginate():
                for db_meta in page.get("DatabaseList", []):
                    databases.append(db_meta["Name"])
        except Exception as exc:
            raise LakeFormationSyncError(f"could not list Glue databases: {exc}") from exc

    for db_name in databases:
        try:
            tables_resp = glue.get_paginator("get_tables").paginate(DatabaseName=db_name)
            for page in tables_resp:
                for tbl in page.get("TableList", []):
                    table_name = tbl["Name"]
                    table_pattern = f"{db_name}.{table_name}"
                    try:
                        filters_resp = lf.list_data_cells_filter(
                            Table={"DatabaseName": db_name, "Name": table_name},
                        )
                    except Exception as exc:
                        errors.append(f"list_data_cells_filter {table_pattern}: {exc}")
                        continue
                    for f in filters_resp.get("DataCellsFilters", []):
                        try:
                            fname = f.get("Name") or "unnamed"
                            external_id = f"{db_name}/{table_name}/{fname}"
                            row_expr = (f.get("RowFilter") or {}).get("FilterExpression") or "TRUE"
                            policy_id = _upsert_row_policy(
                                db,
                                connection_id=connection_id,
                                filter_name=fname,
                                table_pattern=table_pattern,
                                filter_expr=row_expr,
                                external_id=external_id,
                                updated_by=updated_by,
                            )
                            # Bindings — read LF permissions for this filter
                            try:
                                perms = lf.list_permissions(
                                    Resource={"DataCellsFilter": {
                                        "TableCatalogId": tbl.get("CatalogId"),
                                        "DatabaseName":   db_name,
                                        "TableName":      table_name,
                                        "Name":           fname,
                                    }},
                                )
                                for grant in perms.get("PrincipalResourcePermissions", []):
                                    p = _principal_for_lf(grant.get("Principal", {}),
                                                            principal_mapping)
                                    if not p:
                                        continue
                                    _ensure_binding(
                                        db, "row", policy_id,
                                        p["principal_type"], p["principal_id"],
                                        updated_by,
                                    )
                            except Exception as exc:
                                logger.debug("LF permissions read failed for %s: %s",
                                                external_id, exc)
                            imported += 1
                        except Exception as exc:
                            errors.append(f"{table_pattern}/{fname}: {exc}")
                            skipped += 1
        except Exception as exc:
            errors.append(f"db {db_name}: {exc}")
            continue

    return {"imported": imported, "skipped": skipped, "errors": errors}
