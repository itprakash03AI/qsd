"""
Connection Pooling — reuse SQL connectors to avoid 200-800ms setup per query.

Each (connection_id) gets its own pool of SqlConnector instances.
Connectors are lazily created, recycled on release, and evicted after idle timeout.

Usage:
    from core.connection_pool import get_pooled_connector

    with get_pooled_connector(connection_id, connection_type, config, name) as conn:
        result = conn.execute_query("SELECT 1")
"""
from __future__ import annotations

import hashlib
import logging
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# ── Module-level config ──────────────────────────────────────────────────────
_enabled = True
_max_size = 5
_idle_timeout = 300  # seconds
_initialised = False

#: Does anything actually ACQUIRE from the pool?  A module-level constant
#: rather than a runtime scan: flipping it is the single edit that says
#: "pooling is now wired", and ``tests/test_connection_pool_is_honest_
#: 2026_09_16.py`` fails if it disagrees with reality.
_CONTEXT_MANAGER_HAS_CALLERS = True


def init_connection_pool(enabled: bool = True, max_size: int = 5,
                         idle_timeout_seconds: int = 300) -> None:
    """Apply the ``connection_pool`` config.  2026-09-16: this had NO caller,
    so the three declared keys were read by nothing and the module defaults
    were the only values that ever applied."""
    global _enabled, _max_size, _idle_timeout, _initialised
    _enabled = enabled
    _max_size = max_size
    _idle_timeout = idle_timeout_seconds
    _initialised = True
    logger.info("Connection pool: enabled=%s max_size=%d idle_timeout=%ds",
                _enabled, _max_size, _idle_timeout)
    if enabled and not _CONTEXT_MANAGER_HAS_CALLERS:
        logger.warning(
            "connection_pool.enabled=true but pooling is INERT — "
            "get_pooled_connector() has no production caller, so every "
            "connection is still created fresh. %s", _ACQUISITION_SITES_NOTE)


@dataclass
class _PoolEntry:
    connector: Any
    last_used: float = field(default_factory=time.time)
    created_at: float = field(default_factory=time.time)


class ConnectorPool:
    """Thread-safe pool of SqlConnector instances for a single connection_id."""

    def __init__(self, connection_id: int, connection_type: str,
                 config: Dict[str, Any], connection_name: str = ""):
        self.connection_id = connection_id
        self.connection_type = connection_type
        self.config = config
        self.connection_name = connection_name
        self._idle: list[_PoolEntry] = []
        self._active_count: int = 0
        self._lock = threading.Lock()

    def acquire(self, timeout: float = 30.0) -> Any:
        """Get a connector from the pool or create a new one."""
        deadline = time.time() + timeout
        while True:
            with self._lock:
                # Evict expired idle connectors
                self._evict_expired()
                # Try to reuse an idle connector
                if self._idle:
                    entry = self._idle.pop()
                    entry.last_used = time.time()
                    self._active_count += 1
                    return entry.connector
                # Create new if under limit
                if self._active_count < _max_size:
                    self._active_count += 1
                    break  # create outside lock
            # Pool full — wait and retry
            if time.time() >= deadline:
                raise TimeoutError(
                    f"Connection pool for '{self.connection_name}' (id={self.connection_id}) "
                    f"exhausted — {_max_size} active connectors, timeout={timeout}s"
                )
            time.sleep(0.1)

        # Create new connector outside lock
        from core.connectors import get_connector
        try:
            connector = get_connector(
                self.connection_type, self.config,
                connection_id=self.connection_id,
                connection_name=self.connection_name,
            )
        except BaseException:
            # 2026-10-04, live: the slot was counted BEFORE the connector was
            # built, and a failed build (Vault unreachable, bad credentials, a
            # network blip) never gave it back -- five failures and the pool
            # was 'exhausted' for good, every later query on the connection
            # refused until the process restarted, long after the source
            # recovered.  A slot is held only by a connector that exists.
            with self._lock:
                self._active_count -= 1
            raise
        return connector

    def release(self, connector: Any) -> None:
        """Return a connector to the pool — but ONLY if it declares itself
        reusable and its reset succeeds.

        2026-09-16.  Handing one instance to a second caller is safe only
        when nothing of the first caller survives on it, and these
        instances DO carry per-caller state: ``set_execution_id`` binds the
        QueryStudio execution id that live source-DB status is attributed
        to, so a blind reuse reports execution B's progress against
        execution A.  Demonstrated rather than theorised -- turning pooling
        on made a test receive the previous test's connector with its
        fields still set.

        So: ``POOL_SAFE`` must be declared True by the connector CLASS, and
        ``reset_for_reuse()`` must complete.  Anything else is closed, which
        is exactly the un-pooled behaviour -- the safe direction, and the
        one this repo's RETRY_SAFE incident (50M duplicate rows from a
        default of true) says to take when reuse safety is unknown.
        """
        reusable = False
        if getattr(type(connector), "POOL_SAFE", False):
            try:
                connector.reset_for_reuse()
                reusable = True
            except Exception:                            # noqa: BLE001
                logger.warning(
                    "connector for '%s' (id=%s) failed reset_for_reuse — "
                    "discarding instead of pooling it",
                    self.connection_name, self.connection_id, exc_info=True)
        with self._lock:
            self._active_count = max(0, self._active_count - 1)
            if reusable and len(self._idle) < _max_size:
                self._idle.append(_PoolEntry(connector=connector))
            else:
                # Not reusable, or the pool is full — close it.
                self._safe_close(connector)

    def discard(self, connector: Any) -> None:
        """Discard a connector (e.g. after an error) — don't return to pool."""
        with self._lock:
            self._active_count = max(0, self._active_count - 1)
        self._safe_close(connector)

    def invalidate(self) -> None:
        """Close all idle connectors — called when connection config changes."""
        with self._lock:
            for entry in self._idle:
                self._safe_close(entry.connector)
            self._idle.clear()
        logger.info("Pool invalidated for connection %d (%s)",
                    self.connection_id, self.connection_name)

    def stats(self) -> dict:
        with self._lock:
            return {
                "connection_id": self.connection_id,
                "connection_name": self.connection_name,
                "idle": len(self._idle),
                "active": self._active_count,
                "max_size": _max_size,
            }

    def _evict_expired(self) -> None:
        """Remove idle connectors past the timeout (called under lock)."""
        now = time.time()
        still_good = []
        for entry in self._idle:
            if now - entry.last_used > _idle_timeout:
                self._safe_close(entry.connector)
            else:
                still_good.append(entry)
        self._idle = still_good

    @staticmethod
    def _safe_close(connector) -> None:
        try:
            connector.close()
        except Exception as e:
            logger.debug("Error closing pooled connector: %s", e)


def config_identity(connection_type: str, config: Dict[str, Any]) -> str:
    """A stable fingerprint of everything a connector is BUILT from.

    2026-09-16 — THE REASON POOLING COULD NOT SAFELY BE TURNED ON.
    ``get_pool`` used to key on ``connection_id`` alone and DISCARD the
    ``config`` of every call after the first.  This product resolves
    credentials per CALLER: ``_triggered_by_user`` is propagated into a
    destination config so the portal password vault can hand back that
    person's credentials, and system-account fallback rewrites config too.
    So two users querying the same connection arrive with different
    configs, and an id-only key would have handed user B a live connector
    authenticated as user A — a cross-user credential bleed, silently, on
    the very first reuse.

    Hashing the WHOLE config is deliberate over naming "the credential
    fields": a field added later that carries identity would silently
    rejoin the wrong pool, and this codebase has paid for exactly that kind
    of allowlist drift before.  Conservative by construction — identical
    inputs share a pool, ANY difference does not.  The cost is at worst a
    pool that is never reused, which is exactly today's behaviour.

    The digest is of a sorted repr, never logged and never returned to a
    caller, so it cannot become a way to read a secret back out.
    """
    try:
        payload = repr(sorted(
            (str(k), repr(v)) for k, v in dict(config or {}).items()))
    except Exception:                                   # pragma: no cover
        # Unhashable/exotic config -> a unique key, so it pools with
        # nothing.  Failing towards "no sharing" is the only safe direction
        # for a credential-bearing object.
        payload = repr(object())
    return hashlib.sha256(
        # A tuple repr rather than a separator character: no delimiter can
        # then be forged from inside a config value.
        repr((str(connection_type), payload)).encode("utf-8")).hexdigest()


class PoolManager:
    """Global registry of per-connection pools.

    Keyed by ``(connection_id, config_identity)`` — see
    :func:`config_identity` for why the second half is not optional.
    """

    def __init__(self):
        self._pools: Dict[tuple, ConnectorPool] = {}
        self._lock = threading.Lock()

    def get_pool(self, connection_id: int, connection_type: str,
                 config: Dict[str, Any], connection_name: str = "") -> ConnectorPool:
        # 2026-10-30 -- before handing out a pool, ask whether a PEER pod
        # changed a System Account or a connection since we last looked
        # (throttled; fail-open).  The pool key is the STORED config, which
        # does not change when Vault rotates a password, so without this an
        # idle connector built with the old password was reused for the
        # rest of its idle life (core/qs_credentials/freshness.py).
        try:
            from core.qs_credentials import freshness as _fresh
            _fresh.observe()
        except Exception as exc:                          # pragma: no cover
            logger.debug("pool: freshness observe failed (fail-open): %s", exc)
        key = (int(connection_id), config_identity(connection_type, config))
        with self._lock:
            pool = self._pools.get(key)
            if pool is None:
                pool = ConnectorPool(connection_id, connection_type, config, connection_name)
                self._pools[key] = pool
            return pool

    def invalidate_pool(self, connection_id: int) -> None:
        """Invalidate every pool for this connection when its config changes.

        ALL of them: one connection id can now own several pools (one per
        distinct resolved config), and invalidating only the one whose
        config happens to match the edit would leave the others serving
        connectors built from settings the operator just changed.
        """
        with self._lock:
            keys = [k for k in self._pools if k[0] == int(connection_id)]
            pools = [self._pools.pop(k) for k in keys]
        for pool in pools:
            pool.invalidate()

    def invalidate_pools_using_account(self, sa_ref: Any,
                                       row: Optional[Dict[str, Any]] = None) -> int:
        """Close every pool whose STORED config names System Account
        ``sa_ref`` (by id or by name; ``row`` lets an id match a name and
        vice versa).  ``sa_ref=None`` means EVERY pool that names any
        account.  Returns how many pools were closed.

        2026-10-30 -- a Vault rotation changes no stored config, so the pool
        key is unchanged and an idle connector keeps logging in with the old
        password until its idle timeout.  Called by
        ``core/qs_credentials/freshness.py::forget``."""
        wanted: set = set()
        if sa_ref is not None:
            wanted.add(str(sa_ref))
        if row:
            for k in ("id", "name"):
                if row.get(k) not in (None, ""):
                    wanted.add(str(row[k]))
        with self._lock:
            keys = [k for k, p in self._pools.items()
                    if _pool_names_account(p.config, wanted)]
            pools = [self._pools.pop(k) for k in keys]
        for pool in pools:
            pool.invalidate()
        return len(pools)

    def invalidate_all(self) -> int:
        """Close every pool (a peer pod changed a connection).  Returns the
        count; the pools rebuild on next use."""
        with self._lock:
            pools = list(self._pools.values())
            self._pools.clear()
        for pool in pools:
            pool.invalidate()
        return len(pools)

    def get_all_stats(self) -> list:
        with self._lock:
            pools = list(self._pools.values())
        return [p.stats() for p in pools]

    def shutdown(self) -> None:
        """Close all pools — called on app shutdown."""
        with self._lock:
            pools = list(self._pools.values())
            self._pools.clear()
        for pool in pools:
            pool.invalidate()


def _pool_names_account(config: Dict[str, Any], wanted: set) -> bool:
    """Does this pool's stored config name a System Account -- any (empty
    ``wanted``) or one of ``wanted`` (ids / names as strings)?"""
    try:
        from core.qs_credentials.freshness import account_ref
        ref = account_ref(config)
    except Exception:                                     # pragma: no cover
        ref = None
    if ref is None:
        return False
    return not wanted or str(ref) in wanted


# Module-level singleton
_pool_manager = PoolManager()


def _build_unpooled(connection_type: str, config: Dict[str, Any],
                    connection_id: Any = None, connection_name: str = "") -> Any:
    """Construct a connector the way the caller would have without a pool.

    2026-09-16 — the kwargs are OPTIONAL on purpose.  Not every factory in
    play accepts them: several call sites have always been
    ``get_connector(type, config)``, and their test doubles are written to
    that signature, so an unpooled fallback that always passes
    ``connection_id=``/``connection_name=`` raises TypeError inside what is
    supposed to be the SAFE path.  ``api/published_views/management.py``
    already carries the same shim for the same reason ("Older connector
    factories take only (type, config)").
    """
    from core.connectors import get_connector
    try:
        return get_connector(connection_type, config,
                             connection_id=connection_id,
                             connection_name=connection_name)
    except TypeError:
        return get_connector(connection_type, config)


@contextmanager
def get_pooled_connector(connection_id: int, connection_type: str,
                         config: Dict[str, Any], connection_name: str = ""):
    """Context manager that acquires a pooled connector and releases it on exit.

    If pooling is disabled, creates a fresh connector and closes it on exit.
    """
    # 2026-09-16 — a caller with NO connection_id gets the unpooled path,
    # not a TypeError.  The key needs an int, and filing such a connector
    # under a sentinel id would break ``invalidate_pool(connection_id)``: an
    # edited connection would keep serving connectors built from the old
    # settings.  Several call sites legitimately have only a type and a
    # config (a cross-connection side whose record carries no id, a test
    # double), and they must keep working exactly as before rather than
    # crash inside a performance optimisation.
    if not _enabled or connection_id is None:
        connector = _build_unpooled(connection_type, config,
                                    connection_id, connection_name)
        try:
            yield connector
        finally:
            try:
                connector.close()
            except Exception:
                pass
        return

    pool = _pool_manager.get_pool(connection_id, connection_type, config, connection_name)
    connector = pool.acquire()
    error_occurred = False
    try:
        yield connector
    except Exception:
        error_occurred = True
        raise
    finally:
        if error_occurred:
            pool.discard(connector)
        else:
            pool.release(connector)


def acquire_pooled(connection_id: int, connection_type: str,
                   config: Dict[str, Any], connection_name: str = "") -> Any:
    """Borrow a connector WITHOUT a ``with`` block.

    2026-09-16 — for the one caller whose lifetime a context manager cannot
    express: ``core/scan_partitions/executor.py`` opens a connector per
    WORKER THREAD inside a thread pool and gives them all back after the
    join, so acquisition and release happen on different stack frames.
    Pair it with :func:`release_pooled` or :func:`discard_pooled` — an
    unpaired acquire leaks a pool slot, which is exactly why every other
    caller uses ``get_pooled_connector``.
    """
    if not _enabled or connection_id is None:
        return _build_unpooled(connection_type, config,
                               connection_id, connection_name)
    pool = _pool_manager.get_pool(connection_id, connection_type, config,
                                  connection_name)
    return pool.acquire()


def release_pooled(connection_id: int, connection_type: str,
                   config: Dict[str, Any], connection_name: str,
                   connector: Any) -> None:
    """Give back a connector taken with :func:`acquire_pooled`.

    Honours the same reuse contract as the context manager: the connector
    is pooled only if its class declares ``POOL_SAFE`` and
    ``reset_for_reuse()`` succeeds, else it is closed.
    """
    if connector is None:
        return
    if not _enabled or connection_id is None:
        ConnectorPool._safe_close(connector)
        return
    pool = _pool_manager.get_pool(connection_id, connection_type, config,
                                  connection_name)
    pool.release(connector)


def discard_pooled(connection_id: int, connection_type: str,
                   config: Dict[str, Any], connection_name: str,
                   connector: Any) -> None:
    """Give back a connector that FAILED — closed, never pooled."""
    if connector is None:
        return
    if not _enabled or connection_id is None:
        ConnectorPool._safe_close(connector)
        return
    pool = _pool_manager.get_pool(connection_id, connection_type, config,
                                  connection_name)
    pool.discard(connector)


def invalidate_pool(connection_id: int) -> None:
    """Invalidate a pool — called when connection config changes."""
    _pool_manager.invalidate_pool(connection_id)


def invalidate_pools_using_account(sa_ref: Any, row: Optional[Dict[str, Any]] = None) -> int:
    """Close every pool built from System Account ``sa_ref`` (None = any
    account) -- see ``PoolManager.invalidate_pools_using_account``."""
    return _pool_manager.invalidate_pools_using_account(sa_ref, row)


def invalidate_all_pools() -> int:
    """Close every pool (a peer pod changed a connection)."""
    return _pool_manager.invalidate_all()


#: 2026-09-16 — this used to quote "~51 call sites", and a guard caught the
#: number going stale the moment sites started being converted.  A COUNT
#: written into prose is a claim with a shelf life; the sentence now says
#: what is true regardless of how many remain, and anyone who wants the
#: number can count it (tests/test_connection_pool_is_honest_2026_09_16.py
#: does exactly that).
_ACQUISITION_SITES_NOTE = (
    "the remaining call sites construct connectors directly via "
    "core.connectors.get_connector; each would have to move inside this "
    "context manager, and each has its own lifetime (some close, some hand "
    "the connector onward, some keep it for the life of a request)"
)


def pool_status() -> Dict[str, Any]:
    """Is connection pooling actually doing anything?  (2026-09-16)

    ``connection_pool.enabled`` ships ``True``, ``get_pool_stats`` is on an
    admin route, ``invalidate_pool`` is called whenever a connection is
    edited -- and ``get_pooled_connector``, the ONLY way a pooled connector
    is ever handed out, has no caller.  So the subsystem is inert: the admin
    screen showed an empty pool list, which reads as "nothing in use right
    now" rather than "this never pools anything", and three config keys were
    read by nothing at all.

    This reports the truth in the shape this product already uses for the
    same problem (``/api/feeds/backend-options``' available + detail,
    multi_pod's disabled|inert|active, DataFlow's runnability): a status, a
    reason, and the remedy.  It does NOT fake-wire pooling -- releasing a
    pooled connector that is still in use is a cross-request data bleed, and
    that is a deliberate refactor with its own gate, not a line in a sweep.
    """
    acquires = _CONTEXT_MANAGER_HAS_CALLERS
    if not _enabled:
        status, reason = "disabled", "connection_pool.enabled is false"
    elif not acquires:
        status = "inert"
        reason = ("enabled, but nothing acquires a pooled connector: "
                  "get_pooled_connector() has no production caller, so every "
                  "connection is still created fresh and closed. " +
                  _ACQUISITION_SITES_NOTE)
    else:
        status, reason = "active", ""
    return {
        "status": status,
        "reason": reason,
        "enabled": bool(_enabled),
        "max_size": int(_max_size),
        "idle_timeout_seconds": int(_idle_timeout),
        "initialised": bool(_initialised),
        # Through the public helper on purpose: pointing the admin route at
        # pool_status() otherwise left get_pool_stats with no caller at all,
        # trading one orphan for another.
        "pools": get_pool_stats(),
    }


def get_pool_stats() -> list:
    """Return stats for all pools.  Called by :func:`pool_status` above
    (resolved at call time, so definition order does not matter).

    An empty list from this function means "no pool objects exist", which in
    the shipped product is ALWAYS -- see :func:`pool_status` for why.  Prefer
    ``pool_status()`` on any surface a human reads: a bare empty list reads
    as "nothing pooled right now", which is a different statement.
    """
    return _pool_manager.get_all_stats()


def shutdown_pools() -> None:
    """Shutdown all pools — called on app shutdown."""
    _pool_manager.shutdown()
