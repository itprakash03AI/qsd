"""One Arrow IPC stream writer for every route that answers in Arrow.

``api/arrow_api.py`` (the SQL editor's results) and the report cube
(``core/reports/cube_arrow.py``, a canvas tile that asks with
``Accept: application/vnd.apache.arrow.stream``) write their table here, so
the two roads cannot drift in how the bytes are laid out.
"""
from __future__ import annotations

ARROW_STREAM_MEDIA_TYPE = "application/vnd.apache.arrow.stream"


def table_to_ipc_stream(table, schema=None) -> bytes:
    """``table`` (a ``pyarrow.Table``) as Arrow IPC stream bytes (schema, batches, end).
    ``schema`` overrides the stream's schema (an empty page keeps its file's)."""
    import pyarrow as pa
    sink = pa.BufferOutputStream()
    writer = pa.ipc.new_stream(sink, schema if schema is not None else table.schema)
    writer.write_table(table)
    writer.close()
    return bytes(sink.getvalue())


def accepts_arrow(accept_header: str | None) -> bool:
    """Did the caller ask for Arrow?  Only an explicit media type counts --
    ``*/*`` (every browser, every script) keeps the JSON it always had."""
    return bool(accept_header) and ARROW_STREAM_MEDIA_TYPE in accept_header.lower()
