"""Routes that carry NO capability by design -- each with its reason (2026-10-31).

Everything else declares exactly one capability (``require_capability``); a
route that is neither is a HOLE, and ``tests/test_tool_entitlement_route_guard_
2026_10_31.py`` fails naming it.  A declaration here for a route that no
longer exists fails the same guard (a stale reason is a lie).

Two kinds:

* ``PUBLIC``     -- no login at all: probes, the login page's own needs, the
                    build stamp, the API docs; or authenticated by something
                    other than a person -- a share / embed / unsubscribe TOKEN
                    in the path, a webhook SIGNATURE, a worker's shared secret.
                    Each handler enforces its own token or signature.
* ``LOGIN_ONLY`` -- a signed-in person, whatever they hold: the routes a
                    browser needs to BE signed in and to ask what it may do.
                    A capability here would be a foot-gun (take it from a
                    group and its members cannot even see why).

Keys are ``"METHOD /path"`` exactly as FastAPI spells the path.
"""
from __future__ import annotations

from typing import Dict

PUBLIC: Dict[str, str] = {
    # liveness, readiness, the build stamp, metrics, the docs
    "GET /": "the API root banner",
    "GET /health": "Kubernetes probe", "GET /health/live": "Kubernetes probe",
    "GET /health/ready": "Kubernetes probe", "GET /metrics": "Prometheus scrape (no data)",
    "GET /api/version": "the build stamp the UI shows on the login page",
    "GET /docs": "the published-API consumer docs",
    # the login page's own needs
    "GET /auth/config": "the login page asks which login type is configured",
    "GET /auth/public-key": "the login page encrypts the password with it",
    "POST /auth/login": "the login itself",
    # a worker pod's probes and its signed chunk protocol
    "GET /api/worker/health": "worker pod probe", "GET /api/worker/ready": "worker pod probe",
    "GET /api/worker/stats": "worker stats: a coordinator's signature or an admin, checked in the handler",
    "POST /api/worker/run-chunk": "signed by the coordinator (shared secret), checked in the handler",
    # webhooks: authenticated by their signature / token, checked in the handler
    "POST /api/webhooks/dataflow/{token}": "a dataflow webhook trigger: the token IS the credential",
    "POST /api/webhooks/etl-complete": "signed webhook (feed_generation.webhook_secret)",
    "POST /api/webhooks/feed-complete": "signed webhook (feed_generation.webhook_secret)",
    "POST /api/webhooks/feed-progress": "signed webhook (feed_generation.webhook_secret)",
    "POST /api/v1/feeds/{id_or_slug}/trigger": "an external feed trigger: API key checked in the handler",
    # share / embed / unsubscribe tokens in the path: the token is the credential
    "GET /api/shared/{token}": "a shared query opened by its token",
    "GET /api/shared-dashboard/{token}": "a shared dashboard opened by its token",
    "POST /api/shared-dashboard/{token}/widgets/{widget_id}/execute": "a shared dashboard tile run by its token",
    "POST /api/shared-dashboard/{token}/widgets/{widget_id}/cube": "a shared dashboard tile drilled by its token",
    "GET /api/shared-business-report/{token}": "a shared report opened by its token",
    "POST /api/shared-business-report/{token}/execute": "a shared report run by its token",
    "POST /api/shared-business-report/{token}/cube": "a shared report drilled by its token",
    "POST /api/shared-business-report/{token}/parameter-values": "a shared report's parameter values by its token",
    "GET /api/business-reports/shared/{token}/download-csv": "a shared report exported by its token",
    "GET /api/business-reports/shared/{token}/download-excel": "a shared report exported by its token",
    "GET /api/business-reports/shared/{token}/download-pdf": "a shared report exported by its token",
    "GET /api/embedded-business-report/{token}": "an embedded report opened by its token",
    "POST /api/embedded-business-report/{token}/execute": "an embedded report run by its token",
    "POST /api/embedded-business-report/{token}/cube": "an embedded report drilled by its token",
    "POST /api/embedded-business-report/{token}/parameter-values": "an embedded report's parameter values by its token",
    "GET /api/business-reports/embedded/{token}/download-csv": "an embedded report exported by its token",
    "GET /api/business-reports/embedded/{token}/download-excel": "an embedded report exported by its token",
    "GET /api/business-reports/embedded/{token}/download-pdf": "an embedded report exported by its token",
    "GET /api/unsubscribe/{token}": "an e-mail's unsubscribe link: the token is the credential",
    # legacy spellings that only redirect (308) to the real route, which carries the gate
    "GET /api/reports/connector-matrix": "308 redirect to /api/report-connectors/matrix, which carries the gate",
    "POST /api/reports/bulk-set-connection-override": "308 redirect to /api/report-connectors/bulk-set-override, which carries the gate",
    "GET /api/v1/views/{slug}/bulk/parts/{part_index}": "a bulk part fetched by its signed URL, checked in the handler",
}

LOGIN_ONLY: Dict[str, str] = {
    "GET /auth/me": "a signed-in person may always ask who they are",
    "POST /auth/logout": "a signed-in person may always sign out",
    "GET /api/me/capabilities": "a signed-in person may always ask what they may do (the UI's one question)",
    "GET /api/me/entitlements": "a signed-in person may always see which data entitlements apply to them",
}

#: Routes that exist only when an OPTIONAL package is installed or the UI is
#: bundled (absent on a box without it; the guard tolerates their absence, never a stale one above).
OPTIONAL_PUBLIC: Dict[str, str] = {
    "POST /graphql": ("GraphQL (strawberry): the context getter resolves an API key or a login without "
                      "failing; publishedViewData does the consumer's own auth; every management resolver "
                      "requires an admin holding published_api.manage (api/graphql_api._gql_current_user)"),
    "POST /graphql/": "the same GraphQL endpoint with a trailing slash (one schema, two spellings)",
    # 2026-11-01 (the CI image has strawberry; the dev box does not): the router also
    # registers GET -- it answers 405 (graphql_ide=None, allow_queries_via_get=False,
    # api/graphql_api.py: no in-browser IDE, no queries by GET)
    "GET /graphql": "GraphQL by GET answers 405 -- no in-browser IDE, no queries by GET (api/graphql_api.py)",
    "GET /graphql/": "the same 405 with a trailing slash",
    # mounted only when a built UI is bundled next to the API (main._STATIC_DIR)
    "GET /{full_path:path}": "the built UI's page shell (an /api path is a 404, never the shell)",
}

#: WebSocket routes an OPTIONAL package registers (strawberry's GraphQL transport):
#: the schema declares NO subscription, so the socket can run nothing; queries and
#: mutations go over POST through the same context getter.
OPTIONAL_WEBSOCKETS: Dict[str, str] = {
    "/graphql": "strawberry's GraphQL websocket transport -- the schema has no subscription, so it runs nothing",
    "/graphql/": "the same, with a trailing slash",
}

#: WebSocket routes: authenticated in-protocol (``websocket.require_auth``), not by a dependency
WEBSOCKETS: Dict[str, str] = {
    "/ws": "the live-update socket: the client authenticates in its first message",
    "/ws/{client_id}": "the live-update socket: the client authenticates in its first message",
}
