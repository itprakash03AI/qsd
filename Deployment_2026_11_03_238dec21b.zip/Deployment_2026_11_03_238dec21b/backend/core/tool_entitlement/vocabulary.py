"""The capability vocabulary of TOOL entitlement (2026-10-31; plan §1b, DECIDED).

Which SCREENS and ACTIONS a person may use -- "this group may build reports
but not publish APIs".  Data entitlement (which ROWS a person sees,
``core/row_security/entitlement.py``) is a separate question and stays one:
a person allowed to run reports still sees only their entitled rows.

ONE vocabulary, declared here as data, ``area.action``.  A route declares
exactly one capability (``api.deps.require_capability``); a grant row
(``tool_capability_grants``) gives a capability to a principal -- an AD
group, a QueryStudio user group, a user, or a ROLE.  The roles are BUNDLES:
``DAY_ONE_ROLES`` on each capability is the set of roles that hold it on day
one, derived from the role check the route carried before (``require_admin``
-> admin; ``require_admin_read`` -> admin + support; ``require_role("admin",
"analyst")`` -> admin + analyst; a login-only route -> every role).  The
bundles are SEEDED into the grants table from this declaration
(``core/tool_entitlement/engine.seed_bundles``) so nobody gains or loses
anything on day one -- ``tests/test_tool_entitlement_day_one_2026_10_31.py``
walks every route as every role on master's code and on this code and
compares.  ``super_admin`` is break-glass and bypasses; it holds no rows.

The label and description are the words a person sees ("Ask an admin to
give your group 'Publish reports'") -- plain, no internal words.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, FrozenSet, List, Tuple

# ── the roles (core/roles.py) ──────────────────────────────────────────────
ROLE_ADMIN, ROLE_ANALYST, ROLE_VIEWER = "admin", "analyst", "viewer"
ROLE_SUPPORT, ROLE_API_CONSUMER, ROLE_SCHEDULER = "support", "api_consumer", "scheduler"
ROLE_SUPER_ADMIN = "super_admin"

#: the roles a bundle is seeded for (super_admin bypasses, never a bundle)
BUNDLE_ROLES: Tuple[str, ...] = (ROLE_ADMIN, ROLE_ANALYST, ROLE_VIEWER, ROLE_SUPPORT,
                                 ROLE_API_CONSUMER, ROLE_SCHEDULER)

#: the four day-one holder sets, named after the role check they replace
EVERYONE = frozenset(BUNDLE_ROLES)                         # a login-only route
AUTHORS = frozenset({ROLE_ADMIN, ROLE_ANALYST})            # require_role("admin", "analyst")
ADMINS = frozenset({ROLE_ADMIN})                           # require_admin
OPERATORS = frozenset({ROLE_ADMIN, ROLE_SUPPORT})          # require_admin_read
#: a dataflow run may also be started by a listed API key (dataflow_api._run_starter)
ADMINS_AND_KEYS = frozenset({ROLE_ADMIN, ROLE_API_CONSUMER})
#: clockwork authoring: core/clockwork/scope.AUTHOR_ROLES
CLOCKWORK_AUTHORS = frozenset({ROLE_ADMIN, ROLE_ANALYST, ROLE_SCHEDULER})


@dataclass(frozen=True)
class Capability:
    name: str                   # area.action
    label: str                  # what a person reads, e.g. "Publish reports"
    description: str            # one plain sentence
    day_one_roles: FrozenSet[str]

    @property
    def area(self) -> str:
        return self.name.split(".", 1)[0]


def _c(name: str, label: str, description: str, roles: FrozenSet[str]) -> Capability:
    return Capability(name, label, description, roles)


#: AREA -> plain name, for the admin screen (E3) and the refusal text
AREAS: Dict[str, str] = {
    "connections": "Connections", "datasets": "Datasets", "bqb": "Query builder", "sql": "SQL page",
    "reports": "Reports", "dashboards": "Dashboards", "published_api": "Published APIs",
    "feeds": "Feeds", "dataflows": "Dataflows", "clockwork": "Scheduler", "schedules": "Schedules",
    "data_quality": "Data quality", "etl": "ETL and SAP", "workspaces": "Workspaces",
    "releases": "Configuration releases", "brain": "Caches and the pruning brain",
    "row_security": "Data security", "entitlement": "Permissions", "admin": "Administration",
    "account": "Your account",
}

_CAPABILITIES: List[Capability] = [
    # ── connections ───────────────────────────────────────────────────────
    _c("connections.view", "Browse connections",
       "See the connections you may use and browse their tables and columns.", EVERYONE),
    _c("connections.manage", "Manage connections",
       "Add, change, test, share and remove connections, connection profiles and S3 readers.", ADMINS),
    # ── datasets (the semantic layer, logical tables, lineage, uploads) ───
    _c("datasets.view", "View datasets",
       "Open datasets, their columns, lineage, federation views and uploaded tables.", EVERYONE),
    _c("datasets.create", "Create datasets",
       "Create datasets, preview them, map columns, build federation views and value lists.", AUTHORS),
    _c("datasets.edit", "Edit datasets",
       "Change a dataset you may edit: its columns, classes, hierarchies, metrics, conditions and relationships.",
       EVERYONE),
    _c("datasets.upload", "Upload data",
       "Upload files as local tables and add to them.", AUTHORS),
    _c("datasets.manage", "Manage datasets",
       "Change or remove any dataset, logical table, materialized view or lineage; publish datasets.", ADMINS),
    # ── the query builder (BQB) and query execution ───────────────────────
    _c("bqb.view", "View queries and results",
       "Open saved queries, see results, suggestions and query status.", EVERYONE),
    _c("bqb.run", "Run queries",
       "Run a query from the query builder, submit query jobs, refresh a source's cache.", AUTHORS),
    _c("bqb.save", "Save queries",
       "Save a query in the query builder.", AUTHORS),
    _c("bqb.edit", "Edit saved queries",
       "Change, share or remove a saved query you own.", EVERYONE),
    # ── the SQL page ──────────────────────────────────────────────────────
    _c("sql.view", "Open the SQL page",
       "Browse schemas, saved SQL queries and SQL files; format and split SQL.", EVERYONE),
    _c("sql.run", "Run SQL",
       "Run SQL on the SQL page with the connection's credentials.", AUTHORS),
    _c("sql.save", "Save SQL queries",
       "Save, change and remove saved SQL queries.", AUTHORS),
    # ── reports ───────────────────────────────────────────────────────────
    _c("reports.view", "Open and run reports",
       "Open reports, run them, export them, see the catalog, readiness and sign-offs.", EVERYONE),
    _c("reports.edit", "Edit reports",
       "Change a report you may edit: its definition, parameters, formatting, bookmarks and alerts.", EVERYONE),
    _c("reports.create", "Create reports",
       "Create, clone and duplicate reports; comment on them.", AUTHORS),
    _c("reports.publish", "Publish reports",
       "Publish a report to its readers or take it back.", EVERYONE),
    _c("reports.subscribe", "Subscribe to reports",
       "Subscribe to a report's deliveries and manage your subscriptions.", EVERYONE),
    _c("reports.manage", "Manage all reports",
       "Report administration: certify, retention, delivery settings, usage, bursting.", ADMINS),
    # ── dashboards ────────────────────────────────────────────────────────
    _c("dashboards.view", "View dashboards", "Open dashboards and export them.", EVERYONE),
    _c("dashboards.author", "Build dashboards",
       "Create and change dashboards and their tiles.", EVERYONE),
    # ── published APIs ────────────────────────────────────────────────────
    _c("published_api.view", "View published APIs",
       "See published APIs, their calls and alerts.", EVERYONE),
    _c("published_api.create", "Create published APIs",
       "Create and change published APIs, request an API key.", EVERYONE),
    _c("published_api.manage", "Manage published APIs",
       "Import and export APIs, webhooks, alert thresholds, lifecycle and usage.", ADMINS),
    _c("published_api.keys.approve", "Approve API keys",
       "Approve or deny API key requests; create, change and remove API keys.", ADMINS),
    _c("published_api.consume", "Call published APIs",
       "Call a published API's data endpoints with an API key or a login.", EVERYONE),
    # ── feeds ─────────────────────────────────────────────────────────────
    _c("feeds.view", "View feeds", "See feeds, runs, templates, groups and the feed boards.", EVERYONE),
    _c("feeds.author", "Set up and operate feeds",
       "Create, change, run, re-run, cancel and test feeds you may edit; templates, groups, versions, destinations.",
       EVERYONE),
    _c("feeds.run_now", "Run feeds now", "Start a feed run for a date outside its schedule.", EVERYONE),
    _c("feeds.skip_dependency", "Skip a feed dependency",
       "Release a run that is waiting for a dependency.", EVERYONE),
    _c("feeds.release_hold", "Release a feed hold",
       "Release or reject a run held for a row-count variance.", EVERYONE),
    _c("feeds.monitor", "Monitor feeds",
       "Support views: message tracker, dependency messages, SOD gaps, alerts, digests.", OPERATORS),
    _c("feeds.manage", "Manage feeds",
       "Feed administration: calendars, formats, user groups, approvers, alert routes, SOD.", ADMINS),
    # ── dataflows ─────────────────────────────────────────────────────────
    _c("dataflows.view", "View dataflows", "See dataflows, their runs and stages.", EVERYONE),
    _c("dataflows.author", "Edit dataflows", "Change a dataflow you may edit.", EVERYONE),
    _c("dataflows.run", "Run dataflows", "Start a dataflow run.", ADMINS_AND_KEYS),
    _c("dataflows.monitor", "Monitor dataflows", "Support views: metrics, approvals, start-up state.", OPERATORS),
    _c("dataflows.manage", "Manage dataflows",
       "Create, import, schedule, pause, resume, promote and archive dataflows.", ADMINS),
    # ── the scheduler (Clockwork) ─────────────────────────────────────────
    _c("clockwork.view", "View the scheduler", "See scheduled jobs, their fires and health.", EVERYONE),
    _c("clockwork.author", "Author scheduled jobs", "Create and change scheduled jobs.", CLOCKWORK_AUTHORS),
    _c("clockwork.manage", "Manage the scheduler",
       "Scheduler settings, query templates and the schema.", ADMINS),
    # ── query / report schedules ──────────────────────────────────────────
    _c("schedules.view", "View schedules", "See query and report schedules.", EVERYONE),
    _c("schedules.author", "Create schedules",
       "Create, change and remove schedules.", AUTHORS),
    _c("schedules.operate", "Operate schedules",
       "Pause, resume and run now a schedule you own.", EVERYONE),
    # ── data quality ──────────────────────────────────────────────────────
    _c("data_quality.author", "Use data quality rules",
       "Create and run data quality rules, see results and alerts.", AUTHORS),
    _c("data_quality.manage", "Manage data quality", "Data quality administration.", ADMINS),
    # ── ETL pipelines, SAP, reconciliation ────────────────────────────────
    _c("etl.view", "View ETL", "See ETL pipelines, SAP tasks and reconciliations.", EVERYONE),
    _c("etl.manage", "Manage ETL", "Create, change and run ETL pipelines and SAP tasks.", ADMINS),
    # ── workspaces ────────────────────────────────────────────────────────
    _c("workspaces.view", "View workspaces", "See the workspaces you belong to.", EVERYONE),
    _c("workspaces.author", "Manage your workspaces",
       "Change a workspace you own and its members.", EVERYONE),
    _c("workspaces.manage", "Create and remove workspaces", "Create a workspace; remove any workspace.", ADMINS),
    # ── configuration releases and governance ─────────────────────────────
    _c("releases.view", "View releases", "See configuration releases, drift and exports.", OPERATORS),
    _c("releases.manage", "Manage releases",
       "Create, approve, apply and roll back configuration releases; governance settings.", ADMINS),
    # ── caches and the pruning brain ──────────────────────────────────────
    _c("brain.manage", "Manage caches and the pruning brain",
       "Iceberg, parquet and result caches, pruning, the query queue and running queries.", ADMINS),
    # ── data security ─────────────────────────────────────────────────────
    _c("row_security.manage", "Manage data security",
       "Row and column security policies, and which data values each group or person may see.", ADMINS),
    # ── tool entitlement itself (the E3 screen) ───────────────────────────
    _c("entitlement.manage", "Manage permissions",
       "Give and take back permissions for groups and people.", ADMINS),
    # ── administration ────────────────────────────────────────────────────
    _c("admin.config", "Configure the platform",
       "Platform settings: pods, workers, storage, engines, Spark, agents, vault, screens.", ADMINS),
    _c("admin.users", "Manage users", "Users, their roles, super admins.", ADMINS),
    _c("admin.audit", "Read the audit log", "Read the audit log.", ADMINS),
    _c("admin.monitor", "Monitor the platform",
       "Support views: component health, known users, Spark pod settings.", OPERATORS),
    _c("admin.diagnostics", "Read platform diagnostics",
       "The platform self-test and diagnostics pages.", EVERYONE),
    # ── a person's own account ────────────────────────────────────────────
    _c("account.self", "Use your account",
       "Your preferences, drafts, notifications, downloads and switched-off items.", EVERYONE),
]

CAPABILITIES: Dict[str, Capability] = {c.name: c for c in _CAPABILITIES}
assert len(CAPABILITIES) == len(_CAPABILITIES), "a capability is declared twice"


def is_capability(name: str) -> bool:
    return name in CAPABILITIES


def bundle(role: str) -> FrozenSet[str]:
    """The capabilities ``role`` holds on day one (the seed)."""
    return frozenset(c.name for c in _CAPABILITIES if role in c.day_one_roles)


def refusal_text(name: str) -> str:
    """The plain sentence a refused person reads."""
    c = CAPABILITIES.get(name)
    what = c.label.lower() if c else name
    return (f"You do not have permission to {what[:1].lower()}{what[1:]}. "
            f"Ask an admin to give your group '{c.label if c else name}'.")
