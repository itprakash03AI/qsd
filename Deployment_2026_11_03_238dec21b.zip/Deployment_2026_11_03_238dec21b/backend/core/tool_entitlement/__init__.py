"""Tool entitlement (2026-10-31): which screens and actions a person may use.

* ``vocabulary``   -- the capabilities (``area.action``) and the day-one bundles;
* ``engine``       -- ``can(user, capability, scope=None)``, the ONE decision
                      point, its cache and the seed of the bundles;
* ``declarations`` -- the routes that are PUBLIC or LOGIN-ONLY by design, each
                      with its reason (everything else declares a capability).
"""
from core.tool_entitlement.engine import (  # noqa: F401
    can, capabilities_of, invalidate, seed_bundles, set_db_manager,
)
from core.tool_entitlement.vocabulary import CAPABILITIES, bundle, refusal_text  # noqa: F401
