"""``can(user, capability, scope=None)`` -- the ONE decision point of tool
entitlement, its cache, and the seed of the role bundles (2026-10-31).

How a decision is made
----------------------
1. An unknown capability is DENIED (a typo in a route denies everyone; the
   route guard catches it before it ships).
2. ``super_admin`` is break-glass: always allowed, as every role check before
   this allowed it.  A share / embed token principal is not a person: its
   reach is the object the token was minted for, enforced by the route
   (``api.deps.enforce_token_execute_scope``), so it is let through here.
3. The caller's PRINCIPALS are resolved ONCE, by the resolver data
   entitlement already uses (``core.row_security.entitlement.principals_of``:
   ``user:<name>``, every directory group, every QueryStudio user group BY
   NAME; an API key is ``api_key:<id>``) plus ``role:<role>`` -- the bundle.
4. The ACTIVE grant rows are read once per TTL into a memo; a grant matches
   when its capability is the one asked, its principal is one of the
   caller's, and it is unscoped -- or scoped to exactly the ``scope`` asked
   (``(kind, id)``).  Grants only ADD; there is no deny row, so two groups
   with different grants give their member the union.

Cache
-----
Exactly the row-security pattern: an in-process memo for
``row_security.cache_resolver_seconds`` (30 s), dropped at once on this pod
by ``invalidate()`` (every grant write calls it), and on every other pod
through the coherence bus (``core.cache_coherence``, namespace
``tool_entitlement``: a bump is seen within ``cache.coherence_poll_seconds``)
-- and, failing the bus, within the TTL.  The principal list is memoised per
username for the same TTL (a user-group edit is a grant-like write and bumps
the same epoch).

Failure
-------
A store that is wired and cannot be read DENIES, with a message that says the
check could not be made (never "you have no permission").  A store that was
never wired (a unit harness, a worker that serves no routes) answers from the
code-declared bundles -- exactly master's behaviour -- so no road can be
opened by forgetting a setter: a wired store always wins.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Tuple

from core.tool_entitlement.vocabulary import (
    BUNDLE_ROLES, CAPABILITIES, ROLE_SUPER_ADMIN, ROLE_VIEWER, bundle,
)

logger = logging.getLogger(__name__)

COHERENCE_NAMESPACE = "tool_entitlement"
PRINCIPAL_TYPES = ("role", "user", "group", "api_key")
UNSCOPED = ""

_lock = threading.RLock()
_db_manager: Any = None
#: {"at": monotonic, "epoch": token, "grants": [(capability, ptype, pid, skind, sid)]}
_grants_memo: Dict[str, Any] = {"at": 0.0, "epoch": None, "grants": None}
#: username -> (monotonic, epoch, principals)
_principals_memo: Dict[str, Tuple[float, Any, Tuple[Tuple[str, str], ...]]] = {}


class PermissionCheckUnavailable(Exception):
    """The grants could not be read: deny, and say the check failed."""


def set_db_manager(db: Any) -> None:
    global _db_manager
    with _lock:
        _db_manager = db
    invalidate(local_only=True)


def _db() -> Any:
    if _db_manager is not None:
        return _db_manager
    try:
        from core import config as _cfg
        return getattr(_cfg, "_db_manager_ref", None)
    except Exception:                                                # noqa: BLE001
        return None


def _ttl() -> float:
    try:
        from core.config import row_security as _rs
        return float(max(0, int(_rs.cache_resolver_seconds)))
    except Exception:                                                # noqa: BLE001
        return 30.0


def _epoch() -> Any:
    """The fleet-wide invalidation token (None when no bump ever happened)."""
    try:
        from core.cache_coherence import get_bus
        return get_bus().current_token(COHERENCE_NAMESPACE)
    except Exception:                                                # noqa: BLE001
        return None


def invalidate(local_only: bool = False) -> None:
    """Drop the memos on this pod; announce it to the others unless asked not to."""
    with _lock:
        _grants_memo.update({"at": 0.0, "epoch": None, "grants": None})
        _principals_memo.clear()
    if local_only:
        return
    try:
        from core.cache_coherence import get_bus
        get_bus().bump(COHERENCE_NAMESPACE, reason="grant written")
    except Exception as exc:                                         # noqa: BLE001
        logger.debug("tool_entitlement: coherence bump skipped: %s", exc)


# ── the grants ─────────────────────────────────────────────────────────────

def _active_grants(db: Any) -> List[Tuple[str, str, str, str, str]]:
    now = time.monotonic()
    epoch = _epoch()
    with _lock:
        if (_grants_memo["grants"] is not None and _grants_memo["epoch"] == epoch
                and now - _grants_memo["at"] < _ttl()):
            return _grants_memo["grants"]
    try:
        rows = db.list_tool_capability_grants(active_only=True)
        if not rows and not db.list_tool_capability_grants(active_only=False):
            # NOT ONE row, on or off: the bundles were never seeded into this
            # store (a database created beside the running app -- a harness,
            # a tool).  Switched-off rows would still be there, so this is
            # never "an admin took everything away"; answer as day one does.
            rows = None
    except Exception as exc:
        raise PermissionCheckUnavailable(f"{type(exc).__name__}: {exc}") from exc
    if rows is None:
        grants = _code_bundle_grants()
        logger.warning("tool_entitlement: the grants table is empty (never seeded) -- "
                       "answering from the code-declared bundles")
    else:
        grants = [(str(r["capability"]), str(r["principal_type"]), str(r["principal_id"]),
                   str(r.get("scope_kind") or UNSCOPED), str(r.get("scope_id") or UNSCOPED)) for r in rows]
    with _lock:
        _grants_memo.update({"at": now, "epoch": epoch, "grants": grants})
    return grants


def _code_bundle_grants() -> List[Tuple[str, str, str, str, str]]:
    """The day-one bundles in grant-row shape (what ``seed_bundles`` writes)."""
    return [(cap, "role", role, UNSCOPED, UNSCOPED) for role in BUNDLE_ROLES for cap in sorted(bundle(role))]


# ── the principals ─────────────────────────────────────────────────────────

class _Ctx:
    """The two attributes ``principals_of`` reads from a UserContext."""

    def __init__(self, username: str, groups: Iterable[str]):
        self.username = username
        self.groups = list(groups)


def bundle_role_of(user: Optional[dict]) -> str:
    """The BUNDLE a caller's role maps to.  A role the vocabulary does not
    know (a directory mapping gone wrong, a test's ``"user"``) and a missing
    role both read as ``viewer`` -- the floor ``require_role`` gave a missing
    role, and what a login-only route let through on day one."""
    role = str((user or {}).get("role") or "").strip().lower()
    return role if role in BUNDLE_ROLES else ROLE_VIEWER


def principals_of(user: Optional[dict], db: Any) -> Tuple[Tuple[str, str], ...]:
    """``(type, id)`` pairs a grant may name for this caller, through the ONE
    resolver data entitlement uses, plus the role bundle (and the raw role
    when it is not a bundle, so a grant may still name it)."""
    user = user or {}
    role = str(user.get("role") or "").strip().lower()
    out: List[Tuple[str, str]] = [("role", bundle_role_of(user))]
    if role and role != out[0][1]:
        out.append(("role", role))
    if user.get("api_key_id") is not None and user.get("auth_method") == "api_key":
        out.append(("api_key", str(user["api_key_id"])))
        return tuple(out)
    username = str(user.get("username") or "")
    if not username:
        return tuple(out)
    now = time.monotonic()
    epoch = _epoch()
    key = f"{username}\x00{','.join(sorted(str(g) for g in (user.get('groups') or ())))}"
    with _lock:
        hit = _principals_memo.get(key)
        if hit and hit[1] == epoch and now - hit[0] < _ttl():
            return tuple(out) + hit[2]
    from core.row_security import entitlement as ent
    try:
        pairs = ent.principals_of(_Ctx(username, user.get("groups") or ()), db, (None, None, None))
    except ent.EntitlementRefused as exc:
        raise PermissionCheckUnavailable(str(exc)) from exc
    resolved = tuple((str(t), str(i)) for t, i in pairs)
    with _lock:
        _principals_memo[key] = (now, epoch, resolved)
    return tuple(out) + resolved


# ── the decision ───────────────────────────────────────────────────────────

def _code_bundles_say(user: dict, capability: str) -> bool:
    return capability in bundle(bundle_role_of(user))


def _is_token_principal(user: Optional[dict]) -> bool:
    return bool(user) and user.get("auth_via") in ("share_token", "embed_token")


def can(user: Optional[dict], capability: str, scope: Optional[Tuple[str, Any]] = None) -> bool:
    """May ``user`` exercise ``capability`` (on ``scope``, when given)?

    Raises ``PermissionCheckUnavailable`` when a wired store cannot be read
    -- the caller turns that into "the check could not be made", never into
    a plain refusal."""
    if capability not in CAPABILITIES:
        logger.warning("tool_entitlement: unknown capability %r asked -- denied", capability)
        return False
    if not user:
        return False
    if str(user.get("role") or "").lower() == ROLE_SUPER_ADMIN:
        return True
    if _is_token_principal(user):
        return True
    db = _db()
    if db is None or not hasattr(db, "list_tool_capability_grants"):
        return _code_bundles_say(user, capability)
    principals = set(principals_of(user, db))
    want_scope = (str(scope[0]), str(scope[1])) if scope else None
    for cap, ptype, pid, skind, sid in _active_grants(db):
        if cap != capability or (ptype, pid) not in principals:
            continue
        if skind == UNSCOPED:
            return True
        if want_scope is not None and (skind, sid) == want_scope:
            return True
    return False


def capabilities_of(user: Optional[dict]) -> FrozenSet[str]:
    """Every capability the caller holds UNSCOPED (what the UI asks for)."""
    if not user:
        return frozenset()
    if str(user.get("role") or "").lower() == ROLE_SUPER_ADMIN:
        return frozenset(CAPABILITIES)
    db = _db()
    if db is None or not hasattr(db, "list_tool_capability_grants"):
        return bundle(bundle_role_of(user))
    principals = set(principals_of(user, db))
    return frozenset(cap for cap, ptype, pid, skind, _sid in _active_grants(db)
                     if (ptype, pid) in principals and skind == UNSCOPED and cap in CAPABILITIES)


# ── the seed ───────────────────────────────────────────────────────────────

def seed_bundles(db: Any) -> int:
    """Write the day-one bundles as ``role`` grants, once: a (capability,
    role) pair that already has a row -- ON or switched OFF -- is left as it
    is, so an admin's later change is never undone by a restart.  Returns
    how many rows were added."""
    wanted = [(cap, role) for role in BUNDLE_ROLES for cap in sorted(bundle(role))]
    added = db.seed_tool_capability_grants(wanted)
    if added:
        invalidate()
        logger.info("tool_entitlement: seeded %d bundle grant(s)", added)
    return added
