"""
QueryStudio ETL Pipeline Worker — standalone process (Phase 127).

Polls the ``etl_pipeline_executions`` table for pending jobs, picks the
execution backend (native DuckDB / spark-submit / Airflow) via the ETL engine,
and executes them.  Exposes a small internal FastAPI control API on
``etl_pipelines.worker_host:etl_pipelines.worker_port`` (default 127.0.0.1:8004)
for health checks, pause/resume, and status.

Usage:
    python etl_worker.py
    python -m querystudio etl-worker

Only needed when ``etl_pipelines.enabled = True`` in config.json.
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import signal
import sys
import threading
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Ensure the backend directory is on sys.path so ``core.*`` imports work
_backend_dir = Path(__file__).resolve().parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from fastapi import FastAPI  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:
    psutil = None  # type: ignore[assignment]
    _HAS_PSUTIL = False

logger = logging.getLogger("etl_worker")

# ── Module-level state ──────────────────────────────────────────────────────

_db_manager = None
_db_url: Optional[str] = None
_worker_id: Optional[str] = None
_shutdown_event = threading.Event()
_paused = threading.Event()
_paused.set()  # Start in running state (set = not paused)

_poll_thread: Optional[threading.Thread] = None
_heartbeat_thread: Optional[threading.Thread] = None

_stats = {
    "tasks_completed": 0,
    "tasks_failed": 0,
    "tasks_claimed": 0,
    "started_at": None,
}


# ── Lifespan ────────────────────────────────────────────────────────────────

@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Startup: init DB + ETL engine + start poll loop. Shutdown: stop loop."""
    global _db_manager, _db_url, _worker_id, _poll_thread, _heartbeat_thread

    from core.config import paths as _paths, etl_pipelines as _etl_cfg

    # Logging
    log_level = os.getenv("QUERYSTUDIO_SERVER_LOG_LEVEL", "info").upper()
    logging.basicConfig(
        level=getattr(logging, log_level, logging.INFO),
        format="%(asctime)s [%(name)s] %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    # 2026-09-27 -- the ONE startup line naming the config file this pod loaded.
    from core.config import log_config_source
    log_config_source(logger)

    # Database
    # 2026-08-11 -- was an UNCONDITIONAL sqlite URL, ignoring database.type.
    # On PostgreSQL this worker wrote to a local SQLite while the API used
    # Postgres -- split brain, and silent (it logs a healthy "Database:
    # sqlite:///..." and creates the file).  Same fix as scheduler_worker and
    # executor_worker: reuse the CLI resolver, which already honours the
    # BF-409 env ladder that reading postgresql_url directly does not.
    from querystudio.cli import _resolve_cli_db_target
    _db_url, _db_label, db_file = _resolve_cli_db_target()

    from core.database import DatabaseManager
    _db_manager = DatabaseManager(db_url=_db_url)
    logger.info("Database: %s", _db_label)  # the label masks the password

    # Init ETL engine
    from core.etl_engine import init_etl_engine
    init_etl_engine(_db_manager, broadcast_fn=None)
    logger.info("ETL engine initialised")

    # Worker identity
    _worker_id = f"etl-{platform.node()}:{os.getpid()}"
    _stats["started_at"] = datetime.now(timezone.utc).isoformat()
    logger.info("Worker ID: %s", _worker_id)

    # Start poll loop thread
    poll_interval = _etl_cfg.poll_interval_seconds
    _poll_thread = threading.Thread(
        target=_poll_loop,
        args=(poll_interval,),
        daemon=True,
        name="etl-poll-loop",
    )
    _poll_thread.start()

    # Start heartbeat thread
    _heartbeat_thread = threading.Thread(
        target=_heartbeat_loop,
        daemon=True,
        name="etl-heartbeat",
    )
    _heartbeat_thread.start()

    worker_host = os.getenv("QUERYSTUDIO_ETL_WORKER_HOST", "127.0.0.1")
    worker_port = int(os.getenv("QUERYSTUDIO_ETL_WORKER_PORT", "8004"))
    logger.info(
        "ETL worker ready on %s:%d (poll_interval=%ds)",
        worker_host, worker_port, poll_interval,
    )

    yield  # App is running

    # Shutdown
    _shutdown_event.set()
    if _poll_thread and _poll_thread.is_alive():
        _poll_thread.join(timeout=10)
    if _heartbeat_thread and _heartbeat_thread.is_alive():
        _heartbeat_thread.join(timeout=5)

    # Deregister from worker registry
    try:
        from core.worker_registry import get_worker_registry
        get_worker_registry().deregister(_worker_id)
    except Exception:
        pass
    logger.info("ETL worker stopped")


# ── Poll loop ───────────────────────────────────────────────────────────────

def _poll_loop(poll_interval: float):
    """Poll for pending ETL executions and dispatch them."""
    logger.info("ETL poll loop started (interval=%ds)", poll_interval)

    while not _shutdown_event.is_set():
        if not _paused.is_set():
            _shutdown_event.wait(timeout=poll_interval)
            continue

        try:
            # Reset orphaned claimed/running executions before polling
            _db_manager.reset_stale_claimed_executions(stale_minutes=10)
            _db_manager.reset_stale_running_executions(stale_minutes=24 * 60)  # this worker's own 24 h, unchanged

            pending = _db_manager.get_pending_etl_executions(limit=5)
            for execution in pending:
                if _shutdown_event.is_set():
                    break
                # Atomic claim — prevents thundering herd with multiple workers
                claimed = _db_manager.claim_etl_execution(execution["id"], _worker_id)
                if not claimed:
                    logger.debug("Execution %s already claimed by another worker", execution.get("execution_id"))
                    continue
                _stats["tasks_claimed"] += 1
                _dispatch_pending(claimed)
        except Exception as exc:
            logger.error("ETL poll error: %s", exc)

        _shutdown_event.wait(timeout=poll_interval)

    logger.info("ETL poll loop stopped")


def _dispatch_pending(execution: dict):
    """Dispatch a pending execution to the ETL engine."""
    execution_id = execution.get("execution_id", "unknown")
    pipeline_id = execution.get("pipeline_id")

    try:
        pipeline = _db_manager.get_etl_pipeline(pipeline_id)
        if not pipeline:
            logger.warning("Pipeline %d not found for execution %s", pipeline_id, execution_id)
            _db_manager.update_etl_execution(execution["id"], {
                "status": "failed",
                "error_message": f"Pipeline {pipeline_id} not found",
                "error_stage": "trigger",
                "completed_at": datetime.now(timezone.utc),
            })
            _stats["tasks_failed"] += 1
            return

        if not pipeline.get("is_active"):
            logger.warning("Pipeline %d inactive, skipping execution %s", pipeline_id, execution_id)
            _db_manager.update_etl_execution(execution["id"], {
                "status": "cancelled",
                "error_message": "Pipeline is inactive",
                "completed_at": datetime.now(timezone.utc),
            })
            return

        # Pick backend and dispatch
        from core.etl_engine import _pick_backend

        backend = execution.get("execution_backend_used")
        if not backend:
            backend = _pick_backend(pipeline)
            _db_manager.update_etl_execution(execution["id"], {
                "execution_backend_used": backend,
            })

        logger.info(
            "Dispatching execution %s for pipeline '%s' via %s",
            execution_id, pipeline.get("name"), backend,
        )

        # Run in async context
        loop = asyncio.new_event_loop()
        try:
            from core.etl_engine import _dispatch_execution
            loop.run_until_complete(_dispatch_execution(pipeline, execution, backend))
            _stats["tasks_completed"] += 1
        except Exception as exc:
            logger.error("Execution %s failed: %s", execution_id, exc)
            _stats["tasks_failed"] += 1
        finally:
            loop.close()

    except Exception as exc:
        logger.error("Dispatch error for execution %s: %s", execution_id, exc)
        _stats["tasks_failed"] += 1


# ── Heartbeat loop ──────────────────────────────────────────────────────────

def _heartbeat_loop():
    """Register worker and send periodic heartbeats."""
    heartbeat_interval = 30  # seconds

    while not _shutdown_event.is_set():
        try:
            from core.worker_registry import get_worker_registry
            registry = get_worker_registry()

            cpu_pct = psutil.cpu_percent(interval=1) if _HAS_PSUTIL else 0.0
            mem_pct = psutil.virtual_memory().percent if _HAS_PSUTIL else 0.0
            mem_mb = (psutil.Process().memory_info().rss // (1024 * 1024)) if _HAS_PSUTIL else 0

            registry.register_or_update(
                worker_id=_worker_id,
                hostname=platform.node(),
                pid=os.getpid(),
                worker_type="etl",
                status="paused" if not _paused.is_set() else "running",
                active_tasks=_stats.get("tasks_claimed", 0) - _stats.get("tasks_completed", 0) - _stats.get("tasks_failed", 0),
                max_concurrent=5,
                cpu_pct=cpu_pct,
                memory_pct=mem_pct,
                memory_mb=mem_mb,
                version="1.0.0",
            )
        except Exception as exc:
            logger.debug("Heartbeat failed: %s", exc)

        _shutdown_event.wait(timeout=heartbeat_interval)

    logger.info("ETL heartbeat loop stopped")


# ── Control API ─────────────────────────────────────────────────────────────

control_app = FastAPI(
    title="QueryStudio ETL Worker",
    docs_url=None,
    redoc_url=None,
    lifespan=_lifespan,
)


@control_app.get("/health")
async def health():
    """Full status — ETL worker state + DB connectivity."""
    db_ok = False
    try:
        if _db_manager:
            _db_manager.list_etl_pipelines(is_active=True)
            db_ok = True
    except Exception:
        pass
    return {
        "status": "ok" if db_ok else "degraded",
        "database": {"ok": db_ok},
        "worker_id": _worker_id,
        "paused": not _paused.is_set(),
        **_stats,
    }


@control_app.get("/health/live")
async def liveness():
    """K8s liveness — always 200 if process is up."""
    return {"status": "alive"}


@control_app.get("/health/ready")
async def readiness():
    """K8s readiness — checks DB connectivity."""
    db_ok = False
    try:
        if _db_manager:
            _db_manager.list_etl_pipelines(is_active=True)
            db_ok = True
    except Exception:
        pass
    if not db_ok:
        return JSONResponse(status_code=503, content={"status": "not_ready", "reason": "database unavailable"})
    return {"status": "ready"}


@control_app.get("/control/status")
async def etl_status():
    """Full ETL worker state: pending executions, circuit breakers, stats."""
    pending = []
    try:
        pending = _db_manager.get_pending_etl_executions(limit=20) if _db_manager else []
    except Exception:
        pass

    breakers = {}
    try:
        from core.etl_engine import get_circuit_breaker_status
        breakers = get_circuit_breaker_status()
    except Exception:
        pass

    return {
        "worker_id": _worker_id,
        "paused": not _paused.is_set(),
        "pending_count": len(pending),
        "pending_executions": pending[:10],
        "circuit_breakers": breakers,
        **_stats,
    }


@control_app.post("/control/pause")
async def pause():
    """Pause claiming new jobs. Running jobs finish normally."""
    _paused.clear()
    logger.info("ETL worker paused")
    return {"message": "ETL worker paused"}


@control_app.post("/control/resume")
async def resume():
    """Resume claiming jobs."""
    _paused.set()
    logger.info("ETL worker resumed")
    return {"message": "ETL worker resumed"}


@control_app.post("/control/shutdown")
async def shutdown():
    """Graceful shutdown — stop worker and exit."""
    logger.info("Shutdown requested via control API")
    def _delayed_exit():
        time.sleep(1)
        os._exit(0)
    threading.Thread(target=_delayed_exit, daemon=True).start()
    return {"message": "Shutting down"}


# ── Entry point ─────────────────────────────────────────────────────────────

def main():
    import uvicorn

    host = os.getenv("QUERYSTUDIO_ETL_WORKER_HOST", "127.0.0.1")
    port = int(os.getenv("QUERYSTUDIO_ETL_WORKER_PORT", "8004"))

    print(f"[etl_worker] Starting on {host}:{port}")

    uvicorn.run(
        control_app,
        host=host,
        port=port,
        log_level="warning",
        access_log=False,
    )


if __name__ == "__main__":
    main()
