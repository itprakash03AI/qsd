"""
QueryStudio JOB WORKER -- the one worker tier for every background execution
that is not a feed (2026-11-02, core/responsibilities.py).

The owner: "one worker tier i m ok ... but feed worker should do feed work".
This process declares itself the JOB_WORKER and owns BACKGROUND_EXECUTION:

* it CLAIMS ``task_queue`` rows -- ``scheduled_report`` (a user schedule the
  scheduler pod fired; core/scheduler.py::_run_scheduled_job queues it here)
  and the legacy ``parquet_query`` / ``sql_query`` / ``export`` / ... tasks
  an API in ``executor.mode=external`` still writes while it is migrated to
  query pods (docs/COMPONENT_RESPONSIBILITIES_2026_11_02.html §5);
* it HOSTS the executing daemons the scheduler pod used to run in-process:
  data-quality rules, ETL pipelines, DataFlow runs, reconciliation, custom
  jobs, value-list fills, data mirrors, bloom builds, subscription deliveries
  (``core/daemon_registry.py::JOB_WORKER_DAEMONS``), under the tier's own
  leader election (lock row ``core.scheduler.JOB_WORKER_LOCK_ID``) and an
  in-memory APScheduler (``core.scheduler.init_job_worker_scheduler``).

It never runs a feed and never fires a user schedule itself.

Usage:
    python -m querystudio job-worker          (``executor`` is the old name, kept)
    python executor_worker.py

The control API on ``executor.worker_host:executor.worker_port`` (default
127.0.0.1:8002) serves the probes, pause/resume, status, and -- like the
scheduler worker -- ``/control/background-job/*`` and
``/control/daemon-snapshot/*`` so the API pod's admin routes are answered by
the process that RUNS the job.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import platform
import signal
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Ensure the backend directory is on sys.path so ``core.*`` imports work
_backend_dir = Path(__file__).resolve().parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from fastapi import FastAPI, HTTPException  # noqa: E402
from core.download_retention import (
    download_expires_at as _download_expires_at)

# psutil is optional — used for heartbeat metrics and load-aware claiming
try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:
    psutil = None  # type: ignore[assignment]
    _HAS_PSUTIL = False

logger = logging.getLogger("executor_worker")


# ── Webhook helper ────────────────────────────────────────────────────────────

def _fire_webhook(callback_url: str, payload: dict) -> None:
    """POST task result to callback_url — non-blocking, best-effort, daemon thread."""
    import urllib.request as _urlreq
    import json as _json

    def _post():
        try:
            data = _json.dumps(payload, default=str).encode()
            req = _urlreq.Request(
                callback_url,
                data=data,
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "QueryStudio/1.0",
                },
                method="POST",
            )
            with _urlreq.urlopen(req, timeout=15):
                pass
            logger.info("Webhook delivered: %s", callback_url)
        except Exception as exc:
            logger.warning("Webhook POST failed to %s: %s", callback_url, exc)

    threading.Thread(target=_post, daemon=True).start()

# ── Globals (set during lifespan) ────────────────────────────────────────────
_db_manager = None
_db_url: str = ""
_worker_id: str = ""
_shutdown_event = threading.Event()
_executor_thread: Optional[threading.Thread] = None
_stale_thread: Optional[threading.Thread] = None
_heartbeat_thread: Optional[threading.Thread] = None
_paused = threading.Event()  # clear = paused, set = running
_paused.set()  # start running

# Stats
_stats = {
    "tasks_completed": 0,
    "tasks_failed": 0,
    "tasks_claimed": 0,
    "started_at": None,
}


# ── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Startup: init DB + start executor loop. Shutdown: stop loop."""
    global _db_manager, _db_url, _worker_id, _executor_thread, _stale_thread, _heartbeat_thread

    # ── Load config ──────────────────────────────────────────────────────
    from core.config import paths as _paths, executor as _exec_cfg

    # ── Logging ──────────────────────────────────────────────────────────
    log_level = os.getenv("QUERYSTUDIO_SERVER_LOG_LEVEL", "info").upper()
    logging.basicConfig(
        level=getattr(logging, log_level, logging.INFO),
        format="%(asctime)s [%(name)s] %(levelname)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    # 2026-11-02 -- THE DECLARATION (core/responsibilities.py): this process
    # runs background jobs -- never feeds, never the schedule itself.
    from core import responsibilities as _resp
    _resp.declare(_resp.JOB_WORKER, by="executor_worker.py")
    # 2026-09-27 -- the ONE startup line naming the config file this pod loaded.
    from core.config import log_config_source
    log_config_source(logger)

    # ── Database ─────────────────────────────────────────────────────────
    # 2026-08-11 -- was ``_db_url = f"sqlite:///{db_file}"`` UNCONDITIONALLY,
    # ignoring ``database.type``.  On a PostgreSQL deployment this worker wrote
    # to a LOCAL SQLITE FILE while the API used Postgres -- split brain, and
    # silent: the worker logs a healthy "Database: sqlite:///..." and creates
    # the file.  Observed live in the local docker stack (a 3 MB SQLite
    # appeared alongside a Postgres-backed API).
    #
    # The identical bug was fixed for the CLI on 2026-06-04 by
    # ``_resolve_cli_db_target()`` (querystudio/cli.py) and never ported here.
    # Reuse that resolver rather than growing a fourth copy of the ladder --
    # it already honours the BF-409 env chain (QUERYSTUDIO_DATABASE_URL /
    # _CMD / _SECRET -> postgresql_url -> composed parts) which reading
    # ``postgresql_url`` directly does not, and which is what K8s deploys use.
    #
    # Affects docker-compose.production.yml, docker-compose.scale.yml and the
    # Helm scheduler/worker charts on ANY PostgreSQL deployment.
    from querystudio.cli import _resolve_cli_db_target
    _db_url, _db_label, db_file = _resolve_cli_db_target()

    from core.database import DatabaseManager
    _db_manager = DatabaseManager(db_url=_db_url)
    logger.info("Database: %s", _db_label)  # the label masks the password
    # 2026-11-02 -- the DB config overlay (admin app-config is live here), like
    # every other entry point; non-fatal, loudly.
    try:
        import core.config as _cfg_mod
        _cfg_mod.init_db_settings(_db_manager)
    except Exception as _cfg_db_exc:      # pragma: no cover - defensive
        logger.warning("config.init_db_settings failed (non-fatal): %s -- this pod runs on "
                       "config-FILE values and will NOT see admin changes", _cfg_db_exc)
    # 2026-10-17 -- this pod's component-health reporter (per pod).
    try:
        from core.component_health.reporter import start_reporter as _ch_start
        _ch_start(_db_manager)
    except Exception as _ch_exc:  # noqa: BLE001
        logger.warning("component_health reporter not started (non-fatal): %s", _ch_exc)
    # 2026-11-02 -- the deps the executing daemons and a scheduled report reach
    # (delivery engine, reports_api engines, feed authoring, s3_utilities ...):
    # ONE wiring function, shared with scheduler_worker.py.
    try:
        from core.daemon_registry import wire_scheduled_execution_deps
        logger.info("job-worker: execution deps wired: %s", wire_scheduled_execution_deps(_db_manager))
    except Exception as _wire_exc:  # noqa: BLE001
        logger.warning("job-worker: execution deps not wired (%s) -- scheduled reports and "
                       "deliveries will fail until this is fixed", _wire_exc)
    _worker_loop = asyncio.get_running_loop()

    # ── Queue backend ──────────────────────────────────────────────────
    from core.queue_backend import init_queue_backend, get_task_queue
    init_queue_backend(_db_manager)
    _tq = get_task_queue()
    logger.info("Queue backend: %s", _tq.backend_type)

    # ── Worker identity ──────────────────────────────────────────────────
    _worker_id = f"{platform.node()}:{os.getpid()}"
    _stats["started_at"] = datetime.now(timezone.utc).isoformat()
    logger.info("Worker ID: %s", _worker_id)

    # ── Start executor loop thread ───────────────────────────────────────
    _executor_thread = threading.Thread(
        target=_executor_main_loop,
        args=(_tq, _db_manager, _worker_id, _exec_cfg.max_concurrent, _exec_cfg.poll_interval),
        daemon=True,
        name="executor-loop",
    )
    _executor_thread.start()

    # ── Start stale task reclaimer thread ────────────────────────────────
    _stale_thread = threading.Thread(
        target=_stale_reclaimer_loop,
        args=(_tq, _exec_cfg.stale_timeout_seconds),
        daemon=True,
        name="stale-reclaimer",
    )
    _stale_thread.start()

    # ── Start heartbeat loop thread (Phase 45D) ─────────────────────────
    _heartbeat_thread = threading.Thread(
        target=_heartbeat_loop,
        args=(_db_manager, _worker_id, _exec_cfg.max_concurrent),
        daemon=True,
        name="heartbeat-loop",
    )
    _heartbeat_thread.start()

    # 2026-11-02 -- the daemon host: the tier's lock, an in-memory APScheduler,
    # the executing daemons (daemon_registry, filtered to this tier's homes),
    # pause persistence, background_jobs autostart on this loop.
    threading.Thread(target=_start_daemon_host, args=(_worker_loop,),
                     daemon=True, name="job-worker-daemon-host").start()

    logger.info(
        "Job worker ready on %s:%d (max_concurrent=%d, poll=%.1fs)",
        _exec_cfg.worker_host, _exec_cfg.worker_port,
        _exec_cfg.max_concurrent, _exec_cfg.poll_interval,
    )

    yield  # ── App is running ──

    # ── Shutdown ─────────────────────────────────────────────────────────
    # the daemon host first (inside the grace period), then the task loop
    try:
        from core.scheduler import shutdown_scheduler, JOB_WORKER_LOCK_ID
        import core.scheduler as _cs
        shutdown_scheduler()
        if _cs._scheduler_worker_id and _db_manager is not None:
            _db_manager.release_scheduler_lock(_cs._scheduler_worker_id, lock_id=JOB_WORKER_LOCK_ID)
    except Exception as _sd_exc:  # noqa: BLE001
        logger.warning("job-worker daemon host shutdown: %s", _sd_exc)
    _shutdown_event.set()
    if _executor_thread and _executor_thread.is_alive():
        _executor_thread.join(timeout=10)
    if _heartbeat_thread and _heartbeat_thread.is_alive():
        _heartbeat_thread.join(timeout=5)
    # Safety-net deregister in case heartbeat thread did not complete cleanly
    try:
        from core.worker_registry import get_worker_registry
        get_worker_registry().deregister(_worker_id)
    except Exception:
        pass
    logger.info("Executor worker stopped")


# ── Executor main loop ───────────────────────────────────────────────────────

_daemon_host_state: dict = {"attempted": False, "apscheduler": False, "registered": None,
                            "not_registered": None, "error": None}


def _start_daemon_host(loop) -> None:
    """The job-worker tier's daemon host (see the module docstring).  Runs on
    its own thread like scheduler_worker._start_scheduler; a lost election
    is retried inside init_job_worker_scheduler and the registrations are
    then made by the scheduler's started-hook (late registration)."""
    _daemon_host_state["attempted"] = True
    try:
        from core import background_jobs as _bj
        from core.daemon_registry import DaemonContext, register_scheduler_owned
        from core.scheduler import get_daemon_scheduler, init_job_worker_scheduler
        try:
            _bj.init_persistence(_db_manager)
        except Exception as _p_exc:  # noqa: BLE001
            logger.warning("job-worker: background_jobs pause persistence not wired: %s", _p_exc)
        started = init_job_worker_scheduler(_db_manager)
        _daemon_host_state["apscheduler"] = bool(started)
        ctx = DaemonContext(db_manager=_db_manager, scheduler=get_daemon_scheduler(), loop=loop)
        results = register_scheduler_owned(ctx)
        _daemon_host_state["registered"] = sorted(n for n, ok in results.items() if ok is True)
        _daemon_host_state["not_registered"] = {n: str(v) for n, v in results.items() if v is not True}
        logger.info("job-worker: %d/%d executing daemons registered%s",
                    len(_daemon_host_state["registered"]), len(results),
                    "" if started else " (APScheduler not started here yet: another job-worker leads; "
                                        "retrying)")

        async def _autostart():
            _bj.autostart_all()

        asyncio.run_coroutine_threadsafe(_autostart(), loop)
    except Exception as exc:  # noqa: BLE001
        _daemon_host_state["error"] = f"{type(exc).__name__}: {exc}"
        logger.error("job-worker daemon host failed to start: %s", exc, exc_info=True)


def _executor_main_loop(task_queue, db_manager, worker_id: str, max_concurrent: int, poll_interval: float):
    """Claim tasks from queue, execute them in a thread pool.

    Uses blocking pop (BZPOPMIN) for Redis — instant delivery.
    Uses polling (claim_next_task) for SQLite — same as before.
    """
    # 0 = UNLIMITED product-wide.  Semaphore(0) would claim tasks and never
    # run them; ThreadPoolExecutor(max_workers=0) raises outright.  Neither is
    # the "no restriction" the operator's spelling asks for.
    from core.concurrency_permits import sem_permits as _sem_permits
    _permits = _sem_permits(max_concurrent, name="executor_worker")
    semaphore = threading.Semaphore(_permits)
    pool = ThreadPoolExecutor(max_workers=_permits, thread_name_prefix="exec")
    use_blocking = task_queue.backend_type == "redis"

    logger.info("Executor loop started (max_concurrent=%d, blocking=%s)", max_concurrent, use_blocking)

    while not _shutdown_event.is_set():
        # Check if paused
        if not _paused.is_set():
            _shutdown_event.wait(1.0)
            continue

        # Load-aware gate (Phase 45E) — skip claiming if system is overloaded
        if _should_skip_claiming() or _is_draining():
            _shutdown_event.wait(poll_interval)
            continue

        # Try to acquire a slot (non-blocking)
        if not semaphore.acquire(timeout=0.5):
            continue

        try:
            if use_blocking:
                task = task_queue.wait_and_claim_task(worker_id, timeout=poll_interval)
            else:
                task = task_queue.claim_next_task(worker_id)
        except Exception as exc:
            semaphore.release()
            logger.error("Failed to claim task: %s", exc)
            _shutdown_event.wait(poll_interval)
            continue

        if not task:
            semaphore.release()
            if not use_blocking:
                _shutdown_event.wait(poll_interval)
            continue

        _stats["tasks_claimed"] += 1
        logger.info("Claimed task %s (type=%s, execution=%s)",
                     task["task_id"], task["task_type"], task.get("execution_id"))

        pool.submit(_run_task_safe, task_queue, db_manager, task, semaphore)

    pool.shutdown(wait=True, cancel_futures=True)
    logger.info("Executor loop stopped")


def _run_task_safe(task_queue, db_manager, task: dict, semaphore):
    """Execute a task with error handling. Always releases semaphore."""
    callback_url = (task.get("payload") or {}).get("callback_url", "")
    execution_id = task.get("execution_id", "")
    try:
        _run_task(task_queue, db_manager, task)
        _stats["tasks_completed"] += 1
        if callback_url:
            _fire_webhook(callback_url, {
                "event": "task_completed",
                "execution_id": execution_id,
                "task_id": task["task_id"],
                "status": "completed",
            })
    except InterruptedError:
        # Cooperative cancellation — not a failure
        logger.info("Task %s cancelled by user", task["task_id"])
        try:
            task_queue.fail_task(task["task_id"], "Cancelled by user")
            if execution_id:
                db_manager.update_execution(
                    execution_id,
                    status="cancelled",
                    error_message="Cancelled by user",
                )
        except Exception as _cancel_exc:
            logger.error("Failed to update cancelled execution %s: %s", execution_id, _cancel_exc)
        if callback_url:
            _fire_webhook(callback_url, {
                "event": "task_cancelled",
                "execution_id": execution_id,
                "task_id": task["task_id"],
                "status": "cancelled",
            })
    except Exception as exc:
        _stats["tasks_failed"] += 1
        error_str = str(exc)
        retry_count  = int(task.get("retry_count", 0))
        max_retries  = int(task.get("max_retries", 3))
        # 2026-10-13 -- a failure the SAME input will hit again is not
        # retried: a bad query, a missing column, an empty file list, a
        # refusal.  It used to be retried 3 more times over 3.5 minutes
        # before the user saw the reason (found on the owner's direct AWS S3
        # read).  Transient failures (connection, timeout, I/O) still retry.
        if _cannot_succeed_on_retry(exc):
            retry_count = max_retries

        if retry_count < max_retries:
            # ── Exponential backoff retry (22C) ──────────────────────────────
            # Delay = min(base * 2^retry, cap) with base=30s, cap=1800s
            base_delay = 30
            delay_secs = min(base_delay * (2 ** retry_count), 1800)
            # 2026-09-17 -- exc_info, because without it this is undiagnosable.
            #
            # A task failed four times with "signal only works in main thread
            # of the main interpreter" and the logs carried nothing but that
            # sentence: no frame, no module, no library.  The retry handler
            # logged str(exc) and threw the traceback away, so the ONE place
            # that knows where the failure came from discarded it and then
            # retried three more times, producing three more copies of the
            # same uninformative line.  Unknown is not empty.
            logger.warning(
                "Task %s failed (attempt %d/%d), retrying in %ds: %s",
                task["task_id"], retry_count + 1, max_retries + 1, delay_secs,
                error_str, exc_info=True
            )
            try:
                # Re-enqueue with future timestamp as priority score
                new_task_id = str(uuid.uuid4())
                new_payload = dict(task.get("payload") or {})
                task_queue.enqueue_task(
                    task_id=new_task_id,
                    task_type=task.get("task_type", "parquet_query"),
                    payload=new_payload,
                    execution_id=execution_id,
                    created_by=task.get("created_by", ""),
                    priority=task.get("priority", 5),
                    retry_count=retry_count + 1,
                    max_retries=max_retries,
                    delay_seconds=delay_secs,
                )
                # Update execution status to reflect retry
                if execution_id:
                    db_manager.update_execution(
                        execution_id,
                        status="pending",
                        error_message=f"Retry {retry_count + 1}/{max_retries} in {delay_secs}s: {error_str}",
                    )
            except Exception as retry_exc:
                logger.error("Failed to re-enqueue task %s for retry: %s", task["task_id"], retry_exc)
            # Mark original task as failed
            try:
                task_queue.fail_task(task["task_id"], f"[retry {retry_count+1}] {error_str}")
            except Exception as _fail_exc:
                logger.error("Failed to mark task %s as failed: %s", task["task_id"], _fail_exc)
        else:
            # ── Exhausted retries → Dead-Letter Queue (22C) ──────────────────
            logger.error(
                "Task %s permanently failed after %d attempts, moving to DLQ: %s",
                task["task_id"], max_retries + 1, error_str, exc_info=True
            )
            try:
                task_queue.fail_task(task["task_id"], f"[DLQ] {error_str}")
                if execution_id:
                    db_manager.update_execution(
                        execution_id,
                        status="failed",
                        error_message=f"Permanently failed after {max_retries + 1} attempts: {error_str}",
                    )
                # Push to DLQ table for manual review/replay
                db_manager.push_dead_letter(
                    {**task, "retry_count": retry_count},
                    error=error_str,
                )
                _stats["tasks_dead_lettered"] = _stats.get("tasks_dead_lettered", 0) + 1
            except Exception:
                logger.error("Failed to push task %s to DLQ", task["task_id"], exc_info=True)

            if callback_url:
                _fire_webhook(callback_url, {
                    "event": "task_failed",
                    "execution_id": execution_id,
                    "task_id": task["task_id"],
                    "status": "failed",
                    "error": error_str,
                    "dead_lettered": True,
                })
    finally:
        semaphore.release()


def _run_task(task_queue, db_manager, task: dict):
    """Execute a single task based on its type."""
    task_type = task["task_type"]
    payload = task["payload"]
    task_id = task["task_id"]
    execution_id = task.get("execution_id")

    # Progress callback: writes to task queue + checks cancellation
    _last_progress_t = [time.monotonic()]
    _last_cancel_check = [time.monotonic()]

    def progress_fn(data: dict):
        now = time.monotonic()

        # Check cancellation every 2 seconds
        if now - _last_cancel_check[0] >= 2.0:
            _last_cancel_check[0] = now
            try:
                if task_queue.is_task_cancelled(task_id):
                    raise InterruptedError("Cancelled by user")
            except InterruptedError:
                raise
            except Exception:
                pass

        # Throttle progress writes to 1 update/second
        is_terminal = data.get("status") in ("completed", "failed")
        if not is_terminal and now - _last_progress_t[0] < 1.0:
            return
        _last_progress_t[0] = now

        pct = data.get("progress_pct", 0)
        detail = data.get("log", "")
        try:
            task_queue.update_task_progress(task_id, pct, detail)
        except Exception as _prog_exc:
            logger.warning("Failed to update progress for task %s: %s", task_id, _prog_exc)
        # Also update QueryExecution status (always in SQLite)
        if execution_id:
            try:
                db_manager.update_execution(
                    execution_id,
                    status="processing",
                    chunks_processed=data.get("chunks_processed", 0),
                    total_rows=data.get("total_rows", 0),
                )
            except Exception:
                pass

    if task_type == "parquet_query":
        result = _execute_parquet_query(db_manager, payload, progress_fn)
    elif task_type == "sql_query":
        result = _execute_sql_query(db_manager, payload, progress_fn)
    elif task_type == "export":
        result = _execute_export(db_manager, payload, progress_fn)
    elif task_type == "mv_refresh":
        result = _execute_mv_refresh(db_manager, payload, progress_fn)
    elif task_type == "lt_promote":
        result = _execute_lt_promote(db_manager, payload, progress_fn)
    elif task_type == "lt_upload":
        result = _execute_lt_upload(db_manager, payload, progress_fn)
    elif task_type == "scheduled_report":
        # 2026-11-02 -- a user schedule the scheduler pod fired
        # (core/scheduler.py::_run_scheduled_job -> _enqueue_scheduled_job):
        # the report runs HERE, the pod that owns background execution.
        from core.scheduler import _execute_scheduled_job
        _execute_scheduled_job(int(payload["schedule_id"]), force=bool(payload.get("force")))
        result = {"schedule_id": int(payload["schedule_id"]), "ran_on": platform.node()}
    else:
        raise ValueError(f"Unknown task type: {task_type}")

    # Finalize: update QueryExecution + register DownloadFile
    _finalize_task(db_manager, task, result)
    task_queue.complete_task(task_id, result)
    logger.info("Task %s completed: %s", task_id, result)


def _finalize_task(db_manager, task: dict, result: dict):
    """Update QueryExecution record and register DownloadFile."""
    execution_id = task.get("execution_id")
    if not execution_id:
        return

    output_file = result.get("output_file")
    total_rows = result.get("total_rows", 0)
    file_size = result.get("file_size_bytes", 0)

    db_manager.update_execution(
        execution_id,
        status="completed",
        total_rows=total_rows,
        file_size_bytes=file_size,
        output_file=output_file,
    )

    # Register download file
    if output_file and os.path.exists(output_file):
        file_id = str(uuid.uuid4())
        filename = os.path.basename(output_file)
        try:
            from datetime import timedelta
            db_manager.create_download_file(
                file_id=file_id,
                execution_id=execution_id,
                filename=filename,
                file_path=output_file,
                file_size_bytes=file_size,
                created_by=task.get("created_by", "executor"),
                expires_at=_download_expires_at(),
            )
            result["file_id"] = file_id
        except Exception as exc:
            logger.warning("Failed to register download file: %s", exc)


# ── Task execution functions ─────────────────────────────────────────────────
# These import and reuse the same core functions from main.py.

def _resolve_connection(db_manager, connection_id) -> dict:
    """Resolve connection config with decrypted credentials."""
    if not connection_id:
        return None
    conn_record = db_manager.get_connection_raw(connection_id)
    if not conn_record:
        logger.warning("Connection %s not found", connection_id)
        return None
    return conn_record


def _setup_engine_s3(engine, conn_record, connection_id):
    """Inject S3 credentials into ParquetQueryEngine (mirrors main.py:4915-4918)."""
    cfg = conn_record.get("config", {}) if conn_record else {}
    conn_type = conn_record.get("connection_type", "") if conn_record else ""

    if conn_type == "s3" and cfg.get("bucket_name"):
        engine._s3_conn_config = cfg
        engine._registered_tables = cfg.get("registered_tables", [])
        engine._s3_bucket = cfg.get("bucket_name", "")
        engine._s3_conn_id = connection_id
        try:
            from core.s3_storage import build_s3_config
            engine.s3_config = build_s3_config(cfg)
        except Exception as exc:
            logger.warning("Failed to build S3 config: %s", exc)
    else:
        engine._s3_conn_config = {}
        engine._registered_tables = []
        engine._s3_bucket = ""
        engine._s3_conn_id = connection_id


def _apply_duckdb_env_limits():
    """Set DuckDB resource limits and temp paths via environment variables.

    duckdb_subprocess.py reads these env vars before executing queries.
    Config.json is the source of truth — env vars are the transport to the
    subprocess (child processes inherit parent env automatically).
    """
    from core.config import executor as _exec_cfg, paths as _paths
    mem_limit_gb = _exec_cfg.max_memory_per_task_gb
    if mem_limit_gb > 0:
        os.environ["DUCKDB_MEMORY_LIMIT"] = f"{mem_limit_gb}GB"
        logger.info("DuckDB memory limit: %dGB (via env)", mem_limit_gb)
    # BF-379: was hardcoded to min(4, cpu_count) — artificially throttled
    # DuckDB to 4 threads even on big boxes, regardless of BF-378 config
    # default change.  Now reads from config (query_engine.duckdb_threads_per_query
    # = 0 means auto/all-cores; explicit positive int caps).
    try:
        from core.config import query_engine as _qe_thr
        _cfg_threads = int(_qe_thr.duckdb_threads_per_query)
    except Exception:
        _cfg_threads = 0
    threads = _cfg_threads if _cfg_threads > 0 else (os.cpu_count() or 4)
    os.environ["DUCKDB_THREADS"] = str(threads)

    # Temp paths from config → inherited by subprocesses
    _duckdb_tmp = str(_paths.duckdb_temp_dir)
    _ext_dir = str(_paths.duckdb_extension_dir)
    _dl_tmp = str(_paths.download_temp_dir)
    os.makedirs(_duckdb_tmp, exist_ok=True)
    os.makedirs(_ext_dir, exist_ok=True)
    os.makedirs(_dl_tmp, exist_ok=True)
    os.environ["DUCKDB_TEMP_DIR"] = _duckdb_tmp
    os.environ["DUCKDB_EXTENSION_DIR"] = _ext_dir
    os.environ["QS_DOWNLOAD_TEMP_DIR"] = _dl_tmp
    logger.info("DuckDB temp dirs: spill=%s, extensions=%s, downloads=%s", _duckdb_tmp, _ext_dir, _dl_tmp)

    # S3 download settings from config → env vars for subprocess inheritance
    from core.config import s3 as _s3_cfg
    os.environ["QS_S3_PARALLEL_WORKERS"] = str(_s3_cfg.parallel_download_workers)
    os.environ["QS_S3_DOWNLOAD_RETRIES"] = str(_s3_cfg.download_retries)
    os.environ["QS_S3_DOWNLOAD_TIMEOUT"] = str(_s3_cfg.download_timeout_seconds)
    os.environ["QS_DOWNLOAD_MIN_FREE_GB"] = str(_s3_cfg.min_free_disk_gb)


def _execute_parquet_query(db_manager, payload: dict, progress_fn) -> dict:
    """Execute a parquet query using the same engine as main.py.

    Features:
    - S3 credential resolution from connection_id
    - DuckDB memory budget via environment variables
    - Per-chunk cancellation via progress_fn (checks cancel_requested in DB)
    - Streaming parquet write with zstd compression
    """
    # 2026-09-17 -- WAS ``from main import ...``, and that broke EVERY
    # parquet query routed to this pod.
    #
    #   File "/app/executor_worker.py", line 591, in _execute_parquet_query
    #     from main import ParquetQueryEngine, QueryConfig
    #   File "/app/main.py", line 5742, in <module>
    #     _signal.signal(_signal.SIGINT, _force_exit_handler)
    #   ValueError: signal only works in main thread of the main interpreter
    #
    # ``main`` is the FastAPI application module; importing it runs its whole
    # module body, which installs process signal handlers -- legal at startup
    # on the main thread, impossible from a worker thread.  main only
    # RE-EXPORTS these two names from core.parquet_engine_v2 (main.py:387),
    # so nothing was ever gained by going through it.  Taking them from the
    # module that defines them means this worker no longer depends on the web
    # app being importable at all.
    from core.parquet_engine_v2 import ParquetQueryEngine
    from core.config import paths as _paths

    execution_id = payload["execution_id"]
    query_config = payload["query_config"]
    connection_id = payload.get("connection_id")

    # Build output path
    output_dir = Path(_paths.data_dir) / "downloads"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = str(output_dir / f"{execution_id}.parquet")

    # Resolve S3 credentials from connection
    conn_record = _resolve_connection(db_manager, connection_id)

    # Create engine + inject S3 config
    # 2026-09-26 (F3 / M1, D7) -- this lane had NEVER run.  Three crashes in
    # a row, each behind the previous one: ``ParquetQueryEngine(data_dir=)``
    # (the v2 constructor takes ``base_path``, and files are relative to the
    # PARQUET dir, as main.py constructs it); ``QueryConfig(**stored_dict)``
    # (the payload is ``QueryConfigModel.model_dump()`` -- 27 keys, and the
    # dataclass refuses ``connection_id``); and ``chunk.schema`` /
    # ``write_table(chunk)`` on the pandas frames ``execute_query`` yields.
    # Now: the one converter, the engine's own DuckDB road for every shape
    # beyond the pyarrow reader (aggregates, DISTINCT, OR, HAVING, computed,
    # CASE, window), and every chunk written as an Arrow table.
    engine = ParquetQueryEngine(base_path=str(_paths.parquet_dir))
    _setup_engine_s3(engine, conn_record, connection_id)

    # Build query config object
    if isinstance(query_config, dict):
        from core.query_converter import engine_config_from_stored
        qc = engine_config_from_stored(query_config, where=f"execution {execution_id}")
    else:
        qc = query_config

    # Set DuckDB memory/thread limits via env vars (read by duckdb_subprocess)
    _apply_duckdb_env_limits()

    progress_fn({"log": "Starting query execution...", "progress_pct": 5})

    # The engine's own road: DuckDB for any shape the pyarrow reader cannot
    # express (its ``_needs_duckdb``), pyarrow otherwise.  The DuckDB branch
    # yields Arrow tables, the pyarrow branch pandas frames -- both are
    # written as Arrow below.
    result = engine.execute_duckdb_query(qc)

    # Stream results to parquet with per-chunk cancellation
    import pyarrow as pa
    import pyarrow.parquet as pq
    total_rows = 0
    writer = None
    try:
        for chunk in result:
            if not isinstance(chunk, pa.Table):
                chunk = pa.Table.from_pandas(chunk, preserve_index=False)
            # progress_fn checks cancel_requested in DB (raises InterruptedError)
            progress_fn({
                "log": f"{total_rows:,} rows processed",
                "progress_pct": min(90, 10 + int(total_rows / 1000)),
                "total_rows": total_rows,
                "chunks_processed": total_rows,
            })
            if writer is None:
                writer = pq.ParquetWriter(output_file, chunk.schema, compression="zstd")
            writer.write_table(chunk)
            total_rows += len(chunk)
    finally:
        if writer:
            writer.close()

    file_size = os.path.getsize(output_file) if os.path.exists(output_file) else 0
    progress_fn({"log": f"Complete: {total_rows:,} rows", "progress_pct": 100, "status": "completed"})

    return {
        "total_rows": total_rows,
        "file_size_bytes": file_size,
        "output_file": output_file,
        "status": "completed",
    }


#: exception classes whose cause is the INPUT, not the moment -- a retry
#: meets the same answer (DuckDB's parser / binder / catalog errors by name:
#: the worker does not import duckdb at module level)
_PERMANENT_ERROR_NAMES = frozenset({
    "ParserException", "BinderException", "CatalogException", "ConversionException",
    "InvalidInputException", "NotImplementedException", "PermissionException",
})


def _cannot_succeed_on_retry(exc: BaseException) -> bool:
    """True for a failure the same task will meet again (see the caller).
    Connection, timeout and I/O errors are NOT here: they may pass next time."""
    if isinstance(exc, (OSError, TimeoutError, ConnectionError)):
        return False
    if isinstance(exc, (ValueError, TypeError, KeyError, AttributeError,
                        NotImplementedError, PermissionError)):
        return True
    return type(exc).__name__ in _PERMANENT_ERROR_NAMES


def _execute_sql_query(db_manager, payload: dict, progress_fn) -> dict:
    """Execute a SQL connector query (Snowflake, Trino, Databricks, Oracle)."""
    from core.config import paths as _paths

    connection_id = payload["connection_id"]
    raw_sql = payload.get("raw_sql", "")
    execution_id = payload["execution_id"]

    conn_record = _resolve_connection(db_manager, connection_id)
    if not conn_record:
        raise ValueError(f"Connection {connection_id} not found")

    conn_type = conn_record["connection_type"]
    cfg = conn_record["config"]

    from core.connectors import get_connector
    connector = get_connector(conn_type, cfg)

    progress_fn({"log": f"Connecting to {conn_type}...", "progress_pct": 10})
    con = connector.get_connection()

    try:
        progress_fn({"log": "Executing SQL...", "progress_pct": 20})
        cursor = con.cursor()
        cursor.execute(raw_sql)
        columns = [desc[0] for desc in cursor.description]

        # Stream to parquet
        output_dir = Path(_paths.data_dir) / "downloads"
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = str(output_dir / f"{execution_id}.parquet")

        import pyarrow as pa
        import pyarrow.parquet as pq

        total_rows = 0
        writer = None
        try:
            while True:
                batch = cursor.fetchmany(50000)
                if not batch:
                    break
                progress_fn({
                    "log": f"{total_rows:,} rows fetched from {conn_type}",
                    "progress_pct": min(85, 30 + total_rows // 1000),
                })
                # Build pyarrow table from rows
                col_data = {col: [row[i] for row in batch] for i, col in enumerate(columns)}
                table = pa.table(col_data)
                if writer is None:
                    writer = pq.ParquetWriter(output_file, table.schema, compression="zstd")
                writer.write_table(table)
                total_rows += len(batch)
        finally:
            if writer:
                writer.close()
            cursor.close()
    finally:
        try:
            con.close()
        except Exception:
            pass

    file_size = os.path.getsize(output_file) if os.path.exists(output_file) else 0
    progress_fn({"log": f"Complete: {total_rows:,} rows from {conn_type}", "progress_pct": 100, "status": "completed"})
    return {
        "total_rows": total_rows,
        "file_size_bytes": file_size,
        "output_file": output_file,
        "status": "completed",
    }


def _execute_export(db_manager, payload: dict, progress_fn) -> dict:
    """Convert a parquet result file to CSV/XLSX/JSON."""
    from core.config import paths as _paths

    source_file = payload["source_file"]
    output_format = payload.get("format", "csv")
    execution_id = payload.get("execution_id", str(uuid.uuid4()))

    output_dir = Path(_paths.data_dir) / "downloads"
    output_dir.mkdir(parents=True, exist_ok=True)

    progress_fn({"log": f"Exporting to {output_format.upper()}...", "progress_pct": 20})

    from core.duckdb_factory import duckdb_connection
    src = source_file.replace("\\", "/")
    out_path = None
    with duckdb_connection() as con:
        if output_format == "csv":
            out_path = str(output_dir / f"{execution_id}.csv")
            dest = out_path.replace("\\", "/")
            con.execute(f"COPY (SELECT * FROM read_parquet('{src}')) TO '{dest}' (HEADER, DELIMITER ',')")
        elif output_format == "xlsx":
            import pandas as pd
            df = con.execute(f"SELECT * FROM read_parquet('{src}')").fetchdf()
            out_path = str(output_dir / f"{execution_id}.xlsx")
            df.to_excel(out_path, index=False)
        elif output_format == "json":
            out_path = str(output_dir / f"{execution_id}.json")
            dest = out_path.replace("\\", "/")
            con.execute(f"COPY (SELECT * FROM read_parquet('{src}')) TO '{dest}' (FORMAT JSON)")
        else:
            raise ValueError(f"Unsupported export format: {output_format}")

    file_size = os.path.getsize(out_path) if out_path and os.path.exists(out_path) else 0
    progress_fn({"log": f"Export complete: {output_format.upper()}", "progress_pct": 100, "status": "completed"})
    return {
        "output_file": out_path,
        "file_size_bytes": file_size,
        "format": output_format,
        "status": "completed",
    }


def _execute_mv_refresh(db_manager, payload: dict, progress_fn) -> dict:
    """Refresh a materialized view — reuses main.py's sync function."""
    mv_id = payload["mv_id"]
    progress_fn({"log": f"Starting MV refresh (id={mv_id})...", "progress_pct": 10})

    # 2026-08-23 — this worker process never ran main.py's _startup, so
    # core.mv_manager's singletons were unwired and the refresh died on the
    # first DB call.  Wire them here (idempotent) before delegating.
    import core.mv_manager as _mvm
    if _mvm._db_manager is None or _mvm._mv_cfg is None:
        from core.config import materialized_views as _mv_cfg_w, local_tables as _lt_cfg_w

        class _NoopWs:
            def broadcast_sync(self, *_a, **_k):
                return None
        _mvm.init_mv_manager(db_manager, _NoopWs(), _mv_cfg_w, _lt_cfg_w)

    from core.mv_manager import refresh_materialized_view_sync as _refresh_materialized_view_sync
    _refresh_materialized_view_sync(mv_id)

    mv = db_manager.get_materialized_view(mv_id)
    row_count = mv.get("row_count", 0) if mv else 0
    progress_fn({"log": f"MV refresh complete: {row_count:,} rows", "progress_pct": 100, "status": "completed"})
    return {"mv_id": mv_id, "row_count": row_count, "status": "completed"}


def _execute_lt_promote(db_manager, payload: dict, progress_fn) -> dict:
    """Promote a download file to a local table — reuses main.py's sync function."""
    lt_id = payload["lt_id"]
    source_path = payload["source_path"]
    progress_fn({"log": f"Promoting local table {lt_id}...", "progress_pct": 20})

    from core.mv_manager import promote_download_sync as _promote_download_sync
    _promote_download_sync(lt_id, source_path)

    progress_fn({"log": "Promotion complete", "progress_pct": 100, "status": "completed"})
    return {"lt_id": lt_id, "status": "completed"}


def _execute_lt_upload(db_manager, payload: dict, progress_fn) -> dict:
    """Convert an uploaded file to parquet local table — reuses main.py's sync function."""
    lt_id = payload["lt_id"]
    temp_path = payload["temp_path"]
    original_filename = payload["original_filename"]
    progress_fn({"log": f"Converting {original_filename}...", "progress_pct": 20})

    from core.mv_manager import upload_file_to_local_table_sync as _upload_file_to_local_table_sync
    _upload_file_to_local_table_sync(lt_id, temp_path, original_filename)

    progress_fn({"log": "Upload complete", "progress_pct": 100, "status": "completed"})
    return {"lt_id": lt_id, "status": "completed"}


# ── Heartbeat loop (Phase 45D) ────────────────────────────────────────────────

def _heartbeat_loop(db_manager, worker_id: str, max_concurrent: int):
    """Periodically send heartbeats to the worker registry with system metrics.

    Registers on first call, then loops sending heartbeats every
    ``horizontal_workers.heartbeat_interval_seconds``.  Deregisters on exit.
    """
    from core.worker_registry import init_worker_registry, get_worker_registry, WorkerInfo
    from core.config import horizontal_workers as _hw_cfg

    interval = _hw_cfg.heartbeat_interval_seconds

    # Initialise the registry (idempotent — uses the module singleton)
    try:
        init_worker_registry(db_manager)
    except Exception as exc:
        logger.error("Failed to initialise worker registry: %s", exc)
        return

    registry = get_worker_registry()

    # Build initial WorkerInfo
    now_iso = datetime.now(timezone.utc).isoformat()
    info = WorkerInfo(
        worker_id=worker_id,
        hostname=platform.node(),
        pid=os.getpid(),
        status="active",
        worker_type="executor",
        started_at=_stats.get("started_at", now_iso),
        last_heartbeat=now_iso,
        active_tasks=0,
        max_concurrent=max_concurrent,
        cpu_pct=0.0,
        memory_pct=0.0,
        memory_mb=0,
        tasks_completed=_stats.get("tasks_completed", 0),
        tasks_failed=_stats.get("tasks_failed", 0),
        version="1.0",
    )

    # Register on startup
    try:
        registry.register(info)
        logger.info("Heartbeat loop registered worker %s (interval=%ds)", worker_id, interval)
    except Exception as exc:
        logger.error("Failed to register worker %s: %s", worker_id, exc)

    # Heartbeat loop
    while not _shutdown_event.is_set():
        _shutdown_event.wait(interval)
        if _shutdown_event.is_set():
            break

        # Collect system metrics
        cpu_pct = 0.0
        memory_pct = 0.0
        memory_mb = 0
        if _HAS_PSUTIL:
            try:
                cpu_pct = psutil.cpu_percent(interval=0)
                mem = psutil.virtual_memory()
                memory_pct = mem.percent
                memory_mb = int(mem.used / (1024 * 1024))
            except Exception as _psutil_exc:
                logger.warning("psutil metrics unavailable: %s", _psutil_exc)

        # Determine status
        status = "paused" if not _paused.is_set() else "active"

        now_iso = datetime.now(timezone.utc).isoformat()
        info = WorkerInfo(
            worker_id=worker_id,
            hostname=platform.node(),
            pid=os.getpid(),
            status=status,
            worker_type="executor",
            started_at=_stats.get("started_at", now_iso),
            last_heartbeat=now_iso,
            active_tasks=_stats.get("tasks_claimed", 0) - _stats.get("tasks_completed", 0) - _stats.get("tasks_failed", 0),
            max_concurrent=max_concurrent,
            cpu_pct=cpu_pct,
            memory_pct=memory_pct,
            memory_mb=memory_mb,
            tasks_completed=_stats.get("tasks_completed", 0),
            tasks_failed=_stats.get("tasks_failed", 0),
            version="1.0",
        )

        try:
            registry.heartbeat(worker_id, info)
        except Exception as exc:
            logger.warning("Heartbeat failed for %s: %s", worker_id, exc)

    # Deregister on exit
    try:
        registry.deregister(worker_id)
        logger.info("Heartbeat loop deregistered worker %s", worker_id)
    except Exception as exc:
        logger.warning("Failed to deregister worker %s: %s", worker_id, exc)


# ── Load-aware claiming (Phase 45E) ──────────────────────────────────────────

def _is_draining() -> bool:
    """2026-10-17 -- a DRAIN intent applied on this pod (component health):
    stop claiming; in-flight tasks finish.  Unreadable = not draining."""
    try:
        from core.component_health.intents import effective_draining
        return bool(effective_draining().get("active"))   # the flag OR the drain row (2026-10-18)
    except Exception:  # noqa: BLE001
        return False


def _should_skip_claiming() -> bool:
    """Return True if this worker should skip claiming due to high resource usage.

    Reads thresholds from ``horizontal_workers`` config.  Uses psutil if
    available; if psutil is not installed, always returns False (never skips).
    """
    from core.config import horizontal_workers as _hw_cfg

    if not _hw_cfg.enable_load_aware_claiming:
        return False

    if not _HAS_PSUTIL:
        return False

    try:
        mem = psutil.virtual_memory()
        if mem.percent > _hw_cfg.memory_threshold_pct:
            logger.warning(
                "Load-aware skip: memory usage %.1f%% exceeds threshold %d%%",
                mem.percent, _hw_cfg.memory_threshold_pct,
            )
            return True
    except Exception:
        pass

    try:
        cpu = psutil.cpu_percent(interval=0.1)
        if cpu > _hw_cfg.cpu_threshold_pct:
            logger.warning(
                "Load-aware skip: CPU usage %.1f%% exceeds threshold %d%%",
                cpu, _hw_cfg.cpu_threshold_pct,
            )
            return True
    except Exception:
        pass

    return False


# ── Stale task reclaimer ─────────────────────────────────────────────────────

def _stale_reclaimer_loop(task_queue, stale_timeout: int):
    """Periodically re-claim tasks stuck in claimed/processing state."""
    while not _shutdown_event.is_set():
        try:
            count = task_queue.reclaim_stale_tasks(stale_seconds=stale_timeout)
            if count:
                logger.info("Reclaimed %d stale task(s)", count)
        except Exception as exc:
            logger.warning("Stale reclaimer error: %s", exc)
        _shutdown_event.wait(60)  # Check every 60 seconds


# ── FastAPI control app ──────────────────────────────────────────────────────

control_app = FastAPI(
    title="QueryStudio Executor Worker",
    docs_url=None,
    redoc_url=None,
    lifespan=_lifespan,
)


@control_app.get("/health")
async def health():
    """Full status — executor state + DB connectivity."""
    db_ok = False
    try:
        if _db_manager:
            _db_manager.get_execution("__exec_health_probe__")
            db_ok = True
    except Exception:
        pass
    from core import responsibilities as _resp
    import core.scheduler as _cs
    return {
        "status": "ok" if db_ok else "degraded",
        "database": {"ok": db_ok},
        "worker_id": _worker_id,
        "paused": not _paused.is_set(),
        "responsibilities": _resp.describe(),
        "daemon_host": {**_daemon_host_state,
                        "tier_lock_held": bool(_cs._scheduler_worker_id),
                        "lock_id": _cs._lock_id},
        **_stats,
    }


@control_app.get("/control/daemon-snapshot/{name}")
async def daemon_snapshot(name: str, limit: Optional[int] = None):
    """The in-process state of a daemon THIS process runs (core/daemon_snapshots.py)."""
    from core.daemon_snapshots import SNAPSHOTS, local_snapshot
    if name not in SNAPSHOTS:
        raise HTTPException(404, f"no daemon snapshot named {name!r}")
    data = await asyncio.to_thread(local_snapshot, name, limit)
    return {"name": name, "data": data}


@control_app.get("/control/background-job-ticks")
async def background_job_ticks():
    """Every declared background job's last tick from THIS process's ledger."""
    from core.background_job_contract import local_ticks
    return {"jobs": await asyncio.to_thread(local_ticks, _db_manager)}


@control_app.get("/control/background-job/{name}/status")
async def background_job_status(name: str, limit: int = 10):
    """One job's status from the process that RUNS it."""
    from core.background_job_contract import CONTRACTS, local_status
    if name not in CONTRACTS:
        raise HTTPException(404, f"no background job named {name!r}")
    return await asyncio.to_thread(local_status, name, _db_manager, limit=limit)


@control_app.post("/control/background-job/{name}/run-now")
async def background_job_run_now(name: str):
    """ONE tick of a job in the process that owns it; 409 when it declares it
    cannot run on demand or is already running."""
    from core.background_job_contract import CONTRACTS, TickRefused, local_run_now, refuse_unless_owned
    if name not in CONTRACTS:
        raise HTTPException(404, f"no background job named {name!r}")
    try:
        refuse_unless_owned(name)
        rec = await asyncio.to_thread(local_run_now, name, _db_manager)
    except TickRefused as exc:
        raise HTTPException(exc.status_code, exc.reason)
    rec["name"] = name
    return rec


@control_app.get("/health/live")
async def liveness():
    """K8s liveness — always 200 if process is up."""
    return {"status": "alive"}


@control_app.get("/health/ready")
async def readiness():
    """K8s readiness — checks DB connectivity."""
    db_ok = False
    try:
        if _db_manager:
            _db_manager.get_execution("__exec_ready_probe__")
            db_ok = True
    except Exception:
        pass
    if not db_ok:
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=503, content={"status": "not_ready", "reason": "database unavailable"})
    # 2026-10-17 -- a DRAIN intent applied on this pod: not ready, said.
    from core.component_health.intents import draining_info as _draining
    _d = _draining()
    if _d.get("active"):
        from fastapi.responses import JSONResponse
        return JSONResponse(status_code=503, content={"status": "draining", "since": _d.get("since"),
                                                      "by": _d.get("by"), "intent_id": _d.get("intent_id")})
    return {"status": "ready"}


@control_app.get("/control/status")
async def executor_status():
    """Full executor state: active tasks, queue depth, stats."""
    pending = []
    active = []
    try:
        from core.queue_backend import get_task_queue
        tq = get_task_queue()
        pending = tq.list_tasks(status="pending", limit=20)
        active = tq.list_tasks(status="processing", limit=20)
    except Exception:
        pass
    return {
        "worker_id": _worker_id,
        "paused": not _paused.is_set(),
        "pending_count": len(pending),
        "active_count": len(active),
        "pending_tasks": pending,
        "active_tasks": active,
        **_stats,
    }


@control_app.post("/control/pause")
async def pause():
    """Pause claiming new tasks. Running tasks finish normally."""
    _paused.clear()
    logger.info("Executor paused")
    return {"message": "Executor paused"}


@control_app.post("/control/resume")
async def resume():
    """Resume claiming tasks."""
    _paused.set()
    logger.info("Executor resumed")
    return {"message": "Executor resumed"}


@control_app.post("/control/shutdown")
async def shutdown():
    """Graceful shutdown — stop executor and exit."""
    logger.info("Shutdown requested via control API")
    def _delayed_exit():
        time.sleep(1)
        os._exit(0)
    threading.Thread(target=_delayed_exit, daemon=True).start()
    return {"message": "Shutting down"}


# ── Entry point ──────────────────────────────────────────────────────────────

def main():
    import uvicorn
    from core.config import executor as _exec_cfg

    host = _exec_cfg.worker_host
    port = _exec_cfg.worker_port

    print(f"[job_worker] Starting on {host}:{port} (backend/executor_worker.py)")

    # Windows Ctrl+C handling
    if sys.platform == "win32":
        def _sigint_handler(signum, frame):
            print("\n[executor_worker] Ctrl+C — stopping...")
            _shutdown_event.set()
            os._exit(0)
        signal.signal(signal.SIGINT, _sigint_handler)
        try:
            signal.signal(signal.SIGBREAK, _sigint_handler)
        except (AttributeError, OSError):
            pass

    # TLS — serve HTTPS when certificates are mounted (matches API pod behavior)
    ssl_kwargs: dict = {}
    from core.config import server as _server_cfg
    if _server_cfg.ssl_certfile and _server_cfg.ssl_keyfile:
        cert = Path(_server_cfg.ssl_certfile)
        key = Path(_server_cfg.ssl_keyfile)
        if cert.exists() and key.exists():
            ssl_kwargs["ssl_certfile"] = str(cert)
            ssl_kwargs["ssl_keyfile"] = str(key)
            print(f"[executor_worker] TLS enabled: {cert}")

    uvicorn.run(
        control_app,
        host=host,
        port=port,
        log_level="info",
        access_log=False,
        **ssl_kwargs,
    )


if __name__ == "__main__":
    main()
