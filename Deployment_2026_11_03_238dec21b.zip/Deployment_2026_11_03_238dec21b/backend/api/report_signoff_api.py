"""Commentary + sign-off on a report INSTANCE -- the routes (2026-09-28).

Every rule (who sees what, who may act, what a lock means) is in
``core/reports/signoff.py``; the routes resolve the report, the instance
and the caller, and map a :class:`SignoffRefused` to its status.  The
report gate is the ONE view chokepoint (``can_view_business_report``, a
denied or missing report is 404 -- no existence oracle), the instance
gate is ``resolve_instance`` (404 not this report's, 403 another scope).

Routes (all under the finance report):

    GET  /api/business-reports/{id}/instances/header
         ?instance_id= | ?execution_id= | ?params=      the viewer's header
    GET  /api/business-reports/{id}/instances/{iid}/signoffs
    POST /api/business-reports/{id}/instances/{iid}/signoffs
    POST /api/business-reports/{id}/instances/{iid}/signoffs/{sid}/revoke
    GET  /api/business-reports/{id}/signed-runs
    GET  /api/business-reports/{id}/instances/{iid}/comments
    POST /api/business-reports/{id}/instances/{iid}/comments
    PUT  /api/business-reports/{id}/instances/{iid}/comments/{cid}
    DELETE /api/business-reports/{id}/instances/{iid}/comments/{cid}
    GET  /api/business-reports/{id}/instances/{iid}/diff?against=
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Dict, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_capability
from core.reports import signoff as _so
from core.reports.signoff import SignoffRefused

logger = logging.getLogger(__name__)
router = APIRouter(tags=["report-signoff"])


async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


async def _require_report_view(report_id: int, user: dict) -> dict:
    """404 for a missing report and for a denied one (no oracle)."""
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(404, f"Report {report_id} not found")
    from core.reports.authorization import can_view_business_report
    if not await _adb(can_view_business_report, report, user, db):
        raise HTTPException(404, f"Report {report_id} not found")
    return report


def _refused(exc: SignoffRefused) -> HTTPException:
    return HTTPException(exc.status, str(exc))


async def _instance(db, report: dict, user: dict, instance_id: int) -> dict:
    try:
        return await _adb(_so.resolve_instance, db, report, user, instance_id)
    except SignoffRefused as exc:
        raise _refused(exc)


# ── models ───────────────────────────────────────────────────────────────────

class SignBody(BaseModel):
    role: Literal["preparer", "reviewer", "approver"] = "approver"
    note: Optional[str] = Field(default=None, max_length=2000)
    business_date: Optional[str] = Field(default=None, max_length=10)


class RevokeBody(BaseModel):
    reason: str = Field(..., min_length=3, max_length=2000)


class InstanceCommentCreate(BaseModel):
    text: str = Field(..., min_length=1, max_length=4000)
    parent_id: Optional[int] = None
    anchor: Optional[Dict[str, Any]] = None
    business_date: Optional[str] = Field(default=None, max_length=10)


class InstanceCommentUpdate(BaseModel):
    text: Optional[str] = Field(default=None, min_length=1, max_length=4000)
    is_resolved: Optional[bool] = None


# ── header ───────────────────────────────────────────────────────────────────

@router.get("/api/business-reports/{report_id}/instances/header")
async def instance_header(
    report_id: int,
    instance_id: Optional[int] = Query(default=None),
    execution_id: Optional[str] = Query(default=None),
    params: Optional[str] = Query(default=None),
    user: dict = Depends(require_capability("reports.view")),
):
    """The viewer's instance header, resolved once on the server: the
    instance being looked at (served instance id, else the live run's
    execution id, else the caller's newest instance for ``params``), its
    sign-off state, the signed version it supersedes, the visible thread
    and what THIS caller may do.  ``signoff.status == "no_instance"`` when
    the run was not recorded -- nothing to sign, said so."""
    report = await _require_report_view(report_id, user)
    db = _require_db()
    pv = None
    if isinstance(params, str) and params:
        try:
            pv = json.loads(params)
        except ValueError:
            raise HTTPException(400, "params must be a JSON object")
        if not isinstance(pv, dict):
            raise HTTPException(400, "params must be a JSON object")
    _iid = instance_id if isinstance(instance_id, int) else None
    _eid = execution_id if isinstance(execution_id, str) else None
    try:
        inst = await _adb(_so.resolve_current_instance, db, report, user,
                          instance_id=_iid, execution_id=_eid, params=pv)
    except SignoffRefused as exc:
        raise _refused(exc)
    return await _adb(_so.header_state, db, report, user, inst)


# ── sign-offs ────────────────────────────────────────────────────────────────

@router.get("/api/business-reports/{report_id}/instances/{instance_id}/signoffs")
async def list_instance_signoffs(
    report_id: int, instance_id: int,
    include_revoked: bool = Query(default=True),
    user: dict = Depends(require_capability("reports.view")),
):
    report = await _require_report_view(report_id, user)
    db = _require_db()
    inst = await _instance(db, report, user, instance_id)
    rows = await _adb(db.list_report_instance_signoffs,
                      instance_id=int(inst["id"]), active_only=not include_revoked)
    out = []
    for r in rows:
        pub = _so._public_signoff(r)
        pub["can_revoke"] = (r.get("status") == "active"
                             and _so.can_revoke(r, report, user, db))
        out.append(pub)
    return {"instance_id": inst["id"], "signed": any(r.get("status") == "active" for r in rows),
            "signoffs": out}


@router.post("/api/business-reports/{report_id}/instances/{instance_id}/signoffs",
             status_code=201)
async def sign_instance(
    report_id: int, instance_id: int, body: SignBody, request: Request,
    user: dict = Depends(require_capability("reports.view")),
):
    report = await _require_report_view(report_id, user)
    db = _require_db()
    inst = await _instance(db, report, user, instance_id)
    try:
        row = await _adb(_so.sign_instance, db, report, inst, user,
                         role=body.role, note=body.note,
                         business_date=body.business_date, request=request)
    except SignoffRefused as exc:
        raise _refused(exc)
    pub = _so._public_signoff(row)
    pub["can_revoke"] = True
    return pub


@router.post("/api/business-reports/{report_id}/instances/{instance_id}/signoffs/{signoff_id}/revoke")
async def revoke_instance_signoff(
    report_id: int, instance_id: int, signoff_id: int, body: RevokeBody,
    request: Request, user: dict = Depends(require_capability("reports.view")),
):
    report = await _require_report_view(report_id, user)
    db = _require_db()
    inst = await _instance(db, report, user, instance_id)
    so = await _adb(db.get_report_instance_signoff, signoff_id)
    if not so or int(so.get("instance_id") or 0) != int(inst["id"]):
        raise HTTPException(404, f"Sign-off {signoff_id} not found on instance {instance_id}")
    try:
        row = await _adb(_so.revoke_signoff, db, report, so, user,
                         reason=body.reason, request=request)
    except SignoffRefused as exc:
        raise _refused(exc)
    pub = _so._public_signoff(row)
    pub["can_revoke"] = False
    return pub


@router.get("/api/business-reports/{report_id}/signed-runs")
async def signed_runs(
    report_id: int,
    include_revoked: bool = Query(default=False),
    limit: int = Query(default=200, ge=1, le=1000),
    user: dict = Depends(require_capability("reports.view")),
):
    """The signed runs of a report the caller may see (their scope; every
    scope, labelled, for admin-tier and support)."""
    report = await _require_report_view(report_id, user)
    db = _require_db()
    rows = await _adb(_so.list_signed_runs, db, report, user,
                      include_revoked=include_revoked, limit=limit)
    return {"report_id": report_id, "signed_runs": rows, "total": len(rows),
            "sees_all_scopes": _so.sees_all_scopes(user)}


# ── commentary ───────────────────────────────────────────────────────────────

@router.get("/api/business-reports/{report_id}/instances/{instance_id}/comments")
async def list_instance_comments(
    report_id: int, instance_id: int,
    user: dict = Depends(require_capability("reports.view")),
):
    report = await _require_report_view(report_id, user)
    db = _require_db()
    inst = await _instance(db, report, user, instance_id)
    rows = await _adb(_so.visible_comments, db, report, inst, user)
    return {"instance_id": inst["id"], "comments": rows, "total": len(rows),
            "can_comment": _so.can_comment(report, user, db)}


@router.post("/api/business-reports/{report_id}/instances/{instance_id}/comments",
             status_code=201)
async def create_instance_comment(
    report_id: int, instance_id: int, body: InstanceCommentCreate,
    request: Request, user: dict = Depends(require_capability("reports.view")),
):
    report = await _require_report_view(report_id, user)
    db = _require_db()
    inst = await _instance(db, report, user, instance_id)
    try:
        row = await _adb(_so.add_comment, db, report, inst, user,
                         text=body.text, parent_id=body.parent_id,
                         anchor=body.anchor, business_date=body.business_date,
                         request=request)
    except SignoffRefused as exc:
        raise _refused(exc)
    row["scope_label"] = _so.scope_label(row.get("rls_signature"))
    return row


@router.put("/api/business-reports/{report_id}/instances/{instance_id}/comments/{comment_id}")
async def update_instance_comment(
    report_id: int, instance_id: int, comment_id: int,
    body: InstanceCommentUpdate, user: dict = Depends(require_capability("reports.view")),
):
    report = await _require_report_view(report_id, user)
    db = _require_db()
    inst = await _instance(db, report, user, instance_id)
    c = await _adb(db.get_report_instance_comment, comment_id)
    if not c or int(c.get("instance_id") or 0) != int(inst["id"]):
        raise HTTPException(404, f"Comment {comment_id} not found on instance {instance_id}")
    updates = body.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(400, "No updates provided")
    from core.roles import is_admin_like
    # text: own only; resolve/unresolve: anyone who may comment on it
    if "text" in updates and not (is_admin_like(user)
                                  or c.get("username") == user.get("username")):
        raise HTTPException(403, "You may only edit your own comments")
    if not _so.can_comment(report, user, db):
        raise HTTPException(403, "You may not comment on this report")
    try:
        row = await _adb(db.update_report_instance_comment, comment_id, **updates)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    row["scope_label"] = _so.scope_label(row.get("rls_signature"))
    return row


@router.delete("/api/business-reports/{report_id}/instances/{instance_id}/comments/{comment_id}")
async def delete_instance_comment(
    report_id: int, instance_id: int, comment_id: int, request: Request,
    user: dict = Depends(require_capability("reports.view")),
):
    report = await _require_report_view(report_id, user)
    db = _require_db()
    inst = await _instance(db, report, user, instance_id)
    c = await _adb(db.get_report_instance_comment, comment_id)
    if not c or int(c.get("instance_id") or 0) != int(inst["id"]):
        raise HTTPException(404, f"Comment {comment_id} not found on instance {instance_id}")
    try:
        await _adb(_so.delete_comment, db, report, inst, c, user, request)
    except SignoffRefused as exc:
        raise _refused(exc)
    return {"detail": "Deleted", "comment_id": comment_id}


# ── what changed since I signed ──────────────────────────────────────────────

@router.get("/api/business-reports/{report_id}/instances/{instance_id}/diff")
async def diff_instance(
    report_id: int, instance_id: int,
    against: Optional[int] = Query(default=None,
                                   description="the base instance; default = "
                                               "the signed run under the same key"),
    user: dict = Depends(require_capability("reports.view")),
):
    """Keyed diff of ``instance_id`` (current) against ``against`` (base,
    default: the signed version under the same serve key).  A 200 whose
    ``refused`` is set IS the answer (the reason is the finding); the
    instances themselves are gated like every other instance route."""
    report = await _require_report_view(report_id, user)
    db = _require_db()
    current = await _instance(db, report, user, instance_id)
    if against is None or not isinstance(against, int):
        signed = await _adb(_so.signed_version_for, db, current)
        if not signed:
            return {"refused": "no signed run exists under this run's parameters "
                               "and row-security scope to compare against",
                    "current": {"instance_id": current["id"]}, "base": None}
        against = int(signed["instance_id"])
    base = await _instance(db, report, user, int(against))
    from core.reports.instance_diff import DiffRefused, diff_instances
    try:
        out = await _adb(diff_instances, db, report, base, current)
    except DiffRefused as exc:
        return {"refused": str(exc),
                "current": {"instance_id": current["id"]},
                "base": {"instance_id": base["id"]}}
    out["refused"] = None
    return out
