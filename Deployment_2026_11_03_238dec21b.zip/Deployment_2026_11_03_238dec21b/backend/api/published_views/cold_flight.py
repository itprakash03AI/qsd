"""ONE cold materialisation per dataset across every process and pod (2026-10-04).

THE STAMPEDE
------------
Measured live (Docker, real Snowflake, published-api 2 workers): 100
unpaced consumers hitting four brand-new filter values on a 10M-row
report-backed view at once -> 23 req/s, p50 2 s, p99 31 s and nine 503s
from the memory guard, against 139 req/s once warm.  Every first call for
a value materialises up to ``dataset_row_cap`` (1,000,001 rows, ~4-5 s on
Snowflake).  The in-process merge (``published_views_api._pv_inflight``)
collapses identical MISSes inside ONE process only, so with 2 workers x N
pods the same materialisation ran once per process -- each costing the
engine time and a worker's memory.  (Inside one process it also woke its
joiners BEFORE the dataset was published to the cache, so a joiner found
no file and ran its own: fixed beside this module.)

THE SHAPE
---------
``pv_materialise_flights`` -- one row per dataset (the cache slot), keyed
by the sha256 of the slot's PATH (every process of every pod computes it
identically on the shared cache volume, as ``bulk_jobs`` does):

* The first INSERT is the LEADER: it materialises, publishes the dataset
  through the one cache chokepoint, then marks the flight ``done``.  While
  it runs it refreshes ``heartbeat_at`` every third of
  ``cold_flight_stale_seconds``.
* Everyone else is a FOLLOWER of that flight: it polls the cache file (a
  ``stat``) and the row (one SELECT, off the event loop) and is served the
  published dataset the moment it is there -- a cache read, no engine, no
  materialisation memory, so a follower is never refused by the memory
  guard.
* A leader whose heartbeat stopped (its process died, an OOM kill, a pod
  restart) is STALE after ``cold_flight_stale_seconds``: the first
  follower to notice takes the flight over with a compare-and-swap on
  ``flight_id`` and materialises; the others follow the new flight.
* A leader that FAILED records the HTTP answer it gave (status, detail,
  Retry-After) and its followers give the same answer -- one failed
  engine run, not one per waiting consumer.  A request arriving AFTER that
  starts a fresh flight: failures are shared, never cached.
* A leader that ended without an answer (its client disconnected, the
  memory guard refused it before it started) is ``abandoned``: a follower
  takes the flight over at once.
* A follower waits at most ``dedup_timeout_seconds`` (the same bound the
  in-process merge uses -- one answer to "how long does a duplicate
  wait").  If the leader is still alive and working then, the follower is
  answered **503 + Retry-After + X-QS-Refused: materialisation_in_progress**:
  running a duplicate of a live materialisation is the stampede itself.

FAIL-SOFT
---------
A store error (no metadata database, a lost connection) is logged and the
request runs as it did before this module existed -- its own
materialisation, deduplicated in process only.  The flight is an
optimisation of WHO runs the query, never a gate on WHETHER it runs.
"""
from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import logging
import os
import socket
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)

TABLE = "pv_materialise_flights"

RUNNING, DONE, FAILED, ABANDONED = "running", "done", "failed", "abandoned"

#: Finished rows (and the stale running rows of dead processes) are deleted
#: after this long; a finished row matters only to followers still polling.
RETENTION_SECONDS = 3600.0
_PRUNE_EVERY_SECONDS = 60.0

#: Follower poll cadence: starts fast (a 4-5 s materialisation is the
#: common case), backs off to bound the metadata reads per waiting request.
POLL_FIRST_SECONDS = 0.05
POLL_MAX_SECONDS = 0.5

#: Headers a leader's failure carries to its followers -- nothing else
#: (a response header is per request; these two describe the failure).
_REPLAYED_HEADERS = ("Retry-After", "X-QS-Refused")

_last_prune = 0.0


# ══════════════════════════════════════════════════════════════════════════
# Config
# ══════════════════════════════════════════════════════════════════════════

def _cfg(key: str, default):
    try:
        from core.config import get as _get
        v = _get("published_views", key, default)
        return default if v is None else v
    except Exception:
        return default


def enabled() -> bool:
    """``published_views.cold_flight_enabled`` (default True)."""
    return bool(_cfg("cold_flight_enabled", True))


def stale_seconds() -> float:
    """A RUNNING flight whose heartbeat is older than this belongs to a
    process that ended (``published_views.cold_flight_stale_seconds``,
    default 15).  The leader heartbeats every third of it."""
    try:
        return max(1.0, float(_cfg("cold_flight_stale_seconds", 15)))
    except (TypeError, ValueError):
        return 15.0


def retry_after_seconds() -> int:
    """The Retry-After a follower is given when its wait ran out while the
    leader was still working: a third of the staleness bound -- the
    leader's own heartbeat cadence."""
    return max(1, int(round(stale_seconds() / 3.0)))


# ══════════════════════════════════════════════════════════════════════════
# Identity + store
# ══════════════════════════════════════════════════════════════════════════

def owner_id() -> str:
    """This process, as the row names it."""
    return f"{socket.gethostname()}:{os.getpid()}"


def flight_key(cached_path: Any) -> str:
    """The cross-process identity of one dataset: its cache slot's path."""
    return hashlib.sha256(str(cached_path).encode("utf-8")).hexdigest()


def _engine():
    from core.database import get_db_manager
    mgr = get_db_manager()
    engine = getattr(mgr, "engine", None) if mgr is not None else None
    if engine is None or not hasattr(engine, "begin"):
        raise RuntimeError("no metadata database is configured")
    from core.db.engine_memo import ensure_table
    from core.db.models import PvMaterialiseFlight
    ensure_table(engine, PvMaterialiseFlight.__table__)
    return engine


@dataclass
class FlightRow:
    flight_id: str
    owner: str
    status: str
    heartbeat_at: float
    outcome: Optional[Dict[str, Any]] = None

    def is_stale(self, now: float) -> bool:
        return self.status == RUNNING and now - self.heartbeat_at > stale_seconds()


def read(key: str) -> Optional[FlightRow]:
    """The flight row for ``key`` or None.  Raises on a store error."""
    from sqlalchemy import text as _t
    with _engine().begin() as conn:
        row = conn.execute(_t(
            f"SELECT flight_id, owner, status, heartbeat_at, outcome FROM {TABLE} "
            "WHERE flight_key = :k"), {"k": key}).first()
    if row is None:
        return None
    outcome = None
    if row[4]:
        try:
            outcome = json.loads(row[4])
        except (TypeError, ValueError):
            outcome = None
    return FlightRow(flight_id=row[0], owner=row[1], status=row[2],
                     heartbeat_at=float(row[3] or 0), outcome=outcome)


def try_lead(key: str, *, slug: str = "", replace: Optional[str] = None,
             now: Optional[float] = None) -> Optional[str]:
    """Make this process the leader of ``key``'s flight.

    ``replace`` -- the flight id this caller SAW and may take over (a
    finished, abandoned or stale one): a compare-and-swap, so two
    processes that saw the same dead flight cannot both win.  Returns the
    new flight id when this call leads, None when another flight holds the
    key.  Raises on a store error."""
    from sqlalchemy import text as _t
    from sqlalchemy.exc import IntegrityError
    t = time.time() if now is None else now
    fid = uuid.uuid4().hex
    params = {"k": key, "f": fid, "o": owner_id(), "t": t, "s": RUNNING,
              "slug": (slug or "")[:255], "prev": replace}
    eng = _engine()
    if replace is not None:
        with eng.begin() as conn:
            res = conn.execute(_t(
                f"UPDATE {TABLE} SET flight_id = :f, owner = :o, status = :s, "
                "slug = :slug, started_at = :t, heartbeat_at = :t, "
                "finished_at = NULL, outcome = NULL "
                "WHERE flight_key = :k AND flight_id = :prev"), params)
        return fid if res.rowcount == 1 else None
    insert = (f"INSERT INTO {TABLE} (flight_key, flight_id, owner, status, slug, "
              "started_at, heartbeat_at) VALUES (:k, :f, :o, :s, :slug, :t, :t)")
    dialect = getattr(getattr(eng, "dialect", None), "name", "")
    if dialect in ("postgresql", "sqlite"):
        # A follower's lost race is the COMMON case in a stampede: no
        # duplicate-key error per follower in the database's log.
        with eng.begin() as conn:
            res = conn.execute(_t(insert + " ON CONFLICT (flight_key) DO NOTHING"),
                               params)
        return fid if res.rowcount == 1 else None
    try:
        with eng.begin() as conn:
            conn.execute(_t(insert), params)
        return fid
    except IntegrityError:
        return None


def heartbeat(key: str, fid: str, now: Optional[float] = None) -> bool:
    """Refresh the leader's heartbeat.  False when the flight is no longer
    this one's (it was taken over as stale) or the store failed."""
    from sqlalchemy import text as _t
    t = time.time() if now is None else now
    try:
        with _engine().begin() as conn:
            res = conn.execute(_t(
                f"UPDATE {TABLE} SET heartbeat_at = :t WHERE flight_key = :k "
                "AND flight_id = :f AND status = :s"),
                {"t": t, "k": key, "f": fid, "s": RUNNING})
        return res.rowcount == 1
    except Exception as exc:
        logger.debug("[pv-flight] heartbeat failed for %s: %s", key[:12], exc)
        return False


def finish(key: str, fid: str, status: str,
           outcome: Optional[Dict[str, Any]] = None,
           now: Optional[float] = None) -> bool:
    """End the flight ``fid`` (only if it is still this one)."""
    from sqlalchemy import text as _t
    t = time.time() if now is None else now
    try:
        with _engine().begin() as conn:
            res = conn.execute(_t(
                f"UPDATE {TABLE} SET status = :st, finished_at = :t, "
                "heartbeat_at = :t, outcome = :oc "
                "WHERE flight_key = :k AND flight_id = :f"),
                {"st": status, "t": t, "k": key, "f": fid,
                 "oc": json.dumps(outcome) if outcome is not None else None})
        return res.rowcount == 1
    except Exception as exc:
        logger.warning("[pv-flight] could not record flight %s as %s (its "
                       "followers fall back after the staleness bound): %s",
                       fid[:8], status, exc)
        return False


def prune(now: Optional[float] = None, *, force: bool = False) -> int:
    """Delete finished rows past ``RETENTION_SECONDS`` (and running rows
    whose heartbeat stopped that long ago).  At most once a minute per
    process unless forced."""
    global _last_prune
    from sqlalchemy import text as _t
    t = time.time() if now is None else now
    if not force and t - _last_prune < _PRUNE_EVERY_SECONDS:
        return 0
    _last_prune = t
    try:
        with _engine().begin() as conn:
            n = conn.execute(_t(
                f"DELETE FROM {TABLE} WHERE heartbeat_at < :cut"),
                {"cut": t - RETENTION_SECONDS}).rowcount or 0
        return int(n)
    except Exception as exc:
        logger.debug("[pv-flight] prune skipped: %s", exc)
        return 0


# ══════════════════════════════════════════════════════════════════════════
# The flight a request takes part in
# ══════════════════════════════════════════════════════════════════════════

def failure_outcome(exc: BaseException) -> Optional[Dict[str, Any]]:
    """The replayable answer of a leader that raised ``exc`` -- an
    HTTPException's status, detail and failure headers; None for anything
    that is not an HTTP answer (a cancellation: the flight is abandoned)."""
    from fastapi import HTTPException
    if not isinstance(exc, HTTPException):
        return None
    headers = {k: v for k, v in (exc.headers or {}).items()
               if k in _REPLAYED_HEADERS}
    try:
        json.dumps(exc.detail)
        detail = exc.detail
    except (TypeError, ValueError):
        detail = str(exc.detail)
    return {"status_code": int(exc.status_code), "detail": detail,
            "headers": headers}


def replay(outcome: Dict[str, Any]):
    """The HTTPException a follower raises for its leader's failure."""
    from fastapi import HTTPException
    return HTTPException(int(outcome.get("status_code") or 500),
                         outcome.get("detail"),
                         headers=dict(outcome.get("headers") or {}) or None)


@dataclass
class Flight:
    """This request's part in a dataset's flight.

    ``role``:
      * ``leader``   -- materialise, then ``succeeded()`` / ``failed(exc)``;
        ``close()`` in a ``finally`` (abandons a flight left unfinished);
      * ``ready``    -- the leader published the dataset: serve the cache;
      * ``replay``   -- the leader failed: raise ``replay(outcome)``;
      * ``busy``     -- the wait ran out while the leader is alive: 503;
      * ``solo``     -- no shared store (or disabled): run as before.
    """
    key: str
    role: str
    flight_id: Optional[str] = None
    outcome: Optional[Dict[str, Any]] = None
    waited_s: float = 0.0
    _hb_task: Optional[asyncio.Task] = field(default=None, repr=False)
    _finished: bool = field(default=False, repr=False)

    @property
    def leads(self) -> bool:
        return self.role in ("leader", "solo")

    def _start_heartbeat(self) -> None:
        if self.role != "leader" or self.flight_id is None:
            return
        interval = max(0.2, stale_seconds() / 3.0)
        key, fid = self.key, self.flight_id

        async def _beat():
            while True:
                await asyncio.sleep(interval)
                if not await asyncio.to_thread(heartbeat, key, fid):
                    logger.warning(
                        "[pv-flight] flight %s for %s is no longer this "
                        "process's (taken over as stale, or the store is "
                        "unreachable) -- it keeps running and publishes "
                        "through the atomic cache chokepoint", fid[:8], key[:12])
                    return

        self._hb_task = asyncio.ensure_future(_beat())

    def _stop_heartbeat(self) -> None:
        if self._hb_task is not None:
            self._hb_task.cancel()
            self._hb_task = None

    async def succeeded(self) -> None:
        """The dataset is PUBLISHED in the cache: release the followers."""
        self._stop_heartbeat()
        if self.role == "leader" and not self._finished:
            self._finished = True
            await asyncio.to_thread(finish, self.key, self.flight_id, DONE)

    async def failed(self, exc: BaseException) -> None:
        """The leader's request ends with ``exc``: share the answer."""
        self._stop_heartbeat()
        if self.role == "leader" and not self._finished:
            self._finished = True
            outcome = failure_outcome(exc)
            await asyncio.to_thread(
                finish, self.key, self.flight_id,
                FAILED if outcome is not None else ABANDONED, outcome)

    async def close(self) -> None:
        """Always called: a flight left unfinished is ABANDONED, so a
        follower takes it over at once instead of after the stale bound."""
        self._stop_heartbeat()
        if self.role == "leader" and not self._finished:
            self._finished = True
            try:
                await asyncio.shield(asyncio.to_thread(
                    finish, self.key, self.flight_id, ABANDONED))
            except BaseException as exc:            # cancelled mid-close
                logger.debug("[pv-flight] abandon of %s interrupted: %s",
                             (self.flight_id or "")[:8], exc)


async def _claim(key: str, **kw) -> Optional[str]:
    """``try_lead`` off the loop, safe to cancel (2026-11-01, found by the CI
    replica under load).  A cancel while the claim was on its thread raised at
    once, but the thread still COMMITTED the claim: a ``running`` flight no
    request owned, so every identical request waited out the stale bound.
    Cancelled here, the claim is waited for and, when it was won, abandoned --
    then the cancel goes on."""
    fut = asyncio.ensure_future(asyncio.to_thread(try_lead, key, **kw))
    try:
        return await asyncio.shield(fut)
    except asyncio.CancelledError:
        try:
            fid = await fut
            if fid:
                await asyncio.to_thread(finish, key, fid, ABANDONED)
        except BaseException as exc:                # cancelled again mid-abandon
            logger.debug("[pv-flight] abandon of a cancelled claim for %s "
                         "interrupted: %s", key[:12], exc)
        raise


async def join(key: str, *, is_ready: Callable[[], bool], wait_seconds: float,
               slug: str = "") -> Flight:
    """Lead ``key``'s flight or follow the one in the air.

    ``is_ready`` -- does the cache now hold a dataset that serves THIS
    request (fresh, covering its page)?  Checked before every store read,
    so a follower is served the moment the leader's file lands.  It may be
    a coroutine function (2026-10-10: the route's probe reads the file OFF
    the loop, api/published_views/page_io.py) or a plain callable.

    The leader's cost is two statements (the claiming INSERT and the
    finishing UPDATE, plus a heartbeat per third of the stale bound); a
    follower reads the row once per poll.
    """
    if not enabled():
        return Flight(key=key, role="solo")
    start = time.monotonic()
    deadline = start + max(0.0, float(wait_seconds))
    waiting_on: Optional[str] = None
    delay = POLL_FIRST_SECONDS

    def _done(role: str, **kw) -> Flight:
        return Flight(key=key, role=role, waited_s=time.monotonic() - start, **kw)

    async def _ready() -> bool:
        verdict = is_ready()
        if inspect.isawaitable(verdict):
            verdict = await verdict
        return bool(verdict)

    try:
        if time.time() - _last_prune >= _PRUNE_EVERY_SECONDS:
            await asyncio.to_thread(prune)
        fid = await _claim(key, slug=slug)
        while fid is None:
            row = await asyncio.to_thread(read, key)
            now = time.time()
            if row is None:                          # finished + pruned meanwhile
                fid = await _claim(key, slug=slug)
                continue
            if row.status == RUNNING and not row.is_stale(now):
                # Following.  Adopt whichever flight is in the air now: the
                # one we first saw may have ended and a fresh one begun.
                waiting_on = row.flight_id
                if await _ready():
                    return _done("ready", flight_id=waiting_on)
                if time.monotonic() >= deadline:
                    return _done("busy", flight_id=waiting_on)
                await asyncio.sleep(min(delay, max(0.0, deadline - time.monotonic())))
                delay = min(POLL_MAX_SECONDS, delay * 1.5)
                continue
            if row.status == FAILED and row.flight_id == waiting_on:
                return _done("replay", flight_id=row.flight_id, outcome=row.outcome)
            # done / abandoned / stale / a failure from BEFORE this request:
            # the cache may serve us now; otherwise a fresh flight.
            if await _ready():
                return _done("ready", flight_id=row.flight_id)
            if row.is_stale(now):
                logger.warning(
                    "[pv-flight] flight %s for '%s' (owner %s) stopped "
                    "heartbeating %.0fs ago -- taking it over",
                    row.flight_id[:8], slug, row.owner, now - row.heartbeat_at)
            fid = await _claim(key, slug=slug, replace=row.flight_id)
        flight = _done("leader", flight_id=fid)
        flight._start_heartbeat()
        return flight
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        logger.warning("[pv-flight] shared flight store unavailable for '%s' "
                       "(this request materialises on its own; identical "
                       "requests in OTHER processes may too): %s", slug, exc)
        return _done("solo")
