"""
Phase 133-B — Management endpoints for Published Views API.

Publishing open to all authenticated users; update/delete/republish require
owner or admin.  Export/import, direct API key CRUD, webhooks remain admin-only.
"""
from __future__ import annotations

import hashlib
import logging
import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)

from fastapi.responses import JSONResponse

from api.deps import get_current_user, require_admin
from core.roles import is_admin_like
from core.audit import audit_event
from core.error_sanitizer import sanitize_error
from api.published_views.models import (
    ParamDefinition, PublishViewRequest, UpdateViewRequest,
    CreateApiKeyRequest, UpdateQueryConfigRequest, DetectPartitionsRequest,
    ImportViewRequest, WebhookCreateRequest, WebhookUpdateRequest,
    ApiKeyRequestCreate, ApiKeyRequestApprove, ApiKeyRequestReview,
)
from core.db_async import adb
from core.published_view_params import inherit_report_params
from api.published_views.helpers import _clear_view_cache

logger = logging.getLogger(__name__)

mgmt_router = APIRouter()

# ── Module-level singletons — set by set_management_deps() ──────────────────
_db_manager = None
_pv_cfg = None
_cache_dir: Optional[Path] = None
_federation_engine = None
_ws_manager = None


# Single source of truth for column-name-based parameter type inference.
# Used by detect_partitions() across partition columns, WHERE-clause filter
# columns, and {{param}} placeholders extracted from raw_sql.
# Returns (type, reason) so the frontend can show users *why* a type was picked.
_INTEGER_PARAM_NAMES = frozenset({"year", "month", "day", "quarter"})




def _refuse_unpublished_report(report: dict, what: str) -> None:
    """A consumer-facing artefact over a report that is NOT PUBLISHED is
    refused at creation (2026-10-02, found on Docker).  Consumers are served
    the PUBLISHED version only (core/reports/versions.py answers 410 "not
    published"), so creating the API / embed token / share link was a 200
    with a working-looking key while every call returned 410 -- the
    publisher saw success and the external team saw a dead link."""
    if not (report or {}).get("is_published"):
        raise HTTPException(409, (
            f"Report {report.get('id')} is not published, so {what} would serve "
            f"nothing (every call would answer 410). Publish the report first, "
            f"then create {what}."))

def _infer_param_type(col_name: str) -> tuple[str, str]:
    col_lower = col_name.lower()
    if "date" in col_lower:
        return "date", "name contains 'date'"
    if col_lower.endswith("_dt"):
        return "date", "name ends with '_dt'"
    if col_lower in _INTEGER_PARAM_NAMES:
        return "integer", f"common integer partition name ({col_lower})"
    return "string", "default"


def _inherit_param_defs_from_report(param_definitions, report_params, *, report_id):
    """FB-25 (2026-09-19) -- a view published over a business report
    INHERITS the report's parameters as ``param_definitions``.

    Measured: report 22 declared a required ``p_region``; the publish
    returned 200 with ``param_definitions: []``; every call to the view was
    400 "Required parameter(s) missing: Region" -- a view NOBODY could call,
    minted with a 200.

    AQD-04 (2026-09-23): the inheritance itself now lives in
    ``core.published_view_params`` and ALSO runs on every read of the view,
    so a parameter added to the report after the publish reaches the view
    without a republish.  Here, at publish time, an unusable report
    parameter name is REFUSED with the name -- skipping it would mint the
    uncallable view again.
    """
    out, bad = inherit_report_params(param_definitions, report_params)
    if bad:
        raise HTTPException(
            400,
            f"Business report {report_id} declares parameter(s) whose names "
            f"cannot be published view parameters: {bad}.  A view parameter "
            f"name must match ^[a-zA-Z_][a-zA-Z0-9_]*$; rename the report "
            f"parameter, or declare the view parameter explicitly.")
    return out


def _sync_param_defs_from_dynamic_where(param_definitions, where_rows):
    """BF-491 (2026-05-27) — auto-add a ``param_definitions`` entry for
    every Dynamic WHERE row that doesn't already have a matching name.

    Without this, a publisher who adds a Dynamic WHERE row in either the
    publish OR the edit dialog would have to manually add a duplicate
    param_definitions entry — or skip it and lose the type/default/
    required metadata in the consumer's runtime-params panel + OpenAPI
    docs.  The runtime would still accept ``?col=value`` (allowed_filters
    is already auto-synced) but the param wouldn't be documented or
    typed.

    Idempotent: existing entries are preserved (publisher may have
    customised type/default/required/description).  Adds only — never
    removes — so removing a Dynamic row doesn't silently delete a
    param_definitions entry the publisher may have hand-tuned for SQL
    placeholder interpolation.

    Type inference reuses ``_infer_param_type`` so the result matches
    detect_partitions output for the same column.
    """
    existing_names = {
        (p.get("name") if isinstance(p, dict) else getattr(p, "name", "")).lower()
        for p in (param_definitions or [])
        if (p.get("name") if isinstance(p, dict) else getattr(p, "name", ""))
    }
    out = list(param_definitions or [])
    for w in where_rows or []:
        if hasattr(w, "model_dump"):
            w = w.model_dump()
        elif not isinstance(w, dict):
            continue
        if (w.get("mode") or "static") != "dynamic":
            continue
        col = (w.get("column") or "").strip()
        if not col:
            continue
        # BF-491 follow-up — ParamDefinition.name regex is
        # ``^[a-zA-Z_][a-zA-Z0-9_]*$`` (no dots).  Qualified column
        # names like ``trades.region`` would fail Pydantic validation
        # on the POST path.  Use the bare leaf as the param name
        # (matches consumer URL form: ``?region=value`` not
        # ``?trades.region=value`` — see PublishViewDialog line 1968).
        # Preserve the qualified form in the description so the
        # publisher still sees which table it came from.
        bare_col = col.rsplit(".", 1)[-1] if "." in col else col
        if bare_col.lower() in existing_names:
            continue
        # Defensive — if the bare leaf still doesn't match the regex
        # (rare: backtick-quoted identifiers with spaces, etc.), skip
        # the auto-add rather than emit an invalid ParamDefinition.
        import re as _re
        if not _re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", bare_col):
            continue
        ptype, _reason = _infer_param_type(bare_col)
        out.append({
            "name": bare_col,
            "type": ptype,
            "required": False,
            "default": "",
            "description": f"Auto-added from Dynamic WHERE row on '{col}'.",
        })
        existing_names.add(bare_col.lower())
    return out


def set_management_deps(db_manager, pv_cfg, cache_dir, federation_engine=None, ws_manager=None):
    """Called from set_published_views_dependencies() in the core module."""
    global _db_manager, _pv_cfg, _cache_dir, _federation_engine, _ws_manager
    _db_manager = db_manager
    _pv_cfg = pv_cfg
    _cache_dir = cache_dir
    _federation_engine = federation_engine
    _ws_manager = ws_manager


def _ensure_mgmt_ready() -> None:
    """Phase 133-D: Guard — return 503 if management dependencies not injected yet."""
    if _db_manager is None:
        raise HTTPException(503, "Service not ready — dependencies not initialized")


# ════════════════════════════════════════════════════════════════════════════��═
# MANAGEMENT ENDPOINTS (internal — admin/analyst auth)
# ══════════════════════════════════════════════════════════════════════════════

@mgmt_router.post("/api/published-views")
async def publish_view(
    body: PublishViewRequest,
    user: dict = Depends(require_capability("published_api.create")),
):
    """Publish a saved query or business report as an external API view."""
    _ensure_mgmt_ready()
    # Phase 102-F: enforce per-user published-view quota
    from api.deps import enforce_user_resource_quota
    enforce_user_resource_quota(user, "published_views")
    # Check slug uniqueness
    existing = _db_manager.get_published_view_by_slug(body.slug)
    if existing:
        raise HTTPException(409, f"Slug '{body.slug}' already in use")

    # ── Phase 91: Branch on source_type ──────────────────────────────────
    if body.source_type == "business_report":
        br = _db_manager.get_business_report(body.business_report_id)
        if not br:
            raise HTTPException(404, "Business report not found")
        _refuse_unpublished_report(br, "an API over it")
        # FB-25: the report's parameters become the view's, at publish time.
        _rp = _db_manager.list_report_parameters(body.business_report_id) or []
        body.param_definitions = [  # type: ignore[misc]
            ParamDefinition(**p) if isinstance(p, dict) else p
            for p in _inherit_param_defs_from_report(
                [p.model_dump() if hasattr(p, "model_dump") else p
                 for p in (body.param_definitions or [])],
                _rp, report_id=body.business_report_id)
        ]
        query_config_snap = {"source_type": "business_report", "business_report_id": body.business_report_id}
        query_id_val = None
        conn_id_val = None
        log_detail = f"business_report {body.business_report_id}"
    elif body.source_type == "federation":
        fv = _db_manager.get_federation_view(body.federation_view_id)
        if not fv:
            raise HTTPException(404, "Federation view not found")
        query_config_snap = {"source_type": "federation", "federation_view_id": body.federation_view_id}
        query_id_val = None
        conn_id_val = None
        log_detail = f"federation_view {body.federation_view_id}"
    elif body.source_type == "sql_file":
        # Phase 122C: .sql file as PV source
        sf = _db_manager.get_sql_file(body.sql_file_id)
        if not sf:
            raise HTTPException(404, "SQL file not found")
        # Read SQL content from NFS — split if cross-connection
        from api.sql_files_api import _get_storage_dir, _split_cross_sql
        _sf_path = _get_storage_dir() / sf["file_path"]
        if not _sf_path.exists():
            raise HTTPException(404, "SQL file not found on disk")
        _sf_content = _sf_path.read_text(encoding="utf-8")
        _sf_primary, _sf_secondary = _split_cross_sql(_sf_content)
        query_config_snap = {
            "source_type": "sql_file",
            "sql_file_id": body.sql_file_id,
            "raw_sql": _sf_primary,
            "connection_id": sf.get("connection_id"),
        }
        # Phase 124-C: Cross-connection sql_file
        if sf.get("secondary_connection_id"):
            if not _sf_secondary:
                raise HTTPException(400,
                    f"SQL file {body.sql_file_id} has secondary_connection_id but no secondary SQL content. "
                    "Re-save the .sql file with both primary and secondary SQL.")
            query_config_snap["secondary_connection_id"] = sf["secondary_connection_id"]
            query_config_snap["secondary_raw_sql"] = _sf_secondary
            query_config_snap["combine_mode"] = sf.get("combine_mode", "union")
            query_config_snap["join_config"] = sf.get("join_config")
        query_id_val = None
        conn_id_val = sf.get("connection_id")
        log_detail = f"sql_file {body.sql_file_id} cross={bool(sf.get('secondary_connection_id'))}"
    elif body.source_type == "sql_query":
        # Phase 154 (2026-06-25) -- CQB cross-source published API.
        # SqlSavedQuery (sql_saved_queries table) is CQB's native
        # storage: primary_connection_id + primary_sql with optional
        # secondary_connection_id + secondary_sql + join_config.
        # Snapshot the full shape into query_config so the PV runtime
        # (published_views_api.py:1456) recognises the cross-conn
        # fields and dispatches through execute_cross_query_background.
        sq = _db_manager.get_sql_query(body.sql_query_id)
        if not sq:
            raise HTTPException(404, "SQL saved query not found")
        query_config_snap = {
            "source_type":   "sql_query",
            "sql_query_id":  body.sql_query_id,
            "raw_sql":       sq["primary_sql"],
            "connection_id": sq["primary_connection_id"],
        }
        if sq.get("secondary_connection_id"):
            if not sq.get("secondary_sql"):
                raise HTTPException(400,
                    f"SQL saved query {body.sql_query_id} has "
                    "secondary_connection_id but no secondary_sql. "
                    "Re-save the CQB query with both sides populated.")
            query_config_snap["secondary_connection_id"] = sq["secondary_connection_id"]
            query_config_snap["secondary_raw_sql"]       = sq["secondary_sql"]
            # CQB defaults to "join" when join_config is set; "union"
            # otherwise.  Mirrors the cross-source engine's semantics.
            # 2026-10-24 -- the saved query's OWN combine mode when it has one
            # (a union query carrying a join_config was published as a JOIN)
            query_config_snap["combine_mode"]            = (
                sq.get("combine_mode")
                or ("join" if sq.get("join_config") else "union")
            )
            if sq.get("join_config"):
                query_config_snap["join_config"]         = sq["join_config"]
        query_id_val = None
        conn_id_val = sq["primary_connection_id"]
        log_detail = (f"sql_query {body.sql_query_id} "
                      f"cross={bool(sq.get('secondary_connection_id'))}")
    else:
        # Existing saved query path
        sq = _db_manager.get_query(body.query_id)
        if not sq:
            raise HTTPException(404, "Saved query not found")
        query_config_snap = sq["query_config"]  # frozen snapshot
        query_id_val = body.query_id
        conn_id_val = (sq.get("query_config") or {}).get("connection_id")
        log_detail = f"query {body.query_id}"

    # Phase 132.37 — apply explicit WHERE-clause mapping.  Static rows are
    # merged into the query_config snapshot's filters (replacing any prior
    # filter on the same column so the publisher's static value wins).
    # Dynamic rows append their column to ``allowed_filters`` so the
    # consumer can override via ``?col=value``.  Both lists keep their
    # caller-provided ordering and de-dup by case-insensitive bare column
    # name (matches the ``_col_key`` normaliser the runtime uses for
    # REPLACE-semantics, Phase 132.36).
    if getattr(body, "where_clauses", None):
        _wc_list = list(body.where_clauses or [])
        # Defensive copy of filters — snapshots are shared by reference with
        # the saved-query row in some paths; mutating in place would leak.
        _existing_filters = list((query_config_snap or {}).get("filters") or [])

        def _bare(col: str) -> str:
            return (col or "").rsplit(".", 1)[-1].lower()

        _static_keys = {_bare(w.column) for w in _wc_list if w.mode == "static"}
        # Drop any prior filter whose column collides with a publisher-supplied
        # static row — the new value/operator takes precedence (REPLACE).
        _kept = [f for f in _existing_filters
                 if _bare(f.get("column") or "") not in _static_keys]
        for w in _wc_list:
            if w.mode == "static":
                _kept.append({
                    "column": w.column,
                    "operator": w.operator,
                    "value": w.value,
                })
        query_config_snap = dict(query_config_snap or {})
        query_config_snap["filters"] = _kept
        # Stash the original mapping so editors can re-render the
        # Dynamic/Static toggles when the publisher reopens the dialog.
        query_config_snap["_where_clauses_mapping"] = [
            w.model_dump() for w in _wc_list
        ]
        # Append every Dynamic column into allowed_filters (idempotent).
        _af = list(body.allowed_filters or [])
        _af_lower = {c.lower() for c in _af}
        for w in _wc_list:
            if w.mode == "dynamic" and w.column.lower() not in _af_lower:
                _af.append(w.column)
                _af_lower.add(w.column.lower())
        body.allowed_filters = _af  # type: ignore[misc]

        # BF-491 — auto-add matching param_definitions entries for Dynamic
        # WHERE rows so the consumer's runtime-params panel + OpenAPI docs
        # surface them.  Preserves existing entries (publisher may have
        # customised type/default/required).
        body.param_definitions = [  # type: ignore[misc]
            ParamDefinition(**p) if isinstance(p, dict) else p
            for p in _sync_param_defs_from_dynamic_where(
                [p.model_dump() if hasattr(p, "model_dump") else p
                 for p in (body.param_definitions or [])],
                _wc_list,
            )
        ]

    # Phase 133-J — validate credential routing choices BEFORE persisting.
    # Catches two cases that would otherwise surface as confusing runtime
    # errors during consumer calls (when the publisher has long since
    # closed the browser tab).  We check the effective execution
    # connection — execution_connection_id override wins over conn_id_val.
    _cred_mode_in = (body.credential_mode or "consumer").lower()
    # 2026-10-25 -- THE data-policy switch of this API (stored as
    # ``entitlement_mode``; off = an API key reads with no row policy and no
    # dimension, apply = the key's own bindings and values).  A NEW view
    # starts at the deployment's declared default
    # (``published_views.default_data_policy_mode``), never a hardcoded
    # value; choosing the OTHER side at publish is an ADMIN decision (owner
    # decision 3, 2026-10-24) -- a publisher who sends nothing, or the
    # default, is not deciding anything.
    # 2026-10-25 (the owner: "everything should be based on config"): an API
    # nobody pins is stored UNSET and follows published_views.
    # default_data_policy_mode live (entitlement.effective_mode).  PINNING
    # it (off / apply) is for the roles in row_security.
    # data_policy_switch_roles; anyone may ask for the config's own value,
    # which pins nothing.
    from core.row_security.entitlement import default_mode as _ent_default_of, may_set_switch as _may_pin
    _ent_default = _ent_default_of("api")
    _ent_want = (body.entitlement_mode or "default").lower()
    _ent_mode_in = None if _ent_want == "default" else _ent_want
    if _ent_mode_in is not None and not _may_pin(user):
        if _ent_mode_in != _ent_default:
            raise HTTPException(403, "Only the roles in row_security.data_policy_switch_roles decide whether "
                                     "data policies (row policies and data entitlement) apply to API keys on "
                                     "a view (entitlement_mode); without one the API follows "
                                     f"published_views.default_data_policy_mode ({_ent_default})")
        _ent_mode_in = None
    _eff_conn_id_for_validation = body.execution_connection_id or conn_id_val
    if _cred_mode_in == "shared":
        if not _eff_conn_id_for_validation:
            raise HTTPException(
                400,
                "credential_mode='shared' requires a concrete execution connection. "
                "Pick one in Execution Connection or use a saved query that has one.",
            )
        _conn = _db_manager.get_connection_raw(_eff_conn_id_for_validation)
        if not _conn:
            raise HTTPException(400,
                f"Execution connection id={_eff_conn_id_for_validation} not found.")
        _conn_cfg = _conn.get("config", {}) or {}
        if not _conn_cfg.get("system_account_id"):
            raise HTTPException(
                400,
                "credential_mode='shared' requires the chosen connection to have a "
                "system account configured.  Either attach a system account to the "
                "connection or pick a different credential mode "
                "(publisher / consumer).",
            )

    # BF-430A — validate reader_override against the live registry.  Empty
    # string clears (treated as NULL).  Unknown name fails with 400 here so
    # operators get fast feedback rather than silent router fallback.
    _ro_in = (body.reader_override or "").strip() or None
    if _ro_in:
        from core.s3_readers import available_readers as _avail_readers
        _avail = set(_avail_readers())
        if _ro_in not in _avail:
            raise HTTPException(
                400,
                f"reader_override={_ro_in!r} is not a registered reader. "
                f"Available: {sorted(_avail)}",
            )

    # Phase 146-B -- refuse the publish when the snapshotted SQL
    # references a ``__logical__:name`` that lacks a binding on ANY of
    # the connections the PV is allowed to serve.  Prevents a consumer
    # picking ?engine=42 and hitting a mystery SQL failure downstream.
    #
    # 2026-07-02 audit fix -- validate BOTH primary AND secondary SQL
    # separately (was: first-truthy short-circuit that let one side
    # skip validation) and cover ``custom_sql`` (execute path reads it,
    # publish must too).
    if isinstance(query_config_snap, dict):
        from core.logical_table_service import get_service as _lt_svc
        _svc = _lt_svc(_db_manager)
        _primary_sql = (
            query_config_snap.get("raw_sql")
            or query_config_snap.get("custom_sql")
            or ""
        )
        _secondary_sql = query_config_snap.get("secondary_raw_sql") or ""
        _secondary_conn_id = query_config_snap.get("secondary_connection_id")
        _all_missing: List[Dict[str, Any]] = []
        # Primary side -- validated against primary_connection_id +
        # allowed_engine_connections whitelist.
        if _primary_sql and "__logical__:" in _primary_sql.lower():
            _r_primary = _svc.validate_pv_bindings(
                _primary_sql,
                allowed_engine_connections=(
                    list(body.allowed_engine_connections)
                    if body.allowed_engine_connections else None
                ),
                primary_connection_id=conn_id_val,
            )
            if not _r_primary["ok"]:
                _all_missing.extend(
                    dict(m, side="primary") for m in _r_primary["missing"]
                )
        # Secondary side -- validated against the secondary connection
        # ONLY (Phase 146-A ?engine=... doesn't cover the secondary
        # side of a cross-source PV; a mismatched secondary is a
        # publish-time bug).
        if _secondary_sql and "__logical__:" in _secondary_sql.lower():
            _r_secondary = _svc.validate_pv_bindings(
                _secondary_sql,
                allowed_engine_connections=None,
                primary_connection_id=_secondary_conn_id,
            )
            if not _r_secondary["ok"]:
                _all_missing.extend(
                    dict(m, side="secondary") for m in _r_secondary["missing"]
                )
        if _all_missing:
            raise HTTPException(
                400,
                f"Publish refused: {len(_all_missing)} logical-table "
                f"binding(s) missing.  Add via "
                f"POST /api/admin/logical-tables/{{id}}/bindings for "
                f"each entry.  Detail: {_all_missing}",
            )

    # Snapshot the query config
    pv = _db_manager.create_published_view(
        slug=body.slug,
        name=body.name,
        description=body.description,
        query_id=query_id_val,
        connection_id=conn_id_val,
        query_config=query_config_snap,
        allowed_filters=body.allowed_filters,
        # P4 (2026-08-17) — an OMITTED limit is stored as NULL so the view
        # follows the LIVE published_views config at serve time (see
        # helpers.resolve_view_limits).  Only an EXPLICIT request value is
        # snapshotted onto the row (0 = deliberately unlimited).
        default_limit=(body.default_limit
                       if "default_limit" in body.model_fields_set else None),
        max_limit=(body.max_limit
                   if "max_limit" in body.model_fields_set else None),
        cache_ttl_seconds=body.cache_ttl_seconds,
        param_definitions=[p.model_dump() for p in body.param_definitions],
        allowed_ad_groups=body.allowed_ad_groups or [],
        source_type=body.source_type,
        business_report_id=body.business_report_id,
        federation_view_id=body.federation_view_id,
        sql_file_id=getattr(body, 'sql_file_id', None),
        min_cache_age_seconds=body.min_cache_age_seconds,
        allow_cache_bypass=body.allow_cache_bypass,
        cache_strategy=body.cache_strategy,
        # Phase 146-A — Multi-engine connection whitelist (None/empty = legacy)
        allowed_engine_connections=(
            list(body.allowed_engine_connections) if body.allowed_engine_connections else None
        ),
        reader_override=_ro_in,  # BF-430A
        # Phase 133-J — publisher-time credential routing.  publisher_username
        # is captured here (not derived later) so it survives if the publisher
        # is later deleted or renamed.  When credential_mode='shared' we still
        # store publisher_username for audit, but the resolver path forces
        # is_shared=true and never touches the vault.
        execution_connection_id=body.execution_connection_id,
        credential_mode=(body.credential_mode or "consumer"),
        entitlement_mode=_ent_mode_in,
        publisher_username=user.get("username"),
        created_by=user.get("username"),
    )
    logger.info("Published view '%s' (id=%d) from %s by %s",
                body.slug, pv["id"], log_detail, user.get("username"))
    audit_event(_db_manager, user, None, "pv.publish", "published_view", pv["id"],
                {"slug": body.slug, "source": log_detail,
                 # 2026-10-25 -- the data-policy switch this API was born with
                 "entitlement_mode": _ent_mode_in or f"config ({_ent_default})",
                 "entitlement_mode_default": _ent_default})
    # 2026-09-27 -- the BASELINE schema (version 1): what consumers are
    # handed today, so a later drift has something to diff against.
    _record_schema_version(pv, reason="publish", user=user)

    # Auto-generate a 30-day temporary test key for immediate API testing
    # Skip if a test key with the same name already exists (BF-123: re-publish guard)
    try:
        test_key_name = f"{body.slug}-test-key"
        # BF-131: Use targeted query instead of list_api_keys() full table scan
        has_existing = (
            _db_manager.api_key_exists_by_name(test_key_name)
            if hasattr(_db_manager, 'api_key_exists_by_name')
            else any(k.get("name") == test_key_name and k.get("is_active", True)
                     for k in (_db_manager.list_api_keys() if hasattr(_db_manager, 'list_api_keys') else []))
        )
        if has_existing:
            logger.info("Test key '%s' already exists — skipping auto-generation", test_key_name)
        else:
            test_ak, test_raw_key = _generate_api_key(
                name=test_key_name,
                scoped_view_ids=[pv["id"]],
                rate_limit="60/minute",
                expires_hours=720,  # 30 days
                created_by=user.get("username"),
            )
            pv["test_api_key"] = test_raw_key
            pv["test_api_key_expires_hours"] = 720
            logger.info("Auto-generated 30-day test key for view '%s' (key_id=%d)",
                        body.slug, test_ak.get("id"))
            audit_event(_db_manager, user, None, "pv.auto_test_key", "api_key", test_ak.get("id"),
                        {"slug": body.slug, "expires_hours": 720})
    except Exception as exc:
        logger.warning("Failed to auto-generate test key for '%s': %s", body.slug, exc)

    return pv


# P2 (2026-08-17) — fields safe to show a non-owner in the management list.
# Everything else on the row (query_config, connection/source routing,
# credential_mode, publisher_username, query_hash, engine whitelist, …) is
# publisher-internal and was an object-level IDOR when returned to every
# authenticated user.
_PV_CATALOG_FIELDS = (
    "id", "slug", "name", "description", "source_type", "is_active",
    "version", "created_by", "created_at", "updated_at",
)


def _pv_catalog_entry(pv: dict) -> dict:
    """Redacted, catalog-safe projection of a published view row."""
    entry = {k: pv.get(k) for k in _PV_CATALOG_FIELDS}
    entry["_redacted"] = True
    return entry


@mgmt_router.get("/api/published-views")
async def list_views(user: dict = Depends(require_capability("published_api.view"))):
    """List published views.

    P2 (2026-08-17) — owner-scoped, matching the PUT endpoint's
    created_by/admin pattern.  Admins see every full record; a non-admin sees
    their OWN views in full and every other view as a redacted catalog entry
    (id/slug/name/description/…) so pickers (feed source, API-key request)
    keep working without disclosing another publisher's query, source routing
    or credential mode.
    """
    _ensure_mgmt_ready()
    views = await adb(_db_manager.list_published_views, active_only=False)
    views = await adb(_with_source_status, _db_manager, views)
    views = await adb(_with_schema_versions, _db_manager, views)
    if is_admin_like(user):
        return views
    _username = user.get("username")
    return [
        v if v.get("created_by") == _username else _pv_catalog_entry(v)
        for v in views
    ]


def _with_schema_versions(db, views: list) -> list:
    """Decorate each view with its latest recorded SCHEMA version --
    ``schema_version`` (int or null when none recorded), ``schema_changed_at``
    and ``schema_changes`` (the last diff, or null on the baseline) -- so the
    page can flag a view whose columns moved.  One query for the page.
    Fail-open: an unreadable table leaves the keys null, never the list
    empty."""
    try:
        latest = db.latest_pv_schema_versions([v.get("id") for v in views])
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("published views: schema versions unreadable (%s)", exc)
        latest = {}
    if not isinstance(latest, dict):          # an unexpected shape is unknown, not a crash
        latest = {}
    out = []
    for v in views:
        d = dict(v)
        sv = latest.get(d.get("id"))
        if not isinstance(sv, dict):
            sv = None
        vn = sv.get("version_no") if sv else None
        d["schema_version"] = vn if isinstance(vn, int) else None
        d["schema_changed_at"] = sv.get("created_at") if sv else None
        d["schema_changes"] = (sv.get("changes") if sv and isinstance(vn, int) and vn > 1
                               else None)
        out.append(d)
    return out


# What a view SERVES, by source type: the getter that must still find it.
_SOURCE_GETTERS = {
    "business_report": ("business_report_id", "get_business_report", "finance report"),
    "federation": ("federation_view_id", "get_federation_view", "federation view"),
    "saved_query": ("query_id", "get_query", "saved query"),
}


def _with_source_status(db, views: list) -> list:
    """Each view with ``source_missing`` -- the reason it can no longer run
    -- and ``health`` / ``lifecycle`` (2026-10-17).  2026-09-25: a view over a
    deleted report stayed listed as normal; only Republish (a 404) or a
    consumer's call found out -- and the first fix checked three of the five
    dependency kinds (not the SQL file, not the CONNECTION).  Now ONE reader,
    the inventory's dependency graph (core/published_api/impact.py): every
    connection, the source object, the report's dataset.  A dependency that
    could not be READ is ``health.unknown`` with the reason -- never claimed
    missing, never claimed fine; an inventory that could not be built leaves
    the keys None and says so in ``inventory_problem``."""
    try:
        from core.published_api.inventory import build_inventory
        apis, meta = build_inventory(db, kinds=["published_view"])
        by_id = {a.api_id: a for a in apis}
        problem = None
    except Exception as exc:                            # noqa: BLE001
        logger.warning("published views: inventory health unreadable (%s)", exc)
        by_id, problem = {}, f"{type(exc).__name__}: {str(exc)[:160]}"
    out = []
    for v in views or []:
        api = by_id.get(v.get("id"))
        if api is None:
            out.append({**v, "source_missing": None, "health": None, "lifecycle": None,
                        "inventory_problem": problem or "not in the inventory"})
            continue
        health = api.health or {}
        # source_missing keeps its 2026-09-25 meaning -- the thing it serves is
        # GONE -- for the page that reads it; health carries every state
        # (inactive, unpublished, unknown) with its reason
        gone = [d.reason for d in api.dependencies if d.state == "missing" and d.id is not None]
        out.append({**v, "source_missing": "; ".join(gone) if gone else None, "health": health,
                    "lifecycle": api.lifecycle,
                    "consumer_count": len([c for c in api.consumers if c.is_active])})
    return out


@mgmt_router.get("/api/published-views/{view_id}")
async def get_view(view_id: int, user: dict = Depends(require_capability("published_api.view"))):
    """Get a published view by ID. Owner or admin only (P2 2026-08-17 —
    matches the PUT endpoint's existing ownership pattern; the full record
    includes the frozen query, source routing and credential_mode)."""
    _ensure_mgmt_ready()
    pv = await adb(_db_manager.get_published_view, view_id)
    if not pv:
        raise HTTPException(404, "Published view not found")
    if pv.get("created_by") != user.get("username") and not is_admin_like(user):
        raise HTTPException(403, "Only the view owner or an admin can read this view")
    return pv


@mgmt_router.put("/api/published-views/{view_id}")
async def update_view(
    view_id: int,
    body: UpdateViewRequest,
    user: dict = Depends(require_capability("published_api.create")),
):
    """Update published view settings. Owner or admin only."""
    _ensure_mgmt_ready()
    pv_check = _db_manager.get_published_view(view_id)
    if not pv_check:
        raise HTTPException(404, "Published view not found")
    if pv_check.get("created_by") != user.get("username") and not is_admin_like(user):
        raise HTTPException(403, "Only the view owner or an admin can update this view")
    updates = body.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(400, "No fields to update")

    # BF-130: Strip source_type routing fields — these are set at publish time only.
    # Allowing update would let a view owner redirect execution to data sources
    # they don't own (e.g., change source_type to business_report with someone else's BR).
    # Phase 133-J — publisher_username is frozen at publish time and acts
    # as the trust anchor for credential_mode='publisher'.  Allowing it to
    # be re-pointed via PUT would let a view owner redirect resolved creds
    # to a different account's vault.  Strip silently so older clients
    # that round-trip pv.to_dict() through PUT don't break.
    for _immutable in ("source_type", "business_report_id",
                       "federation_view_id", "publisher_username"):
        updates.pop(_immutable, None)

    # 2026-10-24 -- entitlement_mode is an ADMIN decision; an owner's
    # round-trip of the same value is not a change and passes.
    # 2026-10-25 -- "default" UNPINS (the API follows the config again); a
    # round-trip of what the row already shows is no change.
    _ent_change = None
    if "entitlement_mode" in updates:
        from core.row_security.entitlement import mode_face as _face, may_set_switch as _may_pin
        _now = _face(pv_check.get("entitlement_mode_stored"), "api")
        _want = updates["entitlement_mode"]
        _new = None if _want in (None, "default") else _want
        if _want is None or _new == _now["entitlement_mode_stored"] or (
                _now["entitlement_mode_stored"] is None and _new == _now["entitlement_mode"]):
            updates.pop("entitlement_mode")
        else:
            if not _may_pin(user):
                raise HTTPException(403, "Only the roles in row_security.data_policy_switch_roles decide whether "
                                         "data policies (row policies and data entitlement) apply to API keys "
                                         "on a view (entitlement_mode)")
            updates["entitlement_mode"] = _new
            _ent_change = (_now["entitlement_mode_stored"] or f"config ({_now['entitlement_mode']})",
                           _new or f"config ({_now['entitlement_mode_default']})")

    # Phase 132.37 — re-apply WHERE-clause mapping on update.  Pop the
    # field out of the kwargs payload (the PV model doesn't have a
    # column for it — it's encoded into query_config) and rewrite both
    # filters[] and allowed_filters using the same logic as publish.
    if "where_clauses" in updates and updates["where_clauses"] is not None:
        _wc_in = updates.pop("where_clauses")
        _wc_list = [
            w if isinstance(w, ParamDefinition) is False and hasattr(w, "column") else w
            for w in _wc_in
        ]
        # The Pydantic UpdateViewRequest already validated each row.
        _wc_rows = updates.pop("_wc_rows_internal", None) or _wc_in
        _existing_qc = dict(pv_check.get("query_config") or {})
        _existing_filters = list(_existing_qc.get("filters") or [])

        def _bare2(col: str) -> str:
            return (col or "").rsplit(".", 1)[-1].lower()

        _wc_models = []
        for w in _wc_rows:
            if hasattr(w, "model_dump"):
                _wc_models.append(w.model_dump())
            elif isinstance(w, dict):
                _wc_models.append(w)
        _static_keys = {_bare2(w.get("column") or "")
                        for w in _wc_models if (w.get("mode") or "static") == "static"}
        _kept = [f for f in _existing_filters
                 if _bare2(f.get("column") or "") not in _static_keys]
        for w in _wc_models:
            if (w.get("mode") or "static") == "static":
                _kept.append({
                    "column": w.get("column"),
                    "operator": w.get("operator") or "eq",
                    "value": w.get("value"),
                })
        _existing_qc["filters"] = _kept
        _existing_qc["_where_clauses_mapping"] = _wc_models
        updates["query_config"] = _existing_qc

        _af_upd = list(updates.get("allowed_filters")
                       if updates.get("allowed_filters") is not None
                       else (pv_check.get("allowed_filters") or []))
        _af_lower = {c.lower() for c in _af_upd}
        for w in _wc_models:
            if (w.get("mode") or "static") == "dynamic":
                _col = w.get("column") or ""
                if _col and _col.lower() not in _af_lower:
                    _af_upd.append(_col)
                    _af_lower.add(_col.lower())
        updates["allowed_filters"] = _af_upd

        # BF-491 — same auto-sync as publish path so editors can add
        # Dynamic WHERE rows without manually duplicating param_definitions.
        # Pulls the BASELINE from either the update body (if the client
        # sent param_definitions) or the persisted row (preserving any
        # entries the publisher hand-tuned before).
        _existing_pdefs = (
            updates.get("param_definitions")
            if "param_definitions" in updates and updates["param_definitions"] is not None
            else (pv_check.get("param_definitions") or [])
        )
        _normalised_pdefs = [
            p.model_dump() if hasattr(p, "model_dump") else p
            for p in (_existing_pdefs or [])
        ]
        updates["param_definitions"] = _sync_param_defs_from_dynamic_where(
            _normalised_pdefs, _wc_models,
        )

    # BF-430A — validate reader_override on update too.  Empty string clears.
    if "reader_override" in updates:
        _ro_upd = (updates["reader_override"] or "").strip() or None
        if _ro_upd:
            from core.s3_readers import available_readers as _avail_readers
            _avail = set(_avail_readers())
            if _ro_upd not in _avail:
                raise HTTPException(
                    400,
                    f"reader_override={_ro_upd!r} is not a registered reader. "
                    f"Available: {sorted(_avail)}",
                )
        updates["reader_override"] = _ro_upd

    # Phase 133-J — same shared-mode validation as publish.  If the
    # publisher edits to credential_mode='shared', the effective execution
    # connection (override or PV's stored conn_id) must have a system
    # account.  Otherwise consumer calls would fail with a generic 500
    # long after the publisher closed the edit dialog.
    if updates.get("credential_mode") == "shared":
        _eff_id = (
            updates.get("execution_connection_id")
            or pv_check.get("execution_connection_id")
            or pv_check.get("connection_id")
        )
        if not _eff_id:
            raise HTTPException(
                400,
                "credential_mode='shared' requires a concrete execution connection.",
            )
        _conn = _db_manager.get_connection_raw(_eff_id)
        if not _conn or not (_conn.get("config", {}) or {}).get("system_account_id"):
            raise HTTPException(
                400,
                "credential_mode='shared' requires the chosen connection to have a "
                "system account configured.",
            )

    # Serialize param_definitions if present
    if "param_definitions" in updates:
        updates["param_definitions"] = [
            p.model_dump() if isinstance(p, ParamDefinition) else p
            for p in updates["param_definitions"]
        ]

    # Check slug uniqueness if changing
    if "slug" in updates:
        existing = _db_manager.get_published_view_by_slug(updates["slug"])
        if existing and existing["id"] != view_id:
            raise HTTPException(409, f"Slug '{updates['slug']}' already in use")

    pv = _db_manager.update_published_view(view_id, **updates)
    if _ent_change and pv:
        audit_event(_db_manager, user, None, "pv.entitlement_mode", "published_view", view_id,
                    {"from": _ent_change[0], "to": _ent_change[1]})
    if not pv:
        raise HTTPException(404, "Published view not found")
    if "query_config" in updates:
        _record_schema_version(pv, reason="update", user=user)
    # BF-145: Clear cache when settings change (allowed_filters, limits, cache_ttl, etc.)
    # to prevent stale results being served with old settings.
    # Phase 146-A: allowed_engine_connections also invalidates — removing an
    # engine from the whitelist should not let its cached responses keep serving.
    _cache_fields = {"allowed_filters", "default_limit", "max_limit", "cache_ttl_seconds",
                     "allowed_columns", "allow_cache_bypass", "param_definitions", "slug",
                     "allowed_engine_connections",
                     # 2026-10-24 -- whose rows a key reads changes with it
                     "entitlement_mode"}
    if _cache_fields & set(updates.keys()):
        _clear_view_cache(view_id, _cache_dir)
    audit_event(_db_manager, user, None, "pv.update", "published_view", view_id,
                {"fields": list(updates.keys())})
    return pv


@mgmt_router.delete("/api/published-views/{view_id}")
async def deactivate_view(view_id: int, user: dict = Depends(require_capability("published_api.create"))):
    """Deactivate a published view. Owner or admin only."""
    _ensure_mgmt_ready()
    pv_check = await adb(_db_manager.get_published_view, view_id)
    if not pv_check:
        raise HTTPException(404, "Published view not found")
    if pv_check.get("created_by") != user.get("username") and not is_admin_like(user):
        raise HTTPException(403, "Only the view owner or an admin can deactivate this view")
    ok = await adb(_db_manager.deactivate_published_view, view_id)
    if not ok:
        raise HTTPException(404, "Published view not found")
    # Clear cached responses for this view
    _clear_view_cache(view_id, _cache_dir)
    # BF-132: Revoke auto-generated test key to prevent stale key accumulation
    slug = pv_check.get("slug", "")
    if slug:
        test_key_name = f"{slug}-test-key"
        await adb(_db_manager.revoke_api_key_by_name, test_key_name)
        # P3 (2026-08-17) — same zero-window eviction as the DELETE
        # /api/api-keys/{key_id} route (see comment there).
        try:
            from api.deps import invalidate_api_key_cache
            invalidate_api_key_cache(None)
        except Exception as exc:
            logger.warning("API-key cache invalidation on test-key revoke "
                           "failed: %s", exc)
    audit_event(_db_manager, user, None, "pv.deactivate", "published_view", view_id)
    return {"message": "View deactivated"}


@mgmt_router.post("/api/published-views/{view_id}/republish")
async def republish_view(
    view_id: int,
    user: dict = Depends(require_capability("published_api.create")),
):
    """Re-snapshot query_config from the linked source (query, sql_file, BR, federation). Owner or admin."""
    _ensure_mgmt_ready()
    pv = _db_manager.get_published_view(view_id)
    if not pv:
        raise HTTPException(404, "Published view not found")
    if pv.get("created_by") != user.get("username") and not is_admin_like(user):
        raise HTTPException(403, "Only the view owner or an admin can republish this view")

    source_type = pv.get("source_type") or "saved_query"
    _extra_updates: dict = {}          # FB-25: per-source extra columns to refresh

    if source_type == "sql_file":
        sf = _db_manager.get_sql_file(pv.get("sql_file_id"))
        if not sf:
            raise HTTPException(404, "Linked SQL file not found")
        from api.sql_files_api import _get_storage_dir, _split_cross_sql
        _sf_path = _get_storage_dir() / sf["file_path"]
        if not _sf_path.exists():
            raise HTTPException(404, "SQL file not found on disk")
        _sf_content = _sf_path.read_text(encoding="utf-8")
        _sf_primary, _sf_secondary = _split_cross_sql(_sf_content)
        new_config = {
            "source_type": "sql_file",
            "sql_file_id": pv.get("sql_file_id"),
            "raw_sql": _sf_primary,
            "connection_id": sf.get("connection_id"),
        }
        if sf.get("secondary_connection_id") and _sf_secondary:
            new_config["secondary_connection_id"] = sf["secondary_connection_id"]
            new_config["secondary_raw_sql"] = _sf_secondary
            new_config["combine_mode"] = sf.get("combine_mode", "union")
            new_config["join_config"] = sf.get("join_config")
        conn_id_val = sf.get("connection_id")
        log_detail = f"sql_file {pv.get('sql_file_id')}"

    elif source_type == "business_report":
        br = _db_manager.get_business_report(pv.get("business_report_id"))
        if not br:
            raise HTTPException(404, "Linked business report not found")
        new_config = {"source_type": "business_report", "business_report_id": pv.get("business_report_id")}
        conn_id_val = None
        log_detail = f"business_report {pv.get('business_report_id')}"
        # FB-25: a parameter added to the report since the publish reaches
        # the view on republish (additive -- hand-tuned entries are kept).
        _extra_updates["param_definitions"] = _inherit_param_defs_from_report(
            list(pv.get("param_definitions") or []),
            _db_manager.list_report_parameters(pv.get("business_report_id")) or [],
            report_id=pv.get("business_report_id"))

    elif source_type == "federation":
        fv = _db_manager.get_federation_view(pv.get("federation_view_id"))
        if not fv:
            raise HTTPException(404, "Linked federation view not found")
        new_config = {"source_type": "federation", "federation_view_id": pv.get("federation_view_id")}
        conn_id_val = None
        log_detail = f"federation_view {pv.get('federation_view_id')}"

    else:
        # saved_query — original path
        sq = _db_manager.get_query(pv.get("query_id"))
        if not sq:
            raise HTTPException(404, "Linked saved query not found")
        new_config = sq["query_config"]
        conn_id_val = (sq.get("query_config") or {}).get("connection_id")
        log_detail = f"query {pv.get('query_id')}"

    updated = _db_manager.update_published_view(
        view_id,
        query_config=new_config,
        connection_id=conn_id_val,
        **_extra_updates,
    )
    # Clear cache since config changed
    _clear_view_cache(view_id, _cache_dir)
    _record_schema_version(updated, reason="republish", user=user)
    logger.info("Republished view %d from %s by %s", view_id, log_detail, user.get("username"))
    audit_event(_db_manager, user, None, "pv.republish", "published_view", view_id,
                {"source": log_detail})
    # Fire webhooks (safe — errors suppressed)
    # BF-594: strong-ref track (Python issue #88831) so the webhook
    # delivery isn't silently GC'd mid-call.
    from core.bg_tasks import track_bg_task as _track_bg_task_pv1
    _track_bg_task_pv1(_safe_fire_webhooks("view_updated", view_id, {"view_id": view_id, "slug": pv.get("slug"), "action": "republish"}, _db_manager))
    return updated


@mgmt_router.post("/api/published-views/detect-partitions")
async def detect_partitions(
    body: DetectPartitionsRequest,
    user: dict = Depends(require_capability("published_api.create")),
):
    """
    Phase 98-H: Detect partition columns from a query_config's registered tables
    and return suggested param_definitions.

    Returns:
        suggested_params: list of ParamDefinition dicts with required=true
        partition_columns: dict {table_name: [col, ...]}
        warnings: list of non-fatal messages (schema cache miss, etc.)
    """
    _ensure_mgmt_ready()
    query_config = body.query_config
    conn_id = body.connection_id or query_config.get("connection_id")

    suggested_params: list = []
    partition_columns: dict = {}
    # Phase 133-H (2026-05-24): also return the FULL column list per
    # source table so the publish dialog's WHERE-clause editor can
    # offer a dropdown of every column (not just partition cols), with
    # partition cols badged.  Empty dict if no source could be resolved
    # — the editor falls back to free-text in that case.
    columns_by_table: dict = {}
    # Phase 133-H round 4 — table → connection_id mapping so the
    # frontend's lazy distinct-values lookup hits the RIGHT warehouse
    # for cross-source PVs (primary=Trino, secondary=Oracle).  Without
    # this, picking a column from the secondary side sent the query
    # to the primary connection and silently returned no values.
    table_connection_ids: dict = {}
    warnings: list = []
    seen_params: set = set()

    # Collect file references from files[] and joins[].right_file
    file_refs: list = list(query_config.get("files") or [])
    for j in query_config.get("joins") or []:
        rf = j.get("right_file") or ""
        if rf:
            file_refs.append(rf)

    # Phase 132.37 — SQL connector partition detection.  When the source is a
    # SQL warehouse (Trino/Starburst/Snowflake/Databricks/Oracle/Athena) the
    # ``files`` array is typically empty; the table reference lives inside
    # ``raw_sql`` (sql_file source) or ``custom_sql``.  Extract fully-qualified
    # ``catalog.schema.table`` refs from those SQL strings and dispatch to the
    # connector's ``detect_partitions()`` method.  Iceberg tables expose the
    # partition spec via the metastore; Snowflake exposes clustering keys.
    if conn_id and _db_manager:
        # Connection lookup failure here is silent — the S3 / iceberg loop
        # below tries the same call and surfaces its own warning, so adding
        # a duplicate here would clutter the dialog (caught by enterprise
        # test_sanitize_error_in_warnings).
        try:
            conn_raw_sql = _db_manager.get_connection_raw(conn_id)
        except Exception:
            conn_raw_sql = None
            logger.debug("SQL-connector partition detection: connection lookup failed",
                         exc_info=True)
        conn_type_sql = (conn_raw_sql or {}).get("connection_type", "")
        try:
            from core.connectors import SQL_CONNECTOR_TYPES, get_connector
        except Exception:
            SQL_CONNECTOR_TYPES = set()
            get_connector = None
        if conn_raw_sql and conn_type_sql in SQL_CONNECTOR_TYPES and get_connector:
            import re as _re_sql
            _sql_refs: list = []
            # Phase 133-H deep-dive — match 3-part ``cat.schema.table``,
            # 2-part ``schema.table``, and 1-part ``table`` refs.  Older
            # regex captured only 3-part and silently missed Snowflake
            # ``DB.TABLE`` shortcuts and Oracle ``SCHEMA.TABLE`` queries.
            # 3-part most-specific first so it wins greedy match.
            _pat_3 = _re_sql.compile(
                r'(?:FROM|JOIN)\s+"?(\w+)"?\s*\.\s*"?(\w+)"?\s*\.\s*"?(\w+)"?',
                _re_sql.IGNORECASE,
            )
            _pat_2 = _re_sql.compile(
                r'(?:FROM|JOIN)\s+"?(\w+)"?\s*\.\s*"?(\w+)"?(?!\s*\.)',
                _re_sql.IGNORECASE,
            )
            # Phase 133-H — secondary connection lookup for cross-source
            # PVs.  ``secondary_raw_sql`` runs on a DIFFERENT connection
            # than ``raw_sql`` / ``custom_sql``; introspecting it against
            # the primary connector returns wrong / no partition info.
            _sec_conn_id = query_config.get("secondary_connection_id")
            _sec_conn_raw = None
            if _sec_conn_id and _db_manager:
                try:
                    _sec_conn_raw = _db_manager.get_connection_raw(_sec_conn_id)
                except Exception:
                    _sec_conn_raw = None
                    logger.debug("Secondary connection lookup failed",
                                 exc_info=True)
            # Phase 133-H deep-dive — Trino/Snowflake/etc. require a
            # catalog to DESCRIBE / SHOW CREATE.  When the user's SQL
            # uses 2-part refs (schema.table), fall back to the
            # connection config's ``catalog`` / ``database`` field so
            # ``list_columns("", schema, table)`` doesn't produce
            # ``DESCRIBE .schema.table``.
            _default_cat = (
                (conn_raw_sql or {}).get("config", {}).get("catalog")
                or (conn_raw_sql or {}).get("config", {}).get("database")
                or ""
            )
            for _sql_key in ("raw_sql", "custom_sql"):
                _sql_text = query_config.get(_sql_key) or ""
                if isinstance(_sql_text, str) and _sql_text:
                    for _m in _pat_3.finditer(_sql_text):
                        _sql_refs.append((_m.group(1), _m.group(2), _m.group(3)))
                    for _m in _pat_2.finditer(_sql_text):
                        # 2-part: use connection's default catalog
                        # when the connector requires one (Trino).
                        _sql_refs.append((_default_cat, _m.group(1), _m.group(2)))
            if _sql_refs:
                _conn_obj = None
                try:
                    try:
                        _conn_obj = get_connector(
                            conn_type_sql,
                            (conn_raw_sql or {}).get("config", {}),
                            conn_id,
                            (conn_raw_sql or {}).get("name", ""),
                        )
                    except TypeError:
                        # Older connector factories take only (type, config)
                        _conn_obj = get_connector(
                            conn_type_sql, (conn_raw_sql or {}).get("config", {}),
                        )
                except Exception as _ce:
                    warnings.append(
                        f"SQL connector init failed: {sanitize_error(str(_ce))}"
                    )
                    logger.debug("SQL connector init failed", exc_info=True)
                if _conn_obj is not None:
                    try:
                        for _cat, _sch, _tbl in _sql_refs:
                            _tbl_label = (
                                f"{_cat}.{_sch}.{_tbl}" if _cat else f"{_sch}.{_tbl}"
                            )
                            # Phase 133-H: fetch the FULL column list first
                            # so the publish dialog has a dropdown even when
                            # the table has no partitions (or partition
                            # detection fails).  Best-effort — empty list
                            # means the editor falls back to free-text.
                            # Phase 133-H round 10 — schema_cache hit
                            # short-circuit before hitting the warehouse.
                            # Type-defensive: require real dict to avoid
                            # MagicMock noise in tests.
                            _cached_cols: list = []
                            try:
                                _cs = _db_manager.get_schema_cache(conn_id, _tbl_label)
                                if isinstance(_cs, dict):
                                    _sd = _cs.get("schema_data")
                                    if isinstance(_sd, dict):
                                        _cc = _sd.get("columns")
                                        if isinstance(_cc, list):
                                            _cached_cols = _cc
                            except Exception:
                                _cached_cols = []
                            try:
                                _all_cols = _cached_cols or (
                                    _conn_obj.list_columns(_cat, _sch, _tbl) or []
                                )
                                if _all_cols:
                                    columns_by_table[_tbl_label] = [
                                        {
                                            "name": (c.get("name") if isinstance(c, dict) else str(c)) or "",
                                            "type": (c.get("type") if isinstance(c, dict) else "") or "string",
                                        }
                                        for c in _all_cols
                                        if (c.get("name") if isinstance(c, dict) else c)
                                    ]
                                    table_connection_ids[_tbl_label] = conn_id
                            except Exception as _ce:
                                logger.debug(
                                    "list_columns failed for %s: %s",
                                    _tbl_label, _ce, exc_info=True,
                                )
                            try:
                                parts = _conn_obj.detect_partitions(_cat, _sch, _tbl) or []
                            except Exception as _de:
                                warnings.append(
                                    f"Partition detection failed for {_tbl_label}: "
                                    f"{sanitize_error(str(_de))}"
                                )
                                continue
                            if not parts:
                                continue
                            partition_columns.setdefault(_tbl_label, [])
                            for p in parts:
                                _pname = p.get("name") if isinstance(p, dict) else None
                                if not _pname:
                                    continue
                                if _pname not in partition_columns[_tbl_label]:
                                    partition_columns[_tbl_label].append(_pname)
                                if _pname in seen_params:
                                    continue
                                seen_params.add(_pname)
                                _ptype = (p.get("type") if isinstance(p, dict) else "") or ""
                                inferred_type, reason = _infer_param_type(_pname)
                                # Prefer connector-declared type over heuristic when
                                # it's one of the supported param types.
                                if _ptype.lower() in ("date", "integer", "float",
                                                       "boolean", "string"):
                                    inferred_type = _ptype.lower()
                                    reason = f"connector type {_ptype}"
                                suggested_params.append({
                                    "name": _pname,
                                    "type": inferred_type,
                                    "required": True,
                                    "description": f"Partition column from {_tbl_label}",
                                    "default": None,
                                    "inferred_reason": reason,
                                })
                    finally:
                        try:
                            _conn_obj.close()
                        except Exception:
                            pass

            # Phase 133-H deep-dive — SECONDARY connection introspection
            # for cross-source PVs.  ``secondary_raw_sql`` runs on a
            # DIFFERENT connection (e.g. primary=Trino, secondary=Oracle).
            # Without this pass, secondary-side partitions + columns
            # never surface in the publish dialog.
            _sec_sql_text = query_config.get("secondary_raw_sql") or ""
            if (
                _sec_conn_raw
                and isinstance(_sec_sql_text, str)
                and _sec_sql_text
            ):
                _sec_conn_type = _sec_conn_raw.get("connection_type", "")
                if _sec_conn_type in SQL_CONNECTOR_TYPES:
                    _sec_default_cat = (
                        _sec_conn_raw.get("config", {}).get("catalog")
                        or _sec_conn_raw.get("config", {}).get("database")
                        or ""
                    )
                    _sec_refs: list = []
                    for _m in _pat_3.finditer(_sec_sql_text):
                        _sec_refs.append((_m.group(1), _m.group(2), _m.group(3)))
                    for _m in _pat_2.finditer(_sec_sql_text):
                        _sec_refs.append((_sec_default_cat, _m.group(1), _m.group(2)))
                    if _sec_refs:
                        _sec_obj = None
                        try:
                            try:
                                _sec_obj = get_connector(
                                    _sec_conn_type,
                                    _sec_conn_raw.get("config", {}),
                                    _sec_conn_id,
                                    _sec_conn_raw.get("name", ""),
                                )
                            except TypeError:
                                _sec_obj = get_connector(
                                    _sec_conn_type, _sec_conn_raw.get("config", {}),
                                )
                        except Exception as _ce:
                            warnings.append(
                                f"Secondary connector init failed: {sanitize_error(str(_ce))}"
                            )
                            logger.debug("Secondary connector init failed",
                                         exc_info=True)
                        if _sec_obj is not None:
                            try:
                                for _cat, _sch, _tbl in _sec_refs:
                                    _tbl_label = (
                                        f"{_cat}.{_sch}.{_tbl}" if _cat
                                        else f"{_sch}.{_tbl}"
                                    )
                                    try:
                                        _all_cols = _sec_obj.list_columns(_cat, _sch, _tbl) or []
                                        if _all_cols:
                                            columns_by_table[_tbl_label] = [
                                                {
                                                    "name": (c.get("name") if isinstance(c, dict) else str(c)) or "",
                                                    "type": (c.get("type") if isinstance(c, dict) else "") or "string",
                                                }
                                                for c in _all_cols
                                                if (c.get("name") if isinstance(c, dict) else c)
                                            ]
                                            table_connection_ids[_tbl_label] = _sec_conn_id
                                    except Exception as _ce:
                                        logger.debug(
                                            "Secondary list_columns failed for %s: %s",
                                            _tbl_label, _ce, exc_info=True,
                                        )
                                    try:
                                        parts = _sec_obj.detect_partitions(_cat, _sch, _tbl) or []
                                    except Exception as _de:
                                        warnings.append(
                                            f"Secondary partition detection failed for {_tbl_label}: "
                                            f"{sanitize_error(str(_de))}"
                                        )
                                        continue
                                    if not parts:
                                        continue
                                    partition_columns.setdefault(_tbl_label, [])
                                    for p in parts:
                                        _pname = p.get("name") if isinstance(p, dict) else None
                                        if not _pname:
                                            continue
                                        if _pname not in partition_columns[_tbl_label]:
                                            partition_columns[_tbl_label].append(_pname)
                                        if _pname in seen_params:
                                            continue
                                        seen_params.add(_pname)
                                        _ptype = (p.get("type") if isinstance(p, dict) else "") or ""
                                        inferred_type, reason = _infer_param_type(_pname)
                                        if _ptype.lower() in ("date", "integer", "float",
                                                               "boolean", "string"):
                                            inferred_type = _ptype.lower()
                                            reason = f"connector type {_ptype}"
                                        suggested_params.append({
                                            "name": _pname,
                                            "type": inferred_type,
                                            "required": True,
                                            "description": f"Partition column from {_tbl_label} (secondary)",
                                            "default": None,
                                            "inferred_reason": reason,
                                        })
                            finally:
                                try:
                                    _sec_obj.close()
                                except Exception:
                                    pass

    for file_ref in file_refs:
        path = file_ref if isinstance(file_ref, str) else (file_ref.get("path") or "")
        # Support all virtual prefixes: __registered__, __iceberg__, raw S3
        is_registered = path.startswith("__registered__:")
        is_iceberg = path.startswith("__iceberg__:")
        is_s3_raw = path.startswith("s3://") or path.startswith("s3a://")
        if not (is_registered or is_iceberg or is_s3_raw):
            continue  # local tables, federation views, etc. — skip

        if is_registered or is_iceberg:
            table_name = path.split(":", 1)[1].strip()
        else:
            # Raw S3 path — use last segment as name
            table_name = path.rstrip("/").split("/")[-1] if "/" in path else path

        try:
            if not conn_id or not _db_manager:
                warnings.append(f"No connection_id — skipping partition detection for {table_name}")
                continue

            conn_raw = _db_manager.get_connection_raw(conn_id)
            if not conn_raw:
                warnings.append(f"Connection {conn_id} not found")
                continue

            cfg = conn_raw.get("config", {})
            bucket = cfg.get("bucket_name", "")
            prefix = ""

            if is_registered or is_iceberg:
                reg_tables = cfg.get("registered_tables") or []
                tbl_cfg = next((t for t in reg_tables if t.get("name") == table_name), None)
                if not tbl_cfg:
                    warnings.append(f"Table '{table_name}' not in connection registered_tables")
                    continue
                prefix = tbl_cfg.get("prefix", tbl_cfg.get("s3_prefix", ""))
            elif is_s3_raw:
                # Parse bucket and prefix from raw S3 URL
                from urllib.parse import urlparse
                parsed = urlparse(path)
                bucket = parsed.netloc
                prefix = parsed.path.lstrip("/")

            # Step 4 of REFACTOR_PLAN_SCHEMA_READER.md — use the
            # unified ``read_parquet_schema_for_conn`` helper instead
            # of the previously-positional ``safe_read_parquet_schema``
            # call.  The OLD call was
            #     safe_read_parquet_schema(conn_raw, s3, bucket, prefix)
            # which silently passed the s3 client as ``bucket`` and
            # the real bucket as ``prefix`` (the function signature is
            # ``(conn_raw, bucket, prefix, s3_client=None)``).  That
            # made the schema read fail and partition-column detection
            # for raw-S3-URL published views silently return no
            # partition columns.  The helper takes ``s3_client=...``
            # as a keyword argument so the misorder is impossible.
            from core.s3_utilities import make_s3_client_for_conn
            from core.schema_reader import read_parquet_schema_for_conn
            s3 = make_s3_client_for_conn(conn_raw)
            # Phase 133-H round 10 — schema_cache hit short-circuit.
            # Every CQB / BQB / register-table call already populated
            # this; reading it is a single DB row (sub-ms) vs. the
            # parquet/iceberg S3 metadata round-trip below (seconds).
            # When the user lands on the publish dialog with their
            # data already cached, we want the dropdown to appear
            # IMMEDIATELY — not after a multi-second S3 listing.
            schema_info = None
            try:
                _cached = _db_manager.get_schema_cache(conn_id, table_name)
                # Type-defensive: require a real dict (not MagicMock /
                # None / other) so test fixtures that hand back a bare
                # MagicMock fall through to the read path cleanly.
                if isinstance(_cached, dict):
                    _sd = _cached.get("schema_data")
                    if isinstance(_sd, dict) and _sd:
                        schema_info = _sd
                        logger.debug(
                            "detect_partitions: schema_cache hit for %s",
                            table_name,
                        )
            except Exception:
                logger.debug(
                    "detect_partitions: schema_cache lookup failed for %s",
                    table_name, exc_info=True,
                )
            if schema_info is None:
                schema_info = read_parquet_schema_for_conn(
                    conn_raw, bucket, prefix, s3_client=s3,
                )
            pcols = schema_info.get("partition_columns") or []
            # Phase 133-H round 10 — iceberg schemas (cached or freshly
            # read) carry ``partition_spec`` (list of {name, transform,
            # source_column}) instead of the parquet-style
            # ``partition_columns`` list.  Extract the source columns
            # so iceberg-cached tables also surface partition badges
            # without needing the resolver round-trip.
            if not pcols:
                _pspec = schema_info.get("partition_spec") or []
                if isinstance(_pspec, list) and _pspec:
                    pcols = [
                        (p.get("source_column") or p.get("name") or "")
                        for p in _pspec
                        if isinstance(p, dict) and (p.get("source_column") or p.get("name"))
                    ]

            # Phase 133-H: surface the FULL column list so the publish
            # dialog's WHERE-clause editor offers every column (not
            # just partition cols), with partition cols badged.
            _all_cols = schema_info.get("columns") or []
            if _all_cols:
                columns_by_table[table_name] = [
                    {
                        "name": (c.get("name") if isinstance(c, dict) else str(c)) or "",
                        "type": (c.get("type") if isinstance(c, dict) else "") or "string",
                    }
                    for c in _all_cols
                    if (c.get("name") if isinstance(c, dict) else c)
                ]
                table_connection_ids[table_name] = conn_id

            # Phase 133-H: iceberg manifests + partition_cache fallback.
            # ``read_parquet_schema_for_conn`` reads hive-style ``key=value``
            # path partitions but an iceberg table's partition spec lives
            # in the metadata.json.  The resolver does a 3-tier lookup:
            # admin override (registered_tables[i].partition_columns) →
            # partition_cache (populated by every CQB/BQB run) → iceberg
            # metadata.json.  When the hive scan finds nothing, fall
            # through to the resolver so iceberg + cached tables still
            # populate the WHERE editor's partition badges.
            if not pcols:
                try:
                    from core.iceberg_partition_resolver import (
                        resolve_partition_columns as _resolve_pcols,
                    )
                    _registered_tbl = None
                    if is_registered or is_iceberg:
                        _registered_tbl = tbl_cfg
                    resolved = _resolve_pcols(
                        registered_table=_registered_tbl,
                        db_manager=_db_manager,
                        connection_id=conn_id,
                        table_name=table_name,
                        s3_client=s3,
                        bucket=bucket,
                        table_prefix=prefix,
                    )
                    if resolved:
                        pcols = list(resolved)
                except Exception as _re:
                    logger.debug(
                        "resolve_partition_columns fallback failed for %s: %s",
                        table_name, _re, exc_info=True,
                    )

            if pcols:
                partition_columns[table_name] = pcols
                for col in pcols:
                    if col in seen_params:
                        continue
                    seen_params.add(col)
                    param_type, reason = _infer_param_type(col)
                    suggested_params.append({
                        "name": col,
                        "type": param_type,
                        "required": True,
                        "description": f"Partition column from {table_name}",
                        "default": None,
                        "inferred_reason": reason,
                    })
            else:
                warnings.append(f"No hive partition columns found for table '{table_name}'")

        except Exception as exc:
            warnings.append(f"Schema detection failed for '{table_name}': {sanitize_error(str(exc))}")
            logger.debug("Partition detection error for %s: %s", table_name, exc, exc_info=True)

    # ── Phase 129: Extract filter columns from WHERE clause as params ──
    filters = query_config.get("filters") or []
    for f in filters:
        col = f.get("column") or ""
        # Strip table prefix (e.g. "trades.trade_date" → "trade_date")
        col_name = col.split(".")[-1] if "." in col else col
        if not col_name or col_name in seen_params:
            continue
        seen_params.add(col_name)
        param_type, reason = _infer_param_type(col_name)
        # Pre-fill default from the filter value
        default_val = f.get("value")
        if isinstance(default_val, list):
            default_val = ",".join(str(v) for v in default_val)
        suggested_params.append({
            "name": col_name,
            "type": param_type,
            "required": True,
            "description": "Filter from WHERE clause",
            "default": str(default_val) if default_val else None,
            "inferred_reason": reason,
        })

    # ── Extract {{param}} placeholders from raw_sql ──
    import re
    raw_sql = query_config.get("raw_sql") or ""
    for match in re.finditer(r"\{\{(\w+)\}\}", raw_sql):
        pname = match.group(1)
        if pname in seen_params:
            continue
        seen_params.add(pname)
        param_type, reason = _infer_param_type(pname)
        suggested_params.append({
            "name": pname,
            "type": param_type,
            "required": True,
            "description": "SQL placeholder parameter",
            "default": None,
            "inferred_reason": reason,
        })

    return {
        "suggested_params": suggested_params,
        "partition_columns": partition_columns,
        "columns_by_table": columns_by_table,
        "table_connection_ids": table_connection_ids,
        "warnings": warnings,
    }


# ── Phase 98-E: UAT → Prod Promotion (Export / Import) ───────────────────────

@mgmt_router.get("/api/published-views/{view_id}/export")
async def export_view(
    view_id: int,
    user: dict = Depends(require_capability("published_api.manage")),
):
    """Phase 98-E export, since 2026-10-17 derived from the configuration-
    release item (core/release/types/published.py): the portable keys stay,
    connections are NAMES (the raw ``execution_connection_id`` that used to
    cross environments is gone) and ``release_item`` is what the import
    applies through the release engine."""
    _ensure_mgmt_ready()
    from core.release.contract import ReleaseRefusal
    from core.release.registry import load as _load_registry
    from core.release.types.published import PublishedView, legacy_export_dict

    def _inner():
        with _db_manager.get_session(read_only=True) as session:
            row = session.query(PublishedView).filter(PublishedView.id == int(view_id)).first()
            if row is None:
                raise HTTPException(404, f"Published view {view_id} not found")
            try:
                return legacy_export_dict(session, row, _load_registry())
            except ReleaseRefusal as exc:
                raise HTTPException(422, exc.to_dict())
    return await adb(_inner)


@mgmt_router.get("/api/published-views/export-all")
async def export_all_views(
    user: dict = Depends(require_capability("published_api.manage")),
):
    """Every published view as a portable dict (see export_view).  A view
    that cannot be exported is NAMED under ``skipped`` with the reason,
    never silently dropped."""
    _ensure_mgmt_ready()
    from core.release.contract import ReleaseRefusal
    from core.release.registry import load as _load_registry
    from core.release.types.published import PublishedView, legacy_export_dict

    def _inner():
        result, skipped = [], []
        with _db_manager.get_session(read_only=True) as session:
            registry = _load_registry()
            for row in session.query(PublishedView).order_by(PublishedView.slug).all():
                try:
                    result.append(legacy_export_dict(session, row, registry))
                except ReleaseRefusal as exc:
                    skipped.append({"slug": row.slug, "error": str(exc)})
        return {"count": len(result), "views": result, "skipped": skipped}
    return await adb(_inner)


@mgmt_router.post("/api/published-views/import")
async def import_views(
    body: ImportViewRequest,
    dry_run: bool = Query(False, description="Preview only -- nothing is written"),
    user: dict = Depends(require_capability("published_api.manage")),
):
    """Phase 98-E import, since 2026-10-17 ONE configuration release through
    core/release/engine.promote_items (the same contract, mapping, four-eyes
    and one-transaction apply as Admin -> Governance -> Configuration
    releases).  The summary keeps its shape -- created / updated / skipped /
    errors -- and names the release id(s); in a four-eyes environment the
    release stays previewed and the error says who must approve it."""
    _ensure_mgmt_ready()
    from core.release import engine as _release_engine
    from core.release.contract import ReleaseRefusal
    from core.release.types.published import legacy_dict_to_items

    items, errors, seen = [], [], set()
    for view in body.views:
        try:
            for it in legacy_dict_to_items(view):
                if (it.kind, it.key) not in seen:
                    seen.add((it.kind, it.key))
                    items.append(it)
        except ReleaseRefusal as exc:
            errors.append({"slug": str(view.get("slug") or "(missing)"), "error": str(exc)})

    def _inner():
        try:
            summary = _release_engine.promote_items(
                _db_manager, items, actor=user.get("username", "import"), ticket=body.ticket,
                source_commit=body.source_commit, source_environment="published-views import",
                scope={"kind": "published_view", "keys": [i.key for i in items]},
                connection_map=body.connection_map, overwrite_existing=body.overwrite_existing, dry_run=dry_run)
        except ReleaseRefusal as exc:
            raise HTTPException(422, exc.to_dict())
        summary["errors"] = errors + summary["errors"]
        summary["total_input"] = len(body.views)
        return summary
    summary = await adb(_inner)
    if summary["errors"]:
        logger.warning("Published views import: %d error(s): %s", len(summary["errors"]), summary["errors"])
    if not dry_run:
        audit_event(_db_manager, user, None, "pv.import", "published_view", None,
                    {"created": summary["created"], "updated": summary["updated"], "errors": len(summary["errors"]),
                     "release_ids": summary.get("release_ids")})
    return summary


@mgmt_router.put("/api/published-views/{view_id}/query")
async def update_view_query(
    view_id: int,
    body: UpdateQueryConfigRequest,
    user: dict = Depends(require_capability("published_api.create")),
):
    """
    Phase 98-C: Update the frozen query_config of a published view without
    delete+recreate (preserves slug + consumer URL). Owner or admin only.
    """
    _ensure_mgmt_ready()
    pv = _db_manager.get_published_view(view_id)
    if not pv:
        raise HTTPException(404, "Published view not found")
    if pv.get("created_by") != user.get("username") and not is_admin_like(user):
        raise HTTPException(403, "Only the view owner or an admin can update the query config")

    # Validate the new query_config
    from api.models.query_models import QueryConfigModel
    try:
        QueryConfigModel(**body.query_config)
    except Exception as exc:
        logger.error("Invalid query_config for view %s: %s", view_id, exc)
        raise HTTPException(400, "Invalid view configuration — contact administrator")

    updated = _db_manager.update_published_view(view_id, query_config=body.query_config)
    if not updated:
        raise HTTPException(404, "Published view not found")
    _record_schema_version(updated, reason="query_update", user=user)

    # Clear cache — consumers get fresh data on next request
    files_deleted = _clear_view_cache(view_id, _cache_dir)

    logger.info(
        "View %d (%s) query_config updated by %s — v%d, %d cache files cleared",
        view_id, pv.get("slug"), user.get("username"), updated.get("version", 1), files_deleted,
    )
    audit_event(_db_manager, user, None, "pv.update_query", "published_view", view_id,
                {"slug": pv.get("slug"), "version": updated.get("version", 1)})
    # Fire webhooks (safe — errors suppressed)
    # BF-594: strong-ref track (Python issue #88831).
    from core.bg_tasks import track_bg_task as _track_bg_task_pv2
    _track_bg_task_pv2(_safe_fire_webhooks("view_updated", view_id, {"view_id": view_id, "slug": pv.get("slug"), "action": "query_config_update"}, _db_manager))
    return {**updated, "cache_files_cleared": files_deleted}


@mgmt_router.get("/api/published-views/{view_id}/usage")
async def get_view_usage(
    view_id: int,
    limit: int = Query(100, ge=1, le=1000),
    user: dict = Depends(require_capability("published_api.manage")),
):
    """Get access logs for a published view."""
    _ensure_mgmt_ready()
    return _db_manager.list_api_access_logs(view_id, limit=limit)


def _record_schema_version(pv: Optional[dict], *, reason: str, user: dict) -> None:
    """Record the view's column set after a change that may have moved it
    (core/published_view_schema.py).  Fail-open: never the reason a
    publish / republish / update fails."""
    if not pv:
        return
    try:
        from core.published_view_schema import record_schema
        record_schema(_db_manager, pv, reason=reason,
                      changed_by=(user or {}).get("username"))
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("published view %s: schema version not recorded after %s "
                       "(fail-open): %s", pv.get("id"), reason, exc)


@mgmt_router.get("/api/published-views/{view_id}/schema-versions")
async def get_view_schema_versions(
    view_id: int,
    limit: int = Query(50, ge=1, le=200),
    user: dict = Depends(require_capability("published_api.view")),
):
    """The recorded column sets of a view, newest first, each with what
    changed since the one before and who was told.  Owner or admin --
    the same rule as PUT, because a version carries the column list of a
    view another publisher may not see in full."""
    _ensure_mgmt_ready()
    pv = await adb(_db_manager.get_published_view, view_id)
    if not pv:
        raise HTTPException(404, "Published view not found")
    if pv.get("created_by") != user.get("username") and not is_admin_like(user):
        raise HTTPException(403, "Only the view owner or an admin can read its schema history")
    versions = await adb(_db_manager.list_pv_schema_versions, view_id, limit)
    return {"view_id": view_id, "slug": pv.get("slug"), "versions": versions}


# ── API Key Management ───────────────────────────────────────────────────────

@mgmt_router.post("/api/api-keys")
async def create_api_key(body: CreateApiKeyRequest, user: dict = Depends(require_capability("published_api.keys.approve"))):
    """Create a new API key. The raw key is also stored (Fernet-encrypted) for admin retrieval.

    P1 (2026-08-17) — an empty scope no longer means "every view" (that was a
    silent master key).  A key must either name its views or be EXPLICITLY
    created global via ``global_access=true`` (stored as the "*" sentinel and
    audit-logged).  A scopeless, non-global key would be able to access
    nothing, so it is refused with an actionable 400 instead of minted dead.
    """
    _ensure_mgmt_ready()
    _scoped: list = list(body.scoped_view_ids or [])
    if body.global_access:
        from api.published_views.helpers import GLOBAL_KEY_SCOPE_SENTINEL
        if GLOBAL_KEY_SCOPE_SENTINEL not in _scoped:
            _scoped.append(GLOBAL_KEY_SCOPE_SENTINEL)
    elif not _scoped:
        raise HTTPException(
            400,
            "scoped_view_ids is empty. An empty scope grants access to NO views. "
            "Name the published view ids this key may read, or set "
            "global_access=true to explicitly create an all-views key.",
        )
    prefix = _pv_cfg.api_key_prefix if _pv_cfg else "qs_"
    raw_key = prefix + secrets.token_hex(20)  # 40 hex chars
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

    # Encrypt the raw key for later admin retrieval
    encrypted_key = None
    try:
        from core.crypto import encrypt_value
        encrypted_key = encrypt_value(raw_key)
    except Exception as exc:
        logger.warning("Could not encrypt API key for storage: %s — key will only be shown once", exc)

    expires_at = None
    if body.expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=body.expires_hours)

    ak = await adb(_db_manager.create_api_key, 
        key_hash=key_hash,
        key_prefix=raw_key[:12],
        encrypted_key=encrypted_key,
        name=body.name,
        created_by=user.get("username"),
        scoped_view_ids=_scoped,
        rate_limit=body.rate_limit,
        expires_at=expires_at,
        # 2026-10-17 -- the key's FACE (the inventory's consumer)
        consumer=(body.consumer or None),
        owner_username=(body.owner_username or user.get("username")),
        contact_email=(body.contact_email or None),
    )
    if body.global_access:
        # Loud on purpose — a global key is a deliberate master key and the
        # audit trail must make that unmissable.
        logger.warning(
            "GLOBAL API key '%s' created by %s (prefix=%s) — this key can read "
            "EVERY published view.", body.name, user.get("username"), raw_key[:12])
    logger.info("Created API key '%s' (prefix=%s) by %s", body.name, raw_key[:12], user.get("username"))
    audit_event(_db_manager, user, None, "pv.create_api_key", "api_key", ak.get("id"),
                {"name": body.name, "scoped_views": _scoped,
                 "global_access": bool(body.global_access)})
    # the EFFECTIVE limit beside the declared one (core/published_api/rate_limits.py):
    # a 100000/minute key under a 300/minute operator cap is told so at birth
    from core.published_api.rate_limits import annotate_key
    return {**annotate_key(ak), "raw_key": raw_key}


@mgmt_router.get("/api/api-keys")
async def list_api_keys(user: dict = Depends(require_capability("published_api.keys.approve"))):
    """List all API keys (hash NOT returned), each with its EFFECTIVE rate
    limit (the operator's ``max_rate_limit`` cap applied -- the same function
    the enforcement charges by, so the face and the refusal agree)."""
    _ensure_mgmt_ready()
    from core.published_api.rate_limits import annotate_key
    rows = await adb(_db_manager.list_api_keys)
    return [annotate_key(r) for r in (rows or [])]


@mgmt_router.get("/api/api-keys/{key_id}/reveal")
async def reveal_api_key(key_id: int, user: dict = Depends(require_capability("published_api.view"))):
    """Retrieve the raw API key. Admin can reveal any key; non-admin can reveal keys they own."""
    _ensure_mgmt_ready()
    ak = await adb(_db_manager.get_api_key, key_id)
    if not ak:
        raise HTTPException(404, "API key not found")
    # BF-128: Allow key owner to reveal their own keys (not just admins)
    if ak.get("created_by") != user.get("username") and not is_admin_like(user):
        raise HTTPException(403, "Only the key owner or an admin can reveal this key")
    enc = ak.get("encrypted_key")
    if not enc:
        raise HTTPException(404, "Raw key not available — created before encrypted storage was enabled")
    try:
        from core.crypto import decrypt_value
        raw_key = decrypt_value(enc)
    except Exception as exc:
        logger.error("Failed to decrypt API key %d: %s", key_id, exc)
        raise HTTPException(500, "Could not decrypt API key")
    logger.info("User %s revealed API key %d (%s)", user.get("username"), key_id, ak.get("key_prefix"))
    audit_event(_db_manager, user, None, "pv.reveal_api_key", "api_key", key_id,
                {"key_prefix": ak.get("key_prefix")})
    return JSONResponse(
        content={"raw_key": raw_key, "key_prefix": ak.get("key_prefix"), "name": ak.get("name")},
        headers={"Cache-Control": "no-store, no-cache", "Pragma": "no-cache"},
    )


@mgmt_router.delete("/api/api-keys/{key_id}")
async def revoke_api_key(key_id: int, user: dict = Depends(require_capability("published_api.keys.approve"))):
    """Revoke an API key."""
    _ensure_mgmt_ready()
    ok = await adb(_db_manager.revoke_api_key, key_id)
    if not ok:
        raise HTTPException(404, "API key not found")
    logger.info("Revoked API key %d by %s", key_id, user.get("username"))
    # P3 (2026-08-17) — drop the auth-cache revocation window to ZERO on this
    # pod.  api/deps.py caches key-row lookups for ~30s; without this call a
    # revoked key kept authenticating until its cached entry expired.  The key
    # row's sha256 hash is not exposed by get_api_key(), so evict the WHOLE
    # cache (it is tiny, short-TTL, and repopulates on the next request) —
    # correctness over a micro-optimisation.  Cross-pod, the TTL remains the
    # documented upper bound (see deps.py REVOCATION BOUND note).
    try:
        from api.deps import invalidate_api_key_cache
        invalidate_api_key_cache(None)
    except Exception as exc:
        logger.warning("API-key cache invalidation on revoke failed "
                       "(revocation falls back to the %ss cache TTL): %s",
                       30, exc)
    # Phase 131 deep-dive #13: fire cancel_event for any in-flight
    # executions started by this key (immediate revocation on this pod).
    # Cross-pod revocation is caught by the periodic sweep in scheduler.
    try:
        from core.api_key_lifecycle import cancel_executions_for_api_key
        fired = cancel_executions_for_api_key(int(key_id))
        if fired:
            logger.info("Revoke api_key %d cancelled %d in-flight execution(s)",
                        key_id, fired)
    except Exception as exc:
        logger.debug("In-flight cancel on revoke failed: %s", exc)
    audit_event(_db_manager, user, None, "pv.revoke_api_key", "api_key", key_id)
    return {"message": "API key revoked"}


# ══════════════════════════════════════════════════════════════════════════════
# SELF-SERVICE API KEY REQUESTS (request → admin approve/deny → key generated)
# ══════════════════════════════════════════════════════════════════════════════


def _generate_api_key(name: str, scoped_view_ids, rate_limit, expires_hours, created_by: str,
                      consumer: Optional[str] = None, owner_username: Optional[str] = None,
                      contact_email: Optional[str] = None):
    """Shared key generation logic — used by both direct create and approval flow.
    2026-10-17: the key's FACE (consumer / owner_username / contact_email)
    rides along; ``owner_username`` defaults to ``created_by``."""
    prefix = _pv_cfg.api_key_prefix if _pv_cfg else "qs_"
    raw_key = prefix + secrets.token_hex(20)
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

    encrypted_key = None
    try:
        from core.crypto import encrypt_value
        encrypted_key = encrypt_value(raw_key)
    except Exception as exc:
        logger.warning("Could not encrypt API key for storage: %s", exc)

    expires_at = None
    if expires_hours:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=expires_hours)

    ak = _db_manager.create_api_key(
        key_hash=key_hash,
        key_prefix=raw_key[:12],
        encrypted_key=encrypted_key,
        name=name,
        created_by=created_by,
        scoped_view_ids=scoped_view_ids or [],
        rate_limit=rate_limit,
        expires_at=expires_at,
        consumer=(str(consumer)[:200] if consumer else None),
        owner_username=(str(owner_username or created_by or "")[:100] or None),
        contact_email=(str(contact_email)[:255] if contact_email else None),
    )
    return ak, raw_key


async def _notify_admins_new_request(requester: str, req: dict):
    """Notify all admin users about a new API key request.

    Uses ``target: "admins"`` so the frontend can filter by role —
    non-admin clients silently ignore these messages.
    """
    # BF-146: Redact requester identity from broadcast — broadcast() sends to ALL
    # connected WebSocket clients, not just admins. The "target": "admins" field is
    # only a frontend filter hint. Admins fetch full details via the API.
    if _ws_manager:
        try:
            # BF-598: was bare call to async function — the returned
            # coroutine was GC'd without running, so admin notifications
            # for new API key requests were SILENTLY DROPPED.
            # Strong-ref track via _track_bg_task so the broadcast
            # actually fires.
            from core.bg_tasks import track_bg_task as _track_bg_pv_kr
            _track_bg_pv_kr(_ws_manager.broadcast({
                "type": "api_key_request",
                "action": "new_request",
                "target": "admins",
                "request_id": req.get("id"),
            }))
        except Exception:
            pass
    if _db_manager:
        try:
            await adb(_db_manager.log_notification, 
                event_type="api_key_request",
                channel="api_key_requests",
                recipient="admins",
                status="unread",
                title="New API Key Request",
                message=f"{requester} requested API key '{req.get('key_name')}'",
                payload={"request_id": req.get("id")},
            )
        except Exception:
            pass


async def _notify_requester_decision(requester: str, request_id: int, decision: str, note: str | None):
    """Notify the requester about the admin's decision."""
    if _ws_manager:
        try:
            # BF-598: was bare call to async function — coroutine GC'd
            # without running, requester never got notified of approval
            # / denial.  Strong-ref track via _track_bg_task.
            from core.bg_tasks import track_bg_task as _track_bg_pv_dec
            _track_bg_pv_dec(_ws_manager.broadcast_to_user(requester, {
                "type": "api_key_request",
                "action": decision,
                "request_id": request_id,
                "note": note or "",
            }))
        except Exception:
            pass
    if _db_manager:
        try:
            await adb(_db_manager.log_notification, 
                event_type="api_key_request",
                channel="api_key_requests",
                recipient=requester,
                status="unread",
                title=f"API Key Request {decision.title()}",
                message=f"Your API key request was {decision}" + (f": {note}" if note else ""),
                payload={"request_id": request_id, "decision": decision},
            )
        except Exception:
            pass


@mgmt_router.post("/api/api-key-requests")
async def request_api_key(body: ApiKeyRequestCreate, user: dict = Depends(require_capability("published_api.create"))):
    """Any authenticated user can request an API key for published views."""
    _ensure_mgmt_ready()
    # Validate that all scoped views exist and are active
    _requested_pvs: list = []
    for vid in body.scoped_view_ids:
        pv = await adb(_db_manager.get_published_view, vid)
        if not pv:
            raise HTTPException(400, f"Published view {vid} not found")
        if not pv.get("is_active", True):
            raise HTTPException(400, f"Published view {vid} is not active")
        _requested_pvs.append(pv)

    username = user.get("username", "unknown")

    # BF-125: Prevent duplicate pending requests for same key name by same user
    existing_pending = await adb(_db_manager.list_api_key_requests, username=username, status="pending")
    if any(r.get("key_name") == body.key_name for r in existing_pending):
        raise HTTPException(409, f"You already have a pending request for key '{body.key_name}'")

    # If approval is not required, auto-create key immediately.
    #
    # 2026-08-23 (P6 D11) — A KEY MUST NEVER EXCEED ITS PRINCIPAL.  Nothing
    # here checked that the REQUESTER could open the views they asked for:
    # with require_key_approval=false, any authenticated user could self-mint
    # a key to a view whose allowed_ad_groups excluded them — the key then
    # read data its owner could not.  Auto-approval now runs the SAME
    # _check_view_access rule the serving path applies (admins skip it).  A
    # request the requester is NOT entitled to is not refused — it degrades
    # to a PENDING request for a human admin, so no legitimate workflow is
    # destroyed, and the reviewer sees why it landed on their desk.
    _needs_admin_review: str | None = None
    if _pv_cfg and not _pv_cfg.require_key_approval and not is_admin_like(user):
        from api.published_views.helpers import _check_view_access
        _requester_principal = {
            "username": username,
            "role": user.get("role", "viewer"),
            "is_admin": False,
            "groups": user.get("groups") or [],
            "ad_groups": user.get("ad_groups") or user.get("groups") or [],
            "scoped_view_ids": None,
            "api_key_id": None,
            "auth_method": "session",
        }
        for _pv_row in _requested_pvs:
            try:
                _check_view_access(_pv_row, _requester_principal)
            except HTTPException:
                _needs_admin_review = (
                    f"view {_pv_row.get('id')} ('{_pv_row.get('slug')}') is "
                    f"restricted by allowed_ad_groups and requester "
                    f"'{username}' is not a member — auto-approval withheld")
                break

    if _pv_cfg and not _pv_cfg.require_key_approval and _needs_admin_review is None:
        ak, raw_key = _generate_api_key(
            name=body.key_name,
            scoped_view_ids=body.scoped_view_ids,
            rate_limit=body.rate_limit,
            expires_hours=body.expires_hours,
            created_by=username,
            consumer=body.consumer,
            owner_username=username,
            contact_email=body.contact_email,
        )
        req = await adb(_db_manager.create_api_key_request, 
            requested_by=username,
            key_name=body.key_name,
            scoped_view_ids=body.scoped_view_ids,
            rate_limit=body.rate_limit,
            expires_hours=body.expires_hours,
            justification=body.justification,
            consumer=body.consumer,
            contact_email=body.contact_email,
            status="approved",
            reviewed_by="auto",
            reviewed_at=datetime.now(timezone.utc),
            review_note="Auto-approved (require_key_approval=false)",
            api_key_id=ak.get("id"),
        )
        audit_event(_db_manager, user, None, "pv.api_key_request_auto_approved", "api_key_request", req.get("id"),
                    {"key_name": body.key_name})
        from core.published_api.rate_limits import annotate_key
        key_face = annotate_key(ak)
        return {"request": req, "raw_key": raw_key, "auto_approved": True, "api_key": key_face,
                "effective_rate_limit": key_face["effective_rate_limit"],
                "rate_limit_capped": key_face["rate_limit_capped"],
                "rate_limit_cap_reason": key_face["rate_limit_cap_reason"]}

    # Create pending request.  When auto-approval was withheld (D11), say
    # so in the justification the reviewing admin reads.
    _justification = body.justification
    if _needs_admin_review:
        _justification = ((body.justification or "").strip() + chr(10) +
                          f"[auto-approval withheld: {_needs_admin_review}]").strip()
    req = await adb(_db_manager.create_api_key_request, 
        requested_by=username,
        key_name=body.key_name,
        scoped_view_ids=body.scoped_view_ids,
        rate_limit=body.rate_limit,
        expires_hours=body.expires_hours,
        justification=_justification,
        consumer=body.consumer,
        contact_email=body.contact_email,
    )
    audit_event(_db_manager, user, None, "pv.api_key_request_created", "api_key_request", req.get("id"),
                {"key_name": body.key_name, "views": body.scoped_view_ids})
    await _notify_admins_new_request(username, req)
    # what the key WILL be held to if approved as asked (the operator's cap applied)
    from core.published_api.rate_limits import effective_rate_limit
    preview = effective_rate_limit(body.rate_limit)
    return {"request": req, "auto_approved": False, "effective_rate_limit": preview["effective"],
            "rate_limit_capped": preview["capped"], "rate_limit_cap_reason": preview["reason"]}


@mgmt_router.get("/api/api-key-requests")
async def list_api_key_requests(
    status: str | None = Query(None, pattern="^(pending|approved|denied)$"),
    user: dict = Depends(require_capability("published_api.view")),
):
    """Admin sees all requests; non-admin sees only their own."""
    _ensure_mgmt_ready()
    if is_admin_like(user):
        return _db_manager.list_api_key_requests(status=status)
    return _db_manager.list_api_key_requests(username=user.get("username"), status=status)


@mgmt_router.get("/api/api-key-requests/pending-count")
async def pending_request_count(user: dict = Depends(require_capability("published_api.keys.approve"))):
    """Admin badge — count of pending requests."""
    _ensure_mgmt_ready()
    return {"count": await adb(_db_manager.count_pending_api_key_requests)}


@mgmt_router.post("/api/api-key-requests/{request_id}/approve")
async def approve_api_key_request(
    request_id: int,
    body: ApiKeyRequestApprove,
    user: dict = Depends(require_capability("published_api.keys.approve")),
):
    """Admin approves a pending API key request — key is auto-generated."""
    _ensure_mgmt_ready()
    req = _db_manager.get_api_key_request(request_id)
    if not req:
        raise HTTPException(404, "API key request not found")
    if req["status"] != "pending":
        raise HTTPException(409, f"Request already {req['status']}")

    # Use overrides if provided, else use requester's values
    rate_limit = body.rate_limit_override or req.get("rate_limit")
    expires_hours = body.expires_hours_override or req.get("expires_hours")

    ak, raw_key = _generate_api_key(
        name=req["key_name"],
        scoped_view_ids=req["scoped_view_ids"],
        rate_limit=rate_limit,
        expires_hours=expires_hours,
        created_by=req["requested_by"],
        # 2026-10-17 -- the requester is the person answerable for the key
        consumer=req.get("consumer"),
        owner_username=req["requested_by"],
        contact_email=req.get("contact_email"),
    )

    updated = _db_manager.update_api_key_request(request_id,
        status="approved",
        reviewed_by=user.get("username"),
        reviewed_at=datetime.now(timezone.utc),
        review_note=body.note,
        api_key_id=ak.get("id"),
    )
    logger.info("Admin %s approved API key request %d → key %d",
                user.get("username"), request_id, ak.get("id"))
    audit_event(_db_manager, user, None, "pv.api_key_request_approved", "api_key_request", request_id,
                {"key_name": req["key_name"], "api_key_id": ak.get("id")})
    await _notify_requester_decision(req["requested_by"], request_id, "approved", body.note)
    from core.published_api.rate_limits import annotate_key
    key_face = annotate_key(ak)
    return {"request": updated, "raw_key": raw_key, "api_key": key_face,
            "effective_rate_limit": key_face["effective_rate_limit"],
            "rate_limit_capped": key_face["rate_limit_capped"],
            "rate_limit_cap_reason": key_face["rate_limit_cap_reason"]}


@mgmt_router.post("/api/api-key-requests/{request_id}/deny")
async def deny_api_key_request(
    request_id: int,
    body: ApiKeyRequestReview,
    user: dict = Depends(require_capability("published_api.keys.approve")),
):
    """Admin denies a pending API key request."""
    _ensure_mgmt_ready()
    req = _db_manager.get_api_key_request(request_id)
    if not req:
        raise HTTPException(404, "API key request not found")
    if req["status"] != "pending":
        raise HTTPException(409, f"Request already {req['status']}")

    updated = _db_manager.update_api_key_request(request_id,
        status="denied",
        reviewed_by=user.get("username"),
        reviewed_at=datetime.now(timezone.utc),
        review_note=body.note,
    )
    logger.info("Admin %s denied API key request %d", user.get("username"), request_id)
    audit_event(_db_manager, user, None, "pv.api_key_request_denied", "api_key_request", request_id,
                {"key_name": req["key_name"]})
    await _notify_requester_decision(req["requested_by"], request_id, "denied", body.note)
    return {"request": updated}


# ══════════════════════════════════════════════════════════════════════════════
# PUBLISHED VIEW WEBHOOKS (Phase 114-B)
# ══════════════════════════════════════════════════════════════════════════════


@mgmt_router.get("/api/published-views/webhooks")
async def list_webhooks(view_id: int | None = None, user: dict = Depends(require_capability("published_api.manage"))):
    """List all webhooks, optionally filtered by view_id."""
    _ensure_mgmt_ready()
    return await adb(_db_manager.list_pv_webhooks, view_id=view_id)


async def _safe_fire_webhooks(*args, **kwargs) -> None:
    """Fire webhooks with error suppression — prevent orphaned task exceptions."""
    try:
        from core.webhook_dispatcher import fire_webhooks
        await fire_webhooks(*args, **kwargs)
    except Exception as exc:
        logger.warning("Webhook dispatch failed: %s", exc)


def _validate_webhook_url(url: str) -> None:
    """Phase 133-C: Block webhook URLs targeting private/loopback IPs (SSRF)."""
    try:
        from core.connectors.rest_api_connector import RestApiConnector
        RestApiConnector._validate_url_safety(url)
    except ValueError as exc:
        raise HTTPException(400, f"Webhook URL rejected: {exc}")
    except Exception as exc:
        logger.warning("Webhook URL validation error for %s: %s", url, exc)
        raise HTTPException(400, "Webhook URL validation failed")


@mgmt_router.post("/api/published-views/webhooks")
async def create_webhook(body: WebhookCreateRequest, user: dict = Depends(require_capability("published_api.manage"))):
    """Create a new webhook subscription."""
    _ensure_mgmt_ready()
    _validate_webhook_url(body.url)
    wh = await adb(_db_manager.create_pv_webhook, 
        view_id=body.view_id, url=body.url, events=body.events,
        secret=body.secret, retry_max=body.retry_max,
        timeout_seconds=body.timeout_seconds,
        created_by=user.get("username", ""),
    )
    audit_event(_db_manager, user, None, "pv.create_webhook", "webhook", wh.get("id") if isinstance(wh, dict) else None,
                {"url": body.url, "events": body.events})
    return wh


@mgmt_router.put("/api/published-views/webhooks/{webhook_id}")
async def update_webhook(webhook_id: int, body: WebhookUpdateRequest,
                         user: dict = Depends(require_capability("published_api.manage"))):
    """Update a webhook."""
    _ensure_mgmt_ready()
    if body.url:
        _validate_webhook_url(body.url)
    updates = body.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(400, "No fields to update")
    result = await adb(_db_manager.update_pv_webhook, webhook_id, **updates)
    if not result:
        raise HTTPException(404, "Webhook not found")
    audit_event(_db_manager, user, None, "pv.update_webhook", "webhook", webhook_id,
                {"fields": list(updates.keys())})
    return result


@mgmt_router.delete("/api/published-views/webhooks/{webhook_id}")
async def delete_webhook(webhook_id: int, user: dict = Depends(require_capability("published_api.manage"))):
    """Delete a webhook."""
    _ensure_mgmt_ready()
    if not await adb(_db_manager.delete_pv_webhook, webhook_id):
        raise HTTPException(404, "Webhook not found")
    audit_event(_db_manager, user, None, "pv.delete_webhook", "webhook", webhook_id)
    return {"message": "Webhook deleted"}
