"""DataFlow Engine API — Phase 132.

Brand-new endpoints under ``/api/dataflows`` and ``/api/dataflow-runs``.
Does NOT touch feed_api / reports_api / execute_api / published_views_api;
existing features are unaffected.

Auth model:
* List + get   — any authenticated user (read).
* Create / promote / archive / add_version / start_run / cancel /
  resume / rerun-stage / schedule CRUD — admin only.
* Run listing — authenticated user (filtered to their own runs unless
  they're admin).

Routes:
    GET    /api/dataflows                       — list (filters: name, status)
    POST   /api/dataflows                       — create v1 draft           [admin]
    GET    /api/dataflows/{id}                  — fetch one (with stages)
    POST   /api/dataflows/{id}/promote          — draft → active            [admin]
    POST   /api/dataflows/{id}/archive          — active → archived         [admin]
    POST   /api/dataflows/{id}/versions         — add new draft version     [admin]
    POST   /api/dataflows/{id}/export           — JSON export
    POST   /api/dataflows/import                — JSON import (creates v1)  [admin]
    GET    /api/dataflows/stage-types           — list registered stage types
    GET    /api/dataflows/templates             — list starter templates
    POST   /api/dataflows/templates/{name}/apply — clone starter into draft  [admin]

    POST   /api/dataflows/{name}/runs           — start a run               [admin]
    GET    /api/dataflow-runs                   — list (filters: dataflow_id, status, limit)
    GET    /api/dataflow-runs/{id}              — fetch one (with stage rows)
    POST   /api/dataflow-runs/{id}/cancel       — cancel an in-flight run   [admin]
    POST   /api/dataflow-runs/{id}/resume       — resume a failed/partial   [admin]
    POST   /api/dataflow-runs/{id}/rerun-stage  — rerun a single stage      [admin]

    GET    /api/dataflows/schedules             — list schedules
    POST   /api/dataflows/schedules             — create schedule           [admin]
    PATCH  /api/dataflows/schedules/{id}        — update schedule           [admin]
    DELETE /api/dataflows/schedules/{id}        — delete schedule           [admin]
    POST   /api/dataflows/scheduler/tick        — admin debug tick          [admin]
    POST   /api/dataflows/scheduler/start       — start cron loop           [admin]
    POST   /api/dataflows/scheduler/stop        — stop cron loop            [admin]
"""
from __future__ import annotations

import asyncio
import logging
import threading
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Set

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)
from pydantic import Field
from api.strict_request import StrictRequestModel  # AQD-03: unknown keys are refused, not ignored

from api.deps import get_api_key_user, get_current_user, require_admin, require_admin_read

logger = logging.getLogger(__name__)
router = APIRouter(tags=["dataflows"])


# ── Dependency injection (set from main.py) ──────────────────────────────


_db_manager: Any = None
_engine: Any = None
_dispatcher: Any = None
_scheduler: Any = None
_dispatch_executor: Optional[Any] = None  # ThreadPoolExecutor for ad-hoc run dispatch


# 2026-06-03 — async DB helper.  Wraps a synchronous callable on the
# default thread executor so SQLAlchemy sessions don't block the event
# loop.  Mirrors backend/api/admin_api.py::_adb so call sites read
# identically across the two modules.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)


def set_workflow_dependencies(
    db_manager: Any,
    engine: Any,
    dispatcher: Any,
    scheduler: Any,
    dispatch_executor: Any,
    # Back-compat: older main.py callers still pass user/admin dep refs as
    # positional args; ignore them — endpoints use Depends(get_current_user)
    # / Depends(require_admin) directly now.
    get_current_user_dep: Any = None,
    require_admin_dep: Any = None,
) -> None:
    """Wire dependencies.  Called once from main.py after init_workflow_subsystem."""
    global _db_manager, _engine, _dispatcher, _scheduler, _dispatch_executor
    _db_manager = db_manager
    _engine = engine
    _dispatcher = dispatcher
    _scheduler = scheduler
    _dispatch_executor = dispatch_executor


def _require_deps() -> None:
    if _engine is None or _dispatcher is None:
        # Phase 132.30 — surface the underlying init error if main.py
        # captured one.  Saves operators a trip to the startup log.
        from core.dataflow import get_init_error as _get_init_err
        underlying = _get_init_err()
        detail = "dataflow subsystem not initialised on this pod"
        if underlying:
            detail = (f"dataflow subsystem not initialised — startup error: "
                       f"{underlying}.  See backend startup log for the full "
                       f"traceback.  Hit GET /api/dataflows/_init-status for "
                       f"the captured diagnostic.")
        raise HTTPException(status_code=503, detail=detail)


def _username(user: Any) -> Optional[str]:
    if user is None:
        return None
    if isinstance(user, dict):
        return user.get("username") or user.get("name")
    return getattr(user, "username", None) or str(user)


def _audit(user: Any, action: str, target: Optional[str] = None,
           details: Optional[Dict[str, Any]] = None) -> None:
    """Fire-and-forget audit hook — never raises.

    Wraps ``core.audit.audit_event`` which is the existing fire-and-forget
    audit helper used by every other API router (~34 call sites).
    """
    if _db_manager is None:
        return
    try:
        from core.audit import audit_event
        resource_type = None
        resource_id = None
        if target and ":" in target:
            resource_type, _, resource_id = target.partition(":")
        audit_event(
            db_manager=_db_manager,
            user=user if isinstance(user, dict) else {"username": _username(user)},
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            details=details or {},
        )
    except Exception as exc:
        logger.debug("[workflow_api] audit hook failed: %s", exc)


# ── Pydantic bodies ──────────────────────────────────────────────────────


class StageBody(StrictRequestModel):
    stage_alias: str = Field(..., min_length=1, max_length=80)
    stage_type:  str = Field(..., min_length=1, max_length=80)
    seq:         int = Field(..., ge=0)
    predecessors:      Optional[List[str]]      = None
    config:            Optional[Dict[str, Any]] = None
    retry_policy:      Optional[Dict[str, Any]] = None
    timeout_seconds:   Optional[int]            = Field(None, ge=0)
    on_failure:        str                      = Field("halt", pattern="^(halt|continue|branch_to)$")
    on_failure_target: Optional[str]            = None


class WorkflowCreateBody(StrictRequestModel):
    name:            str  = Field(..., min_length=1, max_length=120)
    description:     Optional[str]            = None
    trigger_type:    str                       = Field("manual",
                                                       pattern="^(manual|cron|event|upstream)$")
    trigger_config:  Optional[Dict[str, Any]]  = None
    default_context: Optional[Dict[str, Any]]  = None
    stages:          List[StageBody]


class RunStartBody(StrictRequestModel):
    context:         Optional[Dict[str, Any]] = None
    trigger_payload: Optional[Dict[str, Any]] = None
    # Phase 132.20 — optional impersonation: who the run "executes as".
    # The actor (triggered_by) is always recorded from the auth context;
    # run_as is the downstream identity used for credential resolution
    # and audit.  Only admins can pass this — enforced in the route.
    run_as:          Optional[str]             = None
    allow_paused:    bool                      = False


class SetSlaBody(StrictRequestModel):
    sla_seconds: Optional[int] = None


class SetMaxRunSecondsBody(StrictRequestModel):
    max_run_seconds: Optional[int] = None


class SetWorkspaceBody(StrictRequestModel):
    workspace_id: Optional[int] = None


class RerunStageBody(StrictRequestModel):
    stage_alias: str = Field(..., min_length=1, max_length=80)
    force_unsafe: bool = False


class ScheduleCreateBody(StrictRequestModel):
    dataflow_id:       int            = Field(..., ge=1)
    name:              str            = Field(..., min_length=1, max_length=120)
    cron_expression:   Optional[str]  = Field(None, min_length=1, max_length=80)
    calendar_rule:     Optional[Dict[str, Any]] = None
    timezone:          str            = Field("UTC", max_length=50)
    context_overrides: Optional[Dict[str, Any]] = None
    is_active:         bool           = True


class ScheduleUpdateBody(StrictRequestModel):
    cron_expression:   Optional[str] = None
    calendar_rule:     Optional[Dict[str, Any]] = None
    timezone:          Optional[str] = None
    context_overrides: Optional[Dict[str, Any]] = None
    is_active:         Optional[bool] = None


class TemplateApplyBody(StrictRequestModel):
    name_override: Optional[str] = Field(None, min_length=1, max_length=120)


# ── Spec builders ────────────────────────────────────────────────────────


def _spec_from_body(body: WorkflowCreateBody):
    from core.dataflow.engine import DataFlowSpec, StageSpec
    stages = [
        StageSpec(
            stage_alias=s.stage_alias,
            stage_type=s.stage_type,
            seq=s.seq,
            predecessors=s.predecessors,
            config=s.config,
            retry_policy=s.retry_policy,
            timeout_seconds=s.timeout_seconds,
            on_failure=s.on_failure,
            on_failure_target=s.on_failure_target,
        )
        for s in body.stages
    ]
    return DataFlowSpec(
        name=body.name,
        stages=stages,
        description=body.description,
        trigger_type=body.trigger_type,
        trigger_config=body.trigger_config,
        default_context=body.default_context,
    )


# ── DataFlow CRUD ────────────────────────────────────────────────────────


@router.get("/api/dataflows")
async def list_workflows(
    name: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    """Phase 132.26 — workspace-scoped.  Non-super-admin users see
    DataFlows that are either workspace-less (global) OR in a workspace
    they belong to.  Super-admins see everything.
    """
    _require_deps()
    try:
        visible_ws_ids = _visible_workspace_ids_for_user(user)
    except WorkspaceScopeUnknown as exc:
        # A LIST that cannot be scoped is not an unscoped list.  503, with
        # the reason -- never "here is everything".
        raise HTTPException(status_code=503, detail=(
            f"workspace membership could not be read, so this list cannot be "
            f"scoped to what you may see: {exc}")) from exc
    return _engine.list_workflows(
        name=name, status=status,
        visible_workspace_ids=visible_ws_ids,
    )


class WorkspaceScopeUnknown(Exception):
    """The workspace memberships could not be READ.

    Distinct from "there are none", and it exists because the two led to
    opposite outcomes and shared a return value: :func:`_visible_workspace_ids_for_user`
    returned ``None`` for "bypass scoping" AND for "the lookup raised", and
    ``_enforce_dataflow_workspace_access`` reads ``None`` as ``# scoping
    bypassed``.  A transient database fault therefore turned the ONLY
    workspace boundary a service-key principal has into no boundary at all
    (2026-09-11).  Unknown is not empty, and it is certainly not "allow".
    """


def _visible_workspace_ids_for_user(user: dict) -> Optional[List[int]]:
    """Return the workspace IDs the user can see.

    * None  — bypass scoping (super_admin, or a principal with no username)
    * []    — no memberships; user only sees workspace-less DAGs
    * [..]  — list of workspace ids

    Raises :class:`WorkspaceScopeUnknown` when the memberships cannot be
    read.  It does NOT return ``None`` for that any more: ``None`` is the
    word for "this principal is not scoped", and a lookup failure is not
    a statement about the principal.
    """
    if user is None:
        return None
    role = (user.get("role") or "").lower()
    if role == "super_admin":
        return None
    username = user.get("username") or user.get("user") or user.get("name")
    if not username:
        return None
    try:
        ws_list = _db_manager.list_workspaces(username=username)
    except Exception as exc:
        logger.error("[dataflow] workspace lookup for %r failed: %s: %s -- "
                     "the scope is UNKNOWN, which is not the same as "
                     "unscoped", username, type(exc).__name__, exc)
        raise WorkspaceScopeUnknown(str(exc)) from exc
    return [int(w["id"]) for w in (ws_list or []) if w.get("id") is not None]


def _enforce_dataflow_workspace_access(user: dict, dataflow_id: int) -> None:
    """Phase 132.28 — guard mutating endpoints.  Raises HTTPException(403)
    when the DataFlow is workspace-scoped to a workspace the user is not
    a member of.  Global (workspace_id IS NULL) DataFlows are accessible
    to any admin.  super_admin always passes.
    """
    if user is None:
        return
    role = (user.get("role") or "").lower()
    if role == "super_admin":
        return
    try:
        visible = _visible_workspace_ids_for_user(user)
    except WorkspaceScopeUnknown as exc:
        # FAIL CLOSED.  This is the only workspace boundary a machine
        # principal has, and a 503 that says "ask again" is recoverable
        # where an unnoticed bypass is not.
        raise HTTPException(status_code=503, detail=(
            f"workspace membership could not be read, so access to DataFlow "
            f"{dataflow_id} cannot be decided: {exc}")) from exc
    if visible is None:
        return   # scoping bypassed
    try:
        from core.db.models import DataFlow
        with _db_manager.get_session(read_only=True) as session:
            row = session.query(DataFlow).filter(
                DataFlow.id == dataflow_id).first()
            if row is None:
                return   # let the route return its own 404
            ws_id = row.workspace_id
    except Exception as exc:
        logger.debug("[dataflow] workspace ACL lookup failed: %s", exc)
        return   # fail-open
    if ws_id is None:
        return   # global — accessible to any admin
    if int(ws_id) not in (visible or []):
        raise HTTPException(
            status_code=403,
            detail=f"DataFlow {dataflow_id} is scoped to a workspace you "
                    "are not a member of",
        )


@router.get("/api/dataflows/stage-types")
async def list_stage_types(
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    _require_deps()
    return _engine.registry.manifests()


@router.get("/api/dataflows/templates")
def list_templates(
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    """Template catalogue — DB-driven with lazy seed + hardcoded fallback
    (Phase 132.14 + 132.18) so the dropdown is never empty during setup.
    """
    _require_deps()
    from core.db.models import DataFlow, DataFlowStage

    def _query_db() -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        with _db_manager.get_session(read_only=True) as session:
            rows = (
                session.query(DataFlow)
                .filter(DataFlow.is_template == True)  # noqa: E712
                .filter(DataFlow.status != "archived")
                .order_by(DataFlow.template_category.asc(), DataFlow.name.asc())
                .all()
            )
            stage_counts: Dict[int, int] = {}
            if rows:
                from sqlalchemy import func
                sc = (
                    session.query(DataFlowStage.dataflow_id, func.count(DataFlowStage.id))
                    .filter(DataFlowStage.dataflow_id.in_([r.id for r in rows]))
                    .group_by(DataFlowStage.dataflow_id)
                    .all()
                )
                stage_counts = {wf_id: cnt for wf_id, cnt in sc}
            for r in rows:
                out.append({
                    "name":         r.name,
                    "description":  r.description or "",
                    "label":        r.template_label or r.name,
                    "category":     r.template_category or "general",
                    "stage_count":  stage_counts.get(r.id, 0),
                    "trigger_type": r.trigger_type or "manual",
                })
        return out

    # 1. DB
    try:
        result = _query_db()
        if result:
            return result
    except Exception as exc:
        logger.warning("[dataflow] templates DB query failed: %s", exc)
        result = []

    # 2. Lazy seed
    try:
        from core.dataflow.template_seeder import seed_built_in_templates
        seed_built_in_templates(_db_manager)
        result = _query_db()
        if result:
            return result
    except Exception as exc:
        logger.warning("[dataflow] templates lazy seed failed: %s", exc)

    # 3. Hardcoded fallback
    try:
        from core.dataflow.templates import list_templates as _list_tmpl
        from core.dataflow.template_seeder import _CATEGORIES, _LABELS
        return [{
            "name":         s["name"],
            "description":  s.get("description") or "",
            "label":        _LABELS.get(s["name"], s["name"]),
            "category":     _CATEGORIES.get(s["name"], "general"),
            "stage_count":  s.get("stage_count", 0),
            "trigger_type": s.get("trigger_type", "manual"),
        } for s in _list_tmpl()]
    except Exception:
        return []


def _unique_dataflow_name(desired: str) -> str:
    """Return the desired name if free, otherwise append _2, _3, ... up to
    a sensible cap.  Keeps clone-from-template flows ergonomic for teams
    — multiple users can clone the same template without colliding.
    """
    from core.db.models import DataFlow
    if _db_manager is None:
        return desired
    base = desired
    candidate = base
    n = 1
    with _db_manager.get_session(read_only=True) as session:
        while session.query(DataFlow).filter(DataFlow.name == candidate).first() is not None:
            n += 1
            if n > 999:
                # Pathological — caller picked an extremely common name.
                # Switch to timestamp suffix to guarantee uniqueness.
                import time
                candidate = f"{base}_{int(time.time())}"
                break
            candidate = f"{base}_{n}"
    return candidate


@router.get("/api/dataflows/names/check")
async def check_name_availability(
    name: str = Query(..., min_length=1, max_length=120),
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    """Inline name-uniqueness check for the UI.  Returns ``available: bool``
    plus a ``suggestion`` field with the next free name when taken so the
    create / template-clone forms can pre-fill it.
    """
    _require_deps()
    from core.db.models import DataFlow
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            taken = session.query(DataFlow).filter(DataFlow.name == name).first() is not None
        return {
            "name":       name,
            "available":  not taken,
            "suggestion": name if not taken else _unique_dataflow_name(name),
        }
    return await asyncio.to_thread(_do)


# ── Job types catalogue (ETL-friendly entry points) ─────────────────────


# Maps each user-facing job type to a default template + a list of the
# canonical step shape so the Simple Job form can pre-fill the steps a
# job_type involves.  Mirrors the structure of ETL/config/step_mapping.yaml
# but exposed as a versioned JSON resource so the UI can build forms
# from it without screen-scraping YAML.
_JOB_TYPES: Dict[str, Dict[str, Any]] = {
    "createJob": {
        "label":       "ETL — Starburst → Oracle",
        "description": ("Standard createJob ETL.  The starburst_to_oracle stage "
                          "has on-prem and on-cloud as a config option (set "
                          "`location` global param to 'onprem' or 'oncloud')."),
        "template":    "etl_createjob",
        "category":    "createJob",
    },
    "file": {
        "label":       "File delivery — Starburst → File → Deliver",
        "description": "Extract, consolidate, compress, CTL, deliver.",
        "template":    "etl_starburst_to_file",
        "category":    "file",
    },
    "sap_odata": {
        "label":       "SAP OData → File",
        "description": "Download SAP OData period data and deliver.",
        "template":    "etl_sap_odata_to_file",
        "category":    "sap_odata",
    },
    "oracle_to_s3": {
        "label":       "Oracle → S3",
        "description": ("Land an Oracle snapshot to S3.  Pick the output format "
                          "(parquet | iceberg) via the format global parameter."),
        "template":    "etl_oracle_to_s3",
        "category":    "cloud_landing",
    },
    "s3_to_oracle": {
        "label":       "S3 → Oracle",
        "description": ("Read S3 data into Oracle.  Pick the source format "
                          "(parquet | iceberg) via the format global parameter."),
        "template":    "etl_s3_to_oracle",
        "category":    "cloud_return",
    },
    "file_to_oracle": {
        "label":       "File → Oracle",
        "description": ("Bulk-load a CSV or Parquet file into Oracle.  Pick the "
                          "format (csv | parquet) via the format global parameter."),
        "template":    "etl_file_to_oracle",
        "category":    "file_ingest",
    },
    "s3_to_s3_transform": {
        "label":       "S3 → S3 transform",
        "description": "Landing → curated zone promotion.",
        "template":    "etl_s3_to_s3_transform",
        "category":    "cloud_transform",
    },
    "http_to_file": {
        "label":       "HTTP fetch → file",
        "description": "Daily REST snapshot capture.",
        "template":    "etl_http_to_file",
        "category":    "external",
    },
    "orchestrator_fanout": {
        "label":       "Orchestrator (fan-out)",
        "description": "Parent dataflow that fires several sub-dataflows in parallel.",
        "template":    "etl_orchestrator_fanout",
        "category":    "orchestration",
    },
    # ── Canonical step_mapping.yaml-aligned full DAGs ───────────────────
    "createjob_canonical": {
        "label":       "createJob — canonical (full DAG)",
        "description": ("Full createJob DAG mirroring step_mapping.yaml.createJob. "
                          "Set location=onprem|oncloud in global params to pick the route."),
        "template":    "etl_createjob_full_onprem",
        "category":    "canonical",
    },
    "file_canonical": {
        "label":       "file — canonical full pipeline",
        "description": "Full file-delivery DAG mirroring step_mapping.yaml.file.",
        "template":    "etl_file_canonical",
        "category":    "canonical",
    },
    "sap_odata_canonical": {
        "label":       "sap_odata — canonical full pipeline",
        "description": "Full SAP OData DAG mirroring step_mapping.yaml.sap_odata.",
        "template":    "etl_sap_odata_canonical",
        "category":    "canonical",
    },
    "file_spark": {
        "label":       "file — Spark engine",
        "description": ("File delivery via Spark for heavy extracts (>10M rows). "
                          "Set location=onprem|oncloud in global params."),
        "template":    "etl_starburst_to_file_spark_onprem",
        "category":    "canonical",
    },
}


@router.get("/api/dataflows/templates/{name}")
def get_template_detail(
    name: str,
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    """Return the FULL template definition.  DB-driven (Phase 132.14)
    with lazy seed + hardcoded fallback (Phase 132.18)."""
    _require_deps()
    from core.db.models import DataFlow, DataFlowStage

    def _query_db():
        with _db_manager.get_session(read_only=True) as session:
            wf = (
                session.query(DataFlow)
                .filter(DataFlow.name == name, DataFlow.is_template == True)  # noqa: E712
                .order_by(DataFlow.version.desc())
                .first()
            )
            if wf is None:
                return None
            stages = (
                session.query(DataFlowStage)
                .filter(DataFlowStage.dataflow_id == wf.id)
                .order_by(DataFlowStage.seq.asc())
                .all()
            )
            return {
                "name":            wf.name,
                "description":     wf.description or "",
                "label":           wf.template_label or wf.name,
                "category":        wf.template_category or "general",
                "trigger_type":    wf.trigger_type,
                "trigger_config":  wf.trigger_config or {},
                "default_context": wf.default_context or {},
                "stages":          [s.to_dict() for s in stages],
            }

    # 1. DB lookup
    try:
        detail = _query_db()
        if detail is not None:
            return detail
    except Exception as exc:
        logger.warning("[dataflow] template %r DB lookup failed: %s", name, exc)

    # 2. Lazy seed + retry
    try:
        from core.dataflow.template_seeder import seed_built_in_templates
        seed_built_in_templates(_db_manager)
        detail = _query_db()
        if detail is not None:
            return detail
    except Exception:
        pass

    # 3. Hardcoded fallback — direct from templates.py
    try:
        from core.dataflow.templates import get_template
        from core.dataflow.template_seeder import _CATEGORIES, _LABELS
        tmpl = get_template(name)
        if tmpl is not None:
            return {
                "name":            tmpl["name"],
                "description":     tmpl.get("description") or "",
                "label":           _LABELS.get(tmpl["name"], tmpl["name"]),
                "category":        _CATEGORIES.get(tmpl["name"], "general"),
                "trigger_type":    tmpl.get("trigger_type", "manual"),
                "trigger_config":  tmpl.get("trigger_config") or {},
                "default_context": tmpl.get("default_context") or {},
                "stages":          tmpl.get("stages") or [],
            }
    except Exception:
        pass

    raise HTTPException(status_code=404, detail=f"template {name!r} not found")


@router.get("/api/dataflows/job-types")
def list_job_types(
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    """Job-type catalogue.

    Phase 132.14 made this DB-driven (rows with is_template=True).
    Phase 132.18 adds lazy seeding + a hardcoded fallback so the
    dropdown is NEVER empty during initial setup:

    1. Query DB for template rows.
    2. If empty, try to seed_built_in_templates() once, then re-query.
    3. If STILL empty (DB error or seed failure), fall back to the
       hardcoded TEMPLATES dict so the admin can at least pick something.
    """
    _require_deps()
    from core.db.models import DataFlow

    def _query_db() -> List[Dict[str, Any]]:
        with _db_manager.get_session(read_only=True) as session:
            rows = (
                session.query(DataFlow)
                .filter(DataFlow.is_template == True)  # noqa: E712
                .filter(DataFlow.status != "archived")
                .order_by(DataFlow.template_category.asc(), DataFlow.name.asc())
                .all()
            )
            return [
                {
                    "id":          r.name,
                    "label":       r.template_label or r.name,
                    "description": r.description or "",
                    "template":    r.name,
                    "category":    r.template_category or "general",
                }
                for r in rows
            ]

    # 1. Normal DB-driven path
    try:
        result = _query_db()
        if result:
            return result
    except Exception as exc:
        logger.warning("[dataflow] job-types DB query failed: %s", exc)
        result = []

    # 2. Empty? Lazy-seed (handles "user ran new code but didn't restart"
    # case + brand-new install).
    try:
        from core.dataflow.template_seeder import seed_built_in_templates
        n = seed_built_in_templates(_db_manager)
        if n:
            logger.info("[dataflow] job-types triggered lazy seed of %d templates", n)
        result = _query_db()
        if result:
            return result
    except Exception as exc:
        logger.warning("[dataflow] lazy seed failed: %s", exc)

    # 3. Hardcoded fallback — never let the UI go empty
    try:
        from core.dataflow.templates import list_templates as _list_tmpl
        from core.dataflow.template_seeder import _CATEGORIES, _LABELS
        fallback = []
        for s in _list_tmpl():
            fallback.append({
                "id":          s["name"],
                "label":       _LABELS.get(s["name"], s["name"]),
                "description": s.get("description") or "",
                "template":    s["name"],
                "category":    _CATEGORIES.get(s["name"], "general"),
            })
        return fallback
    except Exception as exc:
        logger.warning("[dataflow] hardcoded fallback failed: %s", exc)
        return []


# ── Clone an existing DataFlow ──────────────────────────────────────────


class CloneBody(StrictRequestModel):
    name_override: Optional[str] = Field(None, min_length=1, max_length=120)


@router.post("/api/dataflows/{dataflow_id}/clone")
async def clone_dataflow(
    dataflow_id: int,
    body: CloneBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Clone an existing DataFlow (any version) into a new draft.

    Use case: a team member wants to start from a working DataFlow,
    tweak a few global params, and ship it as their own.  The clone is
    always created as a fresh draft v1 of a NEW name (auto-suffix if
    the requested name is taken).  Default_context (global params) and
    stage configs (per-step params) are deep-copied so the original
    is unaffected.
    """
    _require_deps()
    original = _engine.get_dataflow(dataflow_id)
    if original is None:
        raise HTTPException(status_code=404, detail=f"dataflow {dataflow_id} not found")

    desired_name = body.name_override or f"{original['name']}_copy"
    wf_name = _unique_dataflow_name(desired_name)

    from core.dataflow.engine import DataFlowSpec, StageSpec
    stages = [
        StageSpec(
            stage_alias=s["stage_alias"],
            stage_type=s["stage_type"],
            seq=s["seq"],
            predecessors=list(s.get("predecessors") or []),
            config=dict(s.get("config") or {}),
            retry_policy=dict(s.get("retry_policy") or {}),
            timeout_seconds=s.get("timeout_seconds"),
            on_failure=s.get("on_failure", "halt"),
            on_failure_target=s.get("on_failure_target"),
        )
        for s in (original.get("stages") or [])
    ]
    spec = DataFlowSpec(
        name=wf_name,
        stages=stages,
        description=(original.get("description") or "")
                      + f"\n(cloned from {original['name']} v{original['version']})",
        trigger_type=original.get("trigger_type") or "manual",
        trigger_config=original.get("trigger_config") or {},
        default_context=original.get("default_context") or {},
    )
    try:
        cloned = _engine.create_dataflow(spec, created_by=_username(user))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.clone",
           target=f"dataflow:{cloned['id']}",
           details={"source_id":   dataflow_id,
                      "source_name": original["name"],
                      "new_name":    wf_name})
    return cloned


@router.post("/api/dataflows/templates/{name}/apply")
def apply_template(
    name: str,
    body: TemplateApplyBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    # DB-driven template lookup (Phase 132.14) + hardcoded fallback (132.18)
    from core.db.models import DataFlow, DataFlowStage

    src_dict = None
    try:
        with _db_manager.get_session(read_only=True) as session:
            src = (
                session.query(DataFlow)
                .filter(DataFlow.name == name, DataFlow.is_template == True)  # noqa: E712
                .order_by(DataFlow.version.desc())
                .first()
            )
            if src is not None:
                src_stages = (
                    session.query(DataFlowStage)
                    .filter(DataFlowStage.dataflow_id == src.id)
                    .order_by(DataFlowStage.seq.asc())
                    .all()
                )
                src_dict = {
                    "name":            src.name,
                    "description":     src.description,
                    "trigger_type":    src.trigger_type,
                    "trigger_config":  src.trigger_config or {},
                    "default_context": src.default_context or {},
                    "stages":          [{
                        "stage_alias":       s.stage_alias,
                        "stage_type":        s.stage_type,
                        "seq":               s.seq,
                        "predecessors":      list(s.predecessors or []),
                        "config":            dict(s.config or {}),
                        "retry_policy":      dict(s.retry_policy or {}),
                        "timeout_seconds":   s.timeout_seconds,
                        "on_failure":        s.on_failure or "halt",
                        "on_failure_target": s.on_failure_target,
                    } for s in src_stages],
                }
    except Exception as exc:
        logger.warning("[dataflow] apply_template DB lookup failed: %s", exc)

    # Fallback to hardcoded TEMPLATES dict when DB has no seed yet.
    if src_dict is None:
        try:
            from core.dataflow.templates import get_template
            tmpl = get_template(name)
            if tmpl is not None:
                src_dict = {
                    "name":            tmpl["name"],
                    "description":     tmpl.get("description"),
                    "trigger_type":    tmpl.get("trigger_type", "manual"),
                    "trigger_config":  tmpl.get("trigger_config") or {},
                    "default_context": tmpl.get("default_context") or {},
                    "stages":          tmpl.get("stages") or [],
                }
        except Exception as exc:
            logger.warning("[dataflow] apply_template hardcoded lookup failed: %s", exc)

    if src_dict is None:
        raise HTTPException(status_code=404, detail=f"template {name!r} not found")

    desired_name = body.name_override or src_dict["name"]
    wf_name = _unique_dataflow_name(desired_name)
    from core.dataflow.engine import DataFlowSpec, StageSpec
    stages = [StageSpec(**s) for s in src_dict["stages"]]
    spec = DataFlowSpec(
        name=wf_name,
        stages=stages,
        description=src_dict.get("description"),
        trigger_type=src_dict.get("trigger_type", "manual"),
        trigger_config=src_dict.get("trigger_config"),
        default_context=src_dict.get("default_context"),
    )
    try:
        wf = _engine.create_workflow(spec, created_by=_username(user))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.template_apply",
           target=f"dataflow:{wf['id']}",
           details={"template": name, "name": wf_name})
    return wf


@router.post("/api/dataflows")
async def create_workflow(
    body: WorkflowCreateBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    try:
        wf = _engine.create_workflow(_spec_from_body(body), created_by=_username(user))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.create",
           target=f"dataflow:{wf['id']}",
           details={"name": wf["name"], "version": wf["version"]})
    return wf


@router.post("/api/dataflows/import")
async def import_workflow(
    body: Dict[str, Any],
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Import a dataflow definition from JSON.  Body must be the same
    shape as ``WorkflowCreateBody``.  If a dataflow with that name
    already exists, ``add_version`` is called instead of ``create_workflow``.
    """
    _require_deps()
    try:
        parsed = WorkflowCreateBody(**body)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"invalid dataflow body: {exc}")
    spec = _spec_from_body(parsed)
    try:
        existing = _engine.get_active_workflow_by_name(parsed.name) or \
                    next(iter(_engine.list_workflows(name=parsed.name)), None)
        if existing is None:
            wf = _engine.create_workflow(spec, created_by=_username(user))
            _audit(user, "dataflow.import_create",
                   target=f"dataflow:{wf['id']}",
                   details={"name": wf["name"]})
        else:
            wf = _engine.add_version(parsed.name, spec, created_by=_username(user))
            _audit(user, "dataflow.import_addversion",
                   target=f"dataflow:{wf['id']}",
                   details={"name": wf["name"], "version": wf["version"]})
        return wf
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ── Literal-path GET endpoints MUST be declared BEFORE the
#   /api/dataflows/{dataflow_id:int} catch-all below — FastAPI's typed
#   path matcher rejects "tags", "variables", etc. as non-integer and
#   returns 422 instead of falling through to a later literal route.
#   See Phase 132.25 route-ordering bugfix.


@router.get("/api/dataflows/_init-status")
async def dataflow_init_status(
    _user: dict = Depends(require_capability("dataflows.monitor")),   # 2026-10-18: it carries a traceback
) -> Dict[str, Any]:
    """Phase 132.30 — diagnostic endpoint.  When the dataflow subsystem
    fails to start on a pod, every endpoint 503s with a generic message.
    This route exposes the captured init error + traceback so operators
    can fix it without hunting pod logs."""
    from core.dataflow import get_init_error, get_init_traceback
    ok = _engine is not None and _dispatcher is not None
    return {
        "ok":            ok,
        "engine_ready":  _engine is not None,
        "dispatcher_ready": _dispatcher is not None,
        "scheduler_ready": _scheduler is not None,
        "db_manager_set": _db_manager is not None,
        "init_error":    get_init_error(),
        "init_traceback": get_init_traceback(),
    }


@router.get("/api/dataflows/tags")
async def list_all_tags_v2(
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    """Distinct list of tags across all non-archived DataFlows (Ops Grid filter)."""
    _require_deps()
    from core.db.models import DataFlow
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            rows = (
                session.query(DataFlow)
                .filter(DataFlow.status != "archived")
                .all()
            )
            seen: Dict[str, int] = {}
            for r in rows:
                for t in (r.tags or []):
                    seen[t] = seen.get(t, 0) + 1
        return {"tags": sorted(seen.keys()), "counts": seen}
    return await asyncio.to_thread(_do)


@router.get("/api/dataflows/notification-policies")
async def list_notification_policies_v2(
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    _require_deps()
    from core.db.models import DataFlowNotificationPolicy
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            rows = session.query(DataFlowNotificationPolicy).order_by(
                DataFlowNotificationPolicy.id.desc()).all()
            return [r.to_dict() for r in rows]
    return await asyncio.to_thread(_do)


@router.get("/api/dataflows/variables")
async def list_variables_v2(
    dataflow_id: Optional[int] = Query(None),
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    _require_deps()
    from core.db.models import DataFlowVariable
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            q = session.query(DataFlowVariable)
            if dataflow_id is not None:
                q = q.filter(DataFlowVariable.dataflow_id == dataflow_id)
            return [v.to_dict(include_value=True) for v in q.order_by(
                      DataFlowVariable.dataflow_id.asc().nullsfirst(),
                      DataFlowVariable.name.asc()).all()]
    return await asyncio.to_thread(_do)


@router.get("/api/dataflows/webhook-triggers")
async def list_webhook_triggers_v2(
    dataflow_id: Optional[int] = Query(None),
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    _require_deps()
    from core.db.models import DataFlowWebhookTrigger
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            q = session.query(DataFlowWebhookTrigger).order_by(
                DataFlowWebhookTrigger.id.desc())
            if dataflow_id is not None:
                q = q.filter(DataFlowWebhookTrigger.dataflow_id == dataflow_id)
            return [r.to_dict() for r in q.all()]
    return await asyncio.to_thread(_do)


from fastapi.responses import PlainTextResponse  # noqa: E402


@router.get("/api/dataflows/metrics", response_class=PlainTextResponse)
async def dataflow_metrics_v2(
    _user: dict = Depends(require_capability("dataflows.monitor")),   # 2026-10-18: nothing without a login
) -> Any:
    """Prometheus text-format metrics for the DataFlow engine.

    response_class=PlainTextResponse so the OpenAPI schema generator
    knows the content type; the function still returns a PlainTextResponse
    with the explicit Prometheus media type so scrapers see the version.
    Previously this was ``response_class=None`` which broke
    ``GET /openapi.json`` with ``AssertionError: A response class is
    needed to generate OpenAPI`` on recent FastAPI versions.
    """
    from core.dataflow.metrics import render_metrics
    _require_deps()
    body = render_metrics(_db_manager)
    return PlainTextResponse(content=body,
                               media_type="text/plain; version=0.0.4")


@router.get("/api/dataflows/approvals")
async def list_approvals(
    status: Optional[str] = Query(None, pattern="^(pending|approved|rejected|expired)$"),
    run_id: Optional[int] = Query(None),
    limit:  int           = Query(100, ge=1, le=500),
    user: dict = Depends(require_capability("dataflows.monitor")),
) -> List[Dict[str, Any]]:
    # SECURITY + ROUTING (2026-08-23):
    #   * Read is admin/support only (``require_admin_read``), matching the
    #     admin-only decide route and the admin-only client RoleGuard.  It was
    #     ``get_current_user`` — any authenticated viewer could enumerate every
    #     dataflow's approval rows including the ``description``/``payload``
    #     copied from arbitrary run-context keys.  ``status`` is vocabulary-
    #     validated so a mis-cased ``?status=Pending`` 422s instead of an empty
    #     200 that reads as "queue clear".
    #   * This route MUST stay ABOVE ``GET /api/dataflows/{dataflow_id}`` below.
    #     Starlette matches in declaration order and does not fall through on a
    #     path-param type mismatch, so declared after the ``{dataflow_id:int}``
    #     route the literal ``/approvals`` was shadowed and every request 422'd
    #     on int-parsing "approvals" — the list route was unreachable.
    _require_deps()
    from core.db.models import DataFlowApprovalRequest
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            q = session.query(DataFlowApprovalRequest)
            if status is not None:
                q = q.filter(DataFlowApprovalRequest.status == status)
            if run_id is not None:
                q = q.filter(DataFlowApprovalRequest.run_id == run_id)
            rows = (q.order_by(DataFlowApprovalRequest.created_at.desc())
                      .limit(limit).all())
            return [r.to_dict() for r in rows]
    return await asyncio.to_thread(_do)


@router.get("/api/dataflows/{dataflow_id}")
async def get_workflow(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    _require_deps()
    wf = _engine.get_workflow(dataflow_id)
    if wf is None:
        raise HTTPException(status_code=404, detail=f"dataflow {dataflow_id} not found")
    return wf


@router.get("/api/dataflows/{dataflow_id}/estimate")
async def estimate_dataflow_cost(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    """Phase 132.20 — pre-run cost estimate for the DAG.

    Sums each stage's ``estimate_cost(stage_config)`` to produce a wall-
    clock estimate (seconds) and a cents estimate.  Deliberately rough —
    the goal is "is this 30 seconds or 30 minutes?", not budgeting.
    """
    _require_deps()
    wf = _engine.get_workflow(dataflow_id)
    if wf is None:
        raise HTTPException(status_code=404, detail=f"dataflow {dataflow_id} not found")

    # Phase 132.21 — refine estimates using observed history.  When the
    # DataFlow has prior successful runs, median(actual_duration) wins
    # over the static class-level estimate (the static value is a fallback
    # for stages that have never run).
    observed: Dict[str, float] = {}
    def _history_lookup():
        out: Dict[str, float] = {}
        from core.db.models import DataFlowRun, DataFlowRunStage
        from statistics import median
        with _db_manager.get_session(read_only=True) as session:
            recent_runs = (
                session.query(DataFlowRun)
                .filter(DataFlowRun.dataflow_id == dataflow_id,
                         DataFlowRun.status == "succeeded")
                .order_by(DataFlowRun.id.desc()).limit(20).all()
            )
            run_ids = [r.id for r in recent_runs]
            if run_ids:
                stage_rows = (
                    session.query(DataFlowRunStage)
                    .filter(DataFlowRunStage.run_id.in_(run_ids),
                             DataFlowRunStage.status == "succeeded")
                    .all()
                )
                by_alias: Dict[str, List[float]] = {}
                for s in stage_rows:
                    if s.duration_seconds is not None and s.duration_seconds >= 0:
                        by_alias.setdefault(s.stage_alias, []).append(
                            float(s.duration_seconds))
                out = {a: median(d) for a, d in by_alias.items() if d}
        return out
    try:
        observed = await asyncio.to_thread(_history_lookup)
    except Exception as _hist_exc:
        logger.debug("[estimate] history lookup skipped: %s", _hist_exc)

    total_seconds = 0
    total_cents   = 0
    per_stage: List[Dict[str, Any]] = []
    for s in wf.get("stages", []):
        st_name = s.get("stage_type")
        alias   = s.get("stage_alias")
        cfg = s.get("config") or {}
        cls = None
        try:
            cls = _engine.registry.get(st_name) if hasattr(_engine, "registry") else None
        except Exception:
            cls = None
        try:
            est = cls.estimate_cost(cfg) if cls is not None else {"seconds": 5, "cents": 0}
        except Exception:
            est = {"seconds": 5, "cents": 0}
        static_seconds = int(est.get("seconds") or 0)
        cents          = int(est.get("cents") or 0)
        observed_dur   = observed.get(alias)
        seconds        = int(round(observed_dur)) if observed_dur is not None else static_seconds
        total_seconds += seconds
        total_cents   += cents
        per_stage.append({
            "stage_alias":      alias,
            "stage_type":       st_name,
            "seconds":          seconds,
            "static_seconds":   static_seconds,
            "observed_seconds": round(observed_dur, 2) if observed_dur is not None else None,
            "cents":            cents,
        })
    return {
        "dataflow_id":   dataflow_id,
        "stage_count":   len(per_stage),
        "total_seconds": total_seconds,
        "total_cents":   total_cents,
        "uses_history":  bool(observed),
        "per_stage":     per_stage,
    }


@router.post("/api/dataflows/{dataflow_id}/export")
async def export_workflow(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.author")),
) -> Dict[str, Any]:
    """Return a JSON-importable representation of the dataflow."""
    _require_deps()
    wf = _engine.get_workflow(dataflow_id)
    if wf is None:
        raise HTTPException(status_code=404, detail=f"dataflow {dataflow_id} not found")
    stage_keys = {
        "stage_alias", "stage_type", "seq", "predecessors", "config",
        "retry_policy", "timeout_seconds", "on_failure", "on_failure_target",
    }
    return {
        "name":            wf["name"],
        "description":     wf["description"],
        "trigger_type":    wf["trigger_type"],
        "trigger_config":  wf["trigger_config"],
        "default_context": wf["default_context"],
        "stages": [{k: s[k] for k in stage_keys if k in s} for s in wf["stages"]],
    }


@router.post("/api/dataflows/{dataflow_id}/promote")
async def promote_workflow(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    _enforce_dataflow_workspace_access(user, dataflow_id)
    try:
        wf = _engine.promote(dataflow_id)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.promote", target=f"dataflow:{dataflow_id}",
           details={"name": wf["name"], "version": wf["version"]})
    return wf


@router.post("/api/dataflows/{dataflow_id}/archive")
async def archive_workflow(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    _enforce_dataflow_workspace_access(user, dataflow_id)
    try:
        wf = _engine.archive(dataflow_id)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.archive", target=f"dataflow:{dataflow_id}",
           details={"name": wf["name"], "version": wf["version"]})
    return wf


@router.post("/api/dataflows/{dataflow_id}/versions")
async def add_dataflow_version(
    dataflow_id: int,
    body: WorkflowCreateBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    wf = _engine.get_workflow(dataflow_id)
    if wf is None:
        raise HTTPException(status_code=404, detail=f"dataflow {dataflow_id} not found")
    if body.name != wf["name"]:
        raise HTTPException(
            status_code=400,
            detail="body.name must match the dataflow's existing name",
        )
    try:
        new_wf = _engine.add_version(name=wf["name"], spec=_spec_from_body(body),
                                       created_by=_username(user))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.add_version", target=f"dataflow:{new_wf['id']}",
           details={"name": new_wf["name"], "version": new_wf["version"]})
    return new_wf


# ── Run lifecycle ────────────────────────────────────────────────────────


def _submit_run(run_id: int) -> None:
    if _dispatch_executor is None or _dispatcher is None:
        threading.Thread(target=_dispatcher.run, args=(run_id,), daemon=True,
                          name=f"wf-run-{run_id}").start()
        return
    _dispatch_executor.submit(_safe_run, run_id)


def _safe_run(run_id: int) -> None:
    try:
        _dispatcher.run(run_id)
    except Exception as exc:
        logger.error("[workflow_api] dispatcher.run(%d) crashed: %s",
                     run_id, exc, exc_info=True)


def _run_starter(request: Request) -> dict:
    """Who may start a run: an admin (the rule since Phase 132), or -- the
    ONE machine path, opt-in -- an ``X-API-Key`` principal.

    2026-09-10 (Clockwork completion round).  Clockwork's ``qs_api`` task
    calls this route as its pod with a service key; the route was
    ``require_admin`` and an API-key principal is never admin-tier, so the
    action could be authored and never worked.  Mirrors the feed trigger's
    gate, minus its legacy hole: ``dataflows.allow_external_triggers``
    must be on AND the key's id must be listed in
    ``dataflows.external_trigger_api_key_ids`` -- an EMPTY list admits
    nobody, never "any valid key".  A denied key is audited.  The
    principal keeps role ``api_consumer``: the workspace ACL below sees no
    memberships for it, so only a GLOBAL dataflow runs; ``run_as`` is
    refused for it in the route.  A key with the header but the gate off
    is 403 with the gate named (Clockwork reads 401/403 as a definite
    refusal; a 503 would read as "the run may exist").
    """
    if request.headers.get("X-API-Key", "").strip():
        from core.config import get as _cfg_get
        if not bool(_cfg_get("dataflows", "allow_external_triggers", False)):
            raise HTTPException(
                status_code=403,
                detail="External dataflow triggers are not enabled on this instance "
                       "(dataflows.allow_external_triggers)")
        user = get_api_key_user(request)          # 401 on a bad/inactive/expired key
        raw = _cfg_get("dataflows", "external_trigger_api_key_ids", None)
        allowed = _allowed_key_ids(raw)
        if allowed is None:
            # 2026-09-11 audit: a STRING here was iterated per character --
            # "12" admitted keys 1 and 2.  A shape this gate cannot read
            # admits nobody, and says so (fail closed, audited).
            _audit(user, "dataflow.external_trigger_denied",
                   details={"reason": "external_trigger_allowlist_unreadable",
                            "shape": type(raw).__name__})
            raise HTTPException(
                status_code=403,
                detail="dataflows.external_trigger_api_key_ids cannot be read as a list of key ids "
                       f"(it is a {type(raw).__name__}); no service key is admitted until it is "
                       "a JSON list of integers")
        if int(user.get("api_key_id") or -1) not in allowed:
            _audit(user, "dataflow.external_trigger_denied",
                   details={"reason": "api_key_not_allowlisted"})
            raise HTTPException(
                status_code=403,
                detail="This API key is not permitted to start dataflow runs "
                       "(dataflows.external_trigger_api_key_ids)")
        return user
    return require_admin(get_current_user(request))


def _allowed_key_ids(raw: Any) -> Optional[Set[int]]:
    """``dataflows.external_trigger_api_key_ids`` as a set of key ids, or
    ``None`` when its SHAPE cannot be read -- which the caller treats as
    "admit nobody".  Accepted: absent (``None``, an empty allow-list) and a
    list / tuple / set whose every element is an ``int`` or a digit string.
    Refused: a bare string (``"12"`` iterated per character is ``{1, 2}``),
    a mapping, a bool, a float, or any element that is not an integer --
    the allow-list is a security gate and a gate half-read is a gate open
    to whoever the misread lets through."""
    if raw is None:
        return set()
    if isinstance(raw, (str, bytes, bytearray, dict, bool, int, float)):
        return None
    try:
        items = list(raw)
    except TypeError:
        return None
    out: Set[int] = set()
    for x in items:
        if isinstance(x, bool):
            return None
        if isinstance(x, int):
            out.add(x)
        elif isinstance(x, str) and x.strip().isdigit():
            out.add(int(x.strip()))
        else:
            return None
    return out


@router.post("/api/dataflows/{dataflow_name}/runs")
async def start_run(
    dataflow_name: str,
    body: RunStartBody,
    user: dict = Depends(require_capability("dataflows.run", identity=_run_starter)),
) -> Dict[str, Any]:
    _require_deps()
    if user.get("auth_method") == "api_key" and body.run_as:
        raise HTTPException(status_code=403,
                            detail="run_as (impersonation) is not available to a service key")
    if user.get("auth_method") == "api_key" and body.allow_paused:
        # 2026-09-11 audit: an allow-listed key could send allow_paused and
        # bypass an admin's pause.  A pause is a human's decision; a machine
        # principal may not override it.  Refused, not ignored: Clockwork
        # reads a 403 as a definite refusal, whereas a silently dropped flag
        # would look like a run that did not start for no reason.
        raise HTTPException(status_code=403,
                            detail="allow_paused is not available to a service key: a pause is "
                                   "set by a person and only a person may run past it")
    actor = _username(user) or "api"
    # Phase 132.28 — workspace ACL.  Resolve name → active workflow id
    # for the gate; let start_run raise its own error if not found.
    _active_wf = _engine.get_active_workflow_by_name(dataflow_name)
    if _active_wf is not None:
        _enforce_dataflow_workspace_access(user, _active_wf["id"])
    try:
        run = _engine.start_run(
            dataflow_name=dataflow_name,
            context=body.context,
            trigger_payload=body.trigger_payload,
            triggered_by=actor,
            run_as=(body.run_as or None),
            allow_paused=bool(body.allow_paused),
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _submit_run(run["id"])
    _audit(user, "dataflow.run_start", target=f"run:{run['id']}",
           details={"dataflow": dataflow_name,
                     "run_as": body.run_as,
                     "allow_paused": bool(body.allow_paused)})
    return run


# ── Phase 132.20 — pause / resume + SLA admin controls ───────────────────


@router.post("/api/dataflows/{dataflow_id}/pause")
async def pause_dataflow(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Soft-pause: suspends scheduler firings AND blocks new manual runs.
    Different from archive — the DataFlow remains in the catalogue and
    can be resumed.  In-flight runs are not affected.
    """
    _require_deps()
    _enforce_dataflow_workspace_access(user, dataflow_id)
    try:
        wf = _engine.set_paused(dataflow_id, True)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.pause", target=f"dataflow:{dataflow_id}",
           details={"name": wf["name"]})
    return wf


@router.post("/api/dataflows/{dataflow_id}/resume")
async def resume_dataflow(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    _enforce_dataflow_workspace_access(user, dataflow_id)
    try:
        wf = _engine.set_paused(dataflow_id, False)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.resume", target=f"dataflow:{dataflow_id}",
           details={"name": wf["name"]})
    return wf


@router.patch("/api/dataflows/{dataflow_id}/sla")
async def set_dataflow_sla(
    dataflow_id: int,
    body: SetSlaBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Set or clear the per-run wall-clock SLA budget in seconds.  Pass
    sla_seconds=null to clear.  Only affects new runs."""
    _require_deps()
    try:
        wf = _engine.set_sla(dataflow_id, body.sla_seconds)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.set_sla", target=f"dataflow:{dataflow_id}",
           details={"name": wf["name"], "sla_seconds": body.sla_seconds})
    return wf


@router.patch("/api/dataflows/{dataflow_id}/workspace")
async def set_dataflow_workspace(
    dataflow_id: int,
    body: SetWorkspaceBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Phase 132.26 — assign / clear the DataFlow's workspace scope.
    Null = global (visible to everyone).  Set = visible only to members
    of that workspace (plus super_admin)."""
    _require_deps()
    try:
        wf = _engine.set_workspace(dataflow_id, body.workspace_id)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.set_workspace",
           target=f"dataflow:{dataflow_id}",
           details={"name": wf["name"], "workspace_id": body.workspace_id})
    return wf


@router.patch("/api/dataflows/{dataflow_id}/max-run-seconds")
async def set_dataflow_max_run_seconds(
    dataflow_id: int,
    body: SetMaxRunSecondsBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Phase 132.25 — set/clear the HARD timeout.  When the run's
    wall-clock exceeds this, the dispatcher cancels it.  Distinct from
    sla_seconds which is a soft flag.  Pass null/0 to clear."""
    _require_deps()
    try:
        wf = _engine.set_max_run_seconds(dataflow_id, body.max_run_seconds)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _audit(user, "dataflow.set_max_run_seconds",
           target=f"dataflow:{dataflow_id}",
           details={"name": wf["name"],
                     "max_run_seconds": body.max_run_seconds})
    return wf


@router.get("/api/dataflow-runs")
async def list_runs(
    dataflow_id: Optional[int] = Query(None),
    status:      Optional[str] = Query(None),
    limit:       int           = Query(50, ge=1, le=500),
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    _require_deps()
    from core.db.models import DataFlowRun
    # 2026-06-03 — high-frequency Ops grid poll (fires every few
    # seconds from the dashboard) — wrap sync session in to_thread to
    # keep the event loop free.  Audit catch.
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            q = session.query(DataFlowRun)
            if dataflow_id is not None:
                q = q.filter(DataFlowRun.dataflow_id == dataflow_id)
            if status is not None:
                q = q.filter(DataFlowRun.status == status)
            rows = (q.order_by(DataFlowRun.created_at.desc())
                      .limit(limit).all())
            return [r.to_dict() for r in rows]
    return await asyncio.to_thread(_do)


@router.get("/api/dataflow-runs/{run_id}")
async def get_run(
    run_id: int,
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowRun, DataFlowRunStage
    # 2026-06-03 — wrap in to_thread; sync session was on the loop.
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            if run is None:
                return {"__not_found__": True}
            stages = (
                session.query(DataFlowRunStage)
                .filter(DataFlowRunStage.run_id == run_id)
                .order_by(DataFlowRunStage.seq.asc())
                .all()
            )
            d = run.to_dict()
            d["stages"] = [s.to_dict() for s in stages]
            return d
    result = await asyncio.to_thread(_do)
    if result.get("__not_found__"):
        raise HTTPException(status_code=404, detail=f"run {run_id} not found")
    return result


@router.post("/api/dataflow-runs/{run_id}/cancel")
async def cancel_run(
    run_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    ok = _engine.cancel_run(run_id, by=_username(user) or "api")
    if not ok:
        raise HTTPException(status_code=404, detail=f"run {run_id} not found")
    _audit(user, "dataflow.run_cancel", target=f"run:{run_id}")
    return {"run_id": run_id, "cancelled": True}


@router.post("/api/dataflow-runs/{run_id}/resume")
async def resume_run(
    run_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    _submit_resume(run_id)
    _audit(user, "dataflow.run_resume", target=f"run:{run_id}")
    return {"run_id": run_id, "resumed": True}


def _submit_resume(run_id: int) -> None:
    if _dispatch_executor is None:
        threading.Thread(target=_dispatcher.resume, args=(run_id,), daemon=True,
                          name=f"wf-resume-{run_id}").start()
        return
    _dispatch_executor.submit(_safe_resume, run_id)


def _safe_resume(run_id: int) -> None:
    try:
        _dispatcher.resume(run_id)
    except Exception as exc:
        logger.error("[workflow_api] dispatcher.resume(%d) crashed: %s",
                     run_id, exc, exc_info=True)


@router.post("/api/dataflow-runs/{run_id}/rerun-stage")
def rerun_stage(
    run_id: int,
    body: RerunStageBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowRunStage
    from core.dataflow.base import IDEMPOTENT_UNSAFE
    with _db_manager.get_session(read_only=True) as session:
        row = (
            session.query(DataFlowRunStage)
            .filter(DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.stage_alias == body.stage_alias)
            .first()
        )
        if row is None:
            raise HTTPException(
                status_code=404,
                detail=f"stage {body.stage_alias!r} not found on run {run_id}",
            )
        stage_type = row.stage_type
    try:
        cls = _engine.registry.get(stage_type)
        if cls.IDEMPOTENCY == IDEMPOTENT_UNSAFE and not body.force_unsafe:
            raise HTTPException(
                status_code=409,
                detail=(
                    f"stage_type {stage_type!r} is unsafe to rerun "
                    f"(may double-send notifications etc.); pass force_unsafe=true"
                ),
            )
    except HTTPException:
        raise
    except Exception as _idem_exc:
        # If the stage class isn't found, fall through — dispatcher will
        # surface a clearer error.  Logging at debug so we don't spam.
        logger.debug("[workflow_api] idempotency probe failed: %s", _idem_exc)
    _submit_rerun(run_id, body.stage_alias)
    _audit(user, "dataflow.rerun_stage", target=f"run:{run_id}",
           details={"stage_alias": body.stage_alias, "force_unsafe": body.force_unsafe})
    return {"run_id": run_id, "stage_alias": body.stage_alias, "rerun_started": True}


def _submit_rerun(run_id: int, alias: str) -> None:
    if _dispatch_executor is None:
        threading.Thread(target=_dispatcher.rerun_stage, args=(run_id, alias),
                          daemon=True, name=f"wf-rerun-{run_id}").start()
        return
    _dispatch_executor.submit(_safe_rerun, run_id, alias)


def _safe_rerun(run_id: int, alias: str) -> None:
    try:
        _dispatcher.rerun_stage(run_id, alias)
    except Exception as exc:
        logger.error("[workflow_api] dispatcher.rerun_stage(%d,%s) crashed: %s",
                     run_id, alias, exc, exc_info=True)


# ── Schedules ────────────────────────────────────────────────────────────


@router.get("/api/dataflows/schedules")
async def list_schedules(
    dataflow_id: Optional[int] = Query(None),
    is_active:   Optional[bool] = Query(None),
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    _require_deps()
    from core.db.models import DataFlowSchedule
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            q = session.query(DataFlowSchedule)
            if dataflow_id is not None:
                q = q.filter(DataFlowSchedule.dataflow_id == dataflow_id)
            if is_active is not None:
                q = q.filter(DataFlowSchedule.is_active == is_active)
            return [s.to_dict() for s in q.order_by(DataFlowSchedule.id.asc()).all()]
    return await asyncio.to_thread(_do)


@router.post("/api/dataflows/schedules")
def create_schedule(
    body: ScheduleCreateBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    if not body.cron_expression and not body.calendar_rule:
        raise HTTPException(
            status_code=400,
            detail="schedule needs either cron_expression or calendar_rule",
        )
    from core.db.models import DataFlow, DataFlowSchedule
    from core.dataflow.cron_utils import next_fire_at
    from core.dataflow.calendar_trigger import next_calendar_fire_at
    with _db_manager.get_session() as session:
        wf = session.query(DataFlow).filter(DataFlow.id == body.dataflow_id).first()
        if wf is None:
            raise HTTPException(status_code=404, detail=f"dataflow {body.dataflow_id} not found")
        try:
            if body.cron_expression:
                nra = next_fire_at(body.cron_expression, tz_name=body.timezone)
            else:
                nra = next_calendar_fire_at(body.calendar_rule or {},
                                             tz_name=body.timezone,
                                             db_manager=_db_manager)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"invalid schedule: {exc}")
        sched = DataFlowSchedule(
            dataflow_id=body.dataflow_id,
            name=body.name,
            cron_expression=body.cron_expression or "",
            calendar_rule=body.calendar_rule,
            timezone=body.timezone,
            context_overrides=body.context_overrides or {},
            is_active=body.is_active,
            next_run_at=nra,
            created_by=_username(user),
        )
        session.add(sched)
        session.flush()
        session.refresh(sched)
        out = sched.to_dict()
    _audit(user, "dataflow.schedule_create", target=f"schedule:{out['id']}",
           details={"dataflow_id": body.dataflow_id, "name": body.name})
    return out


@router.patch("/api/dataflows/schedules/{schedule_id}")
def update_schedule(
    schedule_id: int,
    body: ScheduleUpdateBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowSchedule
    from core.dataflow.cron_utils import next_fire_at
    from core.dataflow.calendar_trigger import next_calendar_fire_at
    with _db_manager.get_session() as session:
        sched = session.query(DataFlowSchedule).filter(
            DataFlowSchedule.id == schedule_id
        ).first()
        if sched is None:
            raise HTTPException(status_code=404, detail=f"schedule {schedule_id} not found")
        if body.cron_expression is not None:
            try:
                sched.next_run_at = next_fire_at(
                    body.cron_expression, tz_name=(body.timezone or sched.timezone),
                )
            except Exception as exc:
                raise HTTPException(status_code=400, detail=f"invalid cron expression: {exc}")
            sched.cron_expression = body.cron_expression
            sched.calendar_rule = None
        if body.calendar_rule is not None:
            try:
                sched.next_run_at = next_calendar_fire_at(
                    body.calendar_rule,
                    tz_name=(body.timezone or sched.timezone),
                    db_manager=_db_manager,
                )
            except Exception as exc:
                raise HTTPException(status_code=400, detail=f"invalid calendar rule: {exc}")
            sched.calendar_rule = body.calendar_rule
            sched.cron_expression = ""
        if body.timezone is not None:
            sched.timezone = body.timezone
        if body.context_overrides is not None:
            sched.context_overrides = body.context_overrides
        if body.is_active is not None:
            sched.is_active = body.is_active
        session.flush()
        session.refresh(sched)
        out = sched.to_dict()
    _audit(user, "dataflow.schedule_update", target=f"schedule:{schedule_id}")
    return out


@router.delete("/api/dataflows/schedules/{schedule_id}")
def delete_schedule(
    schedule_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowSchedule
    with _db_manager.get_session() as session:
        sched = session.query(DataFlowSchedule).filter(
            DataFlowSchedule.id == schedule_id
        ).first()
        if sched is None:
            raise HTTPException(status_code=404, detail=f"schedule {schedule_id} not found")
        session.delete(sched)
    _audit(user, "dataflow.schedule_delete", target=f"schedule:{schedule_id}")
    return {"schedule_id": schedule_id, "deleted": True}


# ── Human approvals ─────────────────────────────────────────────────────


class ApprovalDecisionBody(StrictRequestModel):
    decision:      str            = Field(..., pattern="^(approve|reject)$")
    decision_notes: Optional[str] = None

# NOTE: the ``GET /api/dataflows/approvals`` LIST route is deliberately
# registered EARLIER in this file (just above ``GET /api/dataflows/{dataflow_id}``).
# Starlette matches routes in declaration order and does NOT fall through on a
# path-param TYPE mismatch, so a literal ``/approvals`` declared AFTER the
# ``{dataflow_id:int}`` route is shadowed — "approvals" fails int-parsing and
# the request 422s before ever reaching this handler.  Keep the list route
# above the parametrised one.


@router.post("/api/dataflows/approvals/{approval_id}/decide")
def decide_approval(
    approval_id: int,
    body: ApprovalDecisionBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from datetime import datetime, timezone
    from core.db.models import DataFlowApprovalRequest
    with _db_manager.get_session() as session:
        row = (
            session.query(DataFlowApprovalRequest)
            .filter(DataFlowApprovalRequest.id == approval_id)
            .first()
        )
        if row is None:
            raise HTTPException(status_code=404, detail=f"approval {approval_id} not found")
        if row.status != "pending":
            raise HTTPException(
                status_code=409,
                detail=f"approval {approval_id} already {row.status}",
            )
        # SECURITY / separation of duties (2026-08-23): a human-approval
        # stage exists precisely to force a SECOND human, yet the requester
        # was never compared to the decider — the admin who triggered the run
        # could approve their own gate, making the control decorative.  Block
        # self-approval by default (a CORRECTNESS GATE fails, it does not
        # throttle).  A single-operator deployment can opt out via
        # ``dataflows.allow_self_approval=true`` so the gate cannot deadlock a
        # one-admin install.  Rejecting your own request stays allowed — you
        # may always withdraw.
        if body.decision == "approve":
            from core import config as _cfg
            _allow_self = bool(_cfg.get("dataflows", "allow_self_approval", False))
            _requester = str(row.requested_by or "").strip().lower()
            _decider = str(_username(user) or "").strip().lower()
            if not _allow_self and _requester and _decider and _requester == _decider:
                raise HTTPException(
                    status_code=403,
                    detail=(
                        "You requested this approval; a different approver "
                        "must decide it (separation of duties). Set "
                        "dataflows.allow_self_approval=true to permit "
                        "self-approval on single-operator installs."
                    ),
                )
        row.status = "approved" if body.decision == "approve" else "rejected"
        row.decided_by = _username(user)
        row.decision_notes = body.decision_notes
        row.decided_at = datetime.now(timezone.utc)
        session.flush()
        session.refresh(row)
        out = row.to_dict()
    _audit(user, f"dataflow.approval_{body.decision}",
           target=f"approval:{approval_id}",
           details={"run_id": out["run_id"], "stage_alias": out["stage_alias"]})
    return out


# ── Custom stage types (DB-driven, no code change) ──────────────────────


class CustomStageTypeBody(StrictRequestModel):
    name:          str = Field(..., min_length=1, max_length=80,
                                 pattern=r"^[a-z][a-z0-9_]*$")
    category:      str = Field(...,
                                 pattern=r"^(source|transform|sink|pipeline|control|quality|notify)$")
    description:   Optional[str] = None
    etl_module:    str = Field(..., min_length=1, max_length=255)
    etl_class:     str = Field(..., min_length=1, max_length=120)
    config_schema: Optional[Dict[str, Any]] = None
    idempotency:   str = Field("configured",
                                 pattern=r"^(safe|overwrite|configured|unsafe)$")
    is_active:     bool = True


@router.get("/api/dataflows/custom-stage-types")
async def list_custom_stage_types(
    is_active: Optional[bool] = Query(None),
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    _require_deps()
    from core.db.models import DataFlowCustomStageType
    def _do():
        from core.config_active import active_clause
        with _db_manager.get_session(read_only=True) as session:
            # 2026-10-30: a deleted stage type is SWITCHED OFF and listed
            # only under Admin -> Switched off; ``is_active=false`` here
            # therefore lists nothing (kept for its old callers)
            q = session.query(DataFlowCustomStageType).filter(
                active_clause(DataFlowCustomStageType))
            if is_active is False:
                return []
            return [r.to_dict() for r in q.order_by(
                DataFlowCustomStageType.category.asc(),
                DataFlowCustomStageType.name.asc(),
            ).all()]
    return await asyncio.to_thread(_do)


@router.post("/api/dataflows/custom-stage-types")
def create_custom_stage_type(
    body: CustomStageTypeBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Create a new DB-driven stage type.  Will be live in the registry
    after the next subsystem init (typically a backend restart).
    """
    _require_deps()
    from core.db.models import DataFlowCustomStageType
    with _db_manager.get_session() as session:
        existing = (
            session.query(DataFlowCustomStageType)
            .filter(DataFlowCustomStageType.name == body.name)
            .first()
        )
        if existing is not None:
            _refuse_stage_name_taken(existing, body.name)
        # Light-weight import check so admins find typos at create time,
        # not at run time.
        try:
            import importlib
            mod = importlib.import_module(body.etl_module)
            if not hasattr(mod, body.etl_class):
                raise AttributeError(
                    f"class {body.etl_class!r} not found in module")
        except Exception as exc:
            raise HTTPException(
                status_code=400,
                detail=f"cannot resolve {body.etl_module}.{body.etl_class}: {exc}",
            )
        row = DataFlowCustomStageType(
            name=body.name, category=body.category,
            description=body.description,
            etl_module=body.etl_module, etl_class=body.etl_class,
            config_schema=body.config_schema or {},
            idempotency=body.idempotency,
            is_active=body.is_active,
            created_by=_username(user),
        )
        session.add(row)
        session.flush()
        session.refresh(row)
        # Hot-register so it's immediately usable without a restart
        try:
            from core.dataflow.template_seeder import register_custom_stage_types
            register_custom_stage_types(_db_manager, _engine.registry)
            # Also sync the catalogue row so the UI sees it
            _engine.registry.sync_to_db(_db_manager)
        except Exception as exc:
            logger.warning("[custom_stage_types] hot-register failed: %s", exc)
        _audit(user, "dataflow.custom_stage_create",
               target=f"stage:{row.id}", details={"name": body.name})
        return row.to_dict()


@router.patch("/api/dataflows/custom-stage-types/{stage_id}")
def update_custom_stage_type(
    stage_id: int,
    body: CustomStageTypeBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.config_active import active_clause
    from core.db.models import DataFlowCustomStageType
    with _db_manager.get_session() as session:
        row = session.query(DataFlowCustomStageType).filter(
            DataFlowCustomStageType.id == stage_id,
            active_clause(DataFlowCustomStageType),
        ).first()
        if row is None:
            raise HTTPException(status_code=404, detail=f"stage {stage_id} not found")
        if body.name != row.name:
            other = session.query(DataFlowCustomStageType).filter(
                DataFlowCustomStageType.name == body.name,
                DataFlowCustomStageType.id != stage_id).first()
            if other is not None:
                _refuse_stage_name_taken(other, body.name)
        # Don't allow renaming a stage that's been used in existing
        # DataFlows — old definitions would reference the stale name.
        if body.name != row.name:
            from core.db.models import DataFlowStage
            in_use = session.query(DataFlowStage).filter(
                DataFlowStage.stage_type == row.name,
            ).first()
            if in_use is not None:
                raise HTTPException(
                    status_code=409,
                    detail=f"stage {row.name!r} is in use; archive + recreate instead of renaming",
                )
        row.name        = body.name
        row.category    = body.category
        row.description = body.description
        row.etl_module  = body.etl_module
        row.etl_class   = body.etl_class
        row.config_schema = body.config_schema or {}
        row.idempotency = body.idempotency
        row.is_active   = body.is_active
        session.flush()
        session.refresh(row)
        _audit(user, "dataflow.custom_stage_update",
               target=f"stage:{stage_id}")
        return row.to_dict()


@router.delete("/api/dataflows/custom-stage-types/{stage_id}")
def delete_custom_stage_type(
    stage_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    # 2026-10-30 (owner): config rows are SWITCHED OFF, never erased.  It
    # already was for a stage type in use (existing DataFlows keep rendering
    # its name); an unused one is now switched off too, so Admin -> Switched
    # off can bring it back.  Not registered at the next start-up
    # (``register_custom_stage_types``); this process keeps the class it
    # registered until then, as it always did after a delete.
    from core.config_active import active_clause, switch_off, switched_off_message
    from core.db.models import DataFlowCustomStageType, DataFlowStage
    with _db_manager.get_session() as session:
        row = session.query(DataFlowCustomStageType).filter(
            DataFlowCustomStageType.id == stage_id,
            active_clause(DataFlowCustomStageType),
        ).first()
        if row is None:
            raise HTTPException(status_code=404, detail=f"stage {stage_id} not found")
        in_use = session.query(DataFlowStage).filter(
            DataFlowStage.stage_type == row.name,
        ).first()
        switch_off(row)
        session.flush()
        if in_use is not None:
            _audit(user, "dataflow.custom_stage_deactivate",
                   target=f"stage:{stage_id}",
                   details={"name": row.name, "reason": "in_use"})
            return {"id": stage_id, "deleted": False, "deactivated": True,
                    "detail": switched_off_message("custom dataflow stage")}
    _audit(user, "dataflow.custom_stage_delete", target=f"stage:{stage_id}")
    return {"id": stage_id, "deleted": True, "deactivated": True,
            "detail": switched_off_message("custom dataflow stage")}


def _refuse_stage_name_taken(other: Any, name: str) -> None:
    """409 either way; a switched-off stage type says how to get it back."""
    from core.config_active import is_on, name_held_message
    if not is_on(other):
        raise HTTPException(status_code=409,
                            detail=name_held_message("custom dataflow stage", name))
    raise HTTPException(status_code=409, detail=f"stage type {name!r} already exists")


def _on_custom_stage_type_switched_on(row: Dict[str, Any], user: dict) -> Optional[str]:
    """Switch on = live again without a restart, as a create is: register
    the bridge class and sync the catalogue row the UI reads."""
    if _db_manager is None or _engine is None:
        return "It is registered at the next start-up."
    from core.dataflow.template_seeder import register_custom_stage_types
    register_custom_stage_types(_db_manager, _engine.registry)
    _engine.registry.sync_to_db(_db_manager)
    return None


def _register_switch_on() -> None:
    from api.config_active_api import ON_SWITCH_ON
    ON_SWITCH_ON["dataflow_custom_stage_types"] = _on_custom_stage_type_switched_on


_register_switch_on()


# ── Backfill (run a DataFlow across a range of business dates) ─────────


class BackfillBody(StrictRequestModel):
    start_date:    str  = Field(..., description="ISO date (YYYY-MM-DD).")
    end_date:      str  = Field(..., description="ISO date (YYYY-MM-DD), inclusive.")
    skip_weekends: bool = True
    extra_context: Optional[Dict[str, Any]] = None
    pacing_seconds: float = Field(0,
                                    description="Sleep N seconds between starts to avoid "
                                                  "overwhelming downstream systems (default 0).")
    # Phase 132.20 — optional impersonation for backfill runs.
    run_as:        Optional[str] = None


@router.post("/api/dataflows/{dataflow_name}/backfill")
async def backfill_dataflow(
    dataflow_name: str,
    body: BackfillBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Kick off a series of runs for one DataFlow, one per business date
    in the requested range.  Each run gets ``business_date`` in its
    context.  Returns the list of run ids — admins can watch them in
    the runs dashboard.

    The runs are scheduled (dispatched) one at a time on the engine's
    executor, optionally paced by ``pacing_seconds`` so downstream
    systems aren't overwhelmed.

    Skips Saturday/Sunday when skip_weekends is true.  Holiday awareness
    can be layered on later by reading FeedCalendar; the basic API uses
    weekday alone to keep first-cut behaviour predictable.
    """
    _require_deps()
    from datetime import date, timedelta
    try:
        start = date.fromisoformat(body.start_date)
        end   = date.fromisoformat(body.end_date)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"invalid date: {exc}")
    if end < start:
        raise HTTPException(status_code=400, detail="end_date is before start_date")
    # Sanity cap so a typo doesn't queue 10 years of runs by accident
    span_days = (end - start).days + 1
    if span_days > 366:
        raise HTTPException(
            status_code=400,
            detail=f"backfill span {span_days} days exceeds 366-day cap",
        )

    # Build the date list
    dates: List[str] = []
    d = start
    while d <= end:
        if not body.skip_weekends or d.weekday() < 5:
            dates.append(d.isoformat())
        d += timedelta(days=1)

    # Dispatch each as a regular DataFlow run
    import threading
    import asyncio as _asyncio_bf
    run_ids: List[int] = []
    last_error: Optional[str] = None
    for bd in dates:
        try:
            ctx_dict = {"business_date": bd}
            if body.extra_context:
                ctx_dict.update(body.extra_context)
            run = _engine.start_run(
                dataflow_name=dataflow_name,
                context=ctx_dict,
                triggered_by=f"backfill:{_username(user) or 'api'}",
                run_as=(body.run_as or None),
                trigger_payload={"backfill": True, "business_date": bd},
            )
            run_ids.append(run["id"])
            # Submit to the engine pool so they run sequentially on the
            # dispatcher's executor (fire-and-forget — the API returns
            # the ids immediately).
            if _dispatch_executor is not None:
                _dispatch_executor.submit(_safe_run, run["id"])
            else:
                threading.Thread(target=_dispatcher.run, args=(run["id"],),
                                  daemon=True, name=f"bf-{run['id']}").start()
            # BF-590: this endpoint is async — blocking time.sleep inside an
            # event-loop coroutine freezes EVERY other request on this worker.
            # With 366 dates × 5s = 30-minute event-loop freeze.  Use
            # asyncio.sleep so other handlers continue to run.
            if body.pacing_seconds > 0:
                await _asyncio_bf.sleep(min(body.pacing_seconds, 5.0))
        except Exception as exc:
            last_error = f"{bd}: {exc}"
            logger.warning("[backfill] %s failed: %s", bd, exc)

    _audit(user, "dataflow.backfill", target=f"dataflow:{dataflow_name}",
           details={"dates": len(dates), "runs_created": len(run_ids),
                     "start": body.start_date, "end": body.end_date,
                     "skip_weekends": body.skip_weekends})
    return {
        "dataflow_name":  dataflow_name,
        "dates_queued":   len(dates),
        "runs_created":   len(run_ids),
        "run_ids":        run_ids,
        "last_error":     last_error,
    }


@router.post("/api/dataflows/templates/seed")
async def force_seed_templates(
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Admin escape hatch — force-runs seed_built_in_templates() and returns
    how many rows were created.  Use when the Job Type / template dropdown
    is empty after deploy + restart cycle.  Idempotent so multiple calls
    are safe — only creates rows that don't already exist by name.
    """
    _require_deps()
    try:
        from core.dataflow.template_seeder import seed_built_in_templates
        n = seed_built_in_templates(_db_manager)
        # Also re-sync stage types so the catalogue is in line.
        try:
            _engine.registry.sync_to_db(_db_manager)
        except Exception as _sx:
            logger.debug("stage-type sync skipped during force-seed: %s", _sx)
        _audit(user, "dataflow.force_seed_templates",
               details={"created": n})
        return {"seeded": n}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/api/dataflows/scheduler/tick")
async def scheduler_tick_debug(
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    if _scheduler is None:
        raise HTTPException(status_code=503, detail="scheduler not initialised")
    # 2026-10-10 -- the tick honours the SAME leader gate the poll loop
    # checks before every tick (DataFlowScheduler.tick_once); a pod that
    # does not hold the role answers 409 and fires nothing.  It used to
    # run a full fire pass on whichever pod served the POST.
    from core.dataflow.scheduler import NotTheScheduler
    try:
        fired = _scheduler.tick_once()
    except NotTheScheduler as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    return {"fired": fired}


@router.post("/api/dataflows/scheduler/start")
async def scheduler_start(
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    if _scheduler is None:
        raise HTTPException(status_code=503, detail="scheduler not initialised")
    # 2026-08-20 — honour the SAME role gate that suppresses the autostart.
    # This endpoint used to start the poll loop on whichever api pod served
    # the POST, silently bypassing QS_POD_ROLE=api: with leader election on
    # it returned {"started": true} while every tick skipped as non-leader
    # (a lie); with election off it genuinely moved DataFlow schedule firing
    # onto the DuckDB-serving pod.  The scheduler pod owns the loop now
    # (core.daemon_registry._reg_dataflow_scheduler); on a role-gated pod
    # the admin opt-in is ``dataflows.scheduler_autostart=true``.
    from core.pod_role import should_run as _pr_should_run
    if not _pr_should_run("dataflow_scheduler_autostart",
                          scheduler_mode=None):
        raise HTTPException(
            status_code=409,
            detail="this pod's role gates the DataFlow scheduler off; it is "
                   "owned by the scheduler pod — set "
                   "dataflows.scheduler_autostart=true there instead of "
                   "starting the loop on an api pod")
    import asyncio
    try:
        asyncio.get_running_loop()
        from core.bg_tasks import track_bg_task as _track
        _track(_scheduler.start())      # strong-ref: see core/bg_tasks
    except RuntimeError:
        # No running loop in this context — caller must use lifespan startup.
        raise HTTPException(status_code=500, detail="no running event loop")
    _audit(user, "dataflow.scheduler_start")
    return {"started": True}


@router.post("/api/dataflows/scheduler/stop")
async def scheduler_stop(
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    if _scheduler is None:
        raise HTTPException(status_code=503, detail="scheduler not initialised")
    import asyncio
    try:
        asyncio.get_running_loop()
        from core.bg_tasks import track_bg_task as _track
        _track(_scheduler.stop())       # strong-ref: see core/bg_tasks
    except RuntimeError:
        raise HTTPException(status_code=500, detail="no running event loop")
    _audit(user, "dataflow.scheduler_stop")
    return {"stopped": True}


# ── Phase 132.21 — Tags + dependency + bulk actions + cost telemetry ────


class TagsBody(StrictRequestModel):
    tags: List[str] = Field(default_factory=list)


class DependsOnPreviousBody(StrictRequestModel):
    depends_on_previous: bool


@router.patch("/api/dataflows/{dataflow_id}/tags")
def set_dataflow_tags(
    dataflow_id: int,
    body: TagsBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlow
    with _db_manager.get_session() as session:
        wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
        if wf is None:
            raise HTTPException(status_code=404, detail=f"dataflow {dataflow_id} not found")
        # Normalize: strip whitespace, dedupe, drop empties, keep order
        seen = set()
        norm: List[str] = []
        for t in body.tags:
            t2 = (t or "").strip().lower()
            if t2 and t2 not in seen:
                seen.add(t2)
                norm.append(t2)
        wf.tags = norm
        wf.updated_at = datetime.now(timezone.utc)
        session.flush()
        result = wf.to_dict()
    _audit(user, "dataflow.set_tags", target=f"dataflow:{dataflow_id}",
           details={"tags": norm})
    return result


@router.patch("/api/dataflows/{dataflow_id}/depends-on-previous")
def set_depends_on_previous(
    dataflow_id: int,
    body: DependsOnPreviousBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlow
    with _db_manager.get_session() as session:
        wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
        if wf is None:
            raise HTTPException(status_code=404, detail=f"dataflow {dataflow_id} not found")
        wf.depends_on_previous = bool(body.depends_on_previous)
        wf.updated_at = datetime.now(timezone.utc)
        session.flush()
        result = wf.to_dict()
    _audit(user, "dataflow.set_depends_on_previous",
           target=f"dataflow:{dataflow_id}",
           details={"depends_on_previous": bool(body.depends_on_previous)})
    return result


# NOTE: list_all_tags / GET /api/dataflows/tags is declared earlier in
# the file (see the v2 block above the `{dataflow_id}` route) so FastAPI
# matches the literal path before its typed catch-all.


# ── Bulk actions ────────────────────────────────────────────────────────


class BulkRunIdsBody(StrictRequestModel):
    run_ids: List[int]


class BulkDataflowIdsBody(StrictRequestModel):
    dataflow_ids: List[int]


@router.post("/api/dataflow-runs/bulk-resume")
async def bulk_resume_runs(
    body: BulkRunIdsBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Resume up to N failed/partial/cancelled runs in one call.  Each
    failure is reported individually; partial successes are returned.
    """
    _require_deps()
    if not body.run_ids:
        return {"requested": 0, "resumed": [], "errors": []}
    if len(body.run_ids) > 100:
        raise HTTPException(status_code=400, detail="bulk_resume limited to 100 runs per call")
    resumed: List[int] = []
    errors: List[Dict[str, Any]] = []
    for rid in body.run_ids:
        try:
            # Re-submit to the dispatcher.  Resume uses the same code path
            # as the single-run endpoint via dispatcher.run().
            if _dispatch_executor is not None:
                _dispatch_executor.submit(_safe_run, rid)
            else:
                import threading as _th
                _th.Thread(target=_dispatcher.run, args=(rid,), daemon=True,
                            name=f"bulk-resume-{rid}").start()
            resumed.append(rid)
        except Exception as exc:
            errors.append({"run_id": rid, "error": str(exc)})
    _audit(user, "dataflow.bulk_resume",
           details={"requested": len(body.run_ids),
                     "resumed": len(resumed), "errors": len(errors)})
    return {"requested": len(body.run_ids),
            "resumed": resumed, "errors": errors}


@router.post("/api/dataflows/bulk-pause")
async def bulk_pause_dataflows(
    body: BulkDataflowIdsBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    if not body.dataflow_ids:
        return {"requested": 0, "paused": [], "errors": []}
    if len(body.dataflow_ids) > 100:
        raise HTTPException(status_code=400, detail="bulk_pause limited to 100 per call")
    paused: List[int] = []
    errors: List[Dict[str, Any]] = []
    for wf_id in body.dataflow_ids:
        try:
            _engine.set_paused(wf_id, True)
            paused.append(wf_id)
        except Exception as exc:
            errors.append({"dataflow_id": wf_id, "error": str(exc)})
    _audit(user, "dataflow.bulk_pause",
           details={"requested": len(body.dataflow_ids),
                     "paused": len(paused), "errors": len(errors)})
    return {"requested": len(body.dataflow_ids),
            "paused": paused, "errors": errors}


@router.post("/api/dataflows/bulk-resume")
async def bulk_resume_dataflows(
    body: BulkDataflowIdsBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    if not body.dataflow_ids:
        return {"requested": 0, "resumed": [], "errors": []}
    if len(body.dataflow_ids) > 100:
        raise HTTPException(status_code=400, detail="bulk_resume limited to 100 per call")
    resumed: List[int] = []
    errors: List[Dict[str, Any]] = []
    for wf_id in body.dataflow_ids:
        try:
            _engine.set_paused(wf_id, False)
            resumed.append(wf_id)
        except Exception as exc:
            errors.append({"dataflow_id": wf_id, "error": str(exc)})
    _audit(user, "dataflow.bulk_resume_dataflows",
           details={"requested": len(body.dataflow_ids),
                     "resumed": len(resumed), "errors": len(errors)})
    return {"requested": len(body.dataflow_ids),
            "resumed": resumed, "errors": errors}


# ── Notification policies ──────────────────────────────────────────────


class NotificationPolicyBody(StrictRequestModel):
    name:        str = Field(..., min_length=1, max_length=120)
    event:       str = Field(..., description="run_failed | sla_breached | run_succeeded | run_partial | run_cancelled")
    channel:     str = Field(..., description="email | webhook | ws")
    dataflow_id: Optional[int] = None
    tag:         Optional[str] = None
    config:      Optional[Dict[str, Any]] = None
    is_active:   bool = True
    cooldown_seconds: int = 0


# NOTE: GET /api/dataflows/notification-policies is declared earlier
# in this file (see the v2 block above the `{dataflow_id}` route).


@router.post("/api/dataflows/notification-policies")
def create_notification_policy(
    body: NotificationPolicyBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowNotificationPolicy
    from core.dataflow.notification_policy import ALL_EVENTS
    if body.event not in ALL_EVENTS:
        raise HTTPException(status_code=400,
                             detail=f"event must be one of {ALL_EVENTS}")
    if body.channel not in ("email", "webhook", "ws"):
        raise HTTPException(status_code=400,
                             detail="channel must be email|webhook|ws")
    with _db_manager.get_session() as session:
        row = DataFlowNotificationPolicy(
            name=body.name, event=body.event, channel=body.channel,
            dataflow_id=body.dataflow_id, tag=body.tag,
            config=body.config or {},
            is_active=body.is_active,
            cooldown_seconds=max(0, int(body.cooldown_seconds or 0)),
            created_by=_username(user),
        )
        session.add(row)
        session.flush()
        result = row.to_dict()
    _audit(user, "dataflow.notification_policy.create",
           target=f"policy:{result['id']}",
           details={"name": body.name, "event": body.event,
                     "channel": body.channel})
    return result


@router.patch("/api/dataflows/notification-policies/{policy_id}")
def update_notification_policy(
    policy_id: int,
    body: NotificationPolicyBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowNotificationPolicy
    with _db_manager.get_session() as session:
        row = session.query(DataFlowNotificationPolicy).filter(
            DataFlowNotificationPolicy.id == policy_id).first()
        if row is None:
            raise HTTPException(status_code=404, detail="policy not found")
        row.name = body.name
        row.event = body.event
        row.channel = body.channel
        row.dataflow_id = body.dataflow_id
        row.tag = body.tag
        row.config = body.config or {}
        row.is_active = bool(body.is_active)
        row.cooldown_seconds = max(0, int(body.cooldown_seconds or 0))
        session.flush()
        result = row.to_dict()
    _audit(user, "dataflow.notification_policy.update",
           target=f"policy:{policy_id}")
    return result


@router.delete("/api/dataflows/notification-policies/{policy_id}")
def delete_notification_policy(
    policy_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowNotificationPolicy
    with _db_manager.get_session() as session:
        row = session.query(DataFlowNotificationPolicy).filter(
            DataFlowNotificationPolicy.id == policy_id).first()
        if row is None:
            raise HTTPException(status_code=404, detail="policy not found")
        session.delete(row)
    _audit(user, "dataflow.notification_policy.delete",
           target=f"policy:{policy_id}")
    return {"deleted": True}


# ── Phase 132.22 — Schedule preview ─────────────────────────────────────


class SchedulePreviewBody(StrictRequestModel):
    cron_expression: Optional[str] = None
    calendar_rule:   Optional[Dict[str, Any]] = None
    timezone:        str = "UTC"
    count:           int = Field(10, ge=1, le=50)


@router.post("/api/dataflows/schedules/preview")
async def preview_schedule(
    body: SchedulePreviewBody,
    user: dict = Depends(require_capability("dataflows.author")),
) -> Dict[str, Any]:
    """Phase 132.22 — preview the next N fire times for a candidate
    schedule before it's saved.  Catches cron typos / calendar-rule
    mistakes at edit-time instead of in production.

    Exactly one of cron_expression / calendar_rule must be set.
    Returns ISO timestamps in the requested timezone.
    """
    _require_deps()
    if not body.cron_expression and not body.calendar_rule:
        raise HTTPException(status_code=400,
                             detail="cron_expression or calendar_rule required")
    if body.cron_expression and body.calendar_rule:
        raise HTTPException(status_code=400,
                             detail="set only one of cron_expression / calendar_rule")
    from core.dataflow.cron_utils import next_fire_at
    from core.dataflow.calendar_trigger import next_calendar_fire_at
    fires: List[str] = []
    errors: List[str] = []
    now = datetime.now(timezone.utc)
    cursor = now
    for _ in range(body.count):
        try:
            if body.cron_expression:
                nxt = next_fire_at(body.cron_expression, now=cursor,
                                    tz_name=body.timezone)
            else:
                nxt = next_calendar_fire_at(body.calendar_rule,
                                              now=cursor, tz_name=body.timezone,
                                              db_manager=_db_manager)
        except Exception as exc:
            errors.append(str(exc))
            break
        fires.append(nxt.isoformat())
        # Advance 1 second past the last fire to get the next
        cursor = nxt + timedelta(seconds=1)
    return {"timezone": body.timezone,
            "count": len(fires), "fires": fires,
            "errors": errors}


# ── Observed cost telemetry ─────────────────────────────────────────────


# ── Phase 132.22 — Project Variables ─────────────────────────────────────


class VariableBody(StrictRequestModel):
    name:        str = Field(..., pattern=r"^[a-zA-Z_][a-zA-Z0-9_]*$",
                                min_length=1, max_length=80)
    # Phase 132.24 — value is OPTIONAL on PATCH so editing a secret
    # without re-typing the password doesn't blow it away.  Backend
    # leaves the stored value untouched when value is null.  Frontend
    # sends value=null for "no change" on secret edits.
    value:       Optional[str] = None
    dataflow_id: Optional[int] = None
    description: Optional[str] = None
    is_secret:   bool = False


# NOTE: GET /api/dataflows/variables is declared earlier in this file
# (above the `{dataflow_id}` typed catch-all).


@router.post("/api/dataflows/variables")
def create_variable(
    body: VariableBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    if body.value is None:
        raise HTTPException(status_code=400, detail="value is required on create")
    from core.db.models import DataFlowVariable
    from core.crypto import encrypt_value
    with _db_manager.get_session() as session:
        # Enforce unique (name, scope)
        existing = session.query(DataFlowVariable).filter(
            DataFlowVariable.name == body.name,
            DataFlowVariable.dataflow_id == body.dataflow_id).first()
        if existing is not None:
            raise HTTPException(status_code=409,
                                  detail=f"variable {body.name!r} already exists at this scope")
        value_to_store = body.value
        if body.is_secret:
            try:
                value_to_store = encrypt_value(body.value)
            except Exception as exc:
                raise HTTPException(status_code=500,
                                      detail=f"could not encrypt secret: {exc}")
        row = DataFlowVariable(
            name=body.name, value=value_to_store,
            dataflow_id=body.dataflow_id, description=body.description,
            is_secret=bool(body.is_secret), created_by=_username(user),
        )
        session.add(row)
        session.flush()
        result = row.to_dict(include_value=not body.is_secret)
    _audit(user, "dataflow.variable.create",
           target=f"variable:{result['id']}",
           details={"name": body.name, "dataflow_id": body.dataflow_id,
                     "is_secret": body.is_secret})
    return result


@router.patch("/api/dataflows/variables/{var_id}")
def update_variable(
    var_id: int,
    body: VariableBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowVariable
    from core.crypto import encrypt_value
    with _db_manager.get_session() as session:
        row = session.query(DataFlowVariable).filter(
            DataFlowVariable.id == var_id).first()
        if row is None:
            raise HTTPException(status_code=404, detail="variable not found")
        row.name = body.name
        row.dataflow_id = body.dataflow_id
        row.description = body.description
        row.is_secret = bool(body.is_secret)
        # Phase 132.24 — only overwrite value when explicitly provided.
        # value=None means "keep existing".  This protects secrets being
        # silently wiped by an admin who clicked Edit without re-typing.
        if body.value is not None:
            row.value = (encrypt_value(body.value) if body.is_secret
                          else body.value)
        session.flush()
        result = row.to_dict(include_value=not body.is_secret)
    _audit(user, "dataflow.variable.update", target=f"variable:{var_id}",
           details={"value_changed": body.value is not None})
    return result


@router.delete("/api/dataflows/variables/{var_id}")
def delete_variable(
    var_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowVariable
    with _db_manager.get_session() as session:
        row = session.query(DataFlowVariable).filter(
            DataFlowVariable.id == var_id).first()
        if row is None:
            raise HTTPException(status_code=404, detail="variable not found")
        session.delete(row)
    _audit(user, "dataflow.variable.delete", target=f"variable:{var_id}")
    return {"deleted": True}


# ── Phase 132.22 — Webhook triggers ──────────────────────────────────────


class WebhookCreateBody(StrictRequestModel):
    dataflow_id: int
    name:        str = Field(..., min_length=1, max_length=120)
    allowed_ips: Optional[List[str]] = None
    is_active:   bool = True
    # Phase 132.26 — when true, mint a random signing secret + require
    # callers to sign request bodies with HMAC-SHA256.  The secret is
    # returned ONCE on creation (alongside the token); subsequent
    # responses only signal has_signing_secret=true.
    require_signature: bool = False


def _hash_token(token: str) -> str:
    """SHA-256 hex digest of a webhook token (Phase 132.25)."""
    import hashlib
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


@router.post("/api/dataflows/webhook-triggers")
def create_webhook_trigger(
    body: WebhookCreateBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Mint a new webhook token for one DataFlow.  Token is returned
    ONCE, in this response only — admins must copy + store it.
    Subsequent list/get calls never return the token (we store only the
    SHA-256 hash + an 8-char prefix for identification).
    """
    _require_deps()
    import secrets as _secrets
    from core.db.models import DataFlow, DataFlowWebhookTrigger
    signing_secret_plain: Optional[str] = None
    with _db_manager.get_session() as session:
        wf = session.query(DataFlow).filter(
            DataFlow.id == body.dataflow_id).first()
        if wf is None:
            raise HTTPException(status_code=404, detail="dataflow not found")
        # 32-byte url-safe token (43 base64 chars).  Plaintext is shown
        # ONCE in this response; the DB only sees the hash.
        token = _secrets.token_urlsafe(32)
        token_hash = _hash_token(token)
        # Phase 132.26 — mint signing secret when requested.
        signing_secret_encrypted: Optional[str] = None
        if body.require_signature:
            signing_secret_plain = _secrets.token_urlsafe(32)
            try:
                from core.crypto import encrypt_value
                signing_secret_encrypted = encrypt_value(signing_secret_plain)
            except Exception as exc:
                raise HTTPException(
                    status_code=500,
                    detail=f"could not encrypt signing secret: {exc}",
                )
        row = DataFlowWebhookTrigger(
            dataflow_id=body.dataflow_id, name=body.name,
            # Phase 132.28 — legacy `token` column has NOT NULL UNIQUE on
            # databases created at Phase 132.22.  Auto-migrate can't drop
            # the NOT NULL constraint on SQLite without a full table
            # rebuild.  Workaround: stash the hash in the legacy column
            # too so the constraint is satisfied without storing the
            # plaintext.  Lookup paths key off token_hash first; the
            # legacy `token == incoming_plaintext` fallback won't match
            # for new rows (token holds the hash, not plaintext) but
            # that's fine — token_hash lookup wins.
            token=token_hash,
            token_hash=token_hash,
            token_prefix=token[:8],
            is_active=bool(body.is_active),
            allowed_ips=body.allowed_ips or [],
            signing_secret=signing_secret_encrypted,
            created_by=_username(user),
        )
        session.add(row)
        session.flush()
        result = row.secure_to_dict(plaintext_token=token)
        if signing_secret_plain:
            result["signing_secret"] = signing_secret_plain
    _audit(user, "dataflow.webhook.create",
           target=f"webhook:{result['id']}",
           details={"dataflow_id": body.dataflow_id, "name": body.name,
                     "token_prefix": token[:8],
                     "require_signature": body.require_signature})
    return result


# NOTE: GET /api/dataflows/webhook-triggers declared earlier in this file
# (above the `{dataflow_id}` typed catch-all).


@router.delete("/api/dataflows/webhook-triggers/{webhook_id}")
def delete_webhook_trigger(
    webhook_id: int,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowWebhookTrigger
    with _db_manager.get_session() as session:
        row = session.query(DataFlowWebhookTrigger).filter(
            DataFlowWebhookTrigger.id == webhook_id).first()
        if row is None:
            raise HTTPException(status_code=404, detail="webhook not found")
        session.delete(row)
    _audit(user, "dataflow.webhook.delete", target=f"webhook:{webhook_id}")
    return {"deleted": True}


def _ip_in_allowlist(ip: str, allowlist: List[str]) -> bool:
    """True when ``ip`` is in any of the CIDR strings in ``allowlist``.
    Empty allowlist → permissive (matches "any source").
    Invalid CIDRs are ignored.
    """
    if not allowlist:
        return True
    import ipaddress
    try:
        target = ipaddress.ip_address(ip)
    except Exception:
        return False
    for cidr in allowlist:
        try:
            if target in ipaddress.ip_network(cidr.strip(), strict=False):
                return True
        except Exception:
            continue
    return False


def _verify_hmac_signature(
    header_value: Optional[str], raw_body: bytes, secret: str,
) -> bool:
    """Phase 132.26 — constant-time HMAC-SHA256 verification.
    Header format: ``sha256=<hex>``.  Returns True on match.
    """
    import hmac as _hmac
    import hashlib as _hashlib
    if not header_value or not header_value.startswith("sha256="):
        return False
    provided = header_value[len("sha256="):].strip()
    expected = _hmac.new(
        secret.encode("utf-8"), raw_body, _hashlib.sha256
    ).hexdigest()
    # compare_digest blocks timing attacks
    return _hmac.compare_digest(provided, expected)


@router.post("/api/webhooks/dataflow/{token}")
async def fire_webhook(
    token: str,
    request: 'Request',   # type: ignore[name-defined]
) -> Dict[str, Any]:
    """External trigger.  No session auth — the token IS the auth.
    Optional JSON body merges into the run's context + trigger_payload.

    Source IP is checked against ``allowed_ips`` (CIDR list) on the
    webhook row when set.  Tokens are rate-limited per-token (cooldown
    = 1 second) so a flood of pokes doesn't queue up runs faster than
    the dispatcher drains.

    Phase 132.26 — when the webhook row has a signing_secret, the caller
    must provide ``X-QueryStudio-Signature: sha256=<hex>`` where hex is
    HMAC-SHA256(signing_secret, raw_body).hexdigest().  Verified before
    any DB write.
    """
    _require_deps()
    if not token or len(token) < 16:
        raise HTTPException(status_code=400, detail="invalid token")
    # Read RAW body bytes for HMAC verification BEFORE FastAPI parses.
    try:
        raw_body = await request.body()
    except Exception:
        raw_body = b""
    sig_header = request.headers.get("x-querystudio-signature") if request else None
    from core.db.models import DataFlowWebhookTrigger, DataFlow
    incoming_hash = _hash_token(token)
    # 2026-06-03 — DB block wrapped in to_thread; await request.body() above
    # already ran on the loop.  fire_webhook is hit by external systems on
    # cron-like cadences so loop blocking here would compound.
    src_ip = (request.client.host if request and request.client else "")
    def _do_webhook_db():
        with _db_manager.get_session() as session:
            from sqlalchemy import or_ as _or
            wh = (
                session.query(DataFlowWebhookTrigger)
                .filter(_or(
                    DataFlowWebhookTrigger.token_hash == incoming_hash,
                    DataFlowWebhookTrigger.token == token,
                ))
                .first()
            )
            if wh is None or not wh.is_active:
                raise HTTPException(status_code=404, detail="webhook not found")
            if wh.token_hash is None and wh.token == token:
                wh.token_hash = incoming_hash
                wh.token_prefix = token[:8]
                wh.token = None
            allowlist = list(wh.allowed_ips or [])
            if allowlist:
                if not _ip_in_allowlist(src_ip, allowlist):
                    raise HTTPException(status_code=403, detail="source IP not allowed")
            if wh.signing_secret:
                try:
                    from core.crypto import decrypt_value
                    secret_plain = decrypt_value(wh.signing_secret)
                except Exception as exc:
                    logger.warning("[webhook] could not decrypt signing_secret: %s",
                                    exc)
                    raise HTTPException(status_code=500,
                                          detail="webhook signing secret unreadable")
                if not _verify_hmac_signature(sig_header, raw_body, secret_plain):
                    raise HTTPException(status_code=401,
                                          detail="invalid signature")
            if wh.last_fired_at is not None:
                lf = wh.last_fired_at
                if lf.tzinfo is None:
                    lf = lf.replace(tzinfo=timezone.utc)
                if (datetime.now(timezone.utc) - lf).total_seconds() < 1.0:
                    raise HTTPException(status_code=429, detail="webhook rate-limited (1/sec)")
            wf = session.query(DataFlow).filter(
                DataFlow.id == wh.dataflow_id, DataFlow.status == "active").first()
            if wf is None:
                raise HTTPException(status_code=409,
                                      detail="dataflow not active (archived or no active version)")
            wh.last_fired_at = datetime.now(timezone.utc)
            wh.fire_count = (wh.fire_count or 0) + 1
            session.flush()
            return wf.name, wh.id
    wf_name, wh_id = await asyncio.to_thread(_do_webhook_db)

    # Parse body as JSON now that signature passed.  Empty body is fine.
    body: Optional[Dict[str, Any]] = None
    if raw_body:
        try:
            import json as _json
            body = _json.loads(raw_body)
            if not isinstance(body, dict):
                body = None
        except Exception:
            body = None
    try:
        ctx_extra = (body or {}).get("context") or {}
        payload = {"webhook_id": wh_id, "fired_at":
                    datetime.now(timezone.utc).isoformat()}
        if body:
            payload.update({k: v for k, v in body.items() if k != "context"})
        run = _engine.start_run(
            dataflow_name=wf_name,
            context=ctx_extra,
            trigger_payload=payload,
            triggered_by=f"webhook:{wh_id}",
        )
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _submit_run(run["id"])
    return {"fired": True, "run_id": run["id"], "dataflow": wf_name}


# ── Phase 132.23 — Run annotations ─────────────────────────────────────


class AnnotationBody(StrictRequestModel):
    note:     str = Field(..., min_length=1)
    severity: str = Field("info", pattern="^(info|warning|resolution)$")


@router.get("/api/dataflow-runs/{run_id}/annotations")
async def list_run_annotations(
    run_id: int,
    user: dict = Depends(require_capability("dataflows.view")),
) -> List[Dict[str, Any]]:
    _require_deps()
    from core.db.models import DataFlowRunAnnotation
    def _do():
        with _db_manager.get_session(read_only=True) as session:
            rows = (
                session.query(DataFlowRunAnnotation)
                .filter(DataFlowRunAnnotation.run_id == run_id)
                .order_by(DataFlowRunAnnotation.id.asc())
                .all()
            )
            return [r.to_dict() for r in rows]
    return await asyncio.to_thread(_do)


@router.post("/api/dataflow-runs/{run_id}/annotations")
def add_run_annotation(
    run_id: int,
    body: AnnotationBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    _require_deps()
    from core.db.models import DataFlowRun, DataFlowRunAnnotation
    with _db_manager.get_session() as session:
        # Verify the run exists
        run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
        if run is None:
            raise HTTPException(status_code=404, detail="run not found")
        row = DataFlowRunAnnotation(
            run_id=run_id, note=body.note, severity=body.severity,
            created_by=_username(user),
        )
        session.add(row)
        session.flush()
        result = row.to_dict()
    _audit(user, "dataflow.run.annotate", target=f"run:{run_id}",
           details={"severity": body.severity})
    return result


# ── Phase 132.23 — Dry-run / validate-only ──────────────────────────────


@router.get("/api/dataflows/{dataflow_id}/dry-run")
def dry_run_dataflow(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    """Validate-only: walks every stage, calls validate_config(), checks
    Connection ids, resolves {var.foo} placeholders, but does NOT
    execute.  Returns a structured report of what would happen.
    """
    _require_deps()
    wf = _engine.get_workflow(dataflow_id)
    if wf is None:
        raise HTTPException(status_code=404, detail="dataflow not found")
    from core.db.models import Connection
    from core.dataflow.variables import VariableResolver

    resolver = VariableResolver(_db_manager, dataflow_id=dataflow_id)
    registry = _engine.registry if hasattr(_engine, "registry") else None

    # Pre-load Connection rows referenced by all stages.
    # BF-599h (2026-05-31): bad connection_id values (e.g. typos) are
    # legitimately skipped during this set construction — the per-stage
    # validation loop below re-walks and surfaces the error via
    # `errs.append(f"{k}={v!r} not an integer")`.  Adding a WARN log
    # here means an operator tailing the backend log also sees the
    # malformed config, not just the API caller.
    referenced: set = set()
    for s in wf.get("stages", []):
        cfg = s.get("config") or {}
        try:
            cls = registry.get(s.get("stage_type")) if registry else None
        except Exception:
            cls = None
        for k in (getattr(cls, "CONNECTION_FIELDS", {}) if cls else {}):
            v = cfg.get(k)
            if v:
                try:
                    referenced.add(int(v))
                except Exception:
                    logger.warning(
                        "[dataflow-validate] stage %r field %s=%r is "
                        "not int-convertible — per-stage report will "
                        "include the error (was silent pre-BF-599h)",
                        s.get("name") or s.get("stage_type"), k, v,
                    )
    connections_present: Dict[int, bool] = {}
    if referenced:
        with _db_manager.get_session(read_only=True) as session:
            rows = session.query(Connection).filter(
                Connection.id.in_(list(referenced))).all()
            connections_present = {r.id: bool(r.is_active) for r in rows}

    report_stages: List[Dict[str, Any]] = []
    overall_ok = True
    for s in wf.get("stages", []):
        cfg = s.get("config") or {}
        st_name = s.get("stage_type")
        try:
            cls = registry.get(st_name) if registry else None
        except Exception:
            cls = None
        errs: List[str] = []
        # 1. Stage class registered?
        if cls is None:
            errs.append(f"stage_type {st_name!r} not registered")
        # 2. Connection ids resolve?
        for k in (getattr(cls, "CONNECTION_FIELDS", {}) if cls else {}):
            v = cfg.get(k)
            if not v:
                continue
            try:
                cid = int(v)
            except Exception:
                errs.append(f"{k}={v!r} not an integer")
                continue
            if cid not in connections_present:
                errs.append(f"{k}={cid} connection not found")
            elif not connections_present[cid]:
                errs.append(f"{k}={cid} connection is inactive")
        # 3. validate_config()
        if cls is not None:
            try:
                cfg_errs = list(cls.validate_config(cfg) or [])
            except Exception as exc:
                cfg_errs = [f"validate_config raised: {exc}"]
            errs.extend(cfg_errs)
        # 4. Expand {var.foo} and report which would resolve
        expanded_cfg = resolver.expand(cfg)
        unresolved_vars: List[str] = []
        # Scan the EXPANDED config string-values for any leftover {var.foo}
        def _scan(v):
            import re as _re
            if isinstance(v, str):
                for m in _re.findall(r"\{var\.([a-zA-Z_][a-zA-Z0-9_]*)\}", v):
                    unresolved_vars.append(m)
            elif isinstance(v, dict):
                for x in v.values():
                    _scan(x)
            elif isinstance(v, list):
                for x in v:
                    _scan(x)
        _scan(expanded_cfg)
        if unresolved_vars:
            errs.append(f"unresolved variables: {sorted(set(unresolved_vars))}")
        if errs:
            overall_ok = False
        report_stages.append({
            "stage_alias":   s.get("stage_alias"),
            "stage_type":    st_name,
            "seq":           s.get("seq"),
            "predecessors":  s.get("predecessors") or [],
            "issues":        errs,
            "ok":            not errs,
        })
    return {
        "dataflow_id": dataflow_id,
        "dataflow_name": wf.get("name"),
        "version":     wf.get("version"),
        "status":      wf.get("status"),
        "ok":          overall_ok,
        "stage_count": len(report_stages),
        "stages":      report_stages,
        "referenced_connection_ids": sorted(referenced),
    }


# ── Phase 132.23 — DAG-as-code bundle (export + import) ────────────────


@router.get("/api/dataflows/{dataflow_id}/bundle")
def export_dataflow_bundle(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    """Phase 132.23 — pkg-format export.  Bundles the DataFlow definition
    + its schedules + tags + SLA + notification policies into a single
    JSON blob.  Designed for GitOps: commit the bundle to a repo, import
    it elsewhere to recreate the DAG with all metadata.

    Excludes runtime state (runs, approvals, observed cost, last_fired_at,
    last_run_at, next_run_at) — those don't transfer.

    Connection ids inside stage configs are kept AS-IS; the target
    environment must already have matching connection records, or admins
    must remap before promote.
    """
    _require_deps()
    wf = _engine.get_workflow(dataflow_id)
    if wf is None:
        raise HTTPException(status_code=404, detail="dataflow not found")
    from core.db.models import (
        DataFlowSchedule, DataFlowNotificationPolicy, DataFlowVariable,
    )
    with _db_manager.get_session(read_only=True) as session:
        schedules = (
            session.query(DataFlowSchedule)
            .filter(DataFlowSchedule.dataflow_id == dataflow_id)
            .all()
        )
        policies = (
            session.query(DataFlowNotificationPolicy)
            .filter(DataFlowNotificationPolicy.dataflow_id == dataflow_id)
            .all()
        )
        # Per-DataFlow variables (NOT global — global travel with the whole
        # project; per-DAG ones are part of the DAG bundle)
        per_vars = (
            session.query(DataFlowVariable)
            .filter(DataFlowVariable.dataflow_id == dataflow_id)
            .all()
        )

    def _scrub_sched(s):
        d = s.to_dict()
        for k in ("id", "last_run_at", "next_run_at", "created_at", "updated_at"):
            d.pop(k, None)
        return d

    def _scrub_policy(p):
        d = p.to_dict()
        for k in ("id", "last_fired_at", "created_at", "updated_at"):
            d.pop(k, None)
        return d

    def _scrub_var(v):
        d = v.to_dict(include_value=not v.is_secret)
        for k in ("id", "created_at", "updated_at"):
            d.pop(k, None)
        # Secrets are NEVER exported in plaintext — bundle carries the
        # name + a placeholder so the target env must re-supply.
        if v.is_secret:
            d["value"] = None
            d["secret_placeholder"] = True
        return d

    # 2026-10-17 -- the configuration-release item (core/release/types/dashboards.py):
    # stages' connection ids as NAMES, secret variable values stripped, the
    # key the release engine applies.  The bundle keys below stay for readers.
    release_item, release_item_error = None, None
    try:
        from core.release.contract import ReleaseRefusal as _RR
        from core.release.registry import load as _load_registry
        from core.db.models import DataFlow as _DF
        with _db_manager.get_session(read_only=True) as _s:
            _row = _s.query(_DF).filter(_DF.id == int(dataflow_id)).first()
            release_item = _load_registry().require("dataflow").export_row(_s, _row, _load_registry()).to_dict() if _row else None
    except _RR as exc:
        release_item_error = str(exc)
    return {
        "bundle_version": 1,            # the bundle keys are unchanged; release_item is ADDED
        "release_item": release_item,
        "release_item_error": release_item_error,
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "dataflow": {
            "name":               wf["name"],
            "description":        wf.get("description"),
            "trigger_type":       wf.get("trigger_type"),
            "trigger_config":     wf.get("trigger_config"),
            "default_context":    wf.get("default_context"),
            "tags":               wf.get("tags") or [],
            "sla_seconds":        wf.get("sla_seconds"),
            "depends_on_previous": wf.get("depends_on_previous", False),
            "is_template":        wf.get("is_template", False),
            "template_category":  wf.get("template_category"),
            "template_label":     wf.get("template_label"),
            "stages":             [
                {k: s[k] for k in (
                    "stage_alias", "stage_type", "seq", "predecessors",
                    "config", "retry_policy", "timeout_seconds",
                    "on_failure", "on_failure_target",
                ) if k in s} for s in wf.get("stages", [])
            ],
        },
        "schedules":            [_scrub_sched(s) for s in schedules],
        "notification_policies": [_scrub_policy(p) for p in policies],
        "variables":            [_scrub_var(v) for v in per_vars],
    }


class BundleImportBody(StrictRequestModel):
    bundle:        Dict[str, Any]
    name_override: Optional[str] = None
    overwrite:     bool = False   # if True and DAG exists, add a new version


@router.post("/api/dataflows/bundle-import")
def import_dataflow_bundle(
    body: BundleImportBody,
    user: dict = Depends(require_capability("dataflows.manage")),
) -> Dict[str, Any]:
    """Phase 132.23 — import a bundle exported by /bundle.

    Creates the DataFlow (v1 draft) + restores all bundle-side resources:
    schedules, notification policies, per-DAG variables.  Secret variables
    arrive as placeholders — admins must re-populate via PATCH /variables.

    The dataflow comes back as a draft so admins can review + promote.
    """
    _require_deps()
    bundle = body.bundle or {}
    if isinstance(bundle.get("release_item"), dict):
        # 2026-10-17 -- a bundle exported since today carries the release
        # item: ONE configuration release through the engine (mapping,
        # four-eyes, one transaction, the ledger), answered in this route's shape.
        from core.release import engine as _release_engine
        from core.release.contract import Item as _Item, ReleaseRefusal as _RR
        item = _Item.from_dict(bundle["release_item"])
        if body.name_override:
            # a renamed import is a CLONE: a new, reviewable draft (the legacy contract)
            item.key = body.name_override.strip()
            item.definition["name"] = item.key
            item.definition["status"] = "draft"
        try:
            summary = _release_engine.promote_items(
                _db_manager, [item], actor=_username(user), source_environment="dataflow bundle",
                scope={"kind": "dataflow", "keys": [item.key]}, overwrite_existing=bool(body.overwrite))
        except _RR as exc:
            raise HTTPException(status_code=422, detail=exc.to_dict())
        if summary["errors"]:
            raise HTTPException(status_code=409 if summary.get("skipped") else 422, detail=summary)
        wfs = _engine.list_workflows(name=item.key)
        wf = max(wfs, key=lambda w: int(w.get("version") or 0)) if wfs else None
        return {"imported_dataflow_id": wf["id"] if wf else None, "name": item.key,
                "dataflow": wf, "release": summary,
                "next_steps": ["review the draft", "promote it when ready",
                               "re-supply secret variables (never carried)"]}
    if int(bundle.get("bundle_version", 0)) not in (1, 2):
        raise HTTPException(status_code=400,
                              detail="unsupported bundle_version")
    logger.warning("[dataflow] bundle-import without a release_item: the pre-2026-10-17 path (connection ids "
                   "kept as-is) -- re-export the bundle to get the release item")
    df = bundle.get("dataflow") or {}
    if not df.get("name") or not df.get("stages"):
        raise HTTPException(status_code=400,
                              detail="bundle.dataflow.{name,stages} required")
    name = (body.name_override or df["name"]).strip()
    # Build the engine spec
    from core.dataflow.engine import DataFlowSpec, StageSpec
    stage_specs = [
        StageSpec(
            s["stage_alias"], s["stage_type"], seq=int(s.get("seq", 0)),
            predecessors=s.get("predecessors") or [],
            config=s.get("config") or {},
            retry_policy=s.get("retry_policy") or {},
            timeout_seconds=s.get("timeout_seconds"),
            on_failure=s.get("on_failure", "halt"),
            on_failure_target=s.get("on_failure_target"),
        )
        for s in df["stages"]
    ]
    spec = DataFlowSpec(
        name=name,
        description=df.get("description"),
        trigger_type=df.get("trigger_type", "manual"),
        trigger_config=df.get("trigger_config") or {},
        default_context=df.get("default_context") or {},
        stages=stage_specs,
    )
    try:
        if body.overwrite:
            existing = _engine.list_workflows(name=name)
            if existing:
                wf = _engine.add_version(name, spec, created_by=_username(user))
            else:
                wf = _engine.create_workflow(spec, created_by=_username(user))
        else:
            wf = _engine.create_workflow(spec, created_by=_username(user))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    wf_id = wf["id"]

    # Apply tags + SLA + depends_on_previous
    try:
        from core.db.models import DataFlow
        with _db_manager.get_session() as session:
            row = session.query(DataFlow).filter(DataFlow.id == wf_id).first()
            if row is not None:
                row.tags = df.get("tags") or []
                row.sla_seconds = df.get("sla_seconds")
                row.depends_on_previous = bool(df.get("depends_on_previous", False))
                if df.get("is_template"):
                    row.is_template = True
                    row.template_category = df.get("template_category")
                    row.template_label    = df.get("template_label")
                session.flush()
    except Exception as exc:
        logger.warning("[bundle import] tags/sla restore failed: %s", exc)

    # Restore schedules (inactive by default so admin reviews before going live)
    sched_count = 0
    for s in (bundle.get("schedules") or []):
        try:
            from core.db.models import DataFlowSchedule
            with _db_manager.get_session() as session:
                session.add(DataFlowSchedule(
                    dataflow_id=wf_id,
                    name=s.get("name") or "imported",
                    cron_expression=s.get("cron_expression") or "",
                    calendar_rule=s.get("calendar_rule"),
                    timezone=s.get("timezone") or "UTC",
                    context_overrides=s.get("context_overrides") or {},
                    is_active=False,   # admin must enable
                    created_by=_username(user),
                ))
                session.flush()
            sched_count += 1
        except Exception as exc:
            logger.warning("[bundle import] schedule restore failed: %s", exc)

    # Restore notification policies (also inactive by default)
    policy_count = 0
    for p in (bundle.get("notification_policies") or []):
        try:
            from core.db.models import DataFlowNotificationPolicy
            with _db_manager.get_session() as session:
                session.add(DataFlowNotificationPolicy(
                    dataflow_id=wf_id,
                    name=p.get("name") or "imported",
                    event=p.get("event"),
                    channel=p.get("channel"),
                    config=p.get("config") or {},
                    is_active=False,
                    cooldown_seconds=p.get("cooldown_seconds") or 0,
                    created_by=_username(user),
                ))
                session.flush()
            policy_count += 1
        except Exception as exc:
            logger.warning("[bundle import] policy restore failed: %s", exc)

    # Per-DAG variables.  Secrets arrive as None — admin must re-populate.
    var_count = 0
    secrets_pending: List[str] = []
    for v in (bundle.get("variables") or []):
        try:
            from core.db.models import DataFlowVariable
            with _db_manager.get_session() as session:
                row = DataFlowVariable(
                    name=v.get("name"),
                    value=None if v.get("secret_placeholder") else v.get("value"),
                    dataflow_id=wf_id,
                    description=v.get("description"),
                    is_secret=bool(v.get("is_secret")),
                    created_by=_username(user),
                )
                session.add(row)
                session.flush()
            var_count += 1
            if v.get("secret_placeholder"):
                secrets_pending.append(v.get("name"))
        except Exception as exc:
            logger.warning("[bundle import] variable restore failed: %s", exc)

    _audit(user, "dataflow.bundle_import", target=f"dataflow:{wf_id}",
           details={"name": name, "schedules": sched_count,
                     "policies": policy_count, "variables": var_count})
    return {
        "imported_dataflow_id": wf_id,
        "name":               name,
        "schedules_restored": sched_count,
        "policies_restored":  policy_count,
        "variables_restored": var_count,
        "secrets_pending_refill": secrets_pending,
        "next_steps": [
            "Review the draft on /dataflows",
            "Verify Connection ids referenced by the stages exist locally",
            *(["Re-populate secret variables: " + ", ".join(secrets_pending)]
                if secrets_pending else []),
            "Promote when ready (POST /api/dataflows/<id>/promote)",
        ],
    }


# ── Phase 132.26 — Item-count-aware cost prediction ────────────────────


@router.get("/api/dataflows/{dataflow_id}/cost-predict")
def predict_dataflow_cost(
    dataflow_id: int,
    items: Optional[int] = Query(None, ge=0,
        description="Predicted item_count for stages that scale linearly (e.g. for_each over N items)."),
    rows:  Optional[int] = Query(None, ge=0,
        description="Predicted row_count for ETL stages."),
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    """Phase 132.26 — predict run duration via linear regression over
    observed history.

    For each stage we fit ``duration ~ scaling_input`` where
    scaling_input comes from per-run outputs:
       * ``item_count``  on for_each outputs
       * ``row_count``   on SAP / ETL / DB-load outputs
       * ``input_bytes`` on merge / split outputs

    Caller passes the predicted scaling value (``items``, ``rows``);
    each stage picks the input it normally exposes.  Stages whose
    history shows no usable scaling input fall back to median.

    Returns per-stage prediction + a "method" field per stage:
       * ``regression``: used a fitted line
       * ``median``    : no scaling found, fell back to median
       * ``static``    : no history at all, fell back to class-level estimate
    """
    _require_deps()
    wf = _engine.get_workflow(dataflow_id)
    if wf is None:
        raise HTTPException(status_code=404, detail="dataflow not found")

    from core.db.models import DataFlowRun, DataFlowRunStage
    from statistics import median

    target_x = None
    if items is not None:
        target_x = items
    elif rows is not None:
        target_x = rows

    # Collect history per stage_alias: list of (duration_seconds, scaling_value)
    by_alias: Dict[str, List[tuple]] = {}
    by_alias_type: Dict[str, str] = {}
    with _db_manager.get_session(read_only=True) as session:
        runs = (
            session.query(DataFlowRun)
            .filter(DataFlowRun.dataflow_id == dataflow_id,
                     DataFlowRun.status == "succeeded")
            .order_by(DataFlowRun.id.desc()).limit(50).all()
        )
        run_ids = [r.id for r in runs]
        if run_ids:
            stage_rows = (
                session.query(DataFlowRunStage)
                .filter(DataFlowRunStage.run_id.in_(run_ids),
                         DataFlowRunStage.status == "succeeded")
                .all()
            )
            for s in stage_rows:
                if s.duration_seconds is None or s.duration_seconds < 0:
                    continue
                outs = s.outputs or {}
                # Pick a scaling input — first one present wins
                x = None
                for key in ("item_count", "row_count", "input_bytes",
                              "totalcount", "output_bytes"):
                    v = outs.get(key)
                    if isinstance(v, (int, float)) and v >= 0:
                        x = float(v)
                        break
                by_alias.setdefault(s.stage_alias, []).append(
                    (float(s.duration_seconds), x))
                by_alias_type[s.stage_alias] = s.stage_type

    registry = _engine.registry if hasattr(_engine, "registry") else None
    total_seconds = 0
    per_stage: List[Dict[str, Any]] = []
    for s in wf.get("stages", []):
        alias = s.get("stage_alias")
        st_name = s.get("stage_type")
        cfg = s.get("config") or {}
        history = by_alias.get(alias, [])
        prediction: float
        method: str
        n_obs = len(history)
        slope: Optional[float] = None
        r2: Optional[float] = None
        if history and target_x is not None and any(x is not None for _d, x in history):
            xs = [x for _d, x in history if x is not None]
            ys = [d for d, x in history if x is not None]
            fit = _fit_linear(xs, ys)
            if fit is not None:
                prediction = max(0.0, fit["intercept"] + fit["slope"] * target_x)
                method = "regression"
                slope = fit["slope"]
                r2 = fit["r_squared"]
            else:
                prediction = float(median([d for d, _ in history]))
                method = "median"
        elif history:
            prediction = float(median([d for d, _ in history]))
            method = "median"
        else:
            # Fall back to static class-level estimate
            cls = None
            try:
                cls = registry.get(st_name) if registry is not None else None
            except Exception:
                cls = None
            try:
                est = cls.estimate_cost(cfg) if cls is not None else {"seconds": 5}
            except Exception:
                est = {"seconds": 5}
            prediction = float(est.get("seconds") or 0)
            method = "static"
        seconds = int(round(prediction))
        total_seconds += seconds
        per_stage.append({
            "stage_alias":     alias,
            "stage_type":      st_name,
            "seconds":         seconds,
            "method":          method,
            "observations":    n_obs,
            "slope":           round(slope, 4) if slope is not None else None,
            "r_squared":       round(r2, 3) if r2 is not None else None,
        })

    return {
        "dataflow_id":   dataflow_id,
        "target_items":  items,
        "target_rows":   rows,
        "stage_count":   len(per_stage),
        "total_seconds": total_seconds,
        "per_stage":     per_stage,
    }


# NOTE: GET /api/dataflows/metrics declared earlier in this file
# (above the `{dataflow_id}` typed catch-all).


@router.post("/api/dataflows/{dataflow_id}/check-connections")
def check_dataflow_connections(
    dataflow_id: int,
    user: dict = Depends(require_capability("dataflows.author")),
) -> Dict[str, Any]:
    """Phase 132.22 — pre-flight check that every Connection id referenced
    by any stage's CONNECTION_FIELDS actually exists and is_active.
    Catches dangling references at promote-time, not run-time.
    """
    _require_deps()
    wf = _engine.get_workflow(dataflow_id)
    if wf is None:
        raise HTTPException(status_code=404, detail="dataflow not found")
    from core.db.models import Connection
    issues: List[Dict[str, Any]] = []
    referenced: set = set()
    registry = _engine.registry if hasattr(_engine, "registry") else None
    for s in wf.get("stages", []):
        st_name = s.get("stage_type")
        cfg = s.get("config") or {}
        try:
            cls = registry.get(st_name) if registry is not None else None
        except Exception:
            cls = None
        conn_field_map = getattr(cls, "CONNECTION_FIELDS", {}) if cls else {}
        for id_key in conn_field_map:
            v = cfg.get(id_key)
            if not v:
                continue   # placeholder / unset — fine for legacy inline path
            try:
                referenced.add(int(v))
            except Exception:
                issues.append({
                    "stage_alias": s.get("stage_alias"),
                    "field": id_key, "value": v,
                    "issue": "not an integer",
                })
    # Bulk-query the connections
    if referenced:
        with _db_manager.get_session(read_only=True) as session:
            rows = (
                session.query(Connection)
                .filter(Connection.id.in_(list(referenced)))
                .all()
            )
            present = {r.id: r for r in rows}
        for s in wf.get("stages", []):
            cfg = s.get("config") or {}
            try:
                cls = registry.get(s.get("stage_type")) if registry else None
            except Exception:
                cls = None
            conn_field_map = getattr(cls, "CONNECTION_FIELDS", {}) if cls else {}
            for id_key in conn_field_map:
                v = cfg.get(id_key)
                if not v:
                    continue
                try:
                    cid = int(v)
                except Exception:
                    continue
                if cid not in present:
                    issues.append({
                        "stage_alias": s.get("stage_alias"),
                        "field": id_key, "value": cid,
                        "issue": "connection not found",
                    })
                elif not present[cid].is_active:
                    issues.append({
                        "stage_alias": s.get("stage_alias"),
                        "field": id_key, "value": cid,
                        "issue": f"connection {present[cid].name!r} is inactive",
                    })
    return {"dataflow_id": dataflow_id,
            "referenced_connection_ids": sorted(referenced),
            "ok": len(issues) == 0,
            "issues": issues}


def _fit_linear(xs: List[float], ys: List[float]) -> Optional[Dict[str, float]]:
    """Phase 132.26 — least-squares linear regression on (xs, ys).
    Returns {slope, intercept, n, r_squared} or None when xs has <2
    distinct values (slope undefined).
    """
    if not xs or len(xs) != len(ys) or len(xs) < 2:
        return None
    if len(set(xs)) < 2:
        return None
    n = len(xs)
    sx = sum(xs)
    sy = sum(ys)
    mean_x = sx / n
    mean_y = sy / n
    sxx = sum((x - mean_x) ** 2 for x in xs)
    sxy = sum((xs[i] - mean_x) * (ys[i] - mean_y) for i in range(n))
    if sxx == 0:
        return None
    slope = sxy / sxx
    intercept = mean_y - slope * mean_x
    # R² as a confidence indicator
    syy = sum((y - mean_y) ** 2 for y in ys)
    if syy == 0:
        r2 = 1.0
    else:
        ss_res = sum((ys[i] - (slope * xs[i] + intercept)) ** 2 for i in range(n))
        r2 = max(0.0, min(1.0, 1.0 - (ss_res / syy)))
    return {"slope": slope, "intercept": intercept, "n": n, "r_squared": r2}


@router.get("/api/dataflows/{dataflow_id}/cost-history")
def dataflow_cost_history(
    dataflow_id: int,
    limit: int = Query(20, ge=1, le=200),
    user: dict = Depends(require_capability("dataflows.view")),
) -> Dict[str, Any]:
    """Phase 132.21 — observed-cost telemetry.

    Returns the median + p95 actual stage duration over the last ``limit``
    successful runs of this DataFlow.  Powers the Ops UI's "estimate vs
    observed" delta + refines future ``estimate_cost()`` calls.
    """
    _require_deps()
    from core.db.models import DataFlow, DataFlowRun, DataFlowRunStage
    with _db_manager.get_session(read_only=True) as session:
        wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
        if wf is None:
            raise HTTPException(status_code=404, detail="dataflow not found")
        # Get the most-recent successful runs
        runs = (
            session.query(DataFlowRun)
            .filter(DataFlowRun.dataflow_id == dataflow_id,
                     DataFlowRun.status == "succeeded")
            .order_by(DataFlowRun.id.desc())
            .limit(limit)
            .all()
        )
        run_ids = [r.id for r in runs]
        if not run_ids:
            return {"dataflow_id": dataflow_id, "runs_observed": 0,
                     "per_stage": []}
        stage_rows = (
            session.query(DataFlowRunStage)
            .filter(DataFlowRunStage.run_id.in_(run_ids),
                     DataFlowRunStage.status == "succeeded")
            .all()
        )
    # Aggregate per stage_alias
    from statistics import median
    by_alias: Dict[str, List[float]] = {}
    by_alias_type: Dict[str, str] = {}
    for s in stage_rows:
        dur = s.duration_seconds
        if dur is None or dur < 0:
            continue
        by_alias.setdefault(s.stage_alias, []).append(float(dur))
        by_alias_type[s.stage_alias] = s.stage_type
    per_stage: List[Dict[str, Any]] = []
    for alias, durs in by_alias.items():
        durs_sorted = sorted(durs)
        p95_idx = max(0, int(round(len(durs_sorted) * 0.95)) - 1)
        per_stage.append({
            "stage_alias":     alias,
            "stage_type":      by_alias_type.get(alias),
            "observations":    len(durs),
            "median_seconds":  round(median(durs), 2),
            "p95_seconds":     round(durs_sorted[p95_idx], 2),
            "max_seconds":     round(max(durs), 2),
        })
    per_stage.sort(key=lambda r: r["stage_alias"])
    return {"dataflow_id": dataflow_id, "runs_observed": len(run_ids),
            "per_stage": per_stage}
