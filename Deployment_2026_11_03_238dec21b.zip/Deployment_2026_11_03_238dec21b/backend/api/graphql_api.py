"""
Phase 22F + Phase 90 — GraphQL API (Strawberry)

Provides a /graphql endpoint (Playground + queries/mutations) wrapping existing
REST business logic via the shared DatabaseManager singleton.

Phase 90 additions:
  - PublishedViewType, FeedType, DatasetType, BusinessReportType,
    SystemAccountType, CatalogTableType
  - ResponseFormat enum (JSON | CSV | PARQUET)
  - format parameter on executionResults + download_url field
  - download_url field on ExecuteResult

Usage:
    pip install strawberry-graphql[fastapi]

Wire from main.py:
    from api.graphql_api import graphql_app, set_graphql_dependencies
    set_graphql_dependencies(db_manager, auth_cfg)
    app.include_router(graphql_app, tags=["graphql"])     # it carries /graphql itself
"""

from __future__ import annotations

import logging
from typing import Optional, List

logger = logging.getLogger(__name__)

# ── Module-level singletons (set from main.py at startup) ────────────────────
_db_manager = None
_auth_cfg = None
_execute_fn = None   # async (sql, connection_id, limit, executed_by) -> str  (execution_id)
_pv_execute_fn = None  # async (slug, params, filters, columns, sort, limit, offset) -> dict
_pv_cfg = None           # Published Views config (_PublishedViewsCfg)
_pv_db_manager = None    # DatabaseManager for PV lookups + audit logging
_pv_cache_dir = None     # Path for file-based parquet cache
_pv_concurrency_sem = None  # asyncio.Semaphore for GraphQL PV concurrency
# Phase 133-K — when True we're running on the dedicated published-api
# pod (QUERYSTUDIO_PUBLISHED_API_MODE=true).  The executeQuery mutation
# refuses with a structured "this endpoint serves Published Views only"
# message instead of the generic "callback not configured" string.
_published_api_mode = False



_RESPONSE_FORMAT_ENUM = None


def _response_format_enum():
    """The GraphQL ``ResponseFormat`` enum, created once per process."""
    global _RESPONSE_FORMAT_ENUM
    if _RESPONSE_FORMAT_ENUM is None:
        import enum as _enum
        import strawberry

        @strawberry.enum
        class ResponseFormat(_enum.Enum):
            JSON = "json"
            CSV = "csv"
            PARQUET = "parquet"

        _RESPONSE_FORMAT_ENUM = ResponseFormat
    return _RESPONSE_FORMAT_ENUM


def _failsafe_effective_limit(requested, view_max, default_max):
    """Resolve a page limit WITHOUT the shared helper -- the fail-safe path.

    2026-08-20 -- EXTRACTED SO IT CAN ACTUALLY BE TESTED.

    This logic lived inline inside the ``except`` branch that fires only when
    importing ``published_views.helpers`` raises.  A test could not reach it,
    so the test that claimed to cover it MIRRORED the arithmetic inside the
    test file -- meaning it verified the test author's copy forever and would
    have stayed green through any change to the real branch.  A mutation
    sweep confirmed exactly that.  Logic that cannot be reached from a test
    has to be moved somewhere it can.

    Handles 0 EXPLICITLY, never by truth-testing: 0 means UNLIMITED
    product-wide, and ``x or default`` folding it into the default is the
    defect class this module has been bitten by repeatedly.

    ``view_max <= 0`` means the VIEW declares no restriction; GraphQL still
    bounds it, because Strawberry materializes the whole result as ONE JSON
    document -- bulk consumers are pointed at /bulk instead.
    """
    req = None if requested is None else int(requested)
    vmax = default_max if view_max is None else int(view_max)
    if vmax <= 0:
        return default_max if req in (None, 0) else req
    if req is None or req == 0:
        return vmax
    return min(req, vmax)


def set_graphql_dependencies(db_manager, auth_cfg) -> None:
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg = auth_cfg


def set_execute_callback(fn) -> None:
    """Inject the execute function from main.py."""
    global _execute_fn
    _execute_fn = fn


def set_published_api_mode(enabled: bool) -> None:
    """Phase 133-K — mark this process as the consumer-facing
    published-api pod.  Used by the executeQuery mutation to refuse
    arbitrary-SQL submissions with a clear error pointing consumers at
    the publishedViewData query instead.
    """
    global _published_api_mode
    _published_api_mode = bool(enabled)


def set_pv_execute_callback(fn) -> None:
    """Inject the Published View execute function from main.py."""
    global _pv_execute_fn
    _pv_execute_fn = fn


def set_pv_enterprise_deps(pv_cfg, db_manager, cache_dir=None) -> None:
    """Inject enterprise dependencies for GraphQL Published View queries.

    Called from main.py _startup() after set_published_views_dependencies().
    Provides: auth config, DB for audit logging, cache dir, concurrency semaphore.
    """
    import asyncio as _aio
    from pathlib import Path as _Path
    global _pv_cfg, _pv_db_manager, _pv_cache_dir, _pv_concurrency_sem
    _pv_cfg = pv_cfg
    _pv_db_manager = db_manager
    if cache_dir:
        _pv_cache_dir = _Path(cache_dir) if not isinstance(cache_dir, _Path) else cache_dir
    if pv_cfg:
        # 0 = UNLIMITED product-wide; Semaphore(0) would deadlock every
        # GraphQL published-view request rather than limit them.
        from core.concurrency_permits import sem_permits as _sem_permits
        _max = getattr(pv_cfg, 'max_concurrent', 10)
        _pv_concurrency_sem = _aio.Semaphore(
            _sem_permits(_max, name='graphql.published_views'))
    logger.info("GraphQL PV enterprise deps: max_concurrent=%s, cache_dir=%s",
                getattr(pv_cfg, 'max_concurrent', '?'), cache_dir)


# ── Published View Data resolver (module-level for testability) ──────────────

async def _resolve_published_view_data(
    request,
    slug: str,
    params_list=None,
    filters_list_raw=None,
    columns=None,
    sort_column=None,
    sort_dir="asc",
    limit=1000,
    offset=0,
    dataset_version=None,
) -> dict:
    """Core enterprise-hardened resolver for Published View data queries.

    ``dataset_version`` (2026-10-24): the ``datasetVersion`` of the first
    page.  A later page whose data is no longer that materialization (a
    refresh or an expiry in between) is an error result, never a page of
    other data -- the REST rule (helpers.pin_refusal) on this door too; it
    had none, so a GraphQL consumer paging across a refresh spliced two.

    Extracted from Strawberry QueryExt so it can be tested independently.
    Returns a plain dict matching ViewDataResult fields.

    params_list: list of dicts with 'name' and 'value' keys
    filters_list_raw: list of dicts with 'column', 'operator', 'value' keys
    """
    import asyncio as _aio
    import json as _json
    import time as _time
    import uuid as _uuid

    def _err(msg: str, rid: str = "") -> dict:
        # 2026-08-23 (P6 D13) — carry the honesty fields EXPLICITLY.  The
        # Strawberry wrapper defaulted a missing total_is_exact to True, so
        # an ERROR result claimed "total is exact" (0 rows, exact!) — the
        # same missing-key-resolves-to-the-strong-claim bug fixed on cache
        # hits on 2026-08-22, still open on the error path.  An error is
        # UNKNOWN: neither exact nor truncated.
        return dict(
            slug=slug, total_rows=0, returned_rows=0,
            offset=offset, error_message=msg, request_id=rid,
            columns=[], rows=[], cached=False, execution_ms=0,
            cache_age_seconds=0, version=1,
            has_more=False, total_is_exact=False, dataset_truncated=False,
            bulk_stream_url="", dataset_version="",
            # an error result was not filtered by anything: no disclosure
            entitlement=None,
        )

    def _build_result(result: dict, elapsed_ms: int, cached: bool,
                      cache_age: int, rid: str) -> dict:
        data_rows = result.get("data") or []
        col_names = result.get("columns") or []
        col_meta = [
            dict(
                name=c.get("name", c) if isinstance(c, dict) else str(c),
                type=c.get("type", "string") if isinstance(c, dict) else "string",
            )
            for c in col_names
        ]
        rows = [dict(json=_json.dumps(r, default=str)) for r in data_rows]
        _total = result.get("total_rows", len(rows))
        # A GraphQL page that stopped short of the dataset used to say so
        # NOWHERE: total_rows=5_000_000 next to returned_rows=50_000, with no
        # signal that the rest is reachable.  Say it, and say where to go —
        # GraphQL is the wrong transport for bulk (it materializes the whole
        # document), so point at the streaming endpoint rather than pretending.
        # 2026-09-29 -- ``has_more`` is THE decision in
        # ``envelope.page_continuation`` (shared with the REST envelope): on a
        # capped dataset's LAST in-ceiling page it is TRUE, so a consumer
        # that follows has_more alone asks for the ceiling next and meets
        # ``_ceiling_refusal`` (the error result naming ``bulk_stream_url``)
        # instead of stopping silently.  The paragraph below predates that
        # decision: the loop it feared now terminates in that refusal.
        from api.published_views.envelope import page_continuation as _page_continuation
        _has_more = _page_continuation(
            dict(result, offset=offset, returned_rows=len(rows), total_rows=_total),
            slug=slug)[0]
        # 2026-08-22 — `has_more` alone cannot express this.  When the dataset
        # was truncated at `published_views.dataset_row_cap`, the executor
        # stamps total_mode="at_least" and total_rows is the CAP, not the
        # table: a 70M-row view caps at 1,000,000, so the last page computes
        # 1000000 > 999000+1000 = False and reports has_more=false.  The
        # consumer stops, believing it holds the whole dataset, having
        # received 1M of 70M rows with no error and no qualifier — and
        # `bulk_stream_url` was already being emitted right next to that
        # has_more=false, telling it to go nowhere.
        #
        # `has_more` is NOT forced true here.  It answers "is there another
        # page THROUGH THIS ENDPOINT", and past the cap there is not; forcing
        # it would send a well-behaved consumer round a paging loop that never
        # terminates.  The missing information is a different fact — the
        # dataset itself is a prefix — so it gets its own field, and
        # total_rows stops being reported as an exact count it is not.
        # 2026-08-22 (fable_audit finding 3) — a MISSING total_mode must
        # never resolve to the strong claim.  The cache-hit path used to
        # hand a result with no total_mode at all (the cached-read dict
        # never carried it), and `not _truncated` then said
        # total_is_exact=true for a 70M-row view capped at 1M — on the
        # DOMINANT path (cache_ttl defaults to 28,800s).  Exactness is now
        # claimed only when provenance SAYS "exact"; unknown is neither
        # exact nor truncated — UNKNOWN = UNSAFE, same as the REST
        # envelope.
        _total_mode = str(result.get("total_mode") or "unknown").lower()
        _truncated = _total_mode in ("at_least", "atleast", "lower_bound")
        _total_exact = _total_mode == "exact"
        return dict(
            slug=slug,
            total_rows=_total,
            returned_rows=len(rows),
            offset=offset,
            columns=col_meta,
            rows=rows,
            cached=cached,
            execution_ms=elapsed_ms,
            cache_age_seconds=cache_age,
            version=pv.get("version", 1) if pv else 1,
            request_id=rid,
            error_message=None,
            has_more=_has_more,
            total_is_exact=_total_exact,
            dataset_truncated=_truncated,
            bulk_stream_url=f"/api/v1/views/{slug}/bulk",
            # the materialization these rows came from: pass it back as
            # datasetVersion on every later page (2026-10-24)
            dataset_version=str(result.get("_dataset_version") or ""),
            # 2026-10-24 -- the entitlement DISCLOSURE, the SAME block REST's
            # ``meta.entitlement`` carries (core/row_security/disclosure.py):
            # the stored summary of the materialisation these rows came from
            # (a MISS stamps it, a HIT reads the manifest) plus THIS caller's
            # principal and the view's mode.  Unknown is said, never "not filtered".
            entitlement=_entitlement_block(result),
        )

    def _entitlement_block(result: dict) -> dict:
        from core.row_security import disclosure as _disclosure
        return _disclosure.for_response(result.get("_entitlement"), consumer=api_user, pv=pv)

    def _ceiling_refusal(result: dict, *, elapsed: int, cached: bool,
                         cache_age: int, cache_status: str, rid: str):
        """2026-09-29 -- a page AT OR PAST a capped dataset's ceiling is
        refused, here as on REST (``envelope.paged_ceiling`` is THE rule;
        REST answers 416, GraphQL answers an ``error_message`` result that
        still carries ``dataset_truncated`` / ``bulk_stream_url`` so the
        consumer is told where the rest is).  ``None`` when the page is
        inside the ceiling or the dataset has none.  Logged as 416 BEFORE
        the caller would have logged a 200."""
        from api.published_views.envelope import paged_ceiling as _paged_ceiling
        _c = _paged_ceiling(result, slug=slug)
        if _c is None or not _c.past(offset):
            return None
        _detail = _c.refusal_detail(offset)
        _log_access(
            api_user, pv, filters_list, 0, elapsed, 416,
            request, _pv_db_manager,
            cache_status=cache_status,
            error_details=_detail["message"],
            columns_requested=columns,
            params=params_dict or None,
        )
        _out = _err(_detail["message"], rid)
        _out.update(
            total_rows=_c.rows, total_is_exact=False, dataset_truncated=True,
            bulk_stream_url=_c.continue_with, cached=cached,
            cache_age_seconds=cache_age, execution_ms=elapsed,
        )
        return _out

    # ── Step 1: Request extraction ────────────────────────────────────
    _rid = ""
    if request:
        _rid = (request.headers.get("x-request-id") or "") if hasattr(request, 'headers') else ""
        if not _rid:
            _rid = _uuid.uuid4().hex[:16]
    else:
        _rid = _uuid.uuid4().hex[:16]
    t0 = _time.time()

    # ── Step 2: Authentication ────────────────────────────────────────
    api_user = None
    try:
        from api.deps import get_api_key_or_ad_user
        if request:
            api_user = get_api_key_or_ad_user(request)
    except Exception as auth_exc:
        _detail = getattr(auth_exc, 'detail', str(auth_exc))
        return _err(f"Authentication failed: {_detail}", _rid)
    if api_user is None:
        return _err("Authentication required (X-API-Key or Basic auth)", _rid)

    # ── Step 3: Rate limiting ─────────────────────────────────────────
    try:
        # 2026-10-10 -- the shared-store upsert OFF the loop (page_io).
        from api.published_views.page_io import enforce_api_key_rate_limit as _rl
        await _rl(api_user, _pv_cfg)
    except Exception as rl_exc:
        _detail = getattr(rl_exc, 'detail', str(rl_exc))
        return _err(str(_detail), _rid)

    # ── Step 4: PV lookup + access control ────────────────────────────
    if not _pv_db_manager:
        return _err("Service not ready", _rid)

    pv = _pv_db_manager.get_published_view_by_slug(slug)
    if not pv or not pv.get("is_active"):
        # 2026-10-17 -- a RETIRED API says so (core/published_api/lifecycle.py);
        # GraphQL has no headers to carry it, so the sentence is the answer
        from core.published_api.lifecycle import refusal_for as _refusal_for
        try:
            _lc_info = _pv_db_manager.get_published_view_lifecycle(slug)
        except Exception:                               # noqa: BLE001 -- unknown reads as not found
            _lc_info = None
        return _err(_refusal_for(_lc_info, slug=slug, kind_word="view")["detail"], _rid)

    try:
        from api.published_views.helpers import _check_view_access
        _check_view_access(pv, api_user)
    except Exception as access_exc:
        _detail = getattr(access_exc, 'detail', str(access_exc))
        return _err(str(_detail), _rid)

    # ── Step 5: Input validation ──────────────────────────────────────
    # P4/P5 (2026-08-17) — GraphQL now resolves the limit through the SAME
    # chokepoint the REST path uses (helpers.effective_page_limit): a NULL
    # per-view max follows the LIVE published_views.max_limit config, and 0
    # means unlimited (product-wide spelling).  This module is the
    # AUTHORITATIVE resolution for GraphQL.  (2026-08-20: this used to say
    # the main.py wrapper "still hardcodes min(limit, max_limit) and must be
    # updated" -- it was updated the same day, so the note was stale and
    # described a defect that no longer existed.  main.py:3125 now calls the
    # same helper.)  GraphQL returns one JSON document and Strawberry
    # materializes every row, so bulk consumers are still pointed at /bulk —
    # see ``bulk_stream_url`` in the result.
    # 2026-08-20 -- CLAMP NEGATIVES BEFORE RESOLUTION.
    #
    # The REST routes declare ``Query(None, ge=0)`` so a negative limit is a
    # 422 there.  GraphQL validates nothing, and downstream ``max(0, int(v))``
    # turns -7 into 0, which in this product means UNLIMITED.  So `limit: -1`
    # on a view with max_limit=0 resolved to the unlimited sentinel and
    # Strawberry then materialized the whole dataset as ONE JSON document --
    # garbage input failing OPEN, in the data-exposure direction.  A negative
    # limit is not a request for everything; treat it as unspecified so the
    # view's own default applies.
    if limit is not None and int(limit) < 0:
        limit = None
    try:
        from api.published_views.helpers import effective_page_limit as _eff_pl
        effective_limit = _eff_pl(pv, limit)
    except Exception:
        # Fail-safe: keep the legacy config-driven cap if the helper import
        # ever breaks — never fail the request over limit resolution.
        try:
            from core.config import get as _gql_cfg_get
            _gql_default_max = int(_gql_cfg_get("published_views", "max_limit", 50000))
        except Exception:
            _gql_default_max = 50000
        # 2026-08-20 -- the banned zero-fold, in the one branch that still
        # had it.  ``int(limit or 0) or _gql_default_max`` folds an explicit
        # 0 into the default, and ``pv.get("max_limit") or _gql_default_max``
        # folds a view's explicit 0 (UNLIMITED) into 50,000 -- disagreeing
        # with the primary path above and with the explicit-0-wins rule.
        # Handle 0 explicitly, never by truth-testing.
        effective_limit = _failsafe_effective_limit(
            limit, pv.get("max_limit"), _gql_default_max)

    # Validate filters.  Mirror the engine's full operator vocabulary —
    # ``core.where_clause_mapping._ENGINE_OPERATOR_PATTERN`` is the
    # source of truth and the REST path (api/published_views/helpers
    # ::_parse_filters) accepts every operator below.  GraphQL was
    # missing is_null / is_not_null / not_contains, silently rejecting
    # them with "Invalid filter operator" — closed 2026-05-27.
    VALID_OPS = {
        "eq", "ne", "gt", "gte", "lt", "lte",
        "in", "not_in", "between",
        "contains", "not_contains",
        "is_null", "is_not_null",
    }
    allowed_filters = pv.get("allowed_filters") or []
    filters_list = []
    if filters_list_raw:
        for f in filters_list_raw:
            f_col = f.get("column", "") if isinstance(f, dict) else getattr(f, "column", "")
            f_op = f.get("operator", "eq") if isinstance(f, dict) else getattr(f, "operator", "eq")
            f_val = f.get("value", "") if isinstance(f, dict) else getattr(f, "value", "")
            if allowed_filters and f_col not in allowed_filters:
                return _err(
                    f"Filter on column '{f_col}' not allowed. "
                    f"Allowed: {', '.join(allowed_filters)}", _rid)
            if f_op not in VALID_OPS:
                return _err(
                    f"Invalid filter operator '{f_op}'. "
                    f"Valid: {', '.join(sorted(VALID_OPS))}", _rid)
            filters_list.append({
                "column": f_col,
                "operator": f_op,
                "value": f_val,
            })

    # Validate params against param_definitions
    from api.published_views.helpers import _validate_param_types
    params_dict = {}
    if params_list:
        for p in params_list:
            p_name = p.get("name", "") if isinstance(p, dict) else getattr(p, "name", "")
            p_val = p.get("value", "") if isinstance(p, dict) else getattr(p, "value", "")
            params_dict[p_name] = p_val
    param_defs = pv.get("param_definitions") or []
    if params_dict and param_defs:
        try:
            params_dict = _validate_param_types(params_dict, param_defs)
        except Exception as param_exc:
            _detail = getattr(param_exc, 'detail', str(param_exc))
            return _err(str(_detail), _rid)

    # Required parameter enforcement
    for _pd in param_defs:
        if _pd.get("required") and _pd["name"] not in params_dict:
            return _err(f"Missing required parameter: {_pd['name']}", _rid)

    # ── Step 6: Cache check ───────────────────────────────────────────
    from api.published_views.helpers import (
        _build_cache_key, _read_cached_result, _log_access, pv_cache_path, served_rows,
        _user_cache_scope, _report_version_scope,
        user_cache_scope_async as _user_cache_scope_async,
        pin_refusal as _pin_refusal,
    )
    # 2026-09-05 — THE SAME TWO KEY INGREDIENTS THE REST READER USES,
    # from the SAME two helpers.  This reader had neither, and the two
    # omissions are not the same severity.
    #
    # ``user_scope`` (BF-415) is the serious one, and it is a LEAK, not a
    # staleness bug.  This resolver EXECUTES per consumer -- it threads
    # ``consumer_user=api_user`` into the PV callback below, so row
    # security rewrites the SQL for the caller -- and then the cache-write
    # block persists that per-consumer dataset.  With the consumer absent
    # from the key, both the read AND the write landed on one shared slot:
    # consumer A's RLS-filtered rows were served verbatim to consumer B on
    # the next request, for the whole cache TTL (default 8h).  Measured
    # before the fix with two real principals: B received A's rows.
    # ``_user_cache_scope`` returns None only when the view has no RLS
    # markers, row security is globally off AND the SQL is not
    # principal-varying -- exactly the case where the shared slot IS
    # correct -- so existing entries for non-RLS views stay valid.
    #
    # ``report_version`` is the publish-lifecycle identity.  A cache HIT
    # returns before ``_pv_execute_fn`` runs, so the resolver that gate
    # lives in (``_resolve_execution_report(..., consumer=True)``) never
    # executed on a hit: an ARCHIVED business report kept answering 200
    # instead of 410 and a REPUBLISHED one kept serving the superseded
    # version.  An IDENTITY ingredient, not a second gate -- a slot that
    # does not exist yet is a miss, and a miss runs the gate.
    #
    # NOT a second scoping implementation, deliberately: a decision made
    # twice is the bug.  Both helpers are the ones published_views_api's
    # five call sites and the warmup loop already use.
    # 2026-10-03 -- the report rows read with the view (one statement) answer
    # both ingredients; see core/reports/preloaded.py.
    from core.reports.preloaded import served_db_for as _served_db_for
    _sdb = _served_db_for(pv, _pv_db_manager)
    _user_scope = await _user_cache_scope_async(pv, api_user, db=_sdb)
    # Two primary-key reads -- OFF the event loop, and unwrapped, exactly as
    # the five REST call sites do it.  No local fallback: the helper already
    # owns "could not read the lifecycle" and answers
    # REPORT_VERSION_UNRESOLVED for it, which is its own slot.  A second
    # fallback here would be a second answer to the same question -- and a
    # branch nothing can reach, which a mutation sweep proved by removing it
    # with no behaviour change.
    from core.db_async import adb as _gql_adb
    _rv_scope = await _gql_adb(_report_version_scope, pv, _sdb)
    cache_key = _build_cache_key(
        pv["id"], filters_list, sort_column, sort_dir,
        columns, effective_limit, offset, params_dict or None,
        user_scope=_user_scope,
        report_version=_rv_scope,
    )
    cache_ttl = pv.get("cache_ttl_seconds", 28800)
    # PAGED slot (bulk datasets live in their own — see helpers.pv_cache_path).
    cached_path = pv_cache_path(_pv_cache_dir, pv["id"], cache_key)

    # Same F2 backstop as the REST reader: a sorted read materializes the whole
    # file, so an entry too large to be a paged dataset (one the pre-2026-08-08
    # bulk path wrote into this slot) is a MISS, not an OOM.  Only the READ is
    # skipped — the write below still runs and overwrites the oversized entry
    # with a properly capped one, so the slot self-heals.
    # 2026-09-15 — the REST route may have published a PAGE-BOUNDED prefix
    # into this slot (manifest.scan_bound); a page it cannot cover is a MISS
    # here exactly as it is there.  Same chokepoint -- and since 2026-10-10
    # the same ONE hop OFF the loop (api/published_views/page_io.py):
    # existence, the sort-safety footer, the coverage probe, the age.
    from api.published_views import page_io as _page_io
    _entry = await _page_io.off_loop(
        _page_io.probe_cached_entry, cached_path, offset=offset,
        limit=effective_limit, sort_column=sort_column,
        slug=pv.get("slug", "?"), cache_ttl=cache_ttl)
    _cache_readable = bool(_entry.exists and _entry.sortable and _entry.covers)
    # 2026-10-24 -- a PINNED page past a prefix the REST route wrote: the run
    # below is full, and it CONTINUES the pin only if it starts with the pinned
    # rows (page_io.extends) -- the REST rule (published_views_api).
    _pinned_regrow_from = (cached_path if (dataset_version and _entry.exists and _entry.fresh
                                           and not _entry.covers) else None)

    if _cache_readable:
        age = _entry.age
        if _entry.fresh:
            try:
                result = await _page_io.off_loop(
                    _page_io.read_cached_page, cached_path, columns, offset,
                    effective_limit, sort_column, sort_dir, stream=False,
                )
                # 2026-08-22 (fable_audit finding 3) — the truncation
                # verdict comes from the CACHED DATASET'S OWN MANIFEST,
                # through the same chokepoint the REST cache-hit reader
                # uses.  _read_cached_result carries no total_mode, so
                # this branch used to build the response with the key
                # missing — and a missing key read as "exact": a capped
                # dataset claimed exactness on precisely the requests
                # the truncation fields were added for.  Not recomputed
                # here: the manifest wrote the verdict at publish time.
                elapsed = int((_time.time() - t0) * 1000)
                _refused = _ceiling_refusal(
                    result, elapsed=elapsed, cached=True, cache_age=int(age),
                    cache_status="HIT", rid=_rid)
                if _refused is not None:
                    return _refused
                _pin_msg = _pin_refusal(dataset_version, result)
                if _pin_msg:
                    return _err(_pin_msg, _rid)
                _log_access(
                    api_user, pv, filters_list,
                    served_rows(result), elapsed, 200,
                    request, _pv_db_manager,
                    cache_status="HIT",
                    columns_requested=columns,
                    params=params_dict or None,
                )
                return _build_result(
                    result, elapsed, True, int(age), _rid)
            except Exception:
                pass  # cache read failure → fall through to fresh execution

    # ── Step 7: Concurrency control ───────────────────────────────────
    if not _pv_execute_fn:
        return _err("Published View execute callback not configured", _rid)

    # 2026-10-04 -- the per-worker memory guard, the same rule REST /data
    # applies to a MISS (api/published_views/memory_guard.py): a worker near
    # its share of the pod's memory refuses a new materialisation rather than
    # start it and be OOM-killed with every request in flight on it.
    from core.process_memory import memory_pressure_verdict as _mem_verdict
    _mem = _mem_verdict("an uncached GraphQL materialisation")
    if _mem is not None:
        return _err(_mem.sentence(), _rid)

    sem_acquired = False
    try:
        if _pv_concurrency_sem:
            try:
                await _aio.wait_for(
                    _pv_concurrency_sem.acquire(), timeout=30.0)
                sem_acquired = True
            except _aio.TimeoutError:
                return _err(
                    "Too many concurrent requests — try again later",
                    _rid)

        # ── Step 8: Execute with timeout ──────────────────────────────
        _exec_timeout = float(
            getattr(_pv_cfg, 'execution_timeout_seconds', 300)
            if _pv_cfg else 300
        )
        try:
            # Phase 131 deep-dive #13: thread api_user → consumer_user
            # so the PV execute path applies RLS against the real
            # consumer's identity AND registers them with the
            # api_key_lifecycle for in-flight revocation.
            _exec_kwargs = dict(
                slug=slug,
                params=params_dict or None,
                filters=filters_list or None,
                columns=columns,
                sort_column=sort_column,
                sort_dir=sort_dir,
                limit=effective_limit,
                offset=offset,
            )
            try:
                import inspect as _gql_inspect
                _sig = _gql_inspect.signature(_pv_execute_fn)
                if "consumer_user" in _sig.parameters:
                    _exec_kwargs["consumer_user"] = api_user
            except Exception:
                pass  # back-compat: callback that doesn't accept consumer_user
            result = await _aio.wait_for(
                _pv_execute_fn(**_exec_kwargs),
                timeout=_exec_timeout,
            )
        except _aio.TimeoutError:
            elapsed = int((_time.time() - t0) * 1000)
            _log_access(
                api_user, pv, filters_list, 0, elapsed, 504,
                request, _pv_db_manager,
                cache_status="TIMEOUT",
                error_details="Execution timed out",
            )
            return _err("Query execution timed out", _rid)
    except Exception as exc:
        # ── Step 9: Error sanitization ────────────────────────────────
        from core.error_sanitizer import sanitize_error
        elapsed = int((_time.time() - t0) * 1000)
        _log_access(
            api_user, pv, filters_list, 0, elapsed, 500,
            request, _pv_db_manager,
            cache_status="ERROR",
            error_details=sanitize_error(str(exc)),
        )
        return _err("Query execution failed", _rid)
    finally:
        if sem_acquired and _pv_concurrency_sem:
            _pv_concurrency_sem.release()
        from api.published_views.memory_guard import large_work_finished
        large_work_finished("an uncached GraphQL materialisation")

    # ── Cache write (non-fatal) ───────────────────────────────────────
    # 2026-08-20 — delegate to the SINGLE publish chokepoint in
    # published_views_api.  This inline writer was an independent second
    # implementation using the same DETERMINISTIC ``.tmp`` staging name as
    # the request-path/warmup publisher, so two writers publishing the same
    # dataset slot could ``copy2`` into ONE staging file concurrently and
    # ``replace()`` the interleaved mixture into the live cache.  The
    # chokepoint stages under a unique per-publish name, retires the stale
    # manifest before the swap (F3, same as the code it replaces) and, when
    # the result carries a manifest, publishes the truth sidecar too.  Async
    # variant because the copy is blocking file I/O and this resolver runs
    # on the event loop.
    if _pinned_regrow_from is not None and result.get("_parquet_path"):
        if await _page_io.off_loop(_page_io.extends, result["_parquet_path"], _pinned_regrow_from):
            result["_extends_version"] = dataset_version
        else:
            result["_pin_refusal"] = "prefix_reordered"
    if cached_path and result.get("_parquet_path"):
        try:
            from api.published_views_api import _persist_result_to_cache_async
            if await _persist_result_to_cache_async(result, cached_path, slug=slug,
                                                    shared_slot=_user_scope is None):
                # the page served IS this materialization (as on REST)
                result["_dataset_version"] = await _page_io.off_loop(
                    _page_io.dataset_version_of, cached_path)
        except Exception:
            pass  # cache write failure is non-fatal

    # ── Step 10: Audit logging + response ─────────────────────────────
    elapsed = int((_time.time() - t0) * 1000)
    _refused = _ceiling_refusal(
        result, elapsed=elapsed, cached=False, cache_age=0,
        cache_status="MISS", rid=_rid)
    if _refused is not None:
        return _refused
    _pin_msg = _pin_refusal(dataset_version, result)
    if _pin_msg:
        return _err(_pin_msg, _rid)
    _log_access(
        api_user, pv, filters_list,
        served_rows(result), elapsed, 200,
        request, _pv_db_manager,
        cache_status="MISS",
        columns_requested=columns,
        params=params_dict or None,
    )
    return _build_result(result, elapsed, False, 0, _rid)


# ── GraphQL auth helpers (SECURITY AUDIT 2026-08-03, S1) ─────────────────────
#
# POST /graphql was mounted with NO auth: every management resolver
# (connections / queries / executions / reports / systemAccounts / …) read
# straight from _db_manager with no user and no ownership filter, so any
# unauthenticated caller could enumerate every tenant's connection names,
# saved-query metadata, execution history and reports.  publishedViewData
# already did its own (API-key/Basic) auth — proving the omission.
#
# The fix has two layers:
#   1. a context_getter that resolves the caller's identity into
#      context["user"] (session Bearer / Basic / guest-in-dev via
#      api.deps.get_current_user; X-API-Key / PV Basic via
#      get_api_key_or_ad_user as fallback) WITHOUT hard-failing the request,
#      because publishedViewData must keep doing its own API-key auth;
#   2. per-resolver enforcement — every management resolver requires an
#      authenticated non-api_consumer user and applies the same ownership
#      visibility rule the REST endpoints use.

async def build_graphql_context(request=None) -> dict:
    """Resolve the caller's identity for GraphQL resolvers.  Never raises —
    unauthenticated callers get context["user"] = None and each resolver
    decides (publishedViewData does its own API-key auth downstream)."""
    import asyncio as _aio
    user = None
    if request is not None:
        try:
            from api.deps import get_current_user as _gcu
            user = await _aio.to_thread(_gcu, request)
        except Exception:
            user = None
        if user is None:
            try:
                from api.deps import get_api_key_or_ad_user as _gaku
                user = await _aio.to_thread(_gaku, request)
            except Exception:
                user = None
    return {"request": request, "user": user}


def _gql_current_user(info) -> dict:
    """Return the authenticated user for a management resolver or raise.

    Raising inside a Strawberry resolver surfaces as a GraphQL error entry
    with a null data field — the standard GraphQL auth-failure shape.
    API-key principals (role=api_consumer) are Published-View consumers and
    have no business in management queries — they keep publishedViewData.
    """
    ctx = getattr(info, "context", None)
    user = ctx.get("user") if isinstance(ctx, dict) else None
    if not user:
        raise Exception("Authentication required")
    if user.get("role") == "api_consumer":
        raise Exception("API-key credentials can only use publishedViewData")
    # 2026-10-24 (security review, when /graphql became reachable again): the
    # management resolvers answer "who may see this" with _gql_row_visible, a
    # generic rule weaker than the REST rules it predates (connections are
    # admin-only, feeds / reports / datasets have their own view rules,
    # workspaces were not filtered at all).  Two answers to one question is the
    # bug -- so the management surface is ADMIN-only (an admin sees all of it on
    # REST too) and everyone else is pointed at the REST API, whose rules are
    # the product's.  publishedViewData keeps its own consumer auth.
    if not _gql_is_admin(user):
        raise Exception("The GraphQL management queries are for administrators; use the "
                        "REST API (/api/...), whose access rules apply to you")
    # 2026-10-31 -- tool entitlement: the management surface is the capability
    # ``published_api.manage`` (admins on day one), the same decision the REST
    # routes make; a GraphQL error carries the plain refusal
    from fastapi import HTTPException as _HTTPException
    from api.deps import check_capability as _check_capability
    try:
        _check_capability(user, "published_api.manage")
    except _HTTPException as exc:
        raise Exception(str(exc.detail)) from exc
    return user


def _gql_is_admin(user: dict) -> bool:
    from core.roles import is_admin_like
    return is_admin_like(user)


def _gql_row_visible(row: Optional[dict], user: dict,
                     owner_keys=("created_by", "owner"),
                     strict: bool = False) -> bool:
    """Ownership visibility mirroring the REST RLS rules.

    Default: visible when admin, owner, shared/public, or legacy-unowned.
    strict=True: visible ONLY to admin or exact owner (used for executions,
    matching REST /api/executions' executed_by filter)."""
    if not row:
        return False
    if _gql_is_admin(user):
        return True
    username = user.get("username", "")
    owner = None
    for k in owner_keys:
        v = row.get(k)
        if v:
            owner = str(v)
            break
    if strict:
        return bool(owner) and owner == username
    if not owner:
        return True   # legacy rows with no recorded owner stay org-visible
    if owner == username:
        return True
    return bool(row.get("is_shared") or row.get("is_public"))


def _gql_require_analyst(user: dict) -> None:
    """Mutations / execution require analyst-tier (parity with REST
    require_role('admin', 'analyst'))."""
    if user.get("role") not in ("admin", "analyst", "super_admin"):
        raise Exception("Requires role: admin or analyst")


# ── Lazy init — defer Strawberry import until first use ──────────────────────
_graphql_app = None


def get_graphql_router():
    """Return the Strawberry FastAPI GraphQLRouter, creating it on first call."""
    global _graphql_app
    if _graphql_app is not None:
        return _graphql_app

    try:
        import strawberry
        from strawberry.fastapi import GraphQLRouter
        from strawberry.types import Info
        # resolvers' ``info: Info`` is recognised when each DECORATOR runs, from
        # the string annotation and the module globals (see the note at the
        # schema below) -- so Info must be there before the first one does
        globals()["Info"] = Info
    except ImportError:
        logger.warning("strawberry-graphql not installed — GraphQL endpoint disabled")
        from fastapi import APIRouter
        _graphql_app = APIRouter()
        return _graphql_app

    # ══════════════════════════════════════════════════════════════════════════
    # Strawberry Type Definitions
    # ══════════════════════════════════════════════════════════════════════════

    @strawberry.type
    class ConnectionType:
        id: int
        name: str
        connection_type: str
        is_active: bool
        created_at: Optional[str] = None
        created_by: Optional[str] = None
        description: Optional[str] = None

    @strawberry.type
    class SavedQueryType:
        id: int
        name: str
        description: Optional[str] = None
        created_by: Optional[str] = None
        created_at: Optional[str] = None
        updated_at: Optional[str] = None
        is_active: bool = True
        is_favorite: bool = False
        is_shared: bool = False
        execution_count: int = 0
        last_executed_at: Optional[str] = None

    @strawberry.type
    class ExecutionType:
        id: int
        execution_id: str
        status: str
        started_at: Optional[str] = None
        completed_at: Optional[str] = None
        total_rows: int = 0
        file_size_bytes: int = 0
        error_message: Optional[str] = None
        executed_by: Optional[str] = None

    @strawberry.type
    class UserType:
        username: str
        role: str
        display_name: Optional[str] = None
        is_admin: bool = False

    @strawberry.type
    class DashboardType:
        id: int
        name: str
        description: Optional[str] = None
        created_by: Optional[str] = None
        created_at: Optional[str] = None
        is_active: bool = True

    @strawberry.type
    class WorkspaceType:
        id: int
        name: str
        slug: str
        description: Optional[str] = None
        is_default: bool = False

    @strawberry.type
    class ScheduleType:
        id: int
        name: str
        cron_expression: Optional[str] = None
        is_active: bool = True
        next_run_at: Optional[str] = None
        last_run_at: Optional[str] = None

    @strawberry.type
    class DeleteResult:
        success: bool
        message: str

    @strawberry.type
    class PaginatedExecutions:
        items: List[ExecutionType]
        total: int

    # ── Phase 90 New Types ─────────────────────────────────────────────────────

    @strawberry.type
    class ParamDefinitionType:
        """Parameter definition for a Published View."""
        name: str
        type: str = "string"
        required: bool = False
        default_value: Optional[str] = None
        description: Optional[str] = None

    @strawberry.type
    class PublishedViewType:
        id: int
        slug: str
        name: str
        description: Optional[str] = None
        is_active: bool = True
        allowed_filters: List[str] = strawberry.field(default_factory=list)
        param_definitions: List[ParamDefinitionType] = strawberry.field(default_factory=list)
        default_limit: int = 1000
        max_limit: int = 50000
        cache_ttl_seconds: int = 300
        created_by: Optional[str] = None
        created_at: Optional[str] = None

    @strawberry.type
    class FeedType:
        id: int
        name: str
        description: Optional[str] = None
        is_active: bool = True
        destination_type: str = "local"  # s3, sftp, local
        schedule_cron: Optional[str] = None
        last_execution_id: Optional[int] = None
        next_run_at: Optional[str] = None
        run_count: int = 0
        created_by: Optional[str] = None
        created_at: Optional[str] = None

    @strawberry.type
    class DatasetType:
        id: int
        name: str
        description: Optional[str] = None
        is_active: bool = True
        connection_id: Optional[int] = None
        subject: Optional[str] = None
        owner: Optional[str] = None
        created_at: Optional[str] = None

    @strawberry.type
    class BusinessReportType:
        id: int
        name: str
        description: Optional[str] = None
        is_active: bool = True
        dataset_id: Optional[int] = None
        owner: Optional[str] = None
        is_published: bool = False
        execution_count: int = 0
        created_at: Optional[str] = None

    @strawberry.type
    class SystemAccountType:
        id: int
        name: str
        account_type: str
        username: str
        is_active: bool = True
        last_status: Optional[str] = None
        last_used_at: Optional[str] = None
        created_by: Optional[str] = None
        created_at: Optional[str] = None

    @strawberry.type
    class CatalogTableType:
        table_path: str
        table_name: str
        connection_id: int
        connection_name: str
        format: str
        estimated_rows: Optional[int] = None
        partition_columns: List[str] = strawberry.field(default_factory=list)
        sample_files: int = 0

    # ── Response Format Enum (Phase 90) ───────────────────────────────────────

    # ONE class per process (2026-10-26): the builder runs more than once (at
    # import, and again wherever a router is built), and a NEW enum class per
    # build left a schema whose argument default was an instance of the
    # previous build's class -- Strawberry 0.335 refuses to print it ("Enum
    # 'ResponseFormat' cannot represent value").
    ResponseFormat = _response_format_enum()

    # ── Published View Data Types ──────────────────────────────────────────────

    @strawberry.input
    class ParamInput:
        """Runtime parameter for Published View execution.

        Equivalent REST form: ``?<name>=<value>`` (bare, Phase 132.36) or
        ``?param[<name>]=<value>`` for reserved-name collisions.  In
        GraphQL just pass ``{name, value}`` pairs — no URL syntax to
        worry about.
        """
        name: str
        value: str

    @strawberry.input
    class ViewFilterInput:
        """Runtime filter for Published View: filter[column]=operator:value."""
        column: str
        operator: str = "eq"  # eq, ne, gt, gte, lt, lte, in, not_in, contains, between
        value: str = ""

    @strawberry.type
    class ViewColumnMeta:
        """Column metadata from Published View results."""
        name: str
        type: str = "string"

    @strawberry.type
    class ViewEntitlementDimension:
        """One data-entitlement dimension that narrowed (or would narrow) the
        rows -- its name and the caller's access only (never the tables or the
        physical columns behind the API; security review 2026-10-24)."""
        name: str
        # values | all | none | everything_by_rule
        access: str = "values"
        values: List[str] = strawberry.field(default_factory=list)
        value_count: int = 0
        values_listed: bool = True

    @strawberry.type
    class ViewEntitlement:
        """What this answer was filtered by -- the REST envelope's
        ``meta.entitlement`` (2026-10-24, core/row_security/disclosure.py).
        ``state``: applied | not_applied | unknown; ``applied`` is null when
        unknown; ``reason`` names why not / why unknown."""
        state: str
        applied: Optional[bool] = None
        reason: Optional[str] = None
        mode: str = "apply"
        principal_type: str = "unknown"
        principal_id: Optional[str] = None
        dimensions: List[ViewEntitlementDimension] = strawberry.field(default_factory=list)
        note: str = ""

    @strawberry.type
    class ViewDataResult:
        """Published View query results — mirrors REST /api/v1/views/{slug}/data."""
        slug: str
        total_rows: int
        returned_rows: int
        offset: int = 0
        columns: List[ViewColumnMeta] = strawberry.field(default_factory=list)
        rows: List[ResultRow] = strawberry.field(default_factory=list)
        cached: bool = False
        execution_ms: int = 0
        error_message: Optional[str] = None
        cache_age_seconds: int = 0
        version: int = 1
        request_id: str = ""
        # 2026-08 bulk discovery (additive — existing queries are unaffected).
        # ``has_more`` tells a consumer the page stopped short of the dataset;
        # ``bulk_stream_url`` tells it where unbounded, chunk-bounded streaming
        # lives.  GraphQL itself stays capped: it returns one materialized JSON
        # document, so it cannot serve a 10M-row pull at any cap.
        has_more: bool = False
        bulk_stream_url: str = ""
        # 2026-08-22 — a dataset capped at `published_views.dataset_row_cap`
        # reports total_rows = THE CAP.  Without these, a 70M-row view is
        # indistinguishable over the wire from a 1M-row one: same total_rows,
        # same has_more=false on the final page.  `total_is_exact` false means
        # total_rows is a LOWER BOUND and the full result is reachable only
        # through `bulk_stream_url`.
        total_is_exact: bool = True
        dataset_truncated: bool = False
        # 2026-10-24 -- the materialization these rows came from; send it back
        # as datasetVersion on every later page (a changed one is an error)
        dataset_version: str = ""
        # 2026-10-24 -- the entitlement disclosure (None on an error result)
        entitlement: Optional[ViewEntitlement] = None

    # ── Helper: dict → strawberry type ────────────────────────────────────────

    def _to_entitlement(d) -> Optional[ViewEntitlement]:
        if not isinstance(d, dict):
            return None
        principal = d.get("principal") or {}
        return ViewEntitlement(
            state=str(d.get("state") or "unknown"),
            applied=d.get("applied"),
            reason=d.get("reason"),
            mode=str(d.get("mode") or "apply"),
            principal_type=str(principal.get("type") or "unknown"),
            principal_id=(None if principal.get("id") is None else str(principal.get("id"))),
            dimensions=[ViewEntitlementDimension(
                name=str(x.get("name") or "?"),
                access=str(x.get("access") or "values"),
                values=[str(v) for v in (x.get("values") or [])],
                value_count=int(x.get("value_count") or 0),
                values_listed=bool(x.get("values_listed", True)),
            ) for x in (d.get("dimensions") or [])],
            note=str(d.get("note") or ""),
        )

    def _to_connection(d: dict) -> ConnectionType:
        return ConnectionType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            connection_type=d.get("connection_type", ""),
            is_active=d.get("is_active", True),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
            created_by=d.get("created_by"),
            description=d.get("description"),
        )

    def _to_query(d: dict) -> SavedQueryType:
        return SavedQueryType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            description=d.get("description"),
            created_by=d.get("created_by"),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
            updated_at=str(d["updated_at"]) if d.get("updated_at") else None,
            is_active=d.get("is_active", True),
            is_favorite=d.get("is_favorite", False),
            is_shared=d.get("is_shared", False),
            execution_count=d.get("execution_count", 0),
            last_executed_at=str(d["last_executed_at"]) if d.get("last_executed_at") else None,
        )

    def _to_execution(d: dict) -> ExecutionType:
        return ExecutionType(
            id=d.get("id", 0),
            execution_id=d.get("execution_id", ""),
            status=d.get("status", "unknown"),
            started_at=str(d["started_at"]) if d.get("started_at") else None,
            completed_at=str(d["completed_at"]) if d.get("completed_at") else None,
            total_rows=d.get("total_rows", 0),
            file_size_bytes=d.get("file_size_bytes", 0),
            error_message=d.get("error_message"),
            executed_by=d.get("executed_by"),
        )

    def _to_dashboard(d: dict) -> DashboardType:
        return DashboardType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            description=d.get("description"),
            created_by=d.get("created_by"),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
            is_active=d.get("is_active", True),
        )

    def _to_workspace(d: dict) -> WorkspaceType:
        return WorkspaceType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            slug=d.get("slug", ""),
            description=d.get("description"),
            is_default=d.get("is_default", False),
        )

    def _to_schedule(d: dict) -> ScheduleType:
        return ScheduleType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            cron_expression=d.get("cron_expression"),
            is_active=d.get("is_active", True),
            next_run_at=str(d["next_run_at"]) if d.get("next_run_at") else None,
            last_run_at=str(d["last_run_at"]) if d.get("last_run_at") else None,
        )

    # ── Phase 90 mapper helpers ────────────────────────────────────────────────

    def _to_published_view(d: dict) -> PublishedViewType:
        # P4 (2026-08-17): rows may carry NULL limits (follow live config) —
        # surface the EFFECTIVE serve-time values, not None.
        try:
            from api.published_views.helpers import resolve_view_limits as _rvl
            _eff_d, _eff_m = _rvl(d)
        except Exception:
            _eff_d = d.get("default_limit") if d.get("default_limit") is not None else 1000
            _eff_m = d.get("max_limit") if d.get("max_limit") is not None else 50000
        pv = PublishedViewType(
            id=d.get("id", 0),
            slug=d.get("slug", ""),
            name=d.get("name", ""),
            description=d.get("description"),
            is_active=d.get("is_active", True),
            allowed_filters=d.get("allowed_filters") or [],
            default_limit=_eff_d,
            max_limit=_eff_m,
            cache_ttl_seconds=d.get("cache_ttl_seconds", 300),
            created_by=d.get("created_by"),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
        )
        # Enrich with param_definitions if available
        param_defs = d.get("param_definitions") or []
        pv.param_definitions = [
            ParamDefinitionType(
                name=p.get("name", ""),
                type=p.get("type", "string"),
                required=p.get("required", False),
                default_value=str(p["default"]) if p.get("default") is not None else None,
                description=p.get("description"),
            )
            for p in param_defs
        ]
        return pv

    def _to_feed(d: dict) -> FeedType:
        return FeedType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            description=d.get("description"),
            is_active=d.get("is_active", True),
            destination_type=d.get("destination_type", "local"),
            schedule_cron=d.get("cron_expression"),
            last_execution_id=d.get("last_execution_id"),
            next_run_at=str(d["next_run_at"]) if d.get("next_run_at") else None,
            run_count=d.get("run_count", 0),
            created_by=d.get("created_by"),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
        )

    def _to_dataset(d: dict) -> DatasetType:
        # BusinessDataset uses 'owner' and 'connection_ids' (list).
        # We expose connection_id as the first entry for simplicity.
        conn_ids = d.get("connection_ids") or []
        first_conn = conn_ids[0] if conn_ids else None
        return DatasetType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            description=d.get("description"),
            is_active=d.get("is_published", True),  # datasets use is_published
            connection_id=first_conn,
            subject=d.get("subject"),
            owner=d.get("owner"),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
        )

    def _to_business_report(d: dict) -> BusinessReportType:
        return BusinessReportType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            description=d.get("description"),
            is_active=d.get("is_published", False),
            dataset_id=d.get("dataset_id"),
            owner=d.get("owner"),
            is_published=d.get("is_published", False),
            execution_count=d.get("execution_count", 0),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
        )

    def _to_system_account(d: dict) -> SystemAccountType:
        return SystemAccountType(
            id=d.get("id", 0),
            name=d.get("name", ""),
            account_type=d.get("account_type", ""),
            username=d.get("username", ""),
            is_active=d.get("is_active", True),
            last_status=d.get("last_status"),
            last_used_at=str(d["last_used_at"]) if d.get("last_used_at") else None,
            created_by=d.get("created_by"),
            created_at=str(d["created_at"]) if d.get("created_at") else None,
        )

    # ══════════════════════════════════════════════════════════════════════════
    # Query Root
    # ══════════════════════════════════════════════════════════════════════════

    @strawberry.type
    class Query:
        # SECURITY AUDIT 2026-08-03 (S1): every management resolver requires an
        # authenticated user (context["user"] via build_graphql_context) and
        # applies the same ownership visibility rule as the REST endpoints.
        # publishedViewData (QueryExt) keeps its own API-key/Basic auth.

        # ── Connections ───────────────────────────────────────────────────────
        @strawberry.field(description="List data connections")
        def connections(self, info: Info, active_only: bool = True) -> List[ConnectionType]:
            user = _gql_current_user(info)
            rows = _db_manager.list_connections(active_only=active_only)
            return [_to_connection(r) for r in rows if _gql_row_visible(r, user)]

        @strawberry.field(description="Get a single connection by ID")
        def connection(self, info: Info, id: int) -> Optional[ConnectionType]:
            user = _gql_current_user(info)
            row = _db_manager.get_connection(id)
            return _to_connection(row) if row and _gql_row_visible(row, user) else None

        # ── Saved Queries ─────────────────────────────────────────────────────
        @strawberry.field(description="List saved queries")
        def queries(self, info: Info, active_only: bool = True) -> List[SavedQueryType]:
            user = _gql_current_user(info)
            rows = _db_manager.list_queries(active_only=active_only)
            return [_to_query(r) for r in rows if _gql_row_visible(r, user)]

        @strawberry.field(description="Get a single saved query by ID")
        def query(self, info: Info, id: int) -> Optional[SavedQueryType]:
            user = _gql_current_user(info)
            row = _db_manager.get_query(id)
            return _to_query(row) if row and _gql_row_visible(row, user) else None

        # ── Executions ────────────────────────────────────────────────────────
        @strawberry.field(description="List query executions")
        def executions(
            self,
            info: Info,
            limit: int = 50,
            offset: int = 0,
            status: Optional[str] = None,
        ) -> PaginatedExecutions:
            user = _gql_current_user(info)
            rows = _db_manager.list_executions(limit=limit, offset=offset, status=status)
            rows = [r for r in rows
                    if _gql_row_visible(r, user, owner_keys=("executed_by",), strict=True)]
            return PaginatedExecutions(
                items=[_to_execution(r) for r in rows],
                total=len(rows),
            )

        @strawberry.field(description="Get a single execution by ID")
        def execution(self, info: Info, execution_id: str) -> Optional[ExecutionType]:
            user = _gql_current_user(info)
            row = _db_manager.get_execution(execution_id)
            if row and _gql_row_visible(row, user, owner_keys=("executed_by",), strict=True):
                return _to_execution(row)
            return None

        # (FB-60, 2026-09-26: the legacy parametric ``reports`` / ``report``
        # fields are gone; ``businessReports`` / ``businessReport`` below are
        # the successor.)

        # ── Dashboards ────────────────────────────────────────────────────────
        @strawberry.field(description="List dashboards")
        def dashboards(self, info: Info) -> List[DashboardType]:
            user = _gql_current_user(info)
            try:
                rows = _db_manager.list_dashboards()
                return [_to_dashboard(r) for r in rows if _gql_row_visible(r, user)]
            except Exception:
                return []

        # ── Workspaces ────────────────────────────────────────────────────────
        @strawberry.field(description="List workspaces")
        def workspaces(self, info: Info) -> List[WorkspaceType]:
            _gql_current_user(info)
            try:
                rows = _db_manager.list_workspaces()
                return [_to_workspace(r) for r in rows]
            except Exception:
                return []

        # ── Schedules ─────────────────────────────────────────────────────────
        @strawberry.field(description="List schedules")
        def schedules(self, info: Info) -> List[ScheduleType]:
            user = _gql_current_user(info)
            try:
                rows = _db_manager.list_schedules()
                return [_to_schedule(r) for r in rows if _gql_row_visible(r, user)]
            except Exception:
                return []

        # ── Phase 90: Published Views ─────────────────────────────────────────
        @strawberry.field(description="List published views")
        def published_views(self, info: Info, active_only: bool = True) -> List[PublishedViewType]:
            user = _gql_current_user(info)
            try:
                rows = _db_manager.list_published_views()
                rows = [r for r in rows if _gql_row_visible(r, user)]
                result = [_to_published_view(r) for r in rows]
                if active_only:
                    result = [v for v in result if v.is_active]
                return result
            except Exception:
                return []

        @strawberry.field(description="Get a single published view by ID")
        def published_view(self, info: Info, id: int) -> Optional[PublishedViewType]:
            user = _gql_current_user(info)
            try:
                row = _db_manager.get_published_view(id)
                return _to_published_view(row) if row and _gql_row_visible(row, user) else None
            except Exception:
                return None

        # ── Phase 90: Feeds ───────────────────────────────────────────────────
        @strawberry.field(description="List feed configurations")
        def feeds(self, info: Info, active_only: bool = True) -> List[FeedType]:
            user = _gql_current_user(info)
            try:
                rows = _db_manager.list_feed_configs()
                rows = [r for r in rows if _gql_row_visible(r, user)]
                result = [_to_feed(r) for r in rows]
                if active_only:
                    result = [f for f in result if f.is_active]
                return result
            except Exception:
                return []

        @strawberry.field(description="Get a single feed configuration by ID")
        def feed(self, info: Info, id: int) -> Optional[FeedType]:
            user = _gql_current_user(info)
            try:
                row = _db_manager.get_feed_config(id)
                return _to_feed(row) if row and _gql_row_visible(row, user) else None
            except Exception:
                return None

        # ── Phase 90: Datasets (Semantic Layer) ───────────────────────────────
        @strawberry.field(description="List datasets (semantic layer)")
        def datasets(self, info: Info) -> List[DatasetType]:
            user = _gql_current_user(info)
            try:
                rows = _db_manager.list_datasets()
                return [_to_dataset(r) for r in rows if _gql_row_visible(r, user)]
            except Exception:
                return []

        @strawberry.field(description="Get a single dataset by ID")
        def dataset(self, info: Info, id: int) -> Optional[DatasetType]:
            user = _gql_current_user(info)
            try:
                row = _db_manager.get_dataset(id)
                return _to_dataset(row) if row and _gql_row_visible(row, user) else None
            except Exception:
                return None

        # ── Phase 90: Business Reports ────────────────────────────────────────
        @strawberry.field(description="List business reports")
        def business_reports(self, info: Info, active_only: bool = False) -> List[BusinessReportType]:
            user = _gql_current_user(info)
            try:
                rows = _db_manager.list_business_reports()
                rows = [r for r in rows if _gql_row_visible(r, user)]
                result = [_to_business_report(r) for r in rows]
                if active_only:
                    result = [r for r in result if r.is_active]
                return result
            except Exception:
                return []

        @strawberry.field(description="Get a single business report by ID")
        def business_report(self, info: Info, id: int) -> Optional[BusinessReportType]:
            user = _gql_current_user(info)
            try:
                row = _db_manager.get_business_report(id)
                return _to_business_report(row) if row and _gql_row_visible(row, user) else None
            except Exception:
                return None

        # ── Phase 90: System Accounts (admin) ─────────────────────────────────
        @strawberry.field(description="List system accounts (admin only — passwords masked)")
        def system_accounts(self, info: Info) -> List[SystemAccountType]:
            user = _gql_current_user(info)
            if not _gql_is_admin(user):
                raise Exception("Admin access required")
            try:
                rows = _db_manager.list_system_accounts(active_only=False)
                return [_to_system_account(r) for r in rows]
            except Exception:
                return []

        # ── Phase 90: Catalog Tables (metadata) ───────────────────────────────
        @strawberry.field(description="Query catalog tables (connection metadata)")
        def catalog_tables(self, info: Info, connection_id: Optional[int] = None) -> List[CatalogTableType]:
            user = _gql_current_user(info)
            try:
                conns = _db_manager.list_connections(active_only=True)
                result = []
                for c in conns:
                    if connection_id and c.get("id") != connection_id:
                        continue
                    if not _gql_row_visible(c, user):
                        continue
                    result.append(CatalogTableType(
                        table_path=c.get("name", ""),
                        table_name=c.get("name", ""),
                        connection_id=c.get("id", 0),
                        connection_name=c.get("name", ""),
                        format=c.get("connection_type", "s3").upper(),
                        estimated_rows=None,
                        partition_columns=[],
                        sample_files=0,
                    ))
                return result
            except Exception:
                return []

    # ══════════════════════════════════════════════════════════════════════════
    # Mutation Root
    # ══════════════════════════════════════════════════════════════════════════

    @strawberry.input
    class SaveQueryInput:
        name: str
        description: Optional[str] = None
        query_config: str  # JSON string — client serialises the config

    @strawberry.input
    class UpdateQueryInput:
        name: Optional[str] = None
        description: Optional[str] = None
        is_favorite: Optional[bool] = None
        is_shared: Optional[bool] = None

    def _require_owner_or_admin(user: dict, row: Optional[dict],
                                owner_keys=("created_by", "owner")) -> None:
        """Mutations require the actual owner (or admin) — is_shared grants
        READ visibility, never edit/delete rights."""
        if row is None:
            return  # not-found handled by the caller
        if _gql_is_admin(user):
            return
        owner = None
        for k in owner_keys:
            v = row.get(k)
            if v:
                owner = str(v)
                break
        if owner and owner != user.get("username"):
            raise Exception("Not authorized: you do not own this object")

    @strawberry.type
    class Mutation:
        # SECURITY AUDIT 2026-08-03 (S1): mutations now require an
        # authenticated analyst/admin and object ownership.
        # ── Saved Queries ─────────────────────────────────────────────────────
        @strawberry.mutation(description="Create a saved query")
        def create_query(self, info: Info, input: SaveQueryInput) -> SavedQueryType:
            import json
            user = _gql_current_user(info)
            _gql_require_analyst(user)
            config = json.loads(input.query_config)
            row = _db_manager.create_query(
                name=input.name,
                query_config=config,
                description=input.description,
                created_by=user.get("username", "graphql_user"),
            )
            return _to_query(row)

        @strawberry.mutation(description="Update a saved query")
        def update_query(self, info: Info, id: int, input: UpdateQueryInput) -> Optional[SavedQueryType]:
            user = _gql_current_user(info)
            _gql_require_analyst(user)
            existing = _db_manager.get_query(id)
            if not existing:
                return None
            _require_owner_or_admin(user, existing)
            updates = {}
            if input.name is not None:
                updates["name"] = input.name
            if input.description is not None:
                updates["description"] = input.description
            if input.is_favorite is not None:
                updates["is_favorite"] = input.is_favorite
            if input.is_shared is not None:
                updates["is_shared"] = input.is_shared
            row = _db_manager.update_query(id, **updates)
            return _to_query(row) if row else None

        @strawberry.mutation(description="Delete a saved query (soft delete)")
        def delete_query(self, info: Info, id: int) -> DeleteResult:
            user = _gql_current_user(info)
            _gql_require_analyst(user)
            existing = _db_manager.get_query(id)
            if not existing:
                return DeleteResult(success=False, message="Not found")
            _require_owner_or_admin(user, existing)
            ok = _db_manager.delete_query(id, soft_delete=True)
            return DeleteResult(success=ok, message="Deleted" if ok else "Not found")

        # ── Connections ───────────────────────────────────────────────────────
        @strawberry.mutation(description="Delete a connection (soft delete)")
        def delete_connection(self, info: Info, id: int) -> DeleteResult:
            user = _gql_current_user(info)
            _gql_require_analyst(user)
            existing = _db_manager.get_connection(id)
            if not existing:
                return DeleteResult(success=False, message="Not found")
            _require_owner_or_admin(user, existing)
            ok = _db_manager.delete_connection(id, soft_delete=True)
            return DeleteResult(success=ok, message="Deleted" if ok else "Not found")

    # ══════════════════════════════════════════════════════════════════════════
    # ExecuteQuery types (Phase 22F + Phase 90 extensions)
    # ══════════════════════════════════════════════════════════════════════════

    @strawberry.type
    class ExecuteResult:
        execution_id: str
        status: str
        message: str = ""
        download_url: Optional[str] = None   # Phase 90: CSV/Parquet download link

    @strawberry.type
    class ResultRow:
        """One data row returned as a JSON string (columns vary per query)."""
        json: str

    @strawberry.type
    class ExecutionResults:
        execution_id: str
        status: str
        columns: List[str]
        rows: List[ResultRow]
        total_rows: int
        returned_rows: int
        error_message: Optional[str] = None
        download_url: Optional[str] = None   # Phase 90: populated for csv/parquet formats
        format: str = "json"                  # Phase 90: format used

    # ── Extend Query with executionResults ────────────────────────────────────

    @strawberry.type
    class QueryExt(Query):
        @strawberry.field(description=(
            "Read rows from a completed execution's output parquet file. "
            "Use format=JSON (default) for inline rows, or format=CSV/PARQUET "
            "to receive a download_url instead."
        ))
        def execution_results(
            self,
            info: Info,
            execution_id: str,
            limit: int = 1000,
            offset: int = 0,
            format: ResponseFormat = ResponseFormat.JSON,
        ) -> ExecutionResults:
            import json as _json
            # SECURITY AUDIT 2026-08-03 (S1): auth + executed_by ownership —
            # result rows are the most sensitive payload on this schema.
            user = _gql_current_user(info)
            rec = _db_manager.get_execution(execution_id)
            if rec and not _gql_row_visible(rec, user, owner_keys=("executed_by",), strict=True):
                rec = None
            if not rec:
                return ExecutionResults(
                    execution_id=execution_id, status="not_found",
                    columns=[], rows=[], total_rows=0, returned_rows=0,
                    error_message="Execution not found",
                    format=str(format.value) if hasattr(format, "value") else str(format),
                )
            status = rec.get("status", "unknown")
            fmt_str = str(format.value) if hasattr(format, "value") else str(format)

            if status != "completed":
                return ExecutionResults(
                    execution_id=execution_id, status=status,
                    columns=[], rows=[], total_rows=rec.get("total_rows", 0),
                    returned_rows=0,
                    error_message=rec.get("error_message"),
                    format=fmt_str,
                )
            output_file = rec.get("output_file")
            if not output_file:
                return ExecutionResults(
                    execution_id=execution_id, status="completed",
                    columns=[], rows=[], total_rows=0, returned_rows=0,
                    error_message="No output file",
                    format=fmt_str,
                )

            # Phase 90: for CSV or PARQUET, return a download URL rather than inline rows
            if fmt_str in ("csv", "parquet"):
                dl_url = f"/api/executions/{execution_id}/download?format={fmt_str}"
                return ExecutionResults(
                    execution_id=execution_id, status="completed",
                    columns=[], rows=[],
                    total_rows=rec.get("total_rows", 0),
                    returned_rows=0,
                    download_url=dl_url,
                    format=fmt_str,
                )

            # JSON: existing inline behaviour
            try:
                from core.duckdb_factory import duckdb_connection
                with duckdb_connection() as con:
                    # Get column names
                    col_res = con.execute(
                        f"DESCRIBE SELECT * FROM read_parquet('{output_file}') LIMIT 1"
                    ).fetchall()
                    columns = [r[0] for r in col_res]
                    # Fetch page of rows
                    rows_res = con.execute(
                        f"SELECT * FROM read_parquet('{output_file}') LIMIT {limit} OFFSET {offset}"
                    ).fetchall()
                rows = [ResultRow(json=_json.dumps(dict(zip(columns, r)), default=str)) for r in rows_res]
                return ExecutionResults(
                    execution_id=execution_id, status="completed",
                    columns=columns, rows=rows,
                    total_rows=rec.get("total_rows", len(rows)),
                    returned_rows=len(rows),
                    format=fmt_str,
                )
            except Exception as exc:
                return ExecutionResults(
                    execution_id=execution_id, status="error",
                    columns=[], rows=[], total_rows=0, returned_rows=0,
                    error_message=str(exc),
                    format=fmt_str,
                )

        @strawberry.field(description=(
            "Query Published View data with parameters and filters. "
            "Equivalent to GET /api/v1/views/{slug}/data?<name>=<value>&filter.<col>=<op>:<val>. "
            "Returns typed rows inline (like REST JSON format). "
            "Requires X-API-Key or Basic auth header."
        ))
        async def published_view_data(
            self,
            info: Info,
            slug: str,
            params: Optional[List[ParamInput]] = None,
            filters: Optional[List[ViewFilterInput]] = None,
            columns: Optional[List[str]] = None,
            sort_column: Optional[str] = None,
            sort_dir: str = "asc",
            limit: int = 1000,
            offset: int = 0,
            dataset_version: Optional[str] = None,
        ) -> ViewDataResult:

            # Extract request from Strawberry context
            request = info.context.get("request") if info and info.context else None

            # Convert Strawberry input types to plain dicts for the resolver
            params_dicts = [{"name": p.name, "value": p.value} for p in params] if params else None
            filters_dicts = [
                {"column": f.column, "operator": f.operator, "value": f.value}
                for f in filters
            ] if filters else None

            # Delegate to module-level resolver (enterprise-hardened, testable)
            result = await _resolve_published_view_data(
                request=request,
                slug=slug,
                params_list=params_dicts,
                filters_list_raw=filters_dicts,
                columns=columns,
                sort_column=sort_column,
                sort_dir=sort_dir,
                limit=limit,
                offset=offset,
                dataset_version=dataset_version,
            )

            # Convert plain dict → Strawberry ViewDataResult
            col_meta = [
                ViewColumnMeta(
                    name=c.get("name", ""), type=c.get("type", "string"),
                ) for c in (result.get("columns") or [])
            ]
            rows = [ResultRow(json=r.get("json", r) if isinstance(r, dict) else str(r))
                    for r in (result.get("rows") or [])]
            return ViewDataResult(
                slug=result.get("slug", slug),
                total_rows=result.get("total_rows", 0),
                returned_rows=result.get("returned_rows", 0),
                offset=result.get("offset", offset),
                columns=col_meta,
                rows=rows,
                cached=result.get("cached", False),
                execution_ms=result.get("execution_ms", 0),
                error_message=result.get("error_message"),
                cache_age_seconds=result.get("cache_age_seconds", 0),
                version=result.get("version", 1),
                request_id=result.get("request_id", ""),
                has_more=bool(result.get("has_more", False)),
                # 2026-08-23 (P6 D13) — a MISSING key must never resolve to
                # the STRONG claim (house rule; same class as the 2026-08-22
                # cache-hit fix).  The module resolver always sets both keys
                # now (_build_result and _err), so this default only fires
                # for a foreign result shape — and then it must say unknown,
                # not exact.
                total_is_exact=bool(result.get("total_is_exact", False)),
                dataset_truncated=bool(result.get("dataset_truncated", False)),
                bulk_stream_url=result.get("bulk_stream_url", ""),
                dataset_version=result.get("dataset_version", ""),
                entitlement=_to_entitlement(result.get("entitlement")),
            )

    # ── Extend Mutation with executeQuery ─────────────────────────────────────

    @strawberry.type
    class MutationExt(Mutation):
        @strawberry.mutation(description=(
            "Submit a SQL query for execution. Returns execution_id to poll. "
            "Pass format=CSV or format=PARQUET to get a download_url in executionResults."
        ))
        async def execute_query(
            self,
            info: Info,
            sql: str,
            connection_id: int,
            limit: int = 1000,
            executed_by: str = "graphql",
        ) -> ExecuteResult:
            # SECURITY AUDIT 2026-08-03 (S1): arbitrary SQL requires an
            # authenticated analyst/admin — parity with REST /api/execute.
            # The caller-supplied executed_by label is overridden with the
            # verified identity so audit rows cannot be forged.
            user = _gql_current_user(info)
            _gql_require_analyst(user)
            executed_by = user.get("username") or executed_by
            # Phase 133-K — clearer error on the published-api pod, where
            # arbitrary-SQL submission isn't a consumer concern.  Direct
            # callers to the publishedViewData query instead so they
            # discover the correct entry point on the first try.
            if _published_api_mode:
                return ExecuteResult(
                    execution_id="",
                    status="error",
                    message=(
                        "executeQuery is not available on the published-api "
                        "endpoint — this pod serves Published Views only. "
                        "Use the publishedViewData query "
                        "(query { publishedViewData(slug: \"<your-slug>\") { rows { json } } }) "
                        "or hit /api/v1/views/<slug>/data via REST."
                    ),
                )
            if _execute_fn is None:
                return ExecuteResult(
                    execution_id="",
                    status="error",
                    message="Execute callback not configured — backend restart required",
                )
            try:
                eid = await _execute_fn(
                    sql=sql,
                    connection_id=connection_id,
                    limit=limit,
                    executed_by=executed_by,
                )
                return ExecuteResult(
                    execution_id=eid,
                    status="pending",
                    message=(
                        "Query submitted. Poll executionResults(executionId) for results. "
                        "Optionally pass format=CSV or format=PARQUET for a download_url."
                    ),
                )
            except Exception as exc:
                return ExecuteResult(execution_id="", status="error", message=str(exc))

    # ══════════════════════════════════════════════════════════════════════════
    # Build schema + router
    # ══════════════════════════════════════════════════════════════════════════

    # 2026-10-24 (rig): every type above is defined INSIDE this function, and
    # ``from __future__ import annotations`` makes each annotation a string
    # that Strawberry resolves against the MODULE's globals when the schema is
    # built -- where the local classes are not.  Strawberry 0.333 refused
    # ("Could not resolve the type of 'connections'"), the router failed to
    # build, main.py logged it at DEBUG and /graphql was simply ABSENT.  The
    # local types are published to the module namespace first (lazy
    # resolution makes that sufficient; nothing else reads these names).
    globals().update({_n: _t for _n, _t in locals().items()
                      if isinstance(_t, type) and not _n.startswith("_")})
    schema = strawberry.Schema(query=QueryExt, mutation=MutationExt)

    # SECURITY AUDIT 2026-08-03 (S1): context_getter resolves the caller's
    # identity ONCE per request into context["user"].  It never hard-fails
    # (publishedViewData keeps doing its own X-API-Key/Basic auth from the
    # raw request); every management resolver enforces auth itself via
    # _gql_current_user().
    from fastapi import Request as _FastAPIRequest
    # resolved from the module globals like every annotation here (a string
    # FastAPI could not resolve made `request` a required QUERY parameter: 422)
    globals()["_FastAPIRequest"] = _FastAPIRequest

    async def _graphql_context_getter(request: _FastAPIRequest) -> dict:
        return await build_graphql_context(request)

    # BOTH /graphql (the documented URL) and /graphql/ answer -- no redirect:
    # a POST to /graphql got a 307 to /graphql/, which urllib, `curl -X POST`
    # without -L and many GraphQL clients do not follow (rig 2026-10-24).
    # One schema, two routes.
    # 2026-10-26: no in-browser IDE and no queries by GET.  Strawberry serves
    # its GraphiQL page to ANY GET by default -- on a login-required
    # deployment an anonymous caller got a 200 (the no-anonymous-reads walk
    # caught it) -- and a GET query is a link anyone can be sent.  Every
    # client here POSTs; GET /graphql now answers 405.
    from fastapi import APIRouter as _APIRouter
    _graphql_app = _APIRouter()
    for _path in ("", "/"):
        _graphql_app.include_router(
            GraphQLRouter(schema, path=_path, context_getter=_graphql_context_getter,
                          graphql_ide=None, allow_queries_via_get=False),
            prefix="/graphql")
    _graphql_app.schema = schema          # the one schema, for introspection / tests

    try:   # strawberry has no __version__ (it raised here, after the schema built)
        from importlib.metadata import version as _dist_version
        _sv = _dist_version("strawberry-graphql")
    except Exception:                                         # noqa: BLE001
        _sv = "unknown"
    logger.info("GraphQL endpoint initialised (Strawberry %s)", _sv)
    return _graphql_app
