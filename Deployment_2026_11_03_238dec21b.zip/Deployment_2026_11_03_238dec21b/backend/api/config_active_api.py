"""Switched-off configuration: ONE list, ONE "Switch on" (owner, 2026-10-30).

Deleting a configuration object switches it off (core/config_active.py).
This router is the one way back, for every configuration table:

  GET  /api/config/switched-off                     what is switched off (admin: all;
                                                    others: what they own)
  POST /api/config/switched-off/{table}/{id}/switch-on

One permission rule (admin, or the row's owner), one name check (an ACTIVE row
of that table already uses the name -> refused, naming it), one audit line.
A table whose switch-on must also do something (a feed's cron back on the
scheduler) registers it in ``ON_SWITCH_ON``.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException

from api.deps import get_current_user, require_capability
from core.config_active import (active_clause, config_tables, is_on, last_switch_off, model_for,
                                name_of, owner_of, switched_off_by)
from core.roles import is_admin_like

logger = logging.getLogger(__name__)
router = APIRouter()

# the word a person uses for each configuration table
WHAT: Dict[str, str] = {
    "agent_config": "assistant setting", "agent_rules": "assistant rule",
    "business_datasets": "dataset", "business_reports": "report",
    "clockwork_jobs": "scheduled job", "clockwork_query_templates": "scheduler query template",
    "column_policies": "column security policy", "custom_background_jobs": "custom job",
    "dashboards": "dashboard", "dataflow_custom_stage_types": "custom dataflow stage",
    "dataflows": "dataflow", "dq_rules": "data quality rule",
    "entitlement_dimensions": "entitlement dimension", "etl_dependency_types": "dependency type",
    "etl_pipeline_configs": "ETL pipeline", "federation_views": "federation view",
    "feed_alert_kinds": "feed alert kind", "feed_alert_routes": "feed alert route",
    "feed_calendars": "business calendar", "feed_configs": "feed",
    "feed_control_file_formats": "control file format", "feed_custom_step_types": "custom feed step",
    "feed_environments": "feed environment", "feed_flows": "feed flow", "feed_groups": "feed group",
    "feed_hold_approvers": "hold approver", "feed_message_fields": "message field",
    "feed_message_tokens": "message token", "feed_restatement_policies": "restatement policy",
    "feed_templates": "feed template", "logical_tables": "logical table",
    "materialized_views": "materialized view", "published_api_alert_thresholds": "API alert threshold",
    "published_views": "published API", "reconciliation_entities": "reconciliation",
    "report_folders": "report folder", "report_tags": "report tag", "rest_query_defs": "REST query",
    "row_level_policies": "row security policy", "sap_task_configs": "SAP task",
    "saved_queries": "saved query", "schedules": "schedule", "sql_files": "SQL file",
    "sql_saved_queries": "saved SQL query", "table_descriptions": "table description",
    "tool_capability_grants": "permission",
    "ui_component_visibility": "screen visibility setting", "user_groups": "user group",
    "value_lists": "value list", "report_themes": "report theme", "report_parameter_templates": "parameter template",
    "watched_iceberg_tables": "watched Iceberg table",
    "workspaces": "workspace",
}

# table -> callable(row_dict, user) run after a row is switched on; may return
# a short note for the person ("Its schedule is back on.")
ON_SWITCH_ON: Dict[str, Callable[[Dict[str, Any], dict], Optional[str]]] = {}
# table -> callable(row_dict, user) run BEFORE a row is switched on; raises
# HTTPException to refuse (a feed whose calendar is gone must not come back on)
BEFORE_SWITCH_ON: Dict[str, Callable[[Dict[str, Any], dict], None]] = {}


def what(table: str) -> str:
    return WHAT.get(table, table.replace("_", " ").rstrip("s"))


def _db():
    from core.database import get_db_manager
    db = get_db_manager()
    if db is None:
        raise HTTPException(status_code=503, detail="The database is not ready yet. Try again in a minute.")
    return db


# The tables a NON-admin owns as a person (an analyst creates, edits and deletes
# their own).  Everything else -- security policies, user groups, schedulers,
# feeds' shared configuration, assistant rules -- is switched on by an admin
# only: "who created it" is not "who may manage it now" (a creator can lose the
# right; a policy's creator must not revive it).  Deny by default.
OWNER_SWITCHABLE = frozenset({
    "business_datasets", "business_reports", "saved_queries", "sql_saved_queries",
    "dashboards", "value_lists",
})
_OWNER_ROLES = frozenset({"analyst"})


def _may_act(user: dict, row, table: str, session) -> bool:
    if is_admin_like(user):
        return True
    if table not in OWNER_SWITCHABLE or (user or {}).get("role") not in _OWNER_ROLES:
        return False
    me = user.get("username")
    owner = owner_of(row)
    if not (owner and owner == me):
        return False
    # an owner undoes only their OWN delete: an admin's takedown of someone's
    # report stays down; not known who -> admins only (security review 2026-10-30)
    return switched_off_by(session, table, row.id) == me


def _when(row) -> Any:
    v = getattr(row, "updated_at", None)
    return v.isoformat() if hasattr(v, "isoformat") else v


def list_switched_off(db, user: dict) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    with db.get_session() as session:
        for table in config_tables():
            model = model_for(table)
            if model is None or not hasattr(model, "is_active"):
                continue
            for row in session.query(model).filter(model.is_active.is_(False)).limit(1000):
                if not _may_act(user, row, table, session):
                    continue
                last = last_switch_off(session, table, row.id)
                at = last[1] if last else None
                out.append({"table": table, "what": what(table), "id": row.id,
                            "name": name_of(row) or f"#{row.id}", "owner": owner_of(row),
                            "switched_off_at": at.isoformat() if hasattr(at, "isoformat") else _when(row),
                            "switched_off_by": (last[0] or None) if last else None})
    out.sort(key=lambda r: (r["what"], (r["name"] or "").lower()))
    return out


def switch_on(db, user: dict, table: str, row_id: int) -> Dict[str, Any]:
    if table not in config_tables():
        raise HTTPException(status_code=404, detail=f"{table!r} is not a configuration table.")
    model = model_for(table)
    with db.get_session() as session:
        row = session.query(model).filter(model.id == row_id).first()
        if row is None:
            raise HTTPException(status_code=404, detail=f"That {what(table)} does not exist.")
        if not _may_act(user, row, table, session):
            raise HTTPException(status_code=403,
                                detail=f"Only an admin can switch this {what(table)} on"
                                       + (" (or its owner)" if table in OWNER_SWITCHABLE else "") + ".")
        if is_on(row):
            raise HTTPException(status_code=409, detail=f"This {what(table)} is already on.")
        check = BEFORE_SWITCH_ON.get(table)
        if check is not None:
            check(row.to_dict() if hasattr(row, "to_dict") else {"id": row.id}, user)
        row.is_active = True
        session.commit()
        data = row.to_dict() if hasattr(row, "to_dict") else {"id": row.id}
        name = name_of(row) or f"#{row.id}"
    hook = ON_SWITCH_ON.get(table)
    note = None
    if hook is not None:
        try:
            note = hook(data, user)
        except Exception as exc:  # the row IS on; say what did not follow
            logger.warning("switch-on follow-up for %s %s failed: %s", table, row_id, exc, exc_info=True)
            note = f"It is on, but this did not follow: {exc}"
    try:
        from core.audit import audit_event
        audit_event(db, user or {}, action="config_switched_on", resource_type=table,
                    resource_id=row_id, details={"name": name})
    except Exception:
        logger.debug("audit of switch-on failed", exc_info=True)
    return {"table": table, "id": row_id, "name": name, "is_active": True,
            "detail": f"{what(table)[:1].upper()}{what(table)[1:]} {name!r} is switched on."
                      + (f" {note}" if note else "")}


@router.get("/api/config/switched-off")
async def get_switched_off(user: dict = Depends(require_capability("account.self"))):
    from core.db_async import adb
    return {"items": await adb(list_switched_off, _db(), user)}


@router.post("/api/config/switched-off/{table}/{row_id}/switch-on")
async def post_switch_on(table: str, row_id: int, user: dict = Depends(require_capability("account.self"))):
    from core.db_async import adb
    return await adb(switch_on, _db(), user, table, row_id)


__all__ = ["router", "ON_SWITCH_ON", "BEFORE_SWITCH_ON", "WHAT", "what", "list_switched_off", "switch_on", "active_clause"]
