"""Row & Column Security admin API — Phase 141.

Endpoints (all admin-gated):

  GET    /api/admin/row-security/policies
  POST   /api/admin/row-security/policies
  GET    /api/admin/row-security/policies/{id}
  PUT    /api/admin/row-security/policies/{id}
  DELETE /api/admin/row-security/policies/{id}

  GET    /api/admin/row-security/column-policies
  POST   /api/admin/row-security/column-policies
  PUT    /api/admin/row-security/column-policies/{id}
  DELETE /api/admin/row-security/column-policies/{id}

  GET    /api/admin/row-security/bindings
  POST   /api/admin/row-security/bindings
  DELETE /api/admin/row-security/bindings/{id}

  POST   /api/admin/row-security/test
  GET    /api/admin/row-security/audit
  POST   /api/admin/row-security/cache/invalidate
  POST   /api/admin/row-security/lake-formation/sync
  GET    /api/admin/row-security/config

  FB-45 (2026-09-20) -- how two row policies on one principal COMPOSE:
  POST   /api/admin/row-security/policies/restamp   explicit, audited reclass
  GET    /api/admin/row-security/composition        per table: classes + shape

HOW POLICIES COMPOSE (the operator-facing statement; the model is
core/row_security/composition.py):

  Each row policy has a ``policy_class``: PERMISSIVE (a grant -- it widens)
  or RESTRICTIVE (a ceiling -- it narrows).  For one principal on one table
  the permissive policies are OR'd, the restrictive policies are AND'd, and
  the two groups are AND'd:  (P1 OR P2) AND (R1 AND R2).

  A policy authored without a class takes ``row_security.policy_composition``:
  permissive (default; Lake Formation / BI-tool semantics), restrictive
  (Oracle VPD / SQL Server semantics, and this engine's behaviour before
  FB-45), or per_policy (every policy must declare -- a request without a
  class is refused, naming the policy).  The stored class is the truth
  thereafter; changing the mode moves no existing policy.

  A principal who matches NO policy: if the table carries a permissive
  policy (a grant exists) they see NO ROWS; if it carries only restrictive
  policies, or none, it is served unrestricted.  Keyed on the classes on
  the table, never on the mode.

  Every policy that existed before FB-45 was stamped restrictive at
  startup, so no upgrade changed anyone's rows.  Reclassifying is
  POST /policies/restamp -- explicit and audited, never a side effect.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from api.deps import require_admin, require_capability
from core.audit import audit_event

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin/row-security", tags=["row-security"])


# ── Pydantic schemas ───────────────────────────────────────────────────────

class RowPolicyCreate(BaseModel):
    name: str
    table_pattern: str
    filter_sql: str
    description: Optional[str] = ""
    connection_id: Optional[int] = None
    enforcement: str = "rewrite"
    enabled: bool = True
    priority: int = 100
    #: FB-45 -- "permissive" (grant, OR'd) | "restrictive" (ceiling, AND'd).
    #: Omitted = the configured row_security.policy_composition default;
    #: refused under per_policy.
    policy_class: Optional[str] = None


class RowPolicyUpdate(BaseModel):
    name: Optional[str] = None
    table_pattern: Optional[str] = None
    filter_sql: Optional[str] = None
    description: Optional[str] = None
    connection_id: Optional[int] = None
    enforcement: Optional[str] = None
    enabled: Optional[bool] = None
    priority: Optional[int] = None
    policy_class: Optional[str] = None


class RestampRequest(BaseModel):
    """The explicit, audited reclassification (FB-45).  ``policy_ids`` names
    the policies; ``all=True`` means every row policy.  One or the other."""
    policy_class: str = Field(..., description="permissive | restrictive")
    policy_ids: Optional[List[int]] = None
    all: bool = False


class ColumnPolicyCreate(BaseModel):
    name: str
    table_pattern: str
    mode: str = Field("exclude", description="include | exclude | mask")
    columns: List[str]
    description: Optional[str] = ""
    connection_id: Optional[int] = None
    mask_expr: Optional[str] = None
    enforcement: str = "rewrite"
    enabled: bool = True
    priority: int = 100


class ColumnPolicyUpdate(BaseModel):
    name: Optional[str] = None
    table_pattern: Optional[str] = None
    mode: Optional[str] = None
    columns: Optional[List[str]] = None
    description: Optional[str] = None
    connection_id: Optional[int] = None
    mask_expr: Optional[str] = None
    enforcement: Optional[str] = None
    enabled: Optional[bool] = None
    priority: Optional[int] = None


class BindingCreate(BaseModel):
    policy_kind: str = Field(..., description="row | column")
    policy_id: int
    principal_type: str = Field(..., description="user | role | group | api_key | system_account | all")
    #: for ``api_key`` the API key's ROW ID (what the keys list shows), never its prefix
    principal_id: str
    priority: int = 100


class TestRequest(BaseModel):
    sql: str
    username: str
    role: str = "analyst"
    groups: List[str] = Field(default_factory=list)
    #: 2026-10-25 -- test AS an API key: the resolved principal ``api_key:<id>``
    #: (row policies bound to it; the API's switch is ``data_policy_mode``)
    api_key_id: Optional[str] = None
    data_policy_mode: str = Field("apply", pattern="^(off|apply)$")
    connection_id: Optional[int] = None
    dialect: str = "duckdb"


class LakeFormationSyncRequest(BaseModel):
    connection_id: int
    databases: Optional[List[str]] = None


# ── Module wiring ───────────────────────────────────────────────────────────

_db_manager = None


def set_row_security_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not ready")
    return _db_manager


async def _adb(fn, *args, **kwargs):
    return await asyncio.to_thread(fn, *args, **kwargs)


def _validate_enforcement(value: str) -> str:
    v = (value or "rewrite").lower()
    if v not in ("rewrite", "view", "native_lf", "audit_only"):
        raise HTTPException(status_code=400, detail="enforcement must be one of: rewrite, view, native_lf, audit_only")
    return v


def _resolve_policy_class(value: Optional[str], policy_name: str) -> str:
    """The class a new policy is STORED with (FB-45).

    An explicit class must be one of the two.  An omitted class takes the
    configured ``row_security.policy_composition`` default; under
    ``per_policy`` there is no default and the request is refused, naming
    the policy, because a policy whose class nobody chose would compose by
    accident.
    """
    from core.row_security.composition import (
        POLICY_CLASSES, composition_mode, default_class_for_new_policy,
        normalise_class,
    )
    if value is not None and str(value).strip():
        cls = normalise_class(value)
        if cls is None:
            raise HTTPException(
                status_code=400,
                detail=f"policy_class must be one of: {', '.join(POLICY_CLASSES)} (got {value!r})")
        return cls
    mode = composition_mode()
    cls = default_class_for_new_policy(mode)
    if cls is None:
        raise HTTPException(
            status_code=400,
            detail=(f"row_security.policy_composition is 'per_policy': policy "
                    f"{policy_name!r} must declare policy_class (permissive | "
                    f"restrictive); there is no default to fall back on."))
    return cls


def _contradiction_warnings_for(policy: Dict[str, Any]) -> List[str]:
    """FB-45 (spec section 5): warn when two RESTRICTIVE policies on the same
    table constrain one column with disjoint equality values -- they AND
    together and a principal bound to both sees zero rows, silently.  A
    cheap syntactic check that says so in its text; never a refusal."""
    try:
        from core.row_security.contradiction import contradiction_warnings
        db = _db()
        others = db.list_row_policies(enabled_only=True) or []
        bindings = db.list_policy_bindings(policy_kind="row") or []
        return contradiction_warnings(policy, others, bindings)
    except HTTPException:
        raise
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("row_security: contradiction check skipped: %s", exc)
        return []


def _with_contradictions(policy: Dict[str, Any], extra: List[str]) -> Dict[str, Any]:
    """FB-45 contradiction advice on a policy response; the engine-off
    warning is layered on by ``_with_engine_warnings`` at the return site
    (the guard in tests/test_row_policy_says_when_inert_2026_09_17.py pins
    that every authoring handler returns through it)."""
    if not extra or not isinstance(policy, dict):
        return policy
    out = dict(policy)
    out["warnings"] = list(out.get("warnings") or []) + list(extra)
    return out


def _validate_mode(value: str) -> str:
    v = (value or "exclude").lower()
    if v not in ("include", "exclude", "mask"):
        raise HTTPException(status_code=400, detail="mode must be one of: include, exclude, mask")
    return v


def _validate_principal_type(value: str) -> str:
    v = (value or "").lower()
    # 2026-10-25 -- ``api_key``: a published-API key is the resolved principal
    # ``api_key:<row id>`` (core/row_security/principal.py); a policy bound to it
    # applies to that key on every API whose data-policy switch is ``apply``.
    if v not in PRINCIPAL_TYPES:
        raise HTTPException(
            status_code=400,
            detail="principal_type must be one of: " + ", ".join(PRINCIPAL_TYPES),
        )
    return v


#: the principal types a binding accepts; ``api_key`` since 2026-10-25
PRINCIPAL_TYPES = ("user", "role", "group", "api_key", "system_account", "all")


def _check_filter_sql_len(filter_sql: str) -> None:
    try:
        from core.config import row_security as _cfg
        cap = int(_cfg.max_filter_sql_chars)
    except Exception:
        cap = 4000
    if len(filter_sql or "") > cap:
        raise HTTPException(
            status_code=400,
            detail=f"filter_sql exceeds max length ({cap} chars)",
        )


def _engine_warnings() -> List[str]:
    """Warn when a policy is being AUTHORED into an engine that is switched off.

    2026-09-17.  ``row_security.enabled`` gates the whole rewriter:
    ``core/row_security/api.py::_is_enabled`` returns False and
    ``federation_engine._warn_if_rls_policies_skipped`` returns on its very
    first line, so with the engine off a policy is stored, reported
    ``enabled: true, enforcement: "rewrite"``, and filters nothing.  Nothing
    on this surface said so -- an operator got a 200 and a policy that looks
    armed.

    This module already holds the right instinct: ``_validate_filter_sql_parses``
    exists, in its own words, "so admins learn about broken syntax
    immediately, not on the first user query".  The engine being off entirely
    is the largest case of learning it later, and it was the one case not
    surfaced.

    A WARNING, not a refusal.  Authoring policies before enabling the engine
    is a legitimate order of work (stage the policy set, then switch on), and
    refusing would break it.  This is the same shape as
    ``multi_pod_state()``'s ``inert`` verdict: the state is legible and names
    its remedy, and nothing is blocked.
    """
    try:
        from core.config import row_security as _cfg
        if bool(_cfg.enabled):
            return []
    except Exception:                                        # noqa: BLE001
        # Config unreadable — say nothing rather than claim a state we could
        # not determine.  Unknown is not "disabled".
        return []
    return [
        "row_security.enabled is false on this deployment, so this policy is "
        "STORED BUT NOT ENFORCED: the rewriter is switched off and queries "
        "return unfiltered rows. Set row_security.enabled=true to arm it."
    ]


def _with_engine_warnings(policy: Dict[str, Any]) -> Dict[str, Any]:
    """Attach ``warnings`` to a policy response.  Additive: every existing
    field keeps its meaning, and a consumer that ignores the key is
    unchanged.  Warnings already on the policy (FB-45's contradiction
    advice) are kept, the engine's appended after them."""
    warns = _engine_warnings()
    if warns and isinstance(policy, dict):
        out = dict(policy)
        out["warnings"] = list(out.get("warnings") or []) + warns
        return out
    return policy


def _validate_filter_sql_parses(filter_sql: str) -> None:
    """Parse-check the filter expression at policy creation time so admins
    learn about broken syntax immediately, not on the first user query.

    We parse a synthetic ``SELECT * FROM __t WHERE <filter>`` so sqlglot
    has a complete statement to validate.  Bare WHERE fragments don't
    parse on their own.

    2026-08-22: the check must validate what the REWRITER will parse, not
    the raw template.  ``${user.<attr>}`` tokens (resolver.substitute_vars,
    the documented per-user substitution syntax) are not SQL -- parsing the
    raw template refused EVERY templated policy (``owner = ${user.username}``,
    ``region IN ${user.groups}``) with 400, so the substitution feature was
    unreachable through this API.  Substitute a benign parenthesised literal
    first, exactly as ``_validate_mask_expr_parses`` already does for
    ``${col}``.  ``('__probe__')`` is valid both as a scalar comparand and
    as an IN-list, matching the two shapes substitute_vars can emit.
    """
    if not filter_sql or not filter_sql.strip():
        raise HTTPException(status_code=400, detail="filter_sql must not be empty")
    try:
        import re as _re
        import sqlglot
        probe_sql = _re.sub(
            r"\$\{user\.[a-zA-Z_][a-zA-Z0-9_]*\}", "('__probe__')", filter_sql
        )
        # Run two passes: one general, one DuckDB-specific.  Most policies
        # will be evaluated under DuckDB so we want that dialect to accept
        # it; if it doesn't, the policy would always raise at query time.
        sqlglot.parse_one(f"SELECT 1 FROM __t WHERE {probe_sql}", dialect="duckdb")
    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=(f"filter_sql does not parse as a SQL boolean expression: {exc}"
                     " — make sure it is a valid WHERE expression."),
        )


def _validate_mask_expr_parses(mask_expr: str) -> None:
    if not mask_expr or not mask_expr.strip():
        return
    try:
        import sqlglot
        # Mask expressions may reference ${col} — substitute a placeholder
        probe = mask_expr.replace("${col}", '"__col__"')
        sqlglot.parse_one(f"SELECT {probe} FROM __t", dialect="duckdb")
    except Exception as exc:
        raise HTTPException(
            status_code=400,
            detail=f"mask_expr does not parse: {exc}",
        )


# ── Row policies ────────────────────────────────────────────────────────────

@router.get("/policies")
async def list_row_policies(
    enabled_only: bool = Query(False),
    connection_id: Optional[int] = Query(None),
    source: Optional[str] = Query(None),
    user: dict = Depends(require_capability("row_security.manage")),
) -> List[Dict[str, Any]]:
    return await _adb(
        _db().list_row_policies,
        enabled_only=enabled_only,
        connection_id=connection_id,
        source=source,
    )


@router.post("/policies")
async def create_row_policy(
    body: RowPolicyCreate,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    _validate_enforcement(body.enforcement)
    _check_filter_sql_len(body.filter_sql)
    _validate_filter_sql_parses(body.filter_sql)
    await _refuse_policy_name_taken("row", body.name)
    payload = body.model_dump()
    # FB-45 -- every stored policy carries an EXPLICIT class.
    payload["policy_class"] = _resolve_policy_class(body.policy_class, body.name)
    payload["created_by"] = user.get("username")
    payload["updated_by"] = user.get("username")
    created = await _adb(_db().create_row_policy, **payload)
    _invalidate_cache()
    audit_event(_db(), user, request, "create_row_policy",
                 resource_type="row_security", resource_id=created["id"],
                 details={"name": body.name, "policy_class": payload["policy_class"]})
    warns = await _adb(_contradiction_warnings_for, created)
    return _with_engine_warnings(_with_contradictions(created, warns))


@router.get("/policies/{policy_id}")
async def get_row_policy(
    policy_id: int,
    user: dict = Depends(require_capability("row_security.manage")),
) -> Dict[str, Any]:
    p = await _adb(_db().get_row_policy, policy_id)
    if not p:
        raise HTTPException(status_code=404, detail="Policy not found")
    return p


@router.put("/policies/{policy_id}")
async def update_row_policy(
    policy_id: int,
    body: RowPolicyUpdate,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    if body.enforcement is not None:
        _validate_enforcement(body.enforcement)
    if body.filter_sql is not None:
        _check_filter_sql_len(body.filter_sql)
        _validate_filter_sql_parses(body.filter_sql)
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if updates.get("name"):
        await _refuse_policy_name_taken("row", updates["name"], policy_id)
    if "policy_class" in updates:
        # An explicit reclassification through PUT is as audited as restamp
        # (the field list below names it); an invalid class is refused.
        updates["policy_class"] = _resolve_policy_class(
            updates["policy_class"], body.name or str(policy_id))
    updates["updated_by"] = user.get("username")
    updated = await _adb(_db().update_row_policy, policy_id, **updates)
    if not updated:
        raise HTTPException(status_code=404, detail="Policy not found")
    _invalidate_cache()
    audit_event(_db(), user, request, "update_row_policy",
                 resource_type="row_security", resource_id=policy_id,
                 details={"fields": list(updates.keys()),
                          **({"policy_class": updates["policy_class"]}
                             if "policy_class" in updates else {})})
    warns = await _adb(_contradiction_warnings_for, updated)
    return _with_engine_warnings(_with_contradictions(updated, warns))


@router.post("/policies/restamp")
async def restamp_row_policies(
    body: RestampRequest,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    """FB-45 -- the EXPLICIT, AUDITED reclassification.

    Every policy that predated classes was stamped restrictive at startup
    so the upgrade moved nobody's rows.  Moving a deployment to grant
    semantics is this call, by an admin, on named policies (or all of
    them), with the before/after of every policy in the audit event --
    never a side effect of deploying or of changing the config mode.
    """
    from core.row_security.composition import POLICY_CLASSES, normalise_class
    cls = normalise_class(body.policy_class)
    if cls is None:
        raise HTTPException(
            status_code=400,
            detail=f"policy_class must be one of: {', '.join(POLICY_CLASSES)}")
    if body.all == bool(body.policy_ids):
        raise HTTPException(
            status_code=400,
            detail="name the policies in policy_ids, or set all=true -- not both, not neither")
    changed = await _adb(_db().restamp_row_policies,
                         None if body.all else list(body.policy_ids or []),
                         cls, user.get("username"))
    _invalidate_cache()
    audit_event(_db(), user, request, "restamp_row_policies",
                 resource_type="row_security",
                 details={"policy_class": cls, "all": body.all,
                          "requested_ids": body.policy_ids,
                          "changed": changed})
    warnings: List[str] = []
    if cls == "restrictive":
        for c in changed:
            pol = await _adb(_db().get_row_policy, c["id"])
            if pol:
                warnings.extend(await _adb(_contradiction_warnings_for, pol))
    out: Dict[str, Any] = {"policy_class": cls, "changed": changed,
                           "changed_count": len(changed)}
    if warnings:
        out["warnings"] = sorted(set(warnings))
    return out


@router.get("/composition")
async def composition_summary(
    connection_id: Optional[int] = Query(None),
    user: dict = Depends(require_capability("row_security.manage")),
) -> Dict[str, Any]:
    """FB-45 -- per table pattern: how many policies of each class apply and
    what the composed predicate looks like, so an operator can SEE the
    pre-FB-45 (all-restrictive) shape and choose to move.

    The shape uses policy ids as symbols: ``((P6) OR (P8)) AND (R9)``.  A
    real principal's predicate depends on its bindings; the dry-run
    (``POST /test``) renders that one.
    """
    from core.row_security.composition import (
        PERMISSIVE, RESTRICTIVE, composition_mode, effective_class,
    )
    pols = await _adb(_db().list_row_policies, enabled_only=False,
                      connection_id=connection_id)
    bindings = await _adb(_db().list_policy_bindings, policy_kind="row")
    by_policy: Dict[int, List[str]] = {}
    for bnd in bindings or []:
        by_policy.setdefault(bnd.get("policy_id"), []).append(
            f"{bnd.get('principal_type')}:{bnd.get('principal_id')}")
    groups: Dict[str, Dict[str, Any]] = {}
    unclassed = 0
    for p in pols or []:
        key = str(p.get("table_pattern") or "")
        g = groups.setdefault(key, {"table_pattern": key, "permissive": [],
                                    "restrictive": [], "disabled": 0})
        if not p.get("enabled", True):
            g["disabled"] += 1
            continue
        if p.get("policy_class") is None:
            unclassed += 1
        entry = {"id": p.get("id"), "name": p.get("name"),
                 "filter_sql": p.get("filter_sql"),
                 "policy_class": effective_class(p),
                 "stored_class": p.get("policy_class"),
                 "bound_to": by_policy.get(p.get("id"), [])}
        g[effective_class(p)].append(entry)
    tables = []
    for g in groups.values():
        perm = [f"P{e['id']}" for e in g["permissive"]]
        restr = [f"R{e['id']}" for e in g["restrictive"]]
        parts = []
        if perm:
            parts.append("(" + " OR ".join(f"({s})" for s in perm) + ")" if len(perm) > 1
                         else f"({perm[0]})")
        parts.extend(f"({s})" for s in restr)
        g["shape"] = " AND ".join(parts) if parts else "TRUE (no enabled policy)"
        g["permissive_count"] = len(g["permissive"])
        g["restrictive_count"] = len(g["restrictive"])
        g["unbound_principal_outcome"] = (
            "no rows (grants exist on this table)" if perm
            else ("unrestricted (only ceilings; none binds)" if restr
                  else "unrestricted (ungoverned)"))
        tables.append(g)
    tables.sort(key=lambda t: t["table_pattern"])
    return {
        "policy_composition": composition_mode(),
        "classes": [PERMISSIVE, RESTRICTIVE],
        "tables": tables,
        "unclassed_policies": unclassed,
        "note": ("permissives OR, restrictives AND, the two groups AND; a policy "
                 "with no stored class composes as restrictive (pre-FB-45 "
                 "semantics) until an admin restamps it"),
    }


@router.delete("/policies/{policy_id}")
async def delete_row_policy(
    policy_id: int,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    ok = await _adb(_db().delete_row_policy, policy_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Policy not found")
    _invalidate_cache()
    audit_event(_db(), user, request, "delete_row_policy",
                 resource_type="row_security", resource_id=policy_id)
    from core.config_active import switched_off_message
    return {"deleted": True, "detail": switched_off_message("row security policy")}


# ── Column policies ─────────────────────────────────────────────────────────

@router.get("/column-policies")
async def list_column_policies(
    enabled_only: bool = Query(False),
    connection_id: Optional[int] = Query(None),
    source: Optional[str] = Query(None),
    user: dict = Depends(require_capability("row_security.manage")),
) -> List[Dict[str, Any]]:
    return await _adb(
        _db().list_column_policies,
        enabled_only=enabled_only,
        connection_id=connection_id,
        source=source,
    )


@router.post("/column-policies")
async def create_column_policy(
    body: ColumnPolicyCreate,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    _validate_enforcement(body.enforcement)
    _validate_mode(body.mode)
    if body.mode == "mask" and not body.mask_expr:
        raise HTTPException(status_code=400,
                              detail="mask_expr required when mode='mask'")
    if not body.columns:
        raise HTTPException(status_code=400, detail="columns must be non-empty")
    if body.mask_expr:
        _validate_mask_expr_parses(body.mask_expr)
    await _refuse_policy_name_taken("column", body.name)
    payload = body.model_dump()
    payload["created_by"] = user.get("username")
    payload["updated_by"] = user.get("username")
    created = await _adb(_db().create_column_policy, **payload)
    _invalidate_cache()
    audit_event(_db(), user, request, "create_column_policy",
                 resource_type="row_security", resource_id=created["id"],
                 details={"name": body.name, "mode": body.mode})
    return _with_engine_warnings(created)


@router.put("/column-policies/{policy_id}")
async def update_column_policy(
    policy_id: int,
    body: ColumnPolicyUpdate,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    if body.enforcement is not None:
        _validate_enforcement(body.enforcement)
    if body.mode is not None:
        _validate_mode(body.mode)
    if body.mask_expr is not None:
        _validate_mask_expr_parses(body.mask_expr)
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if updates.get("name"):
        await _refuse_policy_name_taken("column", updates["name"], policy_id)
    updates["updated_by"] = user.get("username")
    updated = await _adb(_db().update_column_policy, policy_id, **updates)
    if not updated:
        raise HTTPException(status_code=404, detail="Policy not found")
    _invalidate_cache()
    audit_event(_db(), user, request, "update_column_policy",
                 resource_type="row_security", resource_id=policy_id,
                 details={"fields": list(updates.keys())})
    return _with_engine_warnings(updated)


@router.delete("/column-policies/{policy_id}")
async def delete_column_policy(
    policy_id: int,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    ok = await _adb(_db().delete_column_policy, policy_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Policy not found")
    _invalidate_cache()
    audit_event(_db(), user, request, "delete_column_policy",
                 resource_type="row_security", resource_id=policy_id)
    from core.config_active import switched_off_message
    return {"deleted": True, "detail": switched_off_message("column security policy")}


# ── Bindings ────────────────────────────────────────────────────────────────

@router.get("/bindings")
async def list_bindings(
    policy_kind: Optional[str] = Query(None),
    policy_id: Optional[int] = Query(None),
    user: dict = Depends(require_capability("row_security.manage")),
) -> List[Dict[str, Any]]:
    return await _adb(
        _db().list_policy_bindings,
        policy_kind=policy_kind,
        policy_id=policy_id,
    )


@router.post("/bindings")
async def create_binding(
    body: BindingCreate,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    if body.policy_kind not in ("row", "column"):
        raise HTTPException(status_code=400, detail="policy_kind must be 'row' or 'column'")
    _validate_principal_type(body.principal_type)
    payload = body.model_dump()
    payload["created_by"] = user.get("username")
    try:
        created = await _adb(_db().create_policy_binding, **payload)
    except Exception as exc:
        if "uq_polbind_unique" in str(exc) or "UNIQUE" in str(exc):
            raise HTTPException(status_code=409, detail="Binding already exists")
        raise
    _invalidate_cache()
    audit_event(_db(), user, request, "create_policy_binding",
                 resource_type="row_security",
                 resource_id=created["id"],
                 details={"policy_kind": body.policy_kind,
                          "policy_id":   body.policy_id,
                          "principal":   f"{body.principal_type}:{body.principal_id}"})
    if body.policy_kind == "row":
        # FB-45 -- the binding is what makes two restrictive policies meet
        # on one principal; check again now that it exists.
        pol = await _adb(_db().get_row_policy, body.policy_id)
        if pol:
            warns = await _adb(_contradiction_warnings_for, pol)
            if warns:
                created = dict(created)
                created["warnings"] = warns
    return created


@router.delete("/bindings/{binding_id}")
async def delete_binding(
    binding_id: int,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    ok = await _adb(_db().delete_policy_binding, binding_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Binding not found")
    _invalidate_cache()
    audit_event(_db(), user, request, "delete_policy_binding",
                 resource_type="row_security", resource_id=binding_id)
    return {"deleted": True}


# ── Test / dry-run / audit / cache / LF sync ────────────────────────────────

@router.post("/test")
async def test_rewrite(
    body: TestRequest,
    user: dict = Depends(require_capability("row_security.manage")),
) -> Dict[str, Any]:
    """Dry-run: show what ``body.sql`` would look like for the given principal.

    FB-45 -- also WHICH policies matched each table, each one's class, and
    how they combined (``tables[].composition``): this endpoint is what made
    the composition question visible in the first place.

    AQD-07 (2026-09-23) -- it SIMULATES, and says whether it is simulating.
    It used to run the enforcement path, which short-circuits when
    enforcement is off or the engine is not wired, and answered both with
    ``changed: false, tables: []`` -- indistinguishable from "no policy
    applies to you", while a restrictive policy bound to ``all:*`` sat
    enabled.  Now the rewrite is computed whatever the switch says (no audit
    rows -- the principal is one the admin typed), ``engine`` carries the
    enforcement state and the reason it would not act, and ``outcome`` is
    one of ``rewritten`` / ``no_policy_matched`` / ``engine_not_wired``.
    """
    from core.row_security.api import secure_sql_report, build_user_ctx, engine_state
    from core.row_security.composition import composition_mode

    engine = engine_state()

    fake_user = {
        "username": body.username,
        "role": body.role,
        "groups": body.groups,
        "is_admin": False,
    }
    if body.api_key_id:
        # 2026-10-25 -- tested AS an API key calling an API whose data-policy
        # switch is ``data_policy_mode``: the same surface the published-view
        # handlers stamp (api/published_views/helpers.py::with_entitlement_scope)
        fake_user["api_key_id"] = str(body.api_key_id)
        fake_user["auth_method"] = "api_key"
        fake_user["entitlement_scope"] = ("api", body.data_policy_mode, str(body.api_key_id))
    ctx = build_user_ctx(fake_user)
    _tested_as_admin = bool(ctx.is_admin or ctx.role in ("admin", "super_admin"))
    try:
        rewritten, report = await _adb(
            secure_sql_report,
            body.sql,
            dialect=body.dialect,
            user_ctx=ctx,
            connection_id=body.connection_id,
            request_id=None,
            simulate=True,
        )
    except Exception as exc:
        return {"ok": False, "error": str(exc), "original": body.sql,
                "policy_composition": composition_mode(), "engine": engine}
    tables: List[Dict[str, Any]] = []
    skipped: List[Dict[str, Any]] = []
    if report is not None:
        for entry in report.applied:
            comp = entry.get("composition") or {}
            tables.append({
                "table": entry.get("table"),
                "enforcement": entry.get("enforcement"),
                "rewritten": bool(entry.get("rewritten")),
                "row_policies": [
                    {"id": p.get("id"), "name": p.get("name"),
                     "policy_class": p.get("policy_class"),
                     "filter_sql": p.get("filter_sql")}
                    for p in entry.get("row_policies") or []],
                "column_policies": [
                    {"id": p.get("id"), "name": p.get("name"), "mode": p.get("mode")}
                    for p in entry.get("column_policies") or []],
                "composition": comp or None,
            })
        skipped = list(report.skipped)
    return {
        "ok": True,
        "original": body.sql,
        "rewritten": rewritten,
        "changed": rewritten != body.sql,
        "principal_ids": ctx.principal_ids(),
        "policy_composition": composition_mode(),
        "tables": tables,
        "skipped": skipped,
        "engine": engine,
        # "matched_not_rewritten": a policy applies but its enforcement is
        # audit_only / native_lf -- it is recorded, not written into the SQL.
        # "admin_bypass": the principal tested IS an admin, and admins are
        # never rewritten (they author policies) -- not a wiring fault.
        "outcome": ("admin_bypass" if report is None and _tested_as_admin
                    else "engine_not_wired" if report is None
                    else "rewritten" if any(t["rewritten"] for t in tables)
                    else "matched_not_rewritten" if tables
                    else "no_policy_matched"),
    }


@router.get("/audit")
async def list_audit(
    username: Optional[str] = Query(None),
    table_ref: Optional[str] = Query(None),
    limit: int = Query(200, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    user: dict = Depends(require_capability("row_security.manage")),
) -> List[Dict[str, Any]]:
    return await _adb(
        _db().list_row_security_audit,
        username=username,
        table_ref=table_ref,
        limit=limit,
        offset=offset,
    )


@router.post("/cache/invalidate")
async def invalidate_cache(
    request: Request,
    user: dict = Depends(require_capability("row_security.manage")),
) -> Dict[str, Any]:
    _invalidate_cache()
    audit_event(_db(), user, request, "row_security_cache_invalidate",
                 resource_type="row_security")
    return {"invalidated": True}


@router.post("/lake-formation/sync")
async def lake_formation_sync(
    body: LakeFormationSyncRequest,
    request: Request,
    user: dict = Depends(require_capability("row_security.manage", rate_limited=True)),
) -> Dict[str, Any]:
    try:
        from core.config import row_security as _cfg
        if not _cfg.lake_formation_sync_enabled:
            raise HTTPException(
                status_code=400,
                detail="lake_formation_sync_enabled is false in config",
            )
    except HTTPException:
        raise
    except Exception as _cfg_exc:
        # Config-read failure shouldn't refuse the sync (caller is admin
        # and the explicit flag below also gates LF behaviour).
        logger.debug("row_security config read failed (non-fatal): %s", _cfg_exc)

    # Pull AWS creds for the connection
    try:
        conn = await _adb(_db().get_connection_raw, body.connection_id)
    except Exception as exc:
        raise HTTPException(status_code=404, detail=f"Connection not found: {exc}")
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    cfg = (conn.get("config") or {})
    aws_creds = {
        "access_key": cfg.get("access_key"),
        "secret_key": cfg.get("secret_key"),
        "session_token": cfg.get("session_token"),
        "region": cfg.get("region") or cfg.get("aws_region"),
    }
    aws_creds = {k: v for k, v in aws_creds.items() if v}

    from core.row_security.lake_formation_sync import (
        sync_connection, LakeFormationSyncError,
    )
    try:
        result = await _adb(
            sync_connection,
            _db(),
            body.connection_id,
            aws_creds,
            databases=body.databases,
            updated_by=user.get("username", "admin"),
        )
    except LakeFormationSyncError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    _invalidate_cache()
    audit_event(_db(), user, request, "lake_formation_sync",
                 resource_type="row_security",
                 resource_id=body.connection_id,
                 details=result)
    return result


#: 2026-09-15 — ``row_security.materialize_views_enabled`` is a toggle for an
#: OPTIMISATION THAT WAS NEVER WIRED.  ``core/row_security/view_builder.py``
#: implements it (Option B: pre-create ``<table>_secured`` views at session
#: setup so hot paths skip the per-query rewrite) and is fully unit-tested,
#: and ``materialize_secure_views`` has ZERO production callers -- the query
#: path only ever uses Option A, the rewriter.  Turning the flag on therefore
#: changes NOTHING, silently.
#:
#: It is reported rather than wired.  Finishing Option B means hooking DuckDB
#: session setup and repointing hot paths at the secured views, and getting
#: that wrong in a ROW-SECURITY optimisation escalates access -- this
#: codebase has three recorded incidents of exactly that.  An unfinished
#: optimisation that announces itself is honest; one that silently ignores
#: its own switch is the defect being fixed.
_MATERIALIZE_VIEWS_UNAVAILABLE = (
    "built but not wired: core/row_security/view_builder.py implements "
    "Option B (pre-created <table>_secured views) and nothing in the query "
    "path calls it, so enabling this changes nothing. Row filtering is "
    "enforced by the per-query rewriter (Option A) either way — this is a "
    "performance option, never a security one."
)


@router.get("/config")
async def get_config(user: dict = Depends(require_capability("row_security.manage"))) -> Dict[str, Any]:
    try:
        from core.config import row_security as _cfg
        out = {
            "enabled":                          _cfg.enabled,
            "default_mode":                     _cfg.default_mode,
            "fail_open":                        _cfg.fail_open,
            "audit_retention_days":             _cfg.audit_retention_days,
            "cache_resolver_seconds":           _cfg.cache_resolver_seconds,
            "lake_formation_sync_enabled":      _cfg.lake_formation_sync_enabled,
            "lake_formation_sync_interval_hours": _cfg.lake_formation_sync_interval_hours,
            "materialize_views_enabled":        _cfg.materialize_views_enabled,
            "max_filter_sql_chars":             _cfg.max_filter_sql_chars,
            # FB-45 -- the effective composition mode: the class a policy
            # authored without one receives.  Stored classes always win.
            "policy_composition":               _cfg.policy_composition,
            "policy_composition_effective":     _cfg.policy_composition,
            "policy_composition_meaning": {
                "permissive": "grants union: (P1 OR P2) -- Lake Formation / BI tools",
                "restrictive": "ceilings intersect: (R1 AND R2) -- Oracle VPD / SQL Server, pre-FB-45",
                "per_policy": "no default; every policy must declare its class",
            },
        }
        # Availability alongside the value, the shape this product already
        # uses for the same problem (/api/feeds/backend-options' available +
        # detail, Clockwork's routable + reason, DataFlow's runnability).
        out["materialize_views_available"] = False
        out["materialize_views_unavailable_reason"] = _MATERIALIZE_VIEWS_UNAVAILABLE
        if _cfg.materialize_views_enabled:
            logger.warning(
                "[row_security] materialize_views_enabled=true but the "
                "feature is %s", _MATERIALIZE_VIEWS_UNAVAILABLE)
        # The two retention/refresh values below DO have readers now
        # (2026-09-15): audit_retention_days is swept by the
        # rls_audit_cleanup daemon and the LF interval by
        # core/row_security/lake_formation_daemon.py.
        return out
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


def _invalidate_cache() -> None:
    try:
        from core.row_security.api import invalidate_cache as _inv
        _inv()
    except Exception as exc:
        logger.debug("row_security cache invalidate failed: %s", exc)


# ── Switched off, never erased (2026-10-30) ─────────────────────────────────


async def _refuse_policy_name_taken(kind: str, name: str, own_id: Optional[int] = None) -> None:
    """A policy name is UNIQUE and a switched-off policy keeps it: a create
    or rename onto it is 409 with the plain message, never a raw
    IntegrityError (an ON policy holding it is the same 409)."""
    from core.config_active import is_on, name_held_message
    get = _db().get_row_policy_by_name if kind == "row" else _db().get_column_policy_by_name
    other = await _adb(get, name)
    if not other or (own_id is not None and int(other["id"]) == int(own_id)):
        return
    what = "row security policy" if kind == "row" else "column security policy"
    if not is_on(other):
        raise HTTPException(status_code=409, detail=name_held_message(what, name))
    raise HTTPException(status_code=409, detail=f"A {what} named {name!r} already exists")


def _on_policy_switched_on(row: Dict[str, Any], user: dict) -> Optional[str]:
    """A policy switched back on applies again from the next query: drop
    this process's resolved-policy cache, exactly as the delete did."""
    _invalidate_cache()
    return None


def _register_switch_on() -> None:
    from api.config_active_api import ON_SWITCH_ON
    ON_SWITCH_ON["row_level_policies"] = _on_policy_switched_on
    ON_SWITCH_ON["column_policies"] = _on_policy_switched_on


_register_switch_on()
