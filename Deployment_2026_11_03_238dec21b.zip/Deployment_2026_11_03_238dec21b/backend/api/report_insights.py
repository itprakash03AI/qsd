"""The cube route's ``insight`` operation (2026-10-30): one insight tile over a
run's stored, row-secured result.

Not a router: ``api/business_reports_api.py`` calls :func:`answer_insight`
from the routes that ALREADY resolved and authorised the result -- the
signed-in ``POST /api/business-reports/{id}/results/{exec_id}/cube`` (the
executor / owner / admin gate every result read passes) and the share-link /
embed / shared-dashboard ``.../cube`` routes (their sealed handle names their
own run only).  So an insight reads exactly the rows the caller was already
served, at the same row security; nothing here opens another file except
the previous run ``previous`` resolves (same report, same row-security
signature -- ``core/reports/canvas_insights.previous_run_of``), which a link
never gets (``previous=None``).

Answers: 200 the insight; 422 ``insight_problems`` (the tile's settings, in
sentences -- the same rules as the save check), 422 ``insight_refused`` (it
would be wrong or has nothing to stand on: one value of the date, no earlier
run...), 422 ``non_additive_measures`` (the grain rule, like the cube), 409 a
result still being built, 400 a field this run does not have.
"""
from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Sequence

from fastapi import HTTPException

logger = logging.getLogger(__name__)


async def answer_insight(db, report: Optional[dict], artifact: Path, body: Any, *, grain: str,
                         group_cols: Optional[Sequence[str]],
                         previous: Optional[Callable[[], Dict[str, Any]]],
                         allow_assistant: bool = False, principal: Optional[str] = None,
                         execution_id: Optional[str] = None) -> Dict[str, Any]:
    """``execution_id`` (2026-11-01 review): the run whose parameter words the story
    reads -- the ROUTE's own path value after its access checks (the body never
    carried one, so the words never reached the story; a token route passes none)."""
    from core import config as _cfg
    from core.json_utils import sanitize_for_json
    from core.reports import insights as ins
    from core.reports import microcube as mc
    from core.reports.canvas_insights import compute_insight, insight_problems
    from api.business_reports_api import _cube_path_filters as _path_filters_of   # path + linked paths

    cfg = getattr(body, "insight", None)
    if not isinstance(cfg, dict):
        raise HTTPException(status_code=400, detail="Say which insight to show (insight: {kind, measure, ...}).")
    if not report or not report.get("dataset_id"):
        raise HTTPException(status_code=422, detail={
            "error": "insight_refused",
            "message": "Insights need a report built on a dataset; this report runs its own SQL."})
    ds = await asyncio.to_thread(db.get_dataset_full, report["dataset_id"])
    columns = list((ds or {}).get("columns") or [])
    cols = {int(c["id"]): c for c in columns if c.get("id") is not None}
    # the run's own result file is the authority on which columns it has (the
    # microcube checks every name against it); here: the tile's rules
    problems = insight_problems({"insight": cfg}, cols=cols, selected=set(cols),
                                grouped=(grain != mc.GRAIN_DETAIL))
    if problems:
        raise HTTPException(status_code=422, detail={"error": "insight_problems", "problems": problems})
    try:
        res = await asyncio.to_thread(
            compute_insight, artifact, cfg, columns=columns,
            path_filters=_path_filters_of(body),
            slicers=getattr(body, "slicers", None) or None,
            grain=grain, group_columns=group_cols, previous=previous,
            threads=_cfg.business_reports.microcube_threads,
            memory_limit=_cfg.business_reports.microcube_memory_limit)
    except ins.InsightRefused as exc:
        raise HTTPException(status_code=422, detail={"error": "insight_refused", "message": str(exc)})
    except mc.NonAdditiveMeasureError as exc:
        raise HTTPException(status_code=422, detail={
            "error": "non_additive_measures", "message": str(exc), "artifact_grain": grain,
            "refused": [{"column": c, "reason": r} for c, r in exc.refused.items()]})
    except mc.ArtifactNotReady as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    # 2026-11-01 -- a story written by the assistant FROM these numbers (grounded;
    # core/reports/insight_story.py); per report, OFF until an author turns it on
    try:
        from core.reports import insight_story as _story
        settings = _story.settings_of(report.get("layout_config"))
        if settings["assistant"] and isinstance(res, dict) and res.get("sentence"):
            payload = sanitize_for_json({k: v for k, v in res.items() if k not in ("sentence",)})
            res["story"] = await asyncio.to_thread(
                _story.story_cached, db, int(report.get("id") or 0), str(getattr(body, "tile_id", "") or cfg.get("kind") or "insight"),
                # SECURITY (review 2026-11-01): the prompt's parameter words come from the RUN's own
                # record, kept to the declared names -- never from the request body (a stored story is
                # shared by everyone with the same key, and the key holds everything the prompt saw)
                payload, str(res["sentence"]), settings,
                parameters=_story.run_context(db, report, str(execution_id or "")),
                basis_words=(res.get("basis") or {}).get("words") if isinstance(res.get("basis"), dict) else None,
                execution_id=str(execution_id or ""),
                # SECURITY (review 2026-11-01): a model call only for a signed-in person, under the quotas;
                # a share / embed link gets an already-stored story or the standard sentence
                allow_assistant=bool(allow_assistant), principal=principal, report_id=int(report.get("id") or 0),
                by=str(principal or ""))
        elif isinstance(res, dict) and res.get("sentence"):
            res["story"] = {"text": res["sentence"], "source": "template",
                            "reason": "The assistant is off for this report (Edit report -> Look -> Insights)."}
    except Exception as exc:                                  # noqa: BLE001
        logger.info("[insight-story] skipped: %s", exc)
    return sanitize_for_json(res)
