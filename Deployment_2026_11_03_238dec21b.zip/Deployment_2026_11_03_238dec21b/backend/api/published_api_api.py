"""The published-API inventory routes (2026-10-17, design §3.9):

  GET  /api/published-apis                           the inventory (json | csv), filtered
  GET  /api/published-apis/kinds                     the registry (what a row can be)
  GET  /api/published-apis/impact?<object>_id=       what breaks if an object goes
  GET  /api/published-apis/{kind}/{api_id}           one API in full
  PUT  /api/published-apis/{kind}/{api_id}/lifecycle draft / active / deprecated / retired
  GET  /api/published-apis/{kind}/{api_id}/calls     the raw call rows (drill-down)
  PUT  /api/api-keys/{key_id}/identity               a key's consumer / owner / contact

Roles: admin and support see everything; an analyst sees their own APIs in
full and every other as a redacted catalog entry (the published-views list
route's rule); a viewer / consumer is refused.  Every write is audited.
Unknown != empty: an inventory that cannot be built is a 503 naming the
reason, never an empty list; a field that could not be read says so.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin, require_capability
from core.audit import audit_event
from core.db_async import adb
from core.published_api.contract import LIFECYCLE_STATES
from core.published_api.impact import IMPACT_PARAMS, ImpactRefused, dependents_of, refuse_if_apis_depend
from core.published_api.inventory import InventoryUnavailable, build_inventory, filter_apis, to_csv, visible_to
from core.roles import is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter()
_db_manager = None


def set_published_api_dependencies(db_manager) -> None:
    """Called from main.py beside set_published_views_dependencies."""
    global _db_manager
    _db_manager = db_manager


def _db():
    if _db_manager is None:
        raise HTTPException(503, "Service not ready -- the published-API inventory is not wired")
    return _db_manager


def _can_read(user: dict) -> bool:
    if is_admin_like(user):
        return True
    try:
        from core.roles import is_support
        if is_support(user):
            return True
    except Exception:                                   # noqa: BLE001
        pass
    return str((user or {}).get("role") or "") == "analyst"


def _require_reader(user: dict) -> dict:
    """admin / support / analyst may read the inventory; nobody else."""
    try:
        from api.deps import _gates_apply
        if not _gates_apply(user):
            return user
    except Exception:                                   # noqa: BLE001
        pass
    if not _can_read(user):
        raise HTTPException(403, "The published-API inventory is for admins, support and analysts")
    return user


def _build(kinds=None):
    try:
        return build_inventory(_db(), kinds=kinds)
    except InventoryUnavailable as exc:
        raise HTTPException(503, f"The inventory could not be built: {exc}") from exc


def _meta_block(meta: dict) -> dict:
    """What every answer says about itself: when, what could not be read."""
    return {"generated_at": meta.get("generated_at"), "problems": meta.get("problems") or [],
            "numbers_error": meta.get("numbers_error"), "kinds": meta.get("kinds") or []}


# ── the inventory ─────────────────────────────────────────────────────────

@router.get("/api/published-apis")
async def list_published_apis(
    kind: Optional[str] = Query(None), status: Optional[str] = Query(None),
    health: Optional[str] = Query(None), owner: Optional[str] = Query(None),
    consumer: Optional[str] = Query(None), q: Optional[str] = Query(None),
    idle_days: Optional[int] = Query(None, ge=0),
    format: str = Query("json", pattern="^(json|csv)$"),
    page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
    user: dict = Depends(require_capability("published_api.view")),
):
    _require_reader(user)
    apis, meta = await asyncio.to_thread(_build, [kind] if kind else None)
    apis = visible_to(apis, user)
    apis = filter_apis(apis, kind=kind, status=status, health=health, owner=owner, consumer=consumer, q=q,
                       idle_days=idle_days)
    apis.sort(key=lambda a: (a.api_kind, a.key))
    if format == "csv":
        text = to_csv(apis)
        audit_event(_db(), user, None, "api.inventory_exported", "published_api", None,
                    {"format": "csv", "rows": len(apis), "filter": {"kind": kind, "status": status, "health": health,
                                                                     "owner": owner, "consumer": consumer, "q": q,
                                                                     "idle_days": idle_days}})
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        return StreamingResponse(iter([text]), media_type="text/csv",
                                 headers={"Content-Disposition": f'attachment; filename="published-apis-{stamp}.csv"'})
    total = len(apis)
    start = (page - 1) * page_size
    items = apis[start:start + page_size]
    return {"items": [a.to_dict() for a in items], "total": total,
            "paging": {"page": page, "page_size": page_size, "total": total,
                       "pages": max(1, (total + page_size - 1) // page_size)},
            "counts": _counts(apis), **_meta_block(meta)}


def _counts(apis) -> Dict[str, Any]:
    by_status: Dict[str, int] = {}
    by_health: Dict[str, int] = {}
    by_kind: Dict[str, int] = {}
    for a in apis:
        by_status[(a.lifecycle or {}).get("status", "unknown")] = by_status.get((a.lifecycle or {}).get("status", "unknown"), 0) + 1
        by_health[(a.health or {}).get("state", "unknown")] = by_health.get((a.health or {}).get("state", "unknown"), 0) + 1
        by_kind[a.api_kind] = by_kind.get(a.api_kind, 0) + 1
    return {"by_status": by_status, "by_health": by_health, "by_kind": by_kind}


@router.get("/api/published-apis/kinds")
async def list_kinds(user: dict = Depends(require_capability("published_api.view"))):
    _require_reader(user)
    from core.published_api.registry import load
    reg = load()
    return {"kinds": [{"kind": k.kind, "table": k.model.__table__.name,
                       "endpoints": [e.to_dict() for e in k.endpoints(type("_R", (), {"slug": "{slug}", "id": 0})())]}
                      for k in reg.all()]}


@router.get("/api/published-apis/impact")
async def impact(connection_id: Optional[int] = Query(None), saved_query_id: Optional[int] = Query(None),
                 sql_file_id: Optional[int] = Query(None), federation_view_id: Optional[int] = Query(None),
                 report_id: Optional[int] = Query(None), dataset_id: Optional[int] = Query(None),
                 system_account_id: Optional[int] = Query(None),
                 user: dict = Depends(require_capability("published_api.view"))):
    """What breaks if this object goes: every published API resting on it,
    with its consumers.  Exactly one object parameter."""
    _require_reader(user)
    given = {k: v for k, v in {"connection_id": connection_id, "saved_query_id": saved_query_id,
                                "sql_file_id": sql_file_id, "federation_view_id": federation_view_id,
                                "report_id": report_id, "dataset_id": dataset_id,
                                "system_account_id": system_account_id}.items() if v is not None}
    if len(given) != 1:
        raise HTTPException(422, f"name exactly one of {sorted(IMPACT_PARAMS)}")
    (param, obj_id), = given.items()
    kind = IMPACT_PARAMS[param]
    apis, meta = await asyncio.to_thread(_build)
    apis = visible_to(apis, user)
    deps = dependents_of([a for a in apis if not a.is_redacted], kind, int(obj_id))
    hidden = len([a for a in apis if a.is_redacted and any(
        d.kind == kind and d.id == int(obj_id) for d in a.dependencies)])
    return {"kind": kind, "id": int(obj_id), "dependents": deps, "count": len(deps),
            "hidden_from_you": hidden, **_meta_block(meta)}


# ── the numbers (core/published_api/rollup.py) ────────────────────────────

def _range(from_: Optional[datetime], to: Optional[datetime], default_hours: int = 24):
    from core.published_api.rollup import _utcnow   # THE clock the rollup reads (tests pin it)
    end = to if to is not None else _utcnow()
    end = end if end.tzinfo else end.replace(tzinfo=timezone.utc)
    start = from_ if from_ is not None else end - timedelta(hours=default_hours)
    start = start if start.tzinfo else start.replace(tzinfo=timezone.utc)
    if start >= end:
        raise HTTPException(422, "from must be before to")
    if end - start > timedelta(days=400):
        raise HTTPException(422, "a range of more than 400 days: ask for the daily grain in parts")
    return start, end


def _window(window: str) -> timedelta:
    return {"1h": timedelta(hours=1), "24h": timedelta(hours=24), "7d": timedelta(days=7),
            "30d": timedelta(days=30), "90d": timedelta(days=90)}[window]


def _api_filter_for(user: dict, apis_visible, kind: Optional[str], api: Optional[str]):
    """An analyst's numbers are forced to their own APIs; a named API must be
    one they may see in full.  Returns (kind, api_id, key) or raises -- the
    key travels to the exact-percentile path, whose row set must include the
    refusals that carried only the slug (the rollup gave them to this API)."""
    if api is None:
        return kind, None, None
    match = next((a for a in apis_visible if a.key == api and (kind is None or a.api_kind == kind)), None)
    if match is None:
        raise HTTPException(404, f"no published API with key {api!r}")
    if match.is_redacted:
        raise HTTPException(403, "another publisher's API: its numbers are not yours to read")
    return match.api_kind, match.api_id, match.key


@router.get("/api/published-apis/metrics")
async def metrics(from_: Optional[datetime] = Query(None, alias="from"), to: Optional[datetime] = Query(None),
                  grain: str = Query("hour", pattern="^(hour|day)$"),
                  group_by: str = Query("none", pattern="^(api|consumer|endpoint|none)$"),
                  kind: Optional[str] = Query(None), api: Optional[str] = Query(None),
                  consumer: Optional[str] = Query(None), endpoint: Optional[str] = Query(None),
                  user: dict = Depends(require_capability("published_api.view"))):
    """Calls, errors by status, refusals by reason, rows, bytes, cache hit
    rate and p50 / p95 / p99 over the rollups, per bucket and group, plus
    totals; every answer carries the watermark ("numbers end at")."""
    _require_reader(user)
    start, end = _range(from_, to, 24 if grain == "hour" else 24 * 30)
    from core.published_api.rollup import series
    apis, _meta = await asyncio.to_thread(_build)
    visible = visible_to(apis, user)
    k, api_id, api_key = _api_filter_for(user, visible, kind, api)
    out = await adb(series, _db(), start=start, end=end, grain=grain, group_by=group_by, kind=k, api_id=api_id,
                    consumer=consumer, endpoint=endpoint, api_slug=api_key)
    if not is_admin_like(user) and api_id is None:
        # an analyst's unfiltered numbers: only their own APIs' groups
        mine = {f"{a.api_kind}:{a.key}" for a in visible if not a.is_redacted}
        if group_by == "api":
            out["cells"] = [c for c in out["cells"] if c["group"] in mine]
        else:
            out["totals"] = None
            out["cells"] = []
            out["restricted"] = "an analyst's unfiltered numbers are shown per API (group_by=api) or for one API"
    out["ingest"] = await adb(_ingest_summary, _db())
    return out


@router.get("/api/published-apis/metrics/top")
async def metrics_top(window: str = Query("24h", pattern="^(1h|24h|7d|30d|90d)$"),
                      by: str = Query("calls", pattern="^(calls|p95|errors|bytes|rate_limited)$"),
                      n: int = Query(10, ge=1, le=100), user: dict = Depends(require_capability("published_api.view"))):
    """Busiest / slowest / most-erroring / heaviest / most-refused APIs and consumers."""
    _require_reader(user)
    from core.published_api.rollup import top, _utcnow
    end = _utcnow()   # the rollup's clock, one seam (a test pins it; 2026-10-18)
    out = await adb(top, _db(), start=end - _window(window), end=end, by=by, n=n)
    if not is_admin_like(user):
        apis, _meta = await asyncio.to_thread(_build)
        mine = {f"{a.api_kind}:{a.key}" for a in visible_to(apis, user) if not a.is_redacted}
        out["apis"] = [a for a in out["apis"] if a["key"] in mine]
        out["consumers"] = []
        out["restricted"] = "an analyst sees their own APIs; consumers are the admin's view"
    return out


@router.get("/api/published-apis/idle")
async def idle(days: Optional[int] = Query(None, ge=0), user: dict = Depends(require_capability("published_api.view"))):
    """APIs with no call recorded in N days -- retirement candidates.  An API
    whose last call could not be read is listed with ``unknown``."""
    _require_reader(user)
    from core.config import published_views as _pv
    n = int(days if days is not None else _pv.inventory_idle_days_default)
    apis, meta = await asyncio.to_thread(_build)
    apis = [a for a in visible_to(apis, user) if not a.is_redacted]
    items = filter_apis(apis, idle_days=n)
    return {"days": n, "items": [{"api_kind": a.api_kind, "api_id": a.api_id, "key": a.key, "name": a.name,
                                  "owner": a.owner, "lifecycle": (a.lifecycle or {}).get("status"),
                                  "last_call": a.last_call, "consumers": len([c for c in a.consumers if c.is_active])}
                                 for a in items],
            "count": len(items), **_meta_block(meta)}


def _ingest_summary(db) -> Dict[str, Any]:
    """The access-log writers as the dashboard judges them -- THE generic
    silence rule (core/component_health/retire.py::silence_verdict) applied
    to their heartbeat rows by core/published_api/ingest_health.py: the LIVE
    writers' losses are the verdict, a DOWN writer is listed and never
    summed, a RETIRED one is gone (2026-10-18, found on the rebuilt rig: the
    rows of processes replaced with the containers were summed in)."""
    from core.published_api.ingest_health import summary
    return summary(db)


@router.get("/api/published-apis/health")
async def health(user: dict = Depends(require_capability("published_api.view"))):
    """The numbers' own health: the rollup watermark and lag, the daemon's
    last tick (the background-job ledger), the writers' ingest health, the
    raw record's size.  Every field present or ``unknown`` with a reason."""
    _require_reader(user)
    from core.published_api.rollup import watermark
    out: Dict[str, Any] = {}
    try:
        out["rollup"] = await adb(watermark, _db())
    except Exception as exc:                            # noqa: BLE001
        out["rollup"] = {"state": "unknown", "reason": f"{type(exc).__name__}: {exc}"}
    try:
        from core.background_job_contract import status as _job_status
        out["daemon"] = await _job_status("published_api_rollup", _db(), limit=3)
    except Exception as exc:                            # noqa: BLE001
        out["daemon"] = {"state": "unknown", "reason": f"{type(exc).__name__}: {exc}"}
    out["ingest"] = await adb(_ingest_summary, _db())
    try:
        with _db().engine.connect() as conn:
            from sqlalchemy import text as _t
            n = conn.execute(_t("SELECT COUNT(*) FROM api_access_log")).scalar()
            oldest = conn.execute(_t("SELECT MIN(created_at) FROM api_access_log")).scalar()
        out["call_record"] = {"rows": int(n or 0), "oldest_at": str(oldest) if oldest else None}
    except Exception as exc:                            # noqa: BLE001
        out["call_record"] = {"state": "unknown", "reason": f"{type(exc).__name__}: {exc}"}
    return out


# ── alert thresholds + alerts (design §3.8; core/published_api/alerts.py) ──

class ThresholdBody(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)
    scope: str = Field("global", pattern="^(global|kind|api)$")
    api_kind: str = Field("", max_length=30)
    scope_key: str = Field("", max_length=220)
    metric: str = Field(..., max_length=32)
    operator: str = Field(">", pattern="^(>|>=|<|<=)$")
    value: float
    window_minutes: int = Field(15, ge=0, le=10080)
    min_calls: int = Field(50, ge=0)
    clear_after_windows: int = Field(2, ge=1, le=1000)
    alert_kind: str = Field(..., max_length=60)
    is_active: bool = True


class ThresholdPatch(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=120)
    scope: Optional[str] = Field(None, pattern="^(global|kind|api)$")
    api_kind: Optional[str] = Field(None, max_length=30)
    scope_key: Optional[str] = Field(None, max_length=220)
    metric: Optional[str] = Field(None, max_length=32)
    operator: Optional[str] = Field(None, pattern="^(>|>=|<|<=)$")
    value: Optional[float] = None
    window_minutes: Optional[int] = Field(None, ge=0, le=10080)
    min_calls: Optional[int] = Field(None, ge=0)
    clear_after_windows: Optional[int] = Field(None, ge=1, le=1000)
    alert_kind: Optional[str] = Field(None, max_length=60)
    is_active: Optional[bool] = None


def _own_api_keys(apis, user: dict):
    """``{(kind, key)}`` of the APIs this user owns (admin / support: all)."""
    full = visible_to(apis, user)
    return {(a.api_kind, str(a.key)) for a in full if not a.is_redacted}


async def _validated_threshold(data: Dict[str, Any]) -> Dict[str, Any]:
    """Every refusal in one 422 (the UI shows them all)."""
    from core.published_api.alerts import validate_threshold
    from core.published_api.registry import load
    apis, _meta = await asyncio.to_thread(_build)
    kinds_rows = await adb(_db().list_feed_alert_kinds, True)
    problems = validate_threshold(data, kinds=load().kinds(), api_keys={(a.api_kind, str(a.key)) for a in apis},
                                  alert_kinds=[k["kind"] for k in kinds_rows])
    if problems:
        raise HTTPException(422, "; ".join(problems))
    return data


def _with_states(rows: List[dict], states: List[dict]) -> List[dict]:
    by_thr: Dict[int, List[dict]] = {}
    for s in states:
        by_thr.setdefault(int(s["threshold_id"]), []).append(s)
    return [{**r, "states": by_thr.get(int(r["id"]), [])} for r in rows]


@router.get("/api/published-apis/alert-thresholds")
async def list_alert_thresholds(user: dict = Depends(require_capability("published_api.view"))):
    """Every threshold with each (threshold, API) verdict, the metric
    vocabulary, the alert kinds a breach may raise and the seeded AlertGroup.
    An analyst sees the global and kind-wide rows (they apply to their APIs)
    and the API-scoped rows of their own APIs; the verdicts likewise."""
    _require_reader(user)
    from core.published_api.alerts import API_ALERT_KIND_NAMES, METRICS, OPERATORS, SCOPES, STATES, alert_group
    rows = await adb(_db().list_published_api_alert_thresholds, False)
    states = await adb(_db().list_published_api_alert_states)
    kinds_rows = await adb(_db().list_feed_alert_kinds, True)
    if not (is_admin_like(user) or str(user.get("role") or "") in ("support", "admin_read")):
        apis, _meta = await asyncio.to_thread(_build)
        own = _own_api_keys(apis, user)
        rows = [r for r in rows if r["scope"] != "api" or (r["api_kind"], str(r["scope_key"])) in own]
        states = [s for s in states if (s["api_kind"], str(s.get("api_slug"))) in own]
    return {"thresholds": _with_states(rows, states), "count": len(rows), "metrics": METRICS,
            "operators": list(OPERATORS), "scopes": list(SCOPES), "states": list(STATES),
            "alert_kinds": kinds_rows, "api_alert_kinds": list(API_ALERT_KIND_NAMES), "alert_group": alert_group()}


@router.post("/api/published-apis/alert-thresholds")
async def create_alert_threshold(body: ThresholdBody, user: dict = Depends(require_capability("published_api.manage"))):
    data = await _validated_threshold(body.model_dump())
    try:
        row = await adb(_db().create_published_api_alert_threshold, data, user.get("username"))
    except ValueError as exc:
        raise HTTPException(409, str(exc))
    audit_event(_db(), user, None, "api.threshold_created", "api_alert_threshold", str(row["id"]), row)
    return row


@router.put("/api/published-apis/alert-thresholds/{threshold_id}")
async def update_alert_threshold(threshold_id: int, body: ThresholdPatch, user: dict = Depends(require_capability("published_api.manage"))):
    cur = await adb(_db().get_published_api_alert_threshold, threshold_id)
    if cur is None:
        raise HTTPException(404, f"no threshold #{threshold_id}")
    patch = {k: v for k, v in body.model_dump().items() if v is not None}
    merged = {**cur, **patch}
    await _validated_threshold(merged)
    try:
        row = await adb(_db().update_published_api_alert_threshold, threshold_id, patch, user.get("username"))
    except ValueError as exc:
        raise HTTPException(409, str(exc))
    audit_event(_db(), user, None, "api.threshold_updated", "api_alert_threshold", str(threshold_id),
                {"before": cur, "after": row})
    return row


@router.delete("/api/published-apis/alert-thresholds/{threshold_id}")
async def delete_alert_threshold(threshold_id: int, user: dict = Depends(require_capability("published_api.manage"))):
    cur = await adb(_db().get_published_api_alert_threshold, threshold_id)
    if cur is None:
        raise HTTPException(404, f"no threshold #{threshold_id}")
    from core.published_api.alerts import retire_threshold
    outcome = await adb(retire_threshold, _db(), threshold_id, by=f"{user.get('username') or 'admin'}:threshold deleted")
    audit_event(_db(), user, None, "api.threshold_deleted", "api_alert_threshold", str(threshold_id),
                {**cur, "alerts_cleared": outcome["alerts_cleared"]})
    return {"deleted": threshold_id, "alerts_cleared": outcome["alerts_cleared"],
            "note": "the alerts this threshold raised were cleared with it (Netcool resolutions sent)"}


@router.get("/api/published-apis/alerts")
async def list_api_alerts(status: str = Query("open", pattern="^(open|cleared|all)$"),
                          kind: str = Query("published_view"), api: Optional[str] = Query(None),
                          limit: int = Query(200, ge=1, le=2000), user: dict = Depends(require_capability("published_api.view"))):
    """The alerts about published APIs (``feed_alerts`` rows with
    ``subject_kind = published_api``) in the board's public shape; one API
    with ``kind`` + ``api``.  An analyst sees their own APIs' alerts."""
    _require_reader(user)
    from core.feed.feed_alerts import public as _public
    from core.published_api.alerts import SUBJECT_KIND, subject_key_of
    rows = await adb(_db().list_feed_alerts, subject_kind=SUBJECT_KIND,
                     subject_key=subject_key_of(kind, api) if api else None,
                     status=None if status == "all" else status, limit=limit)
    if not (is_admin_like(user) or str(user.get("role") or "") in ("support", "admin_read")):
        apis, _meta = await asyncio.to_thread(_build)
        own = {subject_key_of(k, key) for k, key in _own_api_keys(apis, user)}
        rows = [r for r in rows if r.get("subject_key") in own]
    return {"alerts": [_alert_face(a) for a in rows], "count": len(rows), "status": status}


def _alert_face(a: dict) -> dict:
    """The board's public shape PLUS the two keys a reader needs to follow one
    alert through its life (2026-10-18, the rig proof asked the public shape
    for a dedupe key it never carried): ``dedupe_key`` names the (API,
    threshold) pair, ``netcool_identifier`` the event the resolution closes."""
    from core.feed.feed_alerts import public as _public
    return {**_public(a), "dedupe_key": a.get("dedupe_key"), "netcool_identifier": a.get("netcool_identifier")}


# ── one API ───────────────────────────────────────────────────────────────

def _find(apis, kind: str, api_id: int):
    for a in apis:
        if a.api_kind == kind and int(a.api_id) == int(api_id):
            return a
    return None


@router.get("/api/published-apis/{kind}/{api_id}")
async def get_published_api(kind: str, api_id: int, user: dict = Depends(require_capability("published_api.view"))):
    _require_reader(user)
    apis, meta = await asyncio.to_thread(_build, [kind])
    api = _find(visible_to(apis, user), kind, api_id)
    if api is None:
        raise HTTPException(404, f"no published API {kind} #{api_id}")
    out = api.to_dict()
    if not api.is_redacted:
        # the newest call rows, and what rests on this API's dependencies
        try:
            from core.published_api.numbers import recent_calls
            out["recent_calls"] = await adb(recent_calls, _db(), kind, int(api_id), limit=20)
        except Exception as exc:                        # noqa: BLE001
            out["recent_calls"] = None
            out["recent_calls_error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
        from core.published_api.alerts import SUBJECT_KIND, subject_key_of, thresholds_for
        try:
            rows = await adb(_db().list_feed_alerts, subject_kind=SUBJECT_KIND,
                             subject_key=subject_key_of(api.api_kind, api.key), status="open", limit=50)
            out["alerts"] = [_alert_face(a) for a in rows]
        except Exception as exc:                        # noqa: BLE001
            out["alerts"] = None
            out["alerts_error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
        try:
            out["thresholds"] = await adb(thresholds_for, _db(), api)
        except Exception as exc:                        # noqa: BLE001
            out["thresholds"] = None
            out["thresholds_error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
    return {**out, **_meta_block(meta)}


class LifecycleBody(BaseModel):
    status: str = Field(..., pattern="^(draft|active|deprecated|retired)$")
    sunset_at: Optional[datetime] = None
    deprecation_note: Optional[str] = Field(None, max_length=2000)
    successor: Optional[str] = Field(None, max_length=220)


@router.put("/api/published-apis/{kind}/{api_id}/lifecycle")
async def set_lifecycle(kind: str, api_id: int, body: LifecycleBody, user: dict = Depends(require_capability("published_api.create"))):
    """Move an API through its lifecycle.  The owner or an admin; retired ->
    anything is an admin's act.  Deprecating tells the consumers."""
    from core.published_api import lifecycle as lc
    from core.published_api.registry import load
    reg = load()
    k = reg.get(kind)
    if k is None:
        raise HTTPException(404, f"unknown published-API kind {kind!r}")
    apis, _meta = await asyncio.to_thread(_build, [kind])
    api = _find(apis, kind, api_id)
    if api is None:
        raise HTTPException(404, f"no published API {kind} #{api_id}")
    me = str(user.get("username") or "")
    admin = is_admin_like(user)
    if not admin and api.owner != me and api.created_by != me:
        raise HTTPException(403, "only the API's owner or an admin may change its lifecycle")
    current = (api.lifecycle or {}).get("status")
    succ_exists = succ_status = None
    if body.successor:
        s = _find(apis, kind, -1)                        # by key, same kind
        s = next((a for a in apis if a.key == body.successor), None)
        succ_exists = s is not None
        succ_status = (s.lifecycle or {}).get("status") if s else None
        if s is not None and s.api_id == api.api_id:
            raise HTTPException(422, "an API cannot be its own successor")
    try:
        lc.validate_change(current, body.status, is_admin=admin, sunset_at=body.sunset_at,
                           successor=body.successor, successor_exists=succ_exists, successor_status=succ_status)
    except lc.LifecycleRefused as exc:
        raise HTTPException(exc.status, str(exc))
    if body.status == lc.LIFECYCLE_DEPRECATED and body.sunset_at is not None:
        s_at = body.sunset_at if body.sunset_at.tzinfo else body.sunset_at.replace(tzinfo=timezone.utc)
        if s_at <= datetime.now(timezone.utc):
            raise HTTPException(422, "the sunset date must be in the future (retire the API instead)")
    fields = lc.fields_for(body.status, sunset_at=body.sunset_at, note=body.deprecation_note,
                           successor=body.successor, actor=me)
    row = await adb(_db().set_api_lifecycle, k.model, int(api_id), fields,
                    offered=lc.is_offered(body.status), set_offered=k.set_offered)
    if row is None:
        raise HTTPException(404, f"no published API {kind} #{api_id}")
    notified = None
    if body.status in (lc.LIFECYCLE_DEPRECATED, lc.LIFECYCLE_RETIRED) and current != body.status:
        from core.published_api.notices import notify_consumers
        api.lifecycle = lc.lifecycle_of(row, lc.is_offered(body.status))
        notified = await asyncio.to_thread(notify_consumers, _db(), api, body.status)
    audit_event(_db(), user, None, "api.lifecycle_changed", "published_api", f"{kind}:{api_id}",
                {"kind": kind, "key": api.key, "from": current, "to": body.status,
                 "sunset_at": body.sunset_at.isoformat() if body.sunset_at else None,
                 "successor": body.successor, "notified": notified})
    return {"kind": kind, "api_id": int(api_id), "key": api.key, "from": current,
            "lifecycle": lc.lifecycle_of(row, lc.is_offered(body.status)), "notified": notified}


@router.get("/api/published-apis/{kind}/{api_id}/calls")
async def list_calls(kind: str, api_id: int, limit: int = Query(100, ge=1, le=1000),
                     status: Optional[int] = Query(None), consumer: Optional[str] = Query(None),
                     user: dict = Depends(require_capability("published_api.view"))):
    """The raw call rows of one API, newest first (the drill-down; the
    dashboard's numbers come from the rollup)."""
    _require_reader(user)
    apis, _meta = await asyncio.to_thread(_build, [kind])
    api = _find(visible_to(apis, user), kind, api_id)
    if api is None:
        raise HTTPException(404, f"no published API {kind} #{api_id}")
    if api.is_redacted:
        raise HTTPException(403, "another publisher's API: its calls are not yours to read")
    from core.published_api.numbers import recent_calls
    try:
        rows = await adb(recent_calls, _db(), kind, int(api_id), limit=limit, status=status, consumer=consumer)
    except Exception as exc:                            # noqa: BLE001
        raise HTTPException(503, f"the call record could not be read: {type(exc).__name__}: {exc}")
    return {"kind": kind, "api_id": int(api_id), "key": api.key, "calls": rows, "count": len(rows)}


# ── a key's face ──────────────────────────────────────────────────────────

class KeyIdentityBody(BaseModel):
    consumer: Optional[str] = Field(None, max_length=200)
    owner_username: Optional[str] = Field(None, max_length=100)
    contact_email: Optional[str] = Field(None, max_length=255)


@router.put("/api/api-keys/{key_id}/identity")
async def set_key_identity(key_id: int, body: KeyIdentityBody, user: dict = Depends(require_capability("published_api.keys.approve"))):
    fields = body.model_dump(exclude_unset=True)
    if not fields:
        raise HTTPException(422, "nothing to change: give consumer, owner_username or contact_email")
    if "contact_email" in fields and fields["contact_email"]:
        from core.email_service import _valid_recipients
        if not _valid_recipients([fields["contact_email"]]):
            raise HTTPException(422, f"{fields['contact_email']!r} is not an e-mail address")
    row = await adb(_db().update_api_key_identity, int(key_id), fields)
    if row is None:
        raise HTTPException(404, "API key not found")
    audit_event(_db(), user, None, "api.key_consumer_set", "api_key", int(key_id), fields)
    return row


# ── try an API AS one of its consumers (2026-10-24) ──────────────────────

@router.post("/api/api-keys/{key_id}/try-as-token")
async def mint_try_as_token(key_id: int, user: dict = Depends(require_capability("published_api.keys.approve"))):
    """A short-lived token to call the published endpoints AS this key
    (core/published_api/try_as.py): the API Explorer sends it in
    ``X-QS-Try-As`` and the endpoint answers with the key's own scope, row
    security and refusals.  Admin only; audited ``api.try_as_minted``."""
    from api.deps import api_key_refusal
    from core.published_api.try_as import TryAsRefused, mint
    row = await adb(_db().get_api_key, int(key_id))
    if row is None:
        raise HTTPException(404, "API key not found")
    why = api_key_refusal(row)
    if why:
        raise HTTPException(409, f"This key cannot call -- {why}")
    try:
        out = mint(int(key_id), str((user or {}).get("username") or ""))
    except TryAsRefused as exc:
        raise HTTPException(503, str(exc))
    audit_event(_db(), user, None, "api.try_as_minted", "api_key", int(key_id),
                {"expires_at": out["expires_at"]})
    return {**out, "key": {"id": row.get("id"), "name": row.get("name"),
                           "key_prefix": row.get("key_prefix"),
                           "scoped_view_ids": row.get("scoped_view_ids") or []}}


# ── the delete routes' one rule ──────────────────────────────────────────

async def refuse_if_apis_depend_async(db, kind: str, obj_id: int, *, acknowledged: bool, actor: dict,
                                      action: str = "api.dependency_removed") -> List[dict]:
    """The async face of impact.refuse_if_apis_depend for the delete routes
    (connection / saved query / SQL file / federation view / dataset /
    report): off the loop; ImpactRefused -> 409 / 503."""
    try:
        return await asyncio.to_thread(refuse_if_apis_depend, db, kind, int(obj_id),
                                       acknowledged=bool(acknowledged), actor=actor, action=action,
                                       audit=audit_event)
    except ImpactRefused as exc:
        raise HTTPException(exc.status, exc.detail)


__all__ = ["refuse_if_apis_depend_async", "router", "set_published_api_dependencies"]
