"""
Business Portal API (Phase 59)

Endpoints:
  GET /api/portal/summary  — aggregated portal landing page data
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)

from api.deps import get_current_user
from core.roles import ADMIN_TIER_ROLES

logger = logging.getLogger(__name__)

router = APIRouter(tags=["portal"])

_db_manager = None
_auth_cfg = None


def set_portal_dependencies(db_manager, auth_cfg):
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg = auth_cfg


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


# ── Portal summary endpoint ──────────────────────────────────────────────────

@router.get("/api/portal/summary")
async def get_portal_summary(user: dict = Depends(require_capability("reports.view"))):
    """Aggregated portal data for the landing page."""
    from core import config as _cfg

    portal_cfg = _cfg.business_portal
    if not portal_cfg.enabled:
        raise HTTPException(status_code=403, detail="Business portal is disabled")

    db = _require_db()
    username = (user or {}).get("username", "")
    role = (user or {}).get("role", "viewer")

    # BF-NONBLOCK-AUDIT-5: portal landing makes 6-8 sync DB calls +
    # per-recent/favorite enrichment.  Wrap whole body in to_thread.
    def _inner() -> Dict[str, Any]:
        report_counts = db.count_user_reports(username, role)
        favorites_all = db.get_user_favorites(username, report_type=None)
        exec_today = db.count_executions_today(username)
        unread = db.count_unread_notifications(username)
        _is_admin = role in ADMIN_TIER_ROLES
        dashboards = db.list_dashboards(
            created_by=None if _is_admin else username,
            is_admin=_is_admin,
        )

        kpi = {
            "total_reports": report_counts["total"],
            "favorites_count": len(favorites_all),
            "executions_today": exec_today,
            "unread_notifications": unread,
            "dashboards_count": len(dashboards),
        }

        recent_ids = db.get_recently_viewed(
            username, limit=portal_cfg.recent_reports_limit, report_type=None,
        )
        # Re-authorise recents/favourites through the SAME visibility rule
        # the listing surfaces use -- a report the caller viewed once but is
        # no longer entitled to must not reappear here (nor ship its full
        # detail).  ctx is resolved ONCE so the per-report business check is
        # dict-only (recents+favourites = ~20 rows, was 1-5 SQL each).
        try:
            from core.reports.authorization import resolve_viewer_context
            _view_ctx = resolve_viewer_context(user, db)
        except Exception:
            _view_ctx = None
        recent_reports = _enrich_report_ids(db, recent_ids, user, _view_ctx)

        fav_reports = _enrich_report_ids(
            db, favorites_all[:portal_cfg.favorites_limit], user, _view_ctx,
        )

        try:
            # Slim projection: the certified-template gallery renders a
            # name/description/category card and opens through the guarded
            # viewer route.  list_certified_templates returns full to_dict()
            # (incl. raw_sql_override) -- a landing-page card must not ship
            # the inline SQL of every certified report to every viewer.
            templates = [
                _slim_portal_report(t, "business")
                for t in db.list_certified_templates(
                    limit=portal_cfg.certified_templates_limit,
                )
            ]
        except Exception:
            templates = []

        recent_activity: List[Dict[str, Any]] = []
        if role in ("admin", "analyst", "super_admin"):
            try:
                recent_activity = db.list_audit_log(
                    username=username if role == "analyst" else None,
                    limit=portal_cfg.recent_activity_limit,
                )
            except Exception:
                recent_activity = []

        active_queries = 0
        if role in ADMIN_TIER_ROLES:
            try:
                from core.execution_state import running_tasks
                active_queries = sum(1 for t in running_tasks.values()
                                     if not t.done())
            except Exception:
                active_queries = 0

        return {
            "welcome_message":       portal_cfg.welcome_message,
            "welcome_subtitle":      portal_cfg.welcome_subtitle,
            "kpi":                   kpi,
            "recent_reports":        recent_reports,
            "favorites":             fav_reports,
            "certified_templates":   templates,
            "recent_activity":       recent_activity,
            "dashboards":            [_slim_dashboard(d) for d in dashboards[:6]],
            "quick_actions_enabled": portal_cfg.quick_actions_enabled,
            "kpi_cards_enabled":     portal_cfg.kpi_cards_enabled,
            "active_queries":        active_queries,
            "role":                  role,
        }

    return await asyncio.to_thread(_inner)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _slim_portal_report(r: dict, rtype: str) -> Dict[str, Any]:
    """The card projection BusinessPortalPage renders -- NOT a detail
    payload.  ``to_dict()`` carries ``raw_sql_override`` / ``sql_override``;
    a landing-page card needs none of it."""
    return {
        "id":                r.get("id"),
        "slug":              r.get("slug"),      # 2026-09-20: the card LINKS to /finance-reports/<slug>
        "name":              r.get("name"),
        "description":       r.get("description") or "",
        "report_type":       rtype,
        "is_certified":      bool(r.get("is_certified")),
        "template_category": r.get("template_category"),
        "owner":             r.get("owner") or r.get("created_by"),
    }


def _enrich_report_ids(db, id_list, user, ctx=None):
    """Resolve {report_id, report_type} rows to slim, RE-AUTHORISED cards.

    A recents/favourites id is not proof of current access: the row was
    recorded when the caller opened the report, and access can be revoked
    afterwards.  Each id is re-checked through the SAME chokepoint the
    listing surfaces use (``can_view_business_report``) so a revoked report
    neither reappears here nor ships its definition.  Fail-CLOSED: a broken
    chokepoint import yields an empty list, never an unfiltered one.
    FB-60 (2026-09-26): a row whose ``report_type`` is the legacy
    ``parametric`` is skipped -- nothing serves that table any more.
    """
    try:
        from core.reports.authorization import can_view_business_report
    except Exception:
        return []
    results: List[Dict[str, Any]] = []
    for item in id_list:
        rid = item.get("report_id")
        rtype = item.get("report_type") or "business"
        if rtype != "business":
            # FB-60 (2026-09-26): a recents/favourites row that pointed at the
            # legacy parametric table -- nothing serves it, so no card.
            continue
        try:
            r = db.get_business_report(rid)
            if not r or not can_view_business_report(r, user, db, ctx=ctx):
                continue
            results.append(_slim_portal_report(r, rtype))
        except Exception:
            pass  # skip deleted/inaccessible reports
    return results


def _slim_dashboard(d):
    """Return minimal dashboard info for portal cards."""
    return {
        "id": d.get("id"),
        "name": d.get("name"),
        "widget_count": len(d.get("widgets") or []),
        "updated_at": d.get("updated_at"),
    }


# ── Report portal ────────────────────────────────────────────────────────────

@router.get("/api/portal/reports")
async def list_portal_reports(
    limit: int = 60,
    cursor: str = "",
    q: str = "",
    sort: str = "",
    favorites_only: bool = False,
    folder_id: Optional[int] = None,
    tag_id: Optional[int] = None,
    user: dict = Depends(require_capability("reports.view")),
):
    """The reports a user may open from the portal — published, and mapped to
    them.

    2026-08-10.  There was no such endpoint: the portal landing page showed
    counts, recents and favourites, and every "see all" link went to
    ``/report-catalog``, which is an authoring/browsing screen.  A consumer who
    has been GIVEN two reports had no screen that simply listed those two.

    This is deliberately a thin wrapper over the existing visibility
    chokepoint rather than a fourth visibility rule:
    ``core.reports.authorization.list_visible_business_reports_page`` pushes
    ``_br_visibility_clauses`` INSIDE the SQL (so pagination composes with
    visibility instead of filtering a page after limiting it) and trims the
    ``role_whitelist`` on published rows in Python.  ``published_only=True``
    maps to ``is_published=True``, which is applied for EVERY caller including
    the admin tier — an unpublished draft is not portal content even for its
    author, and the composite index ``ix_business_reports_published_updated``
    covers exactly this query.

    Items are ``to_summary_dict()`` — the slim list projection that
    deliberately excludes ``raw_sql_override`` — decorated with
    ``is_favorite`` / ``tags`` / ``folder_id``.  A list payload is not a
    detail payload.

    2026-08-11 — ``sort`` (``updated`` | ``name`` | ``last_run``),
    ``favorites_only``, ``folder_id`` and ``tag_id``.  All four are NARROWING
    options layered on the SAME visibility chokepoint; none of them is a
    second access rule, and none can widen what a viewer sees.  Sorting is
    SERVER-side and rides the existing keyset cursor (which now carries the
    sort it was minted under, so a stale cursor is a 400 rather than a page
    that quietly skips rows).  Favourites reuse the existing
    ``report_favorites`` table with ``report_type='business'`` — the same
    star the report catalog writes.
    """
    from core import config as _cfg
    from core.reports.authorization import list_visible_business_reports_page

    if not _cfg.business_portal.enabled:
        raise HTTPException(status_code=403, detail="Business portal is disabled")

    db = _require_db()
    # A caller-supplied limit must THROTTLE, not refuse: clamp it.
    safe_limit = max(1, min(int(limit or 60), 200))

    def _inner() -> Dict[str, Any]:
        return list_visible_business_reports_page(
            db, user,
            limit=safe_limit,
            cursor=cursor or None,
            published_only=True,
            q=q or None,
            sort=sort or None,
            favorites_only=bool(favorites_only),
            folder_id=folder_id,
            tag_id=tag_id,
        )

    try:
        page = await asyncio.to_thread(_inner)
    except ValueError as exc:
        # malformed cursor — the chokepoint's documented contract
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("portal report list failed for %s: %s",
                     (user or {}).get("username", "?"), exc, exc_info=True)
        raise HTTPException(status_code=500,
                            detail=f"Could not list reports: {exc}") from exc

    logger.info("Portal reports: user=%s sort=%s fav_only=%s returned=%d "
                "has_more=%s", (user or {}).get("username", "?"),
                page.get("sort"), bool(favorites_only),
                len(page.get("items") or []), page.get("has_more"))
    return page


@router.post("/api/portal/reports/{report_id}/favorite")
async def toggle_portal_report_favorite(
    report_id: int,
    user: dict = Depends(require_capability("reports.view")),
):
    """Star / unstar a business report for the calling user.

    Writes the SAME ``report_favorites`` row the report catalog writes
    (``report_type="business"``), so one star is visible on both screens.
    This endpoint exists because ``catalog_api`` is deliberately NOT mounted
    on the reports pod (``main.py`` excludes catalog + portal routers in
    reports mode), and a portal that can list favourites but not set them is
    only half a feature.

    VISIBILITY GOES THROUGH ``can_view_business_report`` — the same single
    rule the list uses.  Without this check, favouriting would be an oracle:
    404 vs 200 would tell an unauthorised caller whether a report exists.
    """
    from core import config as _cfg
    from core.reports.authorization import can_view_business_report

    if not _cfg.business_portal.enabled:
        raise HTTPException(status_code=403, detail="Business portal is disabled")

    db = _require_db()
    username = ((user or {}).get("username") or "").strip()
    if not username:
        raise HTTPException(status_code=401, detail="Authentication required")

    def _inner() -> Dict[str, Any]:
        report = db.get_business_report(int(report_id))
        # Same answer for "does not exist" and "not yours" — see docstring.
        if not report or not can_view_business_report(report, user, db):
            raise PermissionError("not visible")
        added = db.toggle_report_favorite(
            int(report_id), username, report_type="business")
        return {"report_id": int(report_id), "is_favorite": bool(added)}

    try:
        return await asyncio.to_thread(_inner)
    except PermissionError:
        raise HTTPException(status_code=404, detail="Report not found")
    except Exception as exc:
        logger.error("portal favorite toggle failed (report=%s user=%s): %s",
                     report_id, username, exc, exc_info=True)
        raise HTTPException(status_code=500,
                            detail=f"Could not update favourite: {exc}") from exc
