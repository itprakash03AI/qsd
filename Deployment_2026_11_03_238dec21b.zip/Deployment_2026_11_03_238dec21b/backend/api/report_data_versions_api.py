"""The report run panel's "Data version" listing (2026-11-01).

``GET /api/business-reports/{id}/data-versions`` -- the Iceberg tables the
report reads, ONE row per table per side (each storage connection of the
report's dataset, and of the second dataset of a UNION report), with that
table's versions newest first and the version the dataset's own SQL pins it
at ("As saved").  The viewer draws its Data version control ONLY when
``supported`` is true; the choice travels as ``data_version`` on the run body
(``business_reports_api._with_data_version`` -- the ONE parser checks it).

One listing, one decision: the rows come from
``connections_api.storage_table_versions`` (the SQL editor's listing), so the
person's rights on each TABLE (``core.table_version_access``) decide what is
listed exactly as there.  The report's view rule first; nothing is listed
for a report the caller may not open.

Only storage connections are listed: the report road resolves versions on
QueryStudio's own reader (``FederationEngine._resolve_dataset_versions``); a
report over a SQL source answers ``supported: false`` with the reason, and
the control is not drawn.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException

from api.deps import require_capability

logger = logging.getLogger(__name__)
router = APIRouter(tags=["business-reports"])

NOT_VERSIONED = ("This report reads no table that keeps versions, so there is no data "
                 "version to choose.")


async def _adb(fn, *args, **kwargs):
    return await asyncio.to_thread(fn, *args, **kwargs)


def _require_db():
    from api.deps import require_db
    return require_db()


def report_iceberg_tables(db, report: Dict[str, Any]) -> List[Dict[str, Any]]:
    """``[{dataset_id, connection_id, connection, conn_raw, tables: [{table,
    snapshot_id, as_of_ms}]}]`` -- per dataset of the report, per STORAGE
    connection holding Iceberg tables, the ones the dataset reads (its SQL's
    own pins kept).  The same reading the run's resolver makes: the SQL when
    the dataset has one, else its source tables."""
    from core import iceberg_versions as _iv
    from api.connections_api import _iceberg_registered
    out: List[Dict[str, Any]] = []
    ids = [report.get("dataset_id")]
    if (report.get("merge_config") or {}).get("merge_type") == "union" and report.get("merged_dataset_id"):
        ids.append(report.get("merged_dataset_id"))
    for ds_id in [i for i in ids if i]:
        ds = db.get_dataset(int(ds_id)) or {}
        sql = ds.get("base_query") or ""
        names = [str(t.get("table") or t.get("name") or "").lower()
                 for t in (ds.get("source_tables") or []) if isinstance(t, dict)]
        for cid in ds.get("connection_ids") or []:
            conn = db.get_connection_raw(int(cid)) or {}
            if str(conn.get("connection_type") or "").lower() != "s3":
                continue
            regs = _iceberg_registered(conn)
            if not regs:
                continue
            if sql:
                tables = _iv.iceberg_tables_in_sql(sql, [r.get("name") for r in regs.values()])
            else:
                tables = [{"table": regs[n].get("name"), "snapshot_id": None, "as_of_ms": None}
                          for n in names if n in regs]
            if tables:
                out.append({"dataset_id": int(ds_id), "connection_id": int(cid),
                            "connection": conn.get("name") or f"connection {cid}",
                            "conn_raw": conn, "tables": tables})
    return out


@router.get("/api/business-reports/{report_id}/data-versions")
async def report_data_versions(report_id: int,
                               user: dict = Depends(require_capability("reports.view"))):
    from api import business_reports_api as br
    from api.connections_api import storage_table_versions
    from core import iceberg_versions as _iv
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not await _adb(br._br_can_view, report, user):
        raise HTTPException(status_code=403, detail="Access denied")
    try:
        sides = await _adb(report_iceberg_tables, db, report)
    except _iv.IcebergVersionRefusal as exc:
        return {"report_id": report_id, "supported": False, "reason": str(exc), "tables": []}
    rows: List[Dict[str, Any]] = []
    for side in sides:
        listed = await storage_table_versions(side["conn_raw"], side["connection_id"],
                                              side["tables"], user)
        for r in listed:
            rows.append({
                "table": r.get("table"),
                "side": side["connection"],
                "connection_id": side["connection_id"],
                "dataset_id": side["dataset_id"],
                "saved": ({"snapshot_id": r.get("snapshot_id"), "as_of_ms": r.get("as_of_ms")}
                          if r.get("snapshot_id") or r.get("as_of_ms") else None),
                "current_snapshot_id": r.get("current_snapshot_id"),
                "versions": r.get("versions"),
                "access": r.get("access"),
                "access_words": r.get("access_words"),
                "reason": r.get("reason"),
                "error": r.get("error"),
            })
    # a table name on two sides takes ONE key in data_version: a version number
    # belongs to one side's table, so only a time / latest can be asked for it
    counts: Dict[str, int] = {}
    for r in rows:
        counts[str(r["table"]).lower()] = counts.get(str(r["table"]).lower(), 0) + 1
    for r in rows:
        r["on_several_sides"] = counts[str(r["table"]).lower()] > 1
    if not rows:
        return {"report_id": report_id, "supported": False, "reason": NOT_VERSIONED, "tables": []}
    return {"report_id": report_id, "supported": True, "reason": None, "tables": rows}
