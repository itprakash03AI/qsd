"""
Schedules API — CRUD + control for scheduled query/report downloads.

Endpoints:
  GET    /api/schedules                  — list schedules
  POST   /api/schedules                  — create + register with APScheduler
  GET    /api/schedules/{id}             — get schedule detail
  PUT    /api/schedules/{id}             — update (re-registers trigger)
  DELETE /api/schedules/{id}             — remove from scheduler, switch the row OFF
  POST   /api/schedules/{id}/pause       — pause (keeps trigger, stops firing)
  POST   /api/schedules/{id}/resume      — resume a paused schedule
  POST   /api/schedules/{id}/run-now     — trigger an immediate run
  GET    /api/schedules/scheduler-status — APScheduler health info
"""

from __future__ import annotations

import asyncio
import functools
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Query as QParam, Request, Depends
from api.deps import require_capability
from pydantic import BaseModel

from core.audit import audit_event
from core.roles import is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager  = None
_ws_manager  = None
_main_loop   = None
_auth_cfg    = None   # core.config.auth singleton
_sched_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="sched_api")  # legacy, phasing out


def set_schedule_dependencies(db_manager, ws_manager, loop):
    global _db_manager, _ws_manager, _main_loop
    _db_manager = db_manager
    _ws_manager = ws_manager
    _main_loop  = loop


def set_schedules_auth(auth_cfg):
    global _auth_cfg
    _auth_cfg = auth_cfg


def _get_current_user_sched(request: Request) -> Optional[dict]:
    """Local version of _get_current_user for the schedules router."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "display_name": "Guest", "is_admin": True, "groups": [], "role": "admin"}
    from core.ad_auth import authenticate_user, decode_basic_header
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Authorization header required")
    # Session token (Bearer) — look up server-side session
    if auth_header.startswith("Bearer "):
        from main import _get_session
        user = _get_session(auth_header[7:])
        if not user:
            raise HTTPException(status_code=401, detail="Session expired or invalid")
        return user
    # Basic auth fallback
    try:
        username, password = decode_basic_header(auth_header)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    user = authenticate_user(username, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return user


def _is_owner_or_shared_sched(item: dict, user: dict) -> bool:
    if not user or is_admin_like(user):
        return True
    return (
        item.get("created_by") == user.get("username")
        or item.get("is_shared", False)
    )


async def _run_in_executor(fn, *args, **kwargs):
    loop = asyncio.get_running_loop()
    try:
        from core.worker_pool import get_pool
        _exec = get_pool().executor
    except RuntimeError:
        _exec = _sched_executor
    if kwargs:
        return await loop.run_in_executor(_exec, functools.partial(fn, *args, **kwargs))
    return await loop.run_in_executor(_exec, fn, *args)


def _is_external_scheduler() -> bool:
    """True when the scheduler runs in a separate process."""
    try:
        from core.config import scheduler as _sched_cfg
        return _sched_cfg.mode == "external"
    except Exception:
        return False


async def _scheduler_proxy(method: str, path: str, json_body=None, timeout: float = 10.0):
    """Forward a request to the scheduler worker's internal HTTP API."""
    import httpx
    from core.config import scheduler as _sched_cfg
    url = f"{_sched_cfg.worker_url}{path}"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.request(method, url, json=json_body, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
    except httpx.ConnectError:
        raise HTTPException(503, "Scheduler worker is not running or unreachable") from None
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, exc.response.text)
    except Exception as exc:
        raise HTTPException(503, f"Scheduler worker communication failed: {exc}")


# ── Pydantic models ───────────────────────────────────────────────────────────

class TriggerConfig(BaseModel):
    type: str                        # "cron" | "interval"
    cron_expr: Optional[str] = None  # for type="cron": "0 8 * * 1-5"
    minutes: Optional[int]   = None  # for type="interval"
    hours:   Optional[int]   = None
    seconds: Optional[int]   = None


class CreateScheduleRequest(BaseModel):
    name:                    str
    description:             Optional[str] = None
    source_type:             str             # saved_query | sql_query | report
    source_id:               int
    param_values:            Optional[Dict[str, Any]] = None
    trigger_config:          TriggerConfig
    output_filename_template: Optional[str] = None
    created_by:              Optional[str] = None
    notify_emails:           Optional[str] = None   # comma-separated email addresses
    notify_webhook:          Optional[str] = None   # Slack/Teams/generic webhook URL
    # 2026-08-23 (Phase 4): the UI has ALWAYS sent this switch and the DB
    # column + delivery_engine gate have existed since Phase 60 — but the
    # field was missing here, so Pydantic silently dropped it and
    # evaluate_alerts_for_schedule() was permanently dead for every
    # UI-created schedule.  The toggle did nothing.
    auto_evaluate_alerts:    Optional[bool] = None


class UpdateScheduleRequest(BaseModel):
    name:                    Optional[str] = None
    description:             Optional[str] = None
    source_type:             Optional[str] = None
    source_id:               Optional[int] = None
    param_values:            Optional[Dict[str, Any]] = None
    trigger_config:          Optional[TriggerConfig] = None
    output_filename_template: Optional[str] = None
    is_active:               Optional[bool] = None
    notify_emails:           Optional[str] = None   # comma-separated email addresses
    notify_webhook:          Optional[str] = None   # Slack/Teams/generic webhook URL
    auto_evaluate_alerts:    Optional[bool] = None  # see CreateScheduleRequest note


# ── Helper: validate trigger config ──────────────────────────────────────────

def _validate_trigger(tc: TriggerConfig):
    if tc.type == "cron":
        if not tc.cron_expr:
            raise HTTPException(400, "cron_expr is required for type='cron'")
        # Validate the cron expression is parsable -- through the SAME
        # constructor registration uses (core/cron_compat.py normalises
        # standard-crontab weekday numerals; see its module docstring).
        try:
            from core.cron_compat import crontab_trigger
            crontab_trigger(tc.cron_expr, timezone="UTC")
        except Exception as e:
            raise HTTPException(400, f"Invalid cron expression '{tc.cron_expr}': {e}")
    elif tc.type == "interval":
        if not any([tc.minutes, tc.hours, tc.seconds]):
            raise HTTPException(400, "Specify at least one of: minutes, hours, seconds for type='interval'")
        # 2026-08-23 (Phase 4): a NEGATIVE interval passed `any(...)` and
        # reached IntervalTrigger unvalidated — a misfire storm, not a
        # schedule.  Validate sign and net duration here, loudly.
        parts = [v for v in (tc.hours, tc.minutes, tc.seconds) if v is not None]
        if any(v < 0 for v in parts) or sum(parts) <= 0:
            raise HTTPException(
                400, "Interval values must be non-negative and add up to a "
                     "positive duration")
    else:
        raise HTTPException(400, f"Unknown trigger type '{tc.type}'. Use 'cron' or 'interval'.")


def _validate_source(source_type: str, source_id: int):
    if source_type == "saved_query":
        if not _db_manager.get_query(source_id):
            raise HTTPException(404, f"Saved query {source_id} not found")
    elif source_type == "sql_query":
        if not _db_manager.get_sql_query(source_id):
            raise HTTPException(404, f"SQL query {source_id} not found")
    elif source_type == "business_report":
        # The dispatcher (core.scheduler._exec_business_report) has run this
        # family since Phase 111; the validator never admitted it.  FB-60
        # (2026-09-26) makes it the family that replaces 'report'.
        if not _db_manager.get_business_report(source_id):
            raise HTTPException(404, f"Finance report {source_id} not found")
    elif source_type == "report":
        from core.reports.legacy_parametric import refusal
        raise HTTPException(400, refusal(
            "schedule source_type 'report'",
            instead="Use source_type='business_report'."))
    else:
        raise HTTPException(400, f"Unknown source_type '{source_type}'. Use: saved_query, sql_query, business_report")


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/api/schedules/scheduler-status")
async def get_scheduler_status(request: Request, _access: dict = Depends(require_capability("schedules.view"))):
    """APScheduler health: running state, active jobs, next fire times.

    SECURITY 2026-08-17: took no ``request`` and was anonymous -- it discloses
    the active job list and next fire times of every schedule in the system.
    """
    _get_current_user_sched(request)
    if _is_external_scheduler():
        return await _scheduler_proxy("GET", "/control/status")
    from core.scheduler import get_scheduler_status as _get_status
    return await _run_in_executor(_get_status)


@router.get("/api/schedules")
async def list_schedules(
    request: Request,
    active_only: bool = False,
    limit: int = QParam(200, ge=1, le=1000),
    offset: int = QParam(0, ge=0), _access: dict = Depends(require_capability("schedules.view")),
):
    if active_only:
        items = await _run_in_executor(_db_manager.list_schedules, True, limit, offset)
    else:
        items = await _run_in_executor(_db_manager.list_all_schedules, limit, offset)
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_sched(request)
        items = [i for i in items if _is_owner_or_shared_sched(i, user)]
    return items


@router.post("/api/schedules", status_code=201)
async def create_schedule(req: CreateScheduleRequest, request: Request, _access: dict = Depends(require_capability("schedules.author"))):
    user = _get_current_user_sched(request)
    if _auth_cfg and _auth_cfg.type != "none":
        # 2026-10-31 -- tool entitlement: the ONE decision the route's dependency makes
        from api.deps import check_capability
        check_capability(user or {}, "schedules.author")
    # Phase 102-F: enforce per-user schedule quota
    from api.deps import enforce_user_resource_quota
    enforce_user_resource_quota(user, "schedules")
    _validate_trigger(req.trigger_config)
    await _run_in_executor(_validate_source, req.source_type, req.source_id)

    # 2026-08-31 -- ASK BEFORE WRITING.  When this pod owns no scheduler the
    # registration below CANNOT succeed, and it used to fail only after the
    # row was persisted: the caller got a 500, retried, and every retry left
    # another active row behind.  _bootstrap_schedules re-registers every
    # active row when a scheduler eventually starts, so all of those
    # duplicates then fired together.  Refuse up front and persist nothing.
    if not _is_external_scheduler():
        try:
            from core.scheduler import can_register_jobs
            _can_register = can_register_jobs()
        except Exception:
            # Fail OPEN: an unreadable scheduler module must not block
            # schedule creation on a normal single-pod deployment.  The
            # rollback below still covers us if registration then fails.
            _can_register = True
        if not _can_register:
            raise HTTPException(503,
                "This pod does not run the scheduler, so the schedule was "
                "not created. Set scheduler.mode=external so schedules are "
                "registered with the scheduler pod, or send this request to "
                "a pod that runs one.")

    # Create DB record
    record = await _run_in_executor(
        _db_manager.create_schedule,
        name=req.name,
        description=req.description,
        source_type=req.source_type,
        source_id=req.source_id,
        param_values=req.param_values,
        trigger_config=req.trigger_config.dict(exclude_none=True),
        output_filename_template=req.output_filename_template,
        # SECURITY 2026-08-22: owner is the AUTHENTICATED principal only.  The
        # body's req.created_by used to be a fallback -- a client could stamp
        # another user's name as the schedule owner (and every ownership gate
        # below reads created_by).  Ignored now; only the dev guest remains.
        created_by=(user or {}).get("username") or "guest",
        notify_emails=req.notify_emails,
        notify_webhook=req.notify_webhook,
        auto_evaluate_alerts=bool(req.auto_evaluate_alerts),
    )

    # Register with APScheduler
    try:
        if _is_external_scheduler():
            result = await _scheduler_proxy("POST", "/control/add-job", json_body={
                "schedule_id": record["id"],
                "trigger_config": req.trigger_config.dict(exclude_none=True),
                "name": req.name,
            })
            job_id = result.get("job_id")
        else:
            from core.scheduler import add_schedule
            job_id = await _run_in_executor(add_schedule, record)
        record = await _run_in_executor(
            _db_manager.update_schedule, record["id"], apscheduler_job_id=job_id
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to register schedule %s with APScheduler: %s", record["id"], e)
        # A failed POST must leave nothing behind.  Without this the row
        # stayed ACTIVE with no job: invisible until a scheduler started,
        # at which point _bootstrap_schedules registered it -- along with
        # every duplicate the caller created by retrying.
        try:
            await _run_in_executor(_db_manager.delete_schedule, record["id"])
        except Exception as _rb:
            logger.error(
                "Schedule %s could NOT be rolled back after a failed "
                "registration: it stays in the table with no job and WILL "
                "be registered by _bootstrap_schedules when a scheduler "
                "starts: %s", record["id"], _rb)
            raise HTTPException(500, f"Schedule saved but APScheduler registration failed: {e}")
        raise HTTPException(503, f"Schedule not created: APScheduler registration failed: {e}")

    return record


@router.get("/api/schedules/{schedule_id}")
async def get_schedule(schedule_id: int, request: Request, _access: dict = Depends(require_capability("schedules.view"))):
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    # RLS: non-admins can only see own or shared schedules
    if _auth_cfg and _auth_cfg.type != "none":
        user = _get_current_user_sched(request)
        if not _is_owner_or_shared_sched(s, user):
            raise HTTPException(404, f"Schedule {schedule_id} not found")
    return s


def _require_schedule_owner(user: dict, schedule: dict):
    """Raise 403 if the user is not the owner or admin."""
    if _auth_cfg and _auth_cfg.type != "none" and not is_admin_like(user):
        if schedule.get("created_by") != (user or {}).get("username"):
            raise HTTPException(403, "Permission denied")


@router.put("/api/schedules/{schedule_id}")
async def update_schedule(schedule_id: int, req: UpdateScheduleRequest, request: Request, _access: dict = Depends(require_capability("schedules.author"))):
    user = _get_current_user_sched(request)
    if _auth_cfg and _auth_cfg.type != "none":
        # 2026-10-31 -- tool entitlement: the ONE decision the route's dependency makes
        from api.deps import check_capability
        check_capability(user or {}, "schedules.author")
    existing = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not existing:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, existing)

    updates: Dict[str, Any] = {}
    if req.name           is not None:
        updates["name"]           = req.name
    if req.description    is not None:
        updates["description"]    = req.description
    if req.source_type    is not None:
        updates["source_type"]    = req.source_type
    if req.source_id      is not None:
        updates["source_id"]      = req.source_id
    if req.param_values   is not None:
        updates["param_values"]   = req.param_values
    if req.is_active      is not None:
        # 2026-10-30: the API's is_active means RUNNING (not paused) -- the enabled column
        updates["enabled"]        = req.is_active
    if req.output_filename_template is not None:
        updates["output_filename_template"] = req.output_filename_template
    if req.notify_emails    is not None:
        updates["notify_emails"]  = req.notify_emails
    if req.notify_webhook   is not None:
        updates["notify_webhook"] = req.notify_webhook
    if req.auto_evaluate_alerts is not None:
        updates["auto_evaluate_alerts"] = bool(req.auto_evaluate_alerts)
    if req.trigger_config is not None:
        _validate_trigger(req.trigger_config)
        updates["trigger_config"] = req.trigger_config.dict(exclude_none=True)

    # 2026-08-23 (Phase 4): validate the EFFECTIVE (merged) source pair.
    # The old `if req.source_type and req.source_id` only validated when
    # BOTH fields were in the request — updating source_id alone was
    # accepted unvalidated, and the schedule then failed on every fire.
    if req.source_type is not None or req.source_id is not None:
        eff_type = req.source_type if req.source_type is not None else existing.get("source_type")
        eff_id   = req.source_id   if req.source_id   is not None else existing.get("source_id")
        await _run_in_executor(_validate_source, eff_type, eff_id)

    record = await _run_in_executor(_db_manager.update_schedule, schedule_id, **updates)

    # Re-register with APScheduler if trigger or active state changed
    if "trigger_config" in updates or "enabled" in updates:
        try:
            if _is_external_scheduler():
                if existing.get("apscheduler_job_id"):
                    await _scheduler_proxy("POST", f"/control/remove-job/{existing['apscheduler_job_id']}")
                if record.get("enabled") is not False:      # running (not paused)
                    result = await _scheduler_proxy("POST", "/control/add-job", json_body={
                        "schedule_id": schedule_id,
                        "trigger_config": record.get("trigger_config", {}),
                        "name": record.get("name", ""),
                    })
                    job_id = result.get("job_id")
                    record = await _run_in_executor(
                        _db_manager.update_schedule, schedule_id, apscheduler_job_id=job_id
                    )
                else:
                    await _run_in_executor(
                        _db_manager.update_schedule, schedule_id, apscheduler_job_id=None
                    )
            else:
                from core.scheduler import add_schedule, remove_schedule
                if existing.get("apscheduler_job_id"):
                    await _run_in_executor(remove_schedule, existing["apscheduler_job_id"])
                if record.get("enabled") is not False:      # running (not paused)
                    job_id = await _run_in_executor(add_schedule, record)
                    record = await _run_in_executor(
                        _db_manager.update_schedule, schedule_id, apscheduler_job_id=job_id
                    )
                else:
                    await _run_in_executor(
                        _db_manager.update_schedule, schedule_id, apscheduler_job_id=None
                    )
        except HTTPException:
            raise
        except Exception as e:
            # 2026-08-23 (Phase 4): this used to LOG and return 200 — the
            # DB then held the new trigger while APScheduler kept firing
            # the OLD one (or none, when is_active was being flipped on).
            # A 200 that leaves the schedule not doing what the response
            # says is the defect class this phase exists to close.  Same
            # contract as create: surface it.
            logger.error("APScheduler update failed for schedule %s: %s", schedule_id, e)
            raise HTTPException(
                500,
                f"Schedule saved but APScheduler re-registration failed: {e}. "
                f"The stored trigger will take effect after the scheduler "
                f"restarts or the schedule is re-saved.")

    return record


@router.delete("/api/schedules/{schedule_id}")
async def delete_schedule(schedule_id: int, request: Request, _access: dict = Depends(require_capability("schedules.author"))):
    user = _get_current_user_sched(request)
    if _auth_cfg and _auth_cfg.type != "none":
        # 2026-10-31 -- tool entitlement: the ONE decision the route's dependency makes
        from api.deps import check_capability
        check_capability(user or {}, "schedules.author")
    existing = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not existing:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, existing)

    # Remove from APScheduler first
    if existing.get("apscheduler_job_id"):
        try:
            if _is_external_scheduler():
                await _scheduler_proxy("POST", f"/control/remove-job/{existing['apscheduler_job_id']}")
            else:
                from core.scheduler import remove_schedule
                await _run_in_executor(remove_schedule, existing["apscheduler_job_id"])
        except Exception as e:
            logger.warning("APScheduler remove failed for schedule %s: %s", schedule_id, e)

    success = await _run_in_executor(_db_manager.delete_schedule, schedule_id)
    if not success:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    audit_event(_db_manager, user, request, "delete_schedule", "schedule", schedule_id)
    from core.config_active import switched_off_message
    return {"message": "Deleted", "schedule_id": schedule_id,
            "detail": switched_off_message("schedule")}


@router.post("/api/schedules/{schedule_id}/pause")
async def pause_schedule(schedule_id: int, request: Request, _access: dict = Depends(require_capability("schedules.operate"))):
    user = _get_current_user_sched(request)
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, s)
    if not s.get("apscheduler_job_id"):
        raise HTTPException(400, "Schedule is not registered with APScheduler")
    try:
        if _is_external_scheduler():
            await _scheduler_proxy("POST", f"/control/pause-job/{s['apscheduler_job_id']}")
        else:
            from core.scheduler import pause_schedule as _pause
            await _run_in_executor(_pause, s["apscheduler_job_id"])
        await _run_in_executor(_db_manager.update_schedule, schedule_id, enabled=False)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Pause failed: {e}")
    return {"message": "Paused", "schedule_id": schedule_id}


@router.post("/api/schedules/{schedule_id}/resume")
async def resume_schedule(schedule_id: int, request: Request, _access: dict = Depends(require_capability("schedules.operate"))):
    user = _get_current_user_sched(request)
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, s)
    if not s.get("apscheduler_job_id"):
        raise HTTPException(400, "Schedule is not registered with APScheduler")
    try:
        if _is_external_scheduler():
            result = await _scheduler_proxy("POST", f"/control/resume-job/{s['apscheduler_job_id']}")
            next_run = result.get("next_run")
        else:
            from core.scheduler import resume_schedule as _resume
            next_run = await _run_in_executor(_resume, s["apscheduler_job_id"])
        await _run_in_executor(
            _db_manager.update_schedule, schedule_id, enabled=True, next_run_at=next_run
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Resume failed: {e}")
    return {"message": "Resumed", "schedule_id": schedule_id}


@router.post("/api/schedules/{schedule_id}/run-now")
async def run_schedule_now(schedule_id: int, request: Request, _access: dict = Depends(require_capability("schedules.operate"))):
    """Trigger an immediate out-of-schedule run. Does not affect the regular trigger."""
    user = _get_current_user_sched(request)
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    _require_schedule_owner(user, s)
    try:
        if _is_external_scheduler():
            await _scheduler_proxy("POST", f"/control/run-now/{schedule_id}")
        else:
            from core.scheduler import run_now
            await _run_in_executor(run_now, schedule_id)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Immediate run failed: {e}")
    return {"message": "Triggered", "schedule_id": schedule_id}


# -- Schedule run stats (Phase 38 anomaly detection) ---------------------------

@router.get("/api/schedules/{schedule_id}/run-stats")
async def get_schedule_run_stats(schedule_id: int, request: Request, limit: int = 20, _access: dict = Depends(require_capability("schedules.view"))):
    """Get historical run statistics for a schedule (for anomaly detection charts)."""
    user = _get_current_user_sched(request)
    s = await _run_in_executor(_db_manager.get_schedule, schedule_id)
    if not s:
        raise HTTPException(404, f"Schedule {schedule_id} not found")
    # SECURITY 2026-08-17: `user` was resolved here and then never used.  Every
    # sibling route in this file calls _require_schedule_owner; this one did
    # not, so any authenticated user could read any schedule's run history.
    _require_schedule_owner(user, s)
    stats = await _run_in_executor(_db_manager.get_schedule_run_stats, schedule_id, limit)
    return {"run_stats": stats}


# -- Switch on (2026-10-30: config rows are switched off, never erased) --------

def _on_schedule_switched_on(row: Dict[str, Any], user: dict) -> Optional[str]:
    """Delete removed the APScheduler job; switching the schedule on puts it
    back (a PAUSED schedule listed under Switched off comes back running too:
    its old job is replaced by a fresh one, then paused again when it was paused)."""
    from core.database import get_db_manager
    db = get_db_manager()
    sid = row["id"]
    old_job = row.get("apscheduler_job_id")
    if _is_external_scheduler():
        import httpx
        from core.config import scheduler as _sched_cfg
        base = _sched_cfg.worker_url
        with httpx.Client(timeout=10.0) as client:
            if old_job:
                client.post(f"{base}/control/remove-job/{old_job}")
            resp = client.post(f"{base}/control/add-job", json={
                "schedule_id": sid, "trigger_config": row.get("trigger_config") or {},
                "name": row.get("name", "")})
            resp.raise_for_status()
            job_id = resp.json().get("job_id")
    else:
        from core.scheduler import add_schedule, remove_schedule
        if old_job:
            remove_schedule(old_job)
        job_id = add_schedule(row)
    db.update_schedule(sid, apscheduler_job_id=job_id)
    if row.get("enabled") is False:      # it was PAUSED when deleted: back, still paused
        if _is_external_scheduler():
            with httpx.Client(timeout=10.0) as client:
                client.post(f"{base}/control/pause-job/{job_id}")
        else:
            from core.scheduler import pause_schedule
            pause_schedule(job_id)
        return "It is back, still paused -- resume it on the Schedules page."
    return "Its timetable is running again."


def _register_switch_on() -> None:
    from api.config_active_api import ON_SWITCH_ON
    ON_SWITCH_ON["schedules"] = _on_schedule_switched_on


_register_switch_on()
