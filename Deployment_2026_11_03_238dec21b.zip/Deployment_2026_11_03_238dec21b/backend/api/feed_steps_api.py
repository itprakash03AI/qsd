"""The step model's surface — catalogue, plugins, flows, plan, timeline,
re-run.

Six questions, six routes, and the two that matter most to the operator
are the last two: "which step failed, and why", and "re-run that step".

Authorisation follows this codebase's rule without exception: the
principal is ALWAYS ``Depends(get_current_user)``, never the request
body — a report execute once took its RLS principal from the body, and
two IDORs survived a green suite because 66 test files run with
``auth.type=none``.  Registering a step type or editing a flow is
``require_admin``: a step is CODE reachable from a config row, and the
security boundary is who may point at it.
"""
from __future__ import annotations

import logging
from datetime import date
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin, require_capability

logger = logging.getLogger(__name__)
router = APIRouter(tags=["feed-steps"])

_db_manager: Any = None


def set_feed_steps_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


def _db() -> Any:
    if _db_manager is None:               # pragma: no cover - wiring guard
        raise HTTPException(
            status_code=503,
            detail="feed steps API not wired to a database")
    return _db_manager


def _feed_or_404(db: Any, feed_id: int) -> dict:
    feed = db.get_feed_config(int(feed_id))
    if not feed:
        raise HTTPException(status_code=404,
                            detail=f"feed {feed_id} not found")
    return feed


def _run_or_404(db: Any, run_id: int) -> dict:
    run = db.get_feed_run(int(run_id))
    if not run:
        raise HTTPException(status_code=404,
                            detail=f"feed run {run_id} not found")
    return run


def _can_act(feed: dict, user: dict) -> bool:
    """The SAME resolver feed_api and feed_ops use — owner / read-write
    group member / admin.  Two authz predicates that disagree converge on
    the stricter one; three implementations of the same predicate is how
    they come to disagree."""
    from core.feed.permissions import can_act_on_feed
    return can_act_on_feed(feed, user, _db_manager)


# ── 1. the catalogue ───────────────────────────────────────────────────


@router.get("/api/feeds/step-types")
async def list_step_types(user: dict = Depends(require_capability("feeds.view"))):
    """Every registered step, with its parameter schema.

    ``config_schema`` is what a UI renders, which is why a step
    registered from the DATABASE alone gets a working form with no
    frontend deploy.

    ``refused`` is NOT an empty list dressed up: a step whose module
    failed to import appears here BY NAME with the reason, because "we
    have no such step" and "that step is broken" lead to opposite
    investigations.
    """
    from core.feed.step_model.registry import get_registry
    reg = get_registry()
    return {
        "step_types": reg.manifests(),
        "refused": [{"name": n, "where": f.where, "reason": f.reason}
                    for n, f in sorted(reg.tombstones().items())],
        "boot_report": reg.boot_report(),
    }


class CustomStepBody(BaseModel):
    """Register a step from the database — the plugin path."""
    name: str = Field(..., min_length=1, max_length=80)
    category: str = Field("quality", max_length=40)
    description: Optional[str] = None
    step_module: str = Field(..., min_length=1, max_length=255)
    step_class: str = Field(..., min_length=1, max_length=120)
    config_schema: Optional[Dict[str, Any]] = None
    requires: Optional[List[str]] = None
    produces: Optional[List[str]] = None
    applies_when: Optional[Dict[str, Any]] = None
    after: Optional[List[str]] = None
    idempotency: Optional[str] = None
    #: Tri-state, and the API keeps it that way.  Omitting it means
    #: UNDECLARED, which means NOT re-runnable — never a default True.
    rerunnable: Optional[bool] = None
    max_attempts: Optional[int] = None


@router.post("/api/feeds/step-types/custom", status_code=201)
async def register_custom_step(body: CustomStepBody,
                               user: dict = Depends(require_capability("feeds.manage"))):
    """Install a step by pointing at an importable class.

    Refuses AT THE POST, not silently at the next boot:

    * a name that would shadow a shipped step;
    * a module/class that cannot be imported, or is not a
      ``FeedPipelineStep``;
    * an ``applies_when`` predicate naming a fact that does not exist —
      a predicate on a nonexistent fact can never hold, so the step
      would register cleanly and never run.
    """
    from core.db.models import FeedCustomStepType
    from core.feed.step_model.registry import get_registry

    db = _db()
    reg = get_registry()
    name = body.name.strip().lower()
    if reg.has(name):
        raise HTTPException(
            status_code=409,
            detail=(f"'{name}' is already a registered step.  A database "
                    f"row cannot take a shipped step away; choose "
                    f"another name."))
    row = FeedCustomStepType(
        name=name, category=body.category, description=body.description,
        step_module=body.step_module, step_class=body.step_class,
        config_schema=body.config_schema, requires=body.requires,
        produces=body.produces, applies_when=body.applies_when,
        after=body.after, idempotency=body.idempotency,
        rerunnable=body.rerunnable, max_attempts=body.max_attempts,
        is_active=True, created_by=(user or {}).get("username"),
    )
    # Try the load BEFORE storing.  A row that cannot produce a step is
    # a row that refuses every flow mapping it at 03:00 instead of
    # refusing the admin at the keyboard.  2026-10-30: decided on the row's
    # declarations WITHOUT writing it (registry.check_plugin_row) -- the old
    # store-load-erase dance erased a config row, and config rows are only
    # ever switched off (core/config_active.py).
    with db.get_session(read_only=True) as session:
        existing = (session.query(FeedCustomStepType)
                    .filter(FeedCustomStepType.name == name).first())
        if existing is not None:
            if existing.is_active is False:
                from core.config_active import name_held_message
                raise HTTPException(status_code=409,
                                    detail=name_held_message("custom feed step", name))
            raise HTTPException(
                status_code=409,
                detail=f"a custom step named '{name}' already exists")
    probe = {c.name: getattr(row, c.name) for c in FeedCustomStepType.__table__.columns}
    refused = reg.check_plugin_row(probe)
    if refused:
        raise HTTPException(
            status_code=422,
            detail=(f"'{body.step_module}.{body.step_class}' could not be "
                    f"registered as a step: {refused}"))
    with db.get_session() as session:
        session.add(row)
        session.flush()
        created = row.to_dict()
    loaded = reg.load_db_plugins(db)
    if not reg.has(name):
        # the probe passed and the stored row did not load: switch it off
        # (it stays visible under Admin -> Switched off, with the reason here)
        failure = reg.tombstones().get(name)
        from core.config_active import switch_off
        with db.get_session() as session:
            stored = (session.query(FeedCustomStepType)
                      .filter(FeedCustomStepType.name == name).first())
            if stored is not None:
                switch_off(stored)
        reg.forget_tombstone(name)
        raise HTTPException(
            status_code=422,
            detail=(f"'{body.step_module}.{body.step_class}' could not be "
                    f"registered as a step: "
                    f"{failure.reason if failure else 'unknown reason'}.  "
                    f"The row was stored and is now switched off."))
    reg.sync_to_db(db)
    logger.info("[feed-steps] %s registered custom step %s (%d loaded)",
                (user or {}).get("username"), name, loaded)
    return {"step_type": created, "registered": True}


def _custom_step_on_switch_on(row: Dict[str, Any], user: dict) -> Optional[str]:
    """A custom step switched back on (Admin -> Switched off) is a step
    again only once the registry has loaded it -- and says so if it cannot."""
    from core.feed.step_model.registry import get_registry
    db = _db()
    reg = get_registry()
    reg.load_db_plugins(db)
    reg.sync_to_db(db)
    name = row.get("name") or ""
    if reg.has(name):
        return "It can be used in feed flows again."
    failure = reg.tombstones().get(name)
    return f"It could not be loaded as a step: {failure.reason if failure else 'unknown reason'}."


def _register_switch_on_hooks() -> None:
    from api.config_active_api import ON_SWITCH_ON
    ON_SWITCH_ON["feed_custom_step_types"] = _custom_step_on_switch_on


_register_switch_on_hooks()


# ── 2. flows — the MAPPING, which is data ─────────────────────────────


class FlowBody(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)
    description: Optional[str] = None
    is_active: bool = True


class FlowStepBody(BaseModel):
    step_type: str = Field(..., min_length=1, max_length=80)
    alias: Optional[str] = Field(None, max_length=80)
    params: Dict[str, Any] = Field(default_factory=dict)
    seq: int = 100
    max_attempts: Optional[int] = None
    enabled: bool = True


@router.get("/api/feeds/flows")
async def list_flows(user: dict = Depends(require_capability("feeds.view"))):
    from core.db.models import FeedFlow, FeedFlowStep
    db = _db()
    with db.get_session(read_only=True) as session:
        # inactive flows are listed on purpose (the page activates them);
        # a deleted flow is inactive too -- it shows there, "inactive"
        flows = [f.to_dict() for f in
                 session.query(FeedFlow).order_by(FeedFlow.name).all()]
        for flow in flows:
            flow["steps"] = [
                s.to_dict() for s in session.query(FeedFlowStep)
                .filter(FeedFlowStep.flow_id == flow["id"])
                .order_by(FeedFlowStep.seq, FeedFlowStep.alias).all()]
    return {"flows": flows}


@router.post("/api/feeds/flows", status_code=201)
async def create_flow(body: FlowBody, user: dict = Depends(require_capability("feeds.manage"))):
    from core.db.models import FeedFlow
    db = _db()
    with db.get_session() as session:
        same = session.query(FeedFlow).filter(
            FeedFlow.name == body.name.strip()).first()
        if same is not None and same.is_active is False:
            # 2026-10-30 -- a deleted flow is switched off and keeps its name
            from core.config_active import name_held_message
            raise HTTPException(status_code=409,
                                detail=name_held_message("feed flow", same.name))
        if same is not None:
            raise HTTPException(
                status_code=409,
                detail=f"a flow named '{body.name}' already exists")
        row = FeedFlow(name=body.name.strip(), description=body.description,
                       is_active=body.is_active,
                       created_by=(user or {}).get("username"))
        session.add(row)
        session.flush()
        return row.to_dict()


# ── 2a. the flow's LIFECYCLE — edit, usage, delete ────────────────────
#
# A flow that can be created and never changed is a flow an administrator
# has to live with forever.  What makes this three routes rather than one
# is that a flow is REFERENCED: ``feed_configs.flow_id`` points at it, and
# that reference has no foreign key on purpose (see the FeedConfig column
# comment) so that a vanished flow makes a feed REFUSE its plan by name
# rather than silently lose its steps.
#
# The consequence, which drives every decision below: this module must
# resolve "who references this flow" ONCE and let both the usage read and
# the delete gate consume that one answer.  A value computed for a gate
# and then thrown away disagrees with what the system does, and a
# decision made twice is a bug.


def _flow_feed_usage(db: Any, flow_id: int) -> Dict[str, Any]:
    """Which feeds reference this flow.

    UNKNOWN IS NOT NONE.  If the reference cannot be read this returns
    ``known=False`` WITH the reason and ``feeds=None`` — never ``[]``.
    An empty list here means "nothing references it, and we checked",
    which is the answer the delete gate is allowed to act on; a failure
    that rendered as ``[]`` would let a delete proceed on a flow half the
    estate is mapped to.
    """
    from core.db.models import FeedConfig
    try:
        with db.get_session(read_only=True) as session:
            rows = (session.query(FeedConfig)
                    .filter(FeedConfig.flow_id == int(flow_id))
                    .order_by(FeedConfig.name).all())
            feeds = [{"id": r.id, "name": r.name,
                      "is_active": bool(r.is_active),
                      "created_by": r.created_by,
                      "owner_group_id": r.owner_group_id} for r in rows]
        return {"known": True, "reason": None, "feeds": feeds,
                "count": len(feeds)}
    except Exception as exc:                       # noqa: BLE001
        logger.warning("[feed-steps] could not resolve usage of flow %s: %s",
                       flow_id, exc)
        return {
            "known": False,
            "reason": (f"which feeds reference flow {flow_id} could not be "
                       f"determined ({type(exc).__name__}: {exc}).  That is "
                       f"not the same as no feed referencing it, and no "
                       f"decision is taken on it"),
            "feeds": None,
            "count": None,
        }


#: The historical record does NOT point back at a flow, and that is a
#: fact about the schema rather than a gap this route papers over.
#: ``feed_run_steps`` copies the alias, the step type, the RESOLVED
#: parameters and the outputs onto each attempt row, precisely so a
#: recorded run stays readable on its own.  So:
#:
#:   * "which runs used this flow" is NOT COMPUTABLE — reported as
#:     unknown WITH this reason, never as a count of zero;
#:   * and a deleted flow leaves no historical read broken, which is why
#:     history is not what blocks the delete below.  The LIVE reference
#:     is.
_RUNS_NOT_ATTRIBUTABLE = (
    "feed_run_steps records each attempt's alias, step type, resolved "
    "parameters and outputs on the row itself, and does not record WHICH "
    "flow mapped the step.  Runs therefore cannot be attributed to a "
    "flow — this is unknown, not zero.  The same property means recorded "
    "runs stay fully readable after this flow is deleted.")


def _delete_verdict(flow_id: int, flow_name: str,
                    usage: Dict[str, Any]) -> Dict[str, Any]:
    """May this flow be deleted, and if not, WHAT is blocking it.

    Resolved ONCE, here, and consumed by both ``GET .../usage`` (which
    reports it) and ``DELETE`` (which enforces it).  The usage screen's
    disabled button therefore carries the system's own reason instead of
    one the UI inferred.

    The decision, and why it is a REFUSAL rather than a cascade:

    * **Refuse while any feed references it.**  The two cascades on offer
      are both worse.  Leaving ``feed_configs.flow_id`` dangling makes
      every mapped feed refuse its next run — a deletion here would break
      feeds elsewhere.  NULLing it is worse, and silent: the feed keeps
      running, but from tomorrow it runs the engine spine ALONE, with
      every mapped quality gate and extra step gone.  A feed that loses
      its row-count floor and still reports SUCCESS is exactly the
      failure this codebase keeps finding, and it must never be a side
      effect of an admin tidying up a flow list.
    * **Then it is switched OFF (owner, 2026-10-30).**  A delete no longer
      erases: the flow and its OWN steps stay, ``is_active`` false
      (core/config_active.py), so Admin -> Switched off brings the whole
      flow back.  Because the refusal above means no feed maps a flow
      being deleted, switching it off has none of deactivation's remote
      effect (``resolve_flow_steps`` refusing a mapped feed's run).
    * **Unknown blocks it.**  If usage cannot be read, nothing is deleted.
    """
    if not usage["known"]:
        return {"allowed": False, "status": 503,
                "error_code": "flow_usage_unknown",
                "reason": (f"refusing to delete flow {flow_id} "
                           f"('{flow_name}'): {usage['reason']}.  Retry once "
                           f"the feed configuration is readable.")}
    feeds = usage["feeds"] or []
    if feeds:
        named = ", ".join(f"{f['name']} (#{f['id']})" for f in feeds[:10])
        more = "" if len(feeds) <= 10 else f", and {len(feeds) - 10} more"
        return {"allowed": False, "status": 409,
                "error_code": "flow_referenced_by_feeds",
                "reason": (
                    f"flow {flow_id} ('{flow_name}') cannot be deleted: "
                    f"{len(feeds)} feed(s) are mapped to it — {named}{more}. "
                    f"Deleting it would either leave those feeds refusing "
                    f"every run, or drop them to the engine spine alone with "
                    f"their mapped steps silently gone.  To proceed, unmap "
                    f"each feed first (PUT /api/feeds/<feed_id>/flow with "
                    f"flow_id: null — a deliberate change to THAT feed's "
                    f"behaviour), or deactivate this flow instead of "
                    f"deleting it.")}
    return {"allowed": True, "status": 200, "error_code": None,
            "reason": "no feed references this flow"}


class FlowUpdateBody(BaseModel):
    """What may change on a flow.

    MUTABLE: ``name``, ``description``, ``is_active``.

    ``name`` is safe to change because nothing references a flow BY NAME:
    ``feed_configs.flow_id`` holds the id, and ``feed_run_steps`` carries
    the alias and the step type, never the flow's name.  A rename
    therefore leaves every in-flight run and every historical record
    exactly as readable as it was.

    IMMUTABLE, and absent from this body by construction: ``id`` (the
    reference every mapped feed holds), ``created_by`` and ``created_at``
    (an audit trail is not editable), and the flow's STEPS — those have
    their own two routes, which validate each mapping where the author
    can fix it.  A bulk step replacement through this body would bypass
    that validation and could swap a running flow's contents in one
    write.

    Every field defaults to ``None`` and is applied only when it was
    actually SENT (``model_fields_set``), so clearing a description is a
    distinct act from not mentioning it.
    """
    name: Optional[str] = Field(None, min_length=1, max_length=120)
    description: Optional[str] = None
    is_active: Optional[bool] = None
    #: Deactivating a flow that feeds are mapped to makes every one of
    #: those feeds REFUSE its next run.  That is a large, remote effect,
    #: so it is refused until the caller has been shown the feeds and
    #: says so.  It is not a default and it is never inferred.
    acknowledge_affected_feeds: bool = False


@router.put("/api/feeds/flows/{flow_id}")
async def update_flow(flow_id: int, body: FlowUpdateBody,
                      user: dict = Depends(require_capability("feeds.manage"))):
    """Rename, re-describe, activate or deactivate a flow.

    The one edit here that is not cosmetic is DEACTIVATION.
    ``store.resolve_flow_steps`` raises on an inactive flow, so the plan
    of every mapped feed becomes fatal: deactivating is not "this flow
    stops being offered to new feeds", it is "every feed already using it
    stops running".  Activating is always allowed — it only removes a
    refusal.
    """
    from core.db.models import FeedFlow
    db = _db()
    fields = body.model_fields_set

    with db.get_session(read_only=True) as session:
        flow = session.get(FeedFlow, int(flow_id))
        if flow is None:
            raise HTTPException(status_code=404,
                                detail=f"flow {flow_id} not found")
        current = flow.to_dict()

    changing = [f for f in ("name", "description", "is_active")
                if f in fields]
    if not changing:
        raise HTTPException(
            status_code=422,
            detail=("nothing to change: send at least one of name, "
                    "description or is_active.  A flow's steps are edited "
                    "through its own /steps routes, and its id, creator and "
                    "creation time are not editable."))

    deactivating = ("is_active" in fields and body.is_active is False
                    and bool(current["is_active"]))
    usage: Optional[Dict[str, Any]] = None
    if deactivating:
        usage = _flow_feed_usage(db, flow_id)
        if not usage["known"]:
            raise HTTPException(
                status_code=503,
                detail={
                    "error_code": "flow_usage_unknown",
                    "message": (
                        f"refusing to deactivate flow {flow_id} "
                        f"('{current['name']}'): {usage['reason']}.  "
                        f"Deactivating makes every mapped feed refuse its "
                        f"next run, and we cannot say which feeds those "
                        f"are."),
                })
        feeds = usage["feeds"] or []
        if feeds and not body.acknowledge_affected_feeds:
            named = ", ".join(f"{f['name']} (#{f['id']})" for f in feeds[:10])
            more = "" if len(feeds) <= 10 else f", and {len(feeds) - 10} more"
            raise HTTPException(
                status_code=409,
                detail={
                    "error_code": "flow_deactivation_affects_feeds",
                    "message": (
                        f"deactivating flow {flow_id} ('{current['name']}') "
                        f"would make {len(feeds)} feed(s) REFUSE every run "
                        f"— {named}{more}.  An inactive flow is not merely "
                        f"hidden: its mapped feeds cannot plan at all.  To "
                        f"proceed, re-send with acknowledge_affected_feeds: "
                        f"true, or unmap those feeds first."),
                    "feeds": feeds,
                })

    with db.get_session() as session:
        flow = session.get(FeedFlow, int(flow_id))
        if flow is None:                            # deleted under us
            raise HTTPException(status_code=404,
                                detail=f"flow {flow_id} not found")
        if "name" in fields:
            new_name = (body.name or "").strip()
            if not new_name:
                raise HTTPException(status_code=422,
                                    detail="a flow's name cannot be blank")
            clash = (session.query(FeedFlow)
                     .filter(FeedFlow.name == new_name,
                             FeedFlow.id != int(flow_id)).first())
            if clash is not None and clash.is_active is False:
                from core.config_active import name_held_message
                raise HTTPException(status_code=409,
                                    detail=name_held_message("feed flow", clash.name))
            if clash is not None:
                raise HTTPException(
                    status_code=409,
                    detail=(f"a different flow (#{clash.id}) is already "
                            f"named '{new_name}'"))
            flow.name = new_name
        if "description" in fields:
            flow.description = body.description
        if "is_active" in fields:
            flow.is_active = bool(body.is_active)
        session.flush()
        updated = flow.to_dict()

    logger.info("[feed-steps] %s updated flow %s (%s); affected feeds: %s",
                (user or {}).get("username"), flow_id, ", ".join(changing),
                (usage or {}).get("count") if deactivating else "n/a")
    return {"flow": updated, "changed": changing,
            "affected_feeds": (usage or {}).get("feeds")}


@router.get("/api/feeds/flows/{flow_id}/usage")
async def get_flow_usage(flow_id: int,
                         user: dict = Depends(require_capability("feeds.view"))):
    """Who references this flow — the read that makes a delete not blind.

    Three separate answers, kept separate on purpose:

    * ``feeds`` — the LIVE reference, and the thing that blocks a delete.
      ``feeds_known: false`` means we could not read it, and ``feeds`` is
      then ``null``, never ``[]``.
    * ``historical_runs`` — reported as UNKNOWN with the schema reason,
      because run rows do not record their flow.  Zero would be a lie.
    * ``delete_verdict`` — the SAME verdict ``DELETE`` enforces, from the
      same function, so a disabled button and the server agree.
    """
    from core.db.models import FeedFlow, FeedFlowStep
    db = _db()
    with db.get_session(read_only=True) as session:
        flow = session.get(FeedFlow, int(flow_id))
        if flow is None:
            raise HTTPException(status_code=404,
                                detail=f"flow {flow_id} not found")
        info = flow.to_dict()
        step_count = (session.query(FeedFlowStep)
                      .filter(FeedFlowStep.flow_id == int(flow_id)).count())

    usage = _flow_feed_usage(db, flow_id)
    verdict = _delete_verdict(flow_id, info["name"], usage)
    return {
        "flow_id": int(flow_id),
        "flow_name": info["name"],
        "is_active": info["is_active"],
        "step_count": step_count,
        "feeds_known": usage["known"],
        "feeds_unknown_reason": usage["reason"],
        "feeds": usage["feeds"],
        "feed_count": usage["count"],
        "historical_runs": {"known": False, "count": None,
                            "reason": _RUNS_NOT_ATTRIBUTABLE},
        "delete_verdict": {"allowed": verdict["allowed"],
                           "reason": verdict["reason"]},
    }


@router.delete("/api/feeds/flows/{flow_id}")
async def delete_flow(flow_id: int, user: dict = Depends(require_capability("feeds.manage"))):
    """Delete a flow — REFUSING while anything references it.

    The full reasoning is on ``_delete_verdict``; the short form is that
    both available cascades are worse than a refusal, and one of them
    (NULLing ``feed_configs.flow_id``) is a silent behaviour change that
    would leave a feed running with its quality gates gone.

    The refusal NAMES the feeds and says how to proceed.  There is no
    force flag: "delete it anyway" is spelled by unmapping the feeds,
    which is a decision taken per feed by someone with rights on it.
    """
    from core.db.models import FeedFlow, FeedFlowStep
    db = _db()
    with db.get_session(read_only=True) as session:
        flow = session.get(FeedFlow, int(flow_id))
        if flow is None:
            raise HTTPException(status_code=404,
                                detail=f"flow {flow_id} not found")
        info = flow.to_dict()

    usage = _flow_feed_usage(db, flow_id)
    verdict = _delete_verdict(flow_id, info["name"], usage)
    if not verdict["allowed"]:
        raise HTTPException(
            status_code=verdict["status"],
            detail={"error_code": verdict["error_code"],
                    "message": verdict["reason"],
                    "feeds": usage["feeds"]})

    with db.get_session() as session:
        # Re-read inside the write session: between the verdict above and
        # here a feed could have been mapped.  Cheap, and the alternative
        # is a delete decided on a stale read.
        flow = session.get(FeedFlow, int(flow_id))
        if flow is None:
            raise HTTPException(status_code=404,
                                detail=f"flow {flow_id} not found")
        recheck = _flow_feed_usage(db, flow_id)
        recheck_verdict = _delete_verdict(flow_id, info["name"], recheck)
        if not recheck_verdict["allowed"]:
            raise HTTPException(
                status_code=recheck_verdict["status"],
                detail={"error_code": recheck_verdict["error_code"],
                        "message": recheck_verdict["reason"],
                        "feeds": recheck["feeds"]})
        # 2026-10-30 (owner): SWITCHED OFF, never erased -- the flow's own
        # steps stay with it, so switching it back on brings the whole flow.
        from core.config_active import switch_off
        steps_kept = (session.query(FeedFlowStep)
                      .filter(FeedFlowStep.flow_id == int(flow_id)).count())
        switch_off(flow)

    logger.info("[feed-steps] %s deleted (switched off) flow %s ('%s'); its %d "
                "step(s) kept", (user or {}).get("username"), flow_id,
                info["name"], steps_kept)
    return {"deleted": int(flow_id), "name": info["name"], "switched_off": True,
            "steps_removed": 0, "steps_kept": int(steps_kept)}


@router.post("/api/feeds/flows/{flow_id}/steps", status_code=201)
async def add_flow_step(flow_id: int, body: FlowStepBody,
                        user: dict = Depends(require_capability("feeds.manage"))):
    """Map a step into a flow.

    Validated HERE, where the author can fix it: the step must exist,
    must not be part of the engine's own spine (mapping it would plan it
    twice), and its required parameters must have values.  A flow saved
    with a missing required parameter is a run that refuses at 03:00.
    """
    from core.db.models import FeedFlow, FeedFlowStep
    from core.feed.step_model.registry import (
        FeedStepLoadFailed, UnknownFeedStep, get_registry,
    )

    db = _db()
    reg = get_registry()
    try:
        manifest = reg.manifest(body.step_type)
    except UnknownFeedStep as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except FeedStepLoadFailed as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    if manifest.get("executor") == "engine":
        raise HTTPException(
            status_code=422,
            detail=(f"'{body.step_type}' is part of the engine's own spine "
                    f"— it already runs on every feed, and mapping it "
                    f"would plan it twice."))
    cls = manifest.get("_class")
    problems = list(cls.validate_params(body.params)) if cls else []
    if problems:
        raise HTTPException(status_code=422, detail="; ".join(problems))
    alias = (body.alias or body.step_type).strip().lower()
    with db.get_session() as session:
        flow = session.get(FeedFlow, int(flow_id))
        if flow is None:
            raise HTTPException(status_code=404,
                                detail=f"flow {flow_id} not found")
        if session.query(FeedFlowStep).filter(
                FeedFlowStep.flow_id == int(flow_id),
                FeedFlowStep.alias == alias).first():
            raise HTTPException(
                status_code=409,
                detail=(f"flow {flow_id} already has a step aliased "
                        f"'{alias}'.  The alias is the run row's identity, "
                        f"so two would make one attempt overwrite the "
                        f"other's record."))
        row = FeedFlowStep(
            flow_id=int(flow_id), step_type=body.step_type, alias=alias,
            params=body.params, seq=body.seq,
            max_attempts=body.max_attempts, enabled=body.enabled)
        session.add(row)
        session.flush()
        return row.to_dict()


@router.delete("/api/feeds/flows/{flow_id}/steps/{step_id}")
async def remove_flow_step(flow_id: int, step_id: int,
                           user: dict = Depends(require_capability("feeds.manage"))):
    from core.db.models import FeedFlowStep
    db = _db()
    with db.get_session() as session:
        row = session.get(FeedFlowStep, int(step_id))
        if row is None or int(row.flow_id) != int(flow_id):
            raise HTTPException(
                status_code=404,
                detail=f"flow {flow_id} has no step {step_id}")
        session.delete(row)
    return {"removed": step_id}


class FeedFlowAssignment(BaseModel):
    flow_id: Optional[int] = None


@router.put("/api/feeds/{feed_id}/flow")
async def assign_flow(feed_id: int, body: FeedFlowAssignment,
                      user: dict = Depends(require_capability("feeds.author"))):
    """Map a feed to a flow (``flow_id: null`` unmaps it).

    Refuses a flow that does not exist rather than storing an id that
    resolves to nothing — a feed mapped to a vanished flow refuses every
    run, and the fix is to never let it be stored.
    """
    from core.db.models import FeedFlow
    db = _db()
    feed = _feed_or_404(db, feed_id)
    if not _can_act(feed, user):
        raise HTTPException(
            status_code=403,
            detail=(f"{(user or {}).get('username')} may not change feed "
                    f"{feed_id}; its owner or a read-write member of its "
                    f"owning group can"))
    if body.flow_id is not None:
        with db.get_session(read_only=True) as session:
            flow = session.get(FeedFlow, int(body.flow_id))
            if flow is None:
                raise HTTPException(
                    status_code=404,
                    detail=f"flow {body.flow_id} does not exist")
            if not flow.is_active:
                raise HTTPException(
                    status_code=422,
                    detail=(f"flow {body.flow_id} ('{flow.name}') is "
                            f"inactive; a feed mapped to it would refuse "
                            f"every run"))
    db.update_feed_config(int(feed_id), {"flow_id": body.flow_id})
    return {"feed_id": feed_id, "flow_id": body.flow_id}


# ── 3. the plan — what WILL run, before anything has ──────────────────


@router.get("/api/feeds/{feed_id}/step-plan")
async def get_step_plan(feed_id: int,
                        business_date: Optional[date] = Query(None),
                        user: dict = Depends(require_capability("feeds.view"))):
    """The ordered plan, the skips WITH REASONS, and any refusals.

    Answerable on a feed that has never run — which is what makes "show
    me what will run tonight" a read rather than a feature.
    """
    from core.feed.step_model.service import describe_plan
    db = _db()
    feed = _feed_or_404(db, feed_id)
    run = None
    if business_date is not None:
        run = db.get_feed_run_by_feed_date(int(feed_id), business_date)
    return describe_plan(db, feed, run)


# ── 4. the timeline ── NOT here, deliberately ──────────────────
#
# "What are this run's steps" is answered by
# ``GET /api/feed-runs/{run_id}/steps`` in ``api/feed_ops_api.py``,
# which has served that path since 2026-09-02 and which now reads the
# real ``feed_run_steps`` rows, falling back to the timing projection
# only for runs that predate them.
#
# A second handler on the same path would not be an alternative
# implementation -- FastAPI matches the FIRST registered route, so the
# later one is unreachable.  Unreachable code with passing tests is
# exactly the shape this codebase keeps producing, and this router is
# registered after feed_ops.  One question, one answer, one route.
#
# What lives here is what that route does NOT answer: the full attempt
# history, the re-run, and the resume point.


@router.get("/api/feed-runs/{run_id}/step-attempts")
async def get_run_step_attempts(run_id: int,
                                user: dict = Depends(require_capability("feeds.view"))):
    """EVERY attempt of every step, not just the latest.

    The latest-attempt view is the run screen's answer ("a replay reports
    the LATEST, never the SUM").  This is the incident view: a retried
    step's FIRST attempt -- how far it got, what it wrote, how it failed
    -- is exactly what an investigation needs, and OG lost it by keeping
    a RETRY_COUNT on one row.
    """
    from core.feed.step_model.store import list_run_steps
    db = _db()
    run = _run_or_404(db, run_id)
    rows = list_run_steps(db, run_id)
    return {
        "run_id": run_id,
        "feed_config_id": run.get("feed_config_id"),
        "business_date": run.get("business_date"),
        "run_status": run.get("status"),
        "attempts": rows,
        "total": len(rows),
    }


@router.get("/api/feed-runs/{run_id}/steps/rerun-verdicts")
async def get_rerun_verdicts(run_id: int,
                             user: dict = Depends(require_capability("feeds.view"))):
    """For each step: may it be re-run, and if not, WHY NOT.

    Resolved once and the reason kept, so the UI's disabled button
    carries the system's reason rather than one the UI invented.  A value
    computed for a gate and then thrown away disagrees with what the
    system does.
    """
    from core.feed.step_model.runner import rerun_precheck
    from core.feed.step_model.store import latest_attempts
    db = _db()
    _run_or_404(db, run_id)
    out = []
    for row in latest_attempts(db, run_id):
        try:
            verdict = rerun_precheck(db, run_id, row["alias"])
            out.append({"alias": row["alias"], "status": row["status"],
                        "allowed": bool(verdict["allowed"]),
                        "reason": verdict["reason"]})
        except Exception as exc:                   # noqa: BLE001
            out.append({"alias": row["alias"], "status": row["status"],
                        "allowed": False,
                        "reason": (f"the re-run gate could not be "
                                   f"evaluated: {exc}")})
    return {"run_id": run_id, "verdicts": out}


# ── 5. re-run one step ────────────────────────────────────────────────


@router.post("/api/feed-runs/{run_id}/steps/{alias}/rerun")
async def rerun_step(run_id: int, alias: str,
                     user: dict = Depends(require_capability("feeds.author"))):
    """Re-run one step, appending a new attempt.

    TWO conditions, both required, both re-checked here rather than
    trusted from the UI:

    * every step it depended on is green in its latest attempt;
    * the step DECLARED itself re-runnable.  Undeclared means unsafe —
      OG defaulted retry-safety to true and a non-idempotent step was
      retried into 50 million duplicate rows.

    A refusal is a 409 naming WHICH condition failed.
    """
    from core.feed.step_model.runner import execute_step, rerun_precheck
    from core.feed.step_model.service import plan_for_feed

    db = _db()
    run = _run_or_404(db, run_id)
    feed = _feed_or_404(db, run["feed_config_id"])
    if not _can_act(feed, user):
        raise HTTPException(
            status_code=403,
            detail=(f"{(user or {}).get('username')} may not act on feed "
                    f"{feed.get('id')}; its owner or a read-write member "
                    f"of its owning group can"))
    verdict = rerun_precheck(db, run_id, alias)
    if verdict["step"] is None:
        raise HTTPException(status_code=404, detail=verdict["reason"])
    if not verdict["allowed"]:
        raise HTTPException(status_code=409, detail=verdict["reason"])

    plan = plan_for_feed(db, feed, run)
    step = plan.by_alias(alias)
    if step is None:
        raise HTTPException(
            status_code=409,
            detail=(f"'{alias}' ran on this run but is no longer in the "
                    f"feed's plan — its flow mapping or its scope changed. "
                    f"Refusing rather than re-running a step the feed no "
                    f"longer declares"))
    # Rebuild the artifact map from what the earlier steps recorded.
    from core.feed.step_model.store import latest_attempts
    artifacts: Dict[str, Any] = {}
    for row in latest_attempts(db, run_id):
        for key, value in (row.get("outputs") or {}).items():
            artifacts.setdefault(key, value)
        if row.get("rows_out") is not None:
            artifacts.setdefault("row_count", row["rows_out"])
    missing = [k for k in (step.manifest.get("requires") or [])
               if k not in artifacts]
    if missing:
        raise HTTPException(
            status_code=409,
            detail=(f"cannot re-run '{alias}': its declared input(s) "
                    f"{sorted(missing)} are not available from this run's "
                    f"records.  Re-running it against a guessed input "
                    f"would produce a verdict about something else"))
    attempt = int(verdict["step"].get("attempt") or 1) + 1
    result = await execute_step(
        db, feed_run_id=int(run_id), step=step, feed_config=feed,
        feed_run=run, artifacts=artifacts,
        execution_id=str(run.get("build_id") or ""),
        attempt=attempt,
        triggered_by=(user or {}).get("username"))
    logger.info("[feed-steps] %s re-ran step '%s' on run %s -> %s",
                (user or {}).get("username"), alias, run_id,
                result.get("status"))
    return {"run_id": run_id, "alias": alias, "attempt": attempt,
            "result": result}


# ── 6. resume — the first non-green step ──────────────────────────────


@router.get("/api/feed-runs/{run_id}/steps/resume-point")
async def resume_point(run_id: int, user: dict = Depends(require_capability("feeds.view"))):
    """Where a resume would start.

    Not a feature with its own code path: with per-step state modelled
    properly, "the first non-green step" is a READ over the latest
    attempts in seq order.
    """
    from core.feed.step_model.runner import rerun_precheck
    from core.feed.step_model.store import first_not_green, latest_attempts
    db = _db()
    _run_or_404(db, run_id)
    rows = latest_attempts(db, run_id)
    row = first_not_green(rows)
    if row is None:
        return {"run_id": run_id, "resume_from": None,
                "reason": "every step is green"}
    verdict = rerun_precheck(db, run_id, row["alias"])
    return {"run_id": run_id, "resume_from": row["alias"],
            "step": row, "rerunnable_now": bool(verdict["allowed"]),
            "reason": verdict["reason"]}
