"""The report Diagnostics panel -- the routes (2026-10-30).

Every fact is what the run RECORDED (``core/reports/diagnostics.py``); these
routes resolve the report, the run and the caller, and decide what the
caller may see.

    GET /api/business-reports/{id}/executions/{exec_id}/diagnostics
        The panel: per parameter its value and WHERE it was applied (with the
        exact condition for an editor), per run the engine, the SQL sent
        (editors), time, rows, cache, the scan; the canvas tiles; the action
        runs.  Gate: the report's view rule, the run belongs to the report,
        THE RESULT's gate (the run's executor, the report owner or an admin --
        the rule ``/results/{exec_id}`` and ``/cube`` share), and the panel's
        own rule: the report's owner / editors / admins, or anyone who may view
        it when the owner allowed it (``layout_config.diagnostics_for_viewers``).
    GET /api/business-reports/{id}/executions/{exec_id}/parameters
        The values the run used, in words -- for a canvas BAND tile.  Same
        gate WITHOUT the panel's rule (a band is shown to every viewer).
    PUT /api/business-reports/{id}/diagnostics-access   {"for_viewers": bool}
        The owner (or an editor / admin) lets people who may only view the
        report open its panel, or stops them.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, Optional, Tuple

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from api.deps import require_capability
from core.reports import diagnostics as _diag
from core.roles import ADMIN_TIER_ROLES

logger = logging.getLogger(__name__)
router = APIRouter(tags=["report-diagnostics"])


async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


def _is_admin(user: Optional[Dict[str, Any]]) -> bool:
    return bool((user or {}).get("username")) and (user or {}).get("role") in ADMIN_TIER_ROLES


async def _run_gate(report_id: int, exec_id: str,
                    user: dict) -> Tuple[Any, Dict[str, Any], Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """The report, and the run's two execution rows, after the RESULT's gate."""
    from api import business_reports_api as br
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not await _adb(br._br_can_view, report, user):
        raise HTTPException(status_code=403, detail="Access denied")
    if not await _adb(br._execution_belongs_to_report, db, report_id, exec_id):
        raise HTTPException(status_code=404, detail="Execution not found for this report")
    job = None
    try:
        job = await _adb(db.get_br_async_job, exec_id)
    except Exception:                                        # noqa: BLE001
        logger.debug("async job lookup failed for %s", exec_id, exc_info=True)
    fed = None
    if job and int(job.get("report_id") or -1) == int(report_id):
        await _adb(br._check_async_exec_access, db, job, user)
    else:
        job = None
        fed = await _adb(db.get_federation_execution, exec_id)
        br._require_execution_belongs_to_report(report_id, report, fed or {})
        br._check_result_access(report, fed, user)
    return db, report, fed, job


@router.get("/api/business-reports/{report_id}/executions/{exec_id}/diagnostics")
async def get_run_diagnostics(report_id: int, exec_id: str,
                              user: dict = Depends(require_capability("reports.view"))):
    """How THIS run applied each parameter, which engine read the data, the
    SQL sent, time, rows, cache, the scan, the canvas tiles and the action
    runs -- each part "not recorded" when the run did not record it."""
    from api import business_reports_api as br
    db, report, fed, job = await _run_gate(report_id, exec_id, user)
    can_edit = bool(await _adb(br._br_can_edit, report, user))
    if not _diag.may_open_panel(report, can_edit=can_edit, is_admin=_is_admin(user)):
        raise HTTPException(
            status_code=403,
            detail=("The Diagnostics panel of this report is shown to its owner and editors. "
                    "Ask the owner to let viewers open it."))
    with_sql = can_edit or _is_admin(user)
    record = await _adb(_diag.get_run_record, db, exec_id)
    if record is None:
        out = _diag.unrecorded_answer(exec_id, fed, job, with_sql=with_sql)
    else:
        out = _diag.project_for_caller(record, with_sql=with_sql)
    out["actions"] = await _adb(_diag.action_runs, db, report_id, exec_id)
    out["for_viewers"] = _diag.viewers_may_open(report)
    out["may_change_access"] = bool(can_edit or _is_admin(user))
    return out


@router.get("/api/business-reports/{report_id}/executions/{exec_id}/parameters")
async def get_run_parameter_values(report_id: int, exec_id: str,
                                   user: dict = Depends(require_capability("reports.view"))):
    """The values this run used, in words (a canvas band tile)."""
    db, _report, _fed, _job = await _run_gate(report_id, exec_id, user)
    record = await _adb(_diag.get_run_record, db, exec_id)
    out = _diag.band_parameters(record)
    out["execution_id"] = exec_id
    return out


class DiagnosticsAccess(BaseModel):
    for_viewers: bool


@router.put("/api/business-reports/{report_id}/diagnostics-access")
async def set_diagnostics_access(report_id: int, body: DiagnosticsAccess,
                                 user: dict = Depends(require_capability("reports.edit"))):
    """Let people who may only VIEW this report open its Diagnostics panel
    (``true``) or not (``false``).  The owner, an editor or an admin."""
    from api import business_reports_api as br
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not (await _adb(br._br_can_edit, report, user) or _is_admin(user)):
        raise HTTPException(status_code=403,
                            detail="Only the report's owner, an editor or an admin can change who sees "
                                   "its Diagnostics panel.")
    layout = dict(report.get("layout_config") or {})
    layout[_diag.VIEWERS_SETTING] = bool(body.for_viewers)
    updated = await _adb(db.update_business_report, report_id, layout_config=layout)
    if not updated:
        raise HTTPException(status_code=404, detail="Report not found")
    logger.info("[diagnostics] report %s: viewers %s open the panel (by %s)", report_id,
                "may" if body.for_viewers else "may not", (user or {}).get("username"))
    return {"report_id": report_id, "for_viewers": bool(body.for_viewers)}
