"""The report band's previous / next BUSINESS day (2026-11-01).

``GET /api/business-reports/{id}/business-day?date=2026-10-30&step=1&param=business_date``

The viewer's band draws a business-date parameter as a cell with two arrows:
the business day before / after the value shown.  "Business day" is the
REPORT's calendar, decided by the one rule a period already runs on
(``core.reports.period.calendar_for``): the parameter's own default token's
calendar (``@PREV_BUSINESS_DAY:LDN`` -> LDN), else the report's
``layout_config.calendar``, else the deployment's
``feed_generation.default_calendar``, else Monday to Friday -- and the answer
SAYS which (``calendar_words``), so the arrow's tooltip never guesses.

A walk that cannot decide (a day past the calendar's horizon) is refused in
words (422), never a guessed day.  The report's view rule first.
"""
from __future__ import annotations

import asyncio
from datetime import date, timedelta
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from api.deps import require_capability

router = APIRouter(tags=["business-reports"])

MAX_WALK_DAYS = 40
DATE_KINDS = ("date", "date_range")


class BusinessDayRefused(ValueError):
    """The walk could not decide -- said in words."""


async def _adb(fn, *args, **kwargs):
    return await asyncio.to_thread(fn, *args, **kwargs)


def _require_db():
    from api.deps import require_db
    return require_db()


def step_business_day(cal: Any, start: date, step: int) -> date:
    """The business day ``step`` (+1 / -1) away from ``start`` on ``cal``.

    ``start`` itself need not be a business day: the walk moves first, then
    skips every day the calendar says is not a business day.  A day the
    calendar cannot answer for (past its horizon) refuses."""
    if step not in (1, -1):
        raise BusinessDayRefused("step must be 1 (next business day) or -1 (previous business day)")
    x = start
    for _ in range(MAX_WALK_DAYS):
        x = x + timedelta(days=step)
        try:
            bd = bool(cal.is_business_day(x))
        except Exception as exc:                              # noqa: BLE001  (horizon: unknown)
            raise BusinessDayRefused(
                f"The business calendar cannot say whether {x.isoformat()} is a business day "
                f"({exc}). Pick the date from the list instead.") from exc
        if bd:
            return x
    raise BusinessDayRefused(
        f"No business day within {MAX_WALK_DAYS} days of {start.isoformat()} on this calendar.")


def date_parameter(params: List[Dict[str, Any]], name: Optional[str]) -> Optional[Dict[str, Any]]:
    """The named parameter, else the report's first date parameter."""
    rows = [p for p in params or [] if isinstance(p, dict)]
    if name:
        for p in rows:
            if str(p.get("name")) == name:
                return p
        return None
    for p in rows:
        if p.get("parameter_type") in DATE_KINDS:
            return p
    return None


@router.get("/api/business-reports/{report_id}/business-day")
async def report_business_day(report_id: int,
                              date_: str = Query(..., alias="date", description="the date shown (YYYY-MM-DD)"),
                              step: int = Query(1, description="1 = next business day, -1 = previous"),
                              param: Optional[str] = Query(None, description="the business-date parameter's name"),
                              user: dict = Depends(require_capability("reports.view"))):
    from api import business_reports_api as br
    from core.reports.period import Weekdays, anchor_calendar_name, calendar_for
    db = _require_db()
    report = await _adb(db.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    if not await _adb(br._br_can_view, report, user):
        raise HTTPException(status_code=403, detail="Access denied")
    try:
        start = date.fromisoformat(str(date_).strip()[:10])
    except ValueError:
        raise HTTPException(status_code=422, detail=f"{date_!r} is not a date -- use YYYY-MM-DD.")
    params = await _adb(br._report_parameters_for_execution, report, db, report_id)
    anchor = date_parameter(params, param)
    if param and anchor is None:
        raise HTTPException(status_code=422, detail=f"This report has no parameter named {param!r}.")
    cal, words = await _adb(calendar_for, anchor, report, db)
    try:
        moved = step_business_day(cal, start, step)
    except BusinessDayRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return {"report_id": report_id, "from": start.isoformat(), "step": step,
            "date": moved.isoformat(),
            "calendar": None if isinstance(cal, Weekdays) else anchor_calendar_name(anchor, report),
            "calendar_words": words}
