"""
Arrow IPC response format — 3-5x faster data transfer for large result sets.

Serves execution results as Arrow IPC streams instead of JSON.
Clients that support Apache Arrow can opt into this format for
significantly reduced serialization overhead and network transfer.

Usage:
    GET /api/executions/{id}/results/arrow?page=0&page_size=10000
"""
from __future__ import annotations

import logging
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request, Query, Depends
from api.deps import require_capability
from fastapi.responses import Response

from core.arrow_ipc import table_to_ipc_stream

logger = logging.getLogger(__name__)

router = APIRouter(tags=["arrow"])

_db_manager = None
_auth_cfg = None


def set_arrow_dependencies(db_manager, auth_cfg) -> None:
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg = auth_cfg


def _get_user(request: Request):
    from api.deps import get_current_user
    return get_current_user(request)


@router.get("/api/executions/{execution_id}/results/arrow")
async def get_results_arrow(
    request: Request,
    execution_id: str,
    page: int = Query(default=0, ge=0),
    page_size: int = Query(default=10000, ge=100, le=100000), _access: dict = Depends(require_capability("bqb.view")),
):
    """
    Return execution results as an Arrow IPC stream.

    Much faster than JSON for large datasets:
    - No JSON serialization overhead
    - Columnar format = better compression
    - Direct memory mapping possible on client side
    """
    import asyncio
    user = _get_user(request)  # authenticate

    execution = (await asyncio.to_thread(_db_manager.get_execution, execution_id)) if _db_manager else None
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")

    # Wiz-scan #1 parity (CWE-639/IDOR): this endpoint previously served ANY
    # execution's results to any authenticated user.  Enforce the SAME
    # owner/service/admin gate the sibling result endpoints use.
    from api.data_grid_api import _enforce_execution_ownership as _own
    await asyncio.to_thread(_own, execution_id, user)

    if execution.get("status") != "completed":
        raise HTTPException(status_code=400, detail=f"Execution status is '{execution.get('status')}', not 'completed'")

    output_file = execution.get("output_file")

    def _build_arrow() -> Response:
        # NFS stat + full parquet read + Arrow IPC serialization — ALL off the
        # event loop.  This used to load the ENTIRE result parquet into memory
        # on the loop before slicing one page, freezing health probes for
        # seconds on large results (event_loop_blocking_audit.md P2-H).
        if not output_file or not Path(output_file).exists():
            raise HTTPException(status_code=404, detail="Result file not found")
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError:
            raise HTTPException(status_code=501, detail="PyArrow not available on this server")
        parquet_file = pq.ParquetFile(output_file)
        total_rows = parquet_file.metadata.num_rows
        total_cols = parquet_file.metadata.num_columns
        start_row = page * page_size
        if start_row >= total_rows:
            schema = parquet_file.schema_arrow
            empty_table = pa.table({f.name: pa.array([], type=f.type) for f in schema})
            return Response(
                content=table_to_ipc_stream(empty_table, schema=schema),
                media_type="application/vnd.apache.arrow.stream",
                headers={
                    "X-Total-Rows": str(total_rows),
                    "X-Total-Columns": str(total_cols),
                    "X-Page": str(page),
                    "X-Page-Size": str(page_size),
                },
            )
        table = parquet_file.read()
        sliced = table.slice(start_row, page_size)
        return Response(
            content=table_to_ipc_stream(sliced),
            media_type="application/vnd.apache.arrow.stream",
            headers={
                "X-Total-Rows": str(total_rows),
                "X-Total-Columns": str(total_cols),
                "X-Page": str(page),
                "X-Page-Size": str(page_size),
                "X-Rows-In-Page": str(sliced.num_rows),
            },
        )

    try:
        return await asyncio.to_thread(_build_arrow)
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Arrow IPC serialization failed for %s: %s", execution_id, e)
        raise HTTPException(status_code=500, detail=f"Arrow serialization failed: {e}")
