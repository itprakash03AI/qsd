"""
Dashboard API Router — CRUD for dashboards + widgets.

Endpoints:
  GET    /api/dashboards
  POST   /api/dashboards
  GET    /api/dashboards/{id}
  PUT    /api/dashboards/{id}
  DELETE /api/dashboards/{id}
  GET    /api/dashboards/{id}/widgets
  POST   /api/dashboards/{id}/widgets
  PUT    /api/dashboards/{id}/widgets/{widget_id}
  DELETE /api/dashboards/{id}/widgets/{widget_id}
  PUT    /api/dashboards/{id}/layout   (bulk layout update from react-grid-layout)
  GET    /api/dashboards/{id}/download-excel  (one sheet per widget + Export Info)
  GET    /api/dashboards/{id}/download-csv    (zip bundle: one CSV per widget + manifest)

Filters (2026-09-25): a dashboard declares FILTERS; each binds by NAME to
the parameters a tile's source declares (core/dashboard_params.py).  GET
returns each widget's ``declared_params``; the exports take the viewer's
values as ``?filter_values=<json>`` and apply the same rule.

Export scope (2026-08-30, deliberate):
  * DATA export only.  Each widget's UNDERLYING DATA is exported — Excel gets
    one sheet per widget (named for it, rendered by the same builder the
    business-report exports use, including its 1,048,576-row sheet spill and
    in-file truncation disclosure), plus a final "Export Info" sheet stating
    per widget: sheet name, rows, cap, status and any failure reason.  CSV
    gets a .zip with one CSV per widget plus an export_info.csv manifest.
  * NO PDF — deliberately.  Widgets are rendered CLIENT-SIDE by recharts, so
    the server cannot screenshot a chart; a PDF of empty boxes (or of tables
    silently pretending to be charts) would be a stub that pretends.  The
    honest tabular artifact is the Excel workbook above, which says what it
    is.  Revisit only with a real chart renderer or a client-supplied image.
  * A widget that fails to resolve NEVER silently vanishes: it appears as an
    error sheet/file AND as an Export Info row carrying the (sanitized)
    reason.
"""
from __future__ import annotations

import asyncio
import io
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query, Request, Depends
from api.deps import require_capability
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from core.audit import audit_event
from core.roles import is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter()


# BF-NONBLOCK-AUDIT-5: dashboards page fires list+widget+access calls
# on every nav.  Sync DB inline pinned the loop.  All routes now
# offload via to_thread.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

# Injected from main.py _startup()
_db_manager = None
_get_user   = None   # reference to main.py's _get_current_user


def set_dashboard_dependencies(db_manager, get_current_user_fn) -> None:
    global _db_manager, _get_user
    _db_manager = db_manager
    _get_user   = get_current_user_fn


def _db():
    if _db_manager is None:
        raise RuntimeError("Dashboard dependencies not initialised")
    return _db_manager


def _user(request: Request) -> dict:
    if _get_user is None:
        return {"username": "guest", "is_admin": True}
    return _get_user(request)


# ── Pydantic models ────────────────────────────────────────────────────────────

class CreateDashboardRequest(BaseModel):
    name:        str
    description: Optional[str] = None
    filters:     Optional[List[Dict[str, Any]]] = None


class UpdateDashboardRequest(BaseModel):
    name:        Optional[str] = None
    description: Optional[str] = None
    filters:     Optional[List[Dict[str, Any]]] = None


def _valid_filters(filters):
    """422 naming the problem -- a filter that cannot bind must not be saved."""
    if filters is None:
        return None
    from core.dashboard_params import validate_filters
    try:
        return validate_filters(filters)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


def _with_declared_params(db, widgets: list) -> list:
    """Each widget with the parameters its source declares -- what a
    dashboard filter can bind to (core/dashboard_params.py)."""
    from core.dashboard_params import declared_widget_params
    return [{**w, "declared_params": declared_widget_params(db, w)} for w in widgets or []]


class CreateWidgetRequest(BaseModel):
    widget_type:  str                       # "saved_query" | "sql_query" | "business_report"
    source_id:    int
    title:        Optional[str] = None
    layout:       Optional[Dict[str, Any]] = None   # {x, y, w, h}
    chart_type:   str = "grid"              # "grid"|"bar"|"line"|"area"|"pie"|"scatter"|"metric"
    chart_config: Optional[Dict[str, Any]] = None
    param_values: Optional[Dict[str, Any]] = None


class UpdateWidgetRequest(BaseModel):
    title:        Optional[str] = None
    layout:       Optional[Dict[str, Any]] = None
    chart_type:   Optional[str] = None
    chart_config: Optional[Dict[str, Any]] = None
    param_values: Optional[Dict[str, Any]] = None


class LayoutUpdateRequest(BaseModel):
    layouts: List[Dict[str, Any]]   # [{i: "42", x, y, w, h}, ...]


# ── Dashboard endpoints ────────────────────────────────────────────────────────

@router.get("/api/dashboards")
async def list_dashboards(request: Request, _access: dict = Depends(require_capability("dashboards.view"))):
    from api.deps import get_workspace_id
    user = _user(request)
    db   = _db()
    return await _adb(db.list_dashboards,
        created_by=user.get("username"),
        # SECURITY (2026-07-06): default is_admin to FALSE.  A missing key (e.g.
        # the LDAP auth path) must NOT grant admin -- defaulting True skipped the
        # created_by scoping and showed every dashboard in scope.
        is_admin=bool(user.get("is_admin", False)),
        workspace_id=get_workspace_id(request),
    )


@router.post("/api/dashboards", status_code=201)
async def create_dashboard(body: CreateDashboardRequest, request: Request, _access: dict = Depends(require_capability("dashboards.author"))):
    from api.deps import get_workspace_id
    user = _user(request)
    filters = _valid_filters(body.filters)
    return await _adb(_db().create_dashboard,
        name=body.name,
        description=body.description,
        created_by=user.get("username"),
        workspace_id=get_workspace_id(request),
        filters=filters,
    )


@router.get("/api/dashboards/{dashboard_id}")
async def get_dashboard(dashboard_id: int, request: Request, _access: dict = Depends(require_capability("dashboards.view"))):
    user = _user(request)
    db   = _db()
    d    = await _adb(db.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    widgets = await _adb(db.list_widgets, dashboard_id)
    widgets = await _adb(_with_declared_params, db, widgets)
    return {**d, "widgets": widgets}


@router.put("/api/dashboards/{dashboard_id}")
async def update_dashboard(dashboard_id: int, body: UpdateDashboardRequest, request: Request, _access: dict = Depends(require_capability("dashboards.author"))):
    user = _user(request)
    db   = _db()
    d    = await _adb(db.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if "filters" in updates:
        # [] is a real value (remove every filter), so it is kept
        updates["filters"] = _valid_filters(updates["filters"])
    return await _adb(db.update_dashboard, dashboard_id, **updates)


@router.delete("/api/dashboards/{dashboard_id}")
async def delete_dashboard(dashboard_id: int, request: Request, _access: dict = Depends(require_capability("dashboards.author"))):
    user = _user(request)
    db   = _db()
    d    = await _adb(db.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    await _adb(db.delete_dashboard, dashboard_id)
    audit_event(db, user, request, "delete_dashboard", "dashboard", dashboard_id)
    return {"message": "Dashboard deleted"}


# ── Widget endpoints ───────────────────────────────────────────────────────────

@router.get("/api/dashboards/{dashboard_id}/widgets")
async def list_widgets(dashboard_id: int, request: Request, _access: dict = Depends(require_capability("dashboards.view"))):
    user = _user(request)
    db   = _db()
    d    = await _adb(db.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    widgets = await _adb(db.list_widgets, dashboard_id)
    return await _adb(_with_declared_params, db, widgets)


@router.post("/api/dashboards/{dashboard_id}/widgets", status_code=201)
async def create_widget(dashboard_id: int, body: CreateWidgetRequest, request: Request, _access: dict = Depends(require_capability("dashboards.author"))):
    user = _user(request)
    db   = _db()
    d    = await _adb(db.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    await _adb(_require_widget_source_access, db, user, body.widget_type, body.source_id)
    w = await _adb(db.create_widget,
        dashboard_id=dashboard_id,
        widget_type=body.widget_type,
        source_id=body.source_id,
        title=body.title,
        layout=body.layout,
        chart_type=body.chart_type,
        chart_config=body.chart_config,
        param_values=body.param_values,
    )
    return (await _adb(_with_declared_params, db, [w]))[0] if w else w


def _require_widget_source_access(db, user: dict, widget_type: str, source_id: int) -> None:
    """A widget references a saved query / SQL query / report by id; that id
    then becomes executable through the dashboard — including anonymously once
    the dashboard is shared.

    SECURITY 2026-08-23: ``source_id`` was trusted verbatim, so a user could
    point a widget at ANOTHER user's PRIVATE saved query (a query they cannot
    read via /api/queries), then read its definition and — once the dashboard
    is shared — its rows through the public token.  Bind the widget source to
    what the CREATOR may already see: the same owner/shared/public/admin rule
    ``/api/queries`` and the report/SQL lists enforce (``is_owner_or_shared``).

    A source that does NOT exist is allowed (the widget simply renders "no
    data" — a missing id is a UI/data problem, not a confidentiality leak, and
    keeps the create contract permissive for legitimately-empty dashboards);
    an EXISTING source the creator cannot access is refused with 403.
    """
    from api.deps import is_owner_or_shared
    if widget_type == "business_report":
        # A finance report has its OWN view rule (grants, groups, published
        # lifecycle) -- the one /execute applies, never owner/shared.
        from core.reports.authorization import can_view_business_report
        try:
            rep_row = db.get_business_report(source_id)
        except Exception:
            rep_row = None
        if rep_row and not can_view_business_report(rep_row, user, db):
            raise HTTPException(status_code=403,
                                detail="You do not have access to this report")
        return
    if widget_type == "report":
        # FB-60 (2026-09-26): the legacy parametric tile.  Refused by NAME, so
        # a client still sending it learns what to send instead.
        from core.reports.legacy_parametric import refusal
        raise HTTPException(status_code=400, detail=refusal(
            "dashboard tile type 'report'",
            instead="Add the tile as a Finance Report (widget_type='business_report')."))
    getter = {
        "saved_query": getattr(db, "get_query", None),
        "sql_query":   getattr(db, "get_sql_query", None),
    }.get(widget_type)
    if getter is None:
        # An unrecognised widget_type carries no resolvable source, so there is
        # nothing to authorize -- stay permissive (the create contract accepted
        # any widget_type before this guard) rather than inventing a 400.
        return
    try:
        src = getter(source_id)
    except Exception:
        src = None
    if src and not is_owner_or_shared(src, user):
        raise HTTPException(status_code=403,
                            detail="You do not have access to this widget source")


async def _require_widget_in_dashboard(db, dashboard_id: int, widget_id: int) -> None:
    """SECURITY 2026-08-22: the widget routes checked access to
    ``dashboard_id`` and then mutated ``widget_id`` GLOBALLY -- the widget was
    never confirmed to belong to that dashboard.  So the owner of dashboard A
    could PUT/DELETE ``/api/dashboards/A/widgets/{victim_widget}`` and mutate a
    widget on someone else's dashboard B.  Bind the widget to the dashboard the
    caller was authorized for; 404 (not 403) so it is not a cross-dashboard
    existence oracle."""
    ids = {w.get("id") for w in (await _adb(db.list_widgets, dashboard_id) or [])}
    if widget_id not in ids:
        raise HTTPException(status_code=404, detail="Widget not found")


@router.put("/api/dashboards/{dashboard_id}/widgets/{widget_id}")
async def update_widget(dashboard_id: int, widget_id: int,
                        body: UpdateWidgetRequest, request: Request, _access: dict = Depends(require_capability("dashboards.author"))):
    user = _user(request)
    db   = _db()
    d    = await _adb(db.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    await _require_widget_in_dashboard(db, dashboard_id, widget_id)
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    w = await _adb(db.update_widget, widget_id, **updates)
    if not w:
        raise HTTPException(status_code=404, detail="Widget not found")
    return w


@router.delete("/api/dashboards/{dashboard_id}/widgets/{widget_id}")
async def delete_widget(dashboard_id: int, widget_id: int, request: Request, _access: dict = Depends(require_capability("dashboards.author"))):
    user = _user(request)
    db   = _db()
    d    = await _adb(db.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    await _require_widget_in_dashboard(db, dashboard_id, widget_id)
    if not await _adb(db.delete_widget, widget_id):
        raise HTTPException(status_code=404, detail="Widget not found")
    audit_event(db, user, request, "delete_widget", "widget", widget_id)
    return {"message": "Widget deleted"}


@router.put("/api/dashboards/{dashboard_id}/layout")
async def update_layout(dashboard_id: int, body: LayoutUpdateRequest, request: Request, _access: dict = Depends(require_capability("dashboards.author"))):
    """Bulk update widget positions — called by react-grid-layout onLayoutChange."""
    user = _user(request)
    db   = _db()
    d    = await _adb(db.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    await _adb(db.update_widget_layouts, dashboard_id, body.layouts)
    return {"message": "Layout saved"}


# ── Access control helper ──────────────────────────────────────────────────────

def _check_dashboard_access(dashboard: dict, user: dict) -> None:
    """Non-admins can only access their own dashboards.

    SECURITY 2026-08-17: this used to return early on ``auth.type != "ad"``,
    which disabled the ownership check under ``auth.type == "local"`` -- a
    supported production mode (core/config.py accepts none|ad|local).  Every
    authenticated user could read, update and DELETE any other user's
    dashboard and widgets through the eight by-id routes that call this.

    The auth MODE decides who you are; it must not decide whether ownership
    is enforced.  The only mode that legitimately skips the check is "none",
    where there are no distinct identities to separate in the first place --
    every caller is the same anonymous principal, so a 403 would be noise.
    """
    from core.config import auth as _auth_cfg
    if _auth_cfg.type == "none":
        return
    if is_admin_like(user):
        return
    if dashboard.get("created_by") != user.get("username"):
        raise HTTPException(status_code=403, detail="Access denied")


# ── Dashboard export (2026-08-30) ─────────────────────────────────────────────
#
# DATA export only — see the module docstring for the deliberate scope (no
# PDF: recharts renders client-side; a server PDF would be empty boxes).
#
# Reuse, not copies:
#   * per-widget execution rides the SAME headless runners every other
#     surface uses (reports_api._run_parquet_report / _run_sql_report for
#     saved-query / SQL widgets, the exact runners business reports
#     dispatch to via _as_legacy_report; a legacy 'report' tile is refused
#     by name -- FB-60);
#   * widget-source authorization is api.deps.is_owner_or_shared — the SAME
#     rule _require_widget_source_access applies at widget creation and the
#     query/report lists enforce;
#   * dashboard-level authorization is _check_dashboard_access — the SAME
#     gate GET /api/dashboards/{id} (the view page) runs;
#   * rendering is business_reports_api._render_excel_bytes /
#     _render_csv_bytes / _export_truncation_disclosure /
#     _export_response_headers / _sanitize_export_filename, by import.

_XLSX_MEDIA_TYPE = ("application/vnd.openxmlformats-officedocument"
                    ".spreadsheetml.sheet")

# Excel forbids []:*?/\ in sheet titles; apostrophes at the edges break some
# readers too.  Keep 24 chars so the multi-sheet spill's " (NN)" suffix and
# our own dedupe suffix always fit inside the 31-char format limit.
_SHEET_TITLE_MAX = 24

_INFO_COLUMNS = ["widget", "widget_type", "source_id", "chart_type",
                 "location", "rows", "row_limit", "status", "detail"]


class _WidgetExportError(Exception):
    """One widget's data could not be produced.  ``reason`` is safe,
    already-sanitized text that goes INTO the export — a failed widget must
    appear with its reason, never silently vanish."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


def _safe_sheet_title(base: str, used: set) -> str:
    import re as _re
    name = _re.sub(r"[\[\]:*?/\\']", " ", str(base or "")).strip() or "widget"
    name = name[:_SHEET_TITLE_MAX]
    cand, n = name, 1
    while cand.lower() in used:
        n += 1
        suffix = f" {n}"
        cand = name[:_SHEET_TITLE_MAX - len(suffix)] + suffix
    used.add(cand.lower())
    return cand


def _widget_display_title(widget: dict) -> str:
    t = (widget.get("title") or "").strip()
    if t:
        return t
    return f"{widget.get('widget_type', 'widget')} {widget.get('source_id')}"


def _resolve_widget_rows(db, widget: dict, user: dict, limit: int) -> tuple:
    """Execute ONE widget's source and return ``(rows, columns)``.

    Reuses the headless runners the report surfaces already trust (see the
    section comment).  RLS: the EXPORTER's full principal is threaded as
    ``user_ctx`` / acting user, so the export applies the same row-security
    scope as the on-screen widget (which executes via /api/execute as the
    caller).

    Authorization: a legacy ``report`` widget is refused (FB-60); saved
    query / SQL widgets are gated here with ``api.deps.is_owner_or_shared``
    — the same rule widget CREATION applies to the source.  Export is never
    more permissive than the dashboard page: a source the caller cannot
    access fails to execute there too.
    """
    import os as _os
    import tempfile
    import uuid as _uuid

    import pandas as pd

    from api.deps import is_owner_or_shared
    from core.error_sanitizer import sanitize_error as _se

    wtype = widget.get("widget_type")
    source_id = widget.get("source_id")
    params = widget.get("param_values") or {}

    def _legacy(saved_query_id=None, sql_saved_query_id=None, name=""):
        # Minimal legacy-report dict, the same adapter shape
        # business_reports_api._as_legacy_report feeds these runners.
        # ``owner`` = the EXPORTER: any background/owner fallback inside the
        # runners then resolves to the caller's own scope — it can restrict,
        # never widen.
        return {
            "owner": user.get("username"),
            "id": int(source_id),
            "name": name or f"dashboard widget {widget.get('id')}",
            "saved_query_id": saved_query_id,
            "sql_saved_query_id": sql_saved_query_id,
            "sql_override": None,
            "parameters": [],
            "connection_override_id": None,
        }

    if wtype == "report":
        # FB-60: a tile saved before the decommission.  Its failure is
        # reported in the export by name, never as an empty sheet.
        from core.reports.legacy_parametric import refusal
        raise _WidgetExportError(refusal(
            "dashboard tile type 'report'",
            instead="Re-add the tile as a Finance Report."))

    elif wtype == "saved_query":
        src = db.get_query(int(source_id))
        if not src:
            raise _WidgetExportError(f"saved query {source_id} not found")
        if not is_owner_or_shared(src, user):
            raise _WidgetExportError(
                "access denied: the exporting user does not have access "
                "to this saved query")
        from api.reports_api import _run_parquet_report
        fd, csv_path = tempfile.mkstemp(suffix=".csv")
        _os.close(fd)
        try:
            _run_parquet_report(_legacy(saved_query_id=int(source_id),
                                        name=src.get("name") or ""),
                                params, limit, csv_path,
                                lambda _m: None, user_ctx=user, db=db)
            df = pd.read_csv(csv_path)
        except _WidgetExportError:
            raise
        except Exception as exc:
            raise _WidgetExportError(_se(str(exc)))
        finally:
            try:
                _os.unlink(csv_path)
            except OSError:
                pass

    elif wtype == "sql_query":
        src = db.get_sql_query(int(source_id))
        if not src:
            raise _WidgetExportError(f"SQL query {source_id} not found")
        if not is_owner_or_shared(src, user):
            raise _WidgetExportError(
                "access denied: the exporting user does not have access "
                "to this SQL query")
        from api.data_grid_api import find_csv_file
        from api.reports_api import _run_sql_report
        exec_id = str(_uuid.uuid4())
        try:
            _run_sql_report(_legacy(sql_saved_query_id=int(source_id),
                                    name=src.get("name") or ""),
                            params, limit, exec_id,
                            lambda _m: None, user_ctx=user, db=db)
            result_file = find_csv_file(exec_id)
            if not result_file or not result_file.exists():
                raise _WidgetExportError("execution produced no output file")
            if result_file.suffix.lower() == ".parquet":
                df = pd.read_parquet(result_file)
            else:
                df = pd.read_csv(result_file)
        except _WidgetExportError:
            raise
        except Exception as exc:
            raise _WidgetExportError(_se(str(exc)))

    else:
        raise _WidgetExportError(f"unsupported widget type {wtype!r}")

    # Exact throttle at the chokepoint (the parquet engine's early-stop is
    # chunk-granular — the R4 trim rule).
    if limit and len(df) > int(limit):
        df = df.head(int(limit))
    # NaN/NaT must not leak into openpyxl/CSV as float("nan") spellings.
    df = df.astype(object).where(pd.notna(df), None)
    return df.to_dict("records"), [str(c) for c in df.columns]


def _read_result_file(path: str) -> tuple:
    import pandas as pd
    from pathlib import Path as _P
    fp = _P(path)
    if not fp.exists():
        raise _WidgetExportError("the report run left no result file")
    df = pd.read_parquet(fp) if fp.suffix.lower() == ".parquet" else pd.read_csv(fp)
    df = df.astype(object).where(pd.notna(df), None)
    return df.to_dict("records"), [str(c) for c in df.columns]


async def _run_business_report_widget(widget: dict, user: dict, limit: int) -> tuple:
    """A finance-report tile, exported: the SAME /execute the tile calls on
    screen (its access gate, published-version fork, RLS and parameter
    checks), then its result file.  Returns ``(rows, columns)``."""
    from api.business_reports_api import ReportExecuteRequest, execute_report
    from core.error_sanitizer import sanitize_error as _se
    try:
        resp = await execute_report(
            int(widget.get("source_id")),
            ReportExecuteRequest(parameter_values=widget.get("param_values") or {},
                                 limit_override=int(limit) if limit else None),
            user=user)
    except HTTPException as exc:
        raise _WidgetExportError(str(exc.detail))
    except Exception as exc:
        raise _WidgetExportError(_se(str(exc)))
    path = (resp or {}).get("output_path") if isinstance(resp, dict) else None
    if not path:
        raise _WidgetExportError("the report run returned no result file")
    rows, cols = await _adb(_read_result_file, path)
    if limit and len(rows) > int(limit):
        rows = rows[:int(limit)]
    return rows, cols


def _collect_widget_exports(db, widgets: list, user: dict, limit: int,
                            prefetched: Optional[dict] = None) -> list:
    """Resolve every widget; a failure becomes an ERROR ENTRY, never a gap.

    Returns entries: {widget, title, rows|None, columns|None, error|None,
    truncated: bool}.  ``truncated`` uses the shared disclosure predicate
    (rows == cap ⇒ possibly cut) — the wording itself comes from
    business_reports_api._export_truncation_disclosure at render time.
    """
    from core.error_sanitizer import sanitize_error as _se
    entries = []
    prefetched = prefetched or {}
    for w in widgets:
        entry = {"widget": w, "title": _widget_display_title(w)}
        try:
            if w.get("id") in prefetched:
                got = prefetched[w.get("id")]
                if isinstance(got, _WidgetExportError):
                    raise got
                rows, cols = got
            else:
                rows, cols = _resolve_widget_rows(db, w, user, limit)
            entry.update(rows=rows, columns=cols, error=None,
                         truncated=bool(limit) and len(rows) >= int(limit))
        except _WidgetExportError as exc:
            entry.update(rows=None, columns=None, error=exc.reason,
                         truncated=False)
        except Exception as exc:  # never let one widget sink the export
            logger.warning("dashboard export: widget %s failed: %s",
                           w.get("id"), exc)
            entry.update(rows=None, columns=None, error=_se(str(exc)),
                         truncated=False)
        entries.append(entry)
    return entries


def _info_rows(entries: list, limit: int, location_key: str) -> list:
    rows = []
    for e in entries:
        w = e["widget"]
        if e["error"] is None:
            status = "truncated" if e["truncated"] else "ok"
            detail = (f"row cap {limit:,} reached — data may be incomplete"
                      if e["truncated"] else "")
            n = len(e["rows"])
        else:
            status, detail, n = "error", e["error"], 0
        rows.append({"widget": e["title"],
                     "widget_type": w.get("widget_type"),
                     "source_id": w.get("source_id"),
                     "chart_type": w.get("chart_type"),
                     "location": e.get(location_key, ""),
                     "rows": n, "row_limit": limit,
                     "status": status, "detail": detail})
    return rows


def _merge_workbook_into(out_wb, part_bytes: bytes, used_titles: set,
                         info_rename: str | None = None) -> None:
    """Copy every sheet of a rendered workbook into ``out_wb``.

    The parts are rendered by the imported business-report builder — this
    helper only RELOCATES sheets (values + styles + widths + freeze panes),
    it renders nothing.  A per-widget spill workbook's own "Export Info"
    sheet is renamed to ``info_rename`` so it cannot collide with (or
    shadow) the dashboard-level Export Info sheet appended last.
    """
    from copy import copy as _copy

    import openpyxl

    src_wb = openpyxl.load_workbook(io.BytesIO(part_bytes))
    for ws in src_wb.worksheets:
        title = ws.title
        if info_rename and title == "Export Info":
            title = info_rename
        n = 1
        base = title
        while title.lower() in used_titles:
            n += 1
            suffix = f" {n}"
            title = base[:31 - len(suffix)] + suffix
        used_titles.add(title.lower())
        tgt = out_wb.create_sheet(title=title)
        for row in ws.iter_rows():
            for c in row:
                nc = tgt.cell(row=c.row, column=c.column, value=c.value)
                if c.has_style:
                    nc.font = _copy(c.font)
                    nc.fill = _copy(c.fill)
                    nc.border = _copy(c.border)
                    nc.alignment = _copy(c.alignment)
                    nc.number_format = c.number_format
        for k, dim in ws.column_dimensions.items():
            if dim.width:
                tgt.column_dimensions[k].width = dim.width
        if ws.freeze_panes:
            tgt.freeze_panes = ws.freeze_panes


def _build_dashboard_excel(dashboard: dict, entries: list, limit: int) -> bytes:
    """One workbook: a sheet per widget + a final dashboard "Export Info"
    sheet.  Every sheet is rendered by business_reports_api._render_excel_
    bytes (per-widget truncation disclosure and the >1,048,576-row spill
    included) and then relocated — no second renderer exists here."""
    import openpyxl

    from api.business_reports_api import (_export_truncation_disclosure,
                                          _render_excel_bytes)

    used_sheet_names: set = set()
    parts = []  # (bytes, info_rename)
    for e in entries:
        sheet = _safe_sheet_title(e["title"], used_sheet_names)
        e["sheet"] = sheet
        if e["error"] is None:
            disclosure = _export_truncation_disclosure(
                "excel", len(e["rows"]), limit) if e["truncated"] else ""
            part = _render_excel_bytes(
                e["rows"], e["columns"], sheet,
                "1976D2", "FFFFFF", "brackets", True, {},
                disclosure_text=disclosure)
        else:
            part = _render_excel_bytes(
                [{"error": f"Widget could not be exported: {e['error']}"}],
                ["error"], sheet,
                "B71C1C", "FFFFFF", "brackets", False, {})
        parts.append((part, f"{sheet[:26]} Info"))

    info = _render_excel_bytes(
        _info_rows(entries, limit, "sheet"), _INFO_COLUMNS, "Export Info",
        "1976D2", "FFFFFF", "brackets", False, {},
        footer_text=(f"Dashboard '{dashboard.get('name', '')}' — tabular "
                     "data export: each sheet holds one widget's underlying "
                     "data (charts are rendered in the browser and are not "
                     "reproduced here)."))
    parts.append((info, None))

    out_wb = openpyxl.Workbook()
    out_wb.remove(out_wb.active)
    used_titles: set = set()
    for part, rename in parts:
        _merge_workbook_into(out_wb, part, used_titles, info_rename=rename)
    buf = io.BytesIO()
    out_wb.save(buf)
    return buf.getvalue()


def _build_dashboard_csv_zip(dashboard: dict, entries: list, limit: int) -> bytes:
    """Zip bundle: one CSV per widget (raw data via the shared renderer) +
    export_info.csv.  CSV cannot carry an in-file note without corrupting
    parsers (the BR precedent), so truncation/errors are disclosed in the
    manifest and in the X-QS-* response headers."""
    import zipfile

    from api.business_reports_api import (_render_csv_bytes,
                                          _sanitize_export_filename)

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for i, e in enumerate(entries, 1):
            base = _sanitize_export_filename(e["title"])[:40] or "widget"
            fname = f"{i:02d}_{base}"
            if e["error"] is None:
                e["file"] = fname + ".csv"
                zf.writestr(e["file"], _render_csv_bytes(e["rows"], e["columns"]))
            else:
                e["file"] = fname + ".ERROR.txt"
                zf.writestr(
                    e["file"],
                    (f"Widget could not be exported: {e['error']}\n"
                     ).encode("utf-8"))
        zf.writestr("export_info.csv",
                    _render_csv_bytes(_info_rows(entries, limit, "file"),
                                      _INFO_COLUMNS))
    return buf.getvalue()


async def _prepare_dashboard_export(dashboard_id: int, request: Request,
                                    limit: int,
                                    filter_values: Optional[str] = None) -> tuple:
    """Shared gate + widget resolution for both export formats.

    AUTHORIZATION: exactly the view rule — the same 404 + _check_dashboard_
    access sequence GET /api/dashboards/{id} runs, nothing more, nothing
    less.  Returns (dashboard, user, db, entries, effective_limit).
    """
    from core import config as _cfg

    user = _user(request)
    db = _db()
    d = await _adb(db.get_dashboard, dashboard_id)
    if not d:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    _check_dashboard_access(d, user)
    widgets = await _adb(db.list_widgets, dashboard_id) or []
    if not widgets:
        # An empty artifact would be a 200 with nothing useful in it — a
        # defect class, not a success.  Say why there is nothing to export.
        raise HTTPException(status_code=400,
                            detail="Dashboard has no widgets to export")
    # Same cap family as the business-report Excel/CSV exports: an explicit
    # ?limit= is honoured; the default is business_reports.excel_row_limit.
    # Applied PER WIDGET; 0/absent never means zero rows.
    effective_limit = limit if limit > 0 else int(
        _cfg.business_reports.excel_row_limit)
    # The viewer's filter values (the filter bar), else each filter's
    # default -- through the ONE binding rule the page applies.
    import json as _json

    from core.dashboard_params import (declared_widget_params,
                                       default_filter_values,
                                       effective_widget_params)
    values = default_filter_values(d.get("filters"))
    if filter_values:
        try:
            given = _json.loads(filter_values)
        except ValueError:
            raise HTTPException(status_code=422,
                                detail="filter_values must be a JSON object")
        if not isinstance(given, dict):
            raise HTTPException(status_code=422,
                                detail="filter_values must be a JSON object")
        values.update(given)
    bound = []
    for w in widgets:
        declared = await _adb(declared_widget_params, db, w)
        bound.append({**w, "param_values": effective_widget_params(w, declared, values)})
    prefetched = {}
    for w in bound:
        if w.get("widget_type") == "business_report":
            try:
                prefetched[w.get("id")] = await _run_business_report_widget(
                    w, user, effective_limit)
            except _WidgetExportError as exc:
                prefetched[w.get("id")] = exc
    entries = await _adb(_collect_widget_exports, db, bound, user,
                         effective_limit, prefetched)
    return d, user, db, entries, effective_limit


def _dashboard_export_headers(name: str, ext: str, entries: list,
                              effective_limit: int) -> dict:
    """X-QS-* headers via the shared BR helper, corrected for the multi-
    dataset shape: the helper's rows>=limit predicate is per-dataset, so
    X-QS-Truncated is recomputed from the PER-WIDGET verdicts (a summed
    row count must neither hide a cut widget nor fake one)."""
    from api.business_reports_api import (_export_response_headers,
                                          _sanitize_export_filename)
    filename = (f"{_sanitize_export_filename(name)}_"
                f"{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}{ext}")
    rows_served = sum(len(e["rows"]) for e in entries if e["error"] is None)
    headers = _export_response_headers(filename, rows_served,
                                       effective_limit, None)
    headers["X-QS-Truncated"] = (
        "true" if any(e["truncated"] for e in entries) else "false")
    headers["X-QS-Widget-Errors"] = str(
        sum(1 for e in entries if e["error"] is not None))
    return headers


@router.get("/api/dashboards/{dashboard_id}/download-excel")
async def download_dashboard_excel(dashboard_id: int, request: Request,
                                   limit: int = Query(default=0, ge=0),
                                   filter_values: Optional[str] = Query(default=None), _access: dict = Depends(require_capability("dashboards.view"))):
    """Export the dashboard's DATA as one .xlsx — a sheet per widget, named
    for it, plus a final "Export Info" sheet (rows, caps, failures)."""
    d, user, db, entries, effective_limit = await _prepare_dashboard_export(
        dashboard_id, request, limit, filter_values)
    excel_bytes = await _adb(_build_dashboard_excel, d, entries,
                             effective_limit)
    audit_event(db, user, request, "export_dashboard_excel", "dashboard",
                dashboard_id,
                details={"widgets": len(entries),
                         "errors": sum(1 for e in entries if e["error"])})
    headers = _dashboard_export_headers(
        d.get("name") or f"dashboard_{dashboard_id}", ".xlsx", entries,
        effective_limit)
    return StreamingResponse(io.BytesIO(excel_bytes),
                             media_type=_XLSX_MEDIA_TYPE, headers=headers)


@router.get("/api/dashboards/{dashboard_id}/download-csv")
async def download_dashboard_csv(dashboard_id: int, request: Request,
                                 limit: int = Query(default=0, ge=0),
                                 filter_values: Optional[str] = Query(default=None), _access: dict = Depends(require_capability("dashboards.view"))):
    """Export the dashboard's DATA as a .zip — one CSV per widget plus an
    export_info.csv manifest disclosing rows, caps and failures."""
    d, user, db, entries, effective_limit = await _prepare_dashboard_export(
        dashboard_id, request, limit, filter_values)
    zip_bytes = await _adb(_build_dashboard_csv_zip, d, entries,
                           effective_limit)
    audit_event(db, user, request, "export_dashboard_csv", "dashboard",
                dashboard_id,
                details={"widgets": len(entries),
                         "errors": sum(1 for e in entries if e["error"])})
    headers = _dashboard_export_headers(
        d.get("name") or f"dashboard_{dashboard_id}", ".zip", entries,
        effective_limit)
    return StreamingResponse(io.BytesIO(zip_bytes),
                             media_type="application/zip", headers=headers)
