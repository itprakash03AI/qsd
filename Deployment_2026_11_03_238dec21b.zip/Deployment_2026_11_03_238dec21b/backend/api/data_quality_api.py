"""
Phase 99 — Data Quality Monitoring API.

CRUD for DQ rules, run checks, view results, acknowledge failures,
summary dashboard, and admin config endpoints.
"""
import asyncio
import logging
import time
from typing import Optional, Dict, Any

from fastapi import APIRouter, Depends, HTTPException, Query
from api.deps import require_capability  # noqa: E402  (tool entitlement, 2026-10-31)
from pydantic import BaseModel, Field, field_validator

from api.deps import require_role
from core.roles import is_admin_like
# The vocabularies are DECLARED where they are owned and imported here —
# the runner registry owns rule types, the alert engine owns severities
# (2026-08-23: DQRuleUpdate used to accept ANY string for rule_type /
# target_type / severity — a saved rule silently became "Unknown
# rule_type" forever-failing, the twin-model defect class).
from core.data_quality_engine import RULE_TYPES
from core.dq_alerting import SEVERITIES, severity_meets_threshold

TARGET_TYPES = ("table", "connection", "dataset", "query")
_RULE_TYPE_RE = "^(" + "|".join(RULE_TYPES) + ")$"
_TARGET_TYPE_RE = "^(" + "|".join(TARGET_TYPES) + ")$"
_SEVERITY_RE = "^(" + "|".join(SEVERITIES) + ")$"

logger = logging.getLogger(__name__)
router = APIRouter(tags=["data-quality"])

# ── Module-level dependencies (injected from main.py::_startup) ──────────
_db_manager = None
_dq_engine = None
_cfg = None
_broadcast_fn = None

# BF-DQ-NONBLOCK: track admin-triggered "run all" so the endpoint returns
# immediately and a follow-up poll can show progress.  Same pattern as
# BF-MANUAL-SYNC-NONBLOCK in iceberg_metadata_sync — long-running admin
# work must NEVER hold the FastAPI request thread for minutes (causes
# /health probe timeouts + WS disconnects + "Backend API unavailable").
_run_all_task: Optional["asyncio.Task"] = None
_run_all_started_at: Optional[float] = None
_run_all_last_summary: Dict[str, Any] = {}


def set_dq_dependencies(db_manager=None, dq_engine=None, cfg=None, broadcast_fn=None):
    global _db_manager, _dq_engine, _cfg, _broadcast_fn
    if db_manager:
        _db_manager = db_manager
    if dq_engine:
        _dq_engine = dq_engine
    if cfg:
        _cfg = cfg
    if broadcast_fn:
        _broadcast_fn = broadcast_fn


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


# ── Pydantic models ──────────────────────────────────────────────────────

class DQRuleCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: str = ""
    rule_type: str = Field(..., pattern=_RULE_TYPE_RE)
    target_type: str = Field(default="table", pattern=_TARGET_TYPE_RE)
    target_id: Optional[int] = None
    target_table: Optional[str] = None
    column_name: Optional[str] = None
    config: Dict[str, Any] = Field(default_factory=dict)
    schedule_cron: Optional[str] = None
    enabled: bool = True
    severity: str = Field(default="warning", pattern=_SEVERITY_RE)

    @field_validator("schedule_cron")
    @classmethod
    def _valid_cron(cls, v):
        if v is None or not str(v).strip():
            return v
        from core.custom_jobs import validate_cron
        ok, msg = validate_cron(str(v))
        if not ok:
            raise ValueError(msg)
        return msg  # normalised


class DQRuleUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=200)
    description: Optional[str] = None
    rule_type: Optional[str] = Field(default=None, pattern=_RULE_TYPE_RE)
    target_type: Optional[str] = Field(default=None, pattern=_TARGET_TYPE_RE)
    target_id: Optional[int] = None
    target_table: Optional[str] = None
    column_name: Optional[str] = None
    config: Optional[Dict[str, Any]] = None
    schedule_cron: Optional[str] = None
    enabled: Optional[bool] = None
    severity: Optional[str] = Field(default=None, pattern=_SEVERITY_RE)

    @field_validator("schedule_cron")
    @classmethod
    def _valid_cron(cls, v):
        if v is None or not str(v).strip():
            return v
        from core.custom_jobs import validate_cron
        ok, msg = validate_cron(str(v))
        if not ok:
            raise ValueError(msg)
        return msg  # normalised


class DQAcknowledge(BaseModel):
    username: Optional[str] = None


# ── Authorization helpers (2026-08-23) ───────────────────────────────────


def _require_rule_mutate(rule: dict, user: dict) -> None:
    """Owner gate for PUT/DELETE on a DQ rule.

    INTENT WAS AMBIGUOUS (flagged 2026-08-22): any analyst could rewrite
    or delete any other analyst's rule — including disabling a CRITICAL
    governance check someone else relies on.  We could not find a recorded
    decision that rules are team-shared mutable objects, so this FAILS
    SAFE on the stricter reading: admins mutate anything; an analyst
    mutates only rules they created.  Reads (list/get/results) stay open
    to admin+analyst, so 403 — not 404 — leaks no existence information
    the caller doesn't already have.  If the operator decides rules are
    team-mutable, relax HERE (one gate), not per-route.
    """
    if is_admin_like(user):
        return
    if (rule.get("created_by") or "") == (user.get("username") or ""):
        return
    raise HTTPException(
        status_code=403,
        detail="Only the rule's creator or an admin may modify or delete "
               "this DQ rule.")


def _rule_connection_ids(target_type, target_id, config) -> list:
    """Every connection id a rule's execution would touch."""
    ids = []
    cid = (config or {}).get("connection_id")
    if cid is not None:
        ids.append(cid)
    if target_type == "connection" and target_id is not None:
        ids.append(target_id)
    return ids


def _assert_rule_connection_entitlement(user: dict, target_type, target_id,
                                        config) -> None:
    """★ THE LEAK GATE, DQ edition (2026-08-23).

    A DQ rule executes SQL against ``config.connection_id`` (custom_sql
    runs ARBITRARY SQL and reports the first column back in the result
    details) — so saving a rule over a connection the caller cannot use
    is the same data leak the dataset gate closes.  Datasets have
    enforced this since 2026-08-09; DQ rules did not.  Same decision,
    same code: ``core.entitlements.denied_connection_ids``.
    """
    from core.entitlements import denied_connection_ids
    ids = _rule_connection_ids(target_type, target_id, config)
    if not ids:
        return
    denied = denied_connection_ids(user, ids, db=_require_db())
    if denied:
        raise HTTPException(
            status_code=403,
            detail=f"You are not entitled to use connection {denied[0]}. "
                   "A data-quality rule can only target connections you can "
                   "already access — ask an admin to share the connection "
                   "or grant you access to it.")


# ── Rules CRUD ───────────────────────────────────────────────────────────

@router.get("/api/data-quality/rules")
async def list_rules(
    target_type: Optional[str] = None,
    target_id: Optional[int] = None,
    enabled_only: bool = False,
    include_latest: bool = False,
    user: dict = Depends(require_capability("data_quality.author")),
):
    """List DQ rules.  ``include_latest=true`` attaches each rule's
    ``latest_result`` (2026-08-23) — the dashboard used to join rules
    against the global "last 50 results" list client-side, so any rule
    whose result fell off that window showed "Never checked": a lie."""
    db = _require_db()
    rules = db.list_dq_rules(target_type=target_type, target_id=target_id,
                             enabled_only=enabled_only)
    if include_latest:
        for r in rules:
            r["latest_result"] = db.get_latest_dq_result(r["id"])
    return rules


@router.get("/api/data-quality/rules/{rule_id}")
async def get_rule(
    rule_id: int,
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    rule = db.get_dq_rule(rule_id)
    if not rule:
        raise HTTPException(404, f"DQ rule {rule_id} not found")
    return rule


@router.post("/api/data-quality/rules", status_code=201)
async def create_rule(
    body: DQRuleCreate,
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    if _cfg and _cfg.max_rules:
        existing = db.list_dq_rules()
        if len(existing) >= _cfg.max_rules:
            raise HTTPException(400, f"Maximum {_cfg.max_rules} DQ rules reached")

    _assert_rule_connection_entitlement(
        user, body.target_type, body.target_id, body.config)
    data = body.model_dump()
    data["created_by"] = user.get("username", "system")
    return db.create_dq_rule(**data)


@router.put("/api/data-quality/rules/{rule_id}")
async def update_rule(
    rule_id: int,
    body: DQRuleUpdate,
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    rule = db.get_dq_rule(rule_id)
    if not rule:
        raise HTTPException(404, f"DQ rule {rule_id} not found")
    _require_rule_mutate(rule, user)
    updates = body.model_dump(exclude_unset=True)
    if not updates:
        raise HTTPException(400, "No updates provided")
    # Gate the EFFECTIVE post-update values — an update that repoints the
    # rule at a new connection is the same act as creating it there.
    effective = {**rule, **updates}
    _assert_rule_connection_entitlement(
        user, effective.get("target_type"), effective.get("target_id"),
        effective.get("config"))
    result = db.update_dq_rule(rule_id, **updates)
    if not result:
        raise HTTPException(404, f"DQ rule {rule_id} not found")
    return result


@router.delete("/api/data-quality/rules/{rule_id}")
async def delete_rule(
    rule_id: int,
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    rule = db.get_dq_rule(rule_id)
    if not rule:
        raise HTTPException(404, f"DQ rule {rule_id} not found")
    _require_rule_mutate(rule, user)
    if not db.delete_dq_rule(rule_id):
        raise HTTPException(404, f"DQ rule {rule_id} not found")
    from core.config_active import switched_off_message
    return {"detail": switched_off_message("data quality rule")}


# ── Run checks ───────────────────────────────────────────────────────────

@router.post("/api/data-quality/rules/{rule_id}/run")
async def run_single_rule(
    rule_id: int,
    user: dict = Depends(require_capability("data_quality.author")),
):
    """Execute a single DQ rule and return the result.

    BF-DQ-NONBLOCK: ``run_rule`` does a synchronous SQL connector call
    against the rule's target connection (Snowflake / Trino / S3 etc.)
    which can take 10-60 seconds on cold caches.  Wrapped via
    ``asyncio.to_thread`` + a 60s ``wait_for`` so the FastAPI request
    thread isn't held for the full duration and concurrent /health,
    WebSocket pings, and other API calls don't queue up behind it.
    On timeout the request returns 202 with `completed=false` —
    the caller can poll the rule's results endpoint for the answer
    once the background work finishes.
    """
    db = _require_db()
    rule = db.get_dq_rule(rule_id)
    if not rule:
        raise HTTPException(404, f"DQ rule {rule_id} not found")

    if not _dq_engine:
        raise HTTPException(503, "Data quality engine not initialized")

    from core.data_quality_engine import record_result, run_rule

    async def _run():
        return await asyncio.to_thread(run_rule, rule)
    try:
        result_data = await asyncio.wait_for(_run(), timeout=60.0)
    except asyncio.TimeoutError:
        logger.warning(
            "DQ rule %s exceeded 60s budget — running in background; "
            "client can poll /api/data-quality/results?rule_id=%s for completion",
            rule_id, rule_id,
        )
        # Schedule the work to continue + persist whenever it completes.
        async def _continue_in_bg():
            try:
                _r = await asyncio.to_thread(run_rule, rule)
                # record_result: persist + alert dispatch (2026-08-23 —
                # this path used to persist WITHOUT dispatching, so a
                # slow rule's failure alerted nobody).
                await asyncio.to_thread(record_result, rule, _r, db=db)
            except Exception as exc:
                logger.warning("DQ rule %s background continuation failed: %s",
                               rule_id, exc)
        try:
            asyncio.get_running_loop().create_task(_continue_in_bg())
        except Exception as exc:
            # If the continuation cannot even be scheduled the result of
            # this run is LOST — that must be visible in the logs, not
            # swallowed (silent-exception rule).
            logger.warning("DQ rule %s: could not schedule background "
                           "continuation — this run's result is lost: %s",
                           rule_id, exc)
        raise HTTPException(
            status_code=202,
            detail=f"DQ rule {rule_id} taking longer than 60s — still running; "
                   f"poll /api/data-quality/results?rule_id={rule_id} for the result"
        )

    # Persist + alert dispatch through THE chokepoint (core.data_quality_
    # engine.record_result) — same code path as scheduled runs, so alert
    # behaviour cannot diverge between "a human clicked" and "the
    # scheduler ticked".
    persisted = await asyncio.to_thread(record_result, rule, result_data, db=db)

    # Notify on failure
    if not persisted.get("passed") and _broadcast_fn and _cfg and _cfg.notify_on_failure:
        severity = persisted.get("severity", "warning")
        # 2026-08-23: same threshold decision as the alert engine — one
        # helper, not an inline copy of the ordering map.
        if severity_meets_threshold(severity, _cfg.notify_severity_threshold):
            try:
                # triggered_by: main.py's _dq_ws_broadcast routes via
                # broadcast_to_user and DROPPED every payload without a
                # user (2026-08-23) — the manual-run notification never
                # reached anyone.
                _broadcast_fn({
                    "type": "dq_failure",
                    "rule_id": rule_id,
                    "rule_name": rule.get("name"),
                    "severity": severity,
                    "details": persisted.get("details"),
                    "triggered_by": user.get("username"),
                })
            except Exception as exc:
                logger.debug("DQ failure broadcast failed (best-effort): %s",
                             exc)

    # Phase 114-E alert dispatch now happens inside record_result — one
    # chokepoint for every path that records a failure.
    return persisted


@router.post("/api/data-quality/run-all")
async def run_all_rules(
    user: dict = Depends(require_capability("data_quality.manage")),
):
    """Kick a "run every enabled DQ rule" pass.  Admin only.

    BF-DQ-NONBLOCK: was awaiting ``run_all_enabled()`` inline — that
    iterates every enabled rule and runs each rule's SQL against its
    target connector (Snowflake / Trino / S3 etc).  With 10+ rules on
    cold connectors that's 5+ minutes of HTTP request held open, while
    health probes time out and the UI shows "Backend API unavailable".

    Now: schedules the batch as an asyncio.Task and returns immediately
    with ``{started, already_running, elapsed_seconds}``.  Status visible
    via GET /api/data-quality/run-all/status.  Failures still broadcast
    via the existing dq_batch_failures WS event when the batch completes.
    """
    global _run_all_task, _run_all_started_at, _run_all_last_summary

    if not _dq_engine:
        raise HTTPException(503, "Data quality engine not initialized")

    if _run_all_task is not None and not _run_all_task.done():
        elapsed = round(time.monotonic() - (_run_all_started_at or time.monotonic()), 1)
        return {
            "started":         False,
            "already_running": True,
            "elapsed_seconds": elapsed,
            "message":         f"DQ run-all is already in progress ({elapsed}s elapsed)",
        }

    from core.data_quality_engine import run_all_enabled

    _kicked_by = user.get("username")

    async def _runner():
        global _run_all_started_at, _run_all_last_summary, _run_all_task
        try:
            # force=True: the admin button means "run everything NOW" —
            # per-rule schedule_cron gating applies to scheduler ticks only.
            results = await asyncio.to_thread(run_all_enabled, True)
            _run_all_last_summary = {
                "total":     len(results),
                "passed":    sum(1 for r in results if r.get("passed")),
                "failed":    sum(1 for r in results if not r.get("passed")),
                "completed_at": time.time(),
            }
            # Broadcast failures (existing behaviour, just from the bg task now).
            if _broadcast_fn and _cfg and _cfg.notify_on_failure:
                failures = [r for r in results if not r.get("passed")]
                if failures:
                    try:
                        _broadcast_fn({
                            "type":  "dq_batch_failures",
                            "count": len(failures),
                            "rules": [
                                {"rule_id": r["rule_id"], "severity": r.get("severity")}
                                for r in failures[:10]
                            ],
                            # deliver to the admin who kicked the batch —
                            # without a user the broadcast is dropped.
                            "triggered_by": _kicked_by,
                        })
                    except Exception as exc:
                        logger.debug("DQ batch broadcast failed "
                                     "(best-effort): %s", exc)
        except Exception as exc:
            logger.warning("BF-DQ-NONBLOCK run-all background task failed: %s", exc)
            _run_all_last_summary = {"error": str(exc)[:200],
                                      "completed_at": time.time()}
        finally:
            _run_all_started_at = None
            _run_all_task = None

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        raise HTTPException(503, "No running event loop — cannot kick run-all") from None

    _run_all_started_at = time.monotonic()
    _run_all_task = loop.create_task(_runner())
    return {
        "started":         True,
        "already_running": False,
        "elapsed_seconds": 0.0,
        "message":         "DQ run-all started in background; poll /api/data-quality/run-all/status for progress",
    }


@router.get("/api/data-quality/run-all/status")
async def run_all_status(user: dict = Depends(require_capability("data_quality.author"))):
    """BF-DQ-NONBLOCK: status of the most recent admin-triggered run-all.

    Returns:
      - ``running`` (bool) — whether the batch is currently executing
      - ``elapsed_seconds`` (float | null) — wall-clock elapsed if running
      - ``last_summary`` (dict) — last completed batch's totals OR error
    """
    running = _run_all_task is not None and not _run_all_task.done()
    elapsed = (round(time.monotonic() - _run_all_started_at, 1)
               if running and _run_all_started_at else None)
    return {
        "running":         running,
        "elapsed_seconds": elapsed,
        "last_summary":    dict(_run_all_last_summary),
    }


# ── Results ──────────────────────────────────────────────────────────────

@router.get("/api/data-quality/results")
async def list_results(
    rule_id: Optional[int] = None,
    passed: Optional[bool] = None,
    limit: int = Query(default=100, ge=1, le=1000),
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    return db.list_dq_results(rule_id=rule_id, passed=passed, limit=limit)


@router.get("/api/data-quality/results/latest/{rule_id}")
async def get_latest_result(
    rule_id: int,
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    result = db.get_latest_dq_result(rule_id)
    if not result:
        raise HTTPException(404, f"No results for rule {rule_id}")
    return result


@router.post("/api/data-quality/results/{result_id}/acknowledge")
async def acknowledge_result(
    result_id: int,
    body: DQAcknowledge = None,
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    # SECURITY 2026-08-22: the acknowledgement is an ATTRIBUTION record ("who
    # signed off").  It used to take body.username when present, so any analyst
    # could record an acknowledgement under an arbitrary name.  The signer is
    # the authenticated principal; the body field is ignored.
    username = user.get("username", "system")
    result = db.acknowledge_dq_result(result_id, username)
    if not result:
        raise HTTPException(404, f"DQ result {result_id} not found")
    return result


# ── Summary / Dashboard ──────────────────────────────────────────────────

@router.get("/api/data-quality/summary")
async def get_summary(
    target_type: Optional[str] = None,
    target_id: Optional[int] = None,
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    return db.get_dq_summary(target_type=target_type, target_id=target_id)


# ── Admin config ─────────────────────────────────────────────────────────
#
# ONE declaration drives both endpoints (2026-08-23): the GET key list
# and the PUT validation used to be two separate hardcoded sets, and PUT
# wrote ANY value for an allowed key — `max_rules: "banana"` was stored
# and only exploded later inside the typed accessor's int().  Each entry
# is (coerce, describe): coerce raises ValueError on a bad value.


def _c_bool(v):
    if isinstance(v, bool):
        return v
    raise ValueError("expected a boolean")


def _c_int(minimum):
    def _c(v):
        if isinstance(v, bool) or not isinstance(v, int):
            raise ValueError("expected an integer")
        if v < minimum:
            raise ValueError(f"must be >= {minimum}")
        return v
    return _c


def _c_severity(v):
    if v not in SEVERITIES:
        raise ValueError(f"must be one of {list(SEVERITIES)}")
    return v


_ALERT_CHANNEL_TYPES = ("email", "webhook", "slack")


def _c_channels(v):
    if not isinstance(v, list):
        raise ValueError("expected a list of channel objects")
    for ch in v:
        if not isinstance(ch, dict):
            raise ValueError("each channel must be an object")
        if str(ch.get("type", "")).lower() not in _ALERT_CHANNEL_TYPES:
            raise ValueError(
                f"channel type must be one of {list(_ALERT_CHANNEL_TYPES)}")
    return v


_DQ_CONFIG_SPEC = {
    "enabled":                      _c_bool,
    "schedule_interval_minutes":    _c_int(1),
    "execution_timeout_seconds":    _c_int(1),
    "result_retention_days":        _c_int(1),
    # ge=1: `if _cfg.max_rules:` reads 0 as NO CAP (a 0==unlimited fold)
    # — refuse the 0 at the only write surface instead of folding it.
    "max_rules":                    _c_int(1),
    "max_concurrent_checks":        _c_int(1),
    "notify_on_failure":            _c_bool,
    "notify_severity_threshold":    _c_severity,
    "cleanup_interval_hours":       _c_int(1),
    "alert_channels":               _c_channels,
    # 0 is a real value here: alert on every failure (documented).
    "alert_cooldown_minutes":       _c_int(0),
}


@router.get("/api/admin/data-quality/config")
async def get_dq_config(user: dict = Depends(require_capability("data_quality.manage"))):
    from core.config import get as cfg_get
    return {k: cfg_get("data_quality", k) for k in _DQ_CONFIG_SPEC}


@router.put("/api/admin/data-quality/config")
async def update_dq_config(
    body: dict,
    user: dict = Depends(require_capability("data_quality.manage")),
):
    from core.config import set as cfg_set
    updated = {}
    errors = {}
    staged = {}
    for k, v in body.items():
        coerce = _DQ_CONFIG_SPEC.get(k)
        if coerce is None:
            continue
        try:
            staged[k] = coerce(v)
        except ValueError as exc:
            errors[k] = str(exc)
    if errors:
        # all-or-nothing: never store half of an invalid request
        raise HTTPException(422, detail={"invalid": errors})
    for k, v in staged.items():
        cfg_set("data_quality", k, v)
        updated[k] = v
    if not updated:
        raise HTTPException(400, "No valid config keys provided")
    return {"detail": "Updated", "updated": updated}


# ── Cleanup ──────────────────────────────────────────────────────────────

@router.post("/api/admin/data-quality/cleanup")
async def cleanup_results(
    retention_days: int = Query(default=90, ge=1),
    user: dict = Depends(require_capability("data_quality.manage")),
):
    db = _require_db()
    count = db.cleanup_dq_results(retention_days=retention_days)
    return {"detail": f"Cleaned up {count} old DQ results", "deleted": count}


# ── Trend (Phase 114-F) ─────────────────────────────────────────────────

@router.get("/api/data-quality/rules/{rule_id}/trend")
async def get_rule_trend(
    rule_id: int,
    limit: int = Query(default=30, ge=1, le=100),
    user: dict = Depends(require_capability("data_quality.author")),
):
    """Last N results for a rule ordered by time (for trend charting)."""
    db = _require_db()
    rule = db.get_dq_rule(rule_id)
    if not rule:
        raise HTTPException(404, f"DQ rule {rule_id} not found")
    return db.list_dq_results_for_trend(rule_id, limit=limit)


# ── Alerts (Phase 114-E) ────────────────────────────────────────────────

@router.get("/api/data-quality/alerts")
async def list_alerts(
    rule_id: Optional[int] = None,
    status: Optional[str] = None,
    limit: int = Query(default=100, ge=1, le=1000),
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    return db.list_dq_alerts(rule_id=rule_id, status=status, limit=limit)


@router.get("/api/data-quality/alerts/summary")
async def get_alert_summary(
    user: dict = Depends(require_capability("data_quality.author")),
):
    db = _require_db()
    return db.get_dq_alert_summary()
