"""
Workspaces API (Phase 25)

Endpoints:
  GET    /api/workspaces                           — list workspaces user belongs to
  POST   /api/workspaces                           — create workspace (admin)
  GET    /api/workspaces/{id}                      — get workspace details + members
  PUT    /api/workspaces/{id}                      — update name/description
  DELETE /api/workspaces/{id}                      — soft delete (admin)
  GET    /api/workspaces/{id}/members              — list members
  POST   /api/workspaces/{id}/members              — add member
  PUT    /api/workspaces/{id}/members/{username}   — update member role
  DELETE /api/workspaces/{id}/members/{username}   — remove member
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Request, Depends
from api.deps import require_capability
from pydantic import BaseModel

from core.audit import audit_event
from core.roles import ADMIN_TIER_ROLES

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager = None
_auth_cfg   = None


def set_workspace_dependencies(db_manager, auth_cfg):
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg   = auth_cfg


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


def _get_user(request: Request) -> Optional[Dict[str, Any]]:
    """Resolve the current user including role — same pattern as reports_api.

    AUTHZ (2026-08-23): gate the guest-admin shortcut through
    ``deps._auth_genuinely_disabled()`` rather than testing
    ``_auth_cfg.type == "none"`` directly.  On a config-LOAD FAILURE
    ``auth.type`` falls back to the built-in default ``'none'``, so the raw
    test short-circuits to "auth disabled — hand out guest ADMIN", the exact
    open-on-failure bypass the helper was written to close.  A missing
    ConfigMap is precisely a pod restart, and DB-backed sessions survive it.
    """
    from api.deps import _auth_genuinely_disabled
    if _auth_genuinely_disabled():
        return {"username": "guest", "role": "admin", "is_admin": True}
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        return None
    if auth_header.startswith("Bearer "):
        try:
            from main import _get_session
            return _get_session(auth_header[7:])
        except Exception:
            return None
    try:
        from core.ad_auth import authenticate_user, decode_basic_header
        username, password = decode_basic_header(auth_header)
        return authenticate_user(username, password)
    except Exception:
        return None


def _require_workspace_manage(db, workspace_id: int,
                              user: Optional[Dict[str, Any]]) -> None:
    """SECURITY (2026-07-06): only a global admin, the workspace CREATOR, or an
    OWNER/ADMIN member may manage a workspace (settings + membership).  Without
    this gate ANY authenticated user could POST themselves as ``owner`` and
    hijack the workspace's tenant scope on every workspace-shared connection /
    report.  Raises 401/403."""
    if user is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    from core.roles import is_admin_like
    if is_admin_like(user):
        return
    uname = user.get("username")
    try:
        ws = db.get_workspace(workspace_id) or {}
        if uname and (ws.get("created_by") == uname or ws.get("owner") == uname):
            return
    except Exception:
        pass
    try:
        for m in (db.list_workspace_members(workspace_id) or []):
            if m.get("username") == uname and str(m.get("role", "")).lower() in ("owner", "admin"):
                return
    except Exception:
        pass
    raise HTTPException(
        status_code=403,
        detail="Only a workspace owner/admin can manage this workspace.")


def _require_workspace_read(db, workspace_id: int,
                            user: Optional[Dict[str, Any]]) -> None:
    """SECURITY 2026-08-17: a workspace and its member roster are readable only
    by a global admin, the creator/owner, or a MEMBER.

    ``GET /api/workspaces/{id}`` and ``GET .../members`` accepted a ``request``
    argument and never passed it to ``_get_user`` -- so both were fully
    anonymous, returning the workspace record plus every member's username and
    role to an unauthenticated caller.  Every mutating route in this file
    already gated on ``_require_workspace_manage``; only the two reads were
    missed.

    That roster is not incidental data: ``deps.get_workspace_id`` uses
    workspace membership as the TENANT BOUNDARY for ``X-Workspace-ID``, so
    publishing it hands an attacker the exact list of names worth
    impersonating.  Read is deliberately wider than manage -- any member may
    see who else is in their workspace -- but it is no longer open to all.
    """
    if user is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    from core.roles import is_admin_like
    if is_admin_like(user):
        return
    uname = user.get("username")
    # These lookups decide an ACCESS question, so a failure must be visible.
    # Swallowing it silently would look identical to "not a member" while
    # actually meaning "we could not tell" -- and the product invariant is
    # UNKNOWN = UNSAFE.  We still deny (fail-closed), but we say why.
    try:
        ws = db.get_workspace(workspace_id) or {}
        if uname and (ws.get("created_by") == uname or ws.get("owner") == uname):
            return
    except Exception as exc:
        logger.warning("workspace %s owner lookup failed for %s: %s",
                       workspace_id, uname, exc)
    try:
        for m in (db.list_workspace_members(workspace_id) or []):
            if m.get("username") == uname:
                return
    except Exception as exc:
        logger.warning("workspace %s membership lookup failed for %s: %s",
                       workspace_id, uname, exc)
    raise HTTPException(
        status_code=403,
        detail="You are not a member of this workspace.")


def _require_admin(request: Request) -> Dict[str, Any]:
    """Raise 403 if auth is enabled and the user is not admin.

    AUTHZ (2026-08-23): same fix as ``_get_user`` — the auth-disabled
    shortcut is gated through ``deps._auth_genuinely_disabled()`` so a
    config-load failure (``auth.type`` defaulting to ``'none'``) can no
    longer open every workspace-admin route to an anonymous caller.
    """
    from api.deps import _auth_genuinely_disabled, check_capability
    if _auth_genuinely_disabled():
        return {"username": "guest", "role": "admin", "is_admin": True}
    user = _get_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    # 2026-10-31 -- tool entitlement: the ONE decision, the same question the
    # route's require_capability dependency asks (a role check until then)
    return check_capability(user, "workspaces.manage")


def _slugify(name: str) -> str:
    # 2026-09-20 -- the one slugify lives in core.slugs (reports use it too).
    from core.slugs import slugify
    return slugify(name, fallback="workspace", max_len=100)


# ── Pydantic models ──────────────────────────────────────────────────────────

class CreateWorkspaceRequest(BaseModel):
    name:        str
    description: Optional[str] = None
    slug:        Optional[str] = None


class UpdateWorkspaceRequest(BaseModel):
    name:        Optional[str] = None
    description: Optional[str] = None


class AddMemberRequest(BaseModel):
    username: str
    role:     str = "member"   # owner / admin / member


class UpdateMemberRoleRequest(BaseModel):
    role: str


# ── Endpoints ────────────────────────────────────────────────────────────────

@router.get("/api/workspaces")
def list_workspaces(request: Request, _access: dict = Depends(require_capability("workspaces.view"))):
    db = _require_db()
    user = _get_user(request)
    # SECURITY 2026-08-17: an UNAUTHENTICATED caller produced username=None,
    # and db.list_workspaces treats username=None as "return ALL workspaces"
    # (database.py: "or all if username is None") -- so the anonymous branch
    # took the list-everything path meant for admins.  Require an identity.
    if user is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    username = user.get("username")
    # Admin sees all workspaces; others see their own
    if user.get("role") in ADMIN_TIER_ROLES:
        workspaces = db.list_workspaces(username=None)
    else:
        workspaces = db.list_workspaces(username=username)
    # Enrich with member count
    result = []
    for ws in workspaces:
        members = db.list_workspace_members(ws["id"])
        ws["member_count"] = len(members)
        result.append(ws)
    return {"workspaces": result}


@router.post("/api/workspaces", status_code=201)
def create_workspace(request: Request, body: CreateWorkspaceRequest, _access: dict = Depends(require_capability("workspaces.manage"))):
    _require_admin(request)
    db = _require_db()
    user = _get_user(request)
    slug = body.slug or _slugify(body.name)
    try:
        ws = db.create_workspace(
            name=body.name,
            slug=slug,
            description=body.description,
            created_by=user["username"] if user else None,
        )
    except Exception as exc:
        if "UNIQUE" in str(exc).upper():
            raise HTTPException(status_code=409,
                                detail="Workspace name or slug already exists")
        raise HTTPException(status_code=400, detail=str(exc))
    return ws


@router.get("/api/workspaces/{workspace_id}")
def get_workspace(workspace_id: int, request: Request, _access: dict = Depends(require_capability("workspaces.view"))):
    db = _require_db()
    ws = db.get_workspace(workspace_id)
    if not ws:
        raise HTTPException(status_code=404, detail="Workspace not found")
    _require_workspace_read(db, workspace_id, _get_user(request))  # SECURITY
    ws["members"] = db.list_workspace_members(workspace_id)
    return ws


@router.put("/api/workspaces/{workspace_id}")
def update_workspace(workspace_id: int, request: Request,
                     body: UpdateWorkspaceRequest, _access: dict = Depends(require_capability("workspaces.author"))):
    db = _require_db()
    if not db.get_workspace(workspace_id):
        raise HTTPException(status_code=404, detail="Workspace not found")
    _require_workspace_manage(db, workspace_id, _get_user(request))  # SECURITY
    kwargs = {k: v for k, v in body.model_dump().items() if v is not None}
    ws = db.update_workspace(workspace_id, **kwargs)
    if not ws:
        raise HTTPException(status_code=404, detail="Workspace not found")
    return ws


@router.delete("/api/workspaces/{workspace_id}", status_code=204)
def delete_workspace(workspace_id: int, request: Request, _access: dict = Depends(require_capability("workspaces.manage"))):
    user = _require_admin(request)
    db = _require_db()
    ok = db.delete_workspace(workspace_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Workspace not found")
    audit_event(db, user, request, "delete_workspace", "workspace", workspace_id)


@router.get("/api/workspaces/{workspace_id}/members")
def list_workspace_members(workspace_id: int, request: Request, _access: dict = Depends(require_capability("workspaces.view"))):
    db = _require_db()
    if not db.get_workspace(workspace_id):
        raise HTTPException(status_code=404, detail="Workspace not found")
    _require_workspace_read(db, workspace_id, _get_user(request))  # SECURITY
    return {"members": db.list_workspace_members(workspace_id)}


@router.post("/api/workspaces/{workspace_id}/members", status_code=201)
def add_workspace_member(workspace_id: int, request: Request,
                         body: AddMemberRequest, _access: dict = Depends(require_capability("workspaces.author"))):
    db = _require_db()
    user = _get_user(request)
    if not db.get_workspace(workspace_id):
        raise HTTPException(status_code=404, detail="Workspace not found")
    _require_workspace_manage(db, workspace_id, user)   # SECURITY: no escalation
    member = db.add_workspace_member(
        workspace_id=workspace_id,
        username=body.username,
        role=body.role,
        added_by=user["username"] if user else None,
    )
    return member


@router.put("/api/workspaces/{workspace_id}/members/{username}")
def update_workspace_member_role(workspace_id: int, username: str,
                                 request: Request,
                                 body: UpdateMemberRoleRequest, _access: dict = Depends(require_capability("workspaces.author"))):
    db = _require_db()
    _require_workspace_manage(db, workspace_id, _get_user(request))  # SECURITY
    ok = db.update_workspace_member_role(workspace_id, username, body.role)
    if not ok:
        raise HTTPException(status_code=404, detail="Member not found")
    return {"workspace_id": workspace_id, "username": username, "role": body.role}


@router.delete("/api/workspaces/{workspace_id}/members/{username}",
               status_code=204)
def remove_workspace_member(workspace_id: int, username: str,
                            request: Request, _access: dict = Depends(require_capability("workspaces.author"))):
    db = _require_db()
    user = _get_user(request)
    _require_workspace_manage(db, workspace_id, user)  # SECURITY
    ok = db.remove_workspace_member(workspace_id, username)
    if not ok:
        raise HTTPException(status_code=404, detail="Member not found")
    audit_event(db, user, request, "remove_workspace_member", "workspace_member",
                f"{workspace_id}/{username}")
