"""What the signed-in person may do (tool entitlement, 2026-10-31).

  GET /api/me/capabilities     the caller's capabilities -- the ONE question the
                               UI asks to show menus and enable buttons (E4);
                               a hidden button is convenience, the route is the gate.

Login-only by declaration (core/tool_entitlement/declarations.py): a person who
holds nothing must still be able to learn that.
"""
from __future__ import annotations

import asyncio
import logging

from fastapi import APIRouter, Depends, HTTPException

from api.deps import get_current_user
from core.tool_entitlement import engine as _te
from core.tool_entitlement.vocabulary import AREAS, CAPABILITIES

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/me", tags=["tool-entitlement"])


@router.get("/capabilities")
async def my_capabilities(user: dict = Depends(get_current_user)):
    """``{"username", "role", "capabilities": [...], "areas": {...}, "all": [...]}``.

    ``capabilities`` are the names the caller holds unscoped; ``all`` is the
    vocabulary with labels, so the UI can say what a missing one is called."""
    try:
        held = await asyncio.to_thread(_te.capabilities_of, user)
    except _te.PermissionCheckUnavailable as exc:
        logger.error("tool_entitlement: /api/me/capabilities unavailable: %s", exc)
        raise HTTPException(status_code=503,
                            detail="Your permissions could not be checked right now. Try again shortly.") from None
    return {
        "username": user.get("username"),
        "role": user.get("role"),
        "super_admin": str(user.get("role") or "").lower() == "super_admin",
        "capabilities": sorted(held),
        "areas": AREAS,
        "all": [{"name": c.name, "label": c.label, "description": c.description, "area": c.area}
                for c in CAPABILITIES.values()],
    }
